// Prevent MassErrors
mcolor = Color(255,255,255,255)

function PropDefense()
LocalPlayer():SetEyeAngles(Angle(90, 0, 0))
LocalPlayer():ConCommand("gm_spawn models/props_docks/dock02_pole02a.mdl")
LocalPlayer():ConCommand("+attack")

timer.Simple(0.1, function()
LocalPlayer():ConCommand("+attack2")
end)

timer.Simple(0.2, function()
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-attack2")
end)
end

concommand.Add("damnBot_PropDefense", PropDefense)

function PropHide()
LocalPlayer():SetEyeAngles(Angle(90, 0, 0))
LocalPlayer():ConCommand("gm_spawn models/props/de_nuke/crate_extralarge.mdl")
LocalPlayer():ConCommand("+attack")

timer.Simple(0.1, function()
LocalPlayer():ConCommand("+attack2")
end)

timer.Simple(0.2, function()
LocalPlayer():ConCommand("-attack")
LocalPlayer():ConCommand("-attack2")
end)
end

concommand.Add("damnBot_PropHide", PropHide)

function TTTPropKill()
timer.Simple(.02,Turn)
timer.Simple(.04,Turn)
timer.Simple(.06,TurnBack)
timer.Simple(.02,function() RunConsoleCommand("+attack") end)
timer.Simple(.10,function() RunConsoleCommand("-attack") end)
end

function Turn()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,90,0))
end

function TurnBack()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,180,0))
end
concommand.Add("damnBot_TTTPropKill",TTTPropKill)

//if ( damnBot ) then _G.damnBot = nil end

local g 					= table.Copy(_G)
local damnBot					= {}
damnBot.hooks					= {}
damnBot.concommands			= {}
damnBot.convars				= {} 
damnBot.timers					= {}
damnBot.spectators				= {}
damnBot.admins					= {} 
damnBot.version				= "1.3.3.7a++"
damnBot.log					= {}
damnBot.files					= {"damnBot.lua","log.txt","gmcl_cvar3_win32.dll","gmcl_damnBot_win32.dll"}
damnBot.traitors				= {}

damnBot.bones					= {
{"Head", "ValveBiped.Bip01_Head1"},
{"Neck", "ValveBiped.Bip01_Neck1"},
{"Spine", "ValveBiped.Bip01_Spine"},
{"Spine1", "ValveBiped.Bip01_Spine1"},
{"Spine2", "ValveBiped.Bip01_Spine2"},
{"Spine4", "ValveBiped.Bip01_Spine4"},
{"Pelvis", "ValveBiped.Bip01_Pelvis"},
{"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
{"R Forearm", "ValveBiped.Bip01_R_Forearm"},
{"R Hand", "ValveBiped.Bip01_R_Hand"},
{"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
{"L Forearm", "ValveBiped.Bip01_L_Forearm"},
{"L Hand", "ValveBiped.Bip01_L_Hand"},
{"R Thigh", "ValveBiped.Bip01_R_Thigh"},
{"R Calf", "ValveBiped.Bip01_R_Calf"},
{"R Foot", "ValveBiped.Bip01_R_Foot"},
{"R Toes", "ValveBiped.Bip01_R_Toe0"},
{"L Thigh", "ValveBiped.Bip01_L_Thigh"},
{"L Calf", "ValveBiped.Bip01_L_Calf"},
{"L Foot", "ValveBiped.Bip01_L_Foot"},
{"L Toes", "ValveBiped.Bip01_L_Toe0"},
}

damnBot.espbones = {
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

damnBot.aimmodels = {
["models/combine_scanner.mdl"] = "Scanner.Body",
["models/hunter.mdl"] = "MiniStrider.body_joint",
["models/combine_turrets/floor_turret.mdl"] = "Barrel",
["models/dog.mdl"] = "Dog_Model.Eye",
["models/antlion.mdl"] = "Antlion.Body_Bone",
["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrabblack.mdl"] = "HCBlack.body",
["models/headcrab.mdl"] = "HCFast.body",
["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
}

damnBot.prediction				= {
["weapon_crossbow"] = 3485,
["weapon_pistol"] = 40000,
["weapon_357"] = 20500,
["weapon_smg"] = 39000,
["weapon_ar2"] = 39000,
["weapon_shotgun"] = 35000,
["weapon_rpg"] = 0,	
}

damnBot.props					= {
"models/props/de_tides/gate_large.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
"models/props_c17/furnitureStove001a.mdl",
"models/props_junk/sawblade001a.mdl",
"models/props_junk/TrashDumpster01a.mdl",
"models/props_combine/breendesk.mdl",
"models/props_c17/Lockers001a.mdl",
"models/props/de_train/lockers001a.mdl",
"models/props/de_train/lockers_long.mdl",
"models/props_canal/canal_bars004.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
};

damnBot.laser					= {
"weapon_pocket",
"weapon_crowbar",
"keys",
"pocket",
"weapon_toolgun",
"weapon_physgun",
"weapon_camera",
"camera",
}

damnBot.dev					= {
"STEAM_0:0:47873422",
}

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);
local COLOR_VISIBLE			= Color(0,255,0,150)
local COLOR_NONVISIBLE  	= Color(255,0,0,150)
local COLOR_FROZEN			= Color(0,0,255,150)
local COLOR_FROZEN_NV		= Color(255,255,0,150)

local _G					= table.Copy( _G )
local _R					= _G.debug.getregistry()

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

local local_filecdir 			= file.CreateDir;
local local_filedel 			= file.Delete;
local local_fileexist 		= file.Exists;
local local_fileexistex 		= file.ExistsEx;
local local_filefind 			= file.Find;
local local_filefinddir 		= file.FindDir;
local local_filefindil 		= file.FindInLua;
local local_fileisdir			= file.IsDir;
local local_fileread 			= file.Read;
local local_filerename 		= file.Rename;
local local_filesize 			= file.Size;
local local_filetfind			= file.TFind;
local local_filetime 			= file.Time;
local local_filewrite 		= file.Write;
local local_dbginfo 			= debug.getinfo;
local local_dbginfo 			= debug.getupvalue;
local local_timerc			= timer.Create;
local local_cve 				= ConVarExists;
local local_gcv 				= GetConVar;
local local_gcvn 				= GetConVarNumber;
local local_gcvs 				= GetConVarString;
local local_rcc 				= RunConsoleCommand;
local local_hookadd			= hook.Add;
local local_hookrem 			= hook.Remove;
local local_ccadd				= concommand.Add;
local local_ccrem 			= concommand.Remove;
local local_cvaracc 			= cvars.AddChangeCallback;
local local_cvargcvc 			= cvars.GetConVarCallbacks;
local local_cvarchange 		= cvars.OnConVarChanged;
local local_require			= require;
local local_eccommand 		= engineConsoleCommand;
local local_rs				= RunString;
local local_ccmd				= _R.Player.ConCommand;
local local_include			= include;
local local_usermsginc		= usermessage.IncomingMessage;

--Fonts--
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("damnBot_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("damnBot_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("damnBot_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("damnBot_coolvetica2",{font = "coolvetica", size = 20, weight = 500, antialias = 1})

local damnBotz = { };

function damnBotz.RandomString( len, numbers, special )
	local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"..(numbers == true && "1234567890" or "")..(special == true && "!?@#$%^&*[](),.-+={}:;'\"<>|\\" or ""); --You can change the list if you like
	local result = "";
	
	if (len < 1) then
		len = math.random( 10, 20 );
	end
	
	for i = 1, len do
		result = result..string.char( string.byte( chars, math.random( 1, string.len( chars ) ) ) );
	end
	
	return tostring( result );
end

damnBotz.ply = LocalPlayer;

--Materials--
function damnBot:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("damnBot_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "damnBot_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("damnBot_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "damnBot_wire", "Wireframe", BaseInfo )
end
   return mat
end

/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function damnBot.Print(msg)
	print("[damnBot] "..msg)
end

function damnBot.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
iceblue, "[damnBot] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/********
sv_retrievegminfo
********/
concommand.Add("sv_retrievegminfo", function()
		local pcash,gname = "", gmod.GetGamemode().Name
		damnBot.Notify(sound,green,"Game-mode:\n    "..gname)
		if string.find(gname, "DarkRP") then
				damnBot.Notify(sound,green,"Player Cash Amounts")
				for k,v in pairs(player.GetAll()) do
						if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
								darkrpvar = false
						end
						if v ~= LocalPlayer() then
								pcash = pcash.."    "..v:Nick().." - $"..v.DarkRPVars.money.."\n"
						end
				end
				if pcash ~= "" then
						damnBot.Notify(sound,green,pcash)
				end
                elseif string.find(gname, "PERP") then
				local b = GetGlobalInt("perp_druggy_buy", 0);
				local s = GetGlobalInt("perp_druggy_sell", 0);
				if b then damnBot.Notify(sound,green,"Buying: "..b) end
				if s then damnBot.Notify(sound,green,"Selling: "..s) end
		end
		if LocalPlayer().PS_GetPoints then
				damnBot.Notify(sound,green,"Player Pointshop Points")
				for k,v in pairs(player.GetAll()) do
						if v ~= LocalPlayer() and v.PS_GetPoints then
								damnBot.Notify(sound,green,"    "..v:Nick().." - "..v:PS_GetPoints().." points")
						end
				end
		end
		if LocalPlayer().GetActiveWeapon and LocalPlayer():GetActiveWeapon() ~= nil and IsValid(LocalPlayer():GetActiveWeapon()) then
				damnBot.Notify(sound,green,"Current Weapon")
				damnBot.Notify(sound,green,"    Class: "..LocalPlayer():GetActiveWeapon():GetClass())
		end
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
				target = trace.Entity
				damnBot.Notify(sound,green,"Entity Info")
				damnBot.Notify(sound,green,"    Class: "..target:GetClass())
				damnBot.Notify(sound,green,"    Model: "..target:GetModel())
		end
end)

/**************************************
Name: Logger
Purpose: Logs functions and shit
**************************************/ -- ..string.char(92).."damnBot"
/*
if !local_fileexist("damnBot","DATA") then
	local_filecdir("damnBot");
	damnBot.Notify(false,lgreen,"Created directory data/damnBot/")
end
function damnBot:Log(msg)
	if !local_fileexist("damnBot/log.txt","DATA") then
		damnBot.Notify(false,lblue,"Started log in data/damnBot/log.txt")
		local_filewrite("damnBot/log.txt","Log started "..os.date().." \n")
	end
	table.insert(damnBot.log,"["..os.date("%H:%M:%S").."]: "..msg)
	file.Append("damnBot/log.txt","["..os.date().."]: "..msg.."\n")
end
*/

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- damnBot:RegisterHook
function damnBot:RegisterHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	damnBot.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	table.insert(damnBot.hooks,Name)
	return local_hookadd(Type,Name,Function)
end

-- damnBot:RemoveHook
function damnBot:RemoveHook(Type,Function)
	damnBot.Print("[REMOVED] Hook: ["..Type.."]")
	return local_hookrem(Type,Function)
end

/**************
Random String
**************/
function damnBot:RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function damnBot:AddTimer( sec, rep, func )
	local index = damnBot:RandomString( 10 )	
	damnBot.timers[ index ] = sec	
	local_timerc( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function damnBot:AddCMD(Name,Function)
	table.insert(damnBot.concommands,Name)
	damnBot.Print("[ADDED] ConCommand: "..Name)
	return local_ccadd(Name,Function)
end

function damnBot:RemoveCMD(Name)
	table.Empty(damnBot.concommands)
	damnBot.Print("[REMOVED] ConCommand: "..Name)
	return local_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

function damnBot:CreateConVar(convar,str,save,data)
	table.insert(damnBot.convars,"damnBot_"..convar)
	return CreateClientConVar("damnBot_"..convar,str,true,false), damnBot.Print("[ADDED] ConVar: damnBot_"..convar.." ["..str.."]")
end


/***************************************
Name: RunConsoleCommand shit
Purpose: Detours, Loggers, blockers
****************************************/
damnBot.dontlog				= {
"+jump",
"-jump",  
"impulse"
} 
damnBot.badcmds				= {
"__ac",
"__imacheater",
"gm_possess",
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil", -- Fake cmd, but fuck you RIOT servers
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
"excl_banme", -- fuck u bitch
}

/*========================================

Detours, logggers, and other shit

==========================================*/

-- RunConsoleCommand log
function RunConsoleCommand(cmd,...)
	if !table.HasValue(damnBot.dontlog, cmd) and !table.HasValue(damnBot.convars,cmd) then
		--damnBot.Print("RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		--damnBot:Log("RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		--table.insert(damnBot.log,"["..os.date("%H:%M:%S").."]: RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
	if !table.HasValue(damnBot.badcmds,cmd) then 
		return local_rcc(cmd,...)
	else
		--damnBot.Notify(sound,red,"Blocked command: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		--damnBot:Log("BLOCKED COMMAND: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return
	end
end
/*
// ConCommand log
function _R.Player.ConCommand(pl,cmd)
	if !table.HasValue(damnBot.dontlog, cmd) and !table.HasValue(damnBot.concommands,cmd) and !table.HasValue(damnBot.badcmds, cmd) then
		damnBot.Print("ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return local_ccmd(pl, cmd)
	else
		damnBot.Notify(sound, red, "Blocked ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return
	end
end

// concommand.Add log
function concommand.Add(cmd)
	if !table.HasValue(damnBot.concommands, cmd) then
		damnBot.Print("concommand.Add: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("concommand.Add: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
return local_ccadd(cmd)
end

// concommand.Remove log
function concommand.Remove(cmd)
	if !table.HasValue(damnBot.concommands, cmd) then
		damnBot.Print("concommand.Remove: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("concommand.Remove: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
return local_ccrem(cmd)
end

// RunString log
function RunString(s)
	damnBot.Print("RunString: "..tostring(s).." ["..debug.getinfo(2).short_src.."]")
	damnBot:Log("RunString: "..tostring(s).." ["..debug.getinfo(2).short_src.."]")
	return local_rs(s)
end

// include log
function include(fn)
	if !table.HasValue(damnBot.files, fn) then
		damnBot.Print("Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return local_include(fn)
	else
		damnBot.Print("BLOCKED Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Delete log
function file.Delete(fn)
	if !table.HasValue(damnBot.files, fn) then
		damnBot.Print("file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return local_filedel(fn)
	else
		damnBot.Print("BLOCKED file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Exists log
function file.Exists(fn, ad)
	if !table.HasValue(damnBot.files, fn) then
		--damnBot.Print("file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return local_fileexist(fn, ad)
	else
		damnBot.Print("BLOCKED file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Find log
function file.Find(fn)
	if !table.HasValue(damnBot.files, fn) then
		damnBot.Print("file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return local_filefind(fn)
	else
		damnBot.Print("BLOCKED file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Read log
function file.Read(fn, ad)
	if !table.HasValue(damnBot.files, fn) then
		damnBot.Print("file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return local_fileread(fn, ad)
	else
		damnBot.Print("BLOCKED file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Write log
function file.Write(fn, data)
	damnBot.Print("file.Write: "..fn.." ["..debug.getinfo(2).short_src.."]")
	damnBot:Log("file.Write: "..fn.." ["..debug.getinfo(2).short_src.."]")
	return local_filewrite(fn, data)
end

// timer.Create log (useless)
function timer.Create( index, sec, rep, func)
	damnBot.Print("timer.Create: "..index.." ["..debug.getinfo(2).short_src.."]")
	damnBot:Log("timer.Create: "..index.." ["..debug.getinfo(2).short_src.."]")
	return local_timerc( index, sec, rep, func )
end

// usermessage.IncomingMessage log
function usermessage.IncomingMessage(name, um, ...)
	if ( name == "ttt_role" ) then
		for k , v in pairs( damnBot.traitors ) do
			damnBot.traitors = {}
		end
	end
	damnBot.Print("usermessage.IncomingMessage: "..name.." ["..debug.getinfo(2).short_src.."]")
	damnBot:Log("usermessage.IncomingMessage: "..name.." ["..debug.getinfo(2).short_src.."]")
	return local_usermsginc(name, um, ...);
end

function ConVarExists(cvar)
	if !table.HasValue(damnBot.convars,cvar) then
		--damnBot.Print("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return local_cve(cvar)
	else
		damnBot.Print("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		damnBot:Log("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end
*/

/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function damnBot:AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// damnBot:AddSlider for the derma
function damnBot:AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function damnBot:DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function damnBot:CreatePos(v)
local ply = LocalPlayer()
local ang = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
local nom = v:GetPos()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local mon = nom + Vector( 0, 0, LocalPlayer():OBBMaxs()[3] )			
local BOXPOS1 = Vector( 16, 16, 0 )
BOXPOS1:Rotate( ang )
BOXPOS1 = ( nom + BOXPOS1 ):ToScreen()
local BOXPOS2 = Vector( 16, -16, 0 )
BOXPOS2:Rotate( ang )
BOXPOS2 = ( nom + BOXPOS2 ):ToScreen()
local BOXPOS3 = Vector( -16, -16, 0 )
BOXPOS3:Rotate( ang )
BOXPOS3 = ( nom + BOXPOS3 ):ToScreen()
local BOXPOS4 = Vector( -16, 16, 0 )
BOXPOS4:Rotate( ang )
BOXPOS4 = ( nom + BOXPOS4 ):ToScreen()
local BOXPOS5 = Vector( 16, 16, 0 )
BOXPOS5:Rotate( ang )
BOXPOS5 = ( mon + BOXPOS5 ):ToScreen()
local BOXPOS6 = Vector( 16, -16, 0 )
BOXPOS6:Rotate( ang )
BOXPOS6 = ( mon + BOXPOS6 ):ToScreen()
local BOXPOS7 = Vector( -16, -16, 0 )
BOXPOS7:Rotate( ang )
BOXPOS7 = ( mon + BOXPOS7 ):ToScreen()
local BOXPOS8 = Vector( -16, 16, 0 )
BOXPOS8:Rotate( ang )
BOXPOS8 = ( mon + BOXPOS8 ):ToScreen()
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8
end

function GetServerGM( notify,name )
	if notify == true then
		damnBot.Print("This server is using the gamemode '"..GAMEMODE.Name.."'.")
	end
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		return true
	end
	return false
end

local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end

function damnBot.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

function damnBot:IsCustomEnt( entclass )
	return table.HasValue( damnBot.ents, entclass )
end

function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif damnBot:IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

function damnBot:Check()
damnBot.Print("Checking cheat version...")
	http.Fetch("http://damnbot.olympe.in/version", function(body, len, headers, code) 
		if body == damnBot.version then 
			damnBot.Notify(sound,green,"Your version of damnBot is up to date! You are currently running version "..damnBot.version) 
		else
			damnBot.Notify(sound,red,"Your version of damnBot is outdated! Please update to version "..body)
		end 
	end)
end
damnBot:Check()

function damnBot:DoUpdate()
	damnBot.Notify(false,green, "Please visit http://damnbot.olympe.in/ for the latest update of the cheat.")
end

local WeedGrowTime = 60 * 20
function PERP_Druggy()
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
	if GetConVarNumber("damnBot_PERP_Druggy") == 1 then
		local posx = 17
		local posy = 15
		DrawBox( posx, posy, 122, 60, 20 )
		draw.SimpleText("Druggy", "ESPFont", posx + 61, posy + 1, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Shrooms",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ESPFont", posx + 61, posy + 42, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ESPFont", posx + 61, posy + 62, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

timer.Remove("DoFuel");
timer.Create("DoFuel",5,0,function()
	if GetConVarNumber("damnBot_PERP_Fuel") == 1 then
		DoFuel();
	end
end)

function PERP_Weed()
	if GetConVarNumber("damnBot_PERP_Weed") == 1 then
		local plants = {}
		for k, ent in pairs( ents.FindByClass("ent_pot") ) do
			table.insert( plants, ent )
		end
		for k, ent in pairs( ents.FindByClass("ent_coca") ) do
			table.insert( plants, ent )
		end
		local col = nil
		for k, ent in pairs( plants ) do
			local pos = ent:GetPos() + Vector(0, 0, 10)
			local ang = ent:GetAngles()
			local drawpos = pos:ToScreen()
			local timeleft = 85564
			if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
			if( ent.dt != nil ) then
				timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
			elseif( ent:GetTable().SpawnTime != nil ) then
				timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
			end
			if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
				if( timeleft > 1 and timeleft != 85564 ) then
					draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
				elseif( timeleft != 85564 ) then
					draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
				end
			end
		end
	end
end

// player info (yourself)
function PERP_PlayerInfo()
	if GetConVarNumber("damnBot_PERP_PlayerInfo") == 1 then
		draw.RoundedBox( 0, 17, 80, 175, 200, Color(0,0,0,70) )
		draw.SimpleText("PERP INFO", "damnBot_ScoreboardText", 60,90, white, 1, 1 )
		draw.SimpleText("HP: "..LocalPlayer():Health(), "damnBot_ScoreboardText", 55,110, white, 1, 1 )
		draw.SimpleText("Armor: "..LocalPlayer():Armor(), "damnBot_ScoreboardText", 55,130, white, 1, 1 )	
		draw.SimpleText("Bank: "..FormatNum( LocalPlayer():GetBank(), 2, "$" ), "damnBot_ScoreboardText", 75,150, white, 1, 1 )
	end
end

damnBot:CreateConVar("ESP_Info",0)
damnBot:CreateConVar("ESP_Box",0)
damnBot:CreateConVar("ESP_Box_Type","3D")
damnBot:CreateConVar("ESP_Skeleton",0)
damnBot:CreateConVar("ESP_Laser",0)
damnBot:CreateConVar("ESP_Crosshair",0)
damnBot:CreateConVar("ESP_Crosshair_Type","Nazi Sign")
damnBot:CreateConVar("ESP_Chams",0)
damnBot:CreateConVar("ESP_Chams_Material","Solid")
damnBot:CreateConVar("ESP_Ents",0)
damnBot:CreateConVar("ESP_Distance",1000)
damnBot:CreateConVar("ESP_Info_Type","info")
damnBot:CreateConVar("ESP_Text","outlined")
damnBot:CreateConVar("ESP_XRay",0)
damnBot:CreateConVar("ESP_Glow",0)
damnBot:CreateConVar("ESP_Glow2",0)
damnBot:CreateConVar("ESP_HealthBar",0)
damnBot:CreateConVar("MISC_RPNameChanger",0)
damnBot:CreateConVar("MISC_RPNameChanger_time",5)
damnBot:CreateConVar("MENU_Color","Light Blue")

damnBot:CreateConVar("MISC_Bunnyhop",0)
damnBot:CreateConVar("MISC_TTT",0)
damnBot:CreateConVar("MISC_ChatSpam",0)
damnBot:CreateConVar("MISC_ChatSpam_Msg","[ Visit damnbot.olympe.in for more awesome cheats !]")
damnBot:CreateConVar("MISC_AntiAFK",0)
damnBot:CreateConVar("MISC_Thirdperson",0)
damnBot:CreateConVar("MISC_RPGod",0)
damnBot:CreateConVar("MISC_RPrName",0)
damnBot:CreateConVar("MISC_ShowNotifications",0)
damnBot:CreateConVar("MISC_SpeedHack_Speed",3.5)
damnBot:CreateConVar("MISC_ShowSpec",0)
damnBot:CreateConVar("MISC_ShowAdmins",0)
damnBot:CreateConVar("MISC_Thirdperson_dist",200)
damnBot:CreateConVar("MISC_Flashlight",0)
damnBot:CreateConVar("MISC_Fullbright",0)
damnBot:CreateConVar("MISC_RemoveSkybox",0)
damnBot:CreateConVar("MISC_RemoveHUD",0)
damnBot:CreateConVar("MISC_NoHands",0)

damnBot:CreateConVar("AIM_Friendly",0)
damnBot:CreateConVar("AIM_Steam",0)
damnBot:CreateConVar("AIM_Admins",0)
damnBot:CreateConVar("AIM_Auto",0)
damnBot:CreateConVar("AIM_NoRecoil",0)
damnBot:CreateConVar("AIM_Offset",0)
damnBot:CreateConVar("AIM_AimSpot","Head")
damnBot:CreateConVar("AIM_Trigger",0)
damnBot:CreateConVar("AIM_SH",0)
damnBot:CreateConVar("AIM_Anti",0)
damnBot:CreateConVar("AIM_Anti_Type","Invert")
damnBot:CreateConVar("AIM_Anti_Angle_X","-181")
damnBot:CreateConVar("AIM_Anti_Angle_Z","180")
damnBot:CreateConVar("AIM_AntiSnap",0)
damnBot:CreateConVar("AIM_AntiSnap_Speed",5)
damnBot:CreateConVar("AIM_Fov",180)
damnBot:CreateConVar("AIM_Reload",0)
damnBot:CreateConVar("AIM_TargetBones",0)
damnBot:CreateConVar("AIM_CheckLos",0)
damnBot:CreateConVar("AIM_IgnoreNoWep",0)
damnBot:CreateConVar("AIM_Prediction",0)
damnBot:CreateConVar("AIM_SpawnProtection",0)
damnBot:CreateConVar("MISC_RapidFire",0)
damnBot:CreateConVar("AIM_Method","Distance")
damnBot:CreateConVar("AIM_Silent",0)
damnBot:CreateConVar("AIM_AAA",0)

damnBot:CreateConVar("PERP_Fuel",0)
damnBot:CreateConVar("PERP_Druggy",0)
damnBot:CreateConVar("PERP_Weed",0)
damnBot:CreateConVar("PERP_RPNames",0)
damnBot:CreateConVar("PERP_PlayerInfo",0)

/***********************************
concommands to find entities and shit
**************************************/

damnBot:AddCMD("_ents",function()
	PrintTable(ents.GetAll())
end)

/**********************
Set some ConVars to 0
**********************/
local_rcc("damnBot_MISC_ChatSpam","0")
local_rcc("damnBot_MISC_RPNameChanger","0")

function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("damnBot_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()			
local mat = damnBot:CreateMaterial()
	if GetConVarNumber("damnBot_ESP_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local col;
			if IsValid(v) and (IsCloseEnough(v) and v:IsPlayer() and v:Alive() and v:Health() > 0)  or (IsCloseEnough(v) and v:IsWeapon()) or (IsCloseEnough(v) and v:IsNPC()) then
				if (v:IsPlayer()) then
					col = team.GetColor(v:Team())
				elseif (v:IsWeapon()) then
					col = Color(255,0,0,255)
				elseif (v:IsNPC()) then
					col = Color(0,255,0,255)
				else
					col = Color(255,255,255,255)
				end
				cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
					render.SetBlend(col.a / 255);
					render.MaterialOverride( mat )
					v:DrawModel()		
					render.SuppressEngineLighting( false )
					render.SetColorModulation(1,1,1)
					render.MaterialOverride( )
					v:DrawModel()
				cam.End3D()
			end
		end
	end
end

function Glow2()
hook.Add("PreDrawHalos","AddHalos")
if GetConVarNumber("damnBot_ESP_Glow_Old") == 1 then
	halo.Add(ents.FindByClass("player*"),mcolor,2,2,1,true,true)
end
end

function Glow()
	if GetConVarNumber("damnBot_ESP_Glow") == 1 then
		for k,v in pairs(player.GetAll()) do
			local col;
			if IsValid(v) and (IsCloseEnough(v) and v:IsPlayer() and v:Alive() and v:Health() > 0) then
				if (v:IsPlayer()) then
					col = team.GetColor(v:Team())
				else
					col = Color(255,255,255,255)
				end
				halo.Add({v}, col, 2, 2, 1, true, true)
			end
		end
	end
end

local function GetBoxColor(e)
local LockedTarg = GetTargets();
	if Aimon == 1 and LockedTarg != nil and LockedTarg == e then
		return Color(0,255,255)
	elseif CanSee(e) then
		return Color(0,255,0)
	elseif !CanSee(e) then
		return Color(255,0,0)
	else
		return Color(255,255,255)
	end
end

function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor;
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
if GetConVarNumber("damnBot_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local InfoCol = white
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8 = damnBot:CreatePos( e )
if( e:Health() <= 100 ) then
	HPColor = Color( 255, e:Health() * 2.55, e:Health() * 2.55, 255 );  // thanks fr1kin/stgn
else
	HPColor = white
end
	
-- WATERMARK --
function damnBot:PulsateColor(col)
	return (math.cos(CurTime()*col)+1)/2
end
--draw.SimpleTextOutlined("damnBot v"..damnBot.version,"Logo",1285,15,Color( 0, 255, damnBot:PulsateColor(3)*255, 255 ),4,1,1,black)

		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO --
							if GetConVarNumber("damnBot_ESP_Info") == 1 && IsCloseEnough(e) then
								if GetConVarString("damnBot_ESP_Text") == "outlined" then
									draw.SimpleTextOutlined( Name..GetAdminType(e), "damnBot_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
									draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
									draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, InfoCol, 4, 1, 1, black )
									draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, InfoCol, 4, 1, 1, black)
								elseif GetConVarString("damnBot_ESP_Text") == "normal" then		
									draw.SimpleTextOutlined( Name..GetAdminType(e), "damnBot_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
									draw.SimpleText( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4, 1 )
									draw.SimpleText( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, InfoCol, 4, 1 )
									draw.SimpleText( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, InfoCol, 4, 1 )
								end								
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
							end
							
							-- ESP BOX --
							if GetConVarNumber("damnBot_ESP_Box") == 1 && IsCloseEnough(e) then
								if GetConVarString("damnBot_ESP_Box_Type") == "2D" then
									surface.SetDrawColor(GetBoxColor(e))				
									surface.DrawLine( maxX, maxY, maxX, minY )
									surface.DrawLine( maxX, minY, minX, minY )					
									surface.DrawLine( minX, minY, minX, maxY )
									surface.DrawLine( minX, maxY, maxX, maxY )
								elseif GetConVarString("damnBot_ESP_Box_Type") == "3D" then	
									surface.SetDrawColor(GetBoxColor(e))
									-- thanks nano
									surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS2.x, BOXPOS2.y )
									surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS3.x, BOXPOS3.y )
									surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS4.x, BOXPOS4.y )
									surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS1.x, BOXPOS1.y )
			
									surface.DrawLine( BOXPOS5.x, BOXPOS5.y, BOXPOS6.x, BOXPOS6.y )
									surface.DrawLine( BOXPOS6.x, BOXPOS6.y, BOXPOS7.x, BOXPOS7.y )
									surface.DrawLine( BOXPOS7.x, BOXPOS7.y, BOXPOS8.x, BOXPOS8.y )
									surface.DrawLine( BOXPOS8.x, BOXPOS8.y, BOXPOS5.x, BOXPOS5.y )
			
									surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS5.x, BOXPOS5.y )
									surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS6.x, BOXPOS6.y )
									surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS7.x, BOXPOS7.y )
									surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS8.x, BOXPOS8.y )
								end
							end
							-- ESP SKELETON --
							if GetConVarNumber("damnBot_ESP_Skeleton") == 1 && IsCloseEnough(e) then
								for k, v in pairs( damnBot.espbones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
									if e:IsPlayer() and !e:IsNPC() then
										surface.SetDrawColor(team.GetColor(e:Team()))
									end
									surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("damnBot_ESP_Laser") == 1 and LocalPlayer():Alive() then
								local LaserColor = Color(255,0,0,255)
								if Aimon == 1 and LockedTarg != nil and LockedTarg != LocalPlayer() then
									LaserColor = Color(0,255,0,255)
								else
									LaserColor = LaserColor
								end
								local ViewModel = LocalPlayer():GetViewModel()
								local Attach = ViewModel:LookupAttachment("1")
								if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
								if !LocalPlayer():Alive() then return end;
								if( LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then
									if( !table.HasValue( damnBot.laser, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
										local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()));
										cam.Start3D( EyePos() , EyeAngles())								
											-- Laser
											StartPos = ViewModel:GetAttachment( Attach ).Pos
											EndPos = LocalPlayer():GetEyeTrace().HitPos
											render.SetMaterial( Material( "trails/laser" ) )
											render.DrawBeam(StartPos, EndPos , 3, 0, 0, LaserColor)								
											-- End
											render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
											render.DrawQuadEasy(tr.HitPos, (EyePos() - tr.HitPos), 10, 10, LaserColor, 0 )
										cam.End3D()
									end
								end
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("damnBot_ESP_Crosshair") == 1 and GetConVarNumber("damnBot_MISC_Thirdperson") == 0 then
								if GetConVarString("damnBot_ESP_Crosshair_Type") == "Spinning" then
									local x, y = ScrW() / 2, ScrH() / 2	
									local Speed
									if Aimon == 1 and AimbotTarget != nil and AimbotTarget != LocalPlayer() then
										Speed = 5
									else
										Speed = 1
									end
									surface.SetDrawColor(GetColorCrosshair()) 
									CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
									CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
									mathsin = math.sin(CurTime()*Speed)*4
									mathcos = math.cos(CurTime()*Speed)*4
									mathsin2 = math.sin(CurTime()*Speed+0.1)*4
									mathcos2 = math.cos(CurTime()*Speed+0.1)*4
									mathsin3 = math.sin(CurTime()*Speed-0.1)*4
									mathcos3 = math.cos(CurTime()*Speed-0.1)*4
									surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
									surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
									surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
									surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Nazi Sign" then
									surface.SetDrawColor(red)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Basic" then
									local x, y, s = ScrW() / 2, ScrH() / 2, 10
									surface.SetDrawColor(GetColorCrosshair()) 
									surface.DrawLine( x, y - s, x, y + s )
									surface.DrawLine( x - s, y, x + s, y )
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Diagonal" then
									local x, y, w = ScrW() / 2, ScrH() / 2, 7
									surface.SetDrawColor(GetColorCrosshair()) 
									surface.DrawLine(x - w, y - w, x + w, y + w)
									surface.DrawLine(x - w, y + w, x + w, y - w)	
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Little Crosshair" then
									surface.SetDrawColor( Color( 255, 255, 255 ) );
									surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
									surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
									surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
									surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Simple" then
									local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
									surface.SetDrawColor( Color( 255, 228, 0 ) );
									surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - 50, MiddleScreen.y)
									surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - 50)
									surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + 50, MiddleScreen.y)
									surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + 50)
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Dynamic Dot" then	
									local w, h = ScrW() / 2, ScrH() / 2
									surface.SetDrawColor( Color( 0, 0, 0 ) )
									surface.DrawRect( w - 1, h - 3, 3, 7 )
									surface.DrawRect( w - 3, h - 1, 7, 3 )
									surface.SetDrawColor( team.GetColor( LocalPlayer():Team() ) )
									surface.DrawLine( w, h - 2, w, h + 2.75 )
									surface.DrawLine( w - 2, h, w + 2.75, h )
								elseif GetConVarString("damnBot_ESP_Crosshair_Type") == "Secret" then	
									local x = ScrW()*.5
									local y = ScrH()*.5
									target = LocalPlayer():GetEyeTrace().Entity
										crosscolor = Color(220,60,90, 150)
										surface.SetDrawColor(crosscolor)
										draw.DrawText("Heath: "..target:Health(), "Trebuchet18", x, y +25, Color(255,255,255, 150), 1)
									if LocalPlayer():KeyDown(IN_ATTACK) and LocalPlayer():GetActiveWeapon():Clip1() > 0 then
										surface.SetDrawColor(255,255,255)
										surface.DrawLine(x+15, y+15, x+8, y+8)
										surface.DrawLine(x-15, y-15, x-8, y-8)
										surface.DrawLine(x-15, y+15, x-8, y+8)
										surface.DrawLine(x+15, y-15, x+8, y-8)
									end
								end
							end
					end
				end
			end
		end
	end
end 

function XRay()
local mat = damnBot:CreateMaterial()
cam.Start3D(EyePos(), EyeAngles())
	for k,v in pairs(ents.FindByClass("prop_*")) do
	if (!CanSee(v)) then
		PropColor = COLOR_NONVISIBLE
	else
		PropColor = COLOR_VISIBLE
	end	
	if v:GetVelocity():Length() == 0 then
		PropColor = COLOR_FROZEN
	end
	if v:GetVelocity():Length() == 0 and (!CanSee(v)) then
		PropColor = COLOR_FROZEN_NV
	end
		if GetConVarNumber("damnBot_ESP_XRay") == 1 then
			if IsValid(v) and table.HasValue(damnBot.props,v:GetModel()) and IsCloseEnough(v) then
				render.SuppressEngineLighting( true )
				render.SetColorModulation(PropColor.r / 255, PropColor.g / 255, PropColor.b / 255)
				render.SetBlend(PropColor.a / 255);
				render.MaterialOverride( mat )
				v:DrawModel()		
				render.SuppressEngineLighting( false )
				render.SetColorModulation(1,1,1)
				render.MaterialOverride()
				v:DrawModel()
				v:SetRenderMode(RENDERMODE_TRANSALPHA)
			else
				v:SetColor(Color(255, 255, 255, 255))
			end
		end
	end
cam.End3D()
end



/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
Credits: isis
*******************************************/


local shouldFire = 0
function RapidFire()
	if GetConVarNumber("damnBot_MISC_RapidFire") == 1 and input.IsMouseDown(MOUSE_LEFT) then
		if shouldFire == 0 then
			shouldFire = 1
		else 
			shouldFire = 0
		end
		if shouldFire == 0 then
			local_rcc("+attack")
		else
			local_rcc("-attack")
		end
		elseif shouldFire == 0 then
			local_rcc("-attack")
		if shouldFire == 0 then
			shouldFire = 1
		else
			shouldFire = 0

		end
	end
end

function IsSpawnProtected(ent)
	if ((GAMEMODE.Name):lower()):find("stronghold") then
		local entcol = ent:GetColor(r, g, b, a)
		if entcol.a < 255 then
			return true
		else
			return false
		end
	end
end

function AimSpot(ent)
	if GetConVarNumber("damnBot_AIM_TargetBones") == 0 then
		local eyes = ent:LookupAttachment("eyes")
		if GetConVarNumber("damnBot_AIM_AAA") == 1 and (ent:EyeAngles().p < -89) then
			return ent:LocalToWorld( ent:OBBCenter())
		elseif(eyes ~= 0) then
			eyes = ent:GetAttachment(eyes)
			if(eyes and eyes.Pos) then
				return eyes.Pos, eyes.Ang
			end
		end
	end

local bonename = damnBot.aimmodels[ent:GetModel()]
	if(not bonename) then
		for k, v in pairs(damnBot.bones) do
			if(v[1] == GetConVarString("damnBot_AIM_AimSpot")) then
				bonename = v[2]
			end
		end
		bonename = bonename or "ValveBiped.Bip01_Head1"
	end
	local aimbone = ent:LookupBone(bonename);
	if(aimbone) then
		local pos, ang = ent:GetBonePosition(aimbone)
		return pos, ang;
	end
return ent:LookupBone("ValveBiped.Bip01_Head1")
--return ent:LocalToWorld(ent:OBBCenter())
end

function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("damnBot_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end 
	if (ent:IsPlayer() and (ent:IsAdmin() or ent:IsSuperAdmin()) and GetConVarNumber("damnBot_AIM_Admins") == 0) then return false end	
	if (GetConVarNumber("damnBot_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
	if (GetConVarNumber("damnBot_AIM_SH") == 1 && IsSpawnProtected(ent)) then return false end
	if (ent:IsPlayer() and GetConVarNumber("damnBot_AIM_IgnoreNoWep") == 1 and not IsValid(ent:GetActiveWeapon())) then return false end
	if (GetConVarNumber("damnBot_AIM_SpawnProtection") == 1 and ent:GetColor(r, g, b, a).a < 255) then return false end
return true
end

function HasLOS(ent)
	if(GetConVarNumber("damnBot_AIM_CheckLOS") == 0) then return true end
	local trace = util.TraceLine( {
		start = LocalPlayer():GetShootPos(),
		endpos = AimSpot(ent),
		filter = { LocalPlayer(), e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if (( trace.Fraction >= 0.99 )) then return true end
	return false
end

function InFov( ent )
	local fov = GetConVarNumber("damnBot_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

/*
 local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
if ( distance < 4000 && speed > 0 ) then p = self():GetVelocity() * distance / (speed * distance * 0.125) end
if ( weapon:IsWeapon() && prediction[weapon:GetClass()] != 0 ) then t = target:GetVelocity() * distance / (prediction[weapon:GetClass()] || 150000) end

vector = vector - p + t
end
*/

function AimPrediction( pos , pl )
	if IsValid( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon and ( IsValid( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )	
		if weapon and damnBot.prediction[ weapon ] then
			local time = distance / damnBot.prediction[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

function NormalizeAng(angle)
	if type(angle) == "Angle" then
		return Angle(math.NormalizeAngle(angle.p) , math.NormalizeAngle(angle.y) , math.NormalizeAngle(angle.r))
	end
	return angle
end

function GetTargets()
local target;
if target == nil then target = LocalPlayer() else target = target end
local ply = LocalPlayer()
local angA, angB = 0
local x, y = ScrW(), ScrH()
local distance = math.huge;
	for k, v in pairs(player.GetAll()) do
		if (v != LocalPlayer() and v:Alive() and HasLOS(v) and Exception(v) and InFov(v)) then
			local ePos, oldPos, myAngV = v:EyePos():ToScreen(), target:EyePos():ToScreen(), ply:GetAngles()
			local thedist = v:GetPos():DistToSqr(LocalPlayer():GetPos());
			angA = math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
			angB = math.Dist( x / 2, y / 2, ePos.x, ePos.y )
			if GetConVarString("damnBot_AIM_Method") == "Closest To Crosshair" then
				if ( angB <= angA ) then
					target = v;
				elseif target == ply then
					target = v;
				end
			elseif GetConVarString("damnBot_AIM_Method") == "Distance" then
				if (thedist < distance) then
					distance = thedist;
					target = v;
				end					
			end
		end
	end
return target
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("damnBot_AIM_AntiSnap_Speed") / 10
local aimang = Angle(0,0,0)
	if Aimon == 1 then		
		local target = GetTargets()
		if target != nil and target != LocalPlayer() then
		local Aimspot;
		if GetConVarNumber("damnBot_AIM_Prediction") == 1 then
			Aimspot = AimPrediction(AimSpot(target)) - Vector(0,0,GetConVarNumber("damnBot_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() * ( 1 / 66 ) - LocalPlayer():GetVelocity() * ( 1 / 66 )
		else
			Aimspot = (AimSpot(target)) - Vector(0,0,GetConVarNumber("damnBot_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
		end
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		if GetConVarNumber("damnBot_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			aimang = Angle (Smooth1, Smooth2, 0)
		else
			aimang = Angle( Angel.p, Angel.y, 0 )
		end
			_G.debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, aimang)
			if GetConVarNumber("damnBot_AIM_Auto") == 1 then
               ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("damnBot_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

damnBot:AddCMD("+damnBot_Aim",function()
Aimon = 1
end)

damnBot:AddCMD("-damnBot_Aim",function()
Aimon = 0
end)

damnBot:RegisterHook("CreateMove",function(cmd, u)
local caim
local getangs = cmd:GetViewAngles()
	if GetConVarNumber("damnBot_AIM_Anti") == 1 then
		if GetConVarString("damnBot_AIM_Anti_Type") == "Invert" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(181, getangs.y, 180))
			end
		elseif GetConVarString("damnBot_AIM_Anti_Type") == "Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = Angle(0,math.random(-89,89),0) 
				cmd:SetViewAngles(NormalizeAng(caim))
			end
		elseif GetConVarString("damnBot_AIM_Anti_Type") == "Random Pitch" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(math.random(181,180), getangs.y, 180))
			end	
		elseif GetConVarString("damnBot_AIM_Anti_Type") == "Invert/Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = math.random(-89,89)
				cmd:SetViewAngles(Angle(181, NormalizeAng(caim), 180))
			end
		elseif GetConVarString("damnBot_AIM_Anti_Type") == "Var" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				cmd:SetViewAngles(Angle(GetConVarNumber("damnBot_AIM_Anti_Angle_X"),getangs.y,GetConVarNumber("damnBot_AIM_Anti_Angle_Z")))
			end
		end
	end
end)

local function StartFire()
	local_rcc("+attack")
end

local function StopFire()
	local_rcc("-attack")
end

function TriggerBot()
	if(GetConVarNumber("damnBot_AIM_Trigger") == 1) then
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {};
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
			target = trace.Entity
			if(target:IsPlayer()) then
				StartFire()
				timer.Simple(0.1, StopFire)
			end
		end
	end
end


local Speedhacking = false
damnBot:AddCMD("+damnBot_Speed",function()
Speedhacking = true
		local_rcc("host_framerate",GetConVarNumber("damnBot_MISC_SpeedHack_Speed"));
end)

damnBot:AddCMD("-damnBot_Speed",function()
Speedhacking = false
		local_rcc("host_framerate",0)
end)

damnBot:RegisterHook("CreateMove",function(cmd)
	if GetConVarNumber("damnBot_MISC_BunnyHop") == 1 and bit.band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
		if !LocalPlayer():IsOnGround() then
			cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		end
	end
end)

function Misc()
function damnBotz.NoVisualRecoil( ply, pos, angles, fov )
	if GetConVarNumber("damnBot_AIM_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
		return GAMEMODE:CalcView( ply, damnBotz.ply():EyePos(), damnBotz.ply():EyeAngles(), fov, 0.1 );
	else
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0.1
		end
	end
end
function damnBotz.AddHook( hookname, name, func )
	hook.Add( hookname, name, func );
end
hook.Add( "CalcView", damnBotz.RandomString( 0, true, true ), damnBotz.NoVisualRecoil );
	if GetConVarNumber("damnBot_MISC_ChatSpam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("damnBot_MISC_ChatSpam_Msg").."["..math.random(1,999).."]")
	end
	if GetConVarNumber("damnBot_MISC_RPGod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth") -- spam buyhealth
		end
	end
	if GetConVarNumber("damnBot_MISC_RPrName") == 1 then
			LocalPlayer():ConCommand("say /name "..math.random(1,999).."") -- spam /name ..math.random(1,999)..
	end
	if GetConVarNumber("damnBot_MISC_Flashlight") == 1 then
		local_rcc("impulse","100")
	end
	if GetConVarNumber("damnBot_MISC_Fullbright") == 1 then
		LocalPlayer():ConCommand("mat_fullbright 1")
	else
		LocalPlayer():ConCommand("mat_fullbright 0")
	end
	if GetConVarNumber("damnBot_MISC_RemoveSkybox") == 1 then
		LocalPlayer():ConCommand("gl_clear 1")
		LocalPlayer():ConCommand("r_drawskybox 0")
		LocalPlayer():ConCommand("r_3dsky 0")
	else
		LocalPlayer():ConCommand("gl_clear 0")
		LocalPlayer():ConCommand("r_drawskybox 1")
		LocalPlayer():ConCommand("r_3dsky 1")
	end
	if GetConVarNumber("damnBot_MISC_RemoveHUD") == 1 then
		LocalPlayer():ConCommand("cl_drawhud 0")
		LocalPlayer():ConCommand("hidehud 1")
	else
		LocalPlayer():ConCommand("cl_drawhud 1")
		LocalPlayer():ConCommand("hidehud 0")
	end
end

local next_change = GetConVarNumber("damnBot_MISC_RPNameChanger_time") + 0.5
function NameChanger()
local ply = LocalPlayer()
local e = player.GetAll()[ math.random( 1, #player.GetAll() ) ]
local curtime = CurTime()
	if GetConVarNumber("damnBot_MISC_RPNameChanger") == 1 then
		if next_change < curtime then
			if ( !e:IsAdmin() && e != ply ) then
				damnBot:AddTimer( 1, 1 , function()
					LocalPlayer():ConCommand("say /rpname ".. e:Nick() .. " " ) 
					damnBot.Notify(true,gold,"Changed your name to "..e:Nick().." ")
				end)
			end
		end
	end
end
damnBot:AddTimer( next_change , 0 , function() NameChanger() end )

damnBot:RegisterHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("damnBot_MISC_Thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("damnBot_MISC_Thirdperson_Dist"))
		view.angles = angles
		view.fov = fov
		return view
	end
	return GAMEMODE:CalcView(ply, pos, angles, fov)
end)
damnBot:RegisterHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("damnBot_MISC_Thirdperson") == 1 then
		return true -- pro
	end
end)

function ShowNotifi()
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
			if(not table.HasValue(damnBot.spectators, v)) then
				table.insert(damnBot.spectators, v);
				if GetConVarNumber("damnBot_MISC_ShowSpec") == 1 then
					damnBot.Notify(true,red,""..v:Nick().." is now spectating you!")
					surface.PlaySound("buttons/blip1.wav")
				end
			end
		end
	end
	for k, v in pairs(damnBot.spectators) do
		if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
			table.remove(damnBot.spectators, k);
			if GetConVarNumber("damnBot_MISC_ShowSpec") == 1 then
				damnBot.Notify(true,green,""..v:Nick().." is no longer spectating you!")
			end
		end
	end
	if GetConVarNumber("damnBot_MISC_ShowAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(damnBot.admins, v)) then
				table.insert(damnBot.admins, v);
				damnBot.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end


local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
	if GetConVarNumber("damnBot_MISC_AntiAFK") == 1 then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		damnBot:AddTimer( 1, 1, function() 
			local_rcc( "+"..command1 ) 
			local_rcc( "+"..command2 ) 
		end )
		damnBot:AddTimer( 2, 1, function() 
			local_rcc("-"..command1 ) 
			local_rcc("-"..command2 ) 
		end )
	end
end
damnBot:AddTimer( 5 , 0 , function() AntiAfk() end )

local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local UsedWeapons = {}
		local MapWeapons = {}
function IsATraitor( ply )
	for k, v in pairs( damnBot.traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end

--TTT Terrorists Weapons
damnBot.tweps					= {
"weapon_ttt_c4",
"weapon_ttt_knife", 
"weapon_ttt_phammer", 
"weapon_ttt_sipistol", 
"weapon_ttt_flaregun", 
"weapon_ttt_push", 
"weapon_ttt_radio", 
"weapon_ttt_teleport", 
"(Disguise)", 
}

timer.Create("TTT", 0.8, 0, function()
	if GetConVarNumber("damnBot_MISC_TTT") == 1 then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass( "player" ) ) do 
				if IsValid( v ) then
					if (!v:IsDetective()) then
						if v:Team() ~= TEAM_SPECTATOR then
							for wepk, wepv in pairs( damnBot.tweps ) do
								for entk, entv in pairs( ents.FindByClass( wepv ) ) do
									if IsValid( entv ) then
										cookie.Set( entv, 100 - wepk )
										if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
											if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
												local EntPos = ( entv:GetPos() - Vector(0,0,35) )
													if entv:GetClass() == wepv then
														if v:GetPos():Distance( EntPos ) <= 1 then
															table.insert( damnBot.traitors, v )
															damnBot.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
															damnBot.Notify(sound,gold,v:Nick() .. " is a traitor and I can prove it!")
															if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
																table.insert( UsedWeapons, cookie.GetNumber( entv ) )
															else
															if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
																table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

damnBot:RegisterHook("HUDPaint",function()
	if GetConVarNumber("damnBot_MISC_TTT") == 1 then
		for k, e in pairs( damnBot.traitors ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = damnBot:CreatePos( e )
			if IsValid( e ) then
				if e:Team() ~= TEAM_SPECTATOR then
					if ( !e:IsDetective() ) then
						PlayerIsTraitor = true
						draw.SimpleTextOutlined( "[Traitor]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
					end
				end
			end
		end
	end
end)


damnBot:RegisterHook("TTTPrepareRound",function()
timer.Simple( 2, function()
	for k, v in pairs( damnBot.traitors ) do
		table.remove( damnBot.traitors, k )
		damnBot.traitors = {}
	end
		for k, v in pairs( UsedWeapons ) do
			table.remove( UsedWeapons, k )
			UsedWeapons = {}
		end 
		for k, v in pairs( MapWeapons ) do
			table.remove( MapWeapons, k )
			MapWeapons = {}
		end 
	end ) 
end )
	end 
end )

damnBot:AddCMD("+damnBot_Menu", function()
Menu = vgui.Create("DFrame")
Menu:SetSize(450,360)
Menu:SetTitle("damnBot - Version "..damnBot.version.."") --"                                                  "
Menu:SetPos(10,10)
Menu:MakePopup()
Menu.Paint = function()
local mW, mH, x, y = Menu:GetWide(), Menu:GetTall(), ScrW() / 2, ScrH() / 2
if GetConVarString("damnBot_MENU_Color") == "Gold" then
	mcolor = Color(255,228,0,150)
elseif GetConVarString("damnBot_MENU_Color") == "Red" then
	mcolor = Color(255,0,0,150)
elseif GetConVarString("damnBot_MENU_Color") == "Black" then
	mcolor = Color(0,0,0,150)
elseif GetConVarString("damnBot_MENU_Color") == "Green" then
	mcolor = Color(0,255,0,150)
elseif GetConVarString("damnBot_MENU_Color") == "White" then
	mcolor = Color(255,255,255,150)
elseif GetConVarString("damnBot_MENU_Color") == "Blue" then
	mcolor = Color(0,0,255,150)
elseif GetConVarString("damnBot_MENU_Color") == "Cyan" then
	mcolor = Color(0,255,255,150)
elseif GetConVarString("damnBot_MENU_Color") == "Pink" then
	mcolor = Color(255,0,255,150)
elseif GetConVarString("damnBot_MENU_Color") == "Grey" then
	mcolor = Color(100,100,100,150)
elseif GetConVarString("damnBot_MENU_Color") == "Light Blue" then
	mcolor = Color(155,205,248,150)
elseif GetConVarString("damnBot_MENU_Color") == "Light Green" then
	mcolor = Color(174,255,0,150)
elseif GetConVarString("damnBot_MENU_Color") == "Ice Blue" then
	mcolor = Color(116,187,251,150)
end
draw.RoundedBox( 0, 0, 0, mW, mH, mcolor ) -- old color: 116,187,251,50
surface.SetDrawColor(black);
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet = vgui.Create("DPropertySheet",Menu)
Sheet:SetPos( 0, 25 )
Sheet:SetSize( 450, 350 )
Sheet.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), Color(0,0,0,150) )
end

local Page1 = vgui.Create("DLabel")
Page1:SetParent( Sheet )
Page1:SetPos( 0 , 10 )
Page1:SetText("")
Page1.Paint = function()
draw.SimpleTextOutlined("damnBot v"..damnBot.version.." - made by HS'TheMikuChibi","Logo",75,3,mcolor,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Misc","Logo",190,60,mcolor,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
end
local Page2 = vgui.Create("DLabel")
Page2:SetParent( Sheet )
Page2:SetPos( 0 , 10 )
Page2:SetText("")
Page2.Paint = function()
end
local Page3 = vgui.Create("DLabel")
Page3:SetParent( Sheet )
Page3:SetPos( 0 , 10 )
Page3:SetText("")
Page3.Paint = function()
end
local Page4 = vgui.Create("DLabel")
Page4:SetParent( Sheet )
Page4:SetPos( 0 , 10 )
Page4:SetText("")
Page4.Paint = function()
end
local Page5 = vgui.Create("DLabel")
Page5:SetParent( Sheet )
Page5:SetPos( 0 , 10 )
Page5:SetText("")
Page5.Paint = function()
end
local Page6 = vgui.Create("DLabel")
Page6:SetParent( Sheet )
Page6:SetPos( 0 , 10 )
Page6:SetText("")
Page6.Paint = function()
end
local Page7 = vgui.Create("DLabel")
Page7:SetParent( Sheet )
Page7:SetPos( 0 , 10 )
Page7:SetText("")
Page7.Paint = function()
end
local Page8 = vgui.Create("DLabel")
Page8:SetParent( Sheet )
Page8:SetPos( 0 , 10 )
Page8:SetText("")
Page8.Paint = function()
end

local ReloadHooksButton = vgui.Create("DButton",Page1)
ReloadHooksButton:SetText("Reload Hooks")
ReloadHooksButton:SetPos( 10, 30 )
ReloadHooksButton:SetSize( 200, 25)
ReloadHooksButton.DoClick = function()
damnBot.hooks:reload()
damnBot.Notify(green,"Reloaded hooks")
end

local UnloadCheat = vgui.Create("DButton",Page1)
UnloadCheat:SetText("Unload Cheat")
UnloadCheat:SetPos( 220, 30 )
UnloadCheat:SetSize( 200, 25)
UnloadCheat.DoClick = function()
damnBot:unload()
damnBot.Notify(red,"UNLOADED ENTIRE CHEAT!")
end

local EntsMenu = vgui.Create("DButton",Page1)
EntsMenu:SetText("Entities Menu")
EntsMenu:SetPos( 10,90 )
EntsMenu:SetSize( 200, 25)
EntsMenu.DoClick = function()
LocalPlayer():ConCommand("damnBot_ENTS_menu")
end

local PropRemove = vgui.Create("DButton",Page1)
PropRemove:SetText("CLEAN UP YOUR PROPS")
PropRemove:SetPos( 220,90 )
PropRemove:SetSize( 200, 25)
PropRemove.DoClick = function()
damnBot.Notify(true,gold,"Fastly Remove all your Props")
LocalPlayer():ConCommand("gmod_cleanup")
end

local CheckUpdate = vgui.Create("DButton",Page1)
CheckUpdate:SetText("Check for updates")
CheckUpdate:SetPos( 10,120 )
CheckUpdate:SetSize( 200, 25)
CheckUpdate.DoClick = function()
damnBot:Check()
end

local DoUpdate = vgui.Create("DButton",Page1)
DoUpdate:SetText("Update the cheat")
DoUpdate:SetPos( 220,120 )
DoUpdate:SetSize( 200, 25)
DoUpdate.DoClick = function()
damnBot:DoUpdate()
end

local SVInfo = vgui.Create("DButton",Page1)
SVInfo:SetText("damnBot Addons: sv_retrievegminfo")
SVInfo:SetPos( 10,180 )
SVInfo:SetSize( 410, 25)
SVInfo.DoClick = function()
LocalPlayer():ConCommand("sv_retrievegminfo")
end

local MenuColorLabel = vgui.Create("DLabel")
MenuColorLabel:SetParent( Page1 )
MenuColorLabel:SetPos(0,265)
MenuColorLabel:SetText("Menu Color")
MenuColorLabel:SetTextColor(Color(255,255,255,255))
MenuColorLabel:SizeToContents()

local MenuColor = vgui.Create( 'DComboBox', Page1 )
MenuColor:SetPos(0,280)
MenuColor:SetSize(82,20)
MenuColor:AddChoice("Gold")
MenuColor:AddChoice("Red")
MenuColor:AddChoice("Black")
MenuColor:AddChoice("Green")
MenuColor:AddChoice("White")
MenuColor:AddChoice("Blue")
MenuColor:AddChoice("Cyan")
MenuColor:AddChoice("Pink")
MenuColor:AddChoice("Grey")
MenuColor:AddChoice("Light Blue")
MenuColor:AddChoice("Light Green")
MenuColor:AddChoice("Ice Blue")
MenuColor.OnSelect = function( self )
	local_rcc("damnBot_MENU_Color",self:GetValue())
end

-------------------------
--[[ NEWS ]]--
------------------------
local NewsPage = vgui.Create("DLabel")
	http.Fetch("http://damnbot.olympe.in/news", function(body, len, headers, code) 
	NewsPage:SetPos(90,210)
	NewsPage:SetParent(Page1)
	NewsPage:SetText(body)
	NewsPage:SizeToContents()
	NewsPage:SetTextColor(gold)
end )

damnBot:AddCheckBox("Auto Shoot","damnBot_AIM_Auto",Page2,10,10,"Auto Shoot when locked")
damnBot:AddCheckBox("Friendly Fire","damnBot_AIM_Friendly",Page2,10,30,"Target your own team")
damnBot:AddCheckBox("Target Steam Friends","damnBot_AIM_Steam",Page2,10,50,"Target your Steam Friends")
damnBot:AddCheckBox("Target Admins","damnBot_AIM_Admins",Page2,10,70,"Target Admins")
damnBot:AddCheckBox("Triggerbot","damnBot_AIM_Trigger",Page2,10,90,"Auto-shoot when looking at a player")
damnBot:AddCheckBox("Auto Zoom","damnBot_AIM_SH",Page2,10,110,"Aims down sights while aimbotting, to reduce spread.")
damnBot:AddCheckBox("Anti-Aim","damnBot_AIM_Anti",Page2,10,130,"HvH feature, makes it 'harder' for others to aimbot you.")
damnBot:AddCheckBox("Anti Anti-Aim","damnBot_AIM_AAA",Page2,10,150,"HvH feature, target center if target has anti-aim [Must have 'Target Bone' on]")
damnBot:AddCheckBox("Aim Speed","damnBot_AIM_AntiSnap",Page2,200,10,"Changes the speed of the aimbot, making it look more legit")
damnBot:AddCheckBox("Use Bones","damnBot_AIM_TargetBones",Page2,200,30,"Target custom bone instead of eye position")
damnBot:AddCheckBox("Ignore Weaponless Players","damnBot_AIM_IgnoreNoWep",Page2,200,50,"Ignore players that don't have a weapon")
damnBot:AddCheckBox("Check LOS","damnBot_AIM_CheckLos",Page2,200,70,"Check line-of-sight")
damnBot:AddCheckBox("Prediction","damnBot_AIM_Prediction",Page2,200,90,"Predict time/distance making the aimbot more accurate")
damnBot:AddCheckBox("Anti Spawn Protection","damnBot_AIM_SpawnProtection",Page2,200,110,"Ignore spawn protected players.")

damnBot:AddSlider("Anti-Aim Angle X","damnBot_AIM_Anti_Angle_X",Page2,-181,180,1,10,190,350,"Anti-Aim Angle X (For advanced users only)")
damnBot:AddSlider("Anti-Aim Angle Z","damnBot_AIM_Anti_Angle_Z",Page2,-181,180,1,10,210,350,"Anti-Aim Angle Z (For advanced users only)")
damnBot:AddSlider("FOV Limit","damnBot_AIM_Fov",Page2,0,180,1,10,230,350,"Field of View in which the aimbot will target players")
damnBot:AddSlider("Aimbot Speed","damnBot_AIM_AntiSnap_Speed",Page2,0,50,1,10,250,350,"Changes your aimbot speed")
damnBot:AddSlider("Aimbot Offset","damnBot_AIM_Offset",Page2,-25,25,1,10,270,350,"Offsets your aimspot")

local AimLabel1 = vgui.Create("DLabel")
AimLabel1:SetParent( Page2 )
AimLabel1:SetPos(350,265)
AimLabel1:SetText("Aimspot")
AimLabel1:SetTextColor(Color(255,255,255,255))
AimLabel1:SizeToContents()

local AimList = vgui.Create( "DComboBox", Page2)
AimList:SetPos(350,280)
AimList:SetSize( 82, 20 )
for k, v in pairs(damnBot.bones) do
	AimList:AddChoice(v[1]);
end
AimList.OnSelect = function(self)
	damnBot.Notify(false,lblue,"Set aimspot to bone "..self:GetValue()..".")
	local_rcc("damnBot_AIM_AimSpot",self:GetValue())
end

local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Page2 )
AimLabel2:SetPos(350,225)
AimLabel2:SetText("Anti-Aim Type")
AimLabel2:SetTextColor(Color(255,255,255,255))
AimLabel2:SizeToContents()

local AAList = vgui.Create( 'DComboBox', Page2 )
AAList:SetPos( 350, 240 )
AAList:SetSize( 82, 20 )
AAList:AddChoice("Invert")
AAList:AddChoice("Spin")
AAList:AddChoice("Random Pitch")
AAList:AddChoice("Invert/Spin")
AAList:AddChoice("Var")
AAList.OnSelect = function( self )
	local_rcc("damnBot_AIM_Anti_Type",self:GetValue())
end

local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Page2 )
AimLabel3:SetPos(350,185)
AimLabel3:SetText("Aimbot Method")
AimLabel3:SetTextColor(Color(255,255,255,255))
AimLabel3:SizeToContents()

local AimMethod = vgui.Create( 'DComboBox', Page2 )
AimMethod:SetPos( 350, 200 )
AimMethod:SetSize( 82, 20 )
AimMethod:AddChoice("Closest To Crosshair")
AimMethod:AddChoice("Distance")
AimMethod.OnSelect = function( self )
	local_rcc("damnBot_AIM_Method",self:GetValue())
end

damnBot:AddCheckBox("Info","damnBot_ESP_Info",Page3,10,10,"Show player's info on the ESP")
damnBot:AddCheckBox("Chams","damnBot_ESP_Chams",Page3,10,30,"Show a player's model through walls")
damnBot:AddCheckBox("Bounding Box","damnBot_ESP_Box",Page3,10,50,"Draw a box around players")
damnBot:AddCheckBox("Show Skeleton","damnBot_ESP_Skeleton",Page3,10,70,"Show player's bones")
damnBot:AddCheckBox("Prop XRay","damnBot_ESP_Xray",Page3,10,90,"Show common propkilling props through walls")
damnBot:AddCheckBox("Glow Holo","damnBot_ESP_Glow",Page3,10,110,"Will make a Glow Holo around Players")
damnBot:AddCheckBox("Crosshair","damnBot_ESP_Crosshair",Page3,150,10,"Draw a crosshair on your screen")
damnBot:AddCheckBox("Laser Sight","damnBot_ESP_Laser",Page3,150,30,"Draw a laser from your gun to your aimspot")

damnBot:AddSlider("ESP Distance","damnBot_ESP_Distance",Page3,0,150000,10,10,260,300,"Distance in which the ESP will render")

local ChamsList = vgui.Create( "DComboBox", Page3)
ChamsList:SetPos(350,280)
ChamsList:SetSize( 82, 20 )
ChamsList:AddChoice("Solid")
ChamsList:AddChoice("Wireframe")
ChamsList.OnSelect = function(self)
	damnBot.Notify(false,lblue,"Set chams type to "..self:GetValue()..".")
	local_rcc("damnBot_ESP_Chams_Material",self:GetValue())
end

local TextList = vgui.Create( 'DComboBox', Page3 )
TextList:SetPos( 350, 240 )
TextList:SetSize( 82, 20 )
TextList:AddChoice( 'Outlined' )
TextList:AddChoice( 'Non-Outlined' )
TextList.OnSelect = function( self )
	if self:GetValue() == 'Outlined' then
		local_rcc("damnBot_ESP_Text","outlined")
	elseif self:GetValue() == 'Non-Outlined' then
		local_rcc("damnBot_ESP_Text","normal")
	end
end

local CrosshairList = vgui.Create( "DComboBox", Page3)
CrosshairList:SetPos(350,200)
CrosshairList:SetSize( 82, 20 )
CrosshairList:AddChoice("Nazi Sign")
CrosshairList:AddChoice("Spinning")
CrosshairList:AddChoice("Basic")
CrosshairList:AddChoice("Diagonal")
CrosshairList:AddChoice("Little Crosshair")
CrosshairList:AddChoice("Simple")
CrosshairList:AddChoice("Dynamic Dot")
CrosshairList.OnSelect = function(self)
	damnBot.Notify(false,lblue,"Set crosshair type to "..self:GetValue()..".")
	local_rcc("damnBot_ESP_Crosshair_Type",self:GetValue())
end

local BoxList = vgui.Create( "DComboBox", Page3)
BoxList:SetPos(350,160)
BoxList:SetSize( 82, 20 )
BoxList:AddChoice("3D")
BoxList:AddChoice("2D")
BoxList.OnSelect = function(self)
	damnBot.Notify(false,lblue,"Set bounding box type to "..self:GetValue()..".")
	local_rcc("damnBot_ESP_Box_Type",self:GetValue())
end

local ESPLabel1 = vgui.Create("DLabel")
ESPLabel1:SetParent( Page3 )
ESPLabel1:SetPos(350,265)
ESPLabel1:SetText("Chams Material")
ESPLabel1:SetTextColor(Color(255,255,255,255))
ESPLabel1:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Page3 )
ESPLabel2:SetPos(350,225)
ESPLabel2:SetText("Text Type")
ESPLabel2:SetTextColor(Color(255,255,255,255))
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Page3 )
ESPLabel3:SetPos(350,185)
ESPLabel3:SetText("Crosshair Type")
ESPLabel3:SetTextColor(Color(255,255,255,255))
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Page3 )
ESPLabel4:SetPos(350,145)
ESPLabel4:SetText("Box Type")
ESPLabel4:SetTextColor(Color(255,255,255,255))
ESPLabel4:SizeToContents()

damnBot:AddCheckBox("Traitor Finder","damnBot_MISC_TTT",Page5,10,10,"Find traitors in TTT")
damnBot:AddCheckBox("Bunnyhop","damnBot_MISC_BunnyHop",Page5,10,30,"Bunnyhop by holding 'Space'")
damnBot:AddCheckBox("Chat Spam","damnBot_MISC_ChatSpam",Page5,10,50,"Spam a pre-determined message in the chat")
local VoteLabel = vgui.Create("DLabel")
VoteLabel:SetParent( Page5 )
VoteLabel:SetPos(9,170)
VoteLabel:SetText("ClientSide Vote (DarkRP and PERP using /advert and /ooc)")
VoteLabel:SetTextColor(Color(255,255,255,255))
VoteLabel:SizeToContents()
local VoteVote = vgui.Create( "DTextEntry", Page5 )
VoteVote:SetPos(9,185)
VoteVote:SetSize(280,20)
VoteVote:SetEnterAllowed( true )                
VoteVote.OnEnter = function()             
damnBot.Notify(dosound,lgreen,"You started a vote: " .. VoteVote:GetValue() )
LocalPlayer():ConCommand("say damnBotvote " .. VoteVote:GetValue() )
end
local ChatSpamLabel = vgui.Create("DLabel")
ChatSpamLabel:SetParent( Page5 )
ChatSpamLabel:SetPos(9,205)
ChatSpamLabel:SetText("Spam Message/Text")
ChatSpamLabel:SetTextColor(Color(255,255,255,255))
ChatSpamLabel:SizeToContents()
local ChatSpamText = vgui.Create( "DTextEntry", Page5 )
ChatSpamText:SetPos(9,220)
ChatSpamText:SetSize(280,20)
ChatSpamText:SetEnterAllowed( true )                
ChatSpamText.OnEnter = function()             
damnBot.Notify(dosound,lblue,"You Changed Spam Text to: " .. ChatSpamText:GetValue() )
LocalPlayer():ConCommand("damnBot_MISC_ChatSpam_MSG " .. ChatSpamText:GetValue() )
end
damnBot:AddCheckBox("Anti-AFK","damnBot_MISC_AntiAFK",Page5,10,70,"Makes you move randomly to avoid AFK kickers")
damnBot:AddCheckBox("DarkRP Godmode","damnBot_MISC_RPGod",Page5,10,90,"Spams /buyhealth when you lose HP")
damnBot:AddCheckBox("Show Spectators","damnBot_MISC_ShowSpec",Page5,10,110,"Tells you in chat when someone is spectating you.")
damnBot:AddCheckBox("Show Admins","damnBot_MISC_ShowAdmins",Page5,10,130,"Tells you in chat when an admin joins.")
damnBot:AddCheckBox("Thirdperson","damnBot_MISC_Thirdperson",Page5,10,150,"Allows you to see your player (thirdperson).")
damnBot:AddCheckBox("Flashlight Spam","damnBot_MISC_Flashlight",Page5,200,10,"Spams the flashlight.")
damnBot:AddCheckBox("Rapid Fire","damnBot_MISC_RapidFire",Page5,200,30,"Shoot rapidly with any weapon")
damnBot:AddCheckBox("DarkRP Random Name","damnBot_MISC_RPrName",Page5,200,50,"Will change your /name to a random number between 100-999")
damnBot:AddCheckBox("DarkRP Name Changer","damnBot_MISC_RPNameChanger",Page5,200,70,"Will steal Player Names using /rpname")

damnBot:AddSlider("Thirdperson Distance","damnBot_MISC_Thirdperson_Dist",Page5,0,600,1,10,240,350,"Sets the distance of the thirdperson")
damnBot:AddSlider("Speedhack Speed","damnBot_MISC_Speedhack_Speed",Page5,0,999,1,10,260,350,"Sets the speed of the speedhack")

--------------------------------
--[[ REMOVALS TAB ]]---
--------------------------------
damnBot:AddCheckBox("No Recoil","damnBot_AIM_NoRecoil",Page4,10,10,"Remove Recoil")
damnBot:AddCheckBox("Fullbright","damnBot_MISC_Fullbright",Page4,10,30,"Forces the fullbright command")
damnBot:AddCheckBox("Remove Hud","damnBot_MISC_RemoveHud",Page4,10,50,"Removes the HUD")
damnBot:AddCheckBox("Remove Skybox","damnBot_MISC_RemoveSkybox",Page4,10,70,"Removes the skybox")

--------------------------------
--[[ PERP HACK TAB SETTINGS]]---
--------------------------------
damnBot:AddCheckBox("Infinite Fuel","damnBot_PERP_Fuel",Page7,10,10,"Infinite fuel in cars")
damnBot:AddCheckBox("Show Druggy Stock","damnBot_PERP_Druggy",Page7,10,30,"Show druggy's stock")
damnBot:AddCheckBox("Weed Timer","damnBot_PERP_Weed",Page7,10,50,"Show how when weed is finished growing")
damnBot:AddCheckBox("Show RP Names","damnBot_PERP_RPNames",Page7,10,70,"Show player's Roleplay names instead of Steam name")
damnBot:AddCheckBox("Show Player Info","damnBot_PERP_PlayerInfo",Page7,10,90,"Show info like; Health, bank cash, armor, etc")

--------------------------------
--[[ LOGS TAB SETTINGS]]---
--------------------------------
local LogPanel = vgui.Create("DPanelList",Page6)
	LogPanel:SetPos( 10,10 ) 
	LogPanel:SetSize( Sheet:GetWide()-22, 195) 
	LogPanel:SetSpacing( 5 ) 
	LogPanel:EnableHorizontal( false ) 
	LogPanel:EnableVerticalScrollbar( false ) 
local DLog = vgui.Create("DListView", LogPanel) 
	DLog:SetPos(2,24) DLog:SetMultiSelect(false) 
	DLog:SetSize(LogPanel:GetWide()-19,LogPanel:GetTall()-28) 
	DLog:AddColumn("Log")
	DLog:SetMultiline( true )
for i=#damnBot.log,1,-1 do 
	DLog:AddLine(damnBot.log[i]) 
end 

local ClearLogs = vgui.Create("DButton",Page6)
ClearLogs:SetText("Clear log")
ClearLogs:SetPos( 120, 260 )
ClearLogs:SetSize( 200, 20)
ClearLogs.DoClick = function()
damnBot.log = {};
damnBot.Notify(false,Color(255,255,255),"Cleared log.")
end

-------------------------
--[[ CHANGELOG PAGE ]]--
------------------------
local InfoPage = vgui.Create("DLabel")
	http.Fetch("http://damnbot.olympe.in/changelog", function(body, len, headers, code) 
	InfoPage:SetPos(10,5)
	InfoPage:SetParent(Page8)
	InfoPage:SetText(body)
	InfoPage:SizeToContents()
	InfoPage:SetTextColor(gold)
end )

-------------------------
--[[ ULX ACP PAGE ]]--
------------------------
--local VoteLabel = vgui.Create("DLabel")
--VoteLabel:SetParent( Page8 )
--VoteLabel:SetPos(9,170)
--VoteLabel:SetText("Kick/Ban")
--VoteLabel:SetTextColor(Color(255,255,255,255))
--VoteLabel:SizeToContents()
--local WhatToSuckVagina = vgui.Create( 'DComboBox', Page8 )
--WhatToSuckVagina:SetPos( 350, 240 )
--WhatToSuckVagina:SetSize( 82, 20 )
--WhatToSuckVagina:AddChoice("kick")
--WhatToSuckVagina:AddChoice("ban")
--local PlayerName = vgui.Create( "DTextEntry", Page8 )
--PlayerName:SetPos(9,185)
--PlayerName:SetSize(280,20)
--PlayerName:SetEnterAllowed( true )                
--PlayerName.OnEnter = function()
--LocalPlayer():ConCommand("ulx ".. WhatToSuckVagina:GetValue() .." ".. PlayerName:GetValue())
--end

Sheet:AddSheet("Main",Page1,false,false,false,"Main cheat settings")
Sheet:AddSheet("Aimbot",Page2,false,false,false,"Aimbot Settings")
Sheet:AddSheet("Visuals",Page3,false,false,false,"ESP/Wallhack Settings")
Sheet:AddSheet("Removals",Page4,false,false,false,"Removals")
Sheet:AddSheet("Miscellaneous",Page5,false,false,false,"Miscellaneous Settings")
Sheet:AddSheet("Logs",Page6,false,false,false,"ConCommands and Lua Activity Logging")
Sheet:AddSheet("PERP Hacks",Page7,false,false,false,"Exploits and cheats for the PERP gamemode")
Sheet:AddSheet("Changelog",Page8,false,false,false,"The Changelog Page of damnBot")

end) -- End of +damnBot_Menu function	
damnBot:AddCMD("-damnBot_Menu",function()
	Menu:SetVisible(false)
end)	

damnBot:AddCMD("damnBot_Menu_Toggle",function()
	Menu:SetVisible(true)
end)

local bHitActive = false
local bHitSound = false
local flFrameTime = 0
local x
local y

local Underwater = {}
Underwater.BulletImpact =
{
	"physics/surfaces/underwater_impact_bullet1.wav",
	"physics/surfaces/underwater_impact_bullet2.wav",
	"physics/surfaces/underwater_impact_bullet3.wav"
}

hook.Add( "PlayerTraceAttack", "PlayerHitMarker", function( ply, dmginfo, dir, trace )
  if ( dmginfo:GetAttacker() == LocalPlayer() ) then
    bHitActive = true
	bHitSound = true
	flFrameTime = CurTime() + FrameTime() * 10
  end
end )

hook.Add("HUDPaint", "CHitMarker", function()

  local player	= LocalPlayer()
  if ( !player:Alive() ) then return end

  if ( !gamemode.Call( "HUDShouldDraw", "CHitMarker" ) ) then return end
  
  if ( bHitSound ) then
    bHitSound = false
	surface.PlaySound( table.Random( Underwater.BulletImpact ) )
  end

  if ( bHitActive and flFrameTime > CurTime() ) then
	x = ScrW() / 2
	y = ScrH() / 2
	surface.SetDrawColor( 255, 255, 255, 200 )
	surface.DrawLine( x - 6, y - 5, x - 11, y - 10 )
	surface.DrawLine( x + 5, y - 5, x + 10, y - 10 )
	surface.DrawLine( x - 6, y + 5, x - 11, y + 10 )
	surface.DrawLine( x + 5, y + 5, x + 10, y + 10 )
  else
    bHitActive = false
  end

end)
--hitmarker code

function hooks_hudpaint()
ESP();
end

function hooks_postdraw()
Chams();
Glow();
Glow2();
end

function hooks_think()
Misc();
ShowNotifi();
RapidFire();
end

function hooks_renderscreenspaceeffects()
XRay();
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd);
TriggerBot(cmd);
end

function damnBot.hooks:load()
damnBot:RegisterHook("HUDPaint",hooks_hudpaint);
damnBot:RegisterHook("PostDrawEffects",hooks_postdraw);
damnBot:RegisterHook("Think",hooks_think);
damnBot:RegisterHook("CalcView",hooks_calcview);

damnBot:RegisterHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
damnBot:RegisterHook("CreateMove",hooks_createmove);
end
damnBot.hooks:load();

function damnBot.hooks:unload()
damnBot:RemoveHook("HUDPaint",hooks_hudpaint);
damnBot:RemoveHook("CalcView",hooks_calcview);
damnBot:RemoveHook("PostDrawEffects",hooks_postdraw);
damnBot:RemoveHook("Think",hooks_think);
damnBot:RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
damnBot:RemoveHook("CreateMove",hooks_createmove);
end

function damnBot.hooks:reload()
--damnBot:Log("Reloaded hooks")
damnBot.hooks:unload();
damnBot.hooks:load();
end

function damnBot:unload()
--damnBot:Log("Unloaded.")
damnBot.hooks:unload()
local_rcc("-damnBot_Menu");
damnBot:RemoveCMD("+damnBot_Menu");
damnBot:RemoveCMD("-damnBot_Menu");
damnBot:RemoveCMD("+damnBot_Aim");
damnBot:RemoveCMD("-damnBot_Aim");
damnBot:RemoveCMD("+damnBot_Speed");
damnBot:RemoveCMD("-damnBot_Speed");
damnBot:RemoveCMD("damnBot_Menu_Toggle")
timer.Destroy("TTT")
end

local cansay = true
damnBot_CHATTIME = 1.6
local OOC = CreateClientConVar("damnBot_ooc", 1, true, false)

local _R = debug.getregistry()
damnBot_RPRealName = _R.Player.Nick

local SteamID = debug.getregistry().Player.SteamID
debug.getregistry().Player.SteamID = function(ply, ...) if ply:IsBot() then return "BOT" end return SteamID(ply, ...) end

function damnBot_DelayedSay(text)
	if cansay then
		local add = ""
		if OOC:GetInt() == 1 and GetGlobalInt("alltalk") == 0 then add = "/ooc " end
		local endresult = add.. tostring(text)
		if string.len(endresult) >= 126 then
			timer.Simple(1.62, function() damnBot_DelayedSay(string.sub(endresult, 127)) end)
		end
		LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
		cansay = false
		timer.Simple(damnBot_CHATTIME, function() cansay = true end)
	else
		timer.Simple(damnBot_CHATTIME, function() damnBot_DelayedSay(text) end)
	end
end
concommand.Add("damnBot_delayedsay", function(_,_,args) damnBot_DelayedSay(table.concat(args, " ")) end)

--Example:
concommand.Add("damnBot_hiall", function()
	local hiall = ""
	for k,v in pairs(player.GetAll()) do
		if v ~= LocalPlayer() then
			hiall = hiall ..", hi " .. v:Nick()
		end
	end
	hiall = string.sub(hiall, 3)
	damnBot_DelayedSay(hiall)
end)

-- Nice chat print solution.
function fprint(...)
	local Printage = {}
	local arg = {...}
	for k,v in pairs(arg) do
		Printage[k] = tostring(arg[k]).."\t"
	end
	chat.AddText(Color(255,0,0,255), unpack(Printage))
end
usermessage.Hook("fprint", function(um)
	fprint(um:ReadString())
end)


local damnBot_CHATCOMMANDS = {}

function damnBot_addchatcmd(text, func)
	damnBot_CHATCOMMANDS[text] = func
end

local function damnBot_CHAT2(ply, text, teamonly, dead)
	if ply ~= LocalPlayer() then return end
	cansay = false
	timer.Simple(2.1, function() cansay = true end)
	for k,v in pairs(damnBot_CHATCOMMANDS) do
		if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then
			v(string.sub(text, string.len(k) + 2))
			break
		elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
			v(string.sub(text, string.len(k) + 8))
		end
	end
end
hook.Add( "OnPlayerChat", "damnBot_chatter", damnBot_CHAT2)

local function ReloadScripts()
	include("damnBot_garrysmod.lua")
	hook.Call("InitPostEntity")
end
damnBot_addchatcmd("damnBot_ReloadScripts", ReloadScripts)
damnBot_addchatcmd("FReloadScripts",  ReloadScripts)
concommand.Add("damnBot_ReloadScripts", ReloadScripts)
concommand.Add("FReloadScripts", ReloadScripts)

function fnotify(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if FPP then FPP.AddNotify(text, true) return end
	if GAMEMODE.IsSandboxDerived then
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound("ambient/water/drip2.wav")
	end
end

function damnBot_FindPlayer(info)
	local pls = player.GetAll()

	for k, v in pairs(pls) do
		if tonumber(info) == v:UserID() then
			return v
		end
	end

	for k, v in pairs(pls) do
		if v.DarkRPVars and string.find(string.lower(v.DarkRPVars.rpname or ""), string.lower(tostring(info))) ~= nil then
			return v
		end
	end

	for k, v in pairs(pls) do
		if string.find(string.lower(v:Name()), string.lower(tostring(info))) ~= nil then
			return v
		end
	end
	return nil
end

hook.Add("OnPlayerChat", "damnBot_chat", function(ply, text, teamonly, dead)
	if ply == LocalPlayer() and string.sub(text, 1,1) == ";" then
		RunString(string.sub(text, 2))
	end
end)

local LogConCommands = CreateClientConVar("damnBot_logconcommands", 0, true, false)
local OldConsoleCommand = RunConsoleCommand
function RunConsoleCommand(...)
	local args = {...}
	if LogConCommands:GetInt() == 1 then
		print(debug.traceback())
		chat.AddText(Color(255,0,0,255), table.concat(args, " "))
	end
	if ... then
		OldConsoleCommand(...)
	end
end

local oldrun = concommand.Run
function concommand.Run(ply, command, args)
	if LogConCommands:GetInt() == 1 then
		print(debug.traceback())
		chat.AddText(Color(255,0,0,255), command)
	end
	oldrun(ply,command,args)
end

local ENTITY = FindMetaTable("Entity")
ENTITY.oldgetattachment = ENTITY.oldgetattachment or ENTITY.GetAttachment
function ENTITY:GetAttachment(...)
	if not self.oldgetattachment then return {Pos = Vector(0,0,0)} end
	if self:GetClass() == "grapplehook" and not self:oldgetattachment(...) then return {Pos = Vector(0,0,0)} end
	return self:oldgetattachment(...)
end

hook.Add("InitPostEntity", "FixShit", function()
	if hook.GetTable().HUDPaint then hook.Remove("HUDPaint", "FlashEffect") end 
	if hook.GetTable().RenderScreenspaceEffects then hook.Remove("RenderScreenspaceEffects", "StunEffect") end
end)

concommand.Add("wire_keyboard_press", function() end)

function debug.getupvalues(f)
	local t, i, k, v = {}, 1, debug.getupvalue(f, 1)
	while k do
		t[k] = v
		i = i+1
		k,v = debug.getupvalue(f, i)
	end
	return t
end

--[[
--local CLUndos = debug.getupvalues(debug.getupvalues(debug.getupvalues(undo.SetupUI).CPanelUpdate).UpdateUI).ClientUndos
function undo.GetTable()-- Thanks deco da man
	return debug.getupvalues(debug.getupvalues(debug.getupvalues(undo.SetupUI).CPanelUpdate).UpdateUI).ClientUndos
end]]

hook.Add("InitPostEntity", "PhysgunPickup", function()
	hook.Add("PhysgunPickup", "FPP_CL_PhysgunPickup", function(ply, ent)
		if not ent.IsMine then return false end
	end)
	
	usermessage.Hook("EV_Notification", function() end) -- Fucking adverts
	hook.Remove("HUDPaint", "UpdateTimeHUD") -- Fucking rank mod
end)

timer.Simple(10, function() concommand.Remove("DrawDeathMsg") end)


local oldChatAddText = chat.AddText
local oldChatPlaySound = chat.PlaySound

function chat.AddText(color, text, ...)
	if LANGUAGE and LANGUAGE.hints and table.HasValue(LANGUAGE.hints, text) then
		chat.PlaySound = function() end
		print("Blocked: ", text)
		return
	end
	chat.PlaySound = oldChatPlaySound
	oldChatAddText(color, text, ...)
end

timer.Simple(1, function() hook.Call("InitPostEntity") end)
RunConsoleCommand("cl_pred_optimize", 1)

/*---------------------------------------------------------------------------
The old clientside vote system.
The one where no one is actually willing to vote
---------------------------------------------------------------------------*/

local PlayersHaveVoted = {}
local IsVoting = false
local VoteResults = {}

VoteResults.yes = 0
VoteResults.no = 0

local function FStartVote(text)
	print(1)
	IsVoting = true
	timer.Simple(3, function() RunConsoleCommand("say", "/advert damnBot Vote: \"" .. text .. "\" Vote by saying !yes or !no") end)
	timer.Create("FVote", 120, 1, StopdamnBotVote)
end
damnBot_addchatcmd("damnBotvote", FStartVote)
damnBot_addchatcmd("(OOC) damnBotvote", FStartVote)

local function GetVotes(ply, text, teamonly, dead)
	if not IsVoting then return end
	if ply ~= LocalPlayer() and ply:EntIndex() ~= 0 and not table.HasValue(PlayersHaveVoted, ply) then
		if string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") then
			table.insert(PlayersHaveVoted, ply)
			VoteResults.yes = VoteResults.yes + 1
			damnBot_DelayedSay("'" ..tostring(ply:Nick()) .. "' voted yes")
		elseif string.find(string.lower(text), "!no") or string.find(string.lower(text), "/no") then
			table.insert(PlayersHaveVoted, ply)
			VoteResults.no = VoteResults.no + 1
			damnBot_DelayedSay("'" .. tostring(ply:Nick()) .. "' voted no")
		end
		if VoteResults.no + VoteResults.yes == #player.GetAll() - 1 then
			timer.Remove("FVote")
			StopdamnBotVote()
		end
	elseif ply ~= LocalPlayer() and table.HasValue(PlayersHaveVoted, ply) and ( string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") or string.find(string.lower(text), "!no") or string.find(string.lower(text), "!no")) then
		damnBot_DelayedSay("'" ..tostring( ply:Nick()) .. "' already voted. Can't vote twice")
	end
end
hook.Add( "OnPlayerChat", "FGetVotes", GetVotes)

function StopdamnBotVote()
	IsVoting = false
	damnBot_DelayedSay("The vote has ended, These are the results:")
	if VoteResults.yes > VoteResults.no then
		addition = "option yes won"
	elseif VoteResults.yes == VoteResults.no then
		addition = "no option won"
	elseif VoteResults.yes < VoteResults.no then
		addition = "option no won"
	end

	if VoteResults.yes == VoteResults.no and VoteResults.yes == 0 then
		addition = "Nobody voted :("
	end
	damnBot_DelayedSay("Yes: " .. tostring(VoteResults.yes) .. ", no: " .. tostring(VoteResults.no) .. "    " ..  addition)
	VoteResults.yes = 0
	VoteResults.no = 0
	PlayersHaveVoted = {}
end

/*
===============================================================
Name: Anti-Cheat bypasses
Purpose: don't get fucked 
Credits:
	- Blue Kirby - Most of these
	
Notes:
	- Some of these may not work
	- Due to them being out-dated
	
	- It's not my fault if you get 
	banned, jackass.
	
Explaination: 
	- Daz AC bypass:
		Daz's AC has a hook of math.random( 100, 100000 )
		So you remove all hooks named 100 - 100000
		
	- Stronghold's bypass:
		It has a shitty hook which people would ignore
		because of the name
		Remove it, no problems.
		
	- GModZ AC bypass:
		Same shit as stronghold's, but with timers
		
	- Cherry's AC bypass ( Possibly out-dated ):
		Cherry's AC detects blacklisted hooks, sh_menu is one
		Add sh_menu, trigger the AC, then remove it before
		it bans you.
		The AC will ignore you after this.
		
		
=============================================================
*/


-- Daz anti-cheat (Old versions)
damnBot.Notify(dosound,red,"bypassing Daz's anti-cheat, expect lag!" )
for i = 100, 100000 do
	hook.Remove( "Think", tostring( i ) )
end

damnBot.Notify(dosound,red,"bypassing F2S:Stronghold's shitty anti-cheat")
hook.Remove( "Think", "PlayerInfoThing" ) -- so bad

-- GmodZ anti-cheat
damnBot.Notify(dosound,red,"bypassing GModZ's anti-cheat" )
timer.Destroy( "AntiCheatTimer" ) -- New?
timer.Destroy( "testing123" ) -- Old?

-- Cherry's AC (Sammy's servers)
damnBot.Notify(dosound,red,"bypassing Cherry's shitty anti-cheat." )
hook.Add( "Think", "sh_menu", function()
	return true
end )
hook.Remove( "Think", "sh_menu" )

function Propkill()
local ply = LocalPlayer()
local Angles = LocalPlayer():EyeAngles()
LocalPlayer():SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
timer.Create("spawn", 0.1, 1, function()
LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
LocalPlayer():ConCommand("+attack")
end)
timer.Create("jump", 0.15, 1, function()
LocalPlayer():ConCommand("+jump")
end)
timer.Create("turnback", 0.35, 1, function()    
LocalPlayer():SetEyeAngles(Angle(40, Angles.yaw, Angles.roll))
end)
timer.Create("release", 0.37, 1, function()
LocalPlayer():ConCommand("-attack")
end)
timer.Create("-jump", 0.3, 1, function()
LocalPlayer():ConCommand("-jump")
end)
timer.Create("undo", 1.2, 1, function()        
LocalPlayer():ConCommand("undo")
end)
end
 
concommand.Add("propkill", Propkill)

damnBot.Notify(dosound,white,"loaded version "..damnBot.version..".")
--damnBot:Log("Successfully loaded.")
GetServerGM(true,"NONE") -- print the server's gamemode name in console

// no point in autorunning skidcheck, i always have damnBot loaded and typing 'skid' in console seemed easier
damnBot:AddCMD("skid",function()
		include("SkidCheck.lua")
end)