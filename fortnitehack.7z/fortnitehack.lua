
--- CONVARS

local AimKey = AimKey or 26



-- Create a convar for the aimbot smoothing
CreateConVar("aimbot_smoothing", 0, FCVAR_ARCHIVE, "Aimbot smoothing factor")
-- Create a convar for the prediction speed
CreateConVar("aimbot_prediction_speed", 1, FCVAR_ARCHIVE, "Prediction speed")
-- Create a convar for the prediction distance
CreateConVar("aimbot_prediction_distance", 10, FCVAR_ARCHIVE, "Prediction distance")
-- Create a convar for enabling prediction adjustments
CreateConVar("aimbot_enable_prediction", 0, FCVAR_ARCHIVE, "Enable prediction adjustments")

CreateClientConVar( "espname", 0, true, false )
CreateClientConVar( "2desp", 0, true, false )
CreateClientConVar( "skeletonesp", 0, true, false )
CreateClientConVar( "fulllbright", 0, true, false )
CreateClientConVar( "noosky", 0, true, false )
CreateClientConVar( "crossbowpred", 0, true, false )
CreateClientConVar( "boltalert", 0, true, false )
CreateClientConVar( "boltbox", 0, true, false )
CreateClientConVar( "norecoil", 0, true, false )
CreateClientConVar( "espbox", 0, true, false )
CreateClientConVar( "aimbot", 0, true, false )
CreateClientConVar( "legitaimbot", 0, true, false )
CreateClientConVar( "BHop", 0, true, false )
CreateClientConVar( "BHop_AC", 0, true, false )
CreateClientConVar( "Autostrafer", 0, true, false )
CreateClientConVar( "triggerbot", 0, true, false )
CreateClientConVar( "propchams", 0, true, false )
CreateClientConVar( "chams", 0, true, false )
local renderdist = CreateClientConVar("RenderDistance", 50000, true, false)
CreateClientConVar( "epicfov1", 0, true, false )
CreateClientConVar( "epicfov2", 0, true, false )
CreateClientConVar("ThirdPerson1", 0, true, false)
CreateClientConVar("Chatspam", 0, true, false)
CreateClientConVar( "killsay", 0, true, false )
CreateClientConVar("TriggerBot_Ignore_Friends", 0, true, false)
CreateClientConVar("TriggerBot_Ignore_Team", 0, true, false)
CreateClientConVar( "nightmodee", 0, true, false )
CreateClientConVar( "antiantiaim", 0, true, false )
CreateClientConVar( "hittsound", 0, true, false )
local espcolor_style = CreateClientConVar("ESPColor_Style", 0, true, false)
local espcolor_r = CreateClientConVar("ESPColor_R", 0, true, false)
local espcolor_g = CreateClientConVar("ESPColor_G", 0, true, false)
local espcolor_b = CreateClientConVar("ESPColor_B", 0, true, false)
local espcolor_a = CreateClientConVar("ESPColor_A", 0, true, false)
CreateClientConVar("toggle_key_generation", "1", true, false, "Toggle Windows key generation in chat (0 = Off, 1 = On)")

--- LOCALS

 
local boxColor = Color(255, 0, 0, 255) 
local hooks = {}
local function AddHook(event, name, func)
        hooks[name] = event
        hook.Add(event, name, func)
    end
local ply = LocalPlayer()
local function RandomString() return tostring(math.random(-9999999999, 9999999999)) end
local cObs, cStaff = RandomString(), RandomString()
local function UtilityCheck(v)
    if v != ply and v:Alive() and v:IsValid() then
        return true
    else
        return false
    end
end
local me = LocalPlayer()
OtherPlayers = OtherPlayers or {}
NoShootGuys = NoShootGuys or {}
EntsToShow = EntsToShow or {}
OtherEnts = OtherEnts or {}
OtherPlayers = OtherPlayers or {}
NoShootGuys = NoShootGuys or {}
EntsToShow = EntsToShow or {}
OtherEnts = OtherEnts or {}
local function PermissionCheck(v)
    if v:IsAdmin()  or string.find(v:GetUserGroup(), "mod") or string.find(v:GetUserGroup(), "admin") or string.find(v:GetUserGroup(), "staff") then
        return true
    else
        return false
    end
end
function GhostCheck(v)
        if not IsValid(v) or v:GetNoDraw() or v:GetRenderMode() == RENDERMODE_NONE then
                return true
        else
                return false
        end
end


--- MAIN FRAME

function epicframe()
        local frame1 = vgui.Create("DFrame")
 
        frame1:SetPos(650,350)
        frame1:SetSize(510,400)
        frame1:SetTitle("")
        frame1:MakePopup()
        frame1:SetVisible( true )
        frame1:SetDraggable( true )
        frame1:ShowCloseButton( true )
        frame1:MakePopup()


       function frame1.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("FortniteHack For Gmod", "ChatFont", 170, 4, color_white)
        end

    
     

        local epicimage = vgui.Create( "HTML" ) 
        epicimage:SetParent( frame1 )
        epicimage:SetPos( 0, 100 )
        epicimage:SetSize( 530, 300 )
        epicimage:SizeToContents()
        epicimage:OpenURL( "https://scontent-ord5-1.xx.fbcdn.net/v/t1.6435-9/42668547_564784630663675_2090067077783093248_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=5f2048&_nc_ohc=n82U3ca-fboAb6A_mVm&_nc_ht=scontent-ord5-1.xx&oh=00_AfC8g3JrDF2vPe3p_7h2Euo9iMSE4z5nDsLaJnhdaSLnCw&oe=664397F3" ) 
        

  local epicButton1 = vgui.Create( "DButton", frame1 )
  epicButton1:SetParent( frame1 ) 
  epicButton1:SetText( "Aim" )
  epicButton1:SetPos( 0, 50 )
  epicButton1:SetSize( 110, 50 )
  epicButton1.DoClick = function ()
    RunConsoleCommand( "AimMenu" ) 
  end


  local epicButton1 = vgui.Create( "DButton", frame1 )
  epicButton1:SetParent( frame1 ) 
  epicButton1:SetText( "Visuals" )
  epicButton1:SetPos( 100, 50 )
  epicButton1:SetSize( 110, 50 )
  epicButton1.DoClick = function ()
    RunConsoleCommand( "VisMenu" ) 
  end


  local epicButton1 = vgui.Create( "DButton", frame1 )
  epicButton1:SetParent( frame1 ) 
  epicButton1:SetText( "Movement" )
  epicButton1:SetPos( 200, 50 )
  epicButton1:SetSize( 110, 50 )
  epicButton1.DoClick = function ()
    RunConsoleCommand( "MovMenu" ) 
  end


  local epicButton1 = vgui.Create( "DButton", frame1 )
  epicButton1:SetParent( frame1 ) 
  epicButton1:SetText( "HvH" )
  epicButton1:SetPos( 300, 50 )
  epicButton1:SetSize( 110, 50 )
  epicButton1.DoClick = function ()
    RunConsoleCommand( "HvhMenu" ) 
  end



  local epicButton1 = vgui.Create( "DButton", frame1 )
  epicButton1:SetParent( frame1 ) 
  epicButton1:SetText( "Misc" )
  epicButton1:SetPos( 400, 50 )
  epicButton1:SetSize( 110, 50 )
  epicButton1.DoClick = function ()
    RunConsoleCommand( "MiscMenu" ) 
  end
end

local function MenuOpenCommand()
    LocalPlayer():ConCommand("menuopen")
end

hook.Add("PlayerButtonDown", "OpenMenuOnKeyPress", function(ply, key)
    if key == KEY_INSERT then
        MenuOpenCommand()
    end
end)

concommand.Add("menuopen", epicframe)

--- aim 

function epiccframe()
        local frame2 = vgui.Create("DFrame")
 
        frame2:SetPos(300,350)
        frame2:SetSize(400,300)
        frame2:SetTitle("")
        frame2:MakePopup()
        frame2:SetVisible( true )
        frame2:SetDraggable( true )
        frame2:ShowCloseButton( true )
        frame2:MakePopup()


       function frame2.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("Aim", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
        end

  local smoothingSlider = vgui.Create("DNumSlider", frame2)
    smoothingSlider:SetPos(25, 20)
    smoothingSlider:SetSize(300, 50)
    smoothingSlider:SetText("Smoothing Factor")
    smoothingSlider:SetMin(0)
    smoothingSlider:SetMax(1)
    smoothingSlider:SetDecimals(2)
    smoothingSlider:SetValue(GetConVar("aimbot_smoothing"):GetFloat())
    smoothingSlider.OnValueChanged = function(_, value)
        RunConsoleCommand("aimbot_smoothing", value)
    end

    local predictionSpeedSlider = vgui.Create("DNumSlider", frame2)
    predictionSpeedSlider:SetPos(25, 70)
    predictionSpeedSlider:SetSize(300, 50)
    predictionSpeedSlider:SetText("Prediction Speed")
    predictionSpeedSlider:SetMin(0)
    predictionSpeedSlider:SetMax(10) 
    predictionSpeedSlider:SetDecimals(2)
    predictionSpeedSlider:SetValue(GetConVar("aimbot_prediction_speed"):GetFloat())
    predictionSpeedSlider.OnValueChanged = function(_, value)
        RunConsoleCommand("aimbot_prediction_speed", value)
    end

    local predictionDistanceSlider = vgui.Create("DNumSlider", frame2)
    predictionDistanceSlider:SetPos(25, 120)
    predictionDistanceSlider:SetSize(300, 50)
    predictionDistanceSlider:SetText("Prediction Distance")
    predictionDistanceSlider:SetMin(0)
    predictionDistanceSlider:SetMax(100) 
    predictionDistanceSlider:SetDecimals(2)
    predictionDistanceSlider:SetValue(GetConVar("aimbot_prediction_distance"):GetFloat())
    predictionDistanceSlider.OnValueChanged = function(_, value)
        RunConsoleCommand("aimbot_prediction_distance", value)
    end

    local enablePredictionCheckbox = vgui.Create("DCheckBoxLabel", frame2)
    enablePredictionCheckbox:SetPos(25, 170)
    enablePredictionCheckbox:SetText("Enable Prediction")
    enablePredictionCheckbox:SetValue(GetConVar("aimbot_enable_prediction"):GetBool())
    enablePredictionCheckbox.OnChange = function(_, value)
        RunConsoleCommand("aimbot_enable_prediction", value and 1 or 0)
    end 
    
    
  local buttonaim7 = vgui.Create( "DCheckBoxLabel", frame2 )
  buttonaim7:SetPos( 180,270 )
  buttonaim7:SetText( "BodytoHead Assist" )
  buttonaim7:SetConVar( "legitaimbot" )  
  buttonaim7:SizeToContents()  

  local buttonaim8 = vgui.Create( "DCheckBoxLabel", frame2 )
  buttonaim8:SetPos( 20,230 )
  buttonaim8:SetText( "Triggerbot" )
  buttonaim8:SetConVar( "triggerbot" )  
  buttonaim8:SizeToContents()

  local buttonaim9 = vgui.Create( "DCheckBoxLabel", frame2 )
  buttonaim9:SetPos( 20,250 )
  buttonaim9:SetText( "TB Ignore Friend" )
  buttonaim9:SetConVar( "TriggerBot_Ignore_Friends" )  
  buttonaim9:SizeToContents()  

  local buttonaim10 = vgui.Create( "DCheckBoxLabel", frame2 )
  buttonaim10:SetPos( 20,270)
  buttonaim10:SetText( "TB Ignore Team" )
  buttonaim10:SetConVar( "TriggerBot_Ignore_Team" )  
  buttonaim10:SizeToContents()

  local buttonaim11 = vgui.Create( "DCheckBoxLabel", frame2 )
  buttonaim11:SetPos( 180,250 )
  buttonaim11:SetText( "No Recoil" )
  buttonaim11:SetConVar( "norecoil" )  
  buttonaim11:SizeToContents() 
  
  local binder = vgui.Create( "DBinder", frame2 )
	binder:SetSize( 75, 20 )
	binder:SetPos( 150, 169 )
	binder:SetText("Aimbot Key")
	function binder:OnChange( num )
		AimKey = num
	end 
  
  

  
end
concommand.Add("AimMenu", epiccframe)

--- visuals

function epicccframe()
        local frame3 = vgui.Create("DFrame")
 
        frame3:SetPos(300,350)
        frame3:SetSize(400,300)
        frame3:SetTitle("")
        frame3:MakePopup()
        frame3:SetVisible( true )
        frame3:SetDraggable( true )
        frame3:ShowCloseButton( true )
        frame3:MakePopup()


       function frame3.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("Visuals", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
        end

  local buttonvisual1 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual1:SetPos( 20,40 )
  buttonvisual1:SetText( "ESP Name" )
  buttonvisual1:SetConVar( "espname" ) 
  buttonvisual1:SizeToContents() 

  local buttonvisual2 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual2:SetPos( 20,60 )
  buttonvisual2:SetText( "ESP 3D Box" )
  buttonvisual2:SetConVar( "espbox" )  
  buttonvisual2:SizeToContents()
  
  local buttonvisual23 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual23:SetPos( 20,80 )
  buttonvisual23:SetText( "ESP 2D Box" )
  buttonvisual23:SetConVar( "2desp" )  
  buttonvisual23:SizeToContents()

  local buttonvisual22 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual22:SetPos( 20,100 )
  buttonvisual22:SetText( "Skeleton ESP" )
  buttonvisual22:SetConVar( "skeletonesp" )  
  buttonvisual22:SizeToContents()    

  local buttonvisual3 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual3:SetPos( 20,120 )
  buttonvisual3:SetText( "Chams" )
  buttonvisual3:SetConVar( "chams" )  
  buttonvisual3:SizeToContents()  

  local buttonvisual4 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual4:SetPos( 20,140 )
  buttonvisual4:SetText( "Prop Chams" )
  buttonvisual4:SetConVar( "propchams" )  
  buttonvisual4:SizeToContents()  

  local buttonvisual5 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual5:SetPos( 20,160 )
  buttonvisual5:SetText( "Thirdperson" )
  buttonvisual5:SetConVar( "ThirdPerson1" )  
  buttonvisual5:SizeToContents()  

  local buttonvisual6 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual6:SetPos( 20,180 )
  buttonvisual6:SetText( "Night Mode" )
  buttonvisual6:SetConVar( "nightmodee" )  
  buttonvisual6:SizeToContents()

  local buttonvisual7 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual7:SetPos( 180,40 )
  buttonvisual7:SetText( "Fov" )
  buttonvisual7:SetConVar( "epicfov1" )  
  buttonvisual7:SizeToContents()  

  local buttonvisual8 = vgui.Create("DNumSlider", frame3)
  buttonvisual8:SetMinMax(20, 179)
  buttonvisual8.TextArea:SetTextColor(Color(200, 200, 200))
  buttonvisual8:SetPos(180, 60)
  buttonvisual8:SetSize(200, 20)
  buttonvisual8:SetText("Field of View")
  buttonvisual8:SetConVar("epicfov2")
  buttonvisual8:SetDecimals(0) 

  local buttonvisual9 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual9:SetPos( 20,200 )
  buttonvisual9:SetText( "No Sky" )
  buttonvisual9:SetConVar( "noosky" )  
  buttonvisual9:SizeToContents()

  local buttonvisual10 = vgui.Create( "DCheckBoxLabel", frame3 )
  buttonvisual10:SetPos( 20,220 )
  buttonvisual10:SetText( "Full Bright" )
  buttonvisual10:SetConVar( "fulllbright" )  
  buttonvisual10:SizeToContents() 

        local DComboBox12 = vgui.Create( "DComboBox", frame3 )
	DComboBox12:SetPos( 195, 250 )
	DComboBox12:SetSize( 100, 20 )
	DComboBox12:SetValue( "Color Style" )
	DComboBox12:AddChoice( "Custom Colors" )
	DComboBox12:AddChoice( "Group Colors" )
	DComboBox12:AddChoice( "Rainbow Colors" )
	DComboBox12.OnSelect = function( self, index, value )
		ESPColorStyle = ( index )
	end

  local ESPColorRed = vgui.Create( "DNumSlider", frame3 )
	ESPColorRed:SetPos( 195, 150 )
	ESPColorRed:SetSize( 190, 25 )
	ESPColorRed:SetText( "Red" )
	ESPColorRed:SetMin( 0 )
	ESPColorRed:SetMax( 255 )
	ESPColorRed:SetDecimals( 0 )
	ESPColorRed:SetConVar( "ESPColor_R" )
	local ESPColorGreen = vgui.Create( "DNumSlider", frame3 )
	ESPColorGreen:SetPos( 195, 170 )
	ESPColorGreen:SetSize( 190, 25 )
	ESPColorGreen:SetText( "Green" )
	ESPColorGreen:SetMin( 0 )
	ESPColorGreen:SetMax( 255 )
	ESPColorGreen:SetDecimals( 0 )
	ESPColorGreen:SetConVar( "ESPColor_G" )
	local ESPColorBlue = vgui.Create( "DNumSlider", frame3 )
	ESPColorBlue:SetPos( 195, 190 )
	ESPColorBlue:SetSize( 190, 25 )
	ESPColorBlue:SetText( "Blue" )
	ESPColorBlue:SetMin( 0 )
	ESPColorBlue:SetMax( 255 )
	ESPColorBlue:SetDecimals( 0 )
	ESPColorBlue:SetConVar( "ESPColor_B" )
	local ESPColorAlpha = vgui.Create( "DNumSlider", frame3 )
	ESPColorAlpha:SetPos( 195, 210 )
	ESPColorAlpha:SetSize( 190, 25 )
	ESPColorAlpha:SetText( "Opacity" )
	ESPColorAlpha:SetMin( 50 )
	ESPColorAlpha:SetMax( 255 )
	ESPColorAlpha:SetDecimals( 0 )
	ESPColorAlpha:SetValue( 255 )
	ESPColorAlpha:SetConVar( "ESPColor_A" )     


end
concommand.Add("VisMenu", epicccframe)

--- movement

function epiccccframe()
        local frame4 = vgui.Create("DFrame")
 
        frame4:SetPos(300,350)
        frame4:SetSize(400,300)
        frame4:SetTitle("")
        frame4:MakePopup()
        frame4:SetVisible( true )
        frame4:SetDraggable( true )
        frame4:ShowCloseButton( true )
        frame4:MakePopup()


       function frame4.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("Movement", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
        end

  local buttonmov2 = vgui.Create( "DCheckBoxLabel", frame4 )
  buttonmov2:SetPos( 20,40 )
  buttonmov2:SetText( "Bhop" )
  buttonmov2:SetConVar( "BHop" ) 
  buttonmov2:SizeToContents() 

  local buttonmov1 = vgui.Create( "DCheckBoxLabel", frame4 )
  buttonmov1:SetPos( 20,60 )
  buttonmov1:SetText( "Bhop AC" )
  buttonmov1:SetConVar( "BHop_AC" )  
  buttonmov1:SizeToContents()  
  
  local buttonmov3 = vgui.Create( "DCheckBoxLabel", frame4 )
  buttonmov3:SetPos( 20,80 )
  buttonmov3:SetText( "Auto Strafer" )
  buttonmov3:SetConVar( "Autostrafer" )  
  buttonmov3:SizeToContents()  

end
concommand.Add("MovMenu", epiccccframe)

--- hvh

function epicccccframe()
        local frame5 = vgui.Create("DFrame")
 
        frame5:SetPos(300,350)
        frame5:SetSize(400,300)
        frame5:SetTitle("")
        frame5:MakePopup()
        frame5:SetVisible( true )
        frame5:SetDraggable( true )
        frame5:ShowCloseButton( true )
        frame5:MakePopup()


       function frame5.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("HvH", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
        end

  local buttonhvh1 = vgui.Create( "DCheckBoxLabel", frame5 )
  buttonhvh1:SetPos( 20,40 )
  buttonhvh1:SetText( "Anti Anti Aim" )
  buttonhvh1:SetConVar( "antiantiaim" ) 
  buttonhvh1:SizeToContents() 

 

end
concommand.Add("HvhMenu", epicccccframe)

--- misc

function epiccccccframe()
        local frame6 = vgui.Create("DFrame")
 
        frame6:SetPos(300,350)
        frame6:SetSize(400,300)
        frame6:SetTitle("")
        frame6:MakePopup()
        frame6:SetVisible( true )
        frame6:SetDraggable( true )
        frame6:ShowCloseButton( true )
        frame6:MakePopup()


       function frame6.Paint(self)
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60))
                draw.RoundedBox(0, 0, 0, self:GetWide(), 22, Color(100, 100, 255))
                draw.SimpleText("Misc", "ChatFont", self:GetWide()/2 - 30, 4, color_white)
        end

  local buttonmisc1 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc1:SetPos( 20,40 )
  buttonmisc1:SetText( "Chat Spam" )
  buttonmisc1:SetConVar( "Chatspam" ) 
  buttonmisc1:SizeToContents() 

  local buttonmisc2 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc2:SetPos( 20,60 )
  buttonmisc2:SetText( "Kill Say" )
  buttonmisc2:SetConVar( "killsay" ) 
  buttonmisc2:SizeToContents()

  local buttonmisc3 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc3:SetPos( 20,80 )
  buttonmisc3:SetText( "Hitsound" )
  buttonmisc3:SetConVar( "hittsound" ) 
  buttonmisc3:SizeToContents()  

  local buttonmisc4 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc4:SetPos( 20,100 )
  buttonmisc4:SetText( "Crossbow Pred" )
  buttonmisc4:SetConVar( "crossbowpred" ) 
  buttonmisc4:SizeToContents() 

  local buttonmisc5 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc5:SetPos( 20,120 )
  buttonmisc5:SetText( "Crossbow Bolt Box" )
  buttonmisc5:SetConVar( "boltbox" ) 
  buttonmisc5:SizeToContents() 

  local buttonmisc6 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc6:SetPos( 20,140 )
  buttonmisc6:SetText( "Crossbow Bolt Alert" )
  buttonmisc6:SetConVar( "boltalert" ) 
  buttonmisc6:SizeToContents() 
  
  local buttonmisc7 = vgui.Create( "DCheckBoxLabel", frame6 )
  buttonmisc7:SetPos( 20,160 )
  buttonmisc7:SetText( "Windows Key Generator" )
  buttonmisc7:SetConVar( "toggle_key_generation" ) 
  buttonmisc7:SizeToContents() 
  
  
  


  local colorSlider = vgui.Create("DColorMixer", frame6)
    colorSlider:SetSize( 150, 150 )
    colorSlider:SetPos(220, 50)
    colorSlider:SetPalette(true)
    colorSlider:SetAlphaBar(true)
    colorSlider:SetWangs(true)
    colorSlider:SetColor(boxColor)

    local applybutton = vgui.Create("DButton", frame6)
    applybutton:SetParent( frame6 ) 
    applybutton:SetSize( 100, 20 )
    applybutton:SetPos(240, 200)
    applybutton:SetText("Apply Color")
    applybutton.DoClick = function()
        boxColor = colorSlider:GetColor()
    end

 

end
concommand.Add("MiscMenu", epiccccccframe)



-- SCRIPTS

-- AIMS

-- aimbot
-- Track the current direction of the prediction slider
local predictionDirection = 1
-- Track the current value of the prediction slider
local currentPredictionValue = 1

hook.Add("Think", "Aimbot", function()
    if input.IsButtonDown(AimKey) and ply:IsTyping() == false then
        local aimPos = LocalPlayer():GetShootPos()
        local aimDir = LocalPlayer():GetAimVector()
        local closestPlayer = nil
        local closestDot = -1

        for _, ply in ipairs(player.GetAll()) do
            if ply != LocalPlayer() and ply:Alive() then
                local plyPos = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
                local dirToPly = (plyPos - aimPos):GetNormalized()
                local dot = aimDir:Dot(dirToPly)

                if dot > closestDot then
                    closestDot = dot
                    closestPlayer = ply
                end
            end
        end

        if IsValid(closestPlayer) then
            local targetPos = closestPlayer:GetBonePosition(closestPlayer:LookupBone("ValveBiped.Bip01_Head1"))

            -- Prediction only if player is moving faster than walking speed and prediction is enabled
            local velocity = closestPlayer:GetVelocity()
            local speed = velocity:Length()
            local predictionSpeed = GetConVar("aimbot_prediction_speed"):GetFloat()
            local predictionDistance = GetConVar("aimbot_prediction_distance"):GetFloat()
            local enablePrediction = GetConVar("aimbot_enable_prediction"):GetBool()
            local predictedPos

            if enablePrediction and speed > 100 then -- Walking speed threshold
                predictedPos = targetPos + velocity * currentPredictionValue * predictionSpeed * predictionDistance
            else
                predictedPos = targetPos
            end

            local aimAng = (predictedPos - aimPos):Angle()

            -- Smooth the aim angle
            local smoothing = GetConVar("aimbot_smoothing"):GetFloat()
            local currentAng = LocalPlayer():EyeAngles()
            local deltaAng = aimAng - currentAng
            deltaAng:Normalize()
            LocalPlayer():SetEyeAngles(currentAng + deltaAng * smoothing)
        end
    end

    -- Oscillate the prediction value between 0 and 1 if prediction is enabled
    local enablePrediction = GetConVar("aimbot_enable_prediction"):GetBool()
    if enablePrediction then
        currentPredictionValue = currentPredictionValue + predictionDirection * FrameTime() * GetConVar("aimbot_prediction_speed"):GetFloat()
        if currentPredictionValue >= 1 then
            currentPredictionValue = 1
            predictionDirection = -1
        elseif currentPredictionValue <= 0 then
            currentPredictionValue = 0
            predictionDirection = 1
        end
    end
end)


-- Add a command to open the settings menu
concommand.Add("open_aimbot_settings", OpenSmoothingMenu)


--triggerbot

local shooting = false
hook.Add("Think", "Triggerbot", function()
    local ply = LocalPlayer()
    local EntTrace = ply:GetEyeTrace()
    if not EntTrace.Hit or not IsValid(EntTrace.Entity) then return end
    local target = EntTrace.Entity
    if GetConVarNumber("triggerBot") == 1 and target:IsPlayer() then
        if GetConVarNumber("TriggerBot_Ignore_Friends") == 1 and target:GetFriendStatus() == "none" or GetConVarNumber("TriggerBot_Ignore_Friends") == 0 then
            if GetConVarNumber("TriggerBot_Ignore_Team") == 1 and target:Team() ~= ply:Team() or GetConVarNumber("TriggerBot_Ignore_Team") == 0 then
                if not shooting and target:IsPlayer() then
                                        timer.Simple(0.01, function()
                    RunConsoleCommand("+attack")
                    shooting = true
                end)
                        end
                timer.Simple(0.075, function()
                    RunConsoleCommand("-attack")
                    shooting = false
                end)
            end
        end
    elseif shooting and GetConVarNumber("triggerBot") == 1 then
        RunConsoleCommand("-attack")
        shooting = false
    end
end)

--legitaim

function legitaimbot() -- Starting the function
     if ConVarExists( "legitaimbot" ) and GetConVar("legitaimbot"):GetInt() == 1 then
        local ply = LocalPlayer() -- Getting ourselves
        local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
        local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
        if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
                local target = traceRes.Entity -- It's obviously an entity.
                if target:IsPlayer() then -- But it must be a player.
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
                        local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
                        ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
                end
        end
      end
end
hook.Add("Think","legitaimbot",legitaimbot) -- The hook will spam "aimbot" until it finds a target..


--- VISUALS

-- fov

local function fov()
  if GetConVarNumber("epicfov1") == 1 then
    local ta = {}
    ta.fov = GetConVarNumber("epicfov2")
    return ta
  end
end
hook.Add("CalcView", "fov", fov)

-- esp name

hook.Add( "HUDPaint", "esppname", function()
    if ConVarExists( "espname" ) and GetConVar("espname"):GetInt() == 1 then
        
        for k,v in pairs ( player.GetAll() ) do
 
                local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
                local Name = ""
 
                if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
                draw.DrawText( Name, "ChatFont", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
        end
     end
end )

--2s esp box

local function CornerCords( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local findcorners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( findcorners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
return minX, minY, maxX, maxY end
hook.Add( "HUDPaint", "2DBoxESP", function()
	for k, v in pairs ( player.GetAll() ) do
		local function DrawHABar(ent, x, y, w, h)
			local health = ent:Health()
			local armor = ent:Armor()
			local maxHealth = ent:GetMaxHealth()
			local maxArmor = ent:GetMaxArmor()
			local healthRatio = health / maxHealth
			local armorRatio = armor / maxArmor
			local percent = health / 100
			local apercent = armor / 100
			if ESPColorStyle == 1 then
				surface.SetDrawColor(espcolor_r:GetInt(), espcolor_g:GetInt(), espcolor_b:GetInt(), espcolor_a:GetInt())
			elseif ESPColorStyle == 2 then
				if team.GetColor(v:Team()) == nil then
					surface.SetDrawColor(espcolor_r:GetInt(), espcolor_g:GetInt(), espcolor_b:GetInt(), espcolor_a:GetInt())
				else
					surface.SetDrawColor(team.GetColor(v:Team()))
				end
			else
				local time = CurTime()
				local speed = 1
				local offset = 0
				local lightness = 255
				local base_value = time * speed + offset
				local r = ( 0.5 * (math.sin(base_value - 2)	+ 1) ) * lightness
				local g = ( 0.5 * (math.sin(base_value + 2)	+ 1) ) * lightness
				local b = ( 0.5 * (math.sin(base_value)		+ 1) ) * lightness
				surface.SetDrawColor(r, g, b)
			end
			surface.DrawOutlinedRect(x, y, w, h)
			surface.DrawOutlinedRect(x, y+6, w, h)
			if percent >= 0.5 then
				surface.SetDrawColor(0, 255 * percent, 0)
			else
				surface.SetDrawColor(255 * percent, 0, 0)
			end
			if healthRatio >= 1 then
				surface.DrawRect(x+1, y+1, (w-2)*1, h-2)
			else 
				surface.DrawRect(x+1, y+1, (w-2)*healthRatio, h-2)
			end
			surface.SetDrawColor(0, 75, 255 * apercent)
			if armorRatio >= 1 then
				surface.DrawRect(x+1, y+h+3, (w-2)*1, h-2)
			else
				surface.DrawRect(x+1, y+h+3, (w-2)*armorRatio, h-2)
			end
		end
		local plydistance = math.Round((ply:GetPos():Distance( v:GetPos())))
		if plydistance < renderdist:GetInt() then
			if GetConVarNumber("2desp") == 1 then
				if UtilityCheck(v) == true then
					if ESPColorStyle == 1 then
						surface.SetDrawColor(espcolor_r:GetInt(), espcolor_g:GetInt(), espcolor_b:GetInt(), espcolor_a:GetInt())
					elseif ESPColorStyle == 2 then
						surface.SetDrawColor(team.GetColor(v:Team()))
					else
						local time = CurTime()
						local speed = 1
						local offset = 0
						local lightness = 255
						local base_value = time * speed + offset
						local r = ( 0.5 * (math.sin(base_value - 2)	+ 1) ) * lightness
						local g = ( 0.5 * (math.sin(base_value + 2)	+ 1) ) * lightness
						local b = ( 0.5 * (math.sin(base_value)		+ 1) ) * lightness
						surface.SetDrawColor(r, g, b)
					end
					local x1,y1,x2,y2 = CornerCords(v)
					surface.DrawLine( x1, y1, math.min( x1 + 500, x2 ), y1 )
					surface.DrawLine( x1, y1, x1, math.min( y1 + 500, y2 ) )
					surface.DrawLine( x2, y1, math.max( x2 - 500, x1 ), y1 )
					surface.DrawLine( x2, y1, x2, math.min( y1 + 500, y2 ) )
					surface.DrawLine( x1, y2, math.min( x1 + 500, x2 ), y2 )
					surface.DrawLine( x1, y2, x1, math.max( y2 - 500, y1 ) )
					surface.DrawLine( x2, y2, math.max( x2 - 500, x1 ), y2 )
					surface.DrawLine( x2, y2, x2, math.max( y2 - 500, y1 ) )
					local barHeight = 5
                    local barY = y2 + barHeight + 2
                    DrawHABar(v, x1+.7, barY, x2-x1, barHeight)
				end
			end
		end
	end
end)

--esp box

function LoadESP()

        if GetConVar("espbox"):GetInt() == 1 then

                for k, v in pairs( ents.GetAll() ) do

                        if v:IsValid() && v != LocalPlayer() && (v:IsPlayer() || v:IsNPC()) then

                                local ent = v
                                local MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8 = getPosition( ent )
                              
                                local healthColor = Color((1-(ent:Health()/ent:GetMaxHealth()))*255, (ent:Health()/ent:GetMaxHealth())*255, 0)
                                local ESPPos = MinY

                                surface.SetDrawColor(healthColor)

                                if GetConVar("espbox"):GetInt() == 1 then

                                        surface.DrawLine( V4.x, V4.y, V6.x, V6.y )
                                        surface.DrawLine( V1.x, V1.y, V8.x, V8.y )
                                        surface.DrawLine( V6.x, V6.y, V8.x, V8.y )
                                        surface.DrawLine( V4.x, V4.y, V1.x, V1.y )

                                        surface.DrawLine( V3.x, V3.y, V5.x, V5.y )
                                        surface.DrawLine( V2.x, V2.y, V7.x, V7.y )
                                        surface.DrawLine( V3.x, V3.y, V2.x, V2.y )
                                        surface.DrawLine( V5.x, V5.y, V7.x, V7.y )

                                        surface.DrawLine( V3.x, V3.y, V4.x, V4.y )
                                        surface.DrawLine( V2.x, V2.y, V1.x, V1.y )
                                        surface.DrawLine( V7.x, V7.y, V8.x, V8.y )
                                        surface.DrawLine( V5.x, V5.y, V6.x, V6.y )

                                else

                                        surface.DrawLine( MaxX, MaxY, MinX, MaxY )
                                        surface.DrawLine( MaxX, MaxY, MaxX, MinY )
                                        surface.DrawLine( MinX, MinY, MaxX, MinY )
                                        surface.DrawLine( MinX, MinY, MinX, MaxY )

                                end

                                
                                

                        end

                end

        end

end


function getPosition(ent)

        if ent:IsValid() then
                local Points = {
                        Vector( ent:OBBMaxs().x, ent:OBBMaxs().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMaxs().y, ent:OBBMins().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMins().y, ent:OBBMins().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMins().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMins().x, ent:OBBMins().y, ent:OBBMins().z ),
                        Vector( ent:OBBMins().x, ent:OBBMins().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMins().x, ent:OBBMaxs().y, ent:OBBMins().z ),
                        Vector( ent:OBBMins().x, ent:OBBMaxs().y, ent:OBBMaxs().z )
                }
                local MaxX, MaxY, MinX, MinY
                local V1, V2, V3, V4, V5, V6, V7, V8
                for k, v in pairs( Points ) do
                        local ScreenPos = ent:LocalToWorld( v ):ToScreen()
                        if MaxX != nil then
                                MaxX, MaxY, MinX, MinY = math.max( MaxX, ScreenPos.x ), math.max( MaxY, ScreenPos.y), math.min( MinX, ScreenPos.x ), math.min( MinY, ScreenPos.y)
                        else
                                MaxX, MaxY, MinX, MinY = ScreenPos.x, ScreenPos.y, ScreenPos.x, ScreenPos.y
                        end

                        if V1 == nil then
                                V1 = ScreenPos
                        elseif V2 == nil then
                                V2 = ScreenPos
                        elseif V3 == nil then
                                V3 = ScreenPos
                        elseif V4 == nil then
                                V4 = ScreenPos
                        elseif V5 == nil then
                                V5 = ScreenPos
                        elseif V6 == nil then
                                V6 = ScreenPos
                        elseif V7 == nil then
                                V7 = ScreenPos
                        elseif V8 == nil then
                                V8 = ScreenPos
                        end
                end
                return MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8
        end

end
hook.Add("HUDPaint", "espboxx", LoadESP)



-- propchams

local function cham()
 
 
    for k,v in pairs(ents.FindByClass("prop_physics")) do
        if GetConVarNumber("propchams") == 1 then
            xray = 1
            cam.Start3D()
            local distance = v:GetPos():Distance(ply:GetPos())
                cam.IgnoreZ(true)
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
                v:SetColor(Color(0,255,255,255))
                // render.MaterialOverride(Material("phoenix_storms/fender_white"))
                v:DrawModel()  
                render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins() + Vector(5, 5, 5), v:OBBMaxs() - Vector(5, 5, 5), Color(0,255,255,255))
                v:AddEffects(256)
            cam.End3D()
            else
                xray = 0
                v:SetColor(Color(255,255,255,255))
        end
    end
end
hook.Add("RenderScreenspaceEffects", "propchams", cham)
 
hook.Add("PreDrawPlayerHands", "asas", function(a)
 
    a:SetModel("models/weapons/c_arms_hev.mdl")
 
end)


-- chamz


local function chams()
        for k, v in pairs ( player.GetAll() ) do
                if GetConVarNumber("Chams") == 1 then
                        if UtilityCheck(v) == true then
                                local plydistance = math.Round((ply:GetPos():Distance( v:GetPos())))
                                if plydistance < renderdist:GetInt() then
                                        cam.Start3D(EyePos(), EyeAngles())
                                        cam.IgnoreZ( true )
                                        render.SuppressEngineLighting( true )
                                        v:DrawModel()
                                        cam.IgnoreZ( false )
                                        render.SuppressEngineLighting( false )
                                        cam.End3D()
                                end
                        end
                end
        end
end
hook.Add("HUDPaint", "PlayerChams",chams)

--- skeleton esp

hook.Add('HUDPaint','SkeletonEsp', function()
	if GetConVarNumber("skeletonesp") == 1 then
		for k, v in pairs(player.GetAll()) do
			local plydistance = math.Round((ply:GetPos():Distance( v:GetPos())))
			if plydistance < renderdist:GetInt() then
				if v != LocalPlayer() and UtilityCheck(v) == true and v:LookupBone('ValveBiped.Bip01_Head1') != nil and v:LookupBone('ValveBiped.Bip01_R_UpperArm') != nil then
					if ESPColorStyle == 1 then
						surface.SetDrawColor(espcolor_r:GetInt(), espcolor_g:GetInt(), espcolor_b:GetInt(), espcolor_a:GetInt())
					elseif ESPColorStyle == 2 then
						local color = (team.GetColor(v:Team()))
						surface.SetDrawColor(color.r, color.g, color.b, espcolor_a:GetInt())
					else
						local time = CurTime()
						local speed = 1
						local offset = 0
						local lightness = 255
						local base_value = time * speed + offset
						local r = ( 0.5 * (math.sin(base_value - 2)	+ 1) ) * lightness
						local g = ( 0.5 * (math.sin(base_value + 2)	+ 1) ) * lightness
						local b = ( 0.5 * (math.sin(base_value)		+ 1) ) * lightness
						surface.SetDrawColor(r, g, b, espcolor_a:GetInt())
					end
					rshoulder = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_R_UpperArm') ):ToScreen()
					lshoulder = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_L_UpperArm') ):ToScreen()
					relbow = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_R_Forearm') ):ToScreen()
					lelbow = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_L_Forearm') ):ToScreen()
					lwrist = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_L_Hand') ):ToScreen()
					rwrist = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_R_Hand') ):ToScreen()
					head = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen()
					pelvis = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Pelvis') ):ToScreen()
					rthigh = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_R_Calf') ):ToScreen()
					lthigh = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_L_Calf') ):ToScreen()
					rfoot = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_R_Foot') ):ToScreen()
					lfoot = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_L_Foot') ):ToScreen()
					if rshoulder != novalue then
						surface.DrawLine(rshoulder.x,rshoulder.y,lshoulder.x,lshoulder.y)
						surface.DrawLine(rshoulder.x,rshoulder.y,relbow.x,relbow.y)
						surface.DrawLine(lshoulder.x,lshoulder.y,lelbow.x,lelbow.y)
						surface.DrawLine(relbow.x,relbow.y,rwrist.x,rwrist.y)
						surface.DrawLine(lelbow.x,lelbow.y,lwrist.x,lwrist.y)
						surface.DrawLine(head.x,head.y,pelvis.x,pelvis.y)
						surface.DrawLine(pelvis.x,pelvis.y,rthigh.x,rthigh.y)
						surface.DrawLine(pelvis.x,pelvis.y,lthigh.x,lthigh.y)
						surface.DrawLine(rthigh.x,rthigh.y,rfoot.x,rfoot.y)
						surface.DrawLine(lthigh.x,lthigh.y,lfoot.x,lfoot.y)
					end
				end
			end
		end
	end
end) 
 


-- nightmode

AddHook("RenderScreenspaceEffects", RandomString(), function()          
                if GetConVarNumber("nightmodee") == 1 then
                        local nightmode = {
                                [ "$pp_colour_addr" ] = 55 * (1 / 255),
                                [ "$pp_colour_addg" ] = 45 * (1 / 255),
                                [ "$pp_colour_addb" ] = 66 * (1 / 255),
                                [ "$pp_colour_brightness" ] = -0.2,
                                [ "$pp_colour_contrast" ] = 0.3,
                                [ "$pp_colour_colour" ] = 1,
                                [ "$pp_colour_mulr" ] = 0,
                                [ "$pp_colour_mulg" ] = 0,
                                [ "$pp_colour_mulb" ] = 0
                        }
                        DrawColorModify( nightmode )
                end
        
    end)

-- thirdpersonn

hook.Add( "CalcView", "ThirdPerson", function(ply, pos, angles, fov)
        local ThirdPerson = {}
        local CustomFOV = {}
        if GetConVarNumber("ThirdPerson1") == 1 then
                ThirdPerson.origin = pos-( angles:Forward()*100 )
                ThirdPerson.angles = angles
                ThirdPerson.fov = fov
                ThirdPerson.drawviewer = true
                return ThirdPerson
        else 
                ThirdPerson.origin = pos-( angles:Forward() )
                ThirdPerson.angles = angles
                ThirdPerson.fov = fov
        end
end)

--- no sky

AddHook("PreDrawSkyBox", RandomString(), function()
     
    	if GetConVarNumber("noosky") == 1 then
    		return true
    	else
    		return false
    	end
     
    end)

--- full bright

local LightingModeChanged = false
    AddHook("PreRender", RandomString(), function()
    		if GetConVarNumber("fulllbright") == 1 then
    			render.SetLightingMode( 1 )
    			LightingModeChanged = true
    		end
    	
    end )
     
    local function EndOfLightingMod()
    	if LightingModeChanged then
    		render.SetLightingMode( 0 )
    		LightingModeChanged = false
    	end
    end
    AddHook("PostRender", RandomString(), EndOfLightingMod)
    AddHook("PreDrawHUD", RandomString(), EndOfLightingMod)
     

 --- MOVEMENT

--bhop

function BHop()
        if GetConVarNumber("BHop") == 1 and input.IsKeyDown( KEY_SPACE ) and GetConVarNumber("BHop_AC") == 1 then
                if ply:IsTyping() == false and ply:IsOnGround() then
                        RunConsoleCommand("+jump")
                        timer.Create("Bhop", 0, math.random( .280, .290 ), function()
                                RunConsoleCommand("-jump")
                        end)
                end
        elseif GetConVarNumber("BHop") == 1 and input.IsKeyDown( KEY_SPACE ) and GetConVarNumber("BHop_AC") == 0 then
                if ply:IsTyping() == false and ply:IsOnGround() then
                        RunConsoleCommand("+jump")
                        timer.Create("Bhop", 0, .01, function()
                                RunConsoleCommand("-jump")
                        end)
                end
        end
end
hook.Add("Think", "BHop", BHop)

-- auto straferr

 
--- HVH

-- anti anti aim

local function AAA()
if GetConVarNumber("antiantiaim") == 1 then
        for k,v in next, player.GetAll() do
                if (!IsValid(v) or v:IsDormant()) then
                        continue
                end
                
                if (!v:Alive() or v:Health() < 1) then
                        continue
                end
                
                local eyeangles = v:EyeAngles()
                local roll = eyeangles.r
                
                if (roll == 180 or roll == -180) then           
                        v:SetRenderAngles(Angle(0, eyeangles.y - 180, 0))
                        v:SetPoseParameter("aim_pitch", eyeangles.x >= 0 and 89 or -89)
                        v:InvalidateBoneCache()
                end
        end
   end
end

hook.Add("PreDrawOpaqueRenderables", "Simple_AAA", AAA)


--- MISC

--no recoil

local OEyeAngles = OEyeAngles or FindMetaTable( "Player" ).SetEyeAngles

FindMetaTable( "Player" ).SetEyeAngles = function( self, angle )

    if ( string.find( string.lower( debug.getinfo( 2 ).short_src ), "/weapons/" ) ) and GetConVar("norecoil"):GetInt() == 1 then return end

    OEyeAngles( self, angle )

end


-- chatspam

SpamMessages = {}
SpamMessages[1] = "FORTNITEHACK FOR GMOD"
SpamMessages[2] = "TIRED OF GETTING OWNED GET FORTNITEHACK NOW!"
SpamMessages[3] = "FORTNITEHACK OWNING SKIDS"
SpamMessages[4] = "FORTNITEHACK PURE LUA!"
SpamMessages[5] = "GET FORTNITEHACK NOW!"
SpamMessages[6] = "VISUALS THAT WILL BLOW YOUR MIND"
SpamMessages[7] = "FORTNITEHACK FOR THE LOW PRICE OF 5 DOLLARS"


local function chatspamsimpleshit()
        if GetConVarNumber("ChatSpam") == 1 then
                ply:ConCommand("say  "..table.Random(SpamMessages).." " )
        end
end
timer.Create("chatspamtimer", .10, 0, chatspamsimpleshit)

-- hvh killsay

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "", function(data)
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;
 local awesome = {"weak", "get owned skid", "lol", "lmao"}
 if GetConVarNumber("killsay") == 1 and (vic_index != att_index && att_index == me:EntIndex()) then
 RunConsoleCommand("say", awesome[ math.random( #awesome ) ] )
end
end)


-- crossbowpred



hook.Add("HUDPaint", "CrossbowPrediction", function()
    local ply = LocalPlayer()

    if not IsValid(ply) or not ply:Alive() then return end

if GetConVarNumber("crossbowpred") == 1 then
    for _, target in pairs(player.GetAll()) do
        if IsValid(target) and target:IsPlayer() and target:Alive() and target != ply then
            local velocity = target:GetVelocity()

            local midsection = target:GetPos() + Vector(0, 0, target:BoundingRadius())
            local predictPos = midsection + velocity * (ply:EyePos():Distance(midsection) / 3500)
            local screenPos = predictPos:ToScreen()

            local distance = ply:EyePos():Distance(midsection)
            local boltDrop = -0.5 * (distance / 800)^2.15  -- Simple quadratic drop formula

            -- Adjust the prediction position for bolt drop
            predictPos.z = predictPos.z - boltDrop

            local screenPosAdjusted = predictPos:ToScreen()

            -- Draw a persistent box for each player with a smaller dot in the middle, factoring in bolt drop and customizable color
            surface.SetDrawColor(boxColor.r, boxColor.g, boxColor.b, boxColor.a)
            surface.DrawOutlinedRect(screenPosAdjusted.x - 7, screenPosAdjusted.y - 7, 14, 14)

            surface.DrawCircle(screenPosAdjusted.x, screenPosAdjusted.y, 2, boxColor.r, boxColor.g, boxColor.b, boxColor.a)
        end
    end
  end
end)

-- bolt box and bolt alert



hook.Add("OnEntityCreated", "CrossbowBoltAlert", function(ent)
if GetConVarNumber("boltalert") == 1 then
    if IsValid(ent) and ent:GetClass() == "crossbow_bolt" then
        local shooter = ent:GetOwner()

        if IsValid(shooter) and shooter:IsPlayer() then
            local shooterName = shooter:Nick()
            chat.AddText(Color(255, 0, 0), "[Crossbow Alert] ", Color(255, 255, 255), shooterName .. " has fired a crossbow bolt!")
        end
    end
 end
end)



hook.Add("HUDPaint", "CrossbowBoltBoxes", function()
    local localPlayer = LocalPlayer()

if GetConVarNumber("boltbox") == 1 then
    for _, ent in pairs(ents.FindByClass("crossbow_bolt")) do
        if IsValid(ent) then
            local owner = ent:GetOwner()
            if IsValid(owner) and owner == localPlayer then
                local boltPos = ent:GetPos():ToScreen()

                local boxSize = 6
                surface.SetDrawColor(0, 255, 0, 255)
                surface.DrawOutlinedRect(boltPos.x - boxSize / 2, boltPos.y - boxSize / 2, boxSize, boxSize)
            end
        end
    end
 end
end)

-- hitsound

AddHook("ScalePlayerDamage", RandomString(), function(ply, group, dmginfo)
    	if GetConVarNumber("hittsound") == 1 then
    		if dmginfo:GetAttacker() == LocalPlayer() then
    			surface.PlaySound("garrysmod/balloon_pop_cute.wav")
    		end
    	end
    end)
    
-- key genereator 


-- Function to generate a random Windows product key
local function GenerateWindowsKey()
    local key = ""
    local characters = {"A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "M", "N", "P", "Q", "R", "T", "V", "W", "X", "Y", "2", "3", "4", "6", "7", "8", "9"}

    -- Generate the first group (5 characters)
    for i = 1, 5 do
        key = key .. characters[math.random(1, #characters)]
    end

    -- Insert a hyphen
    key = key .. "-"

    -- Generate the second group (5 characters)
    for i = 1, 5 do
        key = key .. characters[math.random(1, #characters)]
    end

    -- Insert a hyphen
    key = key .. "-"

    -- Generate the third group (5 characters)
    for i = 1, 5 do
        key = key .. characters[math.random(1, #characters)]
    end

    -- Insert a hyphen
    key = key .. "-"

    -- Generate the fourth group (5 characters)
    for i = 1, 5 do
        key = key .. characters[math.random(1, #characters)]
    end

    return key
end

-- Function to say the generated Windows key in chat
local function SayGeneratedKey()
    local generatedKey = GenerateWindowsKey()
    RunConsoleCommand("say", "Generated Windows Key: " .. generatedKey)
end


-- Timer to continuously generate and say keys until toggled off
timer.Create("KeyGenerationTimer", 1, 0, function()
    if GetConVar("toggle_key_generation"):GetBool() then
        SayGeneratedKey()
    end
end)



--- RANDOM MAIN CHEAT STUFF


local function DrawWatermark()
    local x = 10
    local y = 10
    local width = 600
    local height = 50

    local text = "FORTNITEHACK FOR ALL YOUR CHEATING NEEDS"

    local fontSize = 30

    draw.RoundedBox(8, x, y, width, height, Color(0, 0, 0, 150))  -- Background
    draw.SimpleText(text, "DermaDefaultBold", x + width / 2, y + height / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end


hook.Add("HUDPaint", "MKMHOMESUCKS!", DrawWatermark)






