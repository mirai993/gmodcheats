// GBot Code By Scooby. 

print( "GBot Core Loaded (Version 1)" )

if SERVER then return end

if( !GBot ) then 

	GBot = {} 
	GBot.Version = {}
	GBot.Author = {}
	GBot.NewsLink = ""
	
else

	return
	
end

local ents = ents -- Localizing Comonly Used Functions For Speed
local timer = timer
local print = print
local ipairs = ipairs
local pairs = pairs
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand
local ValidEntity = ValidEntity

local Mat = Material( "GBot/GBot_Walls_vis" )
local Mat2 = Material( "GBot/GBot_Walls" )

/*------------------------------------------------------------------------------------------------------------------------
	Main
------------------------------------------------------------------------------------------------------------------------*/

GBot.Hooks = {}

local function RandName()

	local ret = ""
	
	for i=1, math.random( 10, 30 ) do
	
		local int = math.random( 65, 91 )
		ret = ret..string.char( int )
		
	end
	
	return ret
	
end
	

function GBot.Hook( Hook, Name, Func )
	
	local str = RandName()
	
	table.insert( GBot.Hooks, { Hook, str } )
	
	hook.Add( Hook, str, Func )
	
end

function GBot.ClearHooks()
	
	local hooks = GBot.Hooks
	
	for _,v in ipairs( hooks ) do
	
		hook.Remove( v[1], v[2] )
		
	end
	
end

concommand.Add( "GBot_Off", GBot.ClearHooks )

local Vars = {}
local VarFunc = {}

function GBot.GetVar( str )
	
	if( Vars[ str ] ) then 
		
		return Vars[ str ]:GetInt() 
		
	end
	error( "Attempt To Get An Un-Activated Variable!" )
	return nil
	
end

function GBot.VarHook( func )

	table.insert( VarFunc, func )
	
end

function GBot.SetVar( str, val )
	
	Vars[ str ] = CreateClientConVar( "~GBot_"..str, val, true, true )
	for _,func in ipairs( VarFunc ) do
	
		func()
		
	end
	
end

function GBot.Vars()

	local ret = {}
	
	for nm,var in pairs( Vars ) do
	
		ret[ nm ] = var:GetInt()
		
	end
	
	return ret
	
end

GBot.Hook( "Initialize", "Gbot~DefVars", function()
	
	local config = file.Read( "gbot_cahce.txt" )
	
	if( file.Exists( "gbot/"..config..".txt" ) ) then
	
		local v = util.KeyValuesToTable( file.Read( "gbot/"..config..".txt" ) )
			
		for name,value in pairs( v ) do
		
			GBot.SetVar( string.upper( name ), value )
		
		end
		
	end
	
end )

/* -- This was annoying as fuck.
GBot.Hook( "HUDPaint", "GBot~DrawStuff", function()
	
	if( GBot.GetVar( "2RADAR_ON" ) == 1 or GBot.GetVar( "AIMBEAM_ON" ) == 1 or GBot.GetVar( "WALLS_ON" ) == 1 or GBot.GetVar( "AIMBOT_ON" ) == 1 or GBot.GetVar( "ESP_ON" ) == 1  or GBot.GetVar( "CROSSHAIR_ON" ) == 1 ) then 
		
		surface.SetFont( "HUDNumber1" )
		local w, h = surface.GetTextSize( "GBot V"..GBot.Version.." by "..GBot.Author, "HUDNumber1" )
		
		draw.SimpleText( "GBot V"..GBot.Version.." by "..GBot.Author, "HUDNumber1", ScrW() - w - ScrW()/50, ScrH()/50, color_white )
	
	end
	
end )
*/
/*------------------------------------------------------------------------------------------------------------------------
	Calculator
------------------------------------------------------------------------------------------------------------------------*/

print( "Loaded GBot Calculator" )

GBot.Colors = {}
GBot.Colors.Red = Color( 255, 30, 10 )
GBot.Colors.Yellow = Color( 10, 255, 255 )

// This Is For Calculating Things For The Modules

function GBot.Visible( ent, vec )
	
	if not ValidEntity( LocalPlayer() ) then
		return false
	end
	
	local trace = {}
	trace.start = LocalPlayer():EyePos()
	trace.endpos = vec or ent:GetPos()
	trace.mask = 1174421507
	trace.filter = { LocalPlayer(), ent }
	
	tr = util.TraceLine( trace )
	
	return !tr.Hit or tr.HitEntity == ent
	
end

function _r.Entity:GetGBotStatus()

	if( !self:IsPlayer() ) then return 1 end
	
	if( self:Team() == LocalPlayer():Team() ) then
	
		return 0
		
	else
	
		return 1
		
	end
	
end

/*------------------------------------------------------------------------------------------------------------------------
	Menu
------------------------------------------------------------------------------------------------------------------------*/


local Def

GBot.Menu = {}
GBot.Menu.Cat = {}
GBot.Menu.Type = {
	
	Num = 0,
	Bool = 1
	
}

local cmenuo = false

local CEnts = {}

GBot.Hook( "Initialize", "GBot~LoadCents", function()
	
	if( file.Exists( "gbot_cents.txt" ) ) then
		
		CEnts = util.KeyValuesToTable( file.Read( "gbot_cents.txt" ) )
		
	end
	
end )

function GBot.CMenu()
	
	if( cmenuo ) then return end
	
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( 300, 240 )
	frame:SetTitle( "Custom ESP/Cham Entities" )
	frame:Center()
	frame:MakePopup()
	
	cmenuo = true
	
	frame.Close = function()
	
		frame:Remove()
		cmenuo = false
		
	end
	
	local tb = vgui.Create( "DTextEntry", frame )
	tb:SetWide( 150 )
	tb:SetPos( 10, 170 )
	
	local dl = vgui.Create( "DListView", frame )
	dl:SetSize( 280, 130 )
	dl:SetPos( 10, 30 )
	dl:AddColumn( "Entity Class" )
	
	dl:Clear()
	
	for _,v in ipairs( CEnts ) do
				
				local line = dl:AddLine( v )
				line.OnSelect = function()
				
					tb:SetText( line:GetValue( 1 ) )
					
				end
		
	end
	
	local add = vgui.Create( "DButton", frame )
	add:SetSize( 50, 20 )
	add:SetPos( 165, 170 )
	add:SetText( "Add" )
	
	add.DoClick = function()
		
		local text = tb:GetValue()
		
		if( !table.HasValue( CEnts, string.lower( text ) ) ) then
			
			table.insert( CEnts, string.lower( text ) )
			
		end
		
		dl:Clear()
		
		for _,v in ipairs( CEnts ) do
				
				local line = dl:AddLine( v )
				line.OnSelect = function()
				
					tb:SetText( line:GetValue( 1 ) )
					
				end
		
		end
		
		tb:SetValue( "" )
		
		file.Write( "gbot_cents.txt", util.TableToKeyValues( CEnts ) )
		
	end
	
	local re = vgui.Create( "DButton", frame )
	re:SetSize( 50, 20 )
	re:SetPos( 220, 170 )
	re:SetText( "Remove" )
	
	re.DoClick = function()
	
		local text = tb:GetValue()
	
		for k,str in ipairs( CEnts ) do
		
			if( string.lower( str ) == string.lower( text ) ) then
			
				CEnts[ k ] = nil
				break
				
			end
			
		end
		
		dl:Clear()
		
		for _,v in ipairs( CEnts ) do
				
				local line = dl:AddLine( v )
				line.OnSelect = function()
				
					tb:SetText( line:GetValue( 1 ) )
					
				end
		
		end
		
		tb:SetValue( "" )
		
		file.Write( "gbot_cents.txt", util.TableToKeyValues( CEnts ) )
	
	end
	
	local ae = vgui.Create( "DButton", frame )
	ae:SetSize( 120, 30 )
	ae:SetPos( 90, 200 )
	ae:SetText( "Add Entity At Aim" )
	
	ae.DoClick = function()
		
		local tr = LocalPlayer():GetEyeTrace()
		
		if( !tr.Hit ) then return end
		
		if( tr.Entity:IsValid() ) then
			
			if( !table.HasValue( CEnts, string.lower( tr.Entity:GetClass() ) ) ) then
			
				table.insert( CEnts, string.lower( tr.Entity:GetClass() ) )
				
			end
			
			dl:Clear()
			
			for _,v in ipairs( CEnts ) do
				
				local line = dl:AddLine( v )
				line.OnSelect = function()
				
					tb:SetText( line:GetValue( 1 ) )
					
				end
			
			end
		
			file.Write( "gbot_cents.txt", util.TableToKeyValues( CEnts ) )
			
		end
			
		
	end
	
end

function GBot.CEntity( ent )

	if( ent ) and ValidEntity( ent ) then
	
		local class = string.lower( ent:GetClass() )
		
		for _,cl in ipairs( CEnts ) do
		
			if( string.lower( cl ) == class ) then
			
				return true
				
			end
			
			
		end
		
		return false
		
	end
	
	return false
	
end

function GBot.Menu:AddCategory( Name )
	
	if( !GBot.Menu.Cat[ Name ] ) then
	
		GBot.Menu.Cat[ Name ] = {}
	
	end
	
end

function GBot.Menu:AddItem( Cat, Item, Min, Max, Def, Var, Type )
	
	GBot.Menu.Cat[ Cat ] [ Item ] = { MinV = Min, MaxV = Max, DefV = Def, VarV = Var, Type = Type }
	GBot.SetVar( Var, Def )
	
end

function GBot.Menu:AddButton( Cat, Item, Text, Func )
	
	GBot.Menu.Cat[ Cat ] [ Item ] = { Type = 3, Text = Text, Func = Func }
	
end

function GBot.Menu:AddColorItem( Cat, Item, Def, Pre, pt, mdl )
	
	GBot.Menu.Cat[ Cat ] [ Item ] = { Type = 2, Def = Def, Pre = Pre, Pt = pt, Mdl = mdl }
	GBot.SetVar( Pre.."R", Def.r )
	GBot.SetVar( Pre.."G", Def.g )
	GBot.SetVar( Pre.."B", Def.b )
	
end

function GBot.Menu:AddDropDown( Cat, Item, def, Convar, ValueTable )

	GBot.Menu.Cat[ Cat ] [ Item ] = { Type = 4, Def = def, convar = Convar, Vars = ValueTable, Def = def }
	GBot.SetVar( Convar, def )
	
end

function GBot.Menu.Open()
	
	
	local Frame = vgui.Create( "DFrame" )
	Frame:SetPos( 30, 30 )
	Frame:SetSize( 300, 430 )
	Frame:SetTitle( "GBot Menu" )
	
	local Save = vgui.Create( "DButton", Frame )
	Save:SetPos( 45, 400 )
	Save:SetSize( 100, 25 )
	Save:SetText( "Save" )
	
	local Load = vgui.Create( "DButton", Frame )
	Load:SetPos( 150, 400 )
	Load:SetSize( 100, 25 )
	Load:SetText( "Load" )
	
	local LOpen = false
	local SOpen = false
	
	Load.DoClick = function()
		
		if( LOpen or SOpen ) then return end
		
		local Fl = ""
		
		local LFrame = vgui.Create( "DFrame" )
		LFrame:SetSize( 400, 300 )
		LFrame:Center()
		LFrame:MakePopup()
		LFrame:SetTitle( "GBot Config Menu" )
		
		LFrame.Close = function()
		
			LFrame:Remove()
			LOpen = false
			
		end
		
		local LList = vgui.Create( "DListView", LFrame )
		LList:SetSize( 380, 230 )
		LList:SetPos( 10, 30 )
		LList:SetMultiSelect( false )
		LList:AddColumn( "Name" )
		
		local files = file.Find( "gbot/*.txt" )
		
		for _,con in ipairs( files ) do
		
			local item = LList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
			item.OnSelect = function()
			
				Fl = item:GetValue( 1 )
				
			end
			
		end
		
		local LBut = vgui.Create( "DButton", LFrame )
		LBut:SetSize( 100, 20 )
		LBut:SetPos( 90, 270 )
		LBut:SetText( "Load" )
		
		LBut.DoClick = function()
		
			local v = util.KeyValuesToTable( file.Read( "gbot/"..Fl..".txt" ) )
			
			file.Write( "gbot_cahce.txt", Fl )
			
			for name,value in pairs( v ) do
			
				RunConsoleCommand( "~GBot_"..name, value )
				
		
			end
			
		end
		
		local LBut2 = vgui.Create( "DButton", LFrame )
		LBut2:SetSize( 100, 20 )
		LBut2:SetPos( 200, 270 )
		LBut2:SetText( "Delete" )
		
		LBut2.DoClick = function()
		
			if( file.Exists( "gbot/"..Fl..".txt" ) ) then
			
				file.Delete( "gbot/"..Fl..".txt" )
				
				LList:Clear()
					
				local files = file.Find( "gbot/*.txt" )
		
				for _,con in ipairs( files ) do
		
					local item = SList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
					item.OnSelect = function()
			
						Fl = item:GetValue( 1 )
				
					end
				
				end
				
			end
			
		end
		
	end
	

	Save.DoClick = function()
		
		if( SOpen or LOpen ) then return end
		SOpen = true
		local SFrame = vgui.Create( "DFrame" )
		SFrame:SetSize( 400, 300 )
		SFrame:Center()
		SFrame:MakePopup()
		SFrame:SetTitle( "GBot Config Menu" )
		SFrame.Close = function()
		
			SFrame:Remove()
			SOpen = false
			
		end
		
		local SList = vgui.Create( "DListView", SFrame )
		SList:SetSize( 380, 230 )
		SList:SetPos( 10, 30 )
		SList:SetMultiSelect( false )
		SList:AddColumn( "Name" )
		
		local SBox = vgui.Create( "DTextEntry", SFrame )
		SBox:SetWide( 200 )
		SBox:SetPos( 60, 270 )
		
		local files = file.Find( "gbot/*.txt" )
		
		for _,con in ipairs( files ) do
		
			local item = SList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
			item.OnSelect = function()
			
				SBox:SetValue( item:GetValue( 1 ) )
				
			end
			
		end
		
		local SBut = vgui.Create( "DButton", SFrame )
		SBut:SetSize( 40, 20 )
		SBut:SetPos( 270, 270 )
		SBut:SetText( "Save" )
		
		local SBut2 = vgui.Create( "DButton", SFrame )
		SBut2:SetSize( 40, 20 )
		SBut2:SetPos( 320, 270 )
		SBut2:SetText( "Delete" )
		
		SBut2.DoClick = function()
		
			if( file.Exists( "gbot/"..SBox:GetValue()..".txt" ) ) then
			
				file.Delete( "gbot/"..SBox:GetValue()..".txt" )
				
				SList:Clear()
					
				local files = file.Find( "gbot/*.txt" )
		
				for _,con in ipairs( files ) do
		
					local item = SList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
					item.OnSelect = function()
			
						SBox:SetValue( item:GetValue( 1 ) )
				
					end
				
				end
				
			end
			
		end
				
		
		local OOpen = false
		
		SBut.DoClick = function()
			
			if OOpen then return end
			
			local name = SBox:GetValue()
			
			if( file.Exists( "gbot/"..name..".txt" ) ) then
				
				OOpen = true
				
				local OFrame = vgui.Create( "DFrame" )
				OFrame:SetSize( 250, 100 )
				OFrame:SetTitle( "Overwrite?" )
				OFrame:Center()
				OFrame:MakePopup()
				
				OFrame.Close = function()
				
					OOpen = false
					OFrame:Remove()
					
				end
				
				local OText = vgui.Create( "DLabel", OFrame )
				OText:SetText( "Do You Want To Overwrite The Existing Config?" )
				OText:SizeToContents()
				OText:SetPos( 8, 25 )
				
				local OYes = vgui.Create( "DButton", OFrame )
				OYes:SetSize( 80, 40 )
				OYes:SetPos( 15, 50 )
				OYes:SetText( "Yes" )
				
				OYes.DoClick = function()
				
					file.Write( "gbot/"..name..".txt", util.TableToKeyValues( GBot.Vars() ) )
					
					SList:Clear()
					
					local files = file.Find( "gbot/*.txt" )
		
					for _,con in ipairs( files ) do
		
						local item = SList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
						item.OnSelect = function()
			
							SBox:SetValue( item:GetValue( 1 ) )
				
						end
							
					end
					SBox:SetValue( "" )
					OFrame.Close()
					
				end
				
				local ONo = vgui.Create( "DButton", OFrame )
				ONo:SetSize( 80, 40 )
				ONo:SetPos( 140, 50 )
				ONo:SetText( "No" )
				
				ONo.DoClick = function()
					
					SBox:SetValue( "" )
					OFrame.Close()
					
				end
				
			else
				
				if( name == "" ) then
					
					name = "unnamed"
					
				end
				
				file.Write( "gbot/"..name..".txt", util.TableToKeyValues( GBot.Vars() ) )
				
				SList:Clear()
				
				local files = file.Find( "gbot/*.txt" )
		
				for _,con in ipairs( files ) do
				
					local item = SList:AddLine( string.Left( con, string.find( con, ".txt" ) - 1 ) )
					item.OnSelect = function()
			
						SBox:SetValue( item:GetValue( 1 ) )
				
					end
			
				end
				
			end
			
		end
		
	end

	local Panel1 = vgui.Create( "DPanel", Frame )
	Panel1:SetPos( 5, 25 )
	Panel1:SetSize( 142.5, 370 )

	local Panel2 = vgui.Create( "DPanel", Frame )
	Panel2:SetPos( 152.25, 25 )
	Panel2:SetSize( 142.5, 370 )

	local Combo = vgui.Create( "DComboBox", Panel1 )
	Combo:SetPos( 5, 5 )
	Combo:SetSize( Panel1:GetWide()-10, Panel1:GetTall()-10 )
	Combo:SetMultiple( false )
	
	local cnvs = vgui.Create( "DPanel", Panel2 )
	cnvs:SetPos( 0,0 )
	cnvs:SetWide( Panel2:GetWide() )
	
	local sb = vgui.Create( "DVScrollBar", Panel2 )
	sb:SetPos( Panel2:GetWide() - 16, 0 )
	sb:SetSize( 16, Panel2:GetTall() )
	
	local Items = {}
	
	for cat,items in pairs( GBot.Menu.Cat ) do
		
		local item = Combo:AddItem( cat )
		item.Value = cat
		item.DoClick = function()
		
			sb:SetScroll( 0 )
			
			cnvs:SetTall( 0 )
			cnvs:SetWide( Panel2:GetWide() )
			
			for _,item in ipairs( Items ) do
			
				item:Remove()
				
			end
			
			Items = {}
			
			table.SortByMember( items, "Type" )
			local y = 5
			
			local sort = {}
			sort.s = {}
			sort.c = {}
			sort.ch = {}
			sort.b = {}
			sort.dd = {}
			
			for name,id in pairs( items ) do
			
				if( id.Type == 0 ) then
					
					id.Name = name
					table.insert( sort.s, id )
					
				elseif( id.Type == 1 ) then
				
					id.Name = name
					table.insert( sort.ch, id )
					
				elseif( id.Type == 2 ) then
				
					id.Name = name
					table.insert( sort.c, id )
					
				elseif( id.Type == 3 ) then
				
					id.Name = name
					table.insert( sort.b, id )
					
				else
				
					id.Name = name
					table.insert( sort.dd, id )
					
				end
				
			end

			for _,id in ipairs( sort.ch ) do
				
				local sw = vgui.Create( "DCheckBoxLabel", cnvs )
				sw:SetPos( 10, y )
				sw:SetWidth( 120 )
				sw:SetText( id.Name )
				sw:SetConVar( "~GBot_"..id.VarV )
				table.insert( Items, sw )
					
				y = y + 20
				cnvs:SetTall( cnvs:GetTall() + 20 )
					
			end
	
			
			for _,id in ipairs( sort.s ) do
				
				local num = vgui.Create( "DNumSlider", cnvs )
				num:SetPos( 10, y )
				num:SetWidth( 120 )
				num:SetMax( id.MaxV )
				num:SetMin( id.MinV )
				num:SetDecimals( 0 )
				num:SetText( id.Name )
				num:SetConVar( "~GBot_"..id.VarV )
				table.insert( Items, num )
				
				y = y + 40
				cnvs:SetTall( cnvs:GetTall() + 40 )
				
			end
			
			for _,id in ipairs( sort.c ) do
					
				local title = vgui.Create( "DLabel", cnvs )
				title:SetPos( 20, y )
				title:SetText( id.Name )
				title:SizeToContents()
				
				local cs = vgui.Create( "DRGBBar", cnvs )
				cs:SetPos( 10, y + 20)
				cs:SetSize( 40, 75 )
					
				cs:SetColor( Color( GBot.GetVar( id.Pre.."R" ), GBot.GetVar( id.Pre.."G" ), GBot.GetVar( id.Pre.."B" ) ) )
				local asdf = CurTime() + 0.001
					
					
				local col
					
				cs.Think = function()
					if( asdf > CurTime() ) then return end
						
					col = HSVToColor( cs:GetHue(), 1, 1 )
						
						if( id.Pt != 2 ) then
						RunConsoleCommand( "~GBot_"..id.Pre.."R", col.r )
						RunConsoleCommand( "~GBot_"..id.Pre.."G", col.g )
						RunConsoleCommand( "~GBot_"..id.Pre.."B", col.b )
					end
						
				end
					
				if( id.Pt == 0 ) then
					
					local cb = vgui.Create( "DColouredBox", cnvs )
					cb:SetPos( 60, y + 20 )
					cb:SetSize( 60, 75 )
					
					local asdf = CurTime() + 0.001
						
					cb.Think = function()
							
						if( asdf > CurTime() ) then return end
						cb:SetColor( col )
							
					end
						
					table.insert( Items, cb )
						
				elseif( id.Pt == 2 ) then
					
					local sh = vgui.Create( "DColorCube", cnvs )
					sh:SetPos( 60, y + 20 )
					sh:SetSize( 60, 75 )
					sh:SetColor( Color( GBot.GetVar( id.Pre.."R" ), GBot.GetVar( id.Pre.."G" ), GBot.GetVar( id.Pre.."B" ) ) )
					local asdf = CurTime() + 0.001
					
					sh.Think = function()
						
						if( asdf > CurTime() ) then return end
						local fcol = sh:GetRGB()
						sh:SetBaseRGB( col )
						RunConsoleCommand( "~GBot_"..id.Pre.."R", fcol.r )
						RunConsoleCommand( "~GBot_"..id.Pre.."G", fcol.g )
						RunConsoleCommand( "~GBot_"..id.Pre.."B", fcol.b )
							
					end
						
					table.insert( Items, sh )
						
				end
		
					
				y = y + 100
				cnvs:SetTall( cnvs:GetTall() + 100 )
				table.insert( Items, cs )
				table.insert( Items, title )
					
			end
			
			for _,id in ipairs( sort.b ) do
			
				local but = vgui.Create( "DButton", cnvs )
				but:SetSize( 80, 30 )
				but:SetPos( 20, y )
				but:SetText( id.Text )
				but.DoClick = id.Func
				
				y = y + 40
				cnvs:SetTall( cnvs:GetTall() + 40 )
				table.insert( Items, but )
				
			end
			
			for _,id in ipairs( sort.dd ) do
			
			
				local title = vgui.Create( "DLabel", cnvs )
				title:SetPos( 20, y )
				title:SetText( id.Name )
				title:SizeToContents()
				
				local ddbox = vgui.Create( "DMultiChoice", cnvs )
				ddbox:SetSize( 90, 20 )
				ddbox:SetPos( 15, y + 20 )
				
				for _,var in ipairs( id.Vars ) do
				
					ddbox:AddChoice( var )
					
				end
				
				local q = GBot.GetVar( id.convar )
				
				for a,b in ipairs( id.Vars ) do
				
					if a == q then
						
						ddbox:ChooseOption( b, a )
						
					end
					
				end
				
				function ddbox:OnSelect( _, var, _ )
					
					for a,b in ipairs( id.Vars ) do
				
						if b == var then
							
							RunConsoleCommand( "~GBot_"..id.convar, a )
						end
					
					end
					
					
				end
				
				y = y + 40
				cnvs:SetTall( cnvs:GetTall() + 50 )
				table.insert( Items, ddbox )
				table.insert( Items, title )
				
			end
				
				
			
            sb:SetUp( Panel2:GetTall(), cnvs:GetTall() )
			
			if( sb.Enabled ) then 
				cnvs:SetWide( Panel2:GetWide() - 16 )
				cnvs:SetTall( cnvs:GetTall() + 10 ) -- Padding
				sb:SetUp( Panel2:GetTall(), cnvs:GetTall() ) -- Re Setup
			else
				cnvs:SetTall( Panel2:GetTall() )
			end
			
			
		end
		
	end
	
	cnvs.Think = function()
		
		cnvs:SetPos( 0, sb:GetOffset() )
		
	end
	
	Combo:SelectItem( Combo:GetItems()[1] )
	Combo:GetItems()[1].DoClick() -- The Func Doesnt Run If you select it with ComboBox:SelectItem( item ), so i ran it manually
	Frame:MakePopup()
	
end
concommand.Add( "GBot_Menu", GBot.Menu.Open )

/*------------------------------------------------------------------------------------------------------------------------
	2D Radar
------------------------------------------------------------------------------------------------------------------------*/


GBot.Menu:AddCategory( "2D Radar" )
GBot.Menu:AddItem( "2D Radar", "Enabled", 0, 1, 0, "2RADAR_ON", 1 )
GBot.Menu:AddItem( "2D Radar", "X", 0, 500, 500, "2RADAR_X", 0 )
GBot.Menu:AddItem( "2D Radar", "Y", 0, 500, 5, "2RADAR_Y", 0 )
GBot.Menu:AddItem( "2D Radar", "Width/Height", 0, 500, 15, "2RADAR_S", 0 )
GBot.Menu:AddItem( "2D Radar", "Dot Size", 1, 20, 5, "2RADAR_DS", 0 )
GBot.Menu:AddColorItem( "2D Radar", "Background Color", color_white , "2RADAR_B_", 2, color_white )
GBot.Menu:AddColorItem( "2D Radar", "Axis Color", Color( 150, 150, 150 ), "2RADAR_A_", 2, color_black )
GBot.Menu:AddColorItem( "2D Radar", "Enemy Color", Color( 255, 0, 0 ),  "2RADAR_E_", 0 )
GBot.Menu:AddColorItem( "2D Radar", "Freindly Color", Color( 0, 255, 0 ), "2RADAR_F_", 0 )
GBot.Menu:AddColorItem( "2D Radar", "Vision Lines Color", Color( 150, 150, 150 ), "2RADAR_V_", 2, Color( 150, 150, 150 ) )

local scale_x = ScrW()/500
local scale_y = ScrH()/500

GBot.Hook( "HUDPaint", "GBot~DrawRadar", function()
	
	if( GBot.GetVar( "2RADAR_ON" ) == 0 ) then return end
	
	local RADAR_X1 = GBot.GetVar( "2RADAR_X" )
	local RADAR_Y1 = GBot.GetVar( "2RADAR_Y" )
	local RADAR_S1 = GBot.GetVar( "2RADAR_S" )
	
	local RADAR_X = RADAR_X1 * scale_x
	local RADAR_Y = RADAR_Y1 * scale_y
	local RADAR_S = RADAR_S1 * scale_x
	local RADAR_H = RADAR_S/2
	
	surface.SetDrawColor( Color( GBot.GetVar( "2RADAR_B_R" ), GBot.GetVar( "2RADAR_B_G" ), GBot.GetVar( "2RADAR_B_B" ) ) )
	surface.DrawRect( RADAR_X, RADAR_Y, RADAR_S, RADAR_S ) -- Radar Box
	surface.SetDrawColor( Color( GBot.GetVar( "2RADAR_A_R" ), GBot.GetVar( "2RADAR_A_G" ), GBot.GetVar( "2RADAR_A_B" ) ) )
	surface.DrawLine( RADAR_X, RADAR_Y + RADAR_H, RADAR_X+ RADAR_S, RADAR_Y + RADAR_H ) -- Radar Axis Lines
	surface.DrawLine( RADAR_X + RADAR_H, RADAR_Y, RADAR_X + RADAR_H, RADAR_Y + RADAR_S )
	surface.SetDrawColor( Color( GBot.GetVar( "2RADAR_V_R" ), GBot.GetVar( "2RADAR_V_G" ), GBot.GetVar( "2RADAR_V_B" ) ) )
	local ang = LocalPlayer():GetAngles()
	local p = -ang.y
	surface.DrawLine( RADAR_X + RADAR_H, RADAR_Y + RADAR_H, RADAR_X + RADAR_H/5, RADAR_Y ) -- Vision Lines
	surface.DrawLine( RADAR_X + RADAR_H, RADAR_Y + RADAR_H, RADAR_X + RADAR_S - RADAR_H/5, RADAR_Y )
	
	for _,ent in ipairs( ents.GetAll() ) do
	
		if( ent:IsNPC() or ( ent:IsPlayer() and ent:Alive() and ent:Team() != TEAM_SPECTATOR ) ) then
		
			if( ent != LocalPlayer() ) then
			
				local ts = ent:GetGBotStatus()
				
				if( ts == 0 ) then
				
					surface.SetDrawColor( Color( GBot.GetVar( "2RADAR_F_R" ), GBot.GetVar( "2RADAR_F_G" ), GBot.GetVar( "2RADAR_F_B" ) ) )
					
				else
				
					surface.SetDrawColor( Color( GBot.GetVar( "2RADAR_E_R" ), GBot.GetVar( "2RADAR_E_G" ), GBot.GetVar( "2RADAR_E_B" ) ) )
					
				end
			
				if( math.abs( ent:GetPos().x - LocalPlayer():GetPos().x ) < 8000 and math.abs( ent:GetPos().y - LocalPlayer():GetPos().y ) < 8000 ) then
					
					local offset = {}
					local opos = {} 
					offset.x = LocalPlayer():GetPos().x
					offset.y = LocalPlayer():GetPos().y
					
					opos.x = ent:GetPos().x - offset.x
					opos.y = ent:GetPos().y - offset.y
					
					local FinPos = Vector( opos.x, opos.y, 0 )
					
					FinPos:Rotate( Angle( 0, p - 90 , 0 ) )
					
					local x, y, scale
					
					scale = RADAR_S/10000
					x = -FinPos.x * scale
					y = FinPos.y * scale
					
					if( math.abs( x ) < RADAR_H - 3 and math.abs( y ) < RADAR_H - 3 ) then
					
						surface.DrawRect( RADAR_X + RADAR_H + x - GBot.GetVar( "2RADAR_DS" )/2, RADAR_Y + RADAR_H + y - GBot.GetVar( "2RADAR_DS" )/2, GBot.GetVar( "2RADAR_DS" ),GBot.GetVar( "2RADAR_DS" )  )
						
					end
					
				end
			
			end
			
		end
		
	end
	
end )

/*------------------------------------------------------------------------------------------------------------------------
	Aimbeam
------------------------------------------------------------------------------------------------------------------------*/

GBot.Menu:AddCategory( "Aimbeams" )
GBot.Menu:AddItem( "Aimbeams", "Enabled", 0, 1, 0, "AIMBEAM_ON", 1 )

local function AIMBEAM_DRAW()
	
	if( GBot.GetVar( "AIMBEAM_ON" ) == 0 ) then return end
	for _,ent in ipairs( ents.GetAll() ) do
	
		if( ent:IsPlayer() ) then
		
			if( ent != LocalPlayer() and ent:Alive() and ent:Team() != TEAM_SPECTATOR ) then
					
				local trace = util.GetPlayerTrace( ent )
				local t =  util.TraceLine( trace )
				
				local bool, str = pcall( function()
					cam.Start3D( EyePos(), EyeAngles() )
						render.SetMaterial( Mat )
						render.DrawBeam( t.StartPos, t.HitPos, 4, 0, 0, color_white ) -- Draws A Beam From The Player To Where The Trace Hit Is, Showing where the player is aiming
					cam.End3D()
				end )
				
				if( !bool ) then
				
					print( str )
					
				end

			end
			
		end
		
	end
	
end

GBot.Hook( "RenderScreenspaceEffects", "GBot~AimBeam", AIMBEAM_DRAW )

/*------------------------------------------------------------------------------------------------------------------------
	Aimbot
------------------------------------------------------------------------------------------------------------------------*/

local targets = {}

local function AddTar( ent )

	table.insert( targets, ent )
	
end

local function RemoveTar( ent )

	for k,v in ipairs( targets ) do
	
		if( ent == v ) then
		
			targets[ k ] = nil
			
		end
		
	end
	
end

local function IS_TARGET( ent )

	for k,v in ipairs( targets ) do
		
		if( !ValidEntity( v ) ) then
		
			targets[ k ] = nil
			
		end
		
		if( ent == v ) then
		
			return true
			
		end
		
	end
	
	return false
	
end


GBot.Menu:AddCategory( "Aimbot" )
GBot.Menu:AddItem( "Aimbot", "Enabled", 0, 1, 0, "AIMBOT_ON", 1 )
GBot.Menu:AddDropDown( "Aimbot", "Mode", 1, "AIMBOT_MODE", { "Normal", "Safe Mode", "Highest Health" } )
GBot.Menu:AddItem( "Aimbot", "Show FOV Dots", 0, 1, 0, "AIMBOT_FOV_ON", 1 )
GBot.Menu:AddItem( "Aimbot", "TriggerBot", 0, 1, 0, "AIMBOT_TBOT", 1 )
GBot.Menu:AddDropDown( "Aimbot", "Aim Key", 1, "AIMBOT_KEY", { "Automatic", "Left Mouse", "Right Mouse" } )
GBot.Menu:AddItem( "Aimbot", "FOV", 0, 360, 0, "AIMBOT_FOV", 0 )
GBot.Menu:AddItem( "Aimbot", "Target Players?", 0, 1, 0, "AIMBOT_PLS", 1 )
GBot.Menu:AddItem( "Aimbot", "Target NPCS?", 0, 1, 0, "AIMBOT_NPC", 1 )
GBot.Menu:AddItem( "Aimbot", "FOV Dot Size", 1, 10, 5, "AIMBOT_B_S", 0 )
GBot.Menu:AddColorItem( "Aimbot", "FOV Dot Color", Color( 150, 150, 150 ), "AIMBOT_D_", 2, color_white )
GBot.Menu:AddItem( "Aimbot", "Velocity Prediction", 0, 1, 0, "AIMBOT_VPREDICT", 1 )
GBot.Menu:AddDropDown( "Aimbot", "Target Bone", 1, "AIMBOT_BONEX", { "head", "spine", "Right Shoulder", "Left Shoulder", "Right Hand", "Left Hand", "Right Foot", "Left Foot", "Right Forearm", "Left Forearm", "Right Thigh", "Left Thigh", "Right Calf", "Left Calf", "Right Elblow", "Left Elbow" } )

local weapons = {
["weapon_crossbow"] = 3110
}

function GBot.CalcPos( pos, pl )
	
	if ValidEntity(pl) and type(pl:GetVelocity()) == "Vector" and pl.GetPos and type(pl:GetPos()) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
		local weapon = (LocalPlayer().GetActiveWeapon and (ValidEntity(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()))
		
		if weapon and weapons[weapon] then
			local time = distance / weapons[weapon]
			return pos + pl:GetVelocity() * time
		elseif GBot.GetVar( "AIMBOT_VPREDICT" ) == 1 then
			
			if LocalPlayer():GetVelocity():Length() > 100 then
				pos = pos - Vector(0 , 0 , LocalPlayer():GetVelocity():Length() / 250)
			end
			
			return pos + pl:GetVelocity() * 0.0087 - LocalPlayer():GetVelocity() * 0.0087 -- ( pl:GetVelocity() / 47 - LocalPlayer():GetVelocity() / 47 )--+ ( pl.GetVelocity and pl:GetVelocity() * 0.0025 * LocalPlayer():Ping() )
			
		end
		
		return pos
	end
	return pos
	
end

local AIMBOT_LOCKED = false
local AIMBOT_TARGET = NULL
local AIMBOT_RELOADING = false

local function AIMBOT_GETBONE( ent, _ )
	
	if( ent:IsNPC() ) then return ent:EyePos() end
	
	local str = GBot.GetVar( "AIMBOT_BONEX" )
	local lu = ""
	
	if( str == 1 ) then
	
		if( ent:GetModel() == "models/zombie/classic.mdl" ) then
		
			lu = "ValveBiped.HC_Body_Bone"
			
		elseif( ent:GetModel() == "models/zombie/fast.mdl" ) then
		
			lu = "ValveBiped.HC_BodyCube"
			
		elseif( ent:GetModel() == "models/zombie/poison.mdl" ) then
		
			lu = "ValveBiped.Bip01_Spine4"
			
		else
		
			lu = "ValveBiped.Bip01_Head1"
			
		end
		
	elseif( str == 2 ) then
	
		lu = "ValveBiped.Bip01_Spine"
		
	elseif( str == 3 ) then
	
		lu = "ValveBiped.Bip01_R_Shoulder"
		
	elseif( str == 4 ) then
	
		lu = "ValveBiped.Bip01_L_Shoulder"
		
	elseif( str == 5 ) then
	
		lu = "ValveBiped.Bip01_R_Hand"
		
	elseif( str == 6 ) then
	
		lu = "ValveBiped.Bip01_L_Hand"
		
	elseif( str == 7 ) then
	
		lu = "ValveBiped.Bip01_R_Foot"
		
	elseif( str == 8 ) then
	
		lu = "ValveBiped.Bip01_L_Foot"
		
	elseif( str == 9 ) then
	
		lu = "ValveBiped.Bip01_R_Forearm"
		
	elseif( str == 10 ) then
	
		lu = "ValveBiped.Bip01_L_Forearm"
		
	elseif( str == 11 ) then
	
		lu = "ValveBiped.Bip01_R_Thigh"
		
	elseif( str == 12 ) then
	
		lu = "ValveBiped.Bip01_L_Thigh"
		
	elseif( str == 13 ) then
	
		lu = "ValveBiped.Bip01_R_Calf"
		
	elseif( str == 14 ) then
	
		lu = "ValveBiped.Bip01_L_Calf"
		
	elseif( str == 15 ) then
	
		lu = "ValveBiped.Bip01_R_Elbow"
		
	elseif( str == 16 ) then
	
		lu = "ValveBiped.Bip01_L_Elbow"
		
	end
	
	if( lu == "" ) then print( "Error : Unreconized Bone" ) return end
	
	
    local BoneIndx = ent:LookupBone( lu )
	if( !BoneIndx ) then BoneIndx = ent:LookupBone( "ValveBiped.Bip01_Head1" ) end
    local BonePos , BoneAng = ent:GetBonePosition( BoneIndx )
	
	return BonePos , BoneAng
	
end

local function AIMBOT_SCREEN( ent )
	
	if( ent:IsPlayer() or ent:IsNPC() ) then
	
		if( ent:IsNPC() and GBot.GetVar( "AIMBOT_NPC" ) == 0 ) then return false end
		if( ent:IsPlayer() and GBot.GetVar( "AIMBOT_PLS" ) == 0 ) then return false end
		if( ent:IsPlayer() and !ent:Alive() ) then return false end
		
		return true
		
	else
		
		return false
		
	end

end

local function AngleBetween( a, b )

	return math.deg( math.acos( a:Dot( b ) ) )
	
end


local function AIMBOT_FOV_ENTS()
	
	local ret = {}
	
	for _,v in ipairs( ents.GetAll() ) do
		
		if( v != LocalPlayer() and AIMBOT_SCREEN( v ) ) then
			
			if( GBot.Visible( v, AIMBOT_GETBONE( v ) ) ) then
				
				local p, _ = AIMBOT_GETBONE( v )
				local ang = AngleBetween( EyeAngles():Forward(), ( p - LocalPlayer():GetShootPos() ):GetNormal() )
				print( ang )
				if( GBot.GetVar( "AIMBOT_FOV" ) >= ang ) then
				
					table.insert( ret, v )
					
				end
				
			end
		
		end
		
	end
	return ret
	
end

function AIMBOT_INFOV( ent )

	for _,v in ipairs( AIMBOT_FOV_ENTS() ) do
	
		if( v == ent ) then
		
			return true
			
		end
		
	end
	
end

local function AIMBOT_UPDATE()
	
	local Points = {}
	
	// This generates The most dangerous target, then sets the aimbot after them. 
	local s,e = pcall( function()
		
		if( GBot.GetVar( "AIMBOT_MODE" ) == 2 ) then // Safe Mode!
			
			for _,v in ipairs( AIMBOT_FOV_ENTS() ) do
				
				local q
				if( v:IsNPC() ) then q = v:GetPos() else q = v:GetShootPos() end 
				
				local p, _ = AIMBOT_GETBONE( LocalPlayer() )
				local ang = AngleBetween( v:EyeAngles():Forward(), ( p - q ):GetNormal() )
				
				if( math.sqrt(ang * (LocalPlayer():GetPos():Distance( v:GetPos() ) ) ) < 60 ) then
				
					Points[ v ] = 100
					
				else
				
					Points[ v ] = nil
					
				end
				
			end

		elseif( GBot.GetVar( "AIMBOT_MODE" ) == 1 ) then // Normal Mode
		
			for _,v in ipairs( AIMBOT_FOV_ENTS() )  do
					
				Points[ v ] = 200
				
			end
		
		elseif( GBot.GetVar( "AIMBOT_MODE" ) == 3 ) then // Health Mode
		
			for _,v in ipairs( AIMBOT_FOV_ENTS() ) do
			
				if( v:IsNPC() ) then
				
					Points[ v ] = 50
					
				elseif( v:IsPlayer() ) then
				
					Points[ v ] = v:Health()
					
				end
				
			end
			
		elseif( GBot.GetVar( "AIMBOT_MODE" ) == 4 ) then // RAMPAGE!!
		
			if( v:IsNPC() ) then
			
				Points[ v ] = math.sqrt( ang * ( LocalPlayer():GetPos():Distance( v:GetPos() ) ) ) + LocalPlayer():GetPos():Distance( v:GetPos() )
				
			elseif( v:IsPlayer() ) then
			
				Points[ v ] = math.sqrt( ang * ( LocalPlayer():GetPos():Distance( v:GetPos() ) ) ) + LocalPlayer():GetPos():Distance( v:GetPos() ) + v:Health() - v:Ping()
				
			end
			
		end
	
	end )
	
	if( !s ) then print( "[GBot]->Error: "..e ) end
	
	return Points
	
end

local function AIMBOT_SORT()
	
	-- Sort Through The Table
	
	local Points = AIMBOT_UPDATE()
	
	local ntbl = {}
	for k,v in pairs( Points ) do
		
		if( v != 0 ) then
		
			ntbl[ k ] = v
			
		end
		
	end
	
	table.sort( Points, function( a,b ) return a > b end )
	return table.GetFirstKey( Points )
	
end

local function AIMBOT_FIXANG( ang )
	if ang < 180 then
		return ang
	end
	return (ang % 180) - 180
end

local pang
local AIMBOT_ATTACKING = false

local HL2NonAuto = {

	"weapon_357",
	"weapon_pistol",
	"weapon_rpg"
	
}

local function AIMBOT_FIRE()
	
	local s, e = pcall( function()
		
		if( LocalPlayer():GetActiveWeapon():Clip1() > 0 and !AIMBOT_ATTACKING ) then
			
			RunConsoleCommand( "+attack" )
			AIMBOT_ATTACKING = true
		
		else
			
			RunConsoleCommand( "-attack" )
			AIMBOT_ATTACKING = false
			RunConsoleCommand( "+reload" )
			timer.Simple( 0.1, function()
			
				RunConsoleCommand( "-reload" )
				
			end )
			
		end
			
	end )
	
	if( !s ) then print( "[GBot]->Error: "..e ) end
	
end



local function AIMBOT_NONAUTO()

	if( !ValidEntity( LocalPlayer() ) ) then return false end
	
	if( !LocalPlayer().GetWeapon ) then return false end
	
	if( LocalPlayer():GetWeapon().Primary and LocalPlayer():GetWeapon().Primary.Automatic ) then return true end
	
	if( table.HasValue( HL2NonAuto, LocalPlayer():GetWeapon():GetClass() ) ) then return true end
	
	return false
	
end
	

local function AIMBOT_FIRE_2()
	
	local s, e = pcall( function()
		
		if( LocalPlayer():GetActiveWeapon():Clip1() > 0 and !AIMBOT_ATTACKING ) then
			
			RunConsoleCommand( "+attack" )
			AIMBOT_ATTACKING = true
			
			timer.Simple( 0.1, function()
			
				RunConsoleCommand( "-attack" )
				AIMBOT_ATTACKING = false
				
			end )
		
		else
			
			RunConsoleCommand( "-attack" )
			AIMBOT_ATTACKING = false
			RunConsoleCommand( "+reload" )
			timer.Simple( 0.1, function()
			
				RunConsoleCommand( "-reload" )
				
			end )
			
		end
			
	end )
	
	if( !s ) then print( "[GBot]->Error: "..e ) end
	
end

local function AIMBOT_AIM( cmd )
	
	if( GBot.GetVar( "AIMBOT_ON" ) == 0 ) then return end
	
	if( GBot.GetVar( "AIMBOT_KEY" ) == 2 ) then
		if !cmd:KeyDown( IN_ATTACK ) then
		
			if( AIMBOT_ATTACKING ) then
			
				RunConsoleCommand( "-attack" )
				AIMBOT_ATTACKING = false
				
			end
			
			return
			
		end
	end
	if( GBot.GetVar( "AIMBOT_KEY" ) == 3 ) then
		if !cmd:KeyDown( IN_ATTACK2 )  then
		
			if( AIMBOT_ATTACKING ) then
			
				RunConsoleCommand( "-attack" )
				AIMBOT_ATTACKING = false
				
			end
			
			return
			
		end
	end
	
	pcall( function()
		if( LocalPlayer():GetActiveWeapon() ) then
			if( LocalPlayer():GetActiveWeapon():Clip1() == 0 ) then	
			
				AIMBOT_FIRE()
				
				return
				
			end
		end
	end )
	
	local ent
	if( !AIMBOT_LOCKED ) then
		
		if( AIMBOT_ATTACKING ) then
		
			AIMBOT_ATTACKING = false
			RunConsoleCommand( "-attack" )
			
		end
		
		ent = AIMBOT_SORT()
		if( !ent ) or !ValidEntity( ent ) then return end
		
	else
	
		ent = AIMBOT_TARGET
		
	end
	
	if( !AIMBOT_INFOV( ent ) ) then
		
		if( AIMBOT_ATTACKING ) then
		
			AIMBOT_ATTACKING = false
			RunConsoleCommand( "-attack" )
			
		end
		
		ent = AIMBOT_SORT()
		if( !ent ) or !ValidEntity( ent ) then return end
		
	end
	
	local p, _ = GBot.CalcPos( AIMBOT_GETBONE( ent ), ent )
	local dang = AngleBetween( EyeAngles():Forward(), ( p - LocalPlayer():GetShootPos() ):GetNormal() )
	
	//p.x = p.x - ( dang/( LocalPlayer():GetPos():Distance( ent:GetPos() )^2.5 / 12 ) * ( ent:GetVelocity().x - LocalPlayer():GetVelocity().x ) ) -- More Smooth Aim
	//p.y = p.y - ( dang/( LocalPlayer():GetPos():Distance( ent:GetPos() )^2.5 / 12 ) * ( ent:GetVelocity().y - LocalPlayer():GetVelocity().y ) )
	//p.z = p.z - ( dang/( LocalPlayer():GetPos():Distance( ent:GetPos() )^2.5 / 12 ) * ( ent:GetVelocity().z - LocalPlayer():GetVelocity().z ) )
	
	local mpos = LocalPlayer():EyePos()

	local ang = ( p - mpos ):Angle()
	
	ang.p = AIMBOT_FIXANG( ang.p )
	ang.y = AIMBOT_FIXANG( ang.y )
	ang.r = AIMBOT_FIXANG( ang.r )
	
	AIMBOT_TARGET = ent
	cmd:SetViewAngles( ang )
	AIMBOT_LOCKED = true
	if( GBot.GetVar( "AIMBOT_TBOT" ) == 1 and !AIMBOT_ATTACKING ) then
		
		if( AIMBOT_NONAUTO() ) then
		
			AIMBOT_FIRE_2()
			
		end
		
		AIMBOT_FIRE()
		
	end 
	
end
GBot.Hook( "CreateMove", "GBot~DoStuff", AIMBOT_AIM )


local ScreenMaxAngle = {
	Length = 0,
	FOV = 0,
	MaxAngle = 0
}
local function AIMBOT_DRAW()
	
	if( GBot.GetVar( "AIMBOT_ON" ) == 0 ) then return end
	
	if( GBot.GetVar( "AIMBOT_FOV_ON" ) == 0 ) then return end
	local ply = LocalPlayer()
	
	if !ValidEntity( ply ) then return end

	local info = ScreenMaxAngle
	
	local maxang = GBot.GetVar( "AIMBOT_FOV" )
	
	local fov = ply:GetFOV()
	
	if( maxang > fov ) then return end
	
	if GetViewEntity() == ply && ( maxang != info.MaxAngle || fov != info.FOV ) then
	
		local view = EyeAngles()
		
			view.p = view.p + maxang

		local screen = ( ply:GetShootPos() + ( view:Forward() * 100 ) )
		
		screen = screen:ToScreen()

		info.Length = math.abs( ( ScrH() / 2) - screen.y )

		info.MaxAngle = maxang
		
		info.FOV = fov
	end

	local length = info.Length

	local cx, cy = ScrW() / 2, ScrH() / 2
	
	for x = -1, 1 do
	
		for y = -1, 1 do
		
			if x != 0 || y != 0 then
			
				local add = Vector( x, y, 0 ):GetNormal() * length
				
				surface.SetDrawColor( GBot.GetVar( "AIMBOT_D_R" ), GBot.GetVar( "AIMBOT_D_G" ), GBot.GetVar( "AIMBOT_D_B" ), 255 )
				surface.DrawRect( ( cx + add.x ), ( cy + add.y ), GBot.GetVar( "AIMBOT_B_S" ), GBot.GetVar( "AIMBOT_B_S" ) )
				
			end
			
		end
		
	end
	
end
GBot.Hook( "HUDPaint", "DrawExtraHUD", AIMBOT_DRAW )

local lastwep
GBot.Hook( "Think", "GBot~StopAttacking", function()
	
	if( lastwep != LocalPlayer():GetActiveWeapon() ) then
	
		AIMBOT_ATTACKING = false
		RunConsoleCommand( "-attack" ) 
		lastwep = LocalPlayer():GetActiveWeapon()
		
	end
	
	if( !ValidEntity( AIMBOT_TARGET ) and AIMBOT_ATTACKING ) then 
		
		AIMBOT_ATTACKING = false
		RunConsoleCommand( "-attack" ) 
		AIMBOT_TARGET = NULL
		return
		
	end
	
	if( AIMBOT_TARGET:IsPlayer() ) then
	
		if( !AIMBOT_TARGET:Alive() and AIMBOT_ATTACKING ) then
			
			AIMBOT_ATTACKING = false
			RunConsoleCommand( "-attack" )
			AIMBOT_TARGET = NULL
			
		end
		
	end
	
	
end )

/*------------------------------------------------------------------------------------------------------------------------
	ESP
------------------------------------------------------------------------------------------------------------------------*/

GBot.Menu:AddCategory( "ESP" )
GBot.Menu:AddItem( "ESP", "Enabled", 0, 1, 0, "ESP_ON", 1 )
GBot.Menu:AddItem( "ESP", "Display Admin Status", 0, 1, 0, "ESP_ADMIN", 1 )
GBot.Menu:AddItem( "ESP", "Display Health", 0, 1, 0, "ESP_HP", 1 )
GBot.Menu:AddItem( "ESP", "Display Weapon", 0, 1, 0, "ESP_WEP", 1 )
GBot.Menu:AddItem( "ESP", "Display Name", 0, 1, 0, "ESP_NAME", 1 )
GBot.Menu:AddItem( "ESP", "Draw Custom Entities", 0, 1, 0, "ESP_CENT", 1 )
GBot.Menu:AddButton( "ESP", "lolmutbutton", "Custom Entities", GBot.CMenu )


local ESP_BOOL = 0
local ESP_STRING = 1
local ESP_ENT = 2

local Items = {}


local a = {}
a.Name = "ADMIN"
a.Type = ESP_BOOL
a.Func = function( pl ) if pl:IsAdmin() then return true else return false end end
a.Text = function( bool ) if( bool ) then return "ADMIN" else return "Not Admin" end end
	
table.insert( Items, a )

a = {}
a.Name = "HP"
a.Type = ESP_STRING
a.Func = function( pl ) return pl:Health() or 0 end
 a.Text = function( hp ) return hp.."% HP" or "Unkown" end
	
table.insert( Items, a )

a = {}
a.Name = "WEP"
a.Type = ESP_ENT
a.Func = function( pl ) return pl:GetActiveWeapon() end
a.Text = function( wep ) return wep:GetClass() or "Unkown" end
	
table.insert( Items, a )

a = {}
a.Name = "NAME"
a.Type = ESP_STRING
a.Func = function( pl ) return pl:Nick() or "Unkown" end
a.Text = function( nick ) return nick or "Unkown" end
	
table.insert( Items, a )


function _R.Entity:EspPos()

	return self:GetPos() + Vector( 0, 0, 110 )
	
end

local function ESP_DRAW()
	
	if( GBot.GetVar( "ESP_ON" ) == 0 ) then return end
	
	for _,ent in ipairs( player.GetAll() ) do
	
		if( ent:IsPlayer() ) then
			
			if( ent != LocalPlayer() and ent:Alive() and ent:Team() != TEAM_SPECTATOR ) then
			
				if( ent:GetPos():Distance( LocalPlayer():GetPos() ) < 6000 ) then
					
					local Col
					
					if( GBot.Visible( ent ) ) then
					
						Col = Color( 255, 0, 0, 255 )
						
					else
					
						Col = Color( 255, 255, 0, 255 )
						
					end
					
						if( GBot.CEntity( ent ) ) then
						
							draw.SimpleText( ent:GetClass(), "MenuItem", ent:EspPos():ToScreen().x, ent:EspPos():ToScreen().y, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
							
						else
							
							local xof = 0
							
							pcall( function()
								
								for i=1, #Items do
									
									if( GBot.GetVar( "ESP_"..Items[ i ].Name ) == 1 ) then
										xof = xof + 12
										
										local value = Items[ i ].Func( ent )
										local text = Items[ i ].Text( value )
										draw.SimpleText( text, "MenuItem", ent:EspPos():ToScreen().x, ent:EspPos():ToScreen().y + xof, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
									
									end
									
								end
							
							end )
						
						
					end
					
				end
				
			end
			
		end
		
	end
	
end

GBot.Hook( "HUDPaint", "GBot~ESP", ESP_DRAW )

/*------------------------------------------------------------------------------------------------------------------------
	Removals
------------------------------------------------------------------------------------------------------------------------*/

GBot.Menu:AddCategory( "Removals" )
GBot.Menu:AddItem( "Removals", "Custom Crosshair", 0, 1, 0, "CROSSHAIR_ON", 1 )
GBot.Menu:AddItem( "Removals", "No Recoil (Experimental)", 0, 1, 0, "NORECOIL_ON", 1 )

function GBot.ValidWeapon()

	return true
	
end

// No Recoil (Shitty)
local function NoRecoil()

	if( GBot.GetVar( "NORECOIL_ON" ) == 1 ) then
	
		if GBot.ValidWeapon() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then
			
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			
		end
		
	end
	
end
GBot.Hook( "Think", "GBot~NoRecoil", NoRecoil )

local function CROSSHAIR()

	if( GBot.GetVar( "CROSSHAIR_ON" ) == 0 ) then return end
	
	local cx, cy = ScrW()/2, ScrH()/2
	
	surface.SetDrawColor( color_black )
	surface.DrawLine( cx - 30, cy, cx + 30, cy )
	surface.DrawLine( cx, cy - 30, cx, cy + 30 )
	
end
GBot.Hook( "HUDPaint", "GBot~CrossHair", CROSSHAIR )

/*------------------------------------------------------------------------------------------------------------------------
	Wallhacks
------------------------------------------------------------------------------------------------------------------------*/

GBot.Menu:AddCategory( "Wallhack" )
GBot.Menu:AddItem( "Wallhack", "Enabled", 0, 1, 0, "WALLS_ON", 1 )
GBot.Menu:AddColorItem( "Wallhack", "Vis Item Color", Color( 0, 255, 255 ), "WALLS_WV_",0 )
GBot.Menu:AddColorItem( "Wallhack", "Invis Item Color", Color( 0, 255, 0 ), "WALLS_WI_", 0 )
GBot.Menu:AddColorItem( "Wallhack", "Vis Ally Color", Color( 0, 255, 255 ), "WALLS_AV_", 0 )
GBot.Menu:AddColorItem( "Wallhack", "Invis Ally Color", Color( 0, 255, 0 ), "WALLS_AI_", 0 )
GBot.Menu:AddColorItem( "Wallhack", "Vis Enemey Color", Color( 255, 0, 0 ), "WALLS_EV_", 0 )
GBot.Menu:AddColorItem( "Wallhack", "Invis Enemey Color", Color( 255, 255, 0 ), "WALLS_EI_", 0 )
GBot.Menu:AddButton( "Wallhack", "lolmutbutton", "Custom Entities", GBot.CMenu )

local mat = Material( "GBot/GBot_Walls_vis" )
local mat2 = Material( "GBot/GBot_Walls" )

local function WALLS_DRAW()

	if( GBot.GetVar( "WALLS_ON" ) == 0 ) then return end
	
	for _,ent in ipairs( ents.GetAll() ) do
		
		if( ent:IsNPC() or ( ent:IsPlayer() and ent:Alive() and ent:Team() != TEAM_SPECTATOR ) or ent:IsWeapon() or GBot.CEntity( ent ) ) then
			
			if( ent != LocalPlayer() ) then
				
				local r,g,b,ri,gi,bi
				
				if( ent:IsWeapon() or GBot.CEntity( ent ) ) then
				
					r = GBot.GetVar( "WALLS_WV_R" )
					g = GBot.GetVar( "WALLS_WV_G" )
					b = GBot.GetVar( "WALLS_WV_B" )
					ri = GBot.GetVar( "WALLS_WI_R" )
					gi = GBot.GetVar( "WALLS_WI_G" )
					bi = GBot.GetVar( "WALLS_WI_B" )

				else
					
					if( ent:GetGBotStatus() == 1 ) then
					
						r = GBot.GetVar( "WALLS_EV_R" )
						g = GBot.GetVar( "WALLS_EV_G" )
						b = GBot.GetVar( "WALLS_EV_B" )
						ri = GBot.GetVar( "WALLS_EI_R" )
						gi = GBot.GetVar( "WALLS_EI_G" )
						bi = GBot.GetVar( "WALLS_EI_B" )
						
					else
						
						r = GBot.GetVar( "WALLS_AV_R" )
						g = GBot.GetVar( "WALLS_AV_G" )
						b = GBot.GetVar( "WALLS_AV_B" )
						ri = GBot.GetVar( "WALLS_AI_R" )
						gi = GBot.GetVar( "WALLS_AI_G" )
						bi = GBot.GetVar( "WALLS_AI_B" )
						
					end
					
				end
				
				local err, str = pcall( function()
				
					cam.Start3D( EyePos(), EyeAngles() )
					
							render.SuppressEngineLighting( true )
							
							render.SetColorModulation( ri, gi, bi )
							SetMaterialOverride( mat2 )
							
							ent:DrawModel() -- Model Not Visible Through Walls
							
							render.SetColorModulation( r, g, b )
							SetMaterialOverride( mat )
							
							ent:DrawModel() -- Model Only Visible Through The Walls
							
							render.SuppressEngineLighting( false )
							render.SetColorModulation( 255, 255, 255 )
							render.SetBlend( 1 )
							SetMaterialOverride( 0 )
							
						
						
					cam.End3D()
				
				end )
				
				if( !err ) then
				
					ErrorNoHalt( str )
				
				end
			
			end
		
		end
		
	end
	
end

GBot.Hook( "RenderScreenspaceEffects", "GBot~DrawOtherStuff", WALLS_DRAW )
