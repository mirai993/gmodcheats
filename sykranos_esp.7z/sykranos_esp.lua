

local CSSWeps = {
	["weapon_para"] = true,
	["weapon_ak47"] = true,
	["weapon_glock"] = true,
	["weapon_m4"] = true,
	["weapon_ar2"] = true,
	["weapon_pistol"] = true,
	["weapon_crowbar"] = true,
	["weapon_rpg"] = true,
	["weapon_shotgun"] = true,
	["weapon_crossbow"] = true,
	["weapon_frag"] = true,
}

local function SykESP()
	for k,ent in pairs( ents.GetAll() ) do
		local pos = (ent:LocalToWorld( ent:OBBCenter() )):ToScreen()
		local egc = ent:GetClass()
		
		if egc == "Player" then
			draw.SimpleTextOutlined(ent:GetName().. " "..ent:Health(),"UIBold",pos.x,pos.y,team.GetColor(ent:Team()),TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1,color_black)
			
		elseif CSSWeps[egc] then
			draw.SimpleTextOutlined(ent:GetClass(),"UIBold",pos.x,pos.y,team.GetColor(ent:Team()),TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1,color_black)
		end
	end
end
hook.Add("HUDPaint","SykESP",SykESP)



