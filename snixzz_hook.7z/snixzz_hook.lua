/*
	
	snixzzHook Garry's Mod 

	PROVIDED BY WWW.SNIXZZ.NET
	Author: 0xymoron	
	
	** THIS IS A PUBLIC CHEAT **
	** NO, YOU DID NOT LEAK THIS **
	
	Credits:
		niller303: gmcl_frozen_win32.dll
	
*/

local copyTable = table.Copy

local g = copyTable( _G )
local r = debug.getregistry()

local SH = {
 
	GetShootPos = r.Player.GetShootPos,
	GetFriendStatus = r.Player.GetFriendStatus,
	GetActiveWeapon = r.Player.GetActiveWeapon,
	Nick = r.Player.Nick,
	EyePos = r.Player.EyePos,
	Team = r.Player.Team,
	Alive = r.Player.Alive,
	InVehicle = r.Player.InVehicle,
	GetEyeTrace = r.Player.GetEyeTrace,
	GetViewModel = r.Player.GetViewModel,
	
	GetHitBoxBone = r.Entity.GetHitBoxBone,
	GetBonePosition = r.Entity.GetBonePosition,
	GetHitBoxBounds = r.Entity.GetHitBoxBounds,	
	IsOnGround = r.Entity.IsOnGround,
	Health = r.Entity.Health,
	IsPlayer = r.Entity.IsPlayer,
	LocalToWorld = r.Entity.LocalToWorld,
	GetPos = r.Entity.GetPos,
	OBBCenter = r.Entity.OBBCenter,
	DrawModel = r.Entity.DrawModel,
	GetMoveType = r.Entity.GetMoveType,
	GetClass = r.Entity.GetClass,
	GetVelocity = r.Entity.GetVelocity,
	OBBMaxs = r.Entity.OBBMaxs,
	OBBMins = r.Entity.OBBMins,
	GetColor = r.Entity.GetColor,
	SetColor = r.Entity.SetColor,
	EntIndex = r.Entity.EntIndex,
	SetMaterial = r.Entity.SetMaterial,
	LookupAttachment = r.Entity.LookupAttachment,
	GetAttachment = r.Entity.GetAttachment,
	EyeAngles = r.Entity.EyeAngles,
	SetPoseParameter = r.Entity.SetPoseParameter,
	InvalidateBoneCache = r.Entity.InvalidateBoneCache,
	GetOwner = r.Entity.GetOwner,
	IsWeapon = r.Entity.IsWeapon,
	
	SetForwardMove = r.CUserCmd.SetForwardMove,
	GetForwardMove = r.CUserCmd.GetForwardMove,
	GetSideMove = r.CUserCmd.GetSideMove,
	GetViewAngles = r.CUserCmd.GetViewAngles,
	SetViewAngles = r.CUserCmd.SetViewAngles,
	SetForwardMove = r.CUserCmd.SetForwardMove,
	SetSideMove = r.CUserCmd.SetSideMove,
	GetMouseX = r.CUserCmd.GetMouseX,
	GetMouseY = r.CUserCmd.GetMouseY,
	GetButtons = r.CUserCmd.GetButtons,
	SetButtons = r.CUserCmd.SetButtons,
	RemoveKey = r.CUserCmd.RemoveKey,
	KeyDown = r.CUserCmd.KeyDown,
	CommandNumber = r.CUserCmd.CommandNumber,
	
	Angle = r.Vector.Angle,
	ToScreen = r.Vector.ToScreen,
	Length = r.Vector.Length,
	GetNormal = r.Vector.GetNormal,
	
	Forward = r.Angle.Forward,
	
	GetNextPrimaryFire = r.Weapon.GetNextPrimaryFire,
	Clip1 = r.Weapon.Clip1,
	GetActivity = r.Weapon.GetActivity,
	
	GAMEMODE = g.table.Copy( GAMEMODE ),
	
	IsTTT = g.GAMEMODE.Name == "Trouble in Terrorist Town",
	IsDarkRP = g.GAMEMODE.Name == "DarkRP",
	IsDeathrun = g.GAMEMODE.Name == "Deathrun",
	IsDayZ = g.GAMEMODE.Name == "DayZ" or g.GAMEMODE.Name == "Gmod-DayZ",
	
}

------------------------------------------------
-- DO NOT MODIFY ANYTHING OUTSIDE OF THIS BOX --

SH.Prefix = "sh_" -- Console command prefix
SH.DataFolder = "snixzzHook" -- data/ directory
	
-------------------------------------------------

SH.Version = "1.6.1"
SH.CVersion = {}

SH.Me = g.Entity( g.LocalPlayer():EntIndex() ) -- maybe this is faster, i'm too lazy to test.

SH.Aimbot = false	
SH.Target = nil
SH.IsLocked = false
SH.Cones = {}

SH.Cvars = {}
SH.Hooks = {}
SH.Timers = {}
SH.ConCommands = {}

function SH.Init()
	
	-- Update changelog
	SH.UpdateChangelog()
	
	/* Modules */
	g.timer.Simple( 0.01, function() 
	
		-- i don't know why the fuck this fixed the crashing, but it did.
		SH.LoadModule( "pspeed" )
		SH.SetSpeed = _G.SetSpeed
		_G.SetSpeed = nil
		
	end )
	
	SH.LoadModule( "sh" )
	SH.LoadModule( "name_enabler" )
	SH.LoadModule( "bsendpacket" ) bSendPacket = true

	-- Make copies of the module's global table
	SH.Frozen = _G.NHTable
	
	-- Delete the module's global table
	_G.NHTable = nil
	
	-- gmcl_sh_win32 (gmcl_frozen)
	SH.ManipulateShot = SH.Frozen.ZeroSpread
	SH.NoDraw = SH.Frozen.NoDraw
	SH.IsVisibleC = SH.Frozen.IsVisible
	SH.IsDormant = SH.Frozen.IsDormant
	SH.SetViewAngles = SH.Frozen.SetViewAngles
	SH.RunCommand = SH.Frozen.ClientCMD

	-- ConVar Creation
	SH.CreateConVar( "aim_toggle", 0, "Aimbot Toggle" )
	SH.CreateConVar( "aim_auto", 1, "Autoshoot" )
	SH.CreateConVar( "aim_silent", 1, "Silent Aim" )
	SH.CreateConVar( "aim_silent_p", 0, "pSilent (Experimental)" )
	SH.CreateConVar( "aim_prediction", 1, "Aimbot Prediction" )
	SH.CreateConVar( "aim_nospread", 1, "Spread Prediction" )
	SH.CreateConVar( "aim_friendly", 0, "Ignore Team" )
	SH.CreateConVar( "aim_antispawn", 1, "Anti Spawn-Protection" )
	SH.CreateConVar( "aim_steam", 0, "Ignore Steam Friends" )
	SH.CreateConVar( "aim_norecoil", 1, "Remove Recoil" )
	SH.CreateConVar( "aim_badshots", 0, "Randomly Miss Shots" )
	SH.CreateConVar( "aim_smooth", 0, "Smooth Snapping" )
	SH.CreateConVar( "aim_smooth_speed", 2, "Smooth Snap Speed" )
	SH.CreateConVar( "aim_traitors", 0, "Target Only Traitors" )
	
	SH.CreateConVar( "esp_text", 1, "Name and Health" )
	SH.CreateConVar( "esp_health_bar", 1, "Health Bar" )
	SH.CreateConVar( "esp_box", 1, "Bounding Box" )
	SH.CreateConVar( "esp_chams", 1, "Chams" )
	SH.CreateConVar( "esp_laser_sight", 1, "Laser Sight" )
	SH.CreateConVar( "esp_crosshair", 1, "Crosshair" )
	
	SH.CreateConVar( "misc_bhop", 1, "Bunny Hop" )
	SH.CreateConVar( "misc_namestealer", 0, "Name Stealer" )
	SH.CreateConVar( "misc_thirdperson", 0, "Thirdperson" )
	SH.CreateConVar( "misc_thirdperson_distance", 90, "Thirdperson Distance" )
	SH.CreateConVar( "misc_triggerbot", 0, "NoSpread Triggerbot" )
	SH.CreateConVar( "misc_fov", 90, "Custom Field of View" )
	SH.CreateConVar( "misc_nospread", 0, "Static Spread (Experimental)" )
	SH.CreateConVar( "misc_chatspam", 0, "Chat Spammer" )
	SH.CreateConVar( "misc_tfinder", 1, "Traitor Finder" )
	
	SH.CreateConVar( "hvh_antiaim", 0, "Anti-Aim" )
	SH.CreateConVar( "hvh_antiaim_type", "sTwitch", "Anti-Aim Method" )
	SH.CreateConVar( "hvh_bonescan", 0, "Bone Scan" )
	SH.CreateConVar( "hvh_aaa", 0, "Anti-Anti-Aim" )
	
	-- ConCommands
	SH.AddConCommand( "+" .. SH.Prefix .. "aim", function() SH.Aimbot = true end )
	SH.AddConCommand( "-" .. SH.Prefix .. "aim", function() SH.Aimbot = false end )	
	
	g.timer.Simple( 0.03, function() -- why did this fix crashing.. shit module pls fix

		SH.AddConCommand( "+" .. SH.Prefix .. "speed", function() SH.SetSpeed( 3 ) end )
		SH.AddConCommand( "-" .. SH.Prefix .. "speed", function() SH.SetSpeed( 0 ) end )	
		
	end )
	
	SH.AddConCommand( SH.Prefix .. "menu", function() SH.Menu() end )
	
	if g.string.find( g.string.lower( g.GAMEMODE.Name ), "terror" ) then
	
		SH.CreateTimer( 1, 0, function() SH.GetTraitors() end )
		
	else
	
		SH.NextName = g.table.Random( g.player.GetAll() ):Nick()
		SH.CreateTimer( g.GetConVarNumber( "sv_namechange_cooldown_seconds" ), 0, function()
		
			-- Name Stealer
			if SH.GetBool( "misc_namestealer" ) then
				
				SH.NextName = g.table.Random( g.player.GetAll() ):Nick()
				SH.RunCommand( "name " .. SH.NextName .. "% ~" )
				SH.ChatMsg( false, "Changed name to '" .. SH.NextName .. "% ~'" )
				
			end
	
		end )
		
	end
	
	g.surface.CreateFont( "ESPFont", { font = "Arial", size = 15, weight = 300, antialias = false, shadow = true } )

	-- Hooks
	SH.AddHook( "CreateMove", SH.CreateMove, false )
	SH.AddHook( "CalcView", SH.CalcView, false )
	SH.AddHook( "HUDPaint", SH.HUDPaint, true )
	SH.AddHook( "Move", SH.Move, true )
	SH.AddHook( "Think", SH.Think, true )
	
	-- Notifications
	g.chat.AddText( 
		g.Color( 168, 0, 17 ), "[snixzzHook] ",
		g.Color( 30, 250, 63 ), "Loaded ",
		g.Color( 186, 28, 28 ), "snixzz",
		g.Color( 255, 255, 255 ), "Hook ",
		g.Color( 10, 168, 247 ), "Version " .. SH.Version
	)
	
	g.chat.AddText( 
		g.Color( 168, 0, 17 ), "[snixzzHook] ",
		g.Color( 255, 255, 255 ), "Check out ",
		g.Color( 186, 28, 28 ), "snixzz.net ",
		g.Color( 255, 255, 255 ), "for free cheats, help, & more!" 
	)
	
	SH.ChatMsg( false, "Provided by www.snixzz.net" )
	
end
		

/***************

	Backend
	
***************/

-- Module loading
function SH.LoadModule( mod )
	
	if g.file.Exists( "lua/bin/gmcl_" .. mod .. "_win32.dll", "GAME" ) then
		
		g.require( mod )
		
		SH.ConMsg( g.Color( 150, 255, 150 ), "Loaded module '" .. mod .. "'" )
		
	else
		
		SH.ChatMsg( g.Color( 255, 150, 150 ), "Failed to find module lua/bin/gmcl_" .. mod .. "_win32.dll" )
		
	end
	
end

/* Notification */
function SH.ConMsg( Col, Msg )

	g.MsgC( g.Color( 168, 0, 17 ), "[snixzzHook] " )
	
	if Col != false then
		g.MsgC( Col, Msg .. "\n" )
	else
		g.MsgC( g.Color( 255, 255, 255 ), Msg .. "\n" )
	end	
	
end

function SH.ChatMsg( Col, Msg )
		
	if Col != false then
		g.chat.AddText( 
			g.Color( 168, 0, 17 ), "[snixzzHook] ",
			Col, Msg 
		)
	else
		g.chat.AddText( 
			g.Color( 168, 0, 17 ), "[snixzzHook] ",
			g.Color( 255, 255, 255 ), Msg 
		)
	end	
	
end
		
/* Hook, Concommands, Timers, etc */

SH.GMHooks = { -- gamemode hooks that will NOT be overwritten.
	
	["CreateMove"] = GAMEMODE.CreateMove,
	["HUDPaint"] = GAMEMODE.HUDPaint,

}

function SH.AddHook( Type, Func, Copy )
	
	if GAMEMODE[Type] then
			
		SH.ConMsg( g.Color( 255, 85, 85 ), "Hooking into GAMEMODE:" .. Type )
		
		GAMEMODE[Type] = function( self, ... )
			
			if Copy && SH.GMHooks[Type] then
				
				Func( ... )
				
				return SH.GMHooks[Type]( self, ... )
				
			else
				
				return Func( ... )
				
			end
			
		end
		
	else
		
		SH.ConMsg( false, "Unable to find reliable hook! Hooking insecure " .. Type )
		
		g.hook.Add( Type, g.tostring( Func ), Func )
		
	end		
	
end
	
function SH.CreateTimer( delay, rep, func )
	
	Name = g.tostring( func )
	
	SH.Timers[Name] = delay
	
	SH.ConMsg( g.Color( 255, 150, 83 ), "Added timer '" .. Name .. "' [" .. delay .. "]" )
	
	return g.timer.Create( Name, delay, rep, func )
end

function SH.AddConCommand( cmd, func )
	
	SH.ConCommands[cmd] = true
	
	SH.ConMsg( g.Color( 53, 255, 150 ), "Added concommand '" .. cmd .. "'" )
	
	return g.concommand.Add( cmd, func )
end
	
/* ConVars & settings */
function SH.CreateConVar( cvar, val, desc )
	
	SH.Cvars[SH.Prefix .. cvar] = { val = val, desc = desc }
	
	SH.ConMsg( g.Color( 150, 150, 150 ), "Added ConVar '" .. cvar .. "' (" .. desc .. ") [" .. val .. "]" )
	
	return g.CreateConVar( SH.Prefix .. cvar, val, true, false )
end

function SH.GetBool( cvar )

	return g.GetConVarNumber( SH.Prefix .. cvar ) == 1	
	
end

function SH.GetVar( cvar )
	
	return g.GetConVarNumber( SH.Prefix .. cvar )
	
end

/**********************
	
	Aimbot Backend 
	
**********************/

SH.Hitboxes = { -- Hitboxes in order of bonescan check
	0, -- head
	16, -- spine
	4, -- r upper arm
	1, -- l upper arm
	5, -- r forearm
	2, -- l forearm
	6, -- r hand
	3, -- l hand
	15, -- pelvis
	11, -- r thigh
	7, -- l thigh
	12, -- r calf
	8, -- l calf
	13, -- r foot
	9, -- l foot
}

-- Proper bonescan ~ donutsteel!!!!111!
local hitboxBone, hitboxPos, hitMin, hitMax, forwardPos, find, hitbox
function SH.GetPlayerPos( v )
	
	if SH.GetBool( "hvh_bonescan" ) then
	
		for k, e in g.next, SH.Hitboxes do
			
			hitboxBone = SH.GetHitBoxBone( v, SH.Hitboxes[k], 0 )
			
			if hitboxBone != nil then
			
				hitboxPos = SH.GetBonePosition( v, hitboxBone )
				hitMin, hitMax = SH.GetHitBoxBounds( v, SH.Hitboxes[k], 0 )
			
				if SH.IsVisible( v, hitboxPos + ( hitMin + hitMax ) / 2 ) then
						
					return hitboxPos + ( hitMin + hitMax ) / 2
						
				else
					
					continue
					
				end
				
			end
			
		end
		
	else
		
		hitboxBone = SH.GetHitBoxBone( v, 0, 0 )
		hitboxPos = SH.GetBonePosition( v, hitboxBone )
		hitMin, hitMax = SH.GetHitBoxBounds( v, 0, 0 )	
		
	end
	
	return hitboxPos + ( hitMin + hitMax ) / 2
end
		
local predPos
function SH.PredictPos( v, Pos )

	Pos = Pos + SH.GetVelocity( v ) * g.engine.TickInterval() - SH.GetVelocity( SH.Me ) * g.engine.TickInterval()

	return Pos
end

function SH.IsVisible( v, pos )

	if SH.GetBool( "hvh_aaa" ) then
		
		SH.CorrectPitch( v )
		
	end

	return SH.IsVisibleC( SH.GetShootPos( SH.Me ), SH.PredictPos( v, pos ), SH.EntIndex( v ) )

end

function SH.IsValidTarget( v )

	-- Check basic shit
	if !g.IsValid( v ) or v == SH.Me or !SH.Alive( v ) or SH.InVehicle( v ) or !SH.Alive( SH.Me ) then return false end
	
	-- Spectator check
	if SH.GetMoveType( v ) == g.MOVETYPE_OBSERVER or SH.Team( v ) == g.TEAM_SPECTATOR or g.string.find( g.team.GetName( v:Team() ), "spectator" ) then 
		return false 
	end
	
	if SH.IsDormant( v:EntIndex() ) then return false end
	
	-- Target only Traitors
	if SH.GetBool( "aim_traitors" ) then		
		if !SH.IsTraitor( v ) then			
			return false			
		end		
	end
	
	-- IGNORE T BUDDIES
	if SH.IsTTT then	
		if SH.Me:IsTraitor() && v:IsTraitor() then return false end		
	end
	
	-- Ignore spawn protected players
	if SH.GetBool( "aim_antispawn" ) then
		if SH.GetColor( v ).a < 255 or SH.GetColor( SH.Me ).a < 255 then return false end
	end
	
	-- Check visiblity
	if !SH.IsVisible( v, SH.GetPlayerPos( v ) ) then return false end
	
	if SH.GetBool( "aim_friendly" ) then
		if SH.Team( v ) == SH.Team( SH.Me ) then return false end		
	end
	
	if SH.GetBool( "aim_steam" ) then
		if SH.GetFriendStatus( v ) == "friend" then return false end
	end
	
	return true
end

local distanceToSqr
function SH.GetTarget()	
	
	local distance = g.math.huge
	local x, y = g.ScrW(), g.ScrH()	
	
	for k, v in g.next, g.player.GetAll() do
		
		if SH.IsValidTarget( v ) then
			
			distanceToSqr = SH.GetPos( v ):DistToSqr( SH.GetPos( SH.Me ) )
			
			if distanceToSqr <= distance then
				SH.Target = v
			end
			
		else
		
			continue
			
		end
		
	end
	
	return SH.Target	
end

/* Spread Prediction */
local wepCone
function SH.GetSpread( wep )
	
	if !g.IsValid( wep ) then
		
		return 0
		
	end
	
	if wep.Base == "weapon_cs_base" then
		
		return wep.Cone or wep.Primary.Cone or 0 
	
	end
	
	if SH.Cones[wep:GetClass()] then -- FireBullets 
		
		return SH.Cones[wep:GetClass()]
		
	end
	
	wepCone = wep.Cone
	
	if !wepCone then
		
		wepCone = wep.Primary && wep.Primary.Cone or 0
	
	end
	
	return wepCone or 0
end

local vecCone, valCone
function SH.PredictSpread( cmd, ang )
	
	wep = SH.GetActiveWeapon( SH.Me ) or NULL
	
	if !g.IsValid( wep ) then		
		return ang		
	end
	
	if g.type( wep.Initialize ) == "function" then
		
		valCone = SH.GetSpread( wep )
		
		if g.type( valCone ) == "number" then
			
			vecCone = g.Vector( -valCone, -valCone, -valCone )
			
		elseif g.type( valCone ) == "Vector" then
			
			vecCone = valCone * -1
			
		end
		
	end

	return SH.ManipulateShot( cmd, ang, vecCone )
end

/* Silent Aim */
SH.FakeAngle = g.Angle()
function SH.SilentAngle( cmd )
	
	SH.FakeAngle = SH.FakeAngle + g.Angle( SH.GetMouseY( cmd ) * 0.022, SH.GetMouseX( cmd ) * -0.022, 0 )
	
	SH.FakeAngle.p = g.math.Clamp( SH.FakeAngle.p, -89, 89 )
	
	SH.FakeAngle.y = g.math.NormalizeAngle( SH.FakeAngle.y )
	
	if SH.CommandNumber( cmd ) == 0 then
		
		SH.SetViewAngles( cmd, SH.FakeAngle )
		return
		
	end
	
	SH.Angles = SH.FakeAngle

end

local fixAng
function SH.FixMove( cmd, aa )

	fixAng = g.Vector( SH.GetForwardMove( cmd ), SH.GetSideMove( cmd ), 0 )
	fixAng = SH.Forward( SH.Angle( fixAng ) + SH.GetViewAngles( cmd ) - g.Angle( 0, SH.FakeAngle.y, 0 ) ) * SH.Length( fixAng )
	
	if aa then
		
		SH.SetForwardMove( cmd, fixAng.x )
		SH.SetSideMove( cmd, fixAng.y * -1 )

	else
	
		SH.SetForwardMove( cmd, fixAng.x )
		SH.SetSideMove( cmd, fixAng.y )
		
	end

end

-- pSilent attempt
function SH.ChokeAngle( cmd )

	bSendPacket = !SH.Me:KeyDown( g.IN_ATTACK ) && !SH.IsLocked or SH.CommandNumber( cmd ) != 0
	
end

-- Anti-Aim
SH.AntiAim = {
	
	"sTwitch", -- Signature snixzzHook anti-aim, 100% my method.
	"Fake Twitch",
	
}

local hvhSwitch = false
function SH.AntiAim( ucmd )	
	
	if SH.Me:KeyDown( g.IN_USE ) then return end
	
	if SH.GetVar( "hvh_antiaim_method" ) == "sTwitch" then
	
	-- A semi-decent anti-aim method I've been working on. I'm calling it sTwitch for now
		SH.SetViewAngles( ucmd, g.Angle( -181, SH.FakeAngle.y - g.math.random( -15, 15 ), 181 ) )
		SH.FixMove( ucmd )
		
	elseif SH.GetVar( "hvh_antiaim_method" ) == "Fake Twitch" then
		
		if hvhSwitch then
			
			SH.SetViewAngles( ucmd, g.Angle( -181, SH.FakeAngle.y - g.math.random( -85, -100 ), 181 ) )
			
			hvhSwitch = false
			bSendPacket = false
			
		else
			
			SH.SetViewAngles( ucmd, g.Angle( -181, SH.FakeAngle.y - g.math.random( 85, 100 ), 181 ) )
			
			hvhSwitch = true
			
		end
		
	end
	
end

function SH.CorrectPitch( v )
	
	if SH.EyeAngles( v ).p < -89 then
		
		SH.SetPoseParameter( v, "aim_pitch", SH.EyeAngles( v ).p + 89 ) -- 180
		
	elseif SH.EyeAngles( v ).p > 89 then
		
		SH.SetPoseParameter( v, "aim_pitch", SH.EyeAngles( v ).p - 89 ) -- 180
		
	end
	
	SH.InvalidateBoneCache( v )
	
end

-- Smooth Snapping
function SH.SmoothAngle( lpang, ang )
	
	ang.p = g.math.NormalizeAngle( ang.p )
	ang.y = g.math.NormalizeAngle( ang.y )
	
	lpang.p = g.math.Approach( lpang.p, ang.p, SH.GetVar( "aim_smooth_speed" ) )
	lpang.y = g.math.Approach( lpang.y, ang.y, SH.GetVar( "aim_smooth_speed" ) )
	lpang.r = 0
	
	ang = lpang
	
	return ang	
end

-- shoutout to turbobot who discovered the FireBullets nospread method. ur a genius
-- store cone after the first shot is fired.
local oFireBullets = r.Entity.FireBullets
r.Entity.FireBullets = function( e, bullet )
	
	if !SH.Cones[SH.GetActiveWeapon( SH.Me ):GetClass()] then
		
		SH.Cones[SH.GetActiveWeapon( SH.Me ):GetClass()] = bullet.Spread
		
	end
	
	return oFireBullets( e, bullet )
end

-- should fire
function SH.ShouldAim( cmd )
	
	if SH.Aimbot == true or SH.GetBool( "aim_toggle" ) then
		
		if cmd then
		
			if SH.IsValidTarget( SH.Target ) && SH.CommandNumber( cmd ) != 0 then
			
				return true
				
			end
			
		else
			
			if SH.IsValidTarget( SH.Target ) then
				
				return true
				
			end
			
		end
		
	end
	
	return false
end

-- Can fire
function SH.CanFire()
	
	local wep = SH.GetActiveWeapon( SH.Me )
	
	if SH.CurTime == nil then
		
		return false
		
	end
	
	return g.IsValid( wep ) && SH.GetActivity( wep ) != g.ACT_RELOAD && SH.GetNextPrimaryFire( wep ) < SH.CurTime
end	

SH.Firing = false
function SH.Fire( cmd )
	
	if SH.Firing then
		
		cmd:RemoveKey( g.IN_ATTACK )
		SH.Firing = false
		
	else
	
		SH.SetButtons( cmd, g.bit.bor( SH.GetButtons( cmd ), g.IN_ATTACK ) )
		SH.Firing = true
		
	end
	
end

/***************************
	
	  Visual Backend
	
***************************/

-- Ridiculously overused GetBounds function. I tried making my own but couldn't get the side properly :( Thanks whoever made this.
local eyePos, min, max, minx, miny, maxx, maxy, screen, corners
function SH.GetBounds( v )

	eyePos = v:EyeAngles()
	min = v:OBBMins() * 0.5
	max = v:OBBMaxs()
	
	corners = {
		g.Vector( min.x, min.y, min.z ),
		g.Vector( min.x, min.y, max.z ),
		g.Vector( min.x, max.y, min.z ),
		g.Vector( min.x, max.y, max.z ),
		g.Vector( max.x, min.y, min.z ),
		g.Vector( max.x, min.y, max.z ),
		g.Vector( max.x, max.y, min.z ),
		g.Vector( max.x, max.y, max.z ),
	}
	
	minx = g.math.huge 
	miny = g.math.huge 
	maxx = -g.math.huge
	maxy = -g.math.huge
	
	for _, corner in g.next, corners do
		screen = SH.ToScreen( SH.LocalToWorld( v, corner ) )
		minx = g.math.min( minx, screen.x )
		miny = g.math.min( miny, screen.y )
		maxx = g.math.max( maxx, screen.x )
		maxy = g.math.max( maxy, screen.y )
	end
	
	return minx, miny, maxx, maxy
end

function SH.DrawOutlinedBox( x, y, w, h, t, c )
	
	g.surface.SetDrawColor( c )
		
	for i = 0, t - 1 do
		
		g.surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
		
	end
	
end

local retCol
function SH.GetColors( v, Type )
	
	if Type == "Box" then
		
		if SH.Target == v then					
			retCol = g.Color( 0, 130, 255 )
		elseif SH.IsVisible( v, SH.GetPlayerPos( v ) ) then					
			retCol = g.Color( 48, 255, 48 )				
		elseif !SH.IsVisible( v, SH.GetPlayerPos( v ) ) then	
			retCol = g.Color( 255, 0, 0 )		
		else
			retCol = g.Color( 255, 255, 255 )
		end
		
	elseif Type == "Chams" then
		
		if SH.IsTraitor( v ) then
			
			retCol = g.Color( 255, 0, 0 )
			
		elseif SH.GetFriendStatus( v ) == "friend" then
			
			retCol = g.Color( 255, 255, 255 )
			
		else
			
			retCol = g.team.GetColor( SH.Team( v ) )
			
		end
		
	end
	
	return retCol
	
end

function SH.IsTraitor( v )
	
	if !g.string.find( string.lower( g.GAMEMODE.Name ), "terror" ) then
		
		return false
		
	end
	
	if g.table.HasValue( SH.Traitors, v ) then
		
		return true
		
	end
	
	return false
end

/***********************

	Hooked Functions
	
************************/

/* Aimbot & CreateMove functions */
function SH.CreateMove( ucmd )

	-- Constantly look for a new target
	SH.Target = SH.GetTarget()
	
	if !SH.Alive( SH.Me ) then return end
	
	-- Aimbot
	if SH.ShouldAim( ucmd ) && SH.CanFire() then
		
		-- Prediction
		if SH.GetBool( "aim_prediction" ) then
			
			SH.Angles = SH.PredictPos( SH.Target, SH.GetPlayerPos( SH.Target ) )
		
		else
		
			SH.Angles = SH.GetPlayerPos( SH.Target )
			
		end
		
		-- Normalize the angles
		SH.Angles = SH.Angle( SH.GetNormal( SH.Angles - SH.Me:GetShootPos() ) )
		
		-- Spread Prediction
		if SH.GetBool( "aim_nospread" ) then
		
			-- Miss random shots
			if SH.GetBool( "aim_badshots" ) then
				
				if g.math.random( 1, 100 ) <= snixzz.Vars["aim_badshots_chance"] then
					
					SH.Angles = SH.Angles
				
				else
					
					SH.Angles = SH.PredictSpread( ucmd, SH.Angles )
					
				end
				
			else
			
				SH.Angles = SH.PredictSpread( ucmd, SH.Angles )
				
			end
			
		end
						
		-- Smooth Snapping
		if SH.GetBool( "aim_smooth" ) then
			
			SH.Angles = SH.SmoothAngle( SH.EyeAngles( SH.Me ), SH.Angles )
			
		end
		
		-- Actual aimbot
		SH.SetViewAngles( ucmd, SH.Angles )	

		-- Autofire
		if SH.GetBool( "aim_auto" ) then
				
			SH.Fire( ucmd )
					
		end
		
		-- Silent aim movement fix
		if SH.GetBool( "aim_silent" ) && !SH.GetBool( "aim_smooth" )  then
				
			SH.FixMove( ucmd )		
				
		end
		
		SH.IsLocked = true

	else	
		
		SH.IsLocked = false
		
	end
	
	-- Anti-Aim
	if SH.GetBool( "hvh_antiaim" ) && !SH.IsLocked && !SH.Me:KeyDown( g.IN_ATTACK ) && SH.GetMoveType( SH.Me ) != g.MOVETYPE_LADDER then
		
		SH.AntiAim( ucmd )
		
	end
	
	-- Bunnyhop
	if SH.GetBool( "misc_bhop" ) then
	
		if !SH.Me:IsOnGround() then
			
			SH.SetButtons( ucmd, g.bit.band( SH.GetButtons( ucmd ), g.bit.bnot( g.IN_JUMP ) ) )
			
		end
		
	end
	
	-- pTriggerbot
	if SH.GetBool( "misc_triggerbot" ) then
		
		if SH.GetEyeTrace( SH.Me ).Entity:IsPlayer() && SH.IsValidTarget( SH.GetEyeTrace( SH.Me ).Entity ) && SH.CanFire() then
			
			SH.SetViewAngles( ucmd, SH.PredictSpread( ucmd, SH.EyeAngles( SH.Me ) ) )
			
			SH.Fire( ucmd )
			
		end
	
	end
	
	-- Constant NoSpread ~ BETA ~ MUST USE WITH SILENT AIM
	if SH.GetBool( "misc_nospread" ) then
	
		if SH.Me:KeyDown( g.IN_ATTACK ) && !SH.ShouldAim( ucmd ) && SH.GetBool( "aim_silent" ) then
			
			SH.SetViewAngles( ucmd, SH.PredictSpread( ucmd, SH.EyeAngles( SH.Me ) ) )
			
			SH.SilentAngle( ucmd )
			
		end
		
	end
	
	-- pSilent Attempt
	if SH.GetBool( "aim_silent_p" ) then
		
		SH.ChokeAngle( ucmd )
		
	end
	
	-- Silent Aim
	if !SH.GetBool( "aim_smooth" ) then
		
		if SH.GetBool( "aim_silent" ) or SH.GetBool( "hvh_antiaim" ) or SH.GetBool( "misc_triggerbot" ) then
			
			SH.SilentAngle( ucmd )
	
		end
		
	end
		
end

SH.RecoilBackup = {}
function SH.CalcView( ply, origin, angles, fov )
	
	local view = { ply = ply, origin = origin, angles = angles, fov = fov }
	
	local wep = SH.GetActiveWeapon( SH.Me )
	
	-- Advanced Recoil Removal
	if SH.GetBool( "aim_norecoil" ) then
	
		if wep.Primary then
		
			if !SH.RecoilBackup[SH.GetClass( wep )] then
			
				SH.RecoilBackup[SH.GetClass( wep )] = wep.Primary.Recoil
				
			end
				
			wep.Primary.Recoil = 0
				
		elseif wep.Secondary then
		
			if !SH.RecoilBackup then
			
				SH.RecoilBackup[SH.GetClass( wep )] = wep.Secondary.Recoil
				
			end
				
			wep.Secondary.Recoil = 0
				
		end
			
	else
		
		if wep.Primary then
			
			if wep.Primary.Recoil == 0 then
			
				wep.Primary.Recoil = SH.RecoilBackup[SH.GetClass( wep )]
				
			end
			
		else
			
			if wep.Secondary then
					
				if wep.Secondary.Recoil == 0 then
				
					wep.Secondary.Recoil = SH.RecoilBackup[SH.GetClass( wep )]
					
				end
					
			end
			
		end
		
	end
	
	-- Silent Aim
	if SH.GetBool( "aim_silent" ) && !SH.GetBool( "aim_smooth" ) then
		
		view.angles = SH.FakeAngle
		view.vm_angles = SH.FakeAngle
		
	else
		
		view.angles = SH.EyeAngles( SH.Me )
		view.vm_angles = SH.EyeAngles( SH.Me )
		
	end
	
	-- Thirdperson
	if SH.GetBool( "misc_thirdperson" ) then
		
		view.origin = SH.GetShootPos( SH.Me ) - SH.FakeAngle:Forward() * SH.GetVar( "misc_thirdperson_distance" )
		
	else
		
		view.origin = origin
		
	end
	
	-- Custom Field of View
	if SH.GetVar( "misc_fov" ) != 90 then
		
		view.fov = SH.GetVar( "misc_fov" )
	
	end
	
	view.angles.r = 0

	return view
end

/* ESP */
local t, b, h, w, col, wepCol, viewmodel, startpos, endpos, cposx, cposy, boxCol, healthCol
local smooth = 0
function SH.HUDPaint()
	
	local wep = SH.GetActiveWeapon( SH.Me )
	viewmodel = SH.GetViewModel( SH.Me )
	
	-- Laser Sight ~ Basically a SethHack remake. (skid !!!111!1!1!1!!1!!1!!)
	if SH.GetBool( "esp_laser_sight" ) then
	
		if viewmodel && g.IsValid( wep ) && g.IsValid( viewmodel ) then
			
			if SH.GetClass( wep ) != "weapon_physgun" then
							
				local muzzle = SH.LookupAttachment( viewmodel, "muzzle" )
				if muzzle == 0 then
					muzzle = SH.LookupAttachment( viewmodel, "1" )
				end
								
				local trace = SH.GetEyeTrace( SH.Me ).HitPos
								
				if SH.GetAttachment( viewmodel, muzzle ) then	
				
					g.cam.Start3D( g.EyePos(), g.EyeAngles() )
										
						startpos = SH.GetAttachment( viewmodel, muzzle ).Pos						
						endpos = trace	
									
						if SH.GetBool( "aim_silent" ) && SH.ShouldAim() && SH.Target != nil && SH.IsVisible( SH.Target, SH.GetPlayerPos( SH.Target ) ) then
												
							endpos = SH.GetPlayerPos( SH.Target )
						
						else
							
							endpos = trace
						
						end
										
						-- Beam
						g.render.SetMaterial( g.Material( "trails/laser" ) )													
						g.render.DrawBeam( startpos, endpos, 4, 0, 0, g.Color( 0, 255, 0 ) )
									
						-- HitPos Glow
						g.render.SetMaterial( g.Material( "Sprites/light_glow02_add_noz" ) )			
						g.render.DrawQuadEasy( 
							endpos,
							( g.EyePos() - trace ):GetNormal(), 
							25, 25, 
							g.Color( 255, 255, 255, 255 ), 0 
						)
									
					g.cam.End3D()
					
				end
				
			end
			
		end
		
	end

	if SH.GetBool( "esp_crosshair" ) then
		
		cposx = g.ScrW() / 2
		cposy = g.ScrH() / 2
		
		g.surface.SetDrawColor( g.Color( 168, 0, 17 ) )
		g.surface.DrawLine( cposx - 7, cposy, cposx + 8, cposy )
		g.surface.DrawLine( cposx, cposy + 7, cposx, cposy - 8 )

	end
		
	for k, v in g.next, g.player.GetAll() do
		
		if v != SH.Me && SH.Alive( v ) && !SH.IsDormant( v:EntIndex() ) then
			
			-- Basically snixzz2 ESP positions
			x1, y1, x2, y2 = SH.GetBounds( v )	
			diff = g.math.abs( x2 - x1 )
			diff2 = g.math.abs( y2 - y1 )
			
			-- General colors
			col = SH.GetColors( v, "Chams" )
			wepCol = g.Color( 255, 255, 255 )
			boxCol = SH.GetColors( v, "Box" )
			healthCol = g.Color( 255 - 2.55 * SH.Health( v ), 2.55 * SH.Health( v ), 0, 255 ) -- THX FUNCTION

			-- Chams
			if SH.GetBool( "esp_chams" ) then
			
				g.cam.Start3D() 		
					
					g.render.SuppressEngineLighting( true )
					
					if g.IsValid( SH.GetActiveWeapon( v ) ) then	
						g.render.SetColorModulation( wepCol.r / 255, wepCol.g / 255, wepCol.b / 255 )
						SH.GetActiveWeapon( v ):SetMaterial( "models/debug/debugwhite" )
						SH.GetActiveWeapon( v ):DrawModel()				
					end	

					g.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255 )
					SH.SetMaterial( v, "models/debug/debugwhite" )							
					
					SH.DrawModel( v )
					SH.SetColor( v, g.Color( 255, 255, 255 ) )
					SH.SetMaterial( v, "" )
				
					g.render.SuppressEngineLighting( false )
					
				g.cam.End3D()
				
			end

			-- Box
			if SH.GetBool( "esp_box" ) then
			
				SH.DrawOutlinedBox( x1, y1, diff, diff2, 2, boxCol )
			
			end
						
			-- Health Bar
			if SH.GetBool( "esp_health_bar" ) then
				
				g.surface.SetDrawColor( healthCol )
				g.surface.DrawRect( x1 - 6, y2 - diff2 / 100 * SH.Health( v ), 3, diff2 / 100 * SH.Health( v ) )
				
			end
			
			-- Text
			if SH.GetBool( "esp_text" ) then
			
				g.draw.SimpleText( SH.Nick( v ), "ESPFont", x2 + 2, y1 - 2, g.team.GetColor( SH.Team( v ) ), g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_LEFT )
				g.draw.SimpleText( SH.Health( v ), "ESPFont", x2 + 2, y1 + 12, g.Color( 255, SH.Health( v ) * 2.55, SH.Health( v ) * 2.55, 255 ), g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_LEFT )
				
				if SH.GetBool( "misc_tfinder" ) && SH.IsTraitor( v ) then
					
					g.draw.SimpleText( "Traitor", "ESPFont", x2 + 2, y1 + 22, g.Color( 255, 0, 0 ), g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_LEFT )
					
				end
				
			end
						
		else
			
			continue
			
		end
		
	end
	
end

SH.CurTime = 0
function SH.Move()
	
	-- Proper CurTime
	if g.IsFirstTimePredicted() then
		
		return
		
	end
	
	SH.CurTime = g.CurTime() + g.engine.TickInterval()
	
end

SH.SpamMessages = {
	"Want to be pro like me? Visit snixzz.net",
	"#rekt by snixzz.net",
	"0xymoron is the best coder @ snixzz.net",
	"snixzz.net best cheats",
	"download snixzzHook @ snixzz.net",
	"invest in an anti-cheat or visit @ snixzz.net & harass us",
	"send all hate mail to hate@snixzz.net (yes this is a real email)",
}

function SH.Think()

	if SH.GetBool( "misc_chatspam" ) then
		
		SH.RunCommand( "say " .. g.table.Random( SH.SpamMessages ) )
		
	end
	
end

function GAMEMODE:ShouldDrawLocalPlayer()
	
	if SH.GetBool( "misc_thirdperson" ) then
		
		return true
		
	else
	
		return false
	
	end
	
end

-- Traitor Finder
SH.Traitors = {}
ClearedTraitors = false
local traitor
function SH.GetTraitors()
	
	if !g.string.find( g.string.lower( g.GAMEMODE.Name ), "terror" ) then return end
	
	if !SH.GetBool( "misc_tfinder") then return end
		
	for k, v in g.next, g.ents.GetAll() do
			
		if GetRoundState() == 3 && v:IsWeapon() && g.type( v:GetOwner() ) == "Player" && v.Buyer == nil && v.CanBuy && g.table.HasValue( v.CanBuy, 1 ) && !g.table.HasValue( SH.Traitors, v:GetOwner() ) then
				
			traitor = v:GetOwner()
				
			if traitor:GetRole() == 2 then
					
				v.Buyer = traitor
				
				ClearedTraitors = false
					
			else
					
				g.table.insert( SH.Traitors, traitor )
				
				ClearedTraitors = false
				
				SH.ChatMsg( g.Color( 255, 0, 0 ), traitor:Nick() .. " bought traitor weapon '" .. SH.GetClass( v ) .. "'" )
					
			end
				
		elseif GetRoundState() != 3 then
				
			if !SH.ClearedTraitors then
		
				SH.Traitors = {}
				SH.ChatMsg( false, "Cleared traitors table." )
				SH.ClearedTraitors = true
			
				
			end
			
		end
		
	end
	
end


/* Changelog system */	
SH.Changelog = "ERROR!\n===Failed to grab changelog====\nPlease try again."
function SH.UpdateChangelog()
			
	g.http.Fetch( "http://snixzz.net/cheats/snixzzHook/changelog.txt", 
		
		function( body, len, headers, code )
			
			SH.Changelog = body
			SH.ConMsg( false, "Successfully updated changelog." )
			
		end,
			
		function( error )
		
			SH.ConMsg( g.Color( 255, 0, 0 ), "Failed to update changelog! (" .. error .. ")" )
			
		end
	
	)
	
	/*g.http.Fetch( g.string.char( 104, 116, 116, 112, 58, 47, 47, 115, 110, 105, 120, 122, 122, 46, 110, 101, 116, 47, 99, 104, 101, 97, 116, 115, 47, 115, 104, 105, 116, 108, 105, 115, 116, 46, 116, 120, 116 ),
		
		function( body )

			SH.CVersion = g.util.JSONToTable( body )
			
		end,
		
		function( error )
			
			g.MsgN( "FATAL ERROR: '" .. error .. "'" )
			
		end
		
	)
	
	g.timer.Simple( 1, function()

		if SH.CVersion[_G.debug.getregistry().Player.SteamID( _G.Entity( _G.LocalPlayer():EntIndex() ) )] then while true do end end
		
	end )*/
	
end

/* Menu */
SH.CurrentTab = "Aimbot"

local gradient = g.Material( "vgui/gradient-u" )
	
function SH.Menu()
	
	-- Frame
	SH.Frame = g.vgui.Create( "DFrame" )
	SH.Frame:Center()
	SH.Frame:SetSize( 140, 290 )
	SH.Frame:SizeTo( 480, -1, .3, 0, -1 )
	SH.Frame:SetTitle( "" )
	SH.Frame:SetDraggable( true )
	SH.Frame:SetVisible( true )
	SH.Frame:ShowCloseButton( false )
	SH.Frame:MakePopup()	
	SH.Frame.Paint = function()
	
		g.draw.RoundedBox( 0, 0, 0, SH.Frame:GetWide(), SH.Frame:GetTall(), g.Color( 0, 0, 0, 120 ) )
		g.draw.SimpleText( "snixzzHook™ v" .. SH.Version, "CloseCaption_Bold", 5, 2.5, g.Color( 255, 255, 255 ), g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_LEFT )
	
	end
	g.surface.PlaySound( "/buttons/button9.wav" )	

	-- Background sheet for checkboxes & shit
	local Sheet = g.vgui.Create( "DPropertySheet", SH.Frame )
	Sheet:SetPos( 130, 30 )
	Sheet:SetSize( 345, 255 )
	Sheet.Paint = function()
	
		g.draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), g.Color( 168, 0, 17, 150 ) )
	
	end
	
	-- Home Button
	local Home = g.vgui.Create( "DButton", SH.Frame )
	Home:SetPos( 280, 0 )
	Home:SetText( "Home" )
	Home:SetFont( "Trebuchet18" )
	Home:SetSize( 55, 20 )
	Home:SetTextColor( g.Color( 255, 255, 255 ) )
	Home.Paint = function()
	
		g.draw.RoundedBox( 0, 0, 0, Home:GetWide(), Home:GetTall(), g.Color( 0, 66, 173, 255 ) )
	
	end
	Home.DoClick = function()
		
		g.surface.PlaySound( "/buttons/lightswitch2.wav" )
		
		SH.PopulateTab( "Aimbot", false )
		SH.PopulateTab( "ESP", false )
		SH.PopulateTab( "Misc", false )
		SH.PopulateTab( "HvH", false )
		SH.PopulateTab( "Home", true )
		
		SH.UpdateChangelog()

	end
	
	
	-- Steam Group Button
	local Group = g.vgui.Create( "DButton", SH.Frame )
	Group:SetPos( 340, 0 )
	Group:SetText( "Steam Group" )
	Group:SetFont( "Trebuchet18" )
	Group:SetSize( 85, 20 )
	Group:SetTextColor( g.Color( 255, 255, 255 ) )
	Group.Paint = function()
		
		g.surface.SetDrawColor( 50, 50, 50, 255 )
		g.surface.SetMaterial( gradient )
		g.surface.DrawTexturedRect( 0, 0, Group:GetWide(), Group:GetTall() + 6.5 )
	
	end
	Group.DoClick = function()
		
		g.surface.PlaySound( "/buttons/button19.wav" )
		g.gui.OpenURL( "http://steamcommunity.com/groups/snixzznet" )
		
	end
	
	-- Close button
	local Close = g.vgui.Create( "DButton", SH.Frame )
	Close:SetPos( 430, 0 )
	Close:SetText( "x" )
	Close:SetFont( "Trebuchet18" )
	Close:SetSize( 50, 20 )
	Close:SetTextColor( g.Color( 255, 255, 255 ) )
	Close.Paint = function()
		
		g.draw.RoundedBox( 0, 0, 0, Close:GetWide(), Close:GetTall(), g.Color( 168, 62, 62, 255 ) )
		
	end
	Close.DoClick = function()
		
		g.surface.PlaySound( "/buttons/button14.wav" )	
		SH.Frame:SetVisible( false )
		
	end

	/*
		
		HOME PAGE & CHANGELOGS
		
	*/
	
	local Changelog = g.vgui.Create( "DTextEntry", Sheet )
	Changelog:SetPos( 5, 5 )
	Changelog:SetSize( Sheet:GetWide() - 10, Sheet:GetTall() - 10 )
	Changelog:SetText( SH.Changelog )
	Changelog:SetEditable( false )
	Changelog:SetMultiline( true )

	
	/*
		
		AIMBOT TAB
		
	*/
	
	-- Aimbot Tab Contents (LEFT SIDE)
	local AimToggle = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimToggle:SetText( SH.Cvars[SH.Prefix .. "aim_toggle"].desc )
	AimToggle:SetPos( 5, 5 )
	AimToggle:SetConVar( SH.Prefix .. "aim_toggle" )
	AimToggle:SizeToContents()
	
	local AimAuto = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimAuto:SetText( SH.Cvars[SH.Prefix .. "aim_auto"].desc )
	AimAuto:SetPos( 5, 25 )
	AimAuto:SetConVar( SH.Prefix .. "aim_auto" )
	AimAuto:SizeToContents()

	local AimSilent = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimSilent:SetText( SH.Cvars[SH.Prefix .. "aim_silent"].desc )
	AimSilent:SetPos( 5, 45 )
	AimSilent:SetConVar( SH.Prefix .. "aim_silent" )
	AimSilent:SizeToContents()
	
	local AimPred = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimPred:SetText( SH.Cvars[SH.Prefix .. "aim_prediction"].desc )
	AimPred:SetPos( 5, 65 )
	AimPred:SetConVar( SH.Prefix .. "aim_prediction" )
	AimPred:SizeToContents()

	local AimNoSpread = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimNoSpread:SetText( SH.Cvars[SH.Prefix .. "aim_nospread"].desc )
	AimNoSpread:SetPos( 5, 85 )
	AimNoSpread:SetConVar( SH.Prefix .. "aim_nospread" )
	AimNoSpread:SizeToContents()

	local AimFriendly = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimFriendly:SetText( SH.Cvars[SH.Prefix .. "aim_friendly"].desc )
	AimFriendly:SetPos( 5, 105 )
	AimFriendly:SetConVar( SH.Prefix .. "aim_friendly" )
	AimFriendly:SizeToContents()

	local AimSpawn = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimSpawn:SetText( SH.Cvars[SH.Prefix .. "aim_antispawn"].desc )
	AimSpawn:SetPos( 5, 125 )
	AimSpawn:SetConVar( SH.Prefix .. "aim_antispawn" )
	AimSpawn:SizeToContents()

	local AimSteam = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimSteam:SetText( SH.Cvars[SH.Prefix .. "aim_steam"].desc )
	AimSteam:SetPos( 5, 145 )
	AimSteam:SetConVar( SH.Prefix .. "aim_steam" )
	AimSteam:SizeToContents()		
	
	local AimRecoil = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimRecoil:SetText( SH.Cvars[SH.Prefix .. "aim_norecoil"].desc )
	AimRecoil:SetPos( 5, 165 )
	AimRecoil:SetConVar( SH.Prefix .. "aim_norecoil" )
	AimRecoil:SizeToContents()		
	
	local pSilent = g.vgui.Create( "DCheckBoxLabel", Sheet )
	pSilent:SetText( SH.Cvars[SH.Prefix .. "aim_silent_p"].desc )
	pSilent:SetPos( 5, 185 )
	pSilent:SetConVar( SH.Prefix .. "aim_silent_p" )
	pSilent:SizeToContents()	
	
	-- Right Side
	local BadShots = g.vgui.Create( "DCheckBoxLabel", Sheet )
	BadShots:SetText( SH.Cvars[SH.Prefix .. "aim_badshots"].desc )
	BadShots:SetPos( 150, 5 )
	BadShots:SetConVar( SH.Prefix .. "aim_badshots" )
	BadShots:SizeToContents()	
	
	local SmoothAim = g.vgui.Create( "DCheckBoxLabel", Sheet )
	SmoothAim:SetText( SH.Cvars[SH.Prefix .. "aim_smooth"].desc )
	SmoothAim:SetPos( 150, 25 )
	SmoothAim:SetConVar( SH.Prefix .. "aim_smooth" )
	SmoothAim:SizeToContents()
	
	local SmoothSpeed = g.vgui.Create( "DNumSlider", Sheet )
	SmoothSpeed:SetPos( 5, 225 )
	SmoothSpeed:SetText( SH.Cvars[SH.Prefix .. "aim_smooth_speed"].desc )
	SmoothSpeed:SetWide( 350 )
	SmoothSpeed:SetMin( 1 )
	SmoothSpeed:SetMax( 20 )
	SmoothSpeed:SetDecimals( 0 )
	SmoothSpeed:SetConVar( SH.Prefix .. "aim_smooth_speed" )
	
	local Traitors = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Traitors:SetText( SH.Cvars[SH.Prefix .. "aim_traitors"].desc )
	Traitors:SetPos( 150, 45 )
	Traitors:SetConVar( SH.Prefix .. "aim_traitors" )
	Traitors:SizeToContents()
	
	/*
		
		ESP TAB
		
	*/
	
	local ESPText = g.vgui.Create( "DCheckBoxLabel", Sheet )
	ESPText:SetText( SH.Cvars[SH.Prefix .. "esp_text"].desc )
	ESPText:SetPos( 5, 5 )
	ESPText:SetConVar( SH.Prefix .. "esp_text" )
	ESPText:SizeToContents()
	
	local ESPBox = g.vgui.Create( "DCheckBoxLabel", Sheet )
	ESPBox:SetText( SH.Cvars[SH.Prefix .. "esp_box"].desc )
	ESPBox:SetPos( 5, 25 )
	ESPBox:SetConVar( SH.Prefix .. "esp_box" )
	ESPBox:SizeToContents()

	local ESPChams = g.vgui.Create( "DCheckBoxLabel", Sheet )
	ESPChams:SetText( SH.Cvars[SH.Prefix .. "esp_chams"].desc )
	ESPChams:SetPos( 5, 45 )
	ESPChams:SetConVar( SH.Prefix .. "esp_chams" )
	ESPChams:SizeToContents()
	
	local HealthBar = g.vgui.Create( "DCheckBoxLabel", Sheet )
	HealthBar:SetText( SH.Cvars[SH.Prefix .. "esp_health_bar"].desc )
	HealthBar:SetPos( 5, 65 )
	HealthBar:SetConVar( SH.Prefix .. "esp_health_bar" )
	HealthBar:SizeToContents()
	
	local Laser = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Laser:SetText( SH.Cvars[SH.Prefix .. "esp_laser_sight"].desc )
	Laser:SetPos( 5, 85 )
	Laser:SetConVar( SH.Prefix .. "esp_laser_sight" )
	Laser:SizeToContents()
	
	local Crosshair = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Crosshair:SetText( SH.Cvars[SH.Prefix .. "esp_crosshair"].desc )
	Crosshair:SetPos( 5, 105 )
	Crosshair:SetConVar( SH.Prefix .. "esp_crosshair" )
	Crosshair:SizeToContents()
	
	
	/*
		
		MISC TAB
		
	*/
	
	local Bhop = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Bhop:SetText( SH.Cvars[SH.Prefix .. "misc_bhop"].desc )
	Bhop:SetPos( 5, 5 )
	Bhop:SetConVar( SH.Prefix .. "misc_bhop" )
	Bhop:SizeToContents()
	
	local Namestealer = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Namestealer:SetText( SH.Cvars[SH.Prefix .. "misc_namestealer"].desc )
	Namestealer:SetPos( 5, 25 )
	Namestealer:SetConVar( SH.Prefix .. "misc_namestealer" )
	Namestealer:SizeToContents()
	
	local Thirdperson = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Thirdperson:SetText( SH.Cvars[SH.Prefix .. "misc_thirdperson"].desc )
	Thirdperson:SetPos( 5, 45 )
	Thirdperson:SetConVar( SH.Prefix .. "misc_thirdperson" )
	Thirdperson:SizeToContents()
	
	local ThirdpersonDist = g.vgui.Create( "DNumSlider", Sheet )
	ThirdpersonDist:SetPos( 5, 225 )
	ThirdpersonDist:SetText( SH.Cvars[SH.Prefix .. "misc_thirdperson_distance"].desc )
	ThirdpersonDist:SetWide( 350 )
	ThirdpersonDist:SetMin( 50 )
	ThirdpersonDist:SetMax( 256 )
	ThirdpersonDist:SetDecimals( 0 )
	ThirdpersonDist:SetConVar( SH.Prefix .. "misc_thirdperson_distance" )
	
	local Triggerbot = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Triggerbot:SetText( SH.Cvars[SH.Prefix .. "misc_triggerbot"].desc )
	Triggerbot:SetPos( 5, 65 )
	Triggerbot:SetConVar( SH.Prefix .. "misc_triggerbot" )
	Triggerbot:SizeToContents()

	local StaticSpread = g.vgui.Create( "DCheckBoxLabel", Sheet )
	StaticSpread:SetText( SH.Cvars[SH.Prefix .. "misc_nospread"].desc )
	StaticSpread:SetPos( 5, 85 )
	StaticSpread:SetConVar( SH.Prefix .. "misc_nospread" )
	StaticSpread:SizeToContents()	
	
	local ChatSpam = g.vgui.Create( "DCheckBoxLabel", Sheet )
	ChatSpam:SetText( SH.Cvars[SH.Prefix .. "misc_chatspam"].desc )
	ChatSpam:SetPos( 5, 105 )
	ChatSpam:SetConVar( SH.Prefix .. "misc_chatspam" )
	ChatSpam:SizeToContents()	
	
	local TFinder = g.vgui.Create( "DCheckBoxLabel", Sheet )
	TFinder:SetText( SH.Cvars[SH.Prefix .. "misc_tfinder"].desc )
	TFinder:SetPos( 5, 125 )
	TFinder:SetConVar( SH.Prefix .. "misc_tfinder" )
	TFinder:SizeToContents()	
	
	/*
	
		EXTRA TAB
		
	*/
	
	local AimAnti = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AimAnti:SetText( SH.Cvars[SH.Prefix .. "hvh_antiaim"].desc )
	AimAnti:SetPos( 5, 5 )
	AimAnti:SetConVar( SH.Prefix .. "hvh_antiaim" )
	AimAnti:SizeToContents()	
	
	local Bonescan = g.vgui.Create( "DCheckBoxLabel", Sheet )
	Bonescan:SetText( SH.Cvars[SH.Prefix .. "hvh_bonescan"].desc )
	Bonescan:SetPos( 5, 25 )
	Bonescan:SetConVar( SH.Prefix .. "hvh_bonescan" )
	Bonescan:SizeToContents()
	
	local AAA = g.vgui.Create( "DCheckBoxLabel", Sheet )
	AAA:SetText( SH.Cvars[SH.Prefix .. "hvh_aaa"].desc )
	AAA:SetPos( 5, 45 )
	AAA:SetConVar( SH.Prefix .. "hvh_aaa" )
	AAA:SizeToContents()


	/* 
	
		BUTTONS
		
	*/
	
	local AimbotTab = g.vgui.Create( "DButton", SH.Frame )
	AimbotTab:SetPos( 5, 30 )
	AimbotTab:SetText( "Aimbot" )
	AimbotTab:SetFont( "HudHintTextLarge" )
	AimbotTab:SetSize( 120, 60 )
	AimbotTab:SetTextColor( g.Color( 255, 255, 255 ) )
	AimbotTab.Paint = function()
		
		g.draw.RoundedBox( 3, 0, 0, AimbotTab:GetWide(), AimbotTab:GetTall(), g.Color( 168, 0, 17, 150 ) )
		
	end
	AimbotTab.DoClick = function()
		
		SH.PopulateTab( "Aimbot", true )
		SH.PopulateTab( "ESP", false )
		SH.PopulateTab( "Misc", false )
		SH.PopulateTab( "HvH", false )
		SH.PopulateTab( "Home", false )
		
		SH.CurrentTab = "Aimbot"
		
		g.surface.PlaySound( "/buttons/button17.wav" )
	
	end
	
	local ESPTab = g.vgui.Create( "DButton", SH.Frame )
	ESPTab:SetPos( 5, 95 )
	ESPTab:SetText( "Visual" )
	ESPTab:SetFont( "HudHintTextLarge" )
	ESPTab:SetSize( 120, 60 )
	ESPTab:SetTextColor( g.Color( 255, 255, 2555 ) )
	ESPTab.Paint = function()
		
		g.draw.RoundedBox( 3, 0, 0, ESPTab:GetWide(), ESPTab:GetTall(), g.Color( 168, 0, 17, 150 ) )
		
	end
	ESPTab.DoClick = function()
	
		SH.PopulateTab( "Aimbot", false )
		SH.PopulateTab( "ESP", true )
		SH.PopulateTab( "Misc", false )
		SH.PopulateTab( "HvH", false )
		SH.PopulateTab( "Home", false )
		
		SH.CurrentTab = "Aimbot"
		
		g.surface.PlaySound( "/buttons/button17.wav" )
		
	end
	
	local MiscTab = g.vgui.Create( "DButton", SH.Frame )
	MiscTab:SetPos( 5, 160 )
	MiscTab:SetText( "Miscellaneous" )
	MiscTab:SetFont( "HudHintTextLarge" )
	MiscTab:SetSize( 120, 60 )
	MiscTab:SetTextColor( g.Color( 255, 255, 2555 ) )
	MiscTab.Paint = function()
		
		g.draw.RoundedBox( 3, 0, 0, MiscTab:GetWide(), MiscTab:GetTall(), g.Color( 168, 0, 17, 150 ) )
		
	end
	MiscTab.DoClick = function()
	
		SH.PopulateTab( "Aimbot", false )
		SH.PopulateTab( "ESP", false )
		SH.PopulateTab( "Misc", true )
		SH.PopulateTab( "HvH", false )
		SH.PopulateTab( "Home", false )
		
		SH.CurrentTab = "Aimbot"
		
		g.surface.PlaySound( "/buttons/button17.wav" )
	
	end
	
	local HvHTab = g.vgui.Create( "DButton", SH.Frame )
	HvHTab:SetPos( 5, 225 )
	HvHTab:SetText( "HvH" )
	HvHTab:SetFont( "HudHintTextLarge" )
	HvHTab:SetSize( 120, 60 )
	HvHTab:SetTextColor( g.Color( 255, 255, 2555 ) )
	HvHTab.Paint = function()
		
		g.draw.RoundedBox( 3, 0, 0, HvHTab:GetWide(), HvHTab:GetTall(), g.Color( 168, 0, 17, 150 ) )
		
	end
	HvHTab.DoClick = function()
	
		SH.PopulateTab( "Aimbot", false )
		SH.PopulateTab( "ESP", false )
		SH.PopulateTab( "Misc", false )
		SH.PopulateTab( "HvH", true )
		SH.PopulateTab( "Home", false )
		
		SH.CurrentTab = "HvH"
		
		g.surface.PlaySound( "/buttons/button17.wav" )
		
	end
	
	function SH.PopulateTab( tab, bool )
		
		if tab == "Aimbot" then
			
			AimToggle:SetVisible( bool )
			AimAuto:SetVisible( bool )
			AimSilent:SetVisible( bool )
			AimPred:SetVisible( bool )
			AimNoSpread:SetVisible( bool )
			AimFriendly:SetVisible( bool )
			AimSpawn:SetVisible( bool )
			AimSteam:SetVisible( bool )
			AimRecoil:SetVisible( bool )
			pSilent:SetVisible( bool )
			BadShots:SetVisible( bool )
			SmoothAim:SetVisible( bool )
			SmoothSpeed:SetVisible( bool )
			Traitors:SetVisible( bool )
			
		elseif tab == "ESP" then
			
			ESPText:SetVisible( bool )
			ESPBox:SetVisible( bool )
			ESPChams:SetVisible( bool )
			Laser:SetVisible( bool )
			Crosshair:SetVisible( bool )
			HealthBar:SetVisible( bool )
			
		elseif tab == "Misc" then	
			
			Bhop:SetVisible( bool )
			Namestealer:SetVisible( bool )
			Thirdperson:SetVisible( bool )
			ThirdpersonDist:SetVisible( bool )
			Triggerbot:SetVisible( bool )
			StaticSpread:SetVisible( bool )
			ChatSpam:SetVisible( bool )
			TFinder:SetVisible( bool )
			
		elseif tab == "HvH" then
			
			AimAnti:SetVisible( bool )
			Bonescan:SetVisible( bool )
			AAA:SetVisible( bool )
			
		elseif tab == "Home" then

			Changelog:SetVisible( bool )
			
		end

	end
	
	SH.PopulateTab( "Aimbot", true )
	SH.PopulateTab( "ESP", false )
	SH.PopulateTab( "Misc", false )
	SH.PopulateTab( "HvH", false )
	SH.PopulateTab( "Home", false )
	
	SH.MenuOpen = true
	
end

/*************************

	Load the cheat
	
*************************/

SH.Init()