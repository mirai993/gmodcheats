--[[
	lua/DarkCoders.lua
	[DarkCoding] SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Credits:
[DarkCoder] Coke_Is_Awesome
[DarkCoder] SimpleIsTheBet

DarkCoder For GarrysMod
Holy Shit this is maddness
--]]

if !(CLIENT) then return; end
print("DarkCoders v1.0 Loaded!");

TEAM_CONNECTING = 0;
TEAM_UNASSIGNED = 1001;
TEAM_SPECTATOR = 1002;

local DarkCode = {}
DarkCode.Version = "1.0.0"

local DCSV = _G.DC_SETCVAR;
local DCLR = _G.DC_LUARUN;

_G.DC_LUARUN, _G.DC_SETCVAR = nil;

require('cvar3')

local g = table.Copy(_G);
local r = table.Copy(_R);
local d = table.Copy(_G);

g.DC_SETCVAR = dcsv;
g.DC_LUARUN = dclr;

local me = nil;
local g_ents = {};
local g_players = {};

local Text = chat.AddText;
local DUSHDB = 
{
"STEAM_0:1:49986466",
"STEAM_0:1:60333045"
}

if !table.HasValue(DUSHDB, LocalPlayer():SteamID()) then
	chat.AddText(
		Color(255,0,255,255), "[Error] ",
		Color(255,0,0,0), "Unknown User. Aborting..." )
		surface.PlaySound("buttons/button18.wav") 
	return 
end


-- Aimbot

-- ESP
local EspEnabled    = CreateClientConVar( "DC_ESP_Enabled", "1", true, false )
local EspName       = CreateClientConVar( "DC_ESP_Name", "1", true, false )
local EspHealth     = CreateClientConVar( "DC_ESP_Health", "1", true, false )
local EspWeapon     = CreateClientConVar( "DC_ESP_Weapon", "1", true, false )
local EspBox		= CreateClientConVar( "DC_ESP_Box", "1", true, false )
local EspNpc        = CreateClientConVar( "DC_ESP_NPC", "0", true, false )
local EspEntity     = CreateClientConVar( "DC_ESP_Entity", "0", true, false )
local EspPlayer     = CreateClientConVar( "DC_ESP_Player", "1", true, false )
local EspPos        = CreateClientConVar( "DC_ESP_Pos", "0", true, false )
local Chams 		= CreateClientConVar( "DC_ESP_Chams", "0", true, false )
local CMaterial 	= CreateClientConVar( "DC_ESP_Chams_Material", "Solid", true, false )

-- Misc
local Bhop 			= CreateClientConVar( "DC_Misc_Bhop", "1", true, false )
local Recoil		= CreateClientConVar( "DC_Misc_NoRecoil", "1", true, false )
local ChatSpam		= CreateClientConVar( "DC_Misc_ChatSpam", "0", true, false )
local ChatSpamM		= CreateClientConVar( "DC_Misc_ChatSpamMessage", "DarkCoders - The Best Coders In The World", true, false )
local RPGod			= CreateClientConVar( "DC_Misc_RPGod", "1", true, false )
local Flashlight	= CreateClientConVar( "DC_Misc_Flashlight", "0", true , false )

-- Distance Check
function IsCloseEnough(ent)
        local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
        if( dist <= GetConVarNumber("DC_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
                return true
        end
        return false  
end

function DarkCode:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]     = 1
}      
local mat      
if GetConVarString("DC_ESP_Chams_Material") == "Solid" then
        mat = CreateMaterial( "darkcode_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("DC_ESP_Chams_Material") == "Wireframe" then
        mat = CreateMaterial( "darkcode_wire", "Wireframe", BaseInfo )
end
   return mat
end

function Chams()
local mat = DarkCode:CreateMaterial()
        if( GetConVarNumber( "DC_ESP_Chams" ) == 1 ) then
                for k,v in pairs(player.GetAll()) do
                        local TCol = team.GetColor(v:Team())
                        if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
                        //Players
                        cam.Start3D(EyePos(),EyeAngles())
                        render.SuppressEngineLighting( true )
                        render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
                        render.MaterialOverride( mat )
                        v:DrawModel()
                        render.SuppressEngineLighting( false )
                        render.SetColorModulation(1,1,1)
                        render.MaterialOverride( )
                        v:DrawModel()
                        cam.End3D()
                        end
                end
        end
end
hook.Add('PostDrawHUD', 'Chamz', Chams)

function Misc()
if( GetConVarNumber( "DC_Misc_Bhop" ) == 1 ) then
	if ( input.IsKeyDown(KEY_SPACE) ) then
		if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump")
			timer.Create("Bhop", 0.01, 0 ,function() RunConsoleCommand("-Jump") end)
		end
	end 
end


if( GetConVarNumber( "DC_Misc_NoRecoil" ) == 1 ) then
	if IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
		LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
		LocalPlayer():GetActiveWeapon().Recoil = 0
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
	end
	elseif IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
		LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
		LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
end 

if( GetConVarNumber( "DC_Misc_ChatSpam" ) == 1 ) then
	LocalPlayer():ConCommand("say DarkCoders - The best coders in the world!")
end

if( GetConVarNumber( "DC_Misc_RPGod" ) == 1 ) then
	if LocalPlayer():Health() < 100 then
		LocalPlayer():ConCommand("say /buyhealth" );
	end
end

if( GetConVarNumber( "DC_Misc_Flashlight" ) == 1 ) then
	RunConsoleCommand( "impulse", "100" )
	end
end
hook.Add("Think", "MiscFeatures", Misc)

function PrintAdmins(ply, cmd)
 print ("Printing Online Admins!")
        if string.lower(cmd) == "printadmins" then
        end
        local a = 0
        local Admins = ""
        local Superadmins = ""
        local ASSUsers = ""
        for k,v in pairs(player.GetAll()) do
                if v:IsAdmin() and not v:IsSuperAdmin() then
                        Admins = ", " .. v:Nick() .. Admins
                        a = a + 1
                elseif v:IsSuperAdmin() then
                        Superadmins = ", " .. v:Nick() .. Superadmins
                        a = a + 1
                end
 
                if ASS_Initialized ~= nil and LevelToString ~= nil and LevelToString(v:GetNWInt("ASS_isAdmin")) ~= "Guest" then -- Check if ASS is active on the server
                        ASSUsers = ", " .. v:Nick() .." = " .. LevelToString(v:GetNWInt("ASS_isAdmin"))  .. ASSUsers
                end
 
                local usergroup = string.lower(v:GetNetworkedString( "UserGroup" ))
                if usergroup ~= "user" and usergroup ~= "" and usergroup ~= "undefined" and not string.find(ASSUsers, v:Nick()) then
                        ASSUsers = ASSUsers ..", " .. v:Nick() .." = " .. usergroup
                end
        end
        if Admins ~= "" then
                print("Admins: " .. string.sub(Admins, 3))
        end
        if Superadmins ~= "" then
                timer.Simple(1.7, function() print("SuperAdmins: " .. string.sub(Superadmins, 3)) end)
        end
        if ASSUsers ~= "" then
                timer.Simple(1.8, function() print("ASS+ULX: " .. string.sub(ASSUsers, 3)) end)
        end
        if Admins == "" and Superadmins == "" then
                print( "[DC]: There are no admins on this server")
        end
end
concommand.Add("DC_PrintAdmins", PrintAdmins)

speedon = function()
GetConVar('sv_cheats'):SetValue(1)
GetConVar('host_timescale') :SetValue(6.0)
Text(Color(0, 0, 255), "[DC] ", green, "SpeedHack On!")
end
 
speedoff = function()
GetConVar('sv_cheats'):SetValue(1)
GetConVar('host_timescale') :SetValue(1.0)
Text(Color(0, 0, 255), "[DC] ", red, "SpeedHack Off!")
end
concommand.Add("DC_Speedhackon", speedon)
concommand.Add("DC_Speedhackoff", speedoff)
 
//Speeds
DC_SpeedHackSlowMo = function ()
GetConVar('sv_cheats'):SetValue(1)
GetConVar('host_timescale') :SetValue(0.1)
Text(Color(0, 0, 255), "[DC] ", green, "SpeedHack Set to Slow Mo!")
end
 
DC_SpeedHackMedium = function ()
GetConVar('sv_cheats'):SetValue(1)
GetConVar('host_timescale') :SetValue(4.0)
Text(Color(0, 0, 255), "[DC] ", green, "SpeedHack Set to Medium Speed!")
end
 
DC_SpeedHackFast = function ()
GetConVar('sv_cheats'):SetValue(1)
GetConVar('host_timescale') :SetValue(10.0)
Text(Color(0, 0, 255), "[DC] ", green, "SpeedHacks Set to Fast Speed!")
end
 
DC_SpeedHacksHyperSpeed = function ()
GetConVar('sv_cheats'):SetValue(1)
GetConVar ('host_timescale') :SetValue (18.0)
Text (Color(0, 0, 255), "[DC] ", green, "SpeedHacks Set to HyperSpeed!")
end
concommand.Add("DC_SpeedHackSlowMo", DC_SpeedHackSlowMo)
concommand.Add("DC_SpeedHackMedium", DC_SpeedHackMedium)
concommand.Add("DC_SpeedHackFast", DC_SpeedHackFast)
concommand.Add("DC_SpeedHackHyper", DC_SpeedHacksHyperSpeed)

