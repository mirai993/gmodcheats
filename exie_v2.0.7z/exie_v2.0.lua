local AllESPEntities = {"pot","shroom","weapon_rp_ak47","weapon_rp_uzi","weapon_rp_deagle" }
local draw = draw
local team = team
local player = player
local EXIEESP = CreateClientConVar( "EXIE_esp", "1", true)
local convar = CreateClientConVar( "EXIE_glow", "0", true )
local teamcolors = CreateClientConVar( "EXIE_teamcolors", "1", true )
local passes = CreateClientConVar( "EXIE_passes", "2", true )
local EXIEBhop = CreateClientConVar("EXIE_Bhop" ,"0", true )
local EXIEXhair = CreateClientConVar( "EXIE_xhair", "1", true )
local EXIENoRecoil = CreateClientConVar("EXIE_norecoil", "1", true )
local EXIETB = CreateClientConVar("EXIE_trigger" , "0" , true )
local EXIEHit = CreateClientConVar("EXIE_HitMarker","1",true )
local EXIETTT = CreateClientConVar("EXIE_TTT", "0" , true )
local EXIEAdmin = CreateClientConVar("EXIE_Esp_Admin","1", true )
local EXIERp = CreateClientConVar("EXIE_Rp_Esp", "0" , true )
local EXIEBh = CreateClientConVar("EXIE_Line", "0" ,true )
local EXIEAnti = CreateClientConVar("EXIE_AntiGag","1", true )
local EXIETraitor = CreateClientConVar("EXIE_traitor","1", true )
local EXIEWire = CreateClientConVar("EXIE_wireframe", "0" , true )
local EXIEChams = CreateClientConVar("EXIE_chams", "0" , true )
local EXIEespslider = CreateClientConVar("EXIE_espslider", "3000" , true )
local EXIEShowspec = CreateClientConVar("EXIE_showspec", "1", true )
local EXIEThirdPerson = CreateClientConVar("EXIE_thirdperson", "0", true )
local EXIESmoothAim = CreateClientConVar("EXIE_smooth_aim", "5" , true )

MsgN("EXIEBot Has loaded.")
function QuickESP()
 if EXIEESP:GetBool() then 
   for k,v in pairs(player.GetAll()) do
      if v!=LocalPlayer() and v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < GetConVarNumber( "EXIE_espslider" ) then
         local pos = v:GetPos() + Vector(0,0,70)
         pos = pos:ToScreen()
         local cwep = "None"
         if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then cwep = v:GetActiveWeapon():GetClass() end
         draw.SimpleTextOutlined( tostring(v:GetName()), "Default", pos.x, pos.y, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
         draw.SimpleTextOutlined( "W: " .. cwep .. " | Health: " .. v:Health(), "DefaultSmall", pos.x, pos.y+15,team.GetColor(v:Team()) , TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
              
	 end
   end
   for k,v in pairs(ents.GetAll()) do
      if v:IsValid() and table.HasValue(AllESPEntities, string.lower(v:GetClass())) then
         local pos = v:GetPos() + Vector(0,0,5)
         pos = pos:ToScreen()
         draw.SimpleTextOutlined( tostring(v:GetClass()), "Uibold", pos.x, pos.y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
      end
   end
 end
end
hook.Add("HUDPaint","Quick ESP" ,QuickESP)


------------------------------------------------------------------------
------------------------------------------------------------------------
------------------------------------------------------------------------


local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function DrawCrosshair()
    local w = ScrW() / 2;
    local h = ScrH() / 2;
    
    FillRGBA( w - 5, h, 11, 1, Color( 255, 0, 0, 255 ) );
    FillRGBA( w, h - 5, 1, 11, Color( 255, 0, 0, 255 ) );
end
function DrawXHair()
    if( EXIEXhair:GetInt() == 1 ) then
        DrawCrosshair();
    end
end
hook.Add( "HUDPaint", "DrawXHair", DrawXHair ); 



function Bunnyhop() 
if EXIEBhop:GetBool() then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump") 
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)

			end
		end
			end
				end
hook.Add("Think", "Funkybunny", Bunnyhop)	



hook.Add("CalcView", "NoRecoil", function()
        if EXIENoRecoil:GetInt() == 1 then
                local Wep = LocalPlayer():GetActiveWeapon()
                
                if (Wep.Primary) then Wep.Primary.Recoil = 0.0 end
                if (Wep.Secondary) then Wep.Secondary.Recoil = 0.0 end
        end
end)

WeaponTable = {"weapon_zm_pistol","weapon_ttt_wtester","weapon_zm_revolver","weapon_zm_molotov","weapon_zm_shotgun","weapon_ttt_m16","weapon_ttt_glock","weapon_zm_sledge","weapon_zm_rifle","weapon_zm_mac10"}

function TTTWeaponEsp() 
if EXIETTT:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(WeaponTable,v:GetClass()) and v:GetMoveType() != 0 then
Weaponscreenpot = v:GetPos():ToScreen()

draw.SimpleText(v:GetClass(),"DefaultSmall", Weaponscreenpot.x , Weaponscreenpot.y , Color(255,0,0,255) , TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
						end
					end
				end
					end
						end

hook.Add("HUDPaint","TTTWeaponShow",TTTWeaponEsp)


PrinterTable = {"reg_money_printer","money_printer","platinum_printer","golden_printer","zz_money_printer","money_printer_commercial","money_printer_industrial"}

function MpExtraSp()
if EXIERp:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(PrinterTable,v:GetClass()) then
local Pl = v:GetPos():ToScreen()
draw.SimpleText("Printer", "UiBold", Pl.x , Pl.y,Color(20,255,100,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	end

	hook.Add("HUDPaint","MoneyMoney",MpExtraSp)


	
function Trigger()
local Eye = LocalPlayer():GetEyeTrace().Entity
if EXIETB:GetBool() then
if On == 1 then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+Attack")
else
timer.Simple(0.50, function()
RunConsoleCommand("-Attack")
			end)
		end
	end
		end
end

hook.Add("Think", "Test", Trigger)
		

function Hitmarker() 
if EXIEHit:GetBool() then
local EyeEnt = LocalPlayer():GetEyeTrace().Entity
if EyeEnt:IsPlayer() then
if LocalPlayer():Health() > 0 then
if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
if LocalPlayer():GetActiveWeapon():Clip1() > 0 then

surface.SetDrawColor( 50, 205, 50 )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
					end
				end
			end
				end
					end
						end
						
hook.Add("HUDPaint","DisplayShittyHitmarker",Hitmarker)

function Barrelhax() 
if EXIEBh:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles())
render.SetMaterial( Material( "cable/physbeam" ) )
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(0, 100, 0 ))
cam.End3D()
			end
		end
	end
		end
 
 hook.Add("HUDPaint","Specline", Barrelhax)

function Antigag()
if EXIEAnti:GetBool() then
hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	end
end

TraitorTable = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio"}

function Traitorfind()
if EXIETraitor:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if table.HasValue(TraitorTable,v:GetClass()) then
local Pl = v:GetPos():ToScreen()
draw.SimpleText("Traitor", "UiBold", Pl.x , Pl.y,Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
		end
	end

	hook.Add("HUDPaint","TraitorTTT",Traitorfind)

function WeaponWire()
if EXIEWire:GetBool() then
for k,v in pairs(ents.GetAll()) do
if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < GetConVarNumber( "EXIE_espslider" ) then
if type(v) == "Weapon" or string.find(v:GetClass() , "weapon") then
render.SetColorModulation( 255, 0, 255 )
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
cam.StartMaterialOverride( mat )
v:DrawModel()
cam.IgnoreZ(false)
cam.StartMaterialOverride( 0 )
cam.End3D()
				end
			end
		end
	end
end

hook.Add("HUDPaint","wireframeweap",wire)
	
local mat = Material( "XE/EXIEwireframe")

function wire() 
if EXIEWire:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer and v:Alive() and v:IsPlayer() and v:Team() != TEAM_SPECTATOR ) then
if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < GetConVarNumber( "EXIE_espslider" ) then
local drawc = Color(0, 0, 0)
	drawc = team.GetColor(v:Team())
render.SetColorModulation( (drawc.r/255), (drawc.g/255), (drawc.b/255) )
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
cam.StartMaterialOverride( mat )
v:DrawModel()
cam.IgnoreZ(false)
cam.StartMaterialOverride( 0 )
cam.End3D()
					end
				end
			end
		end
	end
		
hook.Add("HUDPaint","wireframe",wire)

function Chams() 
if EXIEChams:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer and v:Alive() and v:IsPlayer() and v:Team() != TEAM_SPECTATOR ) then
  if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < GetConVarNumber( "EXIE_espslider" ) then
cam.Start3D( EyePos() , EyeAngles() ) 
cam.IgnoreZ(true)
v:DrawModel()
cam.IgnoreZ(false)
cam.End3D()
			end
		end
	end
		end
	end	
hook.Add("HUDPaint","Chamers",Chams)


---------------------------------------
---------------------------------------

local EXIE_Ignore = CreateClientConVar("EXIE_Aimbot_IgnoreSteam","0" , true , false)
local EXIE_Team = CreateClientConVar("EXIE_Aimbot_Friendlyfire","0",true ,false )
local EXIE_Admin = CreateClientConVar("EXIE_Aimbot_IgnoreAdmins","0",true ,false )
local EXIESmooth = CreateClientConVar("EXIE_SmoothAim_Enabled","0",true,false)
local EXIESmSpeed = CreateClientConVar("EXIE_Smooth_Speed" ,"5",true,false)
local AiBone = CreateClientConVar("EXIE_Aimbot_Offset", "0" ,true,false)

function Visible( cent )
trace1 = {}
trace1.start = LocalPlayer():GetShootPos()
trace1.endpos = cent:GetBonePosition(cent:LookupBone("ValveBiped.Bip01_Head1"))
trace1.mask = MASK_SHOT
trace1.filter = {cent , LocalPlayer()}
Main = util.TraceLine(trace1)
if !Main.Hit then return true end
end



function Valid(ent)
if (!ValidEntity(ent) || ent:Team() == TEAM_SPECTATOR || LocalPlayer() == ent) then return false end
if (!ent:Alive() || ent:Health() <= 0) then return false end
if (ent:Team() == LocalPlayer():Team() && GetConVarNumber("EXIE_Aimbot_Friendlyfire") != 1) then return false end
if (ent:IsPlayer() && GetConVarNumber( "EXIE_Aimbot_IgnoreSteam" ) == 1 && ent:GetFriendStatus() == "friend" ) then return false end
if (ent:IsPlayer() && ent:InVehicle() ) then return false end
if (ent:IsPlayer() && GetConVarNumber( "EXIE_Aimbot_IgnoreAdmins" ) && ent:IsAdmin() || ent:IsSuperAdmin()) then return false end
return true
 end

 
function Targetsys()
local target2 = { 0, 0 }
for k, v in ipairs( player.GetAll() ) do
if Visible(v) && Valid(v) then
local distance = v:GetPos() - LocalPlayer():GetPos()
distance = distance:Length()
distance = math.abs( distance )
if ( distance < target2[2] or target2[1] == 0 ) then

target2 = { v, distance }

		end
	end
end
		
return target2[1]

end
	

 

function Mano()
if Targetsys() != 0 then
return Targetsys()
	end
end

On = 0

concommand.Add("+EXIE_Aim",function()
On = 1
end)

concommand.Add("-EXIE_Aim",function()
On = 0
end)

function aim()
if On == 1 then
if Mano() then
Bone = Mano():GetBonePosition(Mano():LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,AiBone:GetInt())
Bone = Bone + Mano():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
local Angl = ((Bone - LocalPlayer():GetShootPos()):GetNormal()):Angle()

Angl.p = math.NormalizeAngle( Angl.p )
Angl.y = math.NormalizeAngle( Angl.y )
Angl.r = 0

if GetConVarNumber("EXIE_SmoothAim_Enabled") == 1 then

Angle1 = LocalPlayer():EyeAngles()
local Smooth1 = math.Approach(Angle1.p, Angl.p, GetConVarNumber("EXIE_Smooth_Speed"))
local Smooth2 = math.Approach(Angle1.y , Angl.y, GetConVarNumber("EXIE_Smooth_Speed"))
	
LocalPlayer():SetEyeAngles(Angle(Smooth1,Smooth2,0))

else

LocalPlayer():SetEyeAngles(Angle(Angl.p,Angl.y,0))
			end
		end
	end
		end
		
hook.Add("Think","Nacrot",aim)



    hook.Add("HUDPaint", "shit", function()
        if EXIEShowspec:GetBool() then
			local spectatePlayers = {}
            local x = 0
            for k,v in pairs(player.GetAll()) do
                    if v:GetObserverTarget() == LocalPlayer() then
                            table.insert(spectatePlayers, v:Name())
                    end
            end
            local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
            draw.RoundedBox(1, ScrW() - 350, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(255, 165, 0))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 310, ScrH() - ScrH() + 17, Color(255, 165, 0))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 310, ScrH() - ScrH() + 16, Color(0,0,0,150))
     
            for k, v in pairs(spectatePlayers) do
            draw.SimpleText(v, "ScoreboardText", ScrW() - 315, ScrH() - ScrH() + 35 + x, Color(0,0,0,150))
            x = x + 15
        end
    end
end)

hook.Add("HUDPaint", "Adminss", function()
			if EXIEAdmin:GetBool() then	
				local admins = {}
                local int = 0
                for k, v in ipairs( player.GetAll() ) do
                        if( v:IsAdmin() && v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (SA)" )
                        elseif( v:IsAdmin() && !v:IsSuperAdmin() ) then
                                table.insert( admins, v:Nick() .. " (A)" )
                        end
                end
                local txtsize = surface.GetTextSize( table.concat( admins ) ) / 3
                draw.RoundedBox( 1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + txtsize, Color( 255, 165, 0 ) )
                draw.SimpleText("Admins", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 16, Color( 0, 0, 0, 150 ) )
                for k, v in pairs( admins ) do
                        draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 35 + int, Color( 0, 0, 0, 150 ) )
                        int = int + 15
	          
				
			   end
        end
end)

RunConsoleCommand("EXIE_thirdperson_toggle")

function Toggle_View()
if EXIEThirdPerson:GetBool() then
		
		hook.Add( "CalcView", "ShoulderView", ShoulderView )
		hook.Add( "ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer", DrawLocalPlayer )
		
	else
	
		hook.Remove( "CalcView", "ShoulderView" )
		hook.Remove( "ShouldDrawLocalPlayer", "ShouldDrawLocalPlayer" )
	
	end
end

function ShoulderView( ply, pos, angles, fov )

	if EXIEThirdPerson:GetBool() then

		local view = {}
		view.origin = pos - ( angles:Forward() * 70 ) + ( angles:Right() * 0 ) + (angles:Up() * 5 )
		view.angles = angles
		view.fov = fov

		return view
	
	end

end


function DrawLocalPlayer( ply )

	if EXIEThirdPerson:GetBool() then

		return true

	else

		return false

	end

end

concommand.Add( "EXIE_thirdperson_toggle", Toggle_View )

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local oHTTP = table.Copy( http )

BaseFrame = vgui.Create("DFrame")
BaseFrame:SetSize( 330 , 200 )
BaseFrame:SetPos( ScrW() / 2 - 200 , ScrH() / 2 - 175 )
BaseFrame:SetTitle("EXIEBot")
BaseFrame:ShowCloseButton( false )
BaseFrame:SetVisible ( false )
BaseFrame:MakePopup()
 function BaseFrame:Paint()
                draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0 ,0 ,220 ) )
        end
 


local Sheet = vgui.Create("DPropertySheet" , BaseFrame)
Sheet:SetSize( 320 , 170 )
Sheet:SetPos( 5 , 25 )
function Sheet:Paint()
                draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 255, 165, 0 ) )
        end
local ThTab = vgui.Create("DLabel")
ThTab:SetParent( Sheet )
ThTab:SetPos( 0 , 10 )
ThTab:SetText("")
	
local FirstTab = vgui.Create("DLabel")
FirstTab:SetParent( Sheet )
FirstTab:SetPos( 0 , 10 )
FirstTab:SetText("")

local SecTab = vgui.Create("DLabel")
SecTab:SetParent( Sheet )
SecTab:SetPos( 0 , 10 )
SecTab:SetText("") 

local InfoTab = vgui.Create("DLabel")
InfoTab:SetParent( Sheet )
InfoTab:SetPos( 0 , 10 )
InfoTab:SetText("")




---- Time ----

local Time = vgui.Create("DLabel")
Time:SetParent( InfoTab )
Time:SetPos( 250 , 10 )
Time:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time:SetText(tostring( os.date("%I") ) )

local Time2 = vgui.Create("DLabel")
Time2:SetParent( InfoTab )
Time2:SetPos( 267 , 10 )
Time2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time2:SetText(tostring( os.date("%M") ) )

local Time3 = vgui.Create("DLabel")
Time3:SetParent( InfoTab )
Time3:SetPos( 263.5 , 10 )
Time3:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time3:SetText(":")

local Time4 = vgui.Create("DLabel")
Time4:SetParent( InfoTab )
Time4:SetPos( 280 , 10 )
Time4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Time4:SetText( tostring( os.date( "%p" ) ) )


// DLabels

local Label1 = vgui.Create("DLabel")
Label1:SetParent( FirstTab )
Label1:SetPos ( 30 , 10 ) 
Label1:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label1:SetText( "Esp" )
Label1:SizeToContents()

local Label2 = vgui.Create("DLabel")
Label2:SetParent( SecTab )
Label2:SetPos ( 30 , 10 ) 
Label2:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label2:SetText( "Other / Misc" )
Label2:SizeToContents()

local Label3 = vgui.Create("DLabel")
Label3:SetParent( InfoTab )
Label3:SetPos ( 30 , 10 ) 
Label3:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label3:SetText( "InfoTab" )
Label3:SizeToContents()

local Label4 = vgui.Create("DLabel")
Label4:SetParent( ThTab )
Label4:SetPos ( 30 , 10 ) 
Label4:SetTextColor( Color ( 0 , 0 , 0 , 255) )
Label4:SetText( "AimBot" )
Label4:SizeToContents()

// Regular Check Boxes

local Box1 = vgui.Create( "DCheckBoxLabel")
Box1:SetText( "ESP" )
Box1:SetConVar( "EXIE_esp" ) 
Box1:SetParent( FirstTab )
Box1:SetPos( 20 , 30 )
Box1:SetValue( 1 )
Box1:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box1:SizeToContents() 

local Box2 = vgui.Create( "DCheckBoxLabel")
Box2:SetText( "Glow" )
Box2:SetPos( 20 , 50 )
Box2:SetParent( FirstTab )
Box2:SetConVar( "EXIE_glow" ) 
Box2:SetValue( 0 )
Box2:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box2:SizeToContents() 

local Box4 = vgui.Create( "DCheckBoxLabel")
Box4:SetText( "Show Admins" )
Box4:SetConVar( "EXIE_esp_admin" ) 
Box4:SetValue( 1 )
Box4:SetPos( 20 , 70 )
Box4:SetParent( FirstTab )
Box4:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box4:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel")
Box5:SetText( "Xhair" )
Box5:SetConVar( "EXIE_xhair" ) 
Box5:SetValue( 0 )
Box5:SetPos( 20 , 90 )
Box5:SetParent( FirstTab )
Box5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box5:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel")
Box5:SetText( "TTT Weapons" )
Box5:SetConVar( "EXIE_ttt" ) 
Box5:SetValue( 0 )
Box5:SetPos( 20 , 110 )
Box5:SetParent( FirstTab )
Box5:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box5:SizeToContents() 

local Box12 = vgui.Create( "DCheckBoxLabel")
Box12:SetText( "MoneyPrinter ESP" )
Box12:SetConVar( "EXIE_Rp_Esp" ) 
Box12:SetParent( FirstTab )
Box12:SetPos( 150 , 30 )
Box12:SetValue( 0 )
Box12:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box12:SizeToContents() 

local Box8 = vgui.Create( "DCheckBoxLabel")
Box8:SetText( "Trigger Bot" )
Box8:SetConVar( "EXIE_trigger" ) 
Box8:SetValue( 0 )
Box8:SetPos( 20 , 110 )
Box8:SetParent( ThTab )
Box8:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box8:SizeToContents() 

local Box9 = vgui.Create( "DCheckBoxLabel")
Box9:SetText( "Bhop" )
Box9:SetConVar( "EXIE_bhop" ) 
Box9:SetValue( 0 )
Box9:SetPos( 20 , 30 )
Box9:SetParent( SecTab )
Box9:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box9:SizeToContents() 

local Box10 = vgui.Create( "DCheckBoxLabel")
Box10:SetText( "No Recoil" )
Box10:SetConVar( "EXIE_norecoil" )
Box10:SetPos( 150 , 30 )
Box10:SetParent( ThTab ) 
Box10:SetValue( 1 )
Box10:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box10:SizeToContents() 

local Box11 = vgui.Create( "DCheckBoxLabel")
Box11:SetText( "Hit Marker" )
Box11:SetConVar( "EXIE_hitmarker" ) 
Box11:SetPos( 20 , 50 )
Box11:SetParent( SecTab )
Box11:SetValue( 1 )
Box11:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box11:SizeToContents() 

local Box13 = vgui.Create( "DCheckBoxLabel")
Box13:SetText( "Laser Eyes" )
Box13:SetConVar( "EXIE_line" ) 
Box13:SetPos( 20 , 70 )
Box13:SetParent( SecTab )
Box13:SetValue( 0 )
Box13:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box13:SizeToContents() 

local Box14 = vgui.Create( "DCheckBoxLabel")
Box14:SetText( "ULXGag Bypass" )
Box14:SetConVar( "EXIE_AntiGag" ) 
Box14:SetPos( 150 , 30 )
Box14:SetParent( SecTab )
Box14:SetValue( 1 )
Box14:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box14:SizeToContents() 

local Box15 = vgui.Create( "DCheckBoxLabel")
Box15:SetText( "Traitor Finder" )
Box15:SetConVar( "EXIE_traitor" ) 
Box15:SetParent( FirstTab )
Box15:SetPos( 150 , 50 )
Box15:SetValue( 1 )
Box15:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box15:SizeToContents() 

local Box16 = vgui.Create( "DCheckBoxLabel")
Box16:SetText( "Wireframe" )
Box16:SetConVar( "EXIE_wireframe" ) 
Box16:SetParent( FirstTab )
Box16:SetPos( 150 , 70 )
Box16:SetValue( 0 )
Box16:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box16:SizeToContents() 

local Box17 = vgui.Create( "DCheckBoxLabel")
Box17:SetText( "Chams" )
Box17:SetConVar( "EXIE_chams" ) 
Box17:SetParent( FirstTab )
Box17:SetPos( 150 , 90 )
Box17:SetValue( 0 )
Box17:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box17:SizeToContents() 

local Box18 = vgui.Create( "DCheckBoxLabel")
Box18:SetText( "Show Spec" )
Box18:SetConVar( "EXIE_showspec" ) 
Box18:SetParent( SecTab )
Box18:SetPos( 150 , 50 )
Box18:SetValue( 1 )
Box18:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box18:SizeToContents()

local Box19 = vgui.Create( "DCheckBoxLabel")
Box19:SetText( "Third Person" )
Box19:SetConVar( "EXIE_thirdperson" ) 
Box19:SetParent( SecTab )
Box19:SetPos( 150 , 70 )
Box19:SetValue( 1 )
Box19:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box19:SizeToContents()

local NumSlider1 = vgui.Create( "DNumSlider" )
NumSlider1:SetPos( 150,105 )
NumSlider1:SetText( "" )
NumSlider1:SetParent( FirstTab )
NumSlider1:SetSize( 140, 90 ) 
NumSlider1:SetMin( 0 ) 
NumSlider1:SetMax( 10000 ) 
NumSlider1:SetDecimals( 0 ) 
NumSlider1:SetConVar( "EXIE_espslider" ) 

local Info3 = vgui.Create("DLabel")
Info3:SetParent( FirstTab )
Info3:SetPos( 160 , 105 )
Info3:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info3:SetSize( 200 , 20 )
Info3:SetText("Esp Distance")


local Box20 = vgui.Create( "DCheckBoxLabel")
Box20:SetText( "Chams" )
Box20:SetConVar( "EXIE_chams" ) 
Box20:SetParent( FirstTab )
Box20:SetPos( 150 , 90 )
Box20:SetValue( 0 )
Box20:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box20:SizeToContents() 

local Box21 = vgui.Create( "DCheckBoxLabel")
Box21:SetText( "Ignore SteamFriends" )
Box21:SetConVar( "EXIE_Aimbot_IgnoreSteam" ) 
Box21:SetParent( ThTab )
Box21:SetPos( 20 , 30 )
Box21:SetValue( 1 )
Box21:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box21:SizeToContents() 

local Box22 = vgui.Create( "DCheckBoxLabel")
Box22:SetText( "Friendly Fire" )
Box22:SetConVar( "EXIE_Aimbot_Friendlyfire" ) 
Box22:SetParent( ThTab )
Box22:SetPos( 20 , 50 )
Box22:SetValue( 1 )
Box22:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box22:SizeToContents() 

local Box23 = vgui.Create( "DCheckBoxLabel")
Box23:SetText( "Ignore Admins" )
Box23:SetConVar( "EXIE_Aimbot_IgnoreAdmins" ) 
Box23:SetParent( ThTab )
Box23:SetPos( 20 , 70 )
Box23:SetValue( 0 )
Box23:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box23:SizeToContents() 

local Box24 = vgui.Create( "DCheckBoxLabel")
Box24:SetText( "SmoothAim Enabled" )
Box24:SetConVar( "EXIE_SmoothAim_Enabled" ) 
Box24:SetParent( ThTab )
Box24:SetPos( 20 , 90 )
Box24:SetValue( 1 )
Box24:SetTextColor( Color(0 , 0 , 0 , 255 ) )
Box24:SizeToContents() 

local NumSlider2 = vgui.Create( "DNumSlider" )
NumSlider2:SetPos( 150,105 )
NumSlider2:SetText( "" )
NumSlider2:SetParent( ThTab )
NumSlider2:SetSize( 140, 90 ) 
NumSlider2:SetMin( 0 ) 
NumSlider2:SetMax( 5 ) 
NumSlider2:SetDecimals( 1 )                   
NumSlider2:SetConVar( "EXIE_Smooth_Speed" ) 

local Info4 = vgui.Create("DLabel")
Info4:SetParent( ThTab )
Info4:SetPos( 160 , 105 )
Info4:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info4:SetSize( 200 , 20 )
Info4:SetText("Smooth Speed")

local NumSlider3 = vgui.Create( "DNumSlider" )
NumSlider3:SetPos( 150,65 )
NumSlider3:SetText( "" )
NumSlider3:SetParent( ThTab )
NumSlider3:SetSize( 140, 90 ) 
NumSlider3:SetMin( -100 ) 
NumSlider3:SetMax( 100 ) 
NumSlider3:SetDecimals( 0 )                  
NumSlider3:SetConVar( "EXIE_Aimbot_Offset")

local Info5 = vgui.Create("DLabel")
Info5:SetParent( ThTab )
Info5:SetPos( 160 , 65 )
Info5:SetTextColor( Color ( 0 , 0 , 0 , 255 ) )
Info5:SetSize( 200 , 20 )
Info5:SetText("Aim Offest")

/// Info ///

local DImageAvatar1 = vgui.Create("AvatarImage")
DImageAvatar1:SetParent( InfoTab)
DImageAvatar1:SetPos( 30, 30 )
DImageAvatar1:SetSize( 32 , 32 )
DImageAvatar1:SetPlayer( LocalPlayer() )

local ilabel
        oHTTP.Get("http://dl.dropbox.com/u/11288952/Exieinfo.htm", "", function( data )
                ilabel = vgui.Create("DLabel")
                ilabel:SetPos( 90, 10 )
                ilabel:SetText( data )
                ilabel:SetParent( InfoTab)
				ilabel:SizeToContents()
                ilabel:SetTextColor( Color ( 0 , 0 , 0 , 255 ))
        end )



Sheet:AddSheet( "Home", InfoTab, "gui/silkicons/table_edit", false, false, "About EXIEBot" )
Sheet:AddSheet( "Aimbot", ThTab, "gui/silkicons/star", false, false, "Aimbot" )
Sheet:AddSheet( "ESP", FirstTab, "gui/silkicons/check_on", false, false, "ESP" )
Sheet:AddSheet( "Miscellaneous", SecTab, "gui/silkicons/wrench", false, false, "Miscellaneous" )


 
 function frame_open()
	BaseFrame:SetVisible(true)
end
 
 function frame_close()
	BaseFrame:SetVisible(false)
end

concommand.Add("-EXIE_menu",frame_close)
concommand.Add("+EXIE_menu",frame_open)


function MagnetoThrow()
-- Nice and easy, turn it slow 180 
	timer.Simple(.02,Turn)
	timer.Simple(.04,Turn)
	timer.Simple(.06,Turn)
	timer.Simple(.08,Turn)
	timer.Simple(.10,Turn)
	timer.Simple(.12,Turn)
	timer.Simple(.14,Turn)
	timer.Simple(.16,Turn)
	timer.Simple(.18,Turn)
	timer.Simple(.20,Turn)
	timer.Simple(.22,Turn)
	timer.Simple(.24,Turn)
	timer.Simple(.26,Turn)
	timer.Simple(.28,Turn)
	timer.Simple(.30,Turn)
	timer.Simple(.32,Turn)
	timer.Simple(.34,Turn)
	timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
	timer.Simple(.46,TurnBack)
-- And deliver the final blow by pressing right click
	timer.Simple(.7,function() RunConsoleCommand("+attack2") end)
	timer.Simple(.72,function() RunConsoleCommand("-attack2") end)
end

function Turn()
-- Turn function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
-- Turn 180 function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
end
-- Making it a console command
concommand.Add("ThrowMagneto",MagnetoThrow)