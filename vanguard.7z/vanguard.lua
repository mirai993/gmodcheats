jit.attach = function(ln) end
hook.Remove("Think", "gRust.AC.LuaCheck")
local VanGuard = {}
VanGuard.NewG = _G.table.Copy(_G)
local function Copy(t, lookup_table)
	if t == nil then return nil end
	local copy = {}
	VanGuard.NewG.setmetatable(copy, VanGuard.NewG.debug.getmetatable(t))
	for i, v in VanGuard.NewG.pairs(t) do
		if not VanGuard.NewG.istable(v) then
			copy[i] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[t] = copy
			if lookup_table[v] then
				copy[i] = lookup_table[v] -- we already copied this table. reuse the copy.
			else
				copy[i] = VanGuard.NewG.table.Copy(v, lookup_table) -- not yet copied. copy it.
			end
		end
	end
	return copy
end
 
VanGuard._G = Copy(_G)
VanGuard.print = VanGuard._G.print
VanGuard.include = VanGuard._G.include
VanGuard.print("VanGuard Loaded")
VanGuard.Receiver = {
	["playerkilledself"] = true,
	["undo_addundo"] = true,
	["playerkilledbyplayer"] = true,
	["receivedupe"] = true,
	["playerkilled"] = true,
	["deathnoticeevent"] = true,
	["npckillednpc"] = true,
	["undo_undone"] = true,
	["undo_fireundo"] = true,
	["copieddupe"] = true,
	["gmodsave"] = true,
	["playerkillednpc"] = true,
}
 
VanGuard.Block = {}
VanGuard.print("Net Receivers Loaded")
for k, v in VanGuard._G.pairs(net.Receivers) do
	if not VanGuard.Receiver[k] then
		VanGuard._G.print("Disabling: " .. k)
		VanGuard.Block[k] = true
	end
end
 
--[[
 
 
VanGuard.WhiteList = {}
VanGuard.print("Net Receivers UnLoaded")
local oldnetstart = VanGuard._G.net.Start
function VanGuard._G.net.Start(str, rel)
	for k, v in VanGuard._G.pairs(VanGuard.Block) do
		if k == str and not VanGuard.WhiteList[k] then
			VanGuard._G.print("Aborting:" .. k)
			VanGuard.Block[k] = true
			return VanGuard._G.net.Abort()
		end
	end
	return oldnetstart(str, rel)
end
]]
VanGuard.OpenFrame = function() end
VanGuard._G.concommand.Add("Vanguard_open", VanGuard.OpenFrame)
local mat = Material("models/shiny")
mat:SetFloat("$alpha", 0.5)
local function Valid(v)
	if not v or not v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me then return false end
	local trace = {
		mask = MASK_SHOT,
		endpos = v:GetPos(),
		start = VanGuard._G.LocalPlayer():EyePos(),
		filter = {VanGuard._G.LocalPlayer(), v},
	}
	return util.TraceLine(trace).Fraction == 1
end
 
VanGuard.FindPlayer = function()
	local closestPlayer = nil
	local closestDistance = math.huge
	for _, ply in ipairs(player.GetAll()) do
		local plyPos = LocalPlayer():GetPos()
		local distance = ply:GetPos():Distance(plyPos)
		if distance < closestDistance and LocalPlayer() ~= ply and ply:Alive() then
			closestPlayer = ply
			closestDistance = distance
		end
	end
	return closestPlayer, closestDistance
end
 
local function PredictBulletHit(shooter, targetPos, muzzlePos, muzzleVelocity)
	local distance = targetPos - muzzlePos
	local timeToTarget = distance:Length() / muzzleVelocity
	local targetVelocity = targetPos - shooter:GetPos()
	local predictedTargetPos = targetPos + targetVelocity * timeToTarget
	return predictedTargetPos
end
 
VanGuard._G.hook.Add("Think", "ThinkFat", function()
	local closestPlayer = VanGuard.FindPlayer()
	if IsValid(closestPlayer) and closestPlayer and Valid(closestPlayer) and LocalPlayer():KeyDown(IN_SPEED) then
		local bone = closestPlayer:GetBoneName(VanGuard._G.math.random(0, 5))
		local targethead = closestPlayer:LookupBone(bone)
		if bone == nil then bone = 1 end
		local targetheadpos = closestPlayer:GetBonePosition(targethead)
		if targetheadpos == nil then return end
		local predictedPos = PredictBulletHit(LocalPlayer(), targetheadpos, LocalPlayer():GetShootPos(), 2000)
		VanGuard._G.LocalPlayer():SetEyeAngles((predictedPos - VanGuard._G.LocalPlayer():GetShootPos()):Angle())
	end
end)
 
local whitelist = {
	["rust_largewoodbox"] = true,
	["rust_toolbox"] = true,
	["player"] = true,
	["rust_woodbox"] = true,
	["rust_militarycrate"] = true,
	["rust_ore"] = true,
	["rust_barrel"] = true,
	["rust_stash"] = true,
	["rust_hemp"] = true,
	["rust_recycler"] = true,
	["rust_woodencrate"] = true,
}
 
hook.Add("PreDrawHalos", "AddPropHalos", function()
	local AddEnts = {}
	for k, v in pairs(ents.GetAll()) do
		if not whitelist[v:GetClass()] then continue end
		AddEnts[k] = v
	end
 
	halo.Add(AddEnts, Color(0, 255, 0), 5, 5, 2, true, true)
end)
 
hook.Add("HUDPaint", "AddPropHalos2", function()
	local AddEntsb = {}
	for k, v in pairs(ents.GetAll()) do
		if not whitelist[v:GetClass()] then continue end
		AddEntsb[k] = v
	end
 
	for k, v in pairs(player.GetAll()) do
		if v ~= LocalPlayer() then
			v.ToScreem = v:GetPos():ToScreen()
			draw.DrawText(v:Nick() .. " IsAdmin: " .. tostring(v:GetUserGroup()), "DermaDefault", v.ToScreem.x, v.ToScreem.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		end
	end
end)
 
local function yupdate(e)
	net.Start("gRust.Inventory.Request")
	net.WriteEntity(e)
	net.SendToServer()
end