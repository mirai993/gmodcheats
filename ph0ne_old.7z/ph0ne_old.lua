--[[************************************************************************
		   _       ____
	____   |      |   /|                  ___|  
	|   |  |___   |  / |  ____   ____    [   |   ___
	|___|  |   |  | /  |  |   |   ___|   [___|  |___|
	|      |   |  |/___|  |   |  [___(_	  ___|  |___
	
	- Coded by ph0ne
	- Credits:
		+ C0BRA - hook.Call detour.
		+ fr1kin - gmcl_ph0nage, autowall, lots of good advice.
		+ noPE - Detouring, autowall.
		+ raBBish - More detour stuff.
		+ RabidToaster - Movement correction.
		+ s0beit - SE bypass, general help with Source engine stuff.
		+ stgn - FireBullets detour, Evolve gag bypass.
	- NOTE: If you're reading this, I apologize for the half-assed title.
**************************************************************************]]

if not CLIENT then return end
if DIX then _G.DIX = nil end -- We don't want to be easily detected.

--[[--------------------------------------------
	INITIALIZATION
--]]--------------------------------------------

local DIX     = {}
DIX.Settings  = {}
DIX.Commands  = {}
DIX.Cones     = { normal = {}, hl2 = {} }
DIX.ConVars   = {}
DIX.Detours   = { _R = {}, lua = {}, protected = { concommand.Run, hook.Call } }
DIX.Hooks     = {}
DIX.Menu	  = { tabs = {}, info = {} }
DIX.Meta	  = { lua = { _G, hook, concommand, debug, file }, _R = { "CUserCmd", "Entity", "Player", "ConVar", "Angle", "Vector" } }
DIX.World	  = { players = {} }

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local Vector 			  = Vector
local MsgN				  = MsgN
local ValidEntity 		  = ValidEntity
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local SetMaterialOverride = SetMaterialOverride
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand
local Material			  = Material

--[ RESET METATABLES ]--

function DIX:UnlockMeta()
	for i = 1, table.Count( DIX.Meta.lua ) do
		rawset( DIX.Meta.lua[i], "__metatable", false )
		rawset( DIX.Meta.lua[i], "__eq", true )
	end
end
DIX:UnlockMeta()

--[ BACKUPS ]--

DIX.Copy = {
	concommand	  = table.Copy( concommand ),
	debug		  = table.Copy( debug ),
	file		  = table.Copy( file ),
	hook		  = table.Copy( hook ),
	_G			  = table.Copy( _G )
}

function DIX:FillDetouredMeta()
	for i = 1, table.Count( DIX.Meta.lua ) do
		DIX.Detours.lua[i] = DIX.Copy._G.getmetatable( DIX.Copy[DIX.Meta.lua[i]] )
	end
end
DIX:FillDetouredMeta()

--[[--------------------------------------------
	VARS
--]]--------------------------------------------

DIX.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	path 	 	 = "lua\\autorun\\client\\ph0ne.lua",
	prefix	     = "ph0ne_"
}

DIX.Files  = { -- Store file names for protection.
	"loader.lua",
	"loader",
	"ph0ne.lua",
	"ph0ne",
	"gmcl_ph0nage.dll",
	"gmcl_ph0nage",
	"ph0nage",
	"gmcl_hake.dll",
	"gmcl_hake",
	"hake",
	"gmcl_sys.dll",
	"gmcl_sys",
	"sys",
	"gmod_cvars_cl.txt",
	"gmod_cvars_cl"
}

--[[--------------------------------------------
	HOOKING AND CONCOMMANDS
--]]--------------------------------------------

--[ HOOKING ]--

local function new_hookCall( name, gm, ... ) -- Thanks C0BRA.
	local ret = nil
	for k, v in pairs( DIX.Hooks ) do
		if ( k == name ) then
			if ( ... == nil ) then
				ret = v()
			else
				ret = v( ... )
			end
			if ( ret ~= nil ) then return ret end
		end
	end
	return DIX.Copy.hook.Call( name, gm, ... )
end

hook = {}

DIX.Copy._G.setmetatable( hook, {
	__index = function( t, k )
		if ( k == "Call" ) then return new_hookCall end
		return DIX.Copy.hook[k]
	end,
	__newindex = function( t, k, v )
		if ( k == "Call" ) then
			if ( v ~= new_hookCall ) then DIX.Detours.protected.hook.Call = v end
			return
		end
		DIX.Copy.hook[k] = v
	end,
	__metatable = true, -- Detouring this way allows me to lock the metatable from further modification.
} )

function DIX:AddHook( name, func )
	DIX.Hooks[name] = func
end

--[ CONCOMMANDS ]--

local function new_concommandRun( ply, name, ... )
	if DIX.Commands[name] then return DIX.Commands[name]( ply, name, ... ) end
	return DIX.Copy.concommand.Run( ply, name, ... )
end

concommand = {}

DIX.Copy._G.setmetatable( concommand, {
	__index = function( t, k )
		if ( k == "Run" ) then return new_concommandRun end
		return DIX.Copy.concommand[k]
	end,
	__newindex = function( t, k, v )
		if ( k == "Run" ) then
			if ( v ~= new_concommandRun ) then DIX.Detours.protected.concommand.Run = v end
			return
		end
		DIX.Copy.concommand[k] = v
	end,
	__metatable = true,
} )

function DIX:AddCommand( name, func )
	DIX.Commands[name] = func
	AddConsoleCommand( name )
end

--[[--------------------------------------------
	DETOURS
--]]--------------------------------------------

function DIX:DetourFunction( old, new ) -- Thanks noPE.
	DIX.Detours[new] = old
	return new
end

usermessage.Hook = DIX:DetourFunction( usermessage.Hook, function( name, func )
	local blacklist = {
		["shindig"] = true,
		["_ac_fuck"] = true,
		["_ac_cmd"] = true
	}
	if blacklist[string.lower( name )] then return end
	return DIX.Detours[usermessage.Hook]( name, func )
end )

require = DIX:DetourFunction( require, function( module )
	return DIX.Detours[require]( module )
end )

debug.getinfo = DIX:DetourFunction( debug.getinfo, function( func, path )
	return DIX.Detours[debug.getinfo]( DIX.Detours[func] or func, path ) -- Return correct information about any detoured function.
end )

debug.getupvalue = DIX:DetourFunction( debug.getupvalue, function( func, int )
	return DIX.Detours[debug.getupvalue]( DIX.Detours[func] or func, int ) -- Same thing here.
end )

cvars.AddChangeCallback = DIX:DetourFunction( cvars.AddChangeCallback, function( cvar, call )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar )] then return end
		if DIX.Settings[string.lower( cvar )] then return end
	end
	return DIX.Detours[cvars.AddChangeCallback]( cvar, call )
end )

cvars.OnConVarChanged = DIX:DetourFunction( cvars.OnConVarChanged, function( name, old, new )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( name )] then return end
		if DIX.Settings[string.lower( name )] then return end
	end
	return DIX.Detours[cvars.OnConVarChanged]( name, old, new )
end )

CreateClientConVar = DIX:DetourFunction( CreateClientConVar, function( cvar, val, save, def )
	if( DIX.ConVars[cvar] ) then return end -- You may not replicate my cvars.
	return DIX.detours[CreateClientConVar]( cvar, val, save, def )
end )

GetConVar = DIX:DetourFunction( GetConVar, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar )] then return end
	end
	return DIX.Detours[GetConVar]( cvar )
end )

ConVarExists = DIX:DetourFunction( ConVarExists, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar )] then return end
	end
	return DIX.Detours[ConVarExists]( cvar )
end )
GetConVarNumber = DIX:DetourFunction( GetConVarNumber, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar )] then return end
	end
	return DIX.Detours[GetConVarNumber]( cvar )
end )
GetConVarString = DIX:DetourFunction( GetConVarString, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar )] then return end
	end
	return DIX.Detours[GetConVarString]( cvar )
end )

RunConsoleCommand = DIX:DetourFunction( RunConsoleCommand, function( cmd, ... )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cmd )] then return end
		if DIX.Commands[string.lower( cmd )] then return end
	end
	return DIX.Detours[RunConsoleCommand]( cmd, ... )
end )

_R.Player.ConCommand = DIX:DetourFunction( _R.Player.ConCommand, function( ply, cmd, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cmd )] then return end
		if DIX.Conmmands[string.lower( cmd )] then return end
	end
	return DIX.Detours[_R.Player.ConCommand]( ply, cmd, ... )
end )

_R.ConVar.GetInt = DIX:DetourFunction( _R.ConVar.GetInt, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar:GetName() )] then return end
	end
	return DIX.Detours[_R.ConVar.GetInt]( cvar )
end )

_R.ConVar.GetBool = DIX:DetourFunction( _R.ConVar.GetBool, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.ConVars[string.lower( cvar:GetName() )] then return end
	end
	return DIX.Detours[_R.ConVar.GetBool]( cvar )
end )

file.Read = DIX:DetourFunction( file.Read, function( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return nil end
	end
	return DIX.Detours[file.Read]( path, bool )
end )

file.Exists = DIX:DetourFunction( file.Exists, function( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return nil end
	end
	return DIX.Detours[file.Exists]( path, bool )
end )
file.ExistsEx = DIX:DetourFunction( file.ExistsEx, function( path, addons )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return nil end
	end
	return DIX.Detours[file.ExistsEx]( path, addons )
end )

file.Write = DIX:DetourFunction( file.Write, function( path, cont, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return nil end
	end
	return DIX.Detours[file.Write]( path, cont, ... )
end )
file.Time = DIX:DetourFunction( file.Time, function( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return 0 end
	end
	return DIX.Detours[file.Time]( path )
end )

file.Size = DIX:DetourFunction( file.Size, function( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		if DIX.Files[string.lower( path )] then return -1 end
	end
	return DIX.Detours[file.Size]( path )
end )
file.Find = DIX:DetourFunction( file.Find, function( name )
	local callpath, find = debug.getinfo(2)['short_src'], DIX.Detours[file.Find]( name )
	if callpath and ( callpath ~= DIX.Vars.path ) then
		for k, v in pairs( find ) do
			for _, e in pairs( DIX.Files ) do
				if string.find( string.lower( e ), v ) then find[k] = nil end
			end
		end
	end
	return DIX.Detours[file.Find]( name )
end )

file.FindInLua = DIX:DetourFunction( file.FindInLua, function( name )
	local callpath, find = debug.getinfo(2)['short_src'], DIX.Detours[file.FindInLua]( name )
	if callpath and ( callpath ~= DIX.Vars.path ) then
		for k, v in pairs( find ) do
			for _, e in pairs( DIX.Files ) do
				if string.find( string.lower( e ), v ) then find[k] = nil end
			end
		end
	end
	return DIX.Detours[file.FindInLua]( name )
end )
file.TFind = DIX:DetourFunction( file.TFind, function( name, call )
	if debug.getinfo(2)['short_src'] then
		return DIX.Detours[file.TFind]( name, function( name, folder, files )
			for k, v in pairs( folder ) do
				for _, e in pairs( DIX.Files ) do
					if string.find( string.lower( e ), v ) then folder[k] = nil end
				end
			end
			for k, v in pairs( files ) do
				for _, e in pairs( DIX.Files ) do
					if string.find( string.lower( e ), v ) then files[k] = nil end
				end
			end
			return call( path, folder, files )
		end )
	end
	return DIX.Detours[file.TFind]( name, function( path, folder, files ) 
		return call( path, folder, files )
	end )
end )

_R.Entity.FireBullets = DIX:DetourFunction( _R.Entity.FireBullets, function( ent, bullet ) -- Thanks stgn.
	local ply = LocalPlayer()
	DIX.Cones.normal[ply:GetActiveWeapon():GetClass()] = bullet.Spread
	return DIX.Detours[_R.Entity.FireBullets]( ent, bullet )
end )

setmetatable = DIX:DetourFunction( setmetatable, function( meta, cont )
	for i = 1, table.Count( DIX.Meta.lua ) do
		if ( meta == DIX.Meta.lua[i] ) then
			DIX.Detours.lua[i] = cont
		else
			DIX.Detours[setmetatable]( meta, cont )
		end
	end
	return meta
end )

getmetatable = DIX:DetourFunction( getmetatable, function( meta, ... )
	for i = 1, table.Count( DIX.Meta.lua ) do
		if ( meta == DIX.Meta.lua[i] ) then return DIX.Detours.lua[i] end
	end
	return DIX.Detours[getmetatable]( meta, ... )
end )

debug['setmetatable'] = setmetatable
debug['getmetatable'] = getmetatable

rawequal = DIX:DetourFunction( rawequal, function( one, two )
	if DIX.Detours[one] and ( tostring( one ) == tostring( two ) ) then return true end -- Make it look like we haven't even detoured anything.
	return DIX.Detours[rawequal]( one, two )
end )

rawset = DIX:DetourFunction( rawset, function( func, name, val )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= DIX.Vars.path ) then
		for i = 1, table.Count( DIX.Meta.lua ) do
			if ( func == tostring( DIX.Meta.lua[i] ) ) then return end -- Prevent others from tampering with our detours.
		end
	end
	return DIX.Detours[rawset]( func, name, val )
end )

--[ DETOUR _R ]--

function DIX:DetourLuaMeta()
	for i = 1, table.Count( DIX.Meta._R ) do
		local var, backup = DIX.Meta._R[i], {}
		for k, v in pairs( _R[var] ) do backup[k] = v end -- Backup the metatables.
		backup.__index = backup
		DIX.Detours._R[var] = backup -- Store it somewhere.
		DIX.Copy._G.setmetatable( _R[var], {
			__index = function( t, k )
				return DIX.Detours._R[var][k]
			end,
			__newindex = function( t, k, v )
				return DIX.Copy._G.rawset( t, k, v )
			end,
			__metatable = true, -- Lock it.
		} )
	end
end
DIX:DetourLuaMeta()

--[[--------------------------------------------
	C++ MODULE
--]]--------------------------------------------

function DIX:LoadModule()
	if tobool( #file.Find( "../lua/includes/modules/gmcl_ph0nage.dll" ) ) then
		if not cheat or ( type( cheat ) ~= "table" ) then
			require( "ph0nage" )
			package.loaded.ph0nage = nil
			DIX.ph0nage = table.Copy( cheat )
			_G.cheat = nil
			DIX.ph0nage.Msg( "\n:: ", Color( 255, 255, 255 ) )
			DIX.ph0nage.Msg( "ph0nage initialized, now loading...\n", Color( 255, 0, 0 ) )
		end
	end
end
DIX:LoadModule()

--[[--------------------------------------------
	CONVARS
--]]--------------------------------------------

--[ ADD CONVARS ]--

DIX.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "AimGeneral" },
	{ Name = "aim_holdtarget", Value = 0, Desc = "Hold Target (NOTE: Saves FPS.)", Type = "bool", Table = "holdtarget", Menu = "AimTarget" },
	{ Name = "aim_silent", Value = 1, Desc = "No View Change", Type = "bool", Table = "aimsilent", Menu = "AimGeneral" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "AimGeneral" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "AimTarget" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "AimTarget" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "AimTarget" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "AimTarget" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "AimGeneral" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "AimGeneral" },
	{ Name = "aim_obb", Value = 0, Desc = "Aim at OBBCenter", Type = "bool", Table = "obb", Menu = "AimTarget" },
	{ Name = "aim_antiaim", Value = 0, Desc = "Anti-Aim", Type = "bool", Table = "antiaim", Menu = "AimGeneral" },
	{ Name = "aim_antiaim_type", Value = 1, Table = "aatype" },
	{ Name = "aim_nospread", Value = 1, Desc = "Nospread", Type = "bool", Table = "nospread", Menu = "AimGeneral" },
	{ Name = "aim_nospread_fire", Value = 1, Desc = "Nospread While Firing", Type = "bool", Table = "nospreadfire", Menu = "AimGeneral" },
	{ Name = "aim_autowall", Value = 0, Desc = "MadCow Autowall", Type = "bool", Table = "autowall", Menu = "AimTarget" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "AimTarget" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "AimTarget" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "AimTarget" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "AimTarget" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "AimTarget" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "AimTarget" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "AimGeneral" },
	{ Name = "esp", Value = 1, Desc = "ESP Enabled", Type = "bool", Table = "esp", Menu = "ESP" },
	{ Name = "esp_skeleton", Value = 1, Desc = "Skeleton", Type = "bool", Table = "skeleton", Menu = "ESP" },
	{ Name = "esp_barrel", Value = 1, Desc = "Barrel Hack", Type = "bool", Table = "barrel", Menu = "ESP" },
	{ Name = "esp_info", Value = 1, Desc = "Player Info", Type = "bool", Table = "infoesp", Menu = "ESP" },
	{ Name = "esp_target", Value = 1, Desc = "Target Indicator Line", Type = "bool", Table = "targetesp", Menu = "ESP" },
	{ Name = "esp_admins", Value = 1, Desc = "Admin List", Type = "bool", Table = "adminlist", Menu = "ESP" },
	{ Name = "esp_rpents", Value = 0, Desc = "RP Entities", Type = "bool", Table = "rpesp", Menu = "ESP" },
	{ Name = "esp_tttweps", Value = 0, Desc = "TTT Traitor Weapons", Type = "bool", Table = "traitorwepesp", Menu = "ESP" },
	{ Name = "esp_chams", Value = 1, Desc = "Chams", Type = "bool", Table = "chams", Menu = "ESP" },
	{ Name = "esp_chams_fullbright", Value = 1, Desc = "Render Fullbright", Type = "bool", Table = "renderfullbright", Menu = "ESP" },
	{ Name = "misc_bunnyhop", Value = 0, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "Misc" },
	{ Name = "misc_ungag", Value = 0, Desc = "ULX/Evolve Ungag", Type = "bool", Table = "ungag", Menu = "Misc" },
	{ Name = "misc_crosshair", Value = 1, Desc = "Crosshair", Type = "bool", Table = "crosshair", Menu = "Misc" },
	{ Name = "misc_calcview", Value = 1, Desc = "Enable CalcView", Type = "bool", Table = "calcview", Menu = "Misc" },
	{ Name = "misc_fullbright", Value = 0, Desc = "Enable Fullbright", Type = "bool", Table = "fullbright", Menu = "Misc" },
	{ Name = "misc_cmdspam", Value = 0, Desc = "Command Spam", Type = "bool", Table = "spam", Menu = "Misc" },
	{ Name = "misc_cmdspam_cmd", Value = "", Table = "cmdtospam" },
	{ Name = "misc_speed", Value = 1, Desc = "Speedhack Value", Type = "number", Table = "speed", Max = 8, Min = 1, Menu = "Misc" }
}

--[ CREATE CONVARS ]--

function DIX:CreateConVars()
	for i = 1, table.Count( DIX.SetVars ) do
		local v = DIX.SetVars[i]
		local pvar = DIX.Vars.prefix .. v.Name
		local convar = DIX.Detours[CreateClientConVar]( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		if ( type( v.Value ) == "number" ) then
			DIX.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table. This increases performance.
		else
			DIX.Settings[v.Table] = convar:GetString()
		end
		DIX.Menu.info[pvar] = cvarinfo
		DIX.Menu.info[#DIX.Menu.info + 1] = cvarinfo
		DIX.Detours[cvars.AddChangeCallback]( pvar, function( cvar, old, new )
			DIX.Settings[v.Table] = new -- If our cvar value changes, then so does our callback table.
		end )
		DIX.ConVars[pvar] = convar
	end
end
DIX:CreateConVars()

DIX.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
DIX.ph0nage.Msg( "Convars created.\n", Color( 255, 0, 0 ) )

--[ CVAR VALUE CHECK ]--
function DIX:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

--[ CVAR HIDING ]--

DIX.OriginalVars = {
	{ "sv_cheats", FCVAR_NOTIFY | FCVAR_REPLICATED | FCVAR_CHEAT, "0" },
	{ "host_timescale", FCVAR_NOTIFY | FCVAR_REPLICATED | FCVAR_CHEAT, "1.0" },
	{ "r_drawothermodels", FCVAR_CLIENTDLL | FCVAR_CHEAT, "1" },
	{ "mat_fullbright", FCVAR_CHEAT, "0" },
	{ "sv_consistency", FCVAR_REPLICATED, "1" },
	{ "sv_allow_voice_from_file", FCVAR_REPLICATED, "1" },
	{ "voice_inputfromfile", FCVAR_NONE, "0" },
	{ "fog_enable", FCVAR_CLIENTDLL | FCVAR_CHEAT, "1" },
	{ "fog_enable_water_fog", FCVAR_CHEAT, "1" }
}

function DIX:HideCvars()
	for i = 1, table.Count( DIX.OriginalVars ) do
		local cvar = DIX.OriginalVars[i]
		local pvar = DIX.Vars.prefix .. cvar[1]
		if not ConVarExists( pvar ) then -- Run only once.
			DIX.ph0nage.ReplicateVar( cvar[1], pvar, cvar[2], cvar[3] )
			CreateConVar( cvar[1], cvar[3], cvar[2] ) -- ReplicateVar doesn't keep the original, so we have to recreate it.
			DIX.ConVars[pvar] = pvar
		end
	end
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "sv_cheats 1" ) -- Set some defaults.
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "sv_consistency 0" )
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "fog_enable 0" )
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "fog_enable_water_fog 0" )
end
DIX:HideCvars()

--[ CVAR FORCING ]--

function DIX.FullBright()
	if DIX:G( DIX.Settings['fullbright'], 1 ) then
		DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "mat_fullbright 1" )
	elseif DIX:G( DIX.Settings['fullbright'], 0 ) then
		DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "mat_fullbright 0" )
	end
end

function DIX.SpeedOn()
	if ( GetConVarNumber( "ph0ne_sv_cheats" ) == 1 ) then
		DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "host_timescale " .. tonumber( DIX.Settings['speed'] ) )
	else
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "ConVar ",
			Color( 255, 0, 0 ), DIX.Vars.prefix .. "sv_cheats ",
			Color( 255, 255, 255 ), "must be enabled to use speedhack."
		)
	end
end
DIX:AddCommand( "+ph0ne_speed", DIX.SpeedOn )

function DIX.SpeedOff()
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "host_timescale 1.0" )
end
DIX:AddCommand( "-ph0ne_speed", DIX.SpeedOff )
--[[--------------------------------------------
	UTIL FUNCTIONS
--]]--------------------------------------------

--[ CHECKS ]--
function DIX:IsAdmin( e )
	if e:IsSuperAdmin() then return true end
	if e:IsAdmin() then return true end
	return false
end
function DIX:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function DIX:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function DIX:IsTraitor( e )
	local ply = LocalPlayer()
	if not DIX:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function DIX:IsOnScreen( e ) -- Thanks fr1kin.
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	for i = 1, table.Count( positions ) do
		local v = positions[i]
		local pos = e:LocalToWorld( _R.Entity[v]( e ) ):ToScreen()
		if ( pos.x > 0 ) and ( pos.y > 0 ) and ( pos.x < x ) and ( pos.y < y ) then return true end
	end
	return false
end

function DIX:TargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( DIX.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if DIX.ph0nage.IsDormant( e:EntIndex() ) then return false end
		if DIX:IsAdmin( e ) and DIX:G( DIX.Settings['ignoreadmins'], 1 ) then return false end
		if DIX:IsTraitor( e ) and DIX:G( DIX.Settings['ignoretraitors'], 1 ) then return false end
		if DIX:IsFriend( e ) and DIX:G( DIX.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and DIX:G( DIX.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ply:GetAimVector():Angle()
			if DIX:G( DIX.Settings['aimsilent'], 1 ) then ang = DIX.Vars.fakeang end
			local aim = ( DIX:GetTargetLocation( e ) - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ang.y - aim.y ) )
			local pitch = math.abs( math.NormalizeAngle( ang.p - aim.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if DIX.ph0nage.IsDormant( e:EntIndex() ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not DIX:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if DIX:IsAdmin( e ) and DIX:G( DIX.Settings['ignoreadmins'], 1 ) then return false end
		if DIX:IsTraitor( e ) and DIX:G( DIX.Settings['ignoretraitors'], 1 ) then return false end
		if DIX:IsFriend( e ) and DIX:G( DIX.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and DIX:G( DIX.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

function DIX:ResetAim()
	if DIX:G( DIX.Settings['aimsilent'], 1 ) then return true end
	if DIX:G( DIX.Settings['antiaim'], 1 ) then return true end
	if DIX:G( DIX.Settings['nospreadfire'], 1 ) then return true end
	return false
end

--[ OTHER ]--

function DIX:GetPlayerColor( e )
	local vis, invis
	if DIX:TargetValid( e, "chams" ) then
		vis = Color( 255, 255, 0, 255 )
		invis = Color( 255, 0, 0, 255 )
	else
		vis = Color( 0, 255, 0, 255 )
		invis = Color( 0, 0, 255, 255 )
	end
	return vis, invis
end

function DIX:GetStatusColor( e )
	local pos = DIX:GetTargetLocation( e ):ToScreen()
	local statuscol = Color( 255, 255, 255, 255 )
	if DIX:IsFriend( e ) then
		statuscol = Color( 0, 255, 0, 255 )
	elseif DIX:IsAdmin( e ) then
		statuscol = Color( 255, 255, 0, 255 )
	elseif DIX:IsTraitor( e ) and DIX:IsTTT() then
		statuscol = Color( 255, 0, 0, 255 )
	else
		statuscol = Color( 255, 255, 255, 255 )
	end
	return statuscol
end

function DIX:SetViewAngles( cmd, ang )
	local aimangle = Vector( ang.p, ang.y, ang.r )
	DIX.ph0nage.SetViewAngles( cmd, aimangle )
end

function DIX:NormalizeAngle( ang )
	return Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
end

function DIX:ClampAngle( cmd, ang )
	ang.p = math.Clamp( ang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	ang.y = math.NormalizeAngle( ang.y + ( cmd:GetMouseX() * -0.022 ) )
	return ang
end

--[[--------------------------------------------
	NOSPREAD
--]]--------------------------------------------

--[ HL2 CONES ]--

DIX.Cones.hl2["weapon_smg1"]    = Vector( -0.04362, -0.04362, -0.04362 )
DIX.Cones.hl2["weapon_pistol"]  = Vector( -0.0100, -0.0100, -0.0100 )
DIX.Cones.hl2["weapon_ar2"]	    = Vector( -0.02618, -0.02618, -0.02618 )
DIX.Cones.hl2["weapon_shotgun"] = Vector( -0.08716, -0.08716, -0.08716 )

--[ MANUPULATE SHOT ]--

function DIX:PredictSpread( cmd, angle )
	local ply, cone = LocalPlayer(), Vector( 0, 0, 0 )
	local ang = ( angle or ply:GetAimVector():Angle() ):Forward()
	local wep = ply:GetActiveWeapon()
	if ply:Alive() and wep and ValidEntity( wep ) then
		local class = wep:GetClass()
		if not DIX.Cones.hl2[class] then
			if DIX.Cones.normal[class] then
				cone = Vector( 0, 0, 0 ) - DIX.Cones.normal[class] or Vector( 0, 0, 0 )
				return DIX.ph0nage.PredictSpread( cmd, ang, cone ):Angle()
			end
		else
			cone = DIX.Cones.hl2[class] or Vector( 0, 0, 0 )
			return DIX.ph0nage.PredictSpread( cmd, ang, cone ):Angle()
		end
	end
	return Angle( angle.p, angle.y, 0 ) -- If something fucks up we can just return the original angle.
end
--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

DIX.Headcrab = {
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body"
}

function DIX:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "att" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function DIX:GetTargetSpot( e )
	if DIX:G( DIX.Settings['obb'], 1 ) then return e:LocalToWorld( e:OBBCenter() ) end
	for k, v in pairs( DIX.Headcrab ) do
		if ( k == e:GetModel() ) then DIX:GetPosition( e, v, "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = DIX:GetPosition( e, "forward", "att" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		local eyes = DIX:GetPosition( e, "eyes", "att" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if ( e:LookupAttachment( "head" ) ~= 0 ) then -- General humanoid models 2.
		local head = DIX:GetPosition( e, "head", "att" )
		if head and head.Pos then return head.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position (using bones sucks big dick).
		return DIX:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

function DIX:Crossbow( e, pos ) -- I have a huge e-penis now.
	local ply = LocalPlayer()
	if DIX:TargetValid( e, "aim" ) then
		local dist = e:GetPos():Distance( ply:GetPos() )
		local wep = ply:GetActiveWeapon()
		if wep and ValidEntity( wep ) and ( wep:GetClass() == "weapon_crossbow" ) then
			local predicted = dist / 3110
			return ( pos + e:GetVelocity() * predicted )
		end
		return pos
	end
	return pos
end

function DIX:GetTargetLocation( e )
	return DIX:Crossbow( e, DIX:GetTargetSpot( e ) )
end

--[ PREDICTION ]--

function DIX:GetPredictionPos( e )
	local ply = LocalPlayer()
	if DIX:G( DIX.Settings['prediction'], 1 ) then
		local vc1 =  tonumber( DIX.Settings['predictiontar'] )
		local vc2 =  tonumber( DIX.Settings['predictionply'] )
		local tv, pv = e:GetVelocity(), ply:GetVelocity()
		if DIX:G( DIX.Settings['predictiontype'], 1 ) then -- Static.
			return ( tv / vc1 ) - ( pv / vc2 )
		elseif DIX:G( DIX.Settings['predictiontype'], 2 ) then -- Framerate.
			local frame1 = RealFrameTime() / vc1
			local frame2 = RealFrameTime() / vc2
			return ( tv * frame1 ) - ( pv * frame2 )
		end
	else
		return Vector( 0, 0, 0 )
	end
end

--[ AUTOWALL ]--

function DIX:IsPenetrable( tr )
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function DIX:TargetVisible( e )
	local ply = LocalPlayer()
	if DIX:G( DIX.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = DIX:GetTargetLocation( e ) + DIX:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( DIX:G( DIX.Settings['autowall'], 1 ) and DIX:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function DIX:GetAimTarget()
	if DIX:G( DIX.Settings['holdtarget'], 1 ) then
		if DIX:TargetValid( DIX.Vars.target, "aim" ) and DIX:TargetVisible( DIX.Vars.target ) then
			return DIX.Vars.target
		else
			DIX.Vars.target = nil
		end
	end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if DIX:G( DIX.Settings['aim'], 1 ) then
		for i = 1, table.Count( DIX.World.players ) do
			local e = DIX.World.players[i]
			if DIX:TargetValid( e, "aim" ) and DIX:TargetVisible( e ) then
				local pos = DIX:GetTargetLocation( e ) + DIX:GetPredictionPos( e )
				local d = math.deg( math.acos( ply:GetAimVector():Dot( ( pos - ply:GetShootPos() ):GetNormal() ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function DIX:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if DIX:G( DIX.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( DIX.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function DIX.OnToggled()
	local ply = LocalPlayer()
	if not ValidEntity( ply ) then return end
	DIX.Vars.fakeang = ply:EyeAngles()
end
DIX:AddHook( "OnToggled", DIX.OnToggled )

--[ AIMBOT ]--

function DIX.Aimbot( cmd )
	local ply, tar = LocalPlayer(), DIX:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	DIX.Vars.fakeang = DIX:NormalizeAngle( DIX.Vars.fakeang )
	DIX.Vars.fakeang = DIX:ClampAngle( cmd, DIX.Vars.fakeang )
	if DIX:ResetAim() then
		DIX:SetViewAngles( cmd, DIX.Vars.fakeang )
	end
	if DIX:G( DIX.Settings['nospread'], 1 ) and DIX:G( DIX.Settings['nospreadfire'], 1 ) and cmd:KeyDown( IN_ATTACK ) then
		spread = DIX:NormalizeAngle( DIX:PredictSpread( cmd, DIX.Vars.fakeang ) )
		DIX:SetViewAngles( cmd, spread )
	end
	if DIX:G( DIX.Settings['aim'], 1 ) and ply:Alive() and tar then
		DIX.Vars.target = tar
		DIX.Vars.found = true
		local pos = ( DIX:GetTargetLocation( tar ) + DIX:GetPredictionPos( tar ) ) + Vector( 0, 0, tonumber( DIX.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		DIX.Vars.aimingang = ang
		ang = DIX:GetSmoothAngle( ang )
		if DIX:G( DIX.Settings['nospread'], 1 ) and DIX:G( DIX.Settings['aimsmooth'], 0 ) then
			ang = DIX:PredictSpread( cmd, ang )
		end
		ang = DIX:NormalizeAngle( ang )
		if DIX:G( DIX.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				DIX:SetViewAngles( cmd, ang )
				DIX.Vars.aimlocked = true
			else
				DIX.Vars.aimlocked = false
			end
		else
			DIX:SetViewAngles( cmd, ang )
			DIX.Vars.aimlocked = true
		end
	else
		DIX.Vars.target = nil
		DIX.Vars.aimlocked = false
		DIX.Vars.found = false
	end
	if DIX:G( DIX.Settings['aimsilent'], 1 ) and DIX.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( DIX.Vars.aimingang - DIX.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end

function DIX.Autoshoot( cmd )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if not DIX:G( DIX.Settings['aim'], 1 ) then return end
	if not DIX.Vars.found or not DIX.Vars.aimlocked then return end
	if DIX:G( DIX.Settings['autoshoot'], 1 ) and DIX:G( DIX.Settings['snaponfire'], 0 ) and not DIX.Vars.firing then
		if DIX:G( DIX.Settings['aimsmooth'], 1 ) then
			local e = ply:GetEyeTrace().Entity
			if DIX:TargetValid( e, "aim" ) then
				DIX.ph0nage.RunCommand( "+attack" )
				DIX.Vars.firing = true
				timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
					DIX.ph0nage.RunCommand( "-attack" )
					DIX.Vars.firing = false
				end )
			end
		else
			DIX.ph0nage.RunCommand( "+attack" )
			DIX.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				DIX.ph0nage.RunCommand( "-attack" )
				DIX.Vars.firing = false
			end )
		end
	end
end

--[[--------------------------------------------
	PROPKILLING
--]]--------------------------------------------

--[ COMMANDS ]--

function DIX.PropkillOn()
	if not DIX:IsTTT() then return end
	if DIX:G( DIX.Settings['aimsilent'], 1 ) then
		DIX.Vars.osv = 1
	else
		DIX.Vars.osv = 0
	end
	DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "aim_silent 0" )
	DIX.Vars.pkfake = true
end
DIX:AddCommand( "+ph0ne_pk", DIX.PropkillOn )

function DIX.PropkillOff()
	if not DIX:IsTTT() then return end
	DIX.Vars.pkfake = false
	DIX.Vars.pkthrow = true
	if DIX:G( DIX.Settings['aimsilent'], 0 ) then
		if ( DIX.Vars.osv == 1 ) then
			DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "aim_silent 1" )
		else
			DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "aim_silent 0" )
		end
	end
end
DIX:AddCommand( "-ph0ne_pk", DIX.PropkillOff )

--[ TURN PLAYER 180 ]--

function DIX.TTTPropkill( cmd )
	local ply = LocalPlayer()
	if DIX:IsTTT() then
		if DIX.Vars.pkfake and not DIX.Vars.pkthrow then
			DIX.Vars.pkthrowang = cmd:GetViewAngles()
			DIX.Vars.pkfakeang = DIX.Vars.pkthrowang - Angle( 0, 180, 0 )
			local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local ang = ply:GetAimVector():Angle()
			if DIX:G( DIX.Settings['aimsilent'], 1 ) then ang = DIX.Vars.fakeang end
			local set = ( norm:Angle() + ( DIX.Vars.pkfakeang - ang ) ):Forward() * move:Length()
			cmd:SetForwardMove( set.x )
			cmd:SetSideMove( set.y )
		elseif not DIX.Vars.pkfake and DIX.Vars.pkthrow then
			DIX.Vars.pkthrow = false
			DIX:SetViewAngles( cmd, DIX.Vars.pkfakeang )
			if DIX:G( DIX.Settings['aimsilent'], 1 ) then
				DIX.Vars.fakeang = DIX.Vars.pkfakeang
				DIX:SetViewAngles( cmd, DIX.Vars.fakeang )
			end
		else
			DIX.Vars.pkthrowang = cmd:GetViewAngles()
			DIX.Vars.pkfakeang = DIX.Vars.pkthrowang
		end
	end
end

--[[--------------------------------------------
	BUNNYHOPPING
--]]--------------------------------------------
	
function DIX.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if DIX:G( DIX.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() | IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end
--[[--------------------------------------------
	ANTI-AIM
--]]--------------------------------------------

function DIX.AntiAim( cmd )
	local ply = LocalPlayer()
	if not ply:Alive() then return end
	if cmd:KeyDown( IN_ATTACK | IN_ATTACK2 | IN_USE ) then return end
	if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
	if DIX.Vars.aimlocked or DIX.Vars.pkfake then return end
	if DIX:G( DIX.Settings['antiaim'], 1 ) then
		if DIX:G( DIX.Settings['aatype'], 1 ) then
			DIX.ph0nage.FakeAngles( cmd, 205, 180 )
		elseif DIX:G( DIX.Settings['aatype'], 2 ) then
			DIX.ph0nage.AntiAim( cmd, 1 )
		end
	end
end
--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function DIX.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {} -- The gun model moves freely.
	if DIX:G( DIX.Settings['calcview'], 1 ) then
		view.angles.r = 0
		if DIX.Vars.pkfake and DIX:IsTTT() then
			view.angles = DIX.Vars.pkfakeang -- TTT propkilling.
		elseif DIX.Vars.aimlocked and DIX:G( DIX.Settings['aimsilent'], 0 ) and DIX:G( DIX.Settings['aimsmooth'], 0 ) then
			view.angles = DIX.Vars.aimingang -- Normalized aimbot angle.
		elseif DIX.Vars.aimlocked and DIX:G( DIX.Settings['aimsmooth'], 1 ) and DIX:G( DIX.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle() -- Smooth aim.
		elseif DIX:ResetAim() then
			view.angles = DIX.Vars.fakeang -- Silent aim, anti-aim, or nospread.
		else
			view.angles = ply:GetAimVector():Angle() -- Anything else.
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
DIX:AddHook( "CalcView", DIX.CalcView )

--[[--------------------------------------------
	ESP
--]]--------------------------------------------

--[ TARGET LINE ]--

function DIX.DrawTargetLine()
	local w, h = ScrW() / 2, ScrH() / 2
	if DIX:G( DIX.Settings['esp'], 1 ) and DIX:G( DIX.Settings['aim'], 1 ) and DIX:G( DIX.Settings['targetesp'], 1 ) then
		if ( DIX.Vars.target ~= nil ) then
			if DIX:TargetValid( DIX.Vars.target, "esp" ) then
				local pos = DIX:GetTargetLocation( DIX.Vars.target ):ToScreen()
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawLine( w, h, pos.x, pos.y )
			end
		end
	end
end

--[ PLAYER ESP ]--

DIX.Skeleton = {
	{ "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Spine4" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
	{ "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
	{ "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0" },
	{ "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0" },
}

function DIX:DrawPlayerSkeleton( e )
	if not DIX:G( DIX.Settings['skeleton'], 1 ) then return end
	for i = 1, table.Count( DIX.Skeleton ) do
		local parent = e:GetBonePosition( e:LookupBone( DIX.Skeleton[i][1] ) ):ToScreen()
		local child = e:GetBonePosition( e:LookupBone( DIX.Skeleton[i][2] ) ):ToScreen()
		local vis, invis = DIX:GetPlayerColor( e )
		if DIX:G( DIX.Settings['chams'], 1 ) then
			surface.SetDrawColor( 255, 255, 255, 255 )
		else
			if DIX:TargetVisible( e ) then
				surface.SetDrawColor( vis )
			else
				surface.SetDrawColor( invis )
			end
		end
		surface.DrawLine( parent.x, parent.y, child.x, child.y )
	end
end

function DIX:DrawStatusLine( e, pos, opos )
	surface.SetDrawColor( DIX:GetStatusColor( e ) )
	surface.DrawLine( opos.x, opos.y, pos.x + 7, pos.y - 3 )
	surface.DrawLine( pos.x + 7, pos.y - 3, pos.x + 30, pos.y - 3 )
end

function DIX:DrawPlayerInfo( e, pos )
	local col = Color( 255, 255, 255, 255 )
	local hp = e:Health()
	if ( hp <= 100 ) and ( hp > 0 ) then
		col = Color( 255, 2.55 * hp, 2.55 * hp, 255 )
	else
		col = Color( 255, 255, 255, 255 )
	end
	draw.SimpleTextOutlined(
		tostring( e:Health() ),
		"Default",
		pos.x + 10,
		pos.y - 2.5,
		col,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_TOP,
		1,
		Color( 0, 0, 0, 255 )
	)
	draw.SimpleTextOutlined(
		string.Left( tostring( e:Nick() ), 14 ),
		"DefaultBold",
		pos.x + 16,
		pos.y - 4.5,
		Color( 255, 255, 255, 255 ),
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_BOTTOM,
		1,
		Color( 0, 0, 0, 255 )
	)
	local vis, invis = DIX:GetPlayerColor( e )
	local pcol = Color( 255, 255, 255, 255 )
	if DIX:TargetVisible( e ) then
		pcol = vis
	else
		pcol = invis
	end
	draw.RoundedBox( 0, pos.x + 7, pos.y - 14, 7, 7, pcol )
end

function DIX:GetLaserMaterial( col )
	local info = {
		["$basetexture"] = "sprites/laser",
		["$additive"]	 = 1,
		["$translucent"] = 1,
		["$vertexcolor"] = 1,
		["$color"]		 = string.format( "{%c %c %c}", col.r, col.g, col.b ),
	}
	return CreateMaterial( "laser", "UnlitGeneric", info )
end

function DIX:DrawBarrelHack( e, pos )
	if not DIX:G( DIX.Settings['barrel'], 1 ) then return end
	local col = Color( 255, 255, 255 ,255 )
	local vis, invis = DIX:GetPlayerColor( e )
	if DIX:TargetVisible( e, "aim" ) then
		col = vis
	else
		col = invis
	end
	cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( DIX:GetLaserMaterial( col ) )
		render.DrawBeam( DIX:GetTargetLocation( e ), e:GetEyeTrace().HitPos, 5, 0, 0, col )
	cam.End3D()
end

function DIX.DrawPlayerESP()
	local ply = LocalPlayer()
	if DIX:G( DIX.Settings['esp'], 1 ) then
		for i = 1, table.Count( DIX.World.players ) do
			local e = DIX.World.players[i]
			if DIX:TargetValid( e, "esp" ) then
				local opos = DIX:GetTargetSpot( e ):ToScreen()
				local pos = ( DIX:GetTargetSpot( e ) + Vector( 0, 0, 12 ) ):ToScreen()
				DIX:DrawPlayerSkeleton( e )
				DIX:DrawStatusLine( e, pos, opos )
				DIX:DrawPlayerInfo( e, pos )
				DIX:DrawBarrelHack( e, opos )
			end
		end
	end
end
	
--[ ADMIN DISPLAY ]--

function DIX.DrawAdminList()
	if DIX:G( DIX.Settings['esp'], 1 ) and DIX:G( DIX.Settings['adminlist'], 1 ) then
		local admins, w, h, y = {}, ScrW(), ScrH(), 0
		draw.SimpleTextOutlined(
			"ADMINS:",
			"Default",
			w - ( w - 20 ),
			( h - h ) + 301,
			Color( 255, 105, 105, 255 ),
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_CENTER,
			1,
			Color( 0, 0, 0, 255 )
		)
		for i = 1, table.Count( DIX.World.players ) do
			local e = DIX.World.players[i]
			if ValidEntity( e ) and DIX:IsAdmin( e ) then
				table.insert( admins, e:Nick() )
			end
		end
		for i = 1, table.Count( admins ) do
			draw.SimpleTextOutlined(
				tostring( admins[i] ),
				"Default",
				w - ( w - 20 ),
				( ( h - h ) + 315 ) + y,
				Color( 255, 255, 255, 255 ),
				TEXT_ALIGN_LEFT,
				TEXT_ALIGN_CENTER,
				1,
				Color( 0, 0, 0, 255 )
			)
			y = y + 15
		end
	end
end

--[ RP ENTITY ESP ]--
DIX.World.rpents = {
	"money_printer",
	"gunlab",
	"drug_lab",
	"spawned_money",
	"dispenser",
	"gunvault",
	"drugfactory",
	"gunfactory",
	"microwave",
	"powerplant"
}

function DIX:DrawRPEntities()
	if DIX:G( DIX.Settings['esp'], 1 ) and DIX:G( DIX.Settings['rpesp'], 1 ) then
		for i = 1, table.Count( DIX.World.rpents ) do
			local ent = ents.FindByClass( DIX.World.rpents[i] ) -- Lag problem fixed.
			for e = 1, table.Count( ent ) do
				local pos = ent[e]:GetPos():ToScreen()
				draw.SimpleTextOutlined(
					tostring( DIX.World.rpents[i] ),
					"DefaultSmall",
					pos.x,
					pos.y,
					Color( 255, 255, 55, 255 ),
					TEXT_ALIGN_CENTER,
					TEXT_ALIGN_CENTER,
					1,
					Color( 0, 0, 0, 255 )
				)
			end
		end
	end
end

--[ TRAITOR WEAPON ESP ]--

DIX.World.traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_decoy",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport"
}

function DIX.DrawTraitorWeapons() -- This is more efficient than hooking Think and using _R.Player.GetWeapon.
	if DIX:G( DIX.Settings['esp'], 1 ) then
		if DIX:G( DIX.Settings['traitorwepesp'], 1 ) and DIX:IsTTT() then
			for i = 1, table.Count( DIX.World.traitorweapons ) do
				local ent = ents.FindByClass( DIX.World.traitorweapons[i] )
				for e = 1, table.Count( ent ) do
					local pos = ent[e]:GetPos():ToScreen()
					local wep = string.gsub( DIX.World.traitorweapons[i], "weapon_ttt_", "" )
					draw.SimpleTextOutlined(
						tostring( wep ),
						"DefaultSmall",
						pos.x,
						pos.y,
						Color( 255, 55, 55, 255 ),
						TEXT_ALIGN_RIGHT,
						TEXT_ALIGN_TOP,
						1,
						Color( 0, 0, 0, 255 )
					)
				end
			end
		end
	end
end

--[[--------------------------------------------
	CROSSHAIR
--]]--------------------------------------------

function DIX.DrawCrosshair()
	if DIX:G( DIX.Settings['crosshair'], 1 ) then
		local w, h = ScrW() / 2, ScrH() / 2
		local e1, e2 = 5, 20
		if DIX:G( DIX.Settings['aim'], 1 ) then
			surface.SetDrawColor( 255, 0, 0, 255 )
		else
			surface.SetDrawColor( 0, 255, 0, 255 )
		end
		surface.DrawLine( w - e1, h, w, h )
   		surface.DrawLine( w + e1, h, w, h )
		surface.DrawLine( w, h - e1, w, h )
		surface.DrawLine( w, h + e1, w, h )
		if DIX.Vars.found and not DIX.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 155 )
			surface.DrawOutlinedRect( ( w - e1 ) - 2, ( h - e1 ) - 2, ( ( e1 + 2 ) * 2 ) + 1, ( ( e1 + 2 ) * 2 ) + 1 )
		elseif DIX.Vars.found and DIX.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawLine( w - e2, h, w - e1, h )
			surface.DrawLine( w + e2, h, w + e1, h )
			surface.DrawLine( w, h - e2, w, h - e1 )
			surface.DrawLine( w, h + e2, w, h + e1 )
		end
		if DIX.Vars.found and ( DIX.Vars.target ~= nil ) then
			draw.SimpleTextOutlined(
				"Target: " .. string.Left( tostring( DIX.Vars.target:Nick() ), 16 ),
				"Default",
				w,
				h + 40,
				Color( 255, 135, 135, 255 ),
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_BOTTOM,
				1,
				Color( 0, 0, 0, 255 )
			)
		end
	end
end

--[[--------------------------------------------
	CHAMS
--]]--------------------------------------------

--[ MATERIAL ]--

function DIX:GetChamsMaterial()
	local params = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	return CreateMaterial( "\0\1", "VertexLitGeneric", params )
end

--[ RENDERING ]--

function DIX.RenderScreenspaceEffects()
	if DIX:G( DIX.Settings['esp'], 1 ) and DIX:G( DIX.Settings['chams'], 1 ) then
		cam.Start3D( EyePos(), EyeAngles() )
		render.SuppressEngineLighting( tobool( DIX.Settings['renderfullbright'] ) )
		SetMaterialOverride( DIX:GetChamsMaterial() )
		for i = 1, table.Count( DIX.World.players ) do
			local e = DIX.World.players[i]
			local vis, invis = DIX:GetPlayerColor( e )
			if DIX:TargetValid( e, "esp" ) then
				render.SetColorModulation( ( invis.r / 255 ), ( invis.g / 255 ), ( invis.b / 255 ) )
				e:DrawModel()
			end
		end
		SetMaterialOverride()
		for i = 1, table.Count( DIX.World.players ) do -- Two loops surprisingly saves FPS as opposed to using one.
			local e = DIX.World.players[i]
			local vis, invis = DIX:GetPlayerColor( e )
			if DIX:TargetValid( e, "esp" ) then
				render.SetColorModulation( ( vis.r / 255 ), ( vis.g / 255 ), ( vis.b / 255 ) )
				e:SetMaterial( "models/debug/debugwhite" )
				e:DrawModel()
				e:SetMaterial( "" ) -- Reset to default mat due to AIDS.
			end
		end
		render.SuppressEngineLighting( false )
		cam.End3D()
	end
end
DIX:AddHook( "RenderScreenspaceEffects", DIX.RenderScreenspaceEffects )

--[[--------------------------------------------
	MISC
--]]--------------------------------------------

--[ ULX/EVOLVE UNGAG ]--

function DIX.UnGag()
	local ply = LocalPlayer()
	if ply and DIX:G( DIX.Settings['ungag'], 1 ) then
		if ulx and ulx.gagUser then
			ulx.gagUser( false )
			DIX.Copy.hook.Remove( "PlayerBindPress", "ULXGagForce" )
			timer.Destroy( "GagLocalPlayer" )
		end
		if evolve then -- Thanks stgn.
			ply:SetNWBool( "Muted", false )
		end
	end
end

--[ COMMAND SPAM ]--

function DIX.CommandSpam()
	if not LocalPlayer():Alive() then return end
	if DIX:G( DIX.Settings['spam'], 1 ) then
		DIX.ph0nage.RunCommand( tostring( DIX.Settings['cmdtospam'] ) )
	end
end

--[[--------------------------------------------
	PLAYERS
--]]--------------------------------------------

function DIX.GetAllPlayers()
	DIX.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if ValidEntity( e ) then table.insert( DIX.World.players, e ) end
	end
end

--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function DIX.CreateMoveHook( cmd )
	DIX.Aimbot( cmd )
	DIX.Autoshoot( cmd )
	DIX.AntiAim( cmd )
	DIX.Bunnyhop( cmd )
	DIX.TTTPropkill( cmd )
end
DIX:AddHook( "CreateMove", DIX.CreateMoveHook )

function DIX.HUDPaintHook()
	DIX.DrawTargetLine()
	DIX.DrawPlayerESP()
	DIX.DrawAdminList()
	DIX.DrawRPEntities()
	DIX.DrawTraitorWeapons()
	DIX.DrawCrosshair()
end
DIX:AddHook( "HUDPaint", DIX.HUDPaintHook )

function DIX.ThinkHook()
	DIX.FullBright()
	DIX.GetAllPlayers()
	DIX.UnGag()
	DIX.CommandSpam()
end
DIX:AddHook( "Think", DIX.ThinkHook )

DIX.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
DIX.ph0nage.Msg( "All functions hooked.\n", Color( 255, 0, 0 ) )

--[[--------------------------------------------
	MENU
--]]--------------------------------------------

--[ TABS ]--

function DIX:AddMenuTab( name )
	if not name or ( name and DIX.Menu.tabs[name] ) then return end
	DIX.Menu.tabs[name] = {}
end

DIX:AddMenuTab( "AimGeneral" )
DIX:AddMenuTab( "AimTarget" )
DIX:AddMenuTab( "ESP" )
DIX:AddMenuTab( "Misc" )

function DIX:AddMenuTabButton( text, x, y )
	local button = vgui.Create( "DButton" )
	button:SetParent( self )
	button:SetSize( 70, 20 )
	button:SetPos( x, y )
	button:SetText( "" )
	button.Paint = function()
		local col = Color( 105, 105, 105, 155 )
		if button.Depressed then
			col = Color( 255, 201, 14, 155 )
		end
		local w, h = button:GetWide(), button:GetTall()
		surface.SetDrawColor( col )
		surface.DrawRect( 0, 0, w, h )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( 0, 0, w, h )
		draw.SimpleTextOutlined(
			tostring( text ),
			"Default",
			( w / 2 ) - 0.5,
			( h / 2 ) - 0.5,
			Color( 255, 255, 255, 255 ),
			TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER,
			1,
			Color( 0, 0, 0, 255 )
		)
	end
	return button
end

--[ MENU ]--

function DIX.OpenMenu()
	local w, h = ScrW() / 2, ScrH() / 2
	local x, y = 400, 325
	local tx, ty = x - 20, y - 65
	DIX.panel = vgui.Create( "DFrame" )
	DIX.panel:SetPos( w - x / 2, h - y / 2 )
	DIX.panel:SetSize( x, y )
	DIX.panel:SetTitle( "" )
	DIX.panel:SetVisible( true )
	DIX.panel:SetDraggable( true )
	DIX.panel:ShowCloseButton( true )
	DIX.panel:MakePopup()
	local pw, ph = DIX.panel:GetWide(), DIX.panel:GetTall()
	DIX.panel.Paint = function()
		draw.RoundedBox( 0, 0, 0, x, y, Color( 25, 55, 105, 55 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, x, y )
		draw.SimpleTextOutlined( ":: ", "DefaultBold", 10, 5, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ph0nage", "DefaultBold", 21, 5, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
	end
	local lists, tab = {}, 0
	for k, v in pairs( DIX.Menu.tabs ) do
		local button = DIX:AddMenuTabButton( k, 10 + tab, 32 )
		button:SetParent( DIX.panel )
		lists[k] = vgui.Create( "DPanelList" )
		lists[k]:SetPos( 10, 56 )
		lists[k]:SetParent( DIX.panel )
		lists[k]:SetSize( tx, ty )
		lists[k]:EnableVerticalScrollbar( true )
		lists[k]:SetSpacing( 7 )
		lists[k]:SetPadding( 10 )
		lists[k].Paint = function()
			local lw, lh = lists[k]:GetWide(), lists[k]:GetTall()
			surface.SetDrawColor( 0, 0, 0, 205 )
			surface.DrawRect( 0, 0, lw, lh )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( 0, 0, lw, lh )
		end
		lists[k]:SetVisible( false )
		button.DoClick = function()
			for r, _ in pairs( lists ) do lists[r]:SetVisible( false ) end
			lists[k]:SetVisible( true )
		end
		tab = tab + 80
	end
	for _, v in ipairs( DIX.Menu.info ) do
		if ( v.Type == "bool" ) then
			local checkbox = vgui.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetConVar( v.Name )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( Color( 255, 255, 255, 255 ) )
			for i, _ in pairs( lists ) do
				if ( tostring( i ) == v.Menu ) then lists[i]:AddItem( checkbox ) end
			end
		elseif ( v.Type == "number" ) then
			local slider = vgui.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max or 1 )
			slider:SetMin( v.Min or 0 )
			slider:SetDecimals( 0 )
			slider:SetConVar( v.Name )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = vgui.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 150 )
			label:SetText( v.Desc )
			label:SetTextColor( Color( 255, 255, 255, 255 ) )
			for i, _ in pairs( lists ) do
				if ( tostring( i ) == v.Menu ) then lists[i]:AddItem( slider ) end
			end
		end
	end
	local label = vgui.Create( "DLabel" )
	label:SetText( "Prediction Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	lists["AimTarget"]:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Static" )
	multichoice:AddChoice( "Framerate" )
	multichoice:ChooseOptionID( tonumber( DIX.Settings['predictiontype'] ) )
	multichoice.OnSelect = function( index, value, data )
		DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "aim_prediction_type " .. value )
	end
	lists["AimTarget"]:AddItem( multichoice )
	local label = vgui.Create( "DLabel" )
	label:SetText( "Anti-Aim Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	lists["AimGeneral"]:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Fake Angles" )
	multichoice:AddChoice( "Normal" )
	multichoice:ChooseOptionID( tonumber( DIX.Settings['aatype'] ) )
	multichoice.OnSelect = function( index, value, data )
		DIX.ph0nage.RunCommand( DIX.Vars.prefix .. "aim_antiaim_type " .. value )
	end
	lists["AimGeneral"]:AddItem( multichoice )
	local label = vgui.Create( "DLabel" )
	label:SetText( "Command To Spam" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	lists["Misc"]:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( true )
	multichoice:AddChoice( "" )
	multichoice:ChooseOptionID( 1 )
	multichoice:SetConVar( "ph0ne_misc_cmdspam_cmd" )
	lists["Misc"]:AddItem( multichoice )
	lists["AimGeneral"]:SetVisible( true ) -- Aimbot is our most important one.
end
DIX:AddCommand( "ph0ne_menu", DIX.OpenMenu )

--[[--------------------------------------------
	END MESSAGE
--]]--------------------------------------------

DIX.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
DIX.ph0nage.Msg( "ph0nage successfully loaded.\n\n", Color( 255, 0, 0 ) )