--[[
	MOD/lua/OCRPEnts.lua
	[TSA] Skittles 2.0 | (STEAM_0:1:41711091) | [05-08-13 08:39:07PM]
	===BadFile===
]]

--Credits: Nomical, Fr1kin, seth, and xerA/skittles 2.0
     --Keep in mind this is the first HvH hack I worked with.(That i publicly released)
     --Aimbot Cvars

    local ClRcl = CreateClientConVar("kla_Aimbot_NoRecoil", 0 , true , false)
    local ClAimSteam = CreateClientConVar("kla_Aimbot_IgnoreSteam",0,true,false)
    local ClFriendly = CreateClientConVar("kla_Aimbot_Friendlyfire",0,true,false)
    local ClFv = CreateClientConVar("kla_Aimbot_FixView",0,true,false)
    local CLM = CreateClientConVar("kla_Aimbot_AutoShoot",0,true,false)
    local CLN = CreateClientConVar("kla_Aimbot_NoSpread", 0 , true , false)
    local ClOf = CreateClientConVar("kla_Aimbot_Offset",0,true,false)
    local ClType = CreateClientConVar("kla_Aimbot_AimSpot","Eye",true,false)
    CreateClientConVar("kla_anti_aim",0,true,false)

    --When you run the lua file
    local function OnLoad()
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Welcome to KLA v0.1 alpha " )
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Shoutouts: Tyler, some random kid in the HvH server with nospread, and that russian kid." )
            if GetConVarNumber("Sv_Cheats") == 1 then
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Either your bypasser works or you are in a local server" )
            else
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Aww, your bypasser does not work. What a shame. (or you have sv_cheats 1 off in a local server)" )
            end
                        if GetConVarNumber("sv_allowcslua") == 1 then
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Your lua bypass works! (Or your in a local server)" )
            else
            LocalPlayer():PrintMessage( HUD_PRINTTALK, "Your lua bypass is not working or you are in a local server with it off." )
            end

            chat.AddText(
Color(255,69,0,255), "[KLA v0.1]: ",
Color(0,255,0,255),"Player Information: ",
Color(0,255,0,255),""..LocalPlayer():Nick" ","("..LocalPlayer():SteamID" ",")")
            --
            OnLoad()

    local function PlyPos( ply )
    local min = ply:OBBMins()
    local max = ply:OBBMaxs()

    local Spots = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
    }

   // Aimbot
    concommand.Add("+kla_Aim",function()
    Aimon = 1
    end)

    concommand.Add("-kla_Aim",function()
    Aimon = 0
    end)

    --Nospread shit

    function WeaponVector( value, typ )
            local s = ( -value )

            if ( typ == true ) then
                    s = ( -value )
            elseif ( typ == false ) then
                    s = ( value )
            else
                    s = ( value )
            end
            return Vector( s, s, s )
    end

    local currentseed, cmd2, seed = currentseed || 0, 0, 0
    local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )

    local CustomCones       = {}
    CustomCones.Weapons = {}
    CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
    CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
    CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
    CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
     -- All weapons deprived from CS:S
    local NormalCones = { [ "weapon_cs_base" ] = true }

    function GetCone( wep )
            local c = wep.Cone

            if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
            if ( !c ) then c = 0 end
            if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
            if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
            return c || 0
    end

    function DoklaNospread( ucmd, angle )
    if CLN:GetInt() >= 1 then
            local ply = LocalPlayer()

            cmd2, seed = abc_ucmd_getperdicston( ucmd )
            if ( cmd2 != 0 ) then currentseed = seed end

            local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
            if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                    valCone = GetCone( w )

                    if ( type( valCone ) == "number" ) then
                            vecCone = Vector( -valCone, -valCone, -valCone )

                    elseif ( type( valCone ) == "Vector" ) then
                            vecCone = valCone * -1

                    end
        else
                    if ( w:IsValid() ) then
                            local class = w:GetClass()
                                    if ( CustomCones.Weapons[ class ] ) then
                                            vecCone = CustomCones.Weapons[ class ]
                                    end
                            end
                    end
            return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
      end
    end

   --Some aimspot stuff

    local function AimSpot(targ)
            if GetConVarString("kla_Aimbot_AimSpot") == "Eye" then
            local eye = targ:LookupAttachment("eyes")
                    if eye then
                    local pos = targ:GetAttachment(eye)
                            if pos then return pos.Pos end
                    end
            end
            if GetConVarString("kla_Aimbot_AimSpot") == "Bone" then
            local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
                    if bone then
                    local pos = targ:GetBonePosition(bone)
                            if pos then return pos end
                    end
            end
            if GetConVarString("kla_Aimbot_AimSpot") == "Center" then
            local center = targ:OBBCenter()
                    if center then
                    local pos = targ:LocalToWorld(center)
                            if pos then return pos end
                    end
            end

    return targ:LocalToWorld(targ:OBBCenter())  -- Dev notes: Revert to center or some shit if not working.

    end
     --Checks
    local function Exception(ent)
            if (ent == LocalPlayer()) then return false end
            if (ent:Team() == TEAM_SPECTATOR) then return false end --Spec check.
            if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end --MoveType Check.
            if (!ent:Alive() ) then return false end -- Alive check.
            if (ent:InVehicle()) then return false end -- vehicle check.
            if (ClFriendly:GetInt() == 0 && ent:Team() == LocalPlayer():Team()) then return false end -- Friendly fire check.
            if (ClAimSteam:GetInt() >= 1 && ent:GetFriendStatus() == "friend" ) then return false end -- I think I am going to remove this next update, waste of space.
    return true
    end
     --Vis check
    local function Visible(ply)
    local tracedata = {}
            tracedata.start = LocalPlayer():GetShootPos()
            tracedata.endpos = AimSpot(ply) - Vector(0,0,ClOf:GetInt())
            tracedata.mask = MASK_SHOT
            tracedata.filter = {ply , LocalPlayer()}
    Trace = util.TraceLine(tracedata)
    if Trace.Hit then return false else return true end
    end
     --Important stuff
    local function klaAimbot(ucmd)
            if Aimon == 1 then
            local targets = { nil, 0 }
                    for k, v in ipairs( player.GetAll() ) do
                            if Exception( v ) && Visible( v ) then

                            local crosshair = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
                            crosshair = crosshair - LocalPlayer():GetAimVector()
                            crosshair = crosshair:Length()
                            crosshair = math.abs( crosshair )
                                    if ( crosshair < targets[2] ) or ( targets[1] == nil ) then
                                    targets = { v, crosshair }

                                    end
                            end
                    end
                    Backup = targets[1] --bugfix
            if targets[1] != nil then

    //      local Aimspot = targets[1]:GetBonePosition(targets[1]:LookupBone("ValveBiped.Bip01_Head1")) - Vector(0,0,ClOf:GetInt())
            local Aimspot = AimSpot(targets[1]) - Vector(0,0,ClOf:GetInt())
            Aimspot = Aimspot + targets[1]:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
            Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
            Angel.p = math.NormalizeAngle( Angel.p )
            Angel.y = math.NormalizeAngle( Angel.y )

                    if CLN:GetInt() >= 1 then
                    ArchAngel = DoIsisNospread( ucmd, Angle( Angel.p, Angel.y, 0 ) )
                    else
                    ArchAngel = Angle( Angel.p, Angel.y, 0 )
                    end

    SetViewAngles(ucmd, ArchAngel)

                    end
            end
    end



    local function CalcV(ply, pos, angles, fov)
            if ClFv:GetInt() >= 1 then
            local view = {}
            view.origin = pos
                    if GetViewEntity() == LocalPlayer() then
                            if Aimon == 1 && Backup != nil then
                            view.angles = Angel
                            else
                            view.angles = LocalPlayer():EyeAngles()
                            end
                    end
            view.fov = fov
            return view
            end
    end

