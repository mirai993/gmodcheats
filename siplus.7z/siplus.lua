//  ____   _   ____    _
// |  __| |_| |  _  | | |
// | |__   _  | |_| | | |    _   _   ____  Made by SiPlus
// |__  | | | |  ___| | |   | | | | |  __| http://steamcommunity.com/id/SiPlus
//  __| | | | | |     | |_  | |_| | |__  | hwguy.siplus@gmail.com
// |____| |_| |_|     |___| |_____| |____| 2010

local condefs = {
	esp_enabled = 1,
	esp_drawOnPlayers = 1,
	esp_drawOnNPCs = 0,
	esp_drawOnLocalPlayer = 0,
	esp_showNames = 0,
	esp_boxWidth = 32,
	esp_boxHeight = 32,
	esp_NPCsColor_r = 0,
	esp_NPCsColor_g = 0,
	esp_NPCsColor_b = 255,
	esp_NPCsColor_a = 255,
	esp_localPlyColor_r = 0,
	esp_localPlyColor_g = 255,
	esp_localPlyColor_b = 0,
	esp_localPlyColor_a = 255,
	esp_localPlyCrossSize = 32,
}

local convars = {}

local function OnInitialize()
	for key,value in pairs(condefs) do
		CreateClientConVar(key, value, true, false)
	end
end

local function DrawESP()
	if GetConVarNumber("esp_enabled")==1 then
		if GetConVarNumber("esp_drawOnPlayers")==1 then
			for k, plys in pairs(player.GetAll()) do
				if plys != LocalPlayer() then
					allplayersposition = plys:GetPos() + plys:OBBCenter()
					playerposition = allplayersposition:ToScreen()
					plysColor = team.GetColor(plys:Team())
					surface.SetDrawColor(plysColor)
					surface.DrawOutlinedRect( playerposition.x - GetConVarNumber("esp_boxWidth") / 2, playerposition.y - GetConVarNumber("esp_boxHeight") / 2, GetConVarNumber("esp_boxWidth"), GetConVarNumber("esp_boxHeight"))
					if GetConVarNumber("esp_showNames")==1 then
						boxHeightDividedBy2 = GetConVarNumber("esp_boxHeight") / 2
						surface.SetTextColor( plysColor )
						surface.SetTextPos(playerposition.x,playerposition.y - boxHeightDividedBy2 - 16)
						surface.SetFont("TabLarge")
						surface.DrawText(plys:GetName())
					end
				end
			end
		end
		if GetConVarNumber("esp_drawOnNPCs")==1 then
			for k, NPCs in pairs(ents.FindByClass("npc_*")) do
				allNPCsposition = NPCs:GetPos() + NPCs:OBBCenter()
				NPCposition = allNPCsposition:ToScreen()
				surface.SetDrawColor(GetConVarNumber("esp_NPCsColor_r"),GetConVarNumber("esp_NPCsColor_g"),GetConVarNumber("esp_NPCsColor_b"),GetConVarNumber("esp_NPCsColor_a"))
				surface.DrawOutlinedRect( NPCposition.x - GetConVarNumber("esp_boxWidth") / 2, NPCposition.y - GetConVarNumber("esp_boxHeight") / 2, GetConVarNumber("esp_boxWidth"), GetConVarNumber("esp_boxHeight"))
				if GetConVarNumber("esp_showNames")==1 then
					boxHeightDividedBy2 = GetConVarNumber("esp_boxHeight") / 2
					surface.SetTextColor( GetConVarNumber("esp_NPCsColor_r"),GetConVarNumber("esp_NPCsColor_g"),GetConVarNumber("esp_NPCsColor_b"),GetConVarNumber("esp_NPCsColor_a") )
					surface.SetTextPos(NPCposition.x,NPCposition.y - boxHeightDividedBy2 - 16)
					surface.SetFont("TabLarge")
					surface.DrawText(NPCs:GetClass())
				end
			end
		end
		if GetConVarNumber("esp_drawOnLocalPlayer")==1 then
			localplayerpos = LocalPlayer():GetPos()
			localplayerposgui = localplayerpos:ToScreen()
			surface.SetDrawColor(GetConVarNumber("esp_localPlyColor_r"),GetConVarNumber("esp_localPlyColor_g"),GetConVarNumber("esp_localPlyColor_b"),GetConVarNumber("esp_localPlyColor_a"))
			surface.DrawLine(localplayerposgui.x-GetConVarNumber("esp_localPlyCrossSize"),localplayerposgui.y,localplayerposgui.x+GetConVarNumber("esp_localPlyCrossSize"),localplayerposgui.y)
			surface.DrawLine(localplayerposgui.x,localplayerposgui.y-GetConVarNumber("esp_localPlyCrossSize"),localplayerposgui.x,localplayerposgui.y+GetConVarNumber("esp_localPlyCrossSize"))
		end
	end
end
local function SpawnmenuToolMenu(panel)
	panel:AddControl("CheckBox", {
		Label = "Mark players",
		Command = "esp_drawOnPlayers",
	})
	panel:AddControl("CheckBox", {
		Label = "Mark NPCs",
		Command = "esp_drawOnNPCs",
	})
	panel:AddControl("CheckBox", {
		Label = "Mark local player (me)",
		Command = "esp_drawOnLocalPlayer",
	})
	panel:AddControl("CheckBox", {
		Label = "Show players and NPCs names",
		Command = "esp_showNames",
	})
	panel:AddControl("Slider", {
		Label = "Box Width",
		Command = "esp_boxWidth",
		Type = "Integer",
		min = 8,
		max = 64,
	})
	panel:AddControl("Slider", {
		Label = "Box Height",
		Command = "esp_boxHeight",
		Type = "Integer",
		min = 8,
		max = 64,
	})
	panel:AddControl("Label", {
		Text = "NPCs color",
	})
	panel:AddControl("Color", {
		Red = "esp_NPCsColor_r",
		Green = "esp_NPCsColor_g",
		Blue = "esp_NPCsColor_b",
		Alpha = "esp_NPCsColor_a",
		ShowHSV	= 1,
		ShowRGB	= 1,
		ShowAlpha = 1,
	})
	panel:AddControl("Label", {
		Text = "Local player cross color",
	})
	panel:AddControl("Color", {
		Red = "esp_localPlyColor_r",
		Green = "esp_localPlyColor_g",
		Blue = "esp_localPlyColor_b",
		Alpha = "esp_localPlyColor_a",
		ShowHSV	= 1,
		ShowRGB	= 1,
		ShowAlpha = 1,
	})
	panel:AddControl("Slider", {
		Label = "Local player cross size",
		Command = "esp_localPlyCrossSize",
		Type = "Integer",
		min = 8,
		max = 64,
	})
end
hook.Add("Initialize", "ESPInitialize", OnInitialize)
function SpawnmenuToolMenuCategory()
	spawnmenu.AddToolMenuOption("Options", "Player", "ESPSettings", "ESP", "", "", SpawnmenuToolMenu, {SwitchConVar = 'esp_enabled'})
end
hook.Add("HUDPaint", "ESPDraw", DrawESP)
hook.Add("PopulateToolMenu", "ESPMenu", SpawnmenuToolMenuCategory)