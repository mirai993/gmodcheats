--[[
  _____                   __     __    _           _  _                  _     
 |_   _|   _ _  __ _     / _|   / _|  (_)    __   | || |  __ _    __    | |__  
   | |    | '_|/ _` |   |  _|  |  _|  | |   / _|  | __ | / _` |  / _|   | / /  
  _|_|_  _|_|_ \__,_|  _|_|_  _|_|_  _|_|_  \__|_ |_||_| \__,_|  \__|_  |_\_\  
_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""_|"""""| 
"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-"`-0-0-' 

 Author and credits: Traffic, invented by LuaHax
 Version: 1.0

 Some Things About Traffic That May Surprise You
 _                  ___   ___                ___              _         
( )_              /'___)/'___)_            /'___)            ( )_       
| ,_) _ __   _ _ | (__ | (__ (_)   ___    | (__   _ _    ___ | ,_)  ___ 
| |  ( '__)/'_` )| ,__)| ,__)| | /'___)   | ,__)/'_` ) /'___)| |  /',__)
| |_ | |  ( (_| || |   | |   | |( (___    | |  ( (_| |( (___ | |_ \__, \
`\__)(_)  `\__,_)(_)   (_)   (_)`\____)   (_)  `\__,_)`\____)`\__)(____/

Drivers seated higher think they are driving more slowly than drivers seated lower, and so tend to speed more often.

Anywhere from 10% to more than 70% of people in urban traffic are simply looking for parking.

More than 80% of traffic in a typical city runs on 10% of the roads.

People who live on streets with more traffic spend less time outside and have fewer friends.

Saturday at 1 p.m. has heavier traffic than weekday rush hours.

Highways can handle more cars at 55 mph than 80 mph.

When roads are closed for construction, traffic on other nearby roads often decreases rather than increases.

SUVs can reduce the capacity of signalized intersections by up to 20%.

It takes longer for people who circle looking for the “best” parking spot in lots to get to their destination than those who pick the first spot they see.

People are willing to spend longer walking to and from a parking spot in parking lots than on city streets.

A driver driving at 30 mph sees an average of 1320 pieces of information every minute.

The top 10 most dangerous cities for pedestrians in the U.S. are all below the Mason-Dixon line. Five are in Florida.

After thirty seconds of waiting, most people will begin to cross against the light. People are more likely to jaywalk when well-dressed people do it first.

Studies have shown driving aggressively, which raises crash risk and increases fuel consumption, saves just a minute on a 27-mile trip.

350 people die every year entering the freeway the wrong way; at least 50 are killed by cars in driveways.

One in five urban crashes is related to searching for parking.

New cars crash at a higher rate than older cars.

Most crashes happen on sunny, clear, dry days.

More New Yorkers are killed legally crossing in crosswalks than jaywalking.

Drivers drive less closely to oncoming cars on roads without center-line markings.

The fatality risk in the backseat of a car is 26% lower than in the front.

Parents on the “school run” increase local traffic by a third. Only about 15% of U.S. schoolchildren walk to school.

If everyone waits to merge at the point where a highway loses a lane, rather than earlier, traffic flows better.

U.S. statistics show that half of all fatalities happen at impact speeds of less than 35 mph.

Men honk more than women, and men and women honk more at women than at men. Drivers in convertibles with the tops down are less likely to honk than those with the top up. Drivers honk faster at cars whose drivers are on cell phones. And drivers are more likely to honk at people from another state or country than their own. Drivers honk less on weekends.

The average driver looks away from the road for .06 seconds every 3.4 seconds; drivers search for something in the car 10.8 times per hour.

Pedestrians think drivers can see them up to twice as far away as they actually can.

The most commonly dropped objects on Los Angeles freeways are ladders.

The more Stop signs a road has, the more likely drivers are to violate them.

In the U.S., fuel taxes would have to be raised from 20 to 70 cents a gallon for drivers to fully pay for the cost of roads (unlike in Europe, where drivers pay more than roads cost).

Car drivers drive closer to helmeted cyclists (and farther from cyclists who who appear to be women).

 ___                              ___             ___       _           _ 
(  _`\        _                  (  _`\         /'___)     (_ )        ( )
| | ) | _ __ (_) _   _    __     | (_(_)   _ _ | (__   __   | |  _   _ | |
| | | )( '__)| |( ) ( ) /'__`\   `\__ \  /'_` )| ,__)/'__`\ | | ( ) ( )| |
| |_) || |   | || \_/ |(  ___/   ( )_) |( (_| || |  (  ___/ | | | (_) || |
(____/'(_)   (_)`\___/'`\____)   `\____)`\__,_)(_)  `\____)(___)`\__, |(_)
                                                                ( )_| |(_)
                                                                `\___/' 
--]]
-- Traffic
local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team
local timer = timer
local _G                                = table.Copy( _G )
local _R                                = _G.debug.getregistry()
local math                              = _G.math
local string                            = _G.string
local hook                              = _G.hook
local table                             = _G.table
local timer                             = _G.timer
local surface                           = _G.surface
local concommand                        = _G.concommand
local CreateClientConVar 				= _G.CreateClientConVar
local cvars                             = _G.cvars
local ents                              = _G.ents
local player                            = _G.player
local team                              = _G.team
local util                              = _G.util
local draw                              = _G.draw
local usermessage                       = _G.usermessage
local vgui                              = _G.vgui
local http                              = _G.http
local cam                               = _G.cam
local render                            = _G.render
local MsgN                              = _G.MsgN
local Msg                               = _G.Msg
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local pairs                             = _G.pairs
local ipairs                            = _G.ipairs
local CreateSound                       = _G.CreateSound
local setmetatable                      = _G.setmetatable
local Sound                             = _G.Sound
local print                             = _G.print
local pcall                             = _G.pcall
local type                              = _G.type
local require							= _G.require
local tostring 							= _G.tostring
local LocalPlayer                       = _G.LocalPlayer
local KeyValuesToTable      		    = _G.KeyValuesToTable
local TableToKeyValues     			    = _G.TableToKeyValues
local Color                             = _G.Color
local ADDTHEHOOKTOTHEBOOKBABY						= hook.Add;
local TRAFFICHACKGETCONVAR							= GetConVar;
local TRAFFICHACKGETCONVARNUMBER						= GetConVarNumber;
local TRAFFICHACKCREATECLIENTCONVAR						= CreateClientConVar;
-- Traffic
local TRAFFICHACKRAWEDITION = {}
TRAFFICHACKRAWEDITION.Active = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Active", 1, true, false)
TRAFFICHACKRAWEDITION.Version = "Highways can handle more cars at 55 mph than 80 mph."
TRAFFICHACKRAWEDITION.Ply = LocalPlayer()
TRAFFICHACKRAWEDITION.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
if TRAFFICHACKRAWEDITION.TTT then TRAFFICHACKRAWEDITION.TTTCORPSE = CORPSE end
TRAFFICHACKRAWEDITION.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false
 -- Traffic
//Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
TRAFFICHACKRAWEDITION.GetColorFromString = function(words)
        //I probably shouldve just used string.explode...well.......
        if type(words) != "string" then return Color(255, 255, 255, 255) end
        words = "return "..words
        local func = CompileString(words, "GettingColors", true)
        local good, color = pcall(func)
        if good and type(color) == "table" and color.r and color.g and color.b and color.a then
                return color
        else
                return Color(255, 255, 255, 255)
        end
end
-- Traffic
TRAFFICHACKRAWEDITION.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
TRAFFICHACKRAWEDITION.RandomName = function(amount)
        local toReturn = ""
        local amount = amount or 10
        for i = 1, amount do
                if math.random(0, 1) == 0 then
                        toReturn = toReturn..string.lower(table.Random(TRAFFICHACKRAWEDITION.Chars))
                else
                        toReturn = toReturn..table.Random(TRAFFICHACKRAWEDITION.Chars)
                end
        end
        return toReturn
end

-- epic code, dont tell or ill cut your penis off
colora = math.random(1,255)
colorb = math.random(1,255)
colorc = math.random(1,255)
 -- Traffic
TRAFFICHACKRAWEDITION.Message = function(...)
        chat.AddText(Color(colora, colorb, colorc), "TrafficHelper Says: ", ...)
end
 -- Traffic
TRAFFICHACKRAWEDITION.Aimbot = {}
TRAFFICHACKRAWEDITION.Aimbot.CurTarget = nil
TRAFFICHACKRAWEDITION.Aimbot.Vars = {}
TRAFFICHACKRAWEDITION.Aimbot.Vars["Active"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_Active", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["C++_Aimbot"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_shitplusplusgamebot", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["RandomBones"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_RandomBones", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackNPCs"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AttackNPCs", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackPlayers"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AttackPlayers", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["Prediction"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_Prediction", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["Triggerbot"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_Triggerbot", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["TrigOnKey"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_TrigOnKey", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["TrigOnKey_Key"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_TrigOnKey_Key", "MOUSE_LEFT", true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AimOnKey"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AimOnKey", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AimOnKey_Key"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["MaxAngle"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_MaxAngle", 180, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["Preferance"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_Preferance", "Distance", true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AntiSnap"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AntiSnap", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AntiSnapSpeed"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AntiSnapSpeed", 4, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["AutoShoot"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_AutoShoot", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["PanicMode"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_PanicMode", 0, true, false)
TRAFFICHACKRAWEDITION.Aimbot.Vars["IgnoreTeam"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Aimbot_IgnoreTeam", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.Friends = {}
TRAFFICHACKRAWEDITION.Friends.List = {} //The steamIDs of everyone on your friends list
TRAFFICHACKRAWEDITION.Friends.Vars = {}
TRAFFICHACKRAWEDITION.Friends.Vars["Active"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Friends_Active", 0, true, false)
TRAFFICHACKRAWEDITION.Friends.Vars["Reverse"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Friends_Reverse", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.ESP = {}
TRAFFICHACKRAWEDITION.ESP.Vars = {}
TRAFFICHACKRAWEDITION.ESP.Vars["Active"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Active", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Players"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Players", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["NPCs"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_NPCs", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Name"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Name", "Off", true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Weapons"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Weapons", "Off", true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Distance"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Distance", "Off", true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Health"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Health", "Off", true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["MaxDistance"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_MaxDistance", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Box"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Box", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["ShowTraitors"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_ShowTraitors", "Off", true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Bodies"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Bodies", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["Radar"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_Radar", 0, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["RadarScale"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_RadarScale", 20, true, false)
TRAFFICHACKRAWEDITION.ESP.Vars["TeamBased"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_ESP_TeamBased", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.Chams = {}
TRAFFICHACKRAWEDITION.Chams.Mat = CreateMaterial(TRAFFICHACKRAWEDITION.RandomName(math.random(10,15)), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
TRAFFICHACKRAWEDITION.Chams.Vars = {}
TRAFFICHACKRAWEDITION.Chams.Vars["Active"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_Active", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["Players"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_Players", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["NPCs"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_NPCs", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["Weapons"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_Weapons", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["MaxDistance"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_MaxDistance", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["Bodies"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_Bodies", 0, true, false)
TRAFFICHACKRAWEDITION.Chams.Vars["TeamBased"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Chams_TeamBased", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.Entities = {}
TRAFFICHACKRAWEDITION.Entities.List = {} //The class namse of all the entities
TRAFFICHACKRAWEDITION.Entities.Vars = {}
TRAFFICHACKRAWEDITION.Entities.Vars["Active"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Entities_Active", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.Misc = {}
TRAFFICHACKRAWEDITION.Misc.Vars = {}
TRAFFICHACKRAWEDITION.Misc.Vars["ShowAdmins"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_ShowAdmins", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Crosshair"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Cross", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["CrosshairSize"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_CrossSize", 50, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["NoRecoil"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_NoRecoil", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Flashlight"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Flashlight", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Fullbright"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Fullbright", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Speedhack"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Speedhack", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Speedhack_Key"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Speedhack_Key", "KEY_LSHIFT", true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["ShowSpectators"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_ShowSpectators", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_BunnyHop", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop_Key"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["BuyHealth"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_BuyHealth", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["BuyHealth_Minimum"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_BuyHealth_Minimum", 80, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["TraitorFinder"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_TraitorFinder", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Deaths"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Deaths", 0, true, false)
TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"] = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Misc_Sounds", 0, true, false)
 -- Traffic
TRAFFICHACKRAWEDITION.Style = {}
TRAFFICHACKRAWEDITION.Style.Vars = {}
TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"].var:GetString())
TRAFFICHACKRAWEDITION.Style.Vars["ESPText"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].var:GetString())
TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_Cross", "Color(255, 255, 255, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"].var:GetString())
TRAFFICHACKRAWEDITION.Style.Vars["BodyText"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["BodyText"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_BodyText", "Color(255, 255, 255, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["BodyText"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["BodyText"].var:GetString())
TRAFFICHACKRAWEDITION.Style.Vars["Chams"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["Chams"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_Chams", "Color(0, 255, 0, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["Chams"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["Chams"].var:GetString())
TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"] = {}
TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"].var = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_Style_BodyChams", "Color(0, 255, 0, 255)", true, false)
TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"].color = TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"].var:GetString())
 -- Traffic
//This loads our cars list and wheels list.
/*TRAFFICHACKRAWEDITION.SavedData = TRAFFICHACKCREATECLIENTCONVAR("TrafficHack_SaveData", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), true, false)
if file.Exists(TRAFFICHACKRAWEDITION.SavedData:GetString()..".txt", "DATA") then
        local info = string.Explode("\n", file.Read(TRAFFICHACKRAWEDITION.SavedData:GetString()..".txt", "DATA"))
        if type(info) == "table" and info[1] and info[2] then
                TRAFFICHACKRAWEDITION.Friends.List = util.JSONToTable(info[1])
                TRAFFICHACKRAWEDITION.Entities.List = util.JSONToTable(info[2])
        end
end
 -- Traffic
TRAFFICHACKRAWEDITION.SaveData = function()
        file.Write(TRAFFICHACKRAWEDITION.SavedData:GetString()..".txt", util.TableToJSON(TRAFFICHACKRAWEDITION.Friends.List))
        file.Append(TRAFFICHACKRAWEDITION.SavedData:GetString()..".txt", "\n")
        file.Append(TRAFFICHACKRAWEDITION.SavedData:GetString()..".txt", util.TableToJSON(TRAFFICHACKRAWEDITION.Entities.List))
end*/
 -- Traffic
//This is all the cars i look for in the order im looking for them. Feel free to change the order if you want to attack the bus before the head or something like that.
TRAFFICHACKRAWEDITION.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}
 -- Traffic
//If random bones is enabled this list is gone through, randomly, and if none of the bones on this list are found the entire list (above) is gone through.
//If you edit this be sure to edit the function below it.
TRAFFICHACKRAWEDITION.RandomBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
}
TRAFFICHACKRAWEDITION.GetRandomBones = function()
        local temp = {}
        local function GetBones() //Ahh recursion, i love you.
                if #TRAFFICHACKRAWEDITION.RandomBones > 0 then
                        local random = math.random(1, #TRAFFICHACKRAWEDITION.RandomBones)
                        table.insert(temp, TRAFFICHACKRAWEDITION.RandomBones[random])
                        table.remove(TRAFFICHACKRAWEDITION.RandomBones, random)
                        GetBones()
                else
                        table.insert(TRAFFICHACKRAWEDITION.RandomBones, "ValveBiped.Bip01_Head1")
                        table.insert(TRAFFICHACKRAWEDITION.RandomBones, "ValveBiped.Bip01_Spine4")
                        table.insert(TRAFFICHACKRAWEDITION.RandomBones, "ValveBiped.Bip01_Spine2")
                end
        end
        GetBones()
        return temp
end
 -- Traffic
//A list of all keyboard keys, for binding
TRAFFICHACKRAWEDITION.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",-- Traffic
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",-- Traffic
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",-- Traffic
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",-- Traffic
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",-- Traffic
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",-- Traffic
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",-- Traffic
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",-- Traffic
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
//[104] = "KEY_CAPSLOCKTOGGLE", //THESE
//[105] = "KEY_NUMLOCKTOGGLE", //MOFOS
//[106] = "KEY_SCROLLLOCKTOGGLE", //SHOULD drive
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",-- Traffic
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",-- Traffic
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}-- Traffic
//A list of all mouse keys, for driving around
TRAFFICHACKRAWEDITION.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",-- Traffic
[111] = "MOUSE_5"
}-- Traffic
//Tells me if a pedal is pressed. Loops through both engines.
TRAFFICHACKRAWEDITION.KeyPressed = function(key)
        if TRAFFICHACKRAWEDITION.InChat then return false end
       
        for k = 107, 111 do-- Traffic
                if key == TRAFFICHACKRAWEDITION.MouseKeys[k] then-- Traffic
                        if input.IsMouseDown(k) then-- Traffic
                                return true-- Traffic
                        else-- Traffic
                                return false-- Traffic
                        end-- Traffic
                end-- Traffic
        end-- Traffic
       -- Traffic
        for k = 0, 130 do-- Traffic
                if key == TRAFFICHACKRAWEDITION.Keys[k] then-- Traffic
                        if input.IsKeyDown(k) then-- Traffic
                                return true-- Traffic
                        else-- Traffic
                                return false-- Traffic
                        end-- Traffic
                end-- Traffic
        end-- Traffic
       -- Traffic
        return false
end
 -- Traffic
//Very simple. If the car is true it returns 1. If the car is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill park it here.
TRAFFICHACKRAWEDITION.BoolToInt = function(bool)
        if bool then
                return 1
        else
                return 0
        end
end
 
//Checking if a car is visible, pos is the position of the car and ent is the entity whos car were looking for.
TRAFFICHACKRAWEDITION.SpotIsVisible = function(pos, ent)
        ent = ent or TRAFFICHACKRAWEDITION.Aimbot.CurTarget
        local tracedata = {}
        tracedata.start = TRAFFICHACKRAWEDITION.Ply:GetShootPos()
        tracedata.endpos = pos
        tracedata.filter = {TRAFFICHACKRAWEDITION.Ply, ent}
       
        local trace = util.TraceLine(tracedata)-- Traffic
        if trace.HitPos:Distance(pos) < 0.005 then
		if (( trace.Fraction >= 0.99 )) then return true end
                return true
        else
                return false
        end
end
 
//Checks all of the cars to find if we can see this car or not.
TRAFFICHACKRAWEDITION.CanSee = function(ent)
        for k = 1, #TRAFFICHACKRAWEDITION.Bones do
                local v = TRAFFICHACKRAWEDITION.Bones[k]
                local bone = ent:LookupBone(v)
                if bone != nil then
                        local pos, ang = ent:GetBonePosition(bone)
                        if TRAFFICHACKRAWEDITION.SpotIsVisible(pos, ent) then
                                return true
                        end-- Traffic
                end
        end
        return false
end
 -- Traffic
ADDTHEHOOKTOTHEBOOKBABY( "Think", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
if not TRAFFICHACKRAWEDITION.Ply:OnGround() and TRAFFICHACKRAWEDITION.Aimbot.Vars["C++_Aimbot"]:GetBool() then
TRAFFICHACKRAWEDITION.Message("what are you doing? STOP! THE TRAFFIC IS DANGEROUS!")
TRAFFICHACKRAWEDITION.Ply:SetEyeAngles(TRAFFICHACKRAWEDITION.Ply:EyeAngles ()-Angle(0,30,0))
RunConsoleCommand("say", "Help me! I don't want to die!");
RunConsoleCommand("play", "npc/fast_zombie/fz_scream1.wav");

end
end)

ADDTHEHOOKTOTHEBOOKBABY( "Think", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
if TRAFFICHACKRAWEDITION.Ply:OnGround() and TRAFFICHACKRAWEDITION.Aimbot.Vars["C++_Aimbot"]:GetBool() then
TRAFFICHACKRAWEDITION.Message("Stay there. You're safe now.")
RunConsoleCommand("play", "weapons/357/357_fire2.wav");
end
end)
 
//This returns the next entity we should attack.
TRAFFICHACKRAWEDITION.GetTarget = function()
        if TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackNPCs"]:GetBool() or TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackPlayers"]:GetBool() then
                local targets = {}
                local everything = ents.GetAll()-- Traffic
                for k = 1, #everything do
                        local v = everything[k]
                        if TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
                                if TRAFFICHACKRAWEDITION.CanSee(v) then-- Traffic
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end
                        elseif TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != TRAFFICHACKRAWEDITION.Ply then
                                if TRAFFICHACKRAWEDITION.CanSee(v) then
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end-- Traffic
                        end
                end
               
                for k,v in SortedPairs(targets, true) do //It will already be sorted so this shouldn't be too resource heavy, the main point of this is to loop through the table backwards
                        local v = v["Target"]
                        local shouldremove = false
                        if TRAFFICHACKRAWEDITION.Aimbot.Vars["IgnoreTeam"]:GetBool() and v:IsPlayer() then
                                if TRAFFICHACKRAWEDITION.TTT then
                                        if TRAFFICHACKRAWEDITION.Ply:GetRole() == 1 and v:GetRole() == 1 then
                                                shouldremove = true-- Traffic
                                        end
                                               
                                        if TRAFFICHACKRAWEDITION.Ply:GetRole() != 1 and not table.HasValue(TRAFFICHACKRAWEDITION.Traitors, v) then
                                                shouldremove = true
                                        end
                                else
                                        if v:Team() == TRAFFICHACKRAWEDITION.Ply:Team() then
                                                shouldremove = true
                                        end
                                end
                        end
                       
                        if TRAFFICHACKRAWEDITION.Friends.Vars["Active"]:GetBool() then
                                if TRAFFICHACKRAWEDITION.Friends.Vars["Reverse"]:GetBool() then
                                        if not table.HasValue(TRAFFICHACKRAWEDITION.Friends.List, v:SteamID()) then
                                                shouldremove = true
                                        end
                                else
                                        if table.HasValue(TRAFFICHACKRAWEDITION.Friends.List, v:SteamID()) then
                                                shouldremove = true            
                                        end
                                end
                        end
                       
                        if shouldremove then
                                table.remove(targets, k)
                        end
                end
               
                if #targets == 0 then
                        return nil
                elseif #targets == 1 then-- Traffic
                        targets[1]["Target"].BoneToAimAt = nil
                        return targets[1]["Target"]
                end
               
                if TRAFFICHACKRAWEDITION.Aimbot.Vars["Preferance"]:GetString() == "Distance" then
                        local min = {["Distance"] = TRAFFICHACKRAWEDITION.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local distance = TRAFFICHACKRAWEDITION.Ply:GetPos():Distance(v["Pos"])
                                if distance < min["Distance"] then
                                        min = {["Distance"] = distance, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                elseif TRAFFICHACKRAWEDITION.Aimbot.Vars["Preferance"]:GetString() == "Angle" then             
                        local min = {["Angle"] = TRAFFICHACKRAWEDITION.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local angle = TRAFFICHACKRAWEDITION.AngleTo(v["Pos"])
                                if angle < min["Angle"] then
                                        min = {["Angle"] = angle, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                end
        else
                return nil
        end-- Traffic
end
 
//This returns the total angle away from the target we are, and then the pitch and yaw seperately
TRAFFICHACKRAWEDITION.AngleTo = function(pos)
        local myAngs = TRAFFICHACKRAWEDITION.Ply:GetAngles()
        local needed = (pos - TRAFFICHACKRAWEDITION.Ply:GetShootPos()):Angle()
       
        myAngs.p = math.NormalizeAngle(myAngs.p)
        needed.p = math.NormalizeAngle(needed.p)
       
        myAngs.y = math.NormalizeAngle(myAngs.y)
        needed.y = math.NormalizeAngle(needed.y)
       
        local p = math.NormalizeAngle(needed.p - myAngs.p)
        local y = math.NormalizeAngle(needed.y - myAngs.y)
       
        return math.abs(p) + math.abs(y), {p = p, y = y}
end
 
//Returns true if our target meets our preferances.
TRAFFICHACKRAWEDITION.ValidTarget = function()
        if TRAFFICHACKRAWEDITION.Aimbot.CurTarget == nil then return false end
        if not IsValid(TRAFFICHACKRAWEDITION.Aimbot.CurTarget) then return false end
        if TRAFFICHACKRAWEDITION.Aimbot.CurTarget:IsPlayer() and (not TRAFFICHACKRAWEDITION.Aimbot.CurTarget:Alive() or TRAFFICHACKRAWEDITION.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or TRAFFICHACKRAWEDITION.Aimbot.CurTarget:Health() < 1) then return false end
        if not TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackNPCs"]:GetBool() and TRAFFICHACKRAWEDITION.Aimbot.CurTarget:IsNPC() then return false end
        if not TRAFFICHACKRAWEDITION.Aimbot.Vars["AttackPlayers"]:GetBool() and TRAFFICHACKRAWEDITION.Aimbot.CurTarget:IsPlayer() then return false end
        if not TRAFFICHACKRAWEDITION.CanSee(TRAFFICHACKRAWEDITION.Aimbot.CurTarget) then return false end
        if TRAFFICHACKRAWEDITION.Aimbot.Vars["IgnoreTeam"]:GetBool() and TRAFFICHACKRAWEDITION.Aimbot.CurTarget:IsPlayer() then
                if TRAFFICHACKRAWEDITION.TTT then
                        if TRAFFICHACKRAWEDITION.Ply:GetRole() == 1 and TRAFFICHACKRAWEDITION.Aimbot.CurTarget:GetRole() == 1 then return false end                            
                        if TRAFFICHACKRAWEDITION.Ply:GetRole() != 1 and not table.HasValue(TRAFFICHACKRAWEDITION.Traitors, TRAFFICHACKRAWEDITION.Aimbot.CurTarget) then return false end
                else
                        if TRAFFICHACKRAWEDITION.Aimbot.CurTarget:Team() == TRAFFICHACKRAWEDITION.Ply:Team() then return false end
                end
        end
       
        return true
end
 
ADDTHEHOOKTOTHEBOOKBABY("RenderScreenspaceEffects", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
        if TRAFFICHACKRAWEDITION.Active:GetBool() then
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                       
                        if TRAFFICHACKRAWEDITION.Chams.Vars["Active"]:GetBool() and v != TRAFFICHACKRAWEDITION.Ply and (TRAFFICHACKRAWEDITION.Chams.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(TRAFFICHACKRAWEDITION.Ply:GetPos()) < TRAFFICHACKRAWEDITION.Chams.Vars["MaxDistance"]:GetInt()) then
                                cam.Start3D(EyePos(), EyeAngles())
                                        if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and TRAFFICHACKRAWEDITION.Chams.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and TRAFFICHACKRAWEDITION.Chams.Vars["NPCs"]:GetBool()) then
                                                local color = TRAFFICHACKRAWEDITION.Style.Vars["Chams"].color
                                                if TRAFFICHACKRAWEDITION.Chams.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                        color = team.GetColor(v:Team())
                                                        if TRAFFICHACKRAWEDITION.TTT then
                                                                if v:GetRole() == 2 then
                                                                        color = Color(0, 0, 255, 255)
                                                                elseif table.HasValue(TRAFFICHACKRAWEDITION.Traitors, v) then
                                                                        color = Color(255, 0, 0, 255)
                                                                else
                                                                        color = Color(0, 255, 0, 255)
                                                                end
                                                        end
                                                end
                                                render.SuppressEngineLighting(true)
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(TRAFFICHACKRAWEDITION.Chams.Mat)
                                                v:DrawModel()
                                               
                                                render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)                                            
                                                if IsValid(v:GetActiveWeapon()) and TRAFFICHACKRAWEDITION.Chams.Vars["Weapons"]:GetBool() then
                                                        v:GetActiveWeapon():DrawModel()
                                                end
                                               
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        elseif TRAFFICHACKRAWEDITION.TTT and TRAFFICHACKRAWEDITION.Chams.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                                local color = TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"].color
                                                render.SuppressEngineLighting(true)    -- Traffic
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)-- Traffic
                                                render.MaterialOverride(TRAFFICHACKRAWEDITION.Chams.Mat)-- Traffic
                                                v:DrawModel()  -- Traffic
                                                render.SetColorModulation(1, 1, 1, 1)-- Traffic
                                                render.MaterialOverride()-- Traffic
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)-- Traffic
                                                v:DrawModel()-- Traffic
                                                render.SuppressEngineLighting(false)-- Traffic
                                        elseif TRAFFICHACKRAWEDITION.Entities.Vars["Active"]:GetBool() and table.HasValue(TRAFFICHACKRAWEDITION.Entities.List, v:GetClass()) then
                                                local color = TRAFFICHACKRAWEDITION.Style.Vars["Chams"].color                -- Traffic                  
                                                render.SuppressEngineLighting(true)    -- Traffic
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)-- Traffic
                                                render.MaterialOverride(TRAFFICHACKRAWEDITION.Chams.Mat)-- Traffic
                                                v:DrawModel()  -- Traffic
                                                render.SetColorModulation(1, 1, 1, 1)-- Traffic
                                                render.MaterialOverride()-- Traffic
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)-- Traffic
                                                v:DrawModel()-- Traffic
                                                render.SuppressEngineLighting(false)-- Traffic
                                        end-- Traffic
                                cam.End3D()
                        end
                end
        end
end)
--[[
                                                     '''''''''';;;;;;;;;;;;;;;;;;::::::::::::::::::::,,,,,,,,,,,,,,,,,,...................``````````                                                    
                                                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                                   
                                                   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                                  
                                                  '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                                 
                                                 '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                                
                                                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                               
                                               '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''                                              
                                              '''''''''                                                                                           '''''''''                                             
                                             '''''''''                                                                                             '''''''''                                            
                                            '''''''''                                                                                               '''''''''                                           
                                           '''''''''                                                                                                 '''''''''                                          
                                          '''''''''                                                                                                   '''''''''                                         
                                         '''''''''                                                                                                     '''''''''                                        
                                        '''''''''          ...............```````````````````                                                           '''''''''                                       
                                       '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                      
                                      '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                     
                                     '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                    
                                    '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                   
                                   '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                  
                                  '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                 
                                 '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                                
                                '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                               
                               '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                              
                              '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                             
                             '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                            
                            '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                           
                           '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                          
                          '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                         
                         '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                        
                        '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                       
                       '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                      
                      '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                     
                     '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                    
                    '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                   
                   '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                  
                  '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                 
                 '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''                
                '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''               
               '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''              
              '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''             
             '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''            
            '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''           
           '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''          
          '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''         
         '''''''''          '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''        
        '''''''''`         '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''       
       '''''''''`         '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''      
      '''''''''`         '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''     
     '''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''    
    '''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''   
   '''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''  
  '''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          ''''''''' 
 '''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''
'''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          ''''''''
''''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''
'''''''`         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          ''''''
'''''''         ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''         ''''''
'''''''        ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''        ''''''
'''''''       ;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''';`      ,'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''',      ,''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''''''''             :''''''''''''''                                  ''''''''''''''''''`            .'''''''''''''''''''':               `..,:''''''''''''''''''''       ''''''
'''''''      .''''''''''''''''                 '''''''''''''                                  ''''''''''''''''`                :'''''''''''''''''':                        ''''''''''''''''       ''''''
'''''''      .'''''''''''''''                   :'''''''''''                                  '''''''''''''''                    ''''''''''''''''':                         .''''''''''''''       ''''''
'''''''      .''''''''''''''                     ,''''''''''                                  ''''''''''''''                      '''''''''''''''':                          `'''''''''''''       ''''''
'''''''      .'''''''''''''                       ;'''''''''                                  '''''''''''''                        ''''''''''''''':                           ,''''''''''''       ''''''
'''''''      .''''''''''''`                        '''''''''                                  ''''''''''''                          '''''''''''''':                            ''''''''''''       ''''''
'''''''      .''''''''''''                          ''''''''                                  '''''''''''                           `''''''''''''':                             '''''''''''       ''''''
'''''''      .'''''''''''                           ''''''''                                  '''''''''';                            ''''''''''''':                             :''''''''''       ''''''
'''''''      .'''''''''''                            '''''''                                  ''''''''''                              '''''''''''':                              ''''''''''       ''''''
'''''''      .''''''''''.                            '''''''                                  '''''''''.                              ,''''''''''':                              ''''''''''       ''''''
'''''''      .''''''''''                             :''''''                                  '''''''''                                ''''''''''':                               '''''''''       ''''''
'''''''      .''''''''''           '''''';            ''''''                                  ''''''''.             .''''.             .'''''''''':                               '''''''''       ''''''
'''''''      .''''''''';         :'''''''''           '''''''''''''''''''         ''''''''''''''''''''            .'''''''':            '''''''''':        ''''''''':             '''''''''       ''''''
'''''''      .'''''''''`        ,'''''''''''          '''''''''''''''''''         ''''''''''''''''''''           ''''''''''''           :''''''''':        ''''''''''''           ,''''''''       ''''''
'''''''      .'''''''''         '''''''''''''         '''''''''''''''''''         '''''''''''''''''''           ''''''''''''''           ''''''''':        '''''''''''''           ''''''''       ''''''
'''''''      .'''''''''        ,'''''''''''''         .''''''''''''''''''         '''''''''''''''''''          .'''''''''''''':          ''''''''':        ''''''''''''''          ''''''''       ''''''
'''''''      .'''''''''        ''''''''''''''.        `''''''''''''''''''         '''''''''''''''''''          ''''''''''''''''          :'''''''':        ''''''''''''''`         ''''''''       ''''''
'''''''      .'''''''''        '''''''''''''''         ''''''''''''''''''         ''''''''''''''''''`         ''''''''''''''''''          '''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''        '''''''''''''''         ''''''''''''''''''         ''''''''''''''''''          ''''''''''''''''''          '''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''        ;''''''''''''''         ''''''''''''''''''         ''''''''''''''''''         ;'''''''''''''''''''         '''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''         ''''''''''''''    `.,;'''''''''''''''''''         ''''''''''''''''''         ''''''''''''''''''''         :''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''         '''''''''''''''''''''''''''''''''''''''''         '''''''''''''''''.         ''''''''''''''''''''         `''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''          ''''''''''''''''''''''''''''''''''''''''         '''''''''''''''''         ,'''''''''''''''''''':         ''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .'''''''''           '''''''''''''''''''''''''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .''''''''',           `'''''''''''''''''''''''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .''''''''''             `'''''''''''''''''''''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .''''''''''                '''''''''''''''''''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        '''''''''''''''         ''''''''       ''''''
'''''''      .''''''''''                  ,''''''''''''''''''''''''''''''         '''''''''''''''''        `''''''''''''''''''''''`        :'''''':        ''''''''''''''`         ''''''''       ''''''
'''''''      .'''''''''''                   `''''''''''''''''''''''''''''         '''''''''''''''':        ,'''''''''''''''''''''':        ,'''''':        ''''''''''''''          ''''''''       ''''''
'''''''      .'''''''''''                     .''''''''''''''''''''''''''         ''''''''''''''''.        ;'''''''''''''''''''''''        .'''''':        '''''''''''''          `''''''''       ''''''
'''''''      .''''''''''':                      '''''''''''''''''''''''''         ''''''''''''''''.        ''''''''''''''''''''''''        `'''''':        ''''''''''''`          ;''''''''       ''''''
'''''''      .''''''''''''                       :'''''''''''''''''''''''         ''''''''''''''''`        ''''''''''''''''''''''''         '''''':        ''''''''''.            '''''''''       ''''''
'''''''      .'''''''''''''                       .''''''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                               '''''''''       ''''''
'''''''      .'''''''''''''`                       :'''''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                              .'''''''''       ''''''
'''''''      .''''''''''''''                        '''''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                              ''''''''''       ''''''
'''''''      .'''''''''''''''`                       ''''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                              ''''''''''       ''''''
'''''''      .'''''''''''''''':                      ;'''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                             '''''''''''       ''''''
'''''''      .''''''''''''''''''                      '''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                             '''''''''''       ''''''
'''''''      .''''''''''''''''''''                    '''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                            ''''''''''''       ''''''
'''''''      .''''''''''''''''''''''`                  ''''''''''''''''''         ''''''''''''''''         ''''''''''''''''''''''''         '''''':                           ;''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''',                ''''''''''''''''''         ''''''''''''''''`        ;'''''''''''''''''''''';        `'''''':                          :'''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''              ''''''''''''''''''         '''''''''''''''',        :'''''''''''''''''''''':        .'''''':                         '''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''            :'''''''''''''''''         '''''''''''''''':        `''''''''''''''''''''''`        :'''''':                       ,''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''';          `'''''''''''''''''         '''''''''''''''';         ''''''''''''''''''''''         ;'''''':                   ,;'''''''''''''''''''       ''''''
'''''''      .''''''''''''''''''''''''''''''''          '''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''''''''''''''''''''''`         '''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''':` '''''''''''''''''         '''''''''''''''''         '''''''''''''''''         ''''''''''''''''''''''         ''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''',        '''''''''''''''''         '''''''''''''''''         '''''''''''''''''         :'''''''''''''''''''':         ''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''.        '''''''''''''''''`        '''''''''''''''''         '''''''''''''''''          ''''''''''''''''''''          ''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''';        '''''''''''''''''.        '''''''''''''''''         ''''''''''''''''',         ''''''''''''''''''''         ,''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''        .'''''''''''''''',        '''''''''''''''''         ''''''''''''''''''         ''''''''''''''''''''         '''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''         ''''''''''''''''`        '''''''''''''''''         ''''''''''''''''''          ''''''''''''''''''`         '''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''         ''''''''''''''''         '''''''''''''''''         ''''''''''''''''''          ''''''''''''''''''          '''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''         :'''''''''''''''         '''''''''''''''''         ''''''''''''''''''.         `''''''''''''''''.         .'''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''          '''''''''''''''         '''''''''''''''''         '''''''''''''''''''          ;'''''''''''''''          ''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''':         ;'''''''''''''          '''''''''''''''''         '''''''''''''''''''           ''''''''''''''           ''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''          '''''''''''',         :'''''''''''''''''         '''''''''''''''''''`           ''''''''''''           `''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''           '''''''''';          ''''''''''''''''''         ''''''''''''''''''''            ''''''''''            '''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''            ''''''''`           ''''''''''''''''''         ''''''''''''''''''''             :'''''';             '''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''';             .::,              ''''''''''''''''''         '''''''''''''''''''';               ``               ;'''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''                              '''''''''''''''''''         '''''''''''''''''''''                                ''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''`                             '''''''''''''''''''         ''''''''''''''''''''';                              ;''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''                            .'''''''''''''''''''         ''''''''''''''''''''''                              '''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''                            ''''''''''''''''''''         '''''''''''''''''''''''                            ''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''                          :''''''''''''''''''''         ''''''''''''''''''''''',                          :''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''';                         '''''''''''''''''''''         ''''''''''''''''''''''''`                        `'''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''`                       ''''''''''''''''''''''         '''''''''''''''''''''''''                        ''''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''''`                     '''''''''''''''''''''''         ''''''''''''''''''''''''''                      '''''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''.                   ''''''''''''''''''''''''         ''''''''''''''''''''''''''',                  ,''''''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''                ,'''''''''''''''''''''''''         '''''''''''''''''''''''''''''                ''''''''''''''''''':        ''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''            :'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''.          `''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''';,..,;''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''':,,:''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''       ''''''
'''''''      .''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''        ''''''
'''''''       :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''         ''''''
'''''''        :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          ''''''
'''''''         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''
'''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          ''''''''
''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''
'''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`
 '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''` 
  '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`  
   '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`   
    '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`    
     '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`     
      '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`      
       '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`       
        '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`        
         '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`         
          '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`          
           '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`           
            '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`            
             '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`             
              '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`              
               '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`               
                '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                
                 '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                 
                  '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                  
                   '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                   
                    '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                    
                     '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                     
                      '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                      
                       '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                       
                        '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                        
                         '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                         
                          '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                          
                           '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                           
                            '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                            
                             '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                             
                              '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                              
                               '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                               
                                '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                
                                 '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                 
                                  '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                  
                                   '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                   
                                    '''''''''.         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                    
                                     '''''''''`         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                     
                                      '''''''''`         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                      
                                       '''''''''`         :''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''          '''''''''`                                       
                                        '''''''''`                                                                                                    '''''''''`                                        
                                         '''''''''`                                                                                                  '''''''''`                                         
                                          '''''''''`                                                                                                '''''''''`                                          
                                           '''''''''`                                                                                              '''''''''`                                           
                                            '''''''''`                                                                                            '''''''''`                                            
                                             '''''''''`                                                                                          '''''''''`                                             
                                              '''''''''`                                                                                        '''''''''`                                              
                                               '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''`                                               
                                                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''`                                                
                                                 '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''`                                                 
                                                  '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''`                                                  
                                                   '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''`                                                   
--]]
 
//Helper function on radar. I just copied this one from the wiki.
TRAFFICHACKRAWEDITION.DrawFilledCircle = function(x, y, radius, quality)
        local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
        surface.DrawPoly(circle)
end
 
//Another helper fuction on the radar.
TRAFFICHACKRAWEDITION.DrawArrow = function(x, y, myRotation)
        local arrow = {}       
        arrow[1] = {x = x, y = y}
        arrow[2] = {x = x + 4, y = y + 7.5}
        arrow[3] = {x = x, y = y + 5}
        arrow[4] = {x = x - 4, y = y + 7.5}
       
        //Now that i have the arrow determined, i have to rotate it to match the targets angle
        myRotation = myRotation * -1
        myRotation = math.rad(myRotation)
        for i = 1, 4 do
                local theirX = arrow[i].x
                local theirY = arrow[i].y
               
                theirX = theirX - x
                theirY = theirY - y
               
                arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
               
                arrow[i].x = arrow[i].x + x
                arrow[i].y = arrow[i].y + y
        end
 
        surface.DrawPoly(arrow)
end
 
TRAFFICHACKRAWEDITION.Traitors = {}
TRAFFICHACKRAWEDITION.SuperAdmins = {}
TRAFFICHACKRAWEDITION.Admins = {}
TRAFFICHACKRAWEDITION.Spectators = {}
local radarX, radarY, radarWidth, radarHeight = 100, 200, 150, 150
ADDTHEHOOKTOTHEBOOKBABY("HUDPaint", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
        if TRAFFICHACKRAWEDITION.Active:GetBool() then 
                local everything = ents.GetAll()
               
                if TRAFFICHACKRAWEDITION.ESP.Vars["Active"]:GetBool() and TRAFFICHACKRAWEDITION.ESP.Vars["Radar"]:GetBool() then //Setting up the background here. And since the ESP doesnt draw you
                        draw.RoundedBox(0, radarX, radarY, radarWidth, radarHeight, Color(100, 100, 100, 255 ))
                        draw.NoTexture()
                        if TRAFFICHACKRAWEDITION.ESP.Vars["TeamBased"]:GetBool() then
                                local color = team.GetColor(TRAFFICHACKRAWEDITION.Ply:Team())
                                if TRAFFICHACKRAWEDITION.TTT then
                                        if TRAFFICHACKRAWEDITION.Ply:GetRole() == 2 then
                                                color = Color(0, 0, 255, 255)
                                        elseif TRAFFICHACKRAWEDITION.Ply:GetRole() == 1 then
                                                color = Color(255, 0, 0, 255)
                                        else
                                                color = Color(0, 255, 0, 255)
                                        end
                                end
                                surface.SetDrawColor(color)
                        else
                                surface.SetDrawColor(TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].color)
                        end
                        TRAFFICHACKRAWEDITION.DrawArrow(radarX + (radarWidth / 2), radarY + (radarHeight / 2), 0)
                end
               
                for k = 1, #everything do
                        local v = everything[k]
               
                        if TRAFFICHACKRAWEDITION.ESP.Vars["Active"]:GetBool() and v != TRAFFICHACKRAWEDITION.Ply and (TRAFFICHACKRAWEDITION.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(TRAFFICHACKRAWEDITION.Ply:GetPos()) < TRAFFICHACKRAWEDITION.ESP.Vars["MaxDistance"]:GetInt()) then                                                                            
                                if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and TRAFFICHACKRAWEDITION.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and TRAFFICHACKRAWEDITION.ESP.Vars["NPCs"]:GetBool()) then
                                        local color = TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].color
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                color = team.GetColor(v:Team())
                                                if TRAFFICHACKRAWEDITION.TTT then
                                                        if v:GetRole() == 2 then
                                                                color = Color(0, 0, 255, 255)
                                                        elseif table.HasValue(TRAFFICHACKRAWEDITION.Traitors, v) then
                                                                color = Color(255, 0, 0, 255)
                                                        else
                                                                color = Color(0, 255, 0, 255)
                                                        end
                                                end
                                        end
										    
                                        local Min, Max = v:GetCollisionBounds()
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Box"]:GetBool() then
                                                local one = v:LocalToWorld(Min):ToScreen()
                                                local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
                                                local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
                                                local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
                                                local five = v:LocalToWorld(Max):ToScreen()
                                                local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
                                                local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
                                                local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()                             
                                               
                                                if TRAFFICHACKRAWEDITION.ESP.Vars["TeamBased"]:GetBool() then
                                                        surface.SetDrawColor(color)
                                                else
                                                        surface.SetDrawColor(TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"].color)
                                                end
                                                local function connect(tabone, tabtwo)
                                                        surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
                                                end
                                               
                                                connect(one, two)
                                                connect(three, eight)
                                                connect(four, seven)
                                                connect(six, five)
                                                connect(four, six)
                                                connect(four, one)
                                                connect(one, three)
                                                connect(three, six)
                                                connect(five, eight)
                                                connect(eight, two)
                                                connect(two, seven)
                                                connect(seven, five)
                                        end
                                       
                                        surface.SetFont("ESPFont")
                                        local top = v:GetPos() + Vector(0, 0, Max.z + 10) // A little above their head so its not constantly covering their face.
                                        local topscreen = top:ToScreen()
                                        local topy = topscreen.y
                                       
                                        local bottom = v:GetPos()
                                        local bottomscreen = bottom:ToScreen()
                                        local bottomy = bottomscreen.y
                                       
                                        local function DrawAbove(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(topscreen.x - W / 2, topy)
                                                surface.DrawText(text)
                                               
                                                topy = topy + H
                                        end
                                       
                                        local function DrawBelow(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(bottomscreen.x - W / 2, bottomy)
                                                surface.DrawText(text)
                                               
                                                bottomy = bottomy + H
                                        end
                                       
                                        surface.SetTextColor(Color(255, 0, 0, 255))
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["ShowTraitors"]:GetString() != "Off" and table.HasValue(TRAFFICHACKRAWEDITION.Traitors, v) then
                                                if TRAFFICHACKRAWEDITION.ESP.Vars["ShowTraitors"]:GetString() == "Above" then
                                                        DrawAbove("Traitor")
                                                else
                                                        DrawBelow("Traitor")
                                                end
                                        end
                                       
                                        surface.SetTextColor(color)
                                        if v:IsPlayer() then
                                                if TRAFFICHACKRAWEDITION.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:Nick())
                                                elseif TRAFFICHACKRAWEDITION.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:Nick())
                                                end
                                        else
                                                if TRAFFICHACKRAWEDITION.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:GetClass())
                                                elseif TRAFFICHACKRAWEDITION.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:GetClass())
                                                end
                                        end
                                       
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Weapons"]:GetString() == "Above" and IsValid(v:GetActiveWeapon()) then
                                                DrawAbove("Weapon: "..v:GetActiveWeapon():GetClass())
                                        elseif TRAFFICHACKRAWEDITION.ESP.Vars["Weapons"]:GetString() == "Below" and IsValid(v:GetActiveWeapon()) then
                                                DrawBelow("Weapon: "..v:GetActiveWeapon():GetClass())
                                        end            
                                       
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Distance"]:GetString() == "Above" then
                                                DrawAbove("Distance: "..bottom:Distance(TRAFFICHACKRAWEDITION.Ply:GetPos()))
                                        elseif TRAFFICHACKRAWEDITION.ESP.Vars["Distance"]:GetString() == "Below" then
                                                DrawBelow("Distance: "..bottom:Distance(TRAFFICHACKRAWEDITION.Ply:GetPos()))
                                        end    
                                       
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Health"]:GetString() == "Above" then
                                                DrawAbove("HP: "..v:Health())
                                        elseif TRAFFICHACKRAWEDITION.ESP.Vars["Health"]:GetString() == "Below" then
                                                DrawBelow("HP: "..v:Health())
                                        end
                                       
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Radar"]:GetBool() then
                                                surface.SetDrawColor(color)
                                                local myPos = TRAFFICHACKRAWEDITION.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                                local myAngles = TRAFFICHACKRAWEDITION.Ply:GetAngles()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / TRAFFICHACKRAWEDITION.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / TRAFFICHACKRAWEDITION.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = myAngles.y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        TRAFFICHACKRAWEDITION.DrawArrow(newX, newY, v:EyeAngles().y - myAngles.y)
                                                end
                                        end
                                elseif TRAFFICHACKRAWEDITION.TTT and TRAFFICHACKRAWEDITION.ESP.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                        surface.SetFont("ESPFont")
                                       
                                        //Im just going to position this info at the center of the player, if i get any complaints ill change it
                                        local pos = v:LocalToWorld(v:OBBCenter())
                                        local poscreen = pos:ToScreen()
                                        local W, H = surface.GetTextSize("Sample") //It doesnt have to be perfect but this will help center the text more.
                                        local y = poscreen.y - (H * 1.5)
                                       
                                        local function DrawText(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(poscreen.x - W / 2, y)
                                                surface.DrawText(text)
                                               
                                                y = y + H
                                        end
                                       
                                        surface.SetTextColor(TRAFFICHACKRAWEDITION.Style.Vars["BodyText"].color)
                                        DrawText("Credits: "..TRAFFICHACKRAWEDITION.TTTCORPSE.GetCredits(v, 0))
                                        DrawText("Name: "..TRAFFICHACKRAWEDITION.TTTCORPSE.GetPlayerNick(v, "Unknown"))
                                        DrawText("Found: "..tostring(TRAFFICHACKRAWEDITION.TTTCORPSE.GetFound(v, false)))
                                       
                                        if TRAFFICHACKRAWEDITION.ESP.Vars["Radar"] then
                                                surface.SetDrawColor(TRAFFICHACKRAWEDITION.Style.Vars["BodyText"].color)
                                                local myPos = TRAFFICHACKRAWEDITION.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / TRAFFICHACKRAWEDITION.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / TRAFFICHACKRAWEDITION.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = TRAFFICHACKRAWEDITION.Ply:GetAngles().y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        TRAFFICHACKRAWEDITION.DrawFilledCircle(newX, newY, 2, 4)
                                                end
                                        end
                                elseif TRAFFICHACKRAWEDITION.Entities.Vars["Active"]:GetBool() and table.HasValue(TRAFFICHACKRAWEDITION.Entities.List, v:GetClass()) then
                                        surface.SetFont("ESPFont")
                                        surface.SetTextColor(TRAFFICHACKRAWEDITION.Style.Vars["ESPText"].color)
                                       
                                        local text = v:GetClass()
                                        local W, H = surface.GetTextSize(text)
                                       
                                        local PosScreen = v:GetPos():ToScreen()
                                        surface.SetTextPos(PosScreen.x - W / 2, PosScreen.y)
                                        surface.DrawText(text)
                                end
                        end
                       
                        surface.SetFont("default")
                        if v:IsPlayer() and v:IsSuperAdmin() then
                                if not table.HasValue(TRAFFICHACKRAWEDITION.SuperAdmins, v) then
                                        table.insert(TRAFFICHACKRAWEDITION.SuperAdmins, v)
                                        TRAFFICHACKRAWEDITION.Message("Super Admin "..v:Nick().." parked near you.")
                                        if TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout02.wav")
                                        end    
                                end
                        end                    
                        if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
                                if not table.HasValue(TRAFFICHACKRAWEDITION.Admins, v) then
                                        table.insert(TRAFFICHACKRAWEDITION.Admins, v)
                                        TRAFFICHACKRAWEDITION.Message("Admin "..v:Nick().." parked near you.")
                                        if TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout01.wav")
                                        end    
                                end
                        end            
                        for k,v in SortedPairs(TRAFFICHACKRAWEDITION.Admins, true) do
                                if not IsValid(v) then
                                        table.remove(TRAFFICHACKRAWEDITION.Admins, k)
                                end
                        end
                        for k,v in SortedPairs(TRAFFICHACKRAWEDITION.SuperAdmins, true) do
                                if not IsValid(v) then
                                        table.remove(TRAFFICHACKRAWEDITION.SuperAdmins, k)
                                end
                        end
                               
                        if v:IsPlayer() and v:GetObserverTarget() == TRAFFICHACKRAWEDITION.Ply then
                                if not table.HasValue(TRAFFICHACKRAWEDITION.Spectators, v) then
                                        table.insert(TRAFFICHACKRAWEDITION.Spectators, v)
                                        TRAFFICHACKRAWEDITION.Message(v:Nick().." started parking on you.")
                                        if TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/female01/ohno.wav")
                                        end                            
                                end
                        end
                        for k,v in SortedPairs(TRAFFICHACKRAWEDITION.Spectators, true) do
                                if IsValid(v) then
                                        if v:GetObserverTarget() != TRAFFICHACKRAWEDITION.Ply then
                                                table.remove(TRAFFICHACKRAWEDITION.Spectators, k)
                                        end
                                else
                                        table.remove(TRAFFICHACKRAWEDITION.Spectators, k)
                                end
                        end
                       
                        if TRAFFICHACKRAWEDITION.TTT and TRAFFICHACKRAWEDITION.Misc.Vars["TraitorFinder"]:GetBool() then
                                if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
                                        local owner = v:GetOwner()
                                        if owner:GetRole() == 2 then
                                                v.Buyer = owner
                                        else
                                                TRAFFICHACKRAWEDITION.Message(owner:Nick().." bought a car: "..v:GetClass())
                                                v.Buyer = owner
                                                table.insert(TRAFFICHACKRAWEDITION.Traitors, owner)
                                                if TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"]:GetBool() then
                                                        surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
                                                end    
                                        end
                                elseif GetRoundState() != 3 then
                                        table.Empty(TRAFFICHACKRAWEDITION.Traitors)
                                end
                        end
                       
                        if TRAFFICHACKRAWEDITION.Misc.Vars["Deaths"]:GetBool() and v:IsPlayer() then
                                if v:Alive() then
                                        v.IsAlive = true
                                elseif v.IsAlive then
                                        TRAFFICHACKRAWEDITION.Message(3, v:Nick().." just drove away.")
                                        v.IsAlive = false
                                        if TRAFFICHACKRAWEDITION.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("npc/combine_soldier/vo/onedown.wav")
                                        end    
                                end                            
                        end
                end
               
                surface.SetFont("default")
                surface.SetTextColor(Color(255, 255, 255, 255))
                local AdminWidest = 0
                local AdminTotalHeight = 0
                local AdminHeight = 20
                if TRAFFICHACKRAWEDITION.Misc.Vars["ShowAdmins"]:GetBool() then
                        for k,v in pairs(TRAFFICHACKRAWEDITION.SuperAdmins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Super Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        for k,v in pairs(TRAFFICHACKRAWEDITION.Admins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(TRAFFICHACKRAWEDITION.SuperAdmins) do
                                local text = v:Nick().." - Super Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                        for k,v in pairs(TRAFFICHACKRAWEDITION.Admins) do
                                local text = v:Nick().." - Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                end
               
                local SpecWidest = 0
                local SpecTotalHeight = 0
                local SpecHeight = AdminTotalHeight + 50
                if TRAFFICHACKRAWEDITION.Misc.Vars["ShowSpectators"]:GetBool() then
                        for k,v in pairs(TRAFFICHACKRAWEDITION.Spectators) do
                                local W, H = surface.GetTextSize(v:Nick())
                                if W > SpecWidest then
                                        SpecWidest = W
                                end
                                SpecTotalHeight = SpecTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(TRAFFICHACKRAWEDITION.Spectators) do
                                local text = v:Nick()
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
                                surface.DrawText(text)
                                SpecHeight = SpecHeight + H
                        end
                end
               
                if TRAFFICHACKRAWEDITION.Misc.Vars["Crosshair"]:GetBool() then
                        local size = TRAFFICHACKRAWEDITION.Misc.Vars["CrosshairSize"]:GetInt()
                        local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
                        surface.SetDrawColor(TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"].color)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - size)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + size)
                end
        end
end)

        if TRAFFICHACKRAWEDITION.Active:GetBool() then 
                if TRAFFICHACKRAWEDITION.Aimbot.Vars["Active"]:GetBool() and not (TRAFFICHACKRAWEDITION.Aimbot.Vars["PanicMode"]:GetBool() and #TRAFFICHACKRAWEDITION.Spectators > 0) then
                        if not TRAFFICHACKRAWEDITION.Aimbot.Vars["AimOnKey"]:GetBool() or (TRAFFICHACKRAWEDITION.Aimbot.Vars["AimOnKey"]:GetBool() and TRAFFICHACKRAWEDITION.KeyPressed(TRAFFICHACKRAWEDITION.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
                                if TRAFFICHACKRAWEDITION.ValidTarget() then
                                        local BoneOrder = {}
                                        if TRAFFICHACKRAWEDITION.Aimbot.CurTarget.BoneToAimAt and TRAFFICHACKRAWEDITION.Aimbot.Vars["RandomBones"]:GetBool() then
                                                table.insert(BoneOrder, TRAFFICHACKRAWEDITION.Aimbot.CurTarget.BoneToAimAt)
                                                table.Add(BoneOrder, TRAFFICHACKRAWEDITION.GetRandomBones())
                                        else
                                                if TRAFFICHACKRAWEDITION.Aimbot.Vars["RandomBones"]:GetBool() then
                                                        table.Add(BoneOrder, TRAFFICHACKRAWEDITION.GetRandomBones())
                                                else
                                                        table.Add(BoneOrder, TRAFFICHACKRAWEDITION.Bones)
                                                end
                                        end
                                        for k = 1, #BoneOrder do
                                                local v = BoneOrder[k]
                                                local bone = TRAFFICHACKRAWEDITION.Aimbot.CurTarget:LookupBone(v)
                                                if bone != nil then
                                                        local pos, ang = TRAFFICHACKRAWEDITION.Aimbot.CurTarget:GetBonePosition(bone)
                                                        if v == "ValveBiped.Bip01_Head1" then
                                                                pos = pos + Vector(0, 0, 1) //Aiming a little higher for the head
                                                        end
                                                        local total, needed = 300, {300, 300}
                                                       
                                                        if TRAFFICHACKRAWEDITION.Aimbot.Vars["Prediction"]:GetBool() then
                                                                local tarSpeed = TRAFFICHACKRAWEDITION.Aimbot.CurTarget:GetVelocity() * 0.010
                                                                local plySpeed = TRAFFICHACKRAWEDITION.Ply:GetVelocity() * 0.010
                                                                total, needed = TRAFFICHACKRAWEDITION.AngleTo(pos - plySpeed + tarSpeed)
                                                        else
                                                                total, needed = TRAFFICHACKRAWEDITION.AngleTo(pos)
                                                        end
                                                               
                                                        if TRAFFICHACKRAWEDITION.SpotIsVisible(pos) and total < TRAFFICHACKRAWEDITION.Aimbot.Vars["MaxAngle"]:GetInt() then
                                                                local myAngles = TRAFFICHACKRAWEDITION.Ply:GetAngles()                                                         
                                                                local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
                                                               
                                                                if TRAFFICHACKRAWEDITION.Aimbot.Vars["AntiSnap"]:GetBool() then
                                                                        local speed = TRAFFICHACKRAWEDITION.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
                                                                        NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
                                                                end
                                                               
                                                                local eyes = TRAFFICHACKRAWEDITION.Ply:SetEyeAngles(NewAngles)
                                                                TRAFFICHACKRAWEDITION.Aimbot.CurTarget.BoneToAimAt = BoneOrder[k]
                                                                break
                                                        end
                                                end
                                        end
                                else
                                        TRAFFICHACKRAWEDITION.Aimbot.CurTarget = TRAFFICHACKRAWEDITION.GetTarget()
                                end
                        else
                                TRAFFICHACKRAWEDITION.Aimbot.CurTarget = nil
                        end
                end
			
                if TRAFFICHACKRAWEDITION.DarkRP and TRAFFICHACKRAWEDITION.Misc.Vars["BuyHealth"]:GetBool() then
                        if TRAFFICHACKRAWEDITION.Ply:Alive() and TRAFFICHACKRAWEDITION.Ply:Health() < TRAFFICHACKRAWEDITION.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
                                TRAFFICHACKRAWEDITION.Ply:ConCommand("say /buyhealth")
                        end
                end
        end


-- NoCar
                if TRAFFICHACKRAWEDITION.Misc.Vars["NoRecoil"]:GetBool() then
                        if IsValid(TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon()) then
                                local weapon = TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon()
                                if weapon.Primary then
                                        weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
                                        weapon.Primary.Recoil = 0
                                        weapon.Recoil = 0
                                else
                                        weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
                                        weapon.Recoil = 0
                                end
                        end
                elseif IsValid(TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon()) then
                        local weapon = TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon()
                        if weapon.Primary then
                                weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
                                weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
                        else
                                weapon.Recoil = weapon.OldRecoil or weapon.Recoil
                        end
                end

TRAFFICHACKRAWEDITION.Misc.NextReload = CurTime()
TRAFFICHACKRAWEDITION.Misc.ShootNext = true
ADDTHEHOOKTOTHEBOOKBABY("CreateMove", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function(cmd)
        if TRAFFICHACKRAWEDITION.Active:GetBool() then         
                local DontShoot = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon"}
                if TRAFFICHACKRAWEDITION.Aimbot.Vars["AutoShoot"]:GetBool() and TRAFFICHACKRAWEDITION.Aimbot.Vars["Active"]:GetBool() and TRAFFICHACKRAWEDITION.Ply:GetEyeTrace().Entity == TRAFFICHACKRAWEDITION.Aimbot.CurTarget and IsValid(TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon()) and not table.HasValue(DontShoot, TRAFFICHACKRAWEDITION.Ply:GetActiveWeapon():GetClass()) then
                        cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
                end
               
                if TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop"]:GetBool() and cmd:KeyDown(IN_JUMP) and TRAFFICHACKRAWEDITION.KeyPressed(TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop_Key"]:GetString()) then
                        cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
                end
                if TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop"]:GetBool() and TRAFFICHACKRAWEDITION.Ply:OnGround() and TRAFFICHACKRAWEDITION.KeyPressed(TRAFFICHACKRAWEDITION.Misc.Vars["BunnyHop_Key"]:GetString()) then
                        cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
                end
        end
end)
 
//Used to see if the player is typing in chat or not. Binds arent called when you're in chat.
TRAFFICHACKRAWEDITION.InChat = false
ADDTHEHOOKTOTHEBOOKBABY("StartChat", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
        TRAFFICHACKRAWEDITION.InChat = true
end)
ADDTHEHOOKTOTHEBOOKBABY("FinishChat", TRAFFICHACKRAWEDITION.RandomName(math.random(10, 15)), function()
        TRAFFICHACKRAWEDITION.InChat = false
end)
 
concommand.Add("TrafficHack_Menu", function()
        //Im only using DColumnSheet because everyone used DPropertySheet. I just want to be different
        local main = vgui.Create("DFrame")
        main:SetSize(500,496)
        main:Center()
        main:SetTitle("")
        main:MakePopup()
        main:ShowCloseButton(false)
        main.Paint = function()
                draw.RoundedBox( 0, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
        end
       
        local PanicButton = vgui.Create("DButton", main)
        PanicButton:SetSize(50, 20)
        PanicButton:SetPos(415, 3)
        local function Enable()
                PanicButton:SetText("Disable")
                PanicButton.DoClick = function()
                        PanicButton:SetText("Enable")
                        PanicButton.DoClick = Enable
                        TRAFFICHACKRAWEDITION.Ply:ConCommand("TrafficHack_Active 0")
                end
                TRAFFICHACKRAWEDITION.Ply:ConCommand("TrafficHack_Active 1")
        end
        local function Disable()
                PanicButton:SetText("Enable")
                PanicButton.DoClick = function()
                        PanicButton:SetText("Disable")
                        PanicButton.DoClick = Disable
                        TRAFFICHACKRAWEDITION.Ply:ConCommand("TrafficHack_Active 1")
                end
                TRAFFICHACKRAWEDITION.Ply:ConCommand("TrafficHack_Active 0")
        end
        if TRAFFICHACKRAWEDITION.Active:GetBool() then
                PanicButton:SetText("Disable")
                PanicButton.DoClick = Disable
        else
                PanicButton:SetText("Enable")
                PanicButton.DoClick = Enable
        end
       
        local CloseButton = vgui.Create("DButton", main)
        CloseButton:SetSize(30, 20)
        CloseButton:SetPos(465, 3)
        CloseButton:SetText("X")
        CloseButton.DoClick = function()
                main:Close()
        end
       
        local title = vgui.Create("DLabel", main)
        title:SetColor(Color(255, 255, 255, 255))
        title:SetFont("TitleFont")
        title:SetText("TrafficHack - "..TRAFFICHACKRAWEDITION.Version)
        title:SizeToContents()
        title:SetPos(main:GetWide() / 2 - title:GetWide() / 2,3)       
       
        ColumnSheet = vgui.Create("DColumnSheet",main)
        ColumnSheet:SetPos(5, 25)
        ColumnSheet:SetSize(500 ,465)
       
        local y = 40
        local function ToggleOption(name, parent, var)
                local Options = vgui.Create("DComboBox", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:AddChoice("Off", 0)
                Options:AddChoice("On", 1)
                Options.OnSelect = function(panel,index,value,data)
                        TRAFFICHACKRAWEDITION.Ply:ConCommand(var.." "..data)
                end
                Options:SetText(Options:GetOptionText(TRAFFICHACKGETCONVAR(var):GetInt() + 1))
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function SetKeyOption(name, parent, var)         
                local Options = vgui.Create("DButton", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetText(TRAFFICHACKGETCONVAR(var):GetString())
                Options.DoClick = function()
                        Options:SetText("Press a key...")
                        Options.Think = function()
                                for k = 107, 111 do
                                        if input.IsMouseDown(k) then
                                                TRAFFICHACKRAWEDITION.Ply:ConCommand(var.." "..TRAFFICHACKRAWEDITION.MouseKeys[k])
                                                Options:SetText(TRAFFICHACKRAWEDITION.MouseKeys[k])
                                                Options.Think = nil
                                        end
                                end
                               
                                for k = 0, 130 do
                                        if input.IsKeyDown(k) then
                                                TRAFFICHACKRAWEDITION.Ply:ConCommand(var.." "..TRAFFICHACKRAWEDITION.Keys[k])
                                                Options:SetText(TRAFFICHACKRAWEDITION.Keys[k])
                                                Options.Think = nil
                                        end
                                end
                        end
                end
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function SetNumberOption(name, parent, var, min, max, decimals)          
                local Options = vgui.Create("DNumberWang", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetMin(min)
                Options:SetMax(max)
                Options:SetDecimals(decimals)
                Options:SetConVar(var)
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        local function MultiOption(name, parent, var, tab)             
                local Options = vgui.Create("DComboBox", parent)
                Options:SetSize(100, 20)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                for i = 1, #tab do
                        Options:AddChoice(tab[i])
                end
                Options.OnSelect = function(panel,index,value,data)
                        TRAFFICHACKRAWEDITION.Ply:ConCommand(var.." "..value)
                end
                Options:SetText(TRAFFICHACKGETCONVAR(var):GetString())
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 20
        end
       
        //Starting the Aimbot panel
        local Aimbot = vgui.Create("DPanel")
        Aimbot:SetSize(379, 465)
        Aimbot.Paint = function()
                draw.RoundedBox( 0, 0, 0, Aimbot:GetWide(), Aimbot:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Aimbot)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Aimbot")
        title:SizeToContents()
        title:SetPos(Aimbot:GetWide() / 2 - title:GetWide() / 2, 0)
       
        ToggleOption("Active", Aimbot, "TrafficHack_Aimbot_Active")
		ToggleOption("C++ Aimbot", Aimbot, "TrafficHack_Aimbot_shitplusplusgamebot")
        ToggleOption("Random Bones", Aimbot, "TrafficHack_Aimbot_RandomBones")
        MultiOption("Preferance", Aimbot, "TrafficHack_Aimbot_Preferance", {"Distance", "Angle"})    
        ToggleOption("Attack Players", Aimbot, "TrafficHack_Aimbot_AttackPlayers")
        ToggleOption("Attack NPCs", Aimbot, "TrafficHack_Aimbot_AttackNPCs")
        ToggleOption("Prediction", Aimbot, "TrafficHack_Aimbot_Prediction")
		ToggleOption("Triggerbot", Aimbot, "TrafficHack_Aimbot_Triggerbot")
		ToggleOption("Trig On Key", Aimbot, "TrafficHack_Aimbot_TrigOnKey")
        SetKeyOption("Key", Aimbot, "TrafficHack_Aimbot_TrigOnKey_Key")
        ToggleOption("Aim On Key", Aimbot, "TrafficHack_Aimbot_AimOnKey")
        SetKeyOption("Key", Aimbot, "TrafficHack_Aimbot_AimOnKey_Key")
        ToggleOption("Anti Snap", Aimbot, "TrafficHack_Aimbot_AntiSnap")
        SetNumberOption("Anti Snap Speed", Aimbot, "TrafficHack_Aimbot_AntiSnapSpeed", 1, 5, 2)
        SetNumberOption("Max Angle", Aimbot, "TrafficHack_Aimbot_MaxAngle", 0, 270, 0)
        ToggleOption("Auto Shoot", Aimbot, "TrafficHack_Aimbot_AutoShoot")
        ToggleOption("Panic Mode", Aimbot, "TrafficHack_Aimbot_PanicMode")
        ToggleOption("Ignore Team", Aimbot, "TrafficHack_Aimbot_IgnoreTeam")
       
        if y > 465 then
                Aimbot:SetTall(y)
        end
       
        //This is the best way i can find to add a scrollbar to the menu...
        AimbotList = vgui.Create( "DPanelList" )
        AimbotList:SetSize(379, 465)
        AimbotList:SetSpacing(0)
        AimbotList:EnableHorizontal(false)
        AimbotList:EnableVerticalScrollbar(true)
        AimbotList:AddItem(Aimbot)
       
        ColumnSheet:AddSheet("Aimbot C++ Version", AimbotList, "icon16/color_wheel.png")
       
        //Starting the Friends panel
        local FriendsPanel = vgui.Create("DPanel")
        FriendsPanel:SetSize(379, 465)
        FriendsPanel.Paint = function()
                draw.RoundedBox( 0, 0, 0, FriendsPanel:GetWide(), FriendsPanel:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", FriendsPanel)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Friends")
        title:SizeToContents()
        title:SetPos(FriendsPanel:GetWide() / 2 - title:GetWide() / 2, 3)
       
        local Friends = {}
        local Enemies = {}
       
        local players = player.GetAll()
        for k = 1, #players do
                local v = players[k]
                if v != TRAFFICHACKRAWEDITION.Ply then
                        if table.HasValue(TRAFFICHACKRAWEDITION.Friends.List, v:SteamID()) then
                                table.insert(Friends, v)
                        else
                                table.insert(Enemies, v)
                        end
                end
        end
       
        y = 40
        local EnemiesList = vgui.Create("DListView", FriendsPanel) //Need this up here so FriendsList can reference it.
        local FriendsList = vgui.Create("DListView", FriendsPanel)
        FriendsList:SetSize(150, 200)
        FriendsList:SetPos(FriendsPanel:GetWide() * 0.25 - FriendsList:GetWide() / 2, y)
        FriendsList:SetMultiSelect(false)
        FriendsList:AddColumn("Friends")
        for k = 1, #Friends do
                FriendsList:AddLine(Friends[k]:Nick())
        end
        FriendsList.DoDoubleClick = function(panel, index, line)
                table.insert(Enemies, Friends[index])
                table.remove(Friends, index)
               
                FriendsList:Clear()
                EnemiesList:Clear()
                for k = 1, #Friends do
                        FriendsList:AddLine(Friends[k]:Nick())
                end
                for k = 1, #Enemies do
                        EnemiesList:AddLine(Enemies[k]:Nick())
                end
               
                TRAFFICHACKRAWEDITION.Friends.List = {}
                for k = 1, #Friends do
                        table.insert(TRAFFICHACKRAWEDITION.Friends.List, Friends[k]:SteamID())
                end
                //TRAFFICHACKRAWEDITION.SaveData()
        end
       
        EnemiesList:SetSize(150, 200)
        EnemiesList:SetPos(FriendsPanel:GetWide() * 0.75 - EnemiesList:GetWide() / 2, y)
        EnemiesList:SetMultiSelect(false)
        EnemiesList:AddColumn("Enemies")
        for k = 1, #Enemies do
                EnemiesList:AddLine(Enemies[k]:Nick())
        end
        EnemiesList.DoDoubleClick = function(panel, index, line)
                table.insert(Friends, Enemies[index])
                table.remove(Enemies, index)
               
                FriendsList:Clear()
                EnemiesList:Clear()
                for k = 1, #Friends do
                        FriendsList:AddLine(Friends[k]:Nick())
                end
                for k = 1, #Enemies do
                        EnemiesList:AddLine(Enemies[k]:Nick())
                end
               
                TRAFFICHACKRAWEDITION.Friends.List = {}
                for k = 1, #Friends do
                        table.insert(TRAFFICHACKRAWEDITION.Friends.List, Friends[k]:SteamID())
                end
                //TRAFFICHACKRAWEDITION.SaveData()
        end
       
        y = y + EnemiesList:GetTall() + 20
        ToggleOption("Use", FriendsPanel, "TrafficHack_Friends_Active")
        ToggleOption("Reverse", FriendsPanel, "TrafficHack_Friends_Reverse")
       
        if y > 465 then
                FriendsPanel:SetTall(y)
        end
       
        local FriendsPanelList = vgui.Create( "DPanelList" )
        FriendsPanelList:SetSize(379, 465)
        FriendsPanelList:SetSpacing(0)
        FriendsPanelList:EnableHorizontal(false)
        FriendsPanelList:EnableVerticalScrollbar(true)
        FriendsPanelList:AddItem(FriendsPanel)
       
        ColumnSheet:AddSheet("Carpoolers", FriendsPanelList, "icon16/color_wheel.png")
 
        //Starting the ESP panel
        local ESP = vgui.Create("DPanel")
        ESP:SetSize(379, 465)
        ESP.Paint = function()
                draw.RoundedBox( 0, 0, 0, ESP:GetWide(), ESP:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", ESP)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("ESP")
        title:SizeToContents()
        title:SetPos(ESP:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Active", ESP, "TrafficHack_ESP_Active")
        ToggleOption("Player Info", ESP, "TrafficHack_ESP_Players")
        ToggleOption("NPC Info", ESP, "TrafficHack_ESP_NPCs")
        MultiOption("Name", ESP, "TrafficHack_ESP_Name", {"Off", "Above", "Below"})  
        MultiOption("Weapon", ESP, "TrafficHack_ESP_Weapons", {"Off", "Above", "Below"})     
        MultiOption("Health", ESP, "TrafficHack_ESP_Health", {"Off", "Above", "Below"})      
        MultiOption("Distance", ESP, "TrafficHack_ESP_Distance", {"Off", "Above", "Below"})
        MultiOption("Show Traitors", ESP, "TrafficHack_ESP_ShowTraitors", {"Off", "Above", "Below"})
        ToggleOption("Bounding Box", ESP, "TrafficHack_ESP_Box")
        ToggleOption("Body Info", ESP, "TrafficHack_ESP_Bodies")
        ToggleOption("2D Radar", ESP, "TrafficHack_ESP_Radar")
        SetNumberOption("Radar Scale", ESP, "TrafficHack_ESP_RadarScale", 1, 100, 0)
        SetNumberOption("Max Distance", ESP, "TrafficHack_ESP_MaxDistance", 0, 8000, 0)
        ToggleOption("Team Based", ESP, "TrafficHack_ESP_TeamBased")
       
        if y > 465 then
                ESP:SetTall(y)
        end
       
        ESPList = vgui.Create( "DPanelList" )
        ESPList:SetSize(379, 465)
        ESPList:SetSpacing(0)
        ESPList:EnableHorizontal(false)
        ESPList:EnableVerticalScrollbar(true)
        ESPList:AddItem(ESP)
       
        ColumnSheet:AddSheet("Carview", ESPList, "icon16/color_wheel.png")
       
        //Starting the Chams panel
        local Chams = vgui.Create("DPanel")
        Chams:SetSize(379, 465)
        Chams.Paint = function()
                draw.RoundedBox( 0, 0, 0, Chams:GetWide(), Chams:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Chams)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Chams")
        title:SizeToContents()
        title:SetPos(Chams:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Active", Chams, "TrafficHack_Chams_Active")
        ToggleOption("Draw Players", Chams, "TrafficHack_Chams_Players")
        ToggleOption("Draw NPCs", Chams, "TrafficHack_Chams_NPCs")
        ToggleOption("Draw Weapons", Chams, "TrafficHack_Chams_Weapons")
        ToggleOption("Draw Bodies", Chams, "TrafficHack_Chams_Bodies")
        ToggleOption("Team Based", Chams, "TrafficHack_Chams_TeamBased")
        SetNumberOption("Max Distance", Chams, "TrafficHack_Chams_MaxDistance", 0, 8000, 0)
       
        if y > 465 then
                Chams:SetTall(y)
        end
       
        ChamsList = vgui.Create( "DPanelList" )
        ChamsList:SetSize(379, 465)
        ChamsList:SetSpacing(0)
        ChamsList:EnableHorizontal(false)
        ChamsList:EnableVerticalScrollbar(true)
        ChamsList:AddItem(Chams)
       
        ColumnSheet:AddSheet("Porsche", ChamsList, "icon16/color_wheel.png")
       
        //Starting the Finder panel
        local Finder = vgui.Create("DPanel")
        Finder:SetSize(379, 465)
        Finder.Paint = function()
                draw.RoundedBox( 0, 0, 0, Finder:GetWide(), Finder:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Finder)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Entity Finder")
        title:SizeToContents()
        title:SetPos(Finder:GetWide() / 2 - title:GetWide() / 2, 3)
       
        local ToShow = {}
        local Others = {}
       
        local All = ents.GetAll()
        for k = 1, #All do
                local v = All[k]
                if table.HasValue(TRAFFICHACKRAWEDITION.Entities.List, v:GetClass()) then
                        if not table.HasValue(ToShow, v:GetClass()) then
                                table.insert(ToShow, v:GetClass())
                        end
                elseif not table.HasValue(Others, v:GetClass()) then
                        table.insert(Others, v:GetClass())
                end
        end
       
        y = 40
        local IgnoreList = vgui.Create("DListView", Finder) //Need this up here so ToShowList can reference it.
        local ToShowList = vgui.Create("DListView", Finder)
        ToShowList:SetSize(150, 200)
        ToShowList:SetPos(Finder:GetWide() * 0.25 - ToShowList:GetWide() / 2, y)
        ToShowList:SetMultiSelect(false)
        ToShowList:AddColumn("To Show")
        for k = 1, #ToShow do
                ToShowList:AddLine(ToShow[k])
        end
        ToShowList.DoDoubleClick = function(panel, index, line)
                table.insert(Others, ToShow[index])
                table.remove(ToShow, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                TRAFFICHACKRAWEDITION.Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(TRAFFICHACKRAWEDITION.Entities.List, ToShow[k])
                end
                //TRAFFICHACKRAWEDITION.SaveData()
        end
       
        IgnoreList:SetSize(150, 200)
        IgnoreList:SetPos(Finder:GetWide() * 0.75 - IgnoreList:GetWide() / 2, y)
        IgnoreList:SetMultiSelect(false)
        IgnoreList:AddColumn("Others")
        for k = 1, #Others do
                IgnoreList:AddLine(Others[k])
        end
        IgnoreList.DoDoubleClick = function(panel, index, line)
                table.insert(ToShow, Others[index])
                table.remove(Others, index)
               
                ToShowList:Clear()
                IgnoreList:Clear()
                for k = 1, #ToShow do
                        ToShowList:AddLine(ToShow[k])
                end
                for k = 1, #Others do
                        IgnoreList:AddLine(Others[k])
                end
               
                TRAFFICHACKRAWEDITION.Entities.List = {}
                for k = 1, #ToShow do
                        table.insert(TRAFFICHACKRAWEDITION.Entities.List, ToShow[k])
                end
                //TRAFFICHACKRAWEDITION.SaveData()
        end
       
        y = y + IgnoreList:GetTall() + 20
        ToggleOption("Active", Finder, "TrafficHack_Entities_Active")
       
        if y > 465 then
                Finder:SetTall(y)
        end
       
        local FinderList = vgui.Create( "DPanelList" )
        FinderList:SetSize(379, 465)
        FinderList:SetSpacing(0)
        FinderList:EnableHorizontal(false)
        FinderList:EnableVerticalScrollbar(true)
        FinderList:AddItem(Finder)
       
        ColumnSheet:AddSheet("GPS", FinderList, "icon16/color_wheel.png")
       
        //Starting the Misc panel
        local Misc = vgui.Create("DPanel")
        Misc:SetSize(379, 465)
        Misc.Paint = function()
                draw.RoundedBox( 0, 0, 0, Misc:GetWide(), Misc:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Misc)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Misc")
        title:SizeToContents()
        title:SetPos(Misc:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 40
        ToggleOption("Show Admins", Misc, "TrafficHack_Misc_ShowAdmins")
        ToggleOption("Crosshair", Misc, "TrafficHack_Misc_Cross")
        SetNumberOption("Corsshair Size", Misc, "TrafficHack_Misc_CrossSize", 0, 1000, 0)
        ToggleOption("No Recoil", Misc, "TrafficHack_Misc_NoRecoil")
		ToggleOption("Flashlight", Misc, "TrafficHack_Misc_Flashlight")
		ToggleOption("Fullbright", Misc, "TrafficHack_Misc_Fullbright")
		ToggleOption("Speedhack", Misc, "TrafficHack_Misc_Speedhack")
		SetKeyOption("Key", Misc, "TrafficHack_Misc_Speedhack_Key")
        ToggleOption("Spectators", Misc, "TrafficHack_Misc_ShowSpectators")
        ToggleOption("Bunny Hop", Misc, "TrafficHack_Misc_BunnyHop")
        SetKeyOption("Key", Misc, "TrafficHack_Misc_BunnyHop_Key")
        ToggleOption("Buy Health", Misc, "TrafficHack_Misc_BuyHealth")
        SetNumberOption("Minimum", Misc, "TrafficHack_Misc_BuyHealth_Minimum", 0, 100, 0)
        ToggleOption("Traitor Finder", Misc, "TrafficHack_Misc_TraitorFinder")
        ToggleOption("Show Deaths", Misc, "TrafficHack_Misc_Deaths")
        ToggleOption("Sounds", Misc, "TrafficHack_Misc_Sounds")
 
        if y > 465 then
                Misc:SetTall(y)
        end
       
        MiscList = vgui.Create( "DPanelList" )
        MiscList:SetSize(379, 465)
        MiscList:SetSpacing(0)
        MiscList:EnableHorizontal(false)
        MiscList:EnableVerticalScrollbar(true)
        MiscList:AddItem(Misc)
 
        ColumnSheet:AddSheet("go", MiscList, "icon16/color_wheel.png")
       
        local function ColorOption(name, parent, tab)
                local Options = vgui.Create("DColorMixer", parent)
                Options:SetSize(150, 100)
                Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
                Options:SetColor(tab.color)//TRAFFICHACKRAWEDITION.GetColorFromString(TRAFFICHACKGETCONVAR(var):GetString()))
                Options:SetWangs(false)
                Options:SetPalette(false)
                Options.ValueChanged = function(panel, color)
                        TRAFFICHACKRAWEDITION.Ply:ConCommand(tab.var:GetName().." ".."Color("..color.r..","..color.g..","..color.b..","..color.a..")")
                        tab.color = TRAFFICHACKRAWEDITION.GetColorFromString(tab.var:GetString())
                end
               
                local text = vgui.Create("DLabel", parent)
                text:SetColor(Color(0, 0, 0, 255))
                text:SetFont("CatagoryText")
                text:SetText(name)
                text:SizeToContents()
                text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
               
                y = y + Options:GetTall() + 10
        end
        //Starting the Style panel
        local Style = vgui.Create("DPanel")
        Style:SetSize(379, 465)
        Style.Paint = function()
                draw.RoundedBox( 0, 0, 0, Style:GetWide(), Style:GetTall(), Color( 240, 240, 240, 255 ) )
        end
       
        local title = vgui.Create("DLabel", Style)
        title:SetColor(Color(0, 0, 0, 255))
        title:SetFont("CatagoryHeader")
        title:SetText("Style")
        title:SizeToContents()
        title:SetPos(Style:GetWide() / 2 - title:GetWide() / 2, 3)
       
        y = 50
        ColorOption("Bounding Box", Style, TRAFFICHACKRAWEDITION.Style.Vars["BoundingBox"])
        ColorOption("ESP Text", Style, TRAFFICHACKRAWEDITION.Style.Vars["ESPText"])
        ColorOption("Crosshair", Style, TRAFFICHACKRAWEDITION.Style.Vars["Crosshair"])
        ColorOption("TTT Body Text", Style, TRAFFICHACKRAWEDITION.Style.Vars["BodyText"])
        ColorOption("Chams", Style, TRAFFICHACKRAWEDITION.Style.Vars["Chams"])
        ColorOption("TTT Body Chams", Style, TRAFFICHACKRAWEDITION.Style.Vars["BodyChams"])
       
        if y > 465 then
                Style:SetTall(y)
        end
       
        StyleList = vgui.Create( "DPanelList" )
        StyleList:SetSize(379, 465)
        StyleList:SetSpacing(0)
        StyleList:EnableHorizontal(false)
        StyleList:EnableVerticalScrollbar(true)
        StyleList:AddItem(Style)
       
        ColumnSheet:AddSheet("bushack", StyleList, "icon16/color_wheel.png")
end)
 
 
//Just some fonts
surface.CreateFont("TitleFont", {font = "Arial", size = 20})
surface.CreateFont("CatagoryHeader", {font = "CloseCaption_Normal", size = 34})
surface.CreateFont("CatagoryText", {font = "CloseCaption_Normal", size = 28})
surface.CreateFont("ESPFont",{font = "coolvetica", size = 14, weight = 500, antialias = 0})
 
--[[
        DPropertySheet - Slightly edited so it looks good.
--]]
local PANEL = {}
AccessorFunc( PANEL, "ActiveButton", "ActiveButton" )
 
--[[---------------------------------------------------------
Name: Init
-----------------------------------------------------------]]
function PANEL:Init()
        self.Navigation = vgui.Create( "DScrollPanel", self )
        self.Navigation:Dock( LEFT )
        self.Navigation:SetWidth( 100 )
        self.Navigation:DockMargin( 0, 0, 10, 0 )
 
        self.Content = vgui.Create( "Panel", self )
        self.Content:Dock( FILL )
 
        self.Items = {}
end
 
function PANEL:UseButtonOnlyStyle()
        self.ButtonOnly = true
end
 
--[[---------------------------------------------------------
Name: AddSheet
-----------------------------------------------------------]]
function PANEL:AddSheet( label, panel, material )
        if ( !IsValid( panel ) ) then return end
 
        local Sheet = {}
 
        if ( self.ButtonOnly ) then
                Sheet.Button = vgui.Create( "DImageButton", self.Navigation )
        else
                Sheet.Button = vgui.Create( "DButton", self.Navigation )
        end
        Sheet.Button:SetImage( material )
        Sheet.Button.Target = panel
        Sheet.Button:Dock( TOP )
        Sheet.Button:SetText( label )
        Sheet.Button:DockMargin( 0, 0, 0, 5 )
 
        Sheet.Button.DoClick = function ()
                self:SetActiveButton( Sheet.Button )
        end
 
        Sheet.Panel = panel
        Sheet.Panel:SetParent( self.Content )
        Sheet.Panel:SetVisible( false )
 
        if ( self.ButtonOnly ) then
                Sheet.Button:SizeToContents()
                Sheet.Button:SetColor( Color( 150, 150, 150, 255 ) )
        end
 
        table.insert( self.Items, Sheet )
 
        if ( !IsValid( self.ActiveButton ) ) then
                self:SetActiveButton( Sheet.Button )
        end
end
 
--[[---------------------------------------------------------
Name: SetActiveTab
-----------------------------------------------------------]]
function PANEL:SetActiveButton( active )
        if ( self.ActiveButton == active ) then return end
 
        if ( self.ActiveButton && self.ActiveButton.Target ) then      
                self.ActiveButton.Target:SetVisible( false )
                self.ActiveButton:SetSelected( false )
                self.ActiveButton:SetColor( Color( 0, 0, 0, 255 ) )
        end
        self.ActiveButton = active
        active.Target:SetVisible( true )
        active:SetSelected( true )
        active:SetColor( Color( 150, 150, 150, 255 ) )
 
        self.Content:InvalidateLayout()
end

--[[
                                                                                            `.,::;;;;;;;:,.`                                                                                            
                                                                                    `:;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                                                    
                                                                               ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                              
                                                                           :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                                                          
                                                                       .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                       
                                                                    ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                   
                                                                 .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                 
                                                               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                              
                                                            `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                            
                                                          ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                          
                                                        :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                       
                                                      :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                     
                                                    ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                    
                                                  `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                  
                                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                
                                               :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                              
                                              ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                             
                                            ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                           
                                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                          
                                         ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                         
                                        ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,.`         `.:;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                       
                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                           ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                      
                                     .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                     :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                     
                                    ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                            `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                   
                                   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                  
                                  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                        `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                 
                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                             :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                
                                ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                  .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                               
                               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                      `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                              
                              ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                          `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                             
                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                              ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                            
                            ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                                                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                           
                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                          
                          ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                        :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                         
                         ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                        
                        ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                       
                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                `;;;;;;;;;;;;;;;;;;;;;;;;;;;;                       
                      .;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;                      
                      ;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;;                     
                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                        :;;;;;;;;;;;;;;;;;;;;;;;;;;;                    
                    ;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                          ,;;;;;;;;;;;;;;;;;;;;;;;;;;.                   
                   :;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                            `;;;;;;;;;;;;;;;;;;;;;;;;;;                   
                   ;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                              `;;;;;;;;;;;;;;;;;;;;;;;;;;                  
                  ;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;;;;;:                 
                 ;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;;;;;                 
                 ;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                    `;;;;;;;;;;;;;;;;;;;;;;;;;                
                ;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                      `;;;;;;;;;;;;;;;;;;;;;;;;:               
               :;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                        ,;;;;;;;;;;;;;;;;;;;;;;;;               
               ;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                          ;;;;;;;;;;;;;;;;;;;;;;;;;              
              ;;;;;;;;;;;;;;;;;;;;;;;;.                                                                                                                           ;;;;;;;;;;;;;;;;;;;;;;;;.             
             `;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                             ;;;;;;;;;;;;;;;;;;;;;;;;             
             ;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                               ;;;;;;;;;;;;;;;;;;;;;;;:            
            ,;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                .;;;;;;;;;;;;;;;;;;;;;;;            
            ;;;;;;;;;;;;;;;;;;;;;;;`                                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;;;;           
           :;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;;;           
           ;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;          
          :;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                      ;;;;;;;;;;;;;;;;;;;;;;;          
          ;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                       ;;;;;;;;;;;;;;;;;;;;;;;         
         ,;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                        `;;;;;;;;;;;;;;;;;;;;;;         
         ;;;;;;;;;;;;;;;;;;;;;;`                                                                                                                                         ;;;;;;;;;;;;;;;;;;;;;;;        
        .;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                           ;;;;;;;;;;;;;;;;;;;;;;        
        ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                            ;;;;;;;;;;;;;;;;;;;;;;,       
        ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                             ;;;;;;;;;;;;;;;;;;;;;;       
       ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                              :;;;;;;;;;;;;;;;;;;;;;       
       ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                               ;;;;;;;;;;;;;;;;;;;;;;      
      .;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                :;;;;;;;;;;;;;;;;;;;;;      
      ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;.     
      ;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                  ;;;;;;;;;;;;;;;;;;;;;;     
     ,;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;     
     ;;;;;;;;;;;;;;;;;;;;;`                                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;.    
     ;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;    
    .;;;;;;;;;;;;;;;;;;;;:                                                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;    
    ;;;;;;;;;;;;;;;;;;;;;                     .................................                                           `````````````````````````````````                    :;;;;;;;;;;;;;;;;;;;;`   
    ;;;;;;;;;;;;;;;;;;;;;                  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@`                                   .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                  ;;;;;;;;;;;;;;;;;;;;;   
    ;;;;;;;;;;;;;;;;;;;;,                '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                ;;;;;;;;;;;;;;;;;;;;;   
   :;;;;;;;;;;;;;;;;;;;;                ;@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#                               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                ,;;;;;;;;;;;;;;;;;;;;   
   ;;;;;;;;;;;;;;;;;;;;;                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@`                             :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                ;;;;;;;;;;;;;;;;;;;;.  
   ;;;;;;;;;;;;;;;;;;;;:               @@@@@@@@@@@@';,`               `,:'#@@@@@@@@@@@                             ;;;;;;;;;;;;,.`                `.,:;;;;;;;;;;;.               ;;;;;;;;;;;;;;;;;;;;;  
   ;;;;;;;;;;;;;;;;;;;;                @@@@@@                                   @@@@@@                            `;;;;;:                                  .;;;;;;               ;;;;;;;;;;;;;;;;;;;;;  
  ,;;;;;;;;;;;;;;;;;;;;                @@@@.                                      @@@@`                           ;;;;;                                      ;;;;;                ;;;;;;;;;;;;;;;;;;;;  
  ;;;;;;;;;;;;;;;;;;;;;               .@@@`                                        @@@'                           ;;;;                                        ;;;;                ;;;;;;;;;;;;;;;;;;;;  
  ;;;;;;;;;;;;;;;;;;;;.               '@@@                                         '@@@                           ;;;                                          ;;;                ;;;;;;;;;;;;;;;;;;;;: 
  ;;;;;;;;;;;;;;;;;;;;                @@@                                           @@@                           ;;;                                          :;;.               :;;;;;;;;;;;;;;;;;;;; 
  ;;;;;;;;;;;;;;;;;;;;                @@@                                           @@@                           ;;:                                           ;;;               `;;;;;;;;;;;;;;;;;;;; 
 .;;;;;;;;;;;;;;;;;;;;                @@@                                           @@@                          .;;.                                           ;;;                ;;;;;;;;;;;;;;;;;;;; 
 :;;;;;;;;;;;;;;;;;;;:                @@@                                           '@@                          :;;                                            ;;;                ;;;;;;;;;;;;;;;;;;;; 
 ;;;;;;;;;;;;;;;;;;;;`               `@@'                                           ,@@:                         ;;;                                            ;;;                ;;;;;;;;;;;;;;;;;;;;`
 ;;;;;;;;;;;;;;;;;;;;                '@@,                                            @@#                         ;;;                                            ;;;                :;;;;;;;;;;;;;;;;;;;,
 ;;;;;;;;;;;;;;;;;;;;                @@@                                             @@@                         ;;;                                            :;;`               .;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;                @@@:                                            @@@                         ;;;                                            ;;;:                ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;                @@@@                                           @@@@                        .;;;,                                           ;;;;                ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;                @@@@@,  ``.:;'+#@@@@@@@@@@@@@@@@@@@@+';:,.`  ,@@@@@                        :;;;;;   ``.,,:;;;;;;;;;;;;;;;;;;;;;;::,.``   ,;;;;;                ;;;;;;;;;;;;;;;;;;;;
`;;;;;;;;;;;;;;;;;;;;               `@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@,                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                ;;;;;;;;;;;;;;;;;;;;
.;;;;;;;;;;;;;;;;;;;,               ;@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                ;;;;;;;;;;;;;;;;;;;;
,;;;;;;;;;;;;;;;;;;;.              :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@;                     :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`              ;;;;;;;;;;;;;;;;;;;;
:;;;;;;;;;;;;;;;;;;;`            .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@;                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;             ;;;;;;;;;;;;;;;;;;;;
:;;;;;;;;;;;;;;;;;;;             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@`               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,           :;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           :;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           :;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           :;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           :;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
:;;;;;;;;;;;;;;;;;;;            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
,;;;;;;;;;;;;;;;;;;;`           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
.;;;;;;;;;;;;;;;;;;;.           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
`;;;;;;;;;;;;;;;;;;;:           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:           ;;;;;;;;;;;;;;;;;;;;
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:          ,;;;;;;;;;;;;;;;;;;;:
 ;;;;;;;;;;;;;;;;;;;;           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`          ;;;;;;;;;;;;;;;;;;;;.
 ;;;;;;;;;;;;;;;;;;;;.           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;           ;;;;;;;;;;;;;;;;;;;; 
 ,;;;;;;;;;;;;;;;;;;;;           ,@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;; 
 `;;;;;;;;;;;;;;;;;;;;            +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;             ;;;;;;;;;;;;;;;;;;;; 
  ;;;;;;;;;;;;;;;;;;;;            +@@@@@@@@@          `.,:;;''+'';;::.`          @@@@@@@@@@                   ;;;;;;;;;           `..,,,::::,,,,.``          ;;;;;;;;;            .;;;;;;;;;;;;;;;;;;;; 
  ;;;;;;;;;;;;;;;;;;;;            +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;;; 
  ;;;;;;;;;;;;;;;;;;;;,           +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;;. 
  ;;;;;;;;;;;;;;;;;;;;;           +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;            ;;;;;;;;;;;;;;;;;;;;  
  .;;;;;;;;;;;;;;;;;;;;           +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;           .;;;;;;;;;;;;;;;;;;;;  
   ;;;;;;;;;;;;;;;;;;;;           +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;           ;;;;;;;;;;;;;;;;;;;;;  
   ;;;;;;;;;;;;;;;;;;;;;          +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;           ;;;;;;;;;;;;;;;;;;;;;  
   ;;;;;;;;;;;;;;;;;;;;;          +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;           ;;;;;;;;;;;;;;;;;;;;`  
   ,;;;;;;;;;;;;;;;;;;;;          +@@@@@@@@@                                     @@@@@@@@@@                   ;;;;;;;;;                                      ;;;;;;;;;          ;;;;;;;;;;;;;;;;;;;;;   
    ;;;;;;;;;;;;;;;;;;;;;         ;@@@@@@@@+                                     ;@@@@@@@@#                   ;;;;;;;;;                                      ;;;;;;;;;          ;;;;;;;;;;;;;;;;;;;;;   
    ;;;;;;;;;;;;;;;;;;;;;          .@@@@@@'                                       ;@@@@@@;                     ;;;;;;;                                        ;;;;;;;           ;;;;;;;;;;;;;;;;;;;;:   
    ;;;;;;;;;;;;;;;;;;;;;             ;+,                                           .''`                         .::                                            ,:,            ;;;;;;;;;;;;;;;;;;;;;    
     ;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;    
     ;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                    .;;;;;;;;;;;;;;;;;;;;;    
     ;;;;;;;;;;;;;;;;;;;;;,                                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;`    
     `;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;     
      ;;;;;;;;;;;;;;;;;;;;;`                                                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;;     
      ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;      
       ;;;;;;;;;;;;;;;;;;;;;                                                                                                                                                ;;;;;;;;;;;;;;;;;;;;;;      
       ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                               ;;;;;;;;;;;;;;;;;;;;;:      
       :;;;;;;;;;;;;;;;;;;;;;`                                                                                                                                             ;;;;;;;;;;;;;;;;;;;;;;       
        ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                             ;;;;;;;;;;;;;;;;;;;;;;       
        ;;;;;;;;;;;;;;;;;;;;;;.                                                                                                                                           ;;;;;;;;;;;;;;;;;;;;;;`       
         ;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                          `;;;;;;;;;;;;;;;;;;;;;;        
         ;;;;;;;;;;;;;;;;;;;;;;:                                                                                                                                         ;;;;;;;;;;;;;;;;;;;;;;,        
         `;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                        :;;;;;;;;;;;;;;;;;;;;;;         
          ;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                       ;;;;;;;;;;;;;;;;;;;;;;:         
          .;;;;;;;;;;;;;;;;;;;;;;,                                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;          
           ;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                    ,;;;;;;;;;;;;;;;;;;;;;;:          
           `;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                   ;;;;;;;;;;;;;;;;;;;;;;;           
            ;;;;;;;;;;;;;;;;;;;;;;;:                                                                                                                                 ;;;;;;;;;;;;;;;;;;;;;;;,           
             ;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                                ;;;;;;;;;;;;;;;;;;;;;;;;            
             ;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                              .;;;;;;;;;;;;;;;;;;;;;;;`            
              ;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                             ;;;;;;;;;;;;;;;;;;;;;;;;             
              ;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                           ;;;;;;;;;;;;;;;;;;;;;;;;              
               ;;;;;;;;;;;;;;;;;;;;;;;;:                                                                                                                         ;;;;;;;;;;;;;;;;;;;;;;;;;              
               `;;;;;;;;;;;;;;;;;;;;;;;;.                                                                                                                       ;;;;;;;;;;;;;;;;;;;;;;;;;               
                ;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;`               
                 ;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                    ;;;;;;;;;;;;;;;;;;;;;;;;;;                
                 .;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                  :;;;;;;;;;;;;;;;;;;;;;;;;;                 
                  ;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                                :;;;;;;;;;;;;;;;;;;;;;;;;;`                 
                   ;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                              ;;;;;;;;;;;;;;;;;;;;;;;;;;;                  
                    ;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                                                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;                   
                    :;;;;;;;;;;;;;;;;;;;;;;;;;;.                                                                                                         ;;;;;;;;;;;;;;;;;;;;;;;;;;;                    
                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                                                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;.                    
                      ;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;;                     
                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                                  .;;;;;;;;;;;;;;;;;;;;;;;;;;;;                      
                       `;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                                               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                       
                        :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                        
                         ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                          ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                         
                          ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                         
                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                    :;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                          
                            ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                                `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                           
                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                            
                              ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                                         ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                             
                               ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                              
                                ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                               
                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                            .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                
                                  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                  
                                   ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                 ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                   
                                    `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                          `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                    
                                      ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                  `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                     
                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:.                       ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                      
                                        ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:::::;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                        
                                          ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                         
                                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                          
                                             ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                            
                                              ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                             
                                                ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                               
                                                 ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                 
                                                   ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;.                                                  
                                                     ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                    
                                                       ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                      
                                                         ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                        
                                                           ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                          
                                                             ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                            
                                                                ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                               
                                                                  .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;                                                                  
                                                                     ,;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                    
                                                                        `;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:                                                                        
                                                                            .;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;`                                                                           
                                                                                `:;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,                                                                                
                                                                                      `,;;;;;;;;;;;;;;;;;;;;;;;;:.                                                                                      

--]]
 
derma.DefineControl( "DColumnSheet", "", PANEL, "Panel" )
-- epic timer code
RunConsoleCommand("say", "Initializing the best dynamic traffic assistant, TrafficHack Version 1.0...");
RunConsoleCommand("play", "vo/coast/cr_playerincar.wav");
timer.Simple(2, function()
RunConsoleCommand("say", "Created by LuaHax. Sponsored by Aimware.");
RunConsoleCommand("play", "vo/npc/female01/hacks01.wav");
end)
timer.Simple(7, function()
RunConsoleCommand("say", "TrafficHack Version 1.0 has intialized. Enjoy the ride baby.");
RunConsoleCommand("play", "vo/coast/cr_getincar.wav");
end)


