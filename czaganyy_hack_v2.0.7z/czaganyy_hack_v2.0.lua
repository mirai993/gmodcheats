--[[
	autorun/randomfile2.lua
	fangli :d | (STEAM_0:0:19962914)
	===DStream===
]]

if SERVER then return end


CreateClientConVar = CreateClientConVar
hook = hook
SetButtons = SetButtons
_R = _R

//general tables
local entlist = {"money_obj", "aura_item", "aura_shipment", "aura_cash"} //esp
local InvisProps = {}

local old = {} //backup
old.RCC = RunConsoleCommand
old.CCCV = CreateClientConVar
local Hooks = {}

local Commands = {} //console
Commands.cmds = {}
//Commands.cmds["ch_runlua"] = function(a) print(a) end
Commands.cvars = {}
Commands.auto = {}

function OCRPWithdraw(ply,command,args) 
        local a = tonumber(args[2])

        RunConsoleCommand("OB_Withdraw",args[1]) 
        timer.Simple(.0001,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0002,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0003,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0004,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0005,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0006,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0007,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0008,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
        timer.Simple(.0009,function() RunConsoleCommand("OB_Withdraw",args[1]) end)
end

Commands.cmds['ch_spamwithdraw'] = OCRPWithdraw

concommand.Add("ch_runlua",function(_, _, a) RunString(table.concat(a, " ")) end)

CreateClientConVar = function(a, b, c, d)
	Commands.cvars[a] = b
	return old.CCCV(a,b,c,d)
end

//general convars
local panic = CreateClientConVar( "ch_panic", 0, false, false )
local bhop = CreateClientConVar( "ch_bhop", 0, true, false )
local afkon = CreateClientConVar( "ch_afk", 0, true, false )
local showcmds = CreateClientConVar( "ch_showcmds", 1, true, false )
local blacklistcmds = CreateClientConVar( "ch_blacklistcmds", "", true, false )
local adminlist = CreateClientConVar( "ch_showadmins", 0, true, false )
local spoofadmin = CreateClientConVar( "ch_spoofadmin", 0, true, false )

//esp convars
local espon = CreateClientConVar( "ch_esp", 0, true, false )
local playeron = CreateClientConVar( "ch_espplayeron", 1, true, false )
local unhideon = CreateClientConVar( "ch_espunhideon", 1, true, false )
local mode = CreateClientConVar( "ch_espmode", 0, true, false )
local itemon = CreateClientConVar( "ch_espitemon", 1, true, false )
local vehicleon = CreateClientConVar( "ch_espvehicleon", 0, true, false )
local npcon = CreateClientConVar( "ch_espnpcon", 0, true, false )
local weaponon = CreateClientConVar( "ch_espweaponon", 0, true, false )
local trans = CreateClientConVar( "ch_esptrans", 255, true, false )

//aim convars
local AimbotSwitch = CreateClientConVar( "trooper_aimbot", 0, true, false )
local BoneSwitch = CreateClientConVar( "trooper_aimbot_bone", 1, true, false )
local AutoshootSwitch = CreateClientConVar( "trooper_autoshoot", 0, true, false )
local NorecoilSwitch = CreateClientConVar( "trooper_norecoil", 0, true, false )
local FriendSwitch = CreateClientConVar( "trooper_friends", 0, true, false )
local TeamSwitch = CreateClientConVar( "trooper_team", 0, true, false )
local TargetSwitch = CreateClientConVar( "trooper_target", 0, true, false )
local TargetSteam = CreateClientConVar( "trooper_target_steamid", "", true, false )
local TargetTypeSwitch  = CreateClientConVar( "trooper_target_type", 1, true, false )


//security stuff
local cve = ConVarExists
ConVarExists = function(c)
        if string.sub(c,1,3) == "ch_" then
                print("[CH-SEC]: Attempted to check ConVar '"..c.."'")
                return false
        end
        return cve(c)
end


// bhop
local bhopclear = 0xFFFF - IN_JUMP
local SetButtons = _R.CUserCmd.SetButtons

function GModBaseMove(cmd)
	if bhop:GetBool() && !LocalPlayer():InVehicle() && (cmd:GetButtons() & IN_JUMP) > 0 then
		if LocalPlayer():IsOnGround() then
			SetButtons(cmd, cmd:GetButtons() | IN_JUMP)
		else
			SetButtons(cmd, cmd:GetButtons() & bhopclear)
		end
	end
end
Hooks["CreateMove"] = {false, GModBaseMove}



//block some commands
local block = {"SH", "gmcl_deco", "SethHackbot", "sv_cheats", "host_timescale", "SethHack_toggle", "db_steamid_ip", "materials/SethHackbot"}
local block_cmd = {"st_ghosting", "kcheatfound", "achievementRefresh", "_command", "gw_iamacheater", "FFFFFFFFFFFF"}
RunConsoleCommand = function(str, ...)
        if panic:GetBool() then return old.RCC(str, ...) end
        if showcmds:GetBool() || str == "perp_ug" then
                print("RCC", str, ...)
        end
        local whole = str
        for k,x in pairs({...}) do
                whole = whole .. " " .. tostring(x)
        end
        for k,v in pairs(Commands.cmds) do
                if string.find(whole, k) then
                        print("[CH-SEC]: Blocked RCC", str, ...)
                        return                 
                end
        end
        for k,v in pairs(block) do
                if string.find(whole, v) and !string.find(string.lower(whole),"schurbert") then
                        print("[CH-SEC]: Blocked RCC", str, ...)
                       // return                 
                end
        end
        for k,v in pairs(block_cmd) do
                if(str == v) then
                        print("[CH-SEC]: RCC Blocked ("..str..")")
                        return
                end
        end
        if str == "debug_init_callback" then
                local c, e = select(1, ...)
                local fixed = e:gsub(util.CRC(c .. "includes/modules/gm_SH.dll"), util.CRC(c .. "tired_of_dealing_with_this_shit" .. tostring(math.random())))
                return old.RCC(str, c, fixed)
        end
        for k,v in pairs(string.Explode(",", blacklistcmds:GetString())) do
                if string.lower(str) == "cc" || string.lower(str) == "_____varwat" || string.lower(str) == "_log_hook" || string.lower(str) == "_blacklistedhook" || string.lower(str) == "_material" || string.lower(str) == string.lower(v) then
                        print("[CH-SEC]: Blocked RCC", str, ...)
                        return
                end
        end
        return old.RCC(str, ...)
end

RunConsoleCommand("_command")


//huge esp
local function admincheck(ply)
        local ads
        if ply:IsAdmin() then
                ads="*Admin*"
                if ply:IsSuperAdmin() then
                        ads="*Super Admin*"
                end
        else
                ads = ""
        end
        return ads
end
local LAST_CHANGE_FOVVALUE = 0
local screensize = math.sqrt((ScrW()^2)+(ScrH()^2))*.5
local cx, cy = ScrW()*.5, ScrH()*.5
local terroristadverts = {}

local function esp()
        if !espon:GetBool() then return end
        local trace = util.TraceLine({start=LocalPlayer():GetShootPos(),endpos=LocalPlayer():GetShootPos() + (LocalPlayer():GetAimVector() * 64000),filter={LocalPlayer()}})
        if (trace.Hit) && (trace.HitNonWorld) then draw.SimpleTextOutlined(trace.Entity:GetClass(), "HealthFont", ScrW()-20, 35, Color(0,255,0,255),2,3,2,Color(0,0,0,255)) end
        local playeron = playeron:GetInt()
        local itemon = itemon:GetInt()
        local unhideon = unhideon:GetInt()
        local vehicleon = vehicleon:GetInt()
        local npcon = npcon:GetInt()
        local weaponon = weaponon:GetInt()
        local trans = trans:GetInt()
        local mode = mode:GetInt()
        surface.SetDrawColor(0,255,0,100)
        if CurTime() - LAST_CHANGE_FOVVALUE < 3 then
                draw_DrawCircleOutline(cx,cy,screensize*(FOV_VALUE:GetInt()/45))
        end
        for k, v in pairs(player.GetAll()) do
                if v != LocalPlayer() && playeron == 1 then
                        local mod = v:GetModel()
                        local ateam = v:Team()
                        local color = team.GetColor(ateam)
                        local colora
                        local weapon = "NONE"
                        color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
                        if v:InVehicle() then
                                colora = Color(255,255,255,trans)
                        else
                                colora = color
                        end
                        if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
                                if v:Alive() && v:GetActiveWeapon():IsValid() then
                                        weapon=v:GetActiveWeapon( ):GetPrintName()
                                        weapon=string.Replace(weapon,"#HL2_","")
                                        weapon=string.Replace(weapon,"#GMOD_","")
                                end
                        else
                                weapon="NONE"
                        end
                        local hp = v:Health()
                        local name = v:Name()
                        local gpos = v:EyePos():ToScreen()
                        local dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
                        local ads = admincheck(v)
                        if v.bb_traitor == true then
                                ads = "(TRAITOR) " .. ads
                        end
                        local tn
                        if mode==2 then
                                tn=team.GetName(ateam)
                                draw.SimpleText(hp.."   W: "..weapon, "Default", gpos.x+15, gpos.y-32, colora,0,0)
                                draw.SimpleText(v:GetActiveWeapon():GetPrintName(),"Signs", gpos.x+1, gpos.y-30, colora,0,0)
                                draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-43, colora,0,0)
                                draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-12, colora,0,0)
                                draw.SimpleText("Dist: "..math.Round(dist/16).."ft","Default", gpos.x+3, gpos.y-22, colora,0,0)
                                draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-53, Color(255,0,0,trans),0,0)
                        elseif mode==0 then
                                draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-23, colora,0,0)
                                draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-12, colora,0,0)
                                draw.SimpleText("F","Signs", gpos.x+1, gpos.y-10, colora,0,0)
                                draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-33, Color(255,0,0,trans),0,0)
                        else
                                draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-33, colora,0,0)
                                draw.SimpleText(hp, "Default", gpos.x+15, gpos.y-12, colora,0,0)
                                draw.SimpleText("W: "..weapon, "Default", gpos.x+3, gpos.y-23, colora,0,0)
                                draw.SimpleText("F","Signs", gpos.x+1, gpos.y-10, colora,0,0)
                                draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-43, Color(255,0,0,trans),0,0)
                        end
                end
        end
        for j, e in pairs(ents.GetAll()) do
                if e:IsValid() then
                        local Br,Bg,Bb,Ba=e:GetColor()
                        if (e:IsValid()&&!string.find(e:GetClass(),"class")&&Ba<=50&&unhideon==1) then
                                e:SetColor(Br,Bg,Bb,200)
                                table.insert(InvisProps,{Ent=e,c={Br,Bg,Bb,Ba}})
                        end
                        if unhideon==0 && #InvisProps>0 then
                                for h,e in ipairs(InvisProps) do
                                        if e.Ent:IsValid() then
                                                e.Ent:SetColor(e.c[1],e.c[2],e.c[3],e.c[4])
                                        end
                                end
                                InvisProps={}
                        end
                        if e:IsWeapon() && e:GetMoveType()!=0 && weaponon == 1 then
                                local wepn = e:GetClass()
                                local wname = string.Replace(wepn,"weapon_","")
                                wname = string.Replace(wname,"_"," ")
                                wname = string.upper(wname)
                                local wpos = e:GetPos():ToScreen()
                                surface.SetDrawColor(255,0,0,trans)
                                draw.SimpleText(""..wname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
                                surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
                                surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
                        elseif e:IsNPC() && npcon == 1 && e:GetMoveType()!=0 then
                                local amod = e:GetModel()
                                local bname = e:GetClass()
                                local aname = string.Replace(bname,"npc_","")
                                aname = string.Replace(aname,"_"," ")
                                aname = string.upper(aname)
                                local agpos
                                if amod == "models/headcrabclassic.mdl" || amod == "models/headcrab.mdl" || amod == "models/headcrabblack.mdl" then
                                        agpos = (e:GetPos()+Vector(0,0,6)):ToScreen()
                                else
                                        if string.find(e:GetClass(),"crow") == nil && string.find(e:GetClass(),"antlion") == nil && string.find(e:GetClass(),"strider") == nil && string.find(e:GetClass(),"hunter") == nil && string.find(e:GetClass(),"pig") == nil && string.find(e:GetClass(),"mine") == nil && string.find(e:GetClass(),"sea") == nil && string.find(e:GetClass(),"furniture") == nil && string.find(e:GetClass(),"driver") == nil && e:GetAttachment(1) != nil then
                                                agpos = e:GetAttachment(1).Pos:ToScreen()
                                        else
                                                agpos = e:GetPos() + Vector(0,0,5)
                                                agpos = agpos:ToScreen()
                                        end
                                end
                                local nhp = e:Health()
                                surface.SetDrawColor(255,200,0,trans)
                                draw.SimpleText(""..aname.."", "Default", agpos.x+3, agpos.y-15, Color(255,200,0,trans),0,0)
                                draw.SimpleText("NPC", "Default", agpos.x+3, agpos.y-25, Color(255,200,0,trans),0,0)
                                surface.DrawLine(agpos.x,agpos.y,agpos.x,agpos.y-20)
                                surface.DrawLine(agpos.x,agpos.y,agpos.x+20,agpos.y)
                        elseif string.find(e:GetClass(),"item_") && itemon == 1 then
                                local iname = e:GetClass()
                                iname = string.Replace(iname,"item_","")
                                iname = string.Replace(iname,"_"," ")
                                iname = string.upper(iname)
                                local ipos = e:GetPos():ToScreen()
                                surface.SetDrawColor(255,0,0,trans)
                                draw.SimpleText(""..iname.."", "Default", ipos.x+3, ipos.y-15, Color(255,0,0,trans),0,0)
                                surface.DrawLine(ipos.x,ipos.y,ipos.x,ipos.y-20)
                                surface.DrawLine(ipos.x,ipos.y,ipos.x+20,ipos.y)
                        elseif string.find(e:GetClass(),"prop_vehicle_") != nil && vehicleon == 1 then
                                local vname = e:GetClass()
                                vname = string.Replace(vname,"prop_vehicle_","")
                                vname = string.Replace(vname,"_"," ")
                                vname = string.upper(vname)
                                local vpos = e:GetPos():ToScreen()
                                surface.SetDrawColor(255,0,0,trans)
                                draw.SimpleText(""..vname.."", "Default", vpos.x+3, vpos.y-15, Color(255,0,0,trans),0,0)
                                surface.DrawLine(vpos.x,vpos.y,vpos.x,vpos.y-20)
                                surface.DrawLine(vpos.x,vpos.y,vpos.x+20,vpos.y)
                        elseif itemon == 1 and table.HasValue(entlist, e:GetClass()) then
                                local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
                                local cename = e:GetClass()
                                local cesname = string.Replace(cename,"weapon_","")
                                cesname = string.Replace(cesname,"ent_","")
                                if cesname ~= "prop_item" then cesname = string.Replace(cesname,"prop_","") end
                                cesname = string.Replace(cesname,"item_","")
                                cesname = string.Replace(cesname,"_"," ")
                                cesname = string.upper(cesname)
                                draw.SimpleText(""..cesname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
                                surface.SetDrawColor(255,0,0,trans)
                                surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
                                surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
                        elseif e:GetClass() == "prop_physics" &&  table.HasValue(entlist, string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","")) then
                                local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
                                draw.SimpleText(""..string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","").."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
                                surface.SetDrawColor(255,0,0,trans)
                                surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
                                surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
                        end
                end
        end
        surface.SetDrawColor(0, 255, 0, 255)
        local cx, cy = ScrW()/2, ScrH()/2
        if !adminlist:GetBool() then return end
        local num = 0
        local temptblf={}
        for k,v in pairs(player.GetAll()) do
                if admincheck(v)!="" then
                        table.insert(temptblf,{ID=1,Ply=v})
                end
        end
        table.SortByMember(temptblf, "ID", function(a, b) return a > b end)
        draw.RoundedBox( 6, ScrW()-219, 103, 200, 8 + (math.Max(1, #temptblf) * 10), Color( 50, 50, 50, 155 ) )
        draw.SimpleText("Admins:", "Default", ScrW()-215, 105, Color(0,255,0,255),0,0)
        for i,b in ipairs(temptblf) do
                draw.SimpleText(b.Ply:Name(), "Default", ScrW()-175, 105+((i - 1) * 10), Color(0,255,0,255),0,0)
        end
        for i=#terroristadverts,1,-1 do
                if CurTime() - terroristadverts[i].time >= 3 then
                        table.remove(terroristadverts, i)
                end
        end
        table.sort(terroristadverts, function(a,b) return a.time < b.time end)
        for i,v in ipairs(terroristadverts) do
                if CurTime() - v.time < 6 then
                        draw.SimpleTextOutlined(v.text, "HealthFont", ScrW()/2, ScrH()/2 - (i * 35), v.color,1,0,2,Color(0,0,0,255))
                end
        end
end
Hooks["HUDPaint"] = {false, esp}


//new hook shit
local origHookCall = hook.Call
local oldHookCall = hook.Call
local recurse = {}
local ha = hook.Add
local ps = surface.PlaySound
hook.Add = function(t,u,f)
        //print("hookadd:", t, u)
        if(u == "PERPSettingsRDL" || u == "PERPCarMovement" || string.find(u, "AntiBB") || (string.find(u, "block_") && t == "HUDPaint")) then
                print("BB: Anticheat hook.add blocked")
                return
        end
        return ha(t,u,f)
end
surface.PlaySound = function(fp)
        if(fp == "vo/npc/male01/hacks01.wav") then
                return
        end
        return ps(fp)
end
local function bindPressOverride(ply, bind, pressed)
        local bind = string.lower(bind)
        for k,v in pairs(Commands.cmds) do
                if string.find(bind, string.lower(k)) then
                        return true
                end
        end
        return false
end
local function newHookCall( name, gm, ... )    
        local myHook = Hooks[name]
        if name == "PlayerBindPress" && bindPressOverride(...) then
                return false
        end
        local rA, rB, rC, rD, rE, rF, rG, rH
        if recurse[name] then
                rA, rB, rC, rD, rE, rF, rG, rH = origHookCall(name, gm, ...)
        else
                recurse[name] = true
                rA, rB, rC, rD, rE, rF, rG, rH = oldHookCall(name, gm, ...)
                recurse[name] = nil
        end
        if myHook then
                if rA != nil && myHook[1] then
                        local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](rA, rB, rC, rD, rE, rF, rG, rH)
                        if rA != nil then
                                return rA, rB, rC, rD, rE, rF, rG, rH
                        end
                else
                        local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](...)
                        if rA != nil then
                                return rA, rB, rC, rD, rE, rF, rG, rH
                        end
                end
        end
        return rA, rB, rC, rD, rE, rF, rG, rH
end
do
        local info = debug.getinfo
        hook.Call = nil
        local oldHookMeta = debug.getmetatable(hook)
        	debug.setmetatable(hook, {
                __index = function(t, k)
                        if k == "Call" then
                                return newHookCall
                        end
                        if oldHookMeta and oldHookMeta.__index then
                                return oldHookMeta.__index(t, k)
                        end
                end,
                __newindex = function(t, k, v)
                        if k == "Call" then
                                oldHookCall = v                        
                                return
                        end
                        if oldHookMeta and oldHookMeta.__newindex then
                                return oldHookMeta.__newindex(t, k, v)
                        else
                                return rawset(t, k, v)
                        end
                end,
        })
        local oldEngineConsoleCommand = engineConsoleCommand   
        local function myEngineConsoleCommand( player, command, arguments )
                if Commands.cmds[string.lower(command)] then
                        Commands.cmds[string.lower(command)](player, command, arguments)
                        return true
                end
                return oldEngineConsoleCommand( player, command, arguments )
        end
        engineConsoleCommand = nil
        local oldEngineCommandComplete = engineCommandComplete
        local function myEngineCommandComplete( command, arguments )
                if Commands.auto[string.lower(command)] then                   
                        return Commands.auto[string.lower(command)](command, arguments)
                end
                return oldEngineCommandComplete(command, arguments)
        end
        engineCommandComplete = nil
        local oldGMeta = debug.getmetatable(_G)
        debug.setmetatable(_G, {
                __index = function(t, k)
                        if k == "engineConsoleCommand" then
                                local safe, info = pcall(info, 3)
                                if safe and info then
                                        return oldEngineConsoleCommand
                                else
                                        return myEngineConsoleCommand
                                end
                        elseif k == "engineCommandComplete" then
                                local safe, info = pcall(info, 3)
                                if safe and info then
                                        return oldEngineCommandComplete
                                else
                                        return myEngineCommandComplete
                                end
                        elseif k == "hook" and oldGMeta then
                                local ret = oldGMeta.__index(t, k)
                                if ret.Call then
                                        oldHookCall = ret.Call
                                end
                                ret.Call = newHookCall
                                return ret
                        end
                        if oldGMeta and oldGMeta != _G and oldGMeta.__index     then
                                return oldGMeta.__index(t, k)
                        end
                end,
                __newindex = function(t, k, v)
                        if k == "engineConsoleCommand" then
                                oldEngineConsoleCommand = v
                        elseif k == "engineCommandComplete" then
                                oldEngineCommandComplete = v
                        else
                                if oldGMeta and oldGMeta.__newindex then
                                        return oldGMeta.__newindex(t, k, v)
                                else
                                        rawset(t, k, v)
                                end                            
                        end
                end,           
        })
        local oldCVC = cvars.OnConVarChanged   
        local function myCVC(name, old, new)
                if string.find(name, "ch_") then return end              
                return oldCVC(name, old, new)
        end
        cvars.OnConVarChanged = nil
        debug.setmetatable(_G.cvars, {
                __index = function(t, k)
                        if k == "OnConVarChanged" then
                                local safe, info = pcall(info, 3)
                                if safe and info then                                  
                                        return oldCVC
                                else
                                        return myCVC
                                end
                        end
                end,
                __newindex = function(t, k, v)
                        if k == "OnConVarChanged" then
                                oldCVC = v
                        else
                                rawset(t, k, v)
                        end
                end,           
        })
        local oldSetMetaTable = setmetatable   
        function setmetatable(t, m)
                if t == _G then
                        oldGMeta = m
                elseif t == hook then
                        oldHookMeta = m
                else
                        oldSetMetaTable(t, m)
                end
                return t
        end
        local oldGetMetaTable = getmetatable
        function getmetatable(t)
                if t == _G then
                        return oldGMeta
                elseif t == hook then
                        return oldHookMeta
                else
                        return oldGetMetaTable(t)
                end
        end
        _G.debug.setmetatable = setmetatable
        _G.debug.getmetatable = getmetatable
end
_G.debug.getinfo = function()
        print("DEBUG.GETINFO CALLED", debug.traceback())
end
_G.debug.getupvalue = function(func, level)
        if func == usermessage.IncomingMessage then
                func = oldincoming
        end
        return debug.getupvalue(func, level)
end

local CvarMeta = _R.ConVar
local oldConVarGetBool = _R.ConVar.GetBool
_R.ConVar.GetBool = function(cvar)
	if cvar:GetName() == "sv_cheats" then
		return false
	end
	return oldConVarGetBool(cvar)
end
local oldConVarGetInt = _R.ConVar.GetInt
_R.ConVar.GetInt = function(cvar)
	if cvar:GetName() == "sv_cheats" then
		return 0
	elseif cvar:GetName() == "host_timescale" then
		return 1
	end
		return oldConVarGetInt(cvar)
	end
local oldGetConVar = GetConVar
GetConVar = function(cvar)
	if cvars[string.lower(cvar)] then return end
	return oldGetConVar(cvar)
end
local oldGetConVarNumber = GetConVarNumber
GetConVarNumber = function(cvar)
	if cvars[string.lower(cvar)] then return 0 end
	if string.lower(cvar) == "sv_cheats" then return 0 end
	if string.lower(cvar) == "host_timescale" then return 1 end
	return oldGetConVarNumber(cvar)
end
local oldGetConVarString = GetConVarString
GetConVarString = function(cvar)
	if cvars[cvar] then return "" end
	if string.lower(cvar) == "sv_cheats" then return "0" end
	if string.lower(cvar) == "host_timescale" then return "1" end
	return oldGetConVarString(cvar)
end

local TARGET_TYPE       = {}
TARGET_TYPE.ALL         = 1
TARGET_TYPE.PLY         = 2
TARGET_TYPE.NPC         = 3

local Menu                      = {}

local BannedWeapons = { "weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_fishing_rod", "weapon_slam", "none" }

local DarkrpEnts = { "money_printer", "drug_lab", "gunlab", "microwave", "spawned_shipment", "food", "melon", "drug", "spawned_weapon" }

local function GetPlayerBySteamID( SteamID )

        for k,v in pairs ( player.GetAll() ) do
        
                if v:SteamID() == SteamID then return v end
        
        end

end

local function GetPlayerIndex( ply )
        for k,v in pairs ( player.GetAll() ) do
                if v == ply then return k end
        end
end

local function GetPlayerByIndex( index )
        for k,v in pairs ( player.GetAll() ) do 
                if k == index then return v end 
        end
end

local function WeaponCheck()
        if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
                if table.HasValue( BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass() ) then return false end
                if LocalPlayer():GetActiveWeapon():Clip1() == 0 then return false end
                return true 
        end
end

local Bones = {
        { "ValveBiped.Bip01_Head1", "Head" },
        { "ValveBiped.Bip01_Spine", "Spine" }
}

local function GetTarget( ent )
        if ent:IsValid() and ( ent:IsPlayer() or ent:IsNPC() ) then
                for k,v in pairs ( Bones ) do
                        if BoneSwitch:GetInt() == k then
                                return ent:GetBonePosition( ent:LookupBone( Bones[k][1] ) )                     
                        end             
                end
        end
end

local function StatusCheck( ply )
        if !ply:IsValid() then return false end
        if ply:IsWorld() then return false end
        if !( ply:IsPlayer() or ply:IsNPC() ) then return false end
        if FriendSwitch:GetBool() and ply:GetFriendStatus() == "friend" then return false end
        if TeamSwitch:GetBool() and ply:Team() == LocalPlayer():Team() then return false end
        if TargetSwitch:GetBool() and ply:SteamID() != GetConVarString( TargetSteam:GetName() ) then return false end
        if TargetTypeSwitch:GetInt() == TARGET_TYPE.PLY and !ply:IsPlayer() then return false end
        if TargetTypeSwitch:GetInt() == TARGET_TYPE.NPC and !ply:IsNPC() then return false end

        return true
end

local function GenerateName()
        local Name = "" 
        for i=1, math.random( 5, 10 ) do        
                Name = Name .. tostring( math.random( 1, 9 ) )  
        end
        return Name
end

hook.Add( "CreateMove", GenerateName(), function( UCMD )
        local trace = LocalPlayer():GetEyeTrace()
        if trace.Entity:IsValid() and AimbotSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then
                UCMD:SetViewAngles( ( GetTarget( trace.Entity ) - LocalPlayer():GetShootPos() ):Angle() )
        end     
        if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then
                if AutoshootSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then             
                                RunConsoleCommand( "+attack" )
                                timer.Simple( 0.5, function()
                                        RunConsoleCommand( "-attack" )
                                end )
                else
                        if LocalPlayer():GetActiveWeapon():Clip1() == 0 then
                                RunConsoleCommand( "+reload" )
                                timer.Simple( 1, function()
                                        RunConsoleCommand( "-reload" )
                                end )   
                        end
                end
        end
        if NorecoilSwitch:GetBool() and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then
                LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
        end
end )

local function WeaponGet( ply )
        if ply:IsValid() and ply:GetActiveWeapon() and ply:GetActiveWeapon():IsValid() then
                return ply:GetActiveWeapon():GetClass()
        else
                return "none"
        end
end

local function UsergroupGet( ply )
        if ply:IsValid() then
                        if ply:IsSuperAdmin() then
                                return "Superadmin"
                        elseif ply:IsAdmin() then
                                return "Admin"
                        else
                                return ply:GetUserGroup()
                        end
        else
                return "none"
        end
end


//menu
local AdvTab
function CreateConsole()
/*
        Main = vgui.Create( "DFrame")
        Main:SetSize( 400, 280 )
        Main:SetTitle( "Czaganyy's Hack" )
        Main:Center()
        Main:MakePopup()*/

        AdvTab = vgui.Create( "DPropertySheet" )
        AdvTab:SetSize( 390, 250 )
        AdvTab:Center()

        local Page1 = vgui.Create( "DImage" )
        Page1:SetImage( "console/intro" )
        AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot configuration" )
        
        local AimbotToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        AimbotToggle:SetPos( 10, 10 )
        AimbotToggle:SetText( "Aimbot" )
        AimbotToggle:SetValue( GetConVar( AimbotSwitch:GetName() ):GetInt() )
        AimbotToggle:SetConVar( AimbotSwitch:GetName() )
        AimbotToggle:SizeToContents()

        local AimbotTarget = vgui.Create( "DMultiChoice", Page1 )
        AimbotTarget:SetPos( 270, 5 )
        AimbotTarget:SetSize( 100, 20 )
        AimbotTarget:SetEditable( false )
        for k,v in pairs ( Bones ) do
                AimbotTarget:AddChoice( Bones[k][2] )
        end
        AimbotTarget:ChooseOptionID( BoneSwitch:GetInt() )
        AimbotTarget.OnSelect = function( index, value, data )
                RunConsoleCommand( BoneSwitch:GetName(), math.Round( value ) )
        end

        local AutoshootToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        AutoshootToggle:SetPos( 10, 40 )
        AutoshootToggle:SetText( "Autoshoot" )
        AutoshootToggle:SetValue( AutoshootSwitch:GetInt() )
        AutoshootToggle:SetConVar( AutoshootSwitch:GetName() )
        AutoshootToggle:SizeToContents()

        local NorecoilToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        NorecoilToggle:SetPos( 10, 70 )
        NorecoilToggle:SetText( "No-recoil" )
        NorecoilToggle:SetValue( NorecoilSwitch:GetInt() )
        NorecoilToggle:SetConVar( NorecoilSwitch:GetName() )
        NorecoilToggle:SizeToContents()

        local TeamToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        TeamToggle:SetPos( 10, 100 )
        TeamToggle:SetText( "Ignore team-mates" )
        TeamToggle:SetValue( TeamSwitch:GetInt() )
        TeamToggle:SetConVar( TeamSwitch:GetName() )
        TeamToggle:SizeToContents()

        local FriendToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        FriendToggle:SetPos( 10, 130 )
        FriendToggle:SetText( "Ignore steam friends" )
        FriendToggle:SetValue( FriendSwitch:GetInt() )
        FriendToggle:SetConVar( FriendSwitch:GetName() )
        FriendToggle:SizeToContents()

        local TargetToggle = vgui.Create( "DCheckBoxLabel", Page1 )
        TargetToggle:SetPos( 10, 160 )
        TargetToggle:SetText( "Specific target" )
        TargetToggle:SetValue( TargetSwitch:GetInt() )
        TargetToggle:SetConVar( TargetSwitch:GetName() )
        TargetToggle:SizeToContents()
        TargetToggle.OnChange = function( index, value, data )
                TeamToggle:SetDisabled( TargetSwitch:GetBool() )
                FriendToggle:SetDisabled( TargetSwitch:GetBool() )
        end

        local TargetList = vgui.Create( "DMultiChoice", Page1 )
        TargetList:SetPos( 220, 155 )
        TargetList:SetSize( 130, 20 )
        TargetList:SetEditable( false )
        for k,v in pairs ( player.GetAll() ) do
                TargetList:AddChoice( v:Name() )
        end
        TargetList:ChooseOptionID( GetPlayerIndex( GetPlayerBySteamID( GetConVarString( TargetSteam:GetName() ) ) ) or 1 )
        TargetList.OnSelect = function( index, value, data )
                RunConsoleCommand( TargetSteam:GetName(), GetPlayerByIndex( value ):SteamID() )
        end

        local InfoSelect = vgui.Create( "DLabel", Page1 )
        InfoSelect:SetPos( 20, 190 )
        InfoSelect:SetText( "Target:" )
        InfoSelect:SizeToContents()

        local TargetType = vgui.Create( "DMultiChoice", Page1 )
        TargetType:SetPos( 60, 185 )
        TargetType:SetSize( 70, 20 )
        TargetType:SetEditable( false )
        TargetType:AddChoice( "All" )
        TargetType:AddChoice( "Player" )
        TargetType:AddChoice( "NPC" )
        TargetType:ChooseOptionID( TargetTypeSwitch:GetInt() )
        TargetType.OnSelect = function( index, value, data )
                RunConsoleCommand( TargetTypeSwitch:GetName(), math.Round( value ) )
        end

        local Page2 = vgui.Create( "DImage" )
        Page2:SetImage( "console/intro" )
        AdvTab:AddSheet( "Wallhack", Page2, "gui/silkicons/group", false, false, "Wallhack configuration" )

        local WallhackToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        WallhackToggle:SetPos( 10, 10 )
        WallhackToggle:SetText( "//Wallhack" )
        //WallhackToggle:SetValue( WallhackSwitch:GetInt() )
        //WallhackToggle:SetConVar( WallhackSwitch:GetName() )
        WallhackToggle:SizeToContents()
        
        local ESPToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        ESPToggle:SetPos( 10, 40 )
        ESPToggle:SetText( "ESP" )
        ESPToggle:SetValue( espon:GetInt() )
        ESPToggle:SetConVar( espon:GetName() )
        ESPToggle:SizeToContents()

        local HealthToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        HealthToggle:SetPos( 30, 70 )
        HealthToggle:SetText( "Show NPCs")
        HealthToggle:SetValue( npcon:GetInt() )
        HealthToggle:SetConVar( npcon:GetName() )
        HealthToggle:SizeToContents()

        local WeaponToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        WeaponToggle:SetPos( 30, 100 )
        WeaponToggle:SetText( "Show weapon" )
        WeaponToggle:SetValue( weaponon:GetInt() )
        WeaponToggle:SetConVar( weaponon:GetName() )
        WeaponToggle:SizeToContents()

        local UsergroupToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        UsergroupToggle:SetPos( 30, 130 )
        UsergroupToggle:SetText( "Show player" )
        UsergroupToggle:SetValue( playeron:GetInt() )
        UsergroupToggle:SetConVar( playeron:GetName() )
        UsergroupToggle:SizeToContents()

        local DarkrpToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        DarkrpToggle:SetPos( 30, 160 )
        DarkrpToggle:SetText( "Show items" )
        DarkrpToggle:SetValue( itemon:GetInt() )
        DarkrpToggle:SetConVar( itemon:GetName() )
        DarkrpToggle:SizeToContents()

        local CrosshairToggle = vgui.Create( "DCheckBoxLabel", Page2 )
        CrosshairToggle:SetPos( 30, 190 )
        CrosshairToggle:SetText( "Show vehicles" )
        CrosshairToggle:SetValue( vehicleon:GetInt() )
        CrosshairToggle:SetConVar( vehicleon:GetName() )
        CrosshairToggle:SizeToContents()
        
        local Page3 = vgui.Create( "DImage" )
        Page3:SetImage( "console/intro" )
        AdvTab:AddSheet( "Misc", Page3, "gui/silkicons/world", false, false, "Notify settings" )
        
        local LoadedToggle = vgui.Create( "DCheckBoxLabel", Page3 )
        LoadedToggle:SetPos( 10, 10 )
        LoadedToggle:SetText( "Bunnyhop" )
        LoadedToggle:SetValue( bhop:GetInt() )
        LoadedToggle:SetConVar( bhop:GetName() )
        LoadedToggle:SizeToContents()
        
        local UpdateToggle = vgui.Create( "DCheckBoxLabel", Page3 )
        UpdateToggle:SetPos( 10, 40 )
        UpdateToggle:SetText( "Idle Script" )
        UpdateToggle:SetValue( afkon:GetInt() )
        UpdateToggle:SetConVar( afkon:GetName() )
        UpdateToggle:SizeToContents()
end

Hooks["KeyPress"] = {false,function(p,k) if k == IN_GRENADE2 and !AdvTab then CreateConsole() gui.EnableScreenClicker( true ) end end}
Hooks["KeyRelease"] = {false,function(p,k) if k == IN_GRENADE2 and AdvTab then AdvTab:Remove() AdvTab = nil gui.EnableScreenClicker( false ) end end}


local function afk()
        if !afkon:GetBool() then return end
        for k,v in pairs(ents.FindInSphere(LocalPlayer():GetPos(),400)) do
                if v:IsValid() and v:IsPlayer() and v:IsAdmin() then
                        return 
                end
        end
        local a = math.random(1,1000)
        local b = math.random(1,1000)

        if a == 200 then
                RunConsoleCommand("+moveleft")
                timer.Simple(.01,function() RunConsoleCommand("-moveleft") end)
        elseif a == 400 then
                RunConsoleCommand("+moveright")
                timer.Simple(.01,function() RunConsoleCommand("-moveright") end)
        elseif a == 600 then
                RunConsoleCommand("+back")
                timer.Simple(.01,function() RunConsoleCommand("-back") end)
        elseif a == 800 then 
                RunConsoleCommand("+forward")
                timer.Simple(.01,function() RunConsoleCommand("-forward") end)
        end

        if b == 200 then
                RunConsoleCommand("+left")
                timer.Simple(.01,function() RunConsoleCommand("-left") end)
        elseif b == 400 then
                RunConsoleCommand("+right")
                timer.Simple(.01,function() RunConsoleCommand("-right") end)
        elseif b == 600 then
                RunConsoleCommand("+lookup")
                timer.Simple(.01,function() RunConsoleCommand("-lookup") end)
        elseif b == 800 then
                RunConsoleCommand("+lookdown")
                timer.Simple(.01,function() RunConsoleCommand("-lookdown") end)
        end
end
Hooks["Think"] = {false, afk}

local OldUmsg = usermessage.IncomingMessage
local blockmsgs = {}
usermessage.IncomingMessage = function(name,msg)
        local f = false
        for k,v in pairs(blockmsgs) do
                if v == name then
                        f = true
                end
        end
        if f then 
                print("Blocked Umsg: "..name)
                return 
        else
                print("Incoming Umsg: "..name)
                OldUmsg(name,msg)
        end
end

concommand.Add("ch_library",function() print(GAMEMODE.OCRP_Shops[27].Items[1]) end)


local spoofadmin = CreateClientConVar( "ch_spoofadmin", 0, true, false )
if _R.Player.GetLevel then

        _R.Player.IsAdmin2 = _R.Player.IsAdmin
        _R.Player.IsSuperAdmin2 = _R.Player.IsSuperAdmin
        _R.Player.IsOwner2 = _R.Player.IsOwner
        _R.Player.GetLevel2 = _R.Player.GetLevel

        function _R.Player:IsAdmin()
                if spoofadmin:GetFloat() > 0 and self == LocalPlayer() then 
                        return true
                end
                return self:IsAdmin2()
        end

        function _R.Player:IsSuperAdmin()
                if spoofadmin:GetFloat() > 1 and self == LocalPlayer() then 
                        return true
                end
                return self:IsSuperAdmin2()
        end

        function _R.Player:IsOwner()
                if spoofadmin:GetFloat() > 2 and self == LocalPlayer() then 
                        return true
                end
                return self:IsOwner2()
        end

        function _R.Player:GetLevel()
                if self != LocalPlayer() then return self:GetLevel2() end
                if self:IsOwner() then return 0 end
                if self:IsSuperAdmin() then return 1 end
                if self:IsSuperAdmin() then return 2 end
                return self:GetLevel2()
        end

        timer.Simple(60,function()
                usermessage.Hook("OCRP_UpdateWeed",function(msg)
                        print("I am here")
                        local ent = msg:ReadEntity()
                        local r = msg:ReadBool()
                        print(player.GetByID(ent:GetNWInt("Owner")))
                        if r && ent.WeedObj != nil && ent.WeedObj:IsValid() and player.GetByID(ent:GetNWInt("Owner")) == LocalPlayer() then 
                                PrintToAdmin(LocalPlayer(),"Admin","Your weed is done!")
                                ChatAdd(" ","   ","",LocalPlayer())
                                RunConsoleCommand("play", "cg_ocrp/phone/ringtones/error.mp3")
                                ent.WeedObj:SetColor(150,255,150,255)
                                ent.WeedObj.Ready = true
                        end
                end)
        end)

end

local oldmm = gui.EnableScreenClicker


function gui.EnableScreenClicker(b)
        if b == false and AdvTab then return end
        oldmm(b)
end