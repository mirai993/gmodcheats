if !MythX.Version or MythX.Version() != 1.9 then print("MythX error; version mismatch") print("ask mythik for the new update") return end

/*=====================
     Initialization
=======================*/

--// Prevent lua stack leak //--
timer.Simple(1, function()

--// Materials //--
MythX.Mats = { 
    myth = Material( "myth.png", "nocull" ),
    warning = Material( "icon16/error.png", "nocull" ),
    info = Material( "icon16/information.png", "nocull" ),
    keyboard = Material( "icon16/keyboard.png", "nocull" ),
    bricks = Material( "icon16/bricks.png", "nocull" ),
    background = Material( "background.png", "nocull" ),
    arrow = Material( "arrow.png", "nocull" ),
    border = Material( "border.png", "nocull" ),
    border2 = Material( "border2.png", "nocull" ),
    palette = Material( "palette.png", "nocull" ), 
    button = Material( "button.png", "nocull" ), 
    cross = Material( "cross.png", "nocull" ), 
    grad = Material( "grad.png", "nocull" ), 
    grid = Material( "grid.png", "nocull" ), 
    slider = Material( "slider.png", "nocull" ), 
    tick = Material( "tick.png", "nocull" ), 
    x = Material( "x.png", "nocull" );
}

local blackListEnts = {"env_sprite", "env_skypaint", "physgun_beam", "beam", "dmglog_sync_ent", "viewmodel"}
local showing = {}

MythX.entlist = {};

--// Font creation //--

-- Menu font large
surface.CreateFont("Tahoma", {font = "Arial", size = 14, weight = 700, antialias = true})

-- Menu font small
surface.CreateFont("TahomaS", {font = "Arial", size = 12, weight = 500, antialias = true})

-- ESP Font
surface.CreateFont("visuals", {font = "Arial", size = 12, weight = 600})

/*=====================
     CVAR Creation
=======================*/

--// Convar table //--
local cvars = {}

--// Convar loop //--
MythX.Settings = (file.Exists("MythX_Settings.txt", "DATA") and util.JSONToTable(file.Read("MythX_Settings.txt", "DATA"))) or cvars
for k, v in pairs(cvars) do
    if MythX.Settings[k] == nil then
        MythX.Settings = cvars
    end
end

--// Convar update function //--
function update(x,y,z, ok)
    if x == "setting" then
        MythX.Settings[y] = z
        if ok == true then
            file.Write("MythX_Settings.txt", util.TableToJSON(MythX.Settings))
        end
    end
end

--// Default setting creation //--
local settings = MythX.Settings -- local convar table
local menuColor = Color(255,0,0,255) -- default menu color
local aim_key = MOUSE_5; -- Aim key

--// If setting exists, change menu color //--
if settings["menu_color"] then
    menuColor = settings["menu_color"]
end

--// If setting exists, change aim key //--
if settings["aim_key"] then
    aim_key = settings["aim_key"]
end

/*=====================
 Utility menu functions
=======================*/

local Tex_Corner8   = surface.GetTextureID( "gui/corner8" )
local Tex_Corner16  = surface.GetTextureID( "gui/corner16" )
local Tex_white     = surface.GetTextureID( "vgui/white" )
local TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, TEXT_ALIGN_BOTTOM = 0, 1, 2, 3, 4

local function RoundedBoxEx( bordersize, x, y, w, h, color, a, b, c, d )
    x, y, w, h = math.Round( x ), math.Round( y ), math.Round( w ), math.Round( h )

    surface.SetDrawColor( color.r, color.g, color.b, color.a )
    surface.DrawRect( x+bordersize, y, w-bordersize*2, h )
    surface.DrawRect( x, y+bordersize, bordersize, h-bordersize*2 )
    surface.DrawRect( x+w-bordersize, y+bordersize, bordersize, h-bordersize*2 )
    
    local tex = Tex_Corner8
    if ( bordersize > 8 ) then tex = Tex_Corner16 end
    surface.SetTexture( tex )
    
    if ( a ) then
        surface.DrawTexturedRectRotated( x + bordersize/2 , y + bordersize/2, bordersize, bordersize, 0 ) 
    else
        surface.DrawRect( x, y, bordersize, bordersize )
    end
    
    if ( b ) then
        surface.DrawTexturedRectRotated( x + w - bordersize/2 , y + bordersize/2, bordersize, bordersize, 270 ) 
    else
        surface.DrawRect( x + w - bordersize, y, bordersize, bordersize )
    end
 
    if ( c ) then
        surface.DrawTexturedRectRotated( x + bordersize/2 , y + h -bordersize/2, bordersize, bordersize, 90 )
    else
        surface.DrawRect( x, y + h - bordersize, bordersize, bordersize )
    end

    if ( d ) then
        surface.DrawTexturedRectRotated( x + w - bordersize/2 , y + h - bordersize/2, bordersize, bordersize, 180 )
    else
        surface.DrawRect( x + w - bordersize, y + h - bordersize, bordersize, bordersize )
    end
end

local function RoundedBox( bordersize, x, y, w, h, color )
    return RoundedBoxEx( bordersize, x, y, w, h, color, true, true, true, true )
end

local function SimpleText(text, font, x, y, colour, xalign, yalign)
    text    = tostring( text )
    font    = font      or "DermaDefault"
    x       = x         or 0
    y       = y         or 0
    xalign  = xalign    or TEXT_ALIGN_LEFT
    yalign  = yalign    or TEXT_ALIGN_TOP
    surface.SetFont(font)
    local w, h = surface.GetTextSize( text )
    if (xalign == TEXT_ALIGN_CENTER) then
        x = x - w/2
    elseif (xalign == TEXT_ALIGN_RIGHT) then
        x = x - w
    end
    if (yalign == TEXT_ALIGN_CENTER) then
        y = y - h/2
    elseif ( yalign == TEXT_ALIGN_BOTTOM ) then
        y = y - h
    end
    surface.SetTextPos( math.ceil( x ), math.ceil( y ) );
    if (colour!=nil) then
        local alpha = 255
        if (colour.a) then alpha = colour.a end
        surface.SetTextColor( colour.r, colour.g, colour.b, alpha )
    else
        surface.SetTextColor(255, 255, 255, 255)
    end
    surface.DrawText(text)
    return w, h
end

local function SimpleTextOutlined(text, font, x, y, colour, xalign, yalign, outlinewidth, outlinecolour)
    local steps = (outlinewidth*2) / 3
    if ( steps < 1 )  then steps = 1 end
    for _x=-outlinewidth, outlinewidth, steps do
        for _y=-outlinewidth, outlinewidth, steps do
            SimpleText(text, font, x + (_x), y + (_y), outlinecolour, xalign, yalign)
        end
    end
    return SimpleText(text, font, x, y, colour, xalign, yalign)
end

local notifyOn, nmsg, nlabel, nicon, ncolor;
local function notify(icon, label, msg, time, sound, color)
    if sound then
        surface.PlaySound("HL1/fvox/warning.wav")
    end

    notifyOn = true;
    nmsg, nlabel, nicon, ncolor = msg, label, icon, color;
    timer.Simple(time, function() notifyOn, nmsg, nlabel, nicon, ncolor = nil end)
end

/*=====================
  Menu derma creation
=======================*/

local points = {};
local options = {};

local x, y = -160, ScrH() / 2 - 75
local w = 100
local key = 16;
local opamt = 0;
local toMinus = -160
local oi = 0;

local mdown = false;
local mrel = false;
local menuOpen = false;
local opened = false;
local key_down = false;
local key_rel = false;
local menu_toggle = false;
local Mixer;

local textCol = Color(255,0,0,255)

for i = 0, #options do
    tabAmt = i;
end

--// Essentially player.GetAll() //--
local function getPlayers()
    local players = {}
    for i = 1, MythX.GetMaxPlayers() do
        if MythX.GetEntity(i) then
            if MythX.GetEntity(i):GetClass() == "player" then 
                local ply = MythX.GetEntity(i):ToPlayer();
                players[i] = MythX.GetEntity(i):ToPlayer();
            end 
        end
    end
    return players;
end

local function getEnts()
    local players = {}
    for i = 1, MythX.GetMaxEnts() do
        if MythX.GetEntity(i) then
            local ply = MythX.GetEntity(i);
            players[i] = MythX.GetEntity(i);
        end
    end
    return players;
end

local function get_owner(ent)
    for k, v in next, getPlayers() do
        if ent:GetAbsPos():Distance(v:GetAbsPos()) == 36 then
            return v
        end
    end
end

local aim_friends = {} -- Aimbot friends list

--// Derma list creation //--
function MythX:CreateList(x, y, listname1, listname2, tbl)
    local DFrame = vgui.Create("DFrame")
    DFrame:SetPos(x, y)
    DFrame:SetSize(275, 240)
    DFrame:SetTitle("")

    local enemylist = vgui.Create( "DListView", DFrame )
    enemylist:AddColumn( listname1 )
    enemylist:SetPos( 8, 32 )
    enemylist:SetSize(100, 200)
    enemylist:SetDrawBackground(false)
    enemylist.Paint = function()
        RoundedBox( 0, 0, 0, enemylist:GetWide(), enemylist:GetTall(), Color( 150, 150, 150, 255 ) )
    end
 
    local friendlist = vgui.Create( "DListView", DFrame )
    friendlist:AddColumn( listname2 )
    friendlist:SetPos( 167, 32 )
    friendlist:SetSize(100, 200)
    friendlist:SetDrawBackground(false)
    friendlist.Paint = function()
        RoundedBox( 0, 0, 0, friendlist:GetWide(), friendlist:GetTall(), Color( 150, 150, 150, 255 ) )
    end

    local addbutton = vgui.Create( "DButton", DFrame ) 
    addbutton:SetPos( 113, 90 ) 
    addbutton:SetSize( 50, 30 )      
    addbutton:SetText("")
    addbutton.PaintOver = function() SimpleText(">", "BudgetLabel", 20, 8, Color(255,255,255,255)) end
    addbutton.DoClick = function()
        if enemylist:GetSelectedLine() != nil then
            local linename = enemylist:GetLine( enemylist:GetSelectedLine() ):GetValue(1)
            if !table.HasValue(tbl, linename) then
                table.insert(tbl, linename)
                enemylist:RemoveLine(enemylist:GetSelectedLine())
                friendlist:AddLine(linename)
            end
        end
    end
    
    local removebutton = vgui.Create( "DButton", DFrame ) 
    removebutton:SetPos( 113, 130 )
    removebutton:SetSize( 50, 30 ) 
    removebutton:SetText("")
    removebutton.PaintOver = function() SimpleText("<", "BudgetLabel", 20, 8, Color(255,255,255,255)) end
    removebutton.DoClick = function()
        if friendlist:GetSelectedLine() != nil then
            local linename = friendlist:GetLine(friendlist:GetSelectedLine()):GetValue(1)
            if table.HasValue( tbl, linename ) then
                for k, v in next, tbl do
                    if v == linename then
                        table.remove( tbl, k )
                    end
                end
                 
                friendlist:RemoveLine(friendlist:GetSelectedLine())
                enemylist:AddLine(linename)
        
            end
        end
    end

    DFrame:MakePopup();

    local friends, loopTable, loopFunc = {}, nil, nil;

    if listname1 == "Players" then
        loopTable = getPlayers()
    elseif listname1 == "Entities" then
        loopTable = getEnts()
    else
        loopTable = nil;
    end

    if not loopTable then return end

    for k, v in next,( loopTable ) do
        if !v then continue end
        if listname1 == "Players" and !table.HasValue(friends, v:Nick()) and !table.HasValue(tbl, v:Nick()) and v != LocalPlayer() then 
            table.insert( friends, v:Nick() ) 
        elseif listname1 == "Entities" and !table.HasValue(friends, v:GetClass()) and !table.HasValue(tbl, v:GetClass()) and v != LocalPlayer() then 
            local ent = v:GetClass();
            if string.sub(ent, 0, 5) == "class" or string.sub(ent, 0, 5) == "func_" or table.HasValue(blackListEnts, ent) then continue end
            if string.sub(ent, 0, 11) == "weapon_ttt_" then ent = string.sub(ent, 12) end
            if string.sub(ent, 0, 10) == "weapon_zm_" then ent = string.sub(ent, 11) end
            if !table.HasValue(friends, ent) and !table.HasValue(tbl, ent) then
                table.insert( friends, ent) 
            end
        end
    end
    
    table.sort(friends)
    for k, v in next,( friends ) do
        enemylist:AddLine( v )
    end

    table.sort(tbl)
    for k, v in next, tbl do
        friendlist:AddLine( v )
    end
end

--// Derma aim-key panel //--
local function aimkey()
    local Frame = vgui.Create( "DFrame" )
    Frame:SetSize( 75, 25 ) --good size for example
    Frame:SetPos(345, y - 12)
    Frame:SetTitle("Pick a key")
    Frame.btnClose:SetVisible(false);
    Frame.btnMinim:SetVisible(false);
    Frame.btnMaxim:SetVisible(false);
    Frame.OnMousePressed = function(panel, key)
        aim_key = key;
        update("setting", "aim_key", key, true);
        Frame:Close()
    end
    Frame.OnKeyCodePressed = function(panel, key)
        aim_key = key;
        update("setting", "aim_key", key, true);
        Frame:Close()
    end
    Frame:MakePopup();
end

--// Derma text entry panel //--
local function textEntry(title)
    local Frame = vgui.Create( "DFrame" )
    Frame:SetSize( 200, 60 ) --good size for example
    Frame:SetPos(345, y - 12)
    Frame:SetTitle("Change name")
    Frame.btnClose:SetVisible(false);
    Frame.btnMinim:SetVisible(false);
    Frame.btnMaxim:SetVisible(false);

    local TextEntry = vgui.Create( "DTextEntry", Frame ) -- create the form as a child of frame
    TextEntry:SetPos( 5, 30 )
    TextEntry:SetSize( 190, 25 )
    TextEntry:SetText( "Sample String" )
    TextEntry.OnEnter = function( self )
        MythX.SetName( self:GetValue() )
        Frame:Close();
    end

    Frame:MakePopup();
end

--// function for name stealer //--
local function nameSteal()
    local players = getPlayers();
    local ply = players[ math.random( #players ) ]
    if !ply then nameSteal() return end
    if ply == LocalPlayer() then nameSteal() return end
    if ply:Nick() == LocalPlayer():Nick().." " then nameSteal() return end
    MythX.SetName(ply:Nick().."â€ª");
    notify(MythX.Mats.info, "MythX", "Name has been changed to "..ply:Nick().."!", 3, false, Color(0,255,0))
end

--// Aimbot friends-list creation //--
local function friendsList()
    if !IsInGame() then return end
    MythX:CreateList(350, ScrH() / 2 - 100, "Players", "Friends", aim_friends)
end

local function entityList()
    if !IsInGame() then return end
    MythX:CreateList(350, ScrH() / 2 - 100, "Entities", "Shown", MythX.entlist)
end

/*=====================
      Base Helper
=======================*/

local basePos;
local people = {}
local baseFriends = {}
local notified = false
local stored = false

local function baseList()
    MythX:CreateList(350, ScrH() / 2 - 100, "Players", "Friends", baseFriends)
end

local function setBase()
    if !stored then
        basePos = LocalPlayer():GetAbsPos()
        notify(MythX.Mats.info, "MythX", "Your base has been set!", 3, false, Color(0,255,0))
        stored = true
    else
        stored = false
    end
end

function MythX:baseHelper()
    if !basePos then return end
    
    local pos = MythX.ToScreen(basePos)
    
    SimpleTextOutlined("Your Base :)", "Tahoma", pos.x, pos.y, Color( 255,0,0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
            
    for k, v in next, getPlayers() do
        if v == LocalPlayer() then continue end
        if table.HasValue(baseFriends, v:Nick()) then continue end
        if v:GetAbsPos():Distance( basePos ) < tonumber(settings["basingDist"]) and !notified then
            if !table.HasValue(people, v) then
                table.insert(people, v)
            end

            notify(MythX.Mats.warning, "Warning!", "Player "..v:Nick().." was found near your base!", 5, true, Color(255,130,0))    
            notified = true

        elseif v:GetAbsPos():Distance( basePos ) > tonumber(settings["basingDist"]) and notified then
            if table.HasValue(people, v) then
                table.RemoveByValue(people, v)
                notified = false
            end
        end
    end
end

--// Check if mouse is at posistion //--
local function mouseInBox( x, y, w, h )
    local mx, my = gui.MousePos();
    if mx >= x and mx <= x + w and my >= y and my <= y + h then return true; end;
    return false;
end;

/*=====================
    Traitor detector
=======================*/

local flags = {"weapon_ttt_knife", "weapon_ttt_teleport", "weapon_ttt_sipistol", "weapon_ttt_decoy", "weapon_ttt_phammer", "weapon_ttt_c4", "weapon_ttt_radio", "weapon_ttt_push", "weapon_ttt_flaregun"}
local traitors = {}

local w, h = 700, 500
local margin = 15
local bw, bh = 100, 25
local xpos, ypos = ScrW() / 2 - (700 / 2), (ScrH() / 2) - 250
local xpos2, ypos2 = (w - bw - margin), (h - bh - margin/2);
local xpos3, ypos3 = xpos + xpos2, ypos + ypos2

function MythX.reset_traitors()
    timer.Simple(1, function()
        traitors = {}
    end)
end

local function detect_traitors()
    for k, v in next, getEnts() do
        if table.HasValue(flags, v:GetClass()) then
            if get_owner(v) and get_owner(v):GetClass() == "player" then
                if !table.HasValue(traitors, get_owner(v):ToPlayer()) && LocalPlayer():GetTeam() != 1002 && LocalPlayer():Health() > 0 then
                    table.insert(traitors, get_owner(v):ToPlayer())
                    notify(MythX.Mats.info, "MythX", "Player "..get_owner(v):ToPlayer():Nick().." has picked up a traitor weapon!", 3, false, Color(0,255,0))
                end
            end
        end
    end

    if (mouseInBox(xpos3, ypos3, bw, bh) and mrel) or LocalPlayer():GetTeam() == 1002 or LocalPlayer():Health() <= 0 then
        MythX.reset_traitors()
    end
end

/*=====================
     Menu creation
=======================*/

--// enable/disable mouse input //--
local function mouse(bool)
    if bool then
        return MythX.RunString("gui.EnableScreenClicker( true )", false)
    end
    return MythX.RunString("gui.EnableScreenClicker( false )", false)
end

--// Rounding function for sliders //--
local function round(num, idp)
    local mult = 10^(idp or 0)
    return math.floor(num * mult + 0.5) / mult
end

--// Add menu tab //--
local function addTab( text )
    local tab = { };
    tab.text = text;
    tab.options = { };
    tab.i = 0;
    
    options[oi] = tab;
    oi = oi + 1;
end;

--// Add menu tab option //--
local function addOption( tab, text, ctext, value, type, min, max)
    local op = { };
    op.text = text;
    
    op.convar_text = ctext;
    
    for k, v in pairs( options ) do
        if v.text == tab then
            v.options[ v.i ] = op;
            v.i = v.i + 1;
            break;
        end;
    end

    cvars[ctext] = value

    if type then
        op.convar_type = type
    end

    if type == "button" or type == "key" then
        op.func = min;
    end

    if type == "slider" then
        op.min = min
        op.max = max
        points[ctext] = 130 / 2 - 10;
    end
end

--// Image drawing function //--
local function drawSprite(mat, x, y, w, h, col)
    surface.SetMaterial( mat );

    if col ~= nil then
        surface.SetDrawColor( col );
    else
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    end

    surface.DrawTexturedRect( x, y, w, h );
end

--// Slider drawing function //--
local sliderpoint = 130 / 2 - 10
local function DrawSlider(x, y, min, max, val, cvar)
    local toround = 0;

    if min%1 ~= 0 or max%1 ~= 0 then
        toround = 2;
    end

    local sliderpos = 6 + x + sliderpoint 
    local value = round(min+((sliderpos-x )/((x + 128) - x))*(max-min), toround)
    local num = 0;
    
    if(settings[cvar])then
        num = settings[cvar]
    end

    if settings["points"] then
        if settings["points"][cvar] then
            points[cvar] = settings["points"][cvar]
        else
            settings["points"][cvar] = sliderpoint
        end
    end

    if mouseInBox(x + 15, y, 128, 16) and mdown then
        local mX, mY = gui.MousePos();
        sliderpoint = mX - 165 - 15
        points[cvar] = mX - 165 - 15
        num = math.Clamp(value, min, max);
        update("setting", cvar, num, true)
        update("setting", "points", points, true)
    end

    drawSprite(MythX.Mats.grid, x + 15, y - 2, 128, 16)
    drawSprite(MythX.Mats.slider, 15 + x + points[cvar], y - 2, 10, 15)
    SimpleTextOutlined(num, "TahomaS", x + points[cvar] + 20, y + 6, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
end

--// Menu option loop //--
local function loop()
    for i = 0, #options do
        if not options[ i ] then timer.Create( "loopnShit", 1, 0, loop) return end
        local op = options[ i ];
    
        for j = 0, #op.options do
            if(op.options[j] ~= nil)then
                op_op = op.options[ j ];
                op_op.selected = settings[op_op.convar_text]
            end
        end;

        tabAmt = i;
    end;
end
loop()

--// Draw menu //--
local function draw()

    if notifyOn then
        surface.SetFont( "TahomaS" )

        local textW, textH = surface.GetTextSize( nmsg )
        local w, h = 150, textH + 8

        if textW > w then
            w = textW + 8
        end

        local nX, nY = ScrW() / 2 - (w / 2), 200 - (h / 2)

        RoundedBox(0, nX, nY - 25, w, 25, Color(menuColor.r - 20, menuColor.g - 20, menuColor.b - 20))
        RoundedBox(0, nX, nY, w, h, Color(40,40,40))
        drawSprite(nicon, nX + 5, nY - 25 + 5, 16, 16)
        SimpleTextOutlined(nlabel, "TahomaS", nX + 25, nY - 25 + 13, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
        SimpleTextOutlined(nmsg, "TahomaS", nX + 5, nY + 9.5, ncolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
    end

    if input.IsKeyDown(KEY_INSERT) and not key_down then key_down = true; end;
    if key_down and not input.IsKeyDown(KEY_INSERT) then key_rel = true; key_down = false; end;

    if input.IsMouseDown(MOUSE_LEFT) and not mdown then mdown = true; end;
    if mdown and not input.IsMouseDown(MOUSE_LEFT) then mrel = true; mdown = false; end;

    local fps = FrameTime()

    for i = 0, #options do
        if options[ i ].selected then
            toMinus = -320
        end
    end

    if key_rel then
        if !opened then
            x = math.Clamp( x + 750 * fps, toMinus, 0 );
        else
            x = math.Clamp( x - 750 * fps, toMinus, 0 );
        end
    end

    if x == 0 and !opened then
        opened = true;
        key_rel = false;
        mouse(true);
    elseif (x == -160 or x == -320) and opened then
        opened = false;
        key_rel = false;
        mouse(false);
    end

    if x == -160 or x == -320 then return end

    if Mixer then
        if Mixer:IsValid() then
            if Mixer:GetColor() then
                menuColor = Mixer:GetColor()
            else
                menuColor = Color(255,0,0,255)
            end
        end
    end

    for i = 0, #options do
        drawSprite(MythX.Mats.button, x, 1 + y + (i * 34), 160, 35)
        drawSprite(MythX.Mats.arrow, x + 140, 1 + y + (i * 34) + 8, 16, 16)
    end

    drawSprite(MythX.Mats.background, x, y - 33, 160, 35, menuColor)
    drawSprite(MythX.Mats.myth, x + 13, y - 33, 128, 32)
    drawSprite(MythX.Mats.x, x + 13, y - 33, 128, 32, menuColor)

    local op_x = x + 79
    local selected_i = nil;
    for i = 0, #options do
        local op = options[ i ];
        local op_y = y + (i * 34);

        SimpleTextOutlined(op.text, "Tahoma", op_x, op_y + 17.5, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));

        if mouseInBox(x, y + (i * 34), 160, 35) then
            if mrel then
                selected_i = i;
                selected_text = op.text;
                selectedY = i * 34; 
            end
        end

        if(op.selected)then
            local text = selected_text;
            local scaleAmt = 0;

            if opamt > tabAmt then scaleAmt = opamt end
            if tabAmt >= opamt then scaleAmt = tabAmt end

            RoundedBox(0, x + 160, y + 2, 158, 34 * (scaleAmt + 1), Color(33,33,33,255));
            drawSprite(MythX.Mats.border, x + 317, y, 2, 2 + 34 * (scaleAmt + 1), menuColor)
            drawSprite(MythX.Mats.grad, x + 159, y - 33, 160, 35, menuColor)
            SimpleTextOutlined(text, "Tahoma", (x + 160) + 75, y - 15, menuColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
            RoundedBox(0, x, y + selectedY + 2, 160, 34, Color(33,33,33,255));
            drawSprite(MythX.Mats.border, x + 1, y + selectedY + 2, 2, 34, menuColor)
            SimpleTextOutlined(text, "Tahoma", op_x, y + 17.5 + selectedY, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
            
            drawSprite(MythX.Mats.palette, x + 295, y - 24, 16, 16)

            if mouseInBox(x + 295, y - 24, 16, 16) and mrel then
                local worldPanel = vgui.GetWorldPanel();

                local Frame = vgui.Create( "DFrame", worldPanel )
                Frame:SetSize( 267, 186 ) --good size for example
                Frame:SetPos(x + 160 + 160 + 15, y - 24)
                Frame:SetTitle("Pick a color")

                Mixer = vgui.Create( "DColorMixer", Frame )
                Mixer:Dock( FILL )
                Mixer:SetPalette( true ) 
                Mixer:SetAlphaBar( false ) 
                Mixer:SetWangs( true )
                Mixer:SetColor( menuColor )
                Mixer.ValueChanged = function()
                    update("setting", "menu_color", Mixer:GetColor(), true)
                end

                Frame:MakePopup();
            end

            if opamt > tabAmt then
                RoundedBox(0, x, y + 36 + (34 * tabAmt), 160, 34 * (opamt - tabAmt), Color(44,44,44,255))
                drawSprite(MythX.Mats.border, x, y + 36 + (34 * tabAmt), 2, 34 * (opamt - tabAmt), menuColor)
                drawSprite(MythX.Mats.border2, x, y + 36 + 34 * (opamt - tabAmt) + (34 * tabAmt) - 2, 318, 2, menuColor)
            else
                if i == #options then
                    drawSprite(MythX.Mats.border2, x + 1, y + 36 + (34 * tabAmt) - 2, 317, 2, menuColor)
                else
                    drawSprite(MythX.Mats.border2, x + 160, y + 36 + (34 * tabAmt) - 2, 158, 2, menuColor)
                end
            end

            for j = 0, #op.options do
                if op.options[ j ] ~= nil then
                    local op_op = op.options[ j ];
              
                    local x2 = 250          

                    if op_op.convar_type == "slider" then
                        SimpleTextOutlined(op.options[ j ].text, "TahomaS", x + 159 + 76, 8 + y + j * 34, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                        DrawSlider(x + 159, 18 + y + j * 34, op.options[ j ].min, op.options[ j ].max, 50, op.options[ j ].convar_text, op.options[ j ].point)
                    elseif op_op.convar_type == "button" then
                         SimpleTextOutlined(op.options[ j ].text, "TahomaS", x + 194, 18 + y + j * 34, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                         drawSprite(MythX.Mats.bricks, x + 169, 10 + y + j * 34, 16, 16)
                    elseif op_op.convar_type == "key" then
                         SimpleTextOutlined(op.options[ j ].text, "TahomaS", x + 194, 18 + y + j * 34, Color(0,160,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                         drawSprite(MythX.Mats.keyboard, x + 169, 10 + y + j * 34, 16, 16)
                    else
                        if op_op.selected then
                            SimpleTextOutlined(op.options[ j ].text, "TahomaS", x + 194, 18 + y + j * 34, Color(0,255,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                            drawSprite(MythX.Mats.tick, x + 169, 10 + y + j * 34, 16, 16)
                        else
                            SimpleTextOutlined(op.options[ j ].text, "TahomaS", x + 194, 18 + y + j * 34, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                            drawSprite(MythX.Mats.cross, x + 169, 10 + y + j * 34, 16, 16)
                        end
                    end
                    
                    if mouseInBox( x + 160, y + 2 + (34 * j), 160, 35 ) then

                        if (op_op.convar_type == "button" or op_op.convar_type == "key") and mrel then
                            op.options[ j ].func()
                        end

                        if op_op.convar_type ~= "slider" and op_op.convar_type ~= "button" and op_op.convar_type ~= "key" then
                            if mrel then
                                if op_op.selected then
                                    op_op.selected = false;
                                    update("setting", op_op.convar_text, false, true)
                                else
                                    op_op.selected = true;
                                    update("setting", op_op.convar_text, true, true)
                                end
                            end
                        end
                    end

                end
                opamt = j
            end
        else
            toMinus = -160;
        end
    end

    if selected_i then
        for i = 0, #options do
            local op = options[ i ];
            
            if selected_i == i then
                op.selected = not op.selected;
            else
                op.selected = false;
            end;
        end;
    end;

    mrel = false;
end

// Kill evil panels
local function fix_esp()
    MythX.RunString("function cam.Start3D() end function cam.End3D() end", false);
end

/*=====================
  Menu option creation
=======================*/

addTab("Aimbot") 
addOption("Aimbot", "Aim Key", "key", true, "key", aimkey);
addOption("Aimbot", "FOV", "Aim_FOV", 15, "slider", 0, 180);
addOption("Aimbot", "Vertical offset", "Aim_Offset", 0, "slider", -12, 12);
addOption("Aimbot", "Smooth speed", "Aim_SmoothSpeed", 0.05, "slider", 0.01, 0.18);
addOption("Aimbot", "Friends list", "Aim_Friends", true, "button", friendsList);
addOption("Aimbot", "Engine Predicition", "Aim_EnginePred", false);
addOption("Aimbot", "No spread", "Aim_Nospread", false);
addOption("Aimbot", "Hitscan", "Aim_Hitscan", false);
addOption("Aimbot", "Smooth aim", "Aim_Smooth", false);
addOption("Aimbot", "Auto fire", "Aim_AutoShoot", false);
addOption("Aimbot", "Friendly fire", "Aim_FriendlyFire", false);

addTab("ESP")
addOption("ESP", "Max distance", "ESP_MaxDist", 15, "slider", 0, 8000);
addOption("ESP", "Enabled", "ESP", true);
addOption("ESP", "Box ESP", "ESP_Box", true);
addOption("ESP", "Only show enemies", "ESP_Enemies", true);
addOption("ESP", "Skeleton ESP", "ESP_HitBox", true);
addOption("ESP", "Entity ESP", "EntESP", true);
addOption("ESP", "Entity list", "EntESP_List", false, "button", entityList);

addTab("Base helper")
addOption("Base helper", "Set base", "baseHelper", false, "button", setBase);
addOption("Base helper", "Base friends", "baseFriends", false, "button", baseList);
addOption("Base helper", "Notify radius", "basingDist", 100, "slider", 1, 500);

addTab("Misc")
addOption("Misc", "Bunnyhop", "Bunnyhop", true);
addOption("Misc", "Spectator list", "spectator_list", true);
addOption("Misc", "Traitor detector", "traitor_detector", true);
addOption("Misc", "Fix ESP", "fixESP", true, "button", fix_esp);
addOption("Misc", "Reset traitors", "resettraitors", true, "button", MythX.reset_traitors);
addOption("Misc", "Change name", "Namechange", true, "button", textEntry);
addOption("Misc", "Steal a name", "nameSteal", true, "button", nameSteal);

/*=====================
    Aimbot functions
=======================*/

--// Distance function //--
function math.Dist( x1, y1, x2, y2 )
    local xd = x2-x1
    local yd = y2-y1
    return math.sqrt( xd*xd + yd*yd )
end

--// Entity distance function //--
function MythX.Dist( p1, p2 )
    return p1:GetPos():Distance( p2:GetPos() )
end

local function is_spec(ply)
    return ply:GetTeam() == 1002;
end

--// Check if player is a valid target //--
local function valid_target(ply)
    if !ply then return false end
    if ply:Health() <= 0 then return false end
    if is_spec(ply) && !is_spec(LocalPlayer()) then return false end
    if is_spec(LocalPlayer()) && !is_spec(ply) then return false end
    if (ply:GetTeam() == LocalPlayer():GetTeam()) && !is_spec(ply) and !settings["Aim_FriendlyFire"] then return false end
    if table.HasValue(aim_friends, ply:Nick()) then return false end

    return true;
end

local bones = {
    "ValveBiped.Bip01_Head1", 
    "ValveBiped.Bip01_Neck1",
    "ValveBiped.Bip01_Spine4",
    "ValveBiped.Bip01_Spine2",
    "ValveBiped.Bip01_Spine", 
    "ValveBiped.Bip01_R_UpperArm",
    "ValveBiped.Bip01_L_UpperArm",
    "ValveBiped.Bip01_R_Forearm",
    "ValveBiped.Bip01_L_Forearm",
    "ValveBiped.Bip01_R_Hand",
    "ValveBiped.Bip01_L_Hand",
    "ValveBiped.Bip01_R_Calf",
    "ValveBiped.Bip01_L_Calf",
    "ValveBiped.Bip01_R_Foot",
    "ValveBiped.Bip01_L_Foot"
}

local function get_bone(ply, num)
    local hitbox = ply:GetBonePosition(num);

    if hitbox && hitbox ~= zero_vec then
        return hitbox;
    end

    return false;
end

local function optimal_bone(ply)
    for k, v in next, bones do
        local bone = get_bone(ply, ply:LookupBone(v));

        if !bone then continue end;

        if MythX.IsVisible(LocalPlayer():GetAbsEyePos(), bone, ply) then
            return bone;
        end
    end
    return nil;
end

--// Check if player is in FOV //--
function in_fov(ent)
    local fov = settings["Aim_FOV"]
    if( fov != 180 ) then
        local eyepos = ent:GetAbsEyePos()
        if settings["Aim_Hitscan"] then
            eyepos = optimal_bone(ent) or ent:GetAbsEyePos();
        end
        local lpang = LocalPlayer():GetAngles()
        local ang = MythX.VectorAngles(eyepos - LocalPlayer():GetAbsEyePos())
        local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
        local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
        if( ady > fov || adp > fov ) then return false end
    end
    return true
end

--// Angle distance function //--
function angle_diff(ang, ang2, num)
     local ady = math.abs( math.NormalizeAngle( ang.y - ang2.y ) )
     local adp = math.abs( math.NormalizeAngle( ang.p - ang2.p ) )
     if( ady > num || adp > num ) then return false end
     return true;
end

local zero_ang = Angle(0, 0, 0);
local zero_vec = Vector(0, 0, 0);

local function get_hitbox(ply, num)

    local hitbox = MythX.CalculateAimVector(ply, num);

    if hitbox && hitbox ~= zero_vec then
        return hitbox;
    end

    return false;
end

--// Return the current aimbot target //--
local function aimTarget()
    if not aimTarg then return end
    if aimTarg == 0 then return end

    return aimTarg
end

--// Get best aimbot target //--
local function getTarget()
    local p = LocalPlayer()
    local closest, dist = nil, 0
    local target = 0

    for k, v in next, getPlayers() do

        if k == MythX.GetLocalPlayerIndex() then continue end

        if not MythX.IsVisible(p:GetAbsEyePos(), v:GetAbsEyePos(), v) && !settings["Aim_Hitscan"] then continue end

        if not valid_target(v) then continue end

        if not in_fov(v) then continue end 

        local _dist = math.Dist(MythX.ToScreen(v:GetAbsEyePos()).x, MythX.ToScreen(v:GetAbsEyePos()).y, ScrW()/2, ScrH()/2)
    
        if (!closest or _dist < dist) then
            dist = _dist
            closest = v
            target = v
        end
    end

    aimTarg = target
end

/*=====================
         Aimbot
=======================*/

--// Aimbot function //--
local function aim(cmd)

    getTarget()

    local v = aimTarget()
    local ply = LocalPlayer()

    if aim_key >= 107 then
        if not (input.IsMouseDown(aim_key)) then return end
    else
        if not (input.IsKeyDown(aim_key)) then return end
    end

    if not v then return end

    local ang = optimal_bone(v);

    if ang then

        if settings["Aim_Offset"] ~= 0 then
            ang = ang - Vector(0,0,settings["Aim_Offset"])
        end

        local angle = MythX.VectorAngles(ang - ply:GetAbsEyePos())
        local preang = angle;

        if settings["Aim_Smooth"] then
            angle = LerpAngle(settings["Aim_SmoothSpeed"], cmd:GetViewAngles(), angle);
        end

        if settings["Aim_Nospread"] && type(MythX.CompensateSpread()) == "Angle" then
            cmd:SetViewAngles(angle + MythX.CompensateSpread());
        else
            cmd:SetViewAngles(angle);
        end

        if settings["Aim_AutoShoot"] then
            if settings["Aim_Smooth"] and !angle_diff(angle, preang, 0.5) then return end
            cmd:AutoShoot()
        end
    end
end

/*=====================
     Spectator List
=======================*/

local niggers, prefix = {}, {}

local function draw_list()
    for k, v in next, getPlayers() do
        if !v then continue end
        if v == LocalPlayer() then continue end

        local target = MythX.GetEntity(v:GetObserverTarget());
        local me = LocalPlayer():Nick();

        if table.HasValue(niggers, v:Nick()) then
            if !target then
                table.RemoveByValue(niggers, v:Nick());
            else
                if target:ToPlayer() then
                    if target:ToPlayer():Nick() ~= me then
                        table.RemoveByValue(niggers, v:Nick());
                    end
                else
                    table.RemoveByValue(niggers, v:Nick());
                end
            end
        end

        if target && target:ToPlayer() && !table.HasValue(niggers, v:Nick()) then
            if target:ToPlayer():Nick() == LocalPlayer():Nick() then
                table.sort(niggers)
                table.insert(niggers, v:Nick())
            end
        end
    end

    if niggers[1] then
        SimpleTextOutlined( "Your being spectated by:", "Tahoma", 25, 25, Color(255,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
    end

    for k, v in next, niggers do
        table.sort(niggers)
        SimpleTextOutlined(v, "Tahoma", 25, k * 12 + 25, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
    end
end

/*=====================
       Entity ESP
=======================*/

// Entity ESP
function MythX:EntESP()
    if not settings["EntESP"] then return end

    for k, v in next, getEnts() do   
        if !v or v == nil then continue end

        if table.HasValue(MythX.entlist, v:GetClass()) or table.HasValue(MythX.entlist, string.sub(v:GetClass(), 11)) or table.HasValue(MythX.entlist, string.sub(v:GetClass(), 12)) then
            if v:GetAbsPos():Distance(LocalPlayer():GetAbsPos()) > tonumber(settings["ESP_MaxDist"]) then continue end
            local pos, text = MythX.ToScreen(v:GetAbsPos()), v:GetClass()
            if string.sub(v:GetClass(), 0, 11) == "weapon_ttt_" then
                text = string.sub(v:GetClass(), 12)
            elseif string.sub(v:GetClass(), 0, 10) == "weapon_zm_" then
                text = string.sub(v:GetClass(), 11)
            end
            SimpleTextOutlined(text, "Tahoma", pos.x, pos.y + 16, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
        end
    end
end

/*=====================
      ESP & Drawing
=======================*/

local function GetAimVector()
    return MythX.GetViewAngles():Forward()
end 

function MythX.EyeTrace()
    local me = LocalPlayer();
    local eyepos = me:GetAbsEyePos();
    local endvec = eyepos + GetAimVector() * 8192;
    return MythX.GetEyeTrace(eyepos, endvec);
end

local spine = {"Head1", "Neck1", "Spine4", "Spine2", "Spine1", "Spine"};
local arm1 = {"R_Hand", "R_Forearm", "R_UpperArm", "R_Clavicle"};
local arm2 = {"L_Hand", "L_Forearm", "L_UpperArm", "L_Clavicle"};
local leg1 = {"R_Thigh", "R_Calf", "R_Foot", "R_Toe0"};
local leg2 = {"L_Thigh", "L_Calf", "L_Foot", "L_Toe0"};

local function DrawBone(ply, b1, b2)
    if !ply or !b1 or !b2 then return end

    local name1, name2 = "ValveBiped.Bip01_"..b1, "ValveBiped.Bip01_"..b2;
    local bone1, bone2 = ply:GetBonePosition(ply:LookupBone(name1)), ply:GetBonePosition(ply:LookupBone(name2));

    if !bone1 or !bone2 then return end
    if bone1 == -1 or bone2 == -1 then return end

    local pos1, pos2 = MythX.ToScreen(bone1), MythX.ToScreen(bone2);

    if pos1 && pos2 then
        surface.SetDrawColor(255,255,255);
        surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y);
    end
end

local function bone_esp(ply)
    for i = 1, 6 do -- Spine
        DrawBone(ply, spine[i], spine[i + 1]);
    end

    for i = 1, 4 do -- Limbs
        DrawBone(ply, arm1[i], arm1[i + 1]);
        DrawBone(ply, arm2[i], arm2[i + 1]);
        DrawBone(ply, leg1[i], leg1[i + 1]);
        DrawBone(ply, leg2[i], leg2[i + 1]);
    end

    -- Joints
    DrawBone(ply, arm1[4], spine[2]);
    DrawBone(ply, arm2[4], spine[2]);
    DrawBone(ply, leg1[1], spine[6]);
    DrawBone(ply, leg2[1], spine[6]);
end

--// Master drawing function //--
local function drawCheat()

    if notifyOn then
        surface.SetFont( "TahomaS" )

        local textW, textH = surface.GetTextSize( nmsg )
        local w, h = 150, textH + 8

        if textW > w then
            w = textW + 8
        end

        local nX, nY = ScrW() / 2 - (w / 2), 200 - (h / 2)

        RoundedBox(0, nX, nY - 25, w, 25, menuColor)
        RoundedBox(0, nX, nY, w, h, Color(40,40,40))
        drawSprite(nicon, nX + 5, nY - 25 + 5, 16, 16)
        SimpleTextOutlined(nlabel, "TahomaS", nX + 25, nY - 25 + 13, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
        SimpleTextOutlined(nmsg, "TahomaS", nX + 5, nY + 9.5, ncolor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
    end

    draw()

    local me = LocalPlayer();

    if IsInGame() then

        if settings["spectator_list"] then
            draw_list();
        end

        if settings["EntESP"] then
            MythX:EntESP()
        end

        MythX:baseHelper()

        if settings["ESP"] then
            for _, ply in next, getPlayers() do
                
                if ply == me then continue end

                if settings["ESP_Enemies"] && (ply:GetTeam() == LocalPlayer():GetTeam()) && !is_spec(ply) then continue end

                if is_spec(ply) && !is_spec(LocalPlayer()) then continue end

                if ply:GetAbsPos():Distance(LocalPlayer():GetAbsPos()) < tonumber(settings["ESP_MaxDist"]) then

                    if ply:Health() <= 0 then continue end

                    local col = Color(0,255,0);
        
                    if ply == aimTarget() then
                        col = Color( 0, 157, 255 );
                    end

                    if !settings["Aim_Hitscan"] then
                        if not MythX.IsVisible(LocalPlayer():GetAbsEyePos(), ply:GetAbsEyePos(), ply) then
                            col = Color(255,0,76);
                        end
                    else
                        local bone = optimal_bone(ply);
                        if bone then
                            if not MythX.IsVisible(LocalPlayer():GetAbsEyePos(), bone, ply) then
                                col = Color(255,0,76);
                            end
                        else
                            col = Color(255,0,76);
                        end
                    end

                    local min, max, pos = ply:OBBMins(), ply:OBBMaxs(), ply:GetAbsPos()
                    local top, bottom = MythX.ToScreen(pos + Vector(0, 0, max.z)), MythX.ToScreen(pos - Vector(0, 0, 15))
                    local middle = bottom.y - top.y
                    local width = middle / 2.5

                    if settings["ESP_Box"] then
                        local pos2 = pos + Vector(0, 0, max.z);
                        local pos = MythX.ToScreen(pos);
                        local pos2 = MythX.ToScreen(pos2);
                        local h = pos.y - pos2.y;
                        local w = h / 2;

                        surface.SetDrawColor(col);
                        surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
                        surface.SetDrawColor(Color(0,0,0));
                        surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
                        surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
    
                        surface.SetFont("visuals");
                        surface.SetTextColor(255, 255, 255);
        
                        local col = Color(( 100 - ply:Health() ) * 2.55, ply:Health() * 2, 0, 255);
                        local hp = ply:Health() * h / 100;
                        if(hp > h) then hp = h; end
                        local diff = h - hp;
                        surface.SetDrawColor(0, 0, 0, 255);
                        surface.DrawRect(pos.x - w / 2 - 6, pos.y - h - 1, 4, h + 2);
                        surface.SetDrawColor(col);
                        surface.DrawRect(pos.x - w / 2 - 5, pos.y - h + diff, 2, hp);
        
                        if table.HasValue(traitors, ply) then
                            SimpleTextOutlined("-TRAITOR-", "visuals", pos.x, pos.y + 10, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                        end

                        local col1 = Color(255,255,255)
                        SimpleTextOutlined(ply:Nick(), "visuals", pos.x, pos.y - h - 1 - 7, col1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255));
                    end

                    if settings["ESP_HitBox"] then
                       bone_esp(ply);
                    end
                end
            end
        end
    end
end

/*=====================
        Hooking
=======================*/

local Hooks = {}

--// Hook called function //--
function MythX.OnHookCall(hookname, a1, a2, a3, a4, a5, a6, a7, a8, a9)

    MythX.SetHookFunc(MythX.OnHookCall)

    if(!hookname) then
        return
    end
    
    local func = MythX.HookTable[hookname]

    if(!func) then
        print("!FUNC: " .. hookname)
        return
    end

    local succ, reta, retb, retc, retd, rete, retf, retg = pcall(func, a1, a2, a3, a4, a5, a6, a7, a8, a9)
    if(not succ) then
        print("!HOOK CALL: " .. reta)
        return
    end

    return reta, retb, retc, retd, rete, retf, retg

end

--// Return hook function //--
local function hook_func(hooknamescrub, ...)
    if(Hooks[hooknamescrub]) then
        return Hooks[hooknamescrub](...)
    end

    return nil
end
MythX.SetHookFunc(hook_func, Vector, Angle)


--// Create move hook //--
local function OnCreateMove(cmd)
    if settings["Bunnyhop"] then
		MythX.Bunnyhop();
    end

    if settings["Aim_EnginePred"] then
        MythX.EnginePred();
    end

    aim(cmd)

    if settings["traitor_detector"] then
        detect_traitors()
    end
end

--// Hook creation //--
Hooks["OnCreateMove"] = OnCreateMove
hook.GetTable()["DrawOverlay"]["CaptureFrames"] = drawCheat;

--// Run code in menu state //--
concommand.Add("menu_run", function(p,c,a,s)
    MythX.RunString(s, true)
end)

concommand.Add("menu_openscript", function(p,c,a,s)
    MythX.OpenScript(s, true)
end)

concommand.Add("menu_openclient", function(p,c,a,s)
    MythX.OpenScript(s, false)
end)

--// Finished loading! //--

MsgC( Color( 0, 255, 0 ), "MythX has successfully loaded!" )
notify(MythX.Mats.info, "Welcome!", "MythX v"..MythX.Version().." has loaded successfully!", 5, false, Color(0,255,0))

end) -- lua stack leak prevention]])