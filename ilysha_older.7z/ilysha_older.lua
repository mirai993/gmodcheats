local surfaceSetColor = surface.SetDrawColor
local surfaceDrawOutline = surface.DrawOutlinedRect
local surfaceSetMaterial = surface.SetMaterial
local surfaceDrawTexturedRect = surface.DrawTexturedRect

-- ilysha.lua

local blur = Material 'pp/blurscreen'
function blurPanel(pnl)
	local x, y = pnl:LocalToScreen(0, 0)
	surface.SetDrawColor(255, 255, 255, 255)
	surface.SetMaterial(blur)
	for i = 1, 6 do
		blur:SetFloat('$blur', (i / 3) * 6)
		blur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(x * -1, y * -1, ScrW(), ScrH())
	end
end
function surfaceOutline(x,y,w,h,thikness,color)
	surfaceSetColor(Color(color.r,color.g,color.b,color.a))
	surfaceDrawOutline(x,y,w,h,thikness)
end
function surfaceTexture(x,y,w,h,material,color,rot)
	if material == nil or material == "" then return end
    if rot == nil then
        surface.SetDrawColor( color.r, color.g, color.b, color.a )
        surface.SetMaterial(Material(material))
        surface.DrawTexturedRect(x,y,w,h)
    else
        surface.SetDrawColor( color.r, color.g, color.b, color.a )
        surface.SetMaterial(Material(material))
        surface.DrawTexturedRectRotated(x,y,w,h,rot)
    end
end

function draw.Circle( x, y, radius, seg )
	local cir = {}
	table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
	for i = 0, seg do
		local a = math.rad( ( i / seg ) * -360 )
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
	end
	local a = math.rad( 0 )
	table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
	surface.DrawPoly( cir )
end


function RainbowLine(x,y,w,h,speed,size)
	local hsv
	for i = 0,w do 
		hsv = HSVToColor( ( CurTime() * speed + i ) % 360, 1, 1 )
		surface.SetDrawColor(hsv.r,hsv.g,hsv.b,255)
		if size != 0 and size != 0 then
			if i != w then
				if i != 0 then
					surface.DrawRect(x+i*size,y,size,h)
				else
					surface.DrawRect(x+i,y,size,h)
				end
			end
		else
			surface.DrawRect(x+i,y,1,h)
		end
	end
end

function DrawRainbowText( speed, str, font, x, y )
	surface.SetFont( font )
	surface.SetTextPos( x, y )

	for i = 1, #str do
		local col = HSVToColor(  ( CurTime() * speed + (i * 5) ) % 360, 1, 1 )
		surface.SetTextColor( col.r, col.g, col.b )			
		surface.DrawText( string.sub( str, i, i ) )
	end
end

require("zxcmodule")

consoleLogs = {}
function AddConsoleMessage(text,color)
    table.insert(consoleLogs, {
        text,
        color.r,
        color.g,
        color.b,
    })
end

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
surface.CreateFont( "MainFont", {
	font = "Tahoma",
	extended = true,
	size = 17,
	weight = 1000,
	antialias = true,
    shadow = true,
    outline = false
} )
surface.CreateFont( "KeybinderFont", {
	font = "Tahoma",
	extended = true,
	size = 12,
	weight = 1000,
	antialias = true,
    shadow = true,
    outline = false
} )
surface.CreateFont( "ESP Font", {
	font = "comfortaa",
	extended = true,
	size = 16.5,
	weight = 550,
    antialias = true,
    shadow = true,
    outline = true,
} )
surface.CreateFont( "ConsoleLog", {
	font = "Verdana",
	extended = true,
	size = 13,
	weight = 500,
	antialias = true,
} )
surface.CreateFont( "Font01", {
	font = "Arial",
	extended = true,
	size = 20,
	weight = 1000,
	antialias = true,
} )
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
local FindMetaTable = FindMetaTable;

local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";

local mNormalizeAng = math.NormalizeAngle

local cfg = {
    ["newcfg"] = "newcfg",
	Aimbot = {
		["aimbot_enable"] = false,

		["aimbot_silent"] = false,

        ["aimbot_aim_target"] = 1,

        ["hitbox_head"] = false,
        ["hitbox_head_roll"] = false,
        ["hitbox_head_mp"] = false,
        ["hitbox_head_mp_scale"] = 1,

        ["hitbox_eyes"] = false,

        ["hitbox_body"] = false,
        ["hitbox_body_mp"] = false,
        ["hitbox_body_mp_scale"] = 1,

        ["hitbox_arms"] = false,
        ["hitbox_legs"] = false,

        ["aimbot_bodyaim_alwayson"] = false,
        ["aimbot_bodyaim_conditions"] = 1,
        ["aimbot_bodyaim_hp"] = 71,
        ["aimbot_ignore_team"] = false,
        ["aimbot_ignore_fr"] = false,
        ["aimbot_ignore_nv"] = false,
        ["aimbot_snapline"] = false,
        
		["aimbot_autofire"] = false,
		["aimbot_autowall"] = false,
		["aimbot_autoreload"] = false,
        ["aimbot_rapidfire"] = false,
	
		["aimbot_nospread"] = true,
		["aimbot_norecoil"] = true,
        ["aimbot_flfix"] = true,

        ["aimbot_resolver"] = false,
        ["aimbot_resolver_step"] = 54,
        ["aimbot_resolver_pitch"] = false,

        ["aimbot_rtx"] = false,
	},
	Ragebot = {
        ["fakelag_enable"] = false,
        ["fakelag_type"] = 1, 
        ["fakelag_amount"] = 1, 
		["antiaim_enable"] = false,
        ["antiaim_yaw_base"] = 1,
        ["antiaim_yaw"] = 1,
        ["antiaim_pitch"] = 1,
        ["antiaim_fyaw"] = 1,
        ["antiaim_jitterrange"] = 29,
        ["antiaim_jitterrange_f"] = 29,
        ["antiaim_spinspeed"] = 55,
        ["antiaim_creal"] = 175,
        ["antiaim_cfake"] = 85,
        ["fake_chams"] = false,
        ["real_chams"] = false,
        ["real_chams_real"] = false,
        ["fakelag_chams"] = false,

        ["antiaim_sr"] = false,
        ["antiaim_hr"] = false,

        ["dance_spam"] = false,
        ["dance_spam_act"] = 3,
        ["dance_spam_kt"] = false,
        ["antiaim_extenddesync"] = false,
        --["antiaim_roll"] = false,
	},
    Misc = { 
        ["misc_3rdp"] = false,
        ["misc_3rdp_d"] = 10,
        ["misc_3rdp_s"] = 25,
        ["misc_ofov"] = false,
        ["misc_ofov_v"] = 90,
        ["misc_3rdp_coll"] = false,

        ["misc_hitsound"] = false,
        ["misc_hitsound_method"] = 1,
        ["misc_hitsound_sound"] = 1,
        ["misc_killsound"] = false,
        ["misc_killsound_ks"] = false,
        ["misc_killsound_sound"] = 1,

        ["misc_hitmarker"] = false,
        ["misc_hitmarker_pos"] = 1,

        ["misc_inds"] = false,
        ["misc_inds_grad"] = false,
        ["misc_inds_r"] = 5,
        ["misc_inds_hsv"] = false,
        ["misc_inds_hsv_g"] = false,
        ["misc_inds_s"] = 1,

        ["misc_heartmarker"] = false,
        ["misc_heartmarker_color"] = 1,

        ["misc_bullettrace"] = false,
        ["misc_bullettrace_type"] = 1,
        ["misc_bullettrace_blinking"] = false,
        ["misc_bullettrace_time"] = 1,

        ["misc_bulletimpact"] = false,
        ["misc_bulletimpact_time"] = 3,
        ["misc_bulletimpact_glow"] = false,

        ["misc_bullettrace_e"] = false,
        ["misc_bullettrace_type_e"] = 1,
        ["misc_bullettrace_blinking_e"] = false,
        ["misc_bullettrace_time_e"] = 1,

        ["misc_bulletimpact_e"] = false,
        ["misc_bulletimpact_time_e"] = 3,
        ["misc_bulletimpact_glow_e"] = false,

        ["misc_bullettrace_onlyt"] = false,

        ["misc_so2_hands"] = false,

        ["logs_hurt"] = false,

        ["misc_chatspam"] = false,
        ["misc_killsay"] = false,
        ["misc_killsay_o"] = false,
        ["misc_chatspam_ar"] = false,
        ["misc_chatspam_lang"] = 1,
        ["misc_chatspam_timer"] = 1,

        ["wall_color"] = false,
        ["prop_color"] = false,

        ["sky_3d"] = false,
        ["sky_b"] = false,
        ["sky_f"] = false,
        ["sky_c"] = false,
        ["skyboxname"] = "sky_day01_09",
        ["sky_ch"] = false,

        ["fall_predict"] = false,
        ["csgo_bscope"] = true,
        ["csgo_bscope_dl"] = true,
        ["csgo_bscope_alt"] = true,
        ["viewmodel_wireframe"] = false,

        ["fog_e"] = false,
        ["fog_s"] = 0,
        ["fog_end"] = 1000,
        ["fog_d"] = 0.3,
        ["skininput"] = "models/wireframe",
    },
    Movement = { 
        ["move_bhop"] = false,
        ["move_ap"] = false,
        ["move_ap_ar"] = false,
        ["move_ap_s"] = 1,
        ["move_ap_sp"] = false,
        ["move_ap_apb"] = false,
        ["move_ap_anim"] = false,
        ["move_strafe"] = false,
        --["move_ls"] = false,
        ["move_autodir"] = false,
        ["move_gstrafe"] = false,
        ["move_circle_strafe"] = false,
        ["move_add_speed"] = false,
        --["move_awalls"] = false,

        ["move_ad"] = false,

        ["move_fd"] = false,
        ["move_fd_m"] = 1,

        ["move_sw"] = false,
        ["move_sws"] = 10,
        ["move_ds"] = false,
        ["move_aw"] = false,
        ["move_aw_d"] = false,

        ["move_aw_len"] = 100,
        ["move_aw_speed"] = 2500,
    },
    ESP = { 
        ["oof_arrows"] = false,
        ["oof_arrows_d"] = false,
        ["oof_arrows_b"] = false,
        ["oof_arrows_bs"] = 2,
        ["oof_arrows_as"] = 10,
        ["oof_arrows_ad"] = 25,

        ["hit_effect"] = false,

        ["logs_enable"] = false,

        ["aa_lines"] = false,
        ["esp_box_r"] = false,
        ["esp_box_grad_r"] = false,
        ["esp_box_f_r"] = false,

        ["esp_box"] = false,
        ["esp_box_grad"] = false,
        ["esp_box_f"] = false,
        ["esp_box_type"] = 1,
        ["esp_box_fr"] = false,
        ["esp_box_trg"] = false,
        ["esp_box_team"] = false,

        ["esp_name"] = false,
        ["esp_wep"] = false,
        ["esp_hp"] = false,
        ["esp_ap"] = false,
        ["self_trail"] = false,

        ["esp_hp_bar"] = false,
        ["esp_hp_bar_ac"] = false,
        ["esp_hp_bar_gradient"] = false,

        ["chams_visible"] = false,
        ["chams_visible_att"] = false,
        ["chams_invisible"] = false,
        ["chams_invisible_att"] = false,

        ["chams_visible_mat"] = 1,
        ["chams_invisible_mat"] = 1,

        ["glow_esp"] = false,
        ["glow_esp_a"] = false,
        ["glow_esp_att"] = false,  
        
        ["fake_chams_m"] = 1,
        ["real_chams_m"] = 1,
        ["fakelag_chams_m"] = 1,
    },
	Colors = {
        ["viewmodel_wireframe"] = "255 0 0 255",
        ["move_ap"] = "255 25 128 255",
        ["csgo_bscope"] = "255 128 128 215",
        ["sky_f"] = "128 128 128 255",
        ["fog_e"] = "128 128 255 255",
        ["sky_c"] = "128 128 255 255",
        
        ["wall_color"] = "255 255 255 255",
        ["prop_color"] = "0 0 0 128",
        
        ["oof_arrows"] = "255 0 0 255",
        ["oof_arrows_d"] = "128 128 128 128",

        ["glow_esp"] = "255 0 0 255",

        ["misc_inds"] = "0 255 0 255",
        ["misc_inds_grad"] = "255 0 0 255",

        ["chams_visible"] = "0 255 0 255",
        ["chams_invisible"] = "255 0 0 255",

        ["logs_hurt"] = "255 15 15 255",
        ["legit_fov_draw"] = "255 25 25 255",

        ["esp_hp_bar"] = "0 255 0 255",
        ["esp_hp_bar_gradient"] = "255 0 0 255",
        ["esp_wep"] = "255 255 255 255",
        ["esp_name"] = "255 255 255 255",
        ["esp_hp"] = "25 255 25 255",
        ["esp_ap"] = "100 100 255 255",
        ["esp_box"] = "255 255 255 255",
        ["esp_box_grad"] = "255 25 25 85",
        ["esp_box_f"] = "255 255 255 55",
        ["esp_box_fr"] = "0 255 0 255",
        ["esp_box_trg"] = "255 0 200 255",

        ["misc_hitmarker"] = "255 255 255 255",
        ["misc_heartmarker"] = "255 255 255 255",

        ["misc_bullettrace"] = "25 25 255 200",

        ["logs_enable"] = "255 25 128 255",

        ["fake_chams"] = "255 45 45 255",
        ["real_chams"] = "45 255 45 255",
        ["fakelag_chams"] = "2 183 255 255",

        ["misc_bulletimpact"] = "25 25 255 200",
        ["misc_bullettrace_e"] = "255 25 25 200",
        ["misc_bulletimpact_e"] = "255 25 25 200",
        ["aimbot_snapline"] = "255 255 255 255",
    },
	Keybinds = {
		["key_tp"] = 0,
        ["key_cstrafe"] = 0,
        ["key_fd"] = 0,
        ["key_ap"] = 0,      
        ["key_aw"] = 0,
        ["key_sw"] = 0,
        ["key_baim"] = 0,
	},
    CvarManager = {
        ["chosen"] = "sv_cheats",
        ["setto"] = 1,
    },
    Player   = {
        ["name_stealer"] = false,
    },
    SpoofedCvars = {},
    gunSkins = {},
}
cfg["friends"] = {}

local scrw, scrh = ScrW(), ScrH()
local tperson, tperson_cd = false, false
local files, dir = file.Find( "Ilysha/*.json", "DATA" )

local IlyshaFrameTable = {}

IlyshaFrameTable.main_frame = false
IlyshaFrameTable["main_frame_x"] = 145
IlyshaFrameTable["main_frame_y"] = 145

IlyshaFrameTable.color_frame = false

IlyshaFrameTable.Saved = "aim"
IlyshaFrameTable.Expands = {}
IlyshaFrameTable.Expands["camera"] = false

IlyshaFrameTable.Expands = {}
IlyshaFrameTable.Expands["camera"] = false
IlyshaFrameTable.Expands["hitmarker"] = false
IlyshaFrameTable.Expands["bullettrace"] = false
IlyshaFrameTable.Expands["bullettrace_e"] = false
IlyshaFrameTable.Expands["visual_self"] = false
IlyshaFrameTable.Expands["aimbottarget"] = false
IlyshaFrameTable.Expands["aimbotfilter"] = false
IlyshaFrameTable.Expands["airstrafe"] = false
IlyshaFrameTable.Expands["player_box"] = false
IlyshaFrameTable.Expands["esp_elements"] = false
IlyshaFrameTable.Expands["esp_elements_bars"] = false
IlyshaFrameTable.Expands["chams"] = false
IlyshaFrameTable.Expands["aw"] = false
IlyshaFrameTable.Expands["flaa"] = false
IlyshaFrameTable.Expands["aa"] = false
IlyshaFrameTable.Expands["aaaa"] = false
IlyshaFrameTable.Expands["chat"] = false
IlyshaFrameTable.Expands["visual_selfaa"] = false
IlyshaFrameTable.Expands["oofarrows"] = false
IlyshaFrameTable.Expands["world"] = false
IlyshaFrameTable.Expands["world1"] = false
IlyshaFrameTable.Expands["ap"] = false
IlyshaFrameTable.Expands["exploits"] = false
IlyshaFrameTable.Expands["crosshair"] = false
IlyshaFrameTable.Expands[""] = false
IlyshaFrameTable.Expands[""] = false
IlyshaFrameTable.Expands[""] = false

local chatSpam = {
    spam = {
        [1] = {
            "悗f篝嚠篩i縒縡齢",
            "盥皋袍i耘蚌紕偸",
            "輯駲f迯瓲i軌帶",
            "殪幢緻Iii爰曷樔黎㌢",
            "艇艀裲f睚鳫巓襴骸",
            "殪幢緻I翰儂樔黎夢",
            "IceHake -",
            ".*˚˚.✦.*˚.˚.*.✦˚.˚..*✦˚..*˚.*",
            "砂糖少女は愛を食む",
            "子なし                                              ？",
        },
        [2] = {
            "Купи IlyaWare и разьеби всех!",
            "Хочется посрать но не можеш? Купи IlyaWare!СЕЙЧАС ЖЕ БЛЯТЬ!",
            "Лучший IlyaWare это IlyaWare!КУПИ БЛЯТЬ!",
            "Еще не купил IlyaWare?Чего ждеш?ТВАРЬ КУПИ БЛЯДИНА!",
            "Кто прочитал тот гей!Купи IlyaWare и будеш не гей!",
            "Что то застряло у тебя в попке кажется это мой IlyaWare!",
            "Удаляй свой кал и качай IlyaWare !",
            "IlyaWare лучшее решение!Хватит жить в коробке от обуви!",
        },
        [3] = {
            "هل مؤخرتك تحصل مارس الجنس مرة أخرى?تحميل الجد القضيب",
            "سقط الحور الرجراج....",
            "أنا مستعد لقطع الأطفال جميعا هنا!",
            "لقد زرعت قنبلة في مدرستك أمس!",
            "سكين بلدي على استعداد لقطع رأسك!",
            "سأمزقك أيها المغفل القذر",
            "إذا كنا في المنطقة ، وأود أن يكون لك بوم بوم بوم",
            "السائبة ليخ توبشيك",
            "وقد أصدرت المحكمة حكما! سيتم مصادرة قضيبك!",
            "أوتكيساي بودوسينوفيك",
            "إيي المتسول ليس ضرطة",
            "أنا قاتل لطفلين! على ركبتيك أيها الأوغاد",
            "كنت مهرج الذهاب إلى السيرك",
            "أنا داست فمك اللعين الأغنام",
            "وأنت تسير أن يموت قريبا (انها ليست تهديدا إذا كان أي شيء)",
            "أنا سحقت لك كاماز",
            "عندما تم إنشاء هذا الغش ، بكى إبليس",
            "بارد خيانة الدولة الآن وأنت تسير على الجلوس ل 100 سنوات?)",
            "الذهاب لمس العشب المعرفة",
            "الذهاب أنبوب ابن",
            "جدي القضيب حريصة على القتال",
            "أنت محتجز)",
            "من يقرأ هو مثلي الجنس",
        },
        [4] = {
            "Ben burada kral ve tanrıyım! köleler dizlerinin üstüne çök",
            "Kim eşcinsel değil duş alsın",
            "Sikimi ağzına koydum",
            "Sana bir şişeyle tecavüz ettim",
            "Ben senin duvarındayım",
            "Arkana dönüp arkana dönüyorum",
            "BEN 140 TECAVÜZE UĞRADIM VE SEN NE YAPTIN?",
            "Dizlerinden kalk ve yaşamak istiyorsan büyükbabanın IlyaWareini al!",
            "Ne kadar acınası olduğunuzu görünce komik buldum!Diz çökün millet! Gözlerini aç!Büyükbabanın IlyaWareini al",
        },
        [5] = {
            "p̵͕͑ě̶̥n̸̙̈ȋ̶̝s̶̪̅",
            "d̴̞̂ē̵̦d̵̟̊a̶͍̽",
            "b̶̲́a̴̳͊ṉ̸̐ḑ̶̆é̴͜r̴̫̐a̷̞͐",
            "i̶̘̕l̶̙̓n̵̗̋a̴͓̿ẓ̷͘ ̶͇̀b̶̞̍o̶͉͗ǧ̷͓",
            "ị̷͊m̵̢̏ ̴̜͗g̸͆͜a̸̰̓y̸̺͘",
            "c̴̡̝̙̞̱͉̊́̊̓͒̈́̉͋̃͗̒͐o̷̯̣̯̦̦͙͖̬͈̻͙̓̇͂̍̂̑́͐͗͛͒͗͋͗̾͘c̴̡̺̻̹̖̠̦͇̣̯̞̻̄̈́̇͝ͅk̴̡̢̨̨͉̬̘̜̞͙̟̱̺͓͛̇͋̂̈́̓̒̉́͛͌͜͠͠͝͝͝͠",
            "g̵͚̑ā̵͓ÿ̸̟́ ̸̖̂c̵̫͛ŏ̸̻c̶̖̐k̵͕̂",
            "п̸̭͝у̸͇͝т̶̥̃и̴̱͗н̵̢͌ ̷̺̅б̷̛̰ӧ̷͇г̸̯̍",
            "я̶͙̫͍͕̗̥͛̏́ ̸̯̗͍̫̥̇п̶̟͕̹̹͌͂̈́̚͘о̴͚͇̘͍̎̉̔̔͛с̷̮̙͂̀р̶̩̱̔̓͑̈́̑а̶̺́̆̆͐͆͘л̸̧͇̟͑̚",
        },
        [6] = {
            "buy 4 6r4ndf47h3r'5 p3n15 4nd fuck 3v3ry0n3!",
            "4ll y0u n33d 15 6r4ndp4'5 p3n15!7ru57 m3",
            "buy 4 6r4ndf47h3r'5 p3n15 4nd y0u c4n l1v3 n07 1n 4 5h03 b0x",
            "6r4ndf47h3r'5 p3n15 15 7h3 b357 50lu710n",
            "w0uld y0u ch0053 70 b3 r4p3d 1n pr150n 0r buy 6r4ndf47h3r'5 p3n15?",
            "Do you have a small IlyaWare?It doesn't matter!Buy a grandfather's IlyaWare",
            "d0 y0u h4v3 4 5m4ll p3n15?17 d035n'7 m4773r!buy 4 6r4ndf47h3r'5 p3n15",
            "1 w4n7 70 5l33p bu7 c4n'7 637 up fr0m 7h3 74bl3?7h3r3 15 4 50lu710n - 6r4ndf47h3r'5 p3n15!",
            "71r3d 0f dy1n6 fr0m 6r4ndf47h3r'5 p3n15?buy 6r4ndf47h3r'5 p3n15 4nd k1ll 3v3ry0n3!",
        },    
    },
    ar = {
        [1] = {
            "shut up dog",
            "everyone really doesn't care",
            "shut up already",
        },
        [2] = {
            "Всем похуй чел алооооо",
            "Всем похуй",
            "Как же всем похуй",
            "Не пиши",
            "Боже изичка не пиши забеала",
            "Всем похуй чел алооооо",
            "Пук раскажеш в садеке",
        },
        [3] = {
            "الجميع لا يهتم بما تكتبه",
            "إنهاء اللعبة بالفعل",
            "اخرس بالفعل",
        },
        [4] = {
            "herkes buraya yazdığın şeyi umursamıyor",
            "zaten oyundan çıkın",
            "bunu yazmayı bırak zaten",
        },
        [5] = {
            "s̴̛͓̈́h̵̭̉u̴̻̱͆t̴̹̅ ̶̲̉͜ǔ̶͇̭̅p̶͙̻̎",
            "s̵̪͙̒̍h̵͓̰͂̌ú̵̩̪́t̵̲͂͝ ̵̳̒̓ụ̸̼͑p̵̢̗̏ ̷͎̌d̵̪͇̐o̶̮͖͑͘g̷̪̫̉",
            "d̸̹̓̒ỏ̴͔̕n̷̥̞̊'̸̲͚͒̍t̴̩͕̆ ̶̦̒c̸͚̖̓a̴͒̓͜r̷̲̚̚e̷̝̕",
        },
        [6] = {
            "5hu7 up",
            "5hu7 up d06",
            "d0n7 c4r3",
        },    
    },
    ks = {
        [1] = {
            "ez",
            "1",
            "ez kill",
            "AHAHAHH EZZZZ !!1!!!1",
            "man, every bullet in your head is flying",
            "man is playing with aim",
            "man, you're deb",
            "my mom is in the hospital",
            "ehh",
            "I feel sorry for you",
            "Man, I'm sorry but your mother is still alive",
            "guys, let's help each other, let's???",
            "(((((",
            " hurrah for victory",
            "I'm yours on the grave of a Jew, it's already flooded",
            "shut the mouth of the result of a torn-up prezek",
            "Uzbek",
            "and I'm a girl",
            "skin devkiv",
            "what to do if parvalza prezek??",
            "ahahah",
            "YES, YOU'RE FUCKED UP",
            "YOU'LL BE BANNED FOR A LONG TIME",
            "yes, I'll probably save some money",
            "da bla che c pb",
            "if they have a script they didn't get banned",
            "ahaphap",
            "People in ban letish",
            "my brains are smaller my breasts",
            "don't step on my cravings",
            "guchi cravings",
            "Funny Shrek2014",
            "Fuck omne",
            "tastemaker",
            "sheting",
            "Piss off young!",
            "why is your mom running around the house naked fix it",
            "get ready for school sucker",
            "the fucking shoe flew off",
            "what fell beggars",
             "not an opponent",
            "are you a clown???",
            "I pissed on you (",
            "what did you fly off there?",
            "XD",
            "the fucking fuck fell like - no spread no resolver",
            "levi with hvh (",
            "up to the shoe connection",
            "learn to play the son of a stupid fool", "the son of a creature is lowered",
            "the beggar flew away",
            "fix the beggar",
            "where is your resolver",
            "animal get out of the game or you fall",
            "your tit would be a jerk, a fool",
            "bitch don't be ashamed and showers",
            "the fucking slipper flew away",
            "the son of an abortion fell down as a unit",
            "Here's a soldering iron, solder yourself a fucker",
            "why are you playing here brainless", "go to get ready for school next time",
            "fresh boar",
            "you're on the jump dog woof",
            "tell your mom not to run naked",
            "fuck you beautifully sat down on a bottle)))",
            "Sorry darling, I didn't want to face",
            "sorry that without lubrication)",
            "hello this an ambulance? here's the situation the guy who fell needs an ambulance)",
        },
        [2] = {
            "чел у тебя каждый патрон в голову летит",
            "чел с аимом играет",
            "чел ты деб",
            "моя мама в больнице",
            "эхх",
            "жалко тебя",
            "Чел мне жаль но твоя мать еще жива",
            "ребята давайте друг другу помогать, давайте???",
            "(((((",
            "ураа победа",
            "я твой на могилу жидиньким насрал её аж затапило",
            "пасть захлопни результат порватово презека",
            "узбек",
            "а я девочка",
            "скин девкив",
            "что делать если парвалзя презек??",
            "ахахах",
            "ДА ТЫ ЗАДОЛБАЛ",
            "ТЕБЯ ЗАБАНЯТ НА ДОЛГО",
            "да пожалуй нек сахраню",
            "da bla che c pb",
            "если у них скрипт они не получал бан",
            "ахапхап",
            "Чел в бан летиш",
            "мои мозги меньше моеи груди",
            "не наступи мне на тяги",
            "гучи тяги",
            "Смешной Шрек2014",
            "Хуйв омне",
            "дегустатар",
            "сheting",
            "Откисай молодой!",
            "че твоя мама по дому голая бегает исправляй",
            "в школу собирайся сосунок",
            "ботинок ебаный чо слетел",
            "чё упал нищие",
            "не противник",
            "а ты че клоун???",
            "я обоссал тебя (",
            "ты че там отлетел то?",
            "XD",
            "упал хуета ебаная типа - no spread no resolver",
            "ливай с хвх (",
            "до связи башмак",
            "сынтупой дуры играть учись",
            "опущен сын твари",
            "нищий улетел",
            "пофикси нищ",
            "где же твой резольвер",
            "животное выйди с игры а то падаешь",
            "твой сиська бы вжик вжик дура",
            "сука не позорься и ливни",
            "улетел тапочек ебаный",
            "единицей свалился сын аборта",
            "Вот тебе паяльник , запаяй себе ебальник",
            "зачем ты играешь тут безмозглый", "иди в школу собирайся очередняра",
            "свежий кабанчик",
            "ты на подскоке пёсик гав",
            "скажи маме чтоб голая не бегала",
            "ахуеть ты красиво на бутылку присел)))",
            "Извини дорогая , не хотел на лицо",
            "прости что без смазки)",
            "алло это скорая? тут такая ситуация парню который упал нужна скорая)",
            "ало ты мапу лузаешь , дура очнись",
            "аниме ублюдок про тебя же?)?",
            "але , а противники то где???",
            "ты с цфф зашёл ?",
            "ХУЕПРЫГАЛО УНИЖЕНОЕ КУДА ПОЛЕТЕЛО",
            "ты куда жертва козьего аборта",
            "iq?", "x_x 3",
            "ты то куда лезешь сын фантомного стационарного спец изолированого металлформовочного механизма",
            "а где противник одни боты",
            "Тебе в ротик или на животик ?"
        },
        [3] = {
            "чол у тебе кожен патрон в голову летить",
            "чол з аімом грає",
            "чол ти деб",
            "моя мама в лікарні",
            "ехх",
            "шкода тебе",
            "Чол мені шкода але твоя мати ще жива",
            "хлопці давайте один одному допомагати, давайте???",
            "(((((",
            "ураа перемога",
            "я Твій на могилу жидиньким насрав її аж затапило",
            "паща зачини результат порватово презека",
            "узбек",
            "а я дівчинка",
            "скін девків",
            "що робити якщо парвалзя презек??",
            "ахахах",
            "ТА ТИ ЗАДОВБАВ",
            "ТЕБЕ ЗАБАНЯТЬ НА ДОВГО",
            "та мабуть нек сахраню",
            "da bla che c pb",
            "якщо у них скрипт вони не отримував бан",
            "ахапхап",
            "Чол в бан летиш",
            "мої мізки менше моеі грудей",
            "не наступай мені на тяги",
            "гучі тяги",
            "Смішний Шрек2014",
            "Хуйв омне",
            "дегустатар",
            "сheting",
            "Откісай молодий!",
            "че твоя мама по дому Гола бігає виправляй",
            "в школу збирайся сосунок",
            "черевик йобаний чо злетів",
            "че впав жебраки",
            "не противник",
            "а ти че клоун???",
            "я обоссал тебе (",
            "ти че там відлетів то?",
            "XD",
            "впав хуета ебаная типу-no spread no resolver",
            "Лівай з хвх (",
            "до зв'язку черевик",
            "синтупой дурепи грати вчися",
            "опущений син тварі",
            "жебрак полетів",
            "пофікси нищ",
            "де ж твій резольвер",
            "тварина вийди з гри а то падаєш",
            "твій сиська б вжик вжик дура",
            "сука не ганьбіть і зливи",
            "полетів тапочок йобаний",
            "одиницею звалився син аборту",
            "Ось тобі паяльник, запаяй собі ебальнік",
            "навіщо ти граєш",
            "Іди в школу збирайся очередняра",
            "свіжий кабанчик",
            "ти на підскоку песик гав",
            "скажи мамі щоб Гола не бігала",
            "ахуеть ти красиво на пляшку присів)))",
            "Вибач дорога, не хотів на обличчя",
            "прости що без мастила)",
            "алло це швидка? тут така ситуація хлопцю який впав потрібна швидка)",
            "ало ти мапу лузаєш, дура Прокинься",
            "Аніме ублюдок про тебе ж?)?",
            "але, а противники то де???",
            "ти з цфф зайшов ?",
            "ХУЕПРИГАЛО ПРИНИЖЕНЕ КУДИ ПОЛЕТІЛО",
            "ти куди жертва козячого аборту",
            "iq?", "x_x 3",
            "ти то куди лізеш син фантомного стаціонарного спец ізольованого металлформовочного механізму",
            "а де противник одні боти",
            "Тобі в ротик або на животик ?",
        },
        [4] = {
            "bana benziyo",
            "sen zayıf bir köpeksin",
            "kurşunu al zayıf köpek",
            "her zamankinden daha kolay",
            "sorun değil",
        },
        [5] = {
            "e̸̡̩͇̬̮͖͈͔̻̞̯͓̮͋͛̾̒̇̌̂̌̈́́̇̍̎͛̈́ż̵̧̨̢̰̝͙̤͚͈̫̗͓̓̋̄͒͛̏́̎̈́̕͠ ̴͈̿̾̅1̷̪̭̤͒̎̈́̽̿͂ͅ",
            "e̷̢̝̠̣̯̪̦̙̺̖̐̾͜z̵̩̓̅̋̀̃͗̆͒͒͘̚̕͝͝͝ ̵̡̼̠̗͚̬͚͋̌̿́̽̓̄͐͊̾͊̃͝ḵ̵̡̠͓͚̖̎̿̓͆͠ĭ̷̝̙͙̀̈̾͂́̒̀͊̆͂͊̄̓͆͜l̵̼̯̲̾̀̂͆̑̈͂̂̿̐͋ͅl̴̨̨̛͇̬̺̭̳̪̺̟̗̱̱̠͐̆̕̚̕͝͝",
            "ơ̸̙͉̲̗̩̗̩͓͖͙̳̏̅̂w̵͖̝̩͖̣̜̜̤̽̋̈́̋̀̂n̵͎͚̬̥̻̤̟͔̞̯̔̾͗̔͠ȩ̸̧̢̧̢͔̻̭̪̳̊̌̀̋̐͑̈́̄̎̑͝ͅd̵̞̟̮̮͔̣͆̄̉̑́̾̈́͒",
            "ę̶̝̿̾̋͊͗̔͌͝z̴̲̝͐͒̀̏̓ ̴͉̹̠͚͖͌͒̅̃̇̐̄d̵̛̲͖̂̑͒̔̊̈́̏͘ỏ̴̢̢̡͈̭̮̲̎̑̇̃͌̾̊̔́̕͜ģ̵̪̼͈̻͉̥͉̭͖̼̗̃̐́̋͛͐̕͠",
            "1̵̥̼̈́ ̴̪̦̍n̷̞̋̕ṋ̶̬̓̚ ̶͍͗͜d̸̩̫́o̷̩̓g̸͉̮͌ ̷̮̪͊͊õ̸͉̟̆w̷͕̕͜n̵̦͑e̷̜̞͌d̷̬̚͜͝",
        },
        [6] = {
            "3z k1ll",
            "3z k1ll 3z k1ll 11111",
            "3z 0wn3d",
            "3z d06",
            "3z k1ll d06 0nw3d by p ",
        },    
    },
}

-- Materials
CreateMaterial("textured", "VertexLitGeneric")
CreateMaterial("flat", "UnLitGeneric")
CreateMaterial( "MovingWireframe", "VertexLitGeneric",
{
    ["$basetexture"] = "models/debug/debugwhite",
})
CreateMaterial( "glowcham", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.0 1.0 1.0]",
    ["$selfillumtint"] = "[0 0 0]",
} )
CreateMaterial( "glowcham2", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )
CreateMaterial( "glow_additive", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "1",
    ["$nodecal"] = "1",
    ["$additive"] = "1",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

AddConsoleMessage("IlyshaHack - IlyaWare.waib.cc!",Color(51,255,0))

local garbage
local cfgDropdown 
local loadedCfg = {}
local verifyconfig = cfg

local function CloseMainFrame()
    RememberCursorPosition()
    IlyshaFrameTable["main_frame_x"], IlyshaFrameTable["main_frame_y"] = IlyshaFrameTable.main_frame:GetPos()

    IlyshaFrameTable.main_frame:Remove()
    IlyshaFrameTable.main_frame = false
end

local function DefaultPaint(w,h,name)
    if name == nil then
        draw.RoundedBox(0,0,0,w,h,Color(35,35,35))
        RainbowLine(6,6,w - 12,2,scrw/25,6) 

    else
        draw.RoundedBox(0,0,0,w,h,Color(35,35,35))
        RainbowLine(6,23,w - 13,2,scrw/25,6) 
        draw.SimpleText(name,"MainFont",8,2,color_white)
    end
end

local function VerifyConfig()

    
    for k, v in pairs(verifyconfig) do
		if cfg[k] == nil then
			cfg[k] = verifyconfig[k]
            AddConsoleMessage("cfg table differs from default!",Color(255,87,87))
        end
	end
    

	for k, v in pairs(verifyconfig.Colors) do
		if cfg.Colors[k] == nil then
			cfg.Colors[k] = verifyconfig.Colors[k]
            AddConsoleMessage("color table differs from default!",Color(255,87,87))
		end
	end

	for k, v in pairs(verifyconfig.Aimbot) do
		if cfg.Aimbot[k] == nil then
			cfg.Aimbot[k] = verifyconfig.Aimbot[k]
            AddConsoleMessage("aimbot table differs from default!",Color(255,87,87))
        end
	end

	for k, v in pairs(verifyconfig.Ragebot) do
		if cfg.Ragebot[k] == nil then
			cfg.Ragebot[k] = verifyconfig.Ragebot[k]
            AddConsoleMessage("ragebot table differs from default!",Color(255,87,87))
        end
	end

    for k, v in pairs(verifyconfig.Misc) do
		if cfg.Misc[k] == nil then
			cfg.Misc[k] = verifyconfig.Misc[k]
            AddConsoleMessage("misc table differs from default!",Color(255,87,87))
        end
	end

    for k, v in pairs(verifyconfig.Movement) do
		if cfg.Movement[k] == nil then
			cfg.Movement[k] = verifyconfig.Movement[k]
            AddConsoleMessage("movement table differs from default!",Color(255,87,87))
        end
	end

    for k, v in pairs(verifyconfig.ESP) do
		if cfg.ESP[k] == nil then
			cfg.ESP[k] = verifyconfig.ESP[k]
            AddConsoleMessage("ESP table differs from default!",Color(255,87,87))
        end
	end

	for k, v in pairs(verifyconfig.Keybinds) do
		if cfg.Keybinds[k] == nil then
			cfg.Keybinds[k] = verifyconfig.Keybinds[k]
            AddConsoleMessage("keybind table differs from default!",Color(255,87,87))
		end
	end

    for k, v in pairs(verifyconfig.gunSkins) do
		if cfg.gunSkins[k] == nil then
			cfg.gunSkins[k] = verifyconfig.gunSkins[k]
            AddConsoleMessage("Skins table differs from default!",Color(90,87,255))
		end
	end

end

local function SaveConfig()
	if cfgDropdown:GetSelected() == nil then return end	
	local selected = cfgDropdown:GetSelected()
	local JSONconfig = util.TableToJSON(cfg, true)
	file.Write("Ilysha/"..selected, JSONconfig) 
    AddConsoleMessage("Config saved!",Color(107,255,87))
end

local function LoadConfig()

	if cfgDropdown:GetSelected() == nil then return end

	local selected = cfgDropdown:GetSelected()
	local JSONconfig = file.Read("Ilysha/"..selected, "DATA")
    if JSONconfig == "" then 
        AddConsoleMessage("CONFIG TABLE IS NIL!",Color(255,0,0))
    end
    if JSONconfig == "" then return end
	cfg = util.JSONToTable(JSONconfig)

	VerifyConfig()

	loadedCfg[0] = selected
	for k, v in ipairs(files) do
		if v == selected then
			loadedCfg[1] = k
		end
        --print(v,k)
	end

    --print(loadedCfg[1])

    --PrintTable(selected)

	CloseMainFrame()
	OpenGUI()

    AddConsoleMessage("Config loaded!",Color(87,255,255))
end

local function CreateConfig()

	if cfg["newcfg"] == nil then return end
	
	if file.Exists("Ilysha/"..cfg["newcfg"]..".json", "DATA") then return end

	local JSONconfig = util.TableToJSON(cfg, true)
	file.CreateDir("Ilysha")
	file.Write("Ilysha/"..cfg["newcfg"]..".json", JSONconfig)

	CloseMainFrame()
	OpenGUI()

    AddConsoleMessage("Config created!",Color(93,255,87))
end

local function DeleteConfig()

	if cfgDropdown:GetSelected() == nil then return end
	
	local selected = cfgDropdown:GetSelected()
	file.Delete("Ilysha/"..selected)

	loadedCfg = {}

	CloseMainFrame()
	OpenGUI()

    AddConsoleMessage("Config deleted!",Color(255,87,87))
end

-- Кнопка типо когда на нее нажал чето будет
local function FuncButton(name,pan,func)
    local p = pan:Add("DPanel")
    p:Dock(TOP)
    p:SetTall(50)
    p:DockMargin(5,5,5,0)

    p.Paint = function(Ilysha,krutoi,chuvak)
		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(45,45,45))
    end

    local b = p:Add("DButton")
    b:Dock(FILL)
    b:SetText("")
    b:DockMargin(9,9,9,9)

    b.Paint = function(s,w,h)
        s.m_move = s.m_move or 0
        s.m_color = s.m_color or 0

        if s:IsHovered() then
            s.m_move = math.Approach(s.m_move,2,FrameTime()*150)
            s.m_color = math.Approach(s.m_color,23,FrameTime()*200)
        else
            s.m_move = math.Approach(s.m_move,0,FrameTime()*50)
            s.m_color = math.Approach(s.m_color,0,FrameTime()*100)
        end

        local grey_color = 65+s.m_color
        local text_color = 225+(s.m_color*1.5)

        draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
        draw.SimpleText(name,"MainFont",w/2,h/2,Color(text_color,text_color,text_color),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end

    b.DoClick = function()
        surface.PlaySound("garrysmod/ui_click.wav")
        func()
    end

end

local function AddButtons(name,icon,pan,show,savename)
    surface.SetFont("MainFont")
    local bSizeW, bSizeH = surface.GetTextSize(name)

    local b = vgui.Create("DButton",pan)
    b:Dock(TOP)
    b:SetTall(45)
    b:SetText("")
    b:DockMargin(5,5,5,0)

    b.Paint = function(s,w,h)
        s.m_move = s.m_move or 0
        s.m_color = s.m_color or 0

        if s:IsHovered() then
            s.m_move = math.Approach(s.m_move,2,FrameTime()*150)
            s.m_color = math.Approach(s.m_color,23,FrameTime()*200)
        else
            s.m_move = math.Approach(s.m_move,0,FrameTime()*50)
            s.m_color = math.Approach(s.m_color,0,FrameTime()*100)
        end

        local grey_color = 65+s.m_color
        local text_color = 225+(s.m_color*1.5)

        draw.RoundedBox(0,0,0,w,h,Color(45,45,45))

        draw.SimpleText(name,"Font01",65,h/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        surfaceTexture(5,5,35,35,icon,color_white)
    end

    b.DoClick = function()
        hidePanels()
        IlyshaFrameTable.Saved = savename
        show:Show()
        
        surface.PlaySound("garrysmod/ui_click.wav")
    end

end

local function CreateTextInput(lbl, cfgg, config, chars, par)

	local p = vgui.Create("DPanel",par)
	p:Dock(TOP)
	p:DockMargin(5,5,5,0)
	p:SetTall(50)
	p.Paint = function(Ilysha,krutoi,chuvak)
		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(45,45,45))
	end

	local x, y = p:GetPos()
	local w, h = p:GetSize()
	
	local textInput = p:Add("DTextEntry")
	textInput:Dock(FILL)
	textInput:DockMargin(10,10,10,10)
	textInput:IsMultiline( false )
	textInput:SetMaximumCharCount(chars)
	textInput:SetPlaceholderText(lbl)
	textInput:SetFont( "MainFont" )
    textInput:SetPaintBackground(false)
    textInput:SetTextColor(Color(255,255,2555))

	if cfgg[config] != nil and cfgg[config] != "" then
		textInput:SetValue(cfgg[config])
	end

	textInput.Think = function()
		if textInput:IsEditing() then
			editingText	= true
		else
			editingText = false
		end
		cfgg[config] = textInput:GetValue()
		--print(textInput:GetValue())
	end 

	textInput.OnValueChange = function()
		cfgg[config] = textInput:GetValue()

	end
end

local function Button(name,ccfg,config,panel,colorable,bindable,bindkey)
	local p = panel:Add("DPanel")
	p:Dock(TOP)
	p:SetTall(35)
	p:DockMargin(5,5,5,0)

	p.Paint = function(Ilysha, krutoi, chuvak)
		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(45,45,45))
		draw.SimpleText(name,"MainFont",35,chuvak/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	end

	local c = p:Add("DCheckBox")
	c:Dock(LEFT)
	c:DockMargin(10,10,10,10)
	c:SetWide(15)
	c:SetValue( ccfg[config] )
	function c:OnChange( bVal )
		ccfg[config] = bVal
		surface.PlaySound("garrysmod/ui_click.wav")
	end

	c.Paint = function(Ilysha, krutoi, chuvak)
		Ilysha.move_alpha = Ilysha.move_alpha or 0
        Ilysha.checked = Ilysha.checked or 0

		if Ilysha:IsHovered() then
			Ilysha.move_alpha = math.Approach(Ilysha.move_alpha,128,FrameTime()*300)
		else
			Ilysha.move_alpha = math.Approach(Ilysha.move_alpha,55,FrameTime()*150)
		end

		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(35,35,35))
		if c:GetChecked() then
            Ilysha.checked = math.Approach(Ilysha.checked,255,FrameTime()*350)
        else
            Ilysha.checked = math.Approach(Ilysha.checked,0,FrameTime()*350)
		end
        draw.RoundedBox(0,0,0,krutoi,chuvak,Color(157,255,0,Ilysha.checked))
		surfaceTexture(0,0,krutoi,chuvak,"gui/gradient_up",Color(99,99,99,Ilysha.move_alpha))
		surfaceOutline(0,0,krutoi,chuvak,1,color_black)			
	end

	if colorable then
		local b = p:Add("DButton")
		b:Dock(RIGHT)
		b:DockMargin(10,10,10,10)
		b:SetText("")

		b.Paint = function(s,w,h)
			local mycolor = string.ToColor(cfg.Colors[config])
			s.move_alpha = s.move_alpha or 0

			if s:IsHovered() then
				s.move_alpha = math.Approach(s.move_alpha,128,FrameTime()*300)
			else
				s.move_alpha = math.Approach(s.move_alpha,55,FrameTime()*150)
			end
			
			surfaceTexture(0,0,w,h,"gui/alpha_grid.png",Color(240,240,240,s.move_alpha))
			draw.RoundedBox(0,0,0,w,h,Color(mycolor.r,mycolor.g,mycolor.b,mycolor.a))
			surfaceTexture(0,0,w,h,"gui/gradient_up",Color(mycolor.r-55,mycolor.g-55,mycolor.b-55,mycolor.a))
			surfaceOutline(0,0,w,h,1,color_black)		
		end

		b.DoClick = function()
			local mousex, mousey = input.GetCursorPos()
			if IsValid(IlyshaFrameTable.color_frame) then
				IlyshaFrameTable.color_frame:Remove()
			end
			
			IlyshaFrameTable.color_frame = vgui.Create("DFrame")
			IlyshaFrameTable.color_frame:SetSize(300, 225)
			IlyshaFrameTable.color_frame:SetTitle(" ")
			IlyshaFrameTable.color_frame:ShowCloseButton(false)			
			IlyshaFrameTable.color_frame.Paint = function(self, w, h) 
				DefaultPaint(w,h,name .. " color")
			end

			IlyshaFrameTable.color_frame:SetPos(mousex+45,mousey-45)
			
			local colorWindowCloser = vgui.Create( "DButton", IlyshaFrameTable.color_frame ) 
            colorWindowCloser:SetText( "" )					
            colorWindowCloser:SetPos( 250, 4 )					
            colorWindowCloser:SetSize( 40, 15 )					
            colorWindowCloser.DoClick = function() IlyshaFrameTable.color_frame:Close() end
            colorWindowCloser.Paint = function(s,w,h) 
				draw.SimpleText("Close", "MainFont", w/2, h/2, color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
			end
			IlyshaFrameTable.color_frame:MakePopup()

			local colorSelector = vgui.Create("DColorMixer", IlyshaFrameTable.color_frame)
			colorSelector:Dock(FILL)
			colorSelector:DockPadding(5, 5, 5, 5)
			colorSelector:SetPalette(false)
			colorSelector:SetWangs(false)
			colorSelector:SetColor(string.ToColor(cfg.Colors[config]))
			function colorSelector:ValueChanged(val)
				local r = tostring(val.r)
				local g = tostring(val.g)
				local b = tostring(val.b)
				local a = tostring(val.a)
				local col = r.." "..g.." "..b.." "..a
				cfg.Colors[config] = col
			end
		end

	end

	if bindable then
		local k = vgui.Create("DBinder", p)
		k:SetValue(cfg.Keybinds[bindkey])
		k:Dock(RIGHT)
		k:DockMargin(10,10,10,10)
		k.OnChange = function()
			cfg.Keybinds[bindkey] = k:GetValue()
		end

		--surface.SetFont("MainFont")

		k.OldThink = k.Think

		function k:Think()
			
			k:SetText("")
			--[[]
			if k:GetValue() != 0 then		
				k:SizeTo(surface.GetTextSize(language.GetPhrase( input.GetKeyName( k:GetValue() ) ))+10,k:GetTall(),0.4,0,1,function() end)
				print(surface.GetTextSize(language.GetPhrase( input.GetKeyName( k:GetValue() ) ))+10)
			else	
				k:SizeTo(surface.GetTextSize("[]")+10,k:GetTall(),0.4,0,1,function() end)
			end]]
			
			self:OldThink()
		end

		k:SetWide(95)

		k.Paint = function(sosok,pizdenka,mne12)
			sosok.move = sosok.move or 0
			if sosok:IsHovered() then
				sosok.move = math.Approach(sosok.move,25,FrameTime()*300)
			else
				sosok.move = math.Approach(sosok.move,0,FrameTime()*150)
			end

			draw.RoundedBox(0,0,0,pizdenka,mne12,Color(25+sosok.move,25+sosok.move,25+sosok.move))
			surfaceOutline(0,0,pizdenka,mne12,1,color_black)	
			if k:GetValue() != 0 then	
				draw.SimpleText(language.GetPhrase( input.GetKeyName( k:GetValue() ) ),"MainFont",pizdenka/2,mne12/2,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
			else
				draw.SimpleText("[]","KeybinderFont",pizdenka/2,mne12/2,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
			end
		end
	end
end

local function FunctionDropDown(name, pan, dpl, saveexpand)
    local dc = vgui.Create( "DCollapsibleCategory", pan )
    if IlyshaFrameTable.Expands[saveexpand] != nil then
        dc:SetExpanded( IlyshaFrameTable.Expands[saveexpand] )
    end	
    dc:SetLabel( "" )	
    dc:SetHeaderHeight( 35 )			
    dc:Dock(TOP)
	dc:DockMargin(5,5,5,0)

    dc.OnToggle = function()
        IlyshaFrameTable.Expands[saveexpand] = dc:GetExpanded()
    end

    dc.Paint = function(s,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(45,45,45))

		draw.SimpleText(name,"MainFont",10,s:GetHeaderHeight()/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)

        if s:GetExpanded() then
            draw.SimpleText("▼","MainFont",w-25,s:GetHeaderHeight()/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        else
            draw.SimpleText("►","MainFont",w-25,s:GetHeaderHeight()/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        end
    end
    
    dc:SetContents( dpl )	
end

local function DropDown(lbl, choices, cfgg, config, par)

	local p = vgui.Create("DPanel",par)
	p:Dock(TOP)
	p:DockMargin(5,5,5,5)
	p:SetTall(50)
	p.Paint = function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
		draw.SimpleText(lbl,"MainFont",10,h/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	end

	local dropdown = p:Add("DComboBox")
	--dropdown:SetSize(200, 30)
	dropdown:Dock(RIGHT)
    dropdown:DockMargin(10,10,10,10)
    dropdown:SetWide(200)
	for k, v in ipairs(choices) do
		dropdown:AddChoice(v)
	end
	dropdown:SetSortItems(false)
	dropdown:ChooseOptionID(cfgg[config])
	function dropdown:OnSelect(index, value, data)
		cfgg[config] = index
	end
	dropdown.Paint = function(self,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))

		draw.SimpleText("▼","MainFont",w-5,h/2,color_white,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
	end
	DMenuOption.Paint = function(self, w, h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
    end
	dropdown.DropButton.Paint = function() end
	dropdown.PerformLayout = function(self)
        self:SetTextColor(Color(255,255,255))
        self:SetFont("MainFont")
    end
end

local function addSkinPanel(name,model,material,weapon,panel)
    
    local skp = panel:Add("DPanel")
    skp:Dock(TOP)
    skp:DockMargin(2,2,2,2)
    skp:SetTall(120)
    skp.Paint = function(s,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(35,35,35))
        --skin info
        draw.SimpleText(name,"MainFont",125,12,color_white)
        draw.SimpleText("Model    " .. model,"MainFont",125,40,color_white)
        draw.SimpleText("Skin    " .. material,"MainFont",125,60,color_white)
        draw.SimpleText("Weapon    " .. weapon,"MainFont",125,80,color_white)
    end

    local skp2 = skp:Add("DPanel")
    skp2:Dock(LEFT)
    skp2:DockMargin(6,6,6,6)
    skp2:SetWide(100)
    skp2.Paint = function(s,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(35,35,35))
        draw.SimpleText(0,0,0,w,h,Color(255,255,255))
    end
    skp2:SetWide(108)

    local m = skp2:Add( "DModelPanel" )
	m:Dock(FILL)
    m:DockMargin(5,5,5,5)
	m:SetModel(model)
    local PrevMins, PrevMaxs = m.Entity:GetRenderBounds()
    m:SetCamPos(PrevMins:Distance(PrevMaxs) * Vector(0.5, 0.5, 0.5))
	m:SetLookAt((PrevMaxs + PrevMins) / 2)

    function m:LayoutEntity(ent) end
    local getskinweapon = cfg.gunSkins[weapon]

	function m:PostDrawModel(ent)	
        render.SetColorModulation(getskinweapon[4]/255,getskinweapon[5]/255,getskinweapon[6]/255)
		render.MaterialOverride(Material(material))
		ent:SetRenderMode(10)
		ent:SetColor(Color(0, 0, 0, 0))
		ent:DrawModel()
        render.SetColorModulation(1,1,1)
        render.MaterialOverride()
	end

    local removeb = skp2:Add("DButton")
    removeb:SetText("")
    removeb:Dock(FILL)
    removeb:DockMargin(5,5,5,5)

    removeb.Paint = function(s,w,h)
        s.Alpha = s.Alpha or 0
        s.Move = s.Move or 0

        if removeb:IsHovered() then
            s.Alpha = math.Approach(s.Alpha,235,FrameTime()*100)  
            s.Move = math.Approach(s.Move,20,FrameTime()*150)  
        else
            s.Alpha = math.Approach(s.Alpha,0,FrameTime()*350)  
            s.Move = math.Approach(s.Move,0,FrameTime()*200)  
        end

        surfaceTexture(0,h-s.Move,w,20,"gui/gradient_up",Color(255,0,0,s.Alpha))
        draw.SimpleText("Remove","MainFont",w/2,h-s.Move,Color(255,255,255,s.Alpha),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
        draw.SimpleText(name,"MainFont",w/2,-19+s.Move,Color(255,255,255,s.Alpha),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
    end

    removeb.DoClick = function()
        cfg.gunSkins[weapon] = nil
        skp:Remove()
    end

    local pp = skp:Add("DPanel")
    pp:Dock(RIGHT)
    pp:SetTall(50)
    pp:SetWide(300)
    pp:DockMargin(6,6,6,6)

    pp.Paint = function(Ilysha,krutoi,chuvak)
		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(45,45,45))
    end

    local colorSelector = pp:Add("DColorMixer")
	colorSelector:Dock(FILL)
	colorSelector:DockPadding(5, 5, 5, 5)
	colorSelector:SetPalette(false)
	colorSelector:SetWangs(false)
	colorSelector:SetColor(Color(getskinweapon[4],getskinweapon[5],getskinweapon[6],getskinweapon[7]))
	function colorSelector:ValueChanged(val)
		getskinweapon[4] = val.r
		getskinweapon[5] = val.g
		getskinweapon[6] = val.b
		getskinweapon[7] = val.a
	end

end

local function skinAdd(pan)
    local p = pan:Add("DPanel")
    p:Dock(TOP)
    p:SetTall(50)
    p:DockMargin(3,3,3,3)

    p.Paint = function(Ilysha,krutoi,chuvak)
		draw.RoundedBox(0,0,0,krutoi,chuvak,Color(45,45,45))
    end

    local b = p:Add("DButton")
    b:Dock(FILL)
    b:SetText("")
    b:DockMargin(9,9,9,9)

    b.Paint = function(s,w,h)
        s.m_move = s.m_move or 0
        s.m_color = s.m_color or 0

        if s:IsHovered() then
            s.m_move = math.Approach(s.m_move,2,FrameTime()*150)
            s.m_color = math.Approach(s.m_color,23,FrameTime()*200)
        else
            s.m_move = math.Approach(s.m_move,0,FrameTime()*50)
            s.m_color = math.Approach(s.m_color,0,FrameTime()*100)
        end

        local grey_color = 65+s.m_color
        local text_color = 225+(s.m_color*1.5)

        draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
        if IsValid(LocalPlayer()) and LocalPlayer():Alive() then
            draw.SimpleText("Add skin for " .. LocalPlayer():GetActiveWeapon():GetPrintName(),"MainFont",w/2,h/2,Color(text_color,text_color,text_color),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        else
            draw.SimpleText("You must be alive or with weapons in your hands!","MainFont",w/2,h/2,Color(text_color,text_color,text_color),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        end

    end

    b.DoClick = function()
        surface.PlaySound("garrysmod/ui_click.wav")
        if IsValid(LocalPlayer()) and LocalPlayer():Alive() then
            cfg.gunSkins[LocalPlayer():GetActiveWeapon():GetClass()] = {
                cfg.Misc["skininput"],
                LocalPlayer():GetActiveWeapon():GetModel(),
                LocalPlayer():GetActiveWeapon():GetPrintName(),
                255,
                255,
                255,
                255,
            }
        end
    end
end


local function CreateSlider(lbl, symbol, ccfg, config, min, max, dec, par)

	local p = vgui.Create("DPanel",par)
	p:Dock(TOP)
	p:DockMargin(5,5,5,0)
	p:SetTall(55)

	local slider = p:Add("DNumSlider")
	slider:Dock(TOP)
	slider:SetHeight(12)
	slider:DockMargin(10,28,10,10)
	slider:SetMin(min)
	slider:SetMax(max)
	slider:SetTooltip(lbl)
	slider:SetDefaultValue(ccfg[config])
	slider:ResetToDefaultValue()
	slider:SetDecimals(dec)

	slider.Label:Hide()
	slider.TextArea:Hide()

	function slider:OnValueChanged()
		ccfg[config] = slider:GetValue()
	end

	p.Paint = function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
		draw.SimpleText(lbl,"MainFont",10,5,color_white)
		draw.SimpleText(math.Round(slider:GetValue()) .. symbol,"MainFont",w-10,5,color_white,TEXT_ALIGN_RIGHT)
	end

	slider.Slider.Paint = function(self,w,h)
		local getwidth = slider.Slider.Knob:GetPos()
		draw.RoundedBox(0,0,0,w,h,Color(15,15,15,128))
		draw.RoundedBox(0,1,1,getwidth-2,h-2,color_white)
		surfaceTexture(0,0,w,h,"gui/gradient_up",Color(0,0,0,128))
	end
	
	slider.Slider.Knob:SetSize(9,12)	
    slider.Slider.Knob.Paint = function(self,w,h)
		draw.RoundedBox(2,0,0,w,h,color_white)
	end
    if !rp then
	    slider.Slider:SetNotches(0)
	    slider.Slider:SetNotchColor(Color(0,0,0,0))
    end
	slider.Scratch:SetVisible(false)
end

local function Spacer(x,pan)
    local p = vgui.Create("DPanel",pan)
    p:Dock(LEFT)
    p:DockMargin(1,1,1,1)
    p:SetWide(x)

    p.Paint = function() end
end
local function TSpacer(y,pan)
    local p = vgui.Create("DPanel",pan)
    p:Dock(TOP)
    p:SetTall(y)

    p.Paint = function() end
end

scriptFiles = file.Find( "IlyaWare/*.lua", "DATA" )
local function RedactorPanel(name,panel)
    local trueName = file.Read( "IlyaWare/" .. name, "DATA" )
    local p = panel:Add("DPanel")
    p:Dock(TOP)
    p:DockMargin(3,3,3,3)
    p:SetTall(45)

    p.Paint = function(s,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(50,50,50))
        draw.RainbowLine(9,2,50)  
        draw.SimpleText(name,"MainFont",8,h/2,color_rainbow,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
    end
       
	local b = p:Add("DButton")
	b:SetText("")
	b:SetWide(85)
	b:Dock(RIGHT)
	b:DockMargin(8,8,8,8)
	b.Paint = function(self,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(50,50,50)) 
		draw.SimpleText("RunString", "MainFont", w/2, h/2, color_rainbow, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	b.DoClick = function()
        local fileRun = RunString(trueName, "IlyaWareRunString", false)
		if fileRun then
			chat.AddText(Color(255, 0, 0), "[IlyaWare] " , fileRun)
		else
			chat.AddText(Color(0, 255, 128), "[IlyaWare] ", color_white, "Script loaded - ", name)
		end
	end
    local b2 = p:Add("DButton")
	b2:SetText("")
	b2:SetWide(85)
	b2:Dock(RIGHT)
	b2:DockMargin(1,8,1,8)
	b2.Paint = function(self,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(50,50,50))
		draw.SimpleText("Unload", "MainFont", w/2, h/2, color_rainbow, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	b2.DoClick = function()
        local fileUnload = RunString([[if unloadScript then return end ]] .. file.Read( "IlyaWare/" .. name, "DATA" ), "IlyaWareRunString", false)
		if fileUnload then
			chat.AddText(Color(255, 0, 0), "[IlyaWare] " , fileUnload)
		else
			chat.AddText(Color(0, 255, 128), "[IlyaWare] ", color_white, "Script unloaded - ", name)
		end
	end
end

function OpenGUI() 

    IlyshaFrameTable.main_frame = vgui.Create("DFrame")
    IlyshaFrameTable.main_frame:SetTitle("")
    IlyshaFrameTable.main_frame:SetDraggable(true)
    IlyshaFrameTable.main_frame:ShowCloseButton(false)
    IlyshaFrameTable.main_frame:SetSize(815,570)
    IlyshaFrameTable.main_frame:SetPos(IlyshaFrameTable["gui/gradient_up"], IlyshaFrameTable["gui/gradient_up"])
    IlyshaFrameTable.main_frame:MakePopup()
    IlyshaFrameTable.main_frame:SetAlpha(0)
    IlyshaFrameTable.main_frame:AlphaTo(189,0.5,0,function()end)

    IlyshaFrameTable.main_frame.Paint = function(s,w,h)
        surface.SetFont("MainFont")
        local IlyaWare2, IlyaTraxer = surface.GetTextSize("Ilysha")


        DefaultPaint(w,h,"IlyaWare | Beta                                                         ︻デ═一 ✛                                                                                    -  ❐  Х")
    end

    local cs = IlyshaFrameTable.main_frame:Add("DPanel")
    cs:Dock(LEFT)
    cs:DockMargin(1,1,0,1)

    cs.Paint = function(s,w,h)
        s.Move = s.Move or 0
        if s:IsHovered() or s:IsChildHovered() then
            s.Move = math.Approach(s.Move,100,FrameTime()*250)
        else
            s.Move = math.Approach(s.Move,0,FrameTime()*450)
        end
        draw.RoundedBoxEx(4,0,0,w,h,Color(40,40,40),true,false,true,false)
    end
    
    local ms = IlyshaFrameTable.main_frame:Add("DPanel")
    ms:Dock(FILL)
    ms:DockMargin(0,1,1,1)
    
    ms.Paint = function(s,w,h)
        draw.RoundedBoxEx(4,0,0,w,h,Color(35,35,35),false,true,false,true)
        if cs.Move > 0 then
            surface.SetDrawColor( 0,0,0,cs.Move )
            surface.SetMaterial(Material("gui/gradient"))
            surface.DrawTexturedRect(0,0,cs.Move/2,h)
        end
    end
    
    function cs:Think()
        self.move_wide = self.move_wide or 0
    
        if self:IsHovered() or self:IsChildHovered() then
            self.move_wide = math.Approach(self.move_wide,150,FrameTime()*350)
        else
            self.move_wide = math.Approach(self.move_wide,0,FrameTime()*400)
        end
    
        cs:SetWide(60 + self.move_wide)
    end

    -- Scroll panels
    local aimpan = vgui.Create("DScrollPanel", ms)
	aimpan:Dock(FILL)
	local aimpanBar = aimpan:GetVBar()
	aimpanBar:SetWide(4)
	function aimpanBar:Paint(w, h) end
	function aimpanBar.btnUp:Paint(w, h) end
	function aimpanBar.btnDown:Paint(w, h) end
	function aimpanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	aimpan.Paint = function() end

	Button("Enable Aimbot",cfg.Aimbot,"aimbot_enable",aimpan)
	Button("Silent Aim",cfg.Aimbot,"aimbot_silent",aimpan)
	Button("Auto Fire",cfg.Aimbot,"aimbot_autofire",aimpan)
	Button("Auto Wallbang",cfg.Aimbot,"aimbot_autowall",aimpan)
	Button("Auto Reload",cfg.Aimbot,"aimbot_autoreload",aimpan)
    Button("Rapid Fire",cfg.Aimbot,"aimbot_rapidfire",aimpan)

    local aimbotdpanel = vgui.Create("DPanelList",aimpan)
    aimbotdpanel:Dock(FILL)
    aimbotdpanel:DockMargin(6,6,6,6)
    aimbotdpanel:EnableHorizontal( false )				
    aimbotdpanel:EnableVerticalScrollbar( true )

    DropDown("Target selection", {"FOV","Distance","Health"},cfg.Aimbot, "aimbot_aim_target", aimbotdpanel)
    
    Button("Head",cfg.Aimbot,"hitbox_head",aimbotdpanel)
    Button("Body",cfg.Aimbot,"hitbox_body",aimbotdpanel)
    Button("Legs",cfg.Aimbot,"hitbox_legs",aimbotdpanel)
    Button("Arms",cfg.Aimbot,"hitbox_arms",aimbotdpanel)

    Button("Always baim",cfg.Aimbot,"aimbot_bodyaim_alwayson",aimbotdpanel,false,true,"key_baim")
    DropDown("Baim condtions", {"Health lower then","None"},cfg.Aimbot, "aimbot_bodyaim_conditions", aimbotdpanel)
    CreateSlider("Baim health", "hp", cfg.Aimbot, "aimbot_bodyaim_hp", 2, 100, 1, aimbotdpanel)

    TSpacer(10,aimbotdpanel)
    FunctionDropDown("Aimbot Target", aimpan, aimbotdpanel,"aimbottarget")

    --Button("Predict Spread",cfg.Aimbot,"aimbot_nospread",aimpan)
	--Button("Recoil control",cfg.Aimbot,"aimbot_norecoil",aimpan)
    --Button("Fix Fakelag",cfg.Aimbot,"aimbot_flfix",aimpan)

    Button("Enable Resolver",cfg.Aimbot,"aimbot_resolver",aimpan)
    CreateSlider("Resolver Step", "°", cfg.Aimbot, "aimbot_resolver_step", 2, 180, 1,aimpan)
    Button("Remember Real Angle",cfg.Aimbot,"aimbot_resolver_rem",aimpan)

    local aimbotfilter = vgui.Create("DPanelList",aimpan)
    aimbotfilter:Dock(FILL)
    aimbotfilter:DockMargin(6,6,6,6)
    aimbotfilter:EnableHorizontal( false )				
    aimbotfilter:EnableVerticalScrollbar( true )

    Button("Ignore teammates",cfg.Aimbot,"aimbot_ignore_team",aimbotfilter)
    Button("Ignore non visible",cfg.Aimbot,"aimbot_ignore_nv",aimbotfilter)
    Button("Ignore friends",cfg.Aimbot,"aimbot_ignore_fr",aimbotfilter)

    TSpacer(10,aimbotfilter)
    FunctionDropDown("Aimbot Filter", aimpan, aimbotfilter,"aimbotfilter")

    Button("Aim snapline",cfg.Aimbot,"aimbot_snapline",aimpan,true)

    local aapan = vgui.Create("DScrollPanel", ms)
	aapan:Dock(FILL)
	local aapanBar = aapan:GetVBar()
	aapanBar:SetWide(4)
	function aapanBar:Paint(w, h) end
	function aapanBar.btnUp:Paint(w, h) end
	function aapanBar.btnDown:Paint(w, h) end
	function aapanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	aapan.Paint = function() end

    local fldpnl = vgui.Create("DPanelList",aapan)
    fldpnl:Dock(FILL)
    fldpnl:DockMargin(6,6,6,6)
    fldpnl:EnableHorizontal( false )				
    fldpnl:EnableVerticalScrollbar( true )

    Button("Enable Fakelag",cfg.Ragebot,"fakelag_enable",fldpnl)
    DropDown("Fakelag type", {"Static","Adaptive"}, cfg.Ragebot, "fakelag_type", fldpnl)
    CreateSlider("Fakelag", "p", cfg.Ragebot, "fakelag_amount", 1, 23, 0, fldpnl)

    TSpacer(10,fldpnl)
    FunctionDropDown("Fake lag's", aapan, fldpnl,"flaa")

    Button("Enable Anti-aim",cfg.Ragebot,"antiaim_enable",aapan)
    DropDown("Yaw Base", {"Viewangles","At targets","Static"}, cfg.Ragebot, "antiaim_yaw_base", aapan)
    DropDown("Real Yaw", {"Forward","Backward","Right","Left","Custom Real","Jitter Real","Spiner","Reverse Spiner","legit forward","Tank"}, cfg.Ragebot, "antiaim_yaw", aapan)
    DropDown("Fake Yaw", {"Forward","Backward","Right","Left","Custom Fake","Jitter Fake","Spiner","Reverse Spiner","Fake legit forward","Tank"}, cfg.Ragebot, "antiaim_fyaw", aapan)
    DropDown("Pitch", {"Viewmodel","Fake jiiter","Fake down","Fake up","Semi-Down","TEST","TEST","TEST","Semi-FakeDown","Semi-FakeUp","Semi-Up"}, cfg.Ragebot, "antiaim_pitch", aapan)



    local aadpnl = vgui.Create("DPanelList",aapan)
    aadpnl:Dock(FILL)
    aadpnl:DockMargin(10,10,10,10)
    aadpnl:EnableHorizontal( true )				
    aadpnl:EnableVerticalScrollbar( false )

    CreateSlider("Jitter Real", "°", cfg.Ragebot, "antiaim_jitterrange", 0, 180, 1, aadpnl)
    CreateSlider("Jitter Fake", "°", cfg.Ragebot, "antiaim_jitterrange_f", 0, 180, 1, aadpnl)
    CreateSlider("Custom Real", "°", cfg.Ragebot, "antiaim_creal", 0, 360, 1, aadpnl)
    CreateSlider("Custom Fake", "°", cfg.Ragebot, "antiaim_cfake", 0, 360, 1, aadpnl)
    CreateSlider("Spin speed", "", cfg.Ragebot, "antiaim_spinspeed", 1, 155, 1, aadpnl)

    TSpacer(10,aadpnl)
    FunctionDropDown("Сustomization Angle", aapan, aadpnl,"aa")

    local aadpnl = vgui.Create("DPanelList",aapan)
    aadpnl:Dock(FILL)
    aadpnl:DockMargin(6,6,6,6)
    aadpnl:EnableHorizontal( false )				
    aadpnl:EnableVerticalScrollbar( true )

    Button("Cnange Real angle on death",cfg.Ragebot,"antiaim_sr",aadpnl)
    Button("Change Real angle on damage",cfg.Ragebot,"antiaim_hr",aadpnl)

    TSpacer(10,aadpnl)
    FunctionDropDown("Death Dmg Angle", aapan, aadpnl,"aaaa")

    Button("Extended Desync",cfg.Ragebot,"antiaim_extenddesync",aapan) 

    Button("Dance spam",cfg.Ragebot,"dance_spam",aapan)
    DropDown("Act", {
        "robot",
        "muscle",
        "laugh",
        "bow",
        "cheer",
        "wave",
        "becon",
        "agree",
        "disagree",
        "forward",
        "group",
        "half",
        "zombie",
        "dance",
        "pers",
        "halt",
        "salute",
    }, cfg.Ragebot, "dance_spam_act", aapan)

    local vispan = vgui.Create("DScrollPanel", ms)
	vispan:Dock(FILL)
	local vispanBar = vispan:GetVBar()
	vispanBar:SetWide(4)
	function vispanBar:Paint(w, h) end
	function vispanBar.btnUp:Paint(w, h) end
	function vispanBar.btnDown:Paint(w, h) end
	function vispanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	vispan.Paint = function() end

    local vdpanellist = vgui.Create("DPanelList",vispan)
    vdpanellist:Dock(FILL)
    vdpanellist:DockMargin(6,6,6,6)
    vdpanellist:EnableHorizontal( false )				
    vdpanellist:EnableVerticalScrollbar( true )

    Button("Enable Bullet tracer",cfg.Misc,"misc_bullettrace_e",vdpanellist,true)
    DropDown("Tracer type", {"Beam","Line"}, cfg.Misc, "misc_bullettrace_type_e", vdpanellist)
    CreateSlider("Trace time", "s", cfg.Misc, "misc_bullettrace_time_e", 1, 10, 1,vdpanellist)
    Button("Blinking tracer",cfg.Misc,"misc_bullettrace_blinking_e",vdpanellist)

    Button("Enable Bullet impact",cfg.Misc,"misc_bulletimpact_e",vdpanellist,true)
    CreateSlider("Bullet impact time", "s", cfg.Misc, "misc_bulletimpact_time_e", 1, 10, 1,vdpanellist)
    Button("Bullet impact glow",cfg.Misc,"misc_bulletimpact_glow_e",vdpanellist)
        
    Button("Target filter",cfg.Misc,"misc_bullettrace_onlyt",vdpanellist)

    TSpacer(10,vdpanellist)
    FunctionDropDown("Enemy bullets", vispan, vdpanellist,"bullettrace_e")

    local vdpanellist2 = vgui.Create("DPanelList",vispan)
    vdpanellist2:Dock(FILL)
    vdpanellist2:DockMargin(6,6,6,6)
    vdpanellist2:EnableHorizontal( false )				
    vdpanellist2:EnableVerticalScrollbar( true )

    Button("Enable Bullet tracer",cfg.Misc,"misc_bullettrace",vdpanellist2,true)
    DropDown("Tracer type", {"Beam","Line"}, cfg.Misc, "misc_bullettrace_type", vdpanellist2)
    CreateSlider("Trace time", "s", cfg.Misc, "misc_bullettrace_time", 1, 10, 1,vdpanellist2)
    Button("Blinking tracer",cfg.Misc,"misc_bullettrace_blinking",vdpanellist2)

    Button("Enable Bullet impact",cfg.Misc,"misc_bulletimpact",vdpanellist2,true)
    CreateSlider("Bullet impact time", "s", cfg.Misc, "misc_bulletimpact_time", 1, 10, 1,vdpanellist2)
    Button("Bullet impact glow",cfg.Misc,"misc_bulletimpact_glow",vdpanellist2)

    Button("Hitmarker",cfg.Misc,"misc_hitmarker",vdpanellist2, true)
    DropDown("Hitmarker pos", {"3D","2D"}, cfg.Misc, "misc_hitmarker_pos", vdpanellist2)

    TSpacer(10,vdpanellist2)
    FunctionDropDown("my bullets", vispan, vdpanellist2,"bullettrace")

    local vdpanellist3 = vgui.Create("DPanelList",vispan)
    vdpanellist3:Dock(FILL)
    vdpanellist3:DockMargin(6,6,6,6)
    vdpanellist3:EnableHorizontal( false )				
    vdpanellist3:EnableVerticalScrollbar( true )

    Button("Indicators",cfg.Misc,"misc_inds",vdpanellist3,true)
    Button("Indicator Gradient",cfg.Misc,"misc_inds_grad",vdpanellist3,true)
    Button("Rainbow Indicator",cfg.Misc,"misc_inds_hsv",vdpanellist3)
    Button("Rainbow Indicator Gradient",cfg.Misc,"misc_inds_hsv_g",vdpanellist3)
    DropDown("Indicator style", {"Default","Textured","Gradient","Rounded"}, cfg.Misc, "misc_inds_s", vdpanellist3)

    TSpacer(10,vdpanellist3)
    FunctionDropDown("Indicator", vispan, vdpanellist3,"visual_self")

    local vdpanellist4 = vgui.Create("DPanelList",vispan)
    vdpanellist4:Dock(FILL)
    vdpanellist4:DockMargin(6,6,6,6)
    vdpanellist4:EnableHorizontal( false )				
    vdpanellist4:EnableVerticalScrollbar( true )

    Button("Fake chams",cfg.Ragebot,"fake_chams",vdpanellist4,true)
    DropDown("Material", {"Flat","Textured", "Shiny","Glass","Wireframe"}, cfg.ESP, "fake_chams_m", vdpanellist4)

    Button("Real chams",cfg.Ragebot,"real_chams",vdpanellist4,true)
    DropDown("Material", {"Flat","Textured", "Shiny","Glass","Wireframe"}, cfg.ESP, "real_chams_m", vdpanellist4)
    Button("Lby Chams",cfg.Ragebot,"real_chams_real",vdpanellist4)

    Button("Fakelag chams",cfg.Ragebot,"fakelag_chams",vdpanellist4,true)
    DropDown("Material", {"Flat","Textured", "Shiny","Glass","Wireframe"}, cfg.ESP, "fakelag_chams_m", vdpanellist4)

    TSpacer(10,vdpanellist4)
    FunctionDropDown("Anti-aim", vispan, vdpanellist4,"visual_selfaa")

    local vdpanellist5 = vgui.Create("DPanelList",vispan)
    vdpanellist5:Dock(FILL)
    vdpanellist5:DockMargin(6,6,6,6)
    vdpanellist5:EnableHorizontal( false )				
    vdpanellist5:EnableVerticalScrollbar( true )

    local worlddpnls = vgui.Create("DPanelList",vdpanellist5)
    worlddpnls:Dock(FILL)
    worlddpnls:DockMargin(6,6,6,6)
    worlddpnls:EnableHorizontal( false )				
    worlddpnls:EnableVerticalScrollbar( true )

    Button("Enable fog",cfg.Misc,"fog_e",worlddpnls,true)
    CreateSlider("Fog start", "u", cfg.Misc, "fog_s", 0, 50000, 1,worlddpnls)  
    CreateSlider("Fog end", "u", cfg.Misc, "fog_end", 0, 50000, 1,worlddpnls)  
    CreateSlider("Fog density", "", cfg.Misc, "fog_d", 0, 1, 1,worlddpnls)  

    TSpacer(10,worlddpnls)
    FunctionDropDown("Fog", vdpanellist5, worlddpnls,"world1") 

    Button("Wall color",cfg.Misc,"wall_color",vdpanellist5,true)
    Button("Prop color",cfg.Misc,"prop_color",vdpanellist5,true)
    Button("Fullbright",cfg.Misc,"fullbright",vispan)

    Button("No sky",cfg.Misc,"sky_b",vdpanellist5)
    Button("No 3d sky",cfg.Misc,"sky_3d",vdpanellist5)
    Button("Sky color",cfg.Misc,"sky_c",vdpanellist5,true)
    Button("Fill sky",cfg.Misc,"sky_f",vdpanellist5,true)

    Button("Skybox changer",cfg.Misc,"sky_ch",vdpanellist5)
    CreateTextInput("Skybox", cfg.Misc, "skyboxname", 128, vdpanellist5)

    TSpacer(10,vdpanellist5)
    FunctionDropDown("World", vispan, vdpanellist5,"world")

    Button("Predict fall",cfg.Misc,"fall_predict",vispan)
    Button("Better scope",cfg.Misc,"csgo_bscope",vispan,true)
    Button("Lines",cfg.Misc,"csgo_bscope_dl",vispan)
    Button("Better scope alt",cfg.Misc,"csgo_bscope_alt",vispan)
    Button("Viewmodel overlay",cfg.Misc,"viewmodel_wireframe",vispan,true)

    local esppan = vgui.Create("DScrollPanel", ms)
	esppan:Dock(FILL)
	local esppanBar = esppan:GetVBar()
	esppanBar:SetWide(4)
	function esppanBar:Paint(w, h) end
	function esppanBar.btnUp:Paint(w, h) end
	function esppanBar.btnDown:Paint(w, h) end
	function esppanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	esppan.Paint = function() end

    local espdpanellist = vgui.Create("DPanelList",esppan)
    espdpanellist:Dock(FILL)
    espdpanellist:DockMargin(6,6,6,6)
    espdpanellist:EnableHorizontal( false )				
    espdpanellist:EnableVerticalScrollbar( true )

    Button("Player Box",cfg.ESP,"esp_box",espdpanellist,true)
    DropDown("Box Style", {"Default","Corners","3D","Outlined"}, cfg.ESP, "esp_box_type", espdpanellist)
    Button("Highlight Friends",cfg.ESP,"esp_box_fr",espdpanellist,true)
    Button("Highlight Targets",cfg.ESP,"esp_box_trg",espdpanellist,true)
    Button("Team Color",cfg.ESP,"esp_box_team",espdpanellist)

    Button("Fill",cfg.ESP,"esp_box_f",espdpanellist,true)
    Button("Gradient fill",cfg.ESP,"esp_box_grad",espdpanellist,true)

    Button("Box Rainbow",cfg.ESP,"esp_box_r",espdpanellist)
    Button("Fill Rainbow",cfg.ESP,"esp_box_f_r",espdpanellist)
    Button("Gradient Rainbow",cfg.ESP,"esp_box_grad_r",espdpanellist)

    TSpacer(10,espdpanellist)
    FunctionDropDown("Player box", esppan, espdpanellist,"player_box")

    local espdpanellist2 = vgui.Create("DPanelList",esppan)
    espdpanellist2:Dock(FILL)
    espdpanellist2:DockMargin(6,6,6,6)
    espdpanellist2:EnableHorizontal( false )				
    espdpanellist2:EnableVerticalScrollbar( true )

    Button("Name",cfg.ESP,"esp_name",espdpanellist2,true)
    Button("Weapon",cfg.ESP,"esp_wep",espdpanellist2,true)
    Button("Health",cfg.ESP,"esp_hp",espdpanellist2,true)
    Button("Armor",cfg.ESP,"esp_ap",espdpanellist2,true)
    --Button("Team",cfg.ESP,"esp_team",espdpanellist2,false)

    TSpacer(10,espdpanellist2)
    FunctionDropDown("ESP Elements", esppan, espdpanellist2,"esp_elements")

    local espdpanellist3 = vgui.Create("DPanelList",esppan)
    espdpanellist3:Dock(FILL)
    espdpanellist3:DockMargin(6,6,6,6)
    espdpanellist3:EnableHorizontal( false )				
    espdpanellist3:EnableVerticalScrollbar( true )
    
    Button("Enable",cfg.ESP,"esp_hp_bar",espdpanellist3,true)
    Button("Auto color",cfg.ESP,"esp_hp_bar_ac",espdpanellist3)
    Button("Gradient",cfg.ESP,"esp_hp_bar_gradient",espdpanellist3,true)

    TSpacer(10,espdpanellist3)
    FunctionDropDown("Healthbar", esppan, espdpanellist3,"esp_elements_bars")

    local espdpanellist4 = vgui.Create("DPanelList",esppan)
    espdpanellist4:Dock(FILL)
    espdpanellist4:DockMargin(6,6,6,6)
    espdpanellist4:EnableHorizontal( false )				
    espdpanellist4:EnableVerticalScrollbar( true )

    Button("Visible Chams",cfg.ESP,"chams_visible",espdpanellist4,true)
    DropDown("Material", {"Flat","Textured", "Shiny","Glass","Wireframe","Glow","Glow (darker)","Glow (additive)"}, cfg.ESP, "chams_visible_mat", espdpanellist4)
    Button("Attachment Chams",cfg.ESP,"chams_visible_att",espdpanellist4)

    Button("Invisible Chams",cfg.ESP,"chams_invisible",espdpanellist4,true)
    DropDown("Material", {"Flat","Textured", "Shiny","Glass","Wireframe","Glow","Glow (darker)","Glow (additive)"}, cfg.ESP, "chams_invisible_mat", espdpanellist4)
    Button("Attachment Chams",cfg.ESP,"chams_invisible_att",espdpanellist4)

    TSpacer(10,espdpanellist4)
    FunctionDropDown("Colored models", esppan, espdpanellist4,"chams")


    Button("Glow ESP",cfg.ESP,"glow_esp",esppan,true)
    Button("Glow Additive",cfg.ESP,"glow_esp_a",esppan)
    Button("Attachment Glow",cfg.ESP,"glow_esp_att",esppan)

    local espdpanellist5 = vgui.Create("DPanelList",esppan)
    espdpanellist5:Dock(FILL)
    espdpanellist5:DockMargin(6,6,6,6)
    espdpanellist5:EnableHorizontal( false )				
    espdpanellist5:EnableVerticalScrollbar( true )

    Button("Enable arrows",cfg.ESP,"oof_arrows",espdpanellist5,true)
    Button("Dormant color",cfg.ESP,"oof_arrows_d",espdpanellist5,true)
    Button("Blinking",cfg.ESP,"oof_arrows_b",espdpanellist5)
    CreateSlider("Blinking speed", "", cfg.ESP, "oof_arrows_bs", 1, 10, 1,espdpanellist5)
    CreateSlider("Arrow size", "", cfg.ESP, "oof_arrows_as", 1, 25, 1,espdpanellist5)
    CreateSlider("Arrow distance", "", cfg.ESP, "oof_arrows_ad", 10, 100, 1,espdpanellist5)

    TSpacer(10,espdpanellist5)
    FunctionDropDown("Ofscreen ESP", esppan, espdpanellist5,"oofarrows")

    local miscpan = vgui.Create("DScrollPanel", ms)
	miscpan:Dock(FILL)
	local miscpanBar = miscpan:GetVBar()
	miscpanBar:SetWide(4)
	function miscpanBar:Paint(w, h) end
	function miscpanBar.btnUp:Paint(w, h) end
	function miscpanBar.btnDown:Paint(w, h) end
	function miscpanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	miscpan.Paint = function() end

    local dpanellist2 = vgui.Create("DPanelList",miscpan)
    dpanellist2:Dock(FILL)
    dpanellist2:DockMargin(6,6,6,6)
    dpanellist2:EnableHorizontal( false )				
    dpanellist2:EnableVerticalScrollbar( true )

    Button("Enable Thirdperson",cfg.Misc,"misc_3rdp",dpanellist2,false,true,"key_tp")
    CreateSlider("Thirdperson distance", "u", cfg.Misc, "misc_3rdp_d", 1, 15, 1,dpanellist2)
    CreateSlider("Thirdperson smoothing", "*ft", cfg.Misc, "misc_3rdp_s", 1, 75, 1,dpanellist2)
    Button("Override FOV",cfg.Misc,"misc_ofov",dpanellist2)
    CreateSlider("FOV", "°", cfg.Misc, "misc_ofov_v", 1, 180, 1,dpanellist2)
    Button("Camera collision",cfg.Misc,"misc_3rdp_coll",dpanellist2)
    
    TSpacer(10,dpanellist2)
    FunctionDropDown("Camera", miscpan, dpanellist2,"camera")

    local dpanellist3 = vgui.Create("DPanelList",miscpan)
    dpanellist3:Dock(FILL)
    dpanellist3:DockMargin(6,6,6,6)
    dpanellist3:EnableHorizontal( false )				
    dpanellist3:EnableVerticalScrollbar( true )

    Button("Hitsound",cfg.Misc,"misc_hitsound",dpanellist3)
    DropDown("Hitsound hook", {"Game Event","Player Damage hook"}, cfg.Misc, "misc_hitsound_method", dpanellist3)
    DropDown("Hitsound sound", {"Metal","Headshot","Eggcrack","Blip","Metal 2","Metal 3","Balloon pop","Stuck","Custom"}, cfg.Misc, "misc_hitsound_sound", dpanellist3)
    Button("Killsound",cfg.Misc,"misc_killsound",dpanellist3)
    DropDown("Hitsound sound", {"Metal","Headshot","Eggcrack","Blip","Metal 2","Metal 3","Balloon pop","Stuck","Custom"}, cfg.Misc, "misc_killsound_sound", dpanellist3)
    Button("Killstreak",cfg.Misc,"misc_killsound_ks",dpanellist3)

    TSpacer(10,dpanellist3)
    FunctionDropDown("Hitsound", miscpan, dpanellist3,"hitmarker")

    local dpanellist4 = vgui.Create("DPanelList",miscpan)
    dpanellist4:Dock(FILL)
    dpanellist4:DockMargin(6,6,6,6)
    dpanellist4:EnableHorizontal( false )				
    dpanellist4:EnableVerticalScrollbar( true )

    Button("Chat spam",cfg.Misc,"misc_chatspam",dpanellist4)
    CreateSlider("Spam timer", "s", cfg.Misc, "misc_chatspam_timer", 0.1, 10, 1,dpanellist4)
    Button("Killsay",cfg.Misc,"misc_killsay",dpanellist4)
    Button("Режим фермера",cfg.Misc,"misc_killsay_o",dpanellist4)
    Button("Auto responder",cfg.Misc,"misc_chatspam_ar",dpanellist4) 

    DropDown("Language", {"English","Русский","Украинский","Роблокс","Ded Insaid","Sex 18+"}, cfg.Misc, "misc_chatspam_lang", dpanellist4)

    TSpacer(10,dpanellist4)
    FunctionDropDown("Chat", miscpan, dpanellist4,"chat")

    Button("Kill taunt",cfg.Ragebot,"dance_spam_kt",miscpan)

    local movepan = vgui.Create("DScrollPanel", ms)
	movepan:Dock(FILL)
	local movepanBar = movepan:GetVBar()
	movepanBar:SetWide(4)
	function movepanBar:Paint(w, h) end
	function movepanBar.btnUp:Paint(w, h) end
	function movepanBar.btnDown:Paint(w, h) end
	function movepanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	movepan.Paint = function() end

    Button("BunnyHop",cfg.Movement,"move_bhop",movepan)

    local dpanellistm1 = vgui.Create("DPanelList",movepan)
    dpanellistm1:Dock(FILL)
    dpanellistm1:DockMargin(6,6,6,6)
    dpanellistm1:EnableHorizontal( false )				
    dpanellistm1:EnableVerticalScrollbar( true )

    Button("Air strafe",cfg.Movement,"move_strafe",dpanellistm1)
    --Button("Multi dir",cfg.Movement,"move_autodir",dpanellistm1)
    Button("Ground strafe",cfg.Movement,"move_gstrafe",dpanellistm1)
    Button("Circle strafe",cfg.Movement,"move_circle_strafe",dpanellistm1,false,true,"key_cstrafe")
    Button("CStrafe speed",cfg.Movement,"move_add_speed",dpanellistm1)
    --Button("CStrafe AWalls",cfg.Movement,"move_awalls",dpanellistm1)

    TSpacer(10,dpanellistm1)
    FunctionDropDown("Autostrafe", movepan, dpanellistm1,"airstrafe")

    local dpanellistm2 = vgui.Create("DPanelList",movepan)
    dpanellistm2:Dock(FILL)
    dpanellistm2:DockMargin(6,6,6,6)
    dpanellistm2:EnableHorizontal( false )				
    dpanellistm2:EnableVerticalScrollbar( true )

    Button("Enable AWalls",cfg.Movement,"move_aw",dpanellistm2,false,true,"key_aw")
    CreateSlider("AWalls Distance", "u", cfg.Movement, "move_aw_len", 1, 350, 1,dpanellistm2)
    CreateSlider("AWalls Force", "", cfg.Movement, "move_aw_speed", 1, 8000, 1,dpanellistm2)

    Button("Boeing Airplane Interface",cfg.Movement,"move_aw_d",dpanellistm2)

    TSpacer(10,dpanellistm2)
    FunctionDropDown("Avoid Walls", movepan, dpanellistm2,"aw")

    Button("Air duck",cfg.Movement,"move_ad",movepan)
    Button("Duck spam",cfg.Movement,"move_ds",movepan)

    Button("Slowwalk",cfg.Movement,"move_sw",movepan,false,true,"key_sw")
    CreateSlider("Slowwalk speed", "", cfg.Movement, "move_sws", 10, 101, 1,movepan)

    Button("Fake duck",cfg.Movement,"move_fd",movepan,false,true,"key_fd")
    DropDown("Fake duck mode", {"Mode up","Mode down"}, cfg.Movement, "move_fd_m", movepan)

    local dpanellistm3 = vgui.Create("DPanelList",movepan)
    dpanellistm3:Dock(FILL)
    dpanellistm3:DockMargin(6,6,6,6)
    dpanellistm3:EnableHorizontal( false )				
    dpanellistm3:EnableVerticalScrollbar( true )

    Button("Autopeak",cfg.Movement,"move_ap",dpanellistm3,true,true,"key_ap")
    Button("Auto reset",cfg.Movement,"move_ap_ar",dpanellistm3)
    DropDown("Autopeak style", {"Circle","Glow"}, cfg.Movement, "move_ap_s", dpanellistm3)
    Button("Speed/",cfg.Movement,"move_ap_sp",dpanellistm3)
    Button("Auto pullback",cfg.Movement,"move_ap_apb",dpanellistm3)
    Button("Animation",cfg.Movement,"move_ap_anim",dpanellistm3)

    TSpacer(10,dpanellistm3)
    FunctionDropDown("Auto peak", movepan, dpanellistm3,"ap")

    local playerpan = vgui.Create("DScrollPanel", ms)
	playerpan:Dock(FILL)
	local playerpanBar = playerpan:GetVBar()
	playerpanBar:SetWide(4)
	function playerpanBar:Paint(w, h) end
	function playerpanBar.btnUp:Paint(w, h) end
	function playerpanBar.btnDown:Paint(w, h) end
	function playerpanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	playerpan.Paint = function() end

    Button("Name changer",cfg.Player,"name_convar",playerpan)
    Button("Name stealer",cfg.Player,"name_stealer",playerpan)

    local skinspan = vgui.Create("DScrollPanel", ms)
	skinspan:Dock(FILL)
	local skinspanBar = skinspan:GetVBar()
	skinspanBar:SetWide(4)
	function skinspanBar:Paint(w, h) end
	function skinspanBar.btnUp:Paint(w, h) end
	function skinspanBar.btnDown:Paint(w, h) end
	function skinspanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	skinspan.Paint = function() end

    CreateTextInput("skin material", cfg.Misc, "skininput", 777, skinspan)
    skinAdd(skinspan)

    for Ilysha,vor in pairs(cfg.gunSkins) do
        --[[]
        cfg.gunSkins[LocalPlayer():GetActiveWeapon():GetClass()] = {
            cfg.Misc["skininput"],
            LocalPlayer():GetActiveWeapon():GetModel(),
            LocalPlayer():GetActiveWeapon():GetPrintName(),
        }
        ]]
        addSkinPanel(vor[3],vor[2],vor[1],Ilysha,skinspan)
    end

    local cfgpan = vgui.Create("DScrollPanel", ms)
	cfgpan:Dock(FILL)
	local cfgpanBar = cfgpan:GetVBar()
	cfgpanBar:SetWide(4)
	function cfgpanBar:Paint(w, h) end
	function cfgpanBar.btnUp:Paint(w, h) end
	function cfgpanBar.btnDown:Paint(w, h) end
	function cfgpanBar.btnGrip:Paint(w, h) draw.RoundedBox(10,0,0,w-2,h,color_white) end
	cfgpan.Paint = function() end

    files, dir = file.Find( "Ilysha/*.json", "DATA" )

    local p = vgui.Create("DPanel",cfgpan)
	p:Dock(TOP)
	p:DockMargin(3,1.5,3,1.5)
	p:SetTall(50)
	p.Paint = function(s,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
		draw.SimpleText("Configs:","MainFont",10,h/2,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
	end

	cfgDropdown = p:Add("DComboBox")
	--dropdown:SetSize(200, 30)
	cfgDropdown:Dock(RIGHT)
    cfgDropdown:DockMargin(10,10,10,10)
    cfgDropdown:SetWide(200)
	if loadedCfg[0] != nil then
		cfgDropdown:ChooseOption(loadedCfg[0], loadedCfg[1])
	end
	for k, v in ipairs(files) do
		cfgDropdown:AddChoice(v)
	end

	cfgDropdown.Paint = function(self,w,h)
		draw.RoundedBox(0,0,0,w,h,Color(45,45,45))
        RainbowLine(6,23,w - 13,2,scrw/25,6)
		draw.SimpleText("⎯","MainFont",w-5,h/2,color_white,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
	end

	cfgDropdown.DropButton.Paint = function() end
	cfgDropdown.PerformLayout = function(self)
        self:SetTextColor(Color(255,255,255))
        self:SetFont("MainFont")
    end

    FuncButton("Create config",cfgpan,CreateConfig)
    FuncButton("Save config",cfgpan,SaveConfig)
    FuncButton("Delete config",cfgpan,DeleteConfig)
    FuncButton("Load config",cfgpan,LoadConfig)

    function hidePanels()
        aimpan:Hide()
        aapan:Hide()
        vispan:Hide()
        esppan:Hide()
        miscpan:Hide()
        movepan:Hide()
        playerpan:Hide()
        skinspan:Hide()
        cfgpan:Hide()
    end

    function preloadPanels()
        if IlyshaFrameTable.Saved == "aim" then
            aimpan:Show()
        elseif IlyshaFrameTable.Saved == "hvh" then
            aapan:Show()
        elseif IlyshaFrameTable.Saved == "vis" then
            vispan:Show()
        elseif IlyshaFrameTable.Saved == "esp" then
            esppan:Show()
        elseif IlyshaFrameTable.Saved == "msc" then
            miscpan:Show()
        elseif IlyshaFrameTable.Saved == "mov" then
            movepan:Show()
        elseif IlyshaFrameTable.Saved == "player" then
            playerpan:Show()
        elseif IlyshaFrameTable.Saved == "sks" then
            skinspan:Show()
        elseif IlyshaFrameTable.Saved == "cfg" then
            cfgpan:Show()
        end
    end

    hidePanels()
    preloadPanels()



    --AddButtons(name,icon,pan,show,savename)
    AddButtons("Aimbot","aim.png",cs,aimpan,"aim")
    AddButtons("HvH","hvh.png",cs,aapan,"hvh")
    AddButtons("Visual","vis.png",cs,vispan,"vis")
    AddButtons("ESP","wh.png",cs,esppan,"esp")
    AddButtons("Misc","misc.png",cs,miscpan,"msc")
    AddButtons("Movement","bhop.png",cs,movepan,"mov")
    AddButtons("Player","player.png",cs,playerpan,"player")
    AddButtons("Skins","skin.png",cs,skinspan,"sks")
    AddButtons("Config","cfg.png",cs,cfgpan,"cfg")

    TSpacer(10,cs)

    local ava = cs:Add( "AvatarImage" )
	ava:Dock(LEFT)
    ava:SetWide(60)
    ava:DockMargin(5,5,5,5)
	ava:SetPlayer( LocalPlayer(), 74 )	

	local avapan = cs:Add( "DPanel" )
	avapan:Dock(FILL)
    avapan:DockMargin(5,5,5,5)
	avapan.Paint = function(self,w,h)
		draw.SimpleText(LocalPlayer():Name(),"MainFont",2,5,color_white)
		draw.SimpleText(os.date( "%H:%M:%S"),"MainFont",2,25,color_white)
	end

end

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////

local badsweps = {
	["gmod_camera"] = true,
	["manhack_welder"] = true,
	["weapon_medkit"] = true,
	["gmod_tool"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["weapon_bugbait"] = true,
}
local bseq = {
	[ACT_VM_RELOAD] = true,
	[ACT_VM_RELOAD_SILENCED] = true,
	[ACT_VM_RELOAD_DEPLOYED] = true,
	[ACT_VM_RELOAD_IDLE] = true,
	[ACT_VM_RELOAD_EMPTY] = true,
	[ACT_VM_RELOADEMPTY] = true,
	[ACT_VM_RELOAD_M203] = true,
	[ACT_VM_RELOAD_INSERT] = true,
	[ACT_VM_RELOAD_INSERT_PULL] = true,
	[ACT_VM_RELOAD_END] = true,
	[ACT_VM_RELOAD_END_EMPTY] = true,
	[ACT_VM_RELOAD_INSERT_EMPTY] = true,
	[ACT_VM_RELOAD2] = true
}
local stime = 0
local target = nil
local targetHealth, targetDistance = math.huge, math.huge
local targetVector = Vector(0,0,0)
local targetAngle = Angle(0,0,0)
local targetFov = 360
local me = LocalPlayer()
local fa = EyeAngles()
local fpos = me:EyePos()

vRealAngles, vFakeAngles = Angle(0,0,0),Angle(0,0,0)

shot = 0
hits = 0

function VisibleCheck(who,where)
    local trace = util.TraceLine({
        mask = MASK_SHOT,
        ignoreworld = false,
        filter = me,
        start = me:EyePos(),
        endpos = where
    })
    return trace.Entity == who
end

local function ValidateTarget(who)
	if !IsValid(who) then return false end

	if who == me then return false end
	if who:IsDormant() then return false end
	if !who:Alive() then return false end
	if who:Team() == TEAM_SPECTATOR then return false end

    if cfg.Aimbot["aimbot_ignore_team"] then
        if who:Team() == me:Team() then return false end
    end
    if cfg.Aimbot["aimbot_ignore_fr"] then
        if table.HasValue(cfg["friends"], who:SteamID()) then
			return false
		end
    end 

	return true
end

local function CanShoot()
	local me = LocalPlayer()
	local weap = me:GetActiveWeapon()

	if !IsValid(weap) then return false end

	local wact = weap:GetSequence()

	if badsweps[weap:GetClass()] then
		return false
	end
    if me:GetMoveType() == MOVETYPE_NOCLIP then
        return false
    end

	return weap:Clip1() != 0 and !bseq[wact] and weap:GetNextPrimaryFire() < stime
end

local function ShootTime()
	if !IsFirstTimePredicted then return end
	stime = CurTime() + engine.TickInterval()
end

local cones = {};
local nullvec = Vector() * -1;

local resolvedGuys = {}

local function AddResolverStep(ent,kuda)
    if resolvedGuys[ent] == nil then
        resolvedGuys[ent] = 1
    else
        if resolvedGuys[ent] > 360/cfg.Aimbot["aimbot_resolver_step"] then
            resolvedGuys[ent] = 1
        else
            if kuda then
                resolvedGuys[ent] = resolvedGuys[ent] + 1
            else
                resolvedGuys[ent] = resolvedGuys[ent] - 1 
            end
        end
    end
end

local function StepResolver(ent,step)
    local entAngle = ent:EyeAngles()
    local angs = ent:GetAngles()

    if resolvedGuys[ent] != nil then
        --ent:SetPoseParameter("aim_yaw", resolvedGuys[ent] * step)
        ent:SetRenderAngles(angs + Angle(0,resolvedGuys[ent] * step,0))
        ent:InvalidateBoneCache()
    end
end

GAMEMODE["EntityFireBullets"] = function(self, p, data)
    --PrintTable(data)
    
    if me:GetShootPos() == data.Src then
        shot = shot + 1
        if target != nil then
            AddResolverStep(target,true)
        end
    end
    
    --abba
	local w = pm.GetActiveWeapon(me);
	local Spread = data.Spread * -1;
	if(!w || !em.IsValid(w) || cones[em.GetClass(w)] == Spread || Spread == nullvec) then return; end
	cones[em.GetClass(w)] = Spread;
	--print(cones[w:GetClass()])
end

local ovoshi = 0
local killstreak = 0
gameevent.Listen("player_hurt")
hook.Add( "player_hurt", "player_hurt_example", function( data )
	local health = data.health
	local priority = SERVER and data.Priority or 5
	local id = data.userid
	local attackerid = data.attacker

	if attackerid == me:UserID() then
		hits = hits + 1
        if target != nil then
            AddResolverStep(target,false)
        end
        if cfg.Misc["misc_hitsound"] and cfg.Misc["misc_hitsound_method"] == 1 then
            if cfg.Misc["misc_hitsound_sound"] == 1 then
                surface.PlaySound("phx/hmetal1.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 2 then
                surface.PlaySound("player/headshot1.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 3 then
                surface.PlaySound("phx/eggcrack.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 4 then
                surface.PlaySound("buttons/blip2.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 5 then
                surface.PlaySound("phx/hmetal2.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 6 then
                surface.PlaySound("phx/hmetal3.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 7 then
                surface.PlaySound("garrysmod/balloon_pop_cute.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 8 then
                surface.PlaySound("common/stuck1.wav")
            elseif cfg.Misc["misc_hitsound_sound"] == 9 then
                surface.PlaySound("custom.wav")
            end
                if cfg.ESP["logs_hurt"] then
                    local attackerply = Player( attackerid )
                    local hitlogc = string.ToColor(cfg.Colors["logs_hurt"])
        
                    local bone = "generic"
        
                    if attackerply:GetEyeTrace().HitBoxBone != nil then
                        bone = hitlog_hitboxes[hurted:GetBoneName(attackerply:GetEyeTrace().HitBoxBone)]
                    end
        
                    table.insert(hitlogs.data, {
                        {
                            "Hit ",
                            hurted:Nick(),
                            " in the ",
                            bone,            
                            " for ",
                            tostring(string.gsub(data.health-hurted:Health(), "-", "")),
                            " damage (",
                            tostring(data.health),
                            " health remaining)",
                        },
                        alpha = 0,
                        alpha1 = 0,
                        time = RealTime(),
                        color = hitlogc,
                    })    
            end
        end
	end
end )
gameevent.Listen("entity_killed")
hook.Add( "entity_killed", "entity_killed_example", function( data ) 
    local victim = Entity(data.entindex_killed)
    local attacker = Entity(data.entindex_attacker)
    
    if attacker == me and attacker != victim and (victim:IsPlayer() or victim:IsBot() and !victim:IsNPC() ) then
        ovoshi = ovoshi + 1
        killstreak = killstreak + 1
        if cfg.Ragebot["dance_spam_kt"] and me:Alive() and !me:IsPlayingTaunt() and CurTime() > nextact then   
            RunConsoleCommand("act", "laugh")
            nextact = CurTime() + 0.3
        end
        if cfg.Misc["misc_killsound"] then
            if cfg.Misc["misc_killsound_sound"] == 1 then
                surface.PlaySound("phx/hmetal1.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 2 then
                surface.PlaySound("player/headshot1.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 3 then
                surface.PlaySound("phx/eggcrack.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 4 then
                surface.PlaySound("buttons/blip2.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 5 then
                surface.PlaySound("phx/hmetal2.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 6 then
                surface.PlaySound("phx/hmetal3.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 7 then
                surface.PlaySound("garrysmod/balloon_pop_cute.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 8 then
                surface.PlaySound("common/stuck1.wav")
            elseif cfg.Misc["misc_killsound_sound"] == 9 then
                surface.PlaySound("custom.wav")
            end
        end
        
        if cfg.Misc["misc_killsay"] then
            local cmsg = chatSpam.ks[cfg.Misc["misc_chatspam_lang"]]
            local fmsg = cmsg[math.random(#cmsg)]
            if cfg.Misc["misc_killsay_o"] then
                if ovoshi <= 1 then
                    RunConsoleCommand("say","Сбор урожая начат!")
                elseif ovoshi > 1 then
                    RunConsoleCommand("say","Сбор урожая продолжается! Собран новый овощ - " .. victim:Nick() .. " !" )
                end
            else
                RunConsoleCommand("say",fmsg)
            end
        end

        if cfg.Misc["misc_killsound_ks"] then
            if killstreak > 0 then
                if killstreak == 4 then
                    surface.PlaySound("oohwhat/multikill.wav")
                elseif killstreak == 6 then
                    surface.PlaySound("oohwhat/ultrakill.wav")
                elseif killstreak == 8 then
                    surface.PlaySound("oohwhat/killingspree.wav")
                elseif killstreak == 10 then
                    surface.PlaySound("oohwhat/holyshit.wav")
                elseif killstreak == 12 then
                    surface.PlaySound("oohwhat/rampage.wav")
                elseif killstreak == 14 then
                    surface.PlaySound("oowhat/monsterkill.wav")
                elseif killstreak == 16 then
                    surface.PlaySound("oohwhat/godlike.wav")
                     elseif killstreak == 18 then
                    surface.PlaySound("oohwhat/tf_domination.wav")
                    
                     elseif killstreak > 18 then
                surface.PlaySound("oohwhat/holyshit.wav")
                end
            end
        end

    end
    
    if attacker != me and me == victim then   

        if cfg.Misc["misc_killsay"] and cfg.Misc["misc_killsay_o"] then
            if ovoshi > 0 then
                RunConsoleCommand("say","Сбор урожая окончен!Собрано овощей : " .. ovoshi .. " !")
            end
        end
        killstreak = 0
        ovoshi = 0
    end
    if me == victim then 
        if cfg.Ragebot["antiaim_sr"] then
            --print(headrot)
            headrot = headrot + 1
            if headrot > 4 then
                headrot = -4
            elseif headrot <= 0 then            
            end
        else
            headrot = 0
        end
    end
end )   

hook.Add("ScalePlayerDamage","hitsnd",function(pl,hit,dmg)
    if cfg.Misc["misc_hitsound"] and cfg.Misc["misc_hitsound_method"] == 2 then
        if cfg.Misc["misc_hitsound_sound"] == 1 then
            surface.PlaySound("phx/hmetal1.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 2 then
            surface.PlaySound("player/headshot1.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 3 then
            surface.PlaySound("phx/eggcrack.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 4 then
            surface.PlaySound("buttons/blip2.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 5 then
            surface.PlaySound("phx/hmetal2.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 6 then
            surface.PlaySound("phx/hmetal3.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 7 then
            surface.PlaySound("garrysmod/balloon_pop_cute.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 8 then
            surface.PlaySound("common/stuck1.wav")
        elseif cfg.Misc["misc_hitsound_sound"] == 9 then
            surface.PlaySound("custom.wav")
        end
    end
end)

local function NoRecoil(ang)
	local w = me:GetActiveWeapon()
	local c = w:GetClass()

	if c:StartWith("m9k_") or c:StartWith("bb_") or c:StartWith("unclen8_") then
		return ang
	else
	    ang = ang - me:GetViewPunchAngles()
    end

    if cfg.Player["legit_spread_recoil"] then
        local rang = ang + ( me:GetViewPunchAngles() - (math.Round(cfg.Player["legit_rcs"]) * (1/100) * me:GetViewPunchAngles()))
        return rang
        end
    
        return ang
    end

local function Bandera(cmd,ang,spread)

	local w = LocalPlayer():GetActiveWeapon()
	local class = w:GetClass()
	if (!w || !w:IsValid() || !cones[w:GetClass()]) then return ang end

	local newangle = ang
	newangle:Normalize()

	return newangle

end

local function FuckMothers(ucmd, ang)
	local w = LocalPlayer():GetActiveWeapon()
	local class = w:GetClass()

	if cones[class] then
		local spread = cones[class]
		return Bandera(ucmd, ang, spread)
	end

	return ang
end
--[[]
if IsValid(me) and me:Alive() and IsValid(me:GetActiveWeapon()) then
    --if me:GetActiveWeapon().Primary.Damage then
        gunbasedamage = 0 -- НАДА ДОДЕЛАТЬ БЛЯТЬ!!!!!!!!!!!
    --end
end
]]

-- Aim hitboxes
local vHitboxes = {
    [1] = { 
        hitHead = "ValveBiped.Bip01_Head1",
        hitNeck = "ValveBiped.Bip01_Neck1",
    },
    [2] = {
        hitSpine4 = "ValveBiped.Bip01_Spine4",
        hitSpine2 = "ValveBiped.Bip01_Spine2",
        hitSpine1 = "ValveBiped.Bip01_Spine1",
        hitSpine = "ValveBiped.Bip01_Spine",
        hitPelvis = "ValveBiped.Bip01_Pelvis",
    },
    [3] = {
        rUpperArm = "ValveBiped.Bip01_R_UpperArm",
        rForeArm = "ValveBiped.Bip01_R_Forearm",
        lUpperArm = "ValveBiped.Bip01_L_UpperArm",
        lForeArm = "ValveBiped.Bip01_R_Forearm",
        rThig = "ValveBiped.Bip01_R_Thigh",
        lThig = "ValveBiped.Bip01_L_Thigh",
    },
    [4] = { 
        rCalf = "ValveBiped.Bip01_R_Calf",
        rFoot = "ValveBiped.Bip01_R_Foot",
        rToe =  "ValveBiped.Bip01_R_Toe0",
        lCalf = "ValveBiped.Bip01_L_Calf",
        lFoot = "ValveBiped.Bip01_L_Foot",
        lToe = "ValveBiped.Bip01_L_Toe0",
    },
}
vVectorDirs = {
    Vector(1,0,0),
    Vector(-1,0,0),
    Vector(0,1,0),
    Vector(0,-1,0),
    Vector(0,0,1),
    Vector(0,0,-1),
}
baiming = false
local function getAimHitbox(v)
    local hitCenter = v:LocalToWorld(v:OBBCenter())
    local headBone, bodyBone, armb, legb, eyes = hitCenter, hitCenter, hitCenter, hitCenter, hitCenter
    baiming = false


    for _,b in pairs(vHitboxes[1]) do
        if cfg.Aimbot["hitbox_head"] then
            if v:LookupBone(b) != nil and VisibleCheck(v,v:GetBonePosition(v:LookupBone(b))) then
                headBone = v:LookupBone(b)
            end
        end
    end
    for _,b in pairs(vHitboxes[2]) do
        if cfg.Aimbot["hitbox_body"] then
            if v:LookupBone(b) != nil and VisibleCheck(v,v:GetBonePosition(v:LookupBone(b))) then
                bodyBone = v:LookupBone(b)
            end
        end
    end
    for _,b in pairs(vHitboxes[3]) do
        if cfg.Aimbot["hitbox_arms"] and VisibleCheck(v,v:GetBonePosition(v:LookupBone(b))) then
            if v:LookupBone(b) != nil then
                armb = v:LookupBone(b)
            end
        end
    end
    for _,b in pairs(vHitboxes[4]) do
        if cfg.Aimbot["hitbox_legs"] then
            if v:LookupBone(b) != nil and VisibleCheck(v,v:GetBonePosition(v:LookupBone(b))) then
                legb = v:LookupBone(b)
            end
        end
    end

    if cfg.Aimbot["aimbot_bodyaim_alwayson"] or input.IsKeyDown(cfg.Keybinds["key_baim"]) or input.IsMouseDown(cfg.Keybinds["key_baim"]) then
        legb = v:LookupBone("ValveBiped.Bip01_Pelvis") 
        armb =  v:LookupBone("ValveBiped.Bip01_Pelvis") 
        headBone = v:LookupBone("ValveBiped.Bip01_Pelvis") 
        baiming = true
    elseif !cfg.Aimbot["aimbot_bodyaim_alwayson"] and cfg.Aimbot["aimbot_bodyaim_conditions"] == 1 and v:Health() <= cfg.Aimbot["aimbot_bodyaim_hp"] then
        legb = v:LookupBone("ValveBiped.Bip01_Pelvis") 
        armb = v:LookupBone("ValveBiped.Bip01_Pelvis") 
        headBone = v:LookupBone("ValveBiped.Bip01_Pelvis") 
        baiming = true
    end

    --local headMP, bodyMP = cfg.Aimbot["hitbox_head_mp_scale"], cfg.Aimbot["hitbox_body_mp_scale"]

    if cfg.Aimbot["hitbox_head"] and v:LookupAttachment("eyes") != nil and VisibleCheck(v,v:GetAttachment(v:LookupAttachment("eyes")).Pos) then
        targetHitbox = v:GetAttachment(v:LookupAttachment("eyes")).Pos 
    elseif headBone != hitCenter and VisibleCheck(v,v:GetBonePosition(headBone)) then
        targetHitbox = v:GetBonePosition(headBone) + Vector(0,0,1)
    elseif bodyBone != hitCenter and VisibleCheck(v,v:GetBonePosition(bodyBone)) then
        targetHitbox = v:GetBonePosition(bodyBone)
    elseif armb != hitCenter and VisibleCheck(v,v:GetBonePosition(armb)) then 
        targetHitbox = v:GetBonePosition(armb)
    elseif legb != hitCenter and VisibleCheck(v,v:GetBonePosition(legb)) then
        targetHitbox = v:GetBonePosition(legb)
    else
        targetHitbox = hitCenter
    end

	return targetHitbox
end

--[[]
local function PredictPos(pos)
	pos = pos + (me:GetVelocity() * engine.TickInterval())
	return(pos)
end
]]

local dists, closest
local function GetClosestAimTarget()
    dists = {};
		
	for k,v in next, player.GetAll() do
        if(!ValidateTarget(v)) then continue; end
        --if (cfg.Aimbot["aimbot_ignore_nv"] and !VisibleCheck(v,AimHitbox(v))) then continue; end
        dists[#dists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
		
	table.sort(dists, function(a, b)
		return(a[1] < b[1]);
	end);
		
	closest = dists[1] && dists[1][2] || nil;
    --print(closest)
    return closest
end

local function GetLowestHealth()
    dists = {};
		
    for k,v in next, player.GetAll() do
        if(!ValidateTarget(v)) then continue; end
        --if (cfg.Aimbot["aimbot_ignore_nv"] and !VisibleCheck(v,AimHitbox(v))) then continue; end
        dists[#dists + 1] = { em.Health(v), v };
    end
    
    table.sort(dists, function(a, b)
        return(a[1] < b[1]);
    end);
    
    closest = dists[1] && dists[1][2] || nil;

    return closest
end

function Smoothing( ang )
	if ( cfg.Player["legit_smooth_amount"] == 0 ) then return ang end
	local speed = RealFrameTime() / ( cfg.Player["legit_smooth_amount"] / 10 )
	local angl = LerpAngle( speed, me:EyeAngles(), ang )
	return Angle( angl.p, angl.y, 0 )
end

local function AimTarget(cmd)

	local newTarget = nil
	local newTargetPos = Vector(0, 0, 0)
	local newTargetAng = Angle(0, 0, 0)
	local newTargetFov = 360

	for k, v in pairs(player.GetAll()) do
		if ValidateTarget(v) then
            local aimVector = getAimHitbox(v)           
            local aimAngle = (aimVector - me:EyePos()):Angle()
            aimAngle:Normalize()         

            if cfg.Aimbot["aimbot_aim_target"] == 1 then
                local aimVector = getAimHitbox(v)           
                local aimAngle = (aimVector - me:EyePos()):Angle()
                aimAngle:Normalize()
                local aimFov = math.abs(math.NormalizeAngle(fa.y - aimAngle.y)) + math.abs(math.NormalizeAngle(fa.p - aimAngle.p))

                if aimFov < newTargetFov then
                    newTarget = v
                    newTargetPos = aimVector
                    newTargetAng = aimAngle
                    newTargetFov = aimFov
                end
            elseif cfg.Aimbot["aimbot_aim_target"] == 2 then
                --if GetClosestAimTarget() == nil then return end
                local aimVector = getAimHitbox(GetClosestAimTarget())           
                local aimAngle = (aimVector - me:EyePos()):Angle()
                aimAngle:Normalize()

                newTarget = GetClosestAimTarget()
                newTargetPos = aimVector
                newTargetAng = aimAngle
            elseif cfg.Aimbot["aimbot_aim_target"] == 3 then
                local aimVector = getAimHitbox(GetLowestHealth())           
                local aimAngle = (aimVector - me:EyePos()):Angle()
                aimAngle:Normalize()
                
                newTarget = GetLowestHealth()
                newTargetPos = aimVector
                newTargetAng = aimAngle       
        end
	end
end

    --aimbot_aim_target

	target = newTarget
	targetVector = newTargetPos
	targetAngle = newTargetAng
	targetFov = newTargetFov
    if cfg.Aimbot["aimbot_enable"] and CanShoot() and ValidateTarget(target) and VisibleCheck(target,targetVector) then 
        bsendpacket = true  
        cmd:AddKey(IN_ATTACK)	    
    end
    --print(target,targetVector,targetAngle,targetFov)
end

if cfg.Player["name_stealer"] then nameChanger() end

local function changename(name)
    ded.NetSetConVar("name",name.." ")

    if changed >= 2 then
        changed = 0
        lastname = name
    else
        changed = changed + 1
    end

    curtime = CurTime() + cooldown
end

function nameChanger() 
    if curtime > CurTime() then return end

    local pltbl = player_GetAll()

    local len = me:Name():len()

    local mname = string.sub(me:Name(),1,len-1)

    local i = math_random(1,#pltbl)

    if not check(pltbl[i],mname,pltbl) then return end

    changename(pltbl[i]:Name())
end

local function SilentAngles(cmd)
	if !fa then fa = cmd:GetViewAngles() end
	fa = fa + Angle(cmd:GetMouseY() * GetConVarNumber("m_yaw"), cmd:GetMouseX() * -GetConVarNumber("m_yaw"), 0)
	fa.p = math.Clamp(fa.p, -89, 89)
	fa.y = math.NormalizeAngle(fa.y)
end

local function MovementFix(cmd, ang)
	local angs = cmd:GetViewAngles()
	local faa = fa
	if ang then
		faa = ang
	end

	local viewang = Angle(0, angs.y, 0)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + (viewang - faa)):Forward() * fix:Length()
	
	if angs.p > 90 or angs.p < -90 then
		fix.x = -fix.x
	end
	
	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
end

local c_sv_noclipspeed = GetConVar("sv_noclipspeed")
local c_sv_specspeed = GetConVar("sv_specspeed")
function MovementFix2(cmd, aWishDir)
    local factor = 1
    if me:GetObserverMode() == OBS_MODE_ROAMING then
        factor = c_sv_specspeed:GetFloat()
    else
        factor = c_sv_noclipspeed:GetFloat()
    end

    if cmd:KeyDown(IN_SPEED) then
        factor = factor * 0.5
    end

    local aRealDir = fa
    aRealDir:Normalize()

    local vRealF = aRealDir:Forward()
    local vRealR = aRealDir:Right()
    vRealF.z = 0
    vRealR.z = 0

    vRealF:Normalize()
    vRealR:Normalize()

    aWishDir:Normalize()

    local vWishF = aWishDir:Forward()
    local vWishR = aWishDir:Right()
    vWishF.z = 0
    vWishR.z = 0

    vWishF:Normalize()
    vWishR:Normalize()

    local forwardmove = cmd:GetForwardMove() * factor
    local sidemove = cmd:GetSideMove() * factor
    local upmove = cmd:GetUpMove() * factor

    local vWishVel = vWishF * forwardmove + vWishR * sidemove
    vWishVel.z = vWishVel.z + upmove

    local a, b, c, d, e, f = vRealF.x, vRealR.x, vRealF.y, vRealR.y, vRealF.z, vRealR.z
    local u, v, w = vWishVel.x, vWishVel.y, vWishVel.z
    local flDivide = (b * c - a * d) * factor

    local x = -(d * u - b * v) / flDivide
    local y = (c * u - a * v) / flDivide
    local z = (a * (f * v - d * w) + b * (c * w - e * v) + u * (d * e - c * f)) / flDivide

    x = math.Clamp(x, -10000, 10000)
    y = math.Clamp(y, -10000, 10000)
    z = math.Clamp(z, -10000, 10000)

    cmd:SetForwardMove(x)
    cmd:SetSideMove(y)
    cmd:SetUpMove(z)
end

bsendpacket = true

local realYaw, realPitch, fakePitch
local fakeYaw, yawbase
local switchside = true
local yawadd, fyawadd = 0, 0

local function GetClosest()
	local ddists = {};
	
	local closest;
		
	for k,v in next, player.GetAll() do
	if(!ValidateTarget(v)) then continue; end
		ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
		
	table.sort(ddists, function(a, b)
		return(a[1] < b[1]);
	end);
		
	closest = ddists[1] && ddists[1][2] || nil;
	
	if(!closest) then return fa.y; end
	
	local pos = em.GetPos(closest);
	
	local pos = vm.Angle(pos - em.EyePos(me));
	
	return( pos.y );
end

local function YawBase()
    if cfg.Ragebot["antiaim_yaw_base"] == 1 then
        yawbase = fa.y
    elseif cfg.Ragebot["antiaim_yaw_base"] == 2 then 
        yawbase = GetClosest()
    elseif cfg.Ragebot["antiaim_yaw_base"] == 3 then 
        yawbase = 0
    end

    return yawbase
end

local function GetAAY()

    if cfg.Ragebot["antiaim_yaw"] == 1 then
        realYaw = YawBase()
    elseif cfg.Ragebot["antiaim_yaw"] == 2 then
        realYaw = YawBase() - 180
    elseif cfg.Ragebot["antiaim_yaw"] == 3 then
        realYaw = YawBase() - 89
    elseif cfg.Ragebot["antiaim_yaw"] == 4 then
        realYaw = YawBase() + 89
    elseif cfg.Ragebot["antiaim_yaw"] == 5 then
        realYaw = YawBase() + cfg.Ragebot["antiaim_creal"]
    elseif cfg.Ragebot["antiaim_yaw"] == 6 then
        realYaw = YawBase() - 180 - math.random(-cfg.Ragebot["antiaim_jitterrange"],cfg.Ragebot["antiaim_jitterrange"])
    elseif cfg.Ragebot["antiaim_yaw"] == 7 then
        realYaw = YawBase() - math.NormalizeAngle(CurTime() * (cfg.Ragebot["antiaim_spinspeed"]*10))
    elseif cfg.Ragebot["antiaim_yaw"] == 8 then
        realYaw = YawBase() + math.NormalizeAngle(CurTime() * (cfg.Ragebot["antiaim_spinspeed"]*10))
    elseif cfg.Ragebot["antiaim_yaw"] == 9 then
        realYaw = YawBase() - 23
    elseif cfg.Ragebot["antiaim_yaw"] == 10 then
        if switchside then
            realYaw = YawBase() - 89 - 30
        else
            realYaw = YawBase() + 89 - 30
        end
    end

    return realYaw
end

local function GetFAPitch()

    if cfg.Ragebot["antiaim_pitch"] == 1 then
        fakePitch = fa.x
    elseif cfg.Ragebot["antiaim_pitch"] == 2 then
        fakePitch = math.random(-89,180)
    elseif cfg.Ragebot["antiaim_pitch"] == 3 then
        fakePitch = -89
    elseif cfg.Ragebot["antiaim_pitch"] == 4 then
        fakePitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 5 then
        fakePitch = math.random(25,50)
    elseif cfg.Ragebot["antiaim_pitch"] == 6 then
        realPitch = math.random(39,-12)
    elseif cfg.Ragebot["antiaim_pitch"] == 7 then
        realPitch = math.random(-0,-89)
    elseif cfg.Ragebot["antiaim_pitch"] == 8 then
        realPitch = math.random(45,89)
    elseif cfg.Ragebot["antiaim_pitch"] == 9 then
        fakePitch = math.random(45,89)
    elseif cfg.Ragebot["antiaim_pitch"] == 10 then
        fakePitch = math.random(39,-12)
    elseif cfg.Ragebot["antiaim_pitch"] == 11 then
        fakePitch = math.random(-0,-89)
    end

    return fakePitch
end

local function GetAAPitch()

    if cfg.Ragebot["antiaim_pitch"] == 1 then
        realPitch = fa.x
    elseif cfg.Ragebot["antiaim_pitch"] == 2 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 3 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 4 then
        realPitch = -89
    elseif cfg.Ragebot["antiaim_pitch"] == 5 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 6 then
        realPitch = -89
    elseif cfg.Ragebot["antiaim_pitch"] == 7 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 8 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 9 then
        realPitch = -89
    elseif cfg.Ragebot["antiaim_pitch"] == 10 then
        realPitch = 89
    elseif cfg.Ragebot["antiaim_pitch"] == 11 then
        realPitch = 89
    end
    return realPitch
    
--[[]
	if switchside then
		realYaw =YawBase() - 89 - 30
	else
		fakeYaw = YawBase() + 89 - 30
	end
	]]

end

local function GetFAAY()
    if cfg.Ragebot["antiaim_fyaw"] == 1 then
        fakeYaw = YawBase()
    elseif cfg.Ragebot["antiaim_fyaw"] == 2 then
        fakeYaw = YawBase() - 180
    elseif cfg.Ragebot["antiaim_fyaw"] == 3 then
        fakeYaw = YawBase() - 89
    elseif cfg.Ragebot["antiaim_fyaw"] == 4 then
        fakeYaw = YawBase() + 89
    elseif cfg.Ragebot["antiaim_fyaw"] == 5 then
        fakeYaw = YawBase() + cfg.Ragebot["antiaim_cfake"]
    elseif cfg.Ragebot["antiaim_fyaw"] == 6 then
        fakeYaw = YawBase() - 180 - math.random(-cfg.Ragebot["antiaim_jitterrange_f"],cfg.Ragebot["antiaim_jitterrange_f"])
    elseif cfg.Ragebot["antiaim_fyaw"] == 7 then
        fakeYaw = YawBase() - math.NormalizeAngle(CurTime() * (cfg.Ragebot["antiaim_spinspeed"]*10))
    elseif cfg.Ragebot["antiaim_fyaw"] == 8 then
        fakeYaw = YawBase() + math.NormalizeAngle(CurTime() * (cfg.Ragebot["antiaim_spinspeed"]*10))
    elseif cfg.Ragebot["antiaim_fyaw"] == 9 then
        fakeYaw = YawBase() - -23
    elseif cfg.Ragebot["antiaim_fyaw"] == 10 then
        fakeYaw = YawBase() - (-realYaw + 30)
    end

    return fakeYaw
end

--[[
"velocity: 200 (fakelag value: 15)
velocity: 400 (fakelag value: 12)
velocity: 650 (fakelag value: 9)
velocity: 800 (fakelag value: 6)"
]]





local adf = 0
local fakeLagTicks = 0
local fakeLagfactor = 0
local function FakeLag(cmd)
    local curvel = me:GetVelocity():Length2D()
    --local maxvel = me:GetMaxSpeed()
    local dst_per_tick = curvel * engine.TickInterval()
    local chokes = math.ceil(23 / dst_per_tick)
	chokes = math.Clamp(chokes, 0, 23)

    if cfg.Ragebot["fakelag_type"] == 1 then
        fakeLagfactor = math.Round(cfg.Ragebot["fakelag_amount"])
    elseif cfg.Ragebot["fakelag_type"] == 2 then
        fakeLagfactor = chokes
    end

    if cfg.Movement["move_fd"] and input.IsKeyDown(cfg.Keybinds["key_fd"]) then 
        fakeLagfactor = 23
    end
     
    if !cfg.Ragebot["fakelag_enable"] then
        bsendpacket = true
    else
        bsendpacket = false
        if fakeLagTicks <= 0 then
            fakeLagTicks = fakeLagfactor
            bsendpacket = true
        else
            fakeLagTicks = fakeLagTicks - 1
        end
    end
    --print(bsendpacket)
end

local headrot = 0
local function Antihit(cmd)
    --[[]
    local adapmax = nh.player["hvh"]["adapmax"]:GetInt()
    local adapspeed = nh.player["hvh"]["adapspeed"]:GetInt()
    if nh.aa_a >= adapmax then
        nh.aa_a = adapmax
        nh.aa_as = false
    elseif -adapmax >= nh.aa_a then
        nh.aa_a = -adapmax
        nh.aa_as = true
    end

    if nh.aa_as then
        nh.aa_a = nh.aa_a + adapspeed
    else
        nh.aa_a = nh.aa_a - adapspeed
    end

    local adapyaw = nh.player["hvh"]["adapyaw"]:GetFloat()
    local aay = (nh.aat and nh.aat != NULL) and (nh.aat:GetAttachment(nh.aat:LookupAttachment("forward") or nh.aat:LookupAttachment("eyes")).Pos - me:GetShootPos()):Angle().y or 0
    if !fakeangles then
        cmd:SetViewAngles(Angle(pitch, aay + adapyaw + nh.aa_a, 0))
    else
        if bSendPacket then
            cmd:SetViewAngles(Angle(pitch, aay + adapyaw, 0))
        else
            cmd:SetViewAngles(Angle(pitch, aay + adapyaw - 92, 0))
        end
    end
    ]]


    switchside = !switchside
    --and !cmd:KeyDown(IN_ATTACK2)
    if cfg.Ragebot["antiaim_enable"] and ( !cmd:KeyDown(IN_ATTACK) and !cmd:KeyDown(IN_USE) ) and me:GetMoveType() != MOVETYPE_NOCLIP then
        if bsendpacket then
            cmd:SetViewAngles(Angle(GetFAPitch(),GetFAAY(),0))
            vFakeAngles = cmd:GetViewAngles()
        else
            cmd:SetViewAngles(Angle(GetAAPitch(),GetAAY()+(headrot*30),0))
            vRealAngles = cmd:GetViewAngles()
        end
    else
        cmd:SetViewAngles(fa)
    end
	
    MovementFix(cmd)
end

local function Aim(cmd)
	if cmd:CommandNumber() == 0 then return end
	if cfg.Aimbot["aimbot_enable"] and CanShoot() and ValidateTarget(target) and VisibleCheck(target,targetVector) then 
		
        local finalAngle = FuckMothers(cmd, NoRecoil(targetAngle))
		cmd:SetViewAngles(finalAngle)
        
        if cfg.Player["legit_smooth"] then
            finalAngle = Smoothing(finalAngle)
        end

        if cfg.Player["legit_fov"] then
            local fov = cfg.Player["legit_fov_val"]
            
            local view = cfg.Player["sa_enable"] and fa or cmd:GetViewAngles()
            local ang = targetAngle - view
            
            ang:Normalize()
            
            ang = msqrt(ang.x * ang.x + ang.y * ang.y)
            
            if ang > fov then
                return
            end
        end

        cmd:SetViewAngles(finalAngle)

        if cfg.Player["legit_fov_draw"] then
            local rad = (mtan(mrad(cfg.Player["legit_fov_val"]) * 0.5) / mtan(realfov)) * scrw
    
            surfaceDrawCircle(scrw * 0.5, scrh * 0.5, rad, string.ToColor(cfg.colors["legit_fov_draw"]))
        end

		MovementFix(cmd)
	else
        Antihit(cmd)
    end
end

local tpsmooth

local function SilentViewAngles(ply, originn, angles, fov, znear, zfar, pos)
	local view = {}

    if cfg.Movement["move_fd"] and input.IsKeyDown(cfg.Keybinds["key_fd"]) or input.IsMouseDown(cfg.Keybinds["key_fd"]) then 
        originn.z = me:GetPos().z + 14 
    end

    tpsmooth = tpsmooth or 0

    if cfg.Misc["misc_3rdp"] and tperson then
        tpsmooth = math.Approach(tpsmooth,cfg.Misc["misc_3rdp_d"]* 10,FrameTime()*math.Round(cfg.Misc["misc_3rdp_s"]*10))
    else
        tpsmooth = math.Approach(tpsmooth,0,FrameTime()*math.Round(cfg.Misc["misc_3rdp_s"]*10))
    end 

    if tpsmooth != 0 then
        if cfg.Misc["misc_3rdp_coll"] then
	        view.origin = util.TraceLine({
                start = originn,
                endpos = originn - ( fa:Forward() * tpsmooth ),
                filter = me,
                    
            }).HitPos
        else
            view.origin = originn - ( fa:Forward() * tpsmooth ) 
        end
        

        if ( cfg.Ragebot["antiaim_enable"] and (cfg.Ragebot["real_chams"] or cfg.Ragebot["fake_chams"]) )  then
            view.drawviewer = false
        else
            view.drawviewer = true
        end
    else  
        view.origin = originn
    end

	view.angles = fa
    if cfg.Misc["misc_ofov"] then
	    view.fov = cfg.Misc["misc_ofov_v"]
    end

	return view

end

local move_right, move_left, move_backwards, move_forward =0,0,0,0
local tx,tx2,ty,ty2 = Color(255,0,0), Color(235,219,0),Color(100,250,0),Color(50,25,250)
hook.Add("PreDrawEffects","Effects",function()
    --[[]
    tracerX = util.QuickTrace(ply:GetPos() + Vector(5, 0, 0), Vector(250, 0, 0))
    tracerY = util.QuickTrace(ply:GetPos() + Vector(0, 5, 0), Vector(0, 250, 0))
    tracerX2 = util.QuickTrace(ply:GetPos() + Vector(-5, 0, 0), Vector(-250, 0, 0))
    tracerY2 = util.QuickTrace(ply:GetPos() + Vector(0, -5, 0), Vector(0, -250, 0))

    cam.Start3D()
        // Tracer X
        render.DrawLine(Vector(ply:GetPos()), tracerX.HitPos, tx) 
        render.DrawWireframeBox(tracerX.HitPos, Angle(0, 0, 0), Vector(-2, -5, -2), Vector(10, 6, 10), tx)

        // -
        render.DrawLine(Vector(ply:GetPos()), tracerX2.HitPos, tx2) 
        render.DrawWireframeBox(tracerX2.HitPos, Angle(0, 0, 0), Vector(-2, -5, -2), Vector(10, 6, 10), tx2)

        // Tracer Y
        render.DrawLine(Vector(ply:GetPos()), tracerY.HitPos, ty) 
        render.DrawWireframeBox(tracerY.HitPos, Angle(0, 0, 0), Vector(-5, -2, -2), Vector(6, 10, 10), ty)

        // -
        render.DrawLine(Vector(ply:GetPos()), tracerY2.HitPos, ty2) 
        render.DrawWireframeBox(tracerY2.HitPos, Angle(0, 0, 0), Vector(-5, -2, -2), Vector(6, 10, 10), ty2)
    cam.End3D()
    ]]

    local ent = me
	
	local mins = Vector(-2, -5, -2)
	local maxs = Vector(10, 6, 10)
	local startpos = ent:GetPos() + Vector(0,0,35)

    local yaw = fa.y

	local dir_left = Angle(0,yaw+90,0):Forward()
    local dir_right = Angle(0,yaw-90,0):Forward()
    local dir_forward = Angle(0,yaw,0):Forward()
    local dir_back = Angle(0,yaw-180,0):Forward()

	local tr_l = util.TraceHull( {
		start = startpos,
		endpos = startpos + dir_left * cfg.Movement["move_aw_len"] ,
		maxs = maxs,
		mins = mins,
		filter = ent
	} )
    local tr_r = util.TraceHull( {
		start = startpos,
		endpos = startpos + dir_right * cfg.Movement["move_aw_len"] ,
		maxs = maxs,
		mins = mins,
		filter = ent
	} )
    local tr_f = util.TraceHull( {
		start = startpos,
		endpos = startpos + dir_forward * cfg.Movement["move_aw_len"] ,
		maxs = maxs,
		mins = mins,
		filter = ent
	} )
    local tr_b = util.TraceHull( {
		start = startpos,
		endpos = startpos + dir_back * cfg.Movement["move_aw_len"] ,
		maxs = maxs,
		mins = mins,
		filter = ent
	} )
	
    local clr = color_white
    if ( tr_l.Hit ) then
        clr = Color( 255, 0, 0 )
        move_left = startpos:Distance(tr_l.HitPos)
    else
        move_left = 0
    end
    local clr2 = color_white
    if ( tr_r.Hit ) then
        clr2 = Color( 255, 0, 0 )
        move_right = startpos:Distance(tr_r.HitPos)
    else
        move_right = 0
    end
    local clr3 = color_white
    if ( tr_f.Hit ) then
        clr3 = Color( 255, 0, 0 )
        move_forward = startpos:Distance(tr_f.HitPos)
    else
        move_forward = 0
    end
    local clr4 = color_white
    if ( tr_b.Hit ) then
        clr4 = Color( 255, 0, 0 )
        move_backwards = startpos:Distance(tr_b.HitPos)
    else
        move_backwards = 0
    end

    if cfg.Movement["move_aw_d"] then
        render.DrawLine( tr_l.HitPos, startpos + dir_left * cfg.Movement["move_aw_len"] , color_white, true )
        render.DrawLine( startpos, tr_l.HitPos, Color( 106, 255, 113), true )

        render.DrawLine( tr_r.HitPos, startpos + dir_right * cfg.Movement["move_aw_len"] , color_white, true )
        render.DrawLine( startpos, tr_r.HitPos, Color( 106, 255, 113 ), true )

        render.DrawLine( tr_f.HitPos, startpos + dir_forward * cfg.Movement["move_aw_len"] , color_white, true )
        render.DrawLine( startpos, tr_f.HitPos, Color( 106, 255, 113 ), true )

        render.DrawLine( tr_b.HitPos, startpos + dir_back * cfg.Movement["move_aw_len"] , color_white, true )
        render.DrawLine( startpos, tr_b.HitPos, Color( 106, 255, 113 ), true )
        
    

        render.DrawWireframeBox( startpos, Angle( 0, 0, 0 ), mins, maxs, Color( 255, 255, 255 ), true )
        render.DrawWireframeBox( tr_l.HitPos, Angle( 0, 0, 0 ), mins, maxs, clr, true )

        render.DrawWireframeBox( startpos, Angle( 0, 0, 0 ), mins, maxs, Color( 255, 255, 255 ), true )
        render.DrawWireframeBox( tr_r.HitPos, Angle( 0, 0, 0 ), mins, maxs, clr2, true )
        
        render.DrawWireframeBox( startpos, Angle( 0, 0, 0 ), mins, maxs, Color( 255, 255, 255 ), true )
        render.DrawWireframeBox( tr_f.HitPos, Angle( 0, 0, 0 ), mins, maxs, clr3, true )

        render.DrawWireframeBox( startpos, Angle( 0, 0, 0 ), mins, maxs, Color( 255, 255, 255 ), true )
        render.DrawWireframeBox( tr_b.HitPos, Angle( 0, 0, 0 ), mins, maxs, clr4, true )
    end

    --print(move_left)
    --print(move_right)
    --print(move_forward)
    --print(move_backwards)
end)

local hl2guns = {
    ["weapon_357"] = true,
    ["weapon_pistol"] = true,
    ["weapon_bugbait"] = true,
    ["weapon_crossbow"] = true,
    ["weapon_crowbar"] = true,
    ["weapon_frag"] = true,
    ["weapon_physcannon"] = true,
    ["weapon_ar2"] = true,
    ["weapon_rpg"] = true,
    ["weapon_slam"] = true,
    ["weapon_shotgun"] = true,
    ["weapon_smg1"] = true,
    ["weapon_stunstick"] = true,
    ["weapon_fists"] = true,
    ["gmod_camera"] = true,
    ["manhack_welder"] = true,
    ["weapon_medkit"] = true,
    ["gmod_tool"] = true,
    ["weapon_physgun"] = true,
}
local side
local GLPTEST = false
local MOVEING = false
local lastpos = me:GetPos()
local ap_alpha = 0

function moveToPos(cmd, pos)
    local world_forward = (pos - me:GetPos())
    local world_forward = (pos - me:GetPos()) fakelagticks = 30 
    local ang_LocalPlayer = fa.y
    local govno = (pos - me:GetPos()):Angle()
    govno.r = 0

    cmd:SetForwardMove(10000)
    cmd:SetSideMove(0)
    if cfg.Movement["move_ap_sp"] then
        cmd:AddKey(IN_SPEED)
    end

    MovementFix2(cmd,Angle(0, govno.y, 0))
end

local function fart(cmd)
    if GLPTEST and cmd:KeyDown(IN_ATTACK) then 
        MOVEING = true
    elseif !GLPTEST and !cmd:KeyDown(IN_ATTACK) then
        MOVEING = false
    end  
end

local function ass(ent)
    local col = string.ToColor(cfg.Colors["move_ap"])
    local pos = GLP
    local offset = Vector(pos)

    cam.Start3D2D(pos, Angle(0,0,0), 0.5 )
        cam.IgnoreZ(true)
        if cfg.Movement["move_ap_s"] == 1 then
            surface.DrawCircle(0,0,ap_alpha/5-5,col.r,col.g,col.b,col.a)
        elseif cfg.Movement["move_ap_s"] == 2 then
            surface.SetDrawColor( col.r,col.g,col.b,ap_alpha ) 
	        surface.SetMaterial( Material("gui/npc.png") )
	        surface.DrawTexturedRect( -ap_alpha/4, -ap_alpha/4, ap_alpha/2, ap_alpha/2 )
        end
        cam.IgnoreZ(false)
    cam.End3D2D()
    
    --print(ap_alpha)
end
hook.Add("Think", "example", function()
    if !cfg.Movement["move_ap"] then return end
    if input.IsKeyDown(cfg.Keybinds["key_ap"]) or input.IsMouseDown(cfg.Keybinds["key_ap"]) then
        if not GLPTEST then
            realPitch = 180
            fakePitch = -180
            GLP = me:GetPos()
            lastpos = me:GetPos()         
        end
        GLPTEST = true
    else
        GLPTEST = false
    end
    if cfg.Movement["move_ap_anim"] then
        if GLPTEST then
            ap_alpha = math.Approach(ap_alpha,255,FrameTime()*750)
        else
            ap_alpha = math.Approach(ap_alpha,0,FrameTime()*750)
        end
    else
        if GLPTEST then
            ap_alpha = 255
        else
            ap_alpha = 0
        end
    end
end)
local function Movement(cmd)
    if !me:Alive() then return end
    local pos = me:GetPos()

    if cfg.Movement["move_ds"] then
		if me:KeyDown(IN_DUCK) then
            cmd:RemoveKey(IN_DUCK)
        end
    end

    
    if cfg.Movement["move_ad"] then
        local trace = util.TraceLine({
            start = pos,
            endpos = pos - Vector(0, 0, 1337),
            mask = MASK_SOLID
        })
        local len = (pos - trace.HitPos).z
        if len > 25 and 50 > len then
            cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
        end
    end

    -- Bunny hop
    if cfg.Movement["move_bhop"] then
        if cmd:KeyDown(IN_JUMP) then
            if !me:OnGround() then
                cmd:RemoveKey(IN_JUMP)
            end
        end
    end

    -- Air strafe
    if cfg.Movement["move_strafe"] then
        if me:GetMoveType() != MOVETYPE_NOCLIP and me:GetMoveType() != MOVETYPE_LADDER then
            if cmd:KeyDown( IN_JUMP ) then

                cmd:SetForwardMove(0)

                if(cmd:GetMouseX() > 1 || cmd:GetMouseX() < - 1) then
                    cmd:SetSideMove(cmd:GetMouseX() > 1 && 10000 || - 10000)
                else
                    cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
                    cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) && -10000 || 10000)
                end

                if(me:IsOnGround()) then
                    if hl2guns[me:GetActiveWeapon():GetClass()] then
                        cmd:AddKey(IN_SPEED)
                    end
                    cmd:SetForwardMove(10000)
                end
                
            end
        end
    end

    -- slowwalk
    if cfg.Movement["move_sw"] then 
        if(input.IsKeyDown(cfg.Keybinds["key_sw"])) then
            if(input.IsKeyDown(KEY_A)) then
                cmd:SetSideMove(-cfg.Movement["move_sws"]) 
            end
            if(input.IsKeyDown(KEY_D)) then
                cmd:SetSideMove(cfg.Movement["move_sws"])
            end
            if(input.IsKeyDown(KEY_W)) then
                cmd:SetForwardMove(cfg.Movement["move_sws"])
            end
            if(input.IsKeyDown(KEY_S)) then
                cmd:SetForwardMove(-cfg.Movement["move_sws"])
            end
        end
    end       

    -- fake duck
    if cfg.Movement["move_fd"] and input.IsKeyDown(cfg.Keybinds["key_fd"]) then
        if(cfg.Movement["move_fd_m"] == 1) then
            if(fakeLagTicks >= 7) then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
            else
                cmd:RemoveKey(IN_DUCK)
            end
        elseif(cfg.Movement["move_fd_m"] == 2) then
            if(bsendpacket) then
                cmd:RemoveKey(IN_DUCK)
            else
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
            end
        end
    end

    -- Avoid walls
    if cfg.Movement["move_aw"] then
        if input.IsKeyDown(cfg.Keybinds["key_aw"]) then
            if move_left != 0 then
                cmd:SetSideMove(cfg.Movement["move_aw_speed"])
            end
            if move_right != 0 then
                cmd:SetSideMove(-cfg.Movement["move_aw_speed"])
            end
            if move_forward != 0 then
                cmd:SetForwardMove(-cfg.Movement["move_aw_speed"])
            end
            if move_backwards != 0 then
                cmd:SetForwardMove(cfg.Movement["move_aw_speed"])
            end
        end
    end

    --Extended dy$ync
    if cfg.Ragebot["antiaim_extenddesync"] then 
        --cmd:SetSideMove(cmd:TickCount() % 2 == 0 and -1.1 or 1.1)
        --print(cmd:TickCount() % 2 == 0 and -1.1 or 1.1)

        if !cmd:KeyDown(IN_BACK) and !cmd:KeyDown(IN_FORWARD) and !cmd:KeyDown(IN_LEFT) and !cmd:KeyDown(IN_RIGHT) then
            cmd:SetSideMove(side and -180 or 180)
            side = !side
        end

    end
end

function IsTickHittable( ply, cmd, tick )
    if ded.GetLatency(0) > 1 then return false end

    local serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
    local diff = serverArriveTick - btrecords[ ply ][ tick ].simulationtime

    if diff > cfg.player["Backtrack time"] / 1000 then return false end

    return true
end

function FindBacktrack( cmd, ply )
    local ticks = #btrecords[ ply ]
    local canhit = {}

    for i = 1, ticks do
        if IsTickHittable( ply, cmd, i ) then
            canhit[ #canhit + 1 ] = i
        end
    end

    return canhit
end

function FindFirstHittableTicks( ply, cmd )
    local tickcount = #btrecords[ ply ]

    if !tickcount then return 1 end

    for i = 1, tickcount do
        if IsTickHittable( ply, cmd, i ) then
            return i
        end
    end
end

do
    local lastdist, lasttick = 1337, 1

    function FindClosestHittableTicks( ply, cmd )
        local mypos = me:EyePos()
        local records = btrecords[ ply ]
        local firstticks = FindFirstHittableTicks( ply, cmd )
        local tickcount = #records

        if !tickcount or !firstticks then return 1 end

        lastdist = math_huge
    
        for i = 1, tickcount - firstticks do
            local mt = i + firstticks

            if ( records[ mt ].aimpos ):DistToSqr( mypos ) < lastdist then
                lastdist = ( records[ mt ].aimpos ):DistToSqr( mypos )
                lasttick = mt
            end
        end

        return lasttick
    end
end

function canBacktrack(ply)
    if not cfg.player["Backtrack"] then return false end 
    if not IsValid(ply) then return false end
    if not btrecords[ply] then return false end 
    if ply.break_lc then return false end 

    return true 
end

function recordBacktrack(ply)
	local deadtime = CurTime() - cfg.player["Backtrack time"] / 1000
	
	local records = btrecords[ply]

	if !records then
        records = {}
		btrecords[ply] = records
	end
	
	local i = 1
	while i < #records do
		local record = records[i]
		
		if record.simulationtime < deadtime then
			table_remove(records, i)
			i = i - 1
		end
		
		i = i + 1
	end
	
	if !ply:Alive() then return end
    if ply.break_lc then return end
	
	local simulationtime = ded.GetSimulationTime(ply:EntIndex())
	local len = #records
	local simtimechanged = true

	if len > 0 then
		simtimechanged = records[len].simulationtime < simulationtime
	end
	
	if !simtimechanged then return end

	local layers = {}
	for i = 0, 13 do
		if ply:IsValidLayer(i) then
			layers[i] = {
				cycle = ply:GetLayerCycle(i),
				sequence = ply:GetLayerSequence(i),
				weight = ply:GetLayerWeight(i)
			}
		end
	end

    local eyeAngles = ply:EyeAngles()
    local x,y = eyeAngles.x, eyeAngles.y

	records[len + 1] = {
		simulationtime = ded.GetSimulationTime(ply:EntIndex()),
		angles = Angle(x,y,0),
		origin = ply:GetNetworkOrigin(),
		aimpos = GetBones( ply )[1],
		sequence = ply:GetSequence(),
		cycle = ply:GetCycle(),
		layers = layers,
        movex = ply:GetPoseParameter("move_x"),
        movey = ply:GetPoseParameter("move_y"),
	}
end

function drawCSModels_backtrack()
    if not cfg.player["Backtrack chams"] then return end 
    if not canBacktrack(target) then return end

    local len = #btrecords[target]
    local tbl = btrecords[target][backtracktick]
    local m = btmodel

    CS_Model_update(target,m,tbl)

    if cfg.player["Backtrack fullbright"] then
        render_SuppressEngineLighting(true)
    end

    local col = string_ToColor(cfg.colors["Backtrack chams"])
    render_MaterialOverride(chamMats.invis[cfg.player["Backtrack material"]]) 
    render_SetColorModulation(col.r/255,col.g/255,col.b/255)
    m:SetRenderMode(1)
    m:DrawModel()

    if cfg.player["Backtrack fullbright"] then
        render_SuppressEngineLighting(false)
    end
end

trailpos = {}
function HUDPaint()
    if cfg.Player["self_trail"] then
		local hsv = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
		surfaceSetDrawColor(hsv.r,hsv.g,hsv.b)
		for i = 1, #trailpos-1 do
			local pos = trailpos[i]:ToScreen()
			local prevpos = trailpos[i+1]:ToScreen()
			surfaceDrawLine(pos.x,pos.y,prevpos.x,prevpos.y)
		end
	end	
	trailpos[#trailpos+1] = LocalPlayer():GetPos()

	if #trailpos > 100 then
		table.remove(trailpos,1)
	end
end

hook.Add("PostDrawOpaqueRenderables", "example", function()
    if LocalPlayer() and ap_alpha > 0 then
        ass(v)
    end
end)

local function CalcViewModelView(wep, vm, oldPos, oldAng, pos, ang)

	if cfg.Aimbot["aimbot_silent"] then
        pos = me:EyePos()
		ang = fa
	end

	return pos, ang
end

local function AutoReload(cmd)
	if !cfg.Aimbot["aimbot_autoreload"] then return end

	local wep = me:GetActiveWeapon()

	if IsValid(wep) then
		if wep.Primary then
			if wep:Clip1() == 0 and wep:GetMaxClip1() > 0 and me:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then
				cmd:AddKey(IN_RELOAD)
			end
		end
	end
end

hook.Add("CreateMove","Aim",function(cmd)
    RunConsoleCommand("cl_interp","0")	
    RunConsoleCommand("cl_interp_ratio","0")	

    garbage = (collectgarbage("count") / 1000)
    --print(garbage)
	SilentAngles(cmd)

	if cmd:CommandNumber() == 0 then return end

    if GLPTEST and MOVEING then
        moveToPos(cmd, GLP)
    end

    if cfg.Movement["move_ap_ar"] then
        if MOVEING then
            if lastpos:Distance(me:GetPos()) < 1 then  
                MOVEING = false
            end
        end
    end

    if cfg.Movement["move_ap_apb"] then
        if GLPTEST and !MOVEING and lastpos:Distance(me:GetPos()) > 1 then
            if !cmd:KeyDown(IN_MOVERIGHT) and !cmd:KeyDown(IN_MOVELEFT) and !cmd:KeyDown(IN_FORWARD) and !cmd:KeyDown(IN_BACK) then
                moveToPos(cmd, GLP)
            end
        end
    end

    --print(GLPTEST,MOVEING,lastpos:Distance(me:GetPos()))

    FakeLag(cmd)

	Movement(cmd)
    CircleStrafe(cmd)   

    ded.StartPrediction(cmd)
        AimTarget(cmd) 
        Aim(cmd)   
    ded.FinishPrediction()
    
    fart(cmd)
    AutoReload(cmd)
    if cfg.Aimbot["aimbot_rapidfire"] then
        if LocalPlayer():Alive() && IsValid(LocalPlayer():GetActiveWeapon()) then
			if LocalPlayer():KeyDown( IN_ATTACK ) then
               cmd:RemoveKey(IN_ATTACK)
            end
		end
    end

    ded.SetBSendPacket(bsendpacket)
end)

hook.Add("CalcView","SilentAngles",SilentViewAngles)
hook.Add("CalcViewModelView", "CalcViewmodel", CalcViewModelView)
hook.Add("Move","Time",ShootTime)

local hitmarkerTable = {}
local hearts = {}
hook.Add("PlayerTraceAttack", "TraceAttack", function (ent, dmg, dir, trace) 
    if(!IsFirstTimePredicted()) then return; end
    local vHitPos, vSrc;
    vHitPos = trace.HitPos;
    vSrc = trace.StartPos;
	table.insert(hitmarkerTable, {vHitPos, 1})
end)

--[[]
local enabled = Menu.Switch('General', 'Enable', false)
local colored = Menu.Switch('General', 'Auto color', false)
local custom_color = Menu.Switch('Customization', 'Custom static color', false)
local custom_color_c = Menu.ColorEdit('Customization', 'Color', Color.new(0, 0, 1, 1))
--1


local function get_color(element, alpha)
    local clr = string.ToColor(cfg.Colors[element])
    return Color( clr.r(), clr.g(), clr.b(), alpha )
end
local function draw_heart(x, y, color)
    local rectangle = draw.RoundedBox

    rectangle(0, x + 2, y + 14, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x, y + 12, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x - 2, y + 10, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x - 4, y + 4, 2, 6, Color( 0, 0, 0, color.a ))
    rectangle(0,x - 2, y + 2, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x, y, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 2, y, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 4, y + 2, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 6, y, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 8, y, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 10, y + 2, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 12, y + 4, 2, 6, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 10, y + 10, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 8, y + 12, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 6, y + 14, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x + 4, y + 16, 2, 2, Color( 0, 0, 0, color.a ))
    rectangle(0,x - 2, y + 4, 2, 6, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x, y + 2, 4, 2, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x, y + 6, 4, 6, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 2, y + 4, 2, 2, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 2, y + 12, 2, 2, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 4, y + 4, 2, 12, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 6, y + 2, 4, 10, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 6, y + 12, 2, 2, Color( color.r, color.g, color.b, color.a ))
    rectangle(0,x + 10, y + 4, 2, 6, Color( color.r, color.g, color.b, color.a ))

    rectangle(0,x, y + 4, 2, 2, Color( 254, 199, 199, color.a ))
end

local function on_draw()

    local realtime = CurTime()

    for i = 1, #hearts do
        if hearts[i] == nil then return end

        local heart = hearts[i]

        :ToScreen()
        local vec = Vector(heart.position.x, heart.position.y, heart.position.z):ToScreen()

        local x = vec.x
        local y = vec.y

        local alpha = math.floor(255 - 255 * (realtime - heart.start_time))

        if realtime - heart.start_time >= 1 then
            alpha = 0
        end

        if x ~= nil and y ~= nil then
            if cfg.Misc["misc_heartmarker_color"] == 2 then
                if heart.damage <= 15 then
                    draw_heart(x - 5, y - 5, { 60, 255, 0, alpha })
                elseif heart.damage <= 30 then
                    draw_heart(x - 5, y - 5, { 255, 251, 0, alpha })
                elseif heart.damage <= 60 then
                    draw_heart(x - 5, y - 5, { 255, 140, 0, alpha })
                else
                    draw_heart(x - 5, y - 5, { 254, 19, 19, alpha })
                end
            else
                local clr = custom_color:Get() and get_color(custom_color_c, alpha) or { 254, 19, 19, alpha }

                draw_heart(x - 5, y - 5, clr)
            end
        end

        heart.position.z = heart.position.z + (realtime - heart.frame_time) * 50
        heart.frame_time = realtime

        if realtime - heart.start_time >= 1 then
            table.remove(hearts, i)
        end
    end
end


]]

local chamsVisible, chamsInVisible
hook.Add("RenderScreenspaceEffects", "OtchimDrochit", function()
    --"Flat","Textured","Glass","Wireframe"
    local realanglecolor = string.ToColor(cfg.Colors["real_chams"])
    
    if cfg.ESP["chams_visible_mat"] == 1 then
        chamsVisible = "!flat"
    elseif cfg.ESP["chams_visible_mat"] == 2 then
        chamsVisible = "!textured"
    elseif cfg.ESP["chams_visible_mat"] == 3 then
        chamsVisible = "models/shiny"
    elseif cfg.ESP["chams_visible_mat"] == 4 then
        chamsVisible = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["chams_visible_mat"] == 5 then
        chamsVisible = "models/wireframe"
    elseif cfg.ESP["chams_visible_mat"] == 6 then
        chamsVisible = "!glowcham"
    elseif cfg.ESP["chams_visible_mat"] == 7 then
        chamsVisible = "!glowcham2"
    elseif cfg.ESP["chams_visible_mat"] == 8 then
        chamsVisible = "!glow_additive"
    end

    if cfg.ESP["chams_invisible_mat"] == 1 then
        chamsInVisible = "!flat"
    elseif cfg.ESP["chams_invisible_mat"] == 2 then
        chamsInVisible = "!textured"
    elseif cfg.ESP["chams_invisible_mat"] == 3 then
        chamsInVisible = "models/shiny"
    elseif cfg.ESP["chams_invisible_mat"] == 4 then
        chamsInVisible = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["chams_invisible_mat"] == 5 then
        chamsInVisible = "models/wireframe"
    elseif cfg.ESP["chams_invisible_mat"] == 6 then
        chamsInVisible = "!glowcham"
    elseif cfg.ESP["chams_invisible_mat"] == 7 then
        chamsInVisible = "!glowcham2"
    elseif cfg.ESP["chams_invisible_mat"] == 8 then
        chamsInVisible = "!glow_additive"
    end

    if cfg.ESP["real_chams_m"] == 1 then
        rlchams = "!flat"
    elseif cfg.ESP["real_chams_m"] == 2 then
        rlchams = "!textured"
    elseif cfg.ESP["real_chams_m"] == 3 then
        rlchams = "models/shiny"
    elseif cfg.ESP["real_chams_m"] == 4 then
        rlchams = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["real_chams_m"] == 5 then
        rlchams = "models/wireframe"
    end

    local cf = (1/255)
    local visivleCol = string.ToColor(cfg.Colors["chams_visible"])
    local invisibleCol = string.ToColor(cfg.Colors["chams_invisible"])

    cam.Start3D()
    for k, v in ipairs(player.GetAll()) do	
        if IsValid(v) and v:Alive() and v == me then
            if IsValid(v:GetActiveWeapon()) then
                local gun = v:GetActiveWeapon():GetClass()

                if cfg.gunSkins[gun] then
                    render.SetColorModulation(cfg.gunSkins[gun][4]/255,cfg.gunSkins[gun][5]/255,cfg.gunSkins[gun][6]/255)
                    render.SetBlend(cfg.gunSkins[gun][7]/255)
                    render.MaterialOverride(Material(cfg.gunSkins[gun][1]))
                else
                    render.SetColorModulation(1,1,1)
                    render.MaterialOverride(Material(""))
                end

                v:GetActiveWeapon():SetRenderMode(1)
                v:GetActiveWeapon():SetColor(Color(255, 255, 255, 0))
                v:GetActiveWeapon():DrawModel()
            end
        end
    end
    cam.End3D()

    if cfg.Ragebot["real_chams_real"] then
        cam.Start3D()
            for k, v in ipairs(player.GetAll()) do	
                if IsValid(v) and v:Alive() and v == me then
                    render.MaterialOverride(Material(rlchams))
                    render.SetBlend(realanglecolor.a/255)
                    render.SetColorModulation(realanglecolor.r/255, realanglecolor.g/255, realanglecolor.b/255)
                    v:SetRenderMode(1)
                    v:SetColor(Color(255, 255, 255, 0))
                    v:DrawModel()
                end
            end
        cam.End3D()
    end

    if cfg.ESP["chams_invisible"] then
        cam.Start3D()
            for k, v in ipairs(player.GetAll()) do	
                if IsValid(v) and v:Alive() and v != me then
                    cam.IgnoreZ(true)
                    render.SetColorModulation( invisibleCol.r * cf, invisibleCol.g * cf, invisibleCol.b * cf )
                    render.SetBlend( invisibleCol.a * cf)
                    render.MaterialOverride(Material(chamsInVisible))
                    v:SetRenderMode(1)
                    v:DrawModel()
                    if cfg.ESP["chams_invisible_att"] then
                        if IsValid(v:GetActiveWeapon()) then
                            local vGun = v:GetActiveWeapon()
                            vGun:SetRenderMode(1)
                            vGun:DrawModel()
                        end
                    end
                    cam.IgnoreZ(false)
                    render.SetColorModulation(1, 1, 1)
                    render.SetBlend(1)
                    render.MaterialOverride()
                    v:DrawModel()
                    if cfg.ESP["chams_invisible_att"] then
                        if IsValid(v:GetActiveWeapon()) then
                            local vGun = v:GetActiveWeapon()
                            vGun:DrawModel()
                        end
                    end
                end
            end
        cam.End3D()
    end
    if cfg.ESP["chams_visible"] then
        cam.Start3D()
            for k, v in ipairs(player.GetAll()) do
                if IsValid(v) and v:Alive() and v != me then
                    render.SetColorModulation( visivleCol.r * cf, visivleCol.g * cf, visivleCol.b * cf )
                    render.SetBlend( visivleCol.a * cf)
                    render.MaterialOverride(Material(chamsVisible))
                    v:SetRenderMode(1)
                    v:SetColor(Color(255, 255, 255, 0))
                    v:DrawModel()
                    if cfg.ESP["chams_visible_att"] then
                        if IsValid(v:GetActiveWeapon()) then
                            local vGun = v:GetActiveWeapon()
                            vGun:SetRenderMode(1)
                            vGun:SetColor(Color(255, 255, 255, 0))
                            vGun:DrawModel()
                        end
                    end
                end
            end
        cam.End3D()
    end
    if !cfg.ESP["chams_invisible"] && !cfg.ESP["chams_visible"] then
		for k, v in pairs(player.GetAll()) do
			v:SetRenderMode(0)
            if !cfg.ESP["chams_invisible_att"] and !cfg.ESP["chams_visible_att"] then
                if IsValid(v:GetActiveWeapon()) then
                    local vGun = v:GetActiveWeapon()
                    vGun:SetRenderMode(0)
                end
            end
		end
	end

    --render.SetColorModulation(1, 1, 1)
    --render.MaterialOverride()
    --render.SetBlend(1)
end)

local numBulletImpacts = 0
local numPlayerHurts = 0
hook.Add("OnImpact", "chepuha", function(data)
    local bestPlayer = nil
    local bestDistance = math.huge
    for _, ply in ipairs(player.GetAll()) do
        local distance = ply:EyePos():DistToSqr(data.m_vStart)
        if distance < bestDistance then
            bestPlayer = ply
            bestDistance = distance
        end
    end

    if bestPlayer == me then
        
        numBulletImpacts = numBulletImpacts + 1

        table.insert(addBulletBeam, {
            data.m_vStart,
            data.m_vOrigin,
            cfg.Misc["misc_bullettrace_time"],
            
        })
        table.insert(addBulletImpact, {
            data.m_vOrigin,
            cfg.Misc["misc_bulletimpact_time"],
        })    

    end

    if bestPlayer != me then
        if cfg.Misc["misc_bullettrace_onlyt"] then 
            if bestPlayer != target then return end
        end
        table.insert(addBulletBeamEnemy, {
            data.m_vStart,
            data.m_vOrigin,
            cfg.Misc["misc_bullettrace_time_e"],     
        })
        table.insert(addBulletImpactEnemy, {
            data.m_vOrigin,
            cfg.Misc["misc_bulletimpact_time_e"],
        })    
    end
end)

addBulletBeam = {}
addBulletImpact = {}
addBulletBeamEnemy = {}
addBulletImpactEnemy = {}

hook.Add("PreDrawOpaqueRenderables", "RandomString()", function ()
    -- Enemy bullets
    if cfg.Misc["misc_bullettrace_e"] then
        for k,v in next, addBulletBeamEnemy do
            if(v[3] <= 0) then
                table.remove(addBulletBeamEnemy, k);
                continue;
            end
            addBulletBeamEnemy[k][3] = addBulletBeamEnemy[k][3] - FrameTime();
            local pos1, pos2 = v[1], v[2]; 
            cam.Start3D();
                if cfg.Misc["misc_bullettrace_blinking_e"] then
                    render.SetMaterial(Material("sprites/tp_beam001"))
                else
                    render.SetMaterial(Material("sprites/physbeama"))
                end
                if cfg.Misc["misc_bullettrace_type_e"] == 1 then
                    render.DrawBeam(v[1], v[2], 4, 1, 1, string.ToColor(cfg.Colors["misc_bullettrace_e"]))
                else
                    render.DrawLine( v[1], v[2] , string.ToColor(cfg.Colors["misc_bullettrace_e"]) )
                end
            cam.End3D();
        end
    end
    if cfg.Misc["misc_bulletimpact_e"] then
        for k,v in next, addBulletImpactEnemy do
            if(v[2] <= 0) then
                table.remove(addBulletImpactEnemy, k);
                continue;
            end
            addBulletImpactEnemy[k][2] = addBulletImpactEnemy[k][2] - FrameTime();
            local posImpact = v[1];
            cam.Start3D();
                render.SetColorMaterial()

                cam.IgnoreZ( true ) 
                    render.DrawBox( posImpact, Angle(0,0,0), Vector( 2, 2, 2 ), -Vector( 2, 2, 2 ), string.ToColor(cfg.Colors["misc_bulletimpact_e"]) )
                cam.IgnoreZ( false )

                render.DrawWireframeBox( posImpact, Angle(0,0,0), Vector( 2, 2, 2 ), -Vector( 2, 2, 2 ), string.ToColor(cfg.Colors["misc_bulletimpact_e"]), true )
                
                if cfg.Misc["misc_bulletimpact_glow_e"] then
                    render.SetMaterial( Material("sprites/light_ignorez") )
                    render.DrawSprite( posImpact, 32, 32, string.ToColor(cfg.Colors["misc_bulletimpact_e"]))
                end

            cam.End3D();
        end
    end
    -- My bullets
    if cfg.Misc["misc_bullettrace"] then
        for k,v in next, addBulletBeam do
            if(v[3] <= 0) then
                table.remove(addBulletBeam, k);
                continue;
            end
            addBulletBeam[k][3] = addBulletBeam[k][3] - FrameTime();
            local pos1, pos2 = v[1], v[2]; 
            cam.Start3D();
                if cfg.Misc["misc_bullettrace_blinking"] then
                    render.SetMaterial(Material("sprites/tp_beam001"))
                else
                    render.SetMaterial(Material("sprites/physbeama"))
                end
                if cfg.Misc["misc_bullettrace_type"] == 1 then
                    render.DrawBeam(v[1], v[2], 4, 1, 1, string.ToColor(cfg.Colors["misc_bullettrace"]))
                else
                    render.DrawLine( v[1], v[2] , string.ToColor(cfg.Colors["misc_bullettrace"]) )
                end
            cam.End3D();
        end
    end
    if cfg.Misc["misc_bulletimpact"] then
        for k,v in next, addBulletImpact do
            if(v[2] <= 0) then
                table.remove(addBulletImpact, k);
                continue;
            end
            addBulletImpact[k][2] = addBulletImpact[k][2] - FrameTime();
            local posImpact = v[1];
            cam.Start3D();
                render.SetColorMaterial()

                cam.IgnoreZ( true ) 
                    render.DrawBox( posImpact, Angle(0,0,0), Vector( 2, 2, 2 ), -Vector( 2, 2, 2 ), string.ToColor(cfg.Colors["misc_bulletimpact"]) )
                cam.IgnoreZ( false )

                render.DrawWireframeBox( posImpact, Angle(0,0,0), Vector( 2, 2, 2 ), -Vector( 2, 2, 2 ), string.ToColor(cfg.Colors["misc_bulletimpact"]), true )
                
                if cfg.Misc["misc_bulletimpact_glow"] then
                    render.SetMaterial( Material("sprites/light_ignorez") )
                    render.DrawSprite( posImpact, 32, 32, string.ToColor(cfg.Colors["misc_bulletimpact"]))
                end

            cam.End3D();
        end
    end


end)

local function DisableWorldModulation()
	for k, v in pairs( Entity( 0 ):GetMaterials() ) do
   		Material( v ):SetVector( "$color", Vector(1, 1, 1) )
   		Material( v ):SetFloat( "$alpha", 1 )
	end
end
local function DisablePropModulation()

	for k, v in pairs(ents.FindByClass("prop_physics")) do
		v:SetColor(Color(255, 255, 255, 255))
		v:SetRenderMode( RENDERMODE_NORMAL )
	end

    for k, v in pairs(ents.FindByClass("prop_dynamic")) do
		v:SetColor(Color(255, 255, 255, 255))
		v:SetRenderMode( RENDERMODE_NORMAL )
	end

    for k, v in pairs(ents.FindByClass("prop_static")) do
		v:SetColor(Color(255, 255, 255, 255))
		v:SetRenderMode( RENDERMODE_NORMAL )
	end

end

local OldWorldModState, OldWorldModColor, OldPropModState, OldPropModColor = cfg.Misc["wall_color"], cfg.Colors["wall_color"], cfg.Misc["prop_color"], cfg.Colors["prop_color"]

local function UpdateWorldModulation()

	local col = string.ToColor(cfg.Colors["wall_color"])

	for k, v in pairs( Entity( 0 ):GetMaterials() ) do
   		Material( v ):SetVector( "$color", Vector(col.r * (1 / 255), col.g * (1 / 255), col.b * (1 / 255)) )
   		Material( v ):SetFloat( "$alpha", col.a * (1 / 255) )
	end

end

local function UpdatePropModulation()

	local col = string.ToColor(cfg.Colors["prop_color"])

	for k, v in pairs(ents.FindByClass("prop_physics")) do
		v:SetRenderMode( RENDERMODE_TRANSCOLOR )
		v:SetColor(col)
	end

    for k, v in pairs(ents.FindByClass("prop_dynamic")) do
		v:SetRenderMode( RENDERMODE_TRANSCOLOR )
		v:SetColor(col)
	end

    for k, v in pairs(ents.FindByClass("prop_static")) do
		v:SetRenderMode( RENDERMODE_TRANSCOLOR )
		v:SetColor(col)
	end

end

local scropeAlpha = 0
hook.Add("Think", "updater", function()

    --print(cfg.Misc["wall_color"])

	if OldWorldModState != cfg.Misc["wall_color"] && cfg.Misc["wall_color"] then
		UpdateWorldModulation()
		OldWorldModState, OldWorldModColor = cfg.Misc["wall_color"], cfg.Colors["wall_color"]
	elseif OldWorldModState != cfg.Misc["wall_color"] && !cfg.Misc["wall_color"] then
		DisableWorldModulation()
		OldWorldModState, OldWorldModColor = cfg.Misc["wall_color"], cfg.Colors["wall_color"]
	end
	if OldWorldModColor != cfg.Colors["wall_color"] && cfg.Misc["wall_color"] then
		UpdateWorldModulation()
		OldWorldModState, OldWorldModColor = cfg.Misc["wall_color"], cfg.Colors["wall_color"]
	end

	if OldPropModState != cfg.Misc["prop_color"] && cfg.Misc["prop_color"] then
		UpdatePropModulation()
		OldPropModState, OldPropModColor = cfg.Misc["prop_color"], cfg.Colors["prop_color"]
	elseif OldPropModState != cfg.Misc["prop_color"] && !cfg.Misc["prop_color"] then
		DisablePropModulation()
		OldPropModState, OldPropModColor = cfg.Misc["prop_color"], cfg.Colors["prop_color"]
	end
	if OldPropModColor != cfg.Colors["prop_color"] && cfg.Misc["prop_color"] then
		UpdatePropModulation()
		OldPropModState, OldPropModColor = cfg.Misc["prop_color"], cfg.Colors["prop_color"]
	end
	
    if cfg.Misc["sky_3d"] and GetConvar("r_3dsky"):GetInt() != 0 then
        RunConsoleCommand("r_3dsky", "0")
    else
        RunConsoleCommand("r_3dsky", "1")
    end
    
end)

hook.Add("SetupWorldFog", "SetupWorldFog", function()
	if cfg.Misc["fog_e"] then
		local col = string.ToColor(cfg.Colors["fog_e"])

		render.FogMode( MATERIAL_FOG_LINEAR )
		render.FogStart(cfg.Misc["fog_s"])
		render.FogEnd(cfg.Misc["fog_end"])
		render.FogMaxDensity(cfg.Misc["fog_d"])
		render.FogColor(col.r, col.g, col.b)

		return true
	end
end)

hook.Add("SetupSkyboxFog","SetupSkyboxFog", function( skyboxscale )

	if cfg.Misc["fog_e"] then

		local col = string.ToColor(cfg.Colors["fog_e"])

		render.FogMode( MATERIAL_FOG_LINEAR )
		render.FogStart(cfg.Misc["fog_s"] * skyboxscale)
		render.FogEnd(cfg.Misc["fog_end"] * skyboxscale)
		render.FogMaxDensity(cfg.Misc["fog_d"])
		render.FogColor(col.r, col.g, col.b)

		return true
	end
end)

-- skybox changer

local SourceSkyname = GetConVar("sv_skyname"):GetString()
local origsky = SourceSkyname
local SourceSkyPre = {"lf", "ft", "rt", "bk", "dn", "up"}
local SourceSkyMat = {
    Material("skybox/".. SourceSkyname.. "lf"),
    Material("skybox/".. SourceSkyname.. "ft"),
    Material("skybox/".. SourceSkyname.. "rt"),
    Material("skybox/".. SourceSkyname.. "bk"),
    Material("skybox/".. SourceSkyname.. "dn"),
    Material("skybox/".. SourceSkyname.. "up")
}
local function ChangeSkybox(skyboxname)
    for i = 1, 6 do
        D = Material("skybox/".. skyboxname.. SourceSkyPre[i]):GetTexture("$basetexture")
        SourceSkyMat[i]:SetTexture("$basetexture", D)
    end
end

local function ChangeSkyColor(reset)
    local col = string.ToColor(cfg.Colors["sky_c"])
    for i = 1, 6 do
        if !reset then
            SourceSkyMat[i]:SetVector( "$color", Vector(col.r * (1 / 255), col.g * (1 / 255), col.b * (1 / 255)) )
        else
            SourceSkyMat[i]:SetVector( "$color", Vector(1,1,1) )
        end
    end
end

hook.Add("RenderScene","SceneRender",function()
    if cfg.Misc["sky_ch"] then
        if cfg.Misc["skyboxname"] != nil then
            ChangeSkybox(cfg.Misc["skyboxname"])
        else
            ChangeSkybox(origsky)
        end
    end
    if cfg.Misc["sky_c"] then
        ChangeSkyColor()
    else
        ChangeSkyColor(true)
    end
    if cfg.Misc["orange"] then
        for k, v in pairs( Entity( 0 ):GetMaterials() ) do
            Material( v ):SetTexture("$basetexture", "pivokvasovo/obeme")
        end
    end
end)


local LightingModeChanged = false
hook.Add("PreRender", "IlyaWareRender", function()
	if cfg.Misc["fullbright"] then
		render.SetLightingMode( 1 )
		LightingModeChanged = true
	end
end )

local function EndOfLightingMod()
	if LightingModeChanged then
		render.SetLightingMode( 0 )
		LightingModeChanged = false
	end
end
hook.Add("PostRender", "post", EndOfLightingMod)
hook.Add("PreDrawHUD", "predrawcock", EndOfLightingMod)

hook.Add("PreDrawSkyBox", "blackSky", function()
	if cfg.Misc["sky_b"] then
		return true
	else
		return false
	end
end)

hook.Add("PostDraw2DSkyBox", "skyboxRect", function()
    local col = string.ToColor(cfg.Colors["sky_f"])
    if cfg.Misc["sky_f"] then
        render.OverrideDepthEnable( true, false )
        cam.Start2D()
            surface.SetDrawColor(col.r, col.g, col.b, col.a)
            surface.DrawRect(0,0,ScrW(), ScrH())
        cam.End2D()
        render.OverrideDepthEnable( false, false )
    end
end)

local function GetENTPos ( Ent )
	if Ent:IsValid() then 
		local Points = {
			Vector( Ent:OBBMaxs().x, Ent:OBBMaxs().y, Ent:OBBMaxs().z ),
			Vector( Ent:OBBMaxs().x, Ent:OBBMaxs().y, Ent:OBBMins().z ),
			Vector( Ent:OBBMaxs().x, Ent:OBBMins().y, Ent:OBBMins().z ),
			Vector( Ent:OBBMaxs().x, Ent:OBBMins().y, Ent:OBBMaxs().z ),
			Vector( Ent:OBBMins().x, Ent:OBBMins().y, Ent:OBBMins().z ),
			Vector( Ent:OBBMins().x, Ent:OBBMins().y, Ent:OBBMaxs().z ),
			Vector( Ent:OBBMins().x, Ent:OBBMaxs().y, Ent:OBBMins().z ),
			Vector( Ent:OBBMins().x, Ent:OBBMaxs().y, Ent:OBBMaxs().z )
		}
		local MaxX, MaxY, MinX, MinY
		local V1, V2, V3, V4, V5, V6, V7, V8
		local isVis
		for k, v in pairs( Points ) do
			local ScreenPos = Ent:LocalToWorld( v ):ToScreen()
			isVis = ScreenPos.visible
			if MaxX != nil then
				MaxX, MaxY, MinX, MinY = math.max( MaxX, ScreenPos.x ), math.max( MaxY, ScreenPos.y), math.min( MinX, ScreenPos.x ), math.min( MinY, ScreenPos.y)
			else
				MaxX, MaxY, MinX, MinY = ScreenPos.x, ScreenPos.y, ScreenPos.x, ScreenPos.y
			end

			if V1 == nil then
				V1 = ScreenPos
			elseif V2 == nil then
				V2 = ScreenPos
			elseif V3 == nil then
				V3 = ScreenPos
			elseif V4 == nil then
				V4 = ScreenPos
			elseif V5 == nil then
				V5 = ScreenPos
			elseif V6 == nil then
				V6 = ScreenPos
			elseif V7 == nil then
				V7 = ScreenPos
			elseif V8 == nil then
				V8 = ScreenPos
			end
		end
		return MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8, isVis
	end
end

local function drawPlayerBox(ply)

    local hsvtocolor = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
    local teamcol = team.GetColor( ply:Team() )
    local boxcolor = string.ToColor(cfg.Colors["esp_box"])
    local frcol = string.ToColor(cfg.Colors["esp_box_fr"])
    local gradcolor, fillcolor = string.ToColor(cfg.Colors["esp_box_grad"]), string.ToColor(cfg.Colors["esp_box_f"])
    if cfg.ESP["esp_box_team"] then
        boxcolor = teamcol
        gradcolor = Color(teamcol.r,teamcol.g,teamcol.b,gradcolor.a)
        fillcolor = Color(teamcol.r,teamcol.g,teamcol.b,fillcolor.a)
    else
        boxcolor = string.ToColor(cfg.Colors["esp_box"])
        gradcolor = string.ToColor(cfg.Colors["esp_box_grad"])
        fillcolor = string.ToColor(cfg.Colors["esp_box_f"])
    end

    if cfg.ESP["esp_box_grad_r"] then 
        gradcolor = Color(hsvtocolor.r,hsvtocolor.g,hsvtocolor.b,gradcolor.a)
    end
    if cfg.ESP["esp_box_f_r"] then 
        fillcolor = Color(hsvtocolor.r,hsvtocolor.g,hsvtocolor.b,fillcolor.a)
    end


    local boxcolortar = string.ToColor(cfg.Colors["esp_box_trg"])
    
    local MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8, isVis = GetENTPos( ply )

    local XLen, YLen = MaxX - MinX, MaxY - MinY
    
    if cfg.ESP["esp_box_f"] then
        draw.RoundedBox(0,MinX,MinY,XLen,YLen,Color(fillcolor.r,fillcolor.g,fillcolor.b,fillcolor.a))
    end

    if cfg.ESP["esp_box_grad"] then
        surfaceTexture(MinX,MinY,XLen,YLen,"gui/gradient_up",gradcolor)
    end

    if cfg.ESP["esp_box_trg"] and target != nil and ply == target then
        surface.SetDrawColor(boxcolortar.r,boxcolortar.g,boxcolortar.b)  
    elseif cfg.ESP["esp_box_r"] then
        surface.SetDrawColor(hsvtocolor.r,hsvtocolor.g,hsvtocolor.b)
    else
        surface.SetDrawColor(boxcolor.r,boxcolor.g,boxcolor.b)
    end

    if cfg.ESP["esp_box_type"] == 1 then
        surface.DrawOutlinedRect(MinX,MinY,XLen,YLen,1)
    elseif cfg.ESP["esp_box_type"] == 2 then    
        surface.DrawLine( MaxX, MaxY, MinX + XLen * 0.7, MaxY)
        surface.DrawLine( MinX, MaxY, MinX + XLen * 0.3, MaxY)
        surface.DrawLine( MaxX, MaxY, MaxX, MinY + YLen * 0.75)
        surface.DrawLine( MaxX, MinY, MaxX, MinY + YLen * 0.25)
        surface.DrawLine( MinX, MinY, MaxX - XLen * 0.7, MinY )
        surface.DrawLine( MaxX, MinY, MaxX - XLen * 0.3, MinY )
        surface.DrawLine( MinX, MinY, MinX, MaxY - YLen * 0.75)
        surface.DrawLine( MinX, MaxY, MinX, MaxY - YLen * 0.25)
    elseif cfg.ESP["esp_box_type"] == 4 then 
        surface.SetDrawColor(0,0,0)
        surface.DrawOutlinedRect(MinX,MinY,XLen,YLen,3)

        if cfg.ESP["esp_box_fr"] and table.HasValue(cfg["friends"], ply:SteamID()) then
            surface.SetDrawColor(frcol.r,frcol.g,frcol.b,frcol.a)  
        elseif cfg.ESP["esp_box_trg"] and target != nil and ply == target then
            surface.SetDrawColor(boxcolortar.r,boxcolortar.g,boxcolortar.b)  
        elseif cfg.ESP["esp_box_r"] then
            surface.SetDrawColor(hsvtocolor.r,hsvtocolor.g,hsvtocolor.b)
        else
            surface.SetDrawColor(boxcolor.r,boxcolor.g,boxcolor.b)
        end
        surface.DrawOutlinedRect(MinX+1,MinY+1,XLen-2,YLen-2,1)
    end

end

function HUDPaint()
    if cfg.Vars["self_trail"] then
		local hsv = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
		surfaceSetDrawColor(hsv.r,hsv.g,hsv.b)
		for i = 1, trailpos-1 do
			local pos = trailpos[i]:ToScreen()
			local prevpos = trailpos[i+1]:ToScreen()
			surfaceDrawLine(pos.x,pos.y,prevpos.x,prevpos.y)
		end
	end	
	trailpos[#trailpos+1] = LocalPlayer():GetPos()

	if trailpos > 100 then
		table.remove(trailpos,1)
	end
end

local function drawESPText(text,color,x,y)

    surface.SetTextColor( color.r, color.g, color.b )
	surface.SetTextPos( x, y ) 
	surface.SetFont( "ESP Font" )
	surface.DrawText( text ) 

end

local surfaceTexture = surfaceTexture

function PlayerESP()
    local nameColor = string.ToColor(cfg.Colors["esp_name"])
    local weaponColor = string.ToColor(cfg.Colors["esp_wep"])
    local healthColor = string.ToColor(cfg.Colors["esp_hp"])
    local armorColor = string.ToColor(cfg.Colors["esp_ap"])

    local healthbarColor = string.ToColor(cfg.Colors["esp_hp_bar"])
    local healthbarColor2 = string.ToColor(cfg.Colors["esp_hp_bar_gradient"])

    for balls, gamer in pairs(player.GetAll()) do
        if IsValid(gamer) then       
            local MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8, isVis = GetENTPos( gamer )
            local XLen, YLen = MaxX - MinX, MaxY - MinY
            surface.SetFont("ESP Font")
            
            gamer.DormantAlpha = gamer.DormantAlpha or 255
            if gamer:IsDormant() then
                gamer.DormantAlpha = math.Approach(gamer.DormantAlpha,85,FrameTime()*200)
            else
                gamer.DormantAlpha = math.Approach(gamer.DormantAlpha,255,FrameTime()*200)
            end

            if gamer != me and gamer:Alive() then
                surface.SetAlphaMultiplier(gamer.DormantAlpha/255)

                -- esp elements
                if cfg.ESP["esp_box"] then
                    drawPlayerBox(gamer)
                end
                if cfg.ESP["esp_name"] then
                    local namelenx,nameleny = surface.GetTextSize(gamer:Name())
                    drawESPText(gamer:Name(),nameColor,MinX+XLen/2-namelenx/2,MinY-nameleny)
                end
                if cfg.ESP["esp_wep"] then
                    if IsValid(gamer:GetActiveWeapon()) then
                        local weplenx,wepleny = surface.GetTextSize(gamer:GetActiveWeapon():GetPrintName())
                        drawESPText(gamer:GetActiveWeapon():GetPrintName(),weaponColor,MinX+XLen/2-weplenx/2,MaxY)
                    end
                end
                if cfg.ESP["esp_hp"] then   
                    local hplenx,hpleny = surface.GetTextSize(gamer:Health())

                    drawESPText(gamer:Health(),healthColor,MinX-hplenx-6,MinY)

                end
                if cfg.ESP["esp_ap"] then
                    local aplenx,apleny = surface.GetTextSize(gamer:Armor())
                    drawESPText(gamer:Armor(),armorColor,MaxX+2,MinY)
                end

                -- bars
                if cfg.ESP["esp_hp_bar"] then
                    local hp = gamer:Health() * YLen / 100;
                    if(hp > YLen) then hp = YLen; end
                    local diff = YLen - hp

                    surface.SetDrawColor(0, 0, 0, 255);
                    surface.DrawRect(MinX - 5, MinY, 4, YLen);
                    if cfg.ESP["esp_hp_bar_ac"] then
                        surface.SetDrawColor( ( 100 - gamer:Health() ) * 2.55, gamer:Health() * 2.55, 0, 255)
                    else
                        surface.SetDrawColor(healthbarColor.r,healthbarColor.g,healthbarColor.b)
                    end
                    surface.DrawRect(MinX - 4, MinY + diff+1, 2, hp-2);
                    if cfg.ESP["esp_hp_bar_gradient"] then
                        surfaceTexture(MinX - 4, MinY + diff+1, 2, hp-2,"gui/gradient_up",healthbarColor2)
                    end
                end

            end
        end
    end
    surface.SetAlphaMultiplier(255)



end

hook.Add("HUDPaint","playerESP",PlayerESP)

local inds = 1
local function drawInds(name,value,number,maxvalue)
    local mainColor 
    if cfg.Misc["misc_inds_hsv"] then
        mainColor = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
    else
        mainColor = string.ToColor(cfg.Colors["misc_inds"])
    end
    local secColor 
    if cfg.Misc["misc_inds_hsv_g"] then
        secColor = HSVToColor( ( CurTime() * -50 ) % 360, 1, 1 )
    else
        secColor = string.ToColor(cfg.Colors["misc_inds_grad"])
    end

    local boxRounding = cfg.Misc["misc_inds_r"]

    local clampedvalue = math.Clamp(value,0,maxvalue)
    local fval = 194 / maxvalue

    if cfg.Misc["misc_inds_s"] == 1 then
        draw.RoundedBox(boxRounding,5,5+number*45,200,25,Color(0,0,0,200))
        draw.RoundedBox(boxRounding/2,5,32+number*45,200,15,Color(0,0,0,200)) 
   
    elseif cfg.Misc["misc_inds_s"] == 2 then
        surfaceTexture(5,5+number*45,200,25,"gui/center_gradient",Color(0,0,0,200))
        surfaceTexture(3,32+number*45,200,15,"gui/center_gradient",Color(0,0,0,200))
    elseif cfg.Misc["misc_inds_s"] == 3 then
        surfaceTexture(5,5+number*45,200,25,"gui/gradient_up",Color(0,0,0,200)) 
        surfaceTexture(5,5+number*45,200,25,"gui/gradient_down",Color(0,0,0,200)) 
        surfaceTexture(3,32+number*45,200,15,"gui/gradient_up",Color(0,0,0,200))
        surfaceTexture(3,32+number*45,200,15,"gui/gradient_down",Color(0,0,0,200))
    elseif cfg.Misc["misc_inds_s"] == 4 then
        surfaceTexture(5,5+number*45,200,25,"gui/gradient",Color(0,0,0,200)) 
        surfaceTexture(5,32+number*45,200,15,"gui/gradient",Color(0,0,0,200)) 
    end

    draw.SimpleText(name .. math.Round(value),"MainFont",102,17+number*45,color_White,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    draw.RoundedBox(0,8,35+number*45,clampedvalue*fval,9,Color(mainColor.r,mainColor.g,mainColor.b))

    if cfg.Misc["misc_inds_grad"] then
        surfaceTexture(8,35+number*45,clampedvalue*fval,9,"gui/gradient",Color(secColor.r,secColor.g,secColor.b)) 
    end

    if value > 194 then fval = 1 clampedvalue = 194 end
end

hook.Add("HUDPaint","OOfarrows",function()
	RotatedArrow = function(x, y, ang)
		local ang1 = Angle(0, ang, 0):Forward() * cfg.ESP["oof_arrows_as"]
		local ang2 = Angle(0, ang + 120, 0):Forward() * (cfg.ESP["oof_arrows_as"] - 1)
		local ang3 = Angle(0, ang - 120, 0):Forward() * (cfg.ESP["oof_arrows_as"] - 1)
	
		local p0 = {x = x, y = y}
		local poly = {
			{x = p0.x + ang1.x, y = p0.y + ang1.y},
			{x = p0.x + ang2.x, y = p0.y + ang2.y},
			{x = p0.x + ang3.x, y = p0.y + ang3.y},
		}
		return poly
	end

	if cfg.ESP["oof_arrows"] then
		
		local myTeam = me:Team()
		local eye = me:EyePos()
	
		local lcolor = string.ToColor(cfg.Colors["oof_arrows"])
		local clr0, dormClr = Color(lcolor.r,lcolor.g,lcolor.b,lcolor.a/2), string.ToColor(cfg.Colors["oof_arrows_d"])
		local clr1 = lcolor, string.ToColor(cfg.Colors["oof_arrows_d"])  

		local xScale, yScale = ScrW() / 250, ScrH() / 250
		local xScale, yScale = xScale * cfg.ESP["oof_arrows_ad"], yScale * cfg.ESP["oof_arrows_ad"]
	
		for k,plr in ipairs(player.GetAll()) do
			if(!plr || plr == me || !plr:Alive()) then continue end

			local angle = (plr:EyePos() - eye):Angle()
			local addPos = Angle(0, (fa.y - angle.y) - 90, 0):Forward()
			
			local pos = Vector(ScrW() / 2, ScrH() / 2, 0) + Vector(addPos.x * xScale, addPos.y * yScale, 0)
	
			if(math.abs(math.NormalizeAngle(angle.y - fa.y)) < 60) then return end

			// ARROW
	
			local arrow = RotatedArrow(pos.x, pos.y, (fa.y - angle.y) - 90)
			
            if cfg.ESP["oof_arrows_d"] then
                if plr:IsDormant() then
			        surface.SetDrawColor(dormClr)
                else
                    if cfg.ESP["oof_arrows_b"] then
                        surface.SetDrawColor(clr0.r,clr0.g,math.floor( math.sin( CurTime() * cfg.ESP["oof_arrows_bs"] + plr:EntIndex() ) * 20 ) + 65)
                    else
                        surface.SetDrawColor(clr0)
                    end
                end
            else
                if cfg.ESP["oof_arrows_b"] then
                    surface.SetDrawColor(clr0.r,clr0.g,clr0.b,math.floor( math.sin( CurTime() * cfg.ESP["oof_arrows_bs"] + plr:EntIndex() ) * 20 ) + 65)
                else
                    surface.SetDrawColor(clr0)
                end
            end

			draw.NoTexture()
			surface.DrawPoly(arrow)
	
            if cfg.ESP["oof_arrows_d"] then
                if plr:IsDormant() then
			        surface.SetDrawColor(dormClr)
                else
                    if cfg.ESP["oof_arrows_b"] then
                        surface.SetDrawColor(clr1.r,clr1.g,clr1.b,math.floor( math.sin( CurTime() * cfg.ESP["oof_arrows_bs"] + plr:EntIndex() ) * 20 ) + 65)
                    else
                        surface.SetDrawColor(clr1)
                    end
                end
            else
                if cfg.ESP["oof_arrows_b"] then
                    surface.SetDrawColor(clr1.r,clr1.g,clr1.b,math.floor( math.sin( CurTime() * cfg.ESP["oof_arrows_bs"] + plr:EntIndex() ) * 20 ) + 65)
                else
                    surface.SetDrawColor(clr1)
                end
            end
		end
	end
end)

local estscope = {
    ["weapon_csgo_snip_ssg08"] = true,
    ["weapon_csgo_snip_awp"] = true,
    ["weapon_csgo_snip_g3sg1"] = true,
    ["weapon_csgo_snip_scar20"] = true,
}
local function basedGigaIlysha()
--    if bsendpacket then
  --      draw.SimpleText("BSENDPACKET","ESP Font",5,ScrH()/2+40,Color(0,255,0))
    --    draw.SimpleText("FL: " .. fakeLagTicks .. " / " .. fakeLagfactor,"ESP Font",5,ScrH()/2+20,Color(0,255,0))
    --else
     --   draw.SimpleText("BSENDPACKET","ESP Font",5,ScrH()/2+40,Color(255,0,0))
      --  draw.SimpleText("FL: " .. fakeLagTicks .. " / " .. fakeLagfactor,"ESP Font",5,ScrH()/2+20,Color(255,0,0))
    --end

    if cfg.Misc["misc_hitmarker"] then
        local hitmarkercolor = string.ToColor(cfg.Colors["misc_hitmarker"])
        for k, v in next, hitmarkerTable do
            local pos = v[1]:ToScreen()
            local sposx, sposy = ScrW()/2, ScrH()/2
    
            if(v[2] <= 0) then
                table.remove(hitmarkerTable, k);
                continue;
            end
            v[2] = v[2] - FrameTime()

            surface.SetDrawColor(hitmarkercolor.r,hitmarkercolor.g,hitmarkercolor.b,hitmarkercolor.a)
            if cfg.Misc["misc_hitmarker_pos"] == 1 then
                surface.DrawLine( pos.x - 8, pos.y - 8, pos.x - 2, pos.y - 2 )
                surface.DrawLine( pos.x - 8, pos.y + 8, pos.x - 2, pos.y + 2 )
                surface.DrawLine( pos.x + 8, pos.y - 8, pos.x + 2, pos.y - 2 )
                surface.DrawLine( pos.x + 8, pos.y + 8, pos.x + 2, pos.y + 2 )
            else
                surface.DrawLine( sposx - 8, sposy - 8, sposx - 2, sposy - 2 )
                surface.DrawLine( sposx - 8, sposy + 8, sposx - 2, sposy + 2 )
                surface.DrawLine( sposx + 8, sposy - 8, sposx + 2, sposy - 2 )
                surface.DrawLine( sposx + 8, sposy + 8, sposx + 2, sposy + 2 ) 
            end

        end
    end
    if cfg.Aimbot["aimbot_snapline"] then
        local trgv = targetVector:ToScreen()
        local aimbot_snapline_color = string.ToColor(cfg.Colors["aimbot_snapline"])
        if target != nil and targetVector != nil then
            surface.SetDrawColor(aimbot_snapline_color.r,aimbot_snapline_color.g,aimbot_snapline_color.b,aimbot_snapline_color.a)
            surface.DrawLine( scrw/2, scrh/2, trgv.x, trgv.y)
        end
    end

    -- Crosshair
    if cfg.ESP["ch_e"] then
        local csizew = cfg.ESP["ch_size"]
        local crosshair_color = string.ToColor(cfg.colors["ch_e"])
        if cfg.ESP["ch_type"] == 1 then
            draw.RoundedBox(0,scrw/2-csizew/2-1,scrh/2-csizew/2-1,csizew+2,csizew+2,color_black)
            draw.RoundedBox(0,scrw/2-csizew/2,scrh/2-csizew/2,csizew,csizew,crosshair_color)

            --left
            draw.RoundedBox(0,scrw/2-csizew-16,scrh/2-csizew/2-1,csizew+2+10,csizew+2,color_black)
            draw.RoundedBox(0,scrw/2-csizew-15,scrh/2-csizew/2,csizew+10,csizew,crosshair_color)
            --right
            draw.RoundedBox(0,scrw/2+3,scrh/2-csizew/2-1,csizew+12,csizew+2,color_black)
            draw.RoundedBox(0,scrw/2+4,scrh/2-csizew/2,csizew+10,csizew,crosshair_color)
            --top
            draw.RoundedBox(0,scrw/2-csizew/2-1,scrh/2-csizew/2-16,csizew+2,csizew+12,color_black)
            draw.RoundedBox(0,scrw/2-csizew/2,scrh/2-csizew/2-15,csizew,csizew+10,crosshair_color)
            --down
            draw.RoundedBox(0,scrw/2-csizew/2-1,scrh/2+3,csizew+2,csizew+12,color_black)
            draw.RoundedBox(0,scrw/2-csizew/2,scrh/2+4,csizew,csizew+10,crosshair_color)

        elseif cfg.ESP["ch_type"] == 2 then
            draw.RoundedBox(0,scrw/2-csizew/2-1,scrh/2-csizew/2-1,csizew+2,csizew+2,color_black)
            draw.RoundedBox(0,scrw/2-csizew/2,scrh/2-csizew/2,csizew,csizew,crosshair_color)
        elseif cfg.ESP["ch_type"] == 3 then
            draw.SimpleText("Z","font-02",scrw/2,scrh/2,crosshair_color,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        elseif cfg.ESP["ch_type"] == 4 then

        end
    end

    if cfg.Misc["misc_inds"] then
        drawInds("Lua garbage ",garbage,0,194)
        drawInds("Fake Lag Compilation ",fakeLagTicks,1,23)
        drawInds("Velocity ",math.Round(me:GetVelocity():Length()),2,3000)
    end

    if cfg.Misc["csgo_bscope"] then
        local col = string.ToColor(cfg.Colors["csgo_bscope"])
        local fcolor = Color(col.r,col.g,col.b,col.a)
        local curw = me:GetActiveWeapon()
        if IsValid(me) and IsValid(curw) then
            if !cfg.Misc["csgo_bscope_alt"] then
                if curw.Scope != nil then
                    if curw:GetClass():StartWith("weapon_csgo_") or curw:GetClass():StartWith("weapon_swcs_")  then
                        curw:SetNWString( "ScopeAlpha", 0 )
                        if curw.Scope != 0 then
                            scropeAlpha = math.Approach(scropeAlpha,85+(curw.Scope*10),FrameTime()*250)
                        else
                            scropeAlpha = math.Approach(scropeAlpha,0,FrameTime()*250)
                        end
                        if scropeAlpha > 1 then
                            surfaceTexture(scrw/2+5,scrh/2,scropeAlpha,2,"gui/gradient_up",fcolor)
                            surfaceTexture(scrw/2-5-scropeAlpha,scrh/2,scropeAlpha,2,"gui/gradient_up",fcolor)
                            surfaceTexture(scrw/2,scrh/2+5,2,scropeAlpha,"gui/gradient_up",fcolor)
                            surfaceTexture(scrw/2,scrh/2-5-scropeAlpha,2,scropeAlpha,"gui/gradient_up",fcolor)

                        end
                        --print(curw.Scope)
                        if cfg.Misc["csgo_bscope_dl"] then
                            if curw.Scope != 0 then
                                surface.SetDrawColor(0,0,0,245)
                                surface.DrawLine(0,scrh/2,scrw,scrh/2)
                                surface.DrawLine(scrw/2,0,scrw/2,scrh)
                            end
                        end
                    end
                end
            else
                if estscope[curw:GetClass()] then
                    if curw:GetZoomLevel() == 0 then
                        scropeAlpha = math.Approach(scropeAlpha,128,FrameTime()*250)
                    end 
                    if curw:GetZoomLevel() == 2 then 
                        scropeAlpha = math.Approach(scropeAlpha,85,FrameTime()*250)
                    end
                    if curw:GetZoomLevel() == 1 then
                        scropeAlpha = math.Approach(scropeAlpha,0,FrameTime()*650)
                    end 
        
                    curw:SetZoomLevel( 1 )
                    curw:SetZoom( 0 )
        
                    surfaceTexture(scrw/2+5,scrh/2,scropeAlpha,2,"gui/gradient",fcolor)
                    surfaceTexture(scrw/2-5-scropeAlpha/2,scrh/2+1,scropeAlpha,2,"gui/gradient",fcolor,180)
                    surfaceTexture(scrw/2,scrh/2+5,2,scropeAlpha,"gui/gradient_down",fcolor)
                    surfaceTexture(scrw/2,scrh/2-5-scropeAlpha,2,scropeAlpha,"gui/gradient_up",fcolor)
                elseif curw:GetClass():StartWith("m9k_")  then
                    if me:KeyDown(IN_ATTACK2) and (!me:KeyDown(IN_SPEED) and !me:KeyDown(IN_USE)) then
                        scropeAlpha = math.Approach(scropeAlpha,128,FrameTime()*250)
                    else
                        scropeAlpha = math.Approach(scropeAlpha,0,FrameTime()*650)
                    end

                    curw:SetIronsights(false)

                    surfaceTexture(scrw/2+5,scrh/2,scropeAlpha,2,"gui/gradient",fcolor)
                    surfaceTexture(scrw/2-5-scropeAlpha/2,scrh/2+1,scropeAlpha,2,"gui/gradient",fcolor,180)
                    surfaceTexture(scrw/2,scrh/2+5,2,scropeAlpha,"gui/gradient_down",fcolor)
                    surfaceTexture(scrw/2,scrh/2-5-scropeAlpha,2,scropeAlpha,"gui/gradient_up",fcolor)
                end
            end
        end
    end

    
end

hook.Add("HUDPaint","indicators",basedGigaIlysha)

--skinchanger 
local drawoverlay = false
hook.Add("PreDrawViewModel", "predraw", function()
    local overlayCol = string.ToColor(cfg.Colors["viewmodel_wireframe"])
	if !me:Alive() then return end
	local gun = me:GetActiveWeapon():GetClass()
	if me:Alive() and me:GetActiveWeapon():GetClass() != nil then	
		if cfg.gunSkins[gun] then
            render.SetColorModulation(cfg.gunSkins[gun][4]/255,cfg.gunSkins[gun][5]/255,cfg.gunSkins[gun][6]/255)
			render.SetBlend(cfg.gunSkins[gun][7]/255)
            render.MaterialOverride(Material(cfg.gunSkins[gun][1]))
		else
            render.SetColorModulation(1,1,1)
			render.MaterialOverride(Material(""))
		end
		render.SetBlend(1)
	end
    if cfg.Misc["viewmodel_wireframe"] then
        render.SuppressEngineLighting(true)
        if drawoverlay then
            render.SetColorModulation(overlayCol.r, overlayCol.g, overlayCol.b)
            render.MaterialOverride(Material("!glowcham2"))
        else
            render.SetColorModulation(1, 1, 1)
        end
        render.SetBlend(1)
    end
end)
	
hook.Add("PostDrawViewModel", "Postdraw", function()
	render.SetColorModulation(1, 1, 1)
    render.MaterialOverride()
    render.SetBlend(1)
    render.SuppressEngineLighting(false)

    if drawoverlay then return end
 
    if cfg.Misc["viewmodel_wireframe"] then
        drawoverlay = true
        LocalPlayer():GetViewModel():DrawModel()
        drawoverlay = false
    end
end)

local isCanTrace = true
local function Trace()
	if (not isCanTrace) then
		return
	end
	isCanTrace = false
	index = 1
	indexF = index * .1
	trace = util.TraceEntity({
		start = LocalPlayer():GetPos(),
		endpos = physenv.GetGravity() * (0.5 * indexF * indexF) + LocalPlayer():GetVelocity() * indexF + LocalPlayer():GetPos(),
		filter = LocalPlayer()
	}, LocalPlayer())
	while (not trace.Hit) do
		render.DrawLine(trace.StartPos, trace.HitPos, Color(180, 155, 0), true)
		index = index + 1
		indexF = index * .1
		indexFN = index * .1 - .1
		trace = util.TraceEntity({
			start = physenv.GetGravity() * (0.5 * indexFN * indexFN) + LocalPlayer():GetVelocity() * indexFN + LocalPlayer():GetPos(),
			endpos = physenv.GetGravity() * (0.5 * indexF * indexF) + LocalPlayer():GetVelocity() * indexF + LocalPlayer():GetPos(),
			filter = LocalPlayer()
		}, LocalPlayer())
		if (index > 256) then
			break
		end
	end
	render.DrawLine(trace.StartPos, trace.HitPos, Color(255, 0, 0), true)
	isCanTrace = true
	return trace.HitPos
end
hook.Add("PostDrawTranslucentRenderables"or"TranslucentRenderables", "3434", function(bD, bS)
    if !cfg.Misc["fall_predict"] then return end
	if not LocalPlayer():IsOnGround() then 
		local pw = Trace()
		render.DrawWireframeBox(pw, Angle(), LocalPlayer():OBBMins(), LocalPlayer():OBBMaxs(), Color(0, 0, 0), true)
	end
end)

function FixMove(cmd, rotation)
	local rot_cos = math.cos(rotation)
	local rot_sin = math.sin(rotation)
	local cur_forwardmove = cmd:GetForwardMove()
	local cur_sidemove = cmd:GetSideMove()
	cmd:SetForwardMove(((rot_cos * cur_forwardmove) - (rot_sin * cur_sidemove)))
	cmd:SetSideMove(((rot_sin * cur_forwardmove) + (rot_cos * cur_sidemove)))
end

CircleStrafeSpeed = 3
function CircleStrafe(cmd) 
    if !IsValid(me) and !me:Alive() then return end
	if cfg.Movement["move_circle_strafe"] then
        if (input.IsKeyDown(cfg.Keybinds["key_cstrafe"])) then
            if hl2guns[me:GetActiveWeapon():GetClass()] then
                cmd:AddKey(IN_SPEED)
            elseif cfg.Movement["move_add_speed"] and target == nil then
                cmd:AddKey(IN_SPEED)
            end

            CircleStrafeVal = CircleStrafeVal + CircleStrafeSpeed
            if ((CircleStrafeVal > 0) and ((CircleStrafeVal / CircleStrafeSpeed) > 361)) then
                CircleStrafeVal = 0
            end
            FixMove(cmd, math.rad((CircleStrafeVal - engine.TickInterval())))
            return false
        else
            CircleStrafeVal = 0
        end
        return true
    end
end

nextact = 0
local act = "dance"

local acts = {
    "robot",
    "muscle",
    "laugh",
    "bow",
    "cheer",
    "wave",
    "becon",
    "agree",
    "disagree",
    "forward",
    "group",
    "half",
    "zombie",
    "dance",
    "pers",
    "halt",
    "salute",
}

--[[]
["misc_killsay"] = false,
["misc_chatspam_ar"] = false,
["misc_chatspam_lang"] = 1,
]]



gameevent.Listen("player_say")

hook.Add( "player_say", "player_say_example", function( data ) 
	local priority = SERVER and data.Priority or 1 	
	local id = data.userid				
	local text = data.text				

    if cfg.Misc["misc_chatspam_ar"] then
        if id != me:UserID() then
            local cmsg = chatSpam.ar[cfg.Misc["misc_chatspam_lang"]]
            local fmsg = cmsg[math.random(#cmsg)]

            RunConsoleCommand("say",fmsg)
        end
    end

end )


chatspamcd = 0

hook.Add("Think","xui",function()

    if cfg.Misc["misc_chatspam"] and CurTime() > chatspamcd then 
        local cmsg = chatSpam.spam[cfg.Misc["misc_chatspam_lang"]]
        local fmsg = cmsg[math.random(#cmsg)]

        RunConsoleCommand("say",fmsg)
        chatspamcd = CurTime() + cfg.Misc["misc_chatspam_timer"] 
    end

    if cfg.Ragebot["dance_spam"] and me:Alive() and !me:IsPlayingTaunt() and CurTime() > nextact then
        act = acts[cfg.Ragebot["dance_spam_act"]]

		RunConsoleCommand("act", act)
		nextact = CurTime() + 0.3
	end

    if input.IsKeyDown(KEY_DELETE) and !menukey then
        if IlyshaFrameTable.main_frame then
            CloseMainFrame()
            if IlyshaFrameTable.color_frame != false then
                IlyshaFrameTable.color_frame:Remove()
                IlyshaFrameTable.color_frame = false
            end
        else
            OpenGUI()
            RestoreCursorPosition()
            
        end
    end

	if cfg.Misc["misc_3rdp"] then
		if cfg.Keybinds["key_tp"] == 0 then 
			tperson = true
		elseif ( ( ( cfg.Keybinds["key_tp"] >= 107 && cfg.Keybinds["key_tp"] <= 113 ) && input.IsMouseDown(cfg.Keybinds["key_tp"] ) && !tperson_cd || input.IsKeyDown(cfg.Keybinds["key_tp"]) && !tperson_cd ) ) then
			tperson = !tperson
			tperson_cd = true
			timer.Simple(0.3, function() tperson_cd = false end)
		end
	end

    menukey = input.IsKeyDown(KEY_DELETE)
    
end)

--[[
hook.Add("HUDPaint","TrahnulChiteraVPopku",function()
    if IlyshaFrameTable.main_frame then
        if IlyshaFrameTable.aim_frame != false then
            local aimpx, aimpy = IlyshaFrameTable.aim_frame:GetPos()
            local aimpw, aimph = IlyshaFrameTable.aim_frame:GetSize()
            for i = 1,6 do
                draw.RoundedBox(4,aimpx-i,aimpy-i,aimpw+i*2,aimph+i*2,Color(0,0,0,45))
            end
        end
    end
end)
]]

--[[]
hook.Add("OnImpact", "kal", function(data)
    PrintTable(data)
end)

m_nDamageType	=	2
m_nEntIndex	=	10829824
m_targetHitbox	=	0
m_vAngles	=	0.000 0.000 0.000
m_vNormal	=	0.000000 0.000000 1.000000
m_vOrigin	=	-1694.387695 1920.890625 -0.125000
m_vStart	=	-1807.38867
]]

hook.Add("PreDrawPlayerHands", "RandomString()", function(hands, vm, ply, weapon)
	local hsv = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
    if cfg.Misc["misc_so2_hands"] then
        render.SetColorModulation(hsv.r/ 255,hsv.g/ 255,hsv.b/ 255)
        render.MaterialOverride(Material(""))
        render.SetBlend(0.9)
        --vm:DrawModel()
    end	
    --print(vm)
end)

local fakemodels = {}
local NewFakeModel, UpdateFakeModel

function NewFakeModel(ply, group)
	local model = ClientsideModel(ply:GetModel(), group)
	model:SetNoDraw(true)
	
	local data = {
		model = model,
		ply = ply
	}
	
	fakemodels[#fakemodels + 1] = data
	
	return data
end

local fakelagmodel = NewFakeModel(me, RENDERGROUP_TRANSLUCENT)
local realmodel = NewFakeModel(me, RENDERGROUP_OPAQUE)
local fakemodel = NewFakeModel(me, RENDERGROUP_OPAQUE)

local function CopyPoseParam(name, from, to)
	local min, max = to:GetPoseParameterRange(from:LookupPoseParameter(name))
	if min then
		to:SetPoseParameter(name, min + (max - min) * from:GetPoseParameter(name))
	end
end

function UpdateFakeModel(model, angles)
	local mdl = model.model
	local ply = model.ply
	
	local ang
	if angles then
		ang = angles
		
		mdl:SetPoseParameter("aim_pitch", ang.p)
		mdl:SetPoseParameter("head_pitch", ang.p)
		mdl:SetPoseParameter("body_yaw", ang.y)
		mdl:SetPoseParameter("aim_yaw", 0)
		
		-- Fix legs
		local velocity = ply:GetVelocity()
		local velocityYaw = mNormalizeAng(ang.y - math.deg(math.atan2(velocity.y, velocity.x)))
		local playbackRate = ply:GetPlaybackRate()
		local moveX = math.cos(math.rad(velocityYaw)) * playbackRate
		local moveY = -math.sin(math.rad(velocityYaw)) * playbackRate
		
		mdl:SetPoseParameter("move_x", moveX)
		mdl:SetPoseParameter("move_y", moveY)
    else
        ang = Angle(0, 0, 0)

        for i = 0, ply:GetNumPoseParameters() - 1 do
			local name = ply:GetPoseParameterName(i)
			CopyPoseParam(name, ply, mdl)
		end
    end
	
    mdl:SetModel(me:GetModel())

	mdl:SetPos(ply:GetPos())
	
	mdl:SetAngles(Angle(0, ang.y, 0))
	
	mdl:SetCycle(ply:GetCycle())
	mdl:SetSequence(ply:GetSequence())
	
	mdl:InvalidateBoneCache()

end

local chamsmat = CreateMaterial("SWBaseChams", "VertexLitGeneric", {
	["$basetexture"] = "color/white",
	["$model"] = 1
})

local chamsmat_transparent = CreateMaterial("SWBaseChams_transparent", "VertexLitGeneric", {
	["$basetexture"] = "color/white",
	["$model"] = 1,
	["$translucent"] = 1,
	["$vertexalpha"] = 1,
	["$vertexcolor"] = 1
})

gameevent.Listen( "player_spawn" )
hook.Add( "player_spawn", "player_spawn_example", function( data ) 
	local id = data.userid	
    if id == me:UserID() then
        fakelagmodel = NewFakeModel(me, RENDERGROUP_TRANSLUCENT)
        realmodel = NewFakeModel(me, RENDERGROUP_OPAQUE)
        fakemodel = NewFakeModel(me, RENDERGROUP_OPAQUE)
    end
end )

local fchams, fkchams,rlchams

hook.Add("PostDrawOpaqueRenderables", "fakeAngleChams", function() 
    local fakeanglecolor = string.ToColor(cfg.Colors["fake_chams"])
    local realanglecolor = string.ToColor(cfg.Colors["real_chams"])

    if cfg.ESP["fake_chams_m"] == 1 then
        fchams = "!flat"
    elseif cfg.ESP["fake_chams_m"] == 2 then
        fchams = "!textured"
    elseif cfg.ESP["fake_chams_m"] == 3 then
        fchams = "models/shiny"
    elseif cfg.ESP["fake_chams_m"] == 4 then
        fchams = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["fake_chams_m"] == 5 then
        fchams = "models/wireframe"
    end

    if cfg.ESP["real_chams_m"] == 1 then
        rlchams = "!flat"
    elseif cfg.ESP["real_chams_m"] == 2 then
        rlchams = "!textured"
    elseif cfg.ESP["real_chams_m"] == 3 then
        rlchams = "models/shiny"
    elseif cfg.ESP["real_chams_m"] == 4 then
        rlchams = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["real_chams_m"] == 5 then
        rlchams = "models/wireframe"
    end

    if cfg.ESP["fakelag_chams_m"] == 1 then
        fkchams = "!flat"
    elseif cfg.ESP["fakelag_chams_m"] == 2 then
        fkchams = "!textured"
    elseif cfg.ESP["fakelag_chams_m"] == 3 then
        fkchams = "models/shiny"
    elseif cfg.ESP["fakelag_chams_m"] == 4 then
        fkchams = "models/props_combine/health_charger_glass"
    elseif cfg.ESP["fakelag_chams_m"] == 5 then
        fkchams = "models/wireframe"
    end

	if tpsmooth > 0 then
        if cfg.Ragebot["antiaim_enable"] then
            UpdateFakeModel(fakemodel, vFakeAngles)
            UpdateFakeModel(realmodel, vRealAngles)
            

            local rl = realmodel.model
            local fk = fakemodel.model

            if cfg.Ragebot["real_chams"] then
                render.MaterialOverride(Material(rlchams))
                render.SetBlend(realanglecolor.a/255)
                render.SetColorModulation(realanglecolor.r/255, realanglecolor.g/255, realanglecolor.b/255)
                rl:DrawModel()
            end
            if cfg.Ragebot["fake_chams"] then
                render.MaterialOverride(Material(fchams))
                render.SetBlend(fakeanglecolor.a/255)
                render.SetColorModulation(fakeanglecolor.r/255, fakeanglecolor.g/255, fakeanglecolor.b/255)
                fk:DrawModel()
            end
            
            render.MaterialOverride()
            me:DrawViewModel( false )
        end
    else
        me:DrawViewModel( true )
    end
end)

hook.Add("PostDrawTranslucentRenderables", "fakeLagChams", function()
    local fakelahchamscolor = string.ToColor(cfg.Colors["fakelag_chams"])

	if bsendpacket then
		UpdateFakeModel(fakelagmodel)
	end

	if tpsmooth > 0 then
        if cfg.Ragebot["fakelag_enable"] and cfg.Ragebot["fakelag_chams"] and LocalPlayer():GetVelocity():Length() > 50 then
		    render.MaterialOverride(Material(fkchams))
            render.SetBlend(fakelahchamscolor.a/255)
		    render.SetColorModulation(fakelahchamscolor.r/255, fakelahchamscolor.g/255, fakelahchamscolor.b/255)
		    fakelagmodel.model:DrawModel()
        end
	end
	
	render.MaterialOverride()
end)

local playerTable = {}

hook.Add("Think", "playertable", function()
	for k, v in pairs(player.GetAll()) do
		if v != nil and v != me and v:Alive() and !v:IsDormant() and v:IsPlayer() or v:IsBot() && !table.HasValue(playerTable, v) then
			playerTable[v] = v
		elseif v == nil or v == me or !v:Alive() or v:IsDormant() or !v:IsPlayer() or !v:IsBot() && table.HasValue(playerTable, v) then
			table.RemoveByValue(playerTable, v)
		end
	end
end)

hook.Add("PreDrawHalos", "GlowESP", function()
	if cfg.ESP["glow_esp"] then
		halo.Add(playerTable,string.ToColor(cfg.Colors["glow_esp"]),2,2,2,cfg.ESP["glow_esp_a"],true)
	end
    if cfg.ESP["glow_esp_att"] then
        for k,v in next, player.GetAll() do
            if v != nil and v != me and v:Alive() and !v:IsDormant() and v:IsPlayer() or v:IsBot() and v:GetActiveWeapon() != nil then
                local hisGun = v:GetActiveWeapon()
                halo.Add({hisGun},string.ToColor(cfg.Colors["glow_esp"]),2,2,2,cfg.ESP["glow_esp_a"],true)
            end
        end
    end
end)

--FindMetaTable("Player").FinishMove = function() end
--FindMetaTable("Player").FinishMove = function() end

function GAMEMODE:CreateMove( cmd )
    return true 
end

function GAMEMODE:CalcView( view )
    return true 
end

hook.Add("PrePlayerDraw", "act", function(ply)
	if ply != me then
        ply.ChatGestureWeight = 0
		for i = 0, 13 do
			if ply:IsValidLayer(i) then
				local seqname = ply:GetSequenceName(ply:GetLayerSequence(i))
				if seqname:StartWith("taunt_") or seqname:StartWith("act_") or seqname:StartWith("gesture_") then
					ply:SetLayerDuration(i, 0.001)
					break
				end
			end
		end
	end

    if cfg.Ragebot["antiaim_enable"] and ply == me then
        if cfg.Ragebot["real_chams"] or cfg.Ragebot["fake_chams"] then
		    return true
        elseif me:IsPlayingTaunt() and tpsmooth == 0 then
            return true
        end
	end
    
    if cfg.Aimbot["aimbot_resolver"] then 
        StepResolver(ply,cfg.Aimbot["aimbot_resolver_step"])
    end
    
end)

DisableWorldModulation()
DisablePropModulation()

AddConsoleMessage("Fully loaded!",Color(255,244,145))

