--[[
	autorun/client/BESTSERVER2011.lua
	xXN00B_DECIMAT0RXx | (STEAM_0:1:43911188)
	===DStream===
]]

--[[
	=== Hades ESP / Wallhack ===
	Ripped & fixed by HeX
]]


local STYLE_WIREFRAME	= 1
local STYLE_SKELETON	= 2
local STYLE_FULLBRIGHT	= 3
local STYLE_TEAMCOLOR	= 4
--local STYLE_L4D			= 5 --Doesn't have code for this..

local Draw_Style			= CreateClientConVar("esp_draw_style", 			2, true, true)

local Enabled				= CreateClientConVar("esp_enabled",				1, true, true)
local Draw_Players			= CreateClientConVar("esp_draw_players", 		1, true, true)
local NoDraw_Players		= CreateClientConVar("esp_nodraw_players", 		0, true, true)
local Draw_Box_Projectile	= CreateClientConVar("esp_draw_box_projectile", 0, true, true)
local Draw_Dead				= CreateClientConVar("esp_draw_dead", 			0, true, true)
local Draw_Team				= CreateClientConVar("esp_draw_team", 			1, true, true)
local Draw_Reticle			= CreateClientConVar("esp_draw_reticle", 		0, true, true)
local Draw_Deathrun_Hax		= CreateClientConVar("esp_draw_deathrun_hax", 	0, true, true)
local S_Light				= CreateClientConVar("esp_s_light", 			0, true, true)
local Draw_Info_Name		= CreateClientConVar("esp_draw_info_name", 		1, true, true)
local Draw_Info_Health		= CreateClientConVar("esp_draw_info_health", 	1, true, true)
local Draw_Info_Weapon		= CreateClientConVar("esp_draw_info_weapon", 	1, true, true)
CreateClientConVar("Vis_Barrel_red",255)
CreateClientConVar("Vis_Barrel_green",255)
CreateClientConVar("vis_Barrel_blue",255)
local red = GetConVarNumber("Vis_Barrel_red")
local green = GetConVarNumber("Vis_Barrel_red")
local blue = GetConVarNumber("Vis_Barrel_blue")



local colPlayer = Color( 255, 255, 255 )
local colEntity = Color( 255, 0, 0 )
local colShadow = Color( 40, 40, 40 )
local white = Color( 255, 255, 255 )



local Projectiles = {
	"rpg_missile",
	"crossbow_bolt",
	"npc_grenade_frag",
	"grenade_ar2",
	"prop_combine_ball",
	"npc_satchel",
}

local Deathrun_Hax = {
	"func_door",
	"func_door_rotating",
	"func_movelinear",
	"func_rotating",
	"func_illusionary",
	"ent_laser",
}


local _bones = {
	{ "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
}

local function GetBonePos( ply, bone )
	return ply:GetBonePosition( ply:LookupBone( bone ) )
end

local function GetBoneScreenPos( ply, bone )
	return GetBonePos( ply, bone ):ToScreen()
end

local function Filter( ply )
	return (
		( ply:Alive() or Draw_Dead:GetBool() ) and
		( ply:Team() != LocalPlayer():Team() or Draw_Team:GetBool() )
	)
end

local function GetDrawAlpha( ply )
	local dist = LocalPlayer():GetPos():Distance( ply:GetPos() )
	return math.Clamp( 255/(dist/1000), 0, 255 )
end

local function GetDrawColor( ply )
	local t = ply:Team()
	local col = team.GetColor( t ) or colPlayer
	
	col.a = GetDrawAlpha( ply )

	return col
end



--[[
--		ESP
--]]
local function DrawHealthBar( fr, x, y, w, h, a )
	x = (x - (w/2))
	--Draw bar
	surface.SetDrawColor( 80, 255, 80, a )
	surface.DrawRect( x+1, y+1, (w*fr)-2, h-2 )
	--Draw background
	surface.SetDrawColor( 180, 180, 180, a/2 )
	surface.DrawRect( x, y, w, h )
	--Draw shadow
	local col = colShadow
	surface.SetDrawColor( col.r, col.g, col.b, a )
    surface.DrawOutlinedRect( x, y, w, h)
end


function DrawPlayerInfo( ply, bone )
	local pos = GetBonePos( ply, bone )
	
	local col = Color( 255, 255, 255 )
	
	local shadow = colShadow
	shadow.a = GetDrawAlpha( ply )
	
	if Draw_Info_Name:GetBool() then
		local namePos = pos:ToScreen()
		draw.SimpleTextOutlined(
			ply:Name(),		--Text
			"default",			--Font
			namePos.x,				--X coordinate
			namePos.y,				--Y coordinate
			col,				--Color
			TEXT_ALIGN_CENTER,	--Text horiz. align
			TEXT_ALIGN_CENTER,	--Text vert. align
			1,					--Shadow offset in px
			shadow				--Shadow colour
		)
	end
	
	if Draw_Info_Health:GetBool() then
		local barPos = pos:ToScreen()
		barPos.y = barPos.y + 7
		DrawHealthBar(
			math.Clamp( ply:Health()/100, 0, 1 ),			--Fraction
			barPos.x,			--X coordinate
			barPos.y,		--Y coordinate
			50,			--Width
			10,				--Height
			GetDrawAlpha( ply )
		)
	end
	
	if Draw_Info_Weapon:GetBool() then
		local weaponPos = pos:ToScreen()
		weaponPos.y = weaponPos.y + 23
		
		local weapon = ply:GetActiveWeapon()
		if not weapon or not weapon:IsValid() then return end
		
		local text = weapon:GetPrintName()
		draw.SimpleTextOutlined(
			text,		--Text
			"default",			--Font
			weaponPos.x,		--X coordinate
			weaponPos.y,		--Y coordinate
			col,				--Color
			TEXT_ALIGN_CENTER,	--Text horiz. align
			TEXT_ALIGN_CENTER,	--Text vert. align
			1,					--Shadow offset in px
			shadow				--Shadow colour
		)
	end
end


local _mats = {}

local function AddMaterial( name, base, shader )
	if !shader then shader = "VertexLitGeneric" end
	name = name:lower()
	
	local mat = CreateMaterial("hades_"..name, shader, {
		["$basetexture"] = base,
		["$ignorez"] = 1
	})
	_mats[name] = mat
end

AddMaterial("solid", "models/debug/debugwhite")
AddMaterial("wireframe", "models/wireframe", "Wireframe")




local function Draw(ent, r, g, b, a)
	render.SetColorModulation(r / 255, g / 255, b / 255)
	render.SetBlend(a / 255)
	
	ent:DrawModel()
end

local function DrawMaterialStuff( style )
	render.SuppressEngineLighting( true )
	cam.Start3D( EyePos(), EyeAngles() )
	pcall( function()
		local mat = _mats.wireframe
		if style == STYLE_TEAMCOLOR then
			mat = _mats.solid
		elseif style == STYLE_FULLBRIGHT then
			mat = nil
		end
		cam.IgnoreZ( true )
		SetMaterialOverride( mat )
		for k,v in pairs( player.GetAll() ) do
			if not Filter( v ) then
				SetMaterialOverride( nil )
				cam.IgnoreZ( false )
				render.SuppressEngineLighting( false )
				
				v:DrawModel()
				
				render.SuppressEngineLighting( true )
				cam.IgnoreZ( true )
				SetMaterialOverride( mat )
			else
				local clr = (style == STYLE_FULLBRIGHT or style == STYLE_WIREFRAME) and white or GetDrawColor( v )
				Draw( v, clr.r, clr.g, clr.b, 255 )
			end
		end
		SetMaterialOverride( nil )
		cam.IgnoreZ( false )
	end )
	cam.End3D()
	render.SuppressEngineLighting( false )
end


--[[
--		SKELETON
--]]
local function DrawSkeleton( ply )
	for _,t in ipairs( _bones ) do
		pos1 = GetBoneScreenPos( ply, t[1] )
		pos2 = GetBoneScreenPos( ply, t[2] )
		surface.DrawLine( pos1.x, pos1.y, pos2.x, pos2.y )
	end
end

local function DrawPlayers()
	local style = Draw_Style:GetInt()
	
	if style == STYLE_WIREFRAME or style == STYLE_FULLBRIGHT or style == STYLE_TEAMCOLOR then
		DrawMaterialStuff( style )
	end
end


local function DrawPlayer( ent )
	if not Filter( ent ) then
		ent:SetRenderMode( RENDERMODE_NORMAL )
		return
	end
	
	if NoDraw_Players:GetBool() then
		ent:SetRenderMode( RENDERMODE_NONE )
	else
		ent:SetRenderMode( RENDERMODE_NORMAL )
	end
	
	local col = GetDrawColor( ent )
	surface.SetDrawColor( col.r, col.g, col.b, col.a )
	
	if Draw_Style:GetInt() == STYLE_SKELETON then
		DrawSkeleton( ent )
	end
	
	DrawPlayerInfo( ent, "ValveBiped.Bip01_Pelvis" )
end




local function DrawBox( ply )
	local center = ply:LocalToWorld( ply:OBBCenter() )
	local min,max = ply:WorldSpaceAABB()
	local dim = max - min
			
	local front = ply:GetForward()*(dim.y/2)
	local right = ply:GetRight()*(dim.x/2)
	local top = ply:GetUp()*(dim.z/2)
	local back = (ply:GetForward()*-1)*(dim.y/2)
	local left = (ply:GetRight()*-1)*(dim.x/2)
	local bottom = (ply:GetUp()*-1)*(dim.z/2)
	local FRT = center+front+right+top
	local BLB = center+back+left+bottom
	local FLT = center+front+left+top
	local BRT = center+back+right+top
	local BLT = center+back+left+top
	local FRB = center+front+right+bottom
	local FLB = center+front+left+bottom
	local BRB = center+back+right+bottom
			
	FRT = FRT:ToScreen()
	BLB = BLB:ToScreen()
	FLT = FLT:ToScreen()
	BRT = BRT:ToScreen()
	BLT = BLT:ToScreen()
	FRB = FRB:ToScreen()
	FLB = FLB:ToScreen()
	BRB = BRB:ToScreen()
	
	local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	
	surface.SetDrawColor( 255, 0, 0, 255 )
	
	surface.DrawLine( xmax, ymax, xmax, ymin )
	surface.DrawLine( xmax, ymin, xmin, ymin )
	surface.DrawLine( xmin, ymin, xmin, ymax )
	surface.DrawLine( xmin, ymax, xmax, ymax )
end



local function FixedESP_HUDPaint()
	if Draw_Box_Projectile:GetBool() then
		for _, ent in pairs( ents.GetAll() ) do
			for k, v in pairs( Projectiles ) do
				if ent:GetClass():lower():find( v ) then
					DrawBox( ent )
				end
			end
		end
	end
	
	if Draw_Deathrun_Hax:GetBool() then
		for _, ent in pairs( ents.GetAll() ) do
			for k, v in pairs( Deathrun_Hax ) do
				if ent:GetClass():lower():find( v ) then
					DrawBox( ent )
				end
			end
		end
	end
end
hook.Add("HUDPaint", "FixedESP_HUDPaint", FixedESP_HUDPaint)



local function FixedESP_POR()
	if not Draw_Reticle:GetBool() then return end
	
	local tr = LocalPlayer():GetEyeTrace()
	local Pos,Normal = tr.HitPos, tr.HitNormal
	
	Pos = Pos + Normal
	
	cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( Material( "sprites/reticle" ) )
		render.DrawQuadEasy( Pos, Normal, 64, 64, Color( 255, 255, 255, 255 ) )
	cam.End3D()
end
hook.Add("PostDrawOpaqueRenderables", "FixedESP_POR", FixedESP_POR)



local function FixedESP_RSE()
	if S_Light:GetBool() then
		render.SuppressEngineLighting( true )
	else
		render.SuppressEngineLighting( false )
	end
	
	if not Enabled:GetBool() then return end
	
	if Draw_Players:GetBool() then
		DrawPlayers()
	end
	
	for _,ent in ipairs( ents.GetAll() ) do
		if ent and IsValid( ent ) and ent != LocalPlayer() then
			if ent:IsPlayer() and Draw_Players:GetBool() then
				DrawPlayer( ent )
			end
		end
	end
end
local function LaserMat()
	local info = {
		["$basetexture"]	= "sprites/laser",
		["$additive"]		= 1,
		["$translucent"]	= 1,
		["$vertexcolor"]	= 1
	}
	
	local matt = CreateMaterial('Lazzzer', "UnlitGeneric", info )
	return matt
end




CreateClientConVar('Vis_Barrel',0,true,false)
	if GetConVarNumber('Vis_Barrel') == 1 then
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v) && v:Team() != TEAM_SPECTATOR && v:Alive() && v:GetMoveType() != MOVETYPE_OBSERVER then
				cam.Start3D(EyePos() ,EyeAngles())
					render.SetMaterial(LaserMat())
					render.DrawBeam(v:GetAttachment(v:LookupAttachment('eyes')).Pos, v:GetEyeTrace().HitPos, 5, 0, 0, Color(red,green,blue))
				cam.End3D()
			end
		end
	end


hook.Add("RenderScreenspaceEffects", "FixedESP_RSE", FixedESP_RSE)
