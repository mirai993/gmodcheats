--[[
	MOD/lua/nai.lua
	псевдоник | STEAM_0:0:19009910 <95.221.235.217:27005> | [24-11-13 10:03:15AM]
	===BadFile===
]]

surface.CreateFont("ElebotPlayerTitle", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})
surface.CreateFont("ElebotPlayerInfo", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})
local target = nil;
 
if (cmdStr != nil and cmdStr != NULL) then
        concommand.Remove("+"..cmdStr)
        concommand.Remove("-"..cmdStr)
end
 
local cmdStr = "elebot"
local offset = CreateClientConVar(cmdStr.."_offset", 24, true, false)
local targetTeam = CreateClientConVar(cmdStr.."_targetteam", 0, true, false)
local simpleColors = CreateClientConVar(cmdStr.."_simplecolors", 1, true, false)
local maxView = CreateClientConVar(cmdStr.."_maxview", 4800, true, false)
local minView = CreateClientConVar(cmdStr.."_minview", 120, true, false)
local boxSize = CreateClientConVar(cmdStr.."_boxsize", 10, true, false)
local filledBox = CreateClientConVar(cmdStr.."_filledbox", 0, true, false)
local showAdmin = CreateClientConVar(cmdStr.."_showadmin", 1, true, false)
local shouldESP = CreateClientConVar(cmdStr.."_esp", 1, true, false)
local filterProps = CreateClientConVar(cmdStr.."_xray", 1, true, false)
local function TrackTarget(ucmd)
        if !target or !IsValid(target) then
 
                local filterTable = {LocalPlayer()}
               
                if (filterProps:GetBool()) then
                        if (ents.GetAll()[1]:IsWorld()) then
                                print("World found!")
                                table.insert(filterTable, ents.GetAll()[1])
                        end
                        for k,v in pairs (ents.GetAll()) do
                                if !(v:IsNPC() or v:IsPlayer()) then
                                        table.insert(filterTable, v)
                                end
                        end
                end
               
                /*
                if (ents.FindByClass("worldspawn") != nil) then
                        print("Found world entity!")
                        table.insert(filterTable, ents.FindByClass("worldspawn")[1])
                end
                */
               
               
                local trace = util.QuickTrace(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector() * 100000, filterTable)
               
                /*
                local traceTable = {start = LocalPlayer():GetShootPos(), endpos = LocalPlayer():GetAimVector() * 10000, filter = filterTable}
               
                local trace = util.TraceLine(traceTable)
                */
                /*
                if (trace.Entity and IsValid(trace.Entity) and trace.Entity:IsValid() and (trace.Entity:IsPlayer() or trace.Entity:IsNPC())) then
                        if trace.Entity:IsPlayer() and !targetTeam:GetBool() and trace.Entity:Team() == LocalPlayer():Team() then
                                return
                        else
                                target = trace.Entity
                        end
                else
                        return
                end
                */
               
                if (trace.Entity and IsValid(trace.Entity)) then
                        if (trace.Entity:IsPlayer()) then
                                if !targetTeam:GetBool() and trace.Entity:Team() == LocalPlayer():Team() then
                                        return
                                else
                                        target = trace.Entity
                                end
                        else
                                if (trace.Entity:IsNPC()) then
                                        target = trace.Entity
                                else
                                        return
                                end
                        end
                else
                        return
                end
        end
       
        /*
        if (target:OBBMaxs().z < offset:GetFloat() or string.find(target:GetModel(), "crab") or string.find(target:GetModel(), "torso")) then
                ucmd:SetViewAngles((target:GetPos() + Vector(0, 0, target:OBBMaxs().z * 0.25) - LocalPlayer():GetShootPos()):Angle())
        else
                ucmd:SetViewAngles((target:GetPos() + Vector(0, 0, offset:GetFloat()) - LocalPlayer():GetShootPos()):Angle())
        end
        */
        if (target:GetAttachment(target:LookupAttachment("eyes"))) then //Standard
                ucmd:SetViewAngles((target:GetAttachment(target:LookupAttachment("eyes")).Pos - LocalPlayer():GetShootPos()):Angle())
                //print((target:GetAttachment(target:LookupAttachment("eyes")).Pos - LocalPlayer():GetShootPos()))
        elseif (target:GetAttachment(target:LookupAttachment("forward"))) then //CSS models
                ucmd:SetViewAngles((target:GetAttachment(target:LookupAttachment("forward")).Pos - LocalPlayer():GetShootPos()):Angle())
                print( LocalPlayer():GetShootPos() )
        elseif (target:GetAttachment(target:LookupAttachment("head"))) then //Zombies
                ucmd:SetViewAngles((target:GetAttachment(target:LookupAttachment("head")).Pos - LocalPlayer():GetShootPos()):Angle())
                print( LocalPlayer():GetShootPos() )
        else //Headcrabs, antlions, etc.
                ucmd:SetViewAngles((target:GetPos() + Vector(0, 0, offset:GetFloat()) - LocalPlayer():GetShootPos()):Angle())
                print( LocalPlayer():GetShootPos() )
        end
end
 
local function PaintTargets()
        if (!shouldESP:GetBool()) then return end
        local adminList = "";
        for k,v in pairs (ents.GetAll()) do
                if v:IsNPC() then
                        local pos = (v:GetPos() + Vector(0, 0, offset:GetFloat())):ToScreen()
                       
                        if v:OBBMaxs().z < offset:GetFloat() then
                                pos = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.25)):ToScreen()
                        end
                       
                        if (pos.visible) then
                                local alpha = math.Clamp((maxView:GetFloat() - v:GetPos():Distance(LocalPlayer():GetShootPos())) * (255 / (maxView:GetFloat() - minView:GetFloat())), 30, 255)
                                draw.SimpleText(string.gsub(v:GetClass(), "npc_", ""), "ElebotPlayerTitle",  pos.x, pos.y, Color(0, 255, 0, alpha), 1, 1)
                                local boxCenter = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z)):ToScreen()
                                local bL = boxSize:GetFloat()
                                if (filledBox:GetBool() && bL != 0) then
                                        draw.RoundedBox(1, boxCenter.x - bL, boxCenter.y - bL, bL * 2, bL * 2, Color(0, 255, 0, alpha))
                                else
                                        if (!filledBox:GetBool() && bL != 0) then
                                                local bL = boxSize:GetFloat()
                                                surface.SetDrawColor(0, 255, 0, alpha)
                                                surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x - bL, boxCenter.y - bL) //Left vertical
                                                surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x + bL, boxCenter.y + bL) //Bottom horizontal
                                                surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x - bL, boxCenter.y - bL) // Top horizontal
                                                surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x + bL, boxCenter.y + bL) //Right vertical
                                        end
                                end
                        end
                else
                        if v:IsPlayer() then
                                local pos = (v:GetPos() + Vector(0, 0, offset:GetFloat())):ToScreen()
                               
                                if string.find(v:GetModel(), "crab") or string.find(v:GetModel(), "torso") then
                                        pos = (v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.25)):ToScreen()
                                end
                               
                                if (pos.visible and v != LocalPlayer() and v.Nick and v.Health and v.GetActiveWeapon and v:GetActiveWeapon().GetPrintName) then
                                        local alpha = math.Clamp((maxView:GetFloat() - v:GetPos():Distance(LocalPlayer():GetShootPos())) * (255 / (maxView:GetFloat() - minView:GetFloat())), 30, 255)
                                        local tcol// = team.GetColor(v:Team())
                                        if (simpleColors:GetBool()) then
                                                if (v:Team() == LocalPlayer():Team()) then
                                                        tcol = Color(0, 255, 0, alpha)
                                                else
                                                        tcol = Color(255, 0, 0, alpha)
                                                end
                                        else
                                                tcol = team.GetColor(v:Team())
                                                tcol = Color(tcol.r, tcol.g, tcol.b, alpha)
                                        end
                                       
                                        draw.SimpleText(v:Nick(), "ElebotPlayerTitle", pos.x, pos.y, tcol, 1, 1)
                                        draw.SimpleText("HP: "..v:Health(), "ElebotPlayerInfo", pos.x, pos.y + 25, tcol, 1, 1)
                                        draw.SimpleText("Weapon: "..v:GetActiveWeapon():GetPrintName(), "ElebotPlayerInfo", pos.x, pos.y + 38, tcol, 1, 1)
                                        local boxCenter = ((v:GetPos() + Vector(0, 0, v:OBBMaxs().z * 0.9))):ToScreen()
                                        local bL = boxSize:GetFloat()
                                        if (filledBox:GetBool() && bL != 0) then
                                                draw.RoundedBox(1, boxCenter.x - bL, boxCenter.y - bL, bL * 2, bL * 2, tcol)
                                        else
                                                if (!filledBox:GetBool() && bL != 0) then
                                                        surface.SetDrawColor(tcol.r, tcol.g, tcol.b, alpha)
                                                        surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x - bL, boxCenter.y - bL) //Left vertical
                                                        surface.DrawLine(boxCenter.x - bL, boxCenter.y + bL, boxCenter.x + bL, boxCenter.y + bL) //Bottom horizontal
                                                        surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x - bL, boxCenter.y - bL) // Top horizontal
                                                        surface.DrawLine(boxCenter.x + bL, boxCenter.y - bL, boxCenter.x + bL, boxCenter.y + bL) //Right vertical
                                                end
                                        end
                                end
                               
                                if v:IsAdmin() or v:IsSuperAdmin() then
                                        adminList = adminList..", "..v:Nick()
                                end
 
                               
                        end
                end
        end
       
        if (showAdmin:GetBool()) then
                if (adminList != "") then
                        adminList = string.sub(adminList, 3, string.len(adminList))
                        draw.SimpleText("Admins: "..adminList, "ElebotPlayerInfo", ScrW() * 0.8, ScrH() * 0.2, Color(0, 255, 0, 200), 1, 1)
                else
                        draw.SimpleText("Sem ADMS online!", "ElebotPlayerInfo", ScrW() * 0.8, ScrH() * 0.2, Color(255, 0, 0, 200), 1, 1)
                end
        end
end
hook.Add("HUDPaint", "PaintTargets", PaintTargets)
 
 
local function AimbotOn(ply, cmd, args)
        hook.Add("CreateMove", "TrackTarget", TrackTarget)
end
concommand.Add("+"..cmdStr, AimbotOn)
 
local function AimbotOff(ply, cmd, args)
        target = nil
        hook.Remove("CreateMove", "TrackTarget")
end
concommand.Add("-"..cmdStr, AimbotOff)
 
 
 
 
LocalPlayer():ChatPrint("Traitor Finder Loaded")
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
 
for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end
 
 
hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _, v in pairs( ents.GetAll() ) do
                                if ( v:IsWeapon() and v.CanBuy and IsValid( v:GetOwner() ) and v:GetOwner():IsPlayer() and !v.HatESPTracked) then
                                                local owner = v:GetOwner();
                        if owner and IsValid(owner) and owner:IsTerror() then
                                if owner:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        owner.HatTraitor = true
                                        chat.AddText( owner, Color(255,125,0), " is ",Color(255,0,0), "TRAITOR!")
                                end
                        end
                end
        end
         
 
 
end)