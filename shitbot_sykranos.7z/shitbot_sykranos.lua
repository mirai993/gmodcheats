/*
	wtf !! [ STEAM_0:0:40143824 | 65.30.50.13:27005 ]
	lua/ShitBot.lua
*/

if( !CLIENT ) then return; end
if( _G["Shitbot"] ) then _G["Shitbot"] = nil; end

local CreateClientConVar = CreateClientConVar;
local Shitbot = {};
Shitbot["ConVars"] = {
	["aim_admins"] = CreateClientConVar( "aim_admins", 0, true );
	["aim_auto"] = CreateClientConVar( "aim_auto", 0, true );
	["aim_friendly"] = CreateClientConVar( "aim_friendly", 0, true );
	["aim_offset"] = CreateClientConVar( "aim_offset", 0, true );
	["aim_prediction"] = CreateClientConVar( "aim_prediction", 0, true );
	["aim_steam"] = CreateClientConVar( "aim_steam", 0, true );
	["esp_crosshair"] = CreateClientConVar( "esp_crosshair", 0, true );
	["esp_enabled"] = CreateClientConVar( "esp_enabled", 0, true );
	["esp_ents"] = CreateClientConVar( "esp_ents", 0, true );
	["vis_barrel"] = CreateClientConVar( "vis_barrel", 0, true );
	["vis_chams"] = CreateClientConVar( "vis_chams", 0, true );
	["vis_xqz"] = CreateClientConVar( "vis_xqz", 0, true );
};
Shitbot["Copy"] = { //wtf !!
	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["draw"] = draw,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["IsValid"] = IsValid,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["render"] = render,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["Color"] = Color,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["RealFrameTime"] = RealFrameTime,
};
Shitbot["Hooks"] = {};

Shitbot["Locked"] = false;
Shitbot["Version"] = "1.0";

Shitbot["Copy"]["MsgN"]( [[

]] )

local function GetUpdates( New_Version ) //Ghetto update checker.
chat.AddText(Color(255,0,0),"fuck you")
end


function Shitbot:Hook( type, func ) //Generic hooking system. Random hook names. If the hook breaks, you're shit out of luck.
	local Name = Shitbot["Copy"]["tostring"]( Shitbot["Copy"]["math"]["random"]( 1, 150 ) );
	Shitbot["Copy"]["MsgN"]( "Adding Hook "..Name.." ["..type.."]" );
	Shitbot["Copy"]["table"]["insert"]( Shitbot["Hooks"], Name );
	return Shitbot["Copy"]["hook"]["Add"]( type, Name, func );
end

surface.CreateFont("ESPFont",{font = "coolvetica", size = 12, weight = 100, antialias = 1})

local Aimspots = {
	"head",
	"forward",
	"eyes"
};

local function Aimspot( e )
	local Pos;
	for k, v in Shitbot["Copy"]["pairs"]( Aimspots ) do
		if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
			Pos = e:GetAttachment( e:LookupAttachment( v ) )["Pos"];
		end
	end
	return Pos;
end

local function bIsVisible( e )
	local Trace = {};
	Trace.start = Shitbot["Copy"]["LocalPlayer"]():GetShootPos();
	Trace.endpos = Aimspot( e );
	Trace.mask = MASK_SHOT,CONTENTS_HITBOX;
	Trace.filter = e, Shitbot["Copy"]["LocalPlayer"]();
	local tr = Shitbot["Copy"]["util"]["TraceLine"]( Trace );
	if( tr.Fraction == 1.0 ) then
		return true;
	end
end

local function bIsValid( e )
	if( !Shitbot["Copy"]["IsValid"]( e ) || e == Shitbot["Copy"]["LocalPlayer"]() ) then return false; end
	if( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then return false; end
	if( Shitbot["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then return false; end //Noclip glitchers are gay as penis, no?
	if( Shitbot["ConVars"]["aim_friendly"]:GetInt() == 0 && e:Team() == Shitbot["Copy"]["LocalPlayer"]():Team() ) then return false; end
	if( Shitbot["ConVars"]["aim_steam"]:GetBool() && e:GetFriendStatus() == "friend" ) then return false; end
	if( Shitbot["ConVars"]["aim_admins"]:GetInt() == 0 && e:IsAdmin() ) then return false; end
	if( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then return false; end
	return true;
end

local function GetTargets()
	local Targets = {0,0};
	for k, v in pairs(player.GetAll()) do
		if( bIsVisible( v ) && bIsValid( v ) ) then
			local Diff = ( v:EyePos() - LocalPlayer():EyePos() ):Normalize();
			Diff = Diff - LocalPlayer():GetAimVector();
			Diff = Diff:Length();
			Diff = math.abs( Diff );
			if( Diff < Targets[2] || Targets[1] == 0 ) then
				Targets = { v, Diff };
			end
		end	
	end
	return( Targets[1] != 0 && Targets[1] != LocalPlayer() ) && Targets[1] || nil;
end

local function NormalizeAngles( Angl )
	Angl.p = Shitbot["Copy"]["math"]["NormalizeAngle"]( Angl.p );
	Angl.y = Shitbot["Copy"]["math"]["NormalizeAngle"]( Angl.y );
	Angl.r = 0;
end

function Shitbot:Prediction( e, Pos )
	if( Shitbot["ConVars"]["aim_prediction"]:GetInt() == 1 ) then
		Pos = Pos + e:GetVelocity() / 50 + Shitbot["Copy"]["LocalPlayer"]():GetVelocity() / 50; //Baconbot prediction.
	end
	if( Shitbot["ConVars"]["aim_prediction"]:GetInt() == 2 ) then
		Pos = Pos + e:GetVelocity() * ( 1 / 66 ) - Shitbot["Copy"]["LocalPlayer"]():GetVelocity() * ( 1 / 66 ); //Turbobot prediction.
	end
	if( Shitbot["ConVars"]["aim_prediction"]:GetInt() == 3 ) then
		Pos = Pos + e:GetVelocity() * Shitbot["Copy"]["RealFrameTime"]() / 45 + Shitbot["Copy"]["LocalPlayer"]():GetVelocity() * Shitbot["Copy"]["RealFrameTime"]() / 45; //Not bullshitted at all.
	end
end

function Shitbot:Aimbot( u ) //Legit aimbots are for bitches.
	if( Shitbot["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then //input.IsKeyDown is gay as hell.
		local Target = GetTargets();
		if( !Target ) then return; end
		Shitbot["Locked"] = true;
		local Aimspot = Aimspot( Target );
		Shitbot:Prediction( Target, Aimspot );
		Aimspot = Aimspot + Shitbot["Copy"]["Vector"]( 0, 0, Shitbot["ConVars"]["aim_offset"]:GetFloat() );
		local Angl = ( Aimspot - Shitbot["Copy"]["LocalPlayer"]():GetShootPos() ):Angle();
		NormalizeAngles( Angl );
		u:SetViewAngles( Angl );
		Shitbot["Copy"]["LocalPlayer"]():GetActiveWeapon()["Recoil"] = 0;
		if( Shitbot["ConVars"]["aim_auto"]:GetBool() ) then
			u:SetButtons( u:GetButtons(), IN_ATTACK );
		end
	end
	if( !Shitbot["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then //Should have used an else.
		Shitbot["Locked"] = false;
	end
end

function Shitbot:Bhop( u )
	if( u:KeyDown( IN_JUMP ) && Shitbot["Copy"]["LocalPlayer"]():IsOnGround() == false && Shitbot["Copy"]["LocalPlayer"]():GetMoveType() != MOVETYPE_OBSERVER && Shitbot["Copy"]["LocalPlayer"]():Team() != TEAM_SPECTATOR ) then
		u:SetButtons( u:GetButtons() - IN_JUMP );
	end
end

local function GetAdminType( e )
	if( e:IsAdmin() && !e:IsSuperAdmin() ) then
		return "[A] ";
	elseif( e:IsSuperAdmin() ) then
		return "[SA] ";
	end
	return "";
end

local Ents = {};

function Shitbot:EntESP()
	if( Shitbot["ConVars"]["esp_ents"]:GetBool() ) then
		for k, v in Shitbot["Copy"]["pairs"]( Ents ) do
			for i, ent in Shitbot["Copy"]["pairs"]( Shitbot["Copy"]["ents"]["FindByClass"]( v ) ) do
				Shitbot["Copy"]["draw"]["SimpleText"]( ent:GetClass(), "TabLarge", ent:GetPos():ToScreen().x, ent:GetPos():ToScreen().y, color_white, TEXT_ALIGN_CENTER );
			end
		end
	end
end

Shitbot["Copy"]["concommand"]["Add"]( "esp_addent", function( p, c, a ) 
	Shitbot["Copy"]["table"]["insert"]( Ents, a[1] );
end );

local function ValidColor() //Skiddy noob shit
	if( Shitbot["Locked"] ) then
		return 255, 0, 0, 255;
	end
	if( Shitbot["Copy"]["LocalPlayer"]():GetEyeTrace()["Entity"]:IsPlayer() ) then
		return 0, 0, 255, 255;
	end
	return Shitbot["Copy"]["team"]["GetColor"]( Shitbot["Copy"]["LocalPlayer"]():Team() );
end

function Shitbot:Crosshair()
	if( Shitbot["ConVars"]["esp_crosshair"]:GetBool() ) then
		Shitbot["Copy"]["surface"]["SetDrawColor"]( ValidColor() );
		local x, y = Shitbot["Copy"]["ScrW"]() / 2, Shitbot["Copy"]["ScrH"]() / 2
		Shitbot["Copy"]["surface"]["DrawLine"]( x, y - 7, x, y + 7 );
		Shitbot["Copy"]["surface"]["DrawLine"]( x - 7, y, x + 7, y );
	end
end

function Shitbot:ESP()
	if( Shitbot["ConVars"]["esp_enabled"]:GetBool() ) then
		for k, v in Shitbot["Copy"]["pairs"]( Shitbot["Copy"]["player"]["GetAll"]() ) do
			if( v:Alive() && v != Shitbot["Copy"]["LocalPlayer"]() && v:Team() != TEAM_SPECTATOR && v:GetMoveType() != MOVETYPE_OBSERVER ) then
				local Pos = ( v:GetPos() + Shitbot["Copy"]["Vector"]( 0, 0, 75 ) ):ToScreen();
				Shitbot["Copy"]["draw"]["SimpleText"]( GetAdminType( v )..v:Name().." ["..v:Health().."]", "ESPFont", Pos.x, Pos.y, Shitbot["Copy"]["team"]["GetColor"]( v:Team() ), TEXT_ALIGN_CENTER );
			end
		end
	end
end

local Texture = { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 };
local Mat = Shitbot["Copy"]["CreateMaterial"]( "Solid", "UnlitGeneric", Texture );

function Shitbot:Chams()
	if( Shitbot["ConVars"]["vis_chams"]:GetBool() ) then
		for k, v in Shitbot["Copy"]["pairs"]( Shitbot["Copy"]["player"]["GetAll"]() ) do
			if( !bIsVisible( v ) && v:Alive() && v:GetMoveType() != MOVETYPE_OBSERVER && v:Team() != TEAM_SPECTATOR ) then
				local col = Shitbot["Copy"]["team"]["GetColor"]( v:Team() );
				Shitbot["Copy"]["cam"]["Start3D"]( Shitbot["Copy"]["EyePos"](), Shitbot["Copy"]["EyeAngles"]() );
				Shitbot["Copy"]["cam"]["IgnoreZ"]( 1 );
				Shitbot["Copy"]["render"]["SuppressEngineLighting"]( 1 );
				render.MaterialOverride( Mat )
				Shitbot["Copy"]["render"]["SetColorModulation"]( ( col.r * 1 / 255 ), ( col.g * 1 / 255 ), ( col.b * 1 / 255 ) );
				Shitbot["Copy"]["render"]["SetBlend"]( 0.65 );
				v:DrawModel();
				Shitbot["Copy"]["render"]["SetColorModulation"]( 1, 1, 1 );
				Shitbot["Copy"]["SetMaterialOverride"]();
				Shitbot["Copy"]["cam"]["IgnoreZ"]( 0 );
				Shitbot["Copy"]["render"]["SetBlend"]( 1 );
				Shitbot["Copy"]["cam"]["End3D"]();
				Shitbot["Copy"]["render"]["SuppressEngineLighting"]( 0 );
			end
		end
	end		
end

function Shitbot:Barrel()
	if( Shitbot["ConVars"]["vis_barrel"]:GetBool() ) then
		for k, v in Shitbot["Copy"]["pairs"]( Shitbot["Copy"]["player"]["GetAll"]() ) do
			if( v:Alive() && v:GetMoveType() != MOVETYPE_OBSERVER && v:Team() != TEAM_SPECTATOR ) then
				Shitbot["Copy"]["cam"]["Start3D"]( Shitbot["Copy"]["EyePos"](), Shitbot["Copy"]["EyeAngles"]() );
				Shitbot["Copy"]["render"]["SetMaterial"]( Shitbot["Copy"]["Material"]( "sprites/bluelaser1" ) );
				Shitbot["Copy"]["render"]["DrawBeam"]( v:GetAttachment( v:LookupAttachment( "eyes" ) )["Pos"], v:GetEyeTrace()["HitPos"], 5, 0, 0, Shitbot["Copy"]["Color"]( 255, 0, 0, 255 ) );
				Shitbot["Copy"]["cam"]["End3D"]();
			end
		end
	end
end

function Shitbot:XQZ()
	if( Shitbot["ConVars"]["vis_xqz"]:GetBool() ) then
		for k, v in Shitbot["Copy"]["pairs"]( Shitbot["Copy"]["player"]["GetAll"]() ) do
			if( Shitbot["Copy"]["IsValid"]( v ) && v:Alive() ) then
				Shitbot["Copy"]["cam"]["Start3D"]( Shitbot["Copy"]["EyePos"](), Shitbot["Copy"]["EyeAngles"]() );
				Shitbot["Copy"]["cam"]["IgnoreZ"]( 1 );
				v:DrawModel();
				Shitbot["Copy"]["cam"]["IgnoreZ"]( 0 );
				Shitbot["Copy"]["cam"]["End3D"]();
			end
		end
	end
end

local function HookRender()
	Shitbot:Barrel();
	Shitbot:Chams();
	Shitbot:XQZ();
end
Shitbot:Hook( "RenderScreenspaceEffects", HookRender );

local function HookCreateMove( u )
	Shitbot:Aimbot( u );
	Shitbot:Bhop( u );
end
Shitbot:Hook( "CreateMove", HookCreateMove );

local function HookHUDPaint()
	Shitbot:EntESP();
	Shitbot:ESP();
	Shitbot:Crosshair();
end
Shitbot:Hook( "HUDPaint", HookHUDPaint );

//This is going to be an ugly menu. Based on Turbobot's.

local dpanel;

function Shitbot:Menu()
	dpanel = Shitbot["Copy"]["vgui"]["Create"]( "DFrame" );
	dpanel:SetPos( 64, 64 );
	dpanel:SetSize( 250, 250 );
	dpanel:SetTitle( "Gorilla Smasher 3000" );
	dpanel:SetDraggable( 1 );
	dpanel:ShowCloseButton( 1 );
	dpanel:SetDeleteOnClose( 0 );
	dpanel:SetVisible( 1 );
	dpanel:MakePopup();
	
	local Sheet = Shitbot["Copy"]["vgui"]["Create"]( "DPropertySheet" );
	Sheet:SetParent( dpanel )
	Sheet:SetPos( 2, 22 );
	Sheet:SetSize( 240, 230 );

	local Aimoptions = Shitbot["Copy"]["vgui"]["Create"]( "DPanelList", Sheet )
	Aimoptions:SetPadding( 8 );
	Aimoptions:SetSpacing( 4 );
	
	local Aimadmins = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Aimadmins:SetText( "Admins" );
	Aimadmins:SetConVar( "aim_admins" );
	Aimadmins:SetValue( Shitbot["ConVars"]["aim_admins"]:GetInt() );
	Aimoptions:AddItem( Aimadmins );
	
	local Aimauto = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Aimauto:SetText( "Autoshoot" );
	Aimauto:SetConVar( "aim_auto" );
	Aimauto:SetValue( Shitbot["ConVars"]["aim_auto"]:GetInt() );
	Aimoptions:AddItem( Aimauto );
	
	local Aimfriendly = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Aimfriendly:SetText( "Friendly-Fire" );
	Aimfriendly:SetConVar( "aim_friendly" );
	Aimfriendly:SetValue( Shitbot["ConVars"]["aim_friendly"]:GetInt() );
	Aimoptions:AddItem( Aimfriendly );
	
	local Aimsteam = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Aimsteam:SetText( "Steam Friends" );
	Aimsteam:SetConVar( "aim_steam" );
	Aimsteam:SetValue( Shitbot["ConVars"]["aim_steam"]:GetInt() );
	Aimoptions:AddItem( Aimsteam );
	
	local Aimoffset = Shitbot["Copy"]["vgui"]["Create"]( "DNumSlider" );
	Aimoffset:SetText( "Offset" );
	Aimoffset:SetMin( -10 );
	Aimoffset:SetMax( 10 );
	Aimoffset:SetDecimals( 1 );
	Aimoffset:SetConVar( "aim_offset" );
	Aimoptions:AddItem( Aimoffset );
	
	local Aimprediction = Shitbot["Copy"]["vgui"]["Create"]( "DNumSlider" );
	Aimprediction:SetText( "Prediction" );
	Aimprediction:SetMin( 0 );
	Aimprediction:SetMax( 3 );
	Aimprediction:SetDecimals( 0 );
	Aimprediction:SetConVar( "aim_prediction" );
	Aimoptions:AddItem( Aimprediction );
	
	local ESPoptions = Shitbot["Copy"]["vgui"]["Create"]( "DPanelList", Sheet );
	ESPoptions:SetPadding( 8 );
	ESPoptions:SetSpacing( 4 );
	
	local Espcross = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espcross:SetText( "Crosshair" );
	Espcross:SetConVar( "esp_crosshair" );
	Espcross:SetValue( Shitbot["ConVars"]["esp_crosshair"]:GetInt() );
	ESPoptions:AddItem( Espcross );
	
	local Espenable = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espenable:SetText( "Enabled" );
	Espenable:SetConVar( "esp_enabled" );
	Espenable:SetValue( Shitbot["ConVars"]["esp_enabled"]:GetInt() );
	ESPoptions:AddItem( Espenable );
	
	local Espent = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espent:SetText( "Entity ESP" );
	Espent:SetConVar( "esp_ents" );
	Espent:SetValue( Shitbot["ConVars"]["esp_ents"]:GetInt() );
	ESPoptions:AddItem( Espent );
	
	local Espbarrel = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espbarrel:SetText( "Barrel Hack" );
	Espbarrel:SetConVar( "vis_barrel" );
	Espbarrel:SetValue( Shitbot["ConVars"]["vis_barrel"]:GetInt() );
	ESPoptions:AddItem( Espbarrel );
	
	local Espchams = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espchams:SetText( "Chams" );
	Espchams:SetConVar( "vis_chams" );
	Espchams:SetValue( Shitbot["ConVars"]["vis_chams"]:GetInt() );
	ESPoptions:AddItem( Espchams );
	
	local Espxqz = Shitbot["Copy"]["vgui"]["Create"]( "DCheckBoxLabel" );
	Espxqz:SetText( "Wallhack" );
	Espxqz:SetConVar( "vis_xqz" );
	Espxqz:SetValue( Shitbot["ConVars"]["vis_xqz"]:GetInt() );
	ESPoptions:AddItem( Espxqz );
	
	Sheet:AddSheet( "Aimbot", Aimoptions, false, false, false, "Aimbot Configuration" );
	Sheet:AddSheet( "ESP", ESPoptions, false, false, false, "ESP Configuration" );
end
Shitbot["Copy"]["concommand"]["Add"]( "SB_Menu", Shitbot.Menu );
