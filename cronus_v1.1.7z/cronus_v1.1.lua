--[[
	MOD/lua/cronus.lua [#31050 (#31847), 3512643454, UID:3500366805]
	{(ACS)} Trainer Blue | STEAM_0:0:77823910 <50.126.114.173:27005> | [31.05.14 10:04:44PM]
	===BadFile===
]]

local Cronus = {}
local Version = 3 .. ""
local CreateClientConVar = CreateClientConVar;
local x = ScrW() / 2 --Crosshair
local y = ScrH() / 2 --Crosshair
local gap = 0 --Crosshair Gap
local length = 5 --Crosshair Length
local spinbot = false
local SpamMessage = "~sethhacked~" -- Set your Chat Spam message here
 
 
surface.CreateFont("Arial",13,700,false,false,"ESPFont") -- fuck you GMod 13, you make me sad.
if( _G["Cronus"] ) then _G["Cronus"] = nil; end
 
--require("cvar2")
 
 
// ConVars
CreateClientConVar( "aim_removeaa", 1, true, false )
CreateClientConVar( "aim_removerecoil", 1, true, false )
CreateClientConVar( "aim_silent", 0, true, false )
CreateClientConVar( "aim_removespread", 1, true, false )
CreateClientConVar( "misc_crosshair", 1, true, false )
CreateClientConVar( "misc_removelaser", 0, true, false )
CreateClientConVar( "misc_removesky", 0, true, false )
CreateClientConVar( "misc_cheats", 1, true, false )
CreateClientConVar( "misc_chatspam", 0, true, false )
CreateClientConVar( "misc_forceCVars", 1, true, false )
CreateClientConVar( "esp_info", 1, true, false )
CreateClientConVar( "esp_chams", 1, true, false )
CreateClientConVar( "esp_box", 1, true, false )
CreateClientConVar( "esp_worldwire", 0, true, false )
CreateClientConVar( "Cronus_Speedhack_Speed", 0, true, false )
 
_G.Scrub = _R["CUserCmd"].SetViewAngles
Cronus.EyeAngles = Angle(0,0,0)
Cronus.StoredAngle = Angle(0,0,0)
Cronus.AngleRestored = 0
Cronus.Ang = Angle(0,0,0)
Cronus["Locked"] = false;
Cronus["Hooks"] = {};
Cronus["Copy"] = {
        ["MsgN"] = MsgN,
        ["tostring"] = tostring,
        ["table"] = table,
        ["hook"] = hook,
        ["math"] = math,
        ["surface"] = surface,
        ["draw"] = draw,
        ["ScrW"] = ScrW,
        ["ScrH"] = ScrH,
        ["pairs"] = pairs,
        ["util"] = util,
        ["http"] = http,
        ["player"] = player,
        ["input"] = input,
        ["ValidEntity"] = ValidEntity,
        ["LocalPlayer"] = LocalPlayer,
        ["GetConVarNumber"] = GetConVarNumber,
        ["SetMaterialOverride"] = SetMaterialOverride,
        ["CreateMaterial"] = CreateMaterial,
        ["Vector"] = Vector,
        ["render"] = render,
        ["Material"] = Material,
        ["EyePos"] = EyePos,
        ["EyeAngles"] = EyeAngles,
        ["cam"] = cam,
        ["team"] = team,
        ["ents"] = ents,
        ["Color"] = Color,
        ["concommand"] = concommand,
        ["vgui"] = vgui,
        ["string"] = string,
        ["RealFrameTime"] = RealFrameTime,
};
 
// Lets show them that the cheat is running?
chat.AddText(
    Color(255,0,255,255), "[Cronus] ",
    Color(0,255,0,255), "Project ",
    Color(0,255,0,255), "Cronus ",
        Color(0,255,0,255), "Version " .. Version .. " Loaded" )
surface.PlaySound("buttons/button19.wav")
 
// Set some stuff that shouldnt be optional
function RunOnStart()
cvar2.SetValue("sv_allow_voice_from_file","1")
end
hook.Add("Think","RunThisOnStart",RunOnStart)  
 
// Aimbot
 
hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "aim_removerecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        end
end )
 
function Cronus:Hook( type, func )
        local Name = Cronus["Copy"]["tostring"]( Cronus["Copy"]["math"]["random"]( 1, 150 ) );
        Cronus["Copy"]["MsgN"]( "Adding Hook "..Name.." ["..type.."]" );
        Cronus["Copy"]["table"]["insert"]( Cronus["Hooks"], Name );
        return Cronus["Copy"]["hook"]["Add"]( type, Name, func );
end
 
 
local function HookCreateMove( u )
        Cronus:Aimbot( u );
        Cronus:Bhop( u );
end
Cronus:Hook( "CreateMove", HookCreateMove );
 
Cronus["ConVars"] = {
        ["aim_admins"] = CreateClientConVar( "aim_admins", 0, true );
        ["aim_auto"] = CreateClientConVar( "aim_auto", 1, true );
        ["aim_friendly"] = CreateClientConVar( "aim_friendly", 1, true );
        ["aim_offset"] = CreateClientConVar( "aim_offset", 0, true );
        ["aim_prediction"] = CreateClientConVar( "aim_prediction", 1, true );
        ["aim_steam"] = CreateClientConVar( "aim_steam", 0, true );
}
 
 
 
local Aimspots = {
"head",
"forward",
"eyes"
 
}
 
local function Aimspot( e )
        local Pos;
        for k, v in Cronus["Copy"]["pairs"]( Aimspots ) do
                if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
                        Pos = e:GetAttachment( e:LookupAttachment( v ) )["Pos"];
                end
        end
        return Pos;
end
 
local function bIsVisible( e )
        local Trace = {};
        Trace.start = Cronus["Copy"]["LocalPlayer"]():GetShootPos();
        Trace.endpos = Aimspot( e );
        Trace.mask = MASK_SHOT|CONTENTS_HITBOX;
        Trace.filter = e, Cronus["Copy"]["LocalPlayer"]();
        local tr = Cronus["Copy"]["util"]["TraceLine"]( Trace );
        if( tr.Fraction == 1.0 ) then
                return true;
        end
end
 
local function bIsValid( e )
        if( !Cronus["Copy"]["ValidEntity"]( e ) || e == Cronus["Copy"]["LocalPlayer"]() ) then return false; end
        if( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then return false; end
        if( Cronus["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then return false; end
        if( Cronus["ConVars"]["aim_friendly"]:GetInt() == 0 && e:Team() == Cronus["Copy"]["LocalPlayer"]():Team() ) then return false; end
        if( Cronus["ConVars"]["aim_steam"]:GetBool() && e:GetFriendStatus() == "friend" ) then return false; end
        if( Cronus["ConVars"]["aim_admins"]:GetInt() == 0 && e:IsAdmin() ) then return false; end
        if( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then return false; end
        return true;
end
 
local function GetTargets()
        local Targets = { 0, 0 };
        for k, v in Cronus["Copy"]["pairs"]( Cronus["Copy"]["player"]["GetAll"]() ) do
                if( bIsVisible( v ) && bIsValid( v ) ) then
                        local Diff = ( v:EyePos() - Cronus["Copy"]["LocalPlayer"]():EyePos() ):Normalize();
                        Diff = Diff - Cronus["Copy"]["LocalPlayer"]():GetAimVector();
                        Diff = Diff:Length();
                        Diff = Cronus["Copy"]["math"]["abs"]( Diff );
                        if( Diff < Targets[2] || Targets[1] == 0 ) then
                                Targets = { v, Diff };
                        end
                end    
        end
        return( Targets[1] != 0 && Targets[1] != Cronus["Copy"]["LocalPlayer"]() ) && Targets[1] || nil;
end
 
local function NormalizeAngles( Angl )
        Angl.p = Cronus["Copy"]["math"]["NormalizeAngle"]( Angl.p );
        Angl.y = Cronus["Copy"]["math"]["NormalizeAngle"]( Angl.y );
        Angl.r = 0;
end
 
function Cronus:Prediction( e, Pos )
        if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 1 ) then
                Pos = Pos + e:GetVelocity() / 50 + Cronus["Copy"]["LocalPlayer"]():GetVelocity() / 50;
        end
        if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 2 ) then
                Pos = Pos + e:GetVelocity() * ( 1 / 66 ) - Cronus["Copy"]["LocalPlayer"]():GetVelocity() * ( 1 / 66 );
        end
        if( Cronus["ConVars"]["aim_prediction"]:GetInt() == 3 ) then
                Pos = Pos + e:GetVelocity() * Cronus["Copy"]["RealFrameTime"]() / 45 + Cronus["Copy"]["LocalPlayer"]():GetVelocity() * Cronus["Copy"]["RealFrameTime"]() / 45;
        end
end
 
function Cronus:Aimbot( u )
        if( Cronus["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then
                local Target = GetTargets();
                if( !Target ) then return; end
                Cronus["Locked"] = true;
                local Aimspot = Aimspot( Target );
                Cronus:Prediction( Target, Aimspot );
                Aimspot = Aimspot + Cronus["Copy"]["Vector"]( 0, 0, Cronus["ConVars"]["aim_offset"]:GetFloat() );
                local Angl = ( Aimspot - Cronus["Copy"]["LocalPlayer"]():GetShootPos() ):Angle();
                NormalizeAngles( Angl );
                u:SetViewAngles( Angl );
                Cronus["Copy"]["LocalPlayer"]():GetActiveWeapon()["Recoil"] = 0;
                if( Cronus["ConVars"]["aim_auto"]:GetBool() ) then
                        u:SetButtons( u:GetButtons() | IN_ATTACK );
                end
        end
        if( !Cronus["Copy"]["input"]["IsKeyDown"]( KEY_F ) ) then //Should have used an else.
                Cronus["Locked"] = false;
        end
end
 
// Anti Aim
hook.Add("CreateMove",1, function(cmd, u)
local C = LocalPlayer()
local v = cmd:GetViewAngles()
if GetConVarNumber( "aim_removeaa" ) >= 1 then return end;
cmd:SetViewAngles(Angle(181, v.y, -181))
end)
 
// No spread... Yeah let's call it that.  
-- This is just a clientside nospread, It's just visual.
local function NoSpread()                                      
if GetConVarNumber("aim_removespread") == 1 and LocalPlayer().GetActiveWeapon != nil then
local wep = LocalPlayer():GetActiveWeapon()
if ValidEntity(wep) then
if wep.data then
wep.data.Recoil = 0
wep.data.Cone = 0
wep.data.Spread = 0
end
if wep.Primary then
wep.Primary.Recoil = 0
wep.Primary.Cone = 0
wep.Primary.Spread = 0
end
end
end
end
hook.Add("Tick", "VisualNoSpread", NoSpread)
 
 
 
// Speedhack
timer.Create("AddSpeed",2,1,function()
concommand.Add("+Cronus_Speed" , function() cvar2.SetValue("sv_Cheats","1") cvar2.SetValue("Host_TimeScale",tostring(GetConVarNumber("Cronus_Speedhack_Speed"))) end)
concommand.Add("-Cronus_Speed", function() cvar2.SetValue("Host_TimeScale","1") end)
end)
 
// Bhop
function Cronus:Bhop( u )
        if( u:KeyDown( IN_JUMP ) && Cronus["Copy"]["LocalPlayer"]():IsOnGround() == false && Cronus["Copy"]["LocalPlayer"]():GetMoveType() != MOVETYPE_OBSERVER && Cronus["Copy"]["LocalPlayer"]():Team() != TEAM_SPECTATOR ) then
                u:SetButtons( u:GetButtons() - IN_JUMP );
        end
end
 
// Crosshair
function Crosshair()
if GetConVarNumber( "misc_crosshair" ) >= 1 then
surface.SetDrawColor( 0, 255, 0, 200 )
surface.DrawLine( x - length, y, x - gap, y )
surface.DrawLine( x + length, y, x + gap, y )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 , ScrH() / 2 + 5, ScrW() / 2 , ScrH() / 2 - 5)
 
 
 
        end
end
hook.Add("HUDPaint","CustomCross",Crosshair)
 
 
// ESP
local function ESP()
if( GetConVarNumber( 'esp_info' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( v:Name(), 'ESPFont', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "HP: " .. v:Health(), 'ESPFont', Pos.x, Pos.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText("Project Cronus", "ESPFont", 50, 10, Color(0, 255, 0, 200)) // This had to go somewhere, Wasn't going to make a function just for it
draw.SimpleText("Version "..Version.."", "ESPFont", 140, 10, Color(255, 0, 0, 200))
end
end
end
end
hook.Add("HUDPaint","PlayerESP", ESP)
 
function WorldWireFrame()
if GetConVarNumber( "esp_worldwire" ) >=1 then
cvar2.SetValue("mat_wireframe","1")
else
cvar2.SetValue("mat_wireframe","0")
end
end
hook.Add("Think","WorldWireFramewtf",WorldWireFrame)
 
 
function BoundingBox()
if GetConVarNumber( "esp_box" ) >= 1 then
for k, v in pairs ( player.GetAll() ) do
if v ~= LocalPlayer() then
if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
local PlayerBoxPos = v:EyePos():ToScreen()
surface.SetDrawColor( team.GetColor( v:Team() ) )
surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 3, PlayerBoxPos.y - 40 / 2, 30, 60 )
end
end
end
end
end
hook.Add( "HUDPaint", "CronusBoundingBox", BoundingBox )
 
// Chams
 
function PlayerModel()
if GetConVarNumber( "esp_chams" ) >= 1 then
for k, v in pairs(ents.GetAll()) do
if ValidEntity( v ) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial( "models/wireframe" )
cam.Start3D( EyePos(), EyeAngles() )
v:DrawModel()
cam.End3D()
end
end
end
end
end
hook.Add( "HUDPaint", "Playermodel1", PlayerModel )
 
 
// Remove Skybox
function RemoveSky()
        if GetConVarNumber("misc_removesky") >= 1 then
        cvar2.SetValue( "gl_clear", "1")
        cvar2.SetValue( "r_drawskybox", "0")
        cvar2.SetValue( "r_3dsky", "0")
        else
        cvar2.SetValue( "gl_clear", "0")
        cvar2.SetValue( "r_drawskybox", "1")
        cvar2.SetValue( "r_3dsky", "1")
        end
end    
hook.Add( 'HUDPaint', 'Ilikemyskyblack', RemoveSky );
 
 
// Radar
function DoChecksRadar( e )
 
        local ply, val = LocalPlayer(), 0
       
        if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
       
        if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
        if ( e:IsPlayer() && !e:Alive() ) then return false end
        if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
        if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
       
        return true
       
end
 
        local Radar = vgui.Create( "DFrame" )
        Radar:SetSize( 300, 300 )
       
        local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2
       
        local sW, sH = ScrW(), ScrH()
        Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
        Radar:SetTitle("Cronus Radar")
        Radar:SetVisible( true )
        Radar:SetDraggable( true )
        Radar:ShowCloseButton( false )
        Radar:MakePopup()
        Radar.Paint = function()
                draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 40 ) )
                surface.SetDrawColor( 255, 255, 255, 255 )
                surface.DrawOutlinedRect( 0, 0, rW, rH )
               
                local ply = LocalPlayer()
               
                local radar = {}
                radar.h         = 300
                radar.w         = 300
                radar.org       = 5000
               
                local x, y = ScrW() / 2, ScrH() / 2
               
                local half = rH / 2
                local xm = half
                local ym = half
               
                surface.DrawLine( xm, ym - 100, xm, ym + 100 )
                surface.DrawLine( xm - 100, ym, xm + 100, ym )
               
                for k, e in pairs( ents.GetAll() ) do
                        if ( DoChecksRadar(e) ) then
                               
                                local s = 6
                                local col = {}
                                local color = Color( 255,255,255,200 )
                                local plyfov = ply:GetFOV() / ( 70 / 1.13 )
                                local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
                               
                                npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
                                local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
                                local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
                               
                               
                                local pX = ( radar.w / 2 )
                                local pY = ( radar.h / 2 )
                               
                                local posX = pX - iY - ( s / 2 )
                                local posY = pY - iX - ( s / 2 )
                               
                                local text = e:GetClass()
                               
                                if ( e:IsPlayer() ) then
                                        text = e:Nick() .. " ["..e:Health().."]"
                                end
                               
                                if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
                               
                                        draw.RoundedBox( s, posX, posY, s, s, color )
 
                                end
                        end
                end
        end
       
        Radar:SetVisible( true )
        Radar:SetMouseInputEnabled( false )
        Radar:SetKeyboardInputEnabled( false )
        concommand.Add( "+mouseenable", function() Radar:SetMouseInputEnabled( true ) end )
        concommand.Add( "-mouseenable", function() Radar:SetMouseInputEnabled( false ) end )
       
        RRadar = Radar
       
// Fake View // -- Ignore the mess?
concommand.Add("FixView", function()
        Cronus.FixView = 1
        //Cronus.Spin = 1
        if GetConVarNumber("aim_silent") == 1 then
        Cronus.StoredAngle = LocalPlayer():EyeAngles() 
        end
        Cronus.Ang = LocalPlayer():EyeAngles() 
        Cronus.AngleRestored = 0
end)
 
 
function Cronus.FovCheck( ent, fov )
        if fov == 0 or fov == 180 then return true end 
        if ValidEntity( ent ) then
                if GetConVarNumber("aim_silent") == 0 then     
                        LAng = LocalPlayer():EyeAngles()       
                else           
                        LAng = Cronus.StoredAngle              
                end            
                if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) > fov then return false end     
                if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) < -fov then return false end
                if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) < -fov then return false end
                if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) > fov then return false end
                               
        end
        return true
end
 
function Cronus.FakeView(cmd)
        if GetConVarNumber("aim_silent") == 1 then
                Cronus.StoredAngle.p = math.Clamp(Cronus.StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89)   
                Cronus.StoredAngle.y = math.NormalizeAngle(Cronus.StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
                Cronus.StoredAngle.r = 0
        end    
end
hook.Add("CreateMove", "FakeView2", Cronus.FakeView)
 
local SetViewAngles = _R.CUserCmd.SetViewAngles
 
function AimHook( cmd )
if GetConVarNumber("aim_silent") == 1 then             
                local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - Cronus.StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
                cmd:SetForwardMove(Forward.x)          
                cmd:SetSideMove(Forward.y)             
        end
end
hook.Add("CreateMove","SILENTSHITPENIS",AimHook)
 
function Cronus.CalcView(ply, pos, angles, fov)
    local view = {}    
   view.origin = pos
        if Cronus.FixView == 1 and GetViewEntity() == LocalPlayer() and GetConVarNumber("aim_silent") == 1 then
                view.angles = Cronus.StoredAngle       
        end    
   view.fov = fov
    return view
end
hook.Add("CalcView", "FAKEVIEWPENIS", Cronus.CalcView)
 
// Spinbot // -- this is broken and i'm not fixing it at all, fuck you.
concommand.Add("+Spinbot", function()
    local normview = LocalPlayer():EyeAngles()
    hook.Add("CalcView", "NormalView", function()
        if spinbot then
            return {angles = normview}
                end
        end)   
        hook.Add("CreateMove", "SpinHack", function(UCMD)
            spinbot = true
            local na = UCMD:GetViewAngles()
            Scrub(UCMD, Angle(na.p, na.y+30, na.r))
        end)
end)
concommand.Add("-Spinbot", function()
    spinbot = false
        hook.Remove("CalcView", "NormalView")
    hook.Remove("CreateMove", "SpinHack")
end)
 
// Force sv_cheats // -- I made it optional because some servers autoban you for forcing sv_cheats
function sv_cheats()
if GetConVarNumber("misc_cheats") >= 1 then
cvar2.SetValue( "sv_cheats", "1" )
else
cvar2.SetValue( "sv_cheats", "0" )
end
end
hook.Add( "Think", "wtfhacker", sv_cheats )
 
 
// Simple Chat Spam // -- Set your message at the top of the cheat "local SpamMessage"
function ChatSpam()
if GetConVarNumber( "misc_chatspam" ) == 1 then
RunConsoleCommand( "say", ""..SpamMessage.."" )
end
end
hook.Add( "Think", "chatspamomg", ChatSpam )
 
 
// Laser Sight //
function Cronus.Barrel( )
if GetConVarNumber( "misc_removelaser" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
//if( !table.HasValue( LaserSightAllowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial( Material( 'sprites/bluelaser1' ) )
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, team.GetColor( LocalPlayer():Team() ) )
cam.End3D()
end
hook.Add( 'HUDPaint', '\2\3', Cronus.Barrel )
 
 
// Derma //
local Menu
function Menu()
 
        local x, y = ScrW() / 2, ScrH() / 2
       
        local Panel = vgui.Create( "DPropertySheet" )
                Panel:SetParent( menu )
                Panel:SetPos( x - 500 / 2, y - 300 / 2)
                Panel:SetSize( 500, 300 )
                Panel:MakePopup()
                Menu = Panel
       
        local Aimpanel = vgui.Create( "DPanelList", Panel )
        local Esppanel = vgui.Create( "DPanelList", Panel )
        local Miscpanel = vgui.Create( "DPanelList", Panel )
        local InfoPage = vgui.Create( "DPanelList", Panel )
       
       
        local Text = vgui.Create("DLabel")
                Text:SetText( "Aimbot Settings: " )
                Text:SetParent( Aimpanel )
                Text:SetWide( 200 )
                Text:SetPos( 10, 0 )
                Text:SetTextColor( Color( 0, 255, 0, 255 ) )
               
        --Aimbot                       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Friendly Fire" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 20 )
                Checkbox:SetConVar( "aim_friendly" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Autoshoot" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 40 )
                Checkbox:SetConVar( "aim_auto" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Remove Recoil" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 60 )
                Checkbox:SetConVar( "aim_removerecoil" )
                Checkbox:SizeToContents()
 
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Remove Spread" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 80 )
                Checkbox:SetConVar( "aim_removespread" )
                Checkbox:SizeToContents()
                       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Remove Anti-Aim" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 100 )
                Checkbox:SetConVar( "aim_removeaa" )
                Checkbox:SizeToContents()
       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Silent Aim" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 120 )
                Checkbox:SetConVar( "aim_silent" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Target Admins" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 140 )
                Checkbox:SetConVar( "aim_admins" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Ignore Steam Friends" )
                Checkbox:SetParent( Aimpanel )
                Checkbox:SetPos( 10, 160 )
                Checkbox:SetConVar( "aim_steam" )
                Checkbox:SizeToContents()      
        /*     
        local List = vgui.Create( "DMultiChoice" )
                List:SetPos( 260, 20 )
                List:SetParent( Aimpanel )
                List:SetSize( 220, 20 )
                List:AddChoice( "Head" )
                List:AddChoice( "Forward" )
                List:AddChoice( "Eyes" )
                List:SetConVar( "aim_offset" )
                */
        local Text = vgui.Create("DLabel")
                Text:SetText( "Aimspot" )
                Text:SetParent( Aimpanel )
                Text:SetWide( 200 )
                Text:SetPos( 260, 0 )
                Text:SetTextColor( Color( 0, 255, 0, 255 ) )
                                       
        local NumberSlider = vgui.Create( "DNumSlider" )
                NumberSlider:SetPos( 260, 220 )
                NumberSlider:SetParent( Aimpanel )
                NumberSlider:SetWide( 220 )
                NumberSlider:SetText( "Aim Prediction" )
                NumberSlider:SetMin( 0 )
                NumberSlider:SetMax( 3 )
                NumberSlider:SetDecimals( 0 )
                NumberSlider:SetConVar( "aim_prediction" )
               
        local FixView = vgui.Create("DButton")
                FixView:SetPos( 150, 20 )
                FixView:SetParent( Aimpanel )
                FixView:SetSize( 95, 25 )
                FixView:SetText( "Reset Aim Position" )
                FixView.DoClick = function()
                RunConsoleCommand( "FixView" )
                end
               
               
               
        --ESP
        local Text = vgui.Create("DLabel")
                Text:SetText( "ESP And WallHack: " )
                Text:SetParent( Esppanel )
                Text:SetWide( 200 )
                Text:SetPos( 10, 0 )
                Text:SetTextColor( Color( 0, 255, 0, 255 ) )
 
       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Name And Health" )
                Checkbox:SetParent( Esppanel )
                Checkbox:SetPos( 10, 20 )
                Checkbox:SetConVar( "esp_info" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Chams" )
                Checkbox:SetParent( Esppanel )
                Checkbox:SetPos( 10, 40 )
                Checkbox:SetConVar( "esp_chams" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Bounding Box" )
                Checkbox:SetParent( Esppanel )
                Checkbox:SetPos( 10, 60 )
                Checkbox:SetConVar( "esp_box" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "World Wireframe" )
                Checkbox:SetParent( Esppanel )
                Checkbox:SetPos( 10, 80 )
                Checkbox:SetConVar( "esp_worldwire" )
                Checkbox:SizeToContents()      
               
               
 
        --Miscellaneous
               
        local Text = vgui.Create("DLabel")
                Text:SetText( "Miscellaneous: " )
                Text:SetParent( Miscpanel )
                Text:SetWide( 200 )
                Text:SetPos( 10, 0 )
                Text:SetTextColor( Color( 0, 255, 0, 255 ) )
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Remove Skybox" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 20 )
                Checkbox:SetConVar( "misc_removesky" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Remove Laser Sight" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 40 )
                Checkbox:SetConVar( "misc_removelaser" )
                Checkbox:SizeToContents()
               
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Crosshair" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 60 )
                Checkbox:SetConVar( "misc_crosshair" )
                Checkbox:SizeToContents()
       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Force sv_cheats" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 80 )
                Checkbox:SetConVar( "misc_cheats" )
                Checkbox:SizeToContents()
       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Chat Spam" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 100 )
                Checkbox:SetConVar( "misc_chatspam" )
                Checkbox:SizeToContents()
       
        local Checkbox = vgui.Create( "DCheckBoxLabel" )
                Checkbox:SetText( "Force Other CVars" )
                Checkbox:SetParent( Miscpanel )
                Checkbox:SetPos( 10, 120 )
                Checkbox:SetConVar( "misc_CVarforce" )
                Checkbox:SizeToContents()
               
        local NumberSlider = vgui.Create( "DNumSlider" )
                NumberSlider:SetPos( 260, 220 )
                NumberSlider:SetParent( Miscpanel )
                NumberSlider:SetWide( 220 )
                NumberSlider:SetText( "SpeedHack Speed" )
                NumberSlider:SetMin( 0 )
                NumberSlider:SetMax( 7 )
                NumberSlider:SetDecimals( 1 )
                NumberSlider:SetConVar( "Cronus_SpeedHack_Speed" )             
       
               
 
        Panel:AddSheet( "Aimbot", Aimpanel, "gui/silkicons/wrench", false, false, "Aimbot Settings" )
        Panel:AddSheet( "ESP", Esppanel, "gui/silkicons/group", false, false, "ESP/Wallhack" )
        Panel:AddSheet( "Miscellaneous", Miscpanel, "gui/silkicons/plugin", false, false, "Miscellaneous" )
               
end
 
concommand.Add( "+Cronus_Menu", Menu )
concommand.Add( "-Cronus_Menu", function()
        Menu:SetVisible( false )
end )