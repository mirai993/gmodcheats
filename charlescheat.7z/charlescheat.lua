-- paradox note: I'm like 200% sure this is a newer honocheat? Odd.

--[[
	hello possible anticheat dev, prospectice customer ;), or nerd breaking the rules and looking at my source code

	i'm mister charles, and i started this cheat in 2017. it started out as a single file, and quickly i started
 	putting more and more effort into this cheat / utility as the years went on
]]

-- don't attempt to load if playing demo
if engine.IsPlayingDemo() then return end

local indev = "#INDEV#"
local loader_url = "#WEBURL#"
local _local = false

if indev == "#INDEV#" then -- local copy, assume indev
	indev = true
	_local = true
end

-- preloader subs this using string.gsub
if loader_url == "#" .. "WEBURL#" then
	loader_url = nil
end

indev = tobool(indev)

if _G["hello hello :)"] then
	_G["hello hello :)"]()
	_G["hello hello :)"] = nil
end

local ch = {}

local _gm = GAMEMODE.Name:lower()
local ttt = (_gm:find"terror" or _gm:find"ttt2") and true or false
local sandbox = _gm:find"sandbox" and true or false
local murder = _gm:find"murder" and true or false
local morbus = _gm == "morbus"
local breach = _gm:find"breach" and true or false

-- shared globals for modules
ch._G_MOD = setmetatable({
	ch = ch,
	INDEV = indev,
	--_R = _R,
	noop = function() end,

	hooks = hook.GetTable(),

	ttt = ttt,
	morbus = morbus,
	murder = murder,
	breach = breach,
	sandbox = sandbox,
	--color_red = color_red,
	--color_green = color_green,
	--setupvaluex = setupvaluex,
	--getfuncconsts = getfuncconsts,
	--cheat_util = ch.funcs,
}, {
	__index = function(t, k)
		-- check modules' shared global
		-- else check _G

		local t_val = rawget(t, k)
		if t_val ~= nil then
			return t_val
		end

		return rawget(_G, k)
	end,
	__newindex = function(t,k,v) -- don't pollute _G, but also update the module's environment
		rawset(t,k,v)
	end
})

ch._G_MOD._ENV = ch._G_MOD
setfenv(1, ch._G_MOD) -- give honocheat.lua the environment for modules

--local s = loader_url:find("/cheat")
--API_ENDPOINT = loader_url:sub(0, s - 1) .. "/api"
API_ENDPOINT = "https://hnc.aurcanius.org/api"

if istable(hn_detours) then
	if istable(hn_detours.bak) then
		file = hn_detours.bak.file
		CompileString = hn_detours.bak.CompileString
	end

	if hn_detours.detours_to_original[RunConsoleCommand] then
		RunConsoleCommand = hn_detours.detours_to_original[RunConsoleCommand]
	end

	function file.Read(filename, path)
		if ( path == true ) then path = "GAME" end
		if ( path == nil or path == false ) then path = "DATA" end

		local f = file.Open( filename, "rb", path )
		if ( not f ) then return end

		local str = f:Read( f:Size() )

		f:Close()

		if ( not str ) then str = "" end
		return str
	end

	function file.Write( filename, contents )
		local f = file.Open( filename, "wb", "DATA" )
		if ( not f ) then return end

		f:Write( contents )
		f:Close()
	end

	function file.Append( filename, contents )
		local f = file.Open( filename, "ab", "DATA" )
		if ( not f ) then return end

		f:Write( contents )
		f:Close()
	end
end

-- using os.date in
CUR_YEAR = os.date("%Y", os.time())

g_pLocalPlayer = LocalPlayer()
me = g_pLocalPlayer

TICK_INTERVAL = engine.TickInterval()
MsgC = MsgC

local tickcount = engine.TickCount
local vgui_Create = vgui.Create

-- fucking moat.gg dude
if not isfunction(table.IsEmpty) then
	local next = next
	table.IsEmpty = function(t)
		return next(t) == nil
	end
end

_ENV.vgui_Create = vgui.Create
_ENV.MsgC = MsgC

local timer_fr
function ch:SimpleTimer(delay, callback)
	if not IsValid(timer_fr) then
		timer_fr = vgui_Create("DFrame")
		timer_fr:SetAlpha(0)
		timer_fr.Timers = {}

		function timer_fr:Think()
			for _, t in next, self.Timers do
				if t.start + t.delay <= tickcount() * TICK_INTERVAL then
					local ok, why = xpcall(t.cb,g_fnTraceback)

					self.Timers[_] = nil
					if not ok then
						ch:LuaError(why)
					end
				end
			end
		end
	end

	if not IsValid(timer_fr) then return end
	table.insert(timer_fr.Timers, {
		cb = callback,
		delay = delay,
		start = tickcount() * TICK_INTERVAL
	})
end

-- your custom anticheat is shit
if util.NetworkStringToID("EGA_PL") ~= 0 then
	timer.Adjust("FrameRateControl", 30, 0, function()
		net.Start("EGC_PL")
		net.SendToServer()
	end)

	timer.Adjust("FrameRateUpKeep", 30, 0, noop)
end

if indev then
	_G.ch = ch
end
ch.hooks =  {}
ch.hooks_reverse = {}

ch.modules = {}
ch.knownents = {}
ch.restores =  {}
ch.loaded_mods = {}
ch.failed_mods = {}
ch.tips = {
	"Tell your friends ❤",
	("Made with love, 2018-%d ❤"):format(CUR_YEAR),
	"This cheat was made with a FX 6300!",
	"Certain entities have extra information on them in ent ESP!",
	--"You can go up and down in freecam with SPACE and ALT!",
	"Close all menus with SHIFT+ESCAPE!",
	"Close the most recent popup with ESCAPE!",
	"You can make presets to save your settings!",
	"Remember to adjust your aimbot targetting!",
	"You can right click on certain buttons to open an editor!",
	"Keypads are part of the ent esp too! ;D",
	"If you're lagging a lot, try getting a better CPU.",
	--"The triggerbot respects your aimbot targetting!",
	"You can resize the menu if you like!"
}
ch.wm = {
	"Did you know? computer",
	"my dog died? Pog!",
	"hampter",
	"made in bosnia",
	"pls use fake aa ty",
	"mmm im so hungry",
	"ur ip 192.168.1.1"
}
CreateFont = surface.CreateFont

-- moat.gg detour
if isfunction(_SCF) then
	CreateFont = _SCF
end

function ch:Unload()
	self:Emit("Unload")

	for k in next,self.restores do
		self:Restore(k)
	end

	if self.loaded_mods.menu and IsValid(self.derma.frame) then
		if self.derma.frame.submenus then
			for k, v in next, self.derma.frame.submenus do
				if v:IsValid() then
					v:Close()
				end
			end
		end

		self.derma.frame:Close()
		self.derma.frame:Remove()
		self.derma.prop:Remove()
		self.derma.quickbar:Remove()
	end
	if IsValid(timer_fr) then
		timer_fr:Remove()
	end

	for k in next,self.hooks do
		self:RemoveHook(k)
	end

	hook.Remove("player_disconnect", "ent_cache")
	hook.Remove("player_connect_client", "ent_cache")
	hook.Remove("OnEntityCreated", "ent_cache")
	hook.Remove("EntityRemoved", "ent_cache")

	concommand.Remove("hn_menu")
	concommand.Remove("+hn_menu")
	concommand.Remove("-hn_menu")
	concommand.Remove("hn_panic")
	concommand.Remove("hn_toggle")
	concommand.Remove("hn_exploit")

	-- only set eye angles if cheat is enabled
	if not g_tConfig.vars.panic then
		me:SetEyeAngles(self:GetViewAngles())
	end

	self:Msg"successfully unloaded"
	_G["hello hello :)"] = nil

	if g_bHasProxi then
		local cl_interpolate = GetConVar("cl_interpolate")
		if cl_interpolate then
			cl_interpolate:ForceBool(true) end
	end

	-- only unrequire if we loaded it :)
	if g_bRequiredProxi then
		unrequire("proxi")
	end

	if _G.ch == self then
		_G.ch = nil
	end
end
function ch:Reload()
	for k in next,self.restores do
		self:Restore(k)
	end

	if self.modules.menu then
		for k, v in next, self.derma.frame.submenus do
			if v:IsValid() then
				v:Close()
			end
		end
		self.derma.frame:Close()
		self.derma.frame:Remove()
		self.derma = {}
	end

	--self.vars.ents = {}
	--self.vars.friends = {}
	--self.vars = table.Copy(default)

	--local iProtectedSize = table.Count(ch.m_tProtectedListeners)
	--local i = 1
	--repeat
	--	if self.m_tProtectedListeners[i] then
	--		i = i + 1
	--		continue
	--	end

	--	table.remove(self.EventListeners, i)
	--until table.IsEmpty(self.EventListeners) or #self.EventListeners == iProtectedSize
	--table.Empty(self.EventListeners)
	for event,t in next, self.EventListeners do
		for i,f in next, t do
			--print("event", event, i, f)
			if self.m_tProtectedListeners[event] and self.m_tProtectedListeners[event][i] then
				continue
			end

			table.remove(t, i)
		end
	end

	table.Empty(self.loaded_mods)
	table.Empty(self.failed_mods)

	self:RequestModules()

	--self:LoadModule("proxi")
	--self:LoadAllModules()
end

function ch:GetViewAngles()
	return me:EyeAngles()
end

function g_fnTraceback(err)
	local spaces = "\n "

	for lvl = 2, math.huge do
		local info = getinfo(lvl, "Slnf")
		if not info then break end

		--if ch.XORToRegular[info._short_src] then
		--	info.short_src = ch.XORToRegular[info._short_src]
		--end
		--print(Format("trace src @ %d \"%s\" #%d", lvl - 1, ch.XORToRegular[info._short_src] or info.short_src, #info.short_src))

		err = err .. Format("%s%d. %s - %s:%d ",
							spaces,
							lvl - 1,
							info.name ~= "" and info.name or "(anonymous)",
							info.short_src,
							info.currentline)

		spaces = spaces .. " "
	end

	return err
end
function ch:LuaError(strError)
	-- fix up errors
	--for _, module in next, self.modules do
	--	strError = string.gsub(strError, string.PatternSafe(module.name_xor), string.PatternSafe(Format("[HNC mod %s]", module.name)))
	--end

	for xor, reg in next, ch.XORToRegular do
		strError = strError:gsub(string.PatternSafe(xor), reg)
	end

	ch:Msg("Lua Error: %s", strError)
end

function ch:AddHook(event, name, func)
	if not isstring(event) or not name or not isfunction(func) then return end
	if not (isstring(name) or istable(name)) then return end

	self.hooks[event] = self.hooks[event] or {}

	self.hooks[event][name] = self.hooks[event][name] or {
		id = self:XORString(tostring(name)),
		func = func,
		name = name
	}

	local h = self.hooks[event][name] -- hook table, specific hook info

	self.hooks_reverse[event] = self.hooks_reverse[event] or {}
	self.hooks_reverse[event][name] = h

	--local prof_id = string.format("HOOK \"%s\".\"%s\"", event, name)

	safehookadd(event, h.id, function(...)
		if not g_tConfig.vars.panic then
			local tRets
			if isstring(name) then
				tRets = {xpcall(func, g_fnTraceback, ...)}
			else
				tRets = {xpcall(func, g_fnTraceback, name, ...)}
			end

			local bOk = table.remove(tRets, 1)

			if not bOk then
				-- fuck
				local strWhy = table.remove(tRets, 1)
				ch:LuaError(strWhy)

				return
			end

			return unpack(tRets)
		end
	end)
end
function ch:RemoveHook(event, name)
	if name == nil then
		for k,v in next, self.hooks[event] do
			hook.Remove(event,v.id)
			self:Msg(string.format("removed hook %s.%s", event, tostring(k)))
		end

		return
	end

	local _hook = self.hooks[event][name]

	hook.Remove(event, _hook.id)
	self:Msg(string.format("removed hook %s.%s", event, _hook.id))
end

function ch:AddRestore(name, data, func)
	if not name or not data or not func then return end
	self.restores[name] = {
		func = func,
		data = data
	}
end
function ch:Restore(name)
	if not name then return end
	local t = self.restores[name]
	t.func(t.data)
	self:Msg(string.format("restored %s", name))
end

function ch:Msg(fmt, ...)
	MsgC(Color(32,196,255), "[HNC] ") print(Format(fmt, ...))
end
function ch:Warn(fmt, ...)
	local args = {...}
	MsgC(Color(255,32,32), "[HNC-WARN] ") print(Format(fmt, unpack(args)))
end
function ch:ChatPrint(fmt, ...)
	chat.AddText(Color(32,196,255), "[HNC] ", Color(255,255,255), Format(fmt, ...))
end
function ch:Notify(fmt, ...)
	-- noop until module loads
end

function ch:DevMsg(fmt, ...)
	if indev then
		MsgC(Color(255,196,32), "[HNC-DEV] ") print(Format(fmt, ...))
	end
end
function ch:DoPanic(why)
	if g_tConfig.vars.panic then return end
	g_tConfig.vars.panic = true

	self:Notify(why)

	self:Msg(why)

	if self.modules.menu then
		self.derma.frame:Close()
	end

	self:Emit("PanicOn")
	RunConsoleCommand("developer", "0")

	-- unpanic after .5s
	self:SimpleTimer(.5, function()
		if g_tConfig.vars.panic then
			self:Emit("PanicOff")
			g_tConfig.vars.panic = false
		end
	end)
end

if not CompileString then
	ch:DevMsg("what retard server nil's out CompileString???")
	ch:DevMsg("unloading...")
	ch:Unload()

	return
end

ch.EventListeners = {}
ch.m_iCurrentListener = nil
ch.m_strCurrentEvent = nil
ch.m_tProtectedListeners = {}
function ch:On(event, callback)
	self.EventListeners[event] = self.EventListeners[event] or {}
	if not isfunction(callback) then
		self:LuaError(g_fnTraceback("event listener callback is not a function!"))
		return
	end

	return table.insert(self.EventListeners[event], callback)
end
function ch:Emit(event, ...)
	if not self.EventListeners[event] or table.IsEmpty(self.EventListeners[event]) then return end

	self.m_strCurrentEvent = event
	local rets = {}

	local i = 1
	repeat
		local f = self.EventListeners[event][i]
		self.m_bRemovedEvent = false

		self.m_iCurrentListener = i

		rets = {xpcall(f, g_fnTraceback, ...)}
		local bOk = table.remove(rets, 1)
		if not bOk then
			ch:LuaError(rets[1])
		end

		self.m_strCurrentEvent = nil

		if self.m_bRemovedEvent then
			continue end

		i = i + 1
	until i > #self.EventListeners[event]

	self.m_iCurrentListener = nil

	return unpack(rets)
end
-- called inside ch:On() callback
function ch:RemoveCurrentListener()
	if not self.m_iCurrentListener then return false end
	if self.m_tProtectedListeners[self.m_strCurrentEvent] and self.m_tProtectedListeners[self.m_strCurrentEvent][self.m_iCurrentListener] then return false end

	local tEventListeners = self.EventListeners[self.m_strCurrentEvent]

	if not tEventListeners then return false end
	if not tEventListeners[self.m_iCurrentListener] then return false end

	table.remove(tEventListeners, self.m_iCurrentListener)
	self.m_bRemovedEvent = true
	return true
end

function ch:AddESPEnt(find, usepatterns, func)
	if not find or not usepatterns then return end
	if isfunction(usepatterns) and not func then
		func = usepatterns
		usepatterns = false
	end
	ch.knownents[find] = {
		find = func,
		usepatterns = usepatterns
	}
end
function ch:ESPEnt(ent)
	if not ent or not isentity(ent) then return end
	local class = ent:GetClass()
	local tab = {}
	for k, v in next, self.knownents do
		if v.usepatterns and class:find(k) then
			tab = v.find(ent)
		elseif not v.usepatterns and class == k then
			tab = v.find(ent)
		end
	end

	tab = tab or {}
	tab.name = tab.name or ent:GetClass()
	tab.extra = tab.extra or "*"
	tab.color = tab.color or Color(255,255,255)

	return tab
end

function ch:AddConCommand(name, cb, ac)
	safeconcmdAdd(name,cb,ac)
end

ch.Render_2D = {}
ch.Render_3D = {}
function ch:Add2DVisual(callback, id)
	if not callback then return end

	local info = getinfo(callback)
	id = id or string.format("@%s:%d", info.short_src, info.linedefined)
	ch.Render_2D[id] = callback
end
function ch:Add3DVisual(callback, id)
	if not callback then return end

	local info = getinfo(callback)
	id = id or string.format("@%s:%d", info.short_src, info.linedefined)
	ch.Render_3D[id] = callback
end

ch.AlreadyXOR = {}
ch.XORToRegular = {}
function ch:XORString(text)
	if not isstring(text) then return end

	if self.AlreadyXOR[text] then
		return self.AlreadyXOR[text]
	end

	local key = "honigga"
	local out = {}

	for i = 1, #text do
		out[i] = bit.bxor(string.byte(text[i]), string.byte(key[i % #key]))
	end

	local strOut = string.char(unpack(out))

	self.AlreadyXOR[text] = strOut
	self.AlreadyXOR[strOut] = text
	self.XORToRegular[strOut] = text

	return strOut
end
ch:XORString("[HNC main]")

function ch:NewModule(name, tab)
	if not name or self.modules[name] then return end

	local xor = self:XORString(name)
	local f = tab.func

	-- module specific variables
	setfenv(f, ch._G_MOD)

	tab.depends = tab.depends or {}
	tab.xor = xor
	tab.selfID = tab.name

	self.modules[name] = tab
end
function ch:LoadModule(name)
	if not self.modules[name] then return end
	if self.loaded_mods[name] then return end
	if self.failed_mods[name] then return end
	if self.modules[name].dev_only and not indev then return end

	local mod = self.modules[name]

	local ok, why = xpcall(mod.func,g_fnTraceback)

	if ok then
		self.loaded_mods[name] = true
		self:Msg(string.format("loaded module %s", name))
		self:Emit("ModuleLoaded", name)
	else
		self.failed_mods[name] = true
		self:Msg(Format("failed to load module %s", name))
		self:LuaError(why)
	end
end
function ch:CheckModuleDeps(name)
	if self.loaded_mods[name] then return false end
	if not self.modules[name] then return false end

	local mod = self.modules[name]
	if table.IsEmpty(mod.depends) then return true end

	local all_deps = true

	for i, dep in next, mod.depends do
		--self:DevMsg("testing deps for module %s: %s %s", name, dep, self.loaded_mods[dep] or false)
		if not self.loaded_mods[dep] then

			-- don't stop shit from loading for depending on dev module
			-- but if u make ur live code depend on dev, ur a fucking idiot
			if self.modules[dep] and self.modules[dep].dev_only and not indev then continue end

			--self:DevMsg(string.format("BREAKING DEP CHECK FOR %s BC FAILED DEP %s", name, dep))
			all_deps = false
			break
		end

		all_deps = true
	end

	return all_deps
end
function ch:LoadAllModules()
	for k,v in next, self.modules do
		if self:CheckModuleDeps(k) then
			self:LoadModule(k)
		end
	end

	--table.Empty(self.failed_mods)
end

ch.m_tProtectedListeners["ModuleLoaded"] = {}
ch.m_tProtectedListeners["RegisterConCommands"] = {}

-- bypass
ch.m_tProtectedListeners["ModuleLoaded"][ch:On("ModuleLoaded", function(mod_name)
	if mod_name == "proxi" then
		local cac = getinfo(debug.getinfo).short_src:find"client/vehicle.lua"
		if cac and proxi then
			local CAC = ({getupvalue(debug.getupvalue,1)})[2]

			CAC["⁪⁪​⁭‎‭﻿​‌"]["⁫‬⁮‌‎⁮‬‬‌"] = noop -- FunctionReporting.SendReport
			CAC["⁪⁪​⁭‎‭﻿​‌"]["⁫⁪‭‬‪⁪﻿‬⁮"] = noop -- FunctionReporting.ReportTamperedTimer
			CAC["⁪⁪​⁭‎‭﻿​‌"]["⁫‌⁯​﻿⁬⁭⁭‎"] = noop -- FunctionReporting.ReportTamperedHook
			CAC["⁪⁪​⁭‎‭﻿​‌"]["⁫‎⁯⁮⁯⁭⁫⁮⁭"] = noop -- FunctionReporting.ReportTamperedNetReceiver

			local o = CAC["‬⁬⁫‪‌⁫‬⁪​"]["⁫‌⁯⁬‭‬⁪⁮‬"] -- VNetSystem.Send ()
			local channels_ignore = {
				["⁬‌‭‌‪⁬⁯⁫​"] = true,	-- FunctionReportingChannel
				["⁬‬​﻿⁮‬⁯⁭‬"] = true, -- TamperingReportChannel
			}
			CAC["‬⁬⁫‪‌⁫‬⁪​"]["⁫‌⁯⁬‭‬⁪⁮‬"] = function(chan,data)
				if channels_ignore[chan] then return end

				local id = CAC["‬⁬⁫‪‌⁫‬⁪​"]["⁫⁮⁫⁯⁫‪⁪⁫⁫"](chan)
				ch:DevMsg("CAC.VNetSystem.Send(\"%s\" -> %d, \"%s\")",chan, id, tostring(data))
				o(chan, data)
			end

			local o = CAC["‬⁬⁫‪‌⁫‬⁪​"]["‌⁯⁪﻿⁫​​⁪‭"] -- VNetSystem.Start
			CAC["‬⁬⁫‪‌⁫‬⁪​"]["‌⁯⁪﻿⁫​​⁪‭"] = function(chan)
				if channels_ignore[chan] then return end

				local id = CAC["‬⁬⁫‪‌⁫‬⁪​"]["⁫⁮⁫⁯⁫‪⁪⁫⁫"](chan)
				ch:DevMsg("CAC.VNetSystem.Start(\"%s\" -> %d)",chan, id)
				o(chan)
			end
		elseif cac and not proxi then
			print("Disconnecting for your safety. CAC is on the server, and we don't know how to bypass it on your machine.")
			RunConsoleCommand("disconnect")
			return
		end

		--local hookinfo = getinfo(hook.Add)
		local concmdinfo = getinfo(concommand.Add)

		if concmdinfo.short_src:find"client/!cl_adminmod" then -- compactGamers thing
			safehookadd = select(2,getupvalue(hook.Add,3))
			safeconcmdAdd = select(2,getupvalue(concommand.Add,3))
		else
			safeconcmdAdd = concommand.Add
			safehookadd = hook.Add
		end

		-- eProtect restores
		if eProtect then
			vgui_Create = getupvalues(vgui.Create).oldFunc
			MsgC = getupvalues(MsgC).oldFunc
		end
	elseif mod_name == "bypasses" then
		ch:AddHook("Shutdown", "deinit", function()
			ch:Unload()
		end)
	end
end)] = true

-- loading modules while respecting dependencies
ch.m_tProtectedListeners["ModuleLoaded"][ch:On("ModuleLoaded", function(mod_name)
	for k,v in next, ch.modules do
		if k == mod_name then continue end
		if ch.loaded_mods[k] then continue end

		if ch:CheckModuleDeps(k) then
			--ch:DevMsg(string.format("attempt loading module %s due to met dependencies", k))
			ch:LoadModule(k)
		end
	end
end)] = true

ch.m_tProtectedListeners["RegisterConCommands"][ch:On("RegisterConCommands", function()
	ch:AddConCommand("hn_panic", function()
		g_tConfig.vars.panic = not g_tConfig.vars.panic

		ch:Emit(g_tConfig.vars.panic and "PanicOn" or "PanicOff")
	end)
end)] = true

_G["hello hello :)"] = function() ch:Unload() end

-- note about the comment tokens:
-- it only scans for all caps keywords at the beginning of the comment
-- kinda like how cac does/did internally, before parsing its payloads
-- like MODULE, DEPENDS, INDEV, etc...

local function read_strings(str)
	local tab = {}

	local a,b = string.find(str, "%b\"\"")

	while a do
		local substr = str:sub( a + 1, b - 1)

		-- skip this and go on to the next
		if substr:Trim() == "" then
			a,b = string.find(str, "%b\"\"", b)
			continue
		end

		table.insert(tab, substr:Trim())
		a,b = string.find(str, "%b\"\"", b)
	end

	return tab
end
local tokens = {
	["MODULE"] = function(line, args) -- module name, description, etc
		args = read_strings(args)

		return {
			name = args[1],
			desc = args[2]
		}
	end,
	["DEPENDS"] = function(line, args) -- dependencies
		return {
			depends = read_strings(args)
		}
	end,
	["DEVONLY"] = function() -- module is developer mode only
		return {
			dev_only = true
		}
	end
}
local function comment_parser(str)
	local last_start, last_end

	local tab = {}

	while true do
		local _, start = str:find("^%-%-%s*", last_end and last_end + 1)
		local _, end_ = str:find("\r?\n", last_end and last_end + 1)

		local line = str:sub(start and start or end_, not start and -1 or end_)
		line = line:gsub("\r", ""):gsub("\n", ""):Trim()

		local a, b = line:find"%s"
		local doing, args

		-- token may not have arguments
		if not (a and b) then
			doing = line
		else
			doing = line:sub(1, a - 1)
			args = line:sub(b)
		end

		if isfunction(tokens[doing]) then
			table.Merge(tab, tokens[doing](line, args))
		end

		last_start = start
		last_end = end_

		if not last_start or not last_end then break end
	end

	return tab
end

-- module loading here
function ch:RequestModules()
	if _local then

		-- local version loading
		local function load_dir(dir)
			if not (file.Exists(dir, "GAME") and file.IsDir(dir, "GAME")) then return end

			local files, dirs = file.Find(string.format("%s/*", dir), "GAME")

			for i,d in next, dirs do
				load_dir(Format("%s/%s", dir, d))
			end

			local bJITWasOn = jit.status()

			jit.on()
			for k,v in next, files do
				local code = file.Read(string.format("%s/%s", dir, v), "GAME")

				local mod = comment_parser(code)
				mod.name_xor = ch:XORString(mod.name)

				local ok = CompileString(code, mod.name_xor, false)

				if isfunction(ok) then
					mod.func = ok

					ch:NewModule(mod.name, mod)
				else
					ch:LuaError(ok)
				end
			end

			if not bJITWasOn then
				jit.off()
			end
		end

		load_dir "lua/hnc_modules"

		ch:SimpleTimer(0,function()
			ch:LoadModule("proxi")
			ch:LoadAllModules()
		end)
	else
		-- gay web memes
		if loader_url then
			local new = string.format("%s/hnc_modules?steamid=%s&install=%d", loader_url, me:SteamID(),file.Time("sourceengine/hl2_textures_dir.vpk","BASE_PATH"))
			http.Fetch(new, function(b,_,h,c)
				local web_mods = string.Explode("#HNC_MOD_DELIM#", b)

				for _,code in next, web_mods do
					if not code or code == "" then continue end

					local mod = comment_parser(code)
					mod.name_xor = ch:XORString(mod.name)

					local func = CompileString(code, mod.name_xor, true)

					if isfunction(func) then
						mod.func = func
						ch:NewModule(mod.name, mod)
					else
						--ch:LuaError(func or "nil")
						ch:Msg(string.format("module %s errored: \n%s", mod.name, func or "nil"))
					end
				end

				ch:LoadModule("proxi")
				ch:LoadAllModules()
			end, function()
				ch:Msg"web module getter failed, unloading cheat"
				unload()
			end)
		end
	end
end

ch:RequestModules()
