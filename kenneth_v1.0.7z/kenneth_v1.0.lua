--  STEAM_0:0:77139324  Kenneth
--  STEAM_0:0:54572250 [nameless] Shankey Dankey

--Fancy Models
--[[
models/props_hightower_event/underworld_sky.mdl

]]

--sbox_e2_maxpropspersecond 
local function DrawPlayerInfo(ply)
	local pos = ply:EyePos()
	
	pos.z = pos.z + 0
	pos = pos:ToScreen()
	local yOffset = -60
	
	if not (ply:GetNWString("usergroup")=="user") then
		draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x + 1, pos.y - 15 + yOffset, Color(0, 0, 0, 255), 1)
		if ply:IsSuperAdmin() then
			draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(255,0,0,200), 1)
		elseif ply:IsAdmin() then
			draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(0,0,255,200), 1)
		else
			draw.DrawText(ply:GetNWString("usergroup"), "TargetID", pos.x, pos.y - 16 + yOffset, Color(0,255,0,200), 1)
		end
	end
	
	draw.DrawText(ply:Nick(), "TargetID", pos.x + 1, pos.y + 1 + yOffset, Color(0, 0, 0, 255), 1)
	draw.DrawText(ply:Nick(), "TargetID", pos.x, pos.y + yOffset, team.GetColor(ply:Team()), 1)

	draw.DrawText("Health: "..ply:Health(), "TargetID", pos.x + 1, pos.y + 16 + yOffset, Color(0, 0, 0, 255), 1)
	draw.DrawText("Health: "..ply:Health(), "TargetID", pos.x, pos.y + 15 + yOffset, Color(255,255,255,200), 1)

	draw.DrawText(ply.DarkRPVars.job or "", "TargetID", pos.x + 1, pos.y + 31 + yOffset, Color(0, 0, 0, 255), 1)
	draw.DrawText(ply.DarkRPVars.job or "", "TargetID", pos.x, pos.y + 30 + yOffset, Color(255, 255, 255, 200), 1)

	if IsValid(ply:GetActiveWeapon()) then
		draw.DrawText(ply:GetActiveWeapon():GetClass() or "", "TargetID", pos.x + 1, pos.y + 46 + yOffset, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:GetActiveWeapon():GetClass() or "", "TargetID", pos.x, pos.y + 45 + yOffset, Color(255, 255, 255, 200), 1)
		
--[[	if ply:GetActiveWeapon():GetClass()=="gmod_tool" then
			if table.HasValue(ply:GetTool(), "Mode") then
				draw.DrawText(ply:GetTool().Mode, "TargetID", pos.x + 1, pos.y + 61 + yOffset, Color(0, 0, 0, 255), 1)
				draw.DrawText(ply:GetTool().Mode, "TargetID", pos.x, pos.y + 60 + yOffset, Color(255, 255, 255, 200), 1)
			end
		end]]
	end
end
local function angDif(pos)
	local myAngs = LocalPlayer():GetAngles()
	local needed = (pos - LocalPlayer():GetShootPos()):Angle()
	
	myAngs.p = math.NormalizeAngle(myAngs.p)
	needed.p = math.NormalizeAngle(needed.p)
	
	myAngs.y = math.NormalizeAngle(myAngs.y)
	needed.y = math.NormalizeAngle(needed.y)
	
	local p = math.NormalizeAngle(needed.p - myAngs.p)
	local y = math.NormalizeAngle(needed.y - myAngs.y)
	
	return math.abs(p) + math.abs(y), {p = p, y = y}
end

local function Distance(pos)
	local myPos = LocalPlayer():GetPos()	
	return math.sqrt((pos.x-myPos.x)^2+(pos.y-myPos.y)^2+(pos.z-myPos.z)^2)
end

for I = 1,100 do
	surface.CreateFont("HFont-"..I, {
		size = I,
		weight = 500,
		antialias = true,
		shadow = false,
		font = "Trebuchet MS"})
		
	surface.CreateFont("HFontAwe-"..I, {
		font = "Tahoma",
		size = I,
		weight = 600,
		antialias = true
	})	
end
local Table = {}
local Data = {}
Table["X"] = ScrW()
Table["Y"] = ScrH()
Table["Wallhack"] = false
Table["AimEnhance"] = false
Data["on"] = false
Data.ply = LocalPlayer()
local wait = true
local turnaround_undo = false
local AimIgnore = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon","lockpick","fas2_ifak"}

Data.Mat = CreateMaterial("Wallhack Material", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })

concommand.Add("lua_turnaround", function()
	local CanSpawn = true
	if IsValid(LocalPlayer():GetEyeTrace()) then
		if IsValid(LocalPlayer():GetEyeTrace().Entity) then
			CanSpawn = false
		end
	end
	if CanSpawn then
		LocalPlayer():SetEyeAngles((LocalPlayer():GetAimVector():Angle())+Angle(0,180,0))
	end
	timer.Simple(0.05, function()
		LocalPlayer():ConCommand("gm_spawn models/props_junk/TrafficCone001a.mdl")
	end)
	timer.Simple(0.1, function()
		RunConsoleCommand("+jump")
	end)
	timer.Simple(0.15, function()
		LocalPlayer():SetEyeAngles(Angle(0,LocalPlayer():GetAimVector():Angle().y+180,0))
		RunConsoleCommand("-jump")
	end)
	turnaround_undo = true
end)
concommand.Add("lua_stopfall", function()
	local CanSpawn = true
	local OldAng = LocalPlayer():GetAimVector():Angle()
	if IsValid(LocalPlayer():GetEyeTrace()) then
		if IsValid(LocalPlayer():GetEyeTrace().Entity) then
			CanSpawn = false
		end
	end
	if CanSpawn then
		LocalPlayer():SetEyeAngles(Angle(90,LocalPlayer():GetAimVector():Angle().y,0))
	end
	timer.Simple(0.05, function()
		LocalPlayer():ConCommand("gmod_undo;gm_spawn models/props_docks/dock02_pole02a.mdl")
	end)
	timer.Simple(0.15, function()
		LocalPlayer():ConCommand("gmod_undo")
		LocalPlayer():SetEyeAngles(OldAng)
	end)
end)
hook.Add("Think","Menu",function()
		if turnaround_undo && (input.IsMouseDown(MOUSE_LEFT)==false) then
		LocalPlayer():ConCommand("gmod_undo")
		turnaround_undo = false
		end

		--http://maurits.tv/data/garrysmod/wiki/wiki.garrysmod.com/indexa077.html
	if((input.IsKeyDown(KEY_LEFT) && input.IsKeyDown(KEY_RIGHT)) && wait) then
		timer.Simple(0.25,function() wait=true end)
			if IsValid(Table["Frame"]) then
				Table["Frame"]:Remove()
			else
				local FramePos=Vector(Table["X"]*0.66,Table["Y"]*0.01,0)
				local FrameScale=Vector(Table["X"]/3,Table["Y"]/3,0)
				Table["Frame"] = vgui.Create("DFrame")
				Table["Frame"]:SetSize(FrameScale.x,FrameScale.y)
				Table["Frame"]:SetPos(FramePos.x,FramePos.y)
				Table["Frame"]:SetTitle("Hack")
				Table["Frame"]:MakePopup()
				
				Table["Button_WallHack"] = vgui.Create("DButton",Table["Frame"])			
				Table["Button_WallHack"]:SetSize(FrameScale.x/6*1.8,FrameScale.y/10*1.8)			
				Table["Button_WallHack"]:SetPos((FrameScale.x/6)*0.1,(FrameScale.y/10)*1.1)			
				Table["Button_WallHack"]:SetText("Wallhack")
				Table["Button_WallHack"].DoClick = function()
					Table["Wallhack"] = !Table["Wallhack"]
					if(Table["Wallhack"])
					then 
						Table["Button_WallHack"]:SetColor(Color(0,0,0))
					else
						Table["Button_WallHack"]:SetColor(Color(255,255,255))
					end
				end
				
				Table["Button_AimEnhance"] = vgui.Create("DButton",Table["Frame"])			
				Table["Button_AimEnhance"]:SetSize(FrameScale.x/6*1.8,FrameScale.y/10*1.8)			
				Table["Button_AimEnhance"]:SetPos((FrameScale.x/6)*0.1,(FrameScale.y/10)*3.1)			
				Table["Button_AimEnhance"]:SetText("AimEnhance")
				Table["Button_AimEnhance"].DoClick = function()
					Table["AimEnhance"] = !Table["AimEnhance"]
					if(Table["AimEnhance"])
					then 
						Table["Button_AimEnhance"]:SetColor(Color(0,0,0))
//						Table["Button_AimEnhance"].Paint = function()
//							draw.RoundedBox( 8, 0, 0, Table["Button_AimEnhance"]:GetWide(), Table["Button_AimEnhance"]:GetTall(), Color( 255, 255, 255, 255 ) )
//						end
					else
						Table["Button_AimEnhance"]:SetColor(Color(255,255,255))
//						Table["Button_AimEnhance"].Paint = function()
//							draw.RoundedBox( 8, 0, 0, Table["Button_AimEnhance"]:GetWide(), Table["Button_AimEnhance"]:GetTall(), Color( 150, 150, 150, 255 ) )
//						end
					end
				end
				
				Table["Button_AutoShoot"] = vgui.Create("DButton",Table["Frame"])			
				Table["Button_AutoShoot"]:SetSize(FrameScale.x/6*1.8,FrameScale.y/10*1.8)			
				Table["Button_AutoShoot"]:SetPos((FrameScale.x/6)*2,(FrameScale.y/10)*3.1)			
				Table["Button_AutoShoot"]:SetText("AutoShoot")
				Table["Button_AutoShoot"].DoClick = function()
					Table["AutoShoot"] = !Table["AutoShoot"]
					if(Table["AutoShoot"])
					then 
						Table["Button_AutoShoot"]:SetColor(Color(0,0,0))
					else
						Table["Button_AutoShoot"]:SetColor(Color(255,255,255))
					end
				end
				
				
				Table["physTxt"] = vgui.Create("DLabel",Table["Frame"]);
				Table["physTxt"]:SetSize(FrameScale.x/6*1.8,FrameScale.y/10*1.8)			
				Table["physTxt"]:SetPos((FrameScale.x/6)*4,(FrameScale.y/10)*0.6)
				Table["physTxt"]:SetText("physgun_wheelspeed");
				
				local myText = vgui.Create("DTextEntry", Table["Frame"])
				myText:SetSize(FrameScale.x/6*1.8,FrameScale.y/10*0.9)	
				myText:SetPos((FrameScale.x/6)*4,(FrameScale.y/10)*2)
				myText:SetText("")
				myText.OnEnter = function(self)
					LocalPlayer():ConCommand("physgun_wheelspeed " .. self:GetValue() )
				end

			end
		wait=false
	end
end)
hook.Add("HUDPaint", "Wallhack", function()
	if Table["Wallhack"] then
		Data["ply"] = LocalPlayer()
		for k,ply in ipairs(player.GetAll()) do		
			if(!(ply==Data["ply"])) then
			
				DrawPlayerInfo(ply)
				
			--[[
				Table["Text"] = ply:GetName()		
				Table["Text_HP"] = ply:Health()	
				Table["Rank"] = ply:GetNWString("usergroup")
				
				--LocalPlayer():GetNWString("usergroup")
				--team.GetColor(ply.Team)
				surface.SetFont("HFontAwe-20")
				
				Table["Textsize"] = surface.GetTextSize(Table["Text"])+20
				Table["RankSize"] =surface.GetTextSize(Table["Rank"])+20
				Table["Pos"] = ply:GetPos():ToScreen()
				Table["HPSize"] = surface.GetTextSize(Table["Text_HP"])+20
				
				--draw.SimpleText(Table["Text"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y,Color(100,255,100,255),1)

				--draw.RoundedBox( 5 ,Table["Pos"].x-(Table["Textsize"]/2), Table["Pos"].y, Table["Textsize"], 25 ,Color(100,0,0,200) )
				--draw.RoundedBox( 5 ,Table["Pos"].x-25, Table["Pos"].y+25, 50, 25 ,Color(100,0,0,200) )
				
				Table["TeamColour"] = team.GetColor(ply:Team())
				
				
				
				draw.RoundedBox( 5 ,Table["Pos"].x-(Table["Textsize"]/2), Table["Pos"].y, Table["Textsize"], 25 ,Color(Table["TeamColour"].r,Table["TeamColour"].g,Table["TeamColour"].b,100) )
--				draw.SimpleText(Table["Text"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y,Color(255,255,255),1)
				draw.SimpleText(Table["Text"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y,Color(  0,  0,  0),1)
				
				draw.RoundedBox( 5 ,Table["Pos"].x-(Table["RankSize"]/2), Table["Pos"].y+25, Table["RankSize"], 25 ,Color(Table["TeamColour"].r,Table["TeamColour"].g,Table["TeamColour"].b,100) )
				draw.SimpleText(Table["Rank"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y+25,Color(  0,  0,  0),1)

				draw.RoundedBox( 5 ,Table["Pos"].x-(Table["HPSize"]/2), Table["Pos"].y+50, Table["HPSize"], 25 ,Color(Table["TeamColour"].r,Table["TeamColour"].g,Table["TeamColour"].b,100) )
				draw.SimpleText(Table["Text_HP"],"HFontAwe-20",Table["Pos"].x,Table["Pos"].y+50,Color(((100-Table["Text_HP"])/100)*255,(Table["Text_HP"]/100)*255,0),1)
				]]--
			end
		end
	end
end)
hook.Add("RenderScreenspaceEffects", "chams", function()
	if Table["Wallhack"] then
		--local everything = ents.GetAll()
		for k,v in ipairs(player.GetAll()) do
			cam.Start3D(EyePos(), EyeAngles())
			if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR) or (v:IsNPC() and v:Health() > 0) then
				local color = team.GetColor(v:Team())
				render.SuppressEngineLighting(true)
				render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
				render.MaterialOverride(Data.Mat)
				v:DrawModel()

				render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)
				if IsValid(v:GetActiveWeapon()) then
					v:GetActiveWeapon():DrawModel()
				end
				render.SetColorModulation(1, 1, 1, 1)
				render.MaterialOverride()
				render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
				v:DrawModel()
				render.SuppressEngineLighting(false)
				
			end
			cam.End3D()
		end
	end
end)
hook.Add("Think","AimEnhance",function()
	if(Table["AimEnhance"] and IsValid(Data.ply:GetActiveWeapon())) then
		Data["MOUSE_RIGHT"] = input.IsMouseDown(MOUSE_RIGHT)
		if Data["MOUSE_RIGHT"] and not table.HasValue(AimIgnore, Data.ply:GetActiveWeapon():GetClass()) then
			Data["ply"] = LocalPlayer()
			if not Data.on then
				for k,ply in ipairs(player.GetAll()) do
					if not (ply == Data.ply) then
						if ply:Alive() then
							Data.Dist = Distance(ply:GetPos()+Vector(0,0,50))
							if angDif(ply:GetPos()) < (3600/Data.Dist) then
								Data.target = ply
								Data.on = true
							end
						end
					end
				end
			end
			
			
			if(Data["ply"]:GetEyeTrace().Entity.IsPlayer()) then
				--Data["target"] = Data["ply"]:GetEyeTrace().Entity
				--Data["on"] = true
			end
			
			if(Data["on"]) then
				if(Data["target"]) then
					if(Data["ply"]:GetActiveWeapon().Primary) then
						local targetheadpos,targetheadang = Data["target"]:GetBonePosition(Data["target"]:LookupBone("ValveBiped.Bip01_Head1"))-Vector(0,0,(Data["ply"]:GetActiveWeapon().Primary.Recoil or 0)	)
						Data["ply"]:SetEyeAngles((targetheadpos - Data["ply"]:GetShootPos()):Angle())
					end
					if(!Data["target"]:Alive()) then
						Data["target"] = false
						Data.on = false
					end
				end
			end
		else 
			Data["on"] = false
		end
	end
end)
hook.Add("HUDPaint", "AimEnhancePaint", function()
	local x = ScrW() / 2
	local y = ScrH() / 2
	local gap = 5
	local length = gap + 15
	
	if IsValid(Data.ply:GetActiveWeapon()) then
		if Table["AimEnhance"] and Data["MOUSE_RIGHT"] and not table.HasValue(AimIgnore, Data.ply:GetActiveWeapon():GetClass()) then
			if Data.on then
				if Data["target"]==LocalPlayer():GetEyeTrace().Entity then
					surface.SetDrawColor( 0, 255, 0, 255 )
				else
					surface.SetDrawColor( 255, 0, 0, 255 )
				end
				if Data["target"] then
					draw.DrawText(Data.target:Nick(), "TargetID", x + 1 , y + 41, Color(0, 0, 0, 200), 1)
					draw.DrawText(Data.target:Nick(), "TargetID", x , y + 40, team.GetColor(Data.target:Team()), 1)
				end
			else
				surface.SetDrawColor( 0, 0, 255, 255 )			
			end
			
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		end
	end
end)

hook.Add("CreateMove", "AutoShoot", function(cmd)
	if IsValid(Data.ply:GetActiveWeapon()) then
		--[[[if (Data.ply:GetActiveWeapon():GetClass() == "weapon_physgun") and input.IsKeyDown(KEY_R) and not input.IsKeyDown(KEY_E) then
--			cmd:SetButtons(cmd:GetButtons() - IN_RELOAD)
		--end
		if Table["AimEnhance"] and Table["AutoShoot"] 
		then
			if (Data.ply:GetActiveWeapon():Clip1() < 1) and (Data.ply:GetActiveWeapon().Primary.ClipSize > 0) then
				if not Data.AutoReloadTimer then
					Data.AutoReloadTimer = true
					timer.Create("AutoShoot", 1, 1, function() Data.AutoReloadDelay = true end)
				end
				if Data.AutoReloadDelay then
					timer.Stop("AutoShoot")
					cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
					Data.AutoReloadDelay = false
					Data.AutoReloadTimer = false
				end
			end]]
			
		if Table["AimEnhance"] and Table["AutoShoot"] 
		then
			if Data["MOUSE_RIGHT"] and Data["target"] then
				if Data["target"]==Data.ply:GetEyeTrace().Entity then
					if not Data.AutoShootTimer then
						Data.AutoShootTimer = true
						timer.Create("AutoShoot", 0.2, 1, function() Data.AutoShootDelay = true end)
					end
				else
					timer.Stop("AutoShoot")
					Data.AutoShootDelay = false
					Data.AutoShootTimer = false
				end
				if Data.AutoShootDelay then
					cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
					Data.AutoShootDelay = false
					Data.AutoShootTimer = false
				end
			end
		end
	end
	
end)





--[[
hook.Add("Think", AHack.RandomName(math.random(10, 15)), function()
	if AHack.Active:GetBool() then	
		if AHack.Aimbot.Vars["Active"]:GetBool() and not (AHack.Aimbot.Vars["PanicMode"]:GetBool() and #AHack.Spectators > 0) then
			if not AHack.Aimbot.Vars["AimOnKey"]:GetBool() or (AHack.Aimbot.Vars["AimOnKey"]:GetBool() and AHack.KeyPressed(AHack.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
				if AHack.ValidTarget() then
					local BoneOrder = {}
					if AHack.Aimbot.CurTarget.BoneToAimAt and AHack.Aimbot.Vars["RandomBones"]:GetBool() then
						table.insert(BoneOrder, AHack.Aimbot.CurTarget.BoneToAimAt)
						table.Add(BoneOrder, AHack.GetRandomBones())
						table.Add(BoneOrder, AHack.Bones)
					else
						if AHack.Aimbot.Vars["RandomBones"]:GetBool() then
							table.Add(BoneOrder, AHack.GetRandomBones())
							table.Add(BoneOrder, AHack.Bones)
						else
							table.Add(BoneOrder, AHack.Bones)
						end
					end
					for k = 1, #BoneOrder do 
						local v = BoneOrder[k]
						local bone = AHack.Aimbot.CurTarget:LookupBone(v)
						if bone != nil then
							local pos, ang = AHack.Aimbot.CurTarget:GetBonePosition(bone)
							if v == "ValveBiped.Bip01_Head1" then
								pos = pos + Vector(0, 0, 3) //Aiming a little higher for the head
							end
							local total, needed = 300, {300, 300}
							
							if AHack.Aimbot.Vars["Prediction"]:GetBool() then
								local tarSpeed = AHack.Aimbot.CurTarget:GetVelocity() * 0.013
								local plySpeed = AHack.Ply:GetVelocity() * 0.013
								total, needed = AHack.AngleTo(pos - plySpeed + tarSpeed)
							else
								total, needed = AHack.AngleTo(pos)
							end
								
							if AHack.SpotIsVisible(pos) and total < AHack.Aimbot.Vars["MaxAngle"]:GetInt() then
								local myAngles = AHack.Ply:GetAngles()								
								local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
								
								if AHack.Aimbot.Vars["AntiSnap"]:GetBool() then
									local speed = AHack.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
									NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
								end
								
								AHack.Ply:SetEyeAngles(NewAngles)
								AHack.Aimbot.CurTarget.BoneToAimAt = BoneOrder[k]
								break
							end
						end
					end
				else
					AHack.Aimbot.CurTarget = AHack.GetTarget()
				end
			else
				AHack.Aimbot.CurTarget = nil
			end
		end
		
		if AHack.Misc.Vars["NoRecoil"]:GetBool() then
			if IsValid(AHack.Ply:GetActiveWeapon()) then
				local weapon = AHack.Ply:GetActiveWeapon()
				if weapon.Primary then
					weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
					weapon.Primary.Recoil = 0
					weapon.Recoil = 0
				else
					weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
					weapon.Recoil = 0
				end
			end
		elseif IsValid(AHack.Ply:GetActiveWeapon()) then
			local weapon = AHack.Ply:GetActiveWeapon()
			if weapon.Primary then
				weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
			else
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil
			end
		end
		
		if AHack.DarkRP and AHack.Misc.Vars["BuyHealth"]:GetBool() then
			if AHack.Ply:Alive() and AHack.Ply:Health() < AHack.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
				AHack.Ply:ConCommand("say /buyhealth")
			end
		end
	end
end)
]]















