-- paradox note: https://pastebin.com/raw/VYdqrCHs

CreateClientConVar("dw_show_weps", "1", false, false)
    CreateClientConVar("dw_show_items", "1", false, false)
    CreateClientConVar("dw_wallhack", "1", false, false)
    CreateClientConVar("dw_cullrange", "500", false, false)
    CreateClientConVar("dw_cull_items", "1", false, false)
    CreateClientConVar("dw_cull_ply", "1", false, false)
    CreateClientConVar("dw_aim", "1", false, false)
    --Menu--
    function Menu()
            local DermaPanel = vgui.Create( "DFrame" )
            DermaPanel:SetPos( 50,50 )
            DermaPanel:SetSize( 200, 250 )
            DermaPanel:SetTitle( "DingusWork Menu" )
            DermaPanel:SetVisible( true )
            DermaPanel:SetDraggable( true )
            DermaPanel:ShowCloseButton( true )
            DermaPanel:MakePopup()
             
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,40 )
            Chk:SetText( "Wallhack Enabled" )
            Chk:SetConVar( "dw_wallhack" )
            Chk:SizeToContents()
           
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,60 )
            Chk:SetText( "Show Weapons" )
            Chk:SetConVar( "dw_show_weps" )
            Chk:SizeToContents()  
           
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,80 )
            Chk:SetText( "Show Items" )
            Chk:SetConVar( "dw_show_items" )
            Chk:SizeToContents()
           
            local DermaNumSlider = vgui.Create( "DNumSlider", DermaPanel )
            DermaNumSlider:SetPos( 10, 100 )             // Set the position
            DermaNumSlider:SetSize( 200, 20 )          // Set the size
            DermaNumSlider:SetText( "ESP Cull range (m)" )   // Set the text above the slider
            DermaNumSlider:SetMin( 0 )                  // Set the minimum number you can slide to
            DermaNumSlider:SetMax( 500 )                // Set the maximum number you can slide to
            DermaNumSlider:SetDecimals( 0 )             // Decimal places - zero for whole number
            DermaNumSlider:SetConVar( "dw_cullrange" ) // Changes the ConVar when you slide
           
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,120 )
            Chk:SetText( "Fade Items" )
            Chk:SetConVar( "dw_cull_items" )
            Chk:SizeToContents()
           
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,140 )
            Chk:SetText( "Fade Players" )
            Chk:SetConVar( "dw_cull_ply" )
            Chk:SizeToContents()
           
            local Chk = vgui.Create( "DCheckBoxLabel", DermaPanel )
            Chk:SetPos( 10,160 )
            Chk:SetText( "Aimbot" )
            Chk:SetConVar( "dw_aim" )
            Chk:SizeToContents()
           
    end
    concommand.Add( "dw_menu", Menu )
     
    ----------------------------------------------Wallhack---------------------------------------------------------------------
    local GoodWeps = {
       "hands",
       "clockwork_hands",
       "weapon_zipties",
       "clockwork_keys",
       "weapon_physgun",
       "weapon_physcannon",
       "clockwork_flashlight"
    };
     
    local Speclockworkeps = {
       "gmdw_tool"
    };
     
    hook.Add('HUDPaint', 'retaded_esp', function()
           
            local ply = LocalPlayer()
        local pos = ply:GetShootPos()
        local ang = ply:GetAimVector()
        local tracedata = {}
        tracedata.start = pos
            tracedata.endpos = pos+(ang*4096)
        tracedata.filter = ply
            local trace = util.TraceLine(tracedata)
            local hitpos = trace.HitPos:ToScreen()
            draw.RoundedBox( 2, hitpos.x-8, hitpos.y, 16, 2, Color( 255, 255, 255, 255 ) )
            draw.RoundedBox( 2, hitpos.x, hitpos.y-8, 2, 16, Color( 255, 255, 255, 255 ) )
            if GetConVar("dw_wallhack"):GetInt() == 1 then
                    for k, v in pairs( player.GetAll() ) do
                     
                            if( v == LocalPlayer() ) then continue; end
                             
                            local hpos = v:GetPos();
                            local dist = hpos:Distance( LocalPlayer():GetPos() );
                            local m = dist / 39.36;
                            local range = GetConVar("dw_cullrange"):GetInt()
                            if m < range or GetConVar("dw_cull_ply"):GetInt() == 0 then
                                    local alpha
                                    if GetConVar("dw_cull_ply"):GetInt() == 1 then
                                            alpha = 255-255*m/range
                                    else alpha = 255 end
                                    local pos = v:EyePos():ToScreen();
                                    local namecol
                                    if v:GetFriendStatus() == "friend" then namecol = Color( 245, 151, 253, alpha ) else
                                            namecol = Color( 0, 255, 0, alpha );
                                    end
                                    local namecola = Color( 255, 251, 50, alpha );
                                    local ooccol = Color( 150, 255, 150, alpha );
                                    local curYPos = pos.y;
                                            if( v:IsAdmin() ) then
                                            namecol = Color( 255, 251, 50, alpha );
                                            end
                                    if ( v:IsUserGroup("operator") ) then
                                            namecol = Color( 255, 122, 50, alpha );
                                    end
                                    if( v:IsSuperAdmin() ) then
                                            namecol = Color( 255, 0, 0, alpha );
                                    end
     
                                     
                                    draw.DrawText( v:Name() .. " - " .. tostring( v:Health() ) .. "HP", "ChatFont", pos.x, curYPos, namecol ); curYPos = curYPos + 12;
                                    draw.DrawText( "AKA " .. v:SteamName(), "ChatFont", pos.x, curYPos, ooccol ); curYPos = curYPos + 12;
     
                                     
                                    draw.DrawText( tostring( math.Round( m ) ) .. "m", "ChatFont", pos.x, curYPos, Color( 187, 0, 255, alpha ) ); curYPos = curYPos + 12;
                                     
                                      if( dist <= math.min( Clockwork.config:Get( "talk_radius" ):Get() / 3, 80 ) ) then
                                             draw.DrawText( "Whisper Range", "ChatFont", pos.x, curYPos, Color( 255, 0, 0, alpha ) );
                                      elseif( dist <= Clockwork.config:Get( "talk_radius" ):Get() ) then
                                             draw.DrawText( "Talk Range", "ChatFont", pos.x, curYPos, Color( 255, 0, 0, alpha ) );
                                      elseif( dist <= Clockwork.config:Get( "talk_radius" ):Get() * 2 ) then
                                             draw.DrawText( "Yell Range", "ChatFont", pos.x, curYPos, Color( 255, 0, 0, alpha ) );
                                      else
                                             draw.DrawText( "Outside Range", "ChatFont", pos.x, curYPos, Color( 128, 128, 128, alpha ) );
                                      end
                                      curYPos = curYPos + 12;
                                      local runy = curYPos;
                                      if GetConVar("dw_show_weps"):GetInt() == 1 then
                                                    if( v != LocalPlayer() ) then
                                                            local pos = v:EyePos():ToScreen();
                                                            local runy = pos.y + 48;
                                                            for _, n in pairs( v:GetWeapons() ) do
                                                                    if( table.HasValue( GoodWeps, n:GetClass() ) ) then continue; end
                                                                            wepCol = Color( 255, 255, 255, alpha );
                                                                    if( n == v:GetActiveWeapon() ) then
                                                                            wepCol = Color( 255, 0, 0, alpha );
                                                                    end
                                                                            if( table.HasValue( Speclockworkeps, n:GetClass() ) ) then
                                                                            wepCol = Color( 128, 128, 128, alpha );
                                                                    end
                                                                    local toPrint = "(" .. n:GetClass() .. ")";
                                                                    if( n.PrintName ) then
                                                                    toPrint = n.PrintName;
                                                                    end
                                                                    draw.DrawText( toPrint, "ChatFont", pos.x+5, runy, wepCol );
                                                                    runy = runy + 12;
                                                            end
                                                    end
                                      end
                            end
                    end
                    if GetConVar("dw_show_items"):GetInt() == 1 then
                            for k, v in pairs(ents.GetAll()) do
                                    if v:IsValid() then
                                            local pos = v:GetPos()
                                            local dist = (pos-LocalPlayer():GetPos()):Length()/39.36
                                            local range = GetConVar("dw_cullrange"):GetInt()
                                           
                                            if dist < range or GetConVar("dw_cull_items"):GetInt() == 0 then
                                                    local alpha
                                                    if GetConVar("dw_cull_items"):GetInt() == 1 then
                                                            alpha = 255-255*dist/range
                                                    else alpha = 255 end
                                                    if v:GetClass() == "cw_cash" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Chedda", 'ChatFont', pos2.x, pos2.y, Color(13, 143, 0,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_item" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            local itemTable = v.cwItemTable;
                                                            local name
                                                            if itemTable then
                                                                    name = itemTable("name")
                                                            else
                                                                    name = v:GetModel()
                                                            end
                                                            draw.SimpleText(name, 'Trebuchet18', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_rationprinter" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Money Printer", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_belongings" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Belongings", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_rationproducer" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Money Printer", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_shipment" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Item Shipment", 'ChatFont', pos2.x, pos2.y, Color(100, 255, 184,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_salesman" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Salesman", 'ChatFont', pos2.x, pos2.y, Color(100, 255, 184,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_propguarder" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Prop Guarder", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_doorguarder" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Door Guarder", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_rationguarder" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Ration Guarder", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                                    if v:GetClass() == "cw_safebox" then
                                                            local pos2 = (pos + Vector(0,0,5)):ToScreen();
                                                            draw.SimpleText("Safebox", 'ChatFont', pos2.x, pos2.y, Color(0, 201, 237,alpha), 1, 1, 1)
                                                    end
                                            end
                                    end
                            end
                    end
            end
    end)
    hook.Add( "HUDPaint", "ESPWeapons", ESPWeapons );
     
    ----------------------------------------------Nightvision----------------------------------------------------------------------
    local On = false
    local Glow
    function Night( on )
     
            function think()
                    for k,v in pairs(ents.GetAll()) do
                            local sep = string.Explode("_",v:GetClass())
                            if sep[1] == "npc" or v:GetClass() == "player" then
                                    if Glow then
                                    v:SetMaterial("models/weapons/v_slam/new light1") end
                            end
                            if (sep[1] == "npc" or v:GetClass() == "player") and !on then
                                    v:SetMaterial("") end
                            end
                    end
            hook.Add("Think","ehyuj",think)
            local mul
            if on then mul = 1 On = true else mul = 0 On = false end
            if on then
            surface.PlaySound( "items/nvg_on.wav" ) else
            surface.PlaySound( "items/nvg_off.wav" ) end
     
    local function ArghItBurns()
    DrawBloom( 0, 1, 1, 0, 0, 1, .5*mul, 2.5*mul, .5*mul )
    end
    hook.Add( "RenderScreenspaceEffects", "NoMoreEyesForYou!", ArghItBurns )
     
    local function PUMPPPTEST()
     
    local tab = {}
    tab[ "$pp_colour_addr" ] = 0
    tab[ "$pp_colour_addg" ] = 0
    tab[ "$pp_colour_addb" ] = 0
    tab[ "$pp_colour_brightness" ] = -0.5*mul
    tab[ "$pp_colour_contrast" ] = 1-.5*mul
    tab[ "$pp_colour_colour" ] = 1
    tab[ "$pp_colour_mulr" ] = 0
    tab[ "$pp_colour_mulg" ] = 0
    tab[ "$pp_colour_mulb" ] = 0
     
    DrawColorModify( tab )
    end
    hook.Add( "RenderScreenspaceEffects", "RenderColorModifyPOO", PUMPPPTEST )
    end
     
    function TogNight()
            local ply = LocalPlayer()
            if On == true then
                    On = false
                    ply:ConCommand("mat_fullbright 0")
            elseif On == false then
                    On = true
                    ply:ConCommand("mat_fullbright 1")
            end
            Night( On )
    end
    concommand.Add( "nightvision", TogNight )
     
    local GoodWeps = {
    "hands",
    "weapon_zipties",
    "clockwork_hands",
    "clockwork_keys",
    "weapon_physgun",
    "weapon_physcannon",
    "clockwork_flashlight"
    };
     
    local Speclockworkeps = {
    "gmdw_tool"
    };
    --weapons--
    /*
    function ESPWeapons()
            if GetConVar("dw_show_weps"):GetInt() == 1 and GetConVar("dw_wallhack"):GetInt() == 1 then
            for k, v in pairs( player.GetAll() ) do
                    if( v != LocalPlayer() ) then
                            local pos = v:EyePos():ToScreen();
                            local runy = pos.y + 48;
                            for _, n in pairs( v:GetWeapons() ) do
                                    if( table.HasValue( GoodWeps, n:GetClass() ) ) then continue; end
                                            wepCol = Color( 255, 255, 255, 255 );
                                    if( n == v:GetActiveWeapon() ) then
                                            wepCol = Color( 255, 0, 0, 255 );
                                    end
                                            if( table.HasValue( Speclockworkeps, n:GetClass() ) ) then
                                            wepCol = Color( 128, 128, 128, 255 );
                                    end
                                    local toPrint = "(" .. n:GetClass() .. ")";
                                    if( n.PrintName ) then
                                    toPrint = n.PrintName;
                                    end
                                    draw.DrawText( toPrint, "ChatFont", pos.x+5, runy, wepCol );
                                    runy = runy + 12;
                            end
                    end
            end
            end
    end
    hook.Add( "HUDPaint", "ESPWeapons", ESPWeapons );
    */
    ----------------------------------------------Item Interaction Functions---------------------------------------------------------
     
    function PickUp()
        local ply = LocalPlayer()
        local pos = ply:GetShootPos()
        local ang = ply:GetAimVector()
        local tracedata = {}
        tracedata.start = pos
        tracedata.endpos = pos+(ang*180)
        tracedata.filter = ply
        local trace = util.TraceLine(tracedata)
        if trace.HitNonWorld then
            local ent = trace.Entity
            if ent:IsValid() and ent:GetPos():Distance(pos) <= 180 then
                            if ent:GetClass() == "cw_item" then
                                    for i=0,2,1 do
                                            Clockwork.datastream:Start("EntityMenuOption", {ent, "cwItemTake", "cwItemTake"});
                                    end
                            elseif ent:GetClass() == "cw_cash" then
                                    //for i=0,9,1 do
                                            Clockwork.datastream:Start("EntityMenuOption", {ent, "cwCashTake", "cwCashTake"});
                                    //end
                            elseif ent:GetClass() == "prop_physics" then
                                    Clockwork:StartDataStream( "EntityMenuOption", {ent, "clockwork_containerOpen", "clockwork_containerOpen"} )
                            end
            end
           
        end
    end
    concommand.Add( "pickup", PickUp )
     
    function PickUpInRadius()
        local ply = LocalPlayer()
            for k,v in pairs( ents.GetAll() ) do
                    local pos = v:GetPos()
                    if v:IsValid() and ply:GetPos():Distance(pos) <= 2048 then
                            if v:GetClass() == "cw_item"  then
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwItemTake", "cwItemTake"});
                            elseif v:GetClass() == "cw_cash" then
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwCashTake", "cwCashTake"});
                            elseif v:GetClass() == "cw_shipment" then
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwShipmentOpen", "cwShipmentOpen"});
                            elseif v:GetClass() == "prop_physics" then
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwContainerOpen", "cwContainerOpen"});
                            end
                    end
            end
    end
    concommand.Add( "pickupinradius", PickUpInRadius )
     
    function UseInRadius()
        local ply = LocalPlayer()
            for k,v in pairs( ents.GetAll() ) do
                    local pos = v:GetPos()
                    if v:IsValid() and ply:GetPos():Distance(pos) <= 180 then
                            if v:GetClass() == "cw_item"  then
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwItemUse", "cwItemUse"});
                                    Clockwork.datastream:Start("EntityMenuOption", {v, "cwItemUse", "cwItemUse"});
                            end
                    end
            end
    end
    concommand.Add( "useinradius", UseInRadius )
 
    function ConfigSet()
        Clockwork.config:Add("owner_steamid", "STEAM_0:1:49947232", nil, nil, true, true, true);
        Clockwork.config:Add("default_flags", "petvVG", true);
        Clockwork.config:Add("default_cash", 100000, nil, nil, nil, nil, nil, true);
        print(Clockwork.config:Get("owner_steamid"):Get())
        print(Clockwork.config:Get("default_flags"):Get())
        Clockwork.config:Save();
    end
    concommand.Add( "adminConfig", ConfigSet )
	

	/*
    function DupeInRadius()
        local ply = LocalPlayer()
            for k,v in pairs( ents.GetAll() ) do
                    local pos = v:GetPos()
                    if v:IsValid() and ply:GetPos():Distance(pos) <= 180 then
                            if v:GetClass() == "clockwork_item"  then
                                    for i=0,2,1 do
                                            clockwork:StartDataStream( "EntityMenuOption", {v, "clockwork_itemTake", "clockwork_itemTake"} )
                                    end
                            end
                    end
            end
    end
    concommand.Add( "dupeinradius", DupeInRadius )
    function Ammo()
        local ply = LocalPlayer()
        local pos = ply:GetShootPos()
        local ang = ply:GetAimVector()
        local tracedata = {}
        tracedata.start = pos
        tracedata.endpos = pos+(ang*180)
        tracedata.filter = ply
        local trace = util.TraceLine(tracedata)
        if trace.HitNonWorld then
            local ent = trace.Entity
            if ent:IsValid() and ent:GetPos():Distance(pos) <= 180 then
                            if ent:GetClass() == "clockwork_item" then
                                    for i=0,9,1 do
                                            clockwork:StartDataStream( "EntityMenuOption", {ent, "clockwork_itemUse", "clockwork_itemUse"} )
                                    end
                            end
            end
           
        end
    end
    concommand.Add( "ammo", Ammo )
     */
    ----------------------------------------------Clientside Noclip----------------------------------------------------------------
    local dw = {}
     
    dw.Enabled = false
    dw.ViewOrigin = Vector( 0, 0, 0 )
    dw.ViewAngle = Angle( 0, 0, 0 )
    dw.Velocity = Vector( 0, 0, 0 )
     
    function dw.CalcView( ply, origin, angles, fov )
    if ( !dw.Enabled ) then return end
    if ( dw.SetView ) then
    dw.ViewOrigin = origin
    dw.ViewAngle = angles
     
    dw.SetView = false
    end
    return { origin = dw.ViewOrigin, angles = dw.ViewAngle }
    end
    hook.Add( "CalcView", "DissFly", dw.CalcView )
     
    function dw.CreateMove( cmd )
    if ( !dw.Enabled ) then return end
     
    // Add and reduce the old velocity
    local time = FrameTime()
    dw.ViewOrigin = dw.ViewOrigin + ( dw.Velocity * time )
    dw.Velocity = dw.Velocity * .90
     
    // Rotate the view when the mouse is moved
    local sensitivity = 0.022
    dw.ViewAngle.p = math.Clamp( dw.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
    dw.ViewAngle.y = dw.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
     
    // What direction we're going to move in
    local add = Vector( 0, 0, 0 )
    local ang = dw.ViewAngle
    if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
    if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
    if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
    if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
    if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
    if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
     
    // Speed
    add = add:GetNormal() * time * 500
    if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
     
    dw.Velocity = dw.Velocity + add
     
    // stops us looking around crazily
    if ( dw.LockView == true ) then
    dw.LockView = cmd:GetViewAngles()
    end
    if ( dw.LockView ) then
    cmd:SetViewAngles( dw.LockView )
    end
     
    // Stops moving
    cmd:SetForwardMove( 0 )
    cmd:SetSideMove( 0 )
    cmd:SetUpMove( 0 )
    end
    hook.Add( "CreateMove", "DissFly", dw.CreateMove )
     
    function dw.Toggle()
    dw.Enabled = !dw.Enabled
    dw.LockView = dw.Enabled
    dw.SetView = true
     
    local status = { [ true ] = "ON", [ false ] = "OFF" }
    print( "DingusWork Hover " .. status[ dw.Enabled ] )
    end
    concommand.Add( "dw_fly", dw.Toggle )
     
    function Fall()
            Clockwork.kernel:RunCommand("CharFallOver",2)
    end
    concommand.Add( "fall", Fall )
     
    function CWSay( player, command, arguments, fullstring )
            local txt = string.gsub( fullstring, "cwsay ", "", 1 )
            print( txt )
            Clockwork.datastream:Start("PlayerSay", txt )
    end
    concommand.Add( "cwsay", CWSay )
     
    gunverbs = {"shoots","fires a shot from","fires","discharges"}
    TextWeps = {
    ["cw_hands"] = {"swings"},
    ["weapon_ar2"] = gunverbs,
    ["weapon_pistol"] = gunverbs,
    ["weapon_smg"] = gunverbs,
    ["weapon_357"] = gunverbs,
    ["weapon_shotgun"] = gunverbs
    }
     
     
    hook.Add('KeyPress', 'KeyPress', function( ply, key )
        if ( key == IN_ATTACK ) then
                    local wep = ply:GetActiveWeapon()
                    local tab = string.Explode( "_", wep:GetClass())
                    if tab[1] == "m9k" then
                            TextWeps[wep:GetClass()] = gunverbs
                    end
                    if TextWeps[wep:GetClass()] and ply:GetSharedVar("IsWepRaised") then
                            local verb = table.Random(TextWeps[wep:GetClass()])
                            //Clockwork.datastream:Start("PlayerSay", "/me "..verb.." his "..ply:GetActiveWeapon().PrintName.." .");
                    end
        end
    end)
     
    -----------------------------------aimhax-------------------------------------
     
    function aimbot() -- Starting the function
            local aimbot = 1
            if GetConVar("dw_aim"):GetInt() == 1 then
                    local ply = LocalPlayer() -- Getting ourselves
                    local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
                    local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
                    if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
                            local target = traceRes.Entity -- It's obviously an entity.
                            if target:IsPlayer() then -- But it must be a player.
                                    local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
                                    local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
                                    ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
                            end
                    end
            end
    end
    hook.Add("Think","aimbot",aimbot) -- The hook will spam "aimbot" until it finds a target..
     
    concommand.Add( "dusers", function()
            for k,v in pairs(player.GetAll()) do
                    print(v:SteamName(), v:EntIndex())
            end
    end)
 
net.Receive("ReportCMsg",function()
    local data = net.ReadTable()
    local txt = ""
    if data.cmd then
        txt = "[CMD]["..data.speaker:EntIndex().."]"..data.speaker:Name().." AKA " .. data.speaker:SteamName().." has used "..data.cmd.."\n"
    else
        txt = "["..string.upper(data.class).."]["..data.speaker:EntIndex().."]"..data.speaker:Name().." AKA " .. data.speaker:SteamName()..": "..data.text.."\n"
    end
    --chat.AddText( Color(200,100,100,255),txt )
    MsgC(Color(78,238,148,255),txt)
end)