--[[
	Product:	Odius ( former MSBot/ShittyHack )
	State:		Working Beta
	Author:		noPE
	Credits:	HL-SDK 			- Help with various stuff related to Source engine, cool guy in general
				UNKNOWNFILE 	- Same as HLSDK
				kolbybrooks 	- Random hook name and stuff
				C0BRA 			- hook.Call and concommand.Run override help
				HelioS 			- ArtificialAiming crosshair I stole
				OGC 			- ESP box
				raBBish/q3k		- Detours
				fr1kin			- Menu shit
				aVoN			- gmcl_syshack
				victormeriqui	- Various stuff, general cool guy
				
	TODO:		Menu
				Better ESP ._.
				Silent Aim
]]

-- include and require some shit --
/*
include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )
*/

if !hack || type( hack ) != "table" then
	require ( "odin" )
end

if !thor || type( thor ) != "table" then
	require ( "thor" )
end

-- asdf --
local math 					= math
local string 				= string
local debug 				= debug
local table 				= table
local pcall 				= pcall
local error 				= error
local ErrorNoHalt 			= ErrorNoHalt
local MsgN 					= MsgN
local Msg 					= Msg
local print 				= print
local surface				= surface
local util 					= util
local type 					= type
local RunConsoleCommand 	= RunConsoleCommand
local CreateClientConVar 	= CreateClientConVar
local CreateConVar 			= CreateConVar
local pairs 				= pairs
local ipairs 				= ipairs
local SortedPairs 			= SortedPairs

-- Tables --
local Odius = {}
Odius.Funcs = {}
Odius.Detours = {}
Odius.Detours.List = {}
Odius.Hook = {}
Odius.Hooks = {}
Odius.IPList = {}
Odius.TraitorList = {}
Odius.Concommand = {}
Odius.Concommands = {}
Odius.NoSpread = {}
Odius.Friends = {}
Odius.FilterEnts = { LocalPlayer() }
Odius.NormalSpreadCones = {
		["weapon_cs_base"]	 = true,
		["darkland_base"]	 = true,
		["weapon_tttbase"]	 = true,
		["kermite_base"]	 = true,
		["kermite_base2"]	 = true,
		["weapon_real_base"] = true
}
Odius.HL2Cones = {
		["#HL2_SMG1"]        = Vector( 0.04362, 0.04362, 0.04362 ),
		["#HL2_Pistol"]      = Vector( 0.0100, 0.0100, 0.0100 ),
		["#HL2_Pulse_Rifle"] = Vector( 0.02618, 0.02618, 0.02618 )
}
Odius.TraitorWeps = {
		["weapon_ttt_c4"]		= true,
		["weapon_ttt_flaregun"]	= true,
		["weapon_ttt_knife"]	= true,
		["weapon_ttt_phammer"]	= true,
		["weapon_ttt_push"]		= true,
		["weapon_ttt_radio"]	= true,
		["weapon_ttt_sipistol"]	= true,
		["weapon_ttt_teleport"]	= true
}
Odius.CheatModules = {
		["odin"] 		= true,
		["thor"]		= true
}

-- Even more locals --
Odius.Aim_Target = nil
Odius.Aim_Locked = false
Odius.Aim_Aiming = false
Odius.Zoom_Enabled = false
Odius.CalcView_RealAngle = Angle( 0, 0, 0 )
Odius.SpinBotAngle = Angle( 0, 0, 0 )
Odius.ConstantNoSpreadAngle = Angle( 0, 0, 0 )


/***************************************************
		---		ANTICHEAT BYPASSES HERE		---
***************************************************/
/*
Odius.Funcs.CallHook = hook.Call

function hook.Call( name, gm, ... )
	for k, tbl in pairs( Odius.Hooks ) do
		if tbl.name == name then
			if ... == nil then
				ret = tbl.func()
			else
				ret = tbl.func( ... )
			end
			
			if ret != nil then // this is so we dont always return a value, EG HUDPaint should not have a return unless overidden
				return ret
			end
		end
	end
	
	return Odius.Funcs.CallHook( name, gm, ... )
end
*/
function Odius.Funcs.AddHook( name, id, func )
	Odius.Hooks[id] = 	{
							name = name,
							func = func
	}
end
/*
Odius.Funcs.RunConCommand = concommand.Run

function concommand.Run( pl, name, ... )
	local tbl = Odius.Concommands[name]
	
	if tbl != nil then
		return tbl.func( pl, name, ... )
	else
		return Odius.Funcs.RunConCommand( pl, name, ... )
	end
end
*/
function Odius.Funcs.AddConsoleCommand( name, func, afunc, help )
	AddConsoleCommand( name, help )
	Odius.Concommands[name] = 	{ 
									func = func,
									afunc = afunc,
									help = help
	}
end

/***************************************************
	---				LOL DETOURS				---
***************************************************/
-- This is how I roll --
function Odius.Detours:DetourFunc( old, new )
	Odius.Detours.List[new] = old
	
	return new
end
/*
require = Odius.Detours:DetourFunc( require, function ( module )
	if Odius.CheatModules[module] then
		return
	end
	
	return Odius.Detours.List[require]( module )
end )
*/
usermessage.IncomingMessage = Odius.Detours:DetourFunc( usermessage.IncomingMessage, function( name, um, ... )
	if( name == "ttt_role" ) then
		Odius.TraitorList = {}
		
		MsgN( "[Odius] Round end, clearing traitors..." )
	end
	
	return Odius.Detours.List[usermessage.IncomingMessage]( name, um, ... )
end )

debug.getinfo = Odius.Detours:DetourFunc( debug.getinfo, function( func, penis )
	return Odius.Detours.List[debug.getinfo]( Odius.Detours.List[func] or func, penis )
end )

hook.Call = Odius.Detours:DetourFunc( hook.Call, function( name, gm, ... )
	for k, tbl in pairs( Odius.Hooks ) do
		if tbl.name == name then
			if ... == nil then
				ret = tbl.func()
			else
				ret = tbl.func( ... )
			end
			
			if ret != nil then
				return ret
			end
		end
	end
	
	return Odius.Detours.List[hook.Call]( name, gm, ... )
end )

concommand.Run = Odius.Detours:DetourFunc( concommand.Run, function ( pl, name, ... )
	local tbl = Odius.Concommands[name]
	
	if tbl != nil then
		return tbl.func( pl, name, ... )
	else
		return Odius.Detours.List[concommand.Run]( pl, name, ... )
	end
end )

/***************************************************
	---				CORE CODENS				---
***************************************************/
-- Backing up some LUA shit --
Odius.Hook.Remove = hook.Remove

-- Copy all SysHack stuff into a local table --
if package.loaded.odin then
	Odius.SysHack = table.Copy( hack )
	_G.hack = nil
	package.loaded.odin = nil
end

-- Copy all Thor stuff into a local table, for security reasons --
if package.loaded.thor then
	Odius.Thor = table.Copy( thor )
	_G.thor = nil
	package.loaded.thor = nil
end

-- Local CVars --
local Aim_AutoShoot 			= CreateClientConVar( "odius_aim_autoshoot", 0, true, false )
local Aim_FOV					= CreateClientConVar( "odius_aim_fov", 8, true, false )
local Aim_Mode					= CreateClientConVar( "odius_aim_mode", "bone", true, false )
local Aim_VecOffset				= CreateClientConVar( "odius_aim_vecoffset", 30, true, false )
local Aim_NoRecoil 				= CreateClientConVar( "odius_aim_norecoil", 1, true, false )
local Aim_NoSpread 				= CreateClientConVar( "odius_aim_nospread", 1, true, false )
local Aim_ConstNoSpread 		= CreateClientConVar( "odius_aim_nospread_const", 1, true, false )
local Aim_Deathmatch 			= CreateClientConVar( "odius_aim_deathmatch", 1, true, false )
local Aim_Prediction 			= CreateClientConVar( "odius_aim_prediction", 1, true, false )
local Aim_ProjectilePredict 	= CreateClientConVar( "odius_aim_predictprojectile", 0, true, false )
local Aim_ProtectBuddies 		= CreateClientConVar( "odius_aim_ignorebuddies", 1, true, false )
local Aim_SilentAim				= CreateClientConVar( "odius_aim_silentaim", 0, true, false )
local Aim_SmoothAim				= CreateClientConVar( "odius_aim_smoothfactor", 0, true, false )
local ESP 						= CreateClientConVar( "odius_esp_enabled", 1, true, false )
local ESP_Name	 				= CreateClientConVar( "odius_esp_name", 1, true, false )
local ESP_OGC_Box 				= CreateClientConVar( "odius_esp_ogcbox", 1, true, false )
local Wallhack 					= CreateClientConVar( "odius_wallhack", 1, true, false )
local PLights					= CreateClientConVar( "odius_playerlights", 1, true, false )
local Misc_Spinbot 				= CreateClientConVar( "odius_misc_spin", 0, true, false )
local Misc_ULXUngag 			= CreateClientConVar( "odius_misc_ungag", 0, true, false )

-- Empty vars --
local Aim_Enabled

-- Yay fonts --
surface.CreateFont( "CenterPrintText" , 17 , 700 , true , false , "ESP_Name", false, true ) 

local function RandomString()
	local j, r = 0, ""
		
	for i = 1, math.random( 3, 19 ) do
		j = math.random( 65, 116 )
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char( j )
	end
	return r
end

local function FillRGBA( x, y, w, h, col ) 
	surface.SetDrawColor( col.r, col.g, col.b, 200 )
	surface.DrawRect( x, y, w, h )
end

/***************************************************
	Method:		AddHook
	Purpose:	Inserts a hook into a table for
				later use and adds it to the game
***************************************************/
function Odius:AddHook( h, f )
	local n = RandomString()
		
	Odius.Funcs.AddHook( h, n, f )
end

/***************************************************
	Method:		AddConcommand
	Purpose:	Adds a concommand
***************************************************/
function Odius:AddConcommand( concomm, func )
	Odius.Funcs.AddConsoleCommand( concomm, func )
end

/***************************************************
	Method:		GetHeadPos
	Purpose:	Get head position of an entity
***************************************************/
function Odius:GetHeadPos( ent )
	local model = ent:GetModel() or ""
	
    if model:find( "crow" ) or model:find( "seagull" ) or model:find( "pigeon" ) then
        return ent:LocalToWorld( ent:OBBCenter() + Vector( 0, 0, -5 ) )
    elseif ent:GetAttachment( ent:LookupAttachment( "eyes" ) ) ~= nil then
        return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos
    else
        return ent:LocalToWorld( ent:OBBCenter() )
    end
end

/***************************************************
	Method:		GetVecPos
	Purpose:	Get the vector position of an entity
				( alt aimbot mode )
***************************************************/
function Odius:GetVecPos( ent )
	return ent:LocalToWorld( ent:OBBCenter() + Vector( 5, 0, Aim_VecOffset:GetInt() ) )
end

/***************************************************
	Method:		DrawBox
	Purpose:	Draws a box around an entity
***************************************************/
local maxesphealth = nil
function Odius:DrawBox( ent, color )
	if ent:Health() <= 0 || !ent:Alive() then return end
	
	local headpos, headang = Odius:GetHeadPos( ent ):ToScreen()
	
	if maxesphealth == nil then maxesphealth = 1 end
	
	if ent:Health() > maxesphealth then maxesphealth = ent:Health() end
	
	if maxesphealth <= 0 then
		maxesphealth = nil
	end
	
	/*
	OGC Box
	
	float distance = vPlayers[ax].distance/22.0f;
	int   boxradius = (300.0*90.0) / (distance*fCurrentFOV);
	*/
	local entpos = ent:GetPos()
	local distance = entpos:Distance( LocalPlayer():GetPos() ) / 22.0
	local radius = ( 300.0 * 90.0 ) / ( distance * LocalPlayer():GetFOV() )
	local radius2 = radius * 2
	local custcol = Color( 64, 144, 255 )
	local obbcenter = ent:LocalToWorld( ent:OBBCenter() ):ToScreen()
	local x, y = obbcenter.x, obbcenter.y
	
	FillRGBA( x - radius + 2, y - radius, radius2 - 2, 2, color )
	FillRGBA( x - radius, y - radius, 2, radius2, color )
	FillRGBA( x - radius, y + radius, radius2, 2, color )
	FillRGBA( x + radius, y - radius, 2, radius2 + 2, color )
	
	/*
	surface.SetDrawColor( color )
	surface.DrawRect( headpos.x + 10, headpos.y - 21, 8, 8 )
	
	surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
	surface.DrawLine( headpos.x, headpos.y, headpos.x + 9, headpos.y - 9 )
	surface.DrawLine( headpos.x + 9, headpos.y - 9, headpos.x + 50, headpos.y - 9 )
	
	
	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	surface.DrawRect( headpos.x - 21, headpos.y - 5, 42, 5 )
	
	surface.SetDrawColor( Color( 255 - ( 255 * ( ent:Health() / maxesphealth ) ), 255 * ( ent:Health() / maxesphealth ), 0, 255 ) )
	surface.DrawRect( headpos.x - 20, headpos.y - 4, 40 * ( ent:Health() / maxesphealth ), 3 )
	*/
end

/***************************************************
	Method:		DrawESPInfo
	Purpose:	Draws ESP information based on
				user's likings
***************************************************/
function Odius:DrawESPInfo( ent, color )
	if ent:Health() <= 0 || !ent:Alive() then return end
	
	local entpos = ent:GetPos()
	local distance = entpos:Distance( LocalPlayer():GetPos() ) / 22.0
	local radius = ( 300.0 * 90.0 ) / ( distance * LocalPlayer():GetFOV() )
	local radius2 = radius * 2
	local custcol = Color( 64, 144, 255 )
	local obbcenter = ent:LocalToWorld( ent:OBBCenter() ):ToScreen()
	local x, y = obbcenter.x, obbcenter.y
	
	local headpos, headang = Odius:GetHeadPos( ent ):ToScreen()
	--if GAMEMODE && GAMEMODE.Name && string.find( GAMEMODE.Name , "Trouble in Terror" )
	if ent:IsPlayer() then
		draw.SimpleText( tostring( ent:Nick() ) , "ESP_Name" , ( x - radius ) - 2, y, Color( 0, 255, 0, 255 ), 2, 1 )
	end
end

/***************************************************
	Method:		SetVAngles
	Purpose:	Sets player viewangles
***************************************************/
function Odius:SetVAngles( cmd, angs )
	return _R.CUserCmd.SetViewAngles( cmd, angs )
end

/***************************************************
	Method:		GetVAngles
	Purpose:	Gets player viewangles
***************************************************/
function Odius:GetVAngles( cmd )
	return _R.CUserCmd.GetViewAngles( cmd )
end

/***************************************************
	Method:		SmoothAngleMovement
	Purpose:	Returns smooth aim angle for legit
				looking aiming
***************************************************/
function Odius:SmoothAngleMovement( ang )
	local current = LocalPlayer():GetAimVector():Angle()
	local speed = Aim_SmoothAim:GetInt()
	
	current.p = math.ApproachAngle( math.NormalizeAngle( current.p ), math.NormalizeAngle( ang.p ), speed * FrameTime() )
	current.y = math.ApproachAngle( math.NormalizeAngle( current.y ), math.NormalizeAngle( ang.y ), speed * FrameTime() )
	current.r = 0
				
	return Angle( current.p, current.y, current.r )
end

/***************************************************
	Method:		PredictProjectile
	Purpose:	Make HLSDK m@d
***************************************************/
function Odius:PredictProjectile( pos , pl )
	if ValidEntity( pl ) && type( pl:GetVelocity() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon && ( ValidEntity( LocalPlayer():GetActiveWeapon() ) && LocalPlayer():GetActiveWeapon():GetClass() ) )
		
		if weapon && Odius.Projectiles[weapon] then
			local time = ( distance / Odius.Projectiles[weapon] ) + 0.05
			
			return pos + pl:GetVelocity() * time
		elseif weapon && weapon == "weapon_ttt_knife" then
		--	  position = gravity / ( distance / 10 )
			local time = 600 / ( distance / 10 )
			
			-- TODO: formula
		end
		
		return pos
	end
	
	return pos
end

/***************************************************
	Method:		GetCone
	Purpose:	Get current weapon's spread cone
***************************************************/
function Odius:GetCone( wep )
	local cone = wep.Cone
	
	if not cone and type( wep.Primary ) == "table" and type( wep.Primary.Cone ) == "number" then
		cone = wep.Primary.Cone
	end
	
	if not cone then cone = 0 end
	if type( wep.Base ) == "string" and Odius.NormalSpreadCones[wep.Base] then return cone end
	if wep.Base == "weapon_mad_base_sniper" and wep:GetDTBool( 3 ) then cone = cone * wep.data.Cone return cone end
	if wep.Base == "weapon_cs_base2" then cone = cone + 0.05 return cone end
	
	if( ValidEntity( wep ) && Odius.HL2Cones[wep:GetPrintName()] ) then cone = Odius.HL2Cones[wep:GetPrintName()] return cone end
		
	-- FortwarsX --
	if string.find( GAMEMODE.Name, "FortwarsX" ) && wep.Base == "weapon_fw_base" then
		if ( LocalPlayer():GetVelocity():Length() > 20 ) then
			cone = cone + 0.025
			return cone
		end
		
		if ( !LocalPlayer():IsOnGround() ) then
			cone = cone + 0.04
			return cone
		end
		
		if ( LocalPlayer():Crouching() or LocalPlayer():GetNetworkedBool( "Ironsights", false ) ) then
			cone = cone / 2
			return cone
		end
		
		return cone
	end
	
	return cone or 0
end

/***************************************************
	Method:		IsEntVisible
	Purpose:	Checks if an entity is visible by
				the local player
***************************************************/
function Odius:IsEntVisible( ent )
	if ent == NULL then return end
	
	local trace = {}
    trace.start = LocalPlayer():GetShootPos()
    trace.endpos = Odius:GetHeadPos( ent )
    trace.filter = { LocalPlayer(), ent }
    trace.mask = 1174421507
	
    local tr = util.TraceLine( trace )
	
    return tr.Fraction >= 0.99 and true or false   
end

/***************************************************
	Method:		PlayerCanSee
	Purpose:	Returns wether or not a player can
				see another player/entity
***************************************************/
function Odius:PlayerCanSee( ply, obj )
	if not IsValid( ply ) or not ply:IsPlayer() then return false end
	if not obj then return false end

	local posmin, posmax = 0, 0

	if type( obj ) == "vector" then
		posmin, posmax = obj, obj
	else
		if !obj:IsValid() then return false end
		posmin, posmax = obj:GetPos() + obj:OBBMaxs(), obj:GetPos() + obj:OBBMins()
	end

	if CLIENT then
		return ( posmin:ToScreen().visible + posmax:ToScreen().visible ) > 0
	else
		local eye = ply:GetPos() + ply:GetViewOffset()

		local tMin = util.TraceLine( { start=eye, endpos=posmin } )
		-- If it didnt hit, it must be visible! And if it did hit, and it hit our Entity then we can see it.
		if( !tMin.Hit || ( tMin.Hit && tMin.Entity == obj ) ) then return true end

		local tMax = util.TraceLine( { start=eye, endpos=posmax } )
		if( !tMax.Hit || ( tMax.Hit && tMax.Entity == obj ) ) then return true end

		return false
	end

	return false
end

/***************************************************
	Method:		AddToFriends
	Purpose:	Add a player to aimbot's ignore list
***************************************************/
function Odius:AddToFriends( ent )
	if !table.HasValue( Odius.Friends, ent ) then
		table.insert( Odius.Friends, ent )
		Odius.Thor.Notify( Color( 0, 255, 0, 255 ), ent:Nick() .. " will be ignored by the aimbot." )
	end
end

/***************************************************
	Method:		ValidTarget
	Purpose:	Perform a shitload of checks and
				select a desired target
***************************************************/
function Odius:ValidTarget( e )	
	if ( !ValidEntity( e ) ) || ( e == LocalPlayer() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end
		
	local m = e:GetMoveType()
	
	if ( m == MOVETYPE_NONE ) then return false end
	
	if ( e:IsPlayer() ) then
		if ( !e:Alive() || e:Health() <= 0 ) || ( m == ( MOVETYPE_OBSERVER || MOVETYPE_NONE ) ) || ( e:Team() == LocalPlayer():Team() && !Aim_Deathmatch:GetBool() ) || ( e:GetFriendStatus() == "friend" && Aim_ProtectBuddies:GetBool() ) /*|| ( e:IsTraitor() && !Traitors:GetBool() )*/ then return false end
	end
	
	if ( Aim_FOV:GetInt() != 180 || Aim_FOV:GetInt() != 0 ) then
		local a = LocalPlayer():GetAimVector():Angle()
		local o = { p, y } -- s0 ghett0
		local t = ( Odius:GetHeadPos( e ) - LocalPlayer():GetShootPos() ):Angle()
		o.p = math.abs( math.NormalizeAngle( a.p - t.p ) )
		o.y = math.abs( math.NormalizeAngle( a.y - t.y ) )
		
		if ( o.p >= Aim_FOV:GetInt() || o.y >= Aim_FOV:GetInt() ) then return false end
	end
		
	return true
end

/***************************************************
	Method:		GetClosestTarget
	Purpose:	Finds a target that is closest to
				crosshair
***************************************************/
function Odius.GetClosestTarget()
    local pos = LocalPlayer():EyePos()
    local ang = LocalPlayer():GetAimVector()
    local closest = { 0, 0 }
	
    for k, ent in pairs( player.GetAll() ) do
		if Odius:ValidTarget( ent ) && Odius:IsEntVisible( ent ) then
			local diff = ( ent:EyePos() - pos ):Normalize()
		
			diff = diff - ang
			diff = diff:Length()
			diff = math.abs( diff )
		
			if ( diff < closest[2] ) or ( closest[1] == 0 ) then
				closest = { ent, diff }
			end
		end
    end
	
	return closest[1]
end

/***************************************************
	Function:		ESP
	Purpose:		Draws ESP information around
					entities, based on player's
					likings
***************************************************/
function Odius.ESP()
	if ESP then
		for k, v in pairs( ents.GetAll() ) do
			if ValidEntity( v ) && v:IsPlayer() && v != LocalPlayer() then
				if ESP_Name:GetBool() then
					Odius:DrawESPInfo( v, Color( 255, 255, 255, 255 ) )
				end
				
				if ESP_OGC_Box:GetBool() then
					if Odius.TraitorList[v] then
						Odius:DrawBox( v, Color( 255, 100, 0, 255 ) )
					else
						Odius:DrawBox( v, team.GetColor( v:Team() ) )
					end
				end
			end
		end
	end
end

/***************************************************
	Function:		DebugPanel
	Purpose:		Gee, I wonder
***************************************************/
function Odius.DebugPanel()
	draw.SimpleText( "Odius Debug Panel", "BudgetLabel", 5, ( ScrH() / 2 ), color_white )
	
	local displaycone = Odius:GetCone( LocalPlayer():GetActiveWeapon() )
	
	if type( displaycone ) == "Vector" then
		displaycone = displaycone.x
	end
	
	draw.SimpleText( "Current weapon cone: " .. displaycone, "BudgetLabel", 5, ( ScrH() / 2 ) + 15, color_white )
end
/***************************************************
	Function:		Visuals
	Purpose:		Wallhacks, chams, etc.
***************************************************/
function Odius.Visuals()
	-- Wallhack --
	if Wallhack:GetBool() then
		for k, v in pairs ( player.GetAll() ) do
			cam.Start3D( EyePos(), EyeAngles() )
				if v:IsPlayer() && v != LocalPlayer() && v:Health() > 0 && v:Alive() && v:GetMoveType() != MOVETYPE_OBSERVER then
					local mat = v:GetMaterial()
					local tc = team.GetColor( v:Team() )
					
					cam.IgnoreZ( true )
					v:DrawModel()
					cam.IgnoreZ( false )
				end
			cam.End3D()
		end
	end
	
	-- Player lights --
	if PLights:GetBool() then
		for k, nig in pairs( player.GetAll() ) do
			if nig:Alive() && nig != LocalPlayer() then
				local light = DynamicLight( nig:EntIndex() )
				
				if light then 
					local color = team.GetColor( nig:Team() )
					
					light.Pos = nig:GetPos() + Vector( 0, 0, 10 )
					light.r = color.r
					light.g = color.g
					light.b = color.b
					light.Brightness = 12
					light.Decay = 64 * 5
					light.Size = 64
					light.DieTime = CurTime() + 1
				end
			end
		end
	end
end

/***************************************************
	Function:		AutoShoot
	Purpose:		Automatically shoot if we have
					a target
***************************************************/
Odius.NextShot = 0
function Odius.AutoShoot()
	if Aim_AutoShoot:GetBool() then
		if Odius.Aim_Aiming && Odius.Aim_Locked && Odius:ValidTarget( Odius.Aim_Target ) && Odius:IsEntVisible( Odius.Aim_Target ) then
			if Odius.NextShot and Odius.NextShot < RealTime() and ValidEntity( LocalPlayer():GetActiveWeapon() ) then
				Odius.Firing = true
				RunConsoleCommand( "+attack" )
				Odius.NextShot = RealTime() + ( LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
			else
				RunConsoleCommand( "-attack" )
				Odius.Firing = false
			end
		elseif Odius.Firing then
			Odius.Firing = false
			RunConsoleCommand( "-attack" )
		end
	end
end

/***************************************************
	Function:		Aimbot
	Purpose:		hurr
***************************************************/
function Odius.Aimbot( ucmd )
	Odius.CalcView_RealAngle = ucmd:GetViewAngles()
	
	if ( !Odius.Aim_Aiming ) then return end
	
	Odius.Aim_Target = Odius.GetClosestTarget()
	
	if ( Odius.Aim_Target == 0 || Odius.Aim_Target == nil ) then
		Odius.Aim_Locked = false
		return
	end
		
	if Odius:ValidTarget( Odius.Aim_Target ) then
		local headpos
		if Aim_Mode:GetString() == "bone" then
			headpos = Odius:GetHeadPos( Odius.Aim_Target )
		elseif Aim_Mode:GetString() == "vector" then
			headpos = Odius:GetVecPos( Odius.Aim_Target )
		end
		
		
		/*
		-- Projectile prediction
		if Aim_ProjectilePredict:GetBool() && Odius.Projectiles[( LocalPlayer():GetActiveWeapon() ):GetClass()] then
			headpos = Odius:PredictProjectile( Odius:GetHeadPos( Odius.Aim_Target ), Odius.Aim_Target )
		else
			headpos = Odius:GetHeadPos( Odius.Aim_Target )
		end
		*/
		
		local shootpos = LocalPlayer():GetShootPos()
		
		-- Player prediction
		if Aim_Prediction:GetBool() then
			shootpos = shootpos + ( Odius.Aim_Target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45 )
		else
			shootpos = LocalPlayer():GetShootPos()
		end
		
		local aimang = ( headpos - shootpos ):Angle()
		
		aimang.p = math.NormalizeAngle( aimang.p )
		aimang.y = math.NormalizeAngle( aimang.y )
			
		if Odius.Aim_Target == LocalPlayer() then
			Odius.Aim_Locked = false
			Odius.Aim_Target = nil
			return
		end
		
		if !Odius:IsEntVisible( Odius.Aim_Target ) then
			Odius.Aim_Locked = false
			Odius.Aim_Target = nil
			return
		end
		
		Odius.Aim_Locked = true
		
		local spreadCone = Odius:GetCone( LocalPlayer():GetActiveWeapon() )
		
		if type( spreadCone ) == "Vector" then
			spreadCone = spreadCone.x
		end
		
		if Aim_NoSpread:GetBool() then
			aimang = Odius.SysHack.CompensateWeaponSpread( ucmd, Vector( -spreadCone, -spreadCone, -spreadCone ), aimang:Forward() ):Angle()
			Odius.CalcView_RealAngle = ( headpos - LocalPlayer():GetShootPos() ):Angle()
		else
			aimang = ( headpos - LocalPlayer():GetShootPos() ):Angle()
		end
		
		aimang.p = math.NormalizeAngle( aimang.p )
		aimang.y = math.NormalizeAngle( aimang.y )
		aimang.r = 0
		
		if Aim_SmoothAim:GetInt() > 0 then
			local smoothang = Odius:SmoothAngleMovement( aimang )
			
			Odius.CalcView_RealAngle = smoothang
			Odius:SetVAngles( ucmd, smoothang )
		else
			Odius:SetVAngles( ucmd, aimang )
		end
	else
		Odius.Aim_Locked = false
		Odius.Aim_Target = nil
	end
end

/***************************************************
	Function:		MovementFuckups
	Purpose:		Various movement related shit
***************************************************/
function Odius.MovementFuckups( ucmd )
end

/***************************************************
	Function:		CalcView
	Purpose:		Corrects local view
***************************************************/
local newfov = math.floor( GetConVarNumber( "fov_desired" ) )
function Odius.CalcView( u, origin, angles, fov )
	if GetViewEntity() != LocalPlayer() then return end
	
	-- No recoil --
	if Aim_NoRecoil:GetBool() then
		if ( LocalPlayer():GetActiveWeapon().Primary ) then LocalPlayer():GetActiveWeapon().Primary.Recoil = 0.0 end
		if ( LocalPlayer():GetActiveWeapon().Secondary ) then LocalPlayer():GetActiveWeapon().Secondary.Recoil = 0.0 end
		
		if Odius.Zoom_Enabled == true then
			newfov = Lerp( 8 * FrameTime(), newfov, 29 )
		else
			newfov = Lerp( 8 * FrameTime(), newfov, math.floor( GetConVarNumber( "fov_desired" ) ) )
		end
		
		return { origin = origin, angles = Odius.CalcView_RealAngle, fov = newfov }
	end
	
	return GAMEMODE:CalcView( u, origin, angles, fov )
end

/***************************************************
	Function:		ULXUngag
	Purpose:		Ungags player if gagged w/ ULX
***************************************************/
function Odius.ULXUngag()
	if ulx && ulx.gagUser then
		if Misc_ULXUngag then
			ulx.gagUser( false )
			
			hook.Remove( "PlayerBindPress", "ULXGagForce" )
			timer.Destroy( "GagLocalPlayer" )
		end
	end
end

/***************************************************
	Function:		TraitorDetect
	Purpose:		Detect traitors and stuff
***************************************************/
function Odius.TraitorDetect()
	for k, v in pairs( Odius.TraitorList ) do
		if !ValidEntity( v ) then
			table.remove( Odius.TraitorList, k )
		end
	end
	
	for k, v in ipairs( player.GetAll() ) do
		if v:Alive() && !table.HasValue( Odius.TraitorList, v ) then
			local wep = v:GetActiveWeapon()
			
			if ValidEntity( wep ) then
				wep = wep:GetClass()
				
				if Odius.TraitorWeps[wep] then
					table.insert( Odius.TraitorList, v )
					chat.AddText( Color( 255, 166, 0 ), "[Odius] ", Color( 255, 10, 10 ), v:Nick() .. " PULLED OUT A TRAITOR WEAPON!" )
				end
			end
		end
	end
end

/***************************************************
	Function:		Crosshair
	Purpose:		Draws a crosshair at the center
					of the screen
***************************************************/
function Odius.Crosshair()
	local x = ScrW() / 2
	local y = ScrH() / 2
 
	surface.SetDrawColor( 255, 255, 0, 255 )
 
	local gap = 0
	local length = 5
 
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
	
	if Odius.Aim_Locked && Odius.Aim_Target != nil then
		surface.DrawOutlinedRect( x - length - 2, y - length - 2, ( length + 2 ) * 2 + 1, ( length + 2 ) * 2 + 1 )
	end
end

/***************************************************
	Function:		IPLogger
	Purpose:		Logs IP addresses, what did you
					think?
***************************************************/
function Odius.IPLogger( name, ip )
	local pnum = #Odius.IPList + 1
	
	Odius.IPList[pnum] = ip
	print( "[Odius] Player " .. name .. " connected! IP: " .. ip )
end

/***************************************************
	Function:		Injector
	Purpose:		Injects scripts using Thor
***************************************************/
function Odius.Injector( ply, command, args )
	if args[1] == "" || args[1] == NULL || args[1] == nil then
		--Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "No file specified for injection." )
	else	
		--Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Injecting " .. args[1] .. " ..." )
		--Odius.Thor.Include( args[1] )
	end
end

/***************************************************
	Function:		PrintTraitors
	Purpose:		Prints all detected traitors in
					console
***************************************************/
function Odius.PrintTraitors()
	for i, p in pairs( Odius.TraitorList ) do
		print( "[TRAITORS] " .. p:Nick() .. " is a traitor." )
	end
end


function Odius.PrintDarkRPMoney()
	for _, player in pairs( player.GetAll() ) do
		MsgN( "Player " .. player:Nick() .. " has $" .. tostring( player:GetNetworkedInt( "money" ) ) .. " cash." )
	end
end

/***************************************************
	Function:		Unload
	Purpose:		Removes all the hooks and empties
					the hook table, unloading the
					hack almost completely
***************************************************/
function Odius.Unload()
	for n, h in pairs ( Odius.Hooks ) do
		local currenthook = string.format( "Removing %s hook [%s]", h, n )
		
	--	Odius.Thor.Notify( Color( 255, 128, 0, 255 ), currenthook )
		Odius.Hook.Remove( h, n )
		Odius.Hooks[n] = nil
	end
	
	Odius.Hooks = {}
end

/***************************************************
	Function:		Reload
	Purpose:		Reloads the hack
***************************************************/
function Odius.Reload()
	--Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Reloading ..." )
	Odius.Unload()
	include( "autorun/client/odius.lua" )
	--Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Reloaded!" )
end

/***************************************************
	Function:		ZoomIn
	Purpose:		Toggles zoom
***************************************************/
local backupsens = GetConVarNumber( "sensitivity" )
function Odius.ZoomIn()
	if Odius.Zoom_Enabled == true then
		Odius.Zoom_Enabled = false
		LocalPlayer():ConCommand( "sensitivity " .. backupsens )
	else
		Odius.Zoom_Enabled = true
		LocalPlayer():ConCommand( "sensitivity 2" )
	end
end

/***************************************************
	Function:		AimbotOn
	Purpose:		Starts the aimbot
***************************************************/
function Odius.AimbotOn( ply, cmd, args )
	Odius.Aim_Aiming = true
end

/***************************************************
	Function:		AimbotOff
	Purpose:		Turns off the aimbot
***************************************************/
function Odius.AimbotOff( ply, cmd, args )
	Odius.Aim_Aiming = false
	Odius.Aim_Target = nil
	Odius.Aim_Locked = false
end

/***************************************************
	---			MENU SHIT STARTS HERE		---
***************************************************/
function Odius:ChangeCategoryState( cat, visible )
	for k, v in pairs( cat ) do
		v:SetVisible( visible )
	end
end



local b_mAim = true
local b_mESP = false
local b_mVis = false
-- SWITCHING TO GAME-BANDIT STYLE MENU --
function Odius.PopupMenu()
	local Derma = {}
	Derma.Aim = {}
	Derma.ESP = {}
	Derma.Vis = {}
	
	-- TESTING --
	function DSlider:PaintNumSlider( panel )
		local w, h = panel:GetSize()
		
		self:DrawGenericBackground( 0, 0, w, h, Color( 255, 255, 255, 20 ) )
		
		surface.SetDrawColor( 0, 0, 0, 200 )
		surface.DrawRect( 3, h/2, w-6, 1 )
	end
	
	local OdiusMenuPanel = vgui.Create( "DFrame" )
	OdiusMenuPanel:SetSize( ScrW(), ScrH() )
	OdiusMenuPanel:SetPos( 0, 0 )
	OdiusMenuPanel:SetTitle( "" )
	OdiusMenuPanel:SetVisible( true )
	OdiusMenuPanel:SetDraggable( false )
	OdiusMenuPanel:ShowCloseButton( true )
	OdiusMenuPanel.Paint = function()
		draw.RoundedBox( 0, 0, 0, 300, OdiusMenuPanel:GetTall(), Color( 0, 0, 0, 200 ) )
		draw.RoundedBox( 0, OdiusMenuPanel:GetWide() - 300, 0, 300, OdiusMenuPanel:GetTall(), Color( 0, 0, 0, 200 ) )
	end
	
	local OdiusAimbotCat = vgui.Create( "DButton", OdiusMenuPanel )
	OdiusAimbotCat:SetPos( ( ScrW() / 2 ) - 263, 30 )
	OdiusAimbotCat:SetSize( 175, 35 )
	OdiusAimbotCat:SetText( "" )
	OdiusAimbotCat.Paint = function()
		draw.RoundedBox( 0, 0, 0, OdiusAimbotCat:GetWide(), OdiusAimbotCat:GetTall(), Color( 0, 0, 0, 255 ) )
		draw.RoundedBox( 0, 0, 0, OdiusAimbotCat:GetWide(), OdiusAimbotCat:GetTall() / 2, Color( 255, 255, 255, 20 ) )
		
		draw.SimpleText( "AIMBOT", "Trebuchet24", OdiusAimbotCat:GetWide() / 2, OdiusAimbotCat:GetTall() / 2, Derma.AimCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	OdiusAimbotCat.DoClick = function()
		Odius:ChangeCategoryState( Derma.Aim, true )
		Odius:ChangeCategoryState( Derma.ESP, false )
		Odius:ChangeCategoryState( Derma.Vis, false )
		
		b_mAim = true
		b_mESP = false
		b_mVis = false
		
		Derma.AimCol = Color( 255, 255, 0 )
		Derma.ESPCol = Color( 255, 255, 255 )
		Derma.VisCol = Color( 255, 255, 255 )
	end
	
	local OdiusESPCat = vgui.Create( "DButton", OdiusMenuPanel )
	OdiusESPCat:SetPos( ( ScrW() / 2 ) - 87, 30 )
	OdiusESPCat:SetSize( 175, 35 )
	OdiusESPCat:SetText( "" )
	OdiusESPCat.Paint = function()
		draw.RoundedBox( 0, 0, 0, OdiusESPCat:GetWide(), OdiusESPCat:GetTall(), Color( 0, 0, 0, 255 ) )
		draw.RoundedBox( 0, 0, 0, OdiusESPCat:GetWide(), OdiusESPCat:GetTall() / 2, Color( 255, 255, 255, 20 ) )
		
		draw.SimpleText( "ESP", "Trebuchet24", OdiusAimbotCat:GetWide() / 2, OdiusAimbotCat:GetTall() / 2, Derma.ESPCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	OdiusESPCat.DoClick = function()
		Odius:ChangeCategoryState( Derma.Aim, false )
		Odius:ChangeCategoryState( Derma.ESP, true )
		Odius:ChangeCategoryState( Derma.Vis, false )
		
		b_mAim = false
		b_mESP = true
		b_mVis = false
		
		Derma.AimCol = Color( 255, 255, 255 )
		Derma.ESPCol = Color( 255, 255, 0 )
		Derma.VisCol = Color( 255, 255, 255 )
	end
	
	local OdiusVisualsCat = vgui.Create( "DButton", OdiusMenuPanel )
	OdiusVisualsCat:SetPos( ( ScrW() / 2 ) + 89, 30 )
	OdiusVisualsCat:SetSize( 175, 35 )
	OdiusVisualsCat:SetText( "" )
	OdiusVisualsCat.Paint = function()
		draw.RoundedBox( 0, 0, 0, OdiusVisualsCat:GetWide(), OdiusVisualsCat:GetTall(), Color( 0, 0, 0, 255 ) )
		draw.RoundedBox( 0, 0, 0, OdiusVisualsCat:GetWide(), OdiusVisualsCat:GetTall() / 2, Color( 255, 255, 255, 20 ) )
	
		draw.SimpleText( "VISUALS", "Trebuchet24", OdiusAimbotCat:GetWide() / 2, OdiusAimbotCat:GetTall() / 2, Derma.VisCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	OdiusVisualsCat.DoClick = function()
		Odius:ChangeCategoryState( Derma.Aim, false )
		Odius:ChangeCategoryState( Derma.ESP, false )
		Odius:ChangeCategoryState( Derma.Vis, true )
		
		b_mAim = false
		b_mESP = false
		b_mVis = true
		
		Derma.AimCol = Color( 255, 255, 255 )
		Derma.ESPCol = Color( 255, 255, 255 )
		Derma.VisCol = Color( 255, 255, 0 )
	end
	
	-- SETUP COLORS AFTER LOAD HERE --
	if b_mAim == true then
		Derma.AimCol = Color( 255, 255, 0 )
		Derma.ESPCol = Color( 255, 255, 255 )
		Derma.VisCol = Color( 255, 255, 255 )
	elseif b_mESP == true then
		Derma.AimCol = Color( 255, 255, 255 )
		Derma.ESPCol = Color( 255, 255, 0 )
		Derma.VisCol = Color( 255, 255, 255 )
	else
		Derma.AimCol = Color( 255, 255, 255 )
		Derma.ESPCol = Color( 255, 255, 255 )
		Derma.VisCol = Color( 255, 255, 0 )
	end
	
	-- AIMBOT --
	Derma.Aim.Label = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.Aim.Label:SetPos( 12, 60 )
	Derma.Aim.Label:SetFont( "HUDNumber2" )
	Derma.Aim.Label:SetTextColor( color_white )
	Derma.Aim.Label:SetText( "AIMBOT" )
	Derma.Aim.Label:SetVisible( b_mAim )
	Derma.Aim.Label:SizeToContents()
	
	Derma.Aim.Label2 = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.Aim.Label2:SetPos( 13, 93 )
	Derma.Aim.Label2:SetFont( "Trebuchet19" )
	Derma.Aim.Label2:SetTextColor( Color( 255, 255, 255, 128 ) )
	Derma.Aim.Label2:SetText( "Magic that points gun barrels at enemies" )
	Derma.Aim.Label2:SetVisible( b_mAim )
	Derma.Aim.Label2:SizeToContents()
	
	Derma.Aim.Shoot = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.Shoot:SetPos( 12, 118 )
	Derma.Aim.Shoot:SetText( "Autoshoot" )
	Derma.Aim.Shoot:SetConVar( "odius_aim_autoshoot" )
	Derma.Aim.Shoot:SetValue( GetConVarNumber( "odius_aim_autoshoot" ) )
	Derma.Aim.Shoot:SetVisible( b_mAim )
	Derma.Aim.Shoot:SizeToContents()
	
	Derma.Aim.DM = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.DM:SetPos( 12, 136 )
	Derma.Aim.DM:SetText( "Deathmatch" )
	Derma.Aim.DM:SetConVar( "odius_aim_deathmatch" )
	Derma.Aim.DM:SetValue( GetConVarNumber( "odius_aim_deathmatch" ) )
	Derma.Aim.DM:SetVisible( b_mAim )
	Derma.Aim.DM:SizeToContents()
	
	Derma.Aim.Recoil = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.Recoil:SetPos( 12, 154 )
	Derma.Aim.Recoil:SetText( "No Recoil" )
	Derma.Aim.Recoil:SetConVar( "odius_aim_norecoil" )
	Derma.Aim.Recoil:SetValue( GetConVarNumber( "odius_aim_norecoil" ) )
	Derma.Aim.Recoil:SetVisible( b_mAim )
	Derma.Aim.Recoil:SizeToContents()
	
	Derma.Aim.Spread = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.Spread:SetPos( 12, 172 )
	Derma.Aim.Spread:SetText( "No Spread" )
	Derma.Aim.Spread:SetConVar( "odius_aim_nospread" )
	Derma.Aim.Spread:SetValue( GetConVarNumber( "odius_aim_nospread" ) )
	Derma.Aim.Spread:SetVisible( b_mAim )
	Derma.Aim.Spread:SizeToContents()
	
	Derma.Aim.Predict = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.Predict:SetPos( 12, 190 )
	Derma.Aim.Predict:SetText( "Prediction" )
	Derma.Aim.Predict:SetConVar( "odius_aim_prediction" )
	Derma.Aim.Predict:SetValue( GetConVarNumber( "odius_aim_prediction" ) )
	Derma.Aim.Predict:SetVisible( b_mAim )
	Derma.Aim.Predict:SizeToContents()
	
	Derma.Aim.SteamBuds = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Aim.SteamBuds:SetPos( 12, 208 )
	Derma.Aim.SteamBuds:SetText( "Ignore Steam friends" )
	Derma.Aim.SteamBuds:SetConVar( "odius_aim_ignorebuddies" )
	Derma.Aim.SteamBuds:SetValue( GetConVarNumber( "odius_aim_ignorebuddies" ) )
	Derma.Aim.SteamBuds:SetVisible( b_mAim )
	Derma.Aim.SteamBuds:SizeToContents()
	
	Derma.Aim.Smooth = vgui.Create( "DNumSlider", OdiusMenuPanel )
	Derma.Aim.Smooth:SetPos( 12, 226 )
	Derma.Aim.Smooth:SetSize( 100, 50 )
	Derma.Aim.Smooth:SetText( "Smooth aim:" )
	Derma.Aim.Smooth:SetMin( 0 )
	Derma.Aim.Smooth:SetMax( 80 )
	Derma.Aim.Smooth:SetDecimals( 1 )
	Derma.Aim.Smooth:SetValue( GetConVarNumber( "odius_aim_smoothfactor" ) )
	Derma.Aim.Smooth:SetConVar( "odius_aim_smoothfactor" )
	Derma.Aim.Smooth:SetVisible( b_mAim )
	
	-- ESP --
	Derma.ESP.Label = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.ESP.Label:SetPos( 12, 60 )
	Derma.ESP.Label:SetFont( "HUDNumber2" )
	Derma.ESP.Label:SetTextColor( color_white )
	Derma.ESP.Label:SetText( "ESP" )
	Derma.ESP.Label:SetVisible( b_mESP )
	Derma.ESP.Label:SizeToContents()
	
	Derma.ESP.Label2 = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.ESP.Label2:SetPos( 13, 93 )
	Derma.ESP.Label2:SetFont( "Trebuchet19" )
	Derma.ESP.Label2:SetTextColor( Color( 255, 255, 255, 128 ) )
	Derma.ESP.Label2:SetText( "Display invisible enemy information" )
	Derma.ESP.Label2:SetVisible( b_mESP )
	Derma.ESP.Label2:SizeToContents()
	
	-- Visuals --
	Derma.Vis.Label = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.Vis.Label:SetPos( 12, 60 )
	Derma.Vis.Label:SetFont( "HUDNumber2" )
	Derma.Vis.Label:SetTextColor( color_white )
	Derma.Vis.Label:SetText( "VISUALS" )
	Derma.Vis.Label:SetVisible( b_mVis )
	Derma.Vis.Label:SizeToContents()
	
	Derma.Vis.Label2 = vgui.Create( "DLabel", OdiusMenuPanel )
	Derma.Vis.Label2:SetPos( 13, 93 )
	Derma.Vis.Label2:SetFont( "Trebuchet19" )
	Derma.Vis.Label2:SetTextColor( Color( 255, 255, 255, 128 ) )
	Derma.Vis.Label2:SetText( "Miscellanious visual features" )
	Derma.Vis.Label2:SetVisible( b_mVis )
	Derma.Vis.Label2:SizeToContents()
	
	Derma.Vis.Chams = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Vis.Chams:SetPos( 12, 118 ) -- + 18
	Derma.Vis.Chams:SetText( "Wallhack" )
	Derma.Vis.Chams:SetConVar( "odius_wallhack" )
	Derma.Vis.Chams:SetValue( GetConVarNumber( "odius_wallhack" ) )
	Derma.Vis.Chams:SetVisible( b_mVis )
	Derma.Vis.Chams:SizeToContents()
	
	Derma.Vis.ReverseView = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Vis.ReverseView:SetPos( 12, 136 )
	Derma.Vis.ReverseView:SetText( "Playerlights" )
	Derma.Vis.ReverseView:SetConVar( "odius_playerlights" )
	Derma.Vis.ReverseView:SetValue( GetConVarNumber( "odius_playerlights" ) )
	Derma.Vis.ReverseView:SetVisible( b_mVis )
	Derma.Vis.ReverseView:SizeToContents()
	
	Derma.Vis.Ungag = vgui.Create( "DCheckBoxLabel", OdiusMenuPanel )
	Derma.Vis.Ungag:SetPos( 12, 154 )
	Derma.Vis.Ungag:SetText( "ULX ungag" )
	Derma.Vis.Ungag:SetConVar( "odius_misc_ungag" )
	Derma.Vis.Ungag:SetValue( GetConVarNumber( "odius_misc_ungag" ) )
	Derma.Vis.Ungag:SetVisible( b_mVis )
	Derma.Vis.Ungag:SizeToContents()
	
	local OdiusMenuNews
	http.Get( "http://dl.dropbox.com/u/7565174/test/hi.txt" , "GMod" , function( cont, size )
		OdiusMenuNews = vgui.Create( "DLabel", OdiusMenuPanel )
		OdiusMenuNews:SetPos( OdiusMenuPanel:GetWide() - 290, 10 )
		OdiusMenuNews:SetSize( 280, OdiusMenuPanel:GetTall() - 10 )
		OdiusMenuNews:SetWrap( true )
		OdiusMenuNews:SetColor( color_white )
		OdiusMenuNews:SetText( cont )
	end )
	
	-- Keep this at the end --
	OdiusMenuPanel:MakePopup()
end

-- Hooks --
Odius:AddHook( "RenderScreenspaceEffects", Odius.Visuals )
Odius:AddHook( "HUDPaint", Odius.ESP )
Odius:AddHook( "HUDPaint", Odius.Crosshair )
//Odius:AddHook( "HUDPaint", Odius.DebugPanel )
Odius:AddHook( "CreateMove", Odius.Aimbot )
--Odius:AddHook( "CreateMove", Odius.MovementFuckups )
Odius:AddHook( "CalcView", Odius.CalcView )
Odius:AddHook( "Think", Odius.AutoShoot )
Odius:AddHook( "Tick", Odius.ULXUngag )
Odius:AddHook( "Tick", Odius.TraitorDetect )
Odius:AddHook( "PlayerConnect", Odius.IPLogger )

-- Concommands --
Odius:AddConcommand( "odius_unload", Odius.Unload )
Odius:AddConcommand( "odius_reload", Odius.Reload )
Odius:AddConcommand( "+odius_aim", Odius.AimbotOn )
Odius:AddConcommand( "-odius_aim", Odius.AimbotOff )
Odius:AddConcommand( "odius_zoom", Odius.ZoomIn )
Odius:AddConcommand( "odius_printtraitors", Odius.PrintTraitors )
Odius:AddConcommand( "odius_drpmoney", Odius.PrintDarkRPMoney )
Odius:AddConcommand( "odius_menu", Odius.PopupMenu )