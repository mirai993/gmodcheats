--[[
	Tyguy's Hack
--]]

surface.CreateFont("thack.hud", {
font = "Arial",
size = 25,
underline = 1,
} )

surface.CreateFont("thack.playerhud", {
font = "Arial",
size = 20,
underline = 1,
} )

surface.CreateFont("thack.lowerhud", {
font = "Arial",
size = 15,
underline = 1,
} )

surface.CreateFont("thack.consolefont", {
font = "Arial",
size = 15
} )

surface.CreateFont("thack.buttonfont", {
font = "Arial Black",
size = 30
} )

thack = {}
thack.filetext = file.Read("thack.lua", "LUA")
thack.tag = "[THack] "
thack.newstext = ""
thack.colorpicked = false
thack.colorpicked_color = 0
thack.me = LocalPlayer()
thack.console_returnresult = ""
thack.console_timesprint = 1

function thack.setnewstext(body, length, headers, code)
thack.newstext = body
end

function thack.setnewstext_notfoundpage()
thack.newstext = "The news could not be retrieved, please try again later"
end

http.Fetch("https://dl.dropboxusercontent.com/u/45639759/thacknews.txt", thack.setnewstext, thack.setnewstext_notfoundpage)

thack.traitorweapons = {"weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_silencedpistol", "weapon_smg1"}
--[[
To add a console command, put the command in brackets and inside it put the string of the command before and after the command (such as ["rawr"])
To make a command print more then one time, use the integer thack.console_timesprint and as the integer use the amount of times you want it to print
To make the return print, use the string thack.console_returnresult = "What to return as a string"
Example function:

["example"] = function()
thack.console_returnresult = "Example"
end,

The function above will print 'Example' when you type "example" into the console.
Remember, that you don't have to set thack.console_timesprint to anything if you don't have to change the amount of times it prints
--]]

thack.consolecommands = 
{
["traitors"] = function()
	if gamemode.Get("terrortown") then
		for k,v in pairs(thack.traitorweapons) do
			for e,r in pairs(ents.FindByClass(v)) do
				for t,p in pairs(player.GetAll()) do
					if r:GetParent() == p then
					thack.console_returnresult = p:Nick().." is a traitor ["..r:GetClass().."]"
					end
				end
			end
		end
	end
end,
["players"] = function()
thack.console_returnresult = #player.GetAll().." players on\n"
end,
["hp"] = function()
thack.console_returnresult = "You have "..thack.me:Health().."hp\n"
end,
["status"] = function()
thack.console_timesprint = #player.GetAll()
	for k,v in pairs(player.GetAll()) do
	thack.console_returnresult = v:Nick().." - "..v:Health().."HP - "..v:SteamID().."\n"
	end
end,
["close"] = function()
	if IsValid(THackConsoleMenu) then
	THackConsoleMenu:Remove()
	end
end,
["author"] = function()
thack.console_returnresult = "This hack was coded and developed by Tyguy (tyguy550 @ steam)\n"
end,
["kill"] = function()
RunConsoleCommand("kill")
end,
["admins"] = function()
thackadminson = 0
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
		thackadminson = thackadminson + 1
		thack.console_returnresult = "There are "..thackadminson.." admins on\n"
		end
	end
end,
["esp on"] = function()
thack.esp = true
thack.console_returnresult = "ESP on\n"
end,
["esp off"] = function()
thack.esp = false
thack.console_returnresult = "ESP off\n"
end,
["chams on"] = function()
thack.chams = true
thack.console_returnresult = "Chams on\n"
end,
["chams off"] = function()
thack.chams = false
thack.console_returnresult = "Chams off\n"
end,
["infoplayer"] = function()
local eyes = thack.me:GetEyeTrace().Entity
	if eyes and eyes:IsPlayer() then
	thack.console_returnresult = eyes:Nick().." - "..eyes:Health().."HP".." - "..eyes:SteamID().."\n"
	end
end,
["infoentity"] = function()
local eyes = thack.me:GetEyeTrace().Entity
	if eyes and !eyes:IsPlayer() then
	thack.console_returnresult = eyes:GetClass()
	end
end,
["nearme"] = function()
nearme_list = 0
	for k,v in pairs(player.GetAll()) do
		if v != thack.me then
		local players_pos = v:GetPos()
		local my_pos = thack.me:GetPos()
			if players_pos:Distance(my_pos) < 500 then
			nearme_list = nearme_list + 1
				if nearme_list != 0 then
				thack.console_returnresult = "There are "..nearme_list.." people near you\n"
				else
				thack.console_returnresult = "There is no one near you\n"
				end
			end
		end
	end
end,
["antiafk on"] = function()
thack.antiafk = true
thack.console_returnresult = "AntiAFK on\n"
end,
["antiafk off"] = function()
thack.antiafk = false
thack.console_returnresult = "AntiAFK off\n"
end,
["clockwork esp on"] = function()
thack.clockworkesp = true
thack.console_returnresult = "Clockwork ESP on"
end,
["clockwork esp off"] = function()
thack.clockworkesp = false
thack.console_returnresult = "Clockwork ESP off"
end,
["say"] = function()
RunConsoleCommand("say", string.sub(THackConsoleTEntry, 5))
thack.console_returnresult = "Say: "..string.sub(THackConsoleTEntry, 5)
end,
["readpage"] = function()
local page = string.sub(THackConsoleTEntry:GetValue(), 10)

function ReadPageWorked(body, length, headers, code)
thack.console_returnresult = body
print(body)
end

function ReadPageFailed(code)
thack.console_returnresult = "Could not retrieve! (Error "..code..")"
end

http.Fetch(page, ReadPageWorked, ReadPageFailed)
end,
}

thack.playerson = {}
thack.esp = false --Enable/disable the ESP. do not change this (unless you want to set the default value)
thack.clockworkesp = false --Same as above
thack.chams = false --Same as above
thack.antiafk = false --Change this to true if you want the AntiAFK to be on when you load the hack (same as above)
thack.grenades = {"grenade*", "weapon_grenade*", "rocket", "npc_grenade_flag"}
table.Empty(thack.playerson)
table.insert(thack.playerson, #player.GetAll())

function thack.message(message)
chat.AddText(Color(171, 0, 255), thack.tag, Color(255, 255, 255), message )
end

	timer.Simple(2, function()
	thack.message("Welcome to THack (Build 2)")
	thack.message("There are "..table.GetFirstValue(thack.playerson).." players on!")
	end )

concommand.Add("+thack_menu", function()

THackBox = vgui.Create("DFrame")
THackBox:SetPos(ScrW()/2.2, ScrH()/2.5)
THackBox:SetSize(300, 200)
THackBox:SetTitle("                                          THack")
THackBox:SetDraggable(false)
THackBox:ShowCloseButton(false)
THackBox:MakePopup()

	function THackBox:Paint()
	draw.RoundedBox(2, 0, 2, 300, 20, Color(15, 107, 245, 255))
	draw.RoundedBox(2, 0, 20, 300, 180, Color(30, 30, 30, 255))
	end


--ESP
THackESP = vgui.Create("DCheckBox", THackBox)
THackESP:SetPos(60, 42)
	if thack.esp then
	THackESP:SetChecked(true)
	else
	THackESP:SetChecked(false)
	end

	function THackESP:OnChange()
	local thack_espcheckboxvalue = THackESP:GetChecked()
	thack.esp = thack_espcheckboxvalue

		if thack_espcheckboxvalue then
		thack.message("ESP on!")
		else
		thack.message("ESP off!")
		end
	end

THackESPLabel = vgui.Create("DLabel", THackBox)
THackESPLabel:SetPos(5, 40)
THackESPLabel:SetText("Enable ESP")

--Clockwork ESP
THackCWESP = vgui.Create("DCheckBox", THackBox)
THackCWESP:SetPos(112, 60)
	if thack.clockworkesp then
	THackCWESP:SetChecked(true)
	else
	THackCWESP:SetChecked(false)
	end

	function THackCWESP:OnChange()
	local thack_clockworkcheckboxvalue = THackCWESP:GetChecked()
	thack.clockworkesp = thack_clockworkcheckboxvalue

		if thack_clockworkcheckboxvalue then
		thack.message("Clockwork ESP on!")
		else
		thack.message("Clockwork ESP off!")
		end
	end

THackCWESPLabel = vgui.Create("DLabel", THackBox)
THackCWESPLabel:SetPos(5, 60)
THackCWESPLabel:SetText("Enable Clockwork ESP")
THackCWESPLabel:SizeToContents()

--Chams

THackChams = vgui.Create("DCheckBox", THackBox)
THackChams:SetPos(75, 80)
	if thack.chams then
	THackChams:SetChecked(true)
	else
	THackChams:SetChecked(false)
	end

	function THackChams:OnChange()
	local thack_chamscheckboxvalue = THackChams:GetChecked()
	thack.chams = thack_chamscheckboxvalue

		if thack_chamscheckboxvalue then
		thack.message("Chams on!")
		else
		thack.message("Chams off!")
		end
	end

THackChamsLabel = vgui.Create("DLabel", THackBox)
THackChamsLabel:SetPos(5, 80)
THackChamsLabel:SetText("Enable Chams")
THackChamsLabel:SizeToContents()

--Anti AFK
THackAntiAFK = vgui.Create("DCheckBox", THackBox)
THackAntiAFK:SetPos(80, 100)
	if thack.antiafk then
	THackAntiAFK:SetChecked(true)
	else
	THackAntiAFK:SetChecked(false)
	end

	function THackAntiAFK:OnChange()
	local thack_antiafkcheckboxvalue = THackAntiAFK:GetChecked()
	thack.antiafk = thack_antiafkcheckboxvalue

		if thack_antiafkcheckboxvalue then
		thack.message("AntiAFK on!")
		else
		thack.message("AntiAFK off!")
		end
	end

THackAntiAFKLabel = vgui.Create("DLabel", THackBox)
THackAntiAFKLabel:SetPos(5, 100)
THackAntiAFKLabel:SetText("Enable AntiAFK")
THackAntiAFKLabel:SizeToContents()

--News TextBox

THackNewsTextBox = vgui.Create("DTextEntry", THackBox)
THackNewsTextBox:SetPos(1, 20)
THackNewsTextBox:SetWide(300)
THackNewsTextBox:SetTall(150)
THackNewsTextBox:SetMultiline(true)
THackNewsTextBox:SetEnterAllowed(false)
THackNewsTextBox:SetVisible(false)
THackNewsTextBox:SetText(thack.newstext)
THackNewsTextBox:SetEditable(false)

local thacknewstextbox_randomcolor = 0
local thacknews_color = 0
local thacknews_goup = false
local thacknews_godown = false

	function THackNewsTextBox:Think()
		if thack.colorpicked then
		thacknews_goup = true
		end
		if thack.colorpicked_color == 1 then
		THackNewsTextBox:SetTextColor(Color(thacknews_color), 0, 0)
		end
		if thack.colorpicked_color == 2 then
		THackNewsTextBox:SetTextColor(Color(0, thacknews_color, 0))
		end
		if thack.colorpicked_color == 3 then
		THackNewsTextBox:SetTextColor(Color(0, 0, thacknews_color))
		end
		if !thack.colorpicked then
		thacknewstextbox_randomcolor = math.random(1, 3)
		thack.colorpicked = true
		thacknews_goup = true
		thacknews_godown = false
		end
		if thacknews_goup and thacknewstextbox_randomcolor != 0 and !thacknews_godown then
			if thacknews_color != 200 then
			thacknews_color = thacknews_color + 1
			elseif thacknews_color == 200 or thacknews_color == 199 then
			thacknews_goup = false
			thacknews_godown = true
			end
		end
	end
	if thacknews_godown then
	thacknews_color = thacknews_color - 1
	end
	if thacknews_color == 0 and thacknews_godown then
	thacknewstextbox_randomcolor = math.random(1, 3)
	thacknews_godown = false
	thacknews_goup = true
	end

--News Tab

THackNewsTab = vgui.Create("DButton", THackBox)
THackNewsTab:SetFont("thack.buttonfont")
THackNewsTab:SetText("News")
THackNewsTab:SizeToContents()
THackNewsTab:SetPos(180, 30)
THackNewsTab:SetSize(100, 50)

	function THackNewsTab:Paint()
	draw.RoundedBox(0, 0, 0, 200, 100, Color(25, 25, 25, 255))
	end

	function THackNewsTab:DoClick()
	THackAntiAFKLabel:SetVisible(false)
	THackAntiAFK:SetVisible(false)
	THackChamsLabel:SetVisible(false)
	THackChams:SetVisible(false)
	THackChams:SetVisible(false)
	THackESPLabel:SetVisible(false)
	THackESP:SetVisible(false)
	THackNewsTab:SetVisible(false)
	THackBackTab:SetVisible(true)
	THackNewsTextBox:SetVisible(true)
	end

--Back Tab

THackBackTab = vgui.Create("DButton", THackBox)
THackBackTab:SetFont("thack.buttonfont")
THackBackTab:SetText("Back")
THackBackTab:SizeToContents()
THackBackTab:SetPos(210, 175)
THackBackTab:SetSize(80, 20)
THackBackTab:SetVisible(false)

	function THackBackTab:Paint()
	draw.RoundedBox(0, 0, 0, 80, 20, Color(25, 25, 25, 255))
	end

	function THackBackTab:DoClick()
	THackAntiAFKLabel:SetVisible(true)
	THackAntiAFK:SetVisible(true)
	THackChamsLabel:SetVisible(true)
	THackChams:SetVisible(true)
	THackChams:SetVisible(true)
	THackESPLabel:SetVisible(true)
	THackESP:SetVisible(true)
	THackNewsTab:SetVisible(true)
	THackBackTab:SetVisible(false)
	THackNewsTextBox:SetVisible(false)
	end
end )

concommand.Add("-thack_menu", function()
	if IsValid(THackBox) then
	THackBox:Remove()
	end
end )

concommand.Add("thack_console", function()
THackConsoleMenu = vgui.Create("DFrame")
THackConsoleMenu:SetTitle("THack Console")
THackConsoleMenu:SetPos(ScrW()/2.4, ScrH()/4)
THackConsoleMenu:SetSize(500, 500)
THackConsoleMenu:SetDraggable(false)
THackConsoleMenu:ShowCloseButton(true)
THackConsoleMenu:MakePopup()

	function THackConsoleMenu:Paint()
	draw.RoundedBox(2, 0, 2, 500, 20, Color(15, 107, 245, 255))
	draw.RoundedBox(2, 0, 20, 500, 480, Color(30, 30, 30, 255))
	end

THackConsoleRichText = vgui.Create("RichText", THackConsoleMenu)
THackConsoleRichText:SetVerticalScrollbarEnabled(false)
THackConsoleRichText:DockMargin(0.1, 0, 0, 0)
THackConsoleRichText:Dock(FILL)
THackConsoleRichText:InsertColorChange(255, 255, 255, 255)

	function THackConsoleRichText:Paint()
	THackConsoleRichText:SetFontInternal("thack.consolefont")
	end

THackConsoleTEntry = vgui.Create("DTextEntry", THackConsoleMenu)
THackConsoleTEntry:SetPos(800, 800)
THackConsoleTEntry:SetWide(500)
THackConsoleTEntry:SizeToContents()
THackConsoleTEntry:MakePopup()

	function THackConsoleTEntry:OnEnter()
	local tentry_text = THackConsoleTEntry:GetValue()
	THackConsoleRichText:AppendText("\n>"..tentry_text)
	local command = thack.consolecommands[tentry_text]
			
			if table.HasValue(thack.consolecommands, command) then
			command()
			file.Append("thackconsolelog.txt", os.date().." - >"..tentry_text.."\n")
			else
			thack.console_result = "Unknown command"
			end
		
			if thack.console_returnresult != "" then
				for i=1, thack.console_timesprint do
				THackConsoleRichText:AppendText("\n"..thack.console_returnresult)
				end
			end		
	thack.console_returnresult = ""
	thack.console_timesprint = 1
	THackConsoleTEntry:SetText("")
	end
end )

hook.Add("HUDPaint", "thack.hudpaint", function(ply)
ply = thack.me
local eyetrace = ply:GetEyeTrace()
local e = eyetrace.Entity
	if e and e:IsPlayer() then
	local w, h = surface.GetTextSize(e:Nick())
	surface.SetTextPos(ScrW()/2.2, ScrH()/10)
	surface.SetTextColor(171, 0, 255)
	surface.SetFont("thack.hud")
	surface.DrawText(e:Nick())

	surface.SetTextPos(ScrW()/2.2, ScrH()/8)
	surface.SetTextColor(171, 0, 255)
	surface.SetFont("thack.hud")
	surface.DrawText(e:Health().." HP")
	end
	if thack.esp then
		for k,v in pairs(player.GetAll()) do
			if v:Alive() and v:Team() != TEAM_SPECTATOR and v != thack.me then
			local position = (v:GetPos() + Vector(0, 0, 80) ):ToScreen()
			local positionhp = (v:GetPos() + Vector(0, 0, 60) ):ToScreen()
			draw.DrawText(v:Nick(), "thack.playerhud", position.x, position.y, team.GetColor(v:Team()))
			draw.DrawText(v:Health().."HP", "thack.lowerhud", positionhp.x, positionhp.y, team.GetColor(v:Team()))
			end
		end
	end
	if thack.clockworkesp then
		for k,v in pairs(ents.FindByClass("cw_*")) do
			for e,r in pairs(player.GetAll()) do
				if v:GetParent() != r then
				local position = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetClass(), "thack.lowerhud", position.x, position.y, Color(255, 94, 0, 255))
				end
			end
		end
	end
	thack_grenade_mepos = thack.me:GetPos()
	for k,v in pairs(thack.grenades) do
		for r,t in pairs(ents.FindByClass(v)) do
		local thack_grenade_pos = t:GetPos()
			if thack_grenade_mepos:Distance(thack_grenade_pos) < 500 then
			surface.SetTextPos(ScrW()/2, ScrH()/6)
			surface.SetTextColor(255, 0, 0, 255)
			surface.SetFont("thack.hud")
			surface.DrawText("Grenade/Rocket detected")
			end
		end
	end
end )

hook.Add("Think", "thack_chams", function()
	if thack.chams then
		for k,v in pairs(player.GetAll()) do
		v:SetMaterial("chams")
		v:SetColor(team.GetColor(v:Team()))
		end
	else
		for k,v in pairs(player.GetAll()) do
		v:SetMaterial("")
		v:SetColor(Color(255, 255, 255, 255))
		end
	end
end )

--Anti AFK

timer.Create("AntiAFK_Running", 5, 0, function()
	if thack.antiafk then
	RunConsoleCommand("+left")
		timer.Simple(1, function()
		RunConsoleCommand("-left")
		end )
	end
end )