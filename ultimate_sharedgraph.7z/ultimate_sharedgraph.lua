// by Serejaga

/*
    Shit
*/

local frame 

local currentTick = 1
local tick = {}
for i = 1, 690 do tick[ i ] = { [1] = 0, [2] = 0, [3] = 0, [4] = 0 } end 


local tickColor = {
    [1]      = Color( 255, 56, 56 ),
    [2]      = Color( 56, 56, 255 ),
    [3]      = Color( 56, 255, 56 ),
    [4]      = Color( 255, 255, 56 ),
}


/*
    Vgui panel
*/

frame = vgui.Create( "DFrame" )
frame:SetTitle( "USG" )
frame:SetPos( 15, 15 )
frame:SetSize( 700, 500 )
frame:ShowCloseButton( false )
frame:MakePopup()

function frame:Paint( w, h )
    surface.SetDrawColor( 0, 0, 0, 128 )
    surface.DrawRect( 0, 0, w, h )


end

local tickgraph = vgui.Create( "DPanel", frame )
tickgraph:SetPos( 5, 35 )
tickgraph:SetSize( 690, 128 )

function tickgraph:Paint( w, h )

    for i = 1, #tick do
        local t = tick[ i ]

        // Tickrate 
        local nextt = i == 690 and 690 or i + 1 

        surface.SetDrawColor( tickColor[ 1 ] )
        surface.DrawLine( i, 128 - t[ 1 ], nextt, 128 - tick[ nextt ][ 1 ] )

        surface.SetDrawColor( tickColor[ 2 ] )
        surface.DrawLine( i, 128 - t[ 2 ], nextt, 128 - tick[ nextt ][ 2 ] )
            
        surface.SetDrawColor( tickColor[ 3 ] )
        surface.DrawLine( i, t[3], nextt, tick[ nextt ][3] )
        
        surface.SetDrawColor( tickColor[ 4 ] )
        surface.DrawLine( i, t[4], nextt, tick[ nextt ][4] )

    end

    surface.SetFont( "BudgetLabel" )

    surface.SetTextColor( tickColor[ 1 ] )
    surface.SetTextPos( currentTick, 128 - tick[ currentTick ][ 1 ] )
    surface.DrawText( tick[ currentTick ][ 1 ] )

    surface.SetTextColor( tickColor[ 2 ] )
    surface.SetTextPos( currentTick, 128 - tick[ currentTick ][ 2 ] )
    surface.DrawText( tick[ currentTick ][ 2 ] )

    surface.SetTextColor( tickColor[ 3 ] )
    surface.SetTextPos( currentTick, tick[ currentTick ][ 3 ] )
    surface.DrawText( tick[ currentTick ][ 3 ] )

    surface.SetTextColor( tickColor[ 4 ] )
    surface.SetTextPos( currentTick, tick[ currentTick ][ 4 ] )
    surface.DrawText( tick[ currentTick ][ 4 ] )

end

concommand.Add( "_usg", function() frame:ToggleVisible() end )

/*
    Hooks
*/

local function Tick()
    local frametime, svtime = engine.ServerFrameTime()

    tick[ currentTick ] = {
        [1]         = ( 1 / frametime ),
        [2]         = frametime,
        [3]         = svtime,
        [4]         = ( 1 / FrameTime() ),
        


    }

    currentTick = math.Clamp( ( currentTick + 1 ) % 691, 1, 690 )
end 

hook.Add( "Tick", "TickGraph", Tick )


void DrawProgressBar(float x, float y, float w, float h, float current_value, float max_value, bool dynamic, ImColor color)
{
    ImColor bar_color;
    if (dynamic) {
        bar_color = ImColor(min(510 * (max_value - current_value) / 100, color.Value.x), min(510 * current_value / 100, color.Value.y), color.Value.z, color.Value.w);
    }
    else {
        bar_color = color;
    }

    DrawRectFilled(x - 1, y + 1, x + w + 1, y + ((h - 1 / max_value)), black, 0.0f, 0);
    DrawRectFilled(x, y + 1, x + w, y + ((h / max_value) * current_value) - 2, bar_color, 0.0f, 0);
}