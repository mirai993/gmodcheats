-- paradox note: https://pastebin.com/raw/va6TEHQt

local BypassHooks = {
{"Think", "HackThink"},
{"PlayerBindPress", "HackPBP"},
{"FinishChat", "chatclosed"},
{"StartChat", "chatopened"},
{"Move", "HackMove"},
{"RenderScreenspaceEffects", "HackRSE"},
{"PreDrawOpaqueRenderables", "HackPDOR"},
{"OnPlayerChat", "HackOPC"},
{"player_disconnect", "HackPD"},
{"player_connect", "HackPC"},
{"player_hurt", "HackPH"},
{"entity_killed", "HackEK"},
{"HUDPaint", "HackHP"},
{"DrawOverlay", "HackDO"},
{"CreateMove", "HackCM"},
{"CalcView", "HackCV"},
{"ShouldDrawLocalPlayer", "HackSDLP"},
{"PreDrawPlayerHands", "HackPDPH"},
{"PostDrawViewModel", "HackPoDVM"},
{"PreDrawViewModel", "HackPrDVM"},
{"ScalePlayerDamage", "HackSPD"},
}


local pcall = pcall;
local require = require;
screengrab = false
voicechat = 0
lemver = "1.6.6.8"
fa = Angle(0,0,0)
menuscol = Color(255, 255, 255, 255)
local actualRenderCapture = _G.render.Capture

local TestCH = false
local FuckHooks = _G.hook.GetTable
MyHooks = FuckHooks()
TestCH = true
/* 
        for k,v in next, BypassHooks do
        if MyHooks[v[1]] then
                if MyHooks[v[1]][v[2]] then
                        MyHooks[v[1]][v[2]] = nil
                end
        end
        if MyHooks[v[1]] then
                if !MyHooks[v[1]][1] then
                        MyHooks[v[1]] = nil
                end
        end
        TestCH = true
        end
        return MyHooks
*/
if TestCH then
function hook.GetTable()
--MsgC( menuscol, "[LucidCheats]", Color(255,255,255,255), " Blocked an attempt to sniff your hook table\n" )

end
function concommand.GetTable()
--MsgC( menuscol, "[LucidCheats]", Color(255,255,255,255), " Blocked an attempt to sniff your ConCommand table\n" )

end
end

timer.Destroy( "STC" )         
hook.Remove("PlayerInitialSpawn", "AddPlayer")       --I hate niggers
hook.Remove("OnGamemodeLoaded", "___scan_g_init")      
hook.Remove("PlayerSay", "screengrab_playersay")       
hook.Remove("Think", "PlayerInfoThing")        
timer.Destroy("AntiCheatTimer")        
timer.Destroy("testing123")        
hook.Remove("Think", "sh_menu")      
if MOTDgd or MOTDGD then
function MOTDgd.GetIfSkip()

return true
end
end

local OriginalGetConVarNumber = GetConVarNumber;
 
function GetConVarNumber( name )
    if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" or name == "mat_fullbright") then
        return 0;
    else
        return OriginalGetConVarNumber( name );
    end
end



--QAC-Bypass LOL

        function debug.getinfo(indexkid)
                return
        end
 
        function _G.debug.getinfo(indexkid)
                return
        end
 
        _G.debug.getinfo = function(indexkid)
                return
        end
 
        debug.getinfo = function(indexkid)
                return
        end

--Fuck your hook checker v2 electric boogaloo

--Big Private lucid hvh cheat now released for all your pasting needs

--[[
	██╗     ██╗   ██╗ ██████╗██╗██████╗ ████████╗███████╗ █████╗ ███╗   ███╗
	██║     ██║   ██║██╔════╝██║██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗ ████║
	██║     ██║   ██║██║     ██║██║  ██║   ██║   █████╗  ███████║██╔████╔██║
	██║     ██║   ██║██║     ██║██║  ██║   ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║
	███████╗╚██████╔╝╚██████╗██║██████╔╝██╗██║   ███████╗██║  ██║██║ ╚═╝ ██║
	╚══════╝ ╚═════╝  ╚═════╝╚═╝╚═════╝ ╚═╝╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝
]]
--concommand.Run( LocalPlayer(), "say", "niggers" )

checkfovang = Angle(0,0,0)
checkfovpos = Vector(0,0,0)
showfov =false

	--[[function render.Capture(nice)
		chat.AddText(Color(255,255,0), "[WARNING] ", Color(255,255,255), "Someone screengrabbed you.")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		chat.AddText(color_white, "")
		screengrab = true
		test = actualRenderCapture(nice)
		return self
	end]]
if !oldRC then
oldRC = render.Capture
end
rndrView = render.RenderView
rndrHUD = render.RenderHUD
scnx = ScrW()
beenscreened = 0
screenbl = 255
if !fullbrightstart && GetConVarNumber("mat_fullbright") == 1 then
	fullbrightstart = true
	CSfb = true
end

render.Capture = function( ... )
	screengrab = true
	SGCheck = nil
	beenscreened = beenscreened + 1
	surface.PlaySound("vo/npc/female01/uhoh.wav")
	screenbl = 0
	if CSfb then
		GetConVar("mat_fullbright"):SetValue(1)
	else
		GetConVar("mat_fullbright"):SetValue(0)
	end
	GetConVar("r_3dsky"):SetValue(1)
	GetConVar("r_drawskybox"):SetValue(1)
	GetConVar("gl_clear"):SetValue(1)
	rndrView({
		origin = LocalPlayer():EyePos(), -- change to your liking
		angles = LocalPlayer():EyeAngles(), -- change to your liking
		x = 0,
		y = 0,
		w = ScrW(),
		h = ScrH(),
		drawhud = true,
		drawviewmodel = true,
	 })
	rndrHUD(0,0,ScrW(),ScrH())
	SGCheck = oldRC( ... )

	screengrab = false
	if SGCheck then
	return SGCheck
	end
end

inserttime = 0
custtest = {}


whiteslest = {
	"q43j9UTUc9WnJ2swfkMw52v38", --GrandpaTroll
	"9oNriRkwbiYg6YOS3iOnrgleD", --Lemon
	"Jmr5Y764PPLhTtrSeD1Cj4tua", --Red
	"Ku3DSlPoT2FgvL4o6AdYOBm6T", --Mike
	"34NPrV1rKIfq4MSuah52n5kZl", --HiptonismHD
	"qSVdLwIWnG88NNnB6n8ULpN61", --Glitch
	"fqHj495cpD3vIzz98wT4E8ew6", --DeadMan
	"8zRYakXdO8u1xlqRf6P1z155q", --T.R
	"PFk94nCfcEpzqf4y9w4ZyH8i2", --HomieKOS
	}

Doners = {
	"9oNriRkwbiYg6YOS3iOnrgleD", --Lemon
	"qSVdLwIWnG88NNnB6n8ULpN61", --Glitch
	"34NPrV1rKIfq4MSuah52n5kZl", --HiptonismHD
	"q43j9UTUc9WnJ2swfkMw52v38", --GrandpaTroll
	"Jmr5Y764PPLhTtrSeD1Cj4tua", --Red
	"fqHj495cpD3vIzz98wT4E8ew6", --DeadMan
}

Dev = {
	"q43j9UTUc9WnJ2swfkMw52v38", --GrandpaTroll
	"qSVdLwIWnG88NNnB6n8ULpN61", --Glitch
}

if !file.Exists("lwn.txt", "DATA") then
	local lwsn = file.Open( "lwn.txt", "wb", "DATA" )
	lwsn:Write('[LOCAL]')
	lwsn:Close()
end
cactme = os.time()

if !wasloaded then
pcall(require, "nspred");
pcall(require, "bsendpacket");
pcall(require, "sh");
pcall(require, "fhook");
pcall(require, "svm");
pcall(require, "mega");
wasloaded = true
end
if file.Exists( "lua/bin/gmcl_chatclear_win32.dll", "GAME" ) then
require("ChatClear")
end

if (ChatClear == nil) then

else
concommand.Add("chatclear_run", function() ChatClear.Run() end) // Normal Chat
concommand.Add("chatclear_ooc", function() ChatClear.OOC() end) // Global Chat for DarkRP
end


if ConVarExists("sv_cheats") then
	GetConVar("sv_cheats"):SetValue(0)
	GetConVar("sv_cheats"):SetFlags(1)
end
if ConVarExists("cl_extrapolate") then
	GetConVar("cl_extrapolate"):SetValue(0)
end

	MyName = "p99.9 SumNigga"
	http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=ED35F0D8404B9FF70922E2647BE50CA5&steamids=76561198031700108",
		function(body)
			local tbe = util.JSONToTable(body)
			if not (tbe) then return end
			MyName = tbe.response.players[1].personaname
			table.insert(custtest,1,{"LucidCheats DUNKED BY CHINK GANG", Color(255,255,255), 12/engine.TickInterval()})
			inserttime = 12/engine.TickInterval()
		end,
		
		function(error)
			table.insert(custtest,1,{"LucidCheats DUNKED BY CHINK GANG", Color(255,255,255), 12/engine.TickInterval()})
			inserttime = 12/engine.TickInterval()
		end
	)
	newstuffz = ""
	http.Fetch( "www.google.com",
	function( body, len, headers, code )
		newstuffz = body
		if file.Exists("lwn.txt", "DATA") then
			file.Write("lwn.txt",  body)
		end
	end,
	function( error )
		newstuffz = "Failed to get updates."
		if file.Exists("lwn.txt", "DATA") then
			newstuffz = file.Read( "lwn.txt", "DATA" )
		end
	end
 )

if !file.Exists( "lua/bin/gmcl_sh_win32.dll", "GAME" )
	|| !file.Exists( "lua/bin/gmcl_bsendpacket_win32.dll", "GAME" )
	|| !file.Exists( "lua/bin/gmcl_svm_win32.dll", "GAME" )
	|| !file.Exists( "lua/bin/gmcl_nspred_win32.dll", "GAME" )
	|| !file.Exists( "lua/bin/gmcl_enginepred_win32.dll", "GAME" )
	|| !file.Exists( "lua/bin/gmcl_fhook_win32.dll", "GAME" ) then
	print("[ERROR] You are missing the required module(s).")
	_G.NHTable.ClientCMD('toggleconsole')
	RunConsoleCommand("disconnect")
end
rColor = Color(255,0,0)
local ChatOpen = false
PSBox = false
local Traitors = {}
local tbudd = false
local tdect = false
local Tbud = {}
local Tdectt = {}
local traitorswep = {}
--RunConsoleCommand("cl_interp", "0.0333333333333333333333333")
--RunConsoleCommand("cl_updaterate", "30")
--RunConsoleCommand("cl_cmdrate", "30")
local type = type;
local next = next;
mottomsg = nil
local funnymsg = {"Whoever made this shitty cheat isn't funny"}
if mottomsg == nil then
mottomsg = table.Random(funnymsg)
else
mottomsg = mottomsg
end


textcol = Color(255, 255, 255, 255)
crocol = Color(255, 255, 255, 255)
	
local function Copy(tt, lt)
        local copy = {}
        if lt then
                if type(tt) == "table" then
                        for k,v in next, tt do
                                copy[k] = Copy(k, v)
                        end
                else
                        copy = lt
                end
                return copy
        end
        if type(tt) != "table" then
                copy = tt
        else
                for k,v in next, tt do
                        copy[k] = Copy(k, v)
                end
        end
        return copy
end
 
local surface = Copy(surface);
local vgui = Copy(vgui);
local input = Copy(input);
local Color = Color;
local ScrW, ScrH = ScrW, ScrH;
local gui = Copy(gui);
local math = Copy(math);
local file = Copy(file);
local util = Copy(util);
local cfov = 0
 
surface.CreateFont("memeyou", {
        font = "Console",
        size = 13,
        weight = 900,
        shadow = true,
        antialias = false,
        outline = true
});
surface.CreateFont("memebudget", {
        font = "BudgetLabel",
        size = 13,
        weight = 10,
        shadow = false,
        antialias = false,
        outline = true
});


surface.CreateFont("ESP", {
        font = "BudgetLabel",
        size = 20,
        weight = 300,
        shadow = false,
        antialias = false,
        outline = true
});
 
surface.CreateFont("memeyou2", {
        font = "Console",
        size = 13,
        weight = 900,
        shadow = false,
        antialias = false,
        outline = true
});
--[[
		-Checkbox:TYPE
	{NAME, TYPE, VAR, DIST, DESC},
	{var[1], var[2], var[3], var[4], var[5]},
		-Slider:TYPE
	{NAME, TYPE, VAR, MAX, DIST, MIN || 0, DESC},
	{var[1], var[2], var[3], var[4], var[5], var[6] || 0, var[7]},
	i.e. {"FOV", "Slider", 70, 120, 68, 70} - with min   _||_   {"FOV", "Slider", 70, 120, 68} -w/o min
		-Selection:TYPE
	{NAME, TYPE, VAR[TABLE], {TABLE}, DIST, DESC },
	{var[1], var[2], var[3], var[4]/Table, var[5], var[6]},
	i.e. {"Type", "Selection", "Thing1", {"Thing4", "Thing2", "Thing1", Thing3"}, 150 },
		-Textbox:TYPE
	{NAME, TYPE, VAR, DIST, DESC},
	{var[1], var[2], var[3], var[4], var[5]},
		-Toggle:TYPE
	{NAME, TYPE, VAR, DIST, STATE, DESC},
	{var[1], var[2], var[3], var[4], var[5], var[6]},
]]
tttgod= false
local options = {
        ["Aimbot"] = {
                {
                        {"Aimbot", 20, 20, 350, 240, 120},
                        {"Enabled", "Checkbox", false, 0},
                        {"Key Toggle", "Toggle", 0, 40, 0, "The key you wish to use for aimbot."},
                        {"Silent", "Checkbox", false, 0, "Aimbot is invisible on your screen."},
						{"pSilent", "Checkbox", false, 0, "Aimbot is invisible on your screen AND spectators."},

                        {"Autofire", "Checkbox", false, 0, "Autoshoots when aimlocked."},
                        {"Autosnap", "Checkbox", false, 0, "Automatically aims at target."},
                        {"Auto Pistol", "Checkbox", false, 0, "Rapidly fires when it can."},
                        {"Non-Sticky", "Checkbox", false, 0, "Dynamic targets."},
						{"fov", "Slider", 0, 180, 200},
                },
               {
                        {"Target", 380, 130, 350, 180, 150},
                        {"Selection", "Selection", "Closest to Crosshair", {"Distance", "Health", "Nextshot", "Closest to Crosshair"}, 150, "Type of ways for aimbot to find target."},
                        {"Bodyaim", "Checkbox", false, 0, "Aimbot will tend to hit for chest."},
                        {"Ignore Bots", "Checkbox", false, 0, "Aimbot will ignore bots."},
                        {"Ignore Team", "Checkbox", false, 0, "Aimbot will ignore teammates."},
                        {"Ignore Friends", "Checkbox", false, 0, "Aimbot will ignore friends/steam friends."},
                    	{"Ignore Spawn Protection", "Checkbox", false, 0, "Aimbot will ignore spawn-protected players."},
                },
                {
                        {"Accuracy", 380, 20, 350, 90, 120},
                        {"NoSpread", "Checkbox", false, 0, "Forces bullets to one spot."},
                        {"NoRecoil", "Checkbox", false, 0, "No visual recoil."},
						{"Auto Wall", "Checkbox", false, 0, "Shoots trought penetrable walls. ONLY FOR M9K"},
                },
                           
        },
        ["Visuals"] = {
                {
                        {"ESP", 20, 20, 350, 300, 120},
                        {"Enabled", "Checkbox", false, 0},
						{"Box", "Checkbox", false, 0},
						{"Box Type", "Selection", "2D Box", {"2D Box", "3D Box"}, 75},
                        {"Name", "Checkbox", false, 0},
						{"UserGroup", "Checkbox", false, 0},
						{"Weapon", "Checkbox", false, 0},
                        {"Health", "Checkbox", false, 0},
						{"Health Type", "Selection", "HP Bar", {"HP Bar", "Percentage"}, 75},
						{"Model Type", "Selection", "Normal", {"Normal", "XQZ", "Chams 2D", "Chams 3D"}, 75},
                        {"Skeleton", "Checkbox", false, 0},
						{"Hitbox", "Checkbox", false, 0},
                },
                {
                        {"Filter", 20, 340, 350, 130, 120},
                        {"Enemies only", "Checkbox", false, 0},
						{"Always show Friends", "Checkbox", false, 0},
                        {"Distance", "Checkbox", false, 0},
                        {"Max Distance", "Slider", 0, 10000, 68},
                },
                {
                        {"Misc", 380, 20, 350, 340, 120},
						{"No Sky", "Checkbox", false, 0},
						{"Fullbright", "Checkbox", false, 0},
						{"Hands - IgnoreZ", "Checkbox", false, 0, "See trough hand from gun." },
						{"Hand Type", "Selection", "Normal", {"Normal", "WireFrame", "No Hands", "Chams 2D", "Chams 3D", "Rainbow"}, 75},
						{"Weapon Type", "Selection", "Normal", {"Normal", "WireFrame", "No Weapon", "Chams 2D", "Chams 3D", "Rainbow"}, 75},
						{"Crosshair", "Checkbox", false, 0},
						{"Custom FOV", "Checkbox", false, 0},
						{"FOV", "Slider", 70, 120, 68, 70},
						{"Radar", "Checkbox", false, 0},
						{"Radar Type", "Selection", "Square", {"Square", "Circle"}, 75},
						{"Radar Distance", "Slider", 0, 10000, 68},
						{"Always show FOV", "Checkbox", false, 0},
						{"Status", "Checkbox", false, 0},
                },
        },
		
        ["HVH"] = {
               {
                    {"Anti-Aim", 20, 20, 350, 195, 130},
                    {"Enabled", "Checkbox", false, 0},
					{"Static", "Checkbox", false, 0, "Angles are relative to world."},
					{"Aim At Closest", "Checkbox", false, 0, "Predicts and aims at closest player."},
					{"Negitive Pitch", "Checkbox", false, 0, "Oppisite pitch. i.e. 66 = -66"},
                    {"Pitch", "Slider", 0, 180, 160, 0, "Up/Down"},
                    {"Yaw", "Slider", 0, 360, 160, 0, "Left/Right"},
					{"Spin", "Slider", 0, 360, 160},
                },
                {
                    {"FakeLag", 20, 225, 350, 100, 130},
                    {"Enabled", "Checkbox", false, 0, "Makes you harder to get hit."},
                    {"Fakelag Rate", "Slider", 0, 13, 68},
					{"Fakelag Prediction", "Checkbox", false, 0, "Predicts players that are fake-lagging."},
				},
				{
                    {"Resolvers", 385, 20, 350, 100, 130},
                    {"Anti-aim resolver", "Checkbox", false, 0, "Auto correct anti-aim angles"},
                    {"Fake-angles resolver", "Checkbox", false, 0, "Auto correct fake-angles [EXPERIMENTAL]"},
                    {"FA bullet amount", "Slider", 1, 15, 68, 1, "Amount of bullets fired before changing FA angles."},
				},
        },
		["Misc"] = {
		
				{
                    {"Spam", 520, 20, 210, 235, 100},
                    {"Act Spam", "Checkbox", false, 0},
					{"Act Type", "Selection", "dance", {"cheer", "laugh", "muscle", "zombie", "robot", "dance", "salute", "wave"}, 75},
					{"Voice Spam", "Checkbox", false, 0},
					{"pAsshole", "Checkbox", false, 0},
					{"Disconnect Say", "Checkbox", false, 0},
					{"Kill Say", "Checkbox", false, 0},
					{"Chat Spam", "Checkbox", false, 0},
					{"Command Spam", "Checkbox", false, 0},
					{"Round Say", "Checkbox", false, 0},
                },
               
				{
                    {"Sounds", 20, 20, 210, 70, 100},
                    {"Hit Sounds", "Checkbox", false, 0},
					{"TextToSpeech", "Checkbox", false, 0},
                },
				{
                    {"Name Changer", 20, 110, 210, 145, 85},
                    {"Enabled", "Checkbox", false, 0},
					{"Custom Name", "Textbox", "",  100, "Custom name..."},
					{"Ignore Friends", "Checkbox", false, 0},
					{"Ignore Admins", "Checkbox", false, 0},
					{"Team Only", "Checkbox", false, 0},
                },
				{
                    {"Notifications", 20, 275, 210, 145, 130},
                    {"Spectators Sound", "Checkbox", false, 0},
					{"Show Spectators", "Checkbox", false, 0},
					{"Admins Sound", "Checkbox", false, 0},
					{"Show Admins", "Checkbox", false, 0},
					{"Player Killed Alert", "Checkbox", false, 0},
                },

                --[[{
                    {"Music", 250, 275, 480, 40, 60},
                    {"URL/DIR", "Textbox", "url or songname.mp3",  380, "Input a url |or| the name of song with .mp3"},
                },]]
				{
                    {"BunnyHop", 250, 20, 260, 100, 120},
					{"Enabled", "Checkbox", false, 0},
					{"cStrafe Toggle", "Toggle", 0, 40, 0, "The key you wish to use for cStrafe."},
					{"Strafe Type", "Selection", "Assist", {"Assist", "Full", "Off"}, 75},
					
                },
				{
                    {"Thirdperson", 250, 140, 260, 100, 120},
					{"Enabled", "Checkbox", false, 0},
					{"Distance", "Slider", 0, 150, 100, 50},
					{"No-Collide", "Checkbox", false, 0, "Distance will go through walls."},
                },
        },
		["Color"] = {
				{
					{"Menu Color", 20, 20, 240, 120, 70},
					{"Red", "Slider", 255, 255, 130},
					{"Green", "Slider", 255, 255, 130},
					{"Blue", "Slider", 0, 255, 130},
				},
				{
					{"Text Color", 20, 160, 240, 120, 70},
					{"Red", "Slider", 255, 255, 130},
					{"Green", "Slider", 255, 255, 130},
					{"Blue", "Slider", 255, 255, 130},
				},
				{
					{"Crosshair Color", 20, 300, 240, 120, 70},
					{"Red", "Slider", 255, 255, 130},
					{"Green", "Slider", 255, 255, 130},
					{"Blue", "Slider", 255, 255, 130},
				},
			{
				{"Chams - Team", 270, 20, 250, 175, 100},
				{"Visible R", "Slider", 0, 255, 88},
				{"Visible G", "Slider", 255, 255, 88},
				{"Visible B", "Slider", 0, 255, 88},
				{"Not Visible R", "Slider", 0, 255, 88},
				{"Not Visible G", "Slider", 0, 255, 88},
				{"Not Visible B", "Slider", 255, 255, 88},
			},
			
			{
				{"Chams - Enemy", 270, 215, 250, 175, 100},
				{"Visible R", "Slider", 255, 255, 88},
				{"Visible G", "Slider", 0, 255, 88},
				{"Visible B", "Slider", 0, 255, 88},
				{"Not Visible R", "Slider", 180, 255, 88},
				{"Not Visible G", "Slider", 120, 255, 88},
				{"Not Visible B", "Slider", 0, 255, 88},
			},
			{
				{"Chams - Hands", 530, 20, 250, 175, 100},
				{"Visible R", "Slider", 0, 255, 88},
				{"Visible G", "Slider", 255, 255, 88},
				{"Visible B", "Slider", 0, 255, 88},
				{"Not Visible R", "Slider", 255, 255, 88},
				{"Not Visible G", "Slider", 0, 255, 88},
				{"Not Visible B", "Slider", 0, 255, 88},
			},
			
			{
				{"Chams - Weapon", 530, 215, 250, 120, 100},
				{"Visible R", "Slider", 255, 255, 88},
				{"Visible G", "Slider", 0, 255, 88},
				{"Visible B", "Slider", 0, 255, 88},
			},
		},
};
if table.HasValue(Doners, file.Read( "whitytighty.txt", "DATA" )) || table.HasValue(Dev, file.Read( "whitytighty.txt", "DATA" )) then
	options["Aimbot"] = {
                {
                        {"Aimbot", 20, 20, 350, 265, 120},
                        {"Enabled", "Checkbox", false, 0},

                        {"Key Toggle", "Toggle", 0, 40, 0, "The key you wish to use for aimbot."},
                        {"Silent", "Checkbox", false, 0, "Aimbot is invisible on your screen."},
						{"pSilent", "Checkbox", false, 0, "Aimbot is invisible on your screen AND spectators."},
                        {"Autofire", "Checkbox", false, 0, "Autoshoots when aimlocked."},
                        {"Autosnap", "Checkbox", false, 0, "Automatically aims at target."},
                        {"Auto Pistol", "Checkbox", false, 0, "Rapidly fires when it can."},
                        {"Non-Sticky", "Checkbox", false, 0, "Dynamic targets."},
						{"fov", "Slider", 0, 180, 200},
						{"Untrusted Angles", "Checkbox", false, 0, "Have inverted angles when aimlocking"},
                },
                {
                        {"Target", 380, 130, 350, 180, 150},
                        {"Selection", "Selection", "Closest to Crosshair", {"Distance", "Health", "Nextshot", "Closest to Crosshair"}, 150, "Type of ways for aimbot to find target."},
                        {"Bodyaim", "Checkbox", false, 0, "Aimbot will tend to hit for chest."},
                        {"Ignore Bots", "Checkbox", false, 0, "Aimbot will ignore bots."},
                        {"Ignore Team", "Checkbox", false, 0, "Aimbot will ignore teammates."},
                        {"Ignore Friends", "Checkbox", false, 0, "Aimbot will ignore friends/steam friends."},
                    	{"Ignore Spawn Protection", "Checkbox", false, 0, "Aimbot will ignore spawn-protected players."},
                },
                {
                        {"Accuracy", 380, 20, 350, 90, 120},
                        {"NoSpread", "Checkbox", false, 0, "Forces bullets to one spot."},
                        {"NoRecoil", "Checkbox", false, 0, "No visual recoil."},
						{"Auto Wall", "Checkbox", false, 0, "Shoots trought penetrable walls. ONLY FOR M9K"},
                },
                           
        }

	options["HVH"] = {
				{
                    {"Anti-Aim", 20, 20, 350, 195, 130},
                    {"Enabled", "Checkbox", false, 0},
					{"Static", "Checkbox", false, 0, "Angles are relative to world."},
					{"Aim At Closest", "Checkbox", false, 0, "Predicts and aims at closest player."},
					{"Negitive Pitch", "Checkbox", false, 0, "Oppisite pitch. i.e. 66 = -66"},
                    {"Pitch", "Slider", 0, 180, 160, 0, "Up/Down"},
                    {"Yaw", "Slider", 0, 360, 160, 0, "Left/Right"},
					{"Spin", "Slider", 0, 360, 160},
                },
                {
                    {"FakeLag", 20, 225, 350, 100, 130},
                    {"Enabled", "Checkbox", false, 0, "Makes you harder to get hit."},
                    {"Fakelag Rate", "Slider", 0, 13, 68},
					{"Fakelag Prediction", "Checkbox", false, 0, "Predicts players that are fake-lagging."},
				},
				{
                    {"FakeAngles", 385, 20, 350, 195, 130},
                    {"Enabled", "Checkbox", false, 0, "Unseeable angle towards other players. AA MUST BE ON"},
					{"Static", "Checkbox", false, 0, "Angles are relative to world."},
					{"Aim At Closest", "Checkbox", false, 0, "Predicts and aims at closest player."},
					{"Negitive Pitch", "Checkbox", false, 0, "Oppisite pitch. i.e. 66 = -66"},
                    {"Pitch", "Slider", 0, 180, 160, 0, "Up/Down"},
                    {"Yaw", "Slider", 0, 360, 160, 0, "Left/Right"},
					{"Spin", "Slider", 0, 360, 160},
                },
				{
                    {"Resolvers", 385, 225, 350, 100, 130},
                    {"Anti-aim resolver", "Checkbox", false, 0, "Auto correct anti-aim angles"},
                    {"Fake-angles resolver", "Checkbox", false, 0, "Auto correct fake-angles [EXPERIMENTAL]"},
                    {"FA bullet amount", "Slider", 1, 15, 68, 1, "Amount of bullets fired before changing FA angles."},
				},
			
        }
end



local order = {
        "Aimbot",
        "Visuals",
        "HVH",
		"Misc",
		"Color",
};

if table.HasValue(Dev, file.Read( "whitytighty.txt", "DATA" )) then
	options["Debug"] = {
				{
					{"Shit's n giggles", 20, 20, 180, 50, 120},
					{"Ammo Count", "Checkbox", false, 0},
				},
	}
	order = {
        "Aimbot",
        "Visuals",
        "HVH",
		"Misc",
		"Color",
		"Debug",
};
end
 
local function updatevar( men, sub, lookup, new )
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
                                val[3] = new;
                        end
                end
        end
end
 
local function loadconfig()
        if(!file.Exists("lemonsquad.txt", "DATA")) then return; end
        local tab = util.JSONToTable( file.Read("lemonsquad.txt", "DATA") );
        local cursub;
        for k,v in next, tab do
                if(!options[k]) then continue; end
                for men, subtab in next, v do
                        for key, val in next, subtab do
                                if(key == 1) then cursub = val[1]; continue; end
                                updatevar(k, cursub, val[1], val[3]);
                        end
                end
        end
end
allplayers = player.GetAll()
local testie = false


local function whatsnewpopup()
	testie = true
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( 500, 400 )
	frame:Center()
	frame:MakePopup()
	frame:SetTitle("")
	function frame:Paint()
		surface.SetDrawColor( 0, 0 ,0, 125 )
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
		surface.SetDrawColor(menuscol)
        surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
		surface.SetDrawColor( 0, 0 ,0, 125 )
	end
	local TextEntry = vgui.Create( "DTextEntry", frame ) -- create the form as a child of frame
	TextEntry.AllowInput = function( self, stringValue )
		return true
	end
	TextEntry:SetUpdateOnType(true)
	TextEntry.OnChange = function( self )
		self:SetText( newstuffz )
	end
	TextEntry:SetPos(10, 30 )
	TextEntry:SetSize( 480, 350 )
	TextEntry:SetText( newstuffz )
	TextEntry:SetMultiline( true )
	TextEntry:SetVerticalScrollbarEnabled(true)
	
end


function GMRP()
    if string.find(string.lower(GAMEMODE.Name), "dark") then return true end
    return false
end
function maFormat(Num)
    Num = tostring(Num)
    Sep = Sep or ","
	Deci = string.find(Num, "%.") or #Num + 1
		for i = Deci - 4, 1, -3 do
			Num = Num:sub(1, i) .. Sep .. Num:sub(i + 1)
		end
    return Num
end
local hackercheck = {}
if !file.Exists("hackerlistv2.txt", "DATA") then
	local news = file.Open( "hackerlistv2.txt", "wb", "DATA" )
	news:Write('["Me"]')
	news:Close()
else
	hackercheck = util.JSONToTable(file.Read("hackerlistv2.txt", "DATA"))
	if table.HasValue(hackercheck, "Me") then
		Hackers = hackercheck
	end
end
if !file.Exists("spamlist.txt", "DATA") then
	local news = file.Open( "spamlist.txt", "wb", "DATA" )
	tablestart = {{"Make your own chat spams", "Chat Spam", "Disabled"},{"_ply_, _weap_, and _me_ are functions for names","Chat Spam", "Disabled"}}
	news:Write(util.TableToJSON(tablestart))
	news:Close()

end
local Friends = {}
local Enemies = {}

local Hackers = {}
		table.insert(Hackers, "Me")

local gonemute = {}
spammylist = {}
if file.Exists("spamlist.txt", "DATA") then
	testboog = file.Read("spamlist.txt", "DATA")
	if testboog then
	spammylist = util.JSONToTable(file.Read("spamlist.txt", "DATA"))
	end
	end
spammydone = {}

function MenuOptions()

return vgui.Create( "DMenu" )
end

function SpamMenu(check)
	testie = true
	PSBox = true
	local SPlyMe = vgui.Create( "DFrame" )
	SPlyMe:InvalidateLayout(true)
	local SPlyPanel = vgui.Create("DPanelList", SPlyMe)
	SPlyPanel:InvalidateLayout(true)
	local SPlyView = vgui.Create("DListView", SPlyPanel)
	local sDComboBox = vgui.Create( "DComboBox", SPlyMe )
	local sTextEntry1 = vgui.Create( "DTextEntry", SPlyMe )
	local DButton = vgui.Create( "DButton", SPlyMe )
	SPlyView:InvalidateLayout(true)
	SPlyMe:SetSize(800, 400)
	SPlyMe:SetTitle("")
	SPlyMe:Center()
	SPlyMe.btnMaxim:Hide()
	SPlyMe.btnMinim:Hide() 
	SPlyMe:MakePopup()
	SPlyMe.OnClose = function( self )
		PSBox = false
	end
	function SPlyMe:Paint()
		surface.SetDrawColor( 0, 0 ,0, 125 )
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
		surface.SetDrawColor(menuscol)
        surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
		surface.SetDrawColor( 0, 0 ,0, 125 )
	end

	SPlyPanel:SetName("log_tab")
	SPlyPanel:SetPos(2, 27)
	SPlyPanel:SetSize(SPlyMe:GetWide() - 4, SPlyMe:GetTall() - 70)
	SPlyPanel:SetSpacing(10)
	SPlyPanel:EnableHorizontal(false)
	SPlyPanel:EnableVerticalScrollbar(false)

	SPlyView:SetPos(10, 2)
	SPlyView:SetMultiSelect(false)
	SPlyView:SetSize(SPlyPanel:GetWide() - 20, SPlyPanel:GetTall() - 5)
	if check == false then
	SPlyView:InvalidateLayout(true)
	SPlyView:AddColumn("Message")
	SPlyView:AddColumn("Type")
	SPlyView:AddColumn("Enabled")
	SPlyView:InvalidateLayout(true)
	--SPlyView:AddLine(MESSAGE,TYPE,ENABLED)
	text = ""
	ttype = ""
	tenable = false
	if file.Exists("spamlist.txt", "DATA") then
	testboog = file.Read("spamlist.txt", "DATA")
	if testboog then
	spammylist = util.JSONToTable(file.Read("spamlist.txt", "DATA"))
	end
	end
	if spammylist then
	for i=1, #spammylist, 1 do
		if spammylist && spammylist[i] then
		SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
		end
	end
	else
		spammylist = {}
	end
	sTextEntry1:SetPos( 12, SPlyMe:GetTall() - 35 )
	sTextEntry1:SetSize( SPlyMe:GetWide() - 250, 20 )
	sTextEntry1:SetText( "" )
	sTextEntry1.OnChange = function( self )
		text = self:GetValue()
	end
	types = {"Chat Spam","Kill Say","Disconnect Say","Round Start", "Command Spam"}
	sDComboBox:SetPos( 12 +  SPlyMe:GetWide() - 250 + 5, SPlyMe:GetTall() - 35 )
	sDComboBox:SetSize( 100, 20 )
	sDComboBox:SetValue( "Type" )
	sDComboBox:AddChoice( "Chat Spam" )
	sDComboBox:AddChoice( "Kill Say" )
	sDComboBox:AddChoice( "Round Start" )
	sDComboBox:AddChoice( "Command Spam" )
	sDComboBox:AddChoice( "Disconnect Say" )
	CFP = {"Chat Spam", "Kill Say", "Round Start", "Command Spam", "Disconnect Say"}
	CFP2 = {CChatSpam, CKillSay, CRoundStart, CCommandSpam, CDisconnectSay}
	sDComboBox.OnSelect = function( panel, index, value )
		ttype = value
	
	end
	DButton:SetPos( SPlyMe:GetWide() - (16 + 75), SPlyMe:GetTall() - 35 )
	DButton:SetText( "Add" )
	DButton:SetSize( 75, 20 )
	DButton.DoClick = function()
		if text ~= "" && table.HasValue(types, ttype) then
		spammydone = {text, ttype, "Enabled"}
		number = 0
		if spammylist then
		number = #spammylist
		end
		table.insert(spammylist, {text, ttype, "Enabled"})
		SPlyView:AddLine(spammydone[1],spammydone[2],spammydone[3] , number +1)
		file.Write("spamlist.txt",  util.TableToJSON(spammylist))
		end
	end
	elseif check == true then
	sTextEntry1:SetPos( SPlyMe:GetWide(), SPlyMe:GetTall() )
	sTextEntry1:SetSize( 1, 1 )
	DButton:SetPos( SPlyMe:GetWide(), SPlyMe:GetTall() )
	DButton:SetText( "" )
	DButton:SetSize( 75, 20 )
	sDComboBox:SetPos( SPlyMe:GetWide(), SPlyMe:GetTall() )
	sDComboBox:SetSize( 1, 1 )
	SPlyView:InvalidateLayout(true)
	SPlyView:AddColumn("Name")
	SPlyView:AddColumn("Rank")
	SPlyView:AddColumn("SteamID")
	SPlyView:AddColumn("Kills")
	SPlyView:AddColumn("Deaths")
	SPlyView:AddColumn("Status")
	SPlyView:InvalidateLayout(true)
	if GMRP() then
		SPlyView:AddColumn("Job")
		SPlyView:AddColumn("Money")
	end
	CPlys = table.Copy(player.GetAll())
	for _, v in next, CPlys do
		
		Money = v:GetNetworkedInt("money")
		if v.DarkRPVars and v.DarkRPVars.money then
			Money = v.DarkRPVars.money
		end
		if v == LocalPlayer() then
		SPlyView:AddLine(v:GetName(), v:GetUserGroup(), v:SteamID(), v:Frags(), v:Deaths(), "You", team.GetName(v:Team()), "$" ..  maFormat(Money), v)
		elseif v:GetFriendStatus() == "friend" then
		SPlyView:AddLine(v:GetName(), v:GetUserGroup(), v:SteamID(), v:Frags(), v:Deaths(), "Steam Friend", team.GetName(v:Team()), "$" ..  maFormat(Money), v)
		elseif (table.HasValue(Friends, v)) then
		SPlyView:AddLine(v:GetName(), v:GetUserGroup(), v:SteamID(), v:Frags(), v:Deaths(), "Ignored", team.GetName(v:Team()), "$" ..  maFormat(Money), v)
		elseif table.HasValue(Hackers, v:SteamID()) then
		SPlyView:AddLine(v:GetName(), v:GetUserGroup(), v:SteamID(), v:Frags(), v:Deaths(), "Cheater", team.GetName(v:Team()), "$" ..  maFormat(Money), v)
		elseif v:IsPlayer() && !v:IsBot() then
		SPlyView:AddLine(v:GetName(), v:GetUserGroup(), v:SteamID(), v:Frags(), v:Deaths(), "Player", team.GetName(v:Team()), "$" ..  maFormat(Money), v)
		end
	end
	end
	SPlyView:InvalidateLayout(true)
	SPlyView.OnRowSelected = function(Par, Line) 
		local DFrame = MenuOptions()
		if check == true then
		tab = SPlyView:GetLine(Line):GetValue(9)
		if not (table.HasValue(Friends, tab)) then
			DFrame:AddOption("Add to Friends(Aimbot)", function() 
				table.insert(Friends, tab)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " added to friends list(aimbot).")
				CloseDermaMenus()
			end):SetIcon("icon16/user_add.png")
		else
			DFrame:AddOption("Remove From Friends(Aimbot)", function()
				table.RemoveByValue(Friends, tab)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " removed from friends list(aimbot).")
				CloseDermaMenus()
			end):SetIcon("icon16/user_delete.png")
		end
		
		if not (table.HasValue(Hackers, tab:SteamID())) then
			DFrame:AddOption("Add to Hacker list", function() 
				table.insert(Hackers, tab:SteamID())
				file.Write("hackerlistv2.txt", util.TableToJSON(Hackers))
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " added to Hacker list.")
				CloseDermaMenus()
			end):SetIcon("icon16/user_add.png")
		end
		
		if (table.HasValue(Hackers, SPlyView:GetLine(Line):GetValue(3))) then
			DFrame:AddOption("Remove From Hacker list", function()
				table.RemoveByValue(Hackers, tab:SteamID())
				file.Write("hackerlistv2.txt", util.TableToJSON(Hackers))
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " removed from Hacker list.")
				CloseDermaMenus()
			end):SetIcon("icon16/user_delete.png")
		end

		DFrame:AddOption("Copy Name", function() 
			SetClipboardText(SPlyView:GetLine(Line):GetValue(1))
			chat.AddText("Player name ", Color(116, 187, 251), tab:GetName(), color_white, " copied to clipboard.")
			CloseDermaMenus()
		end):SetIcon("icon16/user_go.png")

		DFrame:AddOption("Copy SteamID", function() 
			SetClipboardText(SPlyView:GetLine(Line):GetValue(3))
			chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " SteamID ", Color(255, 93, 0), tab:SteamID(), color_white, " copied to clipboard.")			
			CloseDermaMenus()
		end):SetIcon("icon16/table_go.png")

		DFrame:AddOption("Open Profile", function() 
			tab:ShowProfile()
			chat.AddText("Opened ", Color(116, 187, 251), tab:GetName(), color_white, " Steam profile.")
			CloseDermaMenus()
		end):SetIcon("icon16/world_link.png")

		if !tab:IsMuted() then
			DFrame:AddOption("Gag", function()
				tab:SetMuted(true)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " has been gagged.")
			CloseDermaMenus()
		end):SetIcon("icon16/sound_mute.png")
		end
		if tab:IsMuted() then
			DFrame:AddOption("Ungag", function()
				tab:SetMuted(false)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " has been ungagged.")
				CloseDermaMenus()
			end):SetIcon("icon16/sound_mute.png")
		end

		if plysp ~= tab then
			DFrame:AddOption("Spectate", function()
				if tab:Alive() then
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " spectated.")
				tab:SetNoDraw(true)
				plysp = tab
				else
					chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " is dead.")
				end
			CloseDermaMenus()
		end):SetIcon("icon16/eye.png")
		else
			DFrame:AddOption("Un-Spectate", function()
				tab:SetMuted(true)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " unspectated.")
				tab:SetNoDraw(false)
				plysp = nil
			CloseDermaMenus()
		end):SetIcon("icon16/user.png")
		end
		
		if !table.HasValue(gonemute, tab) then
			DFrame:AddOption("Mute", function()
				table.insert(gonemute, tab)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " has been muted.")
				CloseDermaMenus()
			end):SetIcon("icon16/textfield_delete.png")
		end

		if table.HasValue(gonemute, tab) then
			DFrame:AddOption("Unmute", function()
				table.RemoveByValue(gonemute, tab)
				chat.AddText("Player ", Color(116, 187, 251), tab:GetName(), color_white, " has been unmuted.")
				CloseDermaMenus()
			end):SetIcon("icon16/textfield_add.png")
		end

		if (GMRP()) then
			DFrame:AddOption("Copy Money", function() 
				SetClipboardText(SPlyView:GetLine(Line):GetValue(8))
				chat.AddText("Copied ", Color(116, 187, 251), tab:GetName(), color_white, " money of ", Color(0, 201, 0), SPlyView:GetLine(Line):GetValue(7), color_white, " copied to clipboard.")
				CloseDermaMenus()
			end):SetIcon("icon16/money.png")
		end
		elseif check == false then
			--[================================]
			tab = SPlyView:GetLine(Line):GetValue(4)
		
			if spammylist[tab][3] == "Enabled" then
			DFrame:AddOption("Disable", function() 
				spammylist[tab][3] = "Disabled"
				tab = SPlyView:GetLine(Line):GetValue(4)
				for i = 1 , #spammylist, 1 do
					SPlyView:RemoveLine(i)
				end
				for i = 1 , #spammylist, 1 do
					SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
				end
				file.Write("spamlist.txt",  util.TableToJSON(spammylist))
				CloseDermaMenus()
			end):SetIcon("icon16/cross.png")
			else
			DFrame:AddOption("Enable", function() 
				spammylist[tab][3] = "Enabled"
				tab = SPlyView:GetLine(Line):GetValue(4)
				for i = 1 , #spammylist, 1 do
					SPlyView:RemoveLine(i)
				end
				for i = 1 , #spammylist, 1 do
					SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
				end
				file.Write("spamlist.txt",  util.TableToJSON(spammylist))
				CloseDermaMenus()
			end):SetIcon("icon16/accept.png")
			end
		subMenu, subMenuOpt = DFrame:AddSubMenu( "Change..." )
		subMenuOpt:SetIcon( "icon16/table_go.png" )
		textOpt = subMenu:AddOption( "Text.", function()
		tab = SPlyView:GetLine(Line):GetValue(4)
			Derma_StringRequest(
			"Change text.",
			"Input string to change text.",
			spammylist[tab][1],
			function( text )
			tab = SPlyView:GetLine(Line):GetValue(4)
			spammylist[tab][1] = text
			for i = 1 , #spammylist, 1 do
					SPlyView:RemoveLine(i)
				end
				for i = 1 , #spammylist, 1 do
					SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
				end
				file.Write("spamlist.txt",  util.TableToJSON(spammylist))
				CloseDermaMenus()
			end,
			function( text )
				spammylist[tab][1] = spammylist[tab][1]
			end
		)
		end )
		typeMenu, typeOpt = subMenu:AddSubMenu( "Type" )
		typeOpt:SetIcon( "icon16/table_go.png" )
		
		for i = 1, #CFP, 1 do
		CFP2[i] = typeMenu:AddOption( CFP[i], function()
			
				tab = SPlyView:GetLine(Line):GetValue(4)
				spammylist[tab][2] = CFP[i]
				for i = 1 , #spammylist, 1 do
					SPlyView:RemoveLine(i)
				end
				for i = 1 , #spammylist, 1 do
					SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
				end
				file.Write("spamlist.txt",  util.TableToJSON(spammylist))
				CloseDermaMenus()
		end )
		end
		
		DFrame:AddOption("Remove", function() 
				for i = 1 , #spammylist, 1 do
					SPlyView:RemoveLine(i)
				end
				table.remove(spammylist, Line)
				for i = 1 , #spammylist, 1 do
					SPlyView:AddLine(spammylist[i][1],spammylist[i][2],spammylist[i][3], i)
				end
				file.Write("spamlist.txt",  util.TableToJSON(spammylist))
				CloseDermaMenus()
			end):SetIcon("icon16/application_delete.png")
		
		
		end
		DFrame:Open() 
	end
end

local function gBool(men, sub, lookup)
        if(!options[men]) then return; end
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
                                return val[3];
                        end
                end
        end
end

function gKey(men, sub, lookup)
        if(!options[men]) then return; end
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
                        	if input.IsKeyDown(val[3]) || input.IsMouseDown(val[3]) then
                                return true
                            else
                            	return false
                            end
                        end
                end
        end
end

local function gText(men, sub, lookup)
        if(!options[men]) then return ""; end
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
							if val[3] == "" then
                                return val[3];
							else
								 return val[3];
							end
                        end
                end
        end
        return "";
end
 
local function gOption(men, sub, lookup)
        if(!options[men]) then return ""; end
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
                                return val[3];
                        end
                end
        end
        return "";
end
 
local function gInt(men, sub, lookup)
        if(!options[men]) then return 0; end
        for aa,aaa in next, options[men] do
                for key, val in next, aaa do
                        if(aaa[1][1] != sub) then continue; end
                        if(val[1] == lookup) then
                                return val[3];
                        end
                end
        end
        return 0;
end
 
local function saveconfig()
        file.Write("lemonsquad.txt", util.TableToJSON(options));
end
 
local mousedown;
local candoslider;
local drawlast;
 
local visible = {};
 
for k,v in next, order do
        visible[v] = false;
end
if file.Exists("opt.txt", "DATA")  then
visible[file.Read( "opt.txt", "DATA" )] = true
else
file.Write("opt.txt", "Aimbot")
visible["Aimbot"] = true
end
local function DrawBackground(w, h)
        surface.SetDrawColor( 0, 0 ,0, 125 );
        surface.DrawRect(0, 0, w, h);
		surface.SetDrawColor(menuscol);
        surface.DrawOutlinedRect(0, 0, w, h);
		surface.SetDrawColor( 0, 0 ,0, 125 );
       
        local curcol = Color( 0, 0 ,0, 125 );
       
        
       
        surface.SetDrawColor(curcol);
       
        surface.SetFont("memeyou");
       
        local tw, th = surface.GetTextSize("LucidCheats");
                local nw, nh = surface.GetTextSize(LocalPlayer():GetName());
                local lw, lh = surface.GetTextSize("Logged in as: ");
        surface.SetTextPos(5, (15 - th / 2) - 5);
        surface.SetTextColor(textcol);
        surface.DrawText("LucidCheats LEAKED BY CHINKGANG");
        surface.SetTextPos(5, 15 - th / 2 + 6);
        surface.SetTextColor( 255, 255, 255, 255 );
        surface.DrawText("Logged in as: ");
        surface.SetTextPos(5 + lw, 15 - th / 2 + 6);
        surface.SetTextColor(textcol)
        surface.DrawText(LocalPlayer():GetName());
        surface.SetTextPos(5 + lw + nw, 15 - th / 2 + 6);
		if table.HasValue(Dev, file.Read( "whitytighty.txt", "DATA" )) then
        surface.SetTextColor( rColor );
        surface.DrawText(" [DEVELOPER]");
        elseif (table.HasValue(Doners, file.Read( "whitytighty.txt", "DATA" ))) then
        surface.SetTextColor( rColor );
        surface.DrawText(" [DONATOR]");
        else
        surface.SetTextColor( 0, 255, 0, 255 );
        surface.DrawText(" [USER]");
        end
       

end
 
local function MouseInArea(minx, miny, maxx, maxy)
        local mousex, mousey = gui.MousePos();
        return(mousex < maxx && mousex > minx && mousey < maxy && mousey > miny);
end
 
local function DrawOptions(self, w, h)
        local mx, my = self:GetPos();
       
        local sizeper = (w - 10) / #order;
       
        local maxx = 0;
       
        for k,v in next, order do
                local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30);
                if(visible[v]) then
                        local curcol = Color( 0, 0 ,0, 125 );
                                                        surface.SetDrawColor(curcol);
                                                        surface.DrawRect( 5 + maxx, 31, sizeper, 30 )
                elseif(bMouse) then
                        local curcol = Color( 0, 0 ,0, 50 );
                            surface.SetDrawColor(curcol);
                                                        surface.DrawRect( 5 + maxx, 31, sizeper, 30 )
                else
                        local curcol = Color( 0, 0 ,0, 125 );
                                                        surface.SetDrawColor(curcol);
                end
                if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !visible[v]) then
                        local nb = visible[v];
                        for key,val in next, visible do
                                visible[key] = false;
                        end
                        visible[v] = !nb;
						file.Write("opt.txt", v)
                end
                surface.SetFont("memeyou2");
                surface.SetTextColor(textcol);
                local tw, th = surface.GetTextSize(v);
                surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 );
                surface.DrawText(v);
                maxx = maxx + sizeper;
        end
end
 
local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
        surface.SetFont("memeyou2");
       surface.SetTextColor(textcol);
        surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
        local tw, th = surface.GetTextSize(var[1]);
        surface.DrawText(var[1]);
       
        surface.SetDrawColor(menuscol);
       
        surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14);
       
        local mx, my = self:GetPos();
       
        local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16);
		if var[5] then
			if bMouse then
				surface.SetFont("BudgetLabel");
				local tdw, tdh = surface.GetTextSize(var[5]);
				surface.SetTextColor(color_white);
				surface.SetTextPos((800-(tdw+4)), 600-(tdh+50));
				surface.DrawText(var[5]);
				surface.SetTextColor(textcol);
				surface.SetFont("memeyou2");
			end
		end
        if(bMouse) then
                surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
        end
       
        if(var[3]) then
                surface.SetDrawColor(menuscol);
                surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
                surface.SetDrawColor(menuscol.r/2, menuscol.g/2, menuscol.b/2, menuscol.a);
                surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
        end
       
        if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
                var[3] = !var[3];
        end
end
 
local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
		menuscol = Color(menr, meng, menb, 255)
        local curnum = var[3];
        local max = var[4];
        local size = var[5];
		local min = 0
		if var[6] then
		min = var[6]
		max = var[4] - var[6]
		curnum = var[3]
		end
		        local mx, my = self:GetPos();
       
        local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12);
      
        surface.SetFont("memeyou2");
        surface.SetTextColor(textcol);
        surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
        surface.DrawText(var[1]);
        local tw, th = surface.GetTextSize(var[1]);
       
        surface.SetDrawColor(163, 163, 163);
       
        surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2);
       
        local ww = math.ceil((curnum - min) * size / max);
       
        surface.SetDrawColor(menuscol);
       
        surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 4, 12);
       
        surface.SetDrawColor(menuscol.r/2, menuscol.g/2, menuscol.b/2, menuscol.a);
       
        local tw, th = surface.GetTextSize(curnum..".00");
       
        surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 4, 12);
       
        surface.SetTextPos( 5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 61 + posy + maxy + 16);
       showfov = false
        surface.DrawText(curnum..".00");
		if bMouse && var[1] == "fov" then
		showfov = true
		end
		if var[7] then
			if bMouse then
				surface.SetFont("BudgetLabel");
				local tdw, tdh = surface.GetTextSize(var[7]);
				surface.SetTextColor(color_white);
				surface.SetTextPos((800-(tdw+4)), 600-(tdh+50));
				surface.DrawText(var[7]);
				surface.SetTextColor(textcol);
				surface.SetFont("memeyou2");
			end
		end
        if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !candoslider) then
                local mw, mh = gui.MousePos();
       
                local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max) + min;
                var[3] = new;
				menuscol = Color(menr, meng, menb, 255)
        end
end
keychange = 0
local function DrawToggle(self, w, h, var, maxy, posx, posy, dist)
	--[[	-Toggle:TYPE
	{NAME, TYPE, VAR, DIST, STATE, DESC},
	{var[1], var[2], var[3], var[4], var[5], var[6]},
	]]
		surface.SetFont("memeyou2");
       	surface.SetTextColor(textcol);
        surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
        local tw, th = surface.GetTextSize(107);
        surface.DrawText(var[1]);
       	local mx, my = self:GetPos();
       
        local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 18);
        surface.SetDrawColor(menuscol);

       	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist , 61 + posy + maxy , 14+ var[4], 18);
       	if(bMouse) then
        	if input.IsMouseDown(MOUSE_LEFT) && var[5] ~= 2 then
               surface.SetDrawColor(0,0,0, 75);
               surface.DrawRect( 5 + posx + 15 + 5 + dist +2, 61 + posy + maxy +2, 14+ var[4]-4, 18-4);
               var[5] = 1
            end
            if !input.IsMouseDown(MOUSE_LEFT) then
            	if var[5] == 1 then
            		var[5] = 2
            	end

            end
        end
        if var[5] == 2 then
        	if !input.IsKeyDown(KEY_BACKSPACE) && !input.IsKeyDown(KEY_ESCAPE) then
        	for i=1, 159 do
        		if !input.IsKeyDown(KEY_BACKSPACE) && !input.IsKeyDown(KEY_ESCAPE) then
        			if input.IsKeyDown(i) || input.IsMouseDown(i) then
        				var[3] = i
        				var[5] = 0
        			end
        		else
        			var[3] = 0
        				var[5] = 0
        		end
        	end
        	else
        		var[3] = 0
        		var[5] = 0
        	end
        end
        --surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14);
       
		if var[3] then
			surface.SetTextPos( 5 + posx + 15 + 5 + dist+4 , 61 + posy + maxy+2 )
			if var[5] == 0 && input.GetKeyName(var[3]) then
			surface.DrawText(input.GetKeyName(var[3]));
			elseif  var[5] == 0 && !input.GetKeyName(var[3]) then
				surface.DrawText("NONE");
			elseif var[5] ~= 0 then
				surface.DrawText("...");
			end
		end

		if var[6] then
			if bMouse then
				surface.SetFont("BudgetLabel");
				local tdw, tdh = surface.GetTextSize(var[6]);
				surface.SetTextColor(color_white);
				surface.SetTextPos((800-(tdw+4)), 600-(tdh+50));
				surface.DrawText(var[6]);
				surface.SetTextColor(textcol);
				surface.SetFont("memeyou2");
			end
		end
        
       
        --[[if(var[3]) then
       
                surface.SetDrawColor(menuscol.r/2, menuscol.g/2, menuscol.b/2, menuscol.a);
               surface.DrawRect( 5 + posx + 15 + 5 + dist , 61 + posy + maxy , 14+ var[4], 18);
        end]]
       
        --[[if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
                var[3] = !var[3];
        end]]
end

pooptest = {}
for k,v in next, order do
	pooptest[v] = {}
	
	for _, opt in next, options[v] do
		
		for i=1, #opt do
			if i == 1 then continue; end
			if opt[i][2] == "Textbox" then
				pooptest[v][opt[i][1]] = {false}
				
			end
		end
		
	end	
end
local function DrawbText(self, w, h, var, maxy, posx, posy, dist, tab)

		menuscol = Color(menr, meng, menb, 255)
        local curnum = var[3];
        local max = 0
        local size = var[4];
		local min = 0
		local mx, my = self:GetPos();
       
        local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my -10, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12);
        surface.SetFont("memeyou2");
        surface.SetTextColor(textcol);
        surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
        surface.DrawText(var[1]);
        local tw, th = surface.GetTextSize(var[1]);
		local btw, bth, btww, btwh = (5 + posx + 15 + 5 + dist), (61 + posy + maxy + 9), (size), (2)
		if !pooptest[tab][var[1]][1] then
		pooptest[tab][var[1]][2] = vgui.Create( "DTextEntry", self ) -- create the form as a child of frame
		pooptest[tab][var[1]][2]:SetPos( btw, bth - 10 )
			pooptest[tab][var[1]][2]:SetSize( btww, 15 )
			pooptest[tab][var[1]][2]:SetText( var[3] )
			pooptest[tab][var[1]][2].OnEnter = function( poo )
				if poo:GetValue() == "" || !poo:GetValue() then
					var[3] = ""
				else
					var[3] = poo:GetValue()
				end
			end
			
			
			pooptest[tab][var[1]][2].Think = function()
			if !visible[tab] then
				
							pooptest[tab][var[1]][1] = false
							pooptest[tab][var[1]][2]:Remove()
				
				end
			end
		pooptest[tab][var[1]][1] = true
		end
		
		if var[5] then
			if bMouse then
				surface.SetFont("BudgetLabel");
				local tdw, tdh = surface.GetTextSize(var[5]);
				surface.SetTextColor(color_white);
				surface.SetTextPos((800-(tdw+4)), 600-(tdh+50));
				surface.DrawText(var[5]);
				surface.SetTextColor(textcol);
				surface.SetFont("memeyou2");
			end
		end
end
 
local notyetselected;
 
local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
 
        local size = var[5];
        local curopt = var[3];
       
        surface.SetFont("memeyou2");
        surface.SetTextColor(textcol)
        surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
        local tw, th = surface.GetTextSize(var[1]);
        surface.DrawText(var[1]);
       
       surface.SetDrawColor(0, 0, 0, 100);
       
        surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16);
       
        local mx, my = self:GetPos();
       
        local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
       
        local check = dist..posy..posx..w..h..maxy;
       
        if(bMouse || notyetselected == check) then
               
                surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12);
               
        end
       
        local tw, th = surface.GetTextSize(curopt);
       
        surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2);
       
        surface.DrawText(curopt);
       
        if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !mousedown || notyetselected == check) then
                notyetselected = check;
                drawlast = function()
                        local maxy2 = 16;
                        for k,v in next, var[4] do
                                surface.SetDrawColor(0, 0, 0, 75);
                                surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
                                local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
                                if(bMouse2) then
                                       surface.SetDrawColor(menuscol.r , menuscol.g , menuscol.b , 100);
                                        surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
                                end
                                local tw, th = surface.GetTextSize(v);
                                surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2);
                                surface.DrawText(v);
                                maxy2 = maxy2 + 16;
                                if(bMouse2 && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
                                        var[3] = v;
                                        notyetselected = nil;
                                        drawlast = nil;
                                        return;
                                end
                        end
                        local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2);
                        if(!bbMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
                                 notyetselected = nil;
                                 drawlast = nil;
                                 return;
                        end
                end
        end
       
       
end
 
local function DrawSubSub(self, w, h, tab, var)
        local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6];
       
        surface.SetDrawColor(menuscol);
       
        local startpos = 61 + posy;
       
         surface.SetTextColor(textcol)
       
        surface.SetFont("memeyou2");
       
        local tw, th = surface.GetTextSize(opt);
       
        surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos);
       
        surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 );
       
        surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos);
       
        surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey);
       
        surface.DrawLine(5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey );
       
        surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey);
       
        surface.DrawText(opt);
       
        local maxy = 15;
       
        for k,v in next, var do
        		
                if(k == 1) then continue; end
                if(v[2] == "Checkbox") then
                        DrawCheckbox(self, w, h, v, maxy, posx, posy, dist);
                elseif(v[2] == "Slider") then
                        DrawSlider(self, w, h, v, maxy, posx, posy, dist);
				elseif(v[2] == "Textbox") then
					
                        DrawbText(self, w, h, v, maxy, posx, posy, dist, tab);
		
                elseif(v[2] == "Selection") then
                        DrawSelect(self, w, h, v, maxy, posx, posy, dist);
                 elseif(v[2] == "Toggle") then
                 	DrawToggle(self, w, h, v, maxy, posx, posy, dist);
                end
                maxy = maxy + 25;
        end
end
 
local function DrawSub(self, w, h)
        for k, v in next, visible do
                if(!v) then continue; end
                for _, var in next, options[k] do
                        DrawSubSub(self, w, h, k, var);
                        
                end

        end
end


 
local function DrawSaveButton(self, w, h)
        local curcol = Color( 0, 0, 0, 0 );
        local mx, my = self:GetPos();
        local bMouse = MouseInArea(mx + 30, my + h - 50, mx + 30 + 150, my + h - 50 + 30);
        if(bMouse) then
                curcol = Color( 0, 0, 0, 50 );
                                surface.SetDrawColor(curcol);
                                surface.DrawRect(30, h - 50, 150, 30 )
        end
       
        surface.SetFont("memeyou2");
        surface.SetTextColor(textcol);
        local tw, th = surface.GetTextSize("Save Configuration");
        surface.SetTextPos( 30 + 75 - tw / 2, h - 50 + 15 - th / 2 );
        surface.DrawText("Save Configuration");
        if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
                saveconfig();
        end
end
 
local function DrawLoadButton(self, w, h)
        local curcol = Color( 0, 0, 0, 0 );
        local mx, my = self:GetPos();
        local bMouse = MouseInArea(mx + 200, my + h - 50, mx + 200 + 150, my + h - 50 + 30);
        if(bMouse) then
                 curcol = Color( 0, 0, 0, 50 );
                                surface.SetDrawColor(curcol);
                                surface.DrawRect(200, h - 50, 150, 30 )
        end
       
        surface.SetFont("memeyou2");
         surface.SetTextColor(textcol)
        local tw, th = surface.GetTextSize("Load Configuration");
        surface.SetTextPos( 200 + 75 - tw / 2, h - 50 + 15 - th / 2 );
        surface.DrawText("Load Configuration");
        if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
                loadconfig();
        end
end
local mousedownbutton = false
local function DrawWhatsNew(self, w, h)
        local curcol = Color( 0, 0, 0, 0 );
        local mx, my = self:GetPos();
        local bMouse = MouseInArea(mx + 670, my + h - 50, mx + 670 + 100, my + h - 50 + 30);
        if(bMouse) then
                 curcol = Color( 0, 0, 0, 50 );
                                surface.SetDrawColor(curcol);
                                surface.DrawRect(670, h - 50, 100, 30 )
        end
       
        surface.SetFont("memeyou2");
         surface.SetTextColor(textcol)
        local tw, th = surface.GetTextSize("What's New?");
        surface.SetTextPos( 670 + 50 - tw / 2, h - 50 + 15 - th / 2 );
        surface.DrawText("What's New?");
       if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			if mousedownbutton == false then
				whatsnewpopup()
				mousedownbutton = true
			end
		elseif (!bMouse || input.IsMouseDown(MOUSE_LEFT)) then
			mousedownbutton = false
        end
end
local mousedownbutton2 = false
local function DrawPlayerlist(self, w, h)
        local curcol = Color( 0, 0, 0, 0 );
        local mx, my = self:GetPos();
        local bMouse = MouseInArea(mx + 370, my + h - 50, mx + 370 + 75, my + h - 50 + 30);
        if(bMouse) then
                 curcol = Color( 0, 0, 0, 50 );
                                surface.SetDrawColor(curcol);
                                surface.DrawRect(370, h - 50, 75, 30 )
        end
       
        surface.SetFont("memeyou2");
         surface.SetTextColor(textcol)
        local tw, th = surface.GetTextSize("Playerlist");
        surface.SetTextPos( 370 + (75/2) - tw / 2, h - 50 + 15 - th / 2 );
        surface.DrawText("Playerlist");
       if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			if mousedownbutton2 == false then
				SpamMenu(true)
				mousedownbutton2 = true
			end
		elseif (!bMouse || !input.IsMouseDown(MOUSE_LEFT)) then
			mousedownbutton2 = false
        end
end

local function DrawSpamlist(self, w, h)
        local curcol = Color( 0, 0, 0, 0 );
        local mx, my = self:GetPos();
        local bMouse = MouseInArea(mx + 540, my + h - 50, mx + 540 + 75, my + h - 50 + 30);
        if(bMouse) then
                 curcol = Color( 0, 0, 0, 50 );
                                surface.SetDrawColor(curcol);
                                surface.DrawRect(540, h - 50, 75, 30 )
        end
       
        surface.SetFont("memeyou2");
         surface.SetTextColor(textcol)
        local tw, th = surface.GetTextSize("Spamlist");
        surface.SetTextPos( 540 + (75/2) - tw / 2, h - 50 + 15 - th / 2 );
        surface.DrawText("Spamlist");
       if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
			if mousedownbutton2 == false then
				SpamMenu(false)
				mousedownbutton2 = true
			end
		elseif (!bMouse || !input.IsMouseDown(MOUSE_LEFT)) then
			mousedownbutton2 = false
        end
end
 
loadconfig();
 
local insertdown2, insertdown, menuopen;
 
local function menu()
        local frame = vgui.Create("DFrame");
        frame:SetSize(800, 600);
        frame:Center();
        frame:SetTitle("");
        frame:MakePopup();
		frame:SetDraggable(true);
        frame:ShowCloseButton(false);
       
        frame.Paint = function(self, w, h)
                if(candoslider && !mousedown && !drawlast && !input.IsMouseDown(MOUSE_LEFT)) then
                        candoslider = false;
                end
                DrawBackground(w, h);
                DrawOptions(self, w, h);
                DrawSub(self, w, h);
                DrawSaveButton(self, w, h);
                DrawLoadButton(self, w, h);
				DrawWhatsNew(self, w, h);
				DrawPlayerlist(self, w, h);
				DrawSpamlist(self, w, h);
                if(drawlast) then
                        drawlast();
                        candoslider = true;
                end
                mousedown = input.IsMouseDown(MOUSE_LEFT);
        end
       
        frame.Think = function()
        		if screengrab then
        			frame:SetPos( ScrW(), ScrH())
        		else
        			frame:Center()
        		end


                if (input.IsKeyDown(KEY_INSERT) && !insertdown2) || testie then
						testie = false
                        frame:Remove();
                        menuopen = false;
						showfov = false
                        candoslider = false;
                        drawlast = nil;
                        for k,v in next, order do

							for _, opt in next, options[v] do
		
								for i=1, #opt do
									if i == 1 then continue; end
									if opt[i][2] == "Textbox" then
										pooptest[v][opt[i][1]][1] = false
									
									end
								end
		
							end

	
    	
						end
		menr = gInt("Color", "Menu Color", "Red")
		meng = gInt("Color", "Menu Color", "Green")
		menb = gInt("Color", "Menu Color", "Blue")
		menuscol = Color(menr, meng, menb, 255)
		texr = gInt("Color", "Text Color", "Red")
		texg = gInt("Color", "Text Color", "Green")
		texb = gInt("Color", "Text Color", "Blue")
		textcol = Color(texr, texg, texb, 255)
		cror = gInt("Color", "Crosshair Color", "Red")
		crog = gInt("Color", "Crosshair Color", "Green")
		crob = gInt("Color", "Crosshair Color", "Blue")
		crocol = Color(cror, crog, crob, 255)
                end
        end
end
 
local function Think()
        if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
                menuopen = true;
                insertdown = true;
                menu();
        elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
                insertdown = false;
        end
        if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
                insertdown2 = true;
        else
                insertdown2 = false;
        end
		menr = gInt("Color", "Menu Color", "Red")
		meng = gInt("Color", "Menu Color", "Green")
		menb = gInt("Color", "Menu Color", "Blue")
		menuscol = Color(menr, meng, menb, 255)
		texr = gInt("Color", "Text Color", "Red")
		texg = gInt("Color", "Text Color", "Green")
		texb = gInt("Color", "Text Color", "Blue")
		textcol = Color(texr, texg, texb, 255)
		cror = gInt("Color", "Crosshair Color", "Red")
		crog = gInt("Color", "Crosshair Color", "Green")
		crob = gInt("Color", "Crosshair Color", "Blue")
		crocol = Color(cror, crog, crob, 255)
		if scnx ~= ScrW() then
			RunConsoleCommand("retry")

		end
end
 
hook.Add("Think", "HackThink", Think);

local FindMetaTable = FindMetaTable;

local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";
local im = FindMetaTable"IMaterial";
local xm = FindMetaTable"VMatrix";
local Eye_Angles = em.EyeAngles

local testchange
local Vector = Vector;
local player = Copy(player);
local Angle = Angle;
local me = LocalPlayer();
local render = Copy(render);
local cma = Copy(cam);
local Material = Material;
local CreateMaterial = CreateMaterial;
local poop = {89, -89}
local fakelagTick, fakelagSend = 0;
local fakechokeS = 0;
local fakeLagSwitch
local sendCount, chokeCount = 0, 0;
local fakelagBucket = {};
local teststuck = 0
local nullVel = Vector();
local function GetAngle(ang)
	if(!gBool("Aimbot", "Accuracy", "NoRecoil")) then return ang + pm.GetPunchAngle(me); end
	return ang;
end

local function fakelag()
	if(!gBool("HVH", "FakeLag", "Enabled")) then
		sendCount = 0;
		chokeCount = 0;
		fakeLagSwitch = false;
		return;
	end
	local choke = gInt("HVH", "FakeLag", "Fakelag Rate");

	if(fakeLagSwitch) then
		if(sendCount >= 1) then
			fakeLagSwitch = false;
			sendCount = 0;
			chokeCount = 0;
		else
			sendCount = sendCount + 1;
		end
	else
		if(chokeCount >= choke) then
			fakeLagSwitch = true;
			sendCount = 0;
			chokeCount = 0;	
		else
			chokeCount = chokeCount + 1;
		end
	end
end

local function fakelagPredict(v)
	if(!gBool("HVH", "FakeLag", "Fakelag Prediction")) then return; end
	if(!fakelagBucket[v]) then
		fakelagBucket[v] = {
			em.GetVelocity(v),
			em.GetPos(v),
			0,
		};
	end

	local oldVel = fakelagBucket[v][1];
		
		if !v:IsOnGround() then
			oldVel.z  = (0.5 * GetConVarNumber("sv_gravity") * engine.TickInterval()^2) + oldVel.z * engine.TickInterval()
		end
	local oldPos = fakelagBucket[v][2];
	local oldVelz = oldVel.z || 0

	fakelagBucket[v][1] = em.GetVelocity(v);
	fakelagBucket[v][2] = em.GetPos(v);

	if(oldVel == nullVel) then 
		fakelagBucket[v][3] = 0;
		return; 
	end

	if(fakelagBucket[v][1] == oldVel && oldPos == fakelagBucket[v][2]) then
		fakelagBucket[v][3] = fakelagBucket[v][3] + 1;
		
		return fakelagBucket[v][3], fakelagBucket[v][1];
	else
		fakelagBucket[v][3] = 0;
		return 1
	end
end




local function Filter(v)
	local enemy = gBool("Visuals", "Filter", "Enemies only");
	local dist = gBool("Visuals", "Filter", "Distance")
	if(enemy) then
		if gBool("Visuals", "Filter", "Always show Friends") then
			if(pm.Team(v) == pm.Team(me)) && (v:GetFriendStatus() ~= "friend" || table.HasValue(Friends, v)) && v ~= me then return false; end
		else
			if(pm.Team(v) == pm.Team(me)) && v ~= me then return false; end
		end
	end
	if(dist) then
		local maxdist = gBool("Visuals", "Filter", "Max Distance");
		if( vm.Distance( em.GetPos(v), em.GetPos(me) ) > (maxdist * 5) ) then return false; end
	end
	if (pm.Team(me) == TEAM_SPECTATOR && me:GetObserverMode() == 0 && pm.Team(v) ~= TEAM_SPECTATOR || pm.Team(me) ~= TEAM_SPECTATOR  && pm.Team(v) == TEAM_SPECTATOR) || !v:Alive() || v:GetObserverMode() ~= 0 then
		return false
	end
	return true;
end



local chamsmat = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local chamsmat2 = CreateMaterial("@", "vertexlitgeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local function GetChamsColor(v, vis)
	local pre = "Chams - Enemy";
	if(pm.Team(v) == pm.Team(me)) then
		pre = "Chams - Team";
	end
	if(vis) then
		local r = gInt("Color", pre, "Visible R") / 255;
		local g = gInt("Color", pre, "Visible G") / 255;
		local b = gInt("Color", pre, "Visible B") / 255;
		return r,g,b;
	end
	local r = gInt("Color", pre, "Not Visible R") / 255;
	local g = gInt("Color", pre, "Not Visible G") / 255;
	local b = gInt("Color", pre, "Not Visible B") / 255;
	return r,g,b;
end

local function GetHandsColor(vis)
	if(!vis) then
		local r = gInt("Color", "Chams - Hands", "Not Visible R") / 255;
		local g = gInt("Color", "Chams - Hands", "Not Visible G") / 255;
		local b = gInt("Color", "Chams - Hands", "Not Visible B") / 255;
		return r,g,b;
	end
	local r = gInt("Color", "Chams - Hands", "Visible R") / 255;
	local g = gInt("Color", "Chams - Hands", "Visible G") / 255;
	local b = gInt("Color", "Chams - Hands", "Visible B") / 255;
	return r,g,b;
end

local function GetWeapsColor()
	
	local r = gInt("Color", "Chams - Weapon", "Visible R") / 255;
	local g = gInt("Color", "Chams - Weapon", "Visible G") / 255;
	local b = gInt("Color", "Chams - Weapon", "Visible B") / 255;
	return r,g,b;
end

local buttons = {
[KEY_FIRST] = {KEY_FIRST, "KEY_FIRST"},
[KEY_NONE] = {KEY_NONE, "KEY_NONE"},
[KEY_0] = {KEY_0, "KEY_0"},
[KEY_1] = {KEY_1, "KEY_1"},
[KEY_2] = {KEY_2, "KEY_2"},
[KEY_3] = {KEY_3, "KEY_3"},
[KEY_4] = {KEY_4, "KEY_4"},
[KEY_5] = {KEY_5, "KEY_5"},
[KEY_6] = {KEY_6, "KEY_6"},
[KEY_7] = {KEY_7, "KEY_7"},
[KEY_8] = {KEY_8, "KEY_8"},
[KEY_9] = {KEY_9, "KEY_9"},
[KEY_A] = {KEY_A, "KEY_A"},
[KEY_B] = {KEY_B, "KEY_B"},
[KEY_C] = {KEY_C, "KEY_C"},
[KEY_D] = {KEY_D, "KEY_D"},
[KEY_E] = {KEY_E, "KEY_E"},
[KEY_F] = {KEY_F, "KEY_F"},
[KEY_G] = {KEY_G, "KEY_G"},
[KEY_H] = {KEY_H, "KEY_H"},
[KEY_I] = {KEY_I, "KEY_I"},
[KEY_J] = {KEY_J, "KEY_J"},
[KEY_K] = {KEY_K, "KEY_K"},
[KEY_L] = {KEY_L, "KEY_L"},
[KEY_M] = {KEY_M, "KEY_M"},
[KEY_N] = {KEY_N, "KEY_N"},
[KEY_O] = {KEY_O, "KEY_O"},
[KEY_P] = {KEY_P, "KEY_P"},
[KEY_Q] = {KEY_Q, "KEY_Q"},
[KEY_R] = {KEY_R, "KEY_R"},
[KEY_S] = {KEY_S, "KEY_S"},
[KEY_T] = {KEY_T, "KEY_T"},
[KEY_U] = {KEY_U, "KEY_U"},
[KEY_V] = {KEY_V, "KEY_V"},
[KEY_W] = {KEY_W, "KEY_W"},
[KEY_X] = {KEY_X, "KEY_X"},
[KEY_Y] = {KEY_Y, "KEY_Y"},
[KEY_Z] = {KEY_Z, "KEY_Z"},
[KEY_PAD_0] = {KEY_PAD_0, "KEY_PAD_0"},
[KEY_PAD_1] = {KEY_PAD_1, "KEY_PAD_1"},
[KEY_PAD_2] = {KEY_PAD_2, "KEY_PAD_2"},
[KEY_PAD_3] = {KEY_PAD_3, "KEY_PAD_3"},
[KEY_PAD_4] = {KEY_PAD_4, "KEY_PAD_4"},
[KEY_PAD_5] = {KEY_PAD_5, "KEY_PAD_5"},
[KEY_PAD_6] = {KEY_PAD_6, "KEY_PAD_6"},
[KEY_PAD_7] = {KEY_PAD_7, "KEY_PAD_7"},
[KEY_PAD_8] = {KEY_PAD_8, "KEY_PAD_8"},
[KEY_PAD_9] = {KEY_PAD_9, "KEY_PAD_9"},
[KEY_PAD_DIVIDE] = {KEY_PAD_DIVIDE, "KEY_PAD_DIVIDE"},
[KEY_PAD_MULTIPLY] = {KEY_PAD_MULTIPLY, "KEY_PAD_MULTIPLY"},
[KEY_PAD_MINUS] = {KEY_PAD_MINUS, "KEY_PAD_MINUS"},
[KEY_PAD_PLUS] = {KEY_PAD_PLUS, "KEY_PAD_PLUS"},
[KEY_PAD_ENTER] = {KEY_PAD_ENTER, "KEY_PAD_ENTER"},
[KEY_PAD_DECIMAL] = {KEY_PAD_DECIMAL, "KEY_PAD_DECIMAL"},
[KEY_LBRACKET] = {KEY_LBRACKET, "KEY_LBRACKET"},
[KEY_RBRACKET] = {KEY_RBRACKET, "KEY_RBRACKET"},
[KEY_SEMICOLON] = {KEY_SEMICOLON, "KEY_SEMICOLON"},
[KEY_APOSTROPHE] = {KEY_APOSTROPHE, "KEY_APOSTROPHE"},
[KEY_BACKQUOTE] = {KEY_BACKQUOTE, "KEY_BACKQUOTE"},
[KEY_COMMA] = {KEY_COMMA, "KEY_COMMA"},
[KEY_PERIOD] = {KEY_PERIOD, "KEY_PERIOD"},
[KEY_SLASH] = {KEY_SLASH, "KEY_SLASH"},
[KEY_BACKSLASH] = {KEY_BACKSLASH, "KEY_BACKSLASH"},
[KEY_MINUS] = {KEY_MINUS, "KEY_MINUS"},
[KEY_EQUAL] = {KEY_EQUAL, "KEY_EQUAL"},
[KEY_ENTER] = {KEY_ENTER, "KEY_ENTER"},
[KEY_SPACE] = {KEY_SPACE, "KEY_SPACE"},
[KEY_BACKSPACE] = {KEY_BACKSPACE, "KEY_BACKSPACE"},
[KEY_TAB] = {KEY_TAB, "KEY_TAB"},
[KEY_CAPSLOCK] = {KEY_CAPSLOCK, "KEY_CAPSLOCK"},
[KEY_NUMLOCK] = {KEY_NUMLOCK, "KEY_NUMLOCK"},
[KEY_ESCAPE] = {KEY_ESCAPE, "KEY_ESCAPE"},
[KEY_SCROLLLOCK] = {KEY_SCROLLLOCK, "KEY_SCROLLLOCK"},
[KEY_INSERT] = {KEY_INSERT, "KEY_INSERT"},
[KEY_DELETE] = {KEY_DELETE, "KEY_DELETE"},
[KEY_HOME] = {KEY_HOME, "KEY_HOME"},
[KEY_END] = {KEY_END, "KEY_END"},
[KEY_PAGEUP] = {KEY_PAGEUP, "KEY_PAGEUP"},
[KEY_PAGEDOWN] = {KEY_PAGEDOWN, "KEY_PAGEDOWN"},
[KEY_BREAK] = {KEY_BREAK, "KEY_BREAK"},
[KEY_LSHIFT] = {KEY_LSHIFT, "KEY_LSHIFT"},
[KEY_RSHIFT] = {KEY_RSHIFT, "KEY_RSHIFT"},
[KEY_LALT] = {KEY_LALT, "KEY_LALT"},
[KEY_RALT] = {KEY_RALT, "KEY_RALT"},
[KEY_LCONTROL] = {KEY_LCONTROL, "KEY_LCONTROL"},
[KEY_RCONTROL] = {KEY_RCONTROL, "KEY_RCONTROL"},
[KEY_LWIN] = {KEY_LWIN, "KEY_LWIN"},
[KEY_RWIN] = {KEY_RWIN, "KEY_RWIN"},
[KEY_APP] = {KEY_APP, "KEY_APP"},
[KEY_UP] = {KEY_UP, "KEY_UP"},
[KEY_LEFT] = {KEY_LEFT, "KEY_LEFT"},
[KEY_DOWN] = {KEY_DOWN, "KEY_DOWN"},
[KEY_RIGHT] = {KEY_RIGHT, "KEY_RIGHT"},
[KEY_F1] = {KEY_F1, "KEY_F1"},
[KEY_F2] = {KEY_F2, "KEY_F2"},
[KEY_F3] = {KEY_F3, "KEY_F3"},
[KEY_F4] = {KEY_F4, "KEY_F4"},
[KEY_F5] = {KEY_F5, "KEY_F5"},
[KEY_F6] = {KEY_F6, "KEY_F6"},
[KEY_F7] = {KEY_F7, "KEY_F7"},
[KEY_F8] = {KEY_F8, "KEY_F8"},
[KEY_F9] = {KEY_F9, "KEY_F9"},
[KEY_F10] = {KEY_F10, "KEY_F10"},
[KEY_F11] = {KEY_F11, "KEY_F11"},
[KEY_F12] = {KEY_F12, "KEY_F12"},
[KEY_CAPSLOCKTOGGLE] = {KEY_CAPSLOCKTOGGLE, "KEY_CAPSLOCKTOGGLE"},
[KEY_NUMLOCKTOGGLE] = {KEY_NUMLOCKTOGGLE, "KEY_NUMLOCKTOGGLE"},
[KEY_LAST] = {KEY_LAST, "KEY_LAST"},
[KEY_SCROLLLOCKTOGGLE] = {KEY_SCROLLLOCKTOGGLE, "KEY_SCROLLLOCKTOGGLE"},
[KEY_COUNT] = {KEY_COUNT, "KEY_COUNT"},
}

hook.Add("PlayerBindPress", "HackPBP", function( ply, bind, pressed )
	--To block more commands, you could add another line similar to
	--the one below, just replace the command
	local test = "KEY_"..string.upper(input.LookupBinding("voicerecord"))
	local gotit
	for i=0, #buttons, 1 do
		if buttons[i][2] == test then
			gotit = i
		end
	end
	if (string.find( bind, "+voicerecord" )&& (ChatOpen) ) then
		return true
	end
end)

local function Chams(v)
    --[[local plycolor = v:GetPlayerColor()
		plycolor = Color(plycolor.x, plycolor.y, plycolor.z)]]
	if !screengrab then
	if (gOption("Visuals", "ESP", "Model Type") == "XQZ") then
		cam.Start3D();
			render.SuppressEngineLighting(true)
			render.MaterialOverride();
			render.SetColorModulation(1,1,1);
			cam.IgnoreZ(true);
			em.DrawModel(v);
			cam.IgnoreZ(false);
			render.SetColorModulation(1,1,1);
			render.MaterialOverride();
			render.SuppressEngineLighting(false)
		cam.End3D();
	elseif (gOption("Visuals", "ESP", "Model Type") == "Chams 2D") then
		cam.Start3D();
			render.SuppressEngineLighting(true)
			render.MaterialOverride(chamsmat);
			render.SetColorModulation(GetChamsColor(v));
				
			em.DrawModel(v);
				
			render.SetColorModulation(GetChamsColor(v, true));
			render.MaterialOverride(chamsmat2);
				
			em.DrawModel(v);
			render.SuppressEngineLighting(false)
			render.MaterialOverride();
		cam.End3D();
	elseif (gOption("Visuals", "ESP", "Model Type") == "Chams 3D") then
		cam.Start3D();
			render.MaterialOverride(chamsmat);
			render.SetColorModulation(GetChamsColor(v));
				
			em.DrawModel(v);
				
			render.SetColorModulation(GetChamsColor(v, true));
			render.MaterialOverride(chamsmat2);
				
			em.DrawModel(v);
			render.MaterialOverride();
		cam.End3D();
	else
		render.SetColorModulation(1,1,1);
		render.MaterialOverride();
	end
	end
end


local mattable = {};


local AudioSource = nil
local AMP = 500
local addfov = 0
refreshrate = FFT_512

--this is deprived of the refreshrate's levels which can be found here: http://wiki.garrysmod.com/page/Enums/FFT
--i.e FFT_512 = 256
bitrate = 256

function Coords(v)
local omin, omax =  v:OBBMins(), v:OBBMaxs()
vCoords = {
    Vector(omin.x, omin.y, omin.z),
    Vector(omin.x, omin.y, omax.z),
    Vector(omin.x, omax.y, omin.z),
    Vector(omin.x, omax.y, omax.z),
    Vector(omax.x, omin.y, omin.z),
    Vector(omax.x, omin.y, omax.z),
    Vector(omax.x, omax.y, omin.z),
    Vector(omax.x, omax.y, omax.z)
    }
	local minx, miny, maxx, maxy = ScrW() * 9999, ScrH() * 9999, -ScrW() * 9999, -ScrH() * 9999
    for _, corner in pairs(vCoords) do
		local screen = (v:GetPos() + corner):ToScreen()
        minx, miny = math.min(minx, screen.x), math.min(miny, screen.y)
        maxx, maxy = math.max(maxx, screen.x), math.max(maxy, screen.y)
    end
    return minx, miny, maxx, maxy
end



local function GetColor(v)
	if(pm.Team(v) == pm.Team(me)) then
		local r = gInt("Colors", "Box - Team", "R");
		local g = gInt("Colors", "Box - Team", "G");
		local b = gInt("Colors", "Box - Team", "B");
		return(Color(r, g, b, 220));
	end
	local r = gInt("Colors", "Box - Enemy", "R");
	local g = gInt("Colors", "Box - Enemy", "G");
	local b = gInt("Colors", "Box - Enemy", "B");
	return(Color(r, g, b, 220));
end


local aimtarget;

local Spectators = {}
local Moderator = {}
local Admin = {}




local fa;
local aa;
local soo = false;
local ctype = 0
local cspin = 0
local ctype2 = 0
local ctype3 = 0
local ctype4 = 0
veloloss = false
cleft = 0
local function FixMovement(ucmd, aaaaa)
	if (fa) then
	aim = fa
	else 
	aim = fa
	end
	if math.NormalizeAngle(cm.GetViewAngles(ucmd).p) > 89 || math.NormalizeAngle(cm.GetViewAngles(ucmd).p) < -89 then
		soo = true
	else
		soo = false
	end
	local move = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), cm.GetUpMove(ucmd));
	if !input.IsKeyDown(KEY_SPACE) then
		canjump = false
	end
	if gBool("Misc", "BunnyHop", "Enabled") && me:GetMoveType() ~= MOVETYPE_NOCLIP && input.IsKeyDown( KEY_SPACE ) && canjump && me:Alive() && !ChatOpen && !PSBox then
	if (gOption("Misc", "BunnyHop", "Strafe Type") == "Full" || (gOption("Misc", "BunnyHop", "Strafe Type") ~= "Off" && (gKey("Misc", "BunnyHop", "cStrafe Toggle"))))  then
		if gKey("Misc", "BunnyHop", "cStrafe Toggle")  then
			veloloss = true
		
			if ctype == 0 then
				ctype = 200
			elseif ucmd:CommandNumber() ~= 0 then
			ctype = ctype + (math.Clamp((me:GetVelocity():Length2D() *1), 0.25, math.Clamp(((math.Clamp(GetConVarNumber("sv_airaccelerate"),0,80)*(engine.TickInterval()*5))),0.20,8)) )+(cm.GetMouseX(ucmd) * -GetConVarNumber("m_yaw"))
			end
			math.NormalizeAngle(ctype)
			Vector(100, 0, cm.GetUpMove(ucmd))
		else
		
			ctype  = 0
			veloloss = false
		
				if(!me:IsOnGround()) then
					if(ucmd:GetMouseX() > 1 || ucmd:GetMouseX() < -1) then
						move = Vector(0, (ucmd:GetMouseX() > 1 && 400 || -400), cm.GetUpMove(ucmd))
					else
						if ucmd:CommandNumber() ~= 0 then
						move = Vector((5200 / me:GetVelocity():Length2D()), ((ucmd:CommandNumber() % 2 == 0) && -400 || 400), cm.GetUpMove(ucmd))
						end
					end
				else
					move = Vector(1, 0, cm.GetUpMove(ucmd))
				end
	
		end
	elseif gOption("Misc", "BunnyHop", "Strafe Type") == "Assist" then
		ctype  = 0
		veloloss = false
		if(ucmd:GetMouseX() > 1 || ucmd:GetMouseX() < -1) then
			move = Vector(0, (ucmd:GetMouseX() > 1 && 300 || -300), cm.GetUpMove(ucmd))
		end
	else
		ctype  = 0
		veloloss = false
		move = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), cm.GetUpMove(ucmd));
	end
	else
	ctype  = 0
	veloloss = false
	move = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), cm.GetUpMove(ucmd));
	end
	ctype2 = math.rad(ctype)
	ctype3 = math.rad(ctype-80)
	ctype4 = math.rad(ctype+80)
	math.NormalizeAngle(ctype3)
	math.NormalizeAngle(ctype4)
	
	local speed = math.sqrt(move.x * move.x + move.y * move.y);
	local ang = vm.Angle(move);
	local yaw = math.rad(cm.GetViewAngles(ucmd).y - fa.y + ang.y);
	--print(yaw)
	cm.SetForwardMove(ucmd, (math.cos(yaw+ ctype2) * speed) * ( soo && -1 || 1 ));
	cm.SetSideMove(ucmd, math.sin(yaw + ctype2) * speed);
	cm.SetUpMove(ucmd, cm.GetUpMove(ucmd));
end

local function Clamp(val, min, max)
	if(val < min) then
		return min;
	elseif(val > max) then
		return max;
	end
	return val;
end

local function NormalizeAngle(ang)
	ang.x = math.NormalizeAngle(ang.x);
	ang.p = math.Clamp(ang.p, -120, 120);
end


local table = Copy(table);
local dists = {};



function Transform(pos, matrix)
	local matA, matB, matC = matrix[1], matrix[2], matrix[3]
	local x = Vector(matA[1], matA[2], matA[3])
	local y = Vector(matB[1], matB[2], matB[3])
	local z = Vector(matC[1], matC[2], matC[3])

	return Vector(pos:Dot(x) + matA[4], pos:Dot(y) + matB[4], pos:Dot(z)+ matC[4])
end


local function Hitbox(v)
	if v:IsValid() then
		local numHitBoxes = v:GetHitBoxCount( 0 )
		local headbox = nil
		local headbone = nil
		local headfound = false
		local spinebox = nil
		local spinebone = nil
		local spinefound = false
		local zombbox = nil
		local zombbone = nil
		local zombfound = false
		zombfound2 = false

	if !string.find(string.lower(GAMEMODE.Name), "prop") then
		for group = 0, em.GetHitBoxGroupCount(v) - 1 do
			local count = em.GetHitBoxCount(v, group)
			for hitbox = 0, count - 1 do
				local bone = em.GetHitBoxBone( v, hitbox, group );
				if(!bone) then continue; end
				local min, max = em.GetHitBoxBounds( v, hitbox, group );
				local bonepos, boneang = em.GetBonePosition( v, bone );
			end
		end
		for hitbox=0, numHitBoxes - 1 do
			local bone = v:GetHitBoxBone( hitbox, 0 )
			if !gBool("Aimbot", "Target", "Bodyaim") then
				if string.find(string.lower(GAMEMODE.Name), "zomb") then
					if string.find(string.lower(v:GetBoneName( bone )), "head") then
					zombbox = hitbox
					zombbone = em.GetHitBoxBone( v, hitbox, 0 )
					zombfound = true
					elseif string.find(string.lower(v:GetBoneName( bone )), "spine") && !zombfound then
					zombbox = hitbox
					zombbone = em.GetHitBoxBone( v, hitbox, 0 )
			
					elseif (string.find(string.lower(v:GetBoneName( bone )), "body") || string.find(string.lower(v:GetBoneName( bone )), "headcrab")) && !zombfound then
					zombbox = hitbox
					zombbone = em.GetHitBoxBone( v, hitbox, 0 )
				
					elseif hitbox == (numHitBoxes - 1) && bone && !zombfound then
						zombbox = 0
						zombbone = em.GetHitBoxBone( v, 0, 0 )
						zombfound = true
					end
				elseif string.find(string.lower(v:GetBoneName( bone )), "head") then
				headbox = hitbox
				headbone = em.GetHitBoxBone( v, hitbox, 0 )
				headfound = true
				elseif string.find(string.lower(v:GetBoneName( bone )), "spine2") && !headfound then
				spinebox = hitbox
				spinebone = em.GetHitBoxBone( v, hitbox, 0 )
				elseif hitbox == (numHitBoxes - 1) && !headfound then
				headbox = 0
				headbone = em.GetHitBoxBone( v, 0, 0 )
				headfound = true
				end
			else
				if string.find(string.lower(GAMEMODE.Name), "zomb") then
					if string.find(string.lower(v:GetBoneName( bone )), "spine") then
					zombbox = hitbox
					zombbone = em.GetHitBoxBone( v, hitbox, 0 )
					zombfound = true
					elseif (string.find(string.lower(v:GetBoneName( bone )), "body") || string.find(string.lower(v:GetBoneName( bone )), "headcrab")) && !zombfound then
					zombbox = hitbox
					zombbone = em.GetHitBoxBone( v, hitbox, 0 )
					elseif hitbox == (numHitBoxes - 1) && !zombfound then
						zombbox = 0
						zombbone = em.GetHitBoxBone( v, 0, 0 )
						zombfound = true
					end
				else
					if string.find(string.lower(v:GetBoneName( bone )), "spine2") then
						spinebox = hitbox
						spinebone = em.GetHitBoxBone( v, hitbox, 0 )
						spinefound = true
					elseif string.find(string.lower(v:GetBoneName( bone )), "spine1") && !spinefound then
						spinebox = hitbox
						spinebone = em.GetHitBoxBone( v, hitbox, 0 )
					elseif hitbox == (numHitBoxes - 1) && !spinefound then
					spinebox = 0
					spinebone = em.GetHitBoxBone( v, 0, 0 )
					spinefound = true
					end
				end
			end
		end
		if headbone then
			local Matrix = em.GetBoneMatrix(v, headbone)
			if not Matrix then 
			return 
			end
			Matrix = xm.ToTable(Matrix)
			local min, max = em.GetHitBoxBounds( v, headbox, 0 );
			return (Transform(min, Matrix) + Transform(max, Matrix)) * 0.5;
		elseif zombbone then
			local Matrix = em.GetBoneMatrix(v, zombbone)
			if not Matrix then 
			return 
			end
			Matrix = xm.ToTable(Matrix)
			local min, max = em.GetHitBoxBounds( v, zombbox, 0 );
			return (Transform(min, Matrix) + Transform(max, Matrix)) * 0.5;
		elseif spinebox then
			local Matrix = em.GetBoneMatrix(v, spinebone)
			if not Matrix then 
			return 
			end
			Matrix = xm.ToTable(Matrix)
			local min, max = em.GetHitBoxBounds( v, spinebox, 0 );
			return (Transform(min, Matrix) + Transform(max, Matrix)) * 0.5;
		else
			if em.GetBoneMatrix(v, 0, 0) ~= nil then
			local Matrix = em.GetBoneMatrix(v, 0, 0)
			if not Matrix then 
			return 
			end
			Matrix = xm.ToTable(Matrix)
			local min, max = em.GetHitBoxBounds( v, 0, 0 );
			return (Transform(min, Matrix) + Transform(max, Matrix)) * 0.5;
			end
		end
	else
		return em.LocalToWorld(v, em.OBBCenter(v))
	end
	end
end

local function GetPos(v)

	if(gBool("Aimbot", "Target", "Bodyaim")) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end

	local eyes = em.LookupAttachment(v, "eyes");
	
	if(!eyes) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end
	
	local pos = em.GetAttachment(v, eyes);
	
	if(!pos) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end
	
	return(pos.Pos);
end

local aimignore;

function CloseChat()
	ChatOpen = false
end
hook.Add("FinishChat", "chatclosed", CloseChat)

function OpenChat(isTeamChat)
	if ( isTeamChat == false ) then
		ChatOpen = true
	else
		ChatOpen = true
	end
end
hook.Add("StartChat", "chatopened", OpenChat)

local function fasAutowall(wep, startPos, aimPos, v)
local trace_walls = bit.bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX);
local NoPenetration = {[MAT_SLOSH] = true};
local PenMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2};
local trace_normal = bit.bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER);
local MaxPenetration
		ammotype = game.GetAmmoName(wep:GetPrimaryAmmoType())
		wepname = me:GetActiveWeapon():GetClass()
		wepid =  string.Explode("_", wepname)
		if string.find(wepname, "m9k_") then
			if GetConVarNumber("M9KDisablePenetration") == 1 then
			return false
			end
		else
			return false
		end
		
		
 
	if ammotype == "SniperPenetratedRound" then -- .50 Ammo
				MaxPenetration = 20
		elseif ammotype == "pistol" then -- pistols
				MaxPenetration = 9
		elseif ammotype == "357" then -- revolvers with big ass bullets
				MaxPenetration = 12
		elseif ammotype == "smg1" then -- smgs
				MaxPenetration = 14
		elseif ammotype == "ar2" then -- assault rifles
				MaxPenetration = 16
		elseif ammotype == "buckshot" then -- shotguns
				MaxPenetration = 5
		elseif ammotype == "slam" then -- secondary shotguns
				MaxPenetration = 5
		elseif ammotype ==     "AirboatGun" then -- metal piercing shotgun pellet
				MaxPenetration = 17
		else
				MaxPenetration = 14
		end
		local tr = {}
		local tres = {}
		local dist = {}
	
	local dir = ((Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval())) - me:EyePos()):Angle();
	local maxpen = {}

	tr[1] = {
		start = me:EyePos(),
		endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[1] = util.TraceLine(tr[1])
	tr[2] = {
		start = tres[1].HitPos + (dir:Forward() * MaxPenetration),
		endpos = tres[1].HitPos,
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[2] = util.TraceLine(tr[2])
	if tres[1].Fraction == 1 && !tres[2].StartSolid then
	return true
	elseif (!tres[2].StartSolid && (tres[2].Fraction * MaxPenetration) <= MaxPenetration) && (tres[2].Fraction >= 0.00000001) then
	maxpen[1] = MaxPenetration * tres[2].Fraction
	elseif tres[2].StartSolid or (tres[2].Fraction == 0) then
	return false
	end
	
	tr[3] = {
		start = tres[2].HitPos,
		endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[3] = util.TraceLine(tr[3])
	tr[4] = {
		start = tres[3].HitPos + (dir:Forward() * maxpen[1]),
		endpos = tres[3].HitPos,
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[4] = util.TraceLine(tr[4])
	if tres[3].Fraction == 1 && tres[4].StartSolid then
	return true
	elseif (!tres[4].StartSolid && (tres[4].Fraction * maxpen[1]) <= maxpen[1]) && (tres[4].Fraction >= 0.00000001) then
	maxpen[2] = maxpen[1] * tres[4].Fraction
	elseif tres[4].StartSolid or (tres[4].Fraction == 0) then
	return false
	end
	
	tr[5] = {
		start = tres[4].HitPos,
		endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[5] = util.TraceLine(tr[5])
	tr[6] = {
		start = tres[5].HitPos + (dir:Forward() * maxpen[2]),
		endpos = tres[5].HitPos,
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[6] = util.TraceLine(tr[6])
	if tres[5].Fraction == 1 && tres[6].StartSolid then
	return true
	elseif (!tres[6].StartSolid && (tres[6].Fraction * maxpen[2]) <= maxpen[2]) && (tres[6].Fraction >= 0.00000001) then
	maxpen[3] = maxpen[2] * tres[6].Fraction
	elseif tres[6].StartSolid or (tres[6].Fraction == 0) then
	return false
	end
	
	
	tr[7] = {
		start = tres[6].HitPos,
		endpos = Hitbox(v),
		mask = MASK_SHOT,
		filter = {me, v},
	};
	tres[7] = util.TraceLine(tr[7])
	if tres[7].Fraction == 1 then
	return true
	end
	
end
local angting
function GetAng(angle, src, dst)
    delta = src - dst
    hyp = delta:Length2D()
    ang = Angle(math.deg(math.atan(delta.z / hyp)), math.deg(math.atan(delta.y / delta.x)), 0)
	
    if (delta.x >= 0) then
		ang.y = ang.y + 180
	end
	
    pitch = angle.p * math.pi / 180
    yaw = angle.y * math.pi / 180
    tmp = math.cos(pitch)
	
    aim = Angle(tmp * math.cos(yaw), math.sin(yaw) * tmp, -math.sin(pitch))
	
    pitch = ang.p * math.pi / 180
    yaw = ang.y * math.pi / 180
    tmp = math.cos(pitch)
	
    ang = Angle(tmp * math.cos(yaw), math.sin(yaw) * tmp, -math.sin(pitch))
	
    mag_s = math.sqrt((aim.p * aim.p) + (aim.y * aim.y) + (aim.r * aim.r))
    mag_d = math.sqrt((aim.p * aim.p) + (aim.y * aim.y) + (aim.r * aim.r))
    u_dot_v = aim.p * ang.p + aim.y * ang.y + aim.r * ang.r
	testfov = math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)
	if (math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)) then
		angting = (math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi))
    return math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)
	end
end

local testfov = 0
function CanFov(angle, src, dst)
	if gInt("Aimbot", "Aimbot", "fov") == 0 || gInt("Aimbot", "Aimbot", "fov") == 180 then
		return true
	end
    local delta = src - dst
    local hyp = delta:Length2D()
    local ang = Angle(math.deg(math.atan(delta.z / hyp)), math.deg(math.atan(delta.y / delta.x)), 0)
	
    if (delta.x >= 0) then
		ang.y = ang.y + 180
	end
	
    local pitch = angle.p * math.pi / 180
    local yaw = angle.y * math.pi / 180
    local tmp = math.cos(pitch)
	
    local aim = Angle(tmp * math.cos(yaw), math.sin(yaw) * tmp, -math.sin(pitch))
	
    pitch = ang.p * math.pi / 180
    yaw = ang.y * math.pi / 180
    tmp = math.cos(pitch)
	
    ang = Angle(tmp * math.cos(yaw), math.sin(yaw) * tmp, -math.sin(pitch))
	
    local mag_s = math.sqrt((aim.p * aim.p) + (aim.y * aim.y) + (aim.r * aim.r))
    local mag_d = math.sqrt((aim.p * aim.p) + (aim.y * aim.y) + (aim.r * aim.r))
    local u_dot_v = aim.p * ang.p + aim.y * ang.y + aim.r * ang.r
	testfov = math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)
	if (math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)) <= gInt("Aimbot", "Aimbot", "fov") then
    return math.acos(u_dot_v / (mag_s * mag_d)) * (180 / math.pi)
	end
end

local IsFirstTimePredicted = IsFirstTimePredicted;
local CurTime = CurTime;
local servertime=0;
local bit = Copy(bit)

function ClipVelocity( inn, normal, overbounce )
backoff = nil
change = nil
angle = nil
blocked = nil
out = Vector()
angle = normal
blocked = 0
if angle[3] > 0 then blocked = 1 end
if angle[3] < 0 then blocked = 3 end
if !angle then blocked = 2 end
backoff = inn:Dot( normal ) * overbounce
for i = 1, 3 do
change = normal[i] * backoff
out[i] = inn[i] - change
end
local adjust = out:Dot( normal )
if adjust < 0 then
out = out - normal * adjust
end
return blocked, out
end


local testturn = {}
local turn = {}
local moving = {}
checkturn = {}
checkturn2 = {}
bunny = {}
bunny2 = {}

for i = 0, game.MaxPlayers(), 1 do
turn[i] = 0
end
for i = 0, game.MaxPlayers(), 1 do
testturn[i] = Angle(0, 0, 0)
end

for i = 0, game.MaxPlayers(), 1 do
checkturn[i] = Angle(0,0,0)
end

for i = 0, game.MaxPlayers(), 1 do
checkturn2[i] = Angle(0,0,0)
end
for i = 0, game.MaxPlayers(), 1 do
bunny[i] = 0
end

for i = 0, game.MaxPlayers(), 1 do
bunny2[i] = 0
end

local function crossbowcheck(v, withtime, cross, prfm , Zdrop, pDist)
	local fake, oldvelo = fakelagPredict(v) || 1;
	local sA, sB, sC = 0, 0, 0
	local aA, aB, aC = 0, 0, 0
	local disma2 = v:GetVelocity()
	local perf = 25
	local grav = GetConVarNumber("sv_gravity")
	if prfm then
		perf = prfm
	end
	local tim = 3500
	disma2 = disma2:Angle()
	aC = GetAng(disma2, v:GetShootPos(), em.EyePos(me))
	sB = 3500
		sA = (em.EyePos(v)+(Vector(v:GetVelocity().x,v:GetVelocity().y,velopre))):Distance(em.EyePos(v)) + ((em.EyePos(v)+(Vector(v:GetVelocity().x,v:GetVelocity().y,velopre))):Distance(em.EyePos(v)) * engine.TickInterval())
	if pDist then
		sA = pDist:Distance(em.EyePos(v)) + (pDist:Distance(em.EyePos(v))*engine.TickInterval())
	end
	sC = math.pow(sA,2) + math.pow(sB,2) - 2*(sA)*(sB)*(math.cos(aC))
	sC = math.sqrt(sC)
	if withtime then
		tim = (em.GetPos(v):Distance(em.GetPos(me)))/sC 
		if cross then
			tim = tim +(tim*((me:Ping() * (92/78))/1000))
		else
			tim = 0
		end
	else
		tim = 1
	end
		if cross then
			tim = tim + (tim *(me:Ping() /1000))
		end
		tim = tim*fake
		local pl = v:EntIndex()
		local velocityply = em.GetVelocity(v)
			if oldvelo then
				velocityply = oldvelo
			end
		local block = 0
		local starty = em.GetPos(v)
		local oldplypos = em.GetPos(v)
		local disv
		local air = 0
		local maxair = 0
		local turnstate = false
		local turnnum = 0
		local turnflag = Vector()
		local turnflag2 = Vector()
		local zvelo
		local gred, ggreen, gblue = 255, 0, 0
		local move
		local perf = 25
			
		local cDrop = ((0.5 * grav * 0.05) * (tim^2) + math.max(1, (tim * 0.4)))
		for i = 0, perf, 1 do
		if ggreen ~= 255 then
			ggreen = math.Clamp((255/perf) * (2*i), 0, 255)
		elseif ggreen == 255 then
			gred = math.Clamp((255 - (255 * (2*(i-perf)))), 0, 255)
		end
	local mins = v:OBBMins()
	local maxs = v:OBBMaxs()
	if v:Alive() then
		if block ~= 1 then
			disv = (velocityply*(tim+((me:Ping() * (92/78))/1000)))* (1/perf)
			if withtime && !cross then	
				disv = (((velocityply*engine.TickInterval())* (1/perf)))
			end
		else
			disv = (((velocityply*tim)/8) * (1/perf))
			if withtime && !cross then
				disv = ((((velocityply*engine.TickInterval())*tim)/8) * (1/perf))
			end	
		end
		if (!v:IsOnGround() && block ~= 1) && v:GetMoveType() ~= MOVETYPE_NOCLIP then
		disv.z  = (0.5 * -grav * math.pow((tim*(1+i)/(perf)),2) + (velocityply.z) * ((tim)*(1+i)/(perf)))
		if withtime && !cross then
		disv.z  = (0.5 * -grav * math.pow(((engine.TickInterval() * fake)*(1+i)/(perf)),2) + (velocityply.z) * ((engine.TickInterval() * fake)*(1+i)/(perf)))
		end
		end
	
		zvelo = Vector(disv.x, disv.y, (oldplypos.z - starty.z) +(disv.z))
		if pm.KeyDown(me, IN_WALK) && Zdrop then
		zvelo:Rotate(Angle(0,(turn[pl]* tim) * (100*(i/perf)),0))
		if block == 1 then
		zvelo:Rotate(Angle(0,turn[pl] * (100*(turnnum/perf)),0))
		end
		end
	plytr = {
		start = starty + Vector(0,0,0.1),
		endpos = starty + zvelo+ Vector(0,0,0.1),
		maxs = maxs,
		mins = mins,
		filter = v,
	}
	
	plytr2 = {
		start = starty + Vector(0,0,0.1),
		endpos = starty - Vector(0,0,1),
		maxs = maxs - Vector(0,0,maxs.z),
		mins = mins,
		filter = v,
	}
	
	local plytres = util.TraceHull(plytr)
	if cross then
	plytres2 = util.TraceHull(plytr2)
	end
	if Zdrop && cross then
	if !plytres2.Hit && air == 0 then
		air = 1
		
	elseif plytres2.Hit then
		air = 0
		maxair = 0
	end
	end
	
	if plytres.Hit then
	starty = plytres.HitPos
	turnstate = true
	turnnum = i
	block, velocityply = ClipVelocity( velocityply, plytres.HitNormal, 1 )
	
	if block ~= 0 then
	oldplypos = plytres.HitPos
	end
	else
		starty = plytr.endpos
	end

	if i == perf then
		if Zdrop then 
			return plytres.HitPos + Vector(0,0,cDrop)
		else
			return plytres.HitPos
		end
	end
	end
	end
end


local function Valid(v)
	--[[if pm.GetActiveWeapon(me):IsValid() then
		local w = pm.GetActiveWeapon(me);
		if (!w || !em.IsValid(w) || !me:Alive()) then return false
			else
			if wm.GetNextPrimaryFire(w) > servertime || (wm.GetNextPrimaryFire(w) <= servertime && (!input.IsKeyDown(gKey("Aimbot", "Aimbot", "Key Toggle")) || input.IsMouseDown(gKey("Aimbot", "Aimbot", "Key Toggle")) && !gBool("Aimbot", "Aimbot", "Autosnap"))) then
				return false
			end
		end
	end]]
	wep = me:GetActiveWeapon()
	if IsValid(wep) then
		if (me:GetActiveWeapon():GetPrimaryAmmoType() > 0 && wm.GetNextPrimaryFire(wep) > servertime) then
			return
		end
	end
	if !v then
	return false
	end
	if(!v || !v:Alive() || v == me  || v:IsDormant() || v:GetObserverMode() ~= 0 || (!gKey("Aimbot", "Aimbot", "Key Toggle") && !gBool("Aimbot", "Aimbot", "Autosnap")) || em.Health(v) < 0 || v:GetObserverMode() > 0 || (v == aimignore && gOption("Aimbot", "Target", "Selection") == "Nextshot")) then return false; end
	if !CanFov(fa, me:GetShootPos(), Hitbox(v)) then return false; end
	modcolor = em.GetColor(v)
	if string.find(string.lower(GAMEMODE.Name), "prop") then
		modcolor = Color(255,255,255)
	end

	if(gBool("Aimbot", "Target", "Ignore Spawn Protection")) then
		modcolor = Color(255,255,255)
		if tttgod then
			modcolor.r = 100
		end
	end
	if(gBool("Aimbot", "Target", "Ignore Bots")) then
		if(pm.IsBot(v)) then return false; end
	end
	if(gBool("Aimbot", "Target", "Ignore Team")) then
		if(pm.Team(v) == pm.Team(me)) then return false; end
	end
	if(gBool("Aimbot", "Target", "Ignore Friends")) then
		if (v:GetFriendStatus() == "friend") || (table.HasValue(Friends, v)) then return false; end
	end
	if tbudd && table.HasValue(Tbud, v) then return false; end
	if string.find(string.lower(GAMEMODE.Name), "morbus") then
		if !tbudd && !table.HasValue(Traitors, v) && GetRoundState() ==3 && gBool("Aimbot", "Target", "Ignore Team") then return false; end
		if tbudd && table.HasValue(Traitors, v)&&GetRoundState() ==3 && gBool("Aimbot", "Target", "Ignore Team") then return false; end
	end
	if tdect && table.HasValue(Tdectt, v) then return false; end
	if(v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || v.ULXHasGod ||(modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255  ) then return false; end
	if (pm.Team(me) == TEAM_SPECTATOR && pm.Team(v) ~= TEAM_SPECTATOR || pm.Team(me) ~= TEAM_SPECTATOR && pm.Team(v) == TEAM_SPECTATOR) || !v:Alive() || v:GetObserverMode() ~= 0 then
		return false
	end
	
	tr = {
		start = me:EyePos(),
		endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
		mask = MASK_SHOT,
		filter = {me},
	};
	if !string.find(string.lower(GAMEMODE.Name), "prop") then
		tr = {
			start = me:EyePos(),
			endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
			mask = MASK_SHOT,
			filter = {me, v},
		};
		if util.TraceLine(tr).Fraction == 1 then
			return true
		else
			local wep = me:GetActiveWeapon();
			if(wep && wep:IsValid() && gBool("Aimbot", "Accuracy", "Auto Wall")) then
					
				if me:Team() == TEAM_SPECTATOR && me:Alive() then
					tr2 = {
						start = me:EyePos(),
						endpos = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
						mask = MASK_SHOT,
						filter = function( ent ) if ( ent:GetClass() == "worldspawn" && ent ~= v && me ~= ent ) then return true end end,
					};
					return util.TraceLine(tr2).Fraction == 1 || util.TraceLine(tr2).Entity == v
				elseif (me:Team() ~= TEAM_SPECTATOR && me:Alive()) then
					tr2 = {
						start = Hitbox(v) + (em.GetVelocity(v) * engine.TickInterval()),
						endpos = me:EyePos(),
						mask = MASK_SHOT,
						filter = function( ent ) if ( ent:GetClass() ~= "func_breakable" && ent ~= v && me ~= ent ) then return true end end,
					};
					if (util.TraceLine(tr2).Fraction == 1) then
						return true
					else
						if me:GetActiveWeapon() then
							if string.find( me:GetActiveWeapon():GetClass(), "m9k_") && gBool("Aimbot", "Accuracy", "Auto Wall") then
								return fasAutowall(wep, tr2.start, util.TraceLine(tr2).HitPos, v)
							end
						end
					end
				end
			end
			return false
		end
	else
		if util.TraceLine(tr).Entity:IsValid() then
			if (((util.TraceLine(tr).Entity:GetClass()) == "ph_prop" || util.TraceLine(tr).Fraction == 1) && team.GetName(me:Team()) == "Hunters") || (((util.TraceLine(tr).Entity:GetClass()) == "player" || util.TraceLine(tr).Fraction == 1) && team.GetName(me:Team()) == "Props") then
				return true
			end
		elseif util.TraceLine(tr).Fraction == 1 then
			return true
		end
	end
end

local function gettarget()
	
	local opt = gOption("Aimbot", "Target", "Selection");
	
	local sticky = gOption("Aimbot", "Aimbot", "Non-Sticky");
	
	if(opt == "Distance") then

		if( !sticky && Valid(aimtarget) ) then return; end

		dists = {};
		
		for k,v in next, player.GetAll() do
			if v ~= plysp then
				v:SetNoDraw(false)
			else
				v:SetNoDraw(true)
			end
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
		end
		
		table.sort(dists, function(a, b)
			return(a[1] < b[1]);
		end);
		
		aimtarget = dists[1] && dists[1][2] || nil;
		
		
	elseif(opt == "Health") then
		
		if( !sticky && Valid(aimtarget) ) then return; end

		dists = {};
		
		for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { em.Health(v), v };
		end
		
		table.sort(dists, function(a, b)
			return(a[1] < b[1]);
		end);
		
		aimtarget = dists[1] && dists[1][2] || nil;
		
	elseif(opt == "Nextshot") then
		if( !sticky && Valid(aimtarget) ) then return; end
		aimtarget = nil;
		local allplys = player.GetAll();
		local avaib = {};
		for k,v in next,allplys do
			avaib[math.random(100)] = v;
		end
		
		for k,v in next, avaib do
			if(Valid(v)) then
				aimtarget = v;
				
			end
		end
	elseif (opt == "Closest to Crosshair") then
	if ( !sticky && Valid(aimtarget) ) then return; end
	dists = {};
		local x, y = ScrW(), ScrH()
		local AngA, AngB = 0
		for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			local EyePos = v:EyePos():ToScreen()
			dists[#dists + 1] = { math.Dist(x / 2, y / 2, EyePos.x, EyePos.y), v };
		end
		
		table.sort(dists, function(a, b)
			return(a[1] < b[1]);
		end);
		
		aimtarget = dists[1] && dists[1][2] || nil;
		
	end
end




local cones = {};



local nullvec = Vector() * -1;

hook.Add("Move", "HackMove", function()
	if(!IsFirstTimePredicted()) then return; end
	servertime = CurTime();
end);
local FaAng = {}
for i = 0, game.MaxPlayers(), 1 do
FaAng[i] = {0,0,0}
end

GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget;
	local w = pm.GetActiveWeapon(me);
	local Spread = data.Spread * -1;
	if wm.GetNextPrimaryFire(w) <= servertime then
	--chat.AddText(color_white, tostring(checkturn2[me:EntIndex()]))
	end
	if(!w || !em.IsValid(w) || cones[em.GetClass(w)] == Spread || Spread == nullvec) then return; end
	cones[em.GetClass(w)] = Spread;
end

local function PredictSpread(ucmd, ang)
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w) || !cones[em.GetClass(w)] || !gBool("Aimbot", "Accuracy", "NoSpread") || ((gKey("Aimbot", "Aimbot", "Key Toggle"))&& (!gBool("Aimbot", "Aimbot", "Autofire")) && !cm.KeyDown(ucmd, IN_ATTACK))) then return am.Forward(ang); end
	return(dickwrap.Predict(ucmd, am.Forward(ang), cones[em.GetClass(w)]));
end
local wepswitch = 0
local function Autofire(ucmd)
	
	if(pm.KeyDown(me, IN_ATTACK) && gBool("Aimbot", "Aimbot", "Auto Pistol") && gBool("Aimbot", "Aimbot", "Enabled") && me:GetActiveWeapon():Clip1() > 0) then
		cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 1 ) );

		wepswitch = 0
		elseif gBool("Aimbot", "Aimbot", "Autofire") && gBool("Aimbot", "Aimbot", "Enabled") && me:GetActiveWeapon():Clip1() > 0 then
		cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 1 ) );
		wepswitch = 0
		elseif me:GetActiveWeapon():Clip1() <= 0  then
		cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 1 ) );
	end
end


local function WeaponCanFire()
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w)) then return true; end
	
	return( wm.GetNextPrimaryFire(w) <= servertime  );
end

local function WeaponShootable()
    local wep = pm.GetActiveWeapon(me);
    if( em.IsValid(wep) ) then
	     local n = string.lower(wep:GetPrintName())
	     if( wep:Clip1() <= 0 ) then
		    return false;
		 end
		 
		 
		 
		 
		 if( string.find(n,"knife") or string.find(n,"grenade") or string.find(n,"sword") or string.find(n,"bomb") or string.find(n,"ied") or string.find(n,"c4") or string.find(n,"slam") or string.find(n,"climb") or string.find(n,"hand") or string.find(n,"fist") ) then
		    return false;
		 end
		  
		  
		  return true;
	end
end



local ox=-181;
local oy=0;

local ofx=-181;
local ofy=0;

local function RandCoin()
	local randcoin = math.random(0,1);
	if(randcoin == 1) then return 1; else return -1; end
end

local function GetX()
	if gInt("HVH", "Anti-Aim", "Pitch") == 0 then
	ox = fa.p
	else
		if gBool("HVH", "Anti-Aim", "Negitive Pitch") then
		ox = -gInt("HVH", "Anti-Aim", "Pitch")
		else
		ox = gInt("HVH", "Anti-Aim", "Pitch")
		end
	end
end

local function GetFX()
	if gInt("HVH", "FakeAngles", "Pitch") == 0 then
	ofx = fa.p
	else
		if gBool("HVH", "FakeAngles", "Negitive Pitch") then
		ofx = -gInt("HVH", "FakeAngles", "Pitch")
		else
		ofx = gInt("HVH", "FakeAngles", "Pitch")
		end
	end
end

local function GetClosest()
	local ddists = {};
	
	local closest;
		
	for k,v in next, player.GetAll() do
	if( !v:Alive() || v == me || gBool("Aimbot", "Target", "Ignore Friends") && (v:GetFriendStatus() ~= "friend" || ! table.HasValue(Friends, v) )) then continue; end
		ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
		
	table.sort(ddists, function(a, b)
		return(a[1] < b[1]);
	end);
		
	closest = ddists[1] && ddists[1][2] || nil;
	
	if(!closest) then return fa.y; end
	
	local pos = em.GetPos(closest) + (em.GetVelocity(closest) * (me:Ping()/1000))+ (em.GetVelocity(closest) * (closest:Ping()/1000));
	
	local pos = vm.Angle(pos - em.EyePos(me));
	
	return( pos.y );
end
local jit_AngY = 0
local jit_yawC = false

local jit_AngFY = 0
local jit_yawFC = false

local function GetY()
	local getclose = 0
	if gInt("HVH", "Anti-Aim", "Pitch") > 90 then
		if (jit_AngY > 5) then
			jit_yawC = true
		elseif (jit_AngY < -5) then
			jit_yawC = false
		end
		if (jit_yawC == true) then
			jit_AngY = jit_AngY - 0.3
		elseif (jit_yawC == false) then
			jit_AngY = jit_AngY + 0.3
		end
	else 
		jit_AngY = 0
		jit_yawC = false
	end
		if gBool("HVH", "Anti-Aim", "Aim At Closest") then
		getclose = GetClosest() - fa.y
		if gBool("HVH", "Anti-Aim", "Static") then
			getclose = GetClosest()
		end
	end
	if gBool("HVH", "Anti-Aim", "Static") then
	if gInt("HVH", "Anti-Aim", "Spin") ~= 0 then
	oy = math.fmod(CurTime() / .1 * gInt("HVH", "Anti-Aim", "Spin") * 6, 360) + getclose
	else
	oy = gInt("HVH", "Anti-Aim", "Yaw") + jit_AngY + getclose
	end
	else
	if gInt("HVH", "Anti-Aim", "Spin") ~= 0 then
	oy = fa.y + math.fmod(CurTime() / .1 * gInt("HVH", "Anti-Aim", "Spin") * 6, 360) + getclose
	else
	oy = fa.y + gInt("HVH", "Anti-Aim", "Yaw") + jit_AngY + getclose
	end
	end
end

local function GetFY()
	local getclosef = 0
	if gInt("HVH", "FakeAngles", "Pitch") > 90 then
		if (jit_AngFY > 5) then
			jit_yawFC = true
		elseif (jit_AngFY < -5) then
			jit_yawFC = false
		end
		if (jit_yawFC == true) then
			jit_AngFY = jit_AngFY - 0.3
		elseif (jit_yawFC == false) then
			jit_AngFY = jit_AngFY + 0.3
		end
	else 
		jit_AngFY = 0
		jit_yawFC = false
	end
	if gBool("HVH", "FakeAngles", "Aim At Closest") then
		getclosef = GetClosest() - fa.y
		if gBool("HVH", "FakeAngles", "Static") then
			getclosef = GetClosest()
		end
	end

	if gBool("HVH", "FakeAngles", "Static") then
	if gInt("HVH", "FakeAngles", "Spin") ~= 0 then
	ofy = math.fmod(CurTime() / .1 * gInt("HVH", "FakeAngles", "Spin") * 6, 360) + getclosef
	else
	ofy = gInt("HVH", "FakeAngles", "Yaw") + jit_AngFY + getclosef
	end
	else
	if gInt("HVH", "FakeAngles", "Spin") ~= 0 then
	ofy = fa.y + math.fmod(CurTime() / .1 * gInt("HVH", "FakeAngles", "Spin") * 6, 360) + getclosef
	else
	ofy = fa.y + gInt("HVH", "FakeAngles", "Yaw") + jit_AngFY + getclosef
	end
	end
end

local plychange = {}
local plyadd = {}
for i = 1, game.MaxPlayers(), 1 do
plychange[i] = 0
plyadd[i] = 0
end
local function DoAAA(v)
	fake, oldvelo = fakelagPredict(v) || 1, em.GetVelocity(v)

	velos= em.GetVelocity(v)
	velos.z = 0
	ang = vm.Angle(velos);
	Hackers = util.JSONToTable(file.Read("hackerlistv2.txt", "DATA"))
	pl = v:EntIndex()
	
	if FaAng[pl][1] >= gInt("HVH", "Resolvers", "FA bullet amount") then

		FaAng[pl][3] = FaAng[pl][3] + 1
		if FaAng[pl][3] >= 5 then
			FaAng[pl][3] = 0
			if FaAng[pl][2] == 0 then
				FaAng[pl][2] = 1
			elseif FaAng[pl][2] == 2 then
				FaAng[pl][2] = 1
			else
				FaAng[pl][2] = 2
			end
		end
		FaAng[pl][1] = 0
		fyawadd = (FaAng[pl][3] > 2) && (FaAng[pl][3] - 2) * -45 || FaAng[pl][3] * 45
		fpitdiff = (FaAng[pl][2] <= 1 && 89) || -89
	end
	fyawadd = (FaAng[pl][3] > 2) && (FaAng[pl][3] - 2) * -45 || FaAng[pl][3] * 45
	fpitdiff = (FaAng[pl][2] <= 1 && 89) || -89
	
	local EyeAng = em.EyeAngles(v)
			EyeAng = Angle(math.NormalizeAngle(EyeAng.p), math.NormalizeAngle(EyeAng.y), math.NormalizeAngle(EyeAng.r))
	if (v ~= me) && (v:SteamID() ~= "STEAM_0:0:35717190") then
		pe = tostring(v:EntIndex())
		
		local plyang
		if plychange[pe] && plychange[pe] then
		if plychange[pe] ~= EyeAng.y then
			plyadd[pe] =  0
			plychange[pe] = 0
		else
			plyadd[pe] = 0
		end
		else
			plyadd[pe] =0
			plychange[pe] = 0
		end
		plyadd[pe] = plyadd[pe] * fake
		if !gBool("HVH", "Resolvers", "Fake-angles resolver") then
			FaAng[pl][1] = 0
			FaAng[pl][2] = 0
			FaAng[pl][3] = 0
		end
		if math.abs(EyeAng.r) > 170 && gBool("HVH", "Resolvers", "Anti-aim resolver") then
			if (EyeAng.p > 0.001) then
				if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
				
				v:SetRenderAngles(Angle(0, EyeAng.y - 120 + plyadd[pe]+ fyawadd , 0))
				
				em.SetPoseParameter(v, "aim_pitch",  49)
				v:InvalidateBoneCache()
			elseif (EyeAng.p < -0.021) then	
					if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
				v:SetRenderAngles(Angle(0, EyeAng.y - 120 + plyadd[pe]+ fyawadd , 0))
				
				em.SetPoseParameter(v, "aim_pitch", -89)
				em.SetPoseParameter(v, "aim_yaw", 0)
				v:InvalidateBoneCache()
			elseif ((EyeAng.p <= 0.001) && (EyeAng.p >= -0.011)) then
				if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
				v:SetRenderAngles(Angle(0, EyeAng.y - 180 + plyadd[pe]+ fyawadd , 0))
				
				em.SetPoseParameter(v, "aim_pitch",89)
				v:InvalidateBoneCache()
			end
			forw =math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)-180)+ fyawadd)))))
			sidew = math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)-90)+ fyawadd)))))
			em.SetPoseParameter(v, "move_x", forw)
			em.SetPoseParameter(v, "move_y", sidew)
		elseif math.abs(EyeAng.p) > 179.9 && gBool("HVH", "Resolvers", "Anti-aim resolver") then
			if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
			v:SetRenderAngles(Angle(0, EyeAng.y + plyadd[pe]+ fyawadd , 0))
			
			em.SetPoseParameter(v, "aim_pitch", 42)
			forw =math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y))+ fyawadd)))))
			sidew = math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)+40)+ fyawadd)))))
			em.SetPoseParameter(v, "move_x", forw)
			em.SetPoseParameter(v, "move_y", sidew)
			v:InvalidateBoneCache()
		elseif (EyeAng.p > 40) && gBool("HVH", "Resolvers", "Anti-aim resolver") then
			if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
			v:SetRenderAngles(Angle(0, EyeAng.y + plyadd[pe]+ fyawadd , 0))
			
			em.SetPoseParameter(v, "aim_pitch", 22)
			forw =math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y))+ fyawadd)))))
			sidew = math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)+30)+ fyawadd)))))
			em.SetPoseParameter(v, "move_x", forw)
			em.SetPoseParameter(v, "move_y", sidew)
			v:InvalidateBoneCache()
		elseif (EyeAng.p < -50) && gBool("HVH", "Resolvers", "Anti-aim resolver") then
			if !isHack then
					HackTbl = {v:GetName(), v:SteamID(), "Invalid Angles p."..EyeAng.p..", r."..EyeAng.r}
					table.insert(Hackers, HackTbl)
					file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
				end
			v:SetRenderAngles(Angle(0, EyeAng.y + plyadd[pe]+ fyawadd , 0))
			
			em.SetPoseParameter(v, "aim_pitch", -59)
			forw =math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y))+ fyawadd)))))
			sidew = math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)+20)+ fyawadd)))))
			
			em.SetPoseParameter(v, "move_x", forw)
			em.SetPoseParameter(v, "move_y", sidew)
			v:InvalidateBoneCache()
		elseif FaAng[pl][1] ~= 0 && gBool("HVH", "Resolvers", "Fake-angles resolver") then
			if !isHack then
				HackTbl = {v:GetName(), v:SteamID(), "Possible Fake-angles"}
				table.insert(Hackers, HackTbl)
				file.Write("hackerlistv3.txt", util.TableToJSON(Hackers))
			end
			v:SetRenderAngles(Angle(0, EyeAng.y + plyadd[pe]+ fyawadd , 0))
			em.SetPoseParameter(v, "aim_pitch", EyeAng.p)
			forw =math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y))+ fyawadd)))))
			sidew = math.cos(math.rad(((math.NormalizeAngle(EyeAng.y)-((math.NormalizeAngle(ang.y)-60)+ fyawadd)))))
			em.SetPoseParameter(v, "move_x", forw)
			em.SetPoseParameter(v, "move_y", sidew)
			v:InvalidateBoneCache()
		else
		--v:SetRenderAngles(Angle(0, EyeAng.y + plyadd[pe] , 0))
		end
		
		plyang = em.EyeAngles(v)
		v:InvalidateBoneCache()
	end
end

hook.Add("RenderScreenspaceEffects", "HackRSE", function()

	for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 0 || !v:Alive() || v:GetObserverMode() > 0  || v == me)  then continue; end
		if(!Filter(v)) then continue; end
		if gBool("Visuals", "ESP", "Enabled") then
		Chams(v);
		end
		local pl = v:EntIndex()
		local teastman = em.GetVelocity(v)
			teastman.z = 0
			teastman = teastman:Angle()
			teastman:Normalize()
				if math.NormalizeAngle(teastman.y) ~=  math.NormalizeAngle(testturn[pl].y) then
		turn[pl] =  math.NormalizeAngle(teastman.y) -  math.NormalizeAngle(testturn[pl].y)
		testturn[pl] =  teastman
		elseif math.NormalizeAngle(teastman.y) ==  math.NormalizeAngle(testturn[pl].y) then
			turn[pl] = turn[pl]
			testturn[pl] = teastman
		else
		end
	end
	if gBool("Misc", "Spam", "Act Spam") then
		RunConsoleCommand("act", gOption("Misc", "Spam", "Act Type"))
	end
end);




local function PredictPos(v, vec)

	local tgtVelo = Vector(0, 0, 0)
	local plyVelo = Vector(0, 0, 0)
	if me:Alive() then
		 plyVelo = (em.GetVelocity(me))
		 if me:GetActiveWeapon():GetClass() == "weapon_crossbow" then
		 plyVelo = em.GetVelocity(me) + (em.GetVelocity(me)*((me:Ping() * (92/78))/1000))
		 end
		 plyVelo = plyVelo * engine.TickInterval()
		if !me:IsOnGround() && me:GetMoveType() ~= MOVETYPE_NOCLIP then
			plyVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow(engine.TickInterval(),2) + em.GetVelocity(me).z * engine.TickInterval())
			if me:GetActiveWeapon():GetClass() == "weapon_crossbow" then
				plyVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow(engine.TickInterval() + (engine.TickInterval() *((me:Ping() * (92/78))/1000)),2) + me:GetVelocity().z * (engine.TickInterval() + (engine.TickInterval() *((me:Ping() * (92/78))/1000))))
			end
		end
	else
		plyVelo = Vector(0, 0, 0)
	end
	

	if v:Alive() && v ~= nil && me:GetActiveWeapon():GetClass() ~= "weapon_crossbow" then
		if !string.find(string.lower(GAMEMODE.Name), "prop") then
			tgtVelo = (em.GetVelocity(v) * engine.TickInterval())
			if !v:IsOnGround() && v:GetMoveType() ~= MOVETYPE_NOCLIP then
				tgtVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow(engine.TickInterval(),2) + em.GetVelocity(v).z * engine.TickInterval())
			end
			pvtr = {
				start = em.GetPos(v)+ Vector(0,0,0.1),
				endpos =  em.GetPos(v)+tgtVelo + Vector(0,0,0.1),
				maxs = em.OBBMaxs(v),
				mins = em.OBBMins(v),
				filter = v
			}
			pvtres = util.TraceHull(pvtr)
			return (((pvtres.HitPos + (Hitbox(v) - em.GetPos(v))) - Vector(0,0,0.1))) - plyVelo
		else
			for _,ent in next, ents.GetAll() do
				if ent:GetClass() == "ph_prop" && (ent:GetOwner() == v || ent:GetParent() == v) && v:Alive() then
					tgtVelo = (em.GetVelocity(ent) * engine.TickInterval())
					if !v:IsOnGround() && v:GetMoveType() ~= MOVETYPE_NOCLIP then
						tgtVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow(engine.TickInterval(),2) + em.GetVelocity(ent).z * engine.TickInterval())
					end
					pvtr = {
						start = em.GetPos(ent)+em.OBBCenter(ent),
						endpos =  em.GetPos(ent)+em.OBBCenter(ent)+ tgtVelo,
						maxs = em.OBBMaxs(v),
						mins = em.OBBMins(v),
						filter = {me, ent, v},
					}
					pvtres = util.TraceHull(pvtr)

					return  (pvtres.HitPos) - plyVelo
				end
			end
		end
			tgtVelo = (em.GetVelocity(v) * engine.TickInterval())
			if !v:IsOnGround() && v:GetMoveType() ~= MOVETYPE_NOCLIP then
				tgtVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow(engine.TickInterval(),2) + em.GetVelocity(v).z * engine.TickInterval())
			end
			pvtr = {
				start = em.GetPos(v),
				endpos =  em.GetPos(v)+tgtVelo + Vector(0,0,0.1),
				maxs = em.OBBMaxs(v),
				mins = em.OBBMins(v),
				filter = v
			}
			pvtres = util.TraceHull(pvtr)

		return (((pvtres.HitPos + (Hitbox(v) - em.GetPos(v))) - Vector(0,0,0.1))) - plyVelo

	elseif v:Alive() && v ~= nil && me:GetActiveWeapon():GetClass() == "weapon_crossbow" then
		trgpos = crossbowcheck(v, false)
		return crossbowcheck(v, true, true, 25 , true, trgpos) + (Hitbox(v) - v:GetPos()) - plyVelo
	end
	
end

hook.Add("PreDrawOpaqueRenderables", "HackPDOR", function()
	for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 0 || !v:Alive() || v:GetObserverMode() > 0  || v == me) then continue; end
		if(!Filter(v)) then continue; end
		DoAAA(v)
	end
end)



local myname = me:GetName()
local randply = player.GetAll()[math.random(#player.GetAll())]

local localname = false
canjump = false
local jumpen = true
local eyeposd = em.EyePos(me)
local baseposd = em.GetPos(me)
local eyediff = eyeposd.z - baseposd.z
local minsd = em.OBBMins(me)
local maxsd = em.OBBMaxs(me) - Vector(0 , 0,em.OBBMaxs(me).z)
local Switchy = true
local Fakie = 0
local wasair = false
local function bhop(ucmd)
	if cm.CommandNumber(ucmd) ~= 0 then
		fakelag()
		if(gBool("HVH", "FakeLag", "Enabled")) then
			if(fakeLagSwitch) then
				Switchy = true
			else
				Switchy = false
				bSendPacket = false
			end
		else
			if(Fakie > 1) then
				Switchy = true
				Fakie = 0;
			else
				Switchy = false
			end
			if (Switchy) then
				
			else
				Fakie = Fakie + 1
				bSendPacket = false
			end
		end
		wep = me:GetActiveWeapon()
		if IsValid(wep) then
			if wep:GetClass() == "weapon_zm_carry" then
				bSendPacket = true
			end
		end
	else
		Switchy = false
	end

	--[[if cm.KeyDown(ucmd, IN_DUCK) then
		ducktr = {
		start = checkfovpos,
		endpos = checkfovpos - Vector(0,0,eyediff) + (me:GetVelocity()*engine.TickInterval()),
		maxs = me:OBBMaxs(),
		mins = me:OBBMins(),
		filter = me
		}
		dtres = util.TraceHull(ducktr)
		if !dtres.Hit && !me:IsOnGround() then
			if Switchy && cm.CommandNumber(ucmd) ~= 0 then
				cm.SetButtons(ucmd, cm.GetButtons(ucmd), IN_DUCK)
			elseif !Switchy && cm.CommandNumber(ucmd) ~= 0 then
				cm.RemoveKey(ucmd, IN_DUCK)
			end
			wasair = true
		elseif dtres.Hit && wasair && cm.CommandNumber(ucmd) ~= 0 then
			cm.RemoveKey(ucmd, IN_DUCK)
			bSendPacket = false
		end

	else
		
		wasair = false
	end]]
	

	randply = player.GetAll()[math.random(#player.GetAll())]
	local scrambledName = string.sub(randply:Nick(), 1, 1)..randply:Nick()
	if gBool("Misc", "BunnyHop", "Enabled") && ucmd:CommandNumber() ~= 0 && cm.KeyDown(ucmd, IN_JUMP) && me:GetObserverMode() == 0 && me:Alive() && !ChatOpen && !PSBox then
		local myVelo = Vector(0, 0, 0)
	
		 myVelo = (em.GetVelocity(me))
		 if me:Alive() && me:GetActiveWeapon()[3] then
		 if me:GetActiveWeapon():GetClass() == "weapon_crossbow" then
		 		myVelo = em.GetVelocity(me) + (em.GetVelocity(me)*((me:Ping() * (92/78))/1000))
			end
		 end
		 myVelo = myVelo * (engine.TickInterval()*5)
		if !me:IsOnGround() && me:GetMoveType() ~= MOVETYPE_NOCLIP then
			myVelo.z  = (0.5 * -GetConVarNumber("sv_gravity") * math.pow((engine.TickInterval()*5),2) + em.GetVelocity(me).z * (engine.TickInterval()*5))
		end
		
		if me:IsOnGround() then
		cm.SetButtons(ucmd, cm.GetButtons(ucmd), IN_JUMP)
		canjump = true
		elseif !me:IsOnGround() && me:WaterLevel() < 2 && me:GetMoveType() ~= MOVETYPE_LADDER then
			cm.RemoveKey(ucmd, IN_JUMP)
			canjump = true
		end
	end
		if gText("Misc", "Name Changer", "Custom Name") ~= "" then
			_fhook_changename("​"..gText("Misc", "Name Changer", "Custom Name"))
			localname = true
		else
			if gBool("Misc", "Name Changer", "Enabled") then
				localname = true
					
				if randply:IsValid() && randply ~= me then
					local nametable = string.Explode( "", randply:GetName() )
					if #nametable > 30 then
						return false
					end
					if (gBool("Misc", "Name Changer", "Ignore Friends")) && (randply:GetFriendStatus() == "friend" || table.HasValue(Friends, randply)) then
						return false
					end
					if (gBool("Misc", "Name Changer", "Ignore Admins") && table.HasValue(Admin, randply)) then
						return false
					end
					if (gBool("Misc", "Name Changer", "Team Only") && me:Team() ~= randply:Team()) then
						return false
					end
					if randply:GetName() == "unconnected" then
					return false
					end
						table.insert(nametable, math.random(1, #nametable), "​" )
					namefin = string.Implode("", nametable)
					local noname = string.Replace( me:GetName(), "​", "" )
					if string.find(string.lower(GAMEMODE.Name), "darkrp") then
					RunConsoleCommand("say", "/name "..scrambledName.."​")
					end
					if ucmd:CommandNumber() ~= 0 then
						if string.find(string.lower(GAMEMODE.Name), "terror")  then
							if GetConVarNumber("ttt_namechange_kick") ~= 0 then
								if GetRoundState() == 3 then
									_fhook_changename(me:GetName())
								elseif noname ~= randply:GetName() then
									_fhook_changename(namefin)
								end
							else
								_fhook_changename(namefin)
							end
						else
							if noname ~= randply:GetName() then
								_fhook_changename(namefin)
							else
								_fhook_changename(me:GetName())
							end
						end
					end
				else
					_fhook_changename(me:GetName())
				end
			else
				if localname == true then
				_fhook_changename(myname)
				localname = false
				end
				myname = me:GetName()
			end
		end
	local test = "KEY_"..string.upper(input.LookupBinding("voicerecord"))
	local gotit
	for i=0, #buttons, 1 do
		if buttons[i][2] == test then
			gotit = buttons[i][1]
		end
	end
	gotit2 = 0
	for i = 107, 113 do
		if input.LookupKeyBinding(i) == "+voicerecord" then
			gotit2 = i
		end
	end
	if (gotit && ((input.IsKeyDown(gotit)) || input.IsMouseDown(gotit2)) && !ChatOpen && !PSBox ) || gBool("Misc", "Spam", "Voice Spam") then
		if voicechat > 3 then
			voicechat = 0
			RunConsoleCommand("+voicerecord")
		else	
			voicechat = voicechat + 1
			RunConsoleCommand("-voicerecord")
		end
		
	else
		RunConsoleCommand("-voicerecord")
		
	end
	if gBool("Visuals", "Misc", "No Sky") && !screengrab then
		GetConVar("r_3dsky"):SetValue(0)
		GetConVar("r_drawskybox"):SetValue(0)
		GetConVar("gl_clear"):SetValue(1)
	else
		GetConVar("r_3dsky"):SetValue(1)
		GetConVar("r_drawskybox"):SetValue(1)
		GetConVar("gl_clear"):SetValue(1)
	end
	if (gBool("Visuals", "Misc", "Fullbright") || fullbrightstart) && !screengrab then
	GetConVar("mat_fullbright"):SetValue(1)
	fullbrightstart = false
	else
	GetConVar("mat_fullbright"):SetValue(0)
	end




end

propmin, propmax = Vector( -5, -5, -5 ), Vector(5,5,5)

local function aimer(ucmd)
	local wep = me:GetActiveWeapon()
	gettarget();
	if ChatOpen || PSBox then
		return false
	end
	if IsValid(wep) && cm.CommandNumber(ucmd) ~= 0 then
		if wep:Clip1() == 0 && me:GetActiveWeapon():GetMaxClip1() > 0 && wepswitch == 0 then
			cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 8192 ) );
			wepswitch = 1
		elseif wepswitch == 1 then
			cm.RemoveKey(ucmd, IN_RELOAD)
			wepswitch = 2
		elseif wep:Clip1() > 0 then
			wepswitch = 0
		end
	end
	if IsValid(wep) && wep:GetClass() == "weapon_zm_carry" then
			if input.IsMouseDown(MOUSE_RIGHT) &&  cm.CommandNumber(ucmd) ~= 0  then
			magtr = {
				start = me:EyePos(),
				endpos = me:EyePos() + (am.Forward(fa)*200),
				mask = MASK_SOLID,
				filter = me,
			};
			magres = util.TraceLine(magtr)
			if IsValid(magres.Entity) then
				if (string.find(magres.Entity:GetClass(), "prop")||string.find(magres.Entity:GetClass(), "phys")) && magres.Entity && magres.Entity:GetOwner() == me then
					propmin, propmax =magres.Entity:OBBMins(), magres.Entity:OBBMaxs()
				end
			end
			end
		return
	end
	if( !wep:IsValid() || !gBool("Aimbot", "Aimbot", "Enabled") || !me:Alive()) then return; end
	aa = false;
	toggle = false
	if aimtarget && aimtarget:Alive() && CanFov(fa, me:GetShootPos(), Hitbox(aimtarget)) && (gKey("Aimbot", "Aimbot", "Key Toggle") || gBool("Aimbot", "Aimbot", "Autosnap")) && me:GetObserverMode() == 0 && ChatOpen == false && me ~= nil then
		local pos = PredictPos(aimtarget,  (Hitbox(aimtarget))) - em.EyePos(me)
		local ang = vm.Angle(PredictSpread(ucmd, vm.Angle(pos)));
		if gBool("Aimbot", "Aimbot", "Untrusted Angles") then
			ang = Angle(180 - ang.p, ang.y+180, 0)
		end
		if (gBool("Aimbot", "Aimbot", "pSilent")) then
		if (Switchy) then
		aa = false
			if (gBool("Aimbot", "Aimbot", "pSilent") && WeaponCanFire() && (cm.CommandNumber(ucmd) ~= 0)) then
			
			cm.SetViewAngles(ucmd, ang);
		
			aa = false;
			if(gBool("Aimbot", "Aimbot", "Autofire")) then
				Autofire(ucmd);
			end
			end
		end
		else
			if (cm.CommandNumber(ucmd) ~= 0) then
				cm.SetViewAngles(ucmd, ang);
				if !gBool("Aimbot", "Aimbot", "Silent") then
					fa = vm.Angle(pos)
				end
				if(gBool("Aimbot", "Aimbot", "Autofire")) then
				Autofire(ucmd);
			end
			end
			aa = false;
		end
		if (gBool("Aimbot", "Aimbot", "Silent")) || gBool("Aimbot", "Aimbot", "pSilent") then
		else
			if (cm.CommandNumber(ucmd) ~= 0) then
			fa = vm.Angle(pos)
			end
			if(gBool("Aimbot", "Aimbot", "Autofire")) then
				Autofire(ucmd);
			end
		end
	end
end



local function walldetect()
	
	local memeMePlease = {};
	local EyePos = em.EyePos(me);
	for i = 0, 360, 3 do
		local trace = {
			start = EyePos,
			endpos = EyePos + am.Forward(Angle(0, i, 0)) * 20;
			mask = MASK_SHOT,
			filter = function(ent) return(!ent:IsPlayer()) end
		};

		local frac = util.TraceLine(trace).Fraction;

		if(!memeMePlease.y) then
			memeMePlease.f = frac;
			memeMePlease.y = i;
			continue;
		end

		if( memeMePlease.f > frac ) then
			memeMePlease.f = frac;
			memeMePlease.y = i;
		end
	end

	if(memeMePlease.f == 1) then return; end
	ofx = 89
	ofy = math.NormalizeAngle(memeMePlease.y)
	
	--[[local eye = em.EyePos(me);
	local tr = util.TraceLine({
		start = eye,
		endpos = (eye + (am.Forward(fa) * 10)),
		mask = MASK_VISIBLE,
		filter = me,
	});
	if(tr.Hit) then
		ox = -181;
		oy = -90;
	end]]
end
local switchF
propturn = 0
propthrow = false
proppitch = 1
propswitch = true
propswitch2 = 0
local function antiaimer(ucmd)
	local eye = em.EyePos(me);
	wep = me:GetActiveWeapon()
	local trace = ({
		start = eye,
		endpos = (eye + (am.Forward(fa) * 70)),
		mask = MASK_SHOT,
		filter = me,
	});
	local tr = util.TraceLine(trace)
	if IsValid(wep) then
		if (me:GetActiveWeapon():GetPrimaryAmmoType() < 0 && wm.GetNextPrimaryFire(wep) > servertime) then
			return
		elseif  wep:GetClass() == "weapon_zm_carry" then
			if (cm.CommandNumber(ucmd) ~= 0 ) then
				if gKey("Aimbot", "Aimbot", "Key Toggle") && !propswitch && propturn == 0 && propswitch2 == 0 then
					magtr = {
				start = me:EyePos(),
				endpos = me:EyePos() + (am.Forward(fa)*200),
				mask = MASK_SOLID,
				filter = me,
			};
			magres = util.TraceLine(magtr)
			if IsValid(magres.Entity) then
				if (string.find(magres.Entity:GetClass(), "prop")||string.find(magres.Entity:GetClass(), "phys")) && magres.Entity && magres.Entity:GetOwner() == me then
					propmin, propmax =magres.Entity:OBBMins(), magres.Entity:OBBMaxs()
				end
			end
			propthrow = true
			propswitch = true
		elseif gKey("Aimbot", "Aimbot", "Key Toggle") && !propswitch && propturn == 135 then
			propmin, propmax = Vector( -5, -5, -5 ), Vector(5,5,5)
			propthrow = false
			propturn = 45
			proppitch = 1
			propswitch = true
			propswitch2 = propswitch2 +1
		elseif  !gKey("Aimbot", "Aimbot", "Key Toggle") && propswitch then
			propswitch = false

		end
		if propswitch2 >= 1 && propswitch2 <= 15 then
			propswitch2  = propswitch2 +1
		elseif propswitch2 >= 15 then
			propswitch2 = 0
			propturn = 0
		end
		if propthrow && propturn ~= 135 then
			propturn = math.Clamp(propturn + 10, 0, 135)
			proppitch = math.Clamp(proppitch - 0.1, -0.5, 1)
		end
		bSendPacket = true

			--[[
			pitchtest = math.rad(fa.p)
					pitchtest2 = math.rad(fa.p)
					math.NormalizeAngle(pitchtest)
					math.NormalizeAngle(pitchtest2)
					newpPitch2 = math.abs(math.cos(pitchtest) * (propturn/135))
					newpYaw = math.cos(pitchtest2)
						]]

			--cm.SetViewAngles(ucmd, Angle((fa.p/2) * -newpPitch2, fa.y + propturn - (45 * (1-newpPitch2)), 0))
		

			cm.SetViewAngles(ucmd, Angle(fa.p * proppitch, fa.y + propturn, 0))
		elseif gBool("Misc", "Thirdperson", "Enabled") then
			cm.SetViewAngles(ucmd, Angle(fa.p * proppitch, fa.y + propturn, 0))
		end
			return
		elseif wep:GetClass() ~= "weapon_zm_carry" then
			propthrow = false
			propturn = 0
			proppitch = 1
		end
	end
	if( cm.KeyDown(ucmd, 1) || me:GetObserverMode() > 0 || input.WasKeyPressed(KEY_T) || cm.KeyDown(ucmd, 32) || !me:Alive() || me:WaterLevel() >= 2 || me:GetMoveType() == MOVETYPE_LADDER || me:GetMoveType() == MOVETYPE_NOCLIP || aa || !gBool("HVH", "Anti-Aim", "Enabled")) then 
	else
	
	
	if tr.Entity:IsValid() then
		if tr.Entity:GetClass() == "prop_ragdoll" then
			return
		end
	end
	--walldetect();
		if (cm.CommandNumber(ucmd) ~= 0 ) then
			GetX();
			GetY();
			GetFX();
			GetFY();
			if(gBool("HVH", "FakeAngles", "Enabled")) then
				if (Switchy) then
					cm.SetViewAngles(ucmd, Angle(ox, oy, 0));
				else
					cm.SetViewAngles(ucmd, Angle(ofx, ofy, 0))
				end
			else
				cm.SetViewAngles(ucmd, Angle(ox, oy, 0));
			end
		elseif gBool("Misc", "Thirdperson", "Enabled") && !screengrab then
			if(gBool("HVH", "FakeAngles", "Enabled")) then
				cm.SetViewAngles(ucmd, Angle(ofx, ofy, 0))
			else
				cm.SetViewAngles(ucmd, Angle(ox, oy, 0))
			end
		end
	end
end

plysp = nil
hook.Add( "OnPlayerChat", "HackOPC", function( ply, strText )
	for _, v in next, player.GetAll() do
			if ply == me then
			v:SetNoDraw( false )
			end
		if v ~= me then
			if ( strText == "!s " .. v:GetName() ) && ply == me then
				if v:Alive() then
				plysp = v
				v:SetNoDraw( true )
				chat.AddText(color_white, "spectating "..v:GetName()..".")
				else
					chat.AddText(color_white, v:GetName().." is dead.")
				end
			elseif ( strText == "!us")  && ply == me || (plysp &&!plysp:Alive()) then
				if plysp then
				plysp:SetNoDraw( false )
				end
				plysp = nil
			elseif ( strText == "!g ^" ) && !v:IsMuted() && ply == me then
				v:SetMuted(true)
			elseif ( strText == "!ug ^" ) && v:IsMuted() && ply == me then
				v:SetMuted(true)
			elseif ( strText == "!m ^" ) && !table.HasValue(gonemute, v) && ply == me then
				table.insert(gonemute, v)
			elseif ( strText == "!um ^" ) && table.HasValue(gonemute, v) && ply == me then
				table.RemoveByValue(gonemute, v)
			elseif ( strText == "!m " .. v:GetName() ) && !v:IsMuted() && ply == me then -- if the player typed /hello then
				chat.AddText(Color(255,255,255), v:GetName(), " muted.")
				v:SetMuted(true)
				return true
			elseif ( strText == "!um " .. v:GetName() ) && v:IsMuted() && ply == me then -- if the player typed /hello then
				chat.AddText(Color(255,255,255), v:GetName(), " unmuted.")
				v:SetMuted(false)
				return true
			elseif ( strText == "!gp " .. v:GetName() )  && ply == me then -- if the player typed /hello then
				chat.AddText(Color(255,255,255), v:GetName(), "'s profile opened.")
				v:ShowProfile()
				return true
			end
			if table.HasValue(gonemute, v) && ply == v then
				return true
			end
		end
	end
	if ( strText == "!m ^" ) && ply == me then -- if the player typed /hello then
		chat.AddText(Color(255,255,255), "All muted.")
		return true
	elseif ( strText == "!um ^" ) && ply == me then -- if the player typed /hello then
		chat.AddText(Color(255,255,255), "All unmuted.")
		return true
	elseif ( strText == "!g ^" ) && ply == me then
		chat.AddText(Color(255,255,255), "All gagged.")
		return true
	elseif ( strText == "!ug ^" ) && ply == me then
		chat.AddText(Color(255,255,255), "All ungagged.")
		return true
	end
	if gBool("Misc", "Sounds", "TextToSpeech") then
		MEGA.TextToSpeech(strText)
	end
end )

function check_Super(ply)
	if (ply:IsSuperAdmin()) then
		return true
	end
	return false
end

function check_Admin(ply)
	if (ply:IsAdmin() && !ply:IsSuperAdmin()) then
		return true
	end
	return false
end
local Mods = {"moderator", "mod", "donormod", "donormoderator", "donatormod", "trialadmin", "trial-admin", "trialmod", "trial-mod", "operator", "donoradmin"}
function check_Mod(ply)
	if table.HasValue(Mods, string.lower(ply:GetUserGroup())) || string.find( string.lower(ply:GetUserGroup()), "mod" ) || string.find( string.lower(ply:GetUserGroup()), "admin" ) then
		return true
	end
	return false
end

function check_User(ply)
	if (ply:IsUserGroup("user")
	||	ply:IsUserGroup("guest")) then
		return true
	end
	return false
end

function check_Other(ply)
	if (ply:IsUserGroup("donator")
	||	ply:IsUserGroup("donor")
	||	ply:IsUserGroup("vip")
	||	ply:IsUserGroup("vip+")
	||	ply:IsUserGroup("donor+")
	||	ply:IsUserGroup("donator+")
	||	ply:IsUserGroup("member")
	||	ply:IsUserGroup("respected")
	||	ply:IsUserGroup("premiumvip")
	||	ply:IsUserGroup("standardvip")
	||	ply:IsUserGroup("trusted")) then
		return true
	else
		return false
	end
end

function PrecacheCircle(x, y, radius)
	local circle = {}
	local inner = {}
	local outer = {}
	
	local r = radius - 1
	
	for i = 0, 360, 5 do
		local rad = math.rad(i)
		local ox, oy = x + (math.cos(rad) * r), y + (-math.sin(rad) * r)
		
		inner[#inner + 1] = {x = ox, y = oy}
	end
	
	for i = 0, 360, 5 do
		local rad = math.rad(i)
		local ox, oy = x + (math.cos(rad) * radius), y + (-math.sin(rad) * radius)
		
		outer[#outer + 1] = {x = ox, y = oy}
	end
	
	for i = 1, #inner * 2 do
		local v1, v2, v3
		v1 = outer[math.floor(i / 2) + 1]
		v3 = inner[math.floor((i + 1) / 2) + 1]
		
		if (i % 2 == 0) then
			v2 = outer[math.floor((i + 1) / 2)]
		else
			v2 = inner[math.floor((i + 1) / 2)]
		end
		
		circle[#circle + 1] = {v1, v2, v3}
	end
	
	return circle
end

function GetCircle(cir)
	for k, v in ipairs(cir) do
		surface.DrawPoly(v)
	end
end

function DrawCircle(x, y, radius, col)
	draw.NoTexture()
	surface.SetDrawColor(col)
	GetCircle(PrecacheCircle(x, y, radius))
end

function draw.Circle( x, y, radius, seg )
	local cir = {}

	table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
	for i = 0, seg do
		local a = math.rad( ( i / seg ) * -360 )
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
	end

	local a = math.rad( 0 ) -- This is need for non absolute segment counts
	table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

	surface.DrawPoly( cir )
end

gameevent.Listen( "player_disconnect" )
hook.Add( "player_disconnect", "HackPD", function( data )
	kidspammed = {}
	table.insert(custtest,1,{data.name .. " ("..data.networkid..") left the server. ("..data.reason..")", Color(255,255,255), 12/engine.TickInterval()})
	MsgC(data.name .. " ("..data.networkid..") left the server. ("..data.reason..")\n")
	--chat.AddText(Color(166, 206, 242), "Player ", Color(255,255,255), data.name, Color(166, 206, 242), " (", Color(255,123,0), data.networkid, Color(166, 206, 242), ") left the server. (", Color(255,123,0), data.reason, Color(166, 206, 242), ")")
	if gBool("Misc", "Spam", "Disconnect Say") then
		if spammylist[1] then
			
			for i=1, #spammylist, 1 do
				if spammylist[i][2] == "Disconnect Say" && spammylist[i][3] == "Enabled" then
					table.insert(kidspammed, tostring(spammylist[i][1]))
				end
			end
			if kidspammed[1] then
				disspam = kidspammed[math.random( #kidspammed )]
				disspam = string.Replace(disspam, "_ply_", data.name)
				disspam = string.Replace(disspam, "_me_", me:GetName())	
				RunConsoleCommand("say", disspam)
			end
		end
	end
end)

gameevent.Listen( "player_connect" )
hook.Add( "player_connect", "HackPC", function( data )
	if table.HasValue(Hackers, data.networkid) then
		table.insert(custtest,1,{data.name .. " ("..data.networkid..") joined.", Color(255,255,0), 12/engine.TickInterval()})
		MsgC(data.name .. " ("..data.networkid..") joined.\n")
		surface.PlaySound("vo/npc/male01/ohno.wav")
	else
		table.insert(custtest,1,{data.name .. " ("..data.networkid..") joined.", color_white, 12/engine.TickInterval()})
		MsgC(data.name .. " ("..data.networkid..") joined.\n")
		--chat.AddText(Color(166, 206, 242), "Player ", Color(255,255,255), data.name, Color(166, 206, 242), " (", Color(255,123,0), data.networkid, Color(166, 206, 242), ") joined the server.")
	end
end)

gameevent.Listen( "player_hurt" )
hook.Add( "player_hurt", "HackPH", function( data )
	local health = data.health				// Remaining health after injury
	local victim				// Same as Player:UserID()
	local attacker 
	for _, ply in next, player.GetAll() do
		if data.attacker then
			if data.attacker == ply:UserID() && ply:Alive() then
				attacker = ply
			end
		end
		if data.userid then
			if data.userid == ply:UserID() && ply:Alive() then
				victim = ply
				pl = ply:EntIndex()
			end
		end
	end
	if IsValid(attacker) && attacker:IsPlayer() then
		plI = attacker:EntIndex()
		if checkturn2[plI].p > 45 || checkturn2[plI].y > 45 then
			table.insert(Hackers, attacker:SteamID())
			file.Write("hackerlistv2.txt", util.TableToJSON(Hackers))
		end
	end
	if attacker && victim && attacker == me && me:Alive() then
	FaAng[pl][1] = 0
	end
	if attacker && victim then

		if attacker:IsPlayer() && attacker:Alive() && victim:Alive() && victim == me then
			if table.HasValue(Tdectt, attacker) then
				table.RemoveByValue( Tdectt, attacker )
				table.insert(custtest,1,{"Detective "..attacker:GetName().. " attacked you.", Color(255,255,0), 12/engine.TickInterval()})
				MsgC("Detective "..attacker:GetName().. " attacked you.\n")
			end
		end
	end
end )
mystreak = 0
gameevent.Listen( "entity_killed" )
hook.Add( "entity_killed", "HackEK", function( data )
	local inflictor = Entity(data.entindex_inflictor)		// Same as Weapon:EntIndex() / weapon used to kill victim
	local attacker = Entity(data.entindex_attacker)		// Same as Player/Entity:EntIndex() / person or entity who did the damage
	local damagebits = data.damagebits			// DAMAGE_TYPE - use BIT operations to decipher damage types...
	local victim = Entity(data.entindex_killed)		// Same as Victim:EntIndex() / the entity / player victim
	if attacker == me && victim:IsPlayer() then
		pl = victim:EntIndex()
		FaAng[pl][1] = 0
	end
	if  attacker && attacker:IsPlayer() && attacker:Alive() then
		if (IsValid(attacker:GetActiveWeapon())) && IsValid(attacker:GetActiveWeapon()) && attacker ~= victim then
			weapname = attacker:GetActiveWeapon():GetPrintName()
			weapname = string.Replace(weapname, "_name", "")
		end
	else
		weapname = "something"
	end
	if gBool("Misc", "Spam", "pAsshole") then
		if attacker ~= nil && victim ~= nil && inflictor ~= nil && attacker:IsPlayer() && victim:IsPlayer() then
			
			if	(attacker:GetFriendStatus() ~= "friend" && victim:GetFriendStatus() ~= "friend" && attacker ~= me  && victim ~= me) then
				if attacker ~= victim then
					RunConsoleCommand("say", attacker:GetName() .." killed "..victim:GetName().." using "..weapname..".")
				else
					RunConsoleCommand("say", attacker:GetName() .." killed themself.")
				end
			end
		end
	end
	if gBool("Misc", "Notifications", "Player Killed Alert") && inflictor && attacker:IsPlayer() && victim:IsPlayer() then
	if attacker ~= victim then
		table.insert(custtest,1,{attacker:GetName().." killed "..victim:GetName().." using "..weapname..".", Color(255,255,255), 12/engine.TickInterval()})
		MsgC(attacker:GetName().." killed "..victim:GetName().." using "..weapname..".\n")

		--[[if attacker:IsPlayer() && !attacker:IsBot()  then
			chat.AddText(menuscol, "[LucidCheats] ", Color(255,255,255), "Player ", Color(255, 153, 0), attacker:GetName(), Color(255,255,255), " killed ", Color(255, 153, 0), victim:GetName(), Color(255,255,255), " using ",  weapname, Color(255,255,255), "!")
		elseif attacker:IsBot() then
			chat.AddText(menuscol, "[LucidCheats] ", Color(255,255,255), "Bot ", Color(255, 153, 0), attacker:GetName(), Color(255,255,255), " killed ", Color(255, 153, 0), victim:GetName(), Color(255,255,255), " using ", weapname, Color(255,255,255), "!")
		end]]
	else
		table.insert(custtest,1,{attacker:GetName().." killed themself.", Color(255,255,255), 12/engine.TickInterval()})
		MsgC(attacker:GetName().." killed "..victim:GetName().." using "..weapname..".\n")
		--[[if attacker:IsPlayer() && !attacker:IsBot()  then
			chat.AddText(menuscol, "[LucidCheats] ", Color(255,255,255), "Player ", Color(255, 153, 0), attacker:GetName(), Color(255,255,255), " killed themself.")
		elseif attacker:IsBot() then
			chat.AddText(menuscol, "[LucidCheats] ", Color(255,255,255), "Bot ", Color(255, 153, 0), attacker:GetName(), Color(255,255,255), " killed themself.")
		end]]
	end
	end
	kilsay = {}
	
		if spammylist[1] then
			
			for i=1, #spammylist, 1 do
				if spammylist[i][2] == "Kill Say" && spammylist[i][3] == "Enabled" then
					table.insert(kilsay, tostring(spammylist[i][1]))
				end
			end
			if kilsay[1] then
				
				if attacker == me && victim ~= me then
				mystreak = mystreak+1
				kilsay = kilsay[math.random(#kilsay)]
				kilsay = string.Replace(kilsay, "_ply_", victim:GetName())
				kilsay = string.Replace(kilsay, "_weap_", weapname)
				kilsay = string.Replace(kilsay, "_me_", me:GetName())
				kilsay = string.Replace(kilsay, "_streak_", mystreak)
				if string.find(kilsay, "#HL2_") then
					kilsay = string.Replace(kilsay, "#HL2_", "")
					kilsay = string.Replace(kilsay, "_", " ")
				end
				if victim:GetFriendStatus() ~= "friend" && gBool("Misc", "Spam", "Kill Say") then
				RunConsoleCommand("say", kilsay)
				end
				elseif victim && victim == me then
					mystreak = 0
				end
			end
		end

end )
saytimetick = 0
local function meme(ucmd)
	chatspm = {}
	cmdspm= {}
	if string.find(string.lower(GAMEMODE.Name), "terror") then
		if GetRoundState() < 3 then
			tttgod = true
		elseif GetRoundState() == 3 || GetRoundState() == 4 && GetConVarNumber("ttt_postround_dm") == 1 then
			tttgod = false
		else
			tttgod = true
		end
	end
	if ucmd:CommandNumber() ~= 0 then
	if gBool("Misc", "Spam", "Chat Spam") then
		if spammylist[1] then
			
			for i=1, #spammylist, 1 do
				if spammylist[i][2] == "Chat Spam" && spammylist[i][3] == "Enabled" then
					table.insert(chatspm, tostring(spammylist[i][1]))
				end
			end

			if chatspm[1] then
				
				randplyname = player.GetAll()[math.random(#player.GetAll())]
				chatspm = chatspm[math.random(#chatspm)]
				chatspm = string.Replace(chatspm, "_ply_", randplyname:GetName())
				chatspm = string.Replace(chatspm, "_me_", me:GetName())
				if randplyname ~= me && randplyname:GetFriendStatus() ~= "friend" then
				saytimetick = saytimetick + 1
					if saytimetick >= 24 then
						RunConsoleCommand("say", chatspm)
					end
				end
			end
		end
	end
	if gBool("Misc", "Spam", "Command Spam") then
		if spammylist[1] then
			
			for i=1, #spammylist, 1 do
				if spammylist[i][2] == "Command Spam" && spammylist[i][3] == "Enabled" then
					table.insert(cmdspm, tostring(spammylist[i][1]))
				end
			end
			if cmdspm[1] then
				
				randplyname = player.GetAll()[math.random(#player.GetAll())]
				cmdspm = cmdspm[math.random(#cmdspm)]
				cmdspm = string.Replace(cmdspm, "_ply_", randplyname:GetName())
				chatspm = string.Replace(cmdspm, "_me_", me:GetName())
				if randplyname ~= me && randplyname:GetFriendStatus() ~= "friend" then
				me:ConCommand(cmdspm)
				end
			end
		end
	end
	end
	if(!fa) then fa = cm.GetViewAngles(ucmd); end
	local wep = me:GetActiveWeapon()
	if IsValid(wep) then
		if (wep:GetClass() == "weapon_physgun") && pm.KeyDown(me, IN_USE) && pm.KeyDown(me, IN_ATTACK) || aimtarget && (gKey("Aimbot", "Aimbot", "Key Toggle") ||gBool("Aimbot", "Aimbot", "Autosnap")) && !gBool("Aimbot", "Aimbot", "pSilent") && !gBool("Aimbot", "Aimbot", "Silent") then
			fa = fa
		else
			fa = fa + Angle(cm.GetMouseY(ucmd) * GetConVarNumber("m_pitch"), cm.GetMouseX(ucmd) * -GetConVarNumber("m_yaw"), 0);
		end
	else
		fa = fa + Angle(cm.GetMouseY(ucmd) * GetConVarNumber("m_pitch"), cm.GetMouseX(ucmd) * -GetConVarNumber("m_yaw"), 0);
	end
	if !me:Alive() || me:GetObserverMode() > 0 then
	 fa = cm.GetViewAngles(ucmd)
	end
	NormalizeAngle(fa);
	if (gBool("Aimbot", "Aimbot", "pSilent") && !WeaponCanFire()) then
		
		cm.RemoveKey(ucmd, IN_ATTACK)
	end
	local ang = vm.Angle(PredictSpread(ucmd, fa ));
	cm.SetViewAngles(ucmd, GetAngle(fa))
	if gBool("Aimbot", "Aimbot", "pSilent") then
	if (Switchy) then
		local wep = me:GetActiveWeapon();
		if wep && wep:IsValid()&& wep:Clip1() > 0 then
		cm.RemoveKey(ucmd, IN_ATTACK)
		end
	else
		local wep = me:GetActiveWeapon();
		if (gBool("Aimbot", "Aimbot", "pSilent") && !WeaponCanFire()) then
			cm.RemoveKey(ucmd, IN_ATTACK)
		end
		if(wep && wep:IsValid() && cm.KeyDown(ucmd, IN_ATTACK)&& WeaponCanFire() && wep:Clip1() > 0) then
		if(gBool("Aimbot", "Aimbot", "Auto Pistol"))&& WeaponCanFire() then
				Autofire(ucmd);
		end	
			cm.SetViewAngles(ucmd, ang);
		elseif wep && wep:IsValid() && wep:Clip1() > 0 then
			cm.SetViewAngles(ucmd, GetAngle(fa))
			cm.RemoveKey(ucmd, IN_ATTACK)
		else
			cm.SetViewAngles(ucmd, GetAngle(fa))
		end
	end
	else
		local wep = me:GetActiveWeapon();
		if(wep && wep:IsValid() && cm.KeyDown(ucmd, IN_ATTACK)&& WeaponCanFire() && wep:Clip1() > 0) then
		if(gBool("Aimbot", "Aimbot", "Auto Pistol")) then
				Autofire(ucmd);
		end
			cm.SetViewAngles(ucmd, ang);
		elseif wep && wep:IsValid() && wep:Clip1() > 0 then
			cm.SetViewAngles(ucmd, GetAngle(fa))
			cm.RemoveKey(ucmd, IN_ATTACK)
		else
			cm.SetViewAngles(ucmd, GetAngle(fa))
		end
	end
end

local function ESP(v)


	local x1, y1, x2, y2 = Coords(v)
	local namedis = -4
	local modcolor = em.GetColor(v)
	if string.find(string.lower(GAMEMODE.Name), "prop") then
		modcolor = Color(255,255,255)
	end
	vI = v:EntIndex()
	if(gBool("Aimbot", "Target", "Ignore Spawn Protection")) then
		modcolor = Color(255,255,255)
		if tttgod then
			modcolor.r = 100
		end
	end
	if (x2 > x1) then 
		diff = x2 - x1 
	else 
		diff = x1 - x2 
	end
	if (y2 > y1) then
		diff2 = y2 - y1 
	else 
		diff2 = y1 - y2 
	end
	

	if  x1 < ScrW() && y1 < ScrH() && ((x1 + diff + 75) > 0) && (y1 + diff2 +25 > 0) then
	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		
		surface.SetDrawColor(team.GetColor(v:Team()));
		surface.DrawOutlinedRect(x1, y1, diff, diff2)
		surface.SetDrawColor(0,0,0);
		surface.DrawOutlinedRect(x1+1, y1+1, diff-2, diff2-2)
		surface.DrawOutlinedRect(x1-1, y1-1, diff+2, diff2+2)
	elseif (gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "3D Box") then
			cam.Start3D()
					if v == aimtarget && pm.KeyDown(me, IN_ALT2) then
					render.DrawWireframeBox( v:GetPos(), Angle(0, 0, 0), v:OBBMins(), v:OBBMaxs(), Color(255,255,255), false)
					else
					render.DrawWireframeBox( v:GetPos(), Angle(0, 0, 0), v:OBBMins(), v:OBBMaxs(), team.GetColor(v:Team()), false)
					end
			cam.End3D()
	end
		
	surface.SetFont("BudgetLabel");
	
	surface.SetTextColor(255, 255, 255);
	if(gBool("Visuals", "ESP", "Name")) then
		if table.HasValue(Traitors, v) then
		if (v:GetFriendStatus() == "friend") then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 255, 100, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Friends, v) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 100, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Tdectt, v) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 0, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Hackers, v:SteamID()) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 255, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		else
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		end
		else
		if (v:GetFriendStatus() == "friend") then	
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 0, 100, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Friends, v) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 0, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Tdectt, v) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 0, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		elseif table.HasValue(Hackers, v:SteamID()) then
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 255, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		else
			draw.SimpleText( pm.Name(v), "BudgetLabel", x1 + diff, y1-4, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		end
		end
		namedis = namedis + 10
		--[[if bunny2[vI] then
			draw.SimpleText( bunny2[vI].." "..bunny[vI], "BudgetLabel", x1 + diff, y1+namedis, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
			namedis = namedis + 10
		end]]
		if string.find(string.lower(GAMEMODE.Name), "murder") then
			bycol = v:GetPlayerColor() * 255
			draw.SimpleText( v:GetBystanderName(), "BudgetLabel", x1 + diff, y1+namedis, bycol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
			namedis = namedis + 10
		end
	end
	
	
	if(gBool("Visuals", "ESP", "UserGroup")) then
		draw.SimpleText( "[" .. v:GetUserGroup() .. "]", "BudgetLabel", x1 + diff -1, y1+namedis, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		namedis = namedis + 10
	end
	
	if(gBool("Visuals", "ESP", "Weapon")) then
		
		local we = pm.GetActiveWeapon(v);
		if(em.IsValid(we)) then
			draw.SimpleText( pm.GetActiveWeapon(v):GetPrintName(), "BudgetLabel", x1 + diff, y1+namedis, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
			namedis = namedis + 10
		end
		
	end
	if(gBool("Visuals", "ESP", "Health")) then
		surface.SetDrawColor(0, 0, 0, 255);
	
		red = (math.Clamp(((100-em.Health(v))*2),0,100)/100)*255
		green = (math.Clamp((em.Health(v)*2),0,100)/100)*255
		hpcol = Color(red,green,0,255)
		arcol = Color(0,200,200)
		surface.SetDrawColor(hpcol);
		if (v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || (gBool("Aimbot", "Target", "Ignore Team") && v:Team() == me:Team()) ||gBool("Aimbot", "Target", "Ignore Bots") && pm.IsBot(v) || gBool("Aimbot", "Target", "Ignore Friends") && (v:GetFriendStatus() == "friend" || table.HasValue(Friends, v)) ||  v.ULXHasGod || (modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255 ) then		
		surface.SetDrawColor(Color(100, 100, 100));
		hpcol = Color(100, 100, 100)
		arcol = Color(100,100,100)
		end
		if (gOption("Visuals", "ESP", "Health Type") == "HP Bar") then
		surface.DrawLine(x1 -4, y2-1, x1 -4, y2 - (diff2 *  (math.Clamp(em.Health(v), 0, 100)/100)) -1);
		surface.SetDrawColor(0, 0, 0, 255);
		surface.DrawOutlinedRect(x1 -5, y1 - 1, 3, diff2 + 2)
		if v:Armor() > 0 then
		surface.SetDrawColor(arcol)
		surface.DrawLine(x1 -8, y2-1, x1 -8, y2 - (diff2 *  (math.Clamp(v:Armor(), 0, 255)/255)) -1);
		surface.SetDrawColor(0, 0, 0, 255);
		surface.DrawOutlinedRect(x1 -9, y1 - 1, 3, diff2 + 2)
		end
		elseif (gOption("Visuals", "ESP", "Health Type") == "Percentage") then
			draw.SimpleText( em.Health(v), "BudgetLabel", x1 + diff, y1+namedis, hpcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
			 hpw, hph = surface.GetTextSize(em.Health(v))
			if v:Armor() > 0 then
			draw.SimpleText( "/"..v:Armor(), "BudgetLabel", x1 + diff+ hpw, y1+namedis, arcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
			end
		end
	end
	
	if(gBool("Visuals", "ESP", "Skeleton")) then
		local origin = em.GetPos(v);
		for i = 1, em.GetBoneCount(v) do
			local parent = em.GetBoneParent(v, i);
			if(!parent) then continue; end
			local bonepos, parentpos = em.GetBonePosition(v, i), em.GetBonePosition(v, parent);
			if(!bonepos || !parentpos || bonepos == origin) then continue; end
                                                      local bs, ps = vm.ToScreen(bonepos), vm.ToScreen(parentpos);
			surface.SetDrawColor(255, 255, 255);
			surface.DrawLine(bs.x, bs.y, ps.x, ps.y);
		end
	end
	if (gBool("Visuals", "ESP", "Hitbox")) then
		for group = 0, em.GetHitBoxGroupCount(v) - 1 do
			local count = em.GetHitBoxCount(v, group)
			for hitbox = 0, count - 1 do
				local bone = em.GetHitBoxBone( v, hitbox, group );
				if(!bone) then continue; end
				local min, max = em.GetHitBoxBounds( v, hitbox, group );
				local bonepos, boneang = em.GetBonePosition( v, bone );
				cam.Start3D();
					render.DrawWireframeBox( bonepos, boneang, min, max, Color(0, 0, 255), true );
				cam.End3D();
			end
		end
	end
	end
end
propcol = color_white
hook.Add("PreDrawEffects", "HackPDH", function()
	if me:Alive() && propturn == 135 then
		propvel = 3100
		propspot = me:EyePos() + (am.Forward(Angle(0,fa.y+90,0))*60)
		oldpspot = me:EyePos() + (am.Forward(Angle(0,fa.y+90,0))*60)
		propveltr = am.Forward(fa + Angle(0,-2,0))*1750
		
			proptr = {
				start = propspot -(am.Forward(Angle(0,fa.y+90,0)*20)),
				endpos = me:EyePos(),
				mask = MASK_SHOT,
				filter = me,
				mins = Vector(-10,-10,-10),
				maxs = Vector(10,10,10),
			};
			proptres = util.TraceHull(proptr)
			if IsValid(proptres.Entity) then
		
				if (string.find(string.lower(proptres.Entity:GetClass()), "prop") || string.find(string.lower(proptres.Entity:GetClass()), "phys")) && proptres.Entity:GetOwner() == me then
					propmin, propmax = proptres.Entity:OBBMins(), proptres.Entity:OBBMaxs()
				end
			end
		
		

		for i =1, 25 do
			pvelo = propveltr * (engine.TickInterval()*(i*10))
			pvelo.z = (0.5 * -GetConVarNumber("sv_gravity") * math.pow( (engine.TickInterval()*(i*10)),2) + propveltr.z *  (engine.TickInterval()*(i*10)))
			--pvelo = am.Forward(pvelo:Angle()) * (math.Clamp(pvelo:Length() -20,0,pvelo:Length() -20))
			proptr = {
				start = propspot,
				endpos = propspot + pvelo,
				mask = MASK_SHOT,
				filter = function( ent ) if (!string.find(string.lower(ent:GetClass()), "prop") && !string.find(string.lower(ent:GetClass()), "phys") && ent ~= me  ) then return true end end,
				
				mins = propmin,
				maxs =propmax,
			};
			proptres = util.TraceHull(proptr)
			render.DrawLine(propspot,proptres.HitPos,propcol,true)
			if proptres.Hit then
				render.DrawWireframeBox( proptres.HitPos, Angle(0,0,0), propmin, propmax, Color(255,0,0), true )
				if proptres.Entity:IsPlayer() then
					propcol =Color(255,0,0)
				else
					propcol = color_white
				end
				return
			else
				propspot = proptres.HitPos 
			end
		end
	end
end)

if !dRadar then
dRadar = vgui.Create( "DFrame" )
end
dRadar:ShowCloseButton(false)
dRadar:SetSize( 200, 200 )
dRadar:SetPos(ScrW() - 206,6)
if rOffset then
	dRadar:SetPos(rOffset[1],rOffset[2])
end
dRadar:SetMouseInputEnabled(true)
dRadar:SetTitle("")
dragged = false

	rOffset = {}
if !file.Exists("rOffset.txt", "DATA") then
	local rtxt = file.Open( "rOffset.txt", "wb", "DATA" )

	rtxt:Write(util.TableToJSON({5,5}))
	rtxt:Close()
else
	rOffset = util.JSONToTable(file.Read("rOffset.txt", "DATA" ))

end

updatechecknew = false
finishedcheck = false
newnumver = 0
localver = 0
testver = 0

local function CheckUpdate()	
	localver = string.Explode(".", lemver)
	http.Fetch( "www.google.com",
		function( body, len, headers, code )
			newnumver = body
			testver = string.Explode(".", body)
			localver = string.Explode(".", lemver)
			
			for i= 1, 4 do
				if localver[i] && testver[i] then
					if localver[i] < testver[i] && !updatechecknew then
						updatechecknew = true
					end
				end
			end
		end,
		function( error )
		end
	)
end

local timenow = os.time()
local timediff = 0
pTraits = {}
table.Empty(pTraits)
namesF = true
names = ""


hook.Add("HUDPaint", "HackPoDH", function()
		menusize = 70

	if screengrab == false then

		if custtest[1] then
			for i=1, math.Clamp(#custtest,0,6) do
				if custtest[i][2] == "rainbow" then
					cColor = rColor
				else
					cColor = custtest[i][2]
				end
				draw.SimpleText( custtest[i][1], "BudgetLabel", 35 - (20*(66/math.Clamp(custtest[i][3],0,66))), (ScrH()-380) - menusize, cColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				menusize = menusize + 10
			end
		end


---------------------------------------------------

		
mousetoggle = false
	if !screengrab then
	rPosNowX, rPosNowY = dRadar:GetPos()
	if !dRadar:IsDragging() && (rPosNowX ~= rOffset[1] || rPosNowY ~= rOffset[2] ) && !input.IsMouseDown(MOUSE_LEFT) then
		rOffset[1], rOffset[2] = rPosNowX, rPosNowY
		file.Write("rOFfset.txt", util.TableToJSON(rOffset))
		--chat.AddText(Color(255,0,0), "Dropped.")
	end

	if gBool("Visuals", "Misc", "Radar") && !screengrab then
		dRadar:SetDraggable(false)
		if menuopen then
			dRadar:SetDraggable(true)
		end
	else
		dRadar:SetDraggable(false)
	end

	if gBool("Visuals", "Misc", "Radar") && !screengrab then
			if gOption("Visuals", "Misc", "Radar Type") == "Square" then
				function dRadar:Paint()
					surface.SetDrawColor(0, 0, 0, 75)
			        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			        MapAng = fa
			        mapPosX, mapPosY = self:GetPos()
			        eyetr = util.TraceLine( {
					start = me:GetPos(),
					endpos = me:GetPos()+ (am.Forward(Angle(270,0,0))*10000),
					filter = me,
					} )
					mapOut = gInt("Visuals", "Misc", "Radar Distance")
					--print(eyetr.HitPos)
							surface.SetDrawColor(menuscol)
			        render.RenderView({
						origin = eyetr.HitPos+ (am.Forward(Angle(0,MapAng.y,0))*(mapOut/2)),
						angles = Angle(90,MapAng.y,0), -- change to your liking
						--aspectratio = 1,
						x = mapPosX,
						y = mapPosY,
						w = self:GetWide(),
						h = self:GetWide(),
						drawviewmodel = false,
						ortho = true,
						ortholeft = -mapOut/2,
						orthoright = mapOut/2,
						orthotop = -mapOut,
						ortrobottom = mapOut,
						bloomtone = false,
					 })
			        surface.DrawLine( 0, self:GetTall()/2, self:GetWide(), self:GetTall()/2 )
					surface.DrawLine( self:GetWide()/2, 0, self:GetWide()/2, self:GetTall() )
					for k,v in next, player.GetAll() do
					if(!em.IsValid(v) || em.Health(v) < 0 || !v:Alive() || v:GetObserverMode() > 0 || v == me  ) then continue; end
						local modcolor = em.GetColor(v)
						if string.find(string.lower(GAMEMODE.Name), "prop") then
							modcolor = Color(255,255,255)
						end

						if(gBool("Aimbot", "Target", "Ignore Spawn Protection")) then
							modcolor = Color(255,255,255)
							if tttgod then
								modcolor.r = 100
							end
						end
						rPosX, rPosY, rPosW, rPosH = dRadar:GetBounds()
							newrPos = (rPosX + (rPosW/2))
							newrPosy = (rPosY + (rPosH/2))
						plyCol = color_white
						if(!Filter(v)) then continue; end

						if table.HasValue(Traitors, v) then
								if (v:GetFriendStatus() == "friend") then
									dplyCol = Color(255,0,255)
								elseif table.HasValue(Friends, v) then
									plyCol =Color(100,255,0)
								elseif(v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || v.ULXHasGod || (modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255  ) then
									plyCol = Color(100,100,100)
								elseif table.HasValue(Hackers, v:SteamID()) then
									plyCol =Color(255,255,0)
								else
									plyCol =Color(255,0,0)
								end
							else
								if (v:GetFriendStatus() == "friend") then	
									plyCol =Color(0,100,255)
								elseif table.HasValue(Friends, v) then
									plyCol =Color(0,255,0)
								elseif(v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || v.ULXHasGod || (modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255  ) then
									plyCol =Color(100,100,100)
								elseif table.HasValue(Tdectt, v) then
									plyCol = Color(0,255,255)
								elseif table.HasValue(Hackers, v:SteamID()) then
									plyCol =Color(255,255,0)
								else
									plyCol =Color(255,255,255)
								end
							end
						local zpos, pos = v:GetPos().z - me:GetPos().z, v:GetPos() - me:GetPos()
						pos:Rotate(Angle(0, 270+ fa.y, 180))
						local dist = (v:GetPos()-me:GetPos()):Length2D()
						local ScrX = (pos.x/gInt("Visuals", "Misc", "Radar Distance")) * 200
						local ScrY = (pos.y/gInt("Visuals", "Misc", "Radar Distance")) * 200
							teamCol = team.GetColor(v:Team())
							surface.SetFont( "BudgetLabel" )
								surface.SetTextColor(plyCol)
								vX, vY =surface.GetTextSize( v:GetName())
						if ScrX < 100 + (vX/2) && ScrY-15 < 100 then
							surface.SetDrawColor(0,0,0,255)
							surface.DrawRect(100 + ScrX-2, 100+ScrY-2,5,5)
							surface.SetDrawColor(teamCol.r,teamCol.g,teamCol.b,255)
							surface.DrawRect(100 + ScrX-1, 100+ScrY-1,3,3)
						
							surface.SetTextPos( 100+ScrX-(vX/2)+1, 100+ScrY+1 )
							surface.DrawText( v:GetName() )
							--draw.DrawText( v:GetName(), "BudgetLabel", newrPos + ScrX, newrPosy + ScrY, plyCol, TEXT_ALIGN_CENTER )
						
						end
					end
							surface.SetDrawColor(menuscol)
			        surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
					surface.SetDrawColor(0, 0, 0, 75)
				end
			elseif gOption("Visuals", "Misc", "Radar Type") == "Circle" then
				function dRadar:Paint()
					surface.SetDrawColor( 0, 0, 0, 75 )
					draw.NoTexture()
					draw.Circle( self:GetWide()/2,self:GetWide()/2, self:GetWide()/2, math.sin( 1 ) * 20 + 25 )
					center = Vector( self:GetWide()/2,self:GetWide()/2, 0 )
					scale = Vector( self:GetWide()/2, self:GetWide()/2, 0 )
					segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
					surface.SetDrawColor(menuscol)
					 surface.DrawLine( 0, self:GetTall()/2, self:GetWide(), self:GetTall()/2 )
					surface.DrawLine( self:GetWide()/2, 0, self:GetWide()/2, self:GetTall() )
						for k,v in next, player.GetAll() do
			if(!em.IsValid(v) || em.Health(v) < 0 || !v:Alive() || v:GetObserverMode() > 0 || v == me  ) then continue; end
				local modcolor = em.GetColor(v)
				if string.find(string.lower(GAMEMODE.Name), "prop") then
					modcolor = Color(255,255,255)
				end

				if(gBool("Aimbot", "Target", "Ignore Spawn Protection")) then
					modcolor = Color(255,255,255)
					if tttgod then
						modcolor.r = 100
					end
				end
				rPosX, rPosY, rPosW, rPosH = dRadar:GetBounds()
					newrPos = (rPosX + (rPosW/2))
					newrPosy = (rPosY + (rPosH/2))
				plyCol = color_white
				if(!Filter(v)) then continue; end

				if table.HasValue(Traitors, v) then
						if (v:GetFriendStatus() == "friend") then
							dplyCol = Color(255,0,255)
						elseif table.HasValue(Friends, v) then
							plyCol =Color(100,255,0)
						elseif(v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || v.ULXHasGod || (modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255  ) then
							plyCol = Color(100,100,100)
						elseif table.HasValue(Hackers, v:SteamID()) then
							plyCol =Color(255,255,0)
						else
							plyCol =Color(255,0,0)
						end
					else
						if (v:GetFriendStatus() == "friend") then	
							plyCol =Color(0,100,255)
						elseif table.HasValue(Friends, v) then
							plyCol =Color(0,255,0)
						elseif(v:HasGodMode() || v:IsFlagSet(FL_GODMODE) || v.ULXHasGod || (modcolor.r < 255 && modcolor.r > 0 || modcolor.g < 255 && modcolor.g > 0 || modcolor.b < 255 && modcolor.b > 0) || modcolor.a < 255  ) then
							plyCol =Color(100,100,100)
						elseif table.HasValue(Tdectt, v) then
							plyCol = Color(0,255,255)
						elseif table.HasValue(Hackers, v:SteamID()) then
							plyCol =Color(255,255,0)
						else
							plyCol =Color(255,255,255)
						end
					end
				local zpos, pos = v:GetPos().z - me:GetPos().z, v:GetPos() - me:GetPos()
				pos:Rotate(Angle(0, 270+ fa.y, 180))
				local dist = (v:GetPos()-me:GetPos()):Length2D()
				local ScrX = (pos.x/gInt("Visuals", "Misc", "Radar Distance")) * 200
				local ScrY = (pos.y/gInt("Visuals", "Misc", "Radar Distance")) * 200
					teamCol = team.GetColor(v:Team())
	
				if dist < (gInt("Visuals", "Misc", "Radar Distance")/2)  then
					
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(100 + ScrX-2, 100+ScrY-2,5,5)
					surface.SetDrawColor(teamCol.r,teamCol.g,teamCol.b,255)
					surface.DrawRect(100 + ScrX-1, 100+ScrY-1,3,3)
					
						surface.SetFont( "BudgetLabel" )
						surface.SetTextColor(plyCol)
						vX, vY =surface.GetTextSize( v:GetName())
						surface.SetTextPos( 100+ScrX-(vX/2)+1, 100+ScrY+1 )
						surface.DrawText( v:GetName() )
				end
			end
					surface.SetDrawColor(menuscol)
					for a = 0, 360 - segmentdist, segmentdist do
					surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
					end
				end
			end
		else
			
			function dRadar:Paint()
			end
		end

		if(gBool("Visuals", "ESP", "Enabled")) then
			for k,v in next, player.GetAll() do
				if(!em.IsValid(v) || !v:Alive() || em.Health(v) < 0|| v:GetObserverMode() > 0  || v == me && (!gBool("Misc", "Thirdperson", "Enabled")&&!plysp)) then continue; end
				if(!Filter(v)) then continue; end
				ESP(v)
			end
		end
		if beenscreened > 0 then
			if beenscreened > 1 then
				draw.SimpleText( "You've been screengrabbed " .. beenscreened.." times.", "BudgetLabel", ScrW()-5, ScrH()/2, Color(255,screenbl,screenbl), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP )
			elseif beenscreened == 1  then
				draw.SimpleText( "You've been screengrabbed " .. beenscreened.." time.", "BudgetLabel", ScrW()-5, ScrH()/2, Color(255,screenbl,screenbl), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP )
			end
			screenbl = math.Clamp(screenbl + 5, 0, 255)
		end
		if veloloss then
			test = me:GetVelocity():Angle().y - fa.y
			vRed = 255 * math.Clamp((math.cos(ctype3)+1),0,1)
			vGrn = 255 * math.Clamp((math.cos(ctype4)+1),0,1)
			thingy = Color(vRed, vGrn, 0)
			--draw.SimpleText( "Velocity lost: "..math.Round((math.cos(ctype4)+1)/2 * me:GetVelocity():Length2D(), 0), "BudgetLabel", ScrW()/2, (ScrH()/2) + 14, thingy, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			draw.SimpleText( "Velocity lost: "..math.Round(math.abs(math.NormalizeAngle(test)/180) * me:GetVelocity():Length2D(), 0), "BudgetLabel", ScrW()/2, (ScrH()/2) + 14, thingy, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		end
		if (gBool("Visuals", "Misc", "Crosshair")) then
			surface.SetDrawColor(crocol);
			surface.DrawLine((ScrW() / 2) - 15, ScrH() / 2,(ScrW() / 2) + 15, (ScrH() / 2));
			surface.DrawLine((ScrW() / 2), (ScrH() / 2) - 15,(ScrW() / 2) , (ScrH() / 2) + 15);
		end
	end

	if screengrab then return; end
	if gBool("Visuals", "Misc", "Status") then
		scrn = 120
		draw.DrawText("Velocity: ".. math.Round(me:GetVelocity():Length(), 0), "ESP", ScrW() -3, ScrH() - (scrn), Color(255,255,255), TEXT_ALIGN_RIGHT )
		scrn = scrn+17
		if tostring(me:GetActiveWeapon()) ~= "[NULL Entity]" then
			--draw.DrawText("Has Ammo: "..tostring(me:GetActiveWeapon()), "BudgetLabel", ScrW() -3, ScrH() - scrn, Color(255,255,255), TEXT_ALIGN_RIGHT )
			draw.DrawText("Ammo: "..math.Clamp(me:GetActiveWeapon():Clip1(),0,me:GetActiveWeapon():GetMaxClip1()).."/"..me:GetAmmoCount( me:GetActiveWeapon():GetPrimaryAmmoType() ), "ESP", ScrW() -3, ScrH() - (scrn), Color(255,255,255), TEXT_ALIGN_RIGHT )
			--draw.DrawText("Ammo Type: "..me:GetActiveWeapon():GetPrimaryAmmoType(), "BudgetLabel", ScrW() -3, ScrH() - (scrn+10), Color(255,255,255), TEXT_ALIGN_RIGHT )
			--draw.DrawText("Has Ammo: "..tostring(me:GetActiveWeapon():HasAmmo()), "BudgetLabel", ScrW() -3, ScrH() - scrn, Color(255,255,255), TEXT_ALIGN_RIGHT )
			scrn = scrn+17
		else
			draw.DrawText("Ammo: None", "ESP", ScrW() -3, ScrH() - (scrn), Color(255,255,255), TEXT_ALIGN_RIGHT )
			scrn = scrn+17
		end
		if me:Armor() > 0 then
			draw.DrawText("Armor: "..math.Clamp(me:Armor(),0,me:Armor()), "ESP", ScrW() -3, ScrH() - (scrn), Color(0,200,200), TEXT_ALIGN_RIGHT )
		scrn = scrn+17
		end
		pRed = (math.Clamp(((100-em.Health(me))*2),0,100)/100)*255
		pGreen = (math.Clamp((em.Health(me)*2),0,100)/100)*255
		draw.DrawText("Health: "..math.Clamp(me:Health(),0,me:Health()), "ESP", ScrW() -3, ScrH() - (scrn), Color(pRed, pGreen, 0), TEXT_ALIGN_RIGHT )
		scrn = scrn+17
	end
	checkdissheit = Angle(fa.p,fa.y + 30, 0)
	fovpos = checkfovpos + (am.Forward(GetAngle(fa) + Angle(gInt("Aimbot", "Aimbot", "fov"),0,0)) * 100)
	fovpos = fovpos:ToScreen()
	center = Vector( ScrW()/2, ScrH()/2, 0 )
	scale = Vector( fovpos.y - ScrH()/2, fovpos.y - ScrH()/2, 0 )
	surface.SetDrawColor(menuscol)
	segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
	if (showfov || gBool("Visuals", "Misc", "Always show FOV"))&& me:Alive() && me:GetObserverMode() == 0 && fovpos.y <= (ScrW()) && !gBool("Misc", "Thirdperson", "Enabled") then
	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
	end
	end
	local menudist = 6
	if !screengrab then
			
			
		for _, v in next, player.GetAll() do
			
			if v:IsPlayer() and v:GetObserverTarget() == LocalPlayer() && me:Alive() then
				if not table.HasValue(Spectators, v) then
				table.insert(Spectators, v)
				if gBool("Misc", "Notifications", "Show Spectators") then
				table.insert(custtest,1,{v:Nick().." started spectating you.", Color(255,255,0), 9/engine.TickInterval()})
				MsgC(v:Nick().." started spectating you.\n")
				--chat.AddText(Color(255, 0, 0), v:Nick(), Color(255, 255, 255)," started spectating you.")
				end
				if gBool("Misc", "Notifications", "Spectators Sound") then
				surface.PlaySound("npc/scanner/combat_scan3.wav")
				end
				end
			end
			for k,v in SortedPairs(Spectators, true) do
				if IsValid(v) && me:Alive() then
					if v:GetObserverTarget() != LocalPlayer() then
						table.remove(Spectators, k)
						if gBool("Misc", "Notifications", "Show Spectators") then
							table.insert(custtest,1,{v:Nick().." is no longer spectating you.", Color(0,255,0), 9/engine.TickInterval()})
							MsgC(v:Nick().." is no longer spectating you.\n")
						--chat.AddText(Color(0, 255, 0), v:Nick(), Color(255, 255, 255)," is no longer spectating you.")
						end
						if gBool("Misc", "Notifications", "Spectators Sound") then
						surface.PlaySound("npc/scanner/combat_scan2.wav")
						end
					end
				elseif !IsValid(v) then
					table.remove(Spectators, k)	
				elseif !me:Alive() then
					table.Empty(Spectators)
				end
			end
			if check_Admin(v) || check_Mod(v) || check_Super(v) then
				if not table.HasValue(Admin, v) then
					table.insert(Admin, v)
					if gBool("Misc", "Notifications", "Show Admins") then
					table.insert(custtest,1,{v:GetUserGroup().." "..v:Nick().." is online.", Color(255,255,0), 9/engine.TickInterval()})
					MsgC(v:GetUserGroup().." "..v:Nick().." is online.\n")
					--chat.AddText(Color(255, 0, 0), v:GetUserGroup(), " ", Color(255, 255, 255),  v:Nick()," is online.")
					end
					if gBool("Misc", "Notifications", "Admins Sound") then
					surface.PlaySound("vo/npc/female01/watchout.wav")
					end
				end
			end
			for k,v in SortedPairs(Admin, true) do
				if IsValid(v) then
					if !check_Admin(v) && !check_Mod(v) && !check_Super(v) then
						table.remove(Admin, k)
					end
				elseif !IsValid(v) then
					table.remove(Admin, k)	
				end
			end
	    end
		
		if string.find(string.lower(GAMEMODE.Name), "terror") then
			for _, v in next, player.GetAll() do
				if v:IsRole(ROLE_TRAITOR) && me:IsRole(ROLE_TRAITOR) && v ~= me && v:Alive() && me:Team() == v:Team() && me:Team() ~= TEAM_SPECTATOR && GetRoundState() == 3 then
					tbudd = true
					if !table.HasValue(Tbud, v) then
						table.insert(Tbud, v)
						if v:GetFriendStatus() ~= "friend" then
						table.insert(pTraits, v)
						end
						 chat.AddText(Color(255, 10, 10), v:Nick(), Color(255,255,255), " is your Traitor Buddy.")
						 surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
					end
					if !table.HasValue(Traitors, v) then
						table.insert(Traitors, v)
					end
				elseif v:IsRole(ROLE_DETECTIVE) && !me:IsRole(ROLE_TRAITOR) && v ~= me && v:Alive() && me:Team() == v:Team() && me:Team() ~= TEAM_SPECTATOR && GetRoundState() == 3 then
				
					if !table.HasValue(Tdectt, v) && !tdect then
						table.insert(Tdectt, v)
						table.insert(custtest,1,{v:Nick().." is detective.", Color(0,255,255), 9/engine.TickInterval()})
						MsgC(v:Nick().." is detective.\n")
						--chat.AddText(Color(0, 255, 255), v:Nick(), Color(255,255,255), " is a Detective.")
						surface.PlaySound("npc/metropolice/vo/citizen.wav")
					end
				end
				
			end
			if Tdectt[1] then
				tdect = true
			elseif GetRoundState() != 3 then
				table.Empty(Tdectt)
				tdect = false
			end
			if gBool("Misc", "Spam", "pAsshole") then
				if pTraits[1] && namesF then
					if #pTraits == #Traitors then
						for i = 1, #pTraits, 1 do
							if pTraits[1] && namesF then
								if #pTraits > 1 then
									if	#pTraits ~= i && pTraits[i] && pTraits[i] ~= me  then
										names = names .. pTraits[i]:GetName() .. ", "
									else
										names = names .."and ".. pTraits[i]:GetName() .. " are my T buddies."
									end
								else
									if  pTraits[i] && pTraits[i] ~= me then
									names = pTraits[i]:GetName() .. " is my T buddy."
									end
								end
							end
							if #pTraits == i then
								namesF = false
								table.Empty(pTraits)
								
							end
						end
						RunConsoleCommand("say", names)
						namesF = true
						names = ""
						table.Empty(pTraits)
					end
				end
			end
			
			for _, v in next, ents.GetAll() do
	            if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and !table.HasValue(traitorswep, v) and table.HasValue(v.CanBuy, 1) then
					
					local owner = v:GetOwner()
	                if owner:GetRole() == 2 then
	                        v.Buyer = owner
	                else
						if !table.HasValue(Traitors, owner) then
						table.insert(Traitors, owner)
						end
						weapname = v:GetPrintName()
						weapname = string.Replace(weapname, "_name", "")
						if gBool("Misc", "Spam", "pAsshole") && owner:GetFriendStatus() ~= "friend" && owner ~= me then
						RunConsoleCommand("say", owner:Nick().." bought a traitor weapon: ".. weapname.. "!")
						end
						table.insert(custtest,1,{owner:Nick().." bought a traitor weapon: "..weapname..".", Color(255,0,0), 9/engine.TickInterval()})
						MsgC(owner:Nick().." bought a traitor weapon: "..weapname..".\n")
	                    --chat.AddText(Color(255, 10, 10), owner:Nick(), Color(255,255,255), " bought a traitor weapon: ", weapname)
	                    v.Buyer = owner
	                    table.insert(traitorswep, v)
	                    surface.PlaySound("weapons/shotgun/shotgun_cock.wav")  
	                end
	            elseif GetRoundState() != 3 then
	                    table.Empty(Traitors)
						table.Empty(Tdectt)
						table.Empty(traitorswep)
						tbudd = false
						tdect = false
	            end
				
				end
			
			for k,v in SortedPairs(Traitors, true) do
				if !IsValid(v) || !v:Alive() || v:Team() == TEAM_SPECTATOR  then
					table.remove(Traitors, k)
				end
			end
			
			for k,v in SortedPairs(Tbud, true) do
				if !IsValid(v) || !v:Alive() || v:Team() == TEAM_SPECTATOR  then
					table.remove(Tbud, k)
				end
			end
			for k,v in SortedPairs(Tdectt, true) do
				if !IsValid(v) || !v:Alive() || v:Team() == TEAM_SPECTATOR  then
					table.remove(Tdectt, k)
				end
			end

		elseif string.find(string.lower(GAMEMODE.Name), "morbus") then
			if GetRoundState() < 3 then
			tttgod = true
			elseif GetRoundState() == 3 || GetRoundState() == 4 then
				tttgod = false
			else
				tttgod = true
			end
			for _, v in next, ents.GetAll() do
				if v:IsWeapon() && type(v:GetOwner()) == "Player"  then
					owner = v:GetOwner()
					if (v:GetClass() == "weapon_mor_brood" || v:GetClass() == "weapon_mor_swarm") && !table.HasValue(Traitors, owner) && GetRoundState() ==3  then
						if owner == me then
							tbudd = true
						end
					table.insert(Traitors, owner)
					end
				end
			end
			for k,v in SortedPairs(Traitors, true) do
				if !IsValid(v) || !v:Alive() || v:Team() == TEAM_SPECTATOR || GetRoundState() ~= 3  then
					if v == me || GetRoundState() ~= 3 then
						tbudd = false
					end
					table.remove(Traitors, k)
				end

			end
		elseif string.find(string.lower(GAMEMODE.Name), "murder") then
			for _, v in next, ents.GetAll() do
				if v ~= me then
					local ply = v:GetOwner()
					if  v:IsWeapon() and type(v:GetOwner()) == "Player" and v:GetClass() then
						if ply:Alive() and v:GetClass() == "weapon_mu_knife" and !table.HasValue(Traitors, ply) then
							table.insert(Traitors, ply)
						end
						if ply:Alive() and (v:GetClass() == "weapon_mu_magnum") and !table.HasValue(Tdectt, ply) then
							table.insert(Tdectt, ply)
						end
					end
				end
				if IsValid(v) then
					if v:GetClass() == "weapon_mu_magnum" || string.find(string.lower(v:GetClass()),"knife") || v:GetClass() == "mu_loot" then
						wepPos = v:GetPos():ToScreen()

						if v:GetClass() == "weapon_mu_magnum" then
							wepCol = Color(0,0,255)
							wepName ="Magnum"
						
							if (v:GetClass() == "weapon_mu_magnum" && !v:GetOwner():IsPlayer()) then
								draw.DrawText( wepName, "BudgetLabel", wepPos.x+ 5, wepPos.y, wepCol, TEXT_ALIGN_LEFT )
							end
						elseif string.find(string.lower(v:GetClass()),"knife") then
							wepCol = Color(255,0,0)
							wepName = "Knife"
							
							if v:GetClass() == "mu_knife" || (v:GetClass() == "weapon_mu_knife" && !v:GetOwner():IsPlayer()) then
							draw.DrawText( wepName, "BudgetLabel", wepPos.x+ 5, wepPos.y, wepCol, TEXT_ALIGN_LEFT )
							end
						elseif v:GetClass() == "mu_loot" then
							wepCol = Color(0,255,0)
							wepName = "Loot"
							draw.DrawText( wepName, "BudgetLabel", wepPos.x+ 5, wepPos.y, wepCol, TEXT_ALIGN_LEFT )
						end
					end
				end
			end
			
			for k,v in SortedPairs(Traitors, true) do
				if !IsValid(v) || !v:Alive() || !v:HasWeapon( "weapon_mu_knife" ) ||  v:Team() == TEAM_SPECTATOR || me:Team() ~= v:Team() then
					table.remove(Traitors, k)
				end
			end
			for k,v in SortedPairs(Tdectt, true) do
				if !IsValid(v) || !v:Alive() ||!v:HasWeapon( "weapon_mu_magnum" ) || v:Team() == TEAM_SPECTATOR || me:Team() ~= v:Team() then
					table.remove(Tdectt, k)
				end
			end
		end
		surface.SetFont("BudgetLabel")
		surface.SetTextColor(Color(255, 255, 255))
		local WidthA, SHeightA = surface.GetTextSize("Admins:")
		local HeightA = 3
		local numberA = 0
		for k,v in SortedPairs(Admin, true) do
			numberA = numberA + 1
			local W, H = surface.GetTextSize(v:GetName() .. " [" .. v:GetUserGroup() .. "]")
			if W > WidthA then
				WidthA = W
			end
			if gBool("Misc", "Notifications", "Show Admins") then
			draw.DrawText( v:GetName() .. " [" .. v:GetUserGroup() .. "]", "BudgetLabel", 8, menudist + HeightA- 5 + SHeightA, Color(255,255,255), TEXT_ALIGN_LEFT )
			HeightA = HeightA + 10
			else
			HeightA = 3
			end
		end
		if numberA ~= 0 && gBool("Misc", "Notifications", "Show Admins") then
		surface.SetDrawColor(0, 0, 0, 75)
		surface.DrawRect( 6, menudist, WidthA +5, HeightA + SHeightA )
		surface.SetDrawColor(menuscol)
		surface.DrawOutlinedRect( 5, menudist - 1, WidthA + 6, HeightA + 2 + SHeightA )
		draw.DrawText( "Admins:", "BudgetLabel", 10, menudist, Color(255,255,255), TEXT_ALIGN_LEFT )
		surface.DrawLine(6,menudist + SHeightA -2, WidthA + 10, menudist + SHeightA -2)
		menudist = menudist + HeightA + 9 + SHeightA
		end
		surface.SetFont("BudgetLabel")
		surface.SetTextColor(Color(255, 255, 255))
		local Width, SHeight = surface.GetTextSize("Spectators:")
		local Height = 3
		local number = 0
		for k,v in SortedPairs(Spectators, true) do
			number = number + 1
			local W, H = surface.GetTextSize(v:GetName() .. " [" .. v:GetUserGroup() .. "]")
			if W > Width then
				Width = W
			end
			if gBool("Misc", "Notifications", "Show Spectators") then
			draw.DrawText( v:GetName() .. " [" .. v:GetUserGroup() .. "]", "BudgetLabel", 8, menudist + Height- 5 + SHeight, Color(255,255,255), TEXT_ALIGN_LEFT )
			Height = Height + 10
			else
			Height = 3
			end
		end
		if number ~= 0 && gBool("Misc", "Notifications", "Show Spectators") then
		surface.SetDrawColor(0, 0, 0, 75)
		surface.DrawRect( 6, menudist, Width +5, Height + SHeight )
		surface.SetDrawColor(menuscol)
		surface.DrawOutlinedRect( 5, menudist - 1, Width + 6, Height + 2 + SHeight )
		draw.DrawText( "Spectators:", "BudgetLabel", 10, menudist, Color(255,255,255), TEXT_ALIGN_LEFT )
		surface.DrawLine(6,menudist + SHeight -2, Width + 10, menudist + SHeight -2)
		end
		timediff = os.time() - timenow
		if timediff >= 10 && !updatechecknew then
			timenow = os.time()
			CheckUpdate()
		end
		if updatechecknew then
			local W, H = surface.GetTextSize("v" .. newnumver.." is now available!")
			surface.SetDrawColor(0, 0, 0, 75)
			surface.DrawRect( ScrW() - (8 + W), 106, W+2, H )
			surface.SetDrawColor(menuscol)
			surface.DrawOutlinedRect( ScrW() - (9 + W), 105, W+3, H+1 )
			draw.DrawText( "v" .. newnumver.." is now available!", "BudgetLabel", ScrW() - 6, 106, rColor, TEXT_ALIGN_RIGHT )
			if !finishedcheck then
				surface.PlaySound("vo/coast/odessa/male01/nlo_cheer01.wav")
				surface.PlaySound("HL1/fvox/bell.wav")
				finishedcheck = true
			end
		end
		--[[local WidthAA, SHeightAA = surface.GetTextSize("Angles: ")
		local HeightAA = 3
		local numberAA = 0
		for _, v in next, player.GetAll() do
			som = tostring(v:EntIndex())
			numberAA = numberAA + 1
			if v && plyadd[som] then
			local W, H = surface.GetTextSize(v:GetName() .. " Angles: " .. plyadd[som])
			if W > WidthAA then
				WidthAA = W
			end
			draw.DrawText( v:GetName() .. " 's Angles: "..plyadd[som], "BudgetLabel", 8, menudist + HeightAA- 5 + SHeightAA, Color(255,255,255), TEXT_ALIGN_LEFT )
			HeightAA = HeightAA + 10
			end
			end]]
		end
	end
end)





smoothdata = {0,0,0,0}
	

hook.Add("CreateMove", "HackCM", function(ucmd)
	bSendPacket = true	
	meme(ucmd);
	bhop(ucmd);
	aimer(ucmd);
	antiaimer(ucmd);
	FixMovement(ucmd);
	rColor = HSVToColor( RealTime() * 120 % 360, 1, 1 )
	for _, ply in next, player.GetAll() do
		plyI = ply:EntIndex()
		if ucmd:CommandNumber() ~= 0 then
			plyAng = Angle(math.NormalizeAngle(ply:EyeAngles().p), math.NormalizeAngle(ply:EyeAngles().y), math.NormalizeAngle(ply:EyeAngles().r))
			if checkturn[plyI] ~= plyAng then
				checkturn2[plyI] = checkturn[plyI] - plyAng
				checkturn2[plyI]:Normalize()
				checkturn[plyI] = plyAng
			else
				checkturn2[plyI] = Angle(0,0,0)
				checkturn[plyI] = plyAng
			end
			if ply:IsFlagSet(FL_ONGROUND) then
				if bunny[plyI] == 0 then
					bunny2[plyI] = bunny2[plyI] +1
					bunny[plyI] = bunny[plyI] +1
				elseif bunny[plyI] < 2 then
					bunny[plyI] = bunny[plyI] +1
				else
					bunny2[plyI] = 0
				end
			else
				bunny[plyI] = 0
			end
		end
	end
	if custtest[1] && ucmd:CommandNumber() ~= 0 then
		if custtest[7] then
			table.remove(custtest, 7)
		end
		for i=1, math.Clamp(#custtest,0,6) do
			if custtest[i]then


			custtest[i][3] = math.Clamp(custtest[i][3] - 1, 0, custtest[i][3])
			if custtest[i][3] == 0 then
				table.remove(custtest, i)
			end
		end
		end
	end

	if inserttime > 0 && ucmd:CommandNumber() ~= 0 then
		inserttime = math.Clamp(inserttime - 1, 0, 12/engine.TickInterval())
	end
	return false
end);
checksong = false
function playsong()
	if string.find(gText("Misc", "Music", "URL/DIR"), ".mp3") then
	
end
end



hook.Add("CalcView", "HackCV", function(p, o, a, f)
	
	if !screengrab then
	
		local ctrace = {
			start = o,
			endpos = o - (am.Forward(fa) * gInt("Misc", "Thirdperson", "Distance")),
			mins = Vector( -3, -3, -3 ),
			maxs = Vector( 3, 3, 3 ),
			filter = function( ent ) if ( ent:GetClass() == "ph_prop" || ent == me) then return false end end,
		}
		test = Angle(89,0,0)
		checkfovang = Angle(math.Clamp(GetAngle(fa).p, -89, GetAngle(Angle(89,0,0)).p),GetAngle(fa).y,GetAngle(fa).r)
		checkfovpos = o
		local ctres = util.TraceHull(ctrace)
		local Cee = ctres.Fraction
		if gBool("Misc", "Thirdperson", "No-Collide") && (team.GetName(me:Team()) == "Props" && me:Alive()) then
			Cee = 1 
		elseif gInt("Misc", "Thirdperson", "Distance") == 50 && (team.GetName(me:Team()) == "Props" && me:Alive()) then
			Cee = 0
		end
		if gBool("Visuals", "Misc", "Custom FOV") then
		cfov = f+ (gInt("Visuals", "Misc", "FOV") - GetConVarNumber("fov_desired"))
		else
		cfov = f
		end
		if me:GetObserverMode() == 0 && me:Alive() then
			if me:IsPlayingTaunt() then
				return({
				angles = plysp && plysp:EyeAngles()||Angle(math.Clamp(GetAngle(fa).p, -89, GetAngle(Angle(89,0,0)).p),GetAngle(fa).y,GetAngle(fa).r),
				origin = (plysp && plysp:EyePos()||o - (am.Forward(fa) * (gInt("Misc", "Thirdperson", "Distance") * Cee)) && !screengrab || o),
				fov = cfov + addfov,
				});
			else
				return({
				angles = plysp && plysp:EyeAngles()||Angle(math.Clamp(GetAngle(fa).p, -89, GetAngle(Angle(89,0,0)).p),GetAngle(fa).y,GetAngle(fa).r),
				origin = (!screengrab &&plysp && plysp:EyePos()||(gBool("Misc", "Thirdperson", "Enabled") || (team.GetName(me:Team()) == "Props" && me:Alive())) && !screengrab && (o - (am.Forward(fa) * (gInt("Misc", "Thirdperson", "Distance")* Cee)))|| o),
				fov = cfov + addfov,
				});
			end
		else
			return({
				origin = plysp && plysp:EyePos()||o,
				angles = plysp && plysp:EyeAngles()||a,
				fov = cfov + addfov,
				});
		end
	end
end);

hook.Add("ShouldDrawLocalPlayer", "HackSDLP", function()
	if !screengrab then
	if me:GetObserverMode() == 0 then
		if me:IsPlayingTaunt() then
			return true
		else
			return(plysp||gBool("Misc", "Thirdperson", "Enabled") && !screengrab);
		end
	elseif plysp then
		return true
	else
		return false
	end
	end
end);

hook.Add("PreDrawPlayerHands", "HackPDPH", function()
	if !screengrab then
	render.MaterialOverride(CreateMaterial("b", "asda", {["$ignorez"] = 0,["$model"] = 0,}))
	else
		render.SuppressEngineLighting(false)
			render.SetColorModulation(1,1,1);
			render.MaterialOverride();
	end
end);

hook.Add("PostDrawViewModel", "HackPoDVM", function(vm, ply, weapon)
		hands = LocalPlayer():GetHands()
		if ( IsValid( hands ) && !screengrab ) then 
			if gInt("Visuals", "Misc", "Hand Type") == "Chams 3D" then
			render.SuppressEngineLighting(false)
			if gBool("Visuals", "Misc", "Hands - IgnoreZ") then
			render.SetColorModulation(GetHandsColor());
			render.MaterialOverride(chamsmat);
			hands:DrawModel() 
			end
			render.SetColorModulation(GetHandsColor(true));
			render.MaterialOverride(chamsmat2);
			hands:DrawModel()
			elseif  gInt("Visuals", "Misc", "Hand Type") == "Rainbow" then
			render.SuppressEngineLighting(false)
			if gBool("Visuals", "Misc", "Hands - IgnoreZ") then
			render.SetColorModulation((255-rColor.r) / 255, (255-rColor.g) / 255, (255-rColor.b) / 255);
			render.MaterialOverride(chamsmat);
			hands:DrawModel() 
			end
			render.SetColorModulation(rColor.r / 255, rColor.g / 255, rColor.b / 255);
			render.MaterialOverride(chamsmat2);
			hands:DrawModel()
			elseif gInt("Visuals", "Misc", "Hand Type") == "Chams 2D" then
			render.SuppressEngineLighting(true)
			if gBool("Visuals", "Misc", "Hands - IgnoreZ") then
			render.MaterialOverride(chamsmat);
			render.SetColorModulation(GetHandsColor());
			hands:DrawModel() 
			end
			render.SetColorModulation(GetHandsColor(true));
			render.MaterialOverride(chamsmat2);
			hands:DrawModel()
			--render.SuppressEngineLighting(false)
			elseif gInt("Visuals", "Misc", "Hand Type") == "WireFrame" then
			if gBool("Visuals", "Misc", "Hands - IgnoreZ") then
			render.SuppressEngineLighting(false)
			render.SetColorModulation(GetHandsColor());
			render.MaterialOverride(CreateMaterial("test", "Wireframe", {["$ignorez"] = 1,}))
			hands:DrawModel()
			end
			render.SetColorModulation(GetHandsColor(true));
			render.MaterialOverride(Material("models/wireframe"))
			hands:DrawModel()
			elseif gInt("Visuals", "Misc", "Hand Type") == "Normal" then
			render.SuppressEngineLighting(false)
			render.SetColorModulation(1,1,1);
			render.MaterialOverride();
			hands:DrawModel()
			end
		else
			render.SuppressEngineLighting(false)
			render.SetColorModulation(1,1,1);
			render.MaterialOverride();
		end
end);

hook.Add("PreDrawViewModel", "HackPrDVM", function()
	if !screengrab then
	if gInt("Visuals", "Misc", "Weapon Type") == "WireFrame" then
	render.SuppressEngineLighting(false)
	render.SetColorModulation(GetWeapsColor());
	render.MaterialOverride(Material("models/wireframe"))
	elseif gInt("Visuals", "Misc", "Weapon Type") == "Chams 3D" then
	render.SuppressEngineLighting(false)
	render.SetColorModulation(GetWeapsColor());
	render.MaterialOverride(chamsmat2);
	elseif gInt("Visuals", "Misc", "Weapon Type") == "Rainbow" then
	render.SuppressEngineLighting(false)
	render.SetColorModulation(rColor.r / 255, rColor.g / 255, rColor.b / 255);
	render.MaterialOverride(chamsmat2);
	elseif gInt("Visuals", "Misc", "Weapon Type") == "Chams 2D" then
	render.SuppressEngineLighting(true)
	render.SetColorModulation(GetWeapsColor());
	render.MaterialOverride(chamsmat2);
	elseif gInt("Visuals", "Misc", "Weapon Type") == "No Weapon" then
	render.SuppressEngineLighting(false)
	render.MaterialOverride(CreateMaterial("nonothing", "UnlitGeneric", {["$ignorez"] = 0,["$model"] = 0,}))
	elseif gInt("Visuals", "Misc", "Weapon Type") == "Normal" then
	render.SuppressEngineLighting(false)
	render.MaterialOverride()
	end
	else
		render.SuppressEngineLighting(false)
	render.MaterialOverride()
	end
end)


surface.PlaySound("buttons/combine_button1.wav")
hook.Add("ScalePlayerDamage", "HackSPD", function(pl, hitGroup, DmgInfo)
	if pl ~= me && pl == aimtarget && hitGroup then
	pls = aimtarget:EntIndex()
	FaAng[pls][1] = FaAng[pls][1] + 1	
	end
	if gBool("Misc", "Sounds", "Hit Sounds") then
	
		if hitGroup == HITGROUP_HEAD then
			sound.PlayFile("sound/Head.wav", "", function(snd)
				if (IsValid(snd)) then snd:Play() end
			end)
		else
			sound.PlayFile("sound/Hit.wav", "", function(snd)
				if (IsValid(snd)) then snd:Play() end
			end)
		end
	end
end)