/*Hemi Hacks by: Hemirox*/
if( SERVER ) then return end

local version = 2.21
local lastupdated = "6/7/12"


/*---------Variables---------*/


local hook = require ( "hook" )
local draw = require ( "draw" )
local cvars = require ( "cvars" )
local concommand = require ( "concommand" )
local glon = require( "glon" )

local function LoadHH()

local HH = {}
HH.BH = {}

function HH.RandomString( len )
        local ret = ""
       
        for i = 1 , len do
                ret = ret .. string.char( math.random( 65 , 116 ) )
        end
       
        return ret
end

 /*Hook System (Taken from FapHack)*/
HH.Hooks = {}
function HH.AddHook( type , func )
        if not HH.Hooks[type] then
                HH.Hooks[type] = {}
               
                local index = HH.RandomString( 10 )
               
                HH.Hooks[type].Index = index
                HH.Hooks[type].Functions = {}
               
                hook.Add( type, index, function( ... )
                        for k , v in pairs( HH.Hooks[ type ].Functions ) do
                                local isok, ret = pcall( v , ... )
                               
                                if not isok then
                                        ErrorNoHalt( ret.."\n" )
                                elseif ret ~= nil then
                                        return ret
                                end
                        end
                end )
               
               
                table.insert( HH.Hooks[type].Functions , func )
        else
                table.insert( HH.Hooks[type].Functions , func )
        end
end

/*Timers*/
HH.Timers = {}
function HH.AddTimer( sec, rep, func )
	local index = HH.RandomString( 10 )
	
	HH.Timers[ index ] = sec
	
	timer.Create( index, sec, rep, func )
end

/*Static Variables*/
HH.AimbotIsOn = false
HH.IsLocked = false
HH.LockedPlayer = nil
HH.BHop = false
HH.Me = LocalPlayer
HH.LastReload = 0
HH.Friends = ( file.Exists( "hemihack/hh_friends.txt" ) and glon.decode( file.Read( "hemihack/hh_friends.txt" ) ) or {} )
HH.Teams = ( file.Exists( "hemihack/hh_teams.txt" ) and glon.decode( file.Read( "hemihack/hh_teams.txt" ) ) or {} )
HH.CustomEnts = ( file.Exists( "hemihack/hh_ents.txt" ) and glon.decode( file.Read( "hemihack/hh_ents.txt" ) ) or {} )
HH.TargetBone = ( file.Exists( "hemihack/hh_bone.txt" ) and file.Read( "hemihack/hh_bone.txt" ) or "ValveBiped.Bip01_Head1" )
HH.CNPos = HH.Me():EyePos()
HH.BH.Hops = 0
HH.BH.MaxSpeed = 0
HH.SpeedOn = false
HH.PerpEnabled = false
HH.MenuCreated = false
HH.CanDoSteamStuff = false
HH.Loaded = false
HH.BaseColor = Color( 0, 150, 255, 250 )
HH.HostTimeScale = GetConVar( "host_timescale" )
HH.SvCheats = GetConVar( "sv_cheats" )

/*Client Changeable Vars*/
HH.AutoShoot = CreateClientConVar( "hh_autoshoot", "1", true, false )
HH.MaxAimAngle = CreateClientConVar( "hh_maxangle", "90", true, false )
HH.CheckLos = CreateClientConVar( "hh_checklos", "1", true, false )
HH.IgnoreSteamFriends = CreateClientConVar( "hh_ignoresteamfriends", "1", true, false )
HH.ESPEnabled = CreateClientConVar( "hh_espenabled", "1", true, false )
HH.ShowPlayers = CreateClientConVar( "hh_showplayers", "1", false, false )
HH.ShowEnts = CreateClientConVar( "hh_showents", "1", false, false )
HH.ESPDist = CreateClientConVar( "hh_espdist", "2500", true, false )
HH.CustomBone = CreateClientConVar( "hh_custombone", "0", true, false )
HH.DrawCrosshair = CreateClientConVar( "hh_crosshair", "1", true, false )
HH.ShowAdmins = CreateClientConVar( "hh_showadmins", "1", true, false )
HH.AutoReload = CreateClientConVar( "hh_autoreload", "1", true, false )
HH.ShowLaserEyes = CreateClientConVar( "hh_lasereyes", "1", true, false )
HH.FriendsBlackList = CreateClientConVar( "hh_friendsblacklist", "0", true, false )
HH.TeamsBlackList = CreateClientConVar( "hh_teamsblacklist", "0", true, false )
HH.IgnoreFriends = CreateClientConVar( "hh_ignorefriends", "0", true, false )
HH.IgnoreTeams = CreateClientConVar( "hh_ignoreteams", "0", true, false )
HH.IgnoreOwnTeam = CreateClientConVar( "hh_ignoreownteam", "0", true, false )
HH.NoRecoil = CreateClientConVar( "hh_norecoil", "1", true, false )
HH.WallHackEnabled = CreateClientConVar( "hh_wallhack", "0", true, false )
HH.WallHackSolid = CreateClientConVar( "hh_solidwallhack", "1", true, false )
HH.Chams = CreateClientConVar( "hh_chams", "1", true, false )
HH.IgnoreAdmins = CreateClientConVar( "hh_ignoreadmins", "0", true, false )
HH.ClientNoclip = CreateClientConVar( "hh_clientnoclip", "0", true, false )
HH.CNSpeed = CreateClientConVar( "hh_clientnoclipspeed", "10", true, false )
HH.ThirdPerson = CreateClientConVar( "hh_thirdperson", "0", true, false )
HH.ThirdDist = CreateClientConVar( "hh_thirdpersondist", "10", true, false )
HH.SpeedHackSpeed = CreateClientConVar( "hh_speedhackspeed", "5.0", true, false )
HH.AntiAfkEnabled = CreateClientConVar( "hh_antiafkkicker", "0", false, false )
HH.NoSpreadEnabled = CreateClientConVar( "hh_nospread", "1", false, false )
HH.LogIps = CreateClientConVar( "hh_logips", "1", true, false )
HH.NameChanger = CreateClientConVar( "hh_namechanger", "0", false, false )
HH.ShowTraitors = CreateClientConVar( "hh_showtraitors", "1", false, false )
HH.OnlyTargetTraitors = CreateClientConVar( "hh_targettraitors", "0", false, false )
HH.LeftShoulder = CreateClientConVar( "hh_tpleftshoulder", "0", false, false )
HH.TargetNPCs = CreateClientConVar( "hh_targetnpcs", "0", false, false )
RunConsoleCommand( "hh_namechanger", "0" )


/*Valid Bones*/
HH.ValidBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Pelvis",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_R_Foot",
}

HH.InvalidEnts = {
"player",
"prop_physics",
"viewmodel",
}

surface.CreateFont ( "ScoreboardText", 15, 700, true, false, "HHScoreboardText" )


/*Notify*/
function HH.Notify( msg, sound )
	HH.Me():ChatPrint( "[HH] " .. msg )
	if( sound ) then
		local beep = Sound( "/buttons/button17.wav" )
		local mysound = CreateSound( HH.Me(), beep )
		mysound:Play()
	end
end

HH.Notify( "Loading...", false )

HH.AddTimer( 1, 1, function() 
	HH.Notify( "Loading Modules..." )
	HH.ModLoaded = require( "hh" )
	if( HH.ModLoaded ) then 
		HH_ForceCvar( GetConVar("sv_cheats"), "1" ) 
	end
end )

HH.AddTimer( 1, 1, function() 
	HH.CanNospread = require( "hhns" ) 
	if( HH.CanNospread ) then
		HH.hl2_ucmd_getprediciton = hl2_ucmd_getprediciton
		HH.hl2_shotmanip = hl2_shotmanip
	end
end )


/*---------Functions---------*/


/*Get Target*/
function HH.GetNextTarget()
	if( HH.IsLocked and HH.IsValidPlayer( HH.LockedPlayer ) ) then return end
	local pls = {}
    for k, v in pairs( ents.GetAll() ) do
		if( HH.IsValidPlayer( v ) ) then
			local td = {}
			local targethead = v:LookupBone( HH.GetBone() )
			td.start = HH.Me():EyePos()
			td.endpos = v:GetBonePosition( targethead )
			local angle = HH.Me():GetAimVector()
			local difference = ( td.endpos - td.start ):Normalize()
			difference = difference - angle
			difference = difference:Length()
			difference = math.abs( difference * 90 )
			if( HH.InFov( v ) ) then
				table.insert( pls, v )
			end
		end
	end
	
	if( #pls > 1 ) then
		HH.LockedPlayer = HH.GetClosest( pls )
		HH.IsLocked = true
	elseif( #pls == 1 ) then
		HH.LockedPlayer = pls[1]
		HH.IsLocked = true
	else
		HH.IsLocked = false
	end
end

/*Fov Check*/
function HH.InFov( ent )
	local fov = HH.MaxAimAngle:GetInt() --Convar
	if( fov != 180 ) then
		local lpang = HH.Me():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone( HH.GetBone() ) ) - HH.Me():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

/*Los Check*/
function HH.HasLos( ply )
	local td = {} 
	td.start = HH.Me():GetShootPos()
	td.endpos = ply:GetBonePosition( ply:LookupBone( HH.GetBone() ) )
	td.mask = 1174421507
	td.filter = { HH.Me(), ply }
	
	local trace = util.TraceLine( td )
	if( trace.Fraction == 1 ) then
		return true
	end
	return false
end

/*Get Closest Target*/
function HH.GetClosest( pls )
	local pos = HH.Me():EyePos()
	local ang = HH.Me():GetAimVector()
	local returnply = { 0, 0 }
	for k, v in ipairs( pls ) do
		if( HH.IsValidPlayer( v ) ) then
			local plypos = v:GetBonePosition( v:LookupBone( HH.GetBone() ) )
			local difr = ( plypos - pos ):Normalize()
			difr = difr - ang
			difr = difr:Length()
			difr = math.abs( difr )
			if( difr < returnply[2] || returnply[1] == 0 ) then
				returnply = { v, difr }
			end
		end
	end
	return returnply[1]
end

/*Check Valid Players*/
function HH.IsValidPlayer( ply )
	if( !ValidEntity( ply ) or !( ply:IsPlayer() or ply:IsNPC() ) ) then return false end --Check if player is valid
	if( ply == HH.Me() ) then return false end --Don't target self
	if( HH.CheckLos:GetBool() and !HH.HasLos( ply ) ) then return false end --Check for Line of Sight
	if( HH.TargetNPCs:GetBool() and ply:IsNPC() ) then 
		return true 
	elseif( ply:IsNPC() ) then 
		return false 
	end
	if( ply:GetFriendStatus() == "friend" and HH.IgnoreSteamFriends:GetBool() ) then return false end --Ignore Steam friends
	if( !ply:Alive() or ply:InVehicle() or HH.Me():InVehicle() or !HH.Me():Alive() ) then return false end
	if( HH.IgnoreOwnTeam:GetBool() and ply:Team() == HH.Me():Team() ) then return false end
	if( ply:GetMoveType() == MOVETYPE_NONE ) then return false end 
	if( ply:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	if( HH.IgnoreAdmins:GetBool() and ply:IsAdmin() ) then return false end
	if( HH.OnlyTargetTraitors:GetBool() and !HH.IsTraitor( ply ) ) then return false end
		
	if( HH.FriendsBlackList:GetBool() ) then
		if( !table.HasValue( HH.Friends, ply:SteamID() )  and !HH.IgnoreFriends:GetBool() ) then
			return false
		end
	else
		if( table.HasValue( HH.Friends, ply:SteamID() ) and !HH.IgnoreFriends:GetBool() ) then
			return false
		end
	end
	
	if( HH.TeamsBlackList:GetBool() ) then
		if( !HH.IsGoodTeam( team.GetName( ply:Team() ) ) and !HH.IgnoreTeams:GetBool() ) then
			return false
		end
	else
		if( HH.IsGoodTeam( team.GetName( ply:Team() ) ) and !HH.IgnoreTeams:GetBool() ) then
			return false
		end
	end
	
	return true
end

/*Prediction*/
local weapons = {
	[ "weapon_crossbow" ] = 3110,
}

function HH.Prediction( pos , pl )
	if ValidEntity( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = HH.Me():GetPos():Distance( pl:GetPos() )
		local weapon = ( HH.Me().GetActiveWeapon and ( ValidEntity( HH.Me():GetActiveWeapon() ) and HH.Me():GetActiveWeapon():GetClass() ) )
		
		if weapon and weapons[ weapon ] then
			local time = distance / weapons[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

/*Add Friend*/
function HH.AddFriend( ply )
	if( ply:IsPlayer() and ply:IsValid() and ply != HH.Me() and !table.HasValue (HH.Friends, ply:SteamID() ) ) then
		table.insert( HH.Friends, ply:SteamID() )
		file.Write( "hemihack/hh_friends.txt", glon.encode( HH.Friends ) )
	end
end

/*Remove Friend*/
function HH.RemoveFriend( ply )
	if( ply:IsPlayer() and ply:IsValid() and ply != HH.Me() ) then
		for k, v in pairs( HH.Friends ) do
			if( string.Trim( v ) == ply:SteamID() ) then
				HH.Friends[k] = nil
			end
		end
		file.Write( "hemihack/hh_friends.txt", glon.encode( HH.Friends ) )
	end
end

/*Clear Friends*/
function HH.ClearFriendsList()
	HH.Friends = {}
	file.Write( "hemihack/hh_friends.txt", glon.encode( HH.Friends ) )
end

function HH.IsFriend( ply )
	return table.HasValue( HH.Friends, ply:SteamID() )
end

/*Add Ent*/
function HH.AddEnt( entclass )
	if( !table.HasValue( HH.CustomEnts, entclass ) ) then
		table.insert( HH.CustomEnts, entclass )
		file.Write( "hemihack/hh_ents.txt", glon.encode( HH.CustomEnts ) )
	end
end

/*Remove Ent*/
function HH.RemoveEnt( entclass )
	for k, v in pairs( HH.CustomEnts ) do
		if( string.Trim( v ) == entclass ) then
			HH.CustomEnts[k] = nil
		end
	end
	file.Write( "hemihack/hh_ents.txt", glon.encode( HH.CustomEnts ) )
end

/*Clear Ents*/
function HH.ClearEnts()
	HH.CustomEnts = {}
	file.Write( "hemihack/hh_ents.txt", glon.encode( HH.CustomEnts ) )
end

function HH.IsCustomEnt( entclass )
	return table.HasValue( HH.CustomEnts, entclass )
end

/*Add Team*/
function HH.AddTeam( teamname )
	table.insert( HH.Teams, teamname )
	file.Write( "hemihack/hh_teams.txt", glon.encode( HH.Teams ) )
end

/*Remove Team*/
function HH.RemoveTeam( teamname )
	for k, v in pairs( HH.Teams ) do
		if( string.Trim( v ) == teamname ) then
			HH.Teams[k] = nil
		end
	end
	file.Write( "hemihack/hh_teams.txt", glon.encode( HH.Teams ) )
end

function HH.IsGoodTeam( teamname )
	return table.HasValue( HH.Teams, teamname )
end

/*Clear Teams*/
function HH.ClearTeams()
	HH.Teams = {}
	file.Write( "hemihack/hh_teams.txt", glon.encode( HH.Teams ) )
end

/*Get Target Bone*/
function HH.GetBone()
	if HH.CustomBone:GetBool() then 
		return HH.TargetBone
	else
		return "ValveBiped.Bip01_Head1"
	end
end

/*Set Target Bone*/
function HH.SetBone( bone )
	if table.HasValue( HH.ValidBones, bone ) then
		HH.TargetBone = bone
		file.Write( "hemihack/hh_bone.txt", HH.TargetBone )
	end
end

/*Get Wallhack material*/
function HH:CreateMaterial()
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	
	local mat
	if( HH.WallHackSolid:GetBool() ) then
		mat = CreateMaterial( "hh_solid", "VertexLitGeneric", BaseInfo )
	else
		mat = CreateMaterial( "hh_wireframe", "Wireframe", BaseInfo )
	end   
   return mat
end

/*Esp Distance Check*/
function HH.IsCloseEnough( ent )
	local dist = ent:GetPos():Distance( HH.Me():GetPos() )
	if( dist <= HH.ESPDist:GetInt() and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

/*No Spread*/
HH.CustomCones = {}
HH.CustomCones["#HL2_SMG1"]        = Vector( -0.04362, -0.04362, -0.04362 )
HH.CustomCones["#HL2_Pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
HH.CustomCones["#HL2_Pulse_Rifle"] = Vector( -0.02618, -0.02618, -0.02618 )

function HH.PredictSpread( cmd, aimAngle )
        local cmd2, seed = HH.hl2_ucmd_getprediciton( cmd )
        local currentseed = 0, 0, 0
        if( cmd2 != 0 ) then currentseed = seed end
        local wep = HH.Me():GetActiveWeapon()
        local vecCone, valCone = Vector( 0, 0, 0 )
        if( ValidEntity( wep ) ) then
                if( wep.Initialize ) then
                        valCone = wep.Primary && wep.Primary.Cone || 0
                        if( tonumber( valCone ) ) then
                                vecCone = Vector( -valCone, -valCone, -valCone )
                        elseif( type( valCone ) == "Vector" ) then
                                vecCone = -1 * valCone
                        end
                else
                        local pn = wep:GetPrintName()
                        if( HH.CustomCones[pn] ) then vecCone = HH.CustomCones[pn] end
                end
        end
        return HH.hl2_shotmanip( currentseed || 0, ( aimAngle || HH.Me():GetAimVector():Angle() ):Forward(), vecCone ):Angle()
end

/*Ip Logging*/
HH.IPS = {}
function HH.SaveIPs()
	local s = ""
	for k,v in pairs( HH.IPS ) do
		s = s..k.."="..v.."\n"
	end
	
	if HH.LogIps:GetBool() then
		file.Write( "hemihack/hh_loggedips.txt", s )
	end
end

function HH.LoadIPs()
	if !file.Read( "hemihack/hh_loggedips.txt" ) then
		file.Write( "hemihack/hh_loggedips.txt", "" )
	end
	local tbl = string.Explode( "\n", file.Read( "hemihack/hh_loggedips.txt" ) )
	HH.IPS = {}
	for k,v  in pairs( tbl ) do
		local sep = string.Explode( "=", v )
		if sep and table.getn( sep ) == 2 then
			HH.IPS[ sep[ 1 ] ] = sep[ 2 ]
		end
	end
end
HH.LoadIPs()

/*Load Steamworks*/
function HH.IsSteamOk()
	local loaded = require( "steamworks" )
	if( !loaded ) then return false end
	local steamClient007 = steamworks.ISteamClient( 7 )
	if ( !steamClient007 ) then return false end
	local hSteamPipe = steamClient007:CreateSteamPipe()
	if ( !hSteamPipe ) then return false end
	local hSteamUser = steamClient007:ConnectToGlobalUser( hSteamPipe )
	if ( !hSteamUser ) then return false end
	local steamUser012 = steamClient007:GetISteamUser( hSteamUser, hSteamPipe, 12 )
	if ( !steamUser012 ) then return false end
	if ( !steamUser012:LoggedOn() ) then return false end
	HH.SteamUser = steamClient007:GetISteamFriends( hSteamUser, hSteamPipe, 5 )
	if ( !HH.SteamUser ) then return false end
	return true
end

HH.TGuns = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport" }
HH.Traitors = {}
local allocatedweapons = {}
local cleared = false

function HH.PrintTraitors()
	if( !HH or !HH.Loaded ) then return end
	MsgN( "----------------Traitors----------------------")
	for k , v in pairs( HH.Traitors ) do
		print( v:Nick() )
	end
	print( #HH.Traitors.." of total ".. math.floor( #player.GetAll() / 4 ).." traitors detected." )
	MsgN("-----------------------------------------------")
end
concommand.Add( "hh_printtraitors" , HH.PrintTraitors )

function HH.IsTraitor(pl)
	return table.HasValue( HH.Traitors , pl )
end

local umsg = usermessage.IncomingMessage

function usermessage.IncomingMessage( name , um , ... )
	if name == "ttt_role" and HH.ShowTraitors:GetBool() then
		print( "[HH] Clearing traitors - round end." )
		for k , v in pairs( HH.Traitors ) do
			if ValidEntity( v ) then
				Msg( string.format( "Removing traitor %s - the round has ended." , v:Nick() ), false )
			end
			HH.Traitors[k] = nil
		end
	end
	
	return umsg( name , um , ... )
end

function HH.CheckTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find( GAMEMODE.Name , "Trouble in Terror" ) or !HH.ShowTraitors then return end
	for _, pl in pairs( player.GetAll() ) do
		for k, wep in pairs( ents.GetAll() ) do
			if( ValidEntity( wep ) and wep:IsWeapon() and table.HasValue( HH.TGuns , wep:GetClass() ) ) then	
				if pl:GetPos():Distance( wep:GetPos() ) <= 36 and not table.HasValue( HH.Traitors , pl ) and !table.HasValue( allocatedweapons , wep ) and not pl:IsDetective() and pl:Alive() then
					HH.Notify( string.format( "Player %s has traitor weapon %s" , pl:Nick() , wep:GetClass() ), true )
					table.insert( HH.Traitors,  pl )
					table.insert( allocatedweapons , wep )
					cleared = false
				end
			end
		end
		if table.HasValue( HH.Traitors , pl ) and (!pl:Alive() or pl:GetMoveType() == MOVETYPE_OBSERVER ) then
			HH.Notify( string.format( "Traitor %s has died!" , pl:Nick()  ), true )
			for a , b in pairs( HH.Traitors ) do
				if b == pl then
					HH.Traitors[a] = nil
				end
			end
		end
	end
end


/*---------Hooks---------*/
  
  
 /*Player Connect*/
 function HH.PConnect( name, ip )
	if !HH.ModLoaded then return end
	if ip != "none" and string.Left( ip, 2 ) != "0." then HH.IPS[ string.gsub( name,"=", "" ) ] = ip end
	HH.SaveIPs()
	if HH.MenuCreated then
		HH.RefreshIpMenu()
	end
	
	if !HH.LogIps:GetBool() then return end
	print("")
	print( "[HH] " .. name .. " Connected from ip: " .. ip )
	print("")
end
HH.AddHook( "HHPlayerConnect", HH.PConnect )
 
 /*TriggerBot*/
function HH.TriggerBot()
    if HH.Me():Alive() and HH.Me():GetActiveWeapon():IsValid() and HH.AimbotIsOn and !HH.Me():InVehicle() and HH.AutoShoot:GetBool() then
		if ( !Firing and HH.IsLocked and HH.IsValidPlayer( HH.LockedPlayer ) ) then 
			RunConsoleCommand( "+attack" ) 
			HH.Me():GetActiveWeapon().SetNextPrimaryFire( HH.Me():GetActiveWeapon() )
			Firing = true 
		else 
			RunConsoleCommand( "-attack" ) 
			Firing = false
		end
    end
end

/*AimBot*/
function HH.AimBot( cmd )
    if( HH.AimbotIsOn ) then
        if( !HH.IsLocked or !HH.IsValidPlayer( HH.LockedPlayer ) ) then 
			HH.GetNextTarget()
			return
		end
		
		local ply = HH.LockedPlayer
		local targethead = ply:LookupBone( HH.GetBone() )
		local mepos = HH.Me():EyePos()
		local hepos = HH.Prediction( ply:GetBonePosition( targethead ), ply ) 
		
        ang = ( hepos-mepos ):Angle()
        ang.p = math.NormalizeAngle( ang.p )
        ang.y = math.NormalizeAngle( ang.y )
        ang.r = math.NormalizeAngle( ang.r )
		if( HH.NoSpreadEnabled:GetBool() and HH.CanNospread ) then
			ang = HH.PredictSpread( cmd, ang )
		end
		//HH.Me():SetEyeAngles( ang )
		cmd:SetViewAngles( ang )
    end
end

/*Name Changer*/
HH.AddTimer( 0.2, 0, function()
	if( !HH.CanDoSteamStuff ) then return end
	if( !HH.NameChanger:GetBool() ) then return end
	if( !HH.SteamUser ) then return end

	HH.SteamUser:SetPersonaName( player.GetAll()[ math.random( 1, #player.GetAll() ) ]:Nick() .. " ~" )
end )

/*SpeedHack*/
function HH.SpeedHack()
	if !HH.ModLoaded then return end
	if( HH.Speed and HH.HostTimeScale:GetFloat() == 1) then
		HH_ForceCvar( GetConVar( "host_timescale" ),  tostring( HH.SpeedHackSpeed:GetFloat() ) )
	elseif( !HH.Speed and HH.HostTimeScale:GetFloat() != 1 ) then
		HH_ForceCvar( GetConVar( "host_timescale" ),  "1" )
	end
end

local nonreloaders = { "weapon_physgun" , "gmod_tool" , "weapon_gravgun" }
/*Auto Reload*/
function HH.DoAutoReload()
    if( HH.AutoReload:GetBool() and HH.Me():Alive() and HH.Me():GetActiveWeapon():IsValid() and !table.HasValue( nonreloaders, HH.Me():GetActiveWeapon():GetClass() ) ) then
		if( HH.Me():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( HH.LastReload + 5 ) ) then
			RunConsoleCommand("+reload")
			HH.AddTimer( .01, 1, function()
				RunConsoleCommand("-reload")
			end )
			HH.LastReload = CurTime()
		end
    end
end

/*BHop*/
HH.BH.LastHop = 0
function HH.DoBhop( cmd )
	if( HH.BHop ) then
		if( HH.Me():OnGround() and HH.Me():Alive() ) then
			cmd:SetButtons( cmd:GetButtons() | IN_JUMP )
			
			if( CurTime() > HH.BH.LastHop + 0.3 ) then
				HH.BH.LastHop = CurTime()
				HH.BH.Hops = HH.BH.Hops + 1
			end
		end
	end
end
   	
/*No Recoil*/
function HH.DoNoRecoil()
	if HH.NoRecoil:GetBool() and HH.Me():GetActiveWeapon():IsValid() and HH.Me():GetActiveWeapon().Primary then
		HH.Me():GetActiveWeapon().Primary.Recoil = 0
	end
end
	
/*Client Noclip*/
function HH.DoClientNoclip( cmd )
	if( HH.ClientNoclip:GetBool() ) then
		cmd:SetForwardMove( 0 )
		cmd:SetUpMove( 0 )
		cmd:SetSideMove( 0 )
	end
end

/*Aimbot Hud*/
function HH.PaintAimbot()
	if( !HH.IsLocked and HH.AimbotIsOn ) then
		draw.SimpleText( "Looking for Target...", "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	elseif( HH.IsLocked and HH.AimbotIsOn ) then
		if( HH.LockedPlayer:IsPlayer() ) then
			draw.SimpleText( "Locked On: " .. HH.LockedPlayer:Nick() .. " (" .. HH.LockedPlayer:Health() .. " HP)", "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		else
			draw.SimpleText( "Locked On: " .. HH.LockedPlayer:GetClass(), "HHScoreboardText", ScrW()/2, ScrH()/2 + 100, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
end

/*ESP*/
function HH.ESP()
	for k, v in ipairs( player.GetAll() ) do
		if( v:Alive() && v != HH.Me() && HH.IsCloseEnough( v ) and v:Team() != TEAM_SPECTATOR ) then
			local pos = v:EyePos():ToScreen()
			local astatus = ""
			local weaponp = ""
			local rank = ""
			local wep = ""
			if( v:IsAdmin() ) then rank = " [A]" end
			if( v:IsSuperAdmin() ) then rank = " [SA]" end
			local name = v:Nick() .. rank
			
			if( ValidEntity( v:GetActiveWeapon() ) ) then
				wep = v:GetActiveWeapon():GetPrintName().." | "
				wep = string.gsub( wep, "#HL2_", "" )
				wep = string.gsub( wep, "#GMOD_", "" )
			end
			
			local color = team.GetColor(v:Team())
			local dist = math.floor( v:GetPos():Distance( HH.Me():GetPos() ) )
			if( HH.ShowPlayers:GetBool() and HH.IsCloseEnough( v ) ) then
				draw.SimpleTextOutlined( wep .. " Dist: " .. dist , "DefaultSmall", pos.x, pos.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
				draw.SimpleTextOutlined( name .. " | HP: " .. v:Health() .. " A: " .. v:Armor(), "DefaultSmall", pos.x, pos.y - 12, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
				if( HH.ShowTraitors:GetBool() and HH.IsTraitor( v ) ) then
					draw.SimpleTextOutlined( "TRAITOR!", "DefaultSmall", pos.x, pos.y - 24, Color( 255, 0, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 255, 120, 30, 165 ) )
				end
			end
		end
	end
	
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and ValidEntity( v ) and HH.IsCustomEnt( v:GetClass() ) ) then
			if( HH.IsCloseEnough( v ) and HH.ShowEnts:GetBool() ) then
				local entpos = ( v:GetPos() + Vector( 0, 0, 50 ) ):ToScreen()
				draw.SimpleTextOutlined( v:GetClass(), "DefaultSmall", entpos.x, entpos.y - 8, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
			end
		end                    
	end
end

/*Admins and Spectators*/
HH.Admins = {}
HH.Specs = {}
function HH.Info()
	if !HH.ShowAdmins:GetBool() then return end
	HH.AdminsTemp = HH.Admins 
	HH.Admins = {}
	
	local int = 0
	for k, v in ipairs( player.GetAll() ) do
		if( v:IsAdmin() or HH.IsHG and v:GetLevel() < 99 ) then
			table.insert( HH.Admins, v )
		end
	end
	
	if( #HH.Admins > #HH.AdminsTemp ) then
		local pl = {}
		for k, v in ipairs( HH.Admins ) do
			if( !table.HasValue( HH.AdminsTemp, v ) ) then
				table.insert( pl, v )
			end
		end
		
		for k, v in pairs( pl ) do
			if( v and v:IsValid() and v != HH.Me() ) then
				HH.AddTimer( 0.5, 1, function()
					HH.Notify( "Admin " .. v:Nick() .. " Joined!", true )
				end )
			end
		end
	end
	
	local txtsize = #HH.Admins * 16
	local posx = ScrW() - 200
	local posy = ScrH() - ScrH() + 15
	
	if ( #HH.Admins != 0 ) then
		draw.RoundedBoxEx( 2, posx, posy, 180, 20, HH.BaseColor, true, true, false, false )
		draw.RoundedBoxEx( 2, posx, posy + 20, 180, (txtsize + 1) + 4, Color( 0, 0, 0, 170 ), false, false, true, true )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawLine( posx, posy + 20, posx + 180, posy + 20)
		draw.SimpleText( "Admins", "HHScoreboardText", posx + 90, posy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		for k, v in pairs( HH.Admins ) do
			if( v:IsAdmin() and !v:IsSuperAdmin() ) then
				draw.SimpleText(v:Nick() .. " (A)", "Default", posx + 10, posy + 25 + int, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			elseif( v:IsSuperAdmin() ) then
				draw.SimpleText(v:Nick() .. " (SA)", "Default", posx + 10, posy + 25 + int, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			elseif( HH.IsHG and v:GetLevel() < 99 ) then
				draw.SimpleText(v:Nick() .. " (MOD)", "Default", posx + 10, posy + 25 + int, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			end
			int = int + 15
		end
	end
	
	HH.TempSpecs =  HH.Specs
	HH.Specs = {}
	for k, v in ipairs( player.GetAll() ) do
		if( v:GetObserverTarget() == HH.Me() ) then
			table.insert( HH.Specs, v )
		end        
	end
	
	if( #HH.Specs > #HH.TempSpecs ) then
		local spl = {}
		for k, v in ipairs( HH.Specs ) do
			if( !table.HasValue( HH.TempSpecs, v ) ) then
				table.insert( spl, v )
			end
		end
		
		for k, v in pairs( spl ) do
			if( v and v:IsValid() ) then
				HH.Notify( v:Nick() .. " Started Spectating you!", true )
			end
		end
	end
	
	if( #HH.Specs < #HH.TempSpecs ) then
		local saf = {}
		for k, v in ipairs( HH.TempSpecs ) do
			if( !table.HasValue( HH.Specs, v ) ) then
				table.insert( saf, v )
			end
		end
		
		for k, v in pairs( saf ) do
			if( v and v:IsValid() ) then
				HH.Notify( v:Nick() .. " Stopped Spectating you!", false )
			end
		end
	end
	
	local add = 0
    if( #HH.Specs != 0 ) then
		surface.SetFont( "Default" )
		local size = #HH.Specs * 16
		local poy = posy + txtsize + 35
		draw.RoundedBoxEx( 2, posx, poy, 180, 20, HH.BaseColor, true, true, false, false )
		draw.RoundedBoxEx( 2, posx, poy + 20, 180, (size + 1) + 4, Color( 0, 0, 0, 170 ), false, false, true, true )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawLine( posx, poy + 20, posx + 180, poy + 20)
		draw.SimpleText( "Spectators", "HHScoreboardText", posx + 90, poy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
        for k, v in pairs( HH.Specs ) do
			draw.SimpleText(v:Nick(), "Default", posx + 10, poy + 25 + add, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT )
			add = add + 15
		end
	end
	
	/*Bhop Info*/
	if( HH.BHop ) then
		local posx = ScrW() - 200
		local posy = ScrH() - ScrH()/2
		local curspeed = math.Round( HH.Me():GetVelocity():Length() )
		if( curspeed > HH.BH.MaxSpeed and HH.Me():Alive() ) then HH.BH.MaxSpeed = curspeed end
		draw.RoundedBoxEx( 2, posx, posy, 150, 20, HH.BaseColor, true, true, false, false )
		draw.RoundedBoxEx( 2, posx, posy + 20, 150, 70, Color( 0, 0, 0, 170 ), false, false, true, true )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawLine( posx, posy + 20, posx + 150, posy + 20)
		draw.SimpleText( "Bunny Hop", "HHScoreboardText", posx + 75, posy + 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Speed: " .. curspeed, "HHScoreboardText", posx + 75, posy + 27, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Max Speed: " .. HH.BH.MaxSpeed, "HHScoreboardText", posx + 75, posy + 47, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Hops: " .. math.Round( HH.BH.Hops ), "HHScoreboardText", posx + 75, posy + 67, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
	end
	
	/*Show where we are in Client Noclip*/
	if ( HH.ClientNoclip:GetBool() ) then
		local ppos = LocalPlayer():EyePos():ToScreen()
		draw.SimpleTextOutlined( "YOU ARE HERE", "HHScoreboardText", ppos.x, ppos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .6, Color( 30, 30, 30, 255 ) )
	end
end

/*Crosshair*/
function HH.CrossHair()
	if !HH.DrawCrosshair:GetBool() then return end
	local x = ScrW() / 2
	local y = ScrH() / 2
	if( HH.ThirdPerson:GetBool() and !HH.ClientNoclip:GetBool() ) then
		local pos = HH.Me():GetEyeTrace().HitPos:ToScreen()
		x = pos.x
		y = pos.y
	end
	surface.SetDrawColor( 255, 0, 0, 255 )
	local length = 15
	if( !HH.Me():InVehicle() and HH.Me():Alive() ) then
		surface.DrawLine( x - length, y, x , y )
		surface.DrawLine( x + length, y, x, y )
		surface.DrawLine( x, y - length, x, y )
		surface.DrawLine( x, y + length, x, y )
	end
end

/*Laser Eyes*/
local mat = Material("tripmine_laser")
function HH.LaserEyes()
	if( !HH.ShowLaserEyes:GetBool() ) then return end
	for k, v in pairs( player.GetAll() ) do
		if v:IsValid() then
			if v:Alive() then
				cam.Start3D( EyePos(), EyeAngles() )
					render.SetMaterial( mat )
					if( v != HH.Me() and !vgui.CursorVisible() ) then
						local pos = v:EyePos()
						local dist = pos:Distance( HH.Me():EyePos() )
						if( HH.IsCloseEnough( v ) ) then
							render.DrawBeam( pos, v:GetEyeTrace().HitPos, 30, 1, 1, Color( 255, 0, 0, 255 ) )
						end
					end
				cam.End3D()
			end
		end
	end
end

/*Wallhack*/
local function OnScreen( e )
	local a, f = self():GetAimVector():Angle() - (e:GetPos() - self():GetShootPos()):Angle(), self():GetFOV()
	return ( math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2 )
end

function HH.Wallhack()
	if( !HH.ESPEnabled:GetBool() ) then return end
	if HH.WallHackEnabled:GetBool() then
		cam.Start3D( EyePos(), EyeAngles() )
			if( HH.Chams:GetBool() ) then
				for k, v in pairs ( player.GetAll() ) do
					if( v:Alive() and v != HH.Me() and HH.IsCloseEnough( v ) and v:Team() != TEAM_SPECTATOR ) then
						local mat = HH.CreateMaterial()
						local col = team.GetColor( v:Team() )
						if( HH.ShowTraitors:GetBool() and table.HasValue( HH.Traitors , v ) ) then
							col = Color( 255, 120, 0 )
						end
						render.SuppressEngineLighting( true )
						render.SetColorModulation( ( col.r * ( 1 / 255 ) ), ( col.g * ( 1 / 255 ) ), ( col.b * ( 1 / 255 ) ) )
						SetMaterialOverride( mat )
						v:DrawModel()
						render.SuppressEngineLighting( false )
						render.SetColorModulation( 1, 1, 1 )
						SetMaterialOverride( )
						v:DrawModel()
						
						if( v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() ) then
							local wep = v:GetActiveWeapon()
							local wcol = Color( 255, 0, 0 )
							render.SuppressEngineLighting( true )
							render.SetColorModulation( ( wcol.r * ( 1 / 255 ) ), ( wcol.g * ( 1 / 255 ) ), ( wcol.b * ( 1 / 255 ) ) )
							SetMaterialOverride( mat )
							wep:DrawModel()
							render.SuppressEngineLighting( false )
							render.SetColorModulation( 1, 1, 1 )
							SetMaterialOverride()
							wep:DrawModel()
						end
					end
				end
			end
		cam.End3D()
	end
end
HH.AddHook( "RenderScreenspaceEffects", HH.Wallhack )

function HH.WallhackHelper()
	if HH.WallHackEnabled:GetBool() then
		cam.Start3D( EyePos(), EyeAngles() )
			for k, v in pairs ( player.GetAll() ) do
				if( v:Alive() and v != HH.Me() and HH.IsCloseEnough( v ) and v:Team() != TEAM_SPECTATOR ) then
					if !HH.Chams:GetBool() then 
						v:DrawModel() 					
						if( v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() ) then
							local wep = v:GetActiveWeapon()
							wep:DrawModel()
						end
					end	
				end
			end
		cam.End3D()
	end
end

local speed = HH.CNSpeed:GetInt() * ( FrameTime() / 2 ) * 100
/*Client Noclip / Thirdperson*/
function HH.CustomView( ply, pos, angles, fov )
	if( HH.ClientNoclip:GetBool() ) then
		local ang = angles:Forward()
		if HH.Me():KeyDown( IN_FORWARD ) and HH.ClientNoclip:GetBool() then
		HH.CNPos = HH.CNPos + HH.Me():GetAimVector() * speed
		end
		if HH.Me():KeyDown( IN_BACK ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos - HH.Me():GetAimVector() * speed
		end
		if HH.Me():KeyDown( IN_MOVERIGHT ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos + ang:Angle():Right() * speed
		end
		if HH.Me():KeyDown( IN_MOVELEFT ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos - ang:Angle():Right() * speed
		end
		if HH.Me():KeyDown( IN_JUMP ) and HH.ClientNoclip:GetBool() then
			HH.CNPos = HH.CNPos + Vector( 0, 0, speed )
		end
		if HH.Me():KeyDown( IN_SPEED ) and HH.ClientNoclip:GetBool() then
			speed = ( HH.CNSpeed:GetInt() * 3 * ( FrameTime() / 2 ) ) * 100
		elseif HH.Me():KeyDown( IN_DUCK ) and HH.ClientNoclip:GetBool() then
			speed = ( HH.CNSpeed:GetInt() / 3 * ( FrameTime() / 2 ) ) * 100
		else
			speed = ( HH.CNSpeed:GetInt() * ( FrameTime() / 2 ) ) * 100
		end
		
		local view = {}
		view.origin = HH.CNPos
		view.angles = angles
		view.fov = fov
		return view
	elseif( HH.ThirdPerson:GetBool() ) then
		HH.CNPos = HH.Me():EyePos()
		local view = {}
		if( HH.LeftShoulder:GetBool() ) then
			view.origin = pos - ( angles:Forward() * ( 30 + HH.ThirdDist:GetInt() ) + ( angles:Right() * 30  ) )
		else
			view.origin = pos - ( angles:Forward() * ( 30 + HH.ThirdDist:GetInt() ) - ( angles:Right() * 30  ) )
		end
		return view
	else
		HH.CNPos = HH.Me():EyePos()
		return GAMEMODE:CalcView( ply, pos, angles, fov )
	end
end
HH.AddHook( "CalcView", HH.CustomView )

/*Show Yourself*/
function HH.ShowYourSelf()
	if ( HH.ThirdPerson:GetBool() and !HH.ClientNoclip:GetBool() ) then
		return true
	end
end
HH.AddHook( "ShouldDrawLocalPlayer", HH.ShowYourSelf )

/*Anti Afk*/
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "right", "left", "duck" }
function HH.AntiAfk()
	if( HH.AntiAfkEnabled:GetBool() and #HH.Specs == 0 ) then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		HH.AddTimer( 1, 1, function() 
			RunConsoleCommand( "+"..command1 ) 
			RunConsoleCommand( "+"..command2 ) 
		end )
		HH.AddTimer( 2, 1, function() 
			RunConsoleCommand("-"..command1 ) 
			RunConsoleCommand("-"..command2 ) 
		end )
	end
end
HH.AddTimer( 10 , 0 , function() HH.AntiAfk() end )

HH.AddHook( "CreateMove", function( uc )
	HH.AimBot( uc )
	HH.DoBhop( uc )
	HH.DoNoRecoil()
	HH.DoClientNoclip( uc )
end )

HH.AddHook( "Think", function()
	HH.TriggerBot()
	//HH.AimBot()
	HH.SpeedHack()
	HH.DoAutoReload()
	HH.CheckTraitors()
end )

HH.AddHook( "PostDrawHUD", function()
	if( !HH.ESPEnabled:GetBool() ) then return end
	HH.ESP()
	HH.Info()
	HH.CrossHair()
	HH.PaintAimbot()
end )

HH.AddHook( "HUDPaint", function()
	if( !HH.ESPEnabled:GetBool() ) then return end
	HH.LaserEyes()
	HH.WallhackHelper()
end )


/*---------Console Commands---------*/


/*Aimbot*/
concommand.Add( "+hh_aim", function()
	if !HH or !HH.Loaded then return end
	HH.AimbotIsOn =  true
end )

concommand.Add( "-hh_aim", function()
	if !HH or !HH.Loaded then return end
	HH.AimbotIsOn =  false
	HH.IsLocked = false	
	RunConsoleCommand("-attack")
end )

/*Bhop*/
concommand.Add( "+hh_bhop", function()
	if !HH or !HH.Loaded then return end
	HH.BHop = true
end )

concommand.Add( "-hh_bhop", function()
	if !HH or !HH.Loaded then return end
	HH.BHop = false
end )

concommand.Add( "hh_resetbhop", function()
	if !HH or !HH.Loaded then return end
	HH.BH.MaxSpeed = 0
	HH.BH.Hops = 0
	HH.Notify( "BHop Info Reset!", false )
end )

concommand.Add( "+hh_speed", function()
	if !HH or !HH.Loaded then return end
	if !HH.ModLoaded then HH.Notify( "Module not loaded, can't speedhack!", false ) return end
	if( HH.SvCheats:GetInt() != 1 ) then
		HH_ForceCvar( GetConVar("sv_cheats"), "1" ) 
	end
	HH.Speed = true
end )

concommand.Add( "-hh_speed", function()
	if !HH or !HH.Loaded then return end
	HH.Speed = false
end )

function HH.Unload()
	if !HH or !HH.Loaded then return end
	for k, v in pairs( HH.Hooks ) do
		hook.Remove( k, v.Index )
	end
	
	for k, v in pairs( HH.Timers ) do
		timer.Remove( k )
	end
	timer.Remove( "DoFuel" )
	HH = nil
	Msg( "Hemi Hack was succesfully removed.\n" )
end

concommand.Add( "hh_unload", function()
	if !HH or !HH.Loaded then return end
	
	HH.Unload()
end )

concommand.Add( "hh_reload", function()
	Msg( "Restarting Hemi Hack... \n" )
	if( HH ) then HH.Unload() end
	LoadHH()
end )

/*---------Utilities---------*/

function HH.CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function HH.RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function HH.FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain

	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"

	famount = math.abs(HH.RoundNum(amount,decimal))
	famount = math.floor(famount)

	remain = HH.RoundNum(math.abs(amount) - famount, decimal)

	formatted = HH.CommaValue(famount)

	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end

	formatted = (prefix or "") .. formatted 

	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end

	return formatted
end

HH.AddTimer( 3, 1, function()
	HH.CanDoSteamStuff = HH.IsSteamOk()
	HH.Notify( "Succesfully Loaded!", true)
	HH.Loaded = true
end )

/*-----------------------------------------------------------------------------------------------------------Main Menu-----------------------------------------------------------------------------------------------------------*/

/*Menu*/
HH.MenuInited = false
HH.CanCloseMenu = true
HH.MenuClosed = true


function HH.DrawButton( panel )
	local w, h = panel:GetSize()
	if panel.m_bBackground then
		local col = Color( 75, 75, 75, 160 )
		if panel:GetDisabled() then
			col = Color( 25, 25, 25, 200 )
		elseif panel.Depressed or panel:GetSelected() then
			col = Color( HH.BaseColor.r, HH.BaseColor.g - 50, HH.BaseColor.b, 250 )
		elseif panel.Hovered then
			col = HH.BaseColor
		end
		draw.RoundedBox( 0, 2, 2, w - 4, h - 4, col )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end

function HH.DrawFrame( panel )
	draw.RoundedBox( 0, 0, 0, panel:GetWide(), panel:GetTall(), Color( 0, 0, 0, 240 ) )
end

/*Main*/
function HH.InitMenu()
	HH.MainMenu = vgui.Create( "DFrame" )
	HH.MainMenu:SetPos( ScrW()/2-250, ScrH()/2-200 )
	HH.MainMenu:SetSize( 500, 400 )
	HH.MainMenu:ShowCloseButton( false )
	HH.MainMenu:SetDraggable( false )
	HH.MainMenu:SetTitle( "" )
	HH.MainMenu:SetVisible( false )
	HH.MainMenu:MakePopup()
	HH.MainMenu.Paint = function()
		//draw.RoundedBox( 8, 0, 0, HH.MainMenu:GetWide(), HH.MainMenu:GetTall(), Color( 0, 0, 50, 150 ) )
		draw.RoundedBoxEx( 6, 0 , 0, HH.MainMenu:GetWide(), 53, HH.BaseColor, true, true, false, false )
		draw.RoundedBoxEx( 6, 0, 53, HH.MainMenu:GetWide(), HH.MainMenu:GetTall() - 53, Color( 0, 0, 0, 170 ), false, false, true, true )
		draw.SimpleTextOutlined( "Hemi Hack V2", "Trebuchet24", 10, 3, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
		draw.SimpleTextOutlined( "Version: " .. version .. "   Last Updated: " .. lastupdated, "default", HH.MainMenu:GetWide() - 10, HH.MainMenu:GetTall() - 2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, .6, Color( 30, 30, 30, 255 ) )
	end
	
	/*Lock Menu*/
	local Lock = vgui.Create( "DButton", HH.MainMenu )
	Lock:SetPos( HH.MainMenu:GetWide() - 80, 10 )
	Lock:SetSize( 70, 30 )
	Lock:SetText( "Lock Menu" )
	Lock.DoClick = function()
		if HH.CanCloseMenu then
			Lock:SetText( "Unlock Menu" )
			HH.CanCloseMenu = false
		else
			Lock:SetText( "Lock Menu" )
			HH.CanCloseMenu = true
		end
	end
	Lock.Paint = function()
		HH.DrawButton( Lock )
	end
	
	
	/*AimBot Menu*/
	local  AimbotMenu = vgui.Create( "DFrame" )
	AimbotMenu:SetParent( HH.MainMenu )
	AimbotMenu:SetVisible( true )
	AimbotMenu:ShowCloseButton( false )
	AimbotMenu:SetTitle( "" )
	AimbotMenu.Paint = function()
		HH.DrawFrame( AimbotMenu )
	end
	
	HH.AddCheckBox( "Auto Shoot", "hh_autoshoot", AimbotMenu, 20, 20, "Automatically Shoot when locked on." )
	HH.AddCheckBox( "Auto Reload", "hh_autoreload", AimbotMenu, 20, 45, "Automatically Reload when your ammo is depleated." )
	HH.AddCheckBox( "No Recoil", "hh_norecoil", AimbotMenu, 20, 70, "Disable Weapon recoil. (Requires respawn when you disable it)" )
	HH.AddCheckBox( "No Spread", "hh_nospread", AimbotMenu, 20, 95, "Disable Weapon Spread, bullets always hit the same spot." )
	HH.AddCheckBox( "Check for LOS", "hh_checklos", AimbotMenu, 20, 120, "Check to see if you can actually see the target." )
	HH.AddCheckBox( "Ignore Steam Friends", "hh_ignoresteamfriends", AimbotMenu, 20, 145, "Aimbot ignores your Steam Friends." )
	HH.AddCheckBox( "Ignore Admins", "hh_ignoreadmins", AimbotMenu, 20, 170, "Aimbot ignores Admins." )
	HH.AddCheckBox( "Ignore Own Team", "hh_ignoreownteam", AimbotMenu, 20, 195, "Aimbot ignores the team you are currently on." )
	HH.AddCheckBox( "Target Traitors", "hh_targettraitors", AimbotMenu, 20, 220, "Aimbot will only target Detected Traitors. (TTT)" )
	HH.AddCheckBox( "Target NPCs", "hh_targetnpcs", AimbotMenu, 20, 245, "Aimbot will target NPCs." )
	HH.AddCheckBox( "Use Custom Bone", "hh_custombone", AimbotMenu, 20, 270, "Aimbot targets the custom bone that is set. (Otherwise targets head)" )
		
	local BoneList= vgui.Create( "DMultiChoice", AimbotMenu )
	BoneList:SetPos( 20, 290 )
	BoneList:SetSize( 150, 20 )
	BoneList:SetEditable( false )
	BoneList:SetText( string.gsub( HH.TargetBone, "ValveBiped.Bip01_", "" )  )
	for k, v in pairs( HH.ValidBones ) do
		BoneList:AddChoice( string.gsub( v, "ValveBiped.Bip01_", "" ) )
	end
	BoneList.OnSelect = function( panel, index, value, data )
		HH.SetBone( "ValveBiped.Bip01_" .. value )
	end

	HH.AddSlider( "Max Aimbot Snap Angle", "hh_maxangle", AimbotMenu, 5, 180, 0, 250, 270, 200, "How far can you turn to snap to Players?"  )
	
	local OpenFriends= vgui.Create( "DButton", AimbotMenu )
	OpenFriends:SetPos( 320, 40 )
	OpenFriends:SetSize( 100, 50 )
	OpenFriends:SetText( "Edit Friends" )
	OpenFriends.DoClick = function()
		HH.FriendsMenu()
	end
	OpenFriends.Paint = function()
		HH.DrawButton( OpenFriends )
	end
	
	local OpenTeams= vgui.Create( "DButton", AimbotMenu )
	OpenTeams:SetPos( 320, 120 )
	OpenTeams:SetSize( 100, 50 )
	OpenTeams:SetText( "Edit Teams" )
	OpenTeams.DoClick = function()
		HH.TeamsMenu()
	end
	OpenTeams.Paint = function()
		HH.DrawButton( OpenTeams )
	end
	
	HH.AddCheckBox( "Ignore Friends List", "hh_ignorefriends", AimbotMenu, 320, 200, "Aimbot ignores the custom Friends List" )
	HH.AddCheckBox( "Ignore Teams List", "hh_ignoreteams", AimbotMenu, 320, 230, "Aimbot ignores the custom Teams List." )
	
	/*ESP Menu*/
	local  ESPMenu = vgui.Create( "DFrame" )
	ESPMenu:SetParent( HH.MainMenu )
	ESPMenu:SetVisible( true )
	ESPMenu:ShowCloseButton( false )
	ESPMenu:SetTitle( "" )
	ESPMenu.Paint = function()
		HH.DrawFrame( ESPMenu )
	end
	
	local OpenEnts= vgui.Create( "DButton", ESPMenu )
	OpenEnts:SetPos( 320, 100 )
	OpenEnts:SetSize( 100, 50 )
	OpenEnts:SetText( "Edit Ents" )
	OpenEnts.DoClick = function()
		HH.EntsMenu()
	end
	OpenEnts.Paint = function()
		HH.DrawButton( OpenEnts )
	end
	
	HH.AddCheckBox( "Master Switch", "hh_espenabled", ESPMenu, 20, 20, "Uncheck to disable all ESP functions." )
	HH.AddCheckBox( "Player ESP", "hh_showplayers", ESPMenu, 20, 50, "Show info about players above their heads." )
	HH.AddCheckBox( "Entity ESP", "hh_showents", ESPMenu, 20, 80, "Show Entities from the Custom Ents List." )
	HH.AddCheckBox( "Crosshair", "hh_crosshair", ESPMenu, 20, 110, "Show crosshair." )
	HH.AddCheckBox( "Admins/Spectators", "hh_showadmins", ESPMenu, 20, 140, "Show Admins/Spectators on your HUD." )
	HH.AddCheckBox( "Laser Eyes", "hh_lasereyes", ESPMenu, 20, 170, "See where people are looking." )
	HH.AddCheckBox( "Wallhack", "hh_wallhack", ESPMenu, 20, 200, "See people through walls." )
	HH.AddCheckBox( "Chams", "hh_chams", ESPMenu, 20, 230, "Dynamic coloring. (Requires Wallhack)" )
	HH.AddCheckBox( "Solid Chams", "hh_solidwallhack", ESPMenu, 20, 260, "Should Chams be solid? Otherwise Wireframe. (Requires Wallhack)" )
	
	HH.AddSlider( "ESP Distance", "hh_espdist", ESPMenu, 5, 8000, 0, 250, 270, 200, "How far can people be to see them with ESP?" )

	
	/*Misc Menu*/
	local  MiscMenu = vgui.Create( "DFrame" )
	MiscMenu:SetParent( HH.MainMenu )
	MiscMenu:SetVisible( true )
	MiscMenu:ShowCloseButton( false )
	MiscMenu:SetTitle( "" )
	MiscMenu.Paint = function()
		HH.DrawFrame( MiscMenu )
	end
	
	HH.AddCheckBox( "Client Noclip", "hh_clientnoclip", MiscMenu, 20, 20, "Clientside Noclip. No one else can see you No-Clipping, you just appear to be standing still." )
	HH.AddCheckBox( "Third Person", "hh_thirdperson", MiscMenu, 20, 50, "Enable Third Person mode." )
	HH.AddCheckBox( "TP Left Shoulder", "hh_tpleftshoulder", MiscMenu, 20, 80, "Third Person mode over your left shoulder. (Otherwise Right shoulder)" )
	HH.AddCheckBox( "Name Changer", "hh_namechanger", MiscMenu, 20, 110, "Enable Name Changer. (Changing Steam status to 'Offline' is Recommended)" )
	HH.AddCheckBox( "Anti AFK Kicker", "hh_antiafkkicker", MiscMenu, 20, 140, "Makes you move randomly every 10 seconds to spoof AFK checkers." )
	HH.AddCheckBox( "Check for Traitors (TTT)", "hh_showtraitors", MiscMenu, 20, 170, "Check for Traitors in the TTT Gamemode." )
	
	HH.AddSlider( "Client Noclip Speed", "hh_clientnoclipspeed", MiscMenu, 0, 15, 0, 250, 230, 200, "How fast does the Client Noclip go?" )
	HH.AddSlider( "Third Person Distance", "hh_thirdpersondist", MiscMenu, 0, 800, 0, 250, 190, 200, "How far away is the Third Person Mode?" )
	HH.AddSlider( "Speed Hack Speed", "hh_speedhackspeed", MiscMenu, 1, 10, 0, 250, 270, 200, "How fast is the Speed Hack?" )
	
	/*IPs*/
	local  IPMenu = vgui.Create( "DFrame" )
	IPMenu:SetParent( HH.MainMenu )
	IPMenu:SetVisible( true )
	IPMenu:ShowCloseButton( false )
	IPMenu:SetTitle( "" )
	IPMenu.Paint = function()
		HH.DrawFrame( IPMenu )
	end
	
	local IpList = vgui.Create("DListView", IPMenu )
	IpList:SetPos( 0, 20 )
	IpList:SetSize( HH.MainMenu:GetWide() - 30, HH.MainMenu:GetTall() - 96 )
	IpList:SetMultiSelect( false )
	IpList:AddColumn("Name")
	IpList:AddColumn("IP")
	IpList.DoDoubleClick = function( panel, line )
		SetClipboardText( IpList:GetLine( line ):GetValue( 2 ) )
		HH.Notify( "Ip Copied to clipboard", false )
	end
	
	IpList.OnRowRightClick = function( panel, line )
		if #IpList:GetSelected() == 0 then return end
		local dMenu = DermaMenu()
		dMenu:AddOption( "Copy Name", function()
			SetClipboardText( IpList:GetLine( line ):GetValue( 1 ) )
		end )
		dMenu:AddOption( "Copy IP", function()
			SetClipboardText( IpList:GetLine( line ):GetValue( 2 ) )
		end )
		dMenu:AddOption( "Copy Join Line", function()
			SetClipboardText( IpList:GetLine( line ):GetValue( 1 ) .. " Connected from ip: " .. IpList:GetLine( line ):GetValue( 2 ) )
		end )
		dMenu:Open()
	end
	
	local IPSearch = vgui.Create( "DTextEntry", IPMenu )
	IPSearch:SetText( "" )
	IPSearch:SetWide( 200 )
	IPSearch.OnTextChanged = function(PanelVar)
		HH.RefreshIpMenu()
	end
	
	local SearchLabel = vgui.Create( "DLabel", IPMenu )
	SearchLabel:SetText( "Search" )
	SearchLabel:SetPos( 205, 0 )
	
	local NumberLabel = vgui.Create( "DLabel", IPMenu )
	NumberLabel:SetText( table.Count( HH.IPS) .. " IPs" )
	NumberLabel:SetPos( 420, 0 )
	
	function HH.RefreshIpMenu()
		IpList:Clear()
		for k, v  in pairs( HH.IPS ) do
			if( string.find( string.lower( k ), string.lower( IPSearch:GetValue() ) ) ) then
				IpList:AddLine( k, v )
			end
		end
		NumberLabel:SetText( table.Count( HH.IPS) .. " IPs" )
	end
	HH.RefreshIpMenu()
	
	
	/*Add Tabs*/
	HH.Tabs = vgui.Create( "DPropertySheet", HH.MainMenu )
	HH.Tabs:SetPos( 10, 30 )
	HH.Tabs:SetSize( HH.MainMenu:GetWide()-20, HH.MainMenu:GetTall()-45 )
	
	local aimbottab = HH.Tabs:AddSheet( "Aimbot", AimbotMenu, "gui/silkicons/world", false, false )
	local esptab = HH.Tabs:AddSheet( "ESP", ESPMenu, "gui/silkicons/brick_add", false, false )
	local misctab = HH.Tabs:AddSheet( "Misc", MiscMenu, "gui/silkicons/folder", false, false )
	local iptab = HH.Tabs:AddSheet( "IP Logs", IPMenu, "gui/silkicons/computer", false, false )
	HH.MenuInited = true
	HH.MenuCreated = true
end

/*Friends List*/
function HH.FriendsMenu()
	local FriendPanel = vgui.Create( "DFrame" )
	FriendPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	FriendPanel:SetSize( 500, 400 )
	FriendPanel:SetTitle( "Friends List" )
	FriendPanel:SetVisible( true )
	FriendPanel:SetDraggable( false )
	FriendPanel:ShowCloseButton( true )
	FriendPanel.Paint = function()
		HH.DrawFrame( FriendPanel )
	end
	FriendPanel:MakePopup()
	
	local NonFriends = vgui.Create( "DComboBox", FriendPanel )
	NonFriends:SetPos( 20, 45 )
	NonFriends:EnableVerticalScrollbar( true )
	NonFriends:SetSize( 150, FriendPanel:GetTall() - 70 )
	NonFriends:SetMultiple( false )
	
	local Nonlabel = vgui.Create("DLabel", FriendPanel )
	Nonlabel:SetPos( 22, 30 ) 
	Nonlabel:SetColor( Color( 255, 255, 255, 255) )
	Nonlabel:SetFont("default")
	Nonlabel:SetText( "Non-Friends" )
	Nonlabel:SizeToContents()
	
	local AddFriend = vgui.Create( "DButton", FriendPanel )
	AddFriend:SetPos( FriendPanel:GetWide()/2 - 50, FriendPanel:GetTall()/2 - 65 )
	AddFriend:SetSize( 100, 30 )
	AddFriend:SetText( "Add Friend ->" )
	AddFriend.Paint = function()
		HH.DrawButton( AddFriend )
	end
	
	local Friends = vgui.Create( "DComboBox", FriendPanel )
	Friends:SetPos( FriendPanel:GetWide() - 170, 45 )
	Friends:SetSize( 150, FriendPanel:GetTall() - 70 )
	Friends:EnableVerticalScrollbar( true )
	Friends:SetMultiple( false )
	
	local flabel = vgui.Create("DLabel", FriendPanel )
	flabel:SetPos( FriendPanel:GetWide() - 168, 30 ) 
	flabel:SetColor( Color( 255, 255, 255, 255) )
	flabel:SetFont("default")
	flabel:SetText( "Friends" )
	flabel:SizeToContents()
	
	local RemoveFriend = vgui.Create( "DButton", FriendPanel )
	RemoveFriend:SetPos( FriendPanel:GetWide()/2 - 50, FriendPanel:GetTall()/2 + 25 )
	RemoveFriend:SetSize( 100, 30 )
	RemoveFriend:SetText( "<- Remove Friend" )
	RemoveFriend.Paint = function()
		HH.DrawButton( RemoveFriend )
	end
	
	HH.AddCheckBox( "Blacklist->", "hh_friendsblacklist", FriendPanel, FriendPanel:GetWide()/2 - 40, FriendPanel:GetTall()/2 - 125 )
	
	local function RefreshCombo()
		Friends:Clear()
		NonFriends:Clear()
		for k, v in pairs( player.GetAll() ) do
			if( !HH.IsFriend( v ) and v != HH.Me() ) then
				local item = NonFriends:AddItem( v:Nick() )
				NonFriends:SortByMember( 1 )
				item.pl = v
			end
		end
		
		for k, v in pairs( player.GetAll() ) do
			if( HH.IsFriend( v ) and v != HH.Me() ) then
				local item = Friends:AddItem( v:Nick() )	
				item.pl = v
			end
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", FriendPanel )
	Clear:SetPos( FriendPanel:GetWide()/2 - 45, FriendPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		HH.ClearFriendsList()
		RefreshCombo()
	end
	Clear.Paint = function()
		HH.DrawButton( Clear )
	end
	
	AddFriend.DoClick = function()
		if( #NonFriends:GetSelectedItems() != 0 ) then
			HH.Notify( "Added: " .. NonFriends:GetSelectedItems()[1].pl:Nick(), false )
			HH.AddFriend( NonFriends:GetSelectedItems()[1].pl )
			RefreshCombo()
		end
	end
	
	RemoveFriend.DoClick = function()
		if ( #Friends:GetSelectedItems() != 0 ) then
			HH.Notify( "Removed: " .. Friends:GetSelectedItems()[1].pl:Nick(), false )
			HH.RemoveFriend( Friends:GetSelectedItems()[1].pl )
			RefreshCombo()
		end
	end
end

/*Ents List*/
function HH.EntsMenu()
	local EntPanel = vgui.Create( "DFrame" )
	EntPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	EntPanel:SetSize( 500, 400 )
	EntPanel:SetTitle( "Custom Entities" )
	EntPanel:SetVisible( true )
	EntPanel:SetDraggable( false )
	EntPanel:ShowCloseButton( true )
	EntPanel.Paint = function()
		HH.DrawFrame( EntPanel )
	end
	EntPanel:MakePopup()
	
	local NonEnts = vgui.Create( "DComboBox", EntPanel )
	NonEnts:SetPos( 20, 45 )
	NonEnts:EnableVerticalScrollbar( true )
	NonEnts:SetSize( 150, EntPanel:GetTall() - 70 )
	NonEnts:SetMultiple( false )
	
	local AddEnt = vgui.Create( "DButton", EntPanel )
	AddEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 - 65 )
	AddEnt:SetSize( 100, 30 )
	AddEnt:SetText( "Add Ent ->" )
	AddEnt.Paint = function()
		HH.DrawButton( AddEnt )
	end
	
	local Added = vgui.Create( "DComboBox", EntPanel )
	Added:SetPos( EntPanel:GetWide() - 170, 45 )
	Added:SetSize( 150, EntPanel:GetTall() - 70 )
	Added:EnableVerticalScrollbar( true )
	Added:SetMultiple( false )
		
	local RemoveEnt = vgui.Create( "DButton", EntPanel )
	RemoveEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 + 25 )
	RemoveEnt:SetSize( 100, 30 )
	RemoveEnt:SetText( "<- Remove Ent" )
	RemoveEnt.Paint = function()
		HH.DrawButton( RemoveEnt )
	end
	
	local function RefreshCombo()
		NonEnts:Clear()
		Added:Clear()
		local listedn = {}
		for k, v in pairs( ents.GetAll() ) do
			if( ValidEntity( v ) and !HH.IsCustomEnt( v:GetClass() ) and !table.HasValue( listedn, v:GetClass() ) and !table.HasValue( HH.InvalidEnts, v:GetClass() ) and string.Left( v:GetClass(), 8 ) != "class C_" and string.Left( v:GetClass(), 5 ) != "func_" and string.Left( v:GetClass(), 4 ) != "env_") then
				local item = NonEnts:AddItem( v:GetClass() )
				item.ent = v
				table.insert( listedn, v:GetClass() )
			end
		end
		
		local listeda= {}
		for k, v in pairs( HH.CustomEnts ) do
			local item = Added:AddItem( v )
			item.ent = v
			table.insert( listeda, v )
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", EntPanel )
	Clear:SetPos( EntPanel:GetWide()/2 - 45, EntPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		HH.ClearEnts( )
		RefreshCombo()
	end
	Clear.Paint = function()
		HH.DrawButton( Clear )
	end
	
	AddEnt.DoClick = function()
		if( #NonEnts:GetSelectedItems() != 0 ) then
			HH.Notify( "Added: " .. NonEnts:GetSelectedItems()[1].ent:GetClass(), false )
			HH.AddEnt( NonEnts:GetSelectedItems()[1].ent:GetClass() )
			RefreshCombo()
		end
	end
	
	RemoveEnt.DoClick = function()
		if( #Added:GetSelectedItems() != 0 ) then
			HH.Notify( "Removed: " .. Added:GetSelectedItems()[1].ent, false )
			HH.RemoveEnt( Added:GetSelectedItems()[1].ent )
			RefreshCombo()
		end
	end
end

function HH.TeamsMenu()
	local TeamPanel = vgui.Create( "DFrame" )
	TeamPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	TeamPanel:SetSize( 500, 400 )
	TeamPanel:SetTitle( "Team List" )
	TeamPanel:SetVisible( true )
	TeamPanel:SetDraggable( false )
	TeamPanel:ShowCloseButton( true )
	TeamPanel.Paint = function()
		HH.DrawFrame( TeamPanel )
	end
	TeamPanel:MakePopup()
	
	local NonEnts = vgui.Create( "DComboBox", TeamPanel )
	NonEnts:SetPos( 20, 45 )
	NonEnts:EnableVerticalScrollbar( true )
	NonEnts:SetSize( 150, TeamPanel:GetTall() - 70 )
	NonEnts:SetMultiple( false )
	
	local AddEnt = vgui.Create( "DButton", TeamPanel )
	AddEnt:SetPos( TeamPanel:GetWide()/2 - 50, TeamPanel:GetTall()/2 - 65 )
	AddEnt:SetSize( 100, 30 )
	AddEnt:SetText( "Add Team ->" )
	AddEnt.Paint = function()
		HH.DrawButton( AddEnt )
	end
	
	local Added = vgui.Create( "DComboBox", TeamPanel )
	Added:SetPos( TeamPanel:GetWide() - 170, 45 )
	Added:SetSize( 150, TeamPanel:GetTall() - 70 )
	Added:EnableVerticalScrollbar( true )
	Added:SetMultiple( false )
		
	local RemoveEnt = vgui.Create( "DButton", TeamPanel )
	RemoveEnt:SetPos( TeamPanel:GetWide()/2 - 50, TeamPanel:GetTall()/2 + 25 )
	RemoveEnt:SetSize( 100, 30 )
	RemoveEnt:SetText( "<- Remove Team" )
	RemoveEnt.Paint = function()
		HH.DrawButton( RemoveEnt )
	end
	
	HH.AddCheckBox( "Blacklist->", "hh_teamsblacklist", TeamPanel, TeamPanel:GetWide()/2 - 40, TeamPanel:GetTall()/2 - 125 )
	
	local function RefreshCombo()
		NonEnts:Clear()
		Added:Clear()
		for k, v in pairs( team.GetAllTeams() ) do
			if( !HH.IsGoodTeam( team.GetName( k ) ) ) then
				local item = NonEnts:AddItem( team.GetName( k ) )
				item.t = k
			end
		end
		
		for k, v in pairs( team.GetAllTeams() ) do
			if( HH.IsGoodTeam( team.GetName( k ) ) ) then
				local item = Added:AddItem( team.GetName( k ) )
				item.t = k
			end
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", TeamPanel )
	Clear:SetPos( TeamPanel:GetWide()/2 - 45, TeamPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		HH.ClearTeams( )
		RefreshCombo()
	end
	Clear.Paint = function()
		HH.DrawButton( Clear )
	end
	
	AddEnt.DoClick = function()
		if( #NonEnts:GetSelectedItems() != 0 ) then
			HH.Notify( "Added: " .. team.GetName( NonEnts:GetSelectedItems()[1].t ), false )
			HH.AddTeam( team.GetName( NonEnts:GetSelectedItems()[1].t ) )
			RefreshCombo()
		end
	end
	
	RemoveEnt.DoClick = function()
		if( #Added:GetSelectedItems() != 0 ) then
			HH.Notify( "Removed: " .. team.GetName( Added:GetSelectedItems()[1].t ), false )
			HH.RemoveTeam( team.GetName( Added:GetSelectedItems()[1].t ) )
			RefreshCombo()
		end
	end
end

function HH.AddCheckBox( text, cvar, parent, x, y, tt )
	local checkbox = vgui.Create( "DCheckBoxLabel" )
	checkbox:SetPos( x, y )
	checkbox:SetText( text )
	checkbox:SetConVar( cvar )
	checkbox:SetParent( parent )
	checkbox:SetTooltip( tt or "No Tool Tip" )
	checkbox:SizeToContents()	
end

function HH.AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
	local slider = vgui.Create( "DNumSlider" )
	slider:SetParent( parent )
	slider:SetPos( x, y )
	slider:SetWide( wide )
	slider:SetText( text )
	slider:SetMin( min ) 
	slider:SetMax( max ) 
	slider:SetDecimals( decimals ) 
	slider:SetConVar( cvar )
	slider:SetTooltip( tt or "No Tool Tip" )
end


/*---------Console Commands---------*/

HH.AddHook( "Think", function()
	if HH.MenuClosed and HH.CanCloseMenu then
		HH.MainMenu:SetVisible( false )
	else
		HH.MainMenu:SetVisible( true )
	end
end )

concommand.Add( "+hh_menu", function()
	if( !HH or !HH.Loaded ) then return end
	HH.MenuClosed = false
	//HH.MainMenu:SetVisible( true )
end )

concommand.Add( "-hh_menu", function()
	if( !HH or !HH.Loaded ) then return end
	HH.MenuClosed = true
    //HH.MainMenu:SetVisible( false )
end )



/*-----------------------------------------------------------------------------------------------------------PERP STUFF-----------------------------------------------------------------------------------------------------------*/

function HH.RunPerp()

HH.ShowDruggy = CreateClientConVar( "hh_perp_showdruggy", "1", false, false )
HH.InfinateFuel = CreateClientConVar( "hh_perp_infinatefuel", "1", false, false )
HH.ShowWeed = CreateClientConVar( "hh_perp_showweedtimers", "1", false, false )
HH.ShowHP = CreateClientConVar( "hh_perp_showhp", "1", false, false )
HH.ShowRpNames = CreateClientConVar( "hh_perp_showrpnames", "1", false, false )
HH.ShowJoinNotices = CreateClientConVar( "hh_perp_joinleave", "1", false, false )

local WeedGrowTime = 60 * 20 -- 10 Mins
HH.IsHG = false
if( string.Left( GetHostName(), 4 ) == "[HG]" ) then
	HH.IsHG = true
end
HH.IsUn = false
if( string.Left( GetHostName(), 6 ) == "Unleas" ) then
	HH.IsUn = true
end

/*Druggy*/
function HH.DrawDruggy()
	local buying = GetGlobalInt( 'perp_druggy_buy', 0 )
	local selling = GetGlobalInt( 'perp_druggy_sell', 0 )
	
	local cantrobbank = GetGlobalBool('perp_bank_robbing_timer')
	local moneyinbank = GetGlobalInt('perp_realtor_money')
	if( HH.IsHG ) then
		buying = GetSharedInt( 'perp_druggy_buy' )
		selling = GetSharedInt( 'perp_druggy_sell' )
		cantrobbank = GetSharedBool('perp_bank_robbing_timer')
		moneyinbank = GetSharedInt('perp_realtor_money')
	end
	
	
	if( HH.ShowDruggy:GetBool() ) then
		local posx = 17
		local posy = 15
		draw.RoundedBoxEx( 2, posx , posy, 122, 20, HH.BaseColor, true, true, false, false )
		draw.RoundedBoxEx( 2, posx, posy + 20, 122, 40, Color( 0, 0, 0, 170 ), false, false, true, true )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawLine( posx , posy + 20, posx + 122, posy + 20)
		draw.SimpleText("Druggy", "ScoreboardText", posx + 61, posy + 1, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		if !HH.IsHG and !HH.IsUn then
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ScoreboardText", posx + 61, posy + 22, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		else
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Muscle",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ScoreboardText", posx + 61, posy + 22, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
		end
		
		if !HH.IsHG and !HH.IsUn then
			local sellingtbl = {
				"Selling Weed",
				"Selling Shrooms",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ScoreboardText", posx + 61, posy + 42, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		else
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ScoreboardText", posx + 61, posy + 42, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		end

		if( moneyinbank != 0 ) then
			draw.RoundedBoxEx( 2, posx , posy + 65, 122, 20, HH.BaseColor, true, true, false, false )
			draw.RoundedBoxEx( 2, posx, posy + 85, 122, 40, Color( 0, 0, 0, 170 ), false, false, true, true )
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawLine( posx , posy + 85, posx + 122, posy + 85)
			
			draw.SimpleText( "Bank", "ScoreboardText", posx + 61, posy + 66, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
			draw.SimpleText( HH.FormatNum( moneyinbank, 0, "$" ) .. " in bank", "ScoreboardText", posx + 61, posy + 87, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			if( cantrobbank ) then
				draw.SimpleText( "Can't Rob", "ScoreboardText", posx + 61, posy + 107, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			else
				draw.SimpleText( "ROB!", "ScoreboardText", posx + 61, posy + 107, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			end
		end
		draw.SimpleText( HH.FormatNum( HH.Me():GetBank(), 2, "$" ) .. " In your bank", "ScoreboardText", posx, posy + 145, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
	end
end

/*Infinate Fuel*/
timer.Remove( "DoFuel" )
timer.Create( "DoFuel", 5, 0, function()
	if( !HH.InfinateFuel:GetBool() ) then
		DoFuel()
	end
end )

/*Weed Timer Paint*/
function HH.WeedPaint()
	if( HH.ShowWeed:GetBool() ) then
		local plants = {}
		for k, ent in pairs( ents.FindByClass("ent_pot") ) do
			table.insert( plants, ent )
		end
		for k, ent in pairs( ents.FindByClass("ent_coca") ) do
			table.insert( plants, ent )
		end
		local col = nil
		for k, ent in pairs( plants ) do
			local pos = ent:GetPos() + Vector(0, 0, 10)
			local ang = ent:GetAngles()
			local drawpos = pos:ToScreen()
			local timeleft = 85564
			if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
			if( ent.dt != nil ) then
				timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
			elseif( ent:GetTable().SpawnTime != nil ) then
				timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
			end
			if( HH.Me():GetShootPos():Distance( pos ) <= HH.ESPDist:GetInt() ) then
				if( timeleft > 1 and timeleft != 85564 ) then
					draw.SimpleText( HH.ConvertTime( timeleft ) , "MenuLarge", drawpos.x, drawpos.y, col )
				elseif( timeleft != 85564 ) then
					draw.SimpleText( "DONE!", "MenuLarge", drawpos.x, drawpos.y, Color( 0, 250, 0 ) )
				end
			end
		end
	end
end

/*ConvertTime*/
function HH.ConvertTime(sSeconds)
	local nSeconds = tonumber(sSeconds)
	if nSeconds <= 0 then
			return 0;
		else
			local nHours = string.format("%02.f", math.floor(nSeconds/3600));
			local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
			local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
		if tonumber( nHours ) > 0 then
			return nHours..":"..nMins..":"..nSecs
		elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
			return nMins..":"..nSecs
		elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
			return nMins..":"..nSecs
		end
	end
end

/*Numeric Health*/
function HH.NumericHealth()
	if( HH.ShowHP:GetBool() ) then
		draw.SimpleText( "HP: " .. HH.Me():Health(), "Trebuchet22", 150, 20, Color( 255, 255, 255 ) )
	end
end

/*RP Name ESP*/
function HH.RPNames()
	if( HH.ShowRpNames:GetBool() ) then
		for k, v in pairs( player.GetAll() ) do
			if( HH.IsCloseEnough( v ) and v != HH.Me() ) then
				local pos = v:EyePos():ToScreen()
				local name = v:GetRPName() or "ERROR"
				local color = team.GetColor( v:Team() )
				local arrest = false
				if( HH.IsHG ) then
					arrest = false or v:GetSharedBool( "warrent", false )
				else
					arrest = false or v:GetNetworkedBool( "warrent", false )
				end
				if HH.ShowPlayers:GetBool() then
					if( v:Alive() ) then
						if( arrest ) then
							draw.SimpleTextOutlined( name .. " [WARRENT]", "DefaultSmall", pos.x, pos.y - 24, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
						else
							draw.SimpleTextOutlined( name, "DefaultSmall", pos.x, pos.y - 24, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )
						end
					else
						draw.SimpleTextOutlined( name .. " *Dead*", "DefaultSmall", pos.x, pos.y - 24, Color(169,169,169, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, .6, Color( 30, 30, 30, 165 ) )
					end
				end
			end
		end
	end
end

/*Perp HudPaint*/
HH.AddHook( "PostDrawHUD", function()
	if( !HH.ESPEnabled:GetBool() ) then return end
	HH.NumericHealth()
	HH.RPNames()
	HH.WeedPaint()
	HH.DrawDruggy()
end )

/*Join Leave Notices*/
HH.AddHook( "ChatText", function( playerindex, playername, text, messagetype )
	if messagetype == "joinleave" and  HH.ShowJoinNotices:GetBool() and HH.ESPEnabled:GetBool() then
		AddNotify( text, 1, 5, true )
		return true
	end
end )

/*Init the Menu*/
HH.CreateMenu()

end -- End PERP Stuff

/*-----------------------------------------------------------------------------------------------------------PERP Menu-----------------------------------------------------------------------------------------------------------*/

/*Main Menu*/
function HH.InitPerpMenu()
	HH.PerpMenu = vgui.Create( "DFrame" )
	HH.PerpMenu:SetParent( HH.MainMenu )
	HH.PerpMenu:SetVisible( true )
	HH.PerpMenu:ShowCloseButton( false )
	HH.PerpMenu:SetTitle( "" )
	HH.PerpMenu.Paint = function()
		if( HH.PerpMenu ) then
			HH.DrawFrame( HH.PerpMenu )
		end
	end
	
	local PerpWarning = vgui.Create( "DLabel", HH.PerpMenu )
	PerpWarning:SetPos( 90, 100 )
	PerpWarning:SetColor( Color( 150, 0, 0, 255 ) )
	PerpWarning:SetSize( 300, 80 )
	PerpWarning:SetFont( "ScoreboardText" )
	PerpWarning:SetText( "If you are not on a perp gamemode and you push the button below, you may be spammed with errors!" )
	PerpWarning:SetWrap( true )
	
	local RunPerpButton= vgui.Create( "DButton", HH.PerpMenu )
	RunPerpButton:SetPos( 180, 200 )
	RunPerpButton:SetSize( 100, 50 )
	RunPerpButton:SetText( "Run Perp Hack" )
	RunPerpButton.Paint = function()
		HH.DrawButton( RunPerpButton )
	end
	RunPerpButton.DoClick = function()
		RunPerpButton:SetEnabled( false )
		RunPerpButton:SetVisible( false )
		PerpWarning:SetVisible( false )
		HH.RunPerp()
	end
	
	HH.Tabs:AddSheet( "PERP", HH.PerpMenu, "gui/silkicons/car", false, false )
end

function HH.CreateMenu()
	HH.AddCheckBox( "Show Info", "hh_perp_showdruggy", HH.PerpMenu, 20, 20, "Show Druggy Stock and Bank Amount." )
	HH.AddCheckBox( "Infinite Fuel in cars", "hh_perp_infinatefuel", HH.PerpMenu, 20, 50, "Cars will never lose fuel." )
	HH.AddCheckBox( "Show Plant Timers", "hh_perp_showweedtimers", HH.PerpMenu, 20, 80, "Show timers on Weed/Cocaine." )
	HH.AddCheckBox( "Show Numeric Health", "hh_perp_showhp", HH.PerpMenu, 20, 110, "Show your health as a number." )
	HH.AddCheckBox( "RP Name ESP", "hh_perp_showrpnames", HH.PerpMenu, 20, 140, "Show Players RP Names in the Player ESP." )
	HH.AddCheckBox( "Show Join Leave Notices", "hh_perp_joinleave", HH.PerpMenu, 20, 170, "Show notices when people Join/Leave the game." )
	
	local PerpPlayers= vgui.Create( "DButton", HH.PerpMenu )
	PerpPlayers:SetPos( 320, 100 )
	PerpPlayers:SetSize( 100, 50 )
	PerpPlayers:SetText( "Open Player List" )
	PerpPlayers.DoClick = function()
		HH.PerpPlayersMenu()
	end
	PerpPlayers.Paint = function()
		HH.DrawButton( PerpPlayers )
	end
	
	local NoWeather= vgui.Create( "DButton", HH.PerpMenu )
	NoWeather:SetPos( 250, 250 )
	NoWeather:SetSize( 175, 50 )
	NoWeather:SetText( "No Weather (Can't be reversed)" )
	NoWeather:SetEnabled( true )
	NoWeather.DoClick = function()
		hook.Remove( "Think", "weatherThink" )
		if( HH.IsHG ) then
			hook.Remove("PostDrawTranslucentRenderables", "GM.RenderLights")
		end
		NoWeather:SetEnabled( false )
	end
	NoWeather.Paint = function()
		HH.DrawButton( NoWeather )
	end
end

/*Names Menu*/
function HH.PerpPlayersMenu()
	local MainFrame = vgui.Create( "DFrame" )
	MainFrame:SetPos( ScrW()/2-500, ScrH()/2-250 )
	MainFrame:SetSize( 1000, 500 )
	MainFrame:SetTitle( "Perp Player Info" )
	MainFrame:SetVisible( true )
	MainFrame:SetVerticalScrollbarEnabled( true )
	MainFrame:SetDraggable( false )
	MainFrame:ShowCloseButton( true )
	MainFrame:MakePopup()
	
	local NamesList = vgui.Create("DListView", MainFrame )
	NamesList:SetPos( 20, 40 )
	NamesList:SetSize( MainFrame:GetWide() - 40, MainFrame:GetTall() - 60 )
	NamesList:SetMultiSelect( false )
	NamesList:AddColumn("Steam Name")
	NamesList:AddColumn("PERP Name")
	NamesList:AddColumn("Steam ID")
	NamesList:AddColumn("Org")
	NamesList:AddColumn("Team")
	NamesList:AddColumn("Status")
	NamesList:AddColumn("Access")
	NamesList.OnRowRightClick = function( panel, line )
		local dMenu = DermaMenu()
		dMenu:AddOption( "Copy Steam Name", function()
			SetClipboardText( NamesList:GetLine( line ):GetValue( 1 ) )
		end )
		dMenu:AddOption( "Copy PERP Name", function()
			SetClipboardText( NamesList:GetLine( line ):GetValue( 2 ) )
		end )
		dMenu:AddOption( "Copy SteamID", function()
			SetClipboardText( NamesList:GetLine( line ):GetValue( 3 ) )
		end )
		dMenu:AddOption( "Copy Org Name", function()
			SetClipboardText( NamesList:GetLine( line ):GetValue( 4 ) )
		end )
		dMenu:Open()
	end
	 
	for k,v in pairs(player.GetAll()) do
		local alive = "Alive"
		local rpname = v:GetRPName() or "ERROR"
		local orgname = v:GetOrganizationName()
		local access = LevelToString( v:GetLevel() )
		if( !v:Alive() ) then
			alive = "Dead"
		end
		NamesList:AddLine( v:Nick(), rpname, v:SteamID(), orgname, team.GetName( v:Team() ), alive, access )
	end
end

HH.InitMenu()
HH.InitPerpMenu()

end --LoadHH()

LoadHH()