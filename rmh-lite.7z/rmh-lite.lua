--[[
----------  ----------  ----------      -        -  ------------
-        -  -        -          -       -        -            -
-        -  -        -        -         -        -            -
-        -  -        -       -          -        -            -
----------  ----------      -           -        -            -    (Alpha)    
-  -        -        -     -            -        -            -
-    -      -        -    -             -        -            -
-      -    -        -   -               -      -             -
-        -  -        -  ----------        ------         ---------

-A GMod Multihack-

-[ LITE VERSION ]-

Coded by Razor
Release Date: 06/09/2014
Special Thanks:
Bobby aka. Tom (Testing everything i make [Bobby you little faggy:p])
Marten (Testing my stuff)
Jack the Ripper aka. MrFramesHunter (Good Friend and testing my stuff)
Others i don't remember now
]]

--[[ 
Timer function
Useless, just wanted to see if the hack loads in under 1 second
]]

local timer = timer

local finin1sec = false

timer.Simple(1, function()
	if (finin1sec) then
		print("We loaded in under 1 Second!")
	else
		print("We didn't load in under 1 Seconds!")
	end
end)

--[[
Localizing
Makes Cheat run faster
]]

local CreateClientConVar = CreateClientConVar
local ChatPrint = ChatPrint
local concommand = concommand	
local GetConVarNumber = GetConVarNumber
local hook = hook
local GetConVarString = GetConVarString
local raz = {}
local LocalPlayer = LocalPlayer
local player = player
local ents = ents
local ScrW = ScrW
local ScrH = ScrH
local require = require
local pairs = pairs
local cam = cam
local render = render
local cvars = cvars
local surface = surface
local table = table
local math = math
local print = print
local include = include
local Vector = Vector
local Angle = Angle
local GetEyeTrace = GetEyeTrace
local Entity = Entity
local ConCommand = ConCommand
local RunConsoleCommand = RunConsoleCommand
local vgui = vgui
local CurTime = CurTime

--[[
Require DLL's
Load CVAR3 and stuff
]]

require("cvar3")

--[[
Tables
Tables with required informations
]]

raz.cvars = {
	{ Name = "raz_bhop", Value = 0 },
	{ Name = "raz_esp", Value = 0 },
	{ Name = "raz_propwh", Value = 0 },
	{ Name = "raz_rapidfire", Value = 0 },
	{ Name = "raz_rpgod", Value = 0 },
	{ Name = "raz_triggerbot", Value = 0 },
	{ Name = "raz_chatspam", Value = 0 },
	{ Name = "raz_chatspam_msg", Value = "swag"},
	{ Name = "raz_fov", Value = 90 },
	{ Name = "raz_fov_enable", Value = 0 },
	{ Name = "raz_traitorfinder", Value = 0 },
	{ Name = "raz_speedhack_speed",  Value = 5 },
	{ Name = "raz_fspam", Value = 0 },
	{ Name = "raz_radius", Value = 25000 },
	{ Name = "raz_spinme", Value = 0 },
	{ Name = "raz_supportme", Value = 0 },  
	{ Name = "raz_entesp", Value = 0 }
}
	


raz.devs = {
	"STEAM_0:1:40744642"
}

raz.version = "1.0 (LITE)"

--[[
Fonts
]]

surface.CreateFont("menufont12", {
	font = "Arial",
	size = 12,
	weight = 500,
	antialias = 1
})

--[[
Functions
Hook Add functions and stuff
]]

local function AddHook(Type, name, Function)
	hook.Add(Type, name, Function)
end

local function RemoveHook(Type, name)
	hook.Remove(Type, name)
end

local function AddConvar(Name, Value)
	CreateClientConVar(Name, Value)
end

local function ForceVar(use,less,args)
	GetConVar(args[1]):SetValue(args[2])
end

local function ForceVarAlt(var, value)
	GetConVar(var):SetValue(value)
end


--[[
Get Gamemode
Get Servers gamemode
]]

local function GetServerGameMode()
	print("This server is running the gamemode "..GAMEMODE.Name..".")
end

--[[
If Visible Functions and stuff
]]


local function InDist(v)
	local dist = v:GetPos():Distance(LocalPlayer():GetPos())
	if dist < GetConVarNumber("raz_radius") then
		return true
	end
	return false
end



--[[
Get Admin Status
Return Admin Status
]]

local function CheckAdmin(e)
	if e:IsAdmin() and !(e:IsSuperAdmin()) then
		return " Admin "
	end
	if e:IsSuperAdmin() then
		return " Superadmin "
	end
	return " "
end

--[[
Create ConVars
]]

local function CreateConVars()
	for k,v in pairs(raz.cvars) do
		AddConvar(v.Name, v.Value)
	end
end

CreateConVars()


concommand.Add("raz_forcevar", ForceVar)


--[[
Razor Dev
Check's if a razor dev is on
]]


local function checkrazor()
	for k,v in pairs(player.GetAll()) do
		if table.HasValue(raz.devs, v:SteamID()) and !(v.IsDev) then
			LocalPlayer():ChatPrint("Razor Dev is on the server: "..v:Name())
			v.IsDev = true
		end
	end
end



AddHook("Think", "checkdev", checkrazor)

--[[
BHOP
]]

local shalljump = true

local function bhop()
	if LocalPlayer():IsTyping() then
		return
	end
	if LocalPlayer():IsOnGround() and input.IsKeyDown(KEY_SPACE) and (shalljump) then
		RunConsoleCommand("+jump")
		shalljump = false
	elseif !(LocalPlayer():IsOnGround()) and input.IsKeyDown(KEY_SPACE) and !(shalljump) then
		RunConsoleCommand("-jump")
		shalljump = true
	elseif LocalPlayer():IsOnGround() and !(input.IsKeyDown(KEY_SPACE)) then
		RunConsoleCommand("-jump")
		shalljump = false
	end
end

if GetConVarNumber("raz_bhop") == 1 then
	AddHook("Think", "BunnyHop", bhop)
end

cvars.AddChangeCallback("raz_bhop", function()
	if GetConVarNumber("raz_bhop") == 1 then
		AddHook("Think", "BunnyHop", bhop)
	else
		RemoveHook("Think", "BunnyHop")
	end
end)

--[[
ESP
]]

local function BoxEsp()
	
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) then
			local min,max = v:WorldSpaceAABB()
			local diff = max-min
			local pos2 = Vector(0,0,0)
			local pos1 = Vector(0,0,0)
			local pos3 = Vector(0,0,0)
			local pos4 = Vector(0,0,0)
			local pos5 = Vector(0,0,diff.z)
			local pos6 = Vector(0,0,diff.z)
			local pos7 = Vector(0,0,diff.z)
			local pos8 = Vector(0,0,diff.z)

			pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			
			surface.SetDrawColor(0,0,255,255)			
			surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y)
			surface.DrawLine(pos2.x, pos2.y, pos3.x, pos3.y)
			surface.DrawLine(pos3.x, pos3.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos3.x, pos3.y)
			surface.DrawLine(pos2.x, pos2.y, pos4.x, pos4.y)
			
			surface.SetDrawColor(team.GetColor(v:Team()))
			
			surface.DrawLine(pos1.x, pos1.y, pos5.x, pos5.y)
			surface.DrawLine(pos2.x, pos2.y, pos6.x, pos6.y)
			surface.DrawLine(pos3.x, pos3.y, pos7.x, pos7.y)
			surface.DrawLine(pos4.x, pos4.y, pos8.x, pos8.y)
			
			surface.SetDrawColor(90,20,50,255)	
			
			surface.DrawLine(pos5.x, pos5.y, pos6.x, pos6.y)
			surface.DrawLine(pos6.x, pos6.y, pos7.x, pos7.y)
			surface.DrawLine(pos7.x, pos7.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos7.x, pos7.y)
			surface.DrawLine(pos6.x, pos6.y, pos8.x, pos8.y)
			
		end
	end
end


if GetConVarNumber("raz_esp") == 1 then
	AddHook("HUDPaint", "boxesp", BoxEsp)
end

cvars.AddChangeCallback("raz_esp", function()
	if GetConVarNumber("raz_esp") == 1 then
		AddHook("HUDPaint", "boxesp", BoxEsp)
	else
		RemoveHook("HUDPaint", "boxesp")
	end
end)

local function propwh()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics" and v:IsValid() and InDist(v) then
			cam.Start3D()
				v:SetMaterial("models/wireframe")
				local col = Color(255, 93, 0, 255) 
				render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
				render.SetBlend(col.a / 255)
				v:DrawModel()
			cam.End3D()
		elseif v:GetClass() == "prop_physics" and v:IsValid() and !(InDist(v)) then
			cam.Start3D()
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			end
		end
	end


if GetConVarNumber("raz_propwh") == 1 then
	AddHook("HUDPaint", "PropWH", propwh)
end

cvars.AddChangeCallback("raz_propwh", function()
	if GetConVarNumber("raz_propwh") == 1 then
		AddHook("HUDPaint", "PropWH", propwh)
	else
		RemoveHook("HUDPaint", "PropWH")
		cam.Start3D()
		for k,v in pairs(ents.GetAll()) do
			if v:IsValid() and v:GetClass() == "prop_physics" then
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			end
		end
		cam.End3D()
	end
end)

local function espinfo()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) then
			local Position = ( v:GetPos() + Vector( 0,0,60 ) ):ToScreen()
			local Position2 = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Position3 = ( v:GetPos() + Vector( 0,0,100 ) ):ToScreen()
			local Position4 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local Position5 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local pname = " "
			if v:Health() > 0 and v:GetActiveWeapon():IsValid() and v:GetActiveWeapon() then
				pname = v:GetActiveWeapon():GetPrintName()
			else
				pname = ""
			end
			draw.SimpleText(v:Name(), "Default",Position.x, Position.y, Color(0,255,0,255), 1) 
			draw.SimpleText("Health: "..v:Health(), "Default", Position2.x, Position2.y, Color(150,0,255,255), 1)
			draw.SimpleText("Weapon: "..pname, "Default",  Position3.x, Position3.y, Color(0,0,255,255), 1)
			if v:GetFriendStatus() == "friend" then
				draw.SimpleText("FRIEND", "Default",  Position4.x, Position4.y, Color(150,255,150,255), 1)
			end
			if table.HasValue(raz.devs, v:SteamID()) then
				draw.SimpleText("Razor Dev", "Default",  Position5.x, Position5.y, Color(255,255,255,255), 1)
			end
		end
	end
end

if GetConVarNumber("raz_esp") == 1 then
	AddHook("HUDPaint", "Info", espinfo)
end

cvars.AddChangeCallback("raz_esp", function()
	if GetConVarNumber("raz_esp") == 1 then
		AddHook("HUDPaint", "Info", espinfo)
	else
		RemoveHook("HUDPaint", "Info")
	end
end)


--[[
Remove Skybox
]]

local function RemoveSkybox()
	if GetConVarNumber("gl_clear") == 0 then
		ForceVarAlt("gl_clear", 1)
		ForceVarAlt("r_drawskybox", 0)
		ForceVarAlt("r_3dsky",0)
	else
		ForceVarAlt("gl_clear", 0)
		ForceVarAlt("r_drawskybox", 1)
		ForceVarAlt("r_3dsky",1)
	end
end

concommand.Add("raz_removeskybox", RemoveSkybox)


--[[
Thirdperson
]]

inthirdperson = false

local function thirdperson()
	if !(inthirdperson) then
		ForceVarAlt("sv_cheats", 1)
		timer.Simple(0.05, function()
		RunConsoleCommand("thirdperson")
		end)
		inthirdperson = true
	else
		ForceVarAlt("sv_cheats", 1)
		timer.Simple(0.05, function()
		RunConsoleCommand("firstperson")
		end)
		timer.Simple(0.1, function()
		ForceVarAlt("sv_cheats", 0)
		end)
		inthirdperson = false
	end
end

concommand.Add("raz_thirdperson", thirdperson)
	
--[[
Warning when admin on
]]

tracked = {}

local function warning()
	for k,v in pairs(player.GetAll()) do
		if !(table.HasValue(tracked, v)) then
			if v:IsAdmin() and !(v:IsSuperAdmin()) then
				table.insert(tracked, v)
				LocalPlayer():ChatPrint(v:Name().." is an Admin!")
			elseif v:IsSuperAdmin() then
				LocalPlayer():ChatPrint(v:Name().." is a Super Admin!")
				table.insert(tracked, v)
			end
		end
	end
end

AddHook("Think", "adminwarning", warning)

--[[
Rapid Fire
]]

local function rapidfire()
	if !(LocalPlayer():IsTyping()) then
		if !(doit) then
			RunConsoleCommand("-attack")
		end
		if input.IsMouseDown(MOUSE_LEFT) and (doit) then
			RunConsoleCommand("+attack")
			doit = false
		elseif input.IsMouseDown(MOUSE_LEFT) and !(doit) then
			RunConsoleCommand("-attack")
			doit = true
		end
	end
end

if GetConVarNumber("raz_rapidfire") == 1 then
	AddHook("Think", "rapid", rapidfire)
end

cvars.AddChangeCallback("raz_rapidfire", function()
	if GetConVarNumber("raz_rapidfire") == 1 then
		AddHook("Think", "rapid", rapidfire)
	else
		RemoveHook("Think", "rapid")
	end
end)

--[[
RP GOD
Spams "/buyhealth" when you use health.
]]

local function rpgod()
	if LocalPlayer():Health() < 75 then
		if !(delay) then
			LocalPlayer():ConCommand("say /buyhealth")
			delay = true
			timer.Simple(2, function()
				delay = false
			end)
		end
	end
end


if GetConVarNumber("raz_rpgod") == 1 then
	AddHook("Think", "RP", rpgod)
end


cvars.AddChangeCallback("raz_rpgod", function()
	if GetConVarNumber("raz_rpgod") == 1 then
		AddHook("Think", "RP", rpgod)
	else
		RemoveHook("Think", "RP")
	end
end)

--[[
Triggerbot
]]

local function triggerbot()
	local EyeEntity = LocalPlayer():GetEyeTrace().Entity
	if shallfire == nil and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() then
		shallfire = true
	end
	if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() and shallfire then
		LocalPlayer():ConCommand("+attack")
		shallfire = false
	elseif LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() and !shallfire then
		LocalPlayer():ConCommand("-attack")
		shallfire = true
	elseif !EyeEntity:IsPlayer() and shallfire == true then
		LocalPlayer():ConCommand("-attack")
		shallfire = nil
	elseif !EyeEntity:IsPlayer() and shallfire == false then
		LocalPlayer():ConCommand("-attack")
		shallfire = nil
	end
end

if GetConVarNumber("raz_triggerbot") == 1 then
	AddHook("Think", "trigger", triggerbot)
end

cvars.AddChangeCallback("raz_triggerbot", function()
	if GetConVarNumber("raz_triggerbot") == 1 then
		AddHook("Think", "trigger", triggerbot)
	else
		RemoveHook("Think", "trigger")
		LocalPlayer():ConCommand("-attack")
	end
end)

--[[
Chatspam
]]

local wait = false

local function chatspam()
	if !(wait) then
		LocalPlayer():ConCommand("say "..GetConVarString("raz_chatspam_msg"))
		wait = true
		timer.Simple(2, function()
			wait = false
		end)
	end
end

LocalPlayer():ConCommand("raz_chatspam 0")

if GetConVarNumber("raz_chatspam") == 1 then
	AddHook("Think", "chatsp", chatspam)
end

cvars.AddChangeCallback("raz_chatspam", function()
	if GetConVarNumber("raz_chatspam") == 1 then
		AddHook("Think", "chatsp", chatspam)
	else
		RemoveHook("Think", "chatsp")
	end
end)


--[[
PropSurf
]]

local function surf()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
	timer.Simple(0.05, function()
		RunConsoleCommand("gm_spawn", "models/props_c17/Lockers001a.mdl")
	end)
	timer.Simple(0.2, function()
		RunConsoleCommand("+attack")
		a = LocalPlayer():EyeAngles()
	end)
	timer.Simple(0.4, function()
		LocalPlayer():SetEyeAngles(Angle(a.p,a.y-180, a.r))
	end)
end

concommand.Add("+raz_propsurf", function()
	surf()
end)

concommand.Add("-raz_propsurf", function()	
	LocalPlayer():ConCommand("-attack")
	LocalPlayer():ConCommand("undo")
end)

--[[
Speedhack
]]


concommand.Add("+raz_speedhack", function()
	ForceVarAlt("sv_cheats", 1)
	ForceVarAlt("host_framerate", GetConVarNumber("raz_speedhack_speed"))
end)

concommand.Add("-raz_speedhack", function()
	ForceVarAlt("host_framerate", 0)
	ForceVarAlt("sv_cheats", 0)
end)


--[[
FOV-Changer
]]

local function changefov(ply, ori, ang, fov)
	local view = {}
	view.fov = GetConVarNumber("raz_fov")
	return view
end

if GetConVarNumber("raz_fov_enable") == 1 then
	AddHook("CalcView", "ChangeFOV", changefov)
end

cvars.AddChangeCallback("raz_fov_enable", function()
	if GetConVarNumber("raz_fov_enable") == 1 then
		AddHook("CalcView", "ChangeFOV", changefov)
	else
		RemoveHook("CalcView", "ChangeFOV")
	end
end)


--[[
Fullbright
]]

local function fullbright()
	if GetConVarNumber("mat_fullbright") == 1 then
		ForceVarAlt("mat_fullbright", 0)
	else
		ForceVarAlt("mat_fullbright", 1)
	end
end

concommand.Add("raz_fullbright", fullbright)


--[[
ATM Bruteforce
Probaly the longest function in the whole script
]]

concommand.Remove("raz_atm_bruteforce")

concommand.Add("raz_atm_bruteforce", function()

local count = 0
local pincodes = {}
for pin=1,9999 do
	if pin > 0 and pin < 10 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 000"..pin..". Inserting now.")
			table.insert(pincodes,"000"..pin)
			--file.Append("PINZ.txt", "000"..pin.."\n")
		end)
	end
	if pin > 9 and pin < 100 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 00"..pin..". Inserting now.")
			table.insert(pincodes,"00"..pin)
			--file.Append("PINZ.txt", "00"..pin.."\n")
		end)
	end
	if pin > 99 and pin < 1000 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 0"..pin..". Inserting now.")
			table.insert(pincodes,"0"..pin)
			--file.Append("PINZ.txt", "0"..pin.."\n")
		end)
	end
	if pin > 999 and pin < 10000 then
		timer.Simple(pin*.0002, function()
			if pin == 9999 then
				print("Generated pin "..pin..". Inserting now.")
				table.insert(pincodes,pin)
				print("")
				print("All Pins generated!")
				print("")
				print("I wouldn't crack those admins account: ")
				for k,v in pairs(player.GetAll()) do
					if v:IsAdmin() then
						if v:IsSuperAdmin() then
							print(v:Name().. " - Superadmin")
						else
							print(v:Name().. " - Admin")
						end
					end
				end
				print("")
				print("How to use: ")
				print("")
				print('Type "raz_atm_bruteforce <Name> <Amount>" near an ATM to start bruteforcing!"')
				print("")
				print("It should look like this:")
				print("")
				print('raz_atm_bruteforce "Razor Sharp" 1000')
				print("")

				--file.Append("PINZ.txt", pin.."\n")
			else
				print("Generated pin "..pin..". Inserting now.")
				table.insert(pincodes,pin)
				--file.Append("PINZ.txt", pin.."\n")
			end
		end)	
	end
end

local function bruteit(use,less,args)
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Name()), string.lower(args[1])) then
			print("Bruteforce will begin in 3 seconds...")
			timer.Simple(3, function()
			local name = v:Name()
			local uid = v:UniqueID()
			for tab, qpin in pairs(pincodes) do 
				timer.Simple(qpin*.005, function()
					print("Trying pin "..qpin.." on the account of "..name..".")
					RunConsoleCommand("rp_atm_withdraw", util.CRC(qpin), uid, args[2])
				end)
			end
			end)
		end
	end
end
local function bruteall(use,less,args)
	for k,v in pairs(player.GetAll()) do
		for tab, qpin in pairs(pincodes) do
			increasetimetonextbrute()
			timer.Simple(qpin*.002+timetillnextbrute, function()
				print("Trying pin "..qpin.." on the account of "..v:Name()..".")
				RunConsoleCommand("rp_atm_withdraw", util.CRC(qpin), v:UniqueID(), args[1])
				if qpin == 9999 then
					count = 0
				end
			end)
		end
	end
end
local function increasetimetonextbrute()
	if count == 0 then
		count = .08
	end
	count = count+.08
	local delaytillnextbrute = .03
	local thistoaddtillnextbrute = .03
	local timetillnextbrute = thistoaddtillnextbrute+delaytillnextbrute*count
end


concommand.Remove("raz_atm_bruteforce")
timer.Simple(0.2, function()
	concommand.Add("raz_atm_bruteforce", bruteit)
	concommand.Add("raz_atm_bruteforce_all", bruteall)
end)



end)

concommand.Remove("raz_atm_bruteforce_all")

--[[
Traitorfinder
]]

local tweapons = { 
	"weapon_ttt_sipistol", 
	"weapon_ttt_flaregun",  
	"weapon_ttt_teleport",
	"spiderman's_swep", 
	"weapon_ttt_trait_defilibrator", 
	"weapon_ttt_xbow", 
	"weapon_ttt_dhook", 
	"weapon_awp", 
	"weapon_jihadbomb", 
	"weapon_ttt_knife", 
	"weapon_ttt_c4", 
	"weapon_ttt_decoy", 
	"weapon_ttt_phammer", 
	"weapon_ttt_push", 
	"weapon_ttt_radio", 
	"weapon_ttt_awp", 
	"weapon_ttt_silencedsniper", 
	"weapon_ttt_turtlenade", 
	"weapon_ttt_death_station",
	"weapon_ttt_sg552", 
	"weapon_ttt_tripmine"
}

first = true

local function traitorfinder()
	if first then
		for k,v in pairs(player.GetAll()) do
			v.IsTracked = false
			v.IsTraitor = false
			first = false
		end
	end
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and GAMEMODE.round_state != ROUND_ACTIVE then
			v.IsTracked = false
			v.IsTraitor = false
		end
	end
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and GAMEMODE.round_state == ROUND_ACTIVE and !(v.IsTracked) and v:Team() ~= TEAM_SPECTATOR then
			for k2, v2 in pairs(v:GetWeapons()) do
					if table.HasValue( tweapons,v2:GetClass() ) then
						if v:IsDetective() then
							v.IsTracked = true
						else
							v.IsTracked = true
							v.IsTraitor = true
							LocalPlayer():ChatPrint(v:Name().." is a traitor with a "..v2:GetClass())
						end
					end
				end
			end
		end
	end
	
if GetConVarNumber("raz_traitorfinder") == 1 then
	AddHook("Think", "T-Finder", traitorfinder)
end

cvars.AddChangeCallback("raz_traitorfinder", function()
	if GetConVarNumber("raz_traitorfinder") == 1 then
		AddHook("Think", "T-Finder", traitorfinder)
	else
		RemoveHook("Think", "T-Finder")
	end
end)

--[[
Flashlight Spam
Do it infront of admin with antiaim(Not in the liteversion) enabled
]]

local function spamflashlight()
	if LocalPlayer():IsTyping() then
		return
	end
	if input.IsKeyDown(KEY_F) then
		timer.Simple(0.01, function()
			RunConsoleCommand("impulse", "100")
		end)
		timer.Simple(0.02, function()
			RunConsoleCommand("impulse", "100")
		end)
	end
end

if GetConVarNumber("raz_fspam") == 1 then
	AddHook("CreateMove", "fspam", spamflashlight)
end

cvars.AddChangeCallback("raz_fspam", function()
	if GetConVarNumber("raz_fspam") == 1 then
		AddHook("CreateMove", "fspam", spamflashlight)
	else
		RemoveHook("CreateMove", "fspam")
	end
end)

--[[
Use spam
]]

local function usespam()
	timer.Simple(0.015, function()
		LocalPlayer():ConCommand("+use")
	end)
	timer.Simple(0.025, function()
		LocalPlayer():ConCommand("-use")
	end)
end

concommand.Add("+raz_usespam", function()
	AddHook("Think", "Usespam", usespam)
end)

concommand.Add("-raz_usespam", function()
	RemoveHook("Think", "Usespam")
end)


--[[
Entity ESP
Fucking Awesome Box!
]]

trackents = { -- Add Entities to track here, or use ingame function.
"printer",
"spawned_",
"weapon_ttt_awp",
"weapon_jihadbomb",
"weapon_ttt_death_station",
"weapon_ttt_flaregun",
"weapon_ttt_knife",
"weapon_ttt_phammer",
"weapon_ttt_push",
"weapon_perp_glock",
"m9k_ammo_",
"weapon_ttt_health_station",
"weapon_ttt_c4",
"weapon_ttt_decoy"
-- Zworld Afterlife items will be added soon
}



local espcolor = ""

local function entityesp()
	for k,v in pairs(ents.GetAll()) do
		for i,s in pairs(trackents) do
			if v:IsValid() and string.find(v:GetClass(),s) and InDist(v) then
				if table.HasValue(tweapons, v:GetClass()) then 
					if v:GetOwner() == LocalPlayer() then 
						return 
					end
				end
				local ang = Angle(0, v:GetAngles().y, 0)
				local i,x = v:WorldSpaceAABB()
				local diff = x-i
				local pos = (v:GetPos()+Vector(0,0,20)):ToScreen()
				local pos2 = Vector(0,0,0)
				local pos1 = Vector(0,0,0)
				local pos3 = Vector(0,0,0)
				local pos4 = Vector(0,0,0)
				local pos5 = Vector(0,0,diff.z)
				local pos6 = Vector(0,0,diff.z)
				local pos7 = Vector(0,0,diff.z)
				local pos8 = Vector(0,0,diff.z)

				pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				surface.SetDrawColor(0,0,0)
				
				surface.DrawLine(pos1.x,pos1.y,pos2.x,pos2.y)
				surface.DrawLine(pos2.x,pos2.y,pos3.x,pos3.y)
				surface.DrawLine(pos3.x,pos3.y,pos4.x,pos4.y)
				surface.DrawLine(pos1.x,pos1.y,pos4.x,pos4.y)
				
				surface.SetDrawColor(255,0,0)
				
				surface.DrawLine(pos1.x,pos1.y,pos5.x,pos5.y)
				surface.DrawLine(pos2.x,pos2.y,pos6.x,pos6.y)
				surface.DrawLine(pos3.x,pos3.y,pos7.x,pos7.y)
				surface.DrawLine(pos4.x,pos4.y,pos8.x,pos8.y)
				
				surface.SetDrawColor(0,0,255)
				
				surface.DrawLine(pos5.x,pos5.y,pos6.x,pos6.y)
				surface.DrawLine(pos6.x,pos6.y,pos7.x,pos7.y)
				surface.DrawLine(pos7.x,pos7.y,pos8.x,pos8.y)
				surface.DrawLine(pos8.x,pos8.y,pos5.x,pos5.y)
				
				cam.Start3D()
					v:SetMaterial("models/wireframe")
					espcolor = Color(255,191,0,255)
					render.SetColorModulation(espcolor.r / 255, espcolor.g / 255, espcolor.b / 255)
					render.SetBlend( espcolor.a / 255 )
					v:DrawModel()
				cam.End3D()
				draw.SimpleText(v:GetClass(), "Default", pos.x, pos.y, Color(255,255,255,255), 1)
			elseif v:IsValid() and string.find(v:GetClass(),s) and !(InDist(v)) then
				cam.Start3D()
					v:SetMaterial("")
					render.SetColorModulation(1,1,1)
					render.SetBlend(1)
				cam.End3D()
			end
		end
	end
end

if GetConVarNumber("raz_entesp") == 1 then
	AddHook("HUDPaint", "EntityESP", entityesp)
end

cvars.AddChangeCallback("raz_entesp", function()
	if GetConVarNumber("raz_entesp") == 1 then
		AddHook("HUDPaint", "EntityESP", entityesp)
	else
		RemoveHook("HUDPaint", "EntityESP")
		for k,v in pairs(ents.GetAll()) do
			for i,s in pairs(trackents) do
				if v:IsValid() and string.find(v:GetClass(),s) then
					cam.Start3D()
						v:SetMaterial("")
						render.SetColorModulation(1,1,1)
						render.SetBlend(1)
					cam.End3D()
				end
			end
		end
	end
end)

--[[
Breakfall and Propclimb
]]

local function pclimb()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(180, a.y, a.r))
	RunConsoleCommand("+attack")
	timer.Simple(0.1, function()
		LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
	end)
	timer.Simple(0.2, function()
		RunConsoleCommand("+jump")
	end)
	timer.Simple(0.4, function()
		RunConsoleCommand("-jump")
		LocalPlayer():SetEyeAngles(Angle(-90,a.y,a.r))
	end)
end

concommand.Add("+raz_propclimb", function()
	pclimb()
end)

concommand.Add("-raz_propclimb", function()
	RunConsoleCommand("-attack")
	RunConsoleCommand("undo")
end)

-- Need to time perfectly

concommand.Add("raz_breakfall", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(50, a.y, a.r))
	LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/wood/wood_dome360.mdl")
end)

--[[
TTT Propkill
]]

-- You need to try around with this one.

concommand.Add("raz_ttt_pkill", function()
	local a = LocalPlayer():EyeAngles() 
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y-120, a.r))
end)

--[[
Spin me right round
Don't ask.
]]

RunConsoleCommand("raz_spinme", 0)

local oldview = LocalPlayer():EyeAngles() 


local function spinmerightround()
	local a = LocalPlayer():EyeAngles() 
	local spin1 = 1
	local spin2 = 1.2
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y+spin1+spin2, a.r+spin1+spin2))
end

cvars.AddChangeCallback("raz_spinme", function()
	if GetConVarNumber("raz_spinme") == 1 then
		AddHook("Think", "Spinme", spinmerightround)
	else
		RemoveHook("Think", "Spinme")
		LocalPlayer():SetEyeAngles(Angle(0, 0, 0))
	end
end)

--[[
Support me
]]

RunConsoleCommand("raz_supportme", 0)

local delaysupport = false

local function supportrazor()
	if !(delaysupport) then
		if GAMEMODE.Name == "DarkRP" then
			delaysupport = true
			timer.Simple(1.5, function()
				delaysupport = false
			end)
			LocalPlayer():ConCommand("say /advert I'm using RAZ v"..raz.version..".")
		else			
			delaysupport = true
			timer.Simple(1.5, function()
				delaysupport = false
			end)
			LocalPlayer():ConCommand("say I'm using RAZ v"..raz.version..".")
		end
	end
end

cvars.AddChangeCallback("raz_supportme", function()
	if GetConVarNumber("raz_supportme") == 1 then
		AddHook("Think", "SupportMe", supportrazor)
	else
		RemoveHook("Think", "SupportMe")
	end
end)

--[[
Walkbot
]]

local walkforme = false

local function walkbot()
	if (walkforme) then
		RunConsoleCommand("+forward")
	else
		RunConsoleCommand("-forward")
	end
end

concommand.Add("raz_walkbot", function()
	if !(walkforme) then
		walkforme = true
		walkbot()
	elseif (walkforme) then
		walkforme = false
		walkbot()
	end
end)


--[[
Execute Functions
]]

GetServerGameMode()

--[[
Print Stuff
]]

LocalPlayer():ChatPrint("Loaded RAZ v"..raz.version)
LocalPlayer():ChatPrint("Thanks for using RAZ v"..raz.version.."!")

finin1sec = true

--[[
End of the lite version of RAZ
------------------------------------
Notes:

I only accept PayPal purchases.
Sometimes i accept steam gifts.

I won't really update the lite version, maybe twice in a year.
Consider upgrading.
]]