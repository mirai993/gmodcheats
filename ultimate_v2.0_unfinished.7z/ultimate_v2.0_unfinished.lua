require( "zxcmodule" )

local rgba = Color

local scrw = ScrW()
local scrh = ScrH()

local ultimate = {}

// Configurable vars 

ultimate.cfg = { vars = {}, colors = {}, binds = {}, friends = {}, ents = {} }

ultimate.cfg.vars[ "Enable Aimbot" ] = false
ultimate.cfg.vars[ "Aimbot fov" ] = 25
ultimate.cfg.vars[ "hz" ] = "ez 111"

// Input 

ultimate.lastCursorPos  = { x = 0, y = 0 }
ultimate.keyPressData = {}

for i = -1, 172 do
    ultimate.keyPressData[ i ] = false
end

function ultimate.IsKeyDown( key )
    if key >= 107 then
        return input.IsMouseDown( key )
    end

    return input.IsKeyDown( key )
end

function ultimate.WasKeyPressed( key )
    if key >= 107 then
        return input.WasMousePressed( key )
    end

    return input.WasKeyPressed( key )
end

function ultimate.CursorInRect( x, y, w, h )
    return ( ultimate.lastCursorPos.x >= x  and ultimate.lastCursorPos.y >= y ) and ( ultimate.lastCursorPos.x < x + w and ultimate.lastCursorPos.y < y + h )
end

// Theme data 

ultimate.themeSettings  = {
    Background  = rgba( 16, 16, 16 ),
    Outline     = rgba( 64, 64, 64 ),

    TextFocus   = rgba( 164, 164, 164 ),
    TextNormal  = rgba( 128, 128, 128 ),
    TextUnfocus = rgba( 96, 96, 96 ),
}

// UI data 

ultimate.oldCursorPos   = { x = 0, y = 0 }
ultimate.menuPosition   = { x = 65, y = 65 }
ultimate.drawContext    = { x = 0, y = 0, w = 0, h = 0, gbid = 0, gbd = {} }
ultimate.scaled         = {}
ultimate.fonts          = {}
ultimate.uiElements     = {}
ultimate.txtInputData   = {}

ultimate.tooltip        = ""

ultimate.dpiScale       = 1 
ultimate.sliderMode     = 1

ultimate.editingText    = false 
ultimate.cursorState    = false 
ultimate.shouldDrawMenu = false

gui.EnableScreenClicker( true )

// Automatic element scaling

ultimate.scaled[1]  = { val = 0, fnc = function() return math.floor( ( scrw / 1.6 ) * ultimate.dpiScale ) end }
ultimate.scaled[2]  = { val = 0, fnc = function() return math.floor( ( scrh / 1.2 ) * ultimate.dpiScale ) end }
ultimate.scaled[3]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[2].fnc() / 34 ) end }
ultimate.fonts[1]   = { str = "SmallTitle", data = { font = "Open Sans", size = ultimate.scaled[3].fnc() * 0.65, weight = 300 } }
ultimate.scaled[4]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[3].fnc() / 2 - ultimate.fonts[1].data.size / 2 ) end }
ultimate.scaled[5]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[1].fnc() / 3 - 16 ) end }
ultimate.scaled[6]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[3].fnc() / 1.25 ) end }
ultimate.scaled[7]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[6].fnc() - 6 ) end }
ultimate.scaled[8]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[6].fnc() / 2 - ultimate.fonts[1].data.size / 2 ) end }
ultimate.scaled[9]  = { val = 0, fnc = function() return math.floor( ultimate.fonts[1].data.size * 2.2 ) end }
ultimate.scaled[10]  = { val = 0, fnc = function() return math.floor( ultimate.scaled[9].fnc() / 2 ) end }
ultimate.scaled[11]  = { val = 0, fnc = function() return math.floor( ultimate.fonts[1].data.size * 1.25 ) end }



function ultimate.reScale()
    for i = 1, #ultimate.scaled do
        ultimate.scaled[ i ].val = ultimate.scaled[ i ].fnc()
    end

    for i = 1, #ultimate.fonts do
        surface.CreateFont( ultimate.fonts[i].str, ultimate.fonts[i].data )
    end
end

ultimate.reScale()

// UI elements 

ultimate.uiElements[ "GroupBox" ] = function( data )
    local x, y, str, w = ultimate.drawContext.x, ultimate.drawContext.y + ultimate.fonts[1].data.size / 2, data.str, ultimate.scaled[5].val

    if not ultimate.drawContext.gbd[ ultimate.drawContext.gbid ] then
        ultimate.drawContext.gbd[ ultimate.drawContext.gbid ] = 4
    end

    ultimate.drawContext.h = 4

    surface.SetTextColor( ultimate.themeSettings.TextNormal )
    
    local tw, th = surface.GetTextSize( str )
    local tx, ty = x + w / 2 - tw / 2, y - ultimate.fonts[1].data.size / 2

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y, w, ultimate.drawContext.gbd[ ultimate.drawContext.gbid ] )

    surface.SetDrawColor( ultimate.themeSettings.Background )
    surface.DrawRect( tx - 4, ty, tw + 8, th)

    surface.SetTextPos( tx, ty )
    surface.DrawText( str )

    ultimate.drawContext.y = ultimate.drawContext.y + ultimate.fonts[1].data.size / 2
    ultimate.drawContext.w = w
end

ultimate.uiElements[ "EndGroupBox" ] = function()
    ultimate.drawContext.gbd[ ultimate.drawContext.gbid ] = ultimate.drawContext.h
    ultimate.drawContext.gbid = ultimate.drawContext.gbid + 1
    ultimate.drawContext.y = ultimate.drawContext.y + 4
end

ultimate.uiElements[ "CheckBox" ] = function( data )
    local x, y, str, s = ultimate.drawContext.x + 4, ultimate.drawContext.y + 4, data.str, ultimate.scaled[6].val
    local p = ultimate.scaled[7].val

    surface.SetTextColor( ultimate.cfg.vars[ str ] and ultimate.themeSettings.TextFocus or ultimate.themeSettings.TextNormal )
    surface.SetTextPos( x + s + 3, y + ultimate.scaled[8].val )
    surface.DrawText( str )

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y, s, s )

    if ultimate.cfg.vars[ str ] then
        surface.DrawRect( x + 3, y + 3, p, p )
    end

    if ultimate.keyPressData[ 107 ] and ultimate.CursorInRect( x, y, s, s ) then
        ultimate.cfg.vars[ str ] = not ultimate.cfg.vars[ str ]
    end

    ultimate.drawContext.y = ultimate.drawContext.y + s + 4
    ultimate.drawContext.h = ultimate.drawContext.h + 4 + s
end 

ultimate.uiElements[ "Slider" ] = function( data )
    local x, y, str, s = ultimate.drawContext.x + 4, ultimate.drawContext.y + 2, data.str, ultimate.scaled[9].val

    surface.SetTextColor( ultimate.themeSettings.TextNormal )

    surface.SetTextPos( x + 3, y )
    surface.DrawText( str )

    local tw, th = surface.GetTextSize( ultimate.cfg.vars[ str ] .. data.symbol )

    surface.SetTextPos( x + ultimate.drawContext.w - 8 - tw, y )
    surface.DrawText( ultimate.cfg.vars[ str ] .. data.symbol )

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y + ultimate.scaled[10].val, ultimate.drawContext.w - 8, ultimate.scaled[10].val )

    local len = ultimate.cfg.vars[ str ] / data.max * ( ultimate.drawContext.w - 12 )

    surface.DrawRect( x + 2, y + 2 + ultimate.scaled[10].val, len, ultimate.scaled[10].val - 4 )

    local w = ultimate.drawContext.w

    if ultimate.CursorInRect( x + 2, y + 2 + ultimate.scaled[10].val, ultimate.drawContext.w - 12, ultimate.scaled[10].val - 4 ) then
        local d = ultimate.cfg.vars[ str ]
        
        if input.IsMouseDown( MOUSE_LEFT ) then
            ultimate.sliderMode = 1 

            local cx, cy = input.GetCursorPos()

            d = math.Round( data.min + ((cx - x+2) / (x + 2 + ultimate.drawContext.w - 12 - x + 2)) * (data.max - data.min), data.dec )
        elseif ultimate.keyPressData[ 109 ] then
            ultimate.sliderMode = 2
        end

        if input.IsKeyDown( KEY_LCONTROL ) and input.IsKeyDown( KEY_V ) then
            local clip = tonumber( ded.GetClipboardText() )
            if clip then 
                d = clip 
            end
        end

        if ultimate.sliderMode == 2 then
            local str = tostring( d )

            for i = 1, 10 do
                if ultimate.keyPressData[ i ] then
                    str = str .. ( i - 1 )
                end
            end

            if ultimate.keyPressData[ 66 ] then 
                str = string.sub( str, 1, #str - 1 )
                if str == "" then str = data.min end
            end

            if ultimate.keyPressData[ 89 ] then 
                local n = tonumber( str )
                n = n - data.min 
                str = tostring( n )
            elseif ultimate.keyPressData[ 91 ] then
                local n = tonumber( str )
                n = n + data.min 
                str = tostring( n )
            end

            local tw, th = surface.GetTextSize( str )

            surface.SetTextPos( x + ( ultimate.drawContext.w - 12 ) / 2 - tw / 2, y + ultimate.scaled[10].val / 2 + th / 2 + 1 )
            surface.DrawText( str )

            str = tonumber( str )
            if str then
                d = str
            end
        end

        ultimate.cfg.vars[ str ] = math.Clamp( d, data.min, data.max )
    end

    ultimate.drawContext.y = ultimate.drawContext.y + s + 2
    ultimate.drawContext.h = ultimate.drawContext.h + 2 + s
end

ultimate.uiElements[ "Button" ] = function( data )
    local x, y, str, s = ultimate.drawContext.x + 4, ultimate.drawContext.y + 2, data.str, ultimate.scaled[11].val
    local w = ultimate.drawContext.w - 8
    local tw, th = surface.GetTextSize( str )
    local h = ultimate.CursorInRect( x, y, w, s ) 

    surface.SetTextColor( h and ultimate.themeSettings.TextFocus or ultimate.themeSettings.TextNormal )

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y, w, s )

    if h then
        if input.IsMouseDown( MOUSE_LEFT ) then 
            surface.DrawRect( x, y, w, s )
        end

        if ultimate.keyPressData[ 107 ] then
            data.fnc()
        end
    end

    surface.SetTextPos( x + w / 2 - tw / 2, y + s / 2 - th / 2 - 1 )
    surface.DrawText( str )

    ultimate.drawContext.y = ultimate.drawContext.y + s + 2
    ultimate.drawContext.h = ultimate.drawContext.h + s + 2
end

ultimate.uiElements[ "TextInput" ] = function( data )
    local x, y, str, s = ultimate.drawContext.x + 4, ultimate.drawContext.y + 2, data.str, ultimate.scaled[11].val
    local w = ultimate.drawContext.w - 8
    local h = ultimate.CursorInRect( x, y, w, s ) 
    local anytext = ultimate.cfg.vars[ str ] != "" or ultimate.editingText

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y, w, s )

    surface.SetTextColor( anytext and ultimate.themeSettings.TextFocus or ultimate.themeSettings.TextNormal )
    surface.SetTextPos( x + 4, y )

    render.SetScissorRect( x, y, x + w, y + s, true )
        surface.DrawText( anytext and ultimate.cfg.vars[ str ] or data.placeholder )
    render.SetScissorRect( 0, 0, 0, 0, false )
 
    if h then
        if ultimate.keyPressData[ 107 ] then
            ultimate.editingText = true 
        end

        if ultimate.keyPressData[ 64 ] then
            ultimate.editingText = false 
        end

        if ultimate.editingText then
            if input.IsKeyDown( KEY_LCONTROL ) then
                if input.IsKeyDown( KEY_V ) then
                    local clip = tonumber( ded.GetClipboardText() )
                    if clip then 
                        ultimate.cfg.vars[ str ] = clip 
                    end
                elseif input.IsKeyDown( KEY_C ) then 
                    SetClipboardText( ultimate.cfg.vars[ str ] )
                end
            else
                if ultimate.keyPressData[ 65 ] then 
                    ultimate.cfg.vars[ str ] = ultimate.cfg.vars[ str ] .. " "
                elseif ultimate.keyPressData[ 66 ] then 
                    ultimate.cfg.vars[ str ] = string.sub( ultimate.cfg.vars[ str ], 1, #ultimate.cfg.vars[ str ] - 1 )
                else
                    for i = 1, 36 do
                        if ultimate.keyPressData[ i ] then
                            ultimate.cfg.vars[ str ] = ultimate.cfg.vars[ str ] .. input.GetKeyName( i )
                        end
                    end
                end
            end
        end
    end

    ultimate.drawContext.y = ultimate.drawContext.y + s + 2
    ultimate.drawContext.h = ultimate.drawContext.h + s + 2
end

ultimate.uiElements[ "ComboBox" ] = function( data )
    local x, y, str, s = ultimate.drawContext.x + 4, ultimate.drawContext.y + 2, data.str, ultimate.scaled[9].val
    local w = ultimate.drawContext.w - 8

    surface.SetTextColor( ultimate.themeSettings.TextNormal )

    surface.SetTextPos( x + 3, y )
    surface.DrawText( str )
    
    surface.SetTextPos( x + 3, y )
    surface.DrawText( str )

    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y + ultimate.scaled[10].val, w, ultimate.scaled[10].val )

    if ultimate.CursorInRect( x, y, w, s ) then
        
    end

    ultimate.drawContext.y = ultimate.drawContext.y + s + 2
    ultimate.drawContext.h = ultimate.drawContext.h + s + 2
end

// Menu drawing 
 
local bval = false
local numericvar = 1.11


function ultimate.drawMenu()
    if not ultimate.shouldDrawMenu then return end
    local x, y, w, h = ultimate.menuPosition.x, ultimate.menuPosition.y, ultimate.scaled[1].val, ultimate.scaled[2].val

    render.SetScissorRect( x, y, x + w, y + h, true )

    surface.SetDrawColor( ultimate.themeSettings.Background )
    surface.DrawRect( x, y, w, h )
    surface.SetDrawColor( ultimate.themeSettings.Outline )
    surface.DrawOutlinedRect( x, y, w, h )
    surface.DrawRect( x, y, w, ultimate.scaled[3].val )

    surface.SetTextColor( ultimate.themeSettings.TextNormal )
    surface.SetFont( ultimate.fonts[1].str )

    surface.SetTextPos( x + ultimate.scaled[4].val * 2, y + ultimate.scaled[4].val )
    surface.DrawText( "ULTIMATE V3" )

    ultimate.drawContext.x = x + 4
    ultimate.drawContext.y = y + ultimate.scaled[3].val + 4
    ultimate.drawContext.gbid = 1

    surface.SetFont( ultimate.fonts[1].str )

    ultimate.uiElements[ "GroupBox" ]( { str = "Aimbot" } )

        ultimate.uiElements[ "CheckBox" ]( { str = "Enable aimbot" } )
        ultimate.uiElements[ "Slider" ]( { str = "Aimbot fov", max = 45, min = 1, dec = 0, symbol = "unit" } )
        ultimate.uiElements[ "Button" ]( { str = "Enable aimbot" } )
        ultimate.uiElements[ "TextInput" ]( { placeholder = "mazafaka1488", str = "hz" } )

    ultimate.uiElements[ "EndGroupBox" ]()

    ultimate.uiElements[ "GroupBox" ]( { str = "Legit" } )

        ultimate.uiElements[ "ComboBox" ]( { str = "Hitbox" } )
    

    ultimate.uiElements[ "EndGroupBox" ]()

    render.SetScissorRect( 0, 0, 0, 0, false )
end

// Hooks 

function ultimate.ThinkFunc()
    gui.EnableScreenClicker( ultimate.cursorState )

    if ultimate.keyPressData[ KEY_DELETE ] then
        ultimate.shouldDrawMenu = not ultimate.shouldDrawMenu

        if not ultimate.shouldDrawMenu and vgui.CursorVisible() then
            gui.EnableScreenClicker( false )
        end
    end

    ultimate.cursorState = vgui.CursorVisible()

    if ultimate.shouldDrawMenu then
        gui.EnableScreenClicker( true )

        if input.IsMouseDown( MOUSE_LEFT ) and ultimate.CursorInRect( ultimate.menuPosition.x, ultimate.menuPosition.y, ultimate.scaled[1].val, ultimate.scaled[3].val ) then
            local cx, cy = input.GetCursorPos()

            ultimate.menuPosition.x = ultimate.menuPosition.x + ( cx - ultimate.lastCursorPos.x )
            ultimate.menuPosition.y = ultimate.menuPosition.y + ( cy - ultimate.lastCursorPos.y )
        end
    end

    ultimate.lastCursorPos.x, ultimate.lastCursorPos.y = input.GetCursorPos()
end

function ultimate.DrawOverlayFunc() 
    ultimate.drawMenu() 


    
end

function ultimate.CreateMoveFunc( cmd )
    for i = -1, 172 do
        ultimate.keyPressData[ i ] = ultimate.WasKeyPressed( i )
    end


end

hook.Add( "Think", "123", ultimate.ThinkFunc )
hook.Add( "DrawOverlay", "123", ultimate.DrawOverlayFunc )
hook.Add( "CreateMove", "123", ultimate.CreateMoveFunc )

