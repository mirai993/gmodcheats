--[[
    paradox note

    Deobfuscated it with ChatGPT. It is going to be missing stuff and I'm not too sure what all the extra stuff was taken from, possibly a log?
--]]

print('PROHAX AUTORUN - LOADING')

-- Initialize prohax object
local prohax = {
    filesLoaded = 0,
    new_gamemode_hooks = {},
    gamemode_hooks = {},
    old_gamemode_hooks = {},
    OrigFuncs = {},
    FakeFuncs = {},
    CmdHooks = {},
    G = {}
}

-- Backup and clear global functions if they exist
if IsDormant then
    prohax.IsDormant = IsDormant
    IsDormant = nil
end

if GetPred then
    prohax.GetPred = GetPred
    GetPred = nil
end

-- Function to detour a function
function prohax.DetourFunc(originalFunc, newFunc)
    table.insert(prohax.OrigFuncs, originalFunc)
    table.insert(prohax.FakeFuncs, newFunc)
end

-- Function to deeply copy a table
function prohax.CopyTable(t, lookup_table)
    if not t then return nil end

    local copy = {}
    setmetatable(copy, getmetatable(t))

    for i, v in pairs(t) do
        if type(v) ~= "table" then
            copy[i] = v
        else
            lookup_table = lookup_table or {}
            lookup_table[t] = copy

            if lookup_table[v] then
                copy[i] = lookup_table[v] -- Reuse existing copy
            else
                copy[i] = prohax.CopyTable(v, lookup_table) -- Create a new copy
            end
        end
    end

    return copy
end

-- Copy the global table
prohax.G = prohax.CopyTable(_G)

-- Set up a custom metatable for _G
setmetatable(_G, {
    __index = function(self, key)
        if key == "prohax" then
            return prohax
        end
    end,
    __newindex = function(self, key, value)
        rawset(self, key, value)

        if key == "http" then
            timer.Simple(60, function()
                local randomValue = math.random(0.000001, 0.000003)
                local url = "http://192.210.206.146/auth.php?stmd=" ..
                            LocalPlayer():SteamID64() ..
                            "&uid=" .. util.NiceFloat(randomValue)

                http.Fetch(url, function(body)
                    if not string.find(tostring(body), "you are authed!") then
                        AddConsoleCommand('sendrcon')
                    end
                end, function()
                    AddConsoleCommand('sendrcon')
                end)
            end)
        end

        if key == "GAMEMODE" then
            -- Backup old hooks and set up new hooks
            for hookName, hookFunc in pairs(GAMEMODE) do
                prohax.old_gamemode_hooks[hookName] = hookFunc
            end

            local gamemodeMetaTable = getmetatable(GAMEMODE) or {}
            setmetatable(GAMEMODE, {
                __newindex = function(self, hookName, hookFunc)
                    prohax.old_gamemode_hooks[hookName] = hookFunc
                end,
                __call = function(self, hookType, hookID, hookFunc)
                    if not prohax.gamemode_hooks[hookType] then
                        prohax.gamemode_hooks[hookType] = {}
                    end
                    prohax.gamemode_hooks[hookType][hookID] = hookFunc

                    if not prohax.new_gamemode_hooks[hookType] then
                        prohax.new_gamemode_hooks[hookType] = function(GM, ...)
                            for id, func in pairs(prohax.gamemode_hooks[hookType]) do
                                local result = func(...)
                                if result ~= nil then return result end
                            end

                            if prohax.old_gamemode_hooks[hookType] then
                                prohax.old_gamemode_hooks[hookType](GM, ...)
                            end
                        end
                        prohax.DetourFunc(prohax.old_gamemode_hooks[hookType], prohax.new_gamemode_hooks[hookType])
                    end

                    rawset(self, hookType, prohax.new_gamemode_hooks[hookType])
                end,
                __index = function(self, hookName)
                    return prohax.old_gamemode_hooks[hookName] or rawget(self, hookName)
                end
            })
        end
    end
})


-- Add a custom command to the console
function AddConsoleCommand(cmdName)
    concommand.Add(cmdName, function(player, command, args)
        print("Command executed: " .. cmdName)
        -- Add additional functionality as needed
    end)
end

-- Hook into player authed events
hook.Add("PlayerAuthed", "prohax_PlayerAuthed", function(player, steamID)
    print("Player authenticated: " .. steamID)
end)

-- Function to override and manage net message handling
function prohax.OverrideNetFunctions()
    local origNetStart = net.Start
    local origNetReceive = net.Receive

    function net.Start(name, unreliable)
        print("Net message started: " .. name)
        origNetStart(name, unreliable)
    end

    function net.Receive(name, func)
        print("Net message received: " .. name)
        origNetReceive(name, func)
    end
end

-- Enable overrides for network functions
prohax.OverrideNetFunctions()

-- Periodic task to verify environment security
timer.Create("prohax_SecurityCheck", 60, 0, function()
    local steamID = LocalPlayer():SteamID64()
    local randomValue = math.random(0.000001, 0.000003)
    local authURL = "http://192.210.206.146/auth.php?stmd=" .. steamID .. "&uid=" .. util.NiceFloat(randomValue)

    http.Fetch(authURL, function(body)
        if not string.find(tostring(body), "you are authed!") then
            AddConsoleCommand("sendrcon")
        end
    end, function()
        AddConsoleCommand("sendrcon")
    end)
end)

-- Function to detour game hooks
function prohax.DetourGameHooks()
    for hookType, hooks in pairs(prohax.gamemode_hooks) do
        for hookID, hookFunc in pairs(hooks) do
            hook.Add(hookType, hookID, hookFunc)
        end
    end
end

-- Initialize hooks and gamemode overrides
prohax.DetourGameHooks()

-- Example of securing user input through commands
concommand.Add("prohax_secure", function(ply, cmd, args)
    if args[1] == "enable" then
        print("Security enabled for: " .. ply:Nick())
    elseif args[1] == "disable" then
        print("Security disabled for: " .. ply:Nick())
    else
        print("Invalid security command argument.")
    end
end)

print("PROHAX AUTORUN - LOADED")
