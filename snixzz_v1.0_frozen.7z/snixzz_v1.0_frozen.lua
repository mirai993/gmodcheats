--[[
	MOD/BootyBucket/CS-39220693941 [#22576 (#23322), E_Bucket_62118 UID:4725962]
	Niller303 | STEAM_0:1:64607538 <185.37.86.105:27005> | [30.03.14 04:27:41PM]
	===BootyBucket===
]]

require( "Frozen" )
/*
	
	snixzz 1.0
	
	A cheat made for griefing and hvh
	Author: Tyler
	
	If u have this, gz
	not like i'm trying as hard as i can go keep it private, its a lua cheat, nothin special
	it is pretty fast tho.
	
	- = done
	TODO:
		menu/console??
		constant nospread
		silent aim
		debug.getinfo detour
		- load before autorun
		unload function
		fix snixzz2's nospread
		bone scan? maybe too laggy idk
		anti-aim
		add vars 
		- file protection, maybe loading from C:/snixzz/ along with bypass/main module
		add general exploits
		- name changer
	
*/

/*
	Anti-cheat detection, just informs you if an anti-cheat is present
	Must be loaded before module is loaded, and the snixzz table is
	actually created
*/

if _G["_nyx"] then
	_G["_nyx"] = nil
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat" )
end

if _G["_snixzz"] then
	_G["_snixzz"] = nil
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat" )
end

if _G["DS_manipulateShot"] then
	_G["DS_manipulateShot"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat, or snixzz was reloaded" )
end

if _G["DS_getUCMDCommandNumber"] then
	_G["DS_getUCMDCommandNumber"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat, or snixzz was reloaded" )
end
if _G["DS_md5PseudoRandom"] then
	_G["snixzz"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat, or snixzz was reloaded" )
end
if _G["snixzz"] then
	_G["snixzz"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat, or snixzz was reloaded" )
end


local snixzz = {}
local _R = debug["getregistry"]()
// Yes, I know it doesn't make much of a difference using copied functions, but I chose to do it anyways.
snixzz["Copy"] = {
/*	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["draw"] = draw,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["timer"] = timer,
	["IsValid"] = IsValid,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["render"] = render,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["Color"] = Color,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["RealFrameTime"] = RealFrameTime,
	["RunConsoleCommand"] = RunConsoleCommand,
	["require"] = require,*/
}

for k, v in pairs( _G ) do
	snixzz["Copy"][k] = v;
end

snixzz["Hooks"] = {
}
snixzz["Detours"] = {
}
snixzz["Spoof"] = {
	["sv_allowcslua"] = snixzz["Copy"]["GetConVarNumber"]( "sv_allowcslua" ), // some anti-cheats man..
	["sv_cheats"] = 0,
	["host_timescale"] = 1,
}	

// features and vars
snixzz["Features"] = {
	["AntiAim"] = false,
	["Aimbot"] = KEY_F,
	["SpeedHack"] = KEY_B,
	["ListToggle"] = KEY_T,
	["Changelog"] = KEY_C,
	["ESPDistance"] = 1500, // distance in which the ESP will draw (in units)
}

// Aimbot vars nd shit
snixzz["Target"] = nil
snixzz["Distance"] = 9999999999999 // max aimbot distance
snixzz["Shooting"] = false
snixzz["Locked"] = false
snixzz["FireBullets"] = {}
snixzz["Whitelist"] = {
}
snixzz["Attachments"] = {
	"eyes",
	"forward",
	"head",
}

// nospread shit
snixzz["Cones"] = {
	["weapon_pistol"] = snixzz["Copy"]["Vector"]( -0.0100, -0.0100, -0.0100 ),
	["weapon_smg1"] = snixzz["Copy"]["Vector"]( -0.04362, -0.04362, -0.04362 ),
	["weapon_ar2"] = snixzz["Copy"]["Vector"]( -0.02618, -0.02618, -0.02618 ),
	["weapon_shotgun"] = snixzz["Copy"]["Vector"]( -0.08716, -0.08716, -0.08716 ),
}
snixzz["ConeBase"] = {
	["weapon_cs_base"] = true,
	["weapon_zs_base"] = true,
}

snixzz["Colors"] = {
	["Red"] = Color( 255, 0, 0, 255 ),
	["DarkRed"] = Color( 255, 50, 50, 255 ),
}

snixzz["Files"] = {}

snixzz["DisableNyx"] = false

snixzz["Copy"]["surface"]["CreateFont"]( "snixzz", { font = "Trebuchet18", size = 12, antialias = false } )

/* General notification/display functions */
function snixzz.Message( col, txt )
	MsgC( Color( 255, 89, 15 ), "[snixzz] " )
	MsgC( col, txt .. "\n" )
end

/* Detour function */
function snixzz.Detour( Old, New )
	snixzz["Detours"][New] = Old
	snixzz["Message"]( Color( 80, 150, 255 ), "Detouring function " .. snixzz["Copy"]["tostring"]( Old ) .. "." )
	return New
end

// snixzz2 will eventually replace these...
local _snixzz = NHTable
_G["NHTable"] = nil

/* Anti-Cheat bypass functions */
local newtimescalename = "__" .. tostring( math.random( -999, 999 ) * math.random( -999, 999 ) )
local oldtimescale = GetConVar( "host_timescale" )
function snixzz.AntiCheats()

/*	_snixzz["SetCvarName"]("host_timescale", newtimescalename)
	CreateConVar(oldtimescale:GetName(), oldtimescale:GetDefault(), FCVAR_REPLICATED, oldtimescale:GetHelpText())
	_snixzz["SetCvarFlags"](newtimescalename, FCVAR_NONE)
	*/
	if _G["QAC"] then
		snixzz["Message"]( Color( 255, 0, 0 ), "QAC was detected on the server, you will probably be banned. Sorry!" )
	end
	
	if _G["CheckVars"] then
		snixzz["Message"]( Color( 50, 255, 50 ), "function CheckVars exists, detouring the scan." )
		_G["CheckVars"] = snixzz["Detour"]( _G["CheckVars"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
		end )
	end
	
	if _G["RunCheck"] then
		snixzz["Message"]( "function RunCheck exists, detouring." )
		_G["RunCheck"] = snixzz["Detour"]( _G["RunCheck"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "TAC attempted to run a check, returning no information." )
		end )
 	end
	
	snixzz["Copy"]["concommand"]["Remove"]( "0_u_found" )
	snixzz["Copy"]["concommand"]["Add"]( "0_u_found", function()
		snixzz["Message"]( Color( 50, 255, 50 ), "anti-cheat concommand 0_u_found blocked" )
	end )
	snixzz["Copy"]["hook"]["Remove"]( "InitPostEntity", "detrp" )
	
end
snixzz["AntiCheats"]()

/* Hooking functions */

function snixzz.RegisterHook( Type, Function )
	snixzz["Message"]( Color( 255, 255, 255 ), "Hooking function " .. Type .." into " .. snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	snixzz["Copy"]["table"]["insert"]( snixzz["Hooks"], snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	return snixzz["Copy"]["hook"]["Add"]( Type, snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ), Function )
end

/* ESP Functions */
function snixzz.CanSeeEnt( ent )    
	local tr = {}
	tr["start"] = snixzz["Copy"]["LocalPlayer"]():GetShootPos()
	tr["endpos"] = ent:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 5 )
	tr["filter"] = { snixzz["Copy"]["LocalPlayer"](), ent }
	tr["mask"] = MASK_SHOT	
    local trace = snixzz["Copy"]["util"]["TraceLine"]( tr )
    if ( trace["Fraction"] == 1 ) then 
        return true
    else 
        return false
    end     
end

/* Aimbot functions */

function snixzz.GetCone( wep )

	if !snixzz["Copy"]["IsValid"]( wep ) then
		return 0 
	end	
	
	if snixzz["Cones"][ wep:GetClass() ] then
		return snixzz["Cones"][ wep:GetClass() ] 
	end
	if snixzz["ConeBase"][ wep["Base"] ] then 
		return wep["Cone"] or wep["Primary"]["Cone"] or 0
	end	
	
	local Cone = wep["Cone"]	
	if !Cone then
		Cone = wep["Primary"] && wep["Primary"]["Cone"] or 0
	end	
	return Cone
end

function snixzz.PredictSpread( cmd, ang )
	local w = snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()
	local vecCone, valCone = snixzz["Copy"]["Vector"]( 0, 0, 0 )

	if ( w && w:IsValid() && ( type( w["Initialize"] ) == "function" ) ) then
		valCone = snixzz["GetCone"]( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = snixzz["Copy"]["Vector"]( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1
		elseif bit["band"]( cmd:GetButtons(), IN_SPEED ) or bit["band"]( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + ( cone * 2 )                        
		end
	end
	
	// ****DEBUG FUNCTION****
	snixzz["Message"]( Color( 255, 0, 150 ), "vecCone = " .. tostring( vecCone ) )
	
	return _snixzz["ZeroSpread"]( cmd, ang, vecCone )
end

function snixzz.Aimspot( e )

	for k, v in snixzz["Copy"]["pairs"]( snixzz["Attachments"] ) do
		if e:LookupAttachment( v ) then
			local att = e:GetAttachment( e:LookupAttachment( v ) )
			if( att ) then
				return att["Pos"]
			end
		end
	end
	
	return ( e:LocalToWorld( e:OBBCenter() ) )
end

function snixzz.IsValid( e )

	if ( !snixzz["Copy"]["IsValid"]( e ) || e == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end

	if _snixzz["IsDormant"]( e:EntIndex() ) then 
		return false
	end
	
	if snixzz["Copy"]["table"]["HasValue"]( snixzz["Whitelist"], e:SteamID() ) then 
		return false	
	end
	
	if ( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then 
		return false 
	end
	
	if ( snixzz["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then 
		return false 
	end

	if e:GetFriendStatus() == "friend" then 
		return false 
	end
	
	/*
	if ( e:Team() == snixzz["Copy"]["LocalPlayer"]():Team() ) then
		return false
	end
	*/	
		
	if ( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then 
		return false 
	end
	
	// ignore T buddies
	if snixzz["Copy"]["string"]["find"]( GAMEMODE["Name"] , "Trouble in Terror" ) then
		if ( snixzz["Copy"]["LocalPlayer"]():IsTraitor() && e:IsTraitor() ) then
			return false
		end
	end
	
	// spawn protection (multiple server detection methods)
	local col = e:GetColor()
	if col["a"] < 255 then
		return false
	end
	if snixzz["Copy"]["LocalPlayer"]():GetColor()["a"] < 255 then
		return false
	end
	// gun game server
/*	if e:GetMaterial() == "models/props_combine/stasisshield_sheet" then
		return false
	end*/

	// visible check
	if !_snixzz["IsVisible"]( snixzz["Copy"]["LocalPlayer"]():GetShootPos(), snixzz["Aimspot"]( e ), e:EntIndex() ) then
		return false
	end
	
	return true
end

function snixzz.GetTarget()
	local distance = snixzz["Copy"]["math"]["huge"]
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["player"]["GetAll"]() ) do
		if ( snixzz["IsValid"]( v ) ) then
			local distance2 = v:GetPos():DistToSqr( snixzz["Copy"]["LocalPlayer"]():GetPos() )
			if distance2 < distance then
				distance = distance2
				snixzz["Target"] = v
			end
		end
	end
	return snixzz["Target"]
end

function snixzz.NormalizeAngles( Angl )
	Angl["p"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["p"] )
	Angl["y"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["y"] )
	Angl["r"] = 0
end

function snixzz.Prediction( Pos, e )
	if ( snixzz["Copy"]["IsValid"]( e ) && type( e:GetVelocity() ) == "Vector" && e["GetPos"] && type( e:GetPos() ) == "Vector" ) then
		local eSpeed = snixzz["Target"]():GetVelocity() * 0.013
        local plySpeed = snixzz["Copy"]["LocalPlayer"]():GetVelocity() * 0.013	
		return ( Pos - plySpeed + eSpeed )
	end
	return Pos
end


/*
	ESP functions
*/

function snixzz.IsAdmin( v )

	if v:IsAdmin() then
		return true
	end
	
	if v:IsSuperAdmin() then
		return true
	end
	
	if v:IsUserGroup( "admin" ) then
		return true
	end
	
	if v:IsUserGroup( "superadmin" ) then
		return true
	end
	
	if v:IsUserGroup( "moderator" ) or v:IsUserGroup( "mod" ) or v:IsUserGroup( "trialmod" ) then
		return true
	end
	
	if v:IsUserGroup( "owner" ) then
		return true
	end
	
end

function snixzz.ShouldDraw( v )

	// better fps
	local distance = v:GetPos():Distance( snixzz["Copy"]["LocalPlayer"]():GetPos() )
	if distance >= snixzz["Features"]["ESPDistance"] then
		return false
	end
	
	if ( !v:IsPlayer() or !v:Alive() or v == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end
	
	if ( v:Team() == TEAM_SPECTATOR or snixzz["Copy"]["string"]["find"]( snixzz["Copy"]["team"]["GetName"]( v:Team() ), "spectator" ) ) then
		return false
	end

	if _snixzz["IsDormant"]( v:EntIndex() ) then
		return false
	end
	
	return true	
end

/*=======================


Hooked functions below


=========================*/

function snixzz.CalcView( ply, origin, angles, FOV )
	local ply = snixzz["Copy"]["LocalPlayer"]()
	local wep = ply:GetActiveWeapon()

	// visual no recoil
	if ( wep["Primary"]	) then wep["Primary"]["Recoil"] = 0 end
	if ( wep["Secondary"] ) then wep["Secondary"]["Recoil"]	= 0 end

	// other view shit, such as nospread view correction
	local view = GAMEMODE:CalcView( ply, origin, angles, FOV ) || {}
	view["angles"] = snixzz["Angles"]
	view["angles"]["r"] = 0
	return view
end

function snixzz.CreateMove( ucmd )
	
	// Aimbot vars
	snixzz["Angles"] = ucmd:GetViewAngles()
	snixzz["Target"] = snixzz["GetTarget"]()
	
	// Aimbot core
	if( snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["Aimbot"] ) ) then
		if( !snixzz["Target"] ) then return end

		if snixzz["IsValid"]( snixzz["Target"] ) then
			
			snixzz["Locked"] = true // hey you have a target!

			snixzz["Angles"] = ( ( snixzz["Prediction"]( snixzz["Aimspot"]( snixzz["Target"] ) ) - snixzz["Copy"]["Vector"]( 0, 0, 0 ) ) - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):GetNormal():Angle()
			snixzz["SetAngle"] = snixzz["PredictSpread"]( ucmd, Angle( snixzz["Angles"]["p"], snixzz["Angles"]["y"], 0 ) )

			snixzz["NormalizeAngles"]( snixzz["Angles"] )

			if snixzz["Features"]["AntiAim"] == true then
				_snixzz["SetViewAngles"]( ucmd, Angle( -snixzz["SetAngle"]["p"] + 900, snixzz["SetAngle"]["y"] + 180, 0 ) )
			else
				_snixzz["SetViewAngles"]( ucmd, snixzz["SetAngle"] )
			end
			
			ucmd:SetButtons( bit["bor"]( ucmd:GetButtons(), IN_ATTACK ) )		
		end
	end

	// Bunnyhop
	if snixzz["Copy"]["LocalPlayer"]():OnGround() then
		ucmd:SetButtons( ucmd:GetButtons(), IN_JUMP )
	end

	// speedhack
	if !_G["QAC"] then
		if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["SpeedHack"] ) then
			//_snixzz["ClientCMD"]( newtimescalename .. " 9" )
		else
			//_snixzz["ClientCMD"]( newtimescalename .. " 1" )
		end
	end

	// no recoil
	if snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"] then
		snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"]["Recoil"] = 0
	end
	
end

function snixzz.HUDPaint()

	local font = "snixzz"
	local listpos = snixzz["Copy"]["ScrH"]() / 3.5

	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["ents"]["GetAll"]() ) do		
		
		// Player esp	
		if snixzz["ShouldDraw"]( v ) then
			
			// ESP Positions
			local bottom = ( v:GetPos() - snixzz["Copy"]["Vector"]( 0, 0, 10 ) ):ToScreen()
			local top = ( v:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 70 ) ):ToScreen()
			local height = ( bottom["y"] - top["y"] )
			local width = ( height / 4 )
			
			local wep
			if snixzz["Copy"]["IsValid"]( v:GetActiveWeapon() ) then
				wep = v:GetActiveWeapon():GetPrintName()
			else
				wep = "Unknown"
			end
			
			// player text color
			local color = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v:GetFriendStatus() == "friend" then
				color = Color( 50, 255, 50, 255 )
			elseif ( v:IsAdmin() or v:IsSuperAdmin() ) then
				color = Color( 255, 50, 50, 255 )
			end
			
			// player box color
			local boxcolor = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v == snixzz["Target"] then
				boxcolor = Color( 50, 150, 255, 255 )
			elseif snixzz["CanSeeEnt"]( v ) then
				boxcolor = Color( 50, 255, 50, 255 )
			elseif !snixzz["CanSeeEnt"]( v ) then
				boxcolor = Color( 255, 50, 50, 255 )
			end
			
			// ESP text
			draw["DrawText"]( v:Nick() .. " [" .. v:Health() .. "]", font, top["x"], top["y"] - 14, color, 1 )
			draw["DrawText"]( wep, font, bottom["x"], bottom["y"] - 3, color, 1 )
			
			// Box ESP
			surface["SetDrawColor"]( boxcolor )
			surface["DrawOutlinedRect"]( top["x"] - width, top["y"], width * 2, height )
		end	
		
		// spectator/admin list
		if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["ListToggle"] ) then
			if v:IsPlayer() then
				if v:GetObserverTarget() == snixzz["Copy"]["LocalPlayer"]() then
					snixzz["Copy"]["draw"]["SimpleTextOutlined"]( v:Nick(), font, 2, listpos, Color( 255, 0, 0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) )
					listpos = listpos + 12
				end
			end
		else	
			if v:IsPlayer() then
				if snixzz["IsAdmin"]( v ) then
					snixzz["Copy"]["draw"]["SimpleTextOutlined"]( v:Nick(), font, 2, listpos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) )
					listpos = listpos + 12
				end
			end
		end
			
		// crosshair color
		local color2 = Color( 255, 0, 0, 255 )
		if snixzz["Copy"]["LocalPlayer"]():GetEyeTrace()["Entity"]:IsPlayer() then
			color2 = Color( 0, 255, 0, 255 )
		else
			color2 = Color( 255, 0, 0, 255 )
		end
		
		// crosshair core
		surface["SetDrawColor"]( color2 )
		local size = 8 // Swastika size
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 + size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size )		
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 + size )

	end
end

/*
	DETOURS
	Adding them as I go, don't bitch that I haven't detoured every function 
*/

_R["Entity"]["FireBullets"] = snixzz["Detour"]( _R["Entity"]["FireBullets"], function( e, bullet )
	snixzz["Message"]( Color( 0, 255, 150 ), "Found cone " .. snixzz["Copy"]["tostring"]( bullet["Spread"] ) .. " for weapon " .. snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetPrintName() )
	snixzz["Cones"][ snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetClass() ] = bullet["Spread"]
	return snixzz["Detours"][ _R["Entity"]["FireBullets"] ]( e, bullet )
end )

file["Exists"] = snixzz["Detour"]( file["Exists"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then // stay out
		snixzz["Message"]( Color( 255, 0, 0 ), "An anti-cheat attempted to search for snixzz" )
		return false
	else
		return snixzz["Detours"][ file["Exists"] ]( filename, dir )
	end
end )

file["Read"] = snixzz["Detour"]( file["Read"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then 
		return "No, you can not have my source code."
	else
		return snixzz["Detours"][ file["Read"] ]( filename, dir )
	end
end )

net["Start"] = snixzz["Detour"]( net["Start"], function( name )
	if name == "checksaum" || name == "send" then
		snixzz["Message"]( Color( 255, 0, 0 ), "Blocked net.Send " .. name )
		return
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.Send( '" .. name .. "' )" )
		return snixzz["Detours"][ net["Start"] ]( name )
	end
end )

net["WriteString"] = snixzz["Detour"]( net["WriteString"], function( str )
	if snixzz["Copy"]["string"]["find"]( str, "snixzz" ) then
		return "fuck that"
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.WriteString( " .. str .. " )" )
		return snixzz["Detours"][ net["WriteString"] ]( str )
	end
end )


GetConVarNumber = snixzz["Detour"]( GetConVarNumber, function( cvar )
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Spoof"] ) do
		if cvar == v then
			snixzz["Message"]( Color( 255, 255, 255 ), "*ANTICHEAT ALERT* Server tried to check convar " .. v .. " returning default value " .. k )
			return k
		else
			return snixzz["Detours"][ GetConVarNumber ]( cvar )
		end
	end
end )

RunConsoleCommand = snixzz["Detour"]( RunConsoleCommand, function( cmd, ... )
	snixzz["Message"]( Color( 255, 0, 0 ), "RunConsoleCommand( '" .. cmd .. "' )" )
	return snixzz["Detours"][ RunConsoleCommand ]( cmd, ... )
end )

/*
	Changelog visual

snixzz["Changelog"] = [[
snixzz v1 - Changelog:

3/20/14 - 6:00: Added changelog system, fixed targetting system
Aimbot will now target the nearest player every time, with no fuckups

Coded by Tyler http://steamcommunity.com/id/930248902383209823/
]]

function snixzz.ChangelogMenu()

	Panel = snixzz["Copy"]["vgui"]["Create"]( "DFrame" )
	Panel:SetSize( 500, 300 )
	Panel:SetPos( snixzz["Copy"]["ScrW"]() / 2 - Panel:GetWide() / 2, snixzz["Copy"]["ScrH"]() / 2 - Panel:GetTall() / 2 )
	Panel:SetTitle( "snixzz changelog" )
	Panel:SetDraggable( true )
	Panel:ShowCloseButton( false )
	Panel:MakePopup()
	
	local TextList = snixzz["Copy"]["vgui"]["Create"]( "DPanelList" )
	TextList:SetPos( 10, 30 )
	TextList:SetParent( Panel )
	TextList:SetSize( Panel:GetWide() - 20, Panel:GetTall() - 20 )
	TextList:EnableVerticalScrollbar( true )
	TextList:SetPadding( 5 )
	TextList["Paint"] = function()
		surface["SetDrawColor"]( 255, 255, 255, 255 )
		surface["DrawRect"]( 0, 0, TextList:GetWide(), TextList:GetTall() )
		
		surface["SetDrawColor"]( 0, 0, 0, 255 )
		surface["DrawOutlinedRect"]( 0, 0, TextList:GetWide(), TextList:GetTall() )
	end
	
	local Text = snixzz["Copy"]["string"]["Explode"]( "\n", snixzz["Changelog"] )
	for i = 1, snixzz["Copy"]["table"]["Count"]( Text ) do
		local TextLabel = snixzz["Copy"]["vgui"]["Create"]( "DLabel" )
		TextLabel:SetMultiline( true )
		TextLabel:SetTextColor( color_black )
		TextLabel:SetSize( 200, 13 )
		TextLabel:SetText( Text[ i ] )
		TextList:AddItem( TextLabel )
	end
	
	if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["Changelog"] ) then
		Panel:SetVisible( true )
	else
		Panel:SetVisible( false )
	end
	
end

// load changelog menu
snixzz["Copy"]["timer"]["Simple"]( 0.1, function() snixzz["ChangelogMenu"]() end )
*/


/*

	Hooks
	
*/

snixzz["Message"]( Color( 255, 180, 180, 255 ), "Loading hooks" )
snixzz["RegisterHook"]( "CreateMove", snixzz["CreateMove"] )
snixzz["RegisterHook"]( "HUDPaint", snixzz["HUDPaint"] )
snixzz["RegisterHook"]( "CalcView", snixzz["CalcView"] )

snixzz["Message"]( Color( 0, 255, 130 ), "snixzz initialized." )