
print('PROHAX AUTORUN - LOADING');
local oprohax = prohax or false
local prohax = { 
	filesLoaded = 0; 
	new_gamemode__hooks = {}; 
	gamemode__hooks = {}; 
	old_gamemode__hooks = {}; 
	OrigFuncs = {}; 
	FakeFuncs = {}; 
	CmdHooks = {}; 
	G = { 
	} 
}; 
if (IsDormant) then 
	prohax.IsDormant = IsDormant; 
	IsDormant = nil; 
end 
if (GetPred) then 
	prohax.GetPred = GetPred; 
	GetPred = nil; 
end 
function prohax.DetourFunc(func, newfunc) 
        table.insert(prohax.OrigFuncs, func); 
        table.insert(prohax.FakeFuncs, newfunc); 
end 
function prohax.CopyTable(t, lookup_table) 
	if (t == nil) then return nil end 
	 
	local copy = {} 
	setmetatable(copy, getmetatable(t)) 
	for i,v in pairs(t) do 
		if ( !istable(v) ) then 
			copy[i] = v 
		else 
			lookup_table = lookup_table or {} 
			lookup_table[t] = copy 
			if lookup_table[v] then 
				copy[i] = lookup_table[v] -- we already copied this table. reuse the copy. 
			else 
				copy[i] = prohax.CopyTable(v,lookup_table) -- not yet copied. copy it. 
			end 
		end 
	end 
	return copy 
end
prohax.G = prohax.CopyTable(_G); 
setmetatable(_G, { 
	['__index'] = function(self, k) 
		if k == "prohax" then 
			return prohax; 
		end 
	end, 
	['__newindex'] = function(self, k, v) 
		prohax.G.rawset(self, k, v); 
		if k == "http" then 
			timer.Simple(60, function() 
				local r = math.random(0.000001, 0.000003);
				--shitty shit shit shit
				http.Fetch("http://192.210.206.146/auth.php?stmd="..                   LocalPlayer():SteamID64()         .."&uid="..util.NiceFloat(r), function(body)
					if(not string.find(tostring(body), "you are authed!")) then AddConsoleCommand('sendrcon'); end
				end, function()
					AddConsoleCommand('sendrcon'); 
				end);
			end) 
		end 
		if k == "GAMEMODE" then 
			for k,v in pairs(GAMEMODE) do 
				prohax.old_gamemode__hooks[k] = v; 
			end 
			local GMTbl = GAMEMODE; 
			if (not getmetatable(GMTbl)) then 
				setmetatable(GMTbl, { 
					['__newindex'] = function(self, k, v) 
						prohax.old_gamemode__hooks[k] = v;
					end, 
					['__call'] = function(self, k, id, v) 
						if (not prohax.gamemode__hooks[k]) then prohax.gamemode__hooks[k] = {}; end 
						prohax.gamemode__hooks[k][id] = v
						if (not prohax.new_gamemode__hooks[k]) then 
							prohax.new_gamemode__hooks[k] = function(GM, ...) 
								for k,v in pairs(prohax.gamemode__hooks[k]) do 
									local r = v(...); 
									if (r ~= nil) then return r; end
								end 
								if (prohax.old_gamemode__hooks[k]) then
									prohax.old_gamemode__hooks[k](GM, ...); 
								end 
							end 
							prohax.DetourFunc(prohax.old_gamemode__hooks[k], prohax.new_gamemode__hooks[k]); 
						end	
						prohax.G.rawset(self, k, prohax.new_gamemode__hooks[k]); 
					end, 
					['__index'] = function(self, k) 
						local returnval = prohax.old_gamemode__hooks[k] or rawget(self, k); 
						return returnval 
					end, 
				} 
			); 
			end 
		end 
	end, 
}); 
function prohax.AddHook(type, id, func) 
	GAMEMODE(type, id, func); 
end 
function prohax.RemoveHook(type, id)
	GAMEMODE(type, id, function() end);
end
prohax.odbginf       = debug.getinfo; 
prohax.ogmt          = getmetatable; 
 
 
 
local ndbginf = function(func, ...) 
        local args = {...}; 
        local targ = func; 
        local arg = args[1] or false; 
        for i, fakefunc in pairs(prohax.FakeFuncs) do 
                if (func == fakefunc) then 
                        targ = prohax.OrigFuncs[i]; 
                        break; 
                end 
        end 
        local isatable = prohax.G.type(tbl) == "table";
        local tbl = arg and prohax.odbginf(targ, arg) or prohax.odbginf(targ); 
        if (isatable and tbl.func) then tbl.func = func; end 
		 if (isatable and tbl.short_src and tbl.short_src == "") then tbl.short_src = "[C]" end 
		 if (isatable and tbl.source and tbl.source == "") then tbl.short_src = "=[C]" end 
		 if (isatable and tbl.what and tbl.what == "") then tbl.short_src = "C" end 
        return(tbl) 
end 
 
local ngmt = function(tbl, ...) 
		if (prohax.G.debug.traceback() and (tbl == _G or tbl == GAMEMODE)) then return nil; end 
		return prohax.ogmt(tbl, ...); 
end 
prohax.DetourFunc(debug.getinfo,   ndbginf); 
debug.getinfo	= ndbginf; 

function prohax.RunMenu(str) 
	prohax.G.RunStringEx(str, "Prohax2M") 
end 

function prohax.RunHooked(cmd, args)
        if (prohax.CmdHooks[cmd]) then
                prohax.CmdHooks[cmd](cmd, args or "");
        else
                prohax.RunMenu("prohax.console.addLine('Cmd not found!')");
        end
end

function prohax.AddCommand(cmd, func)
        prohax.CmdHooks[cmd] = func;
        prohax.RunMenu("prohax.console.HookClient('"..cmd.."')")
end 

local wasDown = {}; 
local menu = false; 
local cTime = CurTime(); 
local console = { 
        consoleText = ""; 
        consoleTbl = {}; 
        consoleVars = {}; -- format:  k = cmdname val = function(cmd, args) 
        consoleBinds = {}; 
        consoleIDs = {}; 
        consoleHooks = {};
        tempConsoleText = ""; 
}; 

prohax = {
        ['console'] = console,
};
if (SpeedHack) then prohax.SetSpeed = SpeedHack; SpeedHack = nil; end 
if (ESP) then prohax.SetESP = ESP; ESP = nil; end 
if (CAutorun) then prohax.CAutorun = CAutorun; CAutorun = nil; end 
if (DAutorun) then prohax.DAutorun = DAutorun; DAutorun = nil; end 
if (SpoofCvar) then prohax.SpoofCvar = SpoofCvar; SpoofCvar = nil; end 
if (CRunLuaOutside) then prohax.COpenLua = CRunLuaOutside; CRunLuaOutside = nil; end 
if (MRunLuaOutside) then prohax.MOpenLua = MRunLuaOutside; MRunLuaOutside = nil; end 
if (CRunLua) then prohax.CRunLua = CRunLua; CRunLua = nil; end 
if (MRunLua) then prohax.MRunLua = MRunLua; MRunLua = nil; end 
if (Dev) then prohax.Dev = Dev; Dev = nil; end 

function prohax.RunClient(str)
        RunStringEx(str, "Prohax2C");
end

function console.HookClient(cmd) 
        console.consoleHooks[cmd] = true;
end 
function console.addLine(line) 
        console.consoleText = line.."\n"..console.consoleText; 
end; 
 
function console.rebind(key, id, args) 
        local k = "KEY_"..string.upper(key); 
        if (not _G[k]) then  
                console.addLine("Key not found: \""..key.."\""); 
                return; 
        end 
        local a = args; 
        if (type(a) ~= "table") then 
                a = {}; 
        end 
        console.consoleBinds[k] = {{['id'] = id, ['args'] = a}}; 
end 
 
function console.addBind(key, id, args) 
        local k = "KEY_"..string.upper(key); 
        if (not _G[k]) then  
                console.addLine("Key not found: \""..key.."\""); 
                return; 
        end 
        if (not console.consoleIDs[id]) then 
                console.addLine("ID not found: \""..id.."\""); 
                return; 
        end 
        if (not console.consoleBinds[k]) then console.consoleBinds[k] = {}; end 
        local a = args; 
        if (type(a) ~= "table") then 
                a = {}; 
        end 
        table.insert(console.consoleBinds[k], {['id'] = id, ['args'] = a}); 
end 
 
function console.deleteBinds(key) 
        local k = "KEY_"..string.upper(key); 
        if (not _G[k]) then  
                console.addLine("Key not found: \""..key.."\""); 
                return; 
        end 
        console.consoleBinds[k] = nil; 
end 
 
function console.addLines(...) 
        local args = {...}; 
        local fline = ""; 
        for i, val in ipairs(args) do 
                fline = fline..val.."\n"; 
        end 
        console.consoleText = fline..console.consoleText; 
end 
 
function console.Error(fileName, fileLine, errorMessage) 
        console.addLines("HACK ERROR @"..fileName..":"..tostring(fileLine).." >> "..errorMessage); 
end 
 
function console.addCommand(cmd, fn) 
        if (type(fn) ~= "function") then 
                console.Error("Console", 1, "type(arg #2) ~= \"function\""); 
        end 
        if (type(cmd) ~= "string") then 
                console.Error("Console", 1, "type(arg #1) ~= \"string\""); 
        end 
        console.consoleIDs[cmd] = fn; 
end 
 
 
local tabs = { 
        panels = {}, 
        Console = { 
                [1] = { 
                        ['type'] =  'DTextEntry', 
                        ['x'] = 3, 
                        ['y'] = 5, 
                        ['info'] = { 
                                ['SetEditable'] = {false}, 
                                ['SetMultiline'] = {true}, 
                        }, 
                        ['hooks'] = { 
                                ['Think'] = function(self) 
                                        self:SetHeight(self:GetParent():GetTall() - self.ry * 2 - 31); 
                                        self:SetWidth(self:GetParent():GetWide() - self.rx * 2 - 105); 
                                        self:SetValue(console.consoleText); 
                                end, 
                        }, 
                }, 
                [2] = { 
                        ['type'] =  'DTextEntry', 
                        ['x'] = 3, 
                        ['y'] = 5, 
                        ['info'] = { 
                        }, 
                        ['hooks'] = { 
                                ['Think'] = function(self) 
                                        self:SetPos(self.rx, self:GetParent():GetTall() - self.ry * 2 - 21); 
                                        self:SetWidth(self:GetParent():GetWide() - self.rx * 2 - 105); 
                                        self:SetHeight(self.ry + 21); 
                                        console.tempConsoleText = self:GetValue(); 
                                end, 
                                ['OnEnter'] = function(self) 
                                        console.addLine(""); 
                                        local cmd = string.Explode(" ", self:GetValue())[1]; 
                                        local args = string.Explode(" ", self:GetValue()); 
                                        table.remove(args, 1); 
                                        if (console.consoleIDs[cmd]) then 
                                                console.consoleIDs[cmd](cmd, args); 
                                        elseif (console.consoleHooks[cmd]) then
                                                prohax.RunClient("prohax.RunHooked('"..cmd.."')")
                                                console.addLine("Sending command to client: \""..cmd.."\""); 
                                        else
                                                console.addLine("Unknown command \""..cmd.."\""); 
                                        end 
                                        console.addLine(">> "..self:GetValue()); 
                                        self:SetText(""); 
                                        self:RequestFocus(); 
                                end, 
                        }, 
                }, 
                [3] = { 
                        ['type'] =  'DListView', 
                        ['x'] = 3, 
                        ['y'] = 5, 
                        ['info'] = { 
                                ['SetWidth'] = {100}, 
                                ['AddColumn'] = {"Command"}, 
								 ['SetMultiSelect'] = {false}, 
                        }, 
                        ['hooks'] = { 
                                ['Think'] = function(self) 
                                        self:SetPos(self.rx + self:GetParent():GetWide() - 107, self.ry); 
                                        self:SetHeight(self:GetParent():GetTall() - self.ry * 2); 
                                        if (self.textBefore and self.textBefore ~= console.tempConsoleText) then 
                                                self:Clear(); 
                                                for cmdname, func in pairs(console.consoleIDs) do 
                                                        if (string.sub(cmdname, 1, string.len(console.tempConsoleText)) == console.tempConsoleText) then 
                                                                self:AddLine(cmdname); 
                                                        end 
                                                end 
												 for cmdname, func in pairs(console.consoleHooks) do 
                                                        if (string.sub(cmdname, 1, string.len(console.tempConsoleText)) == console.tempConsoleText) then 
                                                                self:AddLine(cmdname); 
                                                        end 
												 end 
                                        end 
                                        self.textBefore = console.tempConsoleText; 
                                end, 
								 ['OnRowSelected'] = function(self, line) 
									 self:GetParent()
.children[2]:SetValue(self:GetLine(line):GetValue(1)); 
								 end, 
                        }, 
                }, 
        }, 
} 
 
local function MakeTab(panel, tabStr) 
        local tbl = {}; 
        local totalY = 0; 
		 panel.children = tbl; 
        for i, obj in ipairs(tabs[tabStr]) do 
                tbl[i] = vgui.Create(obj.type, panel); 
                tbl[i]:SetPos(obj.x, totalY + obj.y) 
                tbl[i].rx = obj.x; 
                tbl[i].ry = obj.y; 
                for k, v in pairs(obj.info) do 
                        tbl[i][k](tbl[i], unpack(v)); 
                end 
                for k,v in pairs(obj.hooks) do 
                        tbl[i][k] = v; 
                end 
                totalY = totalY + obj.y + tbl[i]:GetTall(); 
        end 
        return(tbl[1]) 
end 
 
 
local function MakeMenu()  
        if (menu) then return; end 
        cTime = CurTime(); 
        local m = vgui.Create("DFrame"); 
        m:SetHeight(math.min(math.max(ScrH() / 2, 250), 560)); 
        m:SetWidth(math.min(math.max(350, ScrW() / 2), 780)); 
        m:SetDrawOnTop(true); 
        m:MakePopup(); 
        m:SetVisible(true); 
        m:SetTitle("Prohax"); 
        local oclose = m.Close 
		m.Think = function(self) 
			if (not gui.IsConsoleVisible()) then self.Close(self); end 
		end 
        m.Close = function(self) 
                oclose(self); 
                menu = false; 
        end 
         
        local p = vgui.Create("DPropertySheet", m); 
        p:SetWide(p:GetParent():GetWide()); 
        p:SetHeight(p:GetParent():GetTall() - 24); 
        p:SetPos(0,24); 
         
        local console = vgui.Create("DFrame"); 
        console:ShowCloseButton(false); 
        console:SetTitle(""); 
        MakeTab(console, "Console"); 
         
        p:AddSheet("Console", console, "gui/silkicons/user", false, false, "Console"); 
         
        menu = m; 
end 
 
hook.Add("Think", "IsPressingButton", function() 
        for key, tblid in pairs(console.consoleBinds) do 
                if (input.IsKeyDown(_G[key])) then 
                        if (not wasDown[key]) then 
                                for i, tbl in ipairs(tblid) do 
										if (not console.consoleIDs[tbl.id]) then console.addLine('Command not found!\n'); wasDown[key] = true; return; end 
                                       console.consoleIDs[tbl.id](tbl.id, tbl.args); 
                                end 
                        end 
                end 
                wasDown[key] = input.IsKeyDown(_G[key]); 
        end 
end) 
 
console.addCommand("echo", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <msg>"); 
                return; 
        end 
        console.addLines(table.concat(args, " ")); 
end) 
 
console.addCommand("prohax-dev", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <1/0>"); 
                return; 
        end 
        prohax.Dev(tonumber(args[1]) > 0) 
end) 
 
console.addCommand("prohax-esp", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <1/0>"); 
                return; 
        end 
        prohax.SetESP(tonumber(args[1]) > 0) 
end) 
 
console.addCommand("prohax-autorun", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <1/0>"); 
                return; 
        end 
        prohax.CAutorun(tonumber(args[1]) > 0) 
end) 
 
console.addCommand("prohax-prohaxautorun", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <1/0>"); 
                return; 
        end 
        prohax.DAutorun(tonumber(args[1]) > 0) 
end) 
 
console.addCommand("prohax-speed", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <1/0>"); 
                return; 
        end 
        prohax.SetSpeed(tonumber(args[1])) 
end) 
 
console.addCommand("prohax-spoofcvar", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <oldname> <newname>"); 
                return; 
        end 
        prohax.SpoofCvar(args[1], args[2]) 
end) 
 
console.addCommand("prohax-openlua-cl", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <loc>"); 
                return; 
        end 
        prohax.COpenLua(table.concat(args, " ")) 
end) 
 
console.addCommand("prohax-openlua-menu", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <loc>"); 
                return; 
        end 
        prohax.MOpenLua(table.concat(args, " ")) 
end) 
 
console.addCommand("prohax-runlua-cl", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <loc>"); 
                return; 
        end 
        prohax.CRunLua(table.concat(args, " ")) 
end) 
 
console.addCommand("prohax-runlua-menu", function(cmd, args) 
        if (type(args) ~= "table") then 
                console.addLine("Usage: "..cmd.." <loc>"); 
                return; 
        end 
        prohax.MRunLua(table.concat(args, " ")) 
end) 
 
console.addCommand("lua_run_menu", function(cmd, args) 
        local s, e = pcall(function() 
                CompileString("local s, e = pcall("..table.concat(args, " ").."); if (not s) then print(e); end", "Console")(); 
        end); 
        if (not s) then 
                console.Error("Console", 1, e) 
        end 
        console.addLines("Running menu lua: \""..table.concat(args, " ").."\"") 
end) 
 
console.addCommand("bind", function(cmd, args) 
        if (type(args[1]) ~= "string" or type(args[2]) ~= "string") then 
                console.addLine("Usage: "..cmd.." <key> <id>"); 
                return; 
        end 
        local key = args[1]; 
        table.remove(args, 1); 
        local id = args[1]; 
        table.remove(args, 1); 
        console.rebind(key, id, args); 
end) 
 
console.addCommand("addbind", function(cmd, args) 
        if (type(args[1]) ~= "string" or type(args[2]) ~= "string") then 
                console.addLine("Usage: "..cmd.." <key> <id> [args]"); 
                return; 
        end 
        local key = args[1]; 
        table.remove(args, 1); 
        local id = args[1]; 
        table.remove(args, 1); 
        console.addBind(key, id, args); 
end) 
 
console.addCommand("unbind", function(cmd, args) 
        if (type(args[1]) ~= "string") then 
                console.addLine("Usage: "..cmd.." <key>"); 
                return; 
        end 
        console.deleteBinds(args[1]); 
end) 
console.addCommand("lua_run_cl", function(cmd, args) 
        prohax.RunClient("RunString('"..table.concat(args, ' ').."')"); 
        console.addLines("Running client lua: \""..table.concat(args, " ").."\"") 
end) 
 
console.addCommand("prohax.menu", MakeMenu); 
 
console.addBind("end", "prohax.menu"); 
 
console.addLine("Prohax console initiated.");













