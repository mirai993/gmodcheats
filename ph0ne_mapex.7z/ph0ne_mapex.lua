--[[
	lua/bleebloob.lua
	Mythik | (STEAM_0:1:34050149)
	===DStream===
]]


if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.
local _R = debug.getregistry();

local mapex    = {} -- C is for CHEAT.
mapex.Commands = {}
mapex.ConVars  = {}
mapex.Hooks    = {}
mapex.MenuInfo = {}
mapex.Meta	   = { _G, hook, concommand, debug, file }
mapex.Settings = {}
mapex.World	   = { players = {} }

--[ RESET METATABLES ]--

function mapex:UnlockMeta()
	for i = 1, table.Count( mapex.Meta ) do
		rawset( mapex.Meta[i], "__metatable", false )
	end
end
mapex:UnlockMeta()

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand


mapex.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

mapex.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "mapex_"
}

function mapex:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

function mapex:AddCommand( name, func )
	return concommand.Add(name,func);
end


mapex.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_silent", Value = 1, Desc = "Silent Aim", Type = "bool", Table = "aimsilent", Menu = "aim" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
}

function mapex:CreateConVars()
	local tbl = mapex.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = mapex.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		mapex.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		mapex.MenuInfo[pvar] = cvarinfo
		mapex.MenuInfo[#mapex.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			mapex.Settings[v.Table] = new
		end )
	
		mapex.ConVars[pvar] = convar
	end
end
mapex:CreateConVars()

MsgC( Color( 255, 255, 255 ),":: " )
MsgC(  Color( 255, 0, 0 ),"Convars created.\n" )


function mapex:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

function mapex:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function mapex:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function mapex:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function mapex:IsTraitor( e )
	local ply = LocalPlayer()
	if not mapex:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function mapex:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( mapex.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if mapex:IsAdmin( e ) and mapex:G( mapex.Settings['ignoreadmins'], 1 ) then return false end
		if mapex:IsTraitor( e ) and mapex:G( mapex.Settings['ignoretraitors'], 1 ) then return false end
		if mapex:IsFriend( e ) and mapex:G( mapex.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and mapex:G( mapex.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not mapex:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if mapex:IsAdmin( e ) and mapex:G( mapex.Settings['ignoreadmins'], 1 ) then return false end
		if mapex:IsTraitor( e ) and mapex:G( mapex.Settings['ignoretraitors'], 1 ) then return false end
		if mapex:IsFriend( e ) and mapex:G( mapex.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and mapex:G( mapex.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

mapex.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function mapex:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function mapex:GetTargetLocation( e )
	for i = 1, table.Count( mapex.ZombieModels ) do
		if ( e:GetModel() == mapex.ZombieModels[i][1] ) then return mapex:GetPosition( e, mapex.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = mapex:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = mapex:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return mapex:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

--[ PREDICTION ]--

function mapex:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

--[ AUTOWALL ]--

function mapex:IsPenetrable( tr ) -- Thanks noPE.
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function mapex:TargetVisible( e )
	local ply = LocalPlayer()
	if mapex:G( mapex.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( mapex:G( mapex.Settings['autowall'], 1 ) and mapex:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function mapex:GetAimTarget()
	if mapex:IsTargetValid( mapex.Vars.target, "aim" ) and mapex:TargetVisible( mapex.Vars.target ) then return mapex.Vars.target else mapex.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if mapex:G( mapex.Settings['aim'], 1 ) then
		for i = 1, table.Count( mapex.World.players ) do
			local e = mapex.World.players[i]
			if mapex:IsTargetValid( e, "aim" ) and mapex:TargetVisible( e ) then
				local pos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function mapex:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if mapex:G( mapex.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( mapex.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function mapex.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	mapex.Vars.aacorrectang = ply:GetAimVector():Angle()
	mapex.Vars.fakeang = ply:GetAimVector():Angle()
end
mapex:AddHook( "OnToggled", mapex.OnToggled )

--[ AIMBOT ]--

function mapex.Aimbot( cmd )
	local ply, tar = LocalPlayer(), mapex:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	mapex.Vars.fakeang.p = math.Clamp( mapex.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	mapex.Vars.fakeang.y = math.NormalizeAngle( mapex.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex:G( mapex.Settings['antiaim'], 0 ) then
		mapex.Copy.SetViewAngles( cmd, mapex.Vars.fakeang )
	end
	if mapex:G( mapex.Settings['aim'], 1 ) and ply:Alive() and tar then
		mapex.Vars.target = tar
		mapex.Vars.found = true
		local pos = mapex:GetTargetLocation( tar ) + mapex:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( mapex.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		mapex.Vars.aimingang = ang
		ang = mapex:GetSmoothAngle( ang )
		if mapex:G( mapex.Settings['nospread'], 1 ) and mapex:G( mapex.Settings['aimsmooth'], 0 ) then
			ang = mapex:PredictSpread( cmd, ang )
		end
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		if mapex:G( mapex.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				mapex.Copy.SetViewAngles( cmd, ang )
				mapex.Vars.aimlocked = true
			else
				mapex.Vars.aimlocked = false
			end
		else
			mapex.Copy.SetViewAngles( cmd, ang )
			mapex.Vars.aimlocked = true
		end
		if mapex:G( mapex.Settings['autoshoot'], 1 ) and not mapex.Vars.firing then
			RunConsoleCommand( "+attack" )
			mapex.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				mapex.Vars.firing = false
			end )
		end
	else
		mapex.Vars.target = nil
		mapex.Vars.aimlocked = false
		mapex.Vars.found = false
	end
	if mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( mapex.Vars.aimingang - mapex.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end
concommand.Add("+mapex_derp", mapex.Aimbot)

--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function mapex.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {}
	if mapex:G( mapex.Settings['calcview'], 1 ) then
		if mapex.Vars.pkfake and mapex:IsTTT() then
			view.angles = mapex.Vars.pkfakeang
		elseif mapex.Vars.aimlocked and mapex:G( mapex.Settings['aimsmooth'], 1 ) and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		elseif mapex.Vars.aimlocked and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = mapex.Vars.aimingang
		elseif mapex:G( mapex.Settings['aimsilent'], 1 ) or mapex:G( mapex.Settings['antiaim'], 1 ) then
			view.angles = mapex.Vars.fakeang
		elseif mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex:G( mapex.Settings['novisrecoil'], 1 ) then
			view.angles = mapex.Vars.fakeang
		elseif mapex:G( mapex.Settings['novisrecoil'], 1 ) and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		else
			view = GAMEMODE:CalcView( e, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
mapex:AddHook( "CalcView", mapex.CalcView )


--[[--------------------------------------------
	PLAYERS AND ENTITIES
--]]--------------------------------------------

function mapex.GetAllPlayers()
	mapex.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( mapex.World.players, e ) end
	end
end

--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function mapex.CreateMove( cmd )
	mapex.Aimbot( cmd )
end
mapex:AddHook( "CreateMove", mapex.CreateMove )

function mapex.ThinkHook()
	mapex.GetAllPlayers()
end
mapex:AddHook( "Think", mapex.ThinkHook )


asdasdasdasdasd