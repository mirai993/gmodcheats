--[[
	Product:	Odius ( former MSBot/ShittyHack )
	State:		Terrible Alpha
	Author:		noPE
	TODO:		Replace traces with something less laggy
				Traitor detection
				Chams
				Menu
				Put everything in a table asdfffffffffff
]]

-- include and require some shit --
include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )
require ( "nawpie" )
require ( "hera" )

-- asdf --
local math = math
local string = string
local debug = debug
local table = table
local pcall = pcall
local error = error
local ErrorNoHalt = ErrorNoHalt
local MsgN = MsgN
local Msg = Msg
local print = print
local surface = surface
local util = util
local type = type
local RunConsoleCommand = RunConsoleCommand
local CreateClientConVar = CreateClientConVar
local CreateConVar = CreateConVar
local pairs = pairs
local ipairs = ipairs
local SortedPairs = SortedPairs

-- Tables --
local Odius = {}
Odius.Hook = {}
Odius.Hooks = {}
Odius.Concommand = {}
Odius.NoSpread = {}
Odius.FilterEnts = { LocalPlayer() }
Odius.NormalSpreadCones = {
	["weapon_cs_base"] = true,
	["darkland_base"] = true,
	["weapon_tttbase"] = true,
	["kermite_base"] = true,
	["kermite_base2"] = true,
	["weapon_real_base"] = true
}

-- Even more locals --
Odius.Aim_Target = nil
Odius.Aim_Locked = false
Odius.Aim_Aiming = false
Odius.CalcView_RealAngle = Vector( 0, 0, 0 )

-- Backing up some LUA shit --
Odius.Hook.Add = hook.Add
Odius.Hook.Remove = hook.Remove
Odius.Concommand.Add = concommand.Add

-- Overriding some gmcl_nawpie stuff --
if package.loaded.nawpie then
	Odius.NoSpread.ShotManip = hl2_shotmanip
	Odius.NoSpread.Prediction = hl2_ucmd_getprediciton
	_G.hl2_shotmanip = nil
	_G.hl2_ucmd_getprediciton = nil
	package.loaded.nawpie = nil
end

-- Local CVars --
local Aim_NoSpread = CreateClientConVar( "nope_aim_nospread", 1, true, false )
local Aim_Deathmatch = CreateClientConVar( "nope_aim_deathmatch", 1, true, false )
local Aim_ProtectBuddies = CreateClientConVar( "nope_aim_ignorebuddies", 1, true, false )
local ESP = CreateClientConVar( "nope_esp_enabled", 1, true, false )
local ESP_Info_Box = CreateClientConVar( "nope_esp_box", 1, true, false )
local ESP_Target_Players = CreateClientConVar( "nope_esp_players", 1, true, false )
local ESP_Target_NPCs = CreateClientConVar( "nope_esp_npcs", 1, true, false )

-- Copy all Hera stuff into a local table, for security reasons --
if package.loaded.hera then
	Odius.Hera = table.Copy( hera )
	_G.hera = {}
	package.loaded.hera = nil
end

-- Empty vars --
local Aim_Enabled

-- Yay fonts --
surface.CreateFont( "CenterPrintText" , 17 , 700 , true , false , "ESP_Name", false, true ) 

local function RandomString()
	local j, r = 0, ""
		
	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

/***************************************************
	Method:		AddHook
	Purpose:	Inserts a hook into a table for
				later use and adds it to the game
***************************************************/
function Odius:AddHook( h, f )
	local n = RandomString()
		
	Odius.Hooks[n] = h
	Odius.Hook.Add( h, n, f )
end

/***************************************************
	Method:		AddConcommand
	Purpose:	Adds a concommand
***************************************************/
function Odius:AddConcommand( concomm, func )
	Odius.Concommand.Add( concomm, func )
end


/***************************************************
	Method:		GetHeadPos
	Purpose:	Get head position of an entity
***************************************************/
function Odius:GetHeadPos( ent )
	local model = ent:GetModel() or ""
	
    if model:find( "crow" ) or model:find( "seagull" ) or model:find( "pigeon" ) then
        return ent:LocalToWorld( ent:OBBCenter() + Vector( 0, 0, -5 ) )
    elseif ent:GetAttachment( ent:LookupAttachment( "eyes" ) ) ~= nil then
        return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos
    else
        return ent:LocalToWorld( ent:OBBCenter() )
    end
end

/***************************************************
	Method:		DrawBox
	Purpose:	Draws a box around an entity
***************************************************/
local maxesphealth = nil
function Odius:DrawBox( ent, color )
	if ent:Health() <= 0 || !ent:Alive() then return end
	
	local headpos, headang = Odius:GetHeadPos( ent ):ToScreen()
	
	if maxesphealth == nil then maxesphealth = 1 end
	
	if ent:Health() > maxesphealth then maxesphealth = ent:Health() end
	
	if maxesphealth <= 0 then
		maxesphealth = nil
	end
	
	surface.SetDrawColor( color )
	surface.DrawRect( headpos.x + 10, headpos.y - 21, 8, 8 )
	
	surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
	surface.DrawLine( headpos.x, headpos.y, headpos.x + 9, headpos.y - 9 )
	surface.DrawLine( headpos.x + 9, headpos.y - 9, headpos.x + 50, headpos.y - 9 )
	
	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	surface.DrawRect( headpos.x + 9, headpos.y - 5, 42, 5 )
	
	surface.SetDrawColor( Color( 0, 255, 0, 255 ) )
	surface.DrawRect( headpos.x + 10, headpos.y - 4, ( 40 * ( ent:Health() / maxesphealth ) ), 3 )
end

/***************************************************
	Method:		DrawESPInfo
	Purpose:	Draws ESP information based on
				user's likings
***************************************************/
function Odius:DrawESPInfo( ent, color )
	if ent:Health() <= 0 || !ent:Alive() then return end
	
	local headpos, headang = Odius:GetHeadPos( ent ):ToScreen()
	
	if ent:IsNPC() then
		draw.SimpleText( tostring( ent:GetClass() ) , "ESP_Name" , headpos.x + 22, headpos.y - 25, Color( 0, 255, 0, 255 ), 0 )
	elseif ent:IsPlayer() then
		draw.SimpleText( tostring( ent:Nick() ) , "ESP_Name" , headpos.x + 22, headpos.y - 25, Color( 0, 255, 0, 255 ), 0 )
	end
end

/***************************************************
	Method:		SetVAngles
	Purpose:	Sets player viewangles
***************************************************/
function Odius:SetVAngles( cmd, angs )
	return _R.CUserCmd.SetViewAngles( cmd, angs )
end

/***************************************************
	Method:		GetVAngles
	Purpose:	Gets player viewangles
***************************************************/
function Odius:GetVAngles( cmd )
	return _R.CUserCmd.GetViewAngles( cmd )
end

/***************************************************
	Method:		GetCone
	Purpose:	Get current weapon's spread cone
***************************************************/
function Odius:GetCone( wep )
	local cone = wep.Cone
	
	if not cone and type( wep.Primary ) == "table" and type( wep.Primary.Cone ) == "number" then
		cone = wep.Primary.Cone
	end
	
	if not cone then cone = 0 end
	if type( wep.Base ) == "string" and Odius.NormalSpreadCones[wep.Base] then return cone end
	if wep.Base == "weapon_mad_base_sniper" and wep:GetDTBool( 3 ) then cone = cone * wep.data.Cone return cone end
	if wep.Base == "weapon_cs_base2" then cone = cone + 0.05 return cone end
		
	-- FortwarsX
	if string.find(GAMEMODE.Name, "FortwarsX") ~= nil and wep.Base == "weapon_fw_base" then
		if ( LocalPlayer():GetVelocity():Length() > 20 ) then
			cone = cone + 0.025
			return cone
		end
		if ( !LocalPlayer():IsOnGround() ) then
			cone = cone + 0.04
			return cone
		end
		if ( LocalPlayer():Crouching() or LocalPlayer():GetNetworkedBool( "Ironsights", false ) ) then
			cone = cone / 2
			return cone
		end
		return cone
	end
	
	return cone or 0
end

/***************************************************
	Method:		IsEntVisible
	Purpose:	Checks if an entity is visible by
				the local player
***************************************************/
function Odius:IsEntVisible( ent )
	if ent == NULL then return end
	
	local trace = {}
    trace.start = LocalPlayer():GetShootPos()
    trace.endpos = Odius:GetHeadPos( ent )
    trace.filter = { LocalPlayer(), ent }
    trace.mask = MASK_SHOT
	
    local tr = util.TraceLine( trace )
	
    return tr.Fraction >= 0.99 and true or false   
end 

/***************************************************
	Method:		ValidTarget
	Purpose:	Perform a shitload of checks and
				select a desired target
***************************************************/
function Odius:ValidTarget( e )	
	if ( !ValidEntity(e) ) || ( e == LocalPlayer() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end
		
	local m = e:GetMoveType()
	
	if ( m == MOVETYPE_NONE ) then return false end
	if ( e:IsPlayer() ) then
		if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER ) || ( e:Team() == LocalPlayer():Team() && !Aim_Deathmatch:GetBool() ) || ( e:GetFriendStatus() == "friend" && Aim_ProtectBuddies:GetBool() ) /*|| ( e:IsTraitor() && !Traitors:GetBool() )*/ then return false end
	end
		
	return true
end

/*
function Odius:GetClosestTarget()
    local pos = self.Owner:GetPos()
    local ang = self.Owner:GetAimVector()
    local closest = {0,0}
    for k,ent in pairs(self:GetTargets()) do
        local diff = (ent:GetPos()-pos):Normalize()
        diff = diff - ang
        diff = diff:Length()
        diff = math.abs(diff)
        if (diff < closest[2]) or (closest[1] == 0) then
            closest = {ent,diff}
        end
    end
    return closest[1]
end
*/

/***************************************************
	Function:		PredictSpread
	Purpose:		Calculates spread and compensates it
***************************************************/
function Odius.PredictSpread( cmd, aimAngle )
	local currentseed, cmd2, seed = currentseed or 0, 0, 0
	local wep, vecCone, valCone
	
	cmd2, seed = Odius.NoSpread.Prediction( cmd )
	
	if cmd2 != 0 then
		currentseed = seed
	end
	
	wep = LocalPlayer():GetActiveWeapon()
	vecCone = Vector( 0, 0, 0 )
	
	if wep and wep:IsValid() and type( wep.Initialize ) == "function" then
		valCone = Odius:GetCone( wep )
		if type( valCone ) == "number" then
			vecCone = Vector( -valCone, -valCone, -valCone )
		elseif type( valCone ) == "Vector" then
			vecCone = -1 * valCone
		end
	end
	
	return Odius.NoSpread.ShotManip( currentseed or 0, ( aimAngle or LocalPlayer():GetAimVector():Angle()):Forward(), vecCone ):Angle()
end

/***************************************************
	Function:		ESP
	Purpose:		Draws ESP information around
					entities, based on player's
					likings
***************************************************/
function Odius.ESP()
	if ESP then
		for k, v in pairs( ents.GetAll() ) do
			if ValidEntity( v ) && v:IsPlayer() && v != LocalPlayer() && ESP_Target_Players then
				if ESP_Info_Box then
					Odius:DrawBox( v, team.GetColor( v:Team() ) )
					Odius:DrawESPInfo( v, Color( 255, 255, 255, 255 ) )
				end
			end
		
			if ValidEntity( v ) && v:IsNPC() && ESP_Target_NPCs then
				if ESP_Info_Box then
					Odius:DrawBox( v, Color( 255, 255, 255, 255 ) )
					Odius:DrawESPInfo( v, Color( 255, 255, 255, 255 ) )
				end
			end
		end
	end
end

/***************************************************
	Function:		Wallhack
	Purpose:		Simple wallhack
***************************************************/
function Odius.Wallhack()
	for k, v in pairs ( player.GetAll() ) do
		cam.Start3D( EyePos(), EyeAngles() )
			cam.IgnoreZ( true )
			if( v:IsPlayer() and v != LocalPlayer() and v:Health() > 0 and v:Alive() and v:GetMoveType() ~= MOVETYPE_OBSERVER) then
				local mat = v:GetMaterial()
				
				v:SetMaterial( mat )
				v:DrawModel()
			end
			cam.IgnoreZ( false )
		cam.End3D()
	end
end

/***************************************************
	Function:		AutoShoot
	Purpose:		Automatically shoot if we have
					a target
***************************************************/
Odius.NextShot = 0
function Odius.AutoShoot()
		if Odius.Aim_Aiming && Odius.Aim_Locked && Odius:ValidTarget( Odius.Aim_Target ) then
			if Odius.NextShot and Odius.NextShot < CurTime() and ValidEntity( LocalPlayer():GetActiveWeapon() ) then
				Odius.Firing = true
				RunConsoleCommand( "+attack" )
				Odius.NextShot = CurTime() + ( LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
			else
				RunConsoleCommand( "-attack" )
				Odius.Firing = false
			end
		elseif Odius.Firing then
			Odius.Firing = false
			RunConsoleCommand( "-attack" )
		end
	end
--end

/***************************************************
	Function:		Aimbot
	Purpose:		hurr
***************************************************/
function Odius.Aimbot( ucmd )
	if ( !Odius.Aim_Aiming ) then return end
		if !ValidEntity( Odius.Aim_Target ) then Odius.Aim_Target = LocalPlayer() end
		
		if !Odius.Aim_Target || !ValidEntity( Odius.Aim_Target ) then
			if ( ents.GetAll()[1]:IsWorld() && !table.HasValue( Odius.FilterEnts, ents.GetAll()[1] ) ) then
				Odius.Hera.Notify( Color( 0, 255, 0, 255 ), "Found world." )
				table.insert( Odius.FilterEnts, ents.GetAll()[1] )
			end
	
			for k, v in pairs ( ents.GetAll() ) do
				if ( ( !v:IsNPC() || !v:IsPlayer() || v == NULL ) && !table.HasValue( Odius.FilterEnts, v ) ) then
					table.insert( Odius.FilterEnts, v )
				end
			end
		end
		
		for k, v in pairs ( ents.GetAll() ) do
			if Odius:ValidTarget( v ) then
				local a = 0
				local b = 0
			
				a = Odius.Aim_Target:EyePos():Distance( LocalPlayer():EyePos() )
				b = v:EyePos():Distance( LocalPlayer():EyePos() )
			
				if ( b <= a ) then
					Odius.Aim_Target = v
				elseif Odius.Aim_Target == LocalPlayer() then
					Odius.Aim_Target = v
				end
			end
		end
		
		if ValidEntity( Odius.Aim_Target ) && Odius.Aim_Target:Health() > 0 then
			local headpos = Odius:GetHeadPos( Odius.Aim_Target )
			local aimang = ( headpos - LocalPlayer():GetShootPos() ):Normalize():Angle()
			
			if Odius.Aim_Target == LocalPlayer() then return end
			if !Odius:IsEntVisible( Odius.Aim_Target ) then return end
			
			Odius.Aim_Locked = true
			--CalcView_RealAngle = aimang
			
			if Aim_NoSpread:GetBool() then
				aimang = Odius.PredictSpread( ucmd, aimang )
			else
				aimang = ( headpos - LocalPlayer():GetShootPos() ):Normalize():Angle()
			end
			Odius:SetVAngles( ucmd, aimang )
		else
			Odius.Aim_Locked = false
			Odius.Aim_Target = nil
		end
end

/***************************************************
	Function:		CalcView
	Purpose:		Corrects local view
***************************************************/
function Odius.CalcView( u, o )
	if GetViewEntity() != LocalPlayer() then return end
	
	--if ( !Recoil:GetBool() ) then return end	
	local w = ply:GetActiveWeapon()
			
	if ( w.Primary ) then
		w.Primary.Recoil = 0.0
	end
		
	if ( w.Secondary ) then
		w.Secondary.Recoil = 0.0
	end
	
	return { origin = o, angles = CalcView_RealAngle }
end

/***************************************************
	Function:		Crosshair
	Purpose:		Draws a crosshair at the center
					of the screen
***************************************************/
function Odius.Crosshair()
	local x = ScrW() / 2
	local y = ScrH() / 2
 
	surface.SetDrawColor( 255, 255, 255, 255 )
 
	local gap = 3
	local length = gap + 10
 
	--draw the crosshair
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
end

/***************************************************
	Function:		Injector
	Purpose:		Injects scripts using Hera
***************************************************/
function Odius.Injector( ply, command, args )
	if args[1] == "" || args[1] == NULL || args[1] == nil then
		Odius.Hera.Notify( Color( 255, 128, 0, 255 ), "No file specified for injection." )
	else	
		Odius.Hera.Notify( Color( 255, 128, 0, 255 ), "Injecting " .. args[1] .. " ..." )
		Odius.Hera.Include( args[1] )
	end
end

/***************************************************
	Function:		Unload
	Purpose:		Removes all the hooks and empties
					the hook table, unloading the
					hack almost completely
***************************************************/
function Odius.Unload()
	for n, h in pairs ( Odius.Hooks ) do
		local currenthook = string.format( "Removing %s hook [%s]", h, n )
		
		Odius.Hera.Notify( Color( 255, 128, 0, 255 ), currenthook )
		Odius.Hook.Remove( h, n )
		Odius.Hooks[n] = nil
	end
	
	Odius.Hooks = {} -- Maybe empty the whole Odius table?
	-- Odius = {}
end

/***************************************************
	Function:		Reload
	Purpose:		Reloads the hack
***************************************************/
function Odius.Reload()
	Odius.Hera.Notify( Color( 255, 128, 0, 255 ), "Reloading ..." )
	Odius.Unload()
	include( "autorun/client/shittyshack_v3.lua" )
	Odius.Hera.Notify( Color( 255, 128, 0, 255 ), "Reloaded!" )
end

/***************************************************
	Function:		AimbotOn
	Purpose:		Starts the aimbot
***************************************************/
function Odius.AimbotOn( ply, cmd, args )
	Odius.Aim_Aiming = true
end

/***************************************************
	Function:		AimbotOff
	Purpose:		Turns off the aimbot
***************************************************/
function Odius.AimbotOff( ply, cmd, args )
	Odius.Aim_Aiming = false
	Odius.Aim_Target = nil
	Odius.Aim_Locked = false
end

/***************************************************
	---			VGUI SHIT STARTS HERE		---
***************************************************/
function Odius.PopupMenu()
	local OdiusMenuPanel = vgui.Create( "DFrame" )
	OdiusMenuPanel:SetSize( 280, 300 )
	OdiusMenuPanel:SetPos( ScrW() / 2, ScrH() / 2 )
	OdiusMenuPanel:SetTitle( "Odius :: Menu" )
	OdiusMenuPanel:SetVisible( true )
	OdiusMenuPanel:SetDraggable( true )
	OdiusMenuPanel:ShowCloseButton( true )
	OdiusMenuPanel:MakePopup()
	
	-- Property sheet itself --
	local OdiusPropertySheet = vgui.Create( "DPropertySheet" )
	OdiusPropertySheet:SetParent( OdiusMenuPanel )
	OdiusPropertySheet:SetPos( 5, 30 )
	OdiusPropertySheet:SetSize( OdiusMenuPanel:GetWide() - 10, OdiusMenuPanel:GetTall() - 35 )
	OdiusPropertySheet:SetShowIcons( false )
	
	-- Creating panels for property sheet --
	local OdiusAimbotPanel = vgui.Create( "DPanel", OdiusPropertySheet )
	OdiusAimbotPanel:SetPos( 3, 3 )
	OdiusAimbotPanel:SetSize( OdiusPropertySheet:GetWide() - 6, OdiusPropertySheet:GetTall() - 6 )
	
	local OdiusIjectorPanel = vgui.Create( "DPanel", OdiusPropertySheet )
	OdiusIjectorPanel:SetPos( 3, 3 )
	OdiusIjectorPanel:SetSize( OdiusPropertySheet:GetWide() - 6, OdiusPropertySheet:GetTall() - 6 )
	
	-- Aimbot panel stuff --	
	local OdiusAimbotLabel = vgui.Create( "DLabel", OdiusAimbotPanel )
	OdiusAimbotLabel:SetPos( 5, 3 ) // + 18 from now on
	OdiusAimbotLabel:SetColor( Color( 255, 0, 0, 255 ) )
	OdiusAimbotLabel:SetText( "Fill me up ok" )
	
	-- Injector panel stuff --
	local OdiusInjectorPathLabel = vgui.Create( "DLabel", OdiusIjectorPanel )
	OdiusInjectorPathLabel:SetPos( 5, 3 ) // + 18 from now on
	OdiusInjectorPathLabel:SetColor( Color( 255, 255, 255, 255 ) )
	OdiusInjectorPathLabel:SetText( "Path to script (inside garrysmod\\lua):" )
	OdiusInjectorPathLabel:SizeToContents()
	
	local OdiusInjectorPath = vgui.Create( "DTextEntry", OdiusIjectorPanel )
	OdiusInjectorPath:SetPos( 5, 21 )
	OdiusInjectorPath:SetSize( 200, 21 )
	OdiusInjectorPath:SetText( "" )
	
	local OdiusInjectorButton = vgui.Create( "DSysButton", OdiusIjectorPanel )
	OdiusInjectorButton:SetPos( 212, 21 )
	OdiusInjectorButton:SetSize( 21, 21 )
	OdiusInjectorButton:SetType( "tick" )
	OdiusInjectorButton.DoClick = function( OdiusInjectorButton )
		if OdiusInjectorPath:GetValue() != "" then
			Odius.Hera.Notify( Color( 255, 128, 0, 255 ), "Injecting script..." )
			Odius.Hera.Include( OdiusInjectorPath:GetValue() )
		else
			Odius.Hera.Notify( Color( 255, 0, 0, 255 ), "No file specified for injection." )
		end
	end
	
	
	OdiusPropertySheet:AddSheet( "Aimbot", OdiusAimbotPanel, "gui/silkicons/key", false, false )
	OdiusPropertySheet:AddSheet( "Injector", OdiusIjectorPanel, "gui/silkicons/key", false, false )
end


-- Hooks --
Odius:AddHook( "HUDPaintBackground", Odius.Wallhack )
Odius:AddHook( "HUDPaint", Odius.ESP )
Odius:AddHook( "HUDPaint", Odius.Crosshair )
Odius:AddHook( "CreateMove", Odius.Aimbot )
--Odius:AddHook( "CalcView", Odius.CalcView )
Odius:AddHook( "Think", Odius.AutoShoot )

-- Concommands --
Odius:AddConcommand( "nope_unload", Odius.Unload )
Odius:AddConcommand( "nope_reload", Odius.Reload )
Odius:AddConcommand( "+nope_aim", Odius.AimbotOn )
Odius:AddConcommand( "-nope_aim", Odius.AimbotOff )
Odius:AddConcommand( "nope_inject", Odius.Injector )
Odius:AddConcommand( "nope_menu", Odius.PopupMenu )