--[[
	MOD/lua/ShinnyCowESP.lua
	R_e_V Gage :D | STEAM_0:1:68233689 <74.199.12.122:27005> | [10-09-13 08:31:26PM]
	===BadFile===
]]

local SCE = {}

	---------------- CONFIG
	
	// Toggle esp. Or yknow, just run sc_esp_toggle
local sc_espon = true

	// Draw halo around player? NOTE: Halos cause some FPS drop.
local sc_drawhalos = true

	// Draw the up/down arrows on da player
local sc_drawheadsmash = true

	// Print in your chat when a player's babygod wears off
local sc_notifybabygod = false

	// Draw where you're pointing at.
local sc_drawmyownbeam = false

	// Instead of blue, use yellow/purple
local sc_yellowized = true

	// Other player prop colors. Use Colour tool to find new color.
local sc_otherplayerprops = Color( 255, 200, 0, 60 )

local sc_myprops = Color( 127, 159, 255, 200 )

	---------------- END CONFIG

local debug = debug
local CreateClientConVar = CreateClientConVar
local gameevent = gameevent

local cam = cam
local render = render
local util = util
local draw = draw
local IsValid = IsValid
local LocalPlayer = LocalPlayer
local halo = halo
local ents = ents
local player = player
local surface = surface

local _R = debug.getregistry()
local scSetMat = _R.Entity.SetMaterial

local AddConsoleCommand = AddConsoleCommand

surface.CreateFont("ScoreboardText", 
{
	size = 20,
	weight = 100,
	antialias = true,
	shadow = true,
	font = "coolvetica"
})

gameevent.Listen("player_spawn")

local function sce_AddCommand( cmd, func, help )
	SCE[ "sc_" .. cmd:lower() ] = {Function = func, Help = help}
	AddConsoleCommand( "sc_" .. cmd:lower(), help )
end

local oldICC = InjectConsoleCommand
function InjectConsoleCommand( player, command, arguments, args )
	if SCE[ command:lower() ] then
		SCE[ command:lower() ].Function( player, command, arguments, args )
		return true
	end
	
	oldICC( player, command, arguments, args )
end

local function SC_SetMaterial( ent )
	if sc_espon then
	
		scSetMat( ent, "mat1" )
	
	else
	
		scSetMat( ent, "" )
		
	end
end

local function GetMuzzlePos(ply)
	if not IsValid(ply) then return Vector() end

	local vm = ply:GetViewModel()
	local pos = ply:EyePos()

	if IsValid( vm ) then
		local attachId = vm:LookupAttachment("muzzle")
		if attachId == 0 then
			attachId = vm:LookupAttachment("1")
		end

		if vm:GetAttachment(attachId) != nil then
			pos = vm:GetAttachment(attachId).Pos
		end
	end

	return (pos or ply:EyePos())
end


// Barrelhack
local BH_Material 		= Material("effects/laser1")
local BH_Material_NOZ 	= Material("effects/laser1_noz")

local function RooftopPlayer()
	if not sc_espon then return end
	
	local UpdatedPlayers = player.GetAll()
	cam.Start3D(EyePos(), EyeAngles())
		for i=1,#UpdatedPlayers do
			local v = UpdatedPlayers[ i ]
		
			if IsValid(v) and v:Alive() and v:Team() != TEAM_SPECTATOR then
				if (v == LocalPlayer() and sc_drawmyownbeam) or v != LocalPlayer() then
					render.SetMaterial(BH_Material)
					render.DrawBeam(GetMuzzlePos(v), v:GetEyeTrace().HitPos, 20, 1, 1, Color(255, 0, 0, 255))
				end
				
				if v != LocalPlayer() and sc_drawheadsmash then
				
					render.SetMaterial(BH_Material_NOZ)

					local tr = util.TraceLine({start = v:EyePos(), endpos = v:EyePos() + Vector(0, 0, 100000), filter = v})
					render.DrawBeam(v:EyePos(), tr.HitPos, 50, 1, 1, Color(math.random(0,200), math.random(50,255), 0, 255))

					tr = util.TraceLine({start = v:EyePos(), endpos = v:EyePos() - Vector(0, 0, 100000), filter = v})
					render.DrawBeam(v:EyePos(), tr.HitPos, 10, 1, 1, Color(0, 255, 0, 255))
				
				end
			end
		end
	cam.End3D()
end
hook.Add("RenderScreenspaceEffects", "shinycow_rooftop", RooftopPlayer)

local FakeUM = {}
local function MakeFakeUM()
	FakeUM = {}
	function FakeUM:ReadLong()
		return self.ID
	end
	function FakeUM:ReadString()
		return self.Ent
	end
end

usermessage.Hook("AddUndo", function(um)
	local k = um:ReadLong()
	local v = um:ReadString()
	
	timer.Create("undo_" .. k .. v, 0.008, 19, function()
		if LocalPlayer():GetEyeTrace().Entity:GetClass() == "prop_physics" then
			LocalPlayer():GetEyeTrace().Entity.IsMine = true
			timer.Destroy("undo_" .. k .. v)
		end
	end)
		
	MakeFakeUM()
	FakeUM.ID = k
	FakeUM.Ent = v
end)

local function ESPPlayer()
	if not sc_espon then return end
	
	local UpdatedPlayers = player.GetAll()
	local UpdatedProps = ents.FindByClass("prop_physics")
	
	cam.Start3D(EyePos(), EyeAngles())
		cam.Start2D()
			for i=1,#UpdatedProps do
				local v = UpdatedProps[ i ]
				
				SC_SetMaterial( v )
				if not v.IsMine then
					v:SetColor( sc_otherplayerprops )
				else
					if not v.scColored then
						v:SetColor( sc_myprops )
						v.scColored = true
					end
				end
			end
		
			for i=1,#UpdatedPlayers do
				local v = UpdatedPlayers[ i ]
				
				if v == LocalPlayer() then continue end
				
				local plname = v:Nick()
				local plhead = v:GetPos() + Vector(0, 0, 64)
				local pos = plhead:ToScreen()
				pos.x = math.Clamp(pos.x, 0, ScrW())
				pos.y = math.Clamp(pos.y, 0, ScrH())
				local plteam = team.GetColor(v:Team())
				
				--print(surface.GetTextSize( plname ))
				draw.SimpleText( plname, "ScoreboardText", pos.x - (surface.GetTextSize( plname ) * 0.5), pos.y - 10 - 15, Color(plteam.r, plteam.g, plteam.b, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				local notguest = "user"
				if v:GetNWString("UserGroup", notguest) != notguest then
					draw.SimpleText( v:GetNWString("UserGroup", "user"), "ScoreboardText", pos.x - (surface.GetTextSize( v:GetNWString("UserGroup", "user") ) * 0.5), pos.y - 10 + 10, Color(205, 150, 70, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end
			end
		cam.End2D()
	cam.End3D()
end
hook.Add("RenderScreenspaceEffects", "shinycow_esp", ESPPlayer)
				
local function sc_halos()
	if not sc_espon or not sc_drawhalos then return end
	halo.Add( ents.FindByClass( "Player" ), Color( 205, 150, 70, 255 ), 1, 1, 0.5 )
end
hook.Add("PreDrawHalos", "sc_halos", sc_halos)

hook.Add("player_spawn", "idklisten", function( data )
	if IsValid( Player( data.userid ) ) then
		SC_SetMaterial( Player( data.userid ) )
		if GAMEMODE.Config and GAMEMODE.Config.babygod then
			Player( data.userid ).IsGodded = true
			timer.Simple(GAMEMODE.Config.babygodtime, function()
				if IsValid(Player( data.userid )) then
					Player( data.userid ).IsGodded = false
					if sc_notifybabygod then
						LocalPlayer():ChatPrint( Player( data.userid ):Nick() .. " baby god off.")
					end
				end
			end)
		end
	end
end)

local function resetplayermaterial()
	local playerAll = player.GetAll()
	for i=1,#playerAll do
		local v = playerAll[ i ]
		
		if v:GetMaterial() != "mat1" then
			SC_SetMaterial( v )
		end

	end
end
hook.Add("Think", "resetplayermaterial", resetplayermaterial)

--sce_AddCommand( "esp_toggle", function() sc_espon = not sc_espon end )
local function espnow()
	local playerAll = player.GetAll()
	for i=1,#playerAll do
		local v = playerAll[ i ]
		
		if not sc_espon then v:SetColor( Color( 255, 255, 255, 255 ) ) continue end
		if v == LocalPlayer() then continue end
		
		if v:Alive() then
		
			--[[if GAMEMODE.Config and GAMEMODE.Config.babygod then
				if v.IsSpawned then
					v:SetColor( Color( 0, 255, 255, 255 ) )
				else
					v:SetColor( Color( 127, 255, 255, 200 ) )
				end
			else
				v:SetColor( Color( 0, 255, 255, 255 ) )
			end]]
			
			if v.IsGodded != nil then
				if v.IsGodded then
					if sc_yellowized then
						v:SetColor( Color( 220, 0, 255, 200 ) )
					else
						v:SetColor( Color( 30, 30, 200, 200 ) )
					end
				else
					if sc_yellowized then	
						v:SetColor( Color( 255, 255, 0, 255 ) )
					else
						v:SetColor( Color( 0, 255, 255, 255 ) )
					end
				end
			else
				if sc_yellowized then
					v:SetColor( Color( 255, 255, 0, 255 ) )
				else
					v:SetColor( Color( 0, 255, 255, 255 ) )
				end
			end
					
			
		else
			
			v:SetColor( Color( 255, 0, 191, 255 ) )
		
		end

	end
end
timer.Create("refresh", 0.45, 0, espnow)

sce_AddCommand( "esp_toggle", function()
	sc_espon = not sc_espon
	
	espnow()
	
end )

sce_AddCommand( "180", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles( Angle( a.p, a.y - 180, a.r ) )
end )

sce_AddCommand( "180up", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles( Angle( a.p - a.p - a.p, a.y - 180, a.r ) )
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.2, function() RunConsoleCommand("-jump") end )
end )