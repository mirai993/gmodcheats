local SlenderHook = {};

SlenderHook.Version = 0.1;
SlenderHook.Author  = "Smelly Shoes";

hook.Add("HUDPaint", "Visuals", function()
    for _, ent in pairs(ents.FindByClass("page")) do
        if ( not ent.Taken ) then
            SlenderHook:DrawBox( ent, Color(255, 140, 0, 255) );
        end
    end;

    for _, ply in pairs(player.GetAll()) do
        local plyColor; --Fucking ternary still wont work.
        if ( ply:IsSlenderman() ) then
            plyColor = Color( 255, 0, 0, 255 );
        else
            plyColor = Color( 0, 255, 0, 255 );
        end;

        if ( ply:Alive() && ply ~= LocalPlayer() ) then
            SlenderHook:DrawBox( ply, plyColor );
        end;
    end;
end)

function SlenderHook:DrawBox(ply, color)
    local min, max = ply:OBBMins(), ply:OBBMaxs();
    local corners = {
      Vector( min.x, min.y, min.z ),
      Vector( min.x, min.y, max.z ),
      Vector( min.x, max.y, min.z ),
      Vector( min.x, max.y, max.z ),
      Vector( max.x, min.y, min.z ),
      Vector( max.x, min.y, max.z ),
      Vector( max.x, max.y, min.z ),
      Vector( max.x, max.y, max.z )
    };

    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0;

    for _, corner in pairs( corners ) do
      local onScreen = ply:LocalToWorld( corner ):ToScreen();
      minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y );
      maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y );
    end;

    surface.SetDrawColor(color);
    surface.DrawLine( minX, minY, math.min( minX + 5, maxX ), minY );
    surface.DrawLine( minX, minY, minX, math.min( minY + 5, maxY ) );
    surface.DrawLine( maxX, minY, math.max( maxX - 5, minX ), minY );
    surface.DrawLine( maxX, minY, maxX, math.min( minY + 5, maxY ) );
    surface.DrawLine( minX, maxY, math.min( minX + 5, maxX ), maxY );
    surface.DrawLine( minX, maxY, minX, math.max( maxY - 5, minY ) );
    surface.DrawLine( maxX, maxY, math.max( maxX - 5, minX ), maxY );
    surface.DrawLine( maxX, maxY, maxX, math.max( maxY - 5, minY ) );
end;