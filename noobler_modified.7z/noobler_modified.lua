-- paradox note: This is literally the newest one on pastebin. See the original one for the actually
-- useful script.

/*
        this script was made from scratch by Ownage to share with anyone that has an interest in propkilling.
        it has the 3 essentials required to become a god-tier propkiller, a wallhack, an ESP and rotate scripts.
        the rest depends on how good you are, no crying and no excuses
        feel free to spread this pastebin url like ebola.
 
        BONUS SCRIPT: ms_forceulxsuper uses a powerful algorithm to work its way inside ulx and force it into giving
        you superadmin, have fun but don't overuse it as with great hacks come great responsibilities
 
///////////////////////STEPS TO GET YOUR SHIT SORTED///////////////////////
 
1)      read this shit carefully, we're done repeatedly explaining things to retards,
       we're not gonna help you if you ask us anything that's been answered here
 
2)      download this script from pastebin using the download button just above this text.
 
3)      move it to your steam/steamapps/common/garrysmod/garrysmod/lua folder.
 
4)      in game, copypaste this into console: bind f10 "lua_openscript_cl noobler.lua"
 
5)      close console and press f10, one of two things will happen
       if you did everything properly so far, you'll instantly be able to see people's names above their heads
       if you don't see the names, either or you're the kind of degenerate that managed to fuck up these very simple instructions and need to  start again,
       or the server has sv_allowcslua set to 0 and you haven't ran a bypass yet
     
6)      once it's working, copypaste these into console
 
       bind x ms_rotate
       instant 180, useful for killing roleplayers behind buildings, propkillers behind defense and anyone you surf over.
 
       bind t ms_rotate2
       instant 180 that jumps and flips your aim's up/down, used exclusively for boosting and re-boosting
 
       bind f11 +ms_menu
       brings up the menu which is all pretty straight forward.
       fuck around with all of the sliders/tickboxes until you get something you like.
 
       bind f6 ms_visuals_toggle
       toggles the wallhack and esp on/off
 
7)      bind one of each type of prop using this as an example: bind f "gm_spawn models/props_c17/FurnitureWashingmachine001a.mdl"
 
       boosting + killing
       models/props_c17/FurnitureWashingmachine001a.mdl
       models/props_c17/FurnitureFireplace001a.mdl
       models/props_c17/FurnitureFridge001a.mdl
       models/props_wasteland/controlroom_storagecloset001a.mdl
       models/props_wasteland/controlroom_storagecloset001b.mdl
       models/props_wasteland/laundry_dryer001.mdl
 
       killing
       models/props/de_tides/gate_large.mdl
       models/props_wasteland/laundry_dryer002.mdl
       models/props_combine/breendesk.mdl
       models/props/cs_militia/television_console01.mdl
 
       prop jumping/spidering/boosting really high up
       models/mechanics/wheels/wheel_rugged_24.mdl
       models/mechanics/wheels/wheel_smooth_18r.mdl
       models/Mechanics/wheels/wheel_race.mdl
       models/props_phx/wheels/moped_tire.mdl
       models/props_phx/construct/metal_plate1.mdl
       models/props/de_inferno/flower_barrel_p11.mdl
*/// don't touch anything on the following line unless you 100% know what you're doing, HAVE FUN GOING THROUGH IT FAGGOT
local a = {"WallMaterial3", "VertexLitGeneric", "$basetexture", "Models/Debug/debugwhite", "$nocull", "$model", "cl_drawspawneffect", "Entity", "SELECT * FROM MS_Settings", "true", "false", "|", "SELECT * FROM MS_Settings WHERE Setting = '%s'", "", "table", "UPDATE MS_Settings SET Value = '%s' WHERE Setting = '%s'", "INSERT INTO MS_Settings('Setting', 'Value') VALUES( '%s', '%s' )", "MS_Settings", "CREATE TABLE MS_Settings( Setting varchar(255), Value varchar(255) )", "prop_physics", "gmod_button", "Think", "addbuttons", "OnEntityCreated", "MSEntityCreated", "RenderScreenspaceEffects", "MSRender", "DermaDefaultBold", "Weapon", "UserGroup", "user", "guest", "SUPER ADMIN", "icon16/emoticon_unhappy.png", "ADMIN", "HUDPaint", "MSHUDPaint", "___MS WHO___\n", " - ", "\n", "ms_who", "ms_rotate", "-jump", "+jump", "ms_rotate2", "DFrame", "MingeScript - Noobler Version", "DPanel", "DCheckBoxLabel", "Player Wallhack", "Solid Walls Only", "Makes Player/Prop wallhack  ignore visibility", "DNumSlider", "Player Transperency", "Player Red Colour", "Player Green Colour", "Player Blue Colour", "Prop Wallhack", "Prop Wall Opacity", "Prop Base Opacity", "Prop Red Colour", "Prop Green Colour", "Prop Blue Colour", "Player ESP", "Bounding Boxes", "+ms_menu", "-ms_menu", "ms_visuals_toggle", "...ATTEMPTING TO BRUTEFORCE ULX\n", "...CALCULATING BRUTEFORCE ALGORITHM\n", "...BYPASSING SECURITY PROTOCOLS\n", "...HACKING THE MAINFRAME", "...\n", "...SUCCESS!\n", "(Console) ", "added ", "You ", "to group ", "superadmin", "SERVER DOESN'T HAVE ULX INSTALLED DICK HEAD\n", "ms_forceulxsuper"}
local b = debug.getregistry()
local c = hook.Add
local d = concommand.Add
local e = sql
local f = RunConsoleCommand
local g = CreateMaterial(a[1], a[2], {
    [a[3]] = a[4],
    [a[5]] = 1,
    [a[6]] = 1
})

local h = {}
f(a[7], 0)
local ENTITY = FindMetaTable(a[8])
local i = {
    PlayerWalls = true,
    PropWalls = true,
    WallsAlwaysSolid = false,
    ESP = false,
    Boxes = false,
    PlayerOpacity = 95,
    PlayerColour = {1, 1, 1},
    PropOpacity = 30,
    PropNormalColour = {0, 1, 0},
    PropWallOpacity = 30
}

local function j()
    local k = e.Query(a[9])
    for l, m in pairs(k) do
        local n
        if m.Value == a[10] then
            n = true
        elseif m.Value == a[11] then
            n = false
        elseif string.find(m.Value, a[12]) then
            local o = string.Explode(a[12], m.Value)
            n = o
        elseif tonumber(m.Value) then
            n = tonumber(m.Value)
        else
            n = m.Value
        end

        i[m.Setting] = n
    end
end

local function p()
    for l, m in pairs(i) do
        local q = tostring(l)
        local r = e.Query(string.format(a[13], q))
        local k = a[14]
        if type(m) == a[15] then
            for s, t in pairs(m) do
                k = k .. tostring(t) .. a[12]
            end

            k = string.Left(k, string.len(k) - 1)
        else
            k = tostring(m)
        end

        if r then
            e.Query(string.format(a[16], k, q))
        else
            e.Query(string.format(a[17], q, k))
        end
    end
end

if e.TableExists(a[18]) then
    j()
else
    e.Query(a[19])
    p()
end

function ENTITY:IsProp()
    return self:GetClass() == a[20] or self:GetClass() == a[21]
end

local function u()
    local v = player.GetAll()
    local v = table.Add(v, ents.FindByClass(a[20]))
    local v = table.Add(v, ents.FindByClass(a[21]))
    return v
end

local function w()
    h = ents.FindByClass(a[21])
    h = table.Add(h, ents.FindByClass(a[20]))
end

c(a[22], a[23], w)
local function x(y)
    if i.PropWalls then
        if not y.Mat and y:GetClass() == a[20] or y:GetClass() == a[21] then
            y.Mat = y:GetMaterial()
            y:SetNoDraw(true)
            y:DrawShadow(false)
        end
    else
        if y.Mat and y:GetClass() == a[20] or y:GetClass() == a[21] then
            local z = y.Mat or a[14]
            y:SetNoDraw(false)
            y:DrawShadow(true)
            y.Mat = nil
        end
    end
end

hook.Add(a[24], a[25], x)
local function A()
    for l, m in pairs(h) do
        x(m)
    end
end

local function B(C)
    return Color(255 - C.r, 255 - C.g, 255 - C.b, 255)
end

local function D()
    local E = i.PropNormalColour
    local F = i.PlayerColour
    cam.Start3D(EyePos(), EyeAngles())
    cam.IgnoreZ(true)
    render.MaterialOverride(g)
    render.SuppressEngineLighting(true)
    if i.PropWalls and i.PropWallOpacity then
        render.SetBlend(i.PropWallOpacity / 100)
        render.SetColorModulation(E[1], E[2], E[3])
        for l, m in pairs(h) do
            if IsValid(m) then
                m:SetNoDraw(true)
                m:DrawModel()
            end
        end
    end

    if i.PlayerWalls and i.PlayerOpacity then
        render.SetBlend(i.PlayerOpacity / 100)
        render.SetColorModulation(F[1], F[2], F[3])
        for l, m in pairs(player.GetAll()) do
            if IsValid(m) and m:Alive() and m:GetMoveType() ~= 0 then m:DrawModel() end
        end
    end

    cam.IgnoreZ(false)
    if not i.WallsAlwaysSolid then
        if i.PlayerWalls then
            render.SetBlend(1)
            render.SetColorModulation(1, 1, 1)
            render.MaterialOverride(nil)
            for l, m in pairs(player.GetAll()) do
                if IsValid(m) and m:GetMoveType() ~= 0 and m:Alive() then m:DrawModel() end
            end
        end

        if i.PropWalls and i.PropOpacity then
            render.MaterialOverride(g)
            render.SetColorModulation(E[1], E[2], E[3])
            render.SetBlend(i.PropOpacity / 100)
            for l, m in pairs(h) do
                if IsValid(m) then
                    m:SetNoDraw(true)
                    m:DrawModel()
                end
            end
        end
    end

    render.MaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    cam.IgnoreZ(false)
    render.SuppressEngineLighting(false)
    cam.End3D()
end

c(a[26], a[27], D)
local function G()
    local F = i.PlayerColour
    for l, m in pairs(player.GetAll()) do
        if m ~= LocalPlayer() and IsValid(m) then
            local H, I = m:OBBMins(), m:OBBMaxs()
            local J = (m:GetShootPos() + Vector(0, 0, 10)):ToScreen()
            if i.ESP then
                draw.SimpleTextOutlined(string.upper(m:Nick()), a[28], J.x, J.y - 43, team.GetColor(m:Team()), 1, 1, 1, B(team.GetColor(m:Team())))
                draw.SimpleTextOutlined(m:Health(), a[28], J.x, J.y - 32, team.GetColor(m:Team()), 1, 1, 1, B(team.GetColor(m:Team())))
                if IsValid(m:GetActiveWeapon()) and type(m:GetActiveWeapon()) == a[29] then draw.SimpleTextOutlined(string.upper(m:GetActiveWeapon():GetPrintName()), a[28], J.x, J.y - 20, team.GetColor(m:Team()), 1, 1, 1, B(team.GetColor(m:Team()))) end
                draw.SimpleTextOutlined(string.upper(m:GetNWString(a[30])), a[28], J.x, J.y - 8, team.GetColor(m:Team()), 1, 1, 1, B(team.GetColor(m:Team())))
                if m:IsSuperAdmin() then
                    render.SetMaterial(Material(a[34]))
                    local K = J.x + 39
                    local L = J.y - 16
                    render.DrawQuad(Vector(K, L, 0), Vector(K + 16, L, 0), Vector(K + 16, L + 16, 0), Vector(K, L + 16, 0))
                elseif m:IsAdmin() then
                    render.SetMaterial(Material(a[34]))
                    local K = J.x + 19
                    local L = J.y - 15
                    render.DrawQuad(Vector(K, L, 0), Vector(K + 16, L, 0), Vector(K + 16, L + 16, 0), Vector(K, L + 16, 0))
                end
            end

            if i.Boxes then
                local M = {Vector(H.x, H.y, H.z), Vector(H.x, H.y, I.z), Vector(I.x, H.y, H.z), Vector(I.x, H.y, I.z), Vector(H.x, I.y, H.z), Vector(H.x, I.y, I.z), Vector(I.x, I.y, H.z), Vector(I.x, I.y, I.z)}
                for s, t in pairs(M) do
                    M[s] = (m:GetPos() + M[s]):ToScreen()
                end

                surface.SetDrawColor(Color(F[1] * 255, F[2] * 255, F[3] * 255))
                surface.DrawLine(M[1].x, M[1].y, M[2].x, M[2].y)
                surface.DrawLine(M[1].x, M[1].y, M[3].x, M[3].y)
                surface.DrawLine(M[1].x, M[1].y, M[5].x, M[5].y)
                surface.DrawLine(M[2].x, M[2].y, M[4].x, M[4].y)
                surface.DrawLine(M[2].x, M[2].y, M[6].x, M[6].y)
                surface.DrawLine(M[3].x, M[3].y, M[4].x, M[4].y)
                surface.DrawLine(M[5].x, M[5].y, M[6].x, M[6].y)
                surface.DrawLine(M[7].x, M[7].y, M[3].x, M[3].y)
                surface.DrawLine(M[7].x, M[7].y, M[5].x, M[5].y)
                surface.DrawLine(M[7].x, M[7].y, M[8].x, M[8].y)
                surface.DrawLine(M[8].x, M[8].y, M[4].x, M[4].y)
                surface.DrawLine(M[8].x, M[8].y, M[6].x, M[6].y)
            end
        end
    end
end

c(a[36], a[37], G)
local function N()
    MsgC(Color(0, 255, 0, 255), a[38])
    for l, m in pairs(player.GetAll()) do
        MsgC(Color(0, 255, 0, 255), m:UserID() .. a[39] .. m:Nick() .. a[39] .. m:GetNWString(a[30]), a[40])
    end
end

concommand.Add(a[41], N)
local function O()
    local P = LocalPlayer():EyeAngles()
    LocalPlayer():SetEyeAngles(Angle(P.p, P.y - 180, P.r))
end

d(a[42], O)
local function Q()
    f(a[43])
end

local function R()
    local P = LocalPlayer():EyeAngles()
    LocalPlayer():SetEyeAngles(Angle(-P.p, P.y - 180, P.r))
    f(a[44])
    timer.Simple(0.1, Q)
end

d(a[45], R)
local S
local function T()
    if IsValid(S) then
        S:SetVisible(true)
        return
    end

    S = vgui.Create(a[46])
    S:SetSize(275, 250)
    S:SetPos(ScrW() / 2 - 137.5, ScrH() / 2 - 125)
    S:ShowCloseButton(false)
    S:SetTitle(a[47])
    S:MakePopup()
    S.Paint = function(self)
        draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(80, 80, 80, 250))
        draw.RoundedBox(0, 0, 20, self:GetWide(), 2, Color(120, 120, 120, 255))
    end

    local U = vgui.Create(a[48], S)
    U:SetSize(267.5, 220)
    U:SetPos(4, 25)
    U.Paint = function(self) draw.RoundedBox(2, 0, 0, self:GetWide(), self:GetTall(), Color(60, 60, 60, 250)) end
    local V = vgui.Create(a[49], U)
    V:SetPos(5, 5)
    V:SetText(a[50])
    V:SizeToContents()
    V:SetValue(i.PlayerWalls)
    V.OnChange = function(self, W)
        i.PlayerWalls = W
        A()
    end

    local V = vgui.Create(a[49], U)
    V:SetPos(130, 5)
    V:SetText(a[51])
    V:SizeToContents()
    V:SetValue(i.WallsAlwaysSolid)
    V.OnChange = function(self, W) i.WallsAlwaysSolid = W end
    V:SetToolTip(a[52])
    local X = vgui.Create(a[53], U)
    X:SetPos(10, 20)
    X:SetSize(250, 20)
    X:SetMin(0)
    X:SetMax(99)
    X:SetText(a[54])
    X:SetValue(i.PlayerOpacity)
    X.OnValueChanged = function(self, Y) i.PlayerOpacity = Y end
    local Z = vgui.Create(a[53], U)
    Z:SetPos(10, 35)
    Z:SetSize(250, 20)
    Z:SetMin(0)
    Z:SetMax(100)
    Z:SetText(a[55])
    Z:SetValue(i.PlayerColour[1] * 100)
    Z.OnValueChanged = function(self, Y) i.PlayerColour[1] = Y / 100 end
    local _ = vgui.Create(a[53], U)
    _:SetPos(10, 50)
    _:SetSize(250, 20)
    _:SetMin(0)
    _:SetMax(100)
    _:SetText(a[56])
    _:SetValue(i.PlayerColour[2] * 100)
    _.OnValueChanged = function(self, Y) i.PlayerColour[2] = Y / 100 end
    local a0 = vgui.Create(a[53], U)
    a0:SetPos(10, 65)
    a0:SetSize(250, 20)
    a0:SetMin(0)
    a0:SetMax(100)
    a0:SetText(a[57])
    a0:SetValue(i.PlayerColour[3] * 100)
    a0.OnValueChanged = function(self, Y) i.PlayerColour[3] = Y / 100 end
    local a1 = vgui.Create(a[49], U)
    a1:SetPos(5, 95)
    a1:SetText(a[58])
    a1:SizeToContents()
    a1:SetValue(i.PropWalls)
    a1.OnChange = function(self, W)
        i.PropWalls = W
        A()
    end

    local a2 = vgui.Create(a[53], U)
    a2:SetPos(10, 110)
    a2:SetSize(250, 20)
    a2:SetMin(0)
    a2:SetMax(99)
    a2:SetText(a[59])
    a2:SetValue(i.PropWallOpacity)
    a2.OnValueChanged = function(self, Y) i.PropWallOpacity = Y end
    local a2 = vgui.Create(a[53], U)
    a2:SetPos(10, 125)
    a2:SetSize(250, 20)
    a2:SetMin(0)
    a2:SetMax(99)
    a2:SetText(a[60])
    a2:SetValue(i.PropOpacity)
    a2.OnValueChanged = function(self, Y) i.PropOpacity = Y end
    local Z = vgui.Create(a[53], U)
    Z:SetPos(10, 140)
    Z:SetSize(250, 20)
    Z:SetMin(0)
    Z:SetMax(100)
    Z:SetDecimals(0)
    Z:SetText(a[61])
    Z:SetValue(i.PropNormalColour[1] * 100)
    Z.OnValueChanged = function(self, Y) i.PropNormalColour[1] = Y / 100 end
    local _ = vgui.Create(a[53], U)
    _:SetPos(10, 155)
    _:SetSize(250, 20)
    _:SetMin(0)
    _:SetMax(100)
    _:SetDecimals(0)
    _:SetText(a[62])
    _:SetValue(i.PropNormalColour[2] * 100)
    _.OnValueChanged = function(self, Y) i.PropNormalColour[2] = Y / 100 end
    local a0 = vgui.Create(a[53], U)
    a0:SetPos(10, 170)
    a0:SetSize(250, 20)
    a0:SetMin(0)
    a0:SetMax(100)
    a0:SetDecimals(0)
    a0:SetText(a[63])
    a0:SetValue(i.PropNormalColour[3] * 100)
    a0.OnValueChanged = function(self, Y) i.PropNormalColour[3] = Y / 100 end
    local ESP = vgui.Create(a[49], U)
    ESP:SetValue(i.ESP)
    ESP:SetText(a[64])
    ESP:SetPos(5, 200)
    ESP:SizeToContents()
    ESP.OnChange = function(self, W) i.ESP = W end
    local Boxes = vgui.Create(a[49], U)
    Boxes:SetValue(i.Boxes)
    Boxes:SetText(a[65])
    Boxes:SetPos(130, 200)
    Boxes:SizeToContents()
    Boxes.OnChange = function(self, W) i.Boxes = W end
end

local function a3()
    p()
    S:SetVisible(false)
end

d(a[66], T)
d(a[67], a3)
local function a4()
    i.PropWalls = not i.PropWalls
    i.PlayerWalls = i.PropWalls
    i.ESP = i.PropWalls
    A()
end

d(a[68], a4)
local function a5()
    if ulx then
        MsgC(Color(0, 255, 0, 255), a[69])
        timer.Simple(2, function() MsgC(Color(0, 255, 0, 255), a[70]) end)
        timer.Simple(4, function() MsgC(Color(0, 255, 0, 255), a[71]) end)
        timer.Simple(6, function() MsgC(Color(0, 255, 0, 255), a[72]) end)
        timer.Simple(8, function() MsgC(Color(0, 255, 0, 255), a[73]) end)
        timer.Simple(10, function() MsgC(Color(0, 255, 0, 255), a[74]) end)
        timer.Simple(10.5, function() chat.AddText(Color(0, 0, 0, 255), a[75], Color(160, 200, 200, 255), a[76], Color(80, 0, 120, 255), a[77], Color(160, 200, 200, 255), a[78], Color(0, 255, 0, 255), a[79]) end)
    else
        MsgC(Color(0, 255, 0, 255), a[80])
    end
end

d(a[81], a5)