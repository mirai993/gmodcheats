--[[
	lua/new.lua
	";exit | (STEAM_0:0:21513525)
	===DStream===
]]

--[[************************************************************************
      ______          
	 / ____/___  _____
	/ __/ / __ \/ ___/
   / /___/ /_/ (__  ) 
  /_____/\____/____/  
                    
					
	- Created by Alvy
	- Credits:
		+ INSERT - INSERT.
	
**************************************************************************]]


--[[--------------------------------------------
	LOCALIZING
	Desc: Because cheats need localization.
--]]--------------------------------------------
local Eos					= {} -- Nothing!
Eos.settings				= {} -- Not started yet.
Eos.hooks					= {} -- Store hooks in a table
Eos.concommands			= {} -- Store concommands in a table
Eos.convars				= {} -- Store the ConVars in a table
Eos.timers					= {} -- Store Timers in a table
Eos.cones					= { normal = {}, hl2 = {}, custom = {}} -- I probably won't even need this, I won't have NoSpread for a long time. Anyways, store cones here.
Eos.meta					= {} -- Store metatables here
Eos.files					= {"Eos.lua", "gm_cvar2.dll", "Register.txt", "IPLogs.txt", "ServerLog.txt", "AntiCheatLog.txt", "Log.txt", "ents.txt"} -- Files to hide and protect
Eos.version				= "0.1 Alpha" -- Version of the cheat.
Eos.ents					= {"coke_lab","printer_onyx","bronze_printer","silver_printer","sapphire_printer","ruby_printer","spawned_weapon","spawned_shipment","weed_plant","diamond_printer","spawned_money","emerald_printer","weapon_ak47_dayz","weapon_mp5_dayz","weapon_deagle_dayz","sapphire_money_printer","amethyst_money_printer","topaz_money_printer","emerald_money_printer"} -- Ents to show on the esp
Eos.invalidents			= {"player","prop_physics","viewmodel",} -- Ents to not show on the esp
Eos.weapons				= {["weapon_crossbow"] = 3110,}
Eos.World	  = { players = {} }

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

local _G					= table.Copy(_G)
local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [detour]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;



--Fonts--
surface.CreateFont("espFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("espFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Eos_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("Eos_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	Eos.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	Eos.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookadd(Type,Function)
end

/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function Eos.Print(msg)
	print("[Eos] "..msg)
end

function Eos.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
iceblue, "[Eos] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/**************
Random String
**************/
function RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function AddTimer( sec, rep, func )
	local index = RandomString( 10 )	
	Eos.timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function AddCMD(Name,Function)
	Eos.Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function RemoveCMD(Name)
	Eos.Print("[REMOVED] ConCommand: "..Name.."")
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

-- AddConVar
function AddConVar(convar,str,save,data)
	return CreateClientConVar("Eos_"..convar,str,true,false), Eos.Print("[ADDED] ConVar: Eos_"..convar.." ["..str.."]")
end

/***************************************
Name: RunConsoleCommand shit
Purpose: Detours, Loggers
****************************************/
/*function RunConsoleCommand(cmd,...)
	Eos.Print("RunConsoleCommand: "..cmd)
	MsgN("RunConsoleCommand: "..cmd)
	return old_rcc(cmd,...)
end*/

/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) Eos.Notify(red,"Error in the Lua script!") end
function Error(...) Eos.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) Eos.Notify(red,"Error in the Lua script!") end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end


/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = {}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end    
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end

/**************************************
Name: Number shit
Purpose: Format number, round number, etc
**************************************/
function CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain
	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"
	famount = math.abs(RoundNum(amount,decimal))
	famount = math.floor(famount)
	remain = RoundNum(math.abs(amount) - famount, decimal)
	formatted = CommaValue(famount)
	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end
	formatted = (prefix or "") .. formatted 
	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end
	return formatted
end

function ConvertTime(sSeconds)
	local nSeconds = tonumber(sSeconds)
	if nSeconds <= 0 then
			return 0;
		else
			local nHours = string.format("%02.f", math.floor(nSeconds/3600));
			local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
			local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
		if tonumber( nHours ) > 0 then
			return nHours..":"..nMins..":"..nSecs
		elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
			return nMins..":"..nSecs
		elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
			return nMins..":"..nSecs
		end
	end
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function Eos.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: GetColors
Purpose: Get Colors
****************************/
function SetColors( e )
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/
AddConVar("esp_Info",0)
AddConVar("esp_Box",0)
AddConVar("esp_HPBar",0)
AddConVar("esp_Skeleton",0)
AddConVar("esp_Tracer",0)
AddConVar("esp_Crosshair",0)
AddConVar("esp_Chams",0)
AddConVar("esp_Chams_Material","Solid")
AddConVar("esp_Ents",0)
AddConVar("esp_Distance",1000)

/*AddConVar("misc_Bunnyhop",0)
AddConVar("misc_TTT",0)
AddConVar("misc_ChatSpam",0)
AddConVar("misc_ChatSpam_Msg","visit www.sethhack.seth.im.me.co.cc.net.org.dk.uk.com.gov")
AddConVar("misc_AntiAFK",0)
AddConVar("misc_CSNoclip",0)
AddConVar("misc_Thirdperson",0)
AddConVar("misc_RPGod",0)
AddConVar("misc_Namechanger",0)
AddConVar("misc_ShowNotifications",0)

AddConVar("perp_Fuel",0)
AddConVar("perp_Druggy",0)
AddConVar("perp_Weed",0)
AddConVar("perp_RPNames",0)
AddConVar("perp_PlayerInfo",0)*/

AddConVar("aim_Friendly",0)
AddConVar("aim_Steam",0)
AddConVar("aim_Admins",0)
AddConVar("aim_Auto",0)
AddConVar("aim_NoRecoil",0)
AddConVar("aim_Offset",0)
AddConVar("aim_Trigger",0)
AddConVar("aim_Silent",0)
AddConVar("aim_anti", 0)

/***********************************
concommands to find entities and shit
**************************************/

/*AddCMD("_ents",function()
PrintTable(ents.GetAll())
end)

AddCMD("_players",function()
PrintTable(player.GetAll())
end)*/


/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
*******************************************/

local G = _G

 local Aimspots = {
	"head",
	"forward",
	"eyes"
};


local function Aimspot( e )
	local Pos; // empty the var
	for k, v in pairs( Aimspots ) do
		if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
			Pos = e:GetAttachment( e:LookupAttachment( v ) )["Pos"];
		end
	end
	return Pos;
end

local function bIsVisible( e )
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && e:IsValid() && e != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && e:LookupBone("ValveBiped.Bip01_Head1") != nil && e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), e }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end


local function bIsValid( e )
	if (!InFov( e ) ) then return false; end
	--if( !IsValid( e ) or !( e:IsPlayer())) then return false; end
	if( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then return false; end
	if( GetConVarNumber("Eos_aim_Friendly") == 0 && e:Team() == LocalPlayer():Team() ) then return false; end
	if( GetConVarNumber("Eos_aim_Steam") == 0 && e:GetFriendStatus() == "friend" ) then return false; end
	if( GetConVarNumber("Eos_aim_Admins") == 0 && e:IsAdmin() ) then return false; end
	if ( e:Team() == TEAM_SPECTATOR || e:Team() == TEAM_SPECTATOR ) then return false; end
	return true;
end

local function GetTargets()
	local Targets = {0,0};
	for k, v in pairs(player.GetAll()) do
		if bIsVisible( v ) and bIsValid( v ) then
			local Diff = ( v:EyePos() - LocalPlayer():EyePos() ):GetNormal();
			Diff = Diff - LocalPlayer():GetAimVector();
			Diff = Diff:Length();
			Diff = math.abs( Diff );
			if( Diff < Targets[2] || Targets[1] == 0 ) then
				Targets = { v, Diff };
			end
		end	
	end
	return( Targets[1] != 0 && Targets[1] != LocalPlayer() ) && Targets[1] || nil;
end
-- that was in hera 
function InFov( ent )
	local fov = 180  --Convar
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end


function Prediction(Pos,pl)
	if IsValid(pl) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local Distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local Weapon = ( LocalPlayer().GetActiveWeapon and ( IsValid( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )		
		if Weapon and Eos.weapons[ Weapon ] then
			local Time = Distance / Eos.weapons[ Weapon ]
			return Pos + pl:GetVelocity() * time
		end
	end
	return Pos
end

function Aimbot(ucmd)
	if ShouldAim == 1 then
		local Target = GetTargets();
		if( !Target ) then return; end
		Locked = true;
		local Aimspot = Aimspot( Target );
		Prediction( Target, Aimspot );
		Aimspot = (Aimspot - Vector(0,0,GetConVarNumber("Eos_aim_Offset")))
		local Angl = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angl.p = math.NormalizeAngle( Angl.p )
		Angl.y = math.NormalizeAngle( Angl.y )
		Spread = Angle( Angl.p, Angl.y, 0 )
		if GetConVarNumber("Eos_aim_Auto") == 1 then
			ucmd:SetButtons( bit.bor(ucmd:GetButtons(), IN_ATTACK) );
		end
	debug.getregistry()["CUserCmd"].SetViewAngles(ucmd,Spread)
	end
	if(!ShouldAim) then
		Locked = false;
	end
end

local function FireEx()
    old_rcc("+attack")
end

local function StopFireEx()
    old_rcc("-attack")
end

-- Triggerbot, thanks _Hyperion, fuck traces
AddHook("CreateMove",function()
if GetConVarNumber("Eos_aim_Trigger") == 1 then
    local pos = LocalPlayer():GetShootPos()
    local ang = LocalPlayer():GetAimVector()
    local tracedata = {}
    tracedata.start = pos
    tracedata.endpos = pos+(ang*99899899899)
    local trace = util.TraceLine(tracedata)
    if(trace.HitNonWorld) then
        target = trace.Entity
        if(target:IsPlayer()) then
            FireEx()
            timer.Simple(0.1, StopFireEx)
        end
    end
end
end)

//fack
AddCMD("+Eos_Aim",function()
ShouldAim = 1
end)

AddCMD("-Eos_Aim",function()
ShouldAim = 0
end)

--[[--------------------------------------------
	ANTI-AIM
	Desc: Because anti-aim.
	Credits: Not Le_Troller
	Real Credits: Alvy
--]]--------------------------------------------
AddHook("CreateMove",function(cmd, u)
	if GetConVarNumber("Eos_aim_Anti") == 1 then
		if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
		local aa = cmd:GetViewAngles()
		cmd:SetViewAngles(Angle(-181, aa.y, 180))
	end
end)

/**********************
Name: Hooks
Purpose: Hook shit
***********************/

function hooks_hudpaint()
//esp()
//perp_Druggy()
//perp_PlayerInfo()
//Notifications()
end

function hooks_postdraw()
//Chams()
end

function hooks_think()
//Misc();
//NameChanger();
end

function hooks_renderscreenspaceeffects()
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd);
end

function Eos.hooks:load()
MsgN("Loaded hooks")
AddHook("HUDPaint",hooks_hudpaint)
AddHook("PostDrawEffects",hooks_postdraw)
AddHook("Think",hooks_think)
AddHook("CalcView",hooks_calcview)
AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
AddHook("CreateMove",hooks_createmove)
end
Eos.hooks:load(); -- load them

function Eos.hooks:unload()
RemoveHook("HUDPaint",hooks_hudpaint)
RemoveHook("CalcView",hooks_calcview)
RemoveHook("PostDrawEffects",hooks_postdraw)
RemoveHook("Think",hooks_think)
RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
RemoveHook("CreateMove",hooks_createmove)
end

function Eos.hooks:reload()
MsgN("Reloaded hooks")
Eos.hooks:unload()
Eos.hooks:load()
end

function unload()
MsgN("Unloaded.")
Eos.hooks:unload()
old_rcc("-Eos_Menu")
RemoveCMD("+Eos_Menu")
RemoveCMD("-Eos_Menu")
RemoveCMD("+Eos_Aim")
RemoveCMD("-Eos_Aim")
RemoveCMD("+Eos_Speed")
RemoveCMD("-Eos_Speed")
RemoveCMD("Eos_Menu_Toggle")
timer.Destroy("TTT")
end

/*******
RUN LAST
********/

Eos.Notify(white,"loaded version "..Eos.version..".")
MsgN("Loaded!")