--[[
	https://github.com/awesomeusername69420/miscellaneous-gmod-stuff

	ConCommands:
		bfesp_menu	-	Shows the menu
]]

--colors yay
MsgC( Color( 123, 255, 248 ), [[



██████████████████████████████████████████████████████
█─▄▄─█▄─▀─▄█▄─█─▄█─▄▄▄─█─▄▄─█▄─▄▄▀█─▄▄─█▄─▀█▄─▄█▄─▄▄─█
█─██─██▀─▀███▄─▄██─███▀█─██─██─██─█─██─██─█▄▀─███─▄█▀█
▀▄▄▄▄▀▄▄█▄▄▀▀▄▄▄▀▀▄▄▄▄▄▀▄▄▄▄▀▄▄▄▄▀▀▄▄▄▄▀▄▄▄▀▀▄▄▀▄▄▄▄▄▀
██████████████████████████████████████████████████████

     ███████ ]▄▄▄▄▄▄▄▄▄-----------● pew pew pew
▂▄▅█████████▅▄▃▂
███████████████████].

]])
--incude some things

--include("includes/modules/outline.lua")
--pcall(RunString, file.Read("lua/miscellaneous-gmod-stuff-main/Cheaterino/AntiScreengrab.lua", "GAME"))
--pcall(RunString, file.Read("lua/miscellaneous-gmod-stuff-main/Cheaterino/BitflagESP.lua", "GAME"))

--yay config shit
surface.CreateFont("methshit", {
	font = "Tahoma",
	size = 15,
	weight = 900,
})

surface.CreateFont( "epic", {
	font = "TabLarge", 
	extended = false,
	size = 13,
	weight = 900,
	blursize = 0
} )

local em = FindMetaTable("Entity")
local pm = FindMetaTable("Player")
local cm = FindMetaTable("CUserCmd")
local wm = FindMetaTable("Weapon")
local am = FindMetaTable("Angle")
local vm = FindMetaTable("Vector")
local im =  FindMetaTable("IMaterial")

local me = LocalPlayer()
local steam = me:SteamID64()
local realname = me:Nick()
local date = os.date( "%m/%d/%Y" )

--material
down = Material("vgui/gradient-u")
up = Material("vgui/gradient-d")
--settings
--location
local X = ScrW()/2 - 130
local Y = ScrH()/10 - 109
--size
local SizeX = 260
local SizeY = 30

local glowColor = Color(255, 0, 0) -- Default glow color is red
local function ToggleGlow()
    enableGlow = not enableGlow
end

local User = nil
local ConfigFolder = "Oxycodone"
local ConfigFileExtension = "text"
local Derama = {
	ConfigTable = {
--------------------------------------------------------------------------
-- Use this for reference, comment it out whenever.

		["tab.checkbox"] = false,
		["tab.button"] = nil, -- Buttons are set to nil and created later on. Look at how the config buttons work.
		["tab.binder"] = KEY_F,
		["tab.combobox"] = {
			Option = "Option #1", -- The selected option.
			Options = {"Option #1", "Option #2", "Option #3"}, -- The options we have to select.
		},

		["tab.slider"] = 15.9,
		["tab.colormixer"] = Color(255, 0, 0, 255),
		["tab.textentry"] = "entry text",

--------------------------------------------------------------------------

		["miscellaneous.movement.autojump"] = false,
		["miscellaneous.debug.info"] = false,
		["visuals.checkbox.master"] = false,
		["visuals.checkbox.crosshair"] = false,
		["visuals.size.crosshair"] = 100,
		["visuals.checkbox.watermark"] = false,
		--["visuals.glow.player"] = false,
		["aimbot.toggle.fov"] = 10,
		--["colors.colormixer.crosshair"] = Color(255, 0, 0, 255),
		["settings.menu.button"] = KEY_INSERT,
		["settings.unload"] = nil,
		["settings.config"] = {
			Option = "",
			Options = {},
		},

		["settings.config.name"] = "",
		["settings.config.rename"] = nil,
		["settings.config.save"] = nil,
		["settings.config.load"] = nil,
		["settings.config.delete"] = nil,
	},

	LayoutTable = { --gui elements

--------------------------------------------------------------------------
-- Use this for reference, comment it out whenever.
-- The "Variable" is the value of the data type of the gui element which is supposed to be set above by first identifying it by a config variable.
-- You can also align the elements using "Align" which you set to a string either "Center" or "Right", "Left" is set automatically.

		{Title = "Tab", Controls = {
			{Type = "Label", Text = "This is a Label"},
			{Type = "CheckBox", Text = "This is a CheckBox", Variable = "tab.checkbox"},
			{Type = "Button", Text = "This is a Button", Variable = "tab.button"},
			{Type = "Binder", Text = "This is a Binder", Variable = "tab.binder"},
			{Type = "ComboBox", Text = "This is a ComboBox", Variable = "tab.combobox"},
			{Type = "Slider", Text = "This is a Slider", Minimum = -100, Maximum = 100, Decimals = 1, Variable = "tab.slider"},
			{Type = "ColorMixer", Text = "This is a ColorMixer", Variable = "tab.colormixer"},
			{Type = "TextEntry", Text = "This is a TextEntry", Variable = "tab.textentry"},
		}},

--------------------------------------------------------------------------

		{Title = "Aimbot", controls = {
			{Type = "Slider", Text = "aimbot FOV", Minimum = -100, Maximum = 100, Decimals = 1, Variable = "aimbot.toggle.fov"},
		}},
		{Title = "Visuals", Controls = {
			{Type = "CheckBox", Text = "ESP", Variable = "visuals.checkbox.master"},
			{Type = "CheckBox", Text = "Crosshair", Variable = "visuals.checkbox.crosshair"},
			{Type = "Slider", Text = "Crosshair size", Minimum = 1, Maximum = 180, Decimals = 1, Variable = "visuals.size.crosshair"},
			{Type = "CheckBox", Text = "Watermark", Variable = "visuals.checkbox.watermark"},
			--{Type = "CheckBox", Text = "glow", Variable = "visuals.glow.player"},
		}},
		{Title = "Miscellaneous", Controls = {
			{Type = "CheckBox", Text = "Auto Jump", Variable = "miscellaneous.movement.autojump"},
			{Type = "CheckBox", Text = "debug info", Variable = "miscellaneous.debug.info"},
		}},

		{Title = "Colors"},
		--{Type = "ColorMixer", Text = "Crosshair color", Variable = "colors.colormixer.crosshair"},
		{Title = "Settings", Controls = {
			{Type = "Binder", Text = "Menu Button", Variable = "settings.menu.button"},
			{Type = "Button", Text = "Unload", Variable = "settings.unload"},
			{Type = "ComboBox", Align = "Center", Text = "Config", Variable = "settings.config"},
			{Type = "TextEntry", Align = "Center", Text = "Name", Variable = "settings.config.name"},
			{Type = "Button", Align = "Center", Text = "Rename", Variable = "settings.config.rename"},
			{Type = "Button", Align = "Center", Text = "Save", Variable = "settings.config.save"},
			{Type = "Button", Align = "Center", Text = "Load", Variable = "settings.config.load"},
			{Type = "Button", Align = "Center", Text = "Delete", Variable = "settings.config.delete"},
		}},
	},
}

local xcord = ScrW() / 2
local ycord = ScrH() / 2

local Util = {
	Buttons = {},
	Hooks = {}
}

function Util.IsButtonPressed(Button)
	if (Util.Buttons[Button] == nil) then
		Util.Buttons[Button] = true
	end

	return input.IsButtonDown(Button) and not Util.Buttons[Button]
end

function Util.UpdateButtons()
	for Button = BUTTON_CODE_NONE, BUTTON_CODE_COUNT do
		Util.Buttons[Button] = input.IsButtonDown(Button)
	end
end

function Util.AddHook(Event, Func)
	hook.Add(Event, "Derama", Func)
end

function Util.RemoveHook(Event)
	hook.Remove(Event, "Derama")
end

local GUI = {}

function GUI.Label(ScrollPanel, Control, XPosition, YPosition)
	if (not Control.Text) then
		Control.Text = "This is a Label"
	end

	if (not Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	local Label = vgui.Create("DLabel", ScrollPanel)

	Label:SetPos(XPosition, YPosition)
	Label:SetTextColor(Color(0, 0, 0, 0))

	Label.Paint = function(self, Width, Height)
		self:SetText(Control.Text)

		surface.SetFont("DermaDefault")

		draw.SimpleTextOutlined(self:GetText(), "DermaDefault", 1, 0, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))

		self:SetWidth(surface.GetTextSize(self:GetText()) + 1)
	end
end

function GUI.CheckBox(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a CheckBox"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = false
	end

	local CheckBox = vgui.Create("DCheckBoxLabel", ScrollPanel)

	CheckBox:SetText(Control.Text)
	CheckBox:SetPos(XPosition, YPosition)

	CheckBox.Label:SetTextColor(Color(0, 0, 0, 0))
	CheckBox.Label:Dock(RIGHT)
	CheckBox.Label:DockMargin(0, 0, 5, 0)

	CheckBox.OnChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	CheckBox.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])
	end

	CheckBox.Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered() || CheckBox.Label:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		surface.DrawRect(0, 0, Width, Height)

		if (self:GetChecked()) then
			surface.SetDrawColor(0, 255, 0, 255)
			surface.DrawRect(2, 2, Width - 4, Height - 4)
			surface.SetDrawColor(0, 128, 0, 255)
			surface.DrawOutlinedRect(2, 2, Width - 4, Height - 4)
		end

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)
	end

	CheckBox.Label.Paint = function(self, Width, Height)
		surface.SetFont("DermaDefault")

		draw.SimpleTextOutlined(self:GetText(), "DermaDefault", 1, 0, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))

		self:SetWidth(surface.GetTextSize(self:GetText()) + 1)
	end
end

function GUI.Button(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Button"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = function()
			Error("There is no function for this button!")
		end
	end

	local Button = vgui.Create("DButton", ScrollPanel)

	Button:SetText(Control.Text)
	Button:SetSize(190, 20)
	Button:SetPos(XPosition, YPosition)
	Button:SetTextColor(Color(0, 0, 0, 0))

	Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (self:IsDown()) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "DermaDefault", Width / 2, Height / 2, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (Derama.ConfigTable[Control.Variable]) then
			self.DoClick = Derama.ConfigTable[Control.Variable]
		end
	end
end

function GUI.Binder(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Binder"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = KEY_NONE
	end

	local Binder = vgui.Create("DBinder", ScrollPanel)

	Binder:SetSize(190, 20)
	Binder:SetPos(XPosition, YPosition + 15)
	Binder:SetTextColor(Color(0, 0, 0, 0))

	Binder.OnChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	Binder.Paint = function(self, Width, Height)
		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (self:IsDown()) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "DermaDefault", Width / 2, Height / 2, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (!self.Trapping) then
			self:SetValue(Derama.ConfigTable[Control.Variable])
		end
	end
end

function GUI.ComboBox(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a ComboBox"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = {
			Option = "",
			Options = {}
		}
	end

	local ComboBox = vgui.Create("DComboBox", ScrollPanel)

	ComboBox:SetValue(Derama.ConfigTable[Control.Variable].Option)
	ComboBox:SetSize(190, 20)
	ComboBox:SetPos(XPosition, YPosition + 15)
	ComboBox:SetTextColor(Color(0, 0, 0, 0))
	ComboBox:SetSortItems(false)

	ComboBox.DropButton:SetVisible(false)

	ComboBox.OnSelect = function(self, Index, Value)
		Derama.ConfigTable[Control.Variable].Option = Value
	end

	ComboBox.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable].Option)

		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (self:IsHovered() && input.IsButtonDown(MOUSE_LEFT)) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		if (self:IsMenuOpen()) then
			self.Menu:MoveToFront()

			if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
				self:CloseMenu()
			end
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "DermaDefault", 10, Height / 2, Color(0, 0, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(self:IsMenuOpen() && "5" || "6", "Marlett", Width - 5, Height / 2, Color(0, 0, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local OriginalOnMenuOpened = ComboBox.OnMenuOpened

	ComboBox.OnMenuOpened = function(self, Menu)
		OriginalOnMenuOpened(self, Menu)

		local Children = Menu:GetCanvas():GetChildren()

		for Index, Child in ipairs(Children) do
			Child:SetTextColor(Color(0, 0, 0, 0))

			Child.Paint = function(self, Width, Height)
				surface.SetDrawColor(210, 210, 210, 255)

				if (self:IsHovered()) then
					surface.SetDrawColor(255, 255, 255, 255)
				end

				surface.DrawRect(0, 0, Width, Height)
				surface.SetDrawColor(0, 0, 0, 255)

				if (Index == 1 && #Children > 1) then
					surface.DrawOutlinedRect(0, -1, Width, Height + 2)
				elseif (Index == #Children) then
					surface.DrawOutlinedRect(0, -1, Width, Height + 1)
				else
					surface.DrawOutlinedRect(0, -1, Width, Height + 2)
				end

				draw.SimpleText(self:GetText(), "DermaDefault", 10, Height / 2, Color(0, 0, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
	end

	local OriginalOpenMenu = ComboBox.OpenMenu

	ComboBox.OpenMenu = function(self, ControlOpener)
		self:Clear()

		local Options = Derama.ConfigTable[Control.Variable].Options

		if (Options) then
			for Index, Option in ipairs(Options) do
				self:AddChoice(tostring(Option))
			end
		end

		OriginalOpenMenu(self, ControlOpener)
	end
end

function GUI.Slider(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a Slider"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = 0
	end

	if (!Control.Minimum) then
		Control.Minimum = -10
	end

	if (!Control.Maximum) then
		Control.Maximum = 10
	end

	if (!Control.Decimals) then
		Control.Decimals = 0
	end

	local Slider = vgui.Create("DNumSlider", ScrollPanel)

	Slider:SetText(Control.Text)
	Slider:SetSize(190, 50)
	Slider:SetPos(XPosition, YPosition + 15)
	Slider:SetMin(Control.Minimum)
	Slider:SetMax(Control.Maximum)
	Slider:SetDecimals(Control.Decimals)

	Slider.Label:SetVisible(false)
	Slider.TextArea:SetVisible(false)

	Slider.OnValueChanged = function(self, Value)
		Derama.ConfigTable[Control.Variable] = math.Truncate(Value, self:GetDecimals())

		if (Derama.ConfigTable[Control.Variable] == -0) then
			Derama.ConfigTable[Control.Variable] = 0
		end

		self:SetValue(Derama.ConfigTable[Control.Variable])
	end

	Slider.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])

		draw.SimpleTextOutlined(self:GetText(), "DermaDefault", Width / 2, 0, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255 / 3))
		draw.SimpleTextOutlined(Derama.ConfigTable[Control.Variable], "DermaDefault", Width / 2, Height, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(0, 0, 0, 255 / 3))
	end

	Slider.Slider.Paint = function(self, Width, Height)
		local Dragging = self:GetDragging()

		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (Dragging) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		surface.DrawRect(5, Height / 2 - 3, Width - 10, 4)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(5, Height / 2 - 3, Width - 10, 4)

		local XPosition, YPosition = self.Knob:GetPos()

		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (Dragging) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		surface.DrawRect(XPosition + 5, YPosition, 5, 15)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(XPosition + 5, YPosition, 5, 15)
	end

	Slider.Slider.Knob.Paint = function(self, Width, Height)
	end
end

local AlphaGrid = Material("gui/alpha_grid.png", "nocull")

function GUI.ColorMixer(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a ColorMixer"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition + 20, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = Color(0, 0, 0, 0)
	end

	local Button = vgui.Create("DButton", ScrollPanel)

	Button:SetText("")
	Button:SetSize(15, 15)
	Button:SetPos(XPosition, YPosition)
	Button:SetTextColor(Color(0, 0, 0, 0))

	Button.Paint = function(self, Width, Height)
		surface.SetDrawColor(210, 210, 210, 255)
		surface.SetMaterial(AlphaGrid)
		surface.DrawTexturedRect(0, 0, Width, Height)
		surface.SetDrawColor(Derama.ConfigTable[Control.Variable])
		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)
	end

	local ColorMixer = nil

	Button.DoClick = function(self)
		if (ColorMixer) then
			ColorMixer:SetVisible(!ColorMixer:IsVisible())

			return
		end

		ColorMixer = vgui.Create("DColorMixer", ScrollPanel)

		ColorMixer:SetSize(190, 100)
		ColorMixer:SetPos(XPosition, YPosition)
		ColorMixer:SetPalette(false)
		ColorMixer:SetAlphaBar(true)
		ColorMixer:SetWangs(false)
		ColorMixer:SetColor(Derama.ConfigTable[Control.Variable])

		ColorMixer.ValueChanged = function(self, Value)
			Derama.ConfigTable[Control.Variable] = Value
		end

		ColorMixer.Paint = function(self, Width, Height)
			self:MoveToFront()

			if (self:GetColor() != Derama.ConfigTable[Control.Variable]) then
				self:SetColor(Derama.ConfigTable[Control.Variable])
			end

			if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
				self:SetVisible(!self:IsVisible())
			end

			if (!(self:IsHovered() || (self.HSV:IsHovered() || self.HSV.Knob:IsHovered()) || self.Alpha:IsHovered() || self.RGB:IsHovered()) && Util.IsButtonPressed(MOUSE_LEFT)) then
				self:SetVisible(!self:IsVisible())
			end
		end

		ColorMixer.HSV.Knob.Paint = function(self, Width, Height)
			surface.SetDrawColor(210, 210, 210, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(230, 230, 230, 255)
			end

			if (ColorMixer.HSV.Dragging || self:IsDown()) then
				surface.SetDrawColor(255, 255, 255, 255)
			end

			surface.DrawRect(3, 3, Width - 6, Height - 6)
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect(3, 3, Width - 6, Height - 6)
		end
	end
end

function GUI.TextEntry(ScrollPanel, Control, XPosition, YPosition)
	if (!Control.Text) then
		Control.Text = "This is a TextEntry"
	end

	if (!Control.XPosition) then
		Control.XPosition = 0
	end

	if (!Control.YPosition) then
		Control.YPosition = 0
	end

	XPosition = XPosition + Control.XPosition
	YPosition = YPosition + Control.YPosition

	GUI.Label(ScrollPanel, Control, XPosition, YPosition)

	if (!Control.Variable) then
		Control.Variable = Control.Text
	end

	if (!Derama.ConfigTable[Control.Variable]) then
		Derama.ConfigTable[Control.Variable] = ""
	end

	local TextEntry = vgui.Create("DTextEntry", ScrollPanel)

	TextEntry:SetSize(190, 20)
	TextEntry:SetPos(XPosition, YPosition + 15)
	TextEntry:SetUpdateOnType(true)
	TextEntry:SetTextColor(Color(0, 0, 0, 0))
	TextEntry:SetCursorColor(Color(0, 0, 0, 0))
	TextEntry:SetHighlightColor(Color(0, 0, 0, 0))
	TextEntry:SetPlaceholderColor(Color(0, 0, 0, 0))

	TextEntry.OnValueChange = function(self, Value)
		Derama.ConfigTable[Control.Variable] = Value
	end

	TextEntry.Paint = function(self, Width, Height)
		self:SetValue(Derama.ConfigTable[Control.Variable])

		if (input.IsButtonDown(Derama.ConfigTable["settings.menu.button"])) then
			self:FocusNext()
		end

		surface.SetDrawColor(210, 210, 210, 255)

		if (self:IsHovered()) then
			surface.SetDrawColor(230, 230, 230, 255)
		end

		if (self:IsEditing()) then
			surface.SetDrawColor(255, 255, 255, 255)
		end

		surface.DrawRect(0, 0, Width, Height)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, Width, Height)

		draw.SimpleText(self:GetText(), "DermaDefault", 5, Height / 2, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local Menu = {
	Frame = nil,
	ActiveTab = nil
}

function Menu.LayoutControls(ScrollPanel, TabTitle) -- Mother of god ;-;
	for Index, Tab in ipairs(Derama.LayoutTable) do
		if (Tab.Title == TabTitle) then
			local Controls = Tab.Controls

			if (Controls) then
				local XPosition = 5
				local LeftYPosition = 0
				local CenterYPosition = 0
				local RightYPosition = 0

				for Index, Control in ipairs(Controls) do
					if (!Control.Align || Control.Align == "Left" || (Control.Align != "Center" && Control.Align != "Right")) then
						XPosition = 5

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "Slider") then
							LeftYPosition = LeftYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, LeftYPosition)

							LeftYPosition = LeftYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, LeftYPosition)
						elseif (Control.Type == "Spacer") then
							LeftYPosition = LeftYPosition + (Control.Space || 20)
						end

						LeftYPosition = LeftYPosition + 20
					end

					if (Control.Align == "Center") then
						XPosition = 205

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "Slider") then
							CenterYPosition = CenterYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, CenterYPosition)

							CenterYPosition = CenterYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, CenterYPosition)
						elseif (Control.Type == "Spacer") then
							CenterYPosition = CenterYPosition + (Control.Space || 20)
						end

						CenterYPosition = CenterYPosition + 20
					end

					if (Control.Align == "Right") then
						XPosition = 405

						if (Control.Type == "Label") then
							GUI.Label(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "CheckBox") then
							GUI.CheckBox(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "Button") then
							GUI.Button(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 5
						elseif (Control.Type == "Binder") then
							GUI.Binder(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "ComboBox") then
							GUI.ComboBox(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "Slider") then
							RightYPosition = RightYPosition - 10

							GUI.Slider(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 55
						elseif (Control.Type == "TextEntry") then
							GUI.TextEntry(ScrollPanel, Control, XPosition, RightYPosition)

							RightYPosition = RightYPosition + 20
						elseif (Control.Type == "ColorMixer") then
							GUI.ColorMixer(ScrollPanel, Control, XPosition, RightYPosition)
						elseif (Control.Type == "Spacer") then
							RightYPosition = RightYPosition + (Control.Space || 20)
						end

						RightYPosition = RightYPosition + 20
					end
				end
			end
		end
	end
end

function Menu.Render()
	if (Menu.Frame) then
		Menu.Frame:SetVisible(!Menu.Frame:IsVisible())

		return
	end

	Menu.Frame = vgui.Create("DFrame")

	Menu.Frame:SetTitle("0xyc0d0n3")
	Menu.Frame:SetSize(640, 480)
	Menu.Frame:Center()
	Menu.Frame:MakePopup()
	Menu.Frame:SetScreenLock(true)
	
	
	Menu.Frame.lblTitle:SetVisible(false)
	Menu.Frame.btnMinim:SetVisible(false)
	Menu.Frame.btnMaxim:SetVisible(false)
	Menu.Frame.btnClose:SetVisible(false)

	Menu.Frame.Paint = function(self, Width, Height)
		self:MoveToFront()

		surface.SetDrawColor(255, 28, 117, 200)
		surface.DrawRect(0, 0, Width, 24)
		surface.SetDrawColor(60, 60, 60, 255)
		surface.DrawOutlinedRect(0, 0, Width, 24)
		surface.SetDrawColor(73, 49, 237, 200)
		surface.DrawRect(0, 24, Width, Height - 24)
		surface.SetDrawColor(55, 55, 55, 255)
		surface.DrawOutlinedRect(0, 23, Width, Height - 23)

		draw.SimpleTextOutlined(self:GetTitle(), "methshit", 12, 24 / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255 / 3))
	end

	local PropertySheet = vgui.Create("DPropertySheet", Menu.Frame)

	PropertySheet.tabScroller:SetOverlap(1)

	PropertySheet:Dock(FILL)
	PropertySheet:SetFadeTime(0)

	local OriginalAddSheet = PropertySheet.AddSheet

	PropertySheet.AddSheet = function(self, Label, Panel, Material, NoStretchX, NoStretchY, Tooltip)
		local Sheet = OriginalAddSheet(self, Label, Panel, Material, NoStretchX, NoStretchY, Tooltip)

		Sheet.Tab:SetTextColor(Color(0, 0, 0, 0))

		Sheet.Tab.GetTabHeight = function(self)
			return 20
		end

		Sheet.Tab.ApplySchemeSettings = function(self)
			local LeftMargin, TopMargin, RightMargin, BottomMargin = PropertySheet.tabScroller:GetDockMargin()

			self:SetSize((PropertySheet:GetWide() - LeftMargin) / #PropertySheet:GetItems(), self:GetTabHeight())

			DLabel.ApplySchemeSettings(self)
		end

		Sheet.Tab.Paint = function(self, Width, Height)
			if (self:GetText() == ActiveTab) then
				PropertySheet:SetActiveTab(self)

				ActiveTab = nil
			end

			surface.SetDrawColor(60, 60, 60, 255)
			surface.DrawOutlinedRect(0, 0, Width, Height)
			surface.SetDrawColor(157, 18, 13, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(223, 114, 117, 255)
			end

			if (PropertySheet:GetActiveTab() == self) then
				surface.SetDrawColor(227,28,121, 255)
			end

			surface.DrawRect(1, 1, Width - 2, Height)

			draw.SimpleTextOutlined(self:GetText(), "DermaDefault", Width / 2, Height / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255 / 3))
		end

		return Sheet
	end

	PropertySheet.Paint = function(self, Width, Height)
		surface.SetDrawColor(50, 0, 75, 255)
		surface.DrawRect(0, 20, Width, Height - 20)
		surface.SetDrawColor(70, 70, 70, 255)
		surface.DrawOutlinedRect(0, 20, Width, Height - 20)
	end

	local AddSheet = function(Control)
		local ScrollPanel = vgui.Create("DScrollPanel", PropertySheet)

		ScrollPanel:Dock(FILL)
		ScrollPanel:DockMargin(5, 10, 10, 10)

		ScrollPanel.VBar.Paint = function(self, Width, Height)
			surface.SetDrawColor(180, 180, 180, 255)
			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(90, 90, 90, 255)
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.btnUp.Paint = function(self, Width, Height)
			surface.SetDrawColor(210, 210, 210, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(230, 230, 230, 255)
			end

			if (self:IsDown()) then
				surface.SetDrawColor(255, 255, 255, 255)
			end

			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(105, 105, 105, 255)
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.btnGrip.Paint = function(self, Width, Height)
			surface.SetDrawColor(210, 210, 210, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(230, 230, 230, 255)
			end

			if (self.Depressed) then
				surface.SetDrawColor(255, 255, 255, 255)
			end

			surface.DrawRect(0, 0, Width, Height)

			DisableClipping(true)

			surface.SetDrawColor(105, 105, 105, 255)
			surface.DrawOutlinedRect(0, -1, Width, Height + 2)

			DisableClipping(false)
		end

		ScrollPanel.VBar.btnDown.Paint = function(self, Width, Height)
			surface.SetDrawColor(210, 210, 210, 255)

			if (self:IsHovered()) then
				surface.SetDrawColor(230, 230, 230, 255)
			end

			if (self:IsDown()) then
				surface.SetDrawColor(255, 255, 255, 255)
			end

			surface.DrawRect(0, 0, Width, Height)
			surface.SetDrawColor(105, 105, 105, 255)
			surface.DrawOutlinedRect(0, 0, Width, Height)
		end

		ScrollPanel.VBar.SetUp = function(self, BarSize, CanvasSize)
			self.BarSize = BarSize
			self.CanvasSize = math.max(CanvasSize - BarSize, 0.1)

			self:DockMargin(0, 0, 0, 0)
			self:SetEnabled(true)
			self:InvalidateLayout()
		end

		PropertySheet:AddSheet(Control.Title, ScrollPanel)

		Menu.LayoutControls(ScrollPanel, Control.Title)
	end

	for Index, Control in ipairs(Derama.LayoutTable) do
		AddSheet(Control)
	end
end

function Menu.Toggle()
	if (Util.IsButtonPressed(Derama.ConfigTable["settings.menu.button"])) then
		Menu.Render()
	end
end

function Menu.Destroy()
	if (Menu.Frame) then
		Menu.Frame:Remove()

		Menu.Frame = nil
	end
end

local function RefreshConfigs()
	if (!file.Exists(ConfigFolder, "DATA")) then
		file.CreateDir(ConfigFolder)
	end

	Derama.ConfigTable["settings.config.name"] = ""
	Derama.ConfigTable["settings.config"] = {
		Option = "",
		Options = {}
	}

	local Configs = {}
	local Files, Folders = file.Find(ConfigFolder .. "/*.vtf", "DATA")

	for Index, File in ipairs(Files) do
		File = string.Replace(File, "." .. ConfigFileExtension, "")

		table.insert(Configs, File)
	end

	Derama.ConfigTable["settings.config"].Options = Configs
end

RefreshConfigs()

local function Buttons()
	Derama.ConfigTable["settings.unload"] = function()
		for EventName, Identifier in pairs(hook.GetTable()) do
			Util.RemoveHook(EventName)
		end

		Menu.Destroy()
	end

	Derama.ConfigTable["settings.config.rename"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		file.Rename(Config, string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config.name"], ConfigFileExtension))

		RefreshConfigs()
	end

	Derama.ConfigTable["settings.config.save"] = function()
		if (string.len(Derama.ConfigTable["settings.config.name"]) <= 0) then
			return
		end

		file.Write(string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config.name"], ConfigFileExtension), util.TableToJSON(Derama.ConfigTable))

		RefreshConfigs()
	end

	Derama.ConfigTable["settings.config.load"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		Derama.ConfigTable = util.JSONToTable(file.Read(Config, "DATA"))

		RefreshConfigs()
	end

	Derama.ConfigTable["settings.config.delete"] = function()
		local Config = string.format("%s/%s.%s", ConfigFolder, Derama.ConfigTable["settings.config"].Option, ConfigFileExtension)

		if (!file.Exists(Config, "DATA")) then
			return
		end

		file.Delete(Config)

		RefreshConfigs()
	end
end

Buttons()

local Movement = {}

function Movement.AutoJump(UserCmd)
	if (!Derama.ConfigTable["miscellaneous.movement.autojump"]) then
		return
	end

	if (UserCmd:KeyDown(IN_JUMP) && !User:IsOnGround()) then
		UserCmd:RemoveKey(IN_JUMP)
	end
end

function watermark()
	surface.SetDrawColor(Color(54, 54, 54))
	surface.DrawRect(X, Y, SizeX, SizeY)
	surface.SetDrawColor(Color(237, 0, 96))
	surface.SetMaterial(down)
	surface.DrawTexturedRect(X, Y, SizeX, SizeY)
	surface.SetDrawColor(Color(92, 0, 0))
	surface.SetMaterial(up)
	surface.DrawTexturedRect(X, Y, SizeX, SizeY)
	draw.DrawText( "FPS: "..  math.Round( 1 / FrameTime()), "epic", X + 10, Y + 10, Color( 255, 255, 255, 255 ) )
	draw.DrawText( "Name: "..  realname .. "" , "epic", X + 70, Y + 10, Color( 255, 255, 255, 255 ) )
	draw.DrawText( "Date: "..  date .. "" , "epic", X + 150, Y + 10, Color( 255, 255, 255, 255 ) )
end

local function CheckUser()
	local Client = LocalPlayer()

	if (User != Client && Client != NULL) then
		User = Client
	end

	return IsValid(User)
end

local function InitializeHooks() -- Don't be creating multiple hooks with the same events
	Util.AddHook("PreRender", function()
		CheckUser()
	end)

	Util.AddHook("Tick", function()
		Menu.Toggle()
		Util.UpdateButtons()
	end)

	Util.AddHook("CreateMove", function(UserCmd)
		if (UserCmd:CommandNumber() != 0) then -- Predicted so we don't get any hiccups.
			Movement.AutoJump(UserCmd)
		end
	end)

	Util.AddHook("HUDPaint", function()
		watermark()
	end)
end

local orequire = require

require = function(File)
	orequire(File)

	if (File:find("gamemode") && istable(gamemode)) then
		InitializeHooks()
	end
end

if (CheckUser()) then
	InitializeHooks()
end

