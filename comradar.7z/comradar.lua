--[[
	lua/Hacks/cl_comRadar.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

if ( SERVER ) then return end -- Server you won't run it


require("cvar3") -- Used for Speedhack, NoSpread, Etc...

print('[ComJect]--------------------------------------	')
print('[ComJect] Hack by OverDone						')
print('[ComJect] Modules Loaded							')
print('[ComJect] Anti-Cheat Bypassed					')
print('[ComJect] Open Menu With Com_Menu				')
print('[ComJect]----------------------------------------')

HT = GetConVar('host_timescale')
SC = GetConVar('sv_cheats')
WF = GetConVar('mat_wireframe')
GC = GetConVar('gl_clear')
DS = GetConVar('r_drawskybox')
TD = GetConVar('r_3dsky') 



SC:SetValue(1) -- Set sv_cheats to 1

local Com			= {}
local colors		= {}
Red					= Color( 255, 0, 0, 255 );
Green				= Color( 0, 255, 0, 255 );
Blue				= Color( 0, 0, 255, 255 );
Orange				= Color( 255, 100, 0, 255 );
White				= Color( 255, 255, 255, 255 );
Black				= Color( 0, 0, 0, 255 );

local DarkRP = {
                pot = "Weed",
                shroom = "Shrooms",
                money_printer = "Money Printer",
                gunlab = "Gunlab",
                drug_lag = "Druglab",
                spawned_money = "Money",
                dispenser = "Dispenser",
                gunvault = "Gunvault",
                drugfactory = "Drugfactory",
                gunfactory = "Gunfactory",
                microwave = "Microwave",
                powerplant = "Powerplant",
				}

surface.CreateFont("ESPFont",			{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",		{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",				{font = "akbar", size = 21, weight = 400, antialias = 0})


chat.AddText(
Red, 		"[ComJect]: ",
Green,		"Thanks for buying: ",
Green, 		"ComJect Radar Version 1 for", 
Green, 		" "..LocalPlayer():Nick" ","("..LocalPlayer():SteamID" ",")"
		)
		
chat.AddText(
Red, 		"[ComJect]: ",
Green,		"Look in the ",
Green, 		"Console for more info! "
)
surface.PlaySound("buttons/button19.wav")


-- ConVars --





-- ESP
CreateClientConVar("Com_esp_info",1,true,false)
CreateClientConVar("Com_esp_admin",1,true,false)
CreateClientConVar("Com_esp_friend",1,true,false)
CreateClientConVar("Com_esp_crosshair",1,true,false)
CreateClientConVar("Com_esp_skeleton",0,true,false)
CreateClientConVar("Com_esp_chams",1,true,false)
CreateClientConVar("Com_esp_box",1,true,false)
CreateClientConVar("Com_esp_pritner",1,true,false)



-- Misc
CreateClientConVar('com_misc_bhop', 1, true, false)
CreateClientConVar('com_misc_chatspam', 0, true, false)
CreateClientConVar('com_misc_chatspam_message', '/advert ComJect Radar By OverDone, bought for '..LocalPlayer():Nick' !', true, false)
CreateClientConVar('com_misc_removesky', 0, true, false)
CreateClientConVar("com_speedhack_speed", 3, true, false)





-- Main Code

-- ESP
local function ESP()
if( GetConVarNumber( 'Com_esp_info' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local SteamID = v:SteamID()
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText(	"Name: " 	..v:Name(), 		"ESPFont", Pos.x, Pos.y - 30 , InfoColor,TEXT_ALIGN_CENTER);
draw.SimpleText( 	"Health: " 	..v:Health(), 	'ESPFont', Pos.x, Pos.y - 45, InfoColor, TEXT_ALIGN_CENTER );
draw.SimpleText( 	"SteamID: " ..SteamID, 	'ESPFont', Pos.x, Pos.y - 60, InfoColor, TEXT_ALIGN_CENTER );
if( GetConVarNumber("Com_esp_admin") == 1 ) then 
if v:IsAdmin() then
	draw.SimpleText("-[Admin]-","ESPFont" ,Pos.x, Pos.y -80, Red, TEXT_ALIGN_CENTER );
end
if( GetConVarNumber("Com_esp_friend") == 1 ) then 
if v:GetFriendStatus() == "friend" then
	draw.SimpleText("-[Friend]-","ESPFont" ,Pos.x, Pos.y - 100, Blue, TEXT_ALIGN_CENTER );
end
end
end
end
end
end
end
hook.Add( 'HUDPaint', 'ESP', ESP );

function crosshair()
	if GetConVarNumber("Com_esp_crosshair") == 1 then
		local x, y = ScrW() / 2, ScrH() / 2	
		local Speed = 1
		surface.SetDrawColor(255, 0, 0, 255)
		CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
		CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
		mathsin = math.sin(CurTime()*Speed)*4
		mathcos = math.cos(CurTime()*Speed)*4
		mathsin2 = math.sin(CurTime()*Speed+0.1)*4
		mathcos2 = math.cos(CurTime()*Speed+0.1)*4
		mathsin3 = math.sin(CurTime()*Speed-0.1)*4
		mathcos3 = math.cos(CurTime()*Speed-0.1)*4
		surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
		surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
		surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
		surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
	end
end
hook.Add( 'HUDPaint', 'crosshair', crosshair )


local skeleton = {
        { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
        { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
        { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
        { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
        { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
        { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
        { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
        { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
        { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
        { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
        { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
        { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
        { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
       
        { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
        { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
        { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
        { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
     
local function Skeleton(e)    
        if(GetConVarNumber("com_esp_skeleton") == 1 ) then
        if !e:Alive() then return end
        for k, v in pairs( skeleton ) do
                local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
               
                surface.SetDrawColor( Red )
                surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
                end
    end
end
hook.Add("HUDPaint", "SkeletonESP", function()
        for k,v in pairs(player.GetAll()) do
                if v != LocalPlayer() then
                       Skeleton(v)
                end
        end
end) 

//MoneyPrinterESP
function MoneyPrinterESP()
if GetConVarNumber( "com_esp_pritner" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if IsValid( v ) then
if v:GetClass() == "money_printer" or v:GetClass() == "amethyst_money_printer" or v:GetClass() == "emerald_money_printer" or v:GetClass() == "ruby_money_printer" or v:GetClass() == "sapphire_money_printer" or v:GetClass() == "topaz_money_printer" or v:GetClass() == "money_printer_industrial"  or v:GetClass() == "nuclear_money_printer" then
MoneyPrinterPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "ESPFont", MoneyPrinterPos.x, MoneyPrinterPos.y, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                                end
                        end
                end
        end
end
hook.Add( "HUDPaint", "MoneyPrinterESP1", MoneyPrinterESP )


-- MISC

-- Chams
function PlayerModel()
if GetConVarNumber( "com_esp_chams" ) >= 1 then
for k, v in pairs(ents.GetAll()) do
if IsValid( v ) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial( "models/debug/debugwhite" )
cam.Start3D( EyePos(), EyeAngles() )
v:DrawModel()
cam.End3D()
end
end
end
end
end
hook.Add( "HUDPaint", "Playermodel1", PlayerModel )

-- Misc

-- Bunny Hop
function Bunnyhop()
if GetConVarNumber( "com_misc_bhop" ) >= 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump")
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
 
                        end
                end
                        end
                                end
                               
hook.Add("Think", "immabunny", Bunnyhop)

-- Chat
function ChatSpam()
local SpamMessage = GetConVarString("com_misc_chatspam_message")
if GetConVarNumber("com_misc_chatspam") == 1 then
RunConsoleCommand("say",""..SpamMessage.."")
end
end
hook.Add("Think","Fuckchatspamfuck",ChatSpam)

-- SpeedHack

CreateClientConVar("Com_speedhack_speed", 3.5, true, false)
speedon = function()
HT:SetValue(tostring(GetConVarNumber("Com_speedhack_speed")))
SC:SetValue(5.0)
end
 
speedoff = function()
HT:SetValue(1.0)
SC:SetValue(0)
end
 
concommand.Add("+speedhack", speedon)
concommand.Add("-speedhack", speedoff)

-- WorldWireFrame

GC = GetConVar('gl_clear')
DS = GetConVar('r_drawskybox')
TD = GetConVar('r_3dsky') 

function RemoveSky()
        if GetConVarNumber("com_misc_removesky") >= 1 then
        GC:SetValue(1)
        DS:SetValue(0)
        TD:SetValue(0)
        else
        GC:SetValue(0)
        DS:SetValue(1)
        TD:SetValue(0)
        end
end    
hook.Add( 'HUDPaint', 'Ilikemyskyblack', RemoveSky );

-- Derma --
local function ShowFrame()
 
Frame = vgui.Create("DFrame")
Frame:SetSize( 280 , 270 )
Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
Frame:SetTitle("ComJect [V2]")
Frame:SetVisible( true )
Frame:ShowCloseButton( true )
Frame.Paint = function()
        draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 255, 0, 50 ) )
end
Frame:MakePopup()
 
local BSheet = vgui.Create("DPropertySheet" , Frame)
BSheet:SetSize( 270 , 230 )
BSheet:SetPos( 5 , 25 )
BSheet.Paint = function()
        draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
end
 
local Tab = vgui.Create("DLabel")
Tab:SetParent( BSheet )
Tab:SetPos( 0 , 10 )
Tab:SetText("")
 
local Tab2 = vgui.Create("DLabel")
Tab2:SetParent( BSheet )
Tab2:SetPos( 0 , 10 )
Tab2:SetText("")
 
local Tab3 = vgui.Create("DLabel")
Tab3:SetParent( BSheet )
Tab3:SetPos( 0 , 10 )
Tab3:SetText("")
 
local Tab4 = vgui.Create("DLabel")
Tab4:SetParent( BSheet )
Tab4:SetPos( 0 , 10 )
Tab4:SetText("")
 
 
// Options

local EspLabel = vgui.Create("DLabel")
EspLabel:SetParent( Tab2 )
EspLabel:SetPos( 13 , 10 )
EspLabel:SetText("")
EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel:SizeToContents()
 
local EspLabel2 = vgui.Create("DLabel")
EspLabel2:SetParent( Tab2 )
EspLabel2:SetPos( 13 , 90 )
EspLabel2:SetText("")
EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel2:SizeToContents()
 
local EspLabel3 = vgui.Create("DLabel")
EspLabel3:SetParent( Tab2 )
EspLabel3:SetPos( 200 , 10 )
EspLabel3:SetText("")
EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
EspLabel3:SizeToContents()
 
local Esp = vgui.Create( "DCheckBoxLabel")
Esp:SetText( "Esp Info" )
Esp:SetConVar( "com_esp_info" )
Esp:SetParent( Tab2 )
Esp:SetPos( 10 , 30 )
Esp:SetValue( GetConVarNumber("com_esp_info") )
Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp:SizeToContents()
 
local Esp2 = vgui.Create( "DCheckBoxLabel")
Esp2:SetText( "ESP Info Admin" )
Esp2:SetConVar( "com_esp_admin" )
Esp2:SetParent( Tab2 )
Esp2:SetPos( 10 , 110 )
Esp2:SetValue( GetConVarNumber("com_esp_admin") )
Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp2:SizeToContents()
 
local Esp3 = vgui.Create( "DCheckBoxLabel")
Esp3:SetText( "ESP Info Friend" )
Esp3:SetConVar( "com_esp_friend" )
Esp3:SetParent( Tab2 )
Esp3:SetPos( 10 , 130 )
Esp3:SetValue( GetConVarNumber( 'com_esp_friend' ) )
Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp3:SizeToContents()
 
 
local Esp6 = vgui.Create( "DCheckBoxLabel")
Esp6:SetText( "ESP Chams" )
Esp6:SetConVar( "com_esp_chams" )
Esp6:SetParent( Tab2 )
Esp6:SetPos( 10 , 70 )
Esp6:SetValue( GetConVarNumber("com_esp_chams") )
Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp6:SizeToContents()
 
local Esp4 = vgui.Create( "DCheckBoxLabel")
Esp4:SetText( "ESP Skeleton" )
Esp4:SetConVar( "com_esp_skeleton" )
Esp4:SetParent( Tab2 )
Esp4:SetPos( 10 , 90 )
Esp4:SetValue( GetConVarNumber("com_esp_skeleton") )
Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp4:SizeToContents()
 
local Esp5 = vgui.Create( "DCheckBoxLabel")
Esp5:SetText( "Crosshair" )
Esp5:SetConVar( "com_esp_crosshair" )
Esp5:SetParent( Tab2 )
Esp5:SetPos( 10 , 50 )
Esp5:SetValue( GetConVarNumber("com_esp_crosshair") )
Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Esp5:SizeToContents()
 
 
local MiscLabel = vgui.Create("DLabel")
MiscLabel:SetParent( Tab3 )
MiscLabel:SetPos( 13 , 10 )
MiscLabel:SetText("Misc Features")
MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel:SizeToContents()
 
local MiscLabel2 = vgui.Create("DLabel")
MiscLabel2:SetParent( Tab3 )
MiscLabel2:SetPos( 205 , 10 )
MiscLabel2:SetText("")
MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
MiscLabel2:SizeToContents()
 
local Misc = vgui.Create( "DCheckBoxLabel")
Misc:SetText( "Bunnyhop" )
Misc:SetConVar( "com_misc_bhop" )
Misc:SetParent( Tab3 )
Misc:SetPos( 10 , 30 )
Misc:SetValue( GetConVarNumber("com_misc_bhop") )
Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc:SizeToContents()
 
local Misc2 = vgui.Create( "DCheckBoxLabel")
Misc2:SetText( "Remove SkyBox" )
Misc2:SetConVar( "com_misc_removesky" )
Misc2:SetParent( Tab3 )
Misc2:SetPos( 10 , 50 )
Misc2:SetValue( GetConVarNumber("com_misc_removesky") )
Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc2:SizeToContents()
 
local Misc3 = vgui.Create( "DCheckBoxLabel")
Misc3:SetText( "Chat Spam" )
Misc3:SetConVar( "com_misc_chatspam" )
Misc3:SetParent( Tab3 )
Misc3:SetPos( 10 , 70 )
Misc3:SetValue( GetConVarNumber("com_misc_chatspam") )
Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
Misc3:SizeToContents()
 
local NumSliderThingy = vgui.Create( "DNumSlider", Tab4 )
NumSliderThingy:SetPos( 10,0 )
NumSliderThingy:SetSize( 150, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "Speedhack Speed" )
NumSliderThingy:SetMin( 3 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 15 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "com_speedhack_speed" ) -- Set the convar

       
local IsisB = vgui.Create( "DButton", Tab3 )
IsisB:SetSize( 70, 30 )
IsisB:SetPos( 15, 300 )
IsisB:SetText( "Website." )
IsisB.DoClick = function()
       
local HtmlWin = vgui.Create( "DFrame" )
HtmlWin:SetPos( 1,1 )
HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
HtmlWin:SetTitle( "Updates/Information" )
HtmlWin:SetVisible( true )  
HtmlWin:SetDraggable( true )
HtmlWin:ShowCloseButton( false )
HtmlWin:MakePopup()
       
local HTMLWeb = vgui.Create( "HTML", HtmlWin )
HTMLWeb:SetSize(ScrW(), ScrH())
HTMLWeb:SetPos( 0, 50 )
HTMLWeb:OpenURL( "http://www.VoltageHack.webs.com/" )
 
local IsisB2 = vgui.Create( "DButton", HtmlWin )
IsisB2:SetSize( 70, 30 )
IsisB2:SetPos( 3, 5 )
IsisB2:SetText( "Minimize" )
IsisB2.DoClick = function()
HtmlWin:SetVisible(false)
        end    
local IsisB3 = vgui.Create( "DButton")
IsisB3:SetSize( 80,30 )
IsisB3:SetPos( ScrW() - 85, 35 )
IsisB3:SetText( "Hack Main Page" )
IsisB3.DoClick = function()
HtmlWin:SetVisible(true)
        end    
       
       
end
 
 
BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/ESP" )
BSheet:AddSheet( "Misc", Tab3, "gui/silkicons/world", false, false, "Misc" )
BSheet:AddSheet( "Speedhack", Tab4, "gui/silkicons/wrench", false, false, "Gotta go fast" )
end
concommand.Add("+Com_Menu",ShowFrame)
concommand.Add("-Com_Menu",function()
Frame:SetVisible( false )
end)
 
concommand.Add("Com_Menu_Reload",function()
ShowFrame()
end)