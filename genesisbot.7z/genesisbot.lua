--[[
	aimbot.lua
	Jesse Jackson | (STEAM_0:1:43732934)
	===DStream===
]]

/************************************
            GENESIS BOT
            By Averice
************************************/

local GEN = {}
GEN.safeRoutes = {
    "!",
    "genesisbot",
    "genbot",
    "gmcl_dec0",
    "gm_cvar2",
    "dec0",
    "cvar2"
}
GEN.Commands = {}
GEN.Hooks = {}
GEN.CvarTable = {}
GEN.CvarLoad = false;
GEN.SpreadLoad = false;
GEN.Path = "addons\\genesisbot\\lua\\genbot.lua";
GEN.StringChars = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q" ,"r", "s", "t", "u", "v", "w", "x", "y", "z"}

include("includes/util.lua")
include( "includes/compat.lua" )
include( "includes/util.lua" )
include( "includes/util/sql.lua" )

require( "concommand" )
require( "saverestore" )
require( "gamemode" )
require( "weapons" )
require( "hook" )
require( "timer" )
require( "schedule" )
require( "scripted_ents" )
require( "player_manager" )
require( "numpad" )
require( "team" )
require( "undo" )
require( "cleanup" )
require( "duplicator" )
require( "constraint" )
require( "construct" )    
require( "filex" )
require( "vehicles" )
require( "usermessage" )
require( "list" )
require( "cvars" )
require( "http" )
require( "datastream" )
require( "draw" )
require( "markup" )
require( "effects" )
require( "killicon" )
require( "spawnmenu" )
require( "controlpanel" )
require( "presets" )
require( "cookie" )

include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )    
include( "includes/util/client.lua" )

GEN.Player = _R.Player;
GEN.Entity = _R.Entity;
GEN.ConVar = _R.ConVar;
GEN.CUserCmd = _R.CUserCmd;
GEN.Vector = _R.Vector;
GEN.Angle = _R.Angle;
GEN.require = require;
GEN.include = include;
GEN.debug = debug;
GEN.string = string;
GEN.file = file;
GEN.math = math;
GEN.concommand = concommand;
GEN.hook = hook;
GEN.cvars = cvars;
GEN.filex = filex;
GEN.table = table;
GEN.cam = cam;
GEN.draw = draw;
GEN.team = team;
GEN.RunString = RunString;
GEN.pcall = pcall;
GEN.CreateClientConVar = CreateClientConVar;
GEN.GetConVar = GetConVar;
GEN.RunConsoleCommand = RunConsoleCommand;
GEN.util = util;

local pairs = pairs;
local print = print;
local Msg = Msg;
local MsgN = MsgN;
local ValidEntity = ValidEntity;
local ents = ents;
local player = player;
local type = type;
local Color = Color;
local Angle = Angle;
local Vector = Vector;
local tostring = tostring;
local tonumber = tonumber;
local tobool = tobool;
local LocalPlayer = LocalPlayer;
local Color = Color;

/*************************************************************
                            SETUP
*************************************************************/

if( !cvar2 && !GEN.CvarLoad ) then
    if( #GEN.file.Find("lua/includes/modules/gm_cvar2.dll", true) >= 1 ) then
        GEN.CvarLoad = true;
        GEN.require("cvar2")
        GEN.cvar2 = cvar2
        cvar2 = nil
        MsgN("[GenesisBot] - Cvar2 module loaded.")
    end
end

if( !GEN.SpreadLoad ) then
    if( #GEN.file.Find("lua/includes/modules/gmcl_dec0.dll", true) >= 1 ) then
        GEN.SpreadLoad = true;
        GEN.require("dec0")
        GEN.shotmanip = hl2_shotmanip
        GEN.getprediction = hl2_ucmd_getprediciton
        hl2_shotmanip = nil
        hl2_ucmd_getprediciton = nil
        MsgN("[GenesisBot] - Deco module loaded.")
    end
end    

function GEN:CheckPath(path)
    return ( self.string.lower(path) == self.Path )
end

function require(s)
    if( s ) then
        local CheckPath = GEN.debug.getinfo(2)['short_src'];
        if not( GEN:CheckPath(CheckPath) ) then
            for k,v in pairs(GEN.safeRoutes) do
                if( GEN.string.find(GEN.string.lower(s), GEN.string.lower(v)) ) then
                    return
                end
            end
        end
        return GEN.require(s)
    end
end

function include(s)
    if( s ) then
        local CheckPath = GEN.debug.getinfo(2)['short_src'];
        if not( GEN:CheckPath(CheckPath) ) then
            for k,v in pairs(GEN.safeRoutes) do
                if( GEN.string.find(GEN.string.lower(s), GEN.string.lower(v)) ) then
                    return
                end
            end
        end
        return GEN.include(s)
    end
end

function GEN:RandomString()
    local String = "";
    local Count = self.math.random(1, 15)
    for i = 1, Count do
        String = String .. self.StringChars[self.math.random(1, #self.StringChars)];
    end
    return String
end
    
function GEN:Hook(n, f)
    if( n && f ) then
        local RandomString = self:RandomString()
        self.hook.Add(tostring(n), RandomString, function(...)
            local isOk, RetVal = self.pcall(f, ...)
            if not( isOk ) then
                return MsgN("[GenesisBot] - "..tostring(RetVal))
            elseif( isOk && RetVal != nil ) then
                return RetVal
            end
        end)
        if( self.Hooks[n] != nil ) then
            self.table.insert(self.Hooks[n], RandomString)
        else
            self.Hooks[n] = { RandomString };
        end        
    end
end

function GEN:Command(n, f)
    if( n && f ) then
        self.concommand.Add(tostring(n), function(...)
            local isOk, RetVal = self.pcall(f, ...)
            if not( isOk ) then
                return MsgN("[GenesisBot] - "..tostring(RetVal))
            elseif( isOk && RetVal != nil ) then
                return RetVal
            end
        end)
        self.Commands = self.Commands or {}
        table.insert(self.Commands, tostring(n))
    end
end

function GEN:CreateCon(n, d, f, fa)
    self.Commands = self.Commands or {}
    table.insert(self.Commands, tostring(n))
    return self.CreateClientConVar(n, d, f, fa)
end

local VarToGet
function GEN:GetConVarSet(c, s)
    if( c ) then
        if( self.CvarTable[c] ) then
             VarToGet = self.CvarTable[c]
        end
        if( s ) then
            if( tostring(s) == "str" ) then
                return self.ConVar.GetString(VarToGet)
            elseif( tostring(s) == "num" ) then
                return self.ConVar.GetInt(VarToGet)
            else
                return self.ConVar.GetBool(VarToGet)
            end
        end
    end
end

GEN.Cheats = GEN.GetConVar("sv_cheats");
GEN.ScriptEnforcer = GEN.GetConVar("sv_scriptenforcer");

/*************************************************************
                           COMMANDS
*************************************************************/

GEN.CvarTable.AimBot = GEN:CreateCon("gen_aim", 0, false, false);
GEN.CvarTable.AimBone = GEN:CreateCon("gen_bone", "head", false, false);
GEN.CvarTable.AimNPC = GEN:CreateCon("gen_npc", 1, false, false);
GEN.CvarTable.TeamPlay = GEN:CreateCon("gen_teamplay", 0, false, false);
GEN.CvarTable.AutoShoot = GEN:CreateCon("gen_autoshoot", 0, false, false);
GEN.CvarTable.BunnyHop = GEN:CreateCon("gen_bunnyhop", 0, false, false);
GEN.CvarTable.Esp = GEN:CreateCon("gen_esp", 1, false, false);
GEN.CvarTable.Walls = GEN:CreateCon("gen_walls", 1, false, false);
GEN.CvarTable.Speed = GEN:CreateCon("gen_speed", 2, false, false);
GEN.CvarTable.DarkRP = GEN:CreateCon("gen_darkrp", 0, false, false);

GEN:Command("+gen_bhop", function()
    GEN.RunConsoleCommand("gen_bunnyhop", 1)
end)
GEN:Command("-gen_bhop", function()
    GEN.RunConsoleCommand("gen_bunnyhop", 0)
end)
GEN:Command("+gen_aim", function()
    GEN.RunConsoleCommand("gen_aim", 1)
end)
GEN:Command("-gen_aim", function()
    GEN.RunConsoleCommand("gen_aim", 0)
end)
GEN:Command("+gen_speed", function()
    if( GEN:GetConVarSet(GEN.Cheats, "num") == 1 ) then
        GEN.RunConsoleCommand("host_timescale", GEN:GetConVarSet("Speed", "num"))
    end
end)
GEN:Command("-gen_speed", function()
    if( GEN:GetConVarSet(GEN.Cheats, "num") == 1 ) then
        GEN.RunConsoleCommand("host_timescale", 1)
    end
end)
GEN:Command("gen_lua", function(p,c,a)
    if( GEN:GetConVarSet(GEN.ScriptEnforcer, "num") == 0 ) then
        if( a[1] ) then
            local lua = GEN.table.concat(a, " ");
            local isOk, RetVal = GEN.pcall(GEN.RunString, tostring(lua))
            if not( isOk ) then
                return MsgN("[GenesisBot] - "..tostring(RetVal))
            elseif( isOk && RetVal != nil ) then
                return RetVal
            end
        end
    end
end)
GEN:Command("gen_run", function(p,c,a)
    if( a[1] ) then
        local com = a[1]
        if( GEN.CvarLoad ) then
            GEN.cvar2.SetFlags(tostring(com), FCVAR_CLIENTCMD_CAN_EXECUTE)
            return MsgN("[GenesisBot] - Set command "..tostring(com))
        else
            return MsgN("[GenesisBot] - Cvar2 module not loaded.")
        end
    end
end)

/*************************************************************
                           AIMBOT
*************************************************************/
GEN.Bones = {}
GEN.Bones.Models = {
    ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
    ["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4",
    ["models/combine_scanner.mdl"] = "Scanner.Body",
    ["models/hunter.mdl"] = "MiniStrider.body_joint",
    ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
    ["models/dog.mdl"] = "Dog_Model.Eye",
    ["models/vortigaunt.mdl"] = "ValveBiped.Head",
    ["models/antlion.mdl"] = "Antlion.Body_Bone",
    ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
    ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
    ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
    ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
    ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
    ["models/headcrabblack.mdl"] = "HCBlack.body",
    ["models/headcrab.mdl"] = "HCFast.body",
    ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
    ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
    ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
    ["models/combine_dropship.mdl"] = "D_ship.Spine1",
    ["models/combine_helicopter.mdl"] = "Chopper.Body",
    ["models/gunship.mdl"] = "Gunship.Body",
    ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
    ["models/mortarsynth.mdl"] = "Root Bone",
    ["models/synth.mdl"] = "Bip02 Spine1",
    ["models/vortigaunt_slave.mdl"] = "ValveBiped.Head"
}
GEN.Bones.Bones = {
    ["head"] = "ValveBiped.Bip01_Head1",
    ["spine"] = "ValveBiped.Bip01_Spine",
    ["shoulder"] = "ValveBiped.Bip01_R_Shoulder"
}
GEN.Bones.Attach = {
    ["head"] = "eyes",
    ["spine"] = "chest"
}

local Position, Angles, Bone, Got, PlayerModel
function GEN:GetBestAim(targ, bone)
    if( targ && bone) then
        if( self.Bones.Attach[bone] ) then
            Bone = self.Entity.LookupAttachment(targ, self.Bones.Attach[bone])
            if( Bone ) then
                Got = self.Entity.GetAttachment(targ, Bone)
                if( Got && Got.Pos ) then
                    return Got.Pos, Got.Ang
                end
            end
        end
        
        PlayerModel = self.Entity.GetModel(targ);
        if( self.Bones.Models[PlayerModel] ) then
            Bone = self.Entity.LookupBone(targ, self.Bones.Models[PlayerModel])
            if( Bone ) then
                Position, Angles = self.Entity.GetBonePosition(targ, Bone)
                return Position, Angles
            end
        end
        
        if( self.Bones.Bones[bone] ) then
            Bone = self.Entity.LookupBone(targ, self.Bones.Generic[bone])
            if( Bone ) then
                Position, Angles = self.Entity.GetBonePosition(targ, Bone)
                return Position, Angles
            end
        else
            Bone = self.Entity.LookupBone(targ, self.Bones.Bones["head"])
            if( Bone ) then
                Position, Angles = self.Entity.GetBonePosition(targ, Bone)
                return Position, Angles
            end
        end
    end
end
    
local Myself
function GEN:IsAcceptable(tar)
    Myself = LocalPlayer();
    if( ValidEntity(tar) && self.Player.Alive(Myself) ) then
        if( self:GetConVarSet("AimNPC", "num") == 1 && type(tar) == "NPC" && self.Entity.GetMoveType(tar) != MOVETYPE_NONE ) then
            return true
        end
        if( type(tar) == "Player" && self.Player.Alive(tar) && self.Entity.GetMoveType(tar) != MOVETYPE_NONE && self.Entity.GetMoveType(tar) != MOVETYPE_OBSERVER && tar != Myself ) then
            return true
        end
    end
    return false
end

local EndPos, Trace, Line
function GEN:TraceEntity(tar)
    if( self:IsAcceptable(tar) ) then
        Myself = Myself or LocalPlayer()
        Trace = {}
        Trace.start = self.Entity.EyePos(Myself)
        if( self.Entity.EyePos(tar) ) then
            EndPos = self.Entity.EyePos(tar)
        else
            EndPos = self.Entity.OBBCenter(tar)
        end
        Trace.endpos = EndPos
        Trace.filter = {Myself, tar}
        Trace.mask = 1174421507;
        
        Line = self.util.TraceLine(Trace)
        if not( Line.Hit ) then
            return true
        end
    end
    return false
end

local Target
function GEN:GetTarget()
    if( Target && self:TraceEntity(Target) ) then
        return Target
    else
        Target = nil
    end
    for k,v in pairs(ents.GetAll()) do
        if( self:TraceEntity(v) ) then
            if( Target && self.Vector.Distance(self.Entity.GetPos(Target), self.Entity.GetPos(LocalPlayer())) < self.Vector.Distance(self.Entity.GetPos(v),self.Entity.GetPos(LocalPlayer())) ) then
                return Target
            else
                Target = v
            end
        end
    end
    return Target
end

GEN.Weapons = {
    ["weapon_crossbow"] = 3110; -- Thanks for the number FlapJack <3;
}

local Wep, Vel, Distance, Time
function GEN:GetPrediction(target, position)
    Myself = Myself or LocalPlayer()
    Vel = self.Entity.GetVelocity(target);
    Distance = self.Vector.Distance(self.Entity.GetPos(target),self.Entity.GetPos(Myself))
    if( self.Player.GetActiveWeapon(Myself) && ValidEntity(self.Player.GetActiveWeapon(Myself)) ) then
        Wep = self.Entity.GetClass(self.Player.GetActiveWeapon(Myself));
    end
    if( Wep && self.Weapons[Wep] ) then
        Time = Distance/self.Weapons[Wep];
        position = position + Vel * Time;
        return position
    end
    return position
end

function GEN:GetCone(wep)
        local cone = wep.Cone
        if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
            cone = wep.Primary.Cone
        end
        if not cone then cone = 0 end
        if type(wep.Base) == "string" and wep.Base == "weapon_cs_base" then return cone end
        if self.Entity.GetClass(wep) == "ose_turretcontroller" then return 0 end
        return cone or 0
end

local CurSeed, Com2, Seed = CurSeed or 0, 0, 0
local Wep, VecCone, ValCone
function GEN:PredictSpread(Cmd, AimAng)
    Com2, Seed = self.getprediction(Cmd)
    if Com2 ~= 0 then
         CurSeed = Seed
    end
    Wep = self.Player.GetActiveWeapon(LocalPlayer())
    VecCone = Vector(0, 0, 0)
    if Wep and self.Entity.IsValid(Wep) and type(Wep.Initialize) == "function" then
         ValCone = self:GetCone(Wep)
         if type(ValCone) == "number" then
               VecCone = Vector(-ValCone,-ValCone,-ValCone)
         elseif type(ValCone) == "Vector" then
               VecCone = -1*ValCone
        end
    end
    return self.Vector.Angle(self.shotmanip(CurSeed or 0, self.Angle.Forward(AimAng or self.Vector.Angle(self.Player.GetAimVector(LocalPlayer()))), VecCone))
end

local AimTarget, Pos, Ang, Aim
function GEN.AimBot(uc)
    AimTarget = GEN:GetTarget()
    Myself = Myself or LocalPlayer()
    if( GEN.Entity.IsPlayer(AimTarget) && GEN.Player.Team(AimTarget) == GEN.Player.Team(Myself) && GEN:GetConVarSet("TeamPlay", "num") == 1 ) then
        Target = nil
        return
    end
    if( AimTarget ) then
        Pos, Ang = GEN:GetBestAim(AimTarget, GEN:GetConVarSet("AimBone", "str"))
        Pos = GEN:GetPrediction(AimTarget, Pos)
        Pos = Pos + (GEN.Entity.GetVelocity(AimTarget)/45 - GEN.Entity.GetVelocity(Myself)/45);
        if( GEN:GetConVarSet("AimBot", "num") == 1 && GEN:TraceEntity(AimTarget) ) then
            Aim = GEN.Vector.Angle(Pos - GEN.Player.GetShootPos(Myself))
            
            if( GEN.SpreadLoad ) then
                Aim = GEN:PredictSpread(uc, Aim)
            end
            Aim.p = GEN.math.NormalizeAngle(Aim.p);
            Aim.y = GEN.math.NormalizeAngle(Aim.y);
            Aim.r = 0
            
            GEN.CUserCmd.SetViewAngles(uc, Aim)
        else
            AimTarget = nil
        end
    end
end

GEN:Hook("CreateMove", function(uc)
    GEN.AimBot(uc)
end)

/***********************************
        TERRORIST TOWN!
***********************************/
GEN.TraitorWeapons = {
      ["weapon_ttt_c4"] = 100;
      ["weapon_ttt_flaregun"] = 100;
      ["weapon_ttt_knife"] = 80;
      ["weapon_ttt_phammer"] = 100;
      ["weapon_ttt_push"] = 100;
      ["weapon_ttt_radio"] = 100;
      ["weapon_ttt_sipistol"] = 100;
     }
     
function GEN:TraitorPercentage(tar)
    if( ValidEntity(tar) && self.Entity.IsPlayer(tar) ) then
        for k,v in pairs(self.Player.GetWeapons(tar)) do
            if( self.TraitorWeapons[self.Entity.GetClass(v)] ) then
                return Color(150+self.TraitorWeapons[self.Entity.GetClass(v)], 100-self.TraitorWeapons[self.Entity.GetClass(v)], 0, 255), self.TraitorWeapons[self.Entity.GetClass(v)]
            end
        end
    end
    return Color(80, 255, 0, 255), 33
end

function GEN:TerrorTown()
    return self.string.find(self.string.lower(GAMEMODE.Folder), "terrortown")
end

/***********************************
            ESP!!!
***********************************/
local trace, ppos
function GEN:EntityVisible(ent)
    if( ValidEntity(ent) ) then
        trace = {}
        if( self.Entity.EyePos(ent) ) then
            ppos = self.Entity.EyePos(ent)
        else
            ppos = self.Entity.GetPos(ent)
        end
        trace.start = self.Entity.EyePos(LocalPlayer());
        trace.endpos = ppos;
        trace.filter = {LocalPlayer(), ent}
        trace.mask = MASK_SHOT;
        
        local tr = self.util.TraceLine(trace)
        if not( tr.Hit ) then
            return true
        end
    end
    return false
end

GEN.DarkRP = {
    ["gunlab"] = "Gun Lab",
    ["money_printer"] = "Money Printer",
    ["drug_lab"] = "Drug Lab"
}

local VisibleTargets
function GEN:GetAllVisibleTypes()
    VisibleTargets = {}
    for k,v in pairs(ents.GetAll()) do
        if( (self:IsAcceptable(v) or self.Entity.IsWeapon(v)) && !self:EntityVisible(v) ) then
            self.table.insert(VisibleTargets, v)
        end
    end
    return VisibleTargets
end

local TargetColor
function GEN:Colorize(tar)
    if( ValidEntity(tar) ) then
        if( self.Entity.IsPlayer(tar) ) then
            TargetColor = self.team.GetColor(self.Player.Team(tar))
        else
            TargetColor = Color(255,255,255,255)
        end
    end
    return TargetColor
end

local Admins = {}
function GEN:GetAdmins()
    Admins = {}
    Admins.Supers = {}
    Admins.Admins = {}
    for k,v in pairs(player.GetAll()) do
        if( self.Player.IsSuperAdmin(v) ) then
            self.table.insert(Admins.Supers, v)
        elseif( self.Player.IsAdmin(v) && !self.Player.IsSuperAdmin(v) ) then
            self.table.insert(Admins.Admins, v)
        end
    end
    return Admins
end

local Table, AdminTable
local tCol, tPerc
-- Probably shouldn't have all of this in RSE but, you're cheating with this so shut the fuck up.
GEN:Hook("RenderScreenspaceEffects", function()
    if( GEN:GetConVarSet("Walls", "num") == 1 ) then
        Table = GEN:GetAllVisibleTypes()
        GEN.cam.Start3D(EyePos(), EyeAngles())
            for k,v in pairs(Table) do
                GEN.cam.IgnoreZ(true)
                    if( type(v) == "Player" ) then
                        GEN.Entity.SetMaterial(v, "models/wireframe")
                    end
                    GEN.Entity.DrawModel(v)
                GEN.cam.IgnoreZ(false)
            end
        GEN.cam.End3D()
    end
    for k,v in pairs(player.GetAll()) do
        if not( GEN.table.HasValue(Table, v) ) then
            GEN.Entity.SetMaterial(v, "")
        end
    end
end)

function GEN:GetSexyHealth(p)
    local Health = self.math.Clamp(self.Entity.Health(p), 0, 100);
    local R = 255-(Health*2)
    local G = 55+(Health*2)
    local B = 0
    return R,G,B
end

GEN:Hook("RenderScreenspaceEffects", function()
    if( GEN:GetConVarSet("Esp", "num") == 1 ) then
        AdminTable = GEN:GetAdmins()
        local Pos, Ang
        for k,v in pairs(player.GetAll()) do
            Pos, Ang = GEN:GetBestAim(v, GEN:GetConVarSet("AimBone", "str"))
            if( Pos && GEN:IsAcceptable(v) ) then
                Pos = GEN.Vector.ToScreen(Pos)
                GEN.draw.SimpleTextOutlined(GEN.Player.Nick(v), "default", Pos.x, Pos.y, Color(255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                Pos.y = Pos.y + 15
                local R,G,B = GEN:GetSexyHealth(v);
                GEN.draw.SimpleTextOutlined("Health: "..GEN.Entity.Health(v), "default", Pos.x, Pos.y, Color(R,G,B,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                if( GEN.table.HasValue(AdminTable.Supers, v) ) then
                    Pos.y = Pos.y + 15
                    draw.SimpleTextOutlined("SuperAdmin", "default", Pos.x, Pos.y, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                elseif( GEN.table.HasValue(AdminTable.Admins, v) ) then
                    Pos.y = Pos.y + 15
                    GEN.draw.SimpleTextOutlined("Admin", "default", Pos.x, Pos.y, Color(255,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                end
                if( GEN:TerrorTown() ) then
                    tCol, tPerc = GEN:TraitorPercentage(v)
                    Pos.y = Pos.y + 15
                    GEN.draw.SimpleTextOutlined("Traitor Percent: "..tPerc, "default", Pos.x, Pos.y, tCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                end
            end
        end
        if( GEN:GetConVarSet("DarkRP", "num") == 1 ) then
            for k,v in pairs(ents.GetAll()) do
                if( ValidEntity(v) ) then
                    if( GEN.DarkRP[GEN.Entity.GetClass(v)] ) then
                        GEN.draw.SimpleTextOutlined(GEN.DarkRP[GEN.Entity.GetClass(v)], "default", GEN.Vector.ToScreen(GEN.Entity.GetPos(v)).x, GEN.Vector.ToScreen(GEN.Entity.GetPos(v)).y, Color(0, 180, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))
                    end
                end
            end
        end
    end
end)
