--[[
	MOD/lua/Swag.lua
	[DS]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [16-10-13 12:00:38AM]
	===BadFile===
]]

//

/* 

	Project Helium
	
	Created to compete with Fisheater in his creation of Krypton
	
	Author: Canadian Phuck
	
*/

local Helium = {

	config					= {
		
		[ "Max Detection Distance" ]		= 3200,
		
		/* Esp */	
		[ "Player Esp" ]					= true,
		[ "Player Info"	]					= true,
		[ "Player Boxes" ]					= true,
		[ "Player Lines" ]					= true,
		[ "Player FindTraitors" ] 			= true,
	
		[ "Entity Esp" ]					= true,
		
		/* Aimbot */
		[ "Aimbot IgnoreFriends" ]			= true,
		[ "Aimbot IgnoreTeam" ]				= true,
		[ "Aimbot IgnoreAdmins" ]			= true,
		[ "Aimbot TargetPos" ] 				= "Eyes",
		[ "Aimbot Nospread" ] 				= true,
		
		
		/* Misc */
		[ "Misc Bhop" ]								= true,
		[ "Misc Triggerbot" ]						= true,
		[ "Misc TriggerBot Use Secondary Attack" ]	= true,
		[ "Misc Crosshair" ]						= true,
		[ "Misc Norecoil" ] 						= true,
		[ "Misc Speedfactor" ] 						= .04,

								},
	
	hooks					= {},
	cmds 					= {},
	timers					= {},
	customDrawEnts 			= {},
	aimbotBuddies 			= {},
	detectedTraitors 		= {},
	detectedTraitorWeapons  = {},
	
	espPlayers 				= {},
	espEntities 			= {},
	aimbotPlayers 			= {},
	
	aim 					= false,
}

/* Anti-Anti Cheat */

local hook 				= hook
local table 			= table
local math 				= math
local surface 			= surface
local draw 				= draw
local file 				= file
local util 				= util
local chat 				= chat
local concommand 		= concommand
local hook 				= hook
local input 			= input
local ents 				= ents

local tostring 			= tostring
local require			= require
local RunConsoleCommand = RunConsoleCommand

require( "helium" )

local spoofedCvars = {}
spoofedCvars[ "sv_cheats" ] = 0
spoofedCvars[ "host_framerate" ] = 0
spoofedCvars[ "sv_allowcslua" ] = 0

Helium.GetConVarNumber = GetConVarNumber

function _G.GetConVarNumber( convar )

	convar = string.lower( convar )

	if ( spoofedCvars[ convar ] != nil ) then
	
		return spoofedCvars[ convar ]
	end
	
	return Helium.GetConVarNumber( convar )
end

Helium.GetConVarString = GetConVarString

function _G.GetConVarString( convar )
	
	convar = string.lower( convar )

	if ( spoofedCvars[ convar ] != nil ) then
	
		return tostring( spoofedCvars[ convar ] )
	end
	
	return Helium.GetConVarString( convar )
end


Helium.GetHookTable = hook.GetTable

function _G.hook.GetTable()

	local hookTable = Helium.GetHookTable()
	
	for k,v in pairs( hookTable ) do
	
		for a,b in pairs( Helium.hooks ) do
		
			if ( v[ a ] != nil ) then
			
				v[ a ] = nil
			end
		end
	end
	
	return hookTable
end

Helium.GetCmdTable = concommand.GetTable

function _G.concommand.GetTable()

	local cmdTable = Helium.GetCmdTable()
	
	for k,v in pairs( cmdTable ) do

		if ( Helium.cmds[ k ] ) then
		
			cmdTable[ k ] = nil
		end
	end
	
	return cmdTable
end

/* Write / Read Config file */

if ( !file.Exists( "helium-config.txt","DATA" ) ) then

	local data = { 
	
		config 			= Helium.config,
		customDrawEnts 	= Helium.customDrawEnts,
		aimbotBuddies	= Helium.aimbotBuddies,
	}
	
	file.Write( "helium-config.txt",util.TableToJSON( data ) )
	
else

	local data = util.JSONToTable( file.Read( "helium-config.txt","DATA" ) )

	Helium.config			= data.config
	Helium.customDrawEnts 	= data.customDrawEnts
	Helium.aimbotBuddies 	= data.aimbotBuddies
end

/* Utility Functions */

function Helium:Msg( String )

	chat.AddText( Color( 200,40,40,255 ),"[Helium] ",Color( 255,255,255,255 ),String )
end

function Helium:GenerateString( Length )
	
	local genString = ""
	
	for i = 1,Length do

		genString = genString .. string.char( math.random( 65,91 ) )
	end
	
	return genString
end

function Helium:AddHook( Type,Function )

	local hookName = self:GenerateString( 256 )
	
	self.hooks[ hookName ] = Type
	
	hook.Add( Type,hookName,Function )
end

function Helium:AddTimer( Delay,Reps,Function )

	local timerName = self:GenerateString( 64 )

	self.timers[ timerName ] = true
	
	timer.Create( timerName,Delay,Reps,Function )
end

function Helium:AddCmd( Name,Function )

	Name = string.lower( Name )

	self.cmds[ Name ] = true

	concommand.Add( Name,Function )
end

function Helium:Kill()

	for k,v in pairs( self.hooks ) do
	
		hook.Remove( v,k )
	end
	
	for k,v in pairs( self.timers ) do

		timer.Destroy( k )
	end
	
	for k,v in pairs( self.cmds ) do
	
		concommand.Remove( k )
	end
	
	hook.GetTable = self.GetHookTable
	concommand.GetTable = self.GetCmdTable
	GetConVarNumber = self.GetConVarNumber
	GetConVarString = self.GetConVarString
	
	self:Msg( "Hooks,Timers and Cmds removed, Hack shutdown" )
end

/* Entity Filtration */

function Helium.FilterEntities()

	Helium.espPlayers = {}
	Helium.espEntites = {}
	Helium.aimbotPlayers = {}
	
	for k,v in ipairs( ents.GetAll() ) do
	
		if ( v:GetPos():Distance( LocalPlayer():GetPos() ) > Helium.config[ "Max Detection Distance" ]  ) then continue end
		
		if ( v:IsPlayer() ) then
			
			if ( v == LocalPlayer() ) then continue end
			if ( !v:Alive() ) then continue end
			if( v:Team() == TEAM_SPECTATOR ) then continue end
			
			table.insert( Helium.espPlayers,v )
			
			if ( Helium.config[ "Aimbot IgnoreFriends" ] && v:GetFriendStatus() == "friend" ) then continue end
			if ( Helium.config[ "Aimbot IgnoreTeam" ] && v:Team() == LocalPlayer():Team() ) then continue end
			if ( Helium.config[ "Aimbot IgnoreAdmins" ] && v:IsAdmin() ) then continue end
			if ( Helium.aimbotBuddies[ v:SteamID() ] ) then continue end
			
			table.insert( Helium.aimbotPlayers,v )
			
		elseif ( Helium.customDrawEnts[ v:GetClass() ] != nil ) then
		
			table.insert( Helium.espEntities,v )
		end
	end
end	

/* Rendering */

function Helium:PlayerEsp( ent )

	if ( !self.config[ "Player Esp" ] ) then return end
	
	local min,max = ent:OBBMins(),ent:OBBMaxs()
	
	local bottom = ent:GetPos() - Vector( 0,0,2.5 )
	local top = Vector( bottom.x,bottom.y,bottom.z + max.z )
	
	bottom = bottom:ToScreen()
	top = top:ToScreen()
	
	if ( !bottom.visible ) then return end
	
	local height = math.abs( top.y - bottom.y ) + 2.5
	local width = height / 2
	
	local teamColor = team.GetColor( ent:Team() )
	teamColor.a = 255
	
	if ( self.detectedTraitors[ ent ] ) then
	
		teamColor = Color( 220,20,20,255 )
	end
	
	surface.SetDrawColor( teamColor )
	
	if ( self.config[ "Player Boxes" ] ) then
	
		surface.DrawOutlinedRect( bottom.x - width / 2,top.y - 2.5,width,height )
	end
	
	if ( self.config[ "Player Info" ]) then
		
		draw.SimpleText( ent:Nick(),"BudgetLabel",bottom.x,top.y - 20,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		draw.SimpleText( "HP: " .. ent:Health(),"BudgetLabel",bottom.x,top.y - 30,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		
		if ( ent:IsAdmin() ) then
		
			draw.SimpleText( "Admin","BudgetLabel",bottom.x,top.y - 40,teamColor,TEXT_ALIGN_CENTER,TEXT_ALIGN_LEFT )
		end
	end
	
	if ( self.config[ "Player Lines" ] ) then
	
		local myPos = ( LocalPlayer():EyePos() + LocalPlayer():EyeAngles():Forward() * 50 - Vector( 0,0,20 ) ):ToScreen()

		surface.DrawLine( myPos.x,myPos.y,bottom.x,bottom.y )
	end
end

function Helium:EntityEsp( ent )

	if ( !self.config[ "Entity Esp" ] ) then return end
	
	local center = ent:LocalToWorld( ent:OBBCenter() ):ToScreen()
	
	if ( !center.visible ) then return end

	draw.SimpleText( ent:GetClass(),"BudgetLabel",center.x,center.y,Color( 40,200,40,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
end

Helium.scrnCenter = Vector( ScrW() / 2,ScrH() / 2 )

function Helium.HudPaint()

	for k,v in ipairs( Helium.espPlayers ) do

		if ( !v:IsValid() ) then continue end	 
		
		Helium:PlayerEsp( v )
	end
	
	for k,v in ipairs( Helium.espEntities ) do
		
		if ( !v:IsValid() ) then continue end
		
		Helium:EntityEsp( v )
	end
	
	
	// Crosshair
	
	if ( Helium.config[ "Misc Crosshair" ] ) then
	
		surface.SetDrawColor( Color( 230,40,40,255 ) )
		
		surface.DrawRect( Helium.scrnCenter.x - 5,Helium.scrnCenter.y - 1,10,2 )
		surface.DrawRect( Helium.scrnCenter.x - 1,Helium.scrnCenter.y - 5,2,10 )
	
	end
end

/* Aimbot */

function Helium:GetAimSpot( target )
 
	local aimSpot;

	if ( self.config[ "Aimbot TargetPos" ] == "Eyes" ) then
		
		local eye = target:GetAttachment( target:LookupAttachment( "eyes" ) )
		
		if ( eye ) then 
		
			if ( eye.Pos ) then
		
				aimSpot = eye.Pos
			end
		
		end
	elseif( self.config[ "Aimbot TargetPos" ] == "Head" ) then
	
		local bone = target:GetBonePosition( target:LookupAttachment( "ValveBiped.Bip01_Head1" ) )
		
		if ( bone ) then
	
			aimSpot = target:GetBonePosition( target:LookupAttachment( "ValveBiped.Bip01_Head1" ) )
		
		end
	else
	
		aimSpot = target:LocalToWorld( target:OBBCenter() )
	end	
	
	if ( aimSpot == nil ) then
	
		aimSpot = target:LocalToWorld( target:OBBCenter() )
	end

	return aimSpot
end

function Helium:TraceHit( target )

	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = self:GetAimSpot( target )
	tr.mask = MASK_SHOT
	tr.filter = { LocalPlayer(),target }
	
	return util.TraceLine( tr ).Hit
end

function Helium:GetBestTarget()
	
	local target = { nil,0 }
	
	for k,v in ipairs( self.aimbotPlayers ) do
	
		if ( !v:IsValid() ) then continue end
		if ( Helium:TraceHit( v ) ) then continue end
	
		local scrnPos = v:EyePos():ToScreen()
		
		local distance = math.Distance( self.scrnCenter.x,self.scrnCenter.y,scrnPos.x,scrnPos.y )
		
		if ( target[ 1 ] == nil || distance < target[ 2 ] ) then
		
			target = { v,distance }
		end
	end
	
	return target[ 1 ]
end


function Helium:WepVector( number )

	number = -number
	
	return Vector( number,number,number )
end

Helium.hlWeps = {}
Helium.hlWeps["weapon_pistol"] = Helium:WepVector( 0.0100 )
Helium.hlWeps["weapon_smg1"] = Helium:WepVector( 0.04362 )
Helium.hlWeps["weapon_ar2"] = Helium:WepVector( 0.02618 )
Helium.hlWeps["weapon_shotgun"] = Helium:WepVector( 0.08716 )

function Helium:GetCone()

	local wep = LocalPlayer():GetActiveWeapon()
	
	if ( !wep:IsValid() ) then return Vector( 0,0,0 ) end
	
	if ( self.hlWeps[ wep:GetClass() ] ) then
	
		return self.hlWeps[ wep:GetClass() ]
	end
	
	if ( !wep.Primary ) then return Vector( 0,0,0 ) end
	if ( !wep.Primary.Cone ) then return Vector( 0,0,0 ) end
	
	if ( type( wep.Primary.Cone ) != "Vector" ) then
		
		return self:WepVector( wep.Primary.Cone )
	end
	
	return wep.Primary.Cone * -1
end

function Helium:PredictSpread( ucmd,angle )

	if ( !self.config[ "Aimbot Nospread" ] ) then
	
		return angle
	end
	
	return cow_manipShot( cow_md5PseudoRand( cow_getUCMDNum( ucmd ) ), angle:Forward(), self:GetCone() ):Angle()
end

function Helium.Ucmd( ucmd )

	if ( !Helium.aim ) then return end

	local target = Helium:GetBestTarget()
	
	if ( target == nil ) then return end
	
	local targetPos = Helium:GetAimSpot( target )
	
	targetPos = targetPos + ( target:GetVelocity() / 45 ) - ( LocalPlayer():GetVelocity() / 45 )
	
	local angle = ( targetPos - LocalPlayer():GetShootPos() ):Angle()
	
	angle = Helium:PredictSpread( ucmd,angle )
	
	angle.y = math.NormalizeAngle( angle.y )
	angle.p = math.NormalizeAngle( angle.p )

	
	ucmd:SetViewAngles( angle )
end

/* Misc */

function Helium:Bhop()
	
	if ( self.config[ "Misc Bhop" ] ) then
		
		if ( input.IsKeyDown( KEY_SPACE ) && LocalPlayer():IsOnGround() ) then

			RunConsoleCommand( "+jump" )
			
			timer.Simple( .05,function()
			
				RunConsoleCommand( "-jump" )
			end )
		
		end
	end
end

function Helium:SecondaryFire( cmd )

	if ( self.config[ "Misc TriggerBot Use Secondary Attack" ] ) then
					
		RunConsoleCommand( cmd )
	end
end

Helium.hasFired = false

function Helium:TriggerBot()

	if ( self.config[ "Misc Triggerbot" ] ) then

		local ent = LocalPlayer():GetEyeTrace().Entity
		
		if ( table.HasValue( self.aimbotPlayers,ent ) ) then
			
			if ( !self.hasFired ) then
			
				RunConsoleCommand( "+attack" )
				self:SecondaryFire(  "+attack2" )
				self.hasFired = true
	
			else
			
				RunConsoleCommand( "-attack" )
				self:SecondaryFire( "-attack2" )
				self.hasFired = false
			end
			
		elseif( self.hasFired ) then
	
			RunConsoleCommand( "-attack" )
			self:SecondaryFire( "-attack2" )
			self.hasFired = false
		
		end
	end
end

function Helium:NoRecoil()

	if ( self.config[ "Misc Norecoil" ] ) then
	
		local wep = LocalPlayer():GetActiveWeapon()
		
		if ( !wep:IsValid() ) then return end
		if ( wep.Primary == nil ) then return end
		
		if ( wep.Primary.Recoil != 0 ) then
			
			wep.Primary.Recoil = 0
		end
	end
end

function Helium.Think()

	Helium:Bhop()
	Helium:TriggerBot()
	Helium:NoRecoil()
end


/* TTT */

Helium.traitorWeapons = {

	"weapon_ttt_c4",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
}

function Helium:ScanForTraitors()

	if ( !self.config[ "Player FindTraitors" ] ) then return end
	if ( !GAMEMODE || !GAMEMODE.Name || !string.find( GAMEMODE.Name , "Trouble in Terror" ) ) then return end
	
	if ( GetRoundState() == 2 ) then
		
		self.detectedTraitors = {}
		self.detectedTraitorWeapons = {}
		
		return
	end

	for k,v in ipairs( self.espPlayers ) do
		
		if ( self.detectedTraitors[ v ] ) then continue end
		if ( v:IsDetective() ) then continue end
		
		if ( v:IsActiveTraitor() && !self.detectedTraitors[ v ] ) then
		
			self.detectedTraitors[ v ] = true
			
			continue
		end
		
		for a,b in ipairs( ents.FindByClass( "weapon_ttt_*" ) ) do
		
			if ( !b:IsValid() ) then continue end
			if ( !table.HasValue( self.traitorWeapons,b:GetClass() ) ) then continue end
			if ( self.detectedTraitorWeapons[ b ] ) then continue end
			
			if ( v:GetPos():Distance( b:GetPos() ) <= 37 ) then
				
				self.detectedTraitors[ v ] = true
				self.detectedTraitorWeapons[ b ] = true
					
				Helium:Msg( v:Nick() .. " Has a traitor weapon: " .. b:GetClass() )
			end
		end
	end
end

/* Gui */

function Helium:DLabel( parent,text )

	local label = vgui.Create( "DLabel" )
	
	if ( parent != nil ) then
	
		label:SetParent( parent )
	end
	
	label:SetText( "Helium" )
	label:SetSize( 100,30 )
	label.Paint = function()
		
		surface.SetDrawColor( Color( 220,220,220,255 ) )
		surface.DrawRect( 0,0,label:GetWide(),label:GetTall() )
		
		draw.SimpleText( text,"Trebuchet24",label:GetWide() / 2,label:GetTall() / 2,Color( 0,0,0,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
	end
	
	return label
end

function Helium.Gui()

	local frame = vgui.Create( "DFrame" )
	frame:SetSize( 300,300 )
	frame:Center()
	frame:SetTitle( "Helium: by Canadian Phuck" )
	frame:ShowCloseButton( false )
	frame:MakePopup()
	frame.Paint = function()
	
		surface.SetDrawColor( Color( 0,0,0,250 ) )
		surface.DrawRect( 0,0,frame:GetWide(),frame:GetTall() )
		
		surface.SetDrawColor( Color( 220,220,220,255 ) )
		surface.DrawOutlinedRect( 0,0,frame:GetWide(),frame:GetTall() )
	end
	
	local close = vgui.Create( "DButton" )
	close:SetParent( frame )
	close:SetPos( frame:GetWide() - 35,5 )
	close:SetSize( 30,20 )
	close:SetText( "X" )
	close.DoClick = function()
	
		local data = { 
	
			config 			= Helium.config,
			customDrawEnts 	= Helium.customDrawEnts,
			aimbotBuddies	= Helium.aimbotBuddies,
		}
	
		file.Write( "helium-config.txt",util.TableToJSON( data ) )
		
		frame:Close()
	end
	
	local itemList = vgui.Create( "DPanelList" )
	itemList:SetParent( frame )
	itemList:SetPos( 10,30 )
	itemList:SetSize( frame:GetWide() - 20,frame:GetTall() - 40 )
	itemList:EnableVerticalScrollbar( true )
	itemList:SetSpacing( 5 )
	
	local categories = {
	
		[ "Esp" ] = { 
			
			[ "Player Esp" ]							= false,
			[ "Player Info"	]							= false,
			[ "Player Boxes" ] 							= false,
			[ "Player Lines" ] 							= false,
			[ "Player FindTraitors" ]					= false,
	
			[ "Entity Esp" ]							= false,
		
		},
		
		[ "Aimbot" ] = { 
			
			[ "Aimbot IgnoreFriends" ] 					= false,
			[ "Aimbot IgnoreTeam" ] 					= false,
			[ "Aimbot IgnoreAdmins" ] 					= false,
			[ "Aimbot Nospread" ]						= false,
		
		},
		
		[ "Misc" ] = {
			
			[ "Misc Bhop" ] 							= false,
			[ "Misc Triggerbot" ] 						= false,
			[ "Misc TriggerBot Use Secondary Attack" ] 	= false,
			[ "Misc Crosshair" ] 						= false,
			[ "Misc Norecoil" ]							= false,
		},
	}
	
	function itemList.layout()
	
		itemList:Clear()
		
		for k,v in pairs( categories ) do
		
			local header = Helium:DLabel( nil,k )
			
			itemList:AddItem( header )
			
			for a,b in pairs( v ) do
			
				b = Helium.config[ a ]
		
				local varButton = vgui.Create( "DButton" )
				varButton:SetSize( 100,25 )
				varButton:SetText( "" )
				varButton.DoClick = function()
				
					Helium.config[ a ] = !b
					
					timer.Simple( .1,itemList.layout )
				end
				varButton.Paint = function()
					
					if ( b ) then
					
						surface.SetDrawColor( Color( 40,200,40,255 ) )
					else
						
						surface.SetDrawColor( Color( 200,40,40,255 ) )
					end
					
					surface.DrawRect( 0,0,varButton:GetWide(),varButton:GetTall() )
					
					draw.SimpleText( a .. ": " .. tostring( b ),"DermaDefaultBold",varButton:GetWide() / 2,varButton:GetTall() / 2,Color( 0,0,0,255 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
				end
				
				itemList:AddItem( varButton )
			
			end
		end
	end
	
	itemList.layout()
end

/* Hooks, Timers, Cmds */

Helium:AddTimer( 1,0,function() 


	Helium.FilterEntities()
	Helium:ScanForTraitors()
end )

Helium:AddHook( "HUDPaint",Helium.HudPaint )

Helium:AddHook( "CreateMove",Helium.Ucmd )

Helium:AddHook( "Think",Helium.Think )

Helium:AddCmd( "helium_kill",function() Helium:Kill() end )

Helium:AddCmd( "helium_gui",function() Helium:Gui() end )

Helium:AddCmd( "+helium_aim",function()

	Helium.aim = true
end )

Helium:AddCmd( "-helium_aim",function()

	Helium.aim = false
end )

Helium:AddCmd( "+helium_speed",function()

	RunConsoleCommand( "host_framerate",tostring( Helium.config[ "Misc Speedfactor" ] ) )
end )

Helium:AddCmd( "-helium_speed",function()
	
	RunConsoleCommand( "host_framerate","0" )
end )





