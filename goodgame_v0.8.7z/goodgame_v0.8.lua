local AntiCheat = false
for k,v in pairs(net.Receivers) do 
	if string.find(string.lower(debug.getinfo(v).short_src),string.char(108,101,121)) then 
		print(tostring(k),tostring(debug.getinfo(v).short_src))
		AntiCheat = true
	end 
end

if AntiCheat == true then
	RunConsoleCommand("disconnect")
	print("An Anticheat has been detected, Connect to a different server!")
	return
end


local GG = {}

local b = table
GG.Use_print_func = GG.Use_print_func or function() end

if debug.getinfo(print).short_src == "[C]" then
	GG.Use_print_func = _G.print
elseif debug.getinfo(Msg).short_src == "[C]" then
	GG.Use_print_func = _G.Msg
elseif debug.getinfo(MsgN).short_src == "[C]" then
	GG.Use_print_func = _G.MsgN
elseif debug.getinfo(chat.AddText).short_src == "[C]" then
	GG.Use_print_func = _G.chat.AddText
end

GG.Use_print_func("-----------------------")
GG.Use_print_func("-[Good Game] -Starting-")
GG.Use_print_func("-----------------------")


GG.Plugin_Name = "Plugin Loaded"

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " GG Table Init")
local dasl = _G.FindMetaTable
GG.WP = {}
GG.WP['Aimbot'] = true
GG.WP['Big_Aimbot'] = false
GG.WP.StoreTarg = {}

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " Well Played Loaded")

local t = b.Copy(dasl("Player"))

GG.ply = FindMetaTable("Player")
function GG.ply:EyeVisible(ent)
	if (!IsValid(ent)) then return end
	local trace = {start = self:LocalToWorld(self:OBBCenter()), endpos = ent:LocalToWorld(ent:OBBCenter()), filter = {self, ent}, mask = 1174421507};
    local tr = util.TraceLine(trace);
    return (tr.Fraction == 1);
end

GG.Targ = function()
	
	if GG.WP['Big_Aimbot'] == true then
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() then
				table.insert(GG.WP.StoreTarg, v)
			end
		end
		
		local targ = LocalPlayer():GetEyeTrace().Entity
		
		if targ and !targ:IsPlayer() then return end
		
		return targ
	end
	
	if GG.WP['Big_Aimbot'] == false then

		if #GG.WP.StoreTarg > #player.GetAll() - 1 then GG.WP.StoreTarg = {} end
		
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() and LocalPlayer():EyeVisible(v) and v:Health() > 0 then
				table.insert(GG.WP.StoreTarg, v)
			end
		end
		
		return table.Random(GG.WP.StoreTarg)
		
	end
	
	
end
local d = b.Copy(dasl("Entity"))

GG.Rand = function(tbl)
	return tbl[math.random(1,#tbl)]
end

GG.Timer = 0

local target = NULL

GG.ChooseBonesHead = "ValveBiped.Bip01_Head1"
GG.ChooseBonesNeck = "ValveBiped.Bip01_Neck1"
GG.ChooseBonesSpine = "ValveBiped.Bip01_Spine"

GG.ChooseBonesAll = "ValveBiped.Bip01_Spine","ValveBiped.Bip01_Neck1"

GG.ChooseBones = {GG.ChooseBonesHead}

GG.RunFunc = function()
	local wep = LocalPlayer():GetActiveWeapon()
	if IsValid(wep) then
		if not string.find(string.lower(wep:GetClass()),"weapon_") then return end
	end
	if IsValid(wep) and wep:Clip1() <= 0 then
		LocalPlayer():ConCommand("+reload")
		timer.Simple(0.2, function() LocalPlayer():ConCommand("-reload") end)
	end
	if LocalPlayer():KeyDown(IN_SPEED) and GG.WP['Aimbot'] == true and GG.WP['Big_Aimbot'] == true then
		target = GG.Targ()
	end
	if LocalPlayer():KeyDown(IN_ATTACK) and GG.WP['Aimbot'] == true then
		if GG.WP['Big_Aimbot'] == false then
			target = GG.Targ()
		end
		if target ~= nil and target ~= NULL and target:Health() > 0 then
			local targethead = target:LookupBone(GG.Rand(GG.ChooseBones))
			if targethead ~= nil then
				local targetheadpos,targetheadang = target:GetBonePosition(targethead)
				if LocalPlayer():EyeVisible(target) and target:IsPlayer() then
					if IsValid(wep) and wep.Primary ~= nil then
						wep.Primary.Recoil = 0
						wep.Primary.Cone = 0
					end
					t:SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
				end
			end		
		end
	end
end

GG.BypassScreen = false

GG.CustomTimer = function()
	GG.RunFunc()
	timer.Simple(0.0001, function() GG.CustomTimer() end)
end
GG.CustomTimer()



if GG.BypassScreen == false then
	halo.Add( ents.FindByClass( "player" ), Color( 255, 0, 0 ), 2, 2, 2, true, true )
	halo.Add( ents.FindByClass( "weapon" ), Color( 255, 0, 0 ), 5, 5, 2, true, true  )
end
	
if debug.getinfo(render.Capture).short_src == "[C]" then

if _G == nil then _G = {} end

GG.OldScr = _G.render.Capture

function _G.render.Capture( tbl )
	timer.Simple(2, function() LocalPlayer():ChatPrint("Screenshotted but we've bypassed it") end)
	GG.BypassScreen = true
	timer.Simple(10, function() GG.BypassScreen = false end)
	return GG.OldScr( tbl )
end
	
end

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " Custom Timer Created")

/*function GAMEMODE:CalcView( ply, pos, ang, fov )
	local view = {}

    view.origin = pos-( ang:Forward()*120 )
    view.angles = ang - Angle(0,0,0)
    view.fov = 40
 
    return view
end 

function GAMEMODE:ShouldDrawLocalPlayer()
	return true
end*/

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " CalcView Created")

GG.Use_print_func("-----------------")
GG.Use_print_func("[Good Game] -End-")
GG.Use_print_func("-----------------")

GG.Url = "https://dl.dropboxusercontent.com/u/17743302/update.txt"
GG.Version = 0.8
http.Fetch(GG.Url, function(c) 
local ver = string.Explode(" ",c)

if GG.Version != tonumber(ver[1]) then
	_G.print("Your version is out of date download newest here.. "..tostring(ver[2]))
	else
	_G.print("Your version is up to date")
end 

end, function(err) _G.print(err) end)