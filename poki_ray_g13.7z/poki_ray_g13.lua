--[[
	MOD/lua/pokiray.lua
	Coke_Is_Awesome | (STEAM_0:1:62123151) | [06-08-13 07:31:35PM]
	===BadFile===
]]

	

    local RayOn = false
    local AllMats = {}
    local allcolors = {}
    local FSetColor = _R.Entity.SetColor
    local FSetMat = _R.Entity.SetMaterial
    local FGetMat = _R.Entity.GetMaterial
    local repmat = CreateClientConVar("falco_xraymaterial", "mat2", true, false)
     
    local function TogglePoKiRay()
            if RayOn then
                    surface.PlaySound("buttons/button9.wav")
                    for k,v in pairs(ents.GetAll()) do
                            FSetMat(v, AllMats[v])
                            local z = allcolors[v]
                            if z and type(z) == "table" then
                                    FSetColor(v, z.r, z.g, z.b, z.a)
                            else
                                    FSetColor(v, 255,255,255,255)
                            end
                    end
                    allcolors = {}
            else
                    for k,v in pairs(ents.GetAll()) do
                            ExecFRayOnce(v)
                    end
                    surface.PlaySound("buttons/button9.wav")
            end
            RayOn = not RayOn
    end
    concommand.Add("quinray", TogglePoKiRay)
     
    function ExecFRayOnce(v)
            local r,g,b,a = v:GetColor()
            local class = v:GetClass()
            local low = string.lower(class)
            if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 0, 0, 255, 255)
            elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 140, 0, 255, 255)
            elseif string.find(class, "ghost") and a ~= 100 then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 255,255,255,100)
            elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 255, 0, 100, 50)
            elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 0, 0, 210, 40)
            elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and not v:IsWeapon() and class ~= "viewmodel" and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
                    allcolors[v] = Color(r,g,b,a)
                    FSetColor(v, 250, 0, 250, 100)
            end
            if class ~= "viewmodel" and FGetMat(v) ~= repmat:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
                    AllMats[v] = FGetMat(v)
                    FSetMat(v, repmat:GetString())
            end
    end
     
    function DoPoKiRay()
            if not RayOn then return end
            for k,v in pairs(ents.FindByClass("prop_physics")) do
                    if ValidEntity(v) then
                            FSetColor(v,255, 255, 20, 40)
                            FSetMat(v, repmat:GetString())
                    end
            end
           
            for k,v in pairs(ents.FindByClass("prop")) do
                    if ValidEntity(v) then
                            FSetColor(v,255, 255, 50, 40)
                            FSetMat(v, repmat:GetString())
                    end
            end
           
            for k,v in pairs(player.GetAll()) do
                    if ValidEntity(v) then
                            FSetColor(v,250,50,250,255)
                            FSetMat(v, repmat:GetString())
                    end
            end
    end
    hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)
     
    local ColorMod ={}
    ColorMod[ "$pp_colour_addr" ] = 0
    ColorMod[ "$pp_colour_addg" ] = 0
    ColorMod[ "$pp_colour_addb" ] = 0
    ColorMod[ "$pp_colour_brightness" ] = -0.1
    ColorMod[ "$pp_colour_contrast" ] = 1
    ColorMod[ "$pp_colour_colour" ] = 1
    ColorMod[ "$pp_colour_mulr" ] = 0
    ColorMod[ "$pp_colour_mulg" ] = 0
    ColorMod[ "$pp_colour_mulb" ] = 0

