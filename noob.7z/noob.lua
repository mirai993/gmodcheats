// Guess I will re-write this piece of shit.

if !( CLIENT ) then return end

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CreateMaterial = CreateMaterial
local EyeAngles = EyeAngles
local EyePos = EyePos
local FindMetaTable = FindMetaTable
local GetConVarNumber = GetConVarNumber
local GetConVarString = GetConVarString
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local MsgN = MsgN
local pairs = pairs
local Player = Player
local RealFrameTime = RealFrameTime
local require = require
local RunConsoleCommand = RunConsoleCommand
local SetMaterialOverride = SetMaterialOverride
local ScrW = ScrW
local ScrH = ScrH
local tostring = tostring
local type = type
local ValidEntity = ValidEntity
local Vector = Vector

local cam = cam
local chat = chat
local concommand = concommand
local draw = draw
local ents = ents
local hook = hook
local file = file
local math = math
local player = player
local render = render
local surface = surface
local table = table
local team = team
local timer = timer
local util = util
local vgui = vgui

local Noob = { }
Noob.Commands = { }
Noob.ConVars = { }
Noob.Hooks = { }
Noob.Files = { }
Noob.Forced = { }
Noob.Aiming = false
//Noob.Aim_Locked = false
Noob.Target = nil
Noob.View = Angle( 0, 0, 0 )

do

surface.CreateFont( 'coolvetica', 12, 100, true, true, 'ESPFont' )

function Noob.CreateVar( name, val, ret )
	table.insert( Noob.ConVars, name )
	return CreateClientConVar( name, val, ret )
end

function Noob.ConCommand( name, func )
	table.insert( Noob.Commands, name )
	return concommand.Add( name, func )
end

function Noob.Hook( type, func )
	if !( Noob.Hooks[type] ) then
		Noob.Hooks[type] = {}
		
		local Random = tostring( math.random( 1, 150 )..math.random( 1, 150 ) )
		
		Noob.Hooks[type].Index = Random
		Noob.Hooks[type].Functions = {}
		
		hook.Add(type , Random , function( stuff )
			for k, v in ipairs( Noob.Hooks[type].Functions ) do
				local Okay, Return = pcall( v , stuff )
				
				if !( Okay ) then
					ErrorNoHalt( Return..'\n' )
				elseif ( Return != nil ) then
					return Return
				end
			end
		end )
		table.insert( Noob.Hooks[type].Functions, func )
	else
		table.insert( Noob.Hooks[type].Functions, func )
	end
end

function Noob.Include( path ) // Useless function for right now.
	table.insert( Noob.Files, Path )
	return include( path )
end

Noob.FileRead = file.Read

function file.Read( fil, path ) // Relatively useless.
	if table.HasValue( Noob.Files, path ) then
		return ''
	else
		return Noob.FileRead( fil, path )
	end
end

function Noob.Force( var, val )
	table.insert( Noob.Forced, var )
	return cvar2.SetValue( var, val )
end

function Noob.Message( stuff )
	return MsgN( '[Noob] '.. stuff )
end

Noob.CreateVar( '_Noob_Aim_Admins', 0, true )
Noob.CreateVar( '_Noob_Aim_AimSpot', 'eyes', true )
Noob.CreateVar( '_Noob_Aim_AntiAim', 0, true )
Noob.CreateVar( '_Noob_Aim_Auto', 0, true )
Noob.CreateVar( '_Noob_Aim_Friendly', 0, true )
Noob.CreateVar( '_Noob_Aim_Mayor', 0, true )
//Noob.CreateVar( '_Noob_Aim_Fake', 0, true )
Noob.CreateVar( '_Noob_Aim_Offset', 2.5, true )
Noob.CreateVar( '_Noob_Aim_Steam', 0, true )
Noob.CreateVar( '_Noob_ESP_Enabled', 0, true )
Noob.CreateVar( '_Noob_Misc_Bhop', 0, true )
//Noob.CreateVar( '_Noob_Misc_LogIP', 0, true )
Noob.CreateVar( '_Noob_Vis_Barrel', 0, true )
Noob.CreateVar( '_Noob_Vis_Chams', 0, true )
Noob.CreateVar( '_Noob_Vis_XQZ', 0, true )

function Noob.Valid( e )
	if !( ValidEntity( e ) ) then return false end
	if !( e:IsPlayer() ) then return false end
	if !( e:Alive() ) then return false end
	if ( e == LocalPlayer() ) then return false end
	if ( e:IsNPC() ) then return false end
	if ( e:InVehicle() ) then return false end
	if ( GetConVarNumber( '_Noob_Aim_Admins' ) == 0 && e:IsAdmin() ) then return false end
	if ( GetConVarNumber( '_Noob_Aim_Steam' ) == 1 && e:GetFriendStatus() == 'friend' ) then return false end
	if ( GetConVarNumber( '_Noob_Aim_Friendly' ) == 0 && e:Team() == LocalPlayer():Team() ) then return false end
	if ( GetConVarNumber( '_Noob_Aim_Mayor' ) == 0 && gamemode.Get('DarkRP' ) && e:Team() == TEAM_MAYOR ) then return false end
	if ( e:Team() == TEAM_SPECTATOR ) then return false end
	if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	return true
end

function Noob.Visible( e )
	local Trace = { }
	Trace.start = LocalPlayer():GetShootPos()
	Trace.endpos = Noob.AimSpot( e )
	Trace.filter = e, LocalPlayer()
	Trace.mask = MASK_SHOT
	local tr = util.TraceLine( Trace )
	if !( tr.Hit ) then return true end
end

/*
function Noob.Prediction( e, Pos ) // I'll try to make this better at some later time.
		if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == 'Vector' ) ) then
		local Distance = e:GetPos():Distance( LocalPlayer():GetPos() )
		local Wep = LocalPlayer():GetActiveWeapon():GetClass()
		if ( Wep == 'weapon_crossbow' ) then
			local Time = Distance / 3110
			return ( Pos + e:GetVelocity() * Time )
		end
		return Pos
	end
	return Pos
end
*/

function Noob.AimSpot( e )
	local Pos = ( e:GetBonePosition( e:LookupBone( 'ValveBiped.Bip01_Head1' ) ) )
	if ( GetConVarString( '_Noob_Aim_AimSpot' ) == 'Eye' || ( GetConVarString( '_Noob_Aim_AimSpot' ) == 'Eyes' ) ) then
		Pos = ( e:GetAttachment( e:LookupAttachment( 'eyes' ) ) ).Pos
	elseif ( GetConVarString( '_Noob_Aim_AimSpot' ) == 'Head' || ( GetConVarString( '_Noob_Aim_AimSpot' ) == 'head' ) ) then
		Pos = ( e:GetBonePosition( e:LookupBone( 'ValveBiped.Bip01_Head1' ) ) )
	else
		Pos = ( e:LocalToWorld( e:OBBCenter() ) )
	end
	return Pos //&& Noob.Prediction( e, Pos )
end

function Noob.NormalizeAngles( AimAngle )
	AimAngle.p = math.NormalizeAngle( AimAngle.p )
	AimAngle.y = math.NormalizeAngle( AimAngle.y )
	AimAngle.r = 0
	return AimAngle
end
/*
function Noob.ClampAngles( ucmd, ang )
	ang.y = math.NormalizeAngle( ang.y + ( ucmd:GetMouseX() * -0.022 * 1 ) )
	ang.p = math.Clamp( ang.p + ( ucmd:GetMouseY() * 0.022 * 1 ), -89, 90 )
	return ang
end
*/

function Noob.Bhop( u )
	if ( GetConVarNumber( '_Noob_Misc_Bhop' ) == 1 ) then
		if ( u:KeyDown( IN_JUMP ) && LocalPlayer():IsOnGround() == false && LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP && LocalPlayer():GetMoveType() != MOVETYPE_OBSERVER && LocalPlayer():GetMoveType() != MOVETYPE_LADDER ) then
			u:SetButtons( u:GetButtons() - IN_JUMP )
		end
	end
end
Noob.Hook( 'CreateMove', Noob.Bhop )

Noob.ConCommand( '_Noob_Misc_Force', function( ply, cmd, args )
	if ( args[1] == nil ) then return Noob.Message( 'Usage: <ConVar> <Number>' ) end
	if !( ConVarExists( args[1] ) ) then return Noob.Message( 'Not a valid Cvar!' ) end
	if ( args[2] == nil ) then return Noob.Message( 'No number to force it to.' ) end
	Noob.Force( args[1], args[2] )
	Noob.Message( 'Forced '..args[1]..' to '..args[2] )
end )

//Dec0 isn't working, so stealing Isis' NoSpread.

function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end

local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]             = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function Noob.GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
	   
function Noob.NoSpread( ucmd, angle )
        local ply = LocalPlayer()
		
        cmd2, seed = abc_ucmd_getperdicston( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = Noob.GetCone( w )
                       
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                       
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                               
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
  end

function Noob.AimBot( u )
	if !( Noob.Aiming ) then return end
	Noob.View = Noob.NormalizeAngles( Noob.View )
	Noob.View = Noob.ClampAngles( u, Noob.View )
//	Noob.View.p = math.NormalizeAngle( Noob.View.p )
//	Noob.View.y = math.NormalizeAngle( Noob.View.y )
//	Noob.View.r = 0
//	Noob.View.y = math.NormalizeAngle( Noob.View.y + ( u:GetMouseX() * 0.022 ),  -89, 89 ) // Values taken from AutoAim.
//	Noob.View.p = math.Clamp( Noob.View.p + ( u:GetMouseY() * 0.022 ), -89, 89 ) // Values taken from AutoAim.
	u:SetViewAngles( Noob.View )
	Noob.Target = Noob.GetTargets( )
	if !( Noob.Target ) then return end
//	Noob.Aim_Locked = true
	local AimSpot = Noob.AimSpot( Noob.Target )
//	AimSpot = AimSpot + Noob.Target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
	AimSpot = AimSpot + Vector( 0, 0, GetConVarNumber( '_Noob_Aim_Offset' ) )
	local Angl = ( AimSpot - LocalPlayer():GetShootPos() ):Angle()
	Angl = Noob.NormalizeAngles( Angl )
//	Angl.p = math.NormalizeAngle( Angl.p )
//	Angl.y = math.NormalizeAngle( Angl.y )
//  Angl.r = 0
	u:SetViewAngles( Angl )
	u:SetViewAngles( Noob.NoSpread( u, Angle( Angl.p, Angl.y, 0 ) ) )
	if ( GetConVarNumber( '_Noob_Aim_Auto' ) == 1 && Noob.Aiming ) then
		u:SetButtons( u:GetButtons() | IN_ATTACK )
	end
end
Noob.Hook( 'CreateMove', Noob.AimBot )
Noob.ConCommand( '+Noob', function() Noob.Aiming = true end )
Noob.ConCommand( '-Noob', function() Noob.Aiming = false end )

function Noob.ESP( )
	if ( GetConVarNumber( '_Noob_ESP_Enabled' ) != 1 ) then return end
	for k, v in pairs( player.GetAll() ) do
		if ( v:Alive() && v != LocalPlayer() ) then
			local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen()
			draw.SimpleText( v:Name(), 'ESPFont', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT )
			draw.SimpleText( '['..v:Health()..']', 'ESPFont', Pos.x + 27, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT )
		end
	end
end
Noob.Hook( 'HUDPaint', Noob.ESP ) 

Noob.Banned = { 'weapon_crossbow', 'weapon_crowbar', 'npc_grenade_frag', 'weapon_rpg' } // Grenade will still break the hook.

function Noob.Barrel( )
	if ( GetConVarNumber( '_Noob_Vis_Barrel' ) != 1 ) then return end
	local ViewModel = LocalPlayer():GetViewModel()
	local Attach = ViewModel:LookupAttachment( '1' )
	if !( LocalPlayer():Alive() ) then return end
	if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
	if !( table.HasValue( Noob.Banned, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( Material( 'sprites/bluelaser1' ) )
		render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, Color( 128, 0, 128, 120 ) )
	end
end
Noob.Hook( 'RenderScreenspaceEffects', Noob.Barrel )
/*
function Noob.FakeView( ply, origin, angles, FOV )
	if ( GetConVarNumber( '_Noob_Aim_Fake' ) != 1 || ( !Noob.Aiming ) ) then return end
	local Ye = GAMEMODE:CalcView( ply, origin, Noob.View, FOV ) || {}
		Ye.angles = Noob.View
		Ye.angles.r = 0
	return Ye
end
Noob.Hook( 'CalcView', Noob.FakeView )
*/
/*
function Noob.LogIP( name, ip ) //This will be fixed soon.
	if ( GetConVarNumber( '_Noob_Misc_LogIP' ) == 1 ) then
		chat.AddText( ( Color( 255, 0, 0 ) ), '[ Noob ] ', 'Player '..name..' has connected from '..ip )
		Noob.Message( 'Player '..name.. ' has connected from '..ip )
		local Text = 'Name: '..name.. ' IP: '..ip
		file.Append( 'noob_logged.txt', Text )
	end
end
Noob.Hook( 'PlayerConnect', Noob.LogIP )

Noob.ConCommand( '_Noob_Misc_ClearIP', function( ) 
	if ( file.Exists( 'noob_logged.txt' ) ) then
		file.Delete( 'noob_logged.txt' )
		Noob.Message( 'Logged IPs Cleared!' )
	end
end )
*/


Noob.ConCommand( '+Noob_Speed', function( )
	Noob.Force( 'sv_cheats', 1 )
	Noob.Force( 'host_timescale', 2.5 )
end )

Noob.ConCommand( '-Noob_Speed', function( )
	Noob.Force( 'host_timescale', 1 )
end )

function Noob.NoRecoil( )
	if ( LocalPlayer():GetActiveWeapon().Primary ) then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
	end
end
Noob.Hook( 'Think', Noob.NoRecoil )

function Noob.AntiAim( u ) //This will probably fail.
	if ( GetConVarNumber( '_Noob_Aim_AntiAim' ) == 1 ) then
		if ( !u:KeyDown( IN_ATTACK | IN_USE ) && LocalPlayer():GetMoveType() != MOVETYPE_LADDER && LocalPlayer():GetMoveType() != MOVETYPE_OBSERVER ) then
			u:SetViewAngles( Angle( -90, Noob.View.y, 0 ) )
			Noob.View = Noob.ClampAngles( u, Noob.View )
			Noob.View = Noob.NormalizeAngles( Noob.View )
		end
	end	
end
Noob.Hook( 'CreateMove', Noob.AntiAim )

local Texture = { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 }
local Mat = CreateMaterial( 'Solid', 'UnlitGeneric', Texture )

/*
function Noob.Chams( )
	if ( GetConVarNumber( '_Noob_Vis_Chams' ) == 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if !( Noob.Visible( v ) ) then
				if ( v:Alive() ) then
					local Teamcolor = team.GetColor( v:Team() )
					cam.Start3D( EyePos(), EyeAngles() )
					render.SuppressEngineLighting( 1 ) 
					SetMaterialOverride( Mat )
					render.SetColorModulation( ( Teamcolor.r * 1/255 ), ( Teamcolor.g * 1/255 ), ( Teamcolor.b * 1/255 ) )
					v:DrawModel()
					render.SuppressEngineLighting( 0 )
					render.SetColorModulation( 1, 1, 1 )
					cam.End3D()
				end
			end
		end
	end
end
Noob.Hook( 'RenderScreenspaceEffects', Noob.Chams )

function Noob.Wallhack( )
	if ( GetConVarNumber( '_Noob_Vis_XQZ' ) == 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if ( v:Alive() ) then
				if !( Noob.Visible( v ) ) then
					local WHITE = Color( 255, 255, 255 )
					cam.Start3D( EyePos(), EyeAngles() )
					cam.IgnoreZ( 1 )
					render.SetColorModulation( ( WHITE.r * 1/255 ), ( WHITE.g * 1/255 ), ( WHITE.b * 1/255 ) )
					v:DrawModel()
					cam.IgnoreZ( 0 )
					cam.End3D()
				end
			end
		end
	end
end

Noob.Hook( 'RenderScreenspaceEffects', Noob.Wallhack )
*/

end