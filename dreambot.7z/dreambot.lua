// note by paradox: PA4 is a custom module made for this, I have it in my bin folder.

/*

	$$$$$$$\                                                  $$$$$$$\             $$\     
	$$  __$$\                                                 $$  __$$\            $$ |    
	$$ |  $$ | $$$$$$\   $$$$$$\   $$$$$$\  $$$$$$\$$$$\      $$ |  $$ | $$$$$$\ $$$$$$\   
	$$ |  $$ |$$  __$$\ $$  __$$\  \____$$\ $$  _$$  _$$\     $$$$$$$\ |$$  __$$\\_$$  _|  
	$$ |  $$ |$$ |  \__|$$$$$$$$ | $$$$$$$ |$$ / $$ / $$ |    $$  __$$\ $$ /  $$ | $$ |    
	$$ |  $$ |$$ |      $$   ____|$$  __$$ |$$ | $$ | $$ |    $$ |  $$ |$$ |  $$ | $$ |$$\ 
	$$$$$$$  |$$ |      \$$$$$$$\ \$$$$$$$ |$$ | $$ | $$ |$$\ $$$$$$$  |\$$$$$$  | \$$$$  |
	\_______/ \__|       \_______| \_______|\__| \__| \__|\__|\_______/  \______/   \____/ 
		Dream.Bot Cheat By 2cash		
		
*/

/*
	Dream.Bot
		Variables
*/
	local me = LocalPlayer();
	local DreamBot = {};
		local servertime = 0;
		local eTickInt = engine.TickInterval();
		DreamBot.Config = {};
		DreamBot.Colors = {};
			DreamBot.Colors.white = Color(255,255,255);
			DreamBot.Colors.green = Color(0,255,0);
			DreamBot.Colors.red   = Color(255,0,0);
			DreamBot.Colors.blue  = Color(0,0,255);
		DreamBot.F = {};
		DreamBot.SpreadTables = {};
		DreamBot.F["aimbot"] = {};
		DreamBot.F["draw"] = {};
		DreamBot.F["draw"].color = Color(26, 188, 156,250);
		DreamBot.F["draw"].menuHandle = {};
		DreamBot.F["aimbot"].DownOffset = Vector(0,0,-eTickInt);
		DreamBot.T = {}; // Trash variable ( temp variable storage )
		DreamBot.T["menu"] = {};
		DreamBot.T["menu"].open = false;

/*
	Dream.Bot
		Fresh Global Variables & Detours
*/
	local hook = hook or {};
	local player = player or {};
	local team = team or {}; 
	local surface = surface or {};
	local debug = debug or {};
	local util = util or {};
	local file = file or {};
	local render = render or {};
	local cam = cam or {};
	local http = http or {};
	local package = package or {};
	local chat = chat or {};
	local timer = timer or {};
	local string = string or {};
	local vgui = vgui or {};
	local table = table or {};
	local ents = ents or {};
	local gui = gui or {};
	local debug = debug or {};
	local math = math or {};
	local util = util or {};
	local input = input or {};
	local net = net;
	local jit = jit;
	local MsgC = MsgC;
	local engine = engine;
	local gameevent = gameevent;
	local bit = bit;
	local GAMEMODE = GAMEMODE;
	local jit = jit;
	local tostring = tostring;
	local SortedPairs = SortedPairs;
	local tonumber = tonumber;
	local IsValid = IsValid;
	local LocalPlayer = LocalPlayer;
	local rawset = rawset;
	local Lerp = Lerp;
	local RunConsoleCommand = RunConsoleCommand;
	local pairs = pairs;
	local ipairs = ipairs;
	local Angle = Angle;
	local print = print;
	local next = next; 
	local type = type;
	local MsgN = MsgN;
	local IsFirstTimePredicted = IsFirstTimePredicted;
	local Material = Material;
	local CreateMaterial = CreateMaterial;
	local Msg = Msg; 
	local GetConVar = GetConVar;
	local RunString = RunString;
	local ScrW = ScrW;
	local CurTime = CurTime;
	local ScrH = ScrH;
	local Entity = Entity;
	local pcall = pcall;
	local Format = Format;
	local Color = Color;
	local _G = _G;
	local Vector = Vector;
	local tobool = tobool;
	local FindMetaTable = FindMetaTable;
	local require = require;
	local __eq = __eq;
	local __tostring = __tostring;
	local __gc = __mul;
	local __index = __index;
	local __concat = __concat;
	local __newindex = __newindex;
	local __add = __add;
	local __sub = __sub;
	local __div  = __div;
	local __call = __call;
	local __pow = __pow;
	local __unm = __unm;
	local __lt = __lt;
	local __le = __le;
	local __mode = __mode;
	local __metatable = __metatable;
	local MOVETYPE_OBSERVER = MOVETYPE_OBSERVER;
	local TEAM_SPECTATOR = TEAM_SPECTATOR;
	local KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT, KEY_INSERT, KEY_F = KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT, KEY_INSERT, KEY_F;
	local MASK_SHOT, CONTENTS_WINDOW = MASK_SHOT, CONTENTS_WINDOW; 

	debug.getinfo = function()
		return { 
			what = "C",
			source = "[C]",
			source_src = "[C]",
			linedefined = -1,
			currentline = -1,
			lastlinedefined = -1,
			short_src = "[C]"
		};
	end
	local leltable = {"What u doing snooping around in here!"};
	hook.GetTable = function() return leltable; end	
	debug.traceback = function() return nil; end	
	_G.system.IsOSX = function() return false; end
	_G.system.IsWindows = function() return false; end
	_G.system.IsLinux = function() return false; end
	
	DreamBot.R       = debug.getregistry();
	DreamBot.CR       = table.Copy(DreamBot.R);
	vAngle                    = DreamBot.R.Vector.Angle
	vLength                   = DreamBot.R.Vector.Length
	vLengthSqr                   = DreamBot.R.Vector.LengthSqr
	vDistance                 = DreamBot.R.Vector.Distance
	vToScreen                 = DreamBot.R.Vector.ToScreen
	aForward                  = DreamBot.R.Angle.Forward
	pShootPos              = DreamBot.R.Player.GetShootPos
	pGetFriendStatus  = DreamBot.R.Player.GetFriendStatus
	pGetActiveWeapon  = DreamBot.R.Player.GetActiveWeapon
	pNick                     = DreamBot.R.Player.Nick
	pEyePos                   = DreamBot.R.Entity.EyePos
	pTeam                     = DreamBot.R.Player.Team
	pInVehicle        = DreamBot.R.Player.InVehicle
	pIsBot                    = DreamBot.R.Player.IsBot
	pAlive                    = DreamBot.R.Player.Alive
	eIsOnGround               = DreamBot.R.Entity.IsOnGround
	eHealth                   = DreamBot.R.Entity.Health
	eIsPlayer                 = DreamBot.R.Entity.IsPlayer
	eLocalToWorld     = DreamBot.R.Entity.LocalToWorld
	eGetPos                   = DreamBot.R.Entity.GetPos
	eGetFriendStatus          = DreamBot.R.Entity.GetFriendStatus
	eOnGround                 = DreamBot.R.Entity.OnGround
	eOBBCenter                = DreamBot.R.Entity.OBBCenter
	eDrawModel                = DreamBot.R.Entity.DrawModel
	eWaterLevel               = DreamBot.R.Entity.WaterLevel
	eGetMoveType              = DreamBot.R.Entity.GetMoveType
	eGetClass                 = DreamBot.R.Entity.GetClass
	eIsValid                  = DreamBot.R.Entity.IsValid
	eIsDormant                  = DreamBot.R.Entity.IsDormant
	eGetColor                  = DreamBot.R.Entity.GetColor
	eLookupBone               = DreamBot.R.Entity.LookupBone
	eGetVelocity              = DreamBot.R.Entity.GetVelocity
	eGetVelocity              = DreamBot.R.Entity.GetVelocity
	eGetMaxHealth     = DreamBot.R.Entity.GetMaxHealth
	eSetPoseParameter = DreamBot.R.Entity.SetPoseParameter
	eEyeAngles                = DreamBot.R.Entity.EyeAngles
	eGetAttachment    = DreamBot.R.Entity.GetAttachment
	eLookupAttachment = DreamBot.R.Entity.LookupAttachment
	eGetHitBoxBone = DreamBot.R.Entity.GetHitBoxBone
	eGetHitBoxBounds = DreamBot.R.Entity.GetHitBoxBounds
	eGetHitBoxGroupCount = DreamBot.R.Entity.GetHitBoxGroupCount
	eGetHitBoxCount = DreamBot.R.Entity.GetHitBoxCount
	eGetBoneParent = DreamBot.R.Entity.GetBoneParent
	eGetBoneCount = DreamBot.R.Entity.GetBoneCount;
	eOBBMins                  = DreamBot.R.Entity.OBBMins
	eOBBMaxs                  = DreamBot.R.Entity.OBBMaxs
	eGetBonePosition          = DreamBot.R.Entity.GetBonePosition
	eLookupBone          = DreamBot.R.Entity.LookupBone
	eInvalidateBoneCache          = DreamBot.R.Entity.InvalidateBoneCache
	wClip1                    = DreamBot.R.Weapon.Clip1
	wGetNextPrimaryFire = DreamBot.R.Weapon.GetNextPrimaryFire
	cGetForwardMove   = DreamBot.R.CUserCmd.GetForwardMove
	cGetSideMove              = DreamBot.R.CUserCmd.GetSideMove
	cGetViewAngles    = DreamBot.R.CUserCmd.GetViewAngles
	cSetViewAngles    = DreamBot.R.CUserCmd.SetViewAngles
	cSetForwardMove   = DreamBot.R.CUserCmd.SetForwardMove
	cSetSideMove              = DreamBot.R.CUserCmd.SetSideMove
	cGetMouseX                = DreamBot.R.CUserCmd.GetMouseX
	cGetMouseY                = DreamBot.R.CUserCmd.GetMouseY
	cGetButtons               = DreamBot.R.CUserCmd.GetButtons
	cSetButtons               = DreamBot.R.CUserCmd.SetButtons
	cRemoveKey                = DreamBot.R.CUserCmd.RemoveKey
	cKeyDown                  = DreamBot.R.CUserCmd.KeyDown
	cCommandNumber    = DreamBot.R.CUserCmd.CommandNumber
	cvGetBool                 = DreamBot.R.ConVar.GetBool
		
/*
	Dream.Bot
		Configuration
*/	

	RunConsoleCommand("hud_draw_fixed_reticle","1");

	surface.CreateFont( "MenuTitle", {
	font = "Trebuchet24",
	size = 13,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
	} )


	DreamBot.Config.version = "1.3a";
	DreamBot.Config["Aimbot"] = {}; 
	DreamBot.Config["Misc"] = {}; 
	DreamBot.Config["hvh"] = {}; 
	DreamBot.Config["Misc"]["ThirdPerson"] = false;
	DreamBot.Config["Misc"]["Bhop"] = false;
	DreamBot.Config["Misc"]["StealNames"] = false;
	DreamBot.Config["Misc"]["SpeedHack"] = false;
	DreamBot.Config["Misc"]["FOV"] = false;
	DreamBot.Config["Misc"]["WireFrame"] = false;
	DreamBot.Config["Misc"]["SpamChat"] = false;
	DreamBot.Config["hvh"]["AAA"] = true;
	DreamBot.Config["hvh"]["AA"] = false;
	DreamBot.Config["hvh"]["AA_CHEW"] = 3;
	DreamBot.Config["hvh"]["AA_TYPE"] = 2;
	DreamBot.Config["hvh"]["FakeLag"] = false;
	DreamBot.Config["hvh"]["FakeLagPred"] = false;
	// 180,580,1266,562,900,1657
	//DreamBot.Config["hvh"]["AA_TEST_P"] = 1266;
	DreamBot.Config["esp"] = {}; 
	DreamBot.Config["esp"]["chams"] = false;
	DreamBot.Config["esp"]["on"] = false;
	DreamBot.Config["esp"]["rainbow"] = false;
	DreamBot.Config["esp"]["headbox"] = false;
	DreamBot.Config["esp"]["type"] = 0;
	DreamBot.Config["esp"]["names"] = false;
	DreamBot.Config["esp"]["Radar"] = false;
	DreamBot.Config["Aimbot"]["on"] = false;
	DreamBot.Config["Aimbot"]["SilentAim"] = true;
	DreamBot.Config["Aimbot"]["AutoWall"] = false;
	DreamBot.Config["Aimbot"]["GhostCheck"] = false;
	DreamBot.Config["Aimbot"]["pSilentAim"] = false;
	DreamBot.Config["Aimbot"]["useHitboxes"] = false;
	DreamBot.Config["Aimbot"]["No-Spread"] = false;
	DreamBot.Config["Aimbot"]["No-Recoil"] = false;
	DreamBot.Config["Aimbot"]["ragemode"] = false;
	DreamBot.Config["Aimbot"]["targetfriends"] = false;
	DreamBot.Config["Aimbot"]["targetteam"] = false;
	DreamBot.Config["Aimbot"]["onlytargetteam"] = false;
	
	me:ConCommand([[cl_interp 0.066;cl_interp_ratio 2;cl_updaterate 120]])

/*
	Dream.Bot
		Initial Hooked/Main Functions
*/
	DreamBot.R.Entity.FireBullets = function( entity, bulletInfo )
		local curWep = eGetClass(pGetActiveWeapon(me));
		local spread = bulletInfo.Spread;
		if(spread == Vector() ) then return; end
		DreamBot.SpreadTables[curWep] = spread;
		DreamBot.CR.Entity.FireBullets(entity,bulletInfo);
	end
	
	
	local NoSprd_CenterBullet = function(cmd,AngleToCenter)
		local curWep = eGetClass(pGetActiveWeapon(me));
		local pAngs = DreamBot.SpreadTables[curWep];
		if( pAngs == nil ) then return AngleToCenter; end
		
		local ang = vAngle(DS_manipulateShot( DS_md5PseudoRandom( cCommandNumber(cmd) ), aForward(AngleToCenter), Vector(-pAngs.x,-pAngs.y,0)));
		ang.y, ang.x = math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.x);
		return ang ;
		
	end
	
	local NoRcl_CenterGun = function(vec)
		if(!DreamBot.Config["Aimbot"]["No-Recoil"]) then return vec; end
			return vec - me:GetPunchAngle();
	end
	

/*
	Dream.Bot
		Initial Functions
*/
	local ifCOND = function(cond,y,n) if(cond) then return y; else return n; end end
	local wepAutomatic = function() local wep = pGetActiveWeapon(me); return wep != NULL && wep.Primary && wep.Primary.Automatic; end
	local DrawMSG = function(tf, msg) local MsgMethod = ifCOND(tf,MsgC, chat.AddText) MsgMethod(DreamBot.Colors.white, "[", DreamBot.Colors.green, "Dream.Bot", DreamBot.Colors.white, "]: ", msg, ifCOND(tf,"\n","")); end 
	local RequireO = function(strName) RunConsoleCommand("require", "dlls/" .. strName); end
	local ExtRequire = function(includeFile) DrawMSG(true, "Including Module \"" .. includeFile .. "\""); require(includeFile); DrawMSG(true, "Loaded Module \"" .. includeFile .. "\""); end
	local SortClosestEntity = function(k,v) return vLengthSqr(eGetPos(k) - eGetPos(me)) < vLengthSqr(eGetPos(v) - eGetPos(me)); end
	local NumberInRange = function(num,min,max)  return num <= max && num >= min; end
	local VectorConversion = function(rgb) local tbl = rgb; for k,v in next, tbl do tbl[k] = v / 255; end return tbl; end
	local RecoilFix = function() local curWep = pGetActiveWeapon(me);
        if(curWep.Primary != nil or false)then
			if curWep.Primary.Recoil then
                curWep.Primary.Recoil = 0
            end
             if curWep.Primary.KickUp then
                curWep.Primary.KickUp = 0
                curWep.Primary.KickDown = 0
               curWep.Primary.KickHorizontal = 0
            end
            end 
	end
	
	local StealNames = function()
	if(!DreamBot.Config["Misc"]["StealNames"]) then return; end
		local hacker = player.GetAll()
		for k,v in next,hacker do
			if(v == me || string.find(pNick(v), pNick(me))) then table.remove(hacker,k); end
		end
		GetConVar("name"):SetValue(table.Random(hacker):Nick() .. "⁢");
	end
	
	// Closest thing u will ever see to engine pred
	-- note by paradox: this comment is funny
	local VelocityPrediction = function(ent,aimPos)
		-- local self_Velocity,target_Velocity = eGetVelocity(me), eGetVelocity(ent);
		-- self_Velocity.z,target_Velocity.z = 0; // We cant trust horizonal Prediction, its not reliable
		-- return aimPos - (self_Velocity * engine.TickInterval() + target_Velocity * engine.TickInterval() );
		return aimPos;
	end
	
	local fakelagBucket = {};
	local FakeLagPrediction = function(v)
		if(v == nil || !DreamBot.Config["hvh"]["FakeLagPred"]) then return Vector(0,0,0); end
		if(!fakelagBucket[v]) then
			fakelagBucket[v] = {
				eGetVelocity(v),
				eGetPos(v),
				0,
			};
		end

		local oldVel = fakelagBucket[v][1];
		local oldPos = fakelagBucket[v][2];
	
		fakelagBucket[v][1] = eGetVelocity(v);
		fakelagBucket[v][2] = eGetPos(v);
	
		if(oldVel == Vector()) then 
			fakelagBucket[v][3] = 0;
			return Vector(0,0,0);
		end
	
		if(fakelagBucket[v][1] == oldVel && oldPos == fakelagBucket[v][2]) then
			fakelagBucket[v][3] = fakelagBucket[v][3] + 1;
	
			return ((oldVel * (eTickInt * fakelagBucket[v][3])));
		else
			fakelagBucket[v][3] = 0;
		end
		return Vector(0,0,0);
	end


	local aIsVisible = function(v, vec)
		local trace = util.TraceLine( {
			start = VelocityPrediction(me,pEyePos(me)),
			endpos = (VelocityPrediction(me,vec) + FakeLagPrediction(v)),
			filter = {v,me},
			mask = ifCOND(!DreamBot.Config["Aimbot"]["AutoWall"], MASK_SHOT,MASK_VISIBLE)
		} );
		return trace.Entity == v || !trace.Hit || trace.Fraction == 1;
	end
	
	local GetCurTime = function()
		if(!IsFirstTimePredicted()) then return; end
		servertime = CurTime() + eTickInt;
	end

	local CanFire = function()
		local wep = pGetActiveWeapon(me)
		if(!eIsValid(wep)) then return; end
		return( servertime >= wGetNextPrimaryFire(wep) );
	end
	
	DreamBot.F.ForceVar = function(Var,Val)
		GetConVar(Var):SetValue(Val);
	end
	
	local SpeedHack = function()
		if(input.IsKeyDown(KEY_B) && DreamBot.Config["Misc"]["SpeedHack"]) then
				-- GetConVar("sv_cheats"):SetValue(1)
				-- GetConVar("host_timescale"):SetValue(4)
			else
				-- GetConVar("sv_cheats"):SetValue(0)
				-- GetConVar("host_timescale"):SetValue(1)			
		end
	end
	
/*
	Dream.Bot
		JSON Save Management
*/	
	
	local JSONFileStructCheck = function()
		if(!file.Exists("dreambot_config","DATA")) then
			file.CreateDir("dreambot_config");
		end
	end
	
	local JSONLoad = function(filename)
		if(!file.Exists("dreambot_config/" .. filename .. ".txt", "DATA")) then print("Config " .. filename .. " Does not exist!"); return; end
		local JSONTbl = util.JSONToTable(file.Read("dreambot_config/" .. filename .. ".txt", "DATA"));
		
			for tblTypeN,tblType in next, JSONTbl do
				if(tblPTypeN == "version" || tblPType == "version" || tblTypeN == "version" || tblType == "version") then continue; end 
				for tblPTypeN,tblPType in next, tblType do
					print("Loading Config " .. filename .. ": " .. tblTypeN,tblPTypeN,tblPType);
					DreamBot.Config[tblTypeN][tblPTypeN] = tblPType;
				end
			end	
			DreamBot.F["draw"].notfication("Configuration File " .. filename .. " Loaded!",Color(44, 62, 80,180),2);
		
	end
	
	local JSONSave = function(tbl,filename)
		JSONFileStructCheck(); // Check if director exists
		print("Making...");
		local tblJSON = util.TableToJSON(tbl,true);
		file.Write("dreambot_config/" .. filename .. ".txt", tblJSON);
		DreamBot.F["draw"].notfication("Configuration File " .. filename .. " Saved!",Color(44, 62, 80,180),2);
	end

/*
	Dream.Bot
		Required Modules Include
*/
	
	-- ExtRequire("spreadthebutter");
	-- ExtRequire("cvar3");
	-- ExtRequire("name_enabler");
	if(PA4 == nil) then RequireO("1/gmcl_aaa_win32.dll"); end

		//	timer.Simple(0.5, function() PA4.AAAX(DreamBot.Config["hvh"]["AAA"]);PA4.AAAY(DreamBot.Config["hvh"]["AAA"]); end); // cancer cancer cancer
	
	
/*
	Dream.Bot
		Mouse Correction
*/
	local SilentMouse = function(cmd,aa)
		if(!DreamBot.Config["Aimbot"]["SilentAim"]) then return ms; end 
		if (!ms) then ms = cGetViewAngles(cmd) end
		ms = ms + Angle(cGetMouseY(cmd) * .023, cGetMouseX(cmd) * -.023, 0);
		ms.x = math.NormalizeAngle(ms.x);
		ms.p = math.Clamp(ms.p, -89, 89);
	end
	
	local FixMovement = function(cmd,aa)
		if(!DreamBot.Config["Aimbot"]["SilentAim"]) then return; end 
		local move = Vector( cGetForwardMove(cmd), cGetSideMove(cmd), 0 );
		local angle = cGetViewAngles(cmd);
		angle.x = 0
		move = aForward(( vAngle(move) + (angle - ms) )) * move:Length();
	
		if( aa && cGetViewAngles(cmd).x > 90 || aa && cGetViewAngles(cmd).x < -90 ) then
			move.x = -move.x
		end
	
		cSetForwardMove(cmd, move.x );
		cSetSideMove(cmd, move.y );
	end	
	
/*
	Dream.Bot
		Anti-Aims
*/	
local aaJam = 0;
local AATbl = {1,4,7,10};
local aaLoop = 1;
local aaUpFake = false;

local pPitch_y = {360,270};
	local antiAimHandle = function(cmd)
	
		local startAngle = Angle();
		
		/*
			Anti Aim Research Notes:
			
			After testing for days with different angles, I came across this angle that fakes in range angles.
			
			The angle 631 fakes the 80 range, im pretty sure it fakes 87 or 85
			
			You can mess with this angle too make it manipulate angles Such as 633 that fakes 87
			
		*/ 
		chokeAngle = false;
		aaFixAngle = true;

		
		if(DreamBot.Config["hvh"]["AA_TYPE"] == 1) then
			// FAKES 85
			if(aaJam < 1) then
				startAngle.p = -180;
				startAngle.y = 0;
				startAngle.r = 0;
				aaJam = aaJam + 1;
				chokeAngle = true;
			else
				startAngle.p = 180;
				startAngle.y = 0;
				startAngle.r = 0;
				aaJam = 0;
				chokeAngle = false;
			end
		else if(DreamBot.Config["hvh"]["AA_TYPE"] == 2) then
			// UN-CORRECTABLE AA
				local daYaw = math.random(-1,1);
				local syncmp =  table.Random({1,4,7,10});
			if(aaJam < DreamBot.Config["hvh"]["AA_CHEW"]) then	
				startAngle.p = syncmp;			
				startAngle.y = syncmp;			
				startAngle.r = 0;
				aaJam = aaJam +1;

				if(aaJam == DreamBot.Config["hvh"]["AA_CHEW"]) then
					chokeAngle = false;
				else
					chokeAngle = true;
				end
			else
				startAngle.p =	table.Random({-632,-635,-633});
				startAngle.y = daYaw + syncmp + 180;
				startAngle.r = 0;
				aaJam = 0;
				chokeAngle = true;
				aaFixAngle = false;
			end
			aaLoop = aaLoop + 1;	
		else if(DreamBot.Config["hvh"]["AA_TYPE"] == 3) then
			// ANTI SPINE AA
			if(aaLoop > #AATbl) then aaLoop = 1; end			
			startAngle.p = -181;			
			startAngle.y = 360 + AATbl[aaLoop];			
			startAngle.r = 0;
			aaLoop = aaLoop + 1;	
		else if(DreamBot.Config["hvh"]["AA_TYPE"] == 4) then
			// Jitter AA
			startAngle.p = -181;
			startAngle.y = ms.y + math.random(-90,90);
			startAngle.r = 0;
		else if(DreamBot.Config["hvh"]["AA_TYPE"] == 5) then
			// T-JITTER AA
			startAngle.p = -181;
			startAngle.y = ms.y - -900 + math.random(-90,90);
			startAngle.r = 0;
		else if(DreamBot.Config["hvh"]["AA_TYPE"] == 6) then
			startAngle.p = 180.087929;
			startAngle.y = 0;
			startAngle.r = 0;
			aaJam = 0;
 		end
		end
		end
		end
		end
		end
		
		//aaUpFake = !aaUpFake;
		//startAngle.p = 90.1;
		//startAngle.y = RealTime()*160%360;
		//startAngle.r = 0;
		
			
		//PA4.CHOKE_PACKETS(chokeAngle);
		cSetViewAngles(cmd,startAngle);
		FixMovement(cmd,aaFixAngle);
	end
	
/*
	Dream.Bot
		Aimbot Functions
*/	

	local returnHitBoxedBone = function(ent,h1,h2)
		local bone = eGetBonePosition(ent, eGetHitBoxBone(ent, h1,h2));
		local mins,maxs = eGetHitBoxBounds(ent, h1,h2);
		if(bone) then return bone + (( mins + maxs ) *.5); end
	end
	
	local aimbotGetBone = function(ent)
		if(DreamBot.Config["Aimbot"]["useHitboxes"]) then
			local bone = returnHitBoxedBone(ent, 0,0);
			if(bone && aIsVisible(ent, bone)) then return bone; end
		else
			 if(eLookupAttachment(ent,"eyes") != 0) then
				local bone = eGetAttachment(ent,eLookupAttachment(ent,"eyes")).Pos;
				if(aIsVisible(ent,bone)) then return bone; end
			else if(eLookupAttachment(ent,"forward") != 0) then
				local bone = eGetAttachment(ent,eLookupAttachment(ent,"forward")).Pos;
				if(aIsVisible(ent,bone)) then return bone; end
			else
				local bone = (eGetPos(ent) + eOBBCenter(ent));
				if(aIsVisible(ent,bone)) then return  bone; end
			end
			end
		end
		
		
	end
	
	local aimbotClosestPlayer = function(tf)
		if(!DreamBot.Config["Aimbot"]["on"]) then return; end 
		local players = player.GetAll();
		table.sort(players,SortClosestEntity);
		
		for k,v in next,players do
			if(v == me ||  eHealth(v) < 1 || eIsDormant(v)) then continue; end
			if(pTeam(v) == TEAM_SPECTATOR) then continue; end
			if(pTeam(v) == TEAM_CONNECTING) then continue; end
			if(!DreamBot.Config["Aimbot"]["targetfriends"] && pGetFriendStatus(v) == "friend") then continue; end
			if(DreamBot.Config["Aimbot"]["GhostCheck"] && eGetColor(v).a != 255) then continue; end
			if (DreamBot.Config["Aimbot"]["onlytargetteam"] && pTeam(v) != pTeam(me)) then continue; end
			if(!DreamBot.Config["Aimbot"]["targetteam"] && !DreamBot.Config["Aimbot"]["onlytargetteam"] && pTeam(me) == pTeam(v)) then continue; end
			if(aimbotGetBone(v) != nil) then return v; end; 
		end
			
		return nil;
	end
	
	local aimbotMainHook = function(cmd)
		SilentMouse(cmd);
			local ClosestPlayer = aimbotClosestPlayer(true);
			local ValidTarget = ClosestPlayer != nil;
			local cFire = CanFire();
			//PA4.CHOKE_PACKETS(false);
		if( DreamBot.Config["Aimbot"]["on"] && DreamBot.Config["Aimbot"]["ragemode"] && ValidTarget && cFire || DreamBot.Config["Aimbot"]["on"] && !DreamBot.Config["Aimbot"]["ragemode"] && ValidTarget && cFire && cKeyDown(cmd, IN_ATTACK )  ) then
				local posAim = ( VelocityPrediction(ClosestPlayer,aimbotGetBone(ClosestPlayer)) - pShootPos(me) + (FakeLagPrediction(ClosestPlayer))):Angle();
				posAim.r = 0;
				posAim = NoRcl_CenterGun(posAim);
				posAim = NoSprd_CenterBullet(cmd,posAim);
				if(DreamBot.Config["Aimbot"]["ragemode"]) then
					if(input.IsKeyDown(KEY_B) && DreamBot.Config["Misc"]["SpeedHack"]) then	GetConVar("sv_cheats"):SetValue(1); GetConVar("host_framerate"):SetValue(0) end
						cSetButtons(cmd, bit.bor(cGetButtons(cmd), IN_ATTACK));
				end

//if(DreamBot.Config["Aimbot"]["pSilentAim"]) then PA4.CHOKE_PACKETS(true); end
				cSetViewAngles(cmd, posAim);
			else
			if(DreamBot.Config["hvh"]["AA"]) then antiAimHandle(cmd); return; elseif(DreamBot.Config["Aimbot"]["SilentAim"]) then cSetViewAngles(cmd,ms) end
		end
		FixMovement(cmd,false);
	end

/*
	Dream.Bot
		Misc Functions
*/
	local says = {"Correct Dem Magic Pitches Bitches", "Anti-Aim Trasher", "1 Tap Generator", "sega.pw", "Private cheats for gods"}
	local ChatSpam = function()
		if(!DreamBot.Config["Misc"]["SpamChat"]) then return; end
		LocalPlayer():ConCommand("say Dream.Bot " .. DreamBot.Config.version .. " || " .. table.Random(says) );
	end
	
	
	local chamsmat = CreateMaterial("a", "VertexLitGeneric", {["$ignorez"] = 1,["$model"] = 1,["$basetexture"] = "models/debug/debugwhite",});
	local chamsmat2 = CreateMaterial("@", "vertexLitgeneric", {["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite",});
	local VisiblePlayers = {}
	
	local ChamsDud = function()
		if(!DreamBot.Config["esp"]["chams"]) then return; end 
		for k,v in next, player.GetAll() do	
			if(eHealth(v) < 1 || v == LocalPlayer() || !eIsValid(v) || v:IsDormant()) then continue; end 
			local pColorVis = VectorConversion(Color(46, 204, 113));
			local pColor = VectorConversion(Color(243, 156, 18));
			local pColorGun = VectorConversion(Color(255,20,147));
			cam.Start3D();
				render.MaterialOverride(chamsmat);
				render.SetColorModulation(pColorVis.r,pColorVis.g,pColorVis.b);
				render.SetBlend(1);
				eDrawModel(v);
				
				if (eIsValid(pGetActiveWeapon(v))) then
					render.SetColorModulation(pColorGun.r,pColorGun.g,pColorGun.b);
					eDrawModel(pGetActiveWeapon(v));
				end
				
								
				render.SetColorModulation(pColor.r,pColor.g,pColor.b);
				render.MaterialOverride(chamsmat2);
				render.SetBlend(1);
								
				eDrawModel(v);
				
				if (eIsValid(pGetActiveWeapon(v))) then
					render.SetColorModulation(pColorGun.r,pColorGun.g,pColorGun.b);
					eDrawModel(pGetActiveWeapon(v));
				end
				render.SetColorModulation(1, 1, 1);
	
			cam.End3D();
		end
	end
	
	
	local BHOP = function(userCmd)
		if ( !me:IsTyping() && !eIsOnGround(me) && !me:IsFlagSet(FL_PARTIALGROUND) ) then
			userCmd:RemoveKey( 2 );
			if(DreamBot.Config["Misc"]["Bhop"]) then
				local mouseX = cGetMouseX(userCmd);
				if ( mouseX < 0 ) then
					cSetSideMove(userCmd, -10^4 );
				elseif ( mouseX > 0 ) then
					cSetSideMove(userCmd, 10^4 );
				end
			end
		end
	end
	
	
/*
	Dream.Bot
		Menu / Drawing
*/
	
	function DrawFilledCircle(x, y, radius, quality)
		local circle = {}
		local tmp = 0
		for i = 1, quality do
			tmp = math.rad(i * 360) / quality 
			circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
		end
		surface.DrawPoly(circle)
	end

	local radarX, radarY, radarWidth, radarHeight = 50, ScrH() - 963 + 25, 215, 180 - 25
	DreamBot.F["draw"].DrawBigShit = function()
		draw.WordBox(1, 15,15," Dream.Bot v" .. DreamBot.Config.version .. " ", "BudgetLabel", Color(52, 73, 94, 180), Color(255,255,255))
		// Ahack Paste inbound
		if(DreamBot.Config["esp"]["Radar"]) then
			draw.RoundedBox(1,15,34,300,180,Color(52, 73, 94, 120)) // Background
			draw.RoundedBox(1,15,34,300,25,Color(52, 73, 94, 120)) // Tab Background
			draw.DrawText("Radar", "BudgetLabel", 25,40,Color(255,255,255))
			
			draw.RoundedBox(1,300 / 2 + 15   / 2, 180 / 2 + 34 / 2 + 25 ,5,5,Color(255,255,255))
		
			for k,v in next, player.GetAll() do
				if (eHealth(v) > 0) then
					local myPos = me:GetPos()
					local theirPos = v:GetPos()
					local myAngles = ifCOND(DreamBot.Config["Aimbot"]["SilentAim"],ms,me:EyeAngles())
					local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / 40)
					local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / 40)
					
					local myRotation = myAngles.y - 90
					myRotation = math.rad(myRotation)
					theirX = theirX - (radarX + (radarWidth / 2))
					theirY = theirY - (radarY + (radarHeight / 2))
					local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
					local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
					newX = newX + (radarX + (radarWidth / 2))
					newY = newY + (radarY + (radarHeight / 2))
					if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
						draw.RoundedBox(1,newX, newY,5,5,(pTeam(v) == pTeam(me) and Color(0,255,0) or Color(255,0,0)))
					end
				end
			end
		end
		
	end
	
	local SkeletonESP = function(v,h1,h2,colorsa)
		local origin = eGetPos(v);
				local parent = eGetBoneParent(v,eGetHitBoxBone(v,h1, h2));
				local bonepos, parentpos = eGetBonePosition(v,eGetHitBoxBone(v,h1, h2)), eGetBonePosition(v,parent);
				if(!parent || !bonepos || !parentpos || bonepos == origin) then return; end
				local bs, ps = vToScreen(bonepos), vToScreen(parentpos)
				surface.SetDrawColor(colorsa.r,colorsa.g,colorsa.b);
				local obbmin,obbmax = eGetHitBoxBounds(v,h1, h2); 	
				surface.DrawOutlinedRect(bs.x, bs.y, 10, 10);
	end
	
	local Get2DBounds = function(v)
		local eye = v:EyeAngles();
		local min,max = v:OBBMins(),v:OBBMaxs()
		local corners =
		{
			Vector(min.x,min.y,min.z),
			Vector(min.x,min.y,max.z),
			Vector(min.x,max.y,min.z),
			Vector(min.x,max.y,max.z),
			Vector(max.x,min.y,min.z),
			Vector(max.x,min.y,max.z),
			Vector(max.x,max.y,min.z),
			Vector(max.x,max.y,max.z)
		};
	
		local minx,miny,maxx,maxy = math.huge, math.huge, -math.huge, -math.huge;
	
		for _, corner in next, corners do
			local screen = v:LocalToWorld(corner):ToScreen();
			minx,miny = math.min(minx,screen.x),math.min(miny,screen.y);
			maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y);
		end
		return minx,miny,maxx,maxy;
	end

	// Did not make alot of this, kng.rektor helped make it
	local drawPlayer = function(v,Col)
		if (v == me || eIsDormant(v) || eHealth(v) < 1 || !DreamBot.Config["esp"]["on"] ) then return; end
	
		local min, max = v:OBBMins(), v:OBBMaxs();
        local eye = v:EyeAngles();
        local textespy = -2;
        local hax = -6;
        local hay = 4;
        local wmin, wmax = v:LocalToWorld(min), v:LocalToWorld(max);
        local origin = v:GetPos();
        local x1,y1,x2,y2 = Get2DBounds(v);
        local diff = math.abs(x2 - x1);
        local diff2 = math.abs(y2 - y1);
        local color = (DreamBot.Config["esp"]["rainbow"] and HSVToColor(RealTime()*160%360,1,1) or Col);
		local boxang = v:GetAngles();
		if(DreamBot.Config["esp"]["type"] == 0) then
		// 2D
		  if(DreamBot.Config["esp"]["names"]) then
			draw.DrawText( pNick(v) .. "\nRank: " .. v:GetUserGroup() .. "\nPing: " .. v:Ping() .. "ms\n", "BudgetLabel",
			x2 + 5,y1,
			Color(255,255,255), TEXT_ALIGN_LEFT )
		  end
		  surface.SetDrawColor(color)
          surface.DrawLine(x1,y1,x1+(diff*0.225),y1)
          surface.DrawLine(x1,y1,x1,y1+(diff2*0.225))
          surface.DrawLine(x1,y2,x1+(diff*0.225),y2)
          surface.DrawLine(x1,y2,x1,y2-(diff2*0.225))
          surface.DrawLine(x2,y1,x2-(diff*0.225),y1)
          surface.DrawLine(x2,y1,x2,y1+(diff2*0.225))
          surface.DrawLine(x2,y2,x2-(diff*0.225),y2)
          surface.DrawLine(x2,y2,x2,y2-(diff2*0.225))
		  surface.SetDrawColor(color)
          surface.DrawLine(x1+1,y1+1,x1+(diff*0.225),y1+1)
          surface.DrawLine(x1+1,y1+1,x1+1,y1+(diff2*0.225))
          surface.DrawLine(x1+1,y2-1,x1+(diff*0.225),y2-1)
          surface.DrawLine(x1+1,y2-1,x1+1,y2-(diff2*0.225))
          surface.DrawLine(x2-1,y1+1,x2-(diff*0.225),y1+1)
          surface.DrawLine(x2-1,y1+1,x2-1,y1+(diff2*0.225))
          surface.DrawLine(x2-1,y2-1,x2-(diff*0.225),y2-1)
		else if(DreamBot.Config["esp"]["type"] == 1) then
		// 3D
			cam.Start3D()
			local corners =
			{
					Vector(min.x,min.y,min.z),
					Vector(min.x,min.y,max.z),
					Vector(min.x,max.y,min.z),
					Vector(min.x,max.y,max.z),
					Vector(max.x,min.y,min.z),
					Vector(max.x,min.y,max.z),
					Vector(max.x,max.y,min.z),
					Vector(max.x,max.y,max.z)
			};
			
			for __, _corner in next, corners do
					local swag = Vector(0,0,0);
					local magic = Vector(max.x*0.45, max.y*0.45, max.z*0.45);
				
					if (_corner.x == min.x) then
							swag.x = magic.x;
					else
							swag.x = -magic.x;
					end
				
					if (_corner.y == min.y) then
							swag.y = magic.y;
					else
							swag.y = -magic.y;
					end
				
					if (_corner.z == min.z) then
							swag.z = magic.z;
					else
							swag.z = -magic.z;
					end
				
					if (v:IsPlayer() || v:IsNPC()) then
							cornerx = _corner + Vector(swag.x,0,0);
							cornery = _corner + Vector(0,swag.y,0);
							cornerz = _corner + Vector(0,0,swag.z);
							_corner:Rotate(boxang);
							cornerx:Rotate(boxang);
							cornery:Rotate(boxang);
							cornerz:Rotate(boxang);
					else
							cornerx = Vector(swag.x,0,0);
							cornery = Vector(0,swag.y,0);
							cornerz = Vector(0,0,swag.z);
							cornerx = cornerx + _corner;
							cornery = cornery + _corner;
							cornerz = cornerz + _corner;
					end
					

				
					render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornerx), color)
					render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornery), color)
					render.DrawLine(v:LocalToWorld(_corner), v:LocalToWorld(cornerz), color)
			end
			cam.End3D()
		end
		end
end
	
	DreamBot.F["draw"].drawESP = function()
		if(!DreamBot.Config["esp"]["on"]) then return; end
		
		for k,v in pairs(player.GetAll()) do
			if(v == me || eHealth(v) < 1 || eIsDormant(v)) then continue; end		
			DreamBot.T.PlayerTPos = eGetPos(v);
			DreamBot.T.PlayerTPosEText = (DreamBot.T.PlayerTPos):ToScreen();
			DreamBot.T.PlayerTAngles = v:GetAngles();
			DreamBot.T.PlayerTOBBMins = eOBBMins(v);
			DreamBot.T.PlayerTOBBMaxs = eOBBMaxs(v);
			
		//	render.DrawBox(DreamBot.T.PlayerTPos, Angle(0,DreamBot.T.PlayerTAngles.y,0), DreamBot.T.PlayerTOBBMins, Vector(20,DreamBot.T.PlayerTOBBMaxs.y,DreamBot.T.PlayerTOBBMaxs.z), ifCOND(pTeam(v) != pTeam(me), Color(255,0,0), Color(0,255,0)), false)
			//render.DrawWireframeBox(DreamBot.T.PlayerTPos, Angle(0,DreamBot.T.PlayerTAngles.y,0), DreamBot.T.PlayerTOBBMins, Vector(20,DreamBot.T.PlayerTOBBMaxs.y,DreamBot.T.PlayerTOBBMaxs.z), ifCOND(pTeam(v) != pTeam(me), Color(255,0,0), Color(0,255,0)), false)
		
		end 
	
	end
	
	
	DreamBot.F["draw"].notfication = function(Text, NotifType,timetodest)
		local notID = math.Round(RealTime()*120%360);
		DreamBot.F["draw"].menuHandle["not" .. notID] = vgui.Create("DFrame");
		DreamBot.F["draw"].menuHandle["not" .. notID]:SetPos(ScrW() / 2 - 250 ,ScrH() / 2 - 228);
		DreamBot.F["draw"].menuHandle["not" .. notID]:SetSize(500,25);
		DreamBot.F["draw"].menuHandle["not" .. notID]:SlideDown(0.3);
		DreamBot.F["draw"].menuHandle["not" .. notID]:SetTitle("");
		DreamBot.F["draw"].menuHandle["not" .. notID]:ShowCloseButton(false);
		DreamBot.F["draw"].menuHandle["not" .. notID]:SetDraggable(false);
		DreamBot.F["draw"].menuHandle["not" .. notID].Paint = function(s, w, h) 
		
			//draw.RoundedBox(2,0,0,w,h,NotifType)
			
			draw.RoundedBox(1,0,0,w,25,Color(40,40,40,255))
			draw.DrawText(Text, "MenuTitle", 5, 12 / 2, Color(255,255,255), TEXT_ALIGN_LEFT)
			surface.SetDrawColor( DreamBot.F["draw"].color )
			surface.DrawOutlinedRect( 0, 0, w,h )
		end
		
		timer.Simple(timetodest, function()
			if(DreamBot.F["draw"].menuHandle["not" .. notID]) then
				DreamBot.F["draw"].menuHandle["not" .. notID]:SlideUp(0.3);
				timer.Simple(0.3, function()
					DreamBot.F["draw"].menuHandle["not" .. notID]:Close();
				end)
			end
		end )
	end
	
	// Welcome Shit
	DreamBot.F["draw"].notfication("Dream.Bot " .. DreamBot.Config.version .. " Successfully Loaded","!",2 )

	
	DreamBot.F["draw"].CurCatMenu = "Aimbot"; 
	DreamBot.F["draw"].MenuOpen = function()
			DreamBot.T["menu"].open = true;
			
			
		DreamBot.F["draw"].options = 
		{
		
			["Configs"] = 
			{
				{name = "Here, you can manage your configuration settings for Dream.bot", cType = "text"},
				{name = "Create A New Config", cType = "button", returnFunc = function() 
				
				// Configuration Shit
					Derma_StringRequest(
					"Enter Save Name",
					"Enter the Save name",
					"default",
					function( text ) 
					JSONSave(DreamBot.Config,text); 
					
					if(DreamBot.F["draw"].menuHandle.main) then 
						DreamBot.F["draw"].menuHandle.main:Close();
					end
					DreamBot.F["draw"].MenuOpen();
					
					end,
					function( text ) end)
					//JSONLoad("test");
				
				end},
				{name = "Your Saved Configuration Files:", cType = "text"},
			},
			
			["Aimbot"] = 
			{
				{name = "Aimbot Configuration Menu", cType = "text"},
				{name = "Aimbot", cType = "toggle", checked = DreamBot.Config["Aimbot"]["on"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["on"] = ID; end},
				{name = "Rage-Mode", cType = "toggle", checked = DreamBot.Config["Aimbot"]["ragemode"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["ragemode"] = ID; end},
				{name = "No-Spread", cType = "toggle", checked = DreamBot.Config["Aimbot"]["No-Spread"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["No-Spread"] = ID; end},
				{name = "No-Recoil (buggy)", cType = "toggle", checked = DreamBot.Config["Aimbot"]["No-Recoil"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["No-Recoil"] = ID; end},
				{name = "Hitbox-Based", cType = "toggle", checked = DreamBot.Config["Aimbot"]["useHitboxes"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["useHitboxes"] = ID; end},
				{name = "Silent-Aim", cType = "toggle", checked = DreamBot.Config["Aimbot"]["SilentAim"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["SilentAim"] = ID; end},
				{name = "pSilent-Aim", cType = "toggle", checked = DreamBot.Config["Aimbot"]["pSilentAim"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["pSilentAim"] = ID; end},
				{name = "Target-Friends", cType = "toggle", checked = DreamBot.Config["Aimbot"]["targetfriends"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["targetfriends"] = ID; end},
				{name = "Target-Team", cType = "toggle", checked = DreamBot.Config["Aimbot"]["targetteam"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["targetteam"] = ID; end},
				{name = "Ghost-Check", cType = "toggle", checked = DreamBot.Config["Aimbot"]["GhostCheck"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["GhostCheck"] = ID; end},
				{name = "Auto-Wall", cType = "toggle", checked = DreamBot.Config["Aimbot"]["AutoWall"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["AutoWall"] = ID; end},
				{name = "Only Target-Team", cType = "toggle", checked = DreamBot.Config["Aimbot"]["onlytargetteam"], returnFunc = function(ID) DreamBot.Config["Aimbot"]["onlytargetteam"] = ID; end},
			},
			
			["HVH"] =
			{
				{name = "Hack VS Hack Configuration Menu", cType = "text"},
				{name = "Anti-Anti-Aim", cType = "toggle", checked = DreamBot.Config["hvh"]["AAA"], returnFunc = function(ID) DreamBot.Config["hvh"]["AAA"] = ID; PA4.AAAX(DreamBot.Config["hvh"]["AAA"]);PA4.AAAY(DreamBot.Config["hvh"]["AAA"]); end},
				{name = "Fake-Lag", cType = "toggle", checked = DreamBot.Config["hvh"]["FakeLag"], returnFunc = function(ID) DreamBot.Config["hvh"]["FakeLag"] = ID; PA4.FAKELAG(DreamBot.Config["hvh"]["FakeLag"]); end},
				{name = "Fake-Lag Prediction", cType = "toggle", checked = DreamBot.Config["hvh"]["FakeLagPred"], returnFunc = function(ID) DreamBot.Config["hvh"]["FakeLagPred"] = ID; PA4.FAKELAG(DreamBot.Config["hvh"]["FakeLag"]); end},
				{name = "Anti-Aim", cType = "toggle", checked = DreamBot.Config["hvh"]["AA"], returnFunc = function(ID) DreamBot.Config["hvh"]["AA"] = ID; end},
				{name = "Anti-Aim Type", cType = "text"},
				{name = "Anti-Aim Type", cType = "slider", dvalue = DreamBot.Config["hvh"]["AA_TYPE"], min = 1, max = 6, returnFunc = function(ID) DreamBot.Config["hvh"]["AA_TYPE"] = ID end},
				{name = "", cType = "text"},
				{name = "Used too fake angles", cType = "text"},
				{name = "Anti-Aim Chew", cType = "slider", dvalue = DreamBot.Config["hvh"]["AA_CHEW"], min = 1, max = 3, returnFunc = function(ID) DreamBot.Config["hvh"]["AA_CHEW"] = ID end},
				{name = "", cType = "text"},
				//{name = "Anti-Aim Pitch", cType = "slider", dvalue = DreamBot.Config["hvh"]["AA_TEST_P"], min = 1, max = 1800, returnFunc = function(ID) DreamBot.Config["hvh"]["AA_TEST_P"] = ID end},
			},
			
			["Visuals"] = 
			{
				{name = "Visual Configuration Menu", cType = "text"},
				{name = "Radar", cType = "toggle", checked = DreamBot.Config["esp"]["Radar"], returnFunc = function(ID) DreamBot.Config["esp"]["Radar"] = ID; end},
				{name = "Player Chams", cType = "toggle", checked = DreamBot.Config["esp"]["chams"], returnFunc = function(ID) DreamBot.Config["esp"]["chams"] = ID; end},
				{name = "Player ESP", cType = "toggle", checked = DreamBot.Config["esp"]["on"], returnFunc = function(ID) DreamBot.Config["esp"]["on"] = ID; end},
				{name = "Player ESP Rainbow", cType = "toggle", checked = DreamBot.Config["esp"]["rainbow"], returnFunc = function(ID) DreamBot.Config["esp"]["rainbow"] = ID; end},
				{name = "Player ESP Type", cType = "text"},
				{name = "Player ESP Type", cType = "slider", dvalue = DreamBot.Config["esp"]["type"], min = 0, max = 1, returnFunc = function(ID) DreamBot.Config["esp"]["type"] = ID end},
				{name = "", cType = "text"},
				{name = "Player Head Box", cType = "toggle", checked = DreamBot.Config["esp"]["headbox"], returnFunc = function(ID) DreamBot.Config["esp"]["headbox"] = ID; end},
				{name = "Player ESP Names", cType = "toggle", checked = DreamBot.Config["esp"]["names"], returnFunc = function(ID) DreamBot.Config["esp"]["names"] = ID; end},
				{name = "Wire-Frame guns", cType = "toggle", checked = DreamBot.Config["Misc"]["WireFrame"], returnFunc = function(ID) DreamBot.Config["Misc"]["WireFrame"] = ID; end},
				{name = "Custom FOV", cType = "toggle", checked = DreamBot.Config["Misc"]["FOV"], returnFunc = function(ID) DreamBot.Config["Misc"]["FOV"] = ID; end},
				{name = "Third Person", cType = "toggle", checked = DreamBot.Config["Misc"]["ThirdPerson"], returnFunc = function(ID) DreamBot.Config["Misc"]["ThirdPerson"] = ID; end},
			},
			
			["Misc"] = 
			{
				{name = "Misc Configuration Menu", cType = "text"},
				{name = "Auto Strafe", cType = "toggle", checked = DreamBot.Config["Misc"]["Bhop"], returnFunc = function(ID) DreamBot.Config["Misc"]["Bhop"] = ID; end},
				{name = "Cocaine", cType = "toggle", checked = DreamBot.Config["Misc"]["SpeedHack"], returnFunc = function(ID) DreamBot.Config["Misc"]["SpeedHack"] = ID; end},
				{name = "Steal Names", cType = "toggle", checked = DreamBot.Config["Misc"]["StealNames"], returnFunc = function(ID) DreamBot.Config["Misc"]["StealNames"] = ID; end},
				{name = "ChatSpam", cType = "toggle", checked = DreamBot.Config["Misc"]["SpamChat"], returnFunc = function(ID) DreamBot.Config["Misc"]["SpamChat"] = ID; end},
			},
			
		}
		
		
		local saveFiles,thisvalueisbad = file.Find( "dreambot_config/*", "DATA" );
		for optN,GetCurConfig in next, saveFiles do
			local stringFileName = string.Replace(saveFiles[optN], ".txt","");
			DreamBot.F["draw"].options["Configs"][#DreamBot.F["draw"].options["Configs"] + 1] = {
			name = stringFileName,
			cType = "button",
			returnFunc = function() 
				JSONLoad(stringFileName);
				
				if(DreamBot.F["draw"].menuHandle.main) then 
					DreamBot.F["draw"].menuHandle.main:Close();
				end
				DreamBot.F["draw"].MenuOpen();
			end}
			
			//table.Add(DreamBot.F["draw"].options["Config Settings"], tblToInsert);
		end
			
			DreamBot.F["draw"].menuHandle.main = vgui.Create("DFrame");
			DreamBot.F["draw"].menuHandle.main:SetPos(ScrW() / 2 - 250 ,ScrH() / 2 - 200);
			DreamBot.F["draw"].menuHandle.main:SetSize(500,400);
			DreamBot.F["draw"].menuHandle.main:SlideDown(0.3);
			DreamBot.F["draw"].menuHandle.main:SetTitle("");
			DreamBot.F["draw"].menuHandle.main:ShowCloseButton(false);
			DreamBot.F["draw"].menuHandle.main:SetDraggable(false);
			DreamBot.F["draw"].menuHandle.main:MakePopup();
			DreamBot.F["draw"].menuHandle.main.Paint = function(s, w, h) 
				draw.RoundedBox(2,0,0,w,h,Color(44, 62, 80,180))
				draw.DrawText("Dream.Bot Version " .. DreamBot.Config.version .. ", Nigger Client 4.20v" , "MenuTitle", 
				w - RealTime()*125%1200, h - 20, Color(255,255,255), TEXT_ALIGN_LEFT)
				draw.RoundedBox(2,0,0,w,25,DreamBot.F["draw"].color)
				draw.DrawText("Dream.Bot Version " .. DreamBot.Config.version, "MenuTitle", 5, 12 / 2, Color(255,255,255), TEXT_ALIGN_LEFT)
				surface.SetDrawColor( DreamBot.F["draw"].color )
				surface.DrawOutlinedRect( 0, 0, w,h )
			end
			
			timer.Simple(0.31, function()
			
			DreamBot.F["draw"].menuHandle.closeButton = vgui.Create("DButton",DreamBot.F["draw"].menuHandle.main);
			DreamBot.F["draw"].menuHandle.closeButton:SetPos(DreamBot.F["draw"].menuHandle.main:GetWide() - 45,0);
			DreamBot.F["draw"].menuHandle.closeButton:SetSize(45,25);
			DreamBot.F["draw"].menuHandle.closeButton:SlideDown(0.3);
			DreamBot.F["draw"].menuHandle.closeButton:SetText("X");
			DreamBot.F["draw"].menuHandle.closeButton.DoClick = function() DreamBot.F["draw"].menuHandle.main:SizeTo(DreamBot.F["draw"].menuHandle.main:GetWide(),0,.3,0,.3); timer.Simple(0.3,function() DreamBot.F["draw"].menuHandle.main:Close(); DreamBot.T["menu"].open = false; end) end
			DreamBot.F["draw"].menuHandle.closeButton.Paint = function(s, w, h) 
				if(DreamBot.F["draw"].menuHandle.closeButton:IsHovered()) then
					draw.RoundedBox(1,0,0,w -1 ,h,Color(231, 76, 60,255))
				else
					draw.RoundedBox(1,0,0,w - 1 ,h,Color(255, 76, 60,220))
				end
			end
			
				DreamBot.T.CatPos = {5,30}
				DreamBot.T.Pos = {90,30}
				for k,l in pairs(DreamBot.F["draw"].options) do
						DreamBot.F["draw"].menuHandle[k .. "cat"] = vgui.Create("DButton",DreamBot.F["draw"].menuHandle.main);
						DreamBot.F["draw"].menuHandle[k .. "cat"]:SetPos(DreamBot.T.CatPos[1],DreamBot.T.CatPos[2]);
						DreamBot.F["draw"].menuHandle[k .. "cat"]:SetSize(75,30);
						DreamBot.F["draw"].menuHandle[k .. "cat"]:SlideDown(0.3);
						DreamBot.F["draw"].menuHandle[k .. "cat"]:SetColor(Color(255,255,255));
						DreamBot.F["draw"].menuHandle[k .. "cat"]:SetText(k);
						DreamBot.F["draw"].menuHandle[k .. "cat"].DoClick = function()
							DreamBot.F["draw"].CurCatMenu = k;
							if(DreamBot.F["draw"].menuHandle.main) then 
								DreamBot.F["draw"].menuHandle.main:Close();
							end
							DreamBot.F["draw"].MenuOpen();
							
						end
						DreamBot.F["draw"].menuHandle[k .. "cat"].Paint = function(s, w, h) 
							draw.RoundedBox(1,0,0,w,h,DreamBot.F["draw"].color)
							if(k == DreamBot.F["draw"].CurCatMenu) then
								draw.RoundedBox(1,0,0,w,h *.15,Color(DreamBot.F["draw"].color.r + 10, DreamBot.F["draw"].color.g + 10, DreamBot.F["draw"].color.b + 10));
							end
						end
						DreamBot.T.CatPos[2] = DreamBot.T.CatPos[2] + 35;
				end
				
					for m,v in pairs(DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu]) do
						if(v.cType == "toggle") then
							DreamBot.F["draw"].menuHandle[v.name .. "c"] = vgui.Create("DButton",DreamBot.F["draw"].menuHandle.main);
							DreamBot.F["draw"].menuHandle[v.name .. "c"]:SetPos(DreamBot.T.Pos[1],DreamBot.T.Pos[2]);
							DreamBot.F["draw"].menuHandle[v.name .. "c"]:SetSize(20,20);
							DreamBot.F["draw"].menuHandle[v.name .. "c"]:SlideDown(0.3);
							DreamBot.F["draw"].menuHandle[v.name .. "c"]:SetText("");
							DreamBot.F["draw"].menuHandle[v.name .. "c"].DoClick = function() 
								DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu][m].checked = !DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu][m].checked;
								DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu][m].returnFunc(DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu][m].checked);
								DreamBot.F["draw"].notfication(v.name .. " Toggled: " .. tostring(DreamBot.F["draw"].options[DreamBot.F["draw"].CurCatMenu][m].checked) ,Color(44, 62, 80,180),2);
								DreamBot.F["draw"].menuHandle[v.name .. "c"]:SetAlpha(0);
								DreamBot.F["draw"].menuHandle[v.name .. "c"]:AlphaTo(255,.3);
							end
							DreamBot.F["draw"].menuHandle[v.name .. "c"].Paint = function(s, w, h) 
								if(!v.checked) then 
									draw.RoundedBox(1,0,0,w,h,Color(40,40,40,255))
								else
									draw.RoundedBox(1,0,0,w,h,DreamBot.F["draw"].color)
									draw.RoundedBox(1,0,0,w,h *.25,Color(DreamBot.F["draw"].color.r + 10, DreamBot.F["draw"].color.g + 10, DreamBot.F["draw"].color.b + 10));
								end
								
								surface.SetDrawColor( ifCOND(!v.checked, DreamBot.F["draw"].color, Color(40,40,40)) )
								surface.DrawOutlinedRect( 0, 0, w,h )
								
								//draw.DrawText("Test", "BudgetLabel", DreamBot.T.Pos[1] + 30,DreamBot.T.Pos[2])
							end
							
							DreamBot.F["draw"].menuHandle[v.name] = vgui.Create("DLabel",DreamBot.F["draw"].menuHandle.main);
							DreamBot.F["draw"].menuHandle[v.name]:SetPos(DreamBot.T.Pos[1] + 25,DreamBot.T.Pos[2] + 2.5);
							DreamBot.F["draw"].menuHandle[v.name]:SetText(v.name);
							DreamBot.F["draw"].menuHandle[v.name]:SetAlpha(0);
							DreamBot.F["draw"].menuHandle[v.name]:AlphaTo(255,.3);
							DreamBot.F["draw"].menuHandle[v.name]:SizeToContents();
							DreamBot.F["draw"].menuHandle[v.name]:SlideDown(0.3);
							
						if(DreamBot.T.Pos[2] > 350) then
							DreamBot.T.Pos[1] = DreamBot.T.Pos[1] + 140;
							DreamBot.T.Pos[2] = 30;
						else
							DreamBot.T.Pos[2] = DreamBot.T.Pos[2] + 25;
						end
							
						else if(v.cType == "text") then
						
							DreamBot.F["draw"].menuHandle[v.name .. "_text"] = vgui.Create("DLabel",DreamBot.F["draw"].menuHandle.main);
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:SetPos(DreamBot.T.Pos[1],DreamBot.T.Pos[2]);
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:SetText(v.name);
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:SetAlpha(0);
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:AlphaTo(255,.3);
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:SizeToContents();
							DreamBot.F["draw"].menuHandle[v.name .. "_text"]:SlideDown(0.3);
						
						if(DreamBot.T.Pos[2] > 350) then
							DreamBot.T.Pos[1] = DreamBot.T.Pos[1] + 140;
							DreamBot.T.Pos[2] = 30;
						else
							DreamBot.T.Pos[2] = DreamBot.T.Pos[2] + 20; 
						end
						
						else if(v.cType == "slider") then
						
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"] = vgui.Create( "DNumSlider",DreamBot.F["draw"].menuHandle.main )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetPos( DreamBot.T.Pos[1] - 52,DreamBot.T.Pos[2] - 5 )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetWide( 150 )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetMin( v.min )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetMax( v.max )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetValue( v.dvalue )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"]:SetDecimals( 0 )
						DreamBot.F["draw"].menuHandle[v.name .. "_slider"].OnValueChanged = function(p,va)
							v.returnFunc(math.Round(va));
						end
	
						
						if(DreamBot.T.Pos[2] > 350) then
							DreamBot.T.Pos[1] = DreamBot.T.Pos[1] + 140;
							DreamBot.T.Pos[2] = 30;
						else
							DreamBot.T.Pos[2] = DreamBot.T.Pos[2] + 15; 
						end					
						else if(v.cType == "button") then
						
						DreamBot.F["draw"].menuHandle[v.name .. "_button"] = vgui.Create( "DButton",DreamBot.F["draw"].menuHandle.main )
						DreamBot.F["draw"].menuHandle[v.name .. "_button"]:SetText(v.name);
						DreamBot.F["draw"].menuHandle[v.name .. "_button"]:SetPos( DreamBot.T.Pos[1],DreamBot.T.Pos[2] )
						DreamBot.F["draw"].menuHandle[v.name .. "_button"]:SetSize( 125,25 )
						DreamBot.F["draw"].menuHandle[v.name .. "_button"].DoClick = function()
							DreamBot.F["draw"].menuHandle[v.name .. "_button"]:SetAlpha(0);
							DreamBot.F["draw"].menuHandle[v.name .. "_button"]:AlphaTo(255,.3);
							v.returnFunc();
						end
						
						DreamBot.F["draw"].menuHandle[v.name .. "_button"].Paint = function(s, w, h) 
								if(!v.checked) then 
									draw.RoundedBox(1,0,0,w,h,Color(40,40,40,255))
								else
									draw.RoundedBox(1,0,0,w,h,DreamBot.F["draw"].color)
									draw.RoundedBox(1,0,0,w,h *.25,Color(DreamBot.F["draw"].color.r + 10, DreamBot.F["draw"].color.g + 10, DreamBot.F["draw"].color.b + 10));
								end
								
								surface.SetDrawColor( ifCOND(!v.checked, DreamBot.F["draw"].color, Color(40,40,40)) )
								surface.DrawOutlinedRect( 0, 0, w,h )
								
								//draw.DrawText("Test", "BudgetLabel", DreamBot.T.Pos[1] + 30,DreamBot.T.Pos[2])
							end
	
						
						if(DreamBot.T.Pos[2] > 325) then
							DreamBot.T.Pos[1] = DreamBot.T.Pos[1] + 140;
							DreamBot.T.Pos[2] = 50;
						else
							DreamBot.T.Pos[2] = DreamBot.T.Pos[2] + 30; 
						end					
						
						end
						end
						end
						end
					
						
						
					end
			
			end)
			
		end

/*
	Dream.Bot
		Hijack Hooks
*/	
	oCreateMove = oCreateMove or GAMEMODE.CreateMove;
	function GAMEMODE:CreateMove(cmd)
		//eTickInt = engine.TickInterval() * (math.max(GetConVar("cl_interp"):GetFloat(), GetConVar("cl_interp_ratio"):GetFloat() / GetConVar("cl_interp_ratio"):GetFloat()));
		BHOP(cmd);
		aimbotMainHook(cmd);
		SpeedHack();
		RecoilFix();
		StealNames();
		ChatSpam();
		oCreateMove(cmd);
	end
	
	oThink = oThink or GAMEMODE.Think;
	GAMEMODE["Think"] = function()
		if(input.IsKeyDown(KEY_INSERT) && !DreamBot.T["menu"].open) then
			DreamBot.F["draw"].MenuOpen();
		end
		oThink();
	end
	
	hook.Add("CalcView", "Calc_DreambotView", function(me,origin,angles)
		glob_origin = origin;
        local view = {}
		view.angles = ifCOND(DreamBot.Config["Aimbot"]["SilentAim"],ms,angles);
        view.vm_angles = ifCOND(DreamBot.Config["Aimbot"]["SilentAim"],ms,angles);
		view.origin = ifCOND(DreamBot.Config["Misc"]["ThirdPerson"],origin-( aForward(ms)*125 ),origin);
		view.fov = 100;
        return view;
	end)
	local wireframeMat = Material("models/wireframe");
	GAMEMODE["PreDrawViewModel"] = function() if(!DreamBot.Config["Misc"]["WireFrame"]) then return; end render.MaterialOverride(wireframeMat); render.SetColorModulation(0, 0, 0); end
	GAMEMODE["Move"] =	GetCurTime;
	GAMEMODE["RenderScreenspaceEffects"] = ChamsDud;
	GAMEMODE["ShouldDrawLocalPlayer"] = function() return DreamBot.Config["Misc"]["ThirdPerson"]; end
	GAMEMODE["GetViewModelPosition"] = function(pos,ang) return glob_origin, ifCOND(DreamBot.Config["Aimbot"]["SilentAim"],ms,angles); end	
	GAMEMODE["CalcViewModelView"] = function(wep, vm, oldPos, oldAng, pos, ang) return glob_origin, ifCOND(DreamBot.Config["Aimbot"]["SilentAim"],ms,angles); end	
	
	
	oHudPaint = oHudPaint or GAMEMODE.HUDPaint;
	GAMEMODE["HUDPaint"] = function(self)
		DreamBot.F["draw"].DrawBigShit();
		for k,v in next, player.GetAll() do
			drawPlayer(v,(pTeam(v) == pTeam(me) and Color(0,255,0) or Color(255,0,0)));
		end
		//if(eHealth(me) < 1) then PA4.CHOKE_PACKETS(false); end
		//ChamsGun();
		oHudPaint(self);
	end