local IGNOREZ = true;

local color = Color( 255, 255, 0, 50 );

local that_other_color = Color( color.r, color.g, color.b, 255 );

local function DrawHitbox()
	cam.Start3D( EyePos(), EyeAngles() );
		for i, ent in pairs( ents.GetAll() ) do
			if( !ent ) then continue; end
			if( !IsValid( ent ) ) then continue; end
			if( ent == LocalPlayer() ) then continue; end
			if( !ent:IsPlayer() && !ent:IsNPC() ) then continue; end
			if( ( ent:IsPlayer() && !ent:Alive() ) || ( ent:IsNPC() && ent:GetMoveType() == 0 ) ) then continue; end
			for hitbox = 0, ent:GetHitBoxCount(0) do
				local bone = ent:GetHitBoxBone( hitbox, 0 );
				local bpos, bang = ent:GetBonePosition( bone );
				local min, max = ent:GetHitBoxBounds( hitbox, 0 );
				if( min == nil || max == nil ) then
					continue;
				end
				if( !IGNOREZ ) then
					render.SetColorMaterial();
				else
					render.SetColorMaterialIgnoreZ();
				end
				render.SetBlend( color.a / 255 );
				render.DrawBox( bpos, bang, min, max, color, !IGNOREZ );
				render.DrawWireframeBox( bpos, bang, min, max, that_other_color, !IGNOREZ );
			end
		end
	cam.End3D();
end

hook.Add( "RenderScreenspaceEffects", "Render", DrawHitbox );