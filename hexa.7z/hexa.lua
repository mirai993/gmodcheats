--[[

	[Hexa]

	A Garry's Mod Hack by ☂ Bloom ☁

	[Links]

	☂ Bloom ☁'s Steam Account: http://steamcommunity.com/id/blooomm/

	Hexa.nn.pe Steam Group: http://steamcommunity.com/groups/hexannpe

--]]

surface.PlaySound("HL1/fvox/bell.wav")
chat.AddText(Color(76, 175, 80), "Hexa loaded successfully!")
chat.AddText(Color(76, 175, 80), "Check console for more details.")
print("")
print("[Hexa]")
print("")
print("A Garry's Mod Hack by ☂ Bloom ☁")
print("")
print("[Links]")
print("")
print("☂ Bloom ☁'s Steam Account: http://steamcommunity.com/id/blooomm/")
print("")
print("Hexa.nn.pe Steam Group: http://steamcommunity.com/groups/hexannpe")

require("spreadthebutter");
require("dickwrap")
require("cvar3");
require("_cv3");
require("fhook");
require("stringtables");
require("aaa");

GetConVar("sv_allowcslua"):SetFlags(0)
GetConVar("sv_cheats"):SetFlags(0)
GetConVar("sv_allowcslua"):SetValue(1)
GetConVar("sv_cheats"):SetValue(1)

local type = type;
local next = next;
local function Copy(tt, lt)
	local copy = {}
	if lt then
		if type(tt) == "table" then
			for k,v in next, tt do
				copy[k] = Copy(k, v)
			end
		else
			copy = lt
		end
		return copy
	end
	if type(tt) != "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local G = table.Copy( _G )
local surface = Copy(surface);
local vgui = Copy(vgui);
local input = Copy(input);
local Color = Color;
local ScrW, ScrH = ScrW, ScrH;
local gui = Copy(gui);
local math = Copy(math);
local file = Copy(file);
local util = Copy(util);
local cones = {};
local pcall = pcall;
local require = require;
local nullvec = Vector() * -1;
local IsFirstTimePredicted = IsFirstTimePredicted;
local CurTime = CurTime;
local servertime = 0;
local bit = Copy(bit);
local FindMetaTable = FindMetaTable;
local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";
local cn = FindMetaTable"ConVar";
local im =  FindMetaTable"IMaterial";
local Vector = Vector;
local player = Copy(player);
local Angle = Angle;
local me = me;
local render = Copy(render);
local cma = Copy(cam);
local Material = Material;
local CreateMaterial = CreateMaterial;
local me = LocalPlayer();
local myName = me:Nick();
local _G = _G;
me:ConCommand("cl_interp 0.066; cl_interp_ratio 2; cl_updaterate 200; cl_cmdrate 200");
memesendpacket = true;

surface.CreateFont("hexa1", {
	font = "Console",
	size = 13,
	weight = 900,
	shadow = false,
	antialias = false,
});

surface.CreateFont("hexa2", {
	font = "Console",
	size = 13,
	weight = 900,
	shadow = false,
	antialias = false,
});

surface.CreateFont("MiscFont", {
	font = "HaxrCorp S8 Standard",
	size = 14,
	antialias = false,
	outline  = true,
})

surface.CreateFont("MenuFont", {
	font = "HaxrCorp S8 Standard",
	size = 16,
	antialias = false,
	outline  = true,
})

surface.CreateFont("ESPFont", {
	font = "HaxrCorp S8 Standard",
	size = 13,
	antialias = false,
	outline  = true,
})

surface.CreateFont("WATERMARK", {
	font = "Trebuchet",
	 size = 25,
	  weight = 550,
})

surface.CreateFont("WATERMARK3", {
	font = "Razer Regular", 
	size = 18, 
	weight = 550,
})


local paste			= table.Copy(_G) or {}
local _Hooks		= {}
local ply			= LocalPlayer()

function paste.ChatAlert(str)
	paste.surface.PlaySound("npc/scanner/combat_scan1.wav")
end

if (_G.QAC or _G.CAC) then
		print("!Cake anti-cheat was detected. Disconnecting to prevent being banned.")
		print("!Cake anti-cheat was detected. Disconnecting to prevent being banned.")
		print("!Cake anti-cheat was detected. Disconnecting to prevent being banned.")
		print("!Cake anti-cheat was detected. Disconnecting to prevent being banned.")
		ply:ConCommand("disconnect")
	return
end

function paste.AddHook(event_name, func)
	local name = paste.RandomString()
	hook.Add(event_name, name, func)
	if not (_Hooks[event_name]) then
		_Hooks[event_name] = {}
	end
	_Hooks[event_name][name] = func
end

function paste.RandomString()
	local len = paste.math.random(15, 30)
	local str = ""
	for i = 1, len do
		str = str .. paste.string.char(paste.math.random(32, 126))
	end
	return str
end

function debug.getinfo(indexkid)
    return
end
function _G.debug.getinfo(indexkid)
    return
end
_G.debug.getinfo = function(indexkid)
    return
end
debug.getinfo = function(indexkid)
    return
end

local badcmds = {
	"__ac",
	"__imacheater",
	"gm_possess",
	"achievementRefresh",
	"__uc_",
	"_____b__c",
	"___m",
	"sc",
	"bg",
	"bm",
	"kickme",
	"gw_iamacheater",
	"imafaggot",
	"birdcage_browse",
	"reportmod",
	"_fuckme",
	"st_openmenu",
	"_NOPENOPE",
	"__ping",
	"ar_check",
	"GForceRecoil",
	"~__ac_auth",
	"blade_client_check",
	"blade_client_detected_message",
	"disconnect",
	"exit",
	"retry",
	"kill",
	"-voicerecord",
	"+voicerecord",
	"dac_imcheating",
	"dac_pleasebanme",
	"_hz_perp_bans_2hz1",
	"rdm"
}
local old_rcc = RunConsoleCommand;
function RunConsoleCommand(cmd,...)
        if !table.HasValue(badcmds,cmd) then
            return old_rcc(cmd,...)
        else
            MsgC( Color(252, 0, 0), "[Hexa]:",  Color(255,255,255,255), " Blocked Malicious Concommand:"..cmd )
        return
    end
end

GAMEMODE["storedFuncs"] = GAMEMODE["storedFuncs"] || {};
GAMEMODE["addedHooks"] = GAMEMODE["addedHooks"] || {};
GAMEMODE["AddHook"] = function(self, type, name, func)
	self["addedHooks"][type] = self["addedHooks"][type] || {};
	self["addedHooks"][type][name] = func;
	self["storedFuncs"][type] = self["storedFuncs"][type] || function() end;
	self[type] = function(self, ...)
	self["storedFuncs"][type](self, ...);
	for k,v in next, self["addedHooks"][type] do
		local args = {v(...)};
		if(#args == 0) then continue; end
		return(unpack(args));
		end
	end
end

GAMEMODE["RemoveHook"] = function(self, type, name)
	if(!self["addedHooks"][type]) then return; end
	self["addedHooks"][type][name] = nil;
end

GAMEMODE["RemoveDetour"] = function(self, type)
	if(!self["storedFuncs"][type]) then return; end
	self[type] = self["storedFuncs"][type];
end

local options = {
	["Legitbot"] = {
		{
			{"----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------", 10, 20, 1080, 498, 220},
			{"Legitbot Coming Soon!", "Checkbox", false, 9999},
		},
	},
	["Ragebot"] = {
		{
			{"Aimbot", 10, 20, 220, 220, 130},
			{"Enable", "Checkbox", false, 20},
			{"Aim Key: Mouse3 Or ALT", "Checkbox", false, 20},
			{"Silent Aim", "Checkbox", false, 20},
			{"Perfect Silent Aim", "Checkbox", false, 20},
			{"Auto Fire", "Checkbox", false, 20},
			{"Auto Pistol", "Checkbox", false, 20},
			{"Auto Reload", "Checkbox", false, 20},
			{"Non-Sticky", "Checkbox", false, 20},
		},
		{
			{"Aim Options", 240, 20, 252, 270, 160},
			{"Priority", "Selection", "Random", {"Random", "Distance", "Health"}, 60 },
			{"Body Aim", "Checkbox", false, 0},
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
			{"Ignore Vehicles", "Checkbox", false, 0},
			{"Ignore Noclip", "Checkbox", false, 0},
			{"Ignore Spawn-Protected", "Checkbox", false, 0},
			{"Disable In Noclip", "Checkbox", false, 0},
		},
		{
			{"Anti-Aim", 502, 20, 350, 155, 182},
			{"Enable", "Checkbox", false, 0},
			{"X-Axis", "Selection", "Emotion", {"Emotion", "Up", "Down", "Fake-Down", "Jitter", "Fake-Angles"}, 80},
			{"Y-Axis", "Selection", "Emotion", {"Emotion", "Static", "Fake Straight", "Backwards", "Static Backwards", "Jitter", "Fake Backwards", "Fake Backwards-Jitter", "Sideways", "Opposite-Sideways", "Fake-Sideways", "Side Jitter", "Opposite-Side Jitter", "Side Switch", "Towards Players", "Slow Spin", "Fast Spin", "Jitter Spin", "Fake-Angles"}, 135},
			{"Max Y", "Slider", 0, 360, 100},
			{"Min Y", "Slider", 0, 360, 100},
		},
		{
			{"Extra", 10, 260, 190, 145, 140},
			{"Anti Recoil", "Checkbox", false, 0},
			{"Anti Spread", "Checkbox", false, 0},
			{"Snap Line", "Checkbox", false, 0},
			{"Bullet Time", "Checkbox", false, 0},
			{"Auto Wall", "Checkbox", false, 0},
		},
	},
	["Visuals"] = {
		{
			{"ESP", 10, 20, 222, 495, 140},
			{"Enable", "Checkbox", false, 0},
			{"Box", "Checkbox", false, 0},
			{"Box Type", "Selection", "2D Box", {"2D Box", "3D Box"}, 50},
			{"Name", "Checkbox", false, 0},
			{"Healthbar", "Checkbox", false, 0},
			{"Health Value", "Checkbox", false, 0},
			{"Weapon", "Checkbox", false, 0},
			{"Rank", "Checkbox", false, 0},
			{"Ping", "Checkbox", false, 0},
			{"Entities", "Checkbox", false, 0},
			{"DarkRP Money", "Checkbox", false, 0},
			{"Skeleton", "Checkbox", false, 0},
			{"Health Skeleton", "Checkbox", false, 0},
			{"XQZ", "Checkbox", false, 0},
			{"Chams", "Checkbox", false, 0},
			{"Team Colors", "Checkbox", false, 0},
			{"Transparent Chams", "Checkbox", false, 0},
			{"Hit Boxes", "Checkbox", false, 0},
			{"ASUS Walls", "Checkbox", false, 0},
		},
		{
			{"Viewmodel", 242, 20, 215, 155, 100},
			{"No Hands", "Checkbox", false, 0},
			{"Colored Wireframe", "Checkbox", false, 15},
			{"Red", "Slider", 76, 255, 80},
			{"Green", "Slider", 175, 255, 80},
			{"Blue", "Slider", 80, 255, 80},
		},
		{
			{"Filter", 468, 20, 255, 105, 130},
			{"Enemies Only", "Checkbox", false, 54},
			{"Distance", "Checkbox", false, 54},
			{"Max Distance", "Slider", 0, 5000, 88},
        },
		{
			{"Hud Paint", 735, 20, 335, 120, 220},
			{"Watermark", "Checkbox", false, 54},
			{"Rainbow Watermark", "Checkbox", false, 54},
			{"Crosshair", "Checkbox", false, 54},
			{"Crosshair Type", "Selection", "Box", {"Box", "Cross", "Square", "Circle", "Dot"}, 76},
		},
	},
	["Misc"] = {
		{
			{"Extra", 10, 20, 245, 495, 130},
			{"Auto Jump", "Checkbox", false, 0},
			{"Auto Strafe", "Checkbox", false, 0},
			{"Air Duck", "Checkbox", false, 0},
			{"Remove Sky", "Checkbox", false, 0},
			{"Fullbright", "Checkbox", false, 0},
			{"Rapid Fire", "Checkbox", false, 0},
			{"Flashlight Spam", "Checkbox", false, 0},
			{"Anti-AFK", "Checkbox", false, 0},
			{"Thirdperson", "Checkbox", false, 0},
			{"Thirdperson Distance", "Slider", 10, 100, 80},
			{"Show Radar", "Checkbox", false, 0},
			{"Show Spectators", "Checkbox", false, 0},
			{"Display Status", "Checkbox", false, 0},
			{"Show Mirror", "Checkbox", false, 0},
			{"Kill Spam", "Checkbox", false, 0},
			{"Kill Spam Type", "Selection", "Normal", {"Normal", "HvH"}, 80},
			{"Disconnect Spam", "Checkbox", false, 0},
			{"Traitor Finder", "Checkbox", false, 0},
			{"Murderer Finder", "Checkbox", false, 0},
		},
		{
			{"Chat", 265, 20, 245, 195, 130},
			{"Spam", "Checkbox", false, 0},
			{"Spam Type", "Selection", "Jokes", {"Jokes", "Insult", "ULX Message", "Advertise", "Killstreaks", "Spawn", "Taunts", "Money", "OOC"}, 82},
			{"Name Stealer", "Checkbox", false, 0},
			{"Steal Type", "Selection", "Normal", {"Normal", "DarkRP"}, 80},
			{"Copy Messages", "Checkbox", false, 0},
			{"Death Notify", "Checkbox", false, 0},
			{"'Shut up' As Response", "Checkbox", false, 0},
		},
		{
			{"Emotes", 520, 20, 245, 70, 140},
			{"Enable", "Checkbox", false, 0},
			{"Emote Type", "Selection", "Dance", {"Dance", "Sexy", "Wave", "Robot", "Bow", "Cheer", "Laugh", "Zombie", "Agree", "Disagree", "Forward", "Back", "Salute", "Wave", "Pose", "Halt", "Group"}, 70 },
		},
		{
			{"Change Log - Update 1.0", 468, 479, 550, 90, 130},
			{"• Birth of Hexa", "Checkbox", false, 9999},
			{"• ", "Checkbox", false, 9999},
			{"• ", "Checkbox", false, 9999},
		},
	},
	["Settings"] = {
		{
			{"Team ESP Color", 10, 20, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 0, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
        },
		{
			{"Enemy ESP Color", 270, 20, 205, 105, 100},
			{"Red", "Slider", 255, 255, 75},
			{"Green", "Slider", 0, 255, 75},
			{"Blue", "Slider", 0, 255, 75},
        },
		{
			{"Team Chams Color", 10, 145, 205, 105, 100},
			{"Red", "Slider", 0, 255, 75},
			{"Green", "Slider", 0, 255, 75},
			{"Blue", "Slider", 255, 255, 75},
        },
		{
			{"Enemy Chams Color", 225, 145, 205, 105, 100},
			{"Red", "Slider", 255, 255, 75},
			{"Green", "Slider", 0, 255, 75},
			{"Blue", "Slider", 0, 255, 75},
        },
		{
			{"Crosshair Color", 485, 20, 255, 105, 130},
			{"Red", "Slider", 76, 255, 88},
			{"Green", "Slider", 175, 255, 88},
			{"Blue", "Slider", 80, 255, 88},
        },
		{
			{"Window Color", 440, 145, 250, 105, 130},
			{"Red", "Slider", 76, 255, 88},
			{"Green", "Slider", 175, 255, 88},
			{"Blue", "Slider", 80, 255, 88},
        },
		{
			{"ESP Entities Color", 10, 270, 250, 105, 130},
			{"Red", "Slider", 76, 255, 88},
			{"Green", "Slider", 175, 255, 88},
			{"Blue", "Slider", 80, 255, 88},
        },
		{
			{"Skeleton ESP Color", 270, 270, 250, 105, 130},
			{"Red", "Slider", 76, 255, 88},
			{"Green", "Slider", 175, 255, 88},
			{"Blue", "Slider", 80, 255, 88},
        },
		{
			{"Positions", 10, 395, 250, 125, 130},
			{"Status X", "Slider", 0, 1000, 88},
			{"Status Y", "Slider", 0, 1000, 88},
			{"Window X", "Slider", 0, 1000, 88},
			{"Window Y", "Slider", 0, 1000, 88},
        },
	},
};

local order = {
	"Legitbot",
	"Ragebot",
	"Visuals",
	"Misc",
	"Settings",
};

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				val[3] = new;
			end
		end
	end
end

local function loadconfig()
	if(!file.Exists("hexahack.txt", "DATA")) then return; end
	local tab = util.JSONToTable( file.Read("hexahack.txt", "DATA") );
	local cursub;
	for k,v in next, tab do
		if(!options[k]) then continue; end
		for men, subtab in next, v do
			for key, val in next, subtab do
				if(key == 1) then cursub = val[1]; continue; end
				updatevar(k, cursub, val[1], val[3]);
			end
		end
	end
end

local function gBool(men, sub, lookup)
	if(!options[men]) then return; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
end

local function gOption(men, sub, lookup)
	if(!options[men]) then return ""; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
	return "";
end

local function gInt(men, sub, lookup)
	if(!options[men]) then return 0; end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then continue; end
			if(val[1] == lookup) then
				return val[3];
			end
		end
	end
	return 0;
end

local function saveconfig()
	file.Write("hexahack.txt", util.TableToJSON(options));
end

local mousedown;
local candoslider;
local drawlast;
local visible = {};
for k,v in next, order do
	visible[v] = false;
end

local function DrawBackground(w, h)
	surface.SetDrawColor(20, 20, 20);
	surface.DrawRect(0, 0, w, h);
	local curcol = Color(76, 175, 80);
	for i = 0, 32 do
		surface.SetDrawColor(76, 175, 80);
		curcol.r = curcol.r - 0;
		surface.DrawLine(-5, i, w, i);
	end
	surface.SetDrawColor(76, 175, 80);
	surface.SetFont("hexa1");
	local tw, th = surface.GetTextSize("Hexa for Garry's Mod");
	surface.SetTextPos(5, 15 - th / 2);
	surface.SetTextColor(20, 20, 20);
	surface.DrawText("Hexa for Garry's Mod");
	surface.DrawRect(0, 31, 2, h - 31);
	surface.DrawRect(0, h - 2, w, h);
	surface.DrawRect(w - 2, 31, 2, h);
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos();
	return(mousex < maxx && mousex > minx && mousey < maxy && mousey > miny);
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos();
	local sizeper = (w - 10) / #order;
	local maxx = 5;
	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30);
		if(visible[v]) then
			local curcol = Color(76, 175, 80);
			for i = 0, 0 do
				surface.SetDrawColor(curcol);
				curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3;
				surface.DrawLine( 0.9 + maxx, 60 + i, 0.9 + maxx + sizeper, 60 + i);
			end
		end
		if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !visible[v]) then
			local nb = visible[v];
			for key,val in next, visible do
				visible[key] = false;
			end
			visible[v] = !nb;
		end
		surface.SetFont("hexa2");
		surface.SetTextColor(76, 175, 80);
		local tw, th = surface.GetTextSize(v);
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 );
		surface.DrawText(v);
		maxx = maxx + sizeper;
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("hexa2");
	surface.SetTextColor(76, 175, 80);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	local tw, th = surface.GetTextSize(var[1]);
	surface.DrawText(var[1]);
	surface.SetDrawColor(76, 175, 80);
	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16);
	if(bMouse) then
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
	end
	if(var[3]) then
		surface.SetDrawColor(76, 175, 80);
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
		surface.SetDrawColor(20, 20, 20);
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10);
	end
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
		var[3] = !var[3];
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3];
	local max = var[4];
	local size = var[5];
	surface.SetFont("hexa2");
	surface.SetTextColor(76, 175, 80);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	surface.DrawText(var[1]);
	local tw, th = surface.GetTextSize(var[1]);
	surface.SetDrawColor(76, 175, 80);
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2);
	local ww = math.ceil(curnum * size / max);
	surface.SetDrawColor(76, 175, 80);
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 4, 12);
	surface.SetDrawColor(76, 175, 80);
	local tw, th = surface.GetTextSize(curnum..".00");
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 4, 12);
	surface.SetTextPos( 5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 61 + posy + maxy + 16);
	surface.DrawText(curnum..".00");
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12);
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !candoslider) then
		local mw, mh = gui.MousePos();
		local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max);
		var[3] = new;
	end
end

local notyetselected;
local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5];
	local curopt = var[3];
	surface.SetFont("hexa2");
	surface.SetTextColor(76, 175, 80);
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy );
	local tw, th = surface.GetTextSize(var[1]);
	surface.DrawText(var[1]);
	surface.SetDrawColor(76, 175, 80);
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy;
	if(bMouse || notyetselected == check) then
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12);
	end
	local tw, th = surface.GetTextSize(curopt);
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2);
	surface.DrawText(curopt);
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !mousedown || notyetselected == check) then
		notyetselected = check;
		drawlast = function()
			local maxy2 = 16;
			for k,v in next, var[4] do
				surface.SetDrawColor(76, 175, 80);
				surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
				local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
				if(bMouse2) then
					surface.SetDrawColor(96, 195, 80);
					surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16);
				end
				local tw, th = surface.GetTextSize(v);
				surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2);
				surface.DrawText(v);
				maxy2 = maxy2 + 16;
				if(bMouse2 && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
					var[3] = v;
					notyetselected = nil;
					drawlast = nil;
					return;
				end
			end
			local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2);
			if(!bbMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
				 notyetselected = nil;
				 drawlast = nil;
				 return;
			end
		end
	end
end

local function DrawSubSub(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6];
	surface.SetDrawColor(76, 175, 80);
	local startpos = 61 + posy;
	surface.SetTextColor(76, 175, 80);
	surface.SetFont("hexa2");
	local tw, th = surface.GetTextSize(opt);
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos);
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 );
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos);
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey);
	surface.DrawLine( 5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey );
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey);
	surface.DrawText(opt);
	local maxy = 15;
	for k,v in next, var do
		if(k == 1) then continue; end
		if(v[2] == "Checkbox") then
			DrawCheckbox(self, w, h, v, maxy, posx, posy, dist);
		elseif(v[2] == "Slider") then
			DrawSlider(self, w, h, v, maxy, posx, posy, dist);
		elseif(v[2] == "Selection") then
			DrawSelect(self, w, h, v, maxy, posx, posy, dist);
		end
		maxy = maxy + 25;
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do 
		if(!v) then continue; end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var);
		end
	end
end

local function DrawSaveButton(self, w, h)
	local curcol = Color(76, 175, 80);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 30, my + h - 50, mx + 30 + 200, my + h - 50 + 30);
	if(bMouse) then
		curcol = Color(96, 195, 80);
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol);
		surface.DrawLine( 30, h - 50 + i, 30 + 200, h - 50 + i );
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2;
		end
	end
	surface.SetFont("hexa2");
	surface.SetTextColor(20, 20, 20);
	local tw, th = surface.GetTextSize("Save Configuration");
	surface.SetTextPos( 30 + 100 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Save Configuration");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
		saveconfig();
	end
end

local function DrawLoadButton(self, w, h)
	local curcol = Color(76, 175, 80);
	local mx, my = self:GetPos();
	local bMouse = MouseInArea(mx + 250, my + h - 50, mx + 250 + 200, my + h - 50 + 30);
	if(bMouse) then
		curcol = Color(96, 195, 80);
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol);
		surface.DrawLine( 250, h - 50 + i, 250 + 200, h - 50 + i );
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2;
		end
	end
	surface.SetFont("hexa2");
	surface.SetTextColor(20, 20, 20);
	local tw, th = surface.GetTextSize("Load Configuration");
	surface.SetTextPos( 250 + 100 - tw / 2, h - 50 + 15 - th / 2 );
	surface.DrawText("Load Configuration");
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
		loadconfig();
	end
end
loadconfig();

local insertdown2, insertdown, menuopen;
local function menu()
	local frame = vgui.Create("DFrame");
	frame:SetSize(1110, 650);
	frame:Center();
	frame:SetTitle("");
	frame:MakePopup();
	frame:ShowCloseButton(false);
	frame.Paint = function(self, w, h)
		if(candoslider && !mousedown && !drawlast && !input.IsMouseDown(MOUSE_LEFT)) then
			candoslider = false;
		end
		DrawBackground(w, h);
		DrawOptions(self, w, h);
		DrawSub(self, w, h);
		DrawSaveButton(self, w, h);
		DrawLoadButton(self, w, h);
		if(drawlast) then
			drawlast();
			candoslider = true;
		end
		mousedown = input.IsMouseDown(MOUSE_LEFT);
	end
	frame.Think = function()
		if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then
			frame:Remove();
			menuopen = false;
			candoslider = false;
			drawlast = nil;
		end
	end
	local label = vgui.Create("DLabel", frame);
	label:SetPos(1048, 630);
	label:SetSize(68, 13);
	label:SetText("Version 1.0");
	label:SetColor(Color(76, 175, 80));
end

local function Think()
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
		menuopen = true;
		insertdown = true;
		menu();
	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
		insertdown = false;
	end
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
		insertdown2 = true;
	else
		insertdown2 = false;
	end
end
hook.Add("Think", "", Think);

-- Features

local function MESP()
	for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(255,0,100));
	local color = Color(255, 0, 100);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2.1, pos.y - h /1.1, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2.1 - 1, pos.y - h /1.1 - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2.1 + 1, pos.y - h /1.1 + 1, w - 2, h - 2);
	draw.DrawText( "Shipment", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 255, 255), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_weapon" ) ) do
	local pos = em.GetPos(v) + Vector( 1.5,0,-13.5 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 3
	local col = (Color(100, 0, 255));
	local color = Color(100, 0, 255);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.SimpleText("Weapon", "MiscFont", pos.x, pos.y - h - 2 - (friendstatus == "friend" && 7 || 7), Color(255, 255, 255), 1, 1);
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_money" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-4.5 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 6
	local h = h/ 7
	local col = (Color(0, 200, 0));
	local color = Color(0, 200, 0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("Extra", "Autism") && HSVToColor(RealTime()*33%360,1,1) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.DrawText( "Money", "MiscFont", pos.x, pos.y, Color(255, 255, 255), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_magnum" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Magnum", "MiscFont", pos.x -0, pos.y +10, Color(0,200,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_knife" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Knife", "MiscFont", pos.x -0, pos.y +10, Color(200,0,0))
	end

	for k, v in pairs( ents.FindByClass( "mu_loot" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-12 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.DrawText( "Loot", "MiscFont", pos.x, pos.y, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "gy_medkit" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 2
	local h = h/ 3.3
	local col = (Color(0, 200, 0));
	local color = Color(0, 200, 0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h /1.1, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h /1.1 - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h /1.1 + 1, w - 2, h - 2);
	draw.DrawText( "Health", "MiscFont", pos.x +w/50 -1, pos.y + h /11, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_c4" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200, 0, 0));
	local color = Color(200, 0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_knife" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_phammer" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_sipistol" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_flaregun" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_push" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_radio" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "weapon_ttt_teleport" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "(Disguise)" ) ) do
	local pos = em.GetPos(v) + Vector( 1,0,-6 );
	local pos2 = pos + Vector(0, 0, 70);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local h = pos.y - pos2.y;
	local w = h / 1.3
	local h = h/ 1.8
	local col = (Color(200,0,0));
	local color = Color(0,0,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in pairs( ents.FindByClass( "npc_*" ) ) do
	local col = Color(0, 255, 0);
	local col2 = Color(( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
	local pos = em.GetPos(v);
	local min, max = em.GetCollisionBounds(v);
	local pos2 = pos + Vector(0, 0, max.z);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local hh = 0;
	local h = pos.y - pos2.y;
	local w = h / 1.7;
	local hp = em.Health(v) * h / 100;
	local health = em.Health(v);
	local col = (Color(255, 170, 0));
	local color = Color(255,170,0);
	local Ent = v;
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	if health < 0 then
	health = 0
	end
	if v:Health() > 0 then
	surface.SetDrawColor(col);
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
	local ocol = (gBool("ESP", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,0,0));
	surface.SetDrawColor(ocol);
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
	draw.SimpleText(v:GetClass(), "ESPFont", pos.x, pos.y - h -2 - (friendstatus == "friend" && 7 || 7), Color(255, 255, 255), 1, 1);
	surface.SetDrawColor(Color(0,0,0))
	local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0);
	draw.SimpleText(health.."HP", "ESPFont", pos.x, pos.y - 2, col1, 1, 0);
	if(hp > h) then hp = h; end
	local diff = h - hp;
	surface.SetDrawColor(0, 0, 0, 255);
	surface.DrawRect(pos.x - w / 2 - 7, pos.y - h - 1, 5, h + 2);
	surface.SetDrawColor(col2);
	surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + diff, 3, hp);
	end
	end
end

local ChatTables = {
	"Hey, guess what? Fuck you faggot ass piece of shit cunt motherfucker twat bitch faggot fuck nigger ass shit dickdick goat fucker cock sucker retard ass nigger fuck pussy ass bitch.",
	"You are a cancer piece of shit, kill yourself.",
	"You should rage quit you piece of shit.",
	"I hate you and everything about you, you're a moron rofl.",
	"End your life you sad nerd.",
	"Fuck you lmaooooooooooooooooooooooooooooooooooooooooooooooo.",
	"You are a stupid cancerous nigger.",
	"Stupid jew fuck ass twat ass nigger.",
	"Twat pocket cunt fucker titty shitter dick licker.",
	"Kike ass motherfucking shekel stealing ass jew bitch.",
	"Stinky ass mother fucking nigger-jew.",
}

local ChatTables2 = {
	"I have a big African Shlong.",
	"I will fuck your dead grandmother's corpse.",
	"Fuck niggers, they are stinky and have aids.",
	"Hitler was my hero, and he's also my idol.",
	"I am in the Ku Klux Klan.",
	"Dead babies are delicious.",
	"I have a big African Shlong.",
	"I live in a fucking yurt.",
	"Back in my days they called me fetus puncher.",
	"I beat up nigger babies.",
}

local ChatTables4 = {
	" is a faggot.",
	" is a bitch.",
	" is a retard.",
	" is an asshole.",
	" is an autist.",
	" is a nerd.",
	" is cancer.",
	" is a shithead.",
	" is a dickhead.",
	" is an asshat.",
	" is a dick.",
	" is a chode.",
	" is a mexican.",
	" is a nigger.",
	" is a poopbutt.",
	" is a shitdick.",
	" is a cunt.",
	" is a twat.",
	" is a jew.",
	" is aids.",
}

local ChatTables5 = {
	"Hexa.nn.pe",
}


local namechangeTime = 0;
local function Think()
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
		menuopen = true;
		insertdown = true;
		menu();
	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
		insertdown = false;
	end
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
		insertdown2 = true;
	else
		insertdown2 = false;
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Jokes") then
		RunConsoleCommand("say", ChatTables2[math.random(#ChatTables2)])
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "OOC") then
		RunConsoleCommand("say", "// Hexa | A Garry's Mod Rage/Legit Hack")
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Insult") then
	local player = player;
	local math = math;
	local randply = player.GetAll()[math.random(#player.GetAll())]
	local friendstatus = pm.GetFriendStatus(randply);

	if (!randply:IsValid() || randply == me || (friendstatus == "friend")) then return; end
		RunConsoleCommand("say", randply:Name()..ChatTables4[math.random(#ChatTables4)])
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Money") then
		RunConsoleCommand("say", "/dropmoney "..math.random(2,10))
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Advertise") then
		RunConsoleCommand("say", "Hexa | A Garry's Mod Rage/Legit Hack | "..ChatTables5[math.random(#ChatTables5)].."")
	end

	if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "ULX Message") then
		local v = player.GetAll()[math.random(#player.GetAll())]
		if (v != me && v:GetFriendStatus() != "friend" && !pm.IsAdmin(v)) then
			LocalPlayer():ConCommand("ulx psay \"".. v:Nick() .."\" "..ChatTables[math.random(#ChatTables)]);
		end
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Dance") then
		RunConsoleCommand("act", "dance")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Sexy") then
		RunConsoleCommand("act", "muscle")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Wave") then
		RunConsoleCommand("act", "wave")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Robot") then
		RunConsoleCommand("act", "robot")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Bow") then
		RunConsoleCommand("act", "bow")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Cheer") then
		RunConsoleCommand("act", "cheer")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Laugh") then
		RunConsoleCommand("act", "laugh")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Zombie") then
		RunConsoleCommand("act", "zombie")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Agree") then
		RunConsoleCommand("act", "agree")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Disagree") then
		RunConsoleCommand("act", "disagree")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Forward") then
		RunConsoleCommand("act", "forward")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Back") then
		RunConsoleCommand("act", "becon")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Salute") then
		RunConsoleCommand("act", "salute")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Wave") then
		RunConsoleCommand("act", "wave")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Pose") then
		RunConsoleCommand("act", "pers")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Halt") then
		RunConsoleCommand("act", "halt")
	end

	if(gBool("Misc", "Emotes", "Enable") && gOption("Misc", "Emotes", "Emote Type") == "Group") then
		RunConsoleCommand("act", "group")
	end

	if(gBool("Misc", "Extra", "Flashlight Spam")) then
		RunConsoleCommand("impulse", "100" )
	end

	if(gBool("Misc", "Chat", "Name Stealer")) then
	local player = player;
	local math = math;
	local randply = player.GetAll()[math.random(#player.GetAll())]
	local friendstatus = pm.GetFriendStatus(randply);
	local rank = pm.IsAdmin(randply);
	GAMEMODE:RemoveHook("Think", "nametaker2")
	GAMEMODE:AddHook("Think", "nametaker", function()
		if (!randply:IsValid() || randply == me || friendstatus == "friend" || rank ) then return; end
		_fhook_changename(randply:Name().." ");
		end)
	elseif(!gBool("Misc", "Chat", "Name Stealer")) then
	GAMEMODE:RemoveHook("Think", "nametaker")
	GAMEMODE:AddHook("Think", "nametaker2", function()
		_fhook_changename(myName);
		end)
	end

if(gBool("Misc", "Chat", "Name Stealer") && gOption("Misc", "Chat", "Steal Type") == "DarkRP") then
	local v = player.GetAll()[math.random(#player.GetAll())]
	local scrambledName = string.sub(v:Nick(), 1, 1)..v:Nick();
	local friendstatus = pm.GetFriendStatus(v);
	local rank = pm.IsAdmin(v);
	namechangeTime = namechangeTime + 1;
	if namechangeTime > 650 then
	if (v != me || friendstatus != "friend" || rank ) then
	RunConsoleCommand("say", "/name "..scrambledName);
	namechangeTime = 0;
	end
	end
	end
end
GAMEMODE:AddHook("Think", "", Think);

local fa;
local aa;
local oldAngles = Angle();
local function normalizeAngle(ang)
	ang.p = math.NormalizeAngle(ang.p);
	ang.p = math.Clamp(ang.p, -89, 89);
	ang.y = math.NormalizeAngle(ang.y);
end

local function FixMovement(ucmd)
	local vec = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), 0);
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y);
	local mang = vm.Angle(vec);
	local yaw = cm.GetViewAngles(ucmd).y - fa.y + mang.y;
	if (((cm.GetViewAngles(ucmd).p+90)%360) > 180) then
	yaw = 180 - yaw;
	end
	yaw = ((yaw + 180)%360)-180;
	ucmd:SetForwardMove(math.cos(math.rad(yaw)) * vel);
	ucmd:SetSideMove(math.sin(math.rad(yaw)) * vel);
end

local function Clamp(val, min, max)
        if(val < min) then
                return min;
        elseif(val > max) then
                return max;
        end
        return val;
end

local function NormalizeAngle(ang)
	ang.x = math.NormalizeAngle(ang.x);
	ang.p = math.Clamp(ang.p, -89, 89);
end

local function fasAutowall(wep, startPos, aimPos, ply)
	if(!Autowall:GetBool()) then return false; end
    local traces = {};
    local me = me;
    local traceResults = {};
    local dir = (aimPos - startPos):GetNormalized();
    traces[1] = { start = startPos, filter = me, mask = trace_normal, endpos = aimPos, };
    traceResults[1] = util.TraceLine(traces[1]);
    if(NoPenetration[traceResults[1].MatType]) then return false; end
    if((-dir):DotProduct(traceResults[1].HitNormal) <= .26) then return false; end
    traces[2] = { start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] || 1) * wep.PenMod, filter = me, mask = trace_walls, };
    traceResults[2] = util.TraceLine(traces[2]);
    traces[3] = { start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal, };
    traceResults [3] = util.TraceLine(traces[3]);
    traces[4] = { start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT, };
    traceResults[4] = util.TraceLine(traces[4]);
    if(traceResults[4].Entity != ply) then return false; end
    return(!traceResults[3].Hit);
end

local function m9kAutowall(wep)
	if not gBool("Aimbot", "More...", "Auto Wall") then return end
	local wep = me:GetActiveWeapon()
    local trace = {
        endpos = aimPos,
        start = me:EyePos(),
        mask = MASK_SHOT,
        filter = me,
    }
    return wep:BulletPenetrate(10, nil, util.TraceLine(trace), DamageInfo())
end

local table = Copy(table);
local dists = {};
local function GetPos(v)

	if(gBool("Ragebot", "Aim Options", "Body Aim")) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end

	local eyes = em.LookupAttachment(v, "eyes");

	if(!eyes) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end

	local pos = em.GetAttachment(v, eyes);

	if(!pos) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end

	return(pos.Pos);
end

local function AntiAFK()
if(gBool("Misc", "Extra", "Anti-AFK")) then return; end
	timer.Create("afk1", 6, 0, function()
		local commands = {"moveleft", "moveright", "moveup", "movedown"}
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
			timer.Create("afk2", 1, 1, function()
			RunConsoleCommand( "+"..command1 ) RunConsoleCommand( "+"..command2 )
			end)
		timer.Create("afk3", 4, 1, function()
			RunConsoleCommand( "-"..command1 ) RunConsoleCommand( "-"..command2 )
		end)
	end)
end

local function DrawOutlinedText ( title, font, x, y, color, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, OUTsize, OUTcolor )
end

local function DrawOutlinedTextEx ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
end

local function Status()
local hh = 8;
local wep = pm.GetActiveWeapon(me);
local vw, vh = surface.GetTextSize("Health: "..me:Health());
local hp = me:Health();
local velocity = me:GetVelocity():Length();

if hp < 0 then
hp = 0;
end

surface.SetFont("MenuFont");
surface.SetTextColor(130, 130, 255, 225);
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.DrawText("Status:");
surface.SetTextColor(0, 255, 0, 225);

hh = hh + 12
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.SetTextColor(255 - hp * 2.55, hp * 2, 0, 225)
surface.DrawText("Health: "..hp);

if( em.IsValid(wep) ) then
local daclip = wep:Clip1();
local pw, ph = surface.GetTextSize("Ammo: "..daclip);

if daclip < 0 then
daclip = 0;
end

surface.SetTextColor(255, 140, 0, 225);
hh = hh + 11
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2);
surface.DrawText("Ammo: "..daclip.."/"..me:GetAmmoCount( wep:GetPrimaryAmmoType() ));
else
local pw, ph = surface.GetTextSize("Ammo: ".."0".."/".."0");
surface.SetTextColor(255, 140, 0, 225);
hh = hh + 11
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2);
surface.DrawText("Ammo: ".."0".."/".."0");
end

hh = hh + 12
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.SetTextColor(255, 0, 100, 225)
surface.DrawText("Velocity: "..math["Round"](velocity));

admincount = 0
for k,v in pairs(player.GetAll()) do
if v:GetNWString("usergroup") != "user" && v:GetNWString("usergroup") != "member" && v:GetNWString("usergroup") != "VIP" && v:GetNWString("usergroup") != "User" && v:GetNWString("usergroup") != "vip" && v:GetNWString("usergroup") != "v.i.p." && v:GetNWString("usergroup") != "donator" && v:GetNWString("usergroup") != "power-donator" && v:GetNWString("usergroup") != "guest" && v:GetNWString("usergroup") != "known" && v:GetNWString("usergroup") != "regular" && v:GetNWString("usergroup") != "" then
surface.SetTextColor(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200);
hh = hh + 13
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2 +admincount);
surface.DrawText( "[" .. v:GetNWString("usergroup").."] - ")
surface.SetTextColor(255,255,255, 225);
surface.DrawText(v:GetName())
admincount = admincount-1
end

end
if admincount==0 then
surface.SetTextColor(0,255,0, 225);
hh = hh + 13
surface.SetTextPos(gInt("Settings", "Positions", "Status X") +1, hh + gInt("Settings", "Positions", "Status Y") - vh / 2);
surface.DrawText( "[no admins online]")
end
end

local function spectator()
	local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200;
	local black                                       = (Color(0,0,0,255))
	local red                                       = (Color(255,0,0,125))
	local green                                     = (Color(0,255,0,125))
	local tblack                                    = (Color(0,0,0,225))
	local white                                 = (Color(255,255,255,255))
	local pink = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 100)
	local pink2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200)
	local hudspecslength = 150

	specscount = 0

	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +202, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +200, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +21, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +3, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[ Spectators ]", "MiscFont", gInt("Settings", "Positions", "Window X") +102, gInt("Settings", "Positions", "Window Y") +11, pink2, 1, 1);

	for k,v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget())) and v:GetObserverTarget() == me then
			DrawOutlinedText (v:GetName(), "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32 +specscount, red, 0.1, black)
			specscount = specscount+12
		end
	end

	if specscount == 0 then
		DrawOutlinedText ("none", "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32, green, 0.1, black)
	end

	hudspecslength = specscount + 19

end

local function DrawFilledCircle(x, y, radius, quality)
	local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
	surface.DrawPoly(circle)
end

local function DrawArrow(x, y, myRotation)
	local arrow = {}
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	myRotation = myRotation * -1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		theirX = theirX - x
		theirY = theirY - y
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end
	surface.DrawPoly(arrow)
end

local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200
local function RadarDraw()
	local col = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 100)
	local col2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200)
	local everything = ents.GetAll()
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +425, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y") +200, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225, gInt("Settings", "Positions", "Window Y") +21, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +225 +1, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[ Radar ]", "MiscFont", gInt("Settings", "Positions", "Window X") +325, gInt("Settings", "Positions", "Window Y") +11, col2, 1, 1);
	draw.NoTexture()
	surface.SetDrawColor(team.GetColor(me:Team()))

	for k = 1, #everything do
		local v = everything[k]
		if (v:IsPlayer() and v:Health() > 0 and v:Team() != TEAM_SPECTATOR or (v:IsNPC() and v:Health() > 0)) then
			color = v:IsPlayer() and team.GetColor(v:Team()) or Color(255,255,255)
			surface.SetDrawColor(color)
			local myPos = me:GetPos()
			local theirPos = v:GetPos()
			local myAngles = me:GetAngles()
			local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / 40)
			local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / 40)

			local myRotation = myAngles.y - 90
			myRotation = math.rad(myRotation)
			theirX = theirX - (radarX + (radarWidth / 2))
			theirY = theirY - (radarY + (radarHeight / 2))
			local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
			local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
			newX = newX + (gInt("Settings", "Positions", "Window X") +2 + (radarWidth / 2))
			newY = newY + (gInt("Settings", "Positions", "Window Y") +2 + (radarHeight / 2))
			if newX < (gInt("Settings", "Positions", "Window X") +2 + radarWidth) and newX > gInt("Settings", "Positions", "Window X") +2 and newY < (gInt("Settings", "Positions", "Window Y") + radarHeight) and newY > gInt("Settings", "Positions", "Window Y") then
				DrawArrow(newX + 225, newY, v:EyeAngles().y - myAngles.y)
			end
		end
	end
end

gameevent.Listen("player_disconnect");

hook.Add("player_disconnect", "", function()
	if(!gBool("Misc", "Extra", "Disconnect Spam")) then return; end
	local says = {"Easy Rage Quit!", "R.Q.", "Wow you left why the Rage Quit.", "Maybe not Rage Quit rejoining.", "Well you Rage Quited, what do i do now?", "Fuckin rip he left!"}
 	RunConsoleCommand("say", "[�Arrival Public]:" .. " " .. table.Random(says))
end);

hook.Add( "HUDPaint", "Rainbow Watermark", function()
if(!gBool("Visuals", "Hud Paint", "Rainbow Watermark")) then return; end
	rainbow = {}
	rainbow.R = math.sin(CurTime() * 4) * 127 + 128
	rainbow.G = math.sin(CurTime() * 4 + 2) * 127 + 128
	rainbow.B = math.sin(CurTime() * 4 + 4) * 127 + 128

local h = ScrH() / 1
local w = ScrW() / 5
draw.SimpleText("[Hexa]", "WATERMARK", 10, 25, Color(rainbow.R, rainbow.B, rainbow.G), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
draw.SimpleText("", "WATERMARK", 70, 25, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
draw.SimpleText("#1 Free Hack", "WATERMARK", 10, 50, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
end)


hook.Add( "HUDPaint", "Watermark", function()
if(!gBool("Visuals", "Hud Paint", "Watermark")) then return; end
	rainbow = {}
	rainbow.R = math.sin(CurTime() * 4) * 127 + 128
	rainbow.G = math.sin(CurTime() * 4 + 2) * 127 + 128
	rainbow.B = math.sin(CurTime() * 4 + 4) * 127 + 128

local h = ScrH() / 1
local w = ScrW() / 5
draw.SimpleText("[Hexa]", "WATERMARK", 10, 25, Color(34,207,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
draw.SimpleText("", "WATERMARK", 70, 25, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
draw.SimpleText("#1 Free Hack", "WATERMARK", 10, 50, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
end)

local function crosshair()
	if me:Health() < 1 then return end;
	if(gInt("Visuals", "Hud Paint", "Crosshair Type") == "Box") then
		local x1, y1 = ScrW() * 0.5, ScrH() * 0.5;
		surface.SetDrawColor(0,0,0);
		surface.DrawOutlinedRect(x1-3, y1-2, 6, 6);
		surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 225);
		surface.DrawRect(x1-2, y1-1, 4, 4);
	end
	if(gInt("Visuals", "Hud Paint", "Crosshair Type") == "Cross") then
		surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 225);
		surface.DrawLine(ScrW() / 2 - 11, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 11, ScrW() / 2 - 0 , ScrH() / 2 + 11)
	end
	if(gInt("Visuals", "Hud Paint", "Crosshair Type") == "Square") then
		local x1, y1 = ScrW() * 0.5, ScrH() * 0.5;
		surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 225);
		surface.DrawOutlinedRect(x1-3, y1-2, 6, 6);
	end
	if(gInt("Visuals", "Hud Paint", "Crosshair Type") == "Circle") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 4, Color(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue")));
	end
	if(gInt("Visuals", "Hud Paint", "Crosshair Type") == "Dot") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 1.4, Color(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue")));
	end
end

GAMEMODE:AddHook("RenderScene", "", function()
	render.SetLightingMode(gBool("Misc", "Extra", "Fullbright") && 1 || 0);
end)
GAMEMODE:AddHook("PostDrawViewmodel", "", function()
	render.SetLightingMode(0)
end)
GAMEMODE:AddHook("PreDrawEffects", "", function()
	render.SetLightingMode(0)
end)

local aimignore;
local function Valid(v)
    local wep = me:GetActiveWeapon();
    if(!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || em.IsDormant(v) || pm.Team(v) == 1002 || (v == aimignore && gOption("Ragebot", "Aim Options", "Priority") == "Random")) then return false; end
    if(gBool("Ragebot", "Aim Options", "Ignore Team")) then
        if(pm.Team(v) == pm.Team(me)) then return false; end
    end
    if(gBool("Ragebot", "Aim Options", "Ignore Friends")) then
        if(pm.GetFriendStatus(v) == "friend") then return false; end
    end
		if(gBool("Ragebot", "Aim Options", "Ignore Bots")) then
		if(pm.IsBot(v)) then return false; end
	end
    if(gBool("Ragebot", "Aim Options", "Ignore Admins")) then
        if pm.IsAdmin(v) then return false; end
    end
    if(gBool("Ragebot", "Aim Options", "Ignore Vehicles")) then
		if pm.InVehicle(v) then return false; end
	end
	if(gBool("Ragebot", "Aim Options", "Ignore Noclip")) then
		if (em.GetMoveType(v) == MOVETYPE_NOCLIP) then return false; end
	end
    if(gBool("Ragebot", "Aim Options", "Ignore Spawn-Protected")) then
        if em.GetColor(v).a < 255 then return false; end
    end
	if(gBool("Ragebot", "Aim Options", "Disable In Noclip")) then
		if (em.GetMoveType(me) == MOVETYPE_NOCLIP) then return false; end
	end
    local tr = {
        start = em.EyePos(me),
        endpos = GetPos(v),
        mask = MASK_SHOT,
        filter = {me, v},
    }
    if(util.TraceLine(tr).Fraction == 1) then
        return true
    elseif(wep and wep:IsValid() and wep.PenStr) then
        return fasAutowall(wep, tr.start, tr.endpos, v)
	elseif (wep and wep:IsValid() and wep.BulletPenetrate) then
		return m9kAutowall(wep, tr.start, tr.endpos, v)
    end
    return false
end

local function gettarget()
local opt = gOption("Ragebot", "Aim Options", "Priority");
local sticky = gOption("Ragebot", "Aimbot", "Non-Sticky");

if(opt == "Distance") then
	if( !sticky && Valid(aimtarget) ) then return; end
	dists = {};
	for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end
	table.sort(dists, function(a, b)
			return(a[1] < b[1]);
	end);
	aimtarget = dists[1] && dists[1][2] || nil;
elseif(opt == "Health") then
	if( !sticky && Valid(aimtarget) ) then return; end
	dists = {};
	for k,v in next, player.GetAll() do
			if(!Valid(v)) then continue; end
			dists[#dists + 1] = { em.Health(v), v };
	end
	table.sort(dists, function(a, b)
			return(a[1] < b[1]);
	end);
	aimtarget = dists[1] && dists[1][2] || nil;
elseif(opt == "Random") then
if( !sticky && Valid(aimtarget) ) then return; end
	aimtarget = nil;
	local allplys = player.GetAll();
	local avaib = {};
	for k,v in next,allplys do
			avaib[math.random(100)] = v;
	end
	for k,v in next, avaib do
			if(Valid(v)) then
					aimtarget = v;
			end
	end
end
aimignore = nil;
end

local function IsVisible(ply, pos)
	local trace = {
		start = me:EyePos(),
		endpos = pos,
		filter = {ply, me},
		mask = MASK_SHOT,
	};

	if (util.TraceLine(trace).Fraction == 1 ) then
		return true;
	else
		local wep = me:GetActiveWeapon();
		if(wep && wep:IsValid() && wep.PenStr) then
			return fasAutowall(wep, trace.start, trace.endpos, ply);
		end
	end

	return false;
end

local cones = {}
local pcall = pcall
local require = require
local nullvec = Vector() * -1
local IsFirstTimePredicted = IsFirstTimePredicted
local CurTime = CurTime
local servertime = 0
local bit = Copy(bit)

local badSequences = {
    [ACT_VM_DEPLOY] = true,
    [ACT_VM_DEPLOY_1] = true,
    [ACT_VM_DEPLOY_2] = true,
    [ACT_VM_DEPLOY_3] = true,
    [ACT_VM_DEPLOY_4] = true,
    [ACT_VM_DEPLOY_5] = true,
    [ACT_VM_DEPLOY_6] = true,
    [ACT_VM_DEPLOY_7] = true,
    [ACT_VM_DEPLOY_8] = true,
    [ACT_VM_DEPLOY_EMPTY] = true,
    [ACT_VM_ATTACH_SILENCER] = true,
    [ACT_VM_DETACH_SILENCER] = true,
    [ACT_VM_DRAW] = true,
    [ACT_VM_DRAW_DEPLOYED] = true,
    [ACT_VM_DRAW_EMPTY] = true,
    [ACT_VM_DRAW_SILENCED] = true,
    [ACT_VM_RELOAD] = true,
    [ACT_VM_RELOAD_DEPLOYED] = true,
    [ACT_VM_RELOAD_EMPTY] = true,
}

GAMEMODE:AddHook("Move", "", function()
    if(IsFirstTimePredicted()) then
        servertime = CurTime() + engine.TickInterval()
    end
end )

GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget
	local w = pm.GetActiveWeapon(me)
	local Spread = data.Spread * -1
	if(not w or not em.IsValid(w) or cones[em.GetClass(w)] == Spread or Spread == nullvec) then return end
	cones[em.GetClass(w)] = Spread
end

local function PredictSpread(ucmd, ang)
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w) || !cones[em.GetClass(w)] || !gBool("Ragebot", "Extra", "Anti Spread")) then return am.Forward(ang); end
	return(dickwrap.Predict(ucmd, am.Forward(ang), cones[em.GetClass(w)]));
end

local function AutoFire(ucmd)
	if(pm.KeyDown(me, 1) && gBool("Ragebot", "Aimbot", "Auto Fire")) then
		cm.SetButtons(ucmd, bit.band( cm.GetButtons(ucmd), bit.bnot( 1 ) ) );
	else
		cm.SetButtons(ucmd, bit.bor( cm.GetButtons(ucmd), 1 ) );
	end
end

local function WeaponCanFire()
	local w = pm.GetActiveWeapon(me);
	if(!w || !em.IsValid(w) || !gBool("Ragebot", "Extra", "Bullet Time")) then return true; end
	return( servertime >= wm.GetNextPrimaryFire(w) );
end

function AutoReload(ucmd)
local wep = ply:GetActiveWeapon()
if(!gBool("Ragebot", "Aimbot", "Auto Reload")) then return; end
	if (ply:Alive() and paste.IsValid(wep)) then
		if (wep:Clip1() <= 0 and wep:GetMaxClip1() > 0 and paste.CurTime() > wep:GetNextPrimaryFire()) then
			ucmd:SetButtons(ucmd:GetButtons() + IN_RELOAD)
		end
	end
end

local function WeaponShootable()
    local wep = pm.GetActiveWeapon(me);
    if( em.IsValid(wep) ) then
	     local n = string.lower(wep:GetPrintName())
	     if( wep:Clip1() <= -1 ) then
		    return;
		 end



		 if( string.find(n,"knife") or string.find(n,"grenade") or string.find(n,"sword") or string.find(n,"bomb") or string.find(n,"ied") or string.find(n,"c4") or string.find(n,"slam") or string.find(n,"climb") or string.find(n,"fist") or string.find(n,"crossbow") or string.find(n,"shotgun") or string.find(n,"gravitygun")) then
		    return false;
		 end


		  return true;
	end
end

local function PredictPos(pos)
local myvel = LocalPlayer():GetVelocity()
local pos = pos - (myvel * engine.TickInterval());
return pos;
end

local function Aimbot(ucmd)
	if(cm.CommandNumber(ucmd) == 0 || !gBool("Ragebot", "Aimbot", "Enable")) then return; end
	gettarget();
	aa = false;
	if(aimtarget && (input.IsMouseDown(109) || (input.IsKeyDown(KEY_LALT) || !gBool("Ragebot", "Aimbot", "Aim Key: Mouse3 Or ALT")) && WeaponCanFire() && IsValid(me:GetActiveWeapon()) && WeaponShootable() && me:GetActiveWeapon():GetClass() != "weapon_physgun" && me:GetActiveWeapon():GetClass() != "gmod_tool")) then
		aa = true;
		local pos = GetPos(aimtarget) - em.EyePos(me);
		local ang = vm.Angle(PredictSpread(ucmd, vm.Angle(pos)));
		PredictPos(pos);
		NormalizeAngle(ang);
		cm.SetViewAngles(ucmd, ang);
		local ang = vm.Angle( PredictSpread(ucmd, vm.Angle(pos)));
		NormalizeAngle(ang);
		cm.SetViewAngles(ucmd, ang);
		if(gBool("Ragebot", "Aimbot", "Auto Fire")) then
			AutoFire(ucmd);
		end
		if(gBool("Ragebot", "Aimbot", "Silent Aim")) then
			FixMovement(ucmd);
		else
			fa = ang;
		end
		if(gBool("Ragebot", "Aimbot", "Perfect Silent Aim")) then
			bsendpacket = false
		end
	end
end

local toggler = 0
local function RapidFire(ucmd)
if(gBool("Misc", "Extra", "Rapid Fire")) then
	if me:KeyDown(IN_ATTACK) then
		if me:Health() > 0 then
			if IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() != "weapon_physgun" then
				if toggler == 0 then
					ucmd:SetButtons(bit.bor(ucmd:GetButtons(), IN_ATTACK))
					toggler = 1
				else
					ucmd:SetButtons(bit.band(ucmd:GetButtons(), bit.bnot(IN_ATTACK)))
					toggler = 0
				end
				end
			end
		end
	end
end

local function GetClosest()
	local ddists = {};

	local closest;

	for k,v in next, player.GetAll() do
	if(!Valid(v)) then continue; end
		ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v };
	end

	table.sort(ddists, function(a, b)
		return(a[1] < b[1]);
	end);

	closest = ddists[1] && ddists[1][2] || nil;

	if(!closest) then return fa.y; end

	local pos = em.GetPos(closest);

	local pos = vm.Angle(pos - em.EyePos(me));

	return( pos.y );
end

local function RandCoin()
	local randcoin = math.random(0,1);
	if(randcoin == 1) then return 1; else return -1; end
end

local function GetX()
	local opt = gOption("Ragebot", "Anti-Aim", "X-Axis");
	if(opt == "Emotion") then
		local randcoin = gInt("Ragebot", "Anti-Aim", "Max Y");
		if( math.random(100) < randcoin ) then
			ox = RandCoin() * 181;
		end
	elseif( opt == "Up" ) then
		ox = 181;
	elseif( opt == "Down" ) then
		ox = -181;
	elseif(opt == "Jitter") then
		ox = ox * -1;
	elseif( opt == "Fake-Down" ) then
		ox = -180.000005;
	elseif(opt == "Fake-Angles") then
		ox = math.random(1, 181, 1);
	end
end


local function GetY()
	local opt = gOption("Ragebot", "Anti-Aim", "Y-Axis");
	if(opt == "Emotion") then
		local randcoin = gInt("Ragebot", "Anti-Aim", "Min Y");
		if( math.random(100) < randcoin ) then
			oy = fa.y + math.random(-180, 180);
		end
	elseif( opt == "Sideways" ) then
		oy = fa.y - 90;
	elseif( opt == "Opposite-Sideways" ) then
		oy = fa.y + 90;
	elseif(opt == "Jitter") then
		oy = fa.y + math.random(-90, 90);
	elseif(opt == "Fake Backwards-Jitter") then
		oy = fa.y - 180 + math.random(-90, 90);
	elseif(opt == "Fake Backwards") then
		oy = fa.y + math.random(1, -80, 1);
	elseif(opt == "Side Switch") then
        oy = math.random(90, -90) +20 / 2;
	elseif(opt == "Static") then
		oy = 0;
	elseif(opt == "Static Backwards") then
        oy = 180;
	elseif(opt == "Towards Players") then
		oy = GetClosest();
	elseif(opt == "Slow Spin") then
        oy = (paste.CurTime() * 200) % 360, 0;
	elseif(opt == "Fast Spin") then
		oy = (paste.CurTime() * 500) % 360, 0;
	elseif(opt == "Jitter Spin") then
		oy = (paste.CurTime() * 99999) % 360, 0;
	elseif(opt == "Side Jitter") then
        oy = fa.y + math.random(-200, -55);
	elseif(opt == "Opposite-Side Jitter") then
        oy = fa.y + math.random(200, 55);
	elseif(opt == "Fake-Sideways") then
		oy = fa.y + math.random(1, -40, 1);
	elseif(opt == "Fake-Angles") then
		oy = fa.y + math.random(-1, 80, -1, -40, -1);
	end
end

local function walldetect()
	local eye = em.EyePos(me);
	local tr = util.TraceLine({
		start = eye,
		endpos = (eye + (am.Forward(fa) * 10)),
		mask = MASK_ALL,
	});
	if(tr.Hit) then
		ox = -181;
		oy = -90;
	end
end

local function antiaimer(ucmd)
if( (cm.CommandNumber(ucmd) == 0 && !gBool("Misc", "Extra", "Thirdperson")) || cm.KeyDown(ucmd, 1) || cm.KeyDown(ucmd, 32) || aa || !gBool("Ragebot", "Anti-Aim", "Enable")) then return; end
	GetX();
	GetY();
	walldetect();
	local aaang = Angle(ox, oy, 0);
	cm.SetViewAngles(ucmd, aaang);
	FixMovement(ucmd, true);
end

local function GetAngle(ang)
	if(!gBool("Ragebot", "Extra", "Anti Recoil")) then return ang + pm.GetPunchAngle(me); end
	return ang;
end

local function Hexa(ucmd)
	if(!fa) then fa = cm.GetViewAngles(ucmd); end
        fa = fa + Angle(cm.GetMouseY(ucmd) * .023, cm.GetMouseX(ucmd) * -.023, 0);
        NormalizeAngle(fa);
	if(cm.CommandNumber(ucmd) == 0) then
		cm.SetViewAngles(ucmd, GetAngle(fa));
		return;
        end
	if(cm.KeyDown(ucmd, 1)) then
			local ang = GetAngle(vm.Angle(PredictSpread(ucmd, fa ) ) );
			NormalizeAngle(ang);
			cm.SetViewAngles(ucmd, ang);
        end
end

function AirDuck(ucmd)
	if(!gBool("Misc", "Extra", "Air Duck")) then return end
	local pos = ply:GetPos()
	local trace = {
		start = pos,
		endpos = pos - paste.Vector(0, 0, 50),
		mask = MASK_PLAYERSOLID,
	}
	local trace = util.TraceLine(trace)
	local height = (pos - trace.HitPos).z
	if (height > 25 and 50 > height) then
		ucmd:SetButtons(ucmd:GetButtons() + IN_DUCK)
	end
end

local function AutoJump(ucmd)
local duckEstimate = math.Round(58 + 1 / engine.TickInterval());
if(!gBool("Misc", "Extra", "Auto Jump") || em.GetMoveType(me) == MOVETYPE_NOCLIP || me:Health() < 1) then return; end
	if(cm.KeyDown(ucmd, 2) && !em.IsOnGround(me)) then
		cm.SetButtons(ucmd, bit.band( cm.GetButtons(ucmd), bit.bnot( 2 ) ) );
	end
end

local function AutoStrafe(ucmd)
	if(gBool("Misc", "Extra", "Auto Strafe")) then
		if(!me:IsOnGround()) then
			if (ucmd:GetMouseX() < 0) then
				ucmd:SetSideMove(-31 ^ 2 + 39)
			elseif(ucmd:GetMouseX() > 0) then
				ucmd:SetSideMove(31 ^ 2 + 39)
			end
		end
	end
end

GAMEMODE:AddHook("CreateMove", "", function(ucmd)
	memesendpacket = true;
	AutoJump(ucmd);
	AutoStrafe(ucmd);
	if(ucmd:CommandNumber() != 0) then
	localindex = me:EntIndex();
	currentcommand = ucmd:CommandNumber();
	end
	local oldAngles = ucmd:GetViewAngles();
	Hexa(ucmd);
	AutoReload(ucmd);
	Aimbot(ucmd);
	antiaimer(ucmd);
	RapidFire(ucmd);
	AirDuck(ucmd);
	if(oldAngles != ucmd:GetViewAngles()) then
	local x = ucmd:GetViewAngles().x;
	end
end);

GAMEMODE:AddHook("ShouldDrawLocalPlayer", "", function()
return(gBool("Misc", "Extra", "Thirdperson"));
end);

GAMEMODE:AddHook("CalcView", "", function(p, o, a, f)
local view = {
	angles = GetAngle(fa),
	origin = (gBool("Misc", "Extra", "Thirdperson") && o + am.Forward(fa) * (gInt("Misc", "Extra", "Thirdperson Distance") * -10) || o),
};
return view;
end);

paste.AddHook("entity_killed", function(data)
	if(!gBool("Misc", "Chat", "Death Notify")) then return end

	local inflictor = paste.Entity(data.entindex_inflictor)
	local killer = paste.Entity(data.entindex_attacker)
	local victim = paste.Entity(data.entindex_killed)

	if (paste.IsValid(killer) and paste.IsValid(victim) and killer:IsPlayer() and victim:IsPlayer()) then
	paste.surface.PlaySound(paste.table.Random(paste.cough))
		if (killer == victim and victim ~= ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), victim:Nick() .. " killed themself.")
		elseif (killer == victim and victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), "You killed yourself.")
		elseif (killer == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), "You killed " .. victim:Nick() .. ".")
		elseif (victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), "You were killed by " .. killer:Nick() .. ".")
		else
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), killer:Nick() .. " killed " .. victim:Nick() .. ".")
		end
	elseif (paste.IsValid(victim) and not killer:IsPlayer() and victim:IsPlayer()) then
	paste.surface.PlaySound(paste.table.Random(paste.cough))
		if (paste.IsValid(inflictor) and inflictor:GetClass() == "prop_physics") then
			if (victim == ply) then
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), "You were killed by a prop.")
			else
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), victim:Nick() .. " was killed by a prop.")
			end
		elseif (victim == ply) then
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), "You were killed by life.")
		else
			chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), victim:Nick() .. " was killed by life.")
		end
	end
end)

local hvhexcuses = {
	"My cheat sucks wtf!",
	"Forgot to press aimkey lol.",
	"Give me a minute to configurate noob.",
	"Prepare to get raped once i finished configurating!",
	"Wtf it didnt save my settings wait!",
	"Lol my hvh settings are gone, wait!",
	"Luck!",
	"What cheat are you using???",
	"Are you using lmaobox too??",
}

local reason = {
	"Bad at Game.",
	"Spawnkilling!",
	"Hacker!",
	"Hacking!",
	"Hack!",
	"Bad!",
	"Eats penis!",
}

local randomoption = { 
	"likes_penis!",
	"eats_penis!",
	"is_gay!",
	"is_a_faggot!",
	"should_get_kicked!",
	"hates_vagina!",
	"doesnt_eat_pussy!",
	"doesnt_get_pussy!",
	"thinks_about_penis_all_day!",
	"has_a_fake_penis!",
	"is_a_dirty_jew!",
}

local owned = {
	ply:Nick().." needs to get good.",
	"Can you stop dying, "..ply:Nick().."?",
	"Hey, "..ply:Nick().."? It's okay, try again next time!",
	"Ugh, what was that "..ply:Nick().."?",
	"Plan your next try in the respawn room!",
	"rekt",
	"owned",
	"LOL",
	"!voteretard "..ply:Nick(),
	"Well, that's one less cancer cell existing in gmod.",
	"You're bad, "..ply:Nick()..".",
	"How did "..ply:Nick().." survive the Holocaust???",
	"noob down",
	"Just dont try to suck too many dicks while you respawn, alright "..ply:Nick().."?",
	"lmao",
	"If I had Parkinsons and a Seizure at the same time I could still hit better than you, "..ply:Nick()..".",
	ply:Nick().." has died more times than Native Americans did back in the 1800s.",
	"I bet you're insecure about your aim.",
	"ahahah",
	"Excuse me "..ply:Nick()..", you have won the world record of the worst KD in history!",
	"Your aim is so bad even Hitler wouldn't make you a SS Soldier!",
	"There he goes back to the respawn room!",
	"Don't let the door hit you on the way out, "..ply:Nick().."!",
	"noob",
	ply:Nick().." is a noob",
	"nerd",
	"pff",
	"ha",
	"ez",
	ply:Nick().." is a nerd",
	"good job!",
	"try not to die next time, "..ply:Name().."!",
	"!votekick "..ply:Nick().." "..reason[math.random(#reason)],
	"!voteban "..ply:Nick().." 9999 "..reason[math.random(#reason)],
	"!vote "..ply:Nick().."... "..randomoption[math.random(#randomoption)].." "..randomoption[math.random(#randomoption)].." "..randomoption[math.random(#randomoption)],
}

local hvhowned = {
	"Hey, "..ply:Nick()..". Do you sell, bro?",
	"sick aimbot, "..ply:Nick().."!",
	"smashed.",
	"smacked.",
	"rekt!",
	"owned!!",
	"damn!",
	"did you get that garbage from gmodcheats?",
	"ha",
	"ez",
	"loser",
	"take this L",
	"gmodcheats sure is a good site",
	"\"my cheat is good it owns everyone!\" - "..ply:Nick(),
	ply:Nick()..": LOL WHAT ARE YOU USING??? I WANT THAT",
	"noob",
	"nerd",
	"pff",
	"gj",
	"how can a cheat suck this hard??",
	"nice strategy",
	"nice move!",
	"LOL, "..ply:Nick(),
	"what the fuck are you using "..ply:Nick().."??",
}

if(gBool("Misc", "Extra", "Kill Spam") && gOption("Misc", "Extra", "Kill Spam Type") == "Normal") then
	if !em.IsValid(v) then return false; end
	local randply = player.GetAll()[math.random(#player.GetAll())]
	local friendstatus = pm.GetFriendStatus(randply);
	if(killed == me) then
		if me:Health() < 1 then return end;
		RunConsoleCommand("say", string.format(excuses[math.random(#excuses)]));
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
	RunConsoleCommand("say", owned[math.random(#owned)]);
end

if(gBool("Misc", "Extra", "Kill Spam") && gOption("Misc", "Extra", "Kill Spam Type") == "HvH") then
	if(killed == me) then
		RunConsoleCommand("say", hvhexcuses[math.random(#hvhexcuses)]);
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
	RunConsoleCommand("say", hvhowned[math.random(#hvhowned)]);
end

function GAMEMODE:PreDrawSkyBox()
	if (!gBool("Misc", "Extra", "Remove Sky")) then return; end
	render.Clear(0, 0, 0, 255);
	return true;
end

local wireframeMat = Material("models/wireframe");
GAMEMODE:AddHook("PreDrawViewModel", "", function()
	if(!gBool("Visuals", "Viewmodel", "Colored Wireframe") || gBool("Visuals", "Extra", "Thirdperson")) then return; end
	local WepMat = Material("models/wireframe")
	render.MaterialOverride(WepMat);
	render.SetColorModulation(gInt("Visuals", "Viewmodel", "Red") /255,gInt("Visuals", "Viewmodel", "Green") /255,gInt("Visuals", "Viewmodel", "Blue") /255);
end);

GAMEMODE:AddHook("PreDrawPlayerHands", "", function()
	if(gBool("Visuals", "Viewmodel", "No Hands") || gBool("Misc", "Extra", "Thirdperson")) then
	return true;
	else
	return false;
	end
end);

gameevent.Listen("player_say");
hook.Add("player_say", "", function()
if(!gBool("Misc", "Chat", "'Shut up' As Response")) then return; end
	RunConsoleCommand("say", "shut up")
end);

local function GetChamsColor(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team Chams Color", "Red");
			local g = gInt("Settings", "Team Chams Color", "Green");
			local b = gInt("Settings", "Team Chams Color", "Blue");
			return(Color(r, g, b, 220));
        end
			local r = gInt("Settings", "Enemy Chams Color", "Red");
			local g = gInt("Settings", "Enemy Chams Color", "Green");
			local b = gInt("Settings", "Enemy Chams Color", "Blue");
        return(Color(r, g, b, 220));
end

local chamsmat = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local chamsmat2 = CreateMaterial("@", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
});

local function Chams(v)
if(gBool("Visuals", "ESP", "XQZ")) then
		cam.Start3D();
			cam.IgnoreZ(true);
			em.DrawModel(v);
			cam.IgnoreZ(false);
		cam.End3D();
	end
if(gBool("Visuals", "ESP", "Chams")) then
local col = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v)) || GetChamsColor(v);
	local wep = v:GetActiveWeapon()
	if wep:IsValid() then
	cam.Start3D();
	render.MaterialOverride(chamsmat);
	render.SetColorModulation(col.r/255, col.g/255, col.b/255, 255);
	em.DrawModel(wep);
	render.SetColorModulation(col.r/170, col.g/170, col.b/170, 255);
	render.MaterialOverride(chamsmat2);
	em.DrawModel(wep);
	cam.End3D();
	end

	cam.Start3D();
	render.MaterialOverride(chamsmat);
	render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);
	em.DrawModel(v);
	render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
	render.MaterialOverride(chamsmat2);
	em.DrawModel(v);
	render.SetColorModulation(1, 1, 1);
	cam.End3D();
	end
end

function Xray()
if(gBool("Visuals", "ESP", "Transparent Chams")) then
local ColScheme = Color(gInt("Settings", "Team Chams Color", "Red"), gInt("Settings", "Team Chams Color", "Green"), gInt("Settings", "Team Chams Color", "Blue"), gInt("Settings", "Enemy Chams Color", "Red"), gInt("Settings", "Enemy Chams Color", "Green"), gInt("Settings", "Enemy Chams Color", "Blue")), 100
local ColSchemeV = Vector(gInt("Settings", "Team Chams Color", "Red"), gInt("Settings", "Team Chams Color", "Green"), gInt("Settings", "Team Chams Color", "Blue"), gInt("Settings", "Enemy Chams Color", "Red"), gInt("Settings", "Enemy Chams Color", "Green"), gInt("Settings", "Enemy Chams Color", "Blue") / 255)
local ColSchemeV2 = Vector(math.Clamp(ColSchemeV.x + 0.2, 0, 1), math.Clamp(ColSchemeV.y + 0.5, 0, 1), math.Clamp(ColSchemeV.z + 0.2, 0, 1))
    if !xray then
        xray = true
        hook.Add("HUDPaint", "xxrayz", function()
            for k,v in pairs(ents.GetAll()) do
                local position = (v:GetPos()+Vector(0,0,80)):ToScreen()
                if v:IsPlayer() && v:Alive() then    
                    cam.Start3D(EyePos(),EyeAngles())
                    v:SetMaterial(mat2)
                    v:SetRenderMode(4)
                    v:SetColor(ColScheme)
                    render.SuppressEngineLighting( true )
                    render.MaterialOverride( mat1 )
                    render.SetColorModulation( ColSchemeV2.x, ColSchemeV2.y, ColSchemeV2.z )
                    render.SetBlend(0.3)
                    v:DrawModel()
                    render.SetBlend(1)
                    render.SuppressEngineLighting( false )
                    render.MaterialOverride( )
                    cam.End3D()
                end
            end
        end)
        end
    elseif xray then
        xray = false
        for k,v in pairs(ents.GetAll()) do
            if v:GetClass()==("prop_door_rotating") or v:GetClass()==("func_door_rotating") or v:GetClass()== "prop_physics" or v:IsPlayer() then
                v:SetMaterial("")
                v:SetColor(Color(255,255,255))
            end
        end
        hook.Remove("HUDPaint", "xxrayz")
    end
end
	
	local function ASUS()
        local mats = em.GetMaterials(game.GetWorld())
        for k,v in next, mats do
            local material = Material(v);
            if(!gBool("Visuals", "ESP", "ASUS Walls")) then
                im.SetFloat(material, "$alpha", 1);
                continue;
            end
            im.SetFloat(material, "$alpha", .56);
        end
    end

local function Filter(v)
	local enemy = gBool("Visuals", "Filter", "Enemies Only");
	local dist = gBool("Visuals", "Filter", "Distance")
	if(enemy) then
		if(pm.Team(v) == pm.Team(me)) then return false; end
	end
	if(dist) then
		local maxdist = gBool("Visuals", "Filter", "Max Distance");
		if( vm.Distance( em.GetPos(v), em.GetPos(me) ) > (maxdist * 5) ) then return false; end
	end
	return true;
end

local function GetColor(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team ESP Color", "Red");
			local g = gInt("Settings", "Team ESP Color", "Green");
			local b = gInt("Settings", "Team ESP Color", "Blue");
			return(Color(r, g, b, 220));
        end
			local r = gInt("Settings", "Enemy ESP Color", "Red");
			local g = gInt("Settings", "Enemy ESP Color", "Green");
			local b = gInt("Settings", "Enemy ESP Color", "Blue");
		return(Color(r, g, b, 220));
end

local function GetColor2(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team ESP Color", "Red");
			local g = gInt("Settings", "Team ESP Color", "Green");
			local b = gInt("Settings", "Team ESP Color", "Blue");
			return(Color(r, g, b, 25));
        end
			local r = gInt("Settings", "Enemy ESP Color", "Red");
			local g = gInt("Settings", "Enemy ESP Color", "Green");
			local b = gInt("Settings", "Enemy ESP Color", "Blue");
        return(Color(r, g, b, 25));
end

local function ESP(v)
	local pos = em.GetPos(v);
	local min, max = em.GetCollisionBounds(v);
	local pos2 = pos + Vector(0, 0, max.z);
	local pos = vm.ToScreen(pos);
	local pos2 = vm.ToScreen(pos2);
	local hh = 0;
	local h = pos.y - pos2.y;
	local w = h / 2;
	local col = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v);
	local col2 = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v), 25) || GetColor2(v);
	local ocol = gBool("Extra", "Autism") && HSVToColor(RealTime()*33%360,1,1) || Color(0,0,0);
	local color = team.GetColor(pm.Team(v));
	local hh = 0;

    surface.SetFont("ESPFont");
    surface.SetTextColor(255, 255, 255);


	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		local friendstatus = pm.GetFriendStatus(v);
		if (friendstatus == "friend") then
			surface.SetDrawColor(HSVToColor(RealTime()*65%360,1,1));
			surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
			surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
			surface.DrawOutlinedRect( pos.x - w / 2 + 2, pos.y - h + 2, w - 4, h - 4);
		end
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "2D Box") then
		surface.SetDrawColor(col);
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);
		surface.SetDrawColor(ocol);
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);
		hook.Remove( "HUDPaint", "3D-Box", function()
		end)
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "3D Box") then
		local eye = v:EyeAngles();
		local min, max = v:WorldSpaceAABB();
		local origin = v:GetPos();
		local friendstatus = pm.GetFriendStatus(v);
		if (friendstatus == "friend") then
			cam.Start3D()
			render.DrawWireframeBox( origin,  Angle(0, eye.y, 0), min-origin, max-origin, HSVToColor(RealTime()*65%360,1,1))
			cam.End3D()
		end
	end

	if(gBool("Visuals", "ESP", "Box") && gOption("Visuals", "ESP", "Box Type") == "3D Box") then
		hook.Add( "HUDPaint", "3D-Box", function()
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() and v:IsValid() and v:Alive() and v:Health() >= 0 then
			local eye = v:EyeAngles();
			local min, max = v:WorldSpaceAABB();
			local origin = v:GetPos();
			cam.Start3D()
				render.DrawWireframeBox( origin,  Angle(0, eye.y, 0), min-origin, max-origin, Color(255,0,0))
			cam.End3D()
		end
	end
	end)
	end

	if(gBool("Visuals", "ESP", "Healthbar")) then
		local col = Color(( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2, 0, 255);
		local hp = em.Health(v) * h / 100;
		if(hp > h) then hp = h; end
		local diff = h - hp;
		surface.SetDrawColor(0, 0, 0, 255);
		surface.DrawRect(pos.x - w / 2 - 8, pos.y - h - 1, 5, h + 2);
		surface.SetDrawColor( ( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
		surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + diff, 3, hp);
	end

	if(gBool("Visuals", "ESP", "Name")) then
        local col1 = Color(255,255,255)
		local col2 = Color(100,100,255);
		local friendstatus = pm.GetFriendStatus(v);
		draw.SimpleText(pm.Name(v), "ESPFont", pos.x, pos.y - h - 1 - (friendstatus == "friend" && 12 || 12), col1, 1, 1);
		if (friendstatus == "friend") then
		draw.SimpleText("Friend", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*65%360,1,1), 1, 1);
	end
end

	if(gBool("Visuals", "ESP", "Health Value")) then
		hh = hh + 1;
		local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2, 0);
		draw.SimpleText(em.Health(v).."HP", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0);
		hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "Weapon")) then
		hh = hh + 1;
		local w = pm.GetActiveWeapon(v);
		if(w && em.IsValid(w)) then
		local col = Color(200,150,150);
		draw.SimpleText(w:GetPrintName(), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0);
		hh = hh + 9;
		end
	end

	if(gBool("Visuals", "ESP", "Rank")) then
		hh = hh + 1;
		local col = Color(255,255,255);
		draw.SimpleText(pm.GetUserGroup(v), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0);
		hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "Ping")) then
		hh = hh + 1;
		local col1 = Color(v:Ping() * 2.55, 255 - v:Ping() - 5 * 2, 0);
		draw.SimpleText(v:Ping().."ms", "ESPFont", pos.x, pos.y - -2 + hh, col1, 1, 0);
		hh = hh + 9;
	end

	if(gBool("Visuals", "ESP", "DarkRP Money")) then
		hh = hh + 1;
		if (gmod.GetGamemode().Name == "DarkRP") then
			local col1 = Color(0,150,0);
		if (v:getDarkRPVar("money") == nil) then return end;
		local cash = v:getDarkRPVar("money")
		draw.SimpleText(cash.."$", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0);
		hh = hh + 9;
		end
	end

	if(gBool("Visuals", "ESP", "Skeleton")) then
		local col = gBool("Visuals", "ESP", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v);
		local pos = em.GetPos(v);
		for i = 0, em.GetBoneCount(v) do
			local parent = em.GetBoneParent(v, i);
			if(!parent) then continue; end
			local bonepos = em.GetBonePosition(v, i);
			if(bonepos == pos) then continue; end
			local parentpos = em.GetBonePosition(v, parent);
			if(!bonepos || !parentpos) then continue; end
			local screen1, screen2 = vm.ToScreen(bonepos), vm.ToScreen(parentpos);
			surface.SetDrawColor(gInt("Settings", "Skeleton ESP Color", "Red"), gInt("Settings", "Skeleton ESP Color", "Green"), gInt("Settings", "Skeleton ESP Color", "Blue"));
			surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y);
		end
	end

	if(gBool("Visuals", "ESP", "Health Skeleton")) then
			local origin = em.GetPos(v);
			for i = 1, em.GetBoneCount(v) do
					local parent = em.GetBoneParent(v, i);
					if(!parent) then continue; end
					local bonepos, parentpos = em.GetBonePosition(v, i), em.GetBonePosition(v, parent);
					if(!bonepos || !parentpos || bonepos == origin) then continue; end
					local bs, ps = vm.ToScreen(bonepos), vm.ToScreen(parentpos);
					local hp = em.Health(v) * h / 100;
			if(hp > h) then hp = h; end
			local diff = h - hp;
			surface.SetDrawColor(0, 0, 0, 255);
			surface.SetDrawColor( ( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255);
			surface.DrawLine(bs.x, bs.y, ps.x, ps.y);
			end
		end

	if(gBool("Visuals", "ESP", "Hit Boxes")) then
        for k,v in next, player.GetAll() do
            if(!v || !em.IsValid(v) || em.Health(v) < 1 || em.IsDormant(v) || v == me) then continue; end
            for group = 0, em.GetHitBoxGroupCount(v)do
                local count = em.GetHitBoxCount( v, group ) - 1;
                for hitbox = 0, count do
                    local bone = em.GetHitBoxBone( v, hitbox, group );
                    if(!bone) then continue; end
                   	local min, max = em.GetHitBoxBounds( v, hitbox, group );
                   	local bonepos, boneang = em.GetBonePosition( v, bone );
                    cam.Start3D();
                        render.DrawWireframeBox( bonepos, boneang, min, max, Color(gInt("Settings", "Team ESP Color", "Red"), gInt("Settings", "Team ESP Color", "Green"), gInt("Settings", "Team ESP Color", "Blue"), gInt("Settings", "Enemy ESP Color", "Red"), gInt("Settings", "Enemy ESP Color", "Green"), gInt("Settings", "Enemy ESP Color", "Blue")));
                    cam.End3D();
                end
            end
        end
    end
end

local aimtarget;
GAMEMODE:AddHook("HUDPaint", "", function()
if mode == 0 and fs then
	if not rec then
		rec = Material( 'gmod/recording.png' )
	end
	surface.SetDrawColor( color_white )
	surface.SetMaterial( rec )
	surface.DrawTexturedRect( ScrW() - 512, 0, 512, 256, 0 )
end

if mode == 1 then
	local prev
	for k, v in pairs( waypoints ) do
		local scr = v:ToScreen()
		if not scr.visible then continue end
		if prev and prev.x and prev.y then
			surface.SetDrawColor( color_white )
			surface.DrawLine( prev.x, prev.y, scr.x, scr.y )
		end
		DrawFancyBox( v, next_waypoint == k and Color(0, 225, 0) or Color(255, 0, 100) )
		prev = scr
	end
end

if(aimtarget && aimtarget:IsValid() && gBool("Ragebot", "Extra", "Snap Line")) then
		if me:Health() > 0 then
			local col = Color(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 125);
			local pos = vm.ToScreen(em.LocalToWorld(aimtarget, em.OBBCenter(aimtarget)));
			surface.SetDrawColor(col);
			surface.DrawLine(ScrW() / 2, ScrH() / 2, pos.x, pos.y);
			surface.SetDrawColor(0,0,0);
			surface.DrawOutlinedRect(pos.x -2, pos.y -2, 5, 5);
			surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"));
			surface.DrawRect(pos.x -1, pos.y -1, 3, 3);
		end
	end

	if(gBool("Visuals", "ESP", "Enable")) then
		for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 1 || v == me || pm.Team(v) == TEAM_SPECTATOR) then continue; end
		if(!Filter(v)) then continue; end
			ESP(v);
		end
	end

	if(gBool("Visuals", "ESP", "Entities")) then
		MESP();
	end

	if(gBool("Misc", "Extra", "Show Radar")) then
		RadarDraw();
	end

	if(gBool("Misc", "Extra", "Display Status")) then
		Status();
	end

	if(gBool("Misc", "Extra", "Show Spectators")) then
		spectator();
	end

	if(gBool("Visuals", "Hud Paint", "Crosshair")) then
		crosshair();
	end
end);

GAMEMODE:AddHook("RenderScreenspaceEffects", "", function()
if(!gBool("Visuals", "ESP", "Enable")) then return; end
	for k,v in next, player.GetAll() do
		if(!em.IsValid(v) || em.Health(v) < 1 || v == me || pm.Team(v) == TEAM_SPECTATOR) then continue; end
		if(!Filter(v)) then continue; end
		Chams(v);
		Xray();
	end
end);

gameevent.Listen("player_disconnect");
GAMEMODE:AddHook("player_disconnect", "", function()
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	RunConsoleCommand("say", "// [Hexa] ".."Rage quit!");
end
if(gBool("Misc", "Chat", "Spam") && gOption("Visuals", "Misc", "Spam Type") == "Taunts") then
	RunConsoleCommand("say", "rq lmao");
	end
end);
gameevent.Listen("player_spawn");
GAMEMODE:AddHook("player_spawn", "", function()
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Taunts") then
	RunConsoleCommand("say", "Prepare for rape homo!");
end
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	RunConsoleCommand("say", "Ready to get 1tapped kid?");
end
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Spawn") then
	RunConsoleCommand("say", "Hexa.nn.pe | A Garry's Mod Rage/Legit Hack");
	end
end);
paste.AddHook("OnPlayerChat", function(v, text, team)
	if (!gBool("Misc", "Chat", "Copy Messages")) then return end
	if (v ~= ply) then
		if (team) then
			ply:ConCommand("say_team '" .. text .. "' - " .. v:Nick())
		else
			ply:ConCommand("say '" .. text .. "' - " .. v:Nick())
		end
	end
end)

local playerphrases = {
	"Owned!",
	"Bodied!",
	"Smashed!",
	"Fucked!",
	"Destroyed!",
	"Annihilated!",
	"Decimated!",
	"Wrecked!",
	"Demolished!",
	"Trashed!",
	"Ruined!",
	"Murdered!",
	"Exterminated!",
	"Slaughtered!",
	"Butchered!",
	"Genocided!",
	"Executed!",
	"Bamboozled!",
}

local excuses = {
	"I lagged out wtf!",
	"Bad ping wtf!",
	"Lol wasnt looking at you.",
	"Was alt tabbed!",
	"Luck!",
	"Wow!",
	"My cat was on the keyboard.",
	"My dog was on the keyboard.",
	"Ouch!",
	"Wtf!",
	"Ok.",
	"Aimbot was off.",
	"Mouse was unplugged.",
	"Keyboard was unplugged.",
	"Monitor was unplugged.",
	"Router was unplugged.",
	"Dog was on keyboard.",
	"Antiaim wasn't even on.",
}

local taunts = {
	"Haha you fucking suck lmao!",
	"Fet owned kid!",
	"Raped aha!",
	"Get shit on!",
	"Get fuckin' bamboozled!"
}

paste.cough = {
	"ambient/voices/cough1.wav",
	"ambient/voices/cough2.wav",
	"ambient/voices/cough3.wav",
	"ambient/voices/cough4.wav",
}

local playerkills = 0;
local function entity_killed(info)
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Taunts") then
	local Entity = Entity;
	local killer = Entity(info.entindex_attacker);
	local killed = Entity(info.entindex_killed);
	local v = player.GetAll()[math.random(#player.GetAll())]
	if(killed == me) then
		RunConsoleCommand("say",  excuses[math.random(#excuses)]);
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
	RunConsoleCommand("say", taunts[math.random(#taunts)]);
end
if(gBool("Misc", "Chat", "Spam") && gOption("Misc", "Chat", "Spam Type") == "Killstreaks") then
	local Entity = Entity;
	local killer = Entity(info.entindex_attacker);
	local killed = Entity(info.entindex_killed);
	if(killed == me && playerkills > 0 && killer != me) then
		RunConsoleCommand("say",  "// [Hexa] "..killed:Nick().."'s ".."killstreak of "..playerkills.." has been ended by "..killer:Nick()..".");
		playerkills = 0
	end
	if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
		return;
	end
		playerkills = playerkills + 1
		RunConsoleCommand("say",  "// [Hexa] - "..playerphrases[math.random(#playerphrases)].." "..killed:Nick().." [".."Killstreak: "..playerkills.."]");
	end
end

local function OriginCam()
	if(!gBool("Misc", "Extra", "Show Mirror")) then return; end
	local CamData = {}
	CamData.angles = Angle(180,LocalPlayer():EyeAngles().yaw,180)
	CamData.origin = LocalPlayer():GetPos()+Vector(10,0,65)
	CamData.x = 650
	CamData.y = 0
	CamData.w = ScrW() / 3
	CamData.h = ScrH() / 5
	render.RenderView( CamData )
end
hook.Add("HUDPaint", "OriginCam", OriginCam)

function CheckTeam(v)
	if not (v:IsPlayer()) then
		return false
	end
	if (v == ply) then
		return true
	end
	if (paste.engine.ActiveGamemode() == "terrortown") then
		if (v.Detected and not ply:IsTraitor()) then
			return false
		elseif (ply:IsTraitor() and not v:IsTraitor()) then
			return false
		end
		return true
	else
		return ply:Team() == v:Team()
	end
end

function TraitorDetector()
	if (paste.engine.ActiveGamemode() ~= "terrortown") then return end
		if(gBool("Misc", "Extra", "Traitor Finder")) then
		for k, v in paste.ipairs(paste.ents.GetAll()) do
			local _v = v:GetOwner()
			if (_v == ply ) then continue end
			if (paste.GetRoundState() == 3 and v:IsWeapon() and _v:IsPlayer() and not _v.Detected and paste.table.HasValue(v.CanBuy, 1)) then
				if (_v:GetRole() ~= 2) then
					_v.Detected = true
					surface.PlaySound("npc/scanner/combat_scan1.wav")
					chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 0, 255 ), _v:Nick(), Color( 255, 255, 255 ), " is a Traitor. He just bought: ", Color( 255, 255, 0 ), v:GetPrintName())
				end
			elseif (paste.GetRoundState() ~= 3) then
				v.Detected = false
			end
		end
	end
end

function MurdererDetector()
	if not (gBool("Misc", "Extra", "Murderer Finder")) then return end
	if (paste.engine.ActiveGamemode() ~= "murder") then return end
	
	for k, v in paste.ipairs(paste.player.GetAll()) do
		if (v == ply) then continue end
		
		if (GAMEMODE.RoundStage == 1 and not v.Detected and not v.Magnum) then
			if (v:HasWeapon("weapon_mu_knife")) then
				v.Detected = true
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), (v:Nick() .. " (" .. v:GetNWString("bystanderName") .. ") is the murderer."))
			end
			
			if (v:HasWeapon("weapon_mu_magnum")) then
				v.Magnum = true
				chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "Hexa", "] ", Color( 255, 255, 255 ), (v:Nick() .. " (" .. v:GetNWString("bystanderName") .. ") has a magnum."))
			else
				v.Magnum = false
			end
		elseif (GAMEMODE.RoundStage ~= 1) then
			v.Detected = false
			v.Magnum = false
		end
	end
end

paste.AddHook("Think", function()
	TraitorDetector();
	MurdererDetector();
	AntiAFK();
	ASUS();
end)