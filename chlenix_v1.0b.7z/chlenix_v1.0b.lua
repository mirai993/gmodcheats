--[[
	MOD/lua/chlenix.lua [#2577 (#2669), 1937403967]
	collision | STEAM_0:0:33459537 <95.67.84.20:27005> | [28.11.13 01:27:47AM]
	===BadFile===
]]

-------------------------------
-- CHLENIX v666 by collision --
-------------------------------

chlenix = {}

hook.Add("PostDrawEffects", "chlenix", function()
	cam.Start3D(EyePos(), EyeAngles())
		cam.IgnoreZ(true)
		--render.OverrideDepthEnable(true, false)
		render.SuppressEngineLighting(true)
		for k, v in pairs(player.GetAll()) do
			if v:Alive() and v:GetMoveType() ~= MOVETYPE_NOCLIP then
				v:DrawModel()
				local wep = v:GetActiveWeapon()
				if IsValid(wep) then
					wep:DrawModel()
				end
			end
		end
		render.SuppressEngineLighting(false)
		cam.IgnoreZ(false)
		--render.OverrideDepthEnable(false, false)
	cam.End3D()
end)

hook.Add("HUDPaint", "chlenix", function()
	--if not LocalPlayer():Alive() then return end

	for k,v in pairs(player.GetAll()) do
		if v ~= LocalPlayer() and v:Alive() then
			local head = v:LookupBone("ValveBiped.Bip01_Head1")
			if head then
				local pos, ang = v:GetBonePosition(head)
				pos = pos:ToScreen()
				if pos.visible then
					pos.y = pos.y - 20
					draw.DrawText(v:Name(), "ChatFont", pos.x, pos.y, Color(255, 0, 255), TEXT_ALIGN_CENTER)
					draw.DrawText(v:Health() .. "HP " .. v:Armor() .. "AP", "ChatFont", pos.x, pos.y + 20, Color(255, 0, 255), TEXT_ALIGN_CENTER)
					draw.DrawText(math.Round(v:GetPos():Distance(LocalPlayer():GetPos())), "ChatFont", pos.x, pos.y + 40, Color(255, 0, 255), TEXT_ALIGN_CENTER)
				end
			end
		end
	end
end)

chlenix.marked = {}
chlenix.last_mark = 0

concommand.Add("chlenix_mark", function()
	if CurTime() < (chlenix.last_mark + 0.2) then
		chlenix.aim = not chlenix.aim
		if not chlenix.aim then
			chlenix.marked = {}
		end
	else
		local tr = LocalPlayer():GetEyeTrace()
		if IsValid(tr.Entity) and tr.Entity:IsPlayer() and tr.Entity:Alive() and not chlenix.marked[tr.Entity] then
			chlenix.marked[tr.Entity] = true
			chat.AddText("Marked ", tr.Entity)
		end
	end

	chlenix.last_mark = CurTime()
end)

hook.Add("Think", "chlenix", function()
	for k,v in pairs(chlenix.marked) do
		if not IsValid(k) or not k:Alive() then
			chlenix.marked[k] = nil
		end
	end

	if not chlenix.aim then return end
	if table.Count(chlenix.marked) == 0 then
		chlenix.aim = false
		chat.AddText("You killed everyone! Disabling hax.")
		return
	end

	local lo_hp = math.huge
	local lo_ply = NULL
	for k,v in pairs(chlenix.marked) do
		if k:Health() < lo_hp then
			lo_hp = k:Health()
			lo_ply = k
		end
	end

	local head = lo_ply:LookupBone("ValveBiped.Bip01_Head1")
	local pos, ang = lo_ply:GetBonePosition(head)
	LocalPlayer():SetEyeAngles((pos - LocalPlayer():GetShootPos()):Angle())
end)