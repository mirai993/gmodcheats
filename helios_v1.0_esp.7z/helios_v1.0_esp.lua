--[[
	lua/cl_init.lua
	sup dude | (STEAM_0:0:35901997)
	===DStream===
]]

print("[helios->Init] Chams Started");

hook.Hooks["HUDPaint"].DrawRecordingIcon = function()
	for _, v in pairs(player.GetAll()) do
		if(v:Alive() && v:Health() > 0 && v ~= LocalPlayer()) then
			helios["pcolor"] = team.GetColor(v:Team());
			cam.Start3D(EyePos(), EyeAngles());
				render.SuppressEngineLighting(true);
				render.SetBlend(0.2);
				render.MaterialOverride(Material("models/debug/debugwhite"));
				render.SetColorModulation(helios["pcolor"].r / 255, helios["pcolor"].g / 255, helios["pcolor"].b / 255);
				v:DrawModel();
				render.SuppressEngineLighting(false);
				render.MaterialOverride();
				render.SetColorModulation(1, 1, 1);
			cam.End3D();
		end
	end
end
