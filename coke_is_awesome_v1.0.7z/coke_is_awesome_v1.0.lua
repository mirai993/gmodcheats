--[[
	lua/bin/B-Hacks2.lua
	[DarkCoding] Coke_Is_Awesome | (STEAM_0:1:49986466)
	===DStream===
]]

CreateClientConVar( "aim_removeaa", 1, true, false )
CreateClientConVar( "aim_removerecoil", 1, true, false )
CreateClientConVar( "aim_silent", 0, true, false )
CreateClientConVar( "aim_removespread", 1, true, false )
CreateClientConVar( "misc_crosshair", 1, true, false )
CreateClientConVar( "misc_removelaser", 0, true, false )
CreateClientConVar( "misc_removesky", 0, true, false )
CreateClientConVar( "misc_cheats", 1, true, false )
CreateClientConVar( "misc_chatspam", 0, true, false )
CreateClientConVar( "misc_forceCVars", 1, true, false )
CreateClientConVar( "esp_info", 1, true, false )
CreateClientConVar( "esp_chams", 1, true, false )
CreateClientConVar( "esp_box", 1, true, false )
CreateClientConVar( "esp_worldwire", 0, true, false )
CreateClientConVar( "Cronus_Speedhack_Speed", 0, true, false )


local function NoSpread()                                      
if GetConVarNumber("aim_removespread") == 1 and LocalPlayer().GetActiveWeapon != nil then
local wep = LocalPlayer():GetActiveWeapon()
if wep.data then
wep.data.Recoil = 0
wep.data.Cone = 0
wep.data.Spread = 0
end
if wep.Primary then
wep.Primary.Recoil = 0
wep.Primary.Cone = 0
wep.Primary.Spread = 0
end
end
end
hook.Add("Tick", "VisualNoSpread", NoSpread)