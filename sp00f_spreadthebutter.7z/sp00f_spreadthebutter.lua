--[[
	Leaked by Fami Harukaze :^) - https://www.youtube.com/user/INTELINSIDECHANNEL
]]

require"spreadthebutter"

local me,ply = LocalPlayer()


if not ConVarExists("sp00f_bs_sv_cheats") then
	me:ConCommand("bs_spoofcvar sv_cheats")
end

if not ConVarExists("sp00f_bs_host_timescale") then
	me:ConCommand("bs_spoofcvar host_timescale")
end

timer.Simple(0.1,function()
	RunConsoleCommand("sp00f_bs_sv_cheats","1")
end)

RunConsoleCommand("sp00f_bs_host_timescale","1")
RunConsoleCommand("cl_csr_hit_effects","0")
RunConsoleCommand("cl_csr_extra_muzzle_flash","0")

local Vector,Angle = Vector,Angle

local table = table
local util = util
local input = input
local player = player

local eyepos

if not firebullets then
	firebullets = debug.getregistry().Entity.FireBullets
end

local wep = function() return me:GetActiveWeapon() end

local spreads = {["weapon_pistol"] = Vector(0.01,0.01,0),
["weapon_smg1"] = Vector(0.04362,0.04362,0),
["weapon_ar2"] = Vector(0.02618,0.02618,0),}

debug.getregistry().Entity.FireBullets = function(ent,bullet)
	if not spreads[wep():GetClass()] then
		spreads[wep():GetClass()] = bullet.Spread
	end
	return firebullets(ent,bullet)
end

local ms = me:GetAimVector():Angle()

local function mouse(c)
	ms = ms + Angle(c:GetMouseY() * 0.022,-c:GetMouseX() * 0.022,0)
	ms.p = math.Clamp(ms.p,-89,89.9)
end

local function transform(a,x)
	local b = Vector(0,0,0)
	local m1,m2,m3 = x[1],x[2],x[3]
	local vec1 = Vector(m1[1],m1[2],m1[3])
	local vec2 = Vector(m2[1],m2[2],m2[3])
	local vec3 = Vector(m3[1],m3[2],m3[3])
	b.x = a:DotProduct(vec1) + m1[4]
	b.y = a:DotProduct(vec2) + m2[4]
	b.z = a:DotProduct(vec3) + m3[4]
	return b
end

local function position(v)
	local pos
	if v:LookupBone("ValveBiped.Bip01_Head1") and v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) and v:GetBoneMatrix(v:LookupBone("ValveBiped.Bip01_Head1")) then
		local min,max = v:GetHitBoxBounds(0,0)
		matrix = v:GetBoneMatrix(v:LookupBone("ValveBiped.Bip01_Head1"))
		matrix = matrix:ToTable()
		min = transform(min,matrix)
		max = transform(max,matrix)
		pos = (min + max) * 0.5
	else
		pos = v:LocalToWorld(v:OBBCenter())
	end
	return pos + ((v:GetVelocity() * 0.00672724) - (me:GetVelocity() * 0.0087775))
end

local function insight(v,vec)
	local tr = {}
	tr.start = me:GetShootPos()
	tr.endpos = vec
	tr.filter = {v,me}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	return trace.Fraction == 1 and true or false
end

local function distance(a,b)
	return (a:GetPos() - me:GetPos()):LengthSqr() < (b:GetPos() - me:GetPos()):LengthSqr()
end




local function targets()
	local k = player.GetAll()
	table.sort(k,distance)
	for i=1,#k do
		local v = k[i]
		if v == me then continue end
		if v:Health() < 1 then continue end
		if v:GetFriendStatus() == "friend" then continue end
		//if v:Team() == me:Team() then continue end
		//if v:GetNWString("usergroup") != "user" then continue end
		if v:GetColor().a < 255 then continue end
		if v:GetMoveType() == bit.bor(MOVETYPE_NONE,MOVETYPE_OBSERVER) then continue end
		local pos = position(v)
		if not insight(v,pos) then continue end
		ply = v
		eyepos = pos
		break
	end
end


local function angles(c)
	ply = nil
	targets()
	if not ply or not input.IsKeyDown(KEY_PAD_DECIMAL) then return ms end
	local ang = (eyepos - me:GetShootPos()):Angle()
	c:SetButtons(c:GetButtons() + 1)
	return ang
end

local manip,md5,commandnumber = DS_manipulateShot, DS_md5PseudoRandom, DS_getUCMDCommandNumber

local function aimbot(c)
	me.voice_battery = 100
	mouse(c)
	local ult = angles(c)
	ult = (manip(md5(commandnumber(c)), ult:Forward(), (IsValid(wep()) and spreads[wep():GetClass()]) and -spreads[wep():GetClass()] or Vector())):Angle()
	ult.p = ult.p > 180 and ult.p - 360 or ult.p
	ult.r = 0
	c:SetViewAngles(ult)
	if me:GetMoveType() == MOVETYPE_WALK then
		local side = Vector(c:GetForwardMove(), c:GetSideMove(), 0)
		side = ((side:GetNormal()):Angle() + (ult - ms)):Forward() * side:Length()
		c:SetForwardMove(side.x)
		c:SetSideMove(side.y)
		//_nyx.Bunnyhop(c,me:OnGround())
	end
end
hook.Add("CreateMove","aimbot",aimbot)

local function calc(ply,origin,angles)
	local view = {}
	view.angles = ms
	view.vm_angles = ms
	view.origin = origin
	view.fov = 90
	return view
end
hook.Add("CalcView","calc",calc)

local SimpleText = draw.SimpleText
local GetColor = team.GetColor
local SetDrawColor = surface.SetDrawColor
local DrawLine = surface.DrawLine

local w,h = ScrW()*0.48,ScrH()*0.01


local nametime = 0
local change

local name = me:Name()
local namechange = false

local function think()
	if input.IsKeyDown(KEY_F5) and change then
		namechange = not namechange
		change = false
	end
	if not input.IsKeyDown(KEY_F5) then change = true end
	if namechange and nametime < RealTime() then
		local k = player.GetAll()
		for i=1,#k do
			local v = k[math.random(#k)]
			if string.find(me:Name(),v:Name()) == nil then
				me:ConCommand("bs_namechange "..v:Name().." ")
				break
			end
		end
		nametime = RealTime() + GetConVarNumber("sv_namechange_cooldown_seconds")
	end
end
hook.Add("Think","thinkHACKER",think)