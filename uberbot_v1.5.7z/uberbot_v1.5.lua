--[[
	Uberbot.lua
	[RR] OrangeBox | (STEAM_0:1:42239129)
	===DStream===
]]

local Version = "1.5"

local orgBot = nil
local Menu = nil

local Friends = {}

local cpsonly = CreateClientConVar( "org_cps_only", 0, true )
local only = CreateClientConVar( "org_only", "", true )
local hitman = CreateClientConVar( "org_hitman", 0, false )
local noteamkill = CreateClientConVar( "org_noteamkill", 0, true )
local flipshot = CreateClientConVar( "org_flipshot", 1, true )
local priority = CreateClientConVar( "org_priority", 1, true )
local norecoil = CreateClientConVar( "org_norecoil", 1, true )
local adminshow = CreateClientConVar( "org_showadmins", 1, true )
local adminsx = CreateClientConVar( "org_adminsx", 20, true )
local adminsy = CreateClientConVar( "org_adminsy", 20, true )
local targnpcs = CreateClientConVar( "org_targetnpcs", 0, true )
local insta = CreateClientConVar( "org_instaswap", 0, true )
local trigger = CreateClientConVar( "org_triggerbot", 0, true )
local trololo = CreateClientConVar( "org_trollbot", 0, true )
local flash = CreateClientConVar( "org_flashspam", 0, true )
local esp = CreateClientConVar( "org_esp", 1, true )

-- Localization for MOAR FPS!1!!one
local util = util
local table = table
local player = player
local ents = ents
local surface = surface
local draw = draw
local ScrW = ScrW
local ScrH = ScrH
local string = string

local _R = _R

print( "------------------" )
print( "-- org Bot  --" )
print( "------ v" .. Version .. " ------" )
print( "- By org Tiger -" )
print( "------------------\n" )

print( "For help, bind \"+orgmenu\" to a key and view the \"Help\" tab." )

local meta = _R.Player
function meta.GetHeadPos( self )
	if !ValidEntity( self ) then return end
	local bindex = self:LookupBone( "ValveBiped.Bip01_Head1" )
	local pos
	if bindex and self:GetBonePosition( bindex ) != self:GetPos() then
		pos = self:GetBonePosition( bindex ) + Vector( 0, 0, 3 )
	elseif self:GetAttachment(self:LookupAttachment("head")) and self:GetAttachment(self:LookupAttachment("head")) != self:GetPos() then
		pos = self:GetAttachment(self:LookupAttachment("head")).Pos
	else
		pos = self:GetShootPos()
	end
	
	return pos
end

function meta.GetHeadAngle( self )
	if !ValidEntity( self ) then return end
	local bindex = self:LookupBone( "ValveBiped.Bip01_Head1" )
	local ang = Angle( 0, 0, 0 )
	if bindex and self:GetBonePosition( bindex ) != self:GetPos() then
		local pos = self:GetBonePosition( bindex ) + Vector( 0, 0, 3 )
		ang = ( pos - LocalPlayer():GetShootPos() ):Angle()
	elseif self:GetAttachment(self:LookupAttachment("head")) and self:GetAttachment(self:LookupAttachment("head")) != self:GetPos() then
		ang = ( self:GetAttachment(self:LookupAttachment("head")).Pos - LocalPlayer():GetShootPos() ):Angle()
	else
		ang = ( self:GetShootPos() - LocalPlayer():GetShootPos() ):Angle()
	end
	
	return ang
end

function meta.IsFriend( self )
	if table.HasValue( Friends, self ) then
		return true
	end
	
	return false
end

local OldRecoil = meta.SetEyeAngles
-- NO RECOIL GAH SO HARD TO CODE FFFF
function meta.SetEyeAngles( self, ang )
	if norecoil:GetInt() != 1 then
		OldRecoil( self, ang )
	end
end

meta = _R.NPC
function meta.GetHeadPos( self )
	local bindex = self:LookupBone( "ValveBiped.Bip01_Head1" )
	local pos
	if bindex then
		pos = self:GetBonePosition( bindex ) + Vector( 0, 0, 3 )
	elseif self:GetAttachment(self:LookupAttachment("head")) then
		pos = self:GetAttachment(self:LookupAttachment("head")).Pos
	else
		pos = self:GetPos() + Vector( 0, 0, 10 )
	end
	
	return pos
end
-- Crypto is my lover.
function meta.GetHeadAngle( self )
	if !ValidEntity( self ) then return LocalPlayer():EyeAngles() end
	local bindex = self:LookupBone( "ValveBiped.Bip01_Head1" )
	local ang = Angle( 0, 0, 0 )
	if bindex then
		local pos = self:GetBonePosition( bindex ) + Vector( 0, 0, 3 )
		ang = ( pos - LocalPlayer():GetShootPos() ):Angle()
	elseif self:GetAttachment(self:LookupAttachment("head")) then
		ang = ( self:GetAttachment(self:LookupAttachment("head")).Pos - LocalPlayer():GetShootPos() ):Angle()
	else
		ang = ( (self:GetPos() + Vector( 0, 0, 10 )) - LocalPlayer():GetShootPos() ):Angle()
	end
	
	return ang
end
meta = nil

local w = 0
local h = 0
local admins = {}
hook.Add( "HUDPaint", "orgPaintAdmins", function()
	if adminshow:GetInt() != 1 then return end
	
	admins = {}
	surface.SetFont( "Trebuchet20" )
	w, h = surface.GetTextSize( "Admins:" )
	for k, v in pairs( player.GetAll() ) do
		if v:IsAdmin() then
			if surface.GetTextSize( v:Nick() ) > w then
				w, h = surface.GetTextSize( v:Nick() )
			end
			table.insert( admins, v )
		end
	end
	
	if #admins == 0 then return end
	
	draw.RoundedBoxEx( 4, adminsx:GetInt(), adminsy:GetInt(), w + 10, (4 + h)*(#admins + 1) + 2, Color( 255, 255, 255, 200 ), false, false, true, true )
	draw.RoundedBoxEx( 4, adminsx:GetInt() + 1, adminsy:GetInt() + 1, w + 8, (4 + h)*(#admins + 1), Color( 0, 0, 0, 200 ), false, false, true, true )
	draw.SimpleText( "Admins:", "Trebuchet22", adminsx:GetInt() + 5, adminsy:GetInt() + 1, Color( 255, 255, 0, 255 ), 0, 0 )
	
	surface.SetDrawColor( 255, 255, 0, 255 )
	surface.DrawLine( adminsx:GetInt() + 1, adminsy:GetInt() + h + 3, adminsx:GetInt() + w + 8, adminsy:GetInt() + h + 3 )
	for k, v in pairs( admins ) do
		draw.SimpleText( v:Nick(), "Trebuchet20", adminsx:GetInt() + 5, adminsy:GetInt()+2 + (4 + h)*k, Color( 255, 255, 255, 255 ), 0, 0 )
	end
end )

--[[
local font = "Default"
local pos
hook.Add( "HUDPaint", "orgPaintESP", function()
	if esp:GetInt() == 1 then
		for k, v in pairs( player.GetAll() ) do
			if v != LocalPlayer() then
				pos = v:GetShootPos():ToScreen()
				surface.SetFont( font )
				
				w, h = surface.GetTextSize( v:Nick() )
				draw.SimpleTextOutlined( v:Nick(), font, pos.x - w*.5, pos.y + 50, Color( 0, 0, 0, 255 ), 0, 0, 1, Color( 255, 255, 255, 255 ) )   
				w, h = surface.GetTextSize( v:Health() .. "%" )
				draw.SimpleTextOutlined( v:Health() .. "%", font, pos.x - w*.5, pos.y + 70, Color( 0, 0, 0, 255 ), 0, 0, 1, Color( 255, 255, 255, 255 ) )
			end
		end
	end
end )
]]--

local function NewTab()
	local Tab = vgui.Create( "DPanelList" )
	Tab:SetSize( 480, 360 )
	Tab:SetPos( 5, 5 )
	Tab:EnableHorizontal( true )
	Tab:EnableVerticalScrollbar( true )
	Tab:SetSpacing( 20 )
	Tab:SetPadding( 20 )
	
	return Tab
end

local function orgMenu()
	if Menu and Menu:IsValid() and Menu:IsVisible() then
		Menu:SetVisible( false )
		return
	elseif Menu and Menu:IsValid() and !Menu:IsVisible() then
		Menu:SetVisible( true )
		return
	end
	
	Menu = vgui.Create( "DFrame" )
	Menu:SetSize( 500, 400 )
	Menu:Center()
	Menu:SetTitle( "orgBot" )
	Menu:ShowCloseButton( false )
	Menu:MakePopup()

	local Tabs = vgui.Create( "DPropertySheet", Menu )
	Tabs:SetSize( 490, 370 )
	Tabs:SetPos( 5, 25 )
	
	local Settings = NewTab()
		local ShowAdmins = vgui.Create( "DCheckBoxLabel" )
		ShowAdmins:SetText( "Show Admins?" )
		ShowAdmins:SetSize( 220, 15 )
		ShowAdmins:SetConVar( "org_showadmins" )
		local AdminPos = vgui.Create( "DPanel" )
		AdminPos:SetSize( 200, 130 )
			local Label = vgui.Create( "DLabel", AdminPos )
			Label:SetPos( 5, 5 )
			Label:SetText( "Admin Display Coordinates:" )
			Label:SizeToContents()
			local Slider = vgui.Create( "DNumSlider", AdminPos )
			Slider:SetPos( 5, 30 )
			Slider:SetWide( 190 )
			Slider:SetText( "X Coordinate" )
			Slider:SetMin( 0 )
			Slider:SetMax( ScrW() )
			Slider:SetDecimals( 0 )
			Slider:SetConVar( "org_adminsx" )
			local Slider2 = vgui.Create( "DNumSlider", AdminPos )
			Slider2:SetPos( 5, 75 )
			Slider2:SetWide( 190 )
			Slider2:SetText( "Y Coordinate" )
			Slider2:SetMin( 0 )
			Slider2:SetMax( ScrH() )
			Slider2:SetDecimals( 0 )
			Slider2:SetConVar( "org_adminsy" )
		local CpsOnly = vgui.Create( "DCheckBoxLabel" )
		CpsOnly:SetText( "Target CPs Only? (DarkRP)" )
		CpsOnly:SetSize( 400, 15 )
		CpsOnly:SetConVar( "org_cps_only" )
		local TargNPCs = vgui.Create( "DCheckBoxLabel" )
		TargNPCs:SetText( "Target NPCs?" )
		TargNPCs:SetSize( 400, 15 )
		TargNPCs:SetConVar( "org_targetnpcs" )
		local NoRecoil = vgui.Create( "DCheckBoxLabel" )
		NoRecoil:SetText( "Enable No Recoil?" )
		NoRecoil:SetSize( 400, 15 )
		NoRecoil:SetConVar( "org_norecoil" )
		local Trigger = vgui.Create( "DCheckBoxLabel" )
		Trigger:SetText( "Enable Trigger Bot?" )
		Trigger:SetSize( 220, 15 )
		Trigger:SetConVar( "org_triggerbot" )
		local Priority = vgui.Create( "DPanel" )
		Priority:SetSize( 200, 70 )
			local Label = vgui.Create( "DLabel", Priority )
			Label:SetPos( 5, 5 )
			Label:SetText( "What is the aimbot's priority?" )
			Label:SizeToContents()
			local Slider = vgui.Create( "DNumSlider", Priority )
			Slider:SetPos( 5, 30 )
			Slider:SetWide( 190 )
			Slider:SetText( "1 for Distance, 2 for Health" )
			Slider:SetMin( 1 )
			Slider:SetMax( 2 )
			Slider:SetDecimals( 0 )
			Slider:SetConVar( "org_priority" )
		local NoTeamKill = vgui.Create( "DCheckBoxLabel" )
		NoTeamKill:SetText( "Disable Team/Job Killing?" )
		NoTeamKill:SetSize( 400, 15 )
		NoTeamKill:SetConVar( "org_noteamkill" )
		local FlipShot = vgui.Create( "DCheckBoxLabel" )
		FlipShot:SetText( "Enable Flip Shots?" )
		FlipShot:SetSize( 400, 15 )
		FlipShot:SetConVar( "org_flipshot" )
		local Insta = vgui.Create( "DCheckBoxLabel" )
		Insta:SetText( "Insta-Switch After Killing Target?" )
		Insta:SetSize( 230, 15 )
		Insta:SetConVar( "org_instaswap" )
		local Flash = vgui.Create( "DCheckBoxLabel" )
		Flash:SetText( "Activate Flash Light Spammer?" )
		Flash:SetSize( 200, 15 )
		Flash:SetConVar( "org_flashspam" )
		local Trololo = vgui.Create( "DCheckBoxLabel" )
		Trololo:SetText( "Enable Troll Bot?" )
		Trololo:SetSize( 230, 15 )
		Trololo:SetConVar( "org_trollbot" )
		local ESP = vgui.Create( "DCheckBoxLabel" )
		ESP:SetText( "Enable ESP Wallhack?" )
		ESP:SetSize( 200, 15 )
		ESP:SetConVar( "org_esp" )
		
	Settings:AddItem( ShowAdmins )
	Settings:AddItem( AdminPos )
	Settings:AddItem( CpsOnly )
	Settings:AddItem( TargNPCs )
	Settings:AddItem( NoRecoil )
	Settings:AddItem( Trigger )
	Settings:AddItem( Priority )
	Settings:AddItem( NoTeamKill )
	Settings:AddItem( FlipShot )
	Settings:AddItem( Insta )
	Settings:AddItem( Flash )
	Settings:AddItem( Trololo )
	Settings:AddItem( ESP )
	
	Tabs:AddSheet( "Settings", Settings, "gui/silkicons/check_on", false, false, "Edit the settings for the aimbot here." )

	local Friends = NewTab()
		local Panel = vgui.Create( "DPanel" )
		Panel:SetSize( 440, 299 )
			local FLab = vgui.Create( "DLabel", Panel )
			FLab:SetText( "Friends" )
			FLab:SetFont( "Trebuchet22" )
			FLab:SetTextColor( Color( 0, 255, 0, 255 ) )
			FLab:SizeToContents()
			FLab:SetPos( 70, 10 )
			local FBox = vgui.Create( "DComboBox", Panel )
			FBox:SetSize( 180, 255 )
			FBox:SetPos( 10, 35 )
			FBox:SetMultiple( true )
			FBox.Friends = {}
			FBox.Refresh = function()
				for k, v in pairs( FBox.Friends ) do
					FBox:AddItem( v )
				end
			end
			
			local ELab = vgui.Create( "DLabel", Panel )
			ELab:SetText( "Enemies" )
			ELab:SetFont( "Trebuchet22" )
			ELab:SetTextColor( Color( 255, 0, 0, 255 ) )
			ELab:SizeToContents()
			ELab:SetPos( 310, 10 )			
			local EBox = vgui.Create( "DComboBox", Panel )
			EBox:SetSize( 180, 255 )
			EBox:SetPos( 250, 35 )
			EBox:SetMultiple( true )
			EBox.Enemies = {}
			EBox.Refresh = function()
				for k, v in pairs( EBox.Enemies ) do
					EBox:AddItem( v )
				end
			end
			
			for k, v in pairs( player.GetAll() ) do
				if !v:IsFriend() and v != LocalPlayer() then
					table.insert( EBox.Enemies, v:Nick() )
					EBox:AddItem( v:Nick() )
				elseif v != LocalPlayer() then
					table.insert( FBox.Friends, v:Nick() )
					FBox:AddItem( v:Nick() )
				end
			end
			
			local FtoE = vgui.Create( "DButton", Panel )
			FtoE:SetText( ">>" )
			FtoE:SetSize( 50, 30 )
			FtoE:SetPos( 195, Panel:GetTall()*.5 - 35 )
			FtoE.DoClick = function()
				if !FBox:GetSelectedItems() or #FBox:GetSelectedItems() == 0 then return end
				for k, v in pairs( FBox:GetSelectedItems() ) do
					RunConsoleCommand( "friend", v:GetValue(1) )
					table.insert( EBox.Enemies, v:GetValue(1) )
					for a, name in pairs( FBox.Friends ) do
						if name == v:GetValue(1) then
							table.remove( FBox.Friends, a )
						end
					end
				end

				FBox:Clear()
				EBox:Clear()
				FBox:Refresh()
				EBox:Refresh()
			end
			local EtoF = vgui.Create( "DButton", Panel )
			EtoF:SetText( "<<" )
			EtoF:SetSize( 50, 30 )
			EtoF:SetPos( 195, Panel:GetTall()*.5 + 5 )
			EtoF.DoClick = function()
				if !EBox:GetSelectedItems() or #EBox:GetSelectedItems() == 0 then return end
				
				for k, v in pairs( EBox:GetSelectedItems() ) do
					RunConsoleCommand( "friend", v:GetValue(1) )
					table.insert( FBox.Friends, v:GetValue(1) )
					for a, name in pairs( EBox.Enemies ) do
						if name == v:GetValue(1) then
							table.remove( EBox.Enemies, a )
						end
					end
				end
				
				FBox:Clear()
				EBox:Clear()
				FBox:Refresh()
				EBox:Refresh()
			end
	Friends:AddItem( Panel )

	Tabs:AddSheet( "Friends", Friends, "gui/silkicons/group", false, false, "Make the aimbot avoid these people." )
	
	local Hitman = NewTab()
		local HitmanEnable = vgui.Create( "DCheckBoxLabel" )
		HitmanEnable:SetText( "Enable Hitman Mode?" )
		HitmanEnable:SetSize( 200, 15 )
		HitmanEnable:SetConVar( "org_hitman" )
		local Targs = vgui.Create( "DComboBox", Hitman )
		Targs:SetSize( 230, 240 )
		Targs:SetMultiple( false )
		Targs.Target = ""
		for k, v in pairs( player.GetAll() ) do
			if v:Nick() != Targs.Target and v:Nick() != LocalPlayer():Nick() then
				Targs:AddItem( v:Nick() )
			end
		end
		
		local oldsetvis = Menu.SetVisible
		function Menu:SetVisible( b )
			Targs:Clear()
			FBox:Clear()
			EBox:Clear()
			for k, v in pairs( player.GetAll() ) do
				if !v:IsFriend() and v != LocalPlayer() then
					EBox:AddItem( v:Nick() )
				elseif v != LocalPlayer() then
					FBox:AddItem( v:Nick() )
				end
				
				if v:Nick() != Targs.Target and v:Nick() != LocalPlayer():Nick() then
					Targs:AddItem( v:Nick() )
				else
					for k, pnl in pairs( Targs:GetItems() ) do
						if pnl:GetValue(1) == v:Nick() then
							Targs:RemoveItem( pnl )
							break
						end
					end
				end
			end
			oldsetvis( Menu, b )
		end
		
		local CurTarg = vgui.Create( "DLabel" )
		CurTarg:SetText( "Your current target is:\n\n" .. Targs.Target )
		CurTarg:SetSize( 250, 50 )
		CurTarg.Think = function()
			CurTarg:SetText( "Your current target is:\n\n" .. Targs.Target )
		end
		local Target = vgui.Create( "DButton" )
		Target:SetSize( 100, 20 )
		Target:SetText( "Set as Target" )
		Target.DoClick = function()
			if !Targs:GetSelectedItems() or #Targs:GetSelectedItems() == 0 then return end
			Targs.Target = Targs:GetSelectedItems()[1]:GetValue(1)
			RunConsoleCommand( "org_only", Targs.Target )
		end
		local Dummy = vgui.Create( "DLabel" )
		Dummy:SetText( "" )
		Dummy:SetSize( 250, 40 )

	Hitman:AddItem( HitmanEnable )
	Hitman:AddItem( Targs )
	Hitman:AddItem( CurTarg )
	Hitman:AddItem( Dummy )
	Hitman:AddItem( Dummy )
	Hitman:AddItem( Dummy )
	Hitman:AddItem( Target )
	
	Tabs:AddSheet( "Hitman", Hitman, "gui/silkicons/user", false, false, "Make the aimbot only go for a specific person/team." )
	
	local Help = NewTab()
		local Text = vgui.Create( "DLabel" )
		Text:SetText( "Hello, and welcome to org Bot v" .. Version .. "!\n\nYou are probably ready to get started using this aimbot, so here are a few\nthings you need to know...\n\n1. I'm not responsible if you get banned.\n2. This aimbot only works on servers not using script enforcer\n3. This aimbot is constantly indev, so it may be broken sometimes.\n\nThe command you'll want to bind to use the aimbot is '+org'.\nYou can adjust the settings on targeting players in the settings tab.\n\nHave fun pissing people off!\n\norg Tiger - Coder" )
		Text:SizeToContents()
	Help:AddItem( Text )
	
	Tabs:AddSheet( "Help", Help, "gui/silkicons/magnifier", false, false, "Confused? Want some advice? Look here." )
end

concommand.Add( "+orgmenu", function()
	orgMenu()
end )

concommand.Add( "-orgmenu", function()
	orgMenu()
end )

concommand.Add( "friend", function( p, c, a )
	local friend = a[1]
	
	if friend == "print" then
		PrintTable( Friends )
		return
	end
	
	for _, v in ipairs( player.GetAll() ) do
		if string.find( string.lower( v:Nick() ), string.lower( friend ) ) then
			if !table.HasValue( Friends, v ) then
				table.insert( Friends, v )
			else
				for a, b in pairs( Friends ) do
					if b == v then
						table.remove( Friends, a )
					end
				end
			end
		end
	end
end )

_G.SafeBot = _R["CUserCmd"].SetViewAngles -- To dodge those simple anti-cheats.

local function Requirements()
	if (trololo:GetInt() != 1 and !orgBot) or (#player.GetAll() < 2 and targnpcs:GetInt() != 1) then
		return false
	end
	
	return true
end

--[[
local function AllButTarg( target )
	local tbl = {}
	
	-- Always filter players
	for k, v in pairs( player.GetAll() ) do
		if v != target then
			table.insert( tbl, v )
		end
	end

	for k, v in pairs( ents.FindByClass( "npc_*" ) ) do
		if v != target then
			table.insert( tbl, v )
		end
	end
	
	return tbl
end
]]--

local function FindTargets()
	local targs = {}
	
	local tr = {}
	local trace
	for k, v in pairs( player.GetAll() ) do
		if v:Alive() and !v:InVehicle() and v != LocalPlayer() then
			tr.start = LocalPlayer():GetShootPos()
			tr.endpos = v:GetHeadPos()
			tr.mask = MASK_SHOT
			
			trace = util.TraceLine( tr )

			if ValidEntity( trace.Entity ) and (trace.Entity:IsPlayer() or trace.Entity:IsNPC()) then
				table.insert( targs, v )
			end
		end
	end
	
	return targs
end

local function FindNPCTargets()
	local targs = {}
	
	local tr = {}
	local trace
	for k, v in pairs( ents.FindByClass( "npc_*" ) ) do
		tr.start = LocalPlayer():GetShootPos()
		tr.endpos = v:GetHeadPos()
		tr.mask = MASK_SHOT
			
		trace = util.TraceLine( tr )

		if ValidEntity( trace.Entity ) and (trace.Entity:IsPlayer() or trace.Entity:IsNPC()) then
			table.insert( targs, v )
		end
	end
	
	return targs
end

local function GetTargetByName( target, VTargs )
	for k, v in pairs( VTargs ) do
		if v:Nick() == target then
			return v
		end
	end
	
	return nil
end

local function GetBestTarget( VTargs )
	local best
	local winning = 10000
	
	if priority:GetInt() == 2 then
		for k, v in pairs( VTargs ) do
			if v:Health() < winning and (flipshot:GetInt() == 1 or v:GetPos():ToScreen().visible) and (v:IsNPC() or !v:IsFriend() and (noteamkill:GetInt() != 1 or v:Team() != LocalPlayer():Team())) then
				best = v
				winning = v:Health()
			end
		end
	else
		for k, v in pairs( VTargs ) do
			if LocalPlayer():GetShootPos():Distance( v:GetHeadPos() ) < winning and (flipshot:GetInt() == 1 or v:GetPos():ToScreen().visible) and (v:IsNPC() or !v:IsFriend() and (noteamkill:GetInt() != 1 or v:Team() != LocalPlayer():Team())) then
				best = v
				winning = LocalPlayer():GetShootPos():Distance( v:GetHeadPos() )
			end
		end
	end
	
	return best
end

local function GetBestCPTarget( VTargs )
	local cps = {}
	for k, v in pairs( VTargs ) do
		if v:Team() == TEAM_POLICE or v:Team() == TEAM_MAYOR then
			table.insert( cps, v )
		end
	end
	
	return GetBestTarget( cps )
end

local InChat = false
hook.Add( "StartChat", "orgFSpam", function()
	InChat = true
end )
hook.Add( "FinishChat", "orgFSpam", function()
	InChat = false
end )

local ValidTargets, T
local Switch = true
hook.Add( "CreateMove", "orgBot", function( ucmd )
	if flash:GetInt() == 1 and input.IsKeyDown( KEY_F ) and !InChat then
		RunConsoleCommand( "impulse", "100" )
	end
	
	if !Requirements() then return end
	ValidTargets = FindTargets()
	
	if (insta:GetInt() == 1 or (insta:GetInt() != 1 and !T)) then
		if hitman:GetInt() == 1 and only:GetString() != "" then
			T = GetTargetByName( only:GetString(), ValidTargets )
		elseif cpsonly:GetInt() == 1 then
			T = GetBestCPTarget( ValidTargets )
		else
			if targnpcs:GetInt() == 1 then
				table.Merge( ValidTargets, FindNPCTargets() )
			end
			T = GetBestTarget( ValidTargets )
		end
	end
		
	if !T then return end
	
	SafeBot( ucmd, T:GetHeadAngle() )
	
	if trigger:GetInt() == 1 and (T:IsNPC() or T:Alive()) then
		if Switch then
			RunConsoleCommand( "+attack" )
			Switch = !Switch
		else
			RunConsoleCommand( "-attack" )
			Switch = !Switch
		end
	end
end )

local Overlay = CreateMaterial( "PlayerOverlay", "UnlitGeneric", { [ "$basetexture" ] = "models/debug/debugwhite" } )
local tr = {}
hook.Add( "PostDrawOpaqueRenderables", "orgBot", function()
	if esp:GetInt() != 1 then return end
	
	cam.Start3D( EyePos(), EyeAngles() )
 
	// First we clear the stencil and enable the stencil buffer
	render.ClearStencil()
	render.SetStencilEnable( true )
 
	// First we set every pixel with the prop + outline to 1
	render.SetStencilFailOperation( STENCILOPERATION_KEEP )
	render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
	render.SetStencilReferenceValue( 1 )
 
	for _, ent in pairs( player.GetAll() ) do
		if ent:Alive() then
			ent:DrawModel()
		end
	end
	
	// Now we set every pixel with only the prop to 2
	render.SetStencilReferenceValue( 2 )

	for _, ent in pairs( player.GetAll() ) do
		if ent:Alive() then
			ent:DrawModel()
		end
	end
	
	// Now we only draw the pixels with a value of 1 black, which are the pixels with only the outline
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_LESS )
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
	render.SetStencilReferenceValue( 1 )
 
	render.SetMaterial( Overlay )
	render.DrawScreenQuad()
 
	// Disable the stencil buffer again
	render.SetStencilEnable( false )
 
	cam.End3D()
end )

concommand.Add( "+org", function()
	T = nil
	orgBot = true
end )

concommand.Add( "-org", function()
	orgBot = false
	
	if !Switch then 
		RunConsoleCommand( "-attack" ) 
		Switch = !Switch
	end 
end )