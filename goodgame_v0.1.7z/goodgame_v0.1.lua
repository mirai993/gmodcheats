if QAC then 	local printShit = true  	local hooker = hook.GetTable 	local receive = net.Receive 	local sendtoserv = net.SendToServer 	local writeint = net.WriteInt 	local writebit = net.WriteBit  	local start = net.Start  	local hairs = pairs 	local undack = unpack  	local info = debug.getinfo  	local shitfunc = function()  	end  	local shitfunc2 = function()  		local poop = net.ReadInt(10) 		 		start("Debug1") 			 		net.WriteInt(poop, 16) 			 		sendtoserv()  		if ( not printShit ) then return end  	end   	hooker()["Think"]["penis"] = function()  		hook.Remove("OnGamemodeLoaded", "___scan_g_init") 		hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc 		receive("Debug2", shitfunc2) 		receive("gcontrol_vars", shitfunc) 		receive("control_vars", shitfunc) 		receive("checksaum", shitfunc)  		net.Receivers["Debug2"] = shitfunc2 		net.Receivers["gcontrol_vars"] = shitfunc 		net.Receivers["control_vars"] = shitfunc 		net.Receivers["checksaum"] = shitfunc  	end  	hook.Remove("OnGamemodeLoaded", "___scan_g_init") 	hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc 	receive("Debug2", shitfunc2) 	receive("gcontrol_vars", shitfunc) 	receive("control_vars", shitfunc) 	receive("checksaum", shitfunc)  	net.Receivers["Debug2"] = shitfunc2 	net.Receivers["gcontrol_vars"] = shitfunc 	net.Receivers["control_vars"] = shitfunc 	net.Receivers["checksaum"] = shitfunc   	start("gcontrol_vars")     		writebit() 	sendtoserv()  	function pairs( ... )  		local tbl = { ... } 		 		local dbg = info(2) 		if ( dbg ) then 			local src = dbg.short_src 			if src:find("cl_qac") then 				return hairs( { } ) 			end 			 		end 		 		return hairs(undack(tbl)) 	end end

local GG = {}

GG.Use_print_func = GG.Use_print_func or function() end

if debug.getinfo(print).short_src == "[C]" then
	GG.Use_print_func = print
elseif debug.getinfo(Msg).short_src == "[C]" then
	GG.Use_print_func = Msg
end

GG.Use_print_func("-----------------------")
GG.Use_print_func("-[Good Game] -Starting-")
GG.Use_print_func("-----------------------")

GG.Plugin_Name = "Plugin Loaded"

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " GG Table Init")

GG.WP = {}
GG.WP['Aimbot'] = true
GG.WP['Big_Aimbot'] = false
GG.WP.StoreTarg = {}

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " Well Played Loaded")

GG.ply = FindMetaTable("Player")
function GG.ply:EyeObstructed(ent)
	if (!IsValid(ent)) then return end
	local trace = {start = self:LocalToWorld(self:OBBCenter()), endpos = ent:LocalToWorld(ent:OBBCenter()), filter = {self, ent}, mask = 1174421507};
    local tr = util.TraceLine(trace);
    return (tr.Fraction == 1);
end

GG.Targ = function()
	
	if GG.WP['Big_Aimbot'] == true then
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() then
				table.insert(GG.WP.StoreTarg, v)
			end
		end
		
		local targ = LocalPlayer():GetEyeTrace().Entity
		
		if targ and !targ:IsPlayer() then return end
		
		return targ
	end
	
	if GG.WP['Big_Aimbot'] == false then

		if #GG.WP.StoreTarg > #player.GetAll() - 1 then GG.WP.StoreTarg = {} end
		
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() and LocalPlayer():EyeObstructed(v) and v:Health() > 0 then
				table.insert(GG.WP.StoreTarg, v)
			end
		end
		
		return table.Random(GG.WP.StoreTarg)
		
	end
	
	
end

GG.Rand = function(tbl)
	return tbl[math.random(1,#tbl)]
end

local target = NULL

function GAMEMODE:CreateMove( uc ) 
	local wep = LocalPlayer():GetActiveWeapon()
	if not string.find(string.lower(wep:GetClass()),"weapon_") then return end
	if wep and wep:Clip1() <= 0 then
		RunConsoleCommand("+reload")
		timer.Simple(0.2, function() RunConsoleCommand("-reload") end)
	end
	if uc:KeyDown(IN_SPEED) and GG.WP['Aimbot'] == true and GG.WP['Big_Aimbot'] == true then
		target = GG.Targ()
	end
	if uc:KeyDown(IN_ATTACK) and GG.WP['Aimbot'] == true then
		if GG.WP['Big_Aimbot'] == false then
			target = GG.Targ()
		end
		if target ~= nil and target ~= NULL and target:Health() > 0 then
			local targethead = target:LookupBone(GG.Rand({"ValveBiped.Bip01_Spine","ValveBiped.Bip01_Neck1"}))
			if targethead ~= nil then
				local targetheadpos,targetheadang = target:GetBonePosition(targethead)
				if LocalPlayer():EyeObstructed(target) and target:IsPlayer() then
					if wep.Primary ~= nil then
						wep.Primary.Recoil = 0
						wep.Primary.Cone = 0
					end
					uc:SetViewAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
				end
			end		
		end
	end
end

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " CreateMove Created")


function GAMEMODE:CalcView( ply, pos, ang, fov )
	local view = {}

    view.origin = pos-( ang:Forward()*120 )
    view.angles = ang - Angle(0,0,0)
    view.fov = 50
 
    return view
end 

function GAMEMODE:ShouldDrawLocalPlayer()
	return true
end

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name.. " CalcView Created")

GG.Use_print_func("-----------------")
GG.Use_print_func("[Good Game] -End-")
GG.Use_print_func("-----------------")

GG.Url = "https://dl.dropboxusercontent.com/u/17743302/update.txt"
GG.Version = 0.1
http.Fetch(GG.Url, function(c) 
local ver = string.Explode(" ",c)

if GG.Version != tonumber(ver[1]) then
	print("Your version is out of date download newest here.. "..tostring(ver[2]))
	else
	print("Your version is up to date")
end 

end, function(err) print(err) end)