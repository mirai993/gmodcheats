local SetMaterialOverride = SetMaterialOverride
local RunConsoleCommand = RunConsoleCommand
local IsValid = IsValid
local render = render
local Angle = Angle
local input = input
local timer = timer
local table = table
local pairs = pairs
local util = util
local hook = hook
local team = team
local math = math
local cam = cam

lolwut = {}
lolwut.LightKey = function() return input.IsKeyDown(KEY_V) end
lolwut.AimKey = function() return input.IsKeyDown(KEY_B) end
lolwut.SpinKey = function() return input.IsKeyDown(KEY_N) end
lolwut.ShootKey = function() return input.IsMouseDown(MOUSE_4) end
lolwut.prefbone = "ValveBiped.Bip01_Head1"
lolwut.maxdist = 65535

lolwut.lp = LocalPlayer()
lolwut.lastangle = nil
lolwut.fakeview = false
lolwut.lighton = false
lolwut.trignore = {lolwut.lp,lolwut.lp:GetActiveWeapon()}

lolwut.bpos = function(ent, bone) return ent:GetBonePosition(ent:LookupBone(bone)) end
lolwut.bdist = function(ent, bone) return lolwut.lp:GetShootPos():Distance(lolwut.bpos(ent,bone)) end
lolwut.dist = function(ply) return lolwut.lp:GetShootPos():Distance(ply:GetShootPos()) end
lolwut.etre = function(ply) return ply:GetEyeTrace().Entity end

lolwut.closest = function(a, b) return lolwut.bdist(a, lolwut.prefbone) < lolwut.bdist(b, lolwut.prefbone) end
lolwut.quickest = function(a, b) return (a.Health and a:Health() or 0) < (b.Health and b:Health() or 0) end
lolwut.looking = function(a, b)
	if (lolwut.etre(a) == lolwut.lp and lolwut.etre(b) ~= lolwut.lp) then return a
	elseif (lolwut.etre(a) ~= lolwut.lp and lolwut.etre(b) == lolwut.lp) then return b
	else return table.Random({a,b}) end
end

lolwut.visible = function(pos,ent)
	local tr = util.TraceLine({start=lolwut.lp:GetShootPos(),
		endpos=lolwut.lp:GetShootPos()+((pos - lolwut.lp:GetShootPos())*lolwut.maxdist),
		ilter=lolwut.trignore, mask=MASK_SHOT})
	return tr.HitNonWorld and tr.Hit and IsValid(tr.Entity) and ((ent ~= nil) and (tr.Entity == ent) or true)
end
lolwut.pvalid = function(ply) return IsValid(ply) and ply:Alive() and ply ~= lolwut.lp and ply:Team() ~= lolwut.lp:Team() end
lolwut.esppvalid = function(ply) return IsValid(ply) and ply:Alive() and ply ~= lolwut.lp end
lolwut.keysnotdown = function(keys) for k,v in pairs(keys) do if input.IsKeyDown(v) then return false end end return true end
lolwut.mousesnotdown = function(keys) for k,v in pairs(keys) do if input.IsMouseDown(v) then return false end end return true end
lolwut.notmoving = function() return lolwut.keysnotdown({KEY_W,KEY_A,KEY_S,KEY_D,KEY_SPACE,KEY_LCONTROL,KEY_LSHIFT,KEY_LALT}) and
	lolwut.mousesnotdown({MOUSE_LEFT, MOUSE_RIGHT, MOUSE_MIDDLE, MOUSE_4, MOUSE_5}) end
lolwut.fakeshot = function(func)
	func("+attack")
	local delay = lolwut.lp:GetActiveWeapon().PrimaryDelay or nil
	if (delay == nil) then delay = (lolwut.lp:GetActiveWeapon().Primary and lolwut.lp:GetActiveWeapon().Primary.Delay or 0.1) end
	timer.Simple(delay, func, "-attack")
end
lolwut.CrossbowFix = function(aimpos, target)
	if (lolwut.lp:GetActiveWeapon().GetPrintName ~= nil) then
		if (lolwut.lp:GetActiveWeapon():GetPrintName() == "#HL2_Crossbow") then
			local angp = math.sin((aimpos - lolwut.lp:GetShootPos()):Angle().p)
			aimpos = aimpos + Vector(0,0, (lolwut.dist(target) / 244.286) + angp)
			return aimpos
		end
	end
	return aimpos
end
lolwut.fakelight = function(ent, pos, color, size, brightness)
	local l = DynamicLight(ent:EntIndex())
	if l then
		l.Pos = pos
		l.r = color.r
		l.g = color.g
		l.b = color.b
		l.Brightness = brightness
		l.Decay = size * 5
		l.Size = size
		l.DieTime = CurTime() + 1
	end
end

lolwut.calcview = function(ply, pos, ang, fov)
	if lolwut.LightKey() then lolwut.lighton = not lolwut.lighton end
	if lolwut.lighton then
		local lpos = lolwut.lp:GetEyeTrace().HitPos
		lolwut.fakelight(lolwut.lp, lpos, Color(255,255,255), 64*2, 6)
	end
	
	if lolwut.AimKey() then
		if input.IsKeyDown(KEY_DELETE) then
			hook.Remove("CalcView", "lolwut1")
			hook.Remove("PostDrawOpaqueRenderables", "lolwut2")
		end
		
		local possible = {} for k,v in pairs(player.GetAll()) do
			if lolwut.pvalid(v) and lolwut.visible(lolwut.GetAimPos(v),v) then table.insert(possible, v) end
		end
		table.sort(possible, lolwut.closest)
		if input.IsMouseDown(MOUSE_5) then
			table.sort(possible, lolwut.quickest)
		end
		local closest = possible[1]
		
		if IsValid(closest) then
			if (lolwut.lastangle == nil) then lolwut.lastangle = lolwut.lp:EyeAngles() end
			local aimpos = lolwut.CrossbowFix(lolwut.GetAimPos(closest), closest)
			local ang = (aimpos - lolwut.lp:GetShootPos()):Angle()
			lolwut.lp:SetEyeAngles(ang)
			if lolwut.ShootKey() then
				local x = {origin = pos, angles = lolwut.lastangle, fov = fov}
				lolwut.fakeshot(RunConsoleCommand)
				return x
			else lolwut.lastangle = nil end
		else lolwut.lastangle = nil end
	elseif lolwut.SpinKey() and lolwut.notmoving() then
		lolwut.fakeview = true
		if (lolwut.lastangle == nil) then lolwut.lastangle = lolwut.lp:EyeAngles() end
		local x = {origin = pos, angles = lolwut.lastangle, fov = fov}
		lolwut.lp:SetEyeAngles(Angle(math.random(-180,180), math.random(-180,180), math.random(-180,180)))
		return x
	else
		if (lolwut.fakeview == true) then
			lolwut.lp:SetEyeAngles(lolwut.lastangle)
			lolwut.fakeview = false
		end
		lolwut.lastangle = nil
	end
end
hook.Add("CalcView", "lolwut1", lolwut.calcview)

lolwut.getcm = function(ent)
	if ent:IsPlayer() then
		local tc = team.GetColor(ent:Team())
		if (tc.a < 50) then return 1, 1, 1 end
		return tc.r/255, tc.g/255, tc.b/222
	else return 1, 0, 0 end
end

lolwut.matwhite = CreateMaterial("WhiteMaterial", "VertexLitGeneric", {
	['$basetexture'] = 'color/white', ['$vertexalpha'] = '1', ['$model'] = '1'
});

lolwut.pdor = function()
	render.ClearStencil()
	render.SetStencilEnable(true)
	render.SetStencilFailOperation(STENCILOPERATION_KEEP)
	render.SetStencilPassOperation(STENCILOPERATION_KEEP)
	render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
	render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
	
	render.SetStencilReferenceValue(1)
	render.SetBlend(0.9) --CLOSE ENOUGH
		for k,v in pairs(player.GetAll()) do
			if lolwut.esppvalid(v) then
				local r,g,b = lolwut.getcm(v)
				render.SetColorModulation(r or 1,g or 0,b or 0)
					SetMaterialOverride(lolwut.matwhite)
						v:DrawModel()
					SetMaterialOverride()
				render.SetColorModulation(1,1,1)
			end
		end
	render.SetBlend(1)
	
	render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
	render.SuppressEngineLighting(true)
		cam.IgnoreZ(true)
			for k,v in pairs(player.GetAll()) do
				if lolwut.esppvalid(v) then
					local r,g,b = lolwut.getcm(v)
					render.SetColorModulation(r or 1,g or 0,b or 0)
						SetMaterialOverride(lolwut.matwhite)
							v:DrawModel()
						SetMaterialOverride()
					render.SetColorModulation(1,1,1)
				end
			end
		cam.IgnoreZ(false)
	render.SuppressEngineLighting(false)
	render.SetStencilEnable(false)
end
hook.Add("PostDrawOpaqueRenderables", "lolwut2", lolwut.pdor)

lolwut.GetAimPos = function(ent)
	local exp = string.Explode('/', string.lower(ent:GetModel()))
	if (#exp ~= 3) then
		if ent:IsPlayer() or ent:IsNPC() then
			return lolwut.bpos(ent, lolwut.bones['default'])
		else
			return ent:LocalToWorld(ent:OBBCenter())
		end
	end
	if (lolwut.bones['mdl:'..exp[3]] ~= nil) then
		return lolwut.bpos(ent, lolwut.bones['mdl:'..exp[3]])
	elseif (lolwut.bones['folder:'..exp[2]] ~= nil) then
		return lolwut.bpos(ent, lolwut.bones['folder:'..exp[2]])
	else
		return lolwut.bpos(ent, lolwut.bones['default'])
	end
end

lolwut.bones = {
	['default'] = "ValveBiped.Bip01_Head1",
	['folder:zombie'] = "ValveBiped.HC_Body_Bone",
	['mdl:fast.mdl'] = "ValveBiped.HC_BodyCube",
	['mdl:poison.mdl'] = "ValveBiped.Headcrab_Cube1",
	['mdl:manhack.mdl'] = "Manhack.MH_Control",
	['mdl:combine_scanner.mdl'] = "Scanner.Body",
	['mdl:barnacle.mdl'] = "Barnacle.innards",
	['mdl:combine_helicopter.mdl'] = "Chopper.Body",
	['mdl:combine_strider.mdl'] = "Combine_Strider.Body_Bone",
	['mdl:combine_dropship.mdl'] = "D_ship.Pelvis",
	['mdl:gunship.mdl'] = "Gunship.Body",
	['mdl:pigeon.mdl'] = "Crow.Head"
}