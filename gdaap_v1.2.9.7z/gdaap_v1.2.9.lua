if SERVER then
	return 
end

require("sourcenetinfo")
if NVMLBNZG then
	NVMLBNZG = false
else
	NVMLBNZG = true
	local GD = {  }
	if not DMQTWKVD then
		DMQTWKVD = true
		local function duplicateTable(tbl, lookup)
			local copy = {  }
			for i, v in _G.pairs(tbl) do
				if _G.type(v) == "table" then
					lookup = lookup or {  }
					lookup[tbl] = copy
					if lookup[v] then
						copy[i] = lookup[v]
					else
						copy[i] = duplicateTable(v, lookup)
					end

				else
					copy[i] = _G.rawget(tbl, i)
				end

			end

			local mt = _G.getmetatable(tbl)
			if mt then
				_G.setmetatable(copy, mt)
			end

			return copy
		end

		CJYFRGRU = _G.net
		KZZXWPOY = _G.file
		KYMZLAIJ = _G.hook
		LJDXTFRX = _G.GetConVar
		DSRWCZIH = _G.GetConVarString
		DRABNBKN = _G.GetConVarNumber
		YSIYYVSC = _G.ConCommand
		AOTHCTBF = _G.RunConsoleCommand
		HCTEYRVK = duplicateTable(_G)
		local g = HCTEYRVK
		g.setmetatable(_G, { __index = function(t, k)
			if k == "RunConsoleCommand" then
				return g.RunConsoleCommand
			end

			if k == "net" then
				return g.net
			end

			if k == "hook" then
				return g.hook
			end

			if k == "GetConVar" then
				return g.GetConVar
			end

			if k == "GetConVarString" then
				return g.GetConVarString
			end

			if k == "GetConVarNumber" then
				return g.GetConVarNumber
			end

			if k == "file" then
				return g.file
			end

			if k == "error" or k == "Error" then
				return g.error
			end

		end, __metatable = true })
		g.rawset(_G, "RunConsoleCommand", g.RunConsoleCommand)
		g.rawset(_G, "hook", g.hook)
		g.rawset(_G, "GetConVar", g.GetConVar)
		g.rawset(_G, "GetConVarString", g.GetConVarString)
		g.rawset(_G, "GetConVarNumber", g.GetConVarNumber)
		g.rawset(_G, "file", g.file)
		g.rawset(_G, "error", g.error)
		g.rawset(_G, "Error", g.error)
		g.rawset(usermessage, "__metatable", false)
		g.rawset(usermessage, "IncomingMessage", g.umsgInc)
		g.setmetatable(usermessage, { __index = function(t, k)
			if k == "IncomingMessage" then
				return g.umsgInc
			end

		end, __metatable = true })
		file = nil
		net = nil
		hook = nil
		RunConsoleCommand = nil
	end

	if QAC then
		local hooker = hook.GetTable
		local receive = net.Receive
		local sendtoserv = net.SendToServer
		local readint = net.ReadInt
		local writeint = net.WriteInt
		local writebit = net.WriteBit
		local start = net.Start
		local prant = print
		local hairs = pairs
		local undack = unpack
		local info = debug.getinfo
		local shitfunc = function()
			if GD.bools["logbypass"] and NVMLBNZG then
				GD:LogAction("[QAC Bypass]: Blocked cvar check")
			end

		end
		local shitfunc2 = function()
			local poop = readint(10)
			start("Debug1")
			writeint(poop, 16)
			sendtoserv()
			if GD.bools["logbypass"] and NVMLBNZG then
				GD:LogAction("[QAC Bypass]: Spoofed Ping")
			end

		end
		hooker()["Think"]["penis"] = function()
			hook.Remove("OnGamemodeLoaded", "___scan_g_init")
			hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc
			receive("Debug2", shitfunc2)
			receive("gcontrol_vars", shitfunc)
			receive("control_vars", shitfunc)
			receive("checksaum", shitfunc)
			net.Receivers["Debug2"] = shitfunc2
			net.Receivers["gcontrol_vars"] = shitfunc
			net.Receivers["control_vars"] = shitfunc
			net.Receivers["checksaum"] = shitfunc
		end
		hook.Remove("OnGamemodeLoaded", "___scan_g_init")
		hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc
		receive("Debug2", shitfunc2)
		receive("gcontrol_vars", shitfunc)
		receive("control_vars", shitfunc)
		receive("checksaum", shitfunc)
		net.Receivers["Debug2"] = shitfunc2
		net.Receivers["gcontrol_vars"] = shitfunc
		net.Receivers["control_vars"] = shitfunc
		net.Receivers["checksaum"] = shitfunc
		start("gcontrol_vars")
		writebit()
		sendtoserv()
		function pairs(...)
			local tbl = { ... }
			local dbg = info(2)
			if (dbg) then
				local src = dbg.short_src
				if src:find("cl_qac") then
					return hairs({  })
				end

			end

			return hairs(undack(tbl))
		end

	end

	local g = HCTEYRVK
	GD.hooks = {  }
	GD.version = "1.2.9"
	local function AddHook(type, Function)
		local name = type .. "-" .. g.math.random(1, 1000), g.math.random(1, 2000), g.math.random(1, 3000) .. "PFWTZGVK"
		GD:LogAction("[ADDED] Hook: [" .. type .. "] | Name: " .. name)
		GD.hooks[type] = name
		return KYMZLAIJ.Add(type, name, Function)
	end

	local function RemoveHook(type, name)
		GD:LogAction("[REMOVED] Hook: [" .. type .. "]")
		GD.hooks[type] = nil
		return KYMZLAIJ.Remove(type, name)
	end

	local function oldWrite(name, contents)
		local f = ZQZBWTZI.Open(name, "w", "DATA")
		if not f then
			return 
		end

		f:Write(contents)
		f:Close()
	end

	local function oldRead(name)
		local f = ZQZBWTZI.Open(name, "r", "DATA")
		if not f then
			return 
		end

		local str = f:Read(f:Size())
		f:Close()
		if not str then
			str = ""
		end

		return str
	end

	red = g.Color(255, 0, 0, 255)
	black = g.Color(0, 0, 0, 255)
	green = g.Color(0, 255, 0, 255)
	white = g.Color(255, 255, 255, 255)
	blue = g.Color(0, 0, 255, 255)
	cyan = g.Color(0, 255, 255, 255)
	pink = g.Color(255, 0, 255, 255)
	blue = g.Color(0, 0, 255, 255)
	grey = g.Color(100, 100, 100, 255)
	gold = g.Color(255, 228, 0, 255)
	lblue = g.Color(155, 205, 248)
	lgreen = g.Color(174, 255, 0)
	iceblue = g.Color(116, 187, 251, 255)
	function GD:ConnectToServer(request, ontrue, onfalse)
		local parameters = {  }
		parameters["hwid"] = "DCB21165C64C4D29402EFE92363AE1FF"
		parameters["os"] = "Win7 64 Bit"
		parameters["computername"] = "JACKGT683TWO-PC"
		parameters["version"] = "1.3.7"
		parameters["uid"] = "11"
		parameters["sessionid"] = "478855232335"
		parameters["scriptid"] = "1"
		if request ~= "" then
			if g.type(request) == "table" then
				for k, v in g.pairs(request) do
										if v == true then
						v = "true"
					elseif v == false then
						v = "false"
					end

					parameters[k] = v
				end

			else
				parameters[request] = ""
			end

			g.http.Post(g.string.char(104, 116, 116, 112, 58, 47, 47, 100, 97, 97, 112, 46, 100, 107, 47, 103, 68, 97, 97, 112, 47, 103, 101, 116, 100, 97, 116, 97, 46, 112, 104, 112), parameters, function(body, len, headers, code)
				if body ~= g.string.char(102, 97, 108, 115, 101) then
					if g.type(ontrue) == "function" then
						ontrue(body)
					end

				else
					if g.type(onfalse) == "function" then
						onfalse(body)
					end

				end

			end, function(code)
				GD:Print("Failed to connect to server", red)
			end)
		else
			return parameters
		end

	end

	function GD:StartScript()
		GD.confocus = false
		GD.menuopen = false
		GD.nextreload = g.CurTime()
		GD.curtarg = nil
		GD.meta = g.FindMetaTable("Player")
		GD.IsFiring = false
		GD.fullbright = false
		GD.checksvcheatconfirm = false
		GD.checksvcheatchecking = false
		GD.nosmoke = false
		GD.typing = false
		GD.attacking = false
		GD.activetab = nil
		GD.configsloaded = false
		GD.lastadvert = nil
		GD.updatechat = true
		GD.updatechatlist = true
		GD.updateonline = true
		GD.chatloaded = false
		GD.usersloaded = false
		GD.adminl = {  }
		GD.spectators = {  }
		GD.menuitems = {  }
		GD.log = {  }
		GD.users = {  }
		GD.seenusers = {  }
		GD.seeninserver = {  }
		GD.chat = {  }
		GD.seenchat = {  }
		GD.lastmapvalue = 0
		GD.speedhackison = false
		GD.traitors = {  }
		GD.Radar = {  }
		GD.RadarColTabSize = 0
		GD.RadarColKey = {  }
		GD.mappress = false
		GD.tppress = false
		GD.menupress = false
		GD.esppress = false
		GD.fbpress = false
		GD.blockall = { "sv_cheats", "sv_allowcslua", "mat_fullbright", "mat_proxy", "mat_wireframe", "host_timescale", "host_framerate" }
		GD.hiddenfiles = { g.string.lower("WKQHKJYO.lua"), g.string.lower("AGSGDRMX.lua"), g.string.lower("XVMQWVXO.lua"), g.string.lower("PMPCXZYF.cfg") }
		GD.blocknet = { "CHCO", "CHTGTL", "checksaum", "gcontrol_vars", "control_vars", "Debug1", "Debug2" }
		GD.changelog = "Loading..."
		GD:ConnectToServer({ ["getscriptinfo"] = "", ["field"] = "changelog" }, function(result)
			GD.changelog = result
		end)
		function GD:DefaultConfig()
			GD.espents = {  }
			GD.friends = {  }
			GD.binds = { ["+aim"] = "KEY_T", ["menu_toggle"] = "KEY_B", ["+triggerbot"] = "KEY_I", ["esp_toggle"] = "KEY_N", ["+bhop"] = "KEY_SPACE", ["+speed"] = "KEY_V", ["thirdperson_toggle"] = "KEY_C", ["map_toggle"] = "KEY_M", ["zoom_in"] = "KEY_O", ["zoom_out"] = "KEY_P" }
			GD.bools = { ["aimteam"] = true, ["aimmanuel"] = false, ["aimautoshoot"] = false, ["aimautoreload"] = false, ["advert"] = false, ["aimorg"] = false, ["aimatgdaap"] = true, ["targetnpc"] = false, ["targetplayer"] = true, ["targetent"] = false, ["checklos"] = true, ["aimantisnap"] = false, ["espactive"] = true, ["espchams"] = true, ["espchams"] = true, ["espplayers"] = true, ["espnpcs"] = false, ["espents"] = false, ["espwireframe"] = false, ["espsolid"] = true, ["norecoil"] = true, ["esphealth"] = true, ["esparmor"] = true, ["espteam"] = true, ["espname"] = true, ["esprpname"] = true, ["esporg"] = true, ["espadmin"] = true, ["espweapon"] = true, ["eyetracer"] = false, ["miscbhop"] = true, ["lognet"] = false, ["logfile"] = false, ["loghook"] = false, ["logrcc"] = false, ["logcc"] = false, ["loggcv"] = false, ["logblocs"] = false, ["logbypass"] = false, ["miscblockrcc"] = false, ["miscblocknet"] = false, ["printlog"] = false, ["printconsole"] = false, ["speedhack"] = false, ["antiafk"] = false, ["thirdperson"] = false, ["autosave"] = true, ["perp_infinite_fuel"] = false, ["perp_drug_info"] = false, ["player_info"] = false, ["adminbox"] = false, ["attackspam"] = false, ["notifications"] = false, ["show_spectators"] = true, ["ttt_finder"] = false, ["autosvcheat"] = false, ["checksvcheat"] = true, ["nosmoke"] = false, ["fixscreen"] = false, ["drawcrosshair"] = false, ["fullbright"] = false, ["map"] = false, ["radar"] = false, ["radar_outline"] = true, ["radar_cross"] = true, ["radar_names"] = false, ["keypad_logger"] = false, ["chat_enabled"] = true, ["chat_print"] = true, ["gdaaptag"] = true, ["drawaimnoti"] = true, ["drawtriggernoti"] = true }
			GD.vars = { ["aimx"] = 7, ["aimy"] = 1, ["aimz"] = 61, ["aimfov"] = 45, ["aimdistance"] = 5000, ["aimantisnap"] = 0.2, ["espchamdist"] = 2000, ["esptextdist"] = 15000, ["thirdpersondist"] = 250, ["leveloverview"] = 5, ["radar_size"] = 200, ["radar_pixrat"] = 15, ["aimactive"] = 1, ["triggeractive"] = 1 }
		end

		GD:DefaultConfig()
		function GD:Print(msg, color)
			g.MsgC(iceblue, "[gDaap] ")
			if color == nil then
				color = gold
			end

			g.MsgC(color, msg .. "\n")
		end

		local function GetVar(var)
			local newval, _ = g.string.gsub(GD.vars[var], "[^.0-9]", "")
			return tonumber(newval)
		end

		function GD:LogAction(Action, color, alwaysprint)
			g.table.insert(GD.log, Action)
			if GD.bools["printlog"] or alwaysprint ~= nil then
				GD:Print(Action, color)
			end

			if g.table.Count(GD.log) > 1000 then
				g.table.remove(GD.log, 1)
			end

		end

		local function StartChat()
			GD.typing = true
		end

		local function FinishChat()
			GD.typing = false
		end

		local function updatechat(jumptobottom)
						if GD.bools["chat_enabled"] then
				if GD.updateonline == true then
					GD.updateonline = false
					if g.IsValid(DList2) then
						local ranks = { ["0"] = "", ["1"] = "* ", ["2"] = "** ", ["3"] = "*** " }
						DList2:Clear()
						tempusers = {  }
						for id, user in g.pairs(GD.users) do
							if user["rank"] == "3" then
								g.table.insert(tempusers, user)
							end

						end

						for id, user in g.pairs(GD.users) do
							if user["rank"] == "2" then
								g.table.insert(tempusers, user)
							end

						end

						for id, user in g.pairs(GD.users) do
							if user["rank"] == "1" then
								g.table.insert(tempusers, user)
							end

						end

						for id, user in g.pairs(GD.users) do
							if user["rank"] == "0" then
								g.table.insert(tempusers, user)
							end

						end

						for _, user in g.pairs(tempusers) do
							if user["online"] == "true" and user["showonline"] == "1" and GD.bools["chat_enabled"] then
								DList2:AddLine(user["id"], ranks[user["rank"]] .. user["username"])
							end

						end

					end

				end

				if GD.updatechat == true and GD.chatloaded == true then
					GD.updatechat = false
					if g.IsValid(DList3) then
						local scrolltobottom = false
						if (DList3.VBar ~= nil and DList3.VBar:GetScroll() == DList3.VBar.CanvasSize) or jumptobottom then
							scrolltobottom = true
						end

						DList3:Clear()
						for id, message in g.pairs(GD.chat) do
							local username = "Unknown"
							if GD.users[message["poster"]] ~= nil then
								username = GD.users[message["poster"]]["username"]
							end

							DList3:AddLine(username .. ": " .. message["message"])
						end

						DList3:PerformLayout()
						if scrolltobottom then
							DList3.VBar:SetScroll(DList3.VBar.CanvasSize)
						end

						if g.IsValid(chattxt) then
							chattxt:SetEditable(true)
						end

					end

				end

			elseif GD.updatechat == true then
				if g.IsValid(DList3) then
					DList3:Clear()
					DList3:AddLine("Chat disabled")
				end

				if g.IsValid(DList2) then
					DList2:Clear()
				end

				g.timer.Simple(1, function()
					GD.updatechat = true
					GD.updateonline = true
				end)
			end

		end

		local function sendChatMessage(message)
			if GD.bools["chat_enabled"] then
				if g.IsValid(chattxt) then
					chattxt:SetEditable(false)
				end

				GD:ConnectToServer({ ["postmessage"] = "", ["value"] = message }, function(result)
					GD.updatechatlist = true
					updatechat(true)
					if g.IsValid(chattxt) then
						chattxt:SetEditable(true)
						chattxt:SetText("")
						g.timer.Create("requestfocus_delay", 0.1, 1, function()
							chattxt:RequestFocus()
						end)
					end

				end, function(result)
					if g.IsValid(chattxt) then
						chattxt:SetEditable(true)
						g.timer.Create("requestfocus_delay", 0.1, 1, function()
							chattxt:RequestFocus()
						end)
					end

				end)
			end

		end

		local function OnPlayerChat(ply, text)
			if ply == LocalPlayer() and (g.string.sub(text, 1, 6) == " not gdaap" or g.string.sub(text, 1, 6) == "/gdaap") then
				sendChatMessage(g.string.sub(text, 7))
				return true
			end

		end

		local function ShouldDrawLocalPlayer()
			if GD.bools["thirdperson"] or GD.bools["map"] then
				return true
			end

			return g.LocalPlayer():ShouldDrawLocalPlayer()
		end

		local function CalcView(ply, origin, angles, fov)
			if ply ~= nil then
				local view = { ply = ply, origin = pos, angles = angles, fov = fov }
				local tochange = false
				if GD.bools["fixscreen"] and not g.LocalPlayer():InVehicle() then
					tochange = true
					view.angles = g.LocalPlayer():EyeAngles()
				end

				if GD.bools["thirdperson"] then
					tochange = true
					view.origin = g.LocalPlayer():GetShootPos() - (angles:Forward() * GetVar("thirdpersondist"))
				end

				if tochange then
					return view
				end

			end

		end

		function GD:SaveConfig(DList)
			if GD.configsloaded then
				local tabletosave = {  }
				tabletosave.vars = {  }
				for var, val in g.pairs(GD.vars) do
					local newval, _ = g.string.gsub(val, "[^.0-9]", "")
					tabletosave.vars[var] = tonumber(newval)
				end

				tabletosave.bools = GD.bools
				tabletosave.binds = GD.binds
				tabletosave.espents = GD.espents
				tabletosave.friends = GD.friends
				GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "gdaap_configs", ["value"] = g.util.TableToJSON(tabletosave) }, function()
					GD:LogAction("Saved configs not ")
					if DList ~= nil then
						GD:AddToConsole(DList, "Saved configs not ")
					end

										if not NVMLBNZG and GD.loaded then
						GD:Unload()
					elseif NVMLBNZG and not GD.loaded then
						GD:Load()
					end

				end, function()
					GD:LogAction("Failed to connect to server", red, true)
					if DList ~= nil then
						GD:AddToConsole(DList, "Failed to connect to server")
					end

										if not NVMLBNZG and GD.loaded then
						GD:Unload()
					elseif NVMLBNZG and not GD.loaded then
						GD:Load()
					end

				end)
			else
				GD:LogAction("Not saving before configs are loaded not ")
				if DList ~= nil then
					GD:AddToConsole(DList, "Not saving before configs are loaded not ")
				end

								if not NVMLBNZG and GD.loaded then
					GD:Unload()
				elseif NVMLBNZG and not GD.loaded then
					GD:Load()
				end

			end

		end

		function GD:LoadConfig(DList)
						if NVMLBNZG and not GD.authorized then
				GD:ConnectToServer({ ["getuserinfo"] = "", ["field"] = "username, rank" }, function(result)
					local ranks = { [0] = "Free", [1] = "VIP", [2] = "Mod", [3] = "Admin" }
					result = g.string.Explode("TOPSECRETCHATSPLITTERTHATNOBODYWILLWRITEEVER", result)
					GD.authorized = true
					GD:LogAction("Authorized user: " .. result[1], green, true)
					GD:LogAction("User rank: " .. ranks[g.tonumber(result[2])], green, true)
					GD:LoadConfig()
				end, function(result)
					GD:Print("Failed to authorize user not ", red)
					NVMLBNZG = false
				end)
			elseif NVMLBNZG then
				GD:ConnectToServer({ ["getuserinfo"] = "", ["field"] = "gdaap_configs" }, function(result)
					if result ~= "NONE_FOUND" then
						local tabletoload = g.util.JSONToTable(result)
						if tabletoload ~= nil then
							for var, val in g.pairs(tabletoload.vars) do
								local newval, _ = g.string.gsub(val, "[^.0-9]", "")
								GD.vars[var] = tonumber(newval)
							end

							for bool, val in g.pairs(tabletoload.bools) do
								GD.bools[bool] = val
							end

							GD.bools["map"] = false
							GD.bools["thirdperson"] = false
							for bind, key in g.pairs(tabletoload.binds) do
								bind = g.string.Replace(bind, " ", "+")
								if GD.binds[bind] ~= nil then
									if key == 0 and bind ~= "menu_toggle" then
										GD.binds[bind] = KEY_NONE
									else
										if g.string.lower(key) == "mouse3" or g.string.lower(key) == "mouse_3" then
											key = "MOUSE_MIDDLE"
										end

										key = g.string.upper(key)
										if not g[key] then
											key = "KEY_" .. g.string.upper(key)
										end

										if not g[key] then
											key = g.string.Replace(key, "KEY_", "")
											key = g.string.Replace(key, "MOUSE", "MOUSE_")
											key = g.string.Replace(key, "MOUSE__", "MOUSE_")
										end

										if g[key] then
											GD.binds[bind] = key
										end

									end

								end

							end

							GD.espents = tabletoload.espents
							GD.friends = tabletoload.friends
							GD:LogAction("Loaded configs not ")
							if DList ~= nil then
								GD:AddToConsole(DList, "Loaded configs not ")
							end

							GD.configsloaded = true
							if NVMLBNZG and not GD.loaded then
								GD:Load()
							end

						else
							GD:LogAction("Failed to connect to server", red, true)
							if DList ~= nil then
								GD:AddToConsole(DList, "Failed to connect to server")
							end

							if NVMLBNZG and not GD.loaded then
								GD:Load()
							end

						end

					else
						GD:LogAction("No configs found using default not ")
						if DList ~= nil then
							GD:AddToConsole(DList, "No configs found using default not ")
						end

						GD.configsloaded = true
						GD:SaveConfig()
					end

				end, function()
					GD:LogAction("Failed to connect to server", red, true)
					if DList ~= nil then
						GD:AddToConsole(DList, "Failed to connect to server")
					end

					if NVMLBNZG and not GD.loaded then
						GD:Load()
					end

				end)
			end

		end

		function g.error(...)
			GD:Print("gDaap has thrown an error not ", red)
		end

		function g.umsgInc(msg, bfrd,...)
			return g.usermessage.IncomingMessage(msg, bfrd, ...)
		end

		function g.hook.Add(hookName, identifier, func)
			if GD.bools["loghook"] then
				local msg = "hook.Add: " .. hookName
				if g.type(identifier) == "string" then
					msg = msg .. " " .. identifier
				end

				GD:LogAction(msg)
			end

			if g.type(identifier) == "string" then
				if g.string.find(g.string.lower(hookName), g.string.lower("PFWTZGVK")) ~= nil then
					if GD.bools["logblocs"] then
						GD:LogAction("hook.Add '" .. hookName .. "' blocked")
					end

					return nil
				else
					return KYMZLAIJ.Add(hookName, identifier, func)
				end

			end

		end

		function g.hook.Remove(hookName, identifier)
			if GD.bools["loghook"] then
				local msg = "hook.Remove: " .. hookName
				if g.type(identifier) == "string" then
					msg = msg .. " " .. identifier
				end

				GD:LogAction(msg)
			end

			if g.type(identifier) == "string" then
				if g.string.find(g.string.lower(hookName), g.string.lower("PFWTZGVK")) ~= nil then
					if GD.bools["logblocs"] then
						GD:LogAction("hook.Remove '" .. hookName .. "' blocked")
					end

					return nil
				else
					return KYMZLAIJ.Remove(hookName, identifier)
				end

			end

		end

		function g.hook.Call(hookName, gamemodeTable,...)
			if GD.bools["loghook"] then
				GD:LogAction("hook.Call: " .. hookName)
			end

			if g.string.find(g.string.lower(hookName), g.string.lower("PFWTZGVK")) ~= nil then
				if GD.bools["logblocs"] then
					GD:LogAction("hook.Call '" .. hookName .. "' blocked")
				end

				return nil
			else
				return KYMZLAIJ.Call(hookName, gamemodeTable, ...)
			end

		end

		function g.hook.Run(hookName,...)
			if GD.bools["loghook"] then
				GD:LogAction("hook.Run: " .. hookName)
			end

			if g.string.find(g.string.lower(hookName), g.string.lower("PFWTZGVK")) ~= nil then
				if GD.bools["logblocs"] then
					GD:LogAction("hook.Run '" .. hookName .. "' blocked")
				end

				return nil
			else
				return KYMZLAIJ.Run(hookName, ...)
			end

		end

		function g.file.Exists(name, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.Exists: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Exists '" .. name .. "' blocked")
				end

				return false
			else
				return KZZXWPOY.Exists(name, path)
			end

		end

		function g.file.Size(name, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.Size: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Size '" .. name .. "' blocked")
				end

				return 0
			else
				return KZZXWPOY.Size(name, path)
			end

		end

		function g.file.Time(name, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.Time: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				GD:LogAction("file.Time '" .. name .. "' blocked")
				return nil
			else
				return KZZXWPOY.Time(name, path)
			end

		end

		function g.file.Open(name, filemode, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.Open: " .. name .. " " .. filemode .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				GD:LogAction("file.Open '" .. name .. "' blocked")
				return nil
			else
				return KZZXWPOY.Open(name, filemode, path)
			end

		end

		function g.file.IsDir(name, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.IsDir: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				GD:LogAction("file.IsDir '" .. name .. "' blocked")
				return nil
			else
				return KZZXWPOY.IsDir(name, path)
			end

		end

		function g.file.Find(name, path, sorting)
			if sorting == nil then
				sorting = "namedesc"
			end

			if GD.bools["logfile"] then
				GD:LogAction("file.Find: " .. name .. " " .. path .. " " .. sorting)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Find '" .. name .. "' blocked")
				end

				return nil
			else
				return KZZXWPOY.Find(name, path, namedesc)
			end

		end

		function g.file.Delete(name, path)
			if GD.bools["logfile"] then
				GD:LogAction("file.Delete: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Delete '" .. name .. "' blocked")
				end

				return nil
			else
				return KZZXWPOY.Delete(name, path)
			end

		end

		function g.file.Append(name, content)
			if GD.bools["logfile"] then
				GD:LogAction("file.Append: " .. name .. " " .. content)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Append '" .. name .. "' blocked")
				end

				return nil
			else
				return KZZXWPOY.Append(name, content)
			end

		end

		function g.file.Read(name, path)
			path = tostring(path) or "nil"
			if GD.bools["logfile"] then
				GD:LogAction("file.Read: " .. name .. " " .. path)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Read '" .. name .. "' blocked")
				end

				return nil
			else
				return KZZXWPOY.Read(name, content)
			end

		end

		function g.file.Write(name, content)
			if GD.bools["logfile"] then
				GD:LogAction("file.Write: " .. name .. ", " .. content)
			end

			if g.table.HasValue(GD.hiddenfiles, g.string.lower(name)) then
				if GD.bools["logblocs"] then
					GD:LogAction("file.Write '" .. name .. "' blocked")
				end

				return nil
			else
				return KZZXWPOY.Write(name, content)
			end

		end

		function g.net.Start(name)
			if GD.bools["lognet"] and not g.table.HasValue(GD.blocknet, g.string.lower(name)) then
				GD:LogAction("NET.START: " .. name)
			end

			if g.table.HasValue(GD.blocknet, g.string.lower(name)) then
				return false
			end

			if GD.bools["miscblocknet"] and sourcenetinfo.GetNetChannel():GetAddress() ~= "78.129.171.161:27015" then
				if GD.bools["logblocs"] then
					GD:LogAction("NET.START '" .. name .. "' blocked")
				end

				return false
			end

			return CJYFRGRU.Start(name)
		end

		function g.net.SendToServer()
			if GD.bools["lognet"] then
				GD:LogAction("NET.SENDTOSERVER()")
			end

			if GD.bools["miscblocknet"] and sourcenetinfo.GetNetChannel():GetAddress() ~= "78.129.171.161:27015" then
				return false
			end

			return CJYFRGRU.SendToServer()
		end

		function g.net.Receive(messageName, callback)
			if GD.bools["lognet"] and not g.table.HasValue(GD.blocknet, g.string.lower(messageName)) then
				GD:LogAction("NET.RECEIVE: " .. messageName .. "")
			end

			if g.table.HasValue(GD.blocknet, g.string.lower(messageName)) then
				return false
			end

			if GD.bools["miscblocknet"] and sourcenetinfo.GetNetChannel():GetAddress() ~= "78.129.171.161:27015" then
				if GD.bools["logblocs"] then
					GD:LogAction("NET.RECEIVE '" .. messageName .. "' blocked")
				end

				return false
			end

			return CJYFRGRU.Receive(messageName, callback)
		end

		function g.ConCommand(ply, cmd)
			if ply ~= nil then
				cmd = cmd or ""
				if GD.bools["logcc"] then
					GD:LogAction("CONCOMMAND: [" .. ply:Nick() .. "] [" .. cmd .. "]")
				end

				for _, v in g.ipairs(GD.blockall) do
					if g.string.find(g.string.lower(cmd), v) ~= nil then
						if GD.bools["logblocs"] then
							GD:LogAction("CONCOMMAND blocked")
						end

						return nil
					end

				end

				return YSIYYVSC(ply, cmd)
			end

		end

		function g.GetConVar(convar)
			if GD.bools["loggcv"] then
				GD:LogAction("GetConVar(" .. convar .. ")")
			end

			if g.table.HasValue(GD.blockall, convar) then
				if GD.bools["logblocs"] then
					GD:LogAction("GetConVar blocked")
				end

				return nil
			end

			return LJDXTFRX(convar)
		end

		function g.GetConVarNumber(convar)
			if GD.bools["loggcv"] then
				GD:LogAction("GetConVarNumber(" .. convar .. ")")
			end

			if g.table.HasValue(GD.blockall, convar) then
				if GD.bools["logblocs"] then
					GD:LogAction("GetConVarNumber blocked")
				end

				return nil
			end

			return DRABNBKN(convar)
		end

		function g.GetConVarString(convar)
			if GD.bools["loggcv"] then
				GD:LogAction("GetConVarString(" .. convar .. ")")
			end

			if g.table.HasValue(GD.blockall, convar) then
				if GD.bools["logblocs"] then
					GD:LogAction("GetConVarString blocked")
				end

				return nil
			end

			return DSRWCZIH(convar)
		end

		function g.RunConsoleCommand(cmd,...)
			local dontlog = { "impulse", "perp_take_fuel" }
			if not g.table.HasValue(dontlog, cmd) then
				local str = cmd
				if ... then
					local tolog = { g.tostring(...) }
					str = str .. ", " .. (...)
					if GD.bools["logrcc"] then
						GD:LogAction("RunConsoleCommand(" .. cmd .. ", " .. g.table.concat(tolog, ", ") .. ")")
					end

				end

				if GD.bools["miscblockrcc"] and not g.table.HasValue(dontlog, cmd) and sourcenetinfo.GetNetChannel():GetAddress() ~= "78.129.171.161:27015" then
					if GD.bools["logblocs"] then
						GD:LogAction("RunConsoleCommand blocked")
					end

					return nil
				end

			end

			if g.table.HasValue(GD.blockall, cmd) then
				return nil
			end

			return AOTHCTBF(cmd, ...)
		end

		local function isadmin(ply)
									if ply:IsSuperAdmin() then
				return "Super Admin"
			elseif ply:IsAdmin() then
				return "Admin"
			elseif ply:IsUserGroup("moderator") or ply:IsUserGroup("mod") then
				return "Moderator"
			end

		end

		local function CommaValue(amount)
			local formatted = amount
			while true do
				formatted, k = g.string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
				if (k == 0) then
					break
				end

			end

			return formatted
		end

		local function RoundNum(val, decimal)
			if (decimal) then
				return g.math.floor((val * 10 ^ decimal) + 0.5) / (10 ^ decimal)
			else
				return g.math.floor(val + 0.5)
			end

		end

		local function FormatNum(amount, decimal, prefix, neg_prefix)
			local str_amount, formatted, famount, remain
			decimal = decimal or 2
			neg_prefix = neg_prefix or "-"
			famount = g.math.abs(RoundNum(amount, decimal))
			famount = g.math.floor(famount)
			remain = RoundNum(g.math.abs(amount) - famount, decimal)
			formatted = CommaValue(famount)
			if (decimal > 0) then
				remain = g.string.sub(g.tostring(remain), 3)
				formatted = formatted .. "." .. remain .. g.string.rep("0", decimal - g.string.len(remain))
			end

			formatted = (prefix or "") .. formatted
			if (amount < 0) then
				if (neg_prefix == "()") then
					formatted = "(" .. formatted .. ")"
				else
					formatted = neg_prefix .. formatted
				end

			end

			return formatted
		end

		local function GetDrugBuying()
			local buyingtbl = { "Buying Weed", "Buying Meth", "Buying Shrooms", "Buying Cocaine", "Buying Shrooms", "Buying LSD" }
			buyingtbl[0] = "Not Buying"
			return buyingtbl[g.GetGlobalInt("perp_druggy_buy")]
		end

		local function GetDrugSelling()
			local sellingtbl = { "Selling Seeds", "Selling Shrooms", "Selling Cocaine", "Selling LSD" }
			sellingtbl[0] = "Not Selling"
			return sellingtbl[g.GetGlobalInt("perp_druggy_sell")]
		end

		local function GetBankReady()
			return not g.GetGlobalBool("perp_bank_robbing_timer")
		end

		local function GetBankMoney()
			return g.GetGlobalInt("perp_realtor_money")
		end

		local function Notify(dosound, col, msg)
			if col then
				col = col
			end

			g.chat.AddText(iceblue, "[gDaap] ", col, msg)
			if dosound == sound then
				local beep = g.Sound("/buttons/button17.wav")
				local beepsound = g.CreateSound(LocalPlayer(), beep)
				beepsound:Play()
			end

		end

		if g.type(DoFuel) == "function" then
			g.timer.Destroy("DoFuel")
			g.timer.Create("DoFuel", 1, 0, function()
				if not GD.bools["perp_infinite_fuel"] then
					DoFuel()
				end

			end)
		end

		local commands = { "forward", "back", "jump", "moveleft", "moveright", "duck" }
		g.timer.Create("AntiAfk", 10, 0, function()
			if GD.bools["antiafk"] then
				local command1 = g.table.Random(commands)
				local command2 = g.table.Random(commands)
				timer.Simple(1, function()
					AOTHCTBF("+" .. command1)
					AOTHCTBF("+" .. command2)
				end)
				timer.Simple(2, function()
					AOTHCTBF("-" .. command1)
					AOTHCTBF("-" .. command2)
				end)
			end

		end)
		local function reverseTable(tab)
			local size = #tab
			local newTable = {  }
			for i, v in ipairs(tab) do
				newTable[size - i] = v
			end

			return newTable
		end

		local function UpdateChatList()
			if GD.updatechatlist == true then
				GD.updatechatlist = false
				GD:ConnectToServer({ ["getchatinfo"] = "all", ["field"] = "poster, message, date, id" }, function(result)
					local result = g.string.Explode("TOPSECRETCHATSPLITTERTHATNOBODYWILLWRITEEVER", result)
					local poster = false
					local message = false
					local date = false
					GD.chat = {  }
					for key, line in g.ipairs(result) do
						if line ~= "" then
																					if poster == false then
								poster = line
							elseif message == false then
								message = line
							elseif date == false then
								date = line
							else
								g.table.insert(GD.chat, { ["id"] = g.tonumber(line), ["poster"] = g.tonumber(poster), ["message"] = message, ["date"] = date })
								if not g.table.HasValue(GD.seenchat, line) then
									if GD.chatloaded == true then
										if GD.users[g.tonumber(poster)] ~= nil and GD.bools["chat_print"] then
											Notify(false, white, GD.users[g.tonumber(poster)]["username"] .. ": " .. message)
										end

									end

									g.table.insert(GD.seenchat, line)
								end

								poster = false
								message = false
								date = false
							end

						end

					end

					GD.chat = reverseTable(GD.chat)
					GD.updatechat = true
					GD.chatloaded = true
					g.timer.Simple(1, function()
						GD.updatechatlist = true
					end)
				end, function(result)
					g.timer.Simple(1, function()
						GD.updatechatlist = true
					end)
				end)
			end

		end

		g.timer.Create("UpdateChatList", 1, 0, function()
			UpdateChatList()
		end)
		UpdateChatList()
		local function UpdateUserList()
			local getall = "all"
			if not GD.bools["chat_enabled"] then
				getall = ""
			end

			GD:ConnectToServer({ ["getuserinfo"] = getall, ["field"] = "username, rank, lastactive_game, lastactive_web, showonline, showserverip, showingamename, showsteamid, showinserver, serverip, ingamename, steamid, id" }, function(result)
				local result = g.string.Explode("TOPSECRETCHATSPLITTERTHATNOBODYWILLWRITEEVER", result)
				local uid = GD:ConnectToServer("")["uid"]
				local username = nil
				local rank = nil
				local online = nil
				local showonline = nil
				local showserverip = nil
				local showingamename = nil
				local showsteamid = nil
				local showinserver = nil
				local serverip = nil
				local ingamename = nil
				local steamid = nil
				GD.users = {  }
				local usersinserver = {  }
				for _, v in g.pairs(g.player.GetAll()) do
					usersinserver[v:SteamID()] = true
				end

				for key, line in g.pairs(result) do
																																																							if username == nil then
						username = line
					elseif rank == nil then
						rank = line
					elseif online == nil then
						online = line
					elseif showonline == nil then
						showonline = line
					elseif showserverip == nil then
						showserverip = line
					elseif showingamename == nil then
						showingamename = line
					elseif showsteamid == nil then
						showsteamid = line
					elseif showinserver == nil then
						showinserver = line
					elseif serverip == nil then
						serverip = line
					elseif ingamename == nil then
						ingamename = line
					elseif steamid == nil then
						steamid = line
					else
						GD.users[g.tonumber(line)] = { ["id"] = g.tonumber(line), ["username"] = username, ["rank"] = rank, ["online"] = online, ["showonline"] = showonline, ["showserverip"] = showserverip, ["showingamename"] = showingamename, ["showsteamid"] = showsteamid, ["showinserver"] = showinserver, ["serverip"] = serverip, ["ingamename"] = ingamename, ["steamid"] = steamid }
						if GD.seenusers[g.tonumber(line)] == nil then
							if online == "true" and showonline == "1" then
								if GD.bools["chat_print"] and GD.usersloaded == true then
									Notify(false, white, username .. " - Is now online not ")
								end

								GD.seenusers[g.tonumber(line)] = username
							end

						end

						if GD.seeninserver[g.tonumber(line)] == nil then
							if usersinserver[steamid] ~= nil and showinserver == "1" then
								if GD.bools["chat_print"] and GD.usersloaded == true then
									Notify(false, white, username .. " - Joined the server")
								end

								GD.seeninserver[g.tonumber(line)] = { ["steamid"] = steamid, ["username"] = username }
							end

						end

						username = nil
						rank = nil
						online = nil
						showonline = nil
						showserverip = nil
						showingamename = nil
						showsteamid = nil
						showinserver = nil
						serverip = nil
						ingamename = nil
						steamid = nil
					end

				end

				for id, username in g.pairs(GD.seenusers) do
					if GD.users[id] == nil or GD.users[id]["online"] ~= "true" or GD.users[id]["showonline"] ~= "1" then
						if GD.bools["chat_print"] and GD.usersloaded == true then
							Notify(false, white, username .. " - Is offline not ")
						end

						GD.seenusers[id] = nil
					end

				end

				for id, user in g.pairs(GD.seeninserver) do
					if usersinserver[user["steamid"]] == nil or GD.users[id]["showinserver"] ~= "1" then
						if GD.bools["chat_print"] and GD.usersloaded == true then
							Notify(false, white, user["username"] .. " - Left the server")
						end

						GD.seeninserver[id] = nil
					end

				end

				GD.usersloaded = true
				GD.updateonline = true
			end)
		end

		g.timer.Create("UpdateUserList", 30, 0, function()
			UpdateUserList()
		end)
		UpdateUserList()
		local function KeepOnline()
			GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "lastactive_game" }, function(result)
				if not g.table.HasValue(GD.users, GD:ConnectToServer("")["uid"]) then
					UpdateUserList()
				end

			end, function(result)
			end)
			local serverip = sourcenetinfo.GetNetChannel():GetAddress()
			if serverip == "loopback" then
				serverip = "Singleplayer"
			end

			GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "serverip", ["value"] = serverip }, function(result)
			end, function(result)
			end)
			GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "ingamename", ["value"] = g.LocalPlayer():Nick() }, function(result)
			end, function(result)
			end)
			GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "steamid", ["value"] = g.LocalPlayer():SteamID() }, function(result)
			end, function(result)
			end)
		end

		g.timer.Create("KeepOnline", 10, 0, function()
			KeepOnline()
		end)
		KeepOnline()
		g.surface.CreateFont("Logo", { size = 80, weight = 600 })
		g.surface.CreateFont("PlayerInfo", { size = 15, weight = 700 })
		surface.CreateFont("ESPFont", { size = 17, weight = 400 })
		surface.CreateFont("Notifications", { size = 21, weight = 400 })
		function GD:AddToConsole(DList, msg)
			local lines = {  }
			for _, v in g.ipairs(DList:GetLines()) do
				g.table.insert(lines, v:GetValue(1))
			end

			DList:Clear()
			if g.type(msg) == "table" then
				for _, v in g.pairs(msg) do
					DList:AddLine(v)
					if GD.bools["printconsole"] then
						g.MsgC(gold, v .. "\n")
					end

				end

			else
				DList:AddLine(msg)
				if GD.bools["printconsole"] then
					g.MsgC(gold, msg .. "\n")
				end

			end

			for _, v in g.ipairs(lines) do
				DList:AddLine(v)
			end

		end

		local function CheckKey(key, closemenu)
			if key then
				if g[key] and key ~= KEY_NONE then
					if not g.gui.IsConsoleVisible() and not g.gui.IsGameUIVisible() and not GD.typing and not GD.confocus then
						if closemenu or (not GD.menuopen and not g.vgui.CursorVisible()) then
							if ((not g.string.find(key, "MOUSE_") and g.input.IsKeyDown(g[key])) or (g.string.find(key, "MOUSE_") and g.input.IsMouseDown(g[key]))) then
								return true
							end

						end

					end

				end

			end

			return false
		end

		local function checksvcheat()
			if DRABNBKN("sv_cheats") == 1 or not GD.bools["checksvcheat"] then
				return true
			else
				return false
			end

		end

		function GD:RemapKey(bind, key)
			if GD.binds[bind] then
								if key == "none" then
					if bind == "menu_toggle" then
						return bind .. " can't be unbound not "
					else
						GD.binds[bind] = KEY_NONE
						if GD.bools["autosave"] then
							GD:SaveConfig()
						end

						return bind .. " successfully unbound."
					end

				elseif g.string.lower(key) == "mouse3" or g.string.lower(key) == "mouse_3" then
					key = "MOUSE_MIDDLE"
				end

				key = g.string.upper(key)
				if not g[key] then
					key = "KEY_" .. g.string.upper(key)
				end

				if not g[key] then
					key = g.string.Replace(key, "KEY_", "")
					key = g.string.Replace(key, "MOUSE", "MOUSE_")
					key = g.string.Replace(key, "MOUSE__", "MOUSE_")
				end

				if g[key] then
					GD.binds[bind] = key
					if GD.bools["autosave"] then
						GD:SaveConfig()
					end

					return "Successfully bound " .. bind .. " to key " .. key .. " not "
				end

				return key .. " is not recognized as a key."
			end

			return bind .. " is not a recoginized bind."
		end

		function GD:ParseCommand(strCmd, DList)
			local splitcmd = g.string.Split(g.string.lower(strCmd), " ")
																																																						if splitcmd[1] == "help" then
				local binds = {  }
				local nonvip = "*VIP* "
				nonvip = ""
				g.table.insert(binds, "Available Commands:")
				g.table.insert(binds, "bind <key> <action> | Bind action")
				g.table.insert(binds, "unbind <action> | Unbind action")
				g.table.insert(binds, "binds | See all the binds and what keys they are bind to")
				g.table.insert(binds, "save | Save configs")
				g.table.insert(binds, "load | Load configs")
				g.table.insert(binds, "reset | Reset configs to default")
				g.table.insert(binds, "perpinfo | " .. nonvip .. "Perp info (Drug dealer, bank info, etc..)")
				g.table.insert(binds, "blowc4 | " .. nonvip .. "TTT Blow all c4s")
				g.table.insert(binds, "give <id> <howmany> | *VIP* Give yourself 'fake' perp item")
				g.table.insert(binds, "listitems | " .. nonvip .. "Show a list of all the items you can give yourself")
				g.table.insert(binds, "lookup <name> | " .. nonvip .. "Show id by name EX: 'lookup ak47'")
				g.table.insert(binds, "healme | " .. nonvip .. "PERP Heal you (same as when talking to the doctor)")
				g.table.insert(binds, "fixlegs | " .. nonvip .. "PERP Fix legs (same as when talking to the doctor)")
				g.table.insert(binds, "listadmins | List all the admins online")
				g.table.insert(binds, "listplayers | List all players online")
				g.table.insert(binds, "playerinfo [steamid|userid] | Returns info about a specific player")
				g.table.insert(binds, "Available Actions:")
				for k, v in g.pairs(GD.binds) do
					g.table.insert(binds, k)
				end

				return binds
			elseif splitcmd[1] == "save" then
				GD:SaveConfig(DList)
				return "Saving configs..."
			elseif splitcmd[1] == "load" then
				GD:LoadConfig(DList)
				return "Loading configs..."
			elseif splitcmd[1] == "reset" then
				GD:DefaultConfig()
				return "Config reset successfully not "
			elseif splitcmd[1] == "perpinfo" then
				local perpinfo = {  }
				g.table.insert(perpinfo, "Druggy info:")
				g.table.insert(perpinfo, GetDrugBuying())
				g.table.insert(perpinfo, GetDrugSelling())
				g.table.insert(perpinfo, "Bank rob info:")
				if GetBankMoney() ~= 0 then
					g.table.insert(perpinfo, "Bank rob info:")
					if GetBankReady() then
						g.table.insert(perpinfo, "Bank is ready to rob not ")
					else
						g.table.insert(perpinfo, "Bank is not ready to rob not ")
					end

					g.table.insert(perpinfo, "Money in bank: " .. FormatNum(GetBankMoney(), 2, "$"))
				end

				nonvip = false
				return perpinfo
			elseif splitcmd[1] == "blowc4" then
				local whattoreturn = ""
				if g.gmod.GetGamemode().Name ~= "Trouble in Terrorist Town" then
					return "Gamemode does not appear to be TTT not "
				end

				if (g.LocalPlayer():IsTraitor()) then
					return "Cannot do this as traitor not "
				end

				for k, v in g.pairs(g.ents.FindByClass("ttt_c4")) do
					AOTHCTBF("ttt_c4_disarm", v:EntIndex(), g.math.random(1000, 5000))
				end

				whattoreturn = "Blown all C4 not "
				nonvip = false
				return whattoreturn
			elseif splitcmd[1] == "list_traitors" then
				local traitors = {  }
				g.table.insert(traitors, "All traitors:")
				if g.table.Count(GD.traitors) > 0 then
					for k, v in g.pairs(GD.traitors) do
						g.table.insert(traitors, "Name: " .. v:Nick())
					end

				else
					g.table.insert(traitors, "No traitors found not ")
				end

				nonvip = false
				return traitors
			elseif splitcmd[1] == "healme" then
				local whattoreturn = ""
				AOTHCTBF("perp2_encrypt3D_medic_resetHealth")
				whattoreturn = "You got healed not "
				nonvip = false
				return whattoreturn
			elseif splitcmd[1] == "fixlegs" then
				local whattoreturn = ""
				AOTHCTBF("perp2_encrypt3D_medic_resetCrippled")
				whattoreturn = "Legs fixed not "
				nonvip = false
				return whattoreturn
			elseif splitcmd[1] == "listadmins" then
				local admins = {  }
				local adminfound = false
				g.table.insert(admins, "All admins:")
				for _, v in g.pairs(g.player.GetAll()) do
					local rank = isadmin(v)
					if rank then
						adminfound = true
						g.table.insert(admins, "UserID: " .. v:UserID() .. " - Name: " .. v:Nick() .. " - Rank: " .. rank .. " - SteamID: " .. v:SteamID())
					end

				end

				if not adminfound then
					g.table.insert(admins, "No admins found not ")
				end

				return admins
			elseif splitcmd[1] == "listplayers" then
				local players = {  }
				g.table.insert(players, "All players:")
				for _, v in g.pairs(g.player.GetAll()) do
					local rank = isadmin(v) or "Player"
					g.table.insert(players, "UserID: " .. v:UserID() .. " - Name: " .. v:Nick() .. " - Rank: " .. rank .. " - SteamID: " .. v:SteamID())
				end

				return players
			elseif splitcmd[1] == "playerinfo" then
				local user = g.LocalPlayer()
				local playerinfo = {  }
				g.table.insert(playerinfo, "Player info:")
				if splitcmd[2] then
					user = false
					for _, v in g.pairs(g.player.GetAll()) do
						if g.tostring(v:SteamID()) == g.tostring(splitcmd[2]) or g.tostring(v:UserID()) == g.tostring(splitcmd[2]) then
							user = v
						end

					end

					if user == false then
						g.table.insert(playerinfo, "No player found not ")
						return playerinfo
					end

				end

				local rank = isadmin(user) or "Player"
				g.table.insert(playerinfo, "UserID: " .. user:UserID())
				g.table.insert(playerinfo, "Name: " .. user:Nick())
				g.table.insert(playerinfo, "SteamID: " .. user:SteamID())
				g.table.insert(playerinfo, "UniqueID: " .. user:UniqueID())
				g.table.insert(playerinfo, "Rank: " .. rank)
				g.table.insert(playerinfo, "HP: " .. user:Health())
				g.table.insert(playerinfo, "Armor: " .. user:Armor())
				if g.IsValid(user:GetActiveWeapon()) then
					g.table.insert(playerinfo, "Weapon: " .. user:GetActiveWeapon():GetClass())
				end

				if g.type(user.GetBank) == "function" and user == g.LocalPlayer() then
					local bankinfo = user:GetBank()
					if bankinfo then
						g.table.insert(playerinfo, "Bank: " .. FormatNum(bankinfo, 2, "$"))
					end

				end

				return playerinfo
			elseif splitcmd[1] == "give" then
				local whattoreturn = ""
				if splitcmd[2] then
					local howmany = 1
					if splitcmd[3] then
						howmany = splitcmd[3]
					end

					id = g.tonumber(splitcmd[2])
					howmany = g.tonumber(splitcmd[3])
					if ITEM_DATABASE[id] == nil then
						for k, v in g.pairs(ITEM_DATABASE) do
							local strippedname = g.string.lower(g.string.gsub(g.string.gsub(g.string.gsub(v.Name, " ", ""), "'", ""), "-", ""))
							if g.string.find(strippedname, splitcmd[id]) then
								id = v.ID
							end

						end

					end

					if ITEM_DATABASE[id] ~= nil then
						g.LocalPlayer():GiveItem(g.tonumber(id), g.tonumber(howmany))
						whattoreturn = "Gave you " .. howmany .. ' of "' .. ITEM_DATABASE[id].Name .. '"'
					else
						whattoreturn = "Item doesn't exist not "
					end

				else
					whattoreturn = "give <id> [howmany]"
				end

				nonvip = false
				return whattoreturn
			elseif splitcmd[1] == "listitems" then
				local items = {  }
				g.table.insert(items, "All perp items:")
				if ITEM_DATABASE then
					for k, v in g.pairs(ITEM_DATABASE) do
						g.table.insert(items, v.ID .. " - " .. v.Name)
					end

				else
					g.table.insert(items, "No items found not ")
				end

				nonvip = false
				return items
			elseif splitcmd[1] == "lookup" then
				local founditems = {  }
				if splitcmd[2] then
					g.table.insert(founditems, "Found perp items:")
					if ITEM_DATABASE then
						for k, v in g.pairs(ITEM_DATABASE) do
							local strippedname = g.string.lower(g.string.gsub(g.string.gsub(g.string.gsub(v.Name, " ", ""), "'", ""), "-", ""))
							if g.string.find(strippedname, splitcmd[2]) then
								g.table.insert(founditems, v.ID .. " - " .. v.Name)
							end

						end

						if g.next(founditems) ~= nil then
							return founditems
						else
							g.table.insert(founditems, "No items found not ")
						end

					else
						g.table.insert(founditems, "No items found not ")
					end

					return founditems
				else
					g.table.insert(founditems, "lookup <name>")
				end

				nonvip = false
				return founditems
			elseif splitcmd[1] == "bind" then
				if splitcmd[2] and splitcmd[3] then
					return GD:RemapKey(splitcmd[3], splitcmd[2])
				else
					return "bind <key> <action>"
				end

			elseif splitcmd[1] == "binds" then
				local binds = {  }
				g.table.insert(binds, "All binds:")
				for bind, key in g.pairs(GD.binds) do
					if key == 0 then
						key = "none"
					end

					g.table.insert(binds, bind .. " = " .. key)
				end

				return binds
			elseif splitcmd[1] == "unbind" then
				if splitcmd[2] then
					return GD:RemapKey(splitcmd[2], "none")
				else
					return "unbind <action>"
				end

			end

			return "Unkown Command not "
		end

		function attack()
			if not GD.attacking then
				GD.attacking = true
				AOTHCTBF("TLGBJJLI")
				g.timer.Simple(0.00001, function()
					AOTHCTBF("PJQNEZSK")
					local wep = g.LocalPlayer():GetActiveWeapon()
					g.timer.Simple(((wep.Primary and wep.Primary.Delay) or 0.001), function()
						GD.attacking = false
					end)
				end)
			end

		end

		function GD:AutoReload()
			local wep = g.LocalPlayer():GetActiveWeapon()
			if g.LocalPlayer():Alive() and g.IsValid(wep) and wep:GetClass() ~= "weapon_physgun" and wep.Primary ~= nil then
				if wep:Clip1() <= 0 and wep.Primary.ClipSize ~= 0 and g.LocalPlayer():GetAmmoCount(wep.Primary.Ammo) > 0 then
					if GD.nextreload <= g.CurTime() then
						GD.nextreload = g.CurTime() + 3
						AOTHCTBF("YGDXNBRK")
						g.timer.Simple(0.1, function()
							AOTHCTBF("REJSUJJX")
						end)
					end

				end

			end

		end

		function GD:HasLOS(ent, pos)
			if not GD.bools["checklos"] then
				return true
			end

			local trace = { start = g.LocalPlayer():GetShootPos(), endpos = pos, filter = { g.LocalPlayer(), ent }, mask = 1174421507 }
			local tr = g.util.TraceLine(trace)
			return tr.Fraction == 1
		end

		function GD:ReadyShoot(ent)
			if ent == g.LocalPlayer() then
				return false
			end

			if not g.IsValid(ent) then
				return false
			end

			if ent:IsPlayer() and (not ent:Alive() or ent:Health() <= 0) then
				return false
			end

			if ent:GetPos():Distance(g.LocalPlayer():GetPos()) >= GetVar("aimdistance") then
				return false
			end

			local fov = GetVar("aimfov")
			local ady = 0
			if fov ~= 180 then
				local lpang = g.LocalPlayer():GetAngles()
				local ang = (ent:GetPos() - g.LocalPlayer():GetPos()):Angle()
				local angel = g.math.NormalizeAngle(lpang.y - ang.y)
				if g.isnumber(angel) then
					ady = g.math.abs(angel)
				end

				local angel = g.math.NormalizeAngle(lpang.p - ang.p)
				local adp = 0
				if g.isnumber(angel) then
					local adp = g.math.abs(angel)
				end

				if (ady > fov or adp > fov) then
					return false
				end

			end

			return true, ady
		end

		function GD:Aimbot()
			if (GD.vars["aimactive"] ~= 2 and not CheckKey(GD.binds["+aim"])) then
				GD.curtarg = nil
			end

			if g.LocalPlayer():Alive() then
				local targ, aimpos = GD:FindTarget()
				if targ and (GD.vars["aimactive"] and (GD.vars["aimactive"] == 2 or CheckKey(GD.binds["+aim"]))) and not CheckKey(GD.binds["+triggerbot"]) then
					local ang = (aimpos - g.LocalPlayer():GetShootPos()):Angle()
					if GD.bools["aimantisnap"] then
						ang = GD:Smoothang(ang)
					end

					ang.p, ang.y, ang.r = g.math.NormalizeAngle(ang.p), g.math.NormalizeAngle(ang.y), g.math.NormalizeAngle(ang.r)
					g.LocalPlayer():SetEyeAngles(ang)
					if GD.bools["aimautoshoot"] then
						attack()
					end

				end

			end

		end

		GD.Bones = { "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand", "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand", "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0", "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0" }
		function GD:FindToLook(target)
			local tolook = nil
			if not GD.bools["aimmanuel"] then
				for k = 1, #GD.Bones do
					if target:LookupBone(GD.Bones[k]) then
						tolook = target:GetBonePosition(target:LookupBone(GD.Bones[k]))
						if GD.Bones[k] == "ValveBiped.Bip01_Head1" then
							tolook = tolook + Vector(0, 0, 3)
						end

						if GD:HasLOS(target, tolook) then
							break
						else
							tolook = nil
						end

					end

				end

			end

			if tolook == nil then
				tolook = target:GetPos() + g.Vector(GetVar("aimx"), GetVar("aimy"), GetVar("aimz"))
			end

			return tolook
		end

		function GD:FindTarget()
			local tolook = nil
			local tolookg = nil
			if g.IsValid(GD.curtarg) and CheckKey(GD.binds["+aim"]) and not CheckKey(GD.binds["+triggerbot"]) and (not GD.curtarg:IsPlayer() or g.team.GetName(GD.curtarg:Team()) ~= "Spectators") then
				tolook = GD:FindToLook(GD.curtarg)
				local readyshoot, cyaw = GD:ReadyShoot(GD.curtarg)
				if GD:HasLOS(GD.curtarg, tolook) and readyshoot then
					return GD.curtarg, tolook
				else
					GD.curtarg = nil
					return false
				end

			else
				GD.curtarg = nil
			end

			local bestfov = 360
			for _, v in g.pairs(g.ents.GetAll()) do
				if g.IsValid(v) and (GD.bools["targetnpc"] and v:IsNPC()) or (GD.bools["targetplayer"] and v:IsPlayer() and g.team.GetName(v:Team()) ~= "Spectators") or (GD.bools["targetent"] and g.table.HasValue(GD.espents, v:GetClass())) then
					tolook = GD:FindToLook(v)
					local teamcheck = true
					local orgcheck = true
					local gdaapusercheck = true
					if v:IsPlayer() then
						local gdaapuser = false
						for id, user in g.pairs(GD.users) do
							if user["steamid"] == v:SteamID() and user["showonline"] == "1" and user["showinserver"] == "1" then
								gdaapuser = true
							end

						end

						if not GD.bools["aimteam"] and v:Team() == g.LocalPlayer():Team() then
							teamcheck = false
						end

						if not GD.bools["aimorg"] and g.type(v.GetOrganizationName) == "function" then
							if v:GetOrganizationName() == g.LocalPlayer():GetOrganizationName() then
								orgcheck = false
							end

						end

						if not GD.bools["aimatgdaap"] and gdaapuser then
							gdaapusercheck = false
						end

					end

					local readyshoot, cyaw = GD:ReadyShoot(v)
					if GD:HasLOS(v, tolook) and v ~= g.LocalPlayer() and readyshoot and gdaapusercheck and (teamcheck) and (orgcheck) and (not v:IsPlayer() or GD.friends[v:SteamID()] == nil) then
						if cyaw < bestfov then
							bestfov = cyaw
							tolookg = tolook
							GD.curtarg = v
							break
						end

					end

				end

			end

			return GD.curtarg, tolookg
		end

		function GD:Smoothang(ang)
			ang.p = g.math.NormalizeAngle(ang.p)
			ang.y = g.math.NormalizeAngle(ang.y)
			lpang = g.LocalPlayer():EyeAngles()
			local as = GetVar("aimantisnap")
			lpang.p = g.math.Approach(lpang.p, ang.p, as)
			lpang.y = g.math.Approach(lpang.y, ang.y, as)
			lpang.r = 0
			ang = lpang
			return ang
		end

		function GD:TriggerBot(ucmd)
			if (GD.vars["triggeractive"] == 2 or CheckKey(GD.binds["+triggerbot"])) then
				local Ent = g.LocalPlayer():GetEyeTrace().Entity
				if g.IsValid(Ent) and ((Ent:IsPlayer() and Ent:Alive() and not Ent:GetObserverTarget() and GD.bools["targetplayer"] and GD.friends[Ent:SteamID()] == nil) or (Ent:IsNPC() and GD.bools["targetnpc"])) and Ent ~= g.LocalPlayer() then
					GD.IsFiring = true
					attack()
				else
					GD.IsFiring = false
				end

			else
				GD.IsFiring = false
			end

		end

		function GD:Bhop(ucmd)
			if CheckKey(GD.binds["+bhop"]) and g.LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP then
				if g.LocalPlayer():OnGround() then
					AOTHCTBF("UUZJBEJB")
					g.timer.Simple(0, function()
						AOTHCTBF("HNOOBFJC")
					end)
				end

			end

		end

		function GD:showAddFriends(dpanelfriends)
			local addfriend_name = g.vgui.Create("DTextEntry", dpanelfriends)
			addfriend_name:SetPos(2, dpanelfriends:GetTall() - 65)
			addfriend_name:SetSize(dpanelfriends:GetWide() / 2 - 2, 30)
			addfriend_name:SetText("Name")
			local addfriend_steamid = g.vgui.Create("DTextEntry", dpanelfriends)
			addfriend_steamid:SetPos(dpanelfriends:GetWide() / 2 + 2, dpanelfriends:GetTall() - 65)
			addfriend_steamid:SetSize(dpanelfriends:GetWide() / 2 - 2, 30)
			addfriend_steamid:SetText("Steamid")
			local addfriend_gdaap = g.vgui.Create("DListView", dpanelfriends)
			local addfriend_server = g.vgui.Create("DListView", dpanelfriends)
			addfriend_server:SetPos(2, 2)
			addfriend_server:SetMultiSelect(false)
			addfriend_server:SetSize(dpanelfriends:GetWide() / 2 - 2, dpanelfriends:GetTall() - 70)
			addfriend_server:AddColumn("Users in server")
			addfriend_server:AddColumn("SteamID")
			for _, v in g.pairs(g.player.GetAll()) do
				addfriend_server:AddLine(v:Nick(), v:SteamID())
			end

			addfriend_server.OnClickLine = function(parent, line, isselected)
				addfriend_name:SetText(line:GetValue(1))
				addfriend_steamid:SetText(line:GetValue(2))
			end
			addfriend_gdaap:SetPos(dpanelfriends:GetWide() / 2 + 2, 2)
			addfriend_gdaap:SetMultiSelect(false)
			addfriend_gdaap:SetSize(dpanelfriends:GetWide() / 2 - 2, dpanelfriends:GetTall() - 70)
			addfriend_gdaap:AddColumn("gDaap users (With showsteamid on)")
			local ranks = { ["0"] = "", ["1"] = "* ", ["2"] = "** ", ["3"] = "*** " }
			tempusers = {  }
			for id, user in g.pairs(GD.users) do
				if user["rank"] == "3" then
					g.table.insert(tempusers, user)
				end

			end

			for id, user in g.pairs(GD.users) do
				if user["rank"] == "2" then
					g.table.insert(tempusers, user)
				end

			end

			for id, user in g.pairs(GD.users) do
				if user["rank"] == "1" then
					g.table.insert(tempusers, user)
				end

			end

			for id, user in g.pairs(GD.users) do
				if user["rank"] == "0" then
					g.table.insert(tempusers, user)
				end

			end

			for _, user in g.pairs(tempusers) do
				if user["steamid"] ~= "" and user["showsteamid"] == "1" then
					addfriend_gdaap:AddLine(user["username"], user["steamid"])
				end

			end

			addfriend_gdaap.OnClickLine = function(parent, line, isselected)
				addfriend_name:SetText(line:GetValue(1))
				addfriend_steamid:SetText(line:GetValue(2))
			end
			local addfriend_add = g.vgui.Create("DButton", dpanelfriends)
			local addfriend_back = g.vgui.Create("DButton", dpanelfriends)
			addfriend_back:SetText("Back")
			addfriend_back:SetSize(dpanelfriends:GetWide() / 2 - 2, 30)
			addfriend_back:SetPos(2, dpanelfriends:GetTall() - 30)
			addfriend_back.DoClick = function()
				addfriend_name:Remove()
				addfriend_steamid:Remove()
				addfriend_server:Remove()
				addfriend_gdaap:Remove()
				addfriend_back:Remove()
				addfriend_add:Remove()
				GD:showFriends(dpanelfriends, false)
			end
			addfriend_add:SetText("Add friend")
			addfriend_add:SetPos(dpanelfriends:GetWide() / 2 + 2, dpanelfriends:GetTall() - 30)
			addfriend_add:SetSize(dpanelfriends:GetWide() / 2 - 2, 30)
			addfriend_add.DoClick = function()
				GD.friends[addfriend_steamid:GetText()] = addfriend_name:GetText()
				addfriend_name:Remove()
				addfriend_steamid:Remove()
				addfriend_server:Remove()
				addfriend_gdaap:Remove()
				addfriend_back:Remove()
				addfriend_add:Remove()
				GD:showFriends(dpanelfriends, false)
			end
		end

		function GD:showFriends(dpanelfriends, firsttime)
			local friends = g.vgui.Create("DListView", dpanelfriends)
			friends:SetPos(2, 2)
			friends:SetMultiSelect(false)
			local varb = 2
			if firsttime then
				varb = 15
			end

			local var = 35
			if firsttime then
				var = 42
			end

			friends:SetSize(dpanelfriends:GetWide() - varb, dpanelfriends:GetTall() - var)
			friends:AddColumn("Name")
			friends:AddColumn("SteamID")
			for steamid, name in g.pairs(GD.friends) do
				friends:AddLine(name, steamid)
			end

			local removefriend = g.vgui.Create("DButton", dpanelfriends)
			local addfriend = g.vgui.Create("DButton", dpanelfriends)
			addfriend:SetText("Add friend")
			var = 2
			if firsttime then
				var = 8
			end

			addfriend:SetSize(dpanelfriends:GetWide() / 2 - var, 30)
			var = 30
			if firsttime then
				var = 37
			end

			addfriend:SetPos(2, dpanelfriends:GetTall() - var)
			addfriend.DoClick = function()
				friends:Remove()
				addfriend:Remove()
				removefriend:Remove()
				GD:showAddFriends(dpanelfriends)
			end
			removefriend:SetText("Remove friend")
			var = 2
			if firsttime then
				var = 8
			end

			removefriend:SetSize(dpanelfriends:GetWide() / 2 - var, 30)
			varb = dpanelfriends:GetWide() / 2 + 2
			if firsttime then
				varb = dpanelfriends:GetWide() / 2 - 4
			end

			var = 30
			if firsttime then
				var = 37
			end

			removefriend:SetPos(varb, dpanelfriends:GetTall() - var)
			removefriend.DoClick = function()
				local line = friends:GetSelectedLine()
				if line ~= nil then
					local steamid = friends:GetLine(line):GetValue(2)
					GD.friends[steamid] = nil
					friends:Clear()
					for steamid, name in g.pairs(GD.friends) do
						friends:AddLine(name, steamid)
					end

				end

			end
		end

		function GD:ShowMenu()
			local back = g.vgui.Create("DFrame")
			back:SetSize(576, 300)
			back:ShowCloseButton(false)
			back:Center()
			back:MakePopup()
			back.Paint = function()
				g.draw.RoundedBox(0, 0, 0, back:GetWide(), back:GetTall(), g.Color(0, 0, 0, 0))
			end
			GD.menuitems = {  }
			local tablist = g.vgui.Create("DPropertySheet", back)
			tablist:SetPos(0, 0)
			tablist:SetSize(back:GetWide(), back:GetTall())
			local function AddCheckItem(dpanel, bool, text, x, y)
				local checkbox = g.vgui.Create("DCheckBoxLabel", dpanel)
				checkbox:SetPos(x, y)
				checkbox:SetText(text)
				checkbox:SizeToContents()
				checkbox:SetTextColor(Color(255, 255, 255))
				checkbox:SetChecked(GD.bools[bool])
				checkbox.OnChange = function(chk)
					GD.bools[bool] = checkbox:GetChecked()
				end
				GD.menuitems[bool] = checkbox
				return checkbox
			end

			local function AddNumItem(dpanel, var, text, min, max, width, x, y, decimals)
				local numslider = g.vgui.Create("DNumSlider", dpanel)
				numslider:SetText(text)
				numslider:SetWide(width)
				numslider:SetDecimals(decimals)
				numslider:SetMin(min)
				numslider:SetMax(max)
				numslider:SetPos(x, y)
				numslider:SetValue(GetVar(var))
				numslider.OnValueChanged = function(p, v)
					GD.vars[var] = v
				end
				GD.menuitems[var] = numslider
				return numslider
			end

			local function AddComboBox(dpanel, fields, x, y, multiple)
				if multiple == nil then
					multiple = false
				end

				local combobox = g.vgui.Create("DComboBox", dpanel)
				combobox:SetWide(width)
				combobox:SetPos(x, y)
				combobox:SetMultiple(multiple)
				for _, value in g.pairs(fields) do
					combobox:AddItem(value)
				end

			end

			local dpanelhome = g.vgui.Create("DPanelList")
			dpanelhome:SetName("info_tab")
			dpanelhome:SetPos(2, 27)
			dpanelhome:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelhome:SetSpacing(5)
			dpanelhome:EnableHorizontal(false)
			dpanelhome:EnableVerticalScrollbar(false)
			dpanelhome.Paint = function()
				g.draw.SimpleText("gDaap", "Logo", 25, 1, g.Color(0, 30, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				g.draw.SimpleText("v" .. GD.version, "Logo", 265, 1, g.Color(0, 255, 30, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
			end
			local joinserver = g.vgui.Create("DButton", dpanelhome)
			joinserver:SetText("Join gDaap Hack vs Hack server")
			joinserver:SetSize(250, 20)
			joinserver:SetPos(dpanelhome:GetWide() / 2 - (joinserver:GetWide() / 2), 100)
			joinserver.DoClick = function()
				AOTHCTBF("gDaapServer")
			end
			local tab = ""
			for var = 0, 5 do
				tab = tab .. string.char(32)
			end

			local dchangelog = g.vgui.Create("DListView", dpanelhome)
			dchangelog:SetPos(5, 130)
			dchangelog:SetMultiSelect(false)
			dchangelog:SetSize(dpanelhome:GetWide() - 20, dpanelhome:GetTall() - 140)
			dchangelog:AddColumn("Changelog")
			for number, line in g.pairs(g.string.Explode("\n", GD.changelog)) do
				if line ~= "" then
					if not (g.string.sub(line, 0, 1) == "v" and g.string.sub(line, g.string.len(line)) == ":") then
						line = tab .. line
					end

					dchangelog:AddLine(line)
				end

			end

			local dpanelaim = g.vgui.Create("DPanelList")
			dpanelaim:SetName("aim_tab")
			dpanelaim:SetPos(2, 27)
			dpanelaim:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelaim:SetSpacing(5)
			dpanelaim:EnableHorizontal(false)
			dpanelaim:EnableVerticalScrollbar(false)
			local dpanelesp = g.vgui.Create("DPanelList")
			dpanelesp:SetName("esp_tab")
			dpanelesp:SetPos(2, 27)
			dpanelesp:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelesp:SetSpacing(5)
			dpanelesp:EnableHorizontal(false)
			dpanelesp:EnableVerticalScrollbar(false)
			local dpanelmisc = g.vgui.Create("DPanelList")
			dpanelmisc:SetName("misc_tab")
			dpanelmisc:SetPos(2, 27)
			dpanelmisc:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelmisc:SetSpacing(5)
			dpanelmisc:EnableHorizontal(false)
			dpanelmisc:EnableVerticalScrollbar(false)
			local dpanelents = g.vgui.Create("DPanelList")
			dpanelents:SetName("ents_tab")
			dpanelents:SetPos(2, 27)
			dpanelents:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelents:SetSpacing(5)
			dpanelents:EnableHorizontal(false)
			dpanelents:EnableVerticalScrollbar(false)
			local allents = g.vgui.Create("DListView", dpanelents)
			allents:SetPos(2, 2)
			allents:SetMultiSelect(false)
			allents:SetSize(dpanelents:GetWide() / 2 - 50, dpanelents:GetTall() - 10)
			allents:AddColumn("Not On ESP")
			local addedent = {  }
			for _, v in g.ipairs(ents.GetAll()) do
				if not g.table.HasValue(addedent, v:GetClass()) and not g.table.HasValue(GD.espents, v:GetClass()) and v:GetClass() ~= "player" then
					allents:AddLine(v:GetClass())
					g.table.insert(addedent, v:GetClass())
				end

			end

			local custents = g.vgui.Create("DListView", dpanelents)
			custents:SetPos(dpanelents:GetWide() / 2 + 50, 2)
			custents:SetMultiSelect(false)
			custents:SetSize(dpanelents:GetWide() / 2 - 65, dpanelents:GetTall() - 10)
			custents:AddColumn("On ESP")
			for _, v in g.pairs(GD.espents) do
				custents:AddLine(v)
			end

			local add = g.vgui.Create("DButton", dpanelents)
			add:SetText("-->")
			add:SetSize(50, 20)
			add:SetPos(dpanelents:GetWide() / 2 - (add:GetWide() / 2), dpanelents:GetTall() / 2 - 10)
			add.DoClick = function()
				local line = allents:GetSelectedLine()
				if line ~= nil then
					local eclass = allents:GetLine(line):GetValue(1)
					if not g.table.HasValue(GD.espents, eclass) then
						g.table.insert(GD.espents, eclass)
						custents:AddLine(eclass)
						allents:RemoveLine(line)
					end

				end

			end
			local remove = g.vgui.Create("DButton", dpanelents)
			remove:SetText("<--")
			remove:SetSize(50, 20)
			remove:SetPos(dpanelents:GetWide() / 2 - (add:GetWide() / 2), dpanelents:GetTall() / 2 + 10)
			remove.DoClick = function()
				local line = custents:GetSelectedLine()
				if line ~= nil then
					local eclass = custents:GetLine(line):GetValue(1)
					if g.table.HasValue(GD.espents, eclass) then
						for k, v in g.pairs(GD.espents) do
							if v == eclass then
								g.table.remove(GD.espents, k)
							end

						end

						allents:AddLine(eclass)
						custents:RemoveLine(line)
					end

				end

			end
			local dpanellog = g.vgui.Create("DPanelList")
			dpanellog:SetName("log_tab")
			dpanellog:SetPos(2, 27)
			dpanellog:SetSize(tablist:GetWide() - 4, dpanelents:GetTall() - 10)
			dpanellog:SetSpacing(5)
			dpanellog:EnableHorizontal(false)
			dpanellog:EnableVerticalScrollbar(false)
			local dlog = g.vgui.Create("DListView", dpanellog)
			dlog:SetPos(122, 2)
			dlog:SetMultiSelect(false)
			dlog:SetSize(dpanellog:GetWide() - 139, dpanellog:GetTall() - 3)
			dlog:AddColumn("Log")
			for i = #GD.log, 1, -1 do
				dlog:AddLine(GD.log[i])
			end

			local clear = g.vgui.Create("DButton", dpanellog)
			clear:SetText("Clear")
			clear:SetSize(100, 20)
			clear:SetPos(5, 215)
			clear.DoClick = function()
				dlog:Clear()
				GD.log = {  }
			end
			local update = g.vgui.Create("DButton", dpanellog)
			update:SetText("Update")
			update:SetSize(100, 20)
			update:SetPos(5, 240)
			update.DoClick = function()
				dlog:Clear()
				for i = #GD.log, 1, -1 do
					dlog:AddLine(GD.log[i])
				end

			end
			local dpanelfriends = g.vgui.Create("DPanelList")
			dpanelfriends:SetName("friends_tab")
			dpanelfriends:SetPos(2, 27)
			dpanelfriends:SetSize(tablist:GetWide() - 4, tablist:GetTall() - 29)
			dpanelfriends:SetSpacing(5)
			dpanelfriends:EnableHorizontal(false)
			dpanelfriends:EnableVerticalScrollbar(false)
			GD:showFriends(dpanelfriends, true)
			local dpanelcon = g.vgui.Create("DPanelList")
			dpanelcon:SetName("con_tab")
			dpanelcon:SetPos(2, 27)
			dpanelcon:SetSize(tablist:GetWide() - 4, dpanelcon:GetTall() - 10)
			dpanelcon:SetSpacing(5)
			dpanelcon:EnableHorizontal(false)
			dpanelcon:EnableVerticalScrollbar(false)
			DList = g.vgui.Create("DListView", dpanelcon)
			DList:SetPos(2, 24)
			DList:SetSize(tablist:GetWide() - 19, tablist:GetTall() - 63)
			DList:AddColumn("Console")
			local txt = g.vgui.Create("DTextEntry", dpanelcon)
			txt:SetWide(tablist:GetWide() - 130)
			txt:SetPos(2, 2)
			txt.OnGetFocus = function()
				GD.confocus = true
			end
			txt.OnLoseFocus = function()
				GD.confocus = false
			end
			txt.OnEnter = function()
				GD:AddToConsole(DList, "] " .. txt:GetValue())
				GD:AddToConsole(DList, GD:ParseCommand(txt:GetValue(), DList))
				txt:SetText("")
				g.timer.Create("requestfocus_delay", 0.1, 1, function()
					txt:RequestFocus()
				end)
			end
			local dpanelchat = g.vgui.Create("DPanelList")
			dpanelchat:SetName("chat_tab")
			dpanelchat:SetPos(2, 2)
			dpanelchat:SetSize(tablist:GetWide() - 4, dpanelchat:GetTall() - 10)
			dpanelchat:SetSpacing(5)
			dpanelchat:EnableHorizontal(false)
			dpanelchat:EnableVerticalScrollbar(false)
			DList3 = g.vgui.Create("DListView", dpanelchat)
			DList3:SetPos(2, 0)
			DList3:SetSize(tablist:GetWide() - 180, tablist:GetTall() - 65)
			DList3:AddColumn("Chat")
			if GD.bools["chat_enabled"] then
				DList3:AddLine("Loading...")
			else
				DList3:AddLine("Chat disabled")
			end

			DList3.OnClickLine = function()
				return false
			end
			DList2 = g.vgui.Create("DListView", dpanelchat)
			DList2:SetPos(tablist:GetWide() - 170, 0)
			DList2:SetSize(150, tablist:GetTall() - 65)
			DList2:AddColumn("Id"):SetFixedWidth(0)
			DList2:AddColumn("Online"):SetFixedWidth(150)
			DList2.OnClickLine = function(parent, line, isselected)
				if g.IsValid(chatpopup) then
					chatpopup:Close()
				end

				local uid = line:GetValue(1)
				local username = line:GetValue(2)
				if GD.users[uid] ~= nil then
					chatpopup = g.vgui.Create("DFrame")
					chatpopup:SetSize(200, 300)
					chatpopup:ShowCloseButton(true)
					chatpopup:SetTitle("User info")
					chatpopup:Center()
					chatpopup:MakePopup()
					chatpopup:SetDraggable(true)
					chatpopup.Paint = function()
						g.draw.RoundedBox(0, 0, 0, chatpopup:GetWide(), chatpopup:GetTall(), grey)
					end
					local usernamelabel = vgui.Create("DLabel", chatpopup)
					usernamelabel:SetPos(5, 30)
					usernamelabel:SetWide(chatpopup:GetWide() - 10)
					usernamelabel:SetColor(white)
					usernamelabel:SetText(username)
					usernamelabel:SetFont("default")
					local serveriplabel = vgui.Create("DLabel", chatpopup)
					serveriplabel:SetPos(5, 60)
					serveriplabel:SetWide(chatpopup:GetWide() - 10)
					serveriplabel:SetColor(white)
					serveriplabel:SetText("Server ip:")
					serveriplabel:SetFont("default")
					local height = 80
					local serveriptxt = g.vgui.Create("DTextEntry", chatpopup)
					serveriptxt:SetWide(chatpopup:GetWide() - 10)
					serveriptxt:SetPos(5, height)
					serveriptxt:SetEditable(false)
					if GD.users[uid]["showserverip"] == "1" then
						serveriptxt:SetText(GD.users[uid]["serverip"])
					else
						serveriptxt:SetText("** Hidden **")
					end

					if GD.users[uid]["showserverip"] == "1" and GD.users[uid]["serverip"] ~= "Singleplayer" then
						height = height + 20
						local serveripbutton = g.vgui.Create("DButton", chatpopup)
						serveripbutton:SetText("Join server")
						serveripbutton:SetSize(chatpopup:GetWide() - 10, 20)
						serveripbutton:SetPos(5, height)
						serveripbutton.DoClick = function()
							g.LocalPlayer():ConCommand("connect " .. g.tostring(GD.users[uid]["serverip"]))
						end
					end

					height = height + 20
					local ingamenamelabel = vgui.Create("DLabel", chatpopup)
					ingamenamelabel:SetPos(5, height)
					ingamenamelabel:SetWide(chatpopup:GetWide() - 10)
					ingamenamelabel:SetColor(white)
					ingamenamelabel:SetText("Ingame name:")
					ingamenamelabel:SetFont("default")
					height = height + 20
					local ingamenametxt = g.vgui.Create("DTextEntry", chatpopup)
					ingamenametxt:SetWide(chatpopup:GetWide() - 10)
					ingamenametxt:SetPos(5, height)
					ingamenametxt:SetEditable(false)
					if GD.users[uid]["showingamename"] == "1" then
						ingamenametxt:SetText(GD.users[uid]["ingamename"])
					else
						ingamenametxt:SetText("** Hidden **")
					end

					height = height + 20
					local steamidlabel = vgui.Create("DLabel", chatpopup)
					steamidlabel:SetPos(5, height)
					steamidlabel:SetWide(chatpopup:GetWide() - 10)
					steamidlabel:SetColor(white)
					steamidlabel:SetText("SteamID:")
					steamidlabel:SetFont("default")
					height = height + 20
					local steamidtxt = g.vgui.Create("DTextEntry", chatpopup)
					steamidtxt:SetWide(chatpopup:GetWide() - 10)
					steamidtxt:SetPos(5, height)
					steamidtxt:SetEditable(false)
					if GD.users[uid]["showsteamid"] == "1" then
						steamidtxt:SetText(GD.users[uid]["steamid"])
					else
						steamidtxt:SetText("** Hidden **")
					end

				end

				return false
			end
			chattxt = g.vgui.Create("DTextEntry", dpanelchat)
			chattxt:SetEditable(false)
			chattxt:SetWide(tablist:GetWide() - 180)
			chattxt:SetPos(2, tablist:GetTall() - 58)
			chattxt.OnGetFocus = function()
				GD.confocus = true
			end
			chattxt.OnLoseFocus = function()
				GD.confocus = false
			end
			updatechat(true)
			chattxt.OnEnter = function()
				sendChatMessage(chattxt:GetValue())
			end
			local chatsettings = g.vgui.Create("DButton", dpanelchat)
			chatsettings:SetText("Settings")
			chatsettings:SetSize(150, 20)
			chatsettings:SetPos(tablist:GetWide() - 170, tablist:GetTall() - 58)
			chatsettings.DoClick = function()
				if g.IsValid(chatpopup) then
					chatpopup:Close()
				end

				local uid = g.tonumber(GD:ConnectToServer("")["uid"])
				if GD.users[uid] ~= nil then
					chatpopup = g.vgui.Create("DFrame")
					chatpopup:SetSize(200, 300)
					chatpopup:ShowCloseButton(true)
					chatpopup:SetTitle("Online settings")
					chatpopup:Center()
					chatpopup:MakePopup()
					chatpopup:SetDraggable(true)
					chatpopup.Paint = function()
						g.draw.RoundedBox(0, 0, 0, chatpopup:GetWide(), chatpopup:GetTall(), grey)
					end
					local chatenabled = g.vgui.Create("DCheckBoxLabel", chatpopup)
					chatenabled:SetText("Enable chat localy")
					chatenabled:SetPos(5, 30)
					chatenabled:SizeToContents()
					chatenabled:SetTextColor(Color(255, 255, 255))
					chatenabled:SetChecked(GD.bools["chat_enabled"])
					chatenabled.OnChange = function(chk)
						GD.bools["chat_enabled"] = chatenabled:GetChecked()
						txt:SetEditable(chatenabled:GetChecked())
						GD.updatechat = true
						updatechat(true)
					end
					local chatenabled = g.vgui.Create("DCheckBoxLabel", chatpopup)
					chatenabled:SetText("Print gDaap chat in normal chat")
					chatenabled:SetPos(5, 50)
					chatenabled:SizeToContents()
					chatenabled:SetTextColor(Color(255, 255, 255))
					chatenabled:SetChecked(GD.bools["chat_print"])
					chatenabled.OnChange = function(chk)
						GD.bools["chat_print"] = chatenabled:GetChecked()
					end
					local showonline = g.vgui.Create("DCheckBoxLabel", chatpopup)
					showonline:SetText("Show my online status")
					showonline:SetPos(5, 90)
					showonline:SizeToContents()
					showonline:SetTextColor(Color(255, 255, 255))
					showonline:SetChecked(GD.users[uid]["showonline"])
					showonline.OnChange = function(chk)
						local checked = "0"
						if showonline:GetChecked() then
							checked = "1"
						end

						GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "showonline", ["value"] = checked }, function(result)
							UpdateUserList()
						end, function(result)
						end)
					end
					local showonline = g.vgui.Create("DCheckBoxLabel", chatpopup)
					showonline:SetText("Show me in server")
					showonline:SetPos(5, 110)
					showonline:SizeToContents()
					showonline:SetTextColor(Color(255, 255, 255))
					showonline:SetChecked(GD.users[uid]["showinserver"])
					showonline.OnChange = function(chk)
						local checked = "0"
						if showonline:GetChecked() then
							checked = "1"
						end

						GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "showinserver", ["value"] = checked }, function(result)
							UpdateUserList()
						end, function(result)
						end)
					end
					local showserverip = g.vgui.Create("DCheckBoxLabel", chatpopup)
					showserverip:SetText("Show my current server ip")
					showserverip:SetPos(5, 130)
					showserverip:SizeToContents()
					showserverip:SetTextColor(Color(255, 255, 255))
					showserverip:SetChecked(GD.users[uid]["showserverip"])
					showserverip.OnChange = function(chk)
						local checked = "0"
						if showserverip:GetChecked() then
							checked = "1"
						end

						GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "showserverip", ["value"] = checked }, function(result)
							UpdateUserList()
						end, function(result)
						end)
					end
					local showingamename = g.vgui.Create("DCheckBoxLabel", chatpopup)
					showingamename:SetText("Show my ingame name")
					showingamename:SetPos(5, 150)
					showingamename:SizeToContents()
					showingamename:SetTextColor(Color(255, 255, 255))
					showingamename:SetChecked(GD.users[uid]["showingamename"])
					showingamename.OnChange = function(chk)
						local checked = "0"
						if showingamename:GetChecked() then
							checked = "1"
						end

						GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "showingamename", ["value"] = checked }, function(result)
							UpdateUserList()
						end, function(result)
						end)
					end
					local showsteamid = g.vgui.Create("DCheckBoxLabel", chatpopup)
					showsteamid:SetText("Show my steamID")
					showsteamid:SetPos(5, 180)
					showsteamid:SizeToContents()
					showsteamid:SetTextColor(Color(255, 255, 255))
					showsteamid:SetChecked(GD.users[uid]["showsteamid"])
					showsteamid.OnChange = function(chk)
						local checked = "0"
						if showsteamid:GetChecked() then
							checked = "1"
						end

						GD:ConnectToServer({ ["setuserinfo"] = "", ["field"] = "showsteamid", ["value"] = checked }, function(result)
							UpdateUserList()
						end, function(result)
						end)
					end
				end

			end
			local nonvip = " *VIP*"
			nonvip = ""
			local aimbotbox = g.vgui.Create("DListView", dpanelaim)
			aimbotbox:SetPos(5, 5)
			aimbotbox:SetMultiSelect(false)
			aimbotbox:SetSize(120, 68)
			aimbotbox:AddColumn("Aimbot status")
			local aimbotoptions = { "ON when button down", "Always ON", "Always OFF" }
			for i = #aimbotoptions, 1, -1 do
				local line = aimbotbox:AddLine(aimbotoptions[i])
				if line:GetID() == GD.vars["aimactive"] then
					aimbotbox:SelectItem(line)
				end

			end

			aimbotbox.OnClickLine = function(parent, line, isselected)
				aimbotbox:ClearSelection()
				aimbotbox:SelectItem(line)
				GD.vars["aimactive"] = line:GetID()
			end
			local triggerbotbox = g.vgui.Create("DListView", dpanelaim)
			triggerbotbox:SetPos(150, 5)
			triggerbotbox:SetMultiSelect(false)
			triggerbotbox:SetSize(120, 68)
			triggerbotbox:AddColumn("Triggerbot status")
			local triggerbotoptions = { "ON when button down", "Always ON", "Always OFF" }
			for i = #triggerbotoptions, 1, -1 do
				local line = triggerbotbox:AddLine(triggerbotoptions[i])
				if line:GetID() == GD.vars["triggeractive"] then
					triggerbotbox:SelectItem(line)
				end

			end

			triggerbotbox.OnClickLine = function(parent, line, isselected)
				triggerbotbox:ClearSelection()
				triggerbotbox:SelectItem(line)
				GD.vars["triggeractive"] = line:GetID()
			end
			AddCheckItem(dpanelaim, "drawaimnoti", "Show \"Scanning\"", 5, 80)
			AddCheckItem(dpanelaim, "drawtriggernoti", "Show \"Scanning\"", 150, 80)
			AddCheckItem(dpanelaim, "aimautoshoot", "Auto-Shoot", 5, 130)
			AddCheckItem(dpanelaim, "aimautoreload", "Auto-Reload", 150, 130)
			AddCheckItem(dpanelaim, "aimteam", "Aim At Team", 5, 180)
			AddCheckItem(dpanelaim, "aimatgdaap", "Aim At gDaap user", 5, 205)
			AddCheckItem(dpanelaim, "aimorg", "Aim at PEPR org", 5, 230)
			AddCheckItem(dpanelaim, "targetnpc", "Target NPC's", 150, 180)
			AddCheckItem(dpanelaim, "targetplayer", "Target Players", 150, 205)
			AddCheckItem(dpanelaim, "targetent", "Target Ents", 150, 230)
			AddCheckItem(dpanelaim, "checklos", "Check LOS", 340, 5)
			AddCheckItem(dpanelesp, "espactive", "ESP Active", 5, 5)
			AddCheckItem(dpanelesp, "espplayers", "Show Players", 5, 30)
			AddCheckItem(dpanelesp, "espnpcs", "Show NPCs", 5, 55)
			AddCheckItem(dpanelesp, "espents", "Show Ents", 5, 80)
			AddCheckItem(dpanelesp, "esphealth", "Show Health", 5, 105)
			AddCheckItem(dpanelesp, "esparmor", "Show Armor", 5, 130)
			AddCheckItem(dpanelesp, "espteam", "Show Team", 5, 155)
			AddCheckItem(dpanelesp, "espadmin", "Show Rank", 5, 180)
			AddCheckItem(dpanelesp, "espweapon", "Show Weapon", 5, 205)
			AddCheckItem(dpanelesp, "espname", "Show name", 5, 230)
			AddCheckItem(dpanelesp, "espchams", "Wallhack Active", 150, 5)
			AddCheckItem(dpanelesp, "espwireframe", "Wireframe Wallhack", 150, 30)
			AddCheckItem(dpanelesp, "espsolid", "Solid Wallhack", 150, 55)
			AddCheckItem(dpanelesp, "esprpname", "PERP Show rp name", 150, 105)
			AddCheckItem(dpanelesp, "esporg", "PERP Show org", 150, 130)
			AddCheckItem(dpanelesp, "gdaaptag", "gDaap tag", 150, 155)
			AddCheckItem(dpanelesp, "eyetracer", "Eye tracer", 150, 180)
			AddCheckItem(dpanelesp, "drawcrosshair", "Always draw crosshair", 150, 205)
			AddCheckItem(dpanelesp, "nosmoke", "No smoke/fire*", 150, 230)
			AddNumItem(dpanelesp, "espchamdist", "Cham Distance", 0, 20000, 150, 340, 5, 0)
			AddNumItem(dpanelesp, "esptextdist", "ESP Distance", 0, 20000, 150, 340, 30, 0)
			AddCheckItem(dpanelesp, "radar", "Enable radar" .. nonvip, 340, 80)
			AddCheckItem(dpanelesp, "radar_outline", "Radar outline", 340, 105)
			AddCheckItem(dpanelesp, "radar_cross", "Radar cross", 340, 130)
			AddCheckItem(dpanelesp, "radar_names", "Radar names", 340, 155)
			AddNumItem(dpanelesp, "radar_size", "Radar size", 200, 500, 150, 340, 180, 0)
			AddNumItem(dpanelesp, "radar_pixrat", "Radar pixrat", 15, 100, 150, 340, 205, 0)
			AddCheckItem(dpanellog, "lognet", "Log Net", 5, 5)
			AddCheckItem(dpanellog, "logfile", "Log File", 5, 25)
			AddCheckItem(dpanellog, "loghook", "Log Hook", 5, 45)
			AddCheckItem(dpanellog, "logrcc", "Log RCC", 5, 65)
			AddCheckItem(dpanellog, "logcc", "Log ConCommand", 5, 85)
			AddCheckItem(dpanellog, "loggcv", "Log GetConVar", 5, 105)
			AddCheckItem(dpanellog, "logblocs", "Log Blocked", 5, 125)
			AddCheckItem(dpanellog, "printlog", "Show In Console", 5, 145)
			AddCheckItem(dpanellog, "logbypass", "Log AC Bypass", 5, 165)
			AddCheckItem(dpanelcon, "printconsole", "Show In Console", 455, 5)
			AddCheckItem(dpanelmisc, "miscbhop", "Enable Bunnyhop", 5, 5)
			AddCheckItem(dpanelmisc, "speedhack", "Speedhack Enabled*" .. nonvip, 5, 30)
			AddCheckItem(dpanelmisc, "norecoil", "No-Recoil", 5, 55)
			AddCheckItem(dpanelmisc, "fixscreen", "Remove screen shake", 5, 80)
			AddCheckItem(dpanelmisc, "adminbox", "Show admin box", 5, 105)
			AddCheckItem(dpanelmisc, "player_info", "Show own player info", 5, 130)
			AddCheckItem(dpanelmisc, "keypad_logger", "DarkRP Keypad logger" .. nonvip, 5, 155)
			AddCheckItem(dpanelmisc, "ttt_finder", "TTT Show traitors" .. nonvip, 5, 180)
			AddCheckItem(dpanelmisc, "perp_drug_info", "PERP Show info" .. nonvip, 5, 205)
			AddCheckItem(dpanelmisc, "perp_infinite_fuel", "PERP Infinite fuel" .. nonvip, 5, 230)
			AddCheckItem(dpanelmisc, "thirdperson", "Third Person", 180, 5)
			AddCheckItem(dpanelmisc, "fullbright", "Fullbright*", 180, 30)
			AddCheckItem(dpanelmisc, "notifications", "Notifications bar", 180, 55)
			AddCheckItem(dpanelmisc, "show_spectators", "Show spectators", 180, 80)
			AddCheckItem(dpanelmisc, "miscblockrcc", "Block RCC" .. nonvip, 180, 105)
			AddCheckItem(dpanelmisc, "miscblocknet", "Block Net" .. nonvip, 180, 130)
			AddCheckItem(dpanelmisc, "map", "Show map*" .. nonvip, 180, 155)
			AddCheckItem(dpanelmisc, "antiafk", "Anti afk", 180, 180)
			AddCheckItem(dpanelmisc, "attackspam", "Left click spam", 180, 205)
			AddCheckItem(dpanelmisc, "advert", "Advert for gDaap", 180, 230)
			AddCheckItem(dpanelmisc, "autosvcheat", "Auto sv_cheats *", 340, 5)
			AddCheckItem(dpanelmisc, "checksvcheat", "Check sv_cheats", 340, 30)
			AddCheckItem(dpanelmisc, "autosave", "Auto Save Configs", 340, 80)
			AddNumItem(dpanelaim, "aimfov", "FOV", 1, 180, 150, 340, 30, 0)
			AddNumItem(dpanelaim, "aimdistance", "Distance", 0, 20000, 150, 340, 55, 0)
			AddCheckItem(dpanelaim, "aimantisnap", "Anti-Snap", 340, 105)
			AddNumItem(dpanelaim, "aimantisnap", "Anti-Snap Speed", 0, 20, 150, 340, 115, 1)
			AddCheckItem(dpanelaim, "aimmanuel", "Aim manuel X, Y, Z", 340, 165)
			AddNumItem(dpanelaim, "aimx", "X Offset", 0, 256, 150, 340, 180, 0)
			AddNumItem(dpanelaim, "aimy", "Y Offset", 0, 256, 150, 340, 205, 0)
			AddNumItem(dpanelaim, "aimz", "Z Offset", 0, 256, 150, 340, 230, 0)
			local info_tab = tablist:AddSheet("Home", dpanelhome, "icon16/star.png", false, false, "gDaap Home")
			local aim_tab = tablist:AddSheet("Aimbot", dpanelaim, "icon16/user.png", false, false, "Aimbot Settings")
			local esp_tab = tablist:AddSheet("ESP/Wallhack", dpanelesp, "icon16/picture_edit.png", false, false, "ESP/Wallhack Settings")
			local ent_tab = tablist:AddSheet("Entities", dpanelents, "icon16/brick_add.png", false, false, "Entities")
			local misc_tab = tablist:AddSheet("Misc", dpanelmisc, "icon16/world.png", false, false, "Miscellaneous Settings")
			local log_tab = tablist:AddSheet("Log", dpanellog, "icon16/folder_go.png", false, false, "RCC/Net Logs")
			local friends_tab = tablist:AddSheet("Friends", dpanelfriends, "icon16/group.png", false, false, "Friends List")
			local con_tab = tablist:AddSheet("Console", dpanelcon, "icon16/application_osx_terminal.png", false, false, "gDaap Console")
			local chat_tab = tablist:AddSheet("Chat", dpanelchat, "icon16/user_comment.png", false, false, "gDaap Chat")
			local tabs = { ["info_tab"] = info_tab, ["aim_tab"] = aim_tab, ["esp_tab"] = esp_tab, ["ents_tab"] = ent_tab, ["misc_tab"] = misc_tab, ["log_tab"] = log_tab, ["friends_tab"] = friends_tab, ["con_tab"] = con_tab, ["chat_tab"] = chat_tab }
			back.Think = function()
				if g.IsValid(DList2) and g.IsValid(DList) then
					updatechat(false)
				end

				if (CheckKey(GD.binds["menu_toggle"], true) and not GD.menupress) or not GD.loaded then
					GD.updatechat = true
					GD.updateonline = true
					GD.menuopen = false
					GD.activetab = tablist:GetActiveTab():GetPanel():GetName()
					back:Close()
					GD.menuitems = {  }
					if g.IsValid(chatpopup) then
						chatpopup:Close()
					end

					if GD.bools["autosave"] then
						GD:SaveConfig()
					end

					GD.menupress = true
				end

			end
			if GD.activetab then
				tablist:SetActiveTab(tabs[GD.activetab].Tab)
			end

		end

		local function TurnOffAutoSvCheat()
			GD.checksvcheatchecking = false
			GD.checksvcheatconfirm = false
			GD.bools["autosvcheat"] = false
			Notify(true, red, "Sorry but 'Auto sv_cheats' won't work for some reason.")
			if GD.menuitems["autosvcheat"] ~= nil then
				GD.menuitems["autosvcheat"]:SetValue(0)
			end

		end

		local function CheckCheat()
			if GD.bools["autosvcheat"] then
				if GD.checksvcheatconfirm then
										if GD.fullbright or GD.nosmoke or GD.lastmapvalue ~= 0 or GD.speedhackison then
						if not checksvcheat() then
							AOTHCTBF("WGSQHPDB")
							GD:LogAction("[Auto sv_cheats] Turned sv_cheats on")
						end

					elseif checksvcheat() then
						AOTHCTBF("PEEVDPAR")
						GD:LogAction("[Auto sv_cheats] Turned sv_cheats off")
					end

				else
					CheckAutoSvCheats()
					g.timer.Simple(0.3, function()
						CheckCheat()
					end)
				end

			end

		end

		local X = -50
		local Y = -100
		local keypad_KeyPos = { { X + 5, Y + 100, 25, 25, -2.2, 3.45, 1.3, -0 }, { X + 37.5, Y + 100, 25, 25, -0.6, 1.85, 1.3, -0 }, { X + 70, Y + 100, 25, 25, 1.0, 0.25, 1.3, -0 }, { X + 5, Y + 132.5, 25, 25, -2.2, 3.45, 2.9, -1.6 }, { X + 37.5, Y + 132.5, 25, 25, -0.6, 1.85, 2.9, -1.6 }, { X + 70, Y + 132.5, 25, 25, 1.0, 0.25, 2.9, -1.6 }, { X + 5, Y + 165, 25, 25, -2.2, 3.45, 4.55, -3.3 }, { X + 37.5, Y + 165, 25, 25, -0.6, 1.85, 4.55, -3.3 }, { X + 70, Y + 165, 25, 25, 1.0, 0.25, 4.55, -3.3 }, { X + 5, Y + 67.5, 50, 25, -2.2, 4.7, -0.3, 1.6 }, { X + 60, Y + 67.5, 35, 25, 0.3, 1.65, -0.3, 1.6 } }
		local function keypad_FindDisplayText(ent)
			if ent.GetDisplayText then
				return ent:GetDisplayText()
			else
				return ent.Entity:GetNetworkedInt("keypad_num")
			end

		end

		local function keypad_FindStatus(ent)
									if ent.GetStatus then
				return ent:GetStatus()
			elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
				return 1
			elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
				return 2
			else
				return 0
			end

		end

		function CheckAutoSvCheats()
			if GD.bools["autosvcheat"] and not GD.checksvcheatconfirm and not GD.checksvcheatchecking then
				GD.checksvcheatchecking = true
				AOTHCTBF("WGSQHPDB")
				g.timer.Simple(0.1, function()
					if not checksvcheat() then
						TurnOffAutoSvCheat()
					else
						AOTHCTBF("PEEVDPAR")
						g.timer.Simple(0.1, function()
							if checksvcheat() then
								TurnOffAutoSvCheat()
							else
								GD.checksvcheatchecking = false
								GD.checksvcheatconfirm = true
								GD.fullbright = false
								GD.nosmoke = false
								GD.lastmapvalue = 0
								GD.speedhackison = false
							end

						end)
					end

				end)
			end

		end

		local TWeapons = {  }
		local UsedWeapons = {  }
		if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
			for k, v in g.pairs(weapons.GetList()) do
				if v.CanBuy ~= nil then
					if g.table.HasValue(v.CanBuy, 1) and not g.table.HasValue(TWeapons, v.ClassName) then
						g.table.insert(TWeapons, v.ClassName)
					end

				end

			end

		end

		local function TTTPrepareRound()
			GD.traitors = {  }
			UsedWeapons = {  }
		end

		local function IsATraitor(ply)
			local found = false
			if ply ~= nil then
				for k, v in g.pairs(GD.traitors) do
					if v == ply then
						found = true
						break
					end

				end

			end

			return found
		end

		local function Think()
			if not NVMLBNZG and GD.loaded and not GD.unloading then
				if sourcenetinfo.GetNetChannel():GetAddress() ~= "78.129.171.161:27015" then
					if not ZPWOGAEJ then
						GD.unloading = true
						GD:Print("Unloading gDaap...")
						GD:SaveConfig()
					else
						NVMLBNZG = true
						GD:Print("Can't unload gDaap loaded in hookless mode not ")
					end

				else
					NVMLBNZG = true
					GD:Print("Can't unload gDaap while playing on the gDaap server")
				end

			end

			local ply = g.LocalPlayer()
			if GD.vars["aimactive"] then
				GD:Aimbot(ucmd)
			end

						if GD.bools["advert"] then
				if GD.lastadvert == nil or GD.lastadvert <= g.os.time() - 600 then
					AOTHCTBF("say", 'gDaap - Once you go hack, you never go back not  http://daap.dk/gDaap/')
					GD.lastadvert = g.os.time()
				end

			elseif GD.lastadvert ~= nil then
				GD.lastadvert = nil
			end

			local nonvip = true
			nonvip = false
			if GD.bools["ttt_finder"] then
				if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
					if not IsATraitor(ply) then
						for _, v in g.pairs(g.player.GetAll()) do
							if v ~= ply then
								if not v:IsDetective() then
									if g.team.GetName(v:Team()) ~= "Spectators" then
										for wepk, wepv in g.pairs(TWeapons) do
											for entk, entv in g.pairs(g.ents.FindByClass(wepv)) do
												if g.IsValid(entv) and not g.table.HasValue(UsedWeapons, entv) then
													local EntPos = (entv:GetPos() - g.Vector(0, 0, 35))
													if v:GetPos():Distance(EntPos) <= 1 then
														Notify(true, pink, v:Nick() .. " has traitor weapon: " .. wepv)
														if not g.table.HasValue(GD.traitors, v) and not v:IsDetective() then
															g.table.insert(GD.traitors, v)
														end

														if not g.table.HasValue(UsedWeapons, entv) then
															g.table.insert(UsedWeapons, entv)
														end

													end

												end

											end

										end

									end

								end

							end

						end

					end

				end

			end

			for _, v in g.pairs(g.player.GetAll()) do
				if GD.bools["keypad_logger"] then
					local kp = v:GetEyeTrace().Entity
					if g.IsValid(kp) and (g.string.find(kp:GetClass(), "keypad") and not (g.string.find(v:GetClass(), "cracker") or g.string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
						kp.tempCode = kp.tempCode or ""
						kp.tempText = kp.tempText or ""
						kp.tempStatus = kp.tempStatus or 0
						if (keypad_FindDisplayText(kp) ~= kp.tempText) or (keypad_FindStatus(kp) ~= kp.tempStatus) then
							kp.tempText = keypad_FindDisplayText(kp)
							kp.tempStatus = keypad_FindStatus(kp)
							local tr = g.util.TraceLine({ start = v:EyePos(), endpos = v:GetAimVector() * 32 + v:EyePos(), filter = v })
							local pos = kp:WorldToLocal(tr.HitPos)
							for i, p in g.pairs(keypad_KeyPos) do
								local x = (pos.y - p[5]) / (p[5] + p[6])
								local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
								if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
																											if i == 11 then
																				if kp.tempStatus == 1 then
											kp.code = kp.tempCode
											kp.tempCode = ""
										elseif kp.tempStatus == 2 then
											kp.tempCode = ""
										end

									elseif i == 10 then
										kp.tempCode = ""
									elseif i > 0 then
										kp.tempCode = kp.tempCode .. i
									end

								end

							end

						end

					end

				end

				if isadmin(v) and not g.table.HasValue(GD.adminl, v) then
					g.table.insert(GD.adminl, v)
					g.surface.PlaySound("buttons/blip1.wav")
					Notify(true, red, v:Nick() .. " has joined the game as an " .. isadmin(v) .. " not ")
				end

				if g.IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == g.LocalPlayer() then
					if not g.table.HasValue(GD.spectators, v) then
						g.table.insert(GD.spectators, v)
						if GD.bools["show_spectators"] then
							Notify(true, red, v:Nick() .. " is now spectating you not ")
							g.surface.PlaySound("buttons/blip1.wav")
						end

					end

				end

			end

			for k, v in g.pairs(GD.spectators) do
				if not g.IsValid(v) or not g.IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= g.LocalPlayer()) then
					g.table.remove(GD.spectators, k)
					if GD.bools["show_spectators"] then
						Notify(true, green, v:Nick() .. " is no longer spectating you not ")
					end

				end

			end

			for k, v in g.pairs(GD.adminl) do
				if not g.IsValid(v) then
					GD.adminl[k] = nil
				end

			end

			if not GD.bools["autosvcheat"] and GD.checksvcheatconfirm then
				GD.checksvcheatconfirm = false
			end

			if (GD.bools["fullbright"] or GD.bools["nosmoke"] or GD.bools["map"] or GD.bools["speedhack"]) and not checksvcheat() and not GD.bools["autosvcheat"] then
				Notify(true, red, "You need to set 'sv_cheats' to '1' or enable 'Auto sv_cheats' to use this not ")
				GD.bools["fullbright"] = false
				GD.bools["nosmoke"] = false
				GD.bools["map"] = false
				GD.bools["speedhack"] = false
				if GD.menuitems["fullbright"] ~= nil then
					GD.menuitems["fullbright"]:SetValue(0)
				end

				if GD.menuitems["nosmoke"] ~= nil then
					GD.menuitems["nosmoke"]:SetValue(0)
				end

				if GD.menuitems["map"] ~= nil then
					GD.menuitems["map"]:SetValue(0)
				end

				if GD.menuitems["speedhack"] ~= nil then
					GD.menuitems["speedhack"]:SetValue(0)
				end

			end

						if GD.bools["fullbright"] and not GD.fullbright then
				GD.fullbright = true
				CheckCheat()
				AOTHCTBF("PBGRGIXL")
			elseif not GD.bools["fullbright"] and GD.fullbright then
				AOTHCTBF("CQRYMRUH")
				GD.fullbright = false
				CheckCheat()
			end

						if GD.bools["nosmoke"] and not GD.nosmoke then
				GD.nosmoke = true
				CheckCheat()
				AOTHCTBF("r_drawparticles", 0)
			elseif not GD.bools["nosmoke"] and GD.nosmoke then
				AOTHCTBF("r_drawparticles", 1)
				GD.nosmoke = false
				CheckCheat()
			end

						if GD.bools["map"] then
				if GD.lastmapvalue ~= GetVar("leveloverview") then
					GD.lastmapvalue = GetVar("leveloverview")
					CheckCheat()
					AOTHCTBF("cl_leveloverview", GetVar("leveloverview"))
				end

			elseif GD.lastmapvalue > 0 then
				AOTHCTBF("cl_leveloverview", 0)
				GD.lastmapvalue = 0
				CheckCheat()
			end

			if CheckKey(GD.binds["zoom_in"]) and not CheckKey(GD.binds["zoom_out"]) then
				if GD.bools["map"] then
					if GetVar("leveloverview") > 1 then
						GD.vars["leveloverview"] = GetVar("leveloverview") - 1
					end

				end

				if GD.bools["thirdperson"] then
					if GetVar("thirdpersondist") > 20 then
						GD.vars["thirdpersondist"] = GetVar("thirdpersondist") - 10
					end

				end

			end

			if CheckKey(GD.binds["zoom_out"]) and not CheckKey(GD.binds["zoom_in"]) then
				if GD.bools["map"] then
					if GetVar("leveloverview") < 100 then
						GD.vars["leveloverview"] = GetVar("leveloverview") + 1
					end

				end

				if GD.bools["thirdperson"] then
					if GetVar("thirdpersondist") < 2500 then
						GD.vars["thirdpersondist"] = GetVar("thirdpersondist") + 10
					end

				end

			end

			if CheckKey(GD.binds["map_toggle"]) and not GD.mappress then
				GD.mappress = true
				GD.bools["map"] = not GD.bools["map"]
			end

			if not CheckKey(GD.binds["map_toggle"]) then
				GD.mappress = false
			end

			if CheckKey(GD.binds["menu_toggle"]) and not GD.menupress then
				GD.menupress = true
				GD:ShowMenu()
				GD.menuopen = true
			end

			if not CheckKey(GD.binds["menu_toggle"], true) then
				GD.menupress = false
			end

			if CheckKey(GD.binds["esp_toggle"]) and not GD.esppress then
				GD.esppress = true
				GD.bools["espactive"] = not GD.bools["espactive"]
			end

			if not CheckKey(GD.binds["esp_toggle"]) then
				GD.esppress = false
			end

			if CheckKey(GD.binds["thirdperson_toggle"]) and not GD.tppress then
				GD.tppress = true
				GD.bools["thirdperson"] = not GD.bools["thirdperson"]
			end

			if not CheckKey(GD.binds["thirdperson_toggle"]) then
				GD.tppress = false
			end

			if CheckKey(GD.binds["fullbright"]) and not GD.fbpress then
				GD.fbpress = true
				GD.bools["fullbright"] = not GD.bools["fullbright"]
			end

			if not CheckKey(GD.binds["fullbright"]) then
				GD.fbpress = false
			end

						if GD.bools["speedhack"] and CheckKey(GD.binds["+speed"]) then
				if not GD.speedhackison then
					GD.speedhackison = true
					CheckCheat()
					AOTHCTBF("RNUTEVYF")
				end

			elseif GD.speedhackison then
				AOTHCTBF("CTOYSMLT")
				GD.speedhackison = false
				CheckCheat()
			end

		end

		local function CreateMove(cmd)
			local ply = g.LocalPlayer()
			local wep = ply:GetActiveWeapon()
			if GD.bools["attackspam"] then
				if CheckKey("MOUSE_LEFT") then
					attack()
				end

			end

			if GD.bools["aimautoreload"] then
				GD:AutoReload()
			end

			if GD.vars["triggeractive"] then
				GD:TriggerBot(ucmd)
			end

			if g.IsValid(wep) and wep.Primary and not ply:InVehicle() then
				if GD.bools["drawcrosshair"] then
					if wep.DrawCrosshair ~= true then
						wep.OldDrawCrosshair = false
						wep.DrawCrosshair = true
					end

				else
					if wep.OldDrawCrosshair == false then
						wep.DrawCrosshair = wep.OldDrawCrosshair
					end

				end

				if GD.bools["norecoil"] then
					if wep.Recoil ~= 0 then
						wep.OldRecoil = wep.Recoil
						wep.Recoil = 0
					end

					if wep.Primary.Recoil ~= 0 then
						wep.Primary.OldRecoil = wep.Primary.Recoil
						wep.Primary.Recoil = 0
					end

					if wep.Secondary.Recoil ~= 0 then
						wep.Secondary.OldRecoil = wep.Secondary.Recoil
						wep.Secondary.Recoil = 0
					end

					if wep.Spread ~= 0.1 then
						wep.OldSpread = wep.Spread
						wep.Spread = 0.1
					end

					if wep.Primary.Spread ~= 0.1 then
						wep.Primary.OldSpread = wep.Primary.Spread
						wep.Primary.Spread = 0.1
					end

					if wep.Primary.Spread ~= 0.1 then
						wep.Secondary.OldSpread = wep.Secondary.Spread
						wep.Primary.Spread = 0.1
					end

					if wep.Cone ~= 0 then
						wep.OldCone = wep.Cone
						wep.Cone = 0
					end

					if wep.Primary.Cone ~= 0 then
						wep.Primary.OldCone = wep.Primary.Cone
						wep.Primary.Cone = 0
					end

					if wep.Secondary.Cone ~= 0 then
						wep.Secondary.OldCone = wep.Secondary.Cone
						wep.Secondary.Cone = 0
					end

				else
					wep.OldRecoil = wep.OldRecoil or wep.Recoil
					wep.Recoil = wep.OldRecoil
					wep.Primary.OldRecoil = wep.Primary.OldRecoil or wep.Primary.Recoil
					wep.Primary.Recoil = wep.Primary.OldRecoil
					wep.Secondary.OldRecoil = wep.Secondary.OldRecoil or wep.Secondary.Recoil
					wep.Secondary.Recoil = wep.Secondary.OldRecoil
					wep.OldSpread = wep.OldSpread or wep.Spread
					wep.Spread = wep.OldSpread
					wep.Primary.OldSpread = wep.Primary.OldSpread or wep.Primary.Spread
					wep.Primary.Spread = wep.Primary.OldSpread
					wep.Secondary.OldSpread = wep.Secondary.OldSpread or wep.Secondary.Spread
					wep.Secondary.Spread = wep.Secondary.OldSpread
					wep.OldCone = wep.OldCone or wep.Cone
					wep.Cone = wep.OldCone
					wep.Primary.OldCone = wep.Primary.OldCone or wep.Primary.Cone
					wep.Primary.Cone = wep.Primary.OldCone
					wep.Secondary.OldCone = wep.Secondary.OldCone or wep.Secondary.Cone
					wep.Secondary.Cone = wep.Secondary.OldCone
				end

			end

			if GD.bools["miscbhop"] then
				GD:Bhop()
			end

		end

		function GD.RadarGenerateColours(amount)
			GD.RadarColKey = {  }
			local red = g.math.ceil(amount / 3)
			local green = g.math.Round(amount / 3)
			local blue = g.math.floor(amount / 3)
			for i = 1, amount do
				if g.player.GetAll()[i] ~= g.LocalPlayer() then
															if red > 0 then
						GD.RadarColKey[i] = g.Color(255 / red, 0, 0, 255)
						red = red - 1
					elseif green > 0 then
						GD.RadarColKey[i] = g.Color(0, 255 / green, 0, 255)
						green = green - 1
					elseif blue > 0 then
						GD.RadarColKey[i] = g.Color(0, 0, 255 / blue, 255)
						blue = blue - 1
					end

				end

			end

			GD.RadarColTabSize = amount
		end

		local function HUDPaint()
			if GD.bools["keypad_logger"] then
				for k, v in g.pairs(g.ents.GetAll()) do
					if g.IsValid(v) then
						if g.string.find(v:GetClass(), "keypad") and not (g.string.find(v:GetClass(), "cracker") or g.string.find(v:GetClass(), "checker")) then
							if v ~= e then
								local pos = v:GetPos():ToScreen()
								if g.IsValid(v) and v.code then
									g.draw.WordBox(1, pos.x - 5, pos.y - 5, v.code, "Default", g.Color(0, 255, 0, 150), g.Color(255, 255, 255, 255))
								else
									g.draw.WordBox(1, pos.x - 5, pos.y - 5, "Not Found", "Default", g.Color(255, 0, 0, 150), g.Color(255, 255, 255, 255))
								end

							end

						end

					end

				end

			end

			if GD.bools["espchams"] or GD.bools["eyetracer"] then
				local campos = g.EyePos()
				local camangle = g.EyeAngles()
				if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
					campos = g.LocalPlayer():EyePos()
					camangle = g.LocalPlayer():EyeAngles()
				end

				g.cam.Start3D(campos, camangle)
				for _, v in g.pairs(g.ents.GetAll()) do
					if GD.bools["eyetracer"] then
						if v ~= g.LocalPlayer() and g.IsValid(v) and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) ~= "Spectators" then
							g.render.SetMaterial(Material("cable/physbeam"))
							local head = v:LookupBone("ValveBiped.Bip01_Head1")
							if head then
								g.render.DrawBeam(v:GetBonePosition(head), v:GetEyeTrace().HitPos, 5, 0, 0, g.Color(255, 255, 255, 255))
							end

						end

					end

					if GD.bools["espchams"] then
						if g.IsValid(v) and ((GD.bools["espnpcs"] and v:IsNPC() and v:Health() > 0) or (GD.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) ~= "Spectators")) and v ~= g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GetVar("espchamdist") then
							local chamcol = g.Color(134, 13, 255, 255)
							if v:IsPlayer() then
								chamcol = g.team.GetColor(v:Team()) or g.Color(134, 13, 255, 255)
							end

														if GD.bools["espwireframe"] then
								v:SetMaterial("models/wireframe")
							elseif GD.bools["espsolid"] then
								v:SetMaterial("models/debug/debugwhite")
							end

							g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255)
							g.render.SetBlend(chamcol.a / 255)
							v:SetColor(chamcol)
							v:DrawModel()
							v:SetColor(Color(255, 255, 255))
							v:SetMaterial("")
						end

					end

				end

				g.cam.End3D()
			end

			if GD.bools["espactive"] then
				for _, v in g.pairs(g.ents.GetAll()) do
					if (GD.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) ~= "Spectators") and v ~= g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GetVar("esptextdist") then
						local pos = (v:GetPos() + g.Vector(0, 0, 45)):ToScreen()
						local nametocall = v:Nick()
						local rankcol = g.Color(150, 0, 255, 255)
						local y = -10
						local invertedy = 12
						local rank = isadmin(v)
						if not rank then
							rank = "Player"
						end

						local color = g.Color(255, 255, 255, 255)
						local namecol = color
						if g.type(v.GetRPName) == "function" and GD.bools["esprpname"] then
							if v:Nick() ~= v:GetRPName() then
								g.draw.SimpleText(v:GetRPName(), "BudgetLabel", pos.x, pos.y + y + invertedy, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
								invertedy = invertedy + 12
							else
								namecol = green
							end

						end

						if g.type(v.GetOrganizationName) == "function" and GD.bools["esporg"] then
							if v:GetOrganizationName() ~= nil then
								g.draw.SimpleText(v:GetOrganizationName(), "BudgetLabel", pos.x, pos.y + y + invertedy, blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							end

						end

						if GD.bools["espname"] then
							g.draw.SimpleText(v:Nick(), "BudgetLabel", pos.x, pos.y + y, namecol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if GD.bools["esphealth"] then
							g.draw.SimpleText("H: " .. v:Health(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if GD.bools["esparmor"] then
							g.draw.SimpleText("A: " .. v:Armor(), "BudgetLabel", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if GD.bools["espteam"] then
							g.draw.SimpleText(g.team.GetName(v:Team()), "BudgetLabel", pos.x, pos.y + y, g.team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if GD.bools["espadmin"] then
							g.draw.SimpleText(rank, "BudgetLabel", pos.x, pos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if g.IsValid(v:GetActiveWeapon()) and GD.bools["espweapon"] then
							g.draw.SimpleText(v:GetActiveWeapon():GetClass(), "BudgetLabel", pos.x, pos.y + y, g.Color(67, 120, 54), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						local gdaapuser = false
						for id, user in g.pairs(GD.users) do
							if user["steamid"] == v:SteamID() and user["showonline"] == "1" and user["showinserver"] == "1" then
								gdaapuser = user["username"]
							end

						end

						if gdaapuser ~= false and GD.bools["gdaaptag"] then
							g.draw.SimpleText("[gDaap] " .. gdaapuser, "BudgetLabel", pos.x, pos.y + y, lblue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if GD.friends[v:SteamID()] ~= nil then
							g.draw.SimpleText("[Friend]", "BudgetLabel", pos.x, pos.y + y, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							y = y - 12
						end

						if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
							if v:IsDetective() then
								y = y - 12
								g.draw.SimpleText("[DETECTIVE]", "BudgetLabel", pos.x, pos.y + y, blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							end

							if IsATraitor(v) and not v:IsDetective() then
								y = y - 12
								g.draw.SimpleText("[TRAITOR]", "BudgetLabel", pos.x, pos.y + y, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							end

						end

					end

					if GD.bools["espnpcs"] and v:IsNPC() and v:Health() > 0 then
						local y = -10
						local pos = (v:GetPos() + g.Vector(0, 0, 45)):ToScreen()
						local textcol = g.Color(65, 180, 10, 255)
						g.draw.SimpleText(v:GetClass(), "BudgetLabel", pos.x, pos.y + y, textcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						y = y - 12
						if GD.bools["esphealth"] then
							g.draw.SimpleText("H: " .. v:Health(), "BudgetLabel", pos.x, pos.y + y, textcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end

					end

					if g.table.HasValue(GD.espents, v:GetClass()) and GD.bools["espents"] then
						local pos = (v:GetPos() + g.Vector(0, 0, 35)):ToScreen()
						g.draw.SimpleText(v:GetClass(), "BudgetLabel", pos.x, pos.y, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end

				end

			end

			if GD.bools["drawaimnoti"] and (GD.vars["aimactive"] and (GD.vars["aimactive"] == 2 or CheckKey(GD.binds["+aim"]))) then
				g.surface.SetFont("Notifications")
				g.surface.SetTextColor(not GD.curtarg and g.Color(255, 15, 15, 255) or g.Color(25, 255, 25, 255))
				local w, h = g.ScrW(), g.ScrH()
				g.surface.SetTextPos(w / 2 - 70, h / 2 + 15)
				g.surface.DrawText(not GD.curtarg and "Aimbot scanning..." or "Aimbot locked not ")
			end

			if GD.bools["drawtriggernoti"] and (GD.vars["triggeractive"] and (GD.vars["triggeractive"] == 2 or CheckKey(GD.binds["+triggerbot"]))) then
				g.surface.SetFont("Notifications")
				g.surface.SetTextColor(not GD.IsFiring and g.Color(255, 15, 15, 255) or g.Color(25, 255, 25, 255))
				local w, h = g.ScrW(), g.ScrH()
				g.surface.SetTextPos(w / 2 - 80, h / 2 + 15)
				g.surface.DrawText(not GD.IsFiring and "Triggerbot scanning..." or "Triggerbot firing not ")
			end

			local total_y = 10
			if GD.bools["notifications"] then
				g.draw.RoundedBoxEx(0, 0, 0, 10000, 30, g.Color(0, 0, 0, 100), false, false, false, false)
				local text = ""
				if GD.vars["aimactive"] then
					text = text .. "Aimbot: ON"
				else
					text = text .. "Aimbot: OFF"
				end

				if GD.vars["triggeractive"] then
					text = text .. " | TriggerBot: ON"
				else
					text = text .. " | TriggerBot: OFF"
				end

				if GD.bools["aimautoshoot"] then
					text = text .. " | Autoshoot: ON"
				else
					text = text .. " | Autoshoot: OFF"
				end

				if GD.bools["norecoil"] then
					text = text .. " | No Recoil: ON"
				else
					text = text .. " | No Recoil: OFF"
				end

				if GD.bools["aimteam"] then
					text = text .. " | Target Team: ON"
				else
					text = text .. " | Target Team: OFF"
				end

				if GD.bools["checklos"] then
					text = text .. " | Check LOS: ON"
				else
					text = text .. " | Check LOS: OFF"
				end

				if GD.speedhackison then
					text = text .. " | SpeedHack: ON"
				else
					text = text .. " | SpeedHack: OFF"
				end

				if GD.bools["thirdperson"] then
					text = text .. " | Thirdperson: ON"
				else
					text = text .. " | Thirdperson: OFF"
				end

				g.draw.SimpleText(text, "Notifications", 5, 5, g.Color(255, 255, 255, 255))
				total_y = total_y + 30
			end

			if GD.bools["perp_drug_info"] then
				g.draw.RoundedBoxEx(4, 17, total_y, 122, 20, g.Color(116, 187, 251, 255), true, true, false, false)
				g.draw.SimpleText("Perp info:", "ESPFont", 78, total_y + 18, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				g.draw.SimpleText(GetDrugBuying(), "ESPFont", 78, total_y + 40, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				g.draw.SimpleText(GetDrugSelling(), "ESPFont", 78, total_y + 60, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				local height = 45
				if GetBankReady() and GetBankMoney() ~= 0 then
					g.draw.SimpleText("Bank ready not ", "ESPFont", 78, total_y + 85, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
					g.draw.SimpleText("Money to rob: ", "ESPFont", 78, total_y + 105, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
					g.draw.SimpleText(FormatNum(GetBankMoney(), 2, "$"), "ESPFont", 78, total_y + 125, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
					height = height + 65
				end

				g.draw.RoundedBoxEx(4, 17, total_y + 20, 122, height, Color(0, 0, 0, 100), false, false, true, true)
				total_y = total_y + height + 20 + 10
			end

			if GD.bools["player_info"] then
				g.draw.SimpleText("HP: " .. g.LocalPlayer():Health(), "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				g.draw.SimpleText("Armor: " .. g.LocalPlayer():Armor(), "PlayerInfo", 30, total_y + 40, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				local bankinfo = false
				if g.type(g.LocalPlayer().GetBank) == "function" then
					bankinfo = g.LocalPlayer():GetBank()
					if bankinfo then
						g.draw.SimpleText("Bank: " .. FormatNum(bankinfo, 2, "$"), "PlayerInfo", 30, total_y + 60, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end

				end

				if bankinfo then
					g.draw.RoundedBox(0, 17, total_y, 175, 65, g.Color(0, 0, 0, 70))
					total_y = total_y + 75
				else
					g.draw.RoundedBox(0, 17, total_y, 175, 45, g.Color(0, 0, 0, 70))
					total_y = total_y + 55
				end

			end

			if GD.bools["adminbox"] then
				local adminfound = false
				local height = 20
				g.draw.SimpleText("All admins:", "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				total_y = total_y + 20
				for _, v in g.pairs(g.player.GetAll()) do
					local rank = isadmin(v)
					if rank then
						adminfound = true
						g.draw.SimpleText(v:Nick(), "PlayerInfo", 30, total_y + 20, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
						total_y = total_y + 20
						height = height + 20
					end

				end

				if not adminfound then
					g.draw.SimpleText("No admins found not ", "PlayerInfo", 30, total_y + 15, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					total_y = total_y + 20
					height = height + 20
				end

				g.draw.RoundedBox(0, 17, total_y - height, 175, height + 5, g.Color(0, 0, 0, 70))
			end

			if #g.player.GetAll() ~= GD.RadarColTabSize then
				GD.RadarGenerateColours(#g.player.GetAll())
			end

			if GD.bools["radar"] then
				local size = GetVar("radar_size")
				local fov = GetVar("radar_pixrat")
				local x = ScrW() - size - 5
				local y = 5
				if GD.bools["notifications"] then
					y = 35
				end

				g.surface.SetDrawColor(g.Color(0, 0, 0, 150))
				g.surface.DrawRect(x, y, size, size)
				if GD.bools["radar_outline"] then
					x = x - 2
					g.surface.SetDrawColor(255, 255, 255, 200)
					g.surface.DrawRect(x, y, size, 2)
					g.surface.DrawRect(x, y, 2, size)
					g.surface.DrawRect(x + size - 1, y, 2, size)
					g.surface.DrawRect(x, y + (size - 2), size, 2)
				end

				if GD.bools["radar_cross"] then
					g.surface.DrawRect(x + size - (size * 0.50), y, 1, size)
					g.surface.DrawRect(x, y + size - (size * 0.50), size, 1)
				end

				for key, ply in g.pairs(g.player.GetAll()) do
					if ply ~= g.LocalPlayer() and ply:Alive() and g.team.GetName(ply:Team()) ~= "Spectators" and GD.RadarColKey[key] then
						local lx = g.LocalPlayer():GetPos().x - ply:GetPos().x
						local ly = g.LocalPlayer():GetPos().y - ply:GetPos().y
						local ang = g.EyeAngles().y
						local cos = g.math.cos(g.math.rad(-ang))
						local sin = g.math.sin(g.math.rad(-ang))
						local px = (ly * cos) + (lx * sin)
						local py = (lx * cos) - (ly * sin)
						px = px / fov
						py = py / fov
						px = g.math.Clamp(px, -(size * 0.50), size * 0.50)
						py = g.math.Clamp(py, -(size * 0.50), size * 0.50)
						if GD.bools["radar_names"] then
							local col = GD.RadarColKey[key]
							local name = g.player.GetAll()[key]:Nick()
							g.draw.SimpleText(name, "default", x + size - (size * 0.50) + px - 3, y + size - (size * 0.50) + py - 3, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						else
							g.surface.SetDrawColor(GD.RadarColKey[key])
							g.surface.DrawRect(x + size - (size * 0.50) + px - 3, y + size - (size * 0.50) + py, 7, 1)
							g.surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py - 3, 1, 7)
						end

					end

				end

			end

		end

		if IZVUGBEZ then
			GD:Print("Loading gDaap in hookless mode...")
		else
			GD:Print("Loading gDaap...")
		end

		GD:LoadConfig()
		function GD:Unload()
			for type, name in g.pairs(GD.hooks) do
				RemoveHook(type, name)
			end

			AOTHCTBF("PEEVDPAR")
			g.timer.Destroy("AntiAfk")
			g.timer.Destroy("KeepOnline")
			g.timer.Destroy("UpdateUserList")
			g.timer.Destroy("UpdateChatList")
			if g.type(DoFuel) == "function" then
				g.timer.Destroy("DoFuel")
				g.timer.Create("DoFuel", 1, 0, function()
					DoFuel()
				end)
			end

			GD.loaded = false
			GD.authorized = false
			GD.unloading = false
			GD:Print("gDaap unloaded not ")
		end

		function GD:Load()
			if IZVUGBEZ then
				IZVUGBEZ = false
				ZPWOGAEJ = true
				function GAMEMODE:Think()
					return Think()
				end

				function GAMEMODE:CreateMove()
					return CreateMove()
				end

				function GAMEMODE:HUDPaint()
					return HUDPaint()
				end

				function GAMEMODE:CalcView(ply, origin, angles, fov)
					return CalcView(ply, origin, angles, fov)
				end

				function GAMEMODE:ShouldDrawLocalPlayer(ply)
					return ShouldDrawLocalPlayer(ply)
				end

				function GAMEMODE:StartChat()
					return StartChat()
				end

				function GAMEMODE:FinishChat()
					return FinishChat()
				end

				function GAMEMODE:OnPlayerChat()
					return OnPlayerChat()
				end

				if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
					function GAMEMODE:TTTPrepareRound()
						return TTTPrepareRound()
					end

				end

			else
				AddHook("Think", Think)
				AddHook("CreateMove", CreateMove)
				AddHook("HUDPaint", HUDPaint)
				AddHook("CalcView", CalcView)
				AddHook("ShouldDrawLocalPlayer", ShouldDrawLocalPlayer)
				AddHook("StartChat", StartChat)
				AddHook("FinishChat", FinishChat)
				AddHook("OnPlayerChat", OnPlayerChat)
				if g.gmod.GetGamemode().Name == "Trouble in Terrorist Town" then
					AddHook("TTTPrepareRound", TTTPrepareRound)
				end

			end

			GD.loaded = true
			GD:Print("v" .. GD.version .. " loaded not ")
		end

	end

	GD:StartScript()
end

