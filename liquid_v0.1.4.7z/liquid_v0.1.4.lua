local hook = hook -- Makes the hack load faster appartly.
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team
if ( SERVER ) then return end -- Nono server.
-- Config
local ply = LocalPlayer() -- Being fast
local LVersion = 014 -- Used for the updater. It compares the player's LVersi0n to the VERSI0N on the googlecode site.
local Liquid = { } -- Tables
local players = { } -- Tables
local midx = ScrW()*0.5 -- Used for some ESP shit
local midy = ScrH()*0.5
--VERSION=014 
-- Dont edit the VERSI0N. It's used for the updater.

-- Commands

local aimbot = CreateClientConVar( "Liquid_Aimbot", "0", true, false )
CreateClientConVar( "Liquid_ESP", 0, true, false)
CreateClientConVar( "Liquid_ESP_Draw_HP", 0, true, false)
CreateClientConVar( "Liquid_Flashlight", 0, true, false)
CreateClientConVar( "Liquid_BHop", 0, true, false )
local godmode = CreateClientConVar( "Liquid_Godmode", 0, true, false )
local friendaim = CreateClientConVar( "Liquid_Aim_At_Friends", 0, true, false)
local OOC = CreateClientConVar("Liquid_ooc", 1, true, false)
local Enabled  = CreateClientConVar( "Liquid_chatspam", "0", true, false)
local Chat = CreateClientConVar( "Liquid_chatspam_message", "", true, false)
local Time = CreateClientConVar( "Liquid_chatspam_delay" , "0", true, false)
local Trigger = CreateClientConVar( "Liquid_Triggerbot", 0, true, false )
local TriggerF = CreateClientConVar( "Liquid_Triggerbot_Friends", 0, true, false )
local flashlight = CreateClientConVar("Liquid_Flashlight", "1", true, false )
local chams = CreateClientConVar( "Liquid_ESP_Wallhack", 0, true, false)
local chams1 = CreateClientConVar( "Liquid_ESP_Wallhack_Chams", 0, true, false)
local chams2 = CreateClientConVar( "Liquid_ESP_Wallhack_Wireframe", 0, true, false)
local menu = CreateClientConVar( "Liquid_menu", 0, true, false)
local boxesp = CreateClientConVar( "Liquid_ESP_Box", 0, true, false)
local aimonkey = CreateClientConVar( "Liquid_Aim_On_Mouse1", 0, true, false )
local aimonkey2 = CreateClientConVar( "Liquid_Aim_On_Mouse2", 0, true, false )
local crosshair = CreateClientConVar( "Liquid_ESP_Crosshair", 0, true, false )
local teamaim = CreateClientConVar( "Liquid_Aim_At_Teammates", 0, true, false )
local recoil = CreateClientConVar( "Liquid_Norecoil", 0, true, false )
local cross = CreateClientConVar( "secret", 0, true, false )
local box = CreateClientConVar( "Liquid_ESP_Box2D", 0, true, false )
local box3 = CreateClientConVar( "Liquid_ESP_Box3D", 0, true, false )
local aimangle = CreateClientConVar( "Liquid_Aimbot_MaxAngle", 0, true, false )
-- Mats

local mat1 = (CreateMaterial( "wireframe", "Wireframe", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1, ["$nocull"] = 1 } ))
local mat2 = (CreateMaterial( "chams", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1, ["$nocull"] = 1 } ) )
local box1 = Color( 255, 255, 255, 50 )
local box2 = Color( box1.r, box1.g, box1.b, 255 )

function LiquidPrint(msg)
	print("[Liquid] " ..msg)
end

function LiquidChat(msg)
	chat.AddText(Color(0,166,255), "[Liquid] " .. msg)
end

LiquidChat("Loaded.")
LiquidChat("Have fun! Open the console and type: Liquid_")

local IsTTT = string.find( GAMEMODE.Name , "Terror" )
if IsTTT then
	LiquidChat("You're playing TTT" )
end
surface.CreateFont( "LFont", { font = "Arial", size = 14, weight = 500, antialias = false, outline = false } )

-- Liquid
LiquidPrint("  _      _             _     _ " )
LiquidPrint(" | |    (_)           (_)   | |" )
LiquidPrint(" | |     _  __ _ _   _ _  __| |" )
LiquidPrint(" | |    | |/ _` | | | | |/ _` |" )
LiquidPrint(" | |____| | (_| | |_| | | (_| |" )
LiquidPrint(" |______|_|\\__, |\\__,_|_|\\__,_|" )
LiquidPrint("              | | ")
LiquidPrint("              |_| ")
LiquidPrint("                     Hack succesfully loaded")
LiquidPrint("  Credits : ")
LiquidPrint("")
LiquidPrint("	    MeepDarknessMeep ")
LiquidPrint("	    Fatal ")
LiquidPrint("	    Solemn ")
LiquidPrint("	    Liquid ")
LiquidPrint("	    Cave")
LiquidPrint("	    Frenchy")
LiquidPrint("	    Shadow")
LiquidPrint("	    Henry")
LiquidPrint("	    Ryan")
LiquidPrint("	    Sudoxe")
LiquidPrint("")
LiquidPrint("Update :")
LiquidPrint("	 0.12")
LiquidPrint("")
LiquidPrint("Changelog:")
LiquidPrint("	+ Made 2D and 3D boxes. Liquid_ESP_Box2D/3D")
LiquidPrint("	+ Friends now have green health bar. Normal players red.")
LiquidPrint("	+ Revamped aimbot. Liquid_Aim.. " )
--LiquidPrint("	Still focusing on C++ m8")
LiquidPrint("")

function Liquid.Init()
	LiquidPrint("Checking for updates..." )
	http.Fetch( "https://liquidlua.googlecode.com/svn/trunk/Liquid.lua", 
		function( HTML ) 
			local findpos = string.find( HTML, "VERSION=", 0, false )
			
			if (findpos) then
				local version = tonumber( string.sub( HTML, findpos+8, findpos+11 ) )
				if ( version > LVersion ) then
					LiquidPrint("Your version is out of date!" )
					LiquidPrint("Ask Liquid for the update!" )
					LiquidChat("Your version is out of date!" )
					LiquidChat("Ask Liquid for the update!" )
				else
					LiquidPrint("Your version is up to date." )
					LiquidChat("Your version is up to date." )
			end
		else
		LiquidPrint("Error")
		end
	end)
end

Liquid.Init()
-- ATM bruteforce

concommand.Add("getatm", function(ply, cmd, args)
        local targ = false
        print(args[1]);
        for i, ply in ipairs(player.GetAll()) do
                if (string.find(string.lower(ply:Name()), string.lower(args[1]))) then
                        targ = ply;
                        break;
                end
        end
        
        if (not targ or not targ:IsValid()) then print('targ is not valid'); return; end
        
        for i = 1000, 9999 do
                if (not targ or not targ:IsValid()) then return; end
                timer.Simple(i / 350, function()
                       RunConsoleCommand("rp_atm_login", util.CRC(i), targ:UniqueID());
                end)
        end
        
        print('found');
end)

-- 180

local function Rotate180()
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("Liquid_180", Rotate180)

-- 180up
local function Rotate180Up()
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
end
concommand.Add("Liquid_180up", Rotate180Up)

--Chat spammer

local function ChatSpam()
if Enabled:GetInt() != 0 then
	RunConsoleCommand( "say", Chat:GetString() )
end
end
timer.Create( "RapeChat", Time:GetInt(), 0, ChatSpam )

-- BHOP
local function Liquid_BHop(cmd)
	if tobool( GetConVarNumber( "Liquid_BHop" ) ) then
		if (!LocalPlayer():IsOnGround() && LocalPlayer():Alive() ) then
			cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		end
	end
end
-- Flashlight
local function Flashlight()
	if flashlight:GetBool() then
		RunConsoleCommand("impulse", "100" )
	end
end
timer.Create("Flashlight", 0.001, 0, Flashlight)

-- Menu
local function menu2()
	if menu:GetInt() != 0 then
		draw.RoundedBox( 4, 10, 10, 100, 55, Color( 0, 0, 0, 130 ) )
		draw.SimpleText( "Name: " ..  ply:Name(), "LFont", 20, 15, Color( 0, 161, 255, 255 ) )
		draw.SimpleText( "Speed: " ..  math.Round( LocalPlayer():GetVelocity():Length() ), "LFont", 20, 25, Color( 0, 161, 255, 255 ) )
		draw.SimpleText( "FPS: " ..  math.Round( 1 / FrameTime() ), "LFont", 20, 35, Color( 0, 161, 255, 255 ) )
		draw.SimpleText( "Ping: " ..  ply:Ping() .. " ms", "LFont", 20, 45, Color( 0, 161, 255, 255 ) )
		--draw.SimpleText( "SteamID: " .. ply:SteamID(), "LFont", 20, 55, Color( 33, 255, 0, 255 ) )
	end
end

-- ESP
local function ESP()
	if tobool( GetConVarNumber( "Liquid_ESP" ) ) then
		for k, v in pairs( player.GetAll() ) do
			if v != ply then
				local pos = (v:GetShootPos() + Vector( 0, 0, 12.5 ) ):ToScreen()
					draw.SimpleTextOutlined( v:Nick(), "LFont", pos.x, pos.y - 12.5, team.GetColor(v:Team()), 1, 1, 1, Color(0,0,0,255) )
				end
			end
		end
	end

local function ESPHP()
	if tobool( GetConVarNumber( "Liquid_ESP_Draw_HP" ) ) then
		for _, v in pairs( player.GetAll() ) do
			if v != ply then
				local hp = v:Health()
				local armor = v:Armor()			
				local pos = (v:GetShootPos() + Vector( 0, 0, 12.5 ) ):ToScreen()
				if v:GetFriendStatus() == "friend" then
					draw.SimpleTextOutlined( "Health: " .. hp , "LFont", pos.x, pos.y, Color(0,255,0,255),1 ,1 ,1, Color(0,0,0,255) )
				else
					draw.SimpleTextOutlined( "Health: " .. hp , "LFont", pos.x, pos.y, Color(255,0,0,255),1 ,1 ,1, Color(0,0,0,255) )
				end
				if armor != 0 then
					draw.SimpleTextOutlined( "Armor: " .. armor, "LFont", pos.x, pos.y+12.5, Color(0,0,255,255), 1, 1, 1, Color(0,0,0,255) )
					
				end
			end
		end
	end
end

--Hooks
hook.Add( "Think", "Liquid_Godmode", function()
	if godmode:GetInt() == 1 then
		if LocalPlayer():Alive() then
			if LocalPlayer():Health() < 75 then
				RunConsoleCommand( "say", "/buyhealth" )
			end
		end
	end
end)

hook.Add( "CreateMove", "Liquid_Triggerbot", function(cmd)
	if Trigger:GetInt() != 0 then
		if LocalPlayer():Alive() and ( LocalPlayer():GetEyeTrace().Entity:IsPlayer() or LocalPlayer():GetEyeTrace().Entity:IsNPC() ) then
			if IsValid( LocalPlayer():GetActiveWeapon() ) then
					if TriggerF:GetInt() == 0 and LocalPlayer():GetEyeTrace().Entity:GetFriendStatus() == "friend" then
						return
					end	
					if !Firing then
						cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_ATTACK ) )
						Firing = true
					else	
						Firing = false
					end
				end
			end
		end
	end)
hook.Add( "CreateMove", "Liquid_BHop", Liquid_BHop )
hook.Add( "HUDPaint", "Liquid_ESP", ESP )
hook.Add( "HUDPaint", "Liquid_ESP_Draw_HP", ESPHP )
hook.Add( "HUDPaint", "Liquid_menu", menu2 )

function GetPlayers()
	local players = { }
	
	for _, v in pairs( player.GetAll() ) do
		if (v != ply && IsValid( v ) &&
		(v:IsPlayer() || v:IsBot() ) &&
		v:Alive() &&
		v:Health() >= 1 &&
		( v:GetFriendStatus() != "friend" || friendaim:GetInt() != 0 ) &&
		( v:Team() != ply:Team() || teamaim:GetInt() != 0 )) then
			table.insert( players, v )
		end
	end
	return players
end

function IsVisible( v )
        if (!IsValid( v )) then return false end
       
        local vecPos, _ = v:GetBonePosition( v:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 )
        local trace = { start = LocalPlayer():EyePos(), endpos = vecPos, filter = ply, mask = MASK_SHOT }
        local traceRes = util.TraceLine( trace )
       
        TraceRes = traceRes
       
        if (traceRes.HitWorld || traceRes.Entity != v) then return false end
		--print("cis")
        return true
end

function ClosestAngle( players )
	local flAngleDifference = nil
	local newAngle = nil
	local viewAngles = ply:EyeAngles()
	
	for _, v in pairs( players ) do
		local vecPos, ang = v:GetBonePosition( v:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 )
		local oldpos = vecPos
		vecPos = vecPos - Prediction( ply ) + Prediction( v )
		local angAngle = ( vecPos - ply:EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) )
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (flDif < aimangle:GetInt())) then
			HeadPos = oldpos:ToScreen()
			Target = ply
			flAngleDifference = flDif
			newAngle = angAngle
		end
	end
	return newAngle
end

function Prediction( v ) return ply:GetAbsVelocity() * 0.012 end

hook.Add( "CreateMove", "LAimbot", function(cmd)
	if aimbot:GetInt() != 0 then
		if (aimonkey:GetInt() != 0 && cmd:KeyDown( IN_ATTACK )) || (aimonkey2:GetInt() != 0 && cmd:KeyDown( IN_ATTACK2 )) || (aimonkey:GetInt() == 0 && aimonkey2:GetInt() == 0) then
		local players = { }
		
		for _, v in pairs( GetPlayers() ) do
			if (IsVisible( v ) ) then
				table.insert(players, v )
			end
		end
		
		if (table.Count( players ) == 0) then 
			Target = nil
			return
		end
		
		local newAngle = ClosestAngle( players )
		
		if (newAngle != nil ) then
			cmd:SetViewAngles(newAngle)
		end
		end
	end
end)

-- WH

hook.Add( "HUDPaint", "Liquid_ESP_Wallhack", function()
	if chams:GetInt() != 0 then
		cam.Start3D(EyePos(), EyeAngles())
			for k, v in pairs( player.GetAll() ) do
				if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR	&& v != ply then
					if chams1:GetInt() == 0 && chams2:GetInt() == 0 then
						render.SetBlend(1)
						--render.MaterialOverride()
					
						v:DrawModel()
						if IsValid( v:GetActiveWeapon() ) then
							v:GetActiveWeapon():DrawModel()
					end
					end
				end	
			end
		cam.End3D()
	end
end)

-- Box ESP
local IGNOREZ = true

hook.Add( "HUDPaint", "Liquid_ESP_Box", function()
	if boxesp:GetInt() != 0 then
		cam.Start3D( EyePos(), EyeAngles() )
			for k, v in pairs( player.GetAll() ) do
				if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR && v != ply then
					for hitbox = 0, v:GetHitBoxCount(0) do
						local bone = v:GetHitBoxBone( hitbox, 0 )
                        local bpos, bang = v:GetBonePosition( bone )
                        local min, max = v:GetHitBoxBounds( hitbox, 0 )
						
                        if( min == nil || max == nil ) then
							continue
                        end
						
						if( !IGNOREZ ) then
                            render.SetColorMaterial()
                        else
                            render.SetColorMaterialIgnoreZ()
                        end
						render.SetBlend( 1 )
						render.DrawBox( bpos, bang, min, max, box1 )
						render.DrawWireframeBox( bpos, bang, min, max, box2 )
					end
				end
			end
		cam.End3D()
	end
end)


hook.Add("HUDPaint", "Liquid_BOX", function() -- Done
	if box:GetInt() != 0 then
			for _, v in pairs( player.GetAll() ) do
				if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR && v != ply then
					
				local a, b = v:LocalToWorld(ply:OBBMaxs()), v:LocalToWorld(ply:OBBMins())
				
				if (a && b) then
				
				local vector1 = Vector(a.x, a.y, a.z) 
				local vector2 = Vector(b.x, a.y, a.z) 
				local vector3 = Vector(b.x, b.y, a.z) 
				local vector4 = Vector(a.x, b.y, b.z) 
				local vector5 = Vector(a.x, a.y, b.z) 
				local vector6 = Vector(a.x, b.y, a.z) 
				local vector7 = Vector(b.x, b.y, b.z) 
				local vector8 = Vector(b.x, a.y, b.z) 
				
				vector1 = vector1:ToScreen()
				vector2 = vector2:ToScreen()
				vector3 = vector3:ToScreen()
				vector4 = vector4:ToScreen()
				vector5 = vector5:ToScreen()
				vector6 = vector6:ToScreen()
				vector7 = vector7:ToScreen()
				vector8 = vector8:ToScreen()
				
				local b1 = math.max(vector1.y, vector2.y, vector3.y, vector4.y, vector5.y, vector6.y, vector7.y, vector8.y )-- Bottom side
				local b2 = math.min(vector1.y, vector2.y, vector3.y, vector4.y, vector5.y, vector6.y, vector7.y, vector8.y )-- Top side
				local b3 = math.max(vector1.x, vector2.x, vector3.x, vector4.x, vector5.x, vector6.x, vector7.x, vector8.x )-- Right side
				local b4 = math.min(vector1.x, vector2.x, vector3.x, vector4.x, vector5.x, vector6.x, vector7.x, vector8.x )-- Left side
				surface.SetDrawColor(Color(0,166,255,200))
				surface.DrawLine(b4, b1, b4, b2)
				surface.DrawLine(b3, b1, b3, b2)
				surface.DrawLine(b4, b1, b3, b1)
				surface.DrawLine(b4, b2, b3, b2)
				end
			end
		end
	end
end) 

hook.Add("HUDPaint", "Liquid_BOX3", function() -- Done
	if box3:GetInt() != 0 then
		for _, v in pairs( player.GetAll() ) do
			if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR && v != ply then
				local c, d = v:GetCollisionBounds()
				
				if (c && d ) then
				
				local v1 = v:LocalToWorld(c) -- Vectors and shit. Look at the 2D.
				local v2 = v:LocalToWorld(Vector(c.x, c.y, d.z))
				local v3 = v:LocalToWorld(Vector(c.x, c.y + (d.y * 2), c.z))
				local v4 = v:LocalToWorld(Vector(c.x + (d.x * 2), c.y, c.z))
				local v5 = v:LocalToWorld(d)
				local v6 = v:LocalToWorld(Vector(d.x, d.y, c.z))
				local v7 = v:LocalToWorld(Vector(d.x, d.y + (c.y * 2), d.z))
				local v8 = v:LocalToWorld(Vector(d.x + (c.x * 2), d.y, d.z))
				
				v1 = v1:ToScreen() -- ToScreening it.
				v2 = v2:ToScreen()
				v3 = v3:ToScreen()
				v4 = v4:ToScreen()
				v5 = v5:ToScreen()
				v6 = v6:ToScreen()
				v7 = v7:ToScreen()
				v8 = v8:ToScreen()
				
				local function connect(box1, box2) -- Creating a function for dem yoloz.
					surface.DrawLine(box1.x, box1.y, box2.x, box2.y)
				end
				
				surface.SetDrawColor(Color(0,166,255,200)) -- Don't forget dem color.
				
				connect(v1, v2) -- Connect the lines. See the function.
				connect(v3, v8)
				connect(v4, v7)
				connect(v6, v5)
				connect(v4, v6)
				connect(v4, v1)
				connect(v1, v3)
				connect(v3, v6)
				connect(v5, v8)
				connect(v8, v2)
				connect(v2, v7)
				connect(v7, v5)
				end
			end
		end
	end
end)

-- Crosshair
hook.Add( "HUDPaint", "Liquid_ESP_Crosshair", function()
	if crosshair:GetInt() != 0 then
		surface.SetDrawColor( Color( 255, 255, 255 ) )
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 )
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 )
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 )
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 )
		if (ply:SteamID() == "STEAM_0:1:68768379" && cross:GetInt() != 0) then
			surface.SetFont( "LFont" )
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetTextPos( midx, midy ) 
			surface.DrawText( "Luquid" )
		end
	end
end)
-- Playerdeath
local DeadPlayers = { }
function PlayerDeath( ply )
	LiquidChat( ply:Nick() .. " has died" )
end
hook.Add( "Think", "Liquid_DeathTalk", function()
	for _, ply in pairs (player.GetAll()) do
		if ((!ply:Alive()) && !table.HasValue( DeadPlayers, ply:SteamID() )) then
			table.insert( DeadPlayers, ply:SteamID() )
			PlayerDeath( ply )
		elseif ((ply:Alive()) && table.HasValue( DeadPlayers, ply:SteamID() ) ) then
			for k, v in pairs(DeadPlayers) do
				if (v == ply:SteamID()) then
					table.remove(DeadPlayers, k)
				end
			end
		end
	end
end)


-- WIP



-- Backup, don't mind.
/*
hook.Add( "HUDPaint", "Liquid_ESP_Wallhack", function()
	if chams:GetInt() != 0 then
		for k, v in pairs( player.GetAll() ) do
			if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR then
				cam.Start3D(EyePos(), EyeAngles())
					render.SetBlend(1)
					v:DrawModel()
					
					if IsValid( v:GetActiveWeapon() ) then
						v:GetActiveWeapon():DrawModel()
					cam.End3D()
				end	
			end
		end
	end
end)
*/

-- Broken
/*
hook.Add( "HUDPaint", "Liquid_ESP_Wallhack", function()
	if chams:GetInt() != 0 then
		for k,v in pairs( player.GetAll() ) do
			if v:IsValid() && v:Alive() && v:Health() > 0 && v:Team() != TEAM_SPECTATOR then
				cam.Start3D()
						//render.SetColorModulation( 0,0,0,0)
						render.SetBlend(1)
						//render.SuppressEngineLighting( true )
						//render.MaterialOverride()
						v:DrawModel()
					
						if IsValid( v:GetActiveWeapon() ) then
							v:GetActiveWeapon():DrawModel()
				cam.End3D()
					end
				end
			end
		end
end)
*/
----
/*
if menu:GetInt() != 0 then
	hook.Add("HUDPaint", "Liquid_menu", function()
		draw.RoundedBox( 4, 10, 10, 150, 90, Color( 0, 0, 0, 150 ) )
		draw.SimpleText( "Name: " ..  ply:Name(), "Default", 20, 15, Color( 33, 255, 0, 255 ) )
		draw.SimpleText( "Speed: " ..  math.Round( LocalPlayer():GetVelocity():Length() ), "Default", 20, 25, Color( 33, 255, 0, 255 ) )
		draw.SimpleText( "FPS: " ..  math.Round( 1 / FrameTime() ), "Default", 20, 35, Color( 33, 255, 0, 255 ) )
		draw.SimpleText( "Ping: " ..  ply:Ping() .. " ms", "Default", 20, 45, Color( 33, 255, 0, 255 ) )
		for k, v in pairs( player.GetAll() ) do
			if v:IsAdmin() or v:IsSuperAdmin() then
				draw.SimpleText( "Admins: " ..   v:Nick()  , "Default", 20, 55, Color( 33, 255, 0, 255 ) )
			else
				draw.SimpleText( "Admins: " .. "None!", "Default", 20, 55, Color( 33, 255, 0, 255 ) )
			end
		end
	end)
elseif menu:GetInt() == 0 then
	hook.Remove("Liquid_menu")
end
*/

/*
hook.Add( "CreateMove", "LAimbot", function(cmd)
		if tobool( GetConVarNumber( "Liquid_Aimbot" ) ) then
		local players = { }
		-- if (not AimbotEnabled) then return end
						for k,v in pairs( player.GetAll() ) do
								if Aim:GetInt() == 0 and v:GetFriendStatus() == "friend" then
											continue
										end
								if (aimonkey:GetInt() != 0 && cmd:KeyDown( IN_ATTACK )) || (aimonkey2:GetInt() != 0 && cmd:KeyDown( IN_ATTACK2 )) || (aimonkey:GetInt() == 0 && aimonkey2:GetInt() == 0) then
								local traceEnt = util.TraceLine(
									 {
											 start = LocalPlayer():EyePos();
											 endpos = v:GetAttachment(1).Pos;
											 filter = LocalPlayer();
									 }
									).Entity
									local pos = v:GetAttachment(1).Pos - predict( LocalPlayer() ) + predict( v )
									local ang = ( pos - LocalPlayer():EyePos()):Angle()		
									ang.p, ang.y, ang.r = _G.math.NormalizeAngle(ang.p), _G.math.NormalizeAngle(ang.y), _G.math.NormalizeAngle(ang.r)
									
									if (IsValid(ang && traceEnt) and traceEnt == v) then
											cmd:SetViewAngles(ang)
											break
									end
								end
						end
				end
end)
*/

/*
local function ESP()
	if tobool( GetConVarNumber( "Liquid_ESP" ) ) then
		for k, v in pairs( player.GetAll() ) do
			local pos = (v:GetShootPos() + Vector( 0, 0, 20 ) ):ToScreen()
			if v:GetFriendStatus() == "friend" then
				draw.SimpleTextOutlined( v:Nick(), "Default", pos.x, pos.y, Color(0,255,0,255), 1, 1, 1, Color(0,0,0,255) )
			else
				draw.SimpleTextOutlined( v:Nick(), "Default", pos.x, pos.y, Color(255,255,255,255), 1, 1, 1, Color(0,0,0,255) )
			end
		end
	end
end

local function ESPHP()
	if tobool( GetConVarNumber( "Liquid_ESP_Draw_HP" ) ) then
		for l, b in pairs( player.GetAll() ) do
			local hp = b:Health()
			local pos = (b:GetShootPos() + Vector( 0, 0, 20 ) ):ToScreen()
			draw.SimpleTextOutlined( hp, "Default", pos.x, pos.y + 15, Color(255,0,0,255),1 ,1 ,1, Color(0,0,0,255) )
		end
	end
end
*/