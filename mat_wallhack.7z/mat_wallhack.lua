--[[
	hacks/MatWH.lua
	aintash
	===Begin DStream===
]]

local HealthSwitch = CreateClientConVar("sw_esp_health", 1, false, false)
local WeaponSwitch = CreateClientConVar("sw_esp_weapon", 1, false, false)
local DistSwitch = CreateClientConVar("sw_esp_dist", 1, false, false)

local WallhackSwitch = CreateClientConVar("sw_wallhack", 0, false, false)
local ModelSwitch = CreateClientConVar("sw_model", 1, false, false)
local WireframeSwitch = CreateClientConVar("sw_wireframe", 0, false, false)
local ColorSwitch = CreateClientConVar("sw_color", 0, false, false)
local WeapModelSwitch = CreateClientConVar("sw_weapon", 1, false, false)

local AimSwitch = CreateClientConVar("sw_aim", 0, false, false)
local NoRecoilSwitch = CreateClientConVar("sw_norecoil", 1, false, false)
local AimOnFireSwitch = CreateClientConVar("sw_aimonfire", 0, false, false)

local NpcSwitch = CreateClientConVar("sw_npc", 1, false, false)

local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_fishing_rod", "none"}

local r, g, b, rw, gw, bw, rn, gn, bn = 255
local NoobHackColor = Color(50, 50, 255)

local NpcColor = Color(255, 255, 25, 255)
local TraitorColor = Color(255, 25, 25, 255)
local WeaponColor = Color(25, 25, 255, 255)
local DefColor = Color(255, 255, 255, 255)

local function GetAngle(ent)
	return (ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) - LocalPlayer():GetShootPos()):Angle()
end

local function Madness(ply, del)
	if del != "stop" then
		colors = {}
		colors[1] = Color(255, 0, 0, 255)
		colors[2] = Color(255, 255, 0, 255)
		colors[3] = Color(255, 0, 255, 255)
		colors[4] = Color(0, 255, 0, 255)
		colors[5] = Color(0, 255, 255, 255)
		colors[6] = Color(0, 0, 255, 255)
		colors[7] = Color(0, 0, 0, 255)
		colors[8] = Color(255, 255, 255, 255)
		if del == 0 then
			delay = 1
		else
			delay = del
		end
		timer.Create("timer", delay, 10^10, function()
			ply:SetColor(table.Random(colors))
		end)
	else
		ply:SetMaterial("")
		ply:SetColor(color)
		timer.Stop("timer")
	end
end

local Deads = {}
local Traitors = {}
local FoundWeps = {}
local TWeps = {"C4", "knife_name", "Poltergeist", "sipistol_name", "flare_name", "newton_name", "radio_name", "tele_name", "decoy_name", "����� ������",
"AK47", "AWP|Traitors", "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio",
"weapon_ttt_teleport"}

hook.Add("Think", "CheckTraitors", function()
	if !string.find(GAMEMODE.Name , "Terror") then return end
	for k, v in pairs(player.GetAll()) do
		if v:GetActiveWeapon():IsWeapon() and v:GetActiveWeapon():IsValid() then
			if (table.HasValue(TWeps, v:GetActiveWeapon():GetPrintName()) or table.HasValue(TWeps, v:GetActiveWeapon():GetClass())) and !table.HasValue(FoundWeps, v:GetActiveWeapon()) then
				table.insert(FoundWeps, v:GetActiveWeapon()) 
				table.insert(Traitors, v) 
				chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "Traitor ", Color(255, 50, 50), v:Nick(), Color(100, 200, 100), " got weapon ", Color(75, 255, 75), v:GetActiveWeapon():GetPrintName())
			end
		end
		
		if !v:Alive() and !table.HasValue(Deads, v) then
			table.insert(Deads, v)
			chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "Player ", Color(255, 255, 0), v:Nick(), Color(100, 200, 100), " is now dead.")
		end
		
		if v:Health() > 0 and table.HasValue(Deads, v) then
			Deads = {}
			Traitors = {}
			FoundWeps = {}
		end
	end
end)

concommand.Add("sw_traitors", function()
	if string.find(GAMEMODE.Name , "Terror") then
		chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "Traitors:")
		for k, v in pairs(player.GetAll()) do
			if table.HasValue(Traitors, v) then
				chat.AddText(Color(255, 50, 50), v:Nick())
			end
		end
	else
		chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "This gamemode isn't TTT.")
	end
end)
concommand.Add("sw_deads", function()
	if string.find(GAMEMODE.Name , "Terror") then
		chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "Deads:")
		for k, v in pairs(player.GetAll()) do
			if table.HasValue(Deads, v) then
				chat.AddText(Color(255, 255, 0), v:Nick())
			end
		end
	else
		chat.AddText(Color(50, 50, 255), "[NoobHack]", Color(100, 200, 100), "This gamemode isn't TTT.")
	end
end)

----------------------------------------------ESP----------------------------------------------
hook.Add("HUDPaint", "DrawText", function()
	if !WallhackSwitch:GetBool() then return else
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				--Setup--
				local Pos = (v:GetPos() + Vector(0, 0, 130)):ToScreen()
				local TextColor = Color(100, 255, 100, 185)
				
				if table.HasValue(Traitors, v) then
					Special = "       Traitor"
				else
					Special = ""
				end
				local Name = v:Nick()
				local Health = v:Health()  .. "HP"
				local Weapon = "None"
				local Distance = math.Round(LocalPlayer():GetPos():Distance(v:GetPos()))
				
				if v:GetActiveWeapon():IsValid() then
					Weapon = v:GetActiveWeapon():GetPrintName()
				end
				
				if !v:Alive() then
					TextColor = Color(50, 50, 50, 150)
					Health = "*Dead*"
				end
				
				--Draw--
				draw.DrawText(Name, "BudgetLabel", Pos.x, Pos.y,  TextColor, 1)
				draw.DrawText(Special, "BudgetLabel", Pos.x, Pos.y,  Color(255, 50, 50, 185), 3)
				if HealthSwitch:GetBool() then
					draw.DrawText(Health, "BudgetLabel", Pos.x, Pos.y + 12, TextColor, 1)
				end
				if WeaponSwitch:GetBool() then
					draw.DrawText(Weapon, "BudgetLabel", Pos.x, Pos.y + 24, TextColor, 1)
				end
				if DistSwitch:GetBool() then
					draw.DrawText(Distance, "BudgetLabel", Pos.x, Pos.y + 36, TextColor, 1)
				end
			end
		end

		if NpcSwitch:GetBool() then
			for k, v in pairs(ents.GetAll()) do
				if v:IsNPC() then
					local Pos = (v:GetPos() + Vector(0, 0, 120)):ToScreen()
					local TextColor = Color(100, 100, 255, 185)
					draw.DrawText("NPC", "BudgetLabel", Pos.x, Pos.y,  TextColor, 1)
					draw.DrawText(v:GetModel(), "BudgetLabel", Pos.x, Pos.y + 12, TextColor, 1)
				end
			end
		end
	end
end)

----------------------------------------------Model----------------------------------------------
hook.Add("RenderScreenspaceEffects", "DrawModels", function()
	local DrawColor
	local DrawMat
	local Draw = false
	

		
	for k, v in pairs(ents.GetAll()) do
		if ModelSwitch:GetBool() and v != LocalPlayer() then
			if type(v) == "Player" or v:GetClass() == "player" then
				if ColorSwitch:GetBool() then
					DrawColor = Color(r, g, b, 255)
				else
					DrawColor = team.GetColor(v:Team())
					if table.HasValue(Traitors, v) then
						DrawColor = TraitorColor
					end
				end
				if WireframeSwitch:GetBool() then
					DrawMat = "wh_wireframe"
				else
					DrawMat = "wh_solid"
				end
				Draw = true
			elseif type(v) == "Weapon" or string.find(v:GetClass(), "weapon") then
				if ColorSwitch:GetBool() then
					DrawColor = Color(rw, gw, bw, 255)
				else
					DrawColor = WeaponColor
				end
				if WireframeSwitch:GetBool() then
					DrawMat = "wh_wireframe"
				else
					DrawMat = "wh_solid"
				end
				Draw = true
			elseif type(v) == "NPC" or string.find(v:GetClass(), "npc") then
				if ColorSwitch:GetBool() then
					DrawColor = Color(rn, gn, bn, 255)
				else
					DrawColor = NpcColor
				end
				if WireframeSwitch:GetBool() then
					DrawMat = "wh_wireframe"
				else
					DrawMat = "wh_solid"
				end
				Draw = true
			else
				DrawMat = ""
				DrawColor = DefColor
			end
		else
			DrawMat = ""
			DrawColor = DefColor
		end
		
		if Draw then
			v:SetMaterial(DrawMat)
			v:SetColor(DrawColor)
			Draw = false
		end
	end
end)

----------------------------------------------AimBot----------------------------------------------
hook.Add("CreateMove", "MoveAim", function(ply)
	AimTrace = LocalPlayer():GetEyeTrace()
	if AimTrace.Entity:IsValid() and LocalPlayer():GetActiveWeapon():IsWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
		if AimSwitch:GetBool() and LocalPlayer():Alive() and !table.HasValue(BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass()) then
				if AimTrace.Entity:GetClass() == "player" then
				ply:SetViewAngles(GetAngle(AimTrace.Entity))
			end
		end
	end
	
	if NoRecoilSwitch:GetBool() and LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		LocalPlayer():GetActiveWeapon().Recoil = 0
	end
end)