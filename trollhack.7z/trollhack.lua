--[[
	lua/TrollhackTEST.txt
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

CreateClientConVar("BBox", 1, true, false)
CreateClientConVar("Snaplines", 1, true, false)

local dontaimteam = 0
local _R = debug.getregistry()
local eyang = _R["Player"].SetEyeAngles
local varmenu = {}
varmenu.current = 1
varmenu.showmenu = 1
local nH = {}
nH.aim = 1
nH.esp = 1
nH.snap = 1
nH.radar = 1
nH.nospread = 0
nH.autoshoot = 0
nH.onshoot = 0
nH.silent = 1
nH.AA = 1
local timerruns = 1
cne = Vector(0,0,0)
local function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
 if( input.IsKeyDown( KEY_DELETE ) ) then timerruns = 0
    print("Destroyed timer")
    hook.Remove( "HUDPaint","menuespandcrosshair" )
    hook.Remove( "CalcView","lol" )
    hook.Remove( "CreateMove","nospreadnaim" )
    hook.Remove( "AntiAimz","Imbatman" )
    print("Unloaded Hooks")
    end
    if( input.IsKeyDown( KEY_INSERT ) ) then
    if varmenu.showmenu == 0 then
    varmenu.showmenu = 1
    else
    varmenu.showmenu = 0
    end
    end
    if varmenu.showmenu == 1 then
    if( input.IsKeyDown( KEY_DOWN ) ) then
    if varmenu.current == 1 then
    varmenu.current = 2
    elseif varmenu.current == 2 then
    varmenu.current = 3
    elseif varmenu.current == 3 then
    varmenu.current = 4
    elseif varmenu.current == 4 then
    varmenu.current = 5
    elseif varmenu.current == 5 then
    varmenu.current = 1
    end
    end
    if( input.IsKeyDown( KEY_UP ) ) then
    if varmenu.current == 5 then
    varmenu.current = 4
    elseif varmenu.current == 4 then
    varmenu.current = 3
    elseif varmenu.current == 3 then
    varmenu.current = 2
    elseif varmenu.current == 2 then
    varmenu.current = 1
    elseif varmenu.current == 1 then
    varmenu.current = 5
    end
    end
    if( input.IsKeyDown( KEY_RIGHT ) ) then
    if varmenu.current == 1 then
    if nH.aim == 1 then
    nH.aim = 0
    else
    nH.aim = 1
    end
    elseif varmenu.current == 2 then
    if nH.autoshoot == 1 then
    nH.autoshoot = 0
    else
    nH.autoshoot = 1
    end
    elseif varmenu.current == 3 then
    if nH.AA == 1 then
    nH.AA = 0
    else
    nH.AA = 1
    end
    elseif varmenu.current == 4 then
    if nH.esp == 1 then
    nH.esp = 0
    else
    nH.esp = 1
    //nH.onshoot = 0
    end
    elseif varmenu.current == 5 then
    if nH.snap == 1 then
    nH.snap = 0
    else
    nH.snap = 1
    //nH.autoshoot = 0
    end
    end
    end
    end
    end
KeyPress()



local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.1
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local dontaimweaps = {}
dontaimweaps["weapon_crowbar"] = true
dontaimweaps["weapon_physcannon"] = true
dontaimweaps["weapon_physgun"] = true
dontaimweaps["weapon_rpg"] = true
dontaimweaps["weapon_grenade_frag"] = true
dontaimweaps["weapon_stunstick"] = true
dontaimweaps["weapon_slam"] = true
dontaimweaps["gmod_tool"] = true


local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end




local dontaim = {"npc_hunter","npc_dog","npc_monk","npc_alyx","npc_mossman","npc_barney","npc_eli","npc_gman","npc_citizen","npc_turret_floor","npc_grenade_frag","rebelturret","npc_vortigaunt","npc_barnacle","npc_barnacle_tongue_tip","npc_kleiner","npc_satchel","npc_rollermine"}
local dontaim = {""}
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}

local function HeadPos(ply)
    if IsValid(ply) then
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
    local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
    local hbone = ply:LookupBone(bone)
        return ply:GetBonePosition(hbone)
    else return end
end



local function Visible2(ply)
	local tracedata = {}
	   tracedata.start = LocalPlayer():GetShootPos()
	   tracedata.endpos = HeadPos(ply)
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
end

local function GetColorVisible(e)
	if Visible2(e) then
		return 255,0,0,255
	end
	if !Visible2(e) then
		return team.GetColor(e:Team())
	end
end



	local function Visible(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
      return true
  else
        return false
   end   
end




local tar = nil
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local function fovcheck(input,input2)
return true
end
local function checkteam(pl)
if dontaimteam == 1 then
if LocalPlayer():Team() == pl:Team() then
return false
end
else
return true
end
end

local function validtarget(entz)
if !(LocalPlayer():GetActiveWeapon() == nil) then
if dontaimweaps[LocalPlayer():GetActiveWeapon():GetClass()] then return false end
else
return false
end
if !IsValid(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsNPC() then
if entz.IsDead == true then
return false
end
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
local function validtarget2(entz)
if !IsValid(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then
if entz.IsDead == true then
return false
end
end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
return true
end
local function GetMeta(name)
    return table.Copy(_R[name] or {})
end
local function get(a,b)
return math.abs((a.x or 0)-(b.x or 0))+math.abs((a.y or 0)-(b.y or 0))
end
local VecM = GetMeta("Vector")
local function FindTarget()
    local ply = LocalPlayer()
    if !IsValid(ply) then return end
    local maxAng = 500000000000000
    local aimVec, shootPos = ply:GetAimVector(), ply:GetShootPos()

    local targets = ents.GetAll()
    for i, ent in pairs(targets) do
        if validtarget(ent) == false then
            targets[i] = nil
        end
    end

    local closestTarget, lowestAngle = _, maxAng
    for _, target in pairs(targets) do
            local targetPos = HeadPos(target)
            local angle = LocalPlayer():GetShootPos():Distance(targetPos)

            if angle < lowestAngle then
                lowestAngle = angle
                closestTarget = target
            end
    end
    if closestTarget then
    oldtarget = closestTarget
    return closestTarget
    end
    return false
end
PredictWeapons = {
        ["weapon_crossbow"] = 3110,
    }

function WeaponPrediction( e, pos )
    local ply = LocalPlayer()
    if ( IsValid( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
    if IsValid(ply:GetActiveWeapon()) then
        local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
        if ( wep && PredictWeapons[ wep ]  ) then
            local t = (dis / 3500) + 0.05
                    local mul = 0.0074
                    local pos = ( pos + e:GetVelocity() * t )
            pos = pos - (e:GetVelocity() * mul)
            return pos
        end
    end
    end
    return pos
end
local function calcs( u )
//////
if LocalPlayer():Alive() then
/////
        local ply = LocalPlayer()
        if LocalPlayer():Alive() then
        local ply = LocalPlayer()
        local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
        correctView = correctView + mouse
        end
        correctView.p = math.Clamp(math.NormalizeAngle( correctView.p ),-89,89)
        correctView.y = math.NormalizeAngle( correctView.y )
        local view = correctView
        if nH.nospread == 1 then
        if 1 + 1 == 2 then
        else
        if !(u:GetButtons() and IN_USE > 0) then
        view = view + Vector(180,180,180)
        end
        end
        end
        SetViewAngles( u,view)
        if !(nH.aim==1) then return end
        if nH.onshoot == 1 then
        if !(u:GetButtons() and IN_ATTACK > 0) then
        return
        end
        end
        if FindTarget() && IsValid(FindTarget()) then
        local targetheadpos = HeadPos(FindTarget())
        local velocity = FindTarget():GetVelocity() or Vector(0,0,0)
        local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
        local ang = (((targetheadpos + velocity*FrameTime()))- (ply:GetShootPos()+velocityplayer*FrameTime())):Angle()
        if fovcheck(correctView,ang) then
        if !nH.silent == 1 then
        correctView = ang
        end
        if nH.autoshoot == 1 and nH.onshoot == 0 then
            RunConsoleCommand( "+attack" )
            timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
        end
        local angz = (WeaponPrediction( FindTarget(),(((targetheadpos + velocity*FrameTime()))- (ply:GetShootPos()+velocityplayer*FrameTime())):Angle()))
        if nH.nospread == 1 then
        if (u:GetButtons() and IN_ATTACK > 0) then
        end
        end
        SetViewAngles( u,angz )
        --SetViewAngles( u,PredictSpread(u,ang)-anglepunch() )
        end
        end
//
	end
//
end
hook.Add("CreateMove","aim",calcs)
    local function Norec( u, o )
        return { origin = o, angles = correctView}
    end
    hook.Add( "CalcView","lol", Norec )
function DrawFadingColorBox(x,y,w,h,alpha)
    local calculate = h/255
        for i=0,h do
        surface.SetDrawColor( i/calculate, i/calculate, 0, alpha)
        surface.DrawLine( x, i+y, x+w, i+y )
        end
end
//local function drawradar()
function ServerGamemodeIs( name )
	local _hN = GetConVarString( "hostname" )
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		//PB:ChatMessage( "This server, " .. _hN .. ", is using the gamemode '" .. GAMEMODE.Name "'. Loading gamemode functions..." )
		return true
	end
	return false
end
function DoChecksRadar( e )

	local ply, val = LocalPlayer(), 0
	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
	
	return true
	
end

function DrawText( text, font, x, y, colour, xalign, yalign )

	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end
	
	local curX = x
	local curY = y
	local curString = ""
	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")
	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

function SetColors( e )

	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col
	


		col = team.GetColor( e:Team() )
	
		
		
	
	
	return col
end
local RRadar, AAdminList, IInfoMenu

function drawradar()
	end
function radar()
	
	// Radar ----------------------------------------------------------------------
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 300, 300 )
	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2
	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
	Radar:SetTitle( "TrollHook Rage Edition - Radar" )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, rW, rH )
		
		local ply = LocalPlayer()
		
		local radar = {}
		radar.h		= 300
		radar.w		= 300
		radar.org	= 5000
		
		local x, y = ScrW() / 2, ScrH() / 2
		
		local half = rH / 2
		local xm = half
		local ym = half
		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )
		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then
				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 255 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
				
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				
				
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )
				
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )
				
				local text = e:GetClass()
				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				end
				
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
				
					draw.RoundedBox( s, posX, posY, s, s, color )
					DrawText(
						text,
						"DefaultSmall",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end

	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )
	
	RRadar = Radar
end
radar()

local function box( e )
    local ply, pos = LocalPlayer(), nil
    local center = e:LocalToWorld( e:OBBCenter() )
    local min, max = e:OBBMins(), e:OBBMaxs()
    local dim = max - min
    local z = max + min
    
    local frt    = ( e:GetForward() ) * ( dim.y / 2 )
    local rgt    = ( e:GetRight() ) * ( dim.x / 2 )
    local top    = ( e:GetUp() ) * ( dim.z / 2 )
    local bak    = ( e:GetForward() * -1 ) * ( dim.y / 2 )
    local lft    = ( e:GetRight() * -1 ) * ( dim.x / 2 )
    local btm    = ( e:GetUp() * -1 ) * ( dim.z / 2 )
    
    local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
    v = d / 30
    
    pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
    if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
    
    local FRT     = center + frt + rgt + top; FRT = FRT:ToScreen()
    local BLB     = center + bak + lft + btm; BLB = BLB:ToScreen()
    local FLT    = center + frt + lft + top; FLT = FLT:ToScreen()
    local BRT     = center + bak + rgt + top; BRT = BRT:ToScreen()
    local BLT     = center + bak + lft + top; BLT = BLT:ToScreen()
    local FRB     = center + frt + rgt + btm; FRB = FRB:ToScreen()
    local FLB     = center + frt + lft + btm; FLB = FLB:ToScreen()
    local BRB     = center + bak + rgt + btm; BRB = BRB:ToScreen()
    
    pos = pos:ToScreen()
    
    local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
    local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    
    return maxX, minX, maxY, minY
end

//if !(IsValid(FindTarget())) then
//draw.SimpleText( "[NaziHook] Searching for target.", "Default", ScrW()/2, 16/2, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
//else
//if FindTarget():IsNPC() then
//draw.SimpleText( "[NaziHook] Target: "..FindTarget():GetClass(), "Default", ScrW()/2, 16/2,Color(0,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
//else
//draw.SimpleText( "[NaziHook] Target: "..FindTarget():GetName(), "Default", ScrW()/2, 16/2,Color(0,255,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
//end
//end
if nH.esp == 1 then
RunConsoleCommand("BBox", "1")
else
RunConsoleCommand("BBox", "0")
								//surface.SetDrawColor(0,0,255,255)
								//surface.SetDrawColor(TeamColor)
								//  surface.SetDrawColor(GetColorVisible(e))				
								//surface.DrawLine( maxX, maxY, maxX, minY )
								//surface.DrawLine( maxX, minY, minX, minY )					
								//surface.DrawLine( minX, minY, minX, maxY )
								//surface.DrawLine( minX, maxY, maxX, maxY )
end


if nH.snap == 1 then
RunConsoleCommand("Snaplines", "1")
else
RunConsoleCommand("Snaplines", "0")
end
			
 binds = { ["+speed"] = e }
function Speedkey()

 if input.IsKeyDown(KEY_E) && !(IsValid(FindTarget())) then
RunConsoleCommand("host_framerate", "10")
else
RunConsoleCommand("host_framerate", "0")
end
end
Speedkey()


								
       // for k, v in pairs(ents.GetAll()) do
            //if( IsValid(v) and v ~= LocalPlayer() ) then
                //if( v:IsNPC() ) then
                    //local drwclr = Color(255, 255, 255, 255);
                    //local vis = ""
                    //if( Visible(v) ) then
                   //     vis = "Visible"
                    //    drwclr = Color( 255, 0, 0, 255 );
                   // else
                    //    vis = "Invisible"
                    //    drwclr = Color( 0, 255, 255, 255 );
                   // end
                    //if !validtarget2(v) then
                    //return
                   // end
                   // surface.SetDrawColor(drwclr)
                    //local head = HeadPos(v):ToScreen()
                    //local maxX, minX, maxY, minY = box(v)
                    //local lol = maxY-minY
                    //local x = head.x
                    //local y = head.y
                    //local lol = maxY-minY
                    //surface.DrawLine( maxX, maxY, maxX, head.y )
                    //surface.DrawLine( maxX, head.y, minX, head.y )
                    //
                    //surface.DrawLine( minX, head.y, minX, maxY )
                   // surface.DrawLine( minX, maxY, maxX, maxY )
if FindTarget() == v then
surface.SetDrawColor(Color(255,255,0,255))
end
--[[surface.DrawLine( x-5, y, x+5, y )
surface.DrawLine( x, y-5, x, y+5 )

surface.DrawLine( x+5, y+5, x+5, y )
surface.DrawLine( x-5, y-5, x-5, y )

surface.DrawLine( x+5, y-5, x, y-5 )
surface.DrawLine( x-5, y+5, x, y+5 )]]--
//X
--[[
surface.DrawRect( x, y - 5, 1,11);
surface.DrawRect( x - 5, y, 11,1);
//X

//Outer Horizontal
surface.DrawRect( x - 1, y  - 6, 3,1);
surface.DrawRect( x - 1, y  + 6, 3,1);
surface.DrawRect( x - 1, y  - 8, 3,1);
surface.DrawRect( x - 1, y  + 8, 3,1);
            
surface.DrawRect( x - 2, y  - 8, 1,3);
surface.DrawRect( x - 2, y  + 6, 1,3);

surface.DrawRect( x + 2, y  - 8, 1,3);
surface.DrawRect( x + 2, y  + 6, 1,3);
//Outer Horizontal

//Outer Vertically
surface.DrawRect( x - 6, y  - 1, 1,3);
surface.DrawRect( x + 6, y  - 1, 1,3);
surface.DrawRect( x - 8, y  - 1, 1,3);
surface.DrawRect( x + 8, y  - 1, 1,3);
            
surface.DrawRect( x - 8, y  - 2, 3,1);
surface.DrawRect( x + 6, y  - 2, 3,1);

surface.DrawRect( x - 8, y  + 2, 3,1);
surface.DrawRect( x + 6, y  + 2, 3,1);
//Outer Vertically
surface.SetDrawColor(drwclr)
if FindTarget() == v then
surface.SetDrawColor(Color(255,255,0,255))
end
//Outer Horizontal FILL
surface.DrawRect( x - 1, y - 7, 3,1);
surface.DrawRect( x - 1, y + 7, 3,1);
//Outer Horizontal FILL

//Outer Vertically FILL
surface.DrawRect( x - 7, y - 1, 1,3);
surface.DrawRect( x + 7, y - 1, 1,3);
//Outer Vertically FILL
]]--
              //  end
          //  end
//        end
//end
        if varmenu.showmenu == 1 then
        surface.SetDrawColor( 0, 0, 0, 100 );
        surface.DrawRect( ScrW()/2-100, 0, 200, 16*6+50 );
        //surface.SetDrawColor( 100, 0, 0, 255 );
        //surface.DrawRect( ScrW()/2-99, 18, 198, 16*5-50 );
        surface.SetDrawColor( 255, 0, 0, 255 );
        if varmenu.current == 1 then
        surface.DrawRect(ScrW()/2-99,16,198,16);
        elseif varmenu.current == 2 then
        surface.DrawRect(ScrW()/2-99,16*2,198,16);
        elseif varmenu.current == 3 then
        surface.DrawRect(ScrW()/2-99,16*3,198,16);
        elseif varmenu.current == 4 then
        surface.DrawRect(ScrW()/2-99,16*4,198,16);
        elseif varmenu.current == 5 then
        surface.DrawRect(ScrW()/2-99,16*5,198,16);
	elseif varmenu.current == 6 then
        surface.DrawRect(ScrW()/2-99,16*6,198,16);
        end
        surface.SetDrawColor( 255, 255, 255, 255 );
        surface.DrawOutlinedRect( ScrW()/2-102, 0, 203, 16*6+50 );
        surface.DrawOutlinedRect( ScrW()/2-102, 0, 203, 16*1+1 );
        draw.SimpleText( "TrollHack Rage Edition", "Default", ScrW()/2, 16/2, Color( 255, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1)
        draw.SimpleTextOutlined( "Aimbot: "..nH.aim, "Default", ScrW()/2-80, 16/2+16, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Autoshoot: "..nH.autoshoot, "Default", ScrW()/2-80, 16/2+(16*2), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Anti-Aim: "..nH.AA, "Default", ScrW()/2-80, 16/2+(16*3), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Esp Box: "..nH.esp, "Default", ScrW()/2-80, 16/2+(16*4), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        draw.SimpleTextOutlined( "Snap Lines: "..nH.snap, "Default", ScrW()/2-80, 16/2+(16*5), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
	//draw.SimpleTextOutlined( "Esp Box: "..nH.esp, "Default", ScrW()/2-80, 16/2+(16*6), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
        end
        drawradar()
//        end
local timerruns = 1
//hook.Add("HUDPaint","esp",espzor)
local function unhookz()
timerruns = 0
    hook.Remove("Think","firebulltimer")
    hook.Remove( "HUDPaint","esp" )
    hook.Remove( "CalcView","lol" )
    hook.Remove( "CreateMove","aim" )
    hook.Remove( "HUDPaint", "OnPaint" )
    print("Unloaded Hooks")
end
local function keyz()
if timerruns == 1 then
timer.Simple(0.1,function () keyz() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
unhookz()
    end
    end
keyz()
function OnPaint()
drawradar()
end
hook.Add( "HUDPaint", "OnPaint", OnPaint )