// Trooper Mini-Hack created by Assault_Trooper

local Version = "v1.0 Public"
print( "Trooper Mini-Hack " .. Version .. " loaded!" )

local AimbotSwitch = CreateClientConVar( "trooper_aimbot", 0, true, false )
local WallhackSwitch = CreateClientConVar( "trooper_wallhack", 0, true, false )
local AutoshootSwitch = CreateClientConVar( "trooper_autoshoot", 0, true, false )
local NoRecoilSwitch = CreateClientConVar( "trooper_norecoil", 0, true, false )
local FriendSwitch = CreateClientConVar( "trooper_friends", 0, true, false )
local TeamSwitch = CreateClientConVar( "trooper_team", 0, true, false )

local Firing = false

local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_fishing_rod", "none"}

local function WeaponCheck()

if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
if table.HasValue( BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass() ) then return false end
if LocalPlayer():GetActiveWeapon():Clip1() == 0 then 
RunConsoleCommand( "+reload" )
timer.Simple( 0.1, function() RunConsoleCommand( "-reload" ) end )
return false 
else 
return true 
end
if !LocalPlayer():GetActiveWeapon() then return -1 end

end
end

local function GetTarget( ent )

if ent:IsValid() and ( ent:IsPlayer() or ent:IsNPC() ) then

local Head = ent:LookupBone( "ValveBiped.Bip01_Head1" )
return ent:GetBonePosition( Head )

end

end

local function StatusCheck( ply )

if ply:IsWorld() then return false end
if !( ply:IsPlayer() or ply:IsNPC() ) then return false end
if FriendSwitch:GetInt() == 1 and ply:GetFriendStatus() == "friend" then return false end
if TeamSwitch:GetInt() == 1 and ply:Team() == LocalPlayer():Team() then return false end

return true

end

hook.Add( "CreateMove", "Aimbot", function( UCMD )

local trace = LocalPlayer():GetEyeTrace()

if trace.Entity:IsValid() and AimbotSwitch:GetInt() == 1 and WeaponCheck() and StatusCheck( trace.Entity ) then

UCMD:SetViewAngles( ( GetTarget( trace.Entity ) - LocalPlayer():GetShootPos() ):Angle() )

end

if AutoshootSwitch:GetInt() == 1 and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and trace.Entity:IsValid() and StatusCheck( trace.Entity ) then

if !Firing then

RunConsoleCommand( "+attack" )
LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
Firing = true

end

else

if Firing then

RunConsoleCommand( "-attack" ) 
Firing = false

end

end

if NoRecoilSwitch:GetInt() == 1 and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

end

end )

hook.Add( "HUDPaint", "Wallhack", function()

if WallhackSwitch:GetInt() == 1 then

for k,v in pairs ( player.GetAll() ) do

local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
local Name = ""
local nColor = Color( 255, 255, 255, 255 )

if v == LocalPlayer() then Name = "" else Name = v:Name() end
if !v:Alive() then 
Name = "*Dead* " .. Name 
nColor = Color( 0,0,0,255 )
else
nColor = team.GetColor( v:Team() ) 
end

draw.DrawText( Name, "MenuLarge", Position.x, Position.y, nColor, 1 )

end

end

end )

concommand.Add( "+trooper_menu", function()

AimbotMenu = vgui.Create( "DFrame" )
AimbotMenu:SetSize( 200, 173 )
AimbotMenu:Center()
AimbotMenu:SetTitle( "Trooper Mini-Hack " .. Version )
AimbotMenu:SetVisible( true )
AimbotMenu:MakePopup()

local AimbotToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
AimbotToggle:SetPos( 10, 30 )
AimbotToggle:SetText( "Aimbot" )
AimbotToggle:SetValue ( AimbotSwitch:GetInt() )
AimbotToggle:SetConVar( "trooper_aimbot" )
AimbotToggle:SizeToContents()

local TeamToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
TeamToggle:SetPos( 10, 50 )
TeamToggle:SetText( "Ignore team" )
TeamToggle:SetValue( TeamSwitch:GetInt() )
TeamToggle:SetConVar( "trooper_team" )
TeamToggle:SizeToContents()

local FriendsToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
FriendsToggle:SetPos( 10, 70 )
FriendsToggle:SetText( "Ignore friends" )
FriendsToggle:SetValue( FriendSwitch:GetInt() )
FriendsToggle:SetConVar( "trooper_friends" )
FriendsToggle:SizeToContents()

local AutoshootToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
AutoshootToggle:SetPos( 10, 90 )
AutoshootToggle:SetText( "Autoshoot" )
AutoshootToggle:SetValue( AutoshootSwitch:GetInt() )
AutoshootToggle:SetConVar( "trooper_autoshoot" )
AutoshootToggle:SizeToContents()

local NorecoilToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
NorecoilToggle:SetPos( 10, 110 )
NorecoilToggle:SetText( "No-recoil" )
NorecoilToggle:SetValue( NoRecoilSwitch:GetInt() )
NorecoilToggle:SetConVar( "trooper_norecoil" )
NorecoilToggle:SizeToContents()

local WallhackToggle = vgui.Create( "DCheckBoxLabel", AimbotMenu )
WallhackToggle:SetPos( 10, 130 )
WallhackToggle:SetText( "Wallhack" )
WallhackToggle:SetValue( WallhackSwitch:GetInt() )
WallhackToggle:SetConVar( "trooper_wallhack" )
WallhackToggle:SizeToContents()

local CreditTag = vgui.Create( "DLabel", AimbotMenu )
CreditTag:SetPos( 30, 150 )
CreditTag:SetSize( 50, 20 )
CreditTag:SetText( "Created by Assault_Trooper" )
CreditTag:SizeToContents()

end )

concommand.Add( "-trooper_menu", function()

AimbotMenu:Remove()

end )