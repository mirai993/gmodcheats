// Ultimate v4 - Sublimity
local ultimate = {}

require( "zxcmodule" )




















/*



// Color class
ultimate.Colors = {}
ultimate.PcRamp = {}

function ultimate.AssignColor( id, r, g, b, a, ramp, proxy )
    a = a or 255

    if ramp then
        ramp[ #ramp + 1 ] = { r, g, b }

        local r = {}

        for i = 1, #ramp - 1 do
            local from = ramp[ i ]
            local to = ramp[ i + 1 ]
            
            for s = 1, 32 do
                local mul = s / 32

                local step = {
                    r = math.floor( from[ 1 ] * ( 1 - mul ) + to[ 1 ] * mul ),
                    g = math.floor( from[ 2 ] * ( 1 - mul ) + to[ 2 ] * mul ),
                    b = math.floor( from[ 3 ] * ( 1 - mul ) + to[ 3 ] * mul ),

                    a = a, q = a / 255,
                }

                step.x = step.r / 255
                step.y = step.g / 255
                step.z = step.b / 255

                r[ #r + 1 ] = step
            end
        end

        local m = #r + 1
        for i = 1, m do
            r[ #r + 1 ] = r[ m - i ]
        end

        ramp = r 
    end

    ultimate.Colors[ id ] = {
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255,
        ramp = ramp or false, proxy = proxy or false
    }

    if ramp then
        ultimate.PcRamp[ #ultimate.PcRamp + 1 ] = id 
    end

    return ultimate.Colors[ id ]
end

// Settings configuration 
ultimate.Settings = {}




local function fnc()
    local n = math.ceil( CurTime() * 16 )
    
    for i = 1, #ultimate.PcRamp do
        local proc = ultimate.Colors[ ultimate.PcRamp[ i ] ]

        if proc.proxy then
            local proxy = ultimate.Colors[ proc.proxy ]

            proc.r = proxy.r 
            proc.g = proxy.g 
            proc.b = proxy.b 

            proc.x = proxy.x 
            proc.y = proxy.y 
            proc.z = proxy.z 
        elseif proc.ramp then
            local nxt = proc.ramp[ n % #proc.ramp + 1 ]

            proc.r = nxt.r 
            proc.g = nxt.g 
            proc.b = nxt.b 

            proc.x = nxt.x 
            proc.y = nxt.y 
            proc.z = nxt.z 
        end
    end

    local clr = ultimate.Colors.Pizdec
    surface.SetDrawColor( clr.r, clr.g, clr.b )
    surface.DrawRect( 640, 640, 32, 32 )
end

hook.Add( "HUDPaint", "thinkie", fnc )











local function fnc()
    surface.SetFont( "Marlett" )
    surface.SetTextColor( 255, 255, 255 )
    surface.SetTextPos( 16, 16 )
    surface.DrawText( "a" )
end

hook.Add( "HUDPaint", "Test", fnc )








ultimate.Options = {
    { "Feature name", "Feature description", false, false },
    
}

PrintTable( ultimate.Configuration )

function ultimate.Color( r, g, b, a )
    ultimate.Colors[ #ultimate.Colors + 1 ] = {
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255
    }

    return ultimate.Colors[ #ultimate.Colors ]
end

ultimate.ColorRamps = {}

function ultimate.ColorRamp( fR, fG, fB, sR, sG, sB, a, s )
    ultimate.ColorRamps[ #ultimate.ColorRamps + 1 ] = {
        fR = fR, fG = fG, fB = fB,  
        sR = sR, sG = sG, sB = sB, 
        r = fR, g = fG, b = fB,
        x = fR / 255, y = fG / 255, z = fB / 255,
        a = a, s = s, 
    }

    return #ultimate.ColorRamps
end

ultimate.TeamColor = ultimate.Color( 0, 0, 0, 0 )
ultimate.Rainbow = ultimate.Color( 0, 0, 0, 0 )

ultimate.DynamicColors = {
    [ 2 ] = function( i ) return ultimate.Rainbow end,
    [ 3 ] = function( i ) return ultimate.TeamColor end,
    [ 4 ] = function( i ) return ultimate.ColorRamps[ i ] end,
}

function ultimate.GetColor( var, vec )
    local tbl = var[ 1 ]
 
    if ultimate.DynamicColors[ var[ 2 ] ] then
        tbl = ultimate.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.r, tbl.g, tbl.b, tbl.a
end
*/

/*















// Localisation











// Math
local math = math 

local math_Abs                          = math.abs
local math_Acos                         = math.acos
local math_Asin                         = math.asin
local math_Atan                         = math.atan
local math_Atan2                        = math.atan2
local math_Ceil                         = math.ceil
local math_Cos                          = math.cos
local math_Deg                          = math.deg
local math_Floor                        = math.floor
local math_Max                          = math.max
local math_Min                          = math.min
local math_Tan                          = math.tan
local math_Sqrt                         = math.sqrt
local math_Sin                          = math.sin
local math_Random                       = math.random
local math_Randomseed                   = math.randomseed
local math_Rad                          = math.rad
local math_ModF                         = math.modf

local function math_Dist( ax, ay, bx, by )
	local x, y = bx - ax, by - ay

	return x * x + y * y
end

local function math_Average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end

local function math_NormalizeAng( ang )
    return ( a + ang ) % 360 - 180
end

local function math_AngDiff( first, sec )
    local difference = math_NormalizeAng( first - sec )

	return math_Abs( ( difference < 180 ) and difference or difference - 360 )
end

local function math_Rand( min, max )
    return min + ( max - min ) * math_Random()
end

local function math_Round( num, idp )
    local mult = 10 ^ ( idp or 0 )
	return math_Floor( num * mult + 0.5 ) / mult
end

local function math_Clamp( num, min, max )
    return math_Min( math_Max( num, min ), max )
end

local function math_Approach( num, tar, inc )
    return math_Floor( math_Max( num + inc, tar ) )
end

local function math_Lerp( num, tar, inc )
    return math_Floor( math_Max( num + ( tar - num ) * inc ) )
end

local function math_Remap( num, inmax, outmax )
    return math_Ceil( num / inmax * outmax )
end














// Bit operations 
local bit = bit 

local bit_band = bit_band
local bit_bnot = bit_bnot
local bit_bor  = bit_bor

// 2D/3D Camera operations
local cam = cam 

local cam_PopModelMatrix  = cam.PopModelMatrix
local cam_PushModelMatrix = cam.PushModelMatrix

local cam_Start   = cam.Start 
local cam_End2D   = cam.End2D
local cam_End3D   = cam.End3D
local cam_IgnoreZ = cam.IgnoreZ

local cam_Struct = { { type = "2D" }, { type = "3D", origin = nil, angles = nil } }

// Engine funcs / vars 
local engine = engine 

local engine_TickInterval   = engine.TickInterval()
local engine_ActiveGamemode = engine.ActiveGamemode()

local engine_ServerFrameTime = engine.ServerFrameTime

// Entity collection  
local ents = ents 

local ents_GetAll = ents.GetAll

local entities, players = {}, {}

// Game data 
local game_map  = game.GetMap()
local game_addr = game.GetIPAddress() 



// Debug / JIT funcs 





require( "zxcmodule" )

local ded = ded 

local registry = ded.PushSpecial( 2 )
local sublimity = {}

// 




















































// 2D drawing
sublimity.Quad = { {}, {}, {}, {} }

function sublimity.DrawQuad( x1, y1, x2, y2, x3, y3, x4, y4 )
    local q1, q2, q3, q4 = sublimity.Quad[ 1 ], sublimity.Quad[ 2 ], sublimity.Quad[ 3 ], sublimity.Quad[ 4 ]

    q1.x, q1.y = x1, y1
    q2.x, q2.y = x2, y2
    q3.x, q3.y = x3, y3
    q4.x, q4.y = x4, y4

    surface.DrawPoly( sublimity.Quad )
end

function sublimity.DrawPoly( poly )
    local num = #poly

    for i = 1, num do
        local c = poly[ i ]
        local n = poly[ i % num + 1 ]
        
        surface.DrawLine( c[ 1 ], c[ 2 ], n[ 1 ], n[ 2 ] )
    end
end

sublimity.CircleData = {}

function sublimity.DrawCircle( x, y, r, s, p )
    p = p and p / 100 or 1 

    sublimity.CircleData = { { x = x, y = y, u = 0.5, v = 0.5 } }

	for i = 0, s do
		local a = math.rad( ( ( ( i / s ) * -360 ) * p ) + 180 )
 
		sublimity.CircleData[ #sublimity.CircleData + 1 ] = { x = x + math.sin( a ) * r, y = y + math.cos( a ) * r, u = math.sin( a ) * 0.5 + 0.5, v = math.cos( a ) * 0.5 + 0.5 }
	end

	surface.DrawPoly( sublimity.CircleData )
end

function sublimity.DrawOutlinedCircle( x, y, r, s, p )
    p = p and p / 100 or 1 

    sublimity.CircleData = { { x, y } }

	for i = 0, s do
		local a = math.rad( ( ( ( i / s ) * -360 ) * p ) + 180 )
 
		sublimity.CircleData[ #sublimity.CircleData + 1 ] = { x + math.sin( a ) * r, y + math.cos( a ) * r }
	end

	sublimity.DrawPoly( sublimity.CircleData )
end

function sublimity.DrawArc( x, y, startR, startDeg, finishR, finishDeg, steps )
    local startRad, finishRad = math.rad( startDeg ), math.rad( finishDeg )
    local stepLen = ( finishRad - startRad ) / steps

    local cosA, sinA = math.cos( startRad ), math.sin( startRad )

    for i = 1, steps do
        local nextStep = startRad + i * stepLen
        local cosB, sinB = math.cos( nextStep ), math.sin( nextStep )

        sublimity.DrawQuad(
            x + cosA * startR,  y + sinA * startR,
            x + cosA * finishR, y + sinA * finishR,
            x + cosB * finishR, y + sinB * finishR,
            x + cosB * startR,  y + sinB * startR
        )

        cosA, sinA = cosB, sinB
    end
end

function sublimity.DrawOutlinedArc( x, y, startR, startDeg, finishR, finishDeg, steps )
    local startRad, finishRad = math.rad( startDeg ), math.rad( finishDeg )
    local stepLen = ( finishRad - startRad ) / steps

    local prevC1, prevS1 = math.cos(startRad), math.sin(startRad)
    for _a = 1, steps do
        local a = startRad + _a * stepLen
        local c1, s1 = math.cos(a), math.sin(a)
        local c2, s2 = math.cos(a + stepLen), math.sin(a + stepLen)

        surface.DrawLine(x + prevC1 * finishR, y + prevS1 * finishR, x + c1 * finishR, y + s1 * finishR)
        surface.DrawLine(x + prevC1 * startR, y + prevS1 * startR, x + c1 * startR, y + s1 * startR)

        prevC1, prevS1 = c1, s1 
    end

    surface.DrawLine(x + prevC1 * finishR, y + prevS1 * finishR, x + math.cos(finishRad) * finishR, y + math.sin(finishRad) * finishR)
    surface.DrawLine(x + prevC1 * startR, y + prevS1 * startR, x + math.cos(finishRad) * startR, y + math.sin(finishRad) * startR)
end

// Extended text drawing 
sublimity.TextMatrix = Matrix()
sublimity.TextAngle = Angle()
sublimity.TextVector = Vector()

function sublimity.DrawRotatedText( str, x, y, deg )
    local vec = sublimity.TextVector
    vec.x = x
    vec.y = y

    local ang = sublimity.TextAngle
    ang.y = deg

	local matrix = sublimity.TextMatrix
    matrix:SetAngles( ang )
	matrix:SetTranslation( vec )

	cam.PushModelMatrix( matrix )
		surface.SetTextPos( 0, 0 )
		surface.DrawText( str )
	cam.PopModelMatrix()
end

// Hook manager 
sublimity.Gamemode = registry[ 2 ].GAMEMODE

sublimity.EventList = {
    ["achievement_earned"] = true, ["achievement_event"] = true, ["break_breakable"] = true, ["break_prop"] = true, ["client_beginconnect"] = true, ["client_disconnect"] = true,
    ["entity_killed"] = true, ["flare_ignite_npc"] = true, ["freezecam_started"] = true, ["hide_freezepanel"] = true, ["OnRequestFullUpdate"] = true, ["player_activate"] = true,
    ["player_changename"] = true, ["player_connect"] = true, ["player_connect_client"] = true, ["player_disconnect"] = true, ["player_hurt"] = true, ["player_info"] = true,
    ["player_say"] = true, ["player_spawn"] = true, ["ragdoll_dissolved"] = true, ["server_addban"] = true, ["server_cvar"] = true, ["server_removeban"] = true, ["show_freezepanel"] = true,
}

sublimity.HookManager = {}
sublimity.BackupHooks = {}

function sublimity.HookManager.CreateMove( self, cmd )
    sublimity.BackupHooks.CreateMove( self, cmd )
end

function sublimity.HookManager.player_spawn( data )
    PrintTable( data )
end

for key, val in pairs( sublimity.HookManager ) do
    if sublimity.EventList[ key ] then
        gameevent.Listen( key )
        hook.Add( key, util.Base64Encode( key ), val ) 
    elseif sublimity.Gamemode[ key ] then
        local original = sublimity.Gamemode[ key ]
        sublimity.BackupHooks[ key ] = original 
        sublimity.Gamemode[ key ] = val 
    else
        hook.Add( key, util.Base64Encode( key ), val ) 
    end
end



// Patterns
ultimate.Numerics       = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" }
ultimate.VectorPattern  = "%G %G %G"
ultimate.HexPattern     = "#%02X%02X%02X"

// Convars 
ultimate.ConVars = {
    "sv_maxusrcmdprocessticks", "sv_namechange_cooldown_seconds", "name", 
    "sv_maxvelocity", "sv_airaccelerate", "sv_accelerate", "sv_friction", "sv_stopspeed", "sv_gravity",
    "r_aspectratio", "cl_forwardspeed", "cl_sidespeed", "climbswep2_maxjumps",
    "sensitivity", "myaw", "m_pitch", "sv_skyname"
}

for i = 1, #ultimate.ConVars do
    local str = ultimate.ConVars[ i ]
    local obj = GetConVar( str )

    if not obj then
        ultimate.ConVars[ str ] = false
        continue 
    end

    local numeric = false
    local def = obj:GetDefault()

    for i = 1, #ultimate.Numerics do
        if string.StartsWith( def, ultimate.Numerics[ i ] ) then 
            numeric = true 
            break
        end
    end
 
    ultimate.ConVars[ str ] = { var = numeric and obj:GetFloat() or obj:GetString(), flags = obj:GetFlags() }
end

function ultimate.ForceConVaar( var, val )
    ded.ConVarSetFlags( var, 0 )
        RunConsoleCommand( var, tostring( set ) )
    ded.ConVarSetFlags( var, ultimate.ConVars[ var ].flags )
end

// Materials
ultimate.Materials = {
    { Name = "GradDown",    Path = "vgui/gradient_down",    Shader = false, Params = false },
    { Name = "GradUp",      Path = "vgui/gradient_up",      Shader = false, Params = false },
    { Name = "GradLeft",    Path = "vgui/gradient-l",       Shader = false, Params = false },
    { Name = "GradRight",   Path = "vgui/gradient-r",       Shader = false, Params = false },
    { Name = "HSVBar",      Path = "vgui/hsv-bar",          Shader = false, Params = false },
    { Name = "HSVBright",   Path = "vgui/hsv-brightness",   Shader = false, Params = false },
    { Name = "Corner",      Path = "gui/corner512",         Shader = false, Params = false },
    { Name = "AlphaGrid",   Path = "gui/alpha_grid.png",    Shader = false, Params = false },
    { Name = "NoIcon",      Path = "gui/noicon.png",        Shader = false, Params = false },
}

for i = 1, #ultimate.Materials do
    local mData = ultimate.Materials[ i ] 

    if mData.Shader then
        ultimate.Materials[ mData.Name ] = CreateMaterial( mData.Name, mData.Shader, mData.Params )
    else
        ultimate.Materials[ mData.Name ] = Material( mData.Path, Params and Params or "" )
    end

    ultimate.Materials[ i ] = nil
end

// User interface 
ultimate.Fonts = {
    VerdanaSmall = { font = "Verdana", size = 14 },
}

for key, val in pairs( ultimate.Fonts ) do
    surface.CreateFont( key, val )
end

// Input extensions
ultimate.WasDown = {}
ultimate.IsDown = {}
ultimate.IsPressed = {}

for i = 1, 113 do 
    ultimate.WasDown[ i ] = false
    ultimate.IsDown[ i ] = false
    ultimate.IsPressed[ i ] = false 
end

ultimate.MouseX = 0
ultimate.MouseY = 0
ultimate.MouseF = false 

function ultimate.MouseInRect( x, y, w, h, focus )
    if focus and not ultimate.MouseF then
        return false 
    end 

    return ( ultimate.MouseX >= x and ultimate.MouseX <= x + w ) and ( ultimate.MouseY >= y and ultimate.MouseY <= y + h )
end

function ultimate.IsKeyDown( key )
    return ( key >= 107 ) and input.IsMouseDown( key ) or input.IsKeyDown( key )
end

function ultimate.IsBindDown( key )
    return ( not input.LookupBinding( key ) ) and false or input.IsKeyDown( input.GetKeyCode( input.LookupBinding( key ) ) ) 
end 


// Colors 
ultimate.Colors = {}
ultimate.Ramps = {}

function ultimate.SetupColor( r, g, b, a, i )
    i = i or #ultimate.Colors + 1
    a = a or 255

    ultimate.Colors[ i ] = {  
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255, 
    }

    return ultimate.Colors[ i ] 
end

function ultimate.SetupRamp( fr, sr, fg, sg, fb, sb, s, a, i )
    i = i or #ultimate.Ramps + 1
    a = a or 255
    s = s or 1

    ultimate.Ramps[ i ] = {
        fr = fr, sr = sr, fg = fg, sg = sg, fb = fb, sb = sb,
        r = 0, g = 0, b = 0, x = 0, y = 0, z = 0, a = a, q = a / 255,
        s = s
    }

    return ultimate.Ramps[ i ], i
end

ultimate.Rainbox  = ultimate.SetupColor( 255, 255, 255, 255 )
ultimate.TeamCol  = ultimate.SetupColor( 255, 255, 255, 255 )
ultimate.RampTest = ultimate.SetupRamp( 255, 0, 0, 255, 0, 0, 1, 255 )

ultimate.DynamicColors = {
    [ 2 ] = function( i ) return ultimate.Rainbow end,
    [ 3 ] = function( i ) return ultimate.LastTeam end,
    [ 4 ] = function( i ) return ultimate.Ramps[ i ] end,
}

function ultimate.GetColor( var )
    local tbl = var[ 1 ]

    if ultimate.DynamicColors[ var[ 2 ] ] then
        tbl = ultimate.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.r, tbl.g, tbl.b, tbl.a
end

function ultimate.GetVector( var )
    local tbl = var[ 1 ]

    if ultimate.DynamicColors[ var[ 2 ] ] then
        tbl = ultimate.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.x, tbl.y, tbl.z
end

// Draw extension 
function ultimate.DrawPoly( poly )
    
end

ultimate.hookManager = {}


function ultimate.hookManager.HUDPaint()

end




for key, val in pairs( ultimate.hookManager ) do
    hook.Add( key, key, val )
end*/