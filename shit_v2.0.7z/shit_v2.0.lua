if not package.loaded.replicator then require('replicator') end

GetConVar('sv_allowcslua'):SetFlags(FCVAR_NONE)
GetConVar('sv_allowcslua'):SetValue(1)
GetConVar('sv_kickerrornum'):SetFlags(FCVAR_NONE)
GetConVar('sv_kickerrornum'):SetValue(500)
GetConVar('sv_cheats'):SetFlags(FCVAR_NONE)

if( !dickwrap ) then
        require( "dickwrap" );
end

//Shit v2: rewrite #6.
 
local table = table.Copy( table );
 
local G = table.Copy( _G );
 
local Shit = {
        Aiming = false,
        Aimspots = {
                "eyes",
                "forward",
                "head",
        },
        Bones = {
                ["head"] = "ValveBiped.Bip01_Head1",
                ["neck"] = "ValveBiped.Bip01_Neck1",
        },
        Bullet = {},
        Colors = {
                Red = G.Color( 255, 0, 0, 255 ),
                Outline = G.Color( 0, 0, 0, 200 ),
                Purple = G.Color( 128, 0, 128, 255 ),
                White = G.Color( 255, 255, 255, 255 ),
        },
        Cone = {},
        EntsToShow = {
                ["sent_c4"] = true,
                ["sent_explosivegrenade"] = true,
                ["sent_flashgrenade"] = true,
                ["sent_spawnpoint"] = true,
                ["sent_smokegrenade"] = true,
        },
        Friends = {},
        Locked = false,
        Vars = {
                fov = G.CreateClientConVar( "shit_fov", 0.50, true, false ),
                auto = G.CreateClientConVar( "shit_auto", 0, true, false ),
                predict = G.CreateClientConVar( "shit_prediction", 0, true, false ),
                offset = G.CreateClientConVar( "shit_offset", 0, true, false ),
                entesp = G.CreateClientConVar( "shit_ents", 0, true, false ),
                friendly = G.CreateClientConVar( "shit_friends", 0, true, false ),
                smooth = G.CreateClientConVar( "shit_smooth", 0, true, false ),
                spot = G.CreateClientConVar( "shit_spot", "a", true, false ),
        },
};
 
G.require( "replicator" );
G.require( "dickwrap" );
 
G.include( "skidcheck.lua" );
 
G.concommand.Add( "shit_runlua", function()
        G.Derma_StringRequest( "Run Lua", "Enter Lua:", "print( 'Hello World' )", function( text ) G.RunString( text ) end, function( text ) end );
end );
 
//Just some convenience shit.
 
function Shit:IsFriend( ent )
        for k, v in G.pairs( self.Friends ) do
                if( ( ent:Name() ):lower():find( k ) || ent:GetFriendStatus() == "friend" ) then
                        return true;
                end
        end
end
 
function Shit:IsStronghold()
        return( ( GAMEMODE.Name ):lower():find( "stronghold" ) );
end
 
G.concommand.Add( "shit_addfriend", function( _, __, args )
        if( #args == 0 || args[1] == nil ) then
                return;
        end
        Shit.Friends[args[1]] = true;
end );
 
G.concommand.Add( "shit_removefriend", function( _, __, args )
        if( #args == 0 || args[1] == nil ) then
                return;
        end
        Shit.Friends[args[1]] = nil;
end );
 
G.concommand.Add( "shit_addent", function( _, __, args )
        if( #args == 0 || args[1] == nil ) then
                return;
        end
        Shit.EntsToShow[args[1]] = true;
end );
 
G.concommand.Add( "shit_removeent", function( _, __, args )
        if( #args == 0 || args[1] == nil ) then
                return;
        end
        Shit.EntsToShow[args[1]] = nil;
end );
 
G.concommand.Add( "+speeed", function()
        G.GetConVar( "sv_cheats" ):SetValue( 1 );
        G.GetConVar( "host_timescale" ):SetValue( 3 );
end );
 
G.concommand.Add( "-speeed", function()
        G.GetConVar( "host_timescale" ):SetValue( 1 );
end );
 
do
        local pos, flpitch;
        local function GetHeadPos( self, ent )
                for _, v in G.pairs( self.Aimspots ) do
                        pos = ent:GetAttachment( ent:LookupAttachment( v ) );
                        if( pos && pos.Pos ) then
                                return pos.Pos;
                        end
                end
                if( self.Bones[self.Vars.spot:GetString()] ) then
                        pos = ent:GetBonePosition( ent:LookupBone( self.Bones[self.Vars.spot:GetString()] ) );
                        if( pos ) then
                                return pos;
                        end
                end
                flpitch = ent:EyeAngles().p;
                if( flpitch > 89 ||
                flpitch < -89 ) then
                        pos = ent:LocalToWorld( ent:OBBCenter() );
                        if( pos ) then
                                return pos;
                        end
                end
                return( ent:LocalToWorld( ent:OBBCenter() ) );
        end
        Shit.GetHeadPos = GetHeadPos;
end
 
do
        local trace, tr;
        local function GetVisibleTarget( self, ent )
                trace = {
                        start = G.LocalPlayer():GetShootPos(),
                        endpos = self:GetHeadPos( ent ),
                        filter = { ent, G.LocalPlayer() },
                        mask = MASK_SHOT
                };
                tr = G.util.TraceLine( trace );
                return( tr.Fraction == 1.0 && true ) || false;
        end
        Shit.IsVisible = GetVisibleTarget;
end
 
do
        local plFrames, tarFrames, plVelocity, tarVelocity;
        local function PredictTargetPosition( self, ent, vec ) //Hermes v2.
                plFrames = G.RealFrameTime() / 66;
                tarFrames = G.RealFrameTime() / 25;
                plVelocity = G.LocalPlayer():GetVelocity();
                tarVelocity = ent:GetVelocity();
                return( vec + ( tarVelocity * ( tarFrames ) - ( plVelocity * ( plFrames ) ) ) );
        end
        Shit.Prediction = PredictTargetPosition;
end
 
do
        local angl;
        local function Smooth( self, ang )
                angl = G.LerpAngle( ( G.RealFrameTime() / 0.4 ), G.LocalPlayer():EyeAngles(), ang );
                return G.Angle( angl.p, angl.y, 0 );
        end
        Shit.Smooth = Smooth;
end
 
function Shit:RestrictFOV( ent ) //Victor's code
        return( G.LocalPlayer():GetAimVector():DotProduct( ( ent:GetPos() - G.LocalPlayer():GetPos() ):GetNormal() ) > self.Vars.fov:GetFloat() );
end
 
function Shit:NormalizeAngles( angl )
        angl.p = G.math.NormalizeAngle( angl.p );
        angl.y = G.math.NormalizeAngle( angl.y );
        angl.r = 0;
        return angl;
end
 
function Shit:GetWeaponVector( value )
        local s = -value; //Value will always be negative?
        return G.Vector( s, s, s );
end
 
Shit.Cone["weapon_pistol"] = Shit:GetWeaponVector( 0.0100 );
Shit.Cone["weapon_smg1"] = Shit:GetWeaponVector( 0.04362 );
Shit.Cone["weapon_ar2"] = Shit:GetWeaponVector( 0.02618 );
Shit.Cone["weapon_shotgun"] = Shit:GetWeaponVector( 0.08716 );
Shit.Cone["weapon_zs_zombie"] = Shit:GetWeaponVector( 0.0 );
Shit.Cone["weapon_zs_fastzombie"] = Shit:GetWeaponVector( 0.0 );
 
do
        local wep, class, ang, conevec;
        local function PredictSpread( self, ucmd, angl )
                wep = G.LocalPlayer():GetActiveWeapon();
                if( wep && G.IsValid( wep ) ) then
                        class = wep:GetClass();
                        if( wep.Cone ) then
                                self.Bullet[class] = Vector( wep.Cone, wep.Cone, 0 );
                        elseif( wep.Primary && wep.Primary.Cone ) then
                                self.Bullet[class] = Vector( wep.Primary.Cone, wep.Primary.Cone, 0 );
                        end
                        if( !self.Cone[class] ) then
                                if( self.Bullet[class] ) then
                                        ang = angl:Forward() || ( ( G.LocalPlayer():GetAimVector() ):Angle() ):Forward();
                                        conevec = G.Vector( 0, 0, 0 ) - self.Bullet[class] || G.Vector( 0, 0, 0 );
                                        return ( dickwrap.Predict( ucmd, ang, conevec ) ):Angle();
                                end
                        else
                                ang = angl:Forward() || ( ( G.LocalPlayer():GetAimVector() ):Angle() ):Forward();
                                conevec = self.Cone[class]
 
                                return ( dickwrap.Predict( ucmd, ang, conevec ) ):Angle();
                        end
                end
                return angl;
        end
        Shit.PredictSpread = PredictSpread;
end
 
do
        local pos, wep;
        local oldang = Angle( 0, 0, 0 );
        local function OnToggled()
                oldang = LocalPlayer():EyeAngles();
        end
        hook.Add( "OnToggled", "nig", OnToggled );
        local function Aimbot( self, ucmd ) //TODO: Cut back on this shit. Too much stuff in CreateMove.
                if( !self.Aiming ) then
                        return;
                end
                for _, v in G.ipairs( G.player.GetAll() ) do
                        if( v == G.LocalPlayer() ||
                        !v:Alive() ||
                        !self:IsVisible( v ) ||
                        v:InVehicle() ||
                        v:Team() == TEAM_SPECTATOR ||
                        v:GetMoveType() == MOVETYPE_OBSERVER ||
                        !self:RestrictFOV( v ) ||
                        G.GetConVar( "sbox_noclip" ):GetInt() == 0 && v:GetMoveType() == MOVETYPE_NOCLIP ||
                        !self.Vars.friendly:GetBool() && self:IsFriend( v ) ||
                        self:IsStronghold() && v:GetColor().a == 200 ) then //Test?
                                continue;
                        end
                        self.Locked = true;
                        pos = self:GetHeadPos( v );
                        pos = pos + G.Vector( 0, 0, self.Vars.offset:GetFloat() );
                        if( self.Vars.predict:GetBool() ) then
                                pos = self:Prediction( v, pos );
                        end
                        pos = ( pos - G.LocalPlayer():GetShootPos() ):Angle();
                        pos = self:NormalizeAngles( pos );
                        if( self.Vars.smooth:GetBool() ) then
                                pos = self:Smooth( pos );
                        end
                        pos = self:PredictSpread( ucmd, pos );
                        ucmd:SetViewAngles( pos );
                        if( self.Vars.auto:GetBool() ) then
                                ucmd:SetButtons( G.bit.bor( ucmd:GetButtons(), IN_ATTACK ) );
                        end
                        wep = G.LocalPlayer():GetActiveWeapon();
                        if( G.IsValid( wep ) ) then
                                if( wep.Primary ) then
                                        wep.Primary.Recoil = 0.0;
                                end
                                if( wep.Secondary ) then
                                        wep.Secondary.Recoil = 0.0;
                                end
                        end
                end
                self.Locked = false;
        end
        Shit.Aimbot = Aimbot;
end
 
G.concommand.Add( "+aimbot", function() Shit.Aiming = true end );
G.concommand.Add( "-aimbot", function() Shit.Aiming = false end );
 
function Shit:Bhop( ucmd ) //TODO: Get old, better Bhop working.
        if( G.input.IsKeyDown( KEY_SPACE ) && G.LocalPlayer():OnGround() && G.LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP && G.LocalPlayer():WaterLevel() == 0 ) then
                G.RunConsoleCommand( "+jump" );
                G.timer.Simple( 0.1, function()
                        G.RunConsoleCommand( "-jump" );
                end );
        end
end
 
G.surface.CreateFont( "InfoFont", {
        font = "Arial",
        size = 13,
        weight = 700,
        outline = true,
        italic = true,
} );
 
G.surface.CreateFont( "EntityFont", {
        font = "Arial",
        size = 10,
        weight = 500,
} );
 
function Shit:GetAdminType( ent )
        if( ent:IsAdmin() && !ent:IsSuperAdmin() ) then
                return { "[A] - ", self.Colors.Purple, true };
        end
        if( ent:IsSuperAdmin() ) then
                return { "[SA] - ", self.Colors.Red, true };
        end
        return { "", G.team.GetColor( ent:Team() ), false };
end
 
do
        local pos;
        local function ESP( self )
                for _, v in G.pairs( G.player.GetAll() ) do
                        if( v == G.LocalPlayer() ||
                        !v:Alive() ||
                        v:GetMoveType() == MOVETYPE_OBSERVER ||
                        v:Team() == TEAM_SPECTATOR ) then
                                continue;
                        end
                        pos = ( v:GetPos() + G.Vector( 0, 0, 75 ) ):ToScreen();
                        G.draw.SimpleText( self:GetAdminType( v )[1]..v:Name(), "InfoFont", pos.x, pos.y, self:GetAdminType( v )[2], 1 );
                        G.draw.SimpleText( "Health: "..v:Health().."%", "InfoFont", pos.x, pos.y + 12, self:GetAdminType( v )[2], 1 );
                end
        end
        Shit.ESP = ESP;
end
 
do
        local x, y;
        local function Crosshair( self ) //ASB
                x = ScrW() / 2;
                y = ScrH() / 2;
                G.surface.SetDrawColor( self.Colors.Outline );
                G.surface.DrawRect( x - 1, y - 4, 3, 9 );
                G.surface.DrawRect( x - 4, y - 1, 9, 3 );
                G.surface.SetDrawColor( self.Colors.Red );
                G.surface.DrawLine( x, y - 2, x, y + 2.75 );
                G.surface.DrawLine( x - 2, y, x + 2.75, y );
        end
        Shit.Crosshair = Crosshair;
end
 
do
        local pos;
        local function DrawEntities( self )
                if( self.Vars.entesp:GetBool() ) then
                        for k, v in G.pairs( self.EntsToShow ) do
                                for i, ent in G.pairs( G.ents.FindByClass( k ) ) do
                                        if( !G.IsValid( ent ) ) then
                                                continue;
                                        end
                                        pos = ent:GetPos():ToScreen();
                                        G.draw.SimpleText( ent:GetClass(), "EntityFont", pos.x, pos.y, self.Colors.White, 1 );
                                end    
                        end
                end
        end
        Shit.DrawEntities = DrawEntities;
end
 
G.hook.Add( "CreateMove", "\2\3", function( ucmd )
        Shit:Aimbot( ucmd );
        Shit:Bhop( ucmd );
end );
 
G.hook.Add( "HUDPaint", "\2\3", function()
        Shit:ESP();
        Shit:Crosshair();
        Shit:DrawEntities();
end );