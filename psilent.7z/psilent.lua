local ply = LocalPlayer()

local aimbotcvar = CreateClientConVar( "psilent_aimbot", 1, true, false )
local crosshaircvar = CreateClientConVar( "psilent_crosshair", 1, true, false )
local fovcirclecvar = CreateClientConVar( "psilent_fovcircle", 1, true, false )
local fovcircleopacity = CreateClientConVar( "psilent_fovcircle_opacity", 50, true, false )

local aimkey = CreateClientConVar( "psilent_aimkey", 0, true, false )
local aimfov = CreateClientConVar( "psilent_fov", 2, true, false )

local function getpos( v )

	if ( v:GetAttachment( v:LookupAttachment( "eyes" ) ) ) then
	
		return ( v:GetAttachment( v:LookupAttachment( "eyes" ) ).Pos )
	
	end
	
	return v:LocalToWorld( v:OBBCenter() )

end

local function isvisible( v )

	local tr = {
	
		start = ply:GetShootPos(),
		endpos = getpos( v ),
		filter = { ply, v },
		mask = MASK_SHOT
	
	}
	
	return ( util.TraceLine( tr ).Fraction == 1 )

end

local midx, midy = ScrW() / 2, ScrH() / 2

local function dist( pos )

	local spos = pos:ToScreen()

	return ( math.Distance( spos.x, spos.y, midx, midy ) )

end

local function gettarget()

	local _players = player.GetAll()
	
	table.sort( _players, function( a, b )

		return ( dist( getpos( a ) ) < dist( getpos( b ) ) )

	end )
	
	for k, v in pairs( _players ) do
	
		if ( v == ply or v:IsDormant() or v:Health() <= 0 or !v:Alive() or !isvisible( v ) ) then continue end
		--if ( dist( getpos( v ) ) > 60 ) then continue end
		
		local ang = ( getpos( v ) - ply:GetShootPos() ):Angle()
		local angdiffy = math.abs( math.NormalizeAngle( ply:EyeAngles().y - ang.y ) )
		local angdiffp = math.abs( math.NormalizeAngle( ply:EyeAngles().p - ang.p ) )
		if ( angdiffy > aimfov:GetInt() or angdiffp > aimfov:GetInt() ) then continue end
		
		return v
	
	end

end

local function aimbot( cmd )

	if ( !aimbotcvar:GetBool() or cmd:CommandNumber() == 0 ) then return end

	local target = gettarget()
	if ( target == nil ) then return end
	
	local ang = ( getpos( target ) - ply:GetShootPos() ):Angle()
	ang:Normalize()
	
	if ( !input.IsKeyDown( KEY_F ) and aimkey:GetBool() ) then return end
	
	if ( cmd:KeyDown( IN_ATTACK ) ) then
		
		cmd:SetViewAngles( ang )
		
	end

end

local fakeview = ply:EyeAngles()

local function fixmovement( cmd, old, aaaaa )
	
	local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local speed = math.sqrt( move.x * move.x + move.y * move.y )
	local ang = move:Angle()
	local yaw = math.rad( cmd:GetViewAngles().y - old.y + ang.y )
	
	cmd:SetForwardMove( ( math.cos( yaw ) * speed ) * ( aaaaa and -1 or 1 ) )
	cmd:SetSideMove( math.sin( yaw ) * speed )
	
end

local function fakeangle( cmd )

	fakeview = ( fakeview + Angle( cmd:GetMouseY() * 0.022, cmd:GetMouseX() * -0.022, 0 ) )
	fakeview:Normalize()
	fakeview.x = math.Clamp( fakeview.x, -89, 89 )
	
	cmd:SetViewAngles( fakeview )
	
	if ( cmd:CommandNumber() == 0 ) then return end
	
	local oview = cmd:GetViewAngles()
	
	aimbot( cmd )
	
	local x = cmd:GetViewAngles().p
	
	fixmovement( cmd, oview, x > 89 and true or x < -89 and true or false )

end

local function createmove( cmd )

	aimbot( cmd )
	fakeangle( cmd )

end

hook.Add( "CreateMove", "createmove", createmove )

local function crosshair()

	if ( !crosshaircvar:GetBool() ) then return end

	surface.SetDrawColor( 0, 0, 0 )
	
	surface.DrawLine( ScrW() / 2 - 6, ScrH() / 2 - 1, ScrW() / 2 + 7, ScrH() / 2 - 1 ) --top
	surface.DrawLine( ScrW() / 2 - 6, ScrH() / 2, ScrW() / 2 + 7, ScrH() / 2 ) -- middle
	surface.DrawLine( ScrW() / 2 - 6, ScrH() / 2 + 1, ScrW() / 2 + 7, ScrH() / 2 + 1 ) --bottom
	
	surface.DrawLine( ScrW() / 2 - 1, ScrH() / 2 + 6, ScrW() / 2 - 1, ScrH() / 2 - 6 ) --left
	surface.DrawLine( ScrW() / 2, ScrH() / 2 - 6, ScrW() / 2, ScrH() / 2 + 7 ) --middle
	surface.DrawLine( ScrW() / 2 + 1, ScrH() / 2 - 6, ScrW() / 2 + 1, ScrH() / 2 + 7 ) --right
	
	surface.SetDrawColor( 255, 255, 255 )
	surface.DrawLine( ScrW() / 2 - 5, ScrH() / 2, ScrW() / 2 + 6, ScrH() / 2 ) --horizontal
	surface.DrawLine( ScrW() / 2 , ScrH() / 2 - 5, ScrW() / 2, ScrH() / 2 + 6 ) --vertical
	
end

hook.Add( "HUDPaint", "crosshair", crosshair )

local function fovcircle()

	if ( !fovcirclecvar:GetBool() ) then return end
	
	surface.DrawCircle( midx, midy, aimfov:GetInt() * 13, Color( 255, 255, 255, fovcircleopacity:GetInt() ) )

end

hook.Add( "HUDPaint", "fovcircle", fovcircle )

local function calcview()

	return ( { angles = ply:EyeAngles() } )

end

hook.Add( "CalcView", "calcview", calcview )

MsgC( Color( 0, 255, 150 ), "[psilent] ", Color( 255, 255, 255 ), "loaded" )