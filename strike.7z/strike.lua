MsgC(Color(255, 255, 224), [[
    
                          _                   
                         | |                  
   __ _ _   _  __ _ _ __ | |_ _   _ _ __ ___  
  / _` | | | |/ _` | '_ \| __| | | | '_ ` _ \ 
 | (_| | |_| | (_| | | | | |_| |_| | | | | | |
  \__, |\__,_|\__,_|_| |_|\__|\__,_|_| |_| |_|
     | |                                      
     |_|                                      

]])

local G = table.Copy(_G)
local R = G.debug.getregistry()

local quantumglobal = (_G)
local quantum = {}

local p, w, h = G.LocalPlayer(), G.ScrW(), G.ScrH()

// UTILS //
quantum.util = {}

function quantum.util.msg(str)
    G.chat.AddText(G.Color(255,255,255), "[", G.Color(255, 255, 224), "quantum", G.Color(255,255,255), "] " .. str)
end

function quantum.util.randomstr(length)
    if !length then length = G.math.random(20,50) end 
    local str = ""

    for i = 1,length do 
        str = str .. G.string.char(G.math.random(32,126))
    end

    return str 
end

////////////

// FONT //

for i=12, 50 do
	G.surface.CreateFont( "ui."..i, { font = "Arial", size = i }) -- Because I'm too lazy to make single fonts
	G.surface.CreateFont( "uib."..i, { font = "Arial", size = i, weight = 1024 })
end

////////////

// CONVARS //

local convars = {
    {"aimbot"},
    {"aimbot_smooth"},
    {"aimbot_smoothval",50},
    {"aimbot_fov",1},
    {"aimbot_fovval",180},
    {"aimbot_onshot"},
    {"aimbot_recoil"},
    {"aimbot_spread"},
    {"aimbot_autofire"},
    {"aimbot_autofire_target"},

    {"aimbot_target", "fov"},
    {"aimbot_bot"},
    {"aimbot_staff"},
    {"aimbot_noclip"},
    {"aimbot_team"},
    {"aimbot_compensate"},
    {"aimbot_compensate_type", "automatic"},
    {"aimbot_nonsticky"},

}

for k,v in G.ipairs(convars) do  -- This creates our convars and adds them to the table in the format of: [name] = convar_object
    convars["quantum_" .. v[1]] = G.CreateClientConVar("quantum_" .. v[1], v[2] or 0)
end

function quantum.convar(string)
    return convars[string] -- This returns the convar object
end

require("dickwrap")
require("bsendpacket")
require("fhook")
require("ChatClear")

bSendPacket = true

quantumglobal.Predict = dickwrap.Predict
quantumglobal.Predict = _fhook_changename

quantum._fhook_changename = nil
quantum.dickwrap.Predict = nil

quantum.TickCount = 0

////////////

// MENU //
local menu = {}

menu.Menu = {
    {
        left = {
            {"checkbox","aimbot","quantum_aimbot", "master switch for the aimbot tab; without this on nothing will run"},
            {"checkbox","smooth","quantum_aimbot_smooth", "enables smoothing"},
            {"slider",0,100, "quantum_aimbot_smoothval", 0, "smooths the aimbot, makes it snap less"},
            {"checkbox","fov","quantum_aimbot_fov", "enables fov"},
            {"slider",0,180, "quantum_aimbot_fovval", 0, "only allows the aimbot to target if the player its targeting is inside a circle, this controls how big the circle is"},
            {"checkbox","onshot","quantum_aimbot_onshot", "only aims when your firing"},
            {"checkbox","compensate recoil","quantum_aimbot_recoil", "enables anti recoil"},
            {"checkbox","compensate spread","quantum_aimbot_spread", "enables anti spread"},
            {"checkbox","automaticly fire","quantum_aimbot_autofire", "automatically shoots for you"},
            {"checkbox","only on target","quantum_aimbot_autofire_target", "waits for you to be fully on the target before auto firing."},

        }, // left
        right = {
            {"dropbox", {"health","distance","ping","fov"}, "quantum_aimbot_target", "target system to use"},
            {"checkbox","ignore bot","quantum_aimbot_bot", "ignores bots (IsBot)"},
            {"checkbox","ignore staff","quantum_aimbot_staff", "ignores staff (IsAdmin)"},
            {"checkbox","ignore noclip","quantum_aimbot_noclip", "ignores noclip (Movetype)"},
            {"checkbox","ignore team","quantum_aimbot_team", "ignores team (GetTeam)"},
            {"checkbox","compensate lag","quantum_aimbot_compensate", "attempts to compensate for lag compensation"},
            {"dropbox", {"predictive", "trailing", "automatic", "minimal"}, "quantum_aimbot_compensate_type", "type of lag compensation to use (shouldn't use predictive above 90 ping)"},
            {"checkbox","unlock on target","quantum_aimbot_nonsticky", "somewhat like non stick, won't aim if your on target."},

        }, // right
    }, // aim 
    {
        left = {}, // left
        right = {}, // right
    }, // hvh
    {
        left = {}, // left
        right = {}, // right
    }, // wallhack
    {
        left = {}, // left
        right = {}, // right
    }, // misc
}

//                                                                    \\
//                                                                    \\
// IGNORE THIS, MOSTLY FOR MENU STUFF \\
//                                                                    \\
//                                                                    \\

menu.w =  w*.4
menu.h =   h*.6
menu.tab = 1

menu.MainFrame = G.vgui.Create( "DFrame" )
menu.MainFrame:DockPadding( 0, 0, 0, 0 )
menu.MainFrame:SetTitle( "" )
menu.MainFrame:MakePopup()
menu.MainFrame:SetKeyboardInputEnabled( false )
menu.MainFrame:SetDraggable( true )
menu.MainFrame:SetSize( menu.w, menu.h )
menu.MainFrame:Center()
menu.MainFrame:ShowCloseButton( false )
menu.MainFrame.Paint = function( s, w, h )
    G.draw.RoundedBox( 0, 0, 0, w, h, Color( 19, 22, 31 ) )
end

menu.MainPanel = G.vgui.Create( "DPanel", menu.MainFrame ) -- The outline around the main frame
menu.MainPanel:Dock( FILL )
menu.MainPanel:DockMargin( h*.005, h*.005, h*.005, h*.005 )
menu.MainPanel.Paint = function( s, w, h )
    G.draw.RoundedBox( 0, 0, 0, w, h, Color( 25, 25, 36 ) )
    G.surface.SetDrawColor( 3, 3, 3, 166 )
    G.surface.DrawOutlinedRect( 0, 0, w, h, 2 )

    G.draw.SimpleText( "Quantum © 2O22", "uib.16", 20, menu.h-25, Color( 255, 255, 224 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP ) 
end

local name = p:Name() or ""
local rank = p:GetUserGroup() or ""
menu.Navbar = G.vgui.Create( "DPanel", menu.MainPanel ) -- The line and the text
menu.Navbar:Dock( TOP )
menu.Navbar:DockMargin( h*.016, 0, h*.016, h*.01 )
menu.Navbar:SetTall( h*.05 )
menu.Navbar.Paint = function( s, w, h )
    G.surface.SetDrawColor( 255, 255, 224 )
    G.surface.DrawRect( 0, h-2, w, 2 )
    local x, y = 2, menu.h*.015
    local __, yy = G.draw.SimpleText( name, "uib.16", x, y, Color( 200, 200, 200 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
    y = y + yy
    local __, yy = G.draw.SimpleText( rank, "uib.16", x, y, Color( 255, 255, 224 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP ) -- placeholder
    y = y + yy
end

menu.DCategoryPages = vgui.Create( "DPanel", menu.Navbar )
menu.DCategoryPages:Dock( RIGHT )
menu.DCategoryPages:DockMargin( 0, menu.h*.005, menu.h*.005, menu.h*.005 )
menu.DCategoryPages:SetWide( menu.h*.41 )
menu.DCategoryPages.Paint = function( s, w, h )
    G.surface.SetDrawColor( 43, 42, 50 )
    G.surface.DrawRect( 0, 0, menu.h*.004, menu.h )
    G.surface.SetDrawColor( 18, 18, 24 )
    G.surface.DrawRect( 2, 0, menu.h*.01, menu.h )

    G.surface.SetDrawColor( 43, 42, 50 )
    G.surface.DrawRect( s:GetWide()-3, 0, menu.h*.004, menu.h )
    G.surface.SetDrawColor( 18, 18, 24 )
    G.surface.DrawRect( s:GetWide()-9, 0, menu.h*.01, menu.h )
end

for i=1, 4 do 
    local DButton = vgui.Create( "DButton", menu.DCategoryPages )
    DButton:Dock( LEFT )
    DButton:DockMargin( menu.h*.01, 0, 0, 0 )
    DButton:SetWide( menu.h*.09 )
    DButton:SetText( "" )
    DButton.Paint = function( s, w, h )
        if menu.tab == i or s:IsHovered() then
            draw.SimpleText( i, "uib.22", h*.5, h*.5, Color( 210, 210, 210 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        else
            draw.SimpleText( i, "uib.22", h*.5, h*.5, Color( 135, 135, 135 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
        end
    end
    DButton.DoClick = function()
        menu.tab = i
    
        menu.Update()
    end
end

function menu:AddCheckbox(panel, txt, autovalue, valuetochange, tooltip)
    local DCheckBoxLabel = vgui.Create( "DCheckBoxLabel", panel )
    DCheckBoxLabel:Dock( TOP )
    DCheckBoxLabel:DockMargin( menu.h*.02, menu.h*.02, 0, 0 )
    DCheckBoxLabel:SetTextColor( Color( 188, 188, 188 ) )
    DCheckBoxLabel:SetFont( "ui.14" )
    DCheckBoxLabel:SetText( txt )
    DCheckBoxLabel:SetValue( autovalue or 0 ) 
    DCheckBoxLabel:SetConVar( valuetochange or "gm_demo_icon" )
    DCheckBoxLabel:SetTooltip( tooltip or "" )
    DCheckBoxLabel:SizeToContents()
    DCheckBoxLabel.Button.Paint = function( s, w, h )
        draw.RoundedBox( 0, 2, 2, w - 5, h -5, Color( 35, 35, 44 ) )
        if s:GetChecked() then
            draw.RoundedBox( 0, 2, 2, w - 5, h -5, Color( 255, 255, 224 ) )
            if s:IsHovered() then
                draw.RoundedBox( 0, 2, 2, w - 5, h -5, Color( 200, 190, 222 ) )
            end
        end
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 2, 2, w - 5, h -5 )
    end
end

function menu:AddSlider( parent, min, max, convar, decimals, tooltip  )
    local DNumSlider = vgui.Create( "DNumSlider", parent )
    DNumSlider:Dock( TOP )
    DNumSlider:DockMargin( -menu.h*.182, menu.h*.02, menu.h*.2, 0 )
    DNumSlider:SetTall( 8 )
    DNumSlider:SetText( "" )
    DNumSlider:SetMin( min or 0 )
    DNumSlider:SetMax( max or 0 )
    DNumSlider:SetConVar( convar or "gm_demo_icon" )
    DNumSlider:SetTooltip(tooltip)
    DNumSlider:SetDecimals( decimals )
    // DNumSlider:SizeToContents()
    DNumSlider.Slider.Paint = function( s, w, h )
        max = max or 0
        surface.SetDrawColor( 14,14,14 )
        surface.DrawRect( 0, 0, w, h )
        surface.SetDrawColor(31,30, 38 )
        surface.DrawRect( 1, 1, w - 2, h - 2 )
        surface.SetDrawColor( 255, 255, 224 )
        surface.DrawRect( 1, 1, w * math.Clamp( GetConVar(convar):GetFloat() / max, 0, 1 ) - 2 , h - 2 )
        DisableClipping( true )
        draw.SimpleTextOutlined( math.Round( GetConVar(convar):GetFloat(), decimals ), "ui.14", w* math.Clamp( GetConVar(convar):GetFloat() / max, 0, 1 ) - 2, h / 2 + 5, color_white, 1, 1, 1, color_black )
        DisableClipping( false )
    end
    DNumSlider.Slider:GetChildren()[1].Paint = nil
    DNumSlider:GetChildren()[1].Paint = nil
end

function menu:AddDropbox(parent, choices, convar, tooltip)
    local DComboBox = vgui.Create( "DComboBox", parent )
    DComboBox:Dock( TOP )
    DComboBox:DockMargin( menu.h*.022, menu.h*.02, menu.h*.24, 0 )
    DComboBox:SetFont( "ui.14" )
    DComboBox:SetTextColor( Color( 255, 255, 255 ) )
    DComboBox:SetValue( GetConVar(convar):GetString() )
    DComboBox:SetConVar( convar )
    DComboBox:SetTooltip( tooltip )
    DComboBox:SizeToContents()
    
    for k,v in ipairs(choices) do 
        DComboBox:AddChoice(v)
    end

    DComboBox.OnSelect = function(self)
        self:SizeToContents()
    end
    DComboBox.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 35, 35, 44 ) )
        surface.SetDrawColor( 14, 14, 14 )
        surface.DrawRect( 0, 0, w, h )
        surface.SetDrawColor( 31,30, 38 )
        surface.DrawRect( 1, 1, w - 2, h - 2 )
    end
    DComboBox.OnMenuOpened = function( panel )
        panel:GetChildren()[2].Paint = function( s, w, h )
            draw.RoundedBox( 0, 0, 0, w, h, Color( 40, 40, 49 ) )
    
            if s:IsHovered() then
                draw.RoundedBox( 0, 0, 0, w, h, Color( 51, 51, 61 ) )
            end
        end
    end
end

function menu:Update()

    if menu.Populate then menu.Populate:Remove() end 

    menu.Populate = G.vgui.Create( "DPanel", menu.MainPanel )
    menu.Populate:Dock( TOP )
    menu.Populate:DockMargin( menu.h*.025, 0, menu.h*.025, 0 )
    menu.Populate:SetTall( menu.h*.86 )
    menu.Populate.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 17, 17, 25 ) )
    end
    
    local tabname = ""

    if menu.tab == 1 then 
        tabname = "aim"
    elseif menu.tab == 2 then 
        tabname = "antiaim"
    elseif menu.tab == 3 then
        tabname = "wallhack" 
    elseif menu.tab == 4 then
        tabname = "misc" 
    end

    // LEFT
    menu.LDPanel = G.vgui.Create( "DPanel", menu.Populate )
    
    menu.LDPanel.Paint = function( s, w, h )
        G.draw.RoundedBox( 6, 0, 0, w, h, Color( 23, 23, 31 ) )
        G.DisableClipping( true )
        G.draw.SimpleText( string.lower( tabname ), "ui.17", menu.h*.01, -menu.h*.03, Color( 125, 125, 125 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
        G.DisableClipping( false )
    end

    menu.LDPanel:Dock( LEFT )
    menu.LDPanel:DockMargin( menu.h*.036, menu.h*.045, 0, menu.h*.025 )
    menu.LDPanel:SetWide( menu.w*.428 )

    menu.LDScrollPanel = G.vgui.Create( "DScrollPanel", menu.LDPanel )
    menu.LDScrollPanel:Dock( FILL )

    for k,v in G.ipairs(menu.Menu[menu.tab].left) do 
        if v[1] == "checkbox" then 
            menu:AddCheckbox(menu.LDScrollPanel, v[2], GetConVar(v[3]):GetBool(), v[3], v[4] or false)
        elseif v[1] == "slider" then 
            menu:AddSlider(menu.LDScrollPanel, v[2], v[3], v[4], v[5] or 0, v[6])
        elseif v[1] == "dropbox" then 
            menu:AddDropbox(menu.LDScrollPanel, v[2], v[3], v[4])
        end
    end

    // RIGHT
    menu.RDPanel = G.vgui.Create( "DPanel", menu.Populate )
    
    menu.RDPanel.Paint = function( s, w, h )
        G.draw.RoundedBox( 6, 0, 0, w, h, Color( 23, 23, 31 ) )
        G.DisableClipping( true )
        G.draw.SimpleText( string.lower( "other" ), "ui.17", menu.h*.01, -menu.h*.03, Color( 125, 125, 125 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
        G.DisableClipping( false )
    end

    menu.RDPanel:Dock( RIGHT )
    menu.RDPanel:DockMargin( 0, menu.h*.045, menu.h*.036, menu.h*.025 )
    menu.RDPanel:SetWide( menu.w*.428 )

    menu.RDScrollPanel = G.vgui.Create( "DScrollPanel", menu.RDPanel )
    menu.RDScrollPanel:Dock( FILL )

    for k,v in G.ipairs(menu.Menu[menu.tab].right) do 
        if v[1] == "checkbox" then 
            menu:AddCheckbox(menu.RDScrollPanel, v[2], GetConVar(v[3]):GetBool(), v[3], v[4] or false)
        elseif v[1] == "slider" then 
            menu:AddSlider(menu.RDScrollPanel, v[2], v[3], v[4], v[5] or 0, v[6])
        elseif v[1] == "dropbox" then 
            menu:AddDropbox(menu.RDScrollPanel, v[2], v[3], v[4])
        end
    end
end

menu:Update()

local toggle = false
G.hook.Add( "Think", quantum.util.randomstr(), function()
    if G.input.IsKeyDown( KEY_INSERT ) and !toggle then
        toggle = true
        menu.MainFrame:SetVisible( !menu.MainFrame:IsVisible() )
        G.gui.EnableScreenClicker( menu.MainFrame:IsVisible() )
    elseif !G.input.IsKeyDown( KEY_INSERT ) then
        toggle = false
    end
end )

//////////////

// AIMBOT //

function quantum:CheckFOV( ply )
    if !quantum.convar("quantum_aimbot_fov"):GetBool() then return true end 

    local fov = quantum.convar("quantum_aimbot_fovval"):GetFloat()

    if fov == 180 then return true end 

    -- Basically, it gets the diffrence between the player postion on your screen and the middle of your screen
    -- Subtract the two of them and compare them to get your fov 

    local local_ang = p:EyeAngles()
    local ang = (ply:GetPos() - p:GetPos()):Angle() 
    local ady = G.math.abs(G.math.NormalizeAngle(local_ang.y - ang.y)) -- The diffrence on the Y cord
    local adp = G.math.abs(G.math.NormalizeAngle(local_ang.p - ang.p )) -- The diffrence on the X cord


    if(ady > fov or adp > fov) then return false end

    return true 
end

function quantum:CheckPlayer( ply )

    -- Just checking the things you want checked
    if quantum.convar("quantum_aimbot_bot"):GetBool() && ply:IsBot() then return false end 
    if quantum.convar("quantum_aimbot_staff"):GetBool() && ply:IsAdmin() then return false end 
    if quantum.convar("quantum_aimbot_noclip"):GetBool() && ply:GetMoveType() == MOVETYPE_NOCLIP then return false end 
    if quantum.convar("quantum_aimbot_team"):GetBool() && ply:Team() == p:Team() then return false end 
 
    -- Not customizable since it would break a lot of stuff if we allowed it
    if ply:IsDormant() || !ply:Alive() || ply:Health() <= 0 || ply == p then return false end 

    -- Check FOV
    if !quantum:CheckFOV(ply) then return false end 

    -- Players valid
    return true 
end

function quantum:GetTarget()
    local target_type = quantum.convar("quantum_aimbot_target"):GetString()

    local ply_table = {0,0}

    local me_info = {p:EyePos(),p:GetAimVector()}

    local x, y = G.ScrW(), G.ScrH()

    for k,v in G.pairs(G.player.GetAll()) do 
        if !quantum:CheckPlayer(v) then continue end 


        -- Don't ask.
        if target_type == "fov" then 

            local eyes = v:EyePos():ToScreen()
            local fov = G.math.Dist(x / 2, y / 2, eyes.x, eyes.y)

            if ply_table[1] > fov || ply_table[2] == 0 then 
                ply_table = {fov,v}
            end
        elseif target_type == "distance" then 
            local dif = (v:EyePos() - me_info[1])

            dif = dif - me_info[2]

            dif = G.math.abs(dif:Length())

            if ply_table[1] > dif || ply_table[2] == 0 then 
                ply_table = {dif,v}
            end
        elseif target_type == "ping" then 
            if ply_table[1] > v:Ping() || ply_table[2] == 0 then
                ply_table = {v:Ping(),v} 
            end
        elseif target_type == "health" then 
            if ply_table[1] > v:Health() || ply_table[2] == 0 then
                ply_table = {v:Health(),v} 
            end
        end
    end

    return ply_table[2]
end

function quantum:Autofire( cmd, ply )
    if quantum.convar("quantum_aimbot_autofire"):GetBool() then 
        local only_target = quantum.convar("quantum_aimbot_autofire_target"):GetBool()
        if !only_target || only_target && G.util.TraceLine( G.util.GetPlayerTrace( p ) ).Entity == ply then 
            if p:KeyDown(IN_ATTACK) then -- More accurate and works better with pistols
                cmd:RemoveKey(IN_ATTACK) -- Then the normal +attack -attack method
            else
                cmd:AddKey(IN_ATTACK) -- Also better than bit in and bit out since that fucks up semi auto & burst guns if they are a bad pack
            end
        end
    end
end 

function quantum:Aimbot( cmd )
    if !quantum.convar("quantum_aimbot"):GetBool() then return end 

    if quantum.convar("quantum_aimbot_onshot"):GetBool() && !cmd:KeyDown(1) then return end 

    local ply = quantum.GetTarget() -- Get the target

    if ply == 0 then return end -- If no target then we don't run the aimbot

    -- If your looking at the player
    -- And you don't want it to stick
    -- Then return end 
    if quantum.convar("quantum_aimbot_nonsticky"):GetBool() && G.util.TraceLine( G.util.GetPlayerTrace( p ) ).Entity == ply then quantum:Autofire( cmd, ply ) return end 

    local pos = ply:LocalToWorld(ply:OBBCenter()) -- TODO: PLACEHOLDER! ADD HITBOX SELECTOR (with multipoint pls :)) --

    -- LAG FIX --
    if quantum.convar("quantum_aimbot_compensate"):GetBool() then 

        local compensation_type = quantum.convar("quantum_aimbot_compensate_type"):GetString()

        if compensation_type == "predictive" then 
            pos = pos + (ply:GetVelocity() * G.engine.TickInterval());
        elseif compensation_type == "trailing" then 
            pos = pos - ply:GetVelocity()/50 - G.Vector(0,0,0);
        elseif compensation_type == "automatic" then 
            if p:Ping() > 90 || ply:Ping() > 90 || ply:GetVelocity():LengthSqr() >= 16777216 then -- Equal to 4096 since its not square rooted 
                pos = pos - ply:GetVelocity()/50; -- Player is breaking lag comp, has high ping, or local player has too high ping
                -- Reguardless, lag compensation is rendered impossible
            else
                pos = pos + (ply:GetVelocity() * G.engine.TickInterval());
            end
            // MsgN(ply:GetVelocity():LengthSqr())
        end

        if compensation_type == "minimal" then
            G.RunConsoleCommand("cl_lagcompensation", 0)
        else
            G.RunConsoleCommand("cl_lagcompensation", 1)
        end
    end
    ---------------

    local ang = (pos - p:GetShootPos()):Angle()

    if quantum.convar("quantum_aimbot_recoil") then 
        ang = ang - p:GetViewPunchAngles()
    end

    GAMEMODE["EntityFireBullets"] = function(self, p, data)
	    aimignore = aimtarget
	    local w = pm.GetActiveWeapon(me)
	    local Spread = data.Spread * - 1
	    if (not w or not em.IsValid(w) or cones[em.GetClass(w)] == Spread or Spread == nullvec) then return end
	    cones[em.GetClass(w)] = Spread
    end

    if quantum.convar("quantum_aimbot_spread") then
	    local w = pm.GetActiveWeapon(me)
	    if not w or not em.IsValid(w) or not cones[em.GetClass(w)] then return am.Forward(ang) end
	    return (quantum.Predict(pCmd, am.Forward(ang), cones[em.GetClass(w)]))
	end
	
    if quantum.convar("quantum_aimbot_smooth"):GetBool() then 
        local ratio = (quantum.convar("quantum_aimbot_smoothval"):GetFloat() - 100)/100

        ratio = ratio - 1
    
        ratio = ratio * 2

        local curangles = cmd:GetViewAngles()
        
        ang.p = G.math.NormalizeAngle(ang.p)
        ang.y = G.math.NormalizeAngle(ang.y)

        ang.y = G.math.ApproachAngle(curangles.y, ang.y, ratio/8)
        ang.p = G.math.ApproachAngle(curangles.p, ang.p, ratio/8)

        -- Yeah, new gmod update broke Lerp & LerpAngle
        -- Approaching still works, I dunno why or how the fuck they broke the most
        -- Basic of math equations but whatever 
    end

    ang.z = 0

    -- todo: recoil, spread
    -- potential features: randomizers for smooth and fov, deadzones for fov, resolver (hvh)
    cmd:SetViewAngles(ang)

    quantum:Autofire( cmd, ply )
end


//////////////

// HOOKS //

G.hook.Add( "CreateMove", quantum.util.randomstr(), function(cmd)
    quantum:Aimbot(cmd)
end )


//////////////