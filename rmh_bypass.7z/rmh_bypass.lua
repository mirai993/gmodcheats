require("cvar3")
--Renaming Convars
GetConVar("sv_cheats"):SetName("mecheat")
GetConVar("sv_allowcslua"):SetName("melua")
GetConVar("bot_defend"):SetName("sv_cheats")
GetConVar("bot_flipout"):SetName("sv_allowcslua")
--Setting Flags
GetConVar("melua"):SetFlags(0)
GetConVar("mecheat"):SetFlags(0)
GetConVar("sv_cheats"):SetFlags(0)
GetConVar("sv_allowcslua"):SetFlags(1)
--Setting Values
GetConVar("melua"):SetValue(1)
GetConVar("sv_cheats"):SetValue(0)
GetConVar("sv_allowcslua"):SetValue(1)
GetConVar("mecheat"):SetValue(1)
--Checking if bypass was successful.
if GetConVarNumber("sv_cheats") == 0 and GetConVarNumber("sv_allowcslua") == 1 and GetConVarNumber("melua") == 1 and GetConVarNumber("mecheat") == 1 then
	LocalPlayer():ChatPrint("Bypass finished.")
else
	LocalPlayer():ChatPrint("Bypassing failed.")
end


--[[
Part of RAZ
]]