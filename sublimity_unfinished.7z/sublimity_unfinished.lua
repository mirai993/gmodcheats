


local UI = {}


























/*
    Fake lagz
*/

Sublimity.ToolList = { ["weapon_physcannon"] = true, ["weapon_physgun"] = true, ["gmod_tool"] = true }
Sublimity.ChokedPackets = 0

function Sublimity.ShouldSend()
    if not EntEx.LocalPlayer:Alive() or Sublimity.InBadMove then return true end 
    if BitEx.Band( TempCmd.Buttons, IN_USE ) or Settings.Vars.SendInAttack and BitEx.Band( TempCmd.Buttons, IN_ATTACK ) then return true end 
    if EntEx.LocalPlayer:IsDrivingEntity() or EntEx.LocalPlayer:WaterLevel() > 1 then return true end 
    if Settings.Vars.SendWithTools and Sublimity.ToolList[ PlayerList[ 0 ].WeaponClass ] then return true end 
    
    return false 
end

function Sublimity.FakeLag()
    local SendInterval = Settings.Vars.FakeLagValue 

    if Settings.Vars.FakeLagMode == 2 then
        local PerTick = Sublimity.PredictedVelocity:Length2D() * TickInterval
        SendInterval = math_Clamp( math_Ceil( 64 / PerTick ), 1, SendInterval ) 
    end

    TempCmd.SendPacket = Sublimity.ShouldSend() 

    if Sublimity.ChokedPackets >= SendInterval then
        Sublimity.ChokedPackets = 0
        TempCmd.SendPacket = true 
    else
        Sublimity.ChokedPackets = Sublimity.ChokedPackets + 1
    end
end 

// Fake walk 
function Sublimity.FakeWalk() 
    if not Settings.Binds[7].State then return end 

    local TicksToStop = 6
    local TicksLeft = 21 - Sublimity.ChokedPackets

    local VelocityVec = Vector( Sublimity.PredictedVelocity.x, Sublimity.PredictedVelocity.y, 0 ) 
    local PredictedSpeed = Sublimity.PredictedVelocity:Length2D()
    local EditedData, Data

    ded.StartSimulation( EntEx.LocalPlayer:EntIndex() )

    for i = 1, TicksLeft do
        local Dir = VelocityVec:Angle() 
        Dir.y = Sublimity.FakeAng.y - Dir.y

        local newmove = Dir:Forward() * VelocityVec:Length2D()

        EditedData = {
            m_flForwardMove = -newmove.x,
            m_flSideMove = -newmove.y,
            m_vecViewAngles = Sublimity.FakeAng,
        }

        ded.EditSimulationData( EditedData )

        ded.SimulateTick()

        Data = ded.GetSimulationData()

        VelocityVec = Data.m_vecVelocity
        PredictedSpeed = VelocityVec:Length2D()

        if PredictedSpeed < 0.1 then
            TicksToStop = i - 1
            break
        end
    end

    ded.FinishSimulation()

    if Sublimity.ChokedPackets > 1 and Sublimity.ChokedPackets >= TicksToStop then
        local dir = Sublimity.PredictedVelocity:Angle()  
        dir.y = Sublimity.FakeAng.y - dir.y
                    
        local newmove = dir:Forward() * Sublimity.PredictedVelocity:Length2D()
        TempCmd.ForwardMove = -newmove.x
        TempCmd.SideMove = -newmove.y
    end
end

/*  
    Anti aimbot 
*/

Sublimity.PacketSwap    = false 
Sublimity.YawBase       = 0 


Sublimity.YawModes = {
    { Static = true,    Ang = 180 }, 
    { Static = false,   Ang = function() return TempCmd.SendPacket and 89 or -89 end },  

}

Sublimity.PitchModes = {
    { Static = false, Ang = function() return Sublimity.FakeAng.x end },
    { Static = true, Ang = 89 },       
    { Static = true, Ang = -89 },       
    { Static = true, Ang = 0 },        
    { Static = true, Ang = 180 },       
    { Static = true, Ang = -180 },   
    { Static = false, Ang = function() return Sublimity.PacketSwap and -180 or 271 end },
    { Static = false, Ang = function() return Sublimity.PacketSwap and 179.9 or 89 end },
    { Static = false, Ang = function() return Settings.Vars.AntiAimPitchCustom end },
}

function Sublimity.GetAntiAimPitch()
    local PitchMode = Sublimity.PitchModes[ Settings.Vars.AntiAimPitchMode ]
      
    return PitchMode.Static and PitchMode.Ang or PitchMode.Ang()
end

function Sublimity.GetAntiAimYaw()
    local Yaw = Settings.Vars.AntiAimYawAtTargets and Sublimity.YawBase or Sublimity.FakeAng.y 
    local YawMode = Sublimity.YawModes[ Settings.Vars.AntiAimYawMode ]
    Yaw = YawMode.Static and Yaw + YawMode.Ang or Yaw + YawMode.Ang()

    if Settings.Vars.AntiAimYawDynamic then
        Yaw = Yaw + ( TempCmd.Swap and 1 or -1)
    end

    return math_NormalizeAngle( Yaw ) 
end

function Sublimity.AntiAimbot()
    if TempCmd.SendPacket then Sublimity.PacketSwap = not Sublimity.PacketSwap end 

    if not EntEx.LocalPlayer:Alive() or Sublimity.InBadMove then return end 
    if BitEx.Band( TempCmd.Buttons, IN_USE ) or Settings.Vars.DisableInAttack and BitEx.Band( TempCmd.Buttons, IN_ATTACK ) then return end 
    if EntEx.LocalPlayer:IsDrivingEntity() or EntEx.LocalPlayer:WaterLevel() > 1 then return end 
    if Settings.Vars.DisableWithTools and Sublimity.ToolList[ PlayerList[ 0 ].WeaponClass ] then return true end 

    if Settings.Vars.AntiAimExtend and not Sublimity.InMove then
        TempCmd.SideMove = ( TempCmd.Swap and 12 or -12 )
    end

    TempCmd.ViewAngles.y = Sublimity.GetAntiAimYaw()
    TempCmd.ViewAngles.x = Sublimity.GetAntiAimPitch()
    TempCmd.ViewAngles.r = 0
end
 













// CreateMove hook 
function Sublimity.ComputeAngleData( cmd )
    if not PlayerList[ 0 ] then return end 

    local w = PlayerList[ 0 ].Weapon
    if not w then return end 
    
    if w.FreezeMovement and w:FreezeMovement() then return end 
    if PlayerList[ 0 ].WeaponClass == "weapon_physgun" and isValid( w:GetInternalVariable("m_hGrabbedEntity") ) and BitEx.Band( TempCmd.Buttons, IN_USE ) then return end
    
    Sublimity.FakeAng = Sublimity.FakeAng and Sublimity.FakeAng or cmd:GetViewAngles() 
    Sublimity.FakeAng = Sublimity.FakeAng + Ang( TempCmd.MouseY * Static.ConVars.m_yaw, TempCmd.MouseX * -Static.ConVars.m_yaw, 0 )
    Sublimity.FakeAng.x = math_Clamp( Sublimity.FakeAng.x, -89, 89 )

    Sublimity.FakeAng:Normalize()
end



// Taunt spammer 
Sublimity.LastTauntTime = 0
Sublimity.DarkRpTaunts  = { [4] = ACT_GMOD_GESTURE_BOW, [2] = ACT_GMOD_TAUNT_MUSCLE, [7] = ACT_GMOD_GESTURE_BECON, [3] = ACT_GMOD_TAUNT_LAUGH, [15] = ACT_GMOD_TAUNT_PERSISTENCE, [9] = ACT_GMOD_GESTURE_DISAGREE, [8] = ACT_GMOD_GESTURE_AGREE, [6] = ACT_GMOD_GESTURE_WAVE, [14] = ACT_GMOD_TAUNT_DANCE }
Sublimity.Taunts        = { "robot", "muscle", "laugh", "bow", "cheer", "wave", "becon", "agree", "disagree", "forward", "group", "half", "zombie", "dance", "pers", "halt", "salute" }

function Sublimity.TauntSpammer()
    local shouldTaunt = Settings.Vars.TauntTime == 0 and not EntEx.LocalPlayer:IsPlayingTaunt( true ) == false or Sublimity.LastTauntTime < CurrentTime_

    if not shouldTaunt then return end 

    if DarkRP then
        RunCommand( "_DarkRP_DoAnimation", Sublimity.DarkRpTaunts[ Settings.Vars.TauntCmd ] or ACT_GMOD_TAUNT_DANCE )
    else
        RunCommand( "act", Sublimity.Taunts[ Settings.Vars.TauntCmd ] )  
    end
    
    Sublimity.LastTauntTimes = CurrentTime_ + Settings.Vars.TauntTime
end

// Movement hackz 
Sublimity.NumHops = 0  
Sublimity.TickOnGround      = 0
Sublimity.PredictedOnGround = false
Sublimity.PredictedVelocity = Vec()
Sublimity.OldStrafeYaw      = 0

function Sublimity.EdgeJump()
    if Sublimity.TickOnGround < 24 then return end 

    ded.StartSimulation( PlayerCache[ EntEx.LocalPlayer ].EntIndex )
    ded.SimulateTick()

    local data = ded.GetSimulationData()

    ded.FinishSimulation() 

    if data.m_vecAbsOrigin.z < PlayerList[ 0 ].Origin.z then
        TempCmd.Buttons = bit_Bor( TempCmd.Buttons, IN_JUMP )
    end
end

function Sublimity.FastStop()
    if Sublimity.InMove or not Sublimity.PredictedOnGround then return end 

    local dir = Sublimity.PredictedVelocity:Angle()  
    dir.y = Sublimity.FakeAng.y - dir.y
                
    local newmove = dir:Forward() * Sublimity.PredictedVelocity:Length2D()
        
    TempCmd.ForwardMove = -newmove.x
    TempCmd.SideMove = -newmove.y
end

Sublimity.Autosrafers = {
    [ 1 ] = function() 
        TempCmd.SideMove = TempCmd.Swap and -5250 or 5250
    end,
    [ 2 ] = function()
        if TempCmd.MouseY > 1 then
            TempCmd.SideMove = Static.ConVars.cl_sidespeed
        elseif TempCmd.MouseY < 1 then
            TempCmd.SideMove = -Static.ConVars.cl_sidespeed
        end
    end,
    [ 3 ] = function()  
        local velocityLength = Sublimity.PredictedVelocity:Length2D()
        local sideFlip = ( TempCmd.TickCount % 2 ) == 0 and 1 or -1

        local viewAngles = Sublimity.FakeAng.y
        local velocityAngles = Sublimity.PredictedVelocity:Angle().y

        if velocityLength <= 15 and ( TempCmd.ForwardMove == 0 or TempCmd.SideMove == 0 ) then
            return
        end

        local turnAtan = math_Atan2( -TempCmd.SideMove, TempCmd.ForwardMove )
        viewAngles = viewAngles + ( turnAtan * math_Radian )

        local strafeAngle = math_Min( math_Deg( math_Atan( 15 / velocityLength ) ), Static.ConVars.sv_airaccelerate / TickRate )
        if strafeAngle > 90 then strafeAngle = 90 elseif strafeAngle < 0 then strafeAngle = 0 end

        local tempYaw = math_NormalizeAngle( viewAngles - Sublimity.OldStrafeYaw )
        local yawDelta = tempYaw

        Sublimity.OldStrafeYaw = viewAngles

        local absYawDelta = math_Abs( yawDelta )

        if absYawDelta <= strafeAngle or absYawDelta >= 30 then
            tempYaw = math_NormalizeAngle( viewAngles - velocityAngles )

            local velocityDegree = math_Deg( math_Atan( 30 / ( velocityLength * 128 ) ) )
            if velocityDegree > 90 then velocityDegree = 90 elseif velocityDegree < 0 then velocityDegree = 0 end
       
            if tempYaw <= velocityDegree or velocityLength <= 15 then
                if -velocityDegree <= tempYaw or velocityLength <= 15 then
                    viewAngles = viewAngles + ( strafeAngle * sideFlip )
                    TempCmd.SideMove = ( Static.ConVars.cl_sidespeed * sideFlip )
                else
                    viewAngles = velocityAngles - velocityDegree
                    TempCmd.SideMove = Static.ConVars.cl_sidespeed
                end
            else
                viewAngles = velocityAngles + velocityDegree
                TempCmd.SideMove = -Static.ConVars.cl_sidespeed
            end
        elseif yawDelta != 0 then
            TempCmd.SideMove = yawDelta > 0 and -Static.ConVars.cl_sidespeed or Static.ConVars.cl_sidespeed
        end

        local moveVec = Vec( TempCmd.ForwardMove, TempCmd.SideMove, 0 )
        local moveLen = moveVec:Length()
        local moveAng = moveVec:Angle().y

        local normX = math_ModF( Sublimity.FakeAng.x + 180, 360 ) - 180
        local normY = math_ModF( Sublimity.FakeAng.y + 180, 360 ) - 180

        local moveYaw = math_Rad( normY - viewAngles + moveAng )

        if normX >= 90 or normX <= -90 or Sublimity.FakeAng.x >= 90 and Sublimity.FakeAng.x <= 200 or Sublimity.FakeAng.x <= -90 and Sublimity.FakeAng.x <= 200 then
            TempCmd.ForwardMove = -math_Cos( moveYaw ) * moveLen
        else
            TempCmd.ForwardMove = math_Cos( moveYaw ) * moveLen
        end

        TempCmd.SideMove = math_Sin( moveYaw ) * moveLen
    end
}






Sublimity.InMove    = false
Sublimity.InBadMove = false

Sublimity.MoveKeys     = { IN_BACK, IN_FORWARD, IN_JUMP, IN_MOVELEFT, IN_MOVERIGHT }
Sublimity.BadMovetypes = { MOVETYPE_NOCLIP, MOVETYPE_LADDER, MOVETYPE_OBSERVER }



function Sublimity.CollectCommandData( cmd )
    TempCmd = { 
        Object = cmd, 
        CommandNumber = cmd:CommandNumber(), 
        TickCount = cmd:TickCount(), 
        Buttons = cmd:GetButtons(), 
        Impulse = cmd:GetImpulse(), 
        ForwardMove = cmd:GetForwardMove(), 
        SideMove = cmd:GetSideMove(), 
        UpMove = cmd:GetUpMove(), 
        MouseWheel = cmd:GetMouseWheel(),
        MouseY = cmd:GetMouseY(),
        MouseX = cmd:GetMouseX(),
        ViewAngles = cmd:GetViewAngles(), 
        SendPacket = true, 
    }

    TempCmd.WishYaw = TempCmd.ViewAngles.y
    TempCmd.Swap = TempCmd.CommandNumber % 2 == 0 
end

Sublimity.HandJob = {
    [1] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
			    net_lib.WriteBool(true)
			net_SendToServer()
        else
            ded.SetTyping( cmd, true )
        end
    end,
    [2] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
                net_lib.WriteBool(( TempCmd.CommandNumber % 12 ) >= 6)
            net_SendToServer()
        else
            ded.SetTyping( cmd, ( TempCmd.CommandNumber % 12 ) >= 6 )
        end
    end, 
    [3] = function( cmd )
        if _G.EasyChat then
            net_Start("EASY_CHAT_START_CHAT") 
                net_lib.WriteBool(math_Random( 0, 1 ) == 0)
            net_SendToServer()
        else
            ded.SetTyping( cmd, math_Random( 0, 1 ) == 0 )
        end
    end,
}

// Vape hackz
Sublimity.MaxVapeTicks  = MathEx.TimeToTicks( 5 )
Sublimity.VapeTicks     = 0
Sublimity.VapingCd      = false 
Sublimity.LastTorch     = 0

function Sublimity.AutoVape()
    if not BitEx.Band( TempCmd.Buttons, IN_ATTACK ) then Sublimity.VapeTicks = 0 end 

    if Sublimity.VapeTicks >= Sublimity.MaxVapeTicks then
        TempCmd.Buttons = BitEx.Remove( TempCmd.Buttons, IN_ATTACK ) 
        Sublimity.VapeTicks = 0
        return 
    end
        
    Sublimity.VapeTicks = Sublimity.VapeTicks + 1
end

// Rope spammer 
Sublimity.RopeModes = { ["rope"] = "rope_material", ["hydraulic"] = "hydraulic_material", ["winch"] = "winch_rope_material", ["muscle"] = "muscle_material", ["slider"] = "slider_material", ["pulley"] = "pulley_material", ["elastic"] = "elastic_material" }
Sublimity.FuckedUpMatz = { "pp/copy", "pp/add", "pp/morph/refract", "trails/lol", "debug/debugportals", "debug/debugempty" }

function Sublimity.RopeSpammer()
    if not BitEx.Band( TempCmd.Buttons, IN_ATTACK ) then return end 

    local tool = PlayerList[ 0 ].Weapon:GetToolObject().Mode

    if not Sublimity.RopeModes[ tool ] then return end 

    if Settings.Vars.RopeMatz then
        RunCommand( Sublimity.RopeModes[ tool ], Sublimity.FuckedUpMatz[ math_Random( 1, #Sublimity.FuckedUpMatz ) ] )
    end
    
    TempCmd.ViewAngles.x = math_Random( -89, 89 )
    TempCmd.ViewAngles.y = math_Random( -180, 180 )

    TempCmd.Buttons = bit_Bor( TempCmd.Buttons, IN_ATTACK )

    math_NormalizeAngle( TempCmd.ViewAngles.y )
end

// Pathfinder 
Sublimity.PatherHull = { mins = EntEx.LocalPlayer:OBBMins(), maxs = EntEx.LocalPlayer:OBBMaxs(), filter = EntEx.LocalPlayer, mask = MASK_SOLID }
Sublimity.PathLen = math_Floor( Sublimity.PatherHull.maxs.y )
Sublimity.DirVecs = { Vec( Sublimity.PathLen, 0, 0 ), Vec( -Sublimity.PathLen, 0, 0 ), Vec( 0, Sublimity.PathLen, 0 ), Vec( 0, -Sublimity.PathLen, 0 ), Vec( Sublimity.PathLen, Sublimity.PathLen, 0 ), Vec( Sublimity.PathLen, -Sublimity.PathLen, 0 ), Vec( -Sublimity.PathLen, Sublimity.PathLen, 0 ), Vec( -Sublimity.PathLen, -Sublimity.PathLen, 0 ), Vec( -Sublimity.PathLen, -Sublimity.PathLen, 0 ) }
Sublimity.PathFound = false 
Sublimity.LastPathCalc = 0
Sublimity.PathNodes = {}

function Sublimity.FloorVec( vec )
    vec = Vec( math_Floor( vec.x ), math_Floor( vec.y ), math_Floor( vec.z ) )
end

function Sublimity.FindPath( targetVector )
    if Sublimity.LastPathCalc > CurrentTime_ then return end 

    local CurrentPos = EntEx.LocalPlayer:GetPos()
    Sublimity.PathNodes[ 1 ] = {
        vec = Sublimity.FloorVec( CurrentPos + Vec( 0, 0, 8 ) ),
        dirs = {},
        comp = false,
    }

    for d = 1, #Sublimity.DirVecs do
        Sublimity.PathNodes[ 1 ].dirs[ d ] = false
    end

    if Sublimity.PathFound then return end
    
    for i = 1, #Sublimity.PathNodes do
        

    end

end

/*



UI.Checkbox( "PathFinder", "PathFinder" )
        UI.Checkbox( "Decreaseing mode", "PathFinderDec" )
        UI.ComboBox( "Pathfinding mode", "PathFinderMode", { "Player follower", "Entity collector" } )
        UI.Slider( "Range multiplier", "", "PathFinderRange", 0, 1, 5 )
        UI.Slider( "Pathfinding delay", "", "PathFinderDelay", 0, 0, 5 )


*/














function Sublimity.CreateMove( cmd )
    Sublimity.CollectCommandData( cmd )
    Sublimity.ComputeAngleData( cmd )

    if TempCmd.CommandNumber == 0 then return end 

    local LocalTable = PlayerList[ 0 ]
    if not LocalTable then return end

    if Settings.Vars.SilentAim then
        TempCmd.ViewAngles = Ang( Sublimity.FakeAng.x, Sublimity.FakeAng.y, 0 )
    end

    Sublimity.PredictedVelocity = EntEx.LocalPlayer:GetVelocity()
    Sublimity.PredictedOnGround = BitEx.Band( EntEx.LocalPlayer:GetFlags(), FL_ONGROUND )

    Sublimity.TickOnGround = Sublimity.PredictedOnGround and Sublimity.TickOnGround + 1 or 0 

    Sublimity.InMove = false
    Sublimity.InBadMove = false 

    for i = 1, #Sublimity.MoveKeys do
        if not BitEx.Band( TempCmd.Buttons, Sublimity.MoveKeys[i] ) then 
            continue 
        end
            
        Sublimity.InMove = true 
        break
    end

    for i = 1, #Sublimity.BadMovetypes do
        if not BitEx.Band( LocalTable.MoveType, Sublimity.BadMovetypes[i] ) then 
            continue 
        end
            
        Sublimity.InBadMove = true 
        break
    end

    if Settings.Vars.HandJob then Sublimity.HandJob[ Settings.Vars.HandJobMode ]( cmd ) end
    if Settings.Vars.FlashlightSpam and Settings.Binds[1].State then TempCmd.Impulse = 100 end
    if Settings.Vars.TauntSpam then Sublimity.TauntSpammer() end
    if Settings.Vars.AutoVape then Sublimity.AutoVape() end

    if Settings.Vars.VapeTorch and LocalTable.WeaponClass == "weapon_vape_dragon" and CurrentTime_ - Sublimity.LastTorch > 1 then 
        for i = 1, #PlayerList do
            if PlayerList[ i ].Origin:DistToSqr( LocalTable.Origin ) > 250000 then continue end 

            net_Start( "DragonVapeIgnite" )
                net_lib.WriteEntity( PlayerList[ i ].Ent )
            net_SendToServer()
        end

        Sublimity.LastTorch = CurrentTime_ + 1
    end 

    Sublimity.KeySpammerShortcut( IN_ATTACK, Settings.Vars.CameraSpam and LocalTable.WeaponClass == "gmod_camera" )
    Sublimity.KeySpammerShortcut( IN_USE, Settings.Vars.UseSpam )

    if Settings.Vars.VapeSpam and TempCmd.Swap and string_StartsWith( LocalTable.WeaponClass, "weapon_vape" ) then
        TempCmd.Buttons = bit_Bor( TempCmd.Buttons, IN_ATTACK2 )
    end

    if not Sublimity.InBadMove then
        if Settings.Vars.EdgeJump and Settings.Binds[2].State then 
            Sublimity.EdgeJump()
        end

        if Settings.Vars.WaterFloat and EntEx.LocalPlayer:WaterLevel() > 1 then
            TempCmd.Buttons = bit_Bor( TempCmd.Buttons, IN_JUMP )
        end
      
        if BitEx.Band( TempCmd.Buttons, IN_JUMP ) then
            if Settings.Vars.BunnyHop and ( ( Settings.Vars.MaxHops == 0 or Sublimity.NumHops < Settings.Vars.MaxHops ) and ( Settings.Vars.HopDelay > 0 and Sublimity.TickOnGround < Settings.Vars.HopDelay ) or not Sublimity.PredictedOnGround ) then 
                TempCmd.Buttons = BitEx.Remove( TempCmd.Buttons, IN_JUMP )
                Sublimity.NumHops = Sublimity.NumHops + 1
            end

            if Settings.Vars.AirStrafer then
                TempCmd.ForwardMove = Sublimity.PredictedOnGround and Static.ConVars.cl_forwardspeed or 5850 / Sublimity.PredictedVelocity:Length2D()

                if not Sublimity.PredictedOnGround then
                    Sublimity.Autosrafers[ Settings.Vars.AirStraferMode ]()
                else
                    TempCmd.Buttons = bit_Bor( TempCmd.Buttons, IN_SPEED )
                end
            end
        else
            Sublimity.NumHops = 0
        end

        if Sublimity.PredictedOnGround and Settings.Vars.GroundStrafe and TempCmd.SideMove == 0 and TempCmd.ForwardMove > 0 then
            TempCmd.SideMove = TempCmd.Swap and -5250 or 5250
        end  

        if Settings.Vars.FastStop then
            Sublimity.FastStop()
        end
        
        if Settings.Vars.SlowWalk and Settings.Binds[3].State then 
            local ratio = EntEx.LocalPlayer:GetSlowWalkSpeed()

            TempCmd.ForwardMove = math_Floor( TempCmd.ForwardMove / ( Settings.Vars.SlowWalkSpeed * ratio ) )
            TempCmd.SideMove = math_Floor( TempCmd.SideMove / ( Settings.Vars.SlowWalkSpeed * ratio ) )
        end
    end

    if Settings.Vars.AutoParkour and LocalTable.Weapon and LocalTable.Weapon.Jumps then
        local jumps = EntEx.LocalPlayer:GetNWInt("ClimbJumps")
        
        if Static.ConVars.climbswep2_maxjumps - jumps < Static.ConVars.climbswep2_maxjumps then
            TempCmd.ForwardMove = Static.ConVars.cl_forwardspeed
            TempCmd.SideMove = 0
            
            TempCmd.ViewAngles.y = math_NormalizeAngle( TempCmd.ViewAngles.y - 180 )
        end
    end 

    if Settings.Vars.RopeSpam and LocalTable.WeaponClass == "gmod_tool" then
        Sublimity.RopeSpammer()
    end

    Sublimity.KeySpammerShortcut( IN_ATTACK, Settings.Vars.RapidFire and LocalTable.WeaponClass != "weapon_physgun" )

    if Settings.Vars.FakeLag then
        Sublimity.FakeLag()
    end

    if Settings.Vars.AntiAim then
        Sublimity.AntiAimbot()
    end

    if Settings.Vars.FakeWalk then
        Sublimity.FakeWalk()  
    end

 







    

    if not Settings.Vars.SilentAim then 
        Sublimity.FakeAng = TempCmd.ViewAngles 
    else
        Sublimity.FixMovement( cmd, Sublimity.FakeAng.y )
    end

    if Sublimity.FreeCamActive then
        TempCmd.SideMove = 0
        TempCmd.ForwardMove = 0
        TempCmd.UpMove = 0

        TempCmd.Buttons = 0 
        TempCmd.ViewAngles = Sublimity.PreFreeCamAngs
    else
        Sublimity.PreFreeCamAngs = TempCmd.ViewAngles 
    end

    // Modify cmd data 
    cmd:SetButtons( TempCmd.Buttons )
    cmd:SetImpulse( TempCmd.Impulse )
    cmd:SetForwardMove( TempCmd.ForwardMove )
    cmd:SetSideMove( TempCmd.SideMove )
    cmd:SetUpMove( TempCmd.UpMove )
    cmd:SetMouseWheel( TempCmd.MouseWheel )
    cmd:SetViewAngles( TempCmd.ViewAngles )

    ded.SetBSendPacket( TempCmd.SendPacket )
    ded.SetCommandTick( cmd, TempCmd.TickCount )
end



// SendNetMsg 
Sublimity.SlowMotionState = false
Sublimity.SlowMotionTicks = 0

function Sublimity.SendNetMsg( msgName )
    if msgName == "clc_Move" then
        if Settings.Vars.SlowMotion and Settings.Binds[6].State then
            if Sublimity.SlowMotionTicks < MathEx.TimeToTicks( Settings.Vars.SlowMotionTime ) then
                ded.EnableSlowmotion( true )
                Sublimity.SlowMotionTicks = Sublimity.SlowMotionTicks + 1
            else
                ded.EnableSlowmotion( false )
                Sublimity.SlowMotionTicks = 0
            end
            Sublimity.SlowMotionState = true 
        elseif Sublimity.SlowMotionState then
            ded.EnableSlowmotion( false )

            Sublimity.SlowMotionTicks = 0
            Sublimity.SlowMotionState = false
        end
    end
end

/*
    Player visuals 
*/

Sublimity.DrawData = {
    X = 0, Y = 0, 
    W = 0, H = 0,
    MinX = 0,   MinY = 0,
    MaxX = 0,   MaxY = 0,
    TextX = 0,  TextY = 0,
    Vis = false,
}

Sublimity.DrawnText = {}
Sublimity.StartPoses = {}

Sublimity.BarPoses = {}
Sublimity.BarPadding = {}


// Getting corners of entity in 2d space 
function Sublimity.GetEntityBounds( Ent )
    local Pos   = Ent:GetPos()

    local Maxs  = Ent:OBBMaxs()
    local Mins  = Ent:OBBMins()

    local Bounds = {
        ( Pos + Vec( Maxs.x, Maxs.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Maxs.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Mins.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Mins.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Mins.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Mins.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Maxs.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Maxs.y, Maxs.z ) ):ToScreen(),
    }

    local MaxX, MaxY, MinX, MinY 
    local Vis = false 

    for i = 1, #Bounds do
        local ScreenPoint = Bounds[ i ]
        Vis = ScreenPoint.visible

        if MaxX == nil then
            MaxX = ScreenPoint.x 
            MaxY = ScreenPoint.y
            MinX = ScreenPoint.x
            MinY = ScreenPoint.y

            continue 
        end

        MaxX = math_Max( MaxX, ScreenPoint.x ) 
        MaxY = math_Max( MaxY, ScreenPoint.y ) 
        MinX = math_Min( MinX, ScreenPoint.x )
        MinY = math_Min( MinY, ScreenPoint.y )
    end

    return math_Ceil( MaxX ), math_Ceil( MaxY ), math_Floor( MinX ), math_Floor( MinY ), Vis
end

function Sublimity.PlayerVisuals()



end

















// Menu elements










































// Game overlay 

function Sublimity.DrawOverlay()
    UI.DrawMenu()
end












// Detours :3 
Sublimity.OldConCommand     = PLAYER.ConCommand
Sublimity.OldIsPlayingTaunt = PLAYER.IsPlayingTaunt 




function PLAYER:ConCommand( cmd )
    if Settings.Vars.CameraSpam and cmd == "jpeg" then return end

    Sublimity.OldConCommand( self, cmd )
end

function PLAYER:IsPlayingTaunt( arg )
    if arg then 
        return Sublimity.OldIsPlayingTaunt( EntEx.LocalPlayer ) 
    end

    if Settings.Vars.TauntSpam and self == EntEx.LocalPlayer then
        return false 
    end 

    return Sublimity.OldIsPlayingTaunt( EntEx.LocalPlayer )
end


// Hooks init 
hook_Add( "PostFrameStageNotify", "shit", Sublimity.PostFrameStageNotify )
hook_Add( "Think", "shit", Sublimity.Think )
hook_Add( "CreateMove", "shit", Sublimity.CreateMove )
hook_Add( "CalcView", "shit", Sublimity.CalcView )
hook_Add( "CalcViewModelView", "shit", Sublimity.CalcViewModelView )
hook_Add( "SendNetMsg", "shit", Sublimity.SendNetMsg )
hook_Add( "DrawOverlay", "shit", Sublimity.DrawOverlay )