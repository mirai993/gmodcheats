--[[


Features:
On/Off Switch - In the top right of the hack there is an on/off switch that will deactivate everything.

Aimbot -
Active - Determines, overall, if the aimbot should be working.
Random Bone - If enabled the aimbot will pick a random bone to attack instead of always going at the players head.
Preference - Used to determine who the aimbot should target next. Can be set to Distance or Angle.
Attack NPCs - Determines if the aimbot should target NPCs.
Attack Player - Determines if the aimbot should target Players.
Prediction - Velocity prediction, to increase the aimbots accuracy.
Aim On Key - If this is on the aimbot will only target when your selected key is pressed.
Key - Determines the key for the previous option.
Anti Snap - Stops the aimbot from snapping to the target. But will decrease accuracy.
A-Snap Speed - The speed of the anti-snap. Value between 1 and 5.
Max Angle - The maximum angle the target can be away from you. Value between 0-270.
Auto Shoot - If this is on and the aimbot is locked on it will automatically shoot.
Panic Mode - If this is on the aimbot wont function while you are being spectated.
Ignore Team - If this is on the aimbot will not target players on your team, works with TTT if the traitor detector is enabled.

ESP -
Active - Determines, overall, if the ESP is working.
Player Info - Determines if the ESP should show player information.
NPC Info - Determines if the ESP should show NPC information.
Names - Determines if the targets name should be shown. (on NPCs it will be the class name, ex: npc_monk)
Weapons - Determines if the targets weapon should be displayed
Distance - Determines if distance between you and the target should be displayed.
Health - Determines if the targets health should be displayed.
Bounding Box - Determines if a bounding box should be drawn around the target.
TTT Feature - Show Traitors - Determines if the ESP should display if the target is a traitor. (must have traitor finder active, see Misc)
TTT Feature - Bodies - Will display body information on TTT. (Credits on body, Name of player, Found or not found)
2D Radar - Enables a 2D radar on screen. Players and NPCs are shown as arrows, bodies (TTT) are shown as circles.
Radar Scale - The distance the radar reaches. Value between 1 and 100
Max Distance - Determines the maximum distance the ESP will work to. (set to 0 for unlimited distance)
Team Based - Make the color of the ESP based on the targets team. Works with TTT.

Chams -
Active - Determines, overall, if the Chams are working.
Draw Players - Determines if the Chams should draw players.
Draw NPCs - Determines if the Chams should draw NPCs.
Draw Weapons - Determines if the Chams should draw the targets weapon.
TTT Feature - Bodies - Adds TTT bodies to the Chams
Team Based - Makes the color of the chams based on the targets team. Works with TTT.
Max Distance - Determines the maximum distance the Chams will work to. (set to 0 for unlimited distance)

Misc -
Show Admins - Displays all current admins in the top right corner of your screen.
Crosshair - Will draw a crosshair on your screen.
Crosshair Size - The size of the crosshair. Value between 0 and 1000.
No Recoil - Will remove all weapon recoil. (doesn't work in singleplayer)
Spectators - Displays all your current spectators in the top right corner of your screen, under the admins.
Auto Reload - Will automatically reload your weapon when your magazine is empty.
Bunny Hop - If this is on you will bunny hop while pressing the bunny hop key.
Key - Determines the key for the previous option.
Auto Pistol - Fires semi-automatic weapons as fast as possible. (doesn't work on default HL2 weapons)
DarkRP Feature - Buy Health - Will automatically use /buyhealth when your health falls below the minimum value set.
DarkRP Feature - Minimum - Minimum health before buying health. Value between 0 and 100.
TTT Feature - Traitor Finder - Will display when a traitor buys a traitor weapon. (see also the ESP option for displaying traitors)
Show Deaths - Will notify you via chat when a player dies.
Sounds - Enables sound cues along with notifications.

Style -
Bounding Box - Determines the color the bounding box should draw in.
ESP Text - Determines the color the ESP text should draw in.
Crosshair - Determines the color the Crosshair should draw in.
TTT Feature - Body Text - Determines the color body information will be shown in.
Chams - The color of the chams. (will be overwritten if Cham option Team Based is on)
TTT Feature - Body Chams - The color TTT bodies should be on the chams.
--]]

//I hear this makes the hack load faster, i didn't actually check the O times but whatever.
local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team

local cHack = {}
cHack.Active = CreateClientConVar("cHack_Active", 1, true, false)
cHack.Version = "1.5.0"
cHack.Ply = LocalPlayer()
cHack.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
if cHack.TTT then cHack.TTTCORPSE = CORPSE end
cHack.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false

//Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
cHack.GetColorFromString = function(words)
	//I probably shouldve just used string.explode...well.......
	if type(words) != "string" then return Color(255, 255, 255, 255) end
	words = "return "..words
	local func = CompileString(words, "GettingColors", true)
	local good, color = pcall(func)
	if good and type(color) == "table" and color.r and color.g and color.b and color.a then
		return color
	else
		return Color(255, 255, 255, 255)
	end
end

cHack.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
cHack.RandomName = function(amount)
	local toReturn = ""
	local amount = amount or 10
	for i = 1, amount do
		if math.random(0, 1) == 0 then
			toReturn = toReturn..string.lower(table.Random(cHack.Chars))
		else
			toReturn = toReturn..table.Random(cHack.Chars)
		end
	end
	return toReturn
end

cHack.Message = function(...)
	chat.AddText(Color(50, 255, 100), "[cHack] ", ...)
end

cHack.Aimbot = {}
cHack.Aimbot.CurTarget = nil
cHack.Aimbot.Vars = {}
cHack.Aimbot.Vars["Active"] = CreateClientConVar("cHack_Aimbot_Active", 0, true, false)
cHack.Aimbot.Vars["RandomBones"] = CreateClientConVar("cHack_Aimbot_RandomBones", 0, true, false)
cHack.Aimbot.Vars["AttackNPCs"] = CreateClientConVar("cHack_Aimbot_AttackNPCs", 0, true, false)
cHack.Aimbot.Vars["AttackPlayers"] = CreateClientConVar("cHack_Aimbot_AttackPlayers", 0, true, false)
cHack.Aimbot.Vars["Prediction"] = CreateClientConVar("cHack_Aimbot_Prediction", 0, true, false)
cHack.Aimbot.Vars["AimOnKey"] = CreateClientConVar("cHack_Aimbot_AimOnKey", 0, true, false)
cHack.Aimbot.Vars["AimOnKey_Key"] = CreateClientConVar("cHack_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
cHack.Aimbot.Vars["MaxAngle"] = CreateClientConVar("cHack_Aimbot_MaxAngle", 180, true, false)
cHack.Aimbot.Vars["Preferance"] = CreateClientConVar("cHack_Aimbot_Preferance", "Distance", true, false)
cHack.Aimbot.Vars["AntiSnap"] = CreateClientConVar("cHack_Aimbot_AntiSnap", 0, true, false)
cHack.Aimbot.Vars["AntiSnapSpeed"] = CreateClientConVar("cHack_Aimbot_AntiSnapSpeed", 4, true, false)
cHack.Aimbot.Vars["AutoShoot"] = CreateClientConVar("cHack_Aimbot_AutoShoot", 0, true, false)
cHack.Aimbot.Vars["PanicMode"] = CreateClientConVar("cHack_Aimbot_PanicMode", 0, true, false)
cHack.Aimbot.Vars["IgnoreTeam"] = CreateClientConVar("cHack_Aimbot_IgnoreTeam", 0, true, false)

cHack.Friends = {}
cHack.Friends.List = {} //The steamIDs of everyone on your friends list
cHack.Friends.Vars = {}
cHack.Friends.Vars["Active"] = CreateClientConVar("cHack_Friends_Active", 0, true, false)
cHack.Friends.Vars["Reverse"] = CreateClientConVar("cHack_Friends_Reverse", 0, true, false)

cHack.ESP = {}
cHack.ESP.Vars = {}
cHack.ESP.Vars["Active"] = CreateClientConVar("cHack_ESP_Active", 0, true, false)
cHack.ESP.Vars["Players"] = CreateClientConVar("cHack_ESP_Players", 0, true, false)
cHack.ESP.Vars["NPCs"] = CreateClientConVar("cHack_ESP_NPCs", 0, true, false)
cHack.ESP.Vars["Name"] = CreateClientConVar("cHack_ESP_Name", "Off", true, false)
cHack.ESP.Vars["Weapons"] = CreateClientConVar("cHack_ESP_Weapons", "Off", true, false)
cHack.ESP.Vars["Distance"] = CreateClientConVar("cHack_ESP_Distance", "Off", true, false)
cHack.ESP.Vars["Health"] = CreateClientConVar("cHack_ESP_Health", "Off", true, false)
cHack.ESP.Vars["MaxDistance"] = CreateClientConVar("cHack_ESP_MaxDistance", 0, true, false)
cHack.ESP.Vars["Box"] = CreateClientConVar("cHack_ESP_Box", 0, true, false)
cHack.ESP.Vars["ShowTraitors"] = CreateClientConVar("cHack_ESP_ShowTraitors", "Off", true, false)
cHack.ESP.Vars["Bodies"] = CreateClientConVar("cHack_ESP_Bodies", 0, true, false)
cHack.ESP.Vars["Radar"] = CreateClientConVar("cHack_ESP_Radar", 0, true, false)
cHack.ESP.Vars["RadarScale"] = CreateClientConVar("cHack_ESP_RadarScale", 20, true, false)
cHack.ESP.Vars["TeamBased"] = CreateClientConVar("cHack_ESP_TeamBased", 0, true, false)

cHack.Chams = {}
cHack.Chams.Mat = CreateMaterial(cHack.RandomName(math.random(10,15)), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
cHack.Chams.Vars = {}
cHack.Chams.Vars["Active"] = CreateClientConVar("cHack_Chams_Active", 0, true, false)
cHack.Chams.Vars["Players"] = CreateClientConVar("cHack_Chams_Players", 0, true, false)
cHack.Chams.Vars["NPCs"] = CreateClientConVar("cHack_Chams_NPCs", 0, true, false)
cHack.Chams.Vars["Weapons"] = CreateClientConVar("cHack_Chams_Weapons", 0, true, false)
cHack.Chams.Vars["MaxDistance"] = CreateClientConVar("cHack_Chams_MaxDistance", 0, true, false)
cHack.Chams.Vars["Bodies"] = CreateClientConVar("cHack_Chams_Bodies", 0, true, false)
cHack.Chams.Vars["TeamBased"] = CreateClientConVar("cHack_Chams_TeamBased", 0, true, false)

cHack.Entities = {}
cHack.Entities.List = {} //The class namse of all the entities
cHack.Entities.Vars = {}
cHack.Entities.Vars["Active"] = CreateClientConVar("cHack_Entities_Active", 0, true, false)

cHack.Misc = {}
cHack.Misc.Vars = {}
cHack.Misc.Vars["ShowAdmins"] = CreateClientConVar("cHack_Misc_ShowAdmins", 0, true, false)
cHack.Misc.Vars["Crosshair"] = CreateClientConVar("cHack_Misc_Cross", 0, true, false)
cHack.Misc.Vars["CrosshairSize"] = CreateClientConVar("cHack_Misc_CrossSize", 50, true, false)
cHack.Misc.Vars["NoRecoil"] = CreateClientConVar("cHack_Misc_NoRecoil", 0, true, false)
cHack.Misc.Vars["ShowSpectators"] = CreateClientConVar("cHack_Misc_ShowSpectators", 0, true, false)
cHack.Misc.Vars["BunnyHop"] = CreateClientConVar("cHack_Misc_BunnyHop", 0, true, false)
cHack.Misc.Vars["BunnyHop_Key"] = CreateClientConVar("cHack_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
cHack.Misc.Vars["AutoReload"] = CreateClientConVar("cHack_Misc_AutoReload", 0, true, false)
cHack.Misc.Vars["AutoPistol"] = CreateClientConVar("cHack_Misc_AutoPistol", 0, true, false)
cHack.Misc.Vars["BuyHealth"] = CreateClientConVar("cHack_Misc_BuyHealth", 0, true, false)
cHack.Misc.Vars["BuyHealth_Minimum"] = CreateClientConVar("cHack_Misc_BuyHealth_Minimum", 80, true, false)
cHack.Misc.Vars["TraitorFinder"] = CreateClientConVar("cHack_Misc_TraitorFinder", 0, true, false)
cHack.Misc.Vars["Deaths"] = CreateClientConVar("cHack_Misc_Deaths", 0, true, false)
cHack.Misc.Vars["Sounds"] = CreateClientConVar("cHack_Misc_Sounds", 0, true, false)

cHack.Style = {}
cHack.Style.Vars = {}
cHack.Style.Vars["BoundingBox"] = {}
cHack.Style.Vars["BoundingBox"].var = CreateClientConVar("cHack_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
cHack.Style.Vars["BoundingBox"].color = cHack.GetColorFromString(cHack.Style.Vars["BoundingBox"].var:GetString())
cHack.Style.Vars["ESPText"] = {}
cHack.Style.Vars["ESPText"].var = CreateClientConVar("cHack_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
cHack.Style.Vars["ESPText"].color = cHack.GetColorFromString(cHack.Style.Vars["ESPText"].var:GetString())
cHack.Style.Vars["Crosshair"] = {}
cHack.Style.Vars["Crosshair"].var = CreateClientConVar("cHack_Style_Cross", "Color(255, 255, 255, 255)", true, false)
cHack.Style.Vars["Crosshair"].color = cHack.GetColorFromString(cHack.Style.Vars["Crosshair"].var:GetString())
cHack.Style.Vars["BodyText"] = {}
cHack.Style.Vars["BodyText"].var = CreateClientConVar("cHack_Style_BodyText", "Color(255, 255, 255, 255)", true, false)
cHack.Style.Vars["BodyText"].color = cHack.GetColorFromString(cHack.Style.Vars["BodyText"].var:GetString())
cHack.Style.Vars["Chams"] = {}
cHack.Style.Vars["Chams"].var = CreateClientConVar("cHack_Style_Chams", "Color(0, 255, 0, 255)", true, false)
cHack.Style.Vars["Chams"].color = cHack.GetColorFromString(cHack.Style.Vars["Chams"].var:GetString())
cHack.Style.Vars["BodyChams"] = {}
cHack.Style.Vars["BodyChams"].var = CreateClientConVar("cHack_Style_BodyChams", "Color(0, 255, 0, 255)", true, false)
cHack.Style.Vars["BodyChams"].color = cHack.GetColorFromString(cHack.Style.Vars["BodyChams"].var:GetString())

//This loads our friends list and custom entities list.
/*cHack.SavedData = CreateClientConVar("cHack_SaveData", cHack.RandomName(math.random(10, 15)), true, false)
if file.Exists(cHack.SavedData:GetString()..".txt", "DATA") then
	local info = string.Explode("\n", file.Read(cHack.SavedData:GetString()..".txt", "DATA"))
	if type(info) == "table" and info[1] and info[2] then
		cHack.Friends.List = util.JSONToTable(info[1])
		cHack.Entities.List = util.JSONToTable(info[2])
	end
end

cHack.SaveData = function()
	file.Write(cHack.SavedData:GetString()..".txt", util.TableToJSON(cHack.Friends.List))
	file.Append(cHack.SavedData:GetString()..".txt", "\n")
	file.Append(cHack.SavedData:GetString()..".txt", util.TableToJSON(cHack.Entities.List))
end*/

//This is all the bones i look for in the order im looking for them. Feel free to change the order if you want to attack the foot before the head or something like that.
cHack.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}

//If random bones is enabled this list is gone through, randomly, and if none of the bones on this list are found the entire list (above) is gone through.
//If you edit this be sure to edit the function below it.
cHack.RandomBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_L_UpperArm"
}
cHack.GetRandomBones = function()
	local temp = {}
	local function GetBones() //Ahh recursion, i love you.
		if #cHack.RandomBones > 0 then
			local random = math.random(1, #cHack.RandomBones)
			table.insert(temp, cHack.RandomBones[random])
			table.remove(cHack.RandomBones, random)
			GetBones()
		else
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_Head1")
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_Neck1")
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_Spine4")
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_Spine2")
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_R_UpperArm")
			table.insert(cHack.RandomBones, "ValveBiped.Bip01_L_UpperArm")
		end
	end
	GetBones()
	return temp
end

//A list of all keyboard keys, for binding
cHack.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
//[104] = "KEY_CAPSLOCKTOGGLE", //THESE
//[105] = "KEY_NUMLOCKTOGGLE", //MOFOS
//[106] = "KEY_SCROLLLOCKTOGGLE", //SHOULD DIE
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}
//A list of all mouse keys, for binding
cHack.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",
[111] = "MOUSE_5"
}
//Tells me if a specific key is pressed. Loops through both tables.
cHack.KeyPressed = function(key)
	if cHack.InChat then return false end
	
	for k = 107, 111 do
		if key == cHack.MouseKeys[k] then
			if input.IsMouseDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	for k = 0, 130 do
		if key == cHack.Keys[k] then
			if input.IsKeyDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	return false
end

//Very simple. If the boolean is true it returns 1. If the boolean is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill leave it here.
cHack.BoolToInt = function(bool)
	if bool then 
		return 1
	else
		return 0
	end
end

//Checking if a bone is visible, pos is the position of the bone and ent is the entity whos bone were looking for. 
cHack.SpotIsVisible = function(pos, ent)
	ent = ent or cHack.Aimbot.CurTarget
	local tracedata = {}
	tracedata.start = cHack.Ply:GetShootPos()
	tracedata.endpos = pos
	tracedata.filter = {cHack.Ply, ent}
	
	local trace = util.TraceLine(tracedata)
	if trace.HitPos:Distance(pos) < 0.005 then
		return true
	else
		return false
	end
end

//Checks all of the entities bones to find if we can see this entity or not.
cHack.CanSee = function(ent)
	for k = 1, #cHack.Bones do 
		local v = cHack.Bones[k]
		local bone = ent:LookupBone(v)
		if bone != nil then
			local pos, ang = ent:GetBonePosition(bone)
			if cHack.SpotIsVisible(pos, ent) then
				return true
			end
		end
	end
	return false
end

//This returns the next entity we should attack.
cHack.GetTarget = function()
	if cHack.Aimbot.Vars["AttackNPCs"]:GetBool() or cHack.Aimbot.Vars["AttackPlayers"]:GetBool() then
		local targets = {}
		local everything = ents.GetAll()
		for k = 1, #everything do 
			local v = everything[k]
			if cHack.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
				if cHack.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			elseif cHack.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != cHack.Ply then
				if cHack.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			end
		end
		
		for k,v in SortedPairs(targets, true) do //It will already be sorted so this shouldn't be too resource heavy, the main point of this is to loop through the table backwards
			local v = v["Target"]
			local shouldremove = false
			if cHack.Aimbot.Vars["IgnoreTeam"]:GetBool() and v:IsPlayer() then
				if cHack.TTT then
					if cHack.Ply:GetRole() == 1 and v:GetRole() == 1 then
						shouldremove = true
					end
						
					if cHack.Ply:GetRole() != 1 and not table.HasValue(cHack.Traitors, v) then
						shouldremove = true
					end
				else
					if v:Team() == cHack.Ply:Team() then
						shouldremove = true
					end
				end
			end
			
			if cHack.Friends.Vars["Active"]:GetBool() then
				if cHack.Friends.Vars["Reverse"]:GetBool() then
					if not table.HasValue(cHack.Friends.List, v:SteamID()) then
						shouldremove = true
					end
				else
					if table.HasValue(cHack.Friends.List, v:SteamID()) then
						shouldremove = true		
					end
				end
			end
			
			if shouldremove then
				table.remove(targets, k)
			end
		end
		
		if #targets == 0 then 
			return nil
		elseif #targets == 1 then
			targets[1]["Target"].BoneToAimAt = nil
			return targets[1]["Target"]
		end
		
		if cHack.Aimbot.Vars["Preferance"]:GetString() == "Distance" then
			local min = {["Distance"] = cHack.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local distance = cHack.Ply:GetPos():Distance(v["Pos"])
				if distance < min["Distance"] then
					min = {["Distance"] = distance, ["Target"] = v["Target"]}
				end
			end
			min["Target"].BoneToAimAt = nil
			return min["Target"]
		elseif cHack.Aimbot.Vars["Preferance"]:GetString() == "Angle" then		
			local min = {["Angle"] = cHack.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local angle = cHack.AngleTo(v["Pos"])
				if angle < min["Angle"] then
					min = {["Angle"] = angle, ["Target"] = v["Target"]}
				end
			end
			min["Target"].BoneToAimAt = nil
			return min["Target"]
		end
	else
		return nil
	end
end

//This returns the total angle away from the target we are, and then the pitch and yaw seperately
cHack.AngleTo = function(pos)
	local myAngs = cHack.Ply:GetAngles()
	local needed = (pos - cHack.Ply:GetShootPos()):Angle()
	
	myAngs.p = math.NormalizeAngle(myAngs.p)
	needed.p = math.NormalizeAngle(needed.p)
	
	myAngs.y = math.NormalizeAngle(myAngs.y)
	needed.y = math.NormalizeAngle(needed.y)
	
	local p = math.NormalizeAngle(needed.p - myAngs.p)
	local y = math.NormalizeAngle(needed.y - myAngs.y)
	
	return math.abs(p) + math.abs(y), {p = p, y = y}
end

//Returns true if our target meets our preferances.
cHack.ValidTarget = function()
	if cHack.Aimbot.CurTarget == nil then return false end
	if not IsValid(cHack.Aimbot.CurTarget) then return false end
	if cHack.Aimbot.CurTarget:IsPlayer() and (not cHack.Aimbot.CurTarget:Alive() or cHack.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or cHack.Aimbot.CurTarget:Health() < 1) then return false end
	if not cHack.Aimbot.Vars["AttackNPCs"]:GetBool() and cHack.Aimbot.CurTarget:IsNPC() then return false end
	if not cHack.Aimbot.Vars["AttackPlayers"]:GetBool() and cHack.Aimbot.CurTarget:IsPlayer() then return false end
	if not cHack.CanSee(cHack.Aimbot.CurTarget) then return false end
	if cHack.Aimbot.Vars["IgnoreTeam"]:GetBool() and cHack.Aimbot.CurTarget:IsPlayer() then
		if cHack.TTT then
			if cHack.Ply:GetRole() == 1 and cHack.Aimbot.CurTarget:GetRole() == 1 then return false end				
			if cHack.Ply:GetRole() != 1 and not table.HasValue(cHack.Traitors, cHack.Aimbot.CurTarget) then return false end
		else
			if cHack.Aimbot.CurTarget:Team() == cHack.Ply:Team() then return false end
		end
	end
	
	return true
end

hook.Add("RenderScreenspaceEffects", cHack.RandomName(math.random(10, 15)), function()
	if cHack.Active:GetBool() then
		local everything = ents.GetAll()
		for k = 1, #everything do
			local v = everything[k]
			
			if cHack.Chams.Vars["Active"]:GetBool() and v != cHack.Ply and (cHack.Chams.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(cHack.Ply:GetPos()) < cHack.Chams.Vars["MaxDistance"]:GetInt()) then
				cam.Start3D(EyePos(), EyeAngles())
					if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and cHack.Chams.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and cHack.Chams.Vars["NPCs"]:GetBool()) then
						local color = cHack.Style.Vars["Chams"].color
						if cHack.Chams.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
							color = team.GetColor(v:Team())
							if cHack.TTT then
								if v:GetRole() == 2 then
									color = Color(0, 0, 255, 255)
								elseif table.HasValue(cHack.Traitors, v) then
									color = Color(255, 0, 0, 255)
								else
									color = Color(0, 255, 0, 255)
								end
							end
						end
						render.SuppressEngineLighting(true)
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(cHack.Chams.Mat)
						v:DrawModel()
						
						render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)						
						if IsValid(v:GetActiveWeapon()) and cHack.Chams.Vars["Weapons"]:GetBool() then
							v:GetActiveWeapon():DrawModel() 
						end
						
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					elseif cHack.TTT and cHack.Chams.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
						local color = cHack.Style.Vars["BodyChams"].color
						render.SuppressEngineLighting(true)	
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(cHack.Chams.Mat)
						v:DrawModel()	
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					elseif cHack.Entities.Vars["Active"]:GetBool() and table.HasValue(cHack.Entities.List, v:GetClass()) then
						local color = cHack.Style.Vars["Chams"].color					
						render.SuppressEngineLighting(true)	
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(cHack.Chams.Mat)
						v:DrawModel()	
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					end
				cam.End3D()
			end
		end
	end
end)

//Helper function on radar. I just copied this one from the wiki.
cHack.DrawFilledCircle = function(x, y, radius, quality)
	local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality 
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
	surface.DrawPoly(circle)
end

//Another helper fuction on the radar.
cHack.DrawArrow = function(x, y, myRotation)
	local arrow = {}	
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	
	//Now that i have the arrow determined, i have to rotate it to match the targets angle
	myRotation = myRotation * -1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		
		theirX = theirX - x
		theirY = theirY - y
		
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end

	surface.DrawPoly(arrow)
end

cHack.Traitors = {}
cHack.SuperAdmins = {}
cHack.Admins = {}
cHack.Spectators = {}
local radarX, radarY, radarWidth, radarHeight = 100, 200, 150, 150
hook.Add("HUDPaint", cHack.RandomName(math.random(10, 15)), function()
	if cHack.Active:GetBool() then	
		local everything = ents.GetAll()
		
		if cHack.ESP.Vars["Active"]:GetBool() and cHack.ESP.Vars["Radar"]:GetBool() then //Setting up the background here. And since the ESP doesnt draw you 
			draw.RoundedBox(0, radarX, radarY, radarWidth, radarHeight, Color(100, 100, 100, 255 ))
			draw.NoTexture()
			if cHack.ESP.Vars["TeamBased"]:GetBool() then
				local color = team.GetColor(cHack.Ply:Team())
				if cHack.TTT then
					if cHack.Ply:GetRole() == 2 then
						color = Color(0, 0, 255, 255)
					elseif cHack.Ply:GetRole() == 1 then
						color = Color(255, 0, 0, 255)
					else
						color = Color(0, 255, 0, 255)
					end
				end
				surface.SetDrawColor(color)
			else
				surface.SetDrawColor(cHack.Style.Vars["ESPText"].color)
			end
			cHack.DrawArrow(radarX + (radarWidth / 2), radarY + (radarHeight / 2), 0)
		end
		
		for k = 1, #everything do
			local v = everything[k]
		
			if cHack.ESP.Vars["Active"]:GetBool() and v != cHack.Ply and (cHack.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(cHack.Ply:GetPos()) < cHack.ESP.Vars["MaxDistance"]:GetInt()) then										
				if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and cHack.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and cHack.ESP.Vars["NPCs"]:GetBool()) then
					local color = cHack.Style.Vars["ESPText"].color
					if cHack.ESP.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
						color = team.GetColor(v:Team())
						if cHack.TTT then
							if v:GetRole() == 2 then
								color = Color(0, 0, 255, 255)
							elseif table.HasValue(cHack.Traitors, v) then
								color = Color(255, 0, 0, 255)
							else
								color = Color(0, 255, 0, 255)
							end
						end
					end
					
					local Min, Max = v:GetCollisionBounds()
					if cHack.ESP.Vars["Box"]:GetBool() then
						local one = v:LocalToWorld(Min):ToScreen()
						local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
						local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
						local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
						local five = v:LocalToWorld(Max):ToScreen()
						local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
						local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
						local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()				
						
						if cHack.ESP.Vars["TeamBased"]:GetBool() then
							surface.SetDrawColor(color)
						else
							surface.SetDrawColor(cHack.Style.Vars["BoundingBox"].color)
						end
						local function connect(tabone, tabtwo)
							surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
						end
						
						connect(one, two)
						connect(three, eight)
						connect(four, seven)
						connect(six, five)
						connect(four, six)
						connect(four, one)
						connect(one, three)
						connect(three, six)
						connect(five, eight)
						connect(eight, two)
						connect(two, seven)
						connect(seven, five)
					end
					
					surface.SetFont("ESPFont")
					local top = v:GetPos() + Vector(0, 0, Max.z + 10) // A little above their head so its not constantly covering their face.
					local topscreen = top:ToScreen()
					local topy = topscreen.y
					
					local bottom = v:GetPos()
					local bottomscreen = bottom:ToScreen()
					local bottomy = bottomscreen.y
					
					local function DrawAbove(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(topscreen.x - W / 2, topy) 
						surface.DrawText(text)
						
						topy = topy + H
					end
					
					local function DrawBelow(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(bottomscreen.x - W / 2, bottomy) 
						surface.DrawText(text)
						
						bottomy = bottomy + H
					end
					
					surface.SetTextColor(Color(255, 0, 0, 255))
					if cHack.ESP.Vars["ShowTraitors"]:GetString() != "Off" and table.HasValue(cHack.Traitors, v) then
						if cHack.ESP.Vars["ShowTraitors"]:GetString() == "Above" then
							DrawAbove("Traitor")
						else
							DrawBelow("Traitor")
						end
					end
					
					surface.SetTextColor(color)
					if v:IsPlayer() then
						if cHack.ESP.Vars["Name"]:GetString() == "Above" then
							DrawAbove("Name: "..v:Nick())
						elseif cHack.ESP.Vars["Name"]:GetString() == "Below" then
							DrawBelow("Name: "..v:Nick())
						end
					else
						if cHack.ESP.Vars["Name"]:GetString() == "Above" then
							DrawAbove("Name: "..v:GetClass())
						elseif cHack.ESP.Vars["Name"]:GetString() == "Below" then
							DrawBelow("Name: "..v:GetClass())
						end
					end
					
					if cHack.ESP.Vars["Weapons"]:GetString() == "Above" and IsValid(v:GetActiveWeapon()) then
						DrawAbove("Weapon: "..v:GetActiveWeapon():GetClass()) 
					elseif cHack.ESP.Vars["Weapons"]:GetString() == "Below" and IsValid(v:GetActiveWeapon()) then
						DrawBelow("Weapon: "..v:GetActiveWeapon():GetClass()) 
					end		
					
					if cHack.ESP.Vars["Distance"]:GetString() == "Above" then 
						DrawAbove("Distance: "..bottom:Distance(cHack.Ply:GetPos())) 
					elseif cHack.ESP.Vars["Distance"]:GetString() == "Below" then
						DrawBelow("Distance: "..bottom:Distance(cHack.Ply:GetPos())) 
					end	
					
					if cHack.ESP.Vars["Health"]:GetString() == "Above" then 
						DrawAbove("HP: "..v:Health()) 
					elseif cHack.ESP.Vars["Health"]:GetString() == "Below" then
						DrawBelow("HP: "..v:Health()) 
					end
					
					if cHack.ESP.Vars["Radar"]:GetBool() then
						surface.SetDrawColor(color)
						local myPos = cHack.Ply:GetPos()
						local theirPos = v:GetPos()
						local myAngles = cHack.Ply:GetAngles()
						
						local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / cHack.ESP.Vars["RadarScale"]:GetInt())
						local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / cHack.ESP.Vars["RadarScale"]:GetInt())
						
						//Now i have to rotate this
						local myRotation = myAngles.y - 90
						myRotation = math.rad(myRotation)
						
						theirX = theirX - (radarX + (radarWidth / 2))
						theirY = theirY - (radarY + (radarHeight / 2))
						local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
						local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
						newX = newX + (radarX + (radarWidth / 2))
						newY = newY + (radarY + (radarHeight / 2))
						
						//And now that its rotated i can check if its within our radars bounds and draw it
						if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
							cHack.DrawArrow(newX, newY, v:EyeAngles().y - myAngles.y)
						end
					end
				elseif cHack.TTT and cHack.ESP.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
					surface.SetFont("ESPFont")
					
					//Im just going to position this info at the center of the player, if i get any complaints ill change it
					local pos = v:LocalToWorld(v:OBBCenter())
					local poscreen = pos:ToScreen()
					local W, H = surface.GetTextSize("Sample") //It doesnt have to be perfect but this will help center the text more.
					local y = poscreen.y - (H * 1.5)
					
					local function DrawText(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(poscreen.x - W / 2, y) 
						surface.DrawText(text)
						
						y = y + H
					end
					
					surface.SetTextColor(cHack.Style.Vars["BodyText"].color)
					DrawText("Credits: "..cHack.TTTCORPSE.GetCredits(v, 0))
					DrawText("Name: "..cHack.TTTCORPSE.GetPlayerNick(v, "Unknown"))
					DrawText("Found: "..tostring(cHack.TTTCORPSE.GetFound(v, false)))
					
					if cHack.ESP.Vars["Radar"] then
						surface.SetDrawColor(cHack.Style.Vars["BodyText"].color)
						local myPos = cHack.Ply:GetPos()
						local theirPos = v:GetPos()
						
						local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / cHack.ESP.Vars["RadarScale"]:GetInt())
						local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / cHack.ESP.Vars["RadarScale"]:GetInt())
						
						//Now i have to rotate this
						local myRotation = cHack.Ply:GetAngles().y - 90
						myRotation = math.rad(myRotation)
						
						theirX = theirX - (radarX + (radarWidth / 2))
						theirY = theirY - (radarY + (radarHeight / 2))
						local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
						local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
						newX = newX + (radarX + (radarWidth / 2))
						newY = newY + (radarY + (radarHeight / 2))
						
						//And now that its rotated i can check if its within our radars bounds and draw it
						if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
							cHack.DrawFilledCircle(newX, newY, 2, 4)
						end
					end
				elseif cHack.Entities.Vars["Active"]:GetBool() and table.HasValue(cHack.Entities.List, v:GetClass()) then
					surface.SetFont("ESPFont")
					surface.SetTextColor(cHack.Style.Vars["ESPText"].color)
					
					local text = v:GetClass()
					local W, H = surface.GetTextSize(text)
					
					local PosScreen = v:GetPos():ToScreen()
					surface.SetTextPos(PosScreen.x - W / 2, PosScreen.y) 
					surface.DrawText(text)
				end
			end
			
			surface.SetFont("default")
			if v:IsPlayer() and v:IsSuperAdmin() then
				if not table.HasValue(cHack.SuperAdmins, v) then
					table.insert(cHack.SuperAdmins, v) 
					cHack.Message("Super Admin "..v:Nick().." joined the game.")
					if cHack.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/Alyx/watchout02.wav")
					end	
				end
			end			
			if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
				if not table.HasValue(cHack.Admins, v) then
					table.insert(cHack.Admins, v)
					cHack.Message("Admin "..v:Nick().." joined the game.")
					if cHack.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/Alyx/watchout01.wav")
					end	
				end
			end		
			for k,v in SortedPairs(cHack.Admins, true) do
				if not IsValid(v) then
					table.remove(cHack.Admins, k)
				end
			end
			for k,v in SortedPairs(cHack.SuperAdmins, true) do
				if not IsValid(v) then
					table.remove(cHack.SuperAdmins, k)
				end
			end
				
			if v:IsPlayer() and v:GetObserverTarget() == cHack.Ply then
				if not table.HasValue(cHack.Spectators, v) then
					table.insert(cHack.Spectators, v)
					cHack.Message(v:Nick().." started spectating you.")
					if cHack.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/female01/ohno.wav")
					end				
				end
			end
			for k,v in SortedPairs(cHack.Spectators, true) do
				if IsValid(v) then
					if v:GetObserverTarget() != cHack.Ply then
						table.remove(cHack.Spectators, k)
					end
				else
					table.remove(cHack.Spectators, k)
				end
			end
			
			if cHack.TTT and cHack.Misc.Vars["TraitorFinder"]:GetBool() then
				if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
					local owner = v:GetOwner()
					if owner:GetRole() == 2 then
						v.Buyer = owner
					else
						cHack.Message(owner:Nick().." bought a traitor weapon: "..v:GetClass())
						v.Buyer = owner
						table.insert(cHack.Traitors, owner)
						if cHack.Misc.Vars["Sounds"]:GetBool() then
							surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
						end	
					end
				elseif GetRoundState() != 3 then
					table.Empty(cHack.Traitors)
				end
			end
			
			if cHack.Misc.Vars["Deaths"]:GetBool() and v:IsPlayer() then
				if v:Alive() then
					v.IsAlive = true
				elseif v.IsAlive then
					cHack.Message(3, v:Nick().." just died.")
					v.IsAlive = false
					if cHack.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("npc/combine_soldier/vo/onedown.wav")
					end	
				end				
			end
		end
		
		surface.SetFont("default")
		surface.SetTextColor(Color(255, 255, 255, 255))	
		local AdminWidest = 0
		local AdminTotalHeight = 0
		local AdminHeight = 20
		if cHack.Misc.Vars["ShowAdmins"]:GetBool() then 
			for k,v in pairs(cHack.SuperAdmins) do
				local W, H = surface.GetTextSize(v:Nick().." - Super Admin")
				if W > AdminWidest then
					AdminWidest = W
				end
				AdminTotalHeight = AdminTotalHeight + H
			end
			for k,v in pairs(cHack.Admins) do
				local W, H = surface.GetTextSize(v:Nick().." - Admin")
				if W > AdminWidest then
					AdminWidest = W
				end
				AdminTotalHeight = AdminTotalHeight + H
			end
			draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
			for k,v in pairs(cHack.SuperAdmins) do
				local text = v:Nick().." - Super Admin"
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
				surface.DrawText(text)
				AdminHeight = AdminHeight + H
			end
			for k,v in pairs(cHack.Admins) do
				local text = v:Nick().." - Admin"
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
				surface.DrawText(text)
				AdminHeight = AdminHeight + H
			end
		end
		
		local SpecWidest = 0
		local SpecTotalHeight = 0
		local SpecHeight = AdminTotalHeight + 50
		if cHack.Misc.Vars["ShowSpectators"]:GetBool() then
			for k,v in pairs(cHack.Spectators) do
				local W, H = surface.GetTextSize(v:Nick())
				if W > SpecWidest then
					SpecWidest = W
				end
				SpecTotalHeight = SpecTotalHeight + H
			end
			draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
			for k,v in pairs(cHack.Spectators) do
				local text = v:Nick()
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
				surface.DrawText(text)
				SpecHeight = SpecHeight + H
			end
		end
		
		if cHack.Misc.Vars["Crosshair"]:GetBool() then
			local size = cHack.Misc.Vars["CrosshairSize"]:GetInt()
			local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
			surface.SetDrawColor(cHack.Style.Vars["Crosshair"].color)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - size, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - size)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + size, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + size)
		end
	end
end)

hook.Add("Think", cHack.RandomName(math.random(10, 15)), function()
	if cHack.Active:GetBool() then	
		if cHack.Aimbot.Vars["Active"]:GetBool() and not (cHack.Aimbot.Vars["PanicMode"]:GetBool() and #cHack.Spectators > 0) then
			if not cHack.Aimbot.Vars["AimOnKey"]:GetBool() or (cHack.Aimbot.Vars["AimOnKey"]:GetBool() and cHack.KeyPressed(cHack.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
				if cHack.ValidTarget() then
					local BoneOrder = {}
					if cHack.Aimbot.CurTarget.BoneToAimAt and cHack.Aimbot.Vars["RandomBones"]:GetBool() then
						table.insert(BoneOrder, cHack.Aimbot.CurTarget.BoneToAimAt)
						table.Add(BoneOrder, cHack.GetRandomBones())
						table.Add(BoneOrder, cHack.Bones)
					else
						if cHack.Aimbot.Vars["RandomBones"]:GetBool() then
							table.Add(BoneOrder, cHack.GetRandomBones())
							table.Add(BoneOrder, cHack.Bones)
						else
							table.Add(BoneOrder, cHack.Bones)
						end
					end
					for k = 1, #BoneOrder do 
						local v = BoneOrder[k]
						local bone = cHack.Aimbot.CurTarget:LookupBone(v)
						if bone != nil then
							local pos, ang = cHack.Aimbot.CurTarget:GetBonePosition(bone)
							if v == "ValveBiped.Bip01_Head1" then
								pos = pos + Vector(0, 0, 3) //Aiming a little higher for the head
							end
							local total, needed = 300, {300, 300}
							
							if cHack.Aimbot.Vars["Prediction"]:GetBool() then
								local tarSpeed = cHack.Aimbot.CurTarget:GetVelocity() * 0.013
								local plySpeed = cHack.Ply:GetVelocity() * 0.013
								total, needed = cHack.AngleTo(pos - plySpeed + tarSpeed)
							else
								total, needed = cHack.AngleTo(pos)
							end
								
							if cHack.SpotIsVisible(pos) and total < cHack.Aimbot.Vars["MaxAngle"]:GetInt() then
								local myAngles = cHack.Ply:GetAngles()								
								local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
								
								if cHack.Aimbot.Vars["AntiSnap"]:GetBool() then
									local speed = cHack.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
									NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
								end
								
								cHack.Ply:SetEyeAngles(NewAngles)
								cHack.Aimbot.CurTarget.BoneToAimAt = BoneOrder[k]
								break
							end
						end
					end
				else
					cHack.Aimbot.CurTarget = cHack.GetTarget()
				end
			else
				cHack.Aimbot.CurTarget = nil
			end
		end
		
		if cHack.Misc.Vars["NoRecoil"]:GetBool() then
			if IsValid(cHack.Ply:GetActiveWeapon()) then
				local weapon = cHack.Ply:GetActiveWeapon()
				if weapon.Primary then
					weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
					weapon.Primary.Recoil = 0
					weapon.Recoil = 0
				else
					weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
					weapon.Recoil = 0
				end
			end
		elseif IsValid(cHack.Ply:GetActiveWeapon()) then
			local weapon = cHack.Ply:GetActiveWeapon()
			if weapon.Primary then
				weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
			else
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil
			end
		end
		
		if cHack.DarkRP and cHack.Misc.Vars["BuyHealth"]:GetBool() then
			if cHack.Ply:Alive() and cHack.Ply:Health() < cHack.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
				cHack.Ply:ConCommand("say /buyhealth")
			end
		end
	end
end)

cHack.Misc.NextReload = CurTime()
cHack.Misc.ShootNext = true
hook.Add("CreateMove", cHack.RandomName(math.random(10, 15)), function(cmd)
	if cHack.Active:GetBool() then		
		local DontShoot = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon"}
		if cHack.Aimbot.Vars["AutoShoot"]:GetBool() and cHack.Aimbot.Vars["Active"]:GetBool() and cHack.Ply:GetEyeTrace().Entity == cHack.Aimbot.CurTarget and IsValid(cHack.Ply:GetActiveWeapon()) and not table.HasValue(DontShoot, cHack.Ply:GetActiveWeapon():GetClass()) then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
		end
		
		if cHack.Misc.Vars["BunnyHop"]:GetBool() and cmd:KeyDown(IN_JUMP) and cHack.KeyPressed(cHack.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
		end
		if cHack.Misc.Vars["BunnyHop"]:GetBool() and cHack.Ply:OnGround() and cHack.KeyPressed(cHack.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
		end
		
		local DontReload = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon", "weapon_crowbar"}
		if cHack.Misc.Vars["AutoReload"]:GetBool() and IsValid(cHack.Ply:GetActiveWeapon()) and cHack.Ply:GetActiveWeapon():Clip1() < 1 and not table.HasValue(DontReload, cHack.Ply:GetActiveWeapon():GetClass()) and cHack.Misc.NextReload < CurTime() then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
		
		if cHack.Misc.Vars["AutoPistol"]:GetBool() and IsValid(cHack.Ply:GetActiveWeapon()) then
			local weapon = cHack.Ply:GetActiveWeapon()
			if weapon.Primary and type(weapon.Primary.Automatic) == "boolean" and not weapon.Primary.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if cHack.Misc.ShootNext then
						cHack.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						cHack.Misc.ShootNext = true
					end
				end					
			elseif type(weapon.Automatic) == "boolean" and not weapon.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if cHack.Misc.ShootNext then
						cHack.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						cHack.Misc.ShootNext = true
					end
				end
			end
		end
	end
end)

//Used to see if the player is typing in chat or not. Binds arent called when you're in chat.
cHack.InChat = false
hook.Add("StartChat", cHack.RandomName(math.random(10, 15)), function()
	cHack.InChat = true
end)
hook.Add("FinishChat", cHack.RandomName(math.random(10, 15)), function()
	cHack.InChat = false
end) 

concommand.Add("cHack_Menu", function()
	//Im only using DColumnSheet because everyone used DPropertySheet. I just want to be different
	local main = vgui.Create("DFrame")
	main:SetSize(500,496)
	main:Center()
	main:SetTitle("")
	main:MakePopup()
	main:ShowCloseButton(false)
	main.Paint = function()
		draw.RoundedBox( 0, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
	end
	
	local PanicButton = vgui.Create("DButton", main)
	PanicButton:SetSize(50, 20)
	PanicButton:SetPos(415, 3)
	local function Enable()
		PanicButton:SetText("Disable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Enable")
			PanicButton.DoClick = Enable
			cHack.Ply:ConCommand("cHack_Active 0")
		end
		cHack.Ply:ConCommand("cHack_Active 1")
	end
	local function Disable()
		PanicButton:SetText("Enable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Disable")
			PanicButton.DoClick = Disable
			cHack.Ply:ConCommand("cHack_Active 1")
		end
		cHack.Ply:ConCommand("cHack_Active 0")
	end
	if cHack.Active:GetBool() then
		PanicButton:SetText("Disable")
		PanicButton.DoClick = Disable
	else
		PanicButton:SetText("Enable")
		PanicButton.DoClick = Enable
	end
	
	local CloseButton = vgui.Create("DButton", main)
	CloseButton:SetSize(30, 20)
	CloseButton:SetPos(465, 3)
	CloseButton:SetText("X")
	CloseButton.DoClick = function()
		main:Close()
	end
	
	local title = vgui.Create("DLabel", main)
	title:SetColor(Color(255, 255, 255, 255))
	title:SetFont("TitleFont")
	title:SetText("cHack - "..cHack.Version)
	title:SizeToContents()
	title:SetPos(main:GetWide() / 2 - title:GetWide() / 2,3)	
	
	ColumnSheet = vgui.Create("DColumnSheet",main)
	ColumnSheet:SetPos(5, 25)
	ColumnSheet:SetSize(500 ,465)
	
	local y = 40
	local function ToggleOption(name, parent, var)
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:AddChoice("Off", 0)
		Options:AddChoice("On", 1)
		Options.OnSelect = function(panel,index,value,data)
			cHack.Ply:ConCommand(var.." "..data)
		end
		Options:SetText(Options:GetOptionText(GetConVar(var):GetInt() + 1))
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function SetKeyOption(name, parent, var)		
		local Options = vgui.Create("DButton", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetText(GetConVar(var):GetString())
		Options.DoClick = function()
			Options:SetText("Press a key...")
			Options.Think = function()
				for k = 107, 111 do
					if input.IsMouseDown(k) then
						cHack.Ply:ConCommand(var.." "..cHack.MouseKeys[k])
						Options:SetText(cHack.MouseKeys[k])
						Options.Think = nil
					end
				end
				
				for k = 0, 130 do
					if input.IsKeyDown(k) then
						cHack.Ply:ConCommand(var.." "..cHack.Keys[k])
						Options:SetText(cHack.Keys[k])
						Options.Think = nil
					end
				end 
			end
		end
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function SetNumberOption(name, parent, var, min, max, decimals)		
		local Options = vgui.Create("DNumberWang", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetMin(min)
		Options:SetMax(max)
		Options:SetDecimals(decimals)
		Options:SetConVar(var)
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function MultiOption(name, parent, var, tab)		
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		for i = 1, #tab do
			Options:AddChoice(tab[i])
		end
		Options.OnSelect = function(panel,index,value,data)
			cHack.Ply:ConCommand(var.." "..value)
		end
		Options:SetText(GetConVar(var):GetString())
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	//Starting the Aimbot panel
	local Aimbot = vgui.Create("DPanel")
	Aimbot:SetSize(379, 465)
	Aimbot.Paint = function()
		draw.RoundedBox( 0, 0, 0, Aimbot:GetWide(), Aimbot:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Aimbot)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Aimbot")
	title:SizeToContents()
	title:SetPos(Aimbot:GetWide() / 2 - title:GetWide() / 2, 0)
	
	ToggleOption("Active", Aimbot, "cHack_Aimbot_Active")
	ToggleOption("Random Bones", Aimbot, "cHack_Aimbot_RandomBones")
	MultiOption("Preferance", Aimbot, "cHack_Aimbot_Preferance", {"Distance", "Angle"})	
	ToggleOption("Attack Players", Aimbot, "cHack_Aimbot_AttackPlayers")
	ToggleOption("Attack NPCs", Aimbot, "cHack_Aimbot_AttackNPCs")
	ToggleOption("Prediction", Aimbot, "cHack_Aimbot_Prediction")
	ToggleOption("Aim On Key", Aimbot, "cHack_Aimbot_AimOnKey")
	SetKeyOption("Key", Aimbot, "cHack_Aimbot_AimOnKey_Key")
	ToggleOption("Anti Snap", Aimbot, "cHack_Aimbot_AntiSnap")
	SetNumberOption("Anti Snap Speed", Aimbot, "cHack_Aimbot_AntiSnapSpeed", 1, 5, 2)
	SetNumberOption("Max Angle", Aimbot, "cHack_Aimbot_MaxAngle", 0, 270, 0)
	ToggleOption("Auto Shoot", Aimbot, "cHack_Aimbot_AutoShoot")
	ToggleOption("Panic Mode", Aimbot, "cHack_Aimbot_PanicMode")
	ToggleOption("Ignore Team", Aimbot, "cHack_Aimbot_IgnoreTeam")
	
	if y > 465 then
		Aimbot:SetTall(y)
	end
	
	//This is the best way i can find to add a scrollbar to the menu...
	AimbotList = vgui.Create( "DPanelList" )
	AimbotList:SetSize(379, 465)
	AimbotList:SetSpacing(0)
	AimbotList:EnableHorizontal(false)
	AimbotList:EnableVerticalScrollbar(true)
	AimbotList:AddItem(Aimbot)
	
	ColumnSheet:AddSheet("Aimbot", AimbotList, "icon16/application_xp_terminal.png")
	
	//Starting the Friends panel
	local FriendsPanel = vgui.Create("DPanel")
	FriendsPanel:SetSize(379, 465)
	FriendsPanel.Paint = function()
		draw.RoundedBox( 0, 0, 0, FriendsPanel:GetWide(), FriendsPanel:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", FriendsPanel)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Friends")
	title:SizeToContents()
	title:SetPos(FriendsPanel:GetWide() / 2 - title:GetWide() / 2, 3)
	
	local Friends = {}
	local Enemies = {}
	
	local players = player.GetAll()
	for k = 1, #players do
		local v = players[k]
		if v != cHack.Ply then
			if table.HasValue(cHack.Friends.List, v:SteamID()) then
				table.insert(Friends, v)
			else
				table.insert(Enemies, v)
			end
		end
	end
	
	y = 40
	local EnemiesList = vgui.Create("DListView", FriendsPanel) //Need this up here so FriendsList can reference it.	
	local FriendsList = vgui.Create("DListView", FriendsPanel)
	FriendsList:SetSize(150, 200)
	FriendsList:SetPos(FriendsPanel:GetWide() * 0.25 - FriendsList:GetWide() / 2, y)
	FriendsList:SetMultiSelect(false)
	FriendsList:AddColumn("Friends")
	for k = 1, #Friends do
		FriendsList:AddLine(Friends[k]:Nick())
	end
	FriendsList.DoDoubleClick = function(panel, index, line)
		table.insert(Enemies, Friends[index])
		table.remove(Friends, index)
		
		FriendsList:Clear()
		EnemiesList:Clear()
		for k = 1, #Friends do
			FriendsList:AddLine(Friends[k]:Nick())
		end
		for k = 1, #Enemies do
			EnemiesList:AddLine(Enemies[k]:Nick())
		end
		
		cHack.Friends.List = {}
		for k = 1, #Friends do
			table.insert(cHack.Friends.List, Friends[k]:SteamID())
		end
		//cHack.SaveData()
	end
	
	EnemiesList:SetSize(150, 200)
	EnemiesList:SetPos(FriendsPanel:GetWide() * 0.75 - EnemiesList:GetWide() / 2, y)
	EnemiesList:SetMultiSelect(false)
	EnemiesList:AddColumn("Enemies")
	for k = 1, #Enemies do
		EnemiesList:AddLine(Enemies[k]:Nick())
	end
	EnemiesList.DoDoubleClick = function(panel, index, line)
		table.insert(Friends, Enemies[index])
		table.remove(Enemies, index)
		
		FriendsList:Clear()
		EnemiesList:Clear()
		for k = 1, #Friends do
			FriendsList:AddLine(Friends[k]:Nick())
		end
		for k = 1, #Enemies do
			EnemiesList:AddLine(Enemies[k]:Nick())
		end
		
		cHack.Friends.List = {}
		for k = 1, #Friends do
			table.insert(cHack.Friends.List, Friends[k]:SteamID())
		end
		//cHack.SaveData()
	end
	
	y = y + EnemiesList:GetTall() + 20
	ToggleOption("Use", FriendsPanel, "cHack_Friends_Active")
	ToggleOption("Reverse", FriendsPanel, "cHack_Friends_Reverse")
	
	if y > 465 then
		FriendsPanel:SetTall(y)
	end
	
	local FriendsPanelList = vgui.Create( "DPanelList" )
	FriendsPanelList:SetSize(379, 465)
	FriendsPanelList:SetSpacing(0)
	FriendsPanelList:EnableHorizontal(false)
	FriendsPanelList:EnableVerticalScrollbar(true)
	FriendsPanelList:AddItem(FriendsPanel)
	
	ColumnSheet:AddSheet("Friends", FriendsPanelList, "icon16/group.png")

	//Starting the ESP panel
	local ESP = vgui.Create("DPanel")
	ESP:SetSize(379, 465)
	ESP.Paint = function()
		draw.RoundedBox( 0, 0, 0, ESP:GetWide(), ESP:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", ESP)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("ESP")
	title:SizeToContents()
	title:SetPos(ESP:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", ESP, "cHack_ESP_Active")
	ToggleOption("Player Info", ESP, "cHack_ESP_Players")
	ToggleOption("NPC Info", ESP, "cHack_ESP_NPCs")
	MultiOption("Name", ESP, "cHack_ESP_Name", {"Off", "Above", "Below"})	
	MultiOption("Weapon", ESP, "cHack_ESP_Weapons", {"Off", "Above", "Below"})	
	MultiOption("Health", ESP, "cHack_ESP_Health", {"Off", "Above", "Below"})	
	MultiOption("Distance", ESP, "cHack_ESP_Distance", {"Off", "Above", "Below"})
	MultiOption("Show Traitors", ESP, "cHack_ESP_ShowTraitors", {"Off", "Above", "Below"})
	ToggleOption("Bounding Box", ESP, "cHack_ESP_Box")
	ToggleOption("Body Info", ESP, "cHack_ESP_Bodies")
	ToggleOption("2D Radar", ESP, "cHack_ESP_Radar")
	SetNumberOption("Radar Scale", ESP, "cHack_ESP_RadarScale", 1, 100, 0)
	SetNumberOption("Max Distance", ESP, "cHack_ESP_MaxDistance", 0, 8000, 0)
	ToggleOption("Team Based", ESP, "cHack_ESP_TeamBased")
	
	if y > 465 then
		ESP:SetTall(y)
	end
	
	ESPList = vgui.Create( "DPanelList" )
	ESPList:SetSize(379, 465)
	ESPList:SetSpacing(0)
	ESPList:EnableHorizontal(false)
	ESPList:EnableVerticalScrollbar(true)
	ESPList:AddItem(ESP)
	
	ColumnSheet:AddSheet("ESP", ESPList, "icon16/pencil.png")
	
	//Starting the Chams panel
	local Chams = vgui.Create("DPanel")
	Chams:SetSize(379, 465)
	Chams.Paint = function()
		draw.RoundedBox( 0, 0, 0, Chams:GetWide(), Chams:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Chams)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Chams")
	title:SizeToContents()
	title:SetPos(Chams:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", Chams, "cHack_Chams_Active")
	ToggleOption("Draw Players", Chams, "cHack_Chams_Players")
	ToggleOption("Draw NPCs", Chams, "cHack_Chams_NPCs")
	ToggleOption("Draw Weapons", Chams, "cHack_Chams_Weapons")
	ToggleOption("Draw Bodies", Chams, "cHack_Chams_Bodies")
	ToggleOption("Team Based", Chams, "cHack_Chams_TeamBased")
	SetNumberOption("Max Distance", Chams, "cHack_Chams_MaxDistance", 0, 8000, 0)
	
	if y > 465 then
		Chams:SetTall(y)
	end
	
	ChamsList = vgui.Create( "DPanelList" )
	ChamsList:SetSize(379, 465)
	ChamsList:SetSpacing(0)
	ChamsList:EnableHorizontal(false)
	ChamsList:EnableVerticalScrollbar(true)
	ChamsList:AddItem(Chams)
	
	ColumnSheet:AddSheet("Chams", ChamsList, "icon16/eye.png")
	
	//Starting the Finder panel
	local Finder = vgui.Create("DPanel")
	Finder:SetSize(379, 465)
	Finder.Paint = function()
		draw.RoundedBox( 0, 0, 0, Finder:GetWide(), Finder:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Finder)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Entity Finder")
	title:SizeToContents()
	title:SetPos(Finder:GetWide() / 2 - title:GetWide() / 2, 3)
	
	local ToShow = {}
	local Others = {}
	
	local All = ents.GetAll()
	for k = 1, #All do
		local v = All[k]
		if table.HasValue(cHack.Entities.List, v:GetClass()) then
			if not table.HasValue(ToShow, v:GetClass()) then
				table.insert(ToShow, v:GetClass())
			end
		elseif not table.HasValue(Others, v:GetClass()) then
			table.insert(Others, v:GetClass())
		end
	end
	
	y = 40
	local IgnoreList = vgui.Create("DListView", Finder) //Need this up here so ToShowList can reference it.	
	local ToShowList = vgui.Create("DListView", Finder)
	ToShowList:SetSize(150, 200)
	ToShowList:SetPos(Finder:GetWide() * 0.25 - ToShowList:GetWide() / 2, y)
	ToShowList:SetMultiSelect(false)
	ToShowList:AddColumn("To Show")
	for k = 1, #ToShow do
		ToShowList:AddLine(ToShow[k])
	end
	ToShowList.DoDoubleClick = function(panel, index, line)
		table.insert(Others, ToShow[index])
		table.remove(ToShow, index)
		
		ToShowList:Clear()
		IgnoreList:Clear()
		for k = 1, #ToShow do
			ToShowList:AddLine(ToShow[k])
		end
		for k = 1, #Others do
			IgnoreList:AddLine(Others[k])
		end
		
		cHack.Entities.List = {}
		for k = 1, #ToShow do
			table.insert(cHack.Entities.List, ToShow[k])
		end
		//cHack.SaveData()
	end
	
	IgnoreList:SetSize(150, 200)
	IgnoreList:SetPos(Finder:GetWide() * 0.75 - IgnoreList:GetWide() / 2, y)
	IgnoreList:SetMultiSelect(false)
	IgnoreList:AddColumn("Others")
	for k = 1, ��