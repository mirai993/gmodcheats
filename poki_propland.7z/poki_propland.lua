--[[
	autorun/client/PropLand.lua
	Master | (STEAM_0:1:22519569)
	===DStream===
]]

local function PropLand()
	local ply = LocalPlayer()
	local vel = ply:GetVelocity()
	local pos = ply:GetPos()
	ply:ConCommand("use weapon_physgun")

	local tr = {}
		tr.start = pos
		tr.endpos = pos - Vector(0, 0, 100)
		tr.filter = ply

	local trace = util.TraceLine(tr)

	local HitPos = trace.HitPos
	local ZDis = pos.z - HitPos.z

	if ZDis <= 100 and vel.z < -400 and trace.HitWorld then
		local ang = ply:EyeAngles()
		ply:SetEyeAngles(Angle(90, 0, 0))
		ply:ConCommand("gm_spawn " .. GetConVar("prop_land_prop"):GetString())
		timer.Simple(0.2, function()
			ply:ConCommand("+attack")
		end)
		timer.Simple(0.3, function()
			ply:ConCommand("+attack2")
		end)
		timer.Simple(0.4, function()
			ply:ConCommand("undo")
		end)
		timer.Simple(0.5, function()
			ply:ConCommand("-attack")
			ply:ConCommand("-attack2")
			ply:SetEyeAngles(ang)
			return
			hook.Remove("Tick", "PropLand")
		end)
	end
end

local function StartPropLand()
	hook.Add("Tick", "PropLand", PropLand)
end
local function EndPropLand()
	hook.Remove("Tick", "PropLand")
end

concommand.Add("+prop_land", StartPropLand)
concommand.Add("-prop_land", EndPropLand)
CreateClientConVar("prop_land_prop", "models/hunter/tubes/tube1x1x6.mdl", true, false)