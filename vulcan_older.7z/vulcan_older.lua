--[[
> VULCAN PK SCRIPT [Made by BrainFuck & Trial]
    - This script was made and designed exclusively for propkill. It has visuals, fov, bhop, and a few unique custom concepts I came up with a while ago.
	- We wanted to come up with visually unique looking script, not something similar to 99% of the other propkill scripts around.
    - This script won't help if you want to use it to cheat or be undetected on some other servers. (it will be detected anyways)
    - As this was mainly made for the propkill community, it COULD fuck your fps in case there would be too many players on the server you're on. (propkill servers are rarely very populated..)
	- Nevertheless, I added a few fps optimization shit to help you: 
			the fps saver convar, you should basically always keep this ON
			you can also disable the additional chams halos which is purely aesthetic and takes a lot of fps when there are too many players to render
	- I'll keep updating this script, according to the feedbacks I'll get. (it'll be on workshop too)
]]

-- BRAIN: STEAM_0:1:149906042
-- TRIAL: STEAM_0:1:68249268

// VULCAN
local Vulcan = {
	dangerous = false,
}

RunConsoleCommand("cl_updaterate", 1000)
RunConsoleCommand("cl_cmdrate", 0)
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("rate", 51200)
-- RunConsoleCommand("mat_fastspecular", 0)

CreateMaterial( "White9", "UnlitGeneric", { [ "$basetexture" ] = "models/debug/debugwhite", [ "$nocull" ] = 1, [ "$model" ] = 1 } ); -- fixing the debugwhite shit material

// CONVARS THERE
CreateClientConVar("VULCAN_bhop", 1, true, false)
CreateClientConVar("VULCAN_FOVEnable", 1, true, false)
CreateClientConVar("VULCAN_FOVNumber", "125", true, false)
CreateClientConVar("VULCAN_FOV_VELOCITY", 0, true, false)
CreateClientConVar("VULCAN_SAVEFPS", 1, true, false)

CreateClientConVar("VULCAN_tracers", 1, true, false)

CreateClientConVar("VULCAN_esp", 1, true, false)
CreateClientConVar("VULCAN_esp_lava", 1, true, false)

CreateClientConVar("VULCAN_trajectory", 1, true, false)
CreateClientConVar("VULCAN_P2P", 1, true, false)

CreateClientConVar("VULCAN_xray", 1, true, false)
CreateClientConVar("VULCAN_xray_adaptive_opacity", 0, true, false)

CreateClientConVar("VULCAN_chams", 1, true, false)
CreateClientConVar("VULCAN_chams_additional_halos", 1, true, false)

CreateClientConVar("VULCAN_headbeams", 1, true, false)

CreateClientConVar("VULCAN_pingpredictboxes", 1, true, false)

CreateClientConVar("VULCAN_alert", 1, true, false)

CreateClientConVar("VULCAN_physline", 1, true, false)
CreateClientConVar("VULCAN_physline_otherplayers", 1, true, false)

CreateClientConVar("VULCAN_VelocityHUD", 0, true, false)

MsgC(Color(255,255,0), [[
> VULCAN PK SCRIPT LOADED! THIS WAS MADE BY BRAINFUCK AND TRIAL EXCLUSIVELY FOR PK SERVERS, ENJOY!
- The commands prefix is VULCAN, type VULCAN_menu to open the menu :)
]])


local function lavacolor(n, t)
	if n == 1 then
		return math.Round((255 - (math.floor(math.sin(RealTime() * 3.5 ) * 40 + 50 ) ) ) / t, 2), math.Round((math.floor(math.sin(RealTime() * 3.5 + 2 ) * 55 + 65 ) ) / t, 2), 0
	elseif n == 2 then
		return 255 / t , 0.6- math.Round((math.floor(math.sin(RealTime() * 3.5 + 2 ) * 55 + 65 ) ) / t, 2), 0
	end
end

local function spacecolor(n, t)
	if n == 1 then
		return math.Round( (math.floor(math.sin(RealTime() * 3.5 ) * 30 + 40 ) ) / t, 2), 0, math.Round((math.floor(math.sin(RealTime() * 3.5 ) * 55 + 65 ) ) / t, 2)
	elseif n == 2 then
		return 0.6- math.Round((math.floor(math.sin(RealTime() * 4 ) * 55 + 65 ) ) / t, 2), 0, 0.6- math.Round((math.floor(math.sin(RealTime() * 4) * 55 + 65 ) ) / t, 2)
	end
end

// IsOutOfFOV (very usefull for optimization, thanks Grump)
local function IsOutOfFOV( ent )
	if GetConVarNumber("VULCAN_SAVEFPS") == 1 then
		if LocalPlayer():GetObserverMode() == 0 then
			local Width = ent:BoundingRadius()
			local Disp = ent:GetPos() -LocalPlayer():GetShootPos()
			local Dist = Disp:Length()
			local MaxCos = math.abs( math.cos( math.acos( Dist /math.sqrt( Dist *Dist +Width *Width ) ) +56 *( math.pi /180 ) ) )
			Disp:Normalize()
			local dot = Disp:Dot( LocalPlayer():EyeAngles():Forward() )
			return dot <MaxCos
		end
	end
end

// lazyness
local function validation(x)
	return IsValid(x) && x:Alive() && x != LocalPlayer() && x:Team() != TEAM_SPECTATOR && team.GetName(x:Team()) != "Spectator" && x:GetObserverMode() == 0;
end

local function velocityshower()
	if(GetConVarNumber("VULCAN_VelocityHUD") == 1) then
		draw.SimpleTextOutlined( math.Round(LocalPlayer():GetVelocity():Length(), 0), "DermaLarge", ScrW() /2, ScrH() /9, Color(255,255,255,255), 1, 1, 2, Color(50,50,50,255) )
	end
end
hook.Add("HUDPaint", "velocityshower", velocityshower)

// ESP
local function ESP()
	if GetConVarNumber("VULCAN_esp") == 1 then
		for k,v in next, player.GetAll() do -- Apparently, using "in next" is faster than "in pairs"
			if !IsOutOfFOV(v) then
				if validation(v) and LocalPlayer():GetObserverTarget() != v then
					local vpos = v:EyePos():ToScreen()
					if GetConVarNumber("VULCAN_esp_lava") == 1 then
						draw.SimpleTextOutlined ( v:Name(), "DebugFixed", vpos.x, vpos.y -10, Color(255, 255, 0, 255), 1, 1, 1, Color(255,0,0, 255))
					else
						draw.SimpleTextOutlined ( v:Name(), "DebugFixed", vpos.x, vpos.y -10, Color(255, 255, 255, 255), 1, 1, 1, Color(50, 50, 50, 255))
					end
				end
			end
		end
	end
end
hook.Add("HUDPaint", "names", ESP)

-- // trajectory (draws a red line in the direction of a propsurfing target) // --
local function TRAJECTORY()
	if GetConVarNumber("VULCAN_trajectory") == 1 then
		for k,v in pairs(player.GetAll()) do
			if validation(v) and !IsOutOfFOV(v) then
				if v:GetVelocity():Length() > 1200 then
					local Dist = math.Clamp( v:GetShootPos():Distance( LocalPlayer():GetShootPos() ), 100, 1000 )
					local StretchX = Dist/100
					local StretchY = Dist/200
					local TraceStart = v:LocalToWorld(v:OBBCenter())
					local linepos = util.QuickTrace(TraceStart, Vector(v:GetVelocity().x * 10, v:GetVelocity().y * 10, 0), v)
					if TraceStart:Distance(linepos.HitPos) > 400 then
					cam.Start3D()
						cam.IgnoreZ(true)
						render.SetMaterial( Material( "sprites/tp_beam001" ) )
						render.DrawBeam( TraceStart, linepos.HitPos , 50, StretchX, StretchY, Color(lavacolor(1,1)) )
					cam.End3D()
				end
			end
		end
	end
end
end
hook.Add("RenderScreenspaceEffects", "trajectory", TRAJECTORY)


// I took your physline concept and added a proplogger thing to know if its my prop or not, might be better idk
// I took it because im so used to it that I cant play without it anymore
local myprops = {}
local yourvictims = {}

local function prop_logger(ply,wep,enabled,targ,bone,pos)
	if (IsValid(ply)) and (ply == LocalPlayer()) and (enabled) and IsValid(targ) and targ:GetClass() == "prop_physics" then
		if (!myprops[targ]) then
			myprops[targ] = true
		end
	end
	if GetConVarNumber("VULCAN_physline") != 1 and GetConVarNumber("VULCAN_physline_otherplayers") != 1 then return true end
	if myprops[targ] then
		-- if ply == LocalPlayer() then
		Vulcan.CPos = LocalPlayer():EyePos() + EyeAngles():Forward() * 50
		Vulcan.prop = targ
		Vulcan.propID = targ:GetModel()
		Vulcan.entPOS = targ:LocalToWorld(targ:OBBCenter())
		Vulcan.entPOSI = targ:GetPos()
		Vulcan.propmod = Vulcan.propID
		Vulcan.physlineOn = true
		-- end
		return false
	else
		if ply == LocalPlayer() then
			Vulcan.propID = ""
			Vulcan.physlineOn = false
		else
			if IsValid(targ) and IsValid(ply) then
				Vulcan.srcPos = wep:GetAttachment( 1 ).Pos
				if ( !ply:ShouldDrawLocalPlayer() and ply == LocalPlayer() ) then
					if ply:GetViewModel():GetAttachment( 1 ).Pos then
						Vulcan.srcPos = ply:GetViewModel():GetAttachment( 1 ).Pos
					end
				end
				Vulcan.entPOS2 = targ:LocalToWorld(targ:OBBCenter())
				Vulcan.otherphysline = true
			else
				Vulcan.otherphysline = false
			end
		end
		return false
	end
	return true
end
hook.Add("DrawPhysgunBeam", "heye", prop_logger)

local function physLine()
		if Vulcan.physlineOn == true and GetConVarNumber("VULCAN_physline") == 1 then
			cam.Start3D()
				render.SetMaterial(Material("cable/redlaser"))
				render.DrawBeam(Vulcan.CPos, Vulcan.entPOS, 5, 1, 1, Color(255, 0, 255, 255))
				render.DrawLine(Vulcan.CPos, Vulcan.entPOS, Color(lavacolor(2,1)))
			//prop:SetModel("models/props_junk/watermelon01.mdl")
			cam.End3D()
		end
		if Vulcan.otherphysline == true and GetConVarNumber("VULCAN_physline_otherplayers") == 1 then
			cam.Start3D()
				render.SetMaterial(Material("cable/redlaser"))
				render.DrawBeam(Vulcan.srcPos, Vulcan.entPOS2, 5, 1, 1, Color(255, 0, 255, 255))
				render.DrawLine(Vulcan.srcPos, Vulcan.entPOS2, Color(255,0,0,255))
			//prop:SetModel("models/props_junk/watermelon01.mdl")
			cam.End3D()
		end
end
hook.Add("HUDPaint", "kaosssuw3s", physLine)


 -- // PROPTOPLAYER TRACERS // --
local function proptoplayer()
	if GetConVarNumber("VULCAN_P2P") == 1 then
		for k, v in pairs( ents.FindByClass( "prop_physics" ) ) do

			if (!myprops[v]) then continue end

				for c,b in pairs(player.GetAll()) do
					if v:GetPos():Distance(b:GetPos()) < 2000 then
						if validation(b) then
						local propPOS = v:LocalToWorld(v:OBBCenter())
							if LocalPlayer():KeyDown(IN_ATTACK) then
								if Vulcan.physlineOn == true then
									if v:GetVelocity():Length() > 100 then
										if b:GetVelocity():Length() != 0 then
 
											cam.Start3D()
												render.SetMaterial(Material("trails/LOL"))
												render.DrawBeam(propPOS, b:EyePos(), 45, 0, 0, Color(255, 0, 0, 255))
												render.DrawLine(propPOS, b:EyePos(), Color(255,0,0,100))
											cam.End3D()
 
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
hook.Add ("HUDPaint", "proptoplayer", proptoplayer) // 35

// CHAMS
local function CHAMS()
	for k,v in next, player.GetAll() do
	local oldgetpos = v:GetPos()
	local DIS = v:GetPos():Distance(LocalPlayer():GetPos()) / 500 -- credits to trial for this
		if validation(v) then
			if !IsOutOfFOV(v) then
				if GetConVarNumber("VULCAN_chams") == 1 then
					v:SetColor(Color(0,0,0,0)) -- making the prop invisible before you put the visuals on it so the opacity will be perfectly toggleable
					cam.IgnoreZ( true )
					v:SetRenderMode( RENDERMODE_TRANSALPHA )
					render.SuppressEngineLighting(true)
						-- lava visuals here
						render.MaterialOverride(Material("!White9"))
						render.SetColorModulation( 1, 1, 0.7 )
						render.SetBlend(1)
					v:DrawModel()
					render.SuppressEngineLighting(false)
					cam.IgnoreZ(false)
				else
					v:SetColor(Color(255,255,255,255))
				end
			else
				v:SetColor(Color(255,255,255,255))
			end
		end
		v:SetPos(oldgetpos)
	end
end
hook.Add("PreDrawEffects", "playerchams", CHAMS)

hook.Add( "PreDrawHalos", "AddStaffHalos", function()
if GetConVarNumber("VULCAN_chams") == 1 then
local validplayers = {}
	for k,v in next, player.GetAll() do
		if !IsOutOfFOV(v) and validation(v) then
		plyvel = v:GetVelocity():Length()
			if !table.HasValue(validplayers, v) then
				table.insert(validplayers, v)
			end
		else
			if table.HasValue(validplayers, v) then
				table.RemoveByValue(validplayers, v)
			end
		end
	end

	if #validplayers > 0 then
		halo.Add( validplayers, Color( 255, 0, 0 ), 1, 1, 2, false, true )
		if GetConVarNumber("VULCAN_chams_additional_halos") == 1 then 
			halo.Add( validplayers, Color( 255, 255, 0 ), 1, 2, 2, true, true )
			halo.Add( validplayers, Color( 255, 0, 0 ), 1, 10, 10, true, true )
		end
	end
end
end )

// XRAY
local function XRAY()
	for k,v in next, ents.FindByClass("prop_physics") do
	local DIS = v:GetPos():Distance(LocalPlayer():GetPos()) / 500 -- credits to trial for this
		if !IsOutOfFOV(v) then
			if GetConVarNumber("VULCAN_xray") == 1 then
				v:SetColor(Color(0,0,0,0)) -- making the prop invisible before you put the visuals on it so the opacity will be perfectly toggleable

				-- pre-mat (fixing the gate issue with the !White9 mat)
				cam.IgnoreZ( true )
				v:SetRenderMode( RENDERMODE_TRANSALPHA )
				render.SuppressEngineLighting(true)
					render.MaterialOverride(Material("!White9"))
					render.SetColorModulation( lavacolor(2, 255) )
					if GetConVarNumber("VULCAN_xray_adaptive_opacity") == 1 then
						render.SetBlend(0.1 + DIS)
					else
						render.SetBlend(1)
					end
				v:DrawModel()
				render.SuppressEngineLighting(false)
				cam.IgnoreZ(false)

				-- main material
				cam.IgnoreZ( true )
				v:SetRenderMode( RENDERMODE_TRANSALPHA )
				render.SuppressEngineLighting(true)
					render.MaterialOverride(Material("models/shadertest/vertexlitselfilluminatedenvmappedtexture.mdl"))
					render.SetColorModulation( lavacolor(1, 255) )
					if GetConVarNumber("VULCAN_xray_adaptive_opacity") == 1 then
						render.SetBlend(0.3 + DIS)
					else
						render.SetBlend(1)
					end
				-- boxes here
				render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25) , v:OBBMins() + Vector(-0.25, -0.25, -0.25) , Color(lavacolor(1,1)))
				render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.75, -0.75, -0.75) , v:OBBMins() + Vector(-0.75, -0.75, -0.75) , Color(0,0,0))
				render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-1.25, -1.25, -1.25) , v:OBBMins() + Vector(-1.25, -1.25, -1.25) , Color(lavacolor(1,1)))
				v:DrawModel()
				render.SuppressEngineLighting(false)
				cam.IgnoreZ(false)

				-- second material(gotta add some movement! :D)
				cam.IgnoreZ( true )
				v:SetRenderMode( RENDERMODE_TRANSALPHA )
				render.SuppressEngineLighting(true)
					render.MaterialOverride(Material("models/effects/comball_sphere"))
					render.SetColorModulation( lavacolor(2, 255) )
					if GetConVarNumber("VULCAN_xray_adaptive_opacity") == 1 then
						render.SetBlend(0.1 + DIS)
					else
						render.SetBlend(1)
					end
				v:DrawModel()
				render.SuppressEngineLighting(false)
				cam.IgnoreZ(false)
			else
				v:SetColor(Color(255,255,255,255))
			end
		else
			v:SetColor(Color(255,255,255,255))
		end
	end
end
hook.Add("PreDrawEffects", "propsvisuals", XRAY)

hook.Add("Think", "dsgdfgxds", function()
    if LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
	if GetConVarNumber("VULCAN_bhop") == 1 then
        if (input.IsKeyDown(KEY_SPACE)) then
            if LocalPlayer():IsOnGround() then
                if LocalPlayer():IsTyping() then return end
                    RunConsoleCommand("+jump")
                    jumped = 1
                else
                    RunConsoleCommand("-jump")
                    jumped = 0
            end
			elseif LocalPlayer():IsOnGround() then
				if jumped == 1 then
                    RunConsoleCommand("-jump")
                    jumped = 0
			end
        end
    end
end)

 // FOV CHANGER
local function fov_changer(ply, pos, ang, fov)

	local view = {}

	if (!IsValid(ply)) then return end
	if GetConVarNumber("VULCAN_FOVEnable") == 1 then
		view.fov = GetConVar("VULCAN_FOVNumber"):GetInt()
		if GetConVarNumber("VULCAN_FOV_VELOCITY") == 1 then
			view.fov =  math.Clamp(GetConVar("VULCAN_FOVNumber"):GetInt() + LocalPlayer():GetVelocity():Length() / 60, GetConVar("VULCAN_FOVNumber"):GetInt(), 140) -- trial's idea, feels good but unplayable in propkill :D
		end
	end

	return view 

end
hook.Add("CalcView", "fovchanger", fov_changer)

-- // ROTATING FUNCTIONS // -- (from 3SP as all the rotates are the same thing)
concommand.Add("brain_ROTATE2", function()
	LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().x, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().z))
	RunConsoleCommand("+jump")
	timer.Simple(0.01, function()
		RunConsoleCommand("-jump")
	end)
end)

concommand.Add("brain_ROTATE", function()
	LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().x, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().z))
end)

-- // tracers (old design) // -- 
local function MYTRAERS()
	if ( GetConVarNumber("VULCAN_tracers") == 1 ) then
		for k,v in next, player.GetAll() do
		local Dist = math.Clamp( v:GetShootPos():Distance( LocalPlayer():GetShootPos() ), 100, 2500 )
			if validation(v) and LocalPlayer():GetObserverMode() == 0 then
				cam.Start3D()
					cam.IgnoreZ(true)
					render.SetMaterial(Material("sprites/tp_beam001"))
					render.DrawBeam(LocalPlayer():GetPos() + EyeAngles():Forward() * 80, v:GetPos(), Dist/125, 1, 1, Color(lavacolor(1,1)))
					render.DrawLine(LocalPlayer():GetPos() + EyeAngles():Forward() * 80, v:GetPos(), Color(lavacolor(2,1)))
				cam.End3D()
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects", "tracerslel", MYTRAERS)

local function HEADBEAMS()

local hbcolor = Color(50,50,50,255)

	if GetConVarNumber("VULCAN_headbeams") == 1 then

		for k,v in pairs(player.GetAll()) do

			if validation(v) and !IsOutOfFOV(v) then

			local Origin = v:GetPos() + Vector( 0, 0, 40 ) 
			local Up = util.TraceLine( { start = Origin, endpos = Origin + Vector( 0, 0, 16384 ), filter = { v }, mask = MASK_SHOT } )
			local Down = util.TraceLine( { start = Origin, endpos = Origin - Vector( 0, 0, 16384 ), filter = { v }, mask = MASK_SHOT } )
			local Dist = math.Clamp( v:GetShootPos():Distance( LocalPlayer():GetShootPos() ), 1500, 2500 )
			local CutoffPos
			local SpriteDist = v:EyePos():Distance(Up.HitPos)
			local V = { Start = v:EyePos(), End = Up.HitPos, Width = Dist /40  }
			local StretchX = Dist/200
			local StretchY = Dist/400

				for u,f in pairs(ents.FindByClass("prop_physics")) do -- turning the color red when a prop is over players head
					if Up.Entity == f then
						hbcolor = Color(255,0,0,255)
					else
						hbcolor = Color(50,50,50,255)
					end
				end

				cam.Start3D()
					cam.IgnoreZ(true)
					render.SetMaterial( Material( "trails/smoke" ) )
					render.DrawBeam( V.Start , V.End, V.Width, StretchX, StretchY, hbcolor )
				cam.End3D()
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects", "HEADBEAMS", HEADBEAMS)

local function VMENU()
	local base = vgui.Create("DFrame")
		base:SetSize(240, 375)
		base:Center()
		base:MakePopup()
		base:SetTitle("VULCAN SCRIPT   **DEV TESTING**")
		
		base.lblTitle.UpdateColours = function(label)
			label:SetTextStyleColor(Color(247, 252, 248))
		end
		
		base.btnMaxim:Hide()
		base.btnMinim:Hide()
		
		
		base.Paint = function(self, w, h)
			surface.SetDrawColor(218-25, 124-25, 8)
			surface.DrawRect(0, 0, w, h)
				
			surface.SetDrawColor(247, 252, 248)
			surface.DrawOutlinedRect(0, 0, w, h)
			
			
			surface.SetDrawColor(90, 90, 88)
			surface.DrawRect(2, 2, w - 4, h - 350)
			
			surface.DrawRect(10, 50, 40, 30)
			
			
			surface.SetDrawColor(218-25, 124-25, 8)
			surface.DrawOutlinedRect(1, 1, w - 2, h -351)	
			
		
			surface.DrawRect(2, 35, w - 4, h - 37)		
			surface.SetDrawColor(112, 117, 113)
			
			
			surface.SetDrawColor(226, 164, 79)
			surface.DrawLine(80, 36, 80, 370 )
			surface.DrawLine(160, 36, 160, 370 )
			
			//surface.SetDrawColor(90, 90, 88)
			//surface.DrawRect(18, 49, 20, 20)
			
			
			// horiz line
			for i = 1, 4 do
				//surface.SetDrawColor(112, 117, 113)
				surface.SetDrawColor(226, 164, 79)
				surface.DrawLine(3, 25 + i * 65, 247, 25 + i * 65 )
			
			end
				
		end
		
		local visuals = vgui.Create("DLabel", base)
			visuals:SetText("VISUALS:")
			visuals:SetPos(10,35)
			visuals:SetFont("TargetIDSmall")
			visuals:SizeToContents(true)
		
		local b1 = vgui.Create("DCheckBoxLabel", base)
			b1:SetPos(30, 58)
			b1:SetText("ESP")
			b1:SetConVar("VULCAN_esp")
			b1:SetFont("TargetIDSmall")
			
		
		local b2 = vgui.Create("DCheckBoxLabel", base)
			b2:SetPos(30, 75)
			b2:SetText("ESP LAVA")
			b2:SetConVar("VULCAN_esp_lava")
			b2:SetFont("TargetIDSmall")

		local b3 = vgui.Create("DCheckBoxLabel", base)
			b3:SetPos(30, 103)
			b3:SetText("XRAY")
			b3:SetConVar("VULCAN_xray")
			b3:SetFont("TargetIDSmall")
			
		
		local b4 = vgui.Create("DCheckBoxLabel", base)
			b4:SetPos(30, 120)
			b4:SetText("XRAY SMART OPACITY")
			b4:SetConVar("VULCAN_xray_adaptive_opacity")
			b4:SetFont("TargetIDSmall")
		
		local b5 = vgui.Create("DCheckBoxLabel", base)
			b5:SetPos(30, 147)
			b5:SetText("CHAMS")
			b5:SetConVar("VULCAN_chams")
			b5:SetFont("TargetIDSmall")
			
		
		local b6 = vgui.Create("DCheckBoxLabel", base)
			b6:SetPos(30, 164)
			b6:SetText("CHAMS HALOS")
			b6:SetConVar("VULCAN_chams_additional_halos")
			b6:SetFont("TargetIDSmall")

		local b7 = vgui.Create("DCheckBoxLabel", base)
			b7:SetPos(30, 191)
			b7:SetText("TRACERS")
			b7:SetConVar("VULCAN_tracers")
			b7:SetFont("TargetIDSmall")
			
		
		local b8 = vgui.Create("DCheckBoxLabel", base)
			b8:SetPos(30, 208)
			b8:SetText("PING PREDICTION BOXES")
			b8:SetConVar("VULCAN_pingpredictboxes")
			b8:SetFont("TargetIDSmall")
			b8:SetToolTip("Draw boxes around players moving according to their ping")

		local b66 = vgui.Create("DCheckBoxLabel", base)
			b66:SetPos(30, 225)
			b66:SetText("HEADBEAMS")
			b66:SetConVar("VULCAN_headbeams")
			b66:SetFont("TargetIDSmall")

		local misc = vgui.Create("DLabel", base)
			misc:SetText("MISC:")
			misc:SetPos(10,248)
			misc:SetFont("TargetIDSmall")
			misc:SizeToContents(true)

		local b9 = vgui.Create("DCheckBoxLabel", base)
			b9:SetPos(30, 269)
			b9:SetText("FPS SAVER")
			b9:SetConVar("VULCAN_SAVEFPS")
			b9:SetFont("TargetIDSmall")
			b9:SetToolTip("Disable visuals when they are out of your field of view")

		local b10 = vgui.Create("DCheckBoxLabel", base)
			b10:SetPos(30, 286)
			b10:SetText("BACK-ATTACK ALERT")
			b10:SetToolTip("Draw an alert when a prop is about to kill you from behind")
			b10:SetConVar("VULCAN_alert")
			b10:SetFont("TargetIDSmall")

		local b11 = vgui.Create("DCheckBoxLabel", base)
			b11:SetPos(30, 303)
			b11:SetText("BHOP")
			b11:SetConVar("VULCAN_bhop")
			b11:SetFont("TargetIDSmall")

		local b12 = vgui.Create("DCheckBoxLabel", base)
			b12:SetPos(30, 320)
			b12:SetText("FOV:")
			b12:SetConVar("VULCAN_FOVEnable")
			b12:SetFont("TargetIDSmall")

		local fovnumber = vgui.Create( "DNumberWang", base )
			fovnumber:SetPos( 90, 320 )
			fovnumber:SetSize( 40, 15 )
			fovnumber:SetMin(0)
			fovnumber:SetMax(179)
			fovnumber:SetValue(GetConVarNumber("VULCAN_FOVNumber"))
			function fovnumber:OnValueChanged(value)
				GetConVar("VULCAN_FOVNumber"):SetInt(value)
			end

		local b13 = vgui.Create("DCheckBoxLabel", base)
			b13:SetPos(30, 337)
			b13:SetText("VELOCITY FOV")
			b13:SetToolTip("Higher velocity = higher FOV")
			b13:SetConVar("VULCAN_FOV_VELOCITY")
			b13:SetFont("TargetIDSmall")
end
concommand.Add("VULCAN_menu", VMENU)

function PingPredict()
	if GetConVarNumber("VULCAN_pingpredictboxes") == 1 then
		for k,v in next, player.GetAll() do
			local pos = v:GetPos() + (v:GetVelocity()/1000)*(((LocalPlayer():Ping()/5) - 1) )
			local pos2 = v:GetPos() + (v:GetVelocity()*LocalPlayer():Ping()/1000 )
			local DIS = v:GetPos():Distance(LocalPlayer():GetPos()) / 500
			if validation(v) then
				render.SuppressEngineLighting(true)
					if v:IsOnGround() then
						render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25) , v:OBBMins() + Vector(-0.25, -0.25, -0.25) , Color(lavacolor(1,1)))
						render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-0.75, -0.75, -0.75) , v:OBBMins() + Vector(-0.75, -0.75, -0.75) , Color(0,0,0))
						render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-1.25, -1.25, -1.25) , v:OBBMins() + Vector(-1.25, -1.25, -1.25) , Color(lavacolor(1,1)))
					else
						if v:GetVelocity():Length() >= 700 then
							render.DrawWireframeBox(pos, v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25) , v:OBBMins() + Vector(-0.25, -0.25, -0.25) , Color(lavacolor(1,1)))
							render.DrawWireframeBox(pos, v:GetAngles(), v:OBBMaxs() - Vector(-0.75, -0.75, -0.75) , v:OBBMins() + Vector(-0.75, -0.75, -0.75) , Color(0,0,0))
							render.DrawWireframeBox(pos, v:GetAngles(), v:OBBMaxs() - Vector(-1.25, -1.25, -1.25) , v:OBBMins() + Vector(-1.25, -1.25, -1.25) , Color(lavacolor(1,1)))
						else
							render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25) , v:OBBMins() + Vector(-0.25, -0.25, -0.25) , Color(lavacolor(1,1)))
							render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-0.75, -0.75, -0.75) , v:OBBMins() + Vector(-0.75, -0.75, -0.75) , Color(0,0,0))
							render.DrawWireframeBox(pos2, v:GetAngles(), v:OBBMaxs() - Vector(-1.25, -1.25, -1.25) , v:OBBMins() + Vector(-1.25, -1.25, -1.25) , Color(lavacolor(1,1)))
						end
					end
				render.SuppressEngineLighting(false)
			end
		end
	end
end
hook.Add("PreDrawEffects", "playerChams", PingPredict)

function draw.OutlinedBox( x, y, w, h, thickness, clr )
	surface.SetDrawColor( clr )
	for i=0, thickness - 1 do
		surface.DrawOutlinedRect( x + i, y + i, w - i * 2, h - i * 2 )
	end
end

-- // danger (kills yourself when a prop is about to kill you lul) // --
local function DANGEROUS()
	if GetConVarNumber("VULCAN_alert") == 1 then
		for k,v in next, ents.FindByClass( "prop_physics" ) do
		if (myprops[v]) then continue end
		local entpos = v:LocalToWorld(v:OBBCenter())
		local endpos = util.QuickTrace (  entpos, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos2 = v:LocalToWorld(v:OBBMins())
		local endpos2 = util.QuickTrace (  entpos2, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos3 = v:LocalToWorld(v:OBBMaxs())
		local endpos3 = util.QuickTrace (  entpos3, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos4 = v:LocalToWorld(v:OBBCenter() + Vector(0,0,40))
		local endpos4 = util.QuickTrace (  entpos4, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos5 = v:LocalToWorld(v:OBBCenter() - Vector(0,0,40))
		local endpos5 = util.QuickTrace (  entpos5, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos6 = v:LocalToWorld(v:OBBMins() + Vector(0,0,40))
		local endpos6 = util.QuickTrace (  entpos6, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos7 = v:LocalToWorld(v:OBBMaxs() - Vector(0,0,40))
		local endpos7 = util.QuickTrace (  entpos7, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos8 = v:LocalToWorld(v:OBBMaxs() - Vector(0,45,0))
		local endpos8 = util.QuickTrace (  entpos8, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )
		local entpos9 = v:LocalToWorld(v:OBBMaxs() - Vector(0,0,76))
		local endpos9 = util.QuickTrace (  entpos9, Vector(v:GetVelocity().x / 5, v:GetVelocity().y / 5, 0), v )

			-- cam.Start3D()
				-- cam.IgnoreZ(true)
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos, endpos.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos2, endpos2.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos3, endpos3.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos4, endpos4.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos5, endpos5.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos6, endpos6.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos7, endpos7.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos8, endpos8.HitPos, 125, 50, 50, _Color(255,0,0,255) )
				-- render.SetMaterial( Material( "sprites/tp_beam001" ) )
				-- render.DrawBeam( entpos9, endpos9.HitPos, 125, 50, 50, _Color(255,0,0,255) )
			-- cam.End3D()

			if endpos.Entity == LocalPlayer() or 
			endpos2.Entity == LocalPlayer() or 
			endpos3.Entity == LocalPlayer() or 
			endpos4.Entity == LocalPlayer() or 
			endpos5.Entity == LocalPlayer() or 
			endpos6.Entity == LocalPlayer() or 
			endpos7.Entity == LocalPlayer() then
				if IsOutOfFOV(v) then
					Vulcan.dangerous = true
					hook.Add("HUDPaint", "dflksjhdf", function()
						draw.SimpleText("DANGER!", "DermaDefault", (ScrW() / 2)+11, 15 + (k * 10), Color(255,0,0,255) )
						draw.OutlinedBox(0, 0, ScrW(), ScrH(), 6, Color(255,0,0,255))
					end)
				end
			else
				if (Vulcan.dangerous) then
					hook.Remove("HUDPaint", "dflksjhdf")
				end
				Vulcan.dangerous = false
			end
		end
	end
end
hook.Add("RenderScreenspaceEffects", "itsdangerousdude", DANGEROUS)


