//////////////////                                  \\\\\\\\\\\\\\\
////////////////// THIS IS MADE BY GUSTAVGR/BLOWN25 \\\\\\\\\\\\\\\
//////////////////                                  \\\\\\\\\\\\\\\
//////////////////                                  \\\\\\\\\\\\\\\
local vers = "1.0" or ""
local sname = "GSWH" or ""
--print when start.
print("("..sname .. " " .. vers..")" .. "  Loaded!, type gswh_menu to start!")
//add the shit
AddCSLuaFile( "GSWH.lua" )

//Variables
deffont = "TargetID" //Default font, change "if you want
esppname = true //Show player esp?
espnpc = true //Show npc esp?
espent = true //Show entity esp?
espnameison = "On", 1 // Esp name is on?
espnpcison = "On", 1 // Esp Npc is on?
espentison = "On", 1 // Esp Ent is on?
defc = Color(225, 225, 225, 255) //Default color
wh_color_player = Color(225, 225, 225, 255) //Default Player ESP Color :D
wh_color_npc = Color(225, 225, 225, 255) //Default Npc ESP Color :D
wh_color_ent = Color(225, 225, 225, 255) //Default Entity ESP Color :D
local lp = LocalPlayer()

//Wallhack - ESP
function WESP()

--trace.Entity:GetClass()

local length = 40
local Name = ""
 

if ( esppname == true ) then
for k,v in pairs ( player.GetAll() ) do
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
if v == LocalPlayer() then Name = "" else Name = v:Name() end
draw.DrawText( Name, deffont, Position.x, Position.y, wh_color_player, 1 )
end
end
if ( espnpc == true ) then
	for i,v in pairs( ents.GetAll() ) do
	local Position = ( v:GetPos() + Vector( 0,0,50 ) ):ToScreen()
		if v:IsValid() && v:IsNPC() then
				Name = v:GetClass()
		draw.DrawText( Name, deffont, Position.x, Position.y, wh_color_npc, 1 )
surface.DrawOutlinedRect( Position.x - length / 2, Position.y - length / 2, wh_color_npc  )
		end
end
end
if ( espent == true ) then
	for i,v in pairs( ents.GetAll() ) do
	if (!v:IsWeapon()) then
	local Position = ( v:GetPos() + Vector( 0,0,15 ) ):ToScreen()

				Name = v:GetClass()
		draw.DrawText( Name, deffont, Position.x, Position.y, wh_color_ent, 1 )
surface.DrawOutlinedRect( Position.x - length / 2, Position.y - length / 2, wh_color_ent  )
		end
	end
end
end
hook.Add( "HUDPaint", "wh", WESP)
concommand.Add( "gswh_reload", WESP )



//Teh Epic Menuz -- :3

function settingmenu()
local Base = vgui.Create( "DFrame" )
Base:SetPos( 50, 50 )
Base:SetSize( 350, 400 )
Base:SetTitle( "GSWH Menu" )
Base:SetVisible( true )
Base:SetDraggable( true )
Base:ShowCloseButton( true )
Base:MakePopup()
local Sheet1 = vgui.Create( "DPropertySheet", Base )
Sheet1:SetPos( 5, 30 )
Sheet1:SetSize( 340, 315 )
local InfoMenu = vgui.Create( "DPropertySheet")
InfoMenu:SetPos( 5, 30 )
InfoMenu:SetSize( 340, 315 )
local infotext = vgui.Create("DLabel", InfoMenu)
infotext:SetText("                                     GSWH\nVersion: " .. vers .. "\n\nCommands: \ngswh_menu - Open this menu\ngswh_reload - Refresh the script.\ngswh_esp_players(TOGGLE) - Enable player ESP.\ngswh_esp_entities(TOGGLE) - Enable entity ESP.\ngswh_esp_npcs(TOGGLE) - Enable the NPC Esp.\ngswh_off -- Turns of everything on this script.\n\n\nCredits: Gustavgr/blown25\nOther info: Do not use this too much ;)")
infotext:SetFont("ChatFont")
infotext:SizeToContents()

local ESPMenu = vgui.Create( "DPropertySheet")
ESPMenu:SetPos( 5, 30 )
ESPMenu:SetSize( 340, 315 )

pcolor = vgui.Create( "DColorMixer", ESPMenu);
pcolor:SetSize( 140, 70);
pcolor:SetPos(5, 25 );
pcolor:SetColor(wh_color_player)
local acceptpcolor = vgui.Create( "DButton", ESPMenu )
	acceptpcolor:SetSize( 100, 31 )
	acceptpcolor:SetPos( 30, 96 )
	acceptpcolor:SetText( "Accept" )
	acceptpcolor.DoClick = function( button )
		wh_color_player = (pcolor:GetColor())
	end
		local pcolora= vgui.Create( "DMultiChoice", ESPMenu)
	pcolora:SetPos(30,130)
	pcolora:SetSize( 50, 20 )
	pcolora:AddChoice("On")
	pcolora:AddChoice("Off")
	pcolora:ChooseOption( espnameison )
	pcolora.OnSelect = function(panel,index,value)
	if ( index == 1 ) then
	espnameison = "On", 1
	esppname = true
	RunConsoleCommand("gswh_reload");
		elseif ( index == 2 ) then
	esppname = false
	espnameison = "Off", 2
RunConsoleCommand("gswh_reload");
	end
	end
local pcolort= vgui.Create("DLabel", ESPMenu)
pcolort:SetPos( 17, 10 )
pcolort:SetText("    Player ESP" .. "["..espnameison.."]")
pcolort:SetFont("CenterPrintText")
pcolort:SetColor(wh_color_player)
pcolort:SizeToContents()
//NPC SHIT

ncolor = vgui.Create( "DColorMixer", ESPMenu);
ncolor:SetSize( 140, 70);
ncolor:SetPos(185, 25 );
ncolor:SetColor(wh_color_npc)
local acceptncolor = vgui.Create( "DButton", ESPMenu )
	acceptncolor:SetSize( 100, 31 )
	acceptncolor:SetPos( 210, 96 )
	acceptncolor:SetText( "Accept" )
	acceptncolor.DoClick = function( button )
		wh_color_npc = (ncolor:GetColor())
	end
		local ncolora= vgui.Create( "DMultiChoice", ESPMenu)
	ncolora:SetPos(210,130)
	ncolora:SetSize( 50, 20 )
	ncolora:AddChoice("On")
	ncolora:AddChoice("Off")
	ncolora:ChooseOption( espnpcison )
	ncolora.OnSelect = function(panel,index,value)
	if ( index == 1 ) then
	espnpcison = "On", 1
	espnpc = true
	RunConsoleCommand("gswh_reload");
		elseif ( index == 2 ) then
	espnpc = false
	espnpcison = "Off", 2
RunConsoleCommand("gswh_reload");
	end
	end
local pcolort= vgui.Create("DLabel", ESPMenu)
pcolort:SetPos( 197, 10 )
pcolort:SetText("    Npc ESP" .. "["..espnpcison.."]")
pcolort:SetFont("CenterPrintText")
pcolort:SetColor(wh_color_npc)
pcolort:SizeToContents()

//ENT SHIT
ecolor = vgui.Create( "DColorMixer", ESPMenu);
ecolor:SetSize( 140, 70);
ecolor:SetPos(5, 175 );
ecolor:SetColor(wh_color_ent)
local acceptecolor = vgui.Create( "DButton", ESPMenu )
	acceptecolor:SetSize( 100, 31 )
	acceptecolor:SetPos( 30, 246 )
	acceptecolor:SetText( "Accept" )
	acceptecolor.DoClick = function( button )
		wh_color_ent = (ecolor:GetColor())
	end
		local ecolora= vgui.Create( "DMultiChoice", ESPMenu)
	ecolora:SetPos(130,250)
	ecolora:SetSize( 50, 20 )
	ecolora:AddChoice("On")
	ecolora:AddChoice("Off")
	ecolora:ChooseOption( espentison )
	ecolora.OnSelect = function(panel,index,value)
	if ( index == 1 ) then
	espentison = "On", 1
	espent = true
	RunConsoleCommand("gswh_reload");
		elseif ( index == 2 ) then
	espent = false
	espentison = "Off", 2
RunConsoleCommand("gswh_reload");
	end
	end
local pcolort= vgui.Create("DLabel", ESPMenu)
pcolort:SetPos( 17, 160 )
pcolort:SetText("    Entity ESP" .. "["..espentison.."]")
pcolort:SetFont("CenterPrintText")
pcolort:SetColor(wh_color_player)
pcolort:SizeToContents()
Sheet1:AddSheet( "GSWH Info", InfoMenu, "gui/silkicons/page", false, false)
Sheet1:AddSheet( "GSWH Settings", ESPMenu, "gui/silkicons/application", false, false)
end
concommand.Add( "gswh_menu", settingmenu )
//Teh awesome commands ;D
function gswh_esp_player()
if ( esppname == true ) then
esppname = false
print("Off")
elseif ( esppname == false ) then
esppname = true
print("On")

	end
end
concommand.Add( "gswh_esp_players", gswh_esp_player )
function gswh_esp_npc()
if ( espnpc == true ) then
espnpc = false
print("Off")
elseif ( espnpc == false ) then
espnpc = true
print("On")

	end
end
concommand.Add( "gswh_esp_npcs", gswh_esp_npc )
function gswh_esp_ent()
if ( espent == true ) then
espent = false
print("Off")
elseif ( espent == false ) then
espent = true
print("On")

	end
end
concommand.Add( "gswh_esp_entities", gswh_esp_ent )
function turnoff()
espent = false
espnpc = false
esppname = false
print("All Off!")


	end
concommand.Add( "gswh_off", turnoff )