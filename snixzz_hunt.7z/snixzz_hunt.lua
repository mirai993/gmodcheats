/*
	
	snixzz.net OFFICIAL snixzzHunt
	Author: 0xymoron
	
	VISIT snixzz.net FOR THE BEST FREE & PRIVATE CHEATS, MODULES, & SCRIPTS!
	
*/

-- Tables & copies
local snixzz = { g = table.Copy( _G ), detours = {} }
local g = snixzz.g.table.Copy( _G ) 
local r = g.debug.getregistry()

-- Undefined variables
local pos	
local name
local propmdl

-- Panic mode
local panic = false

CreateClientConVar( "autoswitch", 1, true, false )

function snixzz.AddHook( Type, Func )

	name = g.tostring( Func )
	
	return g.hook.Add( Type, name, Func )
end

function snixzz.Detour( old, new )

	snixzz.detours[new] = old
	
	return new
end
	
function snixzz.HUDPaint()
	
	if panic then return end
	
	for k, v in g.next, g.ents.GetAll() do
		
		pos = v:GetPos():ToScreen()
		
		-- an overly complicated check to maybe improve FPS
		if v:GetClass() == "ph_prop" or v:IsPlayer() && g.IsValid( v ) && v:Team() != g.TEAM_UNASSIGNED && v:Team() != g.TEAM_SPECTATOR && !g.string.find( g.string.lower( g.team.GetName( v:Team() ) ), "spec" ) then

			if v:GetClass() == "ph_prop" && v:GetOwner() != g.LocalPlayer() then
				
				//propmodel = g.string.Replace( v:GetModel(), "models/", "" ) -- shorten it up a lil
				
				g.cam.Start3D()			
					v:SetMaterial( "" )
					v:DrawModel()				
				g.cam.End3D()
				
				halo.Add( { v }, Color( 0, 255, 0 ), 1, 1, 5, true, true )
				
				//g.draw.SimpleText( propmodel, "default", pos.x, pos.y, g.Color( 0, 255, 0 ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
				g.draw.SimpleText( v:GetOwner():Name() or v:Nick(), "Trebuchet24", pos.x, pos.y - 11, g.team.GetColor( v:GetOwner():Team() ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )

			elseif v:IsPlayer() && v:Team() != TEAM_PROPS && v:GetClass() != "ph_prop" && v:Alive() && v != g.LocalPlayer() then -- another overly complicated check
				
				g.cam.Start3D()			
					v:SetMaterial( "" )
					v:DrawModel()				
				g.cam.End3D()
				
				//g.draw.SimpleText( "Player", "default", pos.x, pos.y, g.Color( 255, 0, 0 ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
				g.draw.SimpleText( v:Nick(), "Trebuchet24", pos.x, pos.y - 11, g.team.GetColor( v:Team() ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
		
			else
			
				continue
				
			end
				
						
		else
			
			continue
			
		end
		
	end
	
end

function snixzz.CreateMove( cmd )
	
	if g.LocalPlayer():GetMoveType() == g.MOVETYPE_NOCLIP or g.LocalPlayer():GetMoveType() == g.MOVETYPE_LADDER then 
		
		return 
	
	end
	
	if !g.LocalPlayer():IsOnGround() then 
	
		cmd:SetButtons( g.bit.band( cmd:GetButtons(), g.bit.bnot( g.IN_JUMP ) ) )
		
	end
	
end

net.Receive( "PH_TeamWinning_Snd", function( len )
	
	if GetConVarNumber( "autoswitch" ) == 0 then return end
	
	chat.AddText( Color( 0, 255, 0 ), "Detected round end, attempting to exploit team swap system to become hunter" )
			
	RunConsoleCommand( "changeteam", "2" )
				
end )
		
net.Receive( "PH_RoundDraw_Snd", function( len )
		
	if GetConVarNumber( "autoswitch" ) == 0 then return end
	
	chat.AddText( Color( 0, 255, 0 ), "Detected round draw, attempting to exploit team swap system to become hunter" )
			
	RunConsoleCommand( "changeteam", "2" )
				
end )

render.Capture = snixzz.Detour( render.Capture, function( data )

	panic = true
	
	timer.Simple( 5, function()
	
		panic = false
	
	end )
	
	return data

end )

debug.getinfo = snixzz.Detour( debug.getinfo, function()
	
	return { 
		what = "C",
		source = "[C]",
		source_src = "[C]",
		linedefined = -1,
		currentline = -1,
		lastlinedefined = -1,
		short_src = "[C]",
	}
		
end )

snixzz.AddHook( "CreateMove", snixzz.CreateMove )
snixzz.AddHook( "HUDPaint", snixzz.HUDPaint )

MsgC( Color( 0, 127, 255 ), "[snixzzHunt] " )
MsgC( color_white, "Loaded!\n" )