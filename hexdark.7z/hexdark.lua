--[[
	lua/include/modules/HeXDark.lua
	DJ Simple | (STEAM_0:1:60333045)
	===DStream===
]]

timer.Simple(1, function()
	Msg("//////////////////////////////		\n")
	Msg("///////////Hex-Hack //////////		\n")
	Msg("//////////RP Loaded...//////////	\n")
	Msg("//////////////////////////////		\n")
end )

-- Client Side
-- Remember we don't need to load the modules, we done that in the core
if ( SERVER ) then return end

-- ConVars
CreateClientConVar('Hex_RP_MoneyPrinterESP', 	0, true, false)
CreateClientConVar('Hex_RP_MoneyESP', 			0, true, false)
CreateClientConVar('Hex_RP_ShipmentESP', 		0, true, false)
CreateClientConVar('Hex_RP_WeaponESP', 			0, true, false)




-- Coding --
function RPESP()
if GetConVarNumber( "Hex_RP_MoneyPrinterESP" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "money_printer" or v:GetClass() == "reg_money_printer" or v:GetClass() == "platinum_printer" or v:GetClass() == "golden_printer" or v:GetClass() == "zz_money_printer" or v:GetClass() == "money_printer_commercial" or v:GetClass() == "money_printer_industrial" then
MoneyPrinterPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "TabLarge", MoneyPrinterPos.x, MoneyPrinterPos.y, Gold, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
end

if GetConVarNumber( "Hex_RP_MoneyESP" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "spawned_money" then
MoneyPos = v:EyePos():ToScreen()
draw.SimpleText( "Money: $" .. v.dt.amount, "TabLarge", MoneyPos.x, MoneyPos.y, Blue, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
end

if GetConVarNumber( "Hex_RP_ShipmentESP" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "spawned_shipment" && v:GetMoveType() != 0 then
ShipmentPos = v:EyePos():ToScreen()
 
local content = v.dt.contents
local contents = CustomShipments[content]
contents = contents.name
       
draw.SimpleText( "Shipment: " .. contents, "TabLarge", ShipmentPos.x, ShipmentPos.y, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
draw.SimpleText( "Count: " .. v.dt.count, "TabLarge", ShipmentPos.x, ShipmentPos.y + 22, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end
end

if GetConVarNumber( "Hex_RP_WeaponESP" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then
 
WeaponPos = v:EyePos():ToScreen()
 
draw.SimpleText( v:GetClass(), "TabLarge", WeaponPos.x, WeaponPos.y, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
							end
						end
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "RpESP", RPESP )





