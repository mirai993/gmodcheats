--[[
	Product:	Odius ( former MSBot/ShittyHack )
	Version:	1.5 (approx.)
	Author:		noPE
	Credits:	HL-SDK 			- Help with various stuff related to Source engine, cool guy in general
				UNKNOWNFILE 	- Same as HLSDK
				C0BRA 			- hook.Call and concommand.Run override help
				fr1kin			- Menu shit
				victormeriqui	- Various stuff, general cool guy
				
	TODO:		Fix prediction once SDK gets updated
				New menu... again
]]

local	_G				=	table.Copy( _G )
local require			= _G.require
local include			= _G.include

-- Include fresh copies of libraries I'll need --
include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )

-- asdf --
local math 					= table.Copy( math )
local string 				= table.Copy( string )
local debug 				= table.Copy( debug )
local table 				= table.Copy( table )
local player				= table.Copy( player )
local surface				= table.Copy( surface )
local util 					= table.Copy( util )

local pcall 				= _G.pcall
local error 				= _G.error
local ErrorNoHalt 			= _G.ErrorNoHalt
local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local print 				= _G.print
local type 					= _G.type
local RunConsoleCommand 	= _G.RunConsoleCommand
local CreateClientConVar 	= _G.CreateClientConVar
local CreateConVar 			= _G.CreateConVar
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local SortedPairs 			= _G.SortedPairs

-- Tables --
local Odius = {}
Odius.Funcs = {}
Odius.Detours = {}
Odius.Detours.List = {}
Odius.Hook = {}
Odius.Hooks = {}
Odius.GetWeapons = _R['Player'].GetWeapons
Odius.RecoilBackups = {}
Odius.TraitorList = {}
Odius.Concommand = {}
Odius.Concommands = {}
Odius.NoSpread = {}
Odius.PenetrationDmgMultiplier = 0
Odius.C4Queue = {}
Odius.Spectators = {}
Odius.FilterEnts = { LocalPlayer() }
Odius.NormalSpreadCones = {
		["weapon_cs_base"]	 = true,
		["darkland_base"]	 = true,
		["weapon_tttbase"]	 = true,
		["kermite_base"]	 = true,
		["kermite_base2"]	 = true,
		["weapon_real_base"] = true
}
Odius.CustomCones = {
	[ "weapon_zs_base" ]	=	function( wep )
									local flCone = wep.Cone or wep.Primary.Cone or 0
									
									if LocalPlayer():GetVelocity():Length() > 20 then
										return wep.ConeMoving
									end
									
									if LocalPlayer():Crouching() then
										return wep.ConeCrouching
									end
									
									return flCone
								end,
	[ "weapon_fl_base" ]	=	function( wep )
									local flLastShot = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 )
									local flLastShotMod = math.Clamp( wep.LastFireMax + 1 - math.Clamp( ( CurTime() - flLastShot ) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0, wep.LastFireMaxMod )
									local flCone = wep.Primary.Accuracy
									
									if LocalPlayer():IsMoving() then flCone = flCone * wep.MoveModifier end
									if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then flCone = flCone * 0.75 end
									
									flCone = flCone * ( ( 16 - wep.Owner:GetSkillLevel( "aim" ) ) / 11 )
									
									if LocalPlayer():KeyDown( IN_DUCK ) then
										return flCone * wep.CrouchModifier * flLastShotMod
									else
										return flCone * flLastShotMod
									end
								end,
	[ "weapon_sh_base" ]	=	function( wep )
									local flCone = wep.Primary.Cone
									local flRecoil = Odius.RecoilBackups[ wep:GetClass() ]
									local bIsSniper = wep.Sniper and 2 or 1
									
									local iStance = wep.Owner:IsOnGround() and wep.Owner:Crouching() and 10
									or !wep.Sprinting and wep.Owner:IsOnGround() and 15
									or wep.Walking and wep.Owner:IsOnGround() and 20
									or !wep.Owner:IsOnGround() and 25
									or wep.Primary.Ammo == "buckshot" and 0
									
									local iWepType = wep.Sniper and 8
									or wep.SMG and 2
									or wep.Pistol and 2
									or wep.Primary.Ammo == "buckshot" and 0
									or 1.6
									
									local iShotgun = wep.Primary.Ammo == "buckshot" and wep.Primary.Cone or 0
									
									if wep:GetIronsights() then
										return flCone
									else
										return flCone * flRecoil * iStance * iWepType + iShotgun
									end
								end,
	[ "weapon_sh_base_pistol" ]	=	function( wep ) return Odius.CustomCones[ "weapon_sh_base" ]( wep ) end
}
Odius.HL2Cones = {
		["#HL2_SMG1"]        = Vector( 0.04362, 0.04362, 0.04362 ),
		["#HL2_Pistol"]      = Vector( 0.0100, 0.0100, 0.0100 ),
		["#HL2_Pulse_Rifle"] = Vector( 0.02618, 0.02618, 0.02618 )
}
Odius.Projectiles = {
		["weapon_crossbow"]			=	3500,
		["soldier_rocketlauncher"]	=	1050,
		["soldier_blackbox"]		=	1050,
		["soldier_directhit"]		=	1960
}
Odius.TraitorWeps = {
		["weapon_ttt_c4"]		= true,
		["weapon_ttt_flaregun"]	= true,
		["weapon_ttt_knife"]	= true,
		["weapon_ttt_phammer"]	= true,
		["weapon_ttt_push"]		= true,
		["weapon_ttt_radio"]	= true,
		["weapon_ttt_sipistol"]	= true,
		["weapon_ttt_teleport"]	= true,
		["weapon_gmg_bomb"]		= true
}
Odius.EntitiesToReveal = {
		[ "drug_lab" ]				=	{ n = "Drug Lab" },
		[ "money_printer" ]			=	{ n = "Money Printer" },
		[ "money_machine" ]			=	{ n = "Money Machine", f = function( ent ) return ent:GetDTInt( 0 ) end },			//	Penaco's DickRP
		[ "silver_money_printer" ]	=	{ n = "Silver Money Printer" },		//	RPServers.info
		[ "golden_money_printer" ]	=	{ n = "Golden Money Printer" },		//	RPServers.info
		[ "epic_money_printer" ]	=	{ n = "Epic Money Printer" },		//	RPServers.info
		[ "gunlab" ]				=	{ n = "Gun Lab" },
		[ "spawned_shipment" ]		=	{ n = "Shipment", f = function( ent ) return CustomShipments[ ent:GetDTInt( 0 ) ].name or "_empty_" end },
		[ "spawned_weapon" ]		=	{ n = "Weapon", f = function( ent ) return ent.weaponclass or "unknown" end },
		[ "spawned_money" ]			=	{ n = "Money", f = function( ent ) return ent:GetDTInt( 0 ) end }
}
Odius.Materials = {
		matWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
			[ "$basetexture" ] = "color/white"
		} ),
		matWhiteNonZ = CreateMaterial( "WhiteNonZMaterial", "VertexLitGeneric", {
			[ "$basetexture" ] = "color/white", [ "$ignorez" ] = 1
		} )
}
Odius.UMSGDetours = {
/*		[ "DarkRP_PlayerVar" ]	=	{ func	=	function( um, ... )
													local a, b, c = um:ReadEntity(), um:ReadString(), um:ReadString()
													print( a )
													print( b )
													print( c )
												end
									},*/
		[ "ttt_role" ]	=	{ func	=	function( um, ... )	
											Odius.TraitorList = {}
											Odius:PushToConsole( "Cleaning traitor table." )
										end
							}
}
Odius.CheatFiles = {
		"gmcl_thor.dll",
		"odius.lua",
		"detours.txt",
		"anticheats.txt",
		"hooks.txt"
}
Odius.ConsoleHistory = {
		"",
		"",
		"",
		"",
		"Odius loaded!"
}
Odius.FuckingNames = {
		"soupcan",
		"Jewish Banker",
		"Nomical",
		"Xeno123",
		"BurtonJ",
		"Fisheater",
		"_(=^o^=)/"
}

-- Even more locals --
Odius.Aim_Target = nil
Odius.Aim_Locked = false
Odius.Aim_Aiming = false
Odius.Zoom_Enabled = false
Odius.TriggerShouldFire = false
Odius.NoSpread.CurSpreadCone = 0
Odius.CalcView_RealAngle = Angle( 0, 0, 0 )
Odius.SpinBotAngle = Angle( 0, 0, 0 )
Odius.ConstantNoSpreadAngle = Angle( 0, 0, 0 )

-- Local CVars --
local Aim_AutoShoot 			= CreateClientConVar( "odius_aim_autoshoot", 0, true, false )
local Aim_FOV					= CreateClientConVar( "odius_aim_fov", 8, true, false )
local Aim_Mode					= CreateClientConVar( "odius_aim_mode", "bone", true, false )
local Aim_VecOffset				= CreateClientConVar( "odius_aim_vecoffset", 30, true, false )
local Aim_NoRecoil 				= CreateClientConVar( "odius_aim_norecoil", 1, true, false )
local Aim_NoSpread 				= CreateClientConVar( "odius_aim_nospread", 1, true, false )
local Aim_ConstNoSpread 		= CreateClientConVar( "odius_aim_nospread_const", 1, true, false )
local Aim_NPC		 			= CreateClientConVar( "odius_aim_npcs", 1, true, false )
local Aim_Deathmatch 			= CreateClientConVar( "odius_aim_deathmatch", 1, true, false )
local Aim_Penetration 			= CreateClientConVar( "odius_aim_penetration", 1, true, false )
local Aim_Prediction		 	= CreateClientConVar( "odius_aim_prediction", 0, true, false )
local Aim_ProtectBuddies 		= CreateClientConVar( "odius_aim_ignorebuddies", 1, true, false )
local Aim_SilentAim				= CreateClientConVar( "odius_aim_silentaim", 0, true, false )
local Aim_SmoothAim				= CreateClientConVar( "odius_aim_smoothfactor", 0, true, false )
local Aim_Triggerbot			= CreateClientConVar( "odius_aim_triggerbot", 0, true, false )
local ESP 						= CreateClientConVar( "odius_esp_enabled", 1, true, false )
local ESP_Name	 				= CreateClientConVar( "odius_esp_name", 1, true, false )
local ESP_NPC	 				= CreateClientConVar( "odius_esp_npcs", 1, true, false )
local ESP_Entities				= CreateClientConVar( "odius_esp_entities", 1, true, false )
local Wallhack 					= CreateClientConVar( "odius_wallhack", 1, true, false )
local Chams 					= CreateClientConVar( "odius_chams", 0, true, false )
local Misc_Spinbot 				= CreateClientConVar( "odius_misc_spin", 0, true, false )
local Misc_ULXUngag 			= CreateClientConVar( "odius_misc_ungag", 0, true, false )
local Misc_DetonateC4			= CreateClientConVar( "odius_misc_autoc4", 0, true, false )

-- Yay fonts --
surface.CreateFont( "coolvetica", 17, 400, true, false, "ESPFont" )

-- And the award goes to:
function Odius:PushToConsole( stuff )
	for key, val in pairs( Odius.ConsoleHistory ) do
		if key == table.maxn( Odius.ConsoleHistory ) then
			Odius.ConsoleHistory[ key ] = stuff
		else
			Odius.ConsoleHistory[ key ] = Odius.ConsoleHistory[ key + 1 ]
		end
	end
end

/***************************************************
		---		ANTICHEAT BYPASSES HERE		---
***************************************************/
function Odius.Funcs.AddHook( name, id, func )
	Odius.Hooks[id] = 	{
							name = name,
							func = func
	}
end

function Odius.Funcs.AddConsoleCommand( name, func, afunc, help )
	AddConsoleCommand( name, help )
	Odius.Concommands[name] = 	{ 
									func = func,
									afunc = afunc,
									help = help
	}
end

-- Let's unlock some stuff first, shall we? --
rawset( _G, "__metatable", false )
rawset( hook, "__metatable", false )
rawset( concommand, "__metatable", false )

/***************************************************
	---				LOL DETOURS				---
***************************************************/
-- This is how I roll --
function Odius.Detours:DetourFunc( old, new )
	Odius.Detours.List[new] = old
	
	return new
end
/*
setmetatable = Odius.Detours:DetourFunc( setmetatable, function( name, tbl )
	if tbl[__metatable] == true then
		PrintTable( tbl )
		Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] FAC status = denied.\n" )
		return
	end
	
	return Odius.Detours.List[setmetatable]( name, tbl )
end )
*/
debug.getinfo = Odius.Detours:DetourFunc( debug.getinfo, function( func, penis )
	return Odius.Detours.List[debug.getinfo]( Odius.Detours.List[func] or func, penis )
end )

debug.getupvalue = Odius.Detours:DetourFunc( debug.getupvalue, function( func, index )
	return Odius.Detours.List[debug.getupvalue]( Odius.Detours.List[func] or func, index )
end )

-- Yep
_G.require = Odius.Detours:DetourFunc( _G.require, function( module )
	return Odius.Detours.List[_G.require]( module )
end )

RunConsoleCommand = Odius.Detours:DetourFunc( RunConsoleCommand, function( cmd, ... )
	if cmd == "-voicerecord" then
		return
	end
	
	return Odius.Detours.List[RunConsoleCommand]( cmd, ... )
end )

/***************************************************
	---			MODULE TRACE CLEANUP		---
***************************************************/
/*
 _G.require ( "thor" )

-- Copy all Thor stuff into a local table, for security reasons --
if package.loaded.thor then
	Odius.Thor = table.Copy( thor )
	_G.thor = nil
	package.loaded.thor = nil
end
*/

/***************************************************
	---			DETOUR CONTINUATION			---
***************************************************/

render.ReadPixel = Odius.Detours:DetourFunc( render.ReadPixel, function( x, y )
	return math.random( 0, 255 ), math.random( 0, 255 ), math.random( 0, 255 )
end )

usermessage.IncomingMessage = Odius.Detours:DetourFunc( usermessage.IncomingMessage, function( name, um, ... )
	if Odius.UMSGDetours[ name ] then
		Odius.UMSGDetours[ name ].func( um, ... )
	end
	
	return Odius.Detours.List[usermessage.IncomingMessage]( name, um, ... )
end )

hook.Call = Odius.Detours:DetourFunc( hook.Call, function( name, gm, ... )
	local ret = nil
	for k, tbl in pairs( Odius.Hooks ) do
		if tbl.name == name then
			if ... == nil then
				ret = tbl.func()
			else
				ret = tbl.func( ... )
			end
			
			if ret != nil then
				return ret
			end
		end
	end
	
	return Odius.Detours.List[hook.Call]( name, gm, ... )
end )

concommand.Run = Odius.Detours:DetourFunc( concommand.Run, function( pl, name, ... )
	local tbl = Odius.Concommands[name]
	
	if tbl != nil then
		return tbl.func( pl, name, ... )
	else
		return Odius.Detours.List[concommand.Run]( pl, name, ... )
	end
end )

-- ABOUT TIME I DID THE FOLLOWING
file.Exists = Odius.Detours:DetourFunc( file.Exists, function( filename, userbase )
	if not filename then return end
	
	for k, file in pairs( Odius.CheatFiles ) do
		if string.find( filename, file ) then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server tried to search for: " .. filename .. ". Denied.\n" )
			return false
		end
	end
	
	return Odius.Detours.List[file.Exists]( filename, userbase )
end )

file.ExistsEx = Odius.Detours:DetourFunc( file.ExistsEx, function( filename, addons )
	if not filename then return end
	
	for k, file in pairs( Odius.CheatFiles ) do
		if string.find( filename, file ) then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server tried to search for: " .. filename .. ". Denied.\n" )
			return false
		end
	end
	
	return Odius.Detours.List[file.ExistsEx]( filename, addons )
end )

-- this one was a beast to write
file.Find = Odius.Detours:DetourFunc( file.Find, function( filename, userbase )
	if not filename then return end
	
	for k, file_ in pairs( Odius.CheatFiles ) do
		if string.find( filename, file_ ) then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server tried to search for: " .. filename .. ". Denied.\n" )
			return false
		end
	end
	
	if string.find( filename, "/*." ) then
		Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server requested a file list in: " .. filename .. ". File list spoofed.\n" )
			
		local filetable = Odius.Detours.List[file.Find]( filename, userbase )
		local tabletoreturn = {}
			
		for k, file_ in pairs( filetable ) do
			if !table.HasValue( Odius.CheatFiles, file_ ) then
				table.insert( tabletoreturn, file_ )
			end
		end
		
		if ( #tabletoreturn or table.Count( tabletoreturn ) ) == 0 then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Spoofed file list was empty.\n" )
		else
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Spoofed file list was: " .. table.concat( tabletoreturn, ", " ) .. ".\n" )
		end
		
		return tabletoreturn
	end
	
	return Odius.Detours.List[ file.Find ]( filename, userbase )
end )

file.FindDir = Odius.Detours:DetourFunc( file.FindDir, function( path, userbase )
	if not path then return end
	
	if string.find( path, "*" ) then
		Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server requested a directory list. Dir list spoofed.\n" )
		
		local dirtable = Odius.Detours.List[file.FindDir]( path, userbase )
		local tabletoreturn = {}
		
		for k, dir_ in pairs( dirtable ) do
			if dir != "thor" then
				table.insert( tabletoreturn, dir_ )
			end
		end
		
		if ( #tabletoreturn or table.Count( tabletoreturn ) ) == 0 then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Spoofed dir list was empty.\n" )
		end
		
		return tabletoreturn
	end
	
	if string.find( path, "thor" ) then return false end
	
	return Odius.Detours.List[ file.FindDir ]( path, userbase )
end )

file.FindInLua = Odius.Detours:DetourFunc( file.FindInLua, function( path, userbase )
	if not path then return end
	
	if string.find( path, "*" ) then
		Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server requested a file list in: " .. path .. ". File list spoofed.\n" )
			
		local filetable = Odius.Detours.List[file.FindInLua]( path, userbase )
		local tabletoreturn = {}
			
		for k, file_ in pairs( filetable ) do
			if !table.HasValue( Odius.CheatFiles, file_ ) then
				table.insert( tabletoreturn, file_ )
			end
		end
		
		if ( #tabletoreturn or table.Count( tabletoreturn ) ) == 0 then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Spoofed file list was empty.\n" )
		else
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Spoofed file list was: " .. table.concat( tabletoreturn, ", " ) .. ".\n" )
		end
		
		return tabletoreturn
	end
	
	if string.find( path, "thor" ) then return false end
	
	return Odius.Detours.List[ file.FindInLua ]( path, userbase )
end )

file.Read = Odius.Detours:DetourFunc( file.Read, function( path, userbase )
	if not path then return end
	
	if string.find( path, "odius" ) then
		if string.find( GetConVarString( "hostname" ), "sethhack" ) then
			Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Seth tried to read Odius source.\n" )
			
			return "fuck you seth"
		end
		
		Odius.Thor.WriteLog( "anticheats", "[" .. os.date() .. "] Server tried reading odius.lua, denied!\n" )
		
		return nil
	end
	
	return Odius.Detours.List[ file.Read ]( path, userbase )
end )

util.RelativePathToFull = Odius.Detours:DetourFunc( util.RelativePathToFull, function ( path )
	return "big dikes"
end )

/*
_R["Entity"].FireBullets = Odius.Detours:DetourFunc( _R["Entity"].FireBullets, function( ent, bullet )
	Odius.NoSpread.CurSpreadCone = bullet.Spread
	return Odius.Detours.List[_R["Entity"].FireBullets]( ent, bullet )
end)
*/
/***************************************************
	---				CORE CODENS				---
***************************************************/
-- Backing up some LUA shit --
Odius.Hook.Remove = hook.Remove

-- Empty vars --
local Aim_Enabled

local function RandomString()
	local j, r = 0, ""
		
	for i = 1, math.random( 3, 19 ) do
		j = math.random( 65, 116 )
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char( j )
	end
	return r
end

local function FillRGBA( x, y, w, h, col ) 
	surface.SetDrawColor( col.r, col.g, col.b, 200 )
	surface.DrawRect( x, y, w, h )
end

/***************************************************
	Method:		AddHook
	Purpose:	Inserts a hook into a table for
				later use and adds it to the game
***************************************************/
function Odius:AddHook( h, f )
	local n = RandomString()
		
	Odius.Funcs.AddHook( h, n, f )
end

/***************************************************
	Method:		AddConcommand
	Purpose:	Adds a concommand
***************************************************/
function Odius:AddConcommand( concomm, func )
	Odius.Funcs.AddConsoleCommand( concomm, func )
end

/***************************************************
	Method:		GetHeadPos
	Purpose:	Get head position of an entity
***************************************************/
function Odius:GetHeadPos( ent )
	local model = ent:GetModel() or ""
	
    if model:find( "crow" ) or model:find( "seagull" ) or model:find( "pigeon" ) then
        return ent:LocalToWorld( ent:OBBCenter() + Vector( 0, 0, -5 ) )
    elseif ent:GetAttachment( ent:LookupAttachment( "eyes" ) ) ~= nil then
        return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos
	elseif model:find( "headcrab" ) then
		return ent:GetPos() + Vector( 0, 0, 5 )
    else
        return ent:LocalToWorld( ent:OBBCenter() )
    end
end

/***************************************************
	Method:		GetVecPos
	Purpose:	Get the vector position of an entity
				( alt aimbot mode )
***************************************************/
function Odius:GetVecPos( ent )
	return ent:LocalToWorld( ent:OBBCenter() + Vector( 5, 0, Aim_VecOffset:GetInt() ) )
end

/***************************************************
	Method:		DrawBox
	Purpose:	Draws a box around an entity
***************************************************/
function Odius:DrawBox( ent, col )
	if ent:Health() <= 0 || !ent:Alive() then return end
	
	local obbmin = ( ent:GetPos() + ( LocalPlayer():GetRight() * -25 ) ):ToScreen()
	local obbmax = ( ent:GetPos() + ( LocalPlayer():GetRight() * 21 ) + ( ent:GetUp() * 72) ):ToScreen()
			
	surface.SetDrawColor( col.r, col.g, col.b, 255 )
	surface.DrawLine( obbmin.x, obbmax.y, obbmax.x, obbmax.y )
	surface.DrawLine( obbmin.x, obbmin.y, obbmin.x, obbmax.y )
	surface.DrawLine( obbmax.x, obbmax.y, obbmax.x, obbmin.y )
	surface.DrawLine( obbmin.x, obbmin.y, obbmax.x, obbmin.y )
end

/***************************************************
	Method:		DrawESPInfo
	Purpose:	Draws ESP information based on
				user's likings
***************************************************/
function Odius:DrawESPInfo( ent, color )
	if ( ent:IsPlayer() && ent:Health() <= 0 ) ||
	Odius.Thor.IsEntDormant( ent:EntIndex() ) ||
	( ent:IsPlayer() && !ent:Alive() ) ||
	( ent:IsNPC() && ent:GetMoveType() == 0 ) then
		return
	end
	
	local entpos = ( ent:GetPos() + Vector( 0, 0, 25 ) ):ToScreen()
	
	if ent:IsPlayer() then
		draw.SimpleTextOutlined( ent:Nick(), "ESPFont", entpos.x, entpos.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
	elseif ent:IsNPC() then
		draw.SimpleTextOutlined( ent:GetClass(), "ESPFont", entpos.x, entpos.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
	elseif Odius.EntitiesToReveal[ ent:GetClass() ] then
		local name = Odius.EntitiesToReveal[ ent:GetClass() ].n
		local owner = ( ValidEntity( ent:GetDTEntity( 0 ) ) and ent:GetDTEntity( 0 ):Nick() ) or ( ValidEntity( ent:GetDTEntity( 1 ) ) and ent:GetDTEntity( 1 ):Nick() ) or "none"
		local additional = Odius.EntitiesToReveal[ ent:GetClass() ].f and Odius.EntitiesToReveal[ ent:GetClass() ].f( ent ) or nil
		
		draw.SimpleTextOutlined( "N: " .. name, "ESPFont", entpos.x, entpos.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		draw.SimpleTextOutlined( "O: " .. owner, "ESPFont", entpos.x, entpos.y + 14, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		
		if additional != nil then
			draw.SimpleTextOutlined( "A: " .. additional, "ESPFont", entpos.x, entpos.y + 28, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black )
		end
	end
end

/***************************************************
	Method:		SetVAngles
	Purpose:	Sets player viewangles
***************************************************/
function Odius:SetVAngles( cmd, angs )
	return _R.CUserCmd.SetViewAngles( cmd, angs )
end

/***************************************************
	Method:		GetVAngles
	Purpose:	Gets player viewangles
***************************************************/
function Odius:GetVAngles( cmd )
	return _R.CUserCmd.GetViewAngles( cmd )
end

/***************************************************
	Method:		SmoothAngleMovement
	Purpose:	Returns smooth aim angle for legit
				looking aiming
***************************************************/
function Odius:SmoothAngleMovement( ang )
	local current = LocalPlayer():GetAimVector():Angle()
	local speed = Aim_SmoothAim:GetInt()
	
--	current.p = math.ApproachAngle( math.NormalizeAngle( current.p ), math.NormalizeAngle( ang.p ), speed * FrameTime() )
--	current.y = math.ApproachAngle( math.NormalizeAngle( current.y ), math.NormalizeAngle( ang.y ), speed * FrameTime() )
	current = LerpAngle( speed * FrameTime(), current, ang )
	current.r = 0
				
	return Angle( current.p, current.y, current.r )
end

/***************************************************
	Method:		PredictProjectile
	Purpose:	Make HLSDK m@d
***************************************************/
function Odius:PredictProjectile( pos , pl )
	if ValidEntity( pl ) && type( pl:GetVelocity() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon && ( ValidEntity( LocalPlayer():GetActiveWeapon() ) && LocalPlayer():GetActiveWeapon():GetClass() ) )
		
		if weapon && Odius.Projectiles[weapon] then
			local time = ( distance / Odius.Projectiles[weapon] ) + 0.05
			
			return pos + pl:GetVelocity() * time
		elseif weapon && weapon == "sniper_huntsman" then
			local charge = Lerp( LocalPlayer():GetActiveWeapon()["Charge"] or 1 / 100, 200, 3200 )
			local time = ( distance / charge ) + 0.05
			
			return pos + pl:GetVelocity() * time
		end
		
		return pos
	end
	
	return pos
end

function Odius:IsPenetratable( tr, bounce )
	local MaxPenetration
	local wep = LocalPlayer():GetActiveWeapon()
	
	if not ValidEntity( wep ) then return end
	
	if wep.Base != "weapon_mad_base" then return false end
	
	if wep.Primary.Ammo == "AirboatGun" then // 5.56MM Ammo
		MaxPenetration = 18
	elseif wep.Primary.Ammo == "Gravity" then // 4.6MM Ammo
		MaxPenetration = 8
	elseif wep.Primary.Ammo == "AlyxGun" then // 5.7MM Ammo
		MaxPenetration = 12
	elseif wep.Primary.Ammo == "Battery" then // 9MM Ammo
		MaxPenetration = 14
	elseif wep.Primary.Ammo == "StriderMinigun" then // 7.62MM Ammo
		MaxPenetration = 20
	elseif wep.Primary.Ammo == "SniperPenetratedRound" then // .45 Ammo
		MaxPenetration = 16
	elseif wep.Primary.Ammo == "CombineCannon" then // .50 Ammo
		MaxPenetration = 20
	else
		MaxPenetration = 16
	end

	local DoDefaultEffect = true
	// Don't go through metal, sand or player
	if ((tr.MatType == MAT_METAL and wep.Ricochet) or (tr.MatType == MAT_SAND) or (tr.Entity:IsPlayer())) then return false end
	
//	if ( bounce > 3 ) then return false end
	
	// Direction (and length) that we are going to penetrate
	local PenetrationDirection = tr.Normal * MaxPenetration
	
	if (tr.MatType == MAT_GLASS or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_WOOD or tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH) then
		PenetrationDirection = tr.Normal * ( MaxPenetration * 2 )
	end
		
	local trace 	= {}
	trace.endpos 	= tr.HitPos
	trace.start 	= tr.HitPos + PenetrationDirection
	trace.mask 		= MASK_SHOT
	trace.filter 	= {wep.Owner}
	   
	local trace 	= util.TraceLine(trace) 
	
	// Bullet didn't penetrate.
	if (trace.StartSolid or trace.Fraction >= 1.0 or tr.Fraction <= 0.0) then return false end
	
	// Damage multiplier depending on surface
	Odius.PenetrationDmgMultiplier = 0.5
	
	if (tr.MatType == MAT_CONCRETE) then
		Odius.PenetrationDmgMultiplier = 0.3
	elseif (tr.MatType == MAT_WOOD or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_GLASS) then
		Odius.PenetrationDmgMultiplier = 0.8
	elseif (tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH) then
		Odius.PenetrationDmgMultiplier = 0.9
	end
	
	return true
end

/***************************************************
	Method:		GetCone
	Purpose:	Get current weapon's spread cone
***************************************************/
function Odius:GetCone( wep )
	if not ValidEntity( wep ) then return 0 end
	
	if Odius.HL2Cones[ wep:GetPrintName() ] then return Odius.HL2Cones[ wep:GetPrintName() ] end
	if Odius.NormalSpreadCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
	if Odius.CustomCones[ wep.Base ] then return Odius.CustomCones[ wep.Base ]( wep ) end
	
	local flCone = wep.Cone
	
	if not flCone then
		flCone = wep.Primary and wep.Primary.Cone or 0
	end
	
	return flCone
end

/***************************************************
	Method:		IsEntVisible
	Purpose:	Checks if an entity is visible by
				the local player
***************************************************/
function Odius:IsEntVisible( ent )
	if ent == NULL then return end
	
	local trace = {}
    trace.start = LocalPlayer():GetShootPos()
--	if Aim_Prediction:GetBool() then
--		trace.endpos = Odius.Thor.LagCompensation( Odius:GetHeadPos( ent ) )
--	else
		trace.endpos = Odius:GetHeadPos( ent )
--	end
    trace.filter = { LocalPlayer(), ent }
    trace.mask = 1174421507
	
    local tr = util.TraceLine( trace )
	
	return tr.Fraction >= 0.99 and true or Aim_Penetration:GetBool() and Odius:IsPenetratable( tr, 1 ) or false
end

/***************************************************
	Method:		AddToFriends
	Purpose:	Add a player to aimbot's ignore list
***************************************************/
function Odius:AddToFriends( ent )
	if !table.HasValue( Odius.Friends, ent ) then
		table.insert( Odius.Friends, ent )
		Odius.Thor.Notify( Color( 0, 255, 0, 255 ), ent:Nick() .. " will be ignored by the aimbot." )
	end
end

/***************************************************
	Method:		ValidTarget
	Purpose:	Perform a shitload of checks and
				select a desired target
***************************************************/
function Odius:ValidTarget( e )	
	if ( !ValidEntity( e ) ) || ( e == LocalPlayer() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end
	
	if ( e:GetMoveType() == 0 ) then return false end
	if ( e:IsPlayer() and !e:Alive() ) then return false end
	if ( e:IsPlayer() and e:Health() <= 0 ) then return false end
	if ( e:IsPlayer() and Odius.Thor.IsEntDormant( e:EntIndex() ) ) then return false end
	if ( e:IsPlayer() and ( e:Team() == LocalPlayer():Team() and not Aim_Deathmatch:GetBool() ) ) then return false end
	if ( e:IsPlayer() and ( e:GetFriendStatus() == "friend" and Aim_ProtectBuddies:GetBool() ) ) then return false end
	if ( e:IsNPC() and not Aim_NPC:GetBool() ) then return false end
	if ( e:IsNPC() and Odius.Thor.IsEntDormant( e:EntIndex() ) ) then return false end
	
	/*
		--	DEPRECATED
	local m = e:GetMoveType()
	
	if ( m == MOVETYPE_NONE ) then return false end
	
	if ( e:IsPlayer() ) then
		if ( !e:Alive() || e:Health() <= 0 ) ||
		( m == ( MOVETYPE_OBSERVER || MOVETYPE_NONE ) ) ||
		( e:Team() == LocalPlayer():Team() && !Aim_Deathmatch:GetBool() ) ||
		Odius.Thor.IsEntDormant( e:EntIndex() ) ||
		( e:GetFriendStatus() == "friend" && Aim_ProtectBuddies:GetBool() ) then
			return false
		end
	elseif e:IsNPC() then
		if ( e:Health() <= 0 ) ||
		Odius.Thor.IsEntDormant( e:EntIndex() ) then
			return false
		end
	end
	*/
	
	if ( Aim_FOV:GetInt() != 180 || Aim_FOV:GetInt() != 0 ) then
		local a = LocalPlayer():GetAimVector():Angle()
		local o = { p, y } -- s0 ghett0
		local t = ( Odius:GetHeadPos( e ) - LocalPlayer():GetShootPos() ):Angle()
		o.p = math.abs( math.NormalizeAngle( a.p - t.p ) )
		o.y = math.abs( math.NormalizeAngle( a.y - t.y ) )
		
		if ( o.p >= Aim_FOV:GetInt() || o.y >= Aim_FOV:GetInt() ) then return false end
	end
		
	return true
end

/***************************************************
	Method:		GetClosestTarget
	Purpose:	Finds a target that is closest to
				crosshair
***************************************************/
function Odius.GetClosestTarget()
    local pos = LocalPlayer():EyePos()
    local ang = LocalPlayer():GetAimVector()
    local closest = { 0, 0 }
	local enttable = Aim_NPC:GetBool() and ents.GetAll() or player.GetAll()
	
    for k, ent in pairs( enttable ) do
		if Odius:ValidTarget( ent ) && Odius:IsEntVisible( ent ) then
			local diff = ( ent:EyePos() - pos ):Normalize()
		
			diff = diff - ang
			diff = diff:Length()
			diff = math.abs( diff )
		
			if ( diff < closest[2] ) or ( closest[1] == 0 ) then
				closest = { ent, diff }
			end
		end
    end
	
	return closest[1]
end

/***************************************************
	Function:		ESP
	Purpose:		Draws ESP information around
					entities, based on player's
					likings
***************************************************/
function Odius.ESP()
	if ESP:GetBool() then
		for k, v in pairs( ents.GetAll() ) do
			if ValidEntity( v ) && v:IsPlayer() && v != LocalPlayer() then
				if ESP_Name:GetBool() then
					Odius:DrawESPInfo( v, Color( 238, 116, 0 ) )
				end
			elseif ValidEntity( v ) && Odius.EntitiesToReveal[ v:GetClass() ] then
				if ESP_Entities:GetBool() then
					Odius:DrawESPInfo( v, Color( 255, 255, 255 ) )
				end
			elseif ValidEntity( v ) and v:IsNPC() then
				if ESP_NPC:GetBool() then
					Odius:DrawESPInfo( v, Color( 153, 217, 234 ) )
				end
			end
		end
	end
end

/***************************************************
	Function:		Console
	Purpose:		Displays shit
***************************************************/
function Odius.Console()
	local int = 0
	
	draw.RoundedBox( 1, ScrW() / 2 - 150, ScrH() - 80, 300, 80, Color( 0, 0, 0, 150 ) )
	
	for k, v in pairs( Odius.ConsoleHistory ) do
		draw.SimpleText( v, "TabLarge", ScrW() / 2 - 145, ( ScrH() - 75 ) + int, Color( 255, 255, 255 ) )
		int = int + 13
	end
end

/***************************************************
	Function:		Visuals
	Purpose:		Wallhacks, chams, etc.
***************************************************/
function Odius.Visuals()
	-- Wallhack --
	if Wallhack:GetBool() && !Chams:GetBool() then
		cam.Start3D( EyePos(), EyeAngles() )
			for k, v in pairs ( player.GetAll() ) do
				if v:IsPlayer() && v != LocalPlayer() &&
				v:Health() > 0 && v:Alive() &&
				!Odius.Thor.IsEntDormant( v:EntIndex() ) &&
				v:GetMoveType() != MOVETYPE_OBSERVER then
					local mat = v:GetMaterial()
					local tc = team.GetColor( v:Team() )
					
					cam.IgnoreZ( true )
					v:DrawModel()
					cam.IgnoreZ( false )
				end
			end
		cam.End3D()
	-- Chams --
	elseif !Wallhack:GetBool() && Chams:GetBool() then
		for i, ply in pairs( player.GetAll() ) do
			if ply:IsPlayer() && ply != LocalPlayer() &&
				ply:Health() > 0 && ply:Alive() &&
				!Odius.Thor.IsEntDormant( ply:EntIndex() ) &&
				ply:GetMoveType() != MOVETYPE_OBSERVER then
				local teamColor = team.GetColor( ply:Team() )
			
				render.SetColorModulation( ( 255 - teamColor.r ) / 255, ( 255 - teamColor.g ) / 255, ( 255 - teamColor.b ) / 255 )
				SetMaterialOverride( Odius.Materials.matWhiteNonZ )
					ply:DrawModel()
				SetMaterialOverride()
			
				render.SetColorModulation( teamColor.r / 255, teamColor.g / 255, teamColor.b / 255 )
				SetMaterialOverride( Odius.Materials.matWhite )
					ply:DrawModel()
				SetMaterialOverride()
			end
		end
	end
end

/***************************************************
	Function:		AutoShoot
	Purpose:		Automatically shoot if we have
					a target
***************************************************/
Odius.NextShot = 0
function Odius.AutoShoot()
	local wep = LocalPlayer():GetActiveWeapon()
	if Aim_AutoShoot:GetBool() then
		if Odius.TriggerShouldFire == true || ( Odius.Aim_Aiming && Odius.Aim_Locked && Odius:ValidTarget( Odius.Aim_Target ) && Odius:IsEntVisible( Odius.Aim_Target ) && Odius.TriggerShouldFire == false ) then
			if !ValidEntity( wep ) then return end
			
			if Odius.NextShot and Odius.NextShot < RealTime() then
				Odius.Firing = true
				RunConsoleCommand( "+attack" )
				Odius.NextShot = RealTime() + ( LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
			else
				RunConsoleCommand( "-attack" )
				Odius.Firing = false
			end
		elseif Odius.Firing then
			Odius.Firing = false
			RunConsoleCommand( "-attack" )
		end
	end
end

/***************************************************
	Function:		Aimbot
	Purpose:		hurr
***************************************************/
Odius.SilentAngs = Angle( 0, 0, 0 )
function Odius.Aimbot( ucmd )
	Odius.CalcView_RealAngle = ucmd:GetViewAngles()
	
	Odius.SilentAngs.p = math.Clamp( Odius.SilentAngs.p + ( ucmd:GetMouseY() * 0.022 ), -89, 89 )
	Odius.SilentAngs.y = math.NormalizeAngle( Odius.SilentAngs.y + ( ucmd:GetMouseX() * 0.022 * -1 ) )

	if Aim_SilentAim:GetBool() then
		local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( Odius.CalcView_RealAngle - Odius.SilentAngs ) ):Forward() * move:Length()
		
		ucmd:SetForwardMove( set.x )
		ucmd:SetSideMove( set.y )
		
		if Odius.Aim_Locked == false && !Odius.Aim_Target then
			Odius:SetVAngles( ucmd, Odius.SilentAngs )
		end
	end
	
	if ( !Odius.Aim_Aiming ) then return end
	
	if Odius.Aim_Locked == false then
		Odius.Aim_Target = Odius.GetClosestTarget()
	end
	
	if ( Odius.Aim_Target == 0 || Odius.Aim_Target == nil ) then
		Odius.Aim_Locked = false
		return
	end
		
	if Odius:ValidTarget( Odius.Aim_Target ) then
		local headpos
		if Aim_Mode:GetString() == "bone" then
			headpos = Odius:GetHeadPos( Odius.Aim_Target )
		elseif Aim_Mode:GetString() == "vector" then
			headpos = Odius:GetVecPos( Odius.Aim_Target )
		end
		
		-- Player prediction
--		if Aim_Prediction:GetBool() then
--			headpos = Odius:PredictProjectile( headpos, Odius.Aim_Target ) // Odius.Aim_Target:GetPos() + Vector( 0, 0, 5 )
--			headpos = Odius:PredictPlayer( headpos )
--		else
--			headpos = headpos
--		end
		
		local shootpos = LocalPlayer():GetShootPos()
		
		local aimang = ( headpos - shootpos ):Angle()
		
		aimang.p = math.NormalizeAngle( aimang.p )
		aimang.y = math.NormalizeAngle( aimang.y )
			
		if Odius.Aim_Target == LocalPlayer() then
			Odius.Aim_Locked = false
			Odius.Aim_Target = nil
			return
		end
		
		if !Odius:IsEntVisible( Odius.Aim_Target ) then
			Odius.Aim_Locked = false
			Odius.Aim_Target = nil
			return
		end
		
		Odius.Aim_Locked = true
		
		local spreadCone = Odius:GetCone( LocalPlayer():GetActiveWeapon() )
		
		if type( spreadCone ) != "Vector" then
			spreadCone = Vector( -spreadCone, -spreadCone, 0 )
		else
			spreadCone = Vector( 0, 0, 0 ) - spreadCone
		end
		
		if Aim_NoSpread:GetBool() then
			aimang = Odius.Thor.FuckSpread( ucmd, aimang:Forward(), spreadCone ):Angle()
			
			Odius.CalcView_RealAngle = ( headpos - LocalPlayer():GetShootPos() ):Angle()
		else
			aimang = ( headpos - LocalPlayer():GetShootPos() ):Angle()
		end
		
		aimang.p = math.NormalizeAngle( aimang.p )
		aimang.y = math.NormalizeAngle( aimang.y )
		aimang.r = 0
		
		if Aim_SmoothAim:GetInt() > 0 then
			local smoothang = Odius:SmoothAngleMovement( aimang )
			
			Odius.CalcView_RealAngle = smoothang
			Odius:SetVAngles( ucmd, smoothang )
		else
			Odius:SetVAngles( ucmd, aimang )
		end
	else
		Odius.Aim_Locked = false
		Odius.Aim_Target = nil
	end
end

/***************************************************
	Function:		CreateMoveMisc
	Purpose:		Other shit that requires CreateMove
***************************************************/
Odius.PKMode = false
Odius.ReadyToPK = false
Odius.PKAngles = Angle( 0, 0, 0 )
Odius.SpinBotAngle = Angle( 0, 0, 0 )
local bDisableSpin = false
function Odius.CreateMoveMisc( ucmd )
	if Odius.PKMode == false && Odius.ReadyToPK == true then		
		Odius.ReadyToPK = false
		
		ucmd:SetViewAngles( Odius.PKAngles )
	elseif Odius.PKMode == false then
		local ang_trueangles = ucmd:GetViewAngles()
		
		Odius.PKAngles = ang_trueangles
	else
		local ang_trueangles = ucmd:GetViewAngles()
		
		Odius.PKAngles = ang_trueangles
		Odius.PKAngles.y = ang_trueangles.y - 180
		
		local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( Odius.PKAngles - ang_trueangles ) ):Forward() * move:Length()
		
		ucmd:SetForwardMove( -set.x )
		ucmd:SetSideMove( -set.y )
	end
	
	if Aim_SilentAim:GetBool() && Aim_ConstNoSpread:GetBool() then
		local spreadCone = Odius:GetCone( LocalPlayer():GetActiveWeapon() )
		
		if type( spreadCone ) != "Vector" then
			spreadCone = Vector( -spreadCone, -spreadCone, 0 )
		else
			spreadCone = Vector( 0, 0, 0 ) - spreadCone
		end
		
		Odius:SetVAngles( ucmd, Odius.Thor.FuckSpread( ucmd, aimang:Forward(), spreadCone ):Angle() )
	end
	
	if Misc_Spinbot:GetBool() and ( ucmd:GetButtons() & ( IN_ATTACK | IN_ATTACK2 ) ) == 0 then
		local ang_trueangles = ucmd:GetViewAngles()
		
		if not Odius.Aim_Locked then
			bDisableSpin = false
			
			Odius.SpinBotAngle.y = math.Clamp( Odius.SpinBotAngle.y + 25, -179, 179 )
			Odius.SpinBotAngle.r = 0
		
			ucmd:SetViewAngles( Odius.SpinBotAngle )
		
			local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local set = ( norm:Angle() + ( Odius.SpinBotAngle - Odius.SilentAngs ) ):Forward() * move:Length()
		
			ucmd:SetForwardMove( set.x )
			ucmd:SetSideMove( set.y )
		else
			bDisableSpin = true
		end
	end
end

/***************************************************
	Function:		CalcView
	Purpose:		Corrects local view
***************************************************/
local newfov = math.floor( GetConVarNumber( "fov_desired" ) )
function Odius.CalcView( u, origin, angles, fov )
	if GetViewEntity() != LocalPlayer() then return end
	
	-- No recoil --
	if Aim_NoRecoil:GetBool() then
		if ValidEntity( LocalPlayer():GetActiveWeapon() ) and not Odius.RecoilBackups[ LocalPlayer():GetActiveWeapon():GetClass() ] then
			Odius.RecoilBackups[ LocalPlayer():GetActiveWeapon():GetClass() ] = LocalPlayer():GetActiveWeapon().Primary.Recoil
		end
		
		if ( LocalPlayer():GetActiveWeapon().Primary ) then LocalPlayer():GetActiveWeapon().Primary.Recoil = 0.0 end
		if ( LocalPlayer():GetActiveWeapon().Secondary ) then LocalPlayer():GetActiveWeapon().Secondary.Recoil = 0.0 end
		
		if Odius.Zoom_Enabled == true then
			newfov = Lerp( 8 * FrameTime(), newfov, 29 )
		else
			newfov = Lerp( 8 * FrameTime(), newfov, math.floor( GetConVarNumber( "fov_desired" ) ) )
		end
		
		if Odius.PKMode == true then
		//	return { origin = origin, angles = Odius.PKAngles, fov = newfov }
			return GAMEMODE:CalcView( u, origin, Odius.PKAngles, newfov )
		end
		
		if Aim_SilentAim:GetBool() || ( Misc_Spinbot:GetBool() && bDisableSpin == false ) then
		//	return { origin = origin, angles = Odius.SilentAngs, fov = newfov }
			Odius.SilentAngs.r = 0
			return GAMEMODE:CalcView( u, origin, Odius.SilentAngs, newfov )
		end
		
	//	return { origin = origin, angles = Odius.CalcView_RealAngle, fov = newfov }
		Odius.CalcView_RealAngle.r = 0
		return GAMEMODE:CalcView( u, origin, Odius.CalcView_RealAngle, newfov )
	end
	
	return GAMEMODE:CalcView( u, origin, angles, fov )
end

/***************************************************
	Function:		AutoC4
	Purpose:		Suck dicks
***************************************************/
function Odius.AutoC4()
	if !Misc_DetonateC4:GetBool() or LocalPlayer():Health() <= 0 then return end
	
	local c4table = ents.FindByClass( "ttt_c4" )
	
	if table.Count( c4table ) < 1 then	return end
	
	for index, ent in pairs( c4table ) do
		if !ent:GetArmed() or LocalPlayer():IsTraitor() then return end
		
		Odius.Thor.Notify( Color( 128, 255, 0 ), "Detonating " .. ent:GetOwner():Nick() .. "'s C4..." )
		Odius:PushToConsole( "Detonating " .. ent:GetOwner():Nick() .. "'s C4..." )
		
		RunConsoleCommand( "ttt_c4_disarm", tostring( ent:EntIndex() ), math.random( 1000, 5000 ) )
	end
end

/***************************************************
	Function:		TraitorDetect
	Purpose:		Detect traitors and stuff
***************************************************/
function Odius.TraitorDetect()
	if !string.find( string.lower( GAMEMODE.Name ), "trouble in terr" ) then return end
	
	for k, v in pairs( Odius.TraitorList ) do
		if !ValidEntity( v ) then
			table.remove( Odius.TraitorList, k )
		end
	end
	
	for k, v in pairs( player.GetAll() ) do
		if v:Alive() && !table.HasValue( Odius.TraitorList, v ) then
			local wepons = Odius.GetWeapons( v )
			
			for index, wep in pairs( wepons ) do
				if ValidEntity( wep ) then
					wep = wep:GetClass()
				
					if Odius.TraitorWeps[wep] then
						table.insert( Odius.TraitorList, v )
						Odius:PushToConsole( v:Nick() .. " has a " .. wep )
						chat.AddText( Color( 255, 166, 0 ), "[Odius] ", Color( 255, 10, 10 ), v:Nick() .. " has a " .. wep .. "!" )
					end
				end
			end
		end
	end
end

/***************************************************
	Function:		Crosshair
	Purpose:		Draws a crosshair at the center
					of the screen
***************************************************/
function Odius.Crosshair()
	local x, y = ScrW() / 2, ScrH() / 2
	
	surface.SetDrawColor( 255, 0, 0, 255 )
 
	local gap = 0
	local length = 4
	
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )
end

/***************************************************
	Function:		RunLua
	Purpose:		Runs Lua codens
***************************************************/
function Odius.RunLua( ply, command, args )
	if args[1] == "" || args[1] == NULL || args[1] == nil then
		Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Invalid Lua codens." )
	else	
		Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Running Lua codens..." )
		RunString( tostring( args[1] ) )
	end
end


function Odius.HideC4( ply, command, args )
	local oldserv = SERVER
	SERVER = CLIENT
	
	local tr = {}
	tr.Fraction = 1.0
	
	for index, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
		pcall( ent.Explode, ent, tr )
		--ent:Explode( tr )
	end
	
	SERVER = oldserv
end

function Odius.DetonateC4()
	local c4table = ents.FindByClass( "ttt_c4" )
	
	if table.Count( c4table ) < 1 then
		Odius.Thor.Notify( Color( 255, 128, 0 ), "No C4s found. Dying..." )
		Odius:PushToConsole( "No C4s found. Dying..." )
		return
	end
	
	for index, ent in pairs( c4table ) do
		Odius.Thor.Notify( Color( 128, 255, 0 ), "Detonating " .. ent:GetOwner():Nick() .. "'s C4..." )
		Odius:PushToConsole( "Detonating " .. ent:GetOwner():Nick() .. "'s C4..." )
		
		RunConsoleCommand( "ttt_c4_disarm", tostring( ent:EntIndex() ), math.random( 1000, 5000 ) )
	end
end

/***************************************************
	Function:		PrintTraitors
	Purpose:		Prints all detected traitors in
					console
***************************************************/
function Odius.PrintTraitors()
	for i, p in pairs( Odius.TraitorList ) do
		Odius.Thor.Notify( Color( 255, 0, 0, 255 ), "[TRAITORS] " .. p:Nick() .. " is a traitor." )
	end
end

function Odius.RandomName()
	local randname = table.Random( Odius.FuckingNames )
	
	Odius:PushToConsole( "Setting name to " .. randname )
	LocalPlayer():ConCommand( "name " .. tostring( randname ) )
end

/***************************************************
	Function:		Unload
	Purpose:		Removes all the hooks and empties
					the hook table, unloading the
					hack almost completely
***************************************************/
function Odius.Unload()
	for n, h in pairs ( Odius.Hooks ) do
		local currenthook = string.format( "Removing %s hook [%s]", h.name, n )
		
		Odius.Thor.Notify( Color( 255, 128, 0, 255 ), currenthook )
		Odius.Hooks[n] = nil
	end
	
	Odius.Hooks = {}
end

/***************************************************
	Function:		Reload
	Purpose:		Reloads the hack
***************************************************/
function Odius.Reload()
	Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Reloading ..." )
	Odius.Unload()
	include( "autorun/client/odius.lua" )
	Odius.Thor.Notify( Color( 255, 128, 0, 255 ), "Reloaded!" )
end

/***************************************************
	Function:		ZoomIn
	Purpose:		Toggles zoom
***************************************************/
local backupsens = GetConVarNumber( "sensitivity" )
function Odius.ZoomIn()
	if Odius.Zoom_Enabled == true then
		Odius.Zoom_Enabled = false
		LocalPlayer():ConCommand( "sensitivity " .. backupsens )
	else
		Odius.Zoom_Enabled = true
		LocalPlayer():ConCommand( "sensitivity 2" )
	end
end

/***************************************************
	Function:		AimbotOn
	Purpose:		Starts the aimbot
***************************************************/
function Odius.AimbotOn( ply, cmd, args )
	Odius.Aim_Aiming = true
end

/***************************************************
	Function:		AimbotOff
	Purpose:		Turns off the aimbot
***************************************************/
function Odius.AimbotOff( ply, cmd, args )
	Odius.Aim_Aiming = false
	Odius.Aim_Target = nil
	Odius.Aim_Locked = false
end

/***************************************************
	Function:		PKOn
	Purpose:		Turns on prop kill mode
***************************************************/
function Odius.PKOn( ply, cmd, args )
	Odius.PKMode = true
end

/***************************************************
	Function:		PKOff
	Purpose:		Turns off prop kill mode
***************************************************/
function Odius.PKOff( ply, cmd, args )
	Odius.PKMode = false
	Odius.ReadyToPK = true
end

-- SWITCHING TO A NEW MENU --
local menuPanel -- So we can shutdown properly

function Odius:CreateCheckBox( x, y, label, cvar )
	local item = vgui.Create( "DCheckBoxLabel", menuPanel )
	item:SetPos( x, 20 + y * 15 )
	item:SetText( label )
	item:SetConVar( cvar )
	item:SetValue( GetConVarNumber( cvar ) )
	item:SizeToContents()
end

function Odius:CreateTitle( x, y, label, color )
	local item = vgui.Create( "DLabel", menuPanel )
	item:SetPos( x, 20 + y * 15 )
	item:SetColor( color )
	item:SetFont( "MenuLarge" )
	item:SetText( label )
	item:SizeToContents()
end

function Odius:CreateNumberWang( x, y, label, min, max, convar )
	local vglabel = vgui.Create( "DLabel", menuPanel )
	vglabel:SetPos( x, 20 + y + 3 )
	vglabel:SetFont( "default" )
	vglabel:SetText( label )
	vglabel:SizeToContents()
	
	local wang = vgui.Create( "DNumberWang", menuPanel )
	wang:SetPos( x + vglabel:GetWide() + 2, 20 + y )
	wang:SetConVar( convar )
	wang:SetMin( min )
	wang:SetMax( max )
	wang:SetDecimals( 0 )
	wang:SetValue( GetConVarNumber( convar ) )
end

function Odius.PopupMenu()
	menuPanel = vgui.Create( "DFrame" )
	menuPanel:SetPos( ScrW() / 2 - 200, ScrH() / 2 - 200 )
	menuPanel:SetSize( 400, 400 )
	menuPanel:SetTitle( "ODIUS :: REBORN(?)" )
	menuPanel.Paint = function()
		draw.RoundedBox( 1, 0, 0, menuPanel:GetWide(), menuPanel:GetTall(), Color( 0, 0, 0, 200 ) )
	end
	
	Odius:CreateTitle( 5, 1, "AIMBOT", color_white )
	Odius:CreateCheckBox( 5, 2, "Autoshoot", "odius_aim_autoshoot" )
	Odius:CreateCheckBox( 5, 3, "Friendly Fire", "odius_aim_deathmatch" )
	Odius:CreateCheckBox( 5, 4, "Aim at NPCs", "odius_aim_npcs" )
	Odius:CreateCheckBox( 5, 5, "Friend Protection", "odius_aim_ignorebuddies" )
	Odius:CreateCheckBox( 5, 6, "No recoil", "odius_aim_norecoil" )
	Odius:CreateCheckBox( 5, 7, "No spread", "odius_aim_nospread" )
	Odius:CreateCheckBox( 5, 8, "Factor in bullet penetration", "odius_aim_penetration" )
	Odius:CreateCheckBox( 5, 9, "Silent aim", "odius_aim_silentaim" )
	Odius:CreateNumberWang( 5, 151, "FOV:", 1, 180, "odius_aim_fov" )
	Odius:CreateNumberWang( 5, 181, "Smoothness:", 0, 45, "odius_aim_smoothfactor" )
	
	Odius:CreateTitle( 170, 1, "ESP", color_white )
	Odius:CreateCheckBox( 170, 2, "Enabled", "odius_esp_enabled" )
	Odius:CreateCheckBox( 170, 3, "Player Names", "odius_esp_name" )
	Odius:CreateCheckBox( 170, 4, "Draw NPCs", "odius_esp_npcs" )
	Odius:CreateCheckBox( 170, 5, "Draw Entities", "odius_esp_entities" )
	
	Odius:CreateTitle( 270, 1, "MISC", color_white )
	Odius:CreateCheckBox( 270, 2, "Wallhack", "odius_wallhack" )
	Odius:CreateCheckBox( 270, 3, "Chams", "odius_chams" )
	Odius:CreateCheckBox( 270, 4, "Spinbot", "odius_misc_spin" )
	Odius:CreateCheckBox( 270, 5, "Detonate C4's", "odius_misc_autoc4" )
	
	-- Keep this at the end --
	menuPanel:MakePopup()
end

-- Hooks --
Odius:AddHook( "PostDrawOpaqueRenderables", Odius.Visuals )
Odius:AddHook( "HUDPaint", Odius.ESP )
Odius:AddHook( "HUDPaint", Odius.Crosshair )
Odius:AddHook( "HUDPaint", Odius.Console )
Odius:AddHook( "CreateMove", Odius.Aimbot )
Odius:AddHook( "CreateMove", Odius.CreateMoveMisc )
Odius:AddHook( "CalcView", Odius.CalcView )
Odius:AddHook( "Think", Odius.AutoShoot )
Odius:AddHook( "Think", Odius.AutoC4 )
Odius:AddHook( "Tick", Odius.TraitorDetect )

-- Concommands --
Odius:AddConcommand( "odius_unload", Odius.Unload )
Odius:AddConcommand( "odius_reload", Odius.Reload )
Odius:AddConcommand( "odius_runlua", Odius.RunLua )
Odius:AddConcommand( "+odius_aim", Odius.AimbotOn )
Odius:AddConcommand( "+odius_pkmode", Odius.PKOn )
Odius:AddConcommand( "-odius_pkmode", Odius.PKOff )
Odius:AddConcommand( "-odius_aim", Odius.AimbotOff )
Odius:AddConcommand( "odius_zoom", Odius.ZoomIn )
Odius:AddConcommand( "odius_printtraitors", Odius.PrintTraitors )
Odius:AddConcommand( "odius_c4explode", Odius.DetonateC4 )
Odius:AddConcommand( "odius_menu", Odius.PopupMenu )
