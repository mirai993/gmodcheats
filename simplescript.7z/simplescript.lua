--this is a pk cheat I made, it has no menu, no convars, and all the values are pretty much baked in so no customizing stuff lol. I made it that way because I wanted a script that you can just execute and go pk with.
--The fov value by default is 140, so if you want to change it, goto the "CalcView" hook at the bottom and change the number that says 140. have fun with this ig

--[[===============
        LOCALS
===================]]

local Visuals = {}
local Misc = {}

local mat = CreateMaterial( "White9", "VertexLitGeneric", { 
    ["$basetexture"] = "models/debug/debugwhite", 
    ["$nocull"] = 1, 
    ["$model"] = 1 
})

surface.CreateFont("font", {
    font = "Verdana",
    size = 12,
    antialias = false,
    outline = true
})

--[[===============
    FUNCTIONS
===================]]

function Visuals.tesp()
    for k, v in pairs( player.GetAll() ) do 
		if v:IsValid() and not v:IsDormant() then
			if v:IsPlayer() and v ~= LocalPlayer() and v:Alive() and LocalPlayer():GetObserverMode() == 0 and v:Team() ~= TEAM_SPECTATOR then

                local teamcol = team.GetColor( v:Team() )
                local vposx = v:EyePos():ToScreen().x
                local vposy = v:EyePos():ToScreen().y

                draw.SimpleText( v:Name(), 'font', vposx, vposy - 8, teamcol, 1, 1, 1 )

            end
        end
    end
end

function Visuals.boxes()
    for k, v in pairs( player.GetAll() ) do 
		if v:IsValid() and not v:IsDormant() then
			if v:IsPlayer() and v ~= LocalPlayer() and v:Alive() and LocalPlayer():GetObserverMode() == 0 and v:Team() ~= TEAM_SPECTATOR then

                local pos = v:GetPos()
                local mins, maxs = v:OBBMins(), v:OBBMaxs()

                render.DrawWireframeBox(pos, Angle(0, 0, 0), mins, maxs, Color( 255, 255, 255 ), false )

            end
        end
    end
end

function Visuals.crosshair()

    surface.SetDrawColor( 0, 255, 0 )
    surface.DrawLine(ScrW() / 2 - 13, ScrH() / 2, ScrW() / 2 + 13, ScrH() / 2)
    surface.DrawLine(ScrW() / 2, ScrH() / 2 - 13, ScrW() / 2, ScrH() / 2 + 13)

end

function Visuals.chams()
    for k, v in pairs( ents.FindByClass( 'player' ) ) do 
		if v:IsValid() and not v:IsDormant() then
			if v:IsPlayer() and v ~= LocalPlayer() and v:Alive() and LocalPlayer():GetObserverMode() == 0 and v:Team() ~= TEAM_SPECTATOR then

                cam.IgnoreZ( true )
                render.SuppressEngineLighting( true )
                render.SetColorModulation( 1, 0, 0 )
                render.MaterialOverride( mat )
                v:DrawModel()
                render.SuppressEngineLighting( false )
                cam.IgnoreZ( false )

                render.SetColorModulation( 1, 1, 1 )
                render.MaterialOverride( nil ) 

            end
        end
    end
end

function Visuals.xray()
    for k, v in pairs( ents.FindByClass( 'prop_physics' ) ) do 
        if IsValid(v) then 

            cam.IgnoreZ( true )
            render.SuppressEngineLighting( true )
            render.SetColorModulation( 1, 1, 1 )
            render.MaterialOverride( mat )
            render.SetBlend( 0.3 )
            v:DrawModel()
            render.SuppressEngineLighting( false )
            cam.IgnoreZ( false )

            render.SetColorModulation( 1, 1, 1 )
            render.MaterialOverride( nil ) 

        end
    end
end

local User = LocalPlayer()
function Misc.bhop(UserCmd)
    if (UserCmd:KeyDown(IN_JUMP) and not User:IsOnGround()) then
        UserCmd:RemoveKey(IN_JUMP)
    end
end

--[[===============
    HOOKING
===================]]

hook.Add( 'PostDrawTranslucentRenderables', 'whatfuck', function(depth, skybox)
    if depth or skybox then return end
    Visuals.chams()
    Visuals.boxes()
end)

--

hook.Add( 'PreDrawEffects', 'whatfuck', function()
    Visuals.xray()
end)

--

hook.Add( 'CalcView', 'whatfuck', function(ply, pos, ang, fov)
    local view = {}
	local fov2 = 140 - ( GetConVar("fov_desired"):GetFloat() - fov )

    view.fov = fov2
		return view
end)

--

hook.Add( 'CreateMove', 'whatfuck', function(UserCmd)
    Misc.bhop(UserCmd)
end)

--

hook.Add( 'HUDPaint', 'whatfuck', function()
    Visuals.tesp()
    Visuals.crosshair()
end)