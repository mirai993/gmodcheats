require( "zxcmodule" )

local Reg = ded.PushSpecial( 2 )

local Ang = Angle
local Vec = Vector
local Col = Color
local Ply = Player 
local Ent = Entity 
local Mat = Material 

local IsStr = isstring
local IsTbl = istable
local IsNum = isnumber
local ToNum = tonumber
local ToStr = tostring

local GetCurTime  = CurTime 
local SyncedTime  = 0 
local GetRndTime  = FrameTime 
local RenderTime  = 0

local Iterate     = pairs 
local NumLoop     = ipairs
local Validate    = IsValid
local RunCommand  = RunConsoleCommand 
local ConVar  = GetConVar 
local Interpolate = Lerp 
local IsPredicted = IsFirstTimePredicted 
local CreateModel = ClientsideModel 
local CreateITMat = CreateMaterial 

local Meta = { Player = Reg.Player, Entity = Reg.Entity }

local math_lib      = math 
local bit_lib       = bit 
local surface_lib   = surface 
local render_lib    = render
local cam_lib       = cam
local table_lib     = table 
local string_lib    = string
local team_lib      = team
local util_lib      = util
local vgui_lib      = vgui
local input_lib     = input
local player_lib    = player
local ents_lib      = ents
local steam_lib     = steamworks
local net_lib       = net
local hook_lib      = hook
local gui_lib       = gui
local engine_lib    = engine

local math_Infinity                     = 2^1024
local math_Radian                       = 57.295779513082
local math_Pi                           = 3.1415926535898

local math_Abs                          = math_lib.abs
local math_Acos                         = math_lib.acos
local math_Approach                     = math_lib.Approach
local math_Asin                         = math_lib.asin
local math_Atan                         = math_lib.atan
local math_Atan2                        = math_lib.atan2
local math_Ceil                         = math_lib.ceil
local math_Clamp                        = math_lib.Clamp
local math_Cos                          = math_lib.cos
local math_Deg                          = math_lib.deg
local math_Floor                        = math_lib.floor
local math_Max                          = math_lib.max
local math_Min                          = math_lib.min
local math_Tan                          = math_lib.tan
local math_Sqrt                         = math_lib.sqrt
local math_Sin                          = math_lib.sin
local math_Round                        = math_lib.Round
local math_Random                       = math_lib.random
local math_Rand                         = math_lib.Rand
local math_NormalizeAngle               = math_lib.NormalizeAngle
local math_Randomseed                   = math_lib.randomseed
local math_Rad                          = math_lib.rad
local math_ModF                         = math_lib.modf
local math_AngleDifference              = math_lib.AngleDifference
local math_DistanceSqr                  = math_lib.DistanceSqr
local math_Remap                        = math_lib.Remap

local bit_Band                          = bit_lib.band
local bit_Bor                           = bit_lib.bor
local bit_Bnot                          = bit_lib.bnot
local bit_Lshift                        = bit_lib.lshift

local surface_CreateFont                = surface_lib.CreateFont
local surface_DrawCircle                = surface_lib.DrawCircle
local surface_DrawLine                  = surface_lib.DrawLine
local surface_DrawOutlinedRect          = surface_lib.DrawOutlinedRect
local surface_DrawPoly                  = surface_lib.DrawPoly
local surface_DrawRect                  = surface_lib.DrawRect
local surface_DrawText                  = surface_lib.DrawText
local surface_DrawTexturedRect          = surface_lib.DrawTexturedRect
local surface_GetTextSize               = surface_lib.GetTextSize
local surface_PlaySound                 = surface_lib.PlaySound
local surface_SetAlphaMultiplier        = surface_lib.SetAlphaMultiplier
local surface_SetDrawColor              = surface_lib.SetDrawColor
local surface_SetFont                   = surface_lib.SetFont
local surface_SetMaterial               = surface_lib.SetMaterial
local surface_SetTextColor              = surface_lib.SetTextColor
local surface_SetTextPos                = surface_lib.SetTextPos

local input_GetCursorPos                = input_lib.GetCursorPos
local input_GetKeyName                  = input_lib.GetKeyName
local input_IsKeyDown                   = input_lib.IsKeyDown
local input_IsMouseDown                 = input_lib.IsMouseDown
local input_LookupBinding               = input_lib.LookupBinding
local input_GetKeyCode                  = input_lib.GetKeyCode
local input_SetCursorPos                = input_lib.SetCursorPos
local input_WasMousePressed             = input_lib.WasMousePressed

local string_find                       = string_lib.find
local string_format                     = string_lib.format
local string_len                        = string_lib.len
local string_lower                      = string_lib.lower
local string_sub                        = string_lib.sub
local string_StartsWith                 = string_lib.StartsWith
local string_Split                      = string_lib.Split
local string_upper                      = string_lib.upper
local lang_GetPhrase                    = language.GetPhrase

local table_concat                      = table_lib.concat
local table_insert                      = table_lib.insert
local table_remove                      = table_lib.remove
local table_sort                        = table_lib.sort
local table_Add                         = table_lib.Add

local render_MaterialOverride           = render_lib.MaterialOverride
local render_SetColorModulation         = render_lib.SetColorModulation
local render_SetBlend                   = render_lib.SetBlend
local render_SuppressEngineLighting     = render_lib.SuppressEngineLighting
local render_DrawBeam                   = render_lib.DrawBeam
local render_SetMaterial                = render_lib.SetMaterial
local render_DrawWireframeBox           = render_lib.DrawWireframeBox
local render_RenderView                 = render_lib.RenderView
local render_Clear                      = render_lib.Clear
local render_BlurRenderTarget           = render_lib.BlurRenderTarget
local render_SetLightingMode            = render_lib.SetLightingMode
local render_SetStencilEnable           = render_lib.SetStencilEnable
local render_SetStencilCompareFunction  = render_lib.SetStencilCompareFunction
local render_SetStencilReferenceValue   = render_lib.SetStencilReferenceValue
local render_DrawScreenQuad             = render_lib.DrawScreenQuad
local render_SetRenderTarget            = render_lib.SetRenderTarget
local render_CopyRenderTargetToTexture  = render_lib.CopyRenderTargetToTexture
local render_SetStencilFailOperation    = render_lib.SetStencilFailOperation
local render_SetStencilZFailOperation   = render_lib.SetStencilZFailOperation
local render_SetStencilPassOperation    = render_lib.SetStencilPassOperation
local render_SetStencilTestMask         = render_lib.SetStencilTestMask
local render_SetStencilWriteMask        = render_lib.SetStencilWriteMask
local render_GetScreenEffectTexture     = render_lib.GetScreenEffectTexture
local render_SetScissorRect             = render_lib.SetScissorRect
local render_DrawTextureToScreen        = render_lib.DrawTextureToScreen
local render_DrawLine                   = render_lib.DrawLine
local render_SetGoalToneMappingScale    = render_lib.SetGoalToneMappingScale
local render_SetModelLighting           = render_lib.SetModelLighting
local render_SetShadowsDisabled         = render_lib.SetShadowsDisabled
local render_DepthRange                 = render_lib.DepthRange

local engine_ServerFrameTime            = engine_lib.ServerFrameTime
local util_TraceLine                    = util_lib.TraceLine
local util_TraceHull                    = util_lib.TraceHull
local net_Start                         = net_lib.Start
local net_SendToServer                  = net_lib.SendToServer

local cam_Start2D                       = cam_lib.Start2D
local cam_Start3D                       = cam_lib.Start3D
local cam_End2D                         = cam_lib.End2D
local cam_End3D                         = cam_lib.End3D
local cam_IgnoreZ                       = cam_lib.IgnoreZ

local team_GetName                      = team_lib.GetName
local team_GetColor                     = team_lib.GetColor
local player_GetAll                     = player_lib.GetAll
local ents_GetAll                       = ents_lib.GetAll
 
local hook_Add                          = hook_lib.Add
local hook_Remove                       = hook_lib.Remove
local hook_GetTable                     = hook_lib.GetTable
local hook_Call                         = hook_lib.Call

local vgui_Create                       = vgui_lib.Create
local vgui_CursorVisible                = vgui_lib.CursorVisible
local gui_EnableScreenClicker           = gui_lib.EnableScreenClicker 
local gui_IsGameUIVisible               = gui_lib.IsGameUIVisible
local gui_OpenURL                       = gui_lib.OpenURL

local ScreenData   = {}
ScreenData.Width   = ScrW() 
ScreenData.Height  = ScrH() 
ScreenData.CenterX = math_Floor( ScrW() / 2 )
ScreenData.CenterY = math_Floor( ScrH() / 2) 

local TickInterval = engine_lib.TickInterval()
local TickRate     = math_Floor( 1 / TickInterval )

// Math
local MathEx = {}

function MathEx.Average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end

function MathEx.Remap( val, inmax, outmax )
    return math_Ceil( val / inmax * outmax )
end

function MathEx.TimeToTicks( Time )
    return math_Floor( 0.5 + Time / TickInterval )
end

function MathEx.TicksToTime( Ticks )
    return TickInterval * Ticks
end

function MathEx.RoundToTick( Time )
    return MathEx.TicksToTime( MathEx.TimeToTicks( Time ) )
end

// Color
local ColorEx = { Cache = {}, Trans = {} }


// Input extension 
local InputEx = { KeysDown = {}, KeysPressed = {}, KeysOld = {} }

for i = 1, 113 do 
    InputEx.KeysDown[ i ] = false 
    InputEx.KeysPressed[ i ] = false 
    InputEx.KeysOld[ i ] = false 
end

function InputEx.IsKeyDown( Key )
    if Key >= 107 then
        return input_IsMouseDown( Key )
    end

    return input_IsKeyDown( Key )
end

// Angle / Vector extension 
local AngleVec = { NullVec = Vec(), NullAng = Ang(), TempAng = Ang(), Positive = Vec( 1, 1, 1 ) }

function AngleVec.Abs( vec )
    vec.x = math_Floor( vec.x )
    vec.y = math_Floor( vec.y )
    vec.z = math_Floor( vec.z )

    return vec 
end

function AngleVec.GetSumId( vec )
    return string_format( "%G %G %G", vec.x, vec.y, vec.z )
end

function AngleVec.CalcDir( start, endpos )
    AngleVec.TempAng = ( start - endpos ):Angle()
    AngleVec.TempAng:Normalize()

    return AngleVec.TempAng
end

// Draw extension
local DrawEx = { TextSizeData = {}, Output = {}, DrawnText = {}, StartPos = {}, BarPoses = {}, DrawnBars = {}, MaterialData = {}, Font = "" }
DrawEx.BarPadding = { { x = 0, y = -5 }, { x = 0, y = 5 }, { x = 5, y = 0 }, { x = -5, y = 0 } }
DrawEx.Context = { x = 0, y = 0, w = 0, h = 0, g = 0, TextX = 0, TextY = 0, TextWidth = 0, TextHeight = 0, MaxX = 0, MaxY = 0, MinX = 0, MinY = 0, Vis = false }

function DrawEx.SetColor( tbl ) surface_SetDrawColor( tbl[1], tbl[2], tbl[3], tbl[4] ) end
function DrawEx.SetTextColor( tbl ) surface_SetTextColor( tbl[1], tbl[2], tbl[3], tbl[4] ) end

function DrawEx.SetFont( font ) 
    if not DrawEx.TextSizeData[ font ] then
        DrawEx.TextSizeData[ font ] = {}
    end

    DrawEx.Font = font 
    surface_SetFont( font )
end

function DrawEx.GetTextSize( str )
    if DrawEx.TextSizeData[ DrawEx.Font ][ str ] then
        DrawEx.Output = DrawEx.TextSizeData[ DrawEx.Font ][ str ]
        return DrawEx.Output.x, DrawEx.Output.y 
    end

    local tw, th = surface_GetTextSize( str )

    DrawEx.TextSizeData[ DrawEx.Font ][ str ] = { x = tw, y = th }

    return tw, th 
end 

function DrawEx.DrawText( str, x, y )
    surface_SetTextPos( x, y )
    surface_DrawText( str )
end

function DrawEx.DrawOutline( poly )
    local From

    for i = 1, #poly do
        local To = poly[ i ]

        if not From then From = To continue end 

        surface_DrawLine( From.x, From.y, To.x, To.y )
        From = To
    end

    surface_DrawLine( From.x, From.y, poly[ 1 ].x, poly[ 1 ].y )
end

DrawEx.MaterialData[ "gui/colors.png" ] = Mat( "gui/colors.png" )
DrawEx.MaterialData[ "vgui/gradient-d" ] = Mat( "vgui/gradient-d" )

function DrawEx.DrawTexture( mat, x, y, w, h )
    if not DrawEx.MaterialData[ mat ] then
        DrawEx.MaterialData[ mat ] = Mat( mat )
    end

    surface_SetMaterial( DrawEx.MaterialData[ mat ] )
    surface_DrawTexturedRect( x, y, w, h )
end

function DrawEx.GetTextX( TextWidth, Pos )
    if Pos < 3 then
        return TextWidth / 2 
    elseif Pos == 4 then 
        return TextWidth - DrawEx.DrawnBars[ Pos ].x 
    end

    return DrawEx.DrawnBars[ Pos ].x 
end

function DrawEx.GetTextY( TextHeight, Pos )
    if Pos == 1 then
        return DrawEx.Context.MinY + DrawEx.DrawnBars[ Pos ].y - TextHeight - 2 - TextHeight * DrawEx.DrawnText[ Pos ]
    elseif Pos == 2 then
        return DrawEx.Context.MaxY + DrawEx.DrawnBars[ Pos ].y + TextHeight * DrawEx.DrawnText[ Pos ] 
    end

    return DrawEx.Context.MinY + TextHeight * DrawEx.DrawnText[ Pos ]
end

function DrawEx.DrawEspText( String, Pos, TextColor, Conditions )
    if not Conditions then return end 
    if not IsString( String ) then String = ToString( String ) end
    local TextWidth, TextHeight = DrawEx.GetTextSize( String )

    DrawEx.Context.TextX = DrawEx.StartPos[ Pos ] - DrawEx.GetTextX( TextWidth, Pos )
    DrawEx.Context.TextY = DrawEx.GetTextY( TextHeight, Pos )

    surface_SetTextColor( TextColor[ 1 ], TextColor[ 2 ], TextColor[ 3 ], TextColor[ 4 ] )
    surface_SetTextPos( DrawEx.Context.TextX, DrawEx.Context.TextY )
    surface_DrawText( String )

    DrawEx.DrawnText[ Pos ] = DrawEx.DrawnText[ Pos ] + 1
end

function DrawEx.DrawBar( Pos, Current, Max, BarColor, BackColor, Gradient, GradientColor )
    local BarX, BarY = DrawEx.BarPoses[ Pos ].x + DrawEx.DrawnBars[ Pos ].x, DrawEx.BarPoses[ Pos ].y + DrawEx.DrawnBars[ Pos ].y
    local BarW, BarH = DrawEx.Context.w, 4
    local FillW, FillH = math_Ceil( Current / Max * BarW ), BarH

    if Pos > 2 then
        BarW, BarH = 4, DrawEx.Context.h 
        FillW, FillH = BarW, math_Ceil( Current / Max * BarH )
    end

    surface_SetTextColor( BackColor[ 1 ], BackColor[ 2 ], BackColor[ 3 ], BackColor[ 4 ] )
    surface_DrawRect( BarX, BarY, BarW, BarH )

    BarX, BarY = BarX + 1, BarY + 1

    if Pos > 2 then
        BarY = BarY + BarH - FillH
    end

    BarW, BarH = BarW - 2, BarH - 2
    FillW, FillH = FillW - 2, FillH - 2
    
    surface_SetTextColor( BarColor[ 1 ], BarColor[ 2 ], BarColor[ 3 ], BarColor[ 4 ] )
    surface_DrawRect( BarX, BarY, FillW, FillH )

    if Gradient then
        DrawEx.DrawTexture( Pos > 2 and "gui/gradient_up" or "gui/gradient", BarX, BarY, FillW, FillH )
    end

    DrawEx.DrawnBars[ Pos ].x = DrawEx.DrawnBars[ Pos ].x + DrawEx.BarPadding[ Pos ].x 
    DrawEx.DrawnBars[ Pos ].y = DrawEx.DrawnBars[ Pos ].y + DrawEx.BarPadding[ Pos ].y
end

surface_CreateFont( "TabFont", { font = "Verdana", extended = false, size = 16, weight = 100 } )
surface_CreateFont( "MenuFont", { font = "Verdana", extended = false, size = 14, weight = 100 } )
surface_CreateFont( "Veranda", { font = "Verdana", size = 12, antialias = false, outline = true } )

// Render extensions
local RenderEx = {}




// Tracing 
local Trace = {}
Trace.HullStruct = { start = AngleVec.NullVec, endpos = AngleVec.NullVec, maxs = AngleVec.NullVec, mins = AngleVec.NullVec, filter = LocalEntity, mask = MASK_VISIBLE }
Trace.LineStruct = { start = AngleVec.NullVec, endpos = AngleVec.NullVec, filter = LocalEntity, mask = MASK_SHOT }
Trace.Output     = {}
Trace.CanHit     = false 

function Trace.WallScan( Ent, Dir )


end

function Trace.VisibleCheck( Ent, Vec, AWallDir )
    Trace.LineStruct.start = LocalEx.EyePosition
    Trace.LineStruct.endpos = Vec

    Trace.Output = util_TraceLine( Trace.LineStruct )
    Trace.CanHit = Trace.Output.Entity == Ent or Trace.Output.Fraction == 1

    if not Trace.CanHit and AWallDir and Settings.Vars.WallScan then
        return Trace.WallScan( Ent, AWallDir )
    end

    if Settings.Vars.HeadshotOnly then
        return Trace.Output.HitGroup == 1 
    end

    return Trace.CanHit
end


// Entity data 
local LocalEntity = LocalPlayer()

local EntityList = {}
local PlayerList = {}

local EntEx = {  
    PlayerCache = {}, EntityCache = {}, 
    PlayerData = {}, EntityData = {},
    WorldSpawn = Ent( 0 ),
    LastRecache = 0,
    LastEntUpdate = 0
}

function EntEx.ListEntity( Ent, Index )
    EntityList[ Index ] = {
        Ent     = Ent, 
        Class   = Ent:GetClass(),
        Dormant = Ent:IsDormant(),
    }
end

function EntEx.ListPlayer( Ent, Index )
    PlayerList[ Index ] = {
        Ent             = Ent,

        Health          = Ent:Health(),
        MaxHealth       = Ent:GetMaxHealth(),
        Armor           = Ent:Armor(),
        MaxArmor        = Ent:GetMaxArmor(),

        Origin          = Ent:GetPos(),
        NetworkOrigin   = Ent:GetNetworkOrigin(),
        OBBCenter       = Ent:LocalToWorld( Ent:OBBCenter() ),
        Velocity        = Ent:GetVelocity(), 

        PredictedOrigin = Ent:GetPos(),

        Angles          = Ent:GetAngles(),
        EyeAngles       = Ent:EyeAngles(),
        NetworkAngles   = Ent:GetNetworkAngles(),

        MoveType        = Ent:GetMoveType(),
        Effects         = Ent:GetEffects(),
        EngineFlags     = Ent:GetEFlags(),
        Flags           = Ent:GetFlags(),

        Alive           = Ent:Alive(),
        Dormant         = Ent:IsDormant(),

        SimulationTime  = ded.GetSimulationTime( Ent:EntIndex() ),
        BreakingLC      = false,
        PacketSent      = false,
        ChokedPackets   = 0,

        Weapon          = Ent:GetActiveWeapon(),
        WeaponClass     = false,
        WeaponName      = "Unarmed",

        Model       = Ent:GetModel(),
        OBBMins     = Ent:OBBMins(),
        OBBMaxs     = Ent:OBBMaxs(),
    }

    local PlayerTable = PlayerList[ Index ]

    Ent.StartedReloading    = Ent.StartedReloading or 0
    Ent.OldSimulationTime   = Ent.OldSimulationTime or 0 
    Ent.OldNetworkOrigin    = Ent.OldNetworkOrigin or PlayerTable.NetworkOrigin

    if Ent.OldSimulationTime != PlayerTable.SimulationTime then
        PlayerTable.BreakingLC      = PlayerTable.NetworkOrigin:DistToSqr( Ent.OldNetworkOrigin ) > 4096
        PlayerTable.PacketSent      = true 
        PlayerTable.ChokedPackets   = MathEx.TimeToTicks( PlayerTable.SimulationTime - Ent.OldSimulationTime )
        
        Ent.OldSimulationTime = PlayerTable.SimulationTime
    end

    if not Validate( PlayerTable.Weapon ) then return end 

    PlayerTable.WeaponClass = PlayerTable.Weapon:GetClass()
    PlayerTable.WeaponName  = lang_GetPhrase( PlayerTable.Weapon:GetPrintName() )
end

function EntEx.CachePlayer( Ent )
    EntEx.PlayerCache[ Ent ] = {
        SteamID     = Ent:SteamID(),
        SteamID64   = Ent:SteamID64(),
        UserID      = Ent:UserID(),
        EntIndex    = Ent:EntIndex(),
        IsBot       = Ent:IsBot(),
        RealName    = Ent:Name(),
        AvatarImage = vgui_Create( "AvatarImage" )
    }

    EntEx.PlayerCache[ Ent ].AvatarImage:SetPlayer( Ent, 32 )
    EntEx.PlayerCache[ Ent ].AvatarImage:SetPaintedManually( true )

    if not EntEx.PlayerCache[ Ent ].IsBot then
        steam_lib.RequestPlayerInfo( EntEx.PlayerCache[ Ent ].SteamID64, function( steamName )
            EntEx.PlayerCache[ Ent ].RealName = steamName
        end )
    end
end

function EntEx.UpdatePlayerData( Ent )
    local PlayerTeam = Ent:Team()

    EntEx.PlayerData[ Ent ] = {
        Team        = PlayerTeam,
        TeamName    = team_GetName( PlayerTeam ),
        TeamColor   = team_GetColor( PlayerTeam ),

        Name        = Ent:Name(),
        UserGroup   = Ent:GetNWString( "UserGroup", "user" ),
        IsAdmin     = Ent:IsAdmin(),
        IsFriend    = Ent:GetFriendStatus() == "friend",
    }

    if Meta.Player.getDarkRPVar then
        EntEx.PlayerData[ Ent ].Money   = DarkRP.formatMoney( Ent:getDarkRPVar("money") ) or "beggar"
        EntEx.PlayerData[ Ent ].Wanted  = Ent:getDarkRPVar("wanted")
    end
end

// Convar data 
local ConVars = {
    sv_maxvelocity   = ConVar( "sv_maxvelocity" ):GetFloat(),
    sv_airaccelerate = ConVar( "sv_airaccelerate" ):GetFloat(),
    sv_accelerate    = ConVar( "sv_accelerate" ):GetFloat(),
    sv_friction      = ConVar("sv_friction"):GetFloat(),
    sv_stopspeed     = ConVar("sv_stopspeed"):GetFloat(),
    sv_gravity       = ConVar("sv_gravity"):GetFloat(),

    r_aspectratio   = ConVar("r_aspectratio"):GetFloat(),

    sv_maxusrcmdprocessticks = ConVar("sv_maxusrcmdprocessticks"):GetFloat(),
    sv_namechange_cooldown_seconds = ConVar("sv_namechange_cooldown_seconds"):GetFloat(),

    cl_forwardspeed  = ConVar( "cl_forwardspeed" ):GetFloat(),
    cl_sidespeed     = ConVar( "cl_sidespeed" ):GetFloat(),
    
    m_yaw   = ConVar( "m_yaw" ):GetFloat(),
    m_pitch = ConVar( "m_pitch" ):GetFloat(),
    
    climbswep2_maxjumps = ConVar( "climbswep2_maxjumps" ) and ConVar( "climbswep2_maxjumps" ):GetInt() or 0,
    sv_skyname = ConVar( "sv_skyname" ):GetString()
}

// Local player additional data 
local LocalEx = { 
    Index       = LocalEntity:EntIndex(),
    Origin      = Vec(),
    Velocity    = Vec(), 
    EyePosition = Vec(), 
    EyeAngles   = Ang(),
    GroundPos   = Vec(),
    MoveType    = 0,
    Flags       = 0,
    WaterLevel  = 0,
    Moving      = false, 
    BadMove     = false, 
    WeaponEnt   = false,
    WeaponClass = false, 
    WeaponBase  = false,
    OnGround    = false,
    ViewFrozen  = false,
    GroundTicks = 0,
    NumHops     = 0,
    HullMins    = LocalEntity:OBBMins(),
    HullMaxs    = LocalEntity:OBBMaxs()
}

// Simulation data 
local Simulation = { Output = {}, Struct = {} }

// Command data
local CommandEx = { Object = 0, CommandNumber = 0, TickCount = 0, Buttons = 0, Impulse = 0, SideMove = 0, ForwardMove = 0, UpMove = 0, MouseWheel = 0, MouseY = 0, MouseX = 0, ViewAngles = 0, WishYaw = 0, Swap = false, SendPacket = true, OutSequence = 0 }

function CommandEx.FixMovement( yaw )
	local pitch = math_NormalizeAngle( CommandEx.ViewAngles.x )
	local inverted = ( pitch > 89 || pitch < -89 ) and 1 or -1
	local angleDiff = math_Rad( math_NormalizeAngle( ( CommandEx.ViewAngles.y - yaw ) * inverted ) )
    local OldForward, OldSide = CommandEx.ForwardMove, CommandEx.SideMove

	CommandEx.ForwardMove = OldForward * -math_Cos( angleDiff ) * inverted + OldSide * math_Sin( angleDiff )
	CommandEx.SideMove = OldForward * math_Sin( angleDiff ) * inverted + OldSide * math_Cos( angleDiff ) 
end
    
function CommandEx.MoveTo( vec )
    local wishyaw = AngleVec.CalcDir( LocalEx.Origin, vec ).y

    CommandEx.ForwardMove = ConVars.cl_forwardspeed
    CommandEx.SideMove = 0

    CommandEx.FixMovement( wishyaw )
end

function CommandEx.BindDown( bind )
    if not input_LookupBinding( bind ) then return false end 
    
    return input_IsKeyDown( input_GetKeyCode( input_LookupBinding( bind ) ) ) 
end

function CommandEx.KeySpam( key, condition )
    if not CommandEx.Swap or not bit_Band( CommandEx.Buttons, key ) == key or not condition then
        return 
    end 
     
    CommandEx.Buttons = bit_Band( CommandEx.Buttons, bit_Bnot( key ) ) 
end

// Prediction 
local PredictionEx = {}



// Config system 
local Settings = {}

Settings.Vars = {}

Settings.Vars.EnableAimbot  = false

Settings.Vars.DisablersSpectated        = false 
Settings.Vars["DisablersBullet time"]   = true 
Settings.Vars["DisablersWait for send"] = true 

Settings.Vars.SilentAim     = true 
Settings.Vars.ContextAimbot = false

Settings.Vars.RapidFire     = true 
Settings.Vars.RapidFireAlt  = false

Settings.Vars.AutoFire      = false
Settings.Vars.AutoFireAlt   = false
Settings.Vars.AutoReload    = false 

Settings.Vars["AutoSwitchEmpty clip"]    = false 
Settings.Vars["AutoSwitchEmpty reserve"] = false 

Settings.Vars.Smoothing         = false 
Settings.Vars.SmoothingRandom   = false 
Settings.Vars.SmoothingAmount   = 0.5 

Settings.Vars.FovLimit   = false 
Settings.Vars.DynamicFov = false 
Settings.Vars.FovAmount  = 5

Settings.Vars.AccelerativeLeading = false 

Settings.Vars.TriggerBot    = false 
Settings.Vars.TriggerDelay  = 0.35

Settings.Vars.InterpPosition = true
Settings.Vars.InterpSequence = true

Settings.Vars.SyncAnimations = false
Settings.Vars.SyncBones      = false

Settings.Vars.NoRecoil = false
Settings.Vars.NoSpread = false
Settings.Vars.AutoStop = 1

Settings.Vars.AdjustTickcount = false

Settings.Vars.TargetSelection   = 1
Settings.Vars.MaxTargets        = 10

Settings.Vars.Wallz = false
Settings.Vars.IgnoreFriends          = false
Settings.Vars.IgnoreBots             = false
Settings.Vars.IgnoreTeammates        = false
Settings.Vars.IgnoreDriving          = false
Settings.Vars.IgnoreGod              = false
Settings.Vars.IgnoreNoclip           = false
Settings.Vars.IgnoreNodraw           = false
Settings.Vars.IgnoreFrozen           = false
Settings.Vars.IgnoreAdmin            = false
Settings.Vars["IgnoreBroken LC"]     = false
Settings.Vars["IgnoreSteam friends"] = false

Settings.Vars.Extrapolation = 1

Settings.Vars.HitboxSelection = 1
Settings.Vars.OnlyHead = false 

Settings.Vars.HitScan = false 

Settings.Vars.HitboxHead    = false 
Settings.Vars.HitboxChest   = false 
Settings.Vars.HitboxStomach = false 
Settings.Vars.HitboxArms    = false 
Settings.Vars.HitboxLegs    = false 

Settings.Vars.HitboxPriority = 1 

Settings.Vars.Multipoints = false
Settings.Vars.MultipointScale = 0.8 

Settings.Vars.Prediction       = false
Settings.Vars.PredictionMethod = 2
Settings.Vars.PredictionMode   = 1
Settings.Vars.SimulationLimit  = 16

Settings.Vars.AutoMelee     = false
Settings.Vars.MeleeMode     = 2
Settings.Vars.FaceStab      = false
Settings.Vars.FollowTarget  = false
Settings.Vars.AutoDetonator = false
Settings.Vars.XBowTrigger   = false

Settings.Vars.Backtracking         = false
Settings.Vars.BacktrackingMethod   = 1
Settings.Vars.BacktrackingMode     = 1
Settings.Vars.BacktrackingInterval = 0
Settings.Vars.BacktrackTime        = 300

Settings.Vars.BoxEsp = false

Settings.Vars.ThirdPerson         = false
Settings.Vars.ThirdPersonCollide  = false
Settings.Vars.ThirdPersonSmooth   = 2
Settings.Vars.ThirdPersonDistance = 120

Settings.Vars.FreeCamera       = false 
Settings.Vars.FreeCameraGhetto = false 
Settings.Vars.FreeCameraSpeed  = 5 

Settings.Vars.OverrideFov   = false 
Settings.Vars.FovValue      = 125
Settings.Vars.OverrideViewmodel = false 
Settings.Vars.ViewmodelFov      = 15 
Settings.Vars.OverrideAspect = ConVars.r_aspectratio


Settings.Vars.ProjectilePrediction = false 
Settings.Vars.ProjectileTrajectories = false 


Settings.Vars.BunnyHop = false 
Settings.Vars.BunnyUnstuck = true
Settings.Vars.HopDelay = 0 
Settings.Vars.MaxHops = 0
Settings.Vars.AutoLongjump = false 
Settings.Vars.AirDuckSpam = false 

Settings.Vars.EdgeJump = false 

Settings.Vars.AutoParkour = false 
Settings.Vars.WaterFloat = false 

Settings.Vars.AirStrafer = false 
Settings.Vars.AirStraferMode = 1
Settings.Vars.GroundStrafe = false 
Settings.Vars.FastStop = false 

Settings.Vars.AutoPeek = false
Settings.Vars.AutoPeekTeleport = false
Settings.Vars.AutoPeekPullback = false

Settings.Vars.MenuMove = false

Settings.Vars.SlowMotion = false 
Settings.Vars.SlowMotionTime = 0.25 
Settings.Vars.SlowWalk = false 
Settings.Vars.SlowWalkSpeed = 5

Settings.Vars.PathFinder = false 
Settings.Vars.PathFinderDec = false 
Settings.Vars.PathFinderMode = 1 
Settings.Vars.PathFinderRange = 1 
Settings.Vars.PathFinderDelay = 0.05 
Settings.Vars.ForcedRecalc = 1

Settings.Vars.UseSpam = false
Settings.Vars.CameraSpam = false
Settings.Vars.FlashlightSpam = false
Settings.Vars.AutoRape = false

Settings.Vars.HandJob = false
Settings.Vars.HandJobMode = 1

Settings.Vars.ActSpam = false
Settings.Vars.ActSpamMode = 1
Settings.Vars.ActSpamTime = 0

Settings.Vars.VapeSpam = false
Settings.Vars.AutoVape = false
Settings.Vars.VapeTorch = false

Settings.Vars.RopeSpam = false
Settings.Vars.RopeMatz = false

Settings.Vars.ChatSpam = false
Settings.Vars.ChatMode = 1
Settings.Vars.ChatDelay = 1

Settings.Vars.KillSay = false
Settings.Vars.KillMode = 1

Settings.Vars.DeathSay = false
Settings.Vars.DeathMode = 1

Settings.Vars.RespondSay = false
Settings.Vars.RespondMode = 1

Settings.Vars.UlxSpam = false
Settings.Vars.SendChannel = 1

Settings.Vars.NameStealer = false

Settings.Vars.ServerLagger = false
Settings.Vars.LaggerMode = 1
Settings.Vars.LaggerForce = 1

Settings.Vars.SeqManip = false
Settings.Vars.SeqManipMode = 1
Settings.Vars.SeqManipAmt = 1
Settings.Vars.SeqManipSpeedhack = 1

Settings.Vars.FakeFrames = false
Settings.Vars.FakeFramesAmt = 0.25

Settings.Vars.ViewRoll = false
Settings.Vars.ViewRollMode = 1

Settings.Vars.FastLockpick = false
Settings.Vars.PickTimeMin = 11

Settings.Vars.UnterBurner = false

Settings.Vars.WallColor = false 
Settings.Vars.SkyColor = false
Settings.Vars.ModulatePaint = false

Settings.Vars.CustomSkybox = false
Settings.Vars.SkyTexture = ConVars.sv_skyname

Settings.Vars.FogChanger = false 
Settings.Vars.FogStart = 1500
Settings.Vars.FogEnd = 3000

Settings.Vars.BulletTracer = false 
Settings.Vars.MuzzleTracer = false 
Settings.Vars.BulletImpacts = false 
Settings.Vars.TracerDieTime = 5 

Settings.Vars.Fullbright = false

Settings.Vars.MinimapEnable = false
Settings.Vars.MinimapOrthoView = false
Settings.Vars.MinimapDistance = 1024
Settings.Vars.MinimapScaling = 2

Settings.Vars.MinimapPlayers = false
Settings.Vars.MinimapNames = false
Settings.Vars.MinimapAvatars = false
Settings.Vars.MinimapPfpSize = 9

Settings.Vars.BoxEsp                 = true 
Settings.Vars.BoxTeamColor           = true 
Settings.Vars.BoxStyle               = 1
Settings.Vars.BoxGradient            = false

Settings.Vars.FilledBox              = false 
Settings.Vars.FilledGradient         = false 

Settings.Vars.NameEsp                = true 
Settings.Vars.HighlightFriends       = true 
Settings.Vars.SteamName              = false 
Settings.Vars.NamePos                = 1

Settings.Vars.AvatarImage            = true 

Settings.Vars.UsergroupEsp           = true 
Settings.Vars.HighlightAdmins        = false 
Settings.Vars.UsergroupPos           = 1

Settings.Vars.HealthEsp              = true 
Settings.Vars.HealthBar              = true 
Settings.Vars.HealthBarGradient      = true 
Settings.Vars.HealthBarPos           = 4
Settings.Vars.HealthPos              = 4 

Settings.Vars.ArmorEsp               = true 
Settings.Vars.ArmorBar               = true 
Settings.Vars.ArmorBarGradient       = true 
Settings.Vars.ArmorBarPos            = 4
Settings.Vars.ArmorPos               = 4 

Settings.Vars.WeaponEsp              = true 
Settings.Vars.WeaponPrintName        = false 
Settings.Vars.WeaponIcon             = false 
Settings.Vars.WeaponReload           = true 
Settings.Vars.ReloadingBar           = true 
Settings.Vars.ReloadingGradient      = true 
Settings.Vars.WeaponPos              = 2

Settings.Vars.TeamEsp                = true 
Settings.Vars.TeamPos                = 1

Settings.Vars.MoneyEsp               = true 
Settings.Vars.MoneyPos               = 1 

Settings.Vars.LagcompIndicator       = true 
Settings.Vars.PacketIndicator        = true 
Settings.Vars.PacketPos              = 3

Settings.Vars.TauntFlag              = false 
Settings.Vars.NoclipFlag             = true 
Settings.Vars.FrozenFlag             = true 
Settings.Vars.WantedFlag             = true 
Settings.Vars.FlagsPos               = 1

Settings.Vars.BacktrackRecords       = false 
Settings.Vars.RecordsStyle           = 1

Settings.Vars.SkeletonEsp            = true 

Settings.Vars.OOFArrows              = false 
Settings.Vars.OOFArrowsSize          = 1
Settings.Vars.OOFArrowsPadding       = 1
Settings.Vars.OOFArrowsHideDormant   = false 
Settings.Vars.OOFArrowsShowWeapon    = false 
Settings.Vars.OOFArrowsHighlight     = false
Settings.Vars.OOFArrowsAvatar        = false
Settings.Vars.OOFArrowsStyle         = 1

Settings.Vars.SightLines             = true 

Settings.Vars.MaxDistance            = 4096 
Settings.Vars.MainFont               = 1

Settings.Binds = {}

Settings.Binds[ 1 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Thirdperson
Settings.Binds[ 2 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Free cam
Settings.Binds[ 3 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Aimbot 
Settings.Binds[ 4 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Trigger 
Settings.Binds[ 5 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Slow walk 
Settings.Binds[ 6 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Edge jump 
Settings.Binds[ 7 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Slow motion 
Settings.Binds[ 8 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Sequence manip 
Settings.Binds[ 9 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Auto peek
Settings.Binds[ 10 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // Full bright
Settings.Binds[ 11 ] = { State = false, Key = -1, Mode = 1, Trapping = false } // UnterBurner


Settings.Colors = {}
Settings.Colors.WallColor = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.FogChanger = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.SkyColor = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.BulletTracer = ColorEx.Rgb( 255, 64, 64 )
Settings.Colors.SkeletonEsp = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.FilledBox = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.BoxEsp = ColorEx.Rgb( 255, 255, 255 )
Settings.Colors.BoxBg = ColorEx.Rgb( 0, 0, 0 )
Settings.Colors.BoxGradient = ColorEx.Rgb( 255, 255, 255 )
   

Settings.Menu = {}

Settings.Menu.Background = ColorEx.Rgb( 16, 16, 16 )
Settings.Menu.Outline    = ColorEx.Rgb( 72, 72, 72 )

Settings.Menu.Active  = ColorEx.Rgb( 72, 72, 72 )
Settings.Menu.Hovered = ColorEx.Rgb( 56, 56, 56 )
Settings.Menu.Normal  = ColorEx.Rgb( 48, 48, 48 )

Settings.Menu.TextActive   = ColorEx.Rgb( 180, 180, 180 )
Settings.Menu.TextHovered  = ColorEx.Rgb( 156, 156, 156 )
Settings.Menu.TextNormal   = ColorEx.Rgb( 128, 128, 128 )
Settings.Menu.TextDisabled = ColorEx.Rgb( 64, 64, 64 )

Settings.EntList = {}


// End of localization 
local Sublimity = {}

function Sublimity.AddHook( event, func )
    hook_Add( event, event .. "_", Sublimity[ event ] or func )
end

// World 
local WorldEx = { Textures = EntEx.WorldSpawn:GetMaterials(), SkyboxSides = { "lf", "ft", "rt", "bk", "dn", "up" }, SkyTextures = {} }

for i = 1, #WorldEx.Textures do
    WorldEx.Textures[ i ] = Mat( WorldEx.Textures[ i ] )
end

for i = 1, #WorldEx.SkyboxSides do
    WorldEx.SkyTextures[ i ] = Mat( "skybox/" .. ConVars.sv_skyname .. WorldEx.SkyboxSides[ i ] )
end

function WorldEx.ModulateColor() 
    local Custom, A = ColorEx.RgbObjToVecObj( Settings.Colors.WallColor ) 

    for i = 1, #WorldEx.Textures do
        WorldEx.Textures[ i ]:SetFloat( "$alpha", Settings.Vars.WallColor and A or 1 )
        WorldEx.Textures[ i ]:SetVector( "$color", Settings.Vars.WallColor and Custom or AngleVec.Positive )
    end
end  

function WorldEx.ModulateSky()
    local Custom = ColorEx.RgbObjToVecObj( Settings.Colors.SkyColor ) 

    for i = 1, #WorldEx.SkyTextures do
        WorldEx.SkyTextures[ i ]:SetVector( "$color", Settings.Vars.SkyColor and Custom or AngleVec.Positive )
    end
end

WorldEx.SkyPaint = ents_lib.FindByClass( "env_skypaint" )[ 1 ] or false 
WorldEx.SkyPaintColors = { "topcolor", "duskcolor", "bottomcolor", "suncolor" }
WorldEx.SkyPaintVars = { "hdrscale", "fadebias", "drawstars", "starlayers", "starspeed", "starscale", "starfade", "duskintensity", "duskscale", "sunsize" }

WorldEx.DefaultPaintColors = {}
WorldEx.DefaultSkyPaint = {}

if WorldEx.SkyPaint then
    local NetVar, Var 

    for i = 1, #WorldEx.SkyPaintColors do
        NetVar = WorldEx.SkyPaintColors[ i ]
        Var =  WorldEx.SkyPaint:GetNetworkKeyValue( NetVar )

        WorldEx.DefaultPaintColors[ NetVar ] = Var
        Settings.Colors[ NetVar ] = ColorEx.Rgb( math_Round( Var.x * 255, 2 ), math_Round( Var.y * 255 ), math_Round( Var.z * 255 ) )
    end

    for i = 1, #WorldEx.SkyPaintVars do
        NetVar = WorldEx.SkyPaintVars[ i ]
        Var = WorldEx.SkyPaint:GetNetworkKeyValue( NetVar )  

        WorldEx.DefaultSkyPaint[ NetVar ] = Var
        Settings.Vars[ NetVar ] = IsNumber( Var ) and math_Round( Var, 2 ) or Var
    end
end

function WorldEx.ModulateSkyPaint()
    if not Settings.Vars.ModulatePaint then
        for i = 1, #WorldEx.SkyPaintColors do
            WorldEx.SkyPaint:SetNetworkKeyValue( WorldEx.SkyPaintColors[ i ], WorldEx.DefaultPaintColors[ WorldEx.SkyPaintColors[ i ] ] )
        end
    
        for i = 1, #WorldEx.SkyPaintVars do
            
            WorldEx.SkyPaint:SetNetworkKeyValue( WorldEx.SkyPaintVars[ i ], WorldEx.DefaultSkyPaint[ WorldEx.SkyPaintVars[ i ] ] )
        end

        return 
    end 

    for i = 1, #WorldEx.SkyPaintColors do
        WorldEx.SkyPaint:SetNetworkKeyValue( WorldEx.SkyPaintColors[ i ], ColorEx.RgbObjToVecString( Settings.Colors[ WorldEx.SkyPaintColors[ i ] ] ) )
    end

    for i = 1, #WorldEx.SkyPaintVars do
        WorldEx.SkyPaint:SetNetworkKeyValue( WorldEx.SkyPaintVars[ i ], Settings.Vars[ WorldEx.SkyPaintVars[ i ] ] )
    end
end

function WorldEx.SetSkyboxTexture()
    if WorldEx.SkyPaint then return end 

    for i = 1, #WorldEx.SkyTextures do
        WorldEx.SkyTextures[ i ]:SetTexture( "$basetexture", Mat( "skybox/" .. ( Settings.Vars.CustomSkybox and Settings.Vars.SkyTexture or ConVars.sv_skyname ) .. WorldEx.SkyboxSides[ i ] ):GetTexture( "$basetexture" ) )
    end
end

// Calc view 
local ViewData = { origin = Vec(), angles = Ang(), fov = 60, drawviewer = false }
local ViewEx = { Origin = Vec(), Angles = Ang(), PreFreeCam = Ang(), ViewDist = 0, FreeCam = false }

ViewEx.RenderViewData = { origin = Vec(), angles = Ang( 89, 0, 0 ), x = 15, y = 15, w = 256, h = 256, drawviewmodel = false, bloomtone = false }

ViewEx.FreeCamDirs = { 
    { key = KEY_W, fnc = function( ang ) return ang:Forward() end },
    { key = KEY_S, fnc = function( ang ) return -ang:Forward() end },
    { key = KEY_A, fnc = function( ang ) return -ang:Right() end },
    { key = KEY_D, fnc = function( ang ) return ang:Right() end }
}

function Sublimity.CalcView( ply, origin, angles, fov, znear, zfar )
    local ThirdPersonDistance = ( Settings.Vars.ThirdPerson and Settings.Binds[ 1 ].State ) and Settings.Vars.ThirdPersonDistance or 0

    ViewEx.ViewDist = Settings.Vars.ThirdPersonSmooth > 0 and math_Approach( ViewEx.ViewDist, ThirdPersonDistance, Settings.Vars.ThirdPersonSmooth ) or ThirdPersonDistance
    ViewEx.FreeCam  = Settings.Vars.FreeCamera and Settings.Binds[ 2 ].State

    ViewData = { 
        origin = origin, 
        angles = Settings.Vars.SilentAim and ViewEx.Angles or angles, 
        fov = Settings.Vars.OverrideFov and Settings.Vars.FovValue or fov, 
        drawviewer = false 
    }

    if ViewEx.FreeCam then
        ViewData.drawviewer = not Settings.Vars.FreeCameraGhetto

        for i = 1, 4 do
            if not InputEx.IsKeyDown( ViewEx.FreeCamDirs[ i ].key ) then
                continue 
            end 

            ViewEx.Origin = ViewEx.Origin + ViewEx.FreeCamDirs[ i ].fnc( ViewEx.Angles ) * Settings.Vars.FreeCameraSpeed
        end

        ViewData.origin = ViewEx.Origin
    elseif math_Ceil( ViewEx.ViewDist ) > 10 then
        ViewData.drawviewer = true 

        if Settings.Vars.ThirdPersonCollide then
            Trace.HullStruct.mask   = MASK_VISIBLE
            Trace.HullStruct.start  = origin
            Trace.HullStruct.endpos = origin - ViewData.angles:Forward() * ViewEx.ViewDist

            Trace.Output = util_TraceHull( Trace.HullStruct )

            ViewData.origin = Trace.Output.HitPos
        else
            ViewData.origin = origin - ViewData.angles:Forward() * ViewEx.ViewDist
        end
    end

    if not ViewEx.FreeCam then
        ViewEx.Origin = ViewData.origin
    end

    return ViewData
end

ViewEx.VmPos = Vec()
function Sublimity.CalcViewModelView( wep, vm, oldPos, oldAng, pos, ang )
    ViewEx.VmPos = Settings.Vars.OverrideViewmodel and ViewEx.Origin + ViewEx.Angles:Forward() * Settings.Vars.ViewmodelFov or ViewEx.Origin
    
    return ViewEx.VmPos, ViewEx.Angles
end 

ded.ConVarSetFlags( "r_aspectratio", 0 )
function ViewEx.ModifyAspect()
    RunCommand( "r_aspectratio", Settings.Vars.OverrideAspect )
end


// Insanely fucked up user interface
local UI = {}

UI.FrameVisbile = false
UI.FrameX    = 75
UI.FrameY    = 75
UI.OldFrameX = 75
UI.OldFrameY = 75
UI.FrameW    = 750
UI.FrameH    = 850

UI.Tabs       = { "Combat", "Rage", "Visuals", "Render", "Misc", "Settings", "Lists" }
UI.CurrentTab = "Combat"
UI.TabSize    = math_Floor( ( UI.FrameW / #UI.Tabs ) - 4 )  
 
UI.CursorInArea = false
UI.CursorHover  = false 
UI.CursorX = 0
UI.CursorY = 0

UI.HoveringSubframe = false 

function UI.CursorInRect( x, y, w, h ) 
    return ( UI.CursorX >= x and UI.CursorX <= x + w ) and (UI.CursorY >= y and UI.CursorY <= y + h )
end

UI.ThemeBoxes = {}
UI.ThemeBoxID = 0
UI.ThemeBoxW  = 243
   
function UI.StartThemeBox( str )
    if not UI.ThemeBoxes[ DrawEx.Context.g ] then
        UI.ThemeBoxes[ DrawEx.Context.g ] = 0
    end

    DrawEx.Context.tw, DrawEx.Context.th = DrawEx.GetTextSize( str )

    DrawEx.SetTextColor( Settings.Menu.TextNormal )
    surface_SetTextPos( DrawEx.Context.x + UI.ThemeBoxW / 2 - DrawEx.Context.tw / 2, DrawEx.Context.y + 2 )
    surface_DrawText( str )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW, UI.ThemeBoxes[ DrawEx.Context.g ] )
    surface_DrawRect( DrawEx.Context.x + 4, DrawEx.Context.y + DrawEx.Context.th + 4, UI.ThemeBoxW - 9, 1 )

    DrawEx.Context.x = DrawEx.Context.x + 4
    DrawEx.Context.y = DrawEx.Context.y + DrawEx.Context.th + 8
    DrawEx.Context.h = DrawEx.Context.th + 6
end

function UI.EndThemeBox()
    UI.ThemeBoxes[ DrawEx.Context.g ] = DrawEx.Context.h + 3

    DrawEx.Context.g = DrawEx.Context.g + 1
    DrawEx.Context.y = DrawEx.Context.y + 4
    DrawEx.Context.x = DrawEx.Context.x - 4 
end

function UI.Spacer()
    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW - 9, 1 )

    DrawEx.Context.y = DrawEx.Context.y + 4
    DrawEx.Context.h = DrawEx.Context.h + 4
end

UI.CheckboxSize = 16 

UI.ShowHint = false 
UI.HintType = 1
UI.HintX = 0
UI.HintY = 0

UI.ColorPicker = false 
UI.PickerFunc = false 
UI.PickerX = 0 
UI.PickerY = 0 

UI.Binder  = false 
UI.BinderX = 0 
UI.BinderY = 0 
UI.BindModes = { "Hold", "Toggle", "Always" }

function UI.Checkbox( Str, Var, ColorPicker, Binder, Hint, HintType, Disabled, TextColor, OnPaint, OnChange, ColorPickerOnChange )
    if Disabled then surface_SetAlphaMultiplier( 0.25 ) end

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    if Settings.Vars[ Var ] then
        surface_DrawRect( DrawEx.Context.x + 2, DrawEx.Context.y + 2, UI.CheckboxSize - 4, UI.CheckboxSize - 4 )
    end

    DrawEx.SetTextColor( TextColor and TextColor or Settings.Menu.TextNormal )
    surface_SetTextPos( DrawEx.Context.x + UI.CheckboxSize + 2, DrawEx.Context.y + 1 )
    surface_DrawText( Str )

    if UI.CursorInArea and not UI.HoveringSubframe then
        if Hint then
            UI.HintType = HintType or 1
            UI.ShowHint = Hint
            
            UI.HintX = UI.CursorX
            UI.HintY = UI.CursorY
        end

        if InputEx.KeysPressed[ MOUSE_LEFT ] and not Disabled then
            Settings.Vars[ Var ] = not Settings.Vars[ Var ]
            if OnChange then OnChange( Settings.Vars[ Var ] ) end 
        end

        UI.CursorHover = true
    end

    if ColorPicker then
        local x = DrawEx.Context.x + UI.ThemeBoxW - UI.CheckboxSize - 9

        UI.CursorInArea = UI.CursorInRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

        surface_SetDrawColor( 255, 255, 255 )
        DrawEx.DrawTexture( "gui/alpha_grid.png", x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

        DrawEx.SetColor( Settings.Colors[ Var ] )
        surface_DrawRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

        DrawEx.SetColor( Settings.Menu.Outline )
        surface_DrawOutlinedRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

        if UI.CursorInArea and not UI.HoveringSubframe then
            if InputEx.KeysPressed[ MOUSE_LEFT ] and not Disabled then
                UI.ColorPicker = Var
                UI.PickerX = x + UI.CheckboxSize + 6
                UI.PickerY = DrawEx.Context.y

                if ColorPickerOnChange then
                    UI.PickerFunc = ColorPickerOnChange
                end
            end

            UI.CursorHover = true
        end
    end

    if Binder then
        local x = DrawEx.Context.x + UI.ThemeBoxW - ( ColorPicker and UI.CheckboxSize * 2 or UI.CheckboxSize ) - 9
        UI.CursorInArea = UI.CursorInRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

        DrawEx.SetTextColor( Settings.Menu.TextNormal )
        surface_SetTextPos( x, DrawEx.Context.y )
        surface_DrawText( "⌨" )

        if UI.CursorInArea and not UI.HoveringSubframe then
            if InputEx.KeysPressed[ MOUSE_LEFT ] and not Disabled then
                UI.Binder  = Binder
                UI.BinderX = DrawEx.Context.x
                UI.BinderY = DrawEx.Context.y + 35 
            end

            UI.CursorHover = true
        end
    end

    if OnPaint then OnPaint( DrawEx.Context.x, DrawEx.Context.y ) end 
    if Disabled then surface_SetAlphaMultiplier( 1 ) end

    DrawEx.Context.y = DrawEx.Context.y + UI.CheckboxSize + 3
    DrawEx.Context.h = DrawEx.Context.h + UI.CheckboxSize + 3
end 

function UI.SeparateColorPicker( Str, Var, OnChange )
    local x = DrawEx.Context.x + UI.ThemeBoxW - UI.CheckboxSize - 9

    DrawEx.SetTextColor( Settings.Menu.TextNormal )
    surface_SetTextPos( DrawEx.Context.x + 2, DrawEx.Context.y + 1 )
    surface_DrawText( Str )

    UI.CursorInArea = UI.CursorInRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    surface_SetDrawColor( 255, 255, 255 )
    DrawEx.DrawTexture( "gui/alpha_grid.png", x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    DrawEx.SetColor( Settings.Colors[ Var ] )
    surface_DrawRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( x, DrawEx.Context.y, UI.CheckboxSize, UI.CheckboxSize )

    if UI.CursorInArea and not UI.HoveringSubframe then
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            UI.ColorPicker = Var
            UI.PickerX = x + UI.CheckboxSize + 6
            UI.PickerY = DrawEx.Context.y
            if OnChange then UI.PickerFunc = OnChange end
        end

        UI.CursorHover = true
    end

    DrawEx.Context.y = DrawEx.Context.y + UI.CheckboxSize + 3
    DrawEx.Context.h = DrawEx.Context.h + UI.CheckboxSize + 3
end

function UI.SeparateBinder( Str, Bind )
    DrawEx.SetTextColor( Settings.Menu.TextNormal )

    surface_SetTextPos( DrawEx.Context.x, DrawEx.Context.y )
    surface_DrawText( Str )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x + UI.ThemeBoxW - 91, DrawEx.Context.y, 82, 16 )

    local keyName = Settings.Binds[ Bind ].Trapping and "..." or Settings.Binds[ Bind ].Key >= 0 and string_upper( input_lib.GetKeyName( Settings.Binds[ Bind ].Key ) ) or "NONE"
    DrawEx.Context.tw, DrawEx.Context.th = DrawEx.GetTextSize( keyName )
    surface_SetTextPos( ( DrawEx.Context.x + UI.ThemeBoxW - 91 ) + 41 - DrawEx.Context.tw / 2, DrawEx.Context.y )
    surface_DrawText( keyName )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x + UI.ThemeBoxW - 91, DrawEx.Context.y, 82, 16 )

    if input_lib.IsKeyTrapping() and Settings.Binds[ Bind ].Trapping then
        local code = input_lib.CheckKeyTrapping()

        if code then
            Settings.Binds[ Bind ].Key = code == KEY_ESCAPE and -1 or code
            Settings.Binds[ Bind ].Trapping = false
        end
    end

    if UI.CursorInArea and not UI.HoveringSubframe then
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            input_lib.StartKeyTrapping()
            Settings.Binds[ Bind ].Trapping = not Settings.Binds[ Bind ].Trapping 
        elseif InputEx.KeysPressed[ MOUSE_RIGHT ] then
            Settings.Binds[ Bind ].Key = -1
            Settings.Binds[ Bind ].Trapping = false
        end

        UI.CursorHover = true
    end

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x + UI.ThemeBoxW - 157, DrawEx.Context.y, 62, 16 )

    DrawEx.Context.tw, DrawEx.Context.th = DrawEx.GetTextSize( UI.BindModes[ Settings.Binds[ Bind ].Mode ] )
    surface_SetTextPos( ( DrawEx.Context.x + UI.ThemeBoxW - 157 ) + 31 - DrawEx.Context.tw / 2, DrawEx.Context.y )
    surface_DrawText( UI.BindModes[ Settings.Binds[ Bind ].Mode ] )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x + UI.ThemeBoxW - 157, DrawEx.Context.y, 62, 16 )

    if UI.CursorInArea and not UI.HoveringSubframe then
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            Settings.Binds[ Bind ].Mode = ( Settings.Binds[ Bind ].Mode + 1 ) % 4

            if Settings.Binds[ Bind ].Mode < 1 then 
                Settings.Binds[ Bind ].Mode = 1 
            end 
        end

        UI.CursorHover = true
    end
    
    DrawEx.Context.y = DrawEx.Context.y + 19
    DrawEx.Context.h = DrawEx.Context.h + 19
end

function UI.Slider( Str, Symbol, Var, Dec, Min, Max, OnChange )
    local Len = Settings.Vars[ Var ] / Max * ( UI.ThemeBoxW - 13 )
    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW, 30 )

    DrawEx.SetTextColor( Settings.Menu.TextNormal )

    surface_SetTextPos( DrawEx.Context.x, DrawEx.Context.y )
    surface_DrawText( Str )

    DrawEx.Context.tw, DrawEx.Context.th = DrawEx.GetTextSize( Settings.Vars[ Var ] .. Symbol )

    surface_SetTextPos( DrawEx.Context.x + UI.ThemeBoxW - 9 - DrawEx.Context.tw, DrawEx.Context.y )
    surface_DrawText( Settings.Vars[ Var ] .. Symbol )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 9, 10 )
    surface_DrawRect( DrawEx.Context.x + 2, DrawEx.Context.y + 18, Len, 6 )

    if UI.CursorInArea and not UI.HoveringSubframe then
        if InputEx.KeysDown[ MOUSE_LEFT ] then
            Settings.Vars[ Var ] = math_Round( Min + ( ( UI.CursorX - DrawEx.Context.x ) / ( DrawEx.Context.x + UI.ThemeBoxW - 9 - DrawEx.Context.x ) ) * ( Max - Min ), Dec )
            Settings.Vars[ Var ] = math_Clamp( Settings.Vars[ Var ], Min, Max )

            if OnChange then
                OnChange( Settings.Vars[ Var ] )
            end
        end
        
        UI.CursorHover = true
    end

    DrawEx.Context.y = DrawEx.Context.y + 30
    DrawEx.Context.h = DrawEx.Context.h + 30
end

UI.MultiCombo = false 
UI.ComboPanel = false 
UI.ComboVars = false 
UI.ComboX = 0 
UI.ComboY = 0 

function UI.ComboBox( Str, Var, Options, Multi )
    DrawEx.SetTextColor( Settings.Menu.TextNormal )

    surface_SetTextPos( DrawEx.Context.x, DrawEx.Context.y )
    surface_DrawText( Str )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 9, 20 )
    surface_DrawRect( DrawEx.Context.x + UI.ThemeBoxW - 29, DrawEx.Context.y + 16, 1, 20 )

    local MultiStr = "None"
    if Multi then
        for i = 1, #Options do
            if not Settings.Vars[ Var .. Options[ i ] ] then continue end 
            local Sep = ", "

            if MultiStr == "None" then 
                MultiStr = "" 
                Sep = ""
            end

            MultiStr = MultiStr .. Sep .. Options[ i ]
        end
    end 

    surface_SetTextPos( DrawEx.Context.x + 4, DrawEx.Context.y + 18 )
    surface_DrawText( Multi and string_sub( MultiStr, 1, 34 ) or Options[ Settings.Vars[ Var ] ] )

    surface_SetTextPos( DrawEx.Context.x + UI.ThemeBoxW - 26, DrawEx.Context.y + 18 )
    surface_DrawText( "▼" )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 9, 20 )

    if UI.CursorInArea and not UI.HoveringSubframe then 
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            UI.MultiCombo = Multi
            UI.ComboPanel = Var 
            UI.ComboVars = Options

            UI.ComboX = DrawEx.Context.x
            UI.ComboY = DrawEx.Context.y + 35
        end

        UI.CursorHover = true
    end

    DrawEx.Context.y = DrawEx.Context.y + 40
    DrawEx.Context.h = DrawEx.Context.h + 40
end

function UI.ButtonEx( Str, OnPress )
    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW - 9, UI.CheckboxSize )
    
    DrawEx.Context.tw, DrawEx.Context.th = DrawEx.GetTextSize( Str )

    DrawEx.SetTextColor( Settings.Menu.TextNormal )
    surface_SetTextPos( DrawEx.Context.x +  ( ( UI.ThemeBoxW - 9 ) / 2 ) - ( DrawEx.Context.tw / 2 ), DrawEx.Context.y + 1 )
    surface_DrawText( Str )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW - 9, UI.CheckboxSize )

    if UI.CursorInArea and not UI.HoveringSubframe then 
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            OnPress()
        end

        UI.CursorHover = true
    end

    DrawEx.Context.y = DrawEx.Context.y + UI.CheckboxSize + 3
    DrawEx.Context.h = DrawEx.Context.h + UI.CheckboxSize + 3 
end 

UI.EditingText = false 
UI.EditorX = 0
UI.EditorY = 0 
UI.EditorMax = 0
UI.EditorFunc = false

UI.KeysAction = {
    [ KEY_BACKSPACE ] = function( Str ) return string_sub( Str, 1, #Str - 1 ) end,
    [ KEY_SPACE ] = function( Str ) return Str .. " " end,
    [ KEY_EQUAL ] = function( Str ) return Str .. "=" end,
    [ KEY_SLASH ] = function( Str ) return Str .. "/" end,
    [ KEY_COMMA ] = function( Str ) return Str .. "," end,
}

function UI.TextInput( Str, Var, MaxChar, OnChange )
    DrawEx.SetTextColor( Var == UI.EditingText and Settings.Menu.TextActive or Settings.Menu.TextNormal )

    surface_SetTextPos( DrawEx.Context.x, DrawEx.Context.y )
    surface_DrawText( Str )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 33, 20 )
    surface_DrawOutlinedRect( DrawEx.Context.x + UI.ThemeBoxW - 29, DrawEx.Context.y + 16, 20, 20 )

    surface_SetTextPos( DrawEx.Context.x + 4, DrawEx.Context.y + 18 )
    surface_DrawText( string_sub( Settings.Vars[ Var ], 1, 28 ) )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 33, 20 )

    if UI.CursorInArea and not UI.HoveringSubframe then 
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            UI.EditingText = Var 
            UI.EditorX = DrawEx.Context.x
            UI.EditorY = DrawEx.Context.y + 16 
            UI.EditorMax = MaxChar
            if OnChange then UI.EditorFunc = OnChange end
        end

        UI.CursorHover = true
    end

    surface_SetTextPos( DrawEx.Context.x + UI.ThemeBoxW - 24, DrawEx.Context.y + 18 )
    surface_DrawText( "V" )
    
    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x + UI.ThemeBoxW - 29, DrawEx.Context.y + 16, 20, 20 )

    if UI.CursorInArea and not UI.HoveringSubframe then 
        if InputEx.KeysPressed[ MOUSE_LEFT ] and ded.GetClipboardText() then
            Settings.Vars[ Var ] = ded.GetClipboardText()
        end

        UI.CursorHover = true
    end
    
    DrawEx.Context.y = DrawEx.Context.y + 40
    DrawEx.Context.h = DrawEx.Context.h + 40
end

function UI.ListEntity( Name, Option )
    DrawEx.SetTextColor( Settings.EntList[ Name ] and Settings.Menu.TextActive or Settings.Menu.TextNormal )

    surface_SetTextPos( DrawEx.Context.x, DrawEx.Context.y )
    surface_DrawText( Name )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawRect( DrawEx.Context.x, DrawEx.Context.y + 16, UI.ThemeBoxW - 9, 1 )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, UI.ThemeBoxW - 9, 16 )

    if UI.CursorInArea and not UI.HoveringSubframe then 
        if InputEx.KeysPressed[ MOUSE_LEFT ] then
            if Settings.EntList[ Name ] then
                Settings.EntList[ Name ] = false 
            else
                Settings.EntList[ Name ] = true 
            end
        end

        UI.CursorHover = true
    end

    DrawEx.Context.y = DrawEx.Context.y + 16
    DrawEx.Context.h = DrawEx.Context.h + 16
end

// Multi material 
Sublimity.MaterialCache = {}
UI.ChamsOptions = {}
UI.ChamsSubTabs = {}

function Sublimity.AddMaterial( Str, ShaderParams )
    local MatStr = #Sublimity.MaterialCache[ Str ] .. "x" .. Str .. "x" .. math_Ceil( CurrentTime )
    local Params = { ["$model"] = 1, ["$nocull"] = 1, ["$nodecal"] = 1, ["$halflambert"] = 1, ["$additive"] = 0 }

    if ShaderParams then
        for k, v in NextPairs( ShaderParams ) do
            Params[ k ] = v
        end
    end

    local Obj = CreateMaterial( MatStr, "VertexLitGeneric", Params )

    Sublimity.MaterialCache[ Str ][ #Sublimity.MaterialCache[ Str ] + 1 ] = Obj
end

function UI.UpdateFresnel( str )
    Sublimity.MaterialCache[ str ][ 3 ]:SetVector( "$selfIllumFresnelMinMaxExp", Vec( Settings.Vars[ str .. "_Min" ], Settings.Vars[ str .. "_Max" ], Settings.Vars[ str .. "_Exp" ] ) )
    Sublimity.MaterialCache[ str ][ 3 ]:Recompute()
end

function UI.UpdateTint( str )
    local R, G, B = ColorEx.RgbObjToVec( Settings.Colors[ str .. "GlowTint" ] ) 
    Sublimity.MaterialCache[ str ][ 3 ]:SetVector( "$selfillumtint", Vec( R, G, B ) )
    Sublimity.MaterialCache[ str ][ 3 ]:Recompute() 
end

function UI.UpdateCloak( str )
    local R, G, B = ColorEx.RgbObjToVec( Settings.Colors[ str .. "CloakTint" ] ) 
    Sublimity.MaterialCache[ str ][ 6 ]:SetVector( "$cloakcolortint", Vec( R, G, B ) )
    Sublimity.MaterialCache[ str ][ 6 ]:SetFloat( "$cloakfactor", Settings.Vars[ str .. "_Factor" ] )
    Sublimity.MaterialCache[ str ][ 6 ]:Recompute() 
end

function UI.UpdatePhong( str )
    local R, G, B = ColorEx.RgbObjToVec( Settings.Colors[ str .. "PhongTint" ] ) 
    Sublimity.MaterialCache[ str ][ 7 ]:SetVector( "$phongtint", Vec( R, G, B ) )
    Sublimity.MaterialCache[ str ][ 7 ]:SetFloat( "$phongexponent", Settings.Vars[ str .. "_PhongExp" ] )
    Sublimity.MaterialCache[ str ][ 7 ]:SetFloat( "$phongboost", Settings.Vars[ str .. "_Boost" ] )
    Sublimity.MaterialCache[ str ][ 7 ]:Recompute() 
end
 
UI.ChamFuncs = {}

function Sublimity.AddChams( str )
    Sublimity.MaterialCache[ str ] = {}

    Settings.Vars[ str .. "Chams" ]         = false 
    Settings.Vars[ str .. "Material" ]      = 1 
    Settings.Vars[ str .. "Fullbright" ]    = false 
    Settings.Vars[ str .. "IgnoreZ" ]       = false 

    Settings.Vars[ str .. "_Scroll" ]     = false
    Settings.Vars[ str .. "_Min" ]        = 0
    Settings.Vars[ str .. "_Max" ]        = 0.3
    Settings.Vars[ str .. "_Exp" ]        = 0.6
    Settings.Vars[ str .. "_Factor" ]     = 0.29
    Settings.Vars[ str .. "_PhongExp" ]   = 3
    Settings.Vars[ str .. "_Boost" ]      = 4
    Settings.Vars[ str .. "_Saturation" ] = 1
    Settings.Vars[ str .. "_Contrast" ]   = 1

    Settings.Colors[ str .. "Chams" ]     = ColorEx.Rgb( 255, 255, 255 )
    Settings.Colors[ str .. "GlowTint" ]  = ColorEx.Rgb( 0, 0, 0 )
    Settings.Colors[ str .. "CloakTint" ] = ColorEx.Rgb( 64, 64, 64 )
    Settings.Colors[ str .. "PhongTint" ] = ColorEx.Rgb( 255, 255, 255 )
    Settings.Colors[ str .. "HeatTint" ]  = ColorEx.Rgb( 255, 128, 25 )

    Sublimity.AddMaterial( str )
    Sublimity.AddMaterial( str, { ["$wireframe"] = 1 } )
    Sublimity.AddMaterial( str, { ["$basetexture"] = "vgui/white_additive", ["$bumpmap"] = "vgui/white_additive", ["$selfillum"] = 1, ["$selfIllumFresnel"] = 1, ["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]", ["$selfillumtint"] = "[0 0 0]" } )
    Sublimity.AddMaterial( str, { ["$envmap"] = "env_cubemap", ["$envmaptint"] = "[ 1 1 1 ]", ["$envmapcontrast"] = 0, ["$halflambert"] = 1, ["$envmapsaturation"] = 1 } ) 
    Sublimity.AddMaterial( str, { ["$basetexture"] = "_rt_fullframefb", ["$additive"] = 1 } )
    Sublimity.AddMaterial( str, { ['$cloakpassenabled'] = 1, ['$cloakcolortint'] = '[0.2 0.2 0.2]', ['$cloakfactor'] = 0.29 } ) 							
    Sublimity.AddMaterial( str, { ["$baseTexture"] = "phoenix_storms/chrome", ["$bumpmap" ] = "models/shadertest/shader3_normal", ["$envmap" ] = "env_cubemap", ["$normalmapalphaenvmapmask"] = 1, ["$envmaptint" ] = "[ 1 1 1 ]", ["$envmapconstrast" ] = 1, ["$phong"] = 1, ["$phongexponent"] = 3, ["$phongboost"] = 4, ["$phongfresnelranges"] = "[0 0.5 1]",  ["$phongwarptexture"] = "vgui/hsv-bar", ["$phongtint"] = "[ 1 1 1 ]" } ) 
    Sublimity.AddMaterial( str, { ["$wireframe"] = 1, ["$basetexture"] = "models/roller/rollermine_glow", ["proxies"] = { ["texturescroll"] = { ["texturescrollvar"] = "$basetexturetransform", ["texturescrollrate"] = "0.4", ["texturescrollangle"] = "90" } } } )
    
    UI.ChamFuncs[ str ] = {
        UpdateFresnel = function() UI.UpdateFresnel( str ) end,
        UpdateTint = function() UI.UpdateTint( str ) end,
        UpdateCloak = function() UI.UpdateCloak( str ) end,
        UpdatePhong = function() UI.UpdatePhong( str ) end,
    }

    UI.ChamsOptions[ str ] = {
        [ 1 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
        end,
        [ 2 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
            UI.Checkbox( "Scrolling", str .. "_Scroll" )
        end,
        [ 3 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
         
            UI.SeparateColorPicker( "Tint color", str .. "GlowTint", UI.ChamFuncs[ str ].UpdateTint )
    
            UI.Slider( "Min range", "", str .. "_Min", 2, 0, 1, UI.ChamFuncs[ str ].UpdateFresnel )
            UI.Slider( "Max range", "", str .. "_Max", 2, 0, 1, UI.ChamFuncs[ str ].UpdateFresnel )
            UI.Slider( "Exponent", "", str .. "_Exp", 2, 0, 1, UI.ChamFuncs[ str ].UpdateFresnel )
        end,
        [ 4 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
        end,
        [ 5 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
        end,
        [ 6 ] = function()
            UI.Checkbox( "Fullbright", str .. "Fullbright" )
    
            UI.SeparateColorPicker( "Tint color", str .. "CloakTint", UI.ChamFuncs[ str ].UpdateCloak )
            UI.Slider( "Factor", "", str .. "_Factor", 2, 0, 1, UI.ChamFuncs[ str ].UpdateCloak )
        end,
        [ 7 ] = function()
            UI.Slider( "Exponent", "", str .. "_PhongExp", 1, 0, 16, UI.ChamFuncs[ str ].UpdatePhong )
            UI.Slider( "Boost", "", str .. "_Boost", 1, 0, 16, UI.ChamFuncs[ str ].UpdatePhong  )
            UI.SeparateColorPicker( "Tint color", str .. "PhongTint", UI.ChamFuncs[ str ].UpdatePhong )
        end,
    }

    UI.ChamsSubTabs[ #UI.ChamsSubTabs + 1 ] = str
end

Sublimity.AddChams( "Player" )
Sublimity.AddChams( "Entity" )
Sublimity.AddChams( "Viewmodel" )
Sublimity.AddChams( "Hands" )

function UI.BeamColor()
    Sublimity.BeamColor.r = Settings.Colors.BulletTracer[ 1 ]
    Sublimity.BeamColor.g = Settings.Colors.BulletTracer[ 2 ]
    Sublimity.BeamColor.b = Settings.Colors.BulletTracer[ 3 ]
    Sublimity.BeamColor.a = Settings.Colors.BulletTracer[ 4 ]
end

UI.EntityList = {}

UI.TabFuncs = {
    [ "Combat" ] = function()
        UI.StartThemeBox( "Aimbot" )
        
        UI.Checkbox( "Enable aimbot", "EnableAimbot" )
        UI.SeparateBinder( "Aim key", 3 )
        UI.ComboBox( "Disablers", "Disablers", { "Spectated", "Bullet time", "Wait for send" }, true )

        UI.Spacer()

        UI.Checkbox( "Silent aimbot", "SilentAim" )
        UI.Checkbox( "Perfect silent", "ContextAimbot" )

        UI.Spacer()

        UI.Checkbox( "Rapid fire", "RapidFire" )
        UI.Checkbox( "Alt rapid fire", "RapidFireAlt" )

        UI.Spacer()

        UI.Checkbox( "Auto fire", "AutoFire" )
        UI.Checkbox( "Auto alt fire", "AutoFireAlt" )
        UI.Checkbox( "Auto reload", "AutoReload" )
        UI.ComboBox( "Auto switch", "AutoSwitch", { "Empty clip", "Empty reserve" }, true )

        UI.EndThemeBox()

        UI.StartThemeBox( "Legit" )

        UI.Checkbox( "Smoothing", "Smoothing" )
        UI.Checkbox( "Randomise smooth", "SmoothingRandom" )
        UI.Slider( "Smooth amount", "", "SmoothingAmount", 2, 0, 1 )

        UI.Spacer()

        UI.Checkbox( "FOV limited", "FovLimit" )
        UI.Checkbox( "Dynamic FOV", "DynamicFov" )
        UI.Slider( "FOV degree", "°", "FovAmount", 0, 1, 180 )

        UI.Spacer()

        UI.Checkbox( "Accelerative leading", "AccelerativeLeading" )

        UI.Spacer()

        UI.Checkbox( "Trigger", "TriggerBot" )
        UI.Slider( "Trigger delay", "s", "TriggerDelay", 2, 0.05, 1 )

        UI.EndThemeBox()

        DrawEx.Context.x = UI.FrameX + 10 + UI.ThemeBoxW 
        DrawEx.Context.y = UI.FrameY + 30

        UI.StartThemeBox( "Acccuracy" )

        UI.ComboBox( "Interpolation", "Interp", { "Position", "Sequence" }, true )
        UI.ComboBox( "Sync", "Sync", { "Animations", "Bones" }, true )

        UI.Spacer()

        UI.Checkbox( "Compensate recoil", "NoRecoil" )
        UI.Checkbox( "Compensate spread", "NoSpread" )
        UI.ComboBox( "Auto stop", "AutoStop", { "Disabled", "Full", "Minimal" } )

        UI.Spacer()

        UI.Checkbox( "Adjust tickcount", "AdjustTickcount" )

        UI.EndThemeBox()

        UI.StartThemeBox( "Prediction" )

        UI.Checkbox( "Enable prediction", "Prediction" )
        UI.ComboBox( "Prediction method", "PredictionMethod", { "Single", "Continuous" } )
        UI.ComboBox( "Prediction mode", "PredictionMode", { "Simulation", "Badic tracing", "Advanced tracing" } )
        UI.Slider( "Simulation limit", " ticks", "SimulationLimit", 0, 1, 64 )

        UI.EndThemeBox()

        UI.StartThemeBox( "Misc" )

        UI.Checkbox( "Melee bot", "AutoMelee" )
        UI.ComboBox( "Melee mode", "MeleeMode", { "Fast", "Damage", "Lethal" } )
        UI.Checkbox( "Face stab", "FaceStab" )
        UI.Checkbox( "Follow target", "FollowTarget" )
        UI.Spacer()
        UI.Checkbox( "iSLAM", "AutoDetonator" )
        UI.Checkbox( "Crossbow trigger", "XBowTrigger" )
        
        UI.EndThemeBox()

        DrawEx.Context.x = UI.FrameX + 15 + UI.ThemeBoxW * 2
        DrawEx.Context.y = UI.FrameY + 30

        UI.StartThemeBox( "Target selection" )

        UI.ComboBox( "Selection method", "TargetSelection", { "Closest distance", "Field of view", "Lowest health" } )
        UI.Slider( "Max targets", "", "MaxTargets", 0, 0, 10 )

        UI.Spacer()

        UI.Checkbox( "Auto wallz", "Wallz" )
        UI.ComboBox( "Ignore", "Ignore", { "Friends", "Steam friends", "Bots", "Teammates", "Driving", "God", "Noclip", "Nodraw", "Frozen", "Admin", "Broken LC" }, true )

        UI.Spacer()

        UI.ComboBox( "Extrapolation", "Extrapolation", { "Disabled", "Minimal", "Lowest health" } )
        
        UI.EndThemeBox()

        UI.StartThemeBox( "Hitbox selection" )

        UI.ComboBox( "Target hitbox", "HitboxSelection", { "Head", "Chest", "Penis" } )
        UI.Checkbox( "Only headshot", "OnlyHead" )

        UI.Spacer()

        UI.Checkbox( "Hit scan", "HitScan" )
        UI.ComboBox( "Scannable groups", "Hitbox", { "Head", "Chest", "Stomach", "Arms", "Legs" }, true )
        UI.ComboBox( "Scan priority", "HitboxPriority", { "Damage", "Scale", "Safety" } )

        UI.Spacer()

        UI.Checkbox( "Multipoint", "Multipoints" )
        UI.Slider( "Multipoint scale", "", "MultipointScale", 0, 0.1, 1 )

        UI.EndThemeBox()

        UI.StartThemeBox( "Hitbox selection" )

        UI.Checkbox( "Backtracking", "Backtracking" )
        UI.ComboBox( "Backtrack method", "BacktrackingMethod", { "Rage", "Legit", "Always" } )
        UI.ComboBox( "Backtrack mode", "BacktrackingMode", { "Last tick", "Closest", "Scan" } )
        UI.Slider( "Sampling interval", "ms", "BacktrackingInterval", 0, 0, 100 )
        UI.Slider( "Backtrack time", "ms", "BacktrackTime", 0, 100, 1000 )

        UI.EndThemeBox()
    end,
    [ "Rage" ] = function()

    end,
    [ "Visuals" ] = function()
        UI.StartThemeBox( "Player" )

        UI.Checkbox( "Bounding box", "BoxEsp", true )
        UI.SeparateColorPicker( "Background color", "BoxBg" )

        UI.Checkbox( "Team color", "BoxTeamColor" )
        UI.Checkbox( "Gradient", "BoxGradient", true )

        UI.Checkbox( "Filled box", "FilledBox", true )
        UI.Checkbox( "Gradient fill", "FilledGradient" )
        
        UI.Checkbox( "Sight lines", "SightLines" )
        UI.Checkbox( "Skeleton", "SkeletonEsp", true )
        
   
        UI.EndThemeBox()
    end,
    [ "Render" ] = function()
        UI.StartThemeBox( "View" )

        UI.Checkbox( "Third person", "ThirdPerson" )
        UI.Checkbox( "Camera collision", "ThirdPersonCollide" )
        UI.Slider( "Distance", "", "ThirdPersonDistance", 0, 45, 150 )
        UI.Slider( "Smoothing", "", "ThirdPersonSmooth", 0, 1, 10 )
        UI.SeparateBinder( "Thirdperson", 1 )

        UI.Spacer()

        UI.Checkbox( "Free camera", "FreeCamera" )
        UI.Checkbox( "Ghetto mode", "FreeCameraGhetto" )
        UI.Slider( "Camera speed", "", "FreeCameraSpeed", 0, 1, 20 )
        UI.SeparateBinder( "Freecam", 2 )
        
        UI.Spacer()

        UI.Checkbox( "Fov changer", "OverrideFov" )
        UI.Slider( "Fov value", "", "FovValue", 0, 1, 160 )
        UI.Checkbox( "Viewmodel fov changer", "OverrideViewmodel" )
        UI.Slider( "Fov value", "", "ViewmodelFov", 0, 1, 30 )
        UI.Slider( "Aspect ratio", "", "OverrideAspect", 2, 0, 2, ViewEx.ModifyAspect )

        UI.EndThemeBox()

        UI.StartThemeBox( "Tracing" )

        UI.Checkbox( "Bullet tracers", "BulletTracer", true, nil, nil, nil, nil, nil, nil, nil, UI.BeamColor )
        UI.Checkbox( "Muzzle tracers", "MuzzleTracer" )
        UI.Checkbox( "Bullet impacts", "BulletImpacts" )
        UI.Slider( "Tracer die time", "s", "TracerDieTime", 0, 1, 12 )

        UI.Spacer()

        UI.Checkbox( "Projectile prediction", "ProjectilePrediction" )
        UI.Checkbox( "Projectile trajectories", "ProjectileTrajectories" )

        UI.EndThemeBox()

        DrawEx.Context.x = UI.FrameX + 10 + UI.ThemeBoxW 
        DrawEx.Context.y = UI.FrameY + 30

        local Str 
        for i = 1, #UI.ChamsSubTabs do
            Str = UI.ChamsSubTabs[ i ]

            UI.StartThemeBox( Str )

            UI.Checkbox( "Override material", Str .. "Chams", true )
            UI.ComboBox( "Material", Str .. "Material", { "Solid", "Wireframe", "Glow", "Reflect", "Crystal", "Cloak", "Phong"} )
            
            UI.ChamsOptions[ Str ][ Settings.Vars[ Str .. "Material" ] ]() 
            
            if Str != "Viewmodel" and Str != "Hands" then
                UI.Spacer()
            
                UI.Checkbox( "Ignore Z", Str .. "IgnoreZ" )
            end

            UI.EndThemeBox()
        end

        DrawEx.Context.x = UI.FrameX + 15 + UI.ThemeBoxW * 2
        DrawEx.Context.y = UI.FrameY + 30

        UI.StartThemeBox( "World" )

        UI.Checkbox( "Fullbright", "Fullbright" )
        UI.SeparateBinder( "Bright key", 10 )

        UI.Spacer()

        UI.Checkbox( "Override wall color", "WallColor", true, nil, nil, nil, nil, nil, nil, WorldEx.ModulateColor, WorldEx.ModulateColor )
        UI.Checkbox( "Override sky color", "SkyColor", true, nil, nil, nil, nil, nil, nil, WorldEx.ModulateSky, WorldEx.ModulateSky )

        if WorldEx.SkyPaint then
            UI.Checkbox( "Override sky paint", "ModulatePaint", nil, nil, nil, nil, nil, nil, nil, WorldEx.ModulateSkyPaint )

            UI.Spacer()

            UI.SeparateColorPicker( "Top color", "topcolor", WorldEx.ModulateSkyPaint )
            UI.SeparateColorPicker( "Dusk color", "duskcolor", WorldEx.ModulateSkyPaint )
            UI.SeparateColorPicker( "Bottom color", "bottomcolor", WorldEx.ModulateSkyPaint )

            UI.Slider( "Fade BIAS", "", "fadebias", 2, 0, 1, WorldEx.ModulateSkyPaint )
            UI.Slider( "HDR scale", "", "hdrscale", 2, 0, 1, WorldEx.ModulateSkyPaint )

            UI.Checkbox( "Draw stars", "drawstars", nil, nil, nil, nil, nil, nil, nil, WorldEx.ModulateSkyPaint )

            UI.Slider( "Star layers", "", "starlayers", 0, 0, 3, WorldEx.ModulateSkyPaint )
            UI.Slider( "Star speed", "", "starspeed", 2, 0, 2, WorldEx.ModulateSkyPaint )
            UI.Slider( "Star scale", "", "starscale", 2, 0, 5, WorldEx.ModulateSkyPaint )
            UI.Slider( "Star fade", "", "starfade", 2, 0, 5, WorldEx.ModulateSkyPaint )

            UI.Slider( "Dusk int", "", "duskintensity", 2, 0, 10, WorldEx.ModulateSkyPaint )
            UI.Slider( "Dusk scale", "", "duskscale", 2, 0, 1, WorldEx.ModulateSkyPaint )

            UI.Spacer()

            UI.SeparateColorPicker( "Sun color", "suncolor", WorldEx.ModulateSkyPaint )
            UI.Slider( "Sun size", "", "sunsize", 2, 0, 10, WorldEx.ModulateSkyPaint )
        else
            UI.Checkbox( "Custom skybox", "CustomSkybox", nil, nil, nil, nil, nil, nil, nil, WorldEx.SetSkyboxTexture )
            UI.TextInput( "Skybox texture", "SkyTexture", 128, WorldEx.SetSkyboxTexture )
        end

        UI.Spacer()

        UI.Checkbox( "Fog changer", "FogChanger", true )
        UI.Slider( "Fog start", "", "FogStart", 0, 1, 4200 )
        UI.Slider( "Fog end", "", "FogEnd", 0, 1, 9000 )

        UI.EndThemeBox()

        UI.StartThemeBox( "Radar" )

        UI.Checkbox( "Show radar", "MinimapEnable" )
        UI.Checkbox( "Ortho view", "MinimapOrthoView" )
        UI.Slider( "Distance", "u", "MinimapDistance", 0, 512, 8184 )
        UI.Slider( "Scaling", "x", "MinimapScaling", 0, 1, 5 )

        UI.Spacer()

        UI.Checkbox( "Show players", "MinimapPlayers" )
        UI.Checkbox( "Show names", "MinimapNames" )
        UI.Checkbox( "Show avatar", "MinimapAvatars" )
        UI.Slider( "Avatar scale", "p", "MinimapPfpSize", 0, 6, 16 )

        UI.EndThemeBox()
    end,
    [ "Misc" ] = function()
        UI.StartThemeBox( "Movement" )
    
        UI.Checkbox( "Bunny hop", "BunnyHop" )
        UI.Slider( "Hop delay", "", "HopDelay", 0, 0, 16 )
        UI.Slider( "Max hops", "", "MaxHops", 0, 0, 6 )

        UI.Spacer()

        UI.Checkbox( "Air duck", "AutoLongjump" )
        UI.Checkbox( "Duck spam", "AirDuckSpam" )
        
        UI.Spacer()

        UI.Checkbox( "Edge Jump", "EdgeJump" )
        UI.SeparateBinder( "Edge key", 6 )

        UI.Spacer()

        UI.Checkbox( "Parkour assist", "AutoParkour" )
        UI.Checkbox( "Water float", "WaterFloat" )

        UI.Spacer()

        UI.Checkbox( "Auto strafe", "AirStrafer" )
        UI.ComboBox( "Auto strafe mode", "AirStraferMode", { "Rage", "Legit", "Multidir" } )
        UI.Checkbox( "Ground strafe", "GroundStrafe" )
        UI.Checkbox( "Fast stop", "FastStop" )

        UI.Spacer()

        UI.Checkbox( "Slow motion", "SlowMotion" )
        UI.Slider( "Slow motion time", "s", "SlowMotionTime", 2, 0, 0.5 )
        UI.Checkbox( "Slow walk", "SlowWalk" )
        UI.Slider( "Slow walk speed", "", "SlowWalkSpeed", 1, 1, 6 )
        UI.SeparateBinder( "Slow motion", 7 )
        UI.SeparateBinder( "Slow walk", 5 )

        UI.Spacer()

        UI.Checkbox( "Auto peek", "AutoPeek" )
        UI.Checkbox( "Teleport back", "AutoPeekTeleport" )
        UI.Checkbox( "Pull back", "AutoPeekPullback" )
        UI.SeparateBinder( "Peek key", 9 )

        UI.Spacer()

        UI.Checkbox( "Menu move", "MenuMove" )

        UI.EndThemeBox()

        UI.StartThemeBox( "Pathfinder" )

        UI.Checkbox( "PathFinder", "PathFinder" )
        UI.Checkbox( "Decreaseing mode", "PathFinderDec" )
       // UI.ComboBox( "Pathfinding mode", "PathFinderMode", { "Player follower", "Entity collector" } )
       // UI.Slider( "Range multiplier", "u", "PathFinderRange", 0, 1, 5 )
        UI.Slider( "Pathfinding delay", "s", "PathFinderDelay", 3, 0, 5 )
        UI.Slider( "Recalc delay", "s", "ForcedRecalc", 3, 0, 5 )

        UI.EndThemeBox()

        DrawEx.Context.x = UI.FrameX + 10 + UI.ThemeBoxW 
        DrawEx.Context.y = UI.FrameY + 30

        UI.StartThemeBox( "Funnies" )
    
        UI.Checkbox( "Use spam", "UseSpam" )
        UI.Checkbox( "Camera spam", "CameraSpam" )
        UI.Checkbox( "Flashlight spam", "FlashlightSpam" )
        UI.Checkbox( "Sex hacks", "AutoRape" )

        UI.Spacer()

        UI.Checkbox( "Vape spam", "VapeSpam" )
        UI.Checkbox( "Auto затяг", "AutoVape" )
        UI.Checkbox( "Взрывной чарик", "VapeTorch" )

        UI.Spacer()

        UI.Checkbox( "Rope spam", "RopeSpam" )
        UI.Checkbox( "Rope matz", "RopeMatz" )

        UI.Spacer()

        UI.Checkbox( "Hand job", "HandJob" )
        UI.ComboBox( "Hand mode", "HandJobMode", { "Up", "Parkinson", "Ultra cum" } )
        UI.Checkbox( "Taunt spam", "ActSpam" )
        UI.ComboBox( "Taunt mode", "ActSpamMode", Sublimity.DisplayTaunts )
        UI.Slider( "Taunt time", "s", "ActSpamTime", 0, 0, 3 )

        UI.Spacer()

        UI.Checkbox( "Fake frametime", "FakeFrames" )
        UI.Slider( "Multiply", "x", "FakeFramesAmt", 2, 0, 16 )

        UI.Spacer()
        
        UI.Checkbox( "View roll", "ViewRoll" )
        UI.ComboBox( "Roll mode", "ViewRollMode", { "Inverted", "Jittering", "Spin", "Sin" } )

        UI.Spacer()

        UI.Checkbox( "Fast lockpick", "FastLockpick" )
        UI.Slider( "Min time", "s", "PickTimeMin", 1, 10, 30 )

        UI.Spacer()

        UI.Checkbox( "Unter burner", "UnterBurner" )
        UI.SeparateBinder( "Burn key", 11 )

        UI.EndThemeBox()

        DrawEx.Context.x = UI.FrameX + 15 + UI.ThemeBoxW * 2
        DrawEx.Context.y = UI.FrameY + 30

        UI.StartThemeBox( "Chat / Messaging" )
    
        UI.Checkbox( "Chat spam", "ChatSpam" )
        UI.ComboBox( "Spam mode", "ChatMode", { "English Format", "Russian Format", "Trashtalk", "Quotes", "Random facts" } )
        UI.Slider( "Spam delay", "s", "ChatDelay", 0, 0, 20 )
        
        UI.Spacer()

        UI.Checkbox( "Kill say", "KillSay" )
        UI.ComboBox( "Kill say mode", "KillMode", { "English HvH", "Russian HvH", "English Format", "Russian Format", "Quotes" } )
   
        UI.Spacer()

        UI.Checkbox( "Death say", "DeathSay" )
        UI.ComboBox( "Death say mode", "DeathMode", { "Edgy", "CSGO Reportbot", "Trashtalk" } )

        UI.Spacer()

        UI.Checkbox( "Respond say", "RespondSay" )
        UI.ComboBox( "Respond mode", "RespondMode", { "Correction Eng", "Correction Rus" } )

        UI.Spacer()

        UI.Checkbox( "ULX spam", "UlxSpam" )
        UI.ComboBox( "Chat mode", "SendChannel", { "General", "Random PM", "Global", "Advert" } )

        UI.EndThemeBox()

        UI.StartThemeBox( "Net channel" )

        UI.Checkbox( "Name stealer", "NameStealer" )
 
        UI.Spacer()

        UI.Checkbox( "Server lagger", "ServerLagger" )
        UI.ComboBox( "Lagger mode", "LaggerMode", { "File", "Client Msg", "Net Packets", "Advanced", "Combined", "Meta" } )
        UI.Slider( "Lagger multiplier", "x", "LaggerForce", 0, 1, 50 )

        UI.Spacer()

        UI.Checkbox( "Sequence manipulation", "SeqManip" )
        UI.ComboBox( "Sequence mode", "SeqManipMode", { "Custom", "Anim Frezzer", "Air stuck", "Speed hack", "Ultra fuckery", "Multi fire" } )
        UI.Slider( "Sequence value", "", "SeqManipAmt", 0, 1, 5000 )
        UI.Slider( "Speed hack", "", "SeqManipSpeedhack", 0, 1, 29 )
        UI.SeparateBinder( "Seq key", 8 )

        UI.EndThemeBox()
    end,
    [ "Settings" ] = function()

    end,
    [ "Lists" ] = function()
        UI.StartThemeBox( "Entities" )

        for i = 1, #UI.EntityList do
            UI.ListEntity( UI.EntityList[ i ] )
        end

        UI.EndThemeBox()
    end,
}

function UI.GradientBar( Tbl, Num )
    surface_SetDrawColor( Num == 1 and 255 or 0, Num == 2 and 255 or 0, Num == 3 and 255 or 0 )
    surface_DrawRect( DrawEx.Context.x, DrawEx.Context.y, 234, 12 )

    surface_SetDrawColor( 255, 255, 255, 96 )
    DrawEx.DrawTexture( "vgui/gradient-r", DrawEx.Context.x + ( 234 / 2 ), DrawEx.Context.y, 234 / 2, 12 )

    surface_SetDrawColor( 0, 0, 0 )
    DrawEx.DrawTexture( "vgui/gradient-l", DrawEx.Context.x, DrawEx.Context.y, 234 / 2, 12 )

    UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, 234, 12 )
    if InputEx.KeysDown[ MOUSE_LEFT ] and UI.CursorInArea then
        Tbl[ Num ] = math_Round( ( ( UI.CursorX - DrawEx.Context.x ) / ( DrawEx.Context.x + 234 - DrawEx.Context.x ) ) * ( 255 ), 0 )
        Tbl[ Num ] = math_Clamp( Tbl[ Num ], 0, 255 )

        if UI.PickerFunc then UI.PickerFunc() end
    end

    surface_SetDrawColor( 255, 255, 255 )
    surface_DrawOutlinedRect( DrawEx.Context.x - 1 + Tbl[ Num ] / 255 * 234, DrawEx.Context.y, 3, 12 )

    DrawEx.Context.y = DrawEx.Context.y + 16
end

local matBlurScreen = Material( "pp/blurscreen" )
function UI.DrawMenu()
    if not UI.FrameVisible then return end 
    
    local Context = DrawEx.Context
    Context.g = 0

    UI.CursorHover = false
    UI.CursorInArea = false

    render_SetScissorRect( UI.FrameX, UI.FrameY,  UI.FrameX + UI.FrameW, UI.FrameY + UI.FrameH, true )

    DrawEx.SetColor( Settings.Menu.Background )
    surface_DrawRect( UI.FrameX, UI.FrameY, UI.FrameW, UI.FrameH )

    DrawEx.SetColor( Settings.Menu.Outline )
    surface_DrawOutlinedRect( UI.FrameX, UI.FrameY, UI.FrameW, UI.FrameH )
    surface_DrawRect( UI.FrameX + 5, UI.FrameY + 25, UI.FrameW - 11, 1 )

    DrawEx.SetFont( "TabFont" )

    local TabX = 5 
    for i = 1, #UI.Tabs do
        local str = UI.Tabs[ i ]

        Context.x = UI.FrameX + TabX
        Context.y = UI.FrameY + 5
        Context.w = UI.TabSize
        Context.h = 20 

        UI.CursorInArea = UI.CursorInRect( Context.x, Context.y, Context.w, Context.h )
        
        DrawEx.SetColor( UI.CurrentTab == str and Settings.Menu.Active or UI.CursorInArea and Settings.Menu.Hovered or Settings.Menu.Normal )
        surface_DrawRect( Context.x, Context.y, Context.w, Context.h )

        local tw, th = surface_GetTextSize( str )

        DrawEx.SetTextColor( UI.CurrentTab == str and Settings.Menu.TextActive or UI.CursorInArea and Settings.Menu.TextHovered or Settings.Menu.TextNormal )
        surface_SetTextPos( Context.x + Context.w / 2 - tw / 2, Context.y + Context.h / 2 - th / 2 )
        surface_DrawText( str )

        if UI.CursorInArea then
            UI.CursorHover = true

            if InputEx.KeysPressed[ MOUSE_LEFT ] then
                UI.CurrentTab = str
            end
        end

        TabX = TabX + 3 + UI.TabSize 
    end

    DrawEx.SetFont( "MenuFont" )

    Context.x = UI.FrameX + 5
    Context.y = UI.FrameY + 30

    UI.TabFuncs[ UI.CurrentTab ]()

    render_SetScissorRect( 0, 0, 0, 0, false )

    local cx, cy = input_GetCursorPos()

    UI.HoveringSubframe = false 

    if UI.ComboPanel then
        DrawEx.SetColor( Settings.Menu.Background )
        surface_DrawRect( UI.ComboX, UI.ComboY, UI.ThemeBoxW - 9, #UI.ComboVars * 20 )
    
        DrawEx.SetColor( Settings.Menu.Outline )
        surface_DrawOutlinedRect( UI.ComboX, UI.ComboY, UI.ThemeBoxW - 9, #UI.ComboVars * 20 )
        
        for i = 1, #UI.ComboVars do
            DrawEx.SetTextColor( ( UI.MultiCombo and Settings.Vars[ UI.ComboPanel .. UI.ComboVars[i] ] or Settings.Vars[ UI.ComboPanel ] == i ) and Settings.Menu.TextActive or Settings.Menu.TextNormal )
            surface_SetTextPos( UI.ComboX + 4, UI.ComboY - 18 + i * 20 )
            surface_DrawText( UI.ComboVars[ i ] )

            UI.CursorInArea = UI.CursorInRect( UI.ComboX, UI.ComboY - 20 + i * 20, UI.ThemeBoxW - 9, 20 ) 

            if UI.CursorInArea and InputEx.KeysPressed[ MOUSE_LEFT ] then
                if UI.MultiCombo then
                    Settings.Vars[ UI.ComboPanel .. UI.ComboVars[i] ] = not Settings.Vars[ UI.ComboPanel .. UI.ComboVars[i] ]
                else
                    Settings.Vars[ UI.ComboPanel ] = i
                    UI.ComboPanel = false
                end
            end 
        end

        UI.CursorInArea = UI.CursorInRect( UI.ComboX, UI.ComboY - 16, UI.ThemeBoxW - 9, #UI.ComboVars * 20 + 32 )
        UI.HoveringSubframe = UI.CursorInArea

        if ( InputEx.KeysDown[ MOUSE_LEFT ] and not UI.CursorInArea ) or ( UI.FrameX != UI.OldFrameX or UI.FrameY != UI.OldFrameY ) then
            UI.ComboPanel = false
        end
    end

    if UI.EditingText then
        UI.CursorInArea = UI.CursorInRect( UI.EditorX, UI.EditorY - 16, UI.ThemeBoxW - 33, 20 )
      
        if ( InputEx.KeysDown[ MOUSE_LEFT ] and not UI.CursorInArea ) or ( UI.FrameX != UI.OldFrameX or UI.FrameY != UI.OldFrameY ) then
            UI.EditingText = false
        end
    end

    if UI.ColorPicker then
        local Tbl = Settings.Colors[ UI.ColorPicker ]

        DrawEx.SetColor( Settings.Menu.Background )
        surface_DrawRect( UI.PickerX, UI.PickerY, 300, 98 )
    
        DrawEx.SetColor( Settings.Menu.Outline )
        surface_DrawOutlinedRect( UI.PickerX, UI.PickerY, 300, 98 )

        DrawEx.SetColor( Tbl )
        surface_DrawRect( UI.PickerX + 6, UI.PickerY + 6, 48, 24 )

        surface_SetDrawColor( ColorEx.Complementary( Tbl ) )
        surface_DrawRect( UI.PickerX + 6, UI.PickerY + 30, 48, 24 )

        UI.CursorInArea = UI.CursorInRect( UI.PickerX + 6, UI.PickerY + 30, 48, 24 )
        
        if InputEx.KeysPressed[ MOUSE_LEFT ] and UI.CursorInArea then
            Tbl[ 1 ], Tbl[ 2 ], Tbl[ 3 ] = ColorEx.Complementary( Tbl )
            if UI.PickerFunc then UI.PickerFunc() end
        end

        DrawEx.SetColor( Settings.Menu.Outline )
        DrawEx.SetTextColor( Settings.Menu.TextNormal )

        surface_DrawOutlinedRect( UI.PickerX + 6, UI.PickerY + 58, 48, 16 )
        surface_SetTextPos( UI.PickerX + 13, UI.PickerY + 58 )
        surface_DrawText( "Copy" )

        UI.CursorInArea = UI.CursorInRect( UI.PickerX + 6, UI.PickerY + 58, 48, 16 )
        if InputEx.KeysPressed[ MOUSE_LEFT ] and UI.CursorInArea then
            SetClipboardText( ColorEx.RgbToHex( Tbl[ 1 ], Tbl[ 2 ], Tbl[ 3 ] ) )

            if UI.PickerFunc then UI.PickerFunc() end
        end

        surface_DrawOutlinedRect( UI.PickerX + 6, UI.PickerY + 76, 48, 16 )
        surface_SetTextPos( UI.PickerX + 12, UI.PickerY + 76 )
        surface_DrawText( "Paste" )

        UI.CursorInArea = UI.CursorInRect( UI.PickerX + 6, UI.PickerY + 76, 48, 16  )
        if InputEx.KeysPressed[ MOUSE_LEFT ] and UI.CursorInArea and ded.GetClipboardText() then
            local hexr, hexg, hexb = ColorEx.HexToRgb( ded.GetClipboardText() )

            if hexr and hexg and hexb then
                Tbl[ 1 ], Tbl[ 2 ], Tbl[ 3 ] = hexr, hexg, hexb
            end

            if UI.PickerFunc then UI.PickerFunc() end
        end

        DrawEx.Context.x = UI.PickerX + 60
        DrawEx.Context.y = UI.PickerY + 6

        surface_SetDrawColor( 255, 255, 255 )
        DrawEx.DrawTexture( "gui/alpha_grid.png", DrawEx.Context.x, DrawEx.Context.y, 234, 16 )
        surface_SetDrawColor( Tbl[ 1 ], Tbl[ 2 ], Tbl[ 3 ] )
        DrawEx.DrawTexture( "vgui/gradient-r", DrawEx.Context.x, DrawEx.Context.y, 234, 16 )

        UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, 234, 16 )
        if InputEx.KeysDown[ MOUSE_LEFT ] and UI.CursorInArea then
            Tbl[ 4 ] = math_Round( ( ( UI.CursorX - DrawEx.Context.x ) / ( DrawEx.Context.x + 234 - DrawEx.Context.x ) ) * ( 255 ), 0 )
            Tbl[ 4 ] = math_Clamp( Tbl[ 4 ], 0, 255 )

            if UI.PickerFunc then UI.PickerFunc() end
        end

        surface_SetDrawColor( 255, 255, 255 )
        surface_DrawOutlinedRect( DrawEx.Context.x - 1 + Tbl[ 4 ] / 255 * 234, DrawEx.Context.y, 3, 16 )

        DrawEx.Context.y = DrawEx.Context.y + 20

        UI.GradientBar( Tbl, 1 )
        UI.GradientBar( Tbl, 2 )
        UI.GradientBar( Tbl, 3 )

        surface_SetDrawColor( 255, 255, 255 )
        surface_SetMaterial( DrawEx.MaterialData[ "gui/colors.png" ] )
        surface_lib.DrawTexturedRectRotated( DrawEx.Context.x + 117, DrawEx.Context.y + 9, 17, 234, 270 )

        UI.CursorInArea = UI.CursorInRect( DrawEx.Context.x, DrawEx.Context.y, 234, 17 )

        if InputEx.KeysDown[ MOUSE_LEFT ] and UI.CursorInArea then
            local Len = math_Round( ( ( UI.CursorX - DrawEx.Context.x ) / ( DrawEx.Context.x + 234 - DrawEx.Context.x ) ) * ( 255 ), 0 )
            local HSV = HSVToColor( Len * 1.53, 1, 1 )

            Tbl[ 1 ] = math_Clamp( HSV.r, 0, 255 )
            Tbl[ 2 ] = math_Clamp( HSV.g, 0, 255 )
            Tbl[ 3 ] = math_Clamp( HSV.b, 0, 255 )
            
            if UI.PickerFunc then UI.PickerFunc() end
        end 

        UI.CursorInArea = UI.CursorInRect( UI.PickerX, UI.PickerY, 300, 98 )
        UI.HoveringSubframe = UI.CursorInArea

        if ( InputEx.KeysDown[ MOUSE_LEFT ] and not UI.CursorInArea ) or ( UI.FrameX != UI.OldFrameX or UI.FrameY != UI.OldFrameY ) then
            UI.ColorPicker = false
        end
    end

    if not UI.CursorHover and not UI.HoveringSubframe and InputEx.KeysDown[ MOUSE_LEFT ] and UI.CursorInRect( UI.FrameX, UI.FrameY, UI.FrameW, UI.FrameH ) then
        UI.FrameX = UI.FrameX + ( cx - UI.CursorX )
        UI.FrameY = UI.FrameY + ( cy - UI.CursorY ) 
    end

    UI.OldFrameX = UI.FrameX 
    UI.OldFrameY = UI.FrameY  
    UI.CursorX, UI.CursorY = cx, cy 
end

// Player visuals 
 

Sublimity.Bounds = {}

function Sublimity.GetEntityBounds( EntTable )
    local Pos = EntTable.Ent:GetPos()
    local Maxs = EntTable.OBBMaxs
    local Mins = EntTable.OBBMins

    Sublimity.Bounds = {
        ( Pos + Vec( Maxs.x, Maxs.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Maxs.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Mins.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Maxs.x, Mins.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Mins.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Mins.y, Maxs.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Maxs.y, Mins.z ) ):ToScreen(),
        ( Pos + Vec( Mins.x, Maxs.y, Maxs.z ) ):ToScreen(),
    }

    local MaxX, MaxY, MinX, MinY 
    local Vis = false 

    for i = 1, #Sublimity.Bounds do
        local ScreenPoint = Sublimity.Bounds[ i ]
        Vis = ScreenPoint.visible

        if MaxX == nil then
            MaxX = ScreenPoint.x 
            MaxY = ScreenPoint.y
            MinX = ScreenPoint.x
            MinY = ScreenPoint.y

            continue 
        end

        MaxX = math_Max( MaxX, ScreenPoint.x ) 
        MaxY = math_Max( MaxY, ScreenPoint.y ) 
        MinX = math_Min( MinX, ScreenPoint.x )
        MinY = math_Min( MinY, ScreenPoint.y )
    end

    return math_Ceil( MaxX ), math_Ceil( MaxY ), math_Floor( MinX ), math_Floor( MinY ), Vis
end

function Sublimity.DrawPlayerVisuals()
    if #PlayerList == 0 then return end 

    local MaxPlayerDistance = Settings.Vars.MaxDistance
    MaxPlayerDistance = MaxPlayerDistance * MaxPlayerDistance
    local CachedVars, UpdatedVars, Recaching 

    DrawEx.SetFont( "Veranda" )

    local BarPos 
    local BarX, BarY
    local BarW, BarH 
    local FillW, FillH 
    local SequenceID = 1
    local Reloading = false

    for i = 1, #PlayerList do
        UpdatedVars = PlayerList[ i ]
        CachedVars  = EntEx.PlayerCache[ UpdatedVars.Ent ]
        Recaching   = EntEx.PlayerData[ UpdatedVars.Ent ]

        surface_SetAlphaMultiplier( UpdatedVars.IsDormant and 0.35 or 1 )

        if not UpdatedVars.Alive then continue end

        DrawEx.Context.MaxX, DrawEx.Context.MaxY, DrawEx.Context.MinX, DrawEx.Context.MinY, DrawEx.Context.Vis = Sublimity.GetEntityBounds( UpdatedVars )

        if not DrawEx.Context.Vis then continue end
        if LocalEx.Origin:DistToSqr( UpdatedVars.Origin ) > MaxPlayerDistance then continue end

        DrawEx.Context.Width  = math_Floor( DrawEx.Context.MaxX - DrawEx.Context.MinX )
        DrawEx.Context.Height = math_Floor( DrawEx.Context.MaxY - DrawEx.Context.MinY )
        
        DrawEx.DrawnText  = { 0, 0, 0, 0 }
        DrawEx.DrawnBars = { { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 }, { x = 0, y = 0 } }

        DrawEx.StartPos = { 
            DrawEx.Context.MinX + DrawEx.Context.Width / 2, 
            DrawEx.Context.MinX + DrawEx.Context.Width / 2, 
            DrawEx.Context.MaxX + 5, 
            DrawEx.Context.MinX - 5 
        }

        DrawEx.BarPoses = {
            { x = DrawEx.Context.MinX, y = DrawEx.Context.MinY - 6 },
            { x = DrawEx.Context.MinX, y = DrawEx.Context.MaxY + 1 }, 
            { x = DrawEx.Context.MaxX + 1, y = DrawEx.Context.MinY }, 
            { x = DrawEx.Context.MinX - 6, y = DrawEx.Context.MinY }
        }

        if Settings.Vars.SightLines then 
            local EyeTrace = UpdatedVars.Ent:GetEyeTrace()
            local StartPos, HitPos = EyeTrace.StartPos:ToScreen(), EyeTrace.HitPos:ToScreen()

            surface_SetDrawColor( Recaching.TeamColor )
            surface_DrawLine( StartPos.x, StartPos.y, HitPos.x, HitPos.y )
        end

        if Settings.Vars.SkeletonEsp then
            DrawEx.SetColor( Settings.Colors.SkeletonEsp )

		    for BoneId = 0, UpdatedVars.Ent:GetBoneCount() - 1 do
			    local Parent = UpdatedVars.Ent:GetBoneParent( BoneId )
			    if not Parent then continue end

			    local ChildPos = UpdatedVars.Ent:GetBonePosition( BoneId )
			    if ChildPos == UpdatedVars.Ent:GetPos() then continue end

			    local ParentPos = UpdatedVars.Ent:GetBonePosition( Parent )
			    if not ChildPos or not ParentPos then continue end

			    local ChildScreenPos    = ChildPos:ToScreen()
                local ParentScreenPos   = ParentPos:ToScreen()

			    surface_DrawLine( ChildScreenPos.x, ChildScreenPos.y, ParentScreenPos.x, ParentScreenPos.y )
		    end
        end

        surface_SetMaterial( DrawEx.MaterialData[ "vgui/gradient-d" ] ) 

        if Settings.Vars.FilledBox then 
            DrawEx.SetColor( Settings.Colors.FilledBox )    

            if Settings.Vars.FilledGradient then
                surface_DrawTexturedRect( DrawEx.Context.MinX, DrawEx.Context.MinY, DrawEx.Context.Width, DrawEx.Context.Height )
            else
                surface_DrawRect( DrawEx.Context.MinX, DrawEx.Context.MinY, DrawEx.Context.Width, DrawEx.Context.Height )
            end
        end
 
        if Settings.Vars.BoxEsp then  
            DrawEx.SetColor( Settings.Colors.BoxBg )
            surface_DrawOutlinedRect( DrawEx.Context.MinX, DrawEx.Context.MinY, DrawEx.Context.Width, DrawEx.Context.Height, 3 )
        
            if Settings.Vars.BoxTeamColor then
                surface_SetDrawColor( Recaching.TeamColor )
            else
                DrawEx.SetColor( Settings.Colors.BoxEsp )
            end
            
            surface_DrawOutlinedRect( DrawEx.Context.MinX + 1, DrawEx.Context.MinY + 1, DrawEx.Context.Width - 2, DrawEx.Context.Height - 2 )
        
            if Settings.Vars.BoxGradient then
                DrawEx.SetColor( Settings.Colors.BoxGradient ) 

                surface_DrawTexturedRect( DrawEx.Context.MinX + 1, DrawEx.Context.MinY, 1, DrawEx.Context.Height - 1 )
                surface_DrawTexturedRect( DrawEx.Context.MaxX - 2, DrawEx.Context.MinY, 1, DrawEx.Context.Height - 1 )
                surface_DrawRect( DrawEx.Context.MinX + 1, DrawEx.Context.MaxY - 2, DrawEx.Context.Width - 2, 1 )
            end
        end 

        /*

        if Settings.Vars.HealthBar then
            Cat.DrawBar( Settings.Vars.HealthBarPos, UpdatedVars.Health, UpdatedVars.MaxHealth, Cat.Cfg.Colors.HealthBar, Cat.Cfg.Colors.HealthBarBg, Settings.Vars.HealthBarGradient, Cat.Cfg.Colors.HealthBarGr )
        end

        if Settings.Vars.ArmorBar and UpdatedVars.Armor > 0 then
            Cat.DrawBar( Settings.Vars.ArmorBarPos, UpdatedVars.Armor, UpdatedVars.MaxArmor, Cat.Cfg.Colors.ArmorBar, Cat.Cfg.Colors.ArmorBarBg, Settings.Vars.ArmorBarGradient, Cat.Cfg.Colors.ArmorBarGr )
        end

        if Settings.Vars.WeaponReload then
            for Layer = 0, 13 do
                if not UpdatedVars.Ent:IsValidLayer( Layer ) then continue end 
                SequenceID = UpdatedVars.Ent:GetLayerSequence( Layer ) 
                if not UpdatedVars.Ent:GetSequenceActivityName( SequenceID ):find( "RELOAD" ) then continue end 
                      
                if UpdatedVars.Ent.StartedReloading == 0 then
                    UpdatedVars.Ent.StartedReloading = Cat.CurrentTime
                end

                Reloading = true 
                break
            end

            if not Reloading and UpdatedVars.Ent.StartedReloading > 0 then
                UpdatedVars.Ent.StartedReloading = 0
            end
        end
        
        if UpdatedVars.Ent.StartedReloading > 0 and Settings.Vars.ReloadingBar then
            Cat.DrawBar( 2, ( Cat.CurrentTime - UpdatedVars.Ent.StartedReloading ), UpdatedVars.Ent:SequenceDuration( SequenceID ), Cat.Cfg.Colors.ReloadingBar, Cat.Cfg.Colors.ReloadingBarBg, Settings.Vars.ReloadingGradient, Cat.Cfg.Colors.ReloadingBarGr )
        end 

        surface_SetTextColor( Cat.Colors.White )
           
        Cat.EspText( Settings.Vars.NameEsp, Settings.Vars.SteamName and CachedVars.RealName or Recaching.Name, Settings.Vars.NamePos, Recaching.SteamFriend and Cat.Cfg.Colors.FriendName or Cat.Cfg.Colors.PlayerName )

        if Settings.Vars.AvatarImage then
            CachedVars.AvatarImage:SetPos( DrawEx.Context.TextX - 14, DrawEx.Context.TextY + 1 )
            CachedVars.AvatarImage:PaintManual()
        end
   
        Cat.EspText( Settings.Vars.UsergroupEsp, Recaching.UserGroup, Settings.Vars.UsergroupPos, ( Recaching.IsAdmin and Settings.Vars.HighlightAdmins ) and Cat.Cfg.Colors.AdminHighlight or Cat.Cfg.Colors.Usergroup )
        Cat.EspText( Settings.Vars.HealthEsp, UpdatedVars.Health, Settings.Vars.HealthPos, Cat.Cfg.Colors.Health )
        Cat.EspText( Settings.Vars.ArmorEsp, UpdatedVars.Armor, Settings.Vars.ArmorPos, Cat.Cfg.Colors.Armor )
        Cat.EspText( Settings.Vars.WeaponEsp, Settings.Vars.WeaponPrintName and UpdatedVars.WeaponName or UpdatedVars.WeaponClass, Settings.Vars.WeaponPos, Cat.Cfg.Colors.Weapon )
        Cat.EspText( Reloading, "RELOADING!", Settings.Vars.WeaponPos, Cat.Cfg.Colors.Weapon )
        Cat.EspText( Settings.Vars.TeamEsp, Recaching.TeamName, Settings.Vars.TeamPos, Recaching.TeamColor )
        Cat.EspText( Settings.Vars.MoneyEsp and Recaching.Money, Recaching.Money, Settings.Vars.MoneyPos, Cat.Colors.Money )
        Cat.EspText( Settings.Vars.LagcompIndicator, "LAGCOMP", Settings.Vars.PacketPos, UpdatedVars.BreakingLC and Cat.Cfg.Colors.BrokenLC or Cat.Cfg.Colors.PacketSent )
        Cat.EspText( Settings.Vars.PacketIndicator, UpdatedVars.PacketSent and "Packet sent" or "Laggin " .. UpdatedVars.ChokedPackets, Settings.Vars.PacketPos, UpdatedVars.PacketSent and Cat.Cfg.Colors.PacketSent or Cat.Cfg.Colors.BrokenLC )
        Cat.EspText( Settings.Vars.TauntFlag and UpdatedVars.Ent:IsPlayingTaunt(), "Taunting", Settings.Vars.FlagsPos, Cat.Colors.White )
        Cat.EspText( Settings.Vars.NoclipFlag and UpdatedVars.MoveType == MOVETYPE_NOCLIP, "NOCLIP", Settings.Vars.FlagsPos, Cat.Colors.White )
        Cat.EspText( Settings.Vars.FrozenFlag and QuickBand( UpdatedVars.Flags, FL_FROZEN ), "FROZEN", Settings.Vars.FlagsPos, Cat.Colors.Ice )
        Cat.EspText( Settings.Vars.WantedFlag and Recaching.Wanted, "WANTED", Settings.Vars.FlagsPos, Cat.Colors.Arrest )
 





*/
    end

    CachedVars, UpdatedVars, Recaching = nil, nil, nil 

    surface_SetAlphaMultiplier( 1 )
end










// Overlay 
Sublimity.UpVector = Vec( 0, 0, 1024 )
Sublimity.RadarX = 15 
Sublimity.RadarY = 15 
Sublimity.RadarScale = 256
Sublimity.OldX = 0 
Sublimity.OldY = 0

function Sublimity.DrawOverlay()
    Sublimity.DrawPlayerVisuals()

    if Settings.Vars.MinimapEnable then
        local RX, RY, RS = Sublimity.RadarX, Sublimity.RadarY, Sublimity.RadarScale
        local RCX, RCY = RX + RS / 2, RY + RS / 2
        local Distance, Scaling = Settings.Vars.MinimapDistance, Settings.Vars.MinimapScaling
        Sublimity.UpVector.z = Distance

        ViewEx.RenderViewData.angles.y = ViewEx.Angles.y
        ViewEx.RenderViewData.origin = LocalEx.Origin + ( Sublimity.UpVector * Scaling )
        ViewEx.RenderViewData.ortho = { left = -Distance * Scaling, right = Distance * Scaling, top = -Distance * Scaling, bottom = Distance * Scaling  }

        if Settings.Vars.MinimapOrthoView then 
            render_RenderView( ViewEx.RenderViewData )
        else
            DrawEx.SetColor( Settings.Menu.Background )
            surface_DrawRect( RX, RY, RS, RS )
        end

        render_SetScissorRect( RX, RY, RX + RS, RY + RS, true )

        DrawEx.SetFont( "Veranda" ) 

        if Settings.Vars.MinimapPlayers then
            local UpdatedVars, CachedVars, Recaching

            if #PlayerList > 0 then
                for i = 1, #PlayerList do
                    UpdatedVars = PlayerList[ i ]
                    CachedVars  = EntEx.PlayerCache[ UpdatedVars.Ent ]
                    Recaching   = EntEx.PlayerData[ UpdatedVars.Ent ]

                    if not UpdatedVars.Alive then continue end

                    local diff = UpdatedVars.Origin - LocalEx.Origin
                    local dist = diff:Length() / Scaling
                    local ang = diff:Angle()
                    ang.y = ( ViewEx.Angles.y - 90 ) - ang.y

                    ang:Normalize()

                    local pos = ( ang:Forward() * dist ) / ( Distance * Scaling )

                    if pos:Length2D() > 1 then continue end

                    if Settings.Vars.MinimapAvatars then
                        CachedVars.AvatarImage:SetSize( Settings.Vars.MinimapPfpSize, Settings.Vars.MinimapPfpSize )
                        CachedVars.AvatarImage:SetPos( RCX + ( pos.x * RS ) - Settings.Vars.MinimapPfpSize / 2, RCY + ( pos.y * RS ) - Settings.Vars.MinimapPfpSize / 2 )
                        CachedVars.AvatarImage:PaintManual()
                    end
 
                    if Settings.Vars.MinimapNames then
                        surface_SetTextColor( Recaching.TeamColor )
                        local tw, th = DrawEx.GetTextSize( CachedVars.RealName )
                        DrawEx.DrawText( CachedVars.RealName, RCX + ( pos.x * RS ) - ( tw / 2 ), Settings.Vars.MinimapAvatars and RCY + ( pos.y * RS ) + Settings.Vars.MinimapPfpSize / 2 or RCY + ( pos.y * RS ) )
                    end
                end
            end
        end

        render_SetScissorRect( 0, 0, 0, 0, false )

        surface_SetAlphaMultiplier( 0.25 )

        DrawEx.SetColor( Settings.Menu.Outline )

        surface_DrawCircle( RCX, RCY, RS / 2 )

        surface_DrawLine( RCX, RY, RCX, RY + RS )
        surface_DrawLine( RX, RCY, RX + RS, RCY ) 

        surface_SetAlphaMultiplier( 1 )

        DrawEx.SetColor( Settings.Menu.Outline )
        surface_DrawOutlinedRect( RX, RY, RS, RS )

        surface_SetTextColor( 128, 128, 128 )

        if UI.FrameVisible then
            local cx, cy = input_GetCursorPos()
            local Disabler = UI.CursorHover or UI.HoveringSubframe or not InputEx.KeysDown[ MOUSE_LEFT ] or UI.CursorInRect( UI.FrameX, UI.FrameY, UI.FrameW, UI.FrameH )

            surface_DrawRect( RX, RY, 16, 16 )
            surface_DrawRect( RX + RS - 16, RY + RS - 16, 16, 16 )

            UI.CursorInArea = UI.CursorInRect( RX, RY, 16, 16 )

            DrawEx.SetTextColor( UI.CursorInArea and Settings.Menu.TextHovered or Settings.Menu.TextNormal )
            DrawEx.DrawText( "P", RX + 4, RY + 2 )

            if UI.CursorInArea and not Disabler then
                Sublimity.RadarX = Sublimity.RadarX + ( cx - Sublimity.OldX )
                Sublimity.RadarY = Sublimity.RadarY + ( cy - Sublimity.OldY ) 

                ViewEx.RenderViewData.x = Sublimity.RadarX
                ViewEx.RenderViewData.y = Sublimity.RadarY
            end

            UI.CursorInArea = UI.CursorInRect( RX + RS - 16, RY + RS - 16, 16, 16 )

            DrawEx.SetTextColor( UI.CursorInArea and Settings.Menu.TextHovered or Settings.Menu.TextNormal )
            DrawEx.DrawText( "S", RX + RS - 12, RY + RS - 14 )

            if UI.CursorInArea and not Disabler then
                Sublimity.RadarScale = Sublimity.RadarScale + ( cx - Sublimity.OldX )
                Sublimity.RadarScale = Sublimity.RadarScale + ( cy - Sublimity.OldY ) 

                ViewEx.RenderViewData.w = Sublimity.RadarScale
                ViewEx.RenderViewData.h = Sublimity.RadarScale
            end

            Sublimity.OldX, Sublimity.OldY = cx, cy 
        end
    end

    


    UI.DrawMenu()
end

// Multi pack support
local WeaponsEx = {}

WeaponsEx[""] = {}

// Hitbox selection 
Sublimity.ParsedBones   = {}
Sublimity.HitBoxData    = { [ HITGROUP_HEAD ] = { damage = 3, scale = 1, safety = 1 }, [ HITGROUP_CHEST ] = { damage = 2, scale = 3, safety = 2 }, [ HITGROUP_STOMACH ] = { damage = 2, scale = 2, safety = 3 }, [ HITGROUP_LEFTARM ] = { damage = 1, scale = 1, safety = 1 }, [ HITGROUP_RIGHTARM ] = { damage = 1, scale = 1, safety = 1 }, [ HITGROUP_LEFTLEG ] = { damage = 1, scale = 1, safety = 1 }, [ HITGROUP_RIGHTLEG ] = { damage = 1, scale = 1, safety = 1 } }
Sublimity.HitBoxSorting = { function( a, b ) return a.DamageRank > b.DamageRank end, function( a, b ) return a.ScaleRank > b.ScaleRank end, function( a, b ) return a.SafetyRank > b.SafetyRank end }

function Sublimity.ParsePlayerBones( EntTable )
    if Sublimity.ParsedBones[ EntTable.Model ] then
        return Sublimity.ParsedBones[ EntTable.Model ]
    end

    Sublimity.ParsedBones[ EntTable.Model ] = {}

    for i = 0, EntTable.Ent:GetBoneCount() - 1 do
        local HitBoxGroup = EntTable.Ent:GetHitBoxHitGroup( i, EntTable.Ent:GetHitboxSet() )

        if HitBoxGroup == nil or not Sublimity.HitBoxData[ HitBoxGroup ] then continue end

        Sublimity.ParsedBones[ EntTable.Model ][ #Sublimity.ParsedBones[ EntTable.Model ] + 1 ] = {
            Index = i,
            Group = HitBoxGroup,
            DamageRank = Sublimity.HitBoxData[ HitBoxGroup ].damage,
            ScaleRank = Sublimity.HitBoxData[ HitBoxGroup ].scale,
            SafetyRank = Sublimity.HitBoxData[ HitBoxGroup ].safety,
        }
    end

    return Sublimity.ParsedBones[ EntTable.Model ]
end 
             
Sublimity.Points = { Vec(), Vec(), Vec(), Vec(), Vec(), Vec(), Vec(), Vec(), Vec() }
function Sublimity.GetHitBoxBounds( Mins, Maxs, Pos, Ang )
    Sublimity.Points = {
        ( ( Mins + Maxs ) * 0.5 ),
        Vec( Mins.x, Mins.y, Mins.z ),
        Vec( Mins.x, Maxs.y, Mins.z ),
        Vec( Maxs.x, Maxs.y, Mins.z ),
        Vec( Maxs.x, Mins.y, Mins.z ),
        Vec( Maxs.x, Maxs.y, Maxs.z ),
        Vec( Mins.x, Maxs.y, Maxs.z ),
        Vec( Mins.x, Mins.y, Maxs.z ),
        Vec( Maxs.x, Mins.y, Maxs.z )
    }

    for i = 1, #Sublimity.Points do
        Sublimity.Points[ i ]:Rotate( Ang )
        Sublimity.Points[ i ] = Sublimity.Points[ i ] + Pos

        if i == 1 then continue end 

        Sublimity.Points[ i ] = ( ( Sublimity.Points[ i ] - Sublimity.Points[ 1 ] ) * Settings.Vars.MultipointScale ) + Sublimity.Points[ 1 ]
    end

    return Sublimity.Points
end

function Sublimity.GetAimPosition( EntTable )
    local BoneTable = Sublimity.ParsePlayerBones( EntTable )
    local BackUpPos = EntTable.OBBCenter
    local HitboxSet = EntTable.Ent:GetHitboxSet()

    if Settings.Vars.HitScan then
        local SortedBones = {}
        local BonePositions = {}

        for i = 1, #BoneTable do
            local Group = BoneTable[ i ].Group 

            if not Settings.Vars.HitboxHead and Group == 1 then continue end           
            if not Settings.Vars.HitboxChest and Group == 2 then continue end                
            if not Settings.Vars.HitboxStomach and Group == 3 then continue end                 
            if not Settings.Vars.HitboxLegs and Group == 6 or Group == 7 then continue end                   
            if not Settings.Vars.HitboxArms and Group == 4 or Group == 5 then continue end 

            SortedBones[ #SortedBones + 1 ] = BoneTable[ i ]
        end

        if #SortedBones == 0 then return { BackUpPos } end 

        table_sort( SortedBones, Sublimity.HitBoxSorting[ Settings.Vars.HitboxPriority ] )

        for i = 1, #SortedBones do
            local Index = SortedBones[ i ].Index
            local HitBoxBone = EntTable.Ent:GetHitBoxBone( Index, HitboxSet )
            if HitBoxBone == nil then continue end

            local BoneMins, BoneMaxs = EntTable.Ent:GetHitBoxBounds( Index, HitboxSet )
            if not BoneMins or not BoneMaxs then return { BackUpPos } end
            
            local BonePos, BoneAng = EntTable.Ent:GetBonePosition( HitBoxBone ) 

            if Settings.Vars.Multipoints then
                local Points = Sublimity.GetHitBoxBounds( BoneMins, BoneMaxs, BonePos, BoneAng )

                for MPs = 1, #Points do
                    BonePositions[ #BonePositions + 1 ] = Points[ MPs ]
                end
            else
                BoneMins:Rotate( BoneAng )
                BoneMaxs:Rotate( BoneAng )
                BonePositions[ #BonePositions + 1 ] = BonePos + ( ( BoneMins + BoneMaxs ) * 0.5 )
            end
        end

        if #BonePositions == 0 then return { BackUpPos } end 

        return BonePositions
    else
        local PreferedBoneIndex = 1

        for i = 1, #BoneTable do
            if BoneTable[ i ].Group != Settings.Vars.HitboxSelection then continue end 
            PreferedBoneIndex = BoneTable[ i ].Index
            break
        end

        local HitBoxBone = EntTable.Ent:GetHitBoxBone( PreferedBoneIndex, HitboxSet )

        if HitBoxBone == nil then return { BackUpPos } end

        local BoneMins, BoneMaxs = EntTable.Ent:GetHitBoxBounds( PreferedBoneIndex, HitboxSet )

        if not BoneMins or not BoneMaxs then return { BackUpPos } end

        local BonePos, BoneAng = EntTable.Ent:GetBonePosition( HitBoxBone )  

        if Settings.Vars.Multipoints then
            return Sublimity.GetHitBoxBounds( BoneMins, BoneMaxs, BonePos, BoneAng )
        else
            BoneMins:Rotate( BoneAng )
            BoneMaxs:Rotate( BoneAng )
            return { BonePos + ( ( BoneMins + BoneMaxs ) * 0.5 ) }
        end
    end
                   
    return { BackUpPos }
end

// Target selection
Sublimity.FriendList = {}
Sublimity.TargetSorting = {} 

Sublimity.TargetSorting[ 1 ] = function( a, b ) 
    return ( a.PredictedOrigin - LocalEx.EyePosition ):LengthSqr() < ( b.PredictedOrigin - LocalEx.EyePosition ):LengthSqr()
end

Sublimity.TargetSorting[ 2 ] = function( a, b )
    local aDist, bDist 

    do 
        local aPos = ( a.PredictedOrigin ):ToScreen()
        local aX, aY = ScreenData.CenterW - aPos.x, ScreenData.CenterH - aPos.y

        aDist = aX * aX + aY * aY
    end

    do 
        local bPos =( b.PredictedOrigin ):ToScreen()
        local bX, bY = ScreenData.CenterW - bPos.x, ScreenData.CenterH - bPos.y

        bDist = bX * bX + bY * bY
    end

    return aDist < bDist
end

Sublimity.TargetSorting[ 3 ] = function( a, b ) 
    return a.Health < b.Health 
end

function Sublimity.SortedPlayers( sortingMode, predictSelf, predictPlayers, visibleCheck )
    local EntTable, Ent  
    local LocalTeam = PlayerList[ 0 ].Team
    local Validated = {}
    local OldEyePos = LocalEx.EyePosition

    if predictSelf then 
        LocalEx.EyePosition = LocalEx.EyePosition + ( LocalEx.Velocity * TickInterval ) * predictSelf
    end 

    for i = 1, #PlayerList do
        EntTable    = PlayerList[ i ]
        Ent         = EntTable.Ent

        if not Validate( Ent ) or not EntTable.Alive or EntTable.Dormant then continue end

        if Settings.Vars.IgnoreFriends          and Sublimity.FriendList[ EntTable.SteamID ]         then continue end
        if Settings.Vars["IgnoreSteam friends"] and EntEx.PlayerData[ Ent ] == "friend"             then continue end
        if Settings.Vars.IgnoreBots             and EntTable.Bot                                    then continue end  
        if Settings.Vars.IgnoreTeammates        and EntTable.Team == LocalTeam                      then continue end
        if Settings.Vars.IgnoreNodraw           and bit_Band( EntTable.Effects, EF_NODRAW ) == EF_NODRAW then continue end 
        if Settings.Vars.IgnoreFrozen           and bit_Band( EntTable.Flags, FL_FROZEN ) == FL_FROZEN   then continue end
        if Settings.Vars.IgnoreGod              and bit_Band( EntTable.Flags, FL_GODMODE ) == FL_GODMODE then continue end
        if Settings.Vars.IgnoreNoclip           and EntTable.MoveType == MOVETYPE_NOCLIP            then continue end
        if Settings.Vars.IgnoreDriving          and Validate( Ent:GetVehicle() )                    then continue end
        if Settings.Vars.IgnoreAdmin            and EntEx.PlayerData[ Ent ].IsAdmin                 then continue end
        if Settings.Vars["IgnoreBroken LC"]     and EntTable.BreakingLagComp                        then continue end 

        if visibleCheck then
            if not Trace.VisibleCheck( Ent, EntTable.OBBCenter, AngleVec.CalcDir( LocalEx.EyePosition, EntTable.OBBCenter ) ) then
                continue 
            end 
        end

        if predictPlayers then 
            EntTable.PredictedOrigin = EntTable.OBBCenter + ( EntTable.Velocity * TickInterval ) * predictPlayers
        end 

        Validated[ #Validated + 1 ] = EntTable
    end

    if #Validated == 0 then 
        return 
    end 

    table_sort( Validated, Sublimity.TargetSorting[ sortingMode ] )
    LocalEx.EyePosition = OldEyePos

    return Validated
end 

function Sublimity.GetAimbotTarget( cmd )
    local Targets = Sublimity.SortedPlayers( Settings.Vars.TargetSelection )
 
    if not Targets then return end

    local NumTargets = #Targets 

    if Settings.Vars.MaxTargets != 0 and NumTargets > Settings.Vars.MaxTargets then
        NumTargets = Settings.Vars.MaxTargets
    end

    for i = 1, #Targets do
        local Target = Targets[ i ]
        local AvaliablePositions = Sublimity.GetAimPosition( Target )

        for p = 1, #AvaliablePositions do
            local Bone = AvaliablePositions[ p ]

            if not Trace.VisibleCheck( Target.Ent, Bone ) then continue end 

            return Target, Bone
        end
    end
end 

// Create move hook

Sublimity.BadMoveTypes = { [ MOVETYPE_NOCLIP ] = true, [ MOVETYPE_LADDER ] = true, [ MOVETYPE_OBSERVER ] = true }
Sublimity.MoveKeys = { IN_BACK, IN_FORWARD, IN_MOVELEFT, IN_MOVERIGHT, IN_JUMP }
Sublimity.ToolList = { ["weapon_physcannon"] = true, ["weapon_physgun"] = true, ["lockpick"] = true }
Sublimity.LastTauntTime = 0

Sublimity.DisplayTaunts = DarkRP and { "Bow", "Muscle", "Becon", "Laugh", "Pers", "Disagree", "Agree", "Wave", "Dance" } or { "Robot", "Muscle", "Laugh", "Bow", "Cheer", "Wave", "Becon", "Agree", "Disagree", "Forward", "Group", "Half", "zombie", "Dance", "Pers", "Halt", "Salute" } 
Sublimity.Taunts = { "robot", "muscle", "laugh", "bow", "cheer", "wave", "becon", "agree", "disagree", "forward", "group", "half", "zombie", "dance", "pers", "halt", "salute" }
Sublimity.DarkRpTaunts = { ACT_GMOD_GESTURE_BOW, ACT_GMOD_TAUNT_MUSCLE, ACT_GMOD_GESTURE_BECON, ACT_GMOD_TAUNT_LAUGH, ACT_GMOD_TAUNT_PERSISTENCE, ACT_GMOD_GESTURE_DISAGREE, ACT_GMOD_GESTURE_AGREE, ACT_GMOD_GESTURE_WAVE, ACT_GMOD_TAUNT_DANCE }

Sublimity.HandJob = {
    [1] = function( cmd )
        if _G.EasyChat then
            net_Start( "EASY_CHAT_START_CHAT" ) 
                net_lib.WriteBool( true )
			net_SendToServer()

            return 
        end
             
        ded.SetTyping( cmd, true )
    end,
    [2] = function( cmd )
        if _G.EasyChat then
            net_Start( "EASY_CHAT_START_CHAT" ) 
                net_lib.WriteBool( ( CommandEx.CommandNumber % 12 ) >= 6 )
            net_SendToServer()

            return
        end
            
        ded.SetTyping( cmd, ( CommandEx.CommandNumber % 12 ) >= 6 )
    end, 
    [3] = function( cmd )
        if _G.EasyChat then
            net_Start( "EASY_CHAT_START_CHAT" ) 
                net_lib.WriteBool( math_Random( 0, 1 ) == 0 )
            net_SendToServer()

            return
        end
            
        ded.SetTyping( cmd, math_Random( 0, 1 ) == 0 )
    end,
}

Sublimity.OldStrafeYaw = 0
Sublimity.Autosrafers = {
    [ 1 ] = function() 
        CommandEx.SideMove = CommandEx.Swap and -5250 or 5250
    end,
    [ 2 ] = function()
        if CommandEx.MouseY > 1 then
            CommandEx.SideMove = ConVars.cl_sidespeed
        elseif CommandEx.MouseY < 1 then
            CommandEx.SideMove = -ConVars.cl_sidespeed
        end
    end,
    [ 3 ] = function()  
        local velocityLength = LocalEx.Velocity:Length2D()
        local sideFlip = CommandEx.Swap and 1 or -1

        local viewAngles = ViewEx.Angles.y
        local velocityAngles = LocalEx.Velocity:Angle().y

        if velocityLength <= 15 and ( CommandEx.ForwardMove == 0 or CommandEx.SideMove == 0 ) then
            return
        end

        local turnAtan = math_Atan2( -CommandEx.SideMove, CommandEx.ForwardMove )
        viewAngles = viewAngles + ( turnAtan * math_Radian )

        local strafeAngle = math_Min( math_Deg( math_Atan( 15 / velocityLength ) ), ConVars.sv_airaccelerate / TickRate )
        if strafeAngle > 90 then strafeAngle = 90 elseif strafeAngle < 0 then strafeAngle = 0 end

        local tempYaw = math_NormalizeAngle( viewAngles - Sublimity.OldStrafeYaw )
        local yawDelta = tempYaw

        Sublimity.OldStrafeYaw = viewAngles

        local absYawDelta = math_Abs( yawDelta )

        if absYawDelta <= strafeAngle or absYawDelta >= 30 then
            tempYaw = math_NormalizeAngle( viewAngles - velocityAngles )

            local velocityDegree = math_Deg( math_Atan( 30 / ( velocityLength * 128 ) ) )
            if velocityDegree > 90 then velocityDegree = 90 elseif velocityDegree < 0 then velocityDegree = 0 end
       
            if tempYaw <= velocityDegree or velocityLength <= 15 then
                if -velocityDegree <= tempYaw or velocityLength <= 15 then
                    viewAngles = viewAngles + ( strafeAngle * sideFlip )
                    CommandEx.SideMove = ( ConVars.cl_sidespeed * sideFlip )
                else
                    viewAngles = velocityAngles - velocityDegree
                    CommandEx.SideMove = ConVars.cl_sidespeed
                end
            else
                viewAngles = velocityAngles + velocityDegree
                CommandEx.SideMove = -ConVars.cl_sidespeed
            end
        elseif yawDelta != 0 then
            CommandEx.SideMove = yawDelta > 0 and -ConVars.cl_sidespeed or ConVars.cl_sidespeed
        end

        local moveVec = Vec( CommandEx.ForwardMove, CommandEx.SideMove, 0 )
        local moveLen = moveVec:Length()
        local moveAng = moveVec:Angle().y

        local normX = math_ModF( ViewEx.Angles.x + 180, 360 ) - 180
        local normY = math_ModF( ViewEx.Angles.y + 180, 360 ) - 180

        local moveYaw = math_Rad( normY - viewAngles + moveAng )

        if normX >= 90 or normX <= -90 or ViewEx.Angles.x >= 90 and ViewEx.Angles.x <= 200 or ViewEx.Angles.x <= -90 and ViewEx.Angles.x <= 200 then
            CommandEx.ForwardMove = -math_Cos( moveYaw ) * moveLen
        else
            CommandEx.ForwardMove = math_Cos( moveYaw ) * moveLen
        end

        CommandEx.SideMove = math_Sin( moveYaw ) * moveLen
    end
}

Sublimity.MaxVape = MathEx.TimeToTicks( 5 )
Sublimity.VapeTime = 0
Sublimity.LastTorch = 0

Sublimity.RopeTools = { ["rope"] = "rope_material", ["hydraulic"] = "hydraulic_material", ["winch"] = "winch_rope_material", ["muscle"] = "muscle_material", ["slider"] = "slider_material", ["pulley"] = "pulley_material", ["elastic"] = "elastic_material" }
Sublimity.Matz = { "debug/debugportals", "debug/debugempty", "debug/debugfbtexture0", "debug/debugreflect", "debug/env_cubemap_model", "debug/debugluxels", "debug/debugrefract", "debug/debugcamerarendertarget", "effects/flashlight/view", "gmod/scope-refract" }

// Simplest pathfinder 
local Pathfinder = { Nodes = {}, FoundNodes = {}, GeneratedPath = {}, LastRecalc = 0, ForcedRecalc = 0, OldTarget = Vec(), Target = Vec(), BestDistance = math_Infinity }

Pathfinder.Step       = math_Abs( LocalEx.HullMaxs.y * 2 ) 
Pathfinder.StepHeight = LocalEntity:GetStepSize()

Pathfinder.SquaredStep   = Pathfinder.Step * Pathfinder.Step
Pathfinder.SquaredHeight = Pathfinder.StepHeight * Pathfinder.StepHeight

Pathfinder.Dirs = { Vec( Pathfinder.Step, 0, 0 ), Vec( -Pathfinder.Step, 0, 0 ), Vec( 0, Pathfinder.Step, 0 ), Vec( 0, -Pathfinder.Step, 0 ) }

Pathfinder.AboveStep = Vec( 0, 0, 8 )
Pathfinder.BelowStep = Vec( 0, 0, Pathfinder.StepHeight )

function Pathfinder.GeneratePath( Target, Fastest )
    local Node = AngleVec.Abs( LocalEx.Origin ) + Pathfinder.AboveStep
 
    if Target != Pathfinder.OldTarget and CurrentTime > Pathfinder.ForcedRecalc then
        Pathfinder.GeneratedPath = {}
        Pathfinder.FoundNodes = {}
        Pathfinder.Nodes = {}
        
        Pathfinder.Nodes[ 1 ] = { Pos = Node, Dirs = { false, false, false, false }, Completed = false, Stuck = false }
        Pathfinder.FoundNodes[ AngleVec.GetSumId( Node ) ] = true 
        
        Pathfinder.ForcedRecalc = CurrentTime + Settings.Vars.ForcedRecalc
        Pathfinder.BestDistance = math_Infinity
        Pathfinder.OldTarget    = Target
    end

    debugoverlay.Cross( Target, 32, 0.1, color_white, true )

    if #Pathfinder.GeneratedPath > 1 then
        for i = 1, #Pathfinder.GeneratedPath do
            debugoverlay.Box( Pathfinder.GeneratedPath[ i ],LocalEx.HullMins, LocalEx.HullMaxs, 0.1, color_transparent )
        end
    end

    Pathfinder.Target = Target

    if Pathfinder.LastRecalc > CurrentTime or Pathfinder.BestDistance <= Pathfinder.Step then return end 

    local Stuck, LastNode = false, 1
    local Dist

    Trace.HullStruct.maxs = LocalEx.HullMaxs
    Trace.HullStruct.mins = LocalEx.HullMins
    Trace.HullStruct.mask = MASK_PLAYERSOLID

    for i = 1, #Pathfinder.Nodes do
        Node = Pathfinder.Nodes[ i ]
        
        if Node.Completed then continue end 

        Dist = Node.Pos:DistToSqr( Target )

        if ( Fastest and Dist > Pathfinder.BestDistance ) and not Node.Stuck then  
            Node.Completed = true 
            continue 
        end 

        if Dist < Pathfinder.BestDistance or Node.Stuck then
            Pathfinder.GeneratedPath[ #Pathfinder.GeneratedPath + 1 ] = Node.Pos
            Pathfinder.BestDistance = Dist
        end

        LastNode    = i
        Stuck       = false 

        for d = 1, #Pathfinder.Dirs do
            if Node.Dirs[ d ] then continue end 

            Trace.HullStruct.start  = Node.Pos
            Trace.HullStruct.endpos = AngleVec.Abs( Node.Pos + Pathfinder.Dirs[ d ] - Pathfinder.BelowStep )

            Trace.Output = util_TraceHull( Trace.HullStruct )

            if not Trace.Output.Hit then 
                Node.Dirs[ d ] = true 
                continue 
            end

            Trace.HullStruct.start  = Node.Pos
            Trace.HullStruct.endpos = AngleVec.Abs( Node.Pos + Pathfinder.Dirs[ d ] )

            Trace.Output = util_TraceHull( Trace.HullStruct )
            Trace.Output.HitPos = AngleVec.Abs( Trace.Output.HitPos ) 

            if Trace.Output.HitPos:DistToSqr( Node.Pos ) < Pathfinder.SquaredStep then
                Node.Dirs[ d ] = true 
                Stuck = true 
                continue 
            elseif Pathfinder.FoundNodes[ AngleVec.GetSumId( Trace.Output.HitPos ) ] then
                Node.Dirs[ d ] = true 
                continue 
            end

            Pathfinder.Nodes[ #Pathfinder.Nodes + 1  ] = { Pos = Trace.Output.HitPos, Dirs = { false, false, false, false }, Completed = false, Stuck = false  }
            Pathfinder.FoundNodes[ AngleVec.GetSumId( Trace.Output.HitPos ) ] = true 

            Node.Dirs[ d ] = true 
        end

        if #Pathfinder.Nodes - LastNode > 0 then
            for d = 1, ( #Pathfinder.Nodes - LastNode ) do
                Pathfinder.Nodes[ d ].Stuck = Stuck
            end
        end

        Stuck = false
    
        Node.Completed = true  
        Pathfinder.LastRecalc = CurrentTime + Settings.Vars.PathFinderDelay

        table_sort( Pathfinder.Nodes, function( a, b ) 
            return a.Pos:DistToSqr( Target ) < b.Pos:DistToSqr( Target ) 
        end ) 
    end
end

// Sequence manipulation 
Sublimity.FrozenTicks = 0
Sublimity.MaxFreezeTicks = TickRate
Sublimity.SkippedFire = false 

Sublimity.ManipulateSequence = {
    [ 1 ] = function()
        CommandEx.OutSequence = CommandEx.OutSequence + Settings.Vars.SeqManipAmt 
    end,
    [ 2 ] = function()
        if bit_Band( CommandEx.Buttons, IN_ATTACK ) == IN_ATTACK or LocalEx.BadMove then Sublimity.FrozenTicks = 0 return end 

        Sublimity.FrozenTicks = Sublimity.FrozenTicks < Sublimity.MaxFreezeTicks and Sublimity.FrozenTicks + 1 or 0 

        if Sublimity.FrozenTicks == 0 then return end 

        CommandEx.OutSequence = CommandEx.OutSequence + Sublimity.FrozenTicks - 1
    end,
    [ 3 ] = function()
        CommandEx.OutSequence = CommandEx.OutSequence + TickRate + 1
    end,
    [ 4 ] = function()
        CommandEx.OutSequence = CommandEx.OutSequence + Settings.Vars.SeqManipSpeedhack
    end,
    [ 5 ] = function()
        if not CommandEx.Swap then return end 
        CommandEx.OutSequence = CommandEx.OutSequence + math_Random( 1, TickRate )
    end,
    [ 6 ] = function()
        if not LocalEx.WeaponClass or bit_Band( CommandEx.Buttons, IN_ATTACK ) != IN_ATTACK or Sublimity.ToolList[ LocalEx.WeaponClass ] then return end
        if Sublimity.SkippedFire then Sublimity.SkippedFire = false return end 

        CommandEx.OutSequence = CommandEx.OutSequence + TickRate - 1
        Sublimity.SkippedFire = true
    end,
}

// View roll memes
Sublimity.ViewRolls = {
    [ 1 ] = function()
        CommandEx.ViewAngles.r = 180 
    end, 
    [ 2 ] = function()
        CommandEx.ViewAngles.r = math_Random( 0, 360 )
    end,
    [ 3 ] = function()
        CommandEx.ViewAngles.r = ( CurrentTime * 32 ) % 360
    end,
    [ 4 ] = function()
        CommandEx.ViewAngles.r = math_Sin( CurrentTime * 3 ) * 180
    end,
}

// Auto peek 
Sublimity.Peeking = false 
Sublimity.MoveBack = false 
Sublimity.PeekPos = Vec()



function Sublimity.CreateMove( cmd )

    -- Collect command data 
    CommandEx.Object        = cmd

    CommandEx.CommandNumber = cmd:CommandNumber()
    CommandEx.TickCount     = cmd:TickCount()
    CommandEx.Swap          = CommandEx.CommandNumber % 2 == 0
    CommandEx.SendPacket    = true

    CommandEx.Buttons       = cmd:GetButtons()
    CommandEx.Impulse       = cmd:GetImpulse()

    CommandEx.SideMove      = cmd:GetSideMove()
    CommandEx.ForwardMove   = cmd:GetForwardMove()
    CommandEx.UpMove        = cmd:GetUpMove()

    CommandEx.ViewAngles    = cmd:GetViewAngles()
    CommandEx.WishYaw       = CommandEx.ViewAngles.y

    CommandEx.MouseWheel    = cmd:GetMouseWheel()
    CommandEx.MouseY        = cmd:GetMouseY()
    CommandEx.MouseX        = cmd:GetMouseX()

    -- Get local entity data 

    LocalEx.Origin      = LocalEntity:GetPos()
    LocalEx.Velocity    = LocalEntity:GetVelocity()
    LocalEx.EyePosition = LocalEntity:EyePos()
    LocalEx.EyeAngles   = LocalEntity:EyeAngles()

    LocalEx.HullMins    = LocalEntity:OBBMins()
    LocalEx.HullMaxs    = LocalEntity:OBBMaxs()

    LocalEx.MoveType    = LocalEntity:GetMoveType()
    LocalEx.Flags       = LocalEntity:GetFlags()
    LocalEx.WaterLevel  = LocalEntity:WaterLevel()
    LocalEx.OnGround    = bit_Band( LocalEx.Flags, FL_ONGROUND ) == FL_ONGROUND

    LocalEx.Moving      = false     
    LocalEx.BadMove     = false 

    LocalEx.WeaponEnt   = LocalEntity:GetActiveWeapon()
    LocalEx.WeaponClass = Validate( LocalEx.WeaponEnt ) and LocalEx.WeaponEnt:GetClass() or false 
    LocalEx.WeaponBase  = LocalEx.WeaponClass and string_Split( LocalEx.WeaponClass, "_" )[ 1 ] or false 

    LocalEx.ViewFrozen  = LocalEx.WeaponClass and ( ( LocalEx.WeaponEnt.FreezeMovement and LocalEx.WeaponEnt:FreezeMovement() ) or ( LocalEx.WeaponClass == "weapon_physgun" and Validate( LocalEx.WeaponEnt:GetInternalVariable("m_hGrabbedEntity") ) and bit_Band( CommandEx.Buttons, IN_USE ) == IN_USE ) ) or false 

    LocalEx.GroundTicks = LocalEx.OnGround and LocalEx.GroundTicks + 1 or 0

    if LocalEx.OnGround then 
        LocalEx.GroundPos = LocalEntity:GetNetworkOrigin() 
    end 

    -- Compute silent angles 

    ViewEx.Angles.r = 0

    if not LocalEx.ViewFrozen then
        ViewEx.Angles = ViewEx.Angles + Ang( CommandEx.MouseY * ConVars.m_yaw, CommandEx.MouseX * -ConVars.m_pitch, 0 )
        ViewEx.Angles.x = math_Clamp( ViewEx.Angles.x, -89, 89 )
        
        ViewEx.Angles:Normalize()
    end

    CommandEx.WishYaw = ViewEx.Angles.y

    -- Command mods

    if CommandEx.CommandNumber == 0 then return end 

    for i = 1, 5 do
        if bit_Band( CommandEx.Buttons, Sublimity.MoveKeys[ i ] ) == Sublimity.MoveKeys[ i ] then 
            LocalEx.Moving = true 
            break 
        end
    end

    LocalEx.BadMove = Sublimity.BadMoveTypes[ LocalEx.MoveType ]
    
    if Settings.Vars.SilentAim then
        CommandEx.ViewAngles = Ang( ViewEx.Angles.x, ViewEx.Angles.y, 0 )
    end

    if not PlayerList[ 0 ] then return end 

    if Settings.Vars.HandJob then 
        Sublimity.HandJob[ Settings.Vars.HandJobMode ]( cmd ) 
    end

    if Settings.Vars.ActSpam then
        local shouldTaunt = Settings.Vars.ActSpamTime == 0 and ( LocalEntity:IsPlayingTaunt( true ) == false ) or ( CurrentTime > Sublimity.LastTauntTime )
        
        if shouldTaunt then
            if DarkRP then
                RunCommand( "_DarkRP_DoAnimation", Sublimity.DarkRpTaunts[ Settings.Vars.ActSpamMode ] )
            else
                RunCommand( "act", Sublimity.Taunts[ Settings.Vars.ActSpamMode ] )  
            end
            
            Sublimity.LastTauntTime = CurrentTime + Settings.Vars.ActSpamTime
        end
    end

    if Settings.Vars.FlashlightSpam and CommandEx.BindDown( "impulse 100" ) then
        CommandEx.Impulse = 100
    end

    CommandEx.KeySpam( IN_USE, Settings.Vars.UseSpam )
   
    -- Movement stuff 

    if not LocalEx.BadMove then
        if Settings.Vars.EdgeJump and Settings.Binds[ 6 ].State and LocalEx.GroundTicks > 16 then
            ded.StartSimulation( LocalEx.Index )

            ded.SimulateTick()

            Simulation.Output = ded.GetSimulationData()

            ded.FinishSimulation() 

            if Simulation.Output.m_vecAbsOrigin.z < LocalEx.Origin.z then
                CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_JUMP )
            end
        end 

        if Settings.Vars.AutoLongjump then
            local ShouldDuck = true 
            local Ducked = bit_Band( LocalEx.Flags, FL_DUCKING ) == FL_DUCKING
            local Maxs = LocalEx.HullMaxs

            if not Ducked then 
                Maxs.z = Maxs.z - 36 
            end 

            Trace.HullStruct.maxs   = Maxs
            Trace.HullStruct.mins   = LocalEx.HullMins
            Trace.HullStruct.mask   = MASK_PLAYERSOLID

            ded.StartSimulation( LocalEx.Index )

            for i = 1, 3 do 
                ded.SimulateTick()

                Simulation.Output = ded.GetSimulationData()

                Trace.HullStruct.start  = Simulation.Output.m_vecAbsOrigin 
                Trace.HullStruct.endpos = Simulation.Output.m_vecAbsOrigin 

                if Ducked then 
                    Trace.HullStruct.endpos.z = Trace.HullStruct.endpos.z - 36 
                end

                Trace.Output = util_TraceHull( Trace.HullStruct )
                
                if LocalEntity:IsFlagSet( FL_ONGROUND ) or Trace.Output.Hit then
                    ShouldDuck = false 
                    break
                end
            end 

            ded.FinishSimulation()

            if Settings.Vars.AirDuckSpam and CommandEx.Swap then
                ShouldDuck = false 
            end

            if ShouldDuck and not LocalEx.OnGround then 
                CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_DUCK ) 
            end
        end

        if bit_Band( CommandEx.Buttons, IN_JUMP ) == IN_JUMP and LocalEx.WaterLevel < 2 then
            local ShouldHop = Settings.Vars.MaxHops < 1 and true or ( LocalEx.NumHops < Settings.Vars.MaxHops )
            
            if Settings.Vars.BunnyHop and ShouldHop then
                if LocalEx.OnGround then 
                    LocalEx.NumHops = LocalEx.NumHops + 1

                    if Settings.Vars.HopDelay > 0 and LocalEx.GroundTicks >= Settings.Vars.HopDelay and CommandEx.Swap then
                        CommandEx.Buttons = bit_Band( CommandEx.Buttons, bit_Bnot( IN_JUMP ) )
                    end
                elseif Settings.Vars.HopDelay == 0 then
                    CommandEx.Buttons = bit_Band( CommandEx.Buttons, bit_Bnot( IN_JUMP ) )
                end
            end

            if Settings.Vars.AirStrafer then
                CommandEx.ForwardMove = LocalEx.OnGround and ConVars.cl_forwardspeed or 5850 / LocalEx.Velocity:Length2D() 

                if not LocalEx.OnGround then
                    Sublimity.Autosrafers[ Settings.Vars.AirStraferMode ]()
                else
                    CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_SPEED )
                end
            end
        else
            LocalEx.NumHops = 0
        end

        if Settings.Vars.WaterFloat and LocalEx.WaterLevel > 1 then
            CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_JUMP )
        end

        if LocalEx.OnGround then  
            if Settings.Vars.GroundStrafe and CommandEx.SideMove == 0 and CommandEx.ForwardMove > 0 then
                CommandEx.SideMove = CommandEx.Swap and -5250 or 5250
            end  

            if Settings.Vars.FastStop and not LocalEx.Moving then
                local dir = LocalEx.Velocity:Angle()
                dir.y = ViewEx.Angles.y - dir.y
                            
                local newmove = dir:Forward() * LocalEx.Velocity:Length2D()
                    
                CommandEx.ForwardMove = -newmove.x
                CommandEx.SideMove = -newmove.y
            end
        
            if Settings.Vars.SlowWalk and Settings.Binds[ 5 ].State then 
                local ratio = LocalEntity:GetSlowWalkSpeed()

                CommandEx.ForwardMove = math_Floor( CommandEx.ForwardMove / ( Settings.Vars.SlowWalkSpeed * ratio ) )
                CommandEx.SideMove = math_Floor( CommandEx.SideMove / ( Settings.Vars.SlowWalkSpeed * ratio ) )
            end
        end
    end

    -- Auto peek 

    if Settings.Vars.AutoPeek then
        if Settings.Binds[ 9 ].State then
            if not Sublimity.Peeking then
                Sublimity.PeekPos = LocalEx.Origin
            end

            Sublimity.Peeking = true 
        else
            Sublimity.Peeking = false 
        end

        local Dist = LocalEx.Origin:DistToSqr( Sublimity.PeekPos ) 

        if Sublimity.MoveBack and Dist < 1024 then
            Sublimity.MoveBack = false 
        elseif not Sublimity.MoveBack and bit_Band( CommandEx.Buttons, IN_ATTACK ) == IN_ATTACK then
            Sublimity.MoveBack = true 
        end
      
        if Sublimity.Peeking and ( Sublimity.MoveBack or ( Settings.Vars.AutoPeekPullback and not LocalEx.Moving and Dist > 1024 ) ) then
            CommandEx.ForwardMove = ConVars.cl_forwardspeed
            CommandEx.SideMove = 0

            CommandEx.WishYaw = math_NormalizeAngle( AngleVec.CalcDir( LocalEx.Origin, Sublimity.PeekPos ).y - 180 )

            if Settings.Vars.AutoPeekTeleport then
                -- add shift code here
            end
        end
    end
    
    -- Vape hackz 

    if LocalEx.WeaponClass and string_StartsWith( LocalEx.WeaponClass, "weapon_vape" ) then
        if Settings.Vars.AutoVape then
            if bit_Band( CommandEx.Buttons, IN_ATTACK ) == IN_ATTACK then
                Sublimity.VapeTime = Sublimity.VapeTime + 1 

                if Sublimity.VapeTime >= Sublimity.MaxVape then
                    CommandEx.Buttons = bit_Band( CommandEx.Buttons, bit_Bnot( IN_ATTACK ) )
                    Sublimity.VapeTime = 0
                end
            else
                Sublimity.VapeTime = 0
            end
        end

        if Settings.Vars.VapeSpam then
            CommandEx.Buttons = CommandEx.Swap and bit_Bor( CommandEx.Buttons, IN_ATTACK2 ) or bit_Band( CommandEx.Buttons, bit_Bnot( IN_ATTACK2 ) )
        end

        if Settings.Vars.VapeTorch and Sublimity.LastTorch < CurrentTime and LocalEx.WeaponClass == "weapon_vape_dragon" then
            local Ent
            for i = 1, #PlayerList do
                Ent = PlayerList[ i ]

                if Ent.Origin:DistToSqr( LocalEx.Origin ) > 250000 or Ent.Ent:IsOnFire() then continue end 

                net_Start( "DragonVapeIgnite" )
                    net_lib.WriteEntity( Ent.Ent )
                net_SendToServer()
            end

            Sublimity.LastTorch = CurrentTime + 0.3
        end
    end

    -- Climb swep auto parkour

    if Settings.Vars.AutoParkour and LocalEx.WeaponEnt.Jumps then
        local jumps = LocalEntity:GetNWInt("ClimbJumps")
        
        if ConVars.climbswep2_maxjumps - jumps < ConVars.climbswep2_maxjumps then
            CommandEx.ForwardMove = ConVars.cl_forwardspeed
            CommandEx.SideMove = 0
            
            CommandEx.ViewAngles.y = math_NormalizeAngle( CommandEx.ViewAngles.y - 180 )
        end
    end 

    -- Rope spam

    if Settings.Vars.RopeSpam and LocalEx.WeaponClass == "gmod_tool" and bit_Band( CommandEx.Buttons, IN_ATTACK ) == IN_ATTACK then
        local ToolMode = LocalEntity:GetTool() 
        
        if Sublimity.RopeTools[ ToolMode.Mode ] then
            if Settings.Vars.RopeMatz then
                RunCommand( Sublimity.RopeTools[ ToolMode.Mode ], Sublimity.Matz[ math_Random( 1, #Sublimity.Matz ) ] )
            end

            CommandEx.ViewAngles.x = math_Random( -89, 90 )
            CommandEx.ViewAngles.y = math_NormalizeAngle( math_Random( -180, 180 ) )

            if CommandEx.Swap then
                CommandEx.Buttons = bit_Band( CommandEx.Buttons, bit_Bnot( IN_ATTACK ) )
            end
        end
    end

    -- Sex hackz 

    if Settings.Vars.AutoRape and LocalEx.WeaponEnt.PRIMARYPW then
        if Validate( LocalEntity:GetEyeTrace().Entity ) then
            RunCommand( LocalEx.WeaponEnt.PRIMARYPW )
        end
    end

    -- Path follower 

    if Settings.Vars.PathFinder and #Pathfinder.GeneratedPath > 2 and LocalEx.Origin:DistToSqr( Pathfinder.Target ) > Pathfinder.SquaredStep * 2 then
        table_sort( Pathfinder.GeneratedPath, function( a, b ) 
            return a:DistToSqr( LocalEx.Origin ) < b:DistToSqr( LocalEx.Origin ) and a:DistToSqr( Pathfinder.Target ) < b:DistToSqr( Pathfinder.Target )
        end ) 

        CommandEx.ForwardMove = ConVars.cl_forwardspeed
        CommandEx.SideMove = 0

        CommandEx.WishYaw = math_NormalizeAngle( AngleVec.CalcDir( LocalEx.Origin, Pathfinder.GeneratedPath[ 1 ] ).y - 180 )

        for i = 1, #Pathfinder.GeneratedPath do
            if not Pathfinder.GeneratedPath[ i ] then continue end 

            if LocalEx.Origin:DistToSqr( Pathfinder.GeneratedPath[ i ] ) < Pathfinder.SquaredStep then
                table_remove( Pathfinder.GeneratedPath, i )
            end
        end
    end

    -- Lock pick 

    if Settings.Vars.FastLockpick and LocalEx.WeaponClass == "lockpick" then
        if LocalEx.WeaponEnt:GetLockpickEndTime() - LocalEx.WeaponEnt:GetLockpickStartTime() > Settings.Vars.PickTimeMin then
            if  CommandEx.Swap then
                CommandEx.ViewAngles.y = math_NormalizeAngle( CommandEx.ViewAngles.y - 180 )
            else
                CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_ATTACK )
            end
        end
    end

    -- Burnmaster hackz

    if Settings.Vars.UnterBurner and LocalEx.WeaponClass == "weapon_burnmaster6000" and Settings.Binds[ 11 ].State then
        CommandEx.ViewAngles.x = 89 
        CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_ATTACK2 )

        if not LocalEntity:IsOnFire() then
            RunCommand( "ulx", "ignite", LocalEntity:Name() )
        end
    end

    -- XBow trigger 

    if Settings.Vars.XBowTrigger and Sublimity.XbowEntity and Sublimity.XbowEntity:IsPlayer() then
        CommandEx.Buttons = bit_Bor( CommandEx.Buttons, IN_ATTACK )
    end

    -- Fix view / rapid fire

    if Settings.Vars.SilentAim then 
        CommandEx.FixMovement( CommandEx.WishYaw ) 
    else
        ViewEx.Angles = CommandEx.ViewAngles
    end

    CommandEx.KeySpam( IN_ATTACK, Settings.Vars.RapidFire and not Sublimity.ToolList[ LocalEx.WeaponClass ] or ( Settings.Vars.CameraSpam and LocalEx.WeaponClass == "gmod_camera" ) )
    CommandEx.KeySpam( IN_ATTACK2, Settings.Vars.RapidFireAlt and not Sublimity.ToolList[ LocalEx.WeaponClass ] )

    if ViewEx.FreeCam or ( not Settings.Vars.MenuMove and UI.FrameVisible ) then
        CommandEx.SideMove = 0
        CommandEx.ForwardMove = 0
        CommandEx.UpMove = 0

        CommandEx.Buttons = 0 

        if ViewEx.FreeCam then 
            CommandEx.ViewAngles = ViewEx.PreFreeCam
        end
    else
        ViewEx.PreFreeCam = CommandEx.ViewAngles
    end

    -- Mofify out sequence 

    CommandEx.OutSequence = ded.GetOutSequenceNr()

    if Settings.Vars.SeqManip and Settings.Binds[ 8 ].State then
        Sublimity.ManipulateSequence[ Settings.Vars.SeqManipMode ]()
    end

    ded.SetOutSequenceNr( CommandEx.OutSequence )

    -- Modify roll angles 

    if Settings.Vars.ViewRoll then
        Sublimity.ViewRolls[ Settings.Vars.ViewRollMode ]()
    else
        CommandEx.ViewAngles.r = 0
    end

    -- Modify command data
    ded.SetCommandNumber( cmd, CommandEx.CommandNumber )
    ded.SetCommandTick( cmd, CommandEx.TickCount )
    ded.SetBSendPacket( CommandEx.SendPacket )

    cmd:SetButtons( CommandEx.Buttons )
    cmd:SetImpulse( CommandEx.Impulse )

    cmd:SetSideMove( CommandEx.SideMove )
    cmd:SetForwardMove( CommandEx.ForwardMove )
    cmd:SetUpMove( CommandEx.UpMove )

    cmd:SetViewAngles( CommandEx.ViewAngles )
    cmd:SetMouseY( CommandEx.MouseY )
    cmd:SetMouseX( CommandEx.MouseX )
    cmd:SetMouseWheel( CommandEx.MouseWheel ) 
end

Sublimity.SlowedTicks = 0
function Sublimity.SendNetMsg( msgName )
    if msgName == "clc_Move" then
        if Settings.Vars.SlowMotion and Settings.Binds[ 7 ].State then
            if Sublimity.SlowedTicks < MathEx.TimeToTicks( Settings.Vars.SlowMotionTime ) then
                ded.EnableSlowmotion( true ) 
                Sublimity.SlowedTicks = Sublimity.SlowedTicks + 1
            else
                ded.EnableSlowmotion( false )
                Sublimity.SlowedTicks = 0
            end
        else
            ded.EnableSlowmotion( false )
            Sublimity.SlowedTicks = 0
        end
    end
end

// Chat spam / kill say messages 
Sublimity.ShouldFormat = {  }
Sublimity.ChatMsgs = {
    { 
        ""
    },
    { 
        "как мать %s ? жива ?",
        "иди мать чекни %s",
        "как там шлюха мать %s поживает?",
        "вчера шлюху на трассе выбеал, вроде мать %s была",
        "мне тут птичка на ухо напела что у %s мать сгнила нахуй",
        "я недавно тут услышал что у %s мать сдохла xD",
        "бля %s убери свою дохлую мать, гнилью воняет пиздец",
        "вчера мать %s ебал норм темка",
        "ебать мать %s жирная свинья",
        "вчера мать %s топором захуярил",
        "мать %s настолько жирная что её грузовиком переехать мало",
        "у %s батя за хлебом ушел",
        "%s ебать лох ливни нахуй",
        "забавный факт, мать %s весит 500кг :)",
        "смотри в садик не опоздай %s",
        "%s у тебя утренник скоро",
        "%s ты как блять из палаты выбрался?",
        "кто сука интернет в палату к %s провёл?)",
        "%s тебе завтра вроде в школу...",
        "%s не забудь дз сделать :)",
        "нахуя к %s в деревню интернет провели...",
        "какой далбаеб додумался в деревню %s инет провести...",
        "%s ливни нахуй пж",
        "%s quit в консоль пж",
        "%s сьеби чмошник",
        "вчера шлюху отьебал. вроде %s звали",
        "пиздец %s лох ебаный ливни пж",
        "лол ебать у %s хуёв в жопе",
        "ебать у матери %s пизда размером с 10 этажный дом :)",
        "%s не обижайся конечно но я твою мать ебал xD",
        "%s когда думаешь из жизни ливать?",
        "сосни хуйца %s",
        "хуесос чмо пидр лох -> %s",
        "%s ебанись головой об стену пж",
        "%s смотри на первый урок не опоздай :)",
        "%s завтра в школу вроде",
        "%s как мать?)",
        "П|/|3ДЕЦ /\0Х -> %s",
        "%s с мамой и папой регулярно играл в снежки :)",
        "%s всегда такой далбаеб или сегодня особый день?",
        "%s задумался?! что то новенькое",
        "таких лохов как %s давно не видел",
        "поговаривают что %s отчим трахает :)",
        "вчера на могилу матери %s насрал :D",
        "мать %s стоя на коленях у меня сосала :)",
        "мать %s сдохла пока мой хуй сосала xD",
        "недавно выебал бабушку %s, было вкусно ˙ ͜ʟ˙",
        "вчера сжег деда %s ˙ ͜ʟ˙",
        "ебал все поколения родственников %s ツ",
        "ронял кирпич на голову матери %s ◝(ᵔᵕᵔ)◜",
        "%s по секрету скажу я твоего деда трахал ( ͡° ͜ʖ ͡°)",
        "выцарапал глаза матери %s. сори у меня лапки ฅ^•ﻌ•^ฅ",
        "%s скажи арбуз! твоя мать шлюха ◉‿◉",
        "( ＾◡＾)っ✂╰⋃╯ отцу %s хуй отрезал хахахахаах",
        "у %s сдохла мать и мне некого больше ебать (つ╥﹏╥)つ",
        "☠ у %s мать сдохла +шлюха +спидозная +похуй всем ☠",
        "( ◡̀_◡́) крепись брат %s у тебя мать сдохла",
        "%s тут такое дело... твоя мать такая милая когда ласкает мой член =^◕⩊◕^=",
        "%s дай сиськи потрогац ฅ՞•ﻌ•՞ฅ",
        "%s далбаеб ◡̈ ◡̈ ◡̈",
        "зуб даю у мамки %s самые мягкие сиськи ˶ᵔ ᵕ ᵔ˶",
    },
    { 

    },
    { 
        "I am the way and the truth and the life. No one comes to the Father except through me. -Jesus",
        "Do to others as you would have them do to you. -Jesus",
        "With man this is impossible, but with God all things are possible. -Jesus",
        "Do not judge, or you too will be judged. -Jesus",
        "No one can serve two masters.You cannot serve both God and money. -Jesus",
        "And whoever wants to be first must be slave of all. -Jesus",
        "And whoever welcomes one such child in my name welcomes me. -Jesus",
        "For where your treasure is, there your heart will be also. -Jesus",
        "Greater love has no one than this: to lay down one’s life for one’s friends. -Jesus",
        "Whoever drinks the water I give them will never thirst. -Jesus",
        "That which does not kill us makes us stronger. -Friedrich Nietzsche",
        "In the middle of every difficulty lies opportunity. -Albert Einstein",
        "Don’t cry because it’s over, smile because it happened. -Dr Suess",
        "If you want something done right, do it yourself. -Charles-Guillaume Étienne",
        "The unexamined life is not worth living. -Socrates",
        "Better to have loved and lost, than to have never loved at all. -St Augustine",
        "An eye for an eye leaves the whole world blind. -Mahatma Gandhi",
        "In three words I can sum up everything I’ve learned about life: it goes on. -Robert Frost",
        "Necessity is the mother of invention. -Plato",
        "To err is human; to forgive, divine. -Alexander Pope",
        "Imagination is more important than knowledge. -Albert Einstein",
        "With great power comes great responsibility. -Voltaire",
        "Believe you can and you’re halfway there. -Theodore Roosevelt",
        "The pen is mightier than the sword. -Proverb",
        "Life is like a box of chocolates. You never know what you’re gonna get. -Forrest Gump’s Mom",
        "Familiarity breeds contempt. -Aesop",
        "It is always darkest just before the dawn. -Thomas Fuller",
        "The ballot is stronger than the bullet. -Lincoln",
        "If you are going through hell, keep going. -Winston Churchill",
        "I am not removing the debug library, calm down. -Rubat",
        "yogurt. -wolfie",
        "加里-纽曼（Garry Newman）请把我们从 rubat 拯救出来，他正在摆脱 debug.getregistry。-usernameeee",
        "Cheat is fucking shit. -Relik",
        "Use ultimate™️, not exechack. -Jesus",
        "A rose by any other name would smell as sweet. -Juliet",
        "Don't cry because it's over, smile because it happened. -Dr. Seuss",
        "You miss 100% of the shots you don't take. -Wayne Gretzky",
        "Happiness is not something ready made. It comes from your own actions. -Dalai Lama",
        "My account details layo2021 - JNYLEQbgpiwv. -Donald Dicks $$$",
        "I WANT TO BE BANGED HARD. -Serejaga",
        "KAZAAAAAAAAAAA lite™️. -Ramzi",
        "Um, I wonder if I am being hacked. -Ramzi",
        "Connections... no hackers. -Ramzi",
        "1 раз выебать мать виги - молодец, 2 раза УК РФ Статья 244.... -Donald Dicks $$$",
        "We love death. The U.S. loves life. That is the difference between us two. -Osama bin Laden",
        "I don't regret what happened there. -Osama bin Laden",
        "For God and country - Geronimo, Geronimo, Geronimo. -Osama bin Laden",
        "I support any Muslims, whether here or abroad. -Osama bin Laden",
        "An ounce of prevention is better than a pound of cure. -Osama bin Laden",
        "There is no dialogue except with weapons. -Osama bin Laden",
        "Russia does not have a great deal of experience building democratic institutions. -Putin",
        "Those who fight corruption should be clean themselves. -Putin",
        "The question isn't who is going to let me; it's who is going to stop me. -Putin",
        "There are no grounds to suggest that Russia will return to the Cold War. -Putin",
        "The 21st century will be defined by the fight against terrorism. -Putin",
        "Russia has never been surrounded by so many friends as it is today. -Putin",
        "Nobody should pin their hopes on a miracle. -Putin",
        "Russia is a country of free people who can ensure their prosperity and well-being. -Putin",
        "I believe in the people and the wisdom of our elites. -Putin",
        "In Russia, the state, in a proper sense, returned only recently. -Putin",
        "Why don't you make me a Double-expresso -- Macchiato -- with extra foam? -Bill Williamson",
        "Everyone's gotta live, everyone's gotta be happy - It's a joke. -Bill Williamson",
    },
    { 

    }, 
    { 

    },
}




// Name stealer 
Sublimity.LastNamechange = 0
Sublimity.UsedName = 1

// Think 
Sublimity.ShouldUppercase = false 
Sublimity.LastChat = 0

function Sublimity.Think()
    CurrentTime = GetCT()
    RenderTime  = GetFT()
 
    local Bind 
    for i = 1, #Settings.Binds do
        Bind = Settings.Binds[ i ]

        if Bind.Key < 0 then continue end 

        if Bind.Mode == 1 then
            Bind.State = InputEx.KeysDown[ Bind.Key ]
        elseif Bind.Mode == 2 and InputEx.KeysPressed[ Bind.Key ] then
            Bind.State = not Bind.State
        elseif Bind.Mode == 3 then
            Bind.State = true
        end
    end

    if InputEx.KeysPressed[ KEY_DELETE ] then
        UI.FrameVisible = not UI.FrameVisible
        gui_EnableScreenClicker( UI.FrameVisible )
    end 

    local KeyName
    for i = 1, 113 do
        InputEx.KeysDown[ i ] = InputEx.IsKeyDown( i )
        InputEx.KeysPressed[ i ] = InputEx.KeysOld[ i ] != InputEx.KeysDown[ i ] and not InputEx.KeysDown[ i ]
        InputEx.KeysOld[ i ] = InputEx.IsKeyDown( i )

        if InputEx.KeysPressed[ 68 ] then
            Sublimity.ShouldUppercase = not Sublimity.ShouldUppercase
        end

        if UI.EditingText and InputEx.KeysPressed[ i ] then
            if i == 64 then UI.EditingText = false end 

            KeyName = input_lib.GetKeyName( i )

            if #KeyName > 1 and not UI.KeysAction[ i ] then continue end 

            if Sublimity.ShouldUppercase then
                KeyName = string_upper( KeyName )
            end

            Settings.Vars[ UI.EditingText ] = UI.KeysAction[ i ] and UI.KeysAction[ i ]( Settings.Vars[ UI.EditingText ] ) or Settings.Vars[ UI.EditingText ] .. KeyName
            Settings.Vars[ UI.EditingText ] = string_sub( Settings.Vars[ UI.EditingText ], 1, UI.EditorMax )

            if UI.EditorFunc then UI.EditorFunc() end
        end
    end 

    if Settings.Vars.PathFinder then
        Pathfinder.GeneratePath( Sublimity.SortedPlayers( 1 )[ 1 ].Origin, Settings.Vars.PathFinderDec )
    end

    local Str 
    if Settings.Vars.ChatSpam and CurrentTime - Sublimity.LastChat > Settings.Vars.ChatDelay then
        Str = Sublimity.ChatMsgs[ Settings.Vars.ChatMode ][ math_Random( 1, #Sublimity.ChatMsgs[ Settings.Vars.ChatMode ] ) ]

        if Settings.Vars.ChatMode < 3 then 
            Str = string_format( Str, EntEx.PlayerCache[ PlayerList[ math_Random( 1, #PlayerList ) ].Ent ].RealName )
        end
        
        RunCommand( "say", Str )

        Sublimity.LastChat = CurrentTime + Settings.Vars.ChatDelay
    end

    if Settings.Vars.NameStealer and CurrentTime - Sublimity.LastNamechange > ConVars.sv_namechange_cooldown_seconds then
        Str = EntEx.PlayerCache[ PlayerList[ Sublimity.UsedName ].Ent ].RealName

        ded.NetSetConVar( "name", Str .. " " )

        Sublimity.UsedName = math_Clamp( Sublimity.UsedName + 1, 1, #PlayerList )
        Sublimity.LastNamechange = CurrentTime
    end
end

// Render hackz
function Sublimity.RestoreRender()
    render_SetBlend( 1 )
    render_SetColorModulation( 1, 1, 1 )
    render_MaterialOverride()
    render_SuppressEngineLighting( false )
    render_DepthRange( 0, 1 )
    render_SetLightingMode( 0 )
end

function Sublimity.OverrideEntityRender( self )
    if not Settings.EntList[ self:GetClass() ] then
        Sublimity.RestoreRender()
        self:DrawModel() 
        return 
    end 

    local RenderMaterial = Sublimity.MaterialCache["Entity"][ ( Settings.Vars.EntityMaterial == 2 and Settings.Vars.Entity_Scroll ) and 8 or Settings.Vars.EntityMaterial ]
    local R, G, B, A = ColorEx.RgbObjToVec( Settings.Colors.EntityChams )

    if Settings.Vars.EntityMaterial == 4 then
        Sublimity.MaterialCache["Entity"][4]:SetVector( "$envmaptint", Vec( R, G, B ) )
    end

    if Settings.Vars.EntityIgnoreZ then
        render_DepthRange( 0, 0.01 )
    end

    if Settings.Vars.EntityChams then
        render_SetBlend( A )
        render_SetColorModulation( R, G, B )
        render_MaterialOverride( RenderMaterial )
        render_SetMaterial( RenderMaterial )
    end

    if Settings.Vars.EntityFullbright and Settings.Vars.EntityMaterial != 7 then
        render_SuppressEngineLighting( true )
    end

    self:DrawModel()
end

function Sublimity.PrePlayerDraw( ent, flags )
    Sublimity.RestoreRender()

    local RenderMaterial = Sublimity.MaterialCache["Player"][ ( Settings.Vars.PlayerMaterial == 2 and Settings.Vars.Player_Scroll ) and 8 or Settings.Vars.PlayerMaterial ]
    local R, G, B, A = ColorEx.RgbObjToVec( Settings.Colors.PlayerChams )

    if Settings.Vars.PlayerMaterial == 4 then
        Sublimity.MaterialCache["Player"][4]:SetVector( "$envmaptint", Vec( R, G, B ) )
    end

    if Settings.Vars.PlayerIgnoreZ then
        render_DepthRange( 0, 0.01 )
    end

    if Settings.Vars.PlayerChams then
        render_SetBlend( A )
        render_SetColorModulation( R, G, B )
        render_MaterialOverride( RenderMaterial )
        render_SetMaterial( RenderMaterial )
    end

    if Settings.Vars.PlayerFullbright and Settings.Vars.PlayerMaterial != 7 then
        render_SuppressEngineLighting( true )
    end
end 

function Sublimity.PreDrawViewModel( vm, ply, wpn )
    Sublimity.RestoreRender()

    local RenderMaterial = Sublimity.MaterialCache["Viewmodel"][ ( Settings.Vars.ViewmodelMaterial == 2 and Settings.Vars.Viewmodel_Scroll ) and 8 or Settings.Vars.ViewmodelMaterial ]
    local R, G, B, A = ColorEx.RgbObjToVec( Settings.Colors.ViewmodelChams )

    if Settings.Vars.ViewmodelMaterial == 4 then
        Sublimity.MaterialCache["Viewmodel"][4]:SetVector( "$envmaptint", Vec( R, G, B ) )
    end

    if Settings.Vars.ViewmodelChams then
        render_SetBlend( A )
        render_SetColorModulation( R, G, B )
        render_MaterialOverride( RenderMaterial )
        render_SetMaterial( RenderMaterial )
    end

    if Settings.Vars.ViewmodelFullbright and Settings.Vars.ViewmodelMaterial != 7 then
        render_SuppressEngineLighting( true )
    end

    render_DepthRange( 0, 0 )
end

function Sublimity.PreDrawPlayerHands( hands, vm, ply, wpn )
    Sublimity.RestoreRender()

    local RenderMaterial = Sublimity.MaterialCache["Hands"][ ( Settings.Vars.HandsMaterial == 2 and Settings.Vars.Hands_Scroll ) and 8 or Settings.Vars.HandsMaterial ]
    local R, G, B, A = ColorEx.RgbObjToVec( Settings.Colors.HandsChams )

    if Settings.Vars.HandsMaterial == 4 then
        Sublimity.MaterialCache["Hands"][4]:SetVector( "$envmaptint", Vec( R, G, B ) )
    end

    if Settings.Vars.HandsChams then
        render_SetBlend( A )
        render_SetColorModulation( R, G, B )
        render_MaterialOverride( RenderMaterial )
        render_SetMaterial( RenderMaterial )
    end

    if Settings.Vars.HandsFullbright and Settings.Vars.HandsMaterial != 7 then
        render_SuppressEngineLighting( true )
    end

    render_DepthRange( 0, 0 )
end

// Fog controller 

function Sublimity.SetupWorldFog()
    if not Settings.Vars.FogChanger then return end 

    render_lib.FogMode( MATERIAL_FOG_LINEAR )
    render_lib.FogColor( Settings.Colors.FogChanger[ 1 ], Settings.Colors.FogChanger[ 2 ], Settings.Colors.FogChanger[ 3 ] )
    render_lib.FogStart( Settings.Vars.FogStart )
    render_lib.FogEnd( Settings.Vars.FogEnd ) 
    render_lib.FogMaxDensity( Settings.Colors.FogChanger[ 4 ] / 255 )
    
    return true 
end

function Sublimity.SetupSkyboxFog( SkyboxSize )
    if not Settings.Vars.FogChanger then return end 

    render_lib.FogMode( MATERIAL_FOG_LINEAR )
    render_lib.FogColor( Settings.Colors.FogChanger[ 1 ], Settings.Colors.FogChanger[ 2 ], Settings.Colors.FogChanger[ 3 ] )
    render_lib.FogStart( Settings.Vars.FogStart * SkyboxSize )
    render_lib.FogEnd( Settings.Vars.FogEnd * SkyboxSize ) 
    render_lib.FogMaxDensity( Settings.Colors.FogChanger[ 4 ] / 255 )
    
    return true 
end

// Opaque rendering 
Sublimity.Tracers = {}
Sublimity.BeamColor = Col( 1, 1, 1 )
Sublimity.TraceMat = Mat( "sprites/physbeam" )
Sublimity.ImpactMins = Vec( -2, -2, -2 )
Sublimity.ImpactMaxs = Vec( 2, 2, 2 )

Sublimity.PathDir = Col( 255, 0, 0 )
Sublimity.PathSeg = Col( 0, 255, 0 )

UI.BeamColor()

function Sublimity.PostDrawOpaqueRenderables()
    Sublimity.RestoreRender()

    if Settings.Vars.BulletTracer then 
        local BeamData

        for i = 1, #Sublimity.Tracers do
            if not Sublimity.Tracers[ i ] then continue end 
            BeamData = Sublimity.Tracers[ i ]

            if BeamData.DieTime < CurrentTime then
                table_remove( Sublimity.Tracers, i )
                table_sort( Sublimity.Tracers, function( a, b ) return a.DieTime < b.DieTime end )

                continue 
            end

            render_SetMaterial( Sublimity.TraceMat ) 
            render_DrawBeam( BeamData.StartPos, BeamData.EndPos, 4, 1, 1, Sublimity.BeamColor )

            if Settings.Vars.BulletImpacts then
                render_DrawWireframeBox( BeamData.EndPos, AngleVec.NullAng, Sublimity.ImpactMins, Sublimity.ImpactMaxs, Sublimity.BeamColor, true )
            end
        end
    end

    if Settings.Vars.ProjectilePrediction and Sublimity.ProjectilePredictions[ LocalEx.WeaponClass ] then
        for i = 1, #Sublimity.XbowTracer - 1 do
            if not Sublimity.XbowTracer[ i ] or not Sublimity.XbowTracer[ i + 1 ] then continue end 

            render_DrawLine( Sublimity.XbowTracer[ i ], Sublimity.XbowTracer[ i + 1 ], Sublimity.PathDir , false )
        end

        if Validate( Sublimity.XbowEntity ) then
            render_DrawWireframeBox( Sublimity.XbowEntity:GetPos(), Sublimity.XbowEntity:GetAngles(), Sublimity.XbowEntity:OBBMins(), Sublimity.XbowEntity:OBBMaxs(), Sublimity.PathSeg, false )
        end
    end

    if Settings.Vars.ProjectileTrajectories then
        for i = 1, #Sublimity.ProjectilePaths do
            for p = 1, #Sublimity.ProjectilePaths[ i ] do
                if not Sublimity.ProjectilePaths[ i ][ p ] or not Sublimity.ProjectilePaths[ i ][ p + 1 ] then continue end 

                render_DrawLine( Sublimity.ProjectilePaths[ i ][ p ], Sublimity.ProjectilePaths[ i ][ p + 1 ], Sublimity.PathSeg , false )
            end
        end
    end
end

function Sublimity.OnImpact( Data )
    if not Settings.Vars.BulletTracer then return end 

    local Start = Data.m_vStart 

    if Settings.Vars.MuzzleTracer and Data.m_vStart == LocalEntity:EyePos() then
        local vm = LocalEntity:GetViewModel()

        if not vm or not Validate( vm ) then 
            goto Failed 
        end 

        local Muzzle = vm:LookupAttachment( "muzzle" )
        Muzzle = Muzzle == 0 and vm:LookupAttachment( "1" ) or vm:LookupAttachment( "muzzle" )
			
        if vm:GetAttachment( Muzzle ) then
            Start = vm:GetAttachment( Muzzle ).Pos
        end
    end

    :: Failed ::

    Sublimity.Tracers[ #Sublimity.Tracers + 1 ] = {
        DieTime = CurrentTime + Settings.Vars.TracerDieTime,
        StartPos = Start,
        EndPos = Data.m_vOrigin,
    }
end

// Render override 

function Sublimity.PreRender()
    if not Settings.Vars.Fullbright or ( Settings.Binds[ 10 ].Key > 0 and not Settings.Binds[ 10 ].State ) then return end 
    render_SetLightingMode( 1 )
end 

// Frame stage notify 
Sublimity.FrameStages = {}
Sublimity.Listed = {}

Sublimity.FrameStages[ 3 ] = function()
    PlayerList = {} 
    EntityList = {}

    local Tbl = ents_GetAll()
    local NeedsRecache = EntEx.LastEntUpdate < CurrentTime

    if NeedsRecache then
        UI.EntityList = {}
        Sublimity.Listed = {}
    end

    Sublimity.Projectiles = {}

    local Class 
    for i = 1, #Tbl do
        EntEx.ListEntity( Tbl[ i ], #EntityList + 1 )
        Class = EntityList[ #EntityList ].Class

        local SanityCheck = Tbl[ i ]:IsSolid() and not Tbl[ i ]:IsPlayer()

        if Tbl[ i ].RenderOverride != Sublimity.OverrideEntityRender and SanityCheck then
            Tbl[ i ].RenderOverride = Sublimity.OverrideEntityRender
        end

        if Sublimity.EntPreds[ Class ] then
            Sublimity.Projectiles[ #Sublimity.Projectiles + 1 ] = Tbl[ i ]
        end  

        if NeedsRecache and SanityCheck and not Sublimity.Listed[ Class ] then
            Sublimity.Listed[ Class ] = true 
            UI.EntityList[ #UI.EntityList + 1 ] = Class
        end
    end 

    if NeedsRecache then
        EntEx.LastEntUpdate = CurrentTime + 3
    end

    NeedsRecache = EntEx.LastRecache < CurrentTime

    Tbl = player_GetAll()
    EntEx.ListPlayer( LocalEntity, 0 )

    for i = 1, #Tbl do
        local Ply = Tbl[ i ]

        if not Validate( Ply ) then continue end 

        if not EntEx.PlayerCache[ Ply ] then
            EntEx.CachePlayer( Ply )
        end

        if NeedsRecache then
            EntEx.UpdatePlayerData( Ply )
        end

        if Ply == LocalEntity then continue end 

        EntEx.ListPlayer( Ply, #PlayerList + 1 )
    end

    if NeedsRecache then
        EntEx.LastRecache = CurrentTime + 0.9
    end
end

Sublimity.GravityVec = Vec( 0, 0, -ConVars.sv_gravity )
Sublimity.XbowEntity = false
Sublimity.XbowTracer = {}

Sublimity.ProjectilePredictions = {
    [ "weapon_crossbow" ] = function()
        local StartPos = LocalEx.EyePosition
        local StartDir = LocalEx.EyeAngles:Forward() * ( LocalEx.WaterLevel == 3 and 1500 or 3500 )
        local StartAcl = Sublimity.GravityVec * 0.05
        local PredPos, HitPos, HitDot, AbsVelocity

        Sublimity.XbowTracer = { StartPos }
        Sublimity.XbowEntity = false

        Trace.LineStruct.filter = LocalEntity

        while true do
            PredPos = StartPos + StartDir * TickInterval

            Trace.LineStruct.start = StartPos
            Trace.LineStruct.endpos = PredPos

            Trace.Output = util_TraceLine( Trace.LineStruct )

            if Validate( Trace.Output.Entity ) and Trace.Output.Entity != LocalEntity then
                Sublimity.XbowEntity = Trace.Output.Entity

                if Sublimity.XbowEntity:IsPlayer() then
                    break
                end
            end

            Sublimity.XbowTracer[ #Sublimity.XbowTracer + 1 ] = PredPos

            if Trace.Output.HitSky then break end

            if Trace.Output.Fraction == 1 then
                StartDir = StartDir + ( StartAcl * TickInterval )
                StartPos = PredPos
            else
                HitPos = Trace.Output.HitPos
                HitDot = Trace.Output.HitNormal:Dot( -Trace.Output.Normal )
                AbsVelocity = StartDir:Length()

                if HitDot < 0.5 and AbsVelocity > 100 then
                    StartDir = ( 2.0 * Trace.Output.HitNormal * HitDot * AbsVelocity + StartDir ) * 0.75
                    StartAcl = Sublimity.GravityVec 
                    StartPos = HitPos
                else
                    break
                end
            end
        end
    end,
    [ "weapon_smg1" ] = function()
        local StartPos = LocalEx.EyePosition
        local StartDir = LocalEx.EyeAngles:Forward() * 1000
        local StartAcl = Sublimity.GravityVec * ( 400 / ConVars.sv_gravity )
        local PredPos

        Sublimity.XbowTracer = { StartPos }
        Sublimity.XbowEntity = false

        Trace.LineStruct.filter = LocalEntity

        while true do
            PredPos = StartPos + StartDir * TickInterval

            Trace.LineStruct.start = StartPos
            Trace.LineStruct.endpos = PredPos

            Trace.Output = util_TraceLine( Trace.LineStruct )

            if Validate( Trace.Output.Entity ) and Trace.Output.Entity != LocalEntity then
                Sublimity.XbowEntity = Trace.Output.Entity
            end

            Sublimity.XbowTracer[ #Sublimity.XbowTracer + 1 ] = PredPos

            if Trace.Output.HitSky then break end

            if Trace.Output.Fraction == 1 then
                StartDir = StartDir + ( StartAcl * TickInterval )
                StartPos = PredPos
            else
                break
            end
        end
    end,
}

Sublimity.ProjectilePaths = {}

Sublimity.EntPreds = { 
    ["crossbow_bolt"] = function( self, index )
        local StartPos = self:GetOwner():EyePos()
        local StartDir = ( self:GetOwner():EyeAngles() ):Forward() * ( self:WaterLevel() == 3 and 1500 or 3500 )
        local StartAcl = Sublimity.GravityVec * 0.05
        local PredPos, HitPos, HitDot, AbsVelocity

        Sublimity.ProjectilePaths[ index ] = { StartPos }

        Trace.LineStruct.filter = { LocalEntity, self }

        while true do
            PredPos = StartPos + StartDir * TickInterval

            Trace.LineStruct.start = StartPos
            Trace.LineStruct.endpos = PredPos

            Trace.Output = util_TraceLine( Trace.LineStruct )

            if Validate( Trace.Output.Entity ) and Trace.Output.Entity != LocalEntity then
                break 
            end

            Sublimity.ProjectilePaths[ index ][ #Sublimity.ProjectilePaths[ index ] + 1 ] = PredPos

            if Trace.Output.HitSky then break end

            if Trace.Output.Fraction == 1 then
                StartDir = StartDir + ( StartAcl * TickInterval )
                StartPos = PredPos
            else
                HitPos = Trace.Output.HitPos
                HitDot = Trace.Output.HitNormal:Dot( -Trace.Output.Normal )
                AbsVelocity = StartDir:Length()

                if HitDot < 0.5 and AbsVelocity > 100 then
                    StartDir = ( 2.0 * Trace.Output.HitNormal * HitDot * AbsVelocity + StartDir ) * 0.75
                    StartAcl = Sublimity.GravityVec 
                    StartPos = HitPos
                else
                    break
                end
            end
        end
    end, 
    ["grenade_ar2"] = function( self, index ) 
        local StartPos = self:GetOwner():EyePos()
        local StartDir = ( self:GetOwner():EyeAngles() ):Forward() * 1000
        local StartAcl = Sublimity.GravityVec * ( 400 / ConVars.sv_gravity )
        local PredPos

        Sublimity.ProjectilePaths[ index ] = { StartPos }

        Trace.LineStruct.filter = { LocalEntity, self }

        while true do
            PredPos = StartPos + StartDir * TickInterval

            Trace.LineStruct.start = StartPos
            Trace.LineStruct.endpos = PredPos

            Trace.Output = util_TraceLine( Trace.LineStruct )

            if Validate( Trace.Output.Entity ) and Trace.Output.Entity != LocalEntity then
                break
            end

            Sublimity.ProjectilePaths[ index ][ #Sublimity.ProjectilePaths[ index ] + 1 ] = PredPos

            if Trace.Output.HitSky then break end

            if Trace.Output.Fraction == 1 then
                StartDir = StartDir + ( StartAcl * TickInterval )
                StartPos = PredPos
            else
                break
            end
        end
    end
}

Sublimity.FrameStages[ 4 ] = function()
    if Settings.Vars.ProjectilePrediction and Sublimity.ProjectilePredictions[ LocalEx.WeaponClass ] then
        Sublimity.ProjectilePredictions[ LocalEx.WeaponClass ]()
    end
end 

Sublimity.FrameStages[ 5 ] = function()
    if Settings.Vars.FakeFrames then
        ded.SetAbsFrameTime( RenderTime * Settings.Vars.FakeFramesAmt / 10 )
    end
    
end

function Sublimity.PostFrameStageNotify( stage )
    if not Sublimity.FrameStages[ stage ] then return end 
    Sublimity.FrameStages[ stage ]()
end

// On entity created 

function Sublimity.OnEntityCreated( ent )
    if not Validate( ent ) or not Sublimity.EntPreds[ ent:GetClass() ] then return end 

    ent.pin = #Sublimity.ProjectilePaths + 1

    if Sublimity.ProjectilePaths[ ent.pin ] then
        table_remove( Sublimity.ProjectilePaths, ent.pin )
    end

    Sublimity.EntPreds[ ent:GetClass() ]( ent, ent.pin )
end

function Sublimity.EntityRemoved( ent, fullupdate )
    if not ent.pin or fullupdate then return end 

    table_remove( Sublimity.ProjectilePaths, ent.pin )
end

// Override 
Sublimity.OldIsPlayingTaunt = Meta.Player.IsPlayingTaunt 

function Meta.Player:IsPlayingTaunt( arg )
    if arg then return Sublimity.OldIsPlayingTaunt( LocalEntity ) end
    if Settings.Vars.ActSpam and self == LocalEntity then return false end 

    return Sublimity.OldIsPlayingTaunt( LocalEntity )
end

Sublimity.oldConCommand = Meta.Player.ConCommand

function Meta.Player:ConCommand( cmd )
    if Settings.Vars.CameraSpam and cmd == "jpeg" then return end

    Sublimity.oldConCommand( self, cmd )
end



// Hooking 
Sublimity.AddHook( "CalcViewModelView" )
Sublimity.AddHook( "CalcView" )
Sublimity.AddHook( "Think" )
Sublimity.AddHook( "DrawOverlay" )
Sublimity.AddHook( "PostFrameStageNotify" )
Sublimity.AddHook( "CreateMove" )
Sublimity.AddHook( "SendNetMsg")

Sublimity.AddHook( "OnEntityCreated")
Sublimity.AddHook( "EntityRemoved")

Sublimity.AddHook( "PrePlayerDraw" )
Sublimity.AddHook( "PreDrawViewModel" )
Sublimity.AddHook( "PreDrawPlayerHands" )

Sublimity.AddHook( "PostDrawViewModel",     Sublimity.RestoreRender)
Sublimity.AddHook( "PostPlayerDraw",        Sublimity.RestoreRender )
Sublimity.AddHook( "PostDrawPlayerHands",   Sublimity.RestoreRender )

Sublimity.AddHook( "SetupWorldFog" )
Sublimity.AddHook( "SetupSkyboxFog" )

Sublimity.AddHook( "PreRender" )

Sublimity.AddHook( "OnImpact" )

Sublimity.AddHook( "PostDrawOpaqueRenderables" )