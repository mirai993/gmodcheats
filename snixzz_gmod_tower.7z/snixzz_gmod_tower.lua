/*
	
	A set of useful scripts for GMod Tower
	By snixzz @ leak.sx
	
*/

local GMT = {}

GMT["Prefix"] = "swag_" // Prefix for convars/concommands

GMT["Version"] = "1.05 Public Release"
GMT["Updated"] = "5/27/15"

GMT["ConVars"] = {}
GMT["Commands"] = {}
GMT["Hooks"] = {}

// lol
GMT["table.Copy"] = table.Copy
GMT["Copy"] = GMT["table.Copy"]( _G )

GMT["Colors"] = {
"999 0 0", -- RED
"0 0 999", -- BLUE
"0 999 0", -- GREEN
"0 999 999", -- CYAN
"999 999 0", -- YELLOW
"999 999 999", -- WHITE
"999 0 999", -- PURPLE
}

/*
	
	Backend functions
	
*/

function GMT.AddSetting( CVar, Str )
	table.insert( GMT["ConVars"], GMT["Prefix"] .. CVar )
	MsgN( "Added setting '" .. GMT["Prefix"] .. CVar .. "' with value '" .. tostring( Str ) .. "'" )
	CreateClientConVar( GMT["Prefix"] .. CVar, Str, true, false )
end
	
function GMT.AddHook( Type, Func )
	Name = string.Replace( tostring( Func ), "function: ", "" )
	MsgN( "Added hook " .. Name )
	GMT["Hooks"][Type] = Name
	hook["Add"]( Type, Name, Func )
end

function GMT.Setting( Cvar )	
	return GetConVarNumber( GMT["Prefix"] .. Cvar )
end

function GMT.CreatePos( v )
	local ply = LocalPlayer()
	local center = v:LocalToWorld( v:OBBCenter() )
	local min, max = v:OBBMins(), v:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( v:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
	local top	= ( v:GetUp() ) * ( dim.z / 2 )
	local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	local x, y, z = 1.1, 0.9, 1
	local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
	local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
	local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
	local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
	local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
	local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
	local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
	local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
	
	local maxX = math["max"]( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math["min"]( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math["max"]( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math["min"]( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	local maxX2 = math["max"]( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
	local minX2 = math["min"]( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
	local maxY2 = math["max"]( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
	local minY2 = math["min"]( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
	
	return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2
end


/*

	Core functions
	
*/


local Players = player["GetAll"]()
local count = 0

function GMT.HUDPaint()

	-- Simple optimization, thanks HeX
	count = count + 1
	if count > 20000 then
		Players = player["GetAll"]()
		MsgN( "Updating player table" )
		count = 0
	end
	
	for k, v in pairs( Players ) do 
		if ( IsValid( v ) && v:IsPlayer() && v != LocalPlayer() && v:Alive() && GMT.Setting( "esp" ) == 1 ) then
		
			local dist = v:GetPos():Distance( LocalPlayer():GetPos() )
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2 = GMT["CreatePos"]( v )
			local hpcolor = Color( 255, v:Health() * 2.55, v:Health() * 2.55, 255 ) -- i did not make this
		
			if dist < GMT["Setting"]( "esp_dist" ) then
				-- Bounding Box
				if v:GetFriendStatus() == "friend" then
					surface["SetDrawColor"]( Color( 0, 255	, 0 ) )
				else
					surface["SetDrawColor"]( Color( 255, 0, 0 ) )
				end
						
				surface["DrawLine"]( maxX, maxY, maxX, minY )
				surface["DrawLine"]( maxX, minY, minX, minY )
		
				surface["DrawLine"]( minX, minY, minX, maxY )
				surface["DrawLine"]( minX, maxY, maxX, maxY )
		
				-- ESP Text
				-- Name
				draw["SimpleTextOutlined"]( v:Nick(), "font1", maxX2, minY2, team["GetColor"]( v:Team() ), 4, 1, 1, Color( 0, 0, 0 ) )
				draw["SimpleText"]( "HP: " .. v:Health(), "font2", maxX2, minY2 + 10, hpcolor, 4, 1 )
			end
		else
			continue
		end
	end
end

function GMT.CreateMove( cmd, u )
	if GMT["Setting"]( "bunnyhop" ) == 1 then
		if ( !LocalPlayer():IsOnGround() && LocalPlayer():Alive() ) then
			cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )		
		end
	end
	if GMT["Setting"]( "triggerbot" ) == 1 then
		local Trace = LocalPlayer():GetEyeTrace().Entity
		if Trace:IsPlayer() then
			if GMT["Setting"]( "triggerbot_friendly" ) == 1 then
				if Trace:GetFriendStatus() == "friend" then 
					return
				end
			end
			if GMT["Setting"]( "triggerbot_ignoreteam" ) == 1 then
				if Trace:Team() == LocalPlayer():Team() then
					return
				end
			end
			cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_ATTACK ) )
		end
	end
end

// Player Color Changer
timer.Create( GMT["Prefix"] .. "playerColor", 0.25, 0, function()
	if GMT["Setting"]( "playercolor" ) == 1 then
		LocalPlayer():ConCommand( "cl_playercolor " .. table.Random( GMT["Colors"] ) )
		RunConsoleCommand( "gmt_updateplayercolor" )
	end
	
	if GMT["Setting"]( "playerglow" ) == 1 && GMT["Setting"]( "vip" ) == 1 then
		LocalPlayer():ConCommand( "cl_playerglowcolor " .. table["Random"]( GMT["Colors"] ) )
	end
end )

/*

		Anything and EVERYTHING menu related
		
*/

function GMT.CreateOption( dtype, parent, o1, o2, o3, o4, o5, o6, o7 )
	local addx, addy = 3, 3.5
	if ( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, bool, x, y = o1, o2, o3, o4
		local checkbox = vgui.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SizeToContents()
		checkbox:SetTextColor( Color( 255, 255, 255 ) )
		checkbox:SetValue( GMT["Setting"]( GMT["Prefix"] .. bool ) ) 
		checkbox:SetConVar( GMT["Prefix"] .. bool )	
	end
end


/*
	
	LOAD EVERYTHING.
	
*/

surface["CreateFont"]( "font1", { font = "Tahoma", size = 14, weight = 200, antialias = 0 } )
surface["CreateFont"]( "font2", { font = "Tahoma", size = 12, weight = 200, antialias = 0 } )

concommand.Add( GMT["Prefix"] .. "updateplayers", function() Players = player["GetAll"]() end )


//GMT["AddHook"]( "Think", GMT["Think"] )
GMT["AddHook"]( "HUDPaint", GMT["HUDPaint"] )
GMT["AddHook"]( "CreateMove", GMT["CreateMove"] )

surface["PlaySound"]( "buttons/blip1.wav" )
chat["AddText"]( 
Color( 0, 255, 255 ), "[GMT] ",
Color( 255, 255, 255 ), "Loaded version ",
Color( 255, 0, 0 ), GMT["Version"],
Color( 255, 255, 255 ), " (Last updated: ",
Color( 255, 0, 255 ), GMT["Updated"],
Color( 255, 255, 255 ), ")" )
chat["AddText"]( 
Color( 0, 255, 255 ), "[GMT] ",
Color( 0, 255, 0 ), "The command prefix is '",
Color( 255, 255, 255 ), GMT["Prefix"],
Color( 0, 255, 0 ), "'" )
chat["AddText"](
Color( 0, 255, 255 ), "[GMT] ",
Color( 255, 255, 0 ), "Coded by ",
Color( 0, 255, 0 ), "snixzz @ ",
Color( 255, 0, 255 ), "leak.sx" )


/*

	Adding settings

*/

GMT["AddSetting"]( "playercolor", 1 )
GMT["AddSetting"]( "playerglow", 1 )
GMT["AddSetting"]( "bunnyhop", 1 )
GMT["AddSetting"]( "vip", 0 )
GMT["AddSetting"]( "esp", 0 )
GMT["AddSetting"]( "esp_dist", 1500 )
GMT["AddSetting"]( "triggerbot", 1 )
GMT["AddSetting"]( "triggerbot_friendly", 1 )
GMT["AddSetting"]( "triggerbot_ignoreteam", 0 )

concommand.Add( "+" .. GMT["Prefix"] .. "menu", function()
	
	GMT.Panel = vgui.Create( "DFrame" )
	GMT.Panel:SetSize( 220, 300 )
	GMT.Panel:SetTitle( "[GMT] Scripts " .. GMT["Version"] )
	GMT.Panel:SetVisible( true )
	GMT.Panel:SetDraggable( true )
	GMT.Panel:ShowCloseButton( true )
	GMT.Panel:MakePopup()
	GMT.Panel:Center()

	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Are you a VIP?", "vip", 10, 10 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Player Color Changer", "playercolor", 10, 30 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Bunny Hop", "bunnyhop", 10, 50 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Enable ESP", "esp", 10, 70 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Triggerbot", "triggerbot", 10, 90 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Ignore Steam Friends?", "triggerbot_friendly", 10, 110 )
	GMT["CreateOption"]( "CheckBox", GMT.Panel, "Ignore Team?", "triggerbot_ignoreteam", 10, 130 )
	
end )

concommand.Add( "-" .. GMT["Prefix"] .. "menu", function() GMT.Panel:Close() end )

