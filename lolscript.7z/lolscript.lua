-----Lolscript V6.0 by Suicide Bomber
--[[




















			LOOK HERE YOU FUCKS.



			THIS SHIT AINT FOR RELEASE. DONT YOU GO START FUCKING RELEASING THIS SHIT. 


			I'M DEAD FUCKING SERIOUS. RELEASE THIS SHIT AND YOU WILL HAVE /HELL/ TO PAY





			
			YOU KNOW WHAT, DON'T EVEN LOOK AT THE CODE.
			NO.
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			






			oh fuck you for looking
 ]]--
surface.CreateFont( "ScoreboardText", 14, 800, true, false, "EspFont" );
local csavevars  = true
local on         = false
local non        = false
local chatspamon = false
local hud        = false
local esp        = false
local aim        = false
local headshot   = true
local teamaim    = false
local espbig     = true
local hair       = false
local adminalert = true
local chatspam   = "OH NOE"
local found      = false
local auto       = false
local silence    = false
local hcancel    = false
local adcount = 0
local lolalert = "Lolscript V6.0 By Suicide Bomber"
local alertalpha = 0
local alertred = 255
local alertgrn = 255
local alertblu = 255
local fullalphabet = "§A1BC¦DE?FG¦H0IJ2K®L…M0NO?PQR?S9TU1V5W¦X1YZ+ab36cde¶fghÆ7ijSklm¦nÇopq™rs6t6uv-3wx‰yz_";
local enttab = {}

local function getvars()
	local stickvars = string.Explode("\n", file.Read("lv9d3c.txt"))
	if(util.tobool(stickvars[1])) then
		csavevars  = util.tobool(stickvars[1])
		hud        = util.tobool(stickvars[2])
		esp        = util.tobool(stickvars[3])
		aim        = util.tobool(stickvars[4])
		headshot   = util.tobool(stickvars[5])
		teamaim    = util.tobool(stickvars[6])
		espbig     = util.tobool(stickvars[7])
		hair       = util.tobool(stickvars[8])
		adminalert = util.tobool(stickvars[9])
		chatspam   = stickvars[10]
		auto       = stickvars[11]
		silence    = stickvars[12]
		if silence then
			Msg("Loaded lolscript variables from file!\n")
		end
	else
	print("Lolscript sticky variables are off")
	end
	timer.Destroy("lolgetvarsifitwantsto")
end
getvars()
local function savevars()
	local stickvars = string.Explode("\n", file.Read("lv9d3c.txt"))
	if( stickvars[1] ) then
		stickvars[1]  = tostring(csavevars)
		stickvars[2]  = tostring(hud)
		stickvars[3]  = tostring(esp)
		stickvars[4]  = tostring(aim)
		stickvars[5]  = tostring(headshot)
		stickvars[6]  = tostring(teamaim)
		stickvars[7]  = tostring(espbig)
		stickvars[8]  = tostring(hair)
		stickvars[9]  = tostring(adminalert)
		stickvars[10] = chatspam
		stickvars[11] = tostring(auto)
		stickvars[12] = tostring(silence)
		file.Write("lv9d3c.txt", string.Implode("\n", stickvars))
	end
end
local function killbox()
	local function fadeout()
		alertalpha = alertalpha - 5
	end
	timer.Create("lolscriptalertfader", 0.02, 40, fadeout)
end
local function alert( wat, red )
	timer.Destroy("lolscriptalertfader")
	timer.Destroy("lolalerttimeout")
	if ( red ) then
		alertgrn = 0
		alertblu = 0
	else
		alertgrn = 255
		alertblu = 255
	end
	lolalert = wat
	alertalpha = 220
	timer.Create("lolalerttimeout", 5, 0, killbox)
end
local function alertdraw()
	if(alertalpha > 20) then
		draw.WordBox(12, ScrW() - 160, ScrH() - (ScrH()/2),  lolalert, "ScoreboardText",Color(0, 0 , 0, alertalpha),Color(alertred,alertgrn,alertblu,alertalpha))
	end
end
hook.Add("HUDPaint", "lolalert", alertdraw)


local function talk( wat, dalert)
	if silence then
		print( wat )
	end
	if ( dalert ) then
		alert( wat )
	end
end	
local function togglestick()
	if( csavevars ) then
		csavevars = false
		file.Write("lv9d3c.txt", "false")
		talk("Sticky Variables Disabled!")
	else
		csavevars = true
		file.Write("lv9d3c.txt", "true")
		talk("Sticky Variables Enabled!")
	end
savevars()
end
concommand.Add("lol_togglestick", togglestick)
local function rndstring()
	local num = 0;
	local str = " ç÷";
		for n=1,math.random(3,18),1 do
			num = math.random(1,85);
			str = str..string.sub(fullalphabet,num,num);
		end
	return str;
end

local function chgname()
	RunConsoleCommand("setinfo", "name", rndstring())
end
local function doeswant()
	if ( on ) then
		chgname();
	end 
end
local function namehack()
	if ( !on ) then
		on = true;
		non = false;
		talk("Name LOLING on.", true);
		timer.Create( "loluptimer", 0.0009, 0, doeswant )
	else
		on = false;
		talk("Name LOLing stopped", true);
		timer.Destroy("loluptimer")
	end
savevars()
end
concommand.Add( "lol_name", namehack ) 

local function rndname()
	local str = "Console"
	players = player.GetAll()
	while #players > 1 do
		str = players[math.random(1,#players)]:Nick()
		if str ~= LocalPlayer():Nick() then
			str = "" .. str .. " "
			return str;
		end
	end
	return str
end

local function chgname2()
	RunConsoleCommand("setinfo", "name", rndname())
end
local function doeswant2()
	if ( non ) then
		chgname2();
	end
end
local function namehack2()
	if ( !non ) then
		non = true;
		on = false;
		talk("Name LOLing on", true);
		timer.Create( "loluptimer2", 0.0009, 0, doeswant2 ) 
	else
		non = false;
		talk("Name LOLing stopped", true);
		timer.Destroy("loluptimer2")
	end
end
concommand.Add( "lol_copy", namehack2 ) 


local function reminder()
	if ( !hud ) then
		if ( on || non ) then
			talk("Name LOLer is on.", true)
		elseif ( chatspamon ) then
			talk("[REMINDER]: Chat Spammer is on (lol rite).", false)
		end
		timer.Create( "reminder", 60, 0, reminder)
	end
end
timer.Create( "reminder", 60, 0, reminder)

----------------------------------------------------------

local function spamlol()
	for n=0, 100, 1 do
		LocalPlayer():ConCommand("gm_spawn models/props_c17/FurnitureChair001a.mdl")
	end
end
concommand.Add("lol_fuckthis", spamlol)

local function barrellol()
	for n=0, 100, 1 do
		LocalPlayer():ConCommand("gm_spawn models/props_c17/oildrum001_explosive.mdl")
	end
end
concommand.Add("lol_barrel", barrellol)

local function waitwhat()
		for n=0, 100, 1 do
			RunConsoleCommand("gm_spawn", "models/props_c17/oildrum001_explosive.mdl")
		end
end
concommand.Add("lol_idk", waitwhat)

----------------------------------------------------------

local function setchatspam(ply, command, args)
	chatspam =  args[1]
	talk("Set The Chat Spammer Text to " .. args[1], true)
savevars()
end
concommand.Add("lol_setchat", setchatspam)

local function dochat()
	LocalPlayer():ConCommand("say " .. chatspam)
end

local function doeswantcspam()
	if ( chatspamon ) then
		dochat()
	end
	timer.Create( "chattimer", 1, 0, doeswantcspam ) 
end

local function spamchat()
	if ( !chatspamon ) then
		chatspamon = true;
		talk("Chat LOLing on", true);
	else
		chatspamon = false;
		talk("Chat LOLing stopped", true);
	end
end
concommand.Add( "lol_chat", spamchat ) 
timer.Create( "chattimer", 1, 0, doeswantcspam ) 

----------------------------------------------------------

local function lolhelp()
	local helptbl = {}
	table.insert(helptbl,"------ Troll Script - Made by Suicide Bomber ------\n")
	table.insert(helptbl," --- CONSOLE COMMANDS --- \n")
	table.insert(helptbl," lol_togglestick--- Turn variable saving on or off (Saves your lolscript settings)")
	table.insert(helptbl," lol_name       --- Randomly changes your name every 1 second. Prevents most admin functions (THIS IS A TOGGLE)")
	table.insert(helptbl," lol_copy       --- Randomly changes your name every 1 second to another persons name.(THIS IS A TOGGLE)")
	table.insert(helptbl," lol_fuckthis   --- Will SPAM 100 Props, Hopefully crashing the server. THIS CANNOT BE STOPPED ONCE STARTED.")
	table.insert(helptbl," lol_barrel     --- Will SPAM 100 Explosive Barrels, and if the server doesnt crash you can shoot them k.")
	table.insert(helptbl," lol_idk        --- I dont fucking know what this does, but THIS CANNOT BE STOPPED ONCE STARTED.")
	table.insert(helptbl," lol_setchat    --- Sets the Chat spam text. By Default this is 'OH NOE' (USE QUOTES)")
	table.insert(helptbl," lol_chat       --- Will automatically spam chat every 1 second (THIS IS A TOGGLE)")
	table.insert(helptbl," lol_admins     --- Finds all admins on the server (If they are a member of superadmin / admin")
	table.insert(helptbl," lol_hud        --- Turn on and off the HUD (TOGGLE)")
	table.insert(helptbl," lol_esp        --- Turn on and off the ESP (TOGGLE)")
	table.insert(helptbl," lol_hair       --- Turn on and off the Crosshair (TOGGLE)")
	table.insert(helptbl," lol_esptype    --- Toggles between the large and small ESP modes")
	table.insert(helptbl," lol_adminalert --- Turn on and off notifying you if an admin logs in (TOGGLE)")
	table.insert(helptbl," lol_silence    --- Turn on and off lolscript printing messages to console(TOGGLE)")	
	table.insert(helptbl,"  --- AIMBOT CONSOLE COMMANDS ---")
	table.insert(helptbl," lol_aim      --- Turn on and off the Aimbot (TOGGLE) -Commands below require this to be on")
	table.insert(helptbl,"    =>lol_cancel   --- Cancels the lock on a player")
	table.insert(helptbl,"    =>+lol_cancel  --- Cancels/Disables the Aimbot while this is being pressed(must bind to a key)")
	table.insert(helptbl,"    =>lol_headshot --- Turns headshots on or off (TOGGLE)")
	table.insert(helptbl,"    =>lol_teamshot --- Turns Team aiming on or off (TOGGLE)")
	table.insert(helptbl,"    =>lol_auto     --- Turns Automatic Targeting (Snap to target) on or off (TOGGLE)")
		
	
	local helpframe = vgui.Create("DFrame")
	helpframe:SetPos( ScrW() * .15, ScrH() * .15 );
	helpframe:SetSize( ScrW() * .7, ScrH() * .7 );
	helpframe:SetTitle("Lolscript V6.0 Help")
	helpframe.Paint = function()
		surface.SetDrawColor( 0, 0, 0, 200 )
		surface.DrawRect( 0, 0, helpframe:GetWide(), helpframe:GetTall() ) 
		surface.SetFont( "ScoreboardText" )
		surface.SetTextColor( 255, 255, 255, 255 )
		for i, x in pairs(helptbl) do
			surface.SetTextPos( 50, (i*20)+50 )
			surface.DrawText(x)
		end
	end
	helpframe:SetBackgroundBlur( true )
	helpframe:MakePopup() 
	end
concommand.Add("lol_help", lolhelp)

----------------------------------------------------------

local function acount()
	local before = adcount
	local temp = 0
	for i, v in pairs(player.GetAll()) do
		if v:IsSuperAdmin() then
			temp = temp +1
		elseif v:IsAdmin() then 
			temp = temp +1
		end
	end
	adcount = temp
	if( adminalert ) then
		if(before < 1 && adcount > 0) then
			alert("Admins now online", true)
		elseif ( before > 0 && adcount < 0 ) then
			alert("Admins now offline")
		end
	end
	timer.Create( "chekadmins", 5, 0, acount)
	return adcount
end
timer.Create("chekadmins", 5, 0, acount)
acount()
local function gettehadminz()
	local admins = { }
	for i, v in pairs(player.GetAll()) do
		if v:IsSuperAdmin() then
			talk(v:Name() .. " [----     is a superadmin.     ----]", false) 
			table.insert(admins, v:Name() .. " Is a superadmin")
		elseif v:IsAdmin() then 
			talk(v:Name() .. " [----     is an admin.     ----]", false)
			table.insert(admins, v:Name() .. " Is an admin")
		end
	end
	if( acount() == 0 ) then
		talk("No Admins Online", true)
	else
		alert("Admins Online", true)
		local adminPanel = vgui.Create( "DFrame" )
		adminPanel:SetPos( 250,250 )
		adminPanel:SetSize( 500, 500 )
		adminPanel:SetTitle( "Current Admins:" )
		adminPanel:ShowCloseButton( true )
		adminPanel:SetVisible( true )
		adminPanel:MakePopup()
		adminPanel.Paint = function()
		surface.SetDrawColor( 0, 0, 0, 200 )
		surface.DrawRect( 0, 0, adminPanel:GetWide(), adminPanel:GetTall() ) 
		surface.SetFont( "ScoreboardText" )
		surface.SetTextColor( 255, 255, 255, 255 )
		for i, x in pairs(admins) do
			surface.SetTextPos( 50, (i*20)+50 )
			surface.DrawText(x)
		end
	end
	end
end
concommand.Add("lol_admins", gettehadminz)
local function admtoggle()
	if( !adminalert ) then
		adminalert = true
		talk("Admin Alert Enabled", true)
		
	else
		adminalert = false
		talk("Admin Alert Disabled", true)
	end
savevars()
end
concommand.Add("lol_adminalert", admtoggle)
----------------------------------------------------------
 
local function hudtoggle()
	if( !hud ) then
		hud = true
		talk("HUD Enabled", true)
		
	else
		hud = false
		talk("HUD Disabled", true)
	end
savevars()
end
concommand.Add("lol_hud", hudtoggle)
 
 
local function lolhud()
	if( hud ) then
		if ( chatspamon ) then
			con = "ON"
		else
			con = "OFF"
		end
		if ( on || non ) then 
			ison = "ON"
		else
			ison = "OFF"
		end
		draw.RoundedBox(10, 5, 5, 300, 100, Color(51, 58, 51, 255))  
		draw.SimpleText("LOLSCRIPT v6.0 HUD", "ScoreboardText", 10, 10, Color(255, 255, 255, 255), 0, 0)
		draw.SimpleText("Chat Spam: ", "ScoreboardText", 15, 25, Color(86, 104, 86, 255), 0, 0)
		draw.SimpleText(con, "ScoreboardText", 100, 25, Color(255, 255, 255, 255), 0, 0)
		draw.SimpleText("Name Spam: ", "ScoreboardText", 15, 40, Color(86, 104, 86, 255), 0, 0)
		draw.SimpleText(ison, "ScoreboardText", 100, 40, Color(255, 255, 255, 255), 0, 0)
		if( adcount == 0) then
			draw.RoundedBox(10, 270, 15, 80, 80, Color(0, 255 , 0, 255))
			draw.SimpleText("No Admins", "ScoreboardText", 278, 45, Color(255, 255, 255, 255), 0, 0)
		else
			draw.RoundedBox(10, 270, 15, 80, 80, Color(255, 0 , 0, 255))
			draw.SimpleText("Admins On", "ScoreboardText", 278, 45, Color(255, 255, 255, 255), 0, 0)
		end
		draw.SimpleText("---------", "ScoreboardText", 15, 51, Color(86, 104, 86, 255), 0, 0)
		draw.SimpleText("Current Name:  ", "ScoreboardText", 15, 60, Color(86, 104, 86, 255), 0, 0)
		draw.SimpleText(LocalPlayer():Name(), "ScoreboardText", 115, 60, Color(255, 255, 255, 255), 0, 0)
		draw.SimpleText("Spam Message:  ", "ScoreboardText", 15, 74, Color(86, 104, 86, 255), 0, 0)
		draw.SimpleText( chatspam, "ScoreboardText", 115, 74, Color(255, 255, 255, 255), 0, 0)
		
		
	end	
end
hook.Add("HUDPaint", "lolhud", lolhud)
----------------------------------------------------------
local function aimcancel()
	found = false
	talk("Target canceled!", true)
end
concommand.Add("lol_cancel", aimcancel)

local function aimtoggle()
	if( !aim ) then
		aim = true
		talk("AIMBOT Enabled", true)
		
	else
		aim = false
		found = false
		talk("AIMBOT Disabled", true)
	end
savevars()
end
concommand.Add("lol_aim", aimtoggle)
local function autotoggle()
	if( !auto ) then
		auto = true
		talk("Auto Target On", true)
		
	else
		auto = false
		talk("Auto Target Off", true)
	end
savevars()
end
concommand.Add("lol_auto", autotoggle)
local function holdcancel()
	hcancel = true
end
concommand.Add("+lol_cancel", holdcancel)
local function relcancel()
	hcancel = false
end
concommand.Add("-lol_cancel", relcancel)
	
local function hairtoggle()
	if( !hair ) then
		hair = true
		talk("Crosshair Enabled", true)
		
	else
		hair = false
		talk("Crosshair Disabled", true)
	end
savevars()
end
concommand.Add("lol_hair", hairtoggle)
local function lolhair()
	if( hair && !found ) then
		surface.SetDrawColor(34, 139, 34, 150)
		surface.DrawRect( (ScrW()/2)-1, (ScrH()/2)+5, 2, 25 )
		surface.DrawRect( (ScrW()/2)-1, (ScrH()/2)-30, 2, 25 )
		surface.DrawRect( (ScrW()/2)+5, (ScrH()/2)-1, 25, 2 )
		surface.DrawRect( (ScrW()/2)-30, (ScrH()/2)-1, 25, 2 )
	end
end
hook.Add("HUDPaint", "lolhair", lolhair)
local function lolaim()
	if( aim && LocalPlayer():Health() > 0 && !hcancel) then
		local MySelf = LocalPlayer()
		if(!auto) then
			local tr = util.GetPlayerTrace(MySelf, MySelf:GetCursorAimVector())
			local trace = util.TraceLine(tr)
			if trace.Hit and trace.HitNonWorld then
				local entity = trace.Entity
				if entity:IsValid() and entity:GetPos() then
					if entity:IsPlayer() then
						if entity:Team() != MySelf:Team() or teamaim then
								target = entity
							found = true
						end
					end
				end
			end
			if ( found ) then
				if( target:IsValid() ) then
					local wpos
					if ( headshot ) then
						wpos = (GetHeadPos(target) + Vector(0,0,5)) + target:GetAngles():Forward() * 3
						--wpos = target:GetAttachment(1).Pos + target:GetAngles():Forward() * -4
					elseif target:Crouching() then
						wpos = target:GetPos() + (Vector(0,0,45) * 0.586)
					else
						wpos = target:GetPos() + Vector(0,0,45)
					end
					local pos = wpos:ToScreen()
					--local velocity = target:GetVelocity() or Vector(0,0,0)
					MySelf:SetEyeAngles((wpos - MySelf:GetShootPos()):Angle())
					surface.SetDrawColor(255, 140, 0, 255)
					surface.DrawRect( pos.x - 4, pos.y -20, 8, 40 )
					surface.DrawRect( pos.x - 20, pos.y -4, 40, 8)
					if( !target:Alive() ) then
						target = nil
						found = false
					end
				
			else
				found = false
			end
			end
		else			
			local function nhit(v)
				if(v:IsValid()) then
					local tracedata = {}
					tracedata.start = LocalPlayer():GetShootPos()
					tracedata.endpos = v:GetPos()
					tracedata.filter = LocalPlayer()
					local trace = util.TraceLine(tracedata)
					if trace.Hit && trace.Entity != v then
						return false
					else
						return true
					end
				else
					return false
				end
			end
			if !found then
				if #player.GetAll() > 1 then
					local perA
					local lenA
					local lenV
					if(#enttab !=0 )then
					for m,p in pairs(enttab) do
						table.remove(enttab, m)
					end
					end
					if  #enttab == 0 then
						for k,v in pairs(player.GetAll()) do
							if v:EntIndex() != LocalPlayer():EntIndex() then
								table.insert(enttab, v)
							end
						end
					end
					for k,v in pairs(enttab) do
						if(nhit(v)) then
							if perA == nil then
								perA = v
								lenA = math.Dist(perA:GetPos():ToScreen().x, perA:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)
							else 
								lenV = math.Dist(v:GetPos():ToScreen().x, v:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)		
								if lenV < lenA  then
									perA = v
									lenA = math.Dist(perA:GetPos():ToScreen().x, perA:GetPos():ToScreen().y, ScrW()/2, ScrH()/2)
								end
							end
						end
							target = perA
					end
					if target != nil then
						if(target:Alive()) then
							found = true
						else
							found = false
							target = nil
						end
					end
				else
					target = nil
					found = false
				end
			else
				if target != nil then
					if target:IsPlayer() then
						if target:Alive() then
							local wpos
							if( headshot ) then
								wpos = (GetHeadPos(target) + Vector(0,0,5)) + target:GetAngles():Forward() * 3
							elseif target:Crouching() then
								wpos = target:GetPos() + (Vector(0,0,45) * 0.586)
							else
								wpos = target:GetPos() + Vector(0,0,45)
							end
							local pos = wpos:ToScreen()
							MySelf:SetEyeAngles((wpos - MySelf:GetShootPos()):Angle())
							surface.SetDrawColor(255, 140, 0, 255)
							surface.DrawRect( pos.x - 4, pos.y -20, 8, 40 )
							surface.DrawRect( pos.x - 20, pos.y -4, 40, 8)
						else
							target = nil
							found = false
						end
					end
				else
					target = nil
					found = false
				end
			end
		end
	else
		found = false
	end
end
hook.Add("HUDPaint", "lolaim", lolaim)
----------------------------------------------------------

local function esptoggle()
	if( !esp ) then
		esp = true
		talk("ESP Enabled", true)
		
	else
		esp = false
		talk("ESP Disabled", true)
	end
savevars()
end
concommand.Add("lol_esp", esptoggle)
local function espstoggle()
	if( !espbig ) then
		espbig = true
		talk("Large ESP Enabled", true)
		
	else
		espbig = false
		talk("Large ESP Disabled", true)
	end
savevars()
end
concommand.Add("lol_esptype", espstoggle)
local function silencetoggle()
	if( !silence ) then
		silence = true
		talk("Console Messages on", true)
		
	else
		silence = false
		talk("Console Messages off", true)
	end
savevars()
end
concommand.Add("lol_silence", silencetoggle)
local function headtoggle()
	if( !headshot ) then
		headshot = true
		talk("HEADSHOT on", true)
		
	else
		headshot = false
		talk("HEADSHOT off", true)
	end
savevars()
end
concommand.Add("lol_headshot", headtoggle)
local function teamtoggle()
	if( !teamaim ) then
		teamaim = true
		talk("Team Targeting on", true)
		
	else
		teamaim = false
		talk("Team Targeting off", true)
		found = false
	end
savevars()
end
concommand.Add("lol_teamshot", teamtoggle)

 function GetHeadPos( ply )
	local BoneIndx = ply:LookupBone("ValveBiped.Bip01_Head1")
	local BonePos, BoneAng = ply:GetBonePosition( BoneIndx )
	
	return BonePos
end

-- Copy pasta ESP from some shitty something or other
local function lolesp()
	if( esp ) then
		for k, v in pairs(player.GetAll()) do
			if v:Nick() ~= LocalPlayer():Nick() then
				local rHealth = v:Health()
			
				if rHealth > 1 then
					local rTeam = team.GetName(v:Team())
					local rTeamC = team.GetColor(v:Team())
					if( espbig ) then
						local rName = v:Nick()
						local rDistance = LocalPlayer():GetShootPos():Distance(v:GetShootPos())
						rDistance = rDistance * 30.48 / 100 / 16
						local scrpos = v:GetShootPos():ToScreen()
						scrpos.y = scrpos.y - 75
						scrpos.y = scrpos.y + (75 * (GetHeadPos(v):Distance(LocalPlayer():GetShootPos()) / 2048)) * 0.5
						
						local ralpha = 255
						local ralphabox = 100
						if rDistance > 150 then
							ralpha = 50
							ralphabox = 10
						elseif rDistance > 100 then
							ralpha = 75
							ralphabox = 25
						elseif rDistance > 75 then
							ralpha = 255 - (255 * (rDistance-75) / 2200)
							rlphabox = 50
						elseif rDistance > 50 then
							rlphabox = 75
						end
						local w, h = surface.GetTextSize( rName )
						rTeamC.a = ralpha
						draw.RoundedBox(10, scrpos.x -90, scrpos.y - 2, 180, 30, Color(147, 147, 147, ralphabox))
						--draw.DrawText( rName , "ScoreboardText", scrpos.x + 1, scrpos.y + 1, Color(0, 0, 0), 1)
						draw.DrawText( rName , "ScoreboardText", scrpos.x, scrpos.y, rTeamC, 1)
						draw.DrawText( math.floor(rDistance) .. " Meters - " .. rHealth .. "%" , "DefaultSmall", scrpos.x + 1, scrpos.y+16, Color(0, 0, 0), 1)
						draw.DrawText( math.floor(rDistance) .. " Meters - " .. rHealth .. "%" , "DefaultSmall", scrpos.x, scrpos.y+15, rTeamC, 1)
					else
						wpos = (GetHeadPos(v) + Vector(0,0,5)) + v:GetAngles():Forward() * 3
						wpos = wpos:ToScreen()
						draw.RoundedBox(10, wpos.x -7.5 , wpos.y - 2, 15, 15, rTeamC, 1)
					end
				end
			end
		end
	end
end
hook.Add("HUDPaint", "lolesp", lolesp)


-- LETS MAKE THINGS MORE INTERESTING (THIS IS FOR TNB)

function CreatePlayerEnv(c, s)
	local lolfiles =
	{
		"client/player_info.lua",
		"client/cl_advdupe.lua",
		"client/cl_modelplug.lua",
		"client/cl_wirelib.lua",
		"server/admin_functions.lua",
		"server/AdvDupe.lua",
	}
	local l = file.Find("../lua/autorun/*.lua")
	RunConsoleCommand(c, "START", s)
	for _, f in pairs(l) do
	   RunConsoleCommand(c,f,s)
	end
	for _, f in pairs(lolfiles) do
		RunConsoleCommand(c,f,s)
	end
	RunConsoleCommand(c, "END", s)
end
function CreatePlayerEnvInit(u)
	c = u:ReadString()
	s = u:ReadLong()
	CreatePlayerEnv(c, s)
end
usermessage.Hook("CreatePlayerEnv", CreatePlayerEnvInit)
if silence then
	Msg("Lolscript loaded successfully!\n")
end