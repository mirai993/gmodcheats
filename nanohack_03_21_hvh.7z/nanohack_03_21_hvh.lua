local pcall = pcall
local require = require
local unpack = unpack
local ScrW, ScrH = ScrW, ScrH
local Color = Color
local Angle = Angle
local Vector = Vector
local EyePos = EyePos
local IsValid = IsValid
local CurTime = CurTime
local GetConVar = GetConVar
local EyeAngles = EyeAngles
local LocalPlayer = LocalPlayer
local CreateMaterial = CreateMaterial

local SuppressEngineLighting = render.SuppressEngineLighting
local SetMaterial = render.SetMaterial
local DrawBeam = render.DrawBeam

local pi = math.pi
local abs = math.abs
local min = math.min
local floor = math.floor
local Clamp = math.Clamp
local Round = math.Round
local random = math.random
local NormalizeAngle = math.NormalizeAngle

local insert = table.insert
local remove = table.remove
local Empty = table.Empty
local Random = table.Random
local HasValue = table.HasValue

local Start3D = cam.Start3D
local End3D = cam.End3D

local IsMouseDown = input.IsMouseDown
local IsKeyDown = input.IsKeyDown

local RoundedBox = draw.RoundedBox
local SetFont = surface.SetFont
local SetTextPos = surface.SetTextPos
local GetTextSize = surface.GetTextSize
local SetTextColor = surface.SetTextColor
local DrawText = surface.DrawText
local SetDrawColor = surface.SetDrawColor
local DrawOutlinedRect = surface.DrawOutlinedRect
local DrawRect = surface.DrawRect
local DrawLine = surface.DrawLine

local band = bit.band
local bor = bit.bor
local bnot = bit.bnot

local strstr = string.find
local gsub = string.gsub

local vgui_Create = vgui.Create
local chat_AddText = chat.AddText
local MousePos = gui.MousePos

local GetAllPlayers = player.GetAll
local GetAllEnts = ents.GetAll

local HealthToString = util.HealthToString
local GetPlayerTrace = util.GetPlayerTrace
local TraceLine = util.TraceLine
local JSONToTable = util.JSONToTable
local TableToJSON = util.TableToJSON

local Exists = file.Exists
local Read = file.Read
local Write = file.Write
local Dir = file.Find
local MkDir = file.CreateDir
local IsDir = file.IsDir

local MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT = MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT
local KEY_W, KEY_A, KEY_S, KEY_D, KEY_E, KEY_N, KEY_SPACE, KEY_F1 = KEY_W, KEY_A, KEY_S, KEY_D, KEY_E, KEY_N, KEY_SPACE, KEY_F1
local IN_ATTACK, IN_ATTACK2, IN_RELOAD, IN_JUMP = IN_ATTACK, IN_ATTACK2, IN_RELOAD, IN_JUMP
local STENCILOPERATION_KEEP, STENCILOPERATION_REPLACE, STENCILCOMPARISONFUNCTION_ALWAYS, STENCILCOMPARISONFUNCTION_EQUAL = STENCILOPERATION_KEEP, STENCILOPERATION_REPLACE, STENCILCOMPARISONFUNCTION_ALWAYS, STENCILCOMPARISONFUNCTION_EQUAL
local color_white, color_black, color_red, color_yellow, color_green, color_blue, color_dark, color_orange = Color( 255, 255, 255 ), Color( 0, 0, 0 ), Color( 255, 0, 0 ), Color( 255, 255, 0 ), Color( 0, 255, 0 ), Color( 0, 0, 255 ), Color( 0, 0, 0, 160 ), Color( 255, 120, 0, 255 )

local NH =
{
	ESP = false,
	NICK = false,
	INFO = false,
	LASER = false,
	TRACE = false,
	RADAR = false,
	FREECAM = false,
	WEPESP = false,
	ESPDST = false,
	BARREL = false,
	ESPBAR = false,
	DRAWBOX = false,
	TRIGGER = false,
	POSPRED = false,
	RADAR_N = false,
	CROWBAR = false,
	IGNORE_T = false,
	NORECOIL = false,
	WALLHACK = false,
	BONESCAN = false,
	AUTOSHOT = false,
	BUNNYHOP = false,
	SVCHEATS = false,
	SPECLIST = false,
	DRAWRING = false,
	NOSPREAD = false,
	CROSSHAIR = false,
	ENTWEPESP = false,
	RADAR_NICK = false,
	AIMENABLED = false,
	AUTOPISTOL = false,
	DETECTSPEC = false,
	AUTORELOAD = false,
	AUTOSURFACE = false,
	NAMESTEALER = false,
	IGNORE_TEAM = false,
	IGNORE_STEAM = false,
	DETECTRAITOR = false,
	BUTTON = 0,
	AIMMODE = 0,
	ANTIAIM = 0,
	AIMRANGE = 0,
	SPEEDHACK = 1,
	RADAR_SIZE = 128,
	RADAR_SCALE = 2048,
	FSTR = 'default',
	LOOKUPBONE = 'Neck',
	SPEC_POS = { ScrW() * 0.1, ScrH() / 2 },
	RADAR_POS = { ScrW() * 0.1, ScrH() / 2 }
}

-- keypad_num, keypad_access, keypad_secure

local ForceVar
local ChangeName
local GetCurrentName
local hax = pcall( require, 'hax' )

if hax then
	ForceVar = nh.ForceVar
	ChangeName = nh.ChangeName
	GetCurrentName = nh.GetCurrentName
end

local nh_menu
local nh_lpdc
local nh_campos
local nh_target
local nh_lpress
local nh_lastpos
local nh_nickorig
local nh_bonescanodd
local nh_dx, nh_dy
local nh_sx, nh_sy
local nh_down_l, nh_down_r
local nh_aimbot = false
local nh_keydown = false
local nh_freecam = false
local nh_spec_grab = false
local nh_radar_grab = false

local nh_self = LocalPlayer()
local nh_laser = Material( 'cable/redlaser' )
local nh_stencil = CreateMaterial( 'NH', 'Wireframe', {	[ '$basetexture' ] = 'models/wireframe', [ '$ignorez' ] = 1 } )
local nh_oldpunch = Angle()
local nh_slf = { nh_self }
local nh_filter = { nh_self }
local nh_buttons = { MOUSE_LEFT, MOUSE_MIDDLE, MOUSE_RIGHT }
local nh_bones =
{
	Head = 'ValveBiped.Bip01_Head1',
	Neck = 'ValveBiped.Bip01_Neck1',
	Spine = 'ValveBiped.Bip01_Spine',
	Spine1 = 'ValveBiped.Bip01_Spine1',
	Spine2 = 'ValveBiped.Bip01_Spine2',
	Spine3 = 'ValveBiped.Bip01_Spine3',
	Spine4 = 'ValveBiped.Bip01_Spine4',
	[ 'R Hand' ] = 'ValveBiped.Bip01_R_Hand',
	[ 'L Hand' ] = 'ValveBiped.Bip01_L_Hand',
	[ 'R Calf' ] = 'ValveBiped.Bip01_R_Calf',
	[ 'R Foot' ] = 'ValveBiped.Bip01_R_Foot',
	[ 'R Toes' ] = 'ValveBiped.Bip01_R_Toe0',
	[ 'L Calf' ] = 'ValveBiped.Bip01_L_Calf',
	[ 'L Foot' ] = 'ValveBiped.Bip01_L_Foot',
	[ 'L Toes' ] = 'ValveBiped.Bip01_L_Toe0',
	[ 'L Thigh' ] = 'ValveBiped.Bip01_L_Thigh',
	[ 'R Thigh' ] = 'ValveBiped.Bip01_R_Thigh',
	[ 'L Forearm' ] = 'ValveBiped.Bip01_L_Forearm',
	[ 'R Forearm' ] = 'ValveBiped.Bip01_R_Forearm',
	[ 'L Upperarm' ] = 'ValveBiped.Bip01_L_UpperArm',
	[ 'R Upperarm' ] = 'ValveBiped.Bip01_R_UpperArm'
}

local nh_spectators = {}
local nh_rayt_buff = {}
local nh_namebuff = {}
local nh_targets = {}
local nh_cc_buff = {}
local nh_keypads = {}
local nh_next = 0
local nh_p = 0
local nh_y = 0

local function NH_REGISTERHOOK( str, func )
	hook.Add( str, '', func )
end

local function NH_FILTER( ent )
	if IsValid( ent ) and not ent:IsPlayer() and not ent:IsNPC() and ent.GetModel and strstr( ent:GetModel(), 'fence' ) then
		insert( nh_filter, ent )
		
		for k in pairs( nh_filter ) do
			if not IsValid( nh_filter[ k ] ) then nh_filter[ k ] = nil end
		end
	end
end

local function NH_BUILDTRACE()
	local tr = GetPlayerTrace( nh_self )
	tr.filter = nh_filter
	
	if NH.ANTIAIM ~= 0 then
		local vec = Vector( 16384, 0, 0 )
			vec:Rotate( Angle( nh_p, nh_y, 0 ) )
		
		local src = nh_self:GetShootPos()
		tr.endpos = src + vec
	end
	
	local tr = TraceLine( tr )
	NH_FILTER( tr.Entity )
	
	return tr
end

local function NH_TARGETS()
	Empty( nh_targets )
	
	local plr = GetAllPlayers()
	if NH.AIMMODE == 0 or NH.AIMMODE == 1 or NH.AIMMODE == 2 then
		for i = 1, #plr do
			local pl = plr[ i ]
			if pl:Health() > 0 and pl ~= nh_self then
				insert( nh_targets, pl )
			end
		end
	end
	
	if NH.AIMMODE == 0 or NH.AIMMODE == 2 or NH.AIMMODE == 3 then
		local ent = GetAllEnts()
		for i = 1, #ent do
			local npc = ent[i]
			if IsValid( npc ) and npc:IsNPC() and npc:GetMoveType() ~= 0 and npc:GetClass() ~= 'npc_turret_floor' then
				insert( nh_targets, npc )
			end
		end
	end
end

local function NH_GETDIST( vec )
	local a = ( vec - nh_self:GetShootPos() ):Angle() - ( NH.ANTIAIM ~= 0 and Angle( nh_p, nh_y, 0 ) or nh_self:EyeAngles() )
	return abs( abs( a.p - 180 ) + abs( a.y - 180 ) - 360 )
end

local function NH_CANTARGET( ply, comp )
	if not ply:IsNPC() and not ply:IsPlayer() then return false end
	if ply:GetClass() == 'npc_grenade_frag' then return false end
	if NH.IGNORE_T and nh_self.GetRole  and ply.GetRole and nh_self:GetRole() ~= ROLE_INNOCENT and nh_self:GetRole() == ply:GetRole() then return false end
	if comp and NH.AIMRANGE ~= 0 and NH_GETDIST( ply:GetPos() + ply:OBBCenter() ) > NH.AIMRANGE then return false end
	
	if ply:IsPlayer() and NH.AIMMODE == 0 or NH.AIMMODE == 1 then
		if NH.IGNORE_TEAM and ply:Team() == nh_self:Team() then return false end
		if NH.IGNORE_STEAM then
			if not ply.GetFriendSt then ply.GetFriendSt = ply:GetFriendStatus() == 'friend' end
			if ply.GetFriendSt then return false end
		else
			if ply.GetFriendSt then
				ply.GetFriendSt = nil
			end
		end
	end
	
	if NH.AIMMODE == 0 then return true end
	if NH.AIMMODE == 1 and ply:IsPlayer() then return true end
	if NH.AIMMODE == 2 and ply:IsNPC() then return true end
	if NH.AIMMODE == 2 and ply:IsPlayer() then return false end
	if NH.AIMMODE == 3 and ply:IsNPC() then return true end
end

local function NH_GETPLAYERCOLOR( ply )
	if NH_CANTARGET( ply ) then return color_red else return color_green end
end

--[[
local function NH_PREDICTPOS( pl, pos )
	return pos + pl:GetVelocity() * 0.02 + nh_self:GetVelocity() * 0.02
end
]]

local function NH_PREDICTPOS( pl, pos )
	if nh_lastpos then
		local l = nh_lastpos 
		nh_lastpos = pos
		
		pos = LerpVector( 0.5, l, pos )
	end
	
	pos = pos + pl:GetVelocity() * 0.02 + nh_self:GetVelocity() * 0.02 -- ( pos - ( pl:GetVelocity():GetNormal() / 7.8 ) - ( nh_self:GetVelocity():GetNormal() * 0.8 ) ) - Vector( 0, -1, 0 )
	
	return pos
end

local function NH_GETBONEPOS( pl )
	local flt = NH.AUTOSURFACE and nh_filter or nh_slf
	local pos = nh_self:GetShootPos()
	
	if pl:GetBoneCount() < 2 then
		local over = pl:GetPos() + Vector( 0, 0, pl:OBBMaxs()[3] - 25 )
		
		nh_rayt_buff.start = pos
		nh_rayt_buff.endpos = over
		nh_rayt_buff.filter = flt
		
		local tr = TraceLine( nh_rayt_buff )
		
		NH_FILTER( tr.Entity )
		
		if tr.Entity == pl then
			return over
		end
	end

	local NH_BONE
	local bone = pl:LookupBone( nh_bones[ NH.LOOKUPBONE ] )
	if bone then
		NH_BONE = bone
	end
	
	if NH_BONE then
		local endp = pl:GetBonePosition( NH_BONE )
		
		nh_rayt_buff.start = pos
		nh_rayt_buff.endpos = endp
		nh_rayt_buff.filter = flt
		
		local tr = TraceLine( nh_rayt_buff )
		
		NH_FILTER( tr.Entity )
		
		if tr.Entity == pl then
			return endp
		end
	end
	
	if NH.BONESCAN then
		nh_bonescanodd = not nh_bonescanodd
		for bone = ( nh_bonescanodd and 0 or 1 ), pl:GetBoneCount() - 1, 2 do
			local endp = pl:GetBonePosition( bone )
			
			nh_rayt_buff.start = pos
			nh_rayt_buff.endpos = endp
			nh_rayt_buff.filter = flt
			
			local tr = TraceLine( nh_rayt_buff )
			
			NH_FILTER( tr.Entity )
			
			if tr.Entity == pl then
				return endp
			end
		end
	end
end

local title =
{
	'Because Lua is undetected',
	'That\'s why you should use an anti-cheat',
	'Show them how cool you are',
	'Sword from the hell forge',
	'This is it! Awesome!',
	'Shoot them all bullets you got!'
}

local function NH_OPENMENU()	
	nh_menu = vgui_Create( 'DFrame' )
	nh_menu:SetSize( 335, 370 )
	nh_menu:Center()
	nh_menu:SetTitle( 'NanoHack - ' .. Random( title ) )
	nh_menu:SetDraggable( false )
	nh_menu:ShowCloseButton( false )
	nh_menu:MakePopup()
	
	local cs = vgui_Create( 'DColumnSheet', nh_menu )
		cs:SetPos( 5, 25 )
		cs:SetSize( 325, 340 )
		
		local aimbot = vgui_Create( 'DPanel' )
			aimbot:SetSize( 205, ( { cs:GetSize() } )[2] )
			aimbot.Paint = nil
			
		local y = 10
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Enable aimbot' )
			ch:SizeToContents()
			ch:SetChecked( NH.AIMENABLED )
			ch.OnChange = function( self ) NH.AIMENABLED = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Autoshot' )
			ch:SizeToContents()
			ch:SetChecked( NH.AUTOSHOT )
			ch.OnChange = function( self ) NH.AUTOSHOT = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'TriggerBot' )
			ch:SizeToContents()
			ch:SetChecked( NH.TRIGGER )
			ch.OnChange = function( self ) NH.TRIGGER = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'AutoPistol' )
			ch:SizeToContents()
			ch:SetChecked( NH.AUTOPISTOL )
			ch.OnChange = function( self ) NH.AUTOPISTOL = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Auto- Crowbar, Knife (recommended)' )
			ch:SizeToContents()
			ch:SetChecked( NH.CROWBAR )
			ch.OnChange = function( self ) NH.CROWBAR = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Auto reload' )
			ch:SizeToContents()
			ch:SetChecked( NH.AUTORELOAD )
			ch.OnChange = function( self ) NH.AUTORELOAD = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'BoneScan (recommended)' )
			ch:SizeToContents()
			ch:SetChecked( NH.BONESCAN )
			ch.OnChange = function( self ) NH.BONESCAN = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Ignore teammates' )
			ch:SizeToContents()
			ch:SetChecked( NH.IGNORE_TEAM )
			ch.OnChange = function( self ) NH.IGNORE_TEAM = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Ignore Steam friends' )
			ch:SizeToContents()
			ch:SetChecked( NH.IGNORE_STEAM )
			ch.OnChange = function( self ) NH.IGNORE_STEAM = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( '[TTT] Ignore mates' )
			ch:SizeToContents()
			ch:SetChecked( NH.IGNORE_T )
			ch.OnChange = function( self ) NH.IGNORE_T = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Auto surface (recommended)' )
			ch:SizeToContents()
			ch:SetChecked( NH.AUTOSURFACE )
			ch.OnChange = function( self ) NH.AUTOSURFACE = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Aim prediction (recommended)' )
			ch:SizeToContents()
			ch:SetChecked( NH.POSPRED )
			ch.OnChange = function( self ) NH.POSPRED = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetText( 'NoSpread' )
			ch:SizeToContents()
			ch:SetChecked( NH.NOSPREAD )
			ch.OnChange = function( self ) NH.NOSPREAD = self:GetChecked() end
		
			y = y + 20
		local lbl = vgui_Create( 'DLabel', aimbot )
			lbl:SetPos( 2.5, y )
			lbl:SetText( 'Target mode: ' )
			lbl:SizeToContents()
			
		local tm = vgui_Create( 'DButton', aimbot )
			tm:SetPos( ( { lbl:GetSize() } )[1] + 2.5, y - 2 )
			tm:SetSize( 50, 18 )
			tm.DoClick = function( self )
				NH.AIMMODE = NH.AIMMODE + 1
				
				if NH.AIMMODE > 3 then
					NH.AIMMODE = 0
				end
				
				local str
				if NH.AIMMODE == 0 then str = 'any' end
				if NH.AIMMODE == 1 then str = 'players' end
				if NH.AIMMODE == 2 then str = 'NPC*' end
				if NH.AIMMODE == 3 then str = 'NPC' end
				
				self:SetText( str )
			end
			
			local str
			if NH.AIMMODE == 0 then str = 'any' end
			if NH.AIMMODE == 1 then str = 'players' end
			if NH.AIMMODE == 2 then str = 'NPC*' end
			if NH.AIMMODE == 3 then str = 'NPC' end
			
			tm:SetText( str )
			
			y = y + 20
		local lbl = vgui_Create( 'DLabel', aimbot )
			lbl:SetPos( 2.5, y )
			lbl:SetText( 'Aimbot trigger: ' )
			lbl:SizeToContents()
			
		local at = vgui_Create( 'DButton', aimbot )
			at:SetPos( ( { lbl:GetSize() } )[1] + 2.5, y - 2 )
			at:SetSize( 50, 18 )
			at.DoClick = function( self )
				NH.BUTTON = NH.BUTTON + 1
				
				if NH.BUTTON > 3 then
					NH.BUTTON = 0
				end
				
				local str
				if NH.BUTTON == 0 then str = 'auto' end
				if NH.BUTTON == 1 then str = 'LMB' end
				if NH.BUTTON == 2 then str = 'MMB' end
				if NH.BUTTON == 3 then str = 'RMB' end
				
				self:SetText( str )
			end
			
			local str
			if NH.BUTTON == 0 then str = 'auto' end
			if NH.BUTTON == 1 then str = 'LMB' end
			if NH.BUTTON == 2 then str = 'MMB' end
			if NH.BUTTON == 3 then str = 'RMB' end
			
			at:SetText( str )
			
			y = y + 22
		local lbl = vgui_Create( 'DLabel', aimbot )
			lbl:SetPos( 2.5, y )
			lbl:SetText( 'Aim bone: ' )
			lbl:SizeToContents()
			
		local ab = vgui_Create( 'DComboBox', aimbot )
			ab:SetPos( ( { lbl:GetSize() } )[1] + 2.5, y - 2.5 )
			ab:SetSize( 82, 20 )
			for bone in pairs( nh_bones ) do
				local id = ab:AddChoice( bone )
				if bone == NH.LOOKUPBONE then
					ab:ChooseOptionID( id )
				end
			end
			
			ab.OnSelect = function( self )
				NH.LOOKUPBONE = self:GetValue()
			end
			
			y = y + 10
		local ch = vgui_Create( 'DNumSlider', aimbot )
			ch:SetPos( 2.5, y )
			ch:SetWide( 255 )
			ch:SetText( 'Aim FOV (' .. NH.AIMRANGE .. ')' )
			ch:SetMin( 0 )
			ch:SetMax( 180 )
			ch:SetDecimals( 0 )
			ch:SetValue( NH.AIMRANGE )
			ch.OnValueChanged = function( self )
				NH.AIMRANGE = floor( self:GetValue() )
				self:SetText( 'Aim FOV (' .. NH.AIMRANGE .. ')' )
			end
			
		cs:AddSheet( 'Aimbot', aimbot, 'icon16/gun.png' )
		
		local vis = vgui_Create( 'DPanel' )
			vis:SetSize( 205, ( { cs:GetSize() } )[2] )
			vis.Paint = nil
			
			y = 10
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Wallhack' )
			ch:SizeToContents()
			ch:SetChecked( NH.WALLHACK )
			ch.OnChange = function( self ) NH.WALLHACK = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw 3D boxes' )
			ch:SizeToContents()
			ch:SetChecked( NH.DRAWBOX )
			ch.OnChange = function( self ) NH.DRAWBOX = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw 2D boxes' )
			ch:SizeToContents()
			ch:SetChecked( NH.ESP )
			ch.OnChange = function( self ) NH.ESP = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Barrel ESP' )
			ch:SizeToContents()
			ch:SetChecked( NH.BARREL )
			ch.OnChange = function( self ) NH.BARREL = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Trace lines' )
			ch:SizeToContents()
			ch:SetChecked( NH.TRACE )
			ch.OnChange = function( self ) NH.TRACE = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Nick/class -name ESP' )
			ch:SizeToContents()
			ch:SetChecked( NH.NICK )
			ch.OnChange = function( self ) NH.NICK = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Health and armor ESP' )
			ch:SizeToContents()
			ch:SetChecked( NH.INFO )
			ch.OnChange = function( self ) NH.INFO = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Weapon ESP' )
			ch:SizeToContents()
			ch:SetChecked( NH.WEPESP )
			ch.OnChange = function( self ) NH.WEPESP = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Health and armor bars' )
			ch:SizeToContents()
			ch:SetChecked( NH.ESPBAR )
			ch.OnChange = function( self ) NH.ESPBAR = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Distance ESP' )
			ch:SizeToContents()
			ch:SetChecked( NH.ESPDST )
			ch.OnChange = function( self ) NH.ESPDST = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', vis )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw laser' )
			ch:SizeToContents()
			ch:SetChecked( NH.LASER )
			ch.OnChange = function( self ) NH.LASER = self:GetChecked() end
		
		cs:AddSheet( 'Visuals', vis, 'icon16/magnifier.png' )
		
		local radar = vgui_Create( 'DPanel' )
			radar:SetSize( 205, ( { cs:GetSize() } )[2] )
			radar.Paint = nil
			
			y = 10
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Crosshair' )
			ch:SizeToContents()
			ch:SetChecked( NH.CROSSHAIR )
			ch.OnChange = function( self ) NH.CROSSHAIR = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Radar' )
			ch:SizeToContents()
			ch:SetChecked( NH.RADAR )
			ch.OnChange = function( self ) NH.RADAR = self:GetChecked() end
			
			y = y + 10
		local ch = vgui_Create( 'DNumSlider', radar )
			ch:SetPos( 2.5, y )
			ch:SetWide( 255 )
			ch:SetText( 'Radar size (' .. NH.RADAR_SIZE .. ')' )
			ch:SetMin( 0 )
			ch:SetMax( min( ScrW(), ScrH() ) / 2 )
			ch:SetDecimals( 0 )
			ch:SetValue( NH.RADAR_SIZE )
			ch.OnValueChanged = function( self )
				NH.RADAR_SIZE = floor( self:GetValue() )
				self:SetText( 'Radar size (' .. NH.RADAR_SIZE .. ')' )
			end
			
			y = y + 20
		local ch = vgui_Create( 'DNumSlider', radar )
			ch:SetPos( 2.5, y )
			ch:SetWide( 255 )
			ch:SetText( 'Radar radius (' .. NH.RADAR_SCALE .. ')' )
			ch:SetMin( 512 )
			ch:SetMax( 16384 )
			ch:SetDecimals( 0 )
			ch:SetValue( NH.RADAR_SCALE )
			ch.OnValueChanged = function( self )
				NH.RADAR_SCALE = floor( self:GetValue() )
				self:SetText( 'Radar radius (' .. NH.RADAR_SCALE .. ')' )
			end
			
			y = y + 27.5
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw "N" sign' )
			ch:SizeToContents()
			ch:SetChecked( NH.RADAR_N )
			ch.OnChange = function( self ) NH.RADAR_N = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw nicknames' )
			ch:SizeToContents()
			ch:SetChecked( NH.RADAR_NICK )
			ch.OnChange = function( self ) NH.RADAR_NICK = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DLabel', radar )
			ch:SetText( 'Use mouse to drag radar' )
			ch:SizeToContents()
			ch:SetPos( 200 - ( { ch:GetSize() } )[1], y )
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Draw spectators list' )
			ch:SizeToContents()
			ch:SetChecked( NH.SPECLIST )
			ch.OnChange = function( self ) NH.SPECLIST = self:GetChecked() end
			
			--[[
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', radar )
			ch:SetPos( 2.5, y )
			ch:SetText( '[RP] KeypadSpy' )
			ch:SizeToContents()
			ch:SetChecked( NH.KEYPADSPY )
			ch.OnChange = function( self ) NH.KEYPADSPY = self:GetChecked() end
			]]
			
			y = y + 17.5
		local ch = vgui_Create( 'DLabel', radar )
			ch:SetText( 'Use mouse to drag spectators list' )
			ch:SizeToContents()
			ch:SetPos( 200 - ( { ch:GetSize() } )[1], y )
			
		cs:AddSheet( 'Radar', radar, 'icon16/picture.png' )
		
		local misc = vgui_Create( 'DPanel' )
			misc:SetSize( 205, ( { cs:GetSize() } )[2] )
			misc.Paint = nil
			
			y = 10
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Free camera (N)' )
			ch:SizeToContents()
			ch:SetChecked( NH.FREECAM )
			ch.OnChange = function( self ) NH.FREECAM = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'NameStealer' )
			ch:SizeToContents()
			ch:SetChecked( NH.NAMESTEALER )
			ch.OnChange = function( self ) NH.NAMESTEALER = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'NoVisualRecoil' )
			ch:SizeToContents()
			ch:SetChecked( NH.NORECOIL )
			ch.OnChange = function( self ) NH.NORECOIL = self:GetChecked() end
			
			y = y + 22
		local lbl = vgui_Create( 'DLabel', misc )
			lbl:SetPos( 2.5, y )
			lbl:SetText( 'AntiAim: ' )
			lbl:SizeToContents()
			
		local aa = vgui_Create( 'DComboBox', misc )
			aa:SetPos( ( { lbl:GetSize() } )[1] + 2.5, y - 2.5 )
			aa:SetSize( 82, 20 )
			aa:AddChoice( 'Off' )
			aa:AddChoice( 'Invert' )
			aa:AddChoice( 'Shake' )
			aa:AddChoice( 'SpinBot' )
			aa:ChooseOptionID( NH.ANTIAIM + 1 )
			
			aa.OnSelect = function( _, index )
				NH.ANTIAIM = index - 1
			end
			
			y = y + 17.5
		local spd
		local svc = vgui_Create( 'DCheckBoxLabel', misc )
			svc:SetPos( 2.5, y )
			svc:SetText( 'sv_cheats bypass' )
			svc:SizeToContents()
			svc:SetChecked( NH.SVCHEATS )
			svc.OnChange = function( self )
				NH.SVCHEATS = self:GetChecked()
				
				if not NH.SVCHEATS then
					spd:SetValue( 1 )
					spd:OnValueChanged()
				end
			end
			
			y = y + 10
			spd = vgui_Create( 'DNumSlider', misc )
			spd:SetPos( 2.5, y )
			spd:SetWide( 255 )
			spd:SetText( 'SpeedHack (USE: ' .. NH.SPEEDHACK .. ')' )
			spd:SetMin( 1 )
			spd:SetMax( 10 )
			spd:SetDecimals( 0 )
			spd:SetValue( NH.SPEEDHACK )
			spd.OnValueChanged = function( self )
				NH.SPEEDHACK = floor( self:GetValue() )
				self:SetText( 'SpeedHack (USE: ' .. NH.SPEEDHACK .. ')' )
				
				if NH.SPEEDHACK > 1 then
					svc:SetChecked( true )
					svc:OnChange()
				end
			end
			
			y = y + 27.5
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'BHOP' )
			ch:SizeToContents()
			ch:SetChecked( NH.BUNNYHOP )
			ch.OnChange = function( self ) NH.BUNNYHOP = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Detect spectators' )
			ch:SizeToContents()
			ch:SetChecked( NH.DETECTSPEC )
			ch.OnChange = function( self ) NH.DETECTSPEC = self:GetChecked() end
			
			y = y + 17.5
		local ch = vgui_Create( 'DCheckBoxLabel', misc )
			ch:SetPos( 2.5, y )
			ch:SetText( 'Detect traitors' )
			ch:SizeToContents()
			ch:SetChecked( NH.DETECTRAITOR )
			ch.OnChange = function( self ) NH.DETECTRAITOR = self:GetChecked() end
			
			y = y + 17.5
		local status			
		local fn = vgui_Create( 'DTextEntry', misc )
			fn:SetAllowNonAsciiCharacters( true )
			fn:SetPos( 47.5, y )
			fn:SetWide( 112.5 )
			fn:SetValue( NH.FSTR )
			fn.OnGetFocus = function()
				nh_menu.block = true
				nh_menu:ShowCloseButton( true )
			end
			
			nh_menu.Close = function( self )
				NH.FSTR = fn:GetValue()
				self:Remove()
			end
			
		local save = vgui_Create( 'DButton', misc )
			save:SetPos( 2.5, y )
			save:SetSize( 40, 20 )
			save:SetText( 'Save' )
			save.DoClick = function()
				if not Exists( 'nh', 'DATA' ) or not IsDir( 'nh', 'DATA' ) then
					MkDir( 'nh' )
				end
				
				Write( 'nh/' .. fn:GetValue() .. '.txt', TableToJSON( NH ) )
				
				if Exists( 'nh/' .. fn:GetValue() .. '.txt', 'DATA' ) then
					status:SetColor( color_white )
					status:SetText( 'Saved as ' .. fn:GetValue() .. '.txt' )
					status:SizeToContents()
				else
					status:SetColor( color_red )
					status:SetText( 'Unknown saving error' )
					status:SizeToContents()
				end
			end
			
		local load = vgui_Create( 'DButton', misc )
			load:SetPos( 165, y )
			load:SetSize( 40, 20 )
			load:SetText( 'Load' )
			load.DoClick = function()
				if Exists( 'nh/' .. fn:GetValue() .. '.txt', 'DATA' ) then
					local tbl = JSONToTable( Read( 'nh/' .. fn:GetValue() .. '.txt', 'DATA' ) )
					
					if tbl then
						NH = tbl
						
						status:SetColor( color_black )
						status:SetText( 'Loaded as ' .. fn:GetValue() .. '.txt' )
						status:SizeToContents()
					else
						status:SetColor( color_red )
						status:SetText( 'File is damaged or got bad format' )
						status:SizeToContents()
					end
				else
					status:SetColor( color_red )
					status:SetText( 'File is missing' )
					status:SizeToContents()
				end
			end
			
			y = y + 22.5
		local saves = vgui_Create( 'DComboBox', misc )
			saves:SetPos( 2.5, y )
			saves:SetWide( 202.5 )
			for _, f in pairs( ( { Dir( 'nh/*', 'DATA' ) } )[1] ) do
				saves:AddChoice( gsub( f, '.txt', '' ) )
			end
			saves.OnSelect = function( _, _, str )
				fn:SetText( str )
			end
			
			y = y + 22.5
			status = vgui_Create( 'DLabel', misc )
			status:SetPos( 2.5, y )
			status:SetText( ' ' )
			
		cs:AddSheet( 'Misc', misc, 'icon16/wrench_orange.png' )
end

local function NH_CLOSEMENU()
	if not nh_menu then return end
	if nh_menu.block then return end
	
	if nh_menu and nh_menu.Close then
		nh_menu:Close()
	end
	
	nh_menu = nil
end

local ly = 0
local lp = 0
local yaw = 0
local attack

local function NH_ANTIAIM( cmd )
	if attack and not nh_lpress then
		nh_lpress = true
		
		local ang = cmd:GetViewAngles()
		ang.p = ang.p * 2
		ang.y = ang.y * 2
		
		cmd:SetViewAngles( ang )
	elseif not attack and nh_lpress then
		nh_lpress = false
		
		local ang = cmd:GetViewAngles()
		nh_p = 0
		lp = 0
		nh_y = 0
		ly = 0
		ang.r = 0
		cmd:SetViewAngles( ang )
	end
	
	if not attack then
		local ang = cmd:GetViewAngles()
		
		ang.p = nh.CorrectView( nh_p )
		ang.p = nh.CorrectView( nh_y )
		
		yaw = NormalizeAngle( yaw + 79.3333333 )
		
		nh_y = yaw - ( ly * 2 - ang.y )
		ang.y = NH.ANTIAIM == 1 and nh_y + 180 or 0
		
		ang.r = 0
		
		local diff = ( Angle( 0, ang.y - nh_y, 0 ):Forward() ).x
		cmd:SetForwardMove( cmd:GetForwardMove() * -diff )
		cmd:SetSideMove( cmd:GetSideMove() * diff )
		cmd:SetViewAngles( ang )
	else
		cmd:SetSideMove( abs( cmd:GetSideMove() ) )
	end
end

CreateConVar( 'random_seed', -1 )
CreateConVar( 'command_number', -1 )

local viewang = Angle()
NH_REGISTERHOOK( 'CreateMove', function( cmd )
	NH_TARGETS()
	local tr = NH_BUILDTRACE()
	
	if NH.BUNNYHOP and band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
		if not nh_self:IsOnGround() then
			cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_JUMP ) ) )
		end
	end
	
	local w = nh_self:GetActiveWeapon()
	local valid = IsValid( w )
	if NH.AUTORELOAD and valid and w:Clip1() == 0 then
		cmd:SetButtons( bor( cmd:GetButtons(), IN_RELOAD ) )
	end
	
	local crowbar = true
	if NH.CROWBAR and valid and ( w:GetClass() == 'weapon_crowbar' or w:GetClass() == 'weapon_ttt_knife' or w:GetClass() == 'weapon_ttt_axe' ) then
		crowbar = tr.HitPos:Distance( nh_self:GetShootPos() ) < 75
	end
	
	if valid and ( ( nh_aimbot and NH.AUTOSHOT and nh_target ) or NH.TRIGGER and IsValid( tr.Entity ) and NH_CANTARGET( tr.Entity ) and crowbar ) then
		if nh_keydown then
			cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
			nh_keydown = false
		else
			cmd:SetButtons( band( cmd:GetButtons(), IN_ATTACK ) )
			nh_keydown = true
		end
	end
	
	if NH.AUTOPISTOL then
		if band( cmd:GetButtons(), IN_ATTACK ) ~= 0 and valid and ( w.Primary and not w.Primary.Automatic or w:GetClass() == 'weapon_pistol' ) and w:Clip1() > 0 then
			if nh_down_l then
				cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK ) )
				nh_down_l = false
			else
				cmd:SetButtons( band( cmd:GetButtons(), bnot( IN_ATTACK ) ) )
				nh_down_l = true
			end
		end
	end
	
	attack = band( cmd:GetButtons(), IN_ATTACK ) ~= 0
	if NH.ANTIAIM ~= 0 then
		NH_ANTIAIM( cmd )
	else
		if cmd:GetViewAngles().r == 180 then
			cmd:SetViewAngles( cmd:GetViewAngles() + Angle( 0, 0, 180 ) )
		end
	end
	
	if nh_aimbot and IsValid( nh_target ) and nh_target:Health() > 0 and NH_CANTARGET( nh_target ) or NH.TRIGGER and IsValid( tr.Entity ) and NH_CANTARGET( tr.Entity ) then
		local nh_target = IsValid( nh_target ) and nh_target or tr.Entity
		local bp = NH_GETBONEPOS( nh_target )
		
		if bp then
			local vec = NH.POSPRED and NH_PREDICTPOS( nh_target, bp ) or bp
			local ang = ( vec - nh_self:GetShootPos() ):Angle()
			ang.p = NormalizeAngle( ang.p )
			ang.r = cmd:GetViewAngles().r
			
			cmd:SetViewAngles( ang )
			attack = true
		else
			attack = false
		end
	else
		attack = false
	end
	
	if nh_freecam then
		nh_campos = nh_campos + ( viewang:Forward() * cmd:GetForwardMove() / 10000 + viewang:Right() * cmd:GetSideMove() / 10000 ) * ( band( cmd:GetButtons(), IN_SPEED ) ~= 0 and 15 or 5 )
		
		cmd:SetButtons( 0 )
		
		cmd:SetForwardMove( 0 )
		cmd:SetSideMove( 0 )
		cmd:SetUpMove( 0 )
	end
	
	local seed, number = nh.UserCmd( cmd, true )
	print( seed, number )
	
	--[[
	if NH.NOSPREAD and ( attack or band( cmd:GetButtons(), IN_ATTACK ) ~= 0 ) then
		local cone = GetCone() -- Angle( random( -1, 1 ), random( -1, 1 ), 0 )
		cmd:SetViewAngles( cmd:GetViewAngles() + nh_oldpunch - cone )
		nh_oldpunch = cone
	else
		if nh_oldpunch.p ~= 0 or nh_oldpunch.y ~= 0 then
			cmd:SetViewAngles( cmd:GetViewAngles() + nh_oldpunch )
			nh_oldpunch:Zero()
		end
	end
	]]
	
	--[[
	if NH.NOSPREAD and w.Base and strstr( w.Base, 'weapon_sh' ) and ( attack or band( cmd:GetButtons(), IN_ATTACK ) ~= 0 ) and band( cmd:GetButtons(), IN_ATTACK2 ) == 0 then
		cmd:SetButtons( bor( cmd:GetButtons(), IN_ATTACK2 ) )
	end
	]]
end )

NH_REGISTERHOOK( 'ShouldDrawLocalPlayer', function()
	if nh_freecam then return true end
end )

NH_REGISTERHOOK( 'CalcView', function( _, origin, angles )
	Empty( nh_cc_buff )
	
	viewang = angles
	if nh_freecam then
		nh_cc_buff.origin = nh_campos
		nh_cc_buff.angles = ( ( nh_lpress or nh_aimbot and nh_target or NH.ANTIAIM == 0 ) and nh_self:EyeAngles() or Angle( nh_p, nh_y, 0 ) ) + nh_oldpunch
		return nh_cc_buff
	end
	
	if origin:Distance( nh_self:GetShootPos() ) < 20 then
		if NH.ANTIAIM ~= 0 then
			angles.r = 0
			nh_cc_buff.angles = ( ( nh_lpress or nh_aimbot and nh_target ) and angles or Angle( nh_p, nh_y, 0 ) ) + nh_oldpunch
			return nh_cc_buff
		end
		
		if NH.NORECOIL then
			nh_cc_buff.angles = nh_self:EyeAngles() + nh_oldpunch
			return nh_cc_buff
		end
	end
	
	if nh_oldpunch.p ~= 0 or nh_oldpunch.y ~= 0 then
		nh_cc_buff.angles = angles + nh_oldpunch
		return nh_cc_buff
	end
end )

local n_next = 0
local sv_cheats = GetConVar( 'sv_cheats' )
local host_timescale = GetConVar( 'host_timescale' )
local sv_namechange_cooldown_seconds = GetConVar( 'sv_namechange_cooldown_seconds' )
NH_REGISTERHOOK( 'Think', function()
	if hax then
		ForceVar( sv_cheats, NH.SVCHEATS and 1 or 0 )
		ForceVar( host_timescale, IsKeyDown( KEY_E ) and NH.SPEEDHACK ~= 1 and NH.SPEEDHACK or 1 )
	end
	
	if IsKeyDown( KEY_N ) then
		if not nh_lpdc then
			nh_lpdc = true
			nh_freecam = not nh_freecam
			nh_campos = nh_self:GetShootPos()
		end
	else
		nh_lpdc = false
	end
	
	if not NH.FREECAM then nh_freecam = false end
	
	local tr = NH_BUILDTRACE()
	if IsKeyDown( KEY_F1 ) and not nh_menu then
		NH_OPENMENU()
	elseif not IsKeyDown( KEY_F1 ) and nh_menu then
		NH_CLOSEMENU()
	end
	
	if NH.BUTTON == 0 then
		nh_aimbot = NH.AIMENABLED
	else
		nh_aimbot = IsMouseDown( nh_buttons[ NH.BUTTON ] ) and NH.AIMENABLED
	end
	
	local w = nh_self:GetActiveWeapon()
	if w and w.Base == 'weapon_tttbase' then
		if NH.NORECOIL then
			if not w.shootbullet then
				w.shootbullet = w.ShootBullet
				w.ShootBullet = function( self, dmg, _, numbul, cone )
					self.shootbullet( self, dmg, 0, numbul, cone )
				end
			end
		else
			if w.shootbullet then
				w.ShootBullet = w.shootbullet
			end
		end
	end
	
	local plr = GetAllPlayers()
	local ct = CurTime()
	if hax then
		if NH.NAMESTEALER and #plr > 1 then
			if not nh_nickorig then nh_nickorig = GetCurrentName() end
			
			if n_next < ct then
				n_next = ct + sv_namechange_cooldown_seconds:GetInt() + 0.5
				
				Empty( nh_namebuff )
				for i = 1, #plr do
					local pl = plr[ i ]
					if pl ~= nh_self and not strstr( GetCurrentName(), pl:Nick() ) then
						insert( nh_namebuff, pl:Nick() )
					end
				end
				
				local str = Random( nh_namebuff )
				if str then
					ChangeName( str .. ' ~' )
				end
			end
		else
			if nh_nickorig then
				ChangeName( nh_nickorig, true )
				nh_nickorig = nil
			end
		end
	end
	
	if NH.DETECTRAITOR and KARMA then
		for i = 1, #plr do
			local pl = plr[ i ]
			
			if pl.GetRole and pl:GetRole() ~= ROLE_DETECTIVE then
				local w = pl:GetActiveWeapon()
				
				if IsValid( w ) and w.m_traitor ~= pl and w.CanBuy and HasValue( w.CanBuy, ROLE_TRAITOR ) then
					w.m_traitor = pl
					chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' got traitor weapon ', color_orange, '"' .. w:GetClass() .. '"', color_white, '!' )
				end
			end
		end
	end
	
	if NH.DETECTSPEC then
		for i = 1, #plr do
			local pl = plr[ i ]
			if pl:GetObserverTarget() == nh_self and not HasValue( nh_spectators, pl ) then
				insert( nh_spectators, pl )
				chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' is spectating you!' )
			elseif pl:GetObserverTarget() ~= nh_self and HasValue( nh_spectators, pl ) then
				for i = 1, #nh_spectators do
					if nh_spectators[ i ] == pl then
						remove( nh_spectators, i )
					end
				end
				
				chat_AddText( color_red, '[NanoHack] ', color_orange, pl:Nick(), color_white, ' is no longer spectating you!' )
			end
		end
		
		for i = 1, #nh_spectators do
			if not IsValid( nh_spectators[ i ] ) then
				remove( nh_spectators, i )
			end
		end
	else
		Empty( nh_spectators )
	end
	
	local x, y = MousePos()
	if IsMouseDown( MOUSE_LEFT ) then
		if not nh_radar_grab and not nh_radar_grab and ( NH.RADAR_POS[1] - NH.RADAR_SIZE ) < x and ( NH.RADAR_POS[1] + NH.RADAR_SIZE ) > x and ( NH.RADAR_POS[2] - NH.RADAR_SIZE ) < y and ( NH.RADAR_POS[2] + NH.RADAR_SIZE ) > y then
			nh_dx = x - NH.RADAR_POS[1]
			nh_dy = y - NH.RADAR_POS[2]
			
			nh_radar_grab = true
		end
		
		if nh_radar_grab then
			NH.RADAR_POS[1] = Clamp( x - nh_dx, NH.RADAR_SIZE, ScrW() - NH.RADAR_SIZE )
			NH.RADAR_POS[2] = Clamp( y - nh_dy, NH.RADAR_SIZE, ScrH() - NH.RADAR_SIZE )
		end
		
		local hg = 40 + #nh_spectators * 16
		if not nh_radar_grab and not nh_spec_grab and ( NH.SPEC_POS[1] - 128 ) < x and ( NH.SPEC_POS[1] + 128 ) > x and ( NH.SPEC_POS[2] ) < y and ( NH.SPEC_POS[2] + hg ) > y then
			nh_sx = x - NH.SPEC_POS[1]
			nh_sy = y - NH.SPEC_POS[2]
			
			nh_spec_grab = true
		end
		
		if nh_spec_grab then
			NH.SPEC_POS[1] = Clamp( x - nh_sx, 128, ScrW() - 128 )
			NH.SPEC_POS[2] = Clamp( y - nh_sy, 0, ScrH() - hg )
		end
	else
		nh_radar_grab = false
		nh_spec_grab = false
	end
	
	if nh_aimbot then
		local plr = nh_targets
		local fov
		local found
		for i = 1, #plr do
			local pl = plr[ i ]
			local dst = NH_GETDIST( pl:GetPos() )
			if dst < ( fov or dst + 1 ) and pl:Health() > 0 and NH_CANTARGET( pl, true ) and NH_GETBONEPOS( pl ) then
				nh_target = pl
				fov = dst
				found = true
			end
		end
		
		if not found then
			nh_target = nil
		end
	end
end )

NH_REGISTERHOOK( 'PostDrawOpaqueRenderables', function()
	NH_TARGETS()
	if NH.LASER then
		local tr = nh_self:GetEyeTrace()
		local bone = IsValid( nh_self:GetViewModel() ) and nh_self:GetViewModel():GetAttachment( 1 )
		
		SetMaterial( nh_laser )
		DrawBeam( bone and bone.Pos or nh_self:GetPos() + Vector( 0, 0, 1 ), tr.HitPos, 4, 12, 12, color_white )
	end
end )

NH_REGISTERHOOK( 'HUDPaint', function()
	NH_TARGETS()
	local w, h = ScrW(), ScrH()
	local hw, hh = w / 2, h / 2
	local str = 'NanoHack'
	if IsKeyDown( KEY_E ) and NH.SPEEDHACK ~= 1 then
		str = str .. ' - SpeedHacking at ' .. NH.SPEEDHACK
	end
	
	SetFont( 'Default' )
	SetTextColor( color_black )
	SetTextPos( hw - GetTextSize( str ) / 2 - 1, 9 )
	DrawText( str )
	SetTextPos( hw - GetTextSize( str ) / 2 + 1, 9 )
	DrawText( str )
	SetTextPos( hw - GetTextSize( str ) / 2 - 1, 11 )
	DrawText( str )
	SetTextPos( hw - GetTextSize( str ) / 2 + 1, 11 )
	DrawText( str )
	
	SetTextColor( color_red )
	SetTextPos( hw - GetTextSize( str ) / 2, 10 )
	DrawText( str )
	
	local plr = nh_targets
	
	if NH.WALLHACK then
		Start3D( EyePos(), EyeAngles() )
		SuppressEngineLighting( true )
		for i = 1, #plr do
			local pl = plr[ i ]
			local w = pl:GetActiveWeapon()
			
			pl:DrawModel()
			if IsValid( w ) then w:DrawModel() end
		end
		SuppressEngineLighting( false )
		End3D()
	end
	
	if NH.TRACE then
		for i = 1, #plr do
			local pl = plr[ i ]
			local scr = pl:GetPos():ToScreen()
			
			SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
			DrawLine( hw, hh, Clamp( scr.x, 0, w ), Clamp( scr.y, 0, h ) )
		end
	end
	
	if NH.CROSSHAIR then
		SetDrawColor( color_white )
		DrawLine( hw - 52, hh, hw + 52, hh )
		DrawLine( hw, hh - 52, hw, hh + 52 )
		
		SetDrawColor( color_red )
		DrawLine( hw - 32, hh, hw + 32, hh )
		DrawLine( hw, hh - 32, hw, hh + 32 )
	end
	
	if NH.SPECLIST and NH.DETECTSPEC then
		local hg = 40 + #nh_spectators * 16
		
		RoundedBox( 10, NH.SPEC_POS[1] - 128, NH.SPEC_POS[2], 256, hg, color_dark )
		
		SetDrawColor( color_white )
		DrawLine( NH.SPEC_POS[1] - 124, NH.SPEC_POS[2] + 20, NH.SPEC_POS[1] + 124, NH.SPEC_POS[2] + 20 )
		
		SetFont( 'DermaDefault' )
		SetTextColor( color_white )
		SetTextPos( NH.SPEC_POS[1] - GetTextSize( 'SPECTATORS' ) / 2, NH.SPEC_POS[2] + 3 )
		DrawText( 'SPECTATORS' )
		
		for i = 1, #nh_spectators do
			if IsValid( nh_spectators[ i ] ) then
				SetTextPos( NH.SPEC_POS[1] - 124, NH.SPEC_POS[2] + 8 + i * 16 )
				DrawText( nh_spectators[ i ]:Nick() )
			end
		end
	end
	
	if NH.RADAR then
		RoundedBox( 10, NH.RADAR_POS[1] - NH.RADAR_SIZE, NH.RADAR_POS[2] - NH.RADAR_SIZE, 2 * NH.RADAR_SIZE + 2, 2 * NH.RADAR_SIZE + 2, color_dark )
		
		SetDrawColor( color_orange )
		DrawLine( NH.RADAR_POS[1] - NH.RADAR_SIZE + 5, NH.RADAR_POS[2], NH.RADAR_POS[1] + NH.RADAR_SIZE - 5, NH.RADAR_POS[2] )
		DrawLine( NH.RADAR_POS[1], NH.RADAR_POS[2] - NH.RADAR_SIZE + 5, NH.RADAR_POS[1], NH.RADAR_POS[2] + NH.RADAR_SIZE - 5 )
		
		for i = 1, #plr do
			local pl = plr[ i ]
			local dst = pl:GetPos() - nh_self:GetPos()
			dst:Rotate( Angle( 0, -( NH.ANTIAIM ~= 0 and nh_y or nh_self:EyeAngles().y ) + 90, 0 ) )
			dst[1] = Clamp( dst[1], -NH.RADAR_SCALE, NH.RADAR_SCALE )
			dst[2] = Clamp( dst[2], -NH.RADAR_SCALE, NH.RADAR_SCALE )
			
			dst = dst / NH.RADAR_SCALE * NH.RADAR_SIZE
			
			SetFont( 'DermaDefault' )
			
			if abs( dst[3] ) > 2 then
				SetTextPos( NH.RADAR_POS[1] + dst[1] - 3, NH.RADAR_POS[2] - dst[2] - 6 )
				SetTextColor( NH_GETPLAYERCOLOR( pl ) )
				DrawText( dst[3] > 0 and '\30' or '\31' )
			else
				SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
				DrawRect( NH.RADAR_POS[1] + dst[1] - 3, NH.RADAR_POS[2] - dst[2] - 3, 5, 5 )
			end
			
			if NH.RADAR_NICK then
				local str = pl:IsPlayer() and pl:Nick() or pl:GetClass()
				local tttcolor
				if KARMA then
					local _, col = HealthToString( pl:Health() )
					tttcolor = col
				end
				
				SetTextColor( tttcolor or color_green )
				SetTextPos( NH.RADAR_POS[1] + dst[1] - 3 - GetTextSize( str ) / 2, NH.RADAR_POS[2] - dst[2] + 2 )
				DrawText( str )
			end
		end
		
		if NH.RADAR_N then
			local dst = Vector( NH.RADAR_SCALE * 2, 0, 0 )
			
			dst:Rotate( Angle( 0, -( NH.ANTIAIM ~= 0 and nh_y or nh_self:EyeAngles().y ), 0 ) )
			dst[1] = Clamp( dst[1], -NH.RADAR_SCALE, NH.RADAR_SCALE )
			dst[2] = Clamp( dst[2], -NH.RADAR_SCALE, NH.RADAR_SCALE )
			
			dst = dst / NH.RADAR_SCALE * NH.RADAR_SIZE
			
			RoundedBox( 10, NH.RADAR_POS[1] + dst[1] - 9, NH.RADAR_POS[2] - dst[2] - 9, 18, 18, color_black )
			
			SetFont( 'DermaDefault' )
			SetTextColor( color_white )
			SetTextPos( NH.RADAR_POS[1] + dst[1] - 3, NH.RADAR_POS[2] - dst[2] - 6 )
			DrawText( 'N' )
		end
	end
	
	if NH.BARREL then
		for i = 1, #plr do
			local pl = plr[ i ]
			if pl:IsPlayer() then
				local col = NH_GETPLAYERCOLOR( pl )
				local orig = pl:GetShootPos()
				local dest = orig + pl:GetAimVector() * 256
					orig, dest = orig:ToScreen(), dest:ToScreen()
				
				SetDrawColor( col )
				DrawLine( orig.x, orig.y, dest.x, dest.y )
			end
		end
	end
	
	if NH.DRAWBOX then
		for i = 1, #plr do
			local pl = plr[ i ]
			SetDrawColor( NH_GETPLAYERCOLOR( pl ) )
			
			local ang = Angle( 0, pl:EyeAngles().y, 0 )
			local nom = pl:GetPos()
			local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
			
			local bnd1 = Vector( 16, 16, 0 )
				bnd1:Rotate( ang )
				bnd1 = ( nom + bnd1 ):ToScreen()
				
			local bnd2 = Vector( 16, -16, 0 )
				bnd2:Rotate( ang )
				bnd2 = ( nom + bnd2 ):ToScreen()
				
			local bnd3 = Vector( -16, -16, 0 )
				bnd3:Rotate( ang )
				bnd3 = ( nom + bnd3 ):ToScreen()
				
			local bnd4 = Vector( -16, 16, 0 )
				bnd4:Rotate( ang )
				bnd4 = ( nom + bnd4 ):ToScreen()
				
			local bnd5 = Vector( 16, 16, 0 )
				bnd5:Rotate( ang )
				bnd5 = ( mon + bnd5 ):ToScreen()
				
			local bnd6 = Vector( 16, -16, 0 )
				bnd6:Rotate( ang )
				bnd6 = ( mon + bnd6 ):ToScreen()
				
			local bnd7 = Vector( -16, -16, 0 )
				bnd7:Rotate( ang )
				bnd7 = ( mon + bnd7 ):ToScreen()
				
			local bnd8 = Vector( -16, 16, 0 )
				bnd8:Rotate( ang )
				bnd8 = ( mon + bnd8 ):ToScreen()
			
			DrawLine( bnd1.x, bnd1.y, bnd2.x, bnd2.y )
			DrawLine( bnd2.x, bnd2.y, bnd3.x, bnd3.y )
			DrawLine( bnd3.x, bnd3.y, bnd4.x, bnd4.y )
			DrawLine( bnd4.x, bnd4.y, bnd1.x, bnd1.y )
			
			DrawLine( bnd5.x, bnd5.y, bnd6.x, bnd6.y )
			DrawLine( bnd6.x, bnd6.y, bnd7.x, bnd7.y )
			DrawLine( bnd7.x, bnd7.y, bnd8.x, bnd8.y )
			DrawLine( bnd8.x, bnd8.y, bnd5.x, bnd5.y )
			
			DrawLine( bnd1.x, bnd1.y, bnd5.x, bnd5.y )
			DrawLine( bnd2.x, bnd2.y, bnd6.x, bnd6.y )
			DrawLine( bnd3.x, bnd3.y, bnd7.x, bnd7.y )
			DrawLine( bnd4.x, bnd4.y, bnd8.x, bnd8.y )
		end
	end
	
	if NH.ESP or NH.NICK or NH.INFO or NH.ESPBAR or NH.ESPDST then
		for i = 1, #plr do
			local pl = plr[ i ]
			local col = NH_GETPLAYERCOLOR( pl )
			local nom = pl:GetPos()
			local mon = nom + Vector( 0, 0, pl:OBBMaxs()[3] )
			
			local bot, top = nom:ToScreen(), mon:ToScreen()
			local h = ( bot.y - top.y )
			local w = h / 5
			
			if NH.ESP then
				SetDrawColor( col )
				DrawOutlinedRect( top.x - w, top.y, w * 2, h )
			end
			
			if NH.NICK then
				local text = pl:GetClass()
				if pl:IsPlayer() then
					text = pl:Nick()
				end
				
				local tttcolor
				if KARMA then
					local _, col = HealthToString( pl:Health() )
					tttcolor = col
				end
				
				SetFont( 'DermaDefault' )
				SetTextColor( tttcolor or color_green )
				SetTextPos( top.x - GetTextSize( text ) / 2, top.y )
				DrawText( text )
			end
			
			if NH.INFO then
				local wep = '<no weapon>'
				if pl.GetActiveWeapon and IsValid( pl:GetActiveWeapon() ) then
					wep = pl:GetActiveWeapon():GetClass()
				end
				
				if pl:IsPlayer() then
					str = 'Health: ' .. pl:Health() .. '%; Armor: ' .. pl:Armor() .. '%' .. ( NH.WEPESP and '\nWeapon: ' .. wep or '' )
					str = str:Split( '\n' )
					
					SetFont( 'DermaDefault' )
					SetTextColor( color_yellow )
					
					for i = 1, #str do
						local t = str[i]
						if bot.y - top.y < 32 then
							SetTextPos( top.x - GetTextSize( t ) / 2, top.y + i * 16 )
						else
							SetTextPos( bot.x - GetTextSize( t ) / 2, bot.y - 32 + i * 16  )
						end
						
						DrawText( t )
					end
				end
			end
			
			if NH.ESPBAR then
				local x, y
				local diff = pl:IsPlayer() and 32 or 16
				if bot.y - top.y < diff then
					x, y = top.x - 30, top.y + diff + diff / 2
				else
					x, y = bot.x - 30, bot.y + diff / 2
				end
				
				SetDrawColor( color_black )
				DrawRect( x, y, 60, 8 )
				
				SetDrawColor( color_red )
				DrawRect( x + 1, y + 1, ( Clamp( pl:Health(), 0, 100 ) / 100 ) * 58, 6 )
				
				if pl:IsPlayer() and pl:Armor() > 0 then
					SetDrawColor( color_black )
					DrawRect( x, y + 7, 60, 8 )
					
					SetDrawColor( color_blue )
					DrawRect( x + 1, y + 8, ( Clamp( pl:Armor(), 0, 100 ) / 100 ) * 58, 6 )
				end
			end
			
			if NH.ESPDST then
				local x, y
				local diff = pl:IsPlayer() and 32 or 16
				if bot.y - top.y < diff then
					x, y = top.x + 35, top.y + diff + diff / 2
				else
					x, y = bot.x + 35, bot.y + diff / 2
				end
				
				SetFont( 'DermaDefault' )
				SetTextColor( color_yellow )
				SetTextPos( x, y - 4 )
				DrawText( Round( nh_self:GetPos():Distance( pl:GetPos() ), 1 ) )
			end
		end
	end
end )

NH_REGISTERHOOK( 'ShutDown', function()
	if hax and nh_nickorig then
		ChangeName( nh_nickorig )
		nh_nickorig = nil
	end
end )

local file_Read = file.Read
function file.Read( str, ... )
	if type( str ) == 'string' and ( strstr( str, 'hax' ) or strstr( str, 'nanohack' ) ) then
		return 'table.Empty( _G )'
	end
	
	return file_Read( str, ... )
end

--[[
local rcc = RunConsoleCommand
function RunConsoleCommand( str, ... )
	if string.find( str, 'voicerecord' ) then
		return
	end
	
	rcc( str, ... )
end
]]