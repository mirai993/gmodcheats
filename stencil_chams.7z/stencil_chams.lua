local colors = {}
local colors_complement = {}

local function GetColors(name)
	if not colors[name] then
		local crc = util.CRC(name)

		local r, g, b = bit.band(bit.rshift(crc, 24), 0xFF) / 0.2, 
						bit.band(bit.rshift(crc, 16), 0xFF) / 0.7, 
						bit.band(bit.rshift(crc, 8), 0xFF) / 0.7

		colors[name] = Color(r, g, b, 128)

		local r, g, b = 0xFF - r,
						0xFF - g,
						0xFF - b

		colors_complement[name] = Color(r, g, b, 128)
	end

	return colors[name], colors_complement[name]
end

local function DrawCham(ply)
	if ply:IsDormant() or not ply:Alive() then
		return
	end

	local wep = ply:GetActiveWeapon()
	local color, color_complement = GetColors(ply:Name())
	local scrw, scrh = ScrW(), ScrH()

	render.SetStencilEnable(true)
	
		render.SetStencilTestMask(1)
		render.SetStencilWriteMask(1)
		render.SetStencilReferenceValue(1)

		render.ClearStencil()

			render.SetStencilCompareFunction(STENCIL_NEVER)
			render.SetStencilPassOperation(STENCIL_KEEP)
			render.SetStencilFailOperation(STENCIL_REPLACE)
			render.SetStencilZFailOperation(STENCIL_KEEP)

				ply:DrawModel()

			render.SetStencilFailOperation(STENCIL_ZERO)

				if IsValid(wep) then
					wep:DrawModel()
				end

			render.SetStencilCompareFunction(STENCIL_EQUAL)
			render.SetStencilPassOperation(STENCIL_KEEP)
			render.SetStencilFailOperation(STENCIL_KEEP)
			render.SetStencilZFailOperation(STENCIL_KEEP)

				cam.Start2D()
					surface.SetDrawColor(color)
					surface.DrawRect(0, 0, scrw, scrh)
				cam.End2D()

		render.ClearStencil()

			render.SetStencilCompareFunction(STENCIL_NEVER)
			render.SetStencilPassOperation(STENCIL_KEEP)
			render.SetStencilFailOperation(STENCIL_REPLACE)
			render.SetStencilZFailOperation(STENCIL_KEEP)

				if IsValid(wep) then
					wep:DrawModel()
				end

			render.SetStencilCompareFunction(STENCIL_EQUAL)
			render.SetStencilPassOperation(STENCIL_KEEP)
			render.SetStencilFailOperation(STENCIL_KEEP)
			render.SetStencilZFailOperation(STENCIL_KEEP)

				cam.Start2D()
					surface.SetDrawColor(color_complement)
					surface.DrawRect(0, 0, scrw, scrh)
				cam.End2D()

		render.ClearStencil()

	render.SetStencilEnable(false)
	

	if IsValid(wep) then
		wep:DrawModel()
	end

	ply:DrawModel()
end

hook.Add("PreDrawHUD", "Chams", function()
	local players = player.GetAll()

	cam.Start3D()
		render.SetColorModulation(1, 1, 1)

		for _, ply in ipairs(players) do
			DrawCham(ply)
		end
	cam.End3D()

	for _, ply in ipairs(players) do
 		-- 2D ESP GOES HERE
	end
end)