--[[
	autorun/client/Trigger.txt
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

/*
 * Integra V1.14 Wallhack and Aimbot (1st real release)
 */

if SERVER then return end

local INT_CMD_PREFIX = "int"

require('cvar2')

local vgui = vgui
local concommand = require("concommand")
local hook = require("hook")
local cvar2 = cvar2 or {}
local http = require("http")
local usermessage = require('usermessage')
local file = file
local cam = cam
local render = render

local RunString = RunString

concommand.Add("int_runstring", function(p, c, a) RunString(unpack(a)) end)

// Check if everything is loaded.
if vgui == nil then MsgN("Integra Error: VGUI Library not loaded!") else MsgN("Integra: VGUI Library loaded succesfully!") end
if concommand == nil then MsgN("Integra Error: Console Commands Library not loaded!") else MsgN("Integra: Console Commands Library loaded succesfully!") end
if hook == nil then MsgN("Integra Error: Function Hook Library not loaded!") else MsgN("Integra: Function Hook Library loaded succesfully!") end

if cvar2 then
	if cvar2.SetValue then
		cvar2.SetValue("sv_cheats", "1")
	else
		MsgN("Integra Error: gm_cvar2 could not be found, bug?")
	end
end

concommand.Add("int_speedamount", function(p, c, args)
	if args[1] == nil then MsgN("You need to specify a value, prefferably in range of 0.2 to 7") return end

	if cvar2 then
		if cvar2.SetValue then
			cvar2.SetValue("host_timescale", args[1])
		else
			MsgN("Integra Error: gm_cvar2 could not be found, bug?")
		end
	else
		MsgN("Integra Error: gm_cvar2 could not be found, bug?")
	end
end)

// Check for newer version
local function IntUpdateBox(lv, sv, desc)
	surface.PlaySound("buttons/blip1.wav")
	local MainFrame = vgui.Create("DFrame")
		MainFrame:SetPos(10, ScrH() - 140)
		MainFrame:SetSize(300, 150)
		MainFrame:SetTitle("Integra Update Notification")
		MainFrame:SetSizable(false)
		MainFrame:SetDraggable(true)
		MainFrame:MakePopup()
		MainFrame.alpha = 0
	local Text = vgui.Create("DLabel", MainFrame)
		Text:SetText("A newer version of Integra is available!\nYour version: " .. lv .. ", Newest version: " .. sv .. "\n\nVersion updates:\n\"" .. desc .. "\"")
		Text:SizeToContents()
		Text:Center()
		Text:SetPos(Text:GetPos(), 25)
		Text:SetTextColor(Color(255, 255, 255, 255))
		function MainFrame:Paint()
			Derma_DrawBackgroundBlur(self, self.m_fCreateTime)
			surface.SetDrawColor(Color(0, 0, 0, self.alpha))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(96, 0, 0, self.alpha))
			surface.DrawRect(0, 0, self:GetWide(), 22)
		end
		function MainFrame:Think()
			if self.alpha < 200 then self.alpha = self.alpha + 2 end
			local x, y = self:GetPos()
			local targetx = ((ScrW() / 2) - (self:GetWide() / 2))
			local targety = ((ScrH() / 2) - (self:GetTall() / 2))
			self:SetPos(x + (targetx - x) / 70, y + (targety - y) / 70)
		end
	local CloseButton = vgui.Create("DButton", MainFrame)
		CloseButton:SetSize(100, 20)
		CloseButton:SetPos(10, MainFrame:GetTall() - 30)
		CloseButton:SetText("Close")
		CloseButton.DoClick = function() MainFrame:Close() end
end

local function IntCouldNotUpdate()
	surface.PlaySound("buttons/button18.wav")
	local MainFrame = vgui.Create("DFrame")
		MainFrame:SetPos(10, ScrH() - 100)
		MainFrame:SetSize(300, 90)
		MainFrame:SetTitle("Integra Update Notification")
		MainFrame:SetSizable(false)
		MainFrame:SetDraggable(true)
		MainFrame:MakePopup()
		MainFrame.alpha = 0
	local Text = vgui.Create("DLabel", MainFrame)
		Text:SetText("Unable to check for updates or retrieve latest version info,\nIntegra may not be up-to-date!")
		Text:SizeToContents()
		Text:Center()
		Text:SetPos(Text:GetPos(), 25)
		Text:SetTextColor(Color(255, 255, 255, 255))
		function MainFrame:Paint()
			Derma_DrawBackgroundBlur(self, self.m_fCreateTime)
			surface.SetDrawColor(Color(0, 0, 0, self.alpha))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(96, 0, 0, self.alpha))
			surface.DrawRect(0, 0, self:GetWide(), 22)
		end
		function MainFrame:Think()
			if self.alpha < 200 then self.alpha = self.alpha + 2 end
			local x, y = self:GetPos()
			local targetx = ((ScrW() / 2) - (self:GetWide() / 2))
			local targety = ((ScrH() / 2) - (self:GetTall() / 2))
			self:SetPos(x + (targetx - x) / 70, y + (targety - y) / 70)
		end
	local CloseButton = vgui.Create("DButton", MainFrame)
		CloseButton:SetSize(100, 20)
		CloseButton:SetPos(10, MainFrame:GetTall() - 30)
		CloseButton:SetText("Close")
		CloseButton.DoClick = function() MainFrame:Close() end
end

local LocalVersion = 1.14

MsgN("Integra: Recieving latest version info...")

http.Get("http://anthraxscripts.googlecode.com/svn/trunk/Integra/VERSION.txt", "", function(c)
	if c != nil then
		local lines = string.Explode("\n", c)
		if #lines > 1 then
			local LatestVersion = tonumber(lines[1])
			local desc = ""
			for i = 2, #lines do
				if i != 2 then
					desc = desc .. "\n"
				end
				desc = desc .. lines[i]
			end
			if LocalVersion < LatestVersion then
				IntUpdateBox(LocalVersion, LatestVersion, desc)
			else
				MsgN("Integra: Your version is up-to-date!")
			end
		else
			IntCouldNotUpdate()
		end
	else
		IntCouldNotUpdate()
	end
end)

// Useful functions
local function CreateHook(t, func, cvar, default, h)
	if cvar != nil and default != nil then
		CreateClientConVar(cvar, default, true, false)
	end

	hook.Add(t, "INT_" .. h .. "_" .. t, function()
		if cvar != nil and default != nil then
			if GetConVar(cvar):GetBool() then
				func()
			end
		else
			func()
		end
	end)
end

local function ValidPlayer(ply)
	local valid = true
	if type(ply) == "Player" then
		if not ValidEntity(ply) then
			valid = false
		end
	else
		valid = false
	end

	return valid
end

local function GetHeadPos(ply)
	local pos = Vector(0, 0, 0)

	if ValidEntity(ply) then
		pos = (ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1")) or ply:EyePos())
	end
	return pos
end

local function GetRank(ply)
	if ValidPlayer(ply) then
		if ply:IsSuperAdmin() then
			return "Super Admin"
		elseif ply:IsAdmin() and not ply:IsSuperAdmin() then
			return "Admin"
		elseif not ply:IsAdmin() then
			return "User"
		end
	else
		return "Unknown"
	end
end

local function RotateVector(amount)
	local angle = amount / 180 * 3.14159
	local pos = {}
		pos.x = math.cos(angle) - math.sin(angle)
		pos.y = math.sin(angle) + math.cos(angle)
	return pos
end

local function AddBindkeyCommand(title, func, htype, on_callback, off_callback)
	concommand.Add("+int_" .. title, function(ply, cmd, args)
		if htype == 1 then
			hook.Add("Think", "INT_BindFunc_" .. title, func)
		elseif htype == 2 then
			hook.Add("Tick", "INT_BindFunc_" .. title, func)
		end
		if on_callback then
			on_callback(args)
		end
	end)
	concommand.Add("-int_" .. title, function(ply, cmd, args)
		hook.Remove("Think", "INT_BindFunc_" .. title)
		hook.Remove("Tick", "INT_BindFunc_" .. title)
		if off_callback then
			off_callback(args)
		end
	end)
end

// Aimbot
local AB_Target
local AB_Active = false

local AB_ConVars_TargetSteamFriends = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_targetsteamfriends", 0, true, false)
local AB_ConVars_Autofire = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_autofire", 1, true, false)
local AB_ConVars_VelocityPredict = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_velocitypredict", 1, true, false)
local AB_ConVars_VelocityPredictMultip = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_velocitypredict_multiplier", 1, true, false)
local AB_ConVars_TargetPlayers = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_targetplayers", 1, true, false)
local AB_ConVars_MaxAngle = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_maxangle", 90, true, false)
local AB_ConVars_MaxDist = CreateClientConVar(INT_CMD_PREFIX .. "_aimbot_maxdistance", 16384, true, false)

local function AB_GetTarget()
	local Targets = {}
	if AB_ConVars_TargetPlayers:GetBool() then
		for k, v in pairs(player.GetAll()) do
			if ValidPlayer(v) and v != LocalPlayer() then
				local valid = false
				if AB_ConVars_TargetSteamFriends:GetBool() then
					if v:GetFriendStatus() != "friend" then
						valid = true
					end
				else
					valid = true
				end
				if valid then
					local tr_data = {}
						tr_data.start = EyePos()
						tr_data.endpos = GetHeadPos(v)
						tr_data.mask = MASK_SHOT
						tr_data.filter = {LocalPlayer()}
					local tr = util.TraceLine(tr_data)
					if tr.Entity == v then
						table.insert(Targets, v)
					end
				end
			end
		end
	end

	local TargetAngleDiffs = {}

	for k, v in pairs(Targets) do
		if v:Health() > 0 or v:IsNPC() then
			if v:GetPos():Distance(EyePos()) <= AB_ConVars_MaxDist:GetInt() then
				local ang = (GetHeadPos(v) - EyePos()):Angle()
					ang.p = 0
				local eyeang = EyeAngles()
					eyeang.p = 0
				local dist = eyeang:Forward():Distance(ang:Forward()) * 90
				if dist <= AB_ConVars_MaxAngle:GetInt() then
					table.insert(TargetAngleDiffs, {ply = v, ang = dist})
				end
			end
		end
	end

	if #TargetAngleDiffs <= 0 then return end
	table.SortByMember(TargetAngleDiffs, "ang", function(a, b) return a > b end)

	AB_Target = TargetAngleDiffs[1].ply
end

local AttackDown = false

local function GetMuzzlePos(ply)
	if not ValidPlayer(ply) then return Vector() end

	local vm = ply:GetViewModel()
	local pos = ply:EyePos()

	if ValidEntity(vm) then
		local attachId = vm:LookupAttachment("muzzle")
		if attachId == 0 then
			attachId = vm:LookupAttachment("1")
		end

		if vm:GetAttachment(attachId) != nil then
			pos = vm:GetAttachment(attachId).Pos
		end
	end

	return (pos or ply:EyePos())
end

local function AB_Think()
	local ValidTarget = false
	if ValidEntity(AB_Target) then
		if AB_Target:Health() > 0 or AB_Target:IsNPC() then
			local tr_data = {}
				tr_data.start = EyePos()
				tr_data.endpos = GetHeadPos(AB_Target)
				tr_data.mask = MASK_SHOT
				tr_data.filter = {LocalPlayer()}
			local tr = util.TraceLine(tr_data)
				if tr.Entity == AB_Target then
					ValidTarget = true
				else
					if AB_ConVars_Autofire:GetBool() then RunConsoleCommand("-attack") end
					AB_Target = nil
				end
		else
			if AB_ConVars_Autofire:GetBool() then RunConsoleCommand("-attack") end
			AB_Target = nil
		end
	else
		if AB_ConVars_Autofire:GetBool() then RunConsoleCommand("-attack") end
		AB_Target = nil
	end
	if not ValidTarget then
		AB_GetTarget()
	else
		local ang = (GetHeadPos(AB_Target) - EyePos()):Angle()
		if AB_ConVars_VelocityPredict:GetBool() then
			local amt = 1
			if AB_ConVars_VelocityPredictMultip:GetFloat() > 1 then
				amt = AB_ConVars_VelocityPredictMultip:GetFloat()
				amt = amt * ((EyePos():Distance(GetHeadPos(AB_Target))) / 1000)
			end
			ang = ((GetHeadPos(AB_Target) + (AB_Target:GetVelocity() / 150) * amt) - (EyePos() + (LocalPlayer():GetVelocity() / 150))):Angle()
		end
		LocalPlayer():SetEyeAngles(ang)
		if AB_ConVars_Autofire:GetBool() then
			local tr_data = {}
				tr_data.start = EyePos()
				tr_data.endpos = GetHeadPos(AB_Target)
				tr_data.mask = MASK_SHOT
				tr_data.filter = {LocalPlayer()}
			local tr = util.TraceLine(tr_data)
			if tr.Entity == AB_Target then
				if AttackDown then
					RunConsoleCommand("-attack")
				else
					RunConsoleCommand("+attack")
				end
				AttackDown = not AttackDown
			end
		end
	end
end
AddBindkeyCommand("aimbot", AB_Think, 1, function() AB_Active = true end, function() AB_Active = false RunConsoleCommand("-attack") AttackDown = false AB_Target = nil end)

// ESP
local ESP_PlayerData = {}

local ESP_ConVars_DrawPlayerInfo = CreateClientConVar(INT_CMD_PREFIX .. "_esp_drawplayerinfo", 1, true, false)
local ESP_ConVars_DrawCrosshair = CreateClientConVar(INT_CMD_PREFIX .. "_esp_drawcrosshair", 1, true, false)
local ESP_ConVars_OutlinedText = CreateClientConVar(INT_CMD_PREFIX .. "_esp_outlinedtext", 1, true, false)
local ESP_ConVars_MaxProps = CreateClientConVar(INT_CMD_PREFIX .. "_esp_maxprops", 20, true, false)
local ESP_ConVars_PropWireframe = CreateClientConVar(INT_CMD_PREFIX .. "_esp_propwireframe", 1, true, false)
local ESP_Material = Material("models/shiny")
local ESP_PropMaterial = Material("models/wireframe")
local ESP_ActiveProps = {}

local function ESP_Render()
	cam.Start3D(EyePos(), EyeAngles())
		cam.Start2D()
			if ESP_ConVars_DrawCrosshair:GetBool() then
				local pos = LocalPlayer():GetEyeTrace().HitPos
				local dist = math.Round(EyePos():Distance(pos))
					pos = pos:ToScreen()
				surface.SetDrawColor(Color(255, 0, 0, 192))
				if AB_Active then
					if ValidEntity(AB_Target) then surface.SetDrawColor(Color(0, 255, 0, 192)) end
					surface.DrawLine(pos.x - RotateVector(CurTime() * 200).x * 15, pos.y - RotateVector(CurTime() * 200).y * 15, pos.x - RotateVector(CurTime() * 200).x * 5, pos.y - RotateVector(CurTime() * 200).y * 5)
					surface.DrawLine(pos.x - RotateVector(CurTime() * 200 + 90).x * 15, pos.y - RotateVector(CurTime() * 200 + 90).y * 15, pos.x - RotateVector(CurTime() * 200 + 90).x * 5, pos.y - RotateVector(CurTime() * 200 + 90).y * 5)
					surface.DrawLine(pos.x - RotateVector(CurTime() * 200 + 180).x * 15, pos.y - RotateVector(CurTime() * 200 + 180).y * 15, pos.x - RotateVector(CurTime() * 200 + 180).x * 5, pos.y - RotateVector(CurTime() * 200 + 180).y * 5)
					surface.DrawLine(pos.x - RotateVector(CurTime() * 200 + 270).x * 15, pos.y - RotateVector(CurTime() * 200 + 270).y * 15, pos.x - RotateVector(CurTime() * 200 + 270).x * 5, pos.y - RotateVector(CurTime() * 200 + 270).y * 5)
				else
					surface.DrawLine(pos.x - 15, pos.y, pos.x - 5, pos.y)
					surface.DrawLine(pos.x + 15, pos.y, pos.x + 5, pos.y)
					surface.DrawLine(pos.x, pos.y - 15, pos.x, pos.y - 5)
					surface.DrawLine(pos.x, pos.y + 15, pos.x, pos.y + 5)
				end
			end
			for k, v in pairs(ESP_PlayerData) do
				local pos = v.Pos:ToScreen()
				if ESP_ConVars_DrawPlayerInfo:GetBool() then
					pos.y = pos.y - 15 - (#v.Data * 15)
				end

				if ESP_ConVars_OutlinedText:GetBool() then
					local rank = ""

					if v.Rank != "User" then
						rank = " (" .. v.Rank .. ")"
					end

					surface.SetFont("MenuLarge")
					local namesize = surface.GetTextSize(v.Name)

					surface.SetFont("MenuItem")
					local ranksize = 0
					if rank != "" then
						ranksize = surface.GetTextSize(rank)
					end

					draw.SimpleTextOutlined(v.Name, "MenuLarge", pos.x - ((namesize + ranksize) / 2), pos.y, v.TeamColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))

					if rank != "" then
						draw.SimpleTextOutlined(rank, "MenuItem", pos.x - ((namesize + ranksize) / 2) + namesize, pos.y, Color(205, 91, 69, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
					end

					surface.SetFont("UiBold")
					for k, v in pairs(v.Data) do
						local value = v[2]
							if v[1] == "Health" then
								if v[2] <= 0 then
									value = "DEAD"
								else
									value = value .. "%"
								end
							end
						draw.SimpleTextOutlined(v[1] .. ": ", "UiBold", pos.x - ((surface.GetTextSize(v[1] .. ": " .. value)) / 2), pos.y + 4 + (k * 12), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
						draw.SimpleTextOutlined(value, "UiBold", pos.x - ((surface.GetTextSize(v[1] .. ": " .. value)) / 2) + surface.GetTextSize(v[1] .. ": "), pos.y + 4 + (k * 12), Color(153, 204, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
					end
				else
					local rank = ""

					if v.Rank != "User" then
						rank = " (" .. v.Rank .. ")"
					end

					surface.SetFont("MenuLarge")
					local namesize = surface.GetTextSize(v.Name)

					surface.SetFont("MenuItem")
					local ranksize = 0
					if rank != "" then
						ranksize = surface.GetTextSize(rank)
					end

					draw.SimpleText(v.Name, "MenuLarge", pos.x - ((namesize + ranksize) / 2), pos.y, v.TeamColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

					if rank != "" then
						draw.SimpleText(rank, "MenuItem", pos.x - ((namesize + ranksize) / 2) + namesize, pos.y, Color(205, 91, 69, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end

					surface.SetFont("UiBold")
					for k, v in pairs(v.Data) do
						local value = v[2]
							if v[1] == "Health" then
								if v[2] <= 0 then
									value = "DEAD"
								else
									value = value .. "%"
								end
							end
						draw.SimpleText(v[1] .. ": ", "UiBold", pos.x - ((surface.GetTextSize(v[1] .. ": " .. value)) / 2), pos.y + 4 + (k * 12), Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
						draw.SimpleText(value, "UiBold", pos.x - ((surface.GetTextSize(v[1] .. ": " .. value)) / 2) + surface.GetTextSize(v[1] .. ": "), pos.y + 4 + (k * 12), Color(153, 204, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
					end
				end
			end
		cam.End2D()
	cam.End3D()
end
CreateHook("HUDPaint", ESP_Render, INT_CMD_PREFIX .. "_esp_enabled", 1, "ESP")

local function ESP_DrawPlayerEnts()
	cam.Start3D(EyePos(), EyeAngles())
		cam.IgnoreZ(true)
		SetMaterialOverride(ESP_Material)
		render.SetBlend(0.4)
		render.SetColorModulation(0, 1, 0)
		render.SuppressEngineLighting(true)
			for k, v in pairs(ESP_PlayerData) do
				if ValidPlayer(v.Player) then
					if v.Player:Alive() then
						v.Player:DrawModel()
					end
				end
			end
		render.SuppressEngineLighting(false)
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
		SetMaterialOverride(nil)
		cam.IgnoreZ(false)
	cam.End3D()
end
CreateHook("RenderScreenspaceEffects", ESP_DrawPlayerEnts, INT_CMD_PREFIX .. "_esp_drawplayerentities", 1, "ESP")

local function ESP_DrawNPCs()
	cam.Start3D(EyePos(), EyeAngles())
		cam.IgnoreZ(true)
		SetMaterialOverride(ESP_PropMaterial)
		render.SetBlend(0.3)
		render.SetColorModulation(0, 0, 1)
		render.SuppressEngineLighting(true)
			for k, v in pairs(ents.GetAll()) do
				if ValidEntity(v) then
					if v:IsNPC() then
						v:DrawModel()
					end
				end
			end
		render.SuppressEngineLighting(false)
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
		SetMaterialOverride(nil)
		cam.IgnoreZ(false)
	cam.End3D()
end
CreateHook("RenderScreenspaceEffects", ESP_DrawNPCs, INT_CMD_PREFIX .. "_esp_drawnpcs", 1, "ESP_NPCs")

local function ESP_DrawProps()
	cam.Start3D(EyePos(), EyeAngles())
		cam.IgnoreZ(true)
		SetMaterialOverride(ESP_Material)
		render.SetBlend(0.3)
		render.SetColorModulation(1, 0, 0)
		render.SuppressEngineLighting(true)
			for k, v in pairs(ESP_ActiveProps) do
				if ValidEntity(v) then
					v:DrawModel()
					if ESP_ConVars_PropWireframe:GetBool() then
						SetMaterialOverride(ESP_PropMaterial)
						render.SetColorModulation(0.4, 0, 0)
						v:DrawModel()
					end
				else
					table.remove(ESP_ActiveProps, k)
				end
			end
		render.SuppressEngineLighting(false)
		render.SetColorModulation(1, 1, 1)
		render.SetBlend(1)
		SetMaterialOverride(nil)
		cam.IgnoreZ(false)
	cam.End3D()
end

hook.Add("OnEntityCreated", "INT_ESP_EntCreate", function(ent)
	if ValidEntity(ent) then
		if ent:GetClass() == "prop_physics" then
			if #ESP_ActiveProps + 1 > ESP_ConVars_MaxProps:GetInt() then
				ESP_ActiveProps[1] = ent
			else
				table.insert(ESP_ActiveProps, ent)
			end
		end
	end
end)
CreateHook("RenderScreenspaceEffects", ESP_DrawProps, INT_CMD_PREFIX .. "_esp_drawprops", 1, "ESP_Props")

local function ESP_Think()
	for k, v in pairs(ESP_PlayerData) do
		if not ValidEntity(v.Player) or v.Player == nil then
			table.remove(ESP_PlayerData, k)
			ESP_PlayerData[k] = nil
		end
	end
	for k, v in pairs(player.GetAll()) do
		if ValidPlayer(v) and v != LocalPlayer() then
			ESP_PlayerData[v:UserID()] = {}
			ESP_PlayerData[v:UserID()].Player = v
			ESP_PlayerData[v:UserID()].Pos = GetHeadPos(v)
			ESP_PlayerData[v:UserID()].Name = v:Nick()
			ESP_PlayerData[v:UserID()].Rank = GetRank(v)
			ESP_PlayerData[v:UserID()].TeamColor = Color(255, 255, 255, 255)
			if team.GetColor(v:Team()) != nil then
				ESP_PlayerData[v:UserID()].TeamColor = team.GetColor(v:Team())
			end
			ESP_PlayerData[v:UserID()].Data = {}
			ESP_PlayerData[v:UserID()].Data[1] = {"Health", v:Health()}
			ESP_PlayerData[v:UserID()].Data[2] = {"Weapon", "Unknown"}
			if v:GetActiveWeapon() != nil then
				if ValidEntity(v:GetActiveWeapon()) then
					if v:GetActiveWeapon().PrintName != nil then
						ESP_PlayerData[v:UserID()].Data[2][2] = v:GetActiveWeapon().PrintName
					else
						ESP_PlayerData[v:UserID()].Data[2][2] = v:GetActiveWeapon():GetClass()
					end
				end
			end
			ESP_PlayerData[v:UserID()].Data[3] = {"Distance", math.Round(v:EyePos():Distance(EyePos()))}
			
		end
	end
end
CreateHook("Think", ESP_Think, INT_CMD_PREFIX .. "_esp_enabled", 1, "ESP")

// Barrel Hack
local BH_Material = Material("effects/laser1")

local function BH_Render()
	cam.Start3D(EyePos(), EyeAngles())
	render.SetMaterial(BH_Material)
		for k, v in pairs(player.GetAll()) do
			if ValidPlayer(v) then
				local pos = v:GetEyeTrace().HitPos
				render.DrawBeam(GetMuzzlePos(v), pos, 10, 1, 1, Color(255, 0, 0, 255))
			end
		end
	cam.End3D()
end
CreateHook("RenderScreenspaceEffects", BH_Render, INT_CMD_PREFIX .. "_barrelhack_enabled", 1, "BH")


// Other stuff, and previous stuff from older versions
local function BunnyHop()
	if LocalPlayer():IsOnGround() then
		RunConsoleCommand("+jump")
	else
		RunConsoleCommand("-jump")
	end
end
AddBindkeyCommand("bhop", BunnyHop, 1, nil, function() RunConsoleCommand("-jump") end)

concommand.Add("int_rotate", function() LocalPlayer():SetEyeAngles(Angle(EyeAngles().p, EyeAngles().y - 180, 0)) end)

local CS_On = false
local CS_Commands = {"attack"}

local function CS_Tick()
	if CS_On then
		for k, v in pairs(CS_Commands) do
			if v != "109" then
				RunConsoleCommand("-" .. v)
			end
		end
		CS_On = false
	else
		for k, v in pairs(CS_Commands) do
			if v != "109" then
				RunConsoleCommand("+" .. v)
			end
		end
		CS_On = true
	end
end
AddBindkeyCommand("commandspam", CS_Tick, 2, function(args) if args != nil then table.Empty(CS_Commands) CS_Commands = args end end, function(args) for k, v in pairs(CS_Commands) do RunConsoleCommand("-" .. v) end CS_Commands = {"attack"} end)

// Menu
local IntMenu = {}
	IntMenu.ConVars = {}

function IntMenu:Display()
	local MainFrame = vgui.Create("DFrame")
		MainFrame:SetSize(800, 600)
		MainFrame:Center()
		MainFrame:SetTitle("Sorry the menu isn't done yet :(")
		MainFrame:SetSizable(false)
		MainFrame:SetDraggable(true)
		MainFrame:MakePopup()
		function MainFrame:Paint()
			surface.SetDrawColor(Color(0, 0, 0, 200))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
		end
end

concommand.Add(INT_CMD_PREFIX .. "_menu", function()
	IntMenu:Display()
end)

// Welcome message
MsgN("\n-- Loaded Integra v1.0 by Anthr4x292 --")
MsgN("-- Integra: Garry's Mod aimbot and Wallhack --\n")