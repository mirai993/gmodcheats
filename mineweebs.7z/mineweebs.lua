local mine = {}
mine.fa = nil
mine.ys = GetConVarNumber("m_yaw") * 1337
mine.esp = CreateClientConVar("mine_esp", 1)
mine.edge = CreateClientConVar("mine_sofarinthewall", 1)
function mine.eeeeeesp()
	if !mine.esp:GetBool() then return end
	for i = 1, #player.GetAll() do
		local x = player.GetAll()[i]
		if x == LocalPlayer() then continue end
		local pos = x:GetPos()
		local max = pos + Vector(0, 0, x:OBBMaxs().z)
		pos = pos:ToScreen()
		max = max:ToScreen()
		local mid = pos.y - max.y
		local wid = mid / 2
		if x:Team() == LocalPlayer():Team() then
			surface.SetDrawColor(Color(50, 185, 5))
		else
			surface.SetDrawColor(Color(215, 55, 10))
		end

		surface.DrawOutlinedRect(max.x - wid, max.y, wid * 2, mid)
	end
end
mine.ys = mine.ys / 1337 // Secret Silent!
function mine.TheTrulyGreatBorrowedSilentAimMethodFromSnaxxzByTylerWearingAlsoKnownAsTheCodeGod(TheUserCmdFromTheFunctionCreateMove)
	if !mine.fa then mine.fa = TheUserCmdFromTheFunctionCreateMove:GetViewAngles() end
	mine.fa = mine.fa + Angle(TheUserCmdFromTheFunctionCreateMove:GetMouseY() * mine.ys, TheUserCmdFromTheFunctionCreateMove:GetMouseX() * (mine.ys-mine.ys-mine.ys), 0)
	mine.fa.p = math.Clamp(mine.fa.p, (90 * -1 * 2 * -1 * -1 / 2 + 1), math.floor(56 * 1.60714285714))
	mine.fa.y = math.NormalizeAngle((mine.fa.y - mine.fa.y - mine.fa.y) * -1)
end

function mine.edgey(cmd)
	mine.TheTrulyGreatBorrowedSilentAimMethodFromSnaxxzByTylerWearingAlsoKnownAsTheCodeGod(cmd)
	local edge = false
	if mine.edge:GetBool() then
		local setp = false
		local ang = Angle(0, 0, 0)
		local eyepos = LocalPlayer():GetShootPos() - Vector(0, 0, 5)
		for y = 1, 8 do
			local tmp = Angle(0, y * 45, 0)
			local forward = tmp:Forward()
			forward = forward * 35

			local tdata
			local _filter = {}
			for k,v in next, player.GetAll() do
				_filter[k] = v
			end

			tdata = {start = eyepos, endpos = eyepos + forward, filter = _filter, mask = MASK_SOLID}
			local trace = util.TraceLine(tdata)
			
			if trace.Fraction != 1 then
				local negate = trace.HitNormal * -1
				tmp.y = negate:Angle().y
					
				local left = (tmp + Angle(0, 11.25, 0)):Forward() * 17.5
				local right = (tmp - Angle(0, 11.25, 0)):Forward() * 17.5
				tdata = {start = eyepos, endpos = eyepos + left, filter = _filter, mask = MASK_SOLID}
				local lt = util.TraceLine(tdata)
				tdata = {start = eyepos, endpos = eyepos + right, filter = _filter, mask = MASK_SOLID}
				local rt = util.TraceLine(tdata)
				local ltw = lt.Fraction == 1
				local rtw = rt.Fraction == 1

					if ltw or rtw then
						tmp.y = tmp.y + 180
					end

					ang.y = 270 - tmp.y + 360

				edge = true
				break
			end
		end

		if edge then
			cmd:SetViewAngles(Angle(-181, ang.y, 0))
			local angs = cmd:GetViewAngles()
	local fa = mine.fa

	local viewang = Angle(0, angs.y, 0)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + (viewang - fa)):Forward() * fix:Length()
	
	if angs.p > 90 or angs.p < -90 then
		fix.x = -fix.x
	end
	
	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
		end
	end
	if !edge then
		cmd:SetViewAngles(mine.fa)
	end
end

function mine.CalculateTheViewUsingSuperiorMethodsSuchAsDoSilentTakenDirectlyFromHeraVersionFourPointTwoPointSeven(ply, pos, angle, fov, nearZ, farZ)
	local view = {}
	view.angles = mine.fa
	view.origin = pos
	view.fov = (245 + 5) / 2 - 7 + 68 - 61 // Hah Hah! Gotta Protect My Superior FOV!

	return view
end

hook.Add("DrawOverlay", "mine.esp", mine.eeeeeesp)
hook.Add("CreateMove", "mine.edge", mine.edgey)
hook.Add("CalcView", "mine.hackertypre", mine.CalculateTheViewUsingSuperiorMethodsSuchAsDoSilentTakenDirectlyFromHeraVersionFourPointTwoPointSeven)

function mine.TheTrulySuperiorMethodOfMakingAMenuUsingDermaHowverThisMenuIsNotMadeByTheTrueDermaGodPMoneySignSilentAlsoKnownAsXanderWilburn()
	local frame = vgui.Create("DFrame")
	frame:SetSize(600, 500)
	frame:SetTitle("MineWebz")
	frame:Center()
	frame:MakePopup()

	local esp = vgui.Create("DButton", frame)
	esp:SetPos(8, 24)
	esp:SetSize(600, 48)
	esp:SetText("")
	function esp.Paint()
		surface.SetDrawColor(Color(255, 185, 0))
		surface.DrawOutlinedRect(0, 0, 48, 48)
		if mine.esp:GetBool() then
			surface.DrawRect(2, 2, 44, 44)
		end

		draw.SimpleText("Truly Revolutionary Player Viewing Utility", "Trebuchet18", 50, 24, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	function esp.DoClick()
		mine.esp:SetBool(!mine.esp:GetBool())
	end

	local edge = vgui.Create("DButton", frame)
	edge:SetPos(8, 78)
	edge:SetSize(600, 400)
	edge:SetText("")
	function edge.Paint()
		surface.SetDrawColor(Color(255, 185, 0))
		surface.DrawOutlinedRect(0, 0, 48, 48)
		if mine.edge:GetBool() then
			surface.DrawRect(2, 2, 44, 44)
		end

		draw.SimpleText("So Basically What This Does Is It Shoves Your Head So Far Into The Wall That The Server Thinks", "Trebuchet18", 50, 24, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("You Are Wearing A Fedora And Adjusts The Hitboxes Accordingly, Making You The True Edge", "Trebuchet18", 50, 38, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Master", "Trebuchet18", 50, 52, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	function edge.DoClick()
		mine.edge:SetBool(!mine.edge:GetBool())
	end
end

concommand.Add("mine_menu", mine.TheTrulySuperiorMethodOfMakingAMenuUsingDermaHowverThisMenuIsNotMadeByTheTrueDermaGodPMoneySignSilentAlsoKnownAsXanderWilburn)