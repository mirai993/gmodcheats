--[[
	MOD/lua/IMNsucks.lua
	IMN | STEAM_0:0:29195781 <68.226.218.32:27005> | [19-12-13 02:18:38PM]
	===BadFile===
]]

local col = Color(255,0,0,255)
local col2 = Color( 100,0,225,20 )
local col3 = Color(173,255,47,180)
local col4 = Color(255,140,0,180)
local col5 = Color(0,255,0,255)
local mat = "models/debug/debugwhite"
CreateClientConVar("FreshyP_Esp", 1, true, false)

local materialshit = {
	["$basetexture"]	= "models/debug/debugwhite",
	["$model"]			= 1,
	["$translucent"]	= 1,
	["$alpha"]			= 1,
	["$nocull"]			= 1,	
	["$ignorez"]		= 1,
	["$additive"]		= 0
}
local mat1 = CreateMaterial("shitheadmaterial","UnlitGeneric",materialshit)

surface.CreateFont("hudfont",
					{
					font = "hudfont",
					size = 11,
					weight = 110
					})

hook.Add("HUDPaint", "I LIKE MEN", function()
	if (GetConVarNumber ("FreshyP_Esp") == 1) then
		for k, v in pairs(player.GetAll()) do
			if (v && IsValid(v)) then
				local strEntClass = v:GetClass();
					if (v:IsPlayer()) then
						if (v:Alive() /*&& v:Health() <= 0*/) then
						cam.Start3D(EyePos(), EyeAngles())
						cam.IgnoreZ ( true )
						v:SetMaterial(mat)
						v:SetColor(col)
						render.MaterialOverride(mat)
						render.SetColorModulation( 1, 0, 0 )
						render.SetBlend ( 100 )
						v:DrawModel()
						cam.End3D()
						cam.IgnoreZ( false )
					end
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "nigger", function()
if (GetConVarNumber ("FreshyP_Esp") == 1) then
	for k, v in pairs(ents.GetAll()) do
		if (v && IsValid(v)) then
			local strEntClass = v:GetClass();
			if (v:IsNPC()) then
			cam.Start3D(EyePos(), EyeAngles())
			v:SetMaterial("models/debug/debugwhite")
			v:SetColor(col3)
			render.MaterialOverride(mat)
			render.SetColorModulation( 0, 1, 0 )
			render.SuppressEngineLighting( false )
			v:DrawModel()
			cam.End3D()
			
			elseif (strEntClass == "prop_physics" || strEntClass == "gmod_button") then
			cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
			v:SetMaterial(mat1)
			v:SetColor(col2)
			v:SetRenderMode( RENDERMODE_TRANSALPHA )
			render.MaterialOverride(mat1)
			render.SuppressEngineLighting( true )
			render.SetBlend( 0.3 )
			render.SetColorModulation( 0.5, 0, 1)
			v:DrawModel()
			cam.End3D()
			cam.IgnoreZ(false)

			elseif (strEntClass == "func_door" || strEntClass == "func_door_rotating" || strEntClass == "func_breakable" || strEntClass == "func_wall" || strEntClass == "prop_door_rotating") then
			v:SetColor(col4)
			render.MaterialOverride(mat)   
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:DrawModel()

			elseif (string.match(strEntClass, "_printer") ||  strEntClass == "drug_lab") then
			v:SetColor(col5)
			render.MaterialOverride(mat)
			v:SetRenderMode(RENDERMODE_TRANSALPHA)

			elseif (strEntClass == "spawned_money") then
			local vMoneyPos = (v:GetPos() + Vector(0, 0, 5)):ToScreen()
				if (v.dt ~= nil) then
					if (v.dt.amount ~= nil) then
					draw.SimpleText( "$" .. v.dt.amount, "hudfont", vMoneyPos.x, vMoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
					else
						draw.SimpleText( "$", "hudfont", vMoneyPos.x, vMoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
			end
		end
	end
end)







			
