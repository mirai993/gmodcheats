--[[
	MOD/lua/lazerthing.lua
	IMN | STEAM_0:0:29195781 <68.226.218.32:27005> | [19-12-13 02:18:39PM]
	===BadFile===
]]

-- Copy and pasted from Integra :D

local LaserMaterial = Material("tripmine_laser")
CreateClientConVar("FreshyP_lazereyes", 1, true, false)
CreateClientConVar("FreshyP_lazerup", 1, true, false)

hook.Add("HUDPaint", "DrawLaser", function()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() and v:Alive() and !IsValid() then
				local pos = v:EyePos()
				local endpos = v:GetEyeTrace().HitPos

				render.SetMaterial(LaserMaterial)

					if (GetConVarNumber ("FreshyP_lazereyes") == 1) then
					render.DrawBeam(pos, endpos, 10, 1, 1, Color(255, 0, 0, 255))
				end

					if (GetConVarNumber ("FreshyP_lazerup") == 1) then
					local tr = {}
						tr.start = v:EyePos()
						tr.endpos = v:EyePos() + Vector(0, 0, 8192)
						tr.filter = v
					local trace = util.TraceLine(tr)

					cam.IgnoreZ(true)
						render.DrawBeam(pos, trace.HitPos, 15, 1, 1, Color(0, 255, 0, 255))
					cam.IgnoreZ(false)
				end
			end
		end
	cam.End3D()
end)

CreateConVar("laser_eyetracer", 1)
CreateConVar("laser_skytracer", 1)