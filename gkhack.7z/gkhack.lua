/*------------------------------------------------------------------------------------------------------
GK Public Hack 1.0
By JustiMaN
*/------------------------------------------------------------------------------------------------------

if !( CLIENT ) then return end

local concommand 			= concommand
local cvars 				= cvars
local debug 				= debug
local ents 					= ents
local file					= file
local hook 					= hook
local math 					= math
local spawnmenu				= spawnmenu
local string 				= string
local surface 				= surface
local table 				= table
local timer 				= timer
local util 					= util
local vgui 					= vgui

local Angle 				= Angle
local CreateClientConVar 	= CreateClientConVar
local CurTime 				= CurTime
local ErrorNoHalt			= ErrorNoHalt
local FrameTime 			= FrameTime
local GetConVarString 		= GetConVarString
local GetViewEntity 		= GetViewEntity
local include 				= include
local ipairs 				= ipairs
local LocalPlayer 			= LocalPlayer
local pairs 				= pairs
local pcall 				= pcall
local print 				= print
local RunConsoleCommand 	= RunConsoleCommand
local ScrH 					= ScrH
local ScrW 					= ScrW
local tonumber 				= tonumber
local type 					= type
local unpack 				= unpack
local ValidEntity 			= ValidEntity
local Vector 				= Vector

local GK	= {}
GK.OLD		= {}

GK.Commands = {}
GK.Files 	= { "gk_pub", "gk_wireframemat", "gk_solid_mat" } // Add the the files you use into here, example: GK.Files = { "gk_pub", "other_script" }
GK.Path		= {}
GK.Timers	= {}
GK.Friends	= {}

GK.CVars = {
	aim_shoot = 0,
	aim_friends = 0,
	aim_steam = 0,
	aim_fov = 360,
	aim_recoil = 1,
	aim_player = 1,
	aim_npc = 0,
	esp_player = 1,
	esp_npc = 1,
	esp_entity = 0,
	esp_aimspot = 0,
	esp_wallhack = 1,
	esp_dead = 1,
	misc_cross = 0,
	misc_admin = 0,
	misc_bhop = 1,
	misc_auto = 0
}

GK.Hooks = {}

GK.OLD.GCV			= GetConVar
GK.OLD.CVE			= ConVarExists
GK.OLD.GCVN			= GetConVarNumber
GK.OLD.GCVS			= GetConVarString
GK.OLD.CCCV			= CreateClientConVar
GK.OLD.RCC			= RunConsoleCommand
GK.OLD.hook			= table.Copy( hook )
GK.OLD.concommand	= table.Copy( concommand )
GK.OLD.cvars		= table.Copy( cvars )
GK.OLD.file			= table.Copy( file )
GK.OLD.debug		= table.Copy( debug )
GK.OLD.timer		= table.Copy( timer )
GK.OLD.PCC			= _R.Player.ConCommand
GK.OLD.CINT			= _R.ConVar.GetInt
GK.OLD.CBOOL		= _R.ConVar.GetBool

GK.Aiming	= false
GK.Target	= nil
GK.FilePath	= "lua\\autorun\\client\\gk_pub.lua"
GK.Version	= "1.0 | By JustiMaN"
GK.Prefix	= "GK_"
GK.Angles	= Angle( 0, 0, 0 )
GK.AimAng	= Angle( 0, 0, 0 )
GK.Viewfix	= Angle( 0, 0, 0 )

function GK:Find( var, lower )
	return string.find( string.lower( var ), lower )
end

function GK:Msg( msg )
	return MsgN( "[GK]: " .. msg )
end

// Later if I care about this I will change the method I add hooks.
function GK:AddHook( typ, func )
	local ran = ""
	for i = 1, math.random( 5, 30 ) do
		ran = ran .. string.char( math.random( 65, 117 ) )
	end
	table.insert( GK.Hooks, ran )
	return GK.OLD.hook.Add( typ, ran, func )
end

function GK:AddCommand( name, func )
	table.insert( GK.Commands, name )
	return GK.OLD.concommand.Add( name, func )
end

function GK:CreateTimer( name, time, reps, func )
	table.insert( GK.Timers, name )
	return GK.OLD.timer.Create( name, time, reps, func )
end

function GK.SetUp()
	for k, v in pairs( GK.CVars ) do
		GK.OLD.CCCV( GK.Prefix .. k, v, true, false )
	end
end

function GK:GetValue( cvar, val )
	if ( GK.OLD.GCVN( GK.Prefix .. cvar ) == val ) then
		return true
	end
	return false
end

function GK:GetConVarNumber( cvar )
	return GK.OLD.GCVN( GK.Prefix .. cvar )
end

function GK:DrawText( text, font, x, y, colour, xalign, yalign )

	if ( font == nil ) then font = "Default" end
	if ( x == nil ) then x = 0 end
	if ( y == nil ) then y = 0 end
	
	local curX, curY, curString = x, y, ""
	
	surface.SetFont( font )
	local sizeX, lineHeight = surface.GetTextSize( "\n" )
	
	for i = 1, string.len( text ) do
		local ch = string.sub( text, i, i )
		if ( ch == "\n" ) then
			if ( string.len( curString ) > 0 ) then
				draw.SimpleText( curString, font, curX, curY, colour, xalign, yalign )
			end
			
			curY, curX, curString = curY + ( lineHeight / 2 ), x, ""
			
		elseif ( ch == "\t" ) then
			if ( string.len( curString ) > 0 ) then
				draw.SimpleText( curString, font, curX, curY, colour, xalign, yalign )
			end
			local tmpSizeX,tmpSizeY = surface.GetTextSize( curString )
			curX = math.ceil( ( curX + tmpSizeX ) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if ( string.len( curString ) > 0 ) then
		draw.SimpleText( curString, font, curX, curY, colour, xalign, yalign )
	end
end

function GK:IsAdmin(e)
	
	if ( e:IsAdmin() ) then 
		return true
	elseif ( e:IsSuperAdmin() ) then 
		return true
	end
	return false
end

function GK:GetAdminType(e)

	local ply = LocalPlayer()
	
	if ( e:IsAdmin() && !e:IsSuperAdmin() ) then
		return "Admin"
	elseif ( e:IsSuperAdmin() ) then
		return "Super Admin"
	end
	return ""
end

function GK:CreateMaterial()
	
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
   
   local mat = CreateMaterial( "GK_wireframemat", "Wireframe", BaseInfo )
   //local mat = CreateMaterial( "GK_solid_mat", "VertexLitGeneric", BaseInfo )

   return mat

end

--[[--------------------------------------
Everything below here is the hack code.
--]]--------------------------------------

function GK:IsValid( e, typ )
	local ply = LocalPlayer()
	if ( typ == true ) then
		if ( !ValidEntity( e ) ) then return false end
		if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() || e == ply ) then return false end
		if ( e:IsPlayer() && ( GK:GetValue( "esp_dead", 0 ) && !e:Alive() ) && !GK:Find( team.GetName( e:Team() ), "spec" ) ) then return false end
		if ( e:IsNPC() && ( e:GetMoveType() == 0 ) ) then return false end
		if ( e:IsWeapon() && ( e:GetMoveType() == 0 ) ) then return false end
		return true
	elseif ( typ == false ) then
		if ( !ValidEntity( e ) ) then return false end
		if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() || e == ply ) then return false end
		if ( e:IsPlayer() && !e:Alive() && !GK:Find( team.GetName( e:Team() ), "spec" ) ) then return false end
		if ( e:IsNPC() && ( e:GetMoveType() == 0 ) ) then return false end
		if ( e:IsWeapon() && ( e:GetMoveType() == 0 ) ) then return false end
		return true
	end
	return true
end

function GK:ConVarEnabled( e )
	if ( GK:GetValue( "esp_wallhack", 0 ) ) then return false end
	if ( e:IsPlayer() && GK:GetValue( "esp_player", 0 ) ) then return false end
	if ( e:IsNPC() && GK:GetValue( "esp_npc", 0 ) ) then return false end
	if ( e:IsWeapon() && GK:GetValue( "esp_entity", 0 ) ) then return false end
	return true
end

function GK:CreatePos( e )
	local ply = LocalPlayer()
	local col = GK:SetColors( e )
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v	= math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	if ( e:IsPlayer() ) then v = d / 30 else v = 0 end
	local pos	= e:LocalToWorld( e:OBBMaxs() ) + Vector( 0, 0, v )
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY, pos
end

function GK:SetColors( e )

	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col

	if ( e:IsPlayer() ) then
		col = team.GetColor( e:Team() )
	elseif ( e:IsNPC() ) then
		col = Color( 255, 0, 0, 255 )
	elseif ( e:IsWeapon() ) then
		col = Color( 255, 128, 0, 255 )
	else
		col = Color( 255, 255, 255, 255 )
	end
	
	return col
end

function GK:DrawRect( x, y, w, h, col )
    surface.SetDrawColor( col.r, col.g, col.b, col.a )
    surface.DrawRect( x, y, w, h )
end

function GK:GetPos( e, pos )
	if ( type( pos ) == "string" ) then
		return ( e:GetBonePosition( e:LookuGKone( pos ) ) )
	elseif ( type( pos ) == "Vector" ) then
		return ( e:LocalToWorld( pos ) )
	end
	return ( e:LocalToWorld( pos ) )
end

function GK:GenerateSpot( e )
	local spt = e:LocalToWorld( e:OBBCenter() )
	spt = GK:GetPos( e, "ValveBiped.Bip01_Head1" )
	
	local m = e:GetModel()
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then 	spt = GK:GetPos( e, Vector( 0, 0, 5 ) ) end
	if ( m == "models/seagull.mdl" ) then 							spt = GK:GetPos( e, Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then 					spt = GK:GetPos( e, "Scanner.Body" ) end
	if ( m == "models/hunter.mdl" ) then 							spt = GK:GetPos( e, "MiniStrider.body_joint" ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then		spt = GK:GetPos( e, "Barrel" ) end
	if ( m == "models/dog.mdl" ) then 								spt = GK:GetPos( e, "Dog_Model.Eye" ) end
	if ( m == "models/vortigaunt.mdl" ) then 						spt = GK:GetPos( e, "ValveBiped.Head" ) end
	if ( m == "models/antlion.mdl" ) then 							spt = GK:GetPos( e, "Antlion.Body_Bone" ) end
	if ( m == "models/antlion_guard.mdl" ) then 					spt = GK:GetPos( e, "Antlion_Guard.Body" ) end
	if ( m == "models/antlion_worker.mdl" ) then 					spt = GK:GetPos( e, "Antlion.Head_Bone" ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then 				spt = GK:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/zombie/fast.mdl" ) then 						spt = GK:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/headcrabclassic.mdl" ) then 					spt = GK:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/headcrabblack.mdl" ) then 					spt = GK:GetPos( e, "HCBlack.body" ) end
	if ( m == "models/headcrab.mdl" ) then 							spt = GK:GetPos( e, "HCFast.body" ) end
	if ( m == "models/zombie/poison.mdl" ) then 					spt = GK:GetPos( e, "ValveBiped.Headcrab_Cube1" ) end
	if ( m == "models/zombie/classic.mdl" ) then 					spt = GK:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then 				spt = GK:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then				spt = GK:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/combine_strider.mdl" ) then 					spt = GK:GetPos( e, "Combine_Strider.Body_Bone" ) end
	if ( m == "models/combine_dropship.mdl" ) then 					spt = GK:GetPos( e, "D_ship.Spine1" ) end
	if ( m == "models/combine_helicopter.mdl" ) then 				spt = GK:GetPos( e, "Chopper.Body" ) end
	if ( m == "models/gunship.mdl" ) then 							spt = GK:GetPos( e, "Gunship.Body" ) end
	if ( m == "models/lamarr.mdl" ) then 							spt = GK:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/mortarsynth.mdl" ) then 						spt = GK:GetPos( e, "Root Bone" ) end
	if ( m == "models/synth.mdl" ) then 							spt = GK:GetPos( e, "Bip02 Spine1" ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then 				spt = GK:GetPos( e, "ValveBiped.Head" ) end
	
	return spt
end

function GK:IsVisible( e )
	if ( !ValidEntity(e) ) then return false end
	
	local ply, spt = LocalPlayer(), GK:GenerateSpot(e)
	
    local visible = {

			start = ply:GetShootPos(),
			endpos = spt,
			filter = { ply, e }

		}

	local trace = util.TraceLine( visible )
	
	if trace.Fraction == 1 then
		return true
    end
    return false 
end

local hp = false
function GK:HealthBar( e )
	if ( e:IsPlayer() && e:Health() > 300 || !e:Alive() ) then return end
	
	local col, normalhp = GK:SetColors(e), 100
	local maxX, minX, maxY, minY, oPos = GK:CreatePos(e)
	
	if( e:Health() > normalhp ) then
		normalhp = e:Health()
	end
	
	local dmg, nor = normalhp / 4, e:Health() / 4
	
	oPos.x = oPos.x - ( dmg / 2 ) + 13
	oPos.y = oPos.y + 15
	
	GK:DrawRect( oPos.x - 1, oPos.y - 1, dmg + 2, 4 + 2, Color( 0, 0, 0, 255 ) )
	GK:DrawRect( oPos.x, oPos.y, nor, 4, col )
end

function GK:GetActiveWeapon( e ) // Removed due to shittyness, rifk.
	if ( !e:GetActiveWeapon():IsValid() ) then return "None" end
	local wep = e:GetActiveWeapon():GetPrintName()
	wep = string.Replace( wep, "#HL2_", "" )
	wep = string.Replace( wep, "#GMOD_", "" )
	wep = string.Replace( wep, "_", " " )
	wep = string.lower( wep )
	return wep
end

function GK:CreateDrawings( e )
	local ply = LocalPlayer()
	local text, box = "", false
	local maxX, minX, maxY, minY, pos = GK:CreatePos(e)
	
	if ( e:IsPlayer() && GK:GetValue( "esp_player", 1 ) ) then
		if ( e:Health() > 300 ) then hp = false else hp = true end
		
		box = true
		if ( !hp ) then text = text .. e:Nick() .. "\nHp: " .. e:Health() else text = text .. e:Nick() GK:HealthBar( e ) end
		if ( GK:GetValue( "esp_dead", 1 ) && !e:Alive() ) then text = text .. "\n*DEAD*" else text = text end
	elseif ( e:IsNPC() && GK:GetValue( "esp_npc", 1 ) ) then
		box = true
		local npc = e:GetClass()
		npc = string.Replace( npc, "npc_", "" )
		npc = string.Replace( npc, "_", "" )
		npc = string.upper( npc )
		text = text .. npc
	elseif ( e:IsWeapon() && GK:GetValue( "esp_entity", 1 ) ) then
		box = false
		local ent = e:GetClass()
		ent = string.Replace( ent, "weapon_", "" )
		ent = string.Replace( ent, "ttt_", "" )
		ent = string.Replace( ent, "zm_", "" )
		ent = string.Replace( ent, "cs_", "" )
		ent = string.Replace( ent, "css_", "" )
		ent = string.Replace( ent, "real_", "" )
		ent = string.Replace( ent, "mad_", "" )
		ent = string.Replace( ent, "_", " " )
		ent = string.lower( ent )
		text = text .. ent
	end
	local col = GK:SetColors(e)
	
	return text, box, maxX, minX, maxY, minY, pos, col
end

function GK:ValidAimTarget( e )
	local ply = LocalPlayer()
	
	if ( !ValidEntity( e ) ) then return false end
	if ( e:IsNPC() && !util.IsValidModel( e:GetModel() || "" ) ) then return false end
	if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsPlayer() && GK:GetValue( "aim_steam", 1 ) && ( e:GetFriendStatus() == "friend" ) ) then return false end
	if ( e:IsPlayer() && GK:GetValue( "aim_friends", 1 ) && ( e:Team() == ply:Team() ) ) then return false end
	if ( e:IsPlayer() && GK:GetValue( "aim_player", 0 ) ) then return false end
	if ( e:IsNPC() && GK:GetValue( "aim_npc", 0 ) ) then return false end
	return true
end
	
function GK.Aimbot( ucmd )
	local ply 	= LocalPlayer()
	local m 	= Angle( ucmd:GetMouseY() * GK.OLD.GCVN( "m_pitch" ), ucmd:GetMouseX() * -GK.OLD.GCVN("m_yaw") ) || Angle( 0, 0, 0 )
	GK.AimAng 	= GK.AimAng + m
	GK.Viewfix 	= ucmd:GetViewAngles()
	
	// I'm not good at making aimbots, so I stealz one.
	if ( GK.Aiming ) then
	
		if ( !GK:ValidAimTarget(GK.Target) || !GK:IsVisible(GK.Target) ) then
			GK.Target = nil
			local f, o, a, t, b = GK:GetConVarNumber( "aim_fov" ), { p, y }
			for k, e in pairs( ents.GetAll() ) do
				if ( GK:ValidAimTarget(e) && GK:IsVisible(e) ) then
					local tP, oP = math.Round( e:GetPos():Distance( ply:GetPos() ) ), math.Round( ply:GetPos():Distance( e:GetPos() ) )
					b = GK:GenerateSpot(e)
					
					a, t = ply:GetAimVector():Angle(), (b - ply:GetShootPos()):Angle()
					o.p, o.y = math.abs(math.NormalizeAngle(a.p - t.p)) / 2, math.abs(math.NormalizeAngle(a.y - t.y)) / 2
					
					if ( !GK.Target || tP > oP ) && ( o.p <= f && o.y <= f ) then GK.Target = e end
				end
			end
		end
		if ( !ValidEntity(GK.Target) || !GK.Aiming ) then return end
		local comp, myPos = GK:GenerateSpot(GK.Target), ply:GetShootPos()
		comp = comp + ( GK.Target:GetVelocity() / 45 - ply:GetVelocity() / 45 )
		
		local ang = ( comp-myPos ):Angle()
		ang.p = math.NormalizeAngle( ang.p )
		ang.y = math.NormalizeAngle( ang.y )
		ang.r = 0
		
		GK.AimAng	= ang
		GK.Viewfix 	= ang
	end
	
	GK.AimAng.r	= 0
	GK.Angles 	= GK.AimAng
	GK.Angles.p	= math.NormalizeAngle( GK.Angles.p )
	GK.Angles.y	= math.NormalizeAngle( GK.Angles.y )
	ucmd:SetViewAngles( GK.Angles )
	
	// Autoshoot
	if ( GK.Aiming && GK.Target != nil && GK:GetValue( "aim_shoot", 1 ) ) then
		GK.OLD.RCC( "+attack" )
		timer.Simple( 0.25, function() GK.OLD.RCC( "-attack" ) end )
	elseif ( ( !GK.Aiming && GK.Target == nil || GK.Target == nil || !GK.Aiming ) && !GK:GetValue( "aim_shoot", 0 ) ) then
		GK.OLD.RCC( "-attack" )
	end
end

GK:AddCommand( "+" .. GK.Prefix .. "aim", function() GK.Aiming = true end )
GK:AddCommand( "-" .. GK.Prefix .. "aim", function() GK.Aiming = false GK.Target = nil end )

function GK.Norecoil( ucmd )
	local wep = LocalPlayer():GetActiveWeapon()
	if ( GK:GetValue( "aim_recoil", 1 ) && !GK.Aiming ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 180, angles = GK.Angles }
	elseif ( GK:GetValue( "aim_recoil", 1 ) && GK.Aiming && GK.Target != nil  ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 180, angles = GK.Angles }
	elseif ( GK:GetValue( "aim_recoil", 1 ) && GK.Aiming && GK.Target == nil ) then
		if ( wep.Primary ) then wep.Primary.Recoil = 0 end
		return { origin = 180, angles = GK.Viewfix }
	end
	return
end

function GK.CreateESP()
	local ply = LocalPlayer()
	for k, e in pairs( ents.GetAll() ) do
		if ( GK:IsValid( e, true ) ) then
			local text, box, maxX, minX, maxY, minY, pos, col = GK:CreateDrawings(e)
			local color = Color( col.r, col.g, col.b, 255 )
			
			if ( box ) then
				surface.SetDrawColor( color )

				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )
			
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
			end
			
			GK:DrawText( 
				text,
				"DefaultSmall",
				pos.x,
				pos.y,
				color,
				TEXT_ALIGN_LEFT,
				TEXT_ALIGN_TOP
			)
		end
	end
	
	if ( GK:GetValue( "misc_cross", 1 ) ) then
		local s, x, y = 10, ScrW() / 2, ScrH() / 2
		surface.SetDrawColor( 0, 255, 0, 255 )
		surface.DrawLine( x - 20, y - 20, x + 20, y + 20 )
		surface.DrawLine( x - 20, y + 20, x + 20, y - 20)
	end
	
	if ( GK:GetValue( "esp_aimspot", 1 ) ) then
		for k, e in pairs( ents.GetAll() ) do
			if ( GK.Target != nil && e == GK.Target && GK.Aiming ) then
				local bone = GK:GenerateSpot(GK.Target) + ( GK.Target:GetVelocity() / 45 - ply:GetVelocity() / 45 )
				local pos = bone:ToScreen()
				draw.RoundedBox( 0, pos.x - 2, pos.y - 2, 4, 4, Color( 255, 0, 0, 255 ) )
			end
		end
	end
	
	if ( GK:GetValue( "misc_admin", 1 ) ) then
	local admin, adminnum, x, y = "", 0, ScrW(), ScrH()
		for k, e in pairs( player.GetAll() ) do
			if ( e:IsPlayer() && GK:IsAdmin(e) ) then
				admin = ( admin .. e:Nick() .. "[" .. GK:GetAdminType(e) .. "]" .. "\n" )
				adminnum = adminnum + 1
			end
		end
		
		local wide, tall = 300, ( adminnum * 20 ) + 20
		local posX, posY = x / 2 + ( wide - wide ) + 300, y / 2 + ( tall + tall ) - 400
		
		if ( adminnum == 0 ) then
			admin = ""
			admin = ( "\nThere are no admins on right now" )
			wide, tall = 300, 40
		end
		
		draw.RoundedBox( 0, posX - ( wide / 2 ), posY - 10, 300, tall, Color( 0, 0, 0, 150 ) )
		GK:DrawText(
			"Admins: " .. admin,
			"Default",
			posX,
			posY,
			Color( 0, 255, 0, 255 ),
			1,
			1
		)
	end
end

function GK.Wireframe()
	local ply, c = LocalPlayer(), ( 1 / 255 )
	for k, e in pairs( ents.GetAll() ) do
		if ( GK:IsValid( e, false ) && GK:ConVarEnabled(e) && !e:IsWeapon() ) then
			cam.Start3D( EyePos(), EyeAngles() )
				local mat, col = GK:CreateMaterial(), GK:SetColors(e)
				render.SuppressEngineLighting( true )
				render.SetColorModulation( ( col.r * c ), ( col.g * c ), ( col.b * c ) )
				SetMaterialOverride( mat )
				e:DrawModel()
				render.SuppressEngineLighting( false )
				render.SetColorModulation( 1, 1, 1 )
				SetMaterialOverride()
				e:DrawModel()
			cam.End3D()
		end
	end
end

function GK.ThinkFunctions()
	local ply, jump, attack = LocalPlayer(), false, false
	if ( GK:GetValue( "misc_bhop", 1 ) && input.IsKeyDown( KEY_SPACE ) ) then
		if ( ply:OnGround() ) then
			GK.OLD.RCC( "+jump" )
			GK:CreateTimer( "BHOP", 0.1, 0, function() GK.OLD.RCC( "-jump" ) end )
		end
	end
end

GK:AddHook( "CreateMove", GK.Aimbot )
GK:AddHook( "CalcView", GK.Norecoil )
GK:AddHook( "HUDPaint", GK.CreateESP )
GK:AddHook( "Initialize", GK.SetUp )
GK:AddHook( "Think", GK.ThinkFunctions )
GK:AddHook( "RenderScreenspaceEffects", GK.Wireframe )

// Menu
local Menu

function GK:AddOptionCheckbox( text, cvar, parent, amt )
	local checkbox = vgui.Create( "DCheckBoxLabel" )
	checkbox:SetPos( 10, amt )
	checkbox:SetText( text )
	checkbox:SetConVar( GK.Prefix .. cvar )
	checkbox:SetParent( parent )
	checkbox:SetTextColor( Color( 0, 0, 0, 255 ) )
	checkbox:SizeToContents()
end

function GK:AddOptionButton( name, posY, sizeW, sizeH, parent, func )
	if ( func == "" ) then func = function() end end
	
	local button = vgui.Create( "DButton" )
	button:SetParent( parent )
	button:SetSize( sizeW, sizeH )
	button:SetPos( 10, posY )
	button:SetText( name )
	button:MakePopup()
	button.DoClick = func
end

function GK:AddOptionSlider( text, cvar, parent, min, max, pos )
	local slider = vgui.Create( "DNumSlider" )
	slider:SetParent( parent )
	slider:SetPos( 10, pos )
	slider:SetSize( 200, 70 )
	slider:SetText( "" )
	slider:SetMin( min )
	slider:SetMax( max )
	slider:SetDecimals( 0 )
	slider:SetConVar( GK.Prefix .. cvar )
		local label = vgui.Create( "DLabel" )
		label:SetParent( parent )
		label:SetText( text )
		label:SetPos( 10, pos )
		label:SetWide( 100 )
		label:SetTextColor( Color( 0, 0, 0 ) )
		label:SizeToContents()
end

function GK.Menu()
	local panel = vgui.Create( "DFrame" )
	panel:SetPos( ScrW() / 2 - 250 / 2, ScrH() / 2 - 250 / 2 )
	panel:SetSize( 250, 300 )
	panel:SetTitle( "GK Mini Pub" .. GK.Version )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:MakePopup()
	Menu = panel
	
	local propsheet = vgui.Create( "DPropertySheet" )
	propsheet:SetParent( panel )
	propsheet:SetPos( 10, 30 )
	propsheet:SetSize( 230, 260 )
	
	local esp = vgui.Create( "DPanel", propsheet )
	local misc = vgui.Create( "DPanel", propsheet )
	
	
	GK:AddOptionCheckbox( "Players", "esp_player", esp, 10 )
	GK:AddOptionCheckbox( "NPC", "esp_npc", esp, 30 )
	GK:AddOptionCheckbox( "Entity", "esp_entity", esp, 50 )
	GK:AddOptionCheckbox( "Chams", "esp_wallhack", esp, 70 )
	GK:AddOptionCheckbox( "Show Aimspot", "esp_aimspot", esp, 90 )
	GK:AddOptionCheckbox( "Show Dead", "esp_dead", esp, 110 )
	
	GK:AddOptionCheckbox( "Crosshair", "misc_cross", misc, 10 )
	GK:AddOptionCheckbox( "Adminlist", "misc_admin", misc, 30 )
	GK:AddOptionCheckbox( "Bunnyhop", "misc_bhop", misc, 50 )
	//GK:AddOptionCheckbox( "Autopistol", "misc_auto", misc, 70 )
	
	propsheet:AddSheet( "Main", esp, nil, false, false, nil )
	propsheet:AddSheet( "Misc", misc, nil, false, false, nil )
end
GK:AddCommand( "gk_menu", GK.Menu )

// Spoof commands so nigz don't blacklist us.
function CreateClientConVar( cvar, val, save, data )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.CCCV( cvar, val, save, data ) end
	local done = {}
	if ( done[cvar] != nil && GK.CVars[cvar] != nil ) then
		return GK.OLD.GCV( cvar )
	end
	done[cvar] = true
	return GK.OLD.CCCV( cvar, val, save, data )
end

function GetConVar( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.GCV( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( k, cvar ) ) then
			return
		end
	end
	return GK.OLD.GCV( cvar )
end

function ConVarExists( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.CVE( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( k, cvar ) ) then
			return false
		end
	end
	return GK.OLD.CVE( cvar )
end

function GetConVarNumber( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.GCVN( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( k, cvar ) ) then
			return
		end
	end
	return GK.OLD.GCVN( cvar )
end

function GetConVarString( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.GCVS( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( k, cvar ) ) then
			return
		end
	end
	return GK.OLD.GCVS( cvar )
end

function file.Read( path, bool )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.Read( path, bool ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			return GK.Path[path] && GK.Path[path].cont || nil
		end
	end
	return GK.OLD.file.Read( path, bool )
end

function file.Exists( path, bool )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.Exists( path, bool ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			return GK.Path[path] && true || false
		end
	end
	return GK.OLD.file.Exists( path, bool )
end

function file.Size( path )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.Size( path ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			return GK.Path[path] && GK.Path[path].size || -1
		end
	end
	return GK.OLD.file.Size( path )
end

function file.Time( path )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.Time( path ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			return GK.Path[path] && GK.Path[path].time || 0
		end
	end
	return GK.OLD.file.Time( path )
end

function file.Find( path, bool )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	local o = GK.OLD.file.Find( path, bool )
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.Find( path, bool ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			table.remove( o, k )
		end
	end
	return GK.OLD.file.Find( path, bool )
end

function file.FindInLua( path )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	local o = GK.OLD.file.FindInLua( path )
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.file.FindInLua( path ) end
	for k, v in pairs( GK.Files ) do
		if ( GK:Find( path, v ) ) then
			table.remove( o, k )
		end
	end
	return GK.OLD.file.FindInLua( path )
end

function hook.Add( typ, name, func )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.hook.Add( typ, name, func ) end
	for k, v in pairs( GK.Hooks ) do
		if ( GK:Find( name, v ) ) then
			return nil
		end
	end
	return GK.OLD.hook.Add( typ, name, func )
end

function hook.Remove( typ, name, func )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.hook.Remove( typ, name, func ) end
	for k, v in pairs( GK.Hooks ) do
		if ( GK:Find( name, v ) ) then
			return nil
		end
	end
	return GK.OLD.hook.Remove( typ, name, func )
end

function concommand.Add( name, func )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.concommand.Add( name, func ) end
	for k, v in pairs( GK.Commands ) do
		if ( GK:Find( name, v ) ) then
			return nil
		end
	end
	return 
	GK.OLD.concommand.Add( name, func )
end

function concommand.Remove( name, func )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.concommand.Remove( name, func ) end
	for k, v in pairs( GK.Commands ) do
		if ( GK:Find( name, v ) ) then
			return nil
		end
	end
	return 
	GK.OLD.concommand.Remove( name, func )
end

function _R.ConVar.GetInt( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.CINT( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( cvar:GetName(), k ) ) then
			return
		end
	end
	return GK.OLD.CINT( cvar )
end

function _R.ConVar.GetBool( cvar )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.CBOOL( cvar ) end
	for k, v in pairs( GK.CVars ) do
		if ( GK:Find( cvar:GetName(), k ) ) then
			return
		end
	end
	return GK.OLD.CBOOL( cvar )
end

function debug.getinfo( thread, func )
	GK.CallPath	= GK.OLD.debug.getinfo(2)['short_src']
	if ( GK.CallPath && GK.CallPath == GK.FilePath ) then return GK.OLD.debug.getinfo( thread, func ) end
	return {}
end