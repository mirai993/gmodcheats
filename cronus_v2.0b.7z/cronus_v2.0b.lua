--[[
// Project Cronus // Thanks to anyone who helped me with this // This is just a HvH Cheat, Not some DarkRP Shit // I take no credit for most of this code // Enjoy Cronus! //
]]--

--[[ Start of the cheat, localizing, requires, and other useless bullshit ]]--

if ( SERVER ) then return end -- We only want this to work clientside ;)

local Cronus = {}
local Version = 2.0 .. " Beta "
local CreateClientConVar = CreateClientConVar;
local x = ScrW() / 2 --Crosshair
local y = ScrH() / 2 --Crosshair
local gap = 0 --Crosshair Gap
local length = 5 --Crosshair Length
local StoredAngle = LocalPlayer():EyeAngles()
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local AimEnt = ""
local ShouldShoot = false


require("cronus_cvar")
require("pall")


// ConVars
CreateClientConVar( "aim_removeaa", 1, true, false )
CreateClientConVar( "aim_aimspot","Eye",true,false )
CreateClientConVar( "aim_friendly", 1, true, false )
CreateClientConVar( "aim_steam", 1, true, false )
CreateClientConVar( "aim_removerecoil", 1, true, false )
CreateClientConVar( "aim_silent", 0, true, false )
CreateClientConVar( "aim_removespread", 1, true, false )
CreateClientConVar( "misc_crosshair", 1, true, false )
CreateClientConVar( "misc_removelaser", 0, true, false )
CreateClientConVar( "misc_removesky", 0, true, false )
CreateClientConVar( "esp_info", 1, true, false )
CreateClientConVar( "esp_chams", 1, true, false )
CreateClientConVar( "esp_box", 1, true, false )

Cronus.EyeAngles = Angle(0,0,0)
Cronus.StoredAngle = Angle(0,0,0)
Cronus.AngleRestored = 0
Cronus.Ang = Angle(0,0,0)



chat.AddText(
    Color(255,0,255,255), "[Cronus] ",
    Color(0,255,0,255), "Project ",
    Color(0,255,0,255), "Cronus ",
	Color(0,255,0,255), "Version " .. Version .. " Loaded" )

	

// Aimbot

hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "aim_removerecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end )

concommand.Add("+Cronus_Aim",function()
Aimon = 1
end)

concommand.Add("-Cronus_Aim",function()
Aimon = 0
end)


function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end

local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
	   
function DoCronusNospread( ucmd, angle )
if GetConVarNumber("aim_removespread") >= 1 then
        local ply = LocalPlayer()
		
        cmd2, seed = abc_ucmd_getperdicston( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )
                       
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                       
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                               
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
  end
end


local function AimSpot(targ)
	if GetConVarString("aim_aimspot") == "Eye" then 
	local eye = targ:LookupAttachment("eyes")
		if eye then
		local pos = targ:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("aim_aimspot") == "Bone" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("aim_aimspot") == "Center" then
	local center = targ:OBBCenter()
		if center then
		local pos = targ:LocalToWorld(center)
			if pos then return pos end
		end
	end
	
return targ:LocalToWorld(targ:OBBCenter())

end

local function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end
	if GetConVarNumber("aim_friendly") == 0 && ent:Team() == LocalPlayer():Team() then return false end
	if GetConVarNumber("aim_steam") == 1 && ent:GetFriendStatus() == "friend" then return false end
return true
 end

local function Visible(ply)
local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = AimSpot(ply) - Vector(0,0,ClOf:GetInt())
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
Trace = util.TraceLine(tracedata)
if Trace.Hit then return false else return true end
end

local function CronusAimbot(ucmd)
	if Aimon == 1 then
	local targets = { nil, 0 } 
		for k, v in ipairs( player.GetAll() ) do
			if Exception( v ) && Visible( v ) then

			local crosshair = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
			crosshair = crosshair - LocalPlayer():GetAimVector()
			crosshair = crosshair:Length()
			crosshair = math.abs( crosshair )
				if ( crosshair < targets[2] ) or ( targets[1] == nil ) then
				targets = { v, crosshair }
				
				end
			end
		end
		Backup = targets[1]
	if targets[1] != nil then
		
	local Aimspot = AimSpot(targets[1]) - Vector(0,0,ClOf:GetInt())
	Aimspot = Aimspot + targets[1]:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
	Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
	Angel.p = math.NormalizeAngle( Angel.p )
	Angel.y = math.NormalizeAngle( Angel.y )

		if GetConVarNumber("aim_removespread") == 1 then
		ArchAngel = DoCronusNospread( ucmd, Angle( Angel.p, Angel.y, 0 ) )
		else
		ArchAngel = Angle( Angel.p, Angel.y, 0 )
		end

SetViewAngles(ucmd, ArchAngel)

		end
	end
end

// Anti Aim
hook.Add("CreateMove",1, function(cmd, u)
local C = LocalPlayer()
local v = cmd:GetViewAngles()
if GetConVarNumber( "aim_removeaa" ) >= 1 then return end;
cmd:SetViewAngles(Angle(181, v.y, -181))
end)

// No spread... Yeah let's call it that.   
-- Too bad it's only Visual clientside.
local function NoSpread()					
        if GetConVarNumber("aim_removespread") == 1 and LocalPlayer().GetActiveWeapon != nil then
                local wep = LocalPlayer():GetActiveWeapon()
                        if ValidEntity(wep) then
                                if wep.data then
                                        wep.data.Recoil = 0
                                        wep.data.Cone = 0
                                        wep.data.Spread = 0
                                end
                                if wep.Primary then
                                        wep.Primary.Recoil = 0
                                        wep.Primary.Cone = 0
                                        wep.Primary.Spread = 0
                                end
                        end
        end
end

hook.Add("Tick", "IwishthisworkedITWORKED", NoSpread)


// Speedhack
local factor = 3.5
concommand.Add( "+Cronus_Speed", function( p, c, a )
	cvar2.SetValue( "sv_cheats", "1" )
	cvar2.SetValue( "host_timescale", factor )
end )

concommand.Add( "-Cronus_Speed", function( p, c, a )
	cvar2.SetValue( "host_timescale", "1.0" )
end )

// Bhop
function Cronus:Bhop( u )
	if( u:KeyDown( IN_JUMP ) && Cronus["Copy"]["LocalPlayer"]():IsOnGround() == false && Cronus["Copy"]["LocalPlayer"]():GetMoveType() != MOVETYPE_OBSERVER && Cronus["Copy"]["LocalPlayer"]():Team() != TEAM_SPECTATOR ) then
		u:SetButtons( u:GetButtons() - IN_JUMP );
	end
end

// Crosshair
function Crosshair()
if GetConVarNumber( "misc_crosshair" ) >= 1 then
surface.SetDrawColor( 0, 255, 0, 200 )
surface.DrawLine( x - length, y, x - gap, y )
surface.DrawLine( x + length, y, x + gap, y )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )
surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2, ScrW() / 2 + 5 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 , ScrH() / 2 + 5, ScrW() / 2 , ScrH() / 2 - 5)



        end
end
hook.Add("HUDPaint","CustomCross",Crosshair)

// ESP
local function ESP()
if( GetConVarNumber( 'esp_info' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( v:Name(), 'TabLarge', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "HP: " .. v:Health(), 'TabLarge', Pos.x, Pos.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
end
end
end
end
hook.Add( 'HUDPaint', 'NIGGERSHITPENIS', ESP );

local function CronusMakeMat() 	
	local Texture = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	} 
   local material = CreateMaterial( "Cronus_Solid", "VertexLitGeneric", Texture )
   return material
end

function CronusChams() --Yes, Stolen from Cronus because I like Cronus's Chams, And I needed more ESP Shit.
local Div = (1 / 255)
local m = CronusMakeMat()
	if GetConVarNumber( "esp_chams" ) >= 1 then 
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
			cam.Start3D(EyePos(),EyeAngles())
			local TCol = team.GetColor(v:Team())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * Div ), ( TCol.g * Div ), ( TCol.b * Div ) )
			SetMaterialOverride( m )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			SetMaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end
hook.Add( 'HUDPaint', 'Chams', CronusChams );

function BoundingBox()
	if GetConVarNumber( "esp_box" ) >= 1 then
		for k, v in pairs ( player.GetAll() ) do
			if v ~= LocalPlayer() then
			if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
				local PlayerBoxPos = v:EyePos():ToScreen()
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 3, PlayerBoxPos.y - 40 / 2, 30, 60 )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "CronusBoundingBox", BoundingBox )

// Remove Skybox
function RemoveSky()
	if GetConVarNumber("misc_removesky") >= 1 then
	cvar2.SetValue( "gl_clear", "1")
	cvar2.SetValue( "r_drawskybox", "0")
	cvar2.SetValue( "r_3dsky", "0")
	else
	cvar2.SetValue( "gl_clear", "0")
	cvar2.SetValue( "r_drawskybox", "1")
	cvar2.SetValue( "r_3dsky", "1")
	end
end	
hook.Add( 'HUDPaint', 'Ilikemyskyblack', RemoveSky );


// Radar
function DoChecksRadar( e )

	local ply, val = LocalPlayer(), 0
	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
	
	return true
	
end

	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 300, 300 )
	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2
	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
	Radar:SetTitle("Cronus Radar")
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 40 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, rW, rH )
		
		local ply = LocalPlayer()
		
		local radar = {}
		radar.h		= 300
		radar.w		= 300
		radar.org	= 5000
		
		local x, y = ScrW() / 2, ScrH() / 2
		
		local half = rH / 2
		local xm = half
		local ym = half
		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )
		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then
				
				local s = 6
				local col = {}
				local color = Color( 255,255,255,200 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
				
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				
				
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )
				
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )
				
				local text = e:GetClass()
				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				end
				
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
				
					draw.RoundedBox( s, posX, posY, s, s, color )

				end
			end
		end
	end
	
	Radar:SetVisible( true )
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )
	concommand.Add( "+mouseenable", function() Radar:SetMouseInputEnabled( true ) end )
	concommand.Add( "-mouseenable", function() Radar:SetMouseInputEnabled( false ) end )
	
	RRadar = Radar
	
// Fake View // --Ignore the messy shit here, I was rushing. Also, I only added this so I could make a spinbot.
concommand.Add("FixView", function()
	Cronus.FixView = 1
	Cronus.Spin = 1
	if GetConVarNumber("aim_silent") == 1 then 
	Cronus.StoredAngle = LocalPlayer():EyeAngles()	
	end
	Cronus.Ang = LocalPlayer():EyeAngles()	
	Cronus.AngleRestored = 0
end)


function Cronus.FovCheck( ent, fov )
	if fov == 0 or fov == 180 then return true end	
	if ValidEntity( ent ) then
		if GetConVarNumber("aim_silent") == 0 then	
			LAng = LocalPlayer():EyeAngles()	
		else		
			LAng = Cronus.StoredAngle		
		end		
		if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) > fov then return false end	
		if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) < -fov then return false end
		if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) < -fov then return false end
		if math.NormalizeAngle( ( Cronus.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) > fov then return false end
				
	end
	return true
end

function Cronus.FakeView(cmd)
	if GetConVarNumber("aim_silent") == 1 then
		Cronus.StoredAngle.p = math.Clamp(Cronus.StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89)	
		Cronus.StoredAngle.y = math.NormalizeAngle(Cronus.StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
		Cronus.StoredAngle.r = 0
	end	
end
hook.Add("CreateMove", "FakeView2", Cronus.FakeView)

local SetViewAngles = _R.CUserCmd.SetViewAngles

function AimHook( cmd )
if GetConVarNumber("aim_silent") == 1 then		
		local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - Cronus.StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())	
		cmd:SetForwardMove(Forward.x)		
		cmd:SetSideMove(Forward.y)		
	end
end
hook.Add("CreateMove","SILENTSHITPENIS",AimHook)

function Cronus.CalcView(ply, pos, angles, fov)
    local view = {}	
    view.origin = pos
	if Cronus.FixView == 1 and GetViewEntity() == LocalPlayer() and GetConVarNumber("aim_silent") == 1 then	
		view.angles = Cronus.StoredAngle	
	end	
    view.fov = fov 
    return view	
end
hook.Add("CalcView", "FAKEVIEWPENIS", Cronus.CalcView)

// Spinbot // -- I made this super long and useless because I was too lazy to spend time on it.
concommand.Add("+Spinbot",function()
timer.Simple(0.1,function()
LocalPlayer():ConCommand("Cronus_Spin_2")
end)
timer.Simple(0.2,function()
LocalPlayer():ConCommand("Cronus_Spin_2")
end)
timer.Simple(0.3,function()
LocalPlayer():ConCommand("Cronus_Spin_2")
end)
timer.Simple(0.4,function()
LocalPlayer():ConCommand("Cronus_Spin_2")
end)
timer.Simple(0.5,function()
LocalPlayer():ConCommand("Cronus_Spin_2")
end)
end)
concommand.Add("Cronus_Spin_2",function()
timer.Simple(0.1,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.2,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.3,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.4,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.5,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.6,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.7,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.8,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.9,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.10,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.11,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.12,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.13,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.14,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.15,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.16,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.17,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.18,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.19,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
timer.Simple(0.20,function()
LocalPlayer():ConCommand("Cronus_Spin")
end)
end)
concommand.Add("Cronus_Spin",function()
timer.Simple(.01,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.02,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.03,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0)) 
end)
timer.Simple(.04,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.05,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.06,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.07,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.08,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.09,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.10,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.11,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.12,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.13,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.14,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.15,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.16,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.17,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.19,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,10,0))
end)
timer.Simple(.25,function()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() - Angle(0,180,0))
end)
end)

// Laser Sight // --Oh you say this is useless and dumb? Well, Yeah it is. fuck you
function Cronus.Barrel( )
if GetConVarNumber( "misc_removelaser" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
//if( !table.HasValue( LaserSightAllowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial( Material( 'sprites/bluelaser1' ) )
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, team.GetColor( LocalPlayer():Team() ) )
cam.End3D()
end
hook.Add( 'RenderScreenspaceEffects', '\2\3', Cronus.Barrel )


// Derma // --Fuck you it's only for idiots who can't use commands
local Menu
function Menu()

	local x, y = ScrW() / 2, ScrH() / 2
	
	local Panel = vgui.Create( "DPropertySheet" )
		Panel:SetParent( menu )
		Panel:SetPos( x - 500 / 2, y - 300 / 2)
		Panel:SetSize( 500, 300 )
		Panel:MakePopup()
		Menu = Panel
	
	local Aimpanel = vgui.Create( "DPanelList", Panel )
	local Esppanel = vgui.Create( "DPanelList", Panel )
	local Miscpanel = vgui.Create( "DPanelList", Panel )
	local InfoPage = vgui.Create( "DPanelList", Panel )
	
	---- Aimbot
	
	local Text = vgui.Create("DLabel")
		Text:SetText( "Aimbot Settings: " )
		Text:SetParent( Aimpanel )
		Text:SetWide( 200 )
		Text:SetPos( 10, 0 )
		Text:SetTextColor( Color( 0, 255, 0, 255 ) )
		
	-- Aimbot			
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Friendly Fire" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 20 )
		Checkbox:SetConVar( "aim_friendly" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Autoshoot" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 40 )
		Checkbox:SetConVar( "aim_auto" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Remove Recoil" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 60 )
		Checkbox:SetConVar( "aim_removerecoil" )
		Checkbox:SizeToContents()

	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Remove Spread" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 80 )
		Checkbox:SetConVar( "aim_removespread" )
		Checkbox:SizeToContents()
			
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Remove Anti-Aim" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 100 )
		Checkbox:SetConVar( "aim_removeaa" )
		Checkbox:SizeToContents()
	
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Silent Aim" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 120 )
		Checkbox:SetConVar( "aim_silent" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Ignore Admins" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 140 )
		Checkbox:SetConVar( "aim_admins" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Ignore Steam Friends" )
		Checkbox:SetParent( Aimpanel )
		Checkbox:SetPos( 10, 160 )
		Checkbox:SetConVar( "aim_steam" )
		Checkbox:SizeToContents()	
		
	local List = vgui.Create( "DMultiChoice" )
		List:SetPos( 260, 20 )
		List:SetParent( Aimpanel )
		List:SetSize( 220, 20 )
		List:AddChoice( "Head" )
		List:AddChoice( "Forward" )
		List:AddChoice( "Eyes" )
		List:SetConVar( "aim_offset" )
		
			local Text = vgui.Create("DLabel")
				Text:SetText( "Aimspot" )
				Text:SetParent( Aimpanel )
				Text:SetWide( 200 )
				Text:SetPos( 260, 0 )
				Text:SetTextColor( Color( 0, 255, 0, 255 ) )
		
/*		
	local List = vgui.Create( "DMultiChoice" )
		List:SetPos( 260, 70 )
		List:SetParent( Aimpanel )
		List:SetSize( 220, 20 )
		List:AddChoice( "Players & NPC's" )
		List:AddChoice( "Players" )
		List:AddChoice( "NPC's" )
		List:SetConVar( "pb_aim_mode" )
		
			local Text = vgui.Create("DLabel")
				Text:SetText( "" )
				Text:SetParent( Aimpanel )
				Text:SetWide( 200 )
				Text:SetPos( 260, 50 )
				Text:SetTextColor( Color( 0, 255, 0, 255 ) )
*/
				
	local NumberSlider = vgui.Create( "DNumSlider" )
		NumberSlider:SetPos( 260, 220 )
		NumberSlider:SetParent( Aimpanel )
		NumberSlider:SetWide( 220 )
		NumberSlider:SetText( "Aim Prediction" )
		NumberSlider:SetMin( 0 )
		NumberSlider:SetMax( 3 )
		NumberSlider:SetDecimals( 0 )
		NumberSlider:SetConVar( "aim_prediction" )
		
	local FixView = vgui.Create("DButton")
		FixView:SetPos( 150, 20 )
		FixView:SetParent( Aimpanel )
		FixView:SetSize( 95, 25 )
		FixView:SetText( "Reset Aim Position" )
		FixView.DoClick = function()
		RunConsoleCommand( "FixView" )
		end
		
		
		
	---- ESP
	local Text = vgui.Create("DLabel")
		Text:SetText( "ESP And WallHack: " )
		Text:SetParent( Esppanel )
		Text:SetWide( 200 )
		Text:SetPos( 10, 0 )
		Text:SetTextColor( Color( 0, 255, 0, 255 ) )
/*		
	local Text = vgui.Create("DLabel")
		Text:SetText( "Entity Information " )
		Text:SetParent( Esppanel )
		Text:SetWide( 200 )
		Text:SetPos( 10, 80 )
		Text:SetTextColor( Color( 255, 0, 0, 255 ) )
		
	local Text = vgui.Create("DLabel")
		Text:SetText( "Extra Settings: " )
		Text:SetParent( Esppanel )
		Text:SetWide( 200 )
		Text:SetPos( 10, 140 )
		Text:SetTextColor( Color( 255, 0, 0, 255 ) )
*/	
	-- Players
	
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Name And Health" )
		Checkbox:SetParent( Esppanel )
		Checkbox:SetPos( 10, 20 )
		Checkbox:SetConVar( "esp_info" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Chams" )
		Checkbox:SetParent( Esppanel )
		Checkbox:SetPos( 10, 40 )
		Checkbox:SetConVar( "esp_chams" )
		Checkbox:SizeToContents()
/*		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )  -- Adding something here soon, Just don't know what yet.
		Checkbox:SetText( "" )
		Checkbox:SetParent( Esppanel )
		Checkbox:SetPos( 10, 60 )
		Checkbox:SetConVar( "" )
		Checkbox:SizeToContents()
*/		

	
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Bounding Box" )
		Checkbox:SetParent( Esppanel )
		Checkbox:SetPos( 10, 80 )
		Checkbox:SetConVar( "esp_box" )
		Checkbox:SizeToContents()
		
		
	---- Info Page / ChangeLog
	local CronusInfoPage
	http.Get( "http://dl.dropbox.com/u/28497094/Project%20Cronus/Cronus/CronusInfoPage.txt", "", function( data )
	CronusInfoPage = vgui.Create("DLabel")
	CronusInfoPage:SetPos( 10, 5 )
	CronusInfoPage:SetParent( InfoPage )
	CronusInfoPage:SetText( data )
	CronusInfoPage:SizeToContents()
	CronusInfoPage:SetTextColor( Color( 255, 255, 255, 255 ) )
	end )

		---- Miscellaneous
		
	local Text = vgui.Create("DLabel")
		Text:SetText( "Miscellaneous: " )
		Text:SetParent( Miscpanel )
		Text:SetWide( 200 )
		Text:SetPos( 10, 0 )
		Text:SetTextColor( Color( 0, 255, 0, 255 ) )
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Remove Skybox" )
		Checkbox:SetParent( Miscpanel )
		Checkbox:SetPos( 10, 20 )
		Checkbox:SetConVar( "misc_removesky" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Remove Laser Sight" )
		Checkbox:SetParent( Miscpanel )
		Checkbox:SetPos( 10, 40 )
		Checkbox:SetConVar( "misc_removelaser" )
		Checkbox:SizeToContents()
		
	local Checkbox = vgui.Create( "DCheckBoxLabel" )
		Checkbox:SetText( "Crosshair" )
		Checkbox:SetParent( Miscpanel )
		Checkbox:SetPos( 10, 60 )
		Checkbox:SetConVar( "misc_crosshair" )
		Checkbox:SizeToContents()

	Panel:AddSheet( "Aimbot", Aimpanel, "gui/silkicons/wrench", false, false, "Aimbot Settings" )
	Panel:AddSheet( "ESP", Esppanel, "gui/silkicons/group", false, false, "ESP/Wallhack" )
	Panel:AddSheet( "Miscellaneous", Miscpanel, "gui/silkicons/plugin", false, false, "Miscellaneous" )
	Panel:AddSheet( "Info/Changelog", InfoPage, "gui/silkicons/star", false, false, "Changelogs and Information" )
		
end

concommand.Add( "+Cronus_Menu", Menu )
concommand.Add( "-Cronus_Menu", function() 
	Menu:SetVisible( false )
end )
-- Thanks for the menu PrecisionBot v2! Credits to you fr1kin. (I'm too lazy to make a menu so fuck you all.)