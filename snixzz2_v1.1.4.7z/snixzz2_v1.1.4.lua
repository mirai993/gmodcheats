/*
	
	snixzz 2.0
	
	A cheat made for ONLY hvh
	Author: Tyler
	
	Thanks to:
	Styler for Silent aim method
	Function for helping test shit, small fixes, & being bae.

	
*/

if _G["snixzz"] then
	_G["snixzz"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz2] Detected an anti-cheat, or snixzz2 was reloaded.\n" )
end

local snixzz = {}
snixzz.DataFolder = "snixzz2"
snixzz.Info = {
	["Version"] = "build 1.1.4",
	["Updated"] = "8/21/15",
}

local _R = debug["getregistry"]()

snixzz["Copy"] = {
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["render"] = render,
	["draw"] = draw,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["timer"] = timer,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["file"] = file,
	["chat"] = chat,
	["CurTime"] = CurTime,
	["RealTime"] = RealTime,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["IsValid"] = IsValid,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["Color"] = Color,
	["RealFrameTime"] = RealFrameTime,
	["RunConsoleCommand"] = RunConsoleCommand,
	["require"] = require,
	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["Angle"] = Angle,
	["next"] = next,
	["include"] = include,
	["IsFirstTimePredicted"] = IsFirstTimePredicted,
	["istable"] = istable,
	["engine"] = engine,
	["bit"] = bit,
	["bor"] = bor,
}

snixzz["Detours"] = {
}
snixzz["Spoof"] = {
	["sv_allowcslua"] = snixzz["Copy"]["GetConVarNumber"]( "sv_allowcslua" ), // some anti-cheats man..
	["sv_cheats"] = 0,
	["host_timescale"] = 1,
	["host_framerate"] = 0,
}	

// Aimbot vars nd shit
snixzz["Target"] = nil
snixzz["Typing"] = false
snixzz["Locked"] = false
snixzz["Whitelist"] = {
}

snixzz.Bools = {
	
	-- Aimbot & view settings
	["aim_toggle"] = false,
	["aim_autoshoot"] = true,
	["aim_antiaim"] = true,
	["aim_silent"] = true,
	["aim_anti"] = false,
	["aim_nospread"] = true,
	["aim_norecoil"] = true,
	["aim_prediction"] = true,	
	["aim_antiantiaim"] = true,
	["aim_checkfov"] = false,
	["aim_ignorelos"] = false,
	["aim_ignoresteam"] = true,
	["aim_ignoreadmins"] = false,
	["aim_ignorebots"] = false,
	["aim_ignoreteam"] = false,
	
	-- ESP settings
	["esp_enabled"] = true,
	["esp_name"] = true,
	["esp_chams"] = true,
	["esp_chams_weapon"] = true,
	["esp_weapon"] = true,
	["esp_box"] = true,
	["esp_crosshair"] = true,
	["esp_crosshair_box"] = true,
	["esp_tracer"] = false,
	["esp_nohands"] = true,
	["esp_status"] = true,
	["esp_list"] = true,
	["esp_asus"] = false,
	
	["misc_bhop"] = true,
	["misc_autostrafe"] = true,
	["misc_namechanger"] = false,
	
}

snixzz.Vars = {
	
	-- Aimbot Vars
	["aim_distance"] = 2147483647,
	["aim_fov"] = 180,
	["aim_offset"] = 0,
	["aim_method"] = "Bone",
	["aim_anti_method"] = "Classic",
	["aim_hitbox"] = "Head",
	["aim_bone"] = "Head",
	["aim_target_method"] = "Distance",
	["aim_prediction_method"] = "Velocity 0.013",
	
	-- ESP Vars
	["esp_distance"] = 3000,
	["esp_chams_material"] = "Solid",
	["esp_asus_alpha"] = 0.95,
	
	-- Misc Vars
	["speedhack_speed"] = 3.5,
	["speedhack_type"] = "pSpeed",
	
	["misc_menucolor"] = Color( 0, 188, 255, 75 ),
	
}

snixzz.Binds = {
	["+aimbot"] = KEY_F,
	["+menu"] = KEY_INSERT,
	["+speedhack"] = KEY_B,
	["+misc_list"] = KEY_T,
}

snixzz.Keys = {
	[1] = { Name = "A", Key = KEY_A },
	[2] = { Name = "B", Key = KEY_B },
	[3] = { Name = "C", Key = KEY_C },
	[4] = { Name = "D", Key = KEY_D },
	[5] = { Name = "E", Key = KEY_E },
	[6] = { Name = "F", Key = KEY_F },
	[7] = { Name = "G", Key = KEY_G },		
	[8] = { Name = "H", Key = KEY_H },
	[9] = { Name = "I", Key = KEY_I },
	[10] = { Name = "J", Key = KEY_J },
	[11] = { Name = "K", Key = KEY_K },
	[12] = { Name = "L", Key = KEY_L },
	[13] = { Name = "M", Key = KEY_M },
	[14] = { Name = "N", Key = KEY_N },
	[15] = { Name = "O", Key = KEY_O },
	[16] = { Name = "P", Key = KEY_P },
	[17] = { Name = "Q", Key = KEY_Q },
	[18] = { Name = "R", Key = KEY_R },
	[19] = { Name = "S", Key = KEY_S },
	[20] = { Name = "T", Key = KEY_T },
	[21] = { Name = "U", Key = KEY_U },
	[22] = { Name = "V", Key = KEY_V },
	[23] = { Name = "W", Key = KEY_W },
	[24] = { Name = "X", Key = KEY_X },
	[25] = { Name = "Y", Key = KEY_Y },
	[26] = { Name = "Z", Key = KEY_Z },
	[27] = { Name = "SPACE", Key = KEY_SPACE },
	[28] = { Name = "TAB", Key = KEY_TAB },
	[29] = { Name = "Left Shift", Key = KEY_LSHIFT },
	[30] = { Name = "Right Shift", Key = KEY_RSHIFT },
	[31] = { Name = "Left Alt", Key = KEY_LALT },
	[32] = { Name = "Right Alt", Key = KEY_RALT },
	[33] = { Name = "Delete", Key = KEY_DELETE },
	[34] = { Name = ".", Key = KEY_PERIOD },
	[35] = { Name = "/", Key = KEY_SLASH },
	[36] = { Name = "[", Key = KEY_LBRACKET },
	[37] = { Name = ";", Key = KEY_SEMICOLON },
	[38] = { Name = "'", Key = KEY_APOSTROPHE },
	[39] = { Name = ",", Key = KEY_COMMA },	
	[40] = { Name = "Insert", Key = KEY_INSERT },
}

snixzz.DefaultConfig = snixzz.Copy.file.Read( snixzz.DataFolder .. "/defaultconfig.txt", "DATA" ) or "default"

// nospread shit
snixzz.RecoilBackup = {}
snixzz["Cones"] = {
	["HL2"] = {	
		["weapon_pistol"] = snixzz["Copy"]["Vector"]( 0.0100, 0.0100, 0.0100 ),
		["weapon_smg1"] = snixzz["Copy"]["Vector"]( 0.04362, 0.04362, 0.04362 ),
		["weapon_ar2"] = snixzz["Copy"]["Vector"]( 0.02618, 0.02618, 0.02618 ),
		["weapon_shotgun"] = snixzz["Copy"]["Vector"]( 0.08716, 0.08716, 0.08716 ),
	},
}
snixzz["ConeBase"] = {
	["weapon_cs_base"] = true,
	["weapon_zs_base"] = true,
}

snixzz.BadWeapons = {
	["gmod_tool"] = true,
	["gmod_camera"] = true,
	["weapon_physgun"] = true,
	["weapon_crowbar"] = true,
	["keys"] = true,
	["pocket"] = true,
}

snixzz["Colors"] = {
	["White"] = Color( 255, 255, 255, 255 ),
	["Black"] = Color( 0, 0, 0, 255 ),
	["Green"] = Color( 0, 255, 0, 255 ),
	["Red"] = Color( 255, 0, 0, 255 ),
	["DarkRed"] = Color( 200, 50, 50, 255 ),
	["Cyan"] = Color( 0, 255, 255, 255 ),
}

snixzz.AdminGroups = {
	["trialmod"] = true,
	["tmod"] = true,
	["trial-mod"] = true,
	["trialmoderator"] = true,
	["t-mod"] = true,
	["mod"] = true,
	["moderator"] = true,
	["operator"] = true,
	["vipmod"] = true,
	["vipmoderator"] = true,
	["admin"] = true,
	["vipadmin"] = true,
	["head-admin"] = true,
	["headadmin"] = true,
	["manager"] = true,
	["developer"] = true,
	["dev"] = true,
	["superadmin"] = true,
	["sadmin"] = true,
	["super"] = true,
	["vipsuperadmin"] = true, -- i cry
	["owner"] = true,
	["root_user"] = true,
	["vipowner"] = true, -- wouldn't be surprised it
}
snixzz["Copy"]["surface"]["CreateFont"]( "snixzz", { font = "Trebuchet18", size = 12, antialias = false } )
snixzz["Copy"]["surface"]["CreateFont"]( "snixzz_status", { font = "coolvetica", size = 20, antialias = true } ) -- HudHintTextLarge
snixzz["Copy"]["surface"]["CreateFont"]( "snixzz_list", { font = "coolvetica", size = 12, antialias = true } )

/* General notification/display functions */
function snixzz.Message( col, txt )
	MsgC( snixzz["Colors"]["Cyan"], "[snixzz2]: " )
	MsgC( col, txt .. "\n" )
end

/* Detour function */
function snixzz.Detour( Old, New )
	snixzz["Detours"][New] = Old
	snixzz["Message"]( Color( 200, 150, 255 ), "Detouring function " .. snixzz["Copy"]["tostring"]( Old ) .. "." )
	return New
end

-- Load the modules
snixzz.Copy.require( "snixzz2" )
snixzz.Copy.require( "pspeed" )
snixzz.Copy.require( "name_enabler" )

-- gmcl_snixzz2_win32.dll
local _snixzz = _G["NHTable"]

-- C++ Module functions
snixzz.Functions = {
	-- gmcl_frozen
	["PredictSpread"] = _G.NHTable.ZeroSpread,
	["SetMuted"] = _G.NHTable.SetMuted,
	["LocalPlayer"] = _G.NHTable.SetLPIndex,
	["SetCvarName"] = _G.NHTable.SetCvarName,
	["ClientCMD"] = _G.NHTable.ClientCMD,
	["IsMuted"] = _G.NHTable.IsMuted,
	["NoDraw"] = _G.NHTable.NoDraw,
	["RawGet"] = _G.NHTable.RawGet,
	["SetViewAngles"] = _G.NHTable.SetViewAngles,
	["AsusWalls"] = _G.NHTable.AsusWalls,
	["GetCvar"] = _G.NHTable.GetCvar,
	["IsDormant"] = _G.NHTable.IsDormant,
	["GetServerIP"] = _G.NHTable.GetServerIP,
	["Changename"] = _G.NHTable.Changename,
	["IsVisible"] = _G.NHTable.IsVisible,
	["SetCvarValue"] = _G.NHTable.SetCvarValue,
	
	-- gmcl_pspeed
 	["pSpeed"] = _G.SetSpeed,
	
}

/* Anti-Cheat bypass functions */
-- This is all really outdated. TODO: Update thhis
function snixzz.AntiCheats()
	
	for k, v in snixzz.Copy.pairs( snixzz.Functions ) do
		snixzz.Message( Color( 200, 255, 0 ), "Copied function " .. snixzz.Copy.tostring( v ) .. " '" .. k .. "'" )
		v = nil
	end
	
	if _G["CheckVars"] then
		snixzz["Message"]( Color( 50, 255, 50 ), "function CheckVars exists, detouring the scan." )
		_G["CheckVars"] = snixzz["Detour"]( _G["CheckVars"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
		end )
	end
	
	if _G["RunCheck"] then
		snixzz["Message"]( Color( 0, 255, 50 ), "function RunCheck exists, detouring." )
		_G["RunCheck"] = snixzz["Detour"]( _G["RunCheck"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "TAC attempted to run a check, returning no information." )
		end )
 	end
	
	if _G["CAC"] then -- lol old as fuck but still works for cracked i believe
		snixzz["Message"]( Color( 0, 255, 50 ), "table CAC exists, bypassing anti-cheat." )
		snixzz["Copy"]["timer"]["Destroy"]( "CAC" )
	end
		
	
	snixzz["Copy"]["concommand"]["Remove"]( "0_u_found" )
	snixzz["Copy"]["concommand"]["Add"]( "0_u_found", function()
		snixzz["Message"]( Color( 50, 255, 50 ), "anti-cheat concommand 0_u_found blocked" )
	end )
	snixzz["Copy"]["hook"]["Remove"]( "InitPostEntity", "detrp" )
	
end
snixzz["AntiCheats"]()

/* Hooking functions */
snixzz.HookCache = {} -- Used to store hooked functions & names to remove them later on.
function snixzz.RegisterHook( Type, Function )
	local Name = snixzz.Copy.string.Replace( snixzz["Copy"]["tostring"]( Function ), "function: ", "" )
	snixzz["Message"]( Color( 0, 185, 255 ), "Hooking function " .. Name .." into " .. Type )
	snixzz.HookCache[Type] = Name
	return snixzz["Copy"]["hook"]["Add"]( Type, Name, Function )
end

function snixzz.ReloadHooks()
	snixzz.Frame:SetVisible( false )
	snixzz.MenuOpen = false2
	for k, v in snixzz.Copy.pairs( snixzz.HookCache ) do
		snixzz.Message( Color( 255, 255, 0 ), "Removing hook " .. v .. " '" .. k )
		snixzz.Copy.hook.Remove( k, v )
		snixzz.HookCache = {}
	end
	snixzz.Copy.timer.Simple( 1, function() 
		for k, v in snixzz.Copy.pairs( snixzz.Hooks ) do
			snixzz.RegisterHook( k, v )
		end
	end )
	snixzz.Copy.timer.Simple( 1.5, function()
		snixzz.Message( Color( 0, 255, 0 ), "Reloaded hooks." )
	end )
end

snixzz.TimerCache = {}
function snixzz.RegisterTimer( delay, rep, func )
	snixzz.Message( Color( 125, 0, 282 ), "Adding timer " .. snixzz.Copy.tostring( func ) .. " with delay '" .. snixzz.Copy.tostring( delay ) .. "'" )
	snixzz.Copy.table.insert( snixzz.TimerCache, snixzz.Copy.tostring( func ) )
	return snixzz.Copy.timer.Create( snixzz.Copy.tostring( func ), delay, rep, func )
end

/*

	Settings & Menu backend.
	Var/Bool system recycled from hake v2
	Re-wrote a bit of it.
	
*/

function snixzz.CreateOption( dtype, parent, oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec )
	local addx, addy = 3, 3.5
	
	if ( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, bool, x, y = oText, oBool, xPos, yPos
		local checkbox = snixzz.Copy.vgui.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetCursor( "crosshair" )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SizeToContents()
		checkbox:SetTextColor( Color( 255, 255, 255 ) )
		checkbox:SetChecked( snixzz.Bools[bool] ) 
		checkbox.OnChange = function( check ) 
			snixzz.Bools[bool] = checkbox:GetChecked() 
		end 	
		
	elseif ( dtype == "Slider" ) then
		dtype = "DNumSlider"
		local text, var, min, max, wide, x, y, Dec = oText, oBool, xPos, yPos, oWide, xPos2, yPos2, oDec
		local slider = vgui.Create( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetCursor( "crosshair" )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( Dec )
		slider:SetValue( snixzz.Vars[var] ) 
		slider.OnValueChanged = function( p, v ) 
			snixzz.Vars[var] = v 
		end
		
	elseif ( dtype == "Label" ) then
		dtype = "DLabel"
		local text, x, y = oText, oBool, xPos
		local label = vgui.Create( dtype, parent )
		label:SetPos( x, y )
		label:SetCursor( "crosshair" )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( color_white )
	end
end

function snixzz.ConfigExists( cfg )
	if snixzz.Copy.file.Exists( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) then
		return true
	else
		return false
	end
end

function snixzz.SaveConfig( cfg )
	local save = {}
	save.Vars = snixzz.Vars
	save.Bools = snixzz.Bools
	save.Binds = snixzz.Binds
	cfg = snixzz.Copy.string.gsub( cfg, " ", "_" )
	if !snixzz.ConfigExists( cfg ) then
		snixzz.Copy.table.insert( snixzz.Configs, cfg )
		snixzz.Copy.file.Write( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", snixzz.Copy.util.TableToJSON( save ) )
		snixzz.Message( snixzz.Colors["Green"], "Created config " .. cfg .. "!" )
	else
		snixzz.Message( snixzz.Colors["Red"], "Config " .. cfg .. " already exists!" )
	end
end

function snixzz.LoadConfig( cfg )
	cfg = snixzz.Copy.string.lower( cfg )
	if snixzz.CurrentConfig != cfg then
		if snixzz.ConfigExists( cfg ) then
			local ToRead = snixzz.Copy.util.JSONToTable( snixzz.Copy.file.Read( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) )
			snixzz.Vars = ToRead.Vars
			snixzz.Bools = ToRead.Bools
			snixzz.Binds = ToRead.Binds
		else
			snixzz.Message( Color( 255, 0, 0 ), "Invalid config file! '" .. cfg .. "'" )
		end
		snixzz.Message( snixzz.Colors["Green"], "Loaded config " .. cfg )
		snixzz.CurrentConfig = cfg
	else
		snixzz.Message( snixzz.Colors["White"], "Config " .. cfg .. " is already loaded!" )
	end
end

function snixzz.DeleteConfig( cfg )
	cfg = snixzz.Copy.string.lower( cfg )
	if cfg != snixzz.DefaultConfig then
		if snixzz.Copy.file.Exists( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt", "DATA" ) then
			snixzz.Copy.file.Delete( snixzz.DataFolder .. "/configs/" .. cfg .. ".txt" )
			snixzz.Message( snixzz.Colors["DarkRed"], "Deleted config " .. cfg )
		else
			snixzz.Message( Color( 255, 0, 0 ), "Unable to find config " .. cfg "!" )
		end
	else
		snixzz.Message( snixzz.Colors["Red"], "You cannot delete the default config!" )
	end
end

function snixzz.RenameConfig( Old, New )
	New = snixzz.Copy.string.gsub( New, " ", "_" )
	if Old != snixzz.DefaultConfig then
		if !snixzz.ConfigExists( New ) then
			local OldConfig = snixzz.Copy.file.Read( snixzz.DataFolder .. "/configs/" .. Old .. ".txt", "DATA" )
			if snixzz.ConfigExists( Old ) then
				snixzz.Copy.file.Delete( snixzz.DataFolder .. "/configs/" .. Old .. ".txt", "DATA" )
			end
			snixzz.Copy.file.Write( snixzz.DataFolder .. "/configs/" .. snixzz.Copy.string.lower( New ) .. ".txt", OldConfig )
			snixzz.Message( snixzz.Colors["DarkRed"], "Renamed " .. Old .. " to " .. snixzz.Copy.string.lower( New ) .. "." )
		else
			snixzz.Message( Color( 255, 0, 0 ), "Config " .. New .. " already exists! Pick a different name." )
		end
	else
		snixzz.Message( snixzz.Colors["Red"], "You cannot rename the default config!" )
	end
end

function snixzz.SetDefaultConfig( cfg )
	if cfg != snixzz.DefaultConfig then
		if snixzz.ConfigExists( cfg ) then
			snixzz.DefaultConfig = cfg 
			snixzz.Copy.file.Write( snixzz.DataFolder .. "/defaultconfig.txt", snixzz.DefaultConfig )
			snixzz.Message( Color( 255, 255, 0 ), "Set '" .. cfg .. "' as the default config." )
		else
			snixzz.Message( Color( 255, 0, 0 ), "'" .. cfg .. "' is not a valid config!" )
		end
	else
		snixzz.Message( Color( 255, 0, 0 ), "'" .. cfg .. "' is already the default config!" )
	end
end

function snixzz.BindKey( Bind, Key ) 
	if snixzz.Binds[Bind] then 
		for _, v in snixzz.Copy.pairs( snixzz.Keys ) do 
			if Key == v.Name then 
				snixzz.Binds[ Bind ] = v.Key 
				snixzz.Message( snixzz.Colors["Green"], "Bound " .. Bind .. " to " .. Key .. "!" )
			end 
		end  
	end 
end

function snixzz.Unbind( Bind )
	if snixzz.Binds[ Bind ] then
		snixzz.Binds[ Bind ] = nil
		snixzz.Message( snixzz.Colors["DarkRed"], "Unbound " .. Bind .. "!" )
	end
end

function snixzz.GetConfigs() 
	local files = snixzz.Copy.file.Find( snixzz.DataFolder .. "/configs/*.txt", "DATA") 
	for k, v in snixzz.Copy.pairs( files ) do 
		files[ k ] = snixzz.Copy.string.Replace( v, ".txt", "" ) 
	end  
	return files 
end 
snixzz.Configs = snixzz.GetConfigs()

function snixzz.FileSystem()
	if !snixzz.Copy.file.IsDir( snixzz.DataFolder, "DATA" ) then
		snixzz.Copy.file.CreateDir( snixzz.DataFolder )
		snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "' data folder." )
	end
	if !snixzz.Copy.file.IsDir( snixzz.DataFolder .. "/configs", "DATA" ) then
		snixzz.Copy.file.CreateDir( snixzz.DataFolder .. "/configs" )
		snixzz.Message( Color( 0, 255, 0 ), "Creating '" .. snixzz.DataFolder .. "/configs' data folder." )
	end
	if !snixzz.ConfigExists( "default" ) then
		snixzz.SaveConfig( "default" )
		snixzz.Message( Color( 0, 255, 0 ), "Creating initial default config" )
	end
	if !snixzz.Copy.file.Exists( snixzz.DataFolder .. "/defaultconfig.txt", "DATA" ) then
		snixzz.Copy.file.Write( snixzz.DataFolder .. "/defaultconfig.txt", snixzz.DefaultConfig )
	end
end
snixzz.Message( Color( 255, 255, 0 ), "Loading filesystem.." )
snixzz.FileSystem()

/*
	ESP functions
*/

function snixzz.GetMaterial()
	local texture = { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 }
	if snixzz.Vars["esp_chams_material"] == "Solid" then
		return snixzz.Copy.CreateMaterial( "VertoxLitGeneric", "VertexLitGeneric", texture )
	elseif snixzz.Vars["esp_chams_material"] == "Wireframe" then
		return snixzz.Copy.CreateMaterial( "Wiireframe", "Wireframe", texture )
	end
end

function snixzz.IsAdmin( v )

	if v:IsAdmin() then
		return true
	end
	
	if v:IsSuperAdmin() then
		return true
	end
	
	if snixzz.AdminGroups[v:GetUserGroup()] then
		return true
	end
	
end

function snixzz.ShouldDraw( v )

	// better fps maybe
	local distance = v:GetPos():Distance( snixzz["Copy"]["LocalPlayer"]():GetPos() )
	if snixzz.Vars["esp_distance"] != 0 && distance >= snixzz.Vars["esp_distance"] then
		return false
	end
	
	if ( !v:IsPlayer() or !v:Alive() or v == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end
	
	if ( v:Team() == TEAM_SPECTATOR or snixzz["Copy"]["string"]["find"]( snixzz["Copy"]["team"]["GetName"]( v:Team() ), "spectator" ) ) then
		return false
	end
	
	if snixzz.Functions.IsDormant( v:EntIndex() ) then
		return false
	end
	
	if !snixzz["OnScreen"]( v ) then
		return false
	end
	
	return true	
end

/********************/
/*					*/
/* Aimbot functions */
/*					*/
/********************/


function snixzz.IsValid( v )

	if ( !snixzz["Copy"]["IsValid"]( v ) || v == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end

	// visible check
	if !snixzz.Bools["aim_ignorelos"] then
		if !snixzz["IsVisible"]( v ) then
			return false
		end
	end
	
	if snixzz.Bools["aim_checkfov"] then
		if !snixzz.InFov( v ) then
			return false
		end
	end
	
	if snixzz.Bools["aim_ignoreadmins"] then
		if snixzz.IsAdmin( v ) then
			return false
		end
	end
	
	if snixzz["IsDormant"]( v:EntIndex() ) then 
		return false
	end
	
	if snixzz.Bools["aim_ignorebots"] && v:IsBot() then
		return false
	end
	
	if snixzz["Copy"]["table"]["HasValue"]( snixzz["Whitelist"], v:SteamID() ) then 
		return false	
	end
	
	if ( !v:Alive() || !v:IsPlayer() || v:InVehicle() ) then 
		return false 
	end
	
	if ( snixzz["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && v:GetMoveType() == MOVETYPE_NOCLIP ) then 
		return false 
	end
	
	-- Ignore Steam friends
	if snixzz.Bools["aim_ignoresteam"] then
		if v:GetFriendStatus() == "friend" then 
			return false 
		end
	end
	
	-- Friendly Fire
	if snixzz.Bools["aim_ignoreteam"] then
		if ( v:Team() == snixzz["Copy"]["LocalPlayer"]():Team() ) then
			return false
		end
	end
			
	if ( v:GetMoveType() == MOVETYPE_OBSERVER || v:Team() == TEAM_SPECTATOR ) then 
		return false 
	end
	
	// ignore T buddies
	if snixzz["Copy"]["string"]["find"]( GAMEMODE["Name"] , "Trouble in Terror" ) then
		if ( snixzz["Copy"]["LocalPlayer"]():IsTraitor() && v:IsTraitor() ) then
			return false
		end
	end
	
	// spawn protection (multiple server detection methods)
	local col = v:GetColor()
	if col["a"] < 255 then
		return false
	end
	if snixzz["Copy"]["LocalPlayer"]():GetColor()["a"] < 255 then
		return false
	end
	
	// gun game server
	if v:GetMaterial() == "models/props_combine/stasisshield_sheet" then
		return false
	end

	return true
end

function snixzz.GetCone( wep )

	if !snixzz["Copy"]["IsValid"]( wep ) then
		return 0 
	end	
	
	if snixzz["Cones"][ wep:GetClass() ] then
		return snixzz["Cones"][ wep:GetClass() ] 
	elseif snixzz["ConeBase"][ wep["Base"] ] then 
		return wep["Cone"] or wep["Primary"]["Cone"] or 0
	elseif snixzz["Cones"]["HL2"][ wep:GetClass() ] then
		return snixzz["Cones"]["HL2"][ wep:GetClass() ]
	else
		local Cone = wep["Cone"]	
		if !Cone then
			Cone = wep["Primary"] && wep["Primary"]["Cone"] or 0
		end	
	end
	return Cone || 0
end

function snixzz.PredictSpread( cmd, ang )
local w = snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()
local vecCone, valCone = snixzz.Copy.Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w["Initialize"] ) == "function" ) ) then
		valCone = snixzz["GetCone"]( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = snixzz["Copy"]["Vector"]( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1
		end
	else
		if ( w:IsValid() && snixzz["Cones"]["HL2"][ w:GetClass() ] ) then
			vecCone = snixzz["Cones"]["HL2"][ w:GetClass() ]
		end
	end
	return snixzz.Functions.PredictSpread( cmd, ang, vecCone )
end

snixzz.Bones = {
	["Head"] = "ValveBiped.Bip01_Head1",
	["Neck"] = "ValveBiped.Bip01_Neck1",
	["Spine"] = "ValveBiped.Bip01_Spine",
	["Spine2"] = "ValveBiped.Bip01_Spine2",
	["Spine4"] =  "ValveBiped.Bip01_Spine4",
	["Pelvis"] = "ValveBiped.Bip01_Pelvis",
	["R Upperarm"] = "ValveBiped.Bip01_R_UpperArm",
	["R Forearm"] = "ValveBiped.Bip01_R_Forearm",
	["R Hand"] = "ValveBiped.Bip01_R_Hand",
	["L Upperarm"] = "ValveBiped.Bip01_L_UpperArm",
	["L Forearm"] = "ValveBiped.Bip01_L_Forearm",
	["L Hand"] = "ValveBiped.Bip01_L_Hand",
	["R Thigh"] = "ValveBiped.Bip01_R_Thigh",
	["R Calf"] = "ValveBiped.Bip01_R_Calf",
	["R Foot"] = "ValveBiped.Bip01_R_Foot",
	["R Toes"] = "ValveBiped.Bip01_R_Toe0",
	["L Thigh"] = "ValveBiped.Bip01_L_Thigh",
	["L Calf"] = "ValveBiped.Bip01_L_Calf",
	["L Foot"] = "ValveBiped.Bip01_L_Foot",
	["L Toes"] = "ValveBiped.Bip01_L_Toe0",
}

snixzz.Hitboxes = {
	["Head"] = 0,	
	["L Upperarm"] = 1,
	["L Forearm"] = 2,
	["L Hand"] = 3,
	["R Upperarm"] = 4,
	["R Forearm"] = 5,
	["R Hand"] = 6,
	["L Thigh"] = 7,
	["L Calf"] = 8,
	["F Foot"] = 9,
	["L Toe"] = 10,
	["R Thigh"] = 11,
	["R Calf"] = 12,
	["R Foot"] = 13,
	["R Toe"] = 14,
	["Pelvis"] = 15,
	["Spine"] = 16,
}

function snixzz.GetPos( v )	
	if snixzz.Vars["aim_method"] == "Hitbox" then
		local Hitbox = v:GetHitBoxBone( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )	
		local HitboxPos = v:GetBonePosition( Hitbox )
	
		local min, max = v:GetHitBoxBounds( snixzz.Hitboxes[snixzz.Vars["aim_hitbox"]], 0 )
		
		return HitboxPos + ( min + max ) / 2
		
	elseif snixzz.Vars["aim_method"] == "Bone" then
		local Bone = snixzz.Bones[snixzz.Vars["aim_bone"]]
		local BonePos = v:LookupBone( Bone )
		if BonePos then
			local pos, ang = v:GetBonePosition( BonePos )
			return pos, ang
		end
	end	
	return v:LocalToWorld( v:OBBCenter() )
end

function snixzz.InFov( v )
	local myang = snixzz.Copy.LocalPlayer():GetAngles()
	if snixzz.Vars["aim_fov"] != 180 && snixzz.Copy.IsValid( v ) && snixzz.Copy.IsValid( myang ) then 
		local myang = snixzz.Copy.LocalPlayer():GetAngles()
		local angle = ( v:GetPos() - snixzz.Copy.LocalPlayer():EyePos() ):Angle()
		local angy = snixzz.Copy.math.abs( snixzz.Copy.math.NormalizeAngle( myang.y - angle.y ) )
		local angp = snixzz.Copy.math.abs( snixzz.Copy.math.NormalizeAngle( myang.p - angle.p ) )
		if snixzz.Copy.IsValid( angy ) && snixzz.Copy.IsValid( angp ) then
			if angy > snixzz.Vars["aim_fov"] or angp > snixzz.Vars["aim_fov"] then return false end
		end
	end
	return true
end

-- thanks asutorea
function snixzz.CanFire()
	local wep = snixzz.Copy.LocalPlayer():GetActiveWeapon()
	if snixzz.properCurTime == nil then return false end
	return snixzz.Copy.IsValid( wep ) && !snixzz.BadWeapons[wep:GetClass()] && wep:GetActivity() != ACT_RELOAD && wep:GetNextPrimaryFire() < snixzz.properCurTime && snixzz.Copy.LocalPlayer():Alive()
end

-- Anti-Anti-Aim ~ Thanks cdriza
function snixzz.FixAngle( v )
	local angPitch = v:EyeAngles().p
	local angYaw = v:EyeAngles().y
	 
	if (angPitch > 89) then
		angPitch = -89
	elseif (angPitch < -89) then
		angPitch = 89
	end
       
	if (angYaw > 180) then
		angYaw = -180
	elseif (angYaw < -180) then
		angYaw = 180
	end

	/*
	angPitch = snixzz.Copy.math.Clamp( angPitch, -89, 89 )
	angPitch = snixzz.Copy.math.NormalizeAngle( angPitch )
	angYaw = snixzz.Copy.math.Clamp( angYaw, -89, 89 )
	angYaw = snixzz.Copy.math.NormalizeAngle(angYaw )
	*/
		   
	v:SetPoseParameter( "aim_pitch", angPitch )
	v:SetPoseParameter( "aim_yaw", angYaw )
end

function snixzz.IsVisible( v )
	if snixzz.Bools["aim_antiantiaim"] then
		snixzz.FixAngle( v )
	end
	return snixzz.Functions.IsVisible( snixzz["Copy"]["LocalPlayer"]():GetShootPos(), snixzz.GetPos( v ), v:EntIndex() )
end

function snixzz.OnScreen( v )
	local a, f = _R["Player"]["GetAimVector"]( snixzz["Copy"]["LocalPlayer"]() ):Angle() - ( v:GetPos() - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):Angle(), _R["Player"]["GetFOV"]( snixzz["Copy"]["LocalPlayer"]() )     
	return ( snixzz["Copy"]["math"]["NormalizeAngle"]( a["y"] ) < f + 2 && snixzz["Copy"]["math"]["NormalizeAngle"]( a["p"] ) < f + 2 )
end

function snixzz.IsDormant( index )
	return snixzz.Functions.IsDormant( index )
end

function snixzz.FixMove( ucmd, aa, spinangle )
	local fixAngle = snixzz.Copy.Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
	fixAngle = (( fixAngle:GetNormal() ):Angle() + ( ucmd:GetViewAngles() - snixzz.Copy.Angle( 0, snixzz.Silent.y, 0 ) ) ):Forward() * fixAngle:Length()
	
	if aa then
		ucmd:SetForwardMove( fixAngle.x )
		ucmd:SetSideMove( fixAngle.y * -1 )
		return
	end
	
	ucmd:SetForwardMove( fixAngle.x )
	ucmd:SetSideMove( fixAngle.y )
end

function snixzz.NormalizeAngles( Angl )
	Angl["p"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["p"] )
	Angl["y"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["y"] )
	Angl["r"] = 0
	return Angl
end

function snixzz.Prediction( Pos, v )
	if ( snixzz["Copy"]["IsValid"]( v ) && type( v:GetVelocity() ) == "Vector" && v["GetPos"] && type( v:GetPos() ) == "Vector" ) then
		if snixzz.Vars["aim_prediction_method"] == "Velocity 0.013" then
			local vSpeed = v:GetVelocity() * 0.013
			local plySpeed = snixzz["Copy"]["LocalPlayer"]():GetVelocity() * 0.013	
			Pos = Pos - plySPeed + vSpeed
		elseif snixzz.Vars["aim_prediction_method"] == "Velocity 0.02" then
			Pos = Pos + v:GetVelocity() * 0.02 + snixzz.Copy.LocalPlayer():GetVelocity() * 0.02
		end
	else
		Pos = Pos
	end
	return Pos
end

function snixzz.GetTarget()
	for k, v in snixzz.Copy.pairs( snixzz.Copy.player.GetAll() ) do
	
		local x, y = snixzz.Copy.ScrW(), snixzz.Copy.ScrH()
		local vPos = v:EyePos():ToScreen()
		local oldPos = snixzz.Copy.LocalPlayer():EyePos():ToScreen()
		local distance = snixzz.Copy.math.huge
		local distance2 = v:GetPos():DistToSqr( snixzz["Copy"]["LocalPlayer"]():GetPos() )
		local AngA = snixzz.Copy.math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
		local AngB = snixzz.Copy.math.Dist( x / 2, y / 2, vPos.x, vPos.y )
		
		if snixzz.IsValid( v ) then
			if snixzz.Vars["aim_target_method"] == "Distance" then
				if distance2 < distance then
					distance = distance2
					snixzz["Target"] = v
				end
			elseif snixzz.Vars["aim_target_method"] == "Crosshair" then
				if AngB <= AngA then
					snixzz.Target = v
				end
			end
		else
			continue;
		end
	end
	return snixzz["Target"]		
end

snixzz.Firing = false
function snixzz.Fire( ucmd )
	if snixzz.Firing then
		ucmd:RemoveKey( IN_ATTACK )
		snixzz.Firing = false
	else
		ucmd:SetButtons( snixzz.Copy.bit.bor( ucmd:GetButtons(), IN_ATTACK ) )
		snixzz.Firing = true
	end
end

snixzz.AntiAimMethods = { "Classic", "Classic Inverted", "Static", "Jitter", "Random Pitch" }
function snixzz.AntiAim( ucmd )
	local pitches = { -181, 541, 262 }
	local yaws = { 262, -262, 181, -181, 541, -541 }

	-- OG anti-aim
	if snixzz.Vars["aim_anti_method"] == "Classic" then
		snixzz.Functions.SetViewAngles( ucmd, snixzz.Copy.Angle( 181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
	-- Looking down instead of up
	elseif snixzz.Vars["aim_anti_method"] == "Classic Inverted" then
		snixzz.Functions.SetViewAngles( ucmd, snixzz.Copy.Angle( -181, ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd )
	-- Static
	elseif snixzz.Vars["aim_anti_method"] == "Static" then
		snixzz.Functions.SetViewAngles( ucmd, snixzz.Copy.Angle( -snixzz.Angles.p + 900, snixzz.Angles.y + 180, 0 ) )
		snixzz.FixMove( ucmd, true )
	-- Jitter - credits to cdriza
	elseif snixzz.Vars["aim_anti_method"] == "Jitter" then
		snixzz.Functions.SetViewAngles( ucmd, snixzz.Copy.Angle( snixzz.Copy.table.Random( pitches ), snixzz.Copy.table.Random( yaws ), 0 ) )
		snixzz.FixMove( ucmd, true )
	-- Randomized pitch
	elseif snixzz.Vars["aim_anti_method"] == "Random Pitch" then
		snixzz.Functions.SetViewAngles( ucmd, snixzz.Copy.Angle( math.random( -89, 89 ), ucmd:GetViewAngles().y, 180 ) )
		snixzz.FixMove( ucmd, true )
	end
	
end


/*=======================


Hooked functions below


=========================*/
snixzz.Status = "Waiting..."
snixzz.StatusColor = Color( 255, 255, 0, 150 )
snixzz.Silent = snixzz.Copy.Angle()
-- To shorten up my aimbot checks a bit.
function snixzz.ShouldAim( ucmd, isToggled )
	if isToggled then
		return snixzz.Target && snixzz.IsValid( snixzz.Target ) && ucmd:CommandNumber() != 0 && snixzz.CanFire()
	else
		return snixzz.Target && snixzz.IsValid( snixzz.Target ) && ucmd:CommandNumber() != 0 -- don't check canfire bc it breaks the aimbot when not toggled
	end
end

function snixzz.CreateMove( ucmd )
	// Aimbot vars
	snixzz["Target"] = snixzz["GetTarget"]()
	snixzz.Offset = snixzz.Copy.Vector( 0, 0, snixzz.Vars["aim_offset"] )
	
	// Silent aim
	if snixzz.Bools["aim_silent"] then
		snixzz.Silent = snixzz.Silent + snixzz.Copy.Angle( ucmd:GetMouseY() * 0.023, -ucmd:GetMouseX() * 0.023, 0 )
		snixzz.Silent.p = snixzz.Copy.math.Clamp( snixzz.Silent.p, -89, 89 )
		if ucmd:CommandNumber() == 0 then
			ucmd:SetViewAngles( snixzz.Silent )
			return
		end		
		snixzz.Angles = snixzz.Silent
	else
		snixzz.Angles = ucmd:GetViewAngles()
	end
	
	// Aimbot core
	if ( snixzz.Copy.input.IsKeyDown( snixzz.Binds["+aimbot"] ) && snixzz.ShouldAim( ucmd, false ) && !snixzz.Typing or snixzz.Bools["aim_toggle"] && snixzz.ShouldAim( ucmd, true ) ) && !snixzz.Typing then
			
		if snixzz.Bools["aim_prediction"] && snixzz.Vars["aim_method"] != "Hitbox" then
			snixzz.Angles = snixzz.Prediction( snixzz.GetPos( snixzz.Target ) - snixzz.Offset )
		else
			snixzz.Angles = snixzz.GetPos( snixzz.Target ) - snixzz.Offset
		end
			
		snixzz.Angles = ( snixzz.Angles - snixzz.Copy.LocalPlayer():GetShootPos() ):GetNormal():Angle()
	
		-- Normalize that shit
		snixzz["NormalizeAngles"]( snixzz["Angles"] )
			
		-- Spread Prediction
		if snixzz.Bools["aim_nospread"] then
			snixzz.SetAngle = snixzz.PredictSpread( ucmd, snixzz.Copy.Angle( snixzz.Angles.p, snixzz.Angles.y, 0 ) )
		else
			snixzz.SetAngle = snixzz.Angles
		end
			
		-- Silent aim
		if snixzz.Bools["aim_silent"] then
			snixzz.Angles.p = snixzz.Angles.p > 180 && snixzz.Angles.p - 360 or snixzz.Angles.p
			snixzz.Angles.r = 0
		end	
			
		-- READY THE CANNON.
		snixzz.Functions.SetViewAngles( ucmd, snixzz["SetAngle"] )

		if snixzz.Bools["aim_autoshoot"] then
			snixzz.Fire( ucmd )
		end
			
		-- Silent aim view correction
		if snixzz.Bools["aim_silent"] then
			snixzz.FixMove( ucmd )
		end
			
		-- status bullshit
		snixzz.Status = "Locked! (" .. snixzz.Target:Nick() .. ")"
		snixzz.StatusColor = Color( 255, 0, 0, 150 )
		snixzz["Locked"] = true
							
		-- Possible bug fix
	elseif snixzz.Target && snixzz.Copy.IsValid( snixzz.Target ) && snixzz.Target != nil && !snixzz.CanFire() && snixzz.Copy.LocalPlayer():Alive() then
		snixzz.Status = "Locked! (" .. snixzz.Target:Nick() .. ")"
		snixzz.StatusColor = Color( 255, 0, 0, 150 )
			
	else
		-- More status bullshit, aimbot not active.
		snixzz.Status = "Searching..."
		snixzz.StatusColor = Color( 0, 255, 0, 150 )
		snixzz.Locked = false		
	end
	
	if snixzz.Bools["aim_anti"] && !snixzz.Locked && !snixzz.Copy.LocalPlayer():KeyDown( IN_ATTACK ) && !snixzz.Copy.input.IsKeyDown( MOUSE_LEFT ) && snixzz.Copy.LocalPlayer():GetMoveType() != MOVETYPE_LADDER then
		snixzz.AntiAim( ucmd )
	end
	
	// Bunnyhop
	if snixzz.Bools["misc_bhop"] then
		if !snixzz.Copy.LocalPlayer():IsOnGround() && !snixzz.Typing then	
			ucmd:SetButtons( bit.band( ucmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		end
	end
	
	-- Recoil Backup
	if snixzz.Bools["aim_norecoil"] then
		if snixzz.Copy.LocalPlayer():GetActiveWeapon()["Primary"] then
			snixzz.Copy.LocalPlayer():GetActiveWeapon()["Primary"]["Recoil"] = 0
		end
	end
	
	if snixzz.Copy.input.IsKeyDown( snixzz.Binds["+speedhack"] ) && !snixzz.Typing then
		snixzz.Functions.pSpeed( snixzz.Vars["speedhack_speed"] )
	else
		snixzz.Functions.pSpeed( 0 )
	end
	
	// No hands
	if snixzz.Bools["esp_nohands"] then
		snixzz.Functions.NoDraw( snixzz.Copy.Material( "models/weapons/v_models/hands/v_hands" ), true )
	else
		snixzz.Functions.NoDraw( snixzz.Copy.Material( "models/weapons/v_models/hands/v_hands" ), false )
	end

end

function snixzz.CalcView( ply, origin, angles, FOV )
	local ply = snixzz.Copy.LocalPlayer()
	local wep = ply:GetActiveWeapon()
	local view = GAMEMODE:CalcView( ply, origin, angles, FOV ) || {}
	
	// visual no recoil
	if snixzz.Bools["aim_norecoil"] then
		if wep["Primary"] then wep["Primary"]["Recoil"] = 0 end
		if wep["Secondary"] then wep["Secondary"]["Recoil"]	= 0 end
	end
	
	// Silent aim
	if snixzz.Bools["aim_silent"] then
		view.angles = snixzz.Silent
		view.vm_angles = snixzz.Silent
		view.origin = origin
		view.fov = 90
	else
		view.angles = snixzz.Angles
		view.angles.r = 0
		view.fov = 90
	end
	
	return view	
end

function snixzz.RenderScreenspaceEffects()
	if snixzz.Bools["esp_chams"] && snixzz.Bools["esp_enabled"] && snixzz.Copy.LocalPlayer():Alive() then
		for k, v in snixzz.Copy.pairs( snixzz.Copy.player.GetAll() ) do
			if snixzz.ShouldDraw( v ) then
				if snixzz.Vars["esp_chams_material"] != "XQZ" then
					local col = snixzz.Copy.team.GetColor( v:Team() )
					local wepcol = Color( 255, 255, 255 )
					
					snixzz.Copy.cam.Start3D( snixzz.Copy.EyePos(), snixzz.Copy.EyeAngles() )
						snixzz.Copy.render.SuppressEngineLighting( true )
						
						snixzz.Copy.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255, 1 )
						snixzz.Copy.render.MaterialOverride( snixzz.GetMaterial() )
						v:DrawModel()
						
						snixzz.Copy.render.SetColorModulation( wepcol.r / 255, wepcol.g / 255, wepcol.r / 255, 1 )
						if snixzz.Copy.IsValid( v:GetActiveWeapon() ) then
							v:GetActiveWeapon():DrawModel()
						end
						
						snixzz.Copy.render.SuppressEngineLighting( false )
						snixzz.Copy.render.SetColorModulation( 1, 1, 1, 1 )
						
						snixzz.Copy.render.MaterialOverride()
						snixzz.Copy.render.SetModelLighting( 4, col.r / 255, col.g / 255, col.b / 255 )
						v:DrawModel()
			
					snixzz.Copy.cam.End3D()
				elseif snixzz.Vars["esp_chams_material"] == "XQZ" then
					snixzz.Copy.cam.Start3D( snixzz.Copy.EyePos(), snixzz.Copy.EyeAngles() )
						snixzz.Copy.cam.IgnoreZ( true )
						snixzz.Copy.render.SuppressEngineLighting( true )
						v:DrawModel()
						if snixzz.Copy.IsValid( v:GetActiveWeapon() ) then
							v:GetActiveWeapon():DrawModel()
						end
						snixzz.Copy.cam.IgnoreZ( false )
						snixzz.Copy.render.SuppressEngineLighting( false )
					snixzz.Copy.cam.End3D()
				end
			end
		end
	end
end


function snixzz.HUDPaint()

	if !snixzz.Bools["esp_enabled"] then return end
	
	local font = "snixzz"
	local listpos = snixzz["Copy"]["ScrH"]() / 3.5

	for k, v in snixzz.Copy.pairs( snixzz["Copy"]["player"]["GetAll"]() ) do		
		
		// Player esp	
		if snixzz.ShouldDraw( v ) && snixzz.Copy.LocalPlayer():Alive() then
			
			// ESP Positions
			local bottom = ( v:GetPos() - snixzz["Copy"]["Vector"]( 0, 0, 10 ) ):ToScreen()
			local top = ( v:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 70 ) ):ToScreen()
			local height = ( bottom["y"] - top["y"] )
			local width = ( height / 4 )
			
			local wep
			if snixzz["Copy"]["IsValid"]( v:GetActiveWeapon() ) then
				wep = v:GetActiveWeapon():GetPrintName()
			else
				wep = "Unknown"
			end
			
			// player text color
			local color = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			
			// player box color
			local boxcolor = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v == snixzz["Target"] then
				boxcolor = Color( 255, 0, 0, 255 )
			else
				boxcolor = Color( 0, 200, 0, 255 )
			end
			
			// ESP text
			if snixzz.Bools["esp_name"] then
				snixzz.Copy.draw.SimpleTextOutlined( v:Nick() .. " [" .. v:Health() .. "]", font, top["x"], top["y"] - 10, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
			end
			
			if snixzz.Bools["esp_weapon"] then
				snixzz.Copy.draw.SimpleTextOutlined( wep, font, bottom["x"], bottom["y"] + 10, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
			end
			
			// Box ESP
			if snixzz.Bools["esp_box"] then
				snixzz.Copy.surface["SetDrawColor"]( boxcolor )
				snixzz.Copy.surface["DrawOutlinedRect"]( top["x"] - width, top["y"], width * 2, height )
			end
			
			if snixzz.Bools["esp_tracer"] then
				snixzz.Copy.cam.Start3D( snixzz.Copy.EyePos(), snixzz.Copy.EyeAngles() )
					snixzz.Copy.render.SetMaterial( snixzz.Copy.Material( "trails/laser" ) )
					local startpos = snixzz.Copy.LocalPlayer():GetPos()
					local endpos = v:GetBonePosition( v:LookupBone( "ValveBiped.Bip01_Head1" ) ) or v:GetPos()
					snixzz.Copy.render.DrawBeam( startpos, endpos, 3, 0, 0, boxcolor )
				snixzz.Copy.cam.End3D()
			end

		else
			continue;
		end	
	
	
		// spectator/admin list
		if snixzz.Bools["esp_list"] then
			if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz.Binds["+misc_list"] ) then
				if v:IsPlayer() then
					if v:GetObserverTarget() == snixzz["Copy"]["LocalPlayer"]() then
						snixzz["Copy"]["draw"]["SimpleText"]( v:Nick(), "snixzz_list", 2, listpos, Color( 0, 255, 255, 200 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						listpos = listpos + 12
					end
				end
			else	
				if v:IsPlayer() then
					if snixzz["IsAdmin"]( v ) then
						snixzz["Copy"]["draw"]["SimpleText"]( v:Nick(), "snixzz_list", 2, listpos, Color( 255, 80, 80, 200 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
						listpos = listpos + 12
					end
				end
			end
		end
	end
	
	// Asus concept
	for k, v in snixzz.Copy.pairs( game.GetWorld() ):GetMaterials() do
		if snixzz.Bools["esp_asus"] then
			snixzz.Copy.Material( v ):SetFloat( "$alpha", snixzz.Vars["esp_asus_alpha"] )
		elseif snixzz.Copy.Material( v ):GetFloat( "$alpha" ) != 1 then
			snixzz.Copy.Material( v ):SetFloat( "$alpha", 1 )
		end
	end
	
	// Aim status & shit
	if snixzz.Bools["esp_status"] then
		snixzz.Copy.draw.DrawText( snixzz.Status, "snixzz_status", snixzz.Copy.ScrW() / 2, snixzz.Copy.ScrH() * 0.5 + 50, snixzz.StatusColor, TEXT_ALIGN_CENTER )
	end
	
	-- Watermark	
	local text = "snixzz2 by 0xymoron" -- Changing this would be bogus as fuck, you didn't code this.
	local text2 = snixzz.Info.Version .. " - " ..snixzz.Info.Updated
	local w, h = surface.GetTextSize( text )
	local w2, h2 = surface.GetTextSize( text2 )
	snixzz.Copy.draw.DrawText( text, "snixzz_status", ScrW() / 2 - w / 2, 5, Color( 0, 255, 255, 255 ), TEXT_ALIGN_LEFT )
	snixzz.Copy.draw.DrawText( text2, "snixzz_status", ScrW() / 2 - w2 / 2, 25, Color( 0, 255, 255, 255 ), TEXT_ALIGN_LEFT )
		
	snixzz.Copy.surface.SetDrawColor( Color( 0, 0, 0, 230 ) )
	snixzz.Copy.surface.DrawOutlinedRect( ScrW() / 2 - w / 2 - 10, 5, w + 20, 20, 2, Color( 0, 0, 0, 90 ) )
	snixzz.Copy.surface.DrawOutlinedRect( ScrW() / 2 - w / 2 - 10, 24, w + 20, 20, 2, Color( 0, 0, 0, 90 ) )
	snixzz.Copy.surface.SetDrawColor( snixzz.Vars["misc_menucolor"].r, snixzz.Vars["misc_menucolor"].g, snixzz.Vars["misc_menucolor"].b, 90 )
	snixzz.Copy.surface.DrawRect( ScrW() / 2 - w / 2 - 10 + 1, 6, w + 18, 37 )
		
	// Crosshair
	local x = ScrW() / 2
	local y = ScrH() / 2
	
	local crosscolor = Color( 0, 0, 0, 255 )
	local crosslength = 50
	local gap = 2
	
	local boxsize = 5
		
	-- Box
	if snixzz.Bools["esp_crosshair_box"] then
		snixzz.Copy.surface.SetDrawColor( Color( 255, 255, 255 ) )
		snixzz.Copy.surface.DrawOutlinedRect( x - boxsize - 2, y - boxsize - 2, ( boxsize + 2 ) * 2 + 1, ( boxsize + 2 ) * 2 + 1 )
	end
	
	-- Crosshair
	if snixzz.Bools["esp_crosshair"] then
		snixzz.Copy.surface.SetDrawColor( 0, 0, 0, 255 )
		snixzz.Copy.surface.DrawLine( x - crosslength, y, x - gap, y )
		snixzz.Copy.surface.DrawLine( x + crosslength, y, x + gap, y )
		
		snixzz.Copy.surface.DrawLine( x, y - crosslength, x, y - gap )
		snixzz.Copy.surface.DrawLine( x, y + crosslength, x, y + gap )
	end
	
	-- Menu opening
	if ( snixzz.Copy.input.IsKeyDown( snixzz.Binds["+menu"] ) && !snixzz.Typing && !snixzz.MenuOpen && !gui.IsConsoleVisible() ) then
		snixzz.Menu()
		snixzz.MenuOpen = true
	end
end

snixzz.properCurTime = 0
function snixzz.Move()
	if IsFirstTimePredicted() then return end
	snixzz.properCurTime = CurTime()
end

function snixzz.Namechanger()
	if snixzz.Bools["misc_namechanger"] then
		snixzz.NextName = table.Random( player.GetAll() ):Nick()
		snixzz.Copy.chat.AddText( Color( 0, 255, 255 ), "[snixzz2] Changed your name to " .. snixzz.NextName ) 
		snixzz.Functions.ClientCMD( "name " .. snixzz.NextName .. " % %" )
	end
end
snixzz.RegisterTimer( snixzz.Copy.GetConVarNumber( "sv_namechange_cooldown_seconds" ), 0, snixzz.Namechanger )

/*
	DETOURS
	Adding them as I go, don't bitch that I haven't detoured every function 
*/
_R["Entity"]["FireBullets"] = snixzz["Detour"]( _R["Entity"]["FireBullets"], function( e, bullet )
	snixzz["Cones"][ snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetClass() ] = bullet["Spread"]
	return snixzz["Detours"][ _R["Entity"]["FireBullets"] ]( e, bullet )
end )

file["Exists"] = snixzz["Detour"]( file["Exists"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then // stay out
		snixzz["Message"]( Color( 255, 0, 0 ), "An anti-cheat attempted to search for snixzz" )
		return false
	else
		return snixzz["Detours"][ file["Exists"] ]( filename, dir )
	end
end )

file["Read"] = snixzz["Detour"]( file["Read"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then 
		return "No, you cannot have my source code."
	else
		return snixzz["Detours"][ file["Read"] ]( filename, dir )
	end
end )

net.Start = snixzz["Detour"]( net["Start"], function( name )
	if ( name == "checksaum" || name == "send" || name == "leyac_cmd" ) then
		snixzz["Message"]( Color( 255, 0, 0 ), "Blocked net.Send " .. name )
		return
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.Send( '" .. name .. "' )" )
		return snixzz["Detours"][ net["Start"] ]( name )
	end
end )

net.WriteString = snixzz["Detour"]( net["WriteString"], function( str )
	if snixzz["Copy"]["string"]["find"]( str, "snixzz" ) then
		return "fuck that"
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.WriteString( " .. str .. " )" )
		return snixzz["Detours"][ net["WriteString"] ]( str )
	end
end )

GetConVarNumber = snixzz["Detour"]( GetConVarNumber, function( cvar )
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Spoof"] ) do
		if cvar == v then
			snixzz["Message"]( Color( 255, 255, 255 ), "*ANTICHEAT ALERT* Server tried to check convar " .. v .. " returning default value " .. k )
			return k
		else
			return snixzz["Detours"][ GetConVarNumber ]( cvar )
		end
	end
end )

RunConsoleCommand = snixzz["Detour"]( RunConsoleCommand, function( cmd, ... )
	snixzz["Message"]( Color( 255, 255, 255 ), "RunConsoleCommand( '" .. cmd .. "' )" )
	return snixzz["Detours"][ RunConsoleCommand ]( cmd, ... )
end )

snixzz["StartChat"] = GAMEMODE["StartChat"] 
function GAMEMODE:StartChat() 
	snixzz["StartChat"]() 
	snixzz["Typing"] = true 
end 
snixzz["FinishChat"] = GAMEMODE["FinishChat"] 
function GAMEMODE:FinishChat() 
	snixzz["FinishChat"]() 
	snixzz["Typing"] = false 
end 

/*
	
	Menu Core
	
*/


function snixzz.Menu()
	local tabs, menuheight, menuwidth, w, h = {}, 430, 240, ScrW() / 2, ScrH() / 2
	
	snixzz.Frame = snixzz.Copy.vgui.Create( "DPropertySheet" )
	snixzz.Frame:SetCursor( "crosshair" )
	snixzz.Frame:SetParent( snixzz.Frame )
	snixzz.Frame:SetPos( 20, 60 )
	--snixzz.Frame:SetPos( w - ( menuwidth / 2 ), h - ( menuheight / 2 ) )
	snixzz.Frame:SetSize( menuwidth, menuheight )
	snixzz.Frame:SetVisible( true )
	snixzz.Frame:MakePopup()
	snixzz.Frame.Think = function()
		if !snixzz.Copy.input.IsKeyDown( snixzz.Binds["+menu"] ) then
			snixzz.MenuOpen = false
			snixzz.Frame:SetVisible( false )
		end
	end		
	snixzz.Frame.Paint = function() 
		snixzz.Copy.draw.RoundedBox( 0, 0, 0, snixzz.Frame:GetWide(), snixzz.Frame:GetTall(), snixzz.Vars["misc_menucolor"] )
		snixzz.Copy.surface.SetDrawColor( Color( 0, 0, 0 ) )
		snixzz.Copy.surface.DrawOutlinedRect( 0, 0, snixzz.Frame:GetWide() , snixzz.Frame:GetTall() )
	end

	-- Parents for the tabs
	tabs.aimbot = vgui.Create( "DLabel", snixzz.Frame )
	tabs.aimbot:SetPos( 0, 0 )
	tabs.aimbot:SetText( "" )
	tabs.aimbot:SetCursor( "crosshair" )
	
	tabs.esp = vgui.Create( "DLabel", snixzz.Frame )
	tabs.esp:SetPos( 0, 0 )
	tabs.esp:SetText( "" )
	tabs.esp:SetCursor( "crosshair" )
	
	tabs.misc = vgui.Create( "DLabel", snixzz.Frame )
	tabs.misc:SetPos( 0, 0 )
	tabs.misc:SetText( "" )
	tabs.misc:SetCursor( "crosshair" )

	tabs.config = vgui.Create( "DLabel", snixzz.Frame )
	tabs.config:SetPos( 0, 0 )
	tabs.config:SetText( "" )
	tabs.config:SetCursor( "crosshair" )

	snixzz.Frame:AddSheet( "Aimbot", tabs.aimbot, "icon16/bomb.png", false, false )
	snixzz.Frame:AddSheet( "Visual", tabs.esp, "icon16/picture_edit.png", false, false )
	snixzz.Frame:AddSheet( "Misc", tabs.misc, "icon16/plugin.png", false, false )
	snixzz.Frame:AddSheet( "Config", tabs.config, "icon16/wrench.png", false, false )

	-- Aimbot Settings
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aimbot Toggle", "aim_toggle", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Autoshoot", "aim_autoshoot", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Silent Aim", "aim_silent", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Spread Prediction", "aim_nospread", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Aim Prediction", "aim_prediction", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Remove Recoil", "aim_norecoil", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Team", "aim_ignoreteam", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Admins", "aim_ignoreadmins", 5, 145 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Steam Friends", "aim_ignoresteam", 5, 165 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore Bots", "aim_ignorebots", 5, 185 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Ignore LOS", "aim_ignorelos", 5, 205 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Check FOV", "aim_checkfov", 5, 225 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti Anti-Aim", "aim_antiantiaim", 5, 245 )
	snixzz.CreateOption( "Checkbox", tabs.aimbot, "Anti-Aim", "aim_anti", 5, 265 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Field of View", "aim_fov", 1, 180, 235, 5, 345, 0 )
	snixzz.CreateOption( "Slider", tabs.aimbot, "Aimspot Offset", "aim_offset", -20, 20, 235, 5, 365, 0 )
	
	snixzz.CreateOption( "Label", tabs.aimbot, "Prediction Method", 120, 70 )
	local PredictionMethod = snixzz.Copy.vgui.Create( "DComboBox", tabs.aimbot )
	PredictionMethod:SetPos( 115, 85 )
	PredictionMethod:SetSize( 105, 20 )
	PredictionMethod:SetText( snixzz.Vars["aim_prediction_method"] )
	PredictionMethod:AddChoice( "Velocity 0.013" )
	PredictionMethod:AddChoice( "Velocity 0.02" )
	PredictionMethod.OnSelect = function( self )
		snixzz.Vars["aim_prediction_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set prediction method to '" .. self:GetValue() .. "'" )
	end	
	
	// Target method
	snixzz.CreateOption( "Label", tabs.aimbot, "Target Method", 115, 205 )
	local TargetMethod = snixzz.Copy.vgui.Create( "DComboBox", tabs.aimbot )
	TargetMethod:SetPos( 115, 220 )
	TargetMethod:SetSize( 105, 20 )
	TargetMethod:SetText( snixzz.Vars["aim_target_method"] )
	TargetMethod:AddChoice( "Distance" )
	TargetMethod:AddChoice( "Crosshair" )
	TargetMethod.OnSelect = function( self )
		snixzz.Vars["aim_target_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set target method to '" .. self:GetValue() .. "'" )
	end	
	
	// AntiAim Method
	snixzz.CreateOption( "Label", tabs.aimbot, "Anti-Aim Method", 115, 250 )
	local AntiAimMethod = snixzz.Copy.vgui.Create( "DComboBox", tabs.aimbot )
	AntiAimMethod:SetPos( 115, 265 )
	AntiAimMethod:SetSize( 105, 20 )
	AntiAimMethod:SetText( snixzz.Vars["aim_anti_method"] )
	for k, v in snixzz.Copy.pairs( snixzz.AntiAimMethods ) do
		AntiAimMethod:AddChoice( v )
	end
	AntiAimMethod.OnSelect = function( self )
		snixzz.Vars["aim_anti_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set anti-aim method to '" .. self:GetValue() .. "'" )
	end

	-- Aimbot hitbox/bone method & spot selection
	snixzz.CreateOption( "Label", tabs.aimbot, "Aimbot Method", 5, 310 )
	local AimbotMethod = snixzz.Copy.vgui.Create( "DComboBox", tabs.aimbot )
	AimbotMethod:SetPos( 5, 325 )
	AimbotMethod:SetSize( 105, 20 )
	AimbotMethod:SetText( snixzz.Vars["aim_method"] )
	AimbotMethod:AddChoice( "Hitbox" )
	AimbotMethod:AddChoice( "Bone" )
	AimbotMethod.OnSelect = function( self )
		snixzz.Vars["aim_method"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set aimbot method to '" .. self:GetValue() .. "'" )
		
		 -- Close to menu to avoid bugs.
		snixzz.Frame:SetVisible( false )
		snixzz.MenuOpen = false
	end
	
	-- SPOT SELECTION. I AM PROUD OF THIS!
	snixzz.CreateOption( "Label", tabs.aimbot, "Aim Spot", 115, 310 )
	local Aimspot = snixzz.Copy.vgui.Create( "DComboBox", tabs.aimbot )
	Aimspot:SetPos( 115, 325 )
	Aimspot:SetSize( 105, 20 )
	if snixzz.Vars["aim_method"] == "Hitbox" then
		Aimspot:SetText( snixzz.Vars["aim_hitbox"] )
	elseif snixzz.Vars["aim_method"] == "Bone" then
		Aimspot:SetText( snixzz.Vars["aim_bone"] )
	end
	if snixzz.Vars["aim_method"] == "Hitbox" then
		for k, v in snixzz.Copy.pairs( snixzz.Hitboxes ) do
			Aimspot:AddChoice( k )
		end
	elseif snixzz.Vars["aim_method"] == "Bone" then
		for k, v in snixzz.Copy.pairs( snixzz.Bones ) do
			Aimspot:AddChoice( k )
		end
	end
	Aimspot.OnSelect = function( self )
		if snixzz.Vars["aim_method"] == "Hitbox" then
			snixzz.Vars["aim_hitbox"] = self:GetValue()
			snixzz.Message( Color( 0, 255, 255 ), "Set aimbot hitbox to '" .. self:GetValue() .. "'" )
		elseif snixzz.Vars["aim_method"] == "Bone" then
			snixzz.Vars["aim_bone"] = self:GetValue()
			snixzz.Message( Color( 0, 255, 255 ), "Set aimbot bone to '" .. self:GetValue() .. "'" )
		end
	end

	-- Visual Settings
	snixzz.CreateOption( "Checkbox", tabs.esp, "Enable Visuals", "esp_enabled", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Name & HP", "esp_name", 5, 25 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Weapon", "esp_weapon", 5, 45 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Box", "esp_box", 5, 65 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Player Chams", "esp_chams", 5, 85 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Draw Tracers", "esp_tracer", 5, 105 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair", "esp_crosshair", 5, 125 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Crosshair Box", "esp_crosshair_box", 5, 145 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Remove Hands", "esp_nohands", 5, 165 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Aimbot Status", "esp_status", 5, 185 )
	snixzz.CreateOption( "Checkbox", tabs.esp, "Admin/Spectator List", "esp_list", 5, 205 )
	snixzz.CreateOption( "Slider", tabs.esp, "Render Distance", "esp_distance", 0, 7500, 235, 5, 365, 0 )
	
	-- Misc Settings
	snixzz.CreateOption( "Checkbox", tabs.misc, "Enable Bunnyhop", "misc_bhop", 5, 5 )
	snixzz.CreateOption( "Checkbox", tabs.misc, "Name Stealer", "misc_namechanger", 5, 25 )
	snixzz.CreateOption( "Slider", tabs.misc, "Speedhack Speed", "speedhack_speed", 1.5, 5, 235, 5, 365, 1 )
	
	snixzz.CreateOption( "Label", tabs.esp, "Chams Material", 115, 70 )
	local ChamsType = snixzz.Copy.vgui.Create( "DComboBox", tabs.esp )
	ChamsType:SetPos( 115, 85 )
	ChamsType:SetSize( 105, 20 )
	ChamsType:SetText( snixzz.Vars["esp_chams_material"] )
	ChamsType:AddChoice( "Solid" )
	ChamsType:AddChoice( "Wireframe" )
	ChamsType:AddChoice( "XQZ" )
	ChamsType.OnSelect = function( self )
		snixzz.Vars["esp_chams_material"] = self:GetValue()
		snixzz.Message( Color( 0, 255, 255 ), "Set chams material to '" .. self:GetValue() .. "'" )
	end
	
	-- Config Tab
		--Menu Settings
	snixzz.CreateOption( "Label", tabs.config, "Menu Color", 5, 5 )
	local Mixer = vgui.Create( "DColorMixer", tabs.config )
	Mixer:SetPos( 5, 240 ) 
	Mixer:SetSize( 130, 90 )
	--Mixer:Dock( FILL )
	Mixer:SetPalette( false )
	Mixer:SetAlphaBar( true )
	Mixer:SetWangs( false )
	Mixer:SetColor( snixzz.Vars["misc_menucolor"] )
	Mixer.ValueChanged = function()
		snixzz.Vars["misc_menucolor"] = Mixer:GetColor()
	end
	
	local CfgList = snixzz.Copy.vgui.Create( "DListView", tabs.config ) 
	CfgList:SetPos( 5, 5 ) 
	CfgList:SetMultiSelect( false ) 
	CfgList:SetSize( 235, 80 )
	CfgList:AddColumn( "Config" ) 
	for k, v in snixzz.Copy.pairs( snixzz.Configs ) do 
		CfgList:AddLine( v ) 
	end 
	CfgList.DoDoubleClick = function() 
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config ) 
		end 
	end 
		
	// Direct from ginject
	local CreateConfig = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	CreateConfig:SetText( "Create New" ) 
	CreateConfig:SetSize( 105, 30 )
	CreateConfig:SetPos( 5, 90 )
	CreateConfig.DoClick = function() 
		Derma_StringRequest( "New Config", "Name of the new config", "", function( txt ) 
			snixzz.SaveConfig( txt ) 
		end )
	end 

	local RenameConfig = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	RenameConfig:SetText( "Rename" ) 
	RenameConfig:SetSize( 105, 30 )
	RenameConfig:SetPos( 5, 125 )
	RenameConfig.DoClick = function()
		Derma_StringRequest( "Rename Config", "Name of the new config", "", function( NewConfig ) 
			local line = CfgList:GetSelectedLine() 
			if line != nil then 
				local OldConfig = CfgList:GetLine( line ):GetValue( 1 ) 
				if OldConfig != "default" then
					snixzz.RenameConfig( OldConfig, NewConfig )
					snixzz.Copy.table.remove( snixzz.Configs, CfgList:GetSelectedLine() )
					snixzz.Copy.table.insert( snixzz.Configs, NewConfig )
				else
					snixzz.Message( snixzz.Colors["Red"], "You cannot rename the default config!" )
				end
			end
		end )
	end	
	
	local DeleteConfig = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	DeleteConfig:SetText( "Delete" ) 
	DeleteConfig:SetSize( 105, 30 )
	DeleteConfig:SetPos( 118, 90 )
	DeleteConfig.DoClick = function() 
		local line = CfgList:GetSelectedLine() 
		if line != nil then
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			if config != "default" then
				for k, v in snixzz.Copy.pairs( snixzz.Configs ) do 
					if v == config then 
						snixzz.DeleteConfig( config )
						snixzz.Copy.table.remove( snixzz.Configs, k ) 
					end 
				end
			else
				snixzz.Message( snixzz.Colors["Red"], "You cannot delete the default config!" )
			end
		end 
	end 
	
	local LoadConfig = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	LoadConfig:SetText( "Load" ) 
	LoadConfig:SetSize( 105, 30 )
	LoadConfig:SetPos( 118, 125 )
	LoadConfig.DoClick = function()
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.LoadConfig( config )
			snixzz.Frame:SetVisible( false )
			snixzz.MenuOpen = false
		end
	end
	
	local SetDefaultCfg = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	SetDefaultCfg:SetText( "Set Default" ) 
	SetDefaultCfg:SetSize( 105, 30 )
	SetDefaultCfg:SetPos( 118, 160 )
	SetDefaultCfg.DoClick = function()
		local line = CfgList:GetSelectedLine() 
		if line != nil then 
			local config = CfgList:GetLine( line ):GetValue( 1 ) 
			snixzz.SetDefaultConfig( config )
			snixzz.LoadConfig( config )
		end
	end	
	
	local ReloadHooks = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	ReloadHooks:SetText( "Reload Hooks" ) 
	ReloadHooks:SetSize( 105, 30 )
	ReloadHooks:SetPos( 118, 195 )
	ReloadHooks.DoClick = function()
		snixzz.ReloadHooks()
	end	
	
	// Binds
	local BindCommands = snixzz.Copy.vgui.Create( "DComboBox", tabs.config )
	BindCommands:SetPos( 5, 160 )
	BindCommands:SetSize( 105, 20 )
	for k, v in snixzz.Copy.pairs( snixzz.Binds ) do
		BindCommands:AddChoice( k )
	end
	
	local BindKeys = snixzz.Copy.vgui.Create( "DComboBox", tabs.config )
	BindKeys:SetPos( 5, 185 )
	BindKeys:SetSize( 105, 20 )
	for k, v in snixzz.Copy.pairs( snixzz.Keys ) do
		BindKeys:AddChoice( v.Name )
	end
	
	local RebindKey = snixzz.Copy.vgui.Create( "DButton", tabs.config ) 
	RebindKey:SetText( "Bind" ) 
	RebindKey:SetSize( 105, 20 )
	RebindKey:SetPos( 5, 210 )
	RebindKey.DoClick = function() 
		local Key = BindKeys:GetValue()
		local Command = BindCommands:GetValue()
		if ( BindKeys:GetValue() != "" && BindCommands:GetValue() != "" ) then
			snixzz.Frame:SetVisible( false )
			snixzz.MenuOpen = false
			snixzz.BindKey( Command, Key )
		end
	end 
	
end

/*

	Hooking & loading.
	
*/

snixzz.Hooks = {}

snixzz.Hooks["CreateMove"] = snixzz.CreateMove
snixzz.Hooks["HUDPaint"] = snixzz.HUDPaint
snixzz.Hooks["CalcView"] = snixzz.CalcView
snixzz.Hooks["Move"] = snixzz.Move
snixzz.Hooks["RenderScreenspaceEffects"] = snixzz.RenderScreenspaceEffects

snixzz["Message"]( Color( 255, 180, 180, 255 ), "Creating hooks..." )

for k, v in snixzz.Copy.pairs( snixzz.Hooks ) do
	snixzz.RegisterHook( k, v )
end


snixzz.LoadConfig( snixzz.DefaultConfig )