require("nyx_mod")
_nyx.Init()
local meHook = _G.table.Copy(_G);
local _R = debug.getregistry()
local aimbot = false

local wep_cones = {}

local old_fire = debug['getregistry']()['Entity']['FireBullets']
	debug['getregistry']()['Entity']['FireBullets'] = function( ent, bullet )
		wep_cones[LocalPlayer():GetActiveWeapon():GetPrintName()] = bullet['Spread']
	return old_fire( ent, bullet )
end

function GetCone( wep )
	if !IsValid( wep ) then return 0 end
	
	if HL2Cones[ wep:GetClass() ] then return HL2Cones[ wep:GetClass() ] end
	if NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
	if CustomCones[ wep.Base ] then return CustomCones[ wep.Base ]( wep ) end
	
	local Cone = wep.Cone
	
	if !Cone then
		Cone = wep.Primary and wep.Primary.Cone or 0
	end
	
	return Cone
end

NormalCones 			= {
	[ "weapon_cs_base" ]	= true,
	[ "weapon_sh_base" ] 	= true,
	[ "weapon_zs_base" ] 	= true,
}

HL2Cones 				= {
	[ "weapon_pistol" ] 	= Vector( 0.0100, 0.0100, 0.0100 ),
	[ "weapon_smg1" ] 		= Vector( 0.04362, 0.04362, 0.04362 ),
	[ "weapon_ar2" ]		= Vector( 0.02618, 0.02618, 0.02618 ),
	[ "weapon_shotgun" ]	= Vector( 0.08716, 0.08716, 0.08716 ),
}

CustomCones 			= {
	[ "weapon_sh_base" ]	= function( wep )
								local Cone = wep.Primary.Cone
								local Recoil = WeaponRecoil[ wep:GetClass() ]
								local IsSniper = wep.Sniper and 2 or 1								
								local Stance = wep.Owner:IsOnGround() and wep.Owner:Crouching() and 10
								or !wep.Sprinting and wep.Owner:IsOnGround() and 15
								or wep.Walking and wep.Owner:IsOnGround() and 20
								or !wep.Owner:IsOnGround() and 25
								or wep.Primary.Ammo == "buckshot" and 0
									
								local WepType = wep.Sniper and 8
								or wep.SMG and 2
								or wep.Pistol and 2
								or wep.Primary.Ammo == "buckshot" and 0
								or 1.6								
								local Shotgun = wep.Primary.Ammo == "buckshot" and wep.Primary.Cone or 0			
								if wep:GetIronsights() then
									return Cone
								else
									return Cone * Recoil * Stance * WepType + Shotgun
								end
							end,
	[ "weapon_zs_base" ] = function( wep )
								local Cone = wep.Cone or wep.Primary.Cone or 0		
								if LocalPlayer():GetVelocity():Length() > 20 then
									return wep.ConeMoving
								end									
								if LocalPlayer():Crouching() then
									return wep.ConeCrouching
								end		
								return Cone
							end,
}


--[[
local function PredictSpread( cmd, ang )
	wep = LocalPlayer():GetActiveWeapon()
	vecCone, valCone = _G.Vector( 0, 0, 0 )
	if( _R.Entity.IsValid(wep) ) then
		if ( wep_cones[wep:GetPrintName()] ) then
			valCone = wep_cones[wep:GetPrintName()]
		if( tonumber( valCone ) ) then
			vecCone =  Vector( -valCone, -valCone, -valCone )
		elseif( type( valCone ) == "Vector" ) then
			vecCone = -1 * valCone
	end
		else
		if( hl2cones[wep:GetPrintName()] ) then 
	vecCone = hl2cones[wep:GetPrintName()] 
		end
	end
end

	return ( _nyx['RemoveSpread']( cmd, ang, vecCone ) ):Angle()
end
--]]

local function PredictSpread( cmd, ang )
local w = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
		//valCone = GetCone( w )     
		valCone = wep_cones[ w:GetPrintName() ]
		if ( type( valCone ) == "number" ) then
			vecCone = Vector( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + (cone * 2 )                        
		end
	else
		if ( w:IsValid() ) then
			local class = w:GetClass()
			if ( CustomCones[ class ] ) then
				vecCone = CustomCones[ class ]
			elseif ( HL2Cones[ class ] ) then
				vecCone = HL2Cones[ class ]
			end
		end
	end
return ( _nyx['RemoveSpread']( cmd, ang, vecCone ) ):Angle()
end

hook.Add("Think","meVisuals", function()
	local p = LocalPlayer()
    wep = LocalPlayer():GetActiveWeapon()
    if ( wep["Primary"] ) then wep["Primary"]["Recoil"] = 0 end
    if ( wep["Secondary"] ) then wep["Secondary"]["Recoil"] = 0 end
end)

function meVisible( ent )
    local tracer = {}
    tracer.start = LocalPlayer():GetShootPos()
    tracer.endpos = ent:GetShootPos()
    tracer.filter = { LocalPlayer(), ent }
    tracer.mask = MASK_SHOT
    local trace = util.TraceLine( tracer )
    if trace.Fraction >= 1 then return true else return false end
end

local meAttack = false;
local function meAuto(CUserCmd)
	if aimbot == true then
	if (CUserCmd:KeyDown( IN_ATTACK )) then
		if (meAttack) then
	CUserCmd:SetButtons( bit.band( CUserCmd:GetButtons(), bit.bnot( IN_ATTACK ) ) );
else
	CUserCmd:SetButtons( bit.bor( CUserCmd:GetButtons(), IN_ATTACK ) );

end
	meAttack = !meAttack;
		end
	end
end

hook.Add("CreateMove","meAuto",meAuto);



function meAimbot(ucmd)
local ply = LocalPlayer()
	for k,v in pairs(player.GetAll()) do
	if aimbot == true then
	if v:Alive() and IsValid(v) and v != LocalPlayer() and meVisible(v) and v:Team() ~= TEAM_SPECTATOR and v:GetFriendStatus() ~= "friend" then
			meAimpos = v:LookupAttachment("eyes")
			meAimpos = v:GetAttachment(meAimpos)
			meAimpos = (meAimpos.Pos - LocalPlayer():GetShootPos()):Angle()
			ucmd:SetViewAngles(PredictSpread(ucmd,meAimpos))
			ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_ATTACK ) );

							end
						end
					end
				end
hook.Add("CreateMove", "Aimbot", meAimbot)
	

concommand.Add("+me_aim", function()
	aimbot = true	
end )

concommand.Add("-me_aim", function()
	aimbot = false
end )
