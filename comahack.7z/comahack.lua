--[[
	MOD/lua/traitor.lua
	snooty arbiter of originality | STEAM_0:1:68153005 <66.66.217.170:27005> | [23-11-13 01:50:46AM]
	===BadFile===
]]

--Coma-Hack
--Coded By Coma
--March 6, 2011
 
if SERVER then return end
 
--------------/
----ConVars----
--------------/
 
--ESP
CreateClientConVar( "Coma_ESP_Player", 0, true, false )
CreateClientConVar( "Coma_ESP_Health", 1, true, false )
CreateClientConVar( "Coma_ESP_ShowAll", 0, true, false )
CreateClientConVar( "Coma_ESP_NPC", 0, true, false )
CreateClientConVar( "Coma_ESP_MoneyPrinter", 1, true, false )
CreateClientConVar( "Coma_ESP_Money", 1, true, false )
CreateClientConVar( "Coma_ESP_Shipment", 1, true, false )
CreateClientConVar( "Coma_ESP_Weapons", 1, true, false )
CreateClientConVar( "Coma_ESP_Items", 0, true, false)
--
--MISC
CreateClientConVar( "Coma_Misc_Bhop", 0, true, false )
CreateClientConVar( "Coma_Misc_Keypad", 0, true, false )
CreateClientConVar( "Coma_Misc_LogIPs", 1, true, false )
CreateClientConVar( "Coma_Misc_ULXAntiGag", 1, true, false )
CreateClientConVar( "Coma_Misc_Date", 0 , true, false )
CreateClientConVar( "Coma_Misc_FPS", 0, true, false )
CreateClientConVar( "Coma_Misc_Spammer", 0, true, false )
--
 
--TTT
CreateClientConVar( "Coma_Traitor", 0, true, false )
CreateClientConVar( "Coma_ESP_C4Detection", 1, true, false )
--
--SH
CreateClientConVar( "Coma_SlowSpeedHack", 0.15, true, false )
CreateClientConVar( "Coma_SH_CheatsOff", 1, true, false )
CreateClientConVar( "Coma_SHSpeed", 7, true, false )
CreateClientConVar( "Coma_HostFrameRate", 1, true, false )
CreateClientConVar( "Coma_HostTimeScale", 0, true, false )
--
--AIM
--CreateClientConVar( "Coma_AimBot_SmoothAim", 0, true, false )
--CreateClientConVar( "Coma_AimBot_SmoothAimSpeed", 2, true, false )
CreateClientConVar( "Coma_AimBot_Autoshoot", 0, true, false )
CreateClientConVar( "Coma_AimBot_NoRecoil", 1, true, false )
CreateClientConVar( "Coma_AimBot_NoSpread", 1, true, false )
CreateClientConVar( "Coma_AimBot_IgnoreSteamFriends", 1, true, false )
CreateClientConVar( "Coma_AimBot_IgnoreAdmins", 1, true, false )
CreateClientConVar( "Coma_AimBot_FriendlyFire", 1, true, false )
CreateClientConVar( "Coma_AimBot_IgnoreTraitorFriends", 1, true, false )
 
local ComaHUDDraw = 0
 
local oC  = table.Copy( concommand )
local oT  = table.Copy( timer )
local oH  = table.Copy( hook )
local oCV = table.Copy( cvars )
local oS  = table.Copy( sql )
local oSR = table.Copy( string )
local oM  = table.Copy( math )
local oF  = table.Copy( file )
local oD  = table.Copy( debug )
local oHTTP = table.Copy( http )
local oUM = table.Copy( usermessage )
 
---------------------------------------------------------------------------------------------------------------------------------
 
--ESP Code
hook.Add( "HUDPaint", "ComaESPSettings", function() -- Adding the hook
 
if GetConVarNumber( "Coma_ESP_Player" ) >= 1 then
for k, v in pairs( player.GetAll() ) do
if ValidEntity( v ) then
if v ~= LocalPlayer() then
local PlyESPPos = ( v:EyePos() ):ToScreen()
if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
draw.SimpleText( v:Nick(), "TabLarge", PlyESPPos.x, PlyESPPos.y -46, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                     draw.SimpleText( team.GetName(v:Team()), "TabLarge", PlyESPPos.x, PlyESPPos.y -42, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER)
local health
if GetConVarNumber( "Coma_ESP_Health" ) >= 1 then
else return end
                      draw.SimpleText("Armor:" .. v:Armor(), "TabLarge", PlyESPPos.x, PlyESPPos.y -22 , team.GetColor( v:Team() ), TEXT_ALIGN_CENTER)
                     draw.SimpleText( "Health:" ..v:Health(), "TabLarge", PlyESPPos.x, PlyESPPos.y -32, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER)
end
if v:IsAdmin() and
 GetConVarNumber( "Coma_Traitor" ) >= 1 then
draw.SimpleText( "-Admin-", "TabLarge", PlyESPPos.x, PlyESPPos.y - 56, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
else
 
   end
end
 
                          
  
 
  
else
 
if GetConVarNumber( "Coma_ESP_ShowAll" ) >= 1 then
draw.SimpleText( "-Dead-", "TabLarge", PlyESPPos.x, PlyESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                        draw.SimpleText( v:Nick(), "TabLarge", PlyESPPos.x, PlyESPPos.y, colorhp, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
               end
            end
         end
 
end
if GetConVarNumber( "Coma_ESP_NPC" ) >= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsNPC() then
local NpcESPPos = ( v:EyePos() ):ToScreen()
draw.SimpleText( v:GetClass(), "TabLarge", NpcESPPos.x, NpcESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
         end
      end end
   end
end)
 
--Weapons
 
if GetConVarNumber( "Coma_ESP_Weapons" ) >= 1 then
 
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsWeapon() && v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then
 
WeaponPos = v:EyePos():ToScreen()
 
draw.SimpleText( v:GetClass(), "TabLarge", WeaponPos.x, WeaponPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
               end
            end
         end
      end
   end
 
 
---------------------------------------------------------------------------------------------------------------------------------
 
--(SL) Core
--Coded by Coma
 
timer.Simple( 3, function()
if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
 
local Traitors = {}
local TWeapons = { "weapon_ttt_knife", "weapon_ttt_c4" }
local TWeapons2 = { "weapon_ttt_push", "weapon_ttt_phammer" }
local TWeapons3 = { "weapon_ttt_sipistol", "weapon_ttt_flaregun" }
local TWeapons4 = { "(Disguise)", "weapon_ttt_radio" }
local UsedWeapons = {}
local MapWeapons = {}
 
local function IsATraitor( ply )
for k, v in pairs( Traitors ) do
if v == ply then
return true
else
return false
      end
   end
end
 
local Stopper = 0
 
timer.Create( tostring( math.random( 1, 1000 ) ), 0.8, 0, function()
 
if GetConVarNumber( "Coma_Traitor" ) >= 1 then
if !IsATraitor( ply ) then
for k, v in pairs( ents.FindByClass( "player" ) ) do
if ValidEntity( v ) then
if (!v:IsDetective()) then
if v:Team() ~= TEAM_SPECTATOR then
 
for wepk, wepv in pairs( TWeapons || TWeapons2 || Tweapons3 || TWeapons4 ) do
for entk, entv in pairs( ents.FindByClass( wepv ) ) do
if ValidEntity( entv ) then
cookie.Set( entv, 100 - wepk )
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
local EntPos = ( entv:GetPos() - Vector( 0, 0, 35 ) )
 
if entv:GetClass() == wepv then
 
if v:GetPos():Distance( EntPos ) > 1 then
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
table.insert( MapWeapons, cookie.GetNumber( entv ) )
   end
end
 
if v:GetPos():Distance( EntPos ) <= 1 then
table.insert( Traitors, v )
 
if Stopper == 0 then
 
chat.AddText(
    Color(153,153,152,255), "[Coma] ",
    Color(255,0,0,255), v:Nick(),
    Color(255,0,0,255), " has the traitor weapon: ",
   Color(255,0,0,255), entv:GetClass() )
 
Stopper = Stopper + 1
 
timer.Simple( 1.5, function()
Stopper = 0
   end )
end
 
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
table.insert( UsedWeapons, cookie.GetNumber( entv ) )
                                          end
                                       end
                                    end
                                 end
                              end
                           end
                        end
                     end
                  end
               end
            end
         end
      end
   end
end )
 
hook.Add( "HUDPaint", "DrawESPTraitor", function()
if GetConVarNumber( "Coma_Traitor" ) >=1 then
for k, v in pairs( Traitors ) do
if ValidEntity( v ) then
if v:Team() ~= TEAM_SPECTATOR then
if v ~= LocalPlayer() then
if ( !v:IsDetective() ) then
local PlyESPPos = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
draw.SimpleText( "-Traitor-", "TabLarge", PlyESPPos.x, PlyESPPos.y - 13, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
                  end
               end
            end
         end
      end
   end
end )
 
hook.Add( "TTTPrepareRound", "ResetItAll42", function()
timer.Simple( 2, function()
for k, v in pairs( Traitors ) do
table.remove( Traitors, k )
Traitors = {}
end
for k, v in pairs( UsedWeapons ) do
table.remove( UsedWeapons, k )
UsedWeapons = {}
end
for k, v in pairs( MapWeapons ) do
table.remove( MapWeapons, k )
MapWeapons = {}
            end
         end )
      end )
   end
end )
 
---------------------------------------------------------------------------------------------------------------------------------
 
 
 
------------------------------------------------------------------------
 
local convar = CreateClientConVar( "Coma_ESP_L4DGlow", "1", true )
local teamcolors = CreateClientConVar( "Coma_ESP_L4D_TeamColors", "1", true )
local passes = CreateClientConVar( "Coma_ESP_L4D_Passes", "3", true )
  
local MaterialBlurX = Material( "pp/blurx" )
local MaterialBlurY = Material( "pp/blury" )
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} )
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} )
  
// we need two render targets, if you don't want to create them yourself, you can
local RT1 = render.GetBloomTex0()
local RT2 = render.GetBloomTex1()
  
/*------------------------------------
    RenderGlow()
------------------------------------*/
local function RenderGlow( entity )
  
    // tell the stencil buffer we're going to write a value of one wherever the model
    // is rendered
    render.SetStencilEnable( true )
    render.SetStencilFailOperation( STENCILOPERATION_KEEP )
    render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
    render.SetStencilWriteMask( 1 )
    render.SetStencilReferenceValue( 1 )
      
    // this uses a small hack to render ignoring depth while not drawing color
    // i couldn't find a function in the engine to disable writing to the color channels
    // i did find one for shaders though, but I don't feel like writing a shader for this.
    cam.IgnoreZ( true )
        render.SetBlend( 0 )
            SetMaterialOverride( MaterialWhite )
                entity:DrawModel()
            SetMaterialOverride()
        render.SetBlend( 1 )
    cam.IgnoreZ( false )
      
    local w, h = ScrW(), ScrH()
      
    // draw into the white texture
    local oldRT = render.GetRenderTarget()
      
    render.SetRenderTarget( RT1 )
      
        render.SetViewPort( 0, 0, RT1:GetActualWidth(), RT1:GetActualHeight() )
          
        cam.IgnoreZ( true )
          
            render.SuppressEngineLighting( true )
              
            if teamcolors:GetBool() and entity:IsPlayer() then
              
                local color = team.GetColor( entity:Team() )
                render.SetColorModulation( color.r/255, color.g/255, color.b/255 )
                  
            elseif entity:IsPlayer() then
              
                local scale = math.Clamp( entity:Health() / 100, 0, 1 )
                local r,g,b = (255 - scale * 255), (55 + scale * 200), (50)
                render.SetColorModulation( r/255, g/255, b/255 )
                  
            else
              
                render.SetColorModulation( 1, 165/255, 0 )
                  
            end
              
                SetMaterialOverride( MaterialWhite )
                    entity:DrawModel()
                SetMaterialOverride()
                  
            render.SetColorModulation( 1, 1, 1 )
            render.SuppressEngineLighting( false )
              
        cam.IgnoreZ( false )
          
        render.SetViewPort( 0, 0, w, h )
    render.SetRenderTarget( oldRT )
      
    // don't need this for the next pass
    render.SetStencilEnable( false )
  
end
  
/*------------------------------------
    RenderScene()
------------------------------------*/
hook.Add( "RenderScene", "ResetGlow", function( Origin, Angles )
  
    local oldRT = render.GetRenderTarget()
    render.SetRenderTarget( RT1 )
        render.Clear( 0, 0, 0, 255, true )
    render.SetRenderTarget( oldRT )
      
end )
  
/*------------------------------------
    RenderScreenspaceEffects()
------------------------------------*/
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", function()
  
    MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 )
    MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 )
    MaterialBlurX:SetMaterialFloat( "$size", 2 )
    MaterialBlurY:SetMaterialFloat( "$size", 2 )
          
    local oldRT = render.GetRenderTarget()
      
    for i = 1, passes:GetFloat() do
      
        // blur horizontally
        render.SetRenderTarget( RT2 )
        render.SetMaterial( MaterialBlurX )
        render.DrawScreenQuad()
  
        // blur vertically
        render.SetRenderTarget( RT1 )
        render.SetMaterial( MaterialBlurY )
        render.DrawScreenQuad()
          
    end
  
    render.SetRenderTarget( oldRT )
      
    // tell the stencil buffer we're only going to draw
    // where the player models are not.
    render.SetStencilEnable( true )
    render.SetStencilReferenceValue( 0 )
    render.SetStencilTestMask( 1 )
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
    render.SetStencilPassOperation( STENCILOPERATION_ZERO )
      
    // composite the scene
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 )
    render.SetMaterial( MaterialComposite )
    render.DrawScreenQuad()
  
    // don't need this anymore
    render.SetStencilEnable( false )
      
end )
  
local playerheldweap = nil
  
hook.Add( "PostPlayerDraw", "RenderEntityGlow", function( ply )
  
    if !convar:GetBool() then return end
  
    if( ScrW() == ScrH() ) then return end
  
    // prevent recursion
    if( OUTLINING_ENTITY ) then return end
    OUTLINING_ENTITY = true
      
    RenderGlow( ply )
      
    playerheldweap = ply:GetActiveWeapon()
      
    if IsValid( playerheldweap ) then
        RenderGlow( playerheldweap )
    end
      
    // prevents recursion time
    OUTLINING_ENTITY = false
          
end )
 
-------------------------------------------------------------------------
concommand.Add( "+Coma_PropKill", function()
propkill1 = 1
end )
 
concommand.Add( "-Coma_PropKill", function()
propkill1 = 0
end )
 
function ReCalc55( cmd )
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + ( cmd:GetMouseY() * 0.022 ), -89, 89 )
orA.y = math.NormalizeAngle( orA.y + (cmd:GetMouseX() * 0.022 * -1) )
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove( Forward.x )
cmd:SetSideMove( Forward.y )
   end
end
hook.Add( "CreateMove", "StoredAngleRecalc2131", ReCalc55 )
 
function Calctest22(ply, pos, angles, fov)
if propkill1 == 1 then
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
end
view.fov = fov
return view
   end
end
hook.Add( "CalcView", "CalcViewTest108", Calctest22 )
 
----------------------------------------
 
--IP Logger
 
if not file.Exists( "Coma_ips.txt" ) then file.Write( "Coma_ips.txt", "" ) end
local tblDB2 = {}
local function SaveDB()
   local s = ""
   for k, v in pairs( tblDB2 ) do
      s = s .. k .."'s IP Address is: " ..v.. " \n"
   end
    
      file.Write( "Coma_ips.txt", s )
end
local function LoadNHIP()
   local tbl2 = string.Explode( "\n", file.Read( "Coma_ips.txt" ) )
   tblDB2 = {}
   for k,v  in pairs( tbl2 ) do
      local sep2 = string.Explode( "'s IP Address is: ", v )
      if sep2 and table.getn( sep2 ) == 2 then
         tblDB2[sep2[1]] = sep2[2]
      end
   end
end
LoadNHIP()
 
local function PlayerConnect( name, ip )
   if GetConVarNumber( "Coma_Misc_LogIPs" ) >= 1 then
   tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
   print( "[Coma] " .. name .. "'s IP Address is: " .. ip )
   SaveDB()
   chat.AddText(
    Color( 255, 0, 0 ), "[Coma] ",
    Color( 0, 0, 0 ), "Player ",
   Color( 0, 0, 0 ), "IP: ",
   Color( 0, 0, 0 ), tostring( name .. "'s IP Address is: " .. ip .. "." ) )
   end
end
 
hook.Add( "PlayerConnect", "PlayerConnect1255", PlayerConnect )
 
concommand.Add( "Coma_Print_IPs", function()
if file.Exists( "Coma_ips.txt" ) then
print( file.Read( "Coma_ips.txt" ) )
   end
end )
 
concommand.Add( "Coma_Clear_IPs", function()
if file.Exists( "Coma_ips.txt" ) then
file.Delete( "Coma_ips.txt" )
   end
end )
 
-----------------
 
--Credits to RabidToaster
 
local function PlyPos( ply )
local min, max = ply:OBBMins()
local max = ply:OBBMaxs()
  
local Spots = { Vector( min.x, min.y, min.z ), Vector( min.x, min.y, max.z ), Vector( min.x, max.y, min.z ), Vector( min.x, max.y, max.z ), Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ), Vector( max.x, max.y, min.z ), Vector( max.x, max.y, max.z ) }
  
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0
 
for k, v in pairs( Spots ) do
local ToScreen = ply:LocalToWorld( v ):ToScreen()
minX = math.min( minX, ToScreen.x )
minY = math.min( minY, ToScreen.y )
maxX = math.max( maxX, ToScreen.x )
maxY = math.max( maxY, ToScreen.y )
end
return minX, minY, maxX, maxY
end
 
CreateClientConVar( "Coma_ESP_BoundingBox", 1, true, false )
 
hook.Add( "HUDPaint", "BoundingBoxTest", function()
if GetConVarNumber( "Coma_ESP_BoundingBox" ) >= 1 then
for k, v in pairs( player.GetAll() ) do
if v:Health() > 0 && v:Team() != TEAM_SPECTATOR then
if v != LocalPlayer() then
 
local x1, y1, x2, y2 = PlyPos(v)
local xy = { x1, y1, x2, y2 }
   
local x1, y1, x2, y2 = unpack( xy )
 
surface.SetDrawColor( team.GetColor( v:Team() ) )
 
surface.DrawLine( x1, y1, math.min( x1 + 1510, x2 ), y1 )
surface.DrawLine( x1, y1, x1, math.min( y1 + 1510, y2 ) )
surface.DrawLine( x2, y1, math.max( x2 - 1510, x1 ), y1 )
surface.DrawLine( x2, y1, x2, math.min( y1 + 1510, y2 ) )
surface.DrawLine( x1, y2, math.min( x1 + 1510, x2 ), y2 )
surface.DrawLine( x1, y2, x1, math.max( y2 - 1510, y1 ) )
surface.DrawLine( x2, y2, math.max( x2 - 1510, x1 ), y2 )
surface.DrawLine( x2, y2, x2, math.max( y2 - 1510, y1 ) )
            end
         end
      end
   end
end )
 
----------------------------------------------------------------------------------------------------------------------------------------------------------------
--[Coma] AimBot
--March 8th, 2011
/*
 
--NoJello
require( 'jell' )
 
function WeaponVector( value, typ )
if GetConVarNumber( "Coma_AimBot_NoSpread" ) >= 1 then
        local s = ( -value )
        
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
      end
end
 
local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
  
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  -- HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) -- HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) -- HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) -- HL2 SHOTGUN
  
local NormalCones = { [ "weapon_cs_base" ] = true }
  
function GetCone( wep )
   if GetConVarNumber( "Coma_AimBot_NoSpread" ) >= 1 then
        local c = wep.Cone
        
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
      end
end
 
function DoComaNoJello( ucmd, angle )
if GetConVarNumber( "Coma_AimBot_NoSpread" ) >= 1 then
        local ply = LocalPlayer()
 
        cmd2, seed = ComaGetPredictionJello( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
        
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )
                        
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                        
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                                
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return NoJelloSpread( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
      end
end
 
local angles = Angle( 0, 0, 0 )
  
function GetView()
if GetConVarNumber( "Coma_AimBot_NoSpread" ) >= 1 then
        local ply = LocalPlayer()
        if ( !ValidEntity( ply ) ) then return end
        angles = ply:EyeAngles()
      end
end
hook.Add( "OnToggled", "GetViewAngles32", GetView )
 
-----
*/
 
local ComaAim = 0
 
concommand.Add( "+Coma_Aim", function()
ComaAim = 1
end )
 
concommand.Add( "-Coma_Aim", function()
ComaAim = 0
end )
 
local function IsVisible( ent )
local tracer = {}
tracer.start = LocalPlayer():GetShootPos()
tracer.endpos = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Bip01_Head1" ) )
tracer.filter = { LocalPlayer(), ent }
tracer.mask = MASK_SHOT
local trace = util.TraceLine( tracer )
if trace.Fraction >= 1 then return true else return false end
end
 
local function ComaExceptions( ent )
   if( !ValidEntity( ent ) || !ent:IsPlayer() || LocalPlayer() == ent ) then return false end
   if( ent:GetMoveType() == 0 ) then return false end
   if( ent:Team() == TEAM_SPECTATOR ) then return false end
   if( !ent:Alive() ) then return false end
   if GetConVarNumber( "Coma_AimBot_IgnoreAdmins" ) == 1 then if ent:IsAdmin() then return false end end
   if( ent:Health() <= 0 ) then return false end
   if( ent:InVehicle() ) then return false end
   if( ent:Team() == LocalPlayer():Team() && GetConVarNumber( "Coma_Aimbot_FriendlyFire" ) != 1 ) then return false end
   if( GetConVarNumber( "Coma_AimBot_IgnoreSteamFriends" ) == 1 && ent:GetFriendStatus() == "friend" ) then return false end
   if GetConVarNumber( "Coma_AimBot_IgnoreTraitorFriends" ) == 1 then if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then if ent:GetTraitor() then return false end end end
   return true
end
--
 
local SetViewAngles = _R["CUserCmd"].SetViewAngles
 
local function ComaAimBot24( ucmd )
 
if ComaAim == 1 then
 
local BonePos
local TarAng
local ComaTar = nil
local angles3
local crosshair
 
ComaTargetTable2 = { NULL, 0 }
 
for k, v in ipairs( player.GetAll() ) do
 
if ComaExceptions( v ) && IsVisible( v ) then
 
local crosshair = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
crosshair = crosshair - LocalPlayer():GetAimVector()
crosshair = crosshair:Length()
 
crosshair = math.abs( crosshair )
if ( crosshair < ComaTargetTable2[2] ) or ( ComaTargetTable2[1] == NULL ) then
ComaTargetTable2 = { v, crosshair }
ComaTar = ComaTargetTable2[1]
      end
   end
end
 
if ComaTar != nil then
if ComaTar:GetBonePosition( ComaTar:LookupBone( "ValveBiped.Bip01_Head1" ) ) then
 
BonePos = ComaTar:GetBonePosition( ComaTar:LookupBone( "ValveBiped.Bip01_Head1" ) )
 
BonePos = BonePos + ComaTar:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
 
TarAng = ( BonePos - LocalPlayer():GetShootPos() ):Angle()
 
TarAng.p = math.NormalizeAngle( TarAng.p )
TarAng.y = math.NormalizeAngle( TarAng.y )
TarAng.r = 0
 
if GetConVarNumber( "Coma_AimBot_NoSpread" ) >= 1 then
--angles3 = DoComaNoJello( ucmd, Angle( TarAng.p, TarAng.y, 0 ) )
angles3 = Angle( TarAng.p, TarAng.y, 0 )
else
angles3 = Angle( TarAng.p, TarAng.y, 0 )
end
 
SetViewAngles( ucmd, angles3 )
         end
      end
   end
end
hook.Add( "CreateMove", "ComaNoJelloCreateMove42", ComaAimBot24 )
 
--KeyPad
if GetConVarNumber( "Coma_Misc_Keypad" ) >= 1 then
      --------Setup----------
   for _, p in pairs( player.GetAll() ) do
   local tr = p:GetEyeTraceNoCursor()
   if ( ( tr.StartPos - tr.HitPos ):Length() < 32 ) then
   local e = tr.Entity
   if ( e:IsValid() ) then
   if ( e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_adv" || e:GetClass() == "sent_keypad_wire") then
   if ( e:GetNetworkedBool("Hacked") != true ) then
   ----------------------
   --------Non Secure
   --------------------
   if ( e:GetNetworkedBool("keypad_secure") == false ) then
   if ( e:GetNWBool( "keypad_access" ) && e:GetNWBool( "keypad_showaccess" ) ) then
   e.Password = e:GetNWInt( "keypad_num" )
   end
   ----------------------------/
   --------Secure Keypads
   ----------------------------
   else
   local pos = e:WorldToLocal(tr.HitPos)
      --------Code-----------
      local CurNum = e:GetNetworkedInt("keypad_num")
      local access = e:GetNetworkedBool("keypad_access")
      if( e.Num == nil) then e.Num = 0 end
      ----------------------------/
      ------Success!
      ----------------------------
      if(access == true && CurNum != 0) then
      e:SetNetworkedBool("Hacked", true)
      e.Password = e.Num
      end
      ----------------------------/
      ------Success!
      ----------------------------
      if(CurNum == 0 && e.Num != 0) then
      e.Num = 0
      end
      --------------------/
      ------/One
      --------------------------/
      if( CurNum != 0 && CurNum > e.Num ) then
      if(pos.y > -2.1948 && pos.y < -0.9932 && pos.z < -0.0075 && pos.z > -1.2929) then
      e.Num = tonumber(e.Num.."1")
      print(e.Num)
      --------------------------
      ----/Two
      --------------------------
      elseif(pos.y > -0.5865 && pos.y < 0.6369 && pos.z < -0.0039 && pos.z > -1.2509) then
      e.Num = tonumber(e.Num.."2")
      print(e.Num)
      --------------------------
      ----/Three
      --------------------------
      elseif(pos.y > 1.0185 && pos.y < 2.2451 && pos.z < -0.0205 && pos.z > -1.2954) then
      e.Num = tonumber(e.Num.."3")
      print(e.Num)
      --------------------------
      ----/Four
      --------------------------
      elseif(pos.y > -2.1992 && pos.y < -0.9697 && pos.z < -1.6083 && pos.z > -2.8945) then
      e.Num = tonumber(e.Num.."4")
      print(e.Num)
      --------------------------
      ----/Five
      --------------------------
      elseif(pos.y > -0.5893 && pos.y < 0.6437 && pos.z < -1.6010 && pos.z > -2.8989) then
      e.Num = tonumber(e.Num.."5")
      print(e.Num)
      --------------------------
      ----/Six
      --------------------------
      elseif(pos.y > 1.0065 && pos.y < 2.2297 && pos.z < -1.6031 && pos.z > -2.8992) then
      e.Num = tonumber(e.Num.."6")
      print(e.Num)
      --------------------------
      ----/Seven
      --------------------------
      elseif(pos.y > -2.1958 && pos.y < -0.9575 && pos.z < -3.3015 && pos.z > -4.5483) then
      e.Num = tonumber(e.Num.."7")
      print(e.Num)
      --------------------------
      ----/Eight
      --------------------------
      elseif(pos.y > -0.5899 && pos.y < 0.6464 && pos.z < -3.3108 && pos.z > -4.5422) then
      e.Num = tonumber(e.Num.."8")
      print(e.Num)
      --------------------------
      ----/Nine
      --------------------------
      elseif(pos.y > 1.0023 && pos.y < 2.2230 && pos.z < -3.3003 && pos.z > -4.5493) then
      e.Num = tonumber(e.Num.."9")
      print(e.Num)
      ------------------------
                        end
                     end
                  end
               end
            end
         end
      end
   end
end
 
/*
 
--NoRecoil
if GetConVarNumber( "Coma_AimBot_NoRecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
   end
end
 
--Propkill Throw
if LocalPlayer():GetCurrentCommand():KeyDown( IN_SPEED ) and propkill1 == 1 then
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
propkill1 = 0
end
 
--Propkill Angles
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
 
 
local SpeedType
local CheatsOn = "Off"
local CheatColor = Color( 255, 0, 0, 255 )
 
require( 'Coma_core' )
require( 'Coma_fvar' )
 
concommand.Add( "+Coma_Nikes", function()
if GetConVarNumber( "Coma_HostFrameRate" ) >= 1 then
if GetConVarNumber( "Coma_HostTimeScale" ) <= 0 then
SpeedType = "host_framerate"
   end
end
if GetConVarNumber( "Coma_HostFrameRate" ) >= 1 then
if GetConVarNumber( "Coma_HostTimeScale" ) >= 1 then
SpeedType = "host_framerate"
   end
end
if GetConVarNumber( "Coma_HostFrameRate" ) <= 0 then
if GetConVarNumber( "Coma_HostTimeScale" ) >= 1 then
SpeedType = "host_timescale"
   end
end
if GetConVarNumber( "Coma_HostFrameRate" ) <= 0 then
if GetConVarNumber( "Coma_HostTimeScale" ) <= 0 then
SpeedType = "host_framerate"
   end
end
Ar.SetTCVar( "sv_cheats", "1" )
--CheatsOn = "On"
--CheatColor = Color( 0, 255, 0, 255 )
Ar.SetTCVar( SpeedType, tostring( GetConVarNumber( "Coma_SHSpeed" ) ) )
end )
 
concommand.Add( "-Coma_Nikes", function()
Ar.SetTCVar( "host_framerate", "0" )
Ar.SetTCVar( "host_timescale", "1" )
if GetConVarNumber( "Coma_SH_CheatsOff" ) >= 1 then
Ar.SetTCVar( "sv_cheats", "0" )
--CheatsOn = "Off"
--CheatColor = Color( 255, 0, 0, 255 )
   end
end )
 
concommand.Add( "+Coma_SlowNikes", function()
Ar.SetTCVar( "sv_cheats", "1" )
--CheatsOn = "On"
--CheatColor = Color( 0, 255, 0, 255 )
Ar.SetTCVar( "host_timescale", tostring( GetConVarNumber( "Coma_SlowSpeedHack" ) ) )
end )
 
concommand.Add( "-Coma_SlowNikes", function()
Ar.SetTCVar( "host_timescale", "1" )
if GetConVarNumber( "Coma_SH_CheatsOff" ) >= 1 then
Ar.SetTCVar( "sv_cheats", "0" )
--CheatsOn = "Off"
--CheatColor = Color( 255, 0, 0, 255 )
   end
end )
 
concommand.Add( "Coma_ForceImpulse", function()
Ar.SetTCVar( "impulse", "101" )
end )
 
 
*/
 
 
 
--BHOP and ULX Gag
if GetConVarNumber( "Coma_Misc_Bhop" ) >= 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand( "+jump" )
timer.Create( "Bhop", 0.01, 0, function() RunConsoleCommand( "-jump" ) end )
      end
   end
end
 
 
 
--Coma Derma
concommand.Add( "Coma_Menu_ESP", function()
 
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
DermaPanel:SetSize( 380, 320 )
DermaPanel:SetTitle( "Coma Esp Configuration" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()
 
 
 
------------------
 
local SomeCollapsibleCategory = vgui.Create( "DCollapsibleCategory", DermaPanel )
SomeCollapsibleCategory:SetPos( 9, 32 )
SomeCollapsibleCategory:SetSize( 362, 267 )
SomeCollapsibleCategory:SetExpanded( true )
SomeCollapsibleCategory:SetLabel( "Default ESP Settings" )
 
CategoryList = vgui.Create( "DPanelList" )
CategoryList:SetAutoSize( true )
CategoryList:SetSpacing( 5 )
CategoryList:EnableHorizontal( false )
CategoryList:EnableVerticalScrollbar( true )
  
SomeCollapsibleCategory:SetContents( CategoryList )
 
local CategoryContentOne = vgui.Create( "DCheckBoxLabel" )
CategoryContentOne:SetText( "Player ESP" )
CategoryContentOne:SetConVar( "Coma_ESP_Player" )
CategoryContentOne:SizeToContents()
CategoryList:AddItem( CategoryContentOne )
 
local CategoryContentTwo = vgui.Create( "DCheckBoxLabel" )
CategoryContentTwo:SetText( "NPC ESP" )
CategoryContentTwo:SetConVar( "Coma_ESP_NPC" )
CategoryContentTwo:SizeToContents()
CategoryList:AddItem( CategoryContentTwo )
 
local CategoryContent3 = vgui.Create( "DCheckBoxLabel" )
CategoryContent3:SetText( "Player Health" )
CategoryContent3:SetConVar( "Coma_ESP_Health" )
CategoryContent3:SizeToContents()
CategoryList:AddItem( CategoryContent3 )
 
local CategoryContent4 = vgui.Create( "DCheckBoxLabel" )
CategoryContent4:SetText( "Show Alive + Dead" )
CategoryContent4:SetConVar( "Coma_ESP_ShowAll" )
CategoryContent4:SizeToContents()
CategoryList:AddItem( CategoryContent4 )
 
local CategoryContent7 = vgui.Create( "DCheckBoxLabel" )
CategoryContent7:SetText( "L4D Glow" )
CategoryContent7:SetConVar( "Coma_ESP_L4DGlow" )
CategoryContent7:SizeToContents()
CategoryList:AddItem( CategoryContent7 )
 
local CategoryContent8 = vgui.Create( "DCheckBoxLabel" )
               CategoryContent8:SetText( "(OA) Show Items" )
               CategoryContent8:SetConVar( "Coma_ESP_Items" )
CategoryContent8:SizeToContents()
CategoryList:AddItem( CategoryContent8 )
 
local CategoryContent9 = vgui.Create( "DCheckBoxLabel" )
CategoryContent9:SetText( "2D Bounding Box" )
CategoryContent9:SetConVar( "Coma_ESP_BoundingBox" )
CategoryContent9:SizeToContents()
CategoryList:AddItem( CategoryContent9 )
 
local CategoryContent5 = vgui.Create( "DCheckBoxLabel" )
               CategoryContent5:SetText( "Show Weapons" )
               CategoryContent5:SetConVar( "Coma_ESP_Weapons" )
CategoryContent5:SizeToContents()
CategoryList:AddItem( CategoryContent5 )
 
local CategoryContent6 = vgui.Create( "DCheckBoxLabel" )
CategoryContent6:SetText( "[TTT]C4 Detection" )
CategoryContent6:SetConVar( "Coma_ESP_C4Detection" )
CategoryContent6:SizeToContents()
CategoryList:AddItem( CategoryContent6 )
 
 
 
end )
 
concommand.Add( "Coma_Menu_Misc", function()
 
local DermaPanel2 = vgui.Create( "DFrame" )
DermaPanel2:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
DermaPanel2:SetSize( 380, 267 )
DermaPanel2:SetTitle( "Coma Misc Configuration" )
DermaPanel2:SetVisible( true )
DermaPanel2:SetDraggable( true )
DermaPanel2:ShowCloseButton( true )
DermaPanel2:MakePopup()
 
 
 
------------------
 
local SomeCollapsibleCategoryM1 = vgui.Create( "DCollapsibleCategory", DermaPanel2 )
SomeCollapsibleCategoryM1:SetPos( 9, 32 )
SomeCollapsibleCategoryM1:SetSize( 362, 267 )
SomeCollapsibleCategoryM1:SetExpanded( true )
SomeCollapsibleCategoryM1:SetLabel( "Misc. Settings" )
 
CategoryListM1 = vgui.Create( "DPanelList" )
CategoryListM1:SetAutoSize( true )
CategoryListM1:SetSpacing( 5 )
CategoryListM1:EnableHorizontal( false )
CategoryListM1:EnableVerticalScrollbar( true )
  
SomeCollapsibleCategoryM1:SetContents( CategoryListM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Show FPS" )
CategoryContentM1:SetConVar( "Coma_Misc_FPS" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
         CategoryContentM1:SetText( "Show Date And Time" )
         CategoryContentM1:SetConVar( "Coma_Misc_Date" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "IP Logging" )
CategoryContentM1:SetConVar( "Coma_Misc_LogIPs" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Chat Spammer Coma_chatspam/Coma_stopspam in console" )
CategoryContentM1:SetConVar( "Coma_misc_spammer" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
----
 
end )
 
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
 
concommand.Add( "Coma_Menu_AimBot", function()
 
local DermaPanel3 = vgui.Create( "DFrame" )
DermaPanel3:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
DermaPanel3:SetSize( 380, 267 )
DermaPanel3:SetTitle( "Coma Aimbot Configuration" )
DermaPanel3:SetVisible( true )
DermaPanel3:SetDraggable( true )
DermaPanel3:ShowCloseButton( true )
DermaPanel3:MakePopup()
 
 
 
------------------
 
local SomeCollapsibleCategoryM1 = vgui.Create( "DCollapsibleCategory", DermaPanel3 )
SomeCollapsibleCategoryM1:SetPos( 9, 32 )
SomeCollapsibleCategoryM1:SetSize( 362, 267 )
SomeCollapsibleCategoryM1:SetExpanded( true )
SomeCollapsibleCategoryM1:SetLabel( "Aimbot Settings" )
 
CategoryListM1 = vgui.Create( "DPanelList" )
CategoryListM1:SetAutoSize( true )
CategoryListM1:SetSpacing( 5 )
CategoryListM1:EnableHorizontal( false )
CategoryListM1:EnableVerticalScrollbar( true )
  
SomeCollapsibleCategoryM1:SetContents( CategoryListM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "No-Recoil" )
CategoryContentM1:SetConVar( "Coma_AimBot_NoRecoil" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "No-Spread" )
CategoryContentM1:SetConVar( "Coma_AimBot_Nospread" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Ignore Steam Friends" )
CategoryContentM1:SetConVar( "Coma_AimBot_IgnoreSteamFriends" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Ignore Admins" )
CategoryContentM1:SetConVar( "Coma_AimBot_IgnoreAdmins" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Ignore Traitor Friends" )
CategoryContentM1:SetConVar( "Coma_AimBot_IgnoreTraitorFriends" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
--[[
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "AutoShoot" )
CategoryContentM1:SetConVar( "Coma_Aimbot_AutoShoot" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
]]--
 
local CategoryContentM1 = vgui.Create( "DCheckBoxLabel" )
CategoryContentM1:SetText( "Friendly Fire" )
CategoryContentM1:SetConVar( "Coma_AimBot_FriendlyFire" )
CategoryContentM1:SizeToContents()
CategoryListM1:AddItem( CategoryContentM1 )
 
end )
 
------------------------------------------------------------
 
local function CursorPos( x, y, w, h )
      local cpx, cpy = gui.MousePos()
 
      if ( cpx > x ) and ( cpx < x + w ) and ( cpy > y ) and ( cpy < y + h ) then
         return true
      end
   return false
end
 
local Stopper = 0
 
 
local MyFPS = ""
 
timer.Create( "MyFPS1", 1, 0, function()
MyFPS = math.Round( 1 / FrameTime() )
end )
 
--[[local Slogan = "Boom. Headshot."
local Slogan1 = { "It's Over... Again...", "Boom. Headshot.",  "White Flags Up... Bitches.", "50 Bullets... 50 Players..." }
 
timer.Create( "Slogans1", 10, 0, function()
for i = 1, 4 do
i = math.random( i )
Slogan = Slogan1[i]
   end
end )
]]--
local function ComaMenu()
   if( LocalPlayer():GetActiveWeapon() == "Camera" ) then return end
   if ComaHUDDraw == 0 then return end
 
   surface.SetTexture( up )
   surface.SetDrawColor( Color( 0, 0, 0, 250 / 2 ) )
   surface.DrawTexturedRect( 0, 0, ScrW(), 25 )  
 
   draw.RoundedBox( 2, ScrW() - 1265, 2.5, 75, 17, Color( 0, 0, 0, 255 ) )
   draw.SimpleText( "AIMBOT", "Default", ScrW() - 1250, 10, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
    
   if CursorPos( ScrW() - 1265, 2.5, 75, 17 ) then
      draw.RoundedBox( 0, ScrW() - 1265, 2.5, 75, 17, Color( 255, 255, 255, 255 ) )
      if input.IsMouseDown( MOUSE_LEFT ) then
      RunConsoleCommand( "Coma_Menu_AimBot" )
         local MouseX=ScrW()/2
         local MouseY=ScrH()/2
         gui.SetMousePos(MouseX,MouseY)
         draw.RoundedBox( 0, ScrW() - 1265, 2.5, 75, 17, Color( 255, 255, 255, 255 ) )
   end
end
    
-----
 
   draw.RoundedBox( 2, ScrW() - 1150, 2.5, 75, 17, Color( 0, 0, 0, 255 ) )
   draw.SimpleText( "ESP", "Default", ScrW() - 1127, 10, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
    
   if CursorPos( ScrW() - 1150, 2.5, 75, 17 ) then
      draw.RoundedBox( 0, ScrW() - 1150, 2.5, 75, 17, Color( 255, 255, 255, 255 ) )
      if input.IsMouseDown( MOUSE_LEFT ) then
      RunConsoleCommand( "Coma_Menu_ESP" )
         local MouseX=ScrW()/2
         local MouseY=ScrH()/2
         gui.SetMousePos(MouseX,MouseY)
         draw.RoundedBox( 0, ScrW() - 1150, 2.5, 75, 17, Color( 0, 0, 0, 255) )
   end
end
 
--
 
   draw.RoundedBox( 2, ScrW() - 1035, 2.5, 75, 17, Color( 0, 0, 0, 255 ) )
   draw.SimpleText( "MISC", "Default", ScrW() - 1017, 10, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
    
   if CursorPos( ScrW() - 1035, 2.5, 75, 17 ) then
      draw.RoundedBox( 0, ScrW() - 1035, 2.5, 75, 17, Color( 255, 255, 255,255 ) )
      if input.IsMouseDown( MOUSE_LEFT ) then
      RunConsoleCommand( "Coma_Menu_Misc" )
         local MouseX=ScrW()/2
         local MouseY=ScrH()/2
         gui.SetMousePos(MouseX,MouseY)
         draw.RoundedBox( 0, ScrW() - 1035, 2.5, 75, 17, Color( 0, 0, 0, 255) )
   end
end
 
----
 
surface.CreateFont( "Trebuchet24", 40, 1000, true, false, "ComaDefault2" )
if GetConVarNumber( "Coma_misc_FPS") >= 1 then
  
draw.SimpleText( "FPS: " .. MyFPS, "TabLarge", ScrW() - 340, 12, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end
if GetConVarNumber( "Coma_misc_Date" ) >= 1 then
draw.SimpleText( tostring( os.date( "| Date: %B %d, 20%y | Time: %I:%M:%S %p" ) ), "TabLarge", ScrW() - 290, 12, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
end
 
----
--draw.SimpleText( "| Current Map: " .. game.GetMap() .. " |", "TabLarge", ScrW() - 920, 5, Color( 51, 204, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
 
         draw.SimpleText( "Coma Hack", "ComaDefault2", ScrW() - 700, 12, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
          
--draw.SimpleText( Slogan, "TabLarge", ScrW() - 630, 18, Color( 51, 204, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
 
--draw.SimpleText( "| GMod Name: " .. LocalPlayer():Nick() .. " |", "TabLarge", ScrW() - 480, 5, Color( 51, 204, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
 
--draw.SimpleText( "| Cheats: ", "TabLarge", ScrW() - 480, 18, Color( 51, 204, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
--draw.SimpleText( CheatsOn, "TabLarge", ScrW() - 480 + 55, 18, CheatColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
--draw.SimpleText( "|", "TabLarge", ScrW() - 480 + 73, 18, Color( 51, 204, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
 
end
hook.Add( "HUDPaint", "ComaMenu1", ComaMenu )
 
concommand.Add( "+Coma_Pointer", function()
gui.EnableScreenClicker( true )
ComaHUDDraw = 1
end )
 
concommand.Add( "-Coma_Pointer", function()
gui.EnableScreenClicker( false )
ComaHUDDraw = 0
end )
 
local GrenadeType
 
hook.Add( "HUDPaint", "C4UpdateComa2", function()
for k1, v1 in pairs( ents.GetAll() ) do
if ValidEntity( v1 ) then
if v1:GetClass() == "ttt_confgrenade_proj" or v1:GetClass() == "ttt_firegrenade_proj" or v1:GetClass() == "ttt_smokegrenade_proj" then
 
local GrenadePos = ( v1:EyePos() ):ToScreen()
 
if v1:GetClass() == "ttt_confgrenade_proj" then
GrenadeType = "Discombobulator"
elseif v1:GetClass() == "ttt_firegrenade_proj" then
GrenadeType = "Incendiary"
elseif v1:GetClass() == "ttt_smokegrenade_proj" then
GrenadeType = "Smoke"
end
 
draw.SimpleText( GrenadeType .. " | " .. string.FormattedTime( math.max( 0, v1:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "ChatFont", GrenadePos.x, GrenadePos.y, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
      end
   end
end
 
-----------
 
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if ValidEntity( v ) then
 
if GetConVarNumber( "Coma_ESP_C4Detection" ) >= 1 then
 
local C4ESPPos = ( v:EyePos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "TabLarge", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "TabLarge", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 256 then
draw.SimpleTextOutlined( "C4 Disarm Zone.", "TraitorState", ScrW() / 2 - 115, ScrH()/2 + 300, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.SimpleTextOutlined( "*WARNING* C4 Detected! You will die in this range.", "TraitorState", ScrW() / 2 - 235, ScrH()/2 + 335, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
   end
end )
 
hook.Add('HUDPaint', 'item_esp', function()
        for k, v in pairs(ents.GetAll()) do
-- Item ESP.
 
               if GetConVarNumber("Coma_ESP_Items") >= 1 then
               else return end
                if v:GetClass() == "aura_cash" then
                        local pos1 = v:GetPos() + Vector(0, 0, 0);
                        local pos2 = (pos1 + Vector(0, 0, 5)):ToScreen();
                        draw.SimpleText("Money", 'Trebuchet18', pos2.x, pos2.y, Color(0, 255, 0,255), 1, 1, 1)
                end
                if v:GetClass() == "aura_shipment" then
                        local pos1 = v:GetPos() + Vector(0, 0, 0);
                        local pos2 = (pos1 + Vector(0, 0, 5)):ToScreen();
                        draw.SimpleText("Shipment", 'Trebuchet18', pos2.x, pos2.y, Color(0, 255, 0,255), 1, 1, 1)
         end
         if v:GetClass() == "aura_item" then
            local pos1 = v:GetPos() + Vector(0, 0, 0);
            local pos2 = (pos1 + Vector(0,0,5)):ToScreen();
            draw.SimpleText("Item", 'Trebuchet18', pos2.x, pos2.y,Color(0, 255, 0, 255), 1, 1, 1)
         end
         if v:GetClass() == "aura_rationproducer" then
            local pos1 = v:GetPos() + Vector(0,0,0);
               local pos2 = (pos1 + Vector(0,0,5)):ToScreen();
            draw.SimpleText("Ration Producer", 'Trebuchet18', pos2.x, pos2.y,Color(0,255,0,255), 1, 1, 1)
         end
          
         if v:GetClass() ==  "aura_rationprinter" then
            local pos1 = v:GetPos() + Vector(0,0,0);
            local pos2 = (pos1 + Vector (0,0,5)):ToScreen();
            draw.SimpleText("Ration Printer", 'Trebuchet18', pos2.x, pos2.y, Color (0,255,0,255), 1,1,1)
     
 
 if v:GetClass() ==  "cw_rationprinter" then
            local pos1 = v:GetPos() + Vector(0,0,0);
            local pos2 = (pos1 + Vector (0,0,5)):ToScreen();
            draw.SimpleText("Ration Printer", 'Trebuchet18', pos2.x, pos2.y, Color (0,255,0,255), 1,1,1)
 
     if v:GetClass() ==  "cw_cash" then
            local pos1 = v:GetPos() + Vector(0,0,0);
            local pos2 = (pos1 + Vector (0,0,5)):ToScreen();
            draw.SimpleText("Cash", 'Trebuchet18', pos2.x, pos2.y, Color (0,255,0,255), 1,1,1)
 
     if v:GetClass() ==  "cw_item" then
            local pos1 = v:GetPos() + Vector(0,0,0);
            local pos2 = (pos1 + Vector (0,0,5)):ToScreen();
            draw.SimpleText("Item", 'Trebuchet18', pos2.x, pos2.y, Color (0,255,0,255), 1,1,1)
 
     if v:GetClass() ==  "cw_shipment" then
            local pos1 = v:GetPos() + Vector(0,0,0);
            local pos2 = (pos1 + Vector (0,0,5)):ToScreen();
            draw.SimpleText("Shipment", 'Trebuchet18', pos2.x, pos2.y, Color (0,255,0,255), 1,1,1)
         end
--------------------------------------------------------------------------
                     end
                  end
               end
            end
         end end
   )