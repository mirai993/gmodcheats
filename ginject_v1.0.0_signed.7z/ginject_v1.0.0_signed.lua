--[[
	lua/GInject.lua
	frist | (STEAM_0:0:30912535)
	===DStream===
]]

// sethhack copypasta #43324528
// ginject fresh copypaste by yuuki

if SERVER then return end

local g = table.Copy(_G)
local GI = {}
GI.version = "1" 

function GI:StartScript() 
	GI.conopen = false 
	GI.menuopen = false 
	GI.nextreload = g.CurTime() 
	GI.curtarg = nil 
	GI.meta = g.FindMetaTable("Player") 
	GI.typing = false 
	GI.adminl = {} 
	GI.espents = {} 
	GI.log = {} 
	GI.configs = {} 
	GI.esppress = false 
	GI.enumlist = { 
		[1] = {char = "a", val = KEY_A},
		[2] = {char = "b", val = KEY_B},
		[3] = {char = "c", val = KEY_C},
		[4] = {char = "d", val = KEY_D},
		[5] = {char = "e", val = KEY_E},
		[6] = {char = "f", val = KEY_F},
		[7] = {char = "g", val = KEY_G},
		[8] = {char = "h", val = KEY_H},
		[9] = {char = "i", val = KEY_I},
		[10] = {char = "j", val = KEY_J},
		[11] = {char = "k", val = KEY_K},
		[12] = {char = "l", val = KEY_L},
		[13] = {char = "m", val = KEY_M},
		[14] = {char = "n", val = KEY_N},
		[15] = {char = "o", val = KEY_O},
		[16] = {char = "p", val = KEY_P},
		[17] = {char = "q", val = KEY_Q},
		[18] = {char = "r", val = KEY_R},
		[19] = {char = "s", val = KEY_S},
		[20] = {char = "t", val = KEY_T},
		[21] = {char = "u", val = KEY_U},
		[22] = {char = "v", val = KEY_V},
		[23] = {char = "w", val = KEY_W},
		[24] = {char = "x", val = KEY_X},
		[25] = {char = "y", val = KEY_Y},
		[26] = {char = "z", val = KEY_Z},
		[27] = {char = "space", val = KEY_SPACE},
		[28] = {char = "tab", val = KEY_TAB},
		[29] = {char = "lshift", val = KEY_LSHIFT},
		[30] = {char = "rshift", val = KEY_RSHIFT},
		[31] = {char = "lalt", val = KEY_LALT},
		[32] = {char = "ralt", val = KEY_RALT},
		[33] = {char = ",", val = KEY_COMMA},
		[34] = {char = ".", val = KEY_PERIOD},
		[35] = {char = "/", val = KEY_SLASH},
		[36] = {char = "[", val = KEY_LBRACKET},
		[37] = {char = ";", val = KEY_SEMICOLON},
		[38] = {char = "'", val = KEY_APOSTROPHE}, 
	} 
	GI.binds = { 
		["+aim"] = KEY_Z,
		["+menu"] = KEY_B,
		["+triggerbot"] = KEY_T,
		["esp_toggle"] = KEY_M,
		["+bhop"] = KEY_SPACE, 
	} GI.bools = { 
		["aimactive"] = true,
		["aimteam"] = false,
		["aimlos"] = false,
		["aimautoshoot"] = false,
		["aimautoreload"] = false,
		["targetbonehead"] = true,
		["targetnpc"] = false,
		["targetplayer"] = true,
		["targetent"] = false,
		["checklos"] = true,
		["triggeractive"] = true,
		["aimantisnap"] = true,
		["espactive"] = true,
		["espchams"] = true,
		["espplayers"] = true,
		["espnpcs"] = false,
		["espents"] = false,
		["espwireframe"] = false,
		["espsolid"] = true,
		["norecoil"] = false,
		["esphealth"] = true,
		["esparmor"] = true,
		["espteam"] = true,
		["espadmin"] = true,
		["espweapon"] = true,
		["miscbhop"] = true,
		["misclognet"] = true,
		["misclogrcc"] = true,
		["miscblock"] = false,
		["miscprint"] = false,
	} 
	GI.vars = { 
		["aimx"] = 7,
		["aimy"] = 1,
		["aimz"] = 61,
		["aimfov"] = 45,
		["aimdistance"] = 5000,
		["aimantisnap"] = 0.2,
		["espchamdist"] = 2000,
		["esptextdist"] = 15000, 
	} 
	g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand) 
	g.rawset(_G, "GetConVar", oGetConVar) 
	
	local onet = net 
	local ofile = file 
	local ofopen = file.Open 
	file = nil 
	net = nil 
	hook = nil RunConsoleCommand = nil 
	
	g.setmetatable(_G, 
		{ 
			__index = function(t , k) 
				if(k == "RunConsoleCommand") then 
					return oRunConsoleCommand 
				end 
				if(k == "net") then 
					return g.net 
				end 
				if(k == "hook") then 
					return g.hook 
				end 
				if(k == "GetConVar") then 
					return oGetConVar 
				end 
				if(k == "file") then 
					return ofile end 
				end, 
				__metatable = true, 
			}
		) 
		
		GI.StartChat = GAMEMODE.StartChat 
		function GAMEMODE:StartChat() 
			GI.StartChat() 
			GI.typing = true 
		end 
		GI.FinishChat = GAMEMODE.FinishChat 
		function GAMEMODE:FinishChat() 
			GI.FinishChat() 
			GI.typing = false 
		end 
		local function oldWrite(name, contents)
			local f = ofopen( name, "w", "DATA" ) 
			if ( !f ) then return end 
			f:Write( contents ) 
			f:Close() 
		end 
		local function oldRead(name) 
			local f = ofopen( name, "r", "DATA" ) 
			if ( !f ) then return end 
			local str = f:Read( f:Size() ) 
			f:Close() 
			if ( !str ) then str = "" end 
			return str 
		end 
		function GI:SaveConfig(cfgname) 
			local tabletosave = {} 
			tabletosave.vars = GI.vars 
			tabletosave.bools = GI.bools 
			tabletosave.binds = GI.binds 
			tabletosave.espents = GI.espents 
			g.file.Delete("ginject/"..cfgname..".txt") 
			oldWrite("ginject/"..cfgname..".txt", g.util.TableToJSON(tabletosave)) 
		end 
		function GI:LoadConfig(cfgname) 
			cfgname = g.string.lower(cfgname) 
			if g.file.Exists("ginject/"..cfgname..".txt", "DATA") then 
				local tabletoload = g.util.JSONToTable(oldRead("ginject/"..cfgname..".txt")) 
				GI.vars = tabletoload.vars 
				GI.bools = tabletoload.bools 
				GI.binds = tabletoload.binds 
				GI.espents = tabletoload.espents 
			end 
		end 
		function GI:DeleteConfig(cfgname) 
			cfgname = g.string.lower(cfgname) 
			if g.file.Exists("ginject/"..cfgname..".txt", "DATA") then 
				g.file.Delete("ginject/"..cfgname..".txt") 
			end 
		end 
		function GI:GetConfigs() 
			local files = g.file.Find("ginject/*.txt", "DATA") 
			for k,v in g.ipairs(files) do 
				files[k] = g.string.Replace(v,".txt","") 
			end 
			return files 
		end 
		
		if !g.file.Exists("ginject", "DATA") then 
			print("file not exists") 
			g.file.CreateDir("ginject") 
			GI:SaveConfig("default") 
		else 
			GI:LoadConfig("default") 
		end 
		GI.configs = GI:GetConfigs() 
		function GI:LogAction(Action) 
			g.table.insert(GI.log, Action) 
			if GI.bools["miscprint"] then 
				g.MsgC(g.Color(255,165,0), Action.."\n") 
			end 
		end 
		function ofile.Exists(name, path) 
			GI:LogAction("file.Exists: "..name.." "..path) 
			if string.find(string.lower(name), "ginject") != nil then 
				return nil 
			else 
				return g.file.Exists(name, path) 
			end 
		end 
		function ofile.Size(name, path) 
			GI:LogAction("file.Size: "..name.." "..path) 
			if string.find(string.lower(name), "ginject") != nil then 
				return nil 
			else 
				return g.file.Size(name, path) 
			end 
		end 
		function ofile.Time(name, path) 
			GI:LogAction("file.Time: "..name.." "..path) 
			if string.find(string.lower(name), "ginject") != nil then 
				return nil 
			else 
				return g.file.Time(name, path) 
			end 
		end 
		function ofile.Open(name, filemode, path) 
			GI:LogAction("file.Open: "..name.." "..filemode.." "..path) 
			if string.find(string.lower(name), "ginject") != nil then
				return nil 
			else
				return g.file.Open(name, filemode, path) 
			end 
		end 
		function ofile.IsDir(name, path) 
			GI:LogAction("file.IsDir: "..name.." "..path) 
			if string.find(string.lower(name), "ginject") != nil then
				return nil 
			else 
				return g.file.IsDir(name, path) 
			end 
		end 
		function ofile.Find(name, path, sorting) 
			if sorting == nil then 
				sorting = "namedesc" 
			end 
			GI:LogAction("file.Find: "..name.." "..path.." "..sorting) 
			if string.find(string.lower(name), "ginject") != nil then 
				return nil 
			else 
				return g.file.Find(name, path, namedesc)
			end 
		end
		function ofile.Append(name, content) 
			GI:LogAction("file.Append: "..name.." "..content) 
			if string.find(string.lower(name), "ginject") == nil then
				return g.file.Append(name, content) 
			end 
		end 
	function ofile.Read(name, path) 
		GI:LogAction("file.Read: "..name.." "..path) 
		if string.find(string.lower(name), "ginject") != nil then
			return nil 
		else 
			return g.file.Read(name, content) 
		end 
	end 
	function ofile.Write(name, content) 
		GI:LogAction("file.Write: "..name..", "..content)
		if string.find(string.lower(name), "ginject") != nil then 
			return nil else return g.file.Write(name, content) 
		end 
	end 
	function g.net.Start(name) 
		GI:LogAction("NET.START: "..name) 
		if GI.bools["miscprint"] then 
			g.MsgC(g.Color(255,165,0),"NET.START: "..name.."\n") 
		end 
		if !GI.bools["miscblock"] then 
			return onet.Start(name) 
		end 
	end 
	function g.net.SendToServer() 
		GI:LogAction("NET.SENDTOSERVER()") 
		if GI.bools["miscprint"] then 
			g.MsgC(g.Color(255,165,0),"NET.SENDTOSERVER()\n") 
		end 
		if !GI.bools["miscblock"] then 
			return onet.SendToServer()
		end 
	end 
	function g.net.Receive( messageName, callback ) 
		GI:LogAction("NET.RECEIVE: "..messageName.."") 
		if GI.bools["miscprint"] then 
			g.MsgC(g.Color(255,165,0),"NET.RECEIVE: ["..messageName.."] ["..callback.."]\n") 
		end 
		return onet.Receive(messageName, callback) 
	end 
	local oConCommand = GI.meta.ConCommand 
	function GI.meta.ConCommand(ply, cmd) 
		GI:LogAction("CONCOMMAND: ["..ply:Nick().."] ["..cmd.."]") 
		if GI.bools["miscprint"] then 
			g.MsgC(g.Color(255,165,0), "CONCOMMAND: ["..ply:Nick().."] ["..cmd.."]\n") 
		end 
		return oConCommand(ply, cmd) 
	end 
	function oGetConVar(convar) 
		GI:LogAction("GetConVar("..convar..")") 
		return g.GetConVar(convar) 
	end 
	function oRunConsoleCommand(cmd, ...) 
		local dontlog = { "+jump", "-jump", "+attack", "-attack", "impulse" } 
		if !g.table.HasValue(dontlog, cmd) then 
			local str = cmd 
			if ... then 
				local tolog = {...} 
				str = str..", "..(...) 
				GI:LogAction("RunConsoleCommand("..cmd..", "..g.table.concat(tolog, ", ")..")") 
			end 
			if GI.bools["miscblock"] && !g.table.HasValue(dontlog, cmd) then 
				if GI.bools["miscprint"] then
					g.MsgC(g.Color(255,0,0), "RCC Blocked\n") 
				end 
				return ""
			end 
		end 
		return g.RunConsoleCommand(cmd, ...) 
	end 
	
	g.timer.Create(g.tostring(g.math.random(1000)), 1, 0, function()
		for _,v in g.pairs(g.player.GetAll()) do 
			if v:IsAdmin() && !g.table.HasValue(GI.adminl, v) then 
				g.table.insert(GI.adminl, v) g.surface.PlaySound("buttons/blip1.wav") 
				g.chat.AddText(g.Color(50,50,120),v:Nick(), g.Color(67,102,255)," has joined the game as an admin!") 
			end 
		end 
		for k,v in g.pairs(GI.adminl) do 
			if !g.IsValid(v) then 
				GI.adminl[k] = nil 
			end 
		end 
	end )
	
	g.surface.CreateFont( "GIF", { font = "Calibri", size = 100, weight = 700, } )
	
	function GI:RemapKey(bind, key) 
		if GI.binds[bind] then 
			if bind == "none" then 
				GI.binds[bind] = KEY_NONE 
				return bind.." successfully unbound." 
			end 
			for _,v in ipairs(GI.enumlist) do 
				if key == v.char then 
					GI.binds[bind] = v.val 
					return "Successfully bound "..bind.." to key "..v.char.."!" 
				end 
			end 
			return key.." is not recognized as a key." 
		end 
		return bind.." is not a recoginized bind." 
	end 
	function GI:AutoReload() 
		if LocalPlayer():Alive() and IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() != "weapon_physgun" then 
			if LocalPlayer():GetActiveWeapon():Clip1() <= 0 then 
				if GI.nextreload <= g.CurTime() then 
					GI.nextreload = g.CurTime() + 3 
					g.RunConsoleCommand("+reload") 
					timer.Simple(0.1, function() 
						g.RunConsoleCommand("-reload") 
					end) 
				end 
			end 
		end 
	end 
	function GI:HasLOS(ent, pos) 
		if !GI.bools["checklos"] then 
			return true 
		end 
		local trace = {start = g.LocalPlayer():GetShootPos(), endpos = pos, filter = {g.LocalPlayer(), ent}, mask = 1174421507} 
		local tr = g.util.TraceLine(trace) 
		return tr.Fraction == 1 
	end 
	function GI:ReadyShoot(ent) 
		if g.LocalPlayer() == ent then 
			return false 
		end 
		if !g.IsValid(ent) then 
			return false 
		end 
		if ent:IsPlayer() and (!ent:Alive() or ent:Health() <= 0) then 
			return false 
		end 
		if ent:GetPos():Distance(g.LocalPlayer():GetPos()) >= GI.vars["aimdistance"] then 
			return false 
		end 
		local fov = GI.vars["aimfov"] 
		local ady = 0 
		if fov != 180 then 
			local lpang = g.LocalPlayer():GetAngles() 
			local ang = (ent:GetPos() - g.LocalPlayer():GetPos()):Angle() 
			ady = g.math.abs(g.math.NormalizeAngle(lpang.y - ang.y)) 
			local adp = g.math.abs(g.math.NormalizeAngle(lpang.p - ang.p)) 
			if(ady > fov or adp > fov) then 
				return false 
			end 
		end 
		return true, ady 
	end 
	function GI:Aimbot(ucmd) 
		if g.LocalPlayer():Alive() and not GI.aimbot then 
			local targ, aimpos = GI:FindTarget() 
			if targ && g.input.IsKeyDown(GI.binds["+aim"]) then 
				local ang = (aimpos-LocalPlayer():GetShootPos()):Angle() 
				if GI.bools["aimantisnap"] then 
					ang = GI:Smoothang(ang) 
				end 
				ang.p, ang.y, ang.r = g.math.NormalizeAngle(ang.p), g.math.NormalizeAngle(ang.y), g.math.NormalizeAngle(ang.r) 
				ucmd:SetViewAngles(ang) 
				if GI.bools["aimautoshoot"] then 
					g.RunConsoleCommand("+attack") 
					g.timer.Simple(0, function() 
						g.RunConsoleCommand("-attack") 
					end) 
				end 
			end 
		end 
	end 
	function GI:FindTarget() 
		local tolook = nil 
		local tolookg = nil 
		if GI.curtarg and g.input.IsKeyDown(GI.binds["+aim"]) then 
			if (GI.curtarg:LookupBone("ValveBiped.Bip01_Head1")) then 
				tolook = (GI.bools["targetbonehead"] and GI.curtarg:GetBonePosition(GI.curtarg:LookupBone("ValveBiped.Bip01_Head1"))) or GI.curtarg:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"]) 
			else 
				tolook = GI.curtarg:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"]) 
			end 
			if GI:HasLOS(GI.curtarg, tolook) and not (GI.curtarg:IsPlayer() and !GI.curtarg:Alive()) then 
				return GI.curtarg, tolook 
			else 
				GI.curtarg = nil 
				return false 
			end 
		else 
			GI.curtarg = nil 
		end 
		local eyes = LocalPlayer():EyePos() 
		local aimangle = LocalPlayer():GetAimVector() 
		local bestfov = 360 
		for _,v in g.ipairs(g.ents.GetAll()) do 
			if (GI.bools["targetnpc"] and v:IsNPC()) or (GI.bools["targetplayer"] and v:IsPlayer()) or (GI.bools["targetent"] and table.HasValue(GI.espents, v:GetClass())) then 
				if (v:LookupBone("ValveBiped.Bip01_Head1")) then 
					tolook = (GI.bools["targetbonehead"] and v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))) or v:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"])
				else 
					tolook = v:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"]) 
				end 
				local readyshoot, cyaw = GI:ReadyShoot(v) 
				if GI:HasLOS(v, tolook) and v != g.LocalPlayer() and readyshoot then 
					if cyaw < bestfov then 
						bestfov = cyaw 
						tolookg = tolook 
						GI.curtarg = v 
					end 
				end 
			end 
		end 
		return GI.curtarg,tolookg 
	end 
	function GI:Smoothang(ang) 
		ang.p = g.math.NormalizeAngle(ang.p) 
		ang.y = g.math.NormalizeAngle(ang.y) 
		lpang = g.LocalPlayer():EyeAngles() 
		local as = GI.vars["aimantisnap"] 
		lpang.p = g.math.Approach(lpang.p, ang.p, as) 
		lpang.y = g.math.Approach(lpang.y, ang.y, as) 
		lpang.r = 0 ang = lpang 
		return ang 
	end 
	function GI:ParseCommand(strCmd) 
		local splitcmd = string.Split(string.lower(strCmd), " ") 
		if splitcmd[1] and splitcmd[2] and splitcmd[3] then 
			if splitcmd[1] == "bind" then 
				return GI:RemapKey(splitcmd[3], splitcmd[2]) 
			end 
			if splitcmd[1] == "unbind" then 
				return GI:RemapKey(splitcmd[3], "none")
			end 
		end 
		if splitcmd[1] then 
			if splitcmd[1] == "help" then 
				local binds = {} 
				g.table.insert(binds, "unbind <KEY>") 
				g.table.insert(binds, "bind <KEY> <action>") 
				for k,v in pairs(GI.binds) do 
					g.table.insert(binds, k) 
				end 
				return binds 
			end 
		end 
		return "Invalid Command" 
	end 
	function GI:TriggerBot(ucmd) 
		if g.input.IsKeyDown(GI.binds["+triggerbot"]) then 
			local trace = g.util.GetPlayerTrace( g.LocalPlayer() ) 
			local traceRes = g.util.TraceLine( trace ) 
			local target = traceRes.Entity 
			if g.IsValid(target) and (GI.bools["targetplayer"] and target:IsPlayer()) or (GI.bools["targetnpc"] and target:IsNPC()) then 
				g.RunConsoleCommand("+attack") 
				g.timer.Simple(0, function() g.RunConsoleCommand("-attack") end) 
			else 
				g.RunConsoleCommand("-attack") 
			end 
		end 
	end 
	function GI:Bhop(ucmd) 
		if g.input.IsKeyDown(GI.binds["+bhop"]) and g.LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP and not g.gui.IsConsoleVisible() and not GI.typing then 
			if g.LocalPlayer():OnGround() then 
				g.RunConsoleCommand("+jump") 
				timer.Simple(0, function() g.RunConsoleCommand("-jump") end)
			end 
		end 
	end 
	function GI:ShowMenu() 
		local back = g.vgui.Create("DFrame") 
		back:SetSize(500,400) 
		back:SetTitle("") 
		back:ShowCloseButton(false)
		back:Center() 
		back:MakePopup() 
		back.Think = function() 
			if !g.input.IsKeyDown(GI.binds["+menu"]) then 
				GI.menuopen = false 
				back:Close() 
			end 
		end 
		back.Paint = function() 
			g.draw.RoundedBox( 8, 0, 0, back:GetWide(), back:GetTall(), g.Color( 0, 0, 0, 250 ) ) 
			g.draw.SimpleText("gInject", "GIF", 85, 1, g.Color(255,30,0,190), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
			g.draw.SimpleText("v1", "GIF", 325, 1, g.Color(0,30,255,190), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
		end 
		local tablist = g.vgui.Create( "DPropertySheet", back ) 
		tablist:SetPos( 2, 107 ) 
		tablist:SetSize( back:GetWide()-4, back:GetTall()-109 ) 
		local function AddCheckItem(dpanel, bool, text, x, y) 
			local checkbox = g.vgui.Create("DCheckBoxLabel", dpanel) 
			checkbox:SetPos(x, y) 
			checkbox:SetText(text) 
			checkbox:SizeToContents() 
			checkbox:SetTextColor(Color(255,255,255)) 
			checkbox:SetChecked(GI.bools[bool]) 
			checkbox.OnChange = function(chk) 
				GI.bools[bool] = checkbox:GetChecked() 
			end 
		end 
		local function AddNumItem(dpanel, var, text, min ,max, width, x, y, decimals)
			local numslider = g.vgui.Create("DNumSlider", dpanel) 
			numslider:SetText(text) 
			numslider:SetWide(width) 
			numslider:SetDecimals(decimals) 
			numslider:SetMin(min) 
			numslider:SetMax(max) 
			numslider:SetPos(x, y) 
			numslider:SetValue(GI.vars[var]) 
			numslider.OnValueChanged = function(p, v) 
				GI.vars[var] = v 
			end
		end 
		local dpanelaim = g.vgui.Create( "DPanelList") 
		dpanelaim:SetPos( 2,27 ) 
		dpanelaim:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 ) 
		dpanelaim:SetSpacing( 5 ) 
		dpanelaim:EnableHorizontal( false ) 
		dpanelaim:EnableVerticalScrollbar( false ) 
		local dpanelesp = g.vgui.Create("DPanelList") 
		dpanelesp:SetPos( 2,27 ) 
		dpanelesp:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 ) 
		dpanelesp:SetSpacing( 5 ) 
		dpanelesp:EnableHorizontal( false ) 
		dpanelesp:EnableVerticalScrollbar( false ) 
		local dpanelmisc = g.vgui.Create("DPanelList") 
		dpanelmisc:SetPos( 2,27 ) 
		dpanelmisc:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 ) 
		dpanelmisc:SetSpacing( 5 ) 
		dpanelmisc:EnableHorizontal( false ) 
		dpanelmisc:EnableVerticalScrollbar( false ) 
		local dpanelents = g.vgui.Create("DPanelList") 
		dpanelents:SetPos( 2,27 ) 
		dpanelents:SetSize( tablist:GetWide()-4, tablist:GetTall()-29 ) 
		dpanelents:SetSpacing( 5 ) dpanelents:EnableHorizontal( false ) 
		dpanelents:EnableVerticalScrollbar( false ) 
		local allents = g.vgui.Create("DListView", dpanelents) 
		allents:SetPos(2,2) 
		allents:SetMultiSelect(false) 
		allents:SetSize(dpanelents:GetWide()/2-50,dpanelents:GetTall()-10) 
		allents:AddColumn("Not On ESP") 
		local addedent = {}
		for _,v in ipairs(ents.GetAll()) do 
			if !table.HasValue(addedent, v:GetClass()) and !table.HasValue(GI.espents, v:GetClass()) and v:GetClass() != "player" then 
				allents:AddLine(v:GetClass()) 
				table.insert(addedent, v:GetClass()) 
			end 
		end 
		local custents = g.vgui.Create("DListView", dpanelents) 
		custents:SetPos(dpanelents:GetWide()/2+50,2) 
		custents:SetMultiSelect(false) 
		custents:SetSize(dpanelents:GetWide()/2-50,dpanelents:GetTall()-10) 
		custents:AddColumn("On ESP") 
		for _,v in pairs(GI.espents) do 
			custents:AddLine(v) 
		end 
		local add = g.vgui.Create("DButton", dpanelents) 
		add:SetText("-->") 
		add:SetSize(50,20) 
		add:SetPos(dpanelents:GetWide()/2-(add:GetWide()/2), dpanelents:GetTall()/2-10) 
		add.DoClick = function() 
			local line = allents:GetSelectedLine() 
			if line != nil then 
				local eclass = allents:GetLine(line):GetValue(1) 
				if !g.table.HasValue(GI.espents, eclass) then 
					g.table.insert(GI.espents, eclass) 
					custents:AddLine(eclass) 
					allents:RemoveLine(line) 
				end 
			end 
		end 
		local remove = g.vgui.Create("DButton", dpanelents) 
		remove:SetText("<--") 
		remove:SetSize(50,20) 
		remove:SetPos(dpanelents:GetWide()/2-(add:GetWide()/2), dpanelents:GetTall()/2+10) 
		remove.DoClick = function() 
			local line = custents:GetSelectedLine() 
			if line != nil then 
				local eclass = custents:GetLine(line):GetValue(1) 
				if g.table.HasValue(GI.espents, eclass) then
					for k,v in g.pairs(GI.espents) do 
						if v == eclass then 
							g.table.remove(GI.espents, k) 
						end 
					end 
					allents:AddLine(eclass) 
					custents:RemoveLine(line) 
				end
			end 
		end 
		local dpanellog = g.vgui.Create("DPanelList") 
		dpanellog:SetPos( 2,27 ) 
		dpanellog:SetSize( tablist:GetWide()-4, dpanelents:GetTall()-10 ) 
		dpanellog:SetSpacing( 5 ) 
		dpanellog:EnableHorizontal( false ) 
		dpanellog:EnableVerticalScrollbar( false ) 
		local dlog = g.vgui.Create("DListView", dpanellog) 
		dlog:SetPos(2,24) dlog:SetMultiSelect(false) 
		dlog:SetSize(dpanellog:GetWide()-19,dpanellog:GetTall()-28) 
		dlog:AddColumn("Log") 
		for i=#GI.log,1,-1 do 
			dlog:AddLine(GI.log[i]) 
		end 
		local clear = g.vgui.Create("DButton", dpanellog) 
		clear:SetText("Clear") 
		clear:SetSize(dpanellog:GetWide()-19, 20) 
		clear:SetPos(2, 2) 
		clear.DoClick = function() 
			dlog:Clear() GI.log = {} 
		end 
		local dpanelcfg = g.vgui.Create("DPanelList") 
		dpanelcfg:SetPos( 2,27 ) 
		dpanelcfg:SetSize( tablist:GetWide()-4, dpanelcfg:GetTall()-10 ) 
		dpanelcfg:SetSpacing( 5 ) 
		dpanelcfg:EnableHorizontal( false ) 
		dpanelcfg:EnableVerticalScrollbar( false ) 
		local dcfg = g.vgui.Create("DListView", dpanelcfg) 
		dcfg:SetPos(2,24) 
		dcfg:SetMultiSelect(false) 
		dcfg:SetSize(tablist:GetWide()-19,tablist:GetTall()-63) 
		dcfg:AddColumn("Config") 
		for _,v in pairs(GI.configs) do 
			dcfg:AddLine(v) 
		end 
		dcfg.DoDoubleClick = function() 
			local line = dcfg:GetSelectedLine() 
			if line != nil then 
				local config = dcfg:GetLine(line):GetValue(1) 
				GI:LoadConfig(config) 
				back:Close() 
				GI.menuopen = false 
			end 
		end 
		local createconfig = g.vgui.Create("DButton", dpanelcfg) 
		createconfig:SetText("Create New") 
		createconfig:SetSize(dpanelcfg:GetWide()/2-50, 20) 
		createconfig:SetPos(2, 2) 
		createconfig.DoClick = function() 
			g.Derma_StringRequest( "New Config", "Name of the new config", "", function(txt) 
				if !g.table.HasValue(GI.configs, txt) then 
					GI:SaveConfig(txt) 
					g.table.insert(GI.configs, txt) 
				end 
			end ) 
			back:Close() 
			GI.menuopen = false 
		end 
		local deleteconfig = g.vgui.Create("DButton", dpanelcfg) 
		deleteconfig:SetText("Delete") 
		deleteconfig:SetSize(dpanelcfg:GetWide()/2-50, 20) 
		deleteconfig:SetPos(dpanelcfg:GetWide()/2+37, 2) 
		deleteconfig.DoClick = function() 
			local line = dcfg:GetSelectedLine() 
			if line != nil then 
				local config = dcfg:GetLine(line):GetValue(1) 
				for k,v in pairs(GI.configs) do 
					if v == config then 
						g.table.remove(GI.configs, k) 
					end 
				end 
				GI:DeleteConfig(config) 
				back:Close() 
				GI.menuopen = false 
			end 
		end 
		AddCheckItem(dpanelaim, "aimactive", "Aimbot Active", 5, 5) 
		AddCheckItem(dpanelaim, "triggeractive", "Triggerbot Active", 5, 30) 
		AddCheckItem(dpanelaim, "aimteam", "Aim At Team", 5, 55) 
		AddCheckItem(dpanelaim, "aimlos", "Check Line of Sight", 5, 80) 
		AddCheckItem(dpanelaim, "aimautoshoot", "Auto-Shoot", 5, 105) 
		AddCheckItem(dpanelaim, "aimautoreload", "Auto-Reload", 5, 130) 
		AddCheckItem(dpanelaim, "targetbonehead", "Target Head Bone", 5, 155) 
		AddCheckItem(dpanelaim, "targetnpc", "Target NPC's", 5, 180) 
		AddCheckItem(dpanelaim, "targetplayer", "Target Players", 5, 205) 
		AddCheckItem(dpanelaim, "targetent", "Target Ents", 5, 230) 
		AddCheckItem(dpanelaim, "checklos", "Check LOS", 150, 5) 
		AddCheckItem(dpanelaim, "aimantisnap", "Anti-Snap", 150, 30) 
		AddCheckItem(dpanelesp, "espactive", "ESP/Wallhack Active", 5, 5) 
		AddCheckItem(dpanelesp, "espchams", "Wallhack", 5, 30) 
		AddCheckItem(dpanelesp, "espwireframe", "Wireframe Wallhack", 5, 55) 
		AddCheckItem(dpanelesp, "espsolid", "Solid Wallhack", 5, 80) 
		AddCheckItem(dpanelesp, "espplayers", "Show Players", 5, 105) 
		AddCheckItem(dpanelesp, "espnpc", "Show NPCs", 5, 130) 
		AddCheckItem(dpanelesp, "espents", "Show Ents", 5, 155) 
		AddCheckItem(dpanelesp, "esphealth", "Show Health", 5, 180) 
		AddCheckItem(dpanelesp, "esparmor", "Show Armor", 5, 205)
		AddCheckItem(dpanelesp, "espteam", "Show Team", 5, 230) 
		AddCheckItem(dpanelesp, "espadmin", "Show Rank", 150, 5) 
		AddCheckItem(dpanelesp, "espweapon", "Show Weapon", 150, 30) 
		AddCheckItem(dpanelmisc, "miscbhop", "Enable Bunnyhop", 5, 5) 
		AddCheckItem(dpanelmisc, "misclognet", "Log Net", 5, 30)
		AddCheckItem(dpanelmisc, "misclogrcc", "Log RunConsoleCommand", 5, 55) 
		AddCheckItem(dpanelmisc, "miscblock", "Block RCC/Net", 5, 80) 
		AddCheckItem(dpanelmisc, "miscprint", "Show In Console", 5, 105) 
		AddCheckItem(dpanelmisc, "norecoil", "No-Recoil", 5, 130) 
		AddNumItem(dpanelaim, "aimx", "X Offset", 0, 256, 150, 340, 5, 0)
		AddNumItem(dpanelaim, "aimy", "Y Offset", 0, 256, 150, 340, 30, 0) 
		AddNumItem(dpanelaim, "aimz", "Z Offset", 0, 256, 150, 340, 55, 0) 
		AddNumItem(dpanelaim, "aimfov", "FOV", 1, 180, 150, 340, 80, 0) 
		AddNumItem(dpanelaim, "aimdistance", "Distance", 0, 20000, 150, 340, 105, 0) 
		AddNumItem(dpanelaim, "aimantisnap", "Anti-Snap Speed", 0, 20, 150, 340, 130, 1) 
		AddNumItem(dpanelesp, "espchamdist", "Cham Distance", 0, 20000, 150, 340, 5, 0) 
		AddNumItem(dpanelesp, "esptextdist", "ESP Distance", 0, 20000, 150, 340, 30, 0) 
		tablist:AddSheet( "Aimbot", dpanelaim, "gui/silkicons/user", false, false, "Aimbot Settings" ) 
		tablist:AddSheet( "ESP/Wallhack", dpanelesp, "gui/silkicons/picture_edit", false, false, "ESP/Wallhack Settings" ) 
		tablist:AddSheet( "Entities", dpanelents, "gui/silkicons/brick_add", false, false, "Entities" ) 
		tablist:AddSheet( "Misc", dpanelmisc, "gui/silkicons/world", false, false, "Miscellaneous Settings" ) 
		tablist:AddSheet( "Log", dpanellog, "gui/silkicons/folder_go", false, false, "RCC/Net Logs" ) 
		tablist:AddSheet( "Configs", dpanelcfg, "gui/silkicons/page", false, false, "Load/Save Settings" ) 
	end 
	function GI:OpenConsole() 
		local back = g.vgui.Create("DFrame") 
		back:ShowCloseButton(false) 
		back:SetSize(600,500) 
		back:SetDraggable(false) 
		back:SetTitle("gInject - Console") 
		back:SetPos(50,50) 
		back:MakePopup() 
		local closebutton = g.vgui.Create("DButton", back) 
		closebutton:SetText("X") 
		closebutton:SetSize(25,23) 
		closebutton:SetPos(574,1) 
		closebutton.DoClick = function() 
			GI.conopen = false 
			back:Close() 
		end 
		local DList = g.vgui.Create("DListView", back) 
		DList:AddColumn("Console") 
		DList:SetSize(back:GetWide() - 10, back:GetTall() - 75) 
		DList:SetPos(5,65) 
		local txt = g.vgui.Create("DTextEntry", back) 
		txt:SetWide(back:GetWide() - 20) txt:SetPos(10,35) 
		txt.OnEnter = function() 
			local lines = {} 
			for _,v in g.ipairs(DList:GetLines()) do 
				g.table.insert(lines, v:GetValue(1)) 
			end 
			DList:Clear() 
			local callb = GI:ParseCommand(txt:GetValue()) 
			if type(callb) == "table" then 
				for _,v in pairs(callb) do 
					DList:AddLine(v) 
				end 
			else 
				DList:AddLine(callb)
			end 
			DList:AddLine("] "..txt:GetValue()) 
			for _,v in g.ipairs(lines) do 
				DList:AddLine(v) 
			end 
			txt:SetText("") 
			txt:RequestFocus() 
		end 
		txt:RequestFocus() 
	end 
	GI.Thinkh = GAMEMODE.Think 
	function GAMEMODE:Think() 
		GI.Thinkh() 
		if g.input.IsKeyDown(KEY_TAB) and g.input.IsKeyDown(KEY_Q) and not GI.conopen and not g.gui.IsConsoleVisible() then 
			GI.conopen = true 
			GI:OpenConsole() 
		end 
		if g.input.IsKeyDown(GI.binds["+menu"]) and not GI.menuopen and not g.gui.IsConsoleVisible() then 
			GI.menuopen = true 
			GI:ShowMenu() 
		end 
		if g.input.IsKeyDown(GI.binds["esp_toggle"]) and not GI.esppress then 
			GI.esppress = true 
			GI.bools["espactive"] = !GI.bools["espactive"] 
		end 
		if !g.input.IsKeyDown(GI.binds["esp_toggle"]) then 
			GI.esppress = false 
		end 
	end 
	GI.CreateMove = GAMEMODE.CreateMove 
	function GAMEMODE:CreateMove(ucmd) 
		GI.CreateMove(ucmd) 
		if(GI.bools["aimautoreload"]) then 
			GI:AutoReload() 
		end 
		if(GI.bools["aimactive"]) then 
			GI:Aimbot(ucmd) 
		end 
		if(GI.bools["triggeractive"]) then 
			GI:TriggerBot(ucmd) 
		end 
		if(GI.bools["norecoil"]) then 
			local wep = g.LocalPlayer():GetActiveWeapon() 
			if IsValid(wep) and wep.Primary then 
				wep.Primary.Recoil = 0 
			end 
		end 
		if(GI.bools["miscbhop"]) then 
			GI:Bhop() 
		end 
	end 
	GI.HUDPaint = GAMEMODE.HUDPaint 
	function GAMEMODE:HUDPaint() 
		if GI.bools["espactive"] then 
			cam.Start3D(g.EyePos() , g.EyeAngles()) 
			for _,v in g.pairs(g.ents.GetAll()) do 
				if (GI.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators") or (GI.bools["espnpcs"] and v:IsNPC()) and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GI.vars["espchamdist"] then 
					local chamcol = g.team.GetColor(v:Team()) or Color(134,13,255,255) 
					if GI.bools["espwireframe"] then 
						v:SetMaterial("models/wireframe") 
					elseif GI.bools["espsolid"] then 
						v:SetMaterial("models/debug/debugwhite") 
					end 
					g.render.SetColorModulation(chamcol.r / 255, chamcol.g / 255, chamcol.b / 255) 
					g.render.SetBlend(chamcol.a / 255) v:SetColor(chamcol) 
					v:DrawModel() 
					v:SetColor(Color(255,255,255)) 
					v:SetMaterial("") 
				end 
			end 
			cam.End3D() 
			for _,v in g.pairs(g.ents.GetAll()) do 
				if (GI.bools["espplayers"] and v:IsPlayer() and v:Alive() and g.team.GetName(v:Team()) != "Spectators") and v != g.LocalPlayer() and v:GetPos():Distance(g.LocalPlayer():GetPos()) <= GI.vars["esptextdist"] then 
					local y = -10 
					local pos = (v:GetPos()+g.Vector(0,0,45)):ToScreen() 
					local nametocall = v:Nick() 
					local rank = "Player" 
					local rankcol = g.Color(150,0,255,255) 
					if v:IsAdmin() then 
						rank = "Admin" 
						rankcol = g.Color(255,0,150,255) 
					elseif v:IsSuperAdmin() then 
						rank = "Super Admin" 
						rankcol = g.Color(0,150,255,255) 
					end 
					local color = g.Color(255,255,255,255) 
					g.draw.SimpleText(v:Nick(), "default", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
					y = y -12 
					if GI.bools["esphealth"] then 
						g.draw.SimpleText("H: "..v:Health(), "default", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
						y = y -12 
					end 
					if GI.bools["esparmor"] then 
						g.draw.SimpleText("A: "..v:Armor(), "default", pos.x, pos.y + y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
						y = y -12 
					end 
					if GI.bools["espteam"] then 
						g.draw.SimpleText(team.GetName(v:Team()), "default", pos.x, pos.y + y, g.team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
						y = y -12 
					end 
					if GI.bools["espadmin"] then 
						g.draw.SimpleText(rank, "default", pos.x, pos.y + y, rankcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
						y = y - 12 
					end 
					if g.IsValid(v:GetActiveWeapon()) and GI.bools["espweapon"] then 
						g.draw.SimpleText(v:GetActiveWeapon():GetClass(), "default", pos.x, pos.y + y, g.Color(67,120,54), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
						y = y - 12
					end 
				end 
				if g.table.HasValue(GI.espents, v:GetClass()) and GI.bools["espents"] then 
					local pos = (v:GetPos()+g.Vector(0,0,35)):ToScreen() 
					g.draw.SimpleText(v:GetClass(), "default", pos.x, pos.y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
				end 
			end 
		end 
		GI.HUDPaint(self) 
	end 
end
GI:StartScript() 