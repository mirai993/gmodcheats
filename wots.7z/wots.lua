local Version = 0.2 .. " Alpha "
local CreateClientConVar = CreateClientConVar;

chat.AddText(
    Color(0,255,0,255), "[Cheat] ",
    Color(0,255,0,255), "The C+P ",
    Color(0,255,0,255), "Project ",
        Color(0,255,0,255), "Version " .. Version .. "Loaded" )
surface.PlaySound("buttons/button19.wav")

chat.AddText(
    Color(255,0,0,255), "This is a really bad cheat, copy pasted together by Kelse ")

local minge = LocalPlayer()
local spining = false
local aiming = false
local MawESPEnabled = false
local wireframeenabled = false
local canban = true
local DarkRPWallhackEnabled = false

CreateClientConVar("wots_aimbot_autoattack", "1", true, false)
CreateClientConVar("wots_aimbot_autoattack_delay", "0", true, false) --keep at 0 for more lulz
CreateClientConVar("wots_aimbot_teammode", "0", true, false)
CreateClientConVar("wots_aimbot_mouselock", "0", true, false) --use it for long range weapons


local darkrpitems = {}
darkrpitems =  {"drug",
                "drug_lab",
                "food",
                "gunlab",
                "melon",
                "money_printer",
                "spawned_shipment",
                "spawned_weapon",
                "microwave"}

                    
function MawNotify(str)
    local gn = string.lower(gmod.GetGamemode().Name)
    if string.find(gn , "sandbox") or string.find(gn, "darkrp") then
        GAMEMODE:AddNotify(str, NOTIFY_CLEANUP, 5 )
    else    
        LocalPlayer():ChatPrint(str)
    end 
    print(str)
end 


function MawTeamAllowed(ent)    
    if GetConVarNumber("wots_aimbot_teammode") >= 1 then
        if ent:Team() != minge:Team() then
            return true
        else
            return false
        end
    end 
    return true 
end


function MawBotAllowed(ent)
    if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or minge == ent then return false end
    if ent:IsPlayer() and !ent:Alive() then return false end
    if ent:IsPlayer() and !MawTeamAllowed(ent) then return false end
    if ent:IsNPC() and ent:GetMoveType() == 0 then return false end
    return true
end 


    


function RPMawBotAllowed(ent)
    for k, v in pairs(darkrpitems) do
        if v == ent:GetClass() then
            return true
        else
            return false
        end 
    end
end


function HeadPosition(ent)
    local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
    return ent:GetBonePosition(hbone)   
end 


function BotVisible(ent)
    local trace = {start = minge:GetShootPos(),endpos = HeadPosition(ent),filter = {minge, ent},mask = 1174421507}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end 
end


function GetMawBotTarget()

    local position = minge:EyePos()
    local angle = minge:GetAimVector()
    local tar = {0,0}
    for _, ent in pairs(ents.GetAll()) do
        if MawBotAllowed(ent) and BotVisible(ent) then
            local targetpos = ent:EyePos()
            local difr = (targetpos-position):Normalize()
            difr = difr - angle
            difr = difr:Length()
            difr = math.abs(difr)
            if difr < tar[2] or tar[1] == 0 then
                tar = {ent, difr}
            end
        end
    end
    
    return tar[1]
end

_G.SafeAIM = _R["CUserCmd"].SetViewAngles

function MawMegaAIM(UCMD)                   
    if aiming then
    
        local pwned = GetMawBotTarget()
        if pwned == 0 then return end
    
        local vel = pwned:GetVelocity() or Vector(0,0,0)
        SafeAIM(UCMD, ((HeadPosition(pwned) + vel * 2 * FrameTime()) - minge:GetShootPos()):Angle())
        
        local tr = minge:GetEyeTrace()
        
        if MawBotAllowed(tr.Entity) then
            if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
                 RunConsoleCommand("cl_mouseenable", "0")
            end 
            
            if GetConVarNumber("wots_aimbot_autoattack") >= 1 then
                local aad = GetConVarNumber("wots_aimbot_autoattack_delay")
                if !timer.IsTimer("autoattack") then
                    timer.Create("autoattack", aad, 0, function()
                        RunConsoleCommand("wots_attack")
                    end)    
                end
            end 
            
            
        else    
        
            
            if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
                RunConsoleCommand("cl_mouseenable", "1")
            end
                                
            if timer.IsTimer("autoattack") then
                timer.Destroy("autoattack")
            end 
        end 
    end
end 
    

hook.Add("CreateMove", "MingeBagAIMBot", MawMegaAIM)

concommand.Add("wots_attack", function()
    LocalPlayer():ConCommand("+attack; +attack; -attack; cl_mouseenable 1")
end)


concommand.Add("+aimbot", function()
    aiming = true   
end)


concommand.Add("-aimbot", function()
    aiming = false 
    
    if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
        RunConsoleCommand("cl_mouseenable", "1")
    end 
    if timer.IsTimer("autoattack") then
        timer.Destroy("autoattack")
    end 
end)    

--Start of config
local s0beitEspCvar = CreateClientConVar( "s0beit_esp", 1, true, false )
local s0beitCroCvar = CreateClientConVar( "s0beit_xhair", 0, true, false )
--End of config

local function HeadPos(ply)
    if ValidEntity(ply) then
        local hbone = ply:LookupBone("ValveBiped.Bip01_Head1")
        return ply:GetBonePosition(hbone)
    else return end
end

local function Visible(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end    
end

local function IsSteamFriend( ply )
    return ply:GetFriendStatus() == "friend"
end

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function OutlineRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawOutlinedRect( x, y, w, h );
end

local function DrawCrosshair()
    local w = ScrW() / 2;
    local h = ScrH() / 2;
    
    FillRGBA( w - 5, h, 11, 1, Color( 255, 0, 0, 255 ) );
    FillRGBA( w, h - 5, 1, 11, Color( 255, 0, 0, 255 ) );
end

function DrawESP()
    if s0beitEspCvar:GetInt() == 1 then
        for k, v in pairs(ents.GetAll()) do
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then
                    local drawColor = Color(255, 255, 255, 255);
                    local drawPosit = v:GetPos():ToScreen();
                    
                    if( Visible(v) ) then
                        drawColor = Color( 255, 0, 0, 255 );
                    else
                        drawColor = Color( 0, 255, 0, 255 );
                    end
                    
                    local textData = {}
                    
                    textData.pos = {}
                    textData.pos[1] = drawPosit.x;
                    textData.pos[2] = drawPosit.y;
                    textData.color = drawColor;
                    textData.text = v:GetClass();
                    textData.font = "DefaultFixed";
                    textData.xalign = TEXT_ALIGN_CENTER;
                    textData.yalign = TEXT_ALIGN_CENTER;
                    draw.Text( textData );
                    
                elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then
                    local drawColor = team.GetColor(v:Team());
                    local drawPosit = v:GetPos():ToScreen();
                    
                    if( Visible(v) ) then
                        drawColor.a = 255;
                    else
                        drawColor.r = 255 - drawColor.r;
                        drawColor.g = 255 - drawColor.g;
                        drawColor.b = 255 - drawColor.b;
                    end
                    
                    local textData = {}
                    
                    textData.pos = {}
                    textData.pos[1] = drawPosit.x;
                    textData.pos[2] = drawPosit.y;
                    textData.color = drawColor;
                    textData.text = v:GetName();
                    textData.font = "DefaultFixed";
                    textData.xalign = TEXT_ALIGN_CENTER;
                    textData.yalign = TEXT_ALIGN_CENTER;
                    
                    draw.Text( textData );
                    
                    local max_health = 100;
                    
                    if( v:Health() > max_health ) then
                        max_health = v:Health();
                    end
                    
                    local mx = max_health / 4;
                    local mw = v:Health() / 4;
                    
                    local drawPosHealth = drawPosit;
                    
                    drawPosHealth.x = drawPosHealth.x - ( mx / 2 );
                    drawPosHealth.y = drawPosHealth.y + 10;
                    
                    FillRGBA( drawPosHealth.x - 1, drawPosHealth.y - 1, mx + 2, 4 + 2, Color( 0, 0, 0, 255 ) );
                    FillRGBA( drawPosHealth.x, drawPosHealth.y, mw, 4, drawColor );
                end
            end
        end
    end
end

function DrawXHair()
    if( s0beitCroCvar:GetInt() == 1 ) then
        DrawCrosshair();
    end
end

hook.Add( "HUDPaint", "DrawESP", DrawESP );
hook.Add( "HUDPaint", "DrawXHair", DrawXHair );  

local showskele = CreateClientConVar( "showskeletonesp", 0, true, false )
local function skeleton()
    if showskele:GetInt() >= 1 then
        surface.SetDrawColor( 225, 0, 0, 255 )
        local skelecore = {
        "ValveBiped.Bip01_Head1", //core
        "ValveBiped.Bip01_Neck1", 
        "ValveBiped.Bip01_Spine4",
        "ValveBiped.Bip01_Spine2",
        "ValveBiped.Bip01_Spine1",
        "ValveBiped.Bip01_Spine"
        }   
        local skelearm_R = {
        "ValveBiped.Bip01_Neck1",
        "ValveBiped.Bip01_R_UpperArm", //right arm
        "ValveBiped.Bip01_R_Forearm", 
        "ValveBiped.Bip01_R_Hand"
        }
        local skelearm_L = {
        "ValveBiped.Bip01_Neck1",
        "ValveBiped.Bip01_L_UpperArm",//left arm
        "ValveBiped.Bip01_L_Forearm",
        "ValveBiped.Bip01_L_Hand"
        }
        local skeleleg_R = {
        "ValveBiped.Bip01_Spine",
        "ValveBiped.Bip01_R_Thigh",//right leg
        "ValveBiped.Bip01_R_Calf",
        "ValveBiped.Bip01_R_Foot",
        "ValveBiped.Bip01_R_Toe0"
        }
        local skeleleg_L = {
        "ValveBiped.Bip01_Spine",
        "ValveBiped.Bip01_L_Thigh",//left leg
        "ValveBiped.Bip01_L_Calf",
        "ValveBiped.Bip01_L_Foot",
        "ValveBiped.Bip01_L_Toe0"
        }
        local curbone
        local nextbone
        for k,v in pairs (ents.GetAll()) do 
            if (v:IsPlayer()) and (v:Alive() == true) and (v:EntIndex() != LocalPlayer():EntIndex()) then
                -----------------------------core-----------------------------
                for n,b in pairs(skelecore) do
                    curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
                    nextbone = v:GetBonePosition(v:LookupBone(tostring(skelecore[n+1]))):ToScreen()
                    surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
                end
                -----------------------------arms-----------------------------
                for n,b in pairs(skelearm_R) do
                    curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
                    nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_R[n+1]))):ToScreen()
                    surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
                end
                for n,b in pairs(skelearm_L) do
                    curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
                    nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_L[n+1]))):ToScreen()
                    surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
                end
                -----------------------------legs-----------------------------
                for n,b in pairs(skeleleg_R) do
                    curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
                    nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_R[n+1]))):ToScreen()
                    surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
                end
                for n,b in pairs(skeleleg_L) do
                    curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
                    nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_L[n+1]))):ToScreen()
                    surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
                end
            end
        end
    end
 end
 hook.Add("HUDPaintBackground", "DrawSkel", skeleton)

local uranoob = CreateClientConVar("triggerbot" , "0" , true , false)
function Trigger()
local Eye = LocalPlayer():GetEyeTrace().Entity
if uranoob:GetBool() then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+Attack")
else
timer.Simple(0.2, function()
RunConsoleCommand("-Attack")
                        end)
                end
        end
                end
 
hook.Add("Think", "Test", Trigger)

local Nocoil = CreateClientConVar("nonerecoil","1",true,false)
hook.Add( "Think", "Nocoil", function() // stolen shit from inkbot, i know, it's useless
    if not LocalPlayer():GetActiveWeapon().Primary then return end
    LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
    LocalPlayer():GetActiveWeapon().Secondary.Recoil = 0
end)


CreateClientConVar( "misc_chatspam", 0, true, false )
function ChatSpam()
if GetConVarNumber( "misc_chatspam" ) == 1 then
RunConsoleCommand( "say", "lol i am a nigger using a copy pasted cheat by kelse." )
end
end
hook.Add( "Think", "lookmomnohands", ChatSpam )

function DoChecksRadar( e )
 
        local ply, val = LocalPlayer(), 0
       
        if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
       
        if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
        if ( e:IsPlayer() && !e:Alive() ) then return false end
        if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
        if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
       
        return true
       
end

local Radar = vgui.Create( "DFrame" )
        Radar:SetSize( 300, 300 )
       
        local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2
       
        local sW, sH = ScrW(), ScrH()
        Radar:SetPos( sW - rW - 10, sH - rH - ( sH - rH ) + 10 )
        Radar:SetTitle("C+P'd Radar")
        Radar:SetVisible( true )
        Radar:SetDraggable( true )
        Radar:ShowCloseButton( false )
        Radar:MakePopup()
        Radar.Paint = function()
                draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 40 ) )
                surface.SetDrawColor( 255, 255, 255, 255 )
                surface.DrawOutlinedRect( 0, 0, rW, rH )
               
                local ply = LocalPlayer()
               
                local radar = {}
                radar.h         = 300
                radar.w         = 300
                radar.org       = 5000
               
                local x, y = ScrW() / 2, ScrH() / 2
               
                local half = rH / 2
                local xm = half
                local ym = half
               
                surface.DrawLine( xm, ym - 100, xm, ym + 100 )
                surface.DrawLine( xm - 100, ym, xm + 100, ym )
               
                for k, e in pairs( ents.GetAll() ) do
                        if ( DoChecksRadar(e) ) then
                               
                                local s = 6
                                local col = {}
                                local color = Color( 255,255,255,200 )
                                local plyfov = ply:GetFOV() / ( 70 / 1.13 )
                                local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
                               
                                npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
                                local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
                                local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
                               
                               
                                local pX = ( radar.w / 2 )
                                local pY = ( radar.h / 2 )
                               
                                local posX = pX - iY - ( s / 2 )
                                local posY = pY - iX - ( s / 2 )
                               
                                local text = e:GetClass()
                               
                                if ( e:IsPlayer() ) then
                                        text = e:Nick() .. " ["..e:Health().."]"
                                end
                               
                                if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
                               
                                        draw.RoundedBox( s, posX, posY, s, s, color )
 
                                end
                        end
                end
        end
       
        Radar:SetVisible( true )
        Radar:SetMouseInputEnabled( false )
        Radar:SetKeyboardInputEnabled( false )
        concommand.Add( "+mouseenable", function() Radar:SetMouseInputEnabled( true ) end )
        concommand.Add( "-mouseenable", function() Radar:SetMouseInputEnabled( false ) end )
       
        RRadar = Radar

CreateClientConVar( "esp_admin", 0, true, false )
local function AdminESP() --Creates the function.
    if GetConVarNumber( "esp_admin" ) == 1 then
        for k,v in pairs (player.GetAll()) do --Get all players.
        if v == LocalPlayer() then continue end --If v is LocalPlayer, then do nothing.
        if v:Alive() and v:Health() > 0 then --Only alive players.
            local Position = v:GetPos() + Vector(0,0,80) --Sets position above head.
            Position = Position:ToScreen()
            if v:IsAdmin() then --If it's an admin, then...
                draw.SimpleText("Admin" ,"TabLarge" ,Position.x ,Position.y ,Color( 255, 0, 0, 255 ) , TEXT_ALIGN_CENTER) --Draw the text.
            elseif v:IsSuperAdmin() then --If it's a superadmin, then...
                draw.SimpleText("Super Admin" ,"TabLarge" ,Position.x ,Position.y ,Color( 255, 0, 0, 255 ) , TEXT_ALIGN_CENTER) --Draw the text.
                end
            end
        end
    end
end
hook.Add("HUDPaint","AdminESP",AdminESP) --Add hook.