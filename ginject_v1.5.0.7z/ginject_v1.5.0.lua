-- paradox note: Was minified into a single line. Fixed it with Falco's glualinter.

--[[
	lua/LOLZOR3.lua
	Kinderknacht | (STEAM_0:0:50357078)
	===DStream===
]]

-- Version 1.2
-- Last Updated: 2/21/2013
-- _DeNy
--
-- Start Script
-- 

if SERVER then return end
local g = table.Copy(_G)
local GI = {}
GI.version = "1.5"
g.http.Fetch("https://dl.dropbox.com/u/42089158/gmod/enabled.txt", function(body, len, headers, code) if body == GI.version then end end, function(code) end)
GI.conopen = false --GI:StartScript()  --function GI:StartScript() 
GI.menuopen = false
GI.nextreload = g.CurTime()
GI.curtarg = nil
GI.meta = g.FindMetaTable("Player")
GI.typing = false
GI.adminl = {}
GI.espents = {}
GI.friends = {}
GI.log = {}
GI.configs = {}
GI.esppress = false
GI.enumlist = {
    [1] = {
        char = "a",
        val = KEY_A
    },
    [2] = {
        char = "b",
        val = KEY_B
    },
    [3] = {
        char = "c",
        val = KEY_C
    },
    [4] = {
        char = "d",
        val = KEY_D
    },
    [5] = {
        char = "e",
        val = KEY_E
    },
    [6] = {
        char = "f",
        val = KEY_F
    },
    [7] = {
        char = "g",
        val = KEY_G
    },
    [8] = {
        char = "h",
        val = KEY_H
    },
    [9] = {
        char = "i",
        val = KEY_I
    },
    [10] = {
        char = "j",
        val = KEY_J
    },
    [11] = {
        char = "k",
        val = KEY_K
    },
    [12] = {
        char = "l",
        val = KEY_L
    },
    [13] = {
        char = "m",
        val = KEY_M
    },
    [14] = {
        char = "n",
        val = KEY_N
    },
    [15] = {
        char = "o",
        val = KEY_O
    },
    [16] = {
        char = "p",
        val = KEY_P
    },
    [17] = {
        char = "q",
        val = KEY_Q
    },
    [18] = {
        char = "r",
        val = KEY_R
    },
    [19] = {
        char = "s",
        val = KEY_S
    },
    [20] = {
        char = "t",
        val = KEY_T
    },
    [21] = {
        char = "u",
        val = KEY_U
    },
    [22] = {
        char = "v",
        val = KEY_V
    },
    [23] = {
        char = "w",
        val = KEY_W
    },
    [24] = {
        char = "x",
        val = KEY_X
    },
    [25] = {
        char = "y",
        val = KEY_Y
    },
    [26] = {
        char = "z",
        val = KEY_Z
    },
    [27] = {
        char = "space",
        val = KEY_SPACE
    },
    [28] = {
        char = "tab",
        val = KEY_TAB
    },
    [29] = {
        char = "lshift",
        val = KEY_LSHIFT
    },
    [30] = {
        char = "rshift",
        val = KEY_RSHIFT
    },
    [31] = {
        char = "lalt",
        val = KEY_LALT
    },
    [32] = {
        char = "ralt",
        val = KEY_RALT
    },
    [33] = {
        char = ",",
        val = KEY_COMMA
    },
    [34] = {
        char = ".",
        val = KEY_PERIOD
    },
    [35] = {
        char = "/",
        val = KEY_SLASH
    },
    [36] = {
        char = "[",
        val = KEY_LBRACKET
    },
    [37] = {
        char = ";",
        val = KEY_SEMICOLON
    },
    [38] = {
        char = "'",
        val = KEY_APOSTROPHE
    },
}

GI.binds = {
    ["+aim"] = KEY_Z,
    ["+menu"] = KEY_B,
    ["+triggerbot"] = KEY_T,
    ["esp_toggle"] = KEY_M,
    ["+bhop"] = KEY_SPACE,
}

GI.bools = {
    ["aimactive"] = true,
    ["aimteam"] = true,
    ["aimautoshoot"] = false,
    ["aimautoreload"] = false,
    ["targetbonehead"] = true,
    ["targetnpc"] = false,
    ["targetplayer"] = true,
    ["targetent"] = false,
    ["checklos"] = true,
    ["triggeractive"] = true,
    ["aimantisnap"] = false,
    ["espactive"] = true,
    ["espchams"] = true,
    ["espplayers"] = true,
    ["espnpcs"] = false,
    ["espents"] = false,
    ["espwireframe"] = false,
    ["espsolid"] = true,
    ["norecoil"] = true,
    ["esphealth"] = true,
    ["esparmor"] = true,
    ["espteam"] = true,
    ["espadmin"] = true,
    ["espweapon"] = true,
    ["miscbhop"] = true,
    ["misclognet"] = true,
    ["misclogrcc"] = true,
    ["miscblock"] = false,
    ["miscprint"] = false,
}

GI.vars = {
    ["aimx"] = 7,
    ["aimy"] = 1,
    ["aimz"] = 61,
    ["aimfov"] = 180,
    ["aimdistance"] = 5000,
    ["aimantisnap"] = 0.2,
    ["espchamdist"] = 2000,
    ["esptextdist"] = 15000,
}

g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand)
g.rawset(_G, "GetConVar", oGetConVar)
local onet = net
local ofile = file
local ofopen = file.Open
file = nil
net = nil
hook = nil
RunConsoleCommand = nil
g.setmetatable(_G, {
    __index = function(t, k)
        if k == "RunConsoleCommand" then return oRunConsoleCommand end
        if k == "net" then return g.net end
        if k == "hook" then return g.hook end
        if k == "GetConVar" then return oGetConVar end
        if k == "file" then return ofile end
    end,
    __metatable = true,
})

GI.StartChat = GAMEMODE.StartChat
function GAMEMODE:StartChat()
    GI.StartChat()
    GI.typing = true
end

GI.FinishChat = GAMEMODE.FinishChat
function GAMEMODE:FinishChat()
    GI.FinishChat()
    GI.typing = false
end

local function oldWrite(name, contents)
    local f = ofopen(name, "w", "DATA")
    if not f then return end
    f:Write(contents)
    f:Close()
end

local function oldRead(name)
    local f = ofopen(name, "r", "DATA")
    if not f then return end
    local str = f:Read(f:Size())
    f:Close()
    if not str then str = "" end
    return str
end

function GI:SaveConfig(cfgname)
    local tabletosave = {}
    tabletosave.vars = GI.vars
    tabletosave.bools = GI.bools
    tabletosave.binds = GI.binds
    tabletosave.espents = GI.espents
    tabletosave.friends = GI.friends
    g.file.Delete("ginject/" .. cfgname .. ".txt")
    oldWrite("ginject/" .. cfgname .. ".txt", g.util.TableToJSON(tabletosave))
end

function GI:LoadConfig(cfgname)
    cfgname = g.string.lower(cfgname)
    if g.file.Exists("ginject/" .. cfgname .. ".txt", "DATA") then
        local tabletoload = g.util.JSONToTable(oldRead("ginject/" .. cfgname .. ".txt"))
        GI.vars = tabletoload.vars
        GI.bools = tabletoload.bools
        GI.binds = tabletoload.binds
        GI.espents = tabletoload.espents
        GI.friends = tabletoload.friends
    end
end

function GI:DeleteConfig(cfgname)
    cfgname = g.string.lower(cfgname)
    if g.file.Exists("ginject/" .. cfgname .. ".txt", "DATA") then g.file.Delete("ginject/" .. cfgname .. ".txt") end
end

function GI:GetConfigs()
    local files = g.file.Find("ginject/*.txt", "DATA")
    for k, v in g.ipairs(files) do
        files[k] = g.string.Replace(v, ".txt", "")
    end
    return files
end

if not g.file.Exists("ginject", "DATA") then
    g.file.CreateDir("ginject")
    GI:SaveConfig("default")
else
    GI:LoadConfig("default")
end

GI.configs = GI:GetConfigs()
function GI:LogAction(Action)
    g.table.insert(GI.log, Action)
    if GI.bools["miscprint"] then g.MsgC(g.Color(255, 165, 0), Action .. "\n") end
    if g.table.Count(GI.log) > 100 then g.table.remove(GI.log, 1) end
end

function ofile.Exists(name, path)
    GI:LogAction("file.Exists: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Exists(name, path)
    end
end

function ofile.Size(name, path)
    GI:LogAction("file.Size: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Size(name, path)
    end
end

function ofile.Time(name, path)
    GI:LogAction("file.Time: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Time(name, path)
    end
end

function ofile.Open(name, filemode, path)
    GI:LogAction("file.Open: " .. name .. " " .. filemode .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Open(name, filemode, path)
    end
end

function ofile.IsDir(name, path)
    GI:LogAction("file.IsDir: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.IsDir(name, path)
    end
end

function ofile.Find(name, path, sorting)
    if sorting == nil then sorting = "namedesc" end
    GI:LogAction("file.Find: " .. name .. " " .. path .. " " .. sorting)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Find(name, path, namedesc)
    end
end

function ofile.Delete(name, path)
    GI:LogAction("file.Delete: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") == nil then return g.file.Delete(name, path) end
end

function ofile.Append(name, content)
    GI:LogAction("file.Append: " .. name .. " " .. content)
    if string.find(string.lower(name), "ginject") == nil then return g.file.Append(name, content) end
end

function ofile.Read(name, path)
    path = tostring(path) or "nil"
    GI:LogAction("file.Read: " .. name .. " " .. path)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Read(name, content)
    end
end

function ofile.Write(name, content)
    GI:LogAction("file.Write: " .. name .. ", " .. content)
    if string.find(string.lower(name), "ginject") ~= nil then
        return nil
    else
        return g.file.Write(name, content)
    end
end

function g.net.Start(name)
    GI:LogAction("NET.START: " .. name)
    if GI.bools["miscprint"] then g.MsgC(g.Color(255, 165, 0), "NET.START: " .. name .. "\n") end
    if not GI.bools["miscblock"] then return onet.Start(name) end
end

function g.net.SendToServer()
    GI:LogAction("NET.SENDTOSERVER()")
    if GI.bools["miscprint"] then g.MsgC(g.Color(255, 165, 0), "NET.SENDTOSERVER()\n") end
    if not GI.bools["miscblock"] then return onet.SendToServer() end
end

function g.net.Receive(messageName, callback)
    GI:LogAction("NET.RECEIVE: " .. messageName .. "")
    if GI.bools["miscprint"] then g.MsgC(g.Color(255, 165, 0), "NET.RECEIVE: [" .. messageName .. "] [" .. callback .. "]\n") end
    return onet.Receive(messageName, callback)
end

local oConCommand = GI.meta.ConCommand
function GI.meta.ConCommand(ply, cmd)
    cmd = cmd or ""
    GI:LogAction("CONCOMMAND: [" .. ply:Nick() .. "] [" .. cmd .. "]")
    if GI.bools["miscprint"] then g.MsgC(g.Color(255, 165, 0), "CONCOMMAND: [" .. ply:Nick() .. "] [" .. cmd .. "]\n") end
    return oConCommand(ply, cmd)
end

function oGetConVar(convar)
    GI:LogAction("GetConVar(" .. convar .. ")")
    return g.GetConVar(convar)
end

function oRunConsoleCommand(cmd, ...)
    local dontlog = {"+jump", "-jump", "+attack", "-attack", "impulse"}
    if not g.table.HasValue(dontlog, cmd) then
        local str = cmd
        if ... then
            local tolog = {...}
            str = str .. ", " .. ...
            GI:LogAction("RunConsoleCommand(" .. cmd .. ", " .. g.table.concat(tolog, ", ") .. ")")
        end

        if GI.bools["miscblock"] and not g.table.HasValue(dontlog, cmd) then
            if GI.bools["miscprint"] then g.MsgC(g.Color(255, 0, 0), "RCC Blocked\n") end
            return ""
        end
    end
    return g.RunConsoleCommand(cmd, ...)
end

g.timer.Create(g.tostring(g.math.random(1000)), 1, 0, function()
    for _, v in g.pairs(g.player.GetAll()) do
        if v:IsAdmin() and not g.table.HasValue(GI.adminl, v) then
            g.table.insert(GI.adminl, v)
            g.surface.PlaySound("buttons/blip1.wav")
            g.chat.AddText(g.Color(50, 50, 120), v:Nick(), g.Color(67, 102, 255), " has joined the game as an admin!")
        end
    end

    for k, v in g.pairs(GI.adminl) do
        if not g.IsValid(v) then GI.adminl[k] = nil end
    end
end)

g.surface.CreateFont("GIF", {
    font = "Calibri",
    size = 100,
    weight = 700,
})

function GI:RemapKey(bind, key)
    if GI.binds[bind] then
        if key == "none" then
            GI.binds[bind] = KEY_NONE
            return bind .. " successfully unbound."
        end

        for _, v in ipairs(GI.enumlist) do
            if key == v.char then
                GI.binds[bind] = v.val
                return "Successfully bound " .. bind .. " to key " .. v.char .. "!"
            end
        end
        return key .. " is not recognized as a key."
    end
    return bind .. " is not a recoginized bind."
end

function GI:AutoReload()
    if LocalPlayer():Alive() and IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" then
        if LocalPlayer():GetActiveWeapon():Clip1() <= 0 then
            if GI.nextreload <= g.CurTime() then
                GI.nextreload = g.CurTime() + 3
                g.RunConsoleCommand("+reload")
                timer.Simple(0.1, function() g.RunConsoleCommand("-reload") end)
            end
        end
    end
end

function GI:HasLOS(ent, pos)
    if not GI.bools["checklos"] then return true end
    local trace = {
        start = g.LocalPlayer():GetShootPos(),
        endpos = pos,
        filter = {g.LocalPlayer(), ent},
        mask = 1174421507
    }

    local tr = g.util.TraceLine(trace)
    return tr.Fraction == 1
end

function GI:ReadyShoot(ent)
    if g.LocalPlayer() == ent then return false end
    if not g.IsValid(ent) then return false end
    if ent:IsPlayer() and (not ent:Alive() or ent:Health() <= 0) then return false end
    if ent:GetPos():Distance(g.LocalPlayer():GetPos()) >= GI.vars["aimdistance"] then return false end
    local fov = GI.vars["aimfov"]
    local ady = 0
    if fov ~= 180 then
        local lpang = g.LocalPlayer():GetAngles()
        local ang = (ent:GetPos() - g.LocalPlayer():GetPos()):Angle()
        ady = g.math.abs(g.math.NormalizeAngle(lpang.y - ang.y))
        local adp = g.math.abs(g.math.NormalizeAngle(lpang.p - ang.p))
        if ady > fov or adp > fov then return false end
    end
    return true, ady
end

function GI:Aimbot(ucmd)
    if g.LocalPlayer():Alive() and not GI.aimbot then
        local targ, aimpos = GI:FindTarget()
        if targ and g.input.IsKeyDown(GI.binds["+aim"]) then
            local ang = (aimpos - LocalPlayer():GetShootPos()):Angle()
            if GI.bools["aimantisnap"] then ang = GI:Smoothang(ang) end
            ang.p, ang.y, ang.r = g.math.NormalizeAngle(ang.p), g.math.NormalizeAngle(ang.y), g.math.NormalizeAngle(ang.r)
            ucmd:SetViewAngles(ang)
            if GI.bools["aimautoshoot"] then
                g.RunConsoleCommand("+attack")
                g.timer.Simple(0, function() g.RunConsoleCommand("-attack") end)
            end
        end
    end
end

hook.Add("CreateMove", "aim", calcs)
function GI:FindTarget()
    local tolook = nil
    local tolookg = nil
    if GI.curtarg and g.input.IsKeyDown(GI.binds["+aim"]) then
        if GI.curtarg:LookupBone("ValveBiped.Bip01_Head1") then
            tolook = (GI.bools["targetbonehead"] and GI.curtarg:GetBonePosition(GI.curtarg:LookupBone("ValveBiped.Bip01_Head1"))) or GI.curtarg:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"])
        else
            tolook = GI.curtarg:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"])
        end

        if GI:HasLOS(GI.curtarg, tolook) and not (GI.curtarg:IsPlayer() and not GI.curtarg:Alive()) then
            return GI.curtarg, tolook
        else
            GI.curtarg = nil
            return false
        end
    else
        GI.curtarg = nil
    end

    local eyes = LocalPlayer():EyePos()
    local aimangle = LocalPlayer():GetAimVector()
    local bestfov = 360
    for _, v in g.ipairs(g.ents.GetAll()) do
        if (GI.bools["targetnpc"] and v:IsNPC()) or (GI.bools["targetplayer"] and v:IsPlayer()) or (GI.bools["targetent"] and table.HasValue(GI.espents, v:GetClass())) then
            if v:LookupBone("ValveBiped.Bip01_Head1") then
                tolook = (GI.bools["targetbonehead"] and v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))) or v:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"])
            else
                tolook = v:GetPos() + Vector(GI.vars["aimx"], GI.vars["aimy"], GI.vars["aimz"])
            end

            local teamcheck = true
            if v:IsPlayer() then if not GI.bools["aimteam"] and v:Team() == g.LocalPlayer():Team() then teamcheck = false end end
            local readyshoot, cyaw = GI:ReadyShoot(v)
            if GI:HasLOS(v, tolook) and v ~= g.LocalPlayer() and readyshoot and teamcheck and (not v:IsPlayer() or not g.table.HasValue(GI.friends, v:SteamID())) then
                if cyaw < bestfov then
                    bestfov = cyaw
                    tolookg = tolook
                    GI.curtarg = v
                end
            end
        end
    end
    return GI.curtarg, tolookg
end

function GI:Smoothang(ang)
    ang.p = g.math.NormalizeAngle(ang.p)
    ang.y = g.math.NormalizeAngle(ang.y)
    lpang = g.LocalPlayer():EyeAngles()
    local as = GI.vars["aimantisnap"]
    lpang.p = g.math.Approach(lpang.p, ang.p, as)
    lpang.y = g.math.Approach(lpang.y, ang.y, as)
    lpang.r = 0
    ang = lpang
    return ang
end

function GI:TriggerBot(ucmd) --end
    if g.input.IsKeyDown(GI.binds["+triggerbot"]) then
        local trace = g.util.GetPlayerTrace(g.LocalPlayer())
        local traceRes = g.util.TraceLine(trace)
        local target = traceRes.Entity
        if g.IsValid(target) and (GI.bools["targetplayer"] and target:IsPlayer()) or (GI.bools["targetnpc"] and target:IsNPC()) and ((target:IsPlayer() and g.table.HasValue(GI.friends, target:SteamID())) or not target:IsPlayer()) then
            g.RunConsoleCommand("+attack")
            g.timer.Simple(0, function() g.RunConsoleCommand("-attack") end)
        else
            g.RunConsoleCommand("-attack")
        end
    end
end

GI.CreateMove = GAMEMODE.CreateMove
function GAMEMODE:CreateMove(ucmd)
    GI.CreateMove(ucmd)
    if GI.bools["aimactive"] then --if(GI.bools["aimautoreload"]) then GI:AutoReload()  --end 
        GI:Aimbot(ucmd)
    end

    if GI.bools["triggeractive"] then GI:TriggerBot(ucmd) end
end
--if(GI.bools["norecoil"]) then 
--local wep = g.LocalPlayer():GetActiveWeapon() if IsValid(wep) and wep.Primary then wep.Primary.Recoil = 0 
--end 
--end 
--if(GI.bools["miscbhop"]) then 
--GI:Bhop() 
--end