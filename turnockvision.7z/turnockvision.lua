--[[
	MOD/lua/turnock/turnockvision.lua
	Atomsk | STEAM_0:1:78045322 <86.158.36.135:27005> | [04-02-14 09:21:28PM]
	===BadFile===
]]


print("TURNOCK VISION ACTIVATED")

turnock = {}
turnock.vision = {}
turnock.vision.toggle = true
turnock.vision.materialprop = Material("/models/wireframe")

function TVision()
surface.PlaySound("garrysmod/ui_click.wav")
print(turnock.vision.toggle)
	if turnock.visiontoggle == false then
		print("off")
		turnock.visiontoggle = true
		hook.Remove("HUDPaint","turnockvision")

		for k,v in pairs(ents.FindByClass("prop_physics")) do
			v:SetNoDraw(false)
		end
		
	elseif turnock.vision.toggle == true then
		turnock.vision.toggle = false
		function TurnockVision()
		render.MaterialOverride(turnock.vision.materialprop)
		cam.Start3D()
		cam.IgnoreZ(true)
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() then		
				render.SetColorModulation(255,255,255)
				render.SetBlend(0.5)			
				v:DrawModel()	
				v:SetNoDraw(true)
			end
		end
		
		for k,v in pairs(ents.FindByClass("prop_physics")) do
			if v:IsValid() then
				render.SetColorModulation(255,255,255)
				render.SetBlend(0.5)
				v:DrawModel()
				v:SetNoDraw(true)
			end
		end
	
		cam.End3D()
		cam.IgnoreZ(false)
		end
		hook.Add("HUDPaint","wallhack",TurnockVision)
	end
end
concommand.Add("turnock",TVision)
