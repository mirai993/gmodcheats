local DeadColors = CreateClientConVar("dead_esp", 1, true, false)
local DeadColors = CreateClientConVar("dead_chams", 1, true, false)
local DeadColors = CreateClientConVar("dead_chams_wire", 0, true, false)
local DeadColors = CreateClientConVar("dead_tracers", 0, true, false)
local DeadColors = CreateClientConVar("dead_tracers_traceteam", 0, true, false)
local DeadColors = CreateClientConVar("dead_esp_line", 0, true, false)
local DeadColors = CreateClientConVar("dead_line_traceteam", 0, true, false)
local DeadColors = CreateClientConVar("dead_esp_ents", 1, true, false)
local DeadColors = CreateClientConVar("dead_xray", 1, true, false)
local DeadColors = CreateClientConVar("dead_aimbot", 1, true, false)
local DeadColors = CreateClientConVar("dead_aimbot_onshoot", 0, true, false)
local boneaim    = CreateClientConVar("dead_aimbot_bone", "ValveBiped.Bip01_Head1", true, false)
local l4dglow    = CreateClientConVar("dead_glow", 0, true, false)
local l4dwglow   = CreateClientConVar("dead_glow_weapons", 0, true, false)
local wepwh      = CreateClientConVar("dead_ents_wallhack", 0, true, false)
local triggerbot = CreateClientConVar("dead_triggerbot", 1, true, false)
local infov1     = CreateClientConVar("dead_aimbot_infov", 0, true, false)
local infov2     = CreateClientConVar("dead_aimbot_fov", 45, true, false)

surface.CreateFont("Trebuchet19", {font="TabLarge", size=13, weight=700})

local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end

local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

local function InFov(ent)
	for k,v in pairs(ents.FindInCone(LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector(), 3000, GetConVarNumber("dead_aimbot_fov")))  do
		if(v:IsPlayer() && ent == v) then
			return true
		else
			return false
		end
	end
end

local function AimHOOK()
	for k,v in pairs(player.GetAll()) do
		local bone = tostring(boneaim:GetString())
		if IsVisible( v ) and LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Team() ~= TEAM_SPECTATOR and GetConVarNumber("dead_aimbot") == 1 and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_tool" and LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" and LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_crowbar" then
			if GetConVarNumber("dead_aimbot_onshoot") >= 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) then
					if(GetConVarNumber("dead_aimbot_infov") == 1) then
						if(InFov(v)) then
							local head = v:LookupBone(bone)
							local headpos,targetheadang = v:GetBonePosition(head)
							LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
						end
					else
						local head = v:LookupBone(bone)
						local headpos,targetheadang = v:GetBonePosition(head)
						LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
					end
				end
			else
				if(GetConVarNumber("dead_aimbot_infov") == 1) then
					if(InFov(v)) then
						local head = v:LookupBone(bone)
						local headpos,targetheadang = v:GetBonePosition(head)
						LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
					end
				else
					local head = v:LookupBone(bone)
					local headpos,targetheadang = v:GetBonePosition(head)
					LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
				end
	/*				if GetConVarNumber("dead_aimbot_shoot") == 1 then
						local Eye = LocalPlayer():GetEyeTrace().Entity
						if Eye:IsValid() and Eye:IsPlayer() then
							RunConsoleCommand("+attack")
						else
							if Eye ~= Eye:IsValid() and Eye ~= Eye:IsPlayer() then
								RunConsoleCommand("-attack")
							end
						end
					else
						if GetConVarNumber("equin0x_aimbot_shoot") == 2 then
							if IsVisible(v) then
								RunConsoleCommand("+attack")
							else
								RunConsoleCommand("-attack")
							end
						end
					end */
			end
		end
	end
end
hook.Add("Think", "AimHOOK", AimHOOK)

hook.Add("HUDPaint", "DeadESP", function()
	for k,v in pairs(player.GetAll()) do
		if GetConVarNumber("dead_esp") == 1 then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:EyePos()):ToScreen()
				if v:IsAdmin() then
					draw.DrawText(v:Name(), "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("Rank: Admin", "Trebuchet19", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				elseif v:IsSuperAdmin() then
					draw.DrawText(v:Name(), "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("Rank: SuperAdmin", "Trebuchet19", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				else
					draw.DrawText(v:Name(), "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					draw.DrawText("Rank: User", "Trebuchet19", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
				draw.DrawText("Health: " .. v:Health(), "Trebuchet19", ESP.x, ESP.y -34, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				if(v:GetActiveWeapon():IsValid()) then
					draw.DrawText("Weapon: " .. v:GetActiveWeapon():GetClass(), "Trebuchet19", ESP.x, ESP.y -12, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "DeadCHAMS", function()
	for k,v in pairs(player.GetAll()) do
	if GetConVarNumber("dead_chams") >= 1 then
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				v:SetMaterial("models/debug/debugwhite")
				v:SetColor(Color(20, 71, 244, 255))
				render.MaterialOverride("models/debug/debugwhite")
				render.SuppressEngineLighting( false )
				render.SetBlend( 0.3 )
				render.SetColorModulation( 0, 1, 0 )
				v:DrawModel()
				if GetConVarNumber("dead_chams_wire") >= 1 then
					v:SetMaterial("models/wireframe")
					render.MaterialOverride("models/wireframe")
					v:DrawModel()
				end
			cam.End3D()
		end
	end
	end
end)

hook.Add("HUDPaint", "L4DGlow", function()
	for k,v in pairs(player.GetAll()) do
		if(MESPCheck(v) && GetConVarNumber("dead_glow") == 1) then
			effects.halo.Add({v}, team.GetColor(v:Team()), 1, 1, 5, true, true)

		end
	end
end)

local function FireEx()
	RunConsoleCommand("+attack")
end

local function StopFireEx()
	RunConsoleCommand("-attack")
end

hook.Add("Think", "Triggerbot", function()
	if(GetConVarNumber("dead_triggerbot") == 1) then
	local pos = LocalPlayer():GetShootPos()
	local ang = LocalPlayer():GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos+(ang*9999999999999)
	local trace = util.TraceLine(tracedata)
	if(trace.HitNonWorld) then
		target = trace.Entity
		if(target:IsPlayer()) then
			FireEx()
			timer.Simple(0.1, StopFireEx)
		end
	end
end
end)

hook.Add("HUDPaint", "EntWH", function()
	for k,v in pairs(ents.GetAll()) do
		if(GetConVarNumber("dead_ents_wallhack") == 1 && string.find(v:GetClass(), "weapon_")) then
			cam.Start3D(EyePos(), EyeAngles())
				v:DrawModel()
			cam.End3D()
		end
	end
end)

hook.Add("HUDPaint", "DeadTRACERS", function()
	if GetConVarNumber("dead_tracers") >= 1 then
		for k,v in pairs(player.GetAll()) do
			local ETrace = v:EyePos():ToScreen()
			local x = ScrW() / 2
			local y = ScrH() / 2
			if GetConVarNumber("dead_tracers_traceteam") >= 1 then
				surface.SetDrawColor(team.GetColor(v:Team()))
			else
				surface.SetDrawColor(255, 255, 255, 255)
			end
			if MESPCheck(v) then
				if GetConVarNumber("dead_tracers_highlight") >= 1 then
				local trace = LocalPlayer():GetEyeTrace().Entity
					if trace:IsPlayer() && trace:IsValid() && LocalPlayer():GetActiveWeapon():IsValid() then
						surface.SetDrawColor(19, 22, 22, 255)
						surface.DrawLine(ETrace.x, ETrace.y, x, y)
						surface.SetDrawColor(255, 255, 255, 255)
					end
				end
				surface.DrawLine(ETrace.x, ETrace.y, x, y)
			end
		end
	end
end)

hook.Add("HUDPaint", "DeadLESP", function()
	for k,v in pairs(player.GetAll()) do
	if GetConVarNumber("dead_esp_line") >= 1 then
			local eye = v:EyePos():ToScreen()
			local trace = v:GetEyeTrace()
			if MESPCheck(v) then
				if GetConVarNumber("dead_esp_line_traceteam") >= 1 then
					surface.SetDrawColor(team.GetColor(v:Team()))
					surface.DrawLine(eye.x, eye.y, eye.x, eye.y -200)
				else
					surface.SetDrawColor(255, 255, 255, 255)
					surface.DrawLine(eye.x, eye.y, eye.x, eye.y -200)
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "DeadCROSSHAIR", function()
	local x = ScrW() / 2
	local y = ScrH() / 2
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawRect(x, y, 3, 3, 0)
end)

local function propcheck(v)
	if(string.find(v:GetClass(), "weapon_") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "player") or string.find(v:GetClass(), "physgun") or string.find(v:GetClass(), "viewmodel")) then
		return false
	else
		return true
	end
end

local function XProps()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(ents.GetAll()) do
				if(v:IsValid() && propcheck(v)) then
					if(GetConVarNumber("dead_xray") == 1) then
						if(string.find(v:GetClass(), "func_door")) then
							v:SetColor(Color(221, 0, 0, 190))
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
						else
							v:SetColor(Color(0, 0, 0, 190))
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
						end
					else
						v:SetColor(Color(255, 255, 255, 255))
					end
			end
		end

	cam.End3D()
end
hook.Add("HUDPaint", "XRAYProps", XProps)

hook.Add("HUDPaint", "WepGlow", function()
	for k,v in pairs(ents.GetAll()) do
		if(GetConVarNumber("dead_glow_weapons") == 1 && string.find(v:GetClass(), "weapon_")) then
			effects.halo.Add({v}, Color(255, 0, 0), 1, 1, 3, true, true)
		end
	end
end)


/*
	I was lazy, So I updated slobbot's ent esp.
*/
function RPSlobBotAllowed(ent)
	if !(ent:IsValid()) then return false end 
	if (ent:GetClass() == nil) or (ent:GetClass() == "") or (string.find(ent:GetClass(), "physgun")) or (ent:GetOwner() == LocalPlayer()) then 
		return false 
	end
	if string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "food") or
	string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "gun") or
	string.find(ent:GetClass(), "melon") or string.find(ent:GetClass(), "money") or
	string.find(ent:GetClass(), "spawned") or string.find(ent:GetClass(), "microwave") or
	string.find(ent:GetClass(), "ent") or string.find(ent:GetClass(), "weapon_ttt") or

	ent:GetModel() == "models/props/cs_assault/money.mdl" then
		return true
	else
		return false
	end
end

hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if RPSlobBotAllowed(ent) and GetConVarNumber("dead_esp_ents") == 1 then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props/cs_assault/money.mdl" then
						draw.DrawText("Class: " .. ent:GetClass(), "Trebuchet19", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money", "Trebuchet19", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)

local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                                end
                        end
                end
        end
          
  
                //Add a name for anyone we tracked
               // cam.Start2D()
                    //    local pos = (pl:GetPos()+Vector(0,0,100)):ToScreen()
                     //   draw.DrawText( pl:Nick(), "ScoreboardText", pos['x'], pos['y'], team.GetColor( pl:Team() ), TEXT_ALIGN_CENTER )
               // cam.End2D()
      //  end
end)