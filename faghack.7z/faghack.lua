print("hello person FagHack has loaded ULTRA PASTE RAHH")


-- CONVARSZ --

CreateClientConVar( "esp", 0, true, false )
CreateClientConVar( "norecoil", 0, true, false )
CreateClientConVar( "espbox", 0, true, false )
CreateClientConVar( "aimbot", 0, true, false )
CreateClientConVar( "legitaimbot", 0, true, false )
CreateClientConVar( "BHop", 0, true, false )
CreateClientConVar( "BHop_AC", 0, true, false )
CreateClientConVar( "triggerbot", 0, true, false )
CreateClientConVar( "propchams", 0, true, false )
CreateClientConVar( "chams", 0, true, false )
local renderdist = CreateClientConVar("RenderDistance", 50000, true, false)
CreateClientConVar( "deppfov", 0, true, false )
CreateClientConVar( "deppfov1", 0, true, false )
CreateClientConVar("Aimbot", 0, true, false)
CreateClientConVar("FOV_Aimbot", 0, true, false)
CreateClientConVar("AimAssist", 0, true, false)
CreateClientConVar("Aimbot_Ignore_Friends", 0, true, false)
CreateClientConVar("Aimbot_Ignore_Staff", 0, true, false)
CreateClientConVar("Aimbot_Ignore_Team", 0, true, false)
CreateClientConVar("Aimbot_Ignore_Through_Walls", 0, true, false)
CreateClientConVar("Aimbot_Ignore_Ghosts", 0, true, false)
CreateClientConVar("Aimbot_Whitelist", 0, true, false)
CreateClientConVar("deppThirdPerson", 0, true, false)
CreateClientConVar("Chatspam", 0, true, false)
CreateClientConVar("killsay", 0, true, false)
CreateClientConVar("nospread", 0, true, false)
CreateClientConVar("killsaytap", 0, true, false)

-- LOCALZZ --


local ply = LocalPlayer()
local function RandomString() return tostring(math.random(-9999999999, 9999999999)) end
local cObs, cStaff = RandomString(), RandomString()
local function UtilityCheck(v)
    if v != ply and v:Alive() and v:IsValid() then
        return true
    else
        return false
    end
end
local me = LocalPlayer()
local AimKey = AimKey or 12
local AimBone = AimBone or ("ValveBiped.Bip01_Head1") 
local AimBoneType = AimBoneType or 1 
OtherPlayers = OtherPlayers or {}
NoShootGuys = NoShootGuys or {}
EntsToShow = EntsToShow or {}
OtherEnts = OtherEnts or {}
OtherPlayers = OtherPlayers or {}
NoShootGuys = NoShootGuys or {}
EntsToShow = EntsToShow or {}
OtherEnts = OtherEnts or {}
local function PermissionCheck(v)
    if v:IsAdmin()  or string.find(v:GetUserGroup(), "mod") or string.find(v:GetUserGroup(), "admin") or string.find(v:GetUserGroup(), "staff") then
        return true
    else
        return false
    end
end
function GhostCheck(v)
	if not IsValid(v) or v:GetNoDraw() or v:GetRenderMode() == RENDERMODE_NONE then
		return true
	else
		return false
	end
end



-- MENUU --

function hackframe()
        local frame1 = vgui.Create("DFrame")
 
        frame1:SetPos(650,350)
        frame1:SetSize(400,260)
        frame1:SetTitle("FagHack")
        frame1:MakePopup()
        frame1:SetVisible( true )
        frame1:SetDraggable( true )
        frame1:ShowCloseButton( true )
        frame1:MakePopup()


local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( frame1 )
PropertySheet:SetPos( 5, 30 )
PropertySheet:SetSize( 390,230 )
  

local SheetItemOne = vgui.Create( "DPanel" )
SheetItemOne.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 100, 255, self:GetAlpha() ) ) end 
PropertySheet:AddSheet( "Aim", SheetItemOne, false, false, false, "aimzz" )

local SheetItem2 = vgui.Create( "DPanel" )
SheetItem2.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 100, 255, self:GetAlpha() ) ) end 
PropertySheet:AddSheet( "Visuals", SheetItem2, false, false, false, "visualzz" )

local SheetItem3 = vgui.Create( "DPanel" )
SheetItem3.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 100, 255, self:GetAlpha() ) ) end 
PropertySheet:AddSheet( "Misc", SheetItem3, false, false, false, "randomstuff" )

local SheetItem4 = vgui.Create( "DPanel" )
SheetItem4.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 100, 255, self:GetAlpha() ) ) end 
PropertySheet:AddSheet( "HvH", SheetItem4, false, false, false, "HvhWOW" )

local SheetItem5 = vgui.Create( "DPanel" )
SheetItem5.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 100, 255, self:GetAlpha() ) ) end 
PropertySheet:AddSheet( "Config", SheetItem5, false, false, false, "setingstuf" )


  local buttonhack = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack:SetPos( 20,10 )
  buttonhack:SetText( "Aimbot" )
  buttonhack:SetConVar( "aimbot" ) -- ConCommand must be a 1 or 0 value
  buttonhack:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack2 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack2:SetPos( 20,10 )
  buttonhack2:SetText( "Esp" )
  buttonhack2:SetConVar( "esp" ) -- ConCommand must be a 1 or 0 value
  buttonhack2:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack3 = vgui.Create( "DCheckBoxLabel", SheetItem3 )
  buttonhack3:SetPos( 20,10 )
  buttonhack3:SetText( "Bhop" )
  buttonhack3:SetConVar( "BHop" ) -- ConCommand must be a 1 or 0 value
  buttonhack3:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack4 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack4:SetPos( 20,30 )
  buttonhack4:SetText( "Triggerbot" )
  buttonhack4:SetConVar( "triggerbot" ) -- ConCommand must be a 1 or 0 value
  buttonhack4:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack5 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack5:SetPos( 20,30 )
  buttonhack5:SetText( "Esp box" )
  buttonhack5:SetConVar( "espbox" ) -- ConCommand must be a 1 or 0 value
  buttonhack5:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack6 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack6:SetPos( 20,50 )
  buttonhack6:SetText( "BodytoHead Assist" )
  buttonhack6:SetConVar( "legitaimbot" ) -- ConCommand must be a 1 or 0 value
  buttonhack6:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack7 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack7:SetPos( 20,50 )
  buttonhack7:SetText( "Prop Chams" )
  buttonhack7:SetConVar( "propchams" ) -- ConCommand must be a 1 or 0 value
  buttonhack7:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack8 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack8:SetPos( 20,70 )
  buttonhack8:SetText( "Chams" )
  buttonhack8:SetConVar( "chams" ) -- ConCommand must be a 1 or 0 value
  buttonhack8:SizeToContents() -- Make its size to the contents. Duh?

  local DermaButton = vgui.Create( "DButton", SheetItem3 )
  DermaButton:SetParent( SheetItem3 ) -- Set parent to our "DermaPanel"
  DermaButton:SetText( "Anti sg" )
  DermaButton:SetPos( 20, 150 )
  DermaButton:SetSize( 100, 50 )
  DermaButton.DoClick = function ()
    RunConsoleCommand( "open_image_menu" ) -- What happens when you press the button
end
 

  local buttonhack9 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack9:SetPos( 20,70 )
  buttonhack9:SetText( "Fov Aimbot" )
  buttonhack9:SetConVar( "FOV_Aimbot" ) -- ConCommand must be a 1 or 0 value
  buttonhack9:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack10 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack10:SetPos( 20,90 )
  buttonhack10:SetText( "Thirdperson" )
  buttonhack10:SetConVar( "deppThirdperson" ) -- ConCommand must be a 1 or 0 value
  buttonhack10:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack11 = vgui.Create( "DCheckBoxLabel", SheetItem2 )
  buttonhack11:SetPos( 20,110 )
  buttonhack11:SetText( "Fov" )
  buttonhack11:SetConVar( "deppfov1" ) -- ConCommand must be a 1 or 0 value
  buttonhack11:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack12 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack12:SetPos( 20,90 )
  buttonhack12:SetText( "Ignore Friends" )
  buttonhack12:SetConVar( "Aimbot_Ignore_Friends" ) -- ConCommand must be a 1 or 0 value
  buttonhack12:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack13 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack13:SetPos( 20,110 )
  buttonhack13:SetText( "Ignore Staff" )
  buttonhack13:SetConVar( "Aimbot_Ignore_Staff" ) -- ConCommand must be a 1 or 0 value
  buttonhack13:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack14 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack14:SetPos( 20,131 )
  buttonhack14:SetText( "Ignore Thru Walls" )
  buttonhack14:SetConVar( "Aimbot_Ignore_Through_Walls" ) -- ConCommand must be a 1 or 0 value
  buttonhack14:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack15 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack15:SetPos( 20,150 )
  buttonhack15:SetText( "Ignore Team" )
  buttonhack15:SetConVar( "Aimbot_Ignore_Team" ) -- ConCommand must be a 1 or 0 value
  buttonhack15:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack16 = vgui.Create( "DCheckBoxLabel", SheetItem3 )
  buttonhack16:SetPos( 20,30 )
  buttonhack16:SetText( "Bhop AC" )
  buttonhack16:SetConVar( "BHop_AC" ) -- ConCommand must be a 1 or 0 value
  buttonhack16:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack16 = vgui.Create( "DCheckBoxLabel", SheetItem3 )
  buttonhack16:SetPos( 20,50 )
  buttonhack16:SetText( "ChatSpam" )
  buttonhack16:SetConVar( "Chatspam" ) -- ConCommand must be a 1 or 0 value
  buttonhack16:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack16 = vgui.Create( "DCheckBoxLabel", SheetItem3 )
  buttonhack16:SetPos( 20,70 )
  buttonhack16:SetText( "Killsay" )
  buttonhack16:SetConVar( "killsay" ) -- ConCommand must be a 1 or 0 value
  buttonhack16:SizeToContents() -- Make its size to the contents. Duh?

  local buttonhack17 = vgui.Create( "DCheckBoxLabel", SheetItemOne )
  buttonhack17:SetPos( 20,170 )
  buttonhack17:SetText( "No Recoil" )
  buttonhack17:SetConVar( "norecoil" ) -- ConCommand must be a 1 or 0 value
  buttonhack17:SizeToContents() -- Make its size to the contents. Duh?
  
  local buttonhack8 = vgui.Create("DNumSlider", SheetItem2)
  buttonhack8:SetMinMax(20, 179)
  buttonhack8.TextArea:SetTextColor(Color(200, 200, 200))
  buttonhack8:SetPos(20, 150)
  buttonhack8:SetSize(200, 20)
  buttonhack8:SetText("Field of View")
  buttonhack8:SetConVar("deppfov")
  buttonhack8:SetDecimals(0)
 
end
concommand.Add("menuopen", hackframe)

-- esp

hook.Add( "HUDPaint", "Wallhack", function()
    if ConVarExists( "esp" ) and GetConVar("esp"):GetInt() == 1 then
        
        for k,v in pairs ( player.GetAll() ) do
 
                local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
                local Name = ""
 
                if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
                draw.DrawText( Name, "ChatFont", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
        end
     end
end )

-- aimbot

SelectedPlayers = vgui.Create("DListView")
	SelectedPlayers:SetSize(0, 0)
	SelectedPlayers:SetPos(0, 0)
	SelectedPlayers:SetMultiSelect(false)
	SelectedPlayers:AddColumn("Whitelisted")
	local AllPlayers = vgui.Create("DListView")
	AllPlayers:SetSize(0, 0)
	AllPlayers:SetPos(75, 0)
	AllPlayers:SetMultiSelect(false)
	AllPlayers:AddColumn("Players")

for _, v in pairs(player.GetAll()) do
		if UtilityCheck(v) == true and not table.HasValue( NoShootGuys, v ) then
			local line = AllPlayers:AddLine(v:Nick())
			line.player = v 
		end
	end
	AllPlayers.DoDoubleClick = function(parent, index, list)
		local line = parent:GetLine(index)
		local player = line.player 
		table.insert(NoShootGuys, player) 
		table.remove(OtherPlayers, table.KeyFromValue(OtherPlayers, player))
		line.player = nil
		local selectedLine = SelectedPlayers:AddLine(player:Nick())
		selectedLine.player = player 
		parent:RemoveLine(index)
	end
	for _, v in pairs(NoShootGuys) do
		if UtilityCheck(v) == true and not table.HasValue( OtherPlayers, v ) then
			local line = SelectedPlayers:AddLine(v:Nick())
			line.player = v
		end
	end
	SelectedPlayers.DoDoubleClick = function(parent, index, list)
		local line = parent:GetLine(index)
		local player = line.player
		table.insert(OtherPlayers, player) 
		table.remove(NoShootGuys, table.KeyFromValue(NoShootGuys, player))
		line.player = nil
		local allLine = AllPlayers:AddLine(player:Nick())
		allLine.player = player 
		parent:RemoveLine(index)
	end
	hook.Add( "Think", "ThinkAboutIt", function()
		if AimBoneType == 1 then
			AimBone = ("ValveBiped.Bip01_Head1")
		end
		if AimBoneType == 2 then
			AimBone = ("ValveBiped.Bip01_Neck1")
		end
		if AimBoneType == 3 then
			AimBone = ("ValveBiped.Bip01_Spine")
		end
		if AimBoneType == 4 then
			AimBone = ("ValveBiped.Bip01_L_Forearm")
		end
		if AimBoneType == 5 then
			AimBone = ("ValveBiped.Bip01_R_UpperArm")
		end
		if AimBoneType == 6 then
			AimBone = ("ValveBiped.Bip01_Pelvis")
		end
		if AimBoneType == 7 then
			AimBone = ("ValveBiped.Bip01_L_Calf")
		end
		if AimBoneType == 8 then
			AimBone = ("ValveBiped.Bip01_R_Calf")
		end
		local Target = nil
		local NearestTargetDist = math.huge
		if GetConVarNumber("Aimbot") == 1 then
			if input.IsButtonDown(KEY_LALT) and ply:IsTyping() == false then
				for k, v in pairs( player.GetAll() ) do
					if UtilityCheck(v) == true then
						if GetConVarNumber("FOV_Aimbot") == 0 then
							local TargetDist = ( Vector( ply:GetPos() ):Distance( Vector( v:GetPos() ) ) )
							if TargetDist > 0 and TargetDist < NearestTargetDist then
								if GetConVarNumber("Aimbot_Ignore_Friends") == 1 and v:IsPlayer() and v:GetFriendStatus() == "none" or GetConVarNumber("Aimbot_Ignore_Friends") == 0 then 
									if GetConVarNumber("Aimbot_Ignore_Staff") == 1 and PermissionCheck(v) == false or GetConVarNumber("Aimbot_Ignore_Staff") == 0 then
										if GetConVarNumber("Aimbot_Ignore_Ghosts") == 1 and GhostCheck(v) == false or GetConVarNumber("Aimbot_Ignore_Ghosts") == 0 then
											if GetConVarNumber("Aimbot_Ignore_Team") == 1 and v:IsPlayer() and v:Team() ~= ply:Team() or GetConVarNumber("Aimbot_Ignore_Team") == 0 then 
												local trace = util.TraceLine( {
													start = ply:GetShootPos(),
													endpos = v:GetPos(),
													filter = function( ent ) if ( ent:GetClass() == "prop_physics" ) then return true end end
												} )
												if trace and (GetConVarNumber("Aimbot_Ignore_Through_Walls") == 1 and trace.Fraction == 1 or GetConVarNumber("Aimbot_Ignore_Through_Walls") == 0) then
													if GetConVarNumber("Aimbot_Whitelist") == 1 and not table.HasValue(NoShootGuys, v) or GetConVarNumber("Aimbot_Whitelist") == 0 then
														NearestTargetDist = TargetDist
															if NearestTargetDist == TargetDist then
															Target = v
														end
														if Target ~= nil then
															if Target:LookupBone(AimBone) == nil then
																local TargetBody = Target:GetPos() + Vector( 0, 0, 35 )
																ply:SetEyeAngles((TargetBody - ply:GetShootPos()):Angle())
															else 
																local TargetHead = Target:LookupBone(AimBone)
																local TargetHeadPos,TargetHeadAng = Target:GetBonePosition(TargetHead)
																ply:SetEyeAngles((TargetHeadPos - ply:GetShootPos()):Angle())
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
						if GetConVarNumber("FOV_Aimbot") == 1 then
							local screenCenter = Vector(ScrW() / 2, ScrH() / 2, 0)
							local closestDist = math.huge
							local closestPlayer = nil
							for k, v in pairs(player.GetAll()) do
								if UtilityCheck(v) == true then
									if GetConVarNumber("Aimbot_Ignore_Friends") == 1 and v:IsPlayer() and v:GetFriendStatus() == "none" or GetConVarNumber("Aimbot_Ignore_Friends") == 0 then 
										if GetConVarNumber("Aimbot_Ignore_Staff") == 1 and PermissionCheck(v) == false or GetConVarNumber("Aimbot_Ignore_Staff") == 0 then
											if GetConVarNumber("Aimbot_Ignore_Ghosts") == 1 and GhostCheck(v) == false or GetConVarNumber("Aimbot_Ignore_Ghosts") == 0 then
												if GetConVarNumber("Aimbot_Ignore_Team") == 1 and v:IsPlayer() and v:Team() ~= ply:Team() or GetConVarNumber("Aimbot_Ignore_Team") == 0 then 
													local trace = util.TraceLine({
														start = ply:GetShootPos(),
														endpos = v:GetPos(),
														filter = function(ent) if ent:GetClass() == "prop_physics" then return true end end
													})
													if trace and (GetConVarNumber("Aimbot_Ignore_Through_Walls") == 1 and trace.Fraction == 1 or GetConVarNumber("Aimbot_Ignore_Through_Walls") == 0) then
														if GetConVarNumber("Aimbot_Whitelist") == 1 and not table.HasValue(NoShootGuys, v) or GetConVarNumber("Aimbot_Whitelist") == 0 then
															local bone = v:LookupBone(AimBone)
															local targetPos = bone and v:GetBonePosition(bone) or v:EyePos()
															local screenPos = targetPos:ToScreen()
															local dist = screenCenter:Distance(Vector(screenPos.x, screenPos.y, 0))
															if dist < closestDist then
																closestDist = dist
																closestPlayer = v
															end
														end
													end
												end
											end
										end
									end
								end
							end
							if closestPlayer ~= nil then
								local bone = closestPlayer:LookupBone(AimBone)
								local targetPos = bone and closestPlayer:GetBonePosition(bone) or closestPlayer:EyePos()
								ply:SetEyeAngles((targetPos - ply:GetShootPos()):Angle())
							end
						end
					end
				end
			end
		end
	end)



--bhop

function BHop()
	if GetConVarNumber("BHop") == 1 and input.IsKeyDown( KEY_SPACE ) and GetConVarNumber("BHop_AC") == 1 then
		if ply:IsTyping() == false and ply:IsOnGround() then
	 		RunConsoleCommand("+jump")
	 		timer.Create("Bhop", 0, math.random( .280, .290 ), function()
	 		 	RunConsoleCommand("-jump")
			end)
		end
	elseif GetConVarNumber("BHop") == 1 and input.IsKeyDown( KEY_SPACE ) and GetConVarNumber("BHop_AC") == 0 then
		if ply:IsTyping() == false and ply:IsOnGround() then
			RunConsoleCommand("+jump")
			timer.Create("Bhop", 0, .01, function()
				RunConsoleCommand("-jump")
			end)
		end
	end
end
hook.Add("Think", "BHop", BHop)
--triggerbot

-- SCRAPED DIDNT WORK

--esp

function LoadESP()

        if GetConVar("espbox"):GetInt() == 1 then

                for k, v in pairs( ents.GetAll() ) do

                        if v:IsValid() && v != LocalPlayer() && (v:IsPlayer() || v:IsNPC()) then

                                local ent = v
                                local MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8 = getPosition( ent )
                              
                                local healthColor = Color((1-(ent:Health()/ent:GetMaxHealth()))*255, (ent:Health()/ent:GetMaxHealth())*255, 0)
                                local ESPPos = MinY

                                surface.SetDrawColor(healthColor)

                                if GetConVar("espbox"):GetInt() == 1 then

                                        surface.DrawLine( V4.x, V4.y, V6.x, V6.y )
                                        surface.DrawLine( V1.x, V1.y, V8.x, V8.y )
                                        surface.DrawLine( V6.x, V6.y, V8.x, V8.y )
                                        surface.DrawLine( V4.x, V4.y, V1.x, V1.y )

                                        surface.DrawLine( V3.x, V3.y, V5.x, V5.y )
                                        surface.DrawLine( V2.x, V2.y, V7.x, V7.y )
                                        surface.DrawLine( V3.x, V3.y, V2.x, V2.y )
                                        surface.DrawLine( V5.x, V5.y, V7.x, V7.y )

                                        surface.DrawLine( V3.x, V3.y, V4.x, V4.y )
                                        surface.DrawLine( V2.x, V2.y, V1.x, V1.y )
                                        surface.DrawLine( V7.x, V7.y, V8.x, V8.y )
                                        surface.DrawLine( V5.x, V5.y, V6.x, V6.y )

                                else

                                        surface.DrawLine( MaxX, MaxY, MinX, MaxY )
                                        surface.DrawLine( MaxX, MaxY, MaxX, MinY )
                                        surface.DrawLine( MinX, MinY, MaxX, MinY )
                                        surface.DrawLine( MinX, MinY, MinX, MaxY )

                                end

                                
                                

                        end

                end

        end

end


function getPosition(ent)

        if ent:IsValid() then
                local Points = {
                        Vector( ent:OBBMaxs().x, ent:OBBMaxs().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMaxs().y, ent:OBBMins().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMins().y, ent:OBBMins().z ),
                        Vector( ent:OBBMaxs().x, ent:OBBMins().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMins().x, ent:OBBMins().y, ent:OBBMins().z ),
                        Vector( ent:OBBMins().x, ent:OBBMins().y, ent:OBBMaxs().z ),
                        Vector( ent:OBBMins().x, ent:OBBMaxs().y, ent:OBBMins().z ),
                        Vector( ent:OBBMins().x, ent:OBBMaxs().y, ent:OBBMaxs().z )
                }
                local MaxX, MaxY, MinX, MinY
                local V1, V2, V3, V4, V5, V6, V7, V8
                for k, v in pairs( Points ) do
                        local ScreenPos = ent:LocalToWorld( v ):ToScreen()
                        if MaxX != nil then
                                MaxX, MaxY, MinX, MinY = math.max( MaxX, ScreenPos.x ), math.max( MaxY, ScreenPos.y), math.min( MinX, ScreenPos.x ), math.min( MinY, ScreenPos.y)
                        else
                                MaxX, MaxY, MinX, MinY = ScreenPos.x, ScreenPos.y, ScreenPos.x, ScreenPos.y
                        end

                        if V1 == nil then
                                V1 = ScreenPos
                        elseif V2 == nil then
                                V2 = ScreenPos
                        elseif V3 == nil then
                                V3 = ScreenPos
                        elseif V4 == nil then
                                V4 = ScreenPos
                        elseif V5 == nil then
                                V5 = ScreenPos
                        elseif V6 == nil then
                                V6 = ScreenPos
                        elseif V7 == nil then
                                V7 = ScreenPos
                        elseif V8 == nil then
                                V8 = ScreenPos
                        end
                end
                return MaxX, MaxY, MinX, MinY, V1, V2, V3, V4, V5, V6, V7, V8
        end

end
hook.Add("HUDPaint", "LoadESP", LoadESP)
--legitaim

function legitaimbot() -- Starting the function
     if ConVarExists( "legitaimbot" ) and GetConVar("legitaimbot"):GetInt() == 1 then
        local ply = LocalPlayer() -- Getting ourselves
        local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
        local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
        if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
                local target = traceRes.Entity -- It's obviously an entity.
                if target:IsPlayer() then -- But it must be a player.
                        local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
                        local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
                        ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
                end
        end
      end
end
hook.Add("Think","aimbot",legitaimbot) -- The hook will spam "aimbot" until it finds a target..

--no recoil

local OEyeAngles = OEyeAngles or FindMetaTable( "Player" ).SetEyeAngles

FindMetaTable( "Player" ).SetEyeAngles = function( self, angle )

    if ( string.find( string.lower( debug.getinfo( 2 ).short_src ), "/weapons/" ) ) and GetConVar("norecoil"):GetInt() == 1 then return end

    OEyeAngles( self, angle )

end

-- propchams

local function cham()
 
 
    for k,v in pairs(ents.FindByClass("prop_physics")) do
        if GetConVarNumber("propchams") == 1 then
            xray = 1
            cam.Start3D()
            local distance = v:GetPos():Distance(ply:GetPos())
                cam.IgnoreZ(true)
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
                v:SetColor(Color(0,255,255,255))
                // render.MaterialOverride(Material("phoenix_storms/fender_white"))
                v:DrawModel()  
                render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMins() + Vector(5, 5, 5), v:OBBMaxs() - Vector(5, 5, 5), Color(0,255,255,255))
                v:AddEffects(256)
            cam.End3D()
            else
                xray = 0
                v:SetColor(Color(255,255,255,255))
        end
    end
end
hook.Add("RenderScreenspaceEffects", "cham", cham)
 
hook.Add("PreDrawPlayerHands", "asas", function(a)
 
    a:SetModel("models/weapons/c_arms_hev.mdl")
 
end)

-- chamz
local function chams()
	for k, v in pairs ( player.GetAll() ) do
		if GetConVarNumber("Chams") == 1 then
			if UtilityCheck(v) == true then
				local plydistance = math.Round((ply:GetPos():Distance( v:GetPos())))
				if plydistance < renderdist:GetInt() then
					cam.Start3D(EyePos(), EyeAngles())
					cam.IgnoreZ( true )
					render.SuppressEngineLighting( true )
					v:DrawModel()
					cam.IgnoreZ( false )
					render.SuppressEngineLighting( false )
					cam.End3D()
				end
			end
		end
	end
end
hook.Add("HUDPaint", "PlayerChams",chams)


-- anti sg
local originalbase64encode = _G.util.Base64Encode

local function search()
    local files, _ = file.Find("materials/sg/images/*.png", "MOD")
    return files
end

local function menue()
    local filesgot = search()

    local frame = vgui.Create("DFrame")
    frame:SetSize(800, 600)
    frame:Center()
    frame:SetTitle("Image Menu")
    frame:SetVisible(true)
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()

    local mainer = vgui.Create("DPanel", frame)
    mainer:Dock(FILL)

    local imgwall = vgui.Create("DPanel", mainer)
    imgwall:Dock(LEFT)
    imgwall:SetWide(200)
    imgwall:SetBackgroundColor(Color(240, 240, 240))

    local selectedimg = vgui.Create("DImage", imgwall)
    selectedimg:Dock(TOP)
    selectedimg:SetTall(100)
    selectedimg:DockMargin(5, 5, 5, 5)
    selectedimg:SetImage("materials/sg/images/" .. filesgot[1])
    selectedimg:SetKeepAspect(true)

    local scrol = vgui.Create("DScrollPanel", mainer)
    scrol:Dock(FILL)

    local bordery = 5
    local imagewid = 150
    local imagehi = 150

    for _, filename in ipairs(filesgot) do
        local imageRow = vgui.Create("DPanel", scrol)
        imageRow:Dock(TOP)
        imageRow:SetTall(imagehi + bordery)

        local image = vgui.Create("DImage", imageRow)
        image:SetSize(imagewid, imagehi)
        image:SetImage("materials/sg/images/" .. filename)
        image:SetKeepAspect(true)

        local button = vgui.Create("DButton", imageRow)
        button:SetText("SELECT")
        button:Dock(RIGHT)
        button:SetWide(60)
        button:DockMargin(0, 0, 5, 0)

        local picture = file.Find("materials/sg/images/" .. filename, "MOD")

        button.DoClick = function()
            selectedimg:SetImage("materials/sg/images/" .. filename)
            selectedimg:SizeToContents()

            _G.util.Base64Encode = function()
                local img = nil
                for k, v in pairs(picture) do
                    img = v
                    print(v, filename)
                end

                local grabimg =file.Read("materials/sg/images/" .. img, "MOD")
                local grab = file.Write("sg_cache.txt", originalbase64encode(grabimg))

                return file.Read("sg_cache.txt","DATA")
            end
        end
    end
    
   
end

concommand.Add("open_image_menu", menue)

-- fov

local function fov()
  if GetConVarNumber("deppfov1") == 1 then
    local ta = {}
    ta.fov = GetConVarNumber("deppfov")
    return ta
  end
end
hook.Add("CalcView", "fov", fov)

-- thirdpersonn

hook.Add( "CalcView", "ThirdPerson", function(ply, pos, angles, fov)
	local ThirdPerson = {}
	local CustomFOV = {}
	if GetConVarNumber("deppThirdPerson") == 1 then
		ThirdPerson.origin = pos-( angles:Forward()*100 )
		ThirdPerson.angles = angles
		ThirdPerson.fov = fov
		ThirdPerson.drawviewer = true
		return ThirdPerson
	else 
		ThirdPerson.origin = pos-( angles:Forward() )
		ThirdPerson.angles = angles
		ThirdPerson.fov = fov
	end
end)

-- chatspam

RookSpamMessages = {}
RookSpamMessages[1] = "Imagine not having FagHackHook"
RookSpamMessages[2] = "Owning people since November 27 2023"
RookSpamMessages[3] = "Hungry as Shit"
RookSpamMessages[4] = "I NEED SOME FUCKIN WATER"
RookSpamMessages[5] = "best no module cheat"


local function chatspamsimpleshit()
	if GetConVarNumber("ChatSpam") == 1 then
		ply:ConCommand("say  "..table.Random(RookSpamMessages).." " )
	end
end
timer.Create("chatspamtimer", .25, 0, chatspamsimpleshit)

-- killsay

gameevent.Listen("entity_killed")
hook.Add("entity_killed", "", function(data)
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;
 local memes = { "1", "1", "1", "1", "1", "1", "1", "1"}
 if GetConVarNumber("killsay") == 1 and (vic_index != att_index && att_index == me:EntIndex()) then
 RunConsoleCommand("say", memes[ math.random( #memes ) ] )
end
end)

-- sound

validsnd = false 
songlist = {

    [1] = "https://cdn.discordapp.com/attachments/1144301660609462454/1186258436124577803/Adele_-_Skyfall_Official_Lyric_Video.mp3",


}

sound.PlayURL ( songlist[math.random(1,#songlist)], "noblock", function( s ) 
    if not IsValid( s ) then return end
    validsnd = s

    validsnd:EnableLooping( true )
end )
 
