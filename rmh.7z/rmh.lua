if SERVER then
	return
end
--[[
----------  ----------  ----------      -        -  ------------
-        -  -        -          -       -        -            -
-        -  -        -        -         -        -            -
-        -  -        -       -          -        -            -
----------  ----------      -           -        -            -    (Alpha)    
-  -        -        -     -            -        -            -
-    -      -        -    -             -        -            -
-      -    -        -   -               -      -             -
-        -  -        -  ----------        ------         ---------

-A GMod Multihack-
  
-[ FULL VERSION ]-

Coded by Razor
Special Thanks:
Bobby aka. Tom (Testing everything i make)
Marten (Testing my stuff)
Jack the Ripper aka. MrFramesHunter (Good Friend and testing my stuff)
Others i don't remember now
]]

--[[ 
Timer function
Useless, just wanted to see if the hack loads in under 1 second
]]

local timer = timer

local finin1sec = false

timer.Simple(1, function()
	if (finin1sec) then
		print("We loaded in under 1 Second!")
	else
		print("We didn't load in under 1 Seconds!")
	end
end)

--[[
Localizing
Makes Cheat run faster
]]

local CreateClientConVar = CreateClientConVar
local ChatPrint = ChatPrint
local concommand = concommand	
local GetConVarNumber = GetConVarNumber
local hook = hook
local GetConVarString = GetConVarString
local LocalPlayer = LocalPlayer
local player = player
local ents = ents
local ScrW = ScrW
local ScrH = ScrH
local require = require
local pairs = pairs
local cam = cam
local render = render
local cvars = cvars
local surface = surface
local table = table
local math = math
local print = print
local include = include
local Vector = Vector
local Angle = Angle
local GetEyeTrace = GetEyeTrace
local Entity = Entity
local ConCommand = ConCommand
local RunConsoleCommand = RunConsoleCommand
local vgui = vgui
local CurTime = CurTime
local EyeAngles = EyeAngles
local EyePos = EyePos
local LookupBone = LookupBone
local GetBonePosition = GetBonePosition
local random = random


--[[
Require DLL's
Load CVAR3 and stuff
]]

require("cvar3")

--[[
Tables
Tables with required informations
]]

local raz = {}

raz.cvars = {
	{ Name = "raz_bhop", Value = 0 },
	{ Name = "raz_esp", Value = 0 },
	{ Name = "raz_chams", Value = 0 },
	{ Name = "raz_chams_type", Value = 1 },
	{ Name = "raz_propwh", Value = 0 },
	{ Name = "raz_rapidfire", Value = 0 },
	{ Name = "raz_rpgod", Value = 0 },
	{ Name = "raz_triggerbot", Value = 0 },
	{ Name = "raz_namesteal", Value = 0 },
	{ Name = "raz_pkill_prop", Value = "models/props_c17/Lockers001a.mdl"},
	{ Name = "raz_pkill_angleup", Value = 10 },
	{ Name = "raz_chatspam", Value = 0 },
	{ Name = "raz_chatspam_msg", Value = "swag"},
	{ Name = "raz_traces", Value = 0 },
	{ Name = "raz_fov", Value = 90 },
	{ Name = "raz_fov_enable", Value = 0 },
	{ Name = "raz_crosshair", Value = 0 },
	{ Name = "raz_crosshair_spin",Value = 0 },
	{ Name = "raz_crosshair_spin_speed", Value = 2.5 },
	{ Name = "raz_crosshair_spin_size", Value = 2 },
	{ Name = "raz_aimbot_fov", Value = 50 },
	{ Name = "raz_traitorfinder", Value = 0 },
	{ Name = "raz_speedhack_speed",  Value = 5 },
	{ Name = "raz_norecoil", Value = 0 },
	{ Name = "raz_fspam", Value = 0 },
	{ Name = "raz_aimbot_autofire", Value = 0 },
	{ Name = "raz_antiaim", Value = 0 },
	{ Name = "raz_los", Value = 0 },
	{ Name = "raz_spectator_notify", Value = 1 },
	{ Name = "raz_entesp", Value = 0 },
	{ Name = "raz_aimbot_autosnap", Value = 0 },
	{ Name = "raz_aimbot_bone", Value = "ValveBiped.Bip01_Head1" },
	{ Name = "raz_radius", Value = 25000 },
	{ Name = "raz_spinme", Value = 0 },
	{ Name = "raz_supportme", Value = 0 },
	{ Name = "raz_murderhacks", Value = 0 },
	{ Name = "raz_nospread", Value = 0 },
	{ Name = "raz_skeleton", Value = 0 },
	{ Name = "raz_targetfriends", Value = 0 },
	{ Name = "raz_targetteam", Value = 1 },
	{ Name = "raz_pkill_speed", Value = 10 },
	{ Name = "raz_antisnap", Value = 0 },
	{ Name = "raz_antisnap_speed", Value = 1 },
	{ Name = "raz_fullbright", Value = 0 },
	{ Name = "raz_thirdperson", Value = 0 },
	{ Name = "raz_removeskybox", Value = 0 },
	{ Name = "raz_npcesp", Value = 0 },
	{ Name = "raz_propsurf_mdl", Value = "models/props_c17/Lockers001a.mdl" },
	{ Name = "raz_rpact", Value = 0 },
	
}


raz.bones = {
	-- Head to Legs
	{ Bone = "ValveBiped.Bip01_Head1", Name = "Head" },
	{ Bone = "ValveBiped.Bip01_Neck1", Name = "Neck" },
	{ Bone = "ValveBiped.Bip01_Spine4", Name = "Spine4" },
	{ Bone = "ValveBiped.Bip01_Spine2", Name = "Spine2" },
	{ Bone = "ValveBiped.Bip01_Spine1", Name = "Spine1" },
	{ Bone = "ValveBiped.Bip01_Pelvis", Name = "Pelvis" },
	-- Left Arm
	{ Bone = "ValveBiped.Bip01_L_UpperArm", Name = "L Upperarm" },
	{ Bone = "ValveBiped.Bip01_L_Forearm", Name = "L Forearm" },
	{ Bone = "ValveBiped.Bip01_L_Hand", Name = "L Hand" },
	-- Right Arm
	{ Bone = "ValveBiped.Bip01_L_UpperArm", Name = "R Upperarm" },
	{ Bone = "ValveBiped.Bip01_L_Forearm", Name = "R Forearm" },
	{ Bone = "ValveBiped.Bip01_L_Hand", Name = "R Hand" },
	-- Left Leg
	{ Bone = "ValveBiped.Bip01_L_Thigh", Name = "L Thigh" },
	{ Bone = "ValveBiped.Bip01_L_Calf", Name = "L Calf" },
	{ Bone = "ValveBiped.Bip01_L_Foot", Name = "L Foot" },
	{ Bone = "ValveBiped.Bip01_L_Toe0", Name = "L Toe" },
	-- Right Leg
	{ Bone = "ValveBiped.Bip01_R_Thigh", Name = "R Thigh" },
	{ Bone = "ValveBiped.Bip01_R_Calf", Name = "R Calf" },
	{ Bone = "ValveBiped.Bip01_R_Foot", Name = "R Foot" },
	{ Bone = "ValveBiped.Bip01_R_Toe0", Name = "R Toe" },
	-- Random
	{ Bone = "random", Name = "random" }
}

raz.randombones = {
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Neck1",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_Spine2", 
	"ValveBiped.Bip01_Spine1", 
	"ValveBiped.Bip01_Pelvis", 
	-- Left Arm
	"ValveBiped.Bip01_L_UpperArm",
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Hand",
	-- Right Arm
	"ValveBiped.Bip01_L_UpperArm",
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Hand", 
	-- Left Leg
	"ValveBiped.Bip01_L_Thigh",
	"ValveBiped.Bip01_L_Calf",
	"ValveBiped.Bip01_L_Foot", 
	"ValveBiped.Bip01_L_Toe0",
	-- Right Leg
	"ValveBiped.Bip01_R_Thigh", 
	"ValveBiped.Bip01_R_Calf",
	"ValveBiped.Bip01_R_Foot",
	"ValveBiped.Bip01_R_Toe0",
}

raz.skeletonbones = {
	-- Head to legs
	{ B = "ValveBiped.Bip01_Head1", Bs = "ValveBiped.Bip01_Neck1" },
	{ B = "ValveBiped.Bip01_Neck1", Bs = "ValveBiped.Bip01_Spine4" },
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_Spine2" },
	{ B = "ValveBiped.Bip01_Spine2", Bs = "ValveBiped.Bip01_Spine1" },
	{ B = "ValveBiped.Bip01_Spine1", Bs = "ValveBiped.Bip01_Pelvis" },
	-- Left Leg
	{ B = "ValveBiped.Bip01_Pelvis", Bs = "ValveBiped.Bip01_L_Thigh" },
	{ B = "ValveBiped.Bip01_L_Thigh", Bs = "ValveBiped.Bip01_L_Calf" },
	{ B = "ValveBiped.Bip01_L_Calf", Bs = "ValveBiped.Bip01_L_Foot" },
	{ B = "ValveBiped.Bip01_L_Foot", Bs = "ValveBiped.Bip01_L_Toe0" },
	-- Right Leg
	{ B = "ValveBiped.Bip01_Pelvis", Bs = "ValveBiped.Bip01_R_Thigh" },
	{ B = "ValveBiped.Bip01_R_Thigh", Bs = "ValveBiped.Bip01_R_Calf" },
	{ B = "ValveBiped.Bip01_R_Calf", Bs = "ValveBiped.Bip01_R_Foot" },
	{ B = "ValveBiped.Bip01_R_Foot", Bs = "ValveBiped.Bip01_R_Toe0" },
	-- Left Arm
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_L_UpperArm" },
	{ B = "ValveBiped.Bip01_L_UpperArm", Bs = "ValveBiped.Bip01_L_Forearm" },
	{ B = "ValveBiped.Bip01_L_Forearm", Bs = "ValveBiped.Bip01_L_Hand" },
	-- Right Arm
	{ B = "ValveBiped.Bip01_Spine4", Bs = "ValveBiped.Bip01_R_UpperArm" },
	{ B = "ValveBiped.Bip01_R_UpperArm", Bs = "ValveBiped.Bip01_R_Forearm" },
	{ B = "ValveBiped.Bip01_R_Forearm", Bs = "ValveBiped.Bip01_R_Hand" }
}


raz.devs = {
	"STEAM_0:1:40744642"
}

raz.version = "1.0 (Alpha)"

--[[
Fonts
]]

surface.CreateFont("menufont12", {
	font = "Arial",
	size = 12,
	weight = 500,
	antialias = 1
})

--[[
Functions
Hook Add functions and stuff
]]

local function AddHook(Type, name, Function)
	hook.Add(Type, name, Function)
end

local function RemoveHook(Type, name)
	hook.Remove(Type, name)
end

local function AddConvar(Name, Value)
	CreateClientConVar(Name, Value)
end

local function ForceVar(use,less,args)
	GetConVar(args[1]):SetValue(args[2])
end

local function ForceVarAlt(var, value)
	GetConVar(var):SetValue(value)
end

for k,v in pairs(player.GetAll()) do
	v.Whitelisted = false
end

--[[
Get Gamemode
Get Servers gamemode
]]

local function GetServerGameMode()
	print("This server is running the gamemode "..GAMEMODE.Name..".")
end

--[[
If Visible Functions and stuff
]]


local function CrossColor()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 255, 0, 0, 255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0, 255, 0, 255
	end
	return 0, 0, 255, 255
end

local function InDist(v)
	local dist = v:GetPos():Distance(LocalPlayer():GetPos())
	if dist > GetConVarNumber("raz_radius") then
		return false
	else
		return true
	end
	return true
end

local function IsVisible(e)   
	local tr = {} 
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end  
end

local function IsVisibleTrace(e)   
	local tr = {} 
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0, 0, 60)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end   
end

local function IsVisibleChams2(e)   
	local tr = {} 
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end
end
	
local function IsVisibleChams3(e)   
	local tr = {} 
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0, 0, 60)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return true
	else
		return false
	end
end

local function IsVisibleChams(e)   
	local tr = {} 
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = e:GetPos() + Vector(0, 0, 30)
	tr.filter = {LocalPlayer(), e}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr)
	if (trace.Fraction == 1) then
		return Color(0,255,63,255)
	else
		if (IsVisibleChams2(e)) then
			return Color(0,255,63,255)
		end
		if (IsVisibleChams3(e)) then
			return Color(0,255,63,255)
		end
		return Color(127,0,0,255)
	end   
end

local function ColorVisible(e)
	if IsVisible(e) then
		return 255, 93, 0, 255
	else
		return 0, 31, 127, 255
	end
end

local targetang = ""
local infovbone = ""

function InFOV(e)
        local aimfov = GetConVarNumber("raz_aimbot_fov")
        if( aimfov != 360 ) then
			local myang = LocalPlayer():GetAngles()
			if GetConVarString("raz_aimbot_bone") == "random" then
				infovbone = "ValveBiped.Bip01_Head1"
			else
				infovbone = GetConVarString("raz_aimbot_bone")
			end
			local targetang = (e:GetBonePosition(e:LookupBone(infovbone)) - LocalPlayer():EyePos()):Angle()
			local calc1 = math.abs( math.NormalizeAngle( myang.y - targetang.y ) )
			local calc2 = math.abs( math.NormalizeAngle( myang.p - targetang.p ) )
			if (calc1 > aimfov || calc2 > aimfov) then 
				return false 
			end
		end
	return true
end

--[[
Skeleton
]]

local function skeleton()
	for k,v in pairs(player.GetAll()) do
		for bt, bonez in pairs(raz.skeletonbones) do
			if GAMEMODE.Name == "Trouble in Terrorist Town" then
				if v:Team() == TEAM_SPECTATOR then
					return
				end
			end
			if v:Alive() and v != LocalPlayer() and v:GetModel() != "" and v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" then
				local spos1, spos2 = v:GetBonePosition( v:LookupBone( bonez.B ) ):ToScreen(), v:GetBonePosition( v:LookupBone( bonez.Bs ) ):ToScreen()
				surface.SetDrawColor(team.GetColor(v:Team()))
				surface.DrawLine(spos1.x, spos1.y, spos2.x, spos2.y)
			end
		end
	end
end

if GetConVarNumber("raz_skeleton") == 1 then
	AddHook("HUDPaint", "Skeleton", skeleton)
end

cvars.AddChangeCallback("raz_skeleton", function()
	if GetConVarNumber("raz_skeleton") == 1 then
		AddHook("HUDPaint", "Skeleton", skeleton)
	else
		RemoveHook("HUDPaint", "Skeleton")
	end
end)


--[[
Get Admin Status
Return Admin Status
]]

local function CheckAdmin(e)
	if e:IsAdmin() and !(e:IsSuperAdmin()) then
		return " Admin "
	end
	if e:IsSuperAdmin() then
		return " Superadmin "
	end
	return " "
end

--[[
Create ConVars
]]

local function CreateConVars()
	for k,v in pairs(raz.cvars) do
		AddConvar(v.Name, v.Value)
	end
end

CreateConVars()


concommand.Add("raz_forcevar", ForceVar)

--[[
Derma Aimbot Bone Menu
]]

local function dermabone()
	local frame = vgui.Create("DFrame")
	frame:SetSize(350,150)
	frame:Center()
	frame:MakePopup()
	frame:SetTitle("RAZ v"..raz.version.." || Choose Aimbot bone")
	
	local label = vgui.Create("DLabel")
	label:SetParent(frame)
	label:SetText([[Choose the bone you want the aimbot
	to aim at and close this window.]])
	label:SetPos(70,50)
	label:SizeToContents()
	
	local Bonelist = vgui.Create( "DComboBox")
	Bonelist:SetParent(frame)
	Bonelist:SetPos(50,100)
	Bonelist:SetSize( 250, 20 )
	for k, v in pairs(raz.bones) do
		Bonelist:AddChoice(v.Name)
	end
	Bonelist.OnSelect = function(self)
		for k,v in pairs(raz.bones) do
			if v.Name == self:GetValue() then
				LocalPlayer():ChatPrint("Changed aimbone to: "..v.Bone)
				RunConsoleCommand("raz_aimbot_bone", v.Bone)
			end
		end
	end
end

concommand.Add("raz_aimbot_bone_menu", dermabone)

--[[
Shitlist for aimbot
]]

local whitelist = {}

local function shitlist()
	local frame = vgui.Create("DFrame")
	frame:SetSize(500,500)
	frame:Center()
	frame:MakePopup()
	frame:SetTitle("RAZ v"..raz.version.." || Shitlist")

	local list1 = vgui.Create("DListView")
	list1:SetParent(frame)
	list1:SetPos(5, 40)
	list1:SetSize(230, 450)
	list1:SetMultiSelect(false)
	list1:AddColumn("Name")
	list1:AddColumn("SteamID")
	
	local list2 = vgui.Create("DListView")
	list2:SetParent(frame)
	list2:SetPos(260, 40)
	list2:SetSize(230, 450)
	list2:SetMultiSelect(false)
	list2:AddColumn("Name")
	list2:AddColumn("SteamID")
	
	local label = vgui.Create("DLabel")
	label:SetParent(frame)
	label:SetPos(80,25)
	label:SetText("Not on whitelist")
	label:SizeToContents()
	
	local label2 = vgui.Create("DLabel")
	label2:SetParent(frame)
	label2:SetPos(350,25)
	label2:SetText("On whitelist")
	label2:SizeToContents()
	
	local at = vgui.Create("DButton",frame)
	at:SetSize(20,20)
	at:SetPos(240,250)
	at:SetText("+")
	at.DoClick = function()
		if list1:GetSelectedLine() != nil then 
			local i1 = list1:GetLine(list1:GetSelectedLine()):GetValue(2)
			local i2 = list1:GetLine(list1:GetSelectedLine()):GetValue(1)
			for k,v in pairs(player.GetAll()) do 
				if v:Name() == i2 then
					if !(v.Whitelisted) then
						v.Whitelisted = true
						list1:RemoveLine(list1:GetSelectedLine())
						list2:AddLine(i2, i1)
					end
				end
			end
		end
	end

	local rm = vgui.Create("DButton",frame)
	rm:SetSize(20,20)
	rm:SetPos(240,270)
	rm:SetText("-")
	rm.DoClick = function() 
		if list2:GetSelectedLine() != nil then 
			local i1 = list2:GetLine(list2:GetSelectedLine()):GetValue(2)
			local i2 = list2:GetLine(list2:GetSelectedLine()):GetValue(1)
			for k,v in pairs(player.GetAll()) do 
				if v:Name() == i2 then
					if (v.Whitelisted) then
						v.Whitelisted = false
						list2:RemoveLine(list2:GetSelectedLine())
						list1:AddLine(i2, i1)
					end
				end
			end
		end
	end

	
	for k,v in pairs(player.GetAll()) do 
		if !(v:SteamID() == LocalPlayer():SteamID()) then
			if !(v.Whitelisted) then
				list1:AddLine(v:Name(), v:SteamID())
			else
				list2:AddLine(v:Name(), v:SteamID())
			end
		end
	end
end

concommand.Add("raz_shitlist", shitlist)

concommand.Add("printwhitelist", function()
	for k,v in pairs(player.GetAll()) do 
		if (v.Whitelisted) then
			print(v:Name().." is whitelisted!")
		else
			print(v:Name().." isn't whitelisted!")
		end
	end
end)

--[[
Razor Dev
Check's if a razor dev is on
]]


local function checkrazor()
	for k,v in pairs(player.GetAll()) do
		if table.HasValue(raz.devs, v:SteamID()) and !(v.IsDev) then
			LocalPlayer():ChatPrint("Razor Dev is on the server: "..v:Name())
			v.IsDev = true
		end
	end
end



AddHook("Think", "checkdev", checkrazor)

--[[
BHOP
]]

local shalljump = true

local function bhop()
	if LocalPlayer():IsTyping() then
		return
	end
	if LocalPlayer():IsOnGround() and input.IsKeyDown(KEY_SPACE) and (shalljump) then
		RunConsoleCommand("+jump")
		shalljump = false
	elseif !(LocalPlayer():IsOnGround()) and input.IsKeyDown(KEY_SPACE) and !(shalljump) then
		RunConsoleCommand("-jump")
		shalljump = true
	elseif LocalPlayer():IsOnGround() and !(input.IsKeyDown(KEY_SPACE)) then
		RunConsoleCommand("-jump")
		shalljump = false
	end
end

if GetConVarNumber("raz_bhop") == 1 then
	AddHook("Think", "BunnyHop", bhop)
end

cvars.AddChangeCallback("raz_bhop", function()
	if GetConVarNumber("raz_bhop") == 1 then
		AddHook("Think", "BunnyHop", bhop)
	else
		RemoveHook("Think", "BunnyHop")
	end
end)

--[[
ESP
]]

local function BoxEsp()
	
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/player.mdl" then
			local min,max = v:WorldSpaceAABB()
			local diff = max-min
			local pos2 = Vector(0,0,0)
			local pos1 = Vector(0,0,0)
			local pos3 = Vector(0,0,0)
			local pos4 = Vector(0,0,0)
			local pos5 = Vector(0,0,diff.z)
			local pos6 = Vector(0,0,diff.z)
			local pos7 = Vector(0,0,diff.z)
			local pos8 = Vector(0,0,diff.z)

			pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			
			surface.SetDrawColor(0,0,255,255)			
			surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y)
			surface.DrawLine(pos2.x, pos2.y, pos3.x, pos3.y)
			surface.DrawLine(pos3.x, pos3.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos3.x, pos3.y)
			surface.DrawLine(pos2.x, pos2.y, pos4.x, pos4.y)
			
			surface.SetDrawColor(team.GetColor(v:Team()))
			
			surface.DrawLine(pos1.x, pos1.y, pos5.x, pos5.y)
			surface.DrawLine(pos2.x, pos2.y, pos6.x, pos6.y)
			surface.DrawLine(pos3.x, pos3.y, pos7.x, pos7.y)
			surface.DrawLine(pos4.x, pos4.y, pos8.x, pos8.y)
			
			surface.SetDrawColor(90,20,50,255)	
			
			surface.DrawLine(pos5.x, pos5.y, pos6.x, pos6.y)
			surface.DrawLine(pos6.x, pos6.y, pos7.x, pos7.y)
			surface.DrawLine(pos7.x, pos7.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos7.x, pos7.y)
			surface.DrawLine(pos6.x, pos6.y, pos8.x, pos8.y)
			
		end
	end
end


if GetConVarNumber("raz_esp") == 1 then
	AddHook("HUDPaint", "boxesp", BoxEsp)
end

cvars.AddChangeCallback("raz_esp", function()
	if GetConVarNumber("raz_esp") == 1 then
		AddHook("HUDPaint", "boxesp", BoxEsp)
	else
		RemoveHook("HUDPaint", "boxesp")
	end
end)

local function espchams()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" then
			cam.Start3D()
				if GetConVarNumber("raz_chams_type") == 1 then
					v:SetMaterial("models/debug/debugwhite")
				elseif GetConVarNumber("raz_chams_type") == 2 then
					v:SetMaterial("models/wireframe")
				elseif GetConVarNumber("raz_chams_type") == 0 then
					v:SetMaterial("models/wireframe")
				end
				local cola = ""
				if GetConVarNumber("raz_chams_type") == 1 then
					cola = IsVisibleChams(v)
				else
					cola = team.GetColor(v:Team())
				end
				render.SetColorModulation(cola.r / 255, cola.g / 255, cola.b / 255)
				render.SetBlend(cola.a / 255)
				v:DrawModel()
			cam.End3D()
		elseif v:IsValid() and v:Alive() and v != LocalPlayer() and !(InDist(v)) then
			cam.Start3D()
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			cam.End3D()
			
		end
	end
end

if GetConVarNumber("raz_chams") == 1 then
	AddHook("HUDPaint", "Chams", espchams)
end

cvars.AddChangeCallback("raz_chams", function()
	if GetConVarNumber("raz_chams") == 1 then
		AddHook("HUDPaint", "Chams", espchams)
	else
		RemoveHook("HUDPaint", "Chams")
		cam.Start3D()
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() and v:Alive() and v != LocalPlayer() then
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			end
		end
		cam.End3D()
	end
end)

local function propwh()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics" and v:IsValid() and InDist(v) then
			cam.Start3D()
				v:SetMaterial("models/wireframe")
				local col = Color(255, 93, 0, 255) 
				render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
				render.SetBlend(col.a / 255)
				v:DrawModel()
			cam.End3D()
		elseif v:GetClass() == "prop_physics" and v:IsValid() and !(InDist(v)) then
			cam.Start3D()
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			end
		end
	end


if GetConVarNumber("raz_propwh") == 1 then
	AddHook("HUDPaint", "PropWH", propwh)
end

cvars.AddChangeCallback("raz_propwh", function()
	if GetConVarNumber("raz_propwh") == 1 then
		AddHook("HUDPaint", "PropWH", propwh)
	else
		RemoveHook("HUDPaint", "PropWH")
		cam.Start3D()
		for k,v in pairs(ents.GetAll()) do
			if v:IsValid() and v:GetClass() == "prop_physics" then
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				render.SetBlend(1)
			end
		end
		cam.End3D()
	end
end)

local function espinfo()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/player.mdl" then
			local Position = ( v:GetPos() + Vector( 0,0,60 ) ):ToScreen()
			local Position2 = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Position3 = ( v:GetPos() + Vector( 0,0,100 ) ):ToScreen()
			local Position4 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local Position5 = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
			local pname = " "
			if v:Health() > 0 and v:GetActiveWeapon():IsValid() and v:GetActiveWeapon() then
				pname = v:GetActiveWeapon():GetPrintName()
			else
				pname = ""
			end
			draw.SimpleText(v:Name(), "Default",Position.x, Position.y, Color(0,255,0,255), 1) 
			draw.SimpleText("Health: "..v:Health(), "Default", Position2.x, Position2.y, Color(150,0,255,255), 1)
			draw.SimpleText("Weapon: "..pname, "Default",  Position3.x, Position3.y, Color(0,0,255,255), 1)
			if v:GetFriendStatus() == "friend" then
				draw.SimpleText("FRIEND", "Default",  Position4.x, Position4.y, Color(150,255,150,255), 1)
			end
			if table.HasValue(raz.devs, v:SteamID()) then
				draw.SimpleText("Razor Dev", "Default",  Position5.x, Position5.y, Color(255,255,255,255), 1)
			end
		end
	end
end

if GetConVarNumber("raz_esp") == 1 then
	AddHook("HUDPaint", "Info", espinfo)
end

cvars.AddChangeCallback("raz_esp", function()
	if GetConVarNumber("raz_esp") == 1 then
		AddHook("HUDPaint", "Info", espinfo)
	else
		RemoveHook("HUDPaint", "Info")
	end
end)

--[[
NPC-ESP
]]

local function NpcEsp()
	
	for k,v in pairs(ents.GetAll()) do
		if v:IsValid() and v:IsNPC() and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/player.mdl" then
			local min,max = v:WorldSpaceAABB()
			local diff = max-min
			local pos2 = Vector(0,0,0)
			local pos1 = Vector(0,0,0)
			local pos3 = Vector(0,0,0)
			local pos4 = Vector(0,0,0)
			local pos5 = Vector(0,0,diff.z)
			local pos6 = Vector(0,0,diff.z)
			local pos7 = Vector(0,0,diff.z)
			local pos8 = Vector(0,0,diff.z)

			pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
			pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
			pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
			pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
			
			surface.SetDrawColor(0,0,255,255)			
			surface.DrawLine(pos1.x, pos1.y, pos2.x, pos2.y)
			surface.DrawLine(pos2.x, pos2.y, pos3.x, pos3.y)
			surface.DrawLine(pos3.x, pos3.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos4.x, pos4.y)
			surface.DrawLine(pos1.x, pos1.y, pos3.x, pos3.y)
			surface.DrawLine(pos2.x, pos2.y, pos4.x, pos4.y)
			
			surface.SetDrawColor(0,255,0,255)
			
			surface.DrawLine(pos1.x, pos1.y, pos5.x, pos5.y)
			surface.DrawLine(pos2.x, pos2.y, pos6.x, pos6.y)
			surface.DrawLine(pos3.x, pos3.y, pos7.x, pos7.y)
			surface.DrawLine(pos4.x, pos4.y, pos8.x, pos8.y)
			
			surface.SetDrawColor(90,20,50,255)	
			
			surface.DrawLine(pos5.x, pos5.y, pos6.x, pos6.y)
			surface.DrawLine(pos6.x, pos6.y, pos7.x, pos7.y)
			surface.DrawLine(pos7.x, pos7.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos8.x, pos8.y)
			surface.DrawLine(pos5.x, pos5.y, pos7.x, pos7.y)
			surface.DrawLine(pos6.x, pos6.y, pos8.x, pos8.y)
			
		end
	end
end

local function npcespinfo()
	for k,v in pairs(ents.GetAll()) do
		if v:IsValid() and v:IsNPC() and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/player.mdl" then
			local Position2 = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			draw.SimpleText(v:GetClass(), "Default",Position2.x, Position2.y, Color(0,255,0,255), 1) 
		end
	end
end

if GetConVarNumber("raz_npcesp") == 1 then
	AddHook("HUDPaint", "NPCESP", NpcEsp)
	AddHook("HUDPaint", "NpcEspInfo", npcespinfo)
end

cvars.AddChangeCallback("raz_npcesp", function()
	if GetConVarNumber("raz_npcesp") == 1 then
		AddHook("HUDPaint", "NPCESP", NpcEsp)
	else
		RemoveHook("HUDPaint", "NPCESP")
		RemoveHook("HUDPaint", "NpcEspInfo")
	end
end)

--[[
Remove Skybox
]]

local function RemoveSkybox()
	ForceVarAlt("gl_clear", 1)
	ForceVarAlt("r_drawskybox", 0)
	ForceVarAlt("r_3dsky",0)
end

if GetConVarNumber("raz_removeskybox") == 1 then
	AddHook("Think", "RemoveSkybox", RemoveSkybox)
end

cvars.AddChangeCallback("raz_removeskybox", function()
	if GetConVarNumber("raz_removeskybox") == 1 then
		AddHook("Think", "RemoveSkybox", RemoveSkybox)
	else
		ForceVarAlt("gl_clear", 0)
		ForceVarAlt("r_drawskybox", 1)
		ForceVarAlt("r_3dsky",1)
		RemoveHook("Think", "RemoveSkybox")
	end
end)

-- Imma rock this

--[[
Thirdperson
]]

inthirdperson = false

local function thirdperson()
	RunConsoleCommand("thirdperson")
end

if GetConVarNumber("raz_thirdperson") == 1 then
	AddHook("Think", "Thirdperson", thirdperson)
end

cvars.AddChangeCallback("raz_thirdperson", function()
	if GetConVarNumber("raz_thirdperson") == 1 then
		AddHook("Think", "Thirdperson", thirdperson)
	else
		RemoveHook("Think", "Thirdperson", thirdperson)
		RunConsoleCommand("firstperson")
	end
end)

	
--[[
Warning when admin on
]]

tracked = {}

local function warning()
	for k,v in pairs(player.GetAll()) do
		if !(table.HasValue(tracked, v)) then
			if v:IsAdmin() and !(v:IsSuperAdmin()) then
				table.insert(tracked, v)
				LocalPlayer():ChatPrint(v:Name().." is an Admin!")
			elseif v:IsSuperAdmin() then
				LocalPlayer():ChatPrint(v:Name().." is a Super Admin!")
				table.insert(tracked, v)
			end
		end
	end
end

AddHook("Think", "adminwarning", warning)

--[[
Rapid Fire
]]

local function rapidfire()
	if !(LocalPlayer():IsTyping()) then
		if !(doit) then
			RunConsoleCommand("-attack")
		end
		if input.IsMouseDown(MOUSE_LEFT) and (doit) then
			RunConsoleCommand("+attack")
			doit = false
		elseif input.IsMouseDown(MOUSE_LEFT) and !(doit) then
			RunConsoleCommand("-attack")
			doit = true
		end
	end
end

if GetConVarNumber("raz_rapidfire") == 1 then
	AddHook("Think", "rapid", rapidfire)
end

cvars.AddChangeCallback("raz_rapidfire", function()
	if GetConVarNumber("raz_rapidfire") == 1 then
		AddHook("Think", "rapid", rapidfire)
	else
		RemoveHook("Think", "rapid")
	end
end)

--[[
RP GOD
Spams "/buyhealth" when you lose health.
]]

local function rpgod()
	if LocalPlayer():Health() < 75 then
		if !(delay) then
			LocalPlayer():ConCommand("say /buyhealth")
			delay = true
			timer.Simple(2, function()
				delay = false
			end)
		end
	end
end


if GetConVarNumber("raz_rpgod") == 1 then
	AddHook("Think", "RP", rpgod)
end


cvars.AddChangeCallback("raz_rpgod", function()
	if GetConVarNumber("raz_rpgod") == 1 then
		AddHook("Think", "RP", rpgod)
	else
		RemoveHook("Think", "RP")
	end
end)

--[[
Triggerbot
]]

local function triggerbot()
	local EyeEntity = LocalPlayer():GetEyeTrace().Entity
	if shallfire == nil and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() then
		shallfire = true
	end
	if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() and shallfire then
		LocalPlayer():ConCommand("+attack")
		shallfire = false
	elseif LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() and !shallfire then
		LocalPlayer():ConCommand("-attack")
		shallfire = true
	elseif !EyeEntity:IsPlayer() and shallfire == true then
		LocalPlayer():ConCommand("-attack")
		shallfire = nil
	elseif !EyeEntity:IsPlayer() and shallfire == false then
		LocalPlayer():ConCommand("-attack")
		shallfire = nil
	end
end

if GetConVarNumber("raz_triggerbot") == 1 then
	AddHook("Think", "trigger", triggerbot)
end

cvars.AddChangeCallback("raz_triggerbot", function()
	if GetConVarNumber("raz_triggerbot") == 1 then
		AddHook("Think", "trigger", triggerbot)
	else
		RemoveHook("Think", "trigger")
		LocalPlayer():ConCommand("-attack")
	end
end)

--[[
Chatspam
]]

local wait = false

local function chatspam()
	if !(wait) then
		LocalPlayer():ConCommand("say "..GetConVarString("raz_chatspam_msg"))
		wait = true
		timer.Simple(2, function()
			wait = false
		end)
	end
end

RunConsoleCommand("raz_chatspam", 0)

if GetConVarNumber("raz_chatspam") == 1 then
	AddHook("Think", "chatsp", chatspam)
end

cvars.AddChangeCallback("raz_chatspam", function()
	if GetConVarNumber("raz_chatspam") == 1 then
		AddHook("Think", "chatsp", chatspam)
	else
		RemoveHook("Think", "chatsp")
	end
end)

--[[
Name Stealer
designed for DarkRP
]]

local waitchange = false



local function namesteal()
	if GAMEMODE.Name != "DarkRP" then
		LocalPlayer():ChatPrint("The gamemode isn't DarkRP!")
		RunConsoleCommand("raz_namesteal", 0)
		return
	end
	local name = player.GetAll()[ math.random( 1, #player.GetAll() ) ]
	if name:Name() == LocalPlayer():Name() then
		return
	end
		local space = " "
	
		if name:IsValid() and name != LocalPlayer() then
			if !(waitchange) then
				LocalPlayer():ConCommand("say /name "..name:Name().." ")
				waitchange = true
				timer.Simple(5, function()
					waitchange = false
				end)
			end
		end
	end

LocalPlayer():ConCommand("raz_namesteal 0")

if GetConVarNumber("raz_namesteal") == 1 then
	AddHook("Think", "Namesteal", namesteal)
end

cvars.AddChangeCallback("raz_namesteal", function()
	if GetConVarNumber("raz_namesteal") == 1 then
		AddHook("Think", "Namesteal", namesteal)
	else
		RemoveHook("Think", "Namesteal")
	end
end)

--[[
PropSurf
]]

local function surf()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
	timer.Simple(0.05, function()
		RunConsoleCommand("gm_spawn", GetConVarString("raz_propsurf_mdl"))
	end)
	timer.Simple(0.1, function()
		RunConsoleCommand("+attack")
		a = LocalPlayer():EyeAngles()
	end)
	timer.Simple(0.2, function()
		LocalPlayer():SetEyeAngles(Angle(a.p,a.y-180, a.r))
	end)
end

concommand.Add("+raz_propsurf", function()
	surf()
end)

concommand.Add("-raz_propsurf", function()	
	LocalPlayer():ConCommand("-attack")
	LocalPlayer():ConCommand("undo")
end)

--[[
Speedhack
]]


concommand.Add("+raz_speedhack", function()
	ForceVarAlt("host_framerate", GetConVarNumber("raz_speedhack_speed"))
end)

concommand.Add("-raz_speedhack", function()
	ForceVarAlt("host_framerate", 0)
end)

--[[
Propkill
]]

local function pkill()
	RunConsoleCommand("use", "weapon_physgun")
	timer.Simple(0.1, function()
		RunConsoleCommand("gm_spawn", GetConVarString("raz_pkill_prop"))
	end)
	timer.Simple(0.2, function()
		RunConsoleCommand("+attack")
	end)
	timer.Simple(0.3, function()
		local a = LocalPlayer():EyeAngles()
		LocalPlayer():SetEyeAngles(Angle(a.p-GetConVarNumber("raz_pkill_angleup"), a.y, a.r))
		AddHook("CreateMove", "pkill", function(cmd)
			cmd:SetMouseWheel(GetConVarNumber("raz_pkill_speed") * 10)
		end)
	end)
	timer.Simple(0.4, function()
		RunConsoleCommand("-attack")
		RemoveHook("CreateMove", "pkill")
	end)
end


concommand.Add("raz_pkill", pkill)

--[[
TraceLine
]]

for k,v in pairs(player.GetAll()) do
	v.Targetable = false
end

local TBone = ""
local TBonepos = ""


local function traceline()
	for k,v in pairs(player.GetAll()) do
		if GetConVarNumber("raz_targetfriends") == 0 then
			if v:GetFriendStatus() == "friend" then
				v.Targetable = false
			else
				v.Targetable = true
			end
		end
		if GetConVarNumber("raz_targetteam") == 0 then
			if v:Team() == LocalPlayer():Team() and (v.Targetable) then
				v.Targetable = false
			else
				v.Targetable = true
			end
		end
		if (v.Whitelisted) and (v.Targetable) then
			v.Targetable = false
		else
			v.Targetable = true
		end
		if (v.Targetable) then
		if v:IsValid() and v != LocalPlayer() and v:Alive() and IsVisibleTrace(v) and InFOV(v) and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" then
			if GetConVarString("raz_aimbot_bone") == "random" then
				TBone = v:LookupBone("ValveBiped.Bip01_Head1")         
				TBonepos = (v:GetBonePosition(TBone)):ToScreen()
			else
				TBone = v:LookupBone(GetConVarString("raz_aimbot_bone"))         
				TBonepos = (v:GetBonePosition(TBone)):ToScreen()
			end 
			surface.SetDrawColor(0,0,255,255)
			surface.DrawLine(ScrW() / 2, ScrH() / 2, TBonepos.x, TBonepos.y)
			end
		end
	end
end

if GetConVarNumber("raz_traces") == 1 then
	AddHook("HUDPaint", "Traceline", traceline)
end

cvars.AddChangeCallback("raz_traces", function()
	if GetConVarNumber("raz_traces") == 1 then
		AddHook("HUDPaint", "Traceline", traceline)
	else
		RemoveHook("HUDPaint", "Traceline")
		for k,v in pairs(player.GetAll()) do
			v.Targetable = false
		end
	end
end)

--[[
FOV-Changer
]]

local function changefov(ply, ori, ang, fov)
	local view = {}
	view.fov = GetConVarNumber("raz_fov")
	return view
end

if GetConVarNumber("raz_fov_enable") == 1 then
	AddHook("CalcView", "ChangeFOV", changefov)
end

cvars.AddChangeCallback("raz_fov_enable", function()
	if GetConVarNumber("raz_fov_enable") == 1 then
		AddHook("CalcView", "ChangeFOV", changefov)
	else
		RemoveHook("CalcView", "ChangeFOV")
	end
end)


--[[
Fullbright
]]

local function fullbright()
	ForceVarAlt("mat_fullbright", 1)
end

if GetConVarNumber("raz_fullbright") == 1 then
	AddHook("Think", "Fullbright", fullbright)
end

cvars.AddChangeCallback("raz_fullbright", function()
	if GetConVarNumber("raz_fullbright") == 1 then
		AddHook("Think", "Fullbright", fullbright)
	else
		RemoveHook("Think", "Fullbright")
		ForceVarAlt("mat_fullbright", 0)
	end
end)

--[[	
Crosshair functions
]]



	local function cross()
	local showstuff = "" 
	local SpinSpeed = GetConVarNumber("raz_crosshair_spin_speed")
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() and LocalPlayer():GetEyeTrace().Entity:IsValid() then
		SpinSpeed = SpinSpeed * 2
		showstuff = true
	else
		SpinSpeed = SpinSpeed
		showstuff = false
	end
	local Ete = LocalPlayer():GetEyeTrace().Entity
	local Size = GetConVarNumber("raz_crosshair_spin_size")
	local skill = ""
	local rank = ""
	local dist = ""
	local dist2 = ""
	local money = ""
	local job = ""
	local money = ""
	local x = ScrW() / 2 
	local y = ScrH() / 2
	local spin1 = math.sin(CurTime()*SpinSpeed)*4
	local spin2 = math.cos(CurTime()*SpinSpeed)*4
	local static1 = ScrW() / 2
	local static2 = ScrH() / 2
	local static3 = 10
	local x, y, s = ScrW() / 2, ScrH() / 2, 10

	
	if (showstuff) then
		if Ete:Health() < 100 then
			dist3 = x+50
		end
		if Ete:Health() > 99 then
			dist3 = x+52
		end
		draw.DrawText("Health: "..Ete:Health(), "Default", dist3,y-60, Color(0,155,255), 1)
		if Ete.DarkRPVars then
			money = Ete.DarkRPVars.money
			job = Ete.DarkRPVars.job
			draw.DrawText("Money: $"..money, "Default", x+58,y-30, Color(0,155,255), 1)
			draw.DrawText("Job: "..job, "Default", x+58,y-20, Color(0,155,255), 1)
		end
		if LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Damage then
			skill = math.ceil(Ete:Health()/LocalPlayer():GetActiveWeapon().Primary.Damage)
			dist2 = x+63
		else
			skill = "Can't calculate with your gun"
			dist2 = x+134
		end
		draw.DrawText("Shoots to Kill: "..skill, "Default", dist2, y-50, Color(0,155,255), 1)
		if Ete:IsValid() then
			rank = "User"
			dist = x+51
			if Ete:IsAdmin() then
				rank = "Admin"
				dist = x+56
			end
			if Ete:IsSuperAdmin() then
				rank = "Superadmin"
				dist = x+69
			end
		end
		draw.DrawText("Rank: "..rank, "Default", dist, y-40, Color(0,155,255), 1)
	end
	surface.SetDrawColor(CrossColor(v))
	if GetConVarNumber("raz_crosshair_spin") == 1 then
		surface.DrawLine( x+spin1*2*Size,y-spin2*2*Size,x+spin1*5*Size,y-spin2*5*Size )
		surface.DrawLine( x-spin2*2*Size,y-spin1*2*Size,x-spin2*5*Size,y-spin1*5*Size )
		surface.DrawLine( x-spin1*2*Size,y+spin2*2*Size,x-spin1*5*Size,y+spin2*5*Size )
		surface.DrawLine( x+spin2*2*Size,y+spin1*2*Size,x+spin2*5*Size,y+spin1*5*Size )
	else
		surface.DrawLine( static1, static2 - static3, static1, static2 + static3 )
		surface.DrawLine( static1 - static3, static2, static1 + static3, static2 )	
	end
	
end


if GetConVarNumber("raz_crosshair") == 1 then
	AddHook("HUDPaint", "spin", cross)
end

cvars.AddChangeCallback("raz_crosshair", function()
	if GetConVarNumber("raz_crosshair") == 1 then
		AddHook("HUDPaint", "spin", cross)
	else
		RemoveHook("HUDPaint", "spin")
	end
end)

--[[
ATM Bruteforce
Probaly the longest function in the whole script
]]

concommand.Remove("raz_atm_bruteforce")

concommand.Add("raz_atm_bruteforce", function()

local count = 0
local pincodes = {}
for pin=1,9999 do
	if pin > 0 and pin < 10 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 000"..pin..". Inserting now.")
			table.insert(pincodes,"000"..pin)
			--file.Append("PINZ.txt", "000"..pin.."\n")
		end)
	end
	if pin > 9 and pin < 100 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 00"..pin..". Inserting now.")
			table.insert(pincodes,"00"..pin)
			--file.Append("PINZ.txt", "00"..pin.."\n")
		end)
	end
	if pin > 99 and pin < 1000 then
		timer.Simple(pin*.0002, function()
			print("Generated pin 0"..pin..". Inserting now.")
			table.insert(pincodes,"0"..pin)
			--file.Append("PINZ.txt", "0"..pin.."\n")
		end)
	end
	if pin > 999 and pin < 10000 then
		timer.Simple(pin*.0002, function()
			if pin == 9999 then
				print("Generated pin "..pin..". Inserting now.")
				table.insert(pincodes,pin)
				print("")
				print("All Pins generated!")
				print("")
				print("I wouldn't crack those admins account: ")
				for k,v in pairs(player.GetAll()) do
					if v:IsAdmin() then
						if v:IsSuperAdmin() then
							print(v:Name().. " - Superadmin")
						else
							print(v:Name().. " - Admin")
						end
					end
				end
				print("")
				print("How to use: ")
				print("")
				print('Type "raz_atm_bruteforce <Name> <Amount>" near an ATM to start bruteforcing!"')
				print("")
				print("It should look like this:")
				print("")
				print('raz_atm_bruteforce "Razor Sharp" 1000')
				print("")

				--file.Append("PINZ.txt", pin.."\n")
			else
				print("Generated pin "..pin..". Inserting now.")
				table.insert(pincodes,pin)
				--file.Append("PINZ.txt", pin.."\n")
			end
		end)	
	end
end

local function bruteit(use,less,args)
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Name()), string.lower(args[1])) then
			print("Bruteforce will begin in 3 seconds...")
			timer.Simple(3, function()
				local name = v:Name()
				local uid = v:UniqueID()
				for tab, qpin in pairs(pincodes) do 
					timer.Simple(qpin*.005, function()
						print("Trying pin "..qpin.." on the account of "..name..".")
						RunConsoleCommand("rp_atm_withdraw", util.CRC(qpin), uid, args[2])
					end)
				end
			end)
		end
	end
end
local function bruteall(use,less,args)
	for k,v in pairs(player.GetAll()) do
		for tab, qpin in pairs(pincodes) do
			increasetimetonextbrute()
			timer.Simple(qpin*.002+timetillnextbrute, function()
				print("Trying pin "..qpin.." on the account of "..v:Name()..".")
				RunConsoleCommand("rp_atm_withdraw", util.CRC(qpin), v:UniqueID(), args[1])
				if qpin == 9999 then
					count = 0
				end
			end)
		end
	end
end
local function increasetimetonextbrute()
	if count == 0 then
		count = .08
	end
	count = count+.08
	local delaytillnextbrute = .03
	local thistoaddtillnextbrute = .03
	local timetillnextbrute = thistoaddtillnextbrute+delaytillnextbrute*count
end


concommand.Remove("raz_atm_bruteforce")
timer.Simple(0.2, function()
	concommand.Add("raz_atm_bruteforce", bruteit)
	concommand.Add("raz_atm_bruteforce_all", bruteall)
end)



end)

concommand.Remove("raz_atm_bruteforce_all")

--[[
Aimbot
This Aimbot is badly coded, but it works atleast.
I didn't want to make one in first place, but
]]

RunConsoleCommand("raz_aimbot_autosnap", 0)

local targethead = ""
local targetheadpos = ""

randombonecalcted = false

local function aimbot()
	for k, v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and IsVisibleTrace(v) and InFOV(v) and InDist(v) and v:GetModel() != "" and v:GetModel() != "models/error.mdl" and v:GetModel() != "models/player.mdl" then
			if v != LocalPlayer() then
				if (v.Whitelisted) then
					v.Targetable = false
				else
					v.Targetable = true
				end
				if v:GetFriendStatus() == "friend" then
					if GetConVarNumber("raz_targetfriends") != 1 and (v.Targetable) then
						v.Targetable = false
					else
						v.Targetable = true
					end
				end
				local prediction = ( __R.Entity.GetVelocity(v) * 0.0067 - __R.Entity.GetVelocity(LocalPlayer()) * 0.0067 )
				if GetConVarNumber("raz_targetteam") == 0 and (v.Targetable) then
					if v:Team() == LocalPlayer():Team() then
						v.Targetable = false
					else
						v.Targetable = true
					end
				end
				if (v.Targetable) then
				if GetConVarString("raz_aimbot_bone") == "random" then
					if !(randombonecalcted) then
						targethead = v:LookupBone(table.Random(raz.randombones))         
						targetheadpos = v:GetBonePosition(targethead) 
						randombonecalcted = true
					end
				else
					targethead = v:LookupBone(GetConVarString("raz_aimbot_bone"))         
					targetheadpos = v:GetBonePosition(targethead)  
				end
				LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle() + prediction)
				if GetConVarNumber("raz_aimbot_autofire") == 1 then
					if LocalPlayer():GetEyeTrace().Entity:IsPlayer() and LocalPlayer():GetEyeTrace().Entity:Alive() and LocalPlayer():GetEyeTrace().Entity:IsValid() then
						RunConsoleCommand("+attack")
					elseif !(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then
						RunConsoleCommand("-attack")
					end
				end
				end
			end
		end
	end    
end

concommand.Add("+raz_aim", function()
	AddHook("Think","aimbot",aimbot)
	randombonecalcted = false
	for k,v in pairs(player.GetAll()) do
		v.Targetable = false
	end
end)

concommand.Add("-raz_aim", function()
	RemoveHook("Think","aimbot")
	RunConsoleCommand("-attack")
	randombonecalcted = true
	for k,v in pairs(player.GetAll()) do
		v.Targetable = false
	end
end)

local function autosnap()
	for k, v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and IsVisibleTrace(v) and InFOV(v) and InDist(v) then
			if v != LocalPlayer() then
				if v:GetFriendStatus() == "friend" then
					if GetConVarNumber("raz_targetfriends") != 1 then
						return
					end
				end
				if GetConVarNumber("raz_targetteam") != 1 then
					if v:Team() == LocalPlayer():Team() then
						return
					end
				end
				AddHook("Think", "aimbot", aimbot)
			end
		end
	end
end

RemoveHook("Think", "autosnap")

cvars.AddChangeCallback("raz_aimbot_autosnap", function()
	if GetConVarNumber("raz_aimbot_autosnap") == 1 then
		AddHook("Think", "autosnap", autosnap)
	else
		RemoveHook("Think", "autosnap")
		RemoveHook("Think", "aimbot")
	end
end)

-- This is gay

--[[
Traitorfinder
Tell everyone who's the Traitor.
]]

local tweapons = { 
	"weapon_ttt_sipistol", 
	"weapon_ttt_flaregun",  
	"weapon_ttt_teleport",
	"spiderman's_swep", 
	"weapon_ttt_trait_defilibrator", 
	"weapon_ttt_xbow", 
	"weapon_ttt_dhook", 
	"weapon_awp", 
	"weapon_jihadbomb", 
	"weapon_ttt_knife", 
	"weapon_ttt_c4", 
	"weapon_ttt_decoy", 
	"weapon_ttt_phammer", 
	"weapon_ttt_push", 
	"weapon_ttt_radio", 
	"weapon_ttt_awp", 
	"weapon_ttt_silencedsniper", 
	"weapon_ttt_turtlenade", 
	"weapon_ttt_death_station",
	"weapon_ttt_sg552", 
	"(Disguise)",
	"weapon_ttt_tripmine"
}

first = true

local function traitorfinder()
	if first then
		for k,v in pairs(player.GetAll()) do
			v.IsTracked = false
			v.IsTraitor = false
			first = false
		end
	end
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and GAMEMODE.round_state != ROUND_ACTIVE then
			v.IsTracked = false
			v.IsTraitor = false
		end
	end
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and GAMEMODE.round_state == ROUND_ACTIVE and !(v.IsTracked) and v:Team() ~= TEAM_SPECTATOR then
			for k2, v2 in pairs(v:GetWeapons()) do
					if table.HasValue( tweapons,v2:GetClass() ) then
						if v:IsDetective() then
							v.IsTracked = true
						else
							v.IsTracked = true
							v.IsTraitor = true
							chat.AddText(Color(255,0,0),v:Name(),Color(0,255,0)," is a ",Color(255,0,0),"traitor ", Color(0,255,0), "with a "..v2:GetClass())
						end
					end
				end
			end
		end
	end
	
if GetConVarNumber("raz_traitorfinder") == 1 then
	AddHook("Think", "T-Finder", traitorfinder)
end

cvars.AddChangeCallback("raz_traitorfinder", function()
	if GetConVarNumber("raz_traitorfinder") == 1 then
		AddHook("Think", "T-Finder", traitorfinder)
	else
		RemoveHook("Think", "T-Finder")
	end
end)

--[[
No recoil
It doesn't work on every Weapon!
I tried several weapons and these work:
CS:S Realistic Weapons
All (default) TTT-Guns
]]

local function norecoil()
	if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
	end
end

if GetConVarNumber("raz_norecoil") == 1 then
	AddHook("Think", "NoRecoil", norecoil)
end

cvars.AddChangeCallback("raz_norecoil", function()
	if GetConVarNumber("raz_norecoil") == 1 then
		AddHook("Think", "NoRecoil", norecoil)
	else
		RemoveHook("Think", "NoRecoil", norecoil)
	end
end)

--[[
NoSpread
It doesn't work on every Weapon!
I tried several weapons and these work:
CS:S Realistic Weapons
All (default) TTT-Guns
]]

local function nospread()
	if LocalPlayer():GetActiveWeapon().Primary then
		LocalPlayer():GetActiveWeapon().Primary.Cone = 00
	end
end

if GetConVarNumber("raz_nospread") == 1 then
	AddHook("Think", "NoSpread", nospread)
end

cvars.AddChangeCallback("raz_nospread", function()
	if GetConVarNumber("raz_nospread") == 1 then
		AddHook("Think", "NoSpread", nospread)
	else
		RemoveHook("Think", "NoSpread", nospreads)
	end
end)

--[[
Flashlight Spam
Do it infront of admin with antiaim enabled
]]

local function spamflashlight()
	if LocalPlayer():IsTyping() then
		return
	end
	if input.IsKeyDown(KEY_F) then
		timer.Simple(0.01, function()
			RunConsoleCommand("impulse", "100")
		end)
		timer.Simple(0.02, function()
			RunConsoleCommand("impulse", "100")
		end)
	end
end

if GetConVarNumber("raz_fspam") == 1 then
	AddHook("CreateMove", "fspam", spamflashlight)
end

cvars.AddChangeCallback("raz_fspam", function()
	if GetConVarNumber("raz_fspam") == 1 then
		AddHook("CreateMove", "fspam", spamflashlight)
	else
		RemoveHook("CreateMove", "fspam")
	end
end)

--[[
Anti-Aimbot
Hack vs Hack feature
Makes aiming on your head harder.
]]

local function antiaim()
	if !(input.IsMouseDown(MOUSE_LEFT)) and !(input.IsMouseDown(MOUSE_RIGHT)) then
		local random1 = math.random(-150,300)
		local random2 = math.random(100,250)
		local a = LocalPlayer():EyeAngles()
		LocalPlayer():SetEyeAngles(Angle(a.p+random2, a.y+random1, a.r))
	end
end

cvars.AddChangeCallback("raz_antiaim", function()
	if GetConVarNumber("raz_antiaim") == 1 then
		AddHook("Think", "Anti-Aim", antiaim)
	else
		RemoveHook("Think", "Anti-Aim")
	end
end)

RunConsoleCommand("raz_antiaim", 0)

--[[
AimLine
]]

local function aimline()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() and v != LocalPlayer() and InDist(v) then   
			local ang = Angle( 0, v:EyeAngles().y, 0 )
			local boonepos = (v:GetShootPos()):ToScreen()
			local booneendpos = Vector(100,0,0)
			booneendpos:Rotate( ang )
			booneendpos = (booneendpos + v:GetShootPos()):ToScreen()
			surface.SetDrawColor(255,0,0,255)
			surface.DrawLine(boonepos.x, boonepos.y, booneendpos.x, booneendpos.y)
		end
	end
end

if GetConVarNumber("raz_los") == 1 then
	AddHook("HUDPaint", "LineOfSight", aimline)
end

cvars.AddChangeCallback("raz_los", function()
	if GetConVarNumber("raz_los") == 1 then
		AddHook("HUDPaint", "LineOfSight", aimline)
	else
		RemoveHook("HUDPaint", "LineOfSight")
	end
end)

--[[
Ropespam
Spam the whole server
]]

local oldmaterial = GetConVarString("rope_material")
local oldwidth = GetConVarNumber("rope_width")

local function ropespam()
	RunConsoleCommand("rope_width", 100000000000)
	RunConsoleCommand("rope_material", "pp/sharpen")
	local rrandom1 = math.random(-90,90)
	local rrandom2 = math.random(-180,180)
	if GetConVarString("rope_material") != "pp/sharpen" then
		return
	end
	timer.Simple(0.02, function()
		local a = LocalPlayer():EyeAngles()
		LocalPlayer():ConCommand("+attack2")
		LocalPlayer():SetEyeAngles(Angle(rrandom1, rrandom2, a.r))
	end)
	timer.Simple(0.03, function()
		local a = LocalPlayer():EyeAngles()
		LocalPlayer():SetEyeAngles(Angle(rrandom1, rrandom2, a.r))
		LocalPlayer():ConCommand("-attack2")
	end)

end


concommand.Add("+raz_ropespam", function()
	AddHook("Think", "Ropespam", ropespam)
end)

concommand.Add("-raz_ropespam", function()
	RemoveHook("Think", "Ropespam")
	RunConsoleCommand("rope_width", oldwidth)
	RunConsoleCommand("rope_material", oldmaterial)
end)

--[[
Use spam
]]

local function usespam()
	timer.Simple(0.015, function()
		LocalPlayer():ConCommand("+use")
	end)
	timer.Simple(0.025, function()
		LocalPlayer():ConCommand("-use")
	end)
end

concommand.Add("+raz_usespam", function()
	AddHook("Think", "Usespam", usespam)
end)

concommand.Add("-raz_usespam", function()
	RemoveHook("Think", "Usespam")
end)


--[[
Entity ESP
Fucking Awesome Box!
]]

trackents = { -- Add Entities to track here, or use ingame function.
"printer",
"spawned_",
"weapon_ttt_awp",
"weapon_jihadbomb",
"weapon_ttt_death_station",
"weapon_ttt_flaregun",
"weapon_ttt_knife",
"weapon_ttt_phammer",
"weapon_ttt_push",
"weapon_perp_glock",
"m9k_ammo_",
"weapon_ttt_health_station",
"weapon_ttt_c4",
"weapon_ttt_decoy",
}



local espcolor = ""

local function entityesp()
	for k,v in pairs(ents.GetAll()) do
		for i,s in pairs(trackents) do
			if v:IsValid() and string.find(v:GetClass(),s) and InDist(v) then
				if table.HasValue(tweapons, v:GetClass()) then 
					if v:GetOwner() == LocalPlayer() then 
						return 
					end
				end
				local ang = Angle(0, v:GetAngles().y, 0)
				local i,x = v:WorldSpaceAABB()
				local diff = x-i
				local pos = (v:GetPos()+Vector(0,0,20)):ToScreen()
				local pos2 = Vector(0,0,0)
				local pos1 = Vector(0,0,0)
				local pos3 = Vector(0,0,0)
				local pos4 = Vector(0,0,0)
				local pos5 = Vector(0,0,diff.z)
				local pos6 = Vector(0,0,diff.z)
				local pos7 = Vector(0,0,diff.z)
				local pos8 = Vector(0,0,diff.z)

				pos1 = (pos1 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos2 = (pos2 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos3 = (pos3 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos4 = (pos4 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				pos5 = (pos5 + v:WorldSpaceAABB() + Vector(diff.x,diff.y,0)):ToScreen()
				pos6 = (pos6 + v:WorldSpaceAABB() + Vector(diff.x,-diff.y/14,0)):ToScreen()
				pos7 = (pos7 + v:WorldSpaceAABB() + Vector(-diff.x/14,-diff.y/14,0)):ToScreen()
				pos8 = (pos8 + v:WorldSpaceAABB() + Vector(-diff.x/14,diff.y,0)):ToScreen()
				surface.SetDrawColor(0,0,0)
				
				surface.DrawLine(pos1.x,pos1.y,pos2.x,pos2.y)
				surface.DrawLine(pos2.x,pos2.y,pos3.x,pos3.y)
				surface.DrawLine(pos3.x,pos3.y,pos4.x,pos4.y)
				surface.DrawLine(pos1.x,pos1.y,pos4.x,pos4.y)
				
				surface.SetDrawColor(255,0,0)
				
				surface.DrawLine(pos1.x,pos1.y,pos5.x,pos5.y)
				surface.DrawLine(pos2.x,pos2.y,pos6.x,pos6.y)
				surface.DrawLine(pos3.x,pos3.y,pos7.x,pos7.y)
				surface.DrawLine(pos4.x,pos4.y,pos8.x,pos8.y)
				
				surface.SetDrawColor(0,0,255)
				
				surface.DrawLine(pos5.x,pos5.y,pos6.x,pos6.y)
				surface.DrawLine(pos6.x,pos6.y,pos7.x,pos7.y)
				surface.DrawLine(pos7.x,pos7.y,pos8.x,pos8.y)
				surface.DrawLine(pos8.x,pos8.y,pos5.x,pos5.y)
				
				cam.Start3D()
					v:SetMaterial("models/wireframe")
					if !(IsVisible(v)) then
						espcolor = Color(255,191,0,255)
					else
						espcolor = Color(63,127,0,255)
					end
					render.SetColorModulation(espcolor.r / 255, espcolor.g / 255, espcolor.b / 255)
					render.SetBlend( espcolor.a / 255 )
					v:DrawModel()
				cam.End3D()
				draw.SimpleText(v:GetClass(), "Default", pos.x, pos.y, Color(255,255,255,255), 1)
			elseif v:IsValid() and string.find(v:GetClass(),s) and !(InDist(v)) then
				cam.Start3D()
					v:SetMaterial("")
					render.SetColorModulation(1,1,1)
					render.SetBlend(1)
				cam.End3D()
			end
		end
	end
end

if GetConVarNumber("raz_entesp") == 1 then
	AddHook("HUDPaint", "EntityESP", entityesp)
end

cvars.AddChangeCallback("raz_entesp", function()
	if GetConVarNumber("raz_entesp") == 1 then
		AddHook("HUDPaint", "EntityESP", entityesp)
	else
		RemoveHook("HUDPaint", "EntityESP")
		for k,v in pairs(ents.GetAll()) do
			for i,s in pairs(trackents) do
				if v:IsValid() and string.find(v:GetClass(),s) then
					cam.Start3D()
						v:SetMaterial("")
						render.SetColorModulation(1,1,1)
						render.SetBlend(1)
					cam.End3D()
				end
			end
		end
	end
end)

local function addentity()
	if LocalPlayer():GetEyeTrace().Entity:IsValid() and !(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then
		table.insert(trackents, LocalPlayer():GetEyeTrace().Entity:GetClass())
		print("Added "..LocalPlayer():GetEyeTrace().Entity:GetClass().." to the entity list.")
	end
end

local function removeentity()
	if LocalPlayer():GetEyeTrace().Entity:IsValid() and !(LocalPlayer():GetEyeTrace().Entity:IsPlayer()) then
		for k,v in pairs(trackents) do
			if v == LocalPlayer():GetEyeTrace().Entity:GetClass() then
				table.remove(trackents,k)
				print("Removed "..LocalPlayer():GetEyeTrace().Entity:GetClass().." from the entity list.")
				cam.Start3D()
					for i,s in pairs(ents.GetAll()) do
						if s:GetClass() == LocalPlayer():GetEyeTrace().Entity:GetClass() then
							s:SetMaterial("")
							render.SetColorModulation(1,1,1)
							render.SetBlend(1)
						end
					end
				cam.End3D()
			end
		end
	end
end

concommand.Add("raz_entesp_add", addentity)
concommand.Add("raz_entesp_remove", removeentity)


-- It will get better.

--[[
Breakfall and Propclimb
]]

local function pclimb()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(180, a.y, a.r))
	RunConsoleCommand("+attack")
	timer.Simple(0.1, function()
		LocalPlayer():ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
	end)
	timer.Simple(0.2, function()
		RunConsoleCommand("+jump")
	end)
	timer.Simple(0.4, function()
		RunConsoleCommand("-jump")
		LocalPlayer():SetEyeAngles(Angle(-90,a.y,a.r))
	end)
end

concommand.Add("+raz_propclimb", function()
	pclimb()
end)

concommand.Add("-raz_propclimb", function()
	RunConsoleCommand("-attack")
	RunConsoleCommand("undo")
end)

-- Need to time perfectly

concommand.Add("raz_breakfall", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(50, a.y, a.r))
	LocalPlayer():ConCommand("gm_spawn models/props_phx/construct/wood/wood_dome360.mdl")
	timer.Simple(0.5, function()
		RunConsoleCommand("undo")
	end)
end)

concommand.Add("raz_breakfall2", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(180, a.y, a.r))
	timer.Simple(0.02,function()
		RunConsoleCommand("gm_spawn", "models/hunter/tubes/tube1x1x3.mdl")
	end)
	timer.Simple(0.5, function()
		RunConsoleCommand("undo")
	end)
end)


--[[
TTT Propkill
]]

-- You need to try around with this one.

concommand.Add("raz_ttt_pkill", function()
	local a = LocalPlayer():EyeAngles() 
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y-120, a.r))
end)

--[[
Spin me right round
Don't ask.
]]

RunConsoleCommand("raz_spinme", 0)

local oldview = LocalPlayer():EyeAngles() 


local function spinmerightround()
	local a = LocalPlayer():EyeAngles() 
	local spin1 = 1
	local spin2 = 1.2
	LocalPlayer():SetEyeAngles(Angle(a.p, a.y+spin1+spin2, a.r+spin1+spin2))
end

cvars.AddChangeCallback("raz_spinme", function()
	if GetConVarNumber("raz_spinme") == 1 then
		AddHook("Think", "Spinme", spinmerightround)
	else
		RemoveHook("Think", "Spinme")
		LocalPlayer():SetEyeAngles(Angle(0, 0, 0))
	end
end)

--[[
Support me
]]

RunConsoleCommand("raz_supportme", 0)

local delaysupport = false

local function supportrazor()
	if !(delaysupport) then
		if GAMEMODE.Name == "DarkRP" then
			delaysupport = true
			timer.Simple(1.5, function()
				delaysupport = false
			end)
			LocalPlayer():ConCommand("say /advert I'm using RAZ v"..raz.version..".")
		else			
			delaysupport = true
			timer.Simple(1.5, function()
				delaysupport = false
			end)
			LocalPlayer():ConCommand("say I'm using RAZ v"..raz.version..".")
		end
	end
end

cvars.AddChangeCallback("raz_supportme", function()
	if GetConVarNumber("raz_supportme") == 1 then
		AddHook("Think", "SupportMe", supportrazor)
	else
		RemoveHook("Think", "SupportMe")
	end
end)

--[[
Murder Hacks
]]

local oldchamvalue = ""
local oldvaluecalced = false

local function murderhacks()
	oldvaluecalced = false
	if GetConVarNumber("raz_chams") == 1 and !(oldvaluecalced) then
		oldchamvalue = GetConVarNumber("raz_chams")
		oldvaluecalced = true
		RunConsoleCommand("raz_chams",0)
		return
	end
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() and v != LocalPlayer() and v:Alive() then
			for wt, weps in pairs(v:GetWeapons()) do
				if weps:GetPrintName() == "Knife" then
					cam.Start3D()
						v:SetMaterial("models/wireframe")
						local col = Color(255,0,0,255)
						render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
						render.SetBlend(col.a / 255)
						v:DrawModel()
					cam.End3D()
				end
				if weps:GetPrintName() == "Magnum" then
					cam.Start3D()
						v:SetMaterial("models/wireframe")
						local col = Color(0,255,0,255)
						render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
						render.SetBlend(col.a / 255)
						v:DrawModel()
					cam.End3D()
				end
			end
		end
	end
end

if GetConVarNumber("raz_murderhacks") == 1 then
	AddHook("HUDPaint", "MurderHacks", murderhacks)
end

cvars.AddChangeCallback("raz_murderhacks", function()
	if GetConVarNumber("raz_murderhacks") == 1 then
		AddHook("HUDPaint", "MurderHacks", murderhacks)
	else
		RemoveHook("HUDPaint", "MurderHacks")
		if (oldvaluecalced) then
			RunConsoleCommand("raz_chams", oldchamvalue)
			oldvaluecalced = false
		end
	end
end)

--[[
Walkbot
]]

local walkforme = false

local function walkbot()
	if (walkforme) then
		RunConsoleCommand("+forward")
	else
		RunConsoleCommand("-forward")
	end
end

concommand.Add("raz_walkbot", function()
	if !(walkforme) then
		walkforme = true
		walkbot()
	elseif (walkforme) then
		walkforme = false
		walkbot()
	end
end)

--[[
Auto-BHOP
]]

local bhopforme = true

local function autobhop()
	if GetConVarNumber("raz_bhop") == 1 then
		RunConsoleCommand("raz_bhop", 0)
	end
	if LocalPlayer():IsOnGround() then
		RunConsoleCommand("+jump")
	else
		RunConsoleCommand("-jump")
	end
end

concommand.Add("raz_autobhop", function()
	if !(bhopforme) then
		RemoveHook("Think", "Auto-BHOP")
		bhopforme = true
	elseif (bhopforme) then
		AddHook("Think", "Auto-BHOP", autobhop)
		bhopforme = false
	end
end)

--[[
RP Act
]]

local actdelay = false

local acttable = {
	{ Act = ACT_GMOD_TAUNT_LAUGH, Delay = 6.3 },
	{ Act = ACT_GMOD_TAUNT_PERSISTENCE, Delay = 3.1 },
	{ Act = ACT_GMOD_GESTURE_DISAGREE, Delay = 2.7 },
	{ Act = ACT_GMOD_GESTURE_AGREE, Delay = 2.7},
	{ Act = ACT_GMOD_GESTURE_WAVE, Delay = 3.7 },
	{ Act = ACT_GMOD_GESTURE_BECON, Delay = 3.4 },
	{ Act = ACT_GMOD_TAUNT_MUSCLE, Delay = 13 },
	{ Act = ACT_GMOD_GESTURE_BOW, Delay = 3 },
}

local function rpact()
	if GAMEMODE.Name != "DarkRP" then
		LocalPlayer():ChatPrint("You're not playing DarkRP!")
		RunConsoleCommand("raz_rpact", 0)
		return
	end
	if !(actdelay) then
		local act = table.Random(acttable)
		RunConsoleCommand("_DarkRP_DoAnimation", act.Act)
		actdelay = true
		timer.Simple(act.Delay, function()
			actdelay = false
		end)
	end
end

RunConsoleCommand("raz_rpact", 0)

cvars.AddChangeCallback("raz_rpact", function()
	if GetConVarNumber("raz_rpact") == 1 then
		AddHook("Think", "rp_act", rpact)
		actdelay = false
	else
		RemoveHook("Think", "rp_act", rpact)
		actdelay = false
	end
end)

--[[
Menu
]]


local function menu()


local Panel = vgui.Create( "DFrame" )
Panel:SetSize(500, 500)
Panel:SetTitle( "RAZ v"..raz.version.." || Menu" )
Panel:SetVisible( true )
Panel:SetDraggable( true )
Panel:ShowCloseButton( true )
Panel:MakePopup()
Panel:Center()


local Sheet = vgui.Create( "DPropertySheet" )
Sheet:SetParent( Panel )
Sheet:SetPos( 20, 30 )
Sheet:SetSize( 450, 450 )

f1 = vgui.Create("DPanel", Sheet)
f1:SetSize(400, 400)
function f1:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(255,150,30) )
end

f2 = vgui.Create("DPanel", Sheet)
f2:SetSize(400, 400)
function f2:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(50,150,60) )
end

f3 = vgui.Create("DPanel", Sheet)
f3:SetSize(400, 400)
function f2:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(150,70,65) )
end

f4 = vgui.Create("DPanel", Sheet)
f4:SetSize(400, 400)
function f3:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(90,30,20) )
end



local AimA2 = vgui.Create( "DNumSlider", f1 )
AimA2:SetPos( 5,25 )
AimA2:SetSize( 380, 20 )
AimA2:SetText( "Aimbot FOV" )
AimA2:SetMin( 1 )
AimA2:SetMax( 360 )
AimA2:SetDecimals( 0 )
AimA2:SetConVar( "raz_aimbot_fov" )

local AimA5 = vgui.Create( "DButton" )
AimA5:SetParent( f1 )
AimA5:SetText( "Open the menu to select the aimbot bone." )
AimA5:SetPos( 5, 90 )
AimA5:SetSize( 250, 30 )
AimA5.DoClick = function ()
    RunConsoleCommand( "raz_aimbot_bone_menu" )
end

local AimA5 = vgui.Create( "DButton" )
AimA5:SetParent( f1 )
AimA5:SetText( "Open aimbot whitelist" )
AimA5:SetPos( 260, 90 )
AimA5:SetSize( 150, 30 )
AimA5.DoClick = function ()
    RunConsoleCommand( "raz_shitlist" )
end

local radiusa1 = vgui.Create( "DNumSlider", f1 )
radiusa1:SetPos( 5,370 )
radiusa1:SetSize( 380, 20 )
radiusa1:SetText( "Hack Radius" )
radiusa1:SetMin( 1 )
radiusa1:SetMax( 100000 )
radiusa1:SetDecimals( 0 )
radiusa1:SetConVar( "raz_radius" )

local function addabox(Name, Text, Convar, posa,posb)
local Name = vgui.Create( "DCheckBoxLabel")
Name:SetParent(f1)
Name:SetText( Text )
Name:SetConVar( Convar )
Name:SetValue( GetConVarNumber( Convar ) )
Name:SizeToContents()
Name:SetSize(500, 20)
Name:SetPos(posa, posb)
end

addabox(aim, "Target Steam Friends", "raz_targetfriends", 5, 5)
addabox(aim2, "Enable Autofire (Aimbot)", "raz_aimbot_autofire", 5, 50)
addabox(aim3, "Enable Autosnap (Aimbot)", "raz_aimbot_autosnap", 5, 70)
addabox(aim4, "Enable Traces", "raz_traces", 5, 130)
addabox(aim5, "Enable Triggerbot", "raz_triggerbot", 5, 150)
addabox(aim6, "Enable Rapidfire", "raz_rapidfire",5,170)
addabox(aim8, "Enable Namestealer", "raz_namesteal", 5, 190)
addabox(aim9, "Enable RP-God (Only works with DarkRP 2.4.3 and below.", "raz_rpgod", 5, 210)
addabox(aim10, "Enable Traitorfinder", "raz_traitorfinder", 5, 230)
addabox(aim11, "Enable NoRecoil", "raz_norecoil", 5, 250)
addabox(aim12, "Enable NoSpread", "raz_nospread", 5, 270)
addabox(aim13, "Enable Flashlightspam", "raz_fspam", 5, 290)
addabox(aim14, "Enable BHop", "raz_bhop", 5, 310)
addabox(aim15, "Draw a line of the players view", "raz_los", 5, 330)
addabox(aim16, "Enable Anti-Aim", "raz_antiaim", 5, 350)
addabox(aim17, "Spin me", "raz_spinme", 5, 390)

local function addabox2(Name, Text, Convar, posa,posb)
local Name = vgui.Create( "DCheckBoxLabel")
Name:SetParent(f2)
Name:SetText( Text )
Name:SetConVar( Convar )
Name:SetValue( GetConVarNumber( Convar ) )
Name:SizeToContents()
Name:SetSize(500, 20)
Name:SetPos(posa, posb)
end

addabox2(espa1, "Enable ESP", "raz_esp", 5, 5)
addabox2(espa2, "Enable Chams", "raz_chams", 5, 25)
addabox2(espa3, "Chams Type (Ticked means solid, unticked means wireframe)", "raz_chams_type", 5, 45)
addabox2(espa4, "Enable Entity-ESP", "raz_entesp", 5, 65)
addabox2(espa5, "Enable Skeleton", "raz_skeleton", 5, 85)
addabox2(crosshair1, "Enable Crosshair", "raz_crosshair",5,105)
addabox2(crosshair2, "Spinning Crosshair", "raz_crosshair_spin", 5, 125)
addabox2(propwh, "Enable Propwallhack", "raz_propwh", 5, 145)
addabox2(fova1, "Enable FOV-Changer", "raz_fov_enable", 5, 165)

local function addabox3(Name, Text, Convar, posa,posb)
local Name = vgui.Create( "DCheckBoxLabel")
Name:SetParent(f3)
Name:SetText( Text )
Name:SetConVar( Convar )
Name:SetValue( GetConVarNumber( Convar ) )
Name:SizeToContents()
Name:SetSize(500, 20)
Name:SetPos(posa, posb)
end

local radiusa1 = vgui.Create( "DNumSlider", f2 )
radiusa1:SetPos( 5,185 )
radiusa1:SetSize( 380, 20 )
radiusa1:SetText( "FOV" )
radiusa1:SetMin( 1 )
radiusa1:SetMax( 179 )
radiusa1:SetDecimals( 0 )
radiusa1:SetConVar( "raz_fov" )


local CsA1 = vgui.Create( "DCheckBoxLabel" )
CsA1:SetParent(f3)
CsA1:SetText( "Enable Chatspam" )
CsA1:SetConVar( "raz_chatspam" )
CsA1:SetValue( GetConVarNumber( "raz_chatspam" ) )
CsA1:SetSize(250, 20)
CsA1:SetPos(5, 5)

local CsLabel = vgui.Create( "DLabel", f3 )
CsLabel:SetPos( 5, 25 )
CsLabel:SetSize(380,20)
CsLabel:SetText( "Type the text you want to spam, then press enter." )

local CsText = vgui.Create( "DTextEntry", f3)
CsText:SetPos( 5,50 )
CsText:SetTall( 20 )
CsText:SetWide( 380 )
CsText:SetEnterAllowed( true )
CsText.OnEnter = function()
    RunConsoleCommand("raz_chatspam_msg", CsText:GetValue())
end


Sheet:AddSheet( "Aim/Other functions here", f1, nil, false, false )
Sheet:AddSheet( "Visuals", f2,nil, false, false ) 
Sheet:AddSheet( "-- Will be added later!", f3, nil, false, false)
Sheet:AddSheet( "Web Broser (will be added soon)", f4, nil, false, false)
end

concommand.Add("raz_menu", function()
	menu()
end)

concommand.Add("raz_reseteverything", function()
	for k,v in pairs(raz.cvars) do
		RunConsoleCommand(v.Name, v.Value)
	end
end)

--[[
Execute Functions
]]

GetServerGameMode()

--[[
Print Stuff
]]

LocalPlayer():ChatPrint("Loaded RAZ v"..raz.version)
LocalPlayer():ChatPrint("The Autosnap function of the aimbot is still buggy (if you enabled autofire) !")
LocalPlayer():ChatPrint("Don't use it if you can't deal with bugs!")
LocalPlayer():ChatPrint("Thanks for using RAZ v"..raz.version.."!")

finin1sec = true

--[[

End of RAZ v1.0 (Alpha)
Not to be leaked.
Stay awesome

]]