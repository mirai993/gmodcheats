--[[


 /$$$$$$$   /$$$$$$  /$$      /$$ /$$$$$$$$ /$$$$$$$  /$$$$$$$   /$$$$$$  /$$$$$$$$                    /$$  
| $$__  $$ /$$__  $$| $$  /$ | $$| $$_____/| $$__  $$| $$__  $$ /$$__  $$|__  $$__/                  /$$$$  
| $$  \ $$| $$  \ $$| $$ /$$$| $$| $$      | $$  \ $$| $$  \ $$| $$  \ $$   | $$          /$$    /$$|_  $$  
| $$$$$$$/| $$  | $$| $$/$$ $$ $$| $$$$$   | $$$$$$$/| $$$$$$$ | $$  | $$   | $$         |  $$  /$$/  | $$  
| $$____/ | $$  | $$| $$$$_  $$$$| $$__/   | $$__  $$| $$__  $$| $$  | $$   | $$          \  $$/$$/   | $$  
| $$      | $$  | $$| $$$/ \  $$$| $$      | $$  \ $$| $$  \ $$| $$  | $$   | $$           \  $$$/    | $$  
| $$      |  $$$$$$/| $$/   \  $$| $$$$$$$$| $$  | $$| $$$$$$$/|  $$$$$$/   | $$            \  $/    /$$$$$$
|__/       \______/ |__/     \__/|________/|__/  |__/|_______/  \______/    |__/             \_/    |______/
                                                                                                           

--]]


	local ply = LocalPlayer()
    CreateClientConVar( "powerbot_config_threshold", 0, true, false )
    CreateClientConVar( "powerbot_config_godmode", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Misc", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Consumables", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Weapons", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Ammo", 0, true, false )
	
    CreateClientConVar( "powerbot_config_ESP_Salesman", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Generator", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Shipment", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Cash", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Legacy", 0, true, false )
    CreateClientConVar( "powerbot_config_ESP_Player", 0, true, false ) 
    CreateClientConVar( "powerbot_config_ESP_Player_Skeleton", 0, true, false ) 
    CreateClientConVar( "powerbot_config_ESP_Player_Cham", 0, true, false ) 
	CreateClientConVar( "powerbot_config_ESP_Holy_PowerBot", 0, true, false ) 
	CreateClientConVar( "powerbot_config_ESP_Player_Distance", 0, true, false )
	CreateClientConVar( "powerbot_screenshot", 0, true, false )


	local colors                            = {}
	red                                             = Color(255,0,0,255);
	black                                           = Color(0,0,0,255);
	yellow                                          = Color(255,255,0,255);
	green                                           = Color(0,255,0,255);
	white                                           = Color(255,255,255,255);
	blue                                            = Color(0,0,255,255);
	cyan                                            = Color(0,255,255,255);
	pink                                            = Color(255,0,255,255);
	blue                                            = Color(0,0,255,255);
	grey                                            = Color(100,100,100,255);
	gold                                            = Color(255,228,0,255);
	lblue                                           = Color(155,205,248);
	lgreen                                          = Color(174,255,0);
	iceblue                                         = Color(116,187,251,255);
	
	
function PowerBotPrintMessage(msg)

    print("[PWR]: "..msg)

end

concommand.Add('PowerBot_PrintEnts', function() 

	for k, v in pairs(ents.GetAll()) do 

PowerBotPrintMessage(v:GetClass()) end end)


PowerBotPrintMessage("Loading successful.")
PowerBotPrintMessage("Welcome to PowerBot.")
PowerBotPrintMessage("To undo the ESP suddenly disappearing type 'powerbot_screenshot 0' into console.")
PowerBotPrintMessage("Enjoy using PowerBotVision. The bestest private cheat.")


surface.CreateFont("DefaultSmallDropShadow", {
                font    = "Tahoma",
                size    = 16,
                weight  = 500,
                shadow  = true,
        }
)

function powerbotMenu()

        local powerbotMenuFrame = vgui.Create("DFrame")
		local PropertySheet = vgui.Create( "DPropertySheet" )
		PropertySheet:SetParent( powerbotMenuFrame )
		PropertySheet:SetPos( 0, 25 )
		PropertySheet:SetSize( 600, 575 )
		
 
        powerbotMenuFrame:SetPos((surface.ScreenWidth()/2) - 300,(surface.ScreenHeight()/2) - 300)
        powerbotMenuFrame:SetSize(600,600)
        powerbotMenuFrame:SetTitle("PowerBotVision")
        powerbotMenuFrame:MakePopup()

		local SheetItemTwo = vgui.Create( "DPanel" )
		SheetItemTwo:SetPos( 25, 50 )
		SheetItemTwo:SetSize( 250, 250 )
		SheetItemTwo.Paint = function() -- Paint function
		surface.SetDrawColor( 50, 50, 50, 255 ) -- Set our rect color below us; we do this so you can see items added to this panel
		surface.DrawRect( 0, 0, SheetItemTwo:GetWide(), SheetItemTwo:GetTall() ) -- Draw the rect
		end
		
		local SheetItemOne = vgui.Create( "DPanel" )
		SheetItemOne:SetPos( 25, 50 )
		SheetItemOne:SetSize( 250, 250 )
		SheetItemOne.Paint = function() -- Paint function
		surface.SetDrawColor( 50, 50, 50, 255 ) -- Set our rect color below us; we do this so you can see items added to this panel
		surface.DrawRect( 0, 0, SheetItemOne:GetWide(), SheetItemOne:GetTall() ) -- Draw the rect
		end
		
		local PowerBotGodmodeToggle = vgui.Create( "DCheckBoxLabel", SheetItemOne )
		PowerBotGodmodeToggle:SetPos( 15,15 )
		PowerBotGodmodeToggle:SetText( "Enable Godmode" )
		PowerBotGodmodeToggle:SetConVar( "powerbot_config_godmode" )
		PowerBotGodmodeToggle:SizeToContents()

		local PowerBotGodmodeSlider = vgui.Create( "DNumSlider", SheetItemOne )
		PowerBotGodmodeSlider:SetPos( 15,35 )
		PowerBotGodmodeSlider:SetSize( 250, 25 )
		PowerBotGodmodeSlider:SetText( "Godmode HP Threshold" )
		PowerBotGodmodeSlider:SetMin( 10 )
		PowerBotGodmodeSlider:SetMax( 99 )
		PowerBotGodmodeSlider:SetDecimals( 0 )
		PowerBotGodmodeSlider:SetConVar( "powerbot_config_threshold" )
		
		local PowerBotESPToggle = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPToggle:SetPos( 15,15 )
		PowerBotESPToggle:SetText( "Enable Misc Item ESP" )
		PowerBotESPToggle:SetConVar( "powerbot_config_ESP_Misc" )
		PowerBotESPToggle:SizeToContents()
		
		local PowerBotESPConsumables = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPConsumables:SetPos( 15,30 )
		PowerBotESPConsumables:SetText( "Enable Medical ESP" )
		PowerBotESPConsumables:SetConVar( "powerbot_config_ESP_Consumables" )
		PowerBotESPConsumables:SizeToContents()
		
		local PowerBotESPWeapons = vgui.Create( "DCheckBoxLabel", SheetItemTwo ) 
		PowerBotESPWeapons:SetPos( 15,45 )
		PowerBotESPWeapons:SetText( "Enable Weapon ESP" )
		PowerBotESPWeapons:SetConVar( "powerbot_config_ESP_Weapons" )
		PowerBotESPWeapons:SizeToContents()
 
 		local PowerBotESPWeapons = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPWeapons:SetPos( 15,60 )
		PowerBotESPWeapons:SetText( "Enable Ammo ESP" )
		PowerBotESPWeapons:SetConVar( "powerbot_config_ESP_Ammo" )
		PowerBotESPWeapons:SizeToContents()
		
 		local PowerBotESPSalesman = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPSalesman:SetPos( 15,75 )
		PowerBotESPSalesman:SetText( "Enable Salesman ESP" )
		PowerBotESPSalesman:SetConVar( "powerbot_config_ESP_Salesman" )
		PowerBotESPSalesman:SizeToContents()
		
 		local PowerBotESPGenerator = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPGenerator:SetPos( 15,90 )
		PowerBotESPGenerator:SetText( "Enable Generator ESP" )
		PowerBotESPGenerator:SetConVar( "powerbot_config_ESP_Generator" )
		PowerBotESPGenerator:SizeToContents()
		
 		local PowerBotESPShipment = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPShipment:SetPos( 15,105 )
		PowerBotESPShipment:SetText( "Enable Shipment ESP" )
		PowerBotESPShipment:SetConVar( "powerbot_config_ESP_Shipment" )
		PowerBotESPShipment:SizeToContents()
 
  		local PowerBotESPCash = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPCash:SetPos( 15,120 )
		PowerBotESPCash:SetText( "Enable Cash ESP" )
		PowerBotESPCash:SetConVar( "powerbot_config_ESP_Cash" )
		PowerBotESPCash:SizeToContents()
		
  		local PowerBotESPPlayer = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPPlayer:SetPos( 15,200 )
		PowerBotESPPlayer:SetText( "Enable Player ESP" )
		PowerBotESPPlayer:SetConVar( "powerbot_config_ESP_Player" )
		PowerBotESPPlayer:SizeToContents()
		
  		local PowerBotESPSkeleton = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPSkeleton:SetPos( 15,215 )
		PowerBotESPSkeleton:SetText( "Enable Player Skeletons" )
		PowerBotESPSkeleton:SetConVar( "powerbot_config_ESP_Player_Skeleton" )
		PowerBotESPSkeleton:SizeToContents()

  		local PowerBotESPCham = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPCham:SetPos( 15,230 )
		PowerBotESPCham:SetText( "Enable Player Cham" )
		PowerBotESPCham:SetConVar( "powerbot_config_ESP_Player_Cham" )
		PowerBotESPCham:SizeToContents()
		
  		local PowerBotESPBox = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPBox:SetPos( 15,245 )
		PowerBotESPBox:SetText( "Enable Player Box" )
		PowerBotESPBox:SetConVar( "powerbot_config_ESP_Player_Box" )
		PowerBotESPBox:SizeToContents()
		
		local PowerBotDistanceModifier = vgui.Create( "DNumSlider", SheetItemTwo )
		PowerBotDistanceModifier:SetPos( 15,260 )
		PowerBotDistanceModifier:SetSize( 250, 25 )
		PowerBotDistanceModifier:SetText( "Player Distance Modifier" )
		PowerBotDistanceModifier:SetMin( 256 )
		PowerBotDistanceModifier:SetMax( 10000 )
		PowerBotDistanceModifier:SetDecimals( 0 )
		PowerBotDistanceModifier:SetConVar( "powerbot_config_ESP_Player_Distance" )
		
		local PowerBotESPBox = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPBox:SetPos( 15,290 )
		PowerBotESPBox:SetText( "Enable Consumable ESP" )
		PowerBotESPBox:SetConVar( "powerbot_config_ESP_Holy_PowerBot" )
		PowerBotESPBox:SizeToContents()
		
  		local PowerBotESPLegacy = vgui.Create( "DCheckBoxLabel", SheetItemTwo )
		PowerBotESPLegacy:SetPos( 15,305 )
		PowerBotESPLegacy:SetText( "Enable Reusables ESP" )
		PowerBotESPLegacy:SetConVar( "powerbot_config_ESP_Legacy" )
		PowerBotESPLegacy:SizeToContents() 
 
		PropertySheet:AddSheet( "PowerBot Config", SheetItemOne, "gui/silkicons/user", false, false, "Configure General Settings for PowerBotVision" )
		PropertySheet:AddSheet( "PowerBot ESP", SheetItemTwo, "gui/silkicons/group", false, false, "Configure the ESP for PowerBotVision" )

end
concommand.Add("powerbotmenu", powerbotMenu)

function PowerBotDebug()
	
	if GetConVar("powerbot_screenshot"):GetInt() == 0 then
	
    draw.SimpleText("PowerBotVision Loaded", 'DefaultSmallDropShadow', 80, 50, Color(255, 150, 0, 255), 1, 1, 1)

	end
	

end
hook.Add("HUDPaint","Debug",PowerBotDebug)

function PowerBotGodmode()

    local dmg = ply:Health()
	local threshold = GetConVar("powerbot_config_threshold"):GetInt()
	
    if ConVarExists( "powerbot_config_godmode" ) and GetConVar("powerbot_config_godmode"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
   
        if dmg <= threshold then
           PowerBotPrintMessage("Warning, damage taken has fallen below threshold. Disconnecting.")
           RunConsoleCommand("disconnect");
        end
       
    else
    return nil;
    end
end
hook.Add("Think","SlothGodmode",PowerBotGodmode)


hook.Add( "HUDPaint", "PBWallhackCash", function()
 
if ConVarExists( "powerbot_config_ESP_Cash" ) and GetConVar("powerbot_config_ESP_Cash"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then

 
for k,v in pairs (ents.FindByClass("cw_cash")) do
if LocalPlayer():Alive() then
local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen()
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
draw.DrawText( "$Cash$", "DefaultSmallDropShadow", Position.x, Position.y, lgreen, 1 )
draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, lgreen, 1 )
else return nil;
end
end
end
end)

hook.Add( "HUDPaint", "PBWallhackShipment", function()

if ConVarExists( "powerbot_config_ESP_Shipment" ) and GetConVar("powerbot_config_ESP_Shipment"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then


for k,v in pairs (ents.FindByClass("cw_shipment")) do
if LocalPlayer():Alive() then
local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen()
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
draw.DrawText( v:GetClass( ), "DefaultSmallDropShadow", Position.x, Position.y, Color( 0, 255, 0, 255 ), 1 )
draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, Color( 0, 255, 0, 255 ), 1 )

else return nil;
end
end
end
end)

hook.Add( "HUDPaint", "PBWallhackGenerator", function()

if ConVarExists( "powerbot_config_ESP_Generator" ) and GetConVar("powerbot_config_ESP_Generator"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then


for k,v in pairs (ents.FindByClass("cw_generator")) do
if LocalPlayer():Alive() then
local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen()
local Dist = v:GetPos():Distance(LocalPlayer():GetPos());
draw.DrawText( v:GetClass( ), "DefaultSmallDropShadow", Position.x, Position.y, Color( 0, 0, 255, 255 ), 1 )
draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, Color( 0, 0, 255, 255 ), 1 )
else return nil;
end
end
end
end)

hook.Add( "HUDPaint", "PBWallhackSalesman", function()

if ConVarExists( "powerbot_config_ESP_Salesman" ) and GetConVar("powerbot_config_ESP_Salesman"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then

for k,v in pairs (ents.FindByClass("cw_salesman")) do
if LocalPlayer():Alive() then
local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen()
draw.DrawText( v:GetClass( ), "DefaultSmallDropShadow", Position.x, Position.y, Color( 255, 0, 0, 255 ), 1 )
else return nil;
end
end
end
end)

function IsCloseEnough(ent)
        local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
        if( dist <= GetConVarNumber("powerbot_config_ESP_Player_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
                return true
        end
        return false   
end

local mat = CreateMaterial("Cham_Texture","VertexLitGeneric",{ ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$translucent"] = 1, ["$alpha"] = 1, ["$nocull"] = 1, ["$ignorez"] = 1 } );

function Chams()
        if GetConVarNumber("powerbot_config_ESP_Player_Cham") == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
                for k,v in pairs(player.GetAll()) do
				
                    local TCol = team.GetColor(v:Team())
                    if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
					
                    cam.Start3D(EyePos(),EyeAngles())
                    render.SuppressEngineLighting( true )
                    render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
                    render.MaterialOverride( mat )
					
                    v:DrawModel()
					render.SuppressEngineLighting( false )
                    render.SetColorModulation(1,1,1)
                    render.MaterialOverride( )
                    v:DrawModel()
                    cam.End3D()
                    end
                end
        end
end
hook.Add( "RenderScreenspaceEffects", "Chams", Chams )

hook.Add( "HUDPaint", "PBPlayerESP", function()
 
 if ConVarExists( "powerbot_config_ESP_Player" ) and GetConVar("powerbot_config_ESP_Player"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
 
 	for k,e in pairs ( player.GetAll() ) do

		if ( e:IsPlayer() and e:Alive() and e != LocalPlayer() and IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
			if type(e:GetActiveWeapon()) == "Weapon" then
			if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
			local weapon = e:GetActiveWeapon():GetPrintName()
 
		local Position = ( e:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
		local Health = e:Health()
		local Name = e:Nick()
		
		if e:Health() >= 90 then HPColor = Color(0,255,0,255)
			elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
			elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
			elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
			elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
			elseif e:Health() >= 10 then HPColor = Color(255,52,0,255)
			else HPColor = Color(255,0,0,255)
		end
		
		
		draw.DrawText( Name, "DefaultSmallDropShadow", Position.x, Position.y, team.GetColor(e:Team()), 1 )
		draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, team.GetColor(e:Team()), 1 )
		draw.DrawText( "H: " .. math.floor(Health), "DefaultSmallDropShadow", Position.x, Position.y + 20, HPColor, 1 )
		draw.DrawText( "W: " ..weapon, "DefaultSmallDropShadow", Position.x, Position.y + 30, team.GetColor(e:Team()), 1 )
		if e:GetFriendStatus() == "friend" then
			draw.DrawText( "[FRIEND]", "DefaultSmallDropShadow", Position.x, Position.y + 40, Color(0, 255, 0, 255), 1 )
		end
		if e:IsAdmin() then
		
			draw.DrawText( "[ADMIN]", "DefaultSmallDropShadow", Position.x, Position.y + 50, Color(255, 0, 0, 255), 1 )
			
		elseif e:IsUserGroup("operator") then
		
			draw.DrawText( "[OPERATOR]", "DefaultSmallDropShadow", Position.x, Position.y + 50, Color(255, 0, 0, 255), 1 )]
		
		elseif e:IsUserGroup("superadmin") then

			draw.DrawText( "[SUPER ADMIN]", "DefaultSmallDropShadow", Position.x, Position.y + 50, Color(255, 0, 0, 255), 1 )
		
		end
		
local bones = {
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
                                                       
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
 
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
 
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
 
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}
    if GetConVarNumber("powerbot_config_ESP_Player_Skeleton") == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
        for k, v in pairs( bones ) do
            local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
                if e:IsPlayer() and !e:IsNPC() then
                        surface.SetDrawColor(team.GetColor(e:Team()))
                end
            surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
        end
			
	end
end
end
end
end
end
end
end)


hook.Add( "HUDPaint", "PBWallhackCW", function() 
for k,ent in pairs (ents.FindByClass("cw_item")) do
if LocalPlayer():Alive() and (Clockwork.entity:HasFetchedItemData(ent)) then

		local itemTable = ent:GetItemTable()
		local Position = ( ent:GetPos() + Vector( 0,0,0 ) ):ToScreen()
		local Dist = ent:GetPos():Distance(LocalPlayer():GetPos()); 
	
		if itemTable("category") == "Weapons" then
		
			if ConVarExists( "powerbot_config_ESP_Weapons" ) and GetConVar("powerbot_config_ESP_Weapons"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
		
				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, red, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, red, 1 )
				
			end
			
		elseif itemTable("category") == "Ammunition" then
		
			if ConVarExists( "powerbot_config_ESP_Ammo" ) and GetConVar("powerbot_config_ESP_Ammo"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
		
				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, yellow, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, yellow, 1 )
			end
			
		elseif itemTable("category") == "Medical" then
		
			if ConVarExists( "powerbot_config_ESP_Consumables" ) and GetConVar("powerbot_config_ESP_Consumables"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then
		
				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, green, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, green, 1 )
		
			end
		
		elseif itemTable("category") == "Consumables" then
		
			if ConVarExists( "powerbot_config_ESP_Holy_PowerBot" ) and GetConVar("powerbot_config_ESP_Holy_PowerBot"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then

				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, lgreen, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, lgreen, 1 )
				
			end
			
		elseif itemTable("category") == "Reusables" then
		
			if ConVarExists( "powerbot_config_ESP_Legacy" ) and GetConVar("powerbot_config_ESP_Legacy"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then

				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, lblue, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, lblue, 1 )
				
			end
			
		else
		
			if ConVarExists( "powerbot_config_ESP_Misc" ) and GetConVar("powerbot_config_ESP_Misc"):GetInt() == 1 and GetConVar("powerbot_screenshot"):GetInt() == 0 then 

				draw.DrawText( itemTable("name").." - "..itemTable("weight").."kg", "DefaultSmallDropShadow", Position.x, Position.y, grey, 1 )
				draw.DrawText( "D: " .. math.floor(Dist), "DefaultSmallDropShadow", Position.x, Position.y + 10, grey, 1 )
		
			end
		
		end

	end
end
end)

_G.render.Capture = function( data )


		RunConsoleCommand("powerbot_screenshot", "1");
		PowerBotPrintMessage("ESP has been hidden due to the screen being rendered. powerbot_screenshot 0 in console to disable.")


end