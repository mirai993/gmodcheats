--[[==================================================
%% CBaseAimbot: Syshack Edition
** Coded by ph0ne
** Credits:
	+ aVoN, Flapadar, fr1kin, noPE, RabidToaster, stgn
	+ http://wiki.garrysmod.com/
==================================================]]--

--[ INITIALIZATION ]--

if !CLIENT then return end
require( "ph0ne" )
require( "localcommand" )
print( ":: CBaseAimbot loading..." )

local C    = {}
C.commands = {}
C.cones    = {}
C.convars  = {}
C.hooks    = {}
C.set	   = {}
C.modules  = { "cbaseaimbot.lua", "gmcl_ph0ne.dll", "gmcl_localcommand.dll" }
C.world	   = { players = {}, entities = {} }

local Angle	 	= Angle
local Color		= Color
local EyeAngles = EyeAngles
local EyePos	= EyePos
local pairs		= pairs
local print		= print
local tonumber  = tonumber
local type 		= type
local Vector 	= Vector

function C.getallents()
	C.world.players = {}; C.world.entities = {}
	for k, e in pairs( ents.GetAll() ) do
		if ValidEntity( e ) then
			if e:IsPlayer( e ) then
				table.insert( C.world.players, e )
			else
				table.insert( C.world.entities, e )
			end
		end
	end
end

--[ FUNCTION/TABLE COPYING ]--

local oACC  = AddConsoleCommand
local oCCCV = CreateClientConVar
local oCVE  = ConVarExists
local oECC  = engineConsoleCommand
local oGCV  = GetConVar
local oGCVN = GetConVarNumber
local oGCVS = GetConVarString
local oCM	= CreateMaterial
local oSMO  = SetMaterialOverride

local oC = table.Copy( cvars )
local oD = table.Copy( debug )
local oF = table.Copy( file )
local oH = table.Copy( hook )

local AngM = table.Copy( _R["Angle"] || {} )
local ConM = table.Copy( _R["ConVar"] || {} )
local CmdM = table.Copy( _R["CUserCmd"] || {} )
local EntM = table.Copy( _R["Entity"] || {} )
local PlyM = table.Copy( _R["Player"] || {} )
local VecM = table.Copy( _R["Vector"] || {} )

--[ HOOKING & CONCOMMANDS ]--

function hook.Call( name, gm, ... )
	for k, v in pairs( C.hooks ) do
		if ( v.name == name ) then
			if ( ... == nil ) then ret = v.func() else ret = v.func( ... ) end
			if ( ret != nil ) then return ret end
		end
	end
	return oH.Call( name, gm, ... )
end
function C:addhook( name, id, func ) C.hooks[id] = { name = name, func = func } end

function engineConsoleCommand( p, c, a )
	local s = string.lower( c )
	if C.commands[s] then C.commands[s]( p, c, a ); return true end
	return oECC( p, c, a )
end
function C:addcommand( name, func ) C.commands[name] = func; oACC( name ) end

--[ VARS ]--

C.OSV 		  = 0
C.aimlocked   = false
C.pkfake 	  = false
C.pkthrow 	  = false
C.firing 	  = false
C.found 	  = false
C.aimingang   = Angle( 0, 0, 0 )
C.fakeang 	  = Angle( 0, 0, 0 )
C.nospreadang = Angle( 0, 0, 0 )
C.pkfakeang   = Angle( 0, 0, 0 )
C.pkthrowang  = Angle( 0, 0, 0 )
C.recoilang   = Angle( 0, 0, 0 )
C.LC		  = LocalCommand
C.path 	 	  = "lua\\autorun\\client\\cbaseaimbot.lua"
C.prefix	  = "ph0ne_"

--[ ANTI-DETECTION ]--

function C:tablesetkeys( table )
	local count, ret = 0, {}
	for k, v in pairs( table ) do count = count + 1; ret[count] = v end
	return ret
end

function cvars.AddChangeCallback( cvar, callback )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oC.AddChangeCallback( cvar ) end
	for k, v in pairs( C.convars ) do
		if string.find( string.lower( v ), cvar ) then
			print( ":: cvars.AddChangeCallback: " .. cvar ); return
		end
	end
	if ( cvar == "host_framerate" ) then return 0 end
	return oC.AddChangeCallback( cvar, callback )
end

function GetConVar( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oGCV( cvar ) end
	for k, v in pairs( C.convars ) do
		if string.find( string.lower( cvar ), v ) then
			print( ":: GetConVar: " .. cvar ); return
		end
	end
	return oGCV( cvar )
end

function ConVarExists( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oCVE( cvar ) end
	for k, v in pairs( C.convars ) do
		if string.find( string.lower( cvar ), v ) then
			print( ":: ConVarExists: " .. cvar ); return
		end
	end
	return oCVE( cvar )
end

function GetConVarNumber( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oGCVN( cvar ) end
	for k, v in pairs( C.convars ) do
		if string.find( string.lower( cvar ), v ) then
			print( ":: GetConVarNumber: " .. cvar ); return
		end
	end
	if ( cvar == "host_framerate" ) then return 0 end
	return oGCVN( cvar )
end

function GetConVarString( cvar )
	local callpath = debug.getinfo(2)['short_src']
	print( callpath, callpath == C.path && "true" || "false" )
	if ( callpath && callpath == C.path ) then return oGCVS( cvar ) end
	for k, v in pairs( C.convars ) do
		if string.find( string.lower( cvar ), v ) then
			print( ":: GetConVarString: " .. cvar ); return
		end
	end
	if ( cvar == "host_framerate" ) then return "0" end
	return oGCVS( cvar )
end

function _R.ConVar.GetInt( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return ConM.GetInt( cvar ) end
	for k, v in pairs( C.convars ) do
		if ( string.find( string.lower( cvar:GetName() ), v ) ) then
			print( ":: _R.ConVar.GetInt: " .. cvar ); return
		end
	end
	if ( cvar:GetName() == "host_framerate" ) then return 0 end
	return ConM.GetInt( cvar )
end

function _R.ConVar.GetBool( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return ConM.GetBool( cvar ) end
	for k, v in pairs( C.convars ) do
		if ( string.find( string.lower( cvar:GetName() ), v ) ) then
			print( ":: _R.ConVar.GetBool: " .. cvar ); return
		end
	end
	if ( cvar:GetName() == "host_framerate" ) then return false end
	return ConM.GetBool( cvar )
end

function file.Read( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.Read( path, bool ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Read: " .. path ); return nil
		end
	end
	return oF.Read( path, bool )
end

function file.Exists( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.Exists( path, bool ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Exists: " .. path ); return nil
		end
	end
	return oF.Exists( path, bool )
end

function file.ExistsEx( path , addons )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.ExistsEx( path, addons ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.ExistsEx: " .. path ); return nil
		end
	end
	return oF.ExistsEx( path, addons )
end

function file.Write( path, cont, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.Write( path, cont, ... ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Write: " .. path ); return nil
		end
	end
	return oF.Write( path, cont, ... )
end

function file.Time( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.Time( path ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Time: " .. path ); return 0
		end
	end
	return oF.Time( path )
end

function file.Size( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oF.Size( path ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Size: " .. path ); return -1
		end
	end
	return oF.Size( path )
end

function file.Find( path, bool )
	local callpath, o = debug.getinfo(2)['short_src'], oF.Find( path, bool )
	if callpath && ( callpath == C.path ) then return oF.Find( path, bool ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.Find: " .. path ); table.remove( o, k )
		end
	end
	return oF.Find( path, bool )
end

function file.FindInLua( path, bool )
	local callpath, o = debug.getinfo(2)['short_src'], oF.FindInLua( path, bool )
	if callpath && ( callpath == C.path ) then return oF.FindInLua( path, bool ) end
	for k, v in pairs( C.modules ) do
		if string.find( string.lower( path ), v ) then
			print( ":: file.FindInLua: " .. path ); table.remove( o, k )
		end
	end
	return oF.FindInLua( path, bool )
end

function file.TFind( path, callback )	
	local callpath = debug.getinfo(2)['short_src']
	if callpath then
		return oF.TFind( path, function( path, folders, files )
			for k, v in pairs( files ) do
				if string.find( string.lower( v ) , "cbaseaimbot" ) then
					print( ":: file.TFind: " .. path ); files[k] = nil
				end
			end
			return callback( path, folders, C:tablesetkeys( files ) )
		end )
	end
	return oF.TFind( path, function( path, folders, files )
		return callback( path, folders, files )
	end )
end

/*
function debug.getinfo( thread, func )
	local callpath = debug.getinfo(2)['short_src']
	if callpath && ( callpath == C.path ) then return oD.getinfo( thread, func ) end
	print( ":: debug.getinfo attempted." )
	return {}
end
*/

--[ CONVARS ]--

function C:CreateConVar( cvar, val, name )
	local convar = oCCCV( C.prefix .. cvar, val, true, false )
	if ( type( val ) == "number" ) then C.set[name] = ConM.GetInt( convar ) end
	table.insert( C.convars, C.prefix .. cvar )
	oC.AddChangeCallback( C.prefix .. cvar, function( cvar, old, new ) C.set[name] = new end )
	return convar
end

C:CreateConVar( "aim", 0, "aim" )
C:CreateConVar( "aim_silent", 0, "aimsilent" )
C:CreateConVar( "aim_team", 1, "aimteam" )
C:CreateConVar( "aim_ignoreadmins", 1, "ignoreadmins" )
C:CreateConVar( "aim_ignorefriendlytraitors", 1, "ignoretraitors" )
C:CreateConVar( "aim_ignorefriends", 1, "ignorefriends" )
C:CreateConVar( "aim_snaponfire", 0, "snaponfire" )
C:CreateConVar( "aim_autoshoot", 0, "autoshoot" )
C:CreateConVar( "aim_ignorevisibility", 0, "ignorevisibility" )
C:CreateConVar( "aim_nospread", 1, "nospread" )
C:CreateConVar( "aim_comp", 1, "velocitycomp" )
C:CreateConVar( "aim_comp_val", 66, "compval" )
C:CreateConVar( "aim_fov", 180, "aimfov" )
C:CreateConVar( "aim_offset", 0, "aimoffset" )
C:CreateConVar( "esp", 1, "esp" )
C:CreateConVar( "esp_info", 1, "infoesp" )
C:CreateConVar( "esp_target", 1, "drawtarget" )
C:CreateConVar( "esp_adminlist", 1, "adminlist" )
C:CreateConVar( "esp_rpents", 0, "rpesp" )
C:CreateConVar( "esp_traitorweps", 1, "traitorwepesp" )
C:CreateConVar( "esp_chams", 1, "chams" )
C:CreateConVar( "esp_chams_type", 1, "chamstype" )
C:CreateConVar( "bhop", 1, "bhop" )
C:CreateConVar( "crosshair", 1, "crosshair" )
C:CreateConVar( "namesteal_auto", 0, "namestealconstant" )
C:CreateConVar( "novisualrecoil", 1, "novisrecoil" )
C:CreateConVar( "ungag", 0, "ungag" )

function C:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

--[ UTIL FUNCTIONS ]--

function C:admin( e )
	if e:IsAdmin() then return true end
	return false
end

function C:friend( e )
	if ( PlyM.GetFriendStatus( e ) == "friend" ) then return true end
	return false
end

function C:traitor( e )
	local ply = LocalPlayer()
	if !string.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	if ply:IsTraitor() && e:IsTraitor() then return true end
	return false
end

function C:onscreen( e )
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	for k, v in pairs( positions ) do
		local pos = VecM.ToScreen( EntM.LocalToWorld( e, _R.Entity[v]( e ) ) )
		if ( pos.x > 0 ) && ( pos.y > 0 ) && ( pos.x < x ) && ( pos.y < y ) then return true end
	end
	return false
end

--[ NAME CHANGING ]--

function C.stealnames()
	local ply, e = LocalPlayer(), player.GetAll()
	local randname = e[ math.random( 1, #e ) ]
	if C:G( C.set.namestealconstant, 1 ) then
		if ply && ( randname != ply ) && ( PlyM.Nick( randname ) != PlyM.Nick( ply ) ) then
			C.LC( "name " .. PlyM.Nick( randname ) .. "~ ~~" )
		end
	end
end

function C.stealname()
	local ply, e = LocalPlayer(), player.GetAll()
	local randname = e[ math.random( 1, #e ) ]
	if ply && ( randname != ply ) && ( PlyM.Nick( randname ) != PlyM.Nick( ply ) ) then
		C.LC( "name " .. PlyM.Nick( randname ) .. "~ ~~" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "Your name is now ",
			Color( 255, 0, 0 ), PlyM.Nick( randname ),
			Color( 255, 255, 255 ), "."
		)
	end
end
C:addcommand( "ph0ne_namesteal", C.stealname )

function C.antimute()
	local ply = LocalPlayer()
	if ply then
		C.LC( "name �" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "You are now ",
			Color( 255, 0, 0 ), "nameless",
			Color( 255, 255, 255 ), "."
		)
	end
end
C:addcommand( "ph0ne_antimute", C.antimute )

--[ ULX UNGAG ]--

function C.ungag()
	local ply = LocalPlayer()
	if ply && C:G( C.set.ungag, 1 ) then
		if ulx && ulx.gagUser then
			ulx.gagUser( false )
			oH.Remove( "PlayerBindPress", "ULXGagForce" )
			timer.Destroy( "GagLocalPlayer" )
		end
		if evolve then EntM.SetNWBool( ply, "Muted", false ) end
	end
end

--[ NOSPREAD ]--

function C:weaponvector( value, typ, vec )
	if !vec then return tonumber( value ) end; local s = tonumber( -value )
	if typ then s = tonumber( -value ) else s = tonumber( value ) end
	return Vector( s, s, s )
end

C.cones["weapon_pistol"]  		= C:weaponvector( 0.0100, true, false )
C.cones["weapon_smg1"]    		= C:weaponvector( 0.04362, true, false )
C.cones["weapon_ar2"]     		= C:weaponvector( 0.02618, true, false )
C.cones["weapon_shotgun"] 		= C:weaponvector( 0.08716, true, false )
C.cones["weapon_zs_zombie"]		= C:weaponvector( 0.0100, true, false )
C.cones["weapon_zs_fastzombie"] = C:weaponvector( 0.04362, true, false )

function C.predictspread( ucmd, angle )
	local ply, cone, ang = LocalPlayer(), 0, AngM.Forward( angle ) || VecM.Angle( PlyM.GetAimVector( ply ) )
	local wep = PlyM.GetActiveWeapon( ply )
	if C:G( C.set.aim, 1 ) && PlyM.Alive( ply ) && wep && EntM.IsValid( wep ) then
		if ( type( wep.Initialize ) == "function" ) then
			cone = wep.Primary && wep.Primary.Cone || 0
			if ( type( cone ) == "number" ) then
				cone = C:weaponvector( cone, true, false )
			elseif ( type( cone ) == "Vector" ) then
				cone = cone * -1
			end
		else
			local c = EntM.GetClass( wep ); if C.cones[c] then cone = C.cones[c] end
		end
	end
	local conevec = Vector( -cone, -cone, -cone ) || 0
	return VecM.Angle( hack.CompensateWeaponSpread( ucmd, conevec, ang ) )
end

--[ AIMBOT ]--

function C.toggleaimbot()
	if C:G( C.set.aim, 0 ) then
		C.LC( "ph0ne_aim 1" )
	elseif C:G( C.set.aim, 1 ) then
		C.LC( "ph0ne_aim 0" ); C.found = false
	end
end
C:addcommand( "ph0ne_aim_toggle", C.toggleaimbot )

function C.ontoggled()
	local ply = LocalPlayer()
	if C:G( C.set.aimsilent, 1 ) then C.fakeang = EntM.EyeAngles( ply ) end
end
C:addhook( "OnToggled", "\0\1", C.ontoggled )

function C.aimspot( e )
	local eyes, bone = EntM.LookupAttachment( e, "eyes" ), "ValveBiped.Bip01_Head1"
	if ( eyes != 0 ) then
		eyes = EntM.GetAttachment( e, eyes ); if eyes && eyes.Pos then return eyes.Pos, eyes.Ang end
	end
	if EntM.LookupBone( e, bone ) then
		bone = EntM.GetBonePosition( e, bone ); if bone then return bone end
	end
	return EntM.LocalToWorld( e, EntM.OBBCenter( e ) )
end

function C:visible( e )
	local ply = LocalPlayer()
	if C:G( C.set.ignorevisibility, 1 ) then return true end
	local trace = util.TraceLine( {
		start = PlyM.GetShootPos( ply ),
		endpos = C.aimspot( e ),
		filter = { ply, e },
		mask = MASK_SHOT
	} )
	if ( trace.Fraction == 1 ) then return true end
	return false
end

function C:aimvalid( e )
	local ply = LocalPlayer()
	if PlyM.IsPlayer( e ) then
		if ( ply == e ) then return false end
		if !EntM.IsValid( e ) then return false end
		if !PlyM.Alive( e ) then return false end
		if ( PlyM.Team( e ) == PlyM.Team( ply ) ) && C:G( C.set.aimteam, 0 )then return false end
		if ( EntM.GetMoveType( e ) == MOVETYPE_NONE ) then return false end
		if ( EntM.GetMoveType( e ) == MOVETYPE_OBSERVER ) then return false end
		if string.find( string.lower( team.GetName( PlyM.Team( e ) ) ), "spec" ) then return false end
		if C:admin( e ) && C:G( C.set.ignoreadmins, 1 ) then return false end
		if C:traitor( e ) && C:G( C.set.ignoretraitors, 1 ) then return false end
		if C:friend( e ) && C:G( C.set.ignorefriends, 1 ) then return false end
	end
	return true
end

function C.aimtarget() 
	local ply, tar, d = LocalPlayer(), false 
	if C:G( C.set.aim, 1 ) then
		for k, e in pairs( C.world.players ) do
			if C:aimvalid( e ) && C:visible( e ) then
				local a = AngM.Forward( EntM.GetAngles( ply ) )
				local b = VecM.GetNormal( C.aimspot( e ) - PlyM.GetShootPos( ply ) )
				d = math.deg( math.acos( VecM.Dot( a, b ) ) )
				if ( d < tonumber( C.set.aimfov ) ) then
					if !tar || ( tar.dist > d ) then
						tar = { e = e, pos = C.aimspot( e ), dist = d }
					end
				end
			end
		end
	end
	return tar
end

function C.aimbot( ucmd )
	local ply, tar, vc, comp = LocalPlayer(), C.aimtarget(), tonumber( C.set.compval )
	if C:G( C.set.novisrecoil, 1 ) then C.recoilang = CmdM.GetViewAngles( ucmd ) end
	C.fakeang.p = math.Clamp( C.fakeang.p + ( CmdM.GetMouseY( ucmd ) * 0.022 ), -89, 90 )
	C.fakeang.y = math.NormalizeAngle( C.fakeang.y + ( CmdM.GetMouseX( ucmd ) * -0.022 ) )
	if C:G( C.set.aimsilent, 1 ) then CmdM.SetViewAngles( ucmd, C.fakeang ) end
	if C:G( C.set.aim, 1 ) && PlyM.Alive( ply ) && tar then
		local ang = C.fakeang; C.found = true
		tar.pos = tar.pos + Vector( 0, 0, tonumber( C.set.aimoffset ) )
		if C:G( C.set.velocitycomp, 1 ) then
			comp = 1 / vc
			tar.pos = tar.pos + ( EntM.GetVelocity( tar.e ) * comp - EntM.GetVelocity( ply ) * comp )
		end
		ang = VecM.Angle( tar.pos - PlyM.GetShootPos( ply ) ); C.aimingang = ang
		if C:G( C.set.nospread, 1 ) then ang = C.predictspread( ucmd, ang ) end
		ang.p, ang.y, ang.r = math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0
		if C:G( C.set.snaponfire, 1 ) then
			if CmdM.KeyDown( ucmd, IN_ATTACK ) then
				CmdM.SetViewAngles( ucmd, ang ); C.aimlocked = true
			else
				C.aimlocked = false
			end
		else
			CmdM.SetViewAngles( ucmd, ang ); C.aimlocked = true
		end
		if C:G( C.set.aimsilent, 1 ) && C.aimlocked then
			local move = Vector( CmdM.GetForwardMove( ucmd ), CmdM.GetSideMove( ucmd ), 0 )
			local norm = VecM.GetNormal( move )
			local set = AngM.Forward( VecM.Angle( norm ) + ( ang - C.fakeang ) ) * VecM.Length( move )
			CmdM.SetForwardMove( ucmd, set.x ); CmdM.SetSideMove( ucmd, set.y )
		end
	else
		C.aimlocked = false; C.found = false
	end
end

--[ AUTOSHOOT ]--

function C.autoshoot( ucmd )
	local ply = LocalPlayer()
	local wep = PlyM.GetActiveWeapon( ply )
	if C:G( C.set.aim, 1 ) && C:G( C.set.autoshoot, 1 ) then
		if C.found && C.aimlocked && !C.firing then
			C.LC( "+attack" ); C.firing = true
			timer.Simple( ( wep.Primary && wep.Primary.Delay ) || 0.05, function()
				C.LC( "-attack" ); C.firing = false
			end )
		end
	end
end

--[ PROPKILLING ]--

function C.pkillon()
	if !string.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	if C:G( C.set.aimsilent, 1 ) then C.OSV = 1 else C.OSV = 0 end
	C.LC( "ph0ne_aim_silent 0" ); C.pkfake = true
end
C:addcommand( "+ph0ne_pk", C.pkillon )

function C.pkilloff()
	if !string.find( GAMEMODE.Name, "Trouble in Terror" ) then return end
	C.pkfake = false; C.pkthrow = true
	if C:G( C.set.aimsilent, 0 ) then
		if ( C.OSV == 1 ) then C.LC( "ph0ne_aim_silent 1" ) else C.LC( "ph0ne_aim_silent 0" ) end
	end
end
C:addcommand( "-ph0ne_pk", C.pkilloff )

function C.propkill( ucmd )
	if string.find( GAMEMODE.Name, "Trouble in Terror" ) then
		if C.pkfake && !C.pkthrow then
			C.pkthrowang = CmdM.GetViewAngles( ucmd )
			C.pkfakeang = C.pkthrowang - Angle( 0, 180, 0 )
		elseif !C.pkfake && C.pkthrow then
			C.pkthrow = false; CmdM.SetViewAngles( ucmd, C.pkfakeang )
			if C:G( C.set.aimsilent, 1 ) then C.fakeang = C.pkfakeang; CmdM.SetViewAngles( ucmd, C.fakeang ) end
		else
			C.pkthrowang = CmdM.GetViewAngles( ucmd ); C.pkfakeang = C.pkthrowang
		end
	end
end

function C.propkillstrafecorrection( ucmd )
	if C.pkfake && !C.pkthrow then
		local ang; if C:G( C.set.aimsilent, 1 ) then ang = C.fakeang else ang = C.recoilang end
		local move = Vector( CmdM.GetForwardMove( ucmd ), CmdM.GetSideMove( ucmd ), 0 )
		local norm = VecM.GetNormal( move )
		local set = AngM.Forward( VecM.Angle( norm ) + ( C.pkfakeang - ang ) ) * VecM.Length( move )
		CmdM.SetForwardMove( ucmd, set.x )
		CmdM.SetSideMove( ucmd, set.y )
	end
end

--[ BUNNYHOPPING ]--
	
function C.bhop( ucmd )	
	local ply, buttons = LocalPlayer(), CmdM.GetButtons( ucmd )
	if C:G( C.set.bhop, 1 ) then
		if ply && CmdM.KeyDown( ucmd, IN_JUMP ) then
			if EntM.IsOnGround( ply ) && ( EntM.GetMoveType( ply ) != MOVETYPE_LADDER ) then
				CmdM.SetButtons( ucmd, buttons | IN_JUMP )
			else
				CmdM.SetButtons( ucmd, buttons - IN_JUMP )
			end
		end
	end
end

--[ CALCVIEW ]--

function C.calcview( ply, origin, angles )
	local ply, view = LocalPlayer(), {}; view.origin = origin
	local wep = PlyM.GetActiveWeapon( ply )
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	if C.pkfake && string.find( GAMEMODE.Name, "Trouble in Terror" ) then
		view.angles = C.pkfakeang
	elseif C.aimlocked && C:G( C.set.aimsilent, 0 ) then
		view.angles = C.aimingang
	elseif C:G( C.set.aimsilent, 1 ) then
		view.angles = C.fakeang
	elseif C:G( C.set.aimsilent, 1 ) && C:G( C.set.novisrecoil, 1 ) then
		view.angles = C.fakeang
	elseif C:G( C.set.novisrecoil, 1 ) && C:G( C.set.aimsilent, 0 ) then
		view.angles = C.recoilang
	else
		view = GAMEMODE:CalcView( ply, origin, angles )
	end
	return view
end
C:addhook( "CalcView", "\1\2", C.calcview )

--[ ESP ]--

function C:espvalid( e )
	local ply = LocalPlayer()
	if PlyM.IsPlayer( e ) then
		if !EntM.IsValid( e ) then return false end
		if !PlyM.Alive( e ) then return false end
		if ( ply == e ) then return false end
		if ( EntM.GetMoveType( e ) == MOVETYPE_NONE ) then return false end
		if ( EntM.GetMoveType( e ) == MOVETYPE_OBSERVER ) then return false end
		if string.find( string.lower( team.GetName( PlyM.Team( e ) ) ), "spec" ) then return false end
		if !C:onscreen( e ) then return false end
	end
	return true
end

function C:colorstatus( e )
	local statuscol
	if C:friend( e ) then
		statuscol = Color( 20, 255, 0, 255 )
	elseif C:admin( e ) then
		statuscol = Color( 215, 255, 0, 255 )
	elseif C:traitor( e ) && string.find( GAMEMODE.Name, "Trouble in Terror" ) then
		statuscol = Color( 255, 55, 20, 155 )
	else
		statuscol = Color( 255, 255, 255, 255 )
	end
	return statuscol
end

function C.playeresp()
	local ply, tc, tl, tr, healthcol, c = LocalPlayer(), TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT
	local white, black, red = Color( 255, 255, 255, 255 ), Color( 0, 0, 0, 255 ), Color( 255, 105, 105, 255 )
	if C:G( C.set.esp, 1 ) && C:G( C.set.infoesp, 1 ) then
		for k, e in pairs( C.world.players ) do
			if C:espvalid( e ) then
				local pos, opos = VecM.ToScreen( C.aimspot( e ) + Vector( 0, 0, 12 ) ), VecM.ToScreen( C.aimspot( e ) )
				local scol, health = C:colorstatus( e ), EntM.Health( e )
				if ( health < 101 ) then c = health * 2.55 else c = 255 end; healthcol = Color( 255, c, c, 255 )
				surface.SetDrawColor( scol )
				surface.DrawLine( opos.x, opos.y, pos.x + 7, pos.y - 3.5 )
				surface.DrawLine( pos.x + 7, pos.y - 3.5, pos.x + 26.5, pos.y - 3.5 )
				draw.SimpleTextOutlined( PlyM.Nick( e ), "DefaultBold", pos.x + 10, pos.y - 12, white, tl, tc, 1, black )
				draw.SimpleTextOutlined( health, "Default", pos.x + 26.5, pos.y + 4.5, healthcol, tr, tc, 1, black )
			end
		end
	end
end

function C.adminlist()
	local admins, w, h, space, tc, tl = {}, ScrW(), ScrH(), 0, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT
	local ax, ayh, aya = ( w - ( w - 20 ) ), ( ( h - h ) + 301 ), ( ( h - h ) + 315 )
	local white, black, red = Color( 255, 255, 255, 255 ), Color( 0, 0, 0, 255 ), Color( 255, 105, 105, 255 )
	if C:G( C.set.adminlist, 1 ) then
		draw.SimpleTextOutlined( "ADMINS:", "DefaultBold", ax, ayh, red, tl, tc, 1, black )
		for k, e in pairs( C.world.players ) do
			if ValidEntity( e ) and C:admin( e ) then table.insert( admins, PlyM.Nick( e ) ) end
		end
		for _, v in pairs( admins ) do
			draw.SimpleTextOutlined( v, "DefaultBold", ax, aya + space, white, tl, tc, 1, black )
			space = space + 15
		end
	end
end

C.rpents = {
	money_printer = "printer",
	gunlab 	      = "gunlab",
	drug_lab      = "drug_lab",
	spawned_money = "money",
	dispenser     = "dispenser",
	gunvault      = "gunvault",
	drugfactory   = "drugfactory",
	gunfactory    = "gunfactory",
	microwave     = "microwave",
	powerplant    = "powerplant",
}

C.traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_decoy",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport"
}

function C.entityesp()
	local ply, tc = LocalPlayer(), TEXT_ALIGN_CENTER
	local yellow, black, red = Color( 255, 255, 0, 255 ), Color( 0, 0, 0, 255 ), Color( 255, 0, 0, 255 )
	if C:G( C.set.esp, 1 ) then
		if C:G( C.set.rpesp, 1 ) then
			for _, e in pairs( C.world.entities ) do
				for k, t in pairs ( C.rpents ) do
					if ValidEntity( e ) and ( EntM.GetClass( e ) == k ) then
						local pos = VecM.ToScreen( EntM.GetPos( e ) )
						draw.SimpleTextOutlined( t, "DefaultSmall", pos.x, pos.y, yellow, tc, tc, 1, black )
					end
				end
			end
		end
		if C:G( C.set.traitorwepesp, 1 ) && string.find( GAMEMODE.Name, "Trouble in Terror" ) then
			for _, e in pairs( C.traitorweapons ) do
				for k, t in pairs( ents.FindByClass( e ) ) do
					local pos, size = VecM.ToScreen( EntM.GetPos( t ) ), 6; local c = size / 2
					draw.RoundedBox( 0, pos.x - c, pos.y - c, size, size, red )
				end
			end
		end
	end
end

--[ CROSSHAIR ]--

function C.crosshair()
	if C:G( C.set.crosshair, 1 ) then
		local w, h, length = ScrW() / 2, ScrH() / 2, 5
		if C:G( C.set.aim, 1 ) then
			surface.SetDrawColor( 255, 0, 0, 255 )
		else
			surface.SetDrawColor( 255, 255, 0, 255 )
		end
		surface.DrawLine( w - length, h, w, h )
   		surface.DrawLine( w + length, h, w, h )
		surface.DrawLine( w, h - length, w, h )
		surface.DrawLine( w, h + length, w, h )
		if C.found && !C.aimlocked then
			surface.SetDrawColor( 255, 255, 0 , 255 )
			surface.DrawOutlinedRect(
				( w - length ) - 2,
				( h - length ) - 2,
				( ( length + 2 ) * 2 ) + 1,
				( ( length + 2 ) * 2 ) + 1
			)
		elseif C.aimlocked && C.found then
			surface.SetDrawColor( 255, 0, 0 , 255 )
			surface.DrawOutlinedRect(
				( w - length ) - 2,
				( h - length ) - 2,
				( ( length + 2 ) * 2 ) + 1,
				( ( length + 2 ) * 2 ) + 1
			)
		end
	end
end

--[ CHAMS ]--

function C:chamsmat()
	local info, mat = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	if C:G( C.set.chamstype, 1 ) then
		mat = oCM( "solid", "UnlitGeneric", info )
	elseif C:G( C.set.chamstype, 2 ) then
		mat = oCM( "wire", "Wireframe", info )
	end
	return mat
end

function C.chams()
	if C:G( C.set.esp, 1 ) && C:G( C.set.chams, 1 ) then
		for k, e in pairs( C.world.players ) do
			if C:espvalid( e ) then
				cam.Start3D( EyePos(), EyeAngles() )
					local col, mat, c = team.GetColor( PlyM.Team( e ) ), C:chamsmat(), ( 1 / 255 )
					render.SuppressEngineLighting( true )
						oSMO( mat ); render.SetColorModulation( ( col.r * c ), ( col.g * c ), ( col.b * c ) )
						if C:G( C.set.chamstype, 2 ) then render.SetBlend( 1 ) else render.SetBlend( 0.85 ) end
						EntM.DrawModel( e )
						oSMO(); render.SetColorModulation( 1, 1, 1 ); render.SetBlend( 1 )
						EntM.DrawModel( e )
					render.SuppressEngineLighting( false )
				cam.End3D()
			end
		end
	end
end
C:addhook( "RenderScreenspaceEffects", "\2\3", C.chams )

--[ HOOKING GROUPS OF FUNCTIONS ]--

function C.createmove( ucmd )
	C.aimbot( ucmd )
	C.autoshoot( ucmd )
	C.bhop( ucmd )
	C.propkill( ucmd )
	C.propkillstrafecorrection( ucmd )
end
C:addhook( "CreateMove", "\3\4", C.createmove )

function C.hudpaint()
	C.playeresp()
	C.adminlist()
	C.entityesp()
	C.crosshair()
end
C:addhook( "HUDPaint", "\4\5", C.hudpaint )

function C.think()
	C.getallents()
	C.stealnames()
	C.ungag()
end
C:addhook( "Think", "\5\6", C.think )

--[ MENU ]--

function C:createoption( dtype, parent, o1, o2, o3, o4, o5, o6, o7 ) -- Using Seth's wrapper.
	local addx, addy = 3, 3.5
	if ( dtype == "Checkbox" ) then
		dtype = "DCheckBoxLabel"
		local text, cvar, x, y = o1, o2, o3, o4
		local checkbox = vgui.Create( dtype, parent )
		checkbox:SetText( text )
		checkbox:SetPos( x + addx, y + addy )
		checkbox:SetConVar( C.prefix .. cvar )
		checkbox:SetValue( GetConVarNumber( C.prefix .. cvar ) )
		checkbox:SizeToContents()
	elseif ( dtype == "Slider" ) then
		dtype = "DNumSlider"
		local text, cvar, min, max, wide, x, y = o1, o2, o3, o4, o5, o6, o7
		local slider = vgui.Create( dtype, parent )
		slider:SetPos( x + addx, y + addy )
		slider:SetWide( wide )
		slider:SetText( text )
		slider:SetMin( min )
		slider:SetMax( max )
		slider:SetDecimals( 0 )
		slider:SetConVar( C.prefix .. cvar )
	elseif ( dtype == "Button" ) then
		dtype = "DButton"
		local text, command, x, y = o1, o2, o3, o4
		local button = vgui.Create( dtype, parent )
		button:SetParent( parent )
		button:SetSize( 125, 25 )
		button:SetPos( x + addx, y + addy )
		button:SetText( text )
		button.DoClick = function() C.LC( C.prefix .. command ) end
	elseif ( dtype == "Label" ) then
		dtype = "DLabel"
		local text, x, y = o1, o2, o3
		local label = vgui.Create( dtype, parent )
		label:SetPos( x, y )
		label:SetText( text )
		label:SizeToContents()
		label:SetTextColor( color_white )
	end
end

function C.menu()
	local tabs, menuheight, menuwidth, w, h = {}, 225, 320, ScrW() / 2, ScrH() / 2
	local c1, c2 = Color( 0, 0, 0, 75 ), Color( 0, 0, 0, 155 )
	C.frame = vgui.Create( "DPropertySheet" )
	C.frame:SetParent( C.frame )
	C.frame:SetPos( w - ( menuwidth / 2 ), h - ( menuheight / 2 ) )
	C.frame:SetSize( menuwidth, menuheight )
	C.frame:SetVisible( true )
	C.frame:MakePopup()
	C.frame.Paint = function() draw.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c1 ) end
	C:createoption( "Label", C.frame, "CBaseAimbot", 250, 6.5 )
	tabs.aimbot = vgui.Create( "DLabel", C.frame )
	tabs.aimbot:SetPos( 0, 0 )
	tabs.aimbot:SetText( "" )
	tabs.aimbot.Paint = function() draw.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "Aimbot", tabs.aimbot, nil, false, false )
	tabs.esp = vgui.Create( "DLabel", C.frame )
	tabs.esp:SetPos( 0, 0 )
	tabs.esp:SetText( "" )
	tabs.esp.Paint = function() draw.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "ESP", tabs.esp, nil, false, false )
	tabs.misc = vgui.Create( "DLabel", C.frame )
	tabs.misc:SetPos( 0, 0 )
	tabs.misc:SetText( "" )
	tabs.misc.Paint = function() draw.RoundedBox( 1, 0, 0, C.frame:GetWide(), C.frame:GetTall(), c2 ) end
	C.frame:AddSheet( "Misc", tabs.misc, nil, false, false )
	C:createoption( "Checkbox", tabs.aimbot, "Aimbot Enabled", "aim", 5, 5 )
	C:createoption( "Checkbox", tabs.aimbot, "No View Change", "aim_silent", 5, 25 )
	C:createoption( "Checkbox", tabs.aimbot, "Aim at Teammates", "aim_team", 5, 45 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Admins", "aim_ignoreadmins", 5, 65 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Friendly Traitors", "aim_ignorefriendlytraitors", 5, 85 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Steam Friends", "aim_ignorefriends", 5, 105 )
	C:createoption( "Checkbox", tabs.aimbot, "Snap On Fire", "aim_snaponfire", 5, 125 )
	C:createoption( "Checkbox", tabs.aimbot, "Autoshoot", "aim_autoshoot", 5, 145 )
	C:createoption( "Checkbox", tabs.aimbot, "Ignore Visibility Checks", "aim_ignorevisibility", 5, 165 )
	C:createoption( "Checkbox", tabs.aimbot, "Velocity Prediction", "aim_comp", 150, 5 )
	C:createoption( "Checkbox", tabs.aimbot, "Nospread", "aim_nospread", 150, 25 )
	C:createoption( "Slider",   tabs.aimbot, "Compensation Value", "aim_comp_val", 10, 80, 150, 150, 45 )
	C:createoption( "Slider", tabs.aimbot, "FOV", "aim_fov", 0, 180, 150, 150, 90 )
	C:createoption( "Slider", tabs.aimbot, "Offset Y", "aim_offset", -10, 10, 150, 150, 135 )
	C:createoption( "Checkbox", tabs.esp, "ESP Enabled", "esp", 5, 5 )
	C:createoption( "Checkbox", tabs.esp, "Name, Health, Status", "esp_info", 5, 25 )
	C:createoption( "Checkbox", tabs.esp, "Admin List", "esp_adminlist", 5, 45 )
	C:createoption( "Checkbox", tabs.esp, "RP Entities", "esp_rpents", 5, 65 )
	C:createoption( "Checkbox", tabs.esp, "TTT Traitor Weapons", "esp_traitorweps", 5, 85 )
	C:createoption( "Checkbox", tabs.esp, "Chams", "esp_chams", 5, 105 )
	C:createoption( "Slider", tabs.esp, "Chams Mat", "esp_chams_type", 1, 2, 80, 220, 15 )
	C:createoption( "Checkbox", tabs.misc, "Bunnyhopping", "bhop", 5, 5 )
	C:createoption( "Checkbox", tabs.misc, "Crosshair", "crosshair", 5, 25 )
	C:createoption( "Checkbox", tabs.misc, "Constant Namesteal", "namesteal_auto", 5, 45 )
	C:createoption( "Checkbox", tabs.misc, "No Visual Recoil", "novisualrecoil", 5, 65 )
	C:createoption( "Checkbox", tabs.misc, "ULX/Evolve Ungag", "ungag", 5, 85 )
	C:createoption( "Button", tabs.misc, "Steal Random Name", "namesteal", 170, 15 )
	C:createoption( "Button", tabs.misc, "Anti-Mute", "antimute", 170, 50 )
end
C:addcommand( "+ph0ne_menu", C.menu )
C:addcommand( "-ph0ne_menu", function() if C.frame then C.frame:Remove(); C.frame = nil end end )

print( ":: CBaseAimbot successfully loaded." )