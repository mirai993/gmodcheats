aimbot = {}
aimbot.Version = 1.0
aimbot.Owner = LocalPlayer()
aimbot.Enabled = false
aimbot.Target = NULL
	print("TasteTheRainbow v2.3 Loaded")
LocalPlayer():ChatPrint("TasteTheRainbow v2.3 Loaded")
LocalPlayer():ChatPrint("Aimbot Loaded")
LocalPlayer():ChatPrint("Wallhack Loaded")
LocalPlayer():ChatPrint("by Skittles 2.0")

Msg( "\n[aimbot] ----------------------------------------\n" )
Msg( "[TasteTheRainbow] Welcome to TasteTheRainbow v2.3.\n" )
Msg( "[TasteTheRainbow] Use the command \"aimbot help\" to get started.\n" )
Msg( "[TasteTheRainbow] ----------------------------------------\n\n" )

function aimbot.Think() -- Starting the function
if ( aimbot.Enabled ) then
local ply = LocalPlayer() -- Getting ourselves
local trace = util.GetPlayerTrace( ply ) -- Player Trace part. 1
local traceRes = util.TraceLine( trace ) -- Player Trace part. 2
if traceRes.HitNonWorld then -- If the aimbot aims at something that isn't the map..
	local target = traceRes.Entity -- It's obviously an entity.
	if target:IsPlayer() then -- But it must be a player.
		local targethead = target:LookupBone("ValveBiped.Bip01_Head1") -- In this aimbot we only aim for the head.
		local targetheadpos,targetheadang = target:GetBonePosition(targethead) -- Get the position/angle of the head.
		ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) -- And finally, we snap our aim to the head of the target.
	end
end
end

									if ( aimbot.AttackState ) then
											local targethead = target:LookupBone()
											aimbot.AttackState = false
									end
						end

hook.Add( "Think", "aimbotThink", aimbot.Think )
hook.Add("Think","aimbot",aimbot)

function aimbot.Command( ply, command, args )
	if ( #args == 0 ) then
			aimbot.Enabled = !aimbot.Enabled
			if ( aimbot.Enabled ) then
					Msg( "[TasteTheRainbow] Enabled.\n" )
			else
					Msg( "[TasteTheRainbow] Disabled.\n" )
			end

	elseif ( args[ 1 ] == "help" ) then
			Msg( "\n[TasteTheRainbow] ----------------------------------------\n" )
			Msg( "Use the command \"aimbot\" to toggle aimbot on and off.\n" )
			Msg( "Commands: \n" )
			Msg( " o ESP(Wallhack) - See players names through walls.\n" )
			Msg( "[TasteTheRainbow] v 2.3 \n" )
			Msg( "[TasteTheRainbow] ----------------------------------------\n\n" )
	end
end
hook.Add( "HUDPaint", "aimbot.Wallhack", function()
for k,v in pairs ( player.GetAll() ) do

	local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
	local Name = ""

	if v == LocalPlayer() then Name = "" else Name = v:Name() end

	draw.DrawText( Name, "MenuLarge", Position.x, Position.y, Color( 158, 234, 194, 300 ), 1 )

end

end )

local shouldDraw = true

local hzCross = CreateClientConVar("HZ_Crosshair","0",false)

function Crosshair1()
surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

concommand.Add( "aimbot", aimbot.Command )

function FindDarkRPEnts()
SystemOnline = true

hook.Add("HUDPaint", "FindDarkRPEnts", function()
for _, ent in pairs(ents.GetAll()) do
	if IsValid(ent) and (ent:GetClass() == "money_printer" or ent:GetClass() == "drug_lab" or ent:GetClass() == "gunlab" or ent:GetClass() == "microwave"
	or ent:GetClass() == "spawned_shipment") then
		ent:SetMaterial("JamsMaterials/hai")
	else
		end
	end
end)
end

FindDarkRPEnts()

concommand.Add("jam_materials", function()

	if SystemOnline then
		hook.Remove("HUDPaint", "FindDarkRPEnts")

for _, ent in pairs(ents.GetAll()) do
	if (ent:GetClass() == "money_printer" or ent:GetClass() == "drug_lab" or ent:GetClass() == "gunlab" or ent:GetClass() == "microwave"
	or ent:GetClass() == "spawned_shipment") then
		ent:SetMaterial("")
end
end

LocalPlayer():ChatPrint("[Materials] - Materials are now back to normal.")
	SystemOnline = false

		elseif !SystemOnline then
			FindDarkRPEnts()
			LocalPlayer():ChatPrint("[Materials] - Materials are now overrwitten.")
	SystemOnline = true
end
end)




local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
	Vector( min.x, min.y, min.z ),
	Vector( min.x, min.y, max.z ),
	Vector( min.x, max.y, min.z ),
	Vector( min.x, max.y, max.z ),
	Vector( max.x, min.y, min.z ),
	Vector( max.x, min.y, max.z ),
	Vector( max.x, max.y, min.z ),
	Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
	local onScreen = ent:LocalToWorld( corner ):ToScreen()
	minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
	maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "Example", function()
for k,v in pairs(player.GetAll()) do
	local x1,y1,x2,y2 = coordinates(v)
	 print(tostring(team.GetColor(v:Team())))
	 surface.SetDrawColor(color_white)


	surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
	surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )


	surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
	surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )


	surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
	surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )


	surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
	surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end)

local struc = {}
struc.pos = {}
struc.pos[1] = 100 -- x pos
struc.pos[2] = 200 -- y pos
struc.color = Color(255,0,0,255) -- Red
struc.text = "Hello World" -- Text
struc.font = "DefaultFixed" -- Font
struc.xalign = TEXT_ALIGN_CENTER -- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )