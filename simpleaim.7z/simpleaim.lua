/* SimpleAim By Logic_Bomb
Tracer Hook Originally by BobFM (Editted By Logic_Bomb) */

/* Controls:
Player-Snap: Left-Alt
Change Team Aim: Middle-Mouse
Tracers: F6
DarkRP: F8
Player Markers: F10
Player Names: F11
*/

hook.Add("Think", "KeyListener", KeyListener)
hook.Add("HUDPaint", "Tracer", Draw)
hook.Add("HUDPaint", "AimStats", HUD)
hook.Add("Think", "Aimbot", Aim)
hook.Add("Think", "Nick_Listener", GetNicks)
hook.Add("HUDPaint", "GetDarkRP", GetDRPStats)

local DebugOn = CreateClientConVar("ae_debug", "0", false, false)

local FireOn = false
local Target = false
local TargetOn = false
local KeyTimer = tonumber(os.clock())
local KeyNow = tonumber(os.clock())

local DoDraw = false
local DoRect = true
local DoText = false
local DoAim = false
local DoTrigger = false
local ShowHUD = true

local DoDarkRP = false

local SelectedNick = nil
local TempNick = nil
local DoNick = nil

local NickCount = 1
local TotalNicks = 1
local NickReady = false

local SavedNick = nil
local SelPlayer = nil

local ClosestE = 100

local SameTeam = false

function Draw() //Tracer Hook - Used to draw tracers to players
    for k, v in pairs (player.GetAll()) do
        if (v != LocalPlayer()) and (v:Alive()) then
            local TPlayer = v:GetPos()
            local TEnemy = LocalPlayer():GetPos()
            local TX = 0
            local TY = 0
            local TZ = 0
            local TT = 0
            TX = TEnemy.x - TPlayer.x
            TY = TEnemy.y - TPlayer.y
            TZ = TEnemy.z - TPlayer.z
            TT = TX + TY + TZ
            TT = math.abs(TT)
            TT = math.Round(TT)
            TT = "Distance: " .. TT

    local EntPos = v:EyePos():ToScreen()
    local EntPosWorld = v:EyePos()
    local PlyPos = {x = ScrW()/2,
    y = ScrH()/2}
    local pos = LocalPlayer():GetShootPos()

            if v:Team() != LocalPlayer():Team() then
    surface.SetDrawColor(255, 0, 0)
    surface.SetTextColor(255, 0, 0)
    else
                surface.SetDrawColor(0, 255, 0)
    surface.SetTextColor(0, 255, 0)
    end

            if v:IsBot() then
    surface.SetDrawColor(255, 255, 0)
    surface.SetTextColor(255, 255, 0)
            end

    if v:IsAdmin() then
    surface.SetDrawColor(255, 0, 255)
    surface.SetTextColor(255, 0, 255)
    end

    if v:IsSuperAdmin() then
    surface.SetDrawColor(255, 0, 255)
    surface.SetTextColor(255, 0, 255)
    end

    if EntPos.y > 0 and EntPos.y < ScrH() then
    if DoDraw then
    surface.DrawLine(PlyPos.x, PlyPos.y, EntPos.x, EntPos.y)
    end
                if DoRect then
    surface.DrawOutlinedRect(EntPos.x, EntPos.y, 7, 7)
    end
    if DoText then
    surface.SetTextPos(EntPos.x-string.len(v:Nick())*3, EntPos.y+5)
    surface.DrawText(v:Nick())
        surface.SetTextPos(EntPos.x-string.len(TT)*3, EntPos.y+20)
        surface.DrawText(TT)
    end
            end
        end
    end
end

function Aim() //Autoaim Hook - Used to automatically aim at the head of the Player.
    if DoAim then
        for k, v in pairs (player.GetAll()) do
            if !(v == LocalPlayer()) then
                local HeadPos = v:EyePos()
                local THead = v:LookupBone("ValveBiped.Bip01_Head1")
                local HeadPos = v:GetBonePosition(THead)
                local PlyPos = {x = ScrW()/2,
        y = ScrH()/2}
                local pos = LocalPlayer():GetShootPos()
                if SelectedNick != nil then
        if v:Nick() == DoNick then
        if v:Alive() then
        LocalPlayer():SetEyeAngles((HeadPos - pos):Angle())
        else
        DoAim = !DoAim
        end
        end
                end
            end
        end
    end
end

function GetDRPStats() //Used to find DarkRP items
    if DoDarkRP and LocalPlayer():Alive() then
        for k, v in pairs(ents.GetAll()) do
            local EntitPos = v:GetPos():ToScreen()
            local ECoords = v:GetPos()
            local PCoords = LocalPlayer():GetPos()
            local DistX = 0
            local DistY = 0
            local DistZ = 0
            local DistT = 0
            DistX = ECoords.x - PCoords.x
            DistY = ECoords.y - PCoords.y
            DistZ = ECoords.z - PCoords.z
            DistT = DistX + DistY + DistZ
            DistT = math.abs(DistT)
            DistT = math.Round(DistT)
            //Debug Method
            if v:GetModel() != nil and DebugOn:GetBool() then
                surface.SetTextColor(255,255,255)
                surface.SetTextPos(EntitPos.x-100, EntitPos.y-30)
                surface.DrawText(v:GetModel())
            end
            //Money Printers
            if (v:GetModel() == "models/props_c17/consolebox01a.mdl") or (v:GetModel() == "models/props_c17/consolebox03a.mdl") then
                surface.SetDrawColor(0, 0, 255)
                surface.SetTextColor(0, 0, 255)
                surface.SetTextPos(EntitPos.x-15, EntitPos.y-30)
                surface.DrawText("$$$ - " .. DistT)
                surface.DrawOutlinedRect(EntitPos.x, EntitPos.y-10, 7, 7)
            end
            //Cash
            if (v:GetModel() == "models/props/cs_assault/money.mdl") then
                surface.SetDrawColor(0, 0, 255)
                surface.SetTextColor(0, 0, 255)
                surface.SetTextPos(EntitPos.x-15, EntitPos.y-30)
                surface.DrawText("$$$ - " .. DistT)
                surface.DrawOutlinedRect(EntitPos.x, EntitPos.y-10, 7, 7)
            end
            //Weapons Spawner
            if (v:GetModel() == "models/props_c17/trappropeller_engine.mdl") then
                surface.SetDrawColor(0, 0, 255)
                surface.SetTextColor(0, 0, 255)
                surface.SetTextPos(EntitPos.x-15, EntitPos.y-30)
                surface.DrawText("SPAWNER")
                surface.DrawOutlinedRect(EntitPos.x, EntitPos.y-10, 7, 7)
            end
            //Weps
            if (v:GetModel() == "models/weapons/w_pist_deagle.mdl") or
                (v:GetModel() == "models/weapons/w_pist_fiveseven.mdl") or
                (v:GetModel() == "models/weapons/w_pist_glock18.mdl") or
                (v:GetModel() == "models/weapons/w_pist_p228.mdl") or
                (v:GetModel() == "models/weapons/w_pist_usp.mdl") or
                (v:GetModel() == "models/weapons/w_pist_elite_dropped.mdl") then
                surface.SetDrawColor(0, 0, 255)
                surface.SetTextColor(0, 0, 255)
                surface.SetTextPos(EntitPos.x-5, EntitPos.y-30)
                surface.DrawText("GUN")
                surface.DrawOutlinedRect(EntitPos.x, EntitPos.y-10, 7, 7)
            end
            if v:IsWeapon() then
                surface.SetDrawColor(0, 0, 255)
                surface.SetTextColor(0, 0, 255)
                surface.SetTextPos(EntitPos.x-5, EntitPos.y-30)
                surface.DrawText("GUN")
                surface.DrawOutlinedRect(EntitPos.x, EntitPos.y-10, 7, 7)
            end
        end
    end
end

function GetNicks() //Used to keep a DB of nicks
if !Target then
    ClosestE = 100
    for k, v in pairs (player.GetAll()) do
        if v:IsValid() then
        //Math Stuff
            if SameTeam and v:Team() == LocalPlayer():Team() then
                local EnemCo = v:GetPos():ToScreen()
                local MyCo = {x = ScrW()/2,
          y = ScrH()/2}
                local DT = 0
                DT = math.sqrt((MyCo.x - EnemCo.x)^2 + (MyCo.y - EnemCo.y)^2)
                DT = math.Round(DT)
                if v:Alive() and v != LocalPlayer() and SavedNick != nil then
        if DT < ClosestE then
        if !SavedNick:Alive() then
        TempNick = v:Nick()
        end
        ClosestE = DT
        end
                else
        if DT < ClosestE and v:Alive() and v != LocalPlayer() then
        TempNick = v:Nick()
        ClosestE = DT
        SavedNick = v.GetByID
        end
                end
            end
            if !SameTeam and v:Team() != LocalPlayer():Team() then
                local EnemCo = v:GetPos():ToScreen()
                local MyCo = {x = ScrW()/2,
          y = ScrH()/2}
                local DT = 0
                DT = math.sqrt((MyCo.x - EnemCo.x)^2 + (MyCo.y - EnemCo.y)^2)
                DT = math.Round(DT)
                if v:Alive() and v != LocalPlayer() and SavedNick != nil then
        if DT < ClosestE then
        if !SavedNick:Alive() then
        TempNick = v:Nick()
        end
        ClosestE = DT
        end
                else
        if DT < ClosestE and v:Alive() and v != LocalPlayer() then
        TempNick = v:Nick()
        ClosestE = DT
        SavedNick = v.GetByID
        end
                end
            end
        end
    end
    NickReady = false
    SelectedNick = TempNick
    NickReady = true
end
end

function KeyListener() //Key Listener Hook
    if input.IsKeyDown(KEY_F6) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            DoDraw = !DoDraw
            KeyTimer = tonumber(os.clock()) + 0.6
        end
    end
    if input.IsKeyDown(KEY_F8) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            DoDarkRP = !DoDarkRP
            if DoDarkRP then
                hook.Add("HUDPaint", "GetDarkRP", GetDRPStats)
            end
            KeyTimer = tonumber(os.clock()) + 0.6
        end
    end
    if input.IsKeyDown(KEY_F9) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            KeyTimer = tonumber(os.clock()) + 0.6
        end
    end
    if input.IsKeyDown(KEY_F10) then
  KeyNow = tonumber(os.clock())
  if KeyNow > KeyTimer then
    DoRect = !DoRect
    KeyTimer = tonumber(os.clock()) + 0.6
  end
    end
    if input.IsKeyDown(KEY_F11) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            DoText = !DoText
    KeyTimer = tonumber(os.clock()) + 0.6
  end
    end
    if input.IsKeyDown(81) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            DoAim = !DoAim
            DoNick = SelectedNick
            KeyTimer = tonumber(os.clock()) + 0.6
        end
    end
    if input.IsMouseDown(MOUSE_MIDDLE) then
        KeyNow = tonumber(os.clock())
        if KeyNow > KeyTimer then
            SameTeam = !SameTeam
            KeyTimer = tonumber(os.clock()) + 0.6
        end
    end
end

function HUD() //HUD Paint Hook
  if ShowHUD then
            if SelectedNick != nil then
                draw.WordBox( 8, (ScrW()/2)-80, 8, "Aimbot Target: " .. SelectedNick, "Default", Color(50, 50, 75, 100), Color(0, 255, 0, 255) )
            else
                draw.WordBox( 8, (ScrW()/2)-80, 8, "Aimbot Target: [Off]", "Default", Color(50, 50, 75, 100), Color(0, 255, 0, 255) )
            end
            //Tracers
            if DoDraw then
                draw.WordBox( 8, 415, ScrH()-27, "[F6] Tracers [On]", "Default", Color(50, 50, 75, 100), Color(50, 205, 50, 255) )
            else
    draw.WordBox( 8, 415, ScrH()-27, "[F6] Tracers [Off]", "Default", Color(50, 50, 75, 100), Color(190, 190, 190, 255) )
    end
            //Aimbot
            if !DoAim then
    draw.WordBox( 8, 300, ScrH()-27, "[ALT] Aimbot [Off]", "Default", Color(50, 50, 75, 100), Color(190, 190, 190, 255) )
    else
    draw.WordBox( 8, 300, ScrH()-27, "[ALT] Aimbot [ON]  ", "Default", Color(50, 50, 75, 100), Color(50, 205, 50, 255) )
    end
            //Player Marker
            if !DoRect then
                draw.WordBox( 8, 530, ScrH()-27, "[F10] Player Markers [OFF]", "Default", Color(50, 50, 75, 100), Color(190, 190, 190, 255) )
            else
                draw.WordBox( 8, 530, ScrH()-27, "[F10] Player Markers [ON]  ", "Default", Color(50, 50, 75, 100), Color(50, 205, 50, 255) )
            end
            //Text
            if !DoText then
                draw.WordBox( 8, 691, ScrH()-27, "[F11] Player Names [OFF]", "Default", Color(50, 50, 75, 100), Color(190, 190, 190, 255) )
            else
                draw.WordBox( 8, 691, ScrH()-27, "[F10] Player Names [ON]  ", "Default", Color(50, 50, 75, 100), Color(50, 205, 50, 255) )
            end
            //DarkRP
            if !DoDarkRP then
                draw.WordBox( 8, 845, ScrH()-27, "[F8] DarkRP [OFF]", "Default", Color(50, 50, 75, 100), Color(190, 190, 190, 255) )
            else
                draw.WordBox( 8, 845, ScrH()-27, "[F8] DarkRP [On]", "Default", Color(50, 50, 75, 100), Color(50, 205, 50, 255) )
            end

  end
end