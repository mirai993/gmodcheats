/*
    FartClient v6.1

    needs gmcl_proxi_win64.dll to work
    if you dont got proxi get tf outa here noob

    one rule: dont give 2 enkai :)
*/

require("proxi")

if not proxi then return end

local g_bSendPacket = false
local g_bShouldEngineViewAngles = false
local FRAME_NET_UPDATE_END = proxi.FRAME_NET_UPDATE_END or 5

local g_pLocalPlayer = LocalPlayer()

local Cache = {
    TickInterval = engine.TickInterval(), 
    LastUpdate = 0,

    FacingAngle = g_pLocalPlayer:EyeAngles(),

    Players = {},
    Entities = {},

    TraceData = {},
    TraceOutput = {},

    Colors = {
        Red = Color(255, 0, 0, 255),
        Orange = Color(255, 150, 0, 255),
        Yellow = Color(255, 255, 0, 255),
        Green = Color(0, 255, 0, 255),
        Blue = Color(0, 0, 255, 255),
        Purple = Color(125, 0, 255, 255),

        White = Color(255, 255, 255, 255),
        Black = Color(0, 0, 0, 255),

        Gray = Color(175, 175, 175, 255),
        DarkGray = Color(50, 50, 50, 255),

        Pink = Color(255, 0, 200, 255),
        Crimson = Color(175, 0, 42, 255),
        Lavender = Color(165, 125, 255, 255),
        Teal = Color(0, 180, 180, 255),
        Seafoam = Color(201, 255, 229),
        Navy = Color(24, 35, 48, 250),
        DarkNavy = Color(10, 21, 32, 230),
        LightWhite = Color(217, 217, 217, 255)
    },

    ConVars = {
        cl_interp = proxi.GetConVar("cl_interp"),
        cl_interp_ratio = proxi.GetConVar("cl_interp_ratio"),
        cl_interpolate = proxi.GetConVar("cl_interpolate"),
        cl_updaterate = proxi.GetConVar("cl_updaterate"),

        sv_client_max_interp_ratio = proxi.GetConVar("sv_client_max_interp_ratio"),
        sv_client_min_interp_ratio = proxi.GetConVar("sv_client_min_interp_ratio"),
        sv_maxunlag = proxi.GetConVar("sv_maxunlag"),
        sv_maxupdaterate = proxi.GetConVar("sv_maxupdaterate"),
        sv_minupdaterate = proxi.GetConVar("sv_minupdaterate"),

        m_pitch = proxi.GetConVar("m_pitch"),
        m_yaw = proxi.GetConVar("m_yaw"),
        sv_gravity = proxi.GetConVar("sv_gravity"),
        view_recoil_tracking = proxi.GetConVar("view_recoil_tracking"),

        arccw_enable_penetration = proxi.GetConVar("arccw_enable_penetration"),
        M9KDisablePenetration = proxi.GetConVar("M9KDisablePenetration"),
        sv_tfa_bullet_penetration = proxi.GetConVar("sv_tfa_bullet_penetration"),
        TFA_HardLimit = proxi.GetConVar("sv_tfa_penetration_hardlimit"),
        TFA_Multiplier = proxi.GetConVar("sv_tfa_bullet_penetration_power_mul"),

        ai_shot_bias_min = proxi.GetConVar("ai_shot_bias_min"),
        ai_shot_bias_max = proxi.GetConVar("ai_shot_bias_max"),
        sv_tfa_recoil_legacy = proxi.GetConVar("sv_tfa_recoil_legacy"),

        Penetration = {
            ArcCW = proxi.GetConVar("arccw_enable_penetration"),
            M9K = proxi.GetConVar("M9KDisablePenetration"),
            TFA = proxi.GetConVar("sv_tfa_bullet_penetration"),
            TFA_Multiplier = proxi.GetConVar("sv_tfa_bullet_penetration_power_mul"),
            TFA_HardLimit = proxi.GetConVar("sv_tfa_penetration_hardlimit")
        }
    },

    NetMessages = {
        Buildmode = { "BuildMode", "buildmode", "_Kyle_Buildmode" },
        God = { "has_god", "god_mode", "ugod" },
        HVH = { "HVHER" },
        Protected = { "LibbyProtectedSpawn", "SH_SZ.Safe", "spawn_protect", "InSpawnZone" }
    },
        
    AimbotData = {
        ScanOrder = {
            HITGROUP_HEAD,
            HITGROUP_CHEST,
            HITGROUP_STOMACH
        }
    },

    ViewData = {},

    ScreenData = {
        Width = ScrW(),
        Height = ScrH(),

        Center = {
            X = math.floor(ScrW() / 2),
            Y = math.floor(ScrH() / 2)
        }
    },

    AmmoPen = {
        Max = { -- Gets :lower()'d; The 2nd values may need some tweaking to be more reliable as the more penetrations there are the chance of the next shot penetrating goes down
            ["357"] = {144, 4},
            ar2 = {256, 8},
            buckshot = {25, 1},
            pistol = {81, 2},
            smg1 = {196, 5},
            sniperpenetratedround = {400, 12},
            sniperround = {400, 12} -- Queer SWB
        },

        Materials = {
            Multipliers = {
                [MAT_SAND] = 0.5,
                [MAT_DIRT] = 0.8,
                [MAT_METAL] = 1.1,
                [MAT_TILE] = 0.9,
                [MAT_WOOD] = 1.2
            },

            NoPenetration = {
                [MAT_SLOSH] = true
            }
        }
    },

    WeaponData = {
        Nospread = {
            Cones = {},
            Seeds = {},
            Storage = {}
        },

        AutoShoot = {
            BaseFunctions = {
                bobs = function(self)
                    if self:Clip1() < 1 then return false end
                    if self:GetNWBool("Reloading") then return false end
            
                    local Owner = self:GetOwner()
                
                    if not Owner:IsPlayer() then return false end
                    if Owner:KeyDown(IN_SPEED) or Owner:KeyDown(IN_RELOAD) then return false end
                
                    return true
                end,

                cw = function(self)
                    if self:Clip1() == 0 then return false end
                    if not self:canFireWeapon(1) or not self:canFireWeapon(2) or not self:canFireWeapon(3) then return false end
                    if self:GetOwner():KeyDown(IN_USE) and rawget(rawget(CustomizableWeaponry, "quickGrenade"), "canThrow")(self) then return false end
                    if self.dt.State == CW_AIMING and self.dt.M203Active and self.M203Chamber then return false end
                    if self.dt.Safe then return false end
                    if self.BurstAmount and self.BurstAmount > 0 then return false end
                
                    return true
                end,

                fas2 = function(self)
                    if self:Clip1() <= 0 then return false end
                
                    local Owner = self:GetOwner()
                
                    if Owner:KeyDown(IN_USE) and self:CanThrowGrenade() then return false end
                    if Owner:WaterLevel() >= 3 then return false end
                
                    if self.FireMode == "safe" then return false end
                    if self.BurstAmount > 0 and self.dt.Shots >= self.BurstAmount then return false end
                    if self.ReloadState ~= 0 then return false end
                    if self.dt.Status == FAS_STAT_CUSTOMIZE then return false end
                    if self.Cooking or self.FuseTime then return false end
                    if self.dt.Status == FAS_STAT_SPRINT or self.dt.Status == FAS_STAT_QUICKGRENADE then return false end
                    if self.CockAfterShot and not self.Cocked then return false end
                
                    return true
                end,

                tfa = function(self)
                    local RunResult = hook.Run("TFA_PreCanPrimaryAttack", self)
                    if RunResult ~= nil then return RunResult end
                
                    local Status = self:GetStatus()
                    local EnumTable = rawget(TFA, "Enum")
                    if Status == rawget(EnumTable, "STATUS_RELOADING_WAIT") or Status == rawget(EnumTable, "STATUS_RELOADING") then return false end
                
                    if self:IsSafety() then return false end
                    if self:GetSprintProgress() >= 0.1 and not self:GetStatL("AllowSprintAttack", false) then return false end
                    if self:GetStatL("Primary.ClipSize") <= 0 and self:Ammo1() < self:GetStatL("Primary.AmmoConsumption") then return false end
                    if self:GetPrimaryClipSize(true) > 0 and self:Clip1() < self:GetStatL("Primary.AmmoConsumption") then return false end
                    if self:GetStatL("Primary.FiresUnderwater") == false and self:GetOwner():WaterLevel() >= 3 then return false end
                
                    RunResult = hook.Run("TFA_CanPrimaryAttack", self)
                    if RunResult ~= nil then return RunResult end
                
                    if self:CheckJammed() then return false end
                
                    return true
                end,

                arccw = function(self)
                    if IsValid(self:GetHolster_Entity()) then return false end
                    if self:GetHolster_Time() > 0 then return false end
                    if self:GetReloading() then return false end
                    if self:GetWeaponOpDelay() > CurTime() then return false end
                    if self:GetHeatLocked() then return false end
                    if self:GetState() == rawget(ArcCW, "STATE_CUSTOMIZE") then return false end
                    if self:BarrelHitWall() > 0 then return false end
                    if self:GetNWState() == rawget(ArcCW, "STATE_SPRINT") and not (self:GetBuff_Override("Override_ShootWhileSprint", self.ShootWhileSprint)) then return false end
                    if (self:GetBurstCount() or 0) >= self:GetBurstLength() then return false end
                    if self:GetNeedCycle() then return false end
                    if self:GetCurrentFiremode().Mode == 0 then return false end
                    if self:GetBuff_Override("Override_TriggerDelay", self.TriggerDelay) and self:GetTriggerDelta() < 1 then return false end
                    if self:GetBuff_Hook("Hook_ShouldNotFire") then return false end
                    if self:GetBuff_Hook("Hook_ShouldNotFireFirst") then return false end
                
                    return true
                end
            },

            Classes = {
                Blacklist = { "bomb", "c4", "climb", "fist", "gravity gun", "grenade", "hand", "ied", "knife", "physics gun", "slam", "sword", "tool gun", "vape" },
                Whitelist = { "handgun" }
            }
        },
    }
}

local config = {}
config.clrs = {}
config.binds = {}

config["Aimbot"] = false -- i really fuck hate this, but this cheat is a paste so i dont care
config["AimHitbox"] = 1
config["MultiPoint"] = true
config["AutoWall"] = false
config["Autofire"] = true
config.binds["AimKey"] = 0
config["AimFOV"] = 16
config["RapidFire"] = false

config["NoSpread"] = false
config["NoRecoil"] = true

config["Backtrack"] = false
config["BacktrackTime"] = 0

config["ContextAiming"] = false

config["FovCircle"] = false
config["IgnorePlayers"] = false
config["IgnoreNPCs"] = false
config["IgnoreBots"] = false
config["IgnoreTeam"] = false
config["IgnoreFriends"] = false
config["IgnoreGodmode"] = true
config["IgnoreBuild"] = false
config["IgnoreProtected"] = true

config["AntiAim"] = false
config["AAPitch"] = 1
config["AAYaw"] = 1
config["AASpinSpeed"] = 1
config["FakeLag"] = false
config["FLChoke"] = 1
config["FLAdaptive"] = false

config["Visuals"] = false
config["Box"] = false
config["BoxFilled"] = false
config["3DBox"] = false
config["3DBoxFill"] = false
config["Health"] = false
config["Armor"] = false
config["Name"] = false
config["Weapon"] = false
config["Skeleton"] = false
config["Distance"] = false
config["Friend"] = false
config["ShowBacktrack"] = false
config["Rank"] = false
config["Chams"] = false
config["ChamsMaterial"] = 1
config["ShowPlayers"] = true
config["ShowNPCs"] = false
config["ShowOther"] = false
config["ESPRender"] = false
config["RenderDist"] = 250
config["EntRender"] = false
config["EntRenderDist"] = 400
config["ViewmodelChanger"] = false
config["removesway"] = false
config["removebob"] = false
config["ViewmodelFOV"] = 100
config["viewmodel_x"] = 0
config["viewmodel_y"] = 0
config["viewmodel_z"] = 0
config["viewmodel_p"] = 0
config["viewmodel_ya"] = 0
config["RemoveSky"] = false
config["RGBSky"] = false
config["RGBSpeed"] = 5
config["Crosshair"] = false
config["WorldModulation"] = false
config["Traitor"] = false
config["EntBox"] = false
config["EntName"] = false
config["EntDist"] = false
config["EntChams"] = false
config["Freecam"] = false
config.binds["Freecam_key"] = 0

config["Misc"] = false
config["Bhop"] = false
config["Autostrafe"] = false
config["SpectatorsList"] = false
config["AdminsList"] = false
config["Thirdperson"] = false
config.binds["Thirdperson_key"] = 0
config["ChatSpam"] = false
config["TPDistance"] = 120
config["Hitsound"] = false
config["MenuColor"] = false
config["config_name"] = nil

config.binds["menu_key"] = 72

config.clrs["Box"] = "61 133 224 255"
config.clrs["3DBox"] = "61 133 224 255"
config.clrs["BoxFilled"] = "61 133 224 255"
config.clrs["ArmorText"] = "84 101 255 255"
config.clrs["Name"] = "255 255 255 255"
config.clrs["Weapon"] = "255 255 255 255"
config.clrs["Distance"] = "255 255 255 255"
config.clrs["Friend"] = "54 134 255 255"
config.clrs["Traitor"] = "155 0 0 255"
config.clrs["Rank"] = "255 255 255 255"
config.clrs["Chams"] = "61 133 224 255"
config.clrs["Skeleton"] = "200 200 200 255"
config.clrs["RemoveSky"] = "0 0 0 255"
config.clrs["WorldModulation"] = "255 255 255 255"
config.clrs["MenuColor"] = "175, 0, 42, 255"
config.clrs["FovCircle"] = "255 255 255 255"
config.clrs["EntBox"] = "252 132 0 255"
config.clrs["EntName"] = "255 255 255 255"
config.clrs["EntDist"] = "255 255 255 255"
config.clrs["EntChams"] = "61 133 224 255"
config.clrs["Crosshair"] = "0 255 0 255"

config["FriendsList"] = {}
config["EntityList"] = {}

CreateMaterial("textured", "VertexLitGeneric")
CreateMaterial("flat", "UnLitGeneric")
CreateMaterial("wireframe", "VertexLitGeneric", { ["$wireframe"] = 1 })

local ChamMaterials = {
    ["Wireframe"] = "!wireframe",
    ["Flat"] = "!flat",
    ["Textured"] = "!textured"
}

surface.CreateFont("FT", { font = "Roboto Bold", weight = 1000, antialias = true, size = 32 })
surface.CreateFont("FT2", { font = "Bahnschrift Bold", weight = 500, antialias = true, size = 18 })
surface.CreateFont("FT3", { font = "Bahnschrift", weight = 300, antialias = true, size = 11 })
surface.CreateFont("FT4", { font = "Segoe UI", weight = 500, antialias = true, size = 14 })
surface.CreateFont("FT5", { font = "Tahoma", weight = 500, antialias = true, size = 13 })
surface.CreateFont("FT6", { font = "Tahoma", weight = 1000, antialias = true, size = 13 })
surface.CreateFont("FT7", { font = "Bahnschrift Bold", weight = 500, antialias = true, size = 15 })
surface.CreateFont("FT8", { font = "Bahnschrift", weight = 500, antialias = true, size = 12 })

local LastFrameSS = false

local function DisableWorldModulation()
    for k, v in pairs( Entity( 0 ):GetMaterials() ) do
        Material( v ):SetVector( "$color", Vector(1, 1, 1) )
        Material( v ):SetFloat( "$alpha", 1 )
    end
end

local function UpdateWorldModulation()
    local col = string.ToColor(config.clrs["WorldModulation"])

    for k, v in pairs( Entity( 0 ):GetMaterials() ) do
        Material( v ):SetVector( "$color", Vector(col.r * (1 / 255), col.g * (1 / 255), col.b * (1 / 255)) )
        Material( v ):SetFloat( "$alpha", col.a * (1 / 255) )
    end
end

local hooks = {}

local staffRanks = {"tmod", "trialmod", "trialmoderator", "tmoderator", "mod", "moderator", "smod", "smoderator", "seniormod", "seniormoderator", "jadmin", "junioradmin", "leadadmin", "headadmin", "trialadmin", "admin", "superadmin", "sadmin", "senioradmin", "owner", "developer", "manager", "staff"}

local ss = false
local verifyconfig = config

local bxsmenu, MenuX, MenuY, colorWindow, cfgDropdown, entityFrame, entityFrameX, entityFrameY, entityFrameWasOpen
local loadedCfg = {}
local files, dir = file.Find( "FartClient/*.json", "DATA" )
local intp, toggledelay3, toggledelayN = false, false, false

local function AddHook(Type, Function)
    local Name = tostring({})

    print(string.format("Hook Added [{%s} {%s}]", Type, Name))

    hooks[#hooks + 1] = {Type, Name}

    hook.Add(Type, Name, Function)
end

local function VerifyConfig()
    for k, v in pairs(verifyconfig) do
        if config[k] == nil then
            config[k] = verifyconfig[k]
            MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "The config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end

    for k, v in pairs(verifyconfig.clrs) do
        if config.clrs[k] == nil then
            if k == "config_name" then return end
            config.clrs[k] = verifyconfig.clrs[k]
            MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "The color config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end

    for k, v in pairs(verifyconfig.binds) do
        if config.binds[k] == nil then
            config.binds[k] = verifyconfig.binds[k]
            MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "The keybind config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your config with your desired settings to prevent this in the future.")
        end
    end
end

local chatspammer = {
    "whats the max tabs you can have open on a vpn","how many vpns does it take to stop a ddos","whats better analog or garrys mod","whats the time","is it possible to make a clock in binary",
    "how many cars can you drive at once","did you know there's more planes on the ground than there is submarines in the air","how many busses can you fit on 1 bus",
    "how many tables does it take to support a chair","how many doors does it take to screw a screw","how long can you hold your eyes closed in bed",
    "how long can you hold your breath for under spagetti","whats the fastest time to deliver the mail as mail man","how many bees does it take to make a wasp make honey",
    "If I paint the sun blue will it turn blue","how many beavers does it take to build a dam","how much wood does it take to build a computer","can i have ur credit card number",
    "is it possible to blink and jump at the same time","did you know that dinosaurs were, on average, large","how many thursdays does it take to paint an elephant purple",
    "if cars could talk how fast would they go","did you know theres no oxygen in space","do toilets flush the other way in australia","if i finger paint will i get a splinter",
    "can you build me an ant farm","can you craft me a campfire","did you know australia hosts 4 out of 6 of the deadliest spiders in the world",
    "is it possible to ride a bike in space","can i make a movie based around your life","how many pants can you put on while wearing pants","if I paint a car red can it wear pants",
    "how come no matter what colour the liquid is the froth is always white","can a hearse driver drive a corpse in the car pool lane","how come the sun is cold at night",
    "why is it called a TV set when there is only one","if i blend strawberries can i have ur number","if I touch the moon will it be as hot as the sun","did u know ur dad is always older than u",
    "did u know the burger king logo spells burger king","did uknow if u chew on broken glass for a few mins, it starts to taste like blood","did u know running is faster than walking",
    "did u kno the colur blue is called blue because its blue","did you know a shooting star isnt a star","did u know shooting stars dont actually have guns",
    "did u kno the great wall of china is in china","statistictal fact: 100% of non smokers die","did you kmow if you eat you poop it out",
    "did u know rain clouds r called rain clouds cus they are clouds that rain","if cows drink milk is that cow a cannibal","did u know you cant win a staring contest with a stuffed animal",
    "did u know if a race car is at peak speed and hits someone they'll die","did u know the distance between the sun and earth is the same distance as the distance between the earth and the sun",
    "did u kno flat screen tvs arent flat","did u know aeroplane mode on ur phone doesnt make ur phone fly","did u kno too many birthdays can kill you","did u know rock music isnt for rocks",
    "did u know if you eat enough ice you can stop global warming","if ww2 happened before vietnam would that make vietnam world war 2","did you know 3.14 isn't a real pie",
    "did u know 100% of stair accidents happen on stairs","can vampires get AIDS","what type of bird was a dodo","did u know dog backwards is god",
    "did you know on average a dog barks more than a cat", "FartClient > any other dogshit"
}

local fakeRT = GetRenderTarget( "fakeRT" .. os.time(), Cache.ScreenData.Width, Cache.ScreenData.Height )

AddHook("RenderScene", function( vOrigin, vAngle, vFOV )
    if ( !gui.IsConsoleVisible() and !gui.IsGameUIVisible() ) or ss then
        local view = {
            x = 0,
            y = 0,
            w = Cache.ScreenData.Width,
            h = Cache.ScreenData.Height,
            dopostprocess = true,
            origin = vOrigin,
            angles = vAngle,
            fov = vFOV,
            drawhud = true,
            drawmonitors = true,
            drawviewmodel = true
        }
    
        render.RenderView( view )
        render.CopyTexture( nil, fakeRT )

        cam.Start2D()
            hook.Run( "PostDrawHUD" )
        cam.End2D()

        render.SetRenderTarget( fakeRT )

        return true
    end
end)

AddHook( "ShutDown", function()
    render.SetRenderTarget()
end)

local renderv = render.RenderView
local renderc = render.Clear
local rendercap = render.Capture
local rendercappix = render.CapturePixels
local vguiworldpanel = vgui.GetWorldPanel
render.CapturePixels = function() return end
    
local function screengrab()
    if ss then return end
    ss = true
    
    renderc( 0, 0, 0, 255, true, true )
    renderv({
        origin = g_pLocalPlayer:EyePos(),
        angles = g_pLocalPlayer:EyeAngles(),
        x = 0,
        y = 0,
        w = Cache.ScreenData.Width,
        h = Cache.ScreenData.Height,
        dopostprocess = true,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    })
    
    local vguishits = vguiworldpanel()
    
    if IsValid( vguishits ) then
        vguishits:SetPaintedManually( true )
    end
    
    timer.Simple( 0.1, function()
        vguiworldpanel():SetPaintedManually( false )
        ss = false
    end)
end
    
render.Capture = function(data)
    screengrab()
    local cap = rendercap( data )
    return cap
end

function CloseFrame()
    MenuX, MenuY = bxsmenu:GetPos()
    RememberCursorPosition()
    bxsmenu:Remove()
    bxsmenu = false
end

local function SaveConfig()
    if cfgDropdown:GetSelected() == nil then return end
        
    local cfg = cfgDropdown:GetSelected()
    local JSONconfig = util.TableToJSON(config, true)
    file.Write("FartClient/"..cfg, JSONconfig)

    MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "Saved Config - ", Color(255, 0, 0), cfg, "\n")
end

local function LoadDefault()
    local JSONconfig = file.Read("FartClient/default.json", "DATA")
    config = util.JSONToTable(JSONconfig)

    VerifyConfig()

    loadedCfg[0] = "default.json"
    for k, v in ipairs(files) do
        if v == "default.json" then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "Loaded Default Config\n")
end

local function LoadConfig()
    if cfgDropdown:GetSelected() == nil then return end

    local cfg = cfgDropdown:GetSelected()
    local JSONconfig = file.Read("FartClient/"..cfg, "DATA")
    config = util.JSONToTable(JSONconfig)

    VerifyConfig()

    loadedCfg[0] = cfg
    for k, v in ipairs(files) do
        if v == cfg then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "Loaded Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    ToggleMenu()
end


local function CreateConfig()
    if config["config_name"] == nil then return end
        
    if file.Exists("FartClient/"..config["config_name"]..".json", "DATA") then return end

    local JSONconfig = util.TableToJSON(config, true)
    file.CreateDir("FartClient")
    file.Write("FartClient/"..config["config_name"]..".json", JSONconfig)

    MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "Created Config - ", Color(255, 0, 0), config["config_name"], "\n")

    CloseFrame()
    ToggleMenu()
end


local function DeleteConfig()
    if cfgDropdown:GetSelected() == nil then return end
        
    local cfg = cfgDropdown:GetSelected()
    file.Delete("FartClient/"..cfg)

    loadedCfg = {}

    MsgC(Color(61, 149, 217), "\n[FartClient] ", Color(222, 222, 222), "Deleted Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    ToggleMenu()
end

function hookdel()
    for i = 1, #hooks do
        local CurrHook = hooks[i]
        local Type, Name = CurrHook[1], CurrHook[2]

        print(string.format("Hook Removed [{%s} {%s}]", Type, Name))

        hook.Remove(Type, Name)
    end

    if bxsmenu then bxsmenu:Remove() end
    if colorWindow then colorWindow:Remove() end
    if entityFrame then entityFrame:Remove() end

    for _, v in pairs(player.GetAll()) do
        v:SetRenderMode(0)
    end

    DisableWorldModulation()
end

local function CreateLabel(lbl, x, y, par)
    local label = vgui.Create("DLabel", par)
    label:SetTextColor(Cache.Colors.Seafoam)
    label:SetFont("FT4")
    label:SetText(lbl)
    local w, h = label:GetTextSize()
    label:SetSize(w, h)
    label:SetPos(x, y)
end

local function CheckBox(Parent, Text, PosX, PosY, Var, Col, Extra )
    local CheckBox = vgui.Create( "DCheckBoxLabel", Parent )
    CheckBox:SetFont("FT4")
    CheckBox:SetText( Text )
    CheckBox:SetSize( 16 + surface.GetTextSize(Text) + 10, 17 )
    CheckBox:SetPos( PosX, PosY )
    CheckBox:SetValue( config[Var] )
    function CheckBox:OnChange(bVal)
        config[Var] = bVal
    end
    function CheckBox.Button:Paint(w, h)
        local menucolor = string.ToColor(config.clrs["MenuColor"])
        if self:GetChecked() then
            CheckBox:SetTextColor(Cache.Colors.White)
            draw.RoundedBox( 4, 1, 1, w - 1, h - 1, menucolor )
        else
            CheckBox:SetTextColor( Cache.Colors.Seafoam )
            draw.RoundedBox( 4, 1, 1, w - 1, h - 1, Cache.Colors.DarkGray )
        end
    end
    if Col then
        local cx, cy = CheckBox:GetPos()
        local colorPicker = vgui.Create("DImageButton", Parent)
        colorPicker:SetImage("icon16/color_wheel.png")
        colorPicker:SetSize(16, 16)
        if Extra then
            colorPicker:SetPos(cx + CheckBox:GetWide() + 5, PosY + 1)
        else
            colorPicker:SetPos(cx + 205 + 4, PosY + 1)
        end
        function colorPicker:DoClick()
            if IsValid(colorWindow) then
                colorWindow:Remove()
            end
            colorWindow = vgui.Create("DFrame")
            colorWindow:SetSize(300, 225)
            colorWindow:SetTitle(Text .. " - Color Picker")
            function colorWindow:Paint(w, h)
                draw.RoundedBox(6, 1, 1, w - 2, h - 2, Cache.Colors.DarkNavy)
                draw.RoundedBox(0, 5, 24, w - 10, 2, Cache.Colors.Navy)
            end
            local frameX, frameY = bxsmenu:GetPos()
            if frameX + 350 > Cache.ScreenData.Width then
                colorWindow:Center()
            else
                colorWindow:SetPos(frameX + 350, frameY)
            end
            colorWindow:MakePopup()

            local colorSelector = vgui.Create("DColorMixer", colorWindow)
            colorSelector:Dock(FILL)
            colorSelector:DockPadding(5, 5, 5, 25)
            colorSelector:SetPalette(true)
            colorSelector:SetColor(string.ToColor(config.clrs[Var]))
            function colorSelector:ValueChanged(val)
                local r = tostring(val.r)
                local g = tostring(val.g)
                local b = tostring(val.b)
                local a = tostring(val.a)
                local col = r.." "..g.." "..b.." "..a
                config.clrs[Var] = col
            end
        end
    end
end

local function Slider(text, x, y, cfg, min, max, dec, par)
    local sliderLabel = vgui.Create("DLabel", par)
    sliderLabel:SetTextColor(Cache.Colors.Seafoam)
    sliderLabel:SetText(text)

    local w, h = sliderLabel:GetTextSize()
    sliderLabel:SetWide(w)
    sliderLabel:SetPos(x + 5, y - h / 8 - 1)

    local slider = vgui.Create("DNumSlider", par)
    slider:SetWide(250)
    slider:SetPos(x - 104, y + 3)
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDark(false)
    slider:SetDefaultValue(config[cfg])
    slider:ResetToDefaultValue()
    slider:SetDecimals(dec)

    function slider:OnValueChanged()
        config[cfg] = slider:GetValue()
    end

    slider.Slider.Paint = function(self,w,h)
        local getwidth = slider.Slider.Knob:GetPos()
        draw.RoundedBox(0,2,16,w-4,2,Cache.Colors.Navy)
        draw.RoundedBox(0,2,16,getwidth-2,2,string.ToColor(config.clrs["MenuColor"]))
    end
        
    slider.Slider.Knob:SetSize(10,10)
    slider.Slider.Knob.Paint = function(self,w,h)
        draw.RoundedBox(64,0,1,w,h,string.ToColor(config.clrs["MenuColor"]))
    end
    slider.Slider:SetNotches(0)
    slider.Slider:SetNotchColor(Cache.Colors.White)
    slider.Scratch:SetVisible(false)
end

local function Binder( Parent, PosX, PosY, SizeX, SizeY, Var )
    local Bind = vgui.Create( "DBinder", Parent )
    Bind:SetTextColor(Cache.Colors.Seafoam)
    Bind:SetValue( config.binds[Var] )
    Bind:SetSize( SizeX, SizeY )
    Bind:SetPos( PosX, PosY )
    Bind.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Cache.Colors.Navy)
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, Cache.Colors.Black)
    end
    Bind.OnChange = function()
        config.binds[Var] = Bind:GetValue()
    end
end

local function ComboBox(Parent, Text, PosX, PosY, Choices, Var, W1, H1)
    local dropdownLabel = vgui.Create("DLabel", Parent)
    dropdownLabel:SetTextColor(Cache.Colors.LightWhite)
    dropdownLabel:SetText(Text)

    local w, h = dropdownLabel:GetTextSize()
    dropdownLabel:SetWide(w)
    dropdownLabel:SetPos(PosX + 2, PosY - h / 8 + 4)

    local dropdown = vgui.Create("DComboBox", Parent)
    dropdown:SetSize(W1, H1)
    dropdown:SetPos(PosX, PosY + 20)

    for k, v in ipairs(Choices) do
        dropdown:AddChoice(v)
    end

    dropdown:SetSortItems(false)
    dropdown:ChooseOptionID(config[Var])

    function dropdown:OnSelect(index, value, data)
        config[Var] = index
    end
end

local function CreateButton(lbl, tooltip, fnc, x, y, par, w1, h1)
    local button = vgui.Create("DButton", par)
    button:SetSize(w1, h1)
    button:SetPos(x, y)
    button:SetTextColor(Cache.Colors.Seafoam)
    button:SetFont("FT7")
    button:SetText(lbl)

    function button:Paint(w, h)
        draw.RoundedBox(4, 0, 0, w, h, Cache.Colors.Navy)
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, Cache.Colors.Black)
    end
    function button:DoClick()
        fnc()
    end
end

local function CreateTextInput(lbl, Var, x, y, chars, par, w1)
    local textInput = vgui.Create("DTextEntry", par)
    textInput:SetSize(w1, 20)
    textInput:SetPos(x, y)
    textInput:IsMultiline( false )
    textInput:SetMaximumCharCount(chars)
    textInput:SetPlaceholderText(lbl)

    textInput.Think = function()
        if textInput:IsEditing() then
            editingText = true
        else
            editingText = false
        end
        config[Var] = textInput:GetValue()
    end 
end

local function SubPanel(parent, text, x, y, w1, h1)
    local panel = vgui.Create("DPanel", parent)
    panel:SetPos( x, y )
    panel:SetSize( w1, h1 )
    panel.Paint = function(self, w, h)
        draw.RoundedBox(6, 1, 1, w - 2, h - 2, Cache.Colors.Navy)
        draw.RoundedBox(0, 5, 28, w - 10, 2, Cache.Colors.LightWhite)
        draw.SimpleText(text, "FT2", 8, 5, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
    end
end

local function CreateEntityList()
    if !entityFrame then
        local entityFrame = vgui.Create("DFrame")
        entityFrame:SetSize(425, 200)
        entityFrame:SetTitle("Entity ESP")

        if entityFrameX == nil or entityFrameY == nil then
            entityFrame:Center()
        else
            entityFrame:SetPos(entityFrameX, entityFrameY) 
        end

        entityFrame:MakePopup()

        function entityFrame:Paint(w, h)
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Cache.Colors.Black)
            draw.RoundedBox(0, 5, 24, w - 10, 2, Cache.Colors.Navy)
            draw.RoundedBox(6, 299, 34, 120, 86, Cache.Colors.Navy)
        end

        function entityFrame:OnClose()
            entityFrameX, entityFrameY = entityFrame:GetPos()
            entityFrame = false
        end

        local entList = vgui.Create("DListView", entityFrame)
        entList:DockMargin(0, 0, 125, 0)
        entList:Dock(FILL)
        entList:SetMultiSelect(false)
        entList:AddColumn("Entities")

        for k, v in ipairs(ents.GetAll()) do
            local good = true
            for k, line in ipairs( entList:GetLines() ) do
                if line:GetValue( 1 ) == v:GetClass() then good = false break end
            end
                
            if v:GetClass() != "worldspawn" and v:GetClass() != "player" and v:GetOwner() != g_pLocalPlayer and good then
                entList:AddLine(v:GetClass())
            end
        end

        local enable = vgui.Create("DCheckBoxLabel", entityFrame)
        enable:SetFont("FT4")
        enable:SetText("Enable ESP")
        surface.SetFont("FT4")
        enable:SetSize( 16 + surface.GetTextSize("Enable ESP") + 10, 17 )
        enable:SetPos(304, 35)
        enable:SetValue( false )

        function enable.Button:Paint(w, h)
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            if self:GetChecked() then
                enable:SetTextColor( Cache.Colors.White )
                draw.RoundedBox( 4, 1, 1, w - 1, h - 1, menucolor )
            else
                enable:SetTextColor( Cache.Colors.Seafoam )
                draw.RoundedBox( 4, 1, 1, w - 1, h - 1, Cache.Colors.Black )
            end
        end

        function enable:OnChange( bVal )
            if entList:GetSelectedLine() != nil then
                local _, line = entList:GetSelectedLine()
                if bVal then
                    if table.HasValue(config["EntityList"], line:GetColumnText(1)) then 
                        return
                    else 
                        config["EntityList"][#config["EntityList"] + 1] = line:GetColumnText(1)
                    end
                else
                    if table.HasValue(config["EntityList"], line:GetColumnText(1)) then
                        table.RemoveByValue(config["EntityList"], line:GetColumnText(1))
                    end
                end
            end
        end
        
        CheckBox(entityFrame, "Box ESP", 304, 51, "EntBox", true, true)
        CheckBox(entityFrame, "Name ESP", 304, 67, "EntName", true, true)
        CheckBox(entityFrame, "Distance ESP", 304, 83, "EntDist", true, true)
        CheckBox(entityFrame, "Chams", 304, 99, "EntChams", true, true)

        function entList:OnRowSelected(ind, line)
            if table.HasValue(config["EntityList"], line:GetColumnText(1)) then
                enable:SetValue(true)
            else
                enable:SetValue(false) 
            end
        end
    end
end

local function AddFriend( ply )
    if !ply:IsValid() then return end
    if table.HasValue( config["FriendsList"], ply ) then return end
    config["FriendsList"][#config["FriendsList"] + 1] = ply
end

local function DelFriend( ply )
    if !ply:IsValid() then return end
    if !table.HasValue( config["FriendsList"], ply ) then return end
    table.RemoveByValue( config["FriendsList"], v )
end

local function IsFriend( ply )
    if !ply or !ply:IsValid() then return false end
    return table.HasValue( config["FriendsList"], ply )
end

AddHook( "player_spawn", function( data )
    local id = data.userid
    local ply =  player.GetByID( id )
    if !ply:IsValid() then return end
    if ply:GetFriendStatus() == "friend" and !table.HasValue( config["FriendsList"], ply ) then
        AddFriend( ply )
    end
end)

local function RefreshFriends()
    for k, v in pairs(player.GetAll()) do
        if v:GetFriendStatus() == "friend" then AddFriend( v ) end
    end
end

local activetab = 'Aimbot'

for k, v in ipairs(files) do
    if string.lower(v) == "default.json" then
        LoadDefault()
    end
end

function ToggleMenu()
    files, dir = file.Find("FartClient/*.json", "DATA" )
    bxsmenu = vgui.Create("DFrame")
    bxsmenu:SetSize(700, 500)

    if MenuX == nil or MenuY == nil then
        bxsmenu:Center()
    else
        bxsmenu:SetPos(MenuX, MenuY)
    end

    bxsmenu:SetTitle("")
    bxsmenu:SetDraggable(true)
    bxsmenu:ShowCloseButton(false)
    bxsmenu:MakePopup()
    bxsmenu.Paint = function(self, w, h)
        draw.RoundedBoxEx(4, 170, 0, w - 170, h, Cache.Colors.Black, false, true, false, true)
        draw.RoundedBoxEx(4, 0, 0, 170, h, Cache.Colors.Navy, true, false, true, false)
        draw.RoundedBoxEx(0, 170, 55, w - 170, 2, Cache.Colors.Navy)
        draw.RoundedBoxEx(0, 168, 0, 2, h, Color(6, 25, 38))
        surface.SetFont("FT")
        draw.SimpleTextOutlined("FartClient", "FT", 24, 32, Cache.Colors.White, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(50, 91, 117, 180) )
        draw.SimpleText("Ragebot", "FT4", 14, 60, Cache.Colors.Gray, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
        draw.SimpleText("Visuals", "FT4", 14, 152, Cache.Colors.Gray, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
        draw.SimpleText("Miscellaneous", "FT4", 14, 242, Cache.Colors.Gray, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
    end

    local AimbotPanel = vgui.Create('DPanel', bxsmenu)
    AimbotPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    AimbotPanel:SetPos( 5, 65 )
    AimbotPanel.Paint = function(self, w, h)
    end
    AimbotPanel:SetVisible(activetab == 'Aimbot')

    local AntiAimPanel = vgui.Create('DPanel', bxsmenu)
    AntiAimPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    AntiAimPanel:SetPos( 5, 65 )
    AntiAimPanel.Paint = function(self, w, h)
    end
    AntiAimPanel:SetVisible(activetab == 'Anti-Aim')

    local ESPPlayerPanel = vgui.Create('DPanel', bxsmenu)
    ESPPlayerPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    ESPPlayerPanel:SetPos( 5, 65 )
    ESPPlayerPanel.Paint = function(self, w, h)
    end
    ESPPlayerPanel:SetVisible(activetab == 'Players')

    local ESPOtherPanel = vgui.Create('DPanel', bxsmenu)
    ESPOtherPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    ESPOtherPanel:SetPos( 5, 65 )
    ESPOtherPanel.Paint = function(self, w, h)
    end
    ESPOtherPanel:SetVisible(activetab == 'Other')

    local MiscMainPanel = vgui.Create('DPanel', bxsmenu)
    MiscMainPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    MiscMainPanel:SetPos( 5, 65 )
    MiscMainPanel.Paint = function(self, w, h)
    end
    MiscMainPanel:SetVisible(activetab == 'Main')

    local MiscConfigPanel = vgui.Create('DPanel', bxsmenu)
    MiscConfigPanel:SetSize( bxsmenu:GetWide() - 10, bxsmenu:GetTall() - 113 )
    MiscConfigPanel:SetPos( 5, 65 )
    MiscConfigPanel.Paint = function(self, w, h)
    end
    MiscConfigPanel:SetVisible(activetab == 'Config')

    /*
        aimbot
    */

    local AimbotTab = vgui.Create( "DButton", bxsmenu )
    AimbotTab:SetText( "" )
    AimbotTab:SetPos( 10, 72 )
    AimbotTab:SetSize( 150, 30 )
    AimbotTab.Paint = function(self, w, h)
        if activetab == 'Aimbot' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end
        draw.SimpleText("Aimbot", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    AimbotTab.DoClick = function()
        activetab = 'Aimbot'
        AimbotPanel:SetVisible(true)
        AntiAimPanel:SetVisible(false)
        ESPPlayerPanel:SetVisible(false)
        MiscMainPanel:SetVisible(false)
        MiscConfigPanel:SetVisible(false)
        ESPOtherPanel:SetVisible(false)
    end

    /*
        antiaim
    */

    local AntiAimTab = vgui.Create( "DButton", bxsmenu )
    AntiAimTab:SetText( "" )
    AntiAimTab:SetPos( 10, 104 )
    AntiAimTab:SetSize( 150, 30 )
    AntiAimTab.Paint = function(self, w, h)  
        if activetab == 'Anti-Aim' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end
        draw.SimpleText("Anti-Aim", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    AntiAimTab.DoClick = function()
        activetab = 'Anti-Aim'

        AimbotPanel:SetVisible(false)
        AntiAimPanel:SetVisible(true)
        ESPPlayerPanel:SetVisible(false)
        MiscMainPanel:SetVisible(false)
        MiscConfigPanel:SetVisible(false)
        ESPOtherPanel:SetVisible(false)
    end

    /*
        player esp
    */

    local PlayerEspTab = vgui.Create( "DButton", bxsmenu )
    PlayerEspTab:SetText( "" )
    PlayerEspTab:SetPos( 10, 164 )
    PlayerEspTab:SetSize( 150, 30 )
    PlayerEspTab.Paint = function(self, w, h)
        if activetab == 'Players' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end

        draw.SimpleText("Players", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    PlayerEspTab.DoClick = function()
        activetab = 'Players'

        AimbotPanel:SetVisible(false)
        AntiAimPanel:SetVisible(false)
        ESPPlayerPanel:SetVisible(true)
        MiscMainPanel:SetVisible(false)
        MiscConfigPanel:SetVisible(false)
        ESPOtherPanel:SetVisible(false)
    end

    /*
        other esp
    */

    local OtherEspTab = vgui.Create( "DButton", bxsmenu )
    OtherEspTab:SetText( "" )
    OtherEspTab:SetPos( 10, 196 )
    OtherEspTab:SetSize( 150, 30 )
    OtherEspTab.Paint = function(self, w, h)
        if activetab == 'Other' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end
        draw.SimpleText("Other", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    OtherEspTab.DoClick = function()
        activetab = 'Other'
        AimbotPanel:SetVisible(false)
        AntiAimPanel:SetVisible(false)
        ESPPlayerPanel:SetVisible(false)
        MiscMainPanel:SetVisible(false)
        MiscConfigPanel:SetVisible(false)
        ESPOtherPanel:SetVisible(true)
    end

    /*
        main
    */

    local MiscMainTab = vgui.Create( "DButton", bxsmenu )
    MiscMainTab:SetText( "" )
    MiscMainTab:SetPos( 10, 254 )
    MiscMainTab:SetSize( 150, 30 )
    MiscMainTab.Paint = function(self, w, h)
        if activetab == 'Main' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end
        draw.SimpleText("Main", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    MiscMainTab.DoClick = function()
        activetab = 'Main'
        AimbotPanel:SetVisible(false)
        AntiAimPanel:SetVisible(false)
        ESPPlayerPanel:SetVisible(false)
        MiscMainPanel:SetVisible(true)
        MiscConfigPanel:SetVisible(false)
        ESPOtherPanel:SetVisible(false)
    end

    local MiscConfigTab = vgui.Create( "DButton", bxsmenu )
    MiscConfigTab:SetText( "" )
    MiscConfigTab:SetPos( 10, 286 )
    MiscConfigTab:SetSize( 150, 30 )
    MiscConfigTab.Paint = function(self, w, h)
        if activetab == 'Config' then
            local menucolor = string.ToColor(config.clrs["MenuColor"])
            draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(menucolor.r, menucolor.g, menucolor.b, 30))
        end
        draw.SimpleText("Config", "FT2", 15, 15, Cache.Colors.LightWhite, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    MiscConfigTab.DoClick = function()
        activetab = 'Config'
        AimbotPanel:SetVisible(false)
        AntiAimPanel:SetVisible(false)
        ESPPlayerPanel:SetVisible(false)
        MiscMainPanel:SetVisible(false)
        MiscConfigPanel:SetVisible(true)
        ESPOtherPanel:SetVisible(false)
    end

    CreateButton("Save", "Save Config.", SaveConfig, 180, 17, bxsmenu, 70, 24)
    CreateButton("Load", "Load Config.", LoadConfig, 255, 17, bxsmenu, 70, 24)

    local usercfgs = {}
    cfgDropdown = vgui.Create("DComboBox", bxsmenu)
    cfgDropdown:SetSize(bxsmenu:GetWide() - 350, 20)
    cfgDropdown:SetPos(335, 19)

    if loadedCfg[0] != nil then
        cfgDropdown:ChooseOption(loadedCfg[0], loadedCfg[1])
    end

    for k, v in ipairs(files) do
        cfgDropdown:AddChoice(v)
    end
        
    cfgDropdown:SetSortItems(false)

    /*
        Ragebot Panels
    */

    SubPanel(AimbotPanel, "Main", 177, 5, 247, 274)
    SubPanel(AimbotPanel, "Aim", 435, 5, 247, 92)
    SubPanel(AimbotPanel, "Targets", 435, 104, 247, 153)

    Slider("FOV", 445, 37, "AimFOV", 0, 180, 0, AimbotPanel)
    CheckBox(AimbotPanel, "Enable Aimbot", 187, 37, "Aimbot" )

    ComboBox(AimbotPanel, "Hitbox", 187, 49, {"Head", "Chest", "Stomach", "COCK", "Arms", "BIG TOE"}, "AimHitbox", 101, 16)
    Binder(AimbotPanel, 187, 88, 101, 16, "AimKey" )
    CheckBox(AimbotPanel, "Silent Aim", 187, 104, "Silent" )
    CheckBox(AimbotPanel, "FireOnKey", 187, 120, "Autofire" )
    CheckBox(AimbotPanel, "Draw FOV", 187, 136, "FovCircle", true )
    CheckBox(AimbotPanel, "No Spread", 187, 152, "NoSpread" )
    CheckBox(AimbotPanel, "No Recoil", 187, 168, "NoRecoil" )
    CheckBox(AimbotPanel, "MultiPoint", 187, 184, "MultiPoint" )
    CheckBox(AimbotPanel, "AutoWall", 187, 200, "AutoWall" )
    CheckBox(AimbotPanel, "Backtrack", 187, 216, "Backtrack" ) 
    Slider("Backtrack Max Time", 187, 232, "BacktrackTime", 0, 0.2, 1, AimbotPanel)
    CheckBox(AimbotPanel, "Use Context", 187, 258, "ContextAiming" ) 

    CheckBox(AimbotPanel, "Ignore Friends", 445, 136, "IgnoreFriends" )
    CheckBox(AimbotPanel, "Ignore Teammates", 445, 152, "IgnoreTeam" )
    CheckBox(AimbotPanel, "Ignore Bots", 445, 168, "IgnoreBots" )
    CheckBox(AimbotPanel, "Ignore Buildmode", 445, 184, "IgnoreBuild" )
    CheckBox(AimbotPanel, "Ignore Godmode", 445, 200, "IgnoreGodmode" )
    CheckBox(AimbotPanel, "Ignore Protected", 445, 216, "IgnoreProtected")
    CheckBox(AimbotPanel, "Ignore HvH", 445, 232, "IgnoreHvH" )

    local function makeflist()
        flist = vgui.Create("DComboBox", AimbotPanel)
        flist:SetPos(178,285)
        flist:SetSize(120,20)

        for k,v in pairs(player.GetAll()) do
            if v ~= g_pLocalPlayer then
                if not table.HasValue(config["FriendsList"], v) then
                    local i = flist:AddChoice(v:Nick())
                end
            end
        end

        flist.OnSelect = function(index,value,data)
            flist2 = data
        end
    end

     local function makeflistc()
        flistc = vgui.Create("DComboBox", AimbotPanel)
        flistc:SetPos(303, 285)
        flistc:SetSize(120,20)

        for k,v in pairs(config["FriendsList"]) do
            if v ~= g_pLocalPlayer then
                local i = flistc:AddChoice(v:Nick())
            end
        end
        flistc.OnSelect = function(index,value,data)
            flistc2 = data
        end
    end

    makeflist()
    makeflistc()

    local function FriendAdd()
        if(flist2) then
            for k,v in pairs(player.GetAll()) do
                if (v:Nick() == flist2) then
                    config["FriendsList"][#config["FriendsList"] + 1] = v
                end
            end
        end
        makeflist()
        makeflistc()
    end

    local function FriendRemove()
        if(flistc2) then
            for k,v in pairs(config["FriendsList"]) do
                if v:Nick() == flistc2 then
                    table.RemoveByValue( config["FriendsList"], v )
                end
            end
        end

        makeflist()
        makeflistc()
    end

    CreateButton("Add Friend", "", FriendAdd, 178, 310, AimbotPanel, 120, 20)
    CreateButton("Remove Friend", "", FriendRemove, 303, 310, AimbotPanel, 120, 20)

    -- antiaim

    SubPanel(AntiAimPanel, "Main", 177, 5, 247, 272)
    SubPanel(AntiAimPanel, "Fake-Lag", 435, 5, 247, 92)

    CheckBox(AntiAimPanel, "Enable Anti-Aim", 187, 37, "AntiAim" )
    ComboBox(AntiAimPanel, "Pitch", 187, 49, {"None", "Static Up", "Static Down", "Jitter", "Front", "Zero Down"}, "AAPitch", 101, 16)
    ComboBox(AntiAimPanel, "Yaw", 187, 82, {"None", "SpinBot", "Jitter", "Backwards Jitter", "Side", "Backwards", "Statis Jitter", "Fake Forwards", "Fake Sideways", "Fake Spinbot"}, "AAYaw", 101, 16)
    Slider("Spin Speed", 187, 122, "AASpinSpeed", 0, 2000, 0, AntiAimPanel)
        
    -- fake lag

    CheckBox(AntiAimPanel, "Enable Fake-Lag", 445, 37, "FakeLag")
    Slider("Choke", 445, 60, "FLChoke", 0, 22, 2, AntiAimPanel)
    CheckBox(AntiAimPanel, "Adaptive", 445, 92, "FLAdaptive")

    /*
        ESP Panels
    */

    SubPanel(ESPPlayerPanel, "ESP", 177, 5, 247, 363)
    SubPanel(ESPPlayerPanel, "Render", 435, 5, 247, 84)
    SubPanel(ESPPlayerPanel, "Filter", 435, 96, 247, 89)
    SubPanel(ESPOtherPanel, "Render", 435, 5, 247, 84)
    SubPanel(ESPOtherPanel, "Screen", 435, 96, 247, 56)
    SubPanel(ESPOtherPanel, "ESP", 177, 5, 247, 357)

    Slider("Rainbow Speed", 187, 70, "RGBSpeed", 1, 50, 0, ESPOtherPanel)
    Slider("Max Draw Distance", 445, 55, "RenderDist", 0, 2500, 1, ESPPlayerPanel)
    Slider("Max Draw Distance", 445, 55, "EntRenderDist", 0, 2500, 1, ESPOtherPanel)

    CheckBox(ESPPlayerPanel, "Enable Visuals", 187, 37, "Visuals" )
    CheckBox(ESPPlayerPanel, "2D Box ESP", 187, 53, "Box", true )
    CheckBox(ESPPlayerPanel, "2D Box Fill", 187, 69, "BoxFilled", true)
    CheckBox(ESPPlayerPanel, "3D Box ESP", 187, 85, "3DBox", true )
    CheckBox(ESPPlayerPanel, "3D Box Fill", 187, 101, "3DBoxFill", false )
    CheckBox(ESPPlayerPanel, "Name ESP", 187, 117, "Name", true )
    CheckBox(ESPPlayerPanel, "Health Bar", 187, 133, "HealthBar" )
    CheckBox(ESPPlayerPanel, "Health ESP", 187, 149, "HealthText" )
    CheckBox(ESPPlayerPanel, "Armor Bar", 187, 165, "ArmorBar", true )
    CheckBox(ESPPlayerPanel, "Armor ESP", 187, 181, "ArmorText", true )
    CheckBox(ESPPlayerPanel, "Show Backtrack", 187, 197, "ShowBacktrack")
    CheckBox(ESPPlayerPanel, "Weapon ESP", 187, 213, "Weapon", true )
    CheckBox(ESPPlayerPanel, "Skeleton ESP", 187, 229, "Skeleton", true )
    CheckBox(ESPPlayerPanel, "Distance ESP", 187, 245, "Distance", true )
    CheckBox(ESPPlayerPanel, "Friend ESP", 187, 261, "Friend", true )
    CheckBox(ESPPlayerPanel, "Traitor ESP", 187, 277, "Traitor", true )
    CheckBox(ESPPlayerPanel, "Rank ESP", 187, 293, "Rank", true )
    CheckBox(ESPPlayerPanel, "Chams", 187, 309, "Chams", true )
    ComboBox(ESPPlayerPanel, "Chams Material", 187, 320, {"Flat", "Textured", "Wireframe"}, "ChamsMaterial", 160, 20)

    CheckBox(ESPOtherPanel, "Skybox Color", 187, 37, "RemoveSky", true, false )
    CheckBox(ESPOtherPanel, "Rainbow Skybox", 187, 53, "RGBSky", false, true )
    CheckBox(ESPOtherPanel, "World Modulation", 187, 97, "WorldModulation", true )
    CheckBox(ESPOtherPanel, "Viewmodel Changer", 187, 113, "ViewmodelChanger" )

    Slider("Viewmodel FOV", 187, 130, "ViewmodelFOV", 60, 160, 0, ESPOtherPanel)
    Slider("Viewmodel X", 187, 154, "viewmodel_x", -50, 50, 0, ESPOtherPanel)
    Slider("Viewmodel Y", 187, 178, "viewmodel_y", -30, 30, 0, ESPOtherPanel)
    Slider("Viewmodel Z", 187, 202, "viewmodel_z", -20, 20, 0, ESPOtherPanel)
    Slider("Viewmodel Pitch", 187, 226, "viewmodel_p", -90, 90, 0, ESPOtherPanel)
    Slider("Viewmodel Yaw", 187, 250, "viewmodel_ya", -90, 90, 0, ESPOtherPanel)
    Slider("Viewmodel Roll", 187, 274, "viewmodel_r", -360, 360, 0, ESPOtherPanel)

    CheckBox(ESPOtherPanel, "Remove Bob", 187, 299, "removebob" )
    CheckBox(ESPOtherPanel, "Remove Sway", 187, 315, "removesway" )
    CreateButton("Entity List", "", CreateEntityList, 187, 335, ESPOtherPanel, 120, 20)
    CheckBox(ESPPlayerPanel, "Limit ESP Distance", 445, 37, "ESPRender" )
    CheckBox(ESPOtherPanel, "Limit Entity ESP Distance", 445, 37, "EntRender" )
    CheckBox(ESPPlayerPanel, "Show Players", 445, 128, "ShowPlayers" )
    CheckBox(ESPPlayerPanel, "Show NPCs", 445, 144, "ShowNPCs" )
    CheckBox(ESPPlayerPanel, "Show Other", 445, 160, "ShowOther" )
    CheckBox(ESPOtherPanel, "Crosshair", 445, 128, "Crosshair", true )

    if entityFrameWasOpen then
        CreateEntityList()
        entityFrameWasOpen = false
    end

    /*
         Misc Panels
    */

    SubPanel(MiscMainPanel, "Other", 177, 5, 247, 321)
    CheckBox(MiscMainPanel, "Enable Misc", 187, 37, "Misc" )
    CheckBox(MiscMainPanel, "Bhop", 187, 53, "Bhop" )
    CheckBox(MiscMainPanel, "Autostrafe", 187, 69, "Autostrafe" )
    CheckBox(MiscMainPanel, "Spectators List", 187, 85, "SpectatorsList" )
    CheckBox(MiscMainPanel, "Admins List", 187, 101, "AdminsList" )
    CheckBox(MiscMainPanel, "Freecam", 187, 117, "Freecam" )
    Binder(MiscMainPanel, 187, 135, 100, 16, "Freecam_key" )
    CheckBox(MiscMainPanel, "Thirdperson", 187, 151, "Thirdperson" )
    Binder(MiscMainPanel, 187, 170, 100, 16, "Thirdperson_key" )
    Slider("Thirdperson Dist", 187, 187, "TPDistance", 20, 300, 0, MiscMainPanel)
    CheckBox(MiscMainPanel, "Auto Pistol", 187, 214, "RapidFire" )
    CheckBox(MiscMainPanel, "Chat Spam", 187, 230, "ChatSpam" )
    CheckBox(MiscMainPanel, "Hitsound", 187, 246, "Hitsound" )
    CheckBox(MiscMainPanel, "Menu Color", 187, 262, "MenuColor", true)
    CreateLabel("Menu Key:", 188, 281, MiscMainPanel)
    Binder(MiscMainPanel, 247, 281, 55, 16, "menu_key" )
    CreateButton("Unload Cheat", "", hookdel, 187, 299, MiscMainPanel, 115, 20)
    CreateButton("Create Config", "Create Config.", CreateConfig, 175, 22, MiscConfigPanel, bxsmenu:GetWide() - 190, 20)
    CreateButton("Delete Config", "Delete Config.", DeleteConfig, 175, 44, MiscConfigPanel, bxsmenu:GetWide() - 190, 20)
    CreateTextInput("Config Name", "config_name", 175, 0, 16, MiscConfigPanel, bxsmenu:GetWide() - 190)
end

ToggleMenu()

AddHook("Think", function()
    if config["Misc"] and config["ChatSpam"] then
        RunConsoleCommand("say", chatspammer[math.random(0, table.Count( chatspammer ) - 1)] )
    end
    if(!ss) then 
        if config["WorldModulation"] and config["Visuals"] then
            DisableWorldModulation()
        end
        LastFrameSS = true
    end
    if LastFrameSS then
        if config["WorldModulation"] and config["Visuals"] then
            UpdateWorldModulation()
        end
        LastFrameSS = false
    end
    if(!config["WorldModulation"] or !config["Visuals"] )then
        DisableWorldModulation()
    end
    if config.binds["menu_key"] != 0 and input.IsKeyDown(config.binds["menu_key"]) and !insertdown and !config["menu_key"] then
        if entityFrame then
            entityFrameX, entityFrameY = entityFrame:GetPos()
            entityFrame:Remove()
            entityFrameWasOpen = true
            entityFrame = false
        end
        if colorWindow then
            colorWindow:Remove()
            colorWindow = false
        end
        if bxsmenu then
            CloseFrame()
        else
            ToggleMenu()
            RestoreCursorPosition()
            RefreshFriends()
        end
    end
    insertdown = input.IsKeyDown(config.binds["menu_key"])
end)

local function CollectFreeCamInfo(Command)
    if(freecamEnabled && config["Freecam"] && config["Misc"]) then
        Command:SetSideMove(0)
        Command:SetForwardMove(0)
        Command:SetViewAngles(freecamAngles2)
        Command:RemoveKey(IN_JUMP)
        Command:RemoveKey(IN_DUCK)
            
        freecamAngles = (freecamAngles + Angle(Command:GetMouseY() * .023, Command:GetMouseX() * -.023, 0))
        freecamAngles.p, freecamAngles.y, freecamAngles.x = math.Clamp(freecamAngles.p, -89, 89), math.NormalizeAngle(freecamAngles.y), math.NormalizeAngle(freecamAngles.x);
    
         local curFreecamSpeed = freecamSpeed
        if(input.IsKeyDown(KEY_LSHIFT)) then
            curFreecamSpeed = freecamSpeed * 2
        end
    
        if(input.IsKeyDown(KEY_W)) then
            freecamPos = freecamPos + (freecamAngles:Forward() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_S)) then
            freecamPos = freecamPos - (freecamAngles:Forward() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_A)) then
            freecamPos = freecamPos - (freecamAngles:Right() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_D)) then
            freecamPos = freecamPos + (freecamAngles:Right() * curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_SPACE)) then
            freecamPos = freecamPos + Vector(0,0,curFreecamSpeed)
        end
        if(input.IsKeyDown(KEY_LCONTROL)) then
            freecamPos = freecamPos - Vector(0,0,curFreecamSpeed)
        end
    end
end

/*
    Autowall
*/

local function GetConVarBoolSafe(ConVar)
    if not ConVar then return false end
    return ConVar:GetBool()
end

local function GetWeaponBase(Weapon)
    if not Weapon.Base then return "" end
    return Weapon.Base:lower():Split("_")[1]
end

local function WeaponIsBase(Weapon, Base)
    return GetWeaponBase(Weapon) == Base
end

local function GetWeaponAmmoName(Weapon)
    if Weapon.Primary and Weapon.Primary.Ammo then
        return Weapon.Primary.Ammo:lower()
    else
        return tostring(game.GetAmmoName(Weapon:GetPrimaryAmmoType())):lower()
    end
end

-- Shorthand for CW based weapons and similar
local function CWCanPenetrate(Weapon, TraceData)
    if Cache.AmmoPen.Materials.NoPenetration[TraceData.MatType] or (Weapon.CanPenetrate ~= nil and not Weapon.CanPenetrate) then
        return false
    end

    local Entity = TraceData.Entity
    if IsValid(Entity) and (Entity:IsPlayer() or Entity:IsNPC()) then
        return false
    end

    return -TraceData.Normal:Dot(TraceData.HitNormal) > 0.26
end

local function GetWeaponMaxPenetration(Weapon, TraceData) -- It'd be nicer to make a function table indexed by bases but meh
    if WeaponIsBase(Weapon, "bobs") then
        if GetConVarBoolSafe(Cache.ConVars.Penetration.M9K) then
            return nil
        end

        -- Ricocheting is random :(

        local DataTable = Cache.AmmoPen.Max[GetWeaponAmmoName(Weapon)]
        if not DataTable then return nil end

        return DataTable[1], DataTable[2]
    end

    -- TFA is off by a small fraction, the numbers are weird plus there's some other logic that isn't being accounted for
    if WeaponIsBase(Weapon, "tfa") then
        if not GetConVarBoolSafe(Cache.ConVars.Penetration.TFA) then
            return nil
        end

        local ForceMultiplier = Weapon:GetAmmoForceMultiplier()
        local PenetrationMultiplier = Weapon:GetPenetrationMultiplier(TraceData.MatType)
        local Multiplier = Cache.ConVars.Penetration.TFA_Multiplier:GetFloat()

        local DataTable = Cache.AmmoPen.Max[GetWeaponAmmoName(Weapon)]
        local MaxPen = math.Clamp(DataTable and DataTable[2] or 1, 0, Cache.ConVars.Penetration.TFA_HardLimit:GetInt())

        return math.Truncate(((ForceMultiplier / PenetrationMultiplier) * Multiplier) * 0.9, 5), MaxPen
    end

    -- Haven't quite worked out the penetration logic with these weapons yet
    -- There's more to them than just distance, so some further logic will need implemented at some point
    if WeaponIsBase(Weapon, "arccw") then
        if not GetConVarBoolSafe(Cache.ConVars.Penetration.ArcCW) then
            return nil
        end

        local DataTable = Cache.AmmoPen.Max[GetWeaponAmmoName(Weapon)]
        return math.pow(Weapon.Penetration, 2), DataTable and DataTable[2] or 1 -- Weapon.Penetration seems to be a 'legacy' thing, a new calculation will need to be made (Unless I just looked in the wrong file)
    end

    -- CW and FA:S also have retarded ammo names, so even though that logic may be better I don't feel like constructing that right now
    if not CWCanPenetrate(Weapon, TraceData) then return nil end

    if WeaponIsBase(Weapon, "cw") then
        local Strength = Weapon.PenStr * Weapon.PenMod
        local Multiplier = Weapon.PenetrationMaterialInteraction and Weapon.PenetrationMaterialInteraction[TraceData.MatType] or 1
        return math.pow(Strength, 2) + (Strength * Multiplier), 1
    end

    if WeaponIsBase(Weapon, "fas2") then
        local Strength = Weapon.PenStr * Weapon.PenMod
        local Multiplier = Cache.AmmoPen.Materials.Multipliers[TraceData.MatType] or 1
        return math.pow(Strength, 2) + (Strength * Multiplier), 1
    end

    if WeaponIsBase(Weapon, "swb") then
        local DataTable = Cache.AmmoPen.Max[GetWeaponAmmoName(Weapon)]
        if not DataTable then return nil end

        local Multiplier = Cache.AmmoPen.Materials.Multipliers[TraceData.MatType] or 1
        return DataTable[1] * Multiplier * Weapon.PenMod, 1
    end

    return nil
end

local function WeaponCanPenetrate(Weapon, TraceData, Target, TargetPos)
    local MaxDistance, MaxTimes = GetWeaponMaxPenetration(Weapon, TraceData)
    if not MaxDistance then return false end

    local tr = {}
    local Trace = {
        start = TargetPos,
        endpos = TraceData.HitPos,
        filter = {Target},
        mask = MASK_SHOT,
        output = tr -- Optimization woo
    }

    util.TraceLine(Trace)

    if not Weapon:IsScripted() then -- Engine weapons can't penetrate anything
        return TraceData.Entity == Target
    end

    local CurTimes = 1
    local LastPos = tr.HitPos

    local World = game.GetWorld()
    local IsTFA = WeaponIsBase(Weapon, "tfa")

    if IsTFA then
        MaxDistance = MaxDistance / 2
    end

    while CurTimes <= MaxTimes do
        if tr.Entity ~= World then
            if tr.Entity == Target then break end -- Success!

            local Entity = tr.Entity

            Trace.start = LastPos

            util.TraceLine(Trace)

            Trace.start = tr.HitPos - TraceData.Normal
            Trace.endpos = LastPos
            Trace.filter[2] = Entity

            util.TraceLine(Trace)
        else
            local OriginalEndPos = Trace.endpos

            for i = 1, 75 do -- Trace out until not inside the wall (FractionLeftSolid would work well if there was a known endpos, but there is no such thing unfortunately)
                Trace.start = tr.HitPos - (TraceData.Normal * 10) -- Multiplier to speed this up tremendously
                Trace.endpos = Trace.start
                util.TraceLine(Trace)

                if not tr.HitWorld then break end
            end

            Trace.endpos = OriginalEndPos
        end

        local ThisDistance

        if IsTFA then -- TFA is retarded
            ThisDistance = tr.HitPos:Distance(LastPos) / 88.88
        else
            ThisDistance = math.floor(tr.HitPos:DistToSqr(LastPos))
        end

        if ThisDistance > MaxDistance then -- This penetration step went too far
            return false
        end

        if tr.Hit then -- Initial hit success
            LastPos = tr.HitPos
        else -- Perform a second trace going the other way to see if there's any further tracing needed
            local OriginalEndPos = TraceData.HitPos

            Trace.endpos = TraceData.HitPos
            util.TraceLine(Trace)
            Trace.endpos = OriginalEndPos

            if tr.Hit then
                LastPos = tr.HitPos
            else -- At the end or in some kind of empty space
                if IsTFA then
                    ThisDistance = tr.HitPos:Distance(LastPos) / 88.88
                else
                    ThisDistance = math.floor(tr.HitPos:DistToSqr(LastPos))
                end

                if ThisDistance <= MaxDistance then -- This penetration is good
                    break
                end
            end
        end

        CurTimes = CurTimes + 1
    end

    if CurTimes <= MaxTimes then
        return true
    end

    return false
end

local function IsVisible(Position, Entity)
    Cache.TraceData.start = g_pLocalPlayer:EyePos()
    Cache.TraceData.endpos = Position
    Cache.TraceData.filter = g_pLocalPlayer
    Cache.TraceData.mask = MASK_SHOT
    Cache.TraceData.output = Cache.TraceOutput
        
    util.TraceLine(Cache.TraceData)

    if Cache.TraceOutput.Entity == Entity then
        return true, 0, Cache.TraceOutput.Fraction
    elseif config["AutoWall"]  then
        local Weapon = g_pLocalPlayer:GetActiveWeapon()
        if not IsValid(Weapon) then
            return false, 0, Cache.TraceOutput.Fraction
        end

        local Hit, Penetrations = WeaponCanPenetrate(Weapon, Cache.TraceOutput, Entity, Position)
        Hit = Hit or false
        Penetrations = Penetrations or 0

        return Hit, Penetrations, Cache.TraceOutput.Fraction
    else
        return false, 0, Cache.TraceOutput.Fraction
    end
end

local function FixAngle(Angle)
    Angle.pitch = math.Clamp(math.NormalizeAngle(Angle.pitch), -89, 89)
    Angle.yaw = math.NormalizeAngle(Angle.yaw)
    Angle.roll = math.NormalizeAngle(Angle.roll)
end

local function FixMovement(Command)
    local CommandViewAngles = Command:GetViewAngles()

    local MoveVector = Vector(Command:GetForwardMove(), Command:GetSideMove(), 0)
    local Yaw = math.rad(CommandViewAngles.yaw - Cache.FacingAngle.yaw + MoveVector:Angle().yaw)
    local Speed = MoveVector:Length2D()

    Command:SetForwardMove(math.cos(Yaw) * Speed)
    Command:SetSideMove(math.sin(Yaw) * Speed)
end

local function GetLerpTime()
    if not Cache.ConVars.cl_interpolate:GetBool() then
        return 0
    end

    if Cache.ConVars.sv_minupdaterate and Cache.ConVars.sv_maxupdaterate then
        Cache.ConVars.cl_updaterate = Cache.ConVars.sv_maxupdaterate:GetInt()
    end

    local ratio = Cache.ConVars.cl_interp_ratio:GetFloat()
    if ratio == 0 then
        ratio = 1
    end

    local lerp = Cache.ConVars.cl_interp:GetFloat()
    if Cache.ConVars.sv_client_max_interp_ratio and Cache.ConVars.sv_client_max_interp_ratio and Cache.ConVars.sv_client_min_interp_ratio:GetFloat() ~= 1 then
        ratio = math.Clamp(ratio, Cache.ConVars.sv_client_min_interp_ratio:GetFloat(), Cache.ConVars.sv_client_max_interp_ratio:GetFloat())
    end

    return math.max(lerp, ratio / Cache.ConVars.cl_updaterate)
end

local function GetWeaponBase(Weapon)
    if not Weapon.Base then return "" end
    return string.Split(string.lower(Weapon.Base), "_")[1]
end

local function TickToTime(Tick)
    return Cache.TickInterval * Tick
end

local function TimeToTick(Time)
    return math.floor(0.5 + (Time / Cache.TickInterval)) + math.min(GetLerpTime(), Cache.ConVars.sv_maxunlag:GetInt())
end

local function GetServerTime()
    return TickToTime(g_pLocalPlayer:GetInternalVariable("m_nTickBase"))
end

local function GetEntitySimulationTime(Entity)
    return proxi.__Ent_GetNetVar(Entity, "DT_BaseEntity->m_flSimulationTime", 1)
end

local function IsTickValid(flTime)
    local correct = 0
    local lerpticks = TimeToTick(GetLerpTime())

    correct = correct + proxi.GetFlowIncoming() + proxi.GetFlowOutgoing()
    correct = correct + TickToTime(lerpticks)
    correct = math.Clamp(correct, 0, 1)

    local targettick = TimeToTick(flTime) -- lerpticks
    local servertick = g_pLocalPlayer:GetInternalVariable("m_nTickBase")
    local deltatime = correct - TickToTime(servertick - targettick)

    return math.abs(deltatime) < 0.2, deltatime
end

local function CanShoot()
    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if not Weapon then return false end

    local WeaponName = string.lower(Weapon.PrintName or Weapon:GetPrintName())

    for i = 1, #Cache.WeaponData.AutoShoot.Classes.Blacklist do
        if string.find(WeaponName, Cache.WeaponData.AutoShoot.Classes.Blacklist[i]) then
            local BreakOuter = false

            for i = 1, #Cache.WeaponData.AutoShoot.Classes.Whitelist do
                if string.find(WeaponName, Cache.WeaponData.AutoShoot.Classes.Whitelist[i]) then
                    BreakOuter = true
                    break
                end
            end

            if BreakOuter then continue end

            return false
        end
    end

    local Base = GetWeaponBase(Weapon)
    local BaseCheck = Cache.WeaponData.AutoShoot.BaseFunctions[Base] and Cache.WeaponData.AutoShoot.BaseFunctions[Base](Weapon) or true

    return GetServerTime() >= Weapon:GetNextPrimaryFire() and BaseCheck
end

function RapidFire(Command)
    if not config["RapidFire"] or not config["Misc"] then return end
    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if not IsValid(Weapon) then return end

    if (Weapon.Primary and not Weapon.Primary.Automatic) or Weapon:GetClass() == "weapon_pistol" or Weapon:GetClass() == "weapon_pistolr" then
        if Command:KeyDown(IN_ATTACK) and not CanShoot() then
            Command:RemoveKey(IN_ATTACK)
        end
    end
end

local function CalculateViewPunch(Weapon)
    if Weapon:GetClass() == "weapon_pistol" then
        return angle_zero
    end

    if Weapon:IsScripted() then
        if GetWeaponBase(Weapon) ~= "cw" and GetWeaponBase(Weapon) ~= "fas2" then
            return angle_zero
        end
    end

    return g_pLocalPlayer:GetViewPunchAngles()
end

function VectorTransform(vecIn, matrixIn, vecOut)
    if not matrixIn then return vecIn end

    local vecRet = Vector()

    local one = Vector(matrixIn:GetField(1, 1), matrixIn:GetField(1, 2), matrixIn:GetField(1, 3))
    local two = Vector(matrixIn:GetField(2, 1), matrixIn:GetField(2, 2), matrixIn:GetField(2, 3))
    local three = Vector(matrixIn:GetField(3, 1), matrixIn:GetField(3, 2), matrixIn:GetField(3, 3))

    vecRet.x = vecIn:Dot(one) + matrixIn:GetField(1, 4)
    vecRet.y = vecIn:Dot(two) + matrixIn:GetField(2, 4)
    vecRet.z = vecIn:Dot(three) + matrixIn:GetField(3, 4)

    if vecOut then
        vecOut:Set(vecRet)
        return
    end

    return vecRet
end

local function GenerateMultiPoint(Position, Angle, Mins, Maxs)
    -- Inset points by a unit to avoid misses
    local pMins = Vector(Mins.x + 1, Mins.y + 1, Mins.z + 1)
    local pMaxs = Vector(Maxs.x - 1, Maxs.y - 1, Maxs.z - 1)

    -- Auto-generation isn't needed here, it's just the 8 corners
    local Data = {
        pMins,
        pMaxs,
        Vector(pMins.x, pMins.y, pMaxs.z),
        Vector(pMaxs.x, pMins.y, pMaxs.z),
        Vector(pMaxs.x, pMaxs.y, pMins.z),
        Vector(pMaxs.x, pMins.y, pMins.z),
        Vector(pMins.x, pMaxs.y, pMins.z),
        Vector(pMins.x, pMaxs.y, pMaxs.z)
    }

    for i = 1, #Data do
        Data[i]:Rotate(Angle) -- Correct for hitbox rotation
        Data[i]:Add(Position) -- Move them into worldspace
    end

    return Data
end

local function GetFOVRadius(Radius)
    if not Cache.ViewData.Origin then
        return 0 
    end

    Radius = Radius or config["AimFOV"]

    local Ratio = Cache.ScreenData.Width / Cache.ScreenData.Height
    local AimFOV = Radius * (math.pi / 180)
    local GameFOV = Cache.ViewData.FOV * (math.pi / 180)
    local ViewFOV = 2 * math.atan(Ratio * (Cache.ViewData.ZNear / 2) * math.tan(GameFOV / 2))

    return (math.tan(AimFOV) / math.tan(ViewFOV / 2)) * Cache.ScreenData.Width
end

local function DistanceFromCrosshair(Position)
    if not Position then
        return 360, false
    end

    local ScreenPosition = Position:ToScreen()
    local Radius = GetFOVRadius()

    if ScreenPosition.visible and Radius >= 0 then
        return math.Distance(Cache.ScreenData.Center.X, Cache.ScreenData.Center.Y, ScreenPosition.x, ScreenPosition.y), true
    else
        local Forward = Cache.ViewData.Angles:Forward()
        local Direction = (Position - Cache.ViewData.Origin):GetNormalized()
        local Degree = math.deg(math.acos(Forward:Dot(Direction)))

        return math.abs(Degree), false
    end
end

local function InFOV(Position)
    local Distance, WasW2S = DistanceFromCrosshair(Position)

    if WasW2S then
        local Radius = GetFOVRadius()
        if Radius < 0 then return true end

        return Distance <= Radius, Distance
    else
        return Distance <= config["AimFOV"], Distance
    end
end

local function PredictTargetPosition(Position, Entity, Ping)
    if not Cache.ConVars.cl_interpolate:GetBool() then return end

    local Velocity = Entity:GetAbsVelocity()
    if Velocity:IsZero() then return end

    Velocity:Mul(Cache.TickInterval * Ping)
    Position:Add(Velocity)
end

local function UpdateCalcViewData(Data)
    if not Data then return end

    Cache.ViewData.Origin = Data.origin
    Cache.ViewData.Angles = Data.angles
    Cache.ViewData.FOV = Data.fov
    Cache.ViewData.ZNear = Data.znear
    Cache.ViewData.ZFar = Data.zfar
end

/*
    Nospread
*/

do
    local CUniformRandomStream = {
        Meta = {}
    }

    CUniformRandomStream.Meta.__index = CUniformRandomStream.Meta
        
    local NTAB = 32
        
    local IA = 16807
    local IM = 2147483647
    local IQ = 127773
    local IR = 2836
    local NDIV = 1 + (IM - 1) / NTAB
    local MAX_RANDOM_RANGE = 0x7FFFFFFF
        
    local AM = 1 / IM
    local EPS = 1.2e-7
    local RNMX = 1 - EPS
        
    -- Set the generation seed
    function CUniformRandomStream.Meta:SetSeed(Seed)
        self.m_idum = Seed < 0 and Seed or -Seed
        self.m_iy = 0
    end
        
    -- Generate a random integer
    function CUniformRandomStream.Meta:GenerateRandomNumber()
        local math_floor = math.floor
        local j, k = 0, 0
        
        if self.m_idum <= 0 or not self.m_iy then
            self.m_idum = -self.m_idum
        
            if self.m_idum < 1 then
                self.m_idum = 1
            end
        
            j = NTAB + 8
            while j > 0 do
                j = j - 1
        
                k = math_floor(self.m_idum / IQ)
                self.m_idum = math_floor(IA * (self.m_idum - k * IQ) - IR * k)
        
                if self.m_idum < 0 then
                    self.m_idum = math_floor(self.m_idum + IM)
                end
        
                if j < NTAB then
                    self.m_iv[j] = math_floor(self.m_idum)
                end
            end
        
            self.m_iy = self.m_iv[0]
        end
        
        k = math_floor(self.m_idum / IQ)
        self.m_idum = math_floor(IA * (self.m_idum - k * IQ) - IR * k)
        
        if self.m_idum < 0 then
            self.m_idum = math_floor(self.m_idum + IM)
        end
        
        j = math_floor(self.m_iy / NDIV)
        
        if j >= NTAB or j < 0 then
            ErrorNoHalt(string.format("CUniformRandomStream array overrun; Tried to write %d", j))
            j = math_floor(bit.band(j % NTAB, MAX_RANDOM_RANGE))
        end
        
        self.m_iy = math_floor(self.m_iv[j])
        self.m_iv[j] = math_floor(self.m_idum)
        
        return self.m_iy
    end

    function CUniformRandomStream.Meta:RandomFloat(Min, Max)
        Min = Min or 0
        Max = Max or 1
        
        local Float = AM * self:GenerateRandomNumber()
        
        if Float > RNMX then
            Float = RNMX
        end
        
        return (Float * (Max - Min)) + Min
    end
        
    -- Create a new CUniformRandomStream object
    function CUniformRandomStream.New()
        local RandomStream = setmetatable({}, CUniformRandomStream.Meta)
        RandomStream.m_iv = {}
        
        RandomStream:SetSeed(0)
        
        return RandomStream
    end

    -- then lets create those nospread seeds :)

    local RandomStream = CUniformRandomStream.New()

    local ShotBiasMin = Cache.ConVars.ai_shot_bias_min:GetFloat()
    local ShotBiasMax = Cache.ConVars.ai_shot_bias_max:GetFloat()
    local ShotBiasDif = (ShotBiasMax - ShotBiasMin) + ShotBiasMin

    local Flatness = math.abs(ShotBiasDif) / 2
    local iFlatness = 1 - Flatness

    for Seed = 0, 255 do
        RandomStream:SetSeed(Seed)

        local FirstRan = false
        local X, Y, Z = 0, 0, 0

        while true do
            if Z <= 1 and FirstRan then break end

            X = (RandomStream:RandomFloat(-1, 1) * Flatness) + (RandomStream:RandomFloat(-1, 1) * iFlatness)
            Y = (RandomStream:RandomFloat(-1, 1) * Flatness) + (RandomStream:RandomFloat(-1, 1) * iFlatness)
                    
            if ShotBiasDif < 0 then
                X = X >= 0 and 1 - X or -1 - X
                Y = Y >= 0 and 1 - Y or -1 - Y
            end

            Z = (X * X) + (Y * Y)
            FirstRan = true
        end

        Cache.WeaponData.Nospread.Seeds[Seed] = {
            X = X,
            Y = Y,
            Z = Z
        }
    end

    local function fsel(c, x, y)
        return c >= 0 and x or y
    end

    function RemapValClamped(val,a,b,c,d)
        if a == b then
            return fsel(val - b, d, c)
        end
        
        local cVal = (val - a) / (b - a)
        cVal = math.Clamp(cVal, 0, 1)
        return c + (d - c) * cVal
    end
    
    local VectorLerp = LerpVector
    local VECTOR_CONE_1DEGREES    = Vector( 0.00873, 0.00873, 0.00873 )
    local VECTOR_CONE_2DEGREES    = Vector( 0.01745, 0.01745, 0.01745 )
    local VECTOR_CONE_3DEGREES    = Vector( 0.02618, 0.02618, 0.02618 )
    local VECTOR_CONE_4DEGREES    = Vector( 0.03490, 0.03490, 0.03490 )
    local VECTOR_CONE_5DEGREES    = Vector( 0.04362, 0.04362, 0.04362 )
    local VECTOR_CONE_6DEGREES    = Vector( 0.05234, 0.05234, 0.05234 )
    local VECTOR_CONE_7DEGREES    = Vector( 0.06105, 0.06105, 0.06105 )
    local VECTOR_CONE_8DEGREES    = Vector( 0.06976, 0.06976, 0.06976 )
    local VECTOR_CONE_9DEGREES    = Vector( 0.07846, 0.07846, 0.07846 )
    local VECTOR_CONE_10DEGREES   = Vector( 0.08716, 0.08716, 0.08716 )
    local VECTOR_CONE_15DEGREES   = Vector( 0.13053, 0.13053, 0.13053 )
    local VECTOR_CONE_20DEGREES   = Vector( 0.17365, 0.17365, 0.17365 )
        
    Cache.WeaponData.Nospread.Cones = {
        weapon_smg1 = VECTOR_CONE_5DEGREES,
        weapon_ar2 = VECTOR_CONE_3DEGREES,
        weapon_357 = vector_origin,
        weapon_pistol = function(wep)
            local nv = wep:GetInternalVariable("m_flAccuracyPenalty")
            local ramp = RemapValClamped(nv, 0, 1.5, 0, 1)
            local cone = VectorLerp(ramp, VECTOR_CONE_1DEGREES, VECTOR_CONE_6DEGREES)
        
            return cone
        end,
        weapon_shotgun = VECTOR_CONE_10DEGREES,
        
        -- hl1 weapons
        weapon_357_hl1 = VECTOR_CONE_1DEGREES,
        weapon_mp5_hl1 = VECTOR_CONE_3DEGREES,
        weapon_gauss = vector_origin,
        weapon_glock_hl1 = function(wep)
            if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
                return Vector(0.1, 0.1, 0.1)
            end
        
            return Vector(0.01, 0.01, 0.01)
        end,
        weapon_shotgun_hl1 = function(wep)
            if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
                return Vector(VECTOR_CONE_10DEGREES.x * 2, VECTOR_CONE_10DEGREES.x / 2)
            end
    
            return Vector(VECTOR_CONE_10DEGREES.x, VECTOR_CONE_10DEGREES.x / 2)
        end
    }
end

local NospreadFunctions = {
    bobs = function(Weapon, Command, WeaponCone) -- Bob is a simple man
		if Weapon:GetNWBool("M9K_Ironsights") or Command:KeyDown(IN_ATTACK2) then -- GetIronsights causes problems on some servers (Fuck you LBG) so do it manually
			WeaponCone.x = Weapon.Primary.IronAccuracy
			WeaponCone.y = Weapon.Primary.IronAccuracy
		else
			WeaponCone.x = Weapon.Primary.Spread
			WeaponCone.y = Weapon.Primary.Spread
		end

		return false
	end,

    tfa = function(Weapon, _, WeaponCone, ForwardAngle)
        local Cone, Recoil = Weapon:CalculateConeRecoil()

        local Yaw, Pitch = Weapon:ComputeBulletDeviation(1, 1, Cone)

        local WeaponAngle = Angle(ForwardAngle)
        local BulletAngle = Angle(WeaponAngle)

        if sv_tfa_recoil_legacy:GetBool() then
            WeaponAngle:Add(g_pLocalPlayer:GetViewPunchAngles())
        elseif Weapon:HasRecoilLUT() then
            WeaponAngle:Add(Weapon:GetRecoilLUTAngle())
        else
            local PitchPunch = Weapon:GetViewPunchP()
            local YawPunch = Weapon:GetViewPunchY()

            PitchPunch = PitchPunch - PitchPunch * Cache.TickInterval
            YawPunch = YawPunch - YawPunch * Cache.TickInterval

            WeaponAngle.pitch = WeaponAngle.pitch + PitchPunch
            WeaponAngle.yaw = WeaponAngle.yaw + YawPunch
        end

        WeaponAngle:Normalize()

        local Up = BulletAngle:Up()
        local Right = BulletAngle:Right()

        BulletAngle:RotateAroundAxis(Up, Yaw)
        BulletAngle:RotateAroundAxis(Right, Pitch)

        local Difference = WeaponAngle - BulletAngle

        ForwardAngle:Sub(Difference)

        return true
    end,

    cw = function(Weapon, Command, _, ForwardAngle)
        local Cone = Weapon.CurCone

        math.randomseed(Command:CommandNumber())
        ForwardAngle:Add(Angle(-math.Rand(-Cone, Cone), -math.Rand(-Cone, Cone), 0) * 25)

        return true
    end
}

local function CalculateNospread(Weapon, Command, ForwardAngle)
    if Weapon:GetClass() == "weapon_pistol" then
        Command:SetRandomSeed(33)
        return
    end

    local WeaponCone = Cache.WeaponData.Nospread.Cones[Weapon:GetClass()]
    if not WeaponCone then return end

    if type(WeaponCone) == "function" then
        WeaponCone = WeaponCone(Weapon, Command)
    end

    if NospreadFunctions[GetWeaponBase(Weapon)] and NospreadFunctions[GetWeaponBase(Weapon)](Weapon, Command, WeaponCone, ForwardAngle) then
        return
    end

    local Seed = Command:GetRandomSeed()

    local X = Cache.WeaponData.Nospread.Seeds[Seed].X
    local Y = Cache.WeaponData.Nospread.Seeds[Seed].Y

    local Forward = ForwardAngle:Forward()
    local Right = ForwardAngle:Right()
    local Up = ForwardAngle:Up()

    local SpreadVector = Forward + (X * WeaponCone.x * Right * -1) + (Y * WeaponCone.y * Up * -1)
    ForwardAngle:Set(SpreadVector:Angle())
end

local LBacktrack = {
    Records = {}
}

/*
    Ragebot
*/

local LRagebot = {}

function LRagebot:ShouldRun()
    if not config["Aimbot"] then return false end
    if g_pLocalPlayer:GetNWInt("SH_SZ.Safe") ~= 0 then return false end

    return true
end

function LRagebot:GetEntityHitboxes(Entity)
    local ShouldMultiPoint = config["MultiPoint"]

    local Data = {
        [HITGROUP_HEAD] = {},
        [HITGROUP_CHEST] = {},
        [HITGROUP_STOMACH] = {}
    }

    Entity:SetupBones()

    local iHitBoxSet = Entity:GetHitboxSet()
    for iHitBox = 0, Entity:GetHitBoxCount(iHitBoxSet) - 1 do
        local iHitGroup = Entity:GetHitBoxHitGroup(iHitBox, iHitBoxSet)
        if not iHitGroup or not Data[iHitGroup] then continue end

        if config["AimHitbox"] == 1 and iHitGroup ~= HITGROUP_HEAD then continue end
        if config["AimHitbox"] == 2 and iHitGroup ~= HITGROUP_CHEST then continue end
        if config["AimHitbox"] == 3 and iHitGroup ~= HITGROUP_STOMACH then continue end
        if config["AimHitbox"] == 5 and (iHitgroup ~= HITGROUP_LEFTARM or iHitgroup ~= HITGROUP_RIGHTARM) then continue end
            
        local FindMatrix
        if config["AimHitbox"] == 4 then 
            FindMatrix = Entity:LookupBone("ValveBiped.Bip01_Pelvis")
        elseif config["AimHitbox"] == 6 then 
            FindMatrix = Entity:LookupBone("ValveBiped.Bip01_L_Toe0") 
        else
            FindMatrix = Entity:GetHitBoxBone(iHitBox, iHitBoxSet)
        end

        local Matrix = Entity:GetBoneMatrix(FindMatrix)
        if not Matrix then continue end

        local Position, Angle = Matrix:GetTranslation(), Matrix:GetAngles()
        local Mins, Maxs = Entity:GetHitBoxBounds(iHitBox, iHitBoxSet)

        local vOutMin, vOutMax = Vector(), Vector()

        VectorTransform(Mins, Matrix, vOutMin)
        VectorTransform(Maxs, Matrix, vOutMax)

        local Center = Vector(vOutMin)
        Center:Add(vOutMax)
        Center:Mul(0.5)

        Data[iHitGroup][#Data[iHitGroup] + 1] = Center --Position + Center

        if ShouldMultiPoint then
            local MultiPointData = GenerateMultiPoint(Position, Angle, Mins, Maxs)

            for mi = 1, #MultiPointData do
                debugoverlay.Cross(MultiPointData[mi], 3, 0.1, Color(255,0,0), true)
                Data[iHitGroup][#Data[iHitGroup] + 1] = MultiPointData[mi]
            end
        end
    end

    return Data
end

function LRagebot:IsViableTarget(Player)
    if Player == g_pLocalPlayer or not Player:Alive() or Player:IsDormant() then return false end -- Never target these
    if Player:Team() == TEAM_SPECTATOR or Player:GetObserverMode() ~= OBS_MODE_NONE then return false end

    if config["IgnoreFriends"] then
        if Player:GetFriendStatus() == "friend" or IsFriend(v) then
            return false
        end
    end

    -- Net stuff
    if config["IgnoreBuild"] then
        for i = 1, #Cache.NetMessages.Buildmode do
            if tobool(Player:GetNWBool(Cache.NetMessages.Buildmode[i])) then
                return false
            end
        end
    end

    if config["IgnoreProtected"]then
        for i = 1, #Cache.NetMessages.Protected do
            if tobool(Player:GetNWBool(Cache.NetMessages.Protected[i])) then
                return false
            end
        end
    end
        
    if config["IgnoreHvH"] then
        local LocalHVH = false
        local PlayerHVH = false

        for i = 1, #Cache.NetMessages.HVH do
            if LocalHVH and PlayerHVH then break end

            LocalHVH = tobool(g_pLocalPlayer:GetNWBool(Cache.NetMessages.HVH[i], false))
            PlayerHVH = tobool(Player:GetNWBool(Cache.NetMessages.HVH[i], false))
        end

        if LocalHVH ~= PlayerHVH then return false end
    end

    if config["IgnoreGodmode"] then
        if Player:HasGodMode() then return false end

        for i = 1, #Cache.NetMessages.God do
            if tobool(Player:GetNWBool(Cache.NetMessages.God[i])) then
                return false
            end
        end
    end

    return true
end

function LRagebot:GetTarget() -- Got a little janky during construction, needs some cleanup
    local BestDistance = math.huge
    local BestHitboxes = nil
    local BestPlayer = NULL
    local BestPenetrations = 0

    local ShouldBacktrack = config["Backtrack"]

    for i = 1, #Cache.Players do
        local Player = Cache.Players[i]

        if not IsValid(Player) then continue end
        if not self:IsViableTarget(Player) then continue end
            
        local WorldSpaceCenter = Player:WorldSpaceCenter()

        local CurrentDistance = math.huge
        local CurrentHasPointInFOV = false
        local CurrentHitboxes = self:GetEntityHitboxes(Player)
        local CurrentPenetrations = 0

        local PlayerIsVisible = false

        for GroupIndex = 1, #Cache.AimbotData.ScanOrder do
            local Hitgroup = Cache.AimbotData.ScanOrder[GroupIndex]
            if not CurrentHitboxes[Hitgroup] then continue end

            for i = 1, #CurrentHitboxes[Hitgroup] do
                local CurrentPosition = CurrentHitboxes[Hitgroup][i]
                if not CurrentPosition then continue end

                local pInFOV, pDistance = InFOV(CurrentPosition)
                if not pInFOV then continue end

                local Valid, Penetrations = IsVisible(CurrentPosition, Player)

                if Valid then
                    CurrentHasPointInFOV = pInFOV
                    CurrentDistance = pDistance

                    PlayerIsVisible = true
                    CurrentPenetrations = Penetrations
                    break
                end
            end

            if PlayerIsVisible then break end
        end

        if not PlayerIsVisible then continue end

        if CurrentHasPointInFOV and CurrentDistance < BestDistance then
            BestDistance = CurrentDistance
            BestPlayer = Player
            BestHitboxes = CurrentHitboxes
            BestPenetrations = CurrentPenetrations
        end

        if ShouldBacktrack and LBacktrack.Records[Player] then
            local BacktrackData = LBacktrack.Records[Player]

            for BacktrackIndex = 1, #BacktrackData do
                local Hitboxes = BacktrackData[BacktrackIndex].Hitboxes

                for GroupIndex = 1, #Cache.AimbotData.ScanOrder do
                    local Hitgroup = Cache.AimbotData.ScanOrder[GroupIndex]
                    if not Hitboxes[Hitgroup] then continue end

                    for HitboxIndex = 1, #Hitboxes[Hitgroup] do
                        local CurrentPosition = Hitboxes[Hitgroup][HitboxIndex]

                        local pInFOV, pDistance = InFOV(CurrentPosition)
                        if not pInFOV then continue end

                        local Valid, Penetrations, Fraction = IsVisible(CurrentPosition, Player)
                        if not Valid and Fraction < 0.99 then continue end

                        if pDistance < BestDistance then
                            return Player, Hitboxes, Penetrations, true, BacktrackData[BacktrackIndex].SimulationTime
                        end
                    end
                end
            end
        end

        CurrentDistance = math.huge
        CurrentHasPointInFOV = false
    end

    return BestPlayer, BestHitboxes, BestPenetrations, BestIsBacktrack
end

function LRagebot:GetAvailablePositions(Entity, Hitboxes)
    local FixedHitboxes = {}

    for GroupIndex = 1, #Cache.AimbotData.ScanOrder do
        local Hitgroup = Cache.AimbotData.ScanOrder[GroupIndex]
        if not Hitboxes[Hitgroup] then continue end

        for i = 1, #Hitboxes[Hitgroup] do
            local CurrentPosition = Hitboxes[Hitgroup][i]

            if InFOV(CurrentPosition) then
                FixedHitboxes[Hitgroup] = FixedHitboxes[Hitgroup] or {}
                FixedHitboxes[Hitgroup][#FixedHitboxes[Hitgroup] + 1] = CurrentPosition
            end
        end
    end

    return #FixedHitboxes == 0 and nil or FixedHitboxes
end

function LRagebot:GetAimPosition(Entity, Hitboxes, IsBacktrack)
    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if Weapon:IsValid() and Weapon:GetClass() == "weapon_crossbow" then
        local hitpos = Entity:LocalToWorld(Entity:OBBCenter())
        local flTime = g_pLocalPlayer:GetShootPos():Distance(hitpos) / 3500

        -- account for lag compensation
        flTime = flTime + GetLerpTime()
        flTime = flTime + TickToTime(1)

        -- latency
        flTime = flTime + (g_pLocalPlayer:Ping() / 1000)

        local vel = Entity:GetAbsVelocity()

        hitpos:Add(vel * flTime)
        hitpos.z = hitpos.z + (Cache.ConVars.sv_gravity:GetFloat() * .05 * flTime)

        return hitpos
    end
        
    local FixedHitboxes = self:GetAvailablePositions(Entity, Hitboxes, IsBacktrack)
    if not FixedHitboxes then return nil end

    for GroupIndex = 1, #Cache.AimbotData.ScanOrder do
        local Hitgroup = Cache.AimbotData.ScanOrder[GroupIndex]
        if not Hitboxes[Hitgroup] then continue end

        for i = 1, #Hitboxes[Hitgroup] do
            local CurrentPosition = Hitboxes[Hitgroup][i]
            if not InFOV(CurrentPosition) then continue end

            if IsBacktrack then
                local Valid, _, Fraction = IsVisible(CurrentPosition, Entity)

                if Valid or Fraction >= 0.99 then
                    return CurrentPosition, Hitgroup
                end
            else
                if IsVisible(CurrentPosition, Entity) then
                    return CurrentPosition, Hitgroup
                end
            end
        end
    end

    return nil
end

function LRagebot:Run(Command)
    if not self:ShouldRun() then return false end

    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if not Weapon then return false end

    if config["Silent"] and Command:TickCount() ~= 0 then
        g_bShouldEngineViewAngles = false
    end

    local KeyDown = (config.binds["AimKey"] == KEY_NONE) or (config.binds["AimKey"] ~= 0 and ((config.binds["AimKey"] >= 107 and config.binds["AimKey"] <= 113) and input.IsMouseDown(config.binds["AimKey"])) or input.IsKeyDown(config.binds["AimKey"]))

    if (KeyDown or Command:KeyDown(IN_ATTACK)) and CanShoot() then
        if not KeyDown then -- Standalone
            local NewForward = Angle(Cache.FacingAngle)

            if config["NoSpread"] then CalculateNospread(Weapon, Command, NewForward) end
            if config["NoRecoil"] then NewForward:Sub(CalculateViewPunch(Weapon)) end
            FixAngle(NewForward)

            Command:SetViewAngles(NewForward)

            return
        end

        local Target, Hitboxes, Penetrations, IsBacktrack, SimulationTime = self:GetTarget()
		if not IsValid(Target) then return end

		local Position, Hitgroup = self:GetAimPosition(Target, Hitboxes, IsBacktrack)
		if not Position then return end

        local Ping = TimeToTick(proxi.GetFlowIncoming() + proxi.GetFlowOutgoing())
        
		if IsBacktrack and IsTickValid(SimulationTime) then
			Command:SetTickCount(TimeToTick(SimulationTime + GetLerpTime()))
		else
			PredictTargetPosition(Position, Target, Ping)
			Command:SetTickCount(Command:TickCount() + Ping)
		end

        debugoverlay.Cross(Position, 3, 0.1, Color(255,0,0), true)

        local vDir = Vector(Position)
        vDir:Sub(g_pLocalPlayer:GetShootPos())
        vDir:Normalize()

        local Direction = vDir:Angle()
        Direction:Normalize()

        if not config["Silent"] then Cache.FacingAngle = Angle(Direction) end
        if config["NoSpread"] then CalculateNospread(Weapon, Command, Direction) end
        if config["NoRecoil"] then Direction:Sub(CalculateViewPunch(Weapon)) end
        FixAngle(Direction)

        if (config["Silent"] and not config["ContextAiming"]) or not config["Silent"] then
            Command:SetViewAngles(Direction)
        else
            Command:SetInWorldClicker(true)
            Command:SetWorldClickerAngles(Direction:Forward())
        end

        if config["Autofire"] then Command:AddKey(IN_ATTACK) end
    end

    return true
end

/*
    Backtrack
*/

function LBacktrack:CollectData()
    for i = 1, #Cache.Players do
        local Player = Cache.Players[i]
        if not IsValid(Player) or not LRagebot:IsViableTarget(Player) then continue end

        if not self.Records[Player] then
            self.Records[Player] = {}
        end

        local SimulationTime = GetEntitySimulationTime(Player)

        self.Records[Player][#self.Records[Player] + 1] = {
            Player = Player,
            Hitboxes = LRagebot:GetEntityHitboxes(Player),
            SimulationTime = SimulationTime
        }
    end
end

function LBacktrack:ClearRecords()
    local CurTime = GetServerTime()

    for i = 1, #Cache.Players do
        local Player = Cache.Players[i]
        if not IsValid(Player) then continue end

        local BacktrackData = self.Records[Player]
        if not BacktrackData then continue end

        for BacktrackIndex = #BacktrackData, 1, -1 do
            local BacktrackCurTime = BacktrackData[BacktrackIndex].SimulationTime

            if CurTime - BacktrackCurTime > config["BacktrackTime"] or BacktrackCurTime > CurTime then
                table.remove(BacktrackData, BacktrackIndex)
                continue
            end
        end
    end
    
    collectgarbage("step") -- :)
end

local function ValidEnt(v)
    return v ~= g_pLocalPlayer and IsValid(v) and v:Health() > 0 and not v:IsDormant()
end

local function GetScreenCorners(Entity)
    local Mins, Maxs = Entity:GetCollisionBounds()

    local Coords = { -- I'm sorry garbage collection :(
        Entity:LocalToWorld(Mins):ToScreen(),
        Entity:LocalToWorld(Vector(Mins.x, Maxs.y, Mins.z)):ToScreen(),
        Entity:LocalToWorld(Vector(Maxs.x, Maxs.y, Mins.z)):ToScreen(),
        Entity:LocalToWorld(Vector(Maxs.x, Mins.y, Mins.z)):ToScreen(),
        Entity:LocalToWorld(Maxs):ToScreen(),
        Entity:LocalToWorld(Vector(Mins.x, Maxs.y, Maxs.z)):ToScreen(),
        Entity:LocalToWorld(Vector(Mins.x, Mins.y, Maxs.z)):ToScreen(),
        Entity:LocalToWorld(Vector(Maxs.x, Mins.y, Maxs.z)):ToScreen()
    }

    local Left, Right, Top, Bottom = Coords[1].x, Coords[1].x, Coords[1].y, Coords[1].y

    for i = 1, #Coords do
        local v = Coords[i]
        if Left > v.x then Left = v.x end
        if Top > v.y then Top = v.y end
        if Right < v.x then Right = v.x end
        if Bottom < v.y then Bottom = v.y end
    end

    return math.Round(Left), math.Round(Right), math.Round(Top), math.Round(Bottom)
end

for _,v in ipairs(player.GetAll()) do
    v.Traitor = nil
end

AddHook("Think", function()
    if config["Visuals"] && config["Traitor"] && engine.ActiveGamemode() == "terrortown" then
        if GAMEMODE.round_state != ROUND_ACTIVE then
            for _,v in ipairs(player.GetAll()) do
                v.Traitor = nil
            end
            return
        end
        for _, v in ipairs( player.GetAll() ) do
            if IsValid(v) && v:IsTerror() && !v:IsDetective() && !v.Traitor && v != g_pLocalPlayer then
                for _, w in ipairs(v:GetWeapons()) do
                    if w and w.CanBuy and table.HasValue(w.CanBuy, ROLE_TRAITOR) && w.AutoSpawnable == false then
                        v.Traitor = true
                        chat.AddText(Color(61, 149, 217), "[FartClient] ", Color(222, 222, 222), v:Nick(),  " is a ", Color(255,0,0), "TRAITOR", Color(222, 222, 222), " with a ", Color(0, 255, 0), w:GetClass() .. ".")
                    end
                end
            end
        end
    end
end)

    local function Visuals()
        if(config["Visuals"]) then
            if config["Crosshair"] then
                draw.RoundedBox(0, Cache.ScreenData.Center.X - 11, Cache.ScreenData.Center.Y - 1, 22, 2, string.ToColor(config.clrs["Crosshair"]))
                draw.RoundedBox(0, Cache.ScreenData.Center.X - 1, Cache.ScreenData.Center.Y - 11, 2, 22, string.ToColor(config.clrs["Crosshair"]))
            end
            for k, v in ipairs(ents.GetAll()) do
                if not ValidEnt(v) then continue end
                
                if (!config["ShowNPCs"]) then
                    if string.StartWith(v:GetClass(), "npc_") or string.StartWith(v:GetClass(), "nz_zombie_*") then continue end
                end

                if (!config["ShowPlayers"]) then
                    if v:GetClass() == "player" then continue end
                end

                if (!config["ShowOther"]) then
                    if (v:GetClass() and v:GetClass() != "player" and (!string.StartWith(v:GetClass(), "npc_")) and (!string.StartWith(v:GetClass(), "nz_zombie_*"))) then
                        if v:GetClass() then continue end
                    end
                end

                if config["ESPRender"] then
                    if (math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= config["RenderDist"] then continue end
                end

                local pos = v:GetPos()
                local min, max = v:GetCollisionBounds()
                local pos2 = pos + Vector(min.x, 0, max.z)
                local pos = Vector(pos):ToScreen()
                local pos2 = Vector(pos2):ToScreen()
                local hh = 0
                local h = pos.y - pos2.y
                local w = h / 2
                local ww = h / 4

                if config["Chams"] then
                    if config["ChamsMaterial"] == 1 then
                        ChamsM = "!flat"
                    elseif config["ChamsMaterial"] == 2 then
                        ChamsM = "!textured"
                    elseif config["ChamsMaterial"] == 3 then
                        ChamsM = "!wireframe"
                    end
                    local ccol = string.ToColor(config.clrs["Chams"])
                    cam.Start3D()
                        render.SuppressEngineLighting(false)
                        render.MaterialOverride(Material(ChamsM))
                        render.SetColorModulation(ccol.r / 255, ccol.g / 255, ccol.b / 255)
                        render.SetBlend(1)
                        v:DrawModel()
                        render.MaterialOverride(nil)
                        render.SuppressEngineLighting(false)
                    cam.End3D()
                end

                if config["3DBoxFill"] or config["3DBox"] then
                    cam.Start3D()
                        local mins, maxs = v:GetCollisionBounds()
                        local pos = v:GetPos()

                        render.SuppressEngineLighting(true)
                        if !config["Box"] and !config["BoxFilled"] then
                            if config["3DBoxFill"] then
                                render.SetColorMaterial()
                                render.DrawBox(pos, angle_zero, mins, maxs, Color(20,20,20,150))
                            end
                            if config["3DBox"] then
                                render.DrawWireframeBox(pos, angle_zero, mins, maxs, string.ToColor(config.clrs["3DBox"]), false )
                            end
                        end
                        render.SuppressEngineLighting(false)
                    cam.End3D()
                end

                if config["Skeleton"] then
                    local pos = v:GetPos()
                    for i = 0, v:GetBoneCount() do
                        local parent = v:GetBoneParent(i)
                        if not parent then continue end

                        local bonepos = v:GetBonePosition(i)
                        if bonepos == pos then continue end

                        local parentpos = v:GetBonePosition(parent)
                        if not onepos or  not parentpos then continue end

                        local screen1, screen2 = Vector(bonepos):ToScreen(), Vector(parentpos):ToScreen()
                            
                        surface.SetDrawColor(string.ToColor(config.clrs["Skeleton"]))
                        surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
                    end
                end
                    
                if config["Name"] then
                    if v:GetClass() == "player" then
                        draw.SimpleTextOutlined(v:Nick(), "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Name"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Cache.Colors.Black)
                    else
                        draw.SimpleTextOutlined(v:GetClass(), "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Name"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Cache.Colors.Black)
                    end
                end

                if config["Weapon"] and v:GetClass() == "player" or string.StartWith(v:GetClass(), "npc_") then
                    if(IsValid(v:GetActiveWeapon())) then
                        draw.SimpleTextOutlined(v:GetActiveWeapon():GetClass(), "FT3", pos.x, pos.y + 3, string.ToColor(config.clrs["Weapon"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                    end
                end

                if config["Rank"] and config["Weapon"] and v:GetClass() == "player" then
                    draw.SimpleTextOutlined(v:GetUserGroup(), "FT3", pos.x, pos.y + 12, string.ToColor(config.clrs["Rank"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                elseif config["Rank"] and (!config["Weapon"]) and v:GetClass() == "player" then
                    draw.SimpleTextOutlined(v:GetUserGroup(), "FT3", pos.x, pos.y + 3, string.ToColor(config.clrs["Rank"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                end

                if config["BoxFilled"] then
                    surface.SetAlphaMultiplier( .08 )
                    surface.SetDrawColor(string.ToColor(config.clrs["BoxFilled"]))
                    surface.DrawRect(pos.x - w / 2, pos2.y, w, h)
                    surface.SetAlphaMultiplier( 1 )
                end

                if config["Box"] then
                    surface.SetDrawColor(string.ToColor(config.clrs["Box"]))
                    surface.DrawOutlinedRect(pos.x - w / 2, pos2.y, w, h)
                    surface.SetDrawColor(Cache.Colors.Black)
                    surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos2.y - 1, w + 2, h + 2, 1)
                    surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos2.y + 1, w - 2, h - 2, 1)
                end

                if config["HealthBar"] then
                    local hp = math.Clamp(v:Health(), 0, 100)
                    if v:Health() <= 100 then
                        surface.SetDrawColor(Color(20, 20, 20))
                        surface.DrawRect(pos.x - w / 2 - 5, pos2.y - 1, w / w + 2, h + 2)
                        surface.SetDrawColor(HSVToColor( hp / 100 * 120, 1, 1 ))
                        surface.DrawRect(pos.x - w / 2 - 4, pos.y - h / 100 * v:Health(), w / w, h / 100 * v:Health())
                    else
                        surface.SetDrawColor(Color(20, 20, 20))
                        surface.DrawRect(pos.x - w / 2 - 5, pos2.y - 1, w / w + 2, h + 2)
                        surface.SetDrawColor(HSVToColor( hp / 100 * 120, 1, 1 ))
                        surface.DrawRect(pos.x - w / 2 - 4, pos.y - h, w / w, h)
                    end
                end

                if config["HealthText"] then
                    local hp = math.Clamp(v:Health(), 0, 100)
                    draw.SimpleTextOutlined(v:Health() .. "HP", "FT3", pos.x - w / 2 - 6, pos2.y + 2, HSVToColor( hp / 100 * 120, 1, 1 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                end

                if config["ArmorBar"] then
                    local ap = math.Clamp(v:Armor(), 0, 100)
                    if v:Armor() <= 100 && v:Armor() > 0 then
                        surface.SetDrawColor(Color(20, 20, 20))
                        surface.DrawRect(pos.x + w / 2 + 2, pos2.y - 1, w / w + 2, h + 2)
                        surface.SetDrawColor(Color(84, 118, 255))
                        surface.DrawRect(pos.x + w / 2 + 3, pos.y - h / 100 * v:Armor(), w / w, h / 100 * v:Armor())
                    elseif v:Armor() > 100 then
                        surface.SetDrawColor(Color(20, 20, 20))
                        surface.DrawRect(pos.x + w / 2 + 2, pos2.y - 1, w / w + 2, h + 2)
                        surface.SetDrawColor(Color(84, 118, 255))
                        surface.DrawRect(pos.x + w / 2 + 3, pos.y - h, w / w, h)
                    end
                end

                if config["ArmorText"] and config["ArmorBar"] and v:GetClass() == "player" then
                    if v:Armor() > 0 then
                        draw.SimpleTextOutlined(v:Armor() .. "AP", "FT3", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(config.clrs["ArmorText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                    end
                elseif config["ArmorText"] and !config["ArmorBar"] and v:GetClass() == "player" then
                    if v:Armor() > 0 then
                        draw.SimpleTextOutlined(v:Armor() .. "AP", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["ArmorText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                    end
                end

                if config["Distance"] and config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 then
                    draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                elseif config["Distance"] and !config["ArmorBar"] and !config["ArmorText"] and v:Armor() > 0 then
                    draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                elseif config["Distance"] and !config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 then
                    draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 11, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                elseif config["Distance"] and config["ArmorBar"] and config["ArmorText"] and v:Armor() > 0 then
                    draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 6, pos2.y + 11, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                elseif config["Distance"] and v:Armor() <= 0 then
                    draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", pos.x + w / 2 + 1, pos2.y + 2, string.ToColor(config.clrs["Distance"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Cache.Colors.Black)
                end

                if config["Friend"] and config["Name"] and v:GetClass() == "player" then
                    if(v:GetFriendStatus() == "friend") then
                        draw.SimpleTextOutlined("*FRIEND*", "FT3", pos.x, pos2.y - 11, string.ToColor(config.clrs["Friend"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Cache.Colors.Black)
                    end
                elseif config["Friend"] and (!config["Name"]) and v:GetClass() == "player" then
                    if(v:GetFriendStatus() == "friend") then
                        draw.SimpleTextOutlined("*FRIEND*", "FT3", pos.x, pos2.y - 2, string.ToColor(config.clrs["Friend"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Cache.Colors.Black)
                    end 
                end
            end
        end

        for k, v in next, ents.GetAll() do
            if not v or v:GetOwner() == g_pLocalPlayer or not IsValid(v) then continue end
            if not table.HasValue(config["EntityList"], v:GetClass()) then continue end

            if config["EntRender"] then
                if (math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= config["EntRenderDist"] then continue end
            end

            local x1,y1,x2,y2 = GetScreenCorners(v)

            local w = math.abs(x2 - x1)
            local h = math.abs(y2 - y1)

            if config["EntBox"] then
                surface.SetDrawColor(string.ToColor(config.clrs["EntBox"]))
                surface.DrawOutlinedRect(x1, y1, w, h)
                surface.SetDrawColor(Cache.Colors.Black)
                surface.DrawOutlinedRect(x1 - 1, y1 - 1, w + 2, h + 2, 1)
                surface.DrawOutlinedRect(x1 + 1, y1 + 1, w - 2, h - 2, 1)
            end

            if config["EntName"] then
                draw.SimpleTextOutlined(v:GetClass(), "FT3", x1 + w / 2, y1 - 2, string.ToColor(config.clrs["EntName"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Cache.Colors.Black)
            end

            if config["EntDist"] then
                draw.SimpleTextOutlined(math.Round(g_pLocalPlayer:GetPos():Distance( v:GetPos() ) / 42, 1 ) .. "m", "FT3", x1 + w / 2, y2 - 2, string.ToColor(config.clrs["EntDist"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Cache.Colors.Black)
            end

            if config["EntChams"] then
                if config["ChamsMaterial"] == 1 then
                    ChamsM = "!flat"
                elseif config["ChamsMaterial"] == 2 then
                    ChamsM = "!textured"
                elseif config["ChamsMaterial"] == 3 then
                    ChamsM = "!wireframe"
                end

                local ccol = string.ToColor(config.clrs["EntChams"])
                cam.Start3D()
                    render.SuppressEngineLighting(false)
                    render.MaterialOverride(Material(ChamsM))
                    render.SetColorModulation(ccol.r / 255, ccol.g / 255, ccol.b / 255)
                    render.SetBlend(1)
                    v:DrawModel()
                    render.MaterialOverride(nil)
                    render.SuppressEngineLighting(false)
                cam.End3D()
            end
        end
    end

local function SpecList()
    local specw = 220
    local spech = 19
    local specamt = 0
    local specx = specw + (Cache.ScreenData.Width / 12)
    local specy = 15
    draw.RoundedBoxEx(4, specx, specy, specw, spech, Cache.Colors.DarkNavy, true, true, false, false)
    draw.SimpleText("Spectator's List", "FT6", specx + specw / 2, specy + 1, Cache.Colors.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    for k, v in pairs(player.GetAll()) do
        if (IsValid(v:GetObserverTarget()) and v != g_pLocalPlayer and v:GetObserverTarget() == g_pLocalPlayer) then
            draw.RoundedBox(0, specx, specy - 1 + spech + specamt, specw, spech, Color(20, 31, 42))
            draw.SimpleText(v:Nick(), "FT8", specx + specw / 2, specy + 1 + spech + specamt, Cache.Colors.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            specamt = specamt + 14
        end
    end
    draw.RoundedBoxEx(4, specx, specy + spech + specamt, specw, 6, Cache.Colors.DarkNavy, false, false, true, true)
    draw.RoundedBox(0, specx, specy + spech - 2, specw, 2, string.ToColor(config.clrs["MenuColor"]))
    specw = specamt + 15
end

local function AdminList()
    local adminw = 220
    local adminh = 19
    local adminamt = 0
    local adminx = adminw + (Cache.ScreenData.Width / 5) + 10
    local adminy = 15

    draw.RoundedBoxEx(4, adminx, adminy, adminw, adminh, Cache.Colors.DarkNavy, true, true, false, false)
    draw.SimpleText("Admin's List", "FT6", adminx + adminw / 2, adminy + 1, Cache.Colors.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    for k, v in pairs(player.GetAll()) do
        if (v != g_pLocalPlayer and table.HasValue(staffRanks, v:GetUserGroup())) then
            draw.RoundedBox(0, adminx, adminy - 1 + adminh + adminamt, adminw, adminh, Color(20, 31, 42))
            draw.SimpleText(v:Nick() .. " | " .. v:GetUserGroup(), "FT8", adminx + adminw / 2, adminy + 1 + adminh + adminamt, Cache.Colors.White, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            adminamt = adminamt + 14
        end
    end
    draw.RoundedBoxEx(4, adminx, adminy + adminh + adminamt, adminw, 6, Cache.Colors.DarkNavy, false, false, true, true)
    draw.RoundedBox(0, adminx, adminy + adminh - 2, adminw, 2, string.ToColor(config.clrs["MenuColor"]))
    adminw = adminamt + 15
end

local freecamAngles = Angle()
local freecamAngles2 = Angle()
local freecamPos = Vector()
local freecamEnabled = false
local freecamSpeed = 3
local keyPressed = false

/*
    Anti Aim
*/  

local LAntiAim = {
    AntiAimAngle = Angle(),
    CurrCmd = nil,
}

local pDance = 0
local trigger = 0
local bFlip

LAntiAim.PitchFunctions = {
    [2] = function(Angle) -- static up
        Angle.x = -89.9
    end,
    [3] = function(Angle) -- static down
        Angle.x = 89.9
    end,
    [4] = function(Angle) -- jitter
        pDance = pDance + 45
        if pDance > 100 then
            pDance = 0
        elseif pDance > 75 then
            Angle.x = -89
        elseif pDance < 75 then
            Angle.x = 89
            end
        end,
    [5] = function(Angle) -- front
        Angle.x = 0
    end,
    [6] = function(Angle) -- fake zero down
        Angle.x = 1080
    end
}

LAntiAim.YawFunctions = {
    [2] = function(Angle) -- spinbot
        local SpinSpeed = config["AASpinSpeed"]
        Angle.y = math.fmod(GetServerTime() * SpinSpeed, 360)
    end,
    [3] = function(Angle) -- jitter
        Angle.y = Angle.y - (bFlip and 30 or -30)
    end,
    [4] = function(Angle) -- jitter backwards
        Angle.y = Angle.y - 180
        Angle.y = Angle.y - (bFlip and 30 or -30)
    end,
    [5] = function(Angle) -- side
        Angle.y = Angle.y + (bFlip and 90 or -90)
    end,
    [6] = function(Angle) -- backwards
        Angle.y = Angle.y - 180
    end,
    [7] = function(Angle) -- static jitter
        trigger = trigger + 15
        Angle.y = trigger > 50 and 150 or -150
    
        if trigger > 100 then trigger = 0 end 
    end,
    [8] = function(Angle) -- fake forwards
        Angle.y = g_bSendPacket and Angle.y or Angle.y + (bFlip and 180 or -180)
    end,
    [9] = function(Angle) -- fake sideways
        Angle.y = g_bSendPacket and Angle.y + (bFlip and 30 or -30) or Angle.y + (bFlip and 180 or -180)
    end,
    [10] = function(Angle) -- fake custom spin
        local factor = config["AASpinSpeed"]
        Angle.y = g_bSendPacket and math.fmod(GetServerTime() * factor, 360) or Angle.y + (bFlip and 180 or -180)
    end
}

function LAntiAim:PerformPitch()
    if config["AAPitch"] == 1 then return false end
    
    local fnPitch = self.PitchFunctions[config["AAPitch"]]
    if not isfunction(fnPitch) then return false end
    
    fnPitch(self.AntiAimAngle)

    return true
end

function LAntiAim:PerformYaw()
    if config["AAYaw"] == 1 then return false end
    
    bFlip = not bFlip
        
    local fnYaw = self.YawFunctions[config["AAYaw"]]
    if not isfunction(fnYaw) then return false end
    
    fnYaw(self.AntiAimAngle)

    return true
end

function LAntiAim:ShouldRun()
    if not config["AntiAim"] then return false end
    if not self.CurrCmd then return false end
    if self.CurrCmd:CommandNumber() == 0 then return false end
    if self.CurrCmd:KeyDown(IN_USE) or g_pLocalPlayer:GetMoveType() == MOVETYPE_LADDER then return false end
    if self.CurrCmd:KeyDown(IN_ATTACK) or (config.binds["AimKey"] == KEY_NONE) or (config.binds["AimKey"] ~= 0 and ((config.binds["AimKey"] >= 107 and config.binds["AimKey"] <= 113) and input.IsMouseDown(config.binds["AimKey"])) or input.IsKeyDown(config.binds["AimKey"])) then return false end
        
    if self.CurrCmd:TickCount() == 0 then return false end
    
    return true
end
    
function LAntiAim:Run(Command)
    self.CurrCmd = Command
    
    if not self:ShouldRun() then return false end
    self.AntiAimAngle:Set(self.CurrCmd:GetViewAngles())
    
    local bPerformedPitch = self:PerformPitch()
    local bPerformedYaw = self:PerformYaw()

    if bPerformedPitch or bPerformedYaw then
        g_bShouldEngineViewAngles = false
    end
    
    self.CurrCmd:SetViewAngles(self.AntiAimAngle)

    return true
end

/*
    Fake Lag
*/

local Choke = 0
function LAntiAim:FakeLag(Command)
    if Command:CommandNumber() == 0 then return end

    if config["FakeLag"] then
        if Choke >= config["FLChoke"] then
            Choke = 0
        else
            Choke = Choke + 1
        end

        if config["FLAdaptive"] then
            local Velocity = g_pLocalPlayer:GetVelocity()
            local Speed = Velocity:Length2D()

            local chokes = math.ceil(64 / (Speed * Cache.TickInterval))
            chokes = math.Clamp(chokes, 1, 22)
        
            g_bSendPacket = Choke >= chokes
        else
            g_bSendPacket = Choke >= config["FLChoke"]
        end
    else
        Choke = 0
            
        g_bSendPacket = true
    end
end

/*
    Hooks n shit
*/

AddHook("Tick", function()
    local Time = SysTime()

    if Time - Cache.LastUpdate >= 0.3 then
        -- Players
        table.Empty(Cache.Players)
            
        local Players = player.GetAll()

        for i = 1, #Players do
            Cache.Players[#Cache.Players + 1] = Players[i]
        end

        Cache.LastUpdate = Time
    end
end)

AddHook("PostFrameStageNotify", function(Stage)
    if not config["Aimbot"] or not config["Backtrack"] then
        if not table.IsEmpty(LBacktrack.Records) then
            table.Empty(LBacktrack.Records)
        end

        return
    end

    if Stage ~= FRAME_NET_UPDATE_END then return end

    LBacktrack:CollectData() 
    LBacktrack:ClearRecords()
end)

AddHook("PreDrawEffects", function()
    if not config["ShowBacktrack"] then return end

	local Mins = Vector(-1, -1, -1)
	local Maxs = Vector(1, 1, 1)

	for _, d in pairs(LBacktrack.Records) do
		for i = 1, #d do
			local h = d[i]

			for i = #Cache.AimbotData.ScanOrder, 1, -1 do
				local Set = Cache.AimbotData.ScanOrder[i]
				if not h.Hitboxes[Set] then continue end

				for _, hPos in ipairs(h.Hitboxes[Set]) do
					render.DrawWireframeBox(hPos, angle_zero, Mins, Maxs, Cache.Colors.White, false)
				end
			end
	    end
	end
end)

AddHook("CalcView", function(Player, Origin, Angles, FOV, ZNear, ZFar, ThisServerIsRetarded)
    if ThisServerRetarded then -- 208.103.169.66
        ZNear = ZFar
        ZFar = ThisServerIsRetarded
    end

    local CalcAngle = config["Silent"] and Cache.FacingAngle or Angles -- used more than once
    local ShouldChangeFOV = config["ViewmodelChanger"] and config["Visuals"] and not ss -- i just dont like how long it looks
        
    local View = {
        origin = config["Thirdperson"] and Origin - ((CalcAngle):Forward() * config["TPDistance"]) or Origin,
        angles = CalcAngle,
        fov = ShouldChangeFOV and config["ViewmodelFOV"] or FOV,
        znear = ZNear,
        zfar = ZFar,
        drawviewer = (freecamEnabled && config["Freecam"] && config["Misc"]) or (config["Thirdperson"] and config["Misc"] and intp), -- stfu
    }
        
    local Vehicle = g_pLocalPlayer:GetVehicle()
    
    if IsValid(Vehicle) then
        UpdateCalcViewData(View)
    
        return hook.Run("CalcVehicleView", Vehicle, g_pLocalPlayer, View)
    end
    
    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if IsValid(Weapon) then
        local wCalcView = Weapon.CalcView
    
        if wCalcView then
            local WeaponAngle = angle_zero
    
            View.origin, WeaponAngle, View.fov = wCalcView(Weapon, g_pLocalPlayer, View.origin * 1, CalcAngle * 1, ShouldChangeFOV and config["ViewmodelFOV"] or FOV)
    
            if GetWeaponBase(Weapon) ~= "arccw" then
                View.angles = WeaponAngle
            end
        end
    end

    if freecamEnabled and config["Freecam"] and config["Misc"] then
        View.origin = freecamPos
        View.angles = freecamAngles
    end
        
    UpdateCalcViewData(View)
    
    return View
end)

AddHook("EntityFireBullets", function(Player, Data)
    if Player ~= g_pLocalPlayer then return end
    if not IsFirstTimePredicted() then return end 
        
    local Weapon = Player:GetActiveWeapon()
    if not IsValid(Weapon) then return end

    if isvector(Data.Spread) and not Data.Spread:IsZero() then
        Cache.WeaponData.Nospread.Cones[Weapon:GetClass()] = Data.Spread
    end
end)

AddHook("InputMouseApply", function(Command, MouseX, MouseY)
    if g_pLocalPlayer:IsFrozen() then return end

    local Weapon = g_pLocalPlayer:GetActiveWeapon()

    if IsValid(Weapon)  then
        if Weapon.FreezeMovement and Weapon:FreezeMovement() then return end -- GMod camera + whatever else may freeze rotation
        if Weapon:GetClass() == "weapon_physgun" and IsValid(Weapon:GetInternalVariable("m_hGrabbedEntity")) and (Command:KeyDown(IN_USE) or g_pLocalPlayer:KeyDown(IN_USE)) then return end
    end

    Cache.FacingAngle.pitch = Cache.FacingAngle.pitch + (MouseY * Cache.ConVars.m_pitch:GetFloat())
    Cache.FacingAngle.yaw = Cache.FacingAngle.yaw - (MouseX * Cache.ConVars.m_yaw:GetFloat())

    FixAngle(Cache.FacingAngle)
end)

AddHook("Think", function()
    if config["Freecam"] && config["Misc"] then
        if (config.binds["Freecam_key"] == KEY_NONE) or ( config.binds["Freecam_key"] != 0 and ( ( config.binds["Freecam_key"] >= 107 and config.binds["Freecam_key"] <= 113 ) and input.IsMouseDown(config.binds["Freecam_key"]) ) or input.IsKeyDown(config.binds["Freecam_key"]) ) then
            if(!keyPressed) then
                freecamEnabled = !freecamEnabled
                freecamAngles = g_pLocalPlayer:EyeAngles()
                freecamAngles2 = g_pLocalPlayer:EyeAngles()
                freecamPos = g_pLocalPlayer:EyePos()
                keyPressed = true
            end
        else
            keyPressed = false
        end
    end
end)

local function ValidMovementType()
    return g_pLocalPlayer:GetMoveType() == MOVETYPE_WALK and not IsValid(g_pLocalPlayer:GetVehicle()) and g_pLocalPlayer:WaterLevel() < 2
end

local function Movement(Command)
    if config["Bhop"] then
        if g_pLocalPlayer:GetMoveType() == MOVETYPE_NOCLIP or g_pLocalPlayer:InVehicle() or g_pLocalPlayer:GetMoveType() == 8 then return end
        if Command:CommandNumber() ~= 0 then
            if g_pLocalPlayer:IsOnGround() and Command:KeyDown(IN_JUMP) then Command:RemoveKey(IN_JUMP) end
                
                
            if config["Autostrafe"] then
                if g_pLocalPlayer:IsOnGround() then return end
                Command:SetForwardMove(5850 / g_pLocalPlayer:GetVelocity():Length2D())
                Command:SetSideMove((Command:CommandNumber() % 2 == 0) and 400 or -400)
            end
        end
    end
end

gameevent.Listen("player_hurt")
AddHook("player_hurt", function(data)
    if config["Hitsound"] and config["Misc"] then
        if data.attacker == g_pLocalPlayer:UserID() then
            surface.PlaySound("buttons/bell1.wav")
        end
    end
end)

AddHook("PostDrawHUD", function()
    if ss then return end
        
    Visuals()

    if(config["Misc"]) then
        if(config["SpectatorsList"]) then
            SpecList()
        end
        if config["AdminsList"] then
            AdminList()
        end
    end

    if config["FovCircle"] and config["Aimbot"] then
        if config["AimFOV"] < 70 then
            surface.DrawCircle(Cache.ScreenData.Center.X, Cache.ScreenData.Center.Y,  GetFOVRadius(), string.ToColor(config.clrs["FovCircle"])) 
        end
    end
end)

AddHook("CalcViewModelView", function(Weapon, ViewModel, OldPos, OldAngle, EyePos, EyeAngle)
    if ss then return end

    if intp && config.binds["Thirdperson_key"] != 0 or freecamEnabled then return end
    if config.binds["Thirdperson_key"] == 0 && config["Thirdperson"] then return end

    if config["removebob"] then
        EyeAngle = OldAngle
    end
    if config["removesway"] then
        EyePos = OldPos
    end

    if !config["ViewmodelChanger"] then return end
        
    local OverridePos = Vector(config["viewmodel_x"], config["viewmodel_y"], config["viewmodel_z"])
    local OverrideAngle = Angle(config["viewmodel_p"], config["viewmodel_ya"], config["viewmodel_r"])

    EyeAngle = EyeAngle * 1

    EyeAngle:RotateAroundAxis(EyeAngle:Right(), OverrideAngle.x * 1.0)
    EyeAngle:RotateAroundAxis(EyeAngle:Up(), OverrideAngle.y * 1.0)
    EyeAngle:RotateAroundAxis(EyeAngle:Forward(), OverrideAngle.z* 1.0)

    EyePos = EyePos + OverridePos.x * EyeAngle:Right() * 1.0
    EyePos = EyePos + OverridePos.y * EyeAngle:Forward() * 1.0
    EyePos = EyePos + OverridePos.z * EyeAngle:Up() * 1.0 

    return EyePos, EyeAngle
end)

AddHook("CreateMove", function(Command)
    if not config["Aimbot"] then
        Cache.FacingAngle = Command:GetViewAngles()
    end

    Command:SetViewAngles(Cache.FacingAngle)
end)

AddHook("CreateMoveEx", function(Command, SendPacket)
    if not g_pLocalPlayer:Alive() then return end

    g_bSendPacket = SendPacket
    g_bShouldEngineViewAngles = true

	if Command:TickCount() ~= 0 then
		LAntiAim:FakeLag(Command)
	end

    proxi.StartPrediction(Command)
        LRagebot:Run(Command)
        LAntiAim:Run(Command)
        RapidFire(Command)
    proxi.EndPrediction()

    Movement(Command)

    if config["Silent"] then
        FixMovement(Command)
    end

    CollectFreeCamInfo(Command)
    
    if config["Thirdperson"] and config["Misc"] then
        if config.binds["Thirdperson_key"] == 0 then 
            intp = true
        elseif ((config.binds["Thirdperson_key"] >= 107 and config.binds["Thirdperson_key"] <= 113) and input.IsMouseDown(config.binds["Thirdperson_key"]) and !toggledelay3 or input.IsKeyDown(config.binds["Thirdperson_key"]) and !toggledelay3) then
            intp = not intp
            toggledelay3 = true
            timer.Simple(0.3, function() toggledelay3 = false end)
        end
    end

    if Command:TickCount() ~= 0 then
        if not isbool(g_bSendPacket) then
            g_bSendPacket = true
        end
          
        if not isbool(g_bShouldEngineViewAngles) then
            g_bShouldEngineViewAngles = true
        end
        
        return g_bSendPacket, g_bShouldEngineViewAngles
    end
end)

AddHook("PostDraw2DSkyBox", function()
    if config["RemoveSky"] and config["Visuals"] and not ss then
        local SkyCol = string.ToColor(config.clrs["RemoveSky"])
        local col = HSVToColor((CurTime() * (config["RGBSpeed"] * 3)) % 360, 1, 1 )

        if config["RGBSky"] then
            render.Clear(col.r, col.g, col.b, SkyCol.a, true, true)
        else
            render.Clear(SkyCol.r, SkyCol.g, SkyCol.b, SkyCol.a, true, true)
        end
    end
end)

AddHook("OnScreenSizeChanged", function()
    Cache.ScreenData.Width = ScrW()
    Cache.ScreenData.Height = ScrH()

    Cache.ScreenData.Center.X = math.floor(Cache.ScreenData.Width / 2)
    Cache.ScreenData.Center.Y = math.floor(Cache.ScreenData.Height / 2)
end)