for i = 0, 255 do
    CPrint(i, "Testing " .. i)
end