# ProtonMenu
Garry's Mod LUA Cheat, supposed to be used with a C++ module.

### Useful Stuff
- [Extreme Injector](https://github.com/master131/ExtremeInjector)
