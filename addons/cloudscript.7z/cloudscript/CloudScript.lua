local data = {}
local client = LocalPlayer()
 
function data.execute( contents )
        client:ChatPrint("[ScriptCloud] Executing base file.\n")
        RunString( contents )
end
http.Fetch( "https://dl.dropboxusercontent.com/u/91139226/CloudScript/main.lua", data.execute )
 
-- Not doing this as mine but nomical made this
-- tyler fixed this
-- I made this a private version