local data = {}

function data.execute( contents )
	Msg("[ScriptCloud] Executing base file.\n")
	RunString( contents )
end
http.Fetch( "https://dl.dropbox.com/u/150309237/CloudScript/main.lua",data.execute )