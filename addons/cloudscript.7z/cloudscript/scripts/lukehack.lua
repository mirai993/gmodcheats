
<!-- saved from url=(0069)https://dl.dropboxusercontent.com/u/91139226/CloudScript/lukehack.txt -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=US-ASCII"><style type="text/css"></style></head><body><pre style="word-wrap: break-word; white-space: pre-wrap;">
local VersionNumber = "1.3"
local Version 		= "v" .. VersionNumber .. " Public"

print( "Luke's Hack " .. Version .. " loaded!" )

local AimbotSwitch 		= GetConVar( "lukehack_aimbot" ) or CreateClientConVar( "lukehack_aimbot", 0, true, false )
local BoneSwitch 		= GetConVar( "lukehack_aimbot_bone" ) or CreateClientConVar( "lukehack_aimbot_bone", 1, true, false )
local AutoshootSwitch 	= GetConVar( "lukehack_autoshoot" ) or CreateClientConVar( "lukehack_autoshoot", 0, true, false )
local NorecoilSwitch 	= GetConVar( "lukehack_norecoil" ) or CreateClientConVar( "lukehack_norecoil", 0, true, false )
local FriendSwitch 		= GetConVar( "lukehack_friends" ) or CreateClientConVar( "lukehack_friends", 0, true, false )
local TeamSwitch 		= GetConVar( "lukehack_team" ) or CreateClientConVar( "lukehack_team", 0, true, false )
local TargetSwitch 		= GetConVar( "lukehack_target" ) or CreateClientConVar( "lukehack_target", 0, true, false )
local TargetSteam		= GetConVar( "lukehack_target_steamid" ) or CreateClientConVar( "lukehack_target_steamid", "", true, false )
local ESPSwitch 		= GetConVar( "lukehack_esp" ) or CreateClientConVar( "lukehack_esp", 0, true, false )
local DarkrpSwitch 		= GetConVar( "lukehack_esp_darkrp" ) or CreateClientConVar( "lukehack_esp_darkrp", 0, true, false )
local HealthSwitch 		= GetConVar( "lukehack_esp_health" ) or CreateClientConVar( "lukehack_esp_health", 0, true, false )
local WeaponSwitch 		= GetConVar( "lukehack_esp_weapon" ) or CreateClientConVar( "lukehack_esp_weapon", 0, true, false )
local UsergroupSwitch	= GetConVar( "lukehack_esp_usergroup" ) or CreateClientConVar( "lukehack_esp_usergroup", 0, true, false )
local TargetTypeSwitch 	= GetConVar( "lukehack_target_type" ) or CreateClientConVar( "lukehack_target_type", 1, true, false )
local CrosshairSwitch	= GetConVar( "lukehack_crosshair" ) or CreateClientConVar( "lukehack_crosshair", 0, true, false )
local WallhackSwitch	= GetConVar( "lukehack_wallhack" ) or CreateClientConVar( "lukehack_wallhack", 1, true, false )
local UpdateSwitch		= GetConVar( "lukehack_notify_update" ) or CreateClientConVar( "lukehack_notify_update", 1, true, false )
local LoadedSwitch		= GetConVar( "lukehack_notify_loaded" ) or CreateClientConVar( "lukehack_notify_loaded", 1, true, false )
local DeadSwitch		= GetConVar( "lukehack_esp_dead" ) or CreateClientConVar( "lukehack_esp_dead", 1, true, false )

local THColor = Color( 20, 20, 200 )

if LoadedSwitch:GetBool() then

	timer.Simple( 1, function()
		chat.AddText( THColor, "[Luke's Hack] ", Color( 255, 255, 255 ), "loaded" )
	end )

end

local function CheckUpdates()


end

if UpdateSwitch:GetBool() then

	--CheckUpdates()

end

local TARGET_TYPE 	= {}
TARGET_TYPE.ALL		= 1
TARGET_TYPE.PLY 	= 2
TARGET_TYPE.NPC		= 3

local Menu 			= {}

local BannedWeapons = { "" }

local DarkrpEnts = { "cash_printer", "ent_fuelcan", "ent_pot", "ent_pot_leaf", "ent_prop_item", "ent_roadspikes", "spawned_money" }

local function GetPlayerIndex( ply )

	for k,v in pairs ( player.GetAll() ) do

		if v == ply then return k end

	end

end

local function GetPlayerByIndex( index )

	for k,v in pairs ( player.GetAll() ) do
	
		if k == index then return v end
	
	end

end

local function WeaponCheck()

	if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
		
		if table.HasValue( BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass() ) then return false end
		if LocalPlayer():GetActiveWeapon():Clip1() == 0 then return false end

		return true 

	end

end

local Bones = {

	{ "ValveBiped.Bip01_Head1", "Head" },
	{ "ValveBiped.Bip01_Spine", "Spine" }

}

local function GetSpecialBone( target )

	local Targets 	= {}
	local Bones 	= {}
	
	for k,v in pairs( Targets ) do
	
		if string.match( target, Targets[k] ) then
		
			return { use = true, bone = Bones[k] }
		
		end
	
	end
	
	return { use = false, bone = "" }
	
end

local function GetTarget( ent )

	if ent:IsValid() and ( ent:IsPlayer() or ent:IsNPC() ) then

		local Special = GetSpecialBone( ent )
	
		if Special.use == true then
		
			return ent:GetBonePosition( ent:LookupBone( Special.bone ) )
		
		else
	
			for k,v in pairs ( Bones ) do

				if BoneSwitch:GetInt() == k then

					return ent:GetBonePosition( ent:LookupBone( Bones[k][1] ) )
				
				end
			
			end
			
		end

	end

end

surface.CreateFont( "MenuLarge",
{
font = "MenuLarge",
size = 12,
weight = 12
})

local function StatusCheck( ply )

	if !ply:IsValid() then return false end
	if ply:IsWorld() then return false end
	if !( ply:IsPlayer() or ply:IsNPC() ) then return false end
	if FriendSwitch:GetBool() and ply:IsPlayer() and ply:GetFriendStatus() == "friend" then return false end
	if TeamSwitch:GetBool() and ply:IsPlayer() and ply:Team() == LocalPlayer():Team() then return false end
	if TargetSwitch:GetBool() and ply:SteamID() != GetConVarString( TargetSteam:GetName() ) then return false end
	if TargetTypeSwitch:GetInt() == TARGET_TYPE.PLY and !ply:IsPlayer() then return false end
	if TargetTypeSwitch:GetInt() == TARGET_TYPE.NPC and !ply:IsNPC() then return false end

	return true

end

local function GenerateName()

	local Name = ""
	
	for i=1, math.random( math.random( 4, 6 ), math.random( 8, 11 ) ) do
	
		Name = Name .. tostring( math.random( 1, 9 ) )
	
	end
	
	return Name

end

hook.Add( "CreateMove", GenerateName(), function( UCMD )

	local trace = LocalPlayer():GetEyeTrace()

	if trace.Entity:IsValid() and AimbotSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then

		UCMD:SetViewAngles( ( GetTarget( trace.Entity ) - LocalPlayer():GetShootPos() ):Angle() )

	end
	
	if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then

		if AutoshootSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then
		
				RunConsoleCommand( "+attack" )
				timer.Simple( 0.5, function()
					RunConsoleCommand( "-attack" )
				end )
		
		else
	
			if LocalPlayer():GetActiveWeapon():Clip1() == 0 then
		
				RunConsoleCommand( "+reload" )
				timer.Simple( 1, function()
					RunConsoleCommand( "-reload" )
				end )
			
			end

		end
	
	end

	if NorecoilSwitch:GetBool() and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

	end

end )

local function WeaponGet( ply )

	if ply:IsValid() and ply:GetActiveWeapon() and ply:GetActiveWeapon():IsValid() then

		return ply:GetActiveWeapon():GetClass()

	else

		return "N/A"

	end

end

local function UsergroupGet( ply )

	if ply:IsValid() then

			if ply:IsSuperAdmin() then
			
				return "Superadmin"
				
			elseif ply:IsAdmin() then
			
				return "Admin"
				
			else
				
				if pcall( function() ply:GetUserGroup() end ) then
					
					return ply:GetUserGroup()
					
				elseif pcall( function() ply:EV_GetRank() end ) then
				
					return ply:EV_GetRank()
					
				else
				
					return "Player"
					
				end
				
			end
			
	else

		return "N/A"

	end

end

hook.Add( "HUDPaint", GenerateName(), function()

	if ESPSwitch:GetBool() then
	
		for k,v in pairs ( player.GetAll() ) do

			local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Name = ""
			local nColor = Color( 255, 255, 255, 255 )
			
			if v != LocalPlayer() then Name = v:Name() end
			
			if !v:Alive() and DeadSwitch:GetBool() then
				Name = "*Dead* " .. Name 
				nColor = Color( 0,0,0,255 )			
			elseif !v:Alive() and !DeadSwitch:GetBool() then
				Name = ""
				nColor = Color( 0,0,0,0 )
			else
				nColor = team.GetColor( v:Team() ) 
			end

			draw.DrawText( Name, "MenuLarge", Position.x, Position.y, nColor, 1 )

			if HealthSwitch:GetBool() and v != LocalPlayer() then
				draw.DrawText( "HP: " .. v:Health(), "Default", Position.x , Position.y + 12, nColor, 1 )
			end

			if WeaponSwitch:GetBool() and v != LocalPlayer() then

				local Math
				if HealthSwitch:GetBool() then Math = 22 else Math = 12 end

				draw.DrawText( "Weapon: " .. WeaponGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

			end

			if UsergroupSwitch:GetBool() and v != LocalPlayer() then

				local Math
				if WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
					Math = 32
				elseif !HealthSwitch:GetBool() and WeaponSwitch:GetBool() or !WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
					Math = 22
				else
					Math = 12
				end

				draw.DrawText( "Usergroup: " .. UsergroupGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

			end

		end

	end

	if DarkrpSwitch:GetBool() then

		for _,ent in pairs ( ents.GetAll() ) do

			if ent:IsValid() and table.HasValue( DarkrpEnts, ent:GetClass() ) then

				local Position = ent:GetPos():ToScreen()
				draw.DrawText( ent:GetClass(), "MenuLarge", Position.x, Position.y, nColor, 1 )
				
				cam.Start3D( LocalPlayer():GetPos() + Vector( 0, 0, 64 ), LocalPlayer():EyeAngles() )
					ent:DrawModel()
				cam.End3D()

			end

		end

	end
	
	if CrosshairSwitch:GetBool() then
	
		draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) )
	
	end
	
	if WallhackSwitch:GetBool() then
	
		for k,v in pairs ( player.GetAll() ) do
		
			local Pos
			local Ang = LocalPlayer():GetAngles()
			
			if LocalPlayer():Crouching() then
				Pos = LocalPlayer():GetPos() + Vector( 0, 0, 28 )
			else
				Pos = LocalPlayer():GetPos() + Vector( 0, 0, 64 )
			end
		
			cam.Start3D( Pos, LocalPlayer():EyeAngles() )
		
			v:DrawModel()
			
			if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				v:GetActiveWeapon():DrawModel()
			end
			
			cam.End3D()
		
		end
	
	end

end )

local function GetPlayerBySteamID( SteamID )

	for k,v in pairs ( player.GetAll() ) do
	
		if v:SteamID() == SteamID then return v end
	
	end

end

concommand.Add( "+save_replay", function()
	
	Menu.Main = vgui.Create( "DFrame")
	--Menu.Main:SetSize( 380, 300 )
	Menu.Main:SetSize( 760, 600 )
	Menu.Main:SetTitle( "LukeHack " .. Version .. " - By Luke" )
	Menu.Main:Center()
	Menu.Main:MakePopup()
	Menu.Main:SetSkin("luke_hack_steam")

	local AdvTab = vgui.Create( "DPropertySheet", Menu.Main )
	AdvTab:SetPos( 5, 25 )
	AdvTab:SetSize( 760, 600 )


	local Page1 = vgui.Create( "DImage" )
	--Page1:SetImage( Menu.Image )
	AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot configuration" )
	
	local AimbotToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	AimbotToggle:SetPos( 10, 10 )
	AimbotToggle:SetText( "Aimbot" )
	AimbotToggle:SetValue( GetConVar( AimbotSwitch:GetName() ):GetInt() )
	AimbotToggle:SetConVar( AimbotSwitch:GetName() )
	AimbotToggle:SizeToContents()

	local AimbotTarget = vgui.Create( "DComboBox", Page1 )
	AimbotTarget:SetPos( 250, 5 )
	AimbotTarget:SetSize( 100, 20 )
	for k,v in pairs ( Bones ) do
		AimbotTarget:AddChoice( Bones[k][2] )
	end
	AimbotTarget:ChooseOptionID( BoneSwitch:GetInt() )
	AimbotTarget.OnSelect = function( index, value, data )
		RunConsoleCommand( BoneSwitch:GetName(), math.Round( value ) )
	end
	
	AimbotToggle.OnChange = function()
		AimbotTarget:SetVisible( AimbotSwitch:GetBool() )
	end

	local AutoshootToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	AutoshootToggle:SetPos( 10, 40 )
	AutoshootToggle:SetText( "Autoshoot" )
	AutoshootToggle:SetValue( AutoshootSwitch:GetInt() )
	AutoshootToggle:SetConVar( AutoshootSwitch:GetName() )
	AutoshootToggle:SizeToContents()

	local NorecoilToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	NorecoilToggle:SetPos( 10, 70 )
	NorecoilToggle:SetText( "No-recoil" )
	NorecoilToggle:SetValue( NorecoilSwitch:GetInt() )
	NorecoilToggle:SetConVar( NorecoilSwitch:GetName() )
	NorecoilToggle:SizeToContents()

	local TeamToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	TeamToggle:SetPos( 10, 100 )
	TeamToggle:SetText( "Ignore team-mates" )
	TeamToggle:SetValue( TeamSwitch:GetInt() )
	TeamToggle:SetConVar( TeamSwitch:GetName() )
	TeamToggle:SizeToContents()

	local FriendToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	FriendToggle:SetPos( 10, 130 )
	FriendToggle:SetText( "Ignore steam friends" )
	FriendToggle:SetValue( FriendSwitch:GetInt() )
	FriendToggle:SetConVar( FriendSwitch:GetName() )
	FriendToggle:SizeToContents()

	local TargetToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	TargetToggle:SetPos( 10, 160 )
	TargetToggle:SetText( "Specific target" )
	TargetToggle:SetValue( TargetSwitch:GetInt() )
	TargetToggle:SetConVar( TargetSwitch:GetName() )
	TargetToggle:SizeToContents()
	
	local TargetList = vgui.Create( "DComboBox", Page1 )
	TargetList:SetPos( 220, 155 )
	TargetList:SetSize( 130, 20 )
	for k,v in pairs ( player.GetAll() ) do
		TargetList:AddChoice( v:Name() )
	end
	TargetList:ChooseOptionID( GetPlayerIndex( GetPlayerBySteamID( GetConVarString( TargetSteam:GetName() ) ) ) or 1 )
	TargetList.OnSelect = function( index, value, data )
		RunConsoleCommand( TargetSteam:GetName(), GetPlayerByIndex( value ):SteamID() )
	end
	
	TargetToggle.OnChange = function( index, value, data )
		TeamToggle:SetDisabled( TargetSwitch:GetBool() )
		FriendToggle:SetDisabled( TargetSwitch:GetBool() )
		TargetList:SetVisible( TargetSwitch:GetBool() )
	end

	local InfoSelect = vgui.Create( "DLabel", Page1 )
	InfoSelect:SetPos( 20, 190 )
	InfoSelect:SetText( "Target:" )
	InfoSelect:SizeToContents()

	local TargetType = vgui.Create( "DComboBox", Page1 )
	TargetType:SetPos( 60, 185 )
	TargetType:SetSize( 70, 20 )
	TargetType:AddChoice( "All" )
	TargetType:AddChoice( "Player" )
	TargetType:AddChoice( "NPC" )
	TargetType:ChooseOptionID( TargetTypeSwitch:GetInt() )
	TargetType.OnSelect = function( index, value, data )
		RunConsoleCommand( TargetTypeSwitch:GetName(), math.Round( value ) )
	end

	local Page2 = vgui.Create( "DImage" )
	--Page2:SetImage( Menu.Image )
	AdvTab:AddSheet( "Wallhack", Page2, "gui/silkicons/group", false, false, "Wallhack configuration" )

	local WallhackToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	WallhackToggle:SetPos( 10, 10 )
	WallhackToggle:SetText( "Wallhack" )
	WallhackToggle:SetValue( WallhackSwitch:GetInt() )
	WallhackToggle:SetConVar( WallhackSwitch:GetName() )
	WallhackToggle:SizeToContents()
	
	local ESPToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	ESPToggle:SetPos( 10, 40 )
	ESPToggle:SetText( "ESP" )
	ESPToggle:SetValue( ESPSwitch:GetInt() )
	ESPToggle:SetConVar( ESPSwitch:GetName() )
	ESPToggle:SizeToContents()

	local HealthToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	HealthToggle:SetPos( 30, 70 )
	HealthToggle:SetText( "Show health")
	HealthToggle:SetValue( HealthSwitch:GetInt() )
	HealthToggle:SetConVar( HealthSwitch:GetName() )
	HealthToggle:SizeToContents()

	local WeaponToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	WeaponToggle:SetPos( 30, 100 )
	WeaponToggle:SetText( "Show weapon" )
	WeaponToggle:SetValue( WeaponSwitch:GetInt() )
	WeaponToggle:SetConVar( WeaponSwitch:GetName() )
	WeaponToggle:SizeToContents()

	local UsergroupToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	UsergroupToggle:SetPos( 30, 130 )
	UsergroupToggle:SetText( "Show usergroup" )
	UsergroupToggle:SetValue( UsergroupSwitch:GetInt() )
	UsergroupToggle:SetConVar( UsergroupSwitch:GetName() )
	UsergroupToggle:SizeToContents()
	
	local DeadToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	DeadToggle:SetPos( 30, 160 )
	DeadToggle:SetText( "Show dead players" )
	DeadToggle:SetValue( DeadSwitch:GetInt() )
	DeadToggle:SetConVar( DeadSwitch:GetName() )
	DeadToggle:SizeToContents()

	ESPToggle.OnChange = function()
		HealthToggle:SetDisabled( !ESPSwitch:GetBool() )
		WeaponToggle:SetDisabled( !ESPSwitch:GetBool() )
		UsergroupToggle:SetDisabled( !ESPSwitch:GetBool() )
		DeadToggle:SetDisabled( !ESPSwitch:GetBool() )
	end

	local CrosshairToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	CrosshairToggle:SetPos( 10, 190 )
	CrosshairToggle:SetText( "Draw crosshair" )
	CrosshairToggle:SetValue( CrosshairSwitch:GetInt() )
	CrosshairToggle:SetConVar( CrosshairSwitch:GetName() )
	CrosshairToggle:SizeToContents()

	
	local Page3 = vgui.Create( "DImage" )
	--Page3:SetImage( Menu.Image )
	AdvTab:AddSheet( "PERP Hacks", Page3, "gui/silkicons/world", false, false, "All the hacks for PERP" )
	
	local UpdateButton = vgui.Create( "DButton", Page3 )
	UpdateButton:SetPos( 10, 10 )
	UpdateButton:SetSize( 300, 40 )
	UpdateButton:SetText( "Fix Me Up." )

	UpdateButton.DoClick = function()
		RunConsoleCommand('sh_fixme_lh');
	end
	
	local fmButton = vgui.Create( "DButton", Page3 )
	fmButton:SetPos( 10, 70 )
	fmButton:SetSize( 300, 40 )
	fmButton:SetText( "PERP Item ESP." )

	fmButton.DoClick = function()
		RunConsoleCommand('ent_esp_perp');
	end
	
	local UpdateButton = vgui.Create( "DButton", Page3 )
	UpdateButton:SetPos( 10, 130 )
	UpdateButton:SetSize( 300, 40 )
	UpdateButton:SetText( "PERP Cash Hack." )

	UpdateButton.DoClick = function()
		RunConsoleCommand('perp_s_b');
		RunConsoleCommand('perp_s_r');
	end
	
	local gu2Button = vgui.Create( "DButton", Page3 )
	gu2Button:SetPos( 10, 190 )
	gu2Button:SetSize( 300, 40 )
	gu2Button:SetText( "PERP gu 2" )

	gu2Button.DoClick = function()
		RunConsoleCommand("perp_gu", "2");
	end
	
	local Page4 = vgui.Create( "DImage" )
	--Page3:SetImage( Menu.Image )
	AdvTab:AddSheet( "OCRP Hacks", Page4, "gui/silkicons/world", false, false, "All the hacks for OCRP" )
	
	local ocrpccButton = vgui.Create( "DButton", Page4 )
	ocrpccButton:SetPos( 10, 10 )
	ocrpccButton:SetSize( 300, 40 )
	ocrpccButton:SetText( "Spawn Cop Car" )

	ocrpccButton.DoClick = function()
		RunConsoleCommand('ocrp_spawnpolice');
	end
	
	local ocrpftButton = vgui.Create( "DButton", Page4 )
	ocrpftButton:SetPos( 10, 70 )
	ocrpftButton:SetSize( 300, 40 )
	ocrpftButton:SetText( "Spawn FireTruck" )

	ocrpftButton.DoClick = function()
		RunConsoleCommand('ocrp_spawnfireengine');
	end
	
	local ocrpespButton = vgui.Create( "DButton", Page4 )
	ocrpespButton:SetPos( 10, 130 )
	ocrpespButton:SetSize( 300, 40 )
	ocrpespButton:SetText( "OCRP Item ESP." )

	ocrpespButton.DoClick = function()
		RunConsoleCommand('ent_esp_ocrp');
	end
	
	local Page5 = vgui.Create( "DImage" )
	--Page3:SetImage( Menu.Image )
	AdvTab:AddSheet( "DarkRP Hacks", Page5, "gui/silkicons/world", false, false, "All the hacks for DarkRP" )
	
	local drpiesp = vgui.Create( "DButton", Page5 )
	drpiesp:SetPos( 10, 10 )
	drpiesp:SetSize( 300, 40 )
	drpiesp:SetText( "Darkrp Item ESP." )

	drpiesp.DoClick = function()
		RunConsoleCommand('ent_esp_drp');
	end

	local Page6 = vgui.Create( "DImage" )
	--Page3:SetImage( Menu.Image )
	AdvTab:AddSheet( "Credits", Page6, "gui/silkicons/world", false, false, "Luke Hacks Credits" )
	
	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 10 )
	UpdateToggle:SetText( "Luke Hack Credits" )
	UpdateToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 30 )
	UpdateToggle:SetText( "Vaqxination - Porting and fixing some shit" )
	UpdateToggle:SizeToContents()

	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 40 )
	UpdateToggle:SetText( "Luke - Coding" )
	UpdateToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 70 )
	UpdateToggle:SetText( "Pengi - Exploits" )
	UpdateToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 100 )
	UpdateToggle:SetText( "Anon Cookie - Testing" )
	UpdateToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DLabel", Page6 )
	UpdateToggle:SetPos( 10, 130 )
	UpdateToggle:SetText( "CrackStealer - Testing" )
	UpdateToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DLabel", Page99 )
	UpdateToggle:SetPos( 10, 10 )
	UpdateToggle:SetText( "Luke Hack - Official Version" )
	UpdateToggle:SizeToContents()
end )

concommand.Add( "-save_replay", function()

	Menu.Main:Remove()

end )
////////////
// HACKS //
///////////



function FixAllOfMe()
        RunConsoleCommand("perp2_encrypt3D_resetHealth")
        RunConsoleCommand("perp2_encrypt3D_resetCrippled")
        print("[LukeHack] you have fixed your legs and healed yourself!")
end
concommand.Add("sh_fixme_lh", FixAllOfMe)</pre></body></html>