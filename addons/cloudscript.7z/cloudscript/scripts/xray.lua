
<!-- saved from url=(0065)https://dl.dropboxusercontent.com/u/91139226/CloudScript/xray.txt -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=US-ASCII"><style type="text/css"></style></head><body><pre style="word-wrap: break-word; white-space: pre-wrap;">--[[ 
		Product: Propkill XRay
		Author: Tyler with help from victoriqui
		updated for gmod 13
		public script, posted on my pastebin.
		no, you didn't "leak" this.
--]]
local G					= table.Copy(_G);
local R 				= debug.getregistry() -- dumb
local AddConVar			= CreateClientConVar;
local AllowedProps		= { // Props that will be shown on the XRay
"models/props/de_tides/gate_large.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
"models/props_c17/furnitureStove001a.mdl",
"models/props_junk/sawblade001a.mdl",
"models/props_junk/TrashDumpster01a.mdl",
"models/props_combine/breendesk.mdl",
"models/props_c17/Lockers001a.mdl", -- one of the paths is fucked
"models/props/de_train/lockers001a.mdl", -- one of the paths is fucked
"models/props/de_train/lockers_long.mdl",
"models/props_canal/canal_bars004.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
};
local hack				= {};
local ORANGE			= Color(255,69,0,255)
local CYAN		 		= Color(0,255,255,255)
local RED	 			= Color(255,0,0,255)
local GREEN 			= Color(0,255,0,255)
local BLACK 			= Color(0,0,0,255)
local WHITE 			= Color(255,255,255,255)
local PINK 				= Color(255,0,255,255)
local BLUE 				= Color(0,0,255,255)
local YELLOW			= Color(255,255,0,255)
local GREY				= Color(50,50,50,255)
local COLOR_VISIBLE		= Color(0,255,0,150) // Can see [GREEN]
local COLOR_NONVISIBLE  = Color(255,0,0,150) // can't see [RED]
local COLOR_FROZEN		= Color(0,0,255,150) // Frozen (visible) [BLUE]
local COLOR_FROZEN_NV	= Color(255,255,0,150) // frozen (non visible) [YELLOW]
local TEAM_SPECTATOR 	= 1002;
local rcc 				= RunConsoleCommand;
local hookadd			= hook.Add;
local hookrem			= hook.Remove;
local cmdadd			= concommand.Add;
local cmdrem			= concommand.Remove;

surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Speed",{font = "akbar", size = 45, weight = 400, antialias = 0})

function RunConsoleCommand(cmd,...)
	print("RCC: "..cmd)
	return rcc(cmd,...)
end

// Simple notification message
function hack.notify(msg)
chat.AddText(
ORANGE, "[XRay]: ",
WHITE, msg.."")
end

// Better print message
function hack.print(msg)
print("[XRay]: "..msg)
end

// AddConVar function (Adds the cheat commands)
function AddConVar(convar,str,save,data )
	return CreateClientConVar( "xray_" .. convar, str, save, data ), hack.print("[XRay]: Added ConVar: xray_"..convar.."["..str.."]")
end

// Simple hooking system
local function AddHook(Type,Function)
	Name = tostring(math.random(1,1000)..math.random(1,1000)..math.random(1,1000))
	return hookadd(Type,Name,Function), hack.print("Added hook: ["..Type.."] ("..Name..")")
end

// Simple hack.RemoveHook (Useless to me)
local function RemoveHook(Type,Function)
	return hookrem(Type,Name), hack.print("Removed hook: ["..Type.."] ("..Name..")")
end

// Neater concommand.Add()
local function AddCMD(Name,Function)
	return cmdadd(Name,Function),hack.print("Added command: "..Name.."")
end

// Neater concommand.Remove()
local function RemoveCMD(Name)
	return cmdrem(Name), hack.print("Removed command"..Name.."");
end

// Adding the ConVars for the cheat
AddConVar("chams",0,true,false);
AddConVar("player",0,true,false);
AddConVar("bhop",0,true,false);
AddConVar("light",0,true,false);
AddConVar("thirdperson",0,true,false);
AddConVar("thirdperson_dist",100,true,false);
AddConVar("use",0,true,false);
AddConVar("mouse",0,true,false);
AddConVar("rp",0,true,false);

// Check if the entity is visible (Thanks, victoriqui)
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

// Create the material for the chams
local function XRayMat()	
local Texture = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}
local material = CreateMaterial( "xray_solid", "VertexLitGeneric", Texture )
return material
end

function XRay()
cam.Start3D(EyePos(), EyeAngles())
	for k,v in pairs(ents.FindByClass("prop_*")) do
	if (!CanSee(v)) then
		PropColor = COLOR_NONVISIBLE
	else
		PropColor = COLOR_VISIBLE
	end	
	if v:GetVelocity():Length() == 0 then
		PropColor = COLOR_FROZEN
	end
	if v:GetVelocity():Length() == 0 and (!CanSee(v)) then
		PropColor = COLOR_FROZEN_NV
	end
		if GetConVarNumber("XRay_chams") == 1 then
			if IsValid(v) and table.HasValue(AllowedProps,v:GetModel()) then
				v:SetColor(PropColor)
				v:SetMaterial("chams") -- get your own material, i used falco's xray material.
				v:SetRenderMode(RENDERMODE_TRANSALPHA)
			else
				v:SetColor(Color(255, 255, 255, 255))
			end
		end
	end
cam.End3D()
end

function Think()
	if GetConVarNumber("xray_bhop") == 1 then
		if input.IsKeyDown( KEY_SPACE ) then
			if LocalPlayer():IsOnGround() then
				rcc("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() rcc("-Jump") end)
			end
		end
	end
	if GetConVarNumber("xray_light") == 1 then
		rcc("impulse","100")
	end
	if GetConVarNumber("xray_use") == 1 then
		if input.IsKeyDown( KEY_E ) then
			rcc("+use")
			timer.Create("usespam",0.01, 0 ,function() rcc("-use") end)
		end
	end
	if GetConVarNumber("xray_mouse") == 1 then
		if input.IsKeyDown( MOUSE_LEFT ) then
			rcc("+attack")
			timer.Create("mouse1spam",0.01, 0 ,function() rcc("-attack") end)
		end
	end
	if GetConVarNumber("xray_rp") == 1 then
		rcc("_DarkRP_DoAnimation", "1627")
	end
end

AddHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("xray_thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("xray_thirdperson_dist"))
		view.angles = angles
		view.fov = fov
		return view
	end
end)
AddHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("xray_thirdperson") == 1 then
		return true
	end
end)

// Player chams function
function Chams()
	for k,v in pairs(player.GetAll()) do
		local Div = (1 / 255)
		local Div2 = ( 0 / 0 )
		local m = XRayMat()
			if GetConVarNumber("xray_player") == 1 then
				if IsValid(v) and v:Health() &gt; 0 and v:Team() != TEAM_SPECTATOR then
					cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(255,0,0)
					render.MaterialOverride( m )
					v:DrawModel()
					render.SuppressEngineLighting( false )
					render.SetColorModulation(1,1,1)
					render.MaterialOverride( )
					cam.End3D()
				end
			end
	end
end

function HUDPaint()
local speed = math.floor(LocalPlayer():GetVelocity():Length())
draw.SimpleTextOutlined("Speed: "..speed,"Speed",600,15,Color(255,255,255,255),4,1,1,Color(0,0,0,255))
cam.Start3D(LocalPlayer():GetShootPos(), LocalPlayer():EyeAngles())
	if GetConVarNumber("xray_player") == 1 then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				if v and v:IsValid() and v:Alive() then
					render.SetMaterial(Material("cable/hydra"))
					local t = {}
					t.start = v:GetShootPos()
					t.endpos = v:GetShootPos() + Vector(0, 0, 99999999)
					t.filter = v
					local trace = util.TraceLine(t)
					render.DrawBeam(trace.HitPos, v:GetShootPos(), 20, 1, 1, Color(255,255,255,255))
				end
			end
		end
	end
cam.End3D()
end

-- useless, but fun.
/*
AddHook("OnEntityCreated",function(ent)
	for k,v in pairs(ents.FindByClass("prop_*")) do
		if GetConVarNumber("xray_chams") == 1 then
			if IsValid(v) and table.HasValue(AllowedProps,v:GetModel()) then
				surface.PlaySound("buttons/button19.wav") 
			end
		end
	end
end)
*/

// Load hooks
function LoadHooks()
hack.print("loading hooks.")
AddHook("RenderScreenspaceEffects",XRay);
AddHook("RenderScreenspaceEffects",Chams);
AddHook("Think",Think);
AddHook("HUDPaint",HUDPaint);
end
LoadHooks();

function Unload()
rcc("xray_chams","0")
rcc("xray_player","0")
rcc("xray_bhop","0")
rcc("xray_light","0")
rcc("xray_thirdperson","0")
rcc("xray_rp","0")
RemoveHook("RenderScreenSpaceEffects",XRay);
RemoveHook("RenderScreenspaceEffects",Chams);
RemoveHook("HUDPaint",HUDPaint);
RemoveHook("Think",Think);
RemoveCMD("xray_menu")
end

function UnloadHooks()
RemoveHook("RenderScreenSpaceEffects",XRay);
RemoveHook("RenderScreenspaceEffects",Chams);
RemoveHook("Think",Think);
RemoveHook("HUDPaint",HUDPaint);
end

function ReloadHooks()
UnloadHooks();
LoadHooks();
end


// Admin mod bypasses (Blinds,gags)
AddCMD("xray_bypass",function()
RemoveHook("PlayerBindPress", "ULXGagForce") // bypass ULX gag
timer.Destroy("GagLocalPlayer") // Bypass Gags
if LocalPlayer():GetNWBool("EV_Blinded") then
	LocalPlayer():SetNWBool("EV_Blinded", false) // Bypass Evolve blind
end
if LocalPlayer():GetNWBool("Muted") then
	LocalPlayer():SetNWBool("Muted", false) // Bypass Mutes
end
hack.notify("Attempted to bypass Gags/Mutes/Blinds")
end)

// AddCheckBox function. makes it easier to add a checkbox
function AddCheckBox( text, cvar, parent, x, y, tt )
	local checkbox = vgui.Create( "DCheckBoxLabel", parent )
	checkbox:SetPos( x, y )
	checkbox:SetText( text )
	checkbox:SetConVar( cvar )
	if( tt ) then checkbox:SetTooltip( tt ) end	
	checkbox:SizeToContents()	
end

AddCMD("xray_menu",function()
local Panel = vgui.Create("DFrame")
Panel:SetTitle("XRay :: Config")
Panel:SetSize(160,290)
Panel:Center()
Panel:ShowCloseButton(true)
Panel:MakePopup()

local Bypass = vgui.Create( "DButton")
Bypass:SetText( "Bypasses" )
Bypass:SetParent( Panel )
Bypass:SetPos( 10, 220 )
Bypass:SetWide( 140 )
Bypass:SetTall( 20 )
Bypass:SetToolTip("Ungag/Unmute/Unblind")
Bypass.DoClick = function()
rcc("xray_bypass")
end

local ReloadXRay = vgui.Create( "DButton")
ReloadXRay:SetText( "Reload Hooks" )
ReloadXRay:SetParent( Panel )
ReloadXRay:SetPos( 10, 240 )
ReloadXRay:SetWide( 140 )
ReloadXRay:SetTall( 20 )
ReloadXRay:SetToolTip("This will reload the hooks")
ReloadXRay.DoClick = function()
ReloadHooks()
end

local UnloadXRay = vgui.Create( "DButton")
UnloadXRay:SetText( "Unload XRay" )
UnloadXRay:SetParent( Panel )
UnloadXRay:SetPos( 10, 260 )
UnloadXRay:SetWide( 140 )
UnloadXRay:SetTall( 20 )
UnloadXRay:SetToolTip("This will unload the cheat")
UnloadXRay.DoClick = function()
Unload()
end


AddCheckBox("Prop XRay","xray_chams",Panel,10,25,"Shows props through objects.")
AddCheckBox("Player ESP","xray_player",Panel,10,45,"Find players.")
AddCheckBox("Bunnyhop","xray_bhop",Panel,10,65,"Allows you to bunnyhop by holding 'space'")
AddCheckBox("Light Spam","xray_light",Panel,10,85,"Spams the flashlight")
AddCheckBox("Use Spam","xray_use",Panel,10,105,"Spams +use")
AddCheckBox("DarkRP Animation","xray_rp",Panel,10,125,"Exploit for DarkRP animation.")
--AddCheckBox("Auto Shoot","xray_mouse",Panel,10,125,"Hold left click to shoot fast")
end)
</pre></body></html>