/*
coded by nomical
*/
local data = {
	host = "https://dl.dropbox.com/u/150309237/", // host's dropbox
	link = "https://dl.dropbox.com/u/150309237/CloudScript/database.txt", // Where all public scripts will be stored.
	source = nil,
	scriptnames = {},
	percent = 0,
	fix = false
}

surface.CreateFont("Medium",{font = "coolvetica", size = 45, weight = 300, antialias = 0})
surface.CreateFont("Normal",{font = "default", size = 20, weight = 200, antialias = 0})

function data.grabdatabase( contents )
	data.database = contents
end

function data.grabscript( contents )
	data.source = contents
end

function data.updatepercent( var )
	if ( var == nil ) then
		data.percent = data.percent + 15
		else
		data.percent = 100
		timer.Simple( 1,function()
			data.percent = 101
			timer.Simple( .5,function()
				data.percent = 0
				timer.Destroy( "Cloud-updatepercent" )
			end )
		end )
	end
end

function data.read( arg )
	if ( !arg ) then return end
	for _,script in pairs( data.scriptlinks ) do
		data.scriptnames[_] = string.gsub(script, data.host, "" )
		if ( string.lower( string.gsub(script, data.host,"" ) ) == string.lower( arg )  ) then
			http.Fetch( script, data.grabscript )
			chat.AddText( Color( 255,255,0,255 ),"[ScriptCloud] ",Color( 255,255,255,255 ),string.gsub( script, data.host,"" ) .. " is installing..." )
		end
	end
end

function data.retrievedata()
	data.scriptlinks = nil
	/* Begin Data Retrieval */
	http.Fetch( data.link,data.grabdatabase )
	timer.Create( "GetDataBase",1,0,function()
		if ( data.database != nil ) then
			data.scriptlinks = string.Explode( ";", data.database )
			timer.Destroy( "GetDataBase" )
		end
	end )
	/* End Data Retrieval */
	timer.Create( "TryVar",1,0,function()
		if ( data.scriptlinks != nil ) then
			Msg( "All data retrieved!\n" )
			data.read( " " )
			timer.Destroy( "TryVar" )
			else
			Msg( "Retrieving data... \n" )
		end
		data.updatepercent( data.scriptlinks )
	end )
end

function data.download( ply,cmd,args )
	if ( args[1] == nil ) then return end
	timer.Create( "TryScript",1,0,function()
		if ( !data.fix ) then
			data.read( args[1] )
			data.fix = true
		end
		data.updatepercent( data.source )
		if ( data.source != nil ) then
			/* Store Installed Script */
			if ( !file.IsDir( "CloudScript", "DATA" ) ) then
				file.CreateDir( "CloudScript", "DATA" )		
			end	
			if ( !file.Exists( args[1], "DATA" ) ) then
				file.Write( args[1],data.source) // Installs to CloudScript/FILENAME.txt
			end 
			/* Destroy Data */
			timer.Destroy( "TryScript" )
			data.source = nil
			data.fix = false
		end
	end )
end

/* Splash Screen - Gui */

function data.painttextoutlined( x,y,font,text,col,bgcol )
    if ( !text ) then return end
    draw.SimpleTextOutlined( text,font,x,y,col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,1,bgcol )
end

function data.painttext( x,y,font,text,col )
    if ( !text ) then return end
    draw.SimpleText( text,font,x,y,col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
end

function data.paintbackground( width,height,x,y,col,bgcolor )
    /* Fill */
    surface.SetDrawColor( col )
    surface.DrawRect( x,y,width,height )
    /* Outline */
    surface.SetDrawColor( bgcolor )
    surface.DrawOutlinedRect( x,y,width,height )
end

function data.paintbar( min,max,cur,width,height,x,y,col,bgcolor )
    local mul = width / max
    local mcur = cur * mul
        
    /* Fill */
    surface.SetDrawColor( col )
    surface.DrawRect( x,y,math.Clamp( mcur,min,width ),height )
    /* Highlight */
    surface.SetDrawColor( Color( 255,255,255,10 ) )
    surface.DrawRect( x,y,math.Clamp( mcur,min,width ),height / 2 ) 
    /* Outline */
    surface.SetDrawColor( bgcolor )
    surface.DrawOutlinedRect( x,y,width,height )       
end

function data.splash()
    /* Background */
    data.paintbackground( 250,150,ScrW() / 2 - 250 / 2,ScrH() / 2 - 150 / 2,Color( 0,0,0,255 ),Color( 255,255,255,255 ) )
    /* Text */
    data.painttextoutlined( ScrW() / 2 - 250 / 2 + 120,ScrH() / 2 - 150 / 2 + 50,"Medium","Script Cloud",Color( 80,80,80,255 ),Color( 255,255,255,255 ) )
    /* Other */
    data.paintbar( 0,100,data.percent,150,18,ScrW() / 2 - 250 / 2 + 50,ScrH() / 2 - 150 / 2 + 70,Color( 80,80,80,255 ),Color( 255,255,255,255 ) )
	if ( data.percent > 100 ) then
		hook.Remove( "HUDPaint","Cloud-Splash" )
	end
end

/* Gui */

function data.gui()
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( 350,300 )
	frame:SetPos( ScrW() / 2 - frame:GetWide() / 2,ScrH() / 2 - frame:GetTall() / 2 )
	frame:SetTitle( "Cloud Script Gui" )
	frame:ShowCloseButton( true )
	frame:SetVisible( true )
	frame.Paint = function()
		data.paintbackground( frame:GetWide(),frame:GetTall(),0,0,Color( 0,0,0,170 ),Color ( 255,255,255,255 ) )
	end
	frame:MakePopup()
	
	local sheet = vgui.Create( "DPropertySheet" )
	sheet:SetParent( frame )
	sheet:SetPos( 5,25 )
	sheet:SetSize( 340,270 )
	sheet.Paint = function()
		data.paintbackground( sheet:GetWide(),sheet:GetTall(),0,0,Color( 0,0,0,0 ),Color ( 0,0,0,0 ) )
	end
	
	local taba = vgui.Create( "DLabel" )
	taba:SetParent( sheet )
	taba:SetText( "" )
	taba:SizeToContents()
	taba.Paint = function()
		data.paintbackground( sheet:GetWide(),sheet:GetTall(),0,0,Color( 0,0,0,0 ),Color ( 255,255,255,255 ) )
	end
	
	local tabb = vgui.Create( "DLabel" )
	tabb:SetParent( sheet )
	tabb:SetText( "" )
	tabb:SizeToContents()
	tabb.Paint = function()
		data.paintbackground( sheet:GetWide(),sheet:GetTall(),0,0,Color( 0,0,0,0 ),Color ( 255,255,255,255 ) )
	end
	
	local function setlistdl()
		local lista = vgui.Create( "DListView" )
		lista:SetParent( taba )
		lista:SetPos( 10, 10 )
		lista:SetSize( 165, 260 )
		lista:SetMultiSelect( false )
		lista:AddColumn( "Scripts" )
		for k,v in pairs( data.scriptnames ) do	
			if ( !file.Exists( v, "DATA") ) then
				lista:AddLine( v )
			end
		end
		lista.OnRowSelected = function( panel , line )
			data.dlselection = lista:GetLine( line ):GetValue(1)
		end
	end
	setlistdl()
	
	local function setlistrn()
		local listb = vgui.Create( "DListView" )
		listb:SetParent( tabb )
		listb:SetPos( 10, 10 )
		listb:SetSize( 165, 260 )
		listb:SetMultiSelect( false )
		listb:AddColumn( "Scripts" )
		for k,v in pairs( data.scriptnames ) do	
			if ( file.Exists( v, "DATA" ) ) then
				listb:AddLine( v )
			end
		end
		listb.OnRowSelected = function( panel , line )
			data.rnselection = listb:GetLine( line ):GetValue(1)
		end
	end
	setlistrn()
	
	local bar = vgui.Create( "DPanel" )
	bar:SetParent( taba )
	bar:SetPos( 212,115 )
	bar:SetSize( 100,17 )
	bar.Paint = function()
		data.paintbar( 0,100,data.percent,100,17,0,0,Color( 80,80,80,255 ),Color( 255,255,255,255 ) )
	end
	
	local button = vgui.Create( "DButton" )
	button:SetSize( 100,35 )
	button:SetPos( 212.5,60 )
	button:SetText( "Retrieve Data" )
	button:SetParent( taba )
	button.DoClick = function()
		RunConsoleCommand( "Cloud_RetrieveData" )
		timer.Create( "UpdateDlList",.1,0,function()
				if ( data.percent > 100 ) then
					setlistdl()
					timer.Destroy( "UpdateDlList" )
				end
		end )
	end 
	
	local button2 = vgui.Create( "DButton" )
	button2:SetSize( 100,35 )
	button2:SetPos( 212.5,150 )
	button2:SetText( "Install" )
	button2:SetParent( taba )
	button2.DoClick = function()
		if ( data.dlselection != nil ) then
			RunConsoleCommand( "Cloud_Download",data.dlselection )
			timer.Create( "UpdateDlList",.1,0,function()
				if ( data.percent > 100 ) then
					setlistdl()
					setlistrn()
					timer.Destroy( "UpdateDlList" )
				end
			end )
		end
	end 
	
	local button3 = vgui.Create( "DButton" )
	button3:SetSize( 100,35 )
	button3:SetPos( 212.5,80 )
	button3:SetText( "Execute" )
	button3:SetParent( tabb )
	button3.DoClick = function()
		if ( data.rnselection != nil ) then
			if ( file.Find( string.lower( data.rnselection ), "DATA" ) )  then
				chat.AddText( Color( 0,255,0,255 ),"[ScriptCloud] ",Color( 255,255,255,255 ),data.rnselection.." is executing..." )
				RunString( file.Read( string.lower( data.rnselection ) ), "DATA" )
			end
		end
	end
	
	local button4 = vgui.Create( "DButton" )
	button4:SetSize( 100,35 )
	button4:SetPos( 212.5,130 )
	button4:SetText( "Delete" )
	button4:SetParent( tabb )
	button4.DoClick = function()
		if ( data.rnselection != nil ) then
			if ( file.Find( string.lower( data.rnselection ), "DATA" ) )  then
				chat.AddText( Color( 255,0,0,255 ),"[ScriptCloud] ",Color( 255,255,255,255 ),data.rnselection.." deleted!" )
				file.Delete( string.lower( data.rnselection ), "DATA" )
				timer.Simple( .3,function()
					setlistrn()
					setlistdl()
				end )
			end
		end
	end
	
	sheet:AddSheet( "Cloud",taba,"gui/silkicons/world",false,false,"Install Scripts" )
	sheet:AddSheet( "Installed",tabb,"gui/silkicons/user",false,false,"Run Scripts" )
	
end


/* Add ConCommands And Hook(s) */

concommand.Add( "Cloud_RetrieveData",data.retrievedata )
concommand.Add( "Cloud_Download",data.download )
concommand.Add( "Cloud_GUI",data.gui )

hook.Add( "HUDPaint","Cloud-Splash",data.splash )

RunConsoleCommand( "Cloud_RetrieveData" )