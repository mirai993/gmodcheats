if not DarkRP then
    print("Only works in DarkRP and not other gamemodes, for safty")
    return
end

local GG = {}
GG.WP = {}
GG.WP['Aimbot'] = true
GG.WP['Big_Aimbot'] = false
GG.WP.StoreTarg = {}
local dasl = _G.FindMetaTable
local b = table
local t = b.Copy(dasl("Player"))
GG.ply = dasl("Player")
function GG.ply:EyeVisible(ent)
    if not IsValid(ent) then return end
    local trace = {
        start = self:LocalToWorld(self:OBBCenter()),
        endpos = ent:LocalToWorld(ent:OBBCenter()),
        filter = {self, ent},
        mask = 1174421507
    }

    local tr = util.TraceLine(trace)
    return tr.Fraction == 1
end

GG.Targ = function()
    if GG.WP['Big_Aimbot'] == true then
        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() then table.insert(GG.WP.StoreTarg, v) end
        end

        local targ = LocalPlayer():GetEyeTrace().Entity
        if targ and not targ:IsPlayer() then return end
        return targ
    end

    if GG.WP['Big_Aimbot'] == false then
        if #GG.WP.StoreTarg > #player.GetAll() - 1 then GG.WP.StoreTarg = {} end
        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() and LocalPlayer():EyeVisible(v) and v:Health() > 0 then table.insert(GG.WP.StoreTarg, v) end
        end
        return table.Random(GG.WP.StoreTarg)
    end
end

local d = b.Copy(dasl("Entity"))
GG.Rand = function(tbl) return tbl[math.random(1, #tbl)] end
local target = NULL
GG.ChooseBonesHead = "ValveBiped.Bip01_Head1"
GG.ChooseBonesNeck = "ValveBiped.Bip01_Neck1"
GG.ChooseBonesSpine = "ValveBiped.Bip01_Spine"
GG.ChooseBonesAll = "ValveBiped.Bip01_Spine"
GG.ChooseBones = {GG.ChooseBonesHead}
GG.GTP = function(ta)
    local i = ta:LookupAttachment("eyes")
    return ta:GetAttachment(i).Pos
end

GG.RunFunc = function()
    local wep = LocalPlayer():GetActiveWeapon()
    if IsValid(wep) then if not string.find(string.lower(wep:GetClass()), "weapon_") then return end end
    if IsValid(wep) and wep:Clip1() <= 0 then
        LocalPlayer():ConCommand("+reload")
        timer.Simple(0.2, function() LocalPlayer():ConCommand("-reload") end)
    end

    if LocalPlayer():KeyDown(IN_SPEED) and GG.WP['Aimbot'] == true and GG.WP['Big_Aimbot'] == true then target = GG.Targ() end
    if LocalPlayer():KeyDown(IN_ATTACK) and GG.WP['Aimbot'] == true then
        if GG.WP['Big_Aimbot'] == false then target = GG.Targ() end
        if target ~= nil and target ~= NULL and target:Health() > 0 then
            if LocalPlayer():EyeVisible(target) and target:IsPlayer() then
                if IsValid(wep) and wep.Primary ~= nil then
                    wep.Primary.Recoil = 0
                    wep.Primary.Cone = 0
                end

                t:SetEyeAngles((GG.GTP(target) - LocalPlayer():GetShootPos()):Angle())
            end
        end
    end
end

GG.CustomTimer = function()
    GG.RunFunc()
    timer.Simple(0.0001, function() GG.CustomTimer() end)
end

GG.CustomTimer()