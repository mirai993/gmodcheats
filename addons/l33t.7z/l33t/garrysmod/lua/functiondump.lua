local Fail_Safe_Mode = false
if LeyAC then
    print("An Anticheat has been detected, Running in safe mode, _G Count [" .. tostring(table.Count(_G)) .. "] Nigger Leystryku ain't got nothing on me!")
    print("Now with aimbot, Enjoy ruining peoples experience again! :D")
    Fail_Safe_Mode = true
end

if Fail_Safe_Mode == true then
    local Ley_Is_Dumb = {}
    Ley_Is_Dumb.Cat_n_Mouse = {}
    function Ley_Is_Dumb.AnticheatEasyFind()
        for k, v in pairs(net.Receivers) do
            local toscan = debug.getinfo(v).short_src
            local scan = file.Read(toscan, "GAME")
            if scan ~= nil then if not string.find(string.lower(scan), string.lower(k)) then table.insert(Ley_Is_Dumb.Cat_n_Mouse, k) end end
        end
    end

    Ley_Is_Dumb.AnticheatEasyFind()
    print("-----------------------")
    print("-Sniffed LeyAC netvars-")
    print("-----------------------")
    PrintTable(Ley_Is_Dumb.Cat_n_Mouse)
    print("-----------------------")
    if DarkRP then include("darkrp/entities/weapons/weapon_cs_base_num_/shared.lua") end
end

local GG = {}
local b = table
GG.Use_print_func = GG.Use_print_func or function() end
local pair, tba = pairs(_G)
local dasl = _G.FindMetaTable
local t = b.Copy(dasl("Player"))
local skype = type
local tbl_detoured_func = {
    {
        F = _G.chat.AddText,
        S = "[C]",
        D = false,
        T = "print"
    },
    {
        F = _G.Msg,
        S = "[C]",
        D = false,
        T = "print"
    },
    {
        F = _G.MsgN,
        S = "[C]",
        D = false,
        T = "print"
    },
    {
        F = _G.print,
        S = "[C]",
        D = false,
        T = "print"
    },
    {
        F = t.SetEyeAngles,
        S = "[C]",
        D = false,
        T = "aimbot"
    },
    {
        F = halo.Add,
        S = "lua/includes/modules/halo.lua",
        D = false,
        T = "halo.Add"
    },
}

GG.Isfunction = function(f)
    if skype(f) == "function" then return true end
    return false
end

GG.CheckDetectedDetouredFunc = function()
    for i = 1, #tbl_detoured_func do
        if GG.Isfunction(tbl_detoured_func[i].F) then
            if debug.getinfo(tbl_detoured_func[i].F).short_src == tbl_detoured_func[i].S and tbl_detoured_func[i].T == "print" then GG.Use_print_func = tbl_detoured_func[i].F end
            if debug.getinfo(tbl_detoured_func[i].F).short_src ~= tbl_detoured_func[i].S and tbl_detoured_func[i].T == "aimbot" then
                tbl_detoured_func[i].D = true
                tbl_detoured_func[i].S = debug.getinfo(tbl_detoured_func[i].F).short_src
                print("[Cheat AntiCheat] Aimbot has been detoured by " .. tostring(tbl_detoured_func[i].S) .. " Not running or you'll be banned!")
            end

            if debug.getinfo(tbl_detoured_func[i].F).short_src ~= tbl_detoured_func[i].S and tbl_detoured_func[i].T == "halo.Add" then
                tbl_detoured_func[i].D = true
                tbl_detoured_func[i].S = debug.getinfo(tbl_detoured_func[i].F).short_src
                print("[Cheat AntiCheat] halo.Add has been detoured by " .. tostring(tbl_detoured_func[i].S) .. " Not running or you'll be banned!")
            end
        end
    end
end

GG.CheckDetectedDetouredFunc()
GG.Use_print_func("-----------------------")
GG.Use_print_func("-[Good Game] -Starting-")
GG.Use_print_func("-----------------------")
GG.Plugin_Name = "Plugin Loaded"
GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name .. " GG Table Init")
GG.WP = {}
GG.WP['Aimbot'] = true
GG.WP['Big_Aimbot'] = false
GG.WP.StoreTarg = {}
GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name .. " Well Played Loaded")
GG.ply = dasl("Player")
function GG.ply:EyeVisible(ent)
    if not IsValid(ent) then return end
    local trace = {
        start = self:LocalToWorld(self:OBBCenter()),
        endpos = ent:LocalToWorld(ent:OBBCenter()),
        filter = {self, ent},
        mask = 1174421507
    }

    local tr = util.TraceLine(trace)
    return tr.Fraction == 1
end

GG.Targ = function()
    if GG.WP['Big_Aimbot'] == true then
        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() then table.insert(GG.WP.StoreTarg, v) end
        end

        local targ = LocalPlayer():GetEyeTrace().Entity
        if targ and not targ:IsPlayer() then return end
        return targ
    end

    if GG.WP['Big_Aimbot'] == false then
        if #GG.WP.StoreTarg > #player.GetAll() - 1 then GG.WP.StoreTarg = {} end
        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() and LocalPlayer():EyeVisible(v) and v:Health() > 0 then table.insert(GG.WP.StoreTarg, v) end
        end
        return table.Random(GG.WP.StoreTarg)
    end
end

local d = b.Copy(dasl("Entity"))
GG.Rand = function(tbl) return tbl[math.random(1, #tbl)] end
GG.Timer = 0
local target = NULL
GG.ChooseBonesHead = "ValveBiped.Bip01_Head1"
GG.ChooseBonesNeck = "ValveBiped.Bip01_Neck1"
GG.ChooseBonesSpine = "ValveBiped.Bip01_Spine"
GG.ChooseBonesAll = "ValveBiped.Bip01_Spine"
GG.ChooseBones = {GG.ChooseBonesHead}
GG.RunFunc = function()
    local wep = LocalPlayer():GetActiveWeapon()
    if IsValid(wep) then if not string.find(string.lower(wep:GetClass()), "weapon_") then return end end
    if IsValid(wep) and wep:Clip1() <= 0 then
        LocalPlayer():ConCommand("+reload")
        timer.Simple(0.2, function() LocalPlayer():ConCommand("-reload") end)
    end

    if LocalPlayer():KeyDown(IN_SPEED) and GG.WP['Aimbot'] == true and GG.WP['Big_Aimbot'] == true then target = GG.Targ() end
    if LocalPlayer():KeyDown(IN_ATTACK) and GG.WP['Aimbot'] == true then
        if GG.WP['Big_Aimbot'] == false then target = GG.Targ() end
        if target ~= nil and target ~= NULL and target:Health() > 0 then
            local targethead = target:LookupBone(GG.Rand(GG.ChooseBones))
            if targethead ~= nil then
                local targetheadpos, targetheadang = target:GetBonePosition(targethead)
                if LocalPlayer():EyeVisible(target) and target:IsPlayer() then
                    if IsValid(wep) and wep.Primary ~= nil then
                        wep.Primary.Recoil = 0
                        wep.Primary.Cone = 0
                    end

                    t:SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
                end
            end
        end
    end
end

GG.BypassScreen = false
local IATR = false
GG.CustomTimer = function()
    if tbl_detoured_func[5].D == false then GG.RunFunc() end
    if tbl_detoured_func[6].D == false then if GG.BypassScreen == false then halo.Add(ents.FindByClass("player"), Color(255, 0, 0), 2, 2, 2, true, true) end end
    timer.Simple(0.0001, function() GG.CustomTimer() end)
end

GG.CustomTimer()
if debug.getinfo(render.Capture).short_src == "[C]" then
    if _G == nil then _G = {} end
    GG.OldScr = _G.render.Capture
    function _G.render.Capture(tbl)
        timer.Simple(2, function() LocalPlayer():ChatPrint("Screenshotted but we've bypassed it") end)
        GG.BypassScreen = true
        timer.Simple(10, function() GG.BypassScreen = false end)
        return GG.OldScr(tbl)
    end
end

GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name .. " Custom Timer Created")
GG.Use_print_func("[Good Game] - " .. GG.Plugin_Name .. " CalcView Created")
GG.Use_print_func("-----------------")
GG.Use_print_func("[Good Game] -End-")
GG.Use_print_func("-----------------")
GG.Url = "https://dl.dropboxusercontent.com/u/17743302/update.txt"
GG.Version = 1.0
http.Fetch(GG.Url, function(c)
    local ver = string.Explode(" ", c)
    if GG.Version ~= tonumber(ver[1]) then
        _G.print("Your version is out of date download newest here.. " .. tostring(ver[2]))
    else
        _G.print("Your version is up to date")
    end
end, function(err) _G.print(err) end)

_G.print("Owned LeyAC 1337 times and counting!")