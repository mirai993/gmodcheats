hoe 2 instell d00d
-------------------

Dump diz fuckin l33t lau module anus penis providing penis module into 

ur gerrysmod LAU FOLDERRRRRR DERP

(Drive):\Program Files\Steam\steamapps\common\GarrysMod\

Dis shiz work on DarkRP Blad aimbot + esp blad init

if u add readme.txt to garrysmod u iz dum just rememeber dat broda

Dis bypass niggaAC aka LeyAC Blad no problem if i find problem no problem i fix problem

install and have fun aimbot and esp no problem i iz lua god