--[[
	qq/todo.txt
	inkbote v2
	===DStream===
]]


// Maybe
- RenderScreenspaceEffectsPlayerStart()
- RenderScreenspaceEffectsPlayer(pl, count)
- RenderScreenspaceEffectsEnd()


// C0BRA's TODO
- Menu API
- Presets

// VICTOR'S TODO
- nothing :(

hostname		"THE KILLZONE - BUILD TO KILL - FASTDL/WIRE/WEAPONS"
rcon_password		"!Marines304"
