--[[
	qq/Plugins/bhop.lua
	inkbote v2
	===DStream===
]]

local qq = eqqlocal Plugin = {	Name = "Bunny Hop",	Alias = "bhop"}Plugin.Init = function()	qq.CreateSetting(qq.MENU_GENERIC, Plugin, "enabled", "Bunnyhop", true, {Save = true})endlocal lp = LocalPlayer()local CmdMeta = qq.Meta.Cmdlocal EntMeta = qq.Meta.EntPlugin.Bhop = function(ucmd)	if not qq.Setting(Plugin, "enabled") then return end	if lp == nil or not ValidEntity(lp) then lp = LocalPlayer() end	if lp == nil or not ValidEntity(lp) then return end	local buttons = CmdMeta.GetButtons(ucmd)	local walking = EntMeta.GetMoveType(lp) == MOVETYPE_WALK	local swimming = EntMeta.WaterLevel(lp) > 0	if (buttons & IN_JUMP) == IN_JUMP and not swimming and walking then		if EntMeta.OnGround(lp) then			CmdMeta.SetButtons(ucmd, buttons | IN_JUMP)		else			CmdMeta.SetButtons(ucmd, buttons - IN_JUMP)		end	endendPlugin.Hooks = {	PreCreateMove = Plugin.Bhop}qq.RegisterPlugin(Plugin)