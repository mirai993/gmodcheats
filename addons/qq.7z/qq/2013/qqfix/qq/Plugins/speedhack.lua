--[[
	qq/Plugins/speedhack.lua
	inkbote v2
	===DStream===
]]

local qq = eqq
// This plugin needs aah!

local Plugin = {
	Name = "Speedhack",
	Alias = "speedhack"
}

Plugin.Init = function()
	qq.CreateSetting(qq.MENU_GENERIC, Plugin, "speed", "Speed", 1, {Min = 0, Max = 10, Places = 1, Slider = true})
end

Plugin.PlusSpeedhack = function()
	console.Command("aah_setupspeedhack")
	console.Command("_timescale " .. qq.Setting(Plugin, "speed"))
end

Plugin.MinusSpeedhack = function()
	console.Command("_timescale " .. 1)
end

Plugin.ConCommands = {}
Plugin.ConCommands["+speed"] = Plugin.PlusSpeedhack
Plugin.ConCommands["-speed"] = Plugin.MinusSpeedhack

qq.RegisterPlugin(Plugin)