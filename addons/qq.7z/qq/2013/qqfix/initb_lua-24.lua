--[[
	autorun/client/initb.lua
	inkbote v2
	===DStream===
]]


include("qq/init.lua")