local qq = eqq -- eqq = externel qq, it exists only a few cycles

local PlyMeta = qq.Meta.Ply
local EntMeta = qq.Meta.Ent

local Plugin = {
	Name = "Wallhack2",
	Alias = "wallhack2",
	Mode = "wf"
}

local lookUpTable = {
	["Left 4 Dead"] = "l4d",
	Wireframe = "wf",
	Fullbright = "fullbr",
	["Team color"] = "tcol"
}
Plugin.Init = function()
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "enabled", "Wallhack", true, {Save = true})
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "weapons", "Weapons", true, {Save = true})
	
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "mode", "Mode", "", {
		MultiChoice = {
			["Left 4 Dead"] = false,
			Wireframe = false,
			Fullbright = false,
			["Team color"] = false
		}
	}, function(name, val) Plugin.Mode = lookUpTable[qq.Setting(Plugin, "mode")] end)
	
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "weapons_maxdmg", "Max Damage", 43, {Save = true, Min = 0, Max = 100})
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "weapons_starthue", "Start Damage Hue", 160, {Save = true, Min = 0, Max = 360})
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "weapons_endhue", "End Damage Hue", 30, {Save = true, Min = 0, Max = 360})
	
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "blursize", "Blur Size", 2, {Min = 0, Max = 10, Places = 1})
end

local MaterialBlurX = Material("pp/blurx")
local MaterialBlurY = Material("pp/blury")
local MaterialWhite = CreateMaterial("WhiteMaterial", "VertexLitGeneric", {
	 ["$basetexture"] = "color/white",
	 ["$vertexalpha"] = "1",
	 ["$model"] = "1",
})
local MaterialComposite = CreateMaterial("CompositeMaterial", "UnlitGeneric", {
	 ["$basetexture"] = "_rt_FullFrameFB",
	 ["$additive"] = "1",
})
  
local RT1 = GetRenderTarget("L4D1")
local RT2 = GetRenderTarget("L4D2")

local STENCILOPERATION_KEEP = STENCILOPERATION_KEEP
local STENCILOPERATION_REPLACE = STENCILOPERATION_REPLACE
local STENCILCOMPARISONFUNCTION_ALWAYS = STENCILCOMPARISONFUNCTION_ALWAYS
local STENCILCOMPARISONFUNCTION_EQUAL = STENCILCOMPARISONFUNCTION_EQUAL
local STENCILOPERATION_ZERO = STENCILOPERATION_ZERO

local MATERIAL_FOG_NONE = MATERIAL_FOG_NONE

local rSetStencilEnable = render.SetStencilEnable
local rSetStencilFailOperation = render.SetStencilFailOperation
local rSetStencilZFailOperation = render.SetStencilZFailOperation
local rSetStencilPassOperation = render.SetStencilPassOperation
local rSetStencilCompareFunction = render.SetStencilCompareFunction
local rSetStencilWriteMask = render.SetStencilWriteMask
local rSetStencilReferenceValue = render.SetStencilReferenceValue
local rSetBlend = render.SetBlend
local rFogStart = render.FogStart
local rFogEnd = render.FogEnd
local rGetRenderTarget = render.GetRenderTarget
local rSetRenderTarget = render.SetRenderTarget
local rClear = render.Clear
local rGetFogMode = render.GetFogMode
local rFogMode = render.FogMode
local rSetViewPort = render.SetViewPort
local rSuppressEngineLighting = render.SuppressEngineLighting
local rSetColorModulation = render.SetColorModulation
local rDrawScreenQuad = render.DrawScreenQuad
local rSetMaterial = render.SetMaterial
local rSetStencilTestMask = render.SetStencilTestMask

local cIgnoreZ = cam.IgnoreZ
local cStart3D = cam.Start3D
local cEnd3D = cam.End3D

local mmax = math.max

local tGetColor = team.GetColor

local pairs = pairs
local type = type
local SetMaterialOverride = SetMaterialOverride
local ValidEntity = ValidEntity
local ScrW = ScrW
local ScrH = ScrH
local HSVToColor = HSVToColor
local ClientsideModel = ClientsideModel

local weap
local fogMode
local oldRT
local col
local oldW
local oldH
local dmg
local maxdmg
local starthue
local endhue
local BlurSize
local wallhackEnts

local colWhite = Color(255, 255, 255, 255)
local colRed = Color(255, 0, 0, 255)

local plyMeta = qq.Meta.Ply
local entMeta = qq.Meta.Ent

local qqMIsDormat = q.Module.IsDormant;

local function shouldWallhack(ent,typ)
	if typ == "Player" then
		return plyMeta.Health(ent) > 0 and qqMIsDormat(ent)
	elseif typ == "NPC" then
		ent.WallhackColor = colRed
		return plyMeta.Health(ent) > 0
	elseif typ == "Weapon" and qq.Setting(Plugin, "weapons") then
		if not ValidEntity(ent.Owner) then
			col = colRed
			if ent.Primary then
				endhue = qq.Setting(Plugin, "weapons_endhue")
				col = HSVToColor(mmax(0, 1 - ((ent.Primary.Damage or 0) / qq.Setting(Plugin, "weapons_maxdmg"))) * (qq.Setting(Plugin, "weapons_starthue") - endhue) + endhue, 1, 1)
			end
			ent.WallhackColor = col
			return true
		end
	end
end

Plugin.Disabled = function()
	if Plugin.FakeModel and ValidEntity(Plugin.FakeModel) then
		entMeta.Remove(Plugin.FakeModel)
	end
end

Plugin.Enabled = function()
	Plugin.FakeModel = ClientsideModel("models/props_c17/canister02a.mdl", RENDERGROUP_OPAQUE)
	entMeta.SetPos(Plugin.FakeModel, Vector(0,0,-1000));
end

local function l4dClearRT()
	oldRT = rGetRenderTarget()
	rSetRenderTarget(RT1)
	rClear(0, 0, 0, 255, true)
	rSetRenderTarget(oldRT)
end

local function drawFakeEnt(ent)
	entMeta.SetModel(Plugin.FakeModel,entMeta.GetModel(ent))
	entMeta.SetPos(Plugin.FakeModel, entMeta.GetPos(ent))
	entMeta.SetAngles(Plugin.FakeModel, entMeta.GetAngles(ent))
	entMeta.SetupBones(Plugin.FakeModel)
	entMeta.DrawModel(Plugin.FakeModel)
end

local function l4dPrepareStencil()
	rSetStencilEnable(true)
	rSetStencilFailOperation(STENCILOPERATION_KEEP)
	rSetStencilZFailOperation(STENCILOPERATION_KEEP)
	rSetStencilPassOperation(STENCILOPERATION_REPLACE)
	rSetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
	rSetStencilWriteMask(1)
	rSetStencilReferenceValue(1)
	rSetBlend(0)
		SetMaterialOverride(MaterialWhite)
			weap = nil
			for _, ent in pairs(wallhackEnts) do
				if(!shouldWallhack(ent, type(ent)) ) then
					continue
				end
				if type(ent) == "Player" then
					if plyMeta.GetActiveWeapon(ent) then
						weap = plyMeta.GetActiveWeapon(ent)
					end
					if ValidEntity(weap) then
						entMeta.DrawModel(weap)
					end
				end
				if(ent.Primary) then
					drawFakeEnt(ent)
					continue
				end
				entMeta.DrawModel(ent)
			end
		SetMaterialOverride()
	rSetBlend(1)
	rSetStencilEnable(false)
end

local function l4dDrawToRT()
	oldW = ScrW()
	oldH = ScrH()
	fogMode = rGetFogMode()
	if(fogMode != MATERIAL_FOG_NONE) then
		rFogMode(MATERIAL_FOG_NONE)
	end
	oldRT = rGetRenderTarget()
	rSetRenderTarget(RT1)
		rSetViewPort(0, 0, 512, 512)
			rSuppressEngineLighting(true)
				SetMaterialOverride(MaterialWhite)
					weap = nil
					for _, ent in pairs(wallhackEnts) do
						if(!shouldWallhack(ent, type(ent))) then
							continue
						end
						if type(ent) == "Player" then
							col = tGetColor(PlyMeta.Team(ent))
							if ent.WallhackColor then
								col = ent.WallhackColor
							end
							rSetColorModulation(col.r/255, col.g/255, col.b/255)
							if PlyMeta.GetActiveWeapon(ent) then
								weap = PlyMeta.GetActiveWeapon(ent)
							end
							if ValidEntity(weap) then
								EntMeta.DrawModel(weap)
							end
						else
							col = colWhite
							if ent.WallhackColor then
								col = ent.WallhackColor
							end
							rSetColorModulation(col.r/255, col.g/255, col.b/255)
						end
						if(ent.Primary) then
							drawFakeEnt(ent)
							continue
						end
						EntMeta.DrawModel(ent)
					end
				SetMaterialOverride()
				rSetColorModulation(1, 1, 1)--general reset!
			rSuppressEngineLighting(false)	
		rSetViewPort(0, 0, oldW, oldH)
	rSetRenderTarget(oldRT)
	if(fogMode != MATERIAL_FOG_NONE) then
		rFogMode(MATERIAL_FOG_NONE)
	end
end

local function l4dDumpToScreen()
	MaterialBlurX:SetMaterialTexture("$basetexture", RT1)
	MaterialBlurY:SetMaterialTexture("$basetexture", RT2)
	
	BlurSize = qq.Setting(Plugin, "blursize") or 2
	
	MaterialBlurX:SetMaterialFloat("$size", BlurSize)
	MaterialBlurY:SetMaterialFloat("$size", BlurSize)
	
	local oldRT = rGetRenderTarget()
	
	-- blur horizontally
	rSetRenderTarget(RT2)
	rSetMaterial(MaterialBlurX)
	rDrawScreenQuad()
 
	-- blur vertically
	rSetRenderTarget(RT1)
	rSetMaterial(MaterialBlurY)
	rDrawScreenQuad()
 
	rSetRenderTarget(oldRT)
	
	-- tell the stencil buffer we're only going to draw
	 -- where the player models are not.
	rSetStencilEnable(true)
	rSetStencilReferenceValue(0)
	rSetStencilTestMask(1)
	rSetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
	rSetStencilPassOperation(STENCILOPERATION_ZERO)
	 
	-- composite the scene
	MaterialComposite:SetMaterialTexture("$basetexture", RT1)
	rSetMaterial(MaterialComposite)
	rDrawScreenQuad()
	 -- don't need this anymore
	rSetStencilEnable(false)
end

local function drawL4DWallhack()
	l4dClearRT()
	suppressPlayerDraw = true
	cStart3D(EyePos(), EyeAngles())
		cIgnoreZ(true)
		l4dPrepareStencil()
		l4dDrawToRT()
		cIgnoreZ(false)
	cEnd3D()
	l4dDumpToScreen()
	suppressPlayerDraw = false
end

local wireFrameMat = Material("hlmv/debugmrmwireframe");

local function drawWireframeWallhack()
	cStart3D(EyePos(), EyeAngles())
		cIgnoreZ(true)
			SetMaterialOverride(wireFrameMat)
			weap = nil
			for _, ent in pairs(wallhackEnts) do
				if(!shouldWallhack(ent, type(ent))) then
					continue
				end
				if type(ent) == "Player" then
					col = tGetColor(PlyMeta.Team(ent))
					if ent.WallhackColor then
						col = ent.WallhackColor
					end
					rSetColorModulation(col.r/255, col.g/255, col.b/255)
					if PlyMeta.GetActiveWeapon(ent)  then
						weap = PlyMeta.GetActiveWeapon(ent)
					end
					if ValidEntity(weap) then
						EntMeta.DrawModel(weap)
					end
				else
					col = colWhite
					if ent.WallhackColor  then
						col = ent.WallhackColor
					end
					rSetColorModulation(col.r/255, col.g/255, col.b/255)
				end
				if(ent.Primary) then
					drawFakeEnt(ent)
					continue
				end
				EntMeta.DrawModel(ent)
			end
			SetMaterialOverride()
		cIgnoreZ(false)
	cEnd3D()
end

local function drawFullbrightWallhack()
	cStart3D(EyePos(), EyeAngles())
		cIgnoreZ(true)
			rSuppressEngineLighting(true)
				weap = nil
				for _, ent in pairs(wallhackEnts) do
					if(!shouldWallhack(ent, type(ent))) then
						continue
					end
					if type(ent) == "Player" then
						if PlyMeta.GetActiveWeapon(ent)  then
							weap = PlyMeta.GetActiveWeapon(ent)
						end
						if ValidEntity(weap) then
							EntMeta.DrawModel(weap)
						end
						if(ent.Primary) then
							drawFakeEnt(ent)
							continue
						end
						EntMeta.DrawModel(ent)
					end
				end
			rSuppressEngineLighting(false)
		cIgnoreZ(false)
	cEnd3D()
end

local function drawTeamColWallhack()
	cStart3D(EyePos(), EyeAngles())
		cIgnoreZ(true)
			rSuppressEngineLighting(true)
				weap = nil
				SetMaterialOverride(MaterialWhite)
				for _, ent in pairs(wallhackEnts) do
					if(!shouldWallhack(ent, type(ent))) then
						continue
					end
					if type(ent) == "Player" then
						col = tGetColor(PlyMeta.Team(ent))
						if ent.WallhackColor then
							col = ent.WallhackColor
						end
						rSetColorModulation(col.r/255, col.g/255, col.b/255)
						if PlyMeta.GetActiveWeapon(ent)  then
							weap = PlyMeta.GetActiveWeapon(ent)
						end
						if ValidEntity(weap) then
							EntMeta.DrawModel(weap)
						end
					else
						col = colWhite
						if ent.WallhackColor  then
							col = ent.WallhackColor
						end
						rSetColorModulation(col.r/255, col.g/255, col.b/255)
					end
					if(ent.Primary) then
						drawFakeEnt(ent)
						continue
					end
					EntMeta.DrawModel(ent)
				end
				SetMaterialOverride()
			rSuppressEngineLighting(false)
		cIgnoreZ(false)
	cEnd3D()
end

Plugin.DrawWallHack = function()
	if not qq.Setting(Plugin, "enabled") or (qq.Plugins.mirror and qq.Plugins.mirror.DrawingMirror) then return end
	wallhackEnts = ents.GetAll()
	if(Plugin.Mode == "l4d") then
		return drawL4DWallhack()--lol tailcalls, fucks with debugging though
	end
	if(Plugin.Mode == "wf") then
		return drawWireframeWallhack()
	end
	if(Plugin.Mode == "fullbr") then
		return drawFullbrightWallhack()
	end
	if(Plugin.Mode == "tcol") then
		return drawTeamColWallhack()
	end
end
	
Plugin.PrePlayerDraw = function(pl)
	if(suppressPlayerDraw) then return false end
end

Plugin.PostPlayerDraw = function(pl)
	if(suppressPlayerDraw) then return false end
end

Plugin.Hooks = {
	RenderScreenspaceEffects = Plugin.DrawWallHack,
	PostPlayerDraw = Plugin.PostPlayerDraw,
	PrePlayerDraw = Plugin.PrePlayerDraw 
}

qq.RegisterPlugin(Plugin)