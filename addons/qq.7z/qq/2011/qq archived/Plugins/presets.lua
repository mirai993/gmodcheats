local qq = eqq

require("glon")

local Plugin = {
	Name = "Presets",
	Alias = "presets",
	LoadedPresets = {}
}
Plugin.Recurse = false

Plugin.ChangePreset = function(cvar, old, new)
	if Plugin.Recurse then
		Plugin.Recurse = false
		return
	end
	
	local preset = Plugin.LoadedPresets[new]
	if new == "" then
		return
	elseif not preset then
		qq.Warn("Failed to set preset {1}", new)
		Plugin.Recurse = true
		qq.SetSetting(Plugin, "preset", "")
		return
	end
	
	for k,info in pairs(preset) do
		if info.PluginAlias == "internal" then continue end
		if info.PluginAlias == "preset" then continue end
		
		qq.SetSetting(qq.Plugins[info.PluginAlias], info.Name, info.Value)
	end
	qq.Inform("Loaded preset {1}", new)
end

Plugin.CreatePreset = function()
	local name = qq.Setting(Plugin, "newpresetname") or ""
	if string.len(name) == 0 then return end
	qq.SetSetting(Plugin, "newpresetname", "")
	
	local NewPreset = {}
	
	for k,v in pairs(qq.Settings) do // We don't want to save it all, just what we need
		NewPreset[k] = {
			PluginAlias = v.Plugin.Alias,
			Name = v.Name,
			Value = v.Value
		}
	end
	
	Plugin.LoadedPresets[name] = NewPreset
	file.Write("qq_presets.txt", TableToKeyValues(Plugin.LoadedPresets))
end

Plugin.Init = function()
	Plugin.LoadedPresets = KeyValuesToTable(file.Read("qq_presets.txt") or "")
	qq.CreateSetting(qq.MENU_GENERIC, Plugin, "preset", "Preset", "", {MultiChoice = Plugin.LoadedPresets}, Plugin.ChangePreset)
	qq.CreateSetting(qq.MENU_GENERIC, Plugin, "newpresetname", "New Preset Name", "", {Save = false})
	qq.CreateSetting(qq.MENU_GENERIC, Plugin, "createpreset", "Create Preset", Plugin.CreatePreset)
end

qq.RegisterPlugin(Plugin)