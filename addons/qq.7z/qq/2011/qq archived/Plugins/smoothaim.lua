local qq = eqq

local Plugin = {
	Name = "Smooth Aim",
	Alias = "smoothaim"
}

local CmdMeta = qq.Meta.Cmd
local PlyMeta = qq.Meta.Ply
local EntMeta = qq.Meta.Ent
local AngMeta = qq.Meta.Ang
local VecMeta = qq.Meta.Vec

Plugin.Init = function()
	qq.CreateSetting(qq.MENU_AIMBOT, Plugin, "speed", "Smooth Aim", 120, {Min = 0, Max = 360})
	qq.CreateSetting(qq.MENU_AIMBOT, Plugin, "distancefactor", "Smooth Aim Distance Factor", 1, {Min = 0, Max = 1, Places = 2})
end

Plugin.ApproachAngle = function(start, target, add)
	local diff = qq.NormalizeAngle(target - start)
	
	local vec = Vector(diff.p, diff.y, diff.r)
	local len = VecMeta.Length(vec)
	vec = VecMeta.GetNormal(vec) * math.min(add, len)

	return start + Angle(vec.x, vec.y, vec.z)
end

Plugin.SmoothAim = function(cmd, TargAim)
	local smooth = qq.Setting(Plugin, "speed")
	if smooth == 0 then return end
	
	local distancefactor = qq.Setting(Plugin, "distancefactor")
	
	local current = CmdMeta.GetViewAngles(cmd)

	// Approach the target angle.
	local multi_vec = qq.NormalizeAngle(current - TargAim)
	local multi = (multi_vec.p + multi_vec.y) * distancefactor
	multi = math.abs(multi)
		
	current = Plugin.ApproachAngle(current, TargAim, smooth * FrameTime() * multi)
	current.r = 0

	return current
end

Plugin.Hooks = {
	PreModifyAimbotAngle = Plugin.SmoothAim
}

qq.RegisterPlugin(Plugin)