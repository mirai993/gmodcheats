local qq = eqq
local PlyMeta = qq.Meta.Ply
local render = qq.GlobalCopy.render

local Plugin = {
	Name = "Mirror",
	Alias = "mirror",
	Mirror = {},
}

Plugin.Init = function()
	qq.CreateSetting(qq.MENU_VISUALS, Plugin, "enabled", "Enabled", true)
end

Plugin.DrawMirror = function()
	if not qq.Setting(Plugin, "enabled") then return end
	
	local lp = qq.GlobalCopy.LocalPlayer()
	
	local width = 300
	local height = 100
	
	Plugin.Mirror.angles = Angle(0,qq.GetView(lp).y+180,0)
	Plugin.Mirror.origin = PlyMeta.GetShootPos(lp)
	Plugin.Mirror.x = qq.ScreenSize.x / 2 - width /2
	Plugin.Mirror.y = 10 // don't need to subttract height
	Plugin.Mirror.w = width
	Plugin.Mirror.h = height
	Plugin.Mirror.znearviewmodel = 0
	Plugin.Mirror.zfarviewmodel = 0
	Plugin.Mirror.fov = 90
	render.RenderView(Plugin.Mirror)

end

Plugin.Hooks = {
HUDPaintPlayerStart = Plugin.DrawMirror,
}

qq.RegisterPlugin(Plugin)