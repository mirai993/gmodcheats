
require("disconnect")


local CustomMsg = false
local NewMsg = ""

local QuitTAB = {
	"Well, that's not jelly filled, now is it?",
	"Kicked and Banned",
	"It looks like a Cheez-Whiz smuggling operation gone horribly wrong",
	"Why would you waste the entire pencil. Youre crazy",
	"In order to make an apple pie from scratch, you must first create the universe",
    "I have a collect call from the Pegasus Galaxy. Will you accept the charges",
    "WATERMELON SAUSAGE EXPLOSION. OH GOD FEED ME",
    "as the three wheeled couch starts to? veer off course",
	"seemingly fade in and out of existence, it's like magic with less bunnies",
	"Donuts and hot dogs are flying everywhere",
	"And A Cartridge in a Bare Tree",
	"Please stop petting the tigers and drinking the gasoline.",
	"limited bottled universe",
	
}


local OnlyTAB = {
	"Disconnect by user.",
	"NetChannel removed.",
}
local function Disconnect(msg)
	if not table.HasValue(OnlyTAB, msg) then return end
	
	if CustomMsg then
		CustomMsg = false
		return NewMsg
	end
	
	local lol2 = table.Random(QuitTAB) 
	print("! disconnect: ", lol2)
    return lol2
end
hook.Add("DisconnectMsg", "Disconnect", Disconnect)


local function Quit(ply,cmd,args)
	if #args > 0 then
		CustomMsg = true
		NewMsg = table.concat(args," ")
	end
	
	timer.Simple(1, RunConsoleCommand, "disconnect")
end
concommand.Add("quit_msg", Quit)








