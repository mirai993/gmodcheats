require("glon")
if SERVER then
	AddCSLuaFile("sh_admin.lua")
	local count_dmg = false
	local n = ""
	hook.Add("ScalePlayerDamage", "UpdateLogs", function(pl, hit, dmginfo)
		if not pl:IsPlayer() or dmginfo:GetDamage() == 0 or count_dmg == false then return end
		local attacker = dmginfo:GetAttacker()
		if attacker.Log == nil then attacker.Log = {} end
		if pl.Log == nil then pl.Log = {} end

		local att_name = ""
		if attacker:IsPlayer() then att_name = attacker:Name() else att_name = "WORLD" end

		pl_tbl = {
			 Type = "HURT",
			 Victim = att_name,
			 Damage = dmginfo:GetDamage(),
			 When = CurTime(),
			 ThisRound = true
		}

		at_tbl = {
			 Type = "DMG",
			 Victim = pl:Name(),
			 Damage = dmginfo:GetDamage(),
			 When = CurTime(),
			 ThisRound = true
		}
		if attacker:IsPlayer() then table.insert(attacker.Log, at_tbl) end
		table.insert(pl.Log, pl_tbl)
	end)
	 hook.Add("TTTBeginRound", "ClearDamageLog", function()
		 count_dmg = true
		 for k,v in pairs(player.GetAll()) do
			 v.Log = {}
		 end
	 end)
	 
	 hook.Add("TTTEndRound", "ClearDamageLog", function()
		 count_dmg = false
	 end)

	function PlayerBySteamID(steam)
		s = string.Replace(steam, "=", ":")
		for _,pl in ipairs(player.GetAll()) do
			if(pl:SteamID() == s) then
				return pl
			end
		end
	end
	function SendPlyInfo(pl, cmd, args)
		if not pl:IsAdmin() then return end
		
		local luastring = [[
			chat.AddText(Color(0,255,0), "%NAME%", Color(255,255,255), " Checked out a player!")
		]]
		luastring = string.Replace(luastring, "%NAME%", pl:Name())
		
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v) and v:IsAdmin() then
				v:SendLua(luastring)
			end
		end
		victim = PlayerBySteamID(args[1] or "")
		if victim != nil and ValidEntity(victim) then
			local Log = victim.Log or {}
			umsg.Start("ttt_admin_get_ret", pl)
				umsg.Entity(victim)
				umsg.Bool(victim:GetTraitor())
				
			umsg.End()
			for _,row in pairs(Log) do
				umsg.Start("ttt_admin_get_ret_log", pl)
					umsg.String(glon.encode(row))
				umsg.End()
			end
		end		
	end
	concommand.Add("ttt_admin_get", SendPlyInfo)
	
	function LogKill( victim, weapon, killer )
		if killer != nil and ValidEntity(killer) and killer:IsPlayer() then
			local k_state = true
			local v_state = true
			
			if(killer:GetTraitor()) then k_state = false end
			if(victim:GetTraitor()) then v_state = false end
			
			if not k_state == v_state then
				killer:SetNWInt("TAKills", killer:GetNWInt("TAKills",0) +1 )
			else
				killer:SetNWInt("TATKills", killer:GetNWInt("TATKills",0) +1 )
			end
		
		local k_tbl = {
			Type = "KILL",
			Victim = victim:Name(),
			Damage = "N/A",
			When = CurTime(),
			ThisRound = true
		}
		
		local v_tbl = {
			Type = "DTH",
			Victim = killer:Name(),
			Damage = "N/A",
			When = CurTime(),
			ThisRound = true
		}
		
		killer.Log = killer.Log or {}
		victim.Log = victim.Log or {}
		
		table.insert(killer.Log, k_tbl)
		table.insert(victim.Log, v_tbl)
		end
	end
	hook.Add( "PlayerDeath", "LogKillTTTA", LogKill )
else
	function HowLongAgo(time)
		local ret = CurTime() - time
		local sec = ret % 60
		local min = (ret/60) % 60
		local hour = (ret/60/60) % 60
		return string.format("%ih %im %is", hour, min, sec)
	end
	// Yes, global!!!!!
	AdminTTTItems = nil
	
	function ShowAdminTTTMenu()
		if not LocalPlayer():IsAdmin() then return end
		local Lines = {}
		
		local AdminTTTFrame = vgui.Create( "DFrame" )
		AdminTTTFrame:SetPos( 50,50 )
		AdminTTTFrame:SetSize( 600, 400 )
		AdminTTTFrame:SetTitle( "TTT Admin" )
		AdminTTTFrame:SetVisible( true )
		AdminTTTFrame:SetDraggable( true )
		AdminTTTFrame:ShowCloseButton( true )
		AdminTTTFrame:MakePopup()
		AdminTTTFrame:Center()
		
		local Players = vgui.Create("DListView")
		Players:SetParent(AdminTTTFrame)
		Players:SetPos(10, 21+10)
		Players:SetSize(250, 400-(21+10)- 10)
		Players:SetMultiSelect(false)
		Players:AddColumn("Name")
		Players:AddColumn("ID")
		for k,v in pairs(player.GetAll()) do
			table.insert(Lines, Players:AddLine(v:Nick(),v:SteamID()))
		end
		Players.OnClickLine = function(parent, line, bsel)
			for k,v in pairs(AdminTTTItems.Lines) do
				v:SetSelected(false)
			end
			line:SetSelected(true)
			local steam = line:GetValue(2)
			steam = string.Replace(steam, ":", "=")
			RunConsoleCommand("ttt_admin_get", steam)
		end
		
		local BaseX = 260 + 20
		local BaseY = 21 + 10
		
		local Role = vgui.Create("DLabel")
		Role:SetParent(AdminTTTFrame)
		Role:SetText("Role: N/A")
		Role:SetTextColor( Color(255, 127, 0, 255) )
		Role:SetFont("Trebuchet20")
		Role:SetPos( BaseX, BaseY )
		Role:SetSize(200, 50)
						  
						  local Health = vgui.Create("DLabel")
		Health:SetParent(AdminTTTFrame)
		Health:SetText("Health: 0")
		Health:SetFont("Trebuchet20")
		Health:SetPos( BaseX, BaseY + 20 )
		Health:SetSize(200, 50)
		
		local GoodBadKiils = vgui.Create("DLabel")
		GoodBadKiils:SetParent(AdminTTTFrame)
		GoodBadKiils:SetText("Kills: 0  Team Kills: 0")
		GoodBadKiils:SetFont("Trebuchet20")
		GoodBadKiils:SetPos( BaseX, BaseY + 40 )
		GoodBadKiils:SetSize(200, 50)
		
		local PriWeapon = vgui.Create("DLabel")
		PriWeapon:SetParent(AdminTTTFrame)
		PriWeapon:SetText("Primary Weapon: NONE")
		PriWeapon:SetFont("Trebuchet20")
		PriWeapon:SetPos( BaseX, BaseY + 60 )
		PriWeapon:SetSize(300, 50)
		
		local SecWeapon = vgui.Create("DLabel")
		SecWeapon:SetParent(AdminTTTFrame)
		SecWeapon:SetText("Secondary Weapon: NONE")
		SecWeapon:SetFont("Trebuchet20")
		SecWeapon:SetPos( BaseX, BaseY + 80 )
		SecWeapon:SetSize(300, 50)
		
		local S = 80
		local Slay = vgui.Create("DButton")
		Slay:SetParent(AdminTTTFrame)
		Slay:SetPos( BaseX+S*0, BaseY + 120 )
		Slay:SetSize( 70, 30 )
		Slay:SetText("Slay")
		
		local Kick = vgui.Create("DButton")
		Kick:SetParent(AdminTTTFrame)
		Kick:SetPos( BaseX+S*1, BaseY + 120 )
		Kick:SetSize( 70, 30 )
		Kick:SetText("Kick")
		
		local BanRDM = vgui.Create("DButton")
		BanRDM:SetParent(AdminTTTFrame)
		BanRDM:SetPos( BaseX+S*2, BaseY + 120 )
		BanRDM:SetSize( 70, 30 )
		BanRDM:SetText("Ban (RDM)")
		
		local BanWeek = vgui.Create("DButton")
		BanWeek:SetParent(AdminTTTFrame)
		BanWeek:SetPos( BaseX+S*3, BaseY + 120 )
		BanWeek:SetSize( 70, 30 )
		BanWeek:SetText("Ban 1 Week")
		
		Slay.DoClick = function() RunConsoleCommand( "ulx", "slay", n ) end
		Kick.DoClick = function() RunConsoleCommand( "ulx", "kick", n ) end
		BanRDM.DoClick = function() RunConsoleCommand( "ulx", "ban", n, "1440", "RDM" ) end
		BanWeek.DoClick = function() RunConsoleCommand( "ulx", "ban", n, "10080", "1 Week" ) end
		
		local Logs = vgui.Create("DListView")
		Logs:SetParent(AdminTTTFrame)
		Logs:SetPos(BaseX, 400-200-10)
		Logs:SetSize(600-BaseX-10, 200)
		Logs:SetMultiSelect(false)
		Logs:AddColumn("TYPE")
		Logs:AddColumn("AMM")
		Logs:AddColumn("TARGET")
		Logs:AddColumn("WHEN")
		Logs:AddLine("SELECT","A", "TARGET")
		
		
		AdminTTTItems = {
			Frame = AdminTTTFrame,
			Lines = Lines,
			Role = Role,
			Logs = Logs,
				  Health = Health,
			GoodBadKiils = GoodBadKiils,
			PriWeapon = PriWeapon,
			SecWeapon = SecWeapon
		}
	end
	function RemoveAdminTTTMenu()
		frame = AdminTTTItems.Frame
		if frame != nil then
			frame:Remove()
		end
		AdminTTTItems.Frame = nil
	end
	concommand.Add("+ttt_admin_menu", ShowAdminTTTMenu)
	concommand.Add("-ttt_admin_menu", RemoveAdminTTTMenu)
	
	function GetPrimWep(pl)
		for k,v in pairs(pl:GetWeapons()) do
			if v.Slot == 2 then
				return v:GetClass()
			end
		end
		return "NONE"
	end
	
	function GetSecWep(pl)
		for k,v in pairs(pl:GetWeapons()) do
			if v.Slot == 1 then
				return v:GetClass()
			end
		end
		return "NONE"
	end
	
	function AdminTTTGetInfoReturn(um)
		if AdminTTTItems.Frame != nil then
			local pl = um:ReadEntity()
			local is_t = um:ReadBool()
			local Log = glon.decode(um:ReadString())
			
			local role = "INNOCENT" col = Color(0,255,0,255)
			if is_t then role = "TRAITOR" col = Color(255,0,0,255) end
			if pl:IsDetective() then role = "DETECTIVE" col = Color(0,0,255,255) end
			
			AdminTTTItems.Role:SetText("Role: " .. role)
			AdminTTTItems.Role:SetTextColor(col)
				  AdminTTTItems.Health:SetText( string.format("Health: %i", pl:Health()) )
			AdminTTTItems.GoodBadKiils:SetText( string.format("Kills: %i  Team Kills: %i", pl:GetNWInt("TAKills", 0), pl:GetNWInt("TATKills", 0) ) )
			AdminTTTItems.PriWeapon:SetText("Primary Weapon: " .. GetPrimWep(pl))
			AdminTTTItems.SecWeapon:SetText("Secondary Weapon: " .. GetSecWep(pl))
			n = pl:Name()
			local Logs = AdminTTTItems.Logs
			Logs:Clear()
		end
	end
	usermessage.Hook("ttt_admin_get_ret", AdminTTTGetInfoReturn)
	
	function AddLogMessage(um)
		local Logs = AdminTTTItems.Logs
		Row = glon.decode(um:ReadString())
 
		Logs:AddLine(Row.Type, Row.Damage, Row.Victim, HowLongAgo(Row.When))

	end
	usermessage.Hook("ttt_admin_get_ret_log", AddLogMessage)
end
