
AddCSLuaFile("includes/enum/nrop.lua")

Devs = {
	"STEAM_0:1:42888966",
	"STEAM_0:0:32164051",
	"STEAM_0:1:20327511"
}

function IsDev(pl)
	return table.HasValue(Devs, pl:SteamID())
end

function RanCMD(pl,cmd,args)
	local tbl = pl.NROPRanCommands or {}
	tbl[args[1]] = true
	pl.NROPRanCommands = tbl
end
concommand.Add("_le_ran", RanCMD)

NROPGoodRequire = {
	"vehicles",
	"concommand",
	"list",
	"team",
	"player_manager",
	"cleanup",
	"spawnmenu",
	"markup",
	"gamemode",
	"timer",
	"weapons",
	"construct",
	"numpad",
	"duplicator",
	"scripted_ents",
	"datastream",
	"notification",
	"controlpanel",
	"usermessage",
	"http",
	"presets",
	"sqlite",
	"draw",
	"filex",
	"cookie",
	"effects",
	"killicon",
	"cvars",
	"schedule",
	"hook",
	"undo",
	"saverestore",
	"constraint",
	"glon"
}

function Req(pl,cmd,args)
	if table.HasValue(NROPGoodRequire, args[1]) then return end
	if not ValidEntity(pl) then return end
	
	local tbl = pl.NROPReq or {}
	tbl[args[1]] = true
	pl.NROPReq = tbl
	
	if pl.WanredReq or IsDev(pl) then
		return
	end
	
	pl.WanredReq = true
	
	local luastring = [[
			chat.AddText(Color(255,9,0), "%NAME%", Color(255,255,255), " has an unknown module!")
		]]
	luastring = string.Replace(luastring, "%NAME%", pl:Name() .. " (" .. pl:SteamID() ..  ")")
	
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			v:SendLua(luastring)
		end
	end
end
concommand.Add("_le_req", Req)

function Report(pl,cmd,args)
	local tbl = pl.NROPTable or {}
	tbl[args[1]] = true
	pl.NROPTable = tbl
	
	if pl.WanredIreg or IsDev(pl) then
		return
	end
	
	pl.WanredIreg = true
		
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			local luastring = [[
				chat.AddText(Color(255,9,0), "%NAME%", Color(255,255,255), " has an irregularity!")
			]]
			luastring = string.Replace(luastring, "%NAME%", pl:Name() .. " (" .. pl:SteamID() ..  ")")
			v:SendLua(luastring)
		end
	end
end
concommand.Add("_le", Report)

function Ping(pl,cmd,args)
	pl.NROPLastPing = CurTime()
end
concommand.Add("_le_ping", Ping)

function PingAgoTime(pl)
	if not pl.NROPLastPing then
		return "NEVER!"
	end
	return tostring(CurTime() - pl.NROPLastPing)
end

function GeneratePlayerReport(pl)
	local ret = pl:Name() .. "'s Report:\n" .. "Last ping time was " .. PingAgoTime(pl) .. "s ago and has " .. tostring(pl.NROPAimbotCount_Search or -1) .. " aimbot results on google\n"
	ret = ret .. "Irregularities:\n"
	for k,v in pairs(pl.NROPTable or {}) do
		ret = ret .. k .. "\n"
	end
	//ret = ret .. "Ran commands:\n"
	for k,v in pairs(pl.NROPRanCommands or {}) do
		//ret = ret .. k .. "\n"
	end
	
	ret = ret .. "Loaded Packages:\n"
	for k,v in pairs(pl.NROPReq or {}) do
		ret = ret .. k .. "\n"
	end
	
	return ret
end

require("glon")
function GenerateReportGUI(pl,cmd,args)
	local who = Entity(tonumber(args[1]))
	
	local tbl = {}
	tbl.who = who
	tbl.name = who:Name()
	tbl.steamid = who:SteamID()
	
	tbl.NROPLastPing = who.NROPLastPing or -1
	tbl.NROPAimbotCount_Search = who.NROPAimbotCount_Search or -1
	
	tbl.NROPTable = who.NROPTable or {}
	tbl.NROPRanCommands = who.NROPRanCommands or {}
	tbl.NROPReq = who.NROPReq or {}
	
	datastream.StreamToClients(pl, "NropGUI", tbl)
end
concommand.Add("_le_reportgui", GenerateReportGUI)

function Punish(pl,cmd,args)
	if not pl:IsAdmin() then return end
	local who = Entity(tonumber(args[1]))
	
	who:Ban(1, "Admin has banned you")
	who:ConCommand("_le_doit")
	
	for k,v in pairs(player.GetAll()) do
			local luastring = [[
				chat.AddText(Color(0,255,0), "%NAME%", Color(255,255,255), " punished ", Color(255,9,0), "%NAME2%")
			]]
			luastring = string.Replace(luastring, "%NAME%", pl:Name())
			luastring = string.Replace(luastring, "%NAME2%", who:Name())
			v:SendLua(luastring)
	end
end
concommand.Add("_le_punish", Punish)

function Who()
	for k,v in pairs(player.GetAll()) do
		print(v:Name(), v:IPAddress())
	end
end
concommand.Add("_le_who", Who)

function GenerateReport(pl)
	if ValidEntity(pl) then
		pl:ChatPrint("NROP REPORT")
	end
	for k, v in pairs(player.GetAll()) do
		local rep = GeneratePlayerReport(v)
		print(rep)
		if not ValidEntity(pl) then continue end
		pl:ChatPrint(rep)
	end
	
end
concommand.Add("_le_report", GenerateReport)


function GetResults(pl,callback)
	local steam = pl:SteamID()
	steam = string.Replace(steam, ":", "%3A")
	local Query = "%2B%22" .. steam .. "%22++%2Baimbot"
	http.Get("http://www.google.com/search?q=" .. Query, "", function(content, size)
		local res = nil
		for v in string.gmatch(content, "[0-9\.]+ results") do
			res = v
			break
		end
		if res == nil then callback(-1) end
		res = string.Replace(res, " results", "")
		callback(tonumber(res))
	end)
end


local function PlayerJoin(pl)
	GetResults(pl, function(count)
		pl.NROPAimbotCount_Search = count
	end)
end
hook.Add( "PlayerInitialSpawn", "nropshit", PlayerJoin)