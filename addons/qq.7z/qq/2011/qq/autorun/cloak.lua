
// Copyright C0BRA - xiatek.org

hook.Add("InitPostEntity", "setup_cloak", function()
	local Item = {
			name = "Cloak",
			disc = "Bind a key to \"togglecloak\" to cloak.",
			mdl = "models/Items/combine_rifle_ammo01.mdl",
			cost = 1,
			visible = true,
			action = function(pl) pl:SetNWBool("ownscloak", true) pl:ChatPrint("Bind a key to \"togglecloak\" to cloak") end,
			canbuy = function(pl)
				if pl:GetNWBool("ownscloak") then return false, "You already own this" end
				if pl:GetTraitor() then return true end
				if pl:IsDetective() then return true end
				return false, "You're not a traitor or detective"
			end
		}

	df.RegisterItem(Item)
end)


if CLIENT then 
	function DrawBar()
		if not LocalPlayer():GetNWBool("ownscloak") then return end
		
		local width = 150
		local height = 10
		local startx = 10
		local starty = ScrH() / 2
		local power = LocalPlayer():GetNWFloat("CloakPower", 0)
		
		if power == 1000 then
			surface.SetDrawColor(Color(0,100,0,100))
			surface.DrawRect(startx, starty, width, height)
			return
		end
		
		surface.SetDrawColor(Color(0,0,0,50))
		surface.DrawRect(startx, starty, width, height)
		
		surface.SetDrawColor(Color(255,255,255,127))
		if power < 300 then
			surface.SetDrawColor(Color(255,0,0,127))
		end
		surface.DrawRect(startx, starty, width * (power / 1000), height)
	end
	hook.Add("HUDPaint", "drawcloakbar", DrawBar)
	
	return
end

resource.AddFile("materials/le/refract.vmt")
resource.AddFile("materials/le/refract_dudv.vtf")
resource.AddFile("materials/le/refract_norm.vtf")
AddCSLuaFile("cloak.lua")

local function PlayerHurt(pl,att,_,dmg)
	if pl.Cloaked then
		pl.CloakPower = 0
		UncloakPlayer(pl)
	end
	if att and ValidEntity(att) then
		att.CloakPower = att.CloakPower or 0
		att.CloakPower = att.CloakPower + dmg * 5
	end
end
hook.Add("PlayerHurt", "cloakhurt", PlayerHurt)

function UncloakPlayer(pl)
	pl:SetNWBool("disguised", false)
	pl:SetColor(Color(255,255,255,255))
	pl:SetMaterial("")
	pl:EmitSound("npc/roller/blade_out.wav")
	pl:SendLua([[LocalPlayer():GetViewModel():SetMaterial("")]])
	pl.Cloaked = false
end

function CloakPlayer(pl)
	if not pl:Alive() then return end
	local c = pl.CloakPower or 0
	if c < 300 then return end
	pl:EmitSound("npc/roller/blade_out.wav")
	pl:SetNWBool("disguised", true)
	pl:SetColor(Color(255,255,255,1))
	pl:SetMaterial("le/refract")
	pl:SendLua([[LocalPlayer():GetViewModel():SetMaterial("le/refract")]])
	pl.Cloaked = true
	local wep = pl:GetActiveWeapon()
	wep.Cloaked = true
	wep:SetNoDraw(true)
end

local function Think()
	for k,v in pairs(ents.GetAll()) do
		if not ValidEntity(v) then continue end
		
		if v:IsPlayer() then
			v.Cloaked = v.Cloaked or false
			v.CloakPower = v.CloakPower or 0
			if v.CloakPower <= 0 and v.Cloaked then
				UncloakPlayer(v)
			elseif v.Cloaked then
				local wep = v:GetActiveWeapon()
				if ValidEntity(wep) then
					wep.Cloaked = true
					wep:SetNoDraw(true)
					wep:SetNextPrimaryFire(CurTime() + 0.5)
				end
				
				local speed = v:GetVelocity():Length() + 40
				
				v.CloakPower = v.CloakPower - speed / 200
				if v:KeyDown(IN_ATTACK) then
					//v.CloakPower = 0
					//UncloakPlayer(v)
				end
				if v.CloakPower < 0 then v.CloakPower = 0 end
			else
				v.CloakPower = math.min(1000, v.CloakPower + 0.25)
			end
			v.CloakPower = math.max(0, math.min(1000, v.CloakPower))
			v:SetNWFloat("CloakPower", v.CloakPower)
		elseif v:IsWeapon() then
			if v.Cloaked then
				local owner = v.Owner
				if not owner then
					v:SetNoDraw(false)
					v.Cloaked = false
					continue
				end
				if not owner.Cloaked then
					v:SetNoDraw(false)
					v.Cloaked = false
				end
			end
		end
	end
end
hook.Add("Think", "cloakthink", Think)

concommand.Add("togglecloak", function(pl)
	if not pl:GetNWBool("ownscloak") then return end
	local LastUsed = pl.LastUse or 0
	if CurTime() - LastUsed < 2 then return end
	pl.LastUse = CurTime()
	if pl.Cloaked then
		UncloakPlayer(pl)
	else
		CloakPlayer(pl)
	end
end)

hook.Add("TTTEndRound", "nr", function()
	for k,v in pairs(player.GetAll()) do
		if v.Cloacked then
			UncloakPlayer(v)
		end
		v:SetNWBool("ownscloak", false)
		v.CloakPower = 0
	end
end)

hook.Add("TTTPrepareRound", "nr", function()
	for k,v in pairs(player.GetAll()) do
		v:SetNWBool("ownscloak", false)
		v.CloakPower = 1000
	end
end)
