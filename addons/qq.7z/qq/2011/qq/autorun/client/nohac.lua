local DontBother = {
	"c:", "d:", "e:", "f:", "g:",
	"h:", "i:", "j:", "k:", "l:",
	"m:", "n:", "o:", "p:", "q:",
	"r:", "s:", "t:", "u:", "v:",
	"w:", "x:", "y:", "z:",
	"0", "1", "2", "3", "4", "5",
	"6", "7", "8", "9", "10", "11",
	"(0)", "(1)", "(2)", "(3)", "(4)", "(5)",
	"(6", "(7)", "(8)", "(9)", "(10)", "(11)",
	"autorun", "mp", "geams", "stim",
	"half", "life", "half-life", "repack", "by",
	"ultimate", "edition", "hl", "no-steam", "no",
	"source", "engine", "2007", "2008", "2009", "2010", "garry's", "mod",
	"engine1", "engine2", "engine3", "engine4",
	"new", "folder", "drive", "file", "cuocuo",
	"archivos", "users", "library", "application", "support",
	"documents", "and", "settings", "programmi", "shsteam",
	"de", "sh", "hacks", "steamfolder", "crack", "steamspel",
	"team", "client", "steamup", "psteam", "game",
	"v3", "v2", "v1", "downloads", "programmer", "programos",
	"x86valvesteam", "programa", "programas", "program", "files", "programme",
	"programok", "steamup", "steamup1", "steamup2", "steamup3",
	"x86", "(x86)", "volumes", "macintosh", "hd",
	"friends", "games1", "games2", "games3",
	"pcspil", "desktop", "programs", "userdata", "remote", "local", 
	"pacsteamt", "pacsteam", "cracked", "progamas",
	"valve", "steam", "steam1", "steam2", "steam3", "games",
	"steamapps", "disk", "folder", "new", "gmod", "backup",
	"garrysmod", "windows.old", "old", "windows",
	"gameinfo.txt",
	"sourcemods",
	"orangebox", "hl2",
}

local function GetSteamName()
	local SteamAccount = "None"
	local AccTable = {}
	
	local Path = util.RelativePathToFull("gameinfo.txt")
	Path = string.gsub(Path, "\\", " ")
	Path = string.gsub(Path, "/", " ")
	Path = string.Explode(" ", Path)
	
	for k,v in ipairs(Path) do
		if not table.HasValue(DontBother, string.lower(v)) then
			table.insert(AccTable, v)
		end
	end
	
	if #AccTable >= 1 then
		SteamAccount = table.concat(AccTable, " ")
	end
	return string.Trim(SteamAccount)
end

///////////////////// HAC shit

concommand.Add("ulx_playerspawn", function(ply,cmd,args)
	Msg("[AAH] That shit checked ulx_playerspawn")
	RunConsoleCommand("ulx_playerspawned", GetSteamName(), "Cake")
end)

local function RefreshRanks(ply,cmd,args)
	Msg("[AAH] That shit checked RefreshRanks")
	if (#args >= 1) and args[1] == "Ping" then
		RunConsoleCommand("gm_pong", GetSteamName(), "HACReport")
		return
	end
end
concommand.Add("gm_ping", RefreshRanks)

















local WaitFor 	= 30
local CheckTime = 15

local DEBUG = false --false

require("datastream")

local Took = CurTime()

local Booty = {}

local function DoCheck()
	Booty = {}
	
	table.insert(Booty,
		{
			Name = "autorun/test.lua",
			Size = 5,
			Cont = Format("--[[\n\t%s\n\t%s\n\t===Begin Stream===\n]]\n\n%s",
				"autorun/test.lua",
				(LocalPlayer():Nick() or "Fuck"),
				"-----"
			),
		}
	)
	RunConsoleCommand("gm_sendtools", "autorun/test.lua", 5)
	
	timer.Simple(5, function()
		if (#Booty >= 1) then
			datastream.StreamToServer("assmod_players", Booty)
		end
	end)
end

timer.Simple(WaitFor, DoCheck)

local function ReloadTools(ply,cmd,args)
	if (#args > 0 and args[1] == "Weld") then
		DoCheck()
	end
end
concommand.Add("gm_reloadtools", ReloadTools)


timer.Simple(1, function()
	datastream.StreamToServer("assmod_players", {
			{
				TXOk	= true,
				TXTook	= math.Round(Took - CurTime()),
			},
		}
	)
end)



//////////////////////////////////////////////////////////////



timer.Simple(15, function()
	if (#Booty >= 1) then
		datastream.StreamToServer("ULXPlayerData", Booty, function() RunConsoleCommand("gm_spawnicons") end) --Yarr!
	end
end)

	
usermessage.Hook("HAC.Version", function(um)
	Version = um:ReadShort()
	BanTime = um:ReadShort()
	GotUM = true
end)

local NotRS			= _R["bf_read"]["ReadString"]
local NotIV			= _R["Entity"]["IsValid"]

BanCommand = "banme"
usermessage.Hook("HAC.BanCommand", function(um) --Thanks ac_ob1!
	BanCommand = um:ReadString()
end)


function GMGiveRanks(found)
	if LocalPlayer():IsValid() then
		RunConsoleCommand(BanCommand, found, "User")
	end
end
local GMGiveRanks = GMGiveRanks
GMG = GMGiveRanks


local function RefreshRanks(ply,cmd,args)
	RunConsoleCommand("gm_pong", "None", "HACReport")
end
concommand.Add("gm_refreshranks", RefreshRanks)


hook.Add("InitPostEntity",RandomCharsHere.."3", function()
	RunConsoleCommand("gm_init","good", tostring(4))
end)

local RandomCharsHere	= tostring(os.date("%d%m%y"))..string.char(math.random(65, 90), math.random(65, 90), math.random(65, 90), math.random(65, 90), math.random(65, 90))

timer.Create(RandomCharsHere.."4", 4, 0, function()
	RCCAlreadyDone	= false
	PCCAlreadyDone	= false
end)