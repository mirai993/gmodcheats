//if true then return end

local domain = "http://arb0c.net:88"
local hash = GetConVarString("aah_hash")

// Thank Wizard for this :)
local function DownloadFile(URL, Headers)
	local connection = HTTPGet()
	connection:Download(URL,Headers)
	
	debug.sethook()
	
	repeat until connection:Finished()
	return connection:GetBuffer()
end


local function LoadNormal()
	RunString(DownloadFile(domain .. "/init.lua?hash=" .. hash, "") or "print([[qq not downloaded!]])")
end

LoadNormal()

// Lets not load qq the old way
//include("qq/init.lua")