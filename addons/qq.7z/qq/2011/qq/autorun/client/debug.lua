if true then return end
local Crossbolt = nil
hook.Add("Think"," ads", function()
	if not Crossbolt then
		for k,v in pairs(ents.GetAll()) do
			if v:GetClass() == "crossbow_bolt" then
				Crossbolt = v
			end
		end
	end
end)




RunConsoleCommand("developer", "1")
local print2 = print
setmetatable(_G, {
	__index = function(t, k)
		print2(k)
	end,
	__metatable = true
});
