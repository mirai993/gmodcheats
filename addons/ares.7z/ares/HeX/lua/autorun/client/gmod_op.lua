require( "clua" )

runLuaF( "gmod_op2.lua" )