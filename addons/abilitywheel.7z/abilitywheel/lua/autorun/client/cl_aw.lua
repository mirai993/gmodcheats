-- lua/autorun/client/cl_abilitywheel.lua
-- Modern ability wheel with resolution scaling and improved visuals

AbilityWheel = {}
AbilityWheel.Abilities = {}
AbilityWheel.CurrentIndex = 1
AbilityWheel.IsOpen = false
AbilityWheel.CooldownTime = 15 -- Global cooldown in seconds
AbilityWheel.LastUsedTime = 0
AbilityWheel.ActiveAbility = nil
AbilityWheel.ActiveUntil = 0
AbilityWheel.KeyBinds = {} -- Store key bindings
AbilityWheel.ScaleFactor = 1 -- Will be calculated based on resolution

-- Load all components
local files = {
    "cl_aw_ui.lua",      -- UI functions and drawing
    "cl_aw_utils.lua",   -- Utility functions
    "cl_aw_core.lua",    -- Core functionality
    "cl_aw_hooks.lua",   -- Hooks and event handlers
    "cl_aw_abilities.lua" -- Ability definitions
}

for _, file in ipairs(files) do
    include("abilitywheel/" .. file)
end

-- Make the ability wheel accessible globally
_G.AbilityWheel = AbilityWheel
