-- lua/autorun/server/sv_ability_wheel.lua

-- Create network strings for communication between client and server
util.AddNetworkString("AbilityWheel_SpeedHack")
util.AddNetworkString("AbilityWheel_NoRecoil")
util.AddNetworkString("AbilityWheel_SilentAim")
util.AddNetworkString("AbilityWheel_Triggerbot")
util.AddNetworkString("AbilityWheel_SilentAimTarget")
util.AddNetworkString("AbilityWheel_TriggerbotTarget")
util.AddNetworkString("AbilityWheel_TriggerbotFire")
util.AddNetworkString("AbilityWheel_NoRecoilWeapon")
util.AddNetworkString("AbilityWheel_Teleport") -- New network string for Teleport Dash

-- Store original player values
local playerOriginalValues = {}

-- Helper function to get head position
local function GetHeadPosition(ent)
    if ent:IsPlayer() then
        local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
        if headBone then
            return ent:GetBonePosition(headBone)
        else
            return ent:GetPos() + Vector(0, 0, 70)
        end
    elseif ent:IsNPC() then
        local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
        if headBone then
            return ent:GetBonePosition(headBone)
        else
            -- Estimate head position based on NPC model
            local mins, maxs = ent:GetModelBounds()
            if mins and maxs then
                return ent:GetPos() + Vector(0, 0, maxs.z * 0.9)
            else
                return ent:GetPos() + Vector(0, 0, 50)
            end
        end
    end
    
    return ent:GetPos()
end

-- Helper function to check if entity is valid target
local function IsValidTarget(ply, ent)
    if not IsValid(ent) then return false end
    
    -- Check if entity is a player
    if ent:IsPlayer() and ent ~= ply and ent:Alive() then
        return true
    end
    
    -- Check if entity is an NPC
    if ent:IsNPC() then
        return true
    end
    
    return false
end

-- Speed Hack handler
net.Receive("AbilityWheel_SpeedHack", function(len, ply)
    local activate = net.ReadBool()
    local duration = net.ReadFloat()
    
    if activate then
        -- Store original values if not already stored
        if not playerOriginalValues[ply] then
            playerOriginalValues[ply] = {
                runSpeed = ply:GetRunSpeed(),
                walkSpeed = ply:GetWalkSpeed(),
                jumpPower = ply:GetJumpPower()
            }
        end
        
        -- Apply speed boost
        local speedMultiplier = 2.5
        ply:SetRunSpeed(playerOriginalValues[ply].runSpeed * speedMultiplier)
        ply:SetWalkSpeed(playerOriginalValues[ply].walkSpeed * speedMultiplier)
        ply:SetJumpPower(playerOriginalValues[ply].jumpPower * 1.5)
        
        -- Set active flag
        ply.SpeedHackActive = true
        
        -- Reset after duration
        timer.Create("SpeedHack_" .. ply:SteamID64(), duration, 1, function()
            if IsValid(ply) and playerOriginalValues[ply] then
                ply:SetRunSpeed(playerOriginalValues[ply].runSpeed)
                ply:SetWalkSpeed(playerOriginalValues[ply].walkSpeed)
                ply:SetJumpPower(playerOriginalValues[ply].jumpPower)
                ply.SpeedHackActive = false
            end
        end)
    else
        -- Deactivate early if requested
        if playerOriginalValues[ply] then
            ply:SetRunSpeed(playerOriginalValues[ply].runSpeed)
            ply:SetWalkSpeed(playerOriginalValues[ply].walkSpeed)
            ply:SetJumpPower(playerOriginalValues[ply].jumpPower)
            ply.SpeedHackActive = false
            timer.Remove("SpeedHack_" .. ply:SteamID64())
        end
    end
end)

-- No Recoil handler
net.Receive("AbilityWheel_NoRecoil", function(len, ply)
    local activate = net.ReadBool()
    local duration = net.ReadFloat()
    
    if activate then
        -- Store that this player has no recoil active
        ply.NoRecoilActive = true
        
        -- Reset after duration
        timer.Create("NoRecoil_" .. ply:SteamID64(), duration, 1, function()
            if IsValid(ply) then
                ply.NoRecoilActive = false
            end
        end)
    else
        -- Deactivate early if requested
        ply.NoRecoilActive = false
        timer.Remove("NoRecoil_" .. ply:SteamID64())
    end
end)

-- Silent Aim handler
net.Receive("AbilityWheel_SilentAim", function(len, ply)
    local activate = net.ReadBool()
    local duration = net.ReadFloat()
    
    if activate then
        -- Store that this player has silent aim active
        ply.SilentAimActive = true
        ply.SilentAimFOV = 30 -- FOV in degrees for silent aim
        ply.SilentAimBones = { -- Priority bones to target
            "ValveBiped.Bip01_Head1", -- Head (highest priority)
            "ValveBiped.Bip01_Spine2", -- Upper chest
            "ValveBiped.Bip01_Spine1", -- Lower chest
            "ValveBiped.Bip01_Pelvis" -- Pelvis (lowest priority)
        }
        
        -- Reset after duration
        timer.Create("SilentAim_" .. ply:SteamID64(), duration, 1, function()
            if IsValid(ply) then
                ply.SilentAimActive = false
            end
        end)
    else
        -- Deactivate early if requested
        ply.SilentAimActive = false
        timer.Remove("SilentAim_" .. ply:SteamID64())
    end
end)

-- Triggerbot handler
net.Receive("AbilityWheel_Triggerbot", function(len, ply)
    local activate = net.ReadBool()
    local duration = net.ReadFloat()
    
    if activate then
        -- Store that this player has triggerbot active
        ply.TriggerbotActive = true
        
        -- Reset after duration
        timer.Create("Triggerbot_" .. ply:SteamID64(), duration, 1, function()
            if IsValid(ply) then
                ply.TriggerbotActive = false
            end
        end)
    else
        -- Deactivate early if requested
        ply.TriggerbotActive = false
        timer.Remove("Triggerbot_" .. ply:SteamID64())
    end
end)

-- Add network strings for teleport trajectory visualization and charge
util.AddNetworkString("AbilityWheel_TeleportFailed")
util.AddNetworkString("AbilityWheel_TeleportTrajectory")
util.AddNetworkString("AbilityWheel_TeleportCharge")

-- Teleport Dash handler
net.Receive("AbilityWheel_Teleport", function(len, ply)
    -- Only allow teleport if player is alive
    if not IsValid(ply) or not ply:Alive() then return end
    
    -- Get the charge percentage and direction from the client
    local chargePercent = net.ReadFloat() -- 0.0 to 1.0
    local direction = net.ReadVector() -- Normalized direction vector
    
    -- Get player's current position and eye position
    local currentPos = ply:GetPos()
    local eyePos = ply:EyePos()
    
    -- Make direction flat (aligned with world)
    direction.z = 0
    direction:Normalize()
    
    -- Calculate teleport distance based on charge percentage
    local minDistance = 100 -- Minimum teleport distance
    local maxDistance = 500 -- Maximum teleport distance
    local teleportDistance = minDistance + (maxDistance - minDistance) * chargePercent
    
    -- Maximum wall thickness that can be teleported through
    local maxWallThickness = 100
    
    -- Perform initial trace to find any obstacles
    local initialTrace = util.TraceLine({
        start = eyePos,
        endpos = eyePos + direction * teleportDistance,
        filter = ply,
        mask = MASK_SOLID
    })
    
    local finalPos
    local teleportSuccess = false
    
    if initialTrace.Hit then
        -- We hit something, check if we can teleport through it
        local wallThickness = 0
        local behindWallPos = initialTrace.HitPos + direction * 5 -- Start slightly inside the wall
        
        -- Trace through the wall to see if it's thin enough
        local throughWallTrace = util.TraceLine({
            start = behindWallPos,
            endpos = behindWallPos + direction * maxWallThickness,
            filter = ply,
            mask = MASK_SOLID
        })
        
        if not throughWallTrace.Hit then
            -- Wall is thinner than maxWallThickness, find a valid position on the other side
            local maxCheckDistance = teleportDistance - initialTrace.Fraction * teleportDistance
            
            -- Find ground on the other side of the wall
            local groundTrace = util.TraceLine({
                start = behindWallPos + direction * maxWallThickness,
                endpos = behindWallPos + direction * maxCheckDistance,
                filter = ply,
                mask = MASK_SOLID
            })
            
            if groundTrace.Hit then
                -- Found a valid position on the other side of the wall
                finalPos = groundTrace.HitPos + Vector(0, 0, 5) -- Slightly above ground
                teleportSuccess = true
                
                -- Create effect at wall entry point
                local effectData1 = EffectData()
                effectData1:SetOrigin(initialTrace.HitPos)
                util.Effect("cball_bounce", effectData1)
                
                -- Create effect at wall exit point
                local effectData2 = EffectData()
                effectData2:SetOrigin(behindWallPos + direction * maxWallThickness)
                util.Effect("cball_bounce", effectData2)
            end
        end
    end
    
    -- If we couldn't teleport through a wall, use normal teleport logic
    if not teleportSuccess then
        -- Calculate a flat trajectory (no z component)
        local flatTargetPos = currentPos + direction * teleportDistance
        
        -- Trace to find ground at the target position
        local groundTrace = util.TraceLine({
            start = flatTargetPos + Vector(0, 0, 50), -- Start above target position
            endpos = flatTargetPos - Vector(0, 0, 100), -- End below target position
            filter = ply,
            mask = MASK_SOLID
        })
        
        if groundTrace.Hit then
            -- Found valid ground
            finalPos = groundTrace.HitPos + Vector(0, 0, 5) -- Slightly above ground
            teleportSuccess = true
        end
    end
    
    -- Perform the teleport if we found a valid position
    if teleportSuccess and finalPos then
        -- Check if there's enough room for the player at the destination
        local hullTrace = util.TraceHull({
            start = finalPos,
            endpos = finalPos,
            mins = ply:OBBMins(),
            maxs = ply:OBBMaxs(),
            filter = ply,
            mask = MASK_SOLID
        })
        
        if not hullTrace.Hit then
            -- Create teleport effect at start position
            local effectData1 = EffectData()
            effectData1:SetOrigin(currentPos + Vector(0, 0, 30)) -- At player's torso
            util.Effect("electrical_arc", effectData1)
            
            -- Teleport the player
            ply:SetPos(finalPos)
            
            -- Create teleport effect at destination
            local effectData2 = EffectData()
            effectData2:SetOrigin(finalPos + Vector(0, 0, 30)) -- At player's torso
            util.Effect("cball_explode", effectData2)
            
            -- Create trail effect between positions
            for i = 0, 10 do
                local trailPos = currentPos + (finalPos - currentPos) * (i / 10)
                local effectData = EffectData()
                effectData:SetOrigin(trailPos + Vector(0, 0, 30))
                effectData:SetScale(0.5)
                util.Effect("energy_splash", effectData)
                
                -- Add a small delay between effects for better visualization
                timer.Simple(i * 0.02, function()
                    local beamEffect = EffectData()
                    beamEffect:SetStart(trailPos + Vector(0, 0, 30))
                    beamEffect:SetOrigin(trailPos + Vector(0, 0, 30) + VectorRand() * 10)
                    beamEffect:SetScale(0.1)
                    util.Effect("ToolTracer", beamEffect)
                end)
            end
            
            -- Play teleport sound for everyone nearby
            ply:EmitSound("physics/flesh/flesh_impact_hard" .. math.random(1, 6) .. ".wav", 75, 100, 1)
            
            -- Apply a small velocity dampening to prevent fall damage
            local vel = ply:GetVelocity()
            vel.z = math.max(vel.z, 0) -- Remove any downward velocity
            ply:SetVelocity(vel)
            
        else
            -- Not enough room at destination, notify player
            net.Start("AbilityWheel_TeleportFailed")
            net.Send(ply)
        end
    else
        -- No valid teleport position found, notify player
        net.Start("AbilityWheel_TeleportFailed")
        net.Send(ply)
    end
end)

-- Teleport trajectory visualization handler
net.Receive("AbilityWheel_TeleportTrajectory", function(len, ply)
    -- Only process if player is alive
    if not IsValid(ply) or not ply:Alive() then return end
    
    local chargePercent = net.ReadFloat() -- 0.0 to 1.0
    local direction = net.ReadVector() -- Normalized direction vector
    
    -- Make direction flat (aligned with world)
    direction.z = 0
    direction:Normalize()
    
    -- Calculate teleport distance based on charge percentage
    local minDistance = 100 -- Minimum teleport distance
    local maxDistance = 500 -- Maximum teleport distance
    local teleportDistance = minDistance + (maxDistance - minDistance) * chargePercent
    
    local eyePos = ply:EyePos()
    local currentPos = ply:GetPos()
    
    -- Perform trace to find potential teleport destination
    local trace = util.TraceLine({
        start = eyePos,
        endpos = eyePos + direction * teleportDistance,
        filter = ply,
        mask = MASK_SOLID
    })
    
    local targetPos
    local canTeleport = true
    
    if trace.Hit then
        -- Check if we can teleport through the wall
        local behindWallPos = trace.HitPos + direction * 5
        local throughWallTrace = util.TraceLine({
            start = behindWallPos,
            endpos = behindWallPos + direction * 50,
            filter = ply,
            mask = MASK_SOLID
        })
        
        if not throughWallTrace.Hit then
            -- Can teleport through wall, find ground on other side
            local groundTrace = util.TraceLine({
                start = behindWallPos + direction * 50,
                endpos = behindWallPos + direction * teleportDistance,
                filter = ply,
                mask = MASK_SOLID
            })
            
            if groundTrace.Hit then
                targetPos = groundTrace.HitPos + Vector(0, 0, 5)
            else
                canTeleport = false
            end
        else
            -- Wall too thick
            canTeleport = false
            targetPos = trace.HitPos
        end
    else
        -- No obstacle, find ground at target position
        local groundTrace = util.TraceLine({
            start = eyePos + direction * teleportDistance,
            endpos = eyePos + direction * teleportDistance - Vector(0, 0, 100),
            filter = ply,
            mask = MASK_SOLID
        })
        
        if groundTrace.Hit then
            targetPos = groundTrace.HitPos + Vector(0, 0, 5)
        else
            canTeleport = false
        end
    end
    -- Send trajectory info back to client
    net.Start("AbilityWheel_TeleportTrajectory")
    net.WriteBool(canTeleport)
    if targetPos then
        net.WriteBool(true)
        net.WriteVector(targetPos)
    else
        net.WriteBool(false)
    end
    net.Send(ply)
    
    -- Create visual effects for the trajectory (only visible to the player)
    if targetPos and canTeleport then
        -- Create beam effect along trajectory
        local beamInfo = EffectData()
        beamInfo:SetStart(currentPos + Vector(0, 0, 30))
        beamInfo:SetOrigin(targetPos)
        beamInfo:SetScale(1)
        util.Effect("ToolTracer", beamInfo, true, ply) -- Only visible to the player
        
        -- Create target marker
        local markerInfo = EffectData()
        markerInfo:SetOrigin(targetPos)
        markerInfo:SetScale(1)
        util.Effect("selection_ring", markerInfo, true, ply) -- Only visible to the player
    end
end)

-- Receive target data from client for silent aim
net.Receive("AbilityWheel_SilentAimTarget", function(len, ply)
    if not ply.SilentAimActive then return end
    
    local hasTarget = net.ReadBool()
    if not hasTarget then return end
    
    local targetIndex = net.ReadUInt(16)
    local targetIsNPC = net.ReadBool()
    local boneName = net.ReadString()
    
    -- Store target info for use in EntityFireBullets hook
    ply.SilentAimTargetInfo = {
        index = targetIndex,
        isNPC = targetIsNPC,
        boneName = boneName,
        time = CurTime() -- When this target was selected
    }
end)

-- Triggerbot target handler
net.Receive("AbilityWheel_TriggerbotTarget", function(len, ply)
    if not ply.TriggerbotActive then return end
    
    local hasTarget = net.ReadBool()
    if not hasTarget then return end
    
    local targetIndex = net.ReadUInt(16)
    local targetIsNPC = net.ReadBool()
    
    -- Get the target entity
    local target
    if targetIsNPC then
        for _, npc in ipairs(ents.GetAll()) do
            if npc:IsNPC() and npc:EntIndex() == targetIndex then
                target = npc
                break
            end
        end
    else
        target = Entity(targetIndex)
        if not IsValid(target) or not target:IsPlayer() or not target:Alive() then
            target = nil
        end
    end
    
    -- Verify target is valid
    if not IsValid(target) or not IsValidTarget(ply, target) then return end
    
    -- Check if player's weapon can fire
    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) or not weapon:GetClass():match("weapon_") then return end
    
    -- Check if weapon has ammo
    if weapon.Clip1 and weapon:Clip1() <= 0 then return end
    
    -- Tell client to fire
    net.Start("AbilityWheel_TriggerbotFire")
    net.Send(ply)
end)

-- No Recoil weapon handler
net.Receive("AbilityWheel_NoRecoilWeapon", function(len, ply)
    if not ply.NoRecoilActive then return end
    
    local weaponClass = net.ReadString()
    
    -- Store the weapon class for server-side recoil compensation
    ply.NoRecoilWeaponClass = weaponClass
end)

-- Enhanced Speed Hack hook
hook.Add("Move", "AbilityWheel_ServerSpeedHack", function(ply, mv)
    if not ply.SpeedHackActive then return end
    
    -- Apply additional velocity when moving in air (air strafing boost)
    if not ply:IsOnGround() and (mv:KeyDown(IN_MOVELEFT) or mv:KeyDown(IN_MOVERIGHT) or 
                                mv:KeyDown(IN_FORWARD) or mv:KeyDown(IN_BACK)) then
        local wishDir = Vector(0, 0, 0)
        
        if mv:KeyDown(IN_FORWARD) then
            wishDir = wishDir + ply:GetForward()
        end
        if mv:KeyDown(IN_BACK) then
            wishDir = wishDir - ply:GetForward()
        end
        if mv:KeyDown(IN_MOVELEFT) then
            wishDir = wishDir - ply:GetRight()
        end
        if mv:KeyDown(IN_MOVERIGHT) then
            wishDir = wishDir + ply:GetRight()
        end
        
        wishDir:Normalize()
        
        -- Add extra velocity in the direction of movement
        local airAccel = 30 * FrameTime() * 2.5 -- Use the same multiplier as the speed hack
        mv:SetVelocity(mv:GetVelocity() + wishDir * airAccel)
    end
    
    -- Reduce fall damage
    if ply:WaterLevel() <= 0 and mv:GetVelocity().z < -500 then
        local vel = mv:GetVelocity()
        vel.z = math.max(vel.z, -500) -- Cap falling speed
        mv:SetVelocity(vel)
    end
    
    -- Set max client speed with multiplier
    mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * 2.5)
    
    return false
end)

-- Enhanced No Recoil hook
hook.Add("EntityFireBullets", "AbilityWheel_ServerNoRecoil", function(ent, bulletData)
    if not IsValid(ent) or not ent:IsPlayer() or not ent.NoRecoilActive then return end
    
    -- Reduce spread to almost zero
    bulletData.Spread = Vector(0.001, 0.001, 0)
    
    -- Store the original view punch angles
    if not ent.OriginalViewPunch then
        ent.OriginalViewPunch = ent:GetViewPunchAngles()
    end
    
    -- Reset view punch
    ent:SetViewPunchAngles(Angle(0, 0, 0))
    
    -- Schedule a timer to prevent other code from adding view punch
    timer.Create("NoRecoilReset_" .. ent:SteamID64(), 0.05, 1, function()
        if IsValid(ent) and ent.NoRecoilActive then
            ent:SetViewPunchAngles(Angle(0, 0, 0))
        end
    end)
    
    return true
end)

-- Hook to handle silent aim
hook.Add("EntityFireBullets", "AbilityWheel_ServerSilentAim", function(ent, bulletData)
    if not IsValid(ent) or not ent:IsPlayer() or not ent.SilentAimActive then return end
    
    -- Find best target
    local bestTarget = nil
    local aimPos = nil
    
    -- First check if we have recent target info from client
    if ent.SilentAimTargetInfo and (CurTime() - ent.SilentAimTargetInfo.time) < 0.2 then
        local targetInfo = ent.SilentAimTargetInfo
        local target
        
        if targetInfo.isNPC then
            -- Find NPC by index
            for _, npc in ipairs(ents.GetAll()) do
                if npc:IsNPC() and npc:EntIndex() == targetInfo.index then
                    target = npc
                    break
                end
            end
        else
            -- Find player by index
            target = Entity(targetInfo.index)
            if not IsValid(target) or not target:IsPlayer() or not target:Alive() then
                target = nil
            end
        end
        
        if IsValid(target) and IsValidTarget(ent, target) then
            bestTarget = target
            
            -- Try to get position of specified bone
            if targetInfo.boneName and targetInfo.boneName ~= "" then
                local boneID = target:LookupBone(targetInfo.boneName)
                if boneID then
                    aimPos = target:GetBonePosition(boneID)
                end
            end
            
            -- If bone position failed, use head position
            if not aimPos then
                aimPos = GetHeadPosition(target)
            end
        end
    end
    
    -- If we don't have a valid target from client info, find one ourselves
    if not bestTarget then
        local closestDist = math.huge
        local eyePos = ent:EyePos()
        local aimVector = ent:GetAimVector()
        
        -- Check players first
        for _, target in ipairs(player.GetAll()) do
            if IsValidTarget(ent, target) then
                -- Try to find a valid bone to target
                for _, boneName in ipairs(ent.SilentAimBones or {"ValveBiped.Bip01_Head1"}) do
                    local boneID = target:LookupBone(boneName)
                    if boneID then
                        local bonePos = target:GetBonePosition(boneID)
                        
                        -- Calculate angle between aim vector and target vector
                        local targetVector = (bonePos - eyePos):GetNormalized()
                        local dotProduct = aimVector:Dot(targetVector)
                        local angleDiff = math.deg(math.acos(dotProduct))
                        
                        if angleDiff < (ent.SilentAimFOV or 30) and angleDiff < closestDist then
                            closestDist = angleDiff
                            bestTarget = target
                            aimPos = bonePos
                            
                            -- If we found the head, prioritize it
                            if boneName == "ValveBiped.Bip01_Head1" then
                                break
                            end
                        end
                    end
                end
            end
        end
        
        -- Check NPCs if no player was found
        if not bestTarget then
            for _, target in ipairs(ents.GetAll()) do
                if target:IsNPC() then
                    -- Try to find a valid bone to target
                    for _, boneName in ipairs(ent.SilentAimBones or {"ValveBiped.Bip01_Head1"}) do
                        local boneID = target:LookupBone(boneName)
                        if boneID then
                            local bonePos = target:GetBonePosition(boneID)
                            
                            -- Calculate angle between aim vector and target vector
                            local targetVector = (bonePos - eyePos):GetNormalized()
                            local dotProduct = aimVector:Dot(targetVector)
                            local angleDiff = math.deg(math.acos(dotProduct))
                            
                            if angleDiff < (ent.SilentAimFOV or 30) and angleDiff < closestDist then
                                closestDist = angleDiff
                                bestTarget = target
                                aimPos = bonePos
                                
                                -- If we found the head, prioritize it
                                if boneName == "ValveBiped.Bip01_Head1" then
                                    break
                                end
                            end
                        end
                    end
                    
                    -- If no bones found, use estimated head position
                    if not aimPos and IsValidTarget(ent, target) then
                        local headPos = GetHeadPosition(target)
                        
                        -- Calculate angle between aim vector and target vector
                        local targetVector = (headPos - eyePos):GetNormalized()
                        local dotProduct = aimVector:Dot(targetVector)
                        local angleDiff = math.deg(math.acos(dotProduct))
                        
                        if angleDiff < (ent.SilentAimFOV or 30) and angleDiff < closestDist then
                            closestDist = angleDiff
                            bestTarget = target
                            aimPos = headPos
                        end
                    end
                end
            end
        end
    end
    
    if bestTarget and aimPos then
        -- Add slight randomization for more natural aiming
        local randomOffset = VectorRand() * 1.5
        aimPos = aimPos + randomOffset
        
        -- Adjust bullet direction to hit target
        local newDir = (aimPos - bulletData.Src):GetNormalized()
        bulletData.Dir = newDir
        
        -- Ensure 100% accuracy
        bulletData.Spread = Vector(0, 0, 0)
        
        return true
    end
end)

-- Hook to handle teleport cooldown and rate limiting
hook.Add("PlayerInitialSpawn", "AbilityWheel_InitTeleport", function(ply)
    ply.LastTeleportTime = 0
    ply.TeleportCooldown = 1.5 -- Seconds between teleports (should match client)
end)

-- Hook to clean up when player disconnects
hook.Add("PlayerDisconnected", "AbilityWheel_CleanupPlayer", function(ply)
    playerOriginalValues[ply] = nil
    timer.Remove("SpeedHack_" .. ply:SteamID64())
    timer.Remove("NoRecoil_" .. ply:SteamID64())
    timer.Remove("SilentAim_" .. ply:SteamID64())
    timer.Remove("Triggerbot_" .. ply:SteamID64())
    timer.Remove("NoRecoilReset_" .. ply:SteamID64())
end)
