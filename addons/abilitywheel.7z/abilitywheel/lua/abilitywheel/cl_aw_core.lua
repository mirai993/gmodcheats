-- lua/abilitywheel/cl_aw_core.lua
-- Core functionality for the ability wheel

-- Function to toggle the wheel
function AbilityWheel:Toggle()
    if not self.IsOpen then
        -- Opening the wheel
        self.IsOpen = true
        surface.PlaySound("ui/buttonrollover.wav")
    else
        -- Closing the wheel - use the selected ability
        self.IsOpen = false
        self:UseAbility()
    end
end

-- Function to cycle to next ability
function AbilityWheel:Next()
    if not self.IsOpen then return end
    
    self.CurrentIndex = (self.CurrentIndex % #self.Abilities) + 1
    surface.PlaySound("buttons/button15.wav") -- Add sound feedback
end

-- Function to cycle to previous ability
function AbilityWheel:Previous()
    if not self.IsOpen then return end
    
    self.CurrentIndex = self.CurrentIndex - 1
    if self.CurrentIndex < 1 then
        self.CurrentIndex = #self.Abilities
    end
    surface.PlaySound("buttons/button15.wav") -- Add sound feedback
end

-- Function to use the current ability
function AbilityWheel:UseAbility()
    -- Check if on cooldown
    if CurTime() < self.LastUsedTime + self.CooldownTime then
        local remainingTime = math.ceil(self.LastUsedTime + self.CooldownTime - CurTime())
        surface.PlaySound("buttons/button10.wav") -- Error sound
        return false
    end
    
    local ability = self.Abilities[self.CurrentIndex]
    if ability and ability.func then
        -- Set cooldown
        self.LastUsedTime = CurTime()
        
        -- Set as active ability
        self.ActiveAbility = ability
        self.ActiveUntil = CurTime() + ability.duration
        
        -- Execute ability function
        ability.func()
        
        -- Play activation sound
        surface.PlaySound("buttons/button3.wav")
        
        -- Start the deactivation timer
        timer.Create("AbilityDeactivation", ability.duration, 1, function()
            if ability.endFunc then
                ability.endFunc()
            end
            self.ActiveAbility = nil
            surface.PlaySound("buttons/button18.wav") -- Deactivation sound
        end)
        
        return true
    end
    
    return false
end

-- Register console commands
concommand.Add("+abilitywheel", function()
    AbilityWheel:Toggle()
end)

concommand.Add("-abilitywheel", function()
    if AbilityWheel.IsOpen then
        AbilityWheel:Toggle() -- This will close the wheel and use the ability
    end
end)

-- Add +/- commands for cycling abilities
concommand.Add("+nextability", function()
    if AbilityWheel.IsOpen then
        AbilityWheel:Next()
    end
end)

concommand.Add("-nextability", function()
    -- Empty, action happens on key press
end)

concommand.Add("+prevability", function()
    if AbilityWheel.IsOpen then
        AbilityWheel:Previous()
    end
end)

concommand.Add("-prevability", function()
    -- Empty, action happens on key press
end)