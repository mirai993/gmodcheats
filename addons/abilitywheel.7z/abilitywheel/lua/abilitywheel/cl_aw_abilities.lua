-- lua/abilitywheel/cl_abilitywheel_abilities.lua
-- Ability definitions for the ability wheel

-- Add descriptions to abilities for the new UI
AbilityWheel.Abilities = {
    {
        name = "Wallhack & ESP", 
        icon = nil, 
        duration = 15,
        description = "See players and NPCs through walls with health and distance info.",
        func = function() 
            -- Wallhack is handled in the HUDPaint hook for ESP
            -- Add wallhack rendering
            hook.Add("PreDrawOpaqueRenderables", "WallhackHook", function()
                cam.IgnoreZ(true)
                
                -- Draw players through walls
                for _, ply in ipairs(player.GetAll()) do
                    if ply ~= LocalPlayer() and ply:Alive() then
                        local color = team.GetColor(ply:Team())
                        color.a = 50 -- Make it semi-transparent
                        
                        render.SetColorModulation(color.r/255, color.g/255, color.b/255)
                        render.SetBlend(0.3)
                        
                        ply:DrawModel()
                    end
                end
                
                -- Draw NPCs through walls
                for _, ent in ipairs(ents.GetAll()) do
                    if ent:IsNPC() then
                        render.SetColorModulation(1, 0.6, 0) -- Orange for NPCs
                        render.SetBlend(0.3)
                        
                        ent:DrawModel()
                    end
                end
                
                cam.IgnoreZ(false)
                render.SetBlend(1)
                render.SetColorModulation(1, 1, 1)
            end)
            
        end,
        endFunc = function()
            hook.Remove("PreDrawOpaqueRenderables", "WallhackHook")
            chat.AddText(Color(255, 100, 100), "Wallhack & ESP deactivated!")
        end
    },
    {
        name = "Silent Aim", 
        icon = nil, 
        duration = 10,
        description = "Automatically aim at targets within your FOV without visible crosshair movement.",
        func = function() 
            -- Set up improved silent aim with server-side aim adjustment
            AbilityWheel.SilentAimFOV = 30 -- FOV in degrees for silent aim
            AbilityWheel.SilentAimBones = { -- Priority bones to target
                "ValveBiped.Bip01_Head1", -- Head (highest priority)
                "ValveBiped.Bip01_Spine2", -- Upper chest
                "ValveBiped.Bip01_Spine1", -- Lower chest
                "ValveBiped.Bip01_Pelvis" -- Pelvis (lowest priority)
            }
            
            -- Tell server to activate silent aim
            net.Start("AbilityWheel_SilentAim")
            net.WriteBool(true)
            net.WriteFloat(10) -- Duration
            net.SendToServer()
            
            -- Draw FOV circle for silent aim
            hook.Add("HUDPaint", "SilentAimFOVCircle", function()
                local centerX, centerY = ScrW() / 2, ScrH() / 2
                local radius = math.tan(math.rad(AbilityWheel.SilentAimFOV / 2)) / math.tan(math.rad(LocalPlayer():GetFOV() / 2)) * ScrH() / 2
                
                -- Draw fancy FOV circle with gradient and pulse effect
                local pulseAmount = math.sin(CurTime() * 3) * 0.2 + 0.8
                local segments = 36
                
                for i = 1, 3 do -- Draw multiple circles for better visibility
                    local circleRadius = radius * (1 + (i - 1) * 0.02)
                    local alpha = 50 * (1 - (i - 1) * 0.3) * pulseAmount
                    
                    for j = 0, segments - 1 do
                        local angle1 = math.rad(j * 360 / segments)
                        local angle2 = math.rad((j + 1) * 360 / segments)
                        
                        local x1 = centerX + circleRadius * math.cos(angle1)
                        local y1 = centerY + circleRadius * math.sin(angle1)
                        local x2 = centerX + circleRadius * math.cos(angle2)
                        local y2 = centerY + circleRadius * math.sin(angle2)
                        
                        local gradientColor = Color(
                            255, 
                            50 + 50 * math.sin(j * 0.5 + CurTime() * 2), 
                            50, 
                            alpha
                        )
                        
                        surface.SetDrawColor(gradientColor)
                        surface.DrawLine(x1, y1, x2, y2)
                    end
                end
            end)
            
            -- Add hook to continuously send target info to server
            hook.Add("Think", "SilentAimTargetFinder", function()
                if not LocalPlayer():Alive() then return end
                
                -- Only send updates every 0.1 seconds to reduce network traffic
                if AbilityWheel.LastTargetUpdate and CurTime() - AbilityWheel.LastTargetUpdate < 0.1 then
                    return
                end
                
                AbilityWheel.LastTargetUpdate = CurTime()
                
                -- Find closest valid target to crosshair
                local closestTarget = nil
                local closestDist = AbilityWheel.SilentAimFOV -- Max degrees from crosshair
                local targetBone = ""
                local centerX, centerY = ScrW() / 2, ScrH() / 2
                
                -- Check players first
                for _, target in ipairs(player.GetAll()) do
                    if target ~= LocalPlayer() and target:Alive() then
                        -- Try to find a valid bone to target
                        for _, boneName in ipairs(AbilityWheel.SilentAimBones) do
                            local boneID = target:LookupBone(boneName)
                            if boneID then
                                local bonePos = target:GetBonePosition(boneID)
                                local screenPos = bonePos:ToScreen()
                                
                                local dist = math.sqrt((screenPos.x - centerX)^2 + (screenPos.y - centerY)^2)
                                local fovDist = (dist / ScrH()) * 90 -- Convert to approximate degrees
                                
                                if fovDist < closestDist then
                                    closestDist = fovDist
                                    closestTarget = target
                                    targetBone = boneName
                                    
                                    -- If we found the head, prioritize it
                                    if boneName == "ValveBiped.Bip01_Head1" then
                                        break
                                    end
                                end
                            end
                        end
                    end
                end
                
                -- Check NPCs if no player was found in FOV
                if not closestTarget then
                    for _, target in ipairs(ents.GetAll()) do
                        if target:IsNPC() then
                            -- Try to find a valid bone to target
                            for _, boneName in ipairs(AbilityWheel.SilentAimBones) do
                                local boneID = target:LookupBone(boneName)
                                if boneID then
                                    local bonePos = target:GetBonePosition(boneID)
                                    local screenPos = bonePos:ToScreen()
                                    
                                    local dist = math.sqrt((screenPos.x - centerX)^2 + (screenPos.y - centerY)^2)
                                    local fovDist = (dist / ScrH()) * 90 -- Convert to approximate degrees
                                    
                                    if fovDist < closestDist then
                                        closestDist = fovDist
                                        closestTarget = target
                                        targetBone = boneName
                                        
                                        -- If we found the head, prioritize it
                                        if boneName == "ValveBiped.Bip01_Head1" then
                                            break
                                        end
                                    end
                                end
                            end
                            
                            -- If no bones found, use estimated head position
                            if not closestTarget and AbilityWheel:IsValidTarget(target) then
                                local headPos = AbilityWheel:GetHeadPosition(target)
                                local screenPos = headPos:ToScreen()
                                
                                local dist = math.sqrt((screenPos.x - centerX)^2 + (screenPos.y - centerY)^2)
                                local fovDist = (dist / ScrH()) * 90 -- Convert to approximate degrees
                                
                                if fovDist < closestDist then
                                    closestDist = fovDist
                                    closestTarget = target
                                    targetBone = "ValveBiped.Bip01_Head1" -- Default to head
                                end
                            end
                        end
                    end
                end
                
                -- Send target info to server
                net.Start("AbilityWheel_SilentAimTarget")
                
                if closestTarget then
                    net.WriteBool(true) -- Has target
                    net.WriteUInt(closestTarget:EntIndex(), 16) -- Entity index
                    net.WriteBool(closestTarget:IsNPC()) -- Is NPC
                    net.WriteString(targetBone) -- Bone name
                else
                    net.WriteBool(false) -- No target
                end
                
                net.SendToServer()
            end)
            
        end,
        endFunc = function()
            -- Tell server to deactivate silent aim
            net.Start("AbilityWheel_SilentAim")
            net.WriteBool(false)
            net.WriteFloat(0)
            net.SendToServer()
            
            hook.Remove("Think", "SilentAimTargetFinder")
            hook.Remove("HUDPaint", "SilentAimFOVCircle")
        end
    },
    {
        name = "Speed Hack", 
        icon = nil, 
        duration = 8,
        description = "Move faster with reduced fall damage and enhanced air control.",
        func = function() 
            -- Set up enhanced speed hack with server-side validation
            
            -- Tell server to activate speed hack
            net.Start("AbilityWheel_SpeedHack")
            net.WriteBool(true)
            net.WriteFloat(8) -- Duration
            net.SendToServer()
            
            -- Store original movement values for client-side effects
            AbilityWheel.OriginalRunSpeed = LocalPlayer():GetRunSpeed()
            AbilityWheel.OriginalWalkSpeed = LocalPlayer():GetWalkSpeed()
            AbilityWheel.SpeedMultiplier = 2.5
            
            -- Add visual effects for speed
            hook.Add("RenderScreenspaceEffects", "SpeedHackEffect", function()
                local vel = LocalPlayer():GetVelocity():Length()
                local maxSpeed = AbilityWheel.OriginalRunSpeed * AbilityWheel.SpeedMultiplier
                
                if vel > maxSpeed * 0.7 then
                    local intensity = math.Clamp((vel - maxSpeed * 0.7) / (maxSpeed * 0.3), 0, 1) * 0.2
                    
                    -- Add motion blur effect
                    DrawMotionBlur(0.1, intensity, 0.01)
                    
                    -- Add color correction for speed effect
                    local colorModify = {
                        ["$pp_colour_addr"] = 0,
                        ["$pp_colour_addg"] = intensity * 0.1,
                        ["$pp_colour_addb"] = intensity * 0.2,
                        ["$pp_colour_brightness"] = 0,
                        ["$pp_colour_contrast"] = 1 + intensity * 0.2,
                        ["$pp_colour_colour"] = 1 + intensity * 0.5,
                        ["$pp_colour_mulr"] = 0,
                        ["$pp_colour_mulg"] = 0,
                        ["$pp_colour_mulb"] = 0
                    }
                    
                    DrawColorModify(colorModify)
                end
            end)
            
            -- Add HUD speedometer with modern style
            hook.Add("HUDPaint", "SpeedHackSpeedometer", function()
                local scale = AbilityWheel.ScaleFactor
                local vel = LocalPlayer():GetVelocity()
                local speed = math.Round(math.sqrt(vel.x^2 + vel.y^2))
                
                -- Draw speedometer background
                local speedWidth = math.Round(120 * scale)
                local speedHeight = math.Round(40 * scale)
                local speedX = ScrW() - speedWidth - math.Round(20 * scale)
                local speedY = ScrH() - speedHeight - math.Round(20 * scale)
                
                -- Draw rounded background
                draw.RoundedBox(math.Round(6 * scale), speedX, speedY, speedWidth, speedHeight, 
                               Color(20, 20, 20, 180))
                
                -- Draw speed text
                local speedColor = speed > 400 and Color(50, 255, 50, 255) or Color(255, 255, 255, 255)
                draw.SimpleText("SPEED", "AbilityWheel_Tiny", speedX + math.Round(10 * scale), speedY + math.Round(10 * scale), 
                               Color(200, 200, 200, 200), TEXT_ALIGN_LEFT)
                
                draw.SimpleText(speed .. " u/s", "AbilityWheel_Normal", speedX + speedWidth - math.Round(10 * scale), 
                               speedY + math.Round(20 * scale), speedColor, TEXT_ALIGN_RIGHT)
            end)
            
        end,
        endFunc = function()
            -- Tell server to deactivate speed hack
            net.Start("AbilityWheel_SpeedHack")
            net.WriteBool(false)
            net.WriteFloat(0)
            net.SendToServer()
            
            hook.Remove("RenderScreenspaceEffects", "SpeedHackEffect")
            hook.Remove("HUDPaint", "SpeedHackSpeedometer")
            
            AbilityWheel.OriginalRunSpeed = nil
            AbilityWheel.OriginalWalkSpeed = nil
            
        end
    },
    {
        name = "No Spread", 
        icon = nil, 
        duration = 15,
        description = "Eliminate weapon recoil and reduce spread for perfect accuracy.",
        func = function() 
            -- Set up enhanced no recoil with server-side validation
            
            -- Tell server to activate no recoil
            net.Start("AbilityWheel_NoRecoil")
            net.WriteBool(true)
            net.WriteFloat(15) -- Duration
            net.SendToServer()
            
            -- Store original view punch angles
            AbilityWheel.OriginalViewPunch = LocalPlayer():GetViewPunchAngles()
            
            -- Hook to prevent view punch locally
            hook.Add("CalcView", "NoRecoilHook", function(ply, pos, angles, fov)
                if ply ~= LocalPlayer() then return end
                
                -- Reset view punch
                ply:SetViewPunchAngles(Angle(0, 0, 0))
                
                -- Return modified view
                return {
                    origin = pos,
                    angles = angles,
                    fov = fov,
                    drawviewer = false
                }
            end)
            
            -- Hook to send weapon info to server
            hook.Add("Think", "NoRecoilWeaponInfoSender", function()
                local activeWeapon = LocalPlayer():GetActiveWeapon()
                if not IsValid(activeWeapon) then return end
                
                -- Only send updates when weapon changes
                if AbilityWheel.LastWeaponClass ~= activeWeapon:GetClass() then
                    AbilityWheel.LastWeaponClass = activeWeapon:GetClass()
                    
                    -- Send weapon class to server
                    net.Start("AbilityWheel_NoRecoilWeapon")
                    net.WriteString(activeWeapon:GetClass())
                    net.SendToServer()
                end
            end)
            
        end,
        endFunc = function()
            -- Tell server to deactivate no recoil
            net.Start("AbilityWheel_NoRecoil")
            net.WriteBool(false)
            net.WriteFloat(0)
            net.SendToServer()
            
            -- Restore original view punch
            if AbilityWheel.OriginalViewPunch and IsValid(LocalPlayer()) then
                LocalPlayer():SetViewPunchAngles(AbilityWheel.OriginalViewPunch)
                AbilityWheel.OriginalViewPunch = nil
            end
            
            AbilityWheel.LastWeaponClass = nil
            
            hook.Remove("CalcView", "NoRecoilHook")
            hook.Remove("Think", "NoRecoilWeaponInfoSender")
            hook.Remove("HUDPaint", "NoRecoilIndicator")
            
        end
    },
    {
        name = "Bunny Hop", 
        icon = nil, 
        duration = 20,
        description = "Automatically jump when holding space with optimized air strafing.",
        func = function() 
            -- Set up bunny hop
            AbilityWheel.BunnyHopActive = true
            
            -- Add hook to automatically jump when on ground
            hook.Add("CreateMove", "BunnyHopHook", function(cmd)
                if not AbilityWheel.BunnyHopActive then return end
                
                -- Only auto-jump if holding space
                if not input.IsKeyDown(KEY_SPACE) then return end
                
                -- Check if on ground
                if bit.band(LocalPlayer():GetFlags(), FL_ONGROUND) ~= 0 then
                    -- Jump
                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
                else
                    -- Release jump button in air for better control
                    cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_JUMP)))
                end
                
                -- Air strafing optimization
                if bit.band(LocalPlayer():GetFlags(), FL_ONGROUND) == 0 then
                    -- Get movement direction
                    local mouseDelta = cmd:GetMouseX()
                    
                    if mouseDelta > 0 then
                        -- Strafing right
                        cmd:SetSideMove(400)
                    elseif mouseDelta < 0 then
                        -- Strafing left
                        cmd:SetSideMove(-400)
                    end
                end
            end)
            
            -- Add visual indicator with modern style
            hook.Add("HUDPaint", "BunnyHopIndicator", function()
                local scale = AbilityWheel.ScaleFactor
                local vel = LocalPlayer():GetVelocity()
                local speed = math.Round(math.sqrt(vel.x^2 + vel.y^2))
                
                -- Draw indicator background
                local indicatorWidth = math.Round(180 * scale)
                local indicatorHeight = math.Round(60 * scale)
                local indicatorX = ScrW() - indicatorWidth - math.Round(20 * scale)
                local indicatorY = ScrH() - math.Round(230 * scale)
                
                -- Draw rounded background with glow effect
                local pulseAmount = math.sin(CurTime() * 2) * 0.1 + 0.9
                local glowColor = Color(255, 50, 255, 30 * pulseAmount)
                
                -- Draw glow
                for i = 1, 3 do
                    draw.RoundedBox(math.Round(6 * scale), 
                                   indicatorX - i * 2, indicatorY - i * 2, 
                                   indicatorWidth + i * 4, indicatorHeight + i * 4, 
                                   Color(glowColor.r, glowColor.g, glowColor.b, glowColor.a / i))
                end
                
                -- Draw background
                draw.RoundedBox(math.Round(6 * scale), indicatorX, indicatorY, indicatorWidth, indicatorHeight, 
                               Color(20, 20, 20, 180))
                
                -- Draw title with shadow
                draw.SimpleText("BUNNY HOP", "AbilityWheel_Small", 
                               indicatorX + math.Round(10 * scale), indicatorY + math.Round(10 * scale) + 1, 
                               Color(0, 0, 0, 180), TEXT_ALIGN_LEFT)
                draw.SimpleText("BUNNY HOP", "AbilityWheel_Small", 
                               indicatorX + math.Round(10 * scale), indicatorY + math.Round(10 * scale), 
                               Color(255, 50, 255, 255), TEXT_ALIGN_LEFT)
                
                -- Draw speed with shadow
                local speedColor = speed > 400 and Color(255, 50, 255, 255) or Color(255, 255, 255, 255)
                draw.SimpleText(speed .. " u/s", "AbilityWheel_Normal", 
                               indicatorX + indicatorWidth - math.Round(10 * scale), 
                               indicatorY + math.Round(30 * scale) + 1, 
                               Color(0, 0, 0, 180), TEXT_ALIGN_RIGHT)
                draw.SimpleText(speed .. " u/s", "AbilityWheel_Normal", 
                               indicatorX + indicatorWidth - math.Round(10 * scale), 
                               indicatorY + math.Round(30 * scale), 
                               speedColor, TEXT_ALIGN_RIGHT)
                
                -- Draw hint
                draw.SimpleText("Hold SPACE to use", "AbilityWheel_Tiny", 
                               indicatorX + math.Round(10 * scale), indicatorY + math.Round(40 * scale), 
                               Color(200, 200, 200, 200), TEXT_ALIGN_LEFT)
            end)
            
        end,
        endFunc = function()
            AbilityWheel.BunnyHopActive = false
            hook.Remove("CreateMove", "BunnyHopHook")
            hook.Remove("HUDPaint", "BunnyHopIndicator")
        end
    },
    {
        name = "Teleport Dash", 
        icon = nil, 
        duration = 12,
        description = "Instantly teleport short distances in your view direction. Hold F longer to teleport further.",
        func = function() 
            -- Set up teleport dash ability
            AbilityWheel.TeleportActive = true
            AbilityWheel.LastTeleport = 0
            AbilityWheel.TeleportCooldown = 1.5 -- Seconds between teleports
            AbilityWheel.TeleportKey = KEY_F -- Key to trigger teleport
            AbilityWheel.TeleportCharging = false
            AbilityWheel.TeleportChargeStart = 0
            AbilityWheel.TeleportMaxChargeTime = 1.0 -- Time to reach max distance
            AbilityWheel.TeleportMinDistance = 100
            AbilityWheel.TeleportMaxDistance = 500
            AbilityWheel.TeleportTrajectoryValid = false
            AbilityWheel.TeleportTargetPos = nil
            
            -- Handle teleport failure notification
            net.Receive("AbilityWheel_TeleportFailed", function()
                surface.PlaySound("buttons/button10.wav")
                
                -- Add screen effect to indicate failure
                local redFlash = 0
                hook.Add("RenderScreenspaceEffects", "TeleportFailEffect", function()
                    if redFlash > 0 then
                        DrawColorModify({
                            ["$pp_colour_addr"] = redFlash * 0.5,
                            ["$pp_colour_addg"] = 0,
                            ["$pp_colour_addb"] = 0,
                            ["$pp_colour_brightness"] = 0,
                            ["$pp_colour_contrast"] = 1,
                            ["$pp_colour_colour"] = 1,
                            ["$pp_colour_mulr"] = 0,
                            ["$pp_colour_mulg"] = 0,
                            ["$pp_colour_mulb"] = 0
                        })
                        redFlash = redFlash - FrameTime() * 5
                    else
                        hook.Remove("RenderScreenspaceEffects", "TeleportFailEffect")
                    end
                end)
                
                redFlash = 0.5
            end)
            
            -- Handle trajectory visualization response
            net.Receive("AbilityWheel_TeleportTrajectory", function()
                local isValid = net.ReadBool()
                AbilityWheel.TeleportTrajectoryValid = isValid
                
                local hasTarget = net.ReadBool()
                if hasTarget then
                    AbilityWheel.TeleportTargetPos = net.ReadVector()
                else
                    AbilityWheel.TeleportTargetPos = nil
                end
            end)
            
            -- Add hook to handle teleport key press and charge
            hook.Add("Think", "TeleportDashThink", function()
                if not AbilityWheel.TeleportActive then return end
                
                -- Check if teleport key is pressed and cooldown has passed
                if input.IsKeyDown(AbilityWheel.TeleportKey) then
                    if CurTime() - AbilityWheel.LastTeleport > AbilityWheel.TeleportCooldown and
                       LocalPlayer():Alive() then
                        
                        -- Start charging if not already charging
                        if not AbilityWheel.TeleportCharging then
                            AbilityWheel.TeleportCharging = true
                            AbilityWheel.TeleportChargeStart = CurTime()
                            
                            -- Play charge start sound
                            surface.PlaySound("weapons/physcannon/energy_sing_loop4.wav")
                        end
                        
                        -- Calculate charge percentage
                        local chargeTime = CurTime() - AbilityWheel.TeleportChargeStart
                        local chargePercent = math.Clamp(chargeTime / AbilityWheel.TeleportMaxChargeTime, 0, 1)
                        
                        -- Get direction vector (flat)
                        local viewAngle = LocalPlayer():EyeAngles()
                        local direction = viewAngle:Forward()
                        direction.z = 0
                        direction:Normalize()
                        
                        -- Send trajectory request to server
                        net.Start("AbilityWheel_TeleportTrajectory")
                        net.WriteFloat(chargePercent)
                        net.WriteVector(direction)
                        net.SendToServer()
                    end
                elseif AbilityWheel.TeleportCharging then
                    -- Key released, perform teleport
                    AbilityWheel.TeleportCharging = false
                    
                    -- Calculate final charge percentage
                    local chargeTime = CurTime() - AbilityWheel.TeleportChargeStart
                    local chargePercent = math.Clamp(chargeTime / AbilityWheel.TeleportMaxChargeTime, 0, 1)
                    
                    -- Get direction vector (flat)
                    local viewAngle = LocalPlayer():EyeAngles()
                    local direction = viewAngle:Forward()
                    direction.z = 0
                    direction:Normalize()
                    
                    -- Send teleport request to server
                    net.Start("AbilityWheel_Teleport")
                    net.WriteFloat(chargePercent)
                    net.WriteVector(direction)
                    net.SendToServer()
                    
                    -- Set cooldown
                    AbilityWheel.LastTeleport = CurTime()
                    
                    -- Stop charge sound
                    LocalPlayer():StopSound("weapons/physcannon/energy_sing_loop4.wav")
                    
                    -- Play teleport sound
                    surface.PlaySound("weapons/physcannon/superphys_launch" .. math.random(1, 4) .. ".wav")
                end
            end)
            
            -- Add HUD indicator for teleport cooldown and charge
            hook.Add("HUDPaint", "TeleportDashIndicator", function()
                local scale = AbilityWheel.ScaleFactor or 1
                
                -- Draw cooldown indicator
                local indicatorWidth = math.Round(180 * scale)
                local indicatorHeight = math.Round(60 * scale)
                local indicatorX = ScrW() - indicatorWidth - math.Round(20 * scale)
                local indicatorY = ScrH() - math.Round(160 * scale)
                
                -- Calculate cooldown percentage
                local cooldownTime = CurTime() - AbilityWheel.LastTeleport
                local cooldownPercent = math.Clamp(cooldownTime / AbilityWheel.TeleportCooldown, 0, 1)
                
                -- Draw background
                draw.RoundedBox(math.Round(6 * scale), indicatorX, indicatorY, indicatorWidth, indicatorHeight, 
                               Color(20, 20, 20, 180))
                
                -- Draw title
                draw.SimpleText("TELEPORT DASH", "AbilityWheel_Small", 
                               indicatorX + math.Round(10 * scale), indicatorY + math.Round(10 * scale), 
                               Color(100, 100, 255, 255), TEXT_ALIGN_LEFT)
                
                -- Draw cooldown bar background
                draw.RoundedBox(math.Round(3 * scale), 
                               indicatorX + math.Round(10 * scale), 
                               indicatorY + math.Round(30 * scale), 
                               indicatorWidth - math.Round(20 * scale), 
                               math.Round(10 * scale), 
                               Color(40, 40, 40, 180))
                
                -- Draw cooldown bar fill
                draw.RoundedBox(math.Round(3 * scale), 
                               indicatorX + math.Round(10 * scale), 
                               indicatorY + math.Round(30 * scale), 
                               (indicatorWidth - math.Round(20 * scale)) * cooldownPercent, 
                               math.Round(10 * scale), 
                               cooldownPercent == 1 and Color(100, 200, 255, 255) or Color(100, 100, 255, 255))
                
                -- Draw key hint
                local keyName = input.GetKeyName(AbilityWheel.TeleportKey)
                
                if AbilityWheel.TeleportCharging then
                    -- Calculate charge percentage
                    local chargeTime = CurTime() - AbilityWheel.TeleportChargeStart
                    local chargePercent = math.Clamp(chargeTime / AbilityWheel.TeleportMaxChargeTime, 0, 1)
                    
                    -- Draw charge text
                    local chargeColor = AbilityWheel.TeleportTrajectoryValid and 
                                       Color(100, 255, 100, 255) or 
                                       Color(255, 100, 100, 255)
                    
                    draw.SimpleText("CHARGING: " .. math.floor(chargePercent * 100) .. "%", "AbilityWheel_Tiny", 
                                   indicatorX + math.Round(10 * scale), indicatorY + math.Round(45 * scale), 
                                   chargeColor, TEXT_ALIGN_LEFT)
                    
                    -- Draw distance
                    local distance = AbilityWheel.TeleportMinDistance + 
                                   (AbilityWheel.TeleportMaxDistance - AbilityWheel.TeleportMinDistance) * chargePercent
                    
                    draw.SimpleText(math.floor(distance) .. " units", "AbilityWheel_Tiny", 
                                   indicatorX + indicatorWidth - math.Round(10 * scale), 
                                   indicatorY + math.Round(45 * scale), 
                                   chargeColor, TEXT_ALIGN_RIGHT)
                    
                    -- Draw charge bar
                    draw.RoundedBox(math.Round(3 * scale), 
                                   indicatorX + math.Round(10 * scale), 
                                   indicatorY + math.Round(45 * scale) + math.Round(15 * scale), 
                                   indicatorWidth - math.Round(20 * scale), 
                                   math.Round(5 * scale), 
                                   Color(40, 40, 40, 180))
                    
                    draw.RoundedBox(math.Round(3 * scale), 
                                   indicatorX + math.Round(10 * scale), 
                                   indicatorY + math.Round(45 * scale) + math.Round(15 * scale), 
                                   (indicatorWidth - math.Round(20 * scale)) * chargePercent, 
                                   math.Round(5 * scale), 
                                   chargeColor)
                else
                    draw.SimpleText("Hold " .. string.upper(keyName) .. " to charge teleport", "AbilityWheel_Tiny", 
                                   indicatorX + math.Round(10 * scale), indicatorY + math.Round(45 * scale), 
                                   Color(200, 200, 200, 200), TEXT_ALIGN_LEFT)
                    
                    -- Draw ready indicator
                    if cooldownPercent >= 1 then
                        local pulseAmount = math.sin(CurTime() * 4) * 0.2 + 0.8
                        draw.SimpleText("READY", "AbilityWheel_Tiny", 
                                       indicatorX + indicatorWidth - math.Round(10 * scale), 
                                       indicatorY + math.Round(45 * scale), 
                                       Color(100, 255, 100, 255 * pulseAmount), TEXT_ALIGN_RIGHT)
                    else
                        draw.SimpleText(math.ceil((AbilityWheel.TeleportCooldown - cooldownTime) * 10) / 10 .. "s", 
                                       "AbilityWheel_Tiny", 
                                       indicatorX + indicatorWidth - math.Round(10 * scale), 
                                       indicatorY + math.Round(45 * scale), 
                                       Color(200, 200, 200, 200), TEXT_ALIGN_RIGHT)
                    end
                end
                
                -- Draw trajectory visualization if charging
                if AbilityWheel.TeleportCharging and AbilityWheel.TeleportTargetPos then
                    local startPos = LocalPlayer():GetPos() + Vector(0, 0, 30)
                    local endPos = AbilityWheel.TeleportTargetPos
                    
                    -- Draw line from player to target position
                    cam.Start3D()
                        render.SetColorMaterial()
                        
                        -- Draw trajectory line
                        local color = AbilityWheel.TeleportTrajectoryValid and 
                                     Color(100, 200, 255, 150) or 
                                     Color(255, 100, 100, 150)
                        
                        render.DrawBeam(
                            startPos,
                            endPos,
                            5,
                            0,
                            1,
                            color
                        )
                        
                        -- Draw target position marker
                        render.DrawWireframeSphere(
                            endPos,
                            20,
                            10,
                            10,
                            color,
                            true
                        )
                    cam.End3D()
                end
            end)
            
            -- Show tutorial message
            chat.AddText(Color(100, 100, 255), "Teleport Dash activated! ", Color(255, 255, 255), "Hold ", 
                        Color(255, 255, 100), string.upper(input.GetKeyName(AbilityWheel.TeleportKey)), 
                        Color(255, 255, 255), " to charge and release to teleport. Hold longer to go further!")
        end,
        endFunc = function()
            AbilityWheel.TeleportActive = false
            hook.Remove("Think", "TeleportDashThink")
            hook.Remove("HUDPaint", "TeleportDashIndicator")
            hook.Remove("RenderScreenspaceEffects", "TeleportBlurEffect")
            hook.Remove("RenderScreenspaceEffects", "TeleportFailEffect")
            LocalPlayer():StopSound("weapons/physcannon/energy_sing_loop4.wav")
            chat.AddText(Color(100, 100, 255), "Teleport Dash deactivated!")
        end
    }
    
    -- Add more abilities here as needed    
}
