-- lua/abilitywheel/cl_abilitywheel_utils.lua
-- Utility functions for the ability wheel

-- Function to get key bound to a command
function AbilityWheel:GetBoundKey(command)
    -- Check if we've already cached this binding
    if self.KeyBinds[command] then
        return self.KeyBinds[command]
    end
    
    -- Special handling for mouse wheel and mouse buttons
    local specialBindings = {
        ["MOUSE1"] = "Mouse 1",
        ["MOUSE2"] = "Mouse 2",
        ["MOUSE3"] = "Mouse 3",
        ["MOUSE4"] = "Mouse 4",
        ["MOUSE5"] = "Mouse 5",
        ["MWHEELUP"] = "Wheel Up",
        ["MWHEELDOWN"] = "Wheel Down"
    }
    
    -- First check if any special bindings are bound to this command
    for bind, name in pairs(specialBindings) do
        if input.GetKeyCode(bind) and input.LookupBinding(bind) == command then
            self.KeyBinds[command] = name
            return name
        end
    end
    
    -- Direct check for mouse wheel bindings
    if input.LookupBinding("mwheelup") == command then
        self.KeyBinds[command] = "Wheel Up"
        return "Wheel Up"
    elseif input.LookupBinding("mwheeldown") == command then
        self.KeyBinds[command] = "Wheel Down"
        return "Wheel Down"
    end
    
    -- Check all bindings directly
    local allBindings = {}
    for i = 1, KEY_COUNT do
        local keyName = input.GetKeyName(i)
        if keyName and keyName ~= "UNBOUND" then
            local binding = input.LookupBinding(keyName)
            if binding then
                allBindings[binding] = keyName
            end
        end
    end
    
    -- Check if our command is in the bindings
    if allBindings[command] then
        self.KeyBinds[command] = allBindings[command]
        return allBindings[command]
    end
    
    -- Check for partial matches (for +commands)
    for binding, keyName in pairs(allBindings) do
        if string.find(binding, command) then
            self.KeyBinds[command] = keyName
            return keyName
        end
    end
    
    -- Manual check for common mouse bindings
    for i = 0, 5 do
        local mouseBinding = input.LookupBinding("mouse" .. i)
        if mouseBinding and string.find(mouseBinding, command) then
            local mouseName = "Mouse " .. i
            self.KeyBinds[command] = mouseName
            return mouseName
        end
    end
    
    -- If no binding found, use default values based on command
    if command == "+abilitywheel" then
        return "TAB"
    elseif command == "+nextability" then
        return "Mouse 4"
    elseif command == "+prevability" then
        return "Mouse 5"
    end
    
    -- Last resort fallback
    return "UNBOUND"
end

-- Helper function to check if entity is valid target (player or NPC)
function AbilityWheel:IsValidTarget(ent)
    if not IsValid(ent) then return false end
    
    -- Check if entity is a player
    if ent:IsPlayer() and ent ~= LocalPlayer() and ent:Alive() then
        return true
    end
    
    -- Check if entity is an NPC
    if ent:IsNPC() then
        return true
    end
    
    return false
end

-- Helper function to get bone position or estimate head position
function AbilityWheel:GetHeadPosition(ent)
    if ent:IsPlayer() then
        local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
        if headBone then
            return ent:GetBonePosition(headBone)
        else
            return ent:GetPos() + Vector(0, 0, 70)
        end
    elseif ent:IsNPC() then
        local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
        if headBone then
            return ent:GetBonePosition(headBone)
        else
            -- Estimate head position based on NPC model
            local mins, maxs = ent:GetModelBounds()
            if mins and maxs then
                return ent:GetPos() + Vector(0, 0, maxs.z * 0.9)
            else
                return ent:GetPos() + Vector(0, 0, 50)
            end
        end
    end
    
    return ent:GetPos()
end
