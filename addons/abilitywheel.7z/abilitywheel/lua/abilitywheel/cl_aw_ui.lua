-- lua/abilitywheel/cl_aw_ui.lua
-- UI functions for the ability wheel

-- Create fonts with different sizes for resolution scaling
local function CreateScaledFonts()
    local baseHeight = 1080 -- Base resolution height
    local currentHeight = ScrH()
    AbilityWheel.ScaleFactor = math.max(0.75, currentHeight / baseHeight)
    
    surface.CreateFont("AbilityWheel_Title", {
        font = "Roboto",
        size = math.Round(24 * AbilityWheel.ScaleFactor),
        weight = 600,
        antialias = true,
        shadow = true
    })
    
    surface.CreateFont("AbilityWheel_Normal", {
        font = "Roboto",
        size = math.Round(18 * AbilityWheel.ScaleFactor),
        weight = 500,
        antialias = true
    })
    
    surface.CreateFont("AbilityWheel_Small", {
        font = "Roboto",
        size = math.Round(14 * AbilityWheel.ScaleFactor),
        weight = 400,
        antialias = true
    })
    
    surface.CreateFont("AbilityWheel_Tiny", {
        font = "Roboto",
        size = math.Round(12 * AbilityWheel.ScaleFactor),
        weight = 400,
        antialias = true
    })
    
    -- Calculate scaled hex radius
    AbilityWheel.HexRadius = math.Round(40 * AbilityWheel.ScaleFactor)
end

-- Create fonts on initial load
CreateScaledFonts()

-- Recreate fonts when resolution changes
hook.Add("OnScreenSizeChanged", "AbilityWheel_ResolutionChange", function()
    CreateScaledFonts()
end)

-- Function to calculate hexagon points
function AbilityWheel:CalculateHexPoints(x, y, radius, rotation)
    rotation = rotation or 0
    local points = {}
    for i = 0, 5 do
        local angle = math.rad(i * 60 + rotation)
        table.insert(points, {
            x = x + radius * math.cos(angle),
            y = y + radius * math.sin(angle)
        })
    end
    return points
end

-- Function to draw a filled hexagon with smooth edges
function AbilityWheel:DrawFilledHexagon(x, y, radius, color, rotation, outlineColor, outlineWidth)
    rotation = rotation or 0
    outlineWidth = outlineWidth or 1
    outlineColor = outlineColor or Color(color.r * 0.7, color.g * 0.7, color.b * 0.7, color.a)
    
    local points = self:CalculateHexPoints(x, y, radius, rotation)
    
    -- Convert points to a table format for surface.DrawPoly
    local polyPoints = {}
    for _, point in ipairs(points) do
        table.insert(polyPoints, {x = point.x, y = point.y})
    end
    
    -- Draw filled hexagon
    surface.SetDrawColor(color)
    draw.NoTexture()
    surface.DrawPoly(polyPoints)
    
    -- Draw outline with smooth edges
    if outlineWidth > 0 then
        for i = 1, #points do
            local p1 = points[i]
            local p2 = points[i % #points + 1]
            
            -- Draw thicker line for outline
            for w = 0, outlineWidth - 1 do
                local offset = w - outlineWidth/2
                local angle = math.atan2(p2.y - p1.y, p2.x - p1.x) + math.pi/2
                local ox1 = p1.x + offset * math.cos(angle)
                local oy1 = p1.y + offset * math.sin(angle)
                local ox2 = p2.x + offset * math.cos(angle)
                local oy2 = p2.y + offset * math.sin(angle)
                
                surface.SetDrawColor(outlineColor)
                surface.DrawLine(ox1, oy1, ox2, oy2)
            end
        end
    end
end

-- Function to draw a smooth arc with rounded edges (hollow version)
function AbilityWheel:DrawSmoothArc(x, y, radius, startAngle, endAngle, color, thickness, segments)
    segments = segments or math.max(30, math.floor((endAngle - startAngle) / 3))
    thickness = thickness * self.ScaleFactor -- Scale thickness with resolution
    
    -- Draw the arc using line segments for a hollow appearance
    local angleStep = (endAngle - startAngle) / segments
    
    surface.SetDrawColor(color)
    
    -- Draw main arc with multiple lines for thickness
    for t = 0, thickness - 1 do
        local offset = t - thickness/2
        local currentRadius = radius + offset
        
        for i = 0, segments - 1 do
            local angle1 = math.rad(startAngle + i * angleStep)
            local angle2 = math.rad(startAngle + (i + 1) * angleStep)
            
            local x1 = x + currentRadius * math.cos(angle1)
            local y1 = y + currentRadius * math.sin(angle1)
            local x2 = x + currentRadius * math.cos(angle2)
            local y2 = y + currentRadius * math.sin(angle2)
            
            surface.DrawLine(x1, y1, x2, y2)
        end
    end
    
    -- Draw rounded caps if the arc doesn't complete a full circle
    if math.abs(endAngle - startAngle) < 359 then
        -- Start cap
        local startRad = math.rad(startAngle)
        local startX = x + radius * math.cos(startRad)
        local startY = y + radius * math.sin(startRad)
        
        -- End cap
        local endRad = math.rad(endAngle)
        local endX = x + radius * math.cos(endRad)
        local endY = y + radius * math.sin(endRad)
        
        -- Draw rounded caps
        draw.NoTexture()
        surface.SetDrawColor(color)
        surface.DrawCircle(startX, startY, thickness/2, color.r, color.g, color.b, color.a)
        surface.DrawCircle(endX, endY, thickness/2, color.r, color.g, color.b, color.a)
    end
    
    -- Optional: Add a highlight for 3D effect
    if thickness > 3 then
        local highlightColor = Color(255, 255, 255, 30)
        local highlightRadius = radius - thickness/4
        local highlightThickness = 1
        
        for i = 0, segments - 1 do
            local angle1 = math.rad(startAngle + i * angleStep)
            local angle2 = math.rad(startAngle + (i + 1) * angleStep)
            
            local x1 = x + highlightRadius * math.cos(angle1)
            local y1 = y + highlightRadius * math.sin(angle1)
            local x2 = x + highlightRadius * math.cos(angle2)
            local y2 = y + highlightRadius * math.sin(angle2)
            
            surface.SetDrawColor(highlightColor)
            surface.DrawLine(x1, y1, x2, y2)
        end
    end
end

-- Function to draw a glowing effect
function AbilityWheel:DrawGlow(x, y, radius, color, intensity)
    intensity = intensity or 1
    local glowColor = Color(color.r, color.g, color.b, math.min(150, color.a) * intensity)
    
    -- Draw multiple circles with decreasing alpha for glow effect
    for i = 1, 5 do
        local glowRadius = radius * (1 + i * 0.15)
        local alpha = glowColor.a * (1 - (i / 5))
        surface.SetDrawColor(glowColor.r, glowColor.g, glowColor.b, alpha)
        surface.DrawCircle(x, y, glowRadius, glowColor.r, glowColor.g, glowColor.b, alpha)
    end
end

-- Custom background blur implementation
function AbilityWheel:DrawBackgroundBlur(x, y, w, h, alpha)
    alpha = alpha or 0.5
    
    -- Draw a semi-transparent black background instead of blur
    surface.SetDrawColor(0, 0, 0, 200 * alpha)
    surface.DrawRect(x, y, w, h)
    
    -- Optional: Add a subtle gradient effect for depth
    for i = 0, h, 2 do
        local gradientAlpha = 5 * (1 - i/h) * alpha
        surface.SetDrawColor(255, 255, 255, gradientAlpha)
        surface.DrawLine(x, y + i, x + w, y + i)
    end
end

-- Function to draw the ability wheel with modern visuals
function AbilityWheel:Draw()
    -- Scale all dimensions based on resolution
    local scale = self.ScaleFactor
    
    if not self.IsOpen then
        -- When closed, just show the active ability if there is one
        if self.ActiveAbility and CurTime() < self.ActiveUntil then
            local timeLeft = math.max(0, self.ActiveUntil - CurTime())
            
            -- Draw active ability hexagon in bottom right
            local x = ScrW() - math.Round(100 * scale)
            local y = ScrH() - math.Round(100 * scale)
            local hexRadius = math.Round(45 * scale)
            
            -- Draw glow effect for active ability
            local glowColor = Color(100, 255, 100, 80)
            self:DrawGlow(x, y, hexRadius * 1.2, glowColor, timeLeft / self.ActiveAbility.duration)
            
            -- Draw hexagon background with shadow
            self:DrawFilledHexagon(x + 2, y + 2, hexRadius * 1.2, Color(20, 20, 20, 200), 0)
            self:DrawFilledHexagon(x, y, hexRadius * 1.2, Color(30, 30, 30, 220), 0, Color(60, 60, 60, 180), 2)
            
            -- Draw ability hexagon with highlight
            local abilityColor = Color(80, 220, 80, 220)
            self:DrawFilledHexagon(x, y, hexRadius, abilityColor, 0, Color(120, 255, 120, 180), 2)
            
            -- Draw ability name and time with shadow for better readability
            draw.SimpleText(self.ActiveAbility.name, "AbilityWheel_Normal", x, y - math.Round(10 * scale), 
                            Color(0, 0, 0, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(self.ActiveAbility.name, "AbilityWheel_Normal", x, y - math.Round(12 * scale), 
                            Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            draw.SimpleText(string.format("%.1fs", timeLeft), "AbilityWheel_Small", x, y + math.Round(12 * scale), 
                            Color(0, 0, 0, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(string.format("%.1fs", timeLeft), "AbilityWheel_Small", x, y + math.Round(10 * scale), 
                            Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            -- Draw active ability progress arc with rounded edges
            local activePercentage = timeLeft / self.ActiveAbility.duration
            local arcRadius = hexRadius * 1.5
            local startAngle = 0
            local endAngle = 360 * activePercentage
            
            self:DrawSmoothArc(x, y, arcRadius, startAngle, endAngle, Color(100, 255, 100, 180), 4)
        end
        return
    end
    
    -- Calculate cooldown percentage
    local cooldownRemaining = math.max(0, self.LastUsedTime + self.CooldownTime - CurTime())
    local cooldownPercentage = math.Clamp(cooldownRemaining / self.CooldownTime, 0, 1)
    
    -- Calculate active ability percentage if one is active
    local activePercentage = 0
    if self.ActiveAbility and CurTime() < self.ActiveUntil then
        local timeLeft = math.max(0, self.ActiveUntil - CurTime())
        activePercentage = timeLeft / self.ActiveAbility.duration
    end
    
    -- Get total number of abilities
    local totalAbilities = #self.Abilities
    if totalAbilities == 0 then return end
    
    -- Determine which abilities to show (all of them in a circle)
    local angleStep = 360 / totalAbilities
    local startAngle = 180 -- Start from left
    
    -- Draw background panel with blur and shadow
    local panelWidth = math.Round(400 * scale)
    local panelHeight = math.Round(300 * scale)
    -- Position in center of screen
    local centerX = ScrW() / 2 + panelWidth / 2
    local centerY = ScrH() / 2 

    local panelX = centerX - panelWidth
    local panelY = centerY - panelHeight / 2
    
    -- Draw blur under the panel
    self:DrawBackgroundBlur(panelX, panelY, panelWidth, panelHeight, 0.5)
    
    -- Draw panel background with rounded corners
    draw.RoundedBox(math.Round(10 * scale), panelX, panelY, panelWidth, panelHeight, Color(20, 20, 20, 200))
    draw.RoundedBox(math.Round(8 * scale), panelX + 2, panelY + 2, panelWidth - 4, panelHeight - 4, Color(40, 40, 40, 220))
    
    -- Draw title
    draw.SimpleText("Ability Wheel", "AbilityWheel_Title", panelX + math.Round(20 * scale), panelY + math.Round(15 * scale), 
                    Color(220, 220, 220, 255), TEXT_ALIGN_LEFT)
    
    -- Draw separator line
    surface.SetDrawColor(80, 80, 80, 180)
    surface.DrawLine(panelX + math.Round(20 * scale), panelY + math.Round(40 * scale), 
                    panelX + panelWidth - math.Round(20 * scale), panelY + math.Round(40 * scale))
    
    -- Arc settings for the wheel
    local arcRadius = math.Round(120 * scale)
    local wheelCenterX = centerX - math.Round(200 * scale)
    local wheelCenterY = centerY
    
    -- Draw outer arc background (full circle)
    self:DrawSmoothArc(wheelCenterX, wheelCenterY, arcRadius, 0, 360, Color(60, 60, 60, 100), 10)
    
    -- Draw cooldown progress on the outer arc if on cooldown
    if cooldownPercentage > 0 then
        self:DrawSmoothArc(wheelCenterX, wheelCenterY, arcRadius, 0, 360 * (1 - cooldownPercentage), Color(255, 100, 100, 180), 10)
    end
    
    -- Draw active ability progress on the inner arc if active
    if activePercentage > 0 then
        local innerArcRadius = arcRadius - math.Round(15 * scale)
        self:DrawSmoothArc(wheelCenterX, wheelCenterY, innerArcRadius, 0, 360 * activePercentage, Color(100, 255, 100, 180), 6)
    end
    
    -- Draw all abilities in a circle
    for i = 1, totalAbilities do
        local ability = self.Abilities[i]
        local isSelected = (i == self.CurrentIndex)
        local isOnCooldown = (cooldownPercentage > 0)
        
        -- Calculate position on circle
        local angle = math.rad(startAngle + (i - 1) * angleStep)
        local distance = isSelected and arcRadius * 0.7 or arcRadius * 0.8
        local x = wheelCenterX + distance * math.cos(angle)
        local y = wheelCenterY + distance * math.sin(angle)
        
        -- Scale hexagons based on selection and resolution
        local hexRadius = isSelected and math.Round(50 * scale) or math.Round(35 * scale)
        
        -- Determine color based on state
        local color, outlineColor
        if isOnCooldown then
            color = Color(100, 100, 100, 200) -- Grayed out during cooldown
            outlineColor = Color(130, 130, 130, 180)
        elseif isSelected then
            color = Color(80, 180, 255, 220) -- Highlighted for selected
            outlineColor = Color(120, 220, 255, 180)
            
            -- Draw glow effect for selected ability
            self:DrawGlow(x, y, hexRadius * 1.2, Color(80, 180, 255, 80))
        else
            color = Color(60, 60, 60, 180) -- Dark for others
            outlineColor = Color(100, 100, 100, 150)
        end
        
        -- Draw shadow for 3D effect
        if isSelected then
            self:DrawFilledHexagon(x + 2, y + 2, hexRadius, Color(0, 0, 0, 100), 0)
        end
        
        -- Draw the filled hexagon with outline
        self:DrawFilledHexagon(x, y, hexRadius, color, 0, outlineColor, math.Round(2 * scale))
        
        -- Draw ability name inside with shadow for better readability
        local textColor = isSelected and Color(255, 255, 255, 255) or Color(200, 200, 200, 200)
        local font = isSelected and "AbilityWheel_Normal" or "AbilityWheel_Small"
        
        -- Shorten name if needed
        local displayName = ability.name
        if #displayName > 10 and not isSelected then
            displayName = string.sub(displayName, 1, 9) .. "."
        end
        
        -- Draw text with shadow
        draw.SimpleText(displayName, font, x, y - math.Round(2 * scale), 
                        Color(0, 0, 0, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(displayName, font, x, y - math.Round(4 * scale), 
                        textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Draw duration for selected ability
        if isSelected then
            draw.SimpleText(ability.duration .. "s", "AbilityWheel_Small", x, y + math.Round(15 * scale), 
                            Color(0, 0, 0, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(ability.duration .. "s", "AbilityWheel_Small", x, y + math.Round(13 * scale), 
                            textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    
    -- Draw cooldown and active ability info
    local infoX = panelX + panelWidth - math.Round(20 * scale)
    local infoY = panelY + panelHeight - math.Round(60 * scale)
    
    -- Draw cooldown text if on cooldown
    if cooldownPercentage > 0 then
        draw.SimpleText("Cooldown: " .. string.format("%.1fs", cooldownRemaining), "AbilityWheel_Small", 
                       infoX, infoY, Color(255, 100, 100, 200), TEXT_ALIGN_RIGHT)
    end
    
    -- Draw active ability text if active
    if activePercentage > 0 then
        local timeLeft = math.max(0, self.ActiveUntil - CurTime())
        draw.SimpleText("Active: " .. string.format("%.1fs", timeLeft), "AbilityWheel_Small", 
                       infoX, infoY + (cooldownPercentage > 0 and math.Round(20 * scale) or 0), 
                       Color(100, 255, 100, 200), TEXT_ALIGN_RIGHT)
    end
end
