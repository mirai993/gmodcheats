-- lua/abilitywheel/cl_abilitywheel_hooks.lua
-- Hooks and event handlers for the ability wheel

-- Hook to draw the wheel and active abilities
hook.Add("HUDPaint", "AbilityWheelDraw", function()
    AbilityWheel:Draw()
    
    -- Draw ESP/Wallhack if active
    if AbilityWheel.ActiveAbility and AbilityWheel.ActiveAbility.name == "Wallhack & ESP" and CurTime() < AbilityWheel.ActiveUntil then
        local scale = AbilityWheel.ScaleFactor
        
        -- Draw ESP for players
        for _, ent in ipairs(player.GetAll()) do
            if ent ~= LocalPlayer() and ent:Alive() then
                local pos = AbilityWheel:GetHeadPosition(ent)
                local screenPos = pos:ToScreen()
                
                if screenPos.visible then
                    local distance = math.floor(LocalPlayer():GetPos():Distance(ent:GetPos()) / 39.37)
                    local health = ent:Health()
                    local color = team.GetColor(ent:Team())
                    
                    -- Calculate box size based on distance and resolution
                    local boxWidth = math.Round(40 * scale)
                    local boxHeight = math.Round(60 * scale)
                    local boxThickness = math.max(1, math.Round(2 * scale))
                    
                    -- Draw fancy box with gradient
                    local boxColor = Color(color.r, color.g, color.b, 100)
                    local boxX, boxY = screenPos.x - boxWidth/2, screenPos.y - boxHeight/2
                    
                    -- Draw box outline with rounded corners
                    draw.RoundedBox(math.Round(4 * scale), boxX - boxThickness, boxY - boxThickness, 
                                   boxWidth + boxThickness*2, boxHeight + boxThickness*2, 
                                   Color(0, 0, 0, 120))
                    
                    -- Draw box with gradient
                    local gradientAlpha = 80
                    for i = 0, boxHeight, 2 do
                        local gradientColor = Color(
                            color.r, 
                            color.g, 
                            color.b, 
                            gradientAlpha * (1 - i/boxHeight)
                        )
                        surface.SetDrawColor(gradientColor)
                        surface.DrawLine(boxX, boxY + i, boxX + boxWidth, boxY + i)
                    end
                    
                    -- Draw box outline
                    surface.SetDrawColor(color.r, color.g, color.b, 180)
                    surface.DrawOutlinedRect(boxX, boxY, boxWidth, boxHeight, boxThickness)
                    
                    -- Draw health bar
                    local healthBarHeight = math.Round(4 * scale)
                    local healthBarWidth = boxWidth
                    local healthPercentage = math.Clamp(health / 100, 0, 1)
                    
                    -- Health bar background
                    draw.RoundedBox(0, boxX, boxY + boxHeight + math.Round(5 * scale), 
                                   healthBarWidth, healthBarHeight, Color(40, 40, 40, 180))
                    
                    -- Health bar fill
                    local healthColor = Color(
                        255 * (1 - healthPercentage),
                        255 * healthPercentage,
                        0,
                        220
                    )
                    draw.RoundedBox(0, boxX, boxY + boxHeight + math.Round(5 * scale), 
                                   healthBarWidth * healthPercentage, healthBarHeight, healthColor)
                    
                    -- Draw name with shadow for better readability
                    local nameY = boxY - math.Round(20 * scale)
                    draw.SimpleText(ent:Nick(), "AbilityWheel_Small", screenPos.x, nameY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText(ent:Nick(), "AbilityWheel_Small", screenPos.x, nameY, 
                                   color, TEXT_ALIGN_CENTER)
                    
                    -- Draw health and distance info with shadow
                    local infoY = boxY + boxHeight + math.Round(15 * scale)
                    draw.SimpleText("HP: " .. health, "AbilityWheel_Tiny", screenPos.x - math.Round(20 * scale), infoY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText("HP: " .. health, "AbilityWheel_Tiny", screenPos.x - math.Round(20 * scale), infoY, 
                                   Color(255, 50, 50), TEXT_ALIGN_CENTER)
                    
                    draw.SimpleText(distance .. "m", "AbilityWheel_Tiny", screenPos.x + math.Round(20 * scale), infoY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText(distance .. "m", "AbilityWheel_Tiny", screenPos.x + math.Round(20 * scale), infoY, 
                                   Color(220, 220, 220), TEXT_ALIGN_CENTER)
                    
                    -- Draw line to player with gradient effect
                    local lineStartX, lineStartY = ScrW()/2, ScrH() - math.Round(50 * scale)
                    local lineEndX, lineEndY = screenPos.x, screenPos.y
                    local lineLength = math.sqrt((lineEndX - lineStartX)^2 + (lineEndY - lineStartY)^2)
                    local lineSteps = math.max(10, math.floor(lineLength / 20))
                    
                    for i = 0, lineSteps do
                        local t = i / lineSteps
                        local x = lineStartX + (lineEndX - lineStartX) * t
                        local y = lineStartY + (lineEndY - lineStartY) * t
                        local nextX = lineStartX + (lineEndX - lineStartX) * ((i + 1) / lineSteps)
                        local nextY = lineStartY + (lineEndY - lineStartY) * ((i + 1) / lineSteps)
                        
                        local alpha = 50 * (1 - t)
                        surface.SetDrawColor(color.r, color.g, color.b, alpha)
                        surface.DrawLine(x, y, nextX, nextY)
                    end
                end
            end
        end
        
        -- Draw ESP for NPCs with similar modern style
        for _, ent in ipairs(ents.GetAll()) do
            if ent:IsNPC() then
                local pos = AbilityWheel:GetHeadPosition(ent)
                local screenPos = pos:ToScreen()
                
                if screenPos.visible then
                    local distance = math.floor(LocalPlayer():GetPos():Distance(ent:GetPos()) / 39.37)
                    local health = ent:Health()
                    local color = Color(255, 150, 0) -- Orange for NPCs
                    
                    -- Calculate box size based on distance and resolution
                    local boxWidth = math.Round(40 * scale)
                    local boxHeight = math.Round(60 * scale)
                    local boxThickness = math.max(1, math.Round(2 * scale))
                    
                    -- Draw fancy box with gradient
                    local boxColor = Color(color.r, color.g, color.b, 100)
                    local boxX, boxY = screenPos.x - boxWidth/2, screenPos.y - boxHeight/2
                    
                    -- Draw box outline with rounded corners
                    draw.RoundedBox(math.Round(4 * scale), boxX - boxThickness, boxY - boxThickness, 
                                   boxWidth + boxThickness*2, boxHeight + boxThickness*2, 
                                   Color(0, 0, 0, 120))
                    
                    -- Draw box with gradient
                    local gradientAlpha = 80
                    for i = 0, boxHeight, 2 do
                        local gradientColor = Color(
                            color.r, 
                            color.g, 
                            color.b, 
                            gradientAlpha * (1 - i/boxHeight)
                        )
                        surface.SetDrawColor(gradientColor)
                        surface.DrawLine(boxX, boxY + i, boxX + boxWidth, boxY + i)
                    end
                    
                    -- Draw box outline
                    surface.SetDrawColor(color.r, color.g, color.b, 180)
                    surface.DrawOutlinedRect(boxX, boxY, boxWidth, boxHeight, boxThickness)
                    
                    -- Draw health bar
                    local healthBarHeight = math.Round(4 * scale)
                    local healthBarWidth = boxWidth
                    local healthPercentage = math.Clamp(health / 1000, 0, 1) -- Assuming NPCs can have more health
                    
                    -- Health bar background
                    draw.RoundedBox(0, boxX, boxY + boxHeight + math.Round(5 * scale), 
                                   healthBarWidth, healthBarHeight, Color(40, 40, 40, 180))
                    
                    -- Health bar fill
                    local healthColor = Color(
                        255 * (1 - healthPercentage),
                        255 * healthPercentage,
                        0,
                        220
                    )
                    draw.RoundedBox(0, boxX, boxY + boxHeight + math.Round(5 * scale), 
                                   healthBarWidth * healthPercentage, healthBarHeight, healthColor)
                    
                    -- Draw name with shadow for better readability
                    local nameY = boxY - math.Round(20 * scale)
                    draw.SimpleText(ent:GetClass(), "AbilityWheel_Small", screenPos.x, nameY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText(ent:GetClass(), "AbilityWheel_Small", screenPos.x, nameY, 
                                   color, TEXT_ALIGN_CENTER)
                    
                    -- Draw health and distance info with shadow
                    local infoY = boxY + boxHeight + math.Round(15 * scale)
                    draw.SimpleText("HP: " .. health, "AbilityWheel_Tiny", screenPos.x - math.Round(20 * scale), infoY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText("HP: " .. health, "AbilityWheel_Tiny", screenPos.x - math.Round(20 * scale), infoY, 
                                   Color(255, 50, 50), TEXT_ALIGN_CENTER)
                    
                    draw.SimpleText(distance .. "m", "AbilityWheel_Tiny", screenPos.x + math.Round(20 * scale), infoY + 1, 
                                   Color(0, 0, 0, 180), TEXT_ALIGN_CENTER)
                    draw.SimpleText(distance .. "m", "AbilityWheel_Tiny", screenPos.x + math.Round(20 * scale), infoY, 
                                   Color(220, 220, 220), TEXT_ALIGN_CENTER)
                    
                    -- Draw line to NPC with gradient effect
                    local lineStartX, lineStartY = ScrW()/2, ScrH() - math.Round(50 * scale)
                    local lineEndX, lineEndY = screenPos.x, screenPos.y
                    local lineLength = math.sqrt((lineEndX - lineStartX)^2 + (lineEndY - lineStartY)^2)
                    local lineSteps = math.max(10, math.floor(lineLength / 20))
                    
                    for i = 0, lineSteps do
                        local t = i / lineSteps
                        local x = lineStartX + (lineEndX - lineStartX) * t
                        local y = lineStartY + (lineEndY - lineStartY) * t
                        local nextX = lineStartX + (lineEndX - lineStartX) * ((i + 1) / lineSteps)
                        local nextY = lineStartY + (lineEndY - lineStartY) * ((i + 1) / lineSteps)
                        
                        local alpha = 50 * (1 - t)
                        surface.SetDrawColor(color.r, color.g, color.b, alpha)
                        surface.DrawLine(x, y, nextX, nextY)
                    end
                end
            end
        end
    end
end)
