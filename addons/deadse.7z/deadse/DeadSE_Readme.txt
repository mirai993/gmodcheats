DeadSE: By Hyperion/hyp3.us

Installation:
	Place autoexec.cfg in your garrysmod/garrysmod/cfg directory.
	Place gmcl_Dead_win32.dll in your garrysmod/garrysmod/lua/bin directory. If it doesn't exist, Create it.
	
In Game:
	Start a singleplayer game and type the following into the console (~):
		"sv_allowcslua 1"
		"lua_run_cl require("Dead")"
	Join a game and hold E for speedhack.
	To load scripts do the following:
		"lua_openscript_cl <yourluascript.lua>"
Enjoy ~ hyp3.us
