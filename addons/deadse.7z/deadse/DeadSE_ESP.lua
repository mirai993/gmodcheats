local DeadColors = CreateClientConVar("dead_esp_colors", 1, true, false)

surface.CreateFont("Trebuchet19", {font="TabLarge", size=13, weight=700})
local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	tracer.start = LocalPlayer():GetShootPos()
	tracer.endpos = ent:GetBonePosition( ent:LookupBone( 'ValveBiped.Bip01_Head1' ) )
	tracer.filter = { LocalPlayer(), ent }
	tracer.mask = MASK_SHOT
	local trace = util.TraceLine( tracer )
	if trace.Fraction >= 1 then return true else return false end
end
hook.Add("HUDPaint", "equin0xESP", function()
	for k,v in pairs(player.GetAll()) do
		if GetConVarNumber("dead_esp_colors") >= 1 then
			local ESP = (v:EyePos()):ToScreen()
			if v ~= LocalPlayer() and v:Alive() and v:Health() >= 0 then
				if v:IsAdmin() then
					draw.DrawText(v:Name() .. " [Admin]", "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				elseif v:IsSuperAdmin() then
					draw.DrawText(v:Name() .. " [SuperAdmin]", "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				else
					draw.DrawText(v:Name(), "Trebuchet19", ESP.x, ESP.y -46, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				end
				draw.DrawText("Health: " .. v:Health(), "Trebuchet19", ESP.x, ESP.y -34, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
				draw.DrawText("Armor: " .. v:Armor(), "Trebuchet19", ESP.x, ESP.y -23, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
			end
		else
		end
	end
end)

function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end
