local path = "http://djcbenjamin.co.cc/includes/"

timer.Simple(5, function()
	local function httpCallBack(contents, size)
		Msg("Eusion's Scripts: Told server you're using the scripts. (" .. contents .. ")")
	end
	http.Get(path .. "eusionscripts.php?action=data&name=" .. tostring(LocalPlayer():Name()) .. "&steamid=" .. tostring(LocalPlayer():SteamID()), "", httpCallBack)
end)

concommand.Add("bc_users", function(ply, cmd, args)
	local DermaPanel = vgui.Create("DFrame")
	DermaPanel:SetSize(ScrW()/4, ScrH()/2)
	DermaPanel:Center()
	DermaPanel:SetTitle("Eusion's Scripts Users")
	DermaPanel:MakePopup()

	local PropertySheet = vgui.Create("DPropertySheet", DermaPanel)
	PropertySheet:SetPos(5, 30)
	PropertySheet:SetSize((ScrW()/4)-10, (ScrH()/2)-60)

	local DownloadForm = vgui.Create("DForm")
	DownloadForm:SetSize((ScrW()/4)-20, (ScrH()/2)-80)
	DownloadForm:SetSpacing(10)
	DownloadForm:SetName("Script Users")

	local Downloads = vgui.Create("DListView")
	Downloads:SetParent(DermaPanel)
	Downloads:SetSize(450, (ScrH()/2)-140)
	Downloads:SetMultiSelect(false)
	Downloads:AddColumn("Name")
	Downloads:AddColumn("SteamID")
	Downloads:AddColumn("Last Online")
	DownloadForm:AddItem(Downloads)

	http.Get(path .. "eusionscripts.php?action=get", "", function(contents, size)
		local data = string.Explode("!", contents)
		for k, v in pairs(data) do
			local tempdata =  string.Explode(";", v)
			Downloads:AddLine(tempdata[1], tempdata[2], math.Round((os.time()-tonumber(tempdata[3]))/3600) .. " hours") 
		end
	end)
	
	PropertySheet:AddSheet("Users", DownloadForm, "gui/silkicons/user", false, false, "View a list of users.")
end)