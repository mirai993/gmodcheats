--[[
Name: Bouncy.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local BouncyToggle = CreateClientConVar("bc_bouncy", 0, true, false)

concommand.Add("+bc_hop", function()
	hook.Add("Think", "BunnyHop", function()
		if not LocalPlayer():IsOnGround() then
			RunConsoleCommand("-jump")
		elseif LocalPlayer():IsOnGround() then
			RunConsoleCommand("+jump")
		end
	end)
end)

concommand.Add("-bc_hop", function()
	hook.Remove("Think", "BunnyHop")
	RunConsoleCommand("-jump")
end)

concommand.Add("+bc_teabag", function()
	hook.Add("Think", "TeaBag", function()
		if not LocalPlayer():Crouching() then
			RunConsoleCommand("+duck")
		elseif LocalPlayer():Crouching() then
			RunConsoleCommand("-duck")
		end
	end)
end)

concommand.Add("-bc_teabag", function()
	hook.Remove("Think", "TeaBag")
	RunConsoleCommand("-duck")
end)

--Gary The Snail requested this, and I quote "[BC-SA] Gary The Snail: 'inspired by a dirty dog'".
Ducked = false
hook.Add("Think", "AutoDetectTeaBag", function()
	if BouncyToggle:GetInt() == 1 then
		for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), 50)) do
			if v:GetClass() == "class C_HL2MPRagdoll" or v:GetClass() == "class C_ClientRagdoll" then
				if not LocalPlayer():Crouching() then
					RunConsoleCommand("+duck")
					Ducked = true
				elseif LocalPlayer():Crouching() then
					RunConsoleCommand("-duck")
					Ducked = false
				end
			else
				if Ducked then
					RunConsoleCommand("-duck")
				end
			end
		end
	end
end)