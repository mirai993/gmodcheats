local FOV = CreateClientConVar("bc_360fov", 0, true, false)
local x = 0 
local y = 0
hook.Add("CreateMove", "360FOV", function(ucmd)
	if FOV:GetInt() == 1 then
		if LocalPlayer():KeyDown(IN_USE) then return end
		x = x + (ucmd:GetMouseX() / (LocalPlayer():GetInfo("sensitivity") * 8))
		y = y + (ucmd:GetMouseY() / (LocalPlayer():GetInfo("sensitivity") * 8))
		ucmd:SetViewAngles(Angle(y,-x,0))
		return true
	end
end)