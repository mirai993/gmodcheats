--[[
Name: Speech.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local Data = {}
local String = ""

local function DoSpeech(title)
	for k, v in pairs(Data) do
		String = String .. ", " .. v
	end
	Speech(title .. String)
	Data = {}
	String = ""
end

concommand.Add("bc_speech_admins", function()
	local mod = ""
	for k, v in pairs(player.GetAll()) do
		if not ValidEntity(v) then return end
		if v:IsAdmin() and ASS_Initialized == nil and v:GetNetworkedString("UserGroup") == "" then
			table.insert(Data, v:Name() .. "(Admin)")
			mod = "Source"
		end
		local usergroup = string.lower(v:GetNetworkedString("UserGroup"))
		if usergroup ~= "user" and usergroup ~= "" and usergroup ~= "undefined" then
			table.insert(Data, v:Name() .. " (" .. v:GetNWString("usergroup") .. ")")
			mod = "ULX"
		end
		if ASS_Initialized ~= nil and LevelToString ~= nil and LevelToString(v:GetNWInt("ASS_isAdmin")) ~= "Guest" then
			table.insert(Data, v:Name() .. " (" .. LevelToString(v:GetNWInt("ASS_isAdmin")) .. ")")
			mod = "ASS"
		end
	end
	DoSpeech("(" .. mod .. ") Staff: ")
end)

concommand.Add("bc_speech_money", function()
	local Players = player.GetAll()
	local MF = 2
	if ValidEntity(Players[1]) and Players[1].DarkRPVars and Players[1].DarkRPVars.money then
		MF = 1
	else
		MF = 2
	end
	if MF == 1 then
		table.sort(Players, function(a, b) return a.DarkRPVars.money > b.DarkRPVars.money end)
	else
		table.sort(Players, function(a, b) return a:GetNWInt("money") > b:GetNWInt("money") end)
	end
	for k, v in pairs(Players) do
		if MF == 1 then
			table.insert(Data, v:Name() .. " has $" .. v.DarkRPVars.money)
		else
			table.insert(Data, v:Name() .. " has $" .. v:GetNWInt("money"))
		end
	end
	DoSpeech("DarkRP Money: ")
end)
ES_ChatCommand("money", function(args)
	local ply = PENT(args)
	if not ValidEntity(ply) then return end
	ESNotify(ply:Name() .. " has $" .. ply.DarkRPVars.money)
	Speech(ply:Name() .. " has $" .. ply.DarkRPVars.money)
end)

concommand.Add("bc_speech_printers", function()
	for k, v in pairs(ents.FindByClass("money_printer")) do
		table.insert(Data, v.dt.owning_ent:Name())
	end
	DoSpeech("Money Printer Owners: ")
end)