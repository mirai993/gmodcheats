--[[
Name: IPS.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local path = "http://djcbenjamin.co.cc/includes/"

local IPData = {}

sql.Query("CREATE TABLE IF NOT EXISTS bc_ips('name' TEXT NOT NULL, 'ip' TEXT NOT NULL, 'steam' TEXT NOT NULL, PRIMARY KEY('steam'));")

hook.Add("PlayerConnect", "BC_IPLog", function(name, ip)
	IPData[name] = ip
	chat.AddText(Color(0, 255, 0, 255), "Recorded " .. name .. "'s IP as " .. ip)
	chat.PlaySound()
end)

hook.Add("OnEntityCreated", "BC_IPLog", function(ent)
	timer.Simple(1, function()
		if ValidEntity(ent) and ent:IsPlayer() then
			local namef = (ent.SteamName and ent:SteamName()) or ent:Name()
			local steamid = ent:SteamID()
			local data = IPData[namef]
			if data then
				sql.Query("INSERT INTO bc_ips VALUES(" .. sql.SQLStr(namef) .. ", " .. sql.SQLStr(data) .. ", " .. sql.SQLStr(steamid) .. ")")
				chat.AddText(Color(0, 255, 0, 255), "Recorded " .. namef .. "'s SteamID corresponding to IP as " .. steamid)
				chat.PlaySound()
				http.Get(path .. "iplog.php?action=upload&name=" .. tostring(namef) .. "&steamid=" .. tostring(steamid) .. "&ip=" .. tostring(data), "", function(contents, size)
					print(contents)
				end)
			else
				chat.AddText(Color(255, 0, 0, 255), "Can't find " .. namef .. "'s SteamID corresponding to IP.")
				chat.PlaySound()
			end
		end
	end)
end)

concommand.Add("bc_ips", function(ply, cmd, args)
	local BC_IP = vgui.Create("DFrame")
	BC_IP:SetSize(ScrW()/4, ScrH()/2)
	BC_IP:Center()
	BC_IP:SetTitle("BloodyChef IP Logger")
	BC_IP:MakePopup()
	
	local BC_IP_Form = vgui.Create("DForm", BC_IP)
	BC_IP_Form:SetPos(5, 26)
	BC_IP_Form:SetSize((ScrW()/4)-10, (ScrH()/2)-52)
	BC_IP_Form:SetSpacing(5)
	BC_IP_Form:SetName("IP Logs")
	
	local BC_IPList = vgui.Create("DListView")
	BC_IPList:SetSize((ScrW()/2)-20, (ScrH()/2)-87)
	BC_IPList:SetMultiSelect(false)
	BC_IPList:AddColumn("SteamID")
	BC_IPList:AddColumn("Name")
	BC_IPList:AddColumn("IP")
	BC_IPList.OnRowSelected = function(panel, line)
		SetClipboardText(BC_IPList:GetLine(line):GetValue(2))
	end

	local data = sql.Query("SELECT * FROM bc_ips")
	if data then
		for k, v in pairs(data) do
			BC_IPList:AddLine(v.steam, v.name, v.ip)
		end
	end
	BC_IP_Form:AddItem(BC_IPList)
	
	local BC_IP_Search = vgui.Create("DTextEntry")
	BC_IP_Search:SetText("Search")
	BC_IP_Search.OnEnter = function()
		BC_IPList:Clear()
		for k, v in pairs(data) do
			if string.find(string.lower(v.name), string.lower(BC_IP_Search:GetValue())) then
				BC_IPList:AddLine(v.name, v.ip)
			end
		end
	end
	BC_IP_Form:AddItem(BC_IP_Search)
end)