local BCOR = CreateClientConVar("bc_or", 0, true, false)
--Because this may conflict majorly with some gamemodes, there is a global disable.

if BCOR:GetInt() == 1 then
	local BCORUM = CreateClientConVar("bc_or_um", 0, true, false)
	local Incoming = usermessage.IncomingMessage
	function usermessage.IncomingMessage(msgn, msg)
		if BCORUM:GetInt() == 1 then
			print("UMSG:", msgn, tostring(msg:ReadString()))
		end
		Incoming(msgn, msg)
	end

	local BCORCMD = CreateClientConVar("bc_or_cmd", 0, true, false)
	local RCC = RunConsoleCommand
	function RunConsoleCommand(a, ...)
		if BCORCMD:GetInt() == 1 then
			print("Command:", a, ...)
		end
		RunConsoleCommand(a, ...)
	end
end