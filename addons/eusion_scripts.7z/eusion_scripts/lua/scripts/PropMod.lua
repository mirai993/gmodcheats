local PropModOn = CreateClientConVar("bc_propmod", 0, true, false)

local function PropMod()
	hook.Add("HUDPaint", "PropMod", function()
		if PropModOn:GetInt() == 1 then
			local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()))
			if (tr.Entity:IsValid()) then
				local PropAng = tostring(tr.Entity:GetAngles())
				local PropPos = tostring(tr.Entity:GetPos())
				local PropMod = tostring(tr.Entity:GetModel())
				local PropEnt = tostring(tr.Entity:GetClass())
				local PropOwner = tostring(tr.Entity:GetNetworkedString("Owner"))
				draw.DrawText("Entity: " .. PropEnt .. "\nModel: " .. PropMod .. "\nAngles: " .. PropAng .. "\nWorld Position: " .. PropPos .. "\nOwner: " .. PropOwner, "DefaultSmall", ScrW() / 100, ScrH() / 8, Color(255,255,255,255),0)
			end
		end
	end)
end
PropMod()