--[[
Name: MapLight.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local FeetOn = false

concommand.Add("bc_light_feet", function()
	if not FeetOn then
		FeetOn = true
		hook.Add("HUDPaint", "BCLight", function()
			local dlight = DynamicLight(LocalPlayer():UserID())
			dlight.Pos = LocalPlayer():GetPos()
			dlight.r = 255
			dlight.g = 255
			dlight.b = 255
			dlight.Brightness = 5
			dlight.Size = 500
			dlight.Decay = 0 
			dlight.DieTime = CurTime() + 0.2
		end)
	elseif FeetOn then
		FeetOn = false
		hook.Remove("HUDPaint", "BCLight")
	end
end)