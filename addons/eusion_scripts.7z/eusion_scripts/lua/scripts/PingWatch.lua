local PingWatch = CreateClientConVar("bc_pingwatch", 0, true, false)

local Average = 0
local ComparisonBad = 1
local ComparisonGood = 1
hook.Add("Think", "PingWatch", function()
	if PingWatch:GetInt() == 1 then
		Average = 0
		for k, v in pairs(player.GetAll()) do
			if ValidEntity(v) then
				Average = Average + v:Ping()
			end
		end
		Average = LocalPlayer():Ping()/(Average/#player.GetAll())
		ComparisonGood = 1/Average
		ComparisonBad = 1/ComparisonGood
	end
end)

hook.Add("HUDPaint", "DrawPing", function()
 	if PingWatch:GetInt() == 1 then
		draw.WordBox(4, 0, ScrH()/2, "Ping: " .. LocalPlayer():Ping() .. " (~" .. string.format("%2.2f", Average) .. " x Average)", "DefaultSmall", Color(ComparisonBad*255, ComparisonGood*255, 0, 100), Color(255, 255, 255, 255))
	end
end)