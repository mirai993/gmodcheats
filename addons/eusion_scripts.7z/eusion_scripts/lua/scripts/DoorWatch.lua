local Entities = {}
local Warn = false
local DoorWatchRadius = CreateClientConVar("bc_dw_radius", 50, true, false)

concommand.Add("bc_dw_add", function()
	local Entity = LocalPlayer():GetEyeTrace().Entity
	table.insert(Entities, Entity)
	LocalPlayer():ChatPrint("Added " .. LocalPlayer():GetEyeTrace().Entity:GetClass())
end)

concommand.Add("bc_dw_print", function()
	PrintTable(Entities)
end)

concommand.Add("bc_dw_reset", function()
	Entities = {}
end)

hook.Add("Think", "DoorWatch", function()
	for k, v in pairs(Entities) do
		if ValidEntity(v) then
			for a, b in pairs(ents.FindInSphere(v:GetPos(), DoorWatchRadius:GetInt())) do
				if b:IsPlayer() and Warn == false then
					Warn = true
					hook.Add("HUDPaint", "DoorWatch", function()
						local Pos = v:GetPos():ToScreen()
						local PPos = b:GetPos():ToScreen()
						local QuadTable = {} 
						QuadTable.texture 	= surface.GetTextureID("BloodyChef/nuke")
						QuadTable.color		= Color( 255, 255, 255, 255 ) 
						QuadTable.x = Pos.x
						QuadTable.y = Pos.y
						QuadTable.w = 60
						QuadTable.h = 60
						draw.TexturedQuad( QuadTable )
						draw.DrawText("Intruder!", "ScoreboardText", PPos.x, PPos.y, Color(255,0,0,255),1)
					end)
					v:EmitSound("BloodyChef/nuke.wav", 400)
					LocalPlayer():ChatPrint(b:Name() .. " is intruding door id: " .. k)
					timer.Simple(11, function()
						Warn = false
						hook.Remove("HUDPaint", "DoorWatch")
					end)
				end
			end
		end
	end
end)