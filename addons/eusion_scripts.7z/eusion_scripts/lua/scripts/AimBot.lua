--[[
Name: AimBot.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local function GetBone(ent, bone)
	return ent:GetBonePosition(ent:LookupBone(bone))
end

local function AimBot(ply)
	local Target = nil
	hook.Add("Think", "Target", function()
		local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()))
		if ValidEntity(tr.Entity) and tr.Entity:IsPlayer() then
			Target = tr.Entity
		end
		
		if Target ~= nil then
			hook.Remove("Think", "Target")
			hook.Add("Think", "AimBot", function()
				LocalPlayer():SetEyeAngles((GetBone(Target, "ValveBiped.Bip01_Head1") - LocalPlayer():GetShootPos()):Angle())
			end)
			hook.Add("HUDPaint", "TargetInfo", function()
				local Col = team.GetColor(Target:Team())
				draw.RoundedBox(6, 0, ScrH() - 50, 170, 50, Color(Col.r, Col.g, Col.b, 127.5))
				draw.DrawText("Target: " .. Target:Name() .. "\nHealth: " .. Target:Health() .. "\nDist: " .. math.Round(tostring(Target:GetPos():Distance(LocalPlayer():GetShootPos()))) .. "", "DefaultSmall", 10, ScrH() - 40, Color(255,255,255,255),0)
			end)
		end
	end)
end
concommand.Add("+bc_aimbot", AimBot)

local function RemoveAimBot()
	hook.Remove("Think", "Target")
	hook.Remove("Think", "AimBot")
	hook.Remove("HUDPaint", "TargetInfo")
end
concommand.Add("-bc_aimbot", RemoveAimBot)