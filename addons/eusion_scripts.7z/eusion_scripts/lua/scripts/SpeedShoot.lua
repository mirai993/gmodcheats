--[[
Name: SpeedShot.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

function SpeedShoot()
	local Shoot = false
	hook.Add("Think", "SpeedShoot", function()
		if Shoot == false then
			RunConsoleCommand("+attack")
			Shoot = true
		elseif Shoot == true then
			RunConsoleCommand("-attack")
			Shoot = false
		end
	end)
end
concommand.Add("+bc_speedshoot", SpeedShoot)

function RemoveSpeedShoot()
	hook.Remove("Think", "SpeedShoot")
	RunConsoleCommand("-attack")
end
concommand.Add("-bc_speedshoot", RemoveSpeedShoot)