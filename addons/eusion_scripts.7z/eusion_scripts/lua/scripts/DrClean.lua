--[[
Name: DrClean.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local DrClean = CreateClientConVar("bc_drclean", 0, true, false)

timer.Create("DrClean", 60, 0, function()
	if DrClean:GetInt() == 1 then
		RunConsoleCommand("r_cleardecals")
		for k, v in pairs(ents.GetAll()) do
			if ValidEntity(v) then
				if v:GetClass() == "class C_ClientRagdoll" or v:GetClass() == "class C_PhysPropClientside" or v:GetClass() == "class C_HL2MPRagdoll" then
					v:Remove()
				end
			end
		end
	end
end)