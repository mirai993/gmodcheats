--[[
Name: InfoMenu.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

function InfoMenu()
	local DF = vgui.Create("DFrame")
	DF:SetPos( 25,25 )
	DF:SetSize( 500, 415 )
	DF:SetTitle("BloodyChef's DarkRP Player Information Menu")
	DF:SetVisible( true )
	DF:SetDraggable( true )
	DF:ShowCloseButton( true )
	DF:MakePopup()
	local DLV = vgui.Create("DListView")
	DLV:SetParent(DF)
	DLV:SetPos(25, 50)
	DLV:SetSize(450, 335)
	DLV:SetMultiSelect(false)
	DLV:AddColumn("Name") 
	DLV:AddColumn("Health")
	DLV:AddColumn("Admin")
	DLV:AddColumn("Money")
	DLV:AddColumn("Job")
	DLV:AddColumn("Salary")
	DLV:AddColumn("Hunger")
	for k,v in pairs(player.GetAll()) do
		DLV:AddLine(v:Nick(),v:Health(),v:IsAdmin(),("$" .. v:GetNetworkedInt("money")),v:GetNWString("job"),v:GetNWInt("salary"),math.Round(v:GetNWInt("energy")))
	end
end
concommand.Add("bc_infomenu", InfoMenu)
