--[[
Name: XRay.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--

local XRay = false
local XRayEntites = {}
local GetClass = GetClass
local SetColor = SetColor
local SetMaterial = SetMaterial
local Length = Length
local GetVelocity = GetVelocity
local IsVehicle = IsVehicle
local IsPlayer = IsPlayer

concommand.Add("bc_xray", function(ply, cmd, args)
	if not XRay then
		for k, v in pairs(ents.GetAll()) do
			if ValidEntity(v) then
				local r, g, b, a = v:GetColor()
				XRayEntites[v:EntIndex()] = {r, g, b, a, tostring(v:GetMaterial())}
			end	
		end
		XRay = true
	else
		XRay = false
		for k, v in pairs(XRayEntites) do
			local ent = Entity(k)
			if ValidEntity(ent) then
				ent:SetColor(v[1], v[2], v[3], v[4])
				ent:SetMaterial(v[5])
			end
		end
		XRayEntites = {}
	end
end)

local Alpha = 50
local Material = "BloodyChef/xray"
hook.Add("RenderScene", "XRay", function()
	if XRay then
		for k, v in pairs(ents.GetAll()) do
			if ValidEntity(v) then
				local velocity = v:GetVelocity():Length()
				local velocitycolour = 255
				if velocity > 0 then
					velocitycolour = math.Clamp(((velocity*0.01905)/25)*255, 0, 255)
				end
				if v:GetClass() == "prop_physics" then
					v:SetMaterial(Material)
					v:SetColor(velocitycolour, 0, 0, Alpha)
				elseif string.find(v:GetClass(), "door") then
					v:SetMaterial(Material)
					v:SetColor(0, 255, 0, Alpha)
				elseif v:IsPlayer() then
					v:SetMaterial(Material)
					v:SetColor(0, 0, 255, Alpha)
				elseif v:IsVehicle() then
					v:SetMaterial(Material)
					v:SetColor(255, 255, 0, Alpha)
				elseif string.find(v:GetClass(), "wire") then
					v:SetMaterial(Material)
					v:SetColor(255, 0, 255, Alpha)
				end
			end
		end
	end
end)