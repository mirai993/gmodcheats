--[[
Name: NoRecoil.lua
Product: BloodyChef Client Scripts
Author: Eusion
]]--
local NoRecoilToggle = CreateClientConVar("bc_norecoil", 1, true, false)

hook.Add("CalcView", "NoRecoil", function()
	if NoRecoilToggle:GetInt() == 1 then
		local Wep = LocalPlayer():GetActiveWeapon()
		
		if (Wep.Primary) then Wep.Primary.Recoil = 0.0 end
		if (Wep.Secondary) then Wep.Secondary.Recoil = 0.0 end
	end
end)