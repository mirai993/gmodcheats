require "glon"

local server = "http://djcbenjamin.co.cc/includes/"

concommand.Add("bc_dupeshare", function(ply, cmd, args)
	local DermaPanel = vgui.Create("DFrame")
	DermaPanel:SetSize(ScrW()/4, ScrH()/2)
	DermaPanel:Center()
	DermaPanel:SetTitle("Duplication Share")
	DermaPanel:MakePopup()

	UploadDataHTML = vgui.Create("HTML", DermaPanel)
	UploadDataHTML:SetPos(10, ScrH()/2-27)
	UploadDataHTML:SetSize(ScrW()/4-10, 47)
	UploadDataHTML:SetHTML("Downloading data...")

	local PropertySheet = vgui.Create("DPropertySheet", DermaPanel)
	PropertySheet:SetPos(5, 30)
	PropertySheet:SetSize((ScrW()/4)-10, (ScrH()/2)-60)

	local DownloadForm = vgui.Create("DForm")
	DownloadForm:SetSize((ScrW()/4)-20, (ScrH()/2)-80)
	DownloadForm:SetSpacing(10)
	DownloadForm:SetName("Download Duplications")

	local Downloads = vgui.Create("DListView")
	Downloads:SetParent(DermaPanel)
	Downloads:SetSize(450, (ScrH()/2)-140)
	Downloads:SetMultiSelect(false)
	Downloads:AddColumn("Description")
	Downloads:AddColumn("Author")
	Downloads:AddColumn("Uploaded")
	DownloadForm:AddItem(Downloads)

	http.Get(server .. "dupeshare.php?action=get", "", function(contents, size)
			UploadDataHTML:SetHTML("Data downloaded.")
			local data = string.Explode("!", contents)
			for k, v in pairs(data) do
				local tempdata =  string.Explode(";", v)
				Downloads:AddLine(tempdata[1], tempdata[2], math.Round((os.time()-tonumber(tempdata[3]))/86400) .. " days") 
			end
	end)

	Downloads.OnRowSelected = function(panel, line)
		local name = tostring(Downloads:GetLine(line):GetValue(1))
		UploadDataHTML:SetHTML("Downloading duplication...")
		http.Get(server .. "dupeshare.php?action=data&desc=" .. name, "", function(contents, size)
			contents = contents .. "" --Very strange that the script decides it doesn't want to add the trailing glon encoding when communicating with the webserver.
			UploadDataHTML:SetHTML("Decompressing data...")
			local data = glon.decode(contents)
			local datstring = ""
			local count = 0
			for k, v in pairs(data) do
				count = count + 1
				if count == 1 then
					datstring = datstring .. v
				else
					datstring = datstring .. "\n" .. v
				end
			end
			UploadDataHTML:SetHTML("Writing file...")
			file.Write("adv_duplicator/" .. name, (datstring))
			UploadDataHTML:SetHTML("Downloaded " .. name .. ".")
		end)
	end

	local UploadForm = vgui.Create("DForm")
	UploadForm:SetSize((ScrW()/4)-20, (ScrH()/2)-80)
	UploadForm:SetSpacing(10)
	UploadForm:SetName("Upload Duplications")

	local Uploads = vgui.Create("DListView")
	Uploads:SetParent(DermaPanel)
	Uploads:SetSize(450, (ScrH()/2)-140)
	Uploads:SetMultiSelect(false)
	Uploads:AddColumn("Duplication")
	UploadForm:AddItem(Uploads)

	for k, v in pairs(file.Find("data/adv_duplicator/*.txt", true)) do
		Uploads:AddLine(v)
	end

	local function Upload(desc, data)
		local compdat = string.Explode("\n", data)
		compdat = glon.encode(compdat)
		local name = LocalPlayer():Name()
		local steamid = LocalPlayer():SteamID()
		UploadDataHTML:OpenURL(server .. "dupeshare.php?action=upload&name=" .. name .. "&steamid=" .. steamid .. "&desc=" .. desc .. "&data=" .. compdat)
	end

	Uploads.OnRowSelected = function(panel, line)
		local name = tostring(Uploads:GetLine(line):GetValue(1))
		local dat = file.Read("data/adv_duplicator/" .. name, true)
		UploadDataHTML:SetHTML("Uploading " .. name .. "...")
		Upload(name, dat)
	end

	PropertySheet:AddSheet("Download", DownloadForm, "gui/silkicons/application_put", false, false, "Download files user's have shared.")
	PropertySheet:AddSheet("Upload", UploadForm, "gui/silkicons/world", false, false, "Upload files to share.")
end)