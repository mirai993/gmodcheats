if not CLIENT then return end -- These scripts are designed for individual clients only, there will be many compatability issues when using these on servers.

local function WelcomeDMenu()
	local DFra = vgui.Create("DFrame")
	DFra:SetPos(0, 0)
	DFra:SetSize(260, 90)
	DFra:SetTitle("Eusion's Scripts")
	DFra:SetVisible(true)
	DFra:SetDraggable(true)
	DFra:ShowCloseButton(true)
	DFra:MakePopup()

	local DImg = vgui.Create("DImageButton", DFra)
	DImg:SetPos(2, 20)
	DImg:SetSize(256,64)
	DImg:SetImage("BloodyChef/welcomedmenu")
end
concommand.Add("bc_welcome", WelcomeDMenu)

local function ReloadScripts()
	include("autorun/EusionScripts.lua")
	ESNotify("Reloaded all Eusion's Scripts.")
end
concommand.Add("bc_reload", ReloadScripts)

local OOC = CreateClientConVar("bc_ooc", 1, true, false)
local Say = {}
local time = 3
local max = 1
local index = 1
local function ActualSay(index)
	if max == index then max = 1 index = 1 Say = {} return end
	if OOC:GetInt() == 1 then
		LocalPlayer():ConCommand("say /ooc " .. Say[index])
	else
		LocalPlayer():ConCommand("say " .. Say[index])
	end
	index = index + 1
	timer.Simple(time, function() ActualSay(index) end)
end
function Speech(text)
	Say = string.split(text, 128)
	max = #Say
	timer.Simple(time, function() ActualSay(index) end)
end

function ESNotify(text)
	if GAMEMODE.IsSandboxDerived then
		GAMEMODE:AddNotify(tostring(text), 1, 4)
		surface.PlaySound("ambient/water/drip" .. math.random(1, 4) .. ".wav")
	else
		LocalPlayer():ChatPrint(text)
	end
	print(text)
end

function PENT(name)
	for k, v in pairs(player.GetAll()) do
		if ValidEntity(v) and string.find(string.lower(v:Name()), string.lower(name)) then
			return v
		end
	end
end

--[[hook.Add("Initialize", "ES_OR", function()
	local GVN = GetConVarNumber
	function GetConVarNumber(cmd)
		if cmd == "host_timescale" then
			return 1
		elseif cmd == "host_framerate" then
			return 0
		elseif cmd == "sv_cheats" then
			return 0
		elseif cmd == "sv_scriptenforcer" then
			return 1
		else
			GVN(cmd)
		end
	end
end)]]

local BC_Commands = {}
function ES_ChatCommand(cmd, func)
	BC_Commands[cmd] = func
end

hook.Add("OnPlayerChat", "BC_ChatCommands", function(ply, text, team, dead)
	if ply == LocalPlayer() then
		for command, func in pairs(BC_Commands) do
			if string.lower(string.sub(text, 0, string.len(command))) == string.lower(command) then
				local args = string.Explode(" ", string.sub(text, string.len(command)+2, string.len(text)))
				func(table.concat(args, ", ")) --Runs the command with extra parameters.
			end
		end
	end
end)

hook.Add("OnPlayerChat", "BC_Version", function(ply, text, team, dead)
	if ValidEntity(ply) and ply:SteamID() == "STEAM_0:0:20450406" then
		if text == "!euv" then
			local data = string.sub(file.Read("addons/eusionscripts/Change Log.txt", true), 10, 13)
			Speech("Eusion's Scripts Loaded (" .. data .. ")")
		end
	end
end)

for k, v in pairs(file.Find("addons/eusionscripts/lua/scripts/*.lua", true)) do
	include("scripts/" .. v)
	print("Eusion's scripts: Client file " .. v .. " has been loaded.")
end