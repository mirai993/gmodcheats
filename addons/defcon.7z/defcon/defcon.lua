local defcon = { Menu = { t = {}; b = {}; c = 0}; Alive = {};}
defcon.Normal			= {
	aimbot					= true;
	aimbot_fov				= 5;
	aimbot_friendly_fire	= true;
	triggerbot				= true;
	
	esp_player				= true;
	esp_player_dist			= 16000;
	esp_player_showdist		= true;
	esp_player_name			= true;
	esp_player_rank			= true;
	esp_player_health		= true;
	esp_player_armor		= true;
	esp_player_glow			= true;
	
	esp_entity				= true;
	esp_entity_dist			= 16000;
	
	flashlight_spam			= false;
	
	darkrp_money			= false;
	darkrp_god				= false;
	
	ttt_deathnotifs			= true;
	
}
defcon.Settings			= (file.Exists("d_settings.txt", "DATA") and util.JSONToTable(file.Read("d_settings.txt", "DATA"))) or defcon.Normal
defcon.Entities 		= (file.Exists("d_entities.txt", "DATA") and util.JSONToTable(file.Read("d_entities.txt", "DATA"))) or {}
defcon.Whitelist 		= (file.Exists("d_whitelist.txt", "DATA") and util.JSONToTable(file.Read("d_whitelist.txt", "DATA"))) or {}
defcon.AimKey			= (file.Exists("d_aimkey.txt", "DATA") and tonumber(file.Read("d_aimkey.txt", "DATA"))) or KEY_LALT
defcon.Phrases 			= {
	"Thanks for using this hack!";
	"Camper is the best.";
	"coded by team garry";
	"BVON U SUK DIK";
}
defcon.Keys = {
"KEY_0", "KEY_1", "KEY_2", "KEY_3", "KEY_4", "KEY_5",
"KEY_6", "KEY_7", "KEY_8", "KEY_9", "KEY_A", "KEY_B", "KEY_C",
"KEY_D", "KEY_E", "KEY_F", "KEY_G", "KEY_H", "KEY_I", "KEY_J",
"KEY_K", "KEY_L", "KEY_M", "KEY_N", "KEY_O", "KEY_P", "KEY_Q",
"KEY_R", "KEY_S", "KEY_T", "KEY_U", "KEY_V", "KEY_W", "KEY_X",
"KEY_Y", "KEY_Z", "KEY_PAD_0", "KEY_PAD_1", "KEY_PAD_2", "KEY_PAD_3",
"KEY_PAD_4", "KEY_PAD_5", "KEY_PAD_6", "KEY_PAD_7", "KEY_PAD_8", "KEY_PAD_9",
"KEY_PAD_DIVIDE", "KEY_PAD_MULTIPLY", "KEY_PAD_MINUS", "KEY_PAD_PLUS", "KEY_PAD_ENTER",
"KEY_PAD_DECIMAL", "KEY_LBRACKET", "KEY_RBRACKET", "KEY_SEMICOLON", "KEY_APOSTROPHE",
"KEY_BACKQUOTE", "KEY_COMMA", "KEY_PERIOD", "KEY_SLASH", "KEY_BACKSLASH", "KEY_MINUS",
"KEY_EQUAL", "KEY_ENTER", "KEY_SPACE", "KEY_BACKSPACE", "KEY_TAB", "KEY_CAPSLOCK",
"KEY_NUMLOCK", "KEY_ESCAPE", "KEY_SCROLLLOCK", "KEY_INSERT", "KEY_DELETE", "KEY_HOME",
"KEY_END", "KEY_PAGEUP", "KEY_PAGEDOWN", "KEY_BREAK", "KEY_LSHIFT", "KEY_RSHIFT",
"KEY_LALT", "KEY_RALT", "KEY_LCONTROL", "KEY_RCONTROL", "KEY_LWIN", "KEY_RWIN",
"KEY_APP", "KEY_UP", "KEY_LEFT", "KEY_DOWN", "KEY_RIGHT", "KEY_F1", "KEY_F2",
"KEY_F3", "KEY_F4", "KEY_F5", "KEY_F6", "KEY_F7", "KEY_F8", "KEY_F9",
"KEY_F10", "KEY_F11", "KEY_F12", "KEY_CAPSLOCKTOGGLE", "KEY_NUMLOCKTOGGLE",
"KEY_SCROLLLOCKTOGGLE"
};

for k,v in pairs(defcon.Normal) do
	if defcon.Settings[k] == nil then
		defcon.Settings = defcon.Normal
		-- so that if a new key is added to the normal config, the Settings will reset
	end
end

-- functions
function defcon.Update(x,y,z, ok)
	if x == "setting" then
		defcon.Settings[y] = z
		if ok == true then
			file.Write("d_settings.txt", util.TableToJSON(defcon.Settings))
		end
	elseif x == "entity" then
		file.Write("d_entities.txt", util.TableToJSON(defcon.Entities))
	elseif x == "friend" then
		file.Write("d_whitelist.txt", util.TableToJSON(defcon.Whitelist))
	end
end
function defcon.ESPCheck(typ, v)
	if typ == "player" then
		if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() /*&& /*LocalPlayer():Alive() &&*/ /*LocalPlayer():Team() ~= TEAM_SPECTATOR*/ then
			return true
		end
	elseif typ == "entity" then
		if IsValid(v) then
			return true
		end
	end
	return false
end
function defcon.ESPDistance(typ, v)
	if typ == "player" then
		if defcon.Settings["esp_player_dist"] >= 16000 then
			return true
		elseif v:GetPos():Distance(LocalPlayer():GetPos()) < (defcon.Settings["esp_player_dist"]) then
			return true
		end
	elseif typ == "entity" then
		if defcon.Settings["esp_entity_dist"] >= 16000 then
			return true
		elseif v:GetPos():Distance(LocalPlayer():GetPos()) < (defcon.Settings["esp_entity_dist"]) then
			return true
		end
	end
	return false
end
function defcon.GetShootPos(ent)
	local eyes = ent:LookupAttachment("eyes");
	if(eyes ~= 0) then
		eyes = ent:GetAttachment(eyes);
		if(eyes and eyes.Pos) then
			return eyes.Pos, eyes.Ang;
		end
	end
end
function defcon.Visible(ent)
	local pos = LocalPlayer():GetShootPos()
	local ang = LocalPlayer():GetAimVector()
	local trace = {start = LocalPlayer():GetShootPos(), endpos = defcon.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
	local tr = util.TraceLine(trace);
	return(tr.Fraction == 1);
end
function defcon.Whitelisted(ent)
	if defcon.Whitelist[ent:SteamID()] then return true
	else return false end
end
function defcon.CanTarget(v)
	if v:IsPlayer() then
		if (defcon.Visible(v) and (not defcon.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
			if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
				if not(defcon.Settings["aimbot_friendly_fire"]) then
					if (v:Team() ~= LocalPlayer():Team()) then
						return true
					end
				else
					return true
				end
			end
		end
	end
	return false
end
function defcon.Ents()
	local t = {}
	for k,v in pairs(ents.GetAll()) do
		if IsValid(v) and not(table.HasValue(t, v:GetClass())) then
			table.insert(t, v:GetClass())
		end
	end
	table.sort(t, function(a,b) return a < b end)
	
	return t
end
-- fonts
surface.CreateFont("deffont", {
	font	=	"impact",
	size	=	64
});
surface.CreateFont("deffontesp1", {
	font="TabLarge", 
	size=13, 
	weight=700
});
surface.CreateFont("deffontesp2", {
	font="TabLarge",
	size=10,
	weight=700
});
-- short vars
local menu				= defcon.Menu
local current			= defcon.Current
local alive				= defcon.Alive
local normal			= defcon.Normal
local settings			= defcon.Settings
local entities			= defcon.Entities
local whitelist			= defcon.Whitelist
local phrases			= defcon.Phrases
local espcheck			= defcon.ESPCheck
local espdistance		= defcon.ESPDistance
-- menu
local function AddTab(txt, tab, func)
	menu.c = menu.c + 1 -- increase the counter for the amount of tabs
	local panel
	if tab and tab == true then
		panel = vgui.Create("DPanel", menu.frame);
		panel:SetPos(120,25);
		panel:SetSize(376,406);
		if menu.Current == txt then
			panel:SetVisible(true)
		else
			panel:SetVisible(false)
		end
		panel.Paint = function()
			surface.SetDrawColor( 10, 10, 10, 255 )
			surface.DrawOutlinedRect( 0, 0, panel:GetWide() - 1, panel:GetTall() - 1)
			draw.SimpleText(string.upper(txt), "deffont", 10, 5, Color(210, 210, 210, 235), TEXT_ALIGN_LEFT);
		end
	end
	local button = vgui.Create("DButton", menu.buttons);
	button:SetText(txt);
	button:SetSize(80, 20);
	button:SetPos(15, -15+(25*menu.c));
	button:SetTextColor(color_white)
	button.Paint = function(self) 
		surface.SetDrawColor(100,100,100,220)
		surface.DrawRect(0, 0,self:GetSize())
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0,0,self:GetSize())
	end
	button.DoClick = func or (tab and tab == true and function()
		for k,v in pairs(menu.t) do
			if v ~= panel then
				v:SetVisible(false)
			end
		end
		panel:SetVisible(true)
		menu.Current = txt
		surface.PlaySound("ambient/levels/canals/drip4.wav");
	end)
	return panel, button;
end

local function AddFeature(id, parent, typ, name, setting, o1, o2)
	if not parent then return end
	if typ == "button" then
		local label = vgui.Create("DLabel", parent)
		label:SetText(name)
		label:SetPos(5,(55+(id*25)))
		label:SizeToContents(false)
		local button = vgui.Create("DButton", parent)
		if defcon.Settings[setting] == true then
			button:SetText("enabled")
		else
			button:SetText("disabled")
		end
		button:SetSize(80,20)
		if not id then
			button:SetPos(285,45)
		else
			button:SetPos(285,(55+(id*25)))
		end
		button.DoClick = function()
			if button:GetText() == "enabled" then
				button:SetText("disabled"); defcon.Update("setting", setting, false, true)
			else
				button:SetText("enabled"); defcon.Update("setting", setting, true, true)
			end
		end
		button:SetTextColor(color_white)
		button.Paint = function(self) 
			surface.SetDrawColor(100,100,100,220)
			surface.DrawRect(0, 0,self:GetSize())
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetSize())
		end
		return button,label
	elseif typ == "slider" then
		local slider = vgui.Create("DNumSlider", parent)
		slider:SetPos(5, (45+(id*25)))
		slider:SetText(name)
		slider:SetMinMax(o1, o2)
		slider:SetWide(372.5)
		slider:SetDecimals( 0 )
		slider:SetFGColor(255,255,255,255)
		slider:SetBGColor(255,255,255,255)
		slider:SetValue(defcon.Settings[setting])
		slider.OnValueChanged = function(panel, value)
			local c = tonumber(value)
			defcon.Update("setting", setting, math.Round(c), true)
		end
		return slider;
	end
end

local function AddButton(parent, text, posx, posy, func)
	local button = vgui.Create("DButton", parent)
	button:SetText(text)
	button:SetSize(80,20)
	button:SetPos(posx,posy)
	button:SetTextColor(color_white)
	button.DoClick = func or function() end
	button.Paint = function(self) 
		surface.SetDrawColor(100,100,100,220)
		surface.DrawRect(0, 0,self:GetSize())
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0,0,self:GetSize())
	end
	return button
end

local function DrawMenu()
	if(menu.frame) then menu.frame:Remove(); menu.frame = nil; end
	
	menu.c = 0
	
	menu.frame = vgui.Create("DFrame");
	menu.frame:SetPos(ScrW()/2-184, ScrH()/2-155);
	menu.frame:SetSize(500, 435);
	menu.frame:SetTitle("defcon @ catapult :: "..defcon.Phrases[math.random(1, table.Count(defcon.Phrases))]);
	menu.frame.Paint = function()
		surface.SetDrawColor(50,50,50,200)
		surface.DrawRect(0, 0,menu.frame:GetWide(),menu.frame:GetTall())
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0,0,menu.frame:GetWide(),menu.frame:GetTall())
	end
	menu.frame:SetVisible(true);
	menu.frame:SetDraggable(true);
	menu.frame:SetSizable(false);
	menu.frame:ShowCloseButton(false);
	menu.frame:SetBackgroundBlur(true)
	menu.frame:MakePopup();
	
	menu.close = vgui.Create("DButton", menu.frame)
	menu.close:SetFont('marlett')
	menu.close:SetText('r')
	menu.close:SetColor(Color(255, 255, 255))
	menu.close:SetSize(15, 15)
	menu.close:SetDrawBackground(false)
	menu.close:SetPos(menu.frame:GetWide() - 20, 5)
	menu.close.DoClick = function()
		menu.frame:Remove(); menu.frame = nil;
	end

	menu.buttons = vgui.Create("DPanel",menu.frame)
	menu.buttons:SetPos(5, 25)
	menu.buttons:SetSize(111,406)
	menu.buttons:SetVisible(true)
	menu.buttons.Paint = function()
		surface.SetDrawColor(10,10,10,255)
		surface.DrawOutlinedRect(0,0,110,405)
	end

	menu.t.def = vgui.Create("DPanel", menu.frame);
	menu.t.def:SetPos(120,25);
	menu.t.def:SetSize(376,406);
	if menu.Current ~= nil then menu.t.def:SetVisible(false) end
	menu.t.def.Paint = function()
		surface.SetDrawColor( 10, 10, 10, 255 )
		surface.DrawOutlinedRect( 0, 0, menu.t.def:GetWide() - 1, menu.t.def:GetTall() - 1)
	end
	
	menu.t.a, menu.b.a 		= AddTab("Aimbot",		true)
	menu.t.p, menu.b.p		= AddTab("Player ESP", 	true)
	menu.t.e, menu.b.e		= AddTab("Entity ESP", 	true)
	menu.t.m, menu.b.m		= AddTab("Misc.",		true)
	menu.t.g, menu.b.g		= AddTab("Game-mode", 	true)
	--id, parent  , the type, the text , setting
	AddFeature(1, menu.t.a, "button", "Enabled", "aimbot")
	AddFeature(2, menu.t.a, "button", "Triggerbot", "triggerbot")
	AddFeature(3, menu.t.a, "button", "Friendly Fire", "aimbot_friendly_fire")
	AddFeature(4, menu.t.a, "slider", "FOV", "aimbot_fov", 0, 180)
	
	AddFeature(1, menu.t.p, "button", "Enabled", "esp_player")
	AddFeature(2, menu.t.p, "button", "Show Name", "esp_player_name")
	AddFeature(3, menu.t.p, "button", "Show Rank", "esp_player_rank")
	AddFeature(4, menu.t.p, "button", "Show Health", "esp_player_health")
	AddFeature(5, menu.t.p, "button", "Show Armor", "esp_player_armor")
	AddFeature(6, menu.t.p, "button", "Show Distance", "esp_player_showdist")
	AddFeature(7, menu.t.p, "slider", "Draw Distance", "esp_player_dist", 0, 16000)
	AddFeature(8, menu.t.p, "button", "Draw Glow Halo", "esp_player_glow")
	
	AddFeature(1, menu.t.e, "button", "Enabled", "esp_entity")
	AddFeature(2, menu.t.e, "slider", "Draw Distance", "esp_entity_dist", 0, 16000)
	
	AddFeature(1, menu.t.m, "button", "Flashlight Spam [hold leftarrow]", "flashlight_spam")
	
	if string.find(gmod.GetGamemode().Name, "DarkRP") then
		AddFeature(1, menu.t.g, "button", "God-mode Exploit (Costs in-game $$$)", "darkrp_god")
	elseif string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") then
		AddFeature(1, menu.t.g, "button", "Display Death Notifications", "ttt_deathnotifs")
	end
	local elist
	local elist2
	local elistc
	local elistc2
	local function makeelist()
		elist = vgui.Create("DComboBox", menu.t.e)
		elist:SetPos(10,menu.t.e:GetTall()-43)
		elist:SetSize(130,20)
		for k,v in pairs(defcon.Ents()) do
			if not(defcon.Entities[v]) then
				local i = elist:AddChoice(v)
			end
		end	
		elist.OnSelect = function(index,value,data)
			print(data)
			elist2 = data
		end
	end
	local function makeelistc()
		elistc = vgui.Create("DComboBox", menu.t.e)
		elistc:SetPos(235, menu.t.e:GetTall()-43)
		elistc:SetSize(130,20)
		for k,v in pairs(defcon.Entities) do
			local i = elistc:AddChoice(v)
		end
		elistc.OnSelect = function(index,value,data)
			elistc2 = data
		end
	end
	makeelist()
	makeelistc()
	AddButton(menu.t.e, "Add Entity", 35, menu.t.e:GetTall()-23, function()
		if(elist2) then
			for k,v in pairs(defcon.Ents()) do
				if (v == elist2) then
					print(v)
					table.insert(defcon.Entities, v)
					defcon.Update("entity")
				end
			end
		end
		makeelist()
		makeelistc()
	end)
	AddButton(menu.t.e, "Remove Entity", 260, menu.t.e:GetTall()-23, function()
		if(elistc2) then
			for k,v in pairs(defcon.Entities) do
				if (v == elistc2) then
					defcon.Entities[k] = nil;
					defcon.Update("entity")
				end
			end
		end
		makeelist()
		makeelistc()
	end)
	/*local flist
	local flist2
	local flistc
	local flistc2
	local function makeflist()
		flist = vgui.Create("DComboBox", menu.t.a)
		flist:SetPos(10,menu.t.a:GetTall()-43)
		flist:SetSize(130,20)
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() then
				if not(defcon.Whitelist[v:SteamID()]) then
					local i = flist:AddChoice(v:Nick())
				end
			end
		end	
		flist.OnSelect = function(index,value,data)
			print(data)
			elist2 = data
		end
	end
	local function makeflistc()
		flistc = vgui.Create("DComboBox", menu.t.a)
		flistc:SetPos(235, menu.t.a:GetTall()-43)
		flistc:SetSize(130,20)
		for k,v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() then
				if defcon.Whitelist[v:SteamID()] then
					local i = flistc:AddChoice(v:Nick())
				end
			end
		end
		flistc.OnSelect = function(index,value,data)
			flistc2 = data
		end
	end
	makeflist()
	makeflistc()
	AddButton(menu.t.a, "Add Friend", 35, menu.t.a:GetTall()-23, function()
		if(flist2) then
			for k,v in pairs(player.GetAll()) do
				if (v:Nick() == flist2) then
					print(v:Nick())
					table.insert(defcon.Whitelist, v:SteamID())
					PrintTable(defcon.Whitelist)
					defcon.Update("friend")
				end
			end
		end
		makeflist()
		makeflistc()
	end)
	AddButton(menu.t.a, "Remove Friend", 260, menu.t.a:GetTall()-23, function()
		if(flistc2) then
			for k,v in pairs(defcon.Whitelist) do
				if (v:SteamID() == flistc2) then
					defcon.Whitelist[k] = nil;
					defcon.Update("friend")
				end
			end
		end
		makeflist()
		makeflistc()
	end)*/
end

hook.Add("HUDPaint", "catHUD", function()
	if defcon.Settings["esp_player"] or defcon.Settings["esp_entity"] then
		for k,v in pairs(ents.GetAll()) do
			if defcon.Settings["esp_player"] && v:IsPlayer() then
				if(espcheck("player", v) and espdistance("player", v))then
					local ESP = (v:EyePos()):ToScreen()
					local name,health,rank,col,distance = "","","","",""
					local outcol = Color(0,0,0,255)
					local white = Color(255,255,255,255)
					local outcol2 = outcol
					if defcon.Settings["esp_player_name"] then
						if v.GetRPName then name = v:GetRPName()
						else name = v:Nick() end
					end
					if v:Nick() ~= name then rank = " "..v:Nick() end
					if v.SteamName and name ~= v:SteamName() then rank = " "..v:SteamName() end
					if defcon.Settings["esp_player_rank"] then
						if v:IsSuperAdmin() then
							rank = "[Super Admin]"..rank
						elseif v:IsAdmin() then
							rank = "[Admin]"..rank
						elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
							rank = "[Moderator]"..rank
						elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
							rank = "[Donator]"..rank
						end
					end
					if defcon.Settings["esp_player_health"] and not(defcon.Settings["esp_player_armor"]) then
						health = v:Health().."H"
					elseif defcon.Settings["esp_player_armor"] and not(defcon.Settings["esp_player_health"]) then
						health = v:Armor().."A"
					elseif defcon.Settings["esp_player_armor"] and defcon.Settings["esp_player_health"] then
						health = v:Health().. "H - "..v:Armor().."A"
					end
					if defcon.Settings["esp_player_showdist"] then
						distance = v:GetPos():Distance(LocalPlayer():GetPos())
						distance = math.Round(distance).." m"
					end
					col = team.GetColor(v:Team())
					if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
						outcol2 = Color(200,200,200,255)
					end
					if col.a <= 50 then
						col = Color(col.r,col.g,col.b, 255)
					end
					draw.SimpleTextOutlined(rank, "deffontesp2", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
					draw.SimpleTextOutlined(name, "deffontesp1", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
					if health ~= "" then
						draw.SimpleTextOutlined(health, "deffontesp2", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
						draw.SimpleTextOutlined(distance, "deffontesp2", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
					else
						draw.SimpleTextOutlined(distance, "deffontesp2", ESP.x, ESP.y - 22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
					end
					if defcon.Settings["esp_player_glow"] then
						halo.Add({v}, col, 2, 2, 1, true, true)
					end
				end
			end
			if (defcon.Settings["esp_entity"] and espcheck("entity", v) and espdistance("entity", v))then
				if table.HasValue(defcon.Entities, v:GetClass()) then
					local ESP = (v:EyePos()):ToScreen()
					draw.SimpleTextOutlined(v:GetClass(), "deffontesp1", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
				end
			end
		end
	end
end)
hook.Add("Think", "catBOT", function()
	if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
		DrawMenu()
	elseif(menu.frame && input.IsKeyDown(KEY_ESCAPE))then
		menu.frame:Remove();menu.frame = nil
	end
	if defcon.Settings["flashlight_spam"] and input.IsKeyDown(KEY_LEFT) then
		RunConsoleCommand("impulse", "100")
	end
	if(defcon.Settings["triggerbot"] && input.IsMouseDown(MOUSE_4)) then
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
			target = trace.Entity
			if(target:IsPlayer() and defcon.CanTarget(target)) then
				RunConsoleCommand("+attack")
				timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
			end
		end
	end
	if(defcon.Settings["aimbot"] && /*input.IsKeyDown(defcon.AimKey)*/ input.IsKeyDown(KEY_F)) then
		for k,v in pairs(player.GetAll()) do
			if defcon.CanTarget(v) then
				local head = v:LookupBone("ValveBiped.Bip01_Head1")
				if head ~= nil then
					local fov = defcon.Settings["aimbot_fov"]
					if fov == 0 then
						local headpos,targetheadang = v:GetBonePosition(head)
						LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
					else
						local lpang = LocalPlayer():GetAngles();
						local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
						local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
						local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
						if not(ady > fov or adp > fov) then
							local headpos,targetheadang = v:GetBonePosition(head)
							if headpos != nil and targetheadang != nil then
								LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
							end
						end
					end
				end
			end
		end
	end
	if string.find(gmod.GetGamemode().Name, "Trouble in Terrorist Town") and defcon.Settings["ttt_deathnotifs"] then
		for k,v in pairs(player.GetAll()) do
			if v:Alive() and not (defcon.Alive[v:UniqueID()] == true) then
				defcon.Alive[v:UniqueID()] = true
			elseif not v:Alive() and (defcon.Alive[v:UniqueID()] == true) then
				defcon.Alive[v:UniqueID()] = false
				notification.AddLegacy(v:Nick().. " has died!", NOTIFY_GENERIC, 5)
			end
		end
	end
end)

/*concommand.Add("debug", function()
	local pcash,gname = "", gmod.GetGamemode().Name
	print("Game-mode:\n    "..gname)
	if string.find(gname, "DarkRP") then
		print("Player Cash Amounts")
		for k,v in pairs(player.GetAll()) do
			if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
				darkrpvar = false
			end
			if v ~= LocalPlayer() then
				pcash = pcash.."    "..v:Nick().." - "..v.DarkRPVars.money.."\n"
			end
		end
		if pcash ~= "" then
			print(pcash)
		end
	end
	if LocalPlayer().GetActiveWeapon and LocalPlayer():GetActiveWeapon() ~= nil and IsValid(LocalPlayer():GetActiveWeapon()) then
		print("Current Weapon")
		print("    "..LocalPlayer():GetActiveWeapon():GetClass())
	end
		local pos = LocalPlayer():GetShootPos()
	local ang = LocalPlayer():GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos+(ang*9999999999999)
	local trace = util.TraceLine(tracedata)
	if(trace.HitNonWorld) then
		target = trace.Entity
		print("Entity Info")
		print("    Class: "..target:GetClass())
		print("    Model: "..target:GetModel())
	end
end)*/