local player = player 

local me = LocalPlayer()

local function say( str, ... )
    local fstr = string.format( str, ... )
    RunConsoleCommand( "say", fstr )
    print( "Sayin", fstr )
end

local lastMsg = 0
local function parseMessage( data )
    if not isstring( data ) or data:find("!whopedo") then 
        return 
    end 

    local curTime = CurTime()

    if lastMsg > curTime then
        return 
    end

    local plys = player.GetAll()

    for i = 1, #plys do
        if plys[ i ] == me then
            table.remove( plys, i )
        end
    end

    local rply = plys[ math.random( 1, #plys ) ]

    say( "I think %s is a pedophile :D", rply:Name() )

    lastMsg = curTime + 1.5
end

chat_AddText = chat_AddText or chat.AddText
function chat.AddText( ... )
    local tbl = { ... }

    for i = 1, #tbl do
        parseMessage( tbl[ i ] )
    end

    return chat_AddText( ... )
end

print("bot")