local commands =  {
    ["require"] = function( ply, cmd, arg, str )
        if str == "" then
            print( "no args was passed XD" )
            return 
        end

        require( str ) 
    end,
    ["rocx_run"] = function( ply, cmd, arg, str )
        if str == "" then
            print( "no args was passed XD" )
            return 
        end

        local strPath = tostring( arg[ 1 ] )
        local bExists = file.Exists( strPath, "LuaMenu" )

        if not bExists then
            print( string.format( "nothing found for %s :(", strPath ) )
            return 
        end

        local strRead = file.Read( strPath, "LuaMenu" )
        RunOnClient( strRead )
    end,
    ["execute"] = function( ply, cmd, arg, str ) 
        if str == "" then
            print( "no args was passed XD" )
            return 
        end

        local strPath = tostring( arg[ 1 ] )
        local bExists = file.Exists( strPath, "LuaMenu" )

        if not bExists then
            print( string.format( "nothing found for %s :(", strPath ) )
            return 
        end

        local strRead = file.Read( strPath, "LuaMenu" )
        RunString( strRead )
    end,
}

for key, func in pairs( commands ) do
    concommand.Add( key, func )
end