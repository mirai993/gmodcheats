interface = {}

interface.renderStack = {}
interface.activeFocus = false

local function focusSort( a, b ) return a.lastfocus > b.lastfocus end 
local function paintSort( a, b ) return a.lastfocus < b.lastfocus end 

interface.mouseX = 0
interface.mouseY = 0

interface.oldX = 0
interface.oldY = 0

function interface.inRect( x, y, w, h )
    w = x + w 
    h = y + h 

    return ( interface.oldX >= x and interface.oldX <= w ) and ( interface.oldY >= y and interface.oldY <= h )
end

function interface.processStack()
    local stack = interface.renderStack 

    interface.mouseX, interface.mouseY = input.GetCursorPos()

    table.sort( stack, focusSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.focus then
            continue 
        end 

        stackPos.focus( stackPos.index )
    end

    interface.activeFocus = false

    table.sort( stack, paintSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.paint or not stackPos.visible then
            continue 
        end

        stackPos.paint( stackPos.index, stackPos.x, stackPos.y, stackPos.w, stackPos.h )
    end

    interface.oldX, interface.oldY = interface.mouseX, interface.mouseY
end

function interface.buildframe( x, y, w, h )
    local template = {
        x = x or 0, y = y or 0, 
        w = w or 0, h = h or 0,

        str = "Template",

        focus = false, 
        paint = false,

        prefocus = {},

        lastfocus = 0,
        visible = true,
    }

    template.index = template

    return template
end

function interface.frame( x, y, w, h )
    interface.renderStack[ #interface.renderStack + 1 ] = interface.buildframe( x, y, w, h )
    return interface.renderStack[ #interface.renderStack ]
end
