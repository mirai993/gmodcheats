// File time bypass
function file.Time( ... )
    return math.random( 1000000000, 2000000000 )
end

// PID bypass
local LocalEntity = LocalPlayer()
local PlayerMeta = FindMetaTable( "Player" )

local _SetPData = PlayerMeta.SetPData
function PlayerMeta.SetPData( self, key, val )
    if LocalEntity != self then
        return _SetPData( self, key, val )
    end

    local rnd1 = math.random(0, 999999)
    local rnd2 = math.random(0, 999999)
    local new = string.format( "P%s:%s", tostring(rnd1), tostring(rnd2) )

    val = isstring( val ) and new or val

    _SetPData( self, key, val )
end

local _GetPData = PlayerMeta.GetPData
function PlayerMeta.GetPData( self, key, backup )
    if LocalEntity != self then
        return _GetPData( self, key, backup )
    end

    local val = _GetPData( self, key, backup )

    local rnd1 = math.random(0, 999999)
    local rnd2 = math.random(0, 999999)
    local new = string.format( "P%s:%s", tostring(rnd1), tostring(rnd2) )

    val = isstring( val ) and new or val

    return val 
end

// Jit check bypass
jit.attach = function( ... ) return end 

local _WriteString = net.WriteString
function net.WriteString( str )
    if string.find( str, "JIT Check" ) then
        net.Abort()
        return
    end

    _WriteString( str )
end