settings = {}

settings.color = {
    Shadow = Color( 8, 8, 8, 96 ),
    Black = Color( 0, 0, 0 ),
    
    Background = Color( 24, 24, 24 ),
    Header = Color( 32, 32, 32 ),
    Outline = Color( 56, 56, 56 ),
    
    AccentLow = Color( 190, 56, 56, 200 ),
    AccentHr = Color( 190, 56, 56, 128 ),
    Accent = Color( 220, 56, 56 ),
    
    TitleColor = Color( 255, 255, 255 ),
}
