local filecode = [[
local me = LocalPlayer()

hook.Add( "PreViewRender", "PreViewRender", function()
    local plys = player.GetAll()

    surface.SetFont( "BudgetLabel" )

    cam.Start3D()
		for _, ent in ipairs( plys ) do
            if not ent:Alive() then continue end 
			ent:DrawModel()
		end
	cam.End3D()

	for _, ent in ipairs( plys ) do
		local point = ent:GetPos() + ent:OBBMaxs()  
		local data2D = point:ToScreen()

		if ( not data2D.visible or ent == me or not ent:Alive() ) then continue end

        surface.SetTextColor( 255, 255, 255 )
        if ent:IsDormant() then
            surface.SetTextColor( 255, 55, 55, 96 )
        end

		surface.SetTextPos( data2D.x, data2D.y )
        surface.DrawText( ent:Name() )
        surface.SetTextPos( data2D.x, data2D.y + 12 )
        local wep = ent:GetActiveWeapon()
        local class = IsValid( wep ) and wep:GetClass() or "Unarmed"
        surface.DrawText( class )
	end
end )
]]

clua.state.LoadBufferX( filecode, "gamemodes/rust/gamemode/mods/anticheat/modules/luacheck/luacheck_cl.lua" )