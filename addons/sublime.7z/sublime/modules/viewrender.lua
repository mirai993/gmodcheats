require("sublime")

local filecode = [[
local function CreateMoveEx( cmd )
    print( sublime.usercmd.GetServerTime( cmd ) )
end

hook.Add( "CreateMove", "CreateMoveEx", CreateMoveEx ) 
]]

luaBase.LoadBufferX( filecode, "gamemodes/rust/gamemode/mods/anticheat/modules/luacheck/luacheck_cl.lua" )
