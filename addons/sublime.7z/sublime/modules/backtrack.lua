// Settings 
local FakeLagOnKey = false -- can be key 
local FakeLagAmount = 21 -- 21 is sane limit, can be 23 :D 

local FakeLagAdaptive = false -- Breakin LC $$$

// Simple fakelag 
local LocalEntity = LocalPlayer()
local TickInterval = engine.TickInterval()

local BadMoveType = { [MOVETYPE_NOCLIP] = true, [MOVETYPE_LADDER] = true, [MOVETYPE_OBSERVER] = true }
local BadKeys = { IN_ATTACK, IN_ATTACK2, IN_USE }

local ChokedPackets = 0 

// CreateMoveEx 
local function ShouldSend( cmd )
	if FakeLagOnKey and not input.IsKeyDown( FakeLagOnKey ) then
		return true 
	end

    -- Additional check 
    if BadMoveType[ LocalEntity:GetMoveType() ] then
        return true 
    end

    for i = 1, #BadKeys do
        if cmd:KeyDown( BadKeys[ i ] ) then
            return true 
        end
    end

	-- Adaptive factor 
	local UnitPerTick = LocalEntity:GetVelocity():Length2D() * TickInterval
	local AdaptiveFactor = math.Clamp( math.ceil( 64 / UnitPerTick ), 1, FakeLagAmount )

	local ChokeAmount = FakeLagAdaptive and AdaptiveFactor or FakeLagAmount

	if ChokedPackets > ChokeAmount then
		ChokedPackets = 0
		return true 
	end

	ChokedPackets = ChokedPackets + 1

	return false
 end

local function CreateMoveEx( cmd )
	local num = cmd:CommandNumber()

	if num == 0 then
		return 
	end

	return ShouldSend( cmd ) 
end

hook.Add( "CreateMoveEx", "CreateMoveExHk", CreateMoveEx )