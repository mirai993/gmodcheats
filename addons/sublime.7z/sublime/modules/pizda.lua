require("rocx")

local bypass = {
    ["gamemodes/rust/gamemode/mods/anticheat/modules/antialt/antialt_cl.lua"] = true,
    ["gamemodes/rust/gamemode/mods/anticheat/modules/luacheck/luacheck_cl.lua"] = true,
}

local function RunOnClient( path, code )
    print(path)
    if bypass[ path ] then
        return "return"
    end

    return code 
end

hook.Add( "RunOnClient", "RunOnClient", RunOnClient )

print("funny")