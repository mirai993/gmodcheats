// Surface additions 
local surface = surface 

function surface.CreateFontArgs( strName, ... )

end










































include( "sublime/modules/interface.lua" )
include( "sublime/modules/settings.lua" )

local fontData = {
    font = "Segoe UI", 
	extended = false,
	size = 18,
}

surface.CreateFont( "Veranda", fontData )

local fontData = {
    font = "Segoe UI", 
	extended = false,
	size = 16,
}

surface.CreateFont( "VerandaS", fontData )

local GradientUp = Material( "gui/gradient_up" )
local GradientLt = Material( "vgui/gradient-l", "noclamp smooth" )

local configTab = 4
local configTabs = { "Combat", "Render", "Misc", "Settings" }

local panel = interface.frame( 480, 56, 480, 640 )

panel.paint = function( self, x, y, w, h )
    local sx, sy, sw, sh = x + 8, y + 36, 228, 200

    surface.SetDrawColor( settings.color.AccentLow )
    surface.DrawRect( x, y, w, 24 )

    surface.SetDrawColor( settings.color.Background )
    surface.DrawRect( x, y + 24, w, h - 24 )

    surface.SetDrawColor( settings.color.Accent )
    surface.DrawRect( x, y + 24, w, 4 )

    surface.SetDrawColor( settings.color.Shadow )
    surface.SetMaterial( GradientUp )
    surface.DrawTexturedRect( x, y, w, 24 )

    surface.SetFont( "Veranda" )  
    surface.SetTextColor( settings.color.TitleColor )
 
    local tabX = x + w

    for i = #configTabs, 1, -1  do
        local tabTitle = configTabs[ i ]
        local textWidth = surface.GetTextSize( tabTitle )
        local tabWidth = textWidth + 16

        tabX = tabX - tabWidth

        if i == configTab then
            surface.SetDrawColor( settings.color.Shadow )
            surface.DrawRect( tabX, y, tabWidth, 24 )

            surface.SetDrawColor( settings.color.Accent )
            surface.SetMaterial( GradientUp )
            surface.DrawTexturedRect( tabX, y, tabWidth, 24 )
        end
  
        surface.SetTextPos( tabX + tabWidth / 2- textWidth / 2, y + 4 ) 
        surface.DrawText( tabTitle )
    end

    surface.SetDrawColor( settings.color.Shadow )   
    surface.DrawOutlinedRect( x - 1, y - 1, w + 2, h + 2, 2 )

    surface.SetTextPos( x + 6, y + 4 )
    surface.DrawText( "Configuration" )

    // sub 
    surface.SetDrawColor( settings.color.Header )
    surface.DrawRect( sx, sy, sw, sh )

    surface.SetDrawColor( settings.color.Shadow )   
    surface.DrawOutlinedRect( sx - 1, sy - 1, sw + 2, sh + 2 )

    surface.SetDrawColor( settings.color.Outline )   
    surface.DrawOutlinedRect( sx, sy, sw, sh )

    surface.SetDrawColor( settings.color.AccentHr )
    surface.DrawRect( sx, sy, sw, 20 )
    
    surface.SetDrawColor( settings.color.AccentLow )
    surface.SetMaterial( GradientUp )
    surface.DrawTexturedRect( sx, sy, sw, 20 )

    surface.SetDrawColor( settings.color.Accent )
    surface.DrawRect( sx, sy + 20, sw, 2 )

    surface.SetFont( "VerandaS" )
    surface.SetTextPos( sx + 4, sy + 2 )
    surface.DrawText( "Something" )
end 

panel.focus = function( self )
    local x, y, w, h = self.x, self.y, self.w, self.h

    if not interface.inRect( x, y, w, h ) or not input.IsMouseDown( MOUSE_LEFT ) then
        return 
    end

    self.x = self.x + ( interface.mouseX - interface.oldX )
    self.y = self.y + ( interface.mouseY - interface.oldY )
end





// Render 
hook.Add( "DrawOverlay", "Render", interface.processStack )