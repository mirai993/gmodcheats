--[[
	autorun/client/mfsp_init.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

/*
	* The forline scripts pack v1.0
	* The first 'real' release of the scripts pack,
	* with effecient API for custom modules.
	* With Comments.
*/

// Initialization of the global table since this is object-oriented.
MFSP = {}
MFSP.Data = {}
MFSP.Internal = {}
MFSP.Modules = {}
MFSP.Util = {}
MFSP.Utilities = {}

MFSP.Data.CFGCheckBoxes = {}
MFSP.Data.CFGTextBoxes = {}
MFSP.Data.CFGSliders = {}
MFSP.Data.CFGColors = {}
MFSP.Data.LastSpawnedProp = nil

MFSP.Data.StaticNames = {}

function MFSP.Internal.ReadStaticNames()
	if not file.Exists("mfsp/staticnames.txt") then
		file.Write("mfsp/staticnames.txt", "")
	else
		MFSP.Data.StaticNames = {}
		table.Empty(MFSP.Data.StaticNames)
		for _, ply in pairs(player.GetAll()) do
			ply.staticname = ""
		end
		local f = file.Read("mfsp/staticnames.txt")
		local exp = string.Explode("\n", f)
		for k, v in pairs(exp) do
			local matcher = "(STEAM_%d:%d:%d+) (.+)"
				if string.match(v, matcher) then
				local checkedid = string.gsub(v, matcher, "%1")
				local checkedname = string.gsub(v, matcher, "%2")
				MFSP.Data.StaticNames[checkedid] = checkedname
				for _, ply in pairs(player.GetAll()) do
					if ply:SteamID() == checkedid then
						ply.staticname = checkedname
					end
				end
			end
		end
	end
end

function MFSP.Internal.WriteStaticNames()
	file.Write("mfsp/staticnames.txt", "")
	for k, v in pairs(MFSP.Data.StaticNames) do
		filex.Append("mfsp/staticnames.txt", k .. " " .. v .. "\n")
	end
end

function MFSP.SetStaticName(steamid, name)
	MFSP.Data.StaticNames[steamid] = name
	MFSP.Internal.WriteStaticNames()
	MFSP.Internal.ReadStaticNames()
end

MFSP.Internal.ReadStaticNames()

function MFSP.Internal.EntityCreated(ent)
	if ent != nil then
		if ent and ent:IsValid() then
			if string.match(string.lower(ent:GetClass()), "prop") then
				local spawner = nil
				for k, v in pairs(player.GetAll()) do
					if v != nil then
						if v and v:IsValid() then
							if v:Alive() then
								local tr = v:GetEyeTrace()
								if tr != nil and tr.Entity != nil then
									local trent = tr.Entity
									if trent and trent:IsValid() then
										if trent == ent then
											if v == LocalPlayer() then
												MFSP.Data.LastSpawnedProp = ent
											end
											spawner = v
										end
									end
								end
							end
						end
					end
				end
				if spawner != nil and spawner:IsValid() then
					ent.mfsp = {}
					ent.mfsp.owner = spawner
					print(spawner:Nick() .. " (" .. spawner:SteamID() .. ") spawned a " .. ent:GetClass() .. " with model " .. ent:GetModel() .. ".");
				end
			end
		end
	end
end

function MFSP.Util.AddCFGCheckBox(Mod, title, convar, default)
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar, default or "1", true, false)
	end
	table.insert(MFSP.Data.CFGCheckBoxes, {mod = Mod, title = title or "Unknown", convar = "mfsp_" .. Mod.ConVar .. "_" .. convar})
end

function MFSP.Util.AddCFGTextBox(Mod, title, convar, default)
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar, default or "Text", true, false)
	end
	table.insert(MFSP.Data.CFGTextBoxes, {mod = Mod, title = title or "Unknown", convar = "mfsp_" .. Mod.ConVar .. "_" .. convar})
end

function MFSP.Util.AddCFGSlider(Mod, title, convar, default, min, max)
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar, default or 0, true, false)
	end
	table.insert(MFSP.Data.CFGSliders, {mod = Mod, title = title or "Unknown", convar = "mfsp_" .. Mod.ConVar .. "_" .. convar, min = min or 0, max = max or 1000})
end

function MFSP.Util.AddCFGColor(Mod, title, convar, defaultr, defaultg, defaultb, defaulta)
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_r") then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_r", defaultr or 0, true, false)
	end
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_g") then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_g", defaultg or 0, true, false)
	end
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_b") then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_b", defaultb or 0, true, false)
	end
	if not ConVarExists("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_a") then
		CreateClientConVar("mfsp_" .. Mod.ConVar .. "_" .. convar .. "_a", defaulta or 255, true, false)
	end
	table.insert(MFSP.Data.CFGColors, {mod = Mod, title = title or "Unknown", convar = "mfsp_" .. Mod.ConVar .. "_" .. convar})
end

include("includes/MFSPModule.lua")
include("mfsp_menu.lua")

CreateClientConVar("mfsp_debugmode", "0", true, false)

// Debug function
function MFSP.Util.Debug(text)
	if GetConVar("mfsp_debugmode"):GetBool() then
		print("[MFSP Debug] > " .. text)
	end
end

// Register an utility
function MFSP.RegisterUtility(title, func, cmd)
	if cmd != "" and cmd != nil then
		concommand.Add("mfsp_" .. cmd, func)
	end
	table.insert(MFSP.Utilities, {func = func, title = title})
end

// Get ConVar as boolean for modules
function MFSP.Util.ModConVarEnabled(mod, convar)
	if not ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar) then
		return true
	else
		return GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar):GetBool()
	end
end

// Get Module Slider ConVar
function MFSP.Util.GetModValue(mod, convar)
	if not ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar) then
		return 0
	else
		return GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar):GetInt()
	end
end

// Get Module Color ConVar
function MFSP.Util.GetModColor(mod, convar)
	local r = 255
	local g = 255
	local b = 255
	local a = 255

	if ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar .. "_r") then
		r = GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar .. "_r"):GetInt()
	end
	if ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar .. "_g") then
		g = GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar .. "_g"):GetInt()
	end
	if ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar .. "_b") then
		b = GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar .. "_b"):GetInt()
	end
	if ConVarExists("mfsp_" .. mod.ConVar .. "_" .. convar .. "_a") then
		a = GetConVar("mfsp_" .. mod.ConVar .. "_" .. convar .. "_a"):GetInt()
	end

	return Color(r, g, b, a)
end

// Function for adding a custom module
function MFSP.Util.AddModule(mod)
	MFSP.Util.Debug("Module added! \"" .. mod.Title .. "\"!")
	table.insert(MFSP.Modules, mod)
end

// Internal Think function
function MFSP.Internal.Think()
	for k, v in pairs(MFSP.Modules) do
		if v and v != nil then
			if MFSP.Util.IsConVarEnabled(v) then
				if v.IsEnabled["Think"] then
					v.Think()
				end
			end
		end
	end
end

// Internal Draw function
function MFSP.Internal.Draw()
	for k, v in pairs(MFSP.Modules) do
		if v and v != nil then
			if MFSP.Util.IsConVarEnabled(v) then
				if v.IsEnabled["Draw"] then
					v.Draw()
				end
			end
		end
	end
end

// Internal RSP function
function MFSP.Internal.SPEffects()
	for k, v in pairs(MFSP.Modules) do
		if v and v != nil then
			if MFSP.Util.IsConVarEnabled(v) then
				if v.IsEnabled["SPEffects"] then
					v.SPEffects()
				end
			end
		end
	end
end

// For Console Command toggling of modules
function MFSP.Util.SetConVarToggle(mod, convar, default)
	CreateClientConVar("mfsp_" .. convar .. "_enabled", default or "1", true, false)
	mod.ConVar = convar
end

// Get if the module has a ConVar toggle and then check if it is enabled. Returns true if object has no ConVar toggling it.
function MFSP.Util.IsConVarEnabled(mod)
	if mod.ConVar == "" then
		return true
	else
		return GetConVar("mfsp_" .. mod.ConVar .. "_enabled"):GetBool()
	end
end

// Included modules
include("modules/mod_esp.lua")
include("modules/mod_xray.lua")
include("modules/mod_bhop.lua")
include("modules/mod_rotate.lua")
include("modules/mod_view.lua")
include("modules/mod_antiadmin.lua")
include("modules/mod_weaponwarning.lua")
include("modules/mod_chat.lua")
include("modules/util_propview.lua")
// Custom (Unofficial) modules, you do not need to include() them,
// it's just to have them reloading whenever mfsp_init reloads or when you use mfsp_reload.

// Utilities
include("modules/util_detector.lua")
include("modules/util_notepad.lua")
include("modules/util_dupeupload.lua")
include("modules/util_specplayer.lua")

hook.Add("Think", "MFSP.Internal.Think", MFSP.Internal.Think)
hook.Add("HUDPaint", "MFSP.Internal.Draw", MFSP.Internal.Draw)
hook.Add("RenderScreenspaceEffects", "MFSP.Internal.SPEffects", MFSP.Internal.SPEffects)
hook.Add("OnEntityCreated", "MFSP.Internal.EntityCreated", MFSP.Internal.EntityCreated)