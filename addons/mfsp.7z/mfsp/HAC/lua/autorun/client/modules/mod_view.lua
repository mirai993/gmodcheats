--[[
	autorun/client/modules/mod_view.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local Mod = MFSPModule("View Utils")

function MFSP.Util.DrawForward()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(0, ang.y, ang.r))
end

concommand.Add("+drawfixed", function()
	hook.Add("Think", "MFSP.Util.DrawForward", MFSP.Util.DrawForward)
end)

concommand.Add("-drawfixed", function()
	hook.Remove("Think", "MFSP.Util.DrawForward")
end)