--[[
	autorun/client/modules/mod_antiadmin.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local Mod = MFSPModule("Anti Admin Effects")
MFSP.Util.SetConVarToggle(Mod, "anti", 1)
	Mod.IsEnabled["Think"] = true
	Mod.HasConfig = true

local umh = usermessage.Hook
function usermessage.Hook(name, func)
	if MFSP.Util.ModConVarEnabled(Mod, "antiblind") then
		if name != "ulx_blind" then
			umh(name, func)
		end
	else
		umh(name, func)
	end
end

function Mod:Think()
	if MFSP.Util.ModConVarEnabled(Mod, "antimute") then
		if LocalPlayer():GetNWBool("Muted") then
			LocalPlayer():SetNWBool("Muted", false)
		end
		hook.Remove("PlayerBindPress", "ULXGagForce")
		timer.Destroy("GagLocalPlayer")
	end
	if MFSP.Util.ModConVarEnabled(Mod, "antiblind") then
		if LocalPlayer():GetNWBool("EV_Blinded") then
			LocalPlayer():SetNWBool("EV_Blinded", false)
		end
	end
end

MFSP.Util.AddCFGCheckBox(Mod, "Enable Anti-Gag/Anti-Mute", "antimute")
MFSP.Util.AddCFGCheckBox(Mod, "Enable Anti-Blind", "antiblind")