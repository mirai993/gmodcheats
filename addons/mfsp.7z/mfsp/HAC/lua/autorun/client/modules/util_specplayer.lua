--[[
	autorun/client/modules/util_specplayer.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

function MFSP.Spectate(plyname)
	local ply = LocalPlayer()
	for k, v in pairs(player.GetAll()) do
		if string.match(string.lower(v:Nick()), string.lower(plyname)) then
			ply = v
		end
	end
	hook.Add("HUDPaint", "SpectatePlayer", function()
		if ply and ply:IsValid() then
			local CamData = {}
				local hpos, hang = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
				CamData.angles = ply:EyeAngles()
				CamData.origin = hpos + ((hpos - ply:GetShootPos()) / 2) - Vector(-5, 0, 4)
				CamData.x = 0
				CamData.y = 0
				CamData.w = ScrW()
				CamData.h = ScrH()
				render.RenderView(CamData)
		end
	end)
end

function MFSP.SpecMenu()
	local sizew = 300
	local sizeh = 100

	local Frame = vgui.Create("DFrame")
		Frame:SetSize(sizew, sizeh)
		Frame:Center()
		Frame:SetTitle("Player Spectating")
		Frame:ShowCloseButton(true)
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:SetBackgroundBlur(true)
		Frame:MakePopup()
	local Name = vgui.Create("DTextEntry", Frame)
		Name:SetSize(sizew - 40, 20)
		Name:SetPos(20, 30)
		Name:SetText("Part of player name")
		Name.OnTextChanged = function()
			local files = file.Find("adv_duplicator/*.txt")
			if #files != 1 then
				local Menu = DermaMenu()
				for k, v in pairs(player.GetAll()) do
					if string.match(string.lower(v:Nick()), string.lower(Name:GetValue())) then
						Menu:AddOption(v:Nick(), function()
							Name:SetText(v:Nick())
						end)
					end
				end
				Menu:Open()
			end
		end
	local SpecButton = vgui.Create("DButton", Frame)
		SpecButton:SetSize(100, 30)
		SpecButton:SetPos((sizew / 2) - 50, 60)
		SpecButton:SetText("Spectate Player")
		SpecButton.DoClick = function(self)
			MFSP.Spectate(Name:GetValue())
			Frame:Close()
		end
end

function MFSP.StopSpec()
	hook.Remove("HUDPaint", "SpectatePlayer")
end

MFSP.RegisterUtility("Player Spectate", MFSP.SpecMenu, "spectatemenu")
MFSP.RegisterUtility("Stop Spectating", MFSP.StopSpec, "stopspec")