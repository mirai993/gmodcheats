--[[
	autorun/client/modules/mod_esp.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

FLS.colors.esp_box = Color(255, 0, 0, 192)
FLS.colors.esp_innerbox = Color(192, 0, 0, 192)
FLS.colors.esp_boxbackground = Color(192, 0, 0, 64)

FLS.colors.esp_aiming_box = Color(0, 255, 0, 192)
FLS.colors.esp_aiming_innerbox = Color(0, 192, 0, 192)
FLS.colors.esp_aiming_boxbackground = Color(0, 192, 0, 64)

FLS.colors.esp_playername = Color(255, 0, 0, 255)

FLS.data.esp_boxsize = 35
FLS.data.esp_innerboxoffset = 2

local XRayEnts = {}

local function ESP_ADDENTITY(ent)
	if GetConVar("fls_esp_xray"):GetInt() == 1 then
		if ent and ent:IsValid() then
			table.insert(XRayEnts, {entity = ent, material = ent:GetMaterial()})
		end
	end
end

local spawned = false

function ESP_DRAW()
	if GetConVar("fls_esp_enabled"):GetInt() != 1 then return end
	
	if GetConVar("fls_esp_xray"):GetInt() == 1 then
		RunConsoleCommand("rope_rendersolid", "0")
		if #XRayEnts <= 0 then
			surface.PlaySound("items/nvg_on.wav")
			for _, ent in pairs(ents.GetAll()) do
				if ent:IsPlayer() or ent:GetClass() == "prop_physics" or ent:GetClass() == "prop_ragdoll" or string.match(ent:GetClass(), "spawned_") or string.match(ent:GetClass(), "printer") or string.match(ent:GetClass(), "npc_") or ent:GetClass() == "prop_static" or ent:GetClass() == "prop_dynamic" or "prop_door_rotating" or ent:GetClass() == "func_door" or ent:GetClass() == "func_door_rotating" then
					ESP_ADDENTITY(ent)
				end
			end
		end
		for k, v in pairs(XRayEnts) do
			local ent = v.entity
			if ent and ent:IsValid() then
				if ent:GetClass() == "prop_physics" then
					ent:SetColor(Color(128, 0, 0, 128))
					ent:SetMaterial("models/xray_wireframe")
				elseif ent:GetClass() == "prop_ragdoll" or string.match(ent:GetClass(), "spawned_") or string.match(ent:GetClass(), "printer") or string.match(ent:GetClass(), "npc_") then
					ent:SetColor(Color(0, 0, 255, 255))
					ent:SetMaterial("models/xray_wireframe")
				elseif ent:GetClass() == "prop_static" or ent:GetClass() == "prop_dynamic" then
					ent:SetColor(Color(255, 0, 0, 255))
					ent:SetMaterial("models/xray_wireframe")
				elseif ent:GetClass() == "prop_door_rotating" or ent:GetClass() == "func_door" or ent:GetClass() == "func_door_rotating" then
					ent:SetColor(Color(0, 0, 255, 128))
					ent:SetMaterial("models/xray_wireframe")
				elseif ent:IsPlayer() then
					ent:SetColor(Color(0, 255, 0, 128))
					ent:SetMaterial("models/xray_wireframe")
				end
			end
		end
	else
		RunConsoleCommand("rope_rendersolid", "1")
		if #XRayEnts > 0 then
			surface.PlaySound("items/nvg_off.wav")
		end
		for k, v in pairs(XRayEnts) do
			if v.entity and v.entity:IsValid() then
				v.entity:SetMaterial(v.material)
				v.entity:SetColor(Color(255, 255, 255, 255))
			end
		end
		table.Empty(XRayEnts)
	end
	
	if GetConVar("fls_esp_drawplayers"):GetInt() == 1 then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				if v and v:IsValid() and GetConVar("fls_esp_drawtrace"):GetBool() then
					local THead = v:LookupBone("ValveBiped.Bip01_Head1")
					HeadPos, HeadAng = v:GetBonePosition(THead)
					HeadPos = v:GetPos() + Vector(0, 0, 32)
					local PHead = LocalPlayer():LookupBone("ValveBiped.Bip01_Head1")
					local HP2 = (HeadPos - Vector(0, 0, 10)):ToScreen()
					local SP = v:GetEyeTrace().HitPos:ToScreen()
					cam.Start3D(LocalPlayer():GetShootPos(), LocalPlayer():EyeAngles())
						render.SetMaterial(Material("cable/blue_elec"))
						render.DrawBeam(v:GetShootPos(), v:GetEyeTrace().HitPos, 5, 1, 1, Color(255,255,255,255))
						render.SetMaterial(Material("cable/hydra"))
						local t = {}
							t.start = v:GetShootPos()
							t.endpos = v:GetShootPos() + Vector(0, 0, 99999999)
							t.filter = v
						local trace = util.TraceLine(t)
						render.DrawBeam(trace.HitPos, v:GetShootPos(), 15, 1, 1, Color(255,255,255,255))
					cam.End3D()
				end
				local head = v:LookupBone("ValveBiped.Bip01_Head1")
				local pos = v:GetBonePosition(head)
					pos = pos:ToScreen()
				if LocalPlayer():GetEyeTrace().Entity != v then
					surface.SetDrawColor(FLS.colors.esp_box)
					surface.DrawOutlinedRect(pos.x - (FLS.data.esp_boxsize / 2), pos.y - (FLS.data.esp_boxsize / 2), FLS.data.esp_boxsize, FLS.data.esp_boxsize)
					surface.SetDrawColor(FLS.colors.esp_innerbox)
					surface.DrawOutlinedRect((pos.x - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, (pos.y - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2), FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2))
					surface.SetDrawColor(FLS.colors.esp_boxbackground)
					surface.DrawRect((pos.x - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, (pos.y - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2), FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2))
				else
					surface.SetDrawColor(FLS.colors.esp_aiming_box)
					surface.DrawOutlinedRect(pos.x - (FLS.data.esp_boxsize / 2), pos.y - (FLS.data.esp_boxsize / 2), FLS.data.esp_boxsize, FLS.data.esp_boxsize)
					surface.SetDrawColor(FLS.colors.esp_aiming_innerbox)
					surface.DrawOutlinedRect((pos.x - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, (pos.y - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2), FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2))
					surface.SetDrawColor(FLS.colors.esp_aiming_boxbackground)
					surface.DrawRect((pos.x - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, (pos.y - (FLS.data.esp_boxsize / 2)) + FLS.data.esp_innerboxoffset, FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2), FLS.data.esp_boxsize - (FLS.data.esp_innerboxoffset * 2))
				end
				surface.SetFont("Trebuchet18")
				local textw, texth = surface.GetTextSize(v:Nick())
				surface.SetTextColor(FLS.colors.esp_playername)
				surface.SetTextPos(pos.x + (FLS.data.esp_boxsize / 2) + 7, (pos.y - FLS.data.esp_boxsize) + texth)
				surface.DrawText(v:Nick())
				if v:IsAdmin() and not v:IsSuperAdmin() then
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.DrawText(" [ADMIN]")
				elseif v:IsSuperAdmin() then
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.DrawText(" [SUPERADMIN]")
				end

				surface.SetFont("DefaultSmall")
				local textw2, texth2 = surface.GetTextSize("S")
				surface.SetTextColor(Color(255, 255, 255))
				surface.SetTextPos(pos.x + (FLS.data.esp_boxsize / 2) + 7, (pos.y - FLS.data.esp_boxsize) + texth + (texth2 * 1))
				surface.DrawText("Distance: ")
				surface.SetTextColor(Color(0, 255, 0))
				surface.DrawText(math.Round(v:GetPos():Distance(LocalPlayer():GetPos())))
				surface.SetTextColor(Color(255, 255, 255))
				surface.SetTextPos(pos.x + (FLS.data.esp_boxsize / 2) + 7, (pos.y - FLS.data.esp_boxsize) + texth + (texth2 * 2))
				surface.DrawText("Health: ")
				if v:Health() <= 0 then
					surface.SetTextColor(Color(255, 0, 0))
					surface.DrawText("DEAD")
				else
					surface.SetTextColor(Color(0, 255, 0))
					surface.DrawText(v:Health() .. "%")
				end
				surface.SetTextColor(Color(255, 255, 255))
				local weapon = "Undefined"
				surface.SetTextPos(pos.x + (FLS.data.esp_boxsize / 2) + 7, (pos.y - FLS.data.esp_boxsize) + texth + (texth2 * 3))
				if v:Alive() and v:Health() > 0 and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() and v:GetActiveWeapon():IsWeapon() then
					weapon = v:GetActiveWeapon():GetPrintName() or v:GetActiveWeapon():GetClass()
				end
				surface.DrawText("Weapon: " .. weapon)
			end
		end
	end
end

hook.Add("HUDPaint", "FLS.DrawESP", ESP_DRAW)

/* CONSOLE VARIABLES */
CreateClientConVar("fls_esp_enabled", "1", true, false)
CreateClientConVar("fls_esp_xray", "1", true, false)
CreateClientConVar("fls_esp_drawplayers", "1", true, false)
CreateClientConVar("fls_esp_drawnpcs", "1", true, false)
CreateClientConVar("fls_esp_drawtrace", "1", true, false)

CreateClientConVar("fls_ev_forceowner", "0", true, false)