--[[
	autorun/client/modules/util_detector.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

MFSP.Data.Detectors = {}

function MFSP.Util.PlaceDetector(name, sound, message, key, friends)
	local tr = LocalPlayer():GetEyeTrace()
	if tr != nil then
		local pos = tr.HitPos
		if pos != nil then
			local t = {}
			if friends != nil then
				t = friends
				PrintTable(t)
			end
			local ang = tr.HitNormal:Angle()
			local ent = ents.Create("prop_physics")
				ent:SetModel("models/weapons/w_slam.mdl")
				local min = ent:OBBMins()
				local max = ent:OBBMaxs()
				ent:SetPos(pos + (tr.HitNormal * ((max - min) / 4)))
				ent:SetAngles(Angle(ang.p + 90, ang.y, ang.r))
				ent:Spawn()
				local num = -1
				if key != nil then
					num = key
				end
				table.insert(MFSP.Data.Detectors, {entity = ent, pos = pos, ang = ang, name = name, text = message, sound = sound, setoff = false, player = nil, key = num, friends = t})
				surface.PlaySound("weapons/slam/throw.wav")
				timer.Simple(0.2, function()
					surface.PlaySound("weapons/slam/mine_mode.wav")
				end)
		end
	end
end

CreateClientConVar("mfsp_drawdetectors", 1, true, false)

function MFSP.DrawDets()
	for k, v in pairs(MFSP.Data.Detectors) do
		if v.entity != nil then
			if v.entity and v.entity:IsValid() then
				if GetConVar("mfsp_drawdetectors"):GetBool() then
					local pos = v.pos:ToScreen()
					surface.SetFont("Default")
					local size = surface.GetTextSize(v.name)
					surface.SetTextPos(pos.x - (size / 2), pos.y - 7)
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetDrawColor(Color(0, 0, 0, 128))
					surface.DrawRect(pos.x - (size / 2) - 10, pos.y - 10, size + 20, 20)
					surface.DrawText(v.name)
				end
				local _tr = {}
					_tr.start = v.pos
					_tr.endpos = v.pos + (v.ang:Forward() * 999999)
					_tr.filter = v.entity
				local _trace = util.TraceLine(_tr)
				local endpos = _trace.HitPos
				cam.Start3D(EyePos(), EyeAngles())
					render.SetMaterial(Material("cable/redlaser"))
					render.DrawBeam(v.pos, endpos, 10, 1, 1, Color(255, 0, 0, 255))
				cam.End3D()
			end
		end
	end
end

function MFSP.Util.TriggerDetector(det)
	if MFSP.Data.Detectors[det] != nil then
		entry = MFSP.Data.Detectors[det]
		if not entry.setoff and entry.player != nil and entry.player:IsValid() then
			local text = entry.text
				text = string.Replace(text, "%P", entry.player:Nick())
				text = string.Replace(text, "%D", entry.name)
				if entry.sound then
					surface.PlaySound("buttons/button17.wav")
				end
				chat.AddText(Color(255, 0, 0), text)
				if entry.key != nil then
					if entry.key != -1 then
						RunConsoleCommand("+gm_special", entry.key)
						timer.Simple(0.05, function()
							RunConsoleCommand("-gm_special", entry.key)
						end)
					end
				end
		end
	end
end

function MFSP.DetectorTick()
	for k, v in pairs(MFSP.Data.Detectors) do
		if v.entity != nil then
			if v.entity and v.entity:IsValid() then
				local _tr = {}
					_tr.start = v.pos
					_tr.endpos = v.pos + (v.ang:Forward() * 999999)
					_tr.filter = v.entity
				local trace = util.TraceLine(_tr)
				if trace.Entity != nil then
					if trace.Entity and trace.Entity:IsValid() then
						if trace.Entity:IsPlayer() and trace.Entity != LocalPlayer() then
							local isFriend = false
							if #v.friends != 0 then
								for _k, _v in pairs(v.friends) do
									if _v == trace.Entity:SteamID() then
										isFriend = true
									end
								end
							end
							if not isFriend then
								v.player = trace.Entity
								MFSP.Util.TriggerDetector(k)
								v.setoff = true
							end
						else
							v.setoff = false
							v.player = nil
						end
					else
						v.setoff = false
						v.player = nil
					end
				else
					v.setoff = false
					v.player = nil
				end
			end
		end
	end
end

hook.Add("HUDPaint", "MFSP.DrawDets", MFSP.DrawDets)
hook.Add("Tick", "MFSP.DetectorTick", MFSP.DetectorTick)

function MFSP.Util.RemoveDetector()
	local tr = LocalPlayer():GetEyeTrace()
	if tr != nil then
		local pos = tr.HitPos
		if pos != nil then
			for k, v in pairs(MFSP.Data.Detectors) do
				if pos:Distance(v.pos) <= 20 then
					v.entity:Remove()
					table.remove(MFSP.Data.Detectors, k)
				end
			end
		end
	end
end

concommand.Add("mfsp_removedetector", MFSP.Util.RemoveDetector)

function MFSP.Util.DetMenu()
	local num = -1
	local FriendList = {}
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(500, 240)
		Frame:Center()
		Frame:SetTitle("Detector")
		Frame:SetDraggable(true)
		Frame:SetSizable(false)
		Frame:ShowCloseButton(false)
		Frame:SetBackgroundBlur(true)
		Frame:MakePopup()
	local Num = vgui.Create("DNumPad", Frame)
		Num:SetPos(410, 30)
		Num.OnButtonPressed = function(panel, key)
			print(key)
			num = key
		end
	local NameLabel = vgui.Create("DLabel", Frame)
		NameLabel:SetPos(10, 32)
		NameLabel:SetText("Detector Name: ")
		NameLabel:SizeToContents()
	local Name = vgui.Create("DTextEntry", Frame)
		Name:SetSize(Frame:GetWide() - 20 - NameLabel:GetWide() - 5 - 100, 20)
		Name:SetPos(10 + NameLabel:GetWide() + 5, 30)
		Name:SetValue("Detector" .. #MFSP.Data.Detectors + 1)
	local TextLabel = vgui.Create("DLabel", Frame)
		TextLabel:SetPos(10, 57)
		TextLabel:SetText("Detection Text: ")
		TextLabel:SizeToContents()
	local TextEntr = vgui.Create("DTextEntry", Frame)
		TextEntr:SetSize(Frame:GetWide() - 20 - NameLabel:GetWide() - 5 - 100, 20)
		TextEntr:SetPos(10 + NameLabel:GetWide() + 5, 55)
		TextEntr:SetValue("%P set off detector %D!")
	local UseSound = vgui.Create("DCheckBoxLabel", Frame)
		UseSound:SetPos(10, 80)
		UseSound:SetText("Use Sound")
		UseSound:SizeToContents()
		UseSound:SetValue(1)
	local PlaceButton = vgui.Create("DButton", Frame)
		PlaceButton:SetSize(150, 30)
		PlaceButton:SetPos(10, 100)
		PlaceButton:SetText("Place Detector")
		PlaceButton.DoClick = function()
			Frame:Close()
			MFSP.Util.PlaceDetector(Name:GetValue(), UseSound:GetChecked(), TextEntr:GetValue(), num, FriendList)
		end
	local CancelButton = vgui.Create("DButton", Frame)
		CancelButton:SetSize(150, 30)
		CancelButton:SetPos(170, 100)
		CancelButton:SetText("Cancel")
		CancelButton.DoClick = function()
			Frame:Close()
		end
	local CancelButton = vgui.Create("DButton", Frame)
		CancelButton:SetSize(60, 30)
		CancelButton:SetPos(330, 100)
		CancelButton:SetText("Clear")
		CancelButton.DoClick = function()
			for k, v in pairs(MFSP.Data.Detectors) do
				if v.entity != nil then
					v.entity:Remove()
				end
			end
			table.Empty(MFSP.Data.Detectors)
		end
	local List = vgui.Create("DListView", Frame)
		List:SetSize(Frame:GetWide() - 20, 80)
		List:SetPos(10, 150)
		List:SetMultiSelect(true)
		List:AddColumn("Detector \"Friends\"")
		List:AddColumn("SteamID")
		for k, v in pairs(player.GetAll()) do
			List:AddLine(v:Nick(), v:SteamID())
		end
		List.OnRowSelected = function(panel, line)
			FriendList = {}
			for k, v in pairs(List:GetSelected()) do
				table.insert(FriendList, v:GetValue(2))
			end
		end
end

MFSP.RegisterUtility("Detector", MFSP.Util.DetMenu, "detector")