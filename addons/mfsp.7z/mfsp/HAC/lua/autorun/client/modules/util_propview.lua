--[[
	autorun/client/modules/util_propview.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local CData = {}
MFSP.Data.IsViewingProp = false
MFSP.Data.EntPositions = {}

function MFSP.ViewProp()
	if MFSP.Data.LastSpawnedProp != nil then
		if MFSP.Data.LastSpawnedProp and MFSP.Data.LastSpawnedProp:IsValid() then
			CData.angles = EyeAngles()
			CData.origin = MFSP.Data.LastSpawnedProp:GetPos()
			CData.x = 0
			CData.y = 0
			CData.w = ScrW()
			CData.h = ScrH()
			render.RenderView(CData)
		else
			MFSP.Data.LastSpawnedProp = nil
		end
	end
end

function MFSP.StartViewProp()
	hook.Add("HUDPaint", "MFSP.ViewProp", MFSP.ViewProp)
	MFSP.Data.IsViewingProp = true
end

function MFSP.EndViewProp()
	hook.Remove("HUDPaint", "MFSP.ViewProp")
	MFSP.Data.IsViewingProp = false
end

concommand.Add("+mfsp_propview", MFSP.StartViewProp)
concommand.Add("-mfsp_propview", MFSP.EndViewProp)