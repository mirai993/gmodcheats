--[[
	autorun/client/modules/mod_chat.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

// Mainly used to extend the Static Name feature.

local Mod = MFSPModule("Chat Function")
MFSP.Util.SetConVarToggle(Mod, "customchat", 1)
	Mod.HasConfig = true

MFSP.Util.AddCFGCheckBox(Mod, "Enabled", "enabled", 0)
MFSP.Util.AddCFGCheckBox(Mod, "Annoying word \"Correction\" (SPELL-O-BOT)", "wordcorrection", 0)

MFSP.Data.WordDictionary =
{
	{"b[i1]+tch", "Elder Woman"},
	{"pu+ss+y+", "Vagina"},
	{"ba+ll+[sz]", "Scrotum"},
	{"t[1i]t[sz]*", "Breast(s)"},
	{"b[0o][0o]+b+[sz]+", "Breasts"},
	{"cu+nt", "Vagina"},
	{"admin", "Administrator"},
	{"u+ma+d%?*$", "Are you mad?"},
	{"u+ma+dbro", "Are you mad, brother?"},
	{"u+sa+d%?$", "Are you sad?"},
	{"u+sa+dbro", "Are you sad, brother?"},
	{"u+ga+y%?$", "Are you homosexual?"},
	{"u+ga+ybro", "Are you homosexual, brother?"},
	{"fag", "Homosexual"},
	{"g+[a@]+y+", "Homosexual"},
	{"n[i1][g5][g5][e3]r", "Thief"},
	{"n[i1]+[g5]+[g5]+[@a]+h*", "Thief"},
	{"jew", "Jewish"},
	{"fat", "Overgrown"},
	{"gtf[0o]+","Leave"},
	{"l[0o]l", "Haha"},
	{"[0o]mf*g", "Oh my god"},
	{"lmf*a[0o]", "Laughing my ass off"},
	{"r[0o]fl", "Rolling on floor laughing"},
	{"d[i1]ck", "Penis"},
	{"c[o0]ck", "Penis"},
	{"w[i1]ll[i1][e3]", "Penis"},
	{"w[i1]lly", "Penis"},
	{"n[o0][o0]+b", "Newbie"},
	{"n[o0]+u+b", "Newbie"},
	{"n[ou]+b", "Newbie"},
	{"shut%s*up", "Be quiet"},
	{"stfu+", "Be quiet"}
}

hook.Add("OnPlayerChat", "MFSP.CustomChat", function(ply, text, isTeam, isDead)
	if (MFSP.Util.ModConVarEnabled(Mod, "wordcorrection")) then
		local text2 = text
		local corrected = false
		local faults = 0

		if ply != LocalPlayer() then
			if string.match(string.lower(text), "f+%s*u+%s*c+%s*k+") then
				if ply.DarkRPVars != nil then
					RunConsoleCommand("say", "/ooc [SPELL-O-BOT] OI! Don't swear!")
				else
					RunConsoleCommand("say", "[SPELL-O-BOT] OI! Don't swear!")
				end
			end
			for k, v in pairs(MFSP.Data.WordDictionary) do
				if string.match(string.lower(text2), string.lower(v[1])) then
					corrected = true
					faults = faults + 1
					text = string.Replace(text, v[1], v[2])
					if ply.DarkRPVars != nil then
						RunConsoleCommand("say", "/ooc [SPELL-O-BOT] Did you mean '" .. v[2] .. "'?")
					else
						RunConsoleCommand("say", "[SPELL-O-BOT] Did you mean '" .. v[2] .. "'?")
					end
				end
			end
		end

		if corrected then
			timer.Simple(0.8, function()
				if ply.DarkRPVars != nil then
					RunConsoleCommand("say", "/ooc  [SPELL-O-BOT] There were " .. faults .. " faults in the sentence.")
				else
					RunConsoleCommand("say", "[SPELL-O-BOT] There were " ..  faults .. " faults in the sentence.")
				end
			end)
		end
	end

	if (MFSP.Util.ModConVarEnabled(Mod, "enabled")) then
		local name = "Console"
		local namecolor = Color(128, 128, 255)
		local staticname = ""

		if (ply:IsValid()) then
			name = ply:Nick()
			namecolor = team.GetColor(ply:Team())

			if ply.staticname != nil then
				if ply.staticname != "" then
					staticname = ply.staticname
					isStatic = true
				end
			end
		end

		if staticname != "" then
			if isTeam then
				if isDead then
					chat.AddText(Color(255, 0, 0), "*DEAD* ", Color(128, 128, 128), "(TEAM) ", namecolor, name, Color(255, 255, 255), " (", Color(0, 255, 0), staticname, Color(255, 255, 255), ")", Color(255, 255, 255), ": ", Color(255, 255, 255), text)
				else
					chat.AddText(Color(128, 128, 128), "(TEAM) ", namecolor, name, Color(255, 255, 255), " (", Color(0, 255, 0), staticname, Color(255, 255, 255), ")", Color(255, 255, 255), ": ", Color(255, 255, 255), text)
				end
			elseif isDead and !isTeam then
				chat.AddText(Color(255, 0, 0), "*DEAD* ", namecolor, name, Color(255, 255, 255), " (", Color(0, 255, 0), staticname, Color(255, 255, 255), ")", Color(255, 255, 255), ": ", Color(255, 255, 255), text)
			else
				chat.AddText(namecolor, name, Color(255, 255, 255), " (", Color(0, 255, 0), staticname, Color(255, 255, 255), ")", Color(255, 255, 255), ": ", Color(255, 255, 255), text)
			end
		else
			if isTeam then
				if isDead then
					chat.AddText(Color(255, 0, 0), "*DEAD* ", Color(128, 128, 128), "(TEAM) ", namecolor, name, Color(255, 255, 255), ": ", Color(255, 255, 255), text)
				else
					chat.AddText(Color(128, 128, 128), "(TEAM) ", namecolor, name, Color(255, 255, 255), ": ", Color(255, 255, 255), text)
				end
			elseif isDead and !isTeam then
				chat.AddText(Color(255, 0, 0), "*DEAD* ", namecolor, name, Color(255, 255, 255), ": ", Color(255, 255, 255), text)
			else
				chat.AddText(namecolor, name, Color(255, 255, 255), ": ", Color(255, 255, 255), text)
			end
		end
	end
end)