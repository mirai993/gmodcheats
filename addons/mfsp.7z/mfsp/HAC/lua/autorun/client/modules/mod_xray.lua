--[[
	autorun/client/modules/mod_xray.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local XRayEnts = {}
local XRayEntTypes = {
	{class = "player", color = Color(0, 255, 0)},
	{class = "prop", color = Color(255, 0, 0)},
	{class = "npc_", color = Color(0, 0, 255)},
	{class = "spawned_", color = Color(255, 255, 0)},
	{class = "door", color = Color(255, 0, 0)}
}

local Mod = MFSPModule("X-Ray")
MFSP.Util.SetConVarToggle(Mod, "xray", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.IsEnabled["SPEffects"] = true
	Mod.HasConfig = true

function MFSP.Util.AddXRayEntity(ent)
	if ent and ent:IsValid() then
		table.insert(XRayEnts, ent)
	end
	if #XRayEnts > MFSP.Util.GetModValue(Mod, "maxents") then
		if XRayEnts[1] != nil then
			if XRayEnts[1] and XRayEnts[1]:IsValid() then
				XRayEnts[1]:SetNoDraw(false)
			end
		end
		table.remove(XRayEnts, 1)
	end
end

CreateClientConVar("mfsp_xray_showdata", "1", true, false)
	
function Mod:Draw()
	if GetConVar("mfsp_xray_showdata"):GetBool() then
		surface.SetDrawColor(Color(0, 0, 0, 128))
		surface.DrawRect(5, 5, 180, 20)
		surface.SetFont("DefaultFixed")
		if #XRayEnts < MFSP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(0, 255, 0, 255))
		elseif #XRayEnts == MFSP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(255, 255, 0, 255))
		elseif #XRayEnts > MFSP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(255, 0, 0, 255))
		end
		surface.SetTextPos(10, 10)
		surface.DrawText("XRay entity count: " .. #XRayEnts .. "/" .. MFSP.Util.GetModValue(Mod, "maxents"))
	end
	if MFSP.Util.ModConVarEnabled(Mod, "drawlines") then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				local pos = EyePos()
				local ang = EyeAngles()

				if MFSP.Data.LastSpawnedProp != nil then
					if MFSP.Data.LastSpawnedProp and MFSP.Data.LastSpawnedProp:IsValid() then
						if MFSP.Data.IsViewingProp then
							pos = MFSP.Data.LastSpawnedProp:GetPos()
						end
					end
				end

				cam.Start3D(pos, ang)
					render.SetMaterial(Material("cable/blue_elec"))
					render.DrawBeam(v:GetShootPos(), v:GetEyeTrace().HitPos, 5, 1, 1, Color(255, 255, 255, 255))
					render.SetMaterial(Material("cable/hydra"))
					local t = {}
						t.start = v:GetShootPos()
						t.endpos = v:GetShootPos() + Vector(0, 0, 99999999)
						t.filter = v
					local trace = util.TraceLine(t)
					render.DrawBeam(trace.HitPos, v:GetShootPos(), 15, 1, 1, Color(255, 255, 255, 255))
				cam.End3D()
			end
		end
	end
end

function Mod:SPEffects()
	if MFSP.Util.IsConVarEnabled(Mod) then
		if #XRayEnts <= 0 then
			RunConsoleCommand("rope_rendersolid", "1")
			table.Empty(XRayEnts)
			if not MFSP.Util.ModConVarEnabled(Mod, "onlyspawnedprops") then
				MFSP.Util.InitXRayEnts()
			else
				MFSP.Util.InitXRayEnts()
			end
		end
	end
	for k, v in pairs(XRayEnts) do
		if v and v:IsValid() then
			for _, ent in pairs(XRayEntTypes) do
				if string.match(v:GetClass(), ent.class) then
					local renderit = true
					if v:IsPlayer() then
						if not v:Alive() then renderit = false end
					end
					if not MFSP.Util.ModConVarEnabled(Mod, "drawdoors") then
						if string.match(v:GetClass(), "door") then
							renderit = false
						end
					end
					if not MFSP.Util.ModConVarEnabled(Mod, "drawplayers") then
						if v:IsPlayer() then
							renderit = false
						end
					end
					if not MFSP.Util.ModConVarEnabled(Mod, "drawnpcs") then
						if string.match(v:GetClass(), "npc") then
							renderit = false
						end
					end
					if not MFSP.Util.ModConVarEnabled(Mod, "drawprops") then
						if string.match(v:GetClass(), "prop") then
							renderit = false
						end
					end
					if renderit then
						local pos = EyePos()
						local ang = EyeAngles()

						if MFSP.Data.LastSpawnedProp != nil then
							if MFSP.Data.LastSpawnedProp and MFSP.Data.LastSpawnedProp:IsValid() then
								if MFSP.Data.IsViewingProp then
									pos = MFSP.Data.LastSpawnedProp:GetPos()
								end
							end
						end

						cam.Start3D(pos, ang)
							cam.IgnoreZ(true)
								render.SuppressEngineLighting(true)
								if MFSP.Util.ModConVarEnabled(Mod, "custommaterial") then
									SetMaterialOverride(Material("models/shiny"))
									v:SetNoDraw(true)
								end
								if MFSP.Util.ModConVarEnabled(Mod, "customcolor") then
									render.SetColorModulation(ent.color.r, ent.color.g, ent.color.b, 128)
									render.SetBlend(0.5)
									v:SetNoDraw(true)
								end
								v:DrawModel()
								render.SetBlend(0)
								SetMaterialOverride(nil)
								render.SetColorModulation(nil)
								render.SuppressEngineLighting(false)
							cam.IgnoreZ(false)
						cam.End3D()
					end
				end
			end
		else
			table.remove(XRayEnts, k)
		end
	end
end

function MFSP.Util.InitXRayEnts()
	XRayEnts = {}
	table.Empty(XRayEnts)
	for k, v in pairs(ents.GetAll()) do
		for _, str in pairs(XRayEntTypes) do
			if string.match(string.lower(v:GetClass()), string.lower(str.class)) then
				MFSP.Util.AddXRayEntity(v)
			end
		end
	end
end

hook.Add("Think", "MFSP.XRay.OnTurnedOff", function()
	if not MFSP.Util.IsConVarEnabled(Mod) then
		if #XRayEnts > 0 then
			RunConsoleCommand("rope_rendersolid", "1")
			surface.PlaySound("items/nvg_off.wav")
			for k, v in pairs(XRayEnts) do
				v:SetNoDraw(false)
			end
			table.Empty(XRayEnts)
		end
	end
end)

hook.Add("OnEntityCreated", "MFSP.XRay.AddXRayEntity", function(ent)
	if MFSP.Util.IsConVarEnabled(Mod) then
		for _, str in pairs(XRayEntTypes) do
			if ent and ent:IsValid() then
				if string.match(string.lower(ent:GetClass()), string.lower(str.class)) then
					MFSP.Util.AddXRayEntity(ent)
				end
			end
		end
	end
end)

MFSP.Util.AddCFGCheckBox(Mod, "Enable XRay", "enabled")
MFSP.Util.AddCFGSlider(Mod, "Max XRay Entities", "maxents", 250, 10, 1000)
MFSP.Util.AddCFGCheckBox(Mod, "Custom Material", "custommaterial", 0)
MFSP.Util.AddCFGCheckBox(Mod, "Custom Color", "customcolor", 1)
MFSP.Util.AddCFGCheckBox(Mod, "Draw Doors", "drawdoors", 1)
MFSP.Util.AddCFGCheckBox(Mod, "Draw Players", "drawplayers", 0)
MFSP.Util.AddCFGCheckBox(Mod, "Draw Props", "drawprops", 1)
MFSP.Util.AddCFGCheckBox(Mod, "Draw NPCs", "drawnpcs", 1)
MFSP.Util.AddCFGCheckBox(Mod, "Only Spawned Props", "onlyspawnedprops", 0)
MFSP.Util.AddCFGCheckBox(Mod, "Tracer Lines", "drawlines", 1)

concommand.Add("mfsp_xray", function()
	if GetConVar("mfsp_xray_enabled"):GetBool() then
		RunConsoleCommand("mfsp_xray_enabled", "0")
	else
		RunConsoleCommand("mfsp_xray_enabled", "1")
	end
end)