--[[
	autorun/client/mfsp_reloader.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local function ReloadScripts()
	if MFSP != nil then
		if MFSP.Data.Detectors != nil then
			for k, v in pairs(MFSP.Data.Detectors) do
				if v.entity != nil then
					v.entity:Remove()
				end
			end
		end
	end
	include('autorun/client/mfsp_init.lua')
end

concommand.Add("mfsp_reload", ReloadScripts)