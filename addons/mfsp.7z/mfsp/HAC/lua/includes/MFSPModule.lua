--[[
	includes/MFSPModule.lua
	/FL-TPK\ Static | (STEAM_0:1:11736063)
	===DStream===
]]

local t = {}
local m = {}
	t.__index = m

function MFSPModule(title)
	local object = {}
		object.Title = title or "Unknown"
		object.ConVar = ""
		object.Think = function() end
		object.Draw = function() end
		object.SPEffects = function() end
		object.IsEnabled = {Think = false, Draw = false, RenderScene = false}
		object.HasConfig = false
	setmetatable(object, t)
	MFSP.Util.AddModule(object)
	return object
end