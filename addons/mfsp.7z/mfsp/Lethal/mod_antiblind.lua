
/*
	ULX (Removing the actual hook)
	However, the ULX anti-blind will always be active,
	you CANNOT turn off anti blinding if you had it on before,
	Unless you reload the scripts.
*/
CreateClientConVar("fls_antiblind", "1", false, true)

local umh = usermessage.Hook
function usermessage.Hook(name, func)
	if GetConVar("fls_antiblind"):GetInt() == 1 then
		if name != "ulx_blind" then
			umh(name, func)
		end
	else
		umh(name, func)
	end
end

function ANTI_BLIND()
	if GetConVar("fls_antiblind"):GetInt() == 1 then
		/* Evolve */
		if LocalPlayer():GetNWBool("EV_Blinded") then
			LocalPlayer():SetNWBool("EV_Blinded", false)
		end
	end
end

hook.Add("Tick", "AntiBlind", ANTI_BLIND)