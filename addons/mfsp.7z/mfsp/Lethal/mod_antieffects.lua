function ANTI_EFFECTS()
	if GetConVar("fls_antieffects"):GetInt() == 1 then
		for k, v in pairs(ents.GetAll()) do
			if v:GetClass() == "env_sprite" or v:GetClass() == "info_decal" then
				v:SetMaterial("models/props_c17/fisheyelens")
			end
		end
	end
end

CreateClientConVar("fls_antieffects", "0", false, true)

hook.Add("Think", "AntiFX", ANTI_EFFECTS)