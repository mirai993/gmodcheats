/*-------------------------------------------------------------------------------
	Nospread module, SE module, and SV bypass module
	AKA
	Deco, Herpes, and Cvar2 lol
*/-------------------------------------------------------------------------------
require("MichaelJFox")
//require("beingSEissuffering") AKA HERPES
require("bypass")
/*-------------------------------------------------------------------------------
	Print
*/-------------------------------------------------------------------------------
Msg( " \n" )
Msg( "i removed the ascii here because it was broken and there's no point in having it, it looked like shit." )
Msg( "\n" )