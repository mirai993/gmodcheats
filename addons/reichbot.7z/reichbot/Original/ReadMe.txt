 _____      _      _     ____        _   
|  __ \    (_)    | |   |  _ \      | |  
| |__) |___ _  ___| |__ | |_) | ___ | |_ 
|  _  // _ \ |/ __| '_ \|  _ < / _ \| __|
| | \ \  __/ | (__| | | | |_) | (_) | |_ 
|_|  \_\___|_|\___|_| |_|____/ \___/ \__|
ReichBot Private v3.0 by p0mf
This is all C+P, credits to all the people I stole code from.

	RabidToaster
	fr1kin
	hasser
	Yes!
	Seth
	BlueKirby
	GD

There's probably more


+rb_menu for menu.

rb_cheats -> sv_cheat bypass.
rb_consistency -> sv_consistency bypass.
rb_hldj -> sv_allow_voice_from_file bypass which lets you use HLDJ again.

There's also quite a few other features/variables that aren't in the menu but they either shouldn't be changed or
wasn't possible to be done in a menu.
This goes in your lua folder.

Steam\steamapps\accountname\garrysmod\garrysmod\lua\

I recommend deleting everything that already exists in your lua folder to prevent FPS fuckery and other issues.