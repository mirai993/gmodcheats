--[[
	MOD/lua/entities2/Lasers.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:11PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()
table.insert(MB.files, debug.getinfo(function() end, "S").short_src)
local function IsPlayerVisible(ply)
    if not IsValid(ply) then return false end
	local plyPos, _ = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1") or 12)
	local traceRes = {
        start = LocalPlayer():EyePos(),
        endpos = plyPos,
        filter = LocalPlayer()
    }
    local trace = util.TraceLine(traceRes)
    if trace.Entity and trace.Entity == ply then return true end
    return false
end
MB.AddHook("HUDPaint", function()
    local a = {["x"] = ScrW() / 2, ["y"] = ScrH() / 2}
    for k,v in pairs(player.GetAll()) do
        if MB.MESPCheck(v) then
            local b = v:GetPos():ToScreen()
            if b.x <= ScrW() and b.y <= ScrH() then
                surface.SetDrawColor(IsPlayerVisible(v) and Color(0,255,0,150) or Color(255,0,0,150))
                surface.DrawLine(a.x, a.y, b.x, b.y)
            end
        end
    end
end)
