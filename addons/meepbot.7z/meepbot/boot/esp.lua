--[[
	MOD/lua/entities2/ESP.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:10PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()

table.insert(MB.files, debug.getinfo(function() end, "S").short_src)

function MB.GetLivingPlayers()
    local pplalive = {}
    local ppl = player.GetAll()
    for i = 1, #ppl do
        if IsValid(ppl[i]) and ppl[i]:Alive() and ppl[i]:Health() > 0 then
            table.insert(pplalive,ppl[i])
        end
    end
    return pplalive
end

MB.AddHook("PreDrawHalos", function()
    if not MB.meep then return end
    halo.Add(MB.GetLivingPlayers(), Color(255,100,50,255), 4, 4, 2, false, true)
end)
