--[[
	MOD/lua/entities2/NewAimbot.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:11PM]
	===BadFile===
]]

--Based off of Blue Kirby's code
--Source: http://bluekirbygmod.googlecode.com/svn/trunk/Blue Bot/blue_bot.lua
--TODO: Friends and enemies list with modes
local MB = originallol.GetValueLol()
MB.aimangles = Angle(0,0,0)
local function GetLivingPlayers()
    local pplalive = {}
    local ppl = player.GetAll()
    for i = 1, #ppl do
        if IsValid(ppl[i]) and ppl[i]:Alive() and ppl[i]:Health() > 0 then
            table.insert(pplalive,ppl[i])
        end
    end
    return pplalive
end
local function IsPlayerVisible(ply)
    if not IsValid(ply) then return false end
	local plyPos, _ = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1") or 12)
	local traceRes = {
        start = LocalPlayer():EyePos(),
        endpos = plyPos,
        filter = LocalPlayer()
    }
    local trace = util.TraceLine(traceRes)
    if trace.Entity and trace.Entity == ply then return true end
    return false
end
local function ClosestLP2PAngle(plys)
    local bestAngDif = false
    local bestAng = false
    local bestAngPly = false
    for i = 1, #plys do
        local ply = plys[i]
        if ply and IsValid(ply) and ply:Health() > 0 and ply:Alive() and IsPlayerVisible(ply) then
            local plyPos, _= ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1") or 11)
            local ang = (plyPos - LocalPlayer():GetShootPos()):Angle()
            local LocalPlayerAng = GetValueLol(pw, "nospread") and LocalPlayer():Health() > 0 and GetValueLol(pw, "curangles") or LocalPlayer():EyeAngles()
            if ang and LocalPlayerAng then
                local angDifY = math.abs(math.AngleDifference(ang.y, LocalPlayerAng.y))
                local angDifP = math.abs(math.AngleDifference(ang.p, LocalPlayerAng.p))
                local angDif = angDifP + angDifY
                if not bestAng or bestAngDif > angDif then
                    bestAng = ang
                    bestAngDif = angDif
                    bestAngPly = ply
                end
            end
        end
    end
    return bestAng, bestAngDif, bestAngPly
end
local function aimbot()
    if not SetValueLol then return end
    local oang = EyeAngles()
    local ang, dif, ply = ClosestLP2PAngle(GetLivingPlayers())
    MB.aimangles = ang
    if not MB.aim then return end
    if LocalPlayer():Health() < 1 then MB.aim = false; return end
    if not (ang and dif) or dif > MB.aimdif then MB.aimoff = true; return end
    MB.aimoff = false
    MB.targ = ply
    LocalPlayer():SetEyeAngles(ang)
end
MB.AddHook("Think", aimbot)
MB.AddHotKey("AimbotToggle", "KEY_UP", function() MB.ToChat(not MB.aim) MB.aim = not MB.aim end)
