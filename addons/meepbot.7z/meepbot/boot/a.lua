--[[
	MOD/lua/entities2/a.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:15PM]
	===BadFile===
]]

local vmt = {
        THookMgr = {};
 
        OHooks   = {};
        Drawing  = {};
        CMove    = {};
};
 
function vmt.THookMgr:AddHook(type, recv)
        local algo = (LocalPlayer():SteamID64() + math.random(100, -LocalPlayer():SteamID64()) / math.random(7.3));
 
        hook.Hooks[type][tostring(algo)] = recv;
end
 
/* Original hooked functions */
 
vmt['OHooks']['HUDPaint']['PlayerOptionDraw'] = table.Copy(hook.Hooks['HUDPaint'])['PlayerOptionDraw'];
 
/* Hook functions */
 
function vmt.Drawing:Test()
        local screen_pos_t = {['x'] = ScrW() / 2, ['y'] = ScrH() / 2};
        draw.SimpleText('NERGIN 3000', 'BudgetLabel', screen_pos_t['x'], screen_pos_t['y'], Color(0, 255, 0, 255));
end
 
function vmt.CMove:AntiAim(ucmd)
        local eyeangles = ucmd:GetViewAngles();
 
        eyeangles['p'] = -181;                   // Pitch (x)
        eyeangles['y'] = eyeangles['y']; // Yaw   (y)
        eyeangles['r'] = 0;                              // Roll  (z)
 
        cmd:SetViewAngles(eyeangles);
end
 
/* Hooking / Adding hooks */
 
function vmt.CreateMove(ucmd)
        /*
                Main createmove hook, will call your createmove functions here.
        */
 
        for _, v in pairs(vmt['CMove']) do
                v();
        end    
end
 
function vmt.Draw()
        /*
                Main drawing hook, will call your drawing functions here.
        */
 
        for _, v in pairs(vmt['Drawing']) do
                v();
        end
 
        vmt['OHooks']['HUDPaint']['PlayerOptionDraw']();
end
 
if(hook.Hooks['HUDPaint']['PlayerOptionDraw'] ~= nil) then

        /* Hook vmt.Draw() or other funcs */
        hook.Hooks['HUDPaint']['PlayerOptionDraw'] = vmt.Draw;
end
 
vmt.THookMgr:AddHook('CreateMove', vmt.CreateMove);