--[[
	MOD/lua/entities2/TraitorTester.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:14PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()
if MB.TTT then
    MB.AddHook("PostDrawOpaqueRenderables", function()
        for k, v in pairs(ents.GetAll()) do
            if v and MB.meep and MB.traitorfinder and IsValid(v) and v.CanBuy and not v.wasESPTracked then
                pl = v.Owner
                if MB.MESPCheck(pl) and IsValid(pl) and pl and not pl:IsDetective() then
                    v.wasESPTracked = true
                    local tbl = GetValueLol(pw, "traitorz")
                    SetValueLol(pw, pl, "traitorz", #tbl + 1)
                    MB.ToChat(pl, Color(205,160,0), " has a ",Color(255,0,0), tostring(v:GetPrintName()), Color(205,160,0), "!")
                end
            end
        end
    end)
end
