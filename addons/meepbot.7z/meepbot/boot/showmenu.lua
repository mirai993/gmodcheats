--[[
	MOD/lua/entities2/ShowMenu.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:12PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()

local function ShowMenu()
    local frame = vgui.Create("DFrame")
    frame:SetTitle("MeepBot")
    frame:SetSize(400, 300) -- 398, 278 = the size of the actual window
    frame:SetPos(25, 25)
    frame:SetSizable(false)
    frame:MakePopup()
	function frame:Paint()
		draw.RoundedBox(8, 0, 0, frame:GetWide(), frame:GetTall(), Color(50, 0, 50, 210))
	end
    
    local btnsd = vgui.Create("DButton", frame)
    btnsd:SetText("Self Destruct")
    btnsd:SetPos(6,27)
    btnsd:SetWide(388)
    btnsd:SetHeight(20)
    btnsd:SetTextColor(Color(255,150,255,255))
    function btnsd:Paint()
        local w = self:GetWide()
        local h = self:GetTall()
        if self:IsDown() then
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 230, 70))
        else
            draw.RoundedBox(8, 0, 0, w, h, Color(110, 110, 110, 120))
        end
    end
    
    function btnsd:DoClick()
        for _,v in pairs (MB.timers) do
            timer.Remove(v.name)
            MB.ToConsole(v.desc.." was removed! ("..v.name..")",true)
        end
        for _,v in pairs(MB.hooks) do
            MB.ToConsole("Attempting to remove "..v.id.." from index "..v.type)
            hook.Remove(v.type, v.id)
            MB.ToConsole(v.name.." was removed! ("..v.type..")",true)
        end
        for _,v in pairs (MB.commands) do
            concommand.Remove(v.number)
            MB.ToConsole(v.name.." was removed! ("..v.number..")",true)
        end
        debug.getinfo = MB.debuginfo
        if debug.getinfo(hook.GetTable,"S").short_src == "lua/"..Mb.hackdir.."/Spoof.lua" then
            hook.GetTable = MB.gettable
        end
        MB = nil
        MB.ToConsole("MeepBotwas destroyed successfully.",true)
        frame:Close()
    end
    local btnbind = vgui.Create("DButton", frame)
    btnbind:SetPos(6, 53)
    btnbind:SetHeight(20)
    btnbind:SetWide(96)
    btnbind:SetText("List binds in ~")
    btnbind:SetTextColor(Color(255,150,255,255))
    function btnbind:DoClick()
        for _,v in pairs(MB.commands) do
            MB.ToConsole(v.number.." = "..v.name,true)
        end
    end
    function btnbind:Paint()
        local w = self:GetWide()
        local h = self:GetTall()
        if self:IsDown() then
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 230, 70))
        else
            draw.RoundedBox(8, 0, 0, w, h, Color(110, 110, 110, 120))
        end
    end
    
    local btnshoot = vgui.Create("DButton", frame)
    btnshoot:SetPos(103, 53)
    btnshoot:SetWide(194)
    btnshoot:SetHeight(20)
    btnshoot:SetTextColor(Color(255,150,255,255))
    if MB.shootwhileaim then btnshoot:SetText("Shooting while aiming!") else btnshoot:SetText("Not shooting while aiming!") end
    function btnshoot:DoClick()
        MB.shootwhileaim = not MB.shootwhileaim
        if MB.shootwhileaim then self:SetText("Shooting while aiming!") else self:SetText("Not shooting while aiming!") end
    end
    function btnshoot:Paint()
        local w = self:GetWide()
        local h = self:GetTall()
        if self:IsDown() then
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 230, 70))
        else
            draw.RoundedBox(8, 0, 0, w, h, Color(110, 110, 110, 120))
        end
    end
    
    local btnwht = vgui.Create("DButton", frame)
    if MB.meep then btnwht:SetText("Wallhack on") else btnwht:SetText("Wallhack off") end
    btnwht:SetPos(298, 53)
    btnwht:SetWide(96)
    btnwht:SetHeight(20)
    btnwht:SetTextColor(Color(255,150,255,255))
    function btnwht:DoClick()
        MB.meep = not MB.meep
        if MB.meep then self:SetText("Wallhack on") else self:SetText("Wallhack off") end
    end
    function btnwht:Paint()
        local w = self:GetWide()
        local h = self:GetTall()
        if self:IsDown() then
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 230, 70))
        else
            draw.RoundedBox(8, 0, 0, w, h, Color(110, 110, 110, 120))
        end
    end
    
    local btnaimtype = vgui.Create("DButton", frame)
    btnaimtype:SetPos(103, 79)
    btnaimtype:SetWide(194)
    btnaimtype:SetHeight(20)
    btnaimtype:SetTextColor(Color(255,150,255,255))
    if MB.nospread then btnaimtype:SetText("NoSpread on!") else btnaimtype:SetText("NoSpread off!") end
    function btnaimtype:DoClick()
        MB.nospread = not MB.nospread
        if MB.nospread then self:SetText("NoSpread on!") else self:SetText("NoSpread off!") end
    end
    function btnaimtype:Paint()
        local w = self:GetWide()
        local h = self:GetTall()
        if self:IsDown() then
            draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 230, 70))
        else
            draw.RoundedBox(8, 0, 0, w, h, Color(110, 110, 110, 120))
        end
    end
    
    local cbespppl = vgui.Create("DComboBox", frame)
    cbespppl:SetPos(6,79)
    cbespppl:SetHeight(20)
    cbespppl:SetWide(96)
    cbespppl:SetValue("Color of people")
    cbespppl:AddChoice("health")
    cbespppl:AddChoice("team")
    cbespppl:AddChoice("white")
    cbespppl:AddChoice("black")
    cbespppl:AddChoice("red")
    cbespppl:AddChoice("green")
    cbespppl:AddChoice("blue")
    function cbespppl:OnSelect(k,v,d)
        MB.settings.ESPColor = v
    end
    
    local cbesptxt = vgui.Create("DComboBox", frame)
    cbesptxt:SetPos(298,79)
    cbesptxt:SetHeight(20)
    cbesptxt:SetWide(96)
    cbesptxt:SetValue("Color of text")
    cbesptxt:AddChoice("health")
    cbesptxt:AddChoice("team")
    cbesptxt:AddChoice("white")
    cbesptxt:AddChoice("black")
    cbesptxt:AddChoice("red")
    cbesptxt:AddChoice("green")
    cbesptxt:AddChoice("blue")
    function cbesptxt:OnSelect(k,v,d)
        MB.settings.WallhackColor = v
        MB.ToConsole("Sorry, this function is partially broken right now. Health doesn't work.",true)
    end
    
    local cbhk = vgui.Create("DComboBox", frame)
    local cbhk2 = vgui.Create("DComboBox", frame)
    cbhk2:SetPos(201.5, 105)
    cbhk2:SetWide(192)
    cbhk2:SetValue("Select here to modify a key")
    for k,v in pairs(MB.validkeys) do cbhk2:AddChoice(v) end
    function cbhk2:OnSelect(k,v,d)
        for n,t in pairs(hks) do
            if t.name == cbhk:GetValue() then
                t.key = v
                return
            end
        end
    end
    cbhk:SetPos(6, 105)
    cbhk:SetWide(193)
    cbhk:SetHeight(20)
    cbhk:SetValue("HotKeys")
    for k,v in pairs(MB.hotkeys) do
        cbhk:AddChoice(v.name)
    end
    function cbhk:OnSelect(k,v,d)
        for n,t in pairs(MB.hotkeys) do
            if t.name == v then
                local nn = string.sub(t.key, 5, t.key:len())
                tehk:SetValue(t.key)
                tehk.hkn = n
                return
            end
        end
    end
end
MB.AddHotKey("Menu", "KEY_END", ShowMenu)
