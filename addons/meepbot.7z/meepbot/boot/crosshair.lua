--[[
	MOD/lua/entities2/Crosshair.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:09PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()

MB.AddHook("HUDPaint", function()
    if not MB.ch then return end
    local h = ScrH() / 2
    local w = ScrW() / 2
    local ah = 7
    local aw = 15
    local bh = ah - 2
    local bw = aw - 2
    surface.SetDrawColor(0,0,0,40)
    surface.DrawRect(w - aw + 1, h - ah + 1, aw * 2 - 1, ah * 2)
    surface.DrawRect(w - ah + 1, h - aw + 1, ah * 2 - 1, aw * 2)
    
    surface.SetDrawColor(255,255,255,40)
    surface.DrawRect(w - bw + 1, h - bh + 1, bw * 2 - 1, bh * 2)
    surface.DrawRect(w - bh + 1, h - bw + 1, bh * 2 - 1, bw * 2)
end)