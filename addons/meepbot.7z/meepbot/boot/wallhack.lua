--[[
	MOD/lua/entities2/Wallhack.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:14PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()
MB.settings = {}
MB.AddHook("HUDPaint", function()
    local lp = MB.lp()
    local trace = util.GetPlayerTrace(lp)
    local traceRes = util.TraceLine(trace)
    if traceRes.HitNonWorld then
        local target = traceRes.Entity
        draw.DrawText(target:GetClass(),"BudgetLabel", 30, ScrH() / 2 + 15,Color(255,255,255,255))
    end
    local numspec = 0
    for k,v in pairs(player.GetAll()) do
        if v:GetObserverTarget() == lp then
            numspec = numspec + 1
        end
    end
    if numspec < 1 then
        numspec = "No one is"
    end
    draw.DrawText(numspec.." spectating you","Font111", 30, ScrH() / 2 + 30,Color(255,0,255,255))
    if MB.meep then
        cam.Start2D()
        if MB.DRP then
            for k,v in pairs (ents.GetAll()) do
                if string.find(string.lower(v:GetClass()),"money") and MB.DRP then
                    local pos = v:GetPos():ToScreen()
                    local x, y = pos.x, pos.y
                    draw.DrawText(tostring(v:GetClass()), "BudgetLabel",x, y, Color(100,150,125,255), TEXT_ALIGN_CENTER)
                elseif string.find(string.lower(tostring(v:GetClass())),"shipment") and MB.DRP then
                    local pos = v:GetPos():ToScreen()
                    local x, y = pos.x, pos.y
                    local ct = v:Getcontents() or ""
                    local cts = CustomShipments[ct] or ""
                    local ctsn = cts.name
                    draw.DrawText(tostring(v:GetClass()..(": "..ctsn.."; Amount: "..v:Getcount() or "")),"BudgetLabel",x,y,Color(100,150,125,255),TEXT_ALIGN_CENTER)
                end
            end
        end
        for k,v in pairs (player.GetAll()) do
            if MB.MESPCheck(v) then
                local Position = v:GetPos():ToScreen()
                local name = v:Name()
                local isadmin = v:IsAdmin() or false
                local issuperadmin = v:IsSuperAdmin() or false
                local text = ""
                if issuperadmin then text = "[SuperAdmin]\n"..name.."\n" elseif isadmin then text = "[Admin]\n"..name.."\n" else text = "\n"..name.."\n" end
                local extra = ""
                local color = Color(0,0,0,255)
                if MB.TTT then
                    if v:IsDetective() then 
                        extra = "Detective"
                    elseif table.HasValue(MB.traitorz,v) then
                        extra = "Traitor"
                    else
                        extra = "Innocent"
                    end
                elseif MB.DRP then
                    extra = tostring(team.GetName(v:Team()))
                end
                color = MB.settings.WallhackColor == "team" and 
                 (MB.TTT and 
                  (v:IsDetective() and Color(0,0,255,255) 
                   or table.HasValue(MB.traitorz, v) and Color(255,0,0,255)
                    or Color(0,255,0,255)
                  )
                  or team.GetColor(v:Team())
                 )
                  or MB.settings.WallhackColor == "health" and Color(math.min(255,v:Health()*2.55-255),math.min(255,v:Health()*2.55),0,255)
                   or MB.settings.WallhackColor == "red" and Color(255,0,0,255)
                    or MB.settings.WallhackColor == "green" and Color(0,255,0,255)
                     or MB.settings.WallhackColor == "blue" and Color(0,0,255,255) 
                      or MB.settings.WallhackColor == "white" and Color(255,255,255,255) 
                       or Color(0,0,0,255) 
                draw.DrawText(text..extra, "BudgetLabel", Position.x, Position.y, color, 1)
            end
        end
        cam.End2D()
    end
end)