--[[
	MOD/lua/entities2/Spoof.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:13PM]
	===BadFile===
]]

--This is as good as it will get in lua.
local MB = originallol.GetValueLol()
timer.Simple(0.01, function()
    MB.SpoofInit = true
    function hook.GetTable()
        local customhooks = MB.hooks
        local oldhooks = MB.gettable()
        if customhooks and oldhooks then
            local returnval = oldhooks
            for k,v in pairs(customhooks) do
                if oldhooks[v.type][v.name] then
                    local aval = {}
                    local question = false
                    for index,value in pairs(returnval[v.type]) do
                        if index ~= v.name then
                            aval[index] = value
                            question = true
                        end
                    end
                    if not question then aval = nil end
                    returnval[v.type] = aval
                end
            end
            return returnval
        else
            return MB.gettable()
        end
    end
    function GetConVar(str)
        if string.lower(str) == "sv_allowcslua" or string.lower(str) == "sv_cheats" then
            return {
                GetBool = function() return false end,
                GetInt = function() return 0 end,
                GetFloat = function() return 0.0 end,
                GetString = function() return "0" end,
                MetaID=27,
                MetaName="ConVar"
            }
        end
        return MB.getconvar(str)
    end
    local function GetFileNames()
        local tbl = {}
        for k,v in pairs(MB.gettable()) do
            for k2,v2 in pairs(v) do 
                local t = debug.getinfo(v2,"S").short_src
                table.insert(tbl,t)
            end
        end
        return tbl
    end
    MB.fakefiles = GetFileNames()
    function debug.getinfo(func, str)
        if string.lower(str) == "s" then
            if table.HasValue(MB.files, MB.debuginfo(func,str).short_src) then
                local tbl = MB.fakefiles
                return {
                    ["short_src"] = tbl[math.random(1,#tbl)],
                    ["linedefined"] = math.random(1,50),
                    ["lastlinedefined"] = math.random(1,50)
                }
            end
        end
        return MB.debuginfo(func,str)
    end
end)
