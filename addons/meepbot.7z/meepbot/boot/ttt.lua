--[[
	MOD/lua/entities2/TTT.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:13PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()
if not MB.TTT then return end
MB.AddHook("TTTPrepareRound",function()
    MB.traitorfinder = false
    MB.targ = nil
end)
MB.AddHook("TTTBeginRound",function()
    MB.traitorfinder = true
    MB.traitorz = {}
    MB.deadpplz = {}
end)