--[[
	MOD/lua/entities2/Debug.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:09PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()