--[[
	MOD/lua/entities2/BonJovi.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:08PM]
	===BadFile===
]]

--I'M WAAAAAAAAAAAAAAAANTED... dead or a-live!
local MB = originallol.GetValueLol()

MB.AddHook("Think",function()
	for _,v in pairs(player.GetAll()) do
        if not v:Alive() and v:Health() < 1 and not v:IsNPC() and v:IsPlayer() then
            if not table.HasValue(MB.deadpplz,v) then
                table.insert(MB.deadpplz,v)
                MB.ToChat(v:Name().." died somehow!")
            end
        else
            for k,v2 in pairs (MB.deadpplz) do
                if v2 == v then
                    table.remove(MB.deadpplz,k)
                end
            end
        end
    end
end)