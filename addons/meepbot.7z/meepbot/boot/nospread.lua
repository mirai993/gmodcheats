--[[
	MOD/lua/entities2/Nospread.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:33:12PM]
	===BadFile===
]]

local MB = originallol.GetValueLol()

table.insert(MB.files, debug.getinfo(function() end, "S").short_src)

timer.Simple(0.01, function()
    if not file.Exists("lua/bin/gmcl_theebirdistheeword_win32.dll", "GAME") then MB.Chat("Module missing - skipping nospread.") return end
    require("theebirdistheeword")
    function MB.GetCone(wep) --shitty funktione, Make another way because I am not going to release the good way.
        local a = wep.Cone 
                   or wep.Primary and wep.Primary.Cone 
                    or 0
        return type(a) == "number" and Vector(-a, -a, -a)
                or a
    end
     
    function MB.PredictSpread(cmd, ang)
        local vecCone = MB.GetCone(LocalPlayer():GetActiveWeapon())
        return DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), ang:Forward(), vecCone):Angle()
    end
    local angles = EyeAngles()
    local curangle = EyeAngles()
    --  3.040 3.142 0.000 cone = 0.09
    --  original - (cone * 33.7777777) = real
    MB.aimangles = EyeAngles()
    function MB.cv(ply, origin, angles, FOV, a, b)
        local wep = ply:GetActiveWeapon()
        if wep.Primary then wep.Primary.Recoil = 0 end
        if wep.Secondary then wep.Secondary.Recoil = 0 end
        --this is local angles
        angles = MB.aim and not MB.aimoff and MB.nospread and MB.aimangles or angles
        if MB.lp():GetObserverMode() ~= OBS_MODE_NONE then return end
        
        local viewangle = angles
        local a = -MB.GetCone(wep).y
        local b = -MB.GetCone(wep).p
        viewangle.p = curangle.p - (a * 65)
        viewangle.y = curangle.y - (b * 55)
        
        local view = {}
        view.origin = origin
        view.angles = viewangle
        view.fov = fov
        if not MB.nospread or not LocalPlayer():Alive() or LocalPlayer():Health() < 1 then 
            return view
        end
    end
    MB.AddHook("CalcView", cv)

    MB.curangles = Angle(0,0,0)
    function MB.cm(ucmd)
        angles = MB.aim and not MB.aimoff and MB.aimangles or angles
        angles.p = math.NormalizeAngle(angles.p)
        angles.y = math.NormalizeAngle(angles.y)
       
        local correct = 1
        angles.y = math.NormalizeAngle(angles.y + (ucmd:GetMouseX() * -0.022 * correct))
        angles.p = math.Clamp(angles.p + (ucmd:GetMouseY() * 0.022 * correct), -89, 90)
       
        local ang = MB.PredictSpread(ucmd, angles)
        ang.p = math.NormalizeAngle(ang.p)
        ang.y = math.NormalizeAngle(ang.y)
        curangle = ang
        MB.curangles = ang
        ucmd:SetViewAngles(curangle)
    end

    MB.AddHook("CreateMove", MB.cm)
    
    MB.AddHotKey("Toggle Nospread", "KEY_PAGEDOWN", function()
        if MB.nospread then
            MB.AddHook("CreateMove", MB.cm)
            MB.AddHook("CalcView", MB.cv)
        else
            for k,v in pairs(MB.gettable()) do
                if t[v.type][v.name] == MB.cm or t[v.type][v.name] == MB.cv then hook.Remove(v.type, v.name) end
            end
        end
        MB.nospread = not MB.nospread
    end)
end)
