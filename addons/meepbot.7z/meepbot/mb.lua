--[[
	MOD/lua/mb.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:32:56PM]
	===BadFile===
]]

local vmt = {
        THookMgr = {};
 
        OHooks   = {HUDPaint = {}};
        Drawing  = {};
        CMove    = {};
};
 
function vmt.THookMgr:AddHook(type, recv)
        local algo = (LocalPlayer():SteamID64() + math.random(100, -LocalPlayer():SteamID64()) / math.random(7.3));
        hook['Add'](type, tostring(algo), recv);
end
 
/* Original hooked functions */
 
vmt['OHooks']['HUDPaint']['PlayerOptionDraw'] = table.Copy(hook.Hooks['HUDPaint'])['PlayerOptionDraw'];
 
/* Hook functions */
 
function vmt.Drawing:Test()
        local screen_pos_t = {['x'] = 3, ['y'] = 1};
        draw.SimpleText('PENGUINHACK 0.01', 'BudgetLabel', screen_pos_t['x'], screen_pos_t['y'], Color(25, 172, 235, 255));
end
function vmt.Drawing:ESP()
    for _,v in pairs(player.GetAll()) do
        if (v ~= LocalPlayer()) then
            local pos = v:EyePos():ToScreen();
            draw.SimpleText(v:Nick(), 'BudgetLabel', pos.x, pos.y, Color(25,172,235,255));
            draw.SimpleText('Health:'..v:Health(), 'BudgetLabel', pos.x, pos.y - 15, Color(25,172,235,255));
        end
    end
end
 
/* Hooking / Adding hooks */
 
function vmt.CreateMove(ucmd)
        --[[
                Main createmove hook, do createmove stuff here
        ]]
 
        local eyeangles = ucmd:GetViewAngles();
 --[[
        eyeangles['p'] = -181;                   // Pitch (x)
        eyeangles['y'] = eyeangles['y']; // Yaw   (y)
        eyeangles['r'] = 0;                              // Roll  (z)
 
        ucmd:SetViewAngles(eyeangles);]]
end
 
function vmt.Draw()
        /*
                Main drawing hook, will call your drawing functions here.
        */
 
        for _, v in pairs(vmt['Drawing']) do
                v();
        end
end
 
vmt.THookMgr:AddHook('HUDPaint', vmt.Draw);
 
vmt.THookMgr:AddHook('CreateMove', vmt.CreateMove);