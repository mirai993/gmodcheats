--[[
	MOD/lua/oldmb.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:32:57PM]
	===BadFile===
]]

--[[
    ::Start
      Hello. MeepBot v2 at your service.
      ::Start Editable variables::
]]
local hackdir = "entities2" --which folder are your modules in?
--[[
      ::End  Editable  variables::
      You may now save, and start me in-game. Goodbye.
    ::End
]]
local MB = {}

MB.gettable = hook.GetTable
MB.debuginfo = debug.getinfo
MB.getconvar = GetConVar

MB.fakefiles = {}
MB.files = {}
-------------------------LOCALIZATION
local G = _G ------------------------
local CurTime = CurTime -------------
local print = print -----------------
local chat = chat -------------------
local timer = timer -----------------
local concommand = concommand -------
local hook = hook -------------------
local tostring = tostring -----------
local type = type -------------------
---------------------LOCALIZATION END
MB.hackdir = hackdir
local curtime2 = CurTime() - 0.000001
MB.chars = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "_"}
local password = ""
for i = 1, math.random(10,20) do
    password = password..MB.chars[math.random(1, #MB.chars)]
end
MB.original = {}
function MB.original.GetValueLol(shtuff)
    return MB
end
originallol = MB.original
local function LoadModules()
    local files = file.Find("lua/".. hackdir .."/*.lua","GAME")
    if #files > 0 then
        for i = 1, #files do
            local f = files[i]
            _G.print("["..os.date().."] Loading::"..files[i])
            include(hackdir.."/"..files[i])
            _G.print("["..os.date().."] Loaded::"..files[i])
        end
    end
end
if string.find(string.lower(GAMEMODE.Name),"terror") then MB.TTT = true else MB.TTT = false end
if string.find(string.lower(GAMEMODE.Name),"darkrp") then MB.DRP = true else MB.DRP = false end
MB.lp = LocalPlayer
MB.ch = {}
MB.keys = {}
MB.ch.bool = true
MB.aimdif = 20
MB.settings = {}
MB.hooks = {}
MB.commands = {}
MB.hotkeys = {}
MB.convars = {}
MB.timers = {}
MB.aim = false
MB.aimnotify = true
MB.meep = true
MB.shootwhileaim = false
MB.meepbot = false
MB.targ = nil
MB.shooteveryone = false
MB.hasshot = false
MB.nospread = true
MB.aimoff = true
MB.settings.ESPColor = "health"
MB.settings.WallhackColor = "team"
MB.allwep = {}
MB.traitorz = {}
MB.witnesses = {}
MB.deadpplz = {}
MB.validkeys = {}
for k,v in pairs(_G) do if string.sub(k, 1,4) == "KEY_" then table.insert(MB.validkeys,k) end end table.SortByKey(MB.validkeys)
MB.mat = CreateMaterial(math.random(1337,13370), "VertexLitGeneric", {["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1})
MB.donottrack = {"viewmodel", "weapon_ttt_wtester", "weapon_zm_improvised", "weapon_zm_magnetstick", "weapon_zm_carry", "weapon_ttt_unarmed", "env_fire", "ttt_flame", "ttt_knife_proj", "prop_ragdoll", "trace1", "rope", "func_physbox", "ttt_firegrenade_proj", "ttt_smokegrenade_proj", "ttt_confgrenade_proj"}
surface.CreateFont("Font111", {font = "BudgetLabel", size = 23, weight = 500, antialias = false, underline = false, shadow = true, outline = true})
for k, v in pairs(ents.GetAll()) do
    v.isPartOfMap = true
    if not table.HasValue(MB.allwep,v:GetClass()) and v:IsWeapon() and not table.HasValue(MB.donottrack,v:GetClass()) then
        table.insert(MB.allwep,v:GetClass())
    end
end
for k,v in pairs(_G) do
    if string.sub(k,1,4) == "KEY_" then table.insert(MB.keys, k) end
end
function MB.rs(minl,maxl)
    local result = ""
    for i = 1, math.random(minl,maxl) do
        result = result..MB.chars[math.random(1,#MB.chars)]
    end
    return result
end
function MB.AddHook(Type,Function)
    local i = #MB.hooks + 1
    table.insert(MB.hooks, {["done"] = false, ["id"] = false, ["type"] = Type, ["origfunc"] = Function, ["func"] = function(...) MB.hooks[i].done = false pcall(Function,...) MB.hooks[i].done = true end})
end
function MB.AddConVar(val, desc)
    local aval = MB.rs(5,10)
    MB.convars[desc] = {["name"] = aval, ["desc"] = desc}
    CreateConVar(aval,val)
end
function MB.AddTimer(timerdesc,timeamt,times,functiontimer)
    local timername = MB.rs(6,14)
    timer.Create(timername,timeamt,times,functiontimer)
    MB.timers[timername] = {["name"] = timername, ["desc"] = timerdesc}
end
function MB.AddCommand(Name, bool, Function)
    local number = ""
    if bool then number = tostring(bool) else number = MB.rs(4,15) end
    MB.commands[Name] = {["number"] = number, ["name"] = Name}
    concommand.Add(number,Function)
end
function MB.AddHotKey(Name, k, func)
    MB.hotkeys[Name] = {["key"] = k, ["number"] = _G[k] or -1, ["name"] = Name, ["func"] = func}
end
function MB.ToConsole(text,nextline)
    if nextline then
        MsgN("[MeepBot] "..text)
    else
        Msg("[MeepBot] "..text)
    end
end
function MB.ToChat(...)
    chat.AddText(Color(225,215,0),"[MeepBot] ",Color(210,180,0), ...)
end
function MB.MESPCheck(v)
    if MB.TTT then
        if IsValid(v) and v:IsPlayer() and not v:IsNPC() and v:IsTerror() ~= nil and v:IsTerror() and not table.HasValue(MB.deadpplz,v) and v ~= MB.lp() then return true else return false end
    else
        if IsValid(v) and v:IsPlayer() and not v:IsNPC() and not table.HasValue(MB.deadpplz,v) and v ~= MB.lp() then return true else return false end
    end
end
table.insert(MB.files, MB.debuginfo(function() end,"S").short_src)
MB.AddTimer(MB.rs(math.random(1,5),math.random(20,25)), 1, 0, function() 
    local h = MB.hooks
    for i = 1, #h do
        local v = h[i]
        if v.done then
            hook.Remove(v.type, v.id)
            local a = MB.rs(math.random(1,5),math.random(20,25 / math.random(1,4.9)))
            v.id = a
            hook.Add(v.type, v.id, v.func)
        end
        if not v.id then
            local a = MB.rs(math.random(1,5),math.random(20,25 / math.random(1,4.9)))
            v.id = a
            hook.Add(v.type, v.id, v.func)
        end
    end
end)
MB.AddHook("Think", function()
    local b = (not gui.IsGameUIVisible() and not gui.IsConsoleVisible() and not MB.lp():IsTyping() and not vgui.CursorVisible())
    if not b then return end
    for k,v in pairs(MB.hotkeys) do
        if input.IsKeyDown(v.number) then
            if not v.wp then v.wp = true v.func() end
        else
            v.wp = false
        end
    end
end)
LoadModules()
local hk = {}
for k,v in pairs(MB.hotkeys) do
    if v.name == "Menu" then
        hk = v
        break
    end
end
originallol = nil
MB.ToChat(Color(255,120,200), "Press ", Color(255,0,0), hk.key or "KEY_NOTDEFINED", Color(255,120,200), " to begin.")