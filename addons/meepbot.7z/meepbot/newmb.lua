--[[
	MOD/lua/newmb.lua
	[Ӻ.ɧ] MeepDarknessMeep | (STEAM_0:0:68219133) | [04-08-13 07:32:57PM]
	===BadFile===
]]

gameevent.Listen('player_hurt');

local vmt = {
        THookMgr = {};
        THotKeyMgr = {['keys'] = {}, ['validkeys'] = {}, ['Functions'] = {}};
        
        HookTable = hook.Hooks;
        Functions = {};
        Cones = {};
        Hooks = {['HUDPaint'] = {}, ['Think'] = {}, ['TTTBeginRound'] = {}, ['CalcView'] = {}, ['player_hurt'] = {}, ['CreateMove'] = {}};
        UMHooks = {};
};

/* Core Functions */

for k,v in pairs(_G) do if string.sub(k, 1,4) == "KEY_" then table.insert(vmt.THotKeyMgr.validkeys,k) end end

function vmt.THookMgr:GetULibHooks()
    for i = 1, debug.getinfo(hook.Add, 'u').nups do
        local up = {};
        up['name'], up['value'] = debug['getupvalue'](hook.Add, i);
        if up['name'] == 'Hooks' then
            return up['value'];
        end
    end
end

if (ULib) then vmt.HookTable = vmt.THookMgr:GetULibHooks() end

function vmt.Functions.Rapid(cmd)
        if (LocalPlayer():KeyDown(IN_ATTACK)) then
                cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)));
        end        
end
 
function vmt.THookMgr:AddHook(type, recv)
        local game = gmod.GetGamemode();
        local old_func = game and game[type] or false;
        if (vmt.HookTable) then 
                if (vmt.HookTable[type]) then
                        local n = tostring(LocalPlayer():SteamID64() + math.random(100, -LocalPlayer():SteamID64()) / math.random(7.3));
                        if (ULib) then
                                local ht = vmt.HookTable[type]
                                ht[#ht + 1] = {['name'] = n, ['priority'] = 0, ['fn'] = recv};
                        else
                            local ht = vmt.HookTable[type]
                            ht[n] = recv
                        end
                else
                        vmt.HookTable[type] = {};
                        local n = tostring(LocalPlayer():SteamID64() + math.random(100, -LocalPlayer():SteamID64()) / math.random(7.3));
                        if (ULib) then
                                vmt.HookTable[type][1] = {['name'] = n, ['priority'] = 0, ['fn'] = recv};
                        else 
                                vmt.HookTable[type][n] = recv
                        end
                end

        elseif (old_func) then
                game[type] = function(...) old_func(...) recv(...) end;
        else
                local algo = (LocalPlayer():SteamID64() + math.random(100, -LocalPlayer():SteamID64()) / math.random(7.3));
                hook['Add'](type, tostring(algo), recv);
        end
end

function vmt.THotKeyMgr.Functions.AddHotKey(Name, k, func)
    vmt.THotKeyMgr.keys[Name] = {["key"] = k, ["number"] = _G[k] or -1, ["name"] = Name, ["func"] = func}
end

function vmt.THookMgr:AddUMHook(n, func)
        vmt.UMHooks[n] = func;
end

do
        local oldumim = usermessage.IncomingMessage;
        function usermessage.IncomingMessage(n, um)
                oldumim(n, um);
                if (vmt.UMHooks[n]) then
                        vmt.UMHooks[n]();
                end
        end
end

do
        local oldhookcall = hook.Call;
        function hook.Call(n, gm, ...)
                if (not gmod.GetGamemode()[n] and vmt.Hooks[n]) then 
                        for k,v in pairs(vmt.Hooks[n]) do
                                v(false, ...);
                        end
                        if (n == 'player_hurt') then return; end
                end
                return oldhookcall(n, gm, ...);
        end
end

do
        vmt.NoSpread = false
        if file.Exists('lua/bin/gmcl_theebirdistheewird_win32.dll', 'GAME') then
                require 'theebirdistheewird'
                vmt.NoSpread = true
                vmt.MShot = DS_manipulateShot
                vmt.md5 = DS_md5PseudoRandom
                vmt.CMDNum = DS_getUCMDCommandNumber
        end
        print(vmt.NoSpread)
end

/* Hook functions helpers */

do
        local tbl = FindMetaTable("Player").MetaBaseClass;
        local fb = tbl.FireBullets;
        function tbl.FireBullets(self, tbl)
                local class = self:GetActiveWeapon():GetClass();
                if (not vmt.Cones[class]) then
                        vmt.Cones[class] = -tbl.Spread;
                end
                fb(self, tbl);
        end
end

function vmt.Functions.GetBestAttachment(ply)
        local atts = ply:GetAttachments();
        local tblatts = {};
        for i = 1, #atts do
                local att = atts[i];
                if (att['name'] == 'eyes') then
                        table.insert(tblatts, 1, att.id);
                elseif (att['name'] == 'lefthand') then
                        table.insert(tblatts, 4, att.id);
                elseif att['name'] == 'mouth' then
                        table.insert(tblatts, 2, att.id);
                elseif att['name'] == 'chest' then
                        table.insert(tblatts, 3, att.id);
                end
        end
        for _, id in pairs(tblatts) do
                return id
        end
        return 1
end

function vmt.Functions.NoSpread(cmd, ang, wep)
        if not vmt.NoSpread then return false, ang end
        if not IsValid(wep) then return false, ang end
        local class = wep:GetClass();
        if not vmt.Cones[class] then return false, ang end
        return vmt.MShot(vmt.md5(vmt.CMDNum(cmd)), ang:Forward(), vmt.Cones[class]):Angle();
end

/* Hook functions */

 --[[ HUDPaint ]]--
 
function vmt.Hooks.HUDPaint:Watermark()
        local screen_pos_t = {['x'] = 3, ['y'] = 1};
        draw.SimpleText('PENGUINHACK 0.07', 'BudgetLabel', screen_pos_t['x'], screen_pos_t['y'], Color(25, 172, 235, 255));
end

function vmt.Hooks.HUDPaint:Wallhax()
        for _, v in pairs(player.GetAll()) do
                if (v ~= LocalPlayer() and v:Health() > 0 and v:Alive() and v:GetObserverMode() == OBS_MODE_NONE) then
                        surface.SetFont('BudgetLabel');
                        local pos = v:EyePos():ToScreen();
                        local text_w, text_h = surface.GetTextSize(v.Nick and v:Nick() or 'Entity:Nick() = nil');
                        draw.SimpleText(v.Nick and v:Nick() or 'Entity:Nick() = nil', 'BudgetLabel', pos['x'] - text_w / 2, pos['y'] - (text_h - 5) * 3, Color(25,172,235,255));
                        local text_w, text_h = surface.GetTextSize(v.Health and 'Health: '..v:Health() or '');
                        draw.SimpleText(v.Health and 'Health: '..v:Health() or '', 'BudgetLabel', pos['x'] - text_w / 2, pos['y'] - (text_h - 5) * 2, Color(25,172,235,255));
                        local wep = v:GetActiveWeapon() or false;
                        local wep_name = wep and IsValid(wep) and ((wep.GetPrintName and wep:GetPrintName()) or (wep.GetClass and wep:GetClass()) or (false)) or false;
                        if (wep) then
                                local text_w, text_h = surface.GetTextSize(wep_name and 'Holding: '..wep_name or '');
                                draw.SimpleText(wep_name and 'Holding: '..wep_name or '', 'BudgetLabel', pos['x'] - text_w / 2, pos['y'] - (text_h - 5) * 1, Color(25,172,235,255));
                        end
                        local text_w, text_h = surface.GetTextSize('Distance: '..LocalPlayer():GetPos():Distance(v:GetPos()) or '');
                        draw.SimpleText('Distance: '..LocalPlayer():GetPos():Distance(v:GetPos()) or '', 'BudgetLabel', pos['x'] - text_w / 2, pos['y'] - (text_h - 5) * 0, Color(25,172,235,255));
                end
        end
end

--[[ Think ]]--

function vmt.Hooks.Think:Stuff()
    local b = (not gui.IsGameUIVisible() and not gui.IsConsoleVisible() and not LocalPlayer():IsTyping() and not vgui.CursorVisible())
    if not b then return end
    for k,v in pairs(vmt.THotKeyMgr.keys) do
        if input.IsKeyDown(v.number) then
            if not v.wp then v.wp = true v.func() end
        else
            v.wp = false
        end
    end
end

 --[[ TTT ]]--

function vmt.Hooks.TTTBeginRound:Null()
end

--[[ Death Events ]]--

function vmt.Hooks.player_hurt:DeathNotifications(data)
        if data.health > 0 then return end
        local attacker;
        local ply;
        for k,v in pairs(player.GetAll()) do
                if (v:UserID() == data.userid) then
                        ply = v;
                end
                if (v:UserID() == data.attacker) then
                        attacker = v;
                end
        end
        if (ply and IsValid(ply) and attacker and IsValid(attacker)) then
               MsgN(attacker:Nick().." killed "..ply:Nick());
        end
end

--[[ CreateMove Event ]]--

function vmt.Hooks.CreateMove:TriggerBot(cmd)
        if (LocalPlayer():Health() < 1 or not LocalPlayer():Alive() or LocalPlayer():GetObserverMode() ~= OBS_MODE_NONE or not vmt.TriggerOn) then return end
        local scr_x = ScrW() / 2;
        local scr_y = ScrH() / 2;
        local plys = player.GetAll();
        for i = 1, #plys do
                local ply = plys[i];
                local trace_r = util.TraceLine({['start'] = LocalPlayer():GetShootPos(), ['endpos'] = ply:GetPos(), ['filter'] = LocalPlayer()})
                if (IsValid(ply) and ply:Health() > 0 and ply:GetObserverMode() == OBS_MODE_NONE and ply:Alive() and trace_r.Entity and IsValid(trace_r.Entity)) then
                        local ply_pos = ply:GetAttachment(vmt.Function.GetBestAttachment(ply)).Pos:ToScreen();
                        if (math.abs(ply_pos.x - scr_x) < 10 and math.abs(ply_pos.y - scr_y) < 15) then
                                local n = (ply:GetAttachment(ply:LookupAttachment('eyes')).Pos - LocalPlayer():GetShootPos()):Angle();
                                local ns = vmt.Functions.NoSpread(cmd, n, LocalPlayer():GetActiveWeapon());
                                if (ns) then
                                        local e = EyeAngles();
                                        LocalPlayer():SetEyeAngles(e);
                                        cmd:SetViewAngles(ns);
                                end
                                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK));
                                break;
                        end
                end
        end
end

vmt.OEAngles = false
local old = {['time'] = CurTime(), ['time2'] = CurTime()}
local tobool = util.tobool

function vmt.Hooks.CreateMove:Aimbot(cmd)
        if (LocalPlayer():Health() > 0 and LocalPlayer():GetObserverMode() ~= OBS_MODE_NONE or not vmt.AimbotOn) then return end
        local o1 = CurTime() - old['time'];
        local o2 = old['time'] - old['time2'];
        o2 = tobool(o2) and o2 or 0.005;
        o1 = tobool(o1) and o1 or 0.005;
        local lpvel = util.tobool(old[LocalPlayer()]) and (old[LocalPlayer()] - LocalPlayer():EyePos()) * (1 + (o1 / o2)) or LocalPlayer():GetVelocity();
        old[LocalPlayer()] = LocalPlayer():EyePos();
        local plys = player.GetAll();
        local b = false
        for i = 1, #plys do
                local ply = plys[i]; 
                local p = ply:EyeAngles().p
                local w = p < 90 and p > -90 and ply:GetAttachment(vmt.Functions.GetBestAttachment(ply)).Pos or ply:LocalToWorld(ply:OBBCenter());
                local realvel = util.tobool(old[ply]) and (old[ply] - w) * (1 + (o1 / o2)) or ply:GetVelocity();
                old[ply] = w;
                local lping = util.tobool(LocalPlayer():Ping()) and LocalPlayer():Ping() or 45
                local v = (w) - (lpvel / (lping * 1000)) + (realvel / (lping * 1000));
                local trace_r = util.TraceLine({['start'] = LocalPlayer():GetShootPos() - (lpvel / (lping * 1000)), ['endpos'] = v, ['filter'] = {LocalPlayer(), ply}, ['mask'] = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER});
                if (IsValid(ply) and ply:Alive() and ply:Health() > 0 and ply ~= LocalPlayer() and ply:GetObserverMode() == OBS_MODE_NONE and (not trace_r['Hit'] or trace_r['Entity'] == ply)) then
                        local n = (v - LocalPlayer():GetShootPos()):Angle();
                        local ns, bang = vmt.Functions.NoSpread(cmd, n, LocalPlayer():GetActiveWeapon());
                        local rang = vmt.AAOn and
                                      (ns and Angle(-ns.p - 181, ns.y - 180, 180) or bang and Angle(bang.p - 181, bang.y - 180, -181))
                                     or ns 
                                     or bang;
                        cmd:SetViewAngles(rang);
                        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK));
                        vmt.Functions.Rapid(cmd);
                        b = true
                end
        end
        vmt.Aiming = b               
        old['time2'] = old['time']
        old['time'] = CurTime()
end

vmt.AAOn = false

function vmt.Hooks.CreateMove:AntiAim(cmd)
        vmt.OEAngles = cmd:GetViewAngles();
        if (not vmt.AAOn) then cmd:SetViewAngles(Angle(vmt.OEAngles.p, vmt.OEAngles.y, 0)) return end
        vmt.OEAngles = Angle(-181, vmt.OEAngles.y, -181);
        cmd:SetViewAngles(vmt.OEAngles);
end

vmt.Aiming = false
vmt.SpinOn = false

function vmt.Hooks.CreateMove:Spin(cmd)
        if (vmt.Aiming  or not vmt.SpinOn) then return end
        local e = cmd:GetViewAngles();
        cmd:SetViewAngles(Angle(e.p, math.NormalizeAngle(e.y - 20), e.r));
end

--[[ CalcView ]]--

/* Adding hooks */

for k,_ in pairs(vmt.Hooks) do
    local func = function(...)
        for _,v in pairs(vmt.Hooks[k]) do
            v(v, ...);
        end
    end
    vmt.THookMgr:AddHook(k, func);
end

/* Adding hotkeys */

vmt.AimbotOn = false
vmt.THotKeyMgr.Functions.AddHotKey("Toggle Aimbot", "KEY_END", function() vmt.AimbotOn = not vmt.AimbotOn chat.AddText(Color(255,125,50), 'I will now '..(vmt.AimbotOn and '' or 'not ')..'aimbot') end)
vmt.THotKeyMgr.Functions.AddHotKey("Toggle triggerbot", "KEY_PAGEDOWN", function() vmt.TriggerOn = not vmt.TriggerOn chat.AddText(Color(255,125,50), 'I will now '..(vmt.TriggerOn and '' or 'not ')..'triggerbot') end)
vmt.THotKeyMgr.Functions.AddHotKey("Toggle AntiAim", "KEY_UP", function() vmt.AAOn = not vmt.AAOn chat.AddText(Color(255,125,50), 'I will now '..(vmt.AAOn and '' or 'not ')..'antiaim') end)
vmt.THotKeyMgr.Functions.AddHotKey("Toggle Spin", "KEY_DOWN", function() vmt.SpinOn = not vmt.SpinOn chat.AddText(Color(255,125,50), 'I will now '..(vmt.SpinOn and '' or 'not ')..'spin') end)