--[[
	MOD/lua/mine/fgtnoise.lua [#547 (#570), 62297056, UID:2520367767]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:54AM]
	===BadFile===
]]

local function FastUndo()
	hook.Add("Think", "fgtfastundo", function()
		RunConsoleCommand("impulse", "100")
	end)	
end
concommand.Add("+fgtmakesound", FastUndo)

local function UndoFastUndo()
	hook.Remove( "Think", "fastundo")
end
concommand.Add("-fgtmakesound", UndoFastUndo)

local bool = false
local function fastsound()
	bool = not bool
	if bool then
		hook.Add("Think", "fgtfastsound", function()
			RunConsoleCommand("impulse", "100")
		end)	
	else 
		hook.Remove( "Think", "fgtfastsound")
	end
end
concommand.Add("fgtmakesound", fastsound)