--[[
	MOD/lua/mine/noafk.lua [#956 (#996), 1677611689, UID:3232643341]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:57AM]
	===BadFile===
]]

local oneTwo = false
local preventAfk = false

local function moveAround()
	if oneTwo then
		RunConsoleCommand( "+jump" )
		RunConsoleCommand( "+forward" )
		RunConsoleCommand( "+right" )
		RunConsoleCommand( "+attack" )
		timer.Simple( 0.5, function()
			RunConsoleCommand( "-jump" )
			RunConsoleCommand( "-forward" )
			RunConsoleCommand( "-right" )
			RunConsoleCommand( "-attack" )
			oneTwo = !oneTwo
		end )
	else
		RunConsoleCommand( "+jump" )
		RunConsoleCommand( "+back" )
		RunConsoleCommand( "+left" )
		RunConsoleCommand( "+attack" )
		timer.Simple( 0.5, function()
			RunConsoleCommand( "-jump" )
			RunConsoleCommand( "-back" )
			RunConsoleCommand( "-left" )
			RunConsoleCommand( "-attack" )
			oneTwo = !oneTwo
		end )
	end
end

local function runLoop()
	if preventAfk then moveAround() end
	timer.Simple( 1, runLoop )
end

timer.Simple( 1, runLoop )

concommand.Add( "fgtnoafk", function( ply, cmd, args )
	preventAfk = !preventAfk
end )