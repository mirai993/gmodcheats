--[[
	MOD/lua/mine/fgtzoom.lua [#3110 (#3204), 3841378849, UID:1956941240]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:56AM]
	===BadFile===
]]

local FalcoZoom = false
local ZoomHowMuch = 1
local ZoomStep = 5
local Extrazoom = 0
local OldSensitivity = GetConVarString("sensitivity")
local CurrentSensitivity = -1

hook.Add( "AdjustMouseSensitivity", "FgtZoomSens", function( defaultSens )
	if( FalcoZoom ) then
		return CurrentSensitivity
	else
		return -1
	end
end )

local function ZoomCalcThing(ply, origin, angles, fov)
	if FalcoZoom then
		local view = {} 
		view.origin = ply:GetShootPos() - LocalPlayer():GetAimVector():Angle():Forward() * - Extrazoom
		view.angles = LocalPlayer():EyeAngles() 
		view.fov = ZoomHowMuch
		
		return view
	end
end
hook.Add("CalcView", "FgtZoomCalcThing", ZoomCalcThing) 

local function ChangeSensitivity()
	if Extrazoom > 99 and Extrazoom < 1000 then
		--LocalPlayer():ConCommand("sensitivity " .. tostring(1 -(((90 - ZoomHowMuch) + (Extrazoom/1000)) / 100)))
		CurrentSensitivity = (1 -(((90 - ZoomHowMuch) + (Extrazoom/1000)) / 100))
	elseif Extrazoom > 999 and Extrazoom < 10000 then
		--LocalPlayer():ConCommand("sensitivity " .. tostring( 1 -(((90 - ZoomHowMuch) + (Extrazoom/10000)) / 100)))
		CurrentSensitivity = (1 -(((90 - ZoomHowMuch) + (Extrazoom/10000)) / 100))
	elseif Extrazoom > 9999 then 
		--LocalPlayer():ConCommand("sensitivity " .. "0.01")
		CurrentSensitivity = 0.01
	elseif Extrazoom < 99 then 
		--LocalPlayer():ConCommand("sensitivity " .. tostring(1 -(((90 - ZoomHowMuch) + (Extrazoom/100)) / 100)))
		CurrentSensitivity = (1 -(((90 - ZoomHowMuch) + (Extrazoom/100)) / 100))
	end
end

local function FZoomToggle(ply, cmd)
	if cmd == "+fzoom" then
		if Extrazoom > 0 then
			ChangeSensitivity()
			LocalPlayer():EmitSound("npc/sniper/reload1.wav")
		else
			LocalPlayer():EmitSound("weapons/sniper/sniper_zoomin.wav")
			ChangeSensitivity()
		end
	else
		--LocalPlayer():ConCommand("sensitivity " .. OldSensitivity)
		CurrentSensitivity = -1
	end
	FalcoZoom = not FalcoZoom
end
concommand.Add("+fzoom", FZoomToggle)
concommand.Add("-fzoom", FZoomToggle)

local function ChangeZoomStuff( ply, bnd, pressed )
	if FalcoZoom and pressed then
		if string.find(bnd, "invprev") and pressed then 
			if ZoomHowMuch > 1 then
				ZoomHowMuch = ZoomHowMuch - ZoomStep
				ChangeSensitivity()
				LocalPlayer():EmitSound("weapons/sniper/sniper_zoomin.wav")
			else
				Extrazoom = Extrazoom + ZoomStep*200
				ChangeSensitivity()
				LocalPlayer():EmitSound("npc/sniper/reload1.wav")
			end
			return true
		elseif string.find(bnd, "invnext") and pressed then
			if ZoomHowMuch < 90 and Extrazoom > 0  then
				Extrazoom = Extrazoom - ZoomStep*200
				ChangeSensitivity()
				LocalPlayer():EmitSound("npc/scanner/cbot_servoscared.wav")
			elseif ZoomHowMuch < 90 and Extrazoom == 0 then
				ZoomHowMuch = ZoomHowMuch + ZoomStep
				ChangeSensitivity()
				LocalPlayer():EmitSound("weapons/sniper/sniper_zoomout.wav")
			end
			return true
		elseif string.find(bnd, "reload") and pressed then
			ZoomHowMuch = 11
			Extrazoom = 0
			ChangeSensitivity()
			LocalPlayer():EmitSound("npc/sniper/reload1.wav")
			return true
		end
	end
end
hook.Add("PlayerBindPress", "FgtChangeZoomStuff", ChangeZoomStuff)