--[[
	MOD/lua/mine/fgtxr.lua [#2635 (#2709), 2338094699, UID:3907680158]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:56AM]
	===BadFile===
]]

RayOn = false
local AllMats = {}
local allcolors = {}
local debugRegistry = debug.getregistry()
local FSetColor = debugRegistry.Entity.SetColor
local FSetMat = debugRegistry.Entity.SetMaterial
local FSetRend = debugRegistry.Entity.SetRenderMode
local shouldFullbright = false
function TogglePoKiRay()
	if RayOn then
		surface.PlaySound("buttons/button19.wav")
		shouldFullbright = false
		for k,v in pairs(ents.GetAll()) do
			FSetMat(v, AllMats[v])
			--print(allcolors[v])
			local z = allcolors[v]
			if type(allcolors[v]) == "number" then print(v, v:GetClass()) end
			FSetColor(v, z)
		end
	else
		shouldFullbright = true
		for k,v in pairs(ents.GetAll()) do
			allcolors[v] = v:GetColor()
		end
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("FgtToggleRay", TogglePoKiRay)

function DoPoKiRay()
	if shouldFullbright then
		render.SetLightingMode( 2 )
	end
	if not RayOn then return end
	for k,v in pairs(ents.GetAll()) do
		local col = v:GetColor()
		local r, g, b, a = col.r, col.g, col.b, col.a
		if v:IsPlayer() and (r ~= 255 or g ~= 0 or b ~= 0 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, Color(255,0,0,255))
		elseif v:IsNPC() and (r ~= 0 or g ~= 255 or b ~= 0 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			--print(allcolors[v])
			FSetColor(v, Color(0, 255, 0, 255))
		elseif v:GetClass() == "prop_physics" and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 70) then
			allcolors[v] = Color(r,g,b,a)
			FSetRend(v, RENDERMODE_TRANSALPHA )
			FSetColor(v, Color(0, 0, 255, 70))
		elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, Color(140, 0, 255, 255))
		elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
			allcolors[v] = Color(r,g,b,a)
			FSetRend(v, RENDERMODE_TRANSALPHA )
			FSetColor(v, Color(0, 0, 0, 30))
		elseif not v:IsPlayer() and not v:IsNPC() and v:GetClass() ~= "prop_physics" and v:GetClass() ~= "env_sprite" and not v:IsWeapon()
		  and v:GetClass() ~= "viewmodel" and string.Left(v:GetClass(),7) ~= "class C" and( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then -- Don't touch clientside ents.
			allcolors[v] = Color(r,g,b,a)
			FSetRend(v, RENDERMODE_TRANSALPHA )
			FSetColor(v, Color(255, 200, 0, 100))
		end
		if v:GetClass() ~= "viewmodel" and v:GetMaterial() ~= "PoKiRayMat" then
			AllMats[v] = v:GetMaterial()
			FSetMat(v, "PoKiRayMat")
		end
	end
end
hook.Add( "RenderScene", "FgtPoKiRay", DoPoKiRay)

hook.Add( "PreDrawHUD", "FgtPoKiNoBright", function()
	if shouldFullbright then
		render.SetLightingMode( 0 )
	end
end )