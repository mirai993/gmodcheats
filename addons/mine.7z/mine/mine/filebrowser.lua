--[[
	MOD/lua/mine/filebrowser.lua [#484 (#500), 3631952077, UID:563182086]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:57AM]
	===BadFile===
]]

concommand.Add( "fgt_browser", function()
	local MainPanel = vgui.Create( "DFrame" )
		MainPanel:SetSize( 600, 600 )
		MainPanel:Center()
		MainPanel:SetTitle( "File Browser" )
		MainPanel:SetVisible( true )
		MainPanel:SetDraggable( true )
		MainPanel:ShowCloseButton( true )
		
	local browser = vgui.Create( "DFileBrowser", MainPanel )
		browser:SetPos( 5, 25 )
		browser:SetSize( 590, 590 )
		browser:SetName( "Browser" )
		browser:SetPath( "lua/" )
		
	MainPanel:MakePopup()
end )