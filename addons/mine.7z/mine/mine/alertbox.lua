--[[
	MOD/lua/mine/alertbox.lua [#2104 (#2172), 4112137943, UID:3072281101]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:53AM]
	===BadFile===
]]

local pointOne = nil
local pointTwo = nil
local foundPlayers = {} -- playerEntity, currentlyInsideAlertArea

concommand.Add("fgt_alertremove", function(ply, cmd, args)
	pointOne = nil
	pointTwo = nil
end )

concommand.Add("fgt_alert", function(ply, cmd, args)
	if ((not pointOne) and (not pointTwo)) then
		pointOne = LocalPlayer():GetEyeTrace().HitPos
	elseif pointOne and (not pointTwo) then
		notification.AddLegacy( "Alert box created.", NOTIFY_HINT, 3 )
		pointTwo = LocalPlayer():GetEyeTrace().HitPos
	else
		pointOne = LocalPlayer():GetEyeTrace().HitPos
		pointTwo = nil
	end
end )

hook.Add("Tick", "FgtAlertTick", function()
	if( (not pointOne) or (not pointTwo) ) then return end
	local foundEnts = ents.FindInBox( pointOne, pointTwo )

	local currentPlayers = {}
	for _, foundEnt in pairs( foundEnts ) do -- Create a table full of all the found players
		if( foundEnt:IsPlayer() ) then
			if( foundEnt ~= LocalPlayer() ) then
				table.insert( currentPlayers, foundEnt )
			end
		end
	end

	for foundPlayer, currentlyIn in pairs( foundPlayers ) do -- Set all the players found last tick to false
		foundPlayers[ foundPlayer ] = false
	end

	for _, foundPlayer in pairs( currentPlayers ) do
		if( foundPlayers[ foundPlayer ] == nil ) then
			notification.AddLegacy( foundPlayer:Nick() .. " has entered the alert area!", NOTIFY_ERROR, 6 )
			nextFlag = true
		end
		foundPlayers[ foundPlayer ] = true
	end

	for foundPlayer, currentlyIn in pairs( foundPlayers ) do
		if( currentlyIn == false ) then
			PrintTable( foundEnts )
			--notification.AddLegacy( foundPlayer:Nick() .. " has exited the alert area.", NOTIFY_HINT, 6 )
			foundPlayers[ foundPlayer ] = nil
		end
	end

end )

--[[hook.Add( "PostPlayerDraw", "FgtAlertDraw", function()
	local offset = Vector( 0, 0, 85 )
	local ang = LocalPlayer():EyeAngles()
	local pos = offset + ang:Up()

	ang:RotateAroundAxis( ang:Forward(), 90 )
	ang:RotateAroundAxis( ang:Right(), 90 )

	cam.Start3D2D( pos, Angle( 0, ang.y, 90 ), 0.25 )
		draw.DrawText( "Testing", "Default", 2, 2, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER )
	cam.End3D2D()

end )]]