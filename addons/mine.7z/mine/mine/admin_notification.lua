--[[
	MOD/lua/mine/admin_notification.lua [#1259 (#1293), 1109184620, UID:2104177045]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:53AM]
	===BadFile===
]]

local _R = debug.getregistry()

hook.Add( "OnEntityCreated", "fgtadminnotify", function( createdEnt )
	if createdEnt and createdEnt:IsPlayer() then
		timer.Simple( 5, function()
			local userGroup = string.lower( createdEnt:GetUserGroup() )
			if( _R.Player.EV_GetRank ) then -- Evolve is installed
				userGroup = createdEnt:EV_GetRank()
			end
			if( (userGroup ~= "user") and (userGroup ~= "guest") ) then
				print( createdEnt:Nick() .. "  has joined with " .. userGroup .. " privileges!" )
				notification.AddLegacy( createdEnt:Nick() .. "  has joined with " .. userGroup .. " privileges!", NOTIFY_ERROR, 10 )
				if createdEnt:IsAdmin() then
					surface.PlaySound( "ambient/tones/elev1.wav" )
				end
			end
		end )
	end
end )

concommand.Add( "fgt_who", function()
	for _, ply in pairs( player.GetHumans() ) do
		local userName = ply:Nick()
		local userGroup = string.lower( ply:GetUserGroup() )
		local userAdmin = ply:IsAdmin() and "[Admin]" or ""
		local userAdmin = ply:IsSuperAdmin() and "[Super Admin]" or userAdmin
		
		if( _R.Player.EV_GetRank ) then -- Evolve is installed
			userGroup = ply:EV_GetRank()
		end
		
		local userString = string.format( "%-30.30s | %-15.15s %s", userName, userGroup, userAdmin )
		print( userString )
	end
end )