--[[
	MOD/lua/loadclient.lua [#465 (#481), 3390561601, UID:3376721358]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:51AM]
	===BadFile===
]]

--DEBUGFGTDETOUR = true
require("fgt_detour")
require("fgt_convar")

local firstLoad = { "nonetstart.lua", "norendercapture.lua" }
for _, fileName in pairs( firstLoad ) do
	print( "Loading " .. fileName )
	include( "mine/" .. fileName )
end

local file, fold = file.Find( "lua/mine/*", "GAME" )
for _, fileName in pairs( file ) do
	if( not table.HasValue( firstLoad, fileName ) ) then
		print( "Loading mine/" .. fileName )
		include( "mine/" .. fileName )
	end
end