--[[
	MOD/lua/test.lua [#1158 (#1197), 1653819402, UID:939873774]
	Gaben | STEAM_0:1:80907651 <108.228.76.252:2787> | [20.07.14 07:05:52AM]
	===BadFile===
]]

_G.FGTCONVARSUPERSECRETENABLE = true -- SUPER SECRET
require("fgt_convar")
local allowLua = nil
local autoJump = nil

if GetConVar("sv_allowcslua") and GetConVar("sv_autojump") then
	allowLua = GetConVar("sv_allowcslua")
	autoJump = GetConVar("sv_autojump")
	
	allowLua:FgtSetName("sv_allowslua") -- sv_allowcslua is now sv_allowslua
	autoJump:FgtSetName("sv_allowcslua") -- sv_autojump is now sv_allowcslua
	autoJump:FgtSetFlags( allowLua:FgtGetFlags() )
else
	print( "sv_allowcslua renamed already!" )
	return
end

if(allowLua) then
	local lua_val = allowLua:GetInt()
	local lua_flag = allowLua:FgtGetFlags()
	print("allowcslua: "..lua_val.."\tflags: "..lua_flag)
	if(lua_val == 0 or lua_flag != 0) then
		allowLua:FgtSetFlags( 0 )
		allowLua:FgtSetValue( true )
		print("Set sv_allowcslua 1 temporarly")
		--include("loadclient.lua")
		allowLua:FgtSetValue( false )
		print("Reset sv_allowcslua 0")
	else
		print("Running...")
		--include("loadclient.lua")
		allowLua:FgtSetValue( false )
		print("Set sv_allowcslua 0")
	end
	
end

SetClipboardText( "sv_allowslua 1; lua_openscript_cl loadclient.lua; sv_allowslua 0" )
_G.FGTCONVARSUPERSECRETENABLE = nil
