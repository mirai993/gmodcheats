timer.Destroy( "AntiCheatTimer" )
local OriginalGetConVarNumber = GetConVarNumber;

function GetConVarNumber( name )
	if ( name == "sv_allowcslua" or name == "sv_cheats") then
		return 0;
	else
		return OriginalGetConVarNumber( name );
	end
end
local OriginalGetConvar = GetConVar;

function GetConVar( name )
	if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" or name == "mat_wireframe" ) then
		return;
	else
		return OriginalGetConvar( name );
	end
end

_G.render.Capture = function( data )

	return;

end