--[[
	Leaked by Fami Harukaze - https://www.youtube.com/user/INTELINSIDECHANNEL
	Thanks to Boatless for his account
]]
BonelessChicken for Garry's Mod, also known as AteeHack:
	Lua Files:
		- cl_init.lua - Main Cheat that contains 'his' Aimbot, ESP and other features (https://mega.co.nz/#!TE0HgBIR!Y7TAOlarJ5V_MNySus0ITjyWHLtDIIBObsws7sbUVWs)
		- qacbp.lua - Renamed Version of Leystryku's Bypass for QAC (https://mega.co.nz/#!bJM2SRgZ!cCOthndzZo1wch0CC1KZby8cTwQTin7iRx3hyd50jqQ)
		- AH Generic Anti-Cheat Bypasser V2.lua - Very Shitty Anti-Cheat Bypass (http://pastebin.com/jNN1u0su)
		
	Executables and Binaries:
		- bootcamp.exe - His loader, can be found here: http://atee.host-ed.me/ah_api/downloadlauncher_2.php
		- ib_6096.tmp - Rename to .dll because it's a dynamic link library, can be dumped from X:\Windows\Temp\ib_XXXX.tmp
		
	Website Copies:
		- account.htm (http://www.bonelesschicken.net/account)
		- account_products_garrysmod.htm (http://www.bonelesschicken.net/account/products/garrysmod)
		