/*
__________                       .__       .__             ___.           __   
\______   \_______   ____   ____ |__| _____|__| ____   ____\_ |__   _____/  |_ 
 |     ___/\_  __ \_/ __ \_/ ___\|  |/  ___/  |/  _ \ /    \| __ \ /  _ \   __\
 |    |     |  | \/\  ___/\  \___|  |\___ \|  (  <_> )   |  \ \_\ (  <_> )  |  
 |____|     |__|    \___  >\___  >__/____  >__|\____/|___|  /___  /\____/|__|   
                        \/     \/        \/               \/    \/             
-----------------
Changelog: [1.5]
-----------------
Proofing methods.
Hiding hooks.
New menu.
Added Chams ( for players, weapons, npcs... )
Added NPC ESP
Added Prefix ( allows you to change the text before and after the command, makes things less detectable )
-----------------
Credits:
-----------------
RabidToaster - Hiding Hooks
kolbybrooks  - Hook Script
AzuiSleet    - ConVar Bypasser ( Module )
Eusion       - Box Script
Deco         - No-Spread ( Module )
Seth		 - Script Enforcer Bypass ( Module )
*/
if ( SERVER ) then return end
local version = "v1.6"
print( "\n\nPrecisionbot " .. version .. " loaded!\n\n" )
print( "\nNOTE: Use the menu, trying to use the commands is dumb.\n" )

require( "fuckoff" )
require( "deco" )
require( "scriptenforcer" )

local prefix = "fr_"
local endprefix = "_endcommand"


// ********************
// Menu VGUI:
// ********************

function menuvgui()
local menu = vgui.Create( "DFrame" )
menu:SetPos( ScrW()/2-250/2,ScrH()/2-500/2 )
menu:SetSize( 250, 500 )
menu:SetTitle( "Precisionbot " .. version )
menu:SetVisible( true )
menu:SetDraggable( true )
menu:ShowCloseButton( true ) 
menu:MakePopup()
menu.Paint = function()
	draw.RoundedBox( 0, 0, 0, 250, 500, Color( 128, 128, 128, 255 ) )
	draw.RoundedBox( 0, 0, 0, 250, 21, Color( 0, 128, 255, 255 ) )
end

local panel = vgui.Create( "DPropertySheet" )
panel:SetParent( menu )
panel:SetPos( 5, 30 )
panel:SetSize( 240, 460 )
panel.Paint = function()
	draw.RoundedBox( 0, 0, 0, 250, 500, Color( 128, 128, 128, 255 ) )
end


// Aimbot
local aimpan = vgui.Create( "DPanel", panel )

local aimbot = vgui.Create( "DCheckBoxLabel", aimpan )
aimbot:SetText( "Aimbot" )
aimbot:SetPos( 10, 10 )
aimbot:SetConVar( "" )
aimbot:SetTextColor( Color( 0, 0, 0, 255 ) )
aimbot:SizeToContents()

local autoshoot = vgui.Create( "DCheckBoxLabel", aimpan )
autoshoot:SetText( "Autoshoot" )
autoshoot:SetPos( 10, 30 )
autoshoot:SetConVar( "" )
autoshoot:SetTextColor( Color( 0, 0, 0, 255 ) )
autoshoot:SizeToContents()

local aimthru = vgui.Create( "DCheckBoxLabel", aimpan )
aimthru:SetText( "Aimthru" )
aimthru:SetPos( 10, 50 )
aimthru:SetConVar( "" )
aimthru:SetTextColor( Color( 0, 0, 0, 255 ) )
aimthru:SizeToContents()

local friendlyfire = vgui.Create( "DCheckBoxLabel", aimpan )
friendlyfire:SetText( "Friendly Fire" )
friendlyfire:SetPos( 10, 70 )
friendlyfire:SetConVar( "" )
friendlyfire:SetTextColor( Color( 0, 0, 0, 255 ) )
friendlyfire:SizeToContents()

// Extra Sensory
local esppan = vgui.Create( "DPanel", panel )

local playero = vgui.Create("DLabel", esppan )
playero:SetPos( 10, 10 )
playero:SetWide( 200 )
playero:SetText( "Player Options:" )
playero:SetTextColor( Color(255, 0, 0, 255) )

local name = vgui.Create( "DCheckBoxLabel", esppan )
name:SetText( "Name" )
name:SetPos( 10, 30 )
name:SetConVar( prefix.."name"..endprefix )
name:SetTextColor( Color( 0, 0, 0, 255 ) )
name:SizeToContents()

local health = vgui.Create( "DCheckBoxLabel", esppan )
health:SetText( "Health" )
health:SetPos( 10, 50 )
health:SetConVar( prefix.."health"..endprefix )
health:SetTextColor( Color( 0, 0, 0, 255 ) )
health:SizeToContents()

local weapon = vgui.Create( "DCheckBoxLabel", esppan )
weapon:SetText( "Weapon" )
weapon:SetPos( 10, 70 )
weapon:SetConVar( prefix.."weapon"..endprefix )
weapon:SetTextColor( Color( 0, 0, 0, 255 ) )
weapon:SizeToContents()

local distance = vgui.Create( "DCheckBoxLabel", esppan )
distance:SetText( "Distance" )
distance:SetPos( 10, 90 )
distance:SetConVar( prefix.."distance"..endprefix )
distance:SetTextColor( Color( 0, 0, 0, 255 ) )
distance:SizeToContents()

local box = vgui.Create( "DCheckBoxLabel", esppan )
box:SetText( "Box" )
box:SetPos( 10, 110 )
box:SetConVar( prefix.."box"..endprefix )
box:SetTextColor( Color( 0, 0, 0, 255 ) )
box:SizeToContents()

local npco = vgui.Create("DLabel", esppan )
npco:SetPos( 10, 130 )
npco:SetWide( 120 )
npco:SetText( "NPC Options:" )
npco:SetTextColor( Color(255, 0, 0, 255) )

local npc = vgui.Create( "DCheckBoxLabel", esppan )
npc:SetText( "NPC Name" )
npc:SetPos( 10, 150 )
npc:SetConVar( prefix.."npc"..endprefix )
npc:SetTextColor( Color( 0, 0, 0, 255 ) )
npc:SizeToContents()

local npcm = vgui.Create( "DCheckBoxLabel", esppan )
npcm:SetText( "NPC Marker" )
npcm:SetPos( 10, 170 )
npcm:SetConVar( )
npcm:SetTextColor( Color( 0, 0, 0, 255 ) )
npcm:SizeToContents()

local entityo = vgui.Create("DLabel", esppan )
entityo:SetPos( 10, 190 )
entityo:SetWide( 220 )
entityo:SetText( "Entity Options:" )
entityo:SetTextColor( Color(255, 0, 0, 255) )

local entitys = vgui.Create( "DCheckBoxLabel", esppan )
entitys:SetText( "Sandbox Entities" )
entitys:SetPos( 10, 210 )
entitys:SetConVar( prefix.."entitysbox"..endprefix )
entitys:SetTextColor( Color( 0, 0, 0, 255 ) )
entitys:SizeToContents()

local entityr = vgui.Create( "DCheckBoxLabel", esppan )
entityr:SetText( "Roleplay Entities" )
entityr:SetPos( 10, 230 )
entityr:SetConVar( prefix.."entityrp"..endprefix )
entityr:SetTextColor( Color( 0, 0, 0, 255 ) )
entityr:SizeToContents()

local entityrem = vgui.Create("DLabel", esppan )
entityrem:SetPos( 150, 250 )
entityrem:SetWide( 220 )
entityrem:SetText( "Removed" )
entityrem:SetTextColor( Color(255, 0, 0, 255) )

local entno = vgui.Create( "DComboBox", esppan )
entno:SetPos( 10, 270 )
entno:SetSize( 90, 100 )
entno:SetMultiple( false )

local entityadd = vgui.Create("DLabel", esppan )
entityadd:SetPos( 40, 250 )
entityadd:SetWide( 220 )
entityadd:SetText( "Added" )
entityadd:SetTextColor( Color(255, 0, 0, 255) )

local entso = vgui.Create( "DComboBox", esppan )
entso:SetPos( 130, 270 )
entso:SetSize( 90, 100 )
entso:SetMultiple( false )


local maxdis = vgui.Create( "DNumSlider", esppan )
maxdis:SetPos( 10, 380 )
maxdis:SetWide( 200 )
maxdis:SetText( "" )
maxdis:SetMin( 0 )
maxdis:SetMax( 50000 )
maxdis:SetDecimals( 0 )
maxdis:SetConVar( prefix.."max"..endprefix )
	local maxdist = vgui.Create("DLabel", esppan )
	maxdist:SetPos( 10, 380 )
	maxdist:SetText( "Max Distance" )
	maxdist:SetTextColor( Color(0, 0, 0, 255) )
	


// Other
local othpan = vgui.Create( "DPanel", panel )

local otherl = vgui.Create("DLabel", othpan )
otherl:SetPos( 10, 10 )
otherl:SetWide( 200 )
otherl:SetText( "Miscellaneous:" )
otherl:SetTextColor( Color(255, 0, 0, 255) )

local crosshair = vgui.Create( "DCheckBoxLabel", othpan )
crosshair:SetText( "Crosshair" )
crosshair:SetPos( 10, 30 )
crosshair:SetConVar( prefix.."crosshair"..endprefix  )
crosshair:SetTextColor( Color( 0, 0, 0, 255 ) )
crosshair:SizeToContents()

local remov = vgui.Create( "DCheckBoxLabel", othpan )
remov:SetText( "Remove Overlays" )
remov:SetPos( 10, 50 )
remov:SetConVar( prefix.."removeoverlays"..endprefix )
remov:SetTextColor( Color( 0, 0, 0, 255 ) )
remov:SizeToContents()

local speedvalue = vgui.Create( "DNumSlider", othpan )
speedvalue:SetPos( 10, 90 )
speedvalue:SetWide( 200 )
speedvalue:SetText( "" )
speedvalue:SetMin( .1 )
speedvalue:SetMax( 1 )
speedvalue:SetDecimals( 1 )
speedvalue:SetConVar( prefix.."speedvalue"..endprefix )
	local svlabel = vgui.Create("DLabel", othpan )
	svlabel:SetPos( 10, 90 )
	svlabel:SetText( "Speed Value" )
	svlabel:SetTextColor( Color(0, 0, 0, 255) )

// Dynamic Lighting
local dlsl = vgui.Create("DLabel", othpan )
dlsl:SetPos( 10, 130 )
dlsl:SetWide( 200 )
dlsl:SetText( "Dynamic Lights:" )
dlsl:SetTextColor( Color(255, 0, 0, 255) )

local dynamiclights = vgui.Create( "DCheckBoxLabel", othpan )
dynamiclights:SetText( "All Dynamic Lights" )
dynamiclights:SetPos( 10, 150 )
dynamiclights:SetConVar( prefix.."dynamiclights"..endprefix )
dynamiclights:SetTextColor( Color( 0, 0, 0, 255 ) )
dynamiclights:SizeToContents()

local selfdl = vgui.Create( "DCheckBoxLabel", othpan )
selfdl:SetText( "Self Dynamic Lights" )
selfdl:SetPos( 10, 170 )
selfdl:SetConVar( prefix.."dynamiclightsself"..endprefix )
selfdl:SetTextColor( Color( 0, 0, 0, 255 ) )
selfdl:SizeToContents()

local dlr = vgui.Create( "DNumSlider", othpan )
dlr:SetPos( 10, 190 )
dlr:SetWide( 200 )
dlr:SetText( "" )
dlr:SetMin( 1 )
dlr:SetMax( 1000 )
dlr:SetDecimals( 0 )
dlr:SetConVar( prefix.."dynamiclightsrad"..endprefix )
	local dlrl = vgui.Create("DLabel", othpan )
	dlrl:SetPos( 10, 190 )
	dlrl:SetText( "Radius" )
	dlrl:SetTextColor( Color(0, 0, 0, 255) )

// Chams
local chamsl = vgui.Create("DLabel", othpan )
chamsl:SetPos( 10, 230 )
chamsl:SetText( "Chams:" )
chamsl:SetTextColor( Color(255, 0, 0, 255) )

local chams = vgui.Create( "DCheckBoxLabel", othpan )
chams:SetText( "Chams" )
chams:SetPos( 110, 250 )
chams:SetConVar( prefix.."chams"..endprefix )
chams:SetTextColor( Color( 0, 0, 0, 255 ) )
chams:SizeToContents()

local chamsn = vgui.Create( "DCheckBoxLabel", othpan )
chamsn:SetText( "Include NPC's" )
chamsn:SetPos( 110, 270 )
chamsn:SetConVar( prefix.."chamsnpc"..endprefix )
chamsn:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsn:SizeToContents()

local chamsw = vgui.Create( "DCheckBoxLabel", othpan )
chamsw:SetText( "Include Weapons" )
chamsw:SetPos( 110, 290 )
chamsw:SetConVar( )
chamsw:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsw:SizeToContents()

local chamsr = vgui.Create( "DCheckBoxLabel", othpan )
chamsr:SetText( "Include Ragdolls" )
chamsr:SetPos( 110, 310 )
chamsr:SetConVar( )
chamsr:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsr:SizeToContents()

local chamstype = vgui.Create( "DComboBox", othpan )
chamstype:SetPos( 10, 250 )
chamstype:SetSize( 90, 120 )
chamstype:SetMultiple( false )
chamstype:AddItem( "Wireframe" )
chamstype:AddItem( "Soild" )
chamstype:AddItem( "XQZ" )
chamstype:AddItem( "Full Wireframe" )
chamstype:AddItem( "Full Soild" )

local chamsmax = vgui.Create( "DNumSlider", othpan )
chamsmax:SetPos( 110, 330 )
chamsmax:SetWide( 100 )
chamsmax:SetText( "" )
chamsmax:SetMin( 3000 )
chamsmax:SetMax( 10000 )
chamsmax:SetDecimals( 0 )
chamsmax:SetConVar( prefix.."chamsmax"..endprefix )
	local chamsmaxl = vgui.Create("DLabel", othpan )
	chamsmaxl:SetPos( 110, 330 )
	chamsmaxl:SetText( "Visibility" )
	chamsmaxl:SetTextColor( Color(0, 0, 0, 255) )

local cheats = vgui.Create( "DButton", othpan )
cheats:SetSize( 200, 20 )
cheats:SetPos( 10, 390 )
cheats:SetText( "Toggle Bypass" )
cheats.DoClick = function()
enabled = !enabled

if enabled then
SetConvar( CreateConVar("sv_cheats", ""), 1 )
else
SetConvar( CreateConVar("sv_cheats", ""), 0 )
end
end

// Radar
local radarpan = vgui.Create( "DPanel", panel )

local radar = vgui.Create( "DCheckBoxLabel", radarpan )
radar:SetText( "Radar" )
radar:SetPos( 10, 10 )
radar:SetConVar( prefix.."radar"..endprefix )
radar:SetTextColor( Color( 0, 0, 0, 255 ) )
radar:SizeToContents()

local ccRed = vgui.Create( "DNumSlider", radarpan )
ccRed:SetPos( 10, 50 )
ccRed:SetWide( 200 )
ccRed:SetText( "" )
ccRed:SetMin( 0 )
ccRed:SetMax( 255 )
ccRed:SetDecimals( 0 )
ccRed:SetConVar( prefix.."radarr"..endprefix )
	local cRed = vgui.Create("DLabel", radarpan )
	cRed:SetPos( 10, 50 )
	cRed:SetText( "Red" )
	cRed:SetTextColor( Color(0, 0, 0, 255) )
 
 local ccGreen = vgui.Create( "DNumSlider", radarpan )
ccGreen:SetPos( 10, 100 )
ccGreen:SetWide( 200 )
ccGreen:SetText( "" )
ccGreen:SetMin( 0 )
ccGreen:SetMax( 255 )
ccGreen:SetDecimals( 0 )
ccGreen:SetConVar( prefix.."radarg"..endprefix )
	local cGreen = vgui.Create("DLabel", radarpan )
	cGreen:SetPos( 10, 100 )
	cGreen:SetText( "Green" )
	cGreen:SetTextColor( Color(0, 0, 0, 255) )

 
 local ccBlue = vgui.Create( "DNumSlider", radarpan )
ccBlue:SetPos( 10, 150 )
ccBlue:SetWide( 200 )
ccBlue:SetText( "" )
ccBlue:SetMin( 0 )
ccBlue:SetMax( 255 )
ccBlue:SetDecimals( 0 )
ccBlue:SetConVar( prefix.."radarb"..endprefix )
	local cBlue = vgui.Create("DLabel", radarpan )
	cBlue:SetPos( 10, 150 )
	cBlue:SetText( "Blue" )
	cBlue:SetTextColor( Color(0, 0, 0, 255) )

local ccAlpha = vgui.Create( "DNumSlider", radarpan )
ccAlpha:SetPos( 10, 200 )
ccAlpha:SetWide( 200 )
ccAlpha:SetText( "" )
ccAlpha:SetMin( 0 )
ccAlpha:SetMax( 255 )
ccAlpha:SetDecimals( 0 )
ccAlpha:SetConVar( prefix.."radara"..endprefix )
	local cAlpha = vgui.Create("DLabel", radarpan )
	cAlpha:SetPos( 10, 200 )
	cAlpha:SetText( "Alpha" )
	cAlpha:SetTextColor( Color(0, 0, 0, 255) )
	
local ccX = vgui.Create( "DNumSlider", radarpan )
ccX:SetPos( 10, 250 )
ccX:SetWide( 200 )
ccX:SetText( "" )
ccX:SetMin( 0 )
ccX:SetMax( ScrW() )
ccX:SetDecimals( 0 )
ccX:SetConVar( prefix.."radarx"..endprefix )
	local cX = vgui.Create("DLabel", radarpan )
	cX:SetPos( 10, 250 )
	cX:SetText( "Radar X" )
	cX:SetTextColor( Color(0, 0, 0, 255) )
	
local ccY = vgui.Create( "DNumSlider", radarpan )
ccY:SetPos( 10, 300 )
ccY:SetWide( 200 )
ccY:SetText( "" )
ccY:SetMin( 0 )
ccY:SetMax( ScrH() )
ccY:SetDecimals( 0 )
ccY:SetConVar( prefix.."radary"..endprefix )
	local cY = vgui.Create("DLabel", radarpan )
	cY:SetPos( 10, 300 )
	cY:SetText( "Radar Y" )
	cY:SetTextColor( Color(0, 0, 0, 255) )
	
local crs = vgui.Create( "DNumSlider", radarpan )
crs:SetPos( 10, 350 )
crs:SetWide( 200 )
crs:SetText( "" )
crs:SetMin( 0 )
crs:SetMax( 10000 )
crs:SetDecimals( 0 )
crs:SetConVar( prefix.."radarra"..endprefix )
	local ccrs = vgui.Create("DLabel", radarpan )
	ccrs:SetPos( 10, 350 )
	ccrs:SetText( "Radar Radius" )
	ccrs:SetTextColor( Color(0, 0, 0, 255) )

panel:AddSheet( "Aimbot", aimpan, "gui/silkicons/star", false, false, "Automatic Aiming" )
panel:AddSheet( "ESP", esppan, "gui/silkicons/group", false, false, "Extra Sensory" ) 
panel:AddSheet( "Misc", othpan, "gui/silkicons/plugin", false, false, "Other Stuff" )
panel:AddSheet( "Radar", radarpan, "gui/silkicons/wrench", false, false, "Other Stuff" ) 
end

concommand.Add( prefix.."menu"..endprefix, menuvgui )
RunConsoleCommand( prefix.."menu"..endprefix )

// ********************
// Main Functions:
// ********************
local PB = {}
local Hooks = {}

// Commands - Console commands.
CreateClientConVar( prefix.."disable"..endprefix, "0", true, false )
CreateClientConVar( prefix.."name"..endprefix, "1", true, false )
CreateClientConVar( prefix.."health"..endprefix, "1", true, false )
CreateClientConVar( prefix.."weapon"..endprefix, "0", true, false )
CreateClientConVar( prefix.."distance"..endprefix, "0", true, false )
CreateClientConVar( prefix.."box"..endprefix, "1", true, false )
CreateClientConVar( prefix.."entityrp"..endprefix, "0", true, false )
CreateClientConVar( prefix.."entitysbox"..endprefix, "0", true, false )
CreateClientConVar( prefix.."color"..endprefix, "0", true, false )
CreateClientConVar( prefix.."npc"..endprefix, "1", true, false )
CreateClientConVar( prefix.."npcmarker"..endprefix, "1", true, false )
CreateClientConVar( prefix.."max"..endprefix, "10000", true, false )
CreateClientConVar( prefix.."crosshair"..endprefix, "1", true, false )
CreateClientConVar( prefix.."dynamiclights"..endprefix, "0", true, false )
CreateClientConVar( prefix.."dynamiclightsself"..endprefix, "0", true, false )
CreateClientConVar( prefix.."dynamiclightsrad"..endprefix, "500", true, false )
CreateClientConVar( prefix.."removeoverlays"..endprefix, "1", true, false )
CreateClientConVar( prefix.."chams"..endprefix, "1", true, false )
CreateClientConVar( prefix.."chamsnpc"..endprefix, "0", true, false )
CreateClientConVar( prefix.."chamsmax"..endprefix, "10000", true, false )
CreateClientConVar( prefix.."speedvalue"..endprefix, ".2", true, false )
CreateClientConVar( prefix.."nospread"..endprefix, "1", true, false )
CreateClientConVar( prefix.."radar"..endprefix, "1", true, false )
CreateClientConVar( prefix.."radarr"..endprefix, "0", true, false )
CreateClientConVar( prefix.."radarg"..endprefix, "255", true, false )
CreateClientConVar( prefix.."radarb"..endprefix, "0", true, false )
CreateClientConVar( prefix.."radara"..endprefix, "50", true, false )
CreateClientConVar( prefix.."radarx"..endprefix, "10", true, false )
CreateClientConVar( prefix.."radary"..endprefix, "10", true, false )
CreateClientConVar( prefix.."radarra"..endprefix, "5000", true, false )
CreateClientConVar( prefix.."radaren"..endprefix, "0", true, false )
CreateClientConVar( prefix.."radaral"..endprefix, "0", true, false )

// LUA Commands - To make this easy.
local ply	   = LocalPlayer()
local e		   = ent
local x 	   = ScrW() / 2
local y 	   = ScrH() / 2
local Target   = nil
local Aiming   = false

// Fonts - Main fonts used in the cheat. You must download visitor2 for this to work.
surface.CreateFont( "Visitor TT2 BRK", 10, 200, true, false, "VISITOR2" )


// Hooking - Servers will block your hooks if you don't do this. I'm going to recode this later, but I'm not sure if its doing anything right now.
function Random()
	local j, r = 0, ""

	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function NewHook( h, f )
	local n = Random()
	Hooks[n] = h
	hook.Add( h, n, f )
end 

// Get Admin - Finds the current admins then then prints what level of admin they are.
function GetAdmin( e )
		if e:IsAdmin() and not e:IsSuperAdmin() then return ( " | Admin" )
		elseif e:IsSuperAdmin() then return ( " | Super Admin" )
		elseif not e:IsAdmin() and not e:IsSuperAdmin() then return ( "" ) 
	end
end

// Targets - Mainly for the chams, tells whats valid and whats not.
function BadTargets( e )
	if string.find(string.lower(team.GetName(e:Team())), "spectator") then return false end
	if string.find(string.lower(team.GetName(e:Team())), "Dead Prisoners") then return false end
	if string.find(string.lower(team.GetName(e:Team())), "Dead Guards") then return false end
	return true
end

// Entitiess!!!!
local RolePlayEntitys = ( {
	"money_printer",
	"drug_lab",
	"drug",
	"microwave",
	"food",
	"gunlab",
	"spawned_shipment",
	"spawned_food",
	"spawned_weapon",
} )

local RPMoney = ( {
	"models/props/cs_assault/money.mdl",
} )

local Warnings = ( {
	"npc_grenade_frag",
	"crossbow_bolt",
	"rpg_missile",
	"grenade_ar2",
	"prop_combine_ball",
	"hunter_flechette",
	"ent_flashgrenade",
	"ent_explosivegrenade",
	"ent_smokegrenade",
} )

// ********************
// Aimbot:
// ********************

// ********************
// Extra Sensory:
// ********************
function PB.Display( e )
	for _, e in pairs(ents.GetAll()) do
		local ply	= LocalPlayer()
		if ( e:IsPlayer() && e:Alive() == true ) && ( e ~=ply ) && ( BadTargets(e) ) then
			local pos	= e:GetPos():ToScreen()
			local tn	= team.GetName( e:Team() )
			local tc	= team.GetColor( e:Team() )
			local dis	= math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
			
			if e:IsValid() then // I had to run this because the script was breaking.
			
			// If the player(s) are in this distance then it will draw everything below.
			if dis <= GetConVarNumber( prefix.."max"..endprefix ) then
			
			// Extra sensory color type, if you want it to be based off their team color or allies/enemyies.
			local col
				if ( GetConVarNumber( prefix.."color"..endprefix ) == 0 ) then
						col = Color( tc.r, tc.g, tc.b, 255 )
					end
				if ( GetConVarNumber( prefix.."color"..endprefix ) == 1 ) then
					if e:Team() == ply:Team() then
						col = Color( 0, 255, 0, 255 )
					elseif e:Team() ~= ply:Team() then
						col = Color( 255, 0, 0, 255 )
					end
				end
				
			// Real Extra sensory code.
				if ( GetConVarNumber( prefix.."name"..endprefix ) == 1 ) then
					draw.SimpleText( e:Nick() .. " | " .. tn .. GetAdmin( e ), "VISITOR2", pos.x, pos.y, col, 0, 2 )
				end
				
				if ( GetConVarNumber( prefix.."health"..endprefix ) == 1 ) then
					draw.SimpleText( "HP: " .. e:Health(), "VISITOR2", pos.x, pos.y + 10, col, 0, 2 )
				end
				
				if ( GetConVarNumber( prefix.."weapon"..endprefix ) == 1 ) then
					if e:GetActiveWeapon():IsValid() then
					local wep = e:GetActiveWeapon():GetPrintName()
					local wep = string.Replace( wep, "#HL2_", "" )
					local wep = string.Replace( wep, "#GMOD_", "" )
					local wep = string.upper( wep )
					draw.SimpleText( "W: " .. wep, "VISITOR2", pos.x , pos.y + 20, col, 0, 2 )
				end
			end
				if ( GetConVarNumber( prefix.."distance"..endprefix ) == 1 ) then
					draw.SimpleText( "D: " .. dis, "VISITOR2", pos.x, pos.y + 30, col, 0, 2 )
				end
					
				if ( GetConVarNumber( prefix.."box"..endprefix ) == 1 ) then
					local center = e:LocalToWorld(e:OBBCenter())
					local min,max = e:WorldSpaceAABB()
					local dim = max-min

					local front = e:GetForward()*(dim.y/2)
					local right = e:GetRight()*(dim.x/2)
					local top = e:GetUp()*(dim.z/2)
					local back = (e:GetForward()*-1)*(dim.y/2)
					local left = (e:GetRight()*-1)*(dim.x/2)
					local bottom = (e:GetUp()*-1)*(dim.z/2)
					local FRT = center+front+right+top
					local BLB = center+back+left+bottom
					local FLT = center+front+left+top
					local BRT = center+back+right+top
					local BLT = center+back+left+top
					local FRB = center+front+right+bottom
					local FLB = center+front+left+bottom
					local BRB = center+back+right+bottom

					FRT = FRT:ToScreen()
					BLB = BLB:ToScreen()
					FLT = FLT:ToScreen()
					BRT = BRT:ToScreen()
					BLT = BLT:ToScreen()
					FRB = FRB:ToScreen()
					FLB = FLB:ToScreen()
					BRB = BRB:ToScreen()

					local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
					local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)

					surface.SetDrawColor(col.r, col.g, col.b, 150)

					surface.DrawLine(xmax,ymax,xmax,ymin)
					surface.DrawLine(xmax,ymin,xmin,ymin)
					surface.DrawLine(xmin,ymin,xmin,ymax)
					surface.DrawLine(xmin,ymax,xmax,ymax)
					end
			else
				if dis >= GetConVarNumber( prefix.."max"..endprefix ) then
					if ( GetConVarNumber( prefix.."name"..endprefix ) == 1 ) then
							draw.SimpleText( e:Nick() .. GetAdmin( e ), "VISITOR2", pos.x, pos.y, col, 1, 1 )
						end
					end
				end
			end
		end
		if e:IsValid() then
			if e:IsNPC() and e:GetMoveType() !=0 then
				if ( GetConVarNumber( prefix.."npc"..endprefix ) == 1 ) then
					local pos = e:GetPos():ToScreen()
					local npc = e:GetClass()
					local npc = string.Replace( npc, "npc_", "" )
					local npc = string.upper( npc )
					draw.RoundedBox( 0, pos.x, pos.y, 5, 5, Color( 255, 0, 0, 255 ) )
					draw.SimpleText( npc, "VISITOR2", pos.x, pos.y + 10, Color( 255, 0, 0, 255 ), 1, 1 )
				end
			end
			
			if e:IsWeapon() and e:GetMoveType() !=0 or string.find( e:GetClass(), "prop_vehicle_" ) then
				if ( GetConVarNumber( prefix.."entitysbox"..endprefix ) == 1 ) then
					local sbox = e:GetClass()
					local sbox = string.Replace(sbox, "prop_vehicle_", "")
					local sbox = string.Replace(sbox, "weapon_", "")
					local pos = e:GetPos():ToScreen()
					draw.SimpleText( sbox, "VISITOR2", pos.x, pos.y + 10, Color( 255, 0, 0, 255 ), 1, 1 )
				end
			end
			
			if table.HasValue( RolePlayEntitys, e:GetClass() ) then
				if ( GetConVarNumber( prefix.."entityrp"..endprefix ) == 1 ) then
					local rpclass = e:GetClass()
					local rpclass = string.Replace(rpclass, "spawned_", "")
					local rpclass = string.Replace(rpclass, "shipment_", "Shipment ")
					local rpclass = string.Replace(rpclass, "dropped_", "")
					local rpclass = string.Replace(rpclass, "dropped_", "")
					local rpclass = string.Replace(rpclass, "smg_", "SMG ")
					local rpclass = string.Replace(rpclass, "money_", "Money ")
					local pos = e:GetPos():ToScreen()
					draw.SimpleText( rpclass, "VISITOR2", pos.x, pos.y, Color( 255, 0, 0, 255 ), 1 ,1)
				end
			end
			
			if table.HasValue( RPMoney, e:GetModel() ) then
				if ( GetConVarNumber( prefix.."entityrp"..endprefix ) == 1 ) then
					local money = e:GetModel()
					local money = string.Replace( money, "models/props/cs_assault/money.mdl", "Money" )
					local pos = e:GetPos():ToScreen()
					if e.DarkRPVars and e.DarkRPVars.money then
					draw.SimpleText( money.."["..e.DarkRPVars.money.."]", "VISITOR2", pos.x, pos.y, Color( 255, 0, 0, 255 ), 1 ,1)
					else
					draw.SimpleText( money.."["..e:GetNWInt("money").."]", "VISITOR2", pos.x, pos.y, Color( 255, 0, 0, 255 ), 1 ,1)
				end
			end
		end
	end
end
end
NewHook( "HUDPaint", PB.Display )

// ********************
// Visuals:
// ********************
function Drawcrosshair()
	if GetConVarNumber( prefix.."crosshair"..endprefix ) == 1 then
	local cross 	= {}
	cross.x			= x				  				// Centure screen.																DEF = x
	cross.y			= y 			  				// Centure screen.																DEF = y
	cross.tall		= 40					  		// Highth of the line.															DEF = 20
	cross.wide		= 40					  		// Width of the line.															DEF = 20
	cross.color		= Color( 0, 255, 0, 255 )		// Crosshair color.																DEF = Color( 0, 255, 0, 255 )
	cross.dotcol	= Color( 255, 0, 0, 255 )		// Crosshair dot color.															DEF = Color( 255, 0, 0, 255 )
	cross.xd		= cross.x - 2					// Crosshair dot - 2.															DEF = cross.x - 2
	cross.yd		= cross.y - 2					// Crosshair dot - 2.															DEF = cross.y - 2

		// GUI
			surface.SetDrawColor( cross.color )
			surface.DrawLine( cross.x, cross.y - cross.tall, cross.x, cross.y + cross.tall )
			surface.DrawLine( cross.x - cross.wide, cross.y, cross.x + cross.wide, cross.y )
			draw.RoundedBox( 1, cross.xd, cross.yd, 5, 5, cross.dotcol )
		end
	end
NewHook( "HUDPaint", Drawcrosshair )

// Dynamic Lights - Draws a light around the player, makes them easy to see if you don't want to bypass cheats.
function Drawdynamiclights()
	local ply = LocalPlayer()
	

		for _, e in pairs( player.GetAll() ) do
		
			local col
				if GetConVarNumber( prefix.."color"..endprefix ) == 0 then
						local tc  = team.GetColor( e:Team() )
						col = Color( tc.r, tc.g, tc.b, 255 )
					end
				if GetConVarNumber( prefix.."color"..endprefix ) == 1 then
						if e:Team() == ply:Team() then
						col = Color( 255, 0, 0, 255 )
						elseif e:Team() ~= ply:Team() then
						col = Color( 0, 255, 0, 255 )
					end
				end
	

				if ( GetConVarNumber( prefix.."dynamiclightsself"..endprefix ) == 1 ) then
					local dlight = DynamicLight( ply )
					dlight.Pos = e:GetPos() + Vector( 0, 0, 20 )
					dlight.r = 255
					dlight.g = 255
					dlight.b = 255
					dlight.Size = GetConVarNumber( prefix.."dynamiclightsrad"..endprefix )
					dlight.Decay = 20
					dlight.DieTime = CurTime() + .1
				end
				if ( GetConVarNumber( prefix.."dynamiclights"..endprefix ) == 1 ) then
				if ValidEntity(e) and e:Alive() and e !=LocalPlayer() then
					local dlight = DynamicLight( player.GetAll() )
					dlight.Pos = e:GetPos() + Vector( 0, 0, 20 )
					dlight.r = col.r
					dlight.g = col.g
					dlight.b = col.b
					dlight.Size = GetConVarNumber( prefix.."dynamiclightsrad"..endprefix )
					dlight.Decay = 20
					dlight.DieTime = CurTime() + .1
				end
			end
		end
	end
NewHook( "HUDPaint", Drawdynamiclights )

// Chams - Shows the player model though the walls.
/*function Chams()
	for k, e in pairs( ents.GetAll() ) do
		if e:IsValid() then
			local ply = LocalPlayer()
			if ( e:IsPlayer() and e:Alive() == true ) and ( e ~=ply ) and ( BadTargets(e) ) or ( e:IsWeapon() or e:IsNPC() and e:GetMoveType() !=0 ) then
			local dis = math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
			if ( GetConVarNumber( prefix.."chams"..endprefix ) == 1 ) then
			if dis <= GetConVarNumber( prefix.."chamsmax"..endprefix ) then
			cam.Start3D( EyePos(), EyeAngles() )
				local c = ( 1/255 )
				local mat = Material("hlmv/debugmrmwireframe")
				local col
				if e:IsPlayer() then
				local tc = team.GetColor( e:Team() )
				col = Color( 255, 255, 0, 255 )
				end
				if e:IsNPC() then
				col = Color( 255, 0, 0, 255 )
				end
				if e:IsWeapon() then
				col = Color( 255, 255, 255, 255 )
				end
					render.SuppressEngineLighting( true )
					render.SetColorModulation((c*col.r), (c*col.g), (c*col.b))
					SetMaterialOverride( mat )
					e:DrawModel()
					render.SuppressEngineLighting( false )
					render.SetColorModulation( 1, 1, 1 )
					SetMaterialOverride( 0 )
					e:DrawModel()
				end
			cam.End3D()
		end
	end
end
end
end
NewHook( "RenderScreenspaceEffects", Chams )*/


// ********************
// Radar:
// ********************
function Drawradar()
	if GetConVarNumber( prefix.."radar"..endprefix ) == 1 then
	
	// Radar Table - The table for the shit n shit.
	local radar 	= {}
	radar.x 		= GetConVarNumber( prefix.."radarx"..endprefix )	  // X postition of the radar.  												DEF = 10
	radar.y			= GetConVarNumber( prefix.."radary"..endprefix )	  // Y postition of the radar.  												DEF = 10
	radar.round		= 0						  					  // The roundness of the radar.  												DEF = 0
	radar.size 		= 200					  					  // Size of radar.  															DEF = 200
	radar.selfsize	= 5						  					  // Your box size. 															DEF = 5
	radar.selfround = 1						  					  // Roundness of your dot.														DEF = 1
	radar.csize		= 90					  					  // Centure line size.															DEF = 90
	red				= GetConVarNumber( prefix.."radarr"..endprefix )	  // Redcolor																	DEF =
	green			= GetConVarNumber( prefix.."radarg"..endprefix )	  // Greencolor																	DEF =
	blue			= GetConVarNumber( prefix.."radarb"..endprefix )	  // Bluecolor																	DEF =
	alpha			= GetConVarNumber( prefix.."radara"..endprefix )	  // Alphacolor																	DEF =
	radar.col		= Color( red, green, blue, alpha ) 			  // Radar Color																DEF =
	radar.outcol	= Color( 0, 0, 0, 255 )	  					  // Outline color.																DEF = Color( 0, 0, 0, 255 )
	radar.selfcol	= Color( 0, 0, 255, 000 ) 					  // Your color.																DEF = Color( 0, 0, 255, 255 )
	radar.radius	= GetConVarNumber( prefix.."radarra"..endprefix )		  // How far the radar will scan.												DEF = 5000
	radar.plyname	= true					  					  // Draws player's name.														DEF = false
	radar.plydot	= true					  					  // Draws a player dot on the position of the radar.							DEF = true
	radar.plycol	= Color( 0, 0, 255, 255 ) 					  // Color of the player's name and dot.										DEF = Color( 0, 0, 255, 255 )
	radar.npcdot	= true					  					  // Draws a NPC dot on the position of the radar.								DEF = true
	radar.npccol	= Color( 255, 0, 0, 255 ) 					  // Color of the NPC's name and dot.											DEF = Color( 0, 0, 255, 255 )
	radar.enpcol	= Color( 255, 0, 0, 255 ) 					  // Enemies color.																DEF = Color( 255, 0, 0, 255 )
	radar.half		= radar.size / 2		  					  // Divides the size by two to make a centured cross.
	radar.selfhalf	= radar.selfsize / 2	 			 		  // Divides the box size by 2 to centure it.
	radar.xm		= radar.x + radar.half	  					  // Center of radar. (x)
	radar.ym		= radar.y + radar.half	  					  // Center of radar. (y)
	radar.xo		= radar.x				  					  // Radar outline. (x)
	radar.yo		= radar.y				  					  // Radar outline. (y)
  
			// Radar GUI - Edit everything above to edit these.
			draw.RoundedBox( radar.round, radar.x, radar.y, radar.size, radar.size, radar.col )
			surface.SetDrawColor( radar.outcol )
			surface.DrawLine( radar.xm, radar.ym - radar.csize, radar.xm, radar.ym + radar.csize )
			surface.DrawLine( radar.xm - radar.csize, radar.ym, radar.xm + radar.csize, radar.ym )
			surface.SetDrawColor( radar.outcol )
			surface.DrawLine( radar.xo, radar.yo, radar.xo, radar.yo + radar.size )
			surface.DrawLine( radar.xo + radar.size, radar.yo, radar.xo + radar.size, radar.yo + radar.size )
			surface.DrawLine( radar.xo, radar.yo, radar.xo + radar.size, radar.yo )
			surface.DrawLine( radar.xo, radar.yo + radar.size, radar.xo + radar.size, radar.yo + radar.size )
			draw.RoundedBox( radar.selfround, radar.xm - radar.selfhalf, radar.ym - radar.selfhalf, radar.selfsize, radar.selfsize, radar.selfcol )
			
		// Radar code thanks to Georg Schmid; I'm only good at creating GUI's n stuff.
			for _, v in pairs( player.GetAll() ) do
			local ply = LocalPlayer()
			

			local col
				if GetConVarNumber( prefix.."color"..endprefix ) == 0 then
						local tc  = team.GetColor( v:Team() )
						col = Color( tc.r, tc.g, tc.b, 255 )
					end
				if GetConVarNumber( prefix.."color"..endprefix ) == 1 then
						if v:Team() == ply:Team() then
						col = Color( 255, 0, 0, 255 )
						elseif v:Team() ~= ply:Team() then
						col = Color( 0, 255, 0, 255 )
					end
				end

				local cenx = radar.x + radar.size / 2
				local ceny = radar.y + radar.size / 2
				local tc = team.GetColor( v:Team() )
				local gpos = v:GetPos() - LocalPlayer():GetPos()
					if v:IsPlayer() and v:Alive() and v ~=ply and gpos:Length() <= radar.radius then
						local pixx = gpos.x / radar.radius
						local pixy = gpos.y / radar.radius
							local root = math.sqrt( pixx * pixx + pixy * pixy )
							local find = math.Deg2Rad( math.Rad2Deg( math.atan2( pixx, pixy ) ) - math.Rad2Deg( math.atan2( LocalPlayer():GetAimVector().x, LocalPlayer():GetAimVector().y ) ) - 90)
								local pixx = math.cos( find ) * root
								local pixy = math.sin( find ) * root
									if radar.plydot then
										draw.RoundedBox( 1, cenx + pixx * radar.size / 2 - 0, ceny + pixy * radar.size / 2 - 4, 5, 5, col )
									end
									if radar.plyname then
										draw.SimpleText( v:Nick(), "DefaultSmall", cenx + pixx * radar.size / 2, ceny + pixy * radar.size / 2 - 10, col, 1, 1 )
											end
										end
									end
			for _, ent in pairs( ents.GetAll() ) do
				if ent:IsValid() then
				local cenx = radar.x + radar.size / 2
				local ceny = radar.y + radar.size / 2
				local gpos = ent:GetPos() - LocalPlayer():GetPos()
					if gpos:Length() <= radar.radius then
						local pixx = gpos.x / radar.radius
						local pixy = gpos.y / radar.radius
							local root = math.sqrt( pixx * pixx + pixy * pixy )
							local find = math.Deg2Rad( math.Rad2Deg( math.atan2( pixx, pixy ) ) - math.Rad2Deg( math.atan2( LocalPlayer():GetAimVector().x, LocalPlayer():GetAimVector().y ) ) - 90)
								local pixx = math.cos( find ) * root
								local pixy = math.sin( find ) * root
								if ent:IsNPC() and ent:GetMoveType() !=0 then
								if radar.npcdot then
										draw.RoundedBox( 1, cenx + pixx * radar.size / 2 - 4, ceny + pixy * radar.size / 2 - 4, 4, 4, radar.npccol )
									end
								end
							end
						end
					end
				end
			end
NewHook( "HUDPaint", Drawradar )

// ********************
// Miscellaneous:
// ********************

// Bunnyhop - Allows you to jump constantly. Note this will not work if a server blocks hooks.
concommand.Add( "+bhop", function()
	hook.Add( "Tick", " ~Bunnyhop", function()
		local ply = LocalPlayer()
			if not ply:IsOnGround() then
				RunConsoleCommand( "-jump" )
			elseif ply:IsOnGround() then
				RunConsoleCommand( "+jump" )
			end
		end )
	end )
concommand.Add( "-bhop", function()
	hook.Remove( "Tick", " ~Bunnyhop" )
end )

//Speed Hack - Lets you go faster than everyone else.
concommand.Add( "+speedhack", function()
	SetConvar( CreateConVar( "host_framerate", "" ), ( GetConVarNumber( prefix.."speedvalue"..endprefix ) ) )
end)
concommand.Add( "-speedhack", function()
	SetConvar( CreateConVar( "host_framerate", "" ), 0 )
end)


// Hook Removels - Removes some hooks that will mess your screen up.
if ( GetConVarNumber( prefix.."removeoverlays"..endprefix ) == 1 ) then
	hook.Remove( "HUDPaint", "ulx_blind" )
	hook.Remove("RenderScreenspaceEffects", "Drugged")
	hook.Remove("RenderScreenspaceEffects", "durgz_alcohol_high")
	hook.Remove("RenderScreenspaceEffects", "durgz_cigarette_high")
	hook.Remove("RenderScreenspaceEffects", "durgz_cocaine_high")
	hook.Remove("RenderScreenspaceEffects", "durgz_heroine_high")
	hook.Remove("HUDPaint", "durgz_heroine_notice")
	hook.Remove("RenderScreenspaceEffects", "durgz_lsd_high")
	hook.Remove("RenderScreenspaceEffects", "durgz_mushroom_high")
	hook.Remove("HUDPaint", "durgz_mushroom_awesomeface")
	hook.Remove("RenderScreenspaceEffects", "durgz_weed_high")
	hook.Remove("HUDPaint", "FlashEffect")
	hook.Remove("RenderScreenspaceEffects", "StunEffect")
	hook.Remove("HUDPaint", "durgz_cigarette_msg")
	hook.Remove("RenderScreenspaceEffects", "durgz_pcp_high")
end

// Nospread? - By deco

/*if ( GetConVarNumber( "pb_nospread" ) == 1 ) and not RAPID_FIRE then
local cmd, seed = hl2_ucmd_getprediciton(UCMD)
if cmd ~= 0 then
currentseed = seed
end
previous_ang = previous_ang or ang
local wep = LocalPlayer():GetActiveWeapon()
local cone
if wep and wep:IsValid() then
cone = -(tonumber(GetWepVal(wep:GetTable(), "Cone")) or tonumber(GetWepVal(wep:GetTable(), "Spread")) or GetFalloutCone(wep:GetTable(), nil, wep) or 0)
else
cone = 0
end
--print(cone)
if cone ~= 0 then
local ang = hl2_shotmanip(currentseed or 0, previous_ang:Forward(), Vector(cone, cone, cone)):Angle()
if memory then
memory.SetVector(UCMD, 8, Vector(0, ang.p, ang.y))
else
UCMD:SetViewAngles(ang)
end
ccc = true
end
cmd = UCMD:GetCommandNumber()
if cmd ~= 0 then
currentseed = MD5_PseudoRandom(cmd)
end
cone = cone or 0
view_adjust = manipulate_shot(currentseed, view_adjust:Forward(), Vector(-cone, -cone, -cone)):Angle()
end*/