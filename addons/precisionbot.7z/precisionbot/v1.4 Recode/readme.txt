Precisionbot Public
Current verison, 1.4 BETA
Coded by fr1kin and snipplets from other coders.

THIS IS A BETA RELEASE, NOT EVERYTHING HAS BEEN CODED YET!

Install:
	PATH: C:/program files/steam/steamapps/**username**/garrysmod/garrysmod..
	* Inside there the lua should merge with lua inside garrysmod.
	* C: If you have multiple drives, the steam location might not be in 'C:' but others like 'D:' or 'E:'.
	* If your computer is 64 bit the program files will be nammed 'Program Files(x86)'.










* Send your suggestions to http://www.youtube.com/user/fr1kins *