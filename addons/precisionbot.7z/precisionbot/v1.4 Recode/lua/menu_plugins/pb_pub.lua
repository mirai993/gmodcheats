--[[------------------------------------------------------------------------------
 ______                   __         __               __           __  	
|   __ \.----.-----.----.|__|.-----.|__|.-----.-----.|  |--.-----.|  |_ 
|    __/|   _|  -__|  __||  ||__ --||  ||  _  |     ||  _  |  _  ||   _|
|___|   |__| |_____|____||__||_____||__||_____|__|__||_____|_____||____|
 ______                      __        
|   __ \.-----.----.-----.--|  |.-----.
|      <|  -__|  __|  _  |  _  ||  -__|
|___|__||_____|____|_____|_____||_____|
--]]------------------------------------------------------------------------------
local changelog, menuallow, curVer = "No data", true, 0
function AddData( typ, date, ver, add )
	if ( changelog == "No data" ) then changelog = "" end
	changelog = changelog .. typ .. "[ " .. date .. " ][ Version " .. ver .. " ]\n" .. add .. "\n"
	curVer = tonumber( ver )
end

AddData( "Release", "12/2/2010", "1.4", " - Recoded\n THIS IS A BETA RELEASE, NOT EVERYTHING HAS BEEN ADDED." )

local webs = "http://precisionbot.hostwebs.com/precisionbot/version.txt"

local nButton
function AddButton( name, posX, posY, sizeW, sizeH, parent, func )
	if ( func == "" ) then func = function() end end
	local button = vgui.Create( "DButton" )
	if ( parent != nil ) then button:SetParent( parent ) end
	button:SetSize( sizeW, sizeH )
	button:SetPos( posX, posY )
	button:SetText( name )
	button.DoClick = func
	nButton = button
end

local FileCheck, disabled, menu
function LoadMenu()
	local panel = vgui.Create( "DFrame" )
	panel:SetPos( ScrW() / 2 - 400 / 2, ScrH() / 2 - 250 / 2 )
	panel:SetSize( 400, 250 )
	panel:SetTitle( "Precisionbot Loader" )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:MakePopup()
	menu = panel
	
	local propsheet = vgui.Create( "DPropertySheet" )
	propsheet:SetParent( panel )
	propsheet:SetPos( 10, 30 )
	propsheet:SetSize( 380, 210 )
	
	local home = vgui.Create( "DPanel", propsheet )
	local logs = vgui.Create( "DPanel", propsheet )
	
	// Home
	local checkbox = vgui.Create( "DCheckBoxLabel" )
	checkbox:SetPos( 10, 10 )
	checkbox:SetText( "Do file check" )
	checkbox:SetParent( home )
	checkbox:SetTextColor( Color( 0, 0, 0, 255 ) )
	checkbox:SizeToContents()
	checkbox:Toggle()
	
	timer.Create( "DOCHECKS", 0.01, 0, function()
		if ( panel:IsVisible() ) then
			FileCheck = checkbox:GetChecked()
		end
	end )
	
	local text, r, g = "", 0, 0
	function ErrorLabel()
		local label = vgui.Create( "DLabel" )
		label:SetParent( home )
		label:SetText( text )
		label:SetPos( 100, 150 )
		label:SetWide( 100 )
		label:SetTextColor( Color( r, g, 0 ) )
		label:SizeToContents()
	end
	
	local update, update_text, update_r, update_g = false, "", 0, 0
	function Updatelabel()
		local label = vgui.Create( "DLabel" )
		label:SetParent( home )
		label:SetText( update_text )
		label:SetPos( 250, 10 )
		label:SetWide( 100 )
		label:SetTextColor( Color( update_r, update_g, 0 ) )
		label:SizeToContents()
		
		local image = vgui.Create( "DImage" )
		image:SetParent( home )
		image:SetPos( 225, 10 )
		if ( update ) then image:SetImage( "gui/silkicons/check_on" ) else image:SetImage( "gui/silkicons/check_off" ) end
		image:SizeToContents()
	end
	
	function FindFiles()
		if ( FileCheck ) then
			if ( #file.Find( "../lua/autorun/client/pb_pub.lua" ) >= 1 ) then
				text = "Found file pb_pub.lua, loading..."
				r = 0
				g = 128
				nButton:SetDisabled( true )
				disabled = true
				ErrorLabel()
			elseif ( #file.Find( "../lua/autorun/client/pb_pub.lua" ) == 0 ) then
				text = "Didn't find file pb_pub.lua! Not loading..."
				r = 255
				g = 0
				ErrorLabel()
				nButton:SetEnabled( true )
				disabled = false
			end
		elseif ( !FileCheck ) then
			text = "Loading pb_pub.lua without file checks"
			r = 0
			g = 128
			nButton:SetDisabled( true )
			ErrorLabel()
			disabled = true
		end
	end
	
	// Thanks to Flapadar for this.
	function NewestVersion( c )
	local s = string.Explode( "\n", c )
		if ( string.find( s[1], "HELLO HUMANS" ) ) then
			local newVer = tonumber( s[2] )
			if ( newVer > curVer ) then
				update = false
				update_text = "New version out, " .. newVer .. "."
				update_r = 255
				update_g = 0
				Updatelabel()
			else
				update = true
				update_text = "No updates found."
				update_r = 0
				update_g = 128
				Updatelabel()
			end
		end
	end
	
	local function IsUpdated()
		http.Get( webs, "", function( c, s )
			if ( s > 0 ) then
				NewestVersion( c )
				Updatelabel()
			else
				update = false
				update_text = "Lost connection."
			end
		end )
	end
	IsUpdated()
	
	timer.Create( "DOBUTTONCHECKS", 0.01, 0, function()
		if ( panel:IsVisible() ) then
			if ( disabled ) then
				nButton:SetDisabled( true )
			else
				nButton:SetEnabled( true )
			end
		end
	end )
	
	AddButton( "Load", 10, 145, 75, 25, home, function() CreateClientConVar( "pb_load", 0, false, false ) FindFiles() end )
	
	// Changelog
	function Changelog()
		local text = vgui.Create( "DTextEntry" )
		text:SetParent( logs )
		text:SetPos( 10, 10 )
		text:SetTall( 160 )
		text:SetWide( 350 )
		text:SetMultiline( true )
		text:SetEditable( false )
		text:SetValue( changelog )
	end
	Changelog()
	
	propsheet:AddSheet( "Home", home, nil, false, false, nil )
	propsheet:AddSheet( "Changelog", logs, nil, false, false, nil )
end

function ConsoleMenu() // Normaly, you can make a consolecommand, but risk detections.
	AddButton( "Options", 10, 10, 75, 35, nil, function()
		local Menu = DermaMenu()
		Menu:AddOption( "Open Menu", function() if ( !menu:IsVisible() ) then LoadMenu() end end )
		Menu:AddOption( "Close Menu", function() if ( menu:IsVisible() ) then menu:SetVisible( false ) end end )
		if ( !disabled ) then
			Menu:AddOption( "Load Script", function() CreateClientConVar( "pb_load", 0, false, false ) disabled = true end )
		end
		Menu:Open()
	end )
end

ConsoleMenu()
LoadMenu()