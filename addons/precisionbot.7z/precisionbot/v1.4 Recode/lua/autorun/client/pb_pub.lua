--[[------------------------------------------------------------------------------
 ______                   __         __               __           __  	
|   __ \.----.-----.----.|__|.-----.|__|.-----.-----.|  |--.-----.|  |_ 
|    __/|   _|  -__|  __||  ||__ --||  ||  _  |     ||  _  |  _  ||   _|
|___|   |__| |_____|____||__||_____||__||_____|__|__||_____|_____||____|
 ______                      __        
|   __ \.-----.----.-----.--|  |.-----.
|      <|  -__|  __|  _  |  _  ||  -__|
|___|__||_____|____|_____|_____||_____|
--]]------------------------------------------------------------------------------
if !( CLIENT ) then return end
if !( ConVarExists( "pb_load" ) ) then return end

local PB 					= {}
PB.hooks					= {}
PB.commands					= {}
PB.features					= {}
PB.info						= {}
PB.old						= {}

PB.old.GetConVar			= GetConVar
PB.old.ConVarExists			= ConVarExists
PB.old.GetConVarNumber		= GetConVarNumber
PB.old.GetConVarString		= GetConVarString
PB.old.engineConsoleCommand = engineConsoleCommand
PB.old.GetConVar			= GetConVar
PB.old.hook					= table.Copy( hook )
PB.old.cvars				= table.Copy( cvars )
PB.old.file					= table.Copy( file )
PB.old.debug				= table.Copy( debug )

PB.set = {
	tar = nil,
	target = nil,
	aiming = false,
	angles = Angle( 0, 0, 0 ),
	filepath = "lua\\autorun\\client\\pb_pub.lua",
}

PB.files = {
	"pb_pub",
	"pb_material",
}

PB.convars = {
	{ Name = "pb_load", Value = 0, Extra = "", Type = "", Table = "" },
	{ Name = "pb_aim_shoot", Value = 1, Extra = "Autoshoot", Type = "bool", Table = "autoshoot" },
	{ Name = "pb_aim_trigger", Value = 0, Extra = "Triggerbot", Type = "bool", Table = "triggerbot" },
	{ Name = "pb_aim_friendlyfire", Value = 1, Extra = "Friendlyfire", Type = "bool", Table = "friendlyfire" },
	{ Name = "pb_aim_igsteam", Value = 0, Extra = "Ignore Steam", Type = "bool", Table = "ignoresteam" },
	{ Name = "pb_aim_player", Value = 1, Extra = "Target Players", Type = "bool", Table = "playeraim" },
	{ Name = "pb_aim_npc", Value = 0, Extra = "Target NPCs", Type = "bool", Table = "npcaim" },
	{ Name = "pb_esp_player", Value = 1, Extra = "Player HUD", Type = "bool", Table = "playeresp" },
	{ Name = "pb_esp_npc", Value = 1, Extra = "NPC HUD", Type = "bool", Table = "npcesp" },
	{ Name = "pb_esp_weapons", Value = 0, Extra = "Weapon HUD", Type = "bool", Table = "weaponesp" },
	{ Name = "pb_esp_xqz", Value = 1, Extra = "XQZ Walls", Type = "bool", Table = "xqz" },
	{ Name = "pb_misc_bunnyhop", Value = 0, Extra = "Bunnyhop", Type = "bool", Table = "bunnyhop" },
	{ Name = "pb_misc_autopistol", Value = 0, Extra = "Autopistol", Type = "bool", Table = "autopistol" },
	{ Name = "pb_misc_drawfov", Value = 0, Extra = "Draw-FOV", Type = "bool", Table = "drawfov" },
	{ Name = "pb_misc_cross", Value = 1, Extra = "Crosshair", Type = "bool", Table = "cross" },
	{ Name = "pb_aim_offset", Value = 0, Extra = "Vector Offset", Type = "number", Table = "vectoroffset", Max = 50, Min = -50 },
	{ Name = "pb_aim_fov", Value = 180, Extra = "Field-of-View", Type = "number", Table = "fov", Max = 180, Min = 0 },
	{ Name = "pb_aim_mode", Value = 1, Extra = "Aimmode", Type = "number", Table = "aimmode", Max = 2, Min = 1 },
}

PB.deathsequences = {
	[ "models/barnacle.mdl" ] = { 4, 15 },
	[ "models/antlion_guard.mdl" ] = { 44 },
	[ "models/hunter.mdl" ] = { 124, 125, 126, 127, 128 }
}

local oldCallHook = hook.Call

local function CallHook( name, gm, ... ) -- omfg i steal from seth
	if ( PB.hooks[ name ] ) then
		PB.old.hook.Call( name, gm, unpack( arg ) )
		return PB.hooks[ name ]( unpack( arg ) )
	end
	return PB.old.hook.Call( name, gm, unpack( arg ) )
end

hook = {}

setmetatable( hook, 
	{ __index = function( t, k )
		if( k == "Call" ) then 
			return CallHook
		end
		return PB.old.hook[ k ] end,
		
		__newindex = function( t, k, v ) 
			if( k == "Call" ) then 
				if( v != CallHook ) then 
					oldCallHook = v 
				end 
				return
			end
			PB.old.hook[k] = v 
		end,
		__metatable = true
	}
)

function PB:AddHook( name, func )
	PB.hooks[ name ] = func
end

function engineConsoleCommand( p, c, a )
	local l = string.lower( c )
	if ( PB.commands[ l ] ) then
		PB.commands[ l ]( p, c, a )
		return true
	end
	return PB.old.engineConsoleCommand( p, c, a )
end

function PB:AddCommand( name, func )
	PB.commands[ name ] = func
	AddConsoleCommand( name )
end

local path, write = {}

function GetConVar( cvar )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.GetConVar( cvar ) end
	for k, v in pairs( PB.convars ) do
		if ( string.find( string.lower( cvar ), v.Name ) ) then
			return
		end
	end
	return PB.old.GetConVar( cvar )
end

function ConVarExists( cvar )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.ConVarExists( cvar ) end
	for k, v in pairs( PB.convars ) do
		if ( string.find( string.lower( cvar ), v.Name ) ) then
			return false
		end
	end
	return PB.old.ConVarExists( cvar )
end

function GetConVarNumber( cvar )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.GetConVarNumber( cvar ) end
	for k, v in pairs( PB.convars ) do
		if ( string.find( string.lower( cvar ), v.Name ) ) then
			return
		end
	end
	return PB.old.GetConVarNumber( cvar )
end

function GetConVarString( cvar )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.GetConVarString( cvar ) end
	for k, v in pairs( PB.convars ) do
		if ( string.find( string.lower( cvar ), v.Name ) ) then
			return
		end
	end
	return PB.old.GetConVarString( cvar )
end

function file.CreateDir( dir )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.CreateDir( dir ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( dir ), v ) ) then
			path[ dir ] = true
			return
		end
	end
	return PB.old.file.CreateDir( dir )
end

function file.Delete( name )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Delete( name ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			write[ name ] = nil
			return
		end
	end
	return PB.old.file.Delete( name )
end

function file.Read( name, folder )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Read( name, folder ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return write[path] && write[path].cont || nil
		end
	end
	return PB.old.file.Read( name, folder )
end

function file.Exists( name, folder )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Exists( name, folder ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return write[path] && true || false
		end
	end
	return PB.old.file.Exists( name, folder )
end

function file.ExistsEx( name, folder )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Exists( name, folder ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return write[path] && true || false
		end
	end
	return PB.old.file.ExistsEx( name, folder )
end

function file.Write( name, folder, ... )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Write( name, folder, ... ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return nil
		end
	end
	return PB.old.file.Write( name, folder, ... )
end

function file.Time( name )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Time( name ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return write[path] && write[path].time || 0
		end
	end
	return PB.old.file.Time( name )
end

function file.Size( name )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Size( name ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			return write[path] && write[path].size || -1
		end
	end
	return PB.old.file.Size( name )
end

function file.Find( name, path )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Find( name, path ) end
	
	local oldfind = PB.old.file.Find( name, path )
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			if ( !write[ v ] ) then
				oldfind[ k ] = nil
			end
		end
	end
	return PB.old.file.Find( name, path )
end

function file.FindInLua( name )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.FindInLua( name ) end
	
	local oldfind = PB.old.file.FindInLua( name )
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			oldfind[ k ] = nil
		end
	end
	return PB.old.file.FindInLua( name )
end

function file.Rename( name, new )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.file.Rename( name, new ) end
	for k, v in pairs( PB.files ) do
		if ( string.find( string.lower( name ), v ) ) then
			if ( write[ name ] ) then
				write[ new ] = table.Copy( write[ name ] )
				write[ path ] = nil
			end
		end
	end
	return PB.old.file.Rename( name )
end

function file.TFind( name, call )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory ) then
		return PB.old.file.TFind( name, function( name, folder, files )
			for k, v in pairs( folder ) do
				if ( string.find( string.lower( name ), v ) ) then
					folder[ k ] = nil
				end
			end
			for k, v in pairs( files ) do
				if ( string.find( string.lower( name ), PB.files[ name ] ) ) then
					files[ k ] = nil
				end
			end
			return call( path, folder, files )
		end )
	end
	return PB.old.file.TFind( name, function( path, folder, files ) 
		return call( path, folder, files )
	end )
end	

function debug.getinfo( name, path )
	local calldirectory = PB.old.debug.getinfo(2)['short_src']
	if ( calldirectory && calldirectory == PB.set.filepath ) then return PB.old.debug.getinfo( name, path ) end
	return
end

for k, v in pairs( PB.convars ) do
	if ( v.Name == "pb_load" ) then
	else
		local convar = CreateClientConVar( v.Name, v.Value, true, false )
		local cvarinfo = { Name = v.Name, Value = v.Value, Desc = v.Extra, Type = v.Type, Max = v.Max, Min = v.Min }
		PB.features[ v.Table ] = convar:GetInt()
		PB.info[ v.Name ] 		= cvarinfo
		PB.info[ #PB.info + 1 ]	= cvarinfo	
		PB.old.cvars.AddChangeCallback( v.Name, function( cvar, old, new )
			PB.features[ v.Table ] = new
		end )
	end
end

function toboolnumber( var )
	return math.floor( var ) == 1
end

------------------------------
-- Now I can get started coding
------------------------------
function PB:FilterConVars( e, use )
	if ( !ValidEntity( e ) ) then return end
	
	if ( use == "hud" ) then
		if ( !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() ) then return false end
		if ( e:IsPlayer() && ( tonumber( PB.features.playeresp ) == 0 ) ) then return false end
		if ( e:IsNPC() && ( tonumber( PB.features.npcesp ) == 0 ) ) then return false end
		if ( e:IsWeapon() && ( tonumber( PB.features.weaponesp ) == 0 ) ) then return false end
		return true
	elseif ( use == "aim" ) then
		if ( !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() ) then return false end
		if ( e:IsPlayer() && ( tonumber( PB.features.playeraim ) == 0 ) ) then return false end
		if ( e:IsNPC() && ( tonumber( PB.features.npcaim ) == 0 ) ) then return false end
		if ( e:IsWeapon() && ( tonumber( PB.features.playeraim ) == 0 ) && ( tonumber( PB.features.npcaim ) == 0 ) ) then return false end
		return true
	end
	return true
end

function PB:FilterEntities( e, use )
	if ( !ValidEntity( e ) ) then return false end
	
	local ply, model = LocalPlayer(), string.lower( e:GetModel() || "" )
	if ( use == "esp" ) then
		if ( !e:IsValid() || ( !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() ) || e == ply ) then return false end
		if ( e:IsPlayer() && ( !e:Alive() ) || ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) ) then return false end
		if ( e:IsNPC() && ( e:GetMoveType() == MOVETYPE_NONE ) ) then return false end
		if ( e:IsWeapon() && ( e:GetMoveType() == MOVETYPE_NONE ) ) then return false end
		if ( !PB:FilterConVars( e, "hud" ) ) then return false end
		return true
	elseif ( use == "cham" ) then
		if ( !e:IsValid() || ( !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() ) || e == ply ) then return false end
		if ( e:IsPlayer() && ( !e:Alive() ) || ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) ) then return false end
		if ( e:IsNPC() && ( e:GetMoveType() == MOVETYPE_NONE ) ) then return false end
		if ( e:IsWeapon() && ( e:GetMoveType() != MOVETYPE_NONE ) ) then return false end
		if ( !PB:FilterConVars( e, "hud" ) ) then return false end
		return true
	elseif ( use == "aim" ) then
		if ( !e:IsValid() || ( !e:IsPlayer() && !e:IsNPC() ) || e == ply ) then return false end
		if ( e:IsPlayer() && ( !e:Alive() ) || ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) || ( e:IsPlayer() && ( tonumber( PB.features.friendlyfire ) == 1 ) && e:Team() == ply:Team() ) || ( e:IsPlayer() && ( tonumber( PB.features.steam ) == 0 ) && ( e:GetFriendStatus() == "friend" ) ) ) then return false end
		if ( e:IsNPC() && ( e:GetMoveType() == MOVETYPE_NONE ) ) then return false end
		if ( !PB:FilterConVars( e, "aim" ) ) then return false end
		return true
	end
	return true
end

function PB:FilterColors( e )
	local col
	if ( e:IsPlayer() ) then
		local tc = team.GetColor( e:Team() )
		col = Color( tc.r, tc.g, tc.b, a )
	elseif ( e:IsNPC() ) then
		if ( !IsEnemyEntityName( e:GetClass() ) && !( e:GetClass() == "npc_metropolice" ) ) then
			col = Color( 0, 100, 0, 255 )
		elseif ( IsEnemyEntityName( e:GetClass() ) || ( e:GetClass() == "npc_metropolice" ) ) then
			col = Color( 230, 0, 0, 255 )
		end
	elseif ( e:IsWeapon() ) then
		if ( e:GetMoveType() == MOVETYPE_NONE ) then
			col = Color( 255, 255, 255, 255 )
		elseif ( e:GetMoveType() != MOVETYPE_NONE ) then
			col = Color( 215, 100, 0, 255 )
		end
	end
	return col
end

function PB:CreateVectors( e )
	local ply, pos = LocalPlayer(), nil
	local col = PB:FilterColors( e )
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY, pos
end

function PB:DrawCircle( rad ) -- GMod wiki stuff here
	local center = Vector( ScrW() / 2, ScrH() / 2, 0 )
	local scale = Vector( rad, rad, 0 )
	local segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
	surface.SetDrawColor( 255, 255, 255, 255 )
 
	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
	end
end


--[[----------
	:: Aimbot
--]]----------
function PB:GetPos( e, pos )
	if ( type( pos ) == "string" ) then
		return ( e:GetBonePosition( e:LookupBone( pos ) ) )
	elseif ( type( pos ) == "Vector" ) then
		return ( e:LocalToWorld( pos ) )
	end
	return ( e:LocalToWorld( pos ) )
end

function PB:LockPosition( e )
	local pos = e:LocalToWorld( e:OBBCenter() )
	
	pos = PB:GetPos( e, "ValveBiped.Bip01_Head1" )
	
	if ( e:IsPlayer() ) then
		pos = e:GetAttachment( e:LookupAttachment( "eyes" ) ).Pos
		if ( ( e:GetAttachment( e:LookupAttachment( "forward" ) ) ) ) then
			pos = e:GetAttachment( e:LookupAttachment( "forward" ) ).Pos
		elseif ( pos != 0 ) then
			pos = PB:GetPos( e, "ValveBiped.Bip01_Head1" )
		end
	end
	
	local m = e:GetModel()
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then 	pos = PB:GetPos( e, Vector( 0, 0, 5 ) ) end
	if ( m == "models/seagull.mdl" ) then 							pos = PB:GetPos( e, Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then 					pos = PB:GetPos( e, "Scanner.Body" ) end
	if ( m == "models/hunter.mdl" ) then 							pos = PB:GetPos( e, "MiniStrider.body_joint" ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then		pos = PB:GetPos( e, "Barrel" ) end
	if ( m == "models/dog.mdl" ) then 								pos = PB:GetPos( e, "Dog_Model.Eye" ) end
	if ( m == "models/vortigaunt.mdl" ) then 						pos = PB:GetPos( e, "ValveBiped.Head" ) end
	if ( m == "models/antlion.mdl" ) then 							pos = PB:GetPos( e, "Antlion.Body_Bone" ) end
	if ( m == "models/antlion_guard.mdl" ) then 					pos = PB:GetPos( e, "Antlion_Guard.Body" ) end
	if ( m == "models/antlion_worker.mdl" ) then 					pos = PB:GetPos( e, "Antlion.Head_Bone" ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then 				pos = PB:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/zombie/fast.mdl" ) then 						pos = PB:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/headcrabclassic.mdl" ) then 					pos = PB:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/headcrabblack.mdl" ) then 					pos = PB:GetPos( e, "HCBlack.body" ) end
	if ( m == "models/headcrab.mdl" ) then 							pos = PB:GetPos( e, "HCFast.body" ) end
	if ( m == "models/zombie/poison.mdl" ) then 					pos = PB:GetPos( e, "ValveBiped.Headcrab_Cube1" ) end
	if ( m == "models/zombie/classic.mdl" ) then 					pos = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then 				pos = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then				pos = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/combine_strider.mdl" ) then 					pos = PB:GetPos( e, "Combine_Strider.Body_Bone" ) end
	if ( m == "models/combine_dropship.mdl" ) then 					pos = PB:GetPos( e, "D_ship.Spine1" ) end
	if ( m == "models/combine_helicopter.mdl" ) then 				pos = PB:GetPos( e, "Chopper.Body" ) end
	if ( m == "models/gunship.mdl" ) then 							pos = PB:GetPos( e, "Gunship.Body" ) end
	if ( m == "models/lamarr.mdl" ) then 							pos = PB:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/mortarsynth.mdl" ) then 						pos = PB:GetPos( e, "Root Bone" ) end
	if ( m == "models/synth.mdl" ) then 							pos = PB:GetPos( e, "Bip02 Spine1" ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then 				pos = PB:GetPos( e, "ValveBiped.Head" ) end
	
	return pos
end

function PB:GetAngles( ucmd, angle )
	local ply, correct = LocalPlayer(), 1
	
	angle = ucmd:GetViewAngles()
	if !( IsValid( ply:GetActiveWeapon() ) && ( ply:GetActiveWeapon():GetClass() == "weapon_physgun" ) && ( ucmd:GetButtons() & IN_USE ) > 0 ) then
		local mouse = Angle( ucmd:GetMouseY() * PB.old.GetConVarNumber( "m_pitch" ), ucmd:GetMouseX() * -PB.old.GetConVarNumber("m_yaw") ) || Angle( 0, 0, 0 )
		angle = angle + mouse
		
		angle.p = math.NormalizeAngle( angle.p )
		angle.y = math.NormalizeAngle( angle.y )
		
		angle.y = math.NormalizeAngle( angle.y + ( ucmd:GetMouseX() * -0.022 * correct ) )
		angle.p = math.Clamp( angle.p + ( ucmd:GetMouseY() * 0.022 * correct ), -89, 90 )
	end
end

function PB:CreateSelfTrace( e )
	local ply = LocalPlayer()
	local start, endP = ply:GetShootPos(), ply:GetAimVector()
	
	local trace = {}
	trace.start = start
	trace.endpos = start + ( endP * 16384 )
	trace.filter = { ply }
	
	return util.TraceLine( trace )
end

local shoot = false

function PB:Auto()
	if ( string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) ) then return false end
	local ply, weps = LocalPlayer(), { "gmod_tool", "weapon_pistol" }
	
	if ( !ValidEntity( ply ) || !ply:Alive() || !ply:GetActiveWeapon():IsValid() ) then return false end
	if ( !ply:KeyDown( IN_ATTACK ) ) then return false end
	
	local wep = ply:GetActiveWeapon()
	if ( table.HasValue( weps, wep:GetClass() ) ) then
		return true
	elseif ( wep.Primary && !wep.Primary.Automatic ) then
		return true
	end
	return false
end

function PB:Autopistol()
	local ply = LocalPlayer()
	
	if ( ( tonumber( PB.features.autopistol ) == 1 ) && input.IsMouseDown( MOUSE_LEFT ) && PB:Auto() ) then
		if ( shoot ) then
			RunConsoleCommand( "+attack" )
			shoot = false
		elseif ( !shoot ) then
			RunConsoleCommand( "-attack" )
			shoot = true
		end
	elseif ( ( tonumber( PB.features.autopistol ) == 1 ) && !input.IsMouseDown( MOUSE_LEFT ) ) then
		if ( !shoot ) then
			RunConsoleCommand( "-attack" )
			shoot = true
		end
	end
end

function PB:Visible( e )
	local ply, pos = LocalPlayer(), PB:LockPosition( e )
	
	local etrace = {
		start = ply:GetShootPos(),
		endpos = pos,
		filter = { ply, e }
	}
	local trace = util.TraceLine( etrace )
	
	if ( trace.Fraction == 1 ) then
		return true
	end
	return false
end

function PB:ValidType()
	local ply, use, targets = LocalPlayer(), player.GetAll(), {}
	
	if ( PB.features.npcaim == 0 ) then
		use = player.GetAll()
	else use = ents.GetAll() end
	
	for i = 1, table.Count( use ) do
		local e = use[ i ]
		if ( ValidEntity( e ) && PB:FilterEntities( e, "aim" ) && PB:Visible( e ) ) then
			table.insert( targets, e )
		end
	end
	return targets
end

function PB:GetTarget()
	local ply, x ,y = LocalPlayer(), ScrW(), ScrH()
	if ( !PB.set.aiming ) then return end
	
	local targets, trace = PB:ValidType(), PB:CreateSelfTrace( e )
	local myPos, myAng, myAngV = ply:EyePos(), ply:GetAimVector(), ply:GetAngles()
	
	if ( !PB:FilterEntities( PB.set.tar, "aim" ) || ( trace.HitWorld || util.IsValidProp( trace.Entity:GetModel() ) ) ) then -- Will help reduce lag
		PB.set.tar = nil
		
		PB.set.tar = LocalPlayer()
		
		for i = 1, table.Count( targets ) do
			local e = targets[ i ]
			
			local ePos, oldPos = e:EyePos():ToScreen(), PB.set.tar:EyePos():ToScreen()
			local angA, angB = 0, 1
			
			local angle = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local angleY = math.abs( math.NormalizeAngle( myAngV.y - angle.y ) )
			local angleP = math.abs( math.NormalizeAngle( myAngV.p - angle.p ) )
			
			if ( angleY < tonumber( PB.features.fov ) && angleP < tonumber( PB.features.fov ) ) then
			
				if ( tonumber( PB.features.aimmode ) == 1 ) then
					angA = math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
					angB = math.Dist( x / 2, y / 2, ePos.x, ePos.y )
				elseif ( tonumber( PB.features.aimmode ) == 2 ) then
					angA = PB.set.tar:EyePos():Distance( ply:EyePos() )
					angB = e:EyePos():Distance( ply:EyePos() )
				end
			
				if ( angB <= angA ) then
					PB.set.tar = e
				elseif ( PB.set.tar == ply ) then
					PB.set.tar = e
				end
			end
		end
	end
	return PB.set.tar
end

function PB.KeepView()
	local ply = LocalPlayer()
	if ( !ValidEntity( ply ) ) then return end
	PB.set.angles = ply:EyeAngles()
end
PB:AddHook( "OnToggled", PB.KeepView )

function PB.Aim( ucmd )
	local ply = LocalPlayer()
	PB.set.target = PB:GetTarget()
	
	if ( ( IsValid( ply:GetActiveWeapon()) && ply:GetActiveWeapon():GetClass() == "weapon_physgun" && ( ucmd:GetButtons() & IN_USE ) > 0 ) ) then return end
	
	local ply, sensitivity = LocalPlayer(), 0.022
	
	PB.set.angles.p = math.Clamp( PB.set.angles.p + ( ucmd:GetMouseY() * sensitivity ), -89, 89 )
	PB.set.angles.y = math.NormalizeAngle( PB.set.angles.y + ( ucmd:GetMouseX() * sensitivity * -1 ) )
	
	PB.set.angles.p = math.NormalizeAngle( PB.set.angles.p )
	PB.set.angles.y = math.NormalizeAngle( PB.set.angles.y )
	
	ucmd:SetViewAngles( PB.set.angles )
	
	PB:Autopistol()
	
	if ( tonumber( PB.features.triggerbot ) == 1 ) then
		local trace = PB:CreateSelfTrace()
		
		if ( ValidEntity( trace.Entity ) && PB:FilterEntities( trace.Entity, "aim" ) ) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
		end
	end
	
	if ( !PB.set.aiming ) then return end 
	if ( PB.set.target == nil || PB.set.target == ply ) then return end
	
	local comp, myPos = PB:LockPosition( PB.set.target ), ply:GetShootPos()
	comp = ( comp + ( PB.set.target:GetVelocity() / 45 - ply:GetVelocity() / 45 ) ) + Vector( 0, 0, tonumber( PB.features.vectoroffset ) )
	
	PB.set.angles = ( comp - myPos ):Angle()
	PB.set.angles.p = math.NormalizeAngle( PB.set.angles.p )
	PB.set.angles.y = math.NormalizeAngle( PB.set.angles.y )
	PB.set.angles.r = 0
	
	ucmd:SetViewAngles( PB.set.angles )
	
	if ( tonumber( PB.features.autoshoot ) == 1 ) then
		RunConsoleCommand( "+attack" )
		timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
	end
end
PB:AddHook( "CreateMove", PB.Aim )

function PB.NoRecoil( ply, origin, angles, FOV )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	
	if ( wep.Primary ) then wep.Primary.Recoil = 0 end
	if ( wep.Secondary ) then wep.Secondary.Recoil = 0 end
	
	local view = GAMEMODE:CalcView( ply, origin, PB.set.angles, FOV ) || {}
	view.angles = PB.set.angles
	view.angles.r = 0
	view.fov = FOV
	return view
end
PB:AddHook( "CalcView", PB.NoRecoil )

PB:AddCommand( "+pb_aim", function() PB.set.aiming = true PB.set.target = nil end )
PB:AddCommand( "-pb_aim", function() PB.set.aiming = false PB.set.target = nil end )

--[[----------
	:: ESP
--]]----------
function PB:FilterText( e )
	local text, box, col = "", false, PB:FilterColors( e )
	local maxX, minX, maxY, minY, pos = PB:CreateVectors( e )
	
	if ( e:IsPlayer() ) then
		box = true
		text = ( e:Nick() .. "\nHp: " .. e:Health() )
	elseif ( e:IsNPC() ) then
		box = true
		text = ( "NPC\n" .. e:GetClass() )
	elseif ( e:IsWeapon() ) then
		box = false
		text = ( e:GetClass() )
	end
	return text, box, col, maxX, minX, maxY, minY, pos
end

function PB.HUD()
	local ply, ent = LocalPlayer(), ents.GetAll()
	
	for i = 1, table.Count( ent ) do
		local e = ent[ i ]
		
		if ( PB:FilterEntities( e, "esp" ) ) then
		
			local text, box, col, maxX, minX, maxY, minY, pos = PB:FilterText( e )
			
			if ( box ) then
				surface.SetDrawColor( col )
				
				surface.DrawLine( maxX, maxY, maxX, minY )
				surface.DrawLine( maxX, minY, minX, minY )
					
				surface.DrawLine( minX, minY, minX, maxY )
				surface.DrawLine( minX, maxY, maxX, maxY )
			end
			
			draw.DrawText( 
				text,
				"Default",
				pos.x,
				pos.y,
				col,
				TEXT_ALIGN_CENTER
			)
		end
	end
	if ( tonumber( PB.features.drawfov ) == 1 && tonumber( PB.features.fov ) < 35 ) then
		local size = ( math.sqrt( ( ScrW() ^ 2 ) + ( ScrH() ^ 2 ) ) * 0.5 )
		PB:DrawCircle( ( size * tonumber( PB.features.fov ) / 45 ) - 45 )
	end
	
	if ( tonumber( PB.features.cross ) == 1 ) then
		local g = 5; local s, x, y, l = 5, ( ScrW() / 2 ), ( ScrH() / 2 ), g + 15
		surface.SetDrawColor( 0, 255, 0, 255 )
		
		surface.DrawLine( x - l, y, x - g, y )
		surface.DrawLine( x + l, y, x + g, y )
		
		surface.DrawLine( x, y - l, x, y - g )
		surface.DrawLine( x, y + l, x, y + g )
		
		surface.SetDrawColor( 255, 0, 0, 255 )
		
		surface.DrawLine( x, y - s, x, y + s )
		surface.DrawLine( x - s, y, x + s, y )
	end
end
PB:AddHook( "HUDPaint", PB.HUD )

--[[----------
	:: XQZ
--]]----------
function PB.XQZ()
	local ply, ent = LocalPlayer(), ents.GetAll()
	
	for i = 1, table.Count( ent ) do
		local e = ent[ i ]
		
		if ( ( tonumber( PB.features.xqz ) == 1 ) && PB:FilterEntities( e, "cham" ) ) then
			cam.Start3D( EyePos(), EyeAngles() )
				render.SuppressEngineLighting( true )
				cam.IgnoreZ( true )
				e:DrawModel()
				render.SuppressEngineLighting( false )
				cam.IgnoreZ( false )
			cam.End3D()
		end
	end
end
PB:AddHook( "RenderScreenspaceEffects", PB.XQZ )

--[[----------
	:: Bunnyhop
--]]----------
function PB.Bunnyhop()
	local ply = LocalPlayer()
	if ( ( tonumber( PB.features.bunnyhop ) == 1 ) && input.IsKeyDown( KEY_SPACE ) ) then
		if ( ply:OnGround() ) then
			RunConsoleCommand( "+jump" )
			timer.Create( "lolololohop", 0.1, 0, function() RunConsoleCommand( "-jump" ) end )
		end
	end
end
PB:AddHook( "Think", PB.Bunnyhop )

--[[----------
	:: Menu
--]]----------
function PB.Menu()
	local panel = vgui.Create( "DFrame" )
	panel:SetPos( ScrW() / 2 - 200 / 2, ScrH() / 2 - 400 / 2 )
	panel:SetSize( 250, 400 )
	panel:SetTitle( "Precisionbot v1.4 BETA" )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:MakePopup()
	
	local dlist = vgui.Create( "DPanelList" )
	dlist:SetPos( 10, 30 )
	dlist:SetParent( panel )
	dlist:SetSize( 250 - 15, 400 - 10 )
	dlist:EnableVerticalScrollbar( true )
	dlist.Paint = function() end
	
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Crosshair" )
	multichoice:AddChoice( "Distance" )
	multichoice:ChooseOptionID( tonumber( PB.features.aimmode ) )
	multichoice.OnSelect = function( index, value, data )
		RunConsoleCommand( "pb_aim_mode", value )
	end
	dlist:AddItem( multichoice )
	
	// Flapadars
	for k, v in ipairs( PB.info ) do
		if ( v.Name == "pb_aim_mode" ) then
		elseif ( v.Type == "bool" ) then
			local checkbox = vgui.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( Color( 0, 0, 0, 255 ) )
			
			checkbox.change = 0
			checkbox.OnChange = function()
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( toboolnumber( checkbox:GetChecked() && 1 || 0 ) )
					RunConsoleCommand( v.Name, checkbox:GetChecked() && 1 || 0 )
				end
			end
			
			cvars.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( checkbox.change < CurTime() ) then
					checkbox.change = CurTime() + 0.1
					checkbox:SetValue( toboolnumber( new ) )
				end
			end )
			dlist:AddItem( checkbox )
			
		elseif ( v.Type == "number" ) then
			local slider = vgui.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max || 1 )
			slider:SetMin( v.Min || 0 )
			slider:SetDecimals( 0 )
			slider:SetValue( GetConVarNumber( v.Name ) )
			
			local label = vgui.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 200 )
			label:SetText( v.Desc )
			label:SetTextColor( Color( 0, 0, 0, 255 ) )
			
			slider.change = 0
			slider.ValueChanged = function( self, new )
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
					RunConsoleCommand( v.Name, new )
				end
			end
			
			cvars.AddChangeCallback( v.Name, function( cvar, old, new ) 
				if ( slider.change < CurTime() ) then
					slider.change = CurTime() + 0.1
					slider:SetValue( new )
				end
			end )
			
			dlist:AddItem( slider )
		end
	end
end

PB:AddCommand( "pb_menu", PB.Menu )