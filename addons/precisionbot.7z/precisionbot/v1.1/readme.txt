Precisionbot Public
Current verison, 1.1
Coded by fr1kin and snipplets from other coders.

Install:
	PATH: C:/program files/steam/steamapps/**username**/garrysmod/garrysmod..
	* Inside there the lua should merge with lua inside garrysmod.
	* C: If you have multiple drives, the steam location might not be in 'C:' but others like 'D:' or 'E:'.
	* If your computer is 64 bit the program files will be nammed 'Program Files(x86)'.

Features:
	* Aimbot
		- Autoshoot
		- Ingnore Friends
		- Ingnore Steam Friends
		- Perfect No-Recoil
		- Option to only target Players or NPC's.
		
	* ESP
		- Players [ Name, Health Bar or Health Text ]
		- NPC's [ Class Name ]
		- Entities [ Class Name ]
		- 2D Bounding Box
		- Chams
		- Aimspot
		- Show Dead
		
	* Miscellaneous
		- Crosshair
		- Adminlist
		- Bunnyhop
		
Bugs:
	- If Autoshot is enabled then when using automatic weapons ( wile not aiming ) you can only shoot once.
	- With the aimbot you can flip upside down when not aiming and norecoil enabled.
	- With the Bunnyhop you have to jump a few times for it to get working properly.

Ideas/Coming soon:
	- More Aim styles [ Distance, Crosshair ]
	- Continue adding better protection.
	- Autopistol
	
	* Send your suggestions to http://www.youtube.com/user/fr1kins
	
Credits:
	fr1kin
	kolbybrooks
	Seth