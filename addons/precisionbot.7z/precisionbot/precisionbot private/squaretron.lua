--[[
	lua/pbaim.lua
	frist | (STEAM_0:0:30912535)
	===DStream===
]]

/*--------------------------------------------------
	Main Code
	Desc: Hooks, Concommands...
*/--------------------------------------------------

if !( CLIENT ) then return end

local Name = ( "Precisionbot [Private]" )
local _R = debug.getregistry()

// We can now create are localized things to make things faster and look
// neater.

local concommand 			= concommand
local cvars 				= cvars
local debug 				= debug
local ents 					= ents
local file					= file
local hook 					= hook
local math 					= math
local spawnmenu				= spawnmenu
local string 				= string
local surface 				= surface
local table 				= table
local timer 				= timer
local util 					= util
local vgui 					= vgui

local Angle 				= Angle
local CreateClientConVar 	= CreateClientConVar
local CurTime 				= CurTime
local ErrorNoHalt			= ErrorNoHalt
local FrameTime 			= FrameTime
local GetConVarString 		= GetConVarString
local GetViewEntity 		= GetViewEntity
local include 				= include
local ipairs 				= ipairs
local LocalPlayer 			= LocalPlayer
local pairs 				= pairs
local pcall 				= pcall
local print 				= print
local RunConsoleCommand 	= RunConsoleCommand
local ScrH 					= ScrH
local ScrW 					= ScrW
local tonumber 				= tonumber
local type 					= type
local unpack 				= unpack
local IsValid 			= IsValid
local Vector 				= Vector

// Let's create the tables which will hold all of our commands, hooks
// and files, so it's easy to add/remove them when it comes to protection.

local PB	= {}
PB.Commands = {}
PB.CVars	= {}
PB.ConVars	= {}
PB.Hooks	= {}
PB.Files	= {}
PB.Log		= {}

PB.Friends	= {"Atomic", "Frost", "speedy"}
PB.Faggots	= {}
PB.Features = {}

// [OLD] Copy basic fuctions
local OLD		= {}
OLD.hook		= {}
OLD.timer		= {}
OLD.cvars		= {}
OLD.file		= {}
OLD.debug		= {}
OLD.usermessage	= {}
OLD.sql			= {}
OLD.Other		= {}

// Copy
OLD.GetConVar					= GetConVar
OLD.GetConVarString				= GetConVarString
OLD.GetConVarNumber				= GetConVarNumber
OLD.ConVarExists				= ConVarExists
OLD.hook.Add					= hook.Add
OLD.hook.Remove					= hook.Remove
OLD.hook.Call					= hook.Call
OLD.timer.Simple				= timer.Simple
OLD.timer.Create				= timer.Create
OLD.timer.Start					= timer.Start
OLD.cvars.AddChangeCallback		= cvars.AddChangeCallback
OLD.file.CreateDir				= file.CreateDir
OLD.file.Delete					= file.Delete
OLD.file.Exists					= file.Exists
OLD.file.ExistsEx				= file.ExistsEx
OLD.file.Find					= file.Find
OLD.file.FindDir				= file.FindDir
OLD.file.FindInLua				= file.FindInLua
OLD.file.IsDir					= file.IsDir
OLD.file.Read					= file.Read
OLD.file.Rename					= file.Rename
OLD.file.Size					= file.Size
OLD.file.TFind					= file.TFind
OLD.file.Time					= file.Time
OLD.file.Write					= file.Write
OLD.debug.getinfo				= debug.getinfo
OLD.debug.getupvalue			= debug.getupvalue
OLD.sql.TableExists				= sql.TableExists
OLD.usermessage.IncomingMessage = usermessage.IncomingMessage
OLD.Other.GetInt				= _R.ConVar.GetInt
OLD.Other.GetBool				= _R.ConVar.GetBool
OLD.Other.GetString				= _R.ConVar.GetString
OLD.Other.ConCommand			= _R.Player.ConCommand
OLD.Other.RunConsoleCommand		= RunConsoleCommand

// To make it easy when making a message lets create a command that will do it
// automaticly for us, so it's cleaner and stuff.

function PB:AddLogReport( data )
	local t = data
	table.insert( PB.Log, t )
	return;
end

function PB:ConsoleMessage( msg )
	return MsgN( "[" .. string.upper( Name ) .. "]: " .. msg )
end

function PB:ChatMessage( msg )
	local message, ply = msg, LocalPlayer()
	return ply:PrintMessage( HUD_PRINTTALK, "[" .. string.upper( Name ) .. "]: " .. message )
end

function PB.GetCVarNumber( cvar )
	return timer.Simple( 0.25, function() GetConVarNumber( cvar ) end )
end

// So we created our tables but have to add stuff to them, a simple way is
// to just create functions that get there name and add them automaticly.
// I'll have to thank Fapadar for the convar function, made things easy.

function PB:AddConCommand( name, func )
	table.insert( PB.Commands, name )
	return concommand.Add( name, func ), PB:ConsoleMessage( "Added ConCommand: " .. name )
end

function PB:AddFile( name, data )
	table.insert( PB.Files, name )
	return PB:ConsoleMessage( "Added File: " .. name )
end

function PB:AddConVar( convar, str, save, data )
	table.insert( PB.ConVars, "pb_" .. convar )
	return CreateClientConVar( "pb_" .. convar, str, save, data ), PB:ConsoleMessage( "Added ConVar: pb_" .. convar .. " [" .. str .. "]" )
end

function PB:AddNormalHook( typ, name, func )
	table.insert( PB.Hooks, name )
	return hook.Add( typ, name, func ), PB:ConsoleMessage( "[ADDED] Hook: " .. name .. " ["..typ.."]" )
end

function PB:AddHook( typ, func )

	local ran, msg = "", notes
	
	for i = 1, 20 do
		ran = ran .. string.char( math.random( 65 , 117 ) )
	end
	
	if ( msg == "" ) then msg = "<none>" end
	
	table.insert( PB.Hooks, ran )
	
	return hook.Add( typ, ran, func ), PB:ConsoleMessage( "Added Hook: " .. ran .. " ["..typ.."]" )
end

function PB:CreateClientConVar( cvar, val, tblname, dec )
	local ply, bool = LocalPlayer(), false
	if ( type( val ) == "boolean" ) then
		val = ( val && 1 || 0 ); bool = true
	end
	
	local addCvar = CreateClientConVar( "pb_" .. cvar, val, true, false )
	
	if ( bool ) then
		PB.Features[tblname] = util.tobool( addCvar:GetInt() )
	elseif ( type( val ) == "number" ) then
		if ( !dec ) then
			PB.Features[tblname] = addCvar:GetInt()
		else
			PB.Features[tblname] = tonumber( addCvar:GetString() )
		end
	elseif ( type( val ) == "string" ) then
		PB.Features[tblname] = addCvar:GetString()
	end
	
	table.insert( PB.ConVars, cvar )
	
	cvars.AddChangeCallback( cvar , function( cvar, old, new )
		if booltype then
			PB.Features[tblname] = util.tobool( math.floor( new ) )
		else
			PB.Features[tblname] = new
		end
	end )
	
	return addCvar
end

// Extra CVar(s)
table.insert( PB.ConVars, "pb_allow" )

// Now we can add our commands and stuff, everthing is localized due
// to GetConVarNumber causing lag because it does a cheacks every frame.

// Aimbot
local AimAuto			= PB:AddConVar( "aim_auto", "0", true, false )
local AimAutoshoot		= PB:AddConVar( "aim_autoshoot", "1", true, false )
local AimFriendlyFire	= PB:AddConVar( "aim_friendlyfire", "1", true, false )
local AimSteam			= PB:AddConVar( "aim_steamfriends", "1", true, false )
local AimSpot			= PB:AddConVar( "aim_spot", "1", true, false )
local AimMode			= PB:AddConVar( "aim_mode", "1", true, false )
local AimFov			= PB:AddConVar( "aim_fov", "60", true, false )
local AimThrogh			= PB:AddConVar( "aim_throgh", "0", true, false )
local AimPlayer			= PB:AddConVar( "aim_player", "1", true, false )
local AimNpc			= PB:AddConVar( "aim_npc", "1", true, false )
local AimType			= PB:AddConVar( "aim_type", "1", true, false )
local AimSilent 		= PB:AddConVar( "aim_silent", "1", true, false )
local AimOffset 		= PB:AddConVar( "aim_offset", "75", true, false )

// ESP
local EspEnabled		= PB:AddConVar( "esp_enabled", "0", true, false )
local EspName			= PB:AddConVar( "esp_name", "0", true, false )
local EspHealth			= PB:AddConVar( "esp_health", "0", true, false )
local EspWeapon			= PB:AddConVar( "esp_weapon", "0", true, false )
local EspBox			= PB:AddConVar( "esp_box", "0", true, false )
local EspBoxW			= PB:AddConVar( "esp_box_wide", "0", true, false )
local EspBoxH			= PB:AddConVar( "esp_box_tall", "0", true, false )
local EspNpc			= PB:AddConVar( "esp_npc", "0", true, false )
local EspEntity			= PB:AddConVar( "esp_entity", "0", true, false )
local EspPlayer			= PB:AddConVar( "esp_player", "0", true, false )
local EspPos			= PB:AddConVar( "esp_pos", "0", true, false )

// Visuals
local VisCross			= PB:AddConVar( "vis_cross", "1", true, false )
local VisLights			= PB:AddConVar( "vis_lights", "0", true, false )
local VisChams			= PB:AddConVar( "vis_chams", "0", true, false )
local VisChamsFB		= PB:AddConVar( "vis_chams_fullbright", "0", true, false )
local VisXQZ			= PB:AddConVar( "vis_xqz", "1", true, false )
local VisBarrel			= PB:AddConVar( "vis_barrel", "0", true, false )
local VisAimline		= PB:AddConVar( "vis_aimline", "0", true, false )
local VisAdminlist		= PB:AddConVar( "vis_adminlist", "1", true, false )
local VisInfobox		= PB:AddConVar( "vis_infobox", "0", true, false )
local VisRadar			= PB:AddConVar( "vis_radar", "0", true, false )
local VisRadarType		= PB:AddConVar( "vis_radar_type", "0", true, false )

// Removels
local RemRecoil			= PB:AddConVar( "rem_recoil", "0", true, false )
local RemSpread			= PB:AddConVar( "rem_spread", "0", true, false )
local RemSpreadCon		= PB:AddConVar( "rem_spread_constant", "0", true, false )
local RemSky			= PB:AddConVar( "rem_sky", "0", true, false )
local RemHands			= PB:AddConVar( "rem_hands", "0", true, false )

// Miscellaneous
local MiscBhop			= PB:AddConVar( "misc_bhop", "1", true, false )
local MiscAutopistol	= PB:AddConVar( "misc_autopistol", "1", true, false )
local MiscSpeedVal		= PB:AddConVar( "misc_speedvalue", "2", true, false )
local MiscSpinbot		= PB:AddConVar( "misc_spinbot", "0", true, false )

// To start lets check the log system.

// Note, this will enable a few functions to keep kids from stealing this
// and calling it 'their' hack.
local Released = true


function PB.Released()
	
	local ply = LocalPlayer()
	
	// Add Steam ID's here:
	local ID = {
	
		fr1kin	= "STEAM_0:1:24332877"
		
	}

	if ( ply:SteamID() == ID.fr1kin ) then
		Released = false
	else
		Released = true
	end
end

PB:AddHook( "Think", PB.Released )

// This is how we are going to tell if a player is an admin so we can add them to 
// the list, there are two ways we have to do this, boolen and string format.

function PB:IsAdmin(e)
	
	if ( e:IsAdmin() ) then 
		return true
	
	elseif ( e:IsSuperAdmin() ) then 
		return true
	
	elseif ( e:IsUserGroup( "Admin" ) || e:IsUserGroup( "admin" ) ) then
		return true
	
	elseif ( e:IsUserGroup( "Moderator" ) || e:IsUserGroup( "moderator" ) ) then
		return true
	
	elseif ( e:IsUserGroup( "Operator" ) || e:IsUserGroup( "operator" ) ) then
		return true
	
	end
	
	return false
	
	
end

function PB:GetAdminType(e)

	local ply = LocalPlayer()
	
	if ( e:IsAdmin() && !e:IsSuperAdmin() ) then
		return "Admin"
		
	elseif ( e:IsSuperAdmin() ) then
		return "Super Admin"

	elseif ( e:IsUserGroup( "Moderator" ) || e:IsUserGroup( "moderator" ) ) then
		return "Moderator"
	
	elseif ( e:IsUserGroup( "Operator" ) || e:IsUserGroup( "operator" ) ) then
		return "Operator"
	
	end
	
	return ""
end

// Here is a huge list of our tables, they contain most of the main code that will 
// be used to defind entities in the world.

local Bones = {

		Head		= "ValveBiped.Bip01_Head1",
		Neck		= "ValveBiped.Bip01_Neck1",
		Spine		= "ValveBiped.Bip01_Spine2",
		Spine1		= "ValveBiped.Bip01_Spine3",
		Spine2		= "ValveBiped.Bip01_Spine4",
		Ass			= "ValveBiped.Bip01_Pelvis",
		RForearm	= "ValveBiped.Bip01_R_Forearm",
		RHand		= "ValveBiped.Bip01_R_Hand",
		LForearm	= "ValveBiped.Bip01_L_Forearm",
		LHand		= "ValveBiped.Bip01_L_Hand",
		RCalf		= "ValveBiped.Bip01_R_Calf",
		RFoot		= "ValveBiped.Bip01_R_Foot",
		LCalf		= "ValveBiped.Bip01_L_Calf",
		LFoot		= "ValveBiped.Bip01_L_Foot"
		
	}

local ServerValues = {

		sv_cheats			= 0,
		sv_consistency 		= 1,
		mat_fullbright		= 0,
		mat_wireframe		= 0,
		r_drawothermodels	= 1
		
	}

local Block = {

		"dick",
		"cock",
		"suck",
		"retard",
		"faggot",
		"fucks",
		"gay",
		"homo",
		"hobo",
		"menu",
		"sex",
		"cool",
		"d1ck",
		"c0ck"
		
	}
		

local Teams = {

		"Dead Guards",
		"Dead Prisoners"
		
	}
	
local Classes = {

		( "money_printer" ),
		( "drug_lab" ),
		( "drug" ),
		( "microwave" ),
		( "food" ),
		( "gunlab" ),
		( "spawned_shipment" ),
		( "spawned_food" ),
		( "spawned_weapon" ),
		( "npc_shop" ),
		( "money_tree" )
		
	}
	
local Allies = { 

		( "npc_crow" ),
		( "npc_monk" ),
		( "npc_pigeon" ),
		( "npc_seagull" ),
		( "npc_alyx" ),
		( "npc_barney" ),
		( "npc_citizen" ),
		( "npc_dog" ),
		( "npc_kleiner" ),
		( "npc_magnusson" ),
		( "npc_eli" ),
		( "npc_gman" ),
		( "npc_citizen" ),
		( "npc_mossman" ),
		( "npc_citizen" ),
		( "npc_citizen" ),
		( "npc_vortigaunt" ),
		( "npc_breen" ),
		( "npc_soldier" ),
		( "npc_tank" ),
		( "npc_tank_turrent" )
	
	}
	
local Warnings = { 

		( "npc_grenade_frag" ),
		( "crossbow_bolt" ),
		( "roleplayg_missile" ),
		( "grenade_ar2" ),
		( "prop_combine_ball" ),
		( "hunter_flechette" ),
		( "ent_flashgrenade" ),
		( "ent_explosivegrenade" ),
		( "ent_smokegrenade" )
		
	}
	
local TraitorWeapons = {

		"weapon_ttt_c4",
		"weapon_ttt_flaregun",
		"weapon_ttt_knife",
		"weapon_ttt_phammer",
		"weapon_ttt_push",
		"weapon_ttt_radio",
		"weapon_ttt_sipistol",
		
	}
	
local DetectiveWeapons = {

		"weapon_ttt_defuser",
		"weapon_ttt_beacon",
		"weapon_ttt_binoculars",
		"weapon_ttt_health_station",
		"weapon_ttt_wtester",
		"weapon_ttt_stungun",
		"weapon_ttt_cse",
		
	}
	
local BadCMDs = {
	"kill",
	"disconnect",
	"retry",
}
	
// Detect vehicles on the map.

function PB.IsVehicle( e )
	
	local ply = LocalPlayer()
	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

// Lets make sure our targets our on our screen.

function PB:OnScreen( e )

	local x, y = ScrW(), ScrH()
	
	local pos = e:GetPos():ToScreen()
	
	if !( pos.x < 0 || pos.y < 0 ) then
		return true
	else 
		return false
	end
end

// Find the gamemode, useful for server that have custom shit.

function ServerGamemodeIs( name )
	local _hN = GetConVarString( "hostname" )
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		//PB:ChatMessage( "This server, " .. _hN .. ", is using the gamemode '" .. GAMEMODE.Name "'. Loading gamemode functions..." )
		return true
	end
	return false
end

// Makes sure the target is visible.

function PB:Visible( e )

	local ply = LocalPlayer()
	
    local visible = {
	
			start = ply:GetShootPos(),
			endpos = "ValveBiped.Bip01_Head1",
			filter = { ply, e }
			
		}

	local trace = util.TraceLine( visible )
	
	if trace.Fraction == 1 then
		return true
    end
    return false  
end


// We will now define our targets, this will depend on the users settings but
// of cource we got to disable and do valid checks!

function PB:TeamName( name )
	local str = ""
	
	for _, e in pairs( player.GetAll() ) do
		str = string.find( string.lower( team.GetName( e:Team() ) ), name )
	end
	
	return str
end

function PB:BadTargets( e )
	
	local ply = LocalPlayer()
	
	if ( e:IsPlayer() && PB:TeamName( "spec" ) ) then return false end
	
	for k, v in pairs( Teams ) do
		if ( e:IsPlayer() && PB:TeamName( v ) ) then return false end
	end
	
	return true
end

function PB:DoChecks( e )

	local ply, val = LocalPlayer(), 0
	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() && !e:IsWeapon() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end
	
	return true
	
end

function PB:SelfIsValid()
	local p = LocalPlayer()
	
	if ( !p:IsPlayer() ) then return false end
	if ( p:IsPlayer() && !p:Alive() ) then return false end
	return true
end
	

// Before we set our colors we must detect serton gamemodes that don't have team colors
// in this it will be mainly TTT.

function PB.HasWeapon( tbl )
	local ply = LocalPlayer()
	for k, e in pairs( player.GetAll() ) do
		if ( e != ply ) then
			for v, wep in pairs( e:GetWeapons() || {} ) do
				if table.HasValue( tbl, e:GetClass() ) then
					return true
				end
			end
		end
	end
	return false
end

local ttt_col = Color( 0, 255, 0, 255 )
timer.Create( "TTT_TIMER", 0.25, 0, function()
	local ttt_col = Color( 0, 255, 0, 255 )
	
	if ( PB.HasWeapon( TraitorWeapons ) && !PB.HasWeapon( DetectiveWeapons ) ) then
		ttt_col = Color( 255, 0, 0, 255 )
	elseif ( !PB.HasWeapon( TraitorWeapons ) && PB.HasWeapon( DetectiveWeapons ) ) then
		ttt_col = Color( 0, 0, 255, 255 )
	else
		ttt_col = Color( 0, 255, 0, 255 )
	end
end )
		
// After we are done with that we can start creating our hack, first thing is to get
// all the entities and give them a color, it's going to be needed below.

function PB:SetColors( e )

	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col
	
	if ( e:IsPlayer() && ServerGamemodeIs( "trouble in terrorist town" ) ) then
		col = ttt_col

	elseif ( e:IsPlayer() && table.HasValue( PB.Faggots, e:Nick() ) ) then
		local r, g, b = math.random( 255 ), math.random( 255 ), math.random( 255 )
		col = Color( r, g, b, 255 )
		
	elseif ( e:IsPlayer() && !table.HasValue( PB.Faggots, e:Nick() ) ) then
		col = team.GetColor( e:Team() )
	
	elseif ( e:IsNPC() && !table.HasValue( Allies, class ) ) then
		col = Color( 255, 0, 0, 255 )
		
	elseif ( e:IsNPC() && table.HasValue( Allies, class ) ) then
		col = Color( 0, 255, 0, 255 )
	
	elseif ( e:IsWeapon() || PB.IsVehicle(e) ) then
		col = Color( 255, 128, 0, 255 )
		
	else
		
		col = Color( 255, 255, 255, 255 )
		
	end
	
	return col
end

// This is going to be our material inside the hack, it's going to be pure lua so
// I don't have to use all the other shitty materials.

function PB:CreateMaterial()
	
	local BaseInfo = {
		["$basetexture"] = "color/white",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1
	}
   
   local mat = CreateMaterial( "vh_mat", "VertexLitGeneric", BaseInfo )

   return mat

end

// This will get cvars that I want to check, like sv_cheats or sv_scriptenforcer. - Added allowcslua for GM13

function PB:CheckScriptEnforcer()
	if ( GetConVarNumber( "sv_allowcslua" ) == 0 ) then
		return "[ON]"
	end
	return "[OFF]"
end

function PB:CheckCheats()
	if ( GetConVarNumber( "sv_cheats" ) != 0 ) then
		return "[ON]"
	end
	return "[OFF]"
end

// Allows you to find things without having extremly long messy parts of code that 
// make you think of shit.

function PB:FindFile( name )
	if ( #file.Find( name ) ) >= 1 then
		return true
	end
	return false
end

// Too create out positions we are going to have to create vectors, then based off
// of of that we can finish this.

function PB:CreateVectors( e )
	
	local ply = LocalPlayer()
	local h, v = EspBoxW:GetInt(), EspBoxH:GetInt()
	
	local col = PB:SetColors( e )
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local pos, n, div = e:LocalToWorld( btm - btm * 1.5 ), 0, 0
	local dis, name, health, weapon = math.Round( e:GetPos():Distance( ply:GetShootPos() ) ), EspName:GetBool(), EspHealth:GetBool(), EspWeapon:GetBool()
	
	if ( div ~= 30 ) then
		if ( name ) then div = div + 10 else div = div - 10 end
		if ( health ) then div = div + 10 else div = div - 10 end
		if ( weapon ) then div = div + 10 else div = div - 10 end
	end
	
	if ( e:IsPlayer() ) then n = dis / div else n = 0 end
	
	if ( EspPos:GetBool() ) then
		pos = e:LocalToWorld( top + top + Vector( 0, 0, n ) )
	else
		pos = e:LocalToWorld( btm - btm * 1.5 )
	end
	
	local eye, hed
	if ( e:IsPlayer() ) then
		eye = ( e:GetEyeTrace().HitPos )
		hed = ( e:EyePos() )
	end
	
	local FRT 	= center + frt + rgt / h + top / v; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft / h + btm / v; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft / h + top / v; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt / h + top / v; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft / h + top / v; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt / h + btm / v; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft / h + btm / v; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt / h + btm / v; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY, pos, eye, hed
end

// People are really tired of trying to kill some failure are a distance and then
// came the nospread, for years hackers needed something to make hacking look so
// obvious that people would scream over the mic at you, mainly little kids.
// Credits to whoever created RaidBot.
local Deco = false
function PB.ModuleDeco()
	if ( Deco ) then
		return true, PB:ConsoleMessage( "Module 'Deco' has loaded." )
	end
	return false, PB:ConsoleMessage( "Module 'Deco' has NOT loaded." )
end

// This will be the real ESP code, it's seperated from the rest of the code to
// provide easy editing, and also recude the lag levels in games.

function PB:CreateTargets( e )

	local ply = LocalPlayer()
	
	local maxX, minX, maxY, minY, pos, eye, hed = PB:CreateVectors(e)
			
	local class, model, s = e:GetClass(), e:GetModel(), "\n"
	local col = PB:SetColors(e)
			
	local text, Box = "", false
		
	if ( e:IsPlayer() && EspPlayer:GetBool() ) then
		
		Box = true
	
		if ( EspName:GetBool() ) then
			text = text .. e:Nick()
		end
		
		if ( EspHealth:GetBool() ) then
			text = text .. "\nHP: " .. e:Health()
		end
			
		if ( EspWeapon:GetBool() && e:GetActiveWeapon():IsValid() ) then
			
			local wep = e:GetActiveWeapon():GetPrintName()
			
			wep = string.Replace( wep, "#HL2_", "" )
			wep = string.Replace( wep, "#GMOD_", "" )
			wep = string.Replace( wep, "_", " " )
			
			wep = string.lower( wep )
			
			text = text .. "\nW: " .. wep
		end
	end
	
	if ( e:IsNPC() ) then
	
		if ( EspNpc:GetBool() ) then
				
			Box = true

			local npc = class
			
			npc = string.Replace( npc, "npc_", "" )
			npc = string.Replace( npc, "_", "" )
			
			npc = string.lower( npc )
			
			text = text .. npc
		end
	end
	
	if ( e:IsWeapon() ) then
		
		if ( EspEntity:GetBool() ) then
		
			Box = false
			local ent = class
			
			ent = string.Replace( ent, "weapon_", "" )
			ent = string.Replace( ent, "ttt_", "" )
			ent = string.Replace( ent, "zm_", "" )
			ent = string.Replace( ent, "cs_", "" )
			ent = string.Replace( ent, "css_", "" )
			ent = string.Replace( ent, "real_", "" )
			ent = string.Replace( ent, "mad_", "" )
			ent = string.Replace( ent, "_", " " )
			
			ent = string.lower( ent )
			
			text = text .. ent
		end
	end
	
	local c_col  = col
	local c_maxX = maxX
	local c_minX = minX
	local c_maxY = maxY
	local c_minY = minY
	local c_pos = pos
	local c_eye  = eye
	local c_head = hed
			
	return text, Box, c_col, c_maxX, c_minX, c_maxY, c_minY, c_pos, c_eye, c_head
end

// This will take the bones from the table above and create the 
// aim spot convar. Also I'd have too thank RabidToaster for the
// model/bone script due to tables screwing with me.

function PB:GetPos( e, pos )
	if ( type( pos ) == "string" ) then
		return ( e:GetBonePosition( e:LookupBone( pos ) ) )
	elseif ( type( pos ) == "Vector" ) then
		return ( e:LocalToWorld( Vector( pos ) ) )
	end
	return ( e:LocalToWorld( e:OBBCenter() ) )
end

function PB:GenerateSpot( e )
	
	local val = math.Clamp( AimSpot:GetInt(), 1, 14 )
	
	local spt = e:LocalToWorld( e:OBBCenter() )
	
	// Main Player Bones:
	if ( AimSpot:GetInt() == 1 ) then spt = PB:GetPos( e, Bones.Head ) end
	if ( AimSpot:GetInt() == 2 ) then spt = PB:GetPos( e, Bones.Neck ) end
	if ( AimSpot:GetInt() == 3 ) then spt = PB:GetPos( e, Bones.Spine ) end
	if ( AimSpot:GetInt() == 4 ) then spt = PB:GetPos( e, Bones.Spine1 ) end
	if ( AimSpot:GetInt() == 5 ) then spt = PB:GetPos( e, Bones.Spine2 ) end
	if ( AimSpot:GetInt() == 6 ) then spt = PB:GetPos( e, Bones.Ass ) end
	if ( AimSpot:GetInt() == 7 ) then spt = PB:GetPos( e, Bones.RForearm ) end
	if ( AimSpot:GetInt() == 8 ) then spt = PB:GetPos( e, Bones.RHand ) end
	if ( AimSpot:GetInt() == 9 ) then spt = PB:GetPos( e, Bones.LForearm ) end
	if ( AimSpot:GetInt() == 10 ) then spt = PB:GetPos( e, Bones.LHand ) end
	if ( AimSpot:GetInt() == 11 ) then spt = PB:GetPos( e, Bones.RCalf ) end
	if ( AimSpot:GetInt() == 12 ) then spt = PB:GetPos( e, Bones.RFoot ) end
	if ( AimSpot:GetInt() == 13 ) then spt = PB:GetPos( e, Bones.LCalf ) end
	if ( AimSpot:GetInt() == 14 ) then spt = PB:GetPos( e, Bones.LFoot ) end
	
	// Model Targets:
	local m = e:GetModel()
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then spt = PB:GetPos( e, Vector( 0, 0, 5 ) ) end
	if ( m == "models/seagull.mdl" ) then spt = PB:GetPos( e, Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then spt = PB:GetPos( e, "Scanner.Body" ) end
	if ( m == "models/hunter.mdl" ) then spt = PB:GetPos( e, "MiniStrider.body_joint" ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then spt = PB:GetPos( e, "Barrel" ) end
	if ( m == "models/dog.mdl" ) then spt = PB:GetPos( e, "Dog_Model.Eye" ) end
	if ( m == "models/vortigaunt.mdl" ) then spt = PB:GetPos( e, "ValveBiped.Head" ) end
	if ( m == "models/antlion.mdl" ) then spt = PB:GetPos( e, "Antlion.Body_Bone" ) end
	if ( m == "models/antlion_guard.mdl" ) then spt = PB:GetPos( e, "Antlion_Guard.Body" ) end
	if ( m == "models/antlion_worker.mdl" ) then spt = PB:GetPos( e, "Antlion.Head_Bone" ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then spt = PB:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/zombie/fast.mdl" ) then spt = PB:GetPos( e, "ValveBiped.HC_BodyCube" ) end
	if ( m == "models/headcrabclassic.mdl" ) then spt = PB:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/headcrabblack.mdl" ) then spt = PB:GetPos( e, "HCBlack.body" ) end
	if ( m == "models/headcrab.mdl" ) then spt = PB:GetPos( e, "HCFast.body" ) end
	if ( m == "models/zombie/poison.mdl" ) then spt = PB:GetPos( e, "ValveBiped.Headcrab_Cube1" ) end
	if ( m == "models/zombie/classic.mdl" ) then spt = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then spt = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then spt = PB:GetPos( e, "ValveBiped.HC_Body_Bone" ) end
	if ( m == "models/combine_strider.mdl" ) then spt = PB:GetPos( e, "Combine_Strider.Body_Bone" ) end
	if ( m == "models/combine_dropship.mdl" ) then spt = PB:GetPos( e, "D_ship.Spine1" ) end
	if ( m == "models/combine_helicopter.mdl" ) then spt = PB:GetPos( e, "Chopper.Body" ) end
	if ( m == "models/gunship.mdl" ) then spt = PB:GetPos( e, "Gunship.Body" ) end
	if ( m == "models/lamarr.mdl" ) then spt = PB:GetPos( e, "HeadcrabClassic.SpineControl" ) end
	if ( m == "models/mortarsynth.mdl" ) then spt = PB:GetPos( e, "Root Bone" ) end
	if ( m == "models/synth.mdl" ) then spt = PB:GetPos( e, "Bip02 Spine1" ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then spt = PB:GetPos( e, "ValveBiped.Head" ) end
	
	return spt
end

// I'm going to make a new function of this value so I don't have 
// to use surface.SetDrawColor.

function PB.DrawOutlinedRect( x, y, w, h, col )
	surface.SetDrawColor( col )
	surface.DrawOutlinedRect( x, y, w, h )
end

// Really Garry, why does this only have xalign.
function PB.DrawText( text, font, x, y, colour, xalign, yalign )

	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end
	
	local curX = x
	local curY = y
	local curString = ""
	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")
	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

/*--------------------------------------------------
	Aimbot
	Desc: Automaticaim setting, aims for you so you
	don't have to move your mouse 2 inches or more
	because thats way to much work!
*/--------------------------------------------------

function PB:IsVisible(e)

	if ( AimThrogh:GetBool() ) then return false end
	if ( !IsValid(e) ) then return false end
	
	local ply, spt = LocalPlayer(), PB:GenerateSpot(e)
	
    local visible = {

			start = ply:GetShootPos(),
			endpos = spt,
			filter = { ply, e }

		}

	local trace = util.TraceLine( visible )
	
	if trace.Fraction == 1 then
		return true
    end
    return false 
end

local ViewAngle = Angle( 0, 0, 0 )
local Aiming = false

function PB:GetShootTrace()
	local ply = LocalPlayer()
		local s, e = ply:GetShootPos(), ply:GetAimVector()
		local t = {}
		t.start = s
		t.endpos = s + ( e * 16384 )
		t.filter = { ply }
	return util.TraceLine(t)
end

local function ValidTarget( e )
	local ply = LocalPlayer()
	
	if ( !IsValid( e ) ) then return false end
	if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	
	if ( e:IsPlayer() && !AimPlayer:GetBool() ) then return false end
	if ( e:IsPlayer() && table.HasValue( PB.Friends, e:Nick() ) ) then return false end
	if ( e:IsPlayer() && !AimFriendlyFire:GetBool() && ply:Team() == e:Team() ) then return false end
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	
	if ( e:IsNPC() && AimNpc:GetBool() ) then return false end
	return true
end

local tar = nil
local ON = false
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local spinangle = Angle( 0, 0, 0 )
local stop = 0xFFFF - IN_JUMP

local offset = ( AimOffset:GetInt() )

local SetViewAngles = _R["CUserCmd"].SetViewAngles

function PB.Bot( u )

		local ply = LocalPlayer()
		
		if ( MiscSpinbot:GetBool() and ( u:GetButtons() and ( IN_ATTACK ) ) == 0 ) then
			local myview = u:GetViewAngles()
				
			spinangle.y = spinangle.y + 20
			SetViewAngles(u, spinangle)

			local diff = math.Deg2Rad(math.NormalizeAngle(spinangle.y - myview.y))
				
			local absf = math.Clamp(u:GetForwardMove(), -1, 1)
			local abss = math.Clamp(u:GetSideMove(), -1, 1)
		
			u:SetForwardMove(-1000 * math.sin(diff) * abss)
			u:SetSideMove(1000 * math.sin(diff) * absf)
		end
		
		if ( !Aiming ) then return end
		
		// stolen untill i become better okay
		local t = PB:GetShootTrace()
		if ( !ValidTarget(tar) || !PB:IsVisible(tar) ) then
			tar = nil
			ON = false
			local f, o, a, t, b = AimFov:GetInt(), { p, y }
			for k, e in pairs( ents.GetAll() ) do
				if ( ValidTarget(e) && PB:IsVisible(e) ) then
					b = PB:GenerateSpot( e )
					
					a, t = ply:GetAimVector():Angle(), (b - ply:GetShootPos()):Angle()
					o.p, o.y = math.abs(math.NormalizeAngle(a.p - t.p)), math.abs(math.NormalizeAngle(a.y - t.y))
					
					if ( !tar || e:Health() > tar:Health() ) && ( o.p <= f && o.y <= f ) then tar = e end
				end
			end
		end
		
		if ( !IsValid(tar) || !Aiming ) then return end
		local setAng = PB:GenerateSpot( tar )
		local myPos = ply:GetShootPos()
		
		setAng = setAng + ( tar:GetVelocity() / 45 - ply:GetVelocity() / 45 )
		
		local ang = ( setAng-myPos ):Angle()
		
		if ( RemSpread:GetBool() ) then
			ang = ang
		end
		
		ang.p = math.NormalizeAngle( ang.p )
		ang.y = math.NormalizeAngle( ang.y )
		ang.r = 0
		
		SetViewAngles( u, ang )
		
		if ( Aiming && tar != nil && AimAutoshoot:GetBool() ) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.01, function() RunConsoleCommand( "-attack" ) end )
		elseif ( ( !Aiming && tar == nil || tar == nil || !Aiming ) && !AimAutoshoot:GetBool() ) then
			RunConsoleCommand( "-attack" )
		end
	end
	
	function PB.AimHUD()
		local ply = LocalPlayer()
		for k, e in pairs( ents.GetAll() ) do
			if ( tar != nil && e == tar ) then
				local spot = PB:GenerateSpot( e ) + ( tar:GetVelocity() / 45 - ply:GetVelocity() / 45 )
				local pos = spot:ToScreen()
				draw.RoundedBox( 0, pos.x - 2, pos.y - 2, 4, 4, Color( 255, 0, 0, 255 ) )
			end
		end
	end

	function PB.On()
		Aiming = true
	end
	
	function PB.Off()
		Aiming = false
		tar = nil
		ON = false
	end
	
	function PB.NoRecoil( u, o )
		if ( !RemRecoil:GetBool() ) then return end
			local ply = LocalPlayer()
			local w = ply:GetActiveWeapon()
			
			if ( w.Primary ) then w.Primary.Recoil = 0.0 end
			if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
	--	return { origin = o, angles = correctView }
	end
	
	PB:AddConCommand( "+pb_aim", PB.On )
	PB:AddConCommand( "-pb_aim", PB.Off )
	PB:AddHook( "CreateMove", PB.Bot )
	PB:AddHook( "HUDPaint", PB.AimHUD )
	PB:AddHook( "CalcView", PB.NoRecoil )

/*--------------------------------------------------
	Visuals
	Desc: Crosshair, player lights...
*/--------------------------------------------------

function PB.Visuals()

	local ply = LocalPlayer()
	local x, y = ScrW() / 2, ScrH() / 2
	
	// Crosshair
	if ( VisCross:GetBool() ) then
		
		local s = 10
		local g = 5; local l = g + 10
		
		// Inside
		surface.SetDrawColor( 255, 0, 0, 255 )
		surface.DrawLine( x, y - s, x, y + s )
		surface.DrawLine( x - s, y, x + s, y )
		
		// Outside
		surface.SetDrawColor( 0, 255, 0, 255 )
		surface.DrawLine( x - l, y, x - g, y ); surface.DrawLine( x + l, y, x + g, y )
		surface.DrawLine( x, y - l, x, y - g ); surface.DrawLine( x, y + l, x, y + g )
	end
	
end
PB:AddHook( "HUDPaint", PB.Visuals )

	// Admin List ----------------------------------------------------------------------
	
	//local admins, adminnum, wide, tall, posX, posY = PB.FunctionAdminlist()
	
	local admins, adminnum = "", 0
	
	for k, e in pairs( player.GetAll() ) do
		if ( PB:IsAdmin(e) ) then
			admins = ( admins .. "\n" .. e:Nick() .. " [" .. PB:GetAdminType(e) .. "]" )
			LocalPlayer():ChatPrint( admins .. "\n" .. e:Nick() .. " [" .. PB:GetAdminType(e) .. "]" )
			adminnum = adminnum + 1
		end
	end