Precision Aim ALPHA
-----
THIS DOES NOT HAVE AN AIMBOT AND THE RADAR IS NOT WORKING!

DO NOT UPLOAD THIS TO GARRYSMOD.ORG UNTILL I'M DONE WITH THIS SHIT!

LUA FILES:
C:/programfiles/steam/steamapps/-username-/garrysmod/garrysmod

MATERIAL FILES:
C:/programfiles/steam/steamapps/-username-/garrysmod/garrysmod

READ THIS:
+ BECAUSE I FAIL SO MUCH YOU HAVE TO RUN THE SCRIPT EVERYTIME YOU WANT TO TURN ON OR OFF THE CHAMS!!!
OPEN CONSOLE AND TPYE THIS
lua_openscript_cl autorun/client/nil.lua

FOOLS I OWN THIS SCRIPT SO DON'T EVEN THINK OF TAKING IT.

MENU COMMANDS:
f_menu  - Advanced Menu
f_menuz - Smaller Menu

NOTE:
I REMOVED THE NO-RECOIL SO AIMBOTS LIKE AUTOAIM AND ASB WORK.














































Last note: Bmthrules stole autoaim, stop giving him fkn credits.