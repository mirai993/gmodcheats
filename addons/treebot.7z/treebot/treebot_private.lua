--[[ Made By TreeLife - Steam - Anthony Bugg
_________ _______  _______  _______  ______   _______ _________   _______  _______ _________          _______ _________ _______ 
\__   __/(  ____ )(  ____ \(  ____ \(  ___ \ (  ___  )\__   __/  (  ____ )(  ____ )\__   __/|\     /|(  ___  )\__   __/(  ____ \
   ) (   | (    )|| (    \/| (    \/| (   ) )| (   ) |   ) (     | (    )|| (    )|   ) (   | )   ( || (   ) |   ) (   | (    \/
   | |   | (____)|| (__    | (__    | (__/ / | |   | |   | |     | (____)|| (____)|   | |   | |   | || (___) |   | |   | (__    
   | |   |     __)|  __)   |  __)   |  __ (  | |   | |   | |     |  _____)|     __)   | |   ( (   ) )|  ___  |   | |   |  __)   
   | |   | (\ (   | (      | (      | (  \ \ | |   | |   | |     | (      | (\ (      | |    \ \_/ / | (   ) |   | |   | (      
   | |   | ) \ \__| (____/\| (____/\| )___) )| (___) |   | |     | )      | ) \ \_____) (___  \   /  | )   ( |   | |   | (____/\
   )_(   |/   \__/(_______/(_______/|/ \___/ (_______)   )_(     |/       |/   \__/\_______/   \_/   |/     \|   )_(   (_______/

   
   Private Version of TreeBot - Do not leak this please, thank you. :)
--]]

-- Local Hack
local hook = hook
local _G                                = table.Copy( _G )
local player                            = _G.player
local string                            = _G.string
local hook                              = _G.hook
local CreateClientConVar 				= _G.CreateClientConVar
local LocalPlayer                       = _G.LocalPlayer

-- Local Hack
local GCVN = GetConVarNumber;
local CCCV = CreateClientConVar;
local RCC = RunConsoleCommand;
local HOOKADD = hook.Add;
local TreeBot = LocalPlayer()

-- ConVar Hack
CCCV("TreeBot_Aimbot", 1, true, false)
CCCV("TreeBot_Wallhack", 1, true, false)
CCCV("TreeBot_Crosshair", 1, true, false)
CCCV("TreeBot_Bunnyhop", 1, true, false)

-- Aim Hack
HOOKADD("Think", "TreeBot_Aim", function(cmd)
	local trace = util.GetPlayerTrace( TreeBot )
	local traceRes = util.TraceLine( trace )
	if GCVN("TreeBot_Aimbot") >= 1 then
	if traceRes.HitNonWorld then
		local target = traceRes.Entity
		if target:IsPlayer() then
			local targethead = target:LookupBone("ValveBiped.Bip01_Neck1")
			local targetheadpos,targetheadang = target:GetBonePosition(targethead)
			TreeBot:SetEyeAngles((targetheadpos - TreeBot:GetShootPos()):Angle())
		end
	end
end
end)

-- Wall Hack
HOOKADD( "HUDPaint", "TreeBot_Wallhack", function()

	for k,v in pairs (player.GetAll()) do
	if GCVN("TreeBot_Wallhack") >= 1 then
                        if v ~= TreeBot then
		if TreeBot:Alive() then
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		draw.DrawText( v:Name(), "ChatFont", Position.x, Position.y, Color( 10, 255, 0, 255 ), 1 )
		else
		
end
end
end
end

if GCVN("TreeBot_Wallhack") >= 1 then
for k,v in pairs ( player.GetAll() ) do
 
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        local Name = ""
 
        if v == TreeBot then Name = "" else Name = v:Name() end
 
end
end

if GCVN("TreeBot_Crosshair") >= 1 then
surface.SetDrawColor(0, 255, 0, 255)
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end

local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end

if GCVN("TreeBot_Wallhack") >= 1 then
for k,v in pairs(player.GetAll()) do
        local x1,y1,x2,y2 = coordinates(v)
         surface.SetDrawColor(color_white)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end

if GCVN("TreeBot_Aimbot") >= 1 then
draw.DrawText("Aimbot Enabled", "Default", 10, 0, Color(0, 255, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
draw.DrawText("Aimbot Disabled", "Default", 10, 0, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("TreeBot_Wallhack") >= 1 then
draw.DrawText("Wallhack Enabled", "Default", 10, 15, Color(0, 255, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
draw.DrawText("Wallhack Disabled", "Default", 10, 15, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("TreeBot_Bunnyhop") >= 1 then
draw.DrawText("Bunnyhop Enabled", "Default", 10, 30, Color(0, 255, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
draw.DrawText("Bunnyhop Disabled", "Default", 10, 30, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

if GCVN("TreeBot_Crosshair") >= 1 then
draw.DrawText("Crosshair Enabled", "Default", 10, 45, Color(0, 255, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
else
draw.DrawText("Crosshair Disabled", "Default", 10, 45, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

end)

-- NoRecoil Hack
local function NoRecoil()
    if TreeBot:GetActiveWeapon() and TreeBot:GetActiveWeapon().Primary then
        TreeBot:GetActiveWeapon().Primary.Recoil = 0
		AHack.Ply:GetActiveWeapon().Recoil = 0
    end
end

-- Jump Hack
HOOKADD("CreateMove", "TreeBot_Bunny", function(cmd)
if GCVN("TreeBot_Bunnyhop") >= 1 and cmd:KeyDown(IN_JUMP) then
cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
if GCVN("TreeBot_Bunnyhop") >= 1 and TreeBot:OnGround() then
cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
end
end
end)

-- Noise Hack
RCC("play", "npc/stalker/go_alert2a.wav")
TreeBot:ChatPrint("Made by TreeLife - Steam - Anthony Bugg")
TreeBot:ChatPrint("Hack Loaded Sucessfully!")