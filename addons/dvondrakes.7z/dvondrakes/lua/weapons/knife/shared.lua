if( SERVER ) then
	AddCSLuaFile( "shared.lua" );
end

if( CLIENT ) then
	SWEP.PrintName = "Knife";
	SWEP.Slot = 3;
	SWEP.SlotPos = 3;
	SWEP.DrawAmmo = false;
	SWEP.DrawCrosshair = false;
end

SWEP.Author			= "Doug Tyrrell"
SWEP.Instructions	= "Left click to stab, press R to throw! Backstab is an instakill!"
SWEP.Contact		= "www.dvondrake.com"
SWEP.Purpose		= ""

SWEP.ViewModelFOV	= 62
SWEP.ViewModelFlip	= false
SWEP.IconLetter	= "j"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= true

SWEP.NextStrike = 0;
SWEP.NextCloak = 0;
SWEP.Cloaked = false;
SWEP.CurrentCloak = 255;
  
SWEP.ViewModel      = "models/weapons/v_knife_t.mdl"
SWEP.WorldModel   = "models/weapons/w_knife_t.mdl"
  
-------------Primary Fire Attributes----------------------------------------
SWEP.Primary.Delay			= 0.9 	--In seconds
SWEP.Primary.Recoil			= 0		--Gun Kick
SWEP.Primary.Damage			= 15	--Damage per Bullet
SWEP.Primary.NumShots		= 1		--Number of shots per one fire
SWEP.Primary.Cone			= 0 	--Bullet Spread
SWEP.Primary.ClipSize		= -1	--Use "-1 if there are no clips"
SWEP.Primary.DefaultClip	= -1	--Number of shots in next clip
SWEP.Primary.Automatic   	= true	--Pistol fire (false) or SMG fire (true)
SWEP.Primary.Ammo         	= "none"	--Ammo Type
 
-------------Secondary Fire Attributes-------------------------------------
SWEP.Secondary.Delay		= 0.9
SWEP.Secondary.Recoil		= 0
SWEP.Secondary.Damage		= 0
SWEP.Secondary.NumShots		= 1
SWEP.Secondary.Cone			= 0
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic   	= true
SWEP.Secondary.Ammo         = "none"

util.PrecacheSound("weapons/knife/knife_deploy1.wav")
util.PrecacheSound("weapons/knife/knife_hitwall1.wav")
util.PrecacheSound("weapons/knife/knife_hit1.wav")
util.PrecacheSound("weapons/knife/knife_hit2.wav")
util.PrecacheSound("weapons/knife/knife_hit3.wav")
util.PrecacheSound("weapons/knife/knife_hit4.wav")
util.PrecacheSound("weapons/iceaxe/iceaxe_swing1.wav")

if CLIENT then
	killicon.AddFont( "knife", "CSKillIcons", SWEP.IconLetter, Color( 255, 245, 40, 255 ) )
end

function SWEP:DrawWeaponSelection(x,y,wide,tall,alpha)
	draw.SimpleText(self.IconLetter,"CSSelectIcons",x+wide/2,y+tall*0.2,Color(255, 245, 10, 255 ),1)
	draw.SimpleText(self.IconLetter,"CSSelectIcons",x+wide/2+math.Rand(-4,4),y+tall*0.2+math.Rand(-14,14),Color(255,210,0,math.Rand(10,120)),1)
	draw.SimpleText(self.IconLetter,"CSSelectIcons",x+wide/2+math.Rand(-4,4),y+tall*0.2+math.Rand(-9,9),Color(255,210,0,math.Rand(10,120)),1)
end

function SWEP:Initialize()
	if( SERVER ) then
		self:SetWeaponHoldType( "melee" );
	end
	self.Hit = { 
	Sound( "weapons/knife/knife_hitwall1.wav" ) };
	self.FleshHit = {
  	Sound( "weapons/knife/knife_hit1.wav" ),
	Sound( "weapons/knife/knife_hit2.wav" ),
	Sound( "weapons/knife/knife_hit3.wav" ),
  	Sound( "weapons/knife/knife_hit4.wav" ) };

end

function SWEP:Precache()
end

function SWEP:Deploy()
	self.Owner:EmitSound( "weapons/knife/knife_deploy1.wav" );
	self.NextStrike = CurTime();
	if SERVER then
		self.Owner:DrawViewModel( true );
	end
	return true;
end

function SWEP:Holster( wep )
	if self.Owner then
		if self.Owner:IsValid() and self.Owner:Alive() then
			self.NextStrike = CurTime();
		end
	end
	return true;
end 

function SWEP:PrimaryAttack()
	if( CurTime() < self.NextStrike ) then return; end
	self.NextStrike = ( CurTime() + .5 );
	
	local tr = {}
	tr.start = self.Owner:GetShootPos()
	tr.endpos = self.Owner:GetShootPos() + ( self.Owner:GetAimVector() * 75 )
	tr.filter = self.Owner
	tr.mask = MASK_SHOT
	local trace = util.TraceLine( tr )
	
 	if trace.Hit then
		if( trace.Entity:IsPlayer() or trace.Entity:IsNPC() or trace.Entity:GetClass()=="prop_ragdoll" ) then
			self.Owner:EmitSound( self.FleshHit[math.random(1,#self.FleshHit)] );
		else
			self.Owner:EmitSound( self.Hit[math.random(1,#self.Hit)] );
		end
			self.Owner:SetAnimation( PLAYER_ATTACK1 );
			self.Weapon:SendWeaponAnim( ACT_VM_HITCENTER );
				bullet = {}
				bullet.Num    = 1
				bullet.Src    = self.Owner:GetShootPos()
				bullet.Dir    = self.Owner:GetAimVector()
				bullet.Spread = Vector(0, 0, 0)
				bullet.Tracer = 0
				bullet.Force  = 1
				
			if ( trace.Entity:IsValid() and ( trace.Entity:IsPlayer() or trace.Entity:IsNPC() ) and ( (trace.Entity:GetAimVector() ):DotProduct( self.Owner:GetAimVector() ) > 0 ) ) then
				bullet.Damage = 1000 -- Back stab, instakill
			else
				bullet.Damage = 25
			end
			self.Owner:FireBullets(bullet) 
	else
		self.Owner:SetAnimation( PLAYER_ATTACK1 );
		self.Weapon:SendWeaponAnim( ACT_VM_HITCENTER );
		self.Weapon:EmitSound("weapons/iceaxe/iceaxe_swing1.wav")
	end
end

function RemoveKnife( ent )
	if ent:IsValid() then
		ent:Remove()
	end
end

function SWEP:Think()
end
	
function SWEP:SecondaryAttack()
end
	

function SWEP:Reload()
	if( CurTime() < self.NextStrike ) then return; end
	self.NextStrike = ( CurTime() + 1 );
 
    self.Owner:SetAnimation( PLAYER_ATTACK1 );
	self.Weapon:SendWeaponAnim( ACT_VM_HITCENTER );
	self.Weapon:EmitSound("weapons/iceaxe/iceaxe_swing1.wav")
	self.Owner:EmitSound( "weapons/knife/knife_deploy1.wav" )
   
	local tr = self.Owner:GetEyeTrace();
	
	if (!SERVER) then return end; 
	
	local ent = ents.Create ("thrownknife");

	ent:SetPos (self.Owner:EyePos() + (self.Owner:GetAimVector() * 16));
	ent:SetAngles (self.Owner:EyeAngles());
	ent:Spawn();
	
	ent.Thrower = self.Owner;

	local phys = ent:GetPhysicsObject();

	local shot_length = tr.HitPos:Length();
	phys:ApplyForceCenter (self.Owner:GetAimVector():GetNormalized() * math.pow (shot_length, 3));

	cleanup.Add (self.Owner, "props", ent);

	undo.Create ("Knife");
	undo.AddEntity (ent);
	undo.SetPlayer (self.Owner);
	undo.Finish(); 
	
	timer.Simple(20, RemoveKnife, ent) 
end 
