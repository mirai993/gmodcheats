if( SERVER ) then
	AddCSLuaFile( "shared.lua" );
	
	resource.AddFile("sound/buttscratch2/intro.wav")
	resource.AddFile("sound/buttscratch2/longrange.wav")
	resource.AddFile("sound/buttscratch2/offer01.wav")
	resource.AddFile("sound/buttscratch2/offer02.wav")
	resource.AddFile("sound/buttscratch2/offer03.wav")
	resource.AddFile("sound/buttscratch2/offer04.wav")
	resource.AddFile("sound/buttscratch2/request01.wav")
	resource.AddFile("sound/buttscratch2/request02.wav")
end

local intro = Sound("buttscratch2/intro.wav")
local longrange = Sound("buttscratch2/longrange.wav")
local offers = {
					Sound("buttscratch2/offer01.wav"),
					Sound("buttscratch2/offer02.wav"),
					Sound("buttscratch2/offer03.wav"),
					Sound("buttscratch2/offer04.wav")
				}
local requests = {
					Sound("buttscratch2/request01.wav"),
					Sound("buttscratch2/request02.wav")
				}

SWEP.PrintName = "Buttscratcha";
SWEP.Slot = 1;
SWEP.SlotPos = 1;
SWEP.DrawAmmo = false;
SWEP.DrawCrosshair = false;
SWEP.Invisible = true;

SWEP.Author			= "Doug Tyrrell"
SWEP.Instructions	= "Left click to offer, right click to request. R to long range butt scratch."
SWEP.Contact		= "dvondrake.com"
SWEP.Purpose		= "To butt your scratch."

SWEP.ViewModel		= "models/weapons/v_crowbar.mdl"
SWEP.WorldModel		= "models/weapons/w_crowbar.mdl"

SWEP.ViewModelFOV	= 62
SWEP.ViewModelFlip	= false

SWEP.Spawnable			= true
SWEP.AdminSpawnable		= false
  
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= 0
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= ""

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= 0
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= ""

SWEP.NextFart				= 0

function SWEP:Initialize()
end

function SWEP:Precache()
end

function SWEP:Deploy()
	if not SERVER then return end
	
	self.NextFart = CurTime() + 4
	self.Owner:EmitSound( intro, 500, 100 )
end

function SWEP:Think()
end

function SWEP:PrimaryAttack()
	if not SERVER then return end
	
	if self.NextFart > CurTime() then return end
	self.NextFart = CurTime() + 1
	
	local rand = math.random(#offers)
	
	self.Owner:EmitSound( offers[rand], 500, 100 )
end
 
function SWEP:SecondaryAttack()
	if not SERVER then return end
	
	if self.NextFart > CurTime() then return end
	self.NextFart = CurTime() + 1
	
	local rand = math.random(#requests)
	
	self.Owner:EmitSound( requests[rand], 500, 100 )
end

function SWEP:Reload()
	if not SERVER then return end
	
	if self.NextFart > CurTime() then return end
	self.NextFart = CurTime() + 1
	
	self.Owner:EmitSound( longrange, 500, 100 )
end
