TOOL.Category		= "Dvondrake's Stuff"
TOOL.Name			= "#Console Box"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.ClientConVar[ "useonspawner" ]		= 0
TOOL.ClientConVar[ "command" ]			= "say Hello World, I'm %name%"
TOOL.ClientConVar[ "label" ]			= "say Hello"

cleanup.Register( "consoles" )

if ( CLIENT ) then

	language.Add( "Tool_console_name", "Console Box" )
	language.Add( "Tool_console_desc", "Press E on a button and execute a console command." )
	language.Add( "Tool_console_0", "Set the command and click to spawn!" )

	language.Add( "Undone_Console", "Undone Console" )
	language.Add( "Cleanup_consoles", "Consoles" )
	language.Add( "Cleaned_consoles", "Cleaned up all Consoles" )

end

function TOOL:LeftClick( trace )
	local hit = trace.HitPos
	if (CLIENT) then return true end
	
	if ( !self:GetOwner():IsAdmin() ) then 
		self:GetOwner():SendLua("GAMEMODE:AddNotify(\"Sorry, this STOOL is for admins only!\", NOTIFY_GENERIC, 5); surface.PlaySound(\"ambient/water/drip"..math.random(1, 4)..".wav\")")
		return false
	end

	local pl			= self:GetOwner()
	local useonspawner	= self:GetClientNumber( "useonspawner" )
	local command		= self:GetClientInfo( "command" )
	local label			= self:GetClientInfo( "label" )
	
	local ent = ""
	if trace.Entity:IsValid() and trace.Entity:GetClass() == "sent_console" then
		ent = trace.Entity
	else
		ent = ents.Create( "sent_console" )
		ent:SetPos( hit + Vector( 0, 0, 4 ) )
		ent:Spawn()
	end
	
	ent.Command = command
	ent.UseOnSpawner = useonspawner
	ent.Spawner = pl
	
	ent:SetLabel( label )

	undo.Create("Console")
	undo.AddEntity( ent )
	undo.SetPlayer( pl )
	undo.Finish()

	pl:AddCleanup( "consoles", ent )

	return true
end

function TOOL:RightClick( trace )

end

function TOOL:Reload( trace )

end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", {	Text = "#Tool_console_name", Description	= "#Tool_console_desc" }  )

	CPanel:AddControl( "CheckBox", { Label = "Execute command on yourself", Command = "console_useonspawner" } )
	
	CPanel:AddControl( "TextBox", { Label = "Command", MaxLength = 255, Command = "console_command" } )	
	
	CPanel:AddControl( "TextBox", { Label = "Label", MaxLength = 255, Command = "console_label" } )	
	
	CPanel:AddControl( "Label", { Text = "Putting %name% in the command field will be replaced by the name of the person who presses the button. If the 'execute command on yourself' box is unchecked, the command will be executed on the person who presses the button." } )	
	
end
