TOOL.Category		= "Dvondrake's Stuff"
TOOL.Name			= "#Remotes"
TOOL.Command		= nil
TOOL.ConfigName		= ""

TOOL.ClientConVar[ "radius" ]		= "128"
TOOL.ClientConVar[ "use" ]			= "1"
TOOL.ClientConVar[ "unlock" ]		= 0
TOOL.ClientConVar[ "openanims" ]	= 0
TOOL.ClientConVar[ "lock" ]		= 0
TOOL.ClientConVar[ "closeanims" ]	= 0

cleanup.Register( "remotes" )

if ( CLIENT ) then

	language.Add( "Tool_remote_name", "Remotes" )
	language.Add( "Tool_remote_desc", "Make a prop press E on something remotely! Good for opening doors and pushing buttons." )
	language.Add( "Tool_remote_0", "Spawn a prop, set the radius, set the button, and click." )

	language.Add( "Undone_Remote", "Undone Remote" )
	language.Add( "Cleanup_remotes", "Remotes" )
	language.Add( "Cleaned_remotes", "Cleaned up all Remotes" )

end

if ( SERVER ) then

	function useRemote( ply, ent, radius, unlock, openanims, lock, closeanims )
		if not ent:IsValid() then return end
		
		for k, v in pairs( ents.FindInSphere( ent:GetPos(), radius ) ) do
			v:Fire( "use", 0 )
			if unlock == 1 then
				v:Fire( "unlock", 0 )
			end
			if openanims == 1 then
				v:Fire( "setanimation", "open", 0 )
			end
			if lock == 1 then
				v:Fire( "lock", 0 )
			end
			if closeanims == 1 then
				v:Fire( "setanimation", "close", 0 )
			end
		end 
	end
	numpad.Register( "remote_press", useRemote )
	
end

function TOOL:LeftClick( trace )
	local ent = trace.Entity
	if (CLIENT) then return true end
	if SERVER && !util.IsValidPhysicsObject( ent, trace.PhysicsBone ) then return false end

	if ent && ent:GetClass() != "prop_physics" then return false end

	local pl			= self:GetOwner()
	local radius		= math.Clamp( self:GetClientNumber( "radius" ), 1, 255 )
	local usekey		= self:GetClientNumber( "use" )
	local unlock		= self:GetClientNumber( "unlock" )
	local openanims		= self:GetClientNumber( "openanims" )
	local lock			= self:GetClientNumber( "lock" )
	local closeanims	= self:GetClientNumber( "closeanims" )
	
	if unlock == 1 and lock == 1 then
		lock = 0
	end
	if openanims == 1 and closeanims == 1 then
		openanims = 0
	end

	numpad.OnDown( pl, usekey, "remote_press", ent, radius, unlock, openanims, lock, closeanims )

	undo.Create("Remote")
	undo.AddEntity( ent )
	undo.SetPlayer( pl )
	undo.Finish()

	pl:AddCleanup( "remotes", ent )

	return true

end

function TOOL:RightClick( trace )

end

function TOOL:Reload( trace )

end

function TOOL.BuildCPanel( CPanel )

	CPanel:AddControl( "Header", {	Text = "#Tool_remote_name", Description	= "#Tool_remote_desc" }  )
	
	CPanel:AddControl( "Slider",  { Label	= "Radius",
					Type	= "Decimal",
					Min		= 1,
					Max		= 255,
					Command = "remote_radius"} )

	CPanel:AddControl( "Numpad", { Label = "#Use", Command = "remote_use", ButtonSize = 22 } )
	
	CPanel:AddControl( "CheckBox", { Label = "Unlock doors", Command = "remote_unlock" } )
	
	CPanel:AddControl( "CheckBox", { Label = "Lock doors", Command = "remote_lock" } )
	
	CPanel:AddControl( "CheckBox", { Label = "Open animation-based doors", Command = "remote_openanims" } )
	
	CPanel:AddControl( "CheckBox", { Label = "Close animation-based doors", Command = "remote_closeanims" } )
	
	CPanel:AddControl( "Label", { Text = "Don't select both lock and unlock or open and close! Radius cannot exceed 255." } )	
end
