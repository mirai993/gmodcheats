local function UnviewModel( ply, cmd, args )
	ply:GetActiveWeapon():SetColor( Color( 0, 0, 0, 0 ) )
	ply:GetActiveWeapon():DrawShadow( false )
end
concommand.Add("unviewmodel", UnviewModel)

function VecMul( a, b )
	return Vector( a.x * b.x, a.y * b.y, a.z * b.z )
end

local function Scale( ply, cmd, args )
	if not ply:IsSuperAdmin() then return end
	
	args[1] = math.Clamp( tonumber(args[1]), 0.01, 10 )
	
	if args[2] == "g" then		
		args[2] = args[1]
		args[3] = args[1]
		args[4] = args[1]
	end
	
	args[2] = math.Clamp( tonumber(args[2]), 0.01, 10 )
	args[3] = math.Clamp( tonumber(args[3]), 0.01, 10 )
	args[4] = math.Clamp( tonumber(args[4]), 0.01, 10 )

	if #args < 2 then
		ply:PrintMessage( HUD_PRINTCONSOLE, "Usage: setmyscale X Y Z speed\nOR\nsetmyscale <scale> g\nLeave the g there to scale globally by one number." )
		return
	end
	
	ply:SetWalkSpeed( 125 * math.Clamp(tonumber(args[4]), 0.4, 5) )
	ply:SetRunSpeed( 300 * math.Clamp(tonumber(args[4]), 0.2, 3) )
	ply:SetCrouchedWalkSpeed( 85 * math.Clamp(tonumber(args[4]), 0.3, 1.5) )
	
	ply:SetStepSize( 18 * math.Clamp(tonumber(args[4]), 0.3, 10) )
	ply:SetJumpPower( 160 * math.Clamp(tonumber(args[4]), 0.3, 20) )
	
	for k, v in pairs( player.GetAll() ) do
		v:SendLua( "player.GetByID("..ply:EntIndex().."):SetModelScale( Vector( "..args[1]..", "..args[2]..", "..args[3].." ) )" )
	end
	
	ply:SetHull( VecMul( Vector( -16, -16, 00 ), Vector( args[1], args[2], args[3] ) ), VecMul( Vector( 16, 16, 72 ), Vector( args[1], args[2], args[3] ) ) )
	ply:SetHullDuck( VecMul( Vector( -16, -16, 00 ), Vector( args[1], args[2], args[3] ) ), VecMul( Vector( 16, 16, 36 ), Vector( args[1], args[2], args[3] ) ) )
	
	ply:SetViewOffset( Vector( 0, 0, 64 / 72 * math.Clamp(tonumber(args[3]), 0.06, 10) * 72 ) )
	ply:SetViewOffsetDucked( Vector( 0, 0, 28 / 72 * math.Clamp(tonumber(args[3]), 0.06, 10) * 72	) )
	
	fovScale = tonumber(args[3])
	if fovScale > 1 then
		fovScale = math.Clamp(fovScale, 1, 1.5)
	elseif fovScale < 1 then
		fovScale = math.Clamp(fovScale + 1, 1, 1.5)
	end
	
	ply:SetFOV( 90 * fovScale )
	
	ply.scaleTable = { 
						X = args[1],
						Y = args[2],
						Z = args[3],
						speed = args[4],
						fov = fovScale
					}
					
	if args[1] == "1" and args[2] == "g" then
		ply.scaleTable = nil
		ply:ResetHull()
		return
	end
end
concommand.Add("setmyscale", Scale)

local function RescaleOnFirstSpawn( ply )
	timer.Simple(5, function() 
		for k, v in pairs( player.GetAll() ) do
			if v.scaleTable then
				ply:SendLua( "player.GetByID("..v:EntIndex().."):SetModelScale( Vector( "..v.scaleTable.X..", "..v.scaleTable.Y..", "..v.scaleTable.Z.." ) )" )
			end
		end
	end)
end
hook.Add( "PlayerInitialSpawn", "RescaleOnFirstSpawn", RescaleOnFirstSpawn )

local function RedoSpeed( ply )
	timer.Simple(2, function()
		if ply.scaleTable then
			ply:SetWalkSpeed( 125 * math.Clamp(tonumber(ply.scaleTable.speed), 0.4, 5) )
			ply:SetRunSpeed( 300 * math.Clamp(tonumber(ply.scaleTable.speed), 0.2, 3) )
			ply:SetCrouchedWalkSpeed( 85 * math.Clamp(tonumber(ply.scaleTable.speed), 0.3, 1.5) )
			
			ply:SetStepSize( 18 * math.Clamp(tonumber(ply.scaleTable.Z), 0.3, 10) )
			ply:SetJumpPower( 160 * math.Clamp(tonumber(ply.scaleTable.Z), 0.3, 20) )
			
			fovScale = tonumber(ply.scaleTable.Z)
			if fovScale > 1 then
				fovScale = math.Clamp(fovScale, 1, 1.5)
			elseif fovScale < 1 then
				fovScale = math.Clamp(fovScale + 1, 1, 1.5)
			end
			
			ply:SetFOV( 90 * fovScale )
		end
	end)
end
hook.Add( "PlayerSpawn", "RedoSpeed", RedoSpeed )

local function FOVThink()
	for k, v in pairs( player.GetAll() ) do
		if v.scaleTable then
			if not v.lastWep then
				v.lastWep = v:GetActiveWeapon()
			end
			
			if v:GetActiveWeapon() ~= v.lastWep then
				v:SetFOV( 90 * v.scaleTable.fov )
			end
			v.lastWep = v:GetActiveWeapon()
		end
	end
end
hook.Add( "Think", "FOVThink", FOVThink )

