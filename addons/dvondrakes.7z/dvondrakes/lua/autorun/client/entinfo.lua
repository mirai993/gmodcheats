----------------------------------------------------------------------------------------
----------------------      Entity Info script by Excel       ----------------------
----- Note: This was made as a development tool only. NOT a hack -----
------------------------------------ Version 1.6 ------------------------------------
----------------------------------------------------------------------------------------

-- Instructions:
--		- Put in garrysmod/lua/autorun/client and create the folders if neccessary
--		- Bind a key to +entinfo (example: bind alt "+entinfo")
--		- Top center of your screen will show your target's class, entindex, and health (if player).
--		- Hold down your +entinfo key (alt) to activate view mode.
--		- Press E while in view mode to toggle locking onto a target.
--		- Press R while in view mode to lock onto the nearest player.
--		- Press X while in view mode to lock onto the nearest living NPC.
--		- Info at top will turn yellow and only show the info for your locked target when locked on.

-- Known Bugs:
--		- Health only shows up for players. This is because Entity.Health doesn't work properly clientside,
--		and only returns a number besides 0 for players. Unfortunately, I can't fix this. Go bug Garry to fix it.

local ViewEnts = nil;
local LockEnt = nil;
local LastUse = 0;
local entCache = {};

local fadeDist = CreateClientConVar("entinfo_fadedist", "200", false, false)
local maxDist = CreateClientConVar("entinfo_maxdist", "400", false, false)
local showHUD = CreateClientConVar("entinfo_hudenabled", "1", false, false)
local onlyPlayers = CreateClientConVar("entinfo_onlyplayers", "0", true, false)
local switchTime = CreateClientConVar("entinfo_switchtime", "0.25", false, false)

surface.CreateFont( "Tahoma", 16, 1000, true, false, "EntInfoText" )

local function EntityInfo()  
	local pos = LocalPlayer():GetShootPos() 
	local ang = LocalPlayer():GetAimVector() 
	local tr = {} 
	tr.start = pos 
	tr.endpos = pos+(ang*80000) 
	tr.filter = LocalPlayer()
	local trace = util.TraceLine( tr )
	
	if not trace.Hit then return end
	
	local ent = trace.Entity
	
	local col = Color(255,255,255,255)
	if LockEnt and LockEnt:IsValid() then
		col = Color(255,255,20,255)
		ent = LockEnt
	end
	
	local entinfo = ent:GetClass() .. " [" .. ent:EntIndex() .. "]"
	
	if ent:IsPlayer() then
		entinfo = ent:Name() .. " [" .. ent:EntIndex() .. "]"
	end

	if showHUD:GetBool() then
		draw.SimpleTextOutlined( 
			entinfo, 
			"EntInfoText",
			ScrW() / 2 - 70,
			40,
			col,
			1,
			1,
			1,
			Color(0,0,0,255)
		) 
	
		if ent:IsPlayer() then
			draw.SimpleTextOutlined( 
				ent:Health(),
				"EntInfoText",
				ScrW() / 2 - 70,
				64,
				Color(255,255,255,255),
				1,
				1,
				1,
				Color(0,0,0,255)
			) 
		end
	end
	
	if ViewEnts then
		local pl = LocalPlayer():GetPos()
		entCache = {}
		
		if not onlyPlayers:GetBool() then
			for k, v in pairs( ents.FindInSphere( pl, maxDist:GetInt()  ) ) do
				if v:IsValid() then
					v['pos'] = v:LocalToWorld( v:OBBCenter() )
					v['dist'] = pl:Distance( v['pos'] )
					
					v['a'] = 255
					if v['dist'] >= fadeDist:GetInt() then
						v['a'] = math.Clamp((1 - ((v['dist'] - fadeDist:GetInt() ) / (maxDist:GetInt()  - fadeDist:GetInt()))) * 255, 0, 255)
					end
					
					v['scr'] = v['pos']:ToScreen()
					
					v['col'] = Color(255, 255, 255, v['a'])
					if v:IsPlayer() then
						v['col'] = Color(20, 20, 255, v['a'])
					elseif v:IsNPC() then
						v['col'] = Color(255, 20, 20, v['a'])
					elseif string.find(v:GetClass(), "prop_") then
						v['col'] = Color(20, 255, 20, v['a'])
					end
					
					v['info'] = v:GetClass()
					if v:IsPlayer() then
						v['info'] = v:Name() .. "\n (" .. math.Round(v:GetPos():Distance(LocalPlayer():GetPos())) .. "m)"
					end
					
					v['fa'] = v['a'] / 3.4
					v['fao'] = v['a'] / 6.8
					
					if not v:IsWeapon() and v != LocalPlayer() then
						entCache[k] = v
					end
				end
			end
		elseif onlyPlayers:GetBool() then
			for k, v in pairs( player.GetAll() ) do
				v['pos'] = v:LocalToWorld( v:OBBCenter() )
				v['dist'] = pl:Distance( v['pos'] )
				
				v['a'] = 255
				
				v['scr'] = v['pos']:ToScreen()
				
				v['col'] = Color(20, 20, 255, v['a'])
				
				v['info'] = v:Name() .. "\n (" .. math.Round(v:GetPos():Distance(LocalPlayer():GetPos())) .. "m)"
				
				v['fa'] = v['a'] / 3.4
				v['fao'] = v['a'] / 6.8
				
				if v != LocalPlayer() then
					entCache[k] = v
				end
			end
		end
	
		for k, v in pairs( entCache ) do	
			if v:IsValid() then
				local pos = v['pos']
				local col = v['col']
				local a = v['a']
				local scr = v['scr']
				local info = v['info']
				local fa = v['fa']
				local fao = v['fao']
				
				draw.SimpleTextOutlined( 
					"x",
					"EntInfoText",
					scr.x,
					scr.y,
					col,
					1,
					1,
					1,
					Color(0,0,0,a)
				)
				
				draw.SimpleTextOutlined( 
					info,
					"EntInfoText",
					scr.x,
					scr.y + 15,
					Color(col.r,col.g,col.b,fa),
					1,
					1,
					1,
					Color(0,0,0,fao)
				)
			end
		end
	
		if LocalPlayer():KeyDown( IN_USE ) then
			if CurTime() > LastUse then
				LastUse = CurTime() + switchTime:GetFloat()
				
				if LockEnt then
					LockEnt = nil
				else
					if trace.Hit and trace.HitNonWorld then
						if ent:IsValid() and ent:GetPos() then
							LockEnt = ent
						end
					elseif trace.HitWorld then
						local function Callback( old )
							local pos = old.HitPos
							local ang = LocalPlayer():GetAimVector() 
							local tr = {} 
							tr.start = pos + (ang*20)
							tr.endpos = pos + (ang*80000) 
							tr.filter = Entity(0)
							local trace = util.TraceLine( tr )
							
							if trace.Hit and trace.Entity and trace.Entity:IsValid() and trace.Entity:GetPos() then
								local ent = trace.Entity								
								if LocalPlayer():GetPos():Distance( ent:GetPos() ) >= maxDist:GetInt()  then return end
								LockEnt = ent
								return
							end
						end
						Callback( trace )
					end
				end
			end
		end
		
		if LocalPlayer():KeyDown( IN_RELOAD ) then
			if CurTime() > LastUse then
				LastUse = CurTime() + switchTime:GetFloat()
				
				if #player.GetAll() > 1 then
					local temp = 80000
					local lock = nil;
					for k, v in pairs( player.GetAll() ) do
						if v ~= LockEnt then
							if LocalPlayer():GetPos():Distance( v:GetPos() ) > 65 then
								if LocalPlayer():GetPos():Distance( v:GetPos() ) < temp then
									temp = LocalPlayer():GetPos():Distance( v:GetPos() )
									lock = v
								end
							end
						end
					end
					if lock and lock:IsValid() then
						LockEnt = lock
					end
				end
			end
		end
		
		if input.IsKeyDown( KEY_X ) then
			if CurTime() > LastUse then
				LastUse = CurTime() + switchTime:GetFloat()
				
				local temp = 80000
				local lock = nil;
				for k, v in pairs( ents.GetAll() ) do
					if v:IsNPC() and v:IsValid() then
						if v ~= LockEnt then
							if LocalPlayer():GetPos():Distance( v:GetPos() ) > 65 then
								if LocalPlayer():GetPos():Distance( v:GetPos() ) < temp then
									temp = LocalPlayer():GetPos():Distance( v:GetPos() )
									lock = v
								end
							end
						end
					end
				end
				if lock and lock:IsValid() then
					LockEnt = lock
				end
			end
		end
	end
	
	if LockEnt then			
		if LockEnt:IsValid() then
			local aimpos = LockEnt:LocalToWorld( LockEnt:OBBCenter() )
			if LockEnt:IsNPC() then
				if string.find( LockEnt:GetClass(), "npc_combine_" ) then
					aimpos = LockEnt:GetAttachment(3).Pos + LockEnt:GetAngles():Forward() * -4
				elseif LockEnt:GetClass() == "npc_combinedropship" then
					aimpos = LockEnt:GetAttachment(5).Pos
				elseif LockEnt:GetClass() == "npc_combinegunship" then
					aimpos = LockEnt:GetAttachment(4).Pos
				elseif LockEnt:GetClass() == "npc_strider" then
					aimpos = LockEnt:GetAttachment(11).Pos + LockEnt:GetAngles():Forward() * -40
				elseif LockEnt:GetClass() == "npc_crow" or LockEnt:GetClass() == "npc_seagull" or LockEnt:GetClass() == "npc_pigeon" then
					aimpos = LockEnt:GetPos() + Vector(0, 0, 5)
				elseif LockEnt:GetClass() == "npc_rollermine" or LockEnt:GetClass() == "npc_manhack" or LockEnt:GetClass() == "npc_cscanner" then
					aimpos = LockEnt:GetPos()
				elseif LockEnt:GetClass() == "npc_antlion" then
					aimpos = LockEnt:GetPos() + Vector(0, 0, 30)
				elseif string.find( LockEnt:GetClass(), "npc_antlion_worker" ) then
					aimpos = LockEnt:GetAttachment(5).Pos
				elseif string.find( LockEnt:GetClass(), "npc_antlionguard" ) then
					aimpos = LockEnt:GetPos() + Vector(0, 0, 70)
				elseif string.find( LockEnt:GetClass(), "npc_hunter" ) then
					aimpos = LockEnt:GetAttachment(6).Pos
				else
					if LockEnt:GetAttachment(1) then
						aimpos = LockEnt:GetAttachment(1).Pos
					else
						aimpos = LockEnt:GetPos() + Vector(0, 0, 10)
					end
				end
			elseif LockEnt:IsPlayer() then
				aimpos = LockEnt:GetAttachment(1).Pos + LockEnt:GetAngles():Forward() * -4
			end
			
			local velocity = Vector(LockEnt:GetVelocity().X / LockEnt:GetVelocity().X,
			LockEnt:GetVelocity().Y / LockEnt:GetVelocity().Y, LockEnt:GetVelocity().Z / LockEnt:GetVelocity().Z) or Vector(0,0,0)
			
			local myVelocity = Vector(LocalPlayer():GetVelocity().X / LocalPlayer():GetVelocity().X,
			LocalPlayer():GetVelocity().Y / LocalPlayer():GetVelocity().Y, LocalPlayer():GetVelocity().Z / LocalPlayer():GetVelocity().Z) or Vector(0,0,0)
			
			LocalPlayer():SetEyeAngles((aimpos + velocity + myVelocity - LocalPlayer():GetShootPos()):Angle())
		else 
			LockEnt = nil;
		end
	end
end
hook.Add("HUDPaint", "entityinfo", EntityInfo)

local function ViewOn( ply, cmd, args)
	ViewEnts = true
	return
end
concommand.Add("+entinfo", ViewOn)

local function ViewOff( ply, cmd, args)
	ViewEnts = nil
	return
end
concommand.Add("-entinfo", ViewOff)

local function TargetSelf( ply, cmd, args)
	LockEnt = ply
	return
end
concommand.Add("entinfo_targetself", TargetSelf)

local function EntInfoTarget( ply, cmd, args)
	if args[1] and Entity( args[1] ):IsValid() then
		LockEnt = Entity( args[1] )
	end
	return
end
concommand.Add("entinfo_target", EntInfoTarget)

local function EntInfoTargetClass( ply, cmd, args)
	if args[1] then
		local temp = 80000
		local lock = nil;
		for k, v in pairs( ents.GetAll() ) do
			if v:IsValid() and v:GetClass() == args[1] then
				if v ~= LockEnt then
					if LocalPlayer():GetPos():Distance( v:GetPos() ) > 65 then
						if LocalPlayer():GetPos():Distance( v:GetPos() ) < temp then
							temp = LocalPlayer():GetPos():Distance( v:GetPos() )
							lock = v
						end
					end
				end
			end
		end
		if lock and lock:IsValid() then
			LockEnt = lock
		end
	end
	return
end
concommand.Add("entinfo_targetclass", EntInfoTargetClass)

local function EntInfoTargetPlayer( ply, cmd, args)
	if args[1] then
		for k, target in pairs( player.GetAll() ) do			
			if target and target:IsValid() and string.find( target:Name(), args[1] ) then
				LockEnt = target
			end
		end
	end
	return
end
concommand.Add("entinfo_targetplayer", EntInfoTargetPlayer)