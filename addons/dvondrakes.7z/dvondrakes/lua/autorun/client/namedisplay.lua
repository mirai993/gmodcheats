local showHUD = CreateClientConVar("showplayernames", "1", false, false)

function PlayerNameDisplay()
	if showHUD:GetBool() then
		for k, v in pairs( player.GetAll() ) do
			if v ~= LocalPlayer() then
				local pos = v:EyePos()
				pos.z = pos.z + 18
				pos = pos:ToScreen()
				
				local dist = math.Round(v:GetPos():Distance(LocalPlayer():GetPos()))
				local fade = math.Clamp((1 - ((dist - 1500 ) / (3000  - 1500))) * 255, 100, 255)
				local col = team.GetColor( v:Team() )
				
				draw.DrawText( v:Name() .. "\n (" .. dist .. "m)", "ScoreboardText", pos.x, pos.y, Color( col.r, col.g, col.b, fade ), 1 )
			end
		end
	end
end
hook.Add( "HUDPaint", "PlayerNameDisplay", PlayerNameDisplay )