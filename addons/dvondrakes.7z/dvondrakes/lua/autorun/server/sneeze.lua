resource.AddFile("sound/brsneeze.wav")

local sound = Sound("brsneeze.wav")
function Sneeze(ply, cmd, args)
	ply:EmitSound( sound )
	
	timer.Simple( 0.3, function()
		local ragdoll = ents.Create( "prop_ragdoll" )
		ragdoll:SetPos( ply:GetPos() )
		ragdoll:SetAngles( ply:GetAngles() )
		ragdoll:SetModel( ply:GetModel() )
		ragdoll:Spawn()
		ragdoll:Activate()
		
		ragdoll:GetPhysicsObject():SetMass( 50000 )
		ragdoll:GetPhysicsObject():EnableGravity( false )
		ragdoll:GetPhysicsObject():SetVelocity(ply:GetForward() * -99999999999999999999999999999999999)
		
		if ply:EyeAngles().p == -89 || ply:EyeAngles().p == 89 then
			ragdoll:GetPhysicsObject():AddVelocity(Vector(0, 0, ply:EyeAngles().p * 99999999999999999999999999999999999))
		end
		
		ply:Spectate(5)
		ply:SpectateEntity(ragdoll)
		oldAngles = ply:GetAngles()
		
		ply:StripWeapons()
		ply:SetColor(0,0,0,0)
		ply:SetCollisionGroup(COLLISION_GROUP_WORLD)
		
		ply:GodEnable()
	
		timer.Simple(0.4, function( ragdoll, oldAngles ) 
			ply:GodDisable()
			ply:SetColor(255,255,255,255)
			ply:SetCollisionGroup(COLLISION_GROUP_PLAYER)
			ply:Spawn()
			ply:SetPos( ragdoll:GetPos() )
			ply:SetEyeAngles( oldAngles )
			ragdoll:Remove()
			ply:UnSpectate()
			ply:SetMoveType(MOVETYPE_NOCLIP);
			ply:SetMoveType(MOVETYPE_WALK);
			end, ragdoll, oldAngles)
	end)
end
concommand.Add("sneeze", Sneeze)