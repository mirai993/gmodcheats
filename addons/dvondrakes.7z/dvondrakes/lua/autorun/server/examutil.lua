function Notify( ply, msg )
	if not ply or not ply:IsValid() or not msg then return end
	ply:ChatPrint( msg );
	ply:SendLua("GAMEMODE:AddNotify(\"" .. msg .. "\", NOTIFY_CLEANUP, 5);");
end

function NotifyAll(  msg )
	for k, v in pairs( player.GetAll() ) do
		Notify( v, msg );
	end
end