--
-- SHARED UTILITIES
--

local vote_minTime = 5; -- Time you need to wait at mapchange to vote again
local vote_waitTime = 2; -- Time you need to wait to change your vote
local vote_voteRadio = 0.6; -- Ratio of votes needed to win
local mapVotes = {}
local vote_minVotes = 0; -- Min votes needed to win
local vote_vetoTime = 30; -- Seconds to veto until map changes
local vote_currentVeto = false;
local vote_changeTime = 5; -- Seconds till map changes (chat time)

AdminCommands = {}
AdminHelp = {}

local CONSOLE = FindMetaTable("Entity")
function CONSOLE:IsSuperAdmin()		if (!self:IsValid()) then return true else return false end end
function CONSOLE:IsAdmin()			if (!self:IsValid()) then return true else return false end end
function CONSOLE:IsModerator()		if (!self:IsValid()) then return true else return false end end
function CONSOLE:SteamID()			if (!self:IsValid()) then return "0"	end end
function CONSOLE:IPAddress()		if (!self:IsValid()) then return "CONSOLE"	end end
function CONSOLE:Nick()				if (!self:IsValid()) then return "Console"	end end
function CONSOLE:PrintMessage(LOC, MSG)		if (LOC == HUD_PRINTCONSOLE || LOC == HUD_PRINTNOTIFY) then Msg(MSG) end end
function CONSOLE:ChatPrint(MSG)				end
CONSOLE = nil

function AddAdminCommand( cmd, callback, access, desc, args, noprefix, diffconsole )
	local prefix_override = noprefix or false;
	local console_override = diffconsole or false;
	local chat = "!"..cmd;
	if prefix_override == true then
		chat = cmd;
	end
	if args ~= "none" then
		chat = chat .. " ";
	end
	local console = cmd;
	if console_override ~= false then
		console = console_override
	end
	table.insert( AdminCommands, { cmd = chat, callback = callback } );
	concommand.Add( "exam_"..console, callback )
	table.insert( AdminHelp, { cmd = console, lvl = access, desc = desc, args = args } );
end

function makePatternSafe( str )
        return str:gsub( "([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1" )
end

function NewExplode( separator, str, limit )
	local t = {}
	local curpos = 1
	while true do -- We have a break in the loop
		local newpos, endpos = str:find( separator, curpos ) -- find the next separator in the string
		if newpos ~= nil then -- if found then..
			table.insert( t, str:sub( curpos, newpos - 1 ) ) -- Save it in our table.
			curpos = endpos + 1 -- save just after where we found it for searching next time.
		else
			if limit and table.getn( t ) > limit then
				return t -- Reached limit
			end
			table.insert( t, str:sub( curpos ) ) -- Save what's left in our array.
			break
		end
	end

	return t
end

function stripQuotes( s )
	return s:gsub( "^%s*[\"]*(.-)[\"]*%s*$", "%1" )
end

function ExplodeChatString( str )
	str = string.Trim( str )
	if str == "" then return {} end
	local quotes = {}
	local t = {}
	local marker = "^*#" -- This is used as a placeholder

	str:gsub( "%b\"\"", function ( match ) -- We're finding the quote groups first.
		local s = stripQuotes( match )
		table.insert( quotes, s )

		str = str:gsub( makePatternSafe( match ), marker .. #quotes, 1 ) -- We aren't sure where in the table this should be placed, so let's leave a marker.
	end )

	t = NewExplode( "%s+", str )

	-- Now trim 'em
	for i, v in ipairs( t ) do
		t[ i ] = string.Trim( v )
	end

	for i, v in ipairs( t ) do
		if v:sub( 1, 3 ) == marker then -- Now we can read our marker into the correct place in the table.
			local num = tonumber( string.sub( v, 4 ) )
			t[ i ] = quotes[ num ]
		end
	end

	return t
end

function addAdminHook()
	function adminSay( ply, txt )
		for k, v in pairs( AdminCommands ) do
			if txt:sub( 1, string.len(v.cmd) ) == v.cmd then
				v.callback( ply, v.cmd, ExplodeChatString(string.sub( txt, string.len( v.cmd ) + 1 )) )
				return "";
			end
		end
	end
	hook.Add( "PlayerSay", "adminSay", adminSay )
end
addAdminHook()

function FindPlayers( info )
	local info = string.lower(info)
	local targets = {}
	if not info or info == "" then
		for k, v in pairs( player.GetAll() ) do
			table.insert(targets, v)
		end
		return targets
	end
	for k, v in pairs( player.GetAll() ) do
		if( tonumber( info ) == v:EntIndex() ) then
			if not table.HasValue( targets, v ) then
				table.insert(targets, v)
			end
		end
		if( info == v:SteamID() ) then
			if not table.HasValue( targets, v ) then
				table.insert(targets, v)
			end
		end
		if( string.find( string.lower(v:Nick()), info ) ~= nil ) then
			if not table.HasValue( targets, v ) then
				table.insert(targets, v)
			end
		end
		if( string.find( string.lower(v:GetNick()), info ) ~= nil ) then
			if not table.HasValue( targets, v ) then
				table.insert(targets, v)
			end
		end
	end
	
	return targets
end

function FindPlayer( info )
	local info = string.lower(info)
	for k, v in pairs( player.GetAll() ) do
		if( tonumber( info ) == v:EntIndex() ) then
			return v;
		end
		if( info == v:SteamID() ) then
			return v;
		end
		if( string.find( string.lower(v:Nick()), info ) ~= nil ) then
			return v;
		end
		if( string.find( string.lower(v:GetNick()), info ) ~= nil ) then
			return v;
		end
	end
	
	return nil;
end

local function muteCheck( ply, strText )
	if ply.mute == true then return "" end
end
hook.Add( "PlayerSay", "muteCheck", muteCheck ) -- Very low priority

function MessageToAll( args )
	for k, v in pairs( player.GetAll() ) do
		v:PrintMessage( HUD_PRINTTALK, args );
	end
	Msg(args.."\n")
end

function Physdrop(pl,target)
	if target:IsPlayer() then
	target:SetMoveType(MOVETYPE_WALK);
	return true;
	end
end

function Physpick(pl,target)
		if pl:IsAdmin() then
		if target:IsPlayer() then
		target:SetMoveType(MOVETYPE_NOCLIP);
		return true;
		end
	end
end
hook.Add("PhysgunPickup", "Playergrapphys", Physpick);
hook.Add("PhysgunDrop" , "Playergrapdrop", Physdrop);


--
-- PUBLIC COMMANDS
--

-- Help
local function accHelp( ply, cmd, args )
	ply:PrintMessage( HUD_PRINTCONSOLE, "EXAM Help:\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "All commands can be used in the console or in the chat.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "To use chat commands, precede the command name with an exclamation point (!).\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "If you want to use the console, precede the command name with 'exam_'.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "For example, you can use !help (in the chat) or exam_help (in the console).\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "Remember, some commands have differently formatted chat commands.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "Arguments precede the command name as usual. Arguments should ALWAYS be in quotes.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "Valid arguments for each command are listed in the command list.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "You can use someone's userid, steamid, OOC name, or IC name for target.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "Some commands can take multiple targets, while some only take one.\n" );
	ply:PrintMessage( HUD_PRINTCONSOLE, "\nCommand list:\n" );

	ply:PrintMessage( HUD_PRINTCONSOLE, "\n Public commands:" );
	for k, v in pairs( AdminHelp ) do
		if v.lvl == "public" then
			ply:PrintMessage( HUD_PRINTCONSOLE, "  o "..v.cmd.." - "..v.desc.." (args: "..v.args..")" );
		end
	end
	
	ply:PrintMessage( HUD_PRINTCONSOLE, "\n Moderator commands:" );
	for k, v in pairs( AdminHelp ) do
		if v.lvl == "moderator" and ply:IsModerator() then
			ply:PrintMessage( HUD_PRINTCONSOLE, "  o "..v.cmd.." - "..v.desc.." (args: "..v.args..")" );
		end
	end
	
	ply:PrintMessage( HUD_PRINTCONSOLE, "\n Administrator commands:" );
	for k, v in pairs( AdminHelp ) do
		if v.lvl == "admin" and ply:IsAdmin() then
			ply:PrintMessage( HUD_PRINTCONSOLE, "  o "..v.cmd.." - "..v.desc.." (args: "..v.args..")" );
		end
	end
	
	ply:PrintMessage( HUD_PRINTCONSOLE, "\n SuperAdmin commands:" );
	for k, v in pairs( AdminHelp ) do
		if v.lvl == "superadmin" and ply:IsSuperAdmin() then
			ply:PrintMessage( HUD_PRINTCONSOLE, "  o "..v.cmd.." - "..v.desc.." (args: "..v.args..")" );
		end
	end
	
	ply:PrintMessage( HUD_PRINTCONSOLE, "\nEnd of help." );
	ply:PrintMessage( HUD_PRINTTALK, "Check your console for the EXAM help screen!" );
end
AddAdminCommand( "help", accHelp, "public", "Shows this help screen", "none" )

-- ASay
local function accASay( ply, cmd, args )
	for k, v in pairs( player.GetAll() ) do
		if v:IsModerator() then
			if not ply:IsModerator() then
				v:PrintMessage( HUD_PRINTTALK, "(ADMIN) **"..ply:Nick()..": "..table.concat(args, " ") );
			else
				v:PrintMessage( HUD_PRINTTALK, "(ADMIN) "..ply:Nick()..": "..table.concat(args, " ") );
			end
		end
	end
	Msg("(ADMIN) *"..ply:Nick()..": "..table.concat(args, " ").."\n")
	return "";
end
AddAdminCommand( "asay", accASay, "public", "Says something to the admins", "text" )

-- Tell
local function accTell( ply, cmd, args )
	local target = FindPlayer( args[1] )
	if target then
		table.remove(args, 1)
		target:PrintMessage( HUD_PRINTTALK, "(TELL) ** "..ply:Nick()..": "..table.concat(args, " ") );
		ply:PrintMessage( HUD_PRINTTALK, "(TELL) *"..target:Nick().."*"..ply:Nick()..": "..table.concat(args, " ") );
	end
	return "";
end
AddAdminCommand( "tell", accTell, "public", "Send a private tell message to someone", "text" )

function GetHighestAccess( ply )
	if ply:IsSuperAdmin() then
		return "superadmin"
	elseif ply:IsAdmin() then
		return "admin"
	elseif ply:IsModerator() then
		return "moderator"
	elseif ply:IsGold() then
		return "gold"
	else
		return "guest"
	end
end

-- Who
local function accWho( ply, cmd, args )
	ply:PrintMessage( HUD_PRINTCONSOLE, "\nEXAM Player List:" );
	for k, v in pairs( player.GetAll() ) do
		ply:PrintMessage( HUD_PRINTCONSOLE, "\n " .. v:Nick() .. ":" );
		ply:PrintMessage( HUD_PRINTCONSOLE, "  o Name: " .. v:GetNick() );
		ply:PrintMessage( HUD_PRINTCONSOLE, "  o Job: " .. v:GetJob() );
		ply:PrintMessage( HUD_PRINTCONSOLE, "  o Team: " .. TeamGetName( v ) );
		ply:PrintMessage( HUD_PRINTCONSOLE, "  o Access: " .. GetHighestAccess( v ) );
	end
	ply:PrintMessage( HUD_PRINTCONSOLE, "\n" );
	ply:PrintMessage( HUD_PRINTTALK, "Check your console for the EXAM player list!" );
	return "";
end
AddAdminCommand( "who", accWho, "public", "See info about everyone", "none" )


--
-- MODERATOR COMMANDS
--

-- TSay
local function accTSay( ply, cmd, args )
	if ply:IsModerator() then
		MessageToAll( table.concat(args, " ") );
	end
	return "";
end
AddAdminCommand( "tsay", accTSay, "moderator", "Prints an anonymous message in the chat box", "text" )

-- CSay
local function accCSay( ply, cmd, args )
	if ply:IsModerator() then
		for k, v in pairs( player.GetAll() ) do
			csay( v, table.concat(args, " "), Color( 255, 255, 255, 255 ), 5 )
		end
	end
	return "";
end
AddAdminCommand( "csay", accCSay, "moderator", "Prints a message in the center of everyones' screens", "text" )
concommand.Add( "exam_csay", accCSay )

-- Kick
local function accKick( ply, cmd, args )
	if ply:IsModerator() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			if args[2] then
				game.ConsoleCommand( "kickid " .. target:UserID() .. " \"" .. args[2] .. "\"\n" )
				MessageToAll( string.format("%s kicked %s (%s)", ply:Nick(), target:Nick(), args[2]) );
			else
				game.ConsoleCommand( "kickid " .. target:UserID() .. "\n" )
				MessageToAll( string.format("%s kicked %s", ply:Nick(), target:Nick()) );
			end
		else
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "kick", accKick, "moderator", "Kicks someone off the server", "target, reason [opt]" )

-- Ban
local function accBan( ply, cmd, args )
	if ply:IsModerator() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			AddBan ( target, args[2], args[3], ply )
		else
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "ban", accBan, "moderator", "Bans someone from the server", "target, time, reason [opt]" )

function AddBan ( target, input, reason, banner )	
	local banby;
	local tnick = target:Nick()
	local reason = string.Replace( reason, "\"", "" )
	
	if banner and banner:IsValid() then
		banby = banner:Nick()
		bsid = banner:SteamID()
	else
		banby = "Console"
		bsid = "0"
	end
	
	bantime = input * 60
	steamid = target:SteamID()
	if input == 0 then
		comment = string.format("[Banned] %s (PERMABAN)", reason)
	else
		comment = string.format("[Banned] %s (%i minute[s])", reason, input)
	end
	game.ConsoleCommand( "kickid " .. steamid .. " \"" .. comment .. "\"\n" )
	game.ConsoleCommand( "banid " .. input .. " " .. steamid .. ";writeid\n" )
end

-- Noclip
local function accNoclip( ply, cmd, args )
	if ply:IsModerator() then
		local target = ply
		if args[1] then
			if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
			target = FindPlayer( args[1] )
		end
		if target then
			if target:GetMoveType() == MOVETYPE_WALK then
				target:SetMoveType( MOVETYPE_NOCLIP )
			elseif target:GetMoveType() == MOVETYPE_NOCLIP then
				target:SetMoveType( MOVETYPE_WALK )
			end
		else
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "noclip", accNoclip, "moderator", "Noclips you (no arg) or someone else", "target [opt]" )

-- Mute
local function accMute( ply, cmd, args )
	if ply:IsModerator() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target.mute = true
			MessageToAll( string.format("%s muted %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "mute", accMute, "moderator", "Mutes someone's speech", "target[s]" )

-- Unmute
local function accUnmute( ply, cmd, args )
	if ply:IsModerator() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target.mute = false
			MessageToAll( string.format("%s unmuted %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "unmute", accUnmute, "moderator", "Allows a muted person to speak again", "target[s]" )

-- Slap
local function SlapTarget( target, damage, power )
	if target:GetMoveType() == MOVETYPE_OBSERVER then return end

	damage = damage or 0
	power = power or 500

	if not target:Alive() then
		return
	end

	if target:InVehicle() then
		target:ExitVehicle()
	end

	if target:GetMoveType() == MOVETYPE_NOCLIP then
		target:SetMoveType( MOVETYPE_WALK )
	end
	
	local slapSounds = {
		"physics/body/body_medium_impact_hard1.wav",
		"physics/body/body_medium_impact_hard2.wav",
		"physics/body/body_medium_impact_hard3.wav",
		"physics/body/body_medium_impact_hard5.wav",
		"physics/body/body_medium_impact_hard6.wav",
		"physics/body/body_medium_impact_soft5.wav",
		"physics/body/body_medium_impact_soft6.wav",
		"physics/body/body_medium_impact_soft7.wav",
	}

	local sound_num = math.random( #slapSounds ) -- Choose at random
	target:EmitSound( slapSounds[ sound_num ] )

	local direction = Vector( math.random( 20 )-10, math.random( 20 )-10, math.random( 20 )-5 ) -- Make it random, slightly biased to go up.

	direction = direction:Normalize()

	local accel = power * 1
	accel = direction * accel

	if target:GetMoveType() == MOVETYPE_VPHYSICS then
		-- a = f/m , so times by mass to get the force.
		local force = accel * target:GetPhysicsObject():GetMass()
		target:GetPhysicsObject():ApplyForceCenter( force )
	else
		target:SetVelocity( accel )
	end

	local newHp = target:Health() - damage
	if newHp <= 0 then
		if target:IsPlayer() then
			target:Kill()
		else
			target:Fire( "break", 1, 0 )
		end
	end
	target:SetHealth( newHp )
end

local function accSlap( ply, cmd, args )
	if ply:IsModerator() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			SlapTarget( target, args[2] or nil, args[3] or nil )
			MessageToAll( string.format("%s slapped %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "slap", accSlap, "moderator", "Slaps someone", "target[s], damage [opt], power [opt]" )

-- Slay
local function accSlay( ply, cmd, args )
	if ply:IsModerator() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target:Kill()	
			MessageToAll( string.format("%s slayed %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "slay", accSlay, "moderator", "Slays (kills) someone", "target" )

-- Map
local function accMap( ply, cmd, args )
	if ply:IsModerator() then
		if not file.Exists( "../maps/" .. args[1] .. ".bsp" ) then
			Notify( ply, "That map doesn't exist!" )
			return
		end
		local map = args[1]
		MessageToAll( string.format("%s changed map to %s", ply:Nick(), args[1] ) );
		timer.Simple(vote_changeTime, game.ConsoleCommand, "changelevel " .. map .. "\n" )
	end
end
AddAdminCommand( "map", accMap, "moderator", "Changes the map", "map name" )

-- Jail
local function accJail( ply, cmd, args )	
	if not ply:IsModerator() then return end
	local mdl1 = Model( "models/props_c17/fence01b.mdl" )
	local mdl2 = Model( "models/props_c17/fence02b.mdl" )
	local jail = {
		{ pos = Vector( 35, 0, 60 ), ang = Angle( 0, 0, 0 ), mdl=mdl2 },
		{ pos = Vector( -35, 0, 60 ), ang = Angle( 0, 0, 0 ), mdl=mdl2 },
		{ pos = Vector( 0, 35, 60 ), ang = Angle( 0, 90, 0 ), mdl=mdl2 },
		{ pos = Vector( 0, -35, 60 ), ang = Angle( 0, 90, 0 ), mdl=mdl2 },
		{ pos = Vector( 0, 0, 110 ), ang = Angle( 90, 0, 0 ), mdl=mdl1 },
		{ pos = Vector( 0, 0, -5 ), ang = Angle( 90, 0, 0 ), mdl=mdl1 },
	}
	
	local targets = FindPlayers( args[1] )
	
	for _, v in ipairs( targets ) do

		if v.jail then -- They're already jailed
			v.jail.unjail()
		end

		MessageToAll( string.format("%s jailed %s", ply:Nick(), v:Nick() ) );
		if v:InVehicle() then
			local vehicle = v:GetParent()
			v:ExitVehicle()
			vehicle:Remove()
		end

		if v:GetMoveType() == MOVETYPE_NOCLIP then -- Take them out of noclip
			v:SetMoveType( MOVETYPE_WALK )
		end

		local pos = v:GetPos()

		local walls = {}
		for _, info in ipairs( jail ) do
			local ent = ents.Create( "prop_physics" )
			ent:SetModel( info.mdl )
			ent:SetPos( pos + info.pos )
			ent:SetAngles( info.ang )
			ent:Spawn()
			ent:GetPhysicsObject():EnableMotion( false )
			table.insert( walls, ent )
		end

		local function unjail()
			for _, ent in ipairs( walls ) do
				if ent:IsValid() then
					ent:Remove()
				end
			end
			if not v:IsValid() then return end -- Make sure they're still connected

			v.jail = nil
		end

		for _, ent in ipairs( walls ) do
			ent:DisallowDeleting( true )
			ent:DisallowMoving( true )
		end
		v.jail = { pos=pos, unjail=unjail }
	end
	if #targets < 1 then
		Notify(ply, "Target not found!")
	end
end
AddAdminCommand( "jail", accJail, "moderator", "Puts someone in a jail", "target[s]" )

-- Unjail
local function accUnJail( ply, cmd, args )	
	if not ply:IsModerator() then return end
	local targets = FindPlayers( args[1] )
	for _, v in ipairs( targets ) do
		if v.jail then
			MessageToAll( string.format("%s unjailed %s", ply:Nick(), v:Nick() ) );
			v.jail.unjail()
			v.jail = nil
		end
	end
	if #targets < 1 then
		Notify(ply, "Target not found!")
	end
end
AddAdminCommand( "unjail", accUnJail, "moderator", "Unjails someone in a jail", "target[s]" )

-- Various jail-related hooks and stuff
local function jailSpawnCheck( ply )
	if ply.jail then
		ply:SetPos( ply.jail.pos )
	end
end
hook.Add( "PlayerSpawn", "jailSpawnCheck", jailSpawnCheck )

local function jailDisconnectedCheck( ply )
	if ply.jail then
		ply.jail.unjail()
	end
end
hook.Add( "PlayerDisconnected", "jailDisconnectedCheck", jailDisconnectedCheck )

local function tool( ply, tr, toolmode, second )
	if tr.Entity.NoMoving then
		return false
	end

	if tr.Entity.NoDeleting then
		return false
	end
end
hook.Add( "CanTool", "EntToolCheck", tool, -10 )

local function physgun( ply, ent )
	if ent.NoMoving then return false end
end
hook.Add( "PhysgunPickup", "EntPhysCheck", physgun, -10 )

-- Decals
local function accDecals( ply, cmd, args )
	if ply:IsModerator() then
		for k, v in pairs( player.GetAll() ) do
			 v:ConCommand("r_cleardecals\n")
			 v:ConCommand("r_cleardecals\n")
		end
		MessageToAll( string.format("%s cleared all the decals on the map", ply:Nick() ) );
	end
end
AddAdminCommand( "decals", accDecals, "moderator", "Clears all the decals on the map", "none" )

-- Teleport stuff
local function playerSend( from, to, force )
	if not to:IsInWorld() and not force then return false end -- No way we can do this one

	local yawForward = to:EyeAngles().yaw
	local directions = { -- Directions to try
		math.NormalizeAngle( yawForward - 180 ), -- Behind first
		math.NormalizeAngle( yawForward + 90 ), -- Right
		math.NormalizeAngle( yawForward - 90 ), -- Left
		yawForward,
	}

	local t = {}
	t.start = to:GetPos() + Vector( 0, 0, 32 ) -- Move them up a bit so they can travel across the ground
	t.filter = { to, from }

	local i = 1
	t.endpos = to:GetPos() + Angle( 0, directions[ i ], 0 ):Forward() * 47 -- (33 is player width, this is sqrt( 33^2 * 2 ))
	local tr = util.TraceEntity( t, from )
    while tr.Hit do -- While it's hitting something, check other angles
    	i = i + 1
    	if i > #directions then  -- No place found
			if force then
				return to:GetPos() + Angle( 0, directions[ 1 ], 0 ):Forward() * 47
			else
				return false
			end
		end

		t.endpos = to:GetPos() + Angle( 0, directions[ i ], 0 ):Forward() * 47

		tr = util.TraceEntity( t, from )
    end

	return tr.HitPos
end

-- Bring
local function accBring( ply, cmd, args )	
	if not ply:IsModerator() then return end
	if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
	local target = FindPlayer( args[1] )
	if target then
		if target == ply then
			Notify( ply, "You can't bring yourself!" )
			return
		end
		if not target:Alive() then
			Notify( ply, target:Nick() .. " is dead!" )
			return
		end
		if ply:InVehicle() then
			Notify( ply, "Please leave the vehicle first!", true )
			return
		end

		local newpos = playerSend( target, ply, target:GetMoveType() == MOVETYPE_NOCLIP )
		if not newpos then
			Notify( ply, "Can't find a place to put them!" )
			return
		end

		if target:InVehicle() then
			target:ExitVehicle()
		end

		local newang = (ply:GetPos() - newpos):Angle()

		target:SetPos( newpos )
		target:SetEyeAngles( newang )
		target:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
		
		MessageToAll( string.format("%s teleported %s to him/her", ply:Nick(), target:Nick() ) );
	else
		Notify(ply, "Target not found!")
	end
end
AddAdminCommand( "bring", accBring, "moderator", "Teleports someone to you", "target" )

-- Goto
local function accGoto( ply, cmd, args )
	if not ply:IsModerator() then return end
	if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
	local target = FindPlayer( args[1] )
	if target then
		if target == ply then
			Notify( ply, "You can't goto yourself!" )
			return
		end

		if not ply:Alive() then
			Notify( ply, "You are dead!" )
			return
		end

		if target:InVehicle() and ply:GetMoveType() ~= MOVETYPE_NOCLIP then
			Notify( ply, "Target is in a vehicle! Noclip and use this command to force a goto." )
			return
		end

		local newpos = playerSend( ply, target, ply:GetMoveType() == MOVETYPE_NOCLIP )
		if not newpos then
			Notify( ply, "Can't find a place to put you! Noclip and use this command to force a goto." )
			return
		end

		if ply:InVehicle() then
			ply:ExitVehicle()
		end

		local newang = (target:GetPos() - newpos):Angle()

		ply:SetPos( newpos )
		ply:SetEyeAngles( newang )
		ply:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
		
		MessageToAll( string.format("%s teleported to %s", ply:Nick(), target:Nick() ) );
	else
		Notify(ply, "Target not found!")
	end
end
AddAdminCommand( "goto", accGoto, "moderator", "Teleports you to someone", "target" )

-- ReHook
local function accReHook( ply, cmd, args )
	if ply:IsModerator() then
		pcall(function() hook.Remove( "PlayerSay", "adminSay" ) end)
		addAdminHook()
		MessageToAll( string.format("%s rehooked EXAM", ply:Nick() ) );
	end
end
AddAdminCommand( "rehook", accReHook, "moderator", "Forces EXAM to rehook if something fucks up", "none" )

-- Spectate
local function accSpectate( ply, cmd, args )
	if ply:IsModerator() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		
		if not target then
			Notify(ply, "Target not found!")
			return
		end
		
		local silent = false
		if args[1] == "1" then
			silent = true
		end
		
		local pos = ply:GetPos()
		local ang = ply:GetAngles()
		local silent = args[2]
		local function unspectate( player, key )
			if ply ~= player then return end -- Not the person we want
			if not ply:IsValid() or not ply:IsConnected() then hook.Remove( "KeyPress", "exam_unspectate_" .. ply:EntIndex() ) return end -- Different person
			if key ~= IN_FORWARD and key ~= IN_BACK and key ~= IN_MOVELEFT and key ~= IN_MOVERIGHT then return end -- Not a key we're interested in

			player:Spawn() -- Get out of spectate.
			player:SetPos( pos )
			player:SetAngles( ang )
			if not silent then
				MessageToAll( string.format("%s stopped spectating %s", ply:Nick(), target:Nick() ) )
			end
			hook.Remove( "KeyPress", "exam_unspectate_" .. ply:EntIndex() )
		end
		hook.Add( "KeyPress", "exam_unspectate_" .. ply:EntIndex(), unspectate )
		
		if ply:InVehicle() then
			ply:ExitVehicle()
		end
		ply:Spectate( OBS_MODE_IN_EYE )
		ply:SpectateEntity( target )
		ply:StripWeapons() -- Otherwise they can use weapons while spectating
		if not silent then
			MessageToAll( string.format("%s began spectating %s", ply:Nick(), target:Nick() ) );
		end
	end
end
AddAdminCommand( "spectate", accSpectate, "moderator", "Lets you see someone someone else sees", "target, silent ('1') [opt]" )

-- Jon
local function accJob( ply, cmd, args )
	if ply:IsModerator() then
		local yes = nil;
		for k, v in pairs( teams ) do
			if string.lower(args[1]) == string.lower(v.name) then
				ply:StripWeapons()
				ply:SetTeam( k )
				ply:SetJob( v.name )
				TeamGiveWeapons( ply )
				yes = true
			end	
		end
		if yes then
			Notify(ply, "You are now a "..args[1])
		else
		Notify(ply, "No such job: "..args[1])
		end
	end
end
AddAdminCommand( "job", accJob, "moderator", "Change your scripted job on-the-fly", "job" )


--
-- ADMIN COMMANDS
--

-- Freeze
local function accFreeze( ply, cmd, args )
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target:Freeze( false )
			target:Freeze( true )
			MessageToAll( string.format("%s froze %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "freeze", accFreeze, "admin", "Freezes someone's movement", "target[s]" )

-- Unfreeze
local function accUnfreeze( ply, cmd, args )
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target:Freeze( false )
			MessageToAll( string.format("%s unfroze %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "unfreeze", accUnfreeze, "admin", "Allows a frozen person to move again", "target[s]" )

-- Whip
local function WhipIgniteDeath( ply, wep, killer )
	if ply.Whip then
		ply.Whip = nil;
	end
	if ply.Ignited then
		ply:Extinguish() 
		ply.Ignited = nil;
	end
end
hook.Add( "PlayerDeath", "WhipIgniteDeathCancel", WhipIgniteDeath )

local function DoWhip( target, times, delay, damage, power )
	SlapTarget( target, damage, power )
	if times > 0 then
		if target.Whip then
			timer.Simple(delay, DoWhip, target, times - 1, delay, damage, power)
		end
	else
		target.Whip = nil;
	end
end

local function accWhip( ply, cmd, args )
	local times = tonumber(args[2]) or 10
	local delay = args[3] or 1
	local damage = args[4] or 5
	local power = args[5] or 500
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target.Whip = true;
			timer.Simple(delay, DoWhip, target, times, delay, damage, power)
			MessageToAll( string.format("%s whipped %s %s times for %s damage", ply:Nick(), target:Nick(), times, damage ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "whip", accWhip, "admin", "Slaps someone multiple times", "target[s], times [opt], delay [opt], damage [opt], power [opt]" )

-- Ignite
local function UnIgnite( target )
	if target.Ignited then
		target.Ignited = nil;
		target:Extinguish()
	end
end

local function accIgnite( ply, cmd, args )
	local time = args[2] or 10;
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target.Ignited = true;
			timer.Simple(time, UnIgnite, target)
			target:Ignite(time,0)
			MessageToAll( string.format("%s ignited %s for %s seconds", ply:Nick(), target:Nick(), time ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "ignite", accIgnite, "admin", "Sets someone on fire!", "target[s], duration" )

local function accUnIgnite( ply, cmd, args )
	local time = args[2] or 10;
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			if target.Ignited then
				target:Extinguish()
				target.Ignited = nil;
			end
			MessageToAll( string.format("%s unignited %s", ply:Nick(), target:Nick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "unignite", accUnIgnite, "admin", "Extinguishes someone on fire", "target[s]" )

-- Send
local function accSend( ply, cmd, args )	
	if not ply:IsAdmin() then return end
	if FindPlayers( args[1] ) > 1 then Notify( ply, "Multiple target1's found!" ) return end
	local target = FindPlayer( args[1] )
	if FindPlayers( args[2] ) > 1 then Notify( ply, "Multiple target2's found!" ) return end
	local sendto = FindPlayer( args[2] )
	if target and sendto then
		if sendto == target then
			Notify( ply, "Error: Time paradox!" )
			return
		end

		if not target:Alive() then
			Notify( ply, "Target isn't alive!" )
			return
		end

		local newpos = playerSend( target, sendto, target:GetMoveType() == MOVETYPE_NOCLIP )
		if not newpos then
			Notify( ply, "Can't find a place to send target!" )
			return
		end

		if target:InVehicle() then
			target:ExitVehicle()
		end

		if sendto:InVehicle() then
			sendto:ExitVehicle()
		end

		local newang = (sendto:GetPos() - newpos):Angle()

		target:SetPos( newpos )
		target:SetEyeAngles( newang )
		target:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
		
		MessageToAll( string.format("%s sent %s to %s", ply:Nick(), target:Nick(), sendto:Nick() ) );
	else
		Notify(ply, "Targets not found, or no targets given!")
	end
end
AddAdminCommand( "send", accSend, "admin", "Teleports the first target to the second target", "target1, target2" )

-- Rcon
local function accRcon( ply, cmd, args )
	if ply:IsAdmin() then
		if not args[1] then
			Notify(ply, "No command inputted!")
			return
		end
		game.ConsoleCommand(args[1].."\n")
		MessageToAll( string.format("%s ran rcon command: %s", ply:Nick(), args[1] ) );
	end
end
AddAdminCommand( "rcon", accRcon, "admin", "Executes a command in the server's console", "command" )

-- Force UnOwn
local function accForceUnOwn( ply, cmd, args )
	if ply:IsAdmin() then
		local trace = ply:GetEyeTrace()
		if( trace.Entity:IsValid() and trace.Entity:IsOwnable() and ply:GetPos():Distance( trace.Entity:GetPos() ) < 110 ) then
		
			for k, v in pairs( player.GetAll() ) do
				if trace.Entity:IsOwner( v ) then
					v:AddMoney(20)
					v:RemoveOwner( v )
					Notify( v, ply:Nick().." has forced you to unown your door!" );
				end
			end			
			
			Notify( ply, "You have forced everyone to unown this door." );
			MessageToAll( string.format("%s force-unowned a door", ply:Nick() ) );
		else
			Notify( ply, "You aren't aiming at a door!" );
		end
	end
end
AddAdminCommand( "forceunown", accForceUnOwn, "admin", "Forces everyone to unown a door", "none" )

-- ForceSpawn
local function accForceSpawn( ply, cmd, args )
	if ply:IsAdmin() then
		local target = FindPlayer( args[1] )
		if target then
			target:Spawn()
			MessageToAll( string.format("%s forced %s to spawn", ply:Nick(), target:Nick() ) );
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "forcespawn", accForceSpawn, "admin", "Forces someone to (re)spawn", "target" )

-- Ressurect
local function accRessurect( ply, cmd, args )
	if ply:IsAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			if target:Alive() then Notify( ply, "Target is already alive!" ) else
				target.respawned = true;
				local oldpos = target:GetPos()
				target:Spawn()
				if target.deathrag and target.deathrag:IsValid() then
					target:SetPos(target.deathrag:GetPos())
					target.deathrag:Remove()
				else
					target:SetPos(oldpos)
				end
				
				target:EmitSound("weapons/stunstick/alyx_stunner2.wav", 75, 100)
				MessageToAll( string.format("%s ressurected %s", ply:Nick(), target:Nick() ) );
			end
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "rez", accRessurect, "admin", "Ressurects someone (respawns them at their location)", "target" )

-- TP
local function accTP( ply, cmd, args )
	if ply:IsAdmin() then
		if not ply:Alive() then return end
		
		local t = {}
		t.start = ply:GetPos() + Vector( 0, 0, 32 ) -- Move them up a bit so they can travel across the ground
		t.endpos = ply:GetPos() + ply:EyeAngles():Forward() * 16384
		t.filter = ply
		local tr = util.TraceEntity( t, ply )

		local pos = tr.HitPos

		if pos:Distance( ply:GetPos() ) < 64 then
			return
		end

		if ply:InVehicle() then
			ply:ExitVehicle()
		end

		ply:SetPos( pos )
		ply:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
	end
end
AddAdminCommand( "tp", accTP, "admin", "Teleports you to where you're looking", "none" )

local function accRagdolls( ply, cmd, args )
	if ply:IsAdmin() then
		game.ConsoleCommand( "g_ragdoll_maxcount 0\n" )
		timer.Simple(1, game.ConsoleCommand, "g_ragdoll_maxcount 8\n")
		MessageToAll( string.format("%s cleared all NPC ragdolls", ply:Nick() ) );
	end
end
AddAdminCommand( "ragdolls", accRagdolls, "admin", "Clears all NPC ragdolls", "none" )

-- Demote
local function accDemote( ply, cmd, args )
	if ply:IsAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			for k, v in pairs( teams ) do
				if k == target:Team() then
					Notify( target, "An admin has demoted you from your job as a "..v.name.."." )
				end	
			end
			target:StripWeapons()
			target:SetTeam( 1 )
			target:SetJob( "None" )
			target.OverrideModel = nil;
			target:SetModel( target.CharModel )
			TeamGiveWeapons( target )
			MessageToAll( string.format("%s demoted %s", ply:Nick(), target:Nick() ) );
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "demote", accDemote, "admin", "Demote's someone back to citizen", "target" )

-- SetJob
local function accSetJob( ply, cmd, args )
	if ply:IsModerator() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			local yes = nil;
			for k, v in pairs( teams ) do
				if string.lower(args[2]) == string.lower(v.name) then
					target:StripWeapons()
					target:SetTeam( k )
					target:SetJob( v.name )
					TeamGiveWeapons( target )
					yes = true;
				end	
			end
			if yes then
				Notify(target, "An admin has made you a "..args[2])
				MessageToAll( string.format("%s changed %s's job", ply:Nick(), target:Nick() ) );
			else
				Notify(ply, "No such job: "..args[2])
			end
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "setjob", accSetJob, "moderator", "Change someone's scripted job on-the-fly", "job" )

local function accGrant( ply, cmd, args )
	if ply:IsAdmin() then
		if not args[1] then
			ply:PrintMessage( HUD_PRINTTALK, "You're missing an argument!" )
		end
		local arg = tonumber( args[1] )
		
		local res = unstickList[arg]
		if res then
			res:SetVelocity((res:GetAimVector() * 250) + (res:GetUp() * 300))
			table.remove( unstickList, arg )
			ply:PrintMessage( HUD_PRINTTALK, "Player "..res:Nick().." has been unstuck." )
			res:PrintMessage( HUD_PRINTTALK, "An admin has approved your unstick." )
		else
			ply:PrintMessage( HUD_PRINTTALK, "There is no unstick needed by that ID." )
		end
	end
end
AddAdminCommand( "grant", accGrant, "admin", "Grant someone to use unstick", "grant id" )


--
-- SUPERADMIN COMMANDS
--

-- Cexec
local function accCexec( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not args[2] then
			Notify(ply, "No command inputted!")
			return
		end
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			target:ConCommand(args[2].."\n")
			MessageToAll( string.format("%s ran %s on %s", ply:Nick(), args[2], target:GetNick() ) );
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "cexec", accCexec, "superadmin", "Executes a command in a client's console", "target[s], command" )

-- Reboot
local function accReboot( ply, cmd, args )
	if ply:IsSuperAdmin() then
		for k, v in pairs( player.GetAll() ) do
			game.ConsoleCommand( "kickid " .. v:UserID() .. " \"Server rebooting--come back soon!\"\n" )
		end
		MessageToAll( string.format("%s rebooted the server", ply:Nick() ) );
		game.ConsoleCommand("quit\n")
	end
end
AddAdminCommand( "reboot", accReboot, "superadmin", "Reboots the server", "none" )

-- Change HP
local function accChangeHP( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			if args[2] then
				target:SetHealth(math.Round(args[2]))
				MessageToAll( string.format("%s set %s's HP to %i", ply:Nick(), target:Nick(), math.Round(args[2]) ) );
				return
			end
			Notify(ply, target:Nick().." has $"..target:GetMoney())
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "hp", accChangeHP, "superadmin", "Sets a target's HP", "target, hp" )

-- Debug
local function accDebug( ply, cmd, args )
	if ply:IsSuperAdmin() then
		function getEntityWidthLengthHeight(ent)
			local lower = ent:OBBMins()
			local upper = ent:OBBMaxs()
			local offset = upper - lower
			return offset
		end 

		local trace = ply:GetEyeTrace()
		ply:PrintMessage(HUD_PRINTCONSOLE, "Self Index: "..tostring(ply:EntIndex()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "EntIndex is: "..tostring(trace.Entity:EntIndex()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "Class is: "..tostring(trace.Entity:GetClass()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "Model is: "..tostring(trace.Entity:GetModel()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "Parent is: "..tostring(trace.Entity:GetParent()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "Owner is: "..tostring(trace.Entity:GetOwner()))
		ply:PrintMessage(HUD_PRINTCONSOLE, "AABB Vector is: "..tostring(getEntityWidthLengthHeight(trace.Entity)))
		ply:PrintMessage(HUD_PRINTCONSOLE, "Mattype is: "..tostring(trace.MatType))
		
		for k, v in pairs( player.GetAll() ) do
			for l, b in pairs( v:GetWeapons() ) do
				ply:PrintMessage( HUD_PRINTCONSOLE, v:Nick() .. " wep: " .. b:GetClass() .. " \n" )
			end
			if v.Inventory then
				for l, b in pairs( v.Inventory ) do
					ply:PrintMessage( HUD_PRINTCONSOLE, v:Nick() .. " inv: " .. b .. " \n" )
				end
			end
		end
		
		ply:PrintMessage(HUD_PRINTTALK, "GetAll() W/I Cache debug in console.")
	end
end
AddAdminCommand( "debug", accDebug, "superadmin", "Gives you trace debug info", "none" )

-- ParentToSelf
local function accParentToSelf( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not ply.CurParents then
			ply.CurParents = { }
		end
		local trace = ply:GetEyeTrace();
		if ( trace.HitWorld ) then 
			trace.Entity:SetParent();
			for k, v in pairs ( ply.CurParents ) do
				ply.CurParents[k] = nil
				v:Remove()
			end
			return;
		end 
		trace.Entity:SetParent(ply);
		ply.CurParents[CurTime()] = trace.Entity;
	end
end
AddAdminCommand( "parenttoself", accParentToSelf, "superadmin", "Parents an object to you. Aim at the world to unparent all", "none" )

-- SetFirstParent
local function accSetFirstParent( ply, cmd, args )
	if ply:IsSuperAdmin() then
		local trace = ply:GetEyeTrace();
		if ( trace.HitWorld ) then 
			ply.FirstParent = nil;
		end 
		ply.FirstParent = trace.Entity;
	end
end
AddAdminCommand( "setfirstparent", accSetFirstParent, "superadmin", "Sets the first object to parent to with settwoparents", "none" )

-- SetSecondParent
local function accSetSecondParent( ply, cmd, args )
	if ply:IsSuperAdmin() then
		local trace = ply:GetEyeTrace();
		if ( trace.HitWorld ) then 
			ply.SecondParent = nil;
		end 
		ply.SecondParent = trace.Entity;
	end
end
AddAdminCommand( "setsecondparent", accSetSecondParent, "superadmin", "Sets the second object to parent to with settwoparents", "none" )
	
-- SetTwoParents
local function accSetTwoParents( ply, cmd, args )
	if ply:IsSuperAdmin() then
		local trace = ply:GetEyeTrace();
		if ( trace.HitWorld ) then 
			ply.FirstParent:SetParent();
			return;
		end 
		ply.FirstParent:SetParent(ply.SecondParent);
	end
end
AddAdminCommand( "settwoparents", accSetTwoParents, "superadmin", "Parents the first object to the second object", "none" )
	
-- SetSelfParent
local function accSetSelfParent( ply, cmd, args )
	if ply:IsSuperAdmin() then
		local trace = ply:GetEyeTrace();
		if ( trace.HitWorld ) then 
			ply:SetParent();
			return;
		end 
		ply:SetParent(trace.Entity);
	end
end
AddAdminCommand( "setselfparent", accSetSelfParent, "superadmin", "Parents you to what you're looking at. Aim at world to unparent", "none" )

-- SpawnEffect
local function accSpawnEffect( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not args[1] then
			Notify(ply, "Effect not found!")
			return
		end
		local trace = ply:GetEyeTrace()
		local vPoint = trace.HitPos
		local effectdata = EffectData()
		effectdata:SetStart( vPoint )
		effectdata:SetOrigin( vPoint )
		effectdata:SetScale( 1 )
		util.Effect( args[1], effectdata ) 
	end
end
AddAdminCommand( "spawneffect", accSpawnEffect, "superadmin", "Spawns an effect where you're looking", "effect" )

-- ForceSpeak
local function accForceSpeak( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			target:ConCommand("say "..args[2])
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "forcespeak", accForceSpeak, "superadmin", "Forces someone to say something without an echo", "target, text" )

-- ForceRate
local function accForceRate( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			local rating = args[2];
			for k, v in pairs( player.GetAll() ) do
				v:ConCommand("rateuser "..target:EntIndex().." "..rating)
			end
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "forcerate", accForceRate, "superadmin", "Forces everyone to rate someone something", "target, rating" )

-- Smite
local function accSmite( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			local effectdata = EffectData()
			effectdata:SetOrigin( target:GetPos() )
			effectdata:SetStart( target:GetPos() + Vector(0,0,1000) )
			
			util.Effect( "cball_explode", effectdata )
			util.Effect( "ManhackSparks", effectdata )
			util.Effect( "ToolTracer", effectdata )
			util.Effect( "Explosion", effectdata )
			
			target:EmitSound("npc/vort/attack_shoot.wav")
			target:Kill()
			
			MessageToAll( string.format("%s smited %s", ply:Nick(), target:Nick() ) );
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "smite", accSmite, "superadmin", "Slay with style", "target" )

-- StripNonDef
local function accStripNonDef( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			for k, v in pairs( target.Weapons ) do
				if not IsDefaultWeapon(v) then
					table.remove(target.Weapons, k)
				end
			end
			target:StripWeapons()
			target.respawned = true;
			local pos = target:GetPos()
			target:Spawn()
			target:SetPos(pos)
			MessageToAll( string.format("%s stripped %s of all non-default weapons", ply:Nick(), target:Nick() ) );
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "stripnondef", accStripNonDef, "superadmin", "Strip all the non-default weapons from a player", "target" )

-- StripWeapons
local function accStripWeapons( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			target:StripWeapons()
			MessageToAll( string.format("%s temporarily stripped %s of all weapons", ply:Nick(), target:Nick() ) );
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "stripweapons", accStripWeapons, "superadmin", "Temporarily strips all weapons from a target", "target" )

-- SetModel
local function accSetModel( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not args[1] then
			Notify(ply,"No model given!")
			return
		end
		ply.CharModel = args[1];
		ply:SetModel(args[1]);
	end
end
AddAdminCommand( "setmodel", accSetModel, "superadmin", "Sets your model to something", "model" )

-- Ghost
local function accGhost( ply, cmd, args )
	if ply:IsSuperAdmin() or ply.AllowGhost then
		GhostCommand(ply, false)
	end
end
AddAdminCommand( "ghost", accGhost, "superadmin", "There's a ghost? Where?!", "none" )

-- Arrest
local function accArrest( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			target:Arrest()
			target:SelectWeapon( "weapon_unarmed" )
			target:ConCommand("-speed")
			Notify(ply, target:Nick().." has been arrested.")
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "arrest", accArrest, "superadmin", "Arrests someone", "target" )

-- UnArrest
local function accUnArrest( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] )
		if target then
			target:Unarrest()
			target:SelectWeapon( "weapon_unarmed" )
			Notify(ply, target:Nick().." has been unarrested.")
		end
		if not target then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "unarrest", accUnArrest, "superadmin", "UnArrests someone", "target" )

-- Flash
local function flashSpawnCheck( ply )
	if ply.Flash then
		ply.Flash = false
	end
end
hook.Add( "PlayerSpawn", "flashSpawnCheck", flashSpawnCheck )

local function accFlash( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if ply.Flash then
			GAMEMODE:SetPlayerSpeed( ply, WALKSPEED_NORMAL, WALKSPEED_RUN )
			ply.Flash = false
			Notify(ply, "Flash off.")
		else
			local speed = tonumber(args[1]) or 2000
			GAMEMODE:SetPlayerSpeed( ply, speed, speed )
			Notify(ply, "Flash on.")
			ply.Flash = true
		end
	end
end
AddAdminCommand( "flash", accFlash, "superadmin", "Makes you run really really fast", "speed [opt]" )

-- God
local function godSpawnCheck( ply )
	if ply.Godded then
		ply.Godded = false
		ply:GodDisable()
	end
end
hook.Add( "PlayerSpawn", "godSpawnCheck", godSpawnCheck )

local function accGod( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			ply:GodEnable()
			MessageToAll( string.format("%s godded %s", ply:Nick(), target:Nick() ) );
			ply.Godded = true
		else
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "god", accGod, "superadmin", "Make someone invincible", "target" )

-- UnGod
local function accUnGod( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			ply:GodDisable()
			MessageToAll( string.format("%s ungodded %s", ply:Nick(), target:Nick() ) );
			ply.Godded = false
		else
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "ungod", accUnGod, "superadmin", "Make someone mortal again", "target" )

-- Earthquake
local earthquake = false
local function accEarthquake( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if earthquake then return end
		
		local shake = ents.Create("env_shake")
		shake:SetKeyValue("amplitude", 200)
		shake:SetKeyValue("duration", 30)
		shake:SetKeyValue("radius", 60000)
		shake:SetKeyValue("frequency", 230)
		shake:SetPos(ply:GetPos())
		shake:Spawn()
		shake:Fire("StartShake","","0")
		shake:Fire("Kill","",30)
		
		earthquake = true
		
		local function RidQuake()
			earthquake = false
		end
		timer.Simple(30, RidQuake)
	end
end
AddAdminCommand( "earthquake", accEarthquake, "superadmin", "Create an earthquake for 30 seconds!", "none" )

-- Give
local function accGive( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target and args[2] then
			target:Give(args[2])
			MessageToAll( string.format("%s gave %s an %s", ply:Nick(), target:Nick(), args[2] ) );
		else
			Notify(ply, "Target or weapon not found!")
		end
	end
end
AddAdminCommand( "give", accGive, "superadmin", "Give someone a weapon", "target, weapon" )

-- SpEnt
local function accSpEnt( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not args[1] then Notify(ply, "Entity not found!") return end
		
		local vStart = ply:GetShootPos()
		local vForward = ply:GetAimVector()

		local trace = {}
		trace.start = vStart
		trace.endpos = vStart + (vForward * 100)
		trace.filter = ply

		local tr = util.TraceLine( trace )

		local ang = ply:EyeAngles()
		ang.yaw = ang.yaw + 180 // Rotate it 180 degrees in my favour
		ang.roll = 0
		ang.pitch = 0

		local function makeflush( ent, tr )
			local vFlushPoint = tr.HitPos - ( tr.HitNormal * 512 )	// Find a point that is definitely out of the object in the direction of the floor
			vFlushPoint = ent:NearestPoint( vFlushPoint )			// Find the nearest point inside the object to that point
			vFlushPoint = ent:GetPos() - vFlushPoint				// Get the difference
			vFlushPoint = tr.HitPos + vFlushPoint					// Add it to our target pos
			
			ent:SetPos(vFlushPoint + Vector(0,0,10))
		end
		
		local npc = ents.Create(args[1])
		npc:SetPos(tr.HitPos)
		npc:Spawn()
		makeflush( npc, tr )
	end
end
AddAdminCommand( "spent", accSpEnt, "superadmin", "Spawn an entity where you're looking", "entity" )

local function accRocket( ply, cmd, args ) 
	if ply:IsSuperAdmin() then
		if table.getn(FindPlayers( args[1] )) > 1 then Notify( ply, "Multiple targets found!" ) return end
		local target = FindPlayer( args[1] );
		if target then
			target:SetVelocity(Vector(0, 0, 2048))

			timer.Simple(3, function()
			local Position = target:GetPos()

			local Effect = EffectData()

			Effect:SetOrigin(Position)
			Effect:SetStart(Position)
			Effect:SetMagnitude(512)
			Effect:SetScale(128)

			util.Effect("Explosion", Effect)
			target:Kill()
			end)
			MessageToAll( string.format("%s turned %s into a rocket", ply:Nick(), target:Nick() ) );
		else
			Notify(ply, "Target or weapon not found!")
		end
	end
end
AddAdminCommand( "rocket", accRocket, "superadmin", "Turn someone into an exploding rocket", "target" )

local function accShoo( ply, cmd, args ) 
	if ply:IsSuperAdmin() then
		local targets = FindPlayers( args[1] )
		for k, target in pairs( targets ) do
			if target != ply then
				target:SetVelocity(((target:GetPos()-ply:GetPos()) * 2048) + Vector( 0, 0, 2048 ))
				MessageToAll( string.format("%s shooed %s away", ply:Nick(), target:Nick() ) );
			end
		end
		if #targets < 1 then
			Notify(ply, "Target not found!")
		end
	end
end
AddAdminCommand( "shoo", accShoo, "superadmin", "Shoo fly, don't bother me", "target[s]" )

local function accSpEff( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not args[1] then Notify(ply, "Entity not found!") return end
		
		local vStart = ply:GetShootPos()
		local vForward = ply:GetAimVector()

		local trace = {}
		trace.start = vStart
		trace.endpos = vStart + (vForward * 100)
		trace.filter = ply

		local tr = util.TraceLine( trace )

		local vPoint = tr.HitPos 
		local effectdata = EffectData() 
		effectdata:SetStart( vPoint )
		effectdata:SetOrigin( vPoint ) 
		effectdata:SetScale( 1 ) 
		util.Effect( args[1], effectdata )  
	end
end
AddAdminCommand( "speff", accSpEff, "superadmin", "Spawn an effect where you're looking", "effect" )

local function toggleAxisMove( ply, mv ) 
	if ply.toggleAxis then
		ply:SetEyeAngles( Angle( 0, ply:GetAngles().y, ply:GetAngles().r ) )
		mv:SetVelocity( Vector( mv:GetVelocity().x, mv:GetVelocity().y, 0 ) )
	end
end 
hook.Add("Move", "toggleAxisMove", toggleAxisMove) 

local function accToggleAxis( ply, cmd, args )
	if ply:IsSuperAdmin() then
		if not ply.toggleAxis then
			ply.toggleAxis = true
			ply:SetMoveType( MOVETYPE_NOCLIP )
		else
			ply.toggleAxis = false
			ply:SetMoveType( MOVETYPE_WALK )
		end
	end
end
AddAdminCommand( "axis", accToggleAxis, "superadmin", "Toggle axis-walking liek Davveh Jonez'a", "none" )


--
-- VOTING COMMANDS
--
local exam_votemaps = {}
local function initVotemap()
	local maps = file.Find( "../maps/*.bsp" )
	for _, map in ipairs( maps ) do
		map = map:sub( 1, -5 ) -- Take off .bsp
		if string.find(string.lower(map), "rp_") or string.find(string.lower(map), "gm_") then
			if string.lower(map) ~= "gm_construct" and string.lower(map) ~= "gm_flatgrass" then
				table.insert( exam_votemaps, string.lower(map) )
			end
		end
	end
end
initVotemap()
table.sort( exam_votemaps )

local function accVotemap( ply, cmd, args )
	if not args[1] then
		Notify(ply, "You didn't input a map name! Say !maplist for a list of maps.")
		return
	end
	local map = string.lower(args[1])
	if not map or map == "" then
		Notify(ply, "You didn't input a map name! Say !maplist for a list of maps.")
		return
	end
	
	if not table.HasValue(exam_votemaps, map) then
		Notify(ply, "Map doesn't exist! Say !maplist for a list of maps.")
		return
	end
	
	if vote_currentVeto then
		Notify(ply, "A vote has already won, and is now awaiting approval.")
		return
	end
	
	if CurTime() < vote_minTime * 60 then
		local timeleft = (vote_minTime*60 - CurTime()) / 60
		Notify(ply, "You must wait "..math.Round(timeleft).." more minutes to vote.")
		return
	end
	
	if ply.lastVoteTime then
		if CurTime() - ply.lastVoteTime < vote_waitTime * 60 then
			local timeleft = (vote_waitTime*60 - (CurTime() - ply.lastVoteTime)) / 60
			Notify(ply, "You must wait "..math.Round(timeleft).." more minutes before changing your vote.")
			return
		end
	end
	
	if ply.lastVoteMap then
		mapVotes[ ply.lastVoteMap ] = mapVotes[ ply.lastVoteMap ] - 1;
	end
	
	ply.lastVoteTime = CurTime()
	ply.lastVoteMap = map;
	if not mapVotes[ map ] then
		mapVotes[ map ] = 0;
	end
	mapVotes[ map ] = mapVotes[ map ] + 1;
	
	local votesNeeded = math.ceil( math.max( vote_minVotes, vote_voteRadio * #player.GetAll() ) )
	
	MessageToAll( string.format("%s voted for %s (%i/%i) Say !votemap %s to vote for this map too.", ply:Nick(), map, mapVotes[ map ], votesNeeded, map ) );
	
	if mapVotes[ map ] >= votesNeeded then		
		local admins = {};
		for k, v in pairs( player.GetAll() ) do
			if v:IsModerator() then
				table.insert(admins, v)
			end
		end
		
		if #admins < 1 then
			MessageToAll( "Vote for map " .. map .. " successful! Changing level now." )
			timer.Simple(vote_changeTime, game.ConsoleCommand, "changelevel " .. map .. "\n" )
		else
			local function checkVeto()
				MessageToAll( "Vote for map " .. map .. " successful! Changing level now." )
				timer.Simple(vote_changeTime, game.ConsoleCommand, "changelevel " .. map .. "\n" )
			end
			vote_currentVeto = true;
			timer.Create( "Votemap", vote_vetoTime, 1, checkVeto )
			MessageToAll( "Vote for " .. map .. " successful! Now pending staff approval. (" .. vote_vetoTime .. " seconds)" )
			for k, v in ipairs( admins ) do
				Notify( v, "To veto this vote, just say '!veto'" )
			end
		end
	end
end
AddAdminCommand( "votemap", accVotemap, "public", "Votes to change the map", "map name" )

local function mapvoteDisconnect( ply )
	if ply.lastVoteMap then
		mapVotes[ ply.lastVoteMap ] = mapVotes[ ply.lastVoteMap ] - 1;
	end
end
hook.Add( "PlayerDisconnected", "VotemapDisconnect", mapvoteDisconnect )

local function accMapList( ply, cmd, args )
	ply:PrintMessage( HUD_PRINTCONSOLE, "Map list:\n" );
	for k, v in pairs( exam_votemaps ) do
		ply:PrintMessage( HUD_PRINTCONSOLE, " o "..v );
	end
	ply:PrintMessage( HUD_PRINTCONSOLE, "\nEnd of map list." );
	ply:PrintMessage( HUD_PRINTTALK, "Check your console for the map list!" );
end
AddAdminCommand( "maplist", accMapList, "public", "Shows a list of all valid, votable maps", "none" )

local function accVeto( ply, cmd, args )
	if ply:IsModerator() then
		timer.Destroy( "Votemap" )
		vote_currentVeto = false;
		MessageToAll( string.format("%s vetoed the map vote", ply:Nick() ) );
	end
end
AddAdminCommand( "veto", accVeto, "moderator", "Vetoes the current map vote", "none" )