ex_protection_config = { 
"func_breakable",
"func_breakable_surf",
"func_brush",
"func_button",
"func_door",
"func_door_rotating",
"func_healthcharger",
"func_lookdoor",
"func_monitor",
"func_movelinear",
"func_platrot",
"func_recharge",
"func_rot_button",
"func_rotating",
"func_tank",
"func_tankairboatgun",
"func_tankapcrocket",
"func_tanklaser",
"func_tankmortar",
"func_tankphyscannister",
"func_tankpulselaser",
"func_tankrocket",
"func_tanktrain",
"func_trackautochange",
"func_trackchange",
"func_tracktrain",
"func_wall",
"func_wall_toggle",
"func_water_analog",
"func_clip_vphysics",
"func_conveyor",
"func_vehicleclip",
"func_lod",
"func_ladder",
"prop_dynamic",
"prop_door_rotating",
"prop_dynamic_override",
"prop_thumper",
"prop_coreball",
"prop_vehicle_crane",
"item_healthcharger",
"item_suitcharger"
}

if !ConVarExists( "ex_protection" ) then
	CreateConVar( "ex_protection", "1" )
end
if !ConVarExists( "ex_adminprotection" ) then
	CreateConVar( "ex_adminprotection", "1" )
end

function exp_PhysgunPickup( ply, ent )
	if GetConVarNumber( "ex_protection" ) == 1 then
		if GetConVarNumber( "ex_adminprotection" ) == 1 then
		    for K, V in pairs(ex_protection_config) do
				if (string.lower(ent:GetClass()) == string.lower(V)) then
					return false
				end
			end
		else
			if !ply:IsAdmin() then
				for K, V in pairs(ex_protection_config) do
					if (string.lower(ent:GetClass()) == string.lower(V)) then
						return false
					end
				end
			end
		end
	end   
end
hook.Add("PhysgunPickup","exp_PhysgunPickup",exp_PhysgunPickup)
 
function exp_CanTool(ply,tr,mode)
	if not ply:IsModerator()
		and mode == "adv_duplicator"
		and tr.Hit
		and tr.Entity
		and tr.Entity:IsValid() then
			if tr.Entity:IsWeapon() or tr.Entity:GetClass() == "sent_tnt" then
				Notify( ply, "I can't let you duplicate that, Dave." )
				return false
			end
	end		
		
	if GetConVarNumber( "ex_protection" ) == 1 then
		if GetConVarNumber( "ex_adminprotection" ) == 1 then
		    for K, V in pairs(ex_protection_config) do
				if (string.lower(tr.Entity:GetClass()) == string.lower(V)) then
					return false
				end
			end
		else
			if !ply:IsAdmin() then
				for K, V in pairs(ex_protection_config) do
					if (string.lower(tr.Entity:GetClass()) == string.lower(V)) then
						return false
					end
				end
			end
		end
	end 
end
hook.Add("CanTool","exp_CanTool",exp_CanTool) 