resource.AddFile("sound/misc/freeze_cam.wav")
local dist = 75

local function FastMeleeRetract( ply, oldGun )
	ply:SelectWeapon( oldGun )
end

local function FastMeleeFix( ply)
	ply:ConCommand( "-attack" )
end

local function FastMeleePhysics( ply, tr )
	if tr.Entity and tr.Entity:IsValid() and tr.Entity:GetPhysicsObject():IsValid() and tr.HitPos:Distance( ply:EyePos() ) < dist then
		tr.Entity:GetPhysicsObject():ApplyForceCenter (ply:GetAimVector():GetNormalized() * math.pow (200, 3))
	end
end

local function FastMeleeStart( ply, tr )
	local oldGun = ply:GetActiveWeapon():GetClass()
	if tr.HitPos:Distance( ply:EyePos() ) < dist then
		if tr.Hit and tr.Entity and tr.Entity:IsValid() and tr.Entity:Health() then
			tr.Entity:SetHealth( 1 )
		end
		if tr.Entity:GetClass() ~= "func_breakable" then
			for k, v in pairs( ents.FindInSphere( tr.Entity:GetPos(), 30 ) ) do
				if v:GetClass() == "func_breakable" then
					v:Fire("break", 0)
				end
			end
		end
	end
	ply:SelectWeapon( "weapon_crowbar" )
	ply:ConCommand( "+attack" )
	timer.Simple(0.1, FastMeleePhysics, ply, tr)
	timer.Simple(0.4, FastMeleeFix, ply)
	timer.Simple(0.5, FastMeleeRetract, ply, oldGun)
end

local function FastMelee( ply, cmd, args )
	if ply.LastMelee and ply.LastMelee > CurTime() then return end
	ply.LastMelee = CurTime() + 1
	local tr = ply:GetEyeTrace()		
	if tr.Hit and tr.Entity and tr.Entity:IsValid() and (tr.Entity:Health() or tr.Entity:GetPhysicsObject():IsValid()) and tr.Entity:GetClass() ~= "func_breakable" and tr.HitPos:Distance( ply:EyePos() ) < dist then
		ply:EmitSound( "misc/freeze_cam.wav", 500, 100 )
	end
	timer.Simple(0.1, FastMeleeStart, ply, tr)
end
concommand.Add("fastmelee", FastMelee)