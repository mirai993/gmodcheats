
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include('shared.lua')

function ENT:Initialize()

	self.Entity:SetModel( "models/props_lab/reciever01d.mdl" )
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	local phys = self.Entity:GetPhysicsObject()
	if(phys:IsValid()) then phys:Wake() end
	
	self.LastUse = 0
	
end


function ENT:Use( activator, caller )

	if ( !activator:IsPlayer() ) then return end
	if self.LastUse > CurTime() then return end

	local command = string.Replace( self.Command, "%name%", activator:Nick() )
	
	if self.UseOnSpawner == 1 then
		if self.Spawner:IsValid() then
			self.Spawner:ConCommand( command )
		end
	else
		activator:ConCommand( command )
	end
	
	self.LastUse = CurTime() + 0.5
	
end


function ENT:Think()

end

