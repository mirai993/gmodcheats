
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

--[[if !ConVarExists( "ex_knifekill" ) then
	CreateConVar( "ex_knifekill", "1" )
end]]--

function ENT:Initialize()
	self.Entity:SetModel( "models/weapons/w_knife_t.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	local phys = self.Entity:GetPhysicsObject()
	if(phys:IsValid()) then phys:Wake() end
	--self.Thrown = 0
end

function ENT:PhysicsCollide( data, phys ) 
	ent = data.HitEntity
	if ent:GetClass()=="thrownknife" or ent==self.Thrower or self.Thrown==1 then return; end
	phys:EnableMotion( false )
	if ent:IsValid() then
		self.Entity:SetParent(ent)
		phys:EnableMotion( true )
	end
	
	--[[if GetConVarNumber( "ex_knifekill" ) == 1 then
		if ent:IsValid() then
			self.Entity:SetParent(ent)
			ent:SetHealth(ent:Health() - 50)
			if ent:Health() < 1 then
				ent:GetTable().Slayed = true
				ent:Kill()
			end
		end
	end]]--
	
	if ent:IsPlayer() or ent:IsNPC() then
		self.Entity:Remove()
	end
	
	--self.Thrown = 1
end

function ENT:Think()
end

