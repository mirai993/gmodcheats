ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Thrown Knife"
ENT.Author = "Doug Tyrrell"
ENT.Spawnable = false
ENT.AdminSpawnable = true
