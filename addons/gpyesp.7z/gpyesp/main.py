import struct
import sys
import win32gui
import win32con
from pymem import Pymem
from pymem.process import module_from_name
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPainter, QPen
import math
 
 
pm = Pymem('gmod.exe')
client_dll = module_from_name(pm.process_handle, 'client.dll').lpBaseOfDll
engine_dll = module_from_name(pm.process_handle, 'engine.dll').lpBaseOfDll
 
# Offsets
VIEW_MATRIX_BASE_OFFSET = 0x00741F08
VIEW_MATRIX_FINAL_OFFSET = 0x2D4
ENTITY_LIST_OFFSET = 0x00917658
ENTITY_HEALTH_OFFSET = 0x00C8
X_COORD_OFFSET = 0x0308
Y_COORD_OFFSET = 0x030C
Z_COORD_OFFSET = 0x0310
LOCAL_PLAYER_OFFSET = 0x008F5920
 
local_player_index = None
 
def world_to_screen(x, y, z, view_matrix, screen_width, screen_height):
    """I hate everything about this and I wish I never had to do it. I dislike maths"""
    clip_x = x * view_matrix[0] + y * view_matrix[1] + z * view_matrix[2] + view_matrix[3]
    clip_y = x * view_matrix[4] + y * view_matrix[5] + z * view_matrix[6] + view_matrix[7]
    clip_w = x * view_matrix[12] + y * view_matrix[13] + z * view_matrix[14] + view_matrix[15]
 
    if clip_w < 0.1:
        return None, None, False
 
    screen_x = (screen_width / 2) * (clip_x / clip_w) + (screen_width / 2)
    screen_y = -(screen_height / 2) * (clip_y / clip_w) + (screen_height / 2)
    return int(screen_x), int(screen_y), True
 
def get_gmod_window_rect():
    """I do know you can get the window a lot better, but this is fine here for now xoxo"""
    hwnd = win32gui.FindWindow(None, "Garry's Mod (x64)")
    if hwnd:
        rect = win32gui.GetWindowRect(hwnd)
        return rect[0], rect[1], rect[2] - rect[0], rect[3] - rect[1]
    return None
 
def read_view_matrix():
    try:
        base_pointer_address = engine_dll + VIEW_MATRIX_BASE_OFFSET
        base_address = pm.read_ulonglong(base_pointer_address)
        view_matrix_address = base_address + VIEW_MATRIX_FINAL_OFFSET
        view_matrix_bytes = pm.read_bytes(view_matrix_address, 64)
        view_matrix = struct.unpack('16f', view_matrix_bytes)
        return view_matrix
    except Exception as e:
        print(f"Error reading view matrix: {e}")
        return None
 
class ESPOverlay(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
 
        hwnd = self.winId()
        win32gui.SetWindowLong(hwnd, win32con.GWL_EXSTYLE,
                               win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
                               | win32con.WS_EX_LAYERED | win32con.WS_EX_TRANSPARENT)
 
        #self.screen_width, self.screen_height = 1920, 1080  # Uncomment this if any issues
        self.last_rect = None
 
        # Timer to update overlay size and position (if your gmod window moves)
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_overlay_position)
        self.update_timer.start(10) # If you set this to 0 it could cause your pc to become slow (lower values dont always mean better)
 
        # Timer for ESP refresh
        self.esp_timer = QTimer()
        self.esp_timer.timeout.connect(self.update)
        self.esp_timer.start(10) # If you set this to 0 it could cause your pc to become slow (lower values dont always mean better)
 
    def update_overlay_position(self):
        rect = get_gmod_window_rect()
        if rect and rect != self.last_rect:
            self.setGeometry(rect[0], rect[1], rect[2], rect[3])
            self.screen_width, self.screen_height = rect[2], rect[3]
            self.last_rect = rect
 
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
 
        view_matrix = read_view_matrix()
        if not view_matrix:
            return
 
        entities = get_entities_data()
 
        for entity in entities:
            if entity['is_local_player']: # Ignores the local player, dont wana render yourself (or maybe you do idk)
                continue
 
            x, y, z = entity['coordinates']
            screen_x, screen_y, visible = world_to_screen(x, y, z, view_matrix, self.screen_width, self.screen_height)
            if visible:
                painter.setPen(QPen(Qt.red, 4))
                painter.drawEllipse(screen_x - 2, screen_y - 2, 4, 4)
 
 
 
def get_entities_data():
    global local_player_index
 
    entity_list_base = get_pointer_address(client_dll + ENTITY_LIST_OFFSET)
    if not entity_list_base:
        print("Entity list base address not found.")
        return []
 
    entities_data = []
    try:
        local_x, local_y, local_z = get_local_player_coordinates()
    except:
        pass
 
    for i in range(128):  # just set to 128 for testing
        entity_base = get_entity_base(entity_list_base, i)
        if entity_base:
            try:
                health = pm.read_int(entity_base + ENTITY_HEALTH_OFFSET)
                if health > 0:
                    x = pm.read_float(entity_base + X_COORD_OFFSET)
                    y = pm.read_float(entity_base + Y_COORD_OFFSET)
                    z = pm.read_float(entity_base + Z_COORD_OFFSET)
 
                    is_local_player = (local_x == x and local_y == y and local_z == z)
                    distance = calculate_distance(local_x, local_y, local_z, x, y, z)
 
                    entity_data = {
                        "index": i,
                        "coordinates": (x, y, z),
                        "distance": distance,
                        "is_local_player": is_local_player,
                        "name": f"Player {i}"
                    }
                    entities_data.append(entity_data)
            except:
                pass
    return entities_data
 
 
 
def get_pointer_address(base, offsets=None):
    if offsets is None or len(offsets) == 0:
        return base
    remote_pointer = base
    for offset in offsets:
        remote_pointer = pm.read_ulonglong(remote_pointer + offset)
    return remote_pointer
 
def get_entity_base(entity_list_base, index):
    entity_address = entity_list_base + index * 0x20
    return pm.read_ulonglong(entity_address)
 
def get_local_player_coordinates():
    local_player_base = pm.read_ulonglong(client_dll + LOCAL_PLAYER_OFFSET)
    x = pm.read_float(local_player_base + X_COORD_OFFSET)
    y = pm.read_float(local_player_base + Y_COORD_OFFSET)
    z = pm.read_float(local_player_base + Z_COORD_OFFSET)
    return x, y, z
 
def calculate_distance(x1, y1, z1, x2, y2, z2):
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2 + (z2 - z1) ** 2)
 
def main():
    app = QApplication(sys.argv)
    overlay = ESPOverlay()
    overlay.show()
    sys.exit(app.exec_())
 
if __name__ == "__main__":
    main()