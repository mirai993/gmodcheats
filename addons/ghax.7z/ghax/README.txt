1) Create a file in your "C:\" drive and name it "gHax.lua"
2) Place you lua hack in there. You need to make sure the hack is on 1 line.
      Eg. "require('notification') print('MrRoxiys Lua File Loads First...')"
            Ps. Make sure you have "require('notification')" at the start.
3) Inject the DLL into your game in the menu.
4) Go into a game. You will see that your hack starts first. Using this method you can bypass all anti-cheats and you don't even need to set your "sv_allowcslua" to 1!

Credits: Roxi.