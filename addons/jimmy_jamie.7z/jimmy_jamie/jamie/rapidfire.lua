--[[
	MOD/lua/jimmy/jamie/rapidfire.lua [#1401 (#1401), 580320962, UID:840370373]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:36PM]
	===BadFile===
]]

--[[
jamies Scripts by jamie. (STEAM_0:0:30422103)
Rapidfire script recycled from jamie's triggerbot by Ott (STEAM_0:0:36527860)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Rapidfire loaded")

CreateClientConVar("jamie_rapidfire", 0)

local toggler = 0

local function rapidfire(cmd)
	if LocalPlayer():KeyDown(IN_ATTACK) && !Jamie.PANIC then
		if LocalPlayer():Alive() then
			if IsValid(LocalPlayer():GetActiveWeapon()) then
				if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					if toggler == 0 then
						cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
						toggler = 1
					else
						cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
						toggler = 0
					end
				end
			end
		end
	end
end


-- prepping
hook.Remove("CreateMove", "rapidfire")

if GetConVarNumber("jamie_rapidfire") == 1 then
	hook.Add("CreateMove", "rapidfire", triggerbot)
end
--end of prep

cvars.AddChangeCallback("jamie_rapidfire", function() 
	if GetConVarNumber("jamie_rapidfire") == 1 then
		hook.Add("CreateMove", "rapidfire", rapidfire)
	else
		hook.Remove("CreateMove", "rapidfire")
	end
end)