--[[
	MOD/lua/jimmy/jamie/norecoil.lua [#889 (#889), 253262646, UID:3244773513]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:35PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Norecoil loaded")

CreateClientConVar("jamie_norecoil", 1)


local function norecoil()
	if LocalPlayer():GetActiveWeapon():Clip1() > 0 && !Jamie.PANIC then
		if LocalPlayer():GetActiveWeapon().Recoil then
			LocalPlayer():GetActiveWeapon().Recoil = 0
		end
		if LocalPlayer():GetActiveWeapon().Primary.Recoil && !Jamie.PANIC then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end



-- prepping
hook.Remove("PlayerSwitchWeapon", "norecoil")

if GetConVarNumber("jamie_norecoil") == 1 then
	hook.Add("PlayerSwitchWeapon", "norecoil", norecoil)
end
--end of prep

cvars.AddChangeCallback("jamie_norecoil", function() 
	if GetConVarNumber("jamie_norecoil") == 1 then
		hook.Add("PlayerSwitchWeapon", "norecoil", norecoil)
	else
		hook.Remove("PlayerSwitchWeapon", "norecoil")
	end
end)