--[[
	MOD/lua/jimmy/jamie/debug.lua [#246 (#256), 759355110, UID:2421655945]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:31PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Debug loaded")

local function DebugHolding()
	PrintTable(LocalPlayer():GetActiveWeapon():GetTable())
end

concommand.Add("jamie_debug_holding", DebugHolding)