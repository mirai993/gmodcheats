--[[
	MOD/lua/jimmy/jamie/hud.lua [#711 (#711), 2455837706, UID:3888678984]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:34PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy HUD loaded")

CreateClientConVar("jamie_hud", 1)

local w, h = ScrW(), ScrH()


local function hud()
	if !Jamie.PANIC then
	draw.SimpleText("Speed: "..math.Round(LocalPlayer():GetVelocity():Length()), "Default", w*.5, 0, Jamie.Colors.iceblue, 1) 
end
end


--prepping
hook.Remove("HUDPaint", "jamiehud")
timer.Simple(1, function()
if GetConVarNumber("jamie_hud") == 1 then
	hook.Add("HUDPaint", "jamiehud", hud)
end
end)
-- end of prep


cvars.AddChangeCallback("jamie_hud", function() 
	if GetConVarNumber("jamie_hud") == 1 then
		hook.Add("HUDPaint", "jamiehud", hud)
	else
		hook.Remove("HUDPaint", "jamiehud")
	end
end)