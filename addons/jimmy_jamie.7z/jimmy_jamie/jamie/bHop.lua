--[[
	MOD/lua/jimmy/jamie/bHop.lua [#866 (#866), 2861859899, UID:498614266]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:30PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]
Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Bunny Hop loaded")

CreateClientConVar("jamie_bhop", 0)


local function bhopper( cmd )
	if cmd:KeyDown(IN_JUMP) and LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP and LocalPlayer():WaterLevel() < 2 then
		local buttonsetter = cmd:GetButtons()
		if !LocalPlayer():IsOnGround() then
			buttonsetter = bit.band(buttonsetter, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttonsetter)
	end
end


-- preperation
hook.Remove("CreateMove", "bunnyhop")
timer.Simple(1, function()
if GetConVarNumber("jamie_bhop") == 1 then
	hook.Add("CreateMove", "bunnyhop", bhopper)
end
end)
-- end of prep


cvars.AddChangeCallback("jamie_bhop", function() 
	if GetConVarNumber("jamie_bhop") == 1 then
		hook.Add("CreateMove", "bunnyhop", bhopper)
	else
		hook.Remove("CreateMove", "bunnyhop")
	end
end)