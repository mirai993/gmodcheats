--[[
	MOD/lua/jimmy/jamie/events.lua [#705 (#705), 2587000912, UID:1318840285]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:32PM]
	===BadFile===
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Events loaded")

timer.Create( "JimmyChecks", 1, 0,
	function() JimmyCheck() end
)

function JimmyCheck()
    for k, v in pairs(player.GetAll()) do
        if (v:IsAdmin() and not table.HasValue(Jamie.Admins, v)) then
            table.insert(Jamie.Admins, v);
            Jamie.Utils.Notify(true,Jamie.Colors.white,"Warning: Admin " .. v:Nick() .. " (" ..v:SteamID().. ") has joined!")
        end
        if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
            Jamie.Utils.Notify(true,Jamie.Colors.red,"Warning: "..v:Nick().." is now spectating you!")
        end
    end
end