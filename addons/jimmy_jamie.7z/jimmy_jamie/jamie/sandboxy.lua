--[[
	MOD/lua/jimmy/jamie/sandboxy.lua [#183 (#183), 3841342237, UID:1629099308]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:37PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

-- This is the file where I try stuff out. (Such as badly documented functions, etc...)


MsgC(Color(0,255,0), "\nJamie's Sandbox initialized!\n")