--[[
	MOD/lua/jimmy/jamie/triggerbot.lua [#1129 (#1129), 1903001337, UID:4088039215]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:38PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Triggerbot loaded")

CreateClientConVar("jamie_triggerbot", 0)

local toggler = 0

local function triggerbot(cmd)
	if LocalPlayer():Alive() then
		local target = LocalPlayer():GetEyeTrace().Entity
		if target:IsValid() && !Jamie.PANIC then
			if IsValid(LocalPlayer():GetActiveWeapon()) then
				if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					if target:IsPlayer() or target:IsNPC() then
						if toggler == 0 then
							cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
							toggler = 1
						else
							cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
							toggler = 0
						end
					end	
				end
			end
		end
	end
end


-- prepping
hook.Remove("CreateMove", "triggerbot")

if GetConVarNumber("jamie_triggerbot") == 1 then
	hook.Add("CreateMove", "triggerbot", triggerbot)
end
--end of prep

cvars.AddChangeCallback("jamie_triggerbot", function() 
	if GetConVarNumber("jamie_triggerbot") == 1 then
		hook.Add("CreateMove", "triggerbot", triggerbot)
	else
		hook.Remove("CreateMove", "triggerbot")
	end
end)