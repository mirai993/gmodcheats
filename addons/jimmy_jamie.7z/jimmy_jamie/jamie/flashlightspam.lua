--[[
	MOD/lua/jimmy/jamie/flashlightspam.lua [#681 (#681), 303936513, UID:2217955193]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:33PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]
Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Flashlight Spammer loaded")

CreateClientConVar("jamie_flashlightspam", 0)


local function flashspammer(cmd)
	if  input.IsKeyDown(KEY_F) && !Jamie.PANIC then
		cmd:SetImpulse(100)
	end
 end

-- preperation
hook.Remove("CreateMove", "flashspam")

if GetConVarNumber("jamie_flashlightspam") == 1 then
	hook.Add("CreateMove", "flashspam", flashspammer)
end
-- end of prep


cvars.AddChangeCallback("jamie_flashlightspam", function() 
	if GetConVarNumber("jamie_flashlightspam") == 1 then
		hook.Add("CreateMove", "flashspam", flashspammer)
	else
		hook.Remove("CreateMove", "flashspam")
	end
end)