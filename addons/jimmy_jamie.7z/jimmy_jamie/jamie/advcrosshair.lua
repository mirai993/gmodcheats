--[[
	MOD/lua/jimmy/jamie/advcrosshair.lua [#1545 (#1545), 3100254750, UID:1478883235]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:29PM]
	===BadFile===
]]

--[[
Jimmy Hack - lol fuk u nerd
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Crosshair loaded")

CreateClientConVar("jamie_advcrosshair", 0)
CreateClientConVar("jamie_advcrosshair_money", 0)
local mx = ScrW()*.5 --middle x
local my = ScrH()*.5  --middle y

local function advcrosshair()
	if LocalPlayer():Health() > 0 && !Jamie.PANIC then
		local target = LocalPlayer():GetEyeTrace().Entity
		if target:IsPlayer() or target:IsNPC() then
			surface.SetDrawColor(Color(255,255,255))
			surface.DrawLine(mx-5, my+5, mx+5, my-5)
			surface.DrawLine(mx-5, my-5, mx+5, my+5)
			draw.DrawText("Health: "..target:Health(), "Default", mx, my+20, Color(255,255,0), 1)
			surface.SetDrawColor(Color(255,0,0))
		else
			if target:IsValid()  && target:GetClass() != "prop_physics" then
				draw.DrawText("Entity Name: "..tostring(target:GetClass()), "Default", mx, my+30, Color(0,255,255), 1)
			end
			surface.SetDrawColor(Color(255,255,255))
		end
	end
	if !Jamie.PANIC then
		surface.DrawLine(mx-35, my, mx-20, my)
		surface.DrawLine(mx+35, my, mx+20, my)
		surface.DrawLine(mx, my-35, mx, my-20)
		surface.DrawLine(mx, my+35, mx, my+20)
	end
end


-- prepping
hook.Remove("HUDPaint", "advcrosshair")

if GetConVarNumber("jamie_advcrosshair") == 1 then
	hook.Add("HUDPaint", "advcrosshair", advcrosshair)
end
--end of prep

cvars.AddChangeCallback("jamie_advcrosshair", function() 
	if GetConVarNumber("jamie_advcrosshair") == 1 then
		hook.Add("HUDPaint", "advcrosshair", advcrosshair)
	else
		hook.Remove("HUDPaint", "advcrosshair")
	end
end)