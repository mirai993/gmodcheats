--[[
	MOD/lua/jimmy/jamie/antiscreenshot.lua [#630 (#630), 1518390486, UID:603190232]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:29PM]
	===BadFile===
]]

Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy Anti-Screenshot loaded")

local actualRenderCapture = _G.render.Capture
local encodeData	  = util.Base64Encode;

local enabled = CreateClientConVar("jamie_antiscreenshot", "1")
local function antiscreenshot()
	if enabled:GetBool() then
		_G.render.Capture = function(data)
		Jamie.PANIC = true
		
		timer.Create( "fuckThePolice", 2, 1, function()
				local dt = actualRenderCapture(data)
				Jamie.PANIC = false
				return dt
			end)
		end

	else
		_G.render.Capture = actualRenderCapture
	end
end
antiscreenshot()
cvars.AddChangeCallback("jamie_antiscreenshot", antiscreenshot)
