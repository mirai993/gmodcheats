--[[
	MOD/lua/jimmy/jamie/nospread.lua [#1240 (#1240), 299467944, UID:830850088]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:36PM]
	===BadFile===
]]

--[[
jamies Scripts by jamie. (STEAM_0:0:30422103)
NoSpread script recycled by Ott (STEAM_0:0:36527860)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]
Jamie.Utils.Notify(false,Jamie.Colors.white,"Jimmy NoSpread loaded")

CreateClientConVar("jamie_nospread", 1)


local function nospread()
	if LocalPlayer():GetActiveWeapon():Clip1() > 0 && !Jamie.PANIC then
		if LocalPlayer():GetActiveWeapon().Cone then
			LocalPlayer():GetActiveWeapon().Cone = 0
		end
		if LocalPlayer():GetActiveWeapon().Primary.Cone && !Jamie.PANIC then
			LocalPlayer():GetActiveWeapon().Primary.Cone = 0
		end
	end
end



-- prepping
hook.Remove("PlayerSwitchWeapon", "nospread")

if GetConVarNumber("jamie_norecoil") == 1 then
	hook.Add("PlayerSwitchWeapon", "nospread", nospread)
end
--end of prep

cvars.AddChangeCallback("jamie_nospread", function() 
	if GetConVarNumber("jamie_nospread") == 1 then
		hook.Add("PlayerSwitchWeapon", "nospread", nospread)
	else
		hook.Remove("PlayerSwitchWeapon", "nospread")
	end
end)