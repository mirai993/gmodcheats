--[[
	MOD/lua/jimmy/jamie/keypad.lua [#5716 (#5716), 1411107328, UID:4264070690]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:34PM]
	===BadFile===
]]

local X = -50
local Y = -100
 
local KeyPos =  {      
        {X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
        {X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
        {X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
 
        {X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
        {X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
        {X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
 
        {X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
        {X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
        {X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
 
        {X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
        {X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}
 function fPrintSomething( player, command, arguments )
    MsgN( "Printing Something." )
end
 
concommand.Add( "PrintSomething", fPrintSomething )

concommand.Add("jamie_keypad_codes", getAllCodes)


local function getAllCodes()
for k,v in pairs(ents.GetAll()) do
	if IsValid(v) then
		if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
			if v.code != nil then
				print(v.code)
			end
		end
	end
end
end
 
local function FindDisplayText(ent)
        if ent.GetDisplayText then
                return ent:GetDisplayText()
        else
                return ent.Entity:GetNetworkedInt("keypad_num")
        end
end
 
local function FindStatus(ent)
        if ent.GetStatus then
                return ent:GetStatus()
        elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 1
        elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 2
        else
                return 0
        end
end
 
hook.Add("Think", "Somethingoranotherthatissomething", function()
        for k,v in pairs(player.GetAll()) do
                local kp = v:GetEyeTrace().Entity
                if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
                        kp.tempCode = kp.tempCode or ""
                        kp.tempText = kp.tempText or ""
                        kp.tempStatus = kp.tempStatus or 0
                       
                        if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
                                kp.tempText = FindDisplayText(kp)
                                kp.tempStatus = FindStatus(kp)
                               
                                local tr = util.TraceLine({
                                        start = v:EyePos(),
                                        endpos = v:GetAimVector() * 32 + v:EyePos(),
                                        filter = v
                                })
                               
                                local pos = kp:WorldToLocal(tr.HitPos)
                               
                                for i,p in pairs(KeyPos) do
                                        local x = (pos.y - p[5]) / (p[5] + p[6])
                                        local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
                                       
                                        if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
                                                if i == 11 then
                                                        if kp.tempStatus == 1 then
                                                                kp.code = kp.tempCode
                                                                kp.tempCode = ""
                                                        elseif kp.tempStatus == 2 then
                                                                kp.tempCode = ""
                                                        end
                                                elseif i == 10 then
                                                        kp.tempCode = ""
                                                elseif i > 0 then
                                                        kp.tempCode = kp.tempCode..i
                                                end
                                        end
                                end
                        end
                end
        end
end)
 
hook.Add( "HUDPaint", "somethingoranotherthatissomethingelse", function()
    if !Jamie.PANIC then
        local e = LocalPlayer():GetEyeTrace().Entity
        if IsValid(e) and string.find(e:GetClass(), "keypad") then
            local text = e.code or "Not Found"
            draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
        end
        
        for k,v in pairs(ents.GetAll()) do
            if IsValid(v) then
                if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
                    if v != e then
                        local pos = v:GetPos():ToScreen()
                        if IsValid(v) and v.code then
                           local text = v.code or "Not Found"
                           draw.WordBox( 8, pos.x-5, pos.y-5, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
                           draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 0, 255, 0, 150 ) )
                       else
                        draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 255, 0, 0, 150 ) )
                    end
                end
            end
        end
    end
end
end)