--[[
	MOD/lua/jimmy/jamie.lua [#1403 (#1403), 4216729144, UID:3042865745]
	Jamie | STEAM_0:0:25687098 <109.153.149.243:27005> | [20.04.14 07:14:22PM]
	===BadFile===
]]

Jamie = {}
Jamie.Colors = {}
Jamie.Utils = {}
Jamie.Admins = {}

Jamie.Colors.red     = Color(255,0,11)
Jamie.Colors.black   = Color(0,0,0,255)
Jamie.Colors.green   = Color(66,255,96)
Jamie.Colors.white   = Color(255,255,255,255)
Jamie.Colors.blue    = Color(0,0,255,255)
Jamie.Colors.cyan    = Color(0,255,255,255)
Jamie.Colors.pink    = Color(255,0,255,255)
Jamie.Colors.blue    = Color(0,0,255,255)
Jamie.Colors.grey    = Color(175,175,175)
Jamie.Colors.gold    = Color(255,228,0,255)
Jamie.Colors.lblue   = Color(155,205,248)
Jamie.Colors.lgreen  = Color(174,255,0)
Jamie.Colors.iceblue = Color(51,153,255)

Jamie.PANIC = false

function Jamie.Utils.Notify(dosound,col,msg)
    if col then
       col = col
    end
    if !Jamie.PANIC then
        chat.AddText(Jamie.Colors.iceblue, "[JHack] ",col, msg)
    else
        MsgC(Jamie.Colors.iceblue, "[JHack] ",col, msg)
    end
    if dosound then
    	surface.PlaySound("buttons/blip1.wav")
    	surface.PlaySound("buttons/blip1.wav")
    end
end

local function ReloadJimmy()
	include("jimmy/jamie.lua")
end
concommand.Add("jamie_reload", ReloadJimmy)

local files, folders = file.Find("lua/jimmy/jamie/*.lua", "GAME")
PrintTable(files)

local timebetweemloads = .1

for k, v in pairs(files) do
	timer.Simple(timebetweemloads * k, function()
		include("jimmy/jamie/" .. v)
	end)
end

Jamie.Utils.Notify(true,Jamie.Colors.white,"Jimmy Hack loaded")
