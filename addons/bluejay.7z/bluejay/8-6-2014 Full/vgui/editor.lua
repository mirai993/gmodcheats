--[[
	bluejay/vgui/editor.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PANEL = vgui.register( "BEditor", {}, "TextEntry" )

function PANEL:Init()
	self:SetPaintBorderEnabled( false )
	self:SetPaintBackgroundEnabled( false )
end

function PANEL:Paint()
	local w, h = self:GetSize()
	surface.SetDrawColor( 20, 20, 20, 255 )
	surface.DrawRect( 0, 0, w, h )
	surface.SetDrawColor( 50, 50, 50, 255 )
	surface.DrawRect( 1, 1, w-2, h-2 )
	return false
end