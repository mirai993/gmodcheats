--[[
	bluejay/vgui/menu.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PANEL = vgui.register( "BMenu", {}, "DFrame" )

function PANEL:Init()
	--self.BaseClass.Init( self )

	self:SetTitle( "Bluejay" )

	self.PropertySheet = vgui.create( "DPropertySheet", self )
	self:PerformLayout()
	self:Center()

	self:SetDeleteOnClose( false )
end

function PANEL:Clear()
	self.PropertySheet:Remove()
	self.PropertySheet = vgui.create( "DPropertySheet", self )
	self:InvalidateLayout( true )
end

function PANEL:Refresh()

end

function PANEL:PerformLayout()
	self.BaseClass.PerformLayout( self )

	self:SetSize( 640, 400 )
	self.PropertySheet:StretchToParent( 5, 25, 5, 5 )
end

function PANEL:AddTab( name, panelclass, icon, tooltip )
	--icon = nil
	local panel = vgui.create( panelclass or "BPanel", self )
	local sheet = self.PropertySheet:AddSheet( name, panel, icon, false, false, tooltip )
	return panel, sheet
end

function PANEL:Think()
	if self:IsVisible() then
		gui.EnableScreenClicker( true )
		self:SetZPos( 100 )
		if not self:HasHierarchicalFocus() then
			self:MakePopup()
		end
	end

	self.BaseClass.Think( self )
end