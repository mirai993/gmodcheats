--[[
	bluejay/vgui/slider.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PANEL = vgui.register( "BSlider", {} )

local function pcallError( f, ... )
	if not f or type( f ) ~= "function" then return end
	local r = { pcall( f, ... ) }
	local s = table.remove( r, 1 )
	if not s then error( e, 2 ) end
	return unpack( r )
end

local values = {
	{ "_min", "Min" },
	{ "_max", "Max" },
	--{ "_stepsize", "StepSize" },
	{ "_color", "Color" },
	{ "_value", "Value" },
}
for k, t in pairs( values ) do
	PANEL[ "Set" .. t[ 2 ] ] = function( self, v ) self[ t[ 1 ] ] = v end
	PANEL[ "Get" .. t[ 2 ] ] = function( self ) return self[ t[ 1 ] ] end
end

function PANEL:Init()
	self:SetMin( 0 )
	self:SetMax( 10 )
	--self:SetStepSize( 1 )
	self:SetColor( Color( 200, 200, 200, 255 ) )

	self:SetValue( 0 )

	self:SetTall( 15 )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( 0, 0, 0, 200 )
	surface.DrawRect( 0, 0, w, h )
	surface.SetDrawColor( 175, 175, 175, 255 )
	surface.DrawRect( 1, 1, w - 2, h - 2 )

	local c = self:GetColor()
	surface.SetDrawColor( c.r, c.g, c.b, c.a )

	local p = ( self:GetValue() - self:GetMin() ) / ( self:GetMax() - self:GetMin() )
	surface.DrawRect( 1, 1, ( w - 2 ) * p, h - 2 )

	local label = self:GetValue()
	surface.SetTextColor( 0, 0, 0, 200 )
	surface.SetFont( "Bluejay13" )
	local tw, th = surface.GetTextSize( label )
	surface.SetTextPos( w / 2 - tw / 2 + 1, h / 2 - th / 2 + 1 )
	surface.DrawText( label )
	surface.SetTextColor( 255, 255, 255, 255 )
	surface.SetTextPos( w / 2 - tw / 2, h / 2 - th / 2 )
	surface.DrawText( label )
end

function PANEL:OnMousePressed( mc )
	if mc == MOUSE_LEFT then
		self:MouseCapture( true )
		self._mouseDown = true
	end
end

function PANEL:OnMouseReleased( mc )
	if mc == MOUSE_LEFT then
		self:MouseCapture( false )
		if not self._mouseDown then return end
		self._mouseDown = nil
	end
end

function PANEL:OnCursorMoved( x, y )
	if not self._mouseDown then return end
	x = math.min( math.max( x, 0 ), self:GetWide() )
	p = x / self:GetWide()
	self:SetValue( math.floor( self:GetMin() + p * ( self:GetMax() - self:GetMin() ) ) )
	pcallError( self.OnSetValue, self, self:GetValue() )
end