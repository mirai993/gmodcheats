--[[
	bluejay/vgui/panel.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PANEL = vgui.register( "BPanel", {}, "DPanel" )

--[[local texBackground = surface.GetTextureID( "bluejay/gui/background" )
local texGradient = surface.GetTextureID( "gui/gradient" )
local deg2rad = math.pi / 180
local defaultRes = 5

local vertCache = {}

local function getUV( x, y )
	return x / 128, y / 128
end

local function addVert( t, x, y )
	local u, v = getUV( x, y )
	table.insert( t, { x = x, y = y, u = u, v = v } )
end

local function generateCornerVerts( t, radius, x, y, startDeg, endDeg, resDeg )
	local t = t or {}
	local startRad = startDeg * deg2rad
	local endRad = ( endDeg - resDeg ) * deg2rad
	local resRad = resDeg * deg2rad
	for i = startRad, endRad, resRad do
		addVert( t, x, y )
		addVert( t, x + math.cos( i ) * radius, y + math.sin( i ) * radius )
		addVert( t, x + math.cos( i + resRad ) * radius, y + math.sin( i + resRad ) * radius )
	end
	return t
end

local function generateVerts( radius, res )
	local t = { tl = {}, bl = {}, br = {}, tr = {} }

	generateCornerVerts( t.tl, radius, radius, radius, 180, 270, res or defaultRes )
	generateCornerVerts( t.bl, radius, radius, 0, 90, 180, res or defaultRes )
	generateCornerVerts( t.br, radius, 0, 0, 0, 90, res or defaultRes )
	generateCornerVerts( t.tr, radius, 0, radius, 270, 360, res or defaultRes )

	return t
end

function PANEL:PaintExpensiveBackground( radius, tl, bl, br, tr )
	local x, y = self:LocalToScreen( 0, 0 )
	local w, h = self:GetWide(), self:GetTall()
	vertCache[ radius ] = vertCache[ radius ] or generateVerts( radius )

	local verts = vertCache[ radius ]

	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.SetTexture( texBackground )

	surface.DrawTexturedRectUV( radius, 0, w - radius * 2, h, 128, 128 )
	surface.DrawTexturedRectUV( 0, radius, w, h - radius * 2, 128, 128 )

	local vw, vh = ScrW(), ScrH()

	if tl then
		render.SetViewPort( x, y, radius * 2, radius * 2 )
		cam.Start2D()
			surface.DrawPoly( verts.tl )
		cam.End2D()
		render.SetViewPort( 0, 0, vw, vh )
	else
		surface.DrawTexturedRectUV( 0, 0, radius, radius, 128, 128 )
	end

	if bl then
		render.SetViewPort( x, y + h - radius, radius * 2, radius * 2 )
		cam.Start2D()
			surface.DrawPoly( verts.bl )
		cam.End2D()
		render.SetViewPort( 0, 0, vw, vh )
	else
		surface.DrawTexturedRectUV( 0, h - radius, radius, radius, 128, 128 )
	end

	if br then
		render.SetViewPort( x + w - radius, y + h - radius, radius * 2, radius * 2 )
		cam.Start2D()
			surface.DrawPoly( verts.br )
		cam.End2D()
		render.SetViewPort( 0, 0, vw, vh )
	else
		surface.DrawTexturedRectUV( w - radius, h - radius, radius, radius, 128, 128 )
	end

	if tr then
		render.SetViewPort( x + w - radius, y, radius * 2, radius * 2 )
		cam.Start2D()
			surface.DrawPoly( verts.tr )
		cam.End2D()
		render.SetViewPort( 0, 0, vw, vh )
	else
		surface.DrawTexturedRectUV( w - radius, 0, radius, radius, 128, 128 )
	end
end

local dshadowsize = 16
function PANEL:PaintShadow( ox, oy, t, b, l, r, shadowsize )
	shadowsize = shadowsize or dshadowsize
	local x, y = self:LocalToScreen( 0, 0 )
	local w, h = self:GetSize()
	local vw, vh = ScrW(), ScrH()
	render.SetViewPort( x - shadowsize, y - shadowsize, w + shadowsize * 2, h + shadowsize * 2 )
	cam.Start2D()

		surface.SetDrawColor( 0, 0, 0, 50 )
		surface.SetTexture( texGradient )
		if t then
			surface.DrawTexturedRectRotated( w / 2 + shadowsize, shadowsize / 2, shadowsize, w - ox, 90 )
		end
		if b then
			surface.DrawTexturedRectRotated( w / 2 + shadowsize, h + shadowsize * 1.5, shadowsize, w - ox, 270 )
		end
		if l then
			surface.DrawTexturedRectRotated( shadowsize / 2, oy / 2 + h / 2 + shadowsize, shadowsize, h - oy, 180 )
		end
		if r then
			surface.DrawTexturedRectRotated( w + shadowsize * 1.5, oy / 2 + h / 2 + shadowsize, shadowsize, h - oy, 0 )
		end

	cam.End2D()
	render.SetViewPort( 0, 0, vw, vh )
end

function PANEL:PaintBackground()
	--self:PaintExpensiveBackground( 0, false, false, false, false )
	local x, y = self:LocalToScreen( 0, 0 )
	local w, h = self:GetSize()
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.SetTexture( texBackground )

	surface.DrawTexturedRectUV( 0, 0, w, h, 0, 0, w / 128, h / 128 )
end

function PANEL:Paint()
	surface.SetDrawColor( 26, 26, 26, 175 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end]]