--[[
	bluejay/vgui/panellist.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PANEL = vgui.register( "BPanelList", {}, "DPanelList" )

function PANEL:Init()
	self.BaseClass.Init( self )
	self:SetSpacing( 5 )
	self:SetPadding( 5 )
	self:EnableHorizontal( false )
	self:EnableVerticalScrollbar( false )
end

function PANEL:Paint()
	--[[draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 125, 125, 125, 150 ) )
	draw.RoundedBox( 4, 1, 1, self:GetWide() - 2, self:GetTall() - 2, Color( 50, 50, 50, 255 ) )]]
	draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 255, 255, 255, 150 ) )
	return true
end

function PANEL:MultiChoice( plugin, config )

	local choice = vgui.create( "DComboBox", self )

	if plugin and config then
		local set = false

		function choice.OnSelect( _, index, value, data )
			set = true
			plugin.config[ config ] = data or value
		end

		local original_addchoice = choice.AddChoice
		function choice.AddChoice( _, value, data, select )

			local index = original_addchoice( choice, value, data, select )

			local config_value = plugin.config[ config ]

			if not set and ( value == config_value or data == config_value ) or select then
				choice:ChooseOptionID( index )
			end

			return index

		end
	end

	self:AddItem( choice )

	return choice
	
end

function PANEL:Category( label )
	local cat = vgui.create( "DCollapsibleCategory", self )

	if not cat then return end

	cat:SetExpanded( false )
	cat:SetLabel( label )

	cat.Panel = vgui.create( "BPanelList", cat )
	cat:SetContents( cat.Panel )

	self:AddItem( cat )
	return cat.Panel
end

function PANEL:Button( label, callback )
	local btn = vgui.create( "DButton", self )

	if not btn then return end

	btn:SetText( label )
	btn.DoClick = callback
	self:AddItem( btn )
	return btn
end

function PANEL:CheckBox( label, plugin, config )
	local box = vgui.create( "DCheckBoxLabel", self )

	if not box then return end

	box:SetText( label )
	box:SetTextColor( Color( 50, 50, 50, 255 ) )
	if plugin and config then
		box:SetValue( plugin.config[ config ] or false )
		box.OnChange = function( _, b )
			plugin.config[ config ] = b
		end
	end
	self:AddItem( box )
	return box
end

function PANEL:ControlBox( name, plugin, config )
	local key = vgui.create( "BControlBox", self )

	if not key then return end

	key:SetName( name )

	if plugin and config then
		key:SetKey( plugin.config[ config ] or { 0, 0 } )
		key.OnSetKey = function( _, t )
			plugin.config[ config ] = t
		end
	end
	
	self:AddItem( key )
	return key
end

function PANEL:Label( text )
	local label = vgui.create( "DLabel", self )

	if not label then return end

	label:SetTextColor( Color( 50, 50, 50, 255 ) )

	label:SetText( text )
	self:AddItem( label )
	return label
end

function PANEL:Spacer()
	local spacer = vgui.create( "BSpacer", self )

	if not spacer then return end

	self:AddItem( spacer )
	return spacer
end

function PANEL:Slider( min, max, plugin, config )
	local slider = vgui.create( "BSlider", self )

	if not slider then return end

	if plugin and config then
		slider:SetValue( plugin.config[ config ] or min )
		slider.OnSetValue = function( _, value )
			plugin.config[ config ] = value
		end
	end
	slider:SetMin( min )
	slider:SetMax( max )
	self:AddItem( slider )
	return slider
end