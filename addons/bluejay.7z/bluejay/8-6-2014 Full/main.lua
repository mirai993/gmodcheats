--[[
	bluejay/main.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

luaerror = luaerror or _G.error

include "bluejay/core/util.lua"

import "setfenv"
import "getfenv"

import "type"
import "print"
import "pcall"
import "table"
import "pairs"
import "ipairs"
import "unpack"
import "tostring"
import "tonumber"

import "rawset"
import "rawget"

import "file"
import "render"
import "surface"

import "debug"
import "jit"

import "gui"

import "RunConsoleCommand"
import "AddConsoleCommand"

include "bluejay/core/log.lua"
include "bluejay/core/include.lua"
include "bluejay/core/detour.lua"
include "bluejay/core/hook.lua"
include "bluejay/core/safe.lua"

include "bluejay/core/config.lua"

include "bluejay/core/convar.lua"
include "bluejay/core/command.lua"
include "bluejay/reload.lua"

include "bluejay/core/vgui.lua"

include "bluejay/core/controlhooks.lua"

include "bluejay/core/plugins.lua"

include "bluejay/core/menu.lua"


--[[command.add( "bluejay_run", function( cmd, args, argstring )

	local func = compile( argstring )
	if not func then return end

	local s, e = pcall( func )
	if not s then
		error( e )
	end

end )]]

--[[import "CurTime"
import "surface"
hook.add( "PostRender", "error", function()

	if not last_error or CurTime() - last_error >= 6 then
		return
	end

	local p = 1 - math.max( 0, math.min( 2, CurTime() - last_error - 4 ) ) / 2

	cam.Start2D()
		surface.SetFont( "Bluejay20" )
		local tw, th = surface.GetTextSize( "Bluejay Error!" )

		surface.SetAlphaMultiplier( p )
		
		surface.SetDrawColor( 0, 0, 0, 255)
		surface.DrawRect( 19, 19, tw + 8, th + 8 )
		surface.SetDrawColor( 200, 80, 20, 255)
		surface.DrawRect( 20, 20, tw + 6, th + 6 )

		surface.SetTextPos( 23, 23 )
		surface.SetTextColor( 255, 255, 255, 255 )
		surface.DrawText( "Bluejay Error!" )

		surface.SetAlphaMultiplier( 1 )
	cam.End2D()

end )

import "SysTime"
local last_refresh = CurTime()
hook.add( "Think", "refresh", function()

	if not last_refresh or CurTime() - last_refresh >= 60 then
		
		last_refresh = CurTime()

		local before = SysTime()
		refreshobjectpaths()
		local impact = SysTime() - before

		impact = math.ceil( impact * 1000 )

		if impact > 50 then
			debugprint( "Warning! Refreshing object paths took " .. impact .. "ms!" )
		end

	end

end )]]