--[[
	bluejay/test.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local jpeg = render.Capture( {
	x = 0,
	y = 0,
	w = ScrW(),
	h = ScrH(),
	format = "jpeg",
	quality = 100
} )

local f = file.Open( "jpeg_bluejay.txt", "wb", "DATA" )
f:Write( jpeg )
f:Close()

local jpeg = _G.render.Capture( {
	x = 0,
	y = 0,
	w = ScrW(),
	h = ScrH(),
	format = "jpeg",
	quality = 100
} )

local f = file.Open( "jpeg_global.txt", "wb", "DATA" )
f:Write( jpeg )
f:Close()

--[[local ignore = false
debug.sethook( function( reason, ... )
	if ignore then
		return
	end

	ignore = true
		print( reason, ... )
	ignore = false
end, "crl" )

debug.sethook()]]

--[[local search = _G.hook.Call

local i = 1

debug.sethook( function( event, line )
	i = i + 1
	if i > 200 then
		debug.sethook()
		return
	end

	--local upvalues = getupvalues( 2 )

	--for k, data in pairs( upvalues ) do
		--if data.value == search then
			--print( data.name, data.value )
		--end
	--end

	local info = debug.getinfo( 2 )
	if info then
		--print( info )
	end

	local locals = getlocals( 2 )

	for k, data in pairs( locals ) do
		if data.value == search then
			--print( data.name, data.value )
			--print( info )
		end
	end

	print( "ASD", getfenv( 2 ) == bluejay )

	--printtable( locals, 1 )
	--print( event, line )
end, "l" )

debug.sethook()]]

--[[local COMPLETE = false

local i = 1
debug.sethook( function( event, line )

	i = i + 1
	if i > 1000000 then
		debug.sethook()
		return
	end

	local info = debug.getinfo( 2 )
	if not info then return end
	if info.source ~= "@lua/includes/ac.lua" then
		return
	end

	for key, data in pairs( getupvalues( 2 ) ) do
		if data.value == _G.hook.Call then
			if data.name == "HC" and not COMPLETE then
				COMPLETE = true

				local old = data.value
				local function replacement( ... )
					return hook.overcall( old, ... )
				end

				debug.setupvalue( info.func, key, replacement )
				rawset( _G.hook, "Call", replacement )

				print( "DONE" )
			end
		end
	end



end, "l" )]]

--[[if not ORIGINALHC then
	ORIGINALHC = _G.hook.Call

	utility.setreferences( _G.hook.Call, function( ... )
		return hook.overcall( ORIGINALHC, ... )
	end )

	reload()
end]]