--[[
	bluejay/core/log.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

import "MsgC"
import "Color"
import "tostring"
import "type"
import "debug"

local function Color( r, g, b, a )
	return {
		r = r or 255,
		g = g or 255,
		b = b or 255,
		a = a or 255
	}
end

function error( err, level )

	level = tonumber( level ) or 1
	last_error = CurTime()

	err = tostring( err )
	err = err .. ( err:sub( -1 ) == "\n" and "" or "\n" )

	MsgC( Color( 255, 255, 255, 255 ), "[" )
	MsgC( Color( 15, 175, 255, 255 ), "bluejay" )
	MsgC( Color( 255, 255, 255, 255 ), "][" )
	MsgC( Color( 255, 50, 50, 255 ), "error" )
	MsgC( Color( 255, 255, 255, 255 ), "] " .. err )

	c.writeFile( "bluejay/errors.txt", ( c.readFile( "bluejay/errors.txt" ) or "" ) .. err )

	local i, info = 1, debug.getinfo( level + 1 )
	while info do
		if i >= 5 then
			MsgC( Color( 175, 175, 25, 255 ), ( "\t" ):rep( i ) .. "......\n" )
			break
		end
		MsgC( Color( 175, 175, 25, 255 ), ( "\t" ):rep( i ) .. tostring( info.namewhat ) .. "@" .. tostring( info.short_src ) .. ":" .. tostring( info.currentline ) .. "\n" )
		
		i = i + 1
		info = debug.getinfo( level + i )
	end

end

function ntostring( value )

	local t = type( value )

	if t == "table" or t == "function" then
		return t .. ": " .. utility.getobjectpath( value )
	end

	return tostring( value )

end

local tab = "\t"
function printtable( tbl, maxdepth, depth, ignore )
	depth = depth or 0
	ignore = ignore or {}

	ignore[ tbl ] = true

	Msg( "{\n" )
	for key, value in pairs( tbl ) do

		Msg( tab:rep( depth + 1 ) )
		Msg( tostring( key ) )
		Msg( " = " )

		local t = type( value )
		if t == "table" and not ignore[ value ] and ( not maxdepth or depth + 1 <= maxdepth ) then
			printtable( value, maxdepth, depth + 1, ignore )
		--[[elseif t == "function" and not ignore[ value ] then

			--ignore[ value ] = true

			Msg( "function: " )
			Msg( utility.getobjectpath( value ) )]]

			--[[local info = debug.getinfo( value )

			Msg( tostring( value ) )
			Msg( " @ " )
			Msg( tostring( info.short_src ) )]]

			--printtable( info, nil, depth + 1, ignore )
		elseif t == "string" then
			Msg( "'" .. value:gsub( "'", "\\'" ) .. "'" )
		else
			Msg( ntostring( value ) )
		end

		Msg( ",\n" )

	end

	Msg( tab:rep( depth ) .. "}" )

	if depth == 0 then
		Msg( "\n" )
	end
end

PrintTable = printtable

function print( ... )

	local n = select( "#", ... )

	if n == 1 then

		local a = select( 1, ... )
		local t = type( a )
		
		if t == "table" then
			printtable( a )
		elseif t == "function" then
			printtable( debug.getinfo( a ) )
		end

	end

	for i=1, n do
		MsgC( Color( 255, 255, 255, 255 ), ntostring( select( i, ... ) ) )
		Msg( "\t" )
	end

	Msg( "\n" )

end

function debugprint( ... )

	MsgC( Color( 255, 255, 255, 255 ), "[" )
	MsgC( Color( 15, 175, 255, 255 ), "bluejay" )
	MsgC( Color( 255, 255, 255, 255 ), "][" )
	MsgC( Color( 175, 175, 50, 255 ), "debug" )
	MsgC( Color( 255, 255, 255, 255 ), "] " )

	print( ... )

end