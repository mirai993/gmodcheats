--[[
	bluejay/core/include.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

function include( path )
	local func = c.compile( path )

	if not func then
		error( "Failed to include " .. tostring( path ) )
		return false
	end

	setfenv( func, bluejay )

	local s, e = pcall( func )
	if not s then
		error( e )
		return false
	end

	return true
end

function compile( str )
	local func = c.compileString( str )

	if not func then
		error( "Failed to compile string!" )
		return
	end

	setfenv( func, bluejay )

	return func
end