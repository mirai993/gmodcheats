--[[
	bluejay/core/vgui.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

vgui = {}

local function merge( dest, src )
	if not dest or not src then return end

	for k, v in pairs( src ) do
		if type( v ) == "table" then
			dest[ k ] = dest[ k ] or {}
			merge( dest[ k ], v )
		else
			dest[ k ] = v
		end
	end
end

local function copy( t, recur )
	recur = recur ~= nil and recur or true
	local r = {}
	for k, v in pairs( t ) do
		if recur and type( v ) == "table" then
			r[ k ] = copy( v )
		else
			r[ k ] = v
		end
	end
	return r
end

local _panels = {}

function vgui.create( class, parent, name )
	if _panels[ class ] then
		local tbl = copy( _panels[ class ], false )
		local panel = vgui.create( tbl.Base, parent, name )
		if not panel then
			error( "Failed to create panel " .. tostring( name or "un-named" ) .. ":" .. tostring( class ), 2 )
			return
		end

		merge( panel, tbl )
		panel.BaseClass = _panels[ tbl.Base ] or _G[ tbl.Base ]
		panel.ClassName = class

		if panel.Init then
			local s, e = pcall( panel.Init, panel )
			if not s then
				error( "vgui.Create: Error when calling '" .. tostring( class ) .. "':Init (" .. tostring( e ) .. ")" )
				return
			end
		end

		panel:Prepare()

		if panel.SetSkin then
			panel:SetSkin( "Default" )
		end

		return panel
	end

	local panel = _G.vgui.Create( class, parent, name )

	if panel and panel.SetSkin then
		panel:SetSkin( "Default" )
	end

	return panel
end

function vgui.get( class )
	return _panels[ class ]
end

function vgui.register( name, tbl, base )
	tbl.Base = base or "DPanel"
	_panels[ name ] = tbl

	return tbl
end

function vgui.reload()

	--_panels = {}

	for _, path in pairs( c.find( "bluejay/vgui/" ) ) do
		path = "bluejay/vgui/" .. path
		if path:sub( -4 ) == ".lua" then
			include( path )
		end
	end

end

if RELOADED then

	vgui.reload()

else

	hook.add( "Initialize", "VGUI", function()

		vgui.reload()

	end )

end