--[[
	bluejay/core/command.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

command = {}

local commands = {}

function command.exists( cmd )
	return commands[ cmd ] ~= nil
end

function command.add( cmd, func, complete )
	cmd = cmd:lower()
	commands[ cmd ] = func
	AddConsoleCommand( cmd )
end

function command.remove( cmd )
	cmd = cmd:lower()
	commands[ cmd ] = nil
end

function command.run( cmd, arguments, args )
	local cmd_func = commands[ cmd ]
	if cmd_func then
		cmd_func( cmd, arguments, args )
		return true
	end
end

hook.add( "PlayerBindPress", "hide_binds", function( ply, bind, pressed )
	if commands[ bind ] then
		return false
	end
end )

detour.onModule( "concommand", "commands", function()
	detour.func( _G, "InjectConsoleCommand", function( old, player, cmd, arguments, args )
		if not command.run( cmd, arguments, args ) then
			old( player, cmd, arguments, args )
		end
	end )
end )