--[[
	bluejay/core/convar.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

import "CreateConVar"
import "GetConVar"
import "GetConVarString"
import "ConVarExists"

import "util"

convar = {}

local detour_prefix = "_bj_"

local CRCCache = {}

local function CRC( crc )
	if CRCCache[ crc ] then return CRCCache[ crc ] end

	local ret = util.CRC( crc )
	CRCCache[ crc ] = ret
	return ret
end

local FCVAR_LOCKED = FCVAR_REPLICATED

function convar.detourConVar( todetour, unlocked )

	local oldConVar = GetConVar( todetour )

	local new_name = detour_prefix .. CRC( todetour )

	if ConVarExists( new_name ) then

		if not oldConVar then
			CreateConVar( todetour, default or 0 )
		end

		return new_name

	elseif not oldConVar then

		return

	end

	c.renameCVar( todetour, new_name )

	if not ConVarExists( todetour ) then
		debugprint( "Rename failed!" )
		CreateConVar( todetour, oldConVar:GetDefault(), unlocked and FCVAR_NONE or FCVAR_LOCKED, oldConVar:GetHelpText() )
	end

	debugprint( "Detoured " .. tostring( todetour ) .. " to " .. new_name )

	return new_name

end

function convar.releaseConVar( name )

	local oldConVar = GetConVar( todetour )

	local new_name = detour_prefix .. CRC( todetour )

	if ConVarExists( new_name ) then

		c.renameCVar( new_name, name )

	end

end

function convar.setConVar( name, value )

	local detoured_name = convar.detourConVar( name )

	if not detoured_name then return end

	RunConsoleCommand( detoured_name, value )

end

function convar.getConVar( name )

	local detoured_name = convar.detourConVar( name )

	if not detoured_name then return end

	return GetConVarString( detoured_name )

end