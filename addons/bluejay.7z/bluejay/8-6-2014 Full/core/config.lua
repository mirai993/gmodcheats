--[[
	bluejay/core/config.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

if RELOADED and config then
	config.save()
end

config = {}

config.vars = {
	[ 'core' ] = {  }
}

local function merge( dest, src )

	for k, v in pairs( src ) do
		if type( v ) == "table" then
			rawset( dest, k, dest[ k ] or {} )
			merge( dest[ k ], v )
		else
			rawset( dest, k, v )
		end
	end

end

function config.load()
	local data = "return " .. ( c.readFile( "bluejay/config.cfg" ) or "{}" )
	config.vars = config.decode( data )--merge( config.vars, config.decode( data ) )
end

function config.save()
	c.writeFile( "bluejay/config.cfg", config.encode( config.vars ) )
end

function config.decode( str )
	local f = compile( str ) or {}

	local s, e = pcall( f )
	if not s then
		error( e )
		return {}
	end

	return e
end

function config.encodeValue( val )

	local t = type( val )
	if t == "string" then
		return "'" .. val .. "'"
	end

	return tostring( val )

end

local tab = "\t"

function config.encode( tbl, depth )

	local depth = depth or 1

	local str = "{\n"

	for key, value in pairs( tbl ) do

		str = str .. tab:rep( depth ) .. "[ " .. config.encodeValue( key ) .. " ] = "

		if type( value ) == "table" then
			str = str .. config.encode( value, depth + 1 )
		else
			str = str .. config.encodeValue( value )
		end

		str = str .. ",\n"

	end

	str = str .. tab:rep( depth - 1 ) .. "}"

	return str

end

local next_save = RealTime() + 10
hook.add( "Think", "config", function()
	if RealTime() > next_save then
		config.save()
		next_save = RealTime() + 10
	end
end )

config.load()

local config_meta = {}
function config_meta:__index( k )
	return self.vars[ 'core' ][ k ]
end
function config_meta:__newindex( k, v )
	self.vars[ 'core' ][ k ] = v
end

setmetatable( config, {}, config_meta )