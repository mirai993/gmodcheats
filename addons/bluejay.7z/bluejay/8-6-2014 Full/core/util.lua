--[[
	bluejay/core/util.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

function IsValid( a )

	if not a then
		return false
	end

	if a.IsValid and not a:IsValid() then
		return false
	end

	return true

end

type = _G.type
pairs = _G.pairs

local function merge( dest, src )

	if not dest or not src then return end

	for k, v in pairs( src ) do
		if type( v ) == "table" then
			dest[ k ] = dest[ k ] or {}
			merge( dest[ k ], v )
		else
			dest[ k ] = v
		end
	end

end

local function copy( table, lookup )

	lookup = lookup or {}
	local out = {}

	lookup[ table ] = out

	for key, value in pairs( table ) do

		if type( value ) == 'table' then
			out[ key ] = lookup[ value ] or copy( value, lookup )
		else
			out[ key ] = value
		end

	end

	return out

end

--merge( _ENV, copy( _G ) )

function import( name )

	if rawget( _ENV, name ) then
		return
	end

	local data = _G[ name ]

	if type( data ) == "table" then

		_ENV[ name ] = copy( data )

	else

		_ENV[ name ] = data

	end

end



import "ipairs"
import "pcall"

function tremove( t, rk )

	if not rk then
		t[ #t ] = nil
		return
	end

	local ret

	for k, v in ipairs( t ) do
		if k == rk then
			ret = v
		elseif k > rk then
			t[ k - 1 ] = v
		end
	end

	t[ #t ] = nil

	return ret

end

function safeCall( func, ... )

	if not func then return end

	local r = { pcall( func, ... ) }
	local s = tremove( r, 1 )

	if not s then
		error( tostring( r[ 1 ] ) )
		return
	end

	return unpack( r )

end

local getinfo = debug.getinfo

function gettrace( func, start )

	start = start or 2

	func = func or getinfo
	local out, i, info = {}, start, func( start )

	while info do
		out[ i ] = info
		i = i + 1
		info = func( i )
	end

	return out

end

function getupvalues( func )

	if type( func ) == "number" then
		func = func + 1
		local info = debug.getinfo( func )
		func = info and info.func
	end

	if type( func ) ~= "function" then
		return {}
	end

	local out = {}

	local i = 1
	local name, value = debug.getupvalue( func, i )
	while name do

		out[ i ] = { name = name, value = value }

		i = i + 1
		name, value = debug.getupvalue( func, i )

	end

	return out

end

function getlocals( func )

	if type( func ) == "number" then
		func = func + 1
	end

	if not debug.getinfo( func ) then
		return
	end

	local out = {}

	local i = 1
	local name, value = debug.getlocal( func, i )
	while name do

		out[ i ] = { name = name, value = value }

		i = i + 1
		name, value = debug.getlocal( func, i )

	end

	return out

end

function getsource( info )

	if type( info ) == "number" then
		info = info + 1
	end

	if type( info ) ~= "table" then
		info = debug.getinfo( info )
	end

	if not info then
		return
	end

	local pre, path = info.short_src:match( "(.-)/(.+)" )
	if pre == "addons" then
		path = path:match( ".-/.-/(.+)" )
	end

	if not path then
		path = info.short_src
	end

	if not file.Exists( path, "LUA" ) then
		return
	end

	local f = file.Open( path, "r", "LUA" )

	if not f then
		return
	end

	local source = f:Read( f:Size() )

	f:Close()

	source = source .. "\n"

	local lines = {}
	for line in source:gmatch( "(.-)\n" ) do
		lines[ #lines + 1 ] = line
	end

	local out, outlines = "", {}

	for i = info.linedefined, info.lastlinedefined do
		outlines[ i ] = lines[ i ]
	end

	return table.concat( lines, "\n", info.linedefined, info.lastlinedefined ), outlines, info

end

function printsource( info )

	if type( info ) == "number" then
		info = info + 1
	end

	local _, lines, info = getsource( info )

	if not lines then
		MsgC( Color( 230, 230, 230, 255 ), "Failed to retrieve source.\n" )
		return
	end

	for number, line in pairs( lines ) do

		local color = Color( 230, 230, 230, 255 )
		if number == info.currentline then
			color = Color( 255, 255, 255, 255 )
		end

		MsgC( color, line .. "\n" )

	end

end

local object_paths = {}

local function getobjectpaths( tab )

	for key, value in pairs( tab ) do
		if type( value ) == "table" and not object_paths[ value ] then
			object_paths[ value ] = object_paths[ tab ] .. "." .. tostring( key )
			getobjectpaths( value )
		elseif type( value ) == "function" and not object_paths[ value ] then
			object_paths[ value ] = object_paths[ tab ] .. "." .. tostring( key )
		end
	end

end

function refreshobjectpaths()

	object_paths = {}

	object_paths[ _G ] = "_G"
	--getobjectpaths( _G )

	object_paths[ bluejay ] = "bluejay"
	--getobjectpaths( bluejay )

	local registry = debug.getregistry()
	object_paths[ registry ] = "registry"
	--getobjectpaths( registry )

end

--refreshobjectpaths()

function IsBluejay( func )
	if type( func ) == "number" then
		func = func + 1
	end

	local info = debug.getinfo( func )
	if info then
		if getfenv( func ) == bluejay then
			return true
		end

		if type( func ) == "number" then
			if info.source == "=[C]" or info.name == "__index" then
				return IsBluejay( func + 1 )
			end

			local i = 1
			local name, value = debug.getlocal( func, i )
			while name do
				if value == bluejay then
					return true
				end

				i = i + 1
				name, value = debug.getlocal( func, i )
			end
		end
	end

	return false
end

utility = {}

function utility.getrank( ply )

	if not IsValid( ply ) then
		return
	end

	if ply.GetUserGroup and ply:GetUserGroup() ~= nil and ply:GetUserGroup() ~= "user" then
		return ply:GetUserGroup()
	end

	if ply.IsSuperAdmin and ply:IsSuperAdmin() then
		return "superadmin"
	end

	if ply.IsAdmin and ply:IsAdmin() then
		return "admin"
	end

end

function utility.getobjectpath( tab )

	return object_paths[ tab ] or tostring( tab ):sub( -10 )

end

function utility.setreferences( search, set, tab )

	local current = debug.getinfo( 1 )
	local caller = debug.getinfo( 2 )

	local function runtables( tab, ignore )

		tab = tab or debug.getregistry()
		ignore = ignore or {}

		for key, value in pairs( tab ) do

			if type( key ) == "table" and not ignore[ key ] then
				ignore[ key ] = true
				runtables( key, ignore )
			end

			if type( value ) == "table" and not ignore[ value ] then
				ignore[ value ] = true
				runtables( value, ignore )
			end

			if key == search then
				rawset( tab, key, nil )
				rawset( tab, set, value )

				--debugprint( "changing key", utility.getobjectpath( tab ), key )
			end

			if value == search then
				rawset( tab, key, set )

				--debugprint( "setting value", utility.getobjectpath( tab ), key, value )
			end

			if type( key ) == "function" then
				for index, data in pairs( getupvalues( key ) ) do
					if data.value == search then
						--debugprint( "setting upvalue", utility.getobjectpath( tab ), key, data.name, data.value )
						debug.setupvalue( key, index, set )
					end
				end
			end

			if type( value ) == "function" then
				for index, data in pairs( getupvalues( value ) ) do
					if data.value == search then
						--debugprint( "setting upvalue", utility.getobjectpath( tab ), value, data.name, data.value )
						debug.setupvalue( value, index, set )
					end
				end
			end

		end

	end

	runtables( tab )

	local hookdata = { debug.gethook() }
	local i = 1
	debug.sethook( function()
		i = i + 1
		if i > 100000 then
			debug.sethook( unpack( hookdata ) )
			return
		end

		local info = debug.getinfo( 2 )
		if not info then return end

		if info.source == caller.source or info.source == current.source then
			i = i - 1
			return
		end

		local locals = getlocals( 2 )
		for index, data in pairs( locals ) do
			if data.name ~= "(*temporary)" and data.value == search then
				i = 0
				print( "L", data.name, data.value )
				print( info )
				debug.setlocal( 2, index, set )
			end
		end

		local locals = getupvalues( 2 )
		for index, data in pairs( locals ) do
			if data.value == search then
				i = 0
				print( "U", data.name, data.value )
				print( info )
				debug.setupvalue( info.func, index, set )
			end
		end
	end, "l" )

end

for i=8, 26 do
	surface.CreateFont( "Bluejay" .. i, {
		font = "Trebuchet",
		size = i,
		antialias = true,
		weight = 500
	} )
end