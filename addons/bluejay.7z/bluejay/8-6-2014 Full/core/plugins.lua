--[[
	bluejay/core/plugins.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

plugins = {}

local _plugins = {}

function plugins.reload()

	for name, plugin in pairs( _plugins ) do
		safeCall( plugin.PluginShutdown, plugin )

		_plugins[ name ] = nil
	end

	config.save()

	for _, path in pairs( c.find( "bluejay/plugins/" ) ) do
		path = "bluejay/plugins/" .. path
		if path:sub( -4 ) == ".lua" then
			include( path )
		end
	end

	menu.reload()

	for name, plugin in pairs( _plugins ) do
		if plugin.config.enabled then
			safeCall( plugin.PluginStartup, plugin )
		end
	end

end

function plugins.callHook( name, ... )

	for _, plugin in pairs( _plugins ) do
		if plugin.config.enabled then
			local r = { safeCall( plugin[ name ], ... ) }
			if #r > 0 then
				return unpack( r )
			end
		end
	end

end

function plugins.register( name )

	local pluginvar_meta = {}
	function pluginvar_meta:__index( k )
		if not config.vars[ name ] then return end
		return config.vars[ name ][ k ]
	end
	function pluginvar_meta:__newindex( k, v )
		config.vars[ name ] = config.vars[ name ] or {}
		config.vars[ name ][ k ] = v
	end

	_plugins[ name ] = {  }
	_plugins[ name ].name = name
	_plugins[ name ].config = {  }

	setmetatable( _plugins[ name ].config, pluginvar_meta )

	if _plugins[ name ].config.enabled == nil then
		_plugins[ name ].config.enabled = true
	end

	return _plugins[ name ]

end

function plugins.get( name )

	return _plugins[ name ]

end

function plugins.getList()

	return _plugins

end

if RELOADED then

	plugins.reload()

else

	hook.add( "Initialize", "Plugins", function()

		plugins.reload()

	end )

end