--[[
	bluejay/core/menu.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

menu = {}

local menu_panel

function menu.create()

	if menu_panel then
		menu_panel:Remove()
		menu_panel = nil
	end

	menu_panel = vgui.create( "BMenu" )
	menu.addPluginTab()

	function menu_panel:OnClose()
		menu.pinned = not menu.pinned
		if not menu.pinned then
			menu.close()
		else
			self:MakePopup()
		end
	end

end

function menu.addPluginTab()

	local plugin_panel, sheet = menu_panel:AddTab( "Plugins", "BPanel", "gui/silkicons/plugin.png" )

	plugin_panel.reload = vgui.create( "DButton", plugin_panel )
	plugin_panel.reload:SetText( "Reload Plugins" )
	plugin_panel.reload.DoClick = function()
		plugins.reload()
	end

	plugin_panel.list = vgui.create( "BPanelList", plugin_panel )
	plugin_panel.list.Paint = vgui.get( "BPanel" ).PaintBackground
	plugin_panel.PerformLayout = function( self )
		plugin_panel.reload:StretchToParent( 5, 5, 5, plugin_panel:GetTall() - 30 )
		plugin_panel.list:StretchToParent( 0, 35, 0, 0 )
	end

	menu.plugin_panel = plugin_panel

end

local function testAlphabetical( a, b )
	local c1, c2 = a:sub( 1, 1 ):byte(), b:sub( 1, 1 ):byte()

	if c1 < c2 then
		return true
	end

	if c1 == c2 then
		local ta, tb = a:sub( 2 ), b:sub( 2 )
		if not ta or ta:len() <= 0 then return false end
		if not tb or tb:len() <= 0 then return true end
		return testAlphabetical( ta, tb )
	end

	return false
end

function menu.reload()

	if not menu_panel then
		menu.create()
		if not menu_panel then return end
		menu_panel:SetVisible( false )
	end

	menu_panel:Clear()
	menu.addPluginTab()

	plugins.callHook( "PluginCreateVGUI", menu_panel )

	menu.plugin_panel.list:Clear()

	local alphabetical = {}
	for k, plugin in pairs( plugins.getList() ) do
		table.insert( alphabetical, plugin )
	end
	table.sort( alphabetical, function( a, b ) return a.name and b.name and a.name:lower() < b.name:lower() end )

	for _, plugin in pairs( alphabetical ) do
		if plugin.optional ~= false then
			local box = menu.plugin_panel.list:CheckBox( plugin.name or "Unknown" )
			box:SetValue( plugin.config.enabled )
			box.OnChange = function( self, b )
				plugin.config.enabled = b

				if b then
					safeCall( plugin.PluginStartup )
				else
					safeCall( plugin.PluginShutdown )
				end

				menu.reload()
			end
		else
			menu.plugins.list:Label( plugin.name or "Unknown" )
		end
	end

end

local ox, oy = ScrW() / 2, ScrH() / 2

local last_open = 0

function menu.open()

	if not menu_panel then
		menu.create()
		if not menu_panel then return end
	end
	gui.EnableScreenClicker( true )
	gui.SetMousePos( ox, oy )
	menu_panel:SetVisible( true )

	if CurTime() < last_open + 0.5 then
		menu.pinned = true
		menu_panel:MakePopup()
	end

	last_open = CurTime()

end

function menu.close()
	if not menu_panel then
		menu.create()
		if not menu_panel then return end
	end
	ox, oy = gui.MousePos()

	if menu.pinned then
		return
	end

	gui.EnableScreenClicker( false )
	menu_panel:SetVisible( false )
end

function menu.AddTab( ... )
	if not menu_panel then return end
	menu_panel:AddTab( ... )
end

local menu_key = KEY_X

hook.add( "KeyPressed", "Menu", function( enum )
	if enum == menu_key then
		menu.open()
	end
end )

hook.add( "KeyReleased", "Menu", function( enum )
	if enum == menu_key then
		menu.close()
	end
end )

if RELOADED then
	menu.reload()
else
	hook.add( "Initialize", "Menu", function()
		menu.reload()
	end )
end

detour.func( _G.gui, "EnableScreenClicker", function( old, b, ... )

	if IsValid( menu_panel ) and menu_panel:IsVisible() and not b then
		return
	end

	return old( b, ... )

end )