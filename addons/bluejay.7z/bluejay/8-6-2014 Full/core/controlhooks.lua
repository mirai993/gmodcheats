--[[
	bluejay/core/controlhooks.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

control = {}

import "input"
import "gui"
import "system"
import "LocalPlayer"

surface.CreateFont( "bjcontrols", {
	font = "Trebuchet",
	size = 12,
	antialias = true,
	weight = 500
} )

local selectedControlBox

function control.shouldIgnore()

	if selectedControlBox then
		return false
	end

	if
		IsValid( _G.vgui.GetKeyboardFocus() ) or
		_G.vgui.CursorVisible() and not _G.vgui.IsHoveringWorld() or
		gui.IsGameUIVisible() or
		gui.IsConsoleVisible() or 
		not system.HasFocus() or 
		LocalPlayer():IsTyping()
	then
		return true
	end

	return false

end

function control.isDown( key )

	if not key then
		return false
	end

	if control.shouldIgnore() then
		return false
	end

	if key[ 1 ] then
		return input.IsKeyDown( key[ 2 ] )
	else
		return input.IsMouseDown( key[ 2 ] )
	end

end

local keyNames = {
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
	
	"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
	"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
	"U", "V", "W", "X", "Y", "Z",
	
	"Numpad 0", "Numpad 1", "Numpad 2", "Numpad 3",
	"Numpad 4", "Numpad 5", "Numpad 6", "Numpad 7",
	"Numpad 8", "Numpad 9", "Numpad /", "Numpad *",
	"Numpad -", "Numpad +", "Numpad Enter", "Numpad .",
	
	"(", ")", ";", "'", "`", ",", ".", "/", "\\", "-",
	"=",
	"Enter", "Space", "Backspace", "Tab", "Capslock",
	"Numlock", "Escape", "Scrolllock", "Insert", "Delete",
	"Home", "End", "Page Up", "Page Down", "Pause",
	
	"Left Shift", "Right Shift",
	"Left Alt", "Right Alt",
	"Left Control", "Right Control",
	"Left Windows", "Right Windows",
	"Application",
	
	"Up", "Left", "Down", "Right",
	
	"F1", "F2", "F3", "F4", "F5", "F6",
	"F7", "F8", "F9", "F10", "F11", "F12",
	
	"Capslock", "Numlock", "Scrolllock",
}

MOUSE_4 = _G.MOUSE_4
MOUSE_5 = _G.MOUSE_5
MOUSE_COUNT = _G.MOUSE_COUNT
MOUSE_LEFT = _G.MOUSE_LEFT
MOUSE_MIDDLE = _G.MOUSE_MIDDLE
MOUSE_RIGHT = _G.MOUSE_RIGHT
MOUSE_WHEEL_UP = _G.MOUSE_WHEEL_UP
MOUSE_WHEEL_DOWN = _G.MOUSE_WHEEL_DOWN

MOUSE_FIRST = _G.MOUSE_FIRST
MOUSE_LAST = _G.MOUSE_LAST

local mouseNames = {
	[MOUSE_4] = "Mouse 4",
	[MOUSE_5] = "Mouse 5",
	[MOUSE_COUNT] = "Mouse Count",
	[MOUSE_FIRST] = "Mouse First",
	[MOUSE_LAST] = "Mouse Last",
	[MOUSE_LEFT] = "Left Mouse",
	[MOUSE_MIDDLE] = "Middle Mouse",
	[MOUSE_RIGHT] = "Right Mouse",
	[MOUSE_WHEEL_DOWN] = "Mouse Wheel Down",
	[MOUSE_WHEEL_UP] = "Mouse Wheel Up",
}

local keyStates = {}
local mouseStates = {}

for enum, _ in pairs( keyNames ) do
	keyStates[ enum ] = false
end

for enum, _ in pairs( mouseNames ) do
	mouseStates[ enum ] = false
end

hook.add( "Think", "ControlHooks", function()

	for enum, state in pairs( keyStates ) do
		local cstate = input.IsKeyDown( enum )
		keyStates[ enum ] = cstate
		if state ~= cstate then
			if cstate then
				if not control.shouldIgnore() then
					hook.call( "KeyPressed", enum )
				end
			else
				hook.call( "KeyReleased", enum )
			end
		end
	end

	for enum, state in pairs( mouseStates ) do
		local cstate = input.IsMouseDown( enum )
		mouseStates[ enum ] = cstate
		if state ~= cstate then
			if cstate then
				if not control.shouldIgnore() then
					hook.call( "MousePressed", enum )
				end
			else
				hook.call( "MouseReleased", enum )
			end
		end
	end

end )

import "surface"
import "Color"

local PANEL = vgui.register( "BControlBox", {} )

function PANEL:Init()
	self.Key = nil
	self.Name = ""
end

function PANEL:SetName( n )
	self.Name = n
end

function PANEL:GetName()
	return self.Name
end

function PANEL:SetKey( data )
	if self.OnSetKey then
		self:OnSetKey( data )
	end

	self.Key = data
end

function PANEL:Paint( w, h )

	surface.SetDrawColor( 200, 200, 200, 255 )
	surface.DrawRect( 0, 0, w, h )

	surface.SetFont( "bjcontrols" )
	local tw, th = surface.GetTextSize( self.Name .. ":" )
	surface.SetTextColor( Color( 50, 50, 50, 255 ) )
	surface.SetTextPos( 10, h / 2 - th / 2 )
	surface.DrawText( self.Name .. ":" )

	local keyText = ""
	if selectedControlBox ~= self then

		local keyData = self.Key
		if keyData then
			local isKeyboard = keyData[ 1 ]
			local enum = keyData[ 2 ]
			if enum ~= 0 then
				if isKeyboard then
					keyText = keyNames[ enum ] or "UNKNOWN"
				else
					keyText = mouseNames[ enum ] or "UNKNOWN"
				end
			end
		end

	else

		keyText = "Press a key..."

	end

	surface.SetFont( "bjcontrols" )
	local tw, th = surface.GetTextSize( keyText )
	surface.SetTextColor( Color( 50, 50, 50, 255 ) )
	surface.SetTextPos( w - tw - 10, h / 2 - th / 2 )
	surface.DrawText( keyText )

	return true

end

local ignoreMouse = false
function PANEL:OnMousePressed( mc )
	if mc == MOUSE_LEFT and not selectedControlBox then
		selectedControlBox = self
		ignoreMouse = true
		self:MouseCapture( true )
	end
end

hook.add( "KeyPressed", "ControlBox", function( kc )

	if not IsValid( selectedControlBox ) then 
		return
	end

	if not keyNames[ kc ] then
		return
	end

	if kc == KEY_BACKSPACE then
		selectedControlBox:SetKey( { true, 0 } )
		selectedControlBox = false
		return
	end

	selectedControlBox:SetKey( { true, kc } )
	selectedControlBox = false

end )

hook.add( "MousePressed", "ControlBox", function( mc )

	if not IsValid( selectedControlBox ) then 
		return
	end

	if not mouseNames[ mc ] then
		return
	end

	if mc == MOUSE_LEFT and ignoreMouse then
		ignoreMouse = false
		return
	end

	selectedControlBox:SetKey( { false, mc } )
	selectedControlBox = false

end )