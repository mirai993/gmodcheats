--[[
	bluejay/load.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

if false then
	bluejayc = nil
	return
end

local bluejay = setmetatable( {}, {
	__index = function( t, k )

		--[[local hook = rawget( t, "hook" )
		if hook then
			local r = { hook.Call( "BluejayMetaIndex", t, k ) }
			if #r > 0 then
				return unpack( r )
			end
		end]]

		return _G[ k ]
		
	end
} )

bluejay._G = _G
bluejay.bluejay = bluejay
bluejay._ENV = bluejay

bluejay.c = bluejayc
_G.bluejayc = nil

local function Color( r, g, b, a )
	return {
		r = r or 255,
		g = g or 255,
		b = b or 255,
		a = a or 255
	}
end

local function error( err, level )

	level = tonumber( level ) or 1
	last_error = CurTime()

	err = tostring( err )
	err = err .. ( err:sub( -1 ) == "\n" and "" or "\n" )

	MsgC( Color( 255, 255, 255, 255 ), "[" )
	MsgC( Color( 15, 175, 255, 255 ), "bluejay" )
	MsgC( Color( 255, 255, 255, 255 ), "][" )
	MsgC( Color( 255, 50, 50, 255 ), "error" )
	MsgC( Color( 255, 255, 255, 255 ), "] " .. err )

	local i, info = 1, debug.getinfo( level + 1 )
	while info do
		MsgC( Color( 175, 175, 25, 255 ), ( "\t" ):rep( i ) .. tostring( info.namewhat ) .. "@" .. tostring( info.short_src ) .. ":" .. tostring( info.currentline ) .. "\n" )
		
		i = i + 1
		info = debug.getinfo( level + i )
	end

end

function bluejay.include( path )

	local func = bluejay.c.compile( path )

	if not func then
		error( "Failed to include " .. tostring( path ) )
		return false
	end

	setfenv( func, bluejay )

	local s, e = pcall( func )
	if not s then
		error( e )
		return false
	end

	return true

end

function bluejay.compile( str )

	local func = bluejay.c.compileString( str )

	if not func then
		error( "Failed to compile string!" )
		return
	end

	setfenv( func, bluejay )

	return func

end

bluejay.include "bluejay/main.lua"