--[[
	bluejay/testhook.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local realgetinfo = debug.getinfo
local getpath = utility.getobjectpath
local printtable = printtable

local print = print

function TEST()
	local i = 1
	debug.sethook( function( event )
		i = i + 1
		if i > 20 then
			debug.sethook()
			return
		end

		local shouldprint = false

		for i=0, 255 do
			local info = debug.getinfo( i )
			if info and info.source == "@" then
				shouldprint = true
			end
		end

		if shouldprint then
			print( "========== Begin" )
			print( "", "Fake" )
			for i=0, 255 do
				local info = debug.getinfo( i )
				if info then
					print( "", i, getpath( info.func ), tostring( info.name ) .. tostring( info.source ) )
				end
			end

			print( "", "Real" )
			for i=0, 255 do
				local info = realgetinfo( i )
				if info then
					print( "", i, getpath( info.func ), tostring( info.name ) .. tostring( info.source ) )
				end
			end
		end

		--[[for i=1, 255 do
			local env = getfenv( i )
			if env ~= _G then
				print( "Found", env )
				printtable( env, 0 )
			end
		end]]
	end, "c" )
end

setfenv( TEST, _G )

TEST()

--[[local i = 1
debug.sethook( function( event )
	i = i + 1
	if i > 2 then
		debug.sethook()
		return
	end

	for i=1, 255 do
		local info = debug.getinfo( i )
		if info then
			print( i, tostring( info.name ) .. tostring( info.source ) )
		end
	end
end, "c" )]]