--[[
	bluejay/reload.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

function reload()

	RELOADED = true

	include "bluejay/main.lua"

end

command.add( "bluejay_reload", function( ply, cmd, arg )
	
	reload()

end )