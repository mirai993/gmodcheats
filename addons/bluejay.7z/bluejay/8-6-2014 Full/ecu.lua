--[[
	bluejay/ecu.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

register( "crankDegrees", 0, 0, 360 )
register( "camDegrees", 0, 0, 360 )

--register( "lastCrankPulse" )
register( "crankRPM" )
--register( "crankRevDuration" )

--register( "lastCamPulse" )
register( "camRPM" )
--register( "camRevDuration" )

function setup()



end

function loop()

	if camRPM then
		local camMicrosecondsPerDegree = 360 / camRevDuration
		local timeSinceCamTDC = micros() - lastCamPulse

		camDegrees = timeSinceCamTDC * camMicrosecondsPerDegree
	end

	if crankRPM then
		local crankMicrosecondsPerDegree = 360 / crankRevDuration
		local timeSinceCrankTDC = micros() - lastCrankPulse

		crankDegrees = timeSinceCrankTDC * crankMicrosecondsPerDegree
	end

end

function campulse()

	if lastCamPulse then
		camRevDuration = micros() - lastCamPulse
		camRPM = math.floor( 60000000 / camRevDuration )
	end

	lastCamPulse = micros()

end

function crankpulse()

	if lastCrankPulse then
		crankRevDuration = micros() - lastCrankPulse
		crankRPM = math.floor( 60000000 / crankRevDuration )
	end

	lastCrankPulse = micros()

end