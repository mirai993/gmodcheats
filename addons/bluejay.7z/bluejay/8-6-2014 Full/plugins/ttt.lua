--[[
	bluejay/plugins/ttt.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "TTT"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local weapons = {}

--[[function PLUGIN.PluginStartup()

	local esp = plugins.get( "ESP" )

	if not esp then return end

	esp.RegisterEntityInfo( "player", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent:Alive() then return end
		if not GAMEMODE or GAMEMODE.Name ~= "Trouble In Terrorist Town" then return end

		for _, wep in pairs( ents.GetAll() ) do
			if wep:IsWeapon() then
				if not weapons[ wep ] or weapons[ wep ] == wep:GetOwner() then
					weapons[ wep ] = wep:GetOwner()
					if wep:GetOwner() == ent then
						table_insert( info, { Color( 255, 0, 0, 255 ), wep:GetClass() } )
					end
				end
			end
		end

		return info

	end )

end]]