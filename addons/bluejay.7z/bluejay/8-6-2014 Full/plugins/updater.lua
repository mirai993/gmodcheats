--[[
	bluejay/plugins/updater.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Updater"

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab, sheet = menu_panel:AddTab( "Updater", "BPanel" )

	tab.reload = vgui.create( "DButton", tab )
	tab.reload:SetText( "Check For Updates" )
	tab.reload.DoClick = PLUGIN.CheckForUpdates

	tab.update = vgui.create( "DButton", tab )
	tab.update:SetText( "Update" )
	tab.update.DoClick = PLUGIN.Update

	tab.list = vgui.create( "BPanelList", tab )
	tab.list.Paint = vgui.get( "BPanel" ).PaintBackground
	tab.PerformLayout = function( self )
		tab.reload:StretchToParent( 5, 5, 5, tab:GetTall() - 30 )
		tab.update:StretchToParent( 5, 30, 5, tab:GetTall() - 55 )
		tab.list:StretchToParent( 0, 60, 0, 0 )
	end

	PLUGIN.tab = tab

end

local UPDATE_URL = "http://blue-jay.info/updater/"

local starting_dir = "bluejay/"

local fetch_queue = 0

function PLUGIN.CheckForUpdates()

	PLUGIN.checkboxes = {}
	PLUGIN.tab.list:Clear()

	http.Fetch( UPDATE_URL .. "version.php", function( html )

		local t = util.JSONToTable( tostring( html ) )
		local needed = {}

		if type( t ) ~= "table" then
			return false
		end

		for path, crc in pairs( t ) do

			local out = c.readFile( starting_dir .. path )
			if not out then
				needed[ #needed + 1 ] = path
			else
				local hexcrc = string.format( "%x", util.CRC( out ) )
				hexcrc = string.rep( "0", 8 - string.len( hexcrc ) ) .. hexcrc

				if hexcrc ~= crc then
					needed[ #needed + 1 ] = { path, crc }
				end
			end

		end

		for _, data in pairs( needed ) do

			--PLUGIN.FetchFile( unpack( data ) )
			local checkbox = PLUGIN.tab.list:CheckBox( data[ 1 ] )
			checkbox.path = data[ 1 ]
			checkbox.crc = data[ 2 ]

			PLUGIN.checkboxes[ data[ 1 ] ] = checkbox

		end

		if fetch_queue == 0 then
			debugprint( "You are up to date!" )
		end

	end, function()

		debugprint( "Failed to connect to update server!" )

	end )

end

function PLUGIN.FetchFile( path, crc )

	fetch_queue = fetch_queue + 1

	http.Fetch( UPDATE_URL .. "fetch.php?p=" .. path, function( html )

		local hexcrc = string.format( "%x", util.CRC( html ) )
		hexcrc = string.rep( "0", 8 - string.len( hexcrc ) ) .. hexcrc

		if hexcrc ~= crc then

			debugprint( "Fetching " .. tostring( path ) .. " failed!! CRC did not match!" )

		else

			c.writeFile( starting_dir .. path, html )
			debugprint( "Fetched " .. tostring( path ) )

		end

		fetch_queue = fetch_queue - 1
		if fetch_queue == 0 then
			debugprint( "Updated!" )

			menu.close()
			reload()
		end

	end, function()

		debugprint( "Fetching " .. tostring( path ) .. " failed!!" )

		fetch_queue = fetch_queue - 1
		if fetch_queue == 0 then
			debugprint( "Updated!" )
			menu.close()
			reload()
		end

	end )

end

function PLUGIN.Update()

	for path, checkbox in pairs( PLUGIN.checkboxes ) do

		if checkbox:GetChecked() then

			PLUGIN.FetchFile( path, checkbox.crc )

		end

	end

end