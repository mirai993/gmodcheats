--[[
	bluejay/plugins/netlog.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local seed = { 622731, 180200, 953754, 710098 }
local ts = tostring
local tn = tonumber
local AC_SendSS, AC_GotSS = ts( (seed[1]*seed[2])/seed[3] ), ts( (seed[1]+seed[2])*seed[3] )
local AC_SendAC, AC_SendFile = ts( (tn(AC_SendSS)*tn(AC_GotSS))*seed[4] ), ts( (tn(AC_SendSS)+tn(AC_GotSS))*seed[4] )

local PLUGIN = plugins.register "Netlog"

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "Netlog", "BPanelList" )

	PLUGIN.tab = tab

end

function PLUGIN.PluginStartup()

	--[[detour.func( _G.net, "Start", function( old, name, ... )

		debugprint( "netmessagestart", name )

		return old( name, ... )

	end )]]

end

function PLUGIN.PluginShutdown()



end

function PLUGIN.sendnetmessage( name )
	
	--debugprint( "netmessage", name )

	PLUGIN.tab:Label( tostring( name ) )

	if name == AC_SendAC then
		debugprint( "BLOCKED NETMESSAGE", name )
		return true
	end

end