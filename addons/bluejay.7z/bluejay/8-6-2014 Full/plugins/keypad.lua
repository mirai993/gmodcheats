--[[
	bluejay/plugins/keypad.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Keypad Cracker"

local X = -50
local Y = -100
local W = 100
local H = 200

local keyPos = {	
	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
	{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
	{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

	{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
	{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
	{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

	{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
	{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
	{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

	{X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
	{X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}

function PLUGIN.Think()
	for _, keypad in pairs( ents.FindByClass( "keypad" ) ) do
		local status = keypad:GetStatus()

		local curNum = string.len( keypad:GetDisplayText() or "" )
		if keypad.prevNum != curNum and curNum != 0 then
			if curNum == 1 or !keypad.candidateCode then keypad.candidateCode = "" end
			
			if curNum > 0 then
				// Retrieve player entering the digit
				local usingPlayer = NULL
				for _, pl in pairs( player.GetAll( ) ) do
					local ent = pl:GetEyeTrace( ).Entity
					if IsValid( ent ) and ent == keypad then
						usingPlayer = pl
						break
					end
				end
				
				if IsValid( usingPlayer ) then
					// Retrieve exact entered digit
					local pos = keypad:WorldToLocal( usingPlayer:GetEyeTrace( ).HitPos )
					local digit = "*"
					for i, v in pairs( keyPos ) do
						local x = ( pos.y - v[5] ) / ( v[5] + v[6] )
						local y = 1 - ( pos.z + v[7] ) / ( v[7] + v[8] )
						
						if x >= 0 and y >= 0 and x <= 1 and y <= 1 then
							digit = i
							break
						end
					end
					
					keypad.candidateCode = keypad.candidateCode .. tostring( digit )
				end
			end
		end
		
		-- Copy the collected digits to the definitive code variable since we now know it's correct!
		if status == keypad.Status_Granted and keypad.code != keypad.candidateCode then
			keypad.code = keypad.candidateCode
		end
		
		keypad.prevNum = curNum
	end
end

function PLUGIN.HUDPaint()
	local keypad = LocalPlayer( ):GetEyeTrace( ).Entity
	if IsValid( keypad ) and keypad:GetClass( ) == "keypad" then
		local keypadTxt = ""
		local keypadColor = Color( 192, 255, 192, 255 )
		
		if !keypad.code then
			keypadTxt = "Code not retrieved yet!"
			keypadColor = Color( 255, 128, 128, 255 )
		else
			keypadTxt = "Keypad Code: " .. keypad.code
		end
		
		surface.SetFont( "Default" )
		local w, h = surface.GetTextSize( keypadTxt )
		draw.WordBox( 8, ScrW( ) / 2 - w / 2 - 8, ScrH( ) / 2 - h / 2 - 48, keypadTxt, "Default", Color( 0, 0, 0, 128 ), keypadColor )
	end
end