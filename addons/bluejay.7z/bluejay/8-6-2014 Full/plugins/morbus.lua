--[[
	bluejay/plugins/morbus.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Morbus"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local function getWeapons( ply )
	local t = {}
	if ply:Health() <= 0 then return t end

	local pos = ply:GetPos() + Vector( 0, 0, ply:Crouching() and 30 or 36 )
	for k, v in pairs( ents.FindByClass( "weapon_*" ) ) do
		if v:IsWeapon() and v:GetPos():Distance( pos ) < 3 then
			table.insert( t, v )
		end
	end

	return t
end

function PLUGIN.PluginStartup()

	local esp = plugins.get( "ESP" )

	if not esp then return end

	esp.RegisterEntityInfo( "player", function( ent )

		if not PLUGIN.config.enabled then return end

		local info = {}

		for k, v in pairs( getWeapons( ent ) ) do
			if v:GetClass() == "weapon_mor_swarm" then
				table_insert( info, { Color( 255, 175, 0, 255 ), "[SWARM ALIEN]" } )
			elseif v:GetClass() == "weapon_mor_brood" then
				table_insert( info, { Color( 255, 050, 0, 255 ), "[BROOD ALIEN]" } )
			end
		end

		return info

	end )

end