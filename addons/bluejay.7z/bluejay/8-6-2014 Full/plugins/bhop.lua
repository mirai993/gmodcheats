--[[
	bluejay/plugins/bhop.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Bunnyhop"

import "LocalPlayer"
import "bit"

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "BHop", "BPanelList" )

	tab:ControlBox( "Bunnyhop", PLUGIN, "bhop_key" )
	tab:ControlBox( "Prehop", PLUGIN, "phop_key" )

end

function PLUGIN.SetMoveDirection( cmd, direction )

	local vec_move = Vector()
		vec_move.x = cmd:GetForwardMove()
		vec_move.y = cmd:GetSideMove()
		vec_move.z = cmd:GetUpMove()

	if type( direction ) == "Vector" then
		direction = direction:Angle()
	end

	local difference = cmd:GetViewAngles() - direction
	difference.p = 0

	vec_move:Rotate( difference )

	cmd:SetForwardMove( vec_move.x )
	cmd:SetSideMove( vec_move.y )
	cmd:SetUpMove( vec_move.z )

end

function PLUGIN.CreateMove( cmd )

	if LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then
		return
	end

	if control.isDown( PLUGIN.config.bhop_key ) or control.isDown( PLUGIN.config.phop_key ) then

		local buttons = cmd:GetButtons()
		if LocalPlayer():IsOnGround() and not pressed then
			cmd:SetButtons( bit.bor( buttons, IN_JUMP ) )
			return
		end

		if bit.band( buttons, IN_JUMP ) > 0 then
			cmd:SetButtons( bit.bxor( buttons, IN_JUMP ) )
		end

		--[[local vel = LocalPlayer():GetVelocity()
		local ang = vel:Angle()

		local difference = ]]

	end

	--[[if control.isDown( PLUGIN.config.phop_key ) then

		local vel = LocalPlayer():GetVelocity()

		local desired_direction = vel:GetNormal():Cross( Vector( 0, 0, 1 ) )

		PLUGIN.SetMoveDirection( cmd, desired_direction )

	end]]

end