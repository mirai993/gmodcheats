--[[
	bluejay/plugins/visible.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Eyeballs"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local function AngBetweenVectors( v1, v2 )

	return math.acos( v1:Dot( v2 ) ) * 180 / math.pi

end

local sqrt_two = math.sqrt( 2 )

function PLUGIN.CanSee( ply, target )

	local t = type( target )

	if t == "Vector" then

		local shootpos = ply:GetShootPos()
		local aimvector = ply:GetAimVector()
		local direction = ( target - shootpos ):GetNormal()
		--local dot = aimvector:Dot( direction )

		local fov = ply:GetFOV() / 2

		if AngBetweenVectors( aimvector, direction ) > fov * sqrt_two then
			return false
		end

		local tr = util.TraceLine( {
			start = shootpos,
			endpos = target,
			filter = { ply, IsValid( target ) and target },
			mask = MASK_VISIBLE
		} )

		if tr.Fraction == 1 then
			return true
		end

	elseif IsValid( target ) then

		if ply:GetObserverTarget() == target then
			return true, "spectating"
		end

		if IsValid( target:GetObserverTarget() ) or target:GetMoveType() == MOVETYPE_OBSERVER then
			return false
		end

		local fog_start, fog_end = render.GetFogDistances()
		if fog_end and ply:GetShootPos():Distance( target:GetShootPos() ) > fog_end then
			return false
		end

		local check = {}
		local max, min, center = target:OBBMaxs(), target:OBBMins(), target:OBBCenter()

		table_insert( check, target:GetPos() )

		table_insert( check, target:LocalToWorld( max ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, max.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, min.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, min.y, max.z ) ) )

		table_insert( check, target:LocalToWorld( min ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, min.y, min.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, max.y, min.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, max.y, min.z ) ) )

		table_insert( check, target:LocalToWorld( center ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, center.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, center.y, min.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, center.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, center.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, max.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, min.y, center.z ) ) )

		table_insert( check, target:LocalToWorld( Vector( max.x, max.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, min.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, max.y, center.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, min.y, center.z ) ) )

		table_insert( check, target:LocalToWorld( Vector( center.x, max.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, min.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, max.y, min.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( center.x, min.y, min.z ) ) )

		table_insert( check, target:LocalToWorld( Vector( max.x, center.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, center.y, max.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( max.x, center.y, min.z ) ) )
		table_insert( check, target:LocalToWorld( Vector( min.x, center.y, min.z ) ) )

		for _, pos in ipairs( check ) do
			if PLUGIN.CanSee( ply, pos ) then
				return true
			end
		end

	end

	return false

end

function PLUGIN.HUDPaint()

	local x, y = 20, ScrH() / 2

	surface.SetFont( "Bluejay13" )

	for _, ply in ipairs( player.GetAll() ) do

		if ply ~= LocalPlayer() then

			local cansee, reason = PLUGIN.CanSee( ply, LocalPlayer() )
			if cansee then

				local rank = utility.getrank( ply )

				local name = ply.SteamName and ply:SteamName() or ply:Nick()
				if ply.SteamName and ply:SteamName() ~= ply:Nick() then
					name = ply:Nick() .. " (" .. ply:SteamName() .. ")"
				end

				local text = ( reason and ( reason .. " - " ) or "" ) .. ( rank and ( "[" .. rank .. "] " ) or "" ) .. tostring( name ) .. ": " .. math.ceil( ply:GetShootPos():Distance( LocalPlayer():GetShootPos() ) )
				local tw, th = surface.GetTextSize( text )
				surface.SetTextColor( 255, rank and 0 or 255, rank and 0 or 255, 255 )
				surface.SetTextPos( x, y )
				surface.DrawText( text )

				y = y + th + 3

			end

		end

	end

end