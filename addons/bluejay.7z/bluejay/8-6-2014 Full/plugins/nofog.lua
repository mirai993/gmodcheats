--[[
	bluejay/plugins/nofog.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Hide Fog"

function PLUGIN.SetupWorldFog()

	render.FogMode( 0 )

	return true

end

local ignore = false
function PLUGIN.CalcView( ply, origin, angles, fov, nearZ, farZ )

	if ignore then return end

	ignore = true
	local view = _G.hook.Call( "CalcView", GAMEMODE, ply, origin, angles, fov, nearZ, farZ )
	ignore = false

	view.farZ = 100000

	return view

end