--[[
	bluejay/plugins/gmodz.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "GModZ"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local function sendmessage( name, data )
	net.Start( "askdo" .. name )
		if type(data) == "table" then
			net.WriteTable( data or {} )
		elseif type(data) == "number" then
			net.WriteFloat( tonumber(data) or 1 )
		end
	net.SendToServer()
end

local nexttime
function PLUGIN.Think()

	local inv = PLUGIN.config.current_inventory or 1

	if not nexttime then
		return
	end

	--[[local count = 1
	for slot, data in pairs( LocalPlayer().inventory ) do
		if type( data ) == "table" then
			if data.item ~= "none" then
				--count = count + 1
				sendmessage( "AskDropItem", { id = slot, count = data.count } )
			end
		end
	end

	if count >= 20 then
		return
	end]]

	if CurTime() > nexttime then
		inv = inv + 1
		nexttime = CurTime() + 0.25

		for item=1, 20 do
			sendmessage( "AskPickupItemInv", { inv=inv, i=item } )
		end
	end

	PLUGIN.config.current_inventory = inv

end

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "GModZ", "BPanelList" )

	tab:SetSpacing( 3 )

	local function grabItems( targetitem )

		for invid, data in pairs( inv ) do
			if invid ~= bankId then
				for slot, item in pairs( data ) do
					if type( item ) == "table" and item.item ~= "none" and string.find( item.item, targetitem ) then
						sendmessage( "AskPickupItemInv", { inv=invid, i=slot } )
					end
				end
			end
		end

	end

	tab:Button( "Grab All Items", function()

		grabItems( "." )

	end )

	tab:Button( "Print Items", function()

		for invid, data in pairs( inv ) do
			if invid ~= bankId then
				print( invid )
				for slot, item in pairs( data ) do
					if type( item ) == "table" and ( item.item ~= "none" ) then
						print( "", item.item, item.count )
					end
				end
			end
		end

	end )

	tab:Button( "Steal Everything", function()
		nexttime = CurTime()
	end )

	tab:Button( "Stop Stealing Everything", function()
		nexttime = nil
	end )

	tab:Button( "Reset Current Inv", function()
		PLUGIN.config.current_inventory = 1
	end )

	tab:Button( "Grab Bank Stuff", function()
		local inventory = inv[ bankId ]
		if inventory then
			for slot, item in pairs( inventory ) do
				if type( item ) == "table" and item.item ~= "none" then
					sendmessage( "AskPickupItemInv", { inv=bankId, i=slot } )
				end
			end
		end
	end )

	tab:Button( "Drop All Items", function()
		for slot, data in pairs( LocalPlayer().inventory ) do
			if type( data ) == "table" then
				if data.item ~= "none" then
					sendmessage( "AskDropItem", { id = slot, count = data.count } )
				end
			end
		end
	end )

end

function PLUGIN.PluginStartup()

	local esp = plugins.get( "ESP" )

	if not esp then return end

	esp.RegisterEntityInfo( "gmodz_item", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent.askedInfo then
			if AskItemInfo then
				ent.askedInfo = true
				AskItemInfo( ent )
			end

			local info = {}
			table_insert( info, { Color( 220, 150, 25, 150 ), "UNKNOWN" } )
			return info
		end

		if ent.id == "none" then return end

		if not items then return end

		local data = items[ ent.id ]

		if data then

			local info = {}
			table_insert( info, { Color( 220, 150, 25, 150 ), data.name } )
			table_insert( info, { Color( 220, 150, 25, 150 ), PLUGIN.config.current_inventory } )
			return info

		end

	end )

	esp.RegisterEntityInfo( "gmodz_inv", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent.askedInfo then
			if AskInvInfo then
				ent.askedInfo = true
				AskInvInfo( ent )
			end
		end

		local info = {}
		table_insert( info, { Color( 220, 150, 25, 50 ), "Backpack" } )

		if ent.inv then
			table_insert( info, { Color( 255, 255, 255, 50 ), ent.inv } )
			local invdata = _G.inv[ ent.inv ]
			if invdata then
				local count = 0
				for _, data in pairs( invdata ) do
					if type( data ) == "table" and data.item ~= "none" then
						local name = items and items[ data.item ] and items[ data.item ].name or data.item or "unknown"
						count = count + 1
						table_insert( info, { Color( 255, 255, 255, 50 ), name .. " x" .. data.count } )
					end
				end

				if count == 0 then
					table_insert( info, { Color( 255, 255, 255, 50 ), "EMPTY" } )
				end
			end
		end

		return info

	end )

end

detour.func( _G.net, "Incoming", function( old, len, client )

	local i = net.ReadHeader()
	local strName = util.NetworkIDToString( i )
	
	if ( !strName ) then return end

	if strName:find("askdo") then
		return
	end
	
	local func = net.Receivers[ strName:lower() ]
	if ( !func ) then return end

	--
	-- len includes the 16 byte int which told us the message name
	--
	len = len - 16
	
	func( len, client )

end )