--[[
	bluejay/plugins/speedhack.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Speedhack"

convar.detourConVar( "sv_cheats" )
convar.detourConVar( "host_timescale" )

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "Speedhack", "BPanelList" )

	tab:SetSpacing( 3 )

	tab:ControlBox( "Speedhack", PLUGIN, "speedhack_key" )

	tab:Label( "Desired Speed" )
	tab:Slider( 0, 1500, PLUGIN, "desiredspeed" )

end

function PLUGIN:Tick()

	if control.isDown( PLUGIN.config.speedhack_key )  then
		
		convar.setConVar( "sv_cheats", 1 )
		convar.setConVar( "host_timescale", PLUGIN.config.desiredspeed / LocalPlayer():GetMaxSpeed() )

	elseif tonumber( convar.getConVar( "host_timescale" ) or 1 ) ~= 1 then

		convar.setConVar( "sv_cheats", 0 )
		convar.setConVar( "host_timescale", 1 )

	end

end