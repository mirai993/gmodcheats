--[[
	bluejay/plugins/aimbot.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Aimbot"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local function table_append( tbl, append )

	if not append then return end

	for _, v in ipairs( append ) do
		tbl[ #tbl + 1 ] = v
	end

end

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "Aimbot", "DPanel" )

	local options_list = vgui.create( "BPanelList", tab )
	options_list:SetSpacing( 3 )

	options_list:ControlBox( "Aimbot", PLUGIN, "aimbot_key" )
	options_list:ControlBox( "Turbofire", PLUGIN, "turbofire_key" )

	local mode = options_list:MultiChoice( PLUGIN, "target_mode" )
	mode:AddChoice( "Angle", 1 )
	mode:AddChoice( "Eye Angles", 2 )
	mode:AddChoice( "Distance from screen center", 3 )
	mode:AddChoice( "Distance", 4 )
	mode:AddChoice( "Danger", 5 )

	options_list:Label( "Field of View" )
	options_list:Slider( 0, 180, PLUGIN, "fov" )

	options_list:Spacer()

	PLUGIN.config.ignore_players = PLUGIN.config.ignore_players or {}

	options_list:CheckBox( "Predict Position", PLUGIN, "predictpos" )
	options_list:CheckBox( "Simulate Gravity", PLUGIN, "simulategravity" )

	options_list:Spacer()

	options_list:CheckBox( "Free Look", PLUGIN, "freelook" )

	options_list:Spacer()

	options_list:CheckBox( "Friendly Fire", PLUGIN, "friendlyfire" )
	options_list:CheckBox( "Target Players", PLUGIN, "target_players" )
	options_list:CheckBox( "Target NPCs", PLUGIN, "target_npcs" )
	options_list:CheckBox( "Ignore Walls", PLUGIN, "ignore_walls" )

	options_list:Spacer()

	options_list:CheckBox( "No Viewpunch", PLUGIN, "noviewpunch" )
	options_list:CheckBox( "No Recoil", PLUGIN, "norecoil" )
	options_list:CheckBox( "No Spread", PLUGIN, "nospread" )

	local player_list = vgui.create( "BPanelList", tab )
	player_list.crc = ""

	PLUGIN.player_list = player_list

	tab.PerformLayout = function()
		options_list:StretchToParent( 0, 0, tab:GetWide() / 2 - 4, 0 )
		player_list:StretchToParent( tab:GetWide() / 2 + 6, 0, 0, 0 )
	end

end

function PLUGIN.Think()
	
	local player_list = PLUGIN.player_list

	if not IsValid( player_list ) then
		return
	end

	local to_crc = ""
	for _, ply in ipairs( player.GetAll() ) do
		to_crc = to_crc .. tostring( ply )
	end

	local crc = util.CRC( to_crc )
	if player_list.update or crc ~= player_list.crc then

		player_list.crc = crc

		player_list:Clear( true )

		player_list:Button( "Clear Saved Players", function()
			PLUGIN.config.ignore_players = {}
			player_list.update = true
		end )

		player_list:Button( "All", function()
			for _, checkbox in pairs( player_list:GetItems() ) do
				if checkbox.steamid then
					checkbox:SetValue( true )
				end
			end
		end )

		player_list:Button( "None", function()
			for _, checkbox in pairs( player_list:GetItems() ) do
				if checkbox.steamid then
					checkbox:SetValue( false )
				end
			end
		end )

		for _, ply in pairs( player.GetAll() ) do

			if ply ~= LocalPlayer() then
				local name = ply:Name() or ply:Nick() or ply:SteamID() or "UNKNOWN"
				local checkbox = player_list:CheckBox( name )
				checkbox.steamid = ply:SteamID()
				checkbox:SetValue( PLUGIN.config.ignore_players[ checkbox.steamid ] or false )
				checkbox.OnChange = function( _, b )
					PLUGIN.config.ignore_players[ checkbox.steamid ] = b
				end
			end

		end

	end

end

local function approach( cur, target, inc )

	inc = math.abs( inc )

	if ( cur < target ) then
		
		return math.Clamp( cur + inc, cur, target )

	elseif ( cur > target ) then

		return math.Clamp( cur - inc, target, cur )

	end

	return target

end

local target_p = 0
local aim_p = 0

local delta = 0

function PLUGIN.HUDPaint()

	local pos = LocalPlayer():GetEyeTraceNoCursor().HitPos
	if not pos then return end
	pos = pos:ToScreen()

	local x, y = ScrW() / 2, ScrH() / 2

	local distance = Vector( pos.x, pos.y ):Distance( Vector( x, y ) )

	surface.SetAlphaMultiplier( math.Clamp( distance / 30, 0, 1 )  )

	surface.SetDrawColor( 0, 0, 0, 200 )
	surface.DrawRect( pos.x -  2, pos.y - 15, 4, 10 )
	surface.DrawRect( pos.x -  2, pos.y +  5, 4, 10 )
	surface.DrawRect( pos.x - 15, pos.y -  2, 10, 4 )
	surface.DrawRect( pos.x +  5, pos.y -  2, 10, 4 )

	surface.SetDrawColor( 255, 255, 255, 200 )
	surface.DrawRect( pos.x -  1, pos.y - 14, 2, 8 )
	surface.DrawRect( pos.x -  1, pos.y +  6, 2, 8 )
	surface.DrawRect( pos.x - 14, pos.y -  1, 8, 2 )
	surface.DrawRect( pos.x +  6, pos.y -  1, 8, 2 )

	surface.SetAlphaMultiplier( 1 )

	surface.SetDrawColor( 0, 0, 0, 200 )
	surface.DrawRect( x - 2, y - 2, 4, 4 )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawRect( x - 1, y - 1, 2, 2 )

	local target = PLUGIN.current_target
	local target_position

	if not PLUGIN.CanTarget( target ) then
		target, target_position = PLUGIN.GetTarget()
	end

	if not target_position then
		target_position = PLUGIN.GetTargetPosition( target )
	end

	target_p = approach( target_p, ( IsValid( target ) and target == PLUGIN.current_target ) and 1 or 0, FrameTime() / 0.25 )

	if not target_position then return end

	local pos = target_position:ToScreen()
	local rad = 8 + 10 * target_p--15--target_position:Distance( EyePos() ) 

	delta = delta + FrameTime() * target_p * 3

	local step_size = math.pi / 3

	local lx, ly

	for i=0, math.pi * 2, step_size do
		local x, y = math.floor( pos.x + math.cos( i + delta ) * rad ), math.floor( pos.y + math.sin( i + delta ) * rad )

		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawRect( x - 2, y - 2, 4, 4 )

		surface.SetDrawColor( 200 + target_p * 55, 200 - 100 * target_p, 200 - 190 * target_p, 255 )
		--surface.SetDrawColor( 200, 200, 200, 255 )
		surface.DrawRect( x - 1, y - 1, 2, 2 )
	end

end

local function HasBase( ent, base )
	if ent.ClassName == base then return end
	while ent.BaseClass do
		ent = ent.BaseClass
		if ent.ClassName == base then return true end
	end
	return false
end

local CPPSpread = {
	["#HL2_SMG1"]        = Vector( 0.04362, 0.04362, 0.04362 ),
	["#HL2_Pistol"]      = Vector( 0.0100, 0.0100, 0.0100 ),
	["#HL2_Pulse_Rifle"] = Vector( 0.02618, 0.02618, 0.02618 )
}

local SpreadFunctions = {}

function PLUGIN.RegisterWeaponSpread( classname, func )

	SpreadFunctions[ classname ] = func

end

function PLUGIN.GetWeaponSpread( weapon )

	if CPPSpread[ weapon:GetPrintName() ] then
		return CPPSpread[ weapon:GetPrintName() ]
	elseif type( weapon.Initialize ) ~= "function" then -- If it's a CPP weapon and we have no cone, we can't do anything
		return 0
	end

	if type( weapon.HoldType ) == "string" and weapon.HoldType:find( "melee" ) then
		return 0
	end

	local cone = weapon.Primary and ( weapon.Primary.Spread or weapon.Primary.Cone ) or weapon.Spread or weapon.Cone or 0

	local base = weapon
	while base do
		if SpreadFunctions[ base.ClassName ] then
			return SpreadFunctions[ base.ClassName ]( weapon ) or cone
		end

		base = base.BaseClass
	end

	return cone

end

function PLUGIN.PredictSpread( cmd, aim )

	local currentseed = 0
	local ucmd_number, seed = c.getUCMDNumber( cmd )

	if ucmd_number ~= 0 then
		currentseed = seed
	else
		return type( aim ) == "Vector" and aim:Angle() or aim
	end

	aim = aim or LocalPlayer():GetAimVector()

	if type( aim ) == "Angle" then
		aim = aim:Forward()
	end

	local weapon = LocalPlayer():GetActiveWeapon()
	local spread_cone = Vector( 0, 0, 0 )

	if IsValid( weapon ) then
		local raw_cone = PLUGIN.GetWeaponSpread( weapon )
		local t = type( raw_cone )
		if t == "number" then
			spread_cone = Vector( 1, 1, 1 ) * -raw_cone
		elseif t == "Vector" then
			spread_cone = -raw_cone
		end
	end

	local counter_aim = c.manipulateShot( currentseed or 0, aim, spread_cone )

	return type( counter_aim ) == "Vector" and counter_aim:Angle() or aim

end

function PLUGIN.GetPossibleTargets()

	local targets = {}

	if PLUGIN.config.target_players then
		table_append( targets, player.GetAll() )
	end

	if PLUGIN.config.target_npcs then
		for _, ent in ipairs( ents.GetAll() ) do
			if IsValid( ent ) and ent:IsNPC() then
				table_insert( targets, ent )
			end
		end
	end

	return targets

end

function PLUGIN.CanTarget( target, target_position )

	if not IsValid( target ) then
		return false
	end

	if not target:IsNPC() and not target:IsPlayer() then
		return false
	end

	if target == LocalPlayer() then
		return false
	end

	local movetype = target:GetMoveType()
	if movetype == MOVETYPE_NONE or movetype == MOVETYPE_OBSERVER then
		return false
	end

	if target:IsPlayer() then

		if not target:Alive() or target:Health() <= 0 then
			return false
		end

		if not PLUGIN.config.friendlyfire and target:Team() == LocalPlayer():Team() then
			return false
		end

		if PLUGIN.config.ignore_players[ target:SteamID() ] then
			return false
		end

		if target:InVehicle() then
			return false
		end

	end

	if target:IsNPC() and not PLUGIN.config.target_npcs then
		return false
	end

	if PLUGIN.config.fov and PLUGIN.config.fov < 360 then
		target_position = target_position or PLUGIN.GetTargetPosition( target )
		local aim = LocalPlayer():GetAimVector()
		local direction = ( target_position - EyePos() ):GetNormal()
		local angle_difference = math.acos( aim:Dot( direction ) )

		if ( angle_difference * ( 180 / math.pi ) ) > PLUGIN.config.fov then
			return false
		end
	end

	if not PLUGIN.config.ignore_walls then
		target_position = target_position or PLUGIN.GetTargetPosition( target )
		local spos = LocalPlayer():GetShootPos()

		local filter = { LocalPlayer(), target }

		for _, ply in ipairs( player.GetAll() ) do

			if _G.hook.Call( "ShouldCollide", GAMEMODE, LocalPlayer(), ply ) == false then
				table_insert( filter, ply )
			end

		end

		local tr = util.TraceLine( {
			start = spos,
			endpos = target_position,
			mask = MASK_SHOT,
			filter = filter
		} )

		if tr.Fraction < 1 then
			return false
		end
	end

	return true

end

--[[function PLUGIN.WillHitTarget( target )

	if not PLUGIN.CanHit( target ) then
		return false
	end

	local td = {}
	td.start = LocalPlayer():GetShootPos()
	td.endpos = td.start + LocalPlayer():GetAimVector() * 10000
	td.filter = LocalPlayer()
	td.mask = MASK_SHOT

	local tr = util.TraceLine( td )

	if tr.Entity == target then
		return true
	end

	return true

end]]

local last_target
local last_position
local last_targetupdate

function PLUGIN.GetTarget()

	if last_targetupdate == CurTime() then
		return last_target, last_position
	end

	local shootpos = LocalPlayer():GetShootPos()
	local aim = LocalPlayer():GetAimVector()

	local targets = PLUGIN.GetPossibleTargets()
	local target, best_value, best_position

	for _, potential_target in pairs( targets ) do
		local target_position = PLUGIN.GetTargetPosition( potential_target )

		if target_position and PLUGIN.CanTarget( potential_target, target_position ) then

			local target_mode = PLUGIN.config.target_mode

			if target_mode == 1 then -- Angle difference
				local dot = aim:Dot( ( target_position - shootpos ):GetNormal() )
				if not best_value or dot > best_value then
					target = potential_target
					best_value = dot
					best_position = target_position
				end
			elseif target_mode == 2 then -- Eyeangles difference
				local dot = EyeAngles():Forward():Dot( ( target_position - shootpos ):GetNormal() )
				if not best_value or dot > best_value then
					target = potential_target
					best_value = dot
					best_position = target_position
				end
			elseif target_mode == 3 then -- Screen center distance
				local pos = target_position:ToScreen()
				local distance = Vector( ScrW()/2, ScrH()/2 ):Distance( Vector( pos.x, pos.y ) )
				if not best_value or distance < best_value then
					target = potential_target
					best_value = distance
					best_position = target_position
				end
			elseif target_mode == 4 then -- Distance
				local distance = shootpos:Distance( target_position )
				if not best_value or distance < best_value then
					target = potential_target
					best_value = distance
					best_position = target_position
				end
			elseif target_mode == 5 then -- Danger
				local danger = 0
				danger = danger + potential_target:Health()

				if not best_value or danger > best_value then
					target = potential_target
					best_value = distance
					best_position = target_position
				end
			end
		end
	end

	last_target = target
	last_position = best_position
	last_targetupdate = CurTime()

	return target, best_position

end

local targetBones = {
	{ "ValveBiped.Bip01_Head1", Vector( 3.5, -2, 0 ) },
	"ValveBiped.head",
	"Barnacle.body",
	"ValveBiped.HC_HeadCube",
	"ValveBiped.HC_Body_Bone",
	"Antlion.Head_Bone",
	"ValveBiped.HC_BodyCube",
	"ValveBiped.Bip01_Spine4",
	"Dog_Model.Eye_Panel_Top",
	"Scanner.Body",
	"Manhack.MH_Control",
	"Antlion_Guard.head",
	"MiniStrider.antennaBase",
	"Crow.Head",
	"Seagull.Head",
	"HCblack.body",
	"HCfast.body",
	"HeadcrabClassic.SpineControl",
}

function PLUGIN.PredictPos( target, pos )

	if not PLUGIN.config.predictpos then
		return pos
	end

	--if true then return pos + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45 end

	local time = 1 / 30--GetConVarNumber( "cl_cmdrate" )

	local oneway_ping = LocalPlayer():Ping() / 2000
	if oneway_ping > 0.5 then -- Serverside caching allows prediction upto 0.5 seconds ago.
		time = time + ping - 0.5
	end

	local gravity = Vector( 0, 0, 0 )
	if PLUGIN.config.simulategravity then
		local sv_gravity = physenv.GetGravity()
		gravity = gravity + sv_gravity * ( ( target:GetMoveType() == MOVETYPE_NOCLIP or target:OnGround() ) and 0 or 1 )
		gravity = gravity - sv_gravity * ( ( target:GetMoveType() == MOVETYPE_NOCLIP or LocalPlayer():OnGround() ) and 0 or 1 )
	end

	gravity = gravity * time

	local velocity = target:GetVelocity() - LocalPlayer():GetVelocity() + gravity

	return pos + velocity * time

end

function PLUGIN.GetTargetPosition( target )

	if not IsValid( target ) then
		return
	end

	local target_position = target:LocalToWorld( target:OBBCenter() )--target:GetPos()

	for _, bone in ipairs( targetBones ) do

		local bone_name = bone
		local bone_shift = Vector( 0, 0, 0 )

		if type( bone ) == "table" then
			bone_name = bone[ 1 ]
			bone_shift = bone[ 2 ]
		end

		local bone = target:LookupBone( bone_name )

		if bone then
			local pos, ang = target:GetBonePosition( bone )
			target_position = LocalToWorld( bone_shift, Angle( 0, 0, 0 ), pos, ang )
			break
		end

	end

	target_position = PLUGIN.PredictPos( target, target_position ) or target_position

	return target_position

end

local function clamp( n, min, max )
	return math.min( math.max( n, min ), max )
end

local function clampAngle( ang, min, max )
	ang.p = clamp( ang.p, min.p, max.p )
	ang.y = clamp( ang.y, min.y, max.y )
	ang.r = clamp( ang.r, min.r, max.r )
	return ang
end

local function normalizeAngle( ang )
	ang.p = ( ang.p + 180 ) % 360 - 180
	ang.y = ( ang.y + 180 ) % 360 - 180
	ang.r = ( ang.r + 180 ) % 360 - 180
	return ang
end

local function normalizeViewAngle( ang )
	return clampAngle( normalizeAngle( ang ), Angle( -90, -180, 0 ), Angle( 90, 180, 0 ) )
end

local norecoil
local freelook
local uncorrected

local turbotoggle = false

function PLUGIN.CreateMove( cmd )

	local ply = LocalPlayer()
	if not IsValid( ply ) then
		return
	end

	local weapon = ply:GetActiveWeapon()
	local ignore_turn = IsValid( weapon ) and weapon:GetClass() == "weapon_physgun" and bit.band( cmd:GetButtons(), IN_USE ) > 0

	local can_turbofire = control.isDown( PLUGIN.config.turbofire_key ) and not ( control.isDown( PLUGIN.config.aimbot_key ) and not PLUGIN.CanTarget( PLUGIN.current_target ) )

	if can_turbofire then

		if ply:Health() > 0 then

			if not weapon or ( weapon.Automatic or weapon.Primary and weapon.Primary.Automatic ) or not turbotoggle then
				cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_ATTACK ) )
				turbotoggle = true
			elseif turbotoggle then
				cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_ATTACK ) ) )
				turbotoggle = false
			end

		end

	elseif turbotoggle then

		cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_ATTACK ) ) )
		turbotoggle = false

	end

	if control.isDown( PLUGIN.config.aimbot_key ) then

		if PLUGIN.config.freelook then
			if not freelook then
				freelook = cmd:GetViewAngles()
				freelook.r = 0
			elseif not ignore_turn then
				freelook.p = freelook.p + cmd:GetMouseY() * GetConVarNumber( "m_pitch" )
				freelook.y = freelook.y + cmd:GetMouseX() * GetConVarNumber( "m_yaw" ) * -1
				freelook.r = 0
			end
		end

		local target, target_position = PLUGIN.current_target
		if not PLUGIN.CanTarget( target ) then
			target, target_position = PLUGIN.GetTarget()
		end

		PLUGIN.current_target = target

		if target then

			if not target_position then
				target_position = PLUGIN.GetTargetPosition( target )
			end

			local spos = ply:GetShootPos()

			local aimAngles = ( target_position - spos ):GetNormal():Angle()

			cmd:SetViewAngles( normalizeViewAngle( aimAngles ) )

		else

			if freelook then
				cmd:SetViewAngles( normalizeViewAngle( freelook ) )
			end
			
		end

	else

		if freelook then
			cmd:SetViewAngles( normalizeViewAngle( freelook ) )
			freelook = nil
		end

		PLUGIN.current_target = nil

	end

	if c and PLUGIN.config.nospread and bit.band( cmd:GetButtons(), IN_ATTACK ) > 0 then
		if not current_target then
			local mousefix = Angle()
			mousefix.p = cmd:GetMouseY() * GetConVarNumber( "m_pitch" )
			mousefix.y = cmd:GetMouseX() * GetConVarNumber( "m_yaw" ) * -1

			if not uncorrected then
				uncorrected = cmd:GetViewAngles()
			end

			if not ignore_turn then
				uncorrected = uncorrected + mousefix
				uncorrected.r = 0
			end
		end

		local aimangles = control.isDown( PLUGIN.config.aimbot_key ) and IsValid( PLUGIN.current_target ) and cmd:GetViewAngles() or uncorrected

		cmd:SetViewAngles( aimangles )
		local antispread = PLUGIN.PredictSpread( cmd, aimangles )
		cmd:SetViewAngles( normalizeViewAngle( antispread ) )
	elseif PLUGIN.config.norecoil and ( bit.band( cmd:GetButtons(), IN_ATTACK ) > 0 or can_turbofire ) then
		if not norecoil then
			norecoil = cmd:GetViewAngles()
			norecoil.r = 0
		elseif not ignore_turn then
			norecoil.p = norecoil.p + cmd:GetMouseY() * GetConVarNumber( "m_pitch" )
			norecoil.y = norecoil.y + cmd:GetMouseX() * GetConVarNumber( "m_yaw" ) * -1
			norecoil.r = 0
			cmd:SetViewAngles( normalizeViewAngle( norecoil ) )
		end
	elseif norecoil then
		cmd:SetViewAngles( normalizeViewAngle( norecoil ) )
		norecoil = nil
	elseif bit.band( cmd:GetButtons(), IN_ATTACK ) == 0 and uncorrected then
		cmd:SetViewAngles( normalizeViewAngle( uncorrected ) )
		uncorrected = nil
	end

	if LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP and ( uncorrected or PLUGIN.config.freelook and freelook ) then

		local correction = freelook or uncorrected

		local vecMove = Vector()
		vecMove.x = cmd:GetForwardMove()
		vecMove.y = cmd:GetSideMove()
		vecMove.z = cmd:GetUpMove()

		local angDiff = cmd:GetViewAngles() - correction
		angDiff.p = 0

		vecMove:Rotate( angDiff )

		cmd:SetForwardMove( vecMove.x )
		cmd:SetSideMove( vecMove.y )
		cmd:SetUpMove( vecMove.z )

	end

end

local ignore = false
function PLUGIN.CalcView( ply, origin, angles, fov )

	if ignore then
		return 
	end

	if not ( PLUGIN.config.freelook and freelook ) and not uncorrected and not PLUGIN.config.noviewpunch then
		return
	end

	angles = ( freelook or uncorrected or ply:GetAimVector():Angle() ) * 1

	ignore = true
	local view = _G.hook.Call( "CalcView", GAMEMODE, ply, origin, angles, fov )
	ignore = false

	return view

end

PLUGIN.RegisterWeaponSpread( "weapon_sh_base", function( weapon )

	if not weapon:GetIronsights() then
		local stance = weapon.Owner:IsOnGround() and weapon.Owner:Crouching() and 10
			or !weapon.Sprinting and weapon.Owner:IsOnGround() and 15
			or weapon.Walking and weapon.Owner:IsOnGround() and 20
			or !weapon.Owner:IsOnGround() and 25
			or weapon.Primary.Ammo == "buckshot" and 0
		local weptype = weapon.Sniper and 8 or weapon.SMG and 2 or weapon.Pistol and 2 or weapon.Primary.Ammo == "buckshot" and 0 or 1.6
		local shotgun = weapon.Primary.Ammo == "buckshot" and weapon.Primary.Cone or 0
		return weapon.Primary.Cone * weapon.Primary.Recoil * stance * weptype + shotgun
	end

end )

PLUGIN.RegisterWeaponSpread( "weapon_mor_base", function( weapon )

	if weapon:GetIronsights() == true and weapon.Owner:KeyDown( IN_ATTACK2 ) then
		return weapon.Primary.Cone / 2
	else
		return weapon.Primary.Cone
	end

end )

PLUGIN.RegisterWeaponSpread( "weapon_zs_base", function( weapon )

	return weapon.GetCone and weapon:GetCone()

end )

PLUGIN.RegisterWeaponSpread( "weapon_dod_sim_base", function( weapon )

	local AccuracyMul = GetConVar( "sim_accuracymul" )

	local Speed = weapon.Owner:GetVelocity():Length()
	local SpeedClamp = math.Clamp( math.abs( Speed / 705 ), 0, 1 )

	if not weapon.Owner:IsOnGround() then
		if weapon:GetDTBool( 1 ) or weapon:GetDTBool( 2 ) then
			return weapon.Primary.Cone * AccuracyMul:GetFloat() * (((1 - SpeedClamp) + 0.1) / 2)
		else
			return weapon.Primary.Cone * AccuracyMul:GetFloat() * 3 * (((1 - SpeedClamp) + 0.1) / 2) 
		end
	elseif weapon.Owner:KeyDown( bit.bor( IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT ) ) then
		if weapon:GetDTBool( 1 ) or weapon:GetDTBool( 2 ) then
			return weapon.Primary.Cone * AccuracyMul:GetFloat()
		elseif Speed > 10 then
			return weapon.Primary.Cone * 2 * AccuracyMul:GetFloat()
		else
			return weapon.Primary.Cone * 1.5 * AccuracyMul:GetFloat()
		end
	elseif weapon.Owner:Crouching() then
		if weapon:GetDTBool( 1 ) or weapon:GetDTBool( 2 ) then
			return weapon.Primary.Cone * AccuracyMul:GetFloat()
		else
			return weapon.Primary.Cone * 1.5 * AccuracyMul:GetFloat()
		end
	else
		if weapon:GetDTBool( 1 ) or weapon:GetDTBool( 2 ) then
			return weapon.Primary.Cone * AccuracyMul:GetFloat()
		else
			return weapon.Primary.Cone * 2 * AccuracyMul:GetFloat()
		end
	end

end )