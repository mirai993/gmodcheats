--[[
	bluejay/plugins/clockwork.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Clockwork"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local unitstometers = 0.01905

function PLUGIN.PluginStartup()

	local esp = plugins.get( "ESP" )

	if not esp then return end

	esp.RegisterEntityInfo( "cw_item", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent.GetItemTable then return end
		local data = ent:GetItemTable()
		if not data then return end

		local info = {}

		local distance = math.ceil( ent:GetPos():Distance( LocalPlayer():GetShootPos() ) )

		table_insert( info, { Color( 220, 150, 25, 50 ), data.name .. " - " .. ( data.weight or 0 ) .. "kg" } )
		table_insert( info, { distance <= 80 and Color( 255, 255, 255, 255 ) or Color( 100, 100, 100, 50 ), distance } )

		return info

	end )

	esp.RegisterEntityInfo( "cw_paper", function( ent )

		if not PLUGIN.config.enabled then return end

		local info = {}

		table_insert( info, { Color( 200, 65, 20, 200 ), "Paper" } )

		return info

	end )

	esp.RegisterEntityInfo( "cw_salesman", function( ent )

		if not PLUGIN.config.enabled then return end

		local info = {}

		local name = ent:GetNetworkedString( "Name" ) or "Unknown Salesman"

		table_insert( info, { Color( 200, 20, 100, 200 ), name } )

		return info

	end )

	esp.RegisterEntityInfo( "player", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent:Alive() then return end
		if not GAMEMODE or GAMEMODE.Name ~= "Clockwork" then return end

		local talk = Clockwork.config:Get( "talk_radius" ):Get()
		local yell = talk * 2
		local whisper = math.min( talk / 3, 80 )

		local info = {}

		table_insert( info, ent:SteamName() )

		local distance = math.ceil( ent:GetPos():Distance( LocalPlayer():GetShootPos() ) )
		table_insert( info, { distance <= 80 and Color( 255, 255, 255, 255 ) or Color( 100, 100, 100, 255 ), distance } )

		if distance <= whisper then
			table_insert( info, { Color( 150, 150, 150, 200 ), "[whisper range]" } )
		elseif distance <= talk then
			table_insert( info, { Color( 150, 200, 150, 200 ), "[talk range]" } )
		elseif distance <= yell then
			table_insert( info, { Color( 200, 150, 150, 255 ), "[yell range]" } )
		end

		return info

	end )

end