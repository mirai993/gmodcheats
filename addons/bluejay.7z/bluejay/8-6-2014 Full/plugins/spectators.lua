--[[
	bluejay/plugins/spectators.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Spectator List"

function PLUGIN.HUDPaint()

	local x, y = 50, 75
	surface.SetFont( "Bluejay18" )
	
	surface.SetTextColor( 0, 0, 0, 255 )
	surface.SetTextPos( x+1, y+1 )
	surface.DrawText( "Spectating:" )
	surface.SetTextColor( 255, 255, 255, 255 )
	surface.SetTextPos( x, y )
	surface.DrawText( "Spectating:" )
	local tx, ty = surface.GetTextSize( "Spectating:" )
	y = y + ty + 5

	for k, v in pairs( player.GetAll() ) do
		if v:GetObserverTarget() then
			local text = tostring( v ) .. " -> " .. tostring( v:GetObserverTarget() )
			surface.SetTextColor( 0, 0, 0, 255 )
			surface.SetTextPos( x+1 + 10, y+1 )
			surface.DrawText( text )
			if v:GetObserverTarget() == LocalPlayer() then
				surface.SetTextColor( 255, 0, 0, 255 )
			else
				surface.SetTextColor( 150, 150, 150, 255 )
			end
			surface.SetTextPos( x + 10, y )
			surface.DrawText( text )
			local tx, ty = surface.GetTextSize( text )
			y = y + ty + 5
		end
	end

end