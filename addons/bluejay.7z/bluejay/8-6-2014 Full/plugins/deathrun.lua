--[[
	bluejay/plugins/deathrun.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Deathrun"

function PLUGIN.Think()

	if not GAMEMODE or GAMEMODE.Name ~= "Deathrun" then return end

	for _, ent in pairs( ents.FindByClass( "func_breakable" ) ) do
		ent:SetColor( Color( math.sin( CurTime() * 10 ) * 100 + 155, 0, 0, 50 ) )
	end

	for _, ent in pairs( ents.FindByClass( "func_door" ) ) do
		ent:SetColor( Color( 0, math.sin( CurTime() * 10 ) * 100 + 155, 0, 50 ) )
	end

	for _, ent in pairs( ents.FindByClass( "func_door_rotating" ) ) do
		ent:SetColor( Color( 0, 0, math.sin( CurTime() * 10 ) * 100 + 155, 50 ) )
	end

	for _, ent in pairs( ents.FindByClass( "func_movelinear" ) ) do
		ent:SetColor( Color( 0, math.sin( CurTime() * 10 ) * 100 + 155, 0, 50 ) )
	end

end

--[[net.Start( "sgn_jumptime" )
	net.WriteString( tostring( "fluffy nipples?" ) )
	net.WriteString( tostring( "blue shoesies" ) )
net.SendToServer()]]