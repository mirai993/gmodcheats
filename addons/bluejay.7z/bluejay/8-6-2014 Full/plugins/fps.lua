--[[
	bluejay/plugins/fps.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "FPS Counter"

function PLUGIN.DrawShadedText( text, color, x, y )
	
	surface.SetTextColor( Color( 0, 0, 0, 255 ) )
	surface.SetTextPos( x + 1, y + 1 )
	surface.DrawText( text )

	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )

end

local last_call = RealTime()

function PLUGIN.PostRender()

	local fps = 1 / ( RealTime() - last_call )
	local ping = LocalPlayer() and LocalPlayer():Ping() or 0

	local y = 20

	cam.Start2D()

		surface.SetFont( "Bluejay13" )

		local text = os.date( "%H:%M" )
		local tw, th = surface.GetTextSize( text )
		PLUGIN.DrawShadedText( text, Color( 255, 255, 255, 255 ), ScrW() - 20 - tw, y )
		y = y + th

		local p = 1 - math.Clamp( fps / 60, 0, 1 )
		local c = p * 255
		local text = math.floor( fps )
		local tw, th = surface.GetTextSize( text )
		PLUGIN.DrawShadedText( text, Color( 255, 255 - c, 255 - c, 255 ), ScrW() - 20 - tw, y )
		y = y + th

		local p = math.Clamp( ( ping - 75 ) / 75, 0, 1 )
		local c = p * 255
		local text = math.floor( ping )
		local tw, th = surface.GetTextSize( text )
		PLUGIN.DrawShadedText( text, Color( 255, 255 - c, 255 - c, 255 ), ScrW() - 20 - tw, y )
		y = y + th

	cam.End2D()

	last_call = RealTime() * 0.9 + last_call * 0.1 -- Dampens the change in fps

end