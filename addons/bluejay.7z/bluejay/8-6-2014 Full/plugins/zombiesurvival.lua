--[[
	bluejay/plugins/zombiesurvival.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Zombie Survival"

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

function PLUGIN.PluginStartup()

	local esp = plugins.get( "ESP" )

	if not esp then return end

	esp.RegisterEntityInfo( "prop_nail", function( ent )

		if not PLUGIN.config.enabled then return end

		if not ent.GetNailHealth or not ent.GetMaxNailHealth then return end

		local info = {}

		local health = math.ceil( ent:GetNailHealth() ).." / "..math.ceil( ent:GetMaxNailHealth() )

		

		table_insert( info, { Color( 255, 255, 255, 150 ), health } )

		return info

	end )

end