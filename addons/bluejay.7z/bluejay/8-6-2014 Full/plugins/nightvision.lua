--[[
	bluejay/plugins/nightvision.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "Night Vision"

function PLUGIN.RenderScene()

	local td = {}
	td.start = LocalPlayer():GetShootPos()
	td.endpos = td.start + LocalPlayer():GetAimVector() * 150

	local tr = util.TraceLine( td )

	local light = DynamicLight( LocalPlayer():EntIndex() )
	light.Brightness = 2
	light.Decay = 0
	light.DieTime = CurTime() + FrameTime() * 20
	light.Dir = LocalPlayer():GetAimVector()
	light.InnerAngle = 10
	light.OuterAngle = 30
	light.Size = 400

	light.r = 1
	light.g = 1
	light.b = 1

	light.Pos = tr.HitPos

end

function PLUGIN.RenderScreenspaceEffects()
	
	local t = {}
	t[ "$pp_colour_addr" ] = 0
	t[ "$pp_colour_addg" ] = 0.15
	t[ "$pp_colour_addb" ] = 0
	t[ "$pp_colour_brightness" ] = 0.025
	t[ "$pp_colour_contrast" ] = 1.5
	t[ "$pp_colour_colour" ] = 0
	t[ "$pp_colour_mulr" ] = 0
	t[ "$pp_colour_mulg" ] = 0
	t[ "$pp_colour_mulb" ] = 0

	DrawColorModify( t )

end