--[[
	bluejay/plugins/ecu.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "ECU"

local function DrawOutlinedText( text, color, x, y, outlinewidth )

	outlinewidth = outlinewidth or 1
	local steps = math.ceil( outlinewidth * 2 / 3 )

	surface.SetTextColor( Color( 0, 0, 0, 255 ) )

	for ox = -outlinewidth, outlinewidth, steps do
		for oy = -outlinewidth, outlinewidth, steps do
			surface.SetTextPos( x + ox, y + oy )
			surface.DrawText( text )
		end
	end

	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )

end

local texGradient = surface.GetTextureID( "gui/gradient" )
local texGradientDown = surface.GetTextureID( "gui/gradient_down" )

local function DrawVariable( x, y, w, h, data, value )

	if data.max then
		local min = data.min or 0

		local p = math.Clamp( ( value - min ) / ( data.max - min ), 0, 1 )

		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawRect( x, y, w, h )

		surface.SetDrawColor( 50, 50, 50, 255 )
		surface.DrawRect( x + 1, y + 1, w - 2, h - 2 )

		surface.SetTexture( texGradient )
		surface.SetDrawColor( 0, 0, 0, 255 )
		--surface.DrawTexturedRectUV( x + 1 + ( w - 2 ) * p, y + 1, w - ( w - 2 ) * p, h - 2, 0, 0, 1, 1 )

		surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
		surface.DrawRect( x + 1, y + 1, ( w - 2 ) * p, h - 2 )

		surface.SetTexture( texGradient )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawTexturedRectUV( x + 1, y + 1, ( w - 2 ) * p, h - 2, 0, 0, 1, 1 )

		DrawVariable( x, y, w, h, {name=data.name}, value )
	else
		local text = tostring( value )
		if type( value ) == "number" then
			text = string.format( "%.2f", value )
		end

		local tw, th = surface.GetTextSize( text )
		DrawOutlinedText( text, Color( 255, 255, 255, 255 ), x + w - tw - 10, y + h / 2 - th / 2 )

		DrawOutlinedText( data.name or "", Color( 255, 255, 255, 255 ), x + 10, y + h / 2 - th / 2 )
	end

end

local ecu_env_meta = {}
local ecu_env = setmetatable( {__index = PLUGIN.config}, ecu_env_meta )

ecu_env.print = print
ecu_env.math = math
ecu_env.string = string

local variables = {}
function ecu_env.register( name, value, min, max )
	ecu_env[ name ] = value

	variables[ #variables + 1 ] = {
		name = name,
		min = min,
		max = max,
	}
end

function ecu_env.registerl( name, value )
	ecu_env[ name ] = value
end

local current_time = 0
local TIMESCALE = 60 / 6000
local function time()
	return current_time--SysTime() * ( 1 / ( PLUGIN.config.timescale or 1 ) )
end

local function millis()
	return time() * 1000
end

local function micros()
	return millis() * 1000
end

ecu_env.time = time
ecu_env.millis = millis
ecu_env.micros = micros

function PLUGIN.LoadECU()

	local func = bluejay.c.compile( "bluejay/ecu.lua" )

	if not func then
		error( "Failed to include " .. tostring( path ) )
		return false
	end

	setfenv( func, ecu_env )

	local s, e = pcall( func )
	if not s then
		error( e )
		return false
	end

	ecu_env.setup()
	ecu_env.crankpulse()
	ecu_env.campulse()

	return ecu_env

end

PLUGIN.LoadECU()

local NUM_CYLINDERS = 6

local RPM = 6000
local crankDegrees = 0
local camDegrees = 0

local lastcall = time()
local last_time = SysTime()
function PLUGIN.HUDPaint()

	current_time = current_time + ( SysTime() - last_time ) * ( 1 / ( PLUGIN.config.timescale or 1 ) )
	last_time = SysTime()

	--RPM = 5000 + math.sin( SysTime() ) * 3000

	surface.SetDrawColor( 25, 25, 25, 255 )
	surface.DrawRect( 0, 0, ScrW(), ScrH() )

	local delta = time() - lastcall
	lastcall = time()

	if crankDegrees + RPM / 60 * 360 * delta >= 360 then
		ecu_env.crankpulse()
	end

	if camDegrees + RPM / 60 / 2 * 360 * delta >= 360 then
		ecu_env.campulse()
	end

	crankDegrees = ( crankDegrees + RPM / 60 * 360 * delta ) % 360
	camDegrees = ( camDegrees + RPM / 60 / 2 * 360 * delta ) % 360

	if not ecu_env.loop then
		return
	end

	ecu_env.loop()

	surface.SetFont( "Bluejay12" )

	local x, y, w, h = 20, 20, 200, 20
	for k, data in ipairs( variables ) do
		DrawVariable( x, y, w, h, data, ecu_env[ data.name ] )

		y = y + h * 1.5
	end

	local x, y = ScrW() / 2 - ( NUM_CYLINDERS * 30 - 10 ) / 2, ScrH() / 2
	surface.SetDrawColor( 255, 255, 255, 200 )
	surface.DrawRect( x-10, y-60, NUM_CYLINDERS * 30 + 10, 140 )
	for i=0, NUM_CYLINDERS - 1 do
		local cx = x + i * 30

		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawRect( cx-1, y - 51, 22, 121 )

		local tw, th = surface.GetTextSize( i + 1 )
		DrawOutlinedText( i + 1, Color( 255, 255, 255, 255 ), cx + 10 - tw / 2, y - 65 - th )

		local offset = 360 / NUM_CYLINDERS * i
		local camdegress = ( camDegrees - offset / 2 ) % 360
		local crankdegrees = ( crankDegrees - offset ) % 360
		local p = math.cos( math.rad( crankdegrees ) )

		surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
		surface.DrawRect( cx, y - p * 50, 20, 20 )

		local color = Color( 255, 255, 255, 100 )
		if camdegress <= 180 then
			-- Compression stroke
			local pp = math.Clamp( crankdegrees / 180, 0, 1 )
			local p = math.Clamp( crankdegrees / 180 - 1, 0, 1 )

			color.a = 255 * pp
			color.r = 150 - p * 150
			color.g = 255
			color.b = 255 - p * 255
		else
			-- Exhaust Stroke
			local p = math.Clamp( crankdegrees / 180 - 1, 0, 1 )
			color.r = 255
			color.g = p * 255
			color.b = p * 255
			color.a = 255 - p * 255
		end
		surface.SetDrawColor( color )
		surface.DrawRect( cx, y - 50, 20, 50 - p * 50 )

		surface.SetTexture( texGradient )
		surface.SetDrawColor( 0, 0, 0, 100 )
		surface.DrawTexturedRectUV( cx, y - 50, 10, 50 - p * 50, 0, 0, 1, 1 )
		surface.DrawTexturedRectUV( cx + 10, y - 50, 10, 50 - p * 50, 1, 0, 0, 1 )

		surface.SetDrawColor( 150, 150, 150, 255 )
		surface.DrawRect( cx + 5, y - p * 50 + 20, 10, 50 + p * 50 )

		surface.SetTexture( texGradientDown )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawTexturedRect( cx + 5, y - p * 50 + 20, 10, 50 + p * 50 )
	end

	DrawVariable( x, y + 85, NUM_CYLINDERS * 30 - 10, 20, {max=360}, crankDegrees )
	DrawVariable( x, y + 105, NUM_CYLINDERS * 30 - 10, 20, {max=360}, camDegrees )

	DrawVariable( x, y + 125, NUM_CYLINDERS * 30 - 10, 20, {}, RPM )

end

local ignore_hud = {
	"CHudHealth",
	"CHudSuitPower",
	"CHudBattery",
	"CHudCrosshair",
	"CHudAmmo",
	"CHudSecondaryAmmo",
	"CHudDamageIndicator",
}

function PLUGIN.HUDShouldDraw( element )
	for _, v in pairs( ignore_hud ) do
		if v == element then
			return false
		end
	end
end

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "ECU", "BPanelList" )

	tab:SetSpacing( 3 )

	tab:Label( "Timescale (1/x)" )
	tab:Slider( 1, 1000, PLUGIN, "timescale" )

	tab:Label( "Throttle" )
	tab:Slider( 0, 100, PLUGIN, "throttle" )

end