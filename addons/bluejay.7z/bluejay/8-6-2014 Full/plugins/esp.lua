--[[
	bluejay/plugins/esp.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local PLUGIN = plugins.register "ESP"

import "debug"

--print( debug.getinfo( _G.hook.Call ) )

import "surface"
import "player"
import "Color"
import "LocalPlayer"
import "ents"

function PLUGIN.PluginCreateVGUI( menu_panel )

	local tab = menu_panel:AddTab( "ESP", "BPanelList" )

	tab:SetSpacing( 3 )

end

local ignore = false

local matBlack = CreateMaterial( "VisorBlack", "UnlitGeneric", { [ "$basetexture" ] = "vgui/black", ["$alpha"] = 1 } )

function PLUGIN.PostDrawTranslucentRenderables()

	for _, ply in ipairs( player.GetAll() ) do

		if IsValid( ply ) and ply ~= LocalPlayer() and ply:Alive() then

			render.OverrideDepthEnable( true, false )

			render.ClearStencil()
			render.SetStencilEnable( true )
			render.SetStencilFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilPassOperation( STENCILOPERATION_KEEP )
			render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
			render.SetStencilWriteMask( 1 )
			render.SetStencilTestMask( 1 )
			render.SetStencilReferenceValue( 1 )
			render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )

			render.SetBlend( 0 )
				ply:DrawModel()
			render.SetBlend( 1 )

			render.SetStencilFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilPassOperation( STENCILOPERATION_ZERO )
			render.SetStencilZFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilReferenceValue( 1 )
			render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )

			render.SetBlend( 0 )
				ply:DrawModel()
			render.SetBlend( 1 )

			render.SetStencilFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilPassOperation( STENCILOPERATION_KEEP )
			render.SetStencilZFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilReferenceValue( 1 )
			render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )

			cam.Start2D()
				local color = team.GetColor( ply:Team() ) or Color( 255, 255, 255, 255 )
				surface.SetDrawColor( color )
				surface.DrawRect( 0, 0, ScrW(), ScrH() )
			cam.End2D()

			render.ClearStencil()
			render.SetStencilEnable( false )
			render.OverrideDepthEnable( false )

		end

	end

end

local entity_info = {}

local function table_insert( tbl, data )

	tbl[ #tbl + 1 ] = data

end

local function table_append( tbl, append )

	if not append then return end

	for _, v in ipairs( append ) do
		tbl[ #tbl + 1 ] = v
	end

end

function PLUGIN.DrawShadedText( text, color, x, y )
	surface.SetTextColor( Color( 0, 0, 0, 255 ) )
	surface.SetTextPos( x + 1, y + 1 )
	surface.DrawText( text )

	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )
end

function PLUGIN.DrawOutlinedText( text, color, x, y, outlinewidth )

	outlinewidth = outlinewidth or 1
	local steps = math.ceil( outlinewidth * 2 / 3 )

	surface.SetTextColor( Color( 0, 0, 0, 255 ) )

	for ox = -outlinewidth, outlinewidth, steps do
		for oy = -outlinewidth, outlinewidth, steps do
			surface.SetTextPos( x + ox, y + oy )
			surface.DrawText( text )
		end
	end

	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )

end

function PLUGIN.RegisterSimpleEntity( identifier )

	PLUGIN.RegisterEntityInfo( identifier, function( ent )

		return { ent:GetClass() }

	end )

end

function PLUGIN.RegisterEntityInfo( identifier, func )

	entity_info[ identifier ] = entity_info[ identifier ] or {}

	local data = entity_info[ identifier ]

	data[ #data + 1 ] = func

end

function PLUGIN.GetEntityInfoByIdentifier( identifier, ent )

	local info = {}

	if not entity_info[ identifier ] then return info end

	for identifier, data in pairs( entity_info ) do
		if identifier:find( "%*" ) then
			local search = identifier:gsub( "*", ".+" )
			if ent:GetClass():find( search ) then

				for _, func in ipairs( data ) do

					table_append( info, func( ent ) or {} )

				end

			end
		end
	end

	for _, func in ipairs( entity_info[ identifier ] ) do

		table_append( info, func( ent ) or {} )

	end

	return info

end

function PLUGIN.GetEntityInfo( ent )

	local info = {}

	for indentifier, funcs in pairs( entity_info ) do
		if type( identifier ) == "function" then
			if identifier( ent ) then
				table_append( info, PLUGIN.GetEntityInfoByIdentifier( identifier, ent ) )
			end
		end
	end

	table_append( info, PLUGIN.GetEntityInfoByIdentifier( ent, ent ) )
	table_append( info, PLUGIN.GetEntityInfoByIdentifier( ent:GetClass(), ent ) )

	return info

end

function PLUGIN.GetEntityInfoPosition( ent )

	if ent:IsPlayer() then
		return ent:GetShootPos() + Vector( 0, 0, 10 )
	end

	return ent:LocalToWorld( ent:OBBCenter() )

end

function PLUGIN.ShouldDrawEntityInfo( ent )

	if not IsValid( ent ) then return false end

	local dot = ( ent:GetPos() - EyePos() ):GetNormal():Dot( EyeAngles():Forward() )
	if dot < 0.5 then
		return false
	end

	return true

end

local sizecache = {}
function PLUGIN.GetTextSize( font, text )
	sizecache[ font ] = sizecache[ font ] or {}
	local fontcache = sizecache[ font ]

	if fontcache[ text ] then
		return unpack( fontcache[ text ] )
	end

	surface.SetFont( font )
	fontcache[ text ] = { surface.GetTextSize( text ) }

	return unpack( fontcache[ text ] )
end

local surface = surface

function PLUGIN.DrawEntityInfo( ent )

	if not PLUGIN.ShouldDrawEntityInfo( ent ) then return end

	local pos = PLUGIN.GetEntityInfoPosition( ent ):ToScreen()
	local info = PLUGIN.GetEntityInfo( ent )

	local y = pos.y

	for i=#info, 1, -1 do

		local data = info[ i ]
		local line = ""
		local color = Color( 255, 255, 255, 255 )

		local t = type( data )

		if t == "table" then
			color = data[ 1 ]
			line = data[ 2 ]
		else
			line = tostring( data )
		end

		if line then

			local p = Vector( pos.x, y ):Distance( Vector( ScrW()/2, ScrH()/2 ) ) / Vector( ScrW()/2, ScrH()/2 ):Length()
			local size = 11--math.Round( math.Clamp( p * 3 + 11, 8, 17 ) )

			surface.SetAlphaMultiplier( p * 0.5 + 0.5 )

			--color.a = color.a * ( p * 0.85 + 0.15 )

			surface.SetFont( "Bluejay" .. size )
			local tw, th = PLUGIN.GetTextSize( "Bluejay" .. size, line )

			PLUGIN.DrawOutlinedText( line, color, pos.x - math.floor( tw / 2 ), y - th )

			y = y - math.floor( th * 0.9 )

		end

	end

	surface.SetAlphaMultiplier( 1 )

end

function PLUGIN.HUDPaint()

	cam.Start2D()

		for _, ent in ipairs( ents.GetAll() ) do
			if IsValid( ent ) and not ent:IsPlayer() then
				PLUGIN.DrawEntityInfo( ent )
			end
		end

		--[[for identifier, _ in pairs( entity_info ) do
			if type( identifier ) == "string" and identifier ~= "player" then
				for _, ent in pairs( ents.FindByClass( identifier ) ) do
					PLUGIN.DrawEntityInfo( ent )
				end
			end
		end]]

		for _, ply in pairs( player.GetAll() ) do
			if ply ~= LocalPlayer() then
				PLUGIN.DrawEntityInfo( ply )
			end
		end
	cam.End2D()

	--[[for _, ply in ipairs( player.GetAll() ) do
		cam.IgnoreZ( true )
			--render.SuppressEngineLighting( true )
				--ply:DrawModel()
			--render.SuppressEngineLighting( false )
		cam.IgnoreZ( false )
	end]]

end

PLUGIN.RegisterEntityInfo( "player", function( ent )

	if not ent:Alive() then return end

	local info = {}

	local color = team.GetColor( ent:Team() ) or Color( 255, 255, 255, 255 )
	table_insert( info, { color, ent:Nick() } )

	local rank = utility.getrank( ent )
	if rank then
		table_insert( info, "(" .. tostring( rank ) .. ")" )
	end

	local hp = math.max( ent:Health(), 0 )
	local p = math.max( math.min( hp / 100, 1 ), 0 )

	table_insert( info, { Color( 255 * (1-p), 255 * p, 0, 255 ), hp } )

	return info

end )

PLUGIN.RegisterEntityInfo( "zweap_*", function( ent )

	local info = {}

	table_insert( info, ent:GetClass() )

	return info

end )

function PLUGIN.Think()
	for _, ent in pairs( ents.FindByClass( "cw_item" ) ) do
		local distance = math.ceil( ent:GetPos():Distance( LocalPlayer():GetShootPos() ) )
		if distance <= 80 then
			--Clockwork.datastream:Start("EntityMenuOption", {ent, "Take", "cwItemTake"})
		end
	end
end