--[[
	bluejay/core/detour.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

detour = detour or {}
detour.PASS = detour.PASS or {}

detour.functions = detour.functions or {}

detour._detours = detour._detours or {}
detour._modReal = detour._modReal or {}
detour._modInit = detour._modInit or {}
detour._modSpoof = detour._modSpoof or {}

local _detours = detour._detours
local _modReal = detour._modReal
local _modInit = detour._modInit
local _modSpoof = detour._modSpoof

function detour.func( tbl, func, new, dontUpdate )

	local k, data = detour.get( tbl, func )

	if not k and not data then
		k, data = detour.get( tbl[ func ] )
	end

	if data then

		if data.tbl[ data.name ] ~= data.func then
			debugprint( utility.getobjectpath( data.tbl ) .. "['" .. tostring( data.name ) .. "'] does not match records." )
			data.new = new

			return false
		else
			debugprint( utility.getobjectpath( tbl ) .. "['" .. tostring( func ) .. "'] redefined" )
			data.new = new

			return false
		end

	end

	local old = tbl[ func ]
	if not old then
		debugprint( utility.getobjectpath( tbl ) .. "['" .. tostring( func ) .. "'] no such member!" )
		return false
	end

	local data = {}
	data.tbl = tbl
	data.name = func
	data.new = new
	data.old = old
	data.shouldupdate = not dontUpdate

	local replacement = function( ... )
		local ret = { pcall( data.new, data.old, ... ) }
		if ret[ 1 ] and ret[ 2 ] ~= detour.PASS then
			local highest = 0
			for key, _ in pairs( ret ) do
				if highest < key then
					highest = key
				end
			end
			return unpack( ret, 2, highest )
		else
			local b, err = pcall( data.old, ... )
			if not b then
				local name = func

				local locals = getlocals( 2 )
				for k, localinfo in pairs( locals ) do
					if localinfo.value == data.func and localinfo.name then
						name = localinfo.name
					end
				end

				local upvalues = getupvalues( 2 )
				for k, upvalueinfo in pairs( upvalues ) do
					if upvalueinfo.value == data.func and upvalueinfo.name then
						name = upvalueinfo.name
					end
				end

				err = err:gsub( "'%?'", "'" .. name .. "'" )

				local info = debug.getinfo( data.old )
				local source = info.source

				luaerror( err, source == "=[C]" and 2 or 0 )
			elseif not ret[ 1 ] then
				error( "Detour function " .. utility.getobjectpath( tbl ) .. "['" .. tostring( func ) .. "'] errored: " .. tostring( ret[ 2 ] ), 0 )
			end
		end
	end

	detour.functions[ replacement ] = old

	data.func = replacement
	_detours[ #_detours + 1 ] = data

	rawset( tbl, func, replacement )

	return new, data

end

function detour.fallback( tbl, func, new )

	local k, data = detour.get( tbl[ func ] )

	if data then
		data.new = new
		return
	end

	local old = tbl[ func ]
	if not old then
		return
	end

	local data = {}
	data.tbl = tbl
	data.name = func
	data.new = new
	data.old = old

	local replacement = function( ... )
		local ret = { pcall( data.new, data.old, ... ) }
		if ret[ 1 ] and ret[ 2 ] ~= detour.PASS then
			local heighest = 0
			for key, _ in pairs( ret ) do
				if heighest < key then
					heighest = key
				end
			end
			return unpack( ret, 2, heighest )
		else
			local b, err = pcall( data.old, ... )
			if not b then
				local name = func

				local locals = getlocals( 2 )
				for k, localinfo in pairs( locals ) do
					if localinfo.value == data.func and localinfo.name then
						name = localinfo.name
					end
				end

				local upvalues = getupvalues( 2 )
				for k, upvalueinfo in pairs( upvalues ) do
					if upvalueinfo.value == data.func and upvalueinfo.name then
						name = upvalueinfo.name
					end
				end

				err = err:gsub( "'%?'", "'" .. name .. "'" )

				local info = debug.getinfo( data.old )
				local source = info.source

				luaerror( err, source == "=[C]" and 2 or 0 )
			elseif not ret[ 1 ] then
				error( "Detour function " .. utility.getobjectpath( tbl ) .. "['" .. tostring( func ) .. "'] errored: " .. tostring( ret[ 2 ] ), 0 )
			end
		end
	end

	detour.functions[ replacement ] = old

	data.func = replacement
	_detours[ #_detours + 1 ] = data

	rawset( tbl, func, replacement )

	utility.setreferences( old, hookreplacement )

end

function detour.onModule( module_name, identifier, func )

	_modInit[ module_name ] = _modInit[ module_name ] or {}

	_modInit[ module_name ][ identifier ] = func

	if _G[ module_name ] then
		func()
	end

end

function detour.module( module_name, func, new )

	_modSpoof[ module_name ] = _modSpoof[ module_name ] or {}

	_modSpoof[ module_name ][ func ] = new

	if _G[ module_name ] and _G[ module_name ][ func ] then
		local k, data = detour.get( _G[ module_name ][ func ] )
		if data then
			data.new = new
		end
	end

end


function detour.getAll()
	return _detours
end

function detour.get( tbl, name )
	if type( tbl ) == "number" then
		return tbl, _detours[ tbl ]
	end

	local func = type( tbl ) == "function" and tbl

	for k, data in pairs( _detours ) do
		if func and data.func == func or not func and data.tbl == tbl and data.name == name then
			return k, data
		end
	end
end

function detour.remove( ... )

	local index, data = detour.get( ... )
	if data then
		debugprint( "Removing detour " .. utility.getobjectpath( data.tbl ) .. "['" .. tostring( data.name ) .. "']..." )

		data.new = function() return end
		data.tbl[ data.name ] = data.old

		detour.unregister( index )
	end

end

function detour.unregister( ... )

	local index, data = detour.get( ... )
	if data then
		for k, v in pairs( _detours ) do
			if k > index then
				_detours[ k - 1 ] = v
			end
		end

		_detours[ #_detours ] = nil
	end

end

function detour.unregisterTable( tab )

	for index, data in pairs( _detours ) do

		if data.tbl == tab then
			detour.unregister( index )
		end

	end

end

function detour.update_all()
	for k, v in pairs( _detours ) do
		if v.shouldupdate and v.tbl[ v.name ] ~= v.func then
			local func = v.tbl[ v.name ]
			if type( func ) ~= "function" then
				continue
			end
			local info = debug.getinfo( func  )
			if info then
				debugprint( utility.getobjectpath( v.tbl ) .. "." .. tostring( v.name ) .. " was detoured by " .. tostring( info.source ) .. "\n\t\t\tre-detouring now." )
			end
			if detour.update( v.tbl, v.name ) then
				debugprint( "\t\t\tsuccess" )
			else
				debugprint( "\t\t\tfailed" )
			end
		end
	end
end

function detour.unload()
	for _, data in pairs( _detours ) do
		data.tbl[ data.name ] = data.old
	end
end

local function handleModule( name, tab )

	local spoof = _modSpoof[ name ]
	local oninit = _modInit[ name ]

	if spoof then

		for key, func in pairs( spoof ) do

			debugprint( "detouring module " .. tostring( name ) .. "." .. tostring( key ) )
			detour.fallback( tab, key, func )
			--detour.func( tab, key, func, true )

		end

	end

	if oninit then

		for key, func in pairs( oninit ) do

			local r = { func( name, tab ) }
			if #r > 0 then
				return unpack( r )
			end

		end

	end

	return tab

end

detour.func( _G, "require", function( old, name, ... )

	if _G.package.loaded[ name ] then
		return _G.package.loaded[ name ]
	end

	local registry = debug.getregistry()

	local spoof = _modSpoof[ name ]
	local init = _modInit[ name ]
	local ret = old( name, ... ) or registry._LOADED[ name ] or _G.package.loaded[ name ] or _G[ name ]

	if type( ret ) ~= "table" then
		return ret
	end

	_modReal[ name ] = {}
	for k, v in pairs( ret ) do
		_modReal[ name ][ k ] = v
	end

	handleModule( name, ret )

	return ret

end )

-- Some people have custom hook scripts, e.g. metaconstruct, ulib, etc

local module_overrides = {
	--{ "hook", "includes/ac.lua" },
	{ "hook", "ulib/shared/hook.lua" },
	{ "hook", "bluejay/bluejay_hook.lua" },
	{ "hook", "includes/modules_override/hook.lua" },
	{ "concommand", "includes/modules_override/concommand.lua" },
}

local CURRENTHC
local function hookreplacement( ... )
	return hook.overcall( CURRENTHC, ... )
end

--[[detour.func( _G, "include", function( old, path, ... )

	local info = debug.getinfo( 4 )
	local totalpath
	if info and info.short_src then
		local callerpath = info.short_src
		callerpath = string.gsub( callerpath, "/[^/]-$", "" )
		callerpath = string.gsub( callerpath, "addons/[^/]-/lua/", "" )

		totalpath = callerpath .. "/" .. path
	end

	local r = { old( path, ... ) }

	for _, data in pairs( module_overrides ) do
		if data[2] == path or data[2] == totalpath then

			local tab

			local registry = debug.getregistry()

			if registry._LOADED and registry._LOADED[ data[ 1 ] ] then

				debugprint( "resorted to registry._LOADED" )
				tab = registry._LOADED[ data[ 1 ] ]

			elseif _G.package.loaded[ data[ 1 ] ] then

				debugprint( "resorted to package.loaded" )
				tab = _G.package.loaded[ data[ 1 ] ]

			elseif _G[ data[ 1 ] ] then

				debugprint( "resorted to global" )
				tab = _G[ data[ 1 ] ]

			else

				debugprint( "resorted to return" )
				tab = r[ 1 ]

			end

			--debugprint( "REDEFINING ", data[1], data[2] )

			--detour.unregisterTable( tab )

			handleModule( data[ 1 ], tab )

			return unpack( r )

		end
	end

	return unpack( r )

end )

detour.func( _G, "CompileFile", function( old, path, ... )

	local info = debug.getinfo( 4 )
	local totalpath
	if info and info.short_src then
		local callerpath = info.short_src
		callerpath = string.gsub( callerpath, "/[^/]-$", "" )
		callerpath = string.gsub( callerpath, "addons/[^/]-/lua/", "" )

		totalpath = callerpath .. "/" .. path
	end

	for _, data in pairs( module_overrides ) do

		if data[2] == path or data[2] == totalpath then

			local func = old( path )
			if not func then
				return
			end

			local detour = detour
			local debugprint = debugprint

			return function( ... )

				setfenv( func, getfenv( 1 ) )

				local r = { func( ... ) }

				local tab

				local registry = debug.getregistry()

				if registry._LOADED and registry._LOADED[ data[ 1 ] ] then

					debugprint( "resorted to registry._LOADED" )
					tab = registry._LOADED[ data[ 1 ] ]

				elseif _G.package.loaded[ data[ 1 ] ] then

					debugprint( "resorted to package.loaded" )
					tab = _G.package.loaded[ data[ 1 ] ]

				elseif _G[ data[ 1 ] ] then

					debugprint( "resorted to global" )
					tab = _G[ data[ 1 ] ]

				else

					debugprint( "resorted to return" )
					tab = r[ 1 ]

				end

				detour.unregisterTable( tab )

				handleModule( data[ 1 ], tab )

				return unpack( r )

			end

		end
	end

	return old( path, ... )

end )]]