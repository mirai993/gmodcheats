--[[
	bluejay/core/safe.lua
	Somer | (STEAM_0:1:15029381)
	===DStream===
]]

local set = "[%d%a]"
local pattern = "0x" .. set:rep( 8 ) .. "$"

--[[detour.func( _G, "tostring", function( old, val )

	if type( val ) == "function" then
		local _, data = detour.get( val )
		if data then
			return old( data.old ) -- This is required for builtin functions like detour.getinfo that returns function: builtin#125
		end
	end

	return old( val )

end )]]

detour.func( _G.debug, "getinfo", function( old, func, what )

	local info

	if type( func ) == "number" then

		if func == 0 then
			local info = old( func, what )
			if info.namewhat then
				info.namewhat = "field"
			end
			if info.name then
				info.name = "getinfo"
			end

			info.func = _G.debug.getinfo

			return info
		elseif func < 0 then
			return nil
		end

		if not old( func ) then
			return
		end

		local cleaninfo = {}
		local i = 2
		local info = old( i, what )
		while info and #cleaninfo < func do
			if not IsBluejay( i ) then
				cleaninfo[ #cleaninfo + 1 ] = info
			end

			i = i + 1
			info = old( i, what )
		end

		return cleaninfo[ func ]

	elseif type( func ) == "function" then

		local _, data = detour.get( func )
		if data then
			info = old( data.old, what )
		else
			info = old( func, what )
		end

	end

	if not info then
		info = old( func, what )
	end

	if info and info.func and type( func ) == "function" then
		info.func = func
	end

	return info

end )

detour.func( _G.debug, "getupvalue", function( old, func, index )

	local _, data = detour.get( func )
	if data then

		return old( data.old, index )

	end

	return old( func, index )

end )

--[[detour.func( _G.debug, "getlocal", function( old, func, index, ... )

	local out = old( func, index, ... )
	return out

end )]]

--[[detour.func( _G.jit.util, "funcinfo", function( old, func, ... )

	local _, data = detour.get( func )
	if data then
		return old( data.old, ... )
	end

	return old( func, ... )

end )

detour.func( _G.jit.util, "funcbc", function( old, func, ... )

	local _, data = detour.get( func )
	if data then
		return old( data.old, ... )
	end

	return old( func, ... )

end )

detour.func( _G.jit.util, "funck", function( old, func, ... )

	local _, data = detour.get( func )
	if data then
		return old( data.old, ... )
	end

	return old( func, ... )

end )

detour.func( _G.jit.util, "funcuvname", function( old, func, ... )

	local _, data = detour.get( func )
	if data then
		return old( data.old, ... )
	end

	return old( func, ... )

end )]]

--[[detour.func( _G, "collectgarbage", function( old, a, ... )

	if tostring( a ) == "count" then
		local normal = old( a, ... )
		if memoryused then
			return normal - memoryused
		end
	end

	return old( a, ... )

end )]]

--[[panic = false

local in_render = false

hook.add( "RenderScene", "Safe", function()

	in_render = true

end )

detour.func( _G.render, "Clear", function( old, ... )

	in_render = false

	return old( ... )

end )

detour.func( _G.render, "Capture", function( old, options )

	if not panic and in_render then
		panic = true

		if gui.IsConsoleVisible() then
			RunConsoleCommand( "toggleconsole" )
		end

		render.Clear( 0, 0, 0, 255, true, true )
		render.RenderView( {
			origin = EyePos(),
			angles = EyeAngles(),
			x = 0,
			y = 0,
			w = ScrW(),
			h = ScrH(),
			dopostprocess = true,
			drawhud = true,
			drawmonitors = true,
			drawviewmodel = true
		} )

		_G.hook.Call( "DrawOverlay", GAMEMODE )

		local worldpanel = _G.vgui.GetWorldPanel()
		if IsValid( worldpanel ) then
			worldpanel:PaintManual()
		end

		panic = false

		local o = {}
		local i = 2
		local info = debug.getinfo( i )
		while info do
			o[ i ] = info
			i = i + 1
			info = debug.getinfo( i )
		end

		print "OUT"
		printtable( o )

		local info = debug.getinfo( 4 )

		if info then
			debugprint( "'" .. tostring( info.short_src ) .. "' took a screen capture!"  )
			local source = getsource( info )
			if source then
				debugprint( "Source code:" )
				print( source )
			else
				debugprint( "Source code unreachable..." )
			end
		end
	end

	local out = old( options )
	return out

end )

local globalhook
local count = 0
local stepsize = 0

local events = {
	[ "call" ] = "c",
	[ "return" ] = "r",
	[ "tail return" ] = "r",
	[ "line" ] = "l"
}

local function luahook( event, line )

	if not globalhook or not globalhook.func then
		return
	end

	local required = events[ event ]
	if required and not globalhook.mask:lower():find( required, 1, true ) then
		return
	end

	if IsBluejay( 2 ) then
		return
	end

	pcall( globalhook.func, event, line )

end]]

--[[detour.func( _G.debug, "sethook", function( old, func, mask, count )

	if not func then
		globalhook = nil
		--old()
		return
	end

	mask = mask:gsub( "l", "" )

	globalhook = {
		func = func,
		mask = mask,
		count = count,
	}

	return --old( luahook, mask, count )

end )

detour.func( _G.debug, "gethook", function( old )

	if not globalhook then
		return nil, "", 0
	end

	return globalhook.func, globalhook.mask

end )]]

--[[detour.func( _G, "RunConsoleCommand", function( old, a, ... )

	if not a then
		return detour.PASS
	end

	debugprint( "RunConsoleCommand", a, ... )
	return old( a, ... )

end )]]

--[[local i = 1
_G.debug.sethook( function( event )
	i = i + 1
	if i > 2 then
		_G.debug.sethook()
		return
	end

	for i=1, 255 do
		local info = _G.debug.getinfo( i )
		if info then
			print( i, tostring( info.name ) .. tostring( info.source ) )
		end
	end
end, "c" )]]