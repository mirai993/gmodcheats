hook = {}

hook.list = {}

function hook.add( name, id, func )
	hook.list[ name ] = hook.list[ name ] or {}
	hook.list[ name ][ id ] = func
end

function hook.remove( name, id )
	hook.list[ name ] = hook.list[ name ] or {}
	hook.list[ name ][ id ] = nil
end

local renderHooks = { "draw", "render", "paint" }

function hook.call( name, ... )

	if not name then return end

	local hooks = hook.list[ name ]
	local ret

	if plugins then
		local ret = { plugins.callHook( name, ... ) }
		if #ret > 0 then
			return ret
		end
	end

	if not hooks then return end

	for k, v in pairs( hooks ) do
		ret = { pcall( v, ... ) }
		local s = table.remove( ret, 1 )
		if not s then
			error( 'hook "' .. tostring( k ) .. '" failed: ' .. tostring( ret[ 1 ] )  )
			hooks[ k ] = nil
		elseif #ret > 0 then
			return ret
		end
	end

end

function hook.overcall( old, name, gm, ... )

	if panic then
		for _, search in ipairs( renderHooks ) do
			if tostring( name ):lower():find( search ) then
				if old then
					return old( name, gm, ... )
				end
				return
			end
		end
	end

	local r = hook.call( name, ... )
	if r then
		return unpack( r )
	end

	if old then
		return old( name, gm, ... )
	end

end

detour.module( "hook", "Call", hook.overcall )

