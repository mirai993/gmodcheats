--[[
	autorun/client/asp_menu.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

function ASP.ChangeStaticName(steamid)
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(300, 100)
		Frame:Center()
		Frame:SetTitle("Change Static Name")
		Frame:MakePopup()
		Frame:SetBackgroundBlur(true)
	local Newname = vgui.Create("DTextEntry", Frame)
		Newname:SetPos(20, 30)
		Newname:SetSize(260, 20)
	local Changeit = vgui.Create("DButton", Frame)
		Changeit:SetSize(100, 30)
		Changeit:SetPos(100, 60)
		Changeit:SetText("Set Static Name")
		Changeit.DoClick = function()
			ASP.SetStaticName(steamid, Newname:GetValue())
			Frame:Close()
		end
end

function ASP.Internal.ShowMenu()
	ASP.Internal.ReadStaticNames()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(ScrW() / 1.5, ScrH() / 1.5)
		Frame:Center()
		Frame:SetTitle("ASP Main Menu")
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:MakePopup()
	local Tabs = vgui.Create("DPropertySheet", Frame)
		Tabs:SetSize(Tabs:GetParent():GetWide() - 20, Tabs:GetParent():GetTall() - 40)
		Tabs:SetPos(10, 30)
	local ConfigPanel = vgui.Create("DPanel", Tabs)
		ConfigPanel:SetSize(ConfigPanel:GetParent():GetWide() - 20, ConfigPanel:GetParent():GetTall() - 20)
		ConfigPanel:SetPos(10, 10)
		Tabs:AddSheet("Config Panel", ConfigPanel, "gui/silkicons/box", "Config Panel")
	local InfoPanel = vgui.Create("DPanel", Tabs)
		InfoPanel:SetSize(ConfigPanel:GetParent():GetWide() - 20, ConfigPanel:GetParent():GetTall() - 20)
		InfoPanel:SetPos(10, 10)
		Tabs:AddSheet("Information", InfoPanel, "gui/info", "Config Panel")
		InfoPanel.Paint = function(self)
			surface.SetDrawColor(Color(48, 48, 48, 255))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
		end
	local PlayerPanel = vgui.Create("DPanel", Tabs)
		PlayerPanel:SetSize(PlayerPanel:GetParent():GetWide() - 20, PlayerPanel:GetParent():GetTall() - 20)
		PlayerPanel:SetPos(10, 10)
		Tabs:AddSheet("Player List", PlayerPanel, "gui/silkicons/user", "Player List")
	local PlayerList = vgui.Create("DListView", PlayerPanel)
		PlayerList:SetSize(PlayerList:GetParent():GetWide() - 20, PlayerList:GetParent():GetTall() - 90)
		PlayerList:SetPos(10, 70)
		PlayerList:AddColumn("Name")
		PlayerList:AddColumn("SteamID")
		PlayerList:AddColumn("Rank")
		PlayerList:AddColumn("Money")
		PlayerList:AddColumn("Static Name")
		for k, v in pairs(player.GetAll()) do
			if v != nil then
				if v and v:IsValid() then
					local name = "Unknown"
					local steamid = "Unknown"
					local rank = "Guest"
					local money = "$???"
					local staticname = ""

					if v:IsAdmin() and not v:IsSuperAdmin() then
						rank = "Admin"
					elseif v:IsSuperAdmin() then
						rank = "Super Admin"
					end
					name = v:Nick()
					steamid = v:SteamID()
					if v.DarkRPVars != nil then
						if v.DarkRPVars.money != nil then
							money = v.DarkRPVars.money
						end
					end

					if v.staticname != nil then
						staticname = v.staticname
					end

					PlayerList:AddLine(name, steamid, rank, money, staticname)
				end
			end
		end
		PlayerList.OnRowRightClick = function(parent, line, value)
			local Menu = DermaMenu()
				Menu:AddOption("Set Static Name", function() ASP.ChangeStaticName(value:GetValue(2)) end)
			Menu:Open()
		end
	local UtilPanel = vgui.Create("DPanel", Tabs)
		UtilPanel:SetSize(UtilPanel:GetParent():GetWide() - 20, UtilPanel:GetParent():GetTall() - 20)
		UtilPanel:SetPos(10, 10)
		Tabs:AddSheet("Utilities", UtilPanel, "gui/silkicons/user", "Utilities")
	local UtilList = vgui.Create("DPanelList", UtilPanel)
		UtilList:SetSize(UtilList:GetParent():GetWide() - 20, UtilList:GetParent():GetTall() - 20)
		UtilList:SetPos(10, 10)
		UtilList:SetSpacing(5)
		UtilList:SetPadding(5)
		UtilList:EnableHorizontal(false)
		UtilList:EnableVerticalScrollbar(true)
		for k, v in pairs(ASP.Utilities) do
			local title = v.title or "Unknown"
			local button = vgui.Create("DButton")
				button:SetText(title)
				button.DoClick = function()
					v.func()
				end
			UtilList:AddItem(button)
		end

	local CFGColumn = vgui.Create("DColumnSheet", ConfigPanel)
		CFGColumn:SetSize(ConfigPanel:GetWide() - 200, ConfigPanel:GetTall())
		CFGColumn:SetPos(10, 10)
		for k, v in pairs(ASP.Modules) do
			if v.HasConfig then
				local panel = vgui.Create("DPanel", CFGColumn)
					panel:SetSize(CFGColumn:GetWide(), CFGColumn:GetTall())
					panel.Paint = function(self)
						surface.SetDrawColor(Color(48, 48, 48, 255))
						surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
					end
				local category = vgui.Create("DCollapsibleCategory", panel)
					category:SetLabel("Config")
					category:SetExpanded(0)
					category:SetSize(300, 300)
					category:SetPos(5, 5)
				local contents = vgui.Create("DPanelList")
					contents:SetAutoSize(true)
					contents:SetSpacing(5)
					contents:SetPadding(5)
					contents:EnableHorizontal(false)
					contents:EnableVerticalScrollbar(true)
				category:SetContents(contents)

				CFGColumn:AddSheet(v.Title or "Unknown", panel, "gui/silkicons/box", v.Title or "Unknown")

				for _, cbox in pairs(ASP.Data.CFGCheckBoxes) do
					if cbox.mod == v then
						local CheckBox = vgui.Create("DCheckBoxLabel")
							CheckBox:SetText(cbox.title or "Unknown")
							CheckBox:SetConVar(cbox.convar)
							CheckBox:SetValue(GetConVar(cbox.convar):GetBool())
							CheckBox:SizeToContents()
						contents:AddItem(CheckBox)
					end
				end
				for _, tbox in pairs(ASP.Data.CFGTextBoxes) do
					if tbox.mod == v then
						local Title = vgui.Create("DLabel")
							Title:SetText(tbox.title or "Unknown")
							Title:SizeToContents()
							contents:AddItem(Title)
						local TextArea = vgui.Create("DTextEntry")
							TextArea:SetText(tbox.title or "Unknown")
							TextArea:SetSize(150, 22)
							TextArea:SetValue(GetConVar(tbox.convar):GetString())
							TextArea.OnEnter = function()
								RunConsoleCommand(tbox.convar, TextArea:GetValue())
							end
						contents:AddItem(TextArea)
					end
				end
				for _, slider in pairs(ASP.Data.CFGSliders) do
					if slider.mod == v then
						local NumSlider = vgui.Create("DNumSlider")
							NumSlider:SetText(slider.title or "Unknown")
							NumSlider:SetSize(100, 40)
							NumSlider:SetMin(slider.min)
							NumSlider:SetMax(slider.max)
							NumSlider:SetDecimals(0)
							NumSlider:SetConVar(slider.convar)
							NumSlider:SetValue(GetConVar(slider.convar):GetFloat())
						contents:AddItem(NumSlider)
					end
				end
				for _, color in pairs(ASP.Data.CFGColors) do
					if color.mod == v then
						local label = vgui.Create("DLabel")
							label:SetText(color.title)
							label:SizeToContents()
						contents:AddItem(label)
						local ColorMix = vgui.Create("DColorMixer")
							ColorMix:SetSize(100, 100)
							local col = Color(math.Round(GetConVar(color.convar .. "_r"):GetFloat()), math.Round(GetConVar(color.convar .. "_g"):GetFloat()), math.Round(GetConVar(color.convar .. "_b"):GetFloat()), math.Round(GetConVar(color.convar .. "_a"):GetInt()))
							print("Color = " .. col.r .. ", " .. col.g .. ", " .. col.b)
							ColorMix:SetColor(col)
						ColorMix.Think = function()
							RunConsoleCommand(color.convar .. "_r", ColorMix:GetColor().r)
							RunConsoleCommand(color.convar .. "_g", ColorMix:GetColor().g)
							RunConsoleCommand(color.convar .. "_b", ColorMix:GetColor().b)
							RunConsoleCommand(color.convar .. "_a", ColorMix:GetColor().a)
						end
						contents:AddItem(ColorMix)
					end
				end
			end
		end
	local ScrollBar = vgui.Create("DScrollPanel", InfoPanel)
		ScrollBar:SetSize(200, 900)
		ScrollBar:SetPos(10, 100)
		ScrollBar:EnableVerticalScrollbar(true)
	local InfoPanelTitle = vgui.Create("DLabel", InfoPanel)
		InfoPanelTitle:SetPos(10, 8)
		InfoPanelTitle:SetFont("DefaultBold")
		InfoPanelTitle:SetText("ASP Information Panel (ASP V1.0)")
		InfoPanelTitle:SizeToContents()
	local InfoPanelMaintext = vgui.Create("DLabel", InfoPanel)
		InfoPanelMaintext:SetPos(10, 22)
		InfoPanelMaintext:SetFont("Default")
		InfoPanelMaintext:SetText([[
ASP (Anthr4x292 Scripts Pack) is a collection of public Client-Side scripts by Anthr4x292.
Originally designed to be private, but i decided to release it too the public.
It is module-based so developers can easily make custom modules for it without recoding the entire menus etc.
Default modules (ESP, XRay etc) are made by Anthr4X, and there will be a collection of custom modules too in updates or by members.
Default commands are:

asp_reload - Use incase of a fatal Lua error, or whenever you'd want to reload the scripts.
asp_xray - Toggle XRay Vision.
+asp_bhop - BunnyHop, will stop bunnyhopping on -asp_bhop (-asp_bhop will be run if you release a bindkey to +asp_bhop).
asp_rotate - Rotate 180 Deg for propboosting.
asp_notepad - Opens up a notepad.
asp_specmenu - Opens up spectator menu.
asp_uploaddupe - Opens Adv. Dupe Forced Uploading (Sometimes not working).
asp_detector - Opens Detector Menu.
asp_removedetector - Removes the detector you are looking at.
+asp_propview - Looks through your last spawned prop, for it to recognize, you must have looked at the prop when you spawned it.
+asp_antidof - Removes dof_nodes (Screen blur) from being drawn, such as the turret glitch.
]])
		InfoPanelMaintext:SizeToContents()
end

concommand.Add("asp_menu", ASP.Internal.ShowMenu)