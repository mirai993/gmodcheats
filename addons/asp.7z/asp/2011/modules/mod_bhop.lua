--[[
	autorun/client/modules/mod_bhop.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

local Mod = ASPModule("Bunnyhop")

function ASP.Util.BunnyHop()
	if LocalPlayer():IsOnGround() then
		LocalPlayer():ConCommand("+jump")
	else
		LocalPlayer():ConCommand("-jump")
	end
end

concommand.Add("+asp_bhop", function()
	hook.Add("Think", "ASP.Util.BunnyHop", ASP.Util.BunnyHop)
end)

concommand.Add("-asp_bhop", function()
	hook.Remove("Think", "ASP.Util.BunnyHop")
	LocalPlayer():ConCommand("-jump")
end)