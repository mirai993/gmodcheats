--[[
	autorun/client/modules/util_propview.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

local CData = {}
ASP.Data.IsViewingProp = false
ASP.Data.EntPositions = {}

function ASP.ViewProp()
	if ASP.Data.LastSpawnedProp != nil then
		if ASP.Data.LastSpawnedProp and ASP.Data.LastSpawnedProp:IsValid() then
			local pos = ASP.Data.LastSpawnedProp:GetPos() + Vector(0, 0, ASP.Data.LastSpawnedProp:OBBCenter().z)
				pos = pos - (EyeAngles():Forward() * 100)
			ASP.Data.EyePos = pos
			ASP.Data.EyeAngles = EyeAngles()
			CData.origin = pos
			CData.angles = EyeAngles()
			CData.x = 0
			CData.y = 0
			CData.w = ScrW()
			CData.h = ScrH()
			render.RenderView(CData)
		else
			ASP.Data.LastSpawnedProp = nil
		end
	end
end

function ASP.StartViewProp()
	hook.Add("ASPHUDPaint", "ASP.ViewProp", ASP.ViewProp)
	ASP.Data.IsViewingProp = true
end

function ASP.EndViewProp()
	hook.Remove("ASPHUDPaint", "ASP.ViewProp")
	ASP.Data.IsViewingProp = false
end

concommand.Add("+asp_propview", ASP.StartViewProp)
concommand.Add("-asp_propview", ASP.EndViewProp)