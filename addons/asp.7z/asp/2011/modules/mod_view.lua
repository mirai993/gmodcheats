--[[
	autorun/client/modules/mod_view.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

local Mod = ASPModule("View Utils")

function ASP.Util.DrawForward()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(0, ang.y, ang.r))
end

concommand.Add("+drawfixed", function()
	hook.Add("Think", "ASP.Util.DrawForward", ASP.Util.DrawForward)
end)

concommand.Add("-drawfixed", function()
	hook.Remove("Think", "ASP.Util.DrawForward")
end)