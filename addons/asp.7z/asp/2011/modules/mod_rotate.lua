--[[
	autorun/client/modules/mod_rotate.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

local Mod = ASPModule("Rotate")

function ASP.Util.Rotate()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(ang - Angle(0, 180, 0))
end

concommand.Add("asp_rotate", ASP.Util.Rotate)