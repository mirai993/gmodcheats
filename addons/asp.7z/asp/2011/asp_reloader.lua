--[[
	autorun/client/asp_reloader.lua
	[L4G]Mao | (STEAM_0:1:30473979)
	===DStream===
]]

local function ReloadScripts()
	hook.Call("ASPReload")
	include('autorun/client/asp_init.lua')
end

concommand.Add("asp_reload", ReloadScripts)