--[[
	MOD/lua/autorun/client/asp_reloader.lua [#143 (#148), 504030271]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:22PM]
	===BadFile===
]]

local function ReloadScripts()
	hook.Call("ASPReload")
	include('autorun/client/asp_init.lua')
end

concommand.Add("asp_reload", ReloadScripts)