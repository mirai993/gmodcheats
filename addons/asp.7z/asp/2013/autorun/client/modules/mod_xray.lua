--[[
	MOD/lua/autorun/client/modules/mod_xray.lua [#7436 (#7668), 4278260123]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:26PM]
	===BadFile===
]]

local XRayEnts = {}
local XRayEntTypes = {
	{class = "prop", color = Color(255, 0, 0)},
	{class = "npc_", color = Color(0, 0, 255)},
	{class = "spawned_", color = Color(255, 255, 0)},
	{class = "door", color = Color(255, 0, 0)},
	{class = "gmod_wire_hologram", color = Color(255, 255, 255)}
}

local Mod = ASPModule("X-Ray")
ASP.Util.SetConVarToggle(Mod, "xray", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.IsEnabled["SPEffects"] = true
	Mod.HasConfig = true

function ASP.Util.AddXRayEntity(ent)
	if ent and ent:IsValid() then
		table.insert(XRayEnts, ent)
	end
	if #XRayEnts > ASP.Util.GetModValue(Mod, "maxents") then
		if XRayEnts[1] != nil then
			if XRayEnts[1] and XRayEnts[1]:IsValid() then
				XRayEnts[1]:SetNoDraw(false)
			end
		end
		table.remove(XRayEnts, 1)
	end
end

CreateClientConVar("asp_xray_showdata", "1", true, false)
	
function Mod:Draw()
	if GetConVar("asp_xray_showdata"):GetBool() then
		surface.SetDrawColor(Color(0, 0, 0, 128))
		surface.DrawRect(5, 5, 180, 20)
		surface.SetFont("DefaultFixed")
		if #XRayEnts < ASP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(0, 255, 0, 255))
		elseif #XRayEnts == ASP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(255, 255, 0, 255))
		elseif #XRayEnts > ASP.Util.GetModValue(Mod, "maxents") then
			surface.SetTextColor(Color(255, 0, 0, 255))
		end
		surface.SetTextPos(10, 10)
		surface.DrawText("XRay entity count: " .. #XRayEnts .. "/" .. ASP.Util.GetModValue(Mod, "maxents"))
	end
end

function Mod:SPEffects()
	if ASP.Util.ModConVarEnabled(Mod, "drawlines") then
		for k, v in pairs(player.GetAll()) do
			if v != nil then
				if v and v:IsValid() and v:Alive() then
					cam.Start3D(EyePos(), EyeAngles())
						render.SetMaterial(LASER)
						if v == LocalPlayer() then
							render.DrawBeam(v:GetMuzzlePos(), v:GetEyeTrace().HitPos, 10, 1, 1, Color(0, 255, 0, 255))
						else
							local pos = v:EyePos()
							if v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Hand")) != nil then
								pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_R_Hand"))
							end
							if v:GetMuzzlePos() != v:EyePos() then
								render.DrawBeam(v:GetMuzzlePos(), v:GetEyeTrace().HitPos, 25, 1, 1, Color(0, 255, 0, 255))
							else
								render.DrawBeam(pos, v:GetEyeTrace().HitPos, 25, 1, 1, Color(0, 255, 0, 255))
							end
						end
					cam.End3D()
				end
			end
		end
	end
	if ASP.Util.IsConVarEnabled(Mod) then
		if #XRayEnts <= 0 then
			RunConsoleCommand("rope_rendersolid", "1")
			table.Empty(XRayEnts)
			if not ASP.Util.ModConVarEnabled(Mod, "onlyspawnedprops") then
				ASP.Util.InitXRayEnts()
			else
				ASP.Util.InitXRayEnts()
			end
		end
	end
	if ASP.Util.ModConVarEnabled(Mod, "drawplayers") then
		for k, v in pairs(player.GetAll()) do
			if v != nil then
				if v and v:IsValid() and v:Alive() then
					cam.Start3D(EyePos(), EyeAngles())
						cam.IgnoreZ(true)
							local mat = v:GetMaterial()
							render.SuppressEngineLighting(true)
							render.SetBlend(1)
							if ASP.Util.ModConVarEnabled(Mod, "custommaterial") then
								//SetMaterialOverride(Material("models/wireframe"))
								render.MaterialOverride(Material("models/wireframe"))
								v:SetMaterial("models/wireframe")
								render.SetBlend(0.5)
							end
							if ASP.Util.ModConVarEnabled(Mod, "customcolor") then
								render.SetColorModulation(0, 1, 0, 0.5)
							end
								v:DrawModel()
							render.SetColorModulation(1, 1, 1)
							//SetMaterialOverride(nil)
							render.MaterialOverride()
							render.SetBlend(0)
							render.SuppressEngineLighting(false)
							v:SetMaterial(mat)
						cam.IgnoreZ(false)
					cam.End3D()
				end
			end
		end
	end
	for k, v in pairs(XRayEnts) do
		if v != nil then
			if v and v:IsValid() then
				for _, ent in pairs(XRayEntTypes) do
					if string.match(v:GetClass(), ent.class) then
						local renderit = true
						if not ASP.Util.ModConVarEnabled(Mod, "drawdoors") then
							if string.match(v:GetClass(), "door") then
								renderit = false
							end
						end
						if not ASP.Util.ModConVarEnabled(Mod, "drawnpcs") then
							if string.match(v:GetClass(), "npc") then
								renderit = false
							end
						end
						if not ASP.Util.ModConVarEnabled(Mod, "drawprops") then
							if string.match(v:GetClass(), "prop") then
								renderit = false
							end
						end
						if renderit then
							cam.Start3D(EyePos(), EyeAngles())
								cam.IgnoreZ(true)
									local mat = v:GetMaterial()
									render.SuppressEngineLighting(true)
									render.SetBlend(1)
										if ASP.Util.ModConVarEnabled(Mod, "custommaterial") then
											v:SetNoDraw(true)
											//SetMaterialOverride(Material(ASP.Util.GetModText(Mod, "material")))
											render.MaterialOverride(Material(ASP.Util.GetModText(Mod, "material")))
											v:SetMaterial("models/shiny")
											render.SetBlend(0.5)
										else
											v:SetNoDraw(false)
										end
										if ASP.Util.ModConVarEnabled(Mod, "customcolor") then
											render.SetColorModulation(ent.color.r / 255, ent.color.g / 255, ent.color.b / 255, 0.5)
										end
											v:DrawModel()
										render.SetColorModulation(1, 1, 1)
										//SetMaterialOverride(nil)
										render.MaterialOverride()
									render.SetBlend(0)
									render.SuppressEngineLighting(false)
									v:SetMaterial(mat)
								cam.IgnoreZ(false)
							cam.End3D()
						end
					end
				end
			else
				table.remove(XRayEnts, k)
			end
		else
			table.remove(XRayEnts, k)
		end
	end
end

function ASP.Util.InitXRayEnts()
	XRayEnts = {}
	table.Empty(XRayEnts)
	for k, v in pairs(ents.GetAll()) do
		for _, str in pairs(XRayEntTypes) do
			if string.match(string.lower(v:GetClass()), string.lower(str.class)) then
				ASP.Util.AddXRayEntity(v)
			end
		end
	end
end

hook.Add("Think", "ASP.XRay.OnTurnedOff", function()
	if not ASP.Util.IsConVarEnabled(Mod) then
		if #XRayEnts > 0 then
			RunConsoleCommand("rope_rendersolid", "1")
			surface.PlaySound("items/nvg_off.wav")
			for k, v in pairs(XRayEnts) do
				v:SetNoDraw(false)
			end
			table.Empty(XRayEnts)
		end
	end
end)

hook.Add("OnEntityCreated", "ASP.XRay.AddXRayEntity", function(ent)
	ASP.Data.EyePos = EyePos()
	ASP.Data.EyeAngles = EyeAngles()
	if ASP.Util.IsConVarEnabled(Mod) then
		for _, str in pairs(XRayEntTypes) do
			if ent and ent:IsValid() then
				if string.match(string.lower(ent:GetClass()), string.lower(str.class)) then
					ASP.Util.AddXRayEntity(ent)
				end
			end
		end
	end
end)

ASP.Util.AddCFGCheckBox(Mod, "Enable XRay", "enabled")
ASP.Util.AddCFGSlider(Mod, "Max XRay Entities", "maxents", 10, 10, 1000)
ASP.Util.AddCFGTextBox(Mod, "Override Material", "material", "models/shiny")
ASP.Util.AddCFGCheckBox(Mod, "Custom Material", "custommaterial", 1)
ASP.Util.AddCFGCheckBox(Mod, "Custom Color", "customcolor", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Doors", "drawdoors", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Players", "drawplayers", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Props", "drawprops", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw NPCs", "drawnpcs", 1)
ASP.Util.AddCFGCheckBox(Mod, "Only Spawned Props", "onlyspawnedprops", 0)
ASP.Util.AddCFGCheckBox(Mod, "Tracer Lines (Barrelhack)", "drawlines", 1)

concommand.Add("asp_xray", function()
	if GetConVar("asp_xray_enabled"):GetBool() then
		RunConsoleCommand("asp_xray_enabled", "0")
	else
		RunConsoleCommand("asp_xray_enabled", "1")
	end
end)