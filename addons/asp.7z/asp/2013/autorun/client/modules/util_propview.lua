--[[
	MOD/lua/autorun/client/modules/util_propview.lua [#960 (#995), 3252722182]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:28PM]
	===BadFile===
]]

local CData = {}
ASP.Data.IsViewingProp = false
ASP.Data.EntPositions = {}

function ASP.ViewProp()
	if ASP.Data.LastSpawnedProp != nil then
		if ASP.Data.LastSpawnedProp and ASP.Data.LastSpawnedProp:IsValid() then
			local pos = ASP.Data.LastSpawnedProp:GetPos() + Vector(0, 0, ASP.Data.LastSpawnedProp:OBBCenter().z)
				pos = pos - (EyeAngles():Forward() * 100)
			ASP.Data.EyePos = pos
			ASP.Data.EyeAngles = EyeAngles()
			CData.origin = pos
			CData.angles = EyeAngles()
			CData.x = 0
			CData.y = 0
			CData.w = ScrW()
			CData.h = ScrH()
			render.RenderView(CData)
		else
			ASP.Data.LastSpawnedProp = nil
		end
	end
end

function ASP.StartViewProp()
	hook.Add("ASPHUDPaint", "ASP.ViewProp", ASP.ViewProp)
	ASP.Data.IsViewingProp = true
end

function ASP.EndViewProp()
	hook.Remove("ASPHUDPaint", "ASP.ViewProp")
	ASP.Data.IsViewingProp = false
end

concommand.Add("+asp_propview", ASP.StartViewProp)
concommand.Add("-asp_propview", ASP.EndViewProp)