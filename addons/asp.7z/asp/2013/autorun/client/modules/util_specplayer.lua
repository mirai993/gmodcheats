--[[
	MOD/lua/autorun/client/modules/util_specplayer.lua [#1891 (#1960), 483649746]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:29PM]
	===BadFile===
]]

function ASP.Spectate(plyname)
	local ply = LocalPlayer()
	for k, v in pairs(player.GetAll()) do
		if string.match(string.lower(v:Nick()), string.lower(plyname)) then
			ply = v
		end
	end
	hook.Add("ASPHUDPaint", "SpectatePlayer", function()
		if ply and ply:IsValid() then
			local CamData = {}
				ASP.Data.EyePos = ply:EyePos()
				ASP.Data.EyeAngles = ply:EyeAngles()
				CamData.origin = ply:EyePos()
				CamData.angles = ply:EyeAngles()
				CamData.x = 0
				CamData.y = 0
				CamData.w = ScrW()
				CamData.h = ScrH()
				render.RenderView(CamData)
		end
	end)
end

function ASP.SpecMenu()
	local sizew = 300
	local sizeh = 100

	local Frame = vgui.Create("DFrame")
		Frame:SetSize(sizew, sizeh)
		Frame:Center()
		Frame:SetTitle("Player Spectating")
		Frame:ShowCloseButton(true)
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:SetBackgroundBlur(true)
		Frame:MakePopup()
	local Name = vgui.Create("DTextEntry", Frame)
		Name:SetSize(sizew - 40, 20)
		Name:SetPos(20, 30)
		Name:SetText("Part of player name")
		Name.OnTextChanged = function()
			local files = file.Find("adv_duplicator/*.txt")
			if #files != 1 then
				local Menu = DermaMenu()
				for k, v in pairs(player.GetAll()) do
					if string.match(string.lower(v:Nick()), string.lower(Name:GetValue())) then
						Menu:AddOption(v:Nick(), function()
							Name:SetText(v:Nick())
						end)
					end
				end
				Menu:Open()
			end
		end
	local SpecButton = vgui.Create("DButton", Frame)
		SpecButton:SetSize(100, 30)
		SpecButton:SetPos((sizew / 2) - 50, 60)
		SpecButton:SetText("Spectate Player")
		SpecButton.DoClick = function(self)
			ASP.Spectate(Name:GetValue())
			Frame:Close()
		end
end

function ASP.StopSpec()
	hook.Remove("ASPHUDPaint", "SpectatePlayer")
end

ASP.RegisterUtility("Player Spectate", ASP.SpecMenu, "spectatemenu")
ASP.RegisterUtility("Stop Spectating", ASP.StopSpec, "stopspec")