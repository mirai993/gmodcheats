--[[
	MOD/lua/autorun/client/modules/mod_weaponwarning.lua [#2258 (#2338), 518292842]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:25PM]
	===BadFile===
]]

local Mod = ASPModule("Weapon Warning")
ASP.Util.SetConVarToggle(Mod, "weaponwarning", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.IsEnabled["Think"] = true
	Mod.HasConfig = true

local drawtext = {}
	drawtext.text = ""
	drawtext.alpha = 0
	drawtext.active = false

local lastaimer = LocalPlayer()
local lastwep = "?"

function ASP.DrawNotif(text)
	print("DRAWING")
	drawtext.text = text
	drawtext.alpha = 255
	drawtext.active = true
end

function ASP.StopNotif()
	drawtext.active = false
end

function Mod:Draw()
	surface.SetDrawColor(Color(255, 0, 0, drawtext.alpha / 2))
	if not LocalPlayer():Alive() then
		if lastaimer and lastaimer:IsValid() then
			if lastaimer:Nick() != nil then
				surface.SetDrawColor(Color(0, 0, 255, drawtext.alpha / 2))
				drawtext.text = "Kill prediction status: Last aimer " .. lastaimer:Nick() .. " wielding a " .. lastwep
				drawtext.alpha = 255
				drawtext.active = true
			end
		end
	end
	if drawtext.alpha > 0 then
		surface.SetFont("Default")
		local size = surface.GetTextSize(drawtext.text)
		surface.DrawRect((ScrW() / 2) - 20 - (size / 2), 10, 20 + (size), 25)
		surface.SetTextColor(Color(255, 255, 255, drawtext.alpha))
		surface.SetTextPos((ScrW() / 2) - 10 - (size / 2), 15)
		surface.DrawText(drawtext.text)
	end

	if not drawtext.active then
		drawtext.alpha = drawtext.alpha - 10
	end
end

// Yes i know, i exxagerate the 'nil' and IsValid() checks, but still better that then errors :)
function Mod:Think()
	for k, v in pairs(player.GetAll()) do
		if v and v:IsValid() then
			if v:Alive() and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				if v:GetEyeTrace() != nil then
					local tr = v:GetEyeTrace()
					if tr and tr != nil then
						local ent = tr.Entity
						if ent and ent:IsValid() then
							if ent == LocalPlayer() then
								if string.match(string.lower(v:GetActiveWeapon():GetClass()), "weapon_") and not drawtext.active then
									ASP.DrawNotif(v:Nick() .. " is aiming at you with a " .. v:GetActiveWeapon():GetClass())
									lastaimer = v
									lastwep = v:GetActiveWeapon():GetClass()
								else
									ASP.StopNotif()
								end
							else
								ASP.StopNotif()
							end
						else
							ASP.StopNotif()
						end
					end
				end
			end
		end
	end
end