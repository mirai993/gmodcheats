--[[
	MOD/lua/autorun/client/modules/mod_view.lua [#366 (#379), 2290418599]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:25PM]
	===BadFile===
]]

local Mod = ASPModule("View Utils")

function ASP.Util.DrawForward()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(0, ang.y, ang.r))
end

concommand.Add("+drawfixed", function()
	hook.Add("Think", "ASP.Util.DrawForward", ASP.Util.DrawForward)
end)

concommand.Add("-drawfixed", function()
	hook.Remove("Think", "ASP.Util.DrawForward")
end)