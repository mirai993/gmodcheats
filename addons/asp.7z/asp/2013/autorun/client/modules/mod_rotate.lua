--[[
	MOD/lua/autorun/client/modules/mod_rotate.lua [#201 (#208), 2120948474]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:24PM]
	===BadFile===
]]

local Mod = ASPModule("Rotate")

function ASP.Util.Rotate()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(ang - Angle(0, 180, 0))
end

concommand.Add("asp_rotate", ASP.Util.Rotate)