--[[
	MOD/lua/autorun/client/modules/mod_antiadmin.lua [#897 (#929), 2696989333]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:22PM]
	===BadFile===
]]

local Mod = ASPModule("Anti Admin Effects")
ASP.Util.SetConVarToggle(Mod, "anti", 1)
	Mod.IsEnabled["Think"] = true
	Mod.HasConfig = true

local umh = usermessage.Hook
function usermessage.Hook(name, func)
	if ASP.Util.ModConVarEnabled(Mod, "antiblind") then
		if name != "ulx_blind" then
			umh(name, func)
		end
	else
		umh(name, func)
	end
end

function Mod:Think()
	if ASP.Util.ModConVarEnabled(Mod, "antimute") then
		if LocalPlayer():GetNWBool("Muted") then
			LocalPlayer():SetNWBool("Muted", false)
		end
		hook.Remove("PlayerBindPress", "ULXGagForce")
		timer.Destroy("GagLocalPlayer")
	end
	if ASP.Util.ModConVarEnabled(Mod, "antiblind") then
		if LocalPlayer():GetNWBool("EV_Blinded") then
			LocalPlayer():SetNWBool("EV_Blinded", false)
		end
	end
end

ASP.Util.AddCFGCheckBox(Mod, "Enable Anti-Gag/Anti-Mute", "antimute")
ASP.Util.AddCFGCheckBox(Mod, "Enable Anti-Blind", "antiblind")