--[[
	MOD/lua/autorun/client/modules/util_dupeupload.lua [#1234 (#1275), 4259342918]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:27PM]
	===BadFile===
]]

function ASP.DupeUpload()
	local sizew = 300
	local sizeh = 100

	local Frame = vgui.Create("DFrame")
		Frame:SetSize(sizew, sizeh)
		Frame:Center()
		Frame:SetTitle("Forced Adv Dupe Upload")
		Frame:ShowCloseButton(true)
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:SetBackgroundBlur(true)
		Frame:MakePopup()
	local File = vgui.Create("DTextEntry", Frame)
		File:SetSize(sizew - 40, 20)
		File:SetPos(20, 30)
		File:SetText("Filename relevant to data/adv_duplicator")
		File.OnTextChanged = function()
			local files = file.Find("adv_duplicator/*.txt")
			if #files != 1 then
				local Menu = DermaMenu()
				for k, v in pairs(files) do
					if string.match(string.lower(v), string.lower(File:GetValue())) then
						Menu:AddOption(v, function()
							File:SetText(v)
						end)
					end
				end
				Menu:Open()
			end
		end
	local UploadButton = vgui.Create("DButton", Frame)
		UploadButton:SetSize(80, 30)
		UploadButton:SetPos((sizew / 2) - 40, 60)
		UploadButton:SetText("Force Upload")
		UploadButton.DoClick = function(self)
			AdvDupeClient.UpLoadFile(LocalPlayer(), "adv_duplicator/" .. File:GetValue())
			Frame:Close()
		end
end

ASP.RegisterUtility("Force ADV Dupe Upload", ASP.DupeUpload, "uploaddupe")