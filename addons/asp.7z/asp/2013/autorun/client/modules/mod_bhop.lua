--[[
	MOD/lua/autorun/client/modules/mod_bhop.lua [#413 (#430), 3954778017]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:23PM]
	===BadFile===
]]

local Mod = ASPModule("Bunnyhop")

function ASP.Util.BunnyHop()
	if LocalPlayer():IsOnGround() then
		LocalPlayer():ConCommand("+jump")
	else
		LocalPlayer():ConCommand("-jump")
	end
end

concommand.Add("+asp_bhop", function()
	hook.Add("Think", "ASP.Util.BunnyHop", ASP.Util.BunnyHop)
end)

concommand.Add("-asp_bhop", function()
	hook.Remove("Think", "ASP.Util.BunnyHop")
	LocalPlayer():ConCommand("-jump")
end)