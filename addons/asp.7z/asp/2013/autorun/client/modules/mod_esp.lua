--[[
	MOD/lua/autorun/client/modules/mod_esp.lua [#6291 (#6436), 1972379011]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:24PM]
	===BadFile===
]]

local Mod = ASPModule("ESP")
ASP.Util.SetConVarToggle(Mod, "esp", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.HasConfig = true

function Mod:Draw()
	cam.Start3D(ASP.Data.EyePos, ASP.Data.EyeAngles)
		cam.Start2D()
		if ASP.Util.ModConVarEnabled(Mod, "drawplayers") then
			for k, v in pairs(player.GetAll()) do
				if v != LocalPlayer() then
					if ASP.Util.ModConVarEnabled(Mod, "litemode") then
						local dist = math.Round(v:GetPos():Distance(LocalPlayer():GetShootPos()))
						local text = v:Nick()
						if ASP.Util.ModConVarEnabled(Mod, "drawplayerdist") then
							text = v:Nick() .. " (" .. dist .. ")"
						end
						local boxsize = 15
						local pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
							pos = pos:ToScreen()
						surface.SetFont("DefaultBold")
						surface.SetTextColor(Color(255, 255, 255, 255))
						local textsize = surface.GetTextSize(text)
						surface.SetTextPos(pos.x + (boxsize / 2) + 2, pos.y - 7)
						surface.DrawText(text)
						surface.SetDrawColor(Color(Color(255, 0, 0).r, Color(255, 0, 0).g, Color(255, 0, 0).b, 255))
						surface.DrawRect(pos.x - (boxsize / 2), pos.y - (boxsize / 2), boxsize, boxsize)
					else
						local boxsize = ASP.Util.GetModValue(Mod, "boxsize")
						local pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
							pos = pos:ToScreen()
						surface.SetDrawColor(Color(255, 0, 0))
						surface.DrawOutlinedRect(pos.x - (boxsize / 2), pos.y - (boxsize / 2), boxsize, boxsize)

						local colb = Color(255, 0, 0)
							colb.a = colb.a - 128
						surface.SetDrawColor(colb)
						surface.DrawOutlinedRect(pos.x - (boxsize / 2) + 3, pos.y - (boxsize / 2) + 3, boxsize - 6, boxsize - 6)

						local coln = Color(255, 0, 0)
							coln.a = 255
						surface.SetFont("DefaultBold")
						surface.SetTextColor(coln)
						surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2))
						surface.DrawText(v:Nick())
						if ASP.Util.ModConVarEnabled(Mod, "drawrank") then
							surface.SetTextColor(Color(255, 255, 255, 255))
							surface.DrawText(" ")
							local rank = ""
							if v:IsAdmin() and not v:IsSuperAdmin() then
								rank = "[Admin]"
							elseif v:IsSuperAdmin() then
								rank = "[Superadmin]"
							end
							surface.DrawText(rank)
						end
						if ASP.Util.ModConVarEnabled(Mod, "drawplayermoney") then
							local money = "???"
							if v.DarkRPVars then
								if v.DarkRPVars.money and v.DarkRPVars.money != nil then
									money = v.DarkRPVars.money
								end
							end
							surface.SetFont("DefaultSmall")
							surface.SetTextColor(Color(255, 255, 255, 255))
							surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 12)
							surface.DrawText("Money: " .. "$" .. money)
						end
						if ASP.Util.ModConVarEnabled(Mod, "drawplayerdist") then
							local dist = math.Round(v:GetPos():Distance(LocalPlayer():GetShootPos()))
							surface.SetFont("DefaultSmall")
							surface.SetTextColor(Color(255, 255, 255, 255))
							surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 20)
							surface.DrawText("Distance: " .. dist)
						end
						if ASP.Util.ModConVarEnabled(Mod, "drawplayerweapon") then
							local wep = "Unknown"
							if v:Alive() then
								if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
									if v:GetActiveWeapon():GetPrintName() and v:GetActiveWeapon():GetPrintName() != nil then
										wep = v:GetActiveWeapon():GetPrintName()
									end
								end
							end
							surface.SetFont("DefaultSmall")
							surface.SetTextColor(Color(255, 255, 255, 255))
							surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 28)
							surface.DrawText("Weapon: " .. wep)
						end
						if ASP.Util.ModConVarEnabled(Mod, "drawplayerhealth") then
							local health = "DEAD"
							surface.SetFont("DefaultSmall")
							surface.SetTextColor(Color(255, 255, 255, 255))
							surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 36)
							surface.DrawText("Health: ")
							if v:Alive() then
								surface.SetTextColor(Color(0, 255, 0, 255))
								if v:Health() and v:Health() != nil then
									health = v:Health() .. "%"
								end
							else
								surface.SetTextColor(Color(255, 0, 0, 255))
							end
							surface.DrawText(health)
						end
					end
				end
			end
		end
		if ASP.Util.ModConVarEnabled(Mod, "drawcrosshair") then
			local dist = math.Round(LocalPlayer():GetShootPos():Distance(LocalPlayer():GetEyeTrace().HitPos))
			local pos2 = LocalPlayer():GetEyeTrace().HitPos
				pos2 = pos2:ToScreen()
			surface.SetDrawColor(Color(0, 255, 0, 255))
			surface.DrawOutlinedRect(pos2.x - 4, pos2.y - 4, 8, 8)
			surface.DrawRect(pos2.x - 1, pos2.y - 1, 2, 2)

			surface.SetDrawColor(Color(0, 255, 0, 255))
			surface.DrawLine(pos2.x - 20 - (dist / 1000), pos2.y, pos2.x - 6 - (dist / 1000), pos2.y)
			surface.DrawLine(pos2.x + 20 + (dist / 1000), pos2.y, pos2.x + 6 + (dist / 1000), pos2.y)
			surface.DrawLine(pos2.x, pos2.y - 20 - (dist / 1000), pos2.x, pos2.y - 6 - (dist / 1000))
			surface.DrawLine(pos2.x, pos2.y + 20 + (dist / 1000), pos2.x, pos2.y + 6 + (dist / 1000))

			surface.SetFont("DefaultBold")
			surface.SetTextColor(Color(255, 0, 0, 255))
			surface.SetTextPos(pos2.x - (surface.GetTextSize("Distance: " .. dist) / 2), pos2.y + 18 + (dist / 700))
			surface.DrawText("Distance: ")
			surface.SetFont("Default")
			surface.DrawText(dist)
		end
		cam.End2D()
	cam.End3D()
end

ASP.Util.AddCFGCheckBox(Mod, "Enable ESP", "enabled")
ASP.Util.AddCFGCheckBox(Mod, "Lite (FPS) Mode", "litemode", 0)
ASP.Util.AddCFGCheckBox(Mod, "Draw Players", "drawplayers", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Player Money", "drawplayermoney", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Player Distance", "drawplayerdist", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Player Weapon", "drawplayerweapon", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Player Health", "drawplayerhealth", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Player Rank", "drawrank", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Shipments", "drawshipments", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Printers", "drawprinters", 1)
ASP.Util.AddCFGCheckBox(Mod, "Draw Crosshair", "drawcrosshair", 1)
ASP.Util.AddCFGSlider(Mod, "Boxsize", "boxsize", 30, 10, 50)