--[[
	MOD/lua/includes/ASPModule.lua [#413 (#429), 2503820126]
	Bullet Time | STEAM_0:0:77769154 <82.238.182.218:27005> | [28.11.13 07:02:29PM]
	===BadFile===
]]

local t = {}
local m = {}
	t.__index = m

function ASPModule(title)
	local object = {}
		object.Title = title or "Unknown"
		object.ConVar = ""
		object.Think = function() end
		object.Draw = function() end
		object.SPEffects = function() end
		object.IsEnabled = {Think = false, Draw = false, RenderScene = false}
		object.HasConfig = false
	setmetatable(object, t)
	ASP.Util.AddModule(object)
	return object
end