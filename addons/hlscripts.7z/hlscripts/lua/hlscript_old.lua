-- Made by hl, Many thanks to Gravko for the help! Gravko credits for aimbot base!
-- Deligit hooking system and optimiziation of esp and xray a great help-

surface.PlaySound ("startup1.wav")
surface.PlaySound ("HL1/fvox/bell.wav")
MsgC (Color( 255, 171, 0 ), [[
                 ?MMMI                  
            MMMMMMMNNNNNNNN             
         OMMMMNNN.  . ONNNNNNN          
        MMMMN.            .DDDD+        
      NMMNN                  DDD8       
     NMNN      DDDDDD         D888      
    MNNN         8888.         ,OOO     
   .NNN           8OOO          OZOO    
   NNNO           OOZZ.          $ZZ    
   NNN           ZZZ$$$          777    
  .NDD          Z$$$7777         :II=   
   DDD         $$77 III?         ,??~   
   DD8        $77I.  ??++        =++    
   D888      77II.    ===.       ~~~    
   =88O     7II?      ~~~~~::   ::::    
    8OOZ   7I??.       ::::,.. ,,,,     
     OZ$$              .      ,,,,      
      $$7I?                  ....       
       :I?++=             ......        
         +==~~::,,    ........          
            ::,,............            
                ........                

HL SCRIPT LOADED!

]])





----------------- Menu code---------------
------- Credits Gmod wiki for help and code snippets--------
  concommand.Add ("hl_menu",function ()

 surface.PlaySound ("HL1/fvox/beep.wav")

 



local frame = vgui.Create( "DFrame" )
frame:SetSize( 500, 400 )
frame:Center()
frame:SetTitle( "HL Scripts ?�" )
frame:MakePopup()
frame.Paint = function()
	surface.SetDrawColor( 255, 115, 0, 150 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end




local sheet = vgui.Create( "DPropertySheet", frame )
sheet:Dock( FILL )
sheet.Paint = function()
	surface.SetDrawColor( 255, 115, 0, 150 )
	surface.DrawRect( 0, 0, sheet:GetWide(), sheet:GetTall() )
end






local panel1 = vgui.Create( "DPanel", sheet )
panel1.Paint = function( self, w, h ) draw.RoundedBox( 8, 0, 0, w, h, Color(0, 0, 0 ) ) end
sheet:AddSheet( "Visuals", panel1, "icon16/eye.png" )

local hllogo = vgui.Create( "DImage", Frame )	-- Add image to Frame
hllogo:SetParent( panel1 )
hllogo:SetPos( 340, 200 )	-- Move it into frame
hllogo:SetSize( 125, 125 )	-- Size it to 150x150
hllogo:SetImage( "hl2.jpg" )



local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "ESP" )
SheetItemTwo:SetPos (30,20)
SheetItemTwo:SetConVar( "hl_esp" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 19 )
DermaImage:SetImage( "icon16/eye.png" ) 
DermaImage:SizeToContents()





local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Entity finder" )
SheetItemTwo:SetPos (30,40)
SheetItemTwo:SetConVar( "hl_entity" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 39 )
DermaImage:SetImage( "icon16/magnifier.png" ) 
DermaImage:SizeToContents()

local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "X-Ray" )
SheetItemTwo:SetPos (30,60)
SheetItemTwo:SetConVar( "hl_xray" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 59 )
DermaImage:SetImage( "icon16/shape_ungroup.png" ) 
DermaImage:SizeToContents()



local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Admin Alert" )
SheetItemTwo:SetPos (30,80)
SheetItemTwo:SetConVar( "hl_adminalert" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 79 )
DermaImage:SetImage( "icon16/exclamation.png" ) 
DermaImage:SizeToContents()





local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Rainbow physgun" )
SheetItemTwo:SetPos (30,100)
SheetItemTwo:SetConVar( "hl_rainbow" )
SheetItemTwo:SizeToContents()
DermaImage:SetParent( panel1 )
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 99 )
DermaImage:SetImage( "icon16/color_wheel.png" ) 
DermaImage:SizeToContents()




local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Crosshair 1" )
SheetItemTwo:SetPos (30,120)
SheetItemTwo:SetConVar( "hl_crosshair" )
SheetItemTwo:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 119 )
DermaImage:SetImage( "icon16/bullet_green.png" ) 
DermaImage:SizeToContents()



local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Crosshair 2" )
SheetItemTwo:SetPos (30,140)
SheetItemTwo:SetConVar( "hl_crosshair2" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 139 )
DermaImage:SetImage( "icon16/bullet_red.png" ) 
DermaImage:SizeToContents()




local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Watermark" )
SheetItemTwo:SetPos (30,160)
SheetItemTwo:SetConVar( "hl_watermark" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 159 )
DermaImage:SetImage( "icon16/text_smallcaps.png" ) 
DermaImage:SizeToContents()



local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "Render Target Spy CAM" )
SheetItemTwo:SetPos (30,180)
SheetItemTwo:SetConVar( "hl_rendertargetspy" )
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel1 )
DermaImage:SetPos( 10, 179 )
DermaImage:SetImage( "icon16/camera.png" ) 
DermaImage:SizeToContents()



local SheetItemTwo = vgui.Create( "DCheckBoxLabel" , frame )
SheetItemTwo:SetParent( panel1 )
SheetItemTwo:SetText( "HUD" )
SheetItemTwo:SetPos (30,200)
SheetItemTwo:SetConVar( "hl_hud" )
SheetItemTwo:SizeToContents()



local panel2 = vgui.Create( "DPanel", sheet )
panel2.Paint = function( self, w, h ) draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0 ) ) end
sheet:AddSheet( "Aim", panel2, "icon16/arrow_in.png" )



local SheetItemTwo = vgui.Create( "DCheckBoxLabel", frame)
SheetItemTwo:SetParent( panel2 )
SheetItemTwo:SetPos( 30,20 )
SheetItemTwo:SetText( "Aimbot" )
SheetItemTwo:SetConVar( "hl_aimbot" ) 
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", frame )
DermaImage:SetParent( panel2 )
DermaImage:SetPos( 10, 19 )
DermaImage:SetImage( "icon16/arrow_in.png" ) 
DermaImage:SizeToContents()




local SheetItemTwo = vgui.Create( "DCheckBoxLabel", frame )
SheetItemTwo:SetParent( panel2 )
SheetItemTwo:SetPos( 30,40)
SheetItemTwo:SetText( "Aimbot Ignore Team" )
SheetItemTwo:SetConVar( "hl_aimbot_ignore_team" ) 
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", frame )
DermaImage:SetParent( panel2 )
DermaImage:SetPos( 10, 39 )
DermaImage:SetImage( "icon16/group_delete.png" ) 
DermaImage:SizeToContents()


local SheetItemTwo = vgui.Create( "DCheckBoxLabel", frame )
SheetItemTwo:SetParent( panel2 )
SheetItemTwo:SetPos( 30,60 )
SheetItemTwo:SetText( "Aimbot Ignore Friends" )
SheetItemTwo:SetConVar( "hl_aimbot_ignore_friends" ) 
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton",frame )
DermaImage:SetParent( panel2 )
DermaImage:SetPos( 10, 59 )
DermaImage:SetImage( "icon16/user_delete.png" ) 
DermaImage:SizeToContents()



local SheetItemTwo = vgui.Create( "DCheckBoxLabel",frame )
SheetItemTwo:SetParent( panel2 )
SheetItemTwo:SetPos( 30,80 )
SheetItemTwo:SetText( "Aimbot Ignore Buddies" )
SheetItemTwo:SetConVar( "hl_aimbot_ignore_buddies" ) 
SheetItemTwo:SizeToContents()
DermaImage = vgui.Create( "DImageButton", frame )
DermaImage:SetParent( panel2 )
DermaImage:SetPos( 10, 79 )
DermaImage:SetImage( "icon16/user_delete.png" ) 
DermaImage:SizeToContents()



local hllogo = vgui.Create( "DImage", Frame )	-- Add image to Frame
hllogo:SetParent( panel2 )
hllogo:SetPos( 340, 200 )	-- Move it into frame
hllogo:SetSize( 125, 125 )	-- Size it to 150x150
hllogo:SetImage( "hl2.jpg" )







 
local panel3 = vgui.Create( "DPanel", sheet )
panel3.Paint = function( self, w, h ) draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0 ) ) end
sheet:AddSheet( "Misc", panel3, "icon16/wand.png" )


local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetParent( panel3 )
CheckBoxThing:SetPos( 30,20 )
CheckBoxThing:SetText( "Auto-jump (Bhop)" )
CheckBoxThing:SetConVar( "hlbhop" )
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetParent( panel3 )
CheckBoxThing:SetPos( 30,40 )
CheckBoxThing:SetText( "Flashlight Spammer" )
CheckBoxThing:SetConVar( "hl_flashspam" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel3 )
DermaImage:SetPos( 10, 39 )
DermaImage:SetImage( "icon16/asterisk_orange.png" ) 
DermaImage:SizeToContents()


DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel3 )
DermaImage:SetPos( 10, 19 )
DermaImage:SetImage( "icon16/arrow_up.png" ) 
DermaImage:SizeToContents()


local hllogo = vgui.Create( "DImage", Frame )	-- Add image to Frame
hllogo:SetParent( panel3 )
hllogo:SetPos( 340, 200 )	-- Move it into frame
hllogo:SetSize( 125, 125 )	-- Size it to 150x150
hllogo:SetImage( "hl2.jpg" )





local DermaButton = vgui.Create( "DButton" , frame)
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Music" )
DermaButton:SetPos( 140, 240 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_music" )
end

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent (panel3)
DermaImage:SetPos( 140, 240)
DermaImage:SetImage( "icon16/sound_mute.png" ) 
DermaImage.DoClick = function ()
	RunConsoleCommand ("stopsound")
	end 
DermaImage:SizeToContents()




local DermaButton = vgui.Create( "DButton" , DermaPanel )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Add waypoint" )
DermaButton:SetPos( 30, 80 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_add_waypoint" )
end


local DermaButton = vgui.Create( "DButton", DermaPanel  )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Remove waypoint" )
DermaButton:SetPos( 30, 120 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_remove_waypoint" )
end



local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "180" )
DermaButton:SetPos( 30, 160)
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_180" )
end


local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Local chatroom" )
DermaButton:SetPos( 30, 240 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_localchat" )
end


local DermaButton = vgui.Create( "DButton" , DermaPanel)
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Help " )
DermaButton:SetPos( 30, 200 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_donate" )
end





local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "Duplicate Weapon" )
DermaButton:SetPos( 140, 200 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_wepdupe" )
end




local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetParent( panel3 )
DermaButton:SetText( "About" )
DermaButton:SetPos( 140,160 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "hl_about" )
end




DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent (panel3)
DermaImage:SetPos( 280, 32 )
DermaImage:SetImage( "icon16/application_osx_terminal.png" ) 
DermaImage:SizeToContents()

local DLabel = vgui.Create( "DLabel", Panel )
DLabel:SetParent (panel3)
DLabel:SetPos( 232, 30)
DLabel:SetText( "Run Lua" )

local DLabel = vgui.Create( "DLabel", Panel )
DLabel:SetParent (panel3)
DLabel:SetPos( 232.5, 58)
DLabel:SetText( "Chatspam" )

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetParent( panel3 )
CheckBoxThing:SetPos( 30,60 )
CheckBoxThing:SetText( "Chat Spammer" )
CheckBoxThing:SetConVar( "hl_chatspammer_nr" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent( panel3 )
DermaImage:SetPos( 10, 59)
DermaImage:SetImage( "icon16/comments.png" ) 
DermaImage:SizeToContents()



DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetParent (panel3)
DermaImage:SetPos( 280, 60 )
DermaImage:SetImage( "icon16/comments_add.png" ) 
DermaImage:SizeToContents()


local DermaText = vgui.Create( "DTextEntry", DermaPanel )
DermaText:SetParent (panel3)
DermaText:SetPos( 300,28 )
DermaText:SetTall( 20 )
DermaText:SetWide( 120 )
DermaText:SetEnterAllowed( true )
DermaText.OnEnter = function ()
	RunConsoleCommand ("hl_openscript", DermaText:GetValue())
		surface.PlaySound ("npc/scanner/scanner_scan2.wav")
		chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "LUA ENTERED")
end

local DermaText = vgui.Create( "DTextEntry", DermaPanel )
DermaText:SetParent (panel3)
DermaText:SetPos( 300,58 )
DermaText:SetTall( 20 )
DermaText:SetWide( 120 )
DermaText:SetEnterAllowed( true )
DermaText.OnEnter = function ()
  RunConsoleCommand ("hl_chatspammer_nr_message", DermaText:GetValue())
		chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "CHAT MESSAGE CONFIRMED")
		surface.PlaySound ("npc/scanner/scanner_scan1.wav")
end




















 
local panel4 = vgui.Create( "DPanel", sheet )
panel4.Paint = function( self, w, h ) draw.RoundedBox( 8, 0, 0, w, h, Color( 0, 0, 0 ) ) end
sheet:AddSheet( "Chat", panel4, "icon16/world_go.png" )

HTMLTEST = vgui.Create("HTML", DermaPanel)
HTMLTEST:SetParent( panel4 )
HTMLTEST:SetPos(10,10)
HTMLTEST:SetSize(450,300)
HTMLTEST:OpenURL(" http://darkv1lua.chatovod.com/")



end)



concommand.Add ("hl_help" ,function ()
MsgC (Color( 255, 171, 0 ),[[

                 ?MMMI                  
            MMMMMMMNNNNNNNN             
         OMMMMNNN.  . ONNNNNNN          
        MMMMN.            .DDDD+        
      NMMNN                  DDD8       
     NMNN      DDDDDD         D888      
    MNNN         8888.         ,OOO     
   .NNN           8OOO          OZOO    
   NNNO           OOZZ.          $ZZ    
   NNN           ZZZ$$$          777    
  .NDD          Z$$$7777         :II=   
   DDD         $$77 III?         ,??~   
   DD8        $77I.  ??++        =++    
   D888      77II.    ===.       ~~~    
   =88O     7II?      ~~~~~::   ::::    
    8OOZ   7I??.       ::::,.. ,,,,     
     OZ$$              .      ,,,,      
      $$7I?                  ....       
       :I?++=             ......        
         +==~~::,,    ........          
            ::,,............            
                ........                

                                        
                   ---------------------------------
                   -----LIST OF CONSOLE COMMANDS----
                   ---------------------------------
hl_menu -- Opens the menu
hl_xray -- toggles the general xray
hl_entity -- toggles the Entity finder/esp (printers,money,weapons)
hl_180 -- Do a 180 flip
hlbhop -- Toggles bunny hop
hl_chat-- Toggles the autospam default message is (ooc) hl is cool!
hl_music -- Toggles a hl2 song
hl_adminalert -- Toggles the admin alert
hlide_adminalert_distance -- Admin alert distance
hl_chatspammermer - Toggle the chatspam on and off default message is "default message"
hl_chatspammermer_msg -- You can change the chatspam message via the menu press enter on the chatspam input or do hl_chatspammer yourmessagehere
hl_flashspam -- Toggles the Flashlight spammer!
hl_rainbow - Toggles the rainbow physgun, It is clientside only so YOU only see this!
hl_unload -- Unloads the script! (Exits the script May be buggy)
hl_aimbot -- Toggles the aimbot, Hold E to activate
hl_aimbot_ignore_buddies -- Toggles the aimbot to ignore buddies
hl_aimbot_ignore_friends -- Toggles the aimbot to ignore friends
hl_aimbot_ignore_team -- Toggles the aimbot to ignore teammates
hl_rendertargetspy -- Toggles the render target spy camera, Server must have render target camera for this to work!
hl_crosshair 1 -- Toggles the first crosshair
hl_crosshair 2 -- toggles the second crosshair
hl_help -- Prints help message
hl_globalchat - Access a global chatroom to speak to other users of lua scripts!
hl_localchat -- Speak to other hls scripts V1 and shittyscripts users on the same server.
]]) 
end )
 
if hl then
        rawset(_G, "hl", nil)
end
 
local hl = {} // make local table
 
hl.g = table.Copy(_G); // copy _G
 
function hl.Copy(t, lookup_table)
    if (t == nil) then return nil end
    local copy = {}
    setmetatable(copy, getmetatable(t))
        for i,v in pairs(t) do
            if ( !istable(v) ) then
                     copy[i] = v
                else
                    lookup_table = lookup_table or {}
                    lookup_table[t] = copy
                    if lookup_table[v] then
                        copy[i] = lookup_table[v]
                    else
                        copy[i] = hl.Copy(v,lookup_table) --
                    end
                end
        end
    return copy
end
 
hl.new_gm_hooks                       = {};
hl.gm_hooks                           = {};                              
hl.old_gm_hooks                       = {};
hl.OrigFuncs                          = {};
hl.FakeFuncs                          = {};
hl.CmdHooks                           = {};
hl.Plys                                       = {} // table for valid players
hl.me                                         = hl.g.LocalPlayer()
hl.gm                                         = table.Copy(GAMEMODE)
hl.cm                                         = hl.Copy(hl.g.FindMetaTable("CUserCmd")) // we need these
hl.am                                         = hl.Copy(hl.g.FindMetaTable("Angle")) // we need these
hl.vm                                         = hl.Copy(hl.g.FindMetaTable("Vector")) // we need these
hl.wm                                         = hl.Copy(hl.g.FindMetaTable("Weapon")) // we need these
hl.em                                         = hl.Copy(hl.g.FindMetaTable("Entity")) // we need these
hl.pm                                         = hl.Copy(hl.g.FindMetaTable("Player")) // we need these
hl.r                                          = hl.Copy(hl.g.debug.getregistry()) // we need these
hl.ConCMD                                     = hl.Copy(concommand)
hl.odbginf                            = debug.getinfo;
hl.ogmt                                       = getmetatable;
hl.shouldbhop                         = CreateClientConVar("hlbhop", "1", true, true)
hl.xrei                                       = CreateClientConVar("hl_xray", 0, false, false)
hl.adminwarning                       = CreateClientConVar("hl_adminalert", "1", true, false)
 hl.espon                     = CreateClientConVar("hl_esp", "1", false, false)
 
 
 
hl.g.surface.CreateFont(
        "hlfont", {
            font = "Default",
size = 15,                   
weight = 250,
        }
)







 
function hl.DetourFunc(func, newfunc) // luv from deligit to my nigga Function <3
    hl.g.table.insert(hl.OrigFuncs, func);
    hl.g.table.insert(hl.FakeFuncs, newfunc);
end
 
function hl.CopyTable(t, lookup_table)
    if (t == nil) then return nil end
    local copy = {}
    setmetatable(copy, getmetatable(t))
        for i,v in hl.g.pairs(t) do
            if ( !istable(v) ) then
                     copy[i] = v
                else
                    lookup_table = lookup_table or {}
                    lookup_table[t] = copy
                    if lookup_table[v] then
                        copy[i] = lookup_table[v]
                    else
                        copy[i] = hl.CopyTable(v,lookup_table) --
                    end
                end
        end
    return copy
end
 
setmetatable(_G, {
        ['__index'] = function(self, k)
                if k == "hl" then
                        return hl;
        end
    end,
    ['__newindex'] = function(self, k, v)
                hl.g.rawset(self, k, v);
                if k == "GAMEMODE" then
                        for k,v in hl.g.pairs(GAMEMODE) do
                                hl.old_gm_hooks[k] = v;
            end
                        local GMTbl = GAMEMODE;
                        if !(getmetatable(GMTbl)) then
                                setmetatable(GMTbl, {
                                        ['__newindex'] = function(self, k, v)
                                                hl.old_gm_hooks[k] = v;
                                        end,
                                        ['__call'] = function(self, k, id, v)
                                                if (not hl.gm_hooks[k]) then hl.gm_hooks[k] = {}; end
                                                hl.gm_hooks[k][id] = v
                                                        if (not hl.new_gm_hooks[k]) then
                                                                hl.new_gm_hooks[k] = function(GM, ...)
                                                                        if (hl.old_gm_hooks[k]) then
                                                                                hl.old_gm_hooks[k](GM, ...);
                                                                        end
                                                                        for k,v in hl.g.pairs(hl.gm_hooks[k]) do
                                                                                v(...);
                                                                        end
                                                                end
                                                                hl.DetourFunc(hl.old_gm_hooks[k], hl.new_gm_hooks[k]);
                                                        end    
                                                hl.g.rawset(self, k, hl.new_gm_hooks[k]);
                                        end,
                                        ['__index'] = function(self, k)
                                                local returnval = hl.old_gm_hooks[k] or rawget(self, k);
                                                return returnval
                                        end,
                                });
            end
        end
    end,
});
 
function hl.Hook(typ, func)
        if hl.gm[typ] and GAMEMODE[typ] then
                GAMEMODE[typ] = function(...)
                        hl.gm[typ](...)
                        func(...)
                end
        end
end
 
local ndbginf = function(func, ...)
        local args = {...};
        local targ = func;
        local arg = args[1] or false;
        for i, fakefunc in hl.g.pairs(hl.FakeFuncs) do
                if (func == fakefunc) then
                        targ = hl.OrigFuncs[i];
                        break;
                end
        end
        local tbl = arg and hl.odbginf(targ, arg) or hl.odbginf(targ);
        if (tbl.func) then tbl.func = func; end
        return(tbl)
end
 
local ngmt = function(tbl, ...)
if (hl.gdebug.traceback() and (tbl == _G or tbl == GAMEMODE)) then return nil; end
        return hl.ogmt(tbl, ...);
end
 
hl.DetourFunc(debug.getinfo,   ndbginf);
debug.getinfo   = ndbginf;
 
function hl.GetPlys() // faster than calling player.GetAll all the time
        hl.Plys = {}
        local humans = hl.g.player.GetAll()
        for i = 1, #humans do
                local v = humans[i]
                if (!IsValid(v) || v == hl.me || !v:Alive() || v:Health() < 1) then continue end
                hl.Plys[i] = v
                hl.Plys[i] = v
        end
        hl.g.timer.Simple(2, hl.GetPlys) // better than using hooks
end
 
 hl.GetPlys()
 
 
 
 
 hl.Hook("DrawOverlay", function(ucmd)
        local humans = hl.g.player.GetAll()
		if hl.espon:GetBool() then
        for k,v in next, humans do
                if (!IsValid(v) || v == hl.me || !v:Alive() || v:Health() < 1 || v:Name() == nil) then continue end
                local c = v:LocalToWorld( v:OBBCenter() ):ToScreen()
               -- hl.g.draw.SimpleTextOutlined( v:Name(), "hlhud", c.x, c.y + 20, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- hl.g.draw.SimpleTextOutlined( v:Health(), "hlhud", c.x, c.y - 10, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- hl.g.draw.SimpleTextOutlined( team.GetName( v:Team()), "hlhud", c.x, c.y, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- hl.g.draw.SimpleTextOutlined( v:GetUserGroup(), "hlhud", c.x, c.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                -- hl.g.draw.SimpleTextOutlined( hl.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "hlhud", c.x, c.y - 20, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0))
        
	hl.g.draw.SimpleTextOutlined( v:Name(), "hlfont", c.x , c.y - 25, Color(255,255,255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0 , 0 ))
		

		hl.g.draw.SimpleTextOutlined( v:Health(), "hlfont", c.x , c.y  - 45, Color(255,255,255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0 , 0 ))
		 
		 hl.g.draw.SimpleTextOutlined( v:GetUserGroup(), "hlfont", c.x , c.y - 35, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0 , 0 ))

		 hl.g.draw.RoundedBox( 3, c.x - 10 , c.y - 65, 15,  5, (team.GetColor( v:Team() )))	
		hl.g.draw.SimpleTextOutlined( math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "hlfont", c.x , c.y  - 55, Color(255,255,255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0 , 0 ))

		
		end
	end
end)
 

 
 
 
 -------------- ESP POSISTIONING ON THIS VERSION IS SCREWED UP DONT UPLOAD WITH THIS ACTIVE UNTIL THE ESP IS FULLY FIXED ALSO EXPERIMENTAL METHODS OF DOING THINGS ARE HERE MUST DO SURVEYS/OPINIONS BEFORE USING THIS VERSION!
---hl.Hook("DrawOverlay", function(ucmd)
       --- local humans = hl.g.player.GetAll()
       ---- for k,v in next, humans do
            ----    if (!IsValid(v) || v == hl.me || !v:Alive() || v:Health() < 1 || v:Name() == nil) then continue end
            -----    local c = v:LocalToWorld( v:OBBCenter() ):ToScreen()
				
				-------------- ESP POSISTIONING ON THIS VERSION IS SCREWED UP DONT UPLOAD UNTIL THE ESP IS FULLY FIXED ALSO EXPERIMENTAL METHODS OF DOING THINGS ARE HERE MUST DO SURVEYS/OPINIONS BEFORE USING THIS VERSION! 
				
				--- hl.g.draw.RoundedBox( 6, c.x - 26, c.y - 100, 50,  70, Color( 255, 255, 255, 100 ) ) --- need to get peoples opinions before i can use this
				
				----hl.g.draw.SimpleTextOutlined( hl.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "hlhud", c.x - 20, c.y - 90, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0))
                
				---hl.g.draw.WordBox( 8, c.x - 26, c.y - 100, v:Health(), "hlhud", team.GetColor( v:Team() ), Color(255,255,255,255) ) -- maybe good idea??????????????????? wordboxes look good but are big and cant make any smaller,.,
				
				----hl.g.draw.WordBox( 8, c.x - 26, c.y - 100, ( team.GetName( v:Team())), "hlhud", team.GetColor( v:Team() ), Color(255,255,255,255) )
				
				
				---- hl.g.draw.SimpleTextOutlined( team.GetName( v:Team()), "hlhud", c.x - 20 , c.y - 80 , team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
				
               -----  hl.g.draw.SimpleTextOutlined( v:Health(), "hlhud", c.x - 20, c.y  - 70, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                
               ----  hl.g.draw.SimpleTextOutlined( v:GetUserGroup(), "hlhud", c.x - 20, c.y - 60, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
				
				---- hl.g.draw.SimpleTextOutlined( v:Name(), "hlhud", c.x - 20, c.y  - 50, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                
		          

	  ----  end
---- end)
 
hl.Hook("CreateMove", function(data, ucmd)
        if (ucmd:KeyDown(2) && !hl.me:IsOnGround() && hl.shouldbhop:GetBool()) then
        ucmd:SetButtons( bit.band( ucmd:GetButtons(), bit.bnot(2) ) );
        end
end)
 
local pm = FindMetaTable("Player");
 
local ogethands = hl.pm.GetHands; -- Note: Only for c_ viewmodels
 
function pm.GetHands(...)
        return false && ogethands(...);
end
 
function hl.AdminAlert()
        if hl.adminwarning:GetBool() then
        for k,v in next, hl.Plys do
                        local amdminipos = v:LocalToWorld(v:OBBCenter()):ToScreen()
                        local admindist = hl.g.math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
                        if v:GetUserGroup() != "user" and v != LocalPlayer() then
                                hl.g.draw.DrawText( "An admin is nearby!", "DermaLarge", ScrW() * 0.5, ScrH() * 0.7, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER )
                                hl.g.surface.PlaySound ("vo/trainyard/female01/cit_bench01.wav")
                                hl.g.surface.SetDrawColor(255,0,0)
                                hl.g.surface.DrawLine(ScrW() * .5, ScrH() * .5, amdminipos.x, amdminipos.y)
                        end
                end
        end
end
 
local chamsmat = hl.g.CreateMaterial("z", "VertexLitGeneric", {
        ["$ignorez"] = 1,
        ["$model"] = 1,
        ["$basetexture"] = "models/debug/debugwhite",
});
 
local chamsmat2 = hl.g.CreateMaterial("y", "vertexlitgeneric", {
        ["$ignorez"] = 0,
        ["$model"] = 1,
        ["$basetexture"] = "models/debug/debugwhite",
});
 
hl.xraymat = hl.g.CreateMaterial(hl.g.util.CRC("hl_xraymat"), "VertexLitGeneric", {
        ["$basetexture"] = "models/debug/debugwhite"
})
 
hl.Hook("HUDPaint", function()
        local allprops = hl.g.ents.FindByClass("prop_physics")
        for i = 1, #allprops do
                local v = allprops[i]
                if !hl.em.IsValid(v) then continue end
                if !hl.xrei:GetBool() then
                        hl.em.SetNoDraw(v, false)
                        continue
                end
                hl.g.cam.Start3D()
                        hl.g.render['SuppressEngineLighting'](true)
                        hl.g.render['MaterialOverride'](hl.xraymat)
                        hl.g.render.SetColorModulation(255,145,0)
						v:SetColor(Color(255,255,255))
                        hl.g.render.SetBlend(0.10)
                        hl.em.DrawModel(v)
                        hl.em.SetNoDraw(v, true)
                        hl.g.render['SuppressEngineLighting'](false)
                       
                        hl.em.DrawModel(v)
                hl.g.cam.End3D()
        end
        if !ShowSpec then return end
        local spectatePlayers = {}
        local x = 0
        for k,v in hl.g.next, hl.Plys do
            if v:GetObserverTarget() == LocalPlayer() then
                hl.g.table.insert(spectatePlayers, v:Name())
                        end
        end
        if #spectatePlayers == 0 then return end
        local textLength = surface.GetTextSize(hl.g.table.concat(spectatePlayers) ) / 3
        hl.g.draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
        hl.g.draw.SimpleText("Spectators", "TabLarge", ScrW() - 140, ScrH() - ScrH() + 18, Color(130, 0, 255, 255))
        hl.g.draw.SimpleText("Spectators", "TabLarge", ScrW() - 140, ScrH() - ScrH() + 16, Color(0, 255, 25, 255))
        for k,v in hl.g.next, spectatePlayers do
        hl.g.draw.SimpleText(v, "TabLarge", ScrW() - 140, ScrH() - ScrH() + 37 + x, Color(130, 0, 255, 255))
                hl.g.draw.SimpleText(v, "TabLarge", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(75, 255, 25, 255))
        x = x + 15
    end
end)

// ?


chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "HL SCRIPT ONLINE...")
chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ENTER HL_MENU INTO THE CONSOLE")
chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ALL SYSTEMS ONLINE")


cvars.AddChangeCallback("hl_xray", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_xray") == 1 then
			surface.PlaySound ("npc/sniper/reload1.wav")
				chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "X-RAY IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_xray") == 0 then
				chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "X-RAY IS TURNED", Color( 255,110,0 ), "  OFF" )
			surface.PlaySound ("vehicles/APC/apc_shutdown.wav")
		end
end)
 
 cvars.AddChangeCallback("hlbhop", function(convar_name, value_old, value_new)
		if GetConVarNumber("hlbhop") == 1 then
			surface.PlaySound ("ambient/machines/thumper_startup1.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AUTOJUMP IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hlbhop") == 0 then
				chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AUTOJUMP IS TURNED", Color( 255,110,0 ), "  OFF" )
			surface.PlaySound ("buttons/combine_button5.wav")
		end
end)
 
  cvars.AddChangeCallback("hl_entity", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_entity") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ENTITY FINDER IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_entity") == 0 then
		chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ENTITY FINDER IS TURNED", Color( 255,110,0 ), "  OFF!")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
   cvars.AddChangeCallback("hl_adminalert", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_adminalert") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ADMIN ALERT IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_adminalert") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ADMIN ALERT IS TURNED",Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
 
    cvars.AddChangeCallback("hl_chatspammer_nr", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_chatspammer_nr") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AUTOMATIC CHAT SPAM IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_chatspammer_nr") == 0 then 
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AUTOMATIC CHAT SPAM IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
 
 
     cvars.AddChangeCallback("hl_flashspam", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_flashspam") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "FLASHLIGHT SPAMMER IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_flashspam") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "FLASHLIGHT SPAMMER IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
      cvars.AddChangeCallback("hl_rainbow", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_rainbow") == 1 then
			surface.PlaySound ("ambient/energy/whiteflash.wav")
				chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "REACTIVE COLOUR PHYSGUN IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_rainbow") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "REACTIVE COLOUR PHYSGUN IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/roller/code2.wav")
		end
end)
 
 
 
       cvars.AddChangeCallback("hl_hud", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_hud") == 1 then
			surface.PlaySound ("npc/scanner/combat_scan2.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ON SCREEN HUD IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_hud") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ON SCREEN HUD IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/scanner/combat_scan5.wav")
		end
end)
 
 
 
        cvars.AddChangeCallback("hl_watermark", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_watermark") == 1 then
			surface.PlaySound ("npc/scanner/combat_scan2.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "WATERMARK IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_watermark") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ON SCREEN HUD IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/scanner/combat_scan5.wav")
		end
end)
 

         cvars.AddChangeCallback("hl_crosshair", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_crosshair") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ASSISTANCE CROSSHAIR IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_crosshair") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ASSISTANCE CROSSHAIR IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)



 
         cvars.AddChangeCallback("hl_crosshair2", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_crosshair2") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "2ND ASSISTANCE CROSSHAIR IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_crosshair2") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "2ND ASSISTANCE CROSSHAIR IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)




         cvars.AddChangeCallback("hl_esp", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_esp") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ESP IS TURNED", Color( 13, 255, 134 ), "  ON")
		elseif GetConVarNumber("hl_esp") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "ESP IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)


         cvars.AddChangeCallback("hl_aimbot", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_aimbot") == 1 then
			surface.PlaySound ("weapons/ar2/ar2_reload_rotate.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT IS TURNED", Color( 13, 255, 134 ), "  ON")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "HOLD THE E KEY TO ACTIVATE THE AIMBOT")
			
			

		elseif GetConVarNumber("hl_aimbot") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT IS TURNED", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/overwatch/radiovoice/off4.wav")
		end
end)


         cvars.AddChangeCallback("hl_aimbot_ignore_buddies", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_aimbot_ignore_buddies") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW IGNORE BUDDIES")
		elseif GetConVarNumber("hl_aimbot_ignore_buddies") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW TARGET BUDDIES")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)


         cvars.AddChangeCallback("hl_aimbot_ignore_friends", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_aimbot_ignore_friends") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW IGNORE FRIENDS")
		elseif GetConVarNumber("hl_aimbot_ignore_friends") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW TARGET FRIENDS")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)

         cvars.AddChangeCallback("hl_aimbot_ignore_team", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_aimbot_ignore_team") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW IGNORE TEAMMATES")
		elseif GetConVarNumber("hl_aimbot_ignore_team") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "AIMBOT WILL NOW TARGET TEAMMATES")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)


         cvars.AddChangeCallback("hl_rendertargetspy", function(convar_name, value_old, value_new)
		if GetConVarNumber("hl_rendertargetspy") == 1 then
			surface.PlaySound ("npc/combine_gunship/ping_search.wav")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "RENDER TARGET SPY CAM IS NOW", Color( 13, 255, 134 ), "  ON")
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "SERVER MUST HAVE RENDER TARGET SPY CAMERA FOR THIS FEATURE TO ACTIVATE.")
		elseif GetConVarNumber("hl_rendertargetspy") == 0 then
			chat.AddText( Color( 0, 0, 0 ) ,"[" ,  Color( 255, 145, 0),"?",  Color (0,0,0), "]" , Color (255,255,255), "RENDER TARGET SPY CAM IS", Color( 255,110,0 ), "  OFF")
			surface.PlaySound ("npc/combine_gunship/gunship_ping_search.wav")
		end
end)


 
hl.Hook("RenderScreenspaceEffects", function()
        if hl.xrei:GetBool() then
		
                for k,v in hl.g.next, hl.Plys do
                if(!hl.em.IsValid(v) || hl.em.Health(v) < 1 || v == hl.me || hl.em.IsDormant(v)) then continue; end
                        hl.g.cam.Start3D();
                                hl.g.render.MaterialOverride(chamsmat);
                                hl.g.render.SetColorModulation(1,1,1);
                                hl.em.DrawModel(v);
                                hl.g.render.SetColorModulation(1,1,1);
                                hl.g.render.MaterialOverride(chamsmat2);
                                hl.em.DrawModel(v);
                        hl.g.cam.End3D();
                end
        end
end)
 
hl.ConCMD['Add']("hl_openscript", function( ply, cmd, args )
        local lua = hl.g.file.Read( args[1] )
        hl.g.RunString( lua )
end )
 
hl.ConCMD['Add']("showspecs", function(ply, command, args)
    ShowSpec = !ShowSpec
end)
 
hl.ConCMD['Add']("hl_180", function()
        LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p,180, 0) )
end)
 
hl.ConCMD['Add']("hl_music", function()
        hl.g.surface.PlaySound("music/HL2_song23_SuitSong3.mp3")
end)
 
 local espCvar = CreateClientConVar("hl_entity", 1, false, false)

cvars.AddChangeCallback( "hl_entity", function( cvar, old, new )
    enableESP = tobool( new )
end, "updatevalue" )

local enableESP = espCvar:GetBool()

local lookup = {
    money_printer  = true,
    spawned_weapon = true,
	spawned_money = true,
	
}

local itemOffset = Vector( 8, -10, 30 )
local swepOffset = Vector( 3, 0, 20 )
local moneyOffset = Vector( 3, 0, 10 )


local itemColor = Color( 255, 255, 0 )
local swepColor = Color( 255, 0, 0 )
local moneyColor = Color( 0, 255, 0 )


hook.Add( "HUDPaint", "ESP", function()
    if ( not enableESP ) then return end
    
    local pos, ent
    local entTable = ents.GetAll()
    
    for i = 1, #entTable do
        ent = entTable[ i ]
        if ( not IsValid( ent ) )           then continue end
        if ( not lookup[ ent:GetClass() ] ) then continue end

        if ( ent:GetClass() == "money_printer" ) then
        ------ new wordboxes!----
		
            pos = ( ent:GetPos() + itemOffset ):ToScreen()
           -- draw.SimpleTextOutlined( "Money Printer", "Trebuchet18", pos.x, pos.y, itemColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Money Printer", "Trebuchet18",  Color(128,128,128,100), Color(255,0,0,255))
			
			
        elseif ( ent:GetClass() == "spawned_weapon" ) then
        
            pos = ( ent:GetPos() + swepOffset ):ToScreen()
            ---draw.SimpleTextOutlined( "Weapon", "Trebuchet18", pos.x, pos.y, swepColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Weapon", "Trebuchet18",  Color(128,128,128,100), Color(255,230,0,255))
			
		elseif ( ent:GetClass() == "spawned_money" ) then
        
            pos = ( ent:GetPos() + moneyOffset ):ToScreen()
            ---draw.SimpleTextOutlined( "Money", "Trebuchet18", pos.x, pos.y, moneyColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Money", "Trebuchet18",  Color(128,128,128,100), Color(0,255,40,255))
			
			
			end
        end
    
end )
 
concommand.Add( "hl_about", function()
	Derma_Message( "This addon was made by Dark. A remake of darks scripts v1!", "About", "OK" )

 end)
 

 
  

 
concommand.Add( "hl_about", function()
	Derma_Message( "This addon was made by hl.", "About", "OK" )
	surface.PlaySound ("notify.wav")
 end)
 

 
  
 
 
 concommand.Add ("hl_donate", function ()
 
local frame = vgui.Create( "DFrame" )
frame:SetTitle( "View the advertisment then click skip ad, Thank you!" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()

frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end

frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( " http://adf.ly/13250485/thank-you-for-helping" )
end)

 
 concommand.Add ("hl_donate", function ()
 
local frame = vgui.Create( "DFrame" )
frame:SetTitle( "View the advertisment then click skip ad, Thank you!" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()

frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end

frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( " http://adf.ly/13250485/thank-you-for-helping" )
end)



 


hl.g.notification.AddProgress("lol", "HL SCRIPTS ONLINE")
hl.g.timer.Simple(5, function() hl.g.notification.Kill("lol") end)

----- Chat spammer -----


--- This is a big f you to Nrgaming, Banning people for clientside lua scripts even though you have sv_allowcslua 1 and are clearly aware of the value
--- If you continue doing this I'm just going to keep bringing out updates with even more insulting messages towards you.
--- If you have a problem with my script, I don't mind you disabling lua on your server and then doing this but you allow clientside lua then ban people for it.
-- Extremely unethical and wrong to do.


CreateClientConVar("hl_chatspammer_nr_message", "Default message", false, false)
CreateClientConVar("hl_chatspammer_nr", "0", false, false)
hook.Add("Think", "hl_chatspammer_hook", function()
if GetConVarNumber("hl_chatspammer_nr") != 1 then return end
     RunConsoleCommand("say", tostring(GetConVarString("hl_chatspammer_nr_message")))
 
end)

---- flashlight spammer---- 
CreateClientConVar("hl_flashspam", "0", true, false)
hook.Add("Think", "hlflash", function()
if GetConVarNumber("hl_flashspam") != 1 then return end
     RunConsoleCommand("impulse", "100")
end)





---------watermark---------------
CreateClientConVar ("hl_watermark","1", true ,false )
hook.Add("HUDPaint", "watermark",function() 
	if GetConVarNumber("hl_watermark") != 1 then return end
		surface.DrawRect( 0, 0, 100, 25 )
		draw.SimpleTextOutlined( "? HL SCRIPTS", "trebuchet18", 5,  5,  Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 155 , 0 ))
end)




surface.CreateFont( "hlhud2", {
	font = "trebuchet18",
	size = 30,
	weight = 500,
	 } )

-------- HUD must be updated to show more info, possibly admin stuff too.------------------
RunConsoleCommand ("hl_hud","1")
RunConsoleCommand ("hl_watermark","1")
CreateClientConVar ("hl_hud","1", true ,false )
hook.Add("HUDPaint", "huddesign",function() 
	if GetConVarNumber("hl_hud") != 1 then return end
		local showvel = math.floor(LocalPlayer():GetVelocity():Length())


local lp = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()

--Layer: 1
draw.RoundedBox(4, ScrW()/3.1, ScrH()/1.04, ScrW()/2.91, ScrH()/27, Color(0, 0, 0, 220))

--Layer: 2
draw.DrawText("SPEED: "..showvel, "hlhud2", ScrW()/2.18, ScrH()/1.04, Color(255, 155, 0, 225))



				
				
				

		---local coolglow = Material("models/props_combine/combine_fenceglow") 
       ----  surface.SetMaterial(coolglow)
        --- surface.SetDrawColor(Color(41, 128, 185, 255))
        --- surface.DrawTexturedRect(300, ScrH()-105, 340, 100, Color(41, 128, 185, 255))
			
end)


---- workshop crosshairs modified until I figure out a more efficent method----
CreateClientConVar ("hl_crosshair","1", true ,false )
hook.Add("HUDPaint", "crosshair",function() 
	if GetConVarNumber("hl_crosshair") != 1 then return end
		local x = ScrW() / 2
	local y = ScrH() / 2
    surface.SetDrawColor( 0, 255, 0, 255 )
    local gap = 5
	local length = gap + 15
 

		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
 
		
end)
CreateClientConVar ("hl_crosshair2","0", true ,false )
hook.Add("HUDPaint", "crosshair2",function() 
	if GetConVarNumber("hl_crosshair2") != 1 then return end
		local x = ScrW() / 2
	local y = ScrH() / 2
    surface.SetDrawColor( 255, 0, 0, 255 )
    local gap = 2
	local length = gap + 15
 

		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		
end)



---surface.DrawLine good method  i hope






CreateClientConVar ("hl_rendertargetspy","0", true ,false )
hook.Add("HUDPaint", "rendertarget",function() 
if GetConVarNumber("hl_rendertargetspy") != 1 then return end
local lp = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()

local Texture1 = Material("models/rendertarget") 
surface.SetMaterial(Texture1)
surface.SetDrawColor(Color(41, 128, 185, 255))
surface.DrawTexturedRect(20, 215, 300, 240, Color(41, 128, 185, 255))


 end)
 





// Thank you for the help  Gravko :) Hopefully this will stop him.
function ConVarExists( sn )
MsgC( Color( 255, 0, 0 ), "Blocked!\n" )
end 

local realNS = net.Start

function net.Send( nstr )
	if nstr == "Iamscriptinglikeascriptkiddy" then
		chat.AddText("Blocked net.send")
	else
		return realNS( nstr )
	end
end


local shitAim = {}
shitAim.TargetMethod = {}
shitAim.Settings = {}
shitAim.TargetMethod["rage"] = false
shitAim.TargetMethod["closest"] = true
shitAim.TargetMethod["aimpoint"] = false
shitAim.Settings["sAimbone"] = "ValveBiped.Bip01_Head1"
shitAim.Settings["AimBotKey"] = KEY_E

local function HasHead(ent)
	local bone = ent:LookupBone(shitAim.Settings["sAimbone"])
	if bone then
		return true 
	else
		return false
	end
end

local function CanSeeHead(ent)
		local wishedbone  = ent:LookupBone(shitAim.Settings["sAimbone"])
		local trendpos = ent:GetBonePosition(wishedbone)
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = trendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

local function CanSeeOBB(ent)
		local obbendpos = ent:LocalToWorld(ent:OBBCenter())
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = obbendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

// Thank You Gravko For letting me use the base, Will be adding additional features soon

CreateClientConVar("hl_aimbot", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_friends", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_buddies", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_team", "0", false, false)

local Locked
local aimBuddies = {}


local target






local function distance_formula(vec, vec2)

    if(type(vec) != "Vector" || type(vec2) != "Vector") then
        return;
    end
    
    return (vec.z != nil && vec2.z != nil) && ((vec2.x - vec.x)^2 + (vec2.y - vec.y)^2 + (vec2.z - vec.z)^2)^1/2 || ((vec2.x - vec.x)^2 + (vec2.y - vec.y)^2)^1/2
    
end

print(distance_formula(Vector(1, 7), Vector(3, 7)))



local function shitaimbot(cmd)

if GetConVarNumber("hl_aimbot") != 1 then return end

	local AimBone
	local lpos = LocalPlayer():GetShootPos()
	

	
	
	local aimPlayers = {}
	for _, v in pairs(player.GetAll()) do
	
		table.insert(aimPlayers, v)
		
		if GetConVarNumber("hl_aimbot_ignore_team") == 1 then
			if v:Team() == LocalPlayer():Team() then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if GetConVarNumber("hl_aimbot_ignore_friends") == 1 then
			if v:GetFriendStatus() != "none" then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if v == LocalPlayer() then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if !CanSeeOBB(v) then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if v:Team() == TEAM_SPECTATOR then
			table.RemoveByValue(aimPlayers, v)
		end
			
	end



	
	if shitAim.TargetMethod["rage"] then
		for _, v in pairs(aimPlayers) do
			if v:Alive() then
				target = v
			end
		end
	end
	
	if shitAim.TargetMethod["closest"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetPos():Distance(v:GetPos():ToScreen())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end

	if shitAim.TargetMethod["aimpoint"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetEyeTrace().HitPos:Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end


for _, b in pairs(aimPlayers) do
	if !HasHead(target) then
		AimBone = target:LocalToWorld(target:OBBCenter())
		else
		AimBone = target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1"))
	end
end



	
			if input.IsKeyDown(shitAim.Settings["AimBotKey"]) then
				if GetConVarNumber("hl_aimbot_ignore_team") == 1 and target:Team() == LocalPlayer():Team() then return end
				if GetConVarNumber("hl_aimbot_ignore_friends") == 1 and target:GetFriendStatus() != "none" then return end
				if !AimBone then return end
				
				cmd:SetViewAngles((AimBone - lpos):Angle())
			end
end



cvars.AddChangeCallback("hl_aimbot", function()
        if GetConVarNumber("hl_aimbot") == 1 then
                hook.Add("CreateMove", "aimbotshit", shitaimbot)
        else
                hook.Remove("aimbotshit")
        end
end)


local ents = ents




CreateClientConVar ("hl_rainbow", "0", true, false )
hook.Add("Think","hlrainbow",function()
if GetConVarNumber ("hl_rainbow") != 1 then return end
	LocalPlayer():SetWeaponColor(VectorRand())
end)


hook.Add( "OnPlayerChat", "HelloCommand", function( typer, strText, bTeam, bDead )
	strText = string.lower( strText ) 
	if ( strText == "hlsend" ) then
	
	 //  if ( string.find(strtText, "hlsend")) then

		print( typer, "hl acknowledge" ) 
	   
	    RunConsoleCommand ("say" ,"/radio hlACK")
		chat.AddText( Color( 100, 100, 255 ), typer, ",sent a message! ") 
			surface.PlaySound ("rx.wav")
		return true
	end

end )



concommand.Add( "hl_ping_rp", function()
	RunConsoleCommand ("say" ,"/radio hlsend")
	surface.PlaySound ("tx.wav")

 end)

 
 RunConsoleCommand ("say", "/channel 75")
 
//local GAD_Chat = CreateClientConVar( "hl_adblock_chat", 1, true, false )
//local GAD_Sound = CreateClientConVar( "hl_adblock_sound", 1, true, false )
 
//function MOTDgd.GetIfSkip()
     //   if GAD_Chat:GetBool() then
    //        chat.AddText( Color( 255, 0, 0 ), "Ad ", Color( 29, 0, 255 ), "removed by ", Color( 0, 255, 255 ), "GAD BLOCK! (Credits to Hackcraft!)" )
    //    end
    //    if GAD_Sound:GetBool() then
    //        surface.PlaySound( table.Random({
   //         "ambient/levels/citadel/portal_beam_shoot1.wav",
    //        "ambient/levels/citadel/portal_beam_shoot2.wav",
  //          "ambient/levels/citadel/portal_beam_shoot3.wav",
   //         "ambient/levels/citadel/portal_beam_shoot4.wav",
   //         "ambient/levels/citadel/portal_beam_shoot5.wav",
   //         "ambient/levels/citadel/portal_beam_shoot6.wav"
//}))
//        end
//        return true
//end
 
 
 //
 //local function channelchanger (
 
// if gamemode.Get("hlrp") then 
// RunConsoleCommand ("say" ,"/channel 75")
// else return end 
 
// end)

concommand.Add ("hl_globalchat", function ()
local frame = vgui.Create( "DFrame" )
frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end
frame:SetTitle( "hl's scripts global chat" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()
frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( "http://hlv1lua.chatovod.com/" )
end)




RunConsoleCommand( "say", "/channel 75" )
 
 

local chat_scripts = {}
chat_scripts["DS"] = { Color(72,72,72,255), "D", Color(255,255,0,255), "S" }
chat_scripts["JS"] = { Color(255,0,0,255), "J", Color(29,0,255,255), "S" }
chat_scripts["AW"] = { Color(255,191,0,255), "A", Color(255,93,0,255), "W" }
chat_scripts["SS"] = { Color(255,0,0,255), "S", Color(255,255,255,255), "S" }
 
local current_script = "DS" -- DS, JS, AW, SS
local console_command = "hl_localchat"
local add_wp_concommand = "hl_add_waypoint"
local remove_wp_concommand = "hl_remove_waypoint"
 
// To do
// Live wp remove list update, if someone else removes a waypoint, your menu will update!
// Waypoint text colour in chat to to be colour of the waypoint.
// Turn refresh scale from concommand to function.
// Radio for hlrp, plain encrypted chat for everything else
// Chat message added by Nick()
// Fix visual 3d2d glitch
 

local message_s
local encryption_num = 9
--local hl_chat = {}
local scale_size = CreateClientConVar( "scale_size", "1.4", true, false )
local note_in_chat = CreateClientConVar( "note_in_chat", 1, true, false )
local note_in_sound = CreateClientConVar( "note_in_sound", 1, true, false )
local time_stamp_chat = CreateClientConVar( "time_stamp_chat", 1, true, false )
 
local scale_s = scale_size:GetFloat()
local back_arrow = Material( "icon16/arrow_right.png" )
local delete_png = Material( "icon16/delete.png" )
local settings_png = Material( "icon16/wrench.png" )
local tick_png = Material( "icon16/tick.png" )
 
--[[        waypoint stuff      ]]--
local text
local TextWidth
local waypoints = {}
local wayp_n = "Name"
local ChosenColor = Color( 255,255,255,255 )
local cango = true
local que = {}
--waypoints["Base"] = { Vector( 5000, 400, 500 ), Color(255,255,255,255) }
--[WP] 0, 0, 0, 255, 255, 255, 255, Base of epicness
--[WP] 500, 50, 300, 255, 0, 255, 255, hackin
--[[         waypoint stuff end         ]]--
 
 
--[[ fast functions ]]--
local function wp_added_msg( name )
    chat.AddText( Color(0,255,63), "Public waypoint '" .. name .. "' has been added!" )
    surface.PlaySound( "npc/turret_floor/active.wav" )
end
local function wp_removed_msg( name )
    chat.AddText( Color(255,255,0), "Public waypoint '" .. name .. "' has been removed!" )
    surface.PlaySound( "physics/concrete/concrete_block_impact_hard1.wav" )
end
local function wp_remove_failed_msg( name )
    chat.AddText( Color( 255,0,0 ), "Failed to remove waypoint '", name, "' ... retrying!" )
//  surface.PlaySound( "physics/metal/metal_barrel_impact_hard7.wav" ) -- would have sound, but then it plays two sounds right after each other if it doesn't fail second time round.
end
local function chat_msg_added()
 
    if note_in_sound:GetBool() then
        LocalPlayer():EmitSound( "Friends/message.wav", 75, 125, 0.5, CHAN_AUTO )
    end
    if note_in_chat:GetBool() then
        chat.AddText( Color(255,255,0), "New message! hl_localchat in console to see!" )   
    end
   
end
 
 
--[[
    Rest of code
]]--
 
--Scaled Derma font
surface.CreateFont( "Hc_chat", {
    font = "DermaDefault",
    size = 13 * scale_s,
    weight = 500 * 1.6,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
 
--Waypoint font
surface.CreateFont( "Waypoint_big", {
    font = "DermaLarge",
    size = 600,
    weight = 5000,
    antialias = true,
} )
 
--[[ add waypoint ]]--
local function add_waypoint( way_table )
 
    local tab_info = string.Explode( "? ", way_table )
   
        waypoints[tab_info[8]] = {} -- Strings will override existing strings if they exist
        local table_add_v = Vector( tab_info[1], tab_info[2], tab_info[3] )
        local table_add_c = Color(tab_info[4],tab_info[5],tab_info[6],tab_info[7])
       
        --print( table_add_v )
        --print( tab_info[1] )
 
        table.insert( waypoints[tab_info[8]], table_add_v )
        table.insert( waypoints[tab_info[8]], table_add_c )
       
        wp_added_msg(tab_info[8])
       
end
 
 
--[[ Send "encrypted" message  to other members of the chat.]]--

local function send_en_mesg()
 
    local en_sentence = ""
 
    -- encrypted
    for i=1, string.len( message_s ) do
   
        local en_word = string.byte( message_s, i, i )
        en_sentence = en_sentence .. string.char( en_word + encryption_num )
 
    end
       
    message_s = ""
    RunConsoleCommand( "say", "/radio " .. current_script .. " " .. string.reverse( en_sentence )   )
 
end
 
--Allows settings derma to call this frame
local Hc_frame = vgui.Create( "DFrame" )
 
   
        --[[ Settings Derma ]]--
       
local function Hc_settings_chat()
 
 
    surface.CreateFont( "Hc_chat", {
        font = "DermaDefault",
        size = 13 * scale_s,
        weight = 500 * 1.6,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false,
    } )
 
 
        local Hc_frame_s = vgui.Create( "DFrame" )
        Hc_frame_s:SetSize( 420 * scale_s, 250 * scale_s )
        Hc_frame_s:Center()
        Hc_frame_s:MakePopup()
        Hc_frame_s:SetVisible( true )
        Hc_frame_s:SetTitle( "" )
        Hc_frame_s:SetDraggable( true )
        Hc_frame_s:ShowCloseButton( false )
        function Hc_frame_s:Paint( w, h )
            draw.RoundedBox( 0, 0, 0, 420 * scale_s, 250 * scale_s, Color( 182, 182, 182, 220 ) )
           
            surface.SetFont( "Hc_chat" )
            surface.SetTextColor( 255, 255, 255, 200 )
            surface.SetTextPos( 40 * scale_s, 55 * scale_s )
            surface.DrawText( "Chat notifications" )
           
            surface.SetTextPos( 40 * scale_s, 85 * scale_s )
            surface.DrawText( "Sound notifications" )
           
            surface.SetTextPos( 40 * scale_s, 115 * scale_s )
            surface.DrawText( "Timestamps" )
           
        end
 
        -- Settings
        local se2_DButton = vgui.Create( "DButton", Hc_frame_s )
        se2_DButton:SetPos( 375 * scale_s, 220 * scale_s)
        se2_DButton:SetText( "" )
        se2_DButton:SetSize( 30 * scale_s, 20 * scale_s )
        se2_DButton.DoClick = function()
            Hc_frame:ToggleVisible()
            Hc_frame_s:ToggleVisible()
            --Hc_frame_s:Close()
        end
        function se2_DButton:Paint( w, h )
            surface.SetDrawColor( 255, 255, 255, 255 )
            surface.SetMaterial( back_arrow )
            se2_DButton:DrawTexturedRect()
        end
       
        local sc_ESlider = vgui.Create( "Slider", Hc_frame_s )
        sc_ESlider:SetText( "Scale" )
        sc_ESlider:SetPos( 5 * scale_s, 10 * scale_s )
        sc_ESlider:SetSize( 335 * scale_s, 20 * scale_s )
        sc_ESlider:SetMin( 1 )
        sc_ESlider:SetMax( 3 )
        sc_ESlider:SetValue( math.Round(scale_s, 1) )
        sc_ESlider:SetDecimals( 1 )
        sc_ESlider:SetConVar( "scale_size" )  
       
        local ap_DButton = vgui.Create( "DButton", Hc_frame_s )
        ap_DButton:SetPos( 333 * scale_s, 10 * scale_s)
        ap_DButton:SetSize( 80 * scale_s, 20 * scale_s )
        ap_DButton:SetFont( "Hc_chat" )
        ap_DButton:SetText( "Apply Scale" )
        ap_DButton.DoClick = function()
            scale_s = scale_size:GetFloat()
            --print( scale_s )
            Hc_frame_s:Close()
            Hc_settings_chat()
            RunConsoleCommand( "refresh_scale" )
        end
       
        --[[ chat notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 50 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if note_in_chat:GetBool() then
                RunConsoleCommand( "note_in_chat", "0" )
            else
                RunConsoleCommand( "note_in_chat", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if note_in_chat:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
       
        --[[ sound notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 80 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if note_in_sound:GetBool() then
                RunConsoleCommand( "note_in_sound", "0" )
            else
                RunConsoleCommand( "note_in_sound", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if note_in_sound:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
        --[[ sound notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 110 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if time_stamp_chat:GetBool() then
                RunConsoleCommand( "time_stamp_chat", "0" )
            else
                RunConsoleCommand( "time_stamp_chat", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if time_stamp_chat:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
       
       
end
 
--[[ Derma ]]--
 
Hc_frame:SetSize( 420 * scale_s, 250 * scale_s )
Hc_frame:Center()
Hc_frame:MakePopup()
Hc_frame:SetVisible( false )
Hc_frame:SetTitle( "" )
Hc_frame:SetDraggable( true )
Hc_frame:ShowCloseButton( false )
function Hc_frame:Paint( w, h )
    draw.RoundedBox( 0, 0, 0, 420 * scale_s, 250 * scale_s, Color( 182, 182, 182, 150 ) )
    draw.RoundedBox( 0, 10 * scale_s, 10 * scale_s, 400 * scale_s, 200 * scale_s, Color( 109, 109, 109, 150 ) )
   
    surface.SetFont( "Hc_chat" )
    surface.SetTextColor( 255, 255, 255, 75 )
    surface.SetTextPos( 115 * scale_s, 238 * scale_s )
    surface.DrawText( "hl Localchat" )
end
 
-- Hc_richtext
local Hc_richtext = vgui.Create( "RichText", Hc_frame )
Hc_richtext:SetPos( 10 * scale_s, 10 * scale_s )
Hc_richtext:SetSize( 400 * scale_s, 200 * scale_s )
 
function Hc_richtext:PerformLayout()
 
    self:SetFontInternal( "Hc_chat" )
    self:SetFGColor( Color( 255, 255, 255 ) )
 
end
 
    -- TextEntry
    local TextEntry = vgui.Create( "DTextEntry", Hc_frame ) -- create the form as a child of frame
    TextEntry:SetPos( 10 * scale_s, 220 * scale_s )
    TextEntry:SetSize( 350 * scale_s, 20 * scale_s )
    TextEntry:SetText( "" )
    TextEntry:SetFont( "Hc_chat" )
    TextEntry:SetTextColor( color_white )
    TextEntry:SetDrawBorder( false )
    TextEntry:SetDrawBackground( false )
    TextEntry:SetCursorColor( color_white )
    TextEntry:SetHighlightColor( Color(0, 161, 255) )
    TextEntry:RequestFocus()
    TextEntry.OnTextChanged = function(self)
    -- 115 Character Cap
    local current_txt = self:GetValue()
        if string.len(current_txt) > 115 then
            self:SetText(self.OldText)
            self:SetValue(self.OldText)
            self:SetCaretPos(115)
            surface.PlaySound ("common/wpn_denyselect.wav")
        else
            self.OldText = current_txt
        end
    end
    -- Send Message
    TextEntry.OnEnter = function( self )
        message_s = self:GetValue()
        send_en_mesg()
        TextEntry:SetText( "" )
        TextEntry:RequestFocus()
    end
    function TextEntry:Paint( w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 109, 109, 109, 150 ) )
        derma.SkinHook( "Paint", "TextEntry", self, w, h )
    end
   
    -- Close
    local cl_DButton = vgui.Create( "DButton", Hc_frame )
    cl_DButton:SetPos( 390 * scale_s, 220 * scale_s )
    cl_DButton:SetText( "" )
    cl_DButton:SetSize( 20 * scale_s, 20 * scale_s )
    cl_DButton.DoClick = function()
        Hc_frame:ToggleVisible()
    end
    function cl_DButton:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( delete_png )
        cl_DButton:DrawTexturedRect()
    end
   
    -- Settings
    local se_DButton = vgui.Create( "DButton", Hc_frame )
    se_DButton:SetPos( 365 * scale_s, 220 * scale_s)
    se_DButton:SetText( "" )
    se_DButton:SetSize( 20 * scale_s, 20 * scale_s )
    se_DButton.DoClick = function()
        Hc_frame:ToggleVisible()
        Hc_settings_chat()
    end
    function se_DButton:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( settings_png )
        se_DButton:DrawTexturedRect()
    end
   
local function add_chatbox_text(script, text, ply)
   
    if time_stamp_chat:GetBool() then
                Hc_richtext:InsertColorChange( 0,255,255, 255 )
                Hc_richtext:AppendText( os.date("[%H:%M]") )
            end
               
            -- Special chat box message
            local col = GAMEMODE:GetTeamColor( ply )
            Hc_richtext:InsertColorChange( chat_scripts[script][1].r, chat_scripts[script][1].g, chat_scripts[script][1].b, chat_scripts[script][1].a )
            Hc_richtext:AppendText( chat_scripts[script][2] )
            Hc_richtext:InsertColorChange( chat_scripts[script][3].r, chat_scripts[script][3].g, chat_scripts[script][3].b, chat_scripts[script][3].a  )
            Hc_richtext:AppendText( chat_scripts[script][4] )
            Hc_richtext:InsertColorChange( 72,72,72, 255 )
            Hc_richtext:AppendText( " - " )
            Hc_richtext:InsertColorChange( col.r, col.g, col.b, 255 )
            Hc_richtext:AppendText( ply:Nick() )
            Hc_richtext:AppendText( ": " )
            Hc_richtext:InsertColorChange( 255,255,255, 255 )
            Hc_richtext:AppendText( string.reverse( text ) .. "\n" )
           
            -- Chat Message
           
//          if note_in_sound:GetBool() then
//          LocalPlayer():EmitSound( "Friends/message.wav", 75, 125, 0.5, CHAN_AUTO )
//          end
//          if note_in_chat:GetBool() then
//          chat.AddText( chat_notification_col, chat_notification )   
//          end
            chat_msg_added()
 
end
 
--[[ remove global waypoints ]]--
local function remove_waypoints( name )
    --[[
    for k, v in pairs( waypoints ) do
        if k == name then
        waypoints[name] = nil
        wp_removed_msg( name )
//      PrintTable( waypoints )
        end
    end
    ]]--
   
    if waypoints[name] != nil then
    waypoints[name] = nil
    wp_removed_msg( name )
    end
   
end
 
--[[ Chat listener + decrypter ]]--
hook.Add( "OnPlayerChat", "ping_pong", function( ply, strText, bTeam, bDead )
 
    local words = string.Explode( " ", strText )
       
        --See which script they are using
        if chat_scripts[words[1]] != nil then
       
            local to_read = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence = ""
 
            for i=1, string.len( to_read ) do
                   
                de_sentence = de_sentence .. string.char( string.byte( to_read, i, i ) - encryption_num )
 
            end
            add_chatbox_text(words[1], de_sentence, ply)
            return true
        end
       
        --Add waypoints
        if words[1] == "[WP]" then
       
            local to_read_wp = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence_wp = ""
           
            for i=1, string.len( to_read_wp ) do
           
                de_sentence_wp = de_sentence_wp .. string.char( string.byte( to_read_wp, i, i ) - encryption_num )
               
            end
            add_waypoint( string.reverse(de_sentence_wp) )
            return true
           
        end
       
        --Remove waypoints
        if words[1] == "[RWP]" then
       
            local to_read_rwp = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence_rwp = ""
           
            for i=1, string.len( to_read_rwp ) do
           
                de_sentence_rwp = de_sentence_rwp .. string.char( string.byte( to_read_rwp, i, i ) - encryption_num )
               
            end
            remove_waypoints( string.reverse(de_sentence_rwp) )
            return true
           
        end
           
end )
 
--Reset the scale of the chat derma, can't re-open or chat will vanish!
concommand.Add( "refresh_scale", function()
 
            Hc_frame:SetSize( 420 * scale_s, 250 * scale_s )
            Hc_frame:Center()
           
            Hc_richtext:SetPos( 10 * scale_s, 10 * scale_s )
            Hc_richtext:SetSize( 400 * scale_s, 200 * scale_s )
           
            TextEntry:SetPos( 10 * scale_s, 220 * scale_s )
            TextEntry:SetSize( 350 * scale_s, 20 * scale_s )
            TextEntry:SetFont( "Hc_chat" )
           
            cl_DButton:SetPos( 390 * scale_s, 220 * scale_s )
            cl_DButton:SetSize( 20 * scale_s, 20 * scale_s )
           
            se_DButton:SetPos( 365 * scale_s, 220 * scale_s)
            se_DButton:SetSize( 20 * scale_s, 20 * scale_s )
                   
end)
 
--[[ draw waypoints ]]--
local function waypoint_draw()
    for k, v in pairs( waypoints ) do
//          if waypoints[k][1] != nil then --return end
            local angles = LocalPlayer():EyeAngles()
            local position = Vector( waypoints[k][1].x, waypoints[k][1].y, waypoints[k][1].z )
            local distance = position:Distance(LocalPlayer():GetPos())
            local distance_m = math.Round(distance / 39.370)
//          if waypoints[k][2] != nil then --return end
            local textcolour = Color(waypoints[k][2].r, waypoints[k][2].g, waypoints[k][2].b, waypoints[k][2].a ) or Color( 0,0,0,0 )
           
            local text = k .. " " .. "[" .. distance_m .. "m]" --,2
            local TextWidth_wp = surface.GetTextSize(text)
            local xy = distance/10 + 100
 
            angles:RotateAroundAxis(angles:Forward(), 90);
            angles:RotateAroundAxis(angles:Right(), 90);
            angles:RotateAroundAxis(angles:Up(), 0);
           
            cam.Start3D2D( position, angles, 0.1)
                cam.IgnoreZ(true)
                draw.RoundedBox( 0, -xy/2, (-xy/2)*2, xy, xy, textcolour )
                draw.WordBox(2, -TextWidth_wp*0.5, 0, text, "Waypoint_big", Color(0, 0, 0, 150), textcolour)
                cam.IgnoreZ(false)
            cam.End3D2D()
//  end
//  end
    end
end
hook.Add("PostDrawOpaqueRenderables", "waypoint_draw", waypoint_draw) --PostDrawOpaqueRenderables
 
--[[ waypoint sender adder ]]--
local function add_dat_wp( argStr )
 
    local en_sentence = ""
   
    -- encrypted
    for i=1, string.len( argStr ) do
   
        local en_word = string.byte( argStr, i, i )
        en_sentence = en_sentence .. string.char( en_word + encryption_num )
 
    end
       
    -- 30 length without message, message can be 115.
    RunConsoleCommand( "say", "/radio " .. "[WP]" .. " " .. string.reverse( en_sentence )   )
    en_sentence = ""
    //wp_added_msg()
 
   
end
 
--[[ waypoint sender remover ]]--
local function remove_dat_wp( argStr )
 
    --que
    if argStr != nil then
    table.insert( que, argStr )
    end
   
    if cango and que != nil then
    --PrintTable( que )
    cango = false
 
    local rwp_en_sentence = ""
   
    -- encrypted
    for i=1, string.len( que[1] ) do
   
        local rwp_en_word = string.byte( que[1], i, i )
        rwp_en_sentence = rwp_en_sentence .. string.char( rwp_en_word + encryption_num )
 
    end
       
    -- 30 length without message, message can be 85.
    RunConsoleCommand( "say", "/radio " .. "[RWP]" .. " " .. string.reverse( rwp_en_sentence )  )
    rwp_en_sentence = ""
    timer.Simple( 2, function()
        if waypoints[que[1]] == nil then // fail safe
            table.remove( que, 1 )
        else
            wp_remove_failed_msg( que[1] )
        end
        cango = true
        if que[1] != nil then
        remove_dat_wp()
        end
    end)
 
    end
   
end
 
--[[ waypoint menu ]]--
concommand.Add( add_wp_concommand, function( ply, cmd, args, argStr )
 
local xScreenRes = 1366
local yScreenRes = 768
local wMod = ScrW() / xScreenRes    
local hMod = ScrH() / yScreenRes
 
local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Waypoint hlV1" )
Frame:SetSize( wMod*400, hMod*320 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
    draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 150 ) ) -- Draw a red box instead of the frame
end
 
local wayp_Entry = vgui.Create( "DTextEntry", Frame )   -- create the form as a child of frame
wayp_Entry:SetPos( wMod*10, hMod*30 )
wayp_Entry:SetSize( wMod*380, hMod*30 )
wayp_Entry:SetText( wayp_n )
wayp_Entry.OnTextChanged = function(self)
    -- 115 Character Cap
        wayp_n = self:GetValue()
        if string.len(wayp_n) > 50 then
            self:SetText(self.OldText)
            self:SetValue(self.OldText)
            self:SetCaretPos(50)
            surface.PlaySound ("common/wpn_denyselect.wav")
        else
            self.OldText = wayp_n
        end
    end
  




  
local ColorPicker = vgui.Create( "DColorMixer", Frame )
ColorPicker:SetSize( wMod*380, hMod*200 )
ColorPicker:SetPos( wMod*10, hMod*70 )
ColorPicker:SetPalette( true )
ColorPicker:SetAlphaBar( true )
ColorPicker:SetWangs( true )
ColorPicker:SetColor( ChosenColor )
 
local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Add waypoint" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( wMod*10, hMod*280 )
Button:SetSize( wMod*380, hMod*30 )
Button.Paint = function( self, w, h )
    draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
Button.DoClick = function()
    ChosenColor = ColorPicker:GetColor()
    local stringyyy = math.Round(LocalPlayer():GetShootPos()[1]) .. "? " .. math.Round(LocalPlayer():GetShootPos()[2]) .. "? " .. math.Round(LocalPlayer():GetShootPos()[3] + 50)
    .. "? " .. (ChosenColor.r) .. "? " .. (ChosenColor.g) .. "? " .. (ChosenColor.b) .. "? " .. (ChosenColor.a) .. "? "
    .. wayp_n
    add_dat_wp( stringyyy )
    --print( stringyyy )
end
 
 
end)
 
--Toggle the chat derma rather than re-open because that would cause the chat to blank.
concommand.Add( console_command, function()
   
    Hc_frame:ToggleVisible()
   
end)
 
 
--[[ remove waypoints ]]--
 
concommand.Add( remove_wp_concommand, function()
 
local xScreenRes = 1366
local yScreenRes = 768
local wMod = ScrW() / xScreenRes    
local hMod = ScrH() / yScreenRes
 
local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Waypoint remover" )
Frame:SetSize( wMod*400, hMod*320 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
    draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 150 ) ) -- Draw a red box instead of the frame
end
 
local WP_LIST = vgui.Create( "DListView", Frame )
WP_LIST:SetPos( wMod*10, hMod*30 )
WP_LIST:SetSize( wMod*380, hMod*240 )
WP_LIST:SetMultiSelect( true )
WP_LIST:AddColumn( "Waypoint" )
--AppList:AddColumn( "Pos" )
 
for k, v in pairs( waypoints ) do
//if waypoints[k][1] != nil then
WP_LIST:AddLine( k )
--AppList:AddLine( "gg" )
//end
end
 
local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Remove waypoint(s)" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( wMod*10, hMod*280 )
Button:SetSize( wMod*380, hMod*30 )
Button.Paint = function( self, w, h )
    draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
Button.DoClick = function()
 
    for k, line in pairs( WP_LIST:GetSelected()) do
 
        remove_dat_wp( line:GetValue(1) )
        WP_LIST:RemoveLine( line:GetID() )
 
    end
   
end
 
 
end)

// mpgh exploits that are free to use

concommand.Add("hl_wepdupe", function()
	

	timer.Simple( 0.4744, function() 
		RunConsoleCommand("say", "/drop")  
	end)
	
	timer.Simple( 1.4135, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
	timer.Simple( 7, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
end)

local ag_toggle = 0
local hook_toggle = 0
function GenAmmo()
lastgun = LocalPlayer():GetActiveWeapon():GetClass()
if hook_toggle == 0 then
hook.Add("CreateMove", "lolammo", function(cmd)
RunConsoleCommand("hlrp", "drop")
RunConsoleCommand("use", lastgun)
if ag_toggle == 0 then
cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_USE))
ag_toggle = 1
else
cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_USE)))
ag_toggle = 0
end
end)
hook_toggle = 1
else
hook.Remove("CreateMove", "lolammo")
hook_toggle = 0
end
end

concommand.Add("hl_ammodupe", GenAmmo)

























-- NOT DONE YET---  DO NOT TOUCH --- REMEMBER TO ADD ADDITONAL HOOKS/concommands here, hmm can't add any function that uses deligits detouring thing NEED FIX ASAP.
concommand.Add( "hl_unload", function()
 ---- surface.PlaySound("ambient/levels/labs/teleport_winddown1.wav") -- should i use this or custom sound? hmmm....,

RunConsoleCommand ("hl_esp","0")
RunConsoleCommand ("hl_hud","0")
RunConsoleCommand ("hl_xray","0")
RunConsoleCommand ("hl_entity","0")
RunConsoleCommand ("hl_watermark","0")
RunConsoleCommand ("hl_crosshair","0")
RunConsoleCommand ("hl_crosshair2","0")
RunConsoleCommand ("hl_flashspam","0")
  concommand.Remove( "hl_entity" )
  concommand.Remove( "hl_xray" )
  concommand.Remove( "hl_about" )
   concommand.Remove( "hl_menu" )
   concommand.Remove ("hl_esp")
 concommand.Remove ("hl_openscript")
 concommand.Remove ("hl_180")
 concommand.Remove ("hl_help")
 concommand.Remove ("hlbhop")
 concommand.Remove ("hl_adminalert")
 concommand.Remove ("hlide_adminalert_distance")
 concommand.Remove ("hl_chatspammer")
 concommand.Remove ("hl_chatspammer_msg")
  concommand.Remove ("hl_crosshair")
    concommand.Remove ("hl_crosshair2")
 hook.Remove ( "Think", "hl_chatspammer_hook")
 hook.Remove ( "HUDPaint", "ESP")
 hook.Remove ("RenderScreenspaceEffects","hl.GetPlys")
 timer.Remove("hl.GetPlys")
 timer.Destroy("hl.GetPlys")
 hook.Remove ("Think","hlflash")
 concommand.Remove ("hl_flashspam")
 concommand.Remove ("hl_rainbow")
  hook.Remove ("Think","hlrainbow")
  hook.Remove ("HUDPaint", "crosshair2")
 hook.Remove ("HUDPaint", "crosshair")
 hook.Remove ("HUDPaint", "huddesign")
 hook.Remove ("HUDPaint", "watermark")
 concommand.Remove ("hl_hud")
  concommand.Remove ("hl_watermark")
    concommand.Remove ("hl_crosshair")
	concommand.Remove ("hl_crosshai2")
	concommand.Remove ("hl_ping_rp")
	 chat.AddText( Color( 100, 255, 100 ) ,"hl NOTICE:" ,  Color( 0, 157, 209 ), "hl's scripts unloaded! Type lua_openscript_cl hlv1.lua to open it again!" )
  chat.AddText ( Color( 0, 157, 209 ), "The ESP will remain until you rejoin the server.")
    chat.AddText ( Color( 0, 157, 209 ), "Do not reload the script too many times or you can crash the script!")
 end)
 













