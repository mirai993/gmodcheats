local aether = aether
local hook = {}
aether.hook = hook

hook.list = {}

function hook.add( name, id, func )
    aether.log.debug( "Adding hook", name, id )
    
    hook.list[name] = hook.list[name] or {}
    hook.list[name][id] = func
end

function hook.remove( name, id )
    hook.list[name][id] = nil
end

function hook.overcall( old, name, gm, ... )
    local hooks = hook.list[name]

    if not hooks then return old( name, gm, ... ) end

    return hook.call( name, function( ... )
        return old( name, gm, ... )
    end, ... ) ~= nil or old( name, gm, ... )
end
aether.detour.module( "hook", "Call", hook.overcall )

function hook.call( name, ... )
    local hooks = hook.list[name]
    local ret

    for k, v in pairs( hooks or {} ) do
        if not v then
            hooks[k] = nil
            break
        end
        
        ret = { pcall( v, ... ) }

        if not ret[1] then
            ErrorNoHalt( "Hook \"" .. k .. "\" failed: " .. ret[2] .. "\n" )
            hooks[k] = nil
        else
            if #ret > 1 then
                return unpack( ret, 2 )
            end
        end
    end
end
