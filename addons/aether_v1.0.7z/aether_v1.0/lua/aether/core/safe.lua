--[[#
--  This file should contain stuff to avoid detection,
--  like detours and function backups
--]]

local aether = aether
local detour = aether.detour

--# first, backup important functions

local safe = {
    setmetatable = setmetatable;
    getmetatable = getmetatable;
    rawset = rawset;
    rawget = rawget;
    coroutine = {
        create = coroutine.create;
        resume = coroutine.resume;
    };
    debug = {
        getinfo = debug.getinfo;
        setinfo = debug.setinfo;
        getupvalue = debug.getupvalue;
        setupvalue = debug.setupvalue;
        setmetatable = debug.setmetatable;
        getmetatable = debug.getmetatable;
    };
}

aether.safe = safe

--# then, safety from my own testing "anti-cheat"

--# this can be used with debug.getlocal to detect cheats
detour.func( coroutine, "create", function( old, func )
    return old( detour.functions[func] or func )
end )

--# EWWWWW
local infoHack = debug.getinfo( 0 )
local tailCall = debug.getinfo( -1 )

detour.func( debug, "getinfo", function( old, func, what )
    local info
    if type( func ) == "number" then
        if func == 0 then
            info = infoHack
        elseif func < 0 then
            info = tailCall
        end
        --# This should work
        func = func + 3
    end

    if not info then
        info = old( detour.functions[func] or func, what )
    end

    if info and type( func ) == "function" then
        info.func = func
    end
    return info
end )

detour.func( debug, "getupvalue", function( old, func, i )
    return old( detour.functions[func] or func, i )
end )
