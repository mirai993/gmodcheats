local aether = aether
local gui = {}
aether.gui = gui

local function mergeTables( dest, src )
    for k,v in pairs( src ) do
        if ( type( v ) == "table" and type( dest[k] ) == "table" ) then
            mergeTables( dest[k], v )
        else
            dest[k] = v
        end
    end

    return dest
end

local _panels = {}

function gui.create( class, parent, name )
    aether.log.debug( "Creating vgui component", class )

    if _panels[class] then
        local tbl = _panels[class]
        local panel = gui.create( tbl.Base, parent, name )

        mergeTables( panel:GetTable(), tbl )
        panel.BaseClass = _panels[tbl.Base] or _G[tbl.Base]
        panel.ClassName = class

        if panel.Init then
            local b, e = pcall( panel.Init, panel )
            if not b then
                ErrorNoHalt( "vgui.Create: Error when calling '", class ,"':Init (", e, ")\n" )
                return
            end
        end

        panel:Prepare()

        return panel
    end

    return vgui.Create( class, parent, name )
end

function gui.register( name, tbl, base )
    tbl.Base = base or "DPanel"
    _panels[name] = tbl

    aether.log.debug( "Registering vgui component", name .. ":" .. tbl.Base )

    return tbl
end
