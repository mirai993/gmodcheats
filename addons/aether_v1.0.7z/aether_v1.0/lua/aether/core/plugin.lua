local aether = aether
local config = aether.config
local plugin = {}
aether.plugin = plugin

--# Config
aether.var.pluginpath = "plugins"

local _pl = {}
_pl.__index = _pl

function plugin.register( name )
    local p = setmetatable( { Name = name }, _pl )

    --# TODO: implement config vars
    p.var = setmetatable( {}, {
        __index = function( t, k )
            return (config.data[name] or {})[k]
        end,
        __newindex = function( t, k, v )
            if not loaded then
                config.data[name] = config.data[name] or {}
            end

            config.data[name][k] = v
        end
    } )
    
    p.hook = setmetatable( {}, {
        __newindex = function( tbl, k, v )
            if v then
                aether.hook.add( k, name .. ":" .. k, v )
            else
                aether.hook.remove( k, name .. ":" .. k )
            end
        end
    } )

    aether.log.print( "", name )

    return p
end

function plugin.init()
    aether.log.print( "Loading plugins..." )

    _G.aether = aether

    local dir = aether.var.pluginpath
    for _, f in ipairs( file.FindInLua( "aether/" .. dir .. "/*.lua" ) ) do
        include( "aether/" .. dir .. "/" .. f )
    end

    _G.aether = nil
end

aether.command.add( "reload", plugin.init )

--# We'll have on-the-fly loading/unloading later
