local aether = aether
local config = {}
aether.config = config

local cfgFile = "aether.txt"

config.data = {}

local loaded = false

function config.read()
    aether.log.print( "Loading config..." )

    config.deserialize( file.Read( cfgFile ) or "return {}" )
    loaded = true
    config.write()
end

config.init = config.read

function config.write()
    file.Write( cfgFile, "return " .. config.serialize() )
end

local function tableMerge( dest, src )
    for k, v in pairs( src ) do
        if type( v ) == "table" then
            dest[k] = dest[k] or {}
            tableMerge( dest[k], v )
        else
            dest[k] = v
        end
    end
end

function config.deserialize( txt )
    local func = CompileString( txt, "cfg" ) or function() end

    tableMerge( config.data, func() or {} )
end

local tab = "    "
function config.serialize( tbl, int )
    tbl = tbl or config.data
    int = int or 1
    local str = "{\n"

    for k, v in pairs( tbl ) do
        if type( v ) == "string" then
            str = string.format( "%s%s[%q] = %q;\n", str, tab:rep( int ),
                                k, v )
        elseif type( v ) == "table" then
            str = string.format( "%s%s[%q] = %s;\n", str, tab:rep( int ),
                                k, config.serialize( v, int + 1 ) )
        else
            str = string.format( "%s%s[%q] = %s;\n", str, tab:rep( int ),
                                k, tostring( v ) )
        end
    end

    return str .. tab:rep( int - 1 ) .. "}"
end

aether.var = setmetatable( {}, {
    __index = function( t, k )
        return (config.data["Core"] or {})[k]
    end,
    __newindex = function( t, k, v )
        if not loaded then
            config.data["Core"] = config.data["Core"] or {}
        end

        config.data["Core"][k] = v
    end
} )
