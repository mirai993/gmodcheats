local aether = aether
local log = {}
aether.log = log

function log.write( ... )
    --# This will be replaced with a fancier one later
    Msg( table.concat( {...}, "\t" ) .. "\n" )
end

function log.debug( ... )
    if not aether.var.debug then return end

    log.write( "[A:D]", ... )
end

function log.print( ... )
    log.write( "[A]", ... )
end

function log.error( ... )
    ErrorNoHalt( table.concat( { ... }, " " ) )
    log.write( "[A:E]", ... )
end
