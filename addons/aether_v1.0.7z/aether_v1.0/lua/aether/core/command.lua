local aether = aether
local command = {}
aether.command = command

command.name = "ae"

local _commands = {}
local _cmdNames = {}

AddConsoleCommand( command.name )

function command.add( cmd, func, complete )
    cmd = cmd:lower()
    _commands[cmd] = { func = func, complete = complete }

    _cmdNames[#_cmdNames + 1] = cmd
    table.sort(_cmdNames)
end

function command.remove( cmd )
    _commands[cmd:lower()] = nil

    local iCmd
    for k, v in pairs( _cmdNames ) do
        if v == cmd then
            iCmd = k
            break
        end
    end

    if iCmd then
        table.remove( _cmdNames, iCmd )
    end
end

function command.run( args )
    local name = args[1]:lower()
    table.remove( args, 1 )

    local cmd = _commands[name]
    if cmd and cmd.func then
        cmd.func( name, args )
    else
        aether.log.print( "Unknown command:", name )
    end

    return true
end

local function getCommandMatches( str )
    local ret = {}

    for k, v in ipairs( _cmdNames ) do
        if v:sub( 1, #str ) == str then
            ret[#ret + 1] = command.name .. " " .. v
        end
    end

    return ret
end

function command.complete( args )
    local name = (args:match "%s+(%S+)" or ""):lower()

    if args:sub( #name + 2, #name + 2 ) == " " then
        local cmd = _commands[name]

        if cmd and cmd.complete then
            local complete = cmd.complete( args:sub( #name ) )
            for k, v in pairs( complete ) do
                complete[k] = command.name .. " " .. name .. " " .. v
            end
            return complete
        end
    end

    return getCommandMatches( name )
end

--# Will be replaced by C++ hooking
aether.detour.module( "concommand", "Run", function( old, ply, cmd, args )
    --# We're only client-side, so player won't be needed
    return (cmd == command.name and command.run( args )) or old( ply, cmd, args )
end )

aether.detour.module( "concommand", "AutoComplete", function( old, cmd, args )
    return (cmd == command.name and command.complete( args )) or old( cmd, args )
end )