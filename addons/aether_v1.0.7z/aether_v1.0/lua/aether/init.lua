local aether = {}
_G.aether = aether

--# we should do core loading manually,
--  to ensure load order

include "core/config.lua"

--# Aether config goes here
aether.var.debug = false

include "core/log.lua"

aether.log.print( "Loading core..." )

include "core/detour.lua"
include "core/safe.lua"
include "core/hook.lua"
include "core/command.lua"
include "core/gui.lua"

--# These are initialized on autorun
--include "core/menu.lua"
include "core/plugin.lua"

aether.config.init()
aether.detour.init()

--# Temporary autorun solution
aether.hook.add( "Initialize", "aoe", function()
    --# Bleh
    aether.plugin.init()

    aether.log.print( "Aether loaded!" )
end )

--# to avoid getting detected
--  REMEMBER TO STORE A LOCAL REFERENCE
_G.aether = nil
