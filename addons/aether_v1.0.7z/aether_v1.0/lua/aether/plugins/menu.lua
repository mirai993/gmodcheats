local aether = aether

local menu = aether.plugin.register "Menu"

--# No, we're not saving this var
--menu.visible = false

function menu.toggle()
    if not menu.panel or not menu.panel:IsValid() then
        menu.panel = aether.gui.create( "Menu" )
        menu.panel:SetVisible( false )
    end
    --menu.visible = (b ~= nil) and b or (not menu.visible)
    menu.panel:SetVisible( not menu.panel:IsVisible() )
end

aether.command.add( "menu", menu.toggle )

--# Load the vgui stuff
for _, f in ipairs( file.FindInLua( "aether/plugins/vgui/*.lua" ) ) do
    include( "aether/plugins/vgui/" .. f )
end

function menu.hook.BuildMenu( menu )
    local panel = menu:AddTab( "Test", "gui/silkicons/bomb", "Test" )
end
