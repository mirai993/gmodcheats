local gui = aether.gui

--# APanel

local PANEL = gui.register( "APanel", {}, "DPanel" )

function PANEL:Init()
    self.BaseClass.Init( self )
    self.List = gui.create( "APanelList", self )
    self.List:SetAutoSize( false )
    self.List:EnableVerticalScrollbar( true )
end

function PANEL:PerformLayout()
    self.BaseClass.PerformLayout( self )
    self.List:StretchToParent( 0, 0, 0, 0 )
end
