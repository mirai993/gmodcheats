local aether = aether
local gui = aether.gui

local MENU = gui.register( "Menu", {}, "DFrame" )

function MENU:Init()
    self.PropertySheet = gui.create( "DPropertySheet", self )
    self:SetTitle( "Aether" )
    self:Center()
    self:MakePopup()

    self:Build()
end

function MENU:Build()
    aether.hook.call( "BuildMenu", self )
end

function MENU:Close()
    self:SetVisible( false )
end

function MENU:PerformLayout()
    DFrame.PerformLayout( self )
    self:SetSize( 640, 400 )
    self.PropertySheet:StretchToParent( 5, 25, 5, 5 )
end

--# Custom methods

function MENU:AddTab( name, icon, tooltip )
    local panel = gui.create( "APanel" )
    self.PropertySheet:AddSheet( name, panel, icon, false, false, tooltip )
    return panel
end
