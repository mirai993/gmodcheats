local gui = aether.gui

local LIST = gui.register( "APanelList", {}, "DPanelList" )

function LIST:Init()
    self.BaseClass.Init( self )
    self:SetSpacing( 5 )
    self:SetPadding( 5 )
    self:SetAutoSize( true )
    self:EnableHorizontal( false )
    self:EnableVerticalScrollbar( false )
end

function LIST:PerformLayout()
    self.BaseClass.PerformLayout( self )
end

function LIST:Paint()
    return true
end

function LIST:MultiChoice()
    local mul = gui.create( "DMultiChoice" )
    mul:SetEditable( false )
    self:AddItem( mul )
    return mul
end

function LIST:Category( label )
    local cat = gui.create( "DCollapsibleCategory" )
    cat:SetExpanded( false )
    cat:SetLabel( label )
    
    cat.Panel = gui.create( "APanelList" )
    cat:SetContents( cat.Panel )
    
    self:AddItem( cat )
    return cat.Panel
end

function LIST:Button( label, cmd )
    local btn = gui.create( "DButton" )
    btn:SetText( label )
    btn:SetCommand( cmd )
    self:AddItem( btn )
    return btn
end

function LIST:CheckBox( label, cfg )
    local box = gui.create( "DCheckBox" )
    box:SetText( label )
    box:SetTextColor( Color( 0, 0, 0, 255 ) )
    --box:SetConfig( cfg )
    self:AddItem( box )
    return box
end

function LIST:TextBox( cfg )
    local txt = gui.create( "DTextBox" )
    txt:SetConfig( cfg )
    self:AddItem( txt )
    return txt
end

function LIST:Label( text )
    local label = gui.create( "DLabel" )
    label:SetText( text )
    self:AddItem( label )
    return label
end
