local aether = aether

--# Creates a plugin object, argument is the plugin name
--  which is also kept in obj.Name
local dummy = aether.plugin.register "Dummy"

--# This initializes the var with a default value
dummy.var.text = "HI"

local clr = { r = 255, g = 255, b = 255, a = 255 }

--# Add a HUDPaint hook
--  Note: plugins can only have one of each hook
function dummy.hook.HUDPaint()
    draw.SimpleText(
        string.format( "%s says %q!", dummy.Name, dummy.var.text ),
        "TargetID",
        10, 10,
        clr,
        TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP
    )
end

--# This removes the hook
dummy.hook.HUDPaint = nil

--# Adds a command (not functional yet)
aether.command.add( "test", function( cmd, args )
    print "concommand test"
end, function( args )
    return { "1", "2", "3" }
end )
