--[[
	MOD/lua/lolwin/gettables.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:24PM]
	===BadFile===
]]

concommand.Add("sc_access", function( pl )
	if ULib then
		PrintTable(ULib.ucl.groups)
	end
end)

concommand.Add("sc_myvars", function( pl )
	if pl.DarkRPVars then
		PrintTable(pl.DarkRPVars)
	end
end)
concommand.Add("sc_vars", function( pl )
	for k,v in pairs(player.GetAll()) do
		if v.DarkRPVars then
			PrintTable(v.DarkRPVars)
		end
	end
end)