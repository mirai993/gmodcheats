--[[
	MOD/lua/lolwin/precision_bypass.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:25PM]
	===BadFile===
]]

RCC = RunConsoleCommand
function RunConsoleCommand( ... )
	local args = {...}
	
	LocalPlayer():ChatPrint("RCC: Sending " .. string.lower(tostring(args[1])) )
	RCC( ... )

end