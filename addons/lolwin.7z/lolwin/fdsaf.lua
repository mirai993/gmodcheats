--[[
	MOD/lua/lolwin/fdsaf.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:24PM]
	===BadFile===
]]


_R = debug.getregistry()

local seteyeangles = _R.Player.SetEyeAngles
local setviewangles = _R.Player.SetViewAngles

_R.Player.SetEyeAngles = function( self, a )
print(debug.getinfo(2).short_src)
--local dbgsrc = debug.getinfo( 3, 'S' )[ 'short_src' ]
--if dbgsrc:lower():find( 'weapon' ) then
--if debug.getinfo(2).short_src:lower():find('weapon') then
return seteyeangles( self, a )
end 

_R.Player.SetViewAngles = function( self, a )
print(debug.getinfo(2).short_src)
--local dbgsrc = debug.getinfo( 3, 'S' )[ 'short_src' ]
--if dbgsrc:lower():find( 'weapon' ) then
--if debug.getinfo(2).short_src:lower():find('weapon') then
--return
--end
return setviewangles( self, a )
end
