--[[
	MOD/lua/lolwin/test.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:26PM]
	===BadFile===
]]

function table.Randomize( tbl )
	local otbl = table.Copy( tbl )
	local ntbl = {}	

		// debug.
	PrintTable(otbl)

	for k,v in pairs(otbl) do
		if not ntbl[ k ] then
			ntbl[ math.random(1, k) ] = v
		end
	end
	
	print("\n\n\n")
	PrintTable(ntbl)
end				