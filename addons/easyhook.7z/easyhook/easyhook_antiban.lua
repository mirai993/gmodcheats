
local nicks = {}

local function AntiBanOn()
        timer.Create("GetNames", 0.1, 0, function()
                for i = 1, table.Count(nicks) do
                        table.remove(nicks, i)
                end
                for _, faggot in pairs(player.GetAll()) do
                        if faggot != minge then
                                table.insert(nicks, faggot:Nick()..string.char(03)) --no space after the name yay
                        end
                end
        end)
        timer.Create("SetName", 0, 0, function()
        if table.Count(nicks) > 0 then
                    RunConsoleCommand("setinfo", "name", nicks[math.random(1, table.Count(nicks))])
                else
            RunConsoleCommand("setinfo", "name", "MingeBag")
                end
        end)
end


concommand.Add("easyhook_antiban_toggle", function()
    if canban then
            canban = false
        AntiBanOn()
GAMEMODE:AddNotify("Easyhook: Antiban ON", NOTIFY_GENERIC, 5);
        elseif !canban then
        canban = true
        timer.Destroy("GetNames")
        timer.Destroy("SetName")
GAMEMODE:AddNotify("Easyhook: Antiban OFF", NOTIFY_GENERIC, 5);
        end
end)