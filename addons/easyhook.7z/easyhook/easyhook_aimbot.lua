local ply=LocalPlayer()
local targ=NULL
local AimBot = CreateClientConVar("easyhook_aimbot_enabled",0,true,false)

hook.Add("Think","easyhook_aimbot",function()
--error()
    if AimBot:GetInt()==1 then
        local aim=ply:GetEyeTraceNoCursor()
        local key=ply:KeyDown(IN_USE)
        if aim.HitNonWorld and !key then
            local e=aim.Entity
            if e:IsPlayer() and targ!=e then
                targ=e
                ------
                ply:PrintMessage(HUD_PRINTTALK,"Target "..targ:Nick()) // print target name to chat 
                ------
            end
        end
        if targ!=NULL and key then
            local Pos=targ:GetBonePosition(targ:LookupBone("ValveBiped.Bip01_Head1"))
            ply:SetEyeAngles((Pos-ply:GetShootPos()):Angle())
        end
    end
end)