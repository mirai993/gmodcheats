local aimbot
local closest
local shoot
local nowep = { 'weapon_physgun', 'weapon_physcannon', 'gmod_tool', 'gmod_camera', 'weapon_frag', 'weapon_crowbar', 'laserpointer', 'remotecontroller' }

CreateClientConVar( 'easyhook_aimbot_team', 0, true )
CreateClientConVar( 'easyhook_aimbot', 1, true )
CreateClientConVar( 'easyhook_aimbot_ignore_friends', 1, true )
CreateClientConVar( 'easyhook_aimbot_autoshoot', 1, true )
CreateClientConVar( 'easyhook_crosshair', 1, true )
CreateClientConVar( 'easyhook_whack', 1, true )
CreateClientConVar( 'easyhook_ewire', 1, true )
CreateClientConVar( 'easyhook_removerecoil', 1, true )
CreateClientConVar( 'easyhook_esp', 1, true )
CreateClientConVar( 'easyhook_esp_name', 1, true )
CreateClientConVar( 'easyhook_esp_health', 1, true )
CreateClientConVar( 'easyhook_esp_box', 1, true )
CreateClientConVar( 'easyhook_esp_snapline', 1, true )
CreateClientConVar( 'easyhook_esp_distance', 1, true )
CreateClientConVar( 'easyhook_esp_headbone', 1, true )
hook.Add( 'CreateMove', 'Aimbot', function( me )
if aimbot and closest and closest:IsValid() then
local tpos = closest:GetBonePosition( closest:LookupBone( 'ValveBiped.Bip01_Head1' ) )
me:SetViewAngles( ( tpos - LocalPlayer():GetShootPos() ):Angle() )
end
end )

local IsTarget = function( ply )
if not ply then return false end
if not ply:IsValid() then return false end
if not ply:IsPlayer() then return false end
if ply:InVehicle() then return false end
if ply == LocalPlayer() then return false end
if not ply:Alive() then return false end

if GetConVarNumber( 'easyhook_aimbot_ignore_friends' ) ~= 0 then
if ply:GetFriendStatus() == 'friend' then
return false
end
end

if GetConVarNumber( 'easyhook_aimbot_team' ) ~= 1 then
if ply:Team() == LocalPlayer():Team() then
return false
end
end

return true
end

function ChatMessage( msg )
LocalPlayer():PrintMessage( HUD_PRINTTALK, msg )
RunConsoleCommand("Say" , "I'm using 'EasyHook W.I.P private develop' by NanoCat and Spirit !" )

end

surface.SetTextColor( col )

timer.Create( "my_timer", 120, 0, function()end)

hook.Add( 'Think', 'NORECOIL', function()
	if GetConVarNumber( 'easyhook_removerecoil' ) ~= 0 then
		pcall( function()
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end )
		
		pcall( function()
			LocalPlayer():GetActiveWeapon().Secondary.Recoil = 0
		end )
	end
end )


timer.Create( 'Aimbot', 0.01, 0, function()
if not aimbot then
if shoot then
shoot = false
RunConsoleCommand( '-attack' )
end
return
end

if not closest or not closest:IsValid() then
if shoot then
shoot = false
RunConsoleCommand( '-attack' )
end
return
end


if GetConVarNumber( 'easyhook_aimbot_autoshoot' ) == 0 then return end

local aim = LocalPlayer():GetEyeTraceNoCursor().Entity
local wep = LocalPlayer():GetActiveWeapon()

if aim == closest then
if wep and wep:IsValid() and not table.HasValue( nowep, wep:GetClass() ) then
shoot = not shoot
if shoot then
RunConsoleCommand( '+attack' )
else
RunConsoleCommand( '-attack' )
end

if wep:Clip1() < 1 then
RunConsoleCommand( '-attack' )
RunConsoleCommand( '+reload' )
timer.Simple( 0.1, function() RunConsoleCommand( '-reload' ) end )
end
end
else    
if shoot then
shoot = false
RunConsoleCommand( '-attack' )

end
end
end )

local SetNormal = function( ent )
ent:SetMaterial( '' )
ent:SetColor( color_white )
ent:SetRenderMode( RENDERMODE_NORMAL )
ent:DrawModel()
end

local tonumber = function( bool )
if bool then
return 1
else
return 0
end
end


concommand.Add( '+eaimbot', function()
if GetConVarNumber( 'easyhook_aimbot' ) ~= 0 then
local dist, ply = ScrW() + ScrH(), NULL
for _, pl in ipairs( player.GetAll() ) do
if IsTarget( pl ) then
local abs = math.abs
local sc = pl:GetPos():ToScreen()
local scr = ScrW() / 2 - abs( sc.x ) + ScrH() / 2 - abs( sc.y )

scr = abs( scr )
if scr < dist then
dist = scr
ply = pl
end
end
end

closest = ply
aimbot = true
end
end )

hook.Add( 'HUDPaint', 'Aimbot', function()
local dist, ply = ScrW() + ScrH(), NULL
local nick = 'No target...'
for _, pl in ipairs( player.GetAll() ) do
if IsTarget( pl ) then
local abs = math.abs
local sc = pl:GetPos():ToScreen()
local scr = ScrW() / 2 - abs( sc.x ) + ScrH() / 2 - abs( sc.y )

scr = abs( scr )
if scr < dist then
dist = scr
nick = pl:Nick()
end
end

if pl ~= LocalPlayer() and GetConVarNumber( 'easyhook_whack' ) ~= 0 then
if pl:Alive() then
cam.Start3D( EyePos(), EyeAngles() )
SetNormal( pl )

if pl:GetActiveWeapon() and pl:GetActiveWeapon():IsValid() then
SetNormal( pl:GetActiveWeapon() )
end
cam.End3D()
end
end

if pl ~= LocalPlayer() and GetConVarNumber( 'easyhook_esp' ) ~= 0 then
local pos = ( pl:GetBonePosition( pl:LookupBone( 'ValveBiped.Bip01_Head1' ) ) + Vector( 0, 0, 36 ) ):ToScreen()
local pos222 = ( pl:GetBonePosition( pl:LookupBone( 'ValveBiped.Bip01_Head1' ) ) ):ToScreen()

pos.x = math.Clamp( pos.x, 0, ScrW() )
pos.y = math.Clamp( pos.y, 0, ScrH() )

pos222.x = math.Clamp( pos222.x, 0, ScrW() )
pos222.y = math.Clamp( pos222.y, 0, ScrH() )



local visible
local tr = util.TraceLine( { start = LocalPlayer():GetShootPos(), endpos = pl:GetShootPos(), filter = LocalPlayer() } )
if tr.Fraction == pl then  
visible = true
else
visible = false
end

local ret = pl:GetPos():ToScreen()

ret.x = math.Clamp( ret.x, 0, ScrW() )
ret.y = math.Clamp( ret.y, 0, ScrH() )

local cols = {}
cols[ false ] = Color( 0, 255 * tonumber( pl:Alive() ), 0 )
cols[ true ] = Color( 255 * tonumber( pl:Alive() ),0, 0 )

local col = cols[ IsTarget(pl) ]
if pl:Alive() and pl:InVehicle() then col = Color( 255, 255, 0 ) end



function DrawSelection(pos)  
local area = 20
local siz = 5      
        if visible then
			
            surface.SetDrawColor(255,255,255,255)
            surface.DrawOutlinedRect(pos.x-(siz*0.5), pos.y-(siz*0.5), siz, siz)
else
        end
end
if GetConVarNumber( 'easyhook_esp' ) ~= 0 then
if GetConVarNumber( 'easyhook_esp_name' ) ~= 0 then
surface.SetTextColor( col )
surface.SetFont( 'Default' )
surface.SetTextPos( pos.x - surface.GetTextSize( pl:Nick() ) / 2, pos.y - 12 )
surface.DrawText( pl:Nick() )
end

if GetConVarNumber( 'easyhook_esp_health' ) ~= 0 then
surface.SetTextColor( col )
surface.SetFont( 'Default' )
surface.SetTextPos( pos.x - surface.GetTextSize( pl:Nick() ) / 2, pos.y )
surface.DrawText( pl:Health().. "% " )
end

if GetConVarNumber( 'easyhook_esp_distance') ~= 0 then
easydist = pl:GetPos():Distance( LocalPlayer():GetPos() )
surface.SetTextColor( col )
surface.SetFont( 'Default' )
surface.SetTextPos( pos.x - surface.GetTextSize( pl:Nick() ) / 2, pos.y + 12)
surface.DrawText( math.Round(easydist) .. " units")
end

if GetConVarNumber( 'easyhook_esp_snapline' ) ~= 0 then
local x = ScrW() / 2
local y = ScrH() / 2
surface.SetDrawColor( col )
surface.DrawLine( x, y , pos222.x, pos222.y )
end

if GetConVarNumber( 'easyhook_esp_headbone' ) ~= 0 then
DrawSelection(pos222)
end

if GetConVarNumber( 'easyhook_esp_box' ) ~= 0 then
surface.SetDrawColor( col )

size = 100000 / pl:GetPos():Distance( LocalPlayer():GetPos() ) * 0.90
surface.DrawOutlinedRect( pos222.x - size / 10.5 - 0 / size * 2.9, pos222.y  , size / 5 + 0 * 5 / size , size / 2 + 0 * 10 / size  )
end

if GetConVarNumber( 'easyhook_ewire' ) ~= 0 then
for _, e in pairs( ents.GetAll() ) do pcall( function() e:SetMaterial( 'models/wireframe' ) end ) end

else
for _, e in pairs( ents.GetAll() ) do pcall( function() e:SetMaterial( '' ) end ) end
end


end
end



end

if GetConVarNumber( 'easyhook_crosshair' ) ~= 0 then
surface.SetDrawColor( color_white )
surface.SetTexture( surface.GetTextureID( 'vgui/hud/autoaim' ) )
surface.DrawTexturedRectRotated( ScrW() / 2, ScrH() / 2, 32, 32, -CurTime() * 128 )

surface.SetTexture( surface.GetTextureID( 'vgui/hud/autoaim' ) )
surface.DrawTexturedRectRotated( ScrW() / 2, ScrH() / 2, 6, 6, 0 )

surface.SetFont( 'ChatFont' )
surface.SetTextColor( color_white )
surface.SetTextPos( ScrW() / 2 - surface.GetTextSize( 'Closest visible: ' .. nick ) / 2, ScrH() * 0.525 )
surface.DrawText( 'Nearest to XHair: ' .. nick )

surface.SetFont( 'ChatFont' )
surface.SetTextColor( color_white )
surface.SetTextPos( 10 , 10 )
surface.DrawText( 'EasyHook WIP V 1.2'  )
else
surface.SetFont( 'ChatFont' )
surface.SetTextColor( color_white )
surface.SetTextPos( 10 , 10 )
surface.DrawText( 'EasyHook WIP V 1.2'  )
end

concommand.Add( '-eaimbot', function() aimbot = false end )

end )
hook.Add( 'Tick', 'ClearDecals', function()
if GetConVarNumber( 'r_decals' ) <= 0 then
RunConsoleCommand( 'r_cleardecals' )
end
end )


local form1

concommand.Add( '+easyhook_menu', function()
form1 = vgui.Create( 'DFrame' )
form1:SetPos( ScrW() / 2 - 160, ScrH() / 2 - 120 )
form1:SetSize( 320, 240 )
form1:SetDraggable( false )
form1:SetVisible( true )
form1:SetTitle( 'EasyHook menu - NanoCat and Spirit' )
form1:ShowCloseButton( false )
form1:MakePopup()
form1.Paint = function()
surface.SetDrawColor( 255, 255, 255, 15 )
surface.DrawRect( 0, 0, form1:GetWide(), form1:GetTall() )

surface.SetDrawColor( 255 ,0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, form1:GetWide(), form1:GetTall() )



surface.SetDrawColor( 255, 0, 0, 255 )
surface.DrawRect( 1, 1, form1:GetWide() - 2, 22 )
end

local tabs = vgui.Create( 'DPropertySheet', form1 )
tabs:SetPos( 1, 22 )
tabs:SetSize( 318, 217 )
tabs.Paint = nil


//Aimehboth settings
local aim = vgui.Create( 'DPanel' )
aim.Paint = nil

local shd = vgui.Create( 'DCheckBoxLabel', aim )
shd:SetPos( 10,15 )
shd:SetText( 'Enable aimbot' )
shd:SetConVar( 'easyhook_aimbot' )
shd:SetTextColor( Color(255, 0, 0, 255) )
shd:SetValue( GetConVarNumber( 'easyhook_aimbot' ) )
shd:SizeToContents()

local shd = vgui.Create( 'DCheckBoxLabel', aim )
shd:SetPos( 150, 15 )
shd:SetText( 'Aim at team' )
shd:SetConVar( 'easyhook_aimbot_team' )
shd:SetTextColor( Color(255, 0, 0, 255) )
shd:SetValue( GetConVarNumber( 'easyhook_aimbot_team' ) )
shd:SizeToContents()

local shd = vgui.Create( 'DCheckBoxLabel', aim )
shd:SetPos( 10, 35 )
shd:SetText( 'Ignore friends' )
shd:SetConVar( 'easyhook_aimbot_ignore_friends' )
shd:SetTextColor( Color(255, 0, 0, 255) )
shd:SetValue( GetConVarNumber( 'easyhook_aimbot_ignore_friends' ) )
shd:SizeToContents()

local shd = vgui.Create( 'DCheckBoxLabel', aim )
shd:SetPos( 150, 35 )
shd:SetText( 'Autoshoot' )
shd:SetConVar( 'easyhook_aimbot_autoshoot' )
shd:SetTextColor( Color(255, 0, 0, 255) )
shd:SetValue( GetConVarNumber( 'easyhook_aimbot_autoshoot' ) )
shd:SizeToContents()

//Whespssszzzz settings
local whesp = vgui.Create( 'DPanel' )
whesp.Paint = nil


local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos(  10,15  )
shd2:SetText( 'ESP health' )
shd2:SetConVar( 'easyhook_esp_health' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_health' ) )
shd2:SizeToContents()

local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos( 10, 35 )
shd2:SetText( 'ESP name' )
shd2:SetConVar( 'easyhook_esp_name' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_name' ) )
shd2:SizeToContents()

local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos( 10,55 )
shd2:SetText( 'ESP boxes' )
shd2:SetConVar( 'easyhook_esp_box' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_box' ) )
shd2:SizeToContents()

local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos( 10,75 )
shd2:SetText( 'Snap Line' )
shd2:SetConVar( 'easyhook_esp_snapline' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_snapline' ) )
shd2:SizeToContents()

local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos(  150,15  )
shd2:SetText( 'ESP Head Marker' )
shd2:SetConVar( 'easyhook_esp_headbone' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_headbone' ) )
shd2:SizeToContents()

local shd2 = vgui.Create( 'DCheckBoxLabel', whesp )
shd2:SetPos( 150,35 )
shd2:SetText( 'ESP Distance' )
shd2:SetConVar( 'easyhook_esp_distance' )
shd2:SetTextColor( Color(255, 0, 0, 255) )
shd2:SetValue( GetConVarNumber( 'easyhook_esp_distance' ) )
shd2:SizeToContents()


//otharfunctionz
local misc = vgui.Create( 'DPanel' )
misc.Paint = nil

local shd23 = vgui.Create( 'DCheckBoxLabel', misc )
shd23:SetPos(  10,15  )
shd23:SetText( 'Wallhack' )
shd23:SetConVar( 'easyhook_whack' )
shd23:SetTextColor( Color(255, 0, 0, 255) )
shd23:SetValue( GetConVarNumber( 'easyhook_whack' ) )
shd23:SizeToContents()

local shd24 = vgui.Create( 'DCheckBoxLabel', misc )
shd24:SetPos(  10,35  )
shd24:SetText( 'Crosshair' )
shd24:SetConVar( 'easyhook_crosshair' )
shd24:SetTextColor( Color(255, 0, 0, 255) )
shd24:SetValue( GetConVarNumber( 'easyhook_crosshair' ) )
shd24:SizeToContents()

local shd24 = vgui.Create( 'DCheckBoxLabel', misc )
shd24:SetPos(  10,55  )
shd24:SetText( 'Wireframe entities' )
shd24:SetConVar( 'easyhook_ewire' )
shd24:SetTextColor( Color(255, 0, 0, 255) )
shd24:SetValue( GetConVarNumber( 'easyhook_ewire' ) )
shd24:SizeToContents()

local shd23 = vgui.Create( 'DCheckBoxLabel', misc )
shd23:SetPos(  10,75  )
shd23:SetText( 'Fix recoil' )
shd23:SetConVar( 'easyhook_removerecoil' )
shd23:SetTextColor( Color(255, 0, 0, 255) )
shd23:SetValue( GetConVarNumber( 'easyhook_removerecoil' ) )
shd23:SizeToContents()


tabs:AddSheet( 'Aimbot', aim, 'vgui/hud/autoaim', false, false, 'Aimbot configuration' )
tabs:AddSheet( 'Wallhack and ESP', whesp, 'vgui/hud/autoaim', false, false, 'ESP settings' )
tabs:AddSheet( 'Misc', misc, 'vgui/hud/autoaim', false, false, 'Other functions' )
tabs.Paint = nil
end )

concommand.Add( '-easyhook_menu', function()
hook.Remove( 'Tick', 'PerfRatesUpdate' )
form1:Remove()
end )