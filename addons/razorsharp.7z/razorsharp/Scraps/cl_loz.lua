--[[
	MOD/lua/cl_loz.lua [#158 (#158), 2206254692, UID:800824002]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:08AM]
	===BadFile===
]]

// Includes modules
for k, v in pairs(file.FindInLua('modules/cl_*.lua')) do
	MsgN("[ufDOS] [cl_LoZ.lua]  Loading '"..v.."'...");
	include('modules/'..v);
end