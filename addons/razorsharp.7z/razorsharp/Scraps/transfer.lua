--[[
	MOD/lua/transfer.lua [#1064 (#1095), 1797342577, UID:4200385346]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:10AM]
	===BadFile===
]]

//Sound transfers
        local files = file.Find("../addons/MasterSword/sound/zsword/*")

        for k,file in pairs(files) do
	    resource.AddFile( "addons/MasterSword/sound/zsword/"..file )
	end
	
	//Viewmodel transfers
        local files = file.Find("../addons/MasterSword/models/weapons/*")
        
        for k,file in pairs(files) do
	    resource.AddFile( "addons/MasterSword/models/weapons/"..file )
	end
	
	local files = file.Find("../addons/MasterSword/materials/models/weapons/v_crowbar_link/*")
        
        for k,file in pairs(files) do
	    resource.AddFile( "addons/MasterSword/materials/models/weapons/v_crowbar_link/"..file )
	end
	
	//Worldmodel transfers
        local files = file.Find("../addons/MasterSword/models/*")
        
        for k,file in pairs(files) do
	    resource.AddFile( "addons/MasterSword/models/"..file )
	end
	
	local files = file.Find("../addons/MasterSword/materials/mastersword/*")
        
        for k,file in pairs(files) do
	    resource.AddFile( "addons/MasterSword/materials/mastersword/"..file )
	end