--[[
	MOD/lua/razorsharp/aimbot.lua [#1481 (#1523), 4032473872, UID:2776169842]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:15PM]
	===BadFile===
]]

--[[
Razor Aimbot by Razor
Version 1.3
]]--

function aimbot()
	CreateClientConVar( "razor_aim", 0, true, false )
	if ConVarExists( "razor_aim" ) and GetConVar( "razor_aim" ):GetInt() == 1 then
		local ply = LocalPlayer()   
		local trace = util.GetPlayerTrace( ply )  
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
			local target = traceRes.Entity      
				if target:IsPlayer() then          
					local targethead = target:LookupBone("ValveBiped.Bip01_Head1")         
					local targetheadpos,targetheadang = target:GetBonePosition(targethead)            
					ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())     
				end    
		end
	end
end
hook.Add("Think","aimbot",aimbot)

function npcaimbot()
CreateClientConVar( "razor_npcaim", 0, true, false )
if ConVarExists( "razor_npcaim" ) and GetConVar("razor_npcaim"):GetInt() == 1 then
	local ply = LocalPlayer()   
	local trace = util.GetPlayerTrace( ply )  
	local traceRes = util.TraceLine( trace )
	if traceRes.HitNonWorld then
		local target = traceRes.Entity      
			if target:IsNPC() then          
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1")         
				local targetheadpos,targetheadang = target:GetBonePosition(targethead)            
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())     
			end    
		end
	end
end
hook.Add("Think","npcaimbot",npcaimbot)

Msg("Razor Sharp's Aimbot loaded!\n")
Msg("Razor Sharp's NPC Aimbot loaded!\n")