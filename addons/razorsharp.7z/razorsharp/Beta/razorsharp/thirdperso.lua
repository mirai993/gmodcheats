--[[
	MOD/lua/razorsharp/thirdperson.lua [#491 (#511), 679549745, UID:3666334887]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:22PM]
	===BadFile===
]]

--[[CreateClientConVar("razor_thirdperson",0 )

hook.Add("CalcView", "tp", function(p, pos,ang,f)
	if GetConVarNumber("razor_thirdperson") == 1 and LocalPlayer():Alive() then
	dist = GetConVarString("razor_thirdperson")
		local view = {}
		view.origin = pos-(ang:Forward() * 150)
		view.angles = ang
		view.fov = f
		return view
	end
end)

hook.Add("ShouldDrawLocalPlayer", "draw", function()
	if GetConVarNumber("razor_thirdperson") == 1 then
		return true
	else
		return false
	end
end)
]]