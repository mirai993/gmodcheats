--[[
	MOD/lua/razorsharp/flspam.lua [#646 (#676), 1728048115, UID:392705748]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:17PM]
	===BadFile===
]]

--[[
Razor Flashlightspam by Razor
Version 1.1
]]--

CreateClientConVar("razor_fspam", 0)

function spamflashlight()
	if input.IsKeyDown(KEY_F) then
		timer.Simple(0.01, function()
			RunConsoleCommand("impulse", "100")
		end)
		timer.Simple(0.02, function()
			RunConsoleCommand("impulse", "100")
		end)
	end
end

hook.Remove("CreateMove", "fspam")

if GetConVarNumber("razor_fspam") == 1 then
	hook.Add("CreateMove", "fspam", spamflashlight)
end

cvars.AddChangeCallback("razor_fspam", function()
	if GetConVarNumber("razor_fspam") == 1 then
		hook.Add("CreateMove", "fspam", spamflashlight)
	else
		hook.Remove("CreateMove", "fspam")
	end
end)