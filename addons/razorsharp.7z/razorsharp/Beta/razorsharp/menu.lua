--[[
	MOD/lua/razorsharp/menu.lua [#11628 (#12042), 1362029416, UID:2701747038]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:19PM]
	===BadFile===
]]

--[[
Razor Menu by Razor.
Version 1.2 
]]--

CreateClientConVar("razor_rainbow", 1)

local Panel = vgui.Create( "DFrame" )
Panel:SetSize(500, 530)
Panel:SetTitle( "Razor Menu" )
Panel:SetVisible( true )
Panel:SetDraggable( true )
Panel:ShowCloseButton( false )
function Panel:Paint( w, h )
	draw.RoundedBox(0,0,0,w,h,Color(89,144,90))
	surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(1,1,w-2,h-2)
end

Panel:Center()
Panel:MakePopup()


local Sheet = vgui.Create( "DPropertySheet" )
Sheet:SetParent( Panel )
Sheet:SetPos( 20, 30 )
Sheet:SetSize( 450, 450 )

--[[f13 = vgui.Create("DPanel", Sheet)
f13:SetSize(400, 400)
function f13:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0) )
	surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(1, 1, w-2, h-2)
end
]]

f1 = vgui.Create("DPanel", Sheet)
f1:SetSize(400, 400)
function f1:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(255,150,30) )
	surface.SetDrawColor(0,0,0)
	surface.DrawOutlinedRect(1, 1, w-2, h-2)
end

f2 = vgui.Create("DPanel", Sheet)
f2:SetSize(400, 400)
function f2:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(50,150,60) )
end

f12 = vgui.Create("DPanel", Sheet)
f12:SetSize(400, 400)
function f12:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(0,150,60) )
end

f3 = vgui.Create("DPanel", Sheet)
f3:SetSize(400, 400)
function f3:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(90,30,20) )
end

f4 = vgui.Create("DPanel", Sheet)
f4:SetSize(400, 400)
function f4:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(30,150,240) )
end

f5 = vgui.Create("DPanel", Sheet)
f5:SetSize(400, 400)
function f5:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(100,50,240) )
end

f6 = vgui.Create("DPanel", Sheet)
f6:SetSize(400, 400)
function f6:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(10,10,250) )
end

f7 = vgui.Create("DPanel", Sheet)
f7:SetSize(400, 400)
function f7:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(100,50,240) )
end

f8 = vgui.Create("DPanel", Sheet)
f8:SetSize(400, 400)
function f8:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(100,50,240) )
end

f10 = vgui.Create("DPanel", Sheet)
f10:SetSize(400, 400)
function f10:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(255,50,150) )
end

f9 = vgui.Create("DPanel", Sheet)
f9:SetSize(400, 400)
function f9:Paint( w, h )
	if GetConVarNumber("razor_rainbow") == 1 then
		draw.RoundedBox( 0, 0, 0, w, h, Color( math.random(0, 255), math.random(0, 255), math.random(0, 255) ) )
	else
		draw.RoundedBox( 0, 0, 0, w, h, Color( 180, 60, 89 ) )
	end
end

f11 = vgui.Create("DPanel", Sheet )
f11:SetSize(400,400)
function f11:Paint( w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color(94,120,150) )
end


local AimA1 = vgui.Create( "DCheckBoxLabel" )
AimA1:SetParent(f1)
AimA1:SetText( "Enable Aimbot" )
AimA1:SetPos(5, 5)
AimA1:SetConVar( "razor_aim" )
AimA1:SetValue( GetConVarNumber( "razor_aim" ) )
AimA1:SetSize(250, 20)
 
local AimA2 = vgui.Create( "DCheckBoxLabel" )
AimA2:SetParent(f1)
AimA2:SetText( "Enable NPC Aimbot" )
AimA2:SetPos(5, 25)
AimA2:SetConVar( "razor_npcaim" )
AimA2:SetValue( GetConVarNumber( "razor_npcaim" ) )
AimA2:SetSize(250, 20)
 
local TriggerA1 = vgui.Create( "DCheckBoxLabel")
TriggerA1:SetParent(f2)
TriggerA1:SetText( "Enable Triggerbot" )
TriggerA1:SetConVar( "razor_triggerbot" )
TriggerA1:SetValue( GetConVarNumber( "razor_triggerbot" ) )
TriggerA1:SizeToContents()
TriggerA1:SetSize(250, 20)
TriggerA1:SetPos(5, 5)
 
local TriggerA2 = vgui.Create( "DCheckBoxLabel")
TriggerA2:SetParent(f2)
TriggerA2:SetText( "Enable NPC Triggerbot" )
TriggerA2:SetConVar( "razor_npctriggerbot" )
TriggerA2:SetValue( GetConVarNumber( "razor_npctriggerbot" ) )
TriggerA2:SetSize(250, 20)
TriggerA2:SetPos(5, 25)

local EspA1 = vgui.Create( "DCheckBoxLabel")
EspA1:SetParent(f3)
EspA1:SetText( "Enable ESP" )
EspA1:SetConVar( "razor_esp" )
EspA1:SetValue( GetConVarNumber( "razor_esp" ) )
EspA1:SetSize(250, 20)
EspA1:SetPos(5, 5)

local EspA2 = vgui.Create( "DCheckBoxLabel")
EspA2:SetParent(f3)
EspA2:SetText( "Enable NPC ESP" )
EspA2:SetConVar( "razor_npcesp" )
EspA2:SetValue( GetConVarNumber( "razor_npcesp" ) )
EspA2:SetSize(250, 20)
EspA2:SetPos(5, 25)

local EspA5 = vgui.Create( "DCheckBoxLabel" )
EspA5:SetParent(f3)
EspA5:SetText("Show Skeleton")
EspA5:SetConVar("razor_skeleton")
EspA5:SetValue( GetConVarNumber( "razor_skeleton" ) )
EspA5:SetSize(250, 20)
EspA5:SetPos(5, 85)

local Bhop = vgui.Create( "DCheckBoxLabel")
Bhop:SetParent(f12)
Bhop:SetText( "Enable BHop" )
Bhop:SetConVar( "razor_bhop" )
Bhop:SetValue( GetConVarNumber( "razor_bhop" ) )
Bhop:SetSize(250, 20)
Bhop:SetPos(5, 5)

local EspA3 = vgui.Create( "DCheckBoxLabel")
EspA3:SetParent(f3)
EspA3:SetText( "Enable Wallhack" )
EspA3:SetConVar( "razor_newwh" )
EspA3:SetValue( GetConVarNumber( "razor_newwh" ) )
EspA3:SetSize(250, 20)
EspA3:SetPos(5, 45)

local EspA4 = vgui.Create( "DCheckBoxLabel")
EspA4:SetParent(f3)
EspA4:SetText( "Enable Itemfinder" )
EspA4:SetConVar( "razor_itemwh" )
EspA4:SetValue( GetConVarNumber( "razor_itemwh" ) )
EspA4:SetSize(250, 20)
EspA4:SetPos(5, 65)

local EspA6 = vgui.Create( "DCheckBoxLabel" )
EspA6:SetParent(f3)
EspA6:SetText("Enable Prop Wallhack")
EspA6:SetConVar("razor_propwh")
EspA6:SetValue( GetConVarNumber( "razor_propwh") )
EspA6:SetSize(250, 20)
EspA6:SetPos(5, 105)

local EspA7 = vgui.Create( "DCheckBoxLabel" )
EspA7:SetParent(f3)
EspA7:SetText("Enable Chams")
EspA7:SetConVar("razor_chams")
EspA7:SetValue( GetConVarNumber( "razor_chams") )
EspA7:SetSize(250, 20)
EspA7:SetPos(5, 125)

local CsA1 = vgui.Create( "DCheckBoxLabel" )
CsA1:SetParent(f4)
CsA1:SetText( "Enable Chatspam" )
CsA1:SetConVar( "razor_chatspam" )
CsA1:SetValue( GetConVarNumber( "razor_chatspam" ) )
CsA1:SetSize(250, 20)
CsA1:SetPos(5, 5)

local CsLabel = vgui.Create( "DLabel", f4 )
CsLabel:SetPos( 5, 25 )
CsLabel:SetSize(380,20)
CsLabel:SetText( "Type the text you want to spam, then press enter." )

local CsText = vgui.Create( "DTextEntry", f4)
CsText:SetPos( 5,50 )
CsText:SetTall( 20 )
CsText:SetWide( 380 )
CsText:SetEnterAllowed( true )
CsText.OnEnter = function()
    RunConsoleCommand("razor_chatspam_msg", CsText:GetValue())
end

Cross = vgui.Create( "DCheckBoxLabel" )
Cross:SetParent(f6)
Cross:SetText( "Enable Crosshair" )
Cross:SetConVar( "razor_crosshair" )
Cross:SetValue( GetConVarNumber( "razor_crosshair" ) )
Cross:SetSize(250, 20)
Cross:SetPos(5, 5)

FovA1 = vgui.Create( "DCheckBoxLabel" )
FovA1:SetParent(f5)
FovA1:SetText( "Enable FOV-Changer" )
FovA1:SetConVar( "razor_fov_enable" )
FovA1:SetValue( GetConVarNumber( "razor_fov_enable" ) )
FovA1:SetSize(250, 20)
FovA1:SetPos(5, 5)

FLA1 = vgui.Create( "DCheckBoxLabel" )
FLA1:SetParent(f11)
FLA1:SetText( "Enable Flashlight Spam" )
FLA1:SetConVar( "razor_fspam" )
FLA1:SetValue( GetConVarNumber( "razor_fspam" ) )
FLA1:SetSize(250, 20)
FLA1:SetPos(5, 5)

local FovA2 = vgui.Create( "DNumSlider", f5 )
FovA2:SetPos( 5,25 )
FovA2:SetSize( 380, 20 )
FovA2:SetText( "New FOV" )
FovA2:SetMin( 20 )
FovA2:SetMax( 180 )
FovA2:SetDecimals( 0 )
FovA2:SetConVar( "razor_fov" )


local Pafa = vgui.Create( "DButton" )
Pafa:SetParent( f7 )
Pafa:SetText( "Print Admins (FAdmin (DarkRP) ) to console" )
Pafa:SetPos( 25, 5 )
Pafa:SetSize( 300, 30 )
Pafa.DoClick = function ()
    RunConsoleCommand( "razor_admincheckfadmin" )
end

local PaUlx = vgui.Create( "DButton" )
PaUlx:SetParent( f7 )
PaUlx:SetText( "Print Admins (ULX) to console" )
PaUlx:SetPos( 25, 35 )
PaUlx:SetSize( 300, 30 )
PaUlx.DoClick = function ()
    RunConsoleCommand( "razor_admincheckulx" )
end

local PM = vgui.Create( "DButton" )
PM:SetParent( f7 )
PM:SetText( "Print Players Money (DarkRP) to console" )
PM:SetPos( 25, 65 )
PM:SetSize( 300, 30 )
PM.DoClick = function ()
    RunConsoleCommand( "razor_moneycheck" )
end

local CG = vgui.Create( "DButton" )
CG:SetParent( f7 )
CG:SetText( "Crash your Garry's Mod" )
CG:SetPos( 25, 95 )
CG:SetSize( 300, 30 )
CG.DoClick = function ()
    RunConsoleCommand( "razor_crashmygmod" )
end
 
local DPG = vgui.Create( "DCheckBoxLabel" )
DPG:SetParent(f8)
DPG:SetText( "Enable DarkRP 2.4.3 God" )
DPG:SetConVar( "razor_darkrpgod" )
DPG:SetValue( GetConVarNumber( "razor_darkrpgod" ) )
DPG:SetSize(250, 20)
DPG:SetPos(5,5)

local cn = vgui.Create( "DButton" )
cn:SetParent( Panel )
cn:SetText( "Close" )
cn:SetPos( 225, 500 )
cn:SetSize( 50, 25 )
cn.DoClick = function ()
    Panel:SetVisible( false )
end

local Atext = vgui.Create( "DLabel", f9 )
Atext:SetSize( 400, 380)
Atext:SetPos( 5, 25 )
Atext:SetText([[ First of all, i would like to thank anyone who supported me in any way.
 I would like to thank my friends, which supported me during the time i made this.
 It's your time to shine Darkboy^, Jack the Ripper, Blubbb and other mates.
 
 It was a pain in the ass to do this menu. I'm going to make this prettier, no worries.
 
 If anyone wants to donate something towards me, i would be happy about some 
 games. 
 If someone donates anything, he will be in my credits and the Donations tab.
 
 If you got any recommendations/questions about my scripts, feel free to add me.
 Also, if you want to play with me, you can add me, and ill play with you ASAP.
 
 I play:
 
 Garry's Mod
 Counter-Strike (All)
 Just Cause 2 Multiplayer
 Some other Random shit.
 ]])
 
 local Dtext = vgui.Create( "DLabel", f10 )
 Dtext:SetSize( 400, 380 )
 Dtext:SetPos( 5, 25 )
 Dtext:SetText([[ List of donations:
 
 None so far.
 Read informations about this on the about tab.]])
	
local cn = vgui.Create( "DButton" )
cn:SetParent( f9 )
cn:SetText( "Turn Rainbow Colors on/off" )
cn:SetPos( 115, 20 )
cn:SetSize( 200, 25 )
cn.DoClick = function ()
    if GetConVarNumber("razor_rainbow") == 1 then
		LocalPlayer():ConCommand("razor_rainbow 0")
	else
		LocalPlayer():ConCommand("razor_rainbow 1")
	end
end
--[[
local third = vgui.Create( "DCheckBoxLabel" )
third:SetParent(f13)
third:SetText( "Enable Thirdperson" )
third:SetConVar( "razor_thirdperson" )
third:SetValue( GetConVarNumber( "razor_thirdperson" ) )
third:SetSize(250, 20)
third:SetPos(5, 5)


local thirdd = vgui.Create( "DNumSlider", f13 )
thirdd:SetPos( 5,25 )
thirdd:SetSize( 380, 20 )
thirdd:SetText( "Distance" )
thirdd:SetMin( 50 )
thirdd:SetMax( 500 )
thirdd:SetDecimals( 0 )
thirdd:SetConVar( "razor_thirdperson_dist" )
]]



Sheet:AddSheet( "Aimbot", f1, nil, false, false, "Adjust Aimbot settings here." )
Sheet:AddSheet( "Triggerbot", f2,nil, false, false, "Adjust Triggerbot settings here." ) 
Sheet:AddSheet( "Wallhack/ESP", f3, nil, false, false, "Adjust Wallhack/ESP settings here." )
Sheet:AddSheet( "Chatspam", f4, nil, false, false, "Adjust Chatspam settings here." )
Sheet:AddSheet( "FOV Changer", f5, nil, false, false, "Adjust FOV Changer settings here." )
Sheet:AddSheet( "Crosshair", f6, nil, false, false, "Adjust Crosshair settings here." )
Sheet:AddSheet( "DarkRP God", f8, nil, false, false, "Adjust DarkRP God settings here." )
Sheet:AddSheet( "Flashlight Spam", f11, nil, false, false, "Adjust Flashlight Spam settings here." )
Sheet:AddSheet( "BHop", f12, nil, false, false, "Adjust BHop settings here." )
--Sheet:AddSheet( "Thirdperson", f13, nil, false, false, "Adjust Thirdperson settings here." )
Sheet:AddSheet( "Various functions", f7, nil, false, false, "Execute Various functions here." )
Sheet:AddSheet( "About", f9, nil, false, false, "Information about Razor's Scripts." )
Sheet:AddSheet( "Donations", f10, nil, false, false, "All Donations are listed here. ")

concommand.Add("razor_menu", function()
	Panel:SetVisible( true )
end)

concommand.Add("razor_crashmygmod", function()
	cam.End3D()
end)

--[[
End of Razor Menu by Razor.
Version 1.2
]]--
