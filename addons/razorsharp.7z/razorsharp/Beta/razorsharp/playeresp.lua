--[[
	MOD/lua/razorsharp/playeresp.lua [#5544 (#5714), 2056025103, UID:742402585]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:20PM]
	===BadFile===
]]

--[[
Razor ESP by Razor
Version 1.5
]]--

local RB = {}

local function RazorBuddys(body)
	local RazorIDs = string.Explode("|", body)
	for k, v in pairs(RazorIDs) do
		print("We successfully got the Member's SteamIDs!")
		table.insert(RB, v)
	end
end


local function ContactTheGroupMate()
	http.Fetch("https://googledrive.com/host/0B8HxW9pc-H_tbzZfclpPQm5tU3M/ids.html", RazorBuddys, OnFailure)
end

local function OnFailure()
	Msg("We couldn't get the Group data!")
end

ContactTheGroupMate()

local espcvar = CreateClientConVar( "razor_esp", 0, true, false ) 


local bones = {
{ g = "ValveBiped.Bip01_Head1", h = "ValveBiped.Bip01_Neck1" },
{ g = "ValveBiped.Bip01_Neck1", h = "ValveBiped.Bip01_Spine4" },
{ g = "ValveBiped.Bip01_Spine4", h = "ValveBiped.Bip01_Spine2" },
{ g = "ValveBiped.Bip01_Spine2", h = "ValveBiped.Bip01_Spine1" },
{ g = "ValveBiped.Bip01_Spine1", h = "ValveBiped.Bip01_Spine" },
{ g = "ValveBiped.Bip01_Spine", h = "ValveBiped.Bip01_Pelvis" },
{ g = "ValveBiped.Bip01_Spine4", h = "ValveBiped.Bip01_L_UpperArm" },
{ g = "ValveBiped.Bip01_L_UpperArm", h = "ValveBiped.Bip01_L_Forearm" },
{ g = "ValveBiped.Bip01_L_Forearm", h = "ValveBiped.Bip01_L_Hand" },
{ g = "ValveBiped.Bip01_Spine4", h = "ValveBiped.Bip01_R_UpperArm" },
{ g = "ValveBiped.Bip01_R_UpperArm", h = "ValveBiped.Bip01_R_Forearm" },
{ g = "ValveBiped.Bip01_R_Forearm", h = "ValveBiped.Bip01_R_Hand" },
{ g = "ValveBiped.Bip01_Pelvis", h = "ValveBiped.Bip01_L_Thigh" },
{ g = "ValveBiped.Bip01_L_Thigh", h = "ValveBiped.Bip01_L_Calf" },
{ g = "ValveBiped.Bip01_L_Calf", h = "ValveBiped.Bip01_L_Foot" },
{ g = "ValveBiped.Bip01_L_Foot", h = "ValveBiped.Bip01_L_Toe0" },
{ g = "ValveBiped.Bip01_Pelvis", h = "ValveBiped.Bip01_R_Thigh" },
{ g = "ValveBiped.Bip01_R_Thigh", h = "ValveBiped.Bip01_R_Calf" },
{ g = "ValveBiped.Bip01_R_Calf", h = "ValveBiped.Bip01_R_Foot" },
{ g = "ValveBiped.Bip01_R_Foot", h = "ValveBiped.Bip01_R_Toe0" },
}

CreateClientConVar("razor_skeleton", 0)
function boneeesp()
	if GetConVarNumber("razor_skeleton") == 1 then
		local allplys = player.GetAll()
		for k, v in pairs(bones) do
			for a,s in pairs(allplys) do
				if s:GetModel() != "" and s:GetModel() != "models/error.mdl" then
				local sPos, ePos = s:GetBonePosition( s:LookupBone( v.g ) ):ToScreen(), s:GetBonePosition( s:LookupBone( v.h ) ):ToScreen()
				if s:IsValid() and s != LocalPlayer() and s:Alive() then
					surface.SetDrawColor(Color(255,191,0,255))
					surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
				end
				end
			end
		end
	end
end

if GetConVarNumber("razor_skeleton") == 1 then
	hook.Add("HUDPaint", "boneesp", boneeesp)
end

cvars.AddChangeCallback("razor_skeleton", function()
	if GetConVarNumber("razor_skeleton") == 1 then
		hook.Add("HUDPaint", "boneesp", boneeesp)
	else
		hook.Remove("HUDPaint", "boneesp")
	end
end)

function box()
	for k,v in pairs(player.GetAll()) do
	if v:IsValid() and v:Alive() and v != LocalPlayer() then
	bp1 = v:GetPos() + Vector(16,16,0)
	bp1 = (bp1):ToScreen()
	bp2 = v:GetPos() + Vector(16,-16,0)
	bp2 = (bp2):ToScreen()
	bp3 = v:GetPos() + Vector(-16,-16,0)
	bp3 = (bp3):ToScreen()
	bp4 = v:GetPos() + Vector(-16,16,0)
	bp4 = (bp4):ToScreen()
	bp5 = v:GetPos() + Vector(16,16,65)
	bp5 = (bp5):ToScreen()
	bp6 = v:GetPos() + Vector(16,-16,65)
	bp6 = (bp6):ToScreen()
	bp7 = v:GetPos() + Vector(-16,-16,65)
	bp7 = (bp7):ToScreen()
	bp8 = v:GetPos() + Vector(-16,16,65)
	bp8 = (bp8):ToScreen()
	
	surface.SetDrawColor(Color(25,136,90,255))
	surface.DrawLine( bp1.x, bp1.y, bp2.x, bp2.y )
	surface.DrawLine( bp2.x, bp2.y, bp3.x, bp3.y )
	surface.DrawLine( bp3.x, bp3.y, bp4.x, bp4.y )
    surface.DrawLine( bp4.x, bp4.y, bp1.x, bp1.y )
                       
    surface.DrawLine( bp5.x, bp5.y, bp6.x, bp6.y )
    surface.DrawLine( bp6.x, bp6.y, bp7.x, bp7.y )
    surface.DrawLine( bp7.x, bp7.y, bp8.x, bp8.y )
    surface.DrawLine( bp8.x, bp8.y, bp5.x, bp5.y )
                       
    surface.DrawLine( bp1.x, bp1.y, bp5.x, bp5.y )
    surface.DrawLine( bp2.x, bp2.y, bp6.x, bp6.y )
    surface.DrawLine( bp3.x, bp3.y, bp7.x, bp7.y )
    surface.DrawLine( bp4.x, bp4.y, bp8.x, bp8.y )
	end
	end
end

if GetConVarNumber("razor_esp") == 1 then
	hook.Add("HUDPaint", "3dbox", box)
end

cvars.AddChangeCallback("razor_esp", function()
	if GetConVarNumber("razor_esp") == 1 then
		hook.Add("HUDPaint", "3dbox", box)
	else
		hook.Remove("HUDPaint", "3dbox")
	end
end)

hook.Add( "HUDPaint", "Wallhack", function()
if espcvar:GetInt() == 1 then
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Positionss = ( v:GetPos() + Vector( 0,0,100 ) ):ToScreen()
		local Positionsss = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
		local Member = false
		local PlyName = ""
		if v != LocalPlayer() and v:Alive() and v:IsValid() then	
			PlyName = v:Name()
		else
			PlyName = ""
		end
		
 
		if table.HasValue(RB, v:SteamID()) then 
			Member = true 
		else
			Member = false
		end
		
		if v:Alive() and v:IsValid() and v != LocalPlayer() then
			draw.DrawText( v:Name(), "Default", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
		end
		if Member then
			draw.DrawText( "[Razor Member]", "Default", Positionss.x, Positionss.y, Color( 255, 0, 0, 255 ), 1 )
		end
		if v:SteamID() == "STEAM_0:1:40744642" and LocalPlayer():SteamID() != "STEAM_0:1:40744642" then
			draw.DrawText( "[Yes, i'm the real Razor]", "Default", Positionsss.x, Positionsss.y, Color( 0, 255, 0, 255 ), 1 )
		end

	end
 
end
end)

Msg("Razor Sharp's Player ESP loaded!\n")