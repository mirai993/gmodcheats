--[[
	MOD/lua/razorsharp/chams.lua [#1161 (#1208), 2989771724, UID:1417264917]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:15PM]
	===BadFile===
]]

CreateClientConVar("razor_chams", 0)

function chams()
for k, ent in pairs(player.GetAll()) do
if ent:IsValid() and ent:Alive() and ent != LocalPlayer() then
cam.Start3D()
	local tr = {}
	tr.start = LocalPlayer():GetShootPos()
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent}
	tr.mask = MASK_SHOT
	local trace = util.TraceLine(tr) 
	if (trace.Fraction != 1) then
	col = Color(150,45,59,255)
	else
	col = Color(45,59,150,255)
	end 
	ent:SetMaterial("models/debug/debugwhite")
	render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
	render.SetBlend(col.a / 255)
	ent:DrawModel()
cam.End3D()
end
end
end

if GetConVarNumber("razor_chams") == 1 then
	hook.Add("HUDPaint", "ch", chams)
end

cvars.AddChangeCallback("razor_chams", function()
	if GetConVarNumber("razor_chams") == 1 then
		hook.Add("HUDPaint", "ch", chams)
	else
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() and v:Alive() and v != LocalPlayer() then
				cam.Start3D()
					v:SetMaterial("")
					render.SetColorModulation(0,0,0)
					render.SetBlend(0 / 255)
					v:DrawModel()
				cam.End3D()
			end
		end
		hook.Remove("HUDPaint", "ch")
	end
end)
