--[[
	MOD/lua/razorsharp/fov.lua [#550 (#577), 2647893271, UID:2953376271]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:18PM]
	===BadFile===
]]

--[[
Razor FOV-Changer by Razor
Version 1.0
]]--

CreateClientConVar("razor_fov", 90)
CreateClientConVar("razor_fov_enable", 0)

function fov(p, o, a, f)
	local view = {}
	view.fov = GetConVarNumber("razor_fov")
	return view
end

if GetConVarNumber("razor_fov_enable") == 1 then
	hook.Add("CalcView", "fovc", fov)
end

cvars.AddChangeCallback("razor_fov_enable", function()
	if GetConVarNumber("razor_fov_enable") == 1 then
		hook.Add("CalcView", "fovc", fov)
	else
		hook.Remove("CalcView", "fovc")
	end
end)

print("Razor's FOV-Changer loaded!\n")
