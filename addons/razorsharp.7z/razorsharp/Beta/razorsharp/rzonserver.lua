--[[
	MOD/lua/razorsharp/rzonserver.lua [#349 (#371), 2305470222, UID:3068399549]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:21PM]
	===BadFile===
]]

--[[
v 1.3
Not tested or anything
]]
--[[
razon = false


function yomatecheckifimonswag()
	if razon then
		return
	else
		for k,v in pairs(player.GetAll()) do
			if v:SteamID() == "" then
				chat.AddText(Color(255,0,0), "Razor is on the server.")
				razon = true
			end
		end
	end
end

hook.Add("Think", "checkthisshit", yomatecheckifimonswag)
]]