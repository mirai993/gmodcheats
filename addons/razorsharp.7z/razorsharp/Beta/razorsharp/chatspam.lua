--[[
	MOD/lua/razorsharp/chatspam.lua [#431 (#455), 752550474, UID:2065883257]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:16PM]
	===BadFile===
]]

--[[
Razor Chatspam by Razor
Version 1.0
]]--

CreateClientConVar("razor_chatspam", 0)
CreateClientConVar("razor_chatspam_msg", "swag")

function chatsp()
	if GetConVarNumber("razor_chatspam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("razor_chatspam_msg"))
	end
end

function stimer()
	timer.Simple(2, function()
		if GetConVarNumber("razor_chatspam") == 1 then
			chatsp()
		end
		stimer()
	end)
end

stimer()
