--[[
	MOD/lua/razorsharp/triggerbot.lua [#1445 (#1505), 1721057982, UID:3686114094]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:22PM]
	===BadFile===
]]

--[[
Razor NPC & Player Triggerbot by Razor 
Version 1.3
]]--

CreateClientConVar("razor_triggerbot", 0)

function triggerbot()
	local EyeEntity = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and EyeEntity:IsPlayer() then
			if Firing then
				LocalPlayer():ConCommand("-attack")
				Firing = false
			else
				LocalPlayer():ConCommand("+attack")
				Firing = true
			end
		end
	end


if GetConVarNumber("razor_triggerbot") == 1 then
	hook.Add("Think", "trigger", triggerbot)
end

cvars.AddChangeCallback("razor_triggerbot", function()
	if GetConVarNumber("razor_triggerbot") == 1 then
		hook.Add("Think", "trigger", triggerbot)
	else
		hook.Remove("Think", "trigger")
	end
end)


local NpcTriggerBot = CreateClientConVar( "razor_npctriggerbot", 0, true, false )
 
hook.Add( "Think", "NpcTriggerbot", function()
 
    local Target = LocalPlayer():GetEyeTrace().Entity
 
    if NpcTriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsNPC() ) then
 
        if !Firing then
 
            RunConsoleCommand( "+attack" )
	    timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
            Firing = true
 
        else
 
            RunConsoleCommand( "-attack" ) 
            Firing = false
 
        end
 
    end
 
end )

Msg("Razor Sharp's Triggerbot loaded!\n")
Msg("Razor Sharp's NPC Triggerbot loaded!\n")