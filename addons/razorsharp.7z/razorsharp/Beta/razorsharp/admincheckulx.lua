--[[
	MOD/lua/razorsharp/admincheckulx.lua [#306 (#319), 1896319934, UID:1946711840]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:14PM]
	===BadFile===
]]

--[[
Razor ULX Admin Check by Razor
Version 1.2
-]]

concommand.Add("razor_admincheckulx", function()
	for k, v in pairs(player.GetAll()) do
		if v:GetUserGroup() != "user" then
			print(v:GetName().."        "..v:GetNWString("usergroup"))
		end
	end	
end)

Msg("Razor Sharp's Admin Check (ULX) loaded!\n")