--[[
	MOD/lua/razorsharp/crosshair.lua [#726 (#753), 1051259055, UID:1074782513]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:16PM]
	===BadFile===
]]

--[[
Razor Crosshair by Razor
Version 1.1
]]--

CreateClientConVar("razor_crosshair","0")

function Crosshair1()
	if GetConVarNumber("razor_crosshair") == 1 then
		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
    end
end

if GetConVarNumber("razor_crosshair") == 1 then
	hook.Add("HUDPaint", "crosshair", Crosshair1)
end

cvars.AddChangeCallback("razor_crosshair", function()
	if GetConVarNumber("razor_crosshair") == 1 then
		hook.Add("HUDPaint", "crosshair", Crosshair1)
	else
		hook.Remove("HUDPaint", "crosshair")
	end
end)

Msg("Razor Sharp's Crosshair loaded!\n")