--[[
	MOD/lua/razorsharp/exaim.lua [#574 (#595), 1463809601, UID:409689352]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:17PM]
	===BadFile===
]]

function exaimbot()
	for k, v in pairs(player.GetAll()) do
		if v:IsValid() and v:Alive() then
			if v != LocalPlayer() then
				local bone = v:LookupBone("ValveBiped.Bip01_Head1")         
				local targetheadpos = v:GetBonePosition(bone)            
				LocalPlayer():SetEyeAngles((targetheadpos - LocalPlayer():GetShootPos()):Angle())
			end
		end    
	end
end

concommand.Add("+razor_exaim", function()
	hook.Add("Think","exaim",exaimbot)
end)

concommand.Add("-razor_exaim", function()
	hook.Remove("Think","exaim")
end)

print("Razor's Experimental Aimbot loaded!\n")
