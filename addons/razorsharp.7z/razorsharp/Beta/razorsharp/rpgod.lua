--[[
	MOD/lua/razorsharp/rpgod.lua [#399 (#423), 2476625017, UID:4013406524]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:21PM]
	===BadFile===
]]

--[[
Razor DarkRP God by Razor
Version 1.0
]]--

CreateClientConVar("razor_darkrpgod", 0)

function rpgod()
	if GetConVarNumber("razor_darkrpgod") == 1 then
		if LocalPlayer():Health() < 75 then
			LocalPlayer():ConCommand("say /buyhealth")
		end
	end
end

function gtimer()
	timer.Simple(2, function()
		if GetConVarNumber("razor_chatspam") == 1 then
			rpgod()
		end
		gtimer()
	end)
end

gtimer()