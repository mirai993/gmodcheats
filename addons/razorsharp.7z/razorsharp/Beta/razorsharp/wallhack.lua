--[[
	MOD/lua/razorsharp/wallhack.lua [#1843 (#1921), 2764726028, UID:1916072995]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:23PM]
	===BadFile===
]]

--[[
Razor Wallhack by Razor
Version 1.0
]]--

CreateClientConVar( "razor_newwh", 0)

function newwh()
	cam.Start3D() -- Draw Models
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() and v:Alive() then
				if v != LocalPlayer() then		
					v:DrawModel()
					v:SetMaterial("models/wireframe")
					v:SetColor(Color(255,255,255,255))
				end
			end
		end
	cam.End3D()
 end
 

hook.Remove("HUDPaint", "whnew")
 
if GetConVarNumber("razor_newwh") == 1 then
	hook.Add("HUDPaint", "whnew", newwh)
else
	hook.Remove("HUDPaint", "whnew")
end

cvars.AddChangeCallback("razor_newwh", function()
	if GetConVarNumber("razor_newwh") == 1 then
		hook.Add("HUDPaint", "whnew", newwh)
	else
		cam.Start3D()
		for k,v in pairs(player.GetAll()) do 
			if v:IsValid() and v != LocalPlayer() then
				v:DrawModel()
				v:SetMaterial("")
				v:SetColor(255,255,255,255)
				
			end
		end
		cam.End3D()
		hook.Remove("HUDPaint", "whnew")
	end
end)

CreateClientConVar( "razor_itemwh", 0)

function entwh()
	for k,Ent in pairs(ents.GetAll()) do
		local Posit = (Ent:GetPos()+Vector(0,0,20)):ToScreen()
		if string.find(Ent:GetClass(), "spawned_") or string.find(Ent:GetClass(), "printer") or string.find(Ent:GetClass(), "weapon_ttt_c4") then
			if Ent:IsValid() then
				if Ent:GetClass() == "spawned_money" then
					draw.SimpleText(Ent:GetClass().."   $"..Ent:Getamount(),"Default",Posit.x,Posit.y,Color(255,0,0),0,0,1,Color(255,255,255))
				else
					draw.SimpleText(Ent:GetClass(),"Default",Posit.x,Posit.y,Color(255,0,0),0,0,1,Color(255,255,255))
				end
			end
		end
	end

end

			
if GetConVarNumber("razor_itemwh") == 1 then
	hook.Add("HUDPaint", "iwh", entwh)
end

cvars.AddChangeCallback("razor_itemwh", function()
	if GetConVarNumber("razor_itemwh") == 1 then
		hook.Add("HUDPaint", "iwh", entwh)
	else
		hook.Remove("HUDPaint", "iwh")
	end
end)
