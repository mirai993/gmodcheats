--[[
	MOD/lua/razorsharp/propwh.lua [#1173 (#1219), 231022084, UID:390039567]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:20PM]
	===BadFile===
]]

--[[CreateClientConVar("razor_propwh", 0)


function seeprops()
	for k,v in pairs(ents.GetAll()) do
		if v:GetClass() == "prop_physics" and v:IsValid() then
			cam.Start3D()
			local tr = {}
				tr.start = LocalPlayer():GetShootPos()
				tr.endpos = v:GetPos() + Vector(0, 0, 5)
				tr.filter = {LocalPlayer(), v}
				tr.mask = MASK_SHOT
			local trace = util.TraceLine(tr) 
			if (trace.Fraction == 1) then
				col = Color(255,191,0,255)
			else
				col = Color(20,20,20,255)
			end    
			v:SetMaterial("models/wireframe")
			render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
			render.SetBlend(col.a / 255)
			v:DrawModel()
			cam.End3D()
		end
	end
end
if GetConVarNumber("razor_propwh") == 1 then
	hook.Add("HUDPaint", "propwh", seeprops)
end

cvars.AddChangeCallback("razor_propwh", function()
	if GetConVarNumber("razor_propwh") == 1 then
		hook.Add("HUDPaint", "propwh", seeprops)
	else
		hook.Remove("HUDPaint", "propwh")
		cam.Start3D()
			for k,v in pairs(ents.GetAll()) do
				if v:GetClass() == "prop_physics" and v:IsValid() then
				v:SetMaterial("")
				render.SetColorModulation(1,1,1)
				v:DrawModel()
			end
		cam.End3D()
	end
end
end)
]]