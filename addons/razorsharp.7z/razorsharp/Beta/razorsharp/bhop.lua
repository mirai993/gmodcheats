--[[
	MOD/lua/razorsharp/bhop.lua [#734 (#773), 2231368564, UID:44284224]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:15PM]
	===BadFile===
]]

CreateClientConVar("razor_bhop", 0)
hook.Add("Think", "bunny", function()
	if rhop then
		if (input.IsKeyDown( KEY_SPACE ) ) then
			if LocalPlayer():IsOnGround() then
				RunConsoleCommand("+jump")
				HasJumped = 1
			else
				RunConsoleCommand("-jump")
				HasJumped = 0
			end
		elseif rhop and LocalPlayer():IsOnGround() then
			if HasJumped == 1 then
				RunConsoleCommand("-jump")
				HasJumped = 0
			end
		end
	end
end)

function startupcheck()
	if GetConVarNumber("razor_bhop") == 1 then
		rhop = true
	else
		rhop = false
	end
end

startupcheck()

cvars.AddChangeCallback("razor_bhop", function()
	if GetConVarNumber("razor_bhop") == 1 then
		rhop = true
	else
		rhop = false
	end
end)


Msg("Razor Sharp's BHop loaded!\n")