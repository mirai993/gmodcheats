--[[
	MOD/lua/razorsharp/admincheckfadmin.lua [#317 (#331), 1051254171, UID:702537346]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:14PM]
	===BadFile===
]]

--[[
Razor FAdmin Admin Check by Razor
Version 1.2
-]]

concommand.Add("razor_admincheckfadmin", function()
	for k, v in pairs(player.GetAll()) do
		if v:GetNWString("usergroup") != "user" then
			print(v:GetName().."          "..v:GetUserGroup())
		end
	end
end)

Msg("Razor Sharp's Admin Check (FAdmin) loaded!\n")
