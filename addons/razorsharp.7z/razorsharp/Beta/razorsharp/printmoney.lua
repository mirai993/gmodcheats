--[[
	MOD/lua/razorsharp/printmoney.lua [#258 (#269), 3241029332, UID:338020700]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:20PM]
	===BadFile===
]]

--[[
Razor Moneycheck by Razor
Version 1.2
]]--

concommand.Add("razor_moneycheck", function()
	for k, v in ipairs( player.GetAll() ) do
		print( Format( "%s has %i $!", v:Nick(), v.DarkRPVars.money ) )
	end
end)

Msg("Razor Sharp's Money Checker loaded!\n")