--[[
	MOD/lua/razor.lua [#2348 (#2432), 1363110684, UID:958912049]
	KingChicken | STEAM_0:0:39593848 <24.20.248.170:27005> | [08.06.14 10:24:06PM]
	===BadFile===
]]

--[[
Razor Scripts by Razor
Version 2.2
]]--

Msg("\n")

include "razorsharp/aimbot.lua"
include "razorsharp/triggerbot.lua"
include "razorsharp/playeresp.lua"
include "razorsharp/triggerbot.lua"
include "razorsharp/npcesp.lua"
include "razorsharp/entwh.lua"
include "razorsharp/crosshair.lua"
include "razorsharp/bhop.lua"
include "razorsharp/admincheckulx.lua"
include "razorsharp/admincheckfadmin.lua"
include "razorsharp/printmoney.lua"
include "razorsharp/wallhack.lua"
include "razorsharp/rpgod.lua"
include "razorsharp/chatspam.lua"
include "razorsharp/fov.lua"
include "razorsharp/rzonserver.lua"
include "razorsharp/flspam.lua"
include "razorsharp/propwh.lua"
include "razorsharp/chams.lua"
include "razorsharp/thirdperson.lua"
timer.Simple(1, function()
	include "razorsharp/menu.lua"
end)

Msg("\n")
Msg("------------------------------------------------------------------\n")
Msg("\n")
Msg("###### ##### ##### ##### #####\n")
Msg("#    # #   #     # #   # #   #\n")
Msg("#    # #   #     # #   # #   #\n")
Msg("###### #   #    #  #   # #####\n")
Msg("##     #####   #   #   # ##\n")
Msg("# #    #   #  #    #   # # #\n")
Msg("#  #   #   #  #    #   # #  #\n")
Msg("#   #  #   # #     #   # #   #\n")
Msg("#    # #   # ##### ##### #    #\n")
Msg("\n")
Msg("------------------------------------------------------------------\n")
Msg("\n")
Msg("All Scripts initialized!\n")
Msg("\n")
Msg("Have fun, and don't forgot to like and favourite if you enjoy playing with this!\n")



 
Title = "Don't forget to like! -Razor Sharp || SOME COMMANDS CHANGED, SO READ THE DESCRIPTION!"
URL = "http://steamcommunity.com/sharedfiles/filedetails/?id=233985633&searchtext=revelation"
Button = "Close"


function razor( )
    local webframe = vgui.Create( "DFrame" );
    webframe:SetTitle( Title )
    webframe:SetSize( ScrW() - 120, ScrH() - 120 )
	webframe:Center()
	webframe:SetDraggable( true )
	webframe:ShowCloseButton( true )
	webframe:SetBackgroundBlur( true )
	webframe:SetVisible( true )
    webframe:MakePopup( )

local url = vgui.Create( "HTML", webframe )
url:SetPos( 24, 50 )
url:SetSize( webframe:GetWide() - 50, webframe:GetTall() - 100 )
url:OpenURL( URL )


end
concommand.Add( "razor_info", razor )

RunConsoleCommand( "razor_info" )

local function reload_razor()
	include("razor.lua")
end
concommand.Add("razor_reload", reload_razor)
