--[[
	MOD/lua/razorsharp/bhop.lua [#627 (#656), 4138199233, UID:852530893]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:32AM]
	===BadFile===
]]

local bhop = true
hook.Add("Think", "bhop", function()
if bhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif bhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("razor_bhop", function()
if bhop then
    bhop = !bhop
else
    bhop = !bhop
end
end)


Msg("Razor Sharp's BHop loaded!\n")