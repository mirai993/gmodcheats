--[[
	MOD/lua/razorsharp/admincheckulx.lua [#565 (#585), 638228314, UID:2841644779]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:31AM]
	===BadFile===
]]

local State = -1
concommand.Add("razor_admincheckulx", function()
	State = State * -1
	if State == 1 then
		local plys = player.GetAll()
		for k, v in pairs(plys) do
			if v:GetUserGroup("") != "user" then
			print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetUserGroup())
		end
	end
else
	local plys = player.GetAll()
	for k, v in pairs(plys) do
		if v:GetUserGroup("") != "user" then
		print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetUserGroup())
	end
end
end
end)

Msg("Razor Sharp's Admin Check (ULX) loaded!\n")