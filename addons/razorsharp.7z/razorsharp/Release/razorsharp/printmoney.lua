--[[
	MOD/lua/razorsharp/printmoney.lua [#394 (#408), 2050991908, UID:3972593395]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:34AM]
	===BadFile===
]]

local State = -1
concommand.Add("razor_moneycheck", function()
	State = State * -1
	if State == 1 then
		for k, v in ipairs( player.GetAll() ) do
			print( Format( "%s has %i $!", v:Nick(), v.DarkRPVars.money ) )
		end
	else
		for k, v in ipairs( player.GetAll() ) do
			print( Format( "%s has %i $!", v:Nick(), v.DarkRPVars.money ) )
	end
end
end)

Msg("Razor Sharp's Money Checker loaded!\n")