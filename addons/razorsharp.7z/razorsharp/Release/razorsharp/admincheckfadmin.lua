--[[
	MOD/lua/razorsharp/admincheckfadmin.lua [#591 (#611), 3402044209, UID:985293661]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:30AM]
	===BadFile===
]]

local State = -1
concommand.Add("razor_admincheckfadmin", function()
	State = State * -1
	if State == 1 then
		local plys = player.GetAll()
		for k, v in pairs(plys) do
			if v:GetUserGroup("") != "user" then
			print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetNWString("usergroup"))
		end
	end
else
	local plys = player.GetAll()
	for k, v in pairs(plys) do
		if v:GetUserGroup("") != "user" then
		print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetNWString("usergroup"))
	end
end
end
end)

Msg("Razor Sharp's Admin Check (FAdmin) loaded!\n")