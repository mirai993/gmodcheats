--[[
	MOD/lua/razorsharp/crosshair.lua [#440 (#454), 568382934, UID:3813801204]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:32AM]
	===BadFile===
]]

local shouldDraw = true


local crosshair = CreateClientConVar("razor_crosshair","0",false)

function Crosshair1()
if crosshair:GetBool() then
surface.SetDrawColor(255,255,255,255)
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
    end
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

Msg("Razor Sharp's Crosshair loaded!\n")