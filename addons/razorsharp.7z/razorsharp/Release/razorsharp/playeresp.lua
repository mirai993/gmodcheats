--[[
	MOD/lua/razorsharp/playeresp.lua [#3059 (#3174), 866448156, UID:2844021869]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:34AM]
	===BadFile===
]]


local espcvar = CreateClientConVar( "razor_esp", 0, true, false ) 

function DrawESP1() 
	if espcvar:GetInt() == 1 then 
		for k, v in pairs(player.GetAll()) do 
 
			local drawColor = Color(255, 255, 255, 255); 
			local drawPosit = v:GetPos():ToScreen(); 

			drawColor = Color( 255, 255, 255, 255 ); 

			local textData = {} 
                     
			textData.pos = {} 
			textData.pos[1] = drawPosit.x; 
			textData.pos[2] = drawPosit.y; 
			textData.color = drawColor; 
			textData.font = "Default"; 
			textData.xalign = TEXT_ALIGN_CENTER; 
			textData.yalign = TEXT_ALIGN_CENTER;  
                     
		end 
	end
end

hook.Add( "HUDPaint", "DrawESP1", DrawESP1 ); 

local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end
 
 
local shouldDraw = true
 
 
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "esp1", function()
if espcvar:GetInt() == 1 then
	for k,v in pairs(player.GetAll()) do
		if(v:IsPlayer()) then 
		local x1,y1,x2,y2 = coordinates(v)
		surface.SetDrawColor(color_white)
 
 
		surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
		surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
		surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
		surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
		surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
		surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
		surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
		surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
	end
	end

	local struc = {}
	struc.pos = {}
	struc.pos[1] = 100 -- x pos
	struc.pos[2] = 200 -- y pos
	struc.color = Color(255,0,0,255) -- Red
	struc.font = "Default"
	struc.xalign = TEXT_ALIGN_CENTER -- Horizontal Alignment
	struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
	end
end)


hook.Add( "HUDPaint", "Wallhack", function()
if espcvar:GetInt() == 1 then
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Name = ""
 
		if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
		draw.DrawText( Name, "Default", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
	end
	end
 
end )

Msg("Razor Sharp's Player ESP loaded!\n")