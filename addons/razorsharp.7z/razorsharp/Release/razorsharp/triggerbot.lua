--[[
	MOD/lua/razorsharp/triggerbot.lua [#1306 (#1357), 3399166770, UID:3143757527]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:35AM]
	===BadFile===
]]

local TriggerBot = CreateClientConVar( "razor_triggerbot", 0, true, false )
 
hook.Add( "Think", "Triggerbot", function()
 
    local Target = LocalPlayer():GetEyeTrace().Entity
 
    if TriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() ) then
 
        if !Firing then
 
            RunConsoleCommand( "+attack" )
	    timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
            Firing = true
 
        else
 
            RunConsoleCommand( "-attack" ) 
            Firing = false
 
        end
 
    end
 
end )

local NpcTriggerBot = CreateClientConVar( "razor_npctriggerbot", 0, true, false )
 
hook.Add( "Think", "NpcTriggerbot", function()
 
    local Target = LocalPlayer():GetEyeTrace().Entity
 
    if NpcTriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsNPC() ) then
 
        if !Firing then
 
            RunConsoleCommand( "+attack" )
	    timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
            Firing = true
 
        else
 
            RunConsoleCommand( "-attack" ) 
            Firing = false
 
        end
 
    end
 
end )

Msg("Razor Sharp's Triggerbot loaded!\n")
Msg("Razor Sharp's NPC Triggerbot loaded!\n")