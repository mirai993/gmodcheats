--[[
	MOD/lua/razorsharp/entwh.lua [#2076 (#2145), 3977080090, UID:3200028351]
	jeff the pony | STEAM_0:0:78607451 <74.76.114.57:27005> | [06.04.14 01:57:33AM]
	===BadFile===
]]


local State = -1
concommand.Add("razor_shipmentfinder", function()
	State = State * -1
	if State == 1 then
		hook.Add("HUDPaint","shipmentfinder", function()
			for k,Ent in pairs(ents.GetAll()) do 
				if string.find(Ent:GetClass(),"spawned_shipment") then
					local ShipPos = (Ent:GetPos()+Vector(0,0,20)):ToScreen()
					draw.SimpleTextOutlined("Shipment","Trebuchet18",ShipPos.x,ShipPos.y,Color(255,0,0),0,0,1,Color(255,255,255))
				end
			end
		end)
	else
		hook.Remove("HUDPaint", "shipmentfinder")
	end
end)

local State = -1
concommand.Add("razor_gunfinder", function()
	State = State * -1
	if State == 1 then
		hook.Add("HUDPaint","gunfinder", function()
			for k,Ent in pairs(ents.GetAll()) do 
				if string.find(Ent:GetClass(),"spawned_weapon") then
					local GunPos = (Ent:GetPos()+Vector(0,0,20)):ToScreen()
					draw.SimpleTextOutlined("Gun","Trebuchet18",GunPos.x,GunPos.y,Color(255,0,0),0,0,1,Color(255,255,255))
				end
			end
		end)
	else
		hook.Remove("HUDPaint", "gunfinder")
	end
end)

local State = -1
concommand.Add("razor_printerfinder", function()
	State = State * -1
	if State == 1 then
		hook.Add("HUDPaint","printerfinder", function()
			for k,Ent in pairs(ents.GetAll()) do 
				if string.find(Ent:GetClass(),"printer") then
					local PrinterPos = (Ent:GetPos()+Vector(0,0,20)):ToScreen()
					draw.SimpleTextOutlined("Money Printer","Trebuchet18",PrinterPos.x,PrinterPos.y,Color(255,0,0),0,0,1,Color(255,255,255))
				end
			end
		end)
	else
		hook.Remove("HUDPaint", "printerfinder")
	end
end)

local State = -1
concommand.Add("razor_moneyfinder", function()
	State = State * -1
	if State == 1 then
		hook.Add("HUDPaint","moneyfinder", function()
			for k,Ent in pairs(ents.GetAll()) do 
				if string.find(Ent:GetClass(),"money") then
					local MoneyPos = (Ent:GetPos()+Vector(0,0,20)):ToScreen()
					draw.SimpleTextOutlined("Money","Trebuchet18",MoneyPos.x,MoneyPos.y,Color(255,0,0),0,0,1,Color(255,255,255))
				end
			end
		end)
	else
		hook.Remove("HUDPaint", "moneyfinder")
	end
end)

Msg("Razor Sharp's Entity Wallhack loaded!\n")