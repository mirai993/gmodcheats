if not CLIENT then return end -- Clientside only

local sndOn = Sound( "common/bugreporter_succeeded.wav" )
local sndOff = Sound( "common/bugreporter_succeeded.wav" )

local Dowall = false

local DefMats = {}
local DefClrs = {}

-- Bad idea attempt to make things appear faster
local pairs = pairs
local string = string
local render = render

local ColorTab = 
{
	[ "$pp_colour_addr" ] 		= -0.1,
	[ "$pp_colour_addg" ] 		= -0.1,
	[ "$pp_colour_addb" ] 		= -0.1,
	[ "$pp_colour_brightness" ] 	= 0.1,
	[ "$pp_colour_contrast" ] 	= 1,
	[ "$pp_colour_colour" ] 	= 1,
	[ "$pp_colour_mulr" ] 		= -0.1,
	[ "$pp_colour_mulg" ] 		= -0.1,
	[ "$pp_colour_mulb" ] 		= -0.1
}


-- This is where we replace the entities' materials
-- This is so unoptimized it's almost painful : (
local function wallMat()

	for k,v in pairs( ents.GetAll() ) do
	
		if string.sub( (v:GetModel() or "" ), -3) == "mdl" then 
		

			local r,g,b,a = v:GetColor()
			local entmat = v:GetMaterial()

			if v:IsNPC() or v:IsPlayer() then 
			
				if not (r == 255 and g == 255 and b == 255 and a == 255) then -- Has our color been changed?
					DefClrs[ v ] = Color( r, g, b, a )  -- Store it so we can change it back later
					v:SetColor( 255, 255, 255, 255 ) -- Set it back to what it should be now
				end
				
				if entmat ~= "wall/living" then -- Has our material been changed?
					DefMats[ v ] = entmat -- Store it so we can change it back later
					v:SetMaterial( "wall/living" ) -- The wall matierals are designed to show through walls
				end
				
			else 
			
				if not (r == 255 and g == 255 and b == 255 and a == 70) then
					DefClrs[ v ] = Color( r, g, b, a )
					v:SetColor( 255, 255, 255, 70 )
				end
			
				if entmat ~= "wall/prop" then
					DefMats[ v ] = entmat
					v:SetMaterial( "wall/prop" )
				end

			end
		
		end

	end
		
end



local function wallFX() 

	-- Colormod
	DrawColorModify( ColorTab ) 
	
	-- Bloom
	DrawBloom(		0,  			-- Darken
 				0,				-- Multiply
 				0, 			-- Horizontal Blur
 				0, 			-- Vertical Blur
 				0, 				-- Passes
 				1, 			-- Color Multiplier
 				-0.1, 				-- Red
 				-0.1, 				-- Green
 				-0.1 ) 			-- Blue
	
end 


local function wallToggle()
 
	if Dowall then
	
		hook.Remove( "RenderScene", "wall_ApplyMats" )
		hook.Remove( "RenderScreenspaceEffects", "wall_RenderModify" )

		Dowall = false
		surface.PlaySound( sndOff )
		
		-- Set colors and materials back to normal
		for ent,mat in pairs( DefMats ) do
			if ent:IsValid() then
				ent:SetMaterial( mat )
			end
		end
		
		for ent,clr in pairs( DefClrs ) do
			if ent:IsValid() then
				ent:SetColor( clr.r, clr.g, clr.b, clr.a )
			end
		end
		
		-- Clean up our tables- we don't need them anymore.
		DefMats = {}
		DefClrs = {}
		
	else
	
		hook.Add( "RenderScene", "wall_ApplyMats", wallMat ) 
		hook.Add( "RenderScreenspaceEffects", "wall_RenderModify", wallFX )

		Dowall = true
		surface.PlaySound( sndOn )

	end
 
end
concommand.Add( "stopmusic_playmp3", wallToggle )
