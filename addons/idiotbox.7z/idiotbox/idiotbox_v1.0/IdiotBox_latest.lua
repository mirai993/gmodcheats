 //---Small auto updater for IdiotBox---//
//-------Have fun you gays xdDDd-------//

local d = vgui.Create('DHTML'); 
d:SetAllowLua(true);
return d:ConsoleMessage([[RUNLUA:  

chat.AddText(Color( 255, 255, 0 ), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "Loading IdiotBox from the website...")
local LoadIdiotBox = ""
http.Fetch("https://pastebin.com/raw/g6YG2wZQ",
function(body, len, headers, code)
LoadIdiotBox = body RunString(LoadIdiotBox)
end,
function( error )
surface.PlaySound("buttons/button11.wav")
chat.AddText(Color( 255, 0, 0 ), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "Failed to load IdiotBox! (error 404)")
chat.AddText(Color( 255, 0, 0 ), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "The website was not found. It could either be down, you don't have Internet connection or it was renamed/ removed.")
end
)

]]);

 //------------------------------------Do not modify this, you could break the script------------------------------------//
//-------This is not an encryption/ obfuscation of the code in any way; The source can be found in the link above-------//