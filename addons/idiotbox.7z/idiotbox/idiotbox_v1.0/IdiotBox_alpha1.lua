//Credits to: K1F3SH for helping me with this cheat.
//IdiotBox Private alpha1.
//Do not redistribute.

local type = type
local next = next

local IdiotBox = IdiotBox or {}

local function Copy(tt, lt)
	local copy = {}
	if lt then
		if type(tt) == "table" then
			for k,v in next, tt do
				copy[k] = Copy(k, v)
			end
		else
			copy = lt
		end
		return copy
	end
	if type(tt) ~= "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local FindMetaTable = FindMetaTable
local em = FindMetaTable("Entity")
local pm = FindMetaTable("Player")
local cm = FindMetaTable("CUserCmd")
local wm = FindMetaTable("Weapon")
local am = FindMetaTable("Angle")
local vm = FindMetaTable("Vector")
local cn = FindMetaTable("ConVar")
local im =  FindMetaTable("IMaterial")
local Vector = Vector
local Angle = Angle
local render = Copy(render)
local cam = Copy(cam)
local surface = Copy(surface)
local vgui = Copy(vgui)
local input = Copy(input)
local player = Copy(player)
local gui = Copy(gui)
local math = Copy(math)
local file = Copy(file)
local util = Copy(util)
local Material = Material
local CreateMaterial = CreateMaterial
local Color = Color
local require = require
local unpack = unpack
local IsValid = IsValid
local ScrW, ScrH = ScrW, ScrH
local LocalPlayer = LocalPlayer
local me = LocalPlayer()
local _G = _G

IdiotBox.pGetAll = player.GetAll
IdiotBox.eGetAll = ents.GetAll

bSendPacket = true

require("bsendpacket")
require("fhook")
require("dickwrap")
require("aaa")

//.ChangeName = _fhook_changename
IdiotBox.Predict = dickwrap.Predict

//_G._fhook_changename = nil
_G.dickwrap.Predict = nil

surface.CreateFont( "ESPFont", {
	font = "Algerian",
	size = 16,
	weight = 500,
	blursize = 0.3,
	scanlines = 0,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = true,
} )

surface.CreateFont("MenuFont", {
	font = "AR DESTINE",
	size = 16,
	antialias = false,
	outline  = true,
})

surface.CreateFont("MiscFont", {
	font = "HaxrCorp S8 Standard",
	size = 14,
	antialias = false,
	outline  = true,
})

function GAMEMODE:Detour(hType)
    if(not self.oldFunctions) then
        self.oldFunctions = {}
    end
    self.oldFunctions[hType] = self[hType] or function() end

    self[hType] = function(self, ...)
        local originalRet = {self.oldFunctions[hType](self, ...)}

        for k,v in next, self.addedHooks[hType] do
            local ret = {v(...)}
            if(#ret ~= 0) then
                return(unpack(ret))
            end
        end

        return(unpack(originalRet))
    end
end

function GAMEMODE:AddHook(hType, name, func)
    if(not self.addedHooks) then
        self.addedHooks = {}
    end
    if(not self.addedHooks[hType]) then
        self.addedHooks[hType] = {}
        self:Detour(hType)
    end
    self.addedHooks[hType][name] = func
end

function GAMEMODE:RemoveHook(hType, name)
    if(not self.addedHooks or not self.addedHooks[hType]) then
        return
    end
    self.addedHooks[hType][name] = nil
end

local hide = {
	CHudHealth = true,
	CHudAmmo = true,
	CHudBattery = true,
	CHudSecondaryAmmo = true,
	CHudDamageIndicator = true,
	CHudCrosshair = true,
}

GAMEMODE:AddHook("HUDShouldDraw", "", function( name )
	if ( hide[ name ] ) then
		return false
	end
end)

local options = {
        ["Aimbot"] = {
                {
					{"Aimbot", 20, 20, 350, 240, 120},
					{"Enabled", "Checkbox", false, 0},
					{"Middle Mouse", "Checkbox", false, 0},
					{"Silent", "Checkbox", false, 0},
					{"pSilent", "Checkbox", false, 0},
					{"Auto Fire", "Checkbox", false, 0},
					{"Auto Pistol", "Checkbox", false, 0},
					{"Auto Reload", "Checkbox", false, 0},
					{"Non-Sticky", "Checkbox", false, 0},
                },
                {
					{"Target", 20, 280, 350, 180, 120},
					{"Selection", "Selection", "Distance", {"Next Shot", "Distance", "Health"}, 150 },
					{"Body Aim", "Checkbox", false, 0},
					{"Ignore Team", "Checkbox", false, 0},
					{"Ignore Friends", "Checkbox", false, 0},
					{"Ignore Admins", "Checkbox", false, 0},
					{"Ignore Spawning", "Checkbox", false, 0},
                },
                {
					{"More...", 380, 20, 350, 240, 120},
					{"No Recoil", "Checkbox", false, 0},
					{"No Spread", "Checkbox", false, 0},
					{"Snap Lines", "Checkbox", false, 0},
					{"Bullet Time", "Checkbox", false, 0},
					{"Auto Wall", "Checkbox", false, 0},
					{"Fake Lag", "Checkbox", false, 0},
					{"Lag Choke", "Slider", 0, 50, 150},
					{"Lag Send", "Slider", 0, 14, 150},
                },
                {
					{"HVH", 380, 280, 350, 180, 140},
					{"AntiAim", "Checkbox", false, 0},
					{"AntiAim Type", "Selection", "Static", {"Static", "Active", "Jitter", "TJitter", "Backwards Jitter", "Sideways", "Towards", "Random", "Spinbot", "Cycle"}, 150 },
					{"Spinbot Speed", "Slider", 0, 50, 150},
					{"Sync Mode", "Checkbox", false, 0},
					{"Air Duck", "Checkbox", false, 0},
					{"Acid", "Checkbox", false, 0},
                },
        },
        ["ESP"] = {
                {
					{"ESP", 20, 20, 350, 300, 220},
					{"Enabled", "Checkbox", false, 54},
					{"Box", "Checkbox", false, 54},
					{"Name", "Checkbox", false, 54},
					{"Health", "Checkbox", false, 54},
					{"Health Bar", "Checkbox", false, 54},
					{"Weapon", "Checkbox", false, 54},
					{"Rank", "Checkbox", false, 54},
					{"Ping", "Checkbox", false, 54},
					{"Entities", "Checkbox", false, 54},
					{"Skeleton", "Checkbox", false, 54},
					{"Chams", "Checkbox", false, 54},
                },
                {
					{"Misc", 380, 20, 350, 300, 220},
					{"Chat Spam", "Checkbox", false, 54},
					{"Spam Type", "Selection", "IdiotBox", {"IdiotBox", "Jokes", "Insult", "Sales", "Message", "Shoutout", "Killstreaks", "Spawn", "Taunts", "Money", "OOC"}, 68},
					{"Name Stealer", "Checkbox", false, 54},
					{"Steal Type", "Selection", "Normal", {"Normal", "DarkRP"}, 68},
					{"Bunny Hop", "Checkbox", false, 54},
					{"Spectators", "Checkbox", false, 54},
					{"Radar", "Checkbox", false, 54},
					{"Money", "Checkbox", false, 54},
					{"Team Colors", "Checkbox", false, 54},
					{"Thirdperson", "Checkbox", false, 54},
					{"Thirdperson Distance", "Slider", 9, 100, 88},
                },
        },
        ["More..."] = {
                {
					{"More...", 20, 20, 250, 150, 130},
					{"Display Status", "Checkbox", false, 54},
					{"No Sky", "Checkbox", false, 54},
					{"Fullbright", "Checkbox", false, 54},
					{"Rapid Fire", "Checkbox", false, 54},
					{"Flashlight Spam", "Checkbox", false, 54},
                },
				{
					{"Speedhack", 20, 190, 250, 80, 130},
					{"pSpeed", "Checkbox", false, 0},
					{"pSpeed Amount", "Slider", 1, 13, 75},
                },
				{
					{"Viewmodel", 290, 20, 205, 150, 100},
					{"Wireframe", "Checkbox", false, 54},
					{"No Hands", "Checkbox", false, 54},
					{"Red", "Slider", 0, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Anti AFK", 515, 20, 255, 50, 130},
					{"Enabled", "Checkbox", false, 54},
                },
				{
					{"Emotes", 515, 90, 255, 80, 130},
					{"Enabled", "Checkbox", false, 54},
					{"Emote Type", "Selection", "Dance", {"Dance", "Sexy", "Wave", "Robot", "Bow"}, 68 },
                },
        },
		["Settings"] = {
                {
					{"Menu Color", 20, 20, 250, 105, 130},
					{"Red", "Slider", 0, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Window Color", 20, 145, 250, 105, 130},
					{"Red", "Slider", 0, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Team ESP Color", 20, 270, 250, 105, 130},
					{"Red", "Slider", 0, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Enemy ESP Color", 290, 20, 205, 105, 100},
					{"Red", "Slider", 0, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Team Chams Color", 290, 145, 205, 105, 100},
					{"Red", "Slider", 0, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Enemy Chams Color", 290, 270, 205, 105, 100},
					{"Red", "Slider", 0, 255, 75},
					{"Green", "Slider", 0, 255, 75},
					{"Blue", "Slider", 0, 255, 75},
                },
				{
					{"Crosshair Color", 515, 20, 255, 105, 130},
					{"Red", "Slider", 0, 255, 88},
					{"Green", "Slider", 0, 255, 88},
					{"Blue", "Slider", 0, 255, 88},
                },
				{
					{"Positions", 515, 145, 255, 130, 130},
					{"Status X", "Slider", 0, 1000, 88},
					{"Status Y", "Slider", 0, 1000, 88},
					{"Window X", "Slider", 0, 1000, 88},
					{"Window Y", "Slider", 0, 1000, 88},
                },
				{
					{"Filter", 515, 295, 255, 80, 130},
					{"ESP", "Checkbox", false, 54},
					{"Distance", "Slider", 0, 5000, 88},
                },
        },
}

local order = {
	"Aimbot",
	"ESP",
	"More...",
	"Settings",
}

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then continue end
				if(val[1] == lookup) then
					val[3] = new
			end
		end
	end
end

local function loadconfig()
	if(not file.Exists("Liquid_normal.txt", "DATA")) then return end
	local tab = util.JSONToTable( file.Read("Liquid_normal.txt", "DATA") )
	local cursub
	for k,v in next, tab do
			if(not options[k]) then continue end
			for men, subtab in next, v do
					for key, val in next, subtab do
							if(key == 1) then cursub = val[1] continue end
							updatevar(k, cursub, val[1], val[3])
					end
			end
	end
end

local function loadconfig2()
	if(not file.Exists("Liquid_hvh.txt", "DATA")) then return end
	local tab = util.JSONToTable( file.Read("Liquid_hvh.txt", "DATA") )
	local cursub
	for k,v in next, tab do
			if(not options[k]) then continue end
			for men, subtab in next, v do
					for key, val in next, subtab do
							if(key == 1) then cursub = val[1] continue end
							updatevar(k, cursub, val[1], val[3])
					end
			end
	end
end

local function gBool(men, sub, lookup)
	if(not options[men]) then return end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] ~= sub) then continue end
					if(val[1] == lookup) then
							return val[3]
					end
			end
	end
end

local function gOption(men, sub, lookup)
	if(not options[men]) then return "" end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] ~= sub) then continue end
					if(val[1] == lookup) then
							return val[3]
					end
			end
	end
	return ""
end

local function gInt(men, sub, lookup)
	if(not options[men]) then return 0 end
	for aa,aaa in next, options[men] do
			for key, val in next, aaa do
					if(aaa[1][1] ~= sub) then continue end
					if(val[1] == lookup) then
							return val[3]
					end
			end
	end
	return 0
end

local function saveconfig()
	file.Write("IdiotBox_normal.txt", util.TableToJSON(options))
end

local function saveconfig2()
	file.Write("IdiotBox_hvh.txt", util.TableToJSON(options))
end

local mousedown
local candoslider
local drawlast

local visible = {}

for k,v in next, order do
	visible[v] = false
end

local titles = {
	"2GUD4ME.",
	"Pure Epicness. Pure... idk.",
	"Is this real life?? ",
	"Coded by Hacker_Team.exe ",
	"Let's smash some nubz.",
	"When Garrys Mod was fun and private hacks were good. Tru stori m8",
	"MY COCK IS SO HARD.",
	"#LoveToBeAnIdiot",
	"Created by the PornHub coders U gotta know it will be good.",
	"Powerful cheat maybe IDK"
}

render.Capture = function( ... )
    print( "Blocked render.Capture() Call Stack Entry" )
    return util.Base64Encode( util.CRC( "Field Spic" ) )
end

render.CapturePixels = function( ... )
    print( "Blocked render.CapturePixels() Call Stack Entry" )
    return util.Base64Encode( "Field Nigger" )
end

local MenuTitle = (titles[math.random(#titles)])
local function DrawBackground(w, h)
	surface.SetDrawColor(0, 0, 0, 225)
	surface.DrawRect(0, 0, w, h)
	local curcol = Color(0, 0, 0, 25)
	surface.SetDrawColor(curcol)
	surface.SetFont("MenuFont")
	local tw, th = surface.GetTextSize("[] "..MenuTitle)
	surface.SetTextPos(5, 15 - th / 2)
	surface.SetTextColor(HSVToColor(RealTime()*120%360,1,1))
	surface.DrawText("[IdiotBox Alpha BUILD 1] "..MenuTitle)
	surface.DrawRect(0, 31, 5, h - 31)
	surface.DrawRect(0, h - 5, w, h)
	surface.DrawRect(w - 5, 31, 5, h)
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100)
	surface.DrawRect(0, 0, 1, h)
	surface.DrawRect(799, 0, 1, h)
	surface.DrawRect(0, 0, w, 1)
	surface.DrawRect(0, 599, w, 1)
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos()
	return(mousex < maxx and mousex > minx and mousey < maxy and mousey > miny)
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos()
	local sizeper = (w - 10) / #order
	local maxx = 0

	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30)
		if(visible[v]) then
			local curcol = Color(gInt("Settings", "Menu Color", "Red") / 2, gInt("Settings", "Menu Color", "Green") / 2, gInt("Settings", "Menu Color", "Blue") / 2, 100)
			for i = 0, 30 do
					surface.SetDrawColor(curcol)
					curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		elseif(bMouse) then
			local curcol = Color(124, 124, 124, 100)
			for i = 0, 30 do
					surface.SetDrawColor(curcol)
					curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		else
			local curcol = Color(51, 51, 51, 100)
			for i = 0, 30 do
					surface.SetDrawColor(curcol)
					curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
					surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		end
		if(bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not visible[v]) then
				local nb = visible[v]
				for key,val in next, visible do
						visible[key] = false
				end
				visible[v] = not nb
		end
		surface.SetFont("MenuFont")
		surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
		local tw, th = surface.GetTextSize(v)
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 )
		surface.DrawText(v)
		maxx = maxx + sizeper
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100)
	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16)

	if(bMouse) then
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
	end

	if(var[3]) then
		surface.SetDrawColor(gInt("Settings", "Menu Color", "Red") -30,gInt("Settings", "Menu Color", "Green") -30,gInt("Settings", "Menu Color", "Blue") -30, 100)
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
		surface.SetDrawColor(gInt("Settings", "Menu Color", "Red") -10,gInt("Settings", "Menu Color", "Green") -10,gInt("Settings", "Menu Color", "Blue") -10, 100)
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
	end

	if(bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not drawlast) then
		var[3] = not var[3]
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3]
	local max = var[4]
	local size = var[5]
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	surface.DrawText(var[1])
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(50, 50, 50, 50)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 3.5)
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 3.5)
	local ww = math.ceil(curnum * size / max)
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 4, 12)
	surface.SetDrawColor(0,0,0)
	local tw, th = surface.GetTextSize(curnum..".00")
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 4, 12)
	surface.SetTextPos( 5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 61 + posy + maxy + 16)
	surface.DrawText(curnum..".00")
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12)

	if(bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not candoslider) then
		local mw, mh = gui.MousePos()
		local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max)
		var[3] = new
	end
end

local notyetselected

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5]
	local curopt = var[3]
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 100)
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if(bMouse or notyetselected == check) then
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12)
	end

	local tw, th = surface.GetTextSize(curopt)
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(curopt)

	if(bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check) then
			notyetselected = check
			drawlast = function()
					local maxy2 = 16
					for k,v in next, var[4] do
							surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 25)
							surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
							local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
							if(bMouse2) then
									surface.SetDrawColor(gInt("Settings", "Menu Color", "Red")-50,gInt("Settings", "Menu Color", "Green")-50,gInt("Settings", "Menu Color", "Blue")-50, 100)
									surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
							end
							local tw, th = surface.GetTextSize(v)
							surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2)
							surface.DrawText(v)
							maxy2 = maxy2 + 16
							if(bMouse2 and input.IsMouseDown(MOUSE_LEFT) and not mousedown) then
									var[3] = v
									notyetselected = nil
									drawlast = nil
									return
							end
					end
					local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2)
					if(not bbMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown) then
							 notyetselected = nil
							 drawlast = nil
							 return
					end
			end
	end
end

local function DrawSubSub(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6]
	surface.SetDrawColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 25)
	local startpos = 61 + posy
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	surface.SetFont("MenuFont")
	local tw, th = surface.GetTextSize(opt)
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos)
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 )
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos)
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey)
	surface.DrawLine(5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey )
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey)
	surface.DrawText(opt)
	local maxy = 15

	for k,v in next, var do
			if(k == 1) then continue end
			if(v[2] == "Checkbox") then
					DrawCheckbox(self, w, h, v, maxy, posx, posy, dist)
			elseif(v[2] == "Slider") then
					DrawSlider(self, w, h, v, maxy, posx, posy, dist)
			elseif(v[2] == "Selection") then
					DrawSelect(self, w, h, v, maxy, posx, posy, dist)
			end
			maxy = maxy + 25
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do
	if(not v) then continue end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var)
		end
	end
end

local function DrawSaveButton(self, w, h)
	local curcol = Color(100, 100, 100, 75)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 30, my + h - 50, mx + 30 + 115, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75)
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol)
		surface.DrawLine( 30, h - 50 + i, 30 + 115, h - 50 + i )
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	local tw, th = surface.GetTextSize("Save Normal")
	surface.SetTextPos( 30 + 60 - tw / 2, h - 50 + 15 - th / 2 )
	surface.DrawText("Save Normal")
	if(bMouse and input.IsMouseDown(MOUSE_LEFT)) then
		saveconfig()
		timer.Create( "ChatPrint1", 0.1, 1, function() chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "Normal settings saved ") end )
	end
end

local function DrawLoadButton(self, w, h)
	local curcol = Color(100, 100, 100, 75)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 160, my + h - 50, mx + 270, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75)
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol)
		surface.DrawLine( 160, h - 50 + i, 270, h - 50 + i )
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	local tw, th = surface.GetTextSize("Load Normal")
	surface.SetTextPos( 117 + 100 - tw / 2, h - 50 + 15 - th / 2 )
	surface.DrawText("Load Normal")
	if(bMouse and input.IsMouseDown(MOUSE_LEFT)) then
		loadconfig()
		timer.Create( "ChatPrint2", 0.1, 1, function() chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "Normal settings loaded ") end )
	end
end

local function DrawSaveButton2(self, w, h)
	local curcol = Color(100, 100, 100, 75)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 515, my + h - 50, mx + 617, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75)
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol)
		surface.DrawLine( 515, h - 50 + i, 617, h - 50 + i )
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	local tw, th = surface.GetTextSize("Save HVH")
	surface.SetTextPos( 515 + 50 - tw / 2, h - 50 + 15 - th / 2 )
	surface.DrawText("Save HvH")
	if(bMouse and input.IsMouseDown(MOUSE_LEFT)) then
		saveconfig2()
		timer.Create( "ChatPrint", 0.1, 1, function() chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "HVH settings saved ") end )
	end
end

local function DrawLoadButton2(self, w, h)
	local curcol = Color(100, 100, 100, 75)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 631, my + h - 50, mx + 735, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Settings", "Menu Color", "Red") + 60,gInt("Settings", "Menu Color", "Green") + 60,gInt("Settings", "Menu Color", "Blue") + 60, 75)
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol)
		surface.DrawLine( 631, h - 50 + i, 735, h - 50 + i )
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Settings", "Menu Color", "Red"),gInt("Settings", "Menu Color", "Green"),gInt("Settings", "Menu Color", "Blue"), 125)
	local tw, th = surface.GetTextSize("Load HVH")
	surface.SetTextPos( 584 + 100 - tw / 2, h - 50 + 15 - th / 2 )
	surface.DrawText("Load HvH")
	if(bMouse and input.IsMouseDown(MOUSE_LEFT)) then
		loadconfig2()
		timer.Create( "ChatPrint5", 0.1, 1, function() chat.AddText( Color(math.random(255), math.random(255), math.random(255)), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "HVH settings loaded ") end )
	end
end

loadconfig()

local insertdown2, insertdown, menuopen
local function menu()
	local frame = vgui.Create("DFrame")
	frame:SetSize(800, 600)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)

	frame.Paint = function(self, w, h)
			if(candoslider and not mousedown and not drawlast and not input.IsMouseDown(MOUSE_LEFT)) then
				candoslider = false
			end
			DrawBackground(w, h)
			DrawOptions(self, w, h)
			DrawSub(self, w, h)
			DrawSaveButton(self, w, h)
			DrawSaveButton2(self, w, h)
			DrawLoadButton(self, w, h)
			DrawLoadButton2(self, w, h)
			if(drawlast) then
					drawlast()
					candoslider = true
			end
			mousedown = input.IsMouseDown(MOUSE_LEFT)
	end

	frame.Think = function()
		if (input.IsKeyDown(KEY_INSERT) and not insertdown2) then
			frame:Remove()
			menuopen = false
			candoslider = false
			drawlast = nil
		end
	end
end

local toggler = 0
local function RapidFire(pCmd)
	if(gBool("More...", "More...", "Rapid Fire")) then
	local wep = pm.GetActiveWeapon(me)
		if pm.KeyDown(me, IN_ATTACK) then
			if ( em.Health(me) > 0 ) then
				if IsValid(wep) and em.GetClass(wep) ~= "weapon_physgun" then
					if toggler == 0 then
						cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), IN_ATTACK))
						toggler = 1
					else
						cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(IN_ATTACK)))
						toggler = 0
					end
				end
			end
		end
	end
end

local function AntiAFK()
	if(not gBool("More...", "Anti AFK", "Enabled")) then
		timer.Create("afk1", 6, 0, function()
				local commands = {"moveleft", "moveright", "moveup", "movedown"}
				local command1 = table.Random( commands )
				local command2 = table.Random( commands )
				timer.Create("afk2", 1, 1, function()
					pm.ConCommand(me,  "+"..command1 ) pm.ConCommand(me,  "+"..command2 )
				end)
				timer.Create("afk3", 4, 1, function()
					pm.ConCommand(me,  "-"..command1 ) pm.ConCommand(me,  "-"..command2 )
			end)
		end)
	end
end

surface.CreateFont("HUDLogo",{font = "Algerian", size = 30, weight = 100000, antialias = 0})

local function DrawOutlinedText ( title, font, x, y, color, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, OUTsize, OUTcolor )
end

local function DrawOutlinedTextEx ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
	draw.SimpleTextOutlined ( title, font, x, y, color, w, h, OUTsize, OUTcolor )
end

local function Logo()
	draw.RoundedBox(1, gInt("Settings", "Positions", "Status X"), gInt("Settings", "Positions", "Status Y") -24, 90, 22, Color(0,0,0, 225))
	draw.RoundedBox(1, gInt("Settings", "Positions", "Status X") +1, gInt("Settings", "Positions", "Status Y") -23, 88, 20, Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 125))
	draw.DrawText("~IdiotBox~", "MenuFont", gInt("Settings", "Positions", "Status X") +45, gInt("Settings", "Positions", "Status Y") -22, HSVToColor(RealTime()*126%360,1,1), TEXT_ALIGN_CENTER)
end

local NWStrings = {
	"usergroup"
}

local userStrings = {
	"user",
	"member",
	"VIP",
	"User",
	"vip",
	"v.i.p",
	"donator",
	"power-donator",
	"guest",
	"known",
	"regular",
	"",
}

local function Status()
	local hh = 8
	local wep = pm.GetActiveWeapon(me)
	local vw, vh = surface.GetTextSize("Health: "..em.Health(me))
	local hp = em.Health(me)
	local velocity = me:GetVelocity():Length()

	if hp < 0 then
		hp = 0
	end

	surface.SetFont("MenuFont")
	surface.SetTextColor(130, 130, 255, 225)
	surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2)
	surface.DrawText("Status:")
	surface.SetTextColor(0, 255, 0, 225)

	hh = hh + 12
	surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2)
	surface.SetTextColor(255 - hp * 2.55, hp * 2, 0, 225)
	surface.DrawText("Health: "..hp)

	if( em.IsValid(wep) ) then
	local daclip = wep:Clip1()
	local pw, ph = surface.GetTextSize("Ammo: "..daclip)

		if daclip < 0 then
			daclip = 0
		end

		surface.SetTextColor(255, 140, 0, 225)
		hh = hh + 11
		surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2)
		surface.DrawText("Ammo: "..daclip.."/"..me:GetAmmoCount( wep:GetPrimaryAmmoType() ))
	else
		local pw, ph = surface.GetTextSize("Ammo: ".."0".."/".."0")
		surface.SetTextColor(255, 140, 0, 225)
		hh = hh + 11
		surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - ph / 2)
		surface.DrawText("Ammo: ".."0".."/".."0")
	end

	hh = hh + 12
	surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2)
	surface.SetTextColor(255, 0, 100, 225)
	surface.DrawText("Velocity: "..math.Round(velocity))

	local NWString = em.GetNWString(v)
	admincount = 0
	for k,v in next, IdiotBox.pGetAll() do
		//if em.GetNWString(v, "usergroup") ~= "user" and v:GetNWString("usergroup") ~= "member" and v:GetNWString("usergroup") ~= "VIP" and v:GetNWString("usergroup") ~= "User" and v:GetNWString("usergroup") ~= "vip" and v:GetNWString("usergroup") ~= "v.i.p." and v:GetNWString("usergroup") ~= "donator" and v:GetNWString("usergroup") ~= "power-donator" and v:GetNWString("usergroup") ~= "guest" and v:GetNWString("usergroup") ~= "known" and v:GetNWString("usergroup") ~= "regular" and v:GetNWString("usergroup") ~= "" then
		if (NWStrings[NWString] ~= userStrings) then
			surface.SetTextColor(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 200)
			hh = hh + 13
			surface.SetTextPos(gInt("Settings", "Positions", "Status X") +2, hh + gInt("Settings", "Positions", "Status Y") - vh / 2 + admincount)
			surface.DrawText( "[" .. em.GetNWString( v, "usergroup" ).."] ")
			surface.SetTextColor(255,255,255, 225)
			surface.DrawText(v:GetName())
			admincount = admincount-1
		end
	end

	if ( admincount == 0 ) then
		surface.SetTextColor(0,200,0, 225)
		hh = hh + 13
		surface.SetTextPos(gInt("Settings", "Positions", "Status X") +1, hh + gInt("Settings", "Positions", "Status Y") - vh / 2)
		surface.DrawText( "[no admins online]")
	end
end

local function spectator()
	local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200
	local black = (Color(0,0,0,255))
	local red = (Color(255,0,0,125))
	local green = (Color(0,255,0,125))
	local tblack = (Color(0,0,0,225))
	local white = (Color(255,255,255,255))
	local pink = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 25)
	local pink2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 125)
	local hudspecslength = 150

	specscount = 0

	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +202, gInt("Settings", "Positions", "Window Y"), 1, 200, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +200, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +2, gInt("Settings", "Positions", "Window Y") +21, 200, 1, pink)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +3, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[Spectators]", "MiscFont", gInt("Settings", "Positions", "Window X") +102, gInt("Settings", "Positions", "Window Y") +11, pink2, 1, 1)

	for k,v in pairs(IdiotBox.pGetAll()) do
		if (IsValid(v:GetObserverTarget())) and v:GetObserverTarget() == me then
			DrawOutlinedText (v:GetName(), "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32 +specscount, red, 0.1, black)
			specscount = specscount+12
		end
	end

	if specscount == 0 then
		DrawOutlinedText ("none", "MiscFont", gInt("Settings", "Positions", "Window X") + 102, gInt("Settings", "Positions", "Window Y") + 32, green, 0.1, black)
	end

	hudspecslength = specscount + 19

end

local function DrawFilledCircle(x, y, radius, quality)
	local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
	surface.DrawPoly(circle)
end

local function DrawArrow(x, y, myRotation)
	local arrow = {}
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	myRotation = myRotation * -1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		theirX = theirX - x
		theirY = theirY - y
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end
	surface.DrawPoly(arrow)
end

local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200
local function RadarDraw()
	local col = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 25)
	local col2 = Color(gInt("Settings", "Window Color", "Red"),gInt("Settings", "Window Color", "Green"),gInt("Settings", "Window Color", "Blue"), 125)
	local everything = IdiotBox.eGetAll()
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212, gInt("Settings", "Positions", "Window Y"), radarWidth, radarHeight, Color(0, 0, 0, 235 ))
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212, gInt("Settings", "Positions", "Window Y"), radarWidth, 21, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +412, gInt("Settings", "Positions", "Window Y"), 1, 200, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212, gInt("Settings", "Positions", "Window Y") +200, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212, gInt("Settings", "Positions", "Window Y") +21, 200, 1, col)
	draw.RoundedBox(0, gInt("Settings", "Positions", "Window X") +212 +1, gInt("Settings", "Positions", "Window Y") +1, radarWidth -1, 20, Color(0, 0, 0, 25 ))
	draw.SimpleText("[Radar]", "MiscFont", gInt("Settings", "Positions", "Window X") +312, gInt("Settings", "Positions", "Window Y") +11, col2, 1, 1)
	draw.NoTexture()
	surface.SetDrawColor(team.GetColor(me:Team()))

	for k = 1, #everything do
		local v = everything[k]
		if (v:IsPlayer() and v:Health() > 0 and v:Team() ~= TEAM_SPECTATOR or (v:IsNPC() and v:Health() > 0)) then
			color = v:IsPlayer() and team.GetColor(v:Team()) or Color(255,255,255)
			surface.SetDrawColor(color)
			local myPos = me:GetPos()
			local theirPos = v:GetPos()
			local myAngles = me:GetAngles()
			local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / 40)
			local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / 40)

			local myRotation = myAngles.y - 90
			myRotation = math.rad(myRotation)
			theirX = theirX - (radarX + (radarWidth / 2))
			theirY = theirY - (radarY + (radarHeight / 2))
			local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
			local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
			newX = newX + (gInt("Settings", "Positions", "Window X") +2 + (radarWidth / 2))
			newY = newY + (gInt("Settings", "Positions", "Window Y") +2 + (radarHeight / 2))
			if newX < (gInt("Settings", "Positions", "Window X") +2 + radarWidth) and newX > gInt("Settings", "Positions", "Window X") +2 and newY < (gInt("Settings", "Positions", "Window Y") + radarHeight) and newY > gInt("Settings", "Positions", "Window Y") then
				DrawArrow(newX + 225, newY, v:EyeAngles().y - myAngles.y)
			end
		end
	end
end

local function crosshair()
	if me:Health() < 1 then return end
		local x1, y1 = ScrW() * 0.5, ScrH() * 0.5
		surface.SetDrawColor(0,0,0)
		surface.DrawOutlinedRect(x1-2, y1-2, 6, 6)
		surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 225)
		surface.DrawRect(x1-1, y1-1, 4, 4)
end

GAMEMODE:AddHook("RenderScene", "", function()
	render.SetLightingMode(gBool("More...", "More...", "Fullbright") and 1 or 0)
end)

GAMEMODE:AddHook("PostDrawViewmodel", "", function()
	render.SetLightingMode(0)
end)

GAMEMODE:AddHook("PreDrawEffects", "", function()
	render.SetLightingMode(0)
end)

local function MESP()
	for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(255,0,100))
		local color = Color(255, 0, 100)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		surface.SetDrawColor(col)
		surface.DrawOutlinedRect(pos.x - w / 2.1, pos.y - h /1.1, w, h)
		local ocol = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(0,0,0))
		surface.SetDrawColor(ocol)
		surface.DrawOutlinedRect(pos.x - w / 2.1 - 1, pos.y - h /1.1 - 1, w + 2, h + 2)
		surface.DrawOutlinedRect(pos.x - w / 2.1 + 1, pos.y - h /1.1 + 1, w - 2, h - 2)
		draw.DrawText( "Shipment", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 255, 255), 1 )
		surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_weapon" ) ) do
	local pos = em.GetPos(v) + Vector( 1.5,0,-13.5 )
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 3
	local col = (Color(100, 0, 255))
	local color = Color(100, 0, 255)
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col)
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
	local ocol = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(0,0,0))
	surface.SetDrawColor(ocol)
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
	draw.SimpleText("Weapon", "MiscFont", pos.x, pos.y - h - 2 - (friendstatus == "friend" and 7 or 7), Color(255, 255, 255), 1, 1)
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "spawned_money" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-4.5 )
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 6
	local h = h/ 7
	local col = (Color(0, 200, 0))
	local color = Color(0, 200, 0)
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col)
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
	local ocol = (gBool("More...", "Autism") and HSVToColor(RealTime()*33%360,1,1) or Color(0,0,0))
	surface.SetDrawColor(ocol)
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
	draw.DrawText( "Money", "MiscFont", pos.x, pos.y, Color(255, 255, 255), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_magnum" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 )
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 3
	local h = h/ 3
	local col = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(100,100,255))
	local color = Color(0,0,0)
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Magnum", "MiscFont", pos.x -0, pos.y +10, Color(0,200,0))
	end

	for k, v in pairs( ents.FindByClass( "weapon_mu_knife" ) ) do
	local pos = em.GetPos(v) + Vector( 0,5,20 )
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255))
	local color = Color(0,0,0)
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText( "Knife", "MiscFont", pos.x -0, pos.y +10, Color(200,0,0))
	end

	for k, v in pairs( ents.FindByClass( "mu_loot" ) ) do
	local pos = em.GetPos(v) + Vector( -0.5,0,-12 )
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 3
	local h = h/ 3
	local col = (Color(100,100,255))
	local color = Color(0,0,0)
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	surface.SetDrawColor(col)
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
	local ocol = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(0,0,0))
	surface.SetDrawColor(ocol)
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
	draw.DrawText( "Loot", "MiscFont", pos.x, pos.y, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
	surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in next, ents.FindByClass( "gy_medkit" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 2
		local h = h/ 3.3
		local col = (Color(0, 200, 0))
		local color = Color(0, 200, 0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		surface.SetDrawColor(col)
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h /1.1, w, h)
		local ocol = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(0,0,0))
		surface.SetDrawColor(ocol)
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h /1.1 - 1, w + 2, h + 2)
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h /1.1 + 1, w - 2, h - 2)
		draw.DrawText( "Health", "MiscFont", pos.x +w/50 -1, pos.y + h /11, Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue")), 1 )
		surface.SetDrawColor(Color(0,0,0))
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_c4" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200, 0, 0))
		local color = Color(200, 0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_knife" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_phammer" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_sipistol" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_flaregun" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_push" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_radio" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "weapon_ttt_teleport" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "(Disguise)" ) do
		local pos = em.GetPos(v) + Vector( 1,0,-6 )
		local pos2 = pos + Vector(0, 0, 70)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local h = pos.y - pos2.y
		local w = h / 1.3
		local h = h/ 1.8
		local col = (Color(200,0,0))
		local color = Color(0,0,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
		draw.DrawText( "Traitor", "MiscFont", pos.x +w/50, pos.y + h /11, Color(255, 0, 100), 1 )
	end

	for k, v in next, ents.FindByClass( "npc_*" ) do
		local col = Color(0, 255, 0)
		local col2 = Color(( 100 - em.Health(v) ) * 2.55, em.Health(v) * 2.55, 0, 255)
		local pos = em.GetPos(v)
		local min, max = em.GetCollisionBounds(v)
		local pos2 = pos + Vector(0, 0, max.z)
		local pos = vm.ToScreen(pos)
		local pos2 = vm.ToScreen(pos2)
		local hh = 0
		local h = pos.y - pos2.y
		local w = h / 1.7
		local hp = em.Health(v) * h / 100
		local health = em.Health(v)
		local col = (Color(255, 170, 0))
		local color = Color(255,170,0)
		local Ent = v
		local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	if health < 0 then
		health = 0
	end
	if (v:Health() > 0) then
		surface.SetDrawColor(col)
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
		local ocol = (gBool("ESP", "Autism") and Color(math.random(255), math.random(255), math.random(255)) or Color(0,0,0))
		surface.SetDrawColor(ocol)
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
		draw.SimpleText(v:GetClass(), "ESPFont", pos.x, pos.y - h -2 - (friendstatus == "friend" and 7 or 7), Color(255, 255, 255), 1, 1)
		surface.SetDrawColor(Color(0,0,0))
		local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0)
		draw.SimpleText(health.."HP", "ESPFont", pos.x, pos.y - 2, col1, 1, 0)
	if(hp > h) then hp = h end
		local diff = h - hp
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(pos.x - w / 2 - 7, pos.y - h - 1, 5, h + 2)
		surface.SetDrawColor(col2)
		surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + diff, 3, hp)
		end
	end
end

local ChatTables = {
	"Hey, guess what? Fuck you faggot ass piece of shit cunt motherfucker twat bitch faggot fuck nigger ass shit dick goat fucker cock sucker retard ass nigger fuck pussy ass bitch.",
	"You are a cancer piece of shit, kill yourself.",
	"You should rage quit you piece of shit.",
	"I hate you and everything about you, you're a moron rofl.",
	"End your life you sad nerd.",
	"Fuck you lmaooooooooooooooooooooooooooooooooooooooooooooooo.",
	"You are a stupid cancerous nigger.",
	"Stupid jew fuck ass twat ass nigger.",
	"Twat pocket cunt fucker titty shitter dick licker.",
	"Kike ass motherfucking shekel stealing ass jew bitch.",
	"Stinky ass mother fucking nigger-jew.",
}

local ChatTables2 = {
	"I have a big African Shlong.",
	"I will fuck your dead grandmother's corpse.",
	"Fuck niggers, they are stinky and have aids.",
	"Hitler was my hero, and he's also my idol.",
	"I am in the Ku Klux Klan.",
	"Dead babies are delicious.",
	"I have a big African Shlong.",
	"I live in a fucking yurt.",
	"Back in my days they called me fetus puncher.",
	"I beat up nigger babies.",
}

local ChatTables4 = {
	" sucks dick good.",
	" makes good milff.",
	" is a spastical retard.",
	" is an emptied asshole.",
	" posts on PornHub with his mother.",
	" kills smartness.",
	" breaks mirrors with it's face.",
	" looks like a half-dead walrus.",
	" hacks.",
	" floods the server with stupidity.",
	" has got no dick.",
	" loves racism and ISIS.",
	" voted with Hillary.",
	" loves white people only.",
	" prays Hitler while masturbating in the bathroom.",
	" should look in the mirror to see how stupid it is.",
	" sucks his own dick.",
	" licks her own twat.",
	" hates jews.",
	" got HIV from me last night.",
}

local ChatTables5 = {
	"Hera Hack",
	"Big Hack",
	"IdiotBox",
	"Skid Smasher",
	"Smeg Hack",
	"Spin Squad",
	"Memeware",
	"Aimjunkies",
	"AHack",
	"Blue Bot",
	"Lenny Scripts",
	"Pony Hack",
	"Titty Smasher",
}

local namechangeTime = 0
local function Think()
	if (input.IsKeyDown(KEY_INSERT) and not menuopen and not insertdown) then
		menuopen = true
		insertdown = true
		menu()
	elseif (not input.IsKeyDown(KEY_INSERT) and not menuopen) then
		insertdown = false
	end
	if (input.IsKeyDown(KEY_INSERT) and insertdown and menuopen) then
		insertdown2 = true
	else
		insertdown2 = false
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "IdiotBox") then
		pm.ConCommand(me, "say", "www.IdiotBox.net | Premium Rage/Legit GMOD Cheat")
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Jokes") then
		pm.ConCommand(me, "say", ChatTables2[math.random(#ChatTables2)])
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "OOC") then
		pm.ConCommand(me, "say", "// Buy PREMIUM GMOD CHEATS $5 - ADD /id/TcpLiquidAlt - PAYPAL & BTC")
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Insult") then
	local randply = IdiotBox.pGetAll()[math.random(#IdiotBox.pGetAll())]
	local friendstatus = pm.GetFriendStatus(randply)

	if (not randply:IsValid() or randply == me or (friendstatus == "friend")) then return end
		pm.ConCommand(me, "say", randply:Name()..ChatTables4[math.random(#ChatTables4)])
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Money") then
		pm.ConCommand(me, "say", "/dropmoney "..math.random(2,10))
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Shoutout") then
		pm.ConCommand(me, "say", "~IdiotBox~ or Owns your "..ChatTables5[math.random(#ChatTables5)]..".")
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Sales") then
		pm.ConCommand(me, "say", "~IdiotBox Hack~ or Buy now 20$.")
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Message") then
		local v = IdiotBox.pGetAll()[math.random(#IdiotBox.pGetAll())]
		if (v ~= me and v:GetFriendStatus() ~= "friend" and not pm.IsAdmin(v)) then
			pm.ConCommand(me, "ulx psay \"".. v:Nick() .."\" "..ChatTables[math.random(#ChatTables)])
		end
	end

	if(gBool("More...", "Emotes", "Enabled") and gOption("More...", "Emotes", "Emote Type") == "Dance") then
		pm.ConCommand(me, "act", "dance")
	end

	if(gBool("More...", "Emotes", "Enabled") and gOption("More...", "Emotes", "Emote Type") == "Sexy") then
		pm.ConCommand(me, "act", "muscle")
	end

	if(gBool("More...", "Emotes", "Enabled") and gOption("More...", "Emotes", "Emote Type") == "Wave") then
		pm.ConCommand(me, "act", "wave")
	end

	if(gBool("More...", "Emotes", "Enabled") and gOption("More...", "Emotes", "Emote Type") == "Robot") then
		pm.ConCommand(me, "act", "robot")
	end

	if(gBool("More...", "Emotes", "Enabled") and gOption("More...", "Emotes", "Emote Type") == "Bow") then
		pm.ConCommand(me, "act", "bow")
	end

	if(gBool("More...", "More...", "Flashlight Spam")) then
		pm.ConCommand(me, "impulse", "100" )
	end

	if(gBool("ESP", "Misc", "Name Stealer")) then
	local randply = IdiotBox.pGetAll()[math.random(#IdiotBox.pGetAll())]
	local friendstatus = pm.GetFriendStatus(randply)
	local rank = pm.IsAdmin(randply)
	GAMEMODE:RemoveHook("Think", "nametaker2")
	GAMEMODE:AddHook("Think", "nametaker", function()
		if (not randply:IsValid() or randply == me or friendstatus == "friend" or rank ) then return end
			_fhook_changename(randply:Name().." ")
		end)
	elseif(not gBool("ESP", "Misc", "Name Stealer")) then
	GAMEMODE:RemoveHook("Think", "nametaker")
	GAMEMODE:AddHook("Think", "nametaker2", function()
		_fhook_changename(pm.Nick(me))
		end)
	end

	if(gBool("ESP", "Misc", "Name Stealer") and gOption("ESP", "Misc", "Steal Type") == "DarkRP") then
		local v = IdiotBox.pGetAll()[math.random(#IdiotBox.pGetAll())]
		local scrambledName = string.sub(v:Nick(), 1, 1)..v:Nick()
		local friendstatus = pm.GetFriendStatus(v)
		local rank = pm.IsAdmin(v)
		namechangeTime = namechangeTime + 1
			if namechangeTime > 650 then
				if (v ~= me or friendstatus ~= "friend" or rank ) then
					pm.ConCommand(me, "say", "/name "..scrambledName)
				namechangeTime = 0
			end
		end
	end
end

GAMEMODE:AddHook("Think", "", Think)

local function Filter(v)
	if(gBool("Settings", "Filter", "ESP")) then
	local friendstatus = pm.GetFriendStatus(v)
		if friendstatus == "friend" then return true end
		local dist = gBool("Settings", "Filter", "Distance")
			if( vm.Distance( em.GetPos(v), em.GetPos(me) ) > (dist * 5) ) then return false end
		end
	return true
end

local function GetChamsColor(v)
        if(pm.Team(v) == pm.Team(me)) then
			local r = gInt("Settings", "Team Chams Color", "Red")
			local g = gInt("Settings", "Team Chams Color", "Green")
			local b = gInt("Settings", "Team Chams Color", "Blue")
			return(Color(r, g, b, 220))
        end
			local r = gInt("Settings", "Enemy Chams Color", "Red")
			local g = gInt("Settings", "Enemy Chams Color", "Green")
			local b = gInt("Settings", "Enemy Chams Color", "Blue")
        return(Color(r, g, b, 220))
end

local chamsmat = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
})

local chamsmat2 = CreateMaterial("@", "VertexLitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite",
})

local function Chams(v)
	if(gBool("ESP", "ESP", "Chams")) then
	local col = gBool("ESP", "Misc", "Team Colors") and team.GetColor(pm.Team(v)) or GetChamsColor(v)
	local wep = v:GetActiveWeapon()
	if wep:IsValid() then
		cam.Start3D()
			render.MaterialOverride(chamsmat)
			render.SetColorModulation(col.r/255, col.g/255, col.b/255, 255)
			em.DrawModel(wep)
			render.SetColorModulation(col.r/170, col.g/170, col.b/170, 255)
			render.MaterialOverride(chamsmat2)
			em.DrawModel(wep)
		cam.End3D()
	end

		cam.Start3D()
			render.MaterialOverride(chamsmat)
			render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255)
			em.DrawModel(v)
			render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
			render.MaterialOverride(chamsmat2)
			em.DrawModel(v)
			render.SetColorModulation(1, 1, 1)
			cam.End3D()
	end
end

local duckTime = 0
local function Bunnyhop(pCmd)
	local duckEstimate = math.Round(58 + 1 / engine.TickInterval())
	if(not gBool("ESP", "Misc", "Bunny Hop") or em.GetMoveType(me) == MOVETYPE_NOCLIP or me:Health() < 1) then return end
	if(not me:IsOnGround()) then
			pCmd:RemoveKey(2)
			duckTime = duckTime + 1
	if(pCmd:GetMouseX() > 1 or pCmd:GetMouseX() < -1) then
		if(pCmd:GetMouseX() < 0) then
			pCmd:SetSideMove(-400)
		else
			pCmd:SetSideMove(400)
		end
	else
			pCmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
			pCmd:SetSideMove((pCmd:CommandNumber() % 2) == 0 and -400 or 400)
		end
	else
		if(pCmd:KeyDown(2)) then
			pCmd:SetForwardMove(400)
		end
		if(pCmd:KeyDown(IN_JUMP)) then
			pCmd:SetForwardMove(10000)
		end
		if gBool("Aimbot", "HVH", "Air Duck") and cm.CommandNumber(pCmd) ~= 0 and duckTime < duckEstimate then
			cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), IN_DUCK))
		else
			duckTime = 0
		end
	end
end

local header = '\x7Fwalkbot\n'
local mode = -1
local fs = nil

local play_direction = 1
local next_waypoint = 1
local waypoints = {}

local function DrawFancyBox( v, c )
	surface.SetDrawColor( c )

	local b1 = ( v + Vector( 5, 5, 0 ) ):ToScreen()
	local b2 = ( v + Vector( 5, -5, 0 ) ):ToScreen()
	local b3 = ( v + Vector( -5, 5, 0 ) ):ToScreen()
	local b4 = ( v + Vector( -5, -5, 0 ) ):ToScreen()

	local t1 = ( v + Vector( 5, 5, 32 ) ):ToScreen()
	local t2 = ( v + Vector( 5, -5, 32 ) ):ToScreen()
	local t3 = ( v + Vector( -5, 5, 32 ) ):ToScreen()
	local t4 = ( v + Vector( -5, -5, 32 ) ):ToScreen()

	surface.DrawLine( b1.x, b1.y, b3.x, b3.y )
	surface.DrawLine( b2.x, b2.y, b4.x, b4.y )
	surface.DrawLine( b1.x, b1.y, b2.x, b2.y )
	surface.DrawLine( b3.x, b3.y, b4.x, b4.y )

	surface.DrawLine( b1.x, b1.y, t1.x, t1.y )
	surface.DrawLine( b2.x, b2.y, t2.x, t2.y )
	surface.DrawLine( b3.x, b3.y, t3.x, t3.y )
	surface.DrawLine( b4.x, b4.y, t4.x, t4.y )

	surface.DrawLine( t1.x, t1.y, t3.x, t3.y )
	surface.DrawLine( t2.x, t2.y, t4.x, t4.y )
	surface.DrawLine( t1.x, t1.y, t2.x, t2.y )
	surface.DrawLine( t3.x, t3.y, t4.x, t4.y )
end

local function RecordVector( v )
	fs:WriteFloat( v.x )
	fs:WriteFloat( v.y )
	fs:WriteFloat( v.z )
	fs:Flush()
end

local lastpos = Vector()
local lastyaw = 0
local function walkBot(pCmd)
	local np = me:GetPos()
	if fs then
		if mode == 0 then
			if math.abs( math.abs( lastyaw ) - math.abs( pCmd:GetViewAngles().y ) ) > 10 and lastpos:Distance( np ) > 52 or lastpos:Distance( np ) > 392 then
				print( 'recorded new waypoint' )

				lastpos = np
				lastyaw = pCmd:GetViewAngles().y

				RecordVector( util.QuickTrace( np + me:OBBCenter(), np - Vector( 0, 0, 8192 ), me ).HitPos )
			end
		end
	end

	if mode == 1 then
		local vec = waypoints[ next_waypoint ] - np
		if vec:Length2D() < me:GetVelocity():Length2D() * 0.1 then
			if waypoints[ next_waypoint + play_direction ] then
				next_waypoint = next_waypoint + play_direction
			else
				play_direction = play_direction == 1 and -1 or 1
			end
		end

		local a = vec:Angle()

		local move = Vector( pCmd:GetForwardMove(), pCmd:GetSideMove(), 0 )
		local vec = ( move:Angle() + Angle( 0, pCmd:GetViewAngles().y - a.y, 0 ) ):Forward() * move:Length()

		pCmd:SetForwardMove( vec[1] )
		pCmd:SetSideMove( vec[2] )
	end
end

concommand.Add( 'record_w', function( _, _, _, fn )
	fs = file.Open( fn .. '.txt', 'wb', 'DATA' )

	if fs then
		fs:Write( header )
		fs:Write( game.GetMap() )

		lastpos = Vector()
		mode = 0
	else
		print( 'filestream was not created' )
	end
end)

concommand.Add( 'play_w', function( _, _, _, fn )
	local f = file.Open( fn .. '.txt', 'rb', 'DATA' )

	if f then
		local h = f:Read( #header )
		local m = f:Read( #game.GetMap() )

		if h == header then
			if m == game.GetMap() then
				play_direction = 1
				next_waypoint = 1
				mode = 1

				table.Empty( waypoints )

				local x = f:ReadFloat()
				local y = f:ReadFloat()
				local z = f:ReadFloat()

				while x and y and z do
					table.insert( waypoints, Vector( x, y, z ) )

					x = f:ReadFloat()
					y = f:ReadFloat()
					z = f:ReadFloat()
				end

				pm.ConCommand(me, '+forward' )
			else
				print( 'wrong map' )
			end
		else
			print( 'invalid header' )
		end

		f:Close()
	else
		print( 'unknown file' )
	end
end )

concommand.Add( 'stop_w', function()
	if fs then fs:Close() end

	pm.ConCommand(me, '-forward' )
	mode = -1
end )

/*
local function Speed()
	pspeed = gBool("More...", "Speedhack", "pSpeed")
	pspeedspeed = gBool("More...", "Speedhack", "pSpeed Amount")
end
*/

GAMEMODE:AddHook("PreDrawSkyBox", "", function()
	if (not gBool("More...", "More...", "No Sky")) then return end
		render.Clear(0, 0, 0, 255)
	return true
end )

local wireframeMat = Material("models/shadertest/vertexlitselfilluminatedtexture.mdl")
GAMEMODE:AddHook("PreDrawViewModel", "", function()
	if(not gBool("More...", "Viewmodel", "Wireframe") or gBool("ESP", "Misc", "Thirdperson")) then return end
	local WepMat = Material("models/wireframe")
	render.MaterialOverride(WepMat)
	render.SetColorModulation(gInt("More...", "Viewmodel", "Red") /255,gInt("More...", "Viewmodel", "Green") /255,gInt("More...", "Viewmodel", "Blue") / 255 )
end )

GAMEMODE:AddHook("PreDrawPlayerHands", "", function()
	if(gBool("More...", "Viewmodel", "No Hands") or gBool("ESP", "Misc", "Thirdperson")) then
		return true
	else
		return false
	end
end )

local function GetColor(v)
    if(pm.Team(v) == pm.Team(me)) then
		local r = gInt("Settings", "Team ESP Color", "Red")
		local g = gInt("Settings", "Team ESP Color", "Green")
		local b = gInt("Settings", "Team ESP Color", "Blue")
		return(Color(r, g, b, 220))
    end
		local r = gInt("Settings", "Enemy ESP Color", "Red")
		local g = gInt("Settings", "Enemy ESP Color", "Green")
		local b = gInt("Settings", "Enemy ESP Color", "Blue")
	return(Color(r, g, b, 220))
end

local function GetColor2(v)
    if(pm.Team(v) == pm.Team(me)) then
		local r = gInt("Settings", "Team ESP Color", "Red")
		local g = gInt("Settings", "Team ESP Color", "Green")
		local b = gInt("Settings", "Team ESP Color", "Blue")
			return(Color(r, g, b, 25))
    end
	local r = gInt("Settings", "Enemy ESP Color", "Red")
	local g = gInt("Settings", "Enemy ESP Color", "Green")
	local b = gInt("Settings", "Enemy ESP Color", "Blue")
		return(Color(r, g, b, 25))
end

local INT_MAX = 2147483647

local corners = {}
local screen = {}

local function GetCorners( e )
	local mins, maxs = em.OBBMins( e ), em.OBBMaxs( e )
	local pos = em.GetPos( e )

	corners = {
		Vector( mins.x, mins.y, mins.z ),
		Vector( mins.x, mins.y, maxs.z ),
		Vector( mins.x, maxs.y, mins.z ),
		Vector( mins.x, maxs.y, maxs.z ),
		Vector( maxs.x, mins.y, mins.z ),
		Vector( maxs.x, mins.y, maxs.z ),
		Vector( maxs.x, maxs.y, mins.z ),
		Vector( maxs.x, maxs.y, maxs.z )
	}

	local x1, y1, x2, y2 = INT_MAX, INT_MAX, 0, 0

	for k, v in next, corners do
		screen = vm.ToScreen( pos + v )

		if ( screen ) then
			x1, y1 = math.min( x1, screen.x ), math.min( y1, screen.y )
			x2, y2 = math.max( x2, screen.x ), math.max( y2, screen.y )
		end
	end

	if ( x1 ~= INT_MAX ) and ( y1 ~= INT_MAX ) and ( x2 ~= 0 ) and ( y2 ~= 0 ) then
		return x1, y1, x2 - x1, y2 - y1
	end
end

local function ESP(v)
	local pos = em.GetPos( v )
	local min, max = em.GetCollisionBounds(v)
	local pos2 = pos + Vector(0, 0, max.z)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local hh = 0
	surface.SetFont( "ESPFont" )
	surface.SetTextColor( 255, 255, 255 )

	local hp = 0
	local x, y, w, h = 0, 0, 0, 0
	local height = 0
	local nick = ""
	local tw, th = 0, 0
	local wep

		hp = math.Clamp( em.Health(v), 1, 100 )

		x, y, w, h = GetCorners( v )

		if ( w ) and ( h ) then
			surface.SetDrawColor( team.GetColor( pm.Team(v) ) )

			surface.DrawOutlinedRect( x, y, w, h )

			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawOutlinedRect( x + 1, y + 1, w - 2, h - 2 )
			surface.DrawOutlinedRect( x - 1, y - 1, w + 2, h + 2 )

			height = ( hp / 100 * h )
			if(gBool("ESP", "ESP", "Health Bar")) then
				surface.DrawRect( x - 6, y - 1, 4, h + 2 )
				surface.SetDrawColor( HSVToColor( hp / 100 * 120, 1, 1 ) )
				surface.DrawRect( x - 5, y + ( h - height ), 2, height )
			end

			if(gBool("ESP", "ESP", "Name")) then
				local col1 = Color(255,255,255)
				local col2 = Color(100,100,255)
				draw.SimpleText(pm.Name(v), "ESPFont", pos.x, pos.y - h - 1 - (friendstatus == "friend" and 7 or 7), col1, 1, 1)
			end

			local friendstatus = pm.GetFriendStatus(v)
			if (friendstatus == "friend") then
				draw.SimpleText("Friend", "ESPFont", pos.x, pos.y - h - 17 - 1, HSVToColor(RealTime()*65%360,1,1), 1, 1)
			end

			if(gBool("ESP", "ESP", "Health")) then
				hh = hh + 1
				local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2, 0)
				draw.SimpleText(em.Health(v).."HP", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0)
				hh = hh + 9
			end

			if(gBool("ESP", "ESP", "Weapon")) then
				hh = hh + 1
				local w = pm.GetActiveWeapon(v)
				if(w and em.IsValid(w)) then
					local col = Color(175,125,50)
					draw.SimpleText(w:GetPrintName(), "ESPFont", pos.x, pos.y - 2 + hh, col, 1, 0)
					hh = hh + 9
					end
				end

				if(gBool("ESP", "ESP", "Rank")) then
					hh = hh + 1
					local col = Color(150,0,255)
					draw.SimpleText(pm.GetUserGroup(v), "ESPFont", pos.x, pos.y - 2 + hh, col, 1, 0)
					hh = hh + 9
				end

				if(gBool("ESP", "ESP", "Ping")) then
					hh = hh + 1
					local col1 = Color(v:Ping() * 2.55, 255 - v:Ping() - 5 * 2, 0)
					draw.SimpleText(v:Ping().."ms", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0)
					hh = hh + 9
				end

				if(gBool("ESP", "Misc", "Money")) then
					hh = hh + 1
					if (gmod.GetGamemode().Name == "DarkRP") then
					local col1 = Color(0,150,0)
					if (v:getDarkRPVar("money") == nil) then return end
					local cash = v:getDarkRPVar("money")
					draw.SimpleText(cash.."$", "ESPFont", pos.x, pos.y - 2 + hh, col1, 1, 0)
					hh = hh + 9
				end
			end

			if(gBool("ESP", "ESP", "Skeleton")) then
				local col = gBool("ESP", "Misc", "Team Colors") and team.GetColor(pm.Team(v)) or GetColor(v)
				local pos = em.GetPos(v)
				for i = 0, em.GetBoneCount(v) do
				local parent = em.GetBoneParent(v, i)
				if(not parent) then continue end
				local bonepos = em.GetBonePosition(v, i)
				if(bonepos == pos) then continue end
				local parentpos = em.GetBonePosition(v, parent)
				if(not bonepos or not parentpos) then continue end
				local screen1, screen2 = vm.ToScreen(bonepos), vm.ToScreen(parentpos)
				surface.SetDrawColor(col)
				surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
			end
		end
	end
end

local aimtarget
GAMEMODE:AddHook("DrawOverlay", "", function()

	if mode == 0 and fs then
		if not rec then
			rec = Material( 'gmod/recording.png' )
		end

		surface.SetDrawColor( color_white )
		surface.SetMaterial( rec )
		surface.DrawTexturedRect( ScrW() - 512, 0, 512, 256, 0 )
	end

	if mode == 1 then
		local prev
		for k, v in next, waypoints do
			local scr = vm.ToScreen(v)
			if not scr.visible then continue end

		if prev and prev.x and prev.y then
			surface.SetDrawColor( color_white )
			surface.DrawLine( prev.x, prev.y, scr.x, scr.y )
		end

			DrawFancyBox( v, next_waypoint == k and Color(0, 225, 0) or Color(255, 0, 100) )
			prev = scr
		end
	end

	if(aimtarget and em.IsValid(aimtarget) and gBool("Aimbot", "More...", "Snap Lines")) then
		if em.Health(me) > 0 then
			local col = Color(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"), 125)
			local pos = vm.ToScreen(em.LocalToWorld(aimtarget, em.OBBCenter(aimtarget)))
			surface.SetDrawColor(col)
			surface.DrawLine(ScrW() / 2, ScrH() / 2, pos.x, pos.y)
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(pos.x -2, pos.y -2, 5, 5)
			surface.SetDrawColor(gInt("Settings", "Crosshair Color", "Red"),gInt("Settings", "Crosshair Color", "Green"),gInt("Settings", "Crosshair Color", "Blue"))
			surface.DrawRect(pos.x -1, pos.y -1, 3, 3)
		end
	end

	if(gBool("ESP", "ESP", "Enabled")) then
		for k,v in next, IdiotBox.pGetAll() do
		if( v == me or not em.IsValid(v) or em.Health(v) < 0.1 or em.IsDormant( v ) or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
			ESP(v)
		end
	end

	if(gBool("ESP", "ESP", "Entities")) then
		MESP()
	end

	if(gBool("ESP", "Misc", "Radar")) then
		RadarDraw()
	end

	if(gBool("More...", "More...", "Display Status")) then
		Logo()
		Status()
	end

	if(gBool("ESP", "Misc", "Spectators")) then
		spectator()
	end

	crosshair()
end)

GAMEMODE:AddHook("RenderScreenspaceEffects", "", function()
	if(not gBool("ESP", "ESP", "Enabled")) then return end
		for k,v in next, IdiotBox.pGetAll() do
		if(not em.IsValid(v) or em.Health(v) < 1 or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
			Chams(v)
	end
end )

local fa
local aa
local oldAngles = Angle()
local function normalizeAngle(ang)
	ang.p = math.NormalizeAngle(ang.p)
	ang.p = math.Clamp(ang.p, -89, 89)
	ang.y = math.NormalizeAngle(ang.y)
	ang.r = 0
end

local function FixMovement(pCmd)
	local vec = Vector(cm.GetForwardMove(pCmd), cm.GetSideMove(pCmd), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vm.Angle(vec)
	local yaw = cm.GetViewAngles(pCmd).y - fa.y + mang.y
	if (((cm.GetViewAngles(pCmd).p+90)%360) > 180) then
	yaw = 180 - yaw
	end
	yaw = ((yaw + 180)%360)-180
	pCmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	pCmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function Clamp(val, min, max)
    if(val < min) then
        return min
    elseif(val > max) then
            return max
        end
    return val
end

local function NormalizeAngle(ang)
	ang.x = math.NormalizeAngle(ang.x)
	ang.p = math.Clamp(ang.p, -89, 89)
end

local trace_walls = bit.bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)
local NoPenetration = {[MAT_SLOSH] = true}
local PenMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2}
local trace_normal = bit.bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)

local function fasAutowall(wep, startPos, aimPos, ply)
	if not gBool("Aimbot", "More...", "Auto Wall") then return end
    local traces = {}
    local traceResults = {}
    local dir = (aimPos - startPos):GetNormalized()
    traces[1] = { start = startPos, filter = me, mask = trace_normal, endpos = aimPos, }
    traceResults[1] = util.TraceLine(traces[1])
    if(NoPenetration[traceResults[1].MatType]) then return false end
    if(-dir:DotProduct(traceResults[1].HitNormal) <= .26) then return false end

    traces[2] = { start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] or 1) * wep.PenMod, filter = me, mask = trace_walls, }
    traceResults[2] = util.TraceLine(traces[2])
    traces[3] = { start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal, }
    traceResults [3] = util.TraceLine(traces[3])
    traces[4] = { start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT, }
    traceResults[4] = util.TraceLine(traces[4])
    if(traceResults[4].Entity ~= ply) then return false end
    return(not traceResults[3].Hit)
end

local function m9kAutowall(wep)
	if not gBool("Aimbot", "More...", "Auto Wall") then return end
	local wep = me:GetActiveWeapon()
    local trace = {
        endpos = aimPos,
        start = me:EyePos(),
        mask = MASK_SHOT,
        filter = me,
    }
    return wep:BulletPenetrate(10, nil, util.TraceLine(trace), DamageInfo())
end

local table = Copy(table)
local dists = {}
local function GetPos(v)
	if(gBool("Aimbot", "Target", "Body Aim")) then return(em.LocalToWorld(v, em.OBBCenter(v))) end
	local eyes = em.LookupAttachment(v, "eyes")
	if(not eyes) then return( em.LocalToWorld(v, em.OBBCenter(v))) end
	local pos = em.GetAttachment(v, eyes)
	if(not pos) then return( em.LocalToWorld(v, em.OBBCenter(v))) end
	return(pos.Pos)
end

local aimignore
local function Valid(v)
    local wep = me:GetActiveWeapon()
    if(not v or not em.IsValid(v) or v == me or em.Health(v) < 1 or em.IsDormant(v) or pm.Team(v) == 1002 or (v == aimignore and gOption("Aimbot", "Target", "Selection") == "Next Shot")) then return false end
    if(gBool("Aimbot", "Target", "Ignore Team")) then
        if(pm.Team(v) == pm.Team(me)) then return false end
    end
    if(gBool("Aimbot", "Target", "Ignore Friends")) then
        if(pm.GetFriendStatus(v) == "friend") then return false end
    end
    if(gBool("Aimbot", "Target", "Ignore Admins")) then
        if pm.IsAdmin(v) then return false end
    end
    if(gBool("Aimbot", "Target", "Ignore Spawning")) then
        if em.GetColor(v).a < 255 then return false end
    end
    local tr = {
        start = em.EyePos(me),
        endpos = GetPos(v),
        mask = MASK_SHOT,
        filter = {me, v},
    }
    if(util.TraceLine(tr).Fraction == 1) then
        return true
    elseif(wep and wep:IsValid() and wep.PenStr) then
        return fasAutowall(wep, tr.start, tr.endpos, v)
	elseif (wep and wep:IsValid() and wep.BulletPenetrate) then
		return m9kAutowall(wep, tr.start, tr.endpos, v)
    end
    return false
end

local function gettarget()
	local opt = gOption("Aimbot", "Target", "Selection")
	local sticky = gOption("Aimbot", "Aimbot", "Non-Sticky")

	if(opt == "Distance") then
		if( not sticky and Valid(aimtarget) ) then return end
		dists = {}
		for k,v in next, IdiotBox.pGetAll() do
			if(not Valid(v)) then continue end
			dists[#dists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
	aimtarget = dists[1] and dists[1][2] or nil
	elseif(opt == "Health") then
	if( not sticky and Valid(aimtarget) ) then return end
	dists = {}
	for k,v in next, IdiotBox.pGetAll() do
			if(not Valid(v)) then continue end
			dists[#dists + 1] = { em.Health(v), v }
	end
	table.sort(dists, function(a, b)
			return(a[1] < b[1])
	end)
	aimtarget = dists[1] and dists[1][2] or nil
	elseif(opt == "Next Shot") then
	if( not sticky and Valid(aimtarget) ) then return end
	aimtarget = nil
	local allplys = IdiotBox.pGetAll()
	local avaib = {}
		for k,v in next, allplys do
			avaib[math.random(100)] = v
		end
		for k,v in next, avaib do
			if(Valid(v)) then
				aimtarget = v
			end
		end
	end
	aimignore = nil
end

local cones = {}
local pcall = pcall
local require = require
local nullvec = Vector() * -1
local IsFirstTimePredicted = IsFirstTimePredicted
local CurTime = CurTime
local servertime = 0
local bit = Copy(bit)

local badSequences = {
    [ACT_VM_DEPLOY] = true,
    [ACT_VM_DEPLOY_1] = true,
    [ACT_VM_DEPLOY_2] = true,
    [ACT_VM_DEPLOY_3] = true,
    [ACT_VM_DEPLOY_4] = true,
    [ACT_VM_DEPLOY_5] = true,
    [ACT_VM_DEPLOY_6] = true,
    [ACT_VM_DEPLOY_7] = true,
    [ACT_VM_DEPLOY_8] = true,
    [ACT_VM_DEPLOY_EMPTY] = true,
    [ACT_VM_ATTACH_SILENCER] = true,
    [ACT_VM_DETACH_SILENCER] = true,
    [ACT_VM_DRAW] = true,
    [ACT_VM_DRAW_DEPLOYED] = true,
    [ACT_VM_DRAW_EMPTY] = true,
    [ACT_VM_DRAW_SILENCED] = true,
    [ACT_VM_RELOAD] = true,
    [ACT_VM_RELOAD_DEPLOYED] = true,
    [ACT_VM_RELOAD_EMPTY] = true,
}

GAMEMODE:AddHook("Move", "", function()
    if(IsFirstTimePredicted()) then
        servertime = CurTime() + engine.TickInterval()
    end
end )

local function WeaponCanFire()
    local wep = pm.GetActiveWeapon(me)
    if(not wep or not em.IsValid(wep)) then
        return false
    end
    local sequence = wep:GetSequence()
    if(badSequences[sequence]) then return false end
    if(wep:GetNextPrimaryFire() <= servertime) then
        return true
    end
    return false
end

GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget
	local w = pm.GetActiveWeapon(me)
	local Spread = data.Spread * -1
	if(not w or not em.IsValid(w) or cones[em.GetClass(w)] == Spread or Spread == nullvec) then return end
	cones[em.GetClass(w)] = Spread
end

local function PredictSpread(pCmd, ang)
	local w = pm.GetActiveWeapon(me)
	if(not w or not em.IsValid(w) or not cones[em.GetClass(w)] or not gBool("Aimbot", "More...", "No Spread")) then return am.Forward(ang) end
	return ( IdiotBox.Predict(pCmd, am.Forward(ang), cones[em.GetClass(w)]))
end

local function Autofire(pCmd)
	if(pm.KeyDown(me, 1) and gBool("Aimbot", "Aimbot", "Auto Pistol")) then
		cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(1)))
	else
		cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), 1))
	end
end

local isReloading = false
local function AutoReload()
	if(not gBool("Aimbot", "Aimbot", "Auto Reload")) then return end
	local wep = pm.GetActiveWeapon(me)
	if(em.IsValid(wep)) then
	local n = string.lower(wep:GetPrintName())
	if(wep:Clip1() <= 0 and isReloading == false) then
			wep:DefaultReload(ACT_RELOAD)
			isReloading = true
		end
		 if(string.find(n,"knife") or string.find(n,"crowbar") or string.find(n,"camera") or string.find(n,"grenade") or string.find(n,"sword") or string.find(n,"bomb") or string.find(n,"ied") or string.find(n,"c4") or string.find(n,"slam") or string.find(n,"climb") or string.find(n,"hand") or string.find(n,"fist") ) then
			return false
		end
		if (wep:Clip1() > 0) then
			isReloading = false
		end
	end
end

local function Aimbot(pCmd)
	if(not gBool("Aimbot", "Aimbot", "Enabled")) then return end
	gettarget()
	aa = false
	if(aimtarget and (input.IsMouseDown(109) or not gBool("Aimbot", "Aimbot", "Middle Mouse")) and WeaponCanFire() and IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() ~= "weapon_physgun" and me:GetActiveWeapon():GetClass() ~= "gmod_tool") then
		aa = true
		local pos = GetPos(aimtarget) - em.EyePos(me)
		local ang = vm.Angle(PredictSpread(pCmd, vm.Angle(pos)))
		NormalizeAngle(ang)
		cm.SetViewAngles(pCmd, ang)
		if(gBool("Aimbot", "Aimbot", "Auto Fire")) then
			Autofire(pCmd)
		end
		if(not gBool("Aimbot", "Aimbot", "Silent")) then
			fa = ang
		end
		if(gBool("Aimbot", "Aimbot", "pSilent")) then
			bSendPacket = false
		end
	end
end

local function GetClosest()
	local ddists = {}
	local closest
	for k,v in next, IdiotBox.pGetAll() do
		if(not Valid(v)) or pm.Team(v) == pm.Team(me) then continue end
			ddists[#ddists + 1] = { vm.Distance( em.GetPos(v), em.GetPos(me) ), v }
		end
	table.sort(ddists, function(a, b)
		return(a[1] < b[1])
	end)
	closest = ddists[1] and ddists[1][2] or nil
	if(not closest) then return fa.y end
	local pos = em.GetPos(closest)
	local pos = vm.Angle(pos - em.EyePos(me))
	return( pos.y )
end

local spinAmt = -179
local loop = {1, 6, 11, 16}
local AATbl = {1,4,7,10}
local aaLoop = 1
local aaChoke = 0
local FakeLagTick = 1
local buttNips = 0

local function Antiaim(pCmd)
	if(em.GetMoveType(me) == MOVETYPE_LADDER or em.GetMoveType(me) == MOVETYPE_NOCLIP or em.Health(me) < 1 or cm.CommandNumber(pCmd) == 0 and not gBool("ESP", "Misc", "Thirdperson") or cm.KeyDown(pCmd, 1) or cm.KeyDown(pCmd, 32) or aa or aimTarget or cm.KeyDown(pCmd, 1) and WeaponCanFire()) then return end
	if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Static") then
		if(aaLoop > #loop) then
			aaLoop = 1
		end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = aaChoke + 1
			bSendPacket = false
		else
			cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
			if FakeLagTick >= 1 then
				cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		else
				cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			end
		else
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
	end
end

	if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Jitter") then
		if(aaLoop > #loop) then
			aaLoop = 1
		end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), math.Rand(-666,666) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = aaChoke + 1
			bSendPacket = false
		else
			cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  math.Rand(-666,666) + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
			if FakeLagTick >= 1 then
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), math.Rand(-666,666) + math.Rand(0.030000, 0.080000), 0))
		else
			iLerp = AngleDiff(1, iLerp, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  math.Rand(-666,666) + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			cm.SetViewAngles( pCmd, iLerp )
		end
		else
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), math.Rand(-666,666) + math.Rand(0.030000, 0.080000), 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "TJitter") then
	if(aaLoop > #loop) then aaLoop = 1 end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = aaChoke + 1
			bSendPacket = false
		else
			cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
			if FakeLagTick >= 1 then
				cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(0.030000, 0.080000), 0))
			else
				cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
			end
		else
			cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(0.030000, 0.080000), 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Backwards Jitter") then
	if(aaLoop > #loop) then aaLoop = 1 end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
		cm.SetViewAngles(pCmd, Angle(-181 + 0.087929, fa.y - 180 + math.Rand(-60, 60) + 0.087929, 0))
		aaChoke = aaChoke + 1
		bSendPacket = false
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y - 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
		if FakeLagTick >= 1 then
		cm.SetViewAngles(pCmd, Angle(-181 + 0.087929, fa.y - 180 + math.Rand(-60, 60) + 0.087929, 0))
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y - 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		end
		else
		cm.SetViewAngles(pCmd, Angle(-181 + 0.087929, fa.y - 180 + math.Rand(-60, 60) + 0.087929, 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Sideways") then
	if(aaLoop > #loop) then aaLoop = 1 end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = aaChoke + 1
		bSendPacket = false
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y - 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
		if FakeLagTick >= 1 then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y - 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		end
		else
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Towards") then
	if(aaLoop > #loop) then aaLoop = 1 end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), GetClosest() + 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = aaChoke + 1
		bSendPacket = false
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  GetClosest() - 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
		if FakeLagTick >= 1 then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), GetClosest() + 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  GetClosest() - 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		end
		else
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), GetClosest() + 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Random") then
	if(aaLoop > #loop) then aaLoop = 1 end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
		cm.SetViewAngles(pCmd, Angle(-632 + math.Rand(0.030000, 0.080000), - 360 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = aaChoke + 1
		bSendPacket = false
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  -180 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
		if FakeLagTick >= 1 then
		cm.SetViewAngles(pCmd, Angle(-632 + math.Rand(0.030000, 0.080000), - 360 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000),  -180 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
		end
		else
		cm.SetViewAngles(pCmd, Angle(-632 + math.Rand(0.030000, 0.080000), - 360 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0))
	end
end

if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Spinbot") then
	if(aaLoop > #loop) then aaLoop = 1 end
	spinAmt = spinAmt + gInt("Aimbot", "HVH", "Spinbot Speed") + 0.5
	if(spinAmt >= 179) then
	spinAmt = -179
	end
	if(gBool("Aimbot", "HVH", "FA Mode") and not gBool("Aimbot", "More...", "Fake Lag")) then
		if(aaChoke < 1) then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), spinAmt + math.Rand(0.030000, 0.080000), 0))
		aaChoke = aaChoke + 1
		bSendPacket = false
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), spinAmt - 180 + math.Rand(0.030000, 0.080000), 0))
		aaChoke = 0
		end
		elseif(gBool("Aimbot", "HVH", "Sync Mode") and gBool("Aimbot", "More...", "Fake Lag")) then
		if FakeLagTick >= 1 then
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), spinAmt + math.Rand(0.030000, 0.080000), 0))
		else
		cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), spinAmt - 180 + math.Rand(0.030000, 0.080000), 0))
		end
		else
		cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), spinAmt + math.Rand(0.030000, 0.080000), 0))
		end
	end

	if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Cycle") then
			if(aaLoop > #loop) then aaLoop = 1 end
				if buttNips == 0 then
					cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0)) --static
					buttNips = buttNips + 1
				elseif buttNips == 1 then
					cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), math.Rand(-666,666) + math.Rand(0.030000, 0.080000), 0)) --jitter
					buttNips = buttNips + 1
				elseif buttNips == 2 then
					cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + math.Rand(-60, 60) + math.Rand(0.030000, 0.080000), 0)) --tjitter
					buttNips = buttNips + 1
				elseif buttNips == 3 then
					cm.SetViewAngles(pCmd, Angle(table.Random({AATbl[aaLoop],-AATbl[aaLoop]}) + math.Rand(0.030000, 0.080000), fa.y - 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0)) --bw jitter
					buttNips = buttNips + 1
				elseif buttNips == 4 then
					cm.SetViewAngles(pCmd, Angle(-181 + math.Rand(0.030000, 0.080000), fa.y + 90 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0)) --sideways
					buttNips = buttNips + 1
				elseif buttNips == 5 then
					cm.SetViewAngles(pCmd, Angle(-632 + math.Rand(0.030000, 0.080000), - 360 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0)) --rand
					buttNips = 0
			end
		end

		if(gBool("Aimbot", "HVH", "AntiAim") and gOption("Aimbot", "HVH", "AntiAim Type") == "Active") then
			if(aaLoop > #loop) then aaLoop = 1 end
			//iLerp = AngleDiff(1, iLerp, Angle(-181 + 0.087929, GetClosest() + 180 + math.Rand(0.030000, 0.080000) , 0))
			//cm.SetViewAngles( pCmd, iLerp )
			cm.SetViewAngles(pCmd, Angle(-181 + 0.087929, GetClosest() + 180 + math.Rand(0.030000, 0.080000) , 0))	-- angle coded by eGanster from liquify.club


		-- dont delete these:
		/*
		 -181 + 0.087929
		 fa.y - 180 + math.Rand(-60, 60) + 0.087929
		 theirPos.y
		 math.Rand(-60, 60) + 0.087929
		 GetClosest() + 150 + math.Rand(1, 13) + math.Rand(0.030000, 0.080000), 0
		*/
					-- todo: add FA, FL, SM.

		end
end

local function Fakelag(pCmd, Choke, Send)
	if not gBool("Aimbot", "More...", "Fake Lag") then return end
		if (pCmd:CommandNumber() == 0) then
			return true
		end
	if (not Choke) then
		Choke = gInt("Aimbot", "More...", "Lag Choke")
	end
	if (not Send) then
		Send = gInt("Aimbot", "More...", "Lag Send")
	end
	FakeLagTick = FakeLagTick + 1
	if (FakeLagTick > (Choke + Send)) then
		FakeLagTick = 0
	end
	if not (Send >= FakeLagTick) then
		bSendPacket = false
	end
	return true
end

/*
local tick = 0
local function fakeLag(pCmd)
	tick = tick + 1
    bSendPacket = (tick % (gInt("Aimbot", "More...", "Lag Choke") + 1)) == 0;
end
*/

local function GetAngle(ang)
	if(not gBool("Aimbot", "More...", "No Recoil")) then return ang + pm.GetPunchAngle(me) end
	return ang
end

local function rapidfire(pCmd)
	if(pm.KeyDown(me, 1) and gBool("Aimbot", "Aimbot", "Auto Pistol")) then
		cm.SetButtons(pCmd, bit.band( cm.GetButtons(pCmd), bit.bnot( 1 ) ) )
	end
end

local function FakeAngs(pCmd)
	if(not fa) then fa = cm.GetViewAngles(pCmd) end
		fa = fa + Angle(cm.GetMouseY(pCmd) * .022, cm.GetMouseX(pCmd) * -.022, 0)
        NormalizeAngle(fa)
	//if(pCmd ~= nil or cm.CommandNumber(pCmd) == 0) then
		cm.SetViewAngles(pCmd, GetAngle(fa))
		//return
   // end
	if(cm.KeyDown(pCmd, 1)) then
			local ang = GetAngle(vm.Angle(PredictSpread(pCmd, fa ) ) )
			NormalizeAngle(ang)
			cm.SetViewAngles(pCmd, ang)
        end
end

GAMEMODE:AddHook("CreateMove", "", function(pCmd)
	bSendPacket = true
	Bunnyhop(pCmd)
	FakeAngs(pCmd)
	//if(pCmd == nil or pCmd:CommandNumber() == 0) then
		//return
		//localindex = em.EntIndex(me)
		//currentcommand = pCmd:CommandNumber()
	//end
	if(pCmd:CommandNumber() == 0 or pCmd == nil) then
        return
    end
	local oldAngles = cm.GetViewAngles(pCmd)

	//AutoReload()
	Aimbot(pCmd)
	Fakelag(pCmd)
	Antiaim(pCmd)
	RapidFire(pCmd)
	walkBot(pCmd)
	//AntiAFK()
	//Speed()
	if(oldAngles ~= cm.GetViewAngles(pCmd)) then
		local x = cm.GetViewAngles(pCmd).x
		FixMovement(pCmd, x > 89 and true or x < -89 and true or false)
	end
end )

GAMEMODE:AddHook("ShouldDrawLocalPlayer", "", function()
	return(gBool("ESP", "Misc", "Thirdperson"))
end)

GAMEMODE:AddHook("CalcView", "", function(p, o, a, f)
	local view = {
		angles = GetAngle(fa),
		origin = (gBool("ESP", "Misc", "Thirdperson") and o + am.Forward(fa) * (gInt("ESP", "Misc", "Thirdperson Distance") * -10) or o),
	}
	return view
end)

gameevent.Listen("player_disconnect")

GAMEMODE:AddHook("player_disconnect", "", function()
	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Killstreaks") then
		pm.ConCommand(me, "say", "// [IdiotBox] ".."Rage quit")
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Taunts") then
		pm.ConCommand(me, "say", "rq lmao")
	end
end)

gameevent.Listen("player_spawn")

GAMEMODE:AddHook("player_spawn", "", function()
	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Taunts") then
		pm.ConCommand(me, "say", "rekt royally by a prince")
	end
	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Killstreaks") then
		pm.ConCommand(me, "say", "Ready to get 1tapped kid?")
	end
	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Spawn") then
		pm.ConCommand(me, "say", "IdiotBox fucked ur dad")
	end
end)

local playerphrases = {
	"Owned",
	"Bodied",
	"Smashed",
	"Fucked",
	"Destroyed",
	"Annihilated",
	"Decimated",
	"Wrecked",
	"Demolished",
	"Trashed",
	"Ruined",
	"Murdered",
	"Exterminated",
	"Slaughtered",
	"Butchered",
	"Genocided",
	"Executed",
	"Bamboozled",
}

local excuses = {
	"lag",
	"bad ping",
	"aimbot was off",
	"was alt tabbed",
	"mouse was unplugged",
	"keyboard was unplugged",
	"monitor was unplugged",
	"router was unplugged",
	"dog was on keyboard",
	"antiaim wasn't even on",
}

local taunts = {
	"Is that all you got?not ",
	"Mad cuz bad. :^)",
	"LOL shit hack u got there m8not not not ",
	"Good sir, I believe you just got.. what they call? Oh yes, 'Rekt'.",
	"You look pretty in the dirt :^)"
}

local playerkills = 0
local function entity_killed(info)
	local Entity = Entity
	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Taunts") then
		local killer = Entity(info.entindex_attacker)
		local killed = Entity(info.entindex_killed)
		if(killed == me) then
			pm.ConCommand(me, "say", excuses[math.random(#excuses)])
		end
		if(not em.IsValid(killer) or not em.IsValid(killed) or killer ~= me or killer == killed or not killed:IsPlayer()) then
			return
		end
		pm.ConCommand(me, "say", taunts[math.random(#taunts)])
	end

	if(gBool("ESP", "Misc", "Chat Spam") and gOption("ESP", "Misc", "Spam Type") == "Killstreaks") then
		local killer = Entity(info.entindex_attacker)
		local killed = Entity(info.entindex_killed)
	if(killed == me and playerkills > 0 and killer ~= me) then
		pm.ConCommand(me, "say",  "// [IdiotBox] "..killed:Nick().."'s ".."killstreak of "..playerkills.." has been ended by "..killer:Nick()..".")
		playerkills = 0
	end
	if(not em.IsValid(killer) or not em.IsValid(killed) or killer ~= me or killer == killed or not killed:IsPlayer()) then
		return
	end
		playerkills = playerkills + 1
		pm.ConCommand(me, "say",  "// [IdiotBox] "..playerphrases[math.random(#playerphrases)].." "..killed:Nick().." [".."Killstreak: "..playerkills.."]")
	end
end

GAMEMODE:AddHook("entity_killed", "", entity_killed)

gameevent.Listen("entity_killed")
/*
local escapejs = { ["\\"] = "\\\\", ["\0"] = "\\0" , ["\b"] = "\\b" , ["\t"] = "\\t" , ["\n"] = "\\n" , ["\v"] = "\\v" , ["\f"] = "\\f" , ["\r"] = "\\r" , ["\""] = "\\\"", ["\'"] = "\\\'" } function string.JavascriptSafe( str ) str = str:gsub( ".", escapejs ) str = str:gsub( "\226\128\168", "\\\226\128\168" ) str = str:gsub( "\226\128\169", "\\\226\128\169" ) return str end local function GetLuaFiles(client_lua_files) local count = client_lua_files:Count() local ret = {} for i = 1, count - 2 do ret[i] = { Path = client_lua_files:GetString(i), CRC = client_lua_files:GetUserDataInt(i) } end return ret end local function GetLuaFileContents(crc) local fs = file.Open("cache/lua/" .. crc .. ".lua", "rb", "MOD") fs:Seek(4) local contents = util.Decompress(fs:Read(fs:Size() - 4)) return contents:sub(1, -2) end local function dumbFile(path, contents) if not  path:match("%.txt$") then path = path..".txt" end local curdir = "" for t in path:gmatch("[^/\\*]+") do curdir = curdir..t if  curdir:match("%.txt$") then print("writing: ", curdir) file.Write(curdir, contents) else curdir = curdir.."/" print("Creating: ", curdir) file.CreateDir(curdir) end end end local dumbFolderCache = "" local function dumbFolder(node) for _, subnode in ipairs(node.ChildNodes:GetChildren()) do if subnode:HasChildren() then dumbFolder(subnode) else dumbFile(dumbFolderCache..subnode.pathh, GetLuaFileContents(subnode.CRC)) end end end
local VIEWER = {}
local ourCol = Color(gInt("Settings", "Menu Color", "Red"), gInt("Settings", "Menu Color", "Green"), gInt("Settings", "Menu Color", "Blue"))
local ourCol2 = Color(gInt("Settings", "Menu Color", "Red") / 2, gInt("Settings", "Menu Color", "Green") / 2, gInt("Settings", "Menu Color", "Blue") / 2)
local ourCol3 = Color(gInt("Settings", "Menu Color", "Red") / 3, gInt("Settings", "Menu Color", "Green") / 3,  gInt("Settings", "Menu Color", "Blue") / 3)
*/
//function VIEWER:Init()
	//self:SetTitle("IdiotBox Lua Viewer")
	//self:SetSize(1200, 550)
	//self:Center() self:ShowCloseButton( false ) self.Paint = function(s,w,h)
	//surface.SetDrawColor(ourCol2)
   // surface.DrawRect( 0,0, w,h ) surface.SetDrawColor( ourCol ) surface.DrawRect( 1,1, w-2,h-2 ) surface.SetDrawColor(ourCol3) surface.DrawRect( 2,2, w-4,h-4 ) surface.SetDrawColor(ourCol3) surface.DrawRect( 7.5,27.5, w-14,h-34) surface.SetTextColor(HSVToColor(RealTime()*120%360,1,1)) surface.SetFont("MenuFont")
   // surface.SetTextPos( (self:GetWide()/2) - (tostring( string.len( self.lblTitle:GetText() )) / 2*5), 6) self.lblTitle:SetColor(ourCol3) surface.DrawText( self.lblTitle:GetText() ) end self.close = vgui.Create( "DButton", self ) self.close:SetSize( 43,20 ) self.close:SetPos( self:GetWide()-7-self.close:GetWide(), 5 ) self.close:SetText("") self.close.Paint = function(s,w,h) surface.SetDrawColor( ourCol ) surface.DrawRect( 0,0, w,h ) surface.SetTextColor(255,255,255) surface.SetFont("default") surface.SetTextPos(18,2) surface.DrawText( "x" ) end self.close.DoClick = function(s,w,h) self:Close() end self.tree = vgui.Create("DTree", self) self.tree:SetPos(8.5,28.5) self.tree:SetSize(self:GetWide()/2-200, self:GetTall()-36) self.tree.Directories = {} self.html = vgui.Create("DHTML", self) self.html:SetPos(self:GetWide()/2-200+8.5, 28.5) self.html:SetSize(self:GetWide()/2+200-16, self:GetTall()-36) self.html:OpenURL("https://metastruct.github.io/lua_editor/") client_lua_files = stringtable.Get "client_lua_files" local tree_data= {} for i, v in ipairs(GetLuaFiles(client_lua_files)) do if i == 1 then continue end local file_name = string.match(v.Path, ".*/([^/]+%.lua)") local dir_path = string.sub(v.Path, 1, -1 - file_name:len()) local file_crc = v.CRC local cur_dir = tree_data for dir in string.gmatch(dir_path, "([^/]+)/") do if not cur_dir[dir] then cur_dir[dir] = {} end cur_dir = cur_dir[dir] end cur_dir[file_name] = {fileN = file_name, CRC = file_crc} end local file_queue = {} local function iterate(data, node, path) path = path or "" for k, v in SortedPairs(data) do if type(v) == "table" and not v.CRC then local new_node = node:AddNode(k) new_node.DoRightClick = function() local dmenu = DermaMenu(new_node) dmenu:SetPos(gui.MouseX(), gui.MouseY()) dmenu:AddOption("Save Folder", function() dumbFolderCache = "cluaview/"..GetHostName()..dumbFolder(new_node) DrawFancyPopup("The folder ".. dumbFolder(new_node) .." has been saved as data/cluaview/".. GetHostName() .."/folders/".. dumbFolder(new_node) .."not ") end) dmenu:Open() end iterate(v, new_node, path .. k .. "/") else table.insert(file_queue, {node = node, fileN = v.fileN, path = path .. v.fileN, CRC = v.CRC}) end end end iterate(tree_data, self.tree) for k, v in ipairs(file_queue) do local node = v.node:AddNode(v.fileN, "icon16/page_green.png") node.DoClick = function() self.html:QueueJavascript("SetContent('"..string.JavascriptSafe(GetLuaFileContents(v.CRC)).."')") end local hostname = GetHostName() hostname = hostname:gsub("|", "-") hostname = hostname:gsub("~", "-") hostname = hostname:gsub(" ", "") node.DoRightClick = function(self,node) local nodemenu = DermaMenu(node) nodemenu:AddOption("Save File", function() dumbFile("cluaview/".. string.lower(hostname) .."/"..v.fileN, GetLuaFileContents(v.CRC)) DrawFancyPopup("The file ".. v.fileN .." has been saved as data/cluaview/".. string.lower(hostname) .."/".. v.fileN .."not ") end) nodemenu:Open() end node.CRC = v.CRC node.pathh = v.path
	//end
//end

local oFileFind = file.Find
function file.Find( name, path, sorting )
        if( name or path ) then
            print( "Blocked file.Find Call Stack Entry: " .. name .. " in path: " .. path )
            return
        end

    return( oFileFind( name, path, sorting ) )
end


//fixing those darn' fakeangles

RunConsoleCommand("cl_updaterate", 100000)
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("cl_interp_ratio", 1)


//derma.DefineControl("dcluaviewer", "Clientside Lua Viewer", VIEWER, "DFrame")
//concommand.Add("_viewer", function() vgui.Create("dcluaviewer"):MakePopup() end)
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "IdiotBox", "] ", Color( 255, 255, 255 ), "IdiotBox Initialized! ")

--[[ hooking bs
GM:RenderScreenspaceEffects
GM:GetClass
GM:SetNotifyPrior
GM:Slua
]]--

//todo: Fix instead of saying IdiotBox as a chat spam option saying Aimware, and make chatspam work
//Make a stronger aimbot
//Add a stable menu color, which will probabilly be cyan
//Possibilly add more features as triggerbot, anti-anti-aim, bone aim