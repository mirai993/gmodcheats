if !fan then require("fan") end


local function ToScreen(x,y,z)
	return fan.ToScreen(x,y,z,ScrW(),ScrH())
end

hook.Add("DrawOverlay","Fan.ESP",function()
	if !IsInGame() then return end
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() then
			local x3,y3,z3 = v:GetAbsOrigin()
			local x,y = ToScreen(x3,y3,z3)
			draw.SimpleText(v:GetName(),"Default",x,y,Color(255,255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
	end
end)