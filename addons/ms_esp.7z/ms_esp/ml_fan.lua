

local fuck = false
concommand.Add("fuck", function()
	fuck = not fuck
	print("! ", fuck)
end)



hook.Add("DrawOverlay","FanESP",function()
	--if not IsInGame() then return end
	if not fuck then return end
	
	for k,v in pairs( player.GetAll() ) do
		if v != LocalPlayer() then
			local Pos = v:GetPos():ToScreen()
			
			draw.SimpleText(v:Nick(),"Default",Pos.x,Pos.y,Color(255,255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
	end
end)




