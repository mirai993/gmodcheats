/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: 1.00.0
	Description	: MODULE TEMPLATE
*/

local MODULE = {
	Name = "nil",
	Hooks = {},
	Help = { 
		/* This is the general layout of the help table */
		"\n  -> MODULE NAME/LABEL :",
		"    convar_name		: Description goes here		: 1-4",
		"    				#ONE, #TWO, #THREE, #FOUR\n",
		"    convar_name		: Description goes here		: 0-180\n",
	}
}

// Functions {
	function MODULE.Function()
		/*
			Function explanation..
		*/
	end
// }

// Register Hooks {
	/*
		This is how you would register MODULE.Function, HOOKNAME Being ex; HUDPaint
		
		MODULE.Hooks["HOOKNAME"] = MODULE.Function
		Asb:Register(MODULE)
	*/
// }