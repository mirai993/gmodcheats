/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: 1.00.0
	Description	: Provides Asb with a Chams Post-render effect
*/

local MODULE = {
	Name = "Chams",
	Hooks = {},
	Help = {
		"\n  -> Chams :",
		"    asb_chams		: Enables chams for enemies		: BOOL\n",
	}
}

// Local vars & functions {
	local self, Overlay = LocalPlayer, Material("asbw")
	// convars {
		local _chams	= CreateClientConVar("asb_chams", "1", true, false)
		local _team		= CreateClientConVar("asb_team", "1", true, false)
	// }
	local Colors = {
		Wireframe	= Color( 255, 255, 255 )
	}
	
	local function OnScreen( e )
		/* OnScreen returns whether an Entity is on screen */
		local a, f = self():GetAimVector():Angle() - (e:GetPos() - self():GetShootPos()):Angle(), self():GetFOV()
		return ( math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2 )
	end
	
	local function ValidTarget( e )	
		/* ValidTarget returns whether an Entity is considered an Enemy */
		if ( !ValidEntity(e) ) || ( e == self() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end

		m = e:GetMoveType()	
		
		if ( m == MOVETYPE_NONE ) then return false end
		if ( e:IsPlayer() ) then
			if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER ) || ( e:Team() == self():Team() && !_team:GetBool() ) then return false end
		end
			
		return true
	end
// }

// Functions {
	function MODULE.Render()
		/* This renders the effects */
		if ( !_chams:GetBool() ) then return end
		
		local targets, t, c, p = {}, 255
		
		cam.Start3D( EyePos(), EyeAngles() )
		// Chams effect {
			// Material & Lighting {
				render.SuppressEngineLighting(true)
				SetMaterialOverride(Overlay)
			// }
			for _, e in pairs( ents.GetAll() ) do
				p = e:GetPos():ToScreen()
				if ( ValidTarget(e) && OnScreen(e) ) then
					table.insert(targets, e); c = Colors.Wireframe
					if ( e:IsPlayer() ) then c = team.GetColor(e:Team()) end
					
					render.SetColorModulation(c.r / t, c.g / t, c.b / t)
					e:DrawModel()
				end
			end
			// Reset {
				render.SuppressEngineLighting(false)
				render.SetColorModulation(1, 1, 1) 			
				SetMaterialOverride()
			// }
			
			for _, e in pairs( targets ) do e:DrawModel() end
		// }
		cam.End3D()
	end
// }

// Register Hooks {
	MODULE.Hooks[MODULE.Render] = "RenderScreenspaceEffects"
	Asb:Register(MODULE)
// }
