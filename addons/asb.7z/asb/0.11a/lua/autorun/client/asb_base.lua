/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: ALPHA 0.11.0
	Description	: The base file that loads & handles Modules
*/

Asb = {}

// Required functions {
	local hook, concommand = hook, concommand
// }
local Files, Hooks, Help = {}, {}, {}
local Header = {
	"\n/*\n  Asb Help table..\n",
	"\n  -> Global :",
	"    asb_team		: Target all Teams			: 0-1\n",
}

// Hook handeling {
	local function RandomString()
		/* Generates a Random String */
		local s, n = ""
			
		for i = 1, math.random(3, 19) do
			n = math.random(65, 116); if ( n > 90 && n < 97 ) then n = n + 6 end
			s = s .. string.char(n)
		end
		
		return s
	end

	local function AddHook( h, f )
		/*
			This actually adds the hook to the Hooks List
		*/
		local n = RandomString()
		
		Hooks[n] = h
		hook.Add(h, n, f)
	end
	
	function Asb:Register( m )
		/* Registers a module */
		local s = debug.getinfo(2, "S").short_src
		
		if ( !m ) then ErrorNoHalt(string.format("ERROR: Attempt to Register nil Module, %s.\n", s)); return end
		
		Files[s] = 0
		for f, h in pairs( m.Hooks ) do
			Msg( string.format("LOADING: '%s'[%s]\n", (m.Name || "nil"), h ) )
			AddHook(h, f)
		end
		
		for _, s in pairs( m.Help ) do
			if ( !table.HasValue(Help, s) ) then
				table.insert(Help, s)
			end
		end
	end
	
	local function PrintHelp()
		/* Prints the help to the console */
		for _, s in pairs( Header ) do print(s) end; for _, s in pairs( Help ) do print(s) end
		print("*/")
	end
	
	local function Unload()
		/* Unloads all the current loaded Modules & Hooks */
		for n, h in pairs( Hooks ) do Msg(string.format("UNLOADING: %s[%s]\n", h, n)); hook.Remove(h, n); Hooks[n] = nil end
		Help = {}
	end
	
	local function Reload()
		/* Unloads all Modules & Hooks; Then reloads the files */
		Unload()
		
		local f = Files
		for s, _ in pairs( f ) do print(string.format("EXECUTING: %s", s)); f[s] = nil; include(s) end
	end
// }

// Commands {
	concommand.Add("asb_base_help", PrintHelp)
	concommand.Add("asb_base_reload", Reload)
	concommand.Add("asb_base_unload", Unload)
// }