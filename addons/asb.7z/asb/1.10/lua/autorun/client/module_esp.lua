/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: 1.00.0
	Description	: Provides Asb with an Esp
*/

local MODULE = {
	Name = "Esp",
	Hooks = {},
	Help = {
		"\n  -> Esp :",
		"    asb_esp		: Enables player Esp			: 0-1\n",
	}
}

// Local vars & functions {
	local self = LocalPlayer
	// convars {
		local _esp		= CreateClientConVar("asb_esp", "1", true, false)
		local _team		= CreateClientConVar("asb_team", "1", true, false)
	// }
	local Colors = {
		Name		= Color( 255, 255, 255 ),
		Outline		= Color( 0, 0, 0, 230)
	}
	
	local function ValidTarget( e )
		/* ValidTarget returns whether an Entity is considered an Enemy */
		if ( !ValidEntity(e) ) || ( e == self() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end

		m = e:GetMoveType()	
		
		if ( m == MOVETYPE_NONE ) then return false end
		if ( e:IsPlayer() ) then
			if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER ) || ( e:Team() == self():Team() && !_team:GetBool() ) then return false end
		end
			
		return true
	end
// }

// Functions {
	function MODULE.Paint()
		/* Paint draws the Esp for players */
		if ( !_esp:GetBool() ) then return end
		
		local b, p, s = self():LookupBone("ValveBiped.Bip01_Neck1")
		
		for _, e in pairs( ents.GetAll() ) do
			if ( ValidTarget(e) && e:IsPlayer() ) then
				p = (e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Neck1")) + Vector(0, 0, 15)):ToScreen()
				s = string.format("%s - [%i]", e:Nick(), e:Health())
				
				draw.SimpleText(s, "DefaultSmall", p.x + 1, p.y + 1, Colors.Outline, 1, 1)
				draw.SimpleText(s, "DefaultSmall", p.x, p.y, Colors.Name, 1, 1)
			end
		end
	end
// }

// Register Hooks {
	MODULE.Hooks["HUDPaintBackground"] = MODULE.Paint
	Asb:Register(MODULE)
// }