/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: 1.00.0
	Description	: Provides Asb with a simple Crosshair
*/

local MODULE = {
	Name = "Crosshair",
	Hooks = {},
	Help = {
		"\n  -> Crosshair :",
		"    asb_crosshair	: Enables a custom crosshair		: 0-1\n",
	}
}

// Local vars {
	// convars {
		local _crosshair	= CreateClientConVar("asb_crosshair", "1", true, false)
	// }
	local Colors = {
		Inside	= Color( 0, 255, 10 ),
		Outline	= Color( 0, 0, 0, 200 )
	}
// }

// Functions {
	function MODULE.Paint()
		/* Paint draws the cursor to the HUD */
		if ( !_crosshair:GetBool() ) then return end
		
		local w, h = ScrW() / 2, ScrH() / 2
		
		surface.SetDrawColor(Colors.Outline)
		// Outline {
			surface.DrawRect(w - 1, h - 4, 3, 9)
			surface.DrawRect(w - 4, h - 1, 9, 3)
		// }
		surface.SetDrawColor(Colors.Inside)
		// Inside {
			surface.DrawLine(w, h - 3, w, h + 3)
			surface.DrawLine(w - 3, h, w + 3, h)
		// }
	end
// }

// Register Hooks {
	MODULE.Hooks["HUDPaint"] = MODULE.Paint
	Asb:Register(MODULE)
// }