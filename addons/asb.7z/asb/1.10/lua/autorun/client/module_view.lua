/*
	Asb -> A simple bot [ Inspoir ]
	
	Revision	: 1.00.0
	Description	: Provides Asb with View Correction
*/

local MODULE = {
	Name = "View Correction",
	Hooks = {},
	Help = {
		"\n  -> View Correction :",
		"    asb_viewcorrect	: Enables View Correction		: 0-1\n",
	}
}

// Local vars {
	local self, viewangle = LocalPlayer, Angle( 0, 0, 0 )
	// convars {
		local _view		= CreateClientConVar("asb_viewcorrect", "1", true, false)
	// }
// }

// Functions {
	function MODULE.Grab()
		/* This Grabs the view before it's distorted */
		viewangle = self():GetAimVector():Angle()
	end
	
	function MODULE.View()
		/* This Corrects the view */
		if ( !_view:GetBool() ) then return end
		
		local w = self():GetActiveWeapon()
		if ( w.Primary ) then w.Primary.Recoil = 0 end
		
		return { angles = viewangle }
	end
// }

// Register Hooks {
	MODULE.Hooks["Think"] = MODULE.Grab
	MODULE.Hooks["CalcView"] = MODULE.View
	Asb:Register(MODULE)
// }