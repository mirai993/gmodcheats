Put In:


 C:/ Program Files/ Steam/Steamapps/Your User/ Garrysmod/garrysmod/addons flder


 That Means Put The File|folder-Asb Into Addos For This To work.


 Its A Lua So You Cant get VAC Banned.


 Options:

 To Start It Up:

 +asb_bot

asb_bot_filter 1
 asb_bot_fov 1
 asb_bot_los 1
 asb_bot_shoot 1
 asb_chams 1
 asb_viewcorrect 1
 asb_team 1
 asb_esp 1
 asb_crosshair 1
 asb_chams 1
 asb_bot_bone 1




            Enjoy!


      I Do Not Take Any Credits Don't Donate At All Or I Kill You.


                      Questions:


             Email Me At: ethanbinkley@gmail.com


           Or Add Me In Steam: ethanbinkley
