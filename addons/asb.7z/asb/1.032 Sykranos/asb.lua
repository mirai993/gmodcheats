/*
	wtf !! [ STEAM_0:0:40143824 | 65.30.50.13:27005 ]
	lua/Asb.lua
*/

/*
	Asb -> A simple bot [ Inspoir ]
	03.04.2009 : REVISION 1.032
*/

if ( SERVER ) then return end


local Asb = {}

//>> Copy common vars {
	// Simple
	local math, table, pairs, string = math, table, pairs, string

	// GMOD main
	local Hook, util, ents, player, vgui = hook, util, ents, player, vgui
	local cam, render = cam, render
	local ScrW, ScrH = ScrW, ScrH
	local Angle, Vector = Angle, Vector
	local LocalPlayer, IsValid = LocalPlayer, IsValid

	// GMOD other
	local CreateClientConVar, CUserCmd, concommand = CreateClientConVar, CUserCmd, concommand
//<< }

//>> Asb vars {
	local ply = LocalPlayer()
	local tar
	local Aiming = false
	local Hooks = {}
	local Menu, MenuCrosshair, MenuEsp, MenuWireframe, MenuRecoil, MenuShoot, MenuAnti, MenuTeam, MenuBone, MenuFov, MenuUnload, MenuReload
	local Next = CurTime()
	local Reloading = false
	local Overlay = Material("models/debug/debugwhite")
	local RenderTargets = {}
	
	local ViewAngle = Vector(0,0,0)
	
	local CPPWeapons = {
		"weapon_phycannon",
		"weapon_physgun",
		"weapon_crowbar",
		"weapon_pistol",
		"weapon_357",
		"weapon_smg1",
		"weapon_ar2",
		"weapon_shotgun",
		"weapon_crossbow",
		"weapon_frag",
		"weapon_rpg",
		"gmod_tool",
		nil
	}
	
	local PassiveWeapons = {
		"weapon_phycannon",
		"weapon_physgun",
		"weapon_crowbar",
		"gmod_tool",
		nil
	}

	//>> ConVars {
		
		local Bone = CreateClientConVar("asb_bone", 1, true, false)
		local Crosshair = CreateClientConVar("asb_crosshair", 1, true, false)
		local Esp = CreateClientConVar("asb_esp", 1, true, false)
		local Fov = CreateClientConVar("asb_fov", 5, true, false)
		local Los = CreateClientConVar("asb_los", 1, true, false)
		local Recoil = CreateClientConVar("asb_norecoil", 1, true, false)
		local Players = CreateClientConVar("asb_players", 1, true, false)
		local Shoot = CreateClientConVar("asb_shoot", 1, true, false)
		local Team = CreateClientConVar("asb_team", 1, true, false)
		local Trigger = CreateClientConVar("asb_trigger", 1, true, false)
		local AntiAim = CreateClientConVar("asb_anti",0,true,false)
		local SilentAim = CreateClientConVar("asb_silent",0,true,false)
		local Wireframe = CreateClientConVar("asb_wireframe", 1, true, false)
	
	//<< }

	local Bones = {
		"ValveBiped.Bip01_Neck1",
		"ValveBiped.Bip01_Spine4",
		"ValveBiped.Bip01_Spine2",
		"ValveBiped.Bip01_Pelvis"
	}
	
	local Colors = {
		Name = Color( 255, 255, 255, 200 ),
		Outline = Color( 0, 0, 0, 235 ),
		Wireframe = Color( 255, 255, 255, 255),
		Crosshair = Color( 0, 255, 10, 230 ),
	}

	local br = "\n>> ------------------------- <<\n"
	local Help = {
		string.format("%s%s%s", "\n" .. br, "A simple bot #HELP [ Inspoir ]", br),
		"asb_bone	: Defines what bones to use		: 0-4",
		"		NONE, NECK, SPINE, CHEST, PELVIS\n",
		"asb_crosshair	: Toggles the custom crosshair		: 0-1",
		"asb_esp		: Toggles the ESP			: 0-1",
		"asb_fov		: The bot's Field of View		: 0-180",
		"asb_los		: Drops a target if not visible		: 0-1",
		"		#0 KEEPS UNTIL DEAD, #1 LOSES LINE OF SIGHT\n",
		"asb_options	: Displays the Asb Options Menu		: FUNC",
		"asb_players	: Toggles Player targetting		: 0-1",
		"		#0 PLAYERS & NPCS, #1 ONLY PLAYERS\n",
		"asb_recoil	: Toggles No Recoil/ViewPunch		: 0-1",
		"		NOTE: This feature works for MOST Weapons!\n",
		"asb_shoot	: Toggles if the bot Autoshoots		: 0-1",
		"asb_team	: Toggles Team targetting		: 0-1",
		"		#0 ALL TEAMS, #1 EVERY TEAM BUT YOURS\n",
		"asb_trigger	: Toggles the Triggerbot		: 0-1",
		"		NOTE: This feature disables while aiming!\n",
		"asb_wireframe	: Toggles enemy wireframe		: 0-1",
		"\n" .. br
	}	
//<< }

//>> Asb global functions {
	local function GenerateRandom()
		/*
			Generates a Random String; Thanks to RabidToaster
		*/ 
		local j, r = 0, ""
		
		for i = 1, math.random(3, 19) do
			j = math.random(65, 116)
			if ( j > 90 && j < 97 ) then j = j + 6 end
			r = r .. string.char(j)
		end
		return r
	end

	local function AddHook( h, f )
		/*
			This is used to catalog the Hooks added; This is done so they can be unloaded & the script reloaded
		*/
		local n = GenerateRandom()
		Hooks[n] = h
		Hook.Add(h, n, f)
	end

	local function GetBone( e )
		/*
			GetBone returns the vector of an Entity; It's purpose is to return the target area for the bot
		*/
		local b = e:GetBonePosition(e:LookupBone(Bones[math.Clamp(Bone:GetInt(), 1, 4)]))
		if ( !b || !Bone:GetBool() ) then b = e:LocalToWorld(e:OBBCenter()) end
		
		return b
	end
	
	local function SimulateShot()
		/*
			SimulateShot simulates shooting a weapon
		*/
		local w = ply:GetActiveWeapon()
		if ( CurTime() < Next || Reloading || w:IsWeapon() && table.HasValue(PassiveWeapons, w:GetClass()) ) then return end

		ply:ConCommand("+attack"); timer.Simple(0.1, function() ply:ConCommand("-attack"); end)
		Next = CurTime() + 0.125
	end
	
	local function ShootTrace()
		/*
			ShootTrace just Returns a trace from gunpoint to 16384 units ahead
		*/
		//>> Trace information {
			local s, e = ply:GetShootPos(), ply:GetAimVector()
			local t = {}
			t.start = s
			t.endpos = s + (e * 16384)
			t.filter = { ply }
		//<< }
		return util.TraceLine(t)
	end
	
	local function Visible( e )
		/*
			Visible returns the visibility of an Entity; It uses a trace to work it's magic
		*/
		if ( !IsValid(e) ) then return false end
		//>> Trace information {
			local t = {}
			t.start = ply:GetShootPos()
			t.endpos = GetBone(e)
			t.filter = { ply }
		//<< }
		return ( util.TraceLine(t).Entity == e )
	end
	
	local function ValidTarget( e )	
		if ( !IsValid(e) ) || ( e == ply ) || ( Players:GetBool() && !e:IsPlayer() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end
		
		local m = e:GetMoveType()	
		if ( m == MOVETYPE_NONE ) then return false end
		if ( e:IsPlayer() ) then
			if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER ) || ( e:Team() == ply:Team() && Team:GetBool() ) then return false end
		end
		
		return true
	end
	
	//>> Math functions {
		local function InRange( j, min, max )
			return ( j >= min && j <= max )
		end
		
		local function toint( v )
			return v && 1 || 0
		end
	//<< }
//<< }

function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end

//>> Asb bot functions {
	function Asb.DrawInfo()
		/*
			DrawInfo draws the ESP & Wireframe functions of the bot; NOTE This is un-optimized; I'll probably re-code it later.
		*/
		draw.SimpleTextOutlined("A Simple Bot [HvH]","DefaultSmall",1235,15,Color(255,255,255,255),4,1,1,Color(0,0,0))
		local j, s
		if ( Esp:GetBool() ) then
			for k, e in pairs( RenderTargets ) do		
				if ( IsValid(e) && e:IsPlayer() ) then
					j = (GetBone(e) + Vector(0, 0, 15)):ToScreen()
					s = string.format("%s - [%i]", e:Nick(), e:Health())
					local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
					surface.SetDrawColor(0,0,255,255)				
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )			
					draw.SimpleTextOutlined(s, "DefaultSmall", j.x, j.y-5, Colors.Name, 2, 1, 1,Color(0,0,0,255))
				end
			end
		end
		RenderTargets = {}
		
		//>> Crosshair {
			if ( !Crosshair:GetBool() ) then return end

			local w, h = ScrW() / 2, ScrH() / 2
			
			//>> Outline {
				surface.SetDrawColor(Colors.Outline)
				surface.DrawRect(w - 1, h - 3, 3, 7)
				surface.DrawRect(w - 3, h - 1, 7, 3)
			//<< }			
			//>> Inside {
				surface.SetDrawColor(Colors.Crosshair)
				surface.DrawLine(w, h - 2, w, h + 2.75)
				surface.DrawLine(w - 2, h, w + 2.75, h)
			//<< }
		//<< }
	end
	
	function Asb.PostRender()
		/*
			PostRender draws the effects such as Wireframe
		*/
		local r = (1/255)
		
		//>> Set our Material & Lighting {
			render.SuppressEngineLighting(true)
			render.MaterialOverride(Overlay)
			
		//<< }
		for k, e in pairs( ents.GetAll() ) do
			if ( ValidTarget(e) ) then
				j = (GetBone(e) + Vector(0, 0, 10)):ToScreen()
				
				if ( InRange(j.x, 0, ScrW()) && InRange(j.y, 0, ScrH()) ) then
					table.insert(RenderTargets, e)
					if ( Wireframe:GetBool() ) then 
						cam.Start3D( EyePos(), EyeAngles() ) 
							//>> Set the color {
								local c = Colors.Wireframe
								if ( e:IsPlayer() ) then c = team.GetColor(e:Team()) end
							//<< }
							//>> Render the Wireframe {
								render.SetColorModulation((r*c.r), (r*c.g), (r*c.b))
								e:DrawModel()
							//<< } 
						cam.End3D()
					end
				end
			end
		end
		//>> Reset {
			render.SuppressEngineLighting(false)
			render.SetColorModulation(1, 1, 1) 
			render.MaterialOverride()
		//<< }
		
		/* 
			This line double renders the targets to achieve a Chams effect 
		*/
		for k, e in pairs( RenderTargets ) do if ( IsValid(e) ) then cam.Start3D( EyePos(), EyeAngles() ); e:DrawModel(); cam.End3D() end end
	end
	

	function Asb.Bot( u )
		/*
			Bot is the basic bones of an aimbot; Selecting the target is also now done here
			Since Autoshooting is calculated here; I put a small auto-reload here also.
		*/
		ViewAngle = u:GetViewAngles()
		
		//>> Auto-reload {
			local w = ply:GetActiveWeapon()
			if ( w:IsWeapon() && w:Clip1() <= 0 ) then ply:ConCommand("+reload"); Reloading = true else ply:ConCommand("-reload"); Reloading = false end
		//<< }
		
		local trace = ShootTrace()
		
		//>> Triggerbot {
		if ( !Aiming && Trigger:GetBool() ) then
			if ( ValidTarget(trace.Entity) && InRange(trace.HitGroup, 0, 3) ) then 
				SimulateShot() 
			end
		end
		//<< }
		
		if ( !Aiming ) then return end
		
		//>> Enemy selection {
		if ( !ValidTarget(tar) || Los:GetBool() && (trace.HitWorld || util.IsValidProp(trace.Entity:GetModel())) ) then
			tar = nil
			local f, o, a, t, b = Fov:GetInt(), { p, y }
			for k, e in pairs( ents.GetAll() ) do
				if ( ValidTarget(e) && Visible(e) ) then
					b = GetBone(e)
					if ( !b || !Bone:GetBool() ) then b = e:LocalToWorld(e:OBBCenter()) end
					
					a, t = ply:GetAimVector():Angle(), (b - ply:GetShootPos()):Angle()
					o.p, o.y = math.abs(math.NormalizeAngle(a.p - t.p)), math.abs(math.NormalizeAngle(a.y - t.y))
					
					if ( !tar || e:Health() > tar:Health() ) && ( o.p <= f && o.y <= f ) then tar = e end
				end
			end
		end
		//<< }
		
		if ( !IsValid(tar) || !Aiming ) then return end
		ViewAngle = (GetBone(tar) - ply:GetShootPos()):Angle()
		u:SetViewAngles(ViewAngle)
		
		if ( !Shoot:GetBool() ) then return end
		trace = ShootTrace()
		if ( ValidTarget(trace.Entity) && InRange(trace.HitGroup, 0, 3) ) then SimulateShot() end
	end
	
	function Asb.NoRecoil( u, o )
		if ( !Recoil:GetBool() ) then return end
		//>> No Recoil For most SWEPS {		
			local w = ply:GetActiveWeapon()
			
			if ( w.Primary ) then w.Primary.Recoil = 0.0 end
			if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
		//<< }
		return { origin = o, angles = ViewAngle }
	end
//<< }


function AntiAim(cmd)
	if GetConVarNumber("asb_anti") == 1 then
	if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
		local aa = cmd:GetViewAngles()
		cmd:SetViewAngles(Angle(-181, aa.y, 180))
	end
end
hook.Add("CreateMove","fackyou",AntiAim);

Asb.EyeAngles = Angle(0,0,0)
Asb.StoredAngle = Angle(0,0,0)
Asb.AngleRestored = 0
Asb.Ang = Angle(0,0,0)
local old_rcc = RunConsoleCommand

concommand.Add("asb_view", function()
	Asb.FixView = 1
	if GetConVarNumber("asb_silent") == 1 then 
	Asb.StoredAngle = LocalPlayer():EyeAngles()	
	end
	Asb.Ang = LocalPlayer():EyeAngles()	
	Asb.AngleRestored = 0
end)


local SetViewAngles = SetViewAngles

function Asb.FovCheck( ent, fov )
	if fov == 0 or fov == 180 then return true end	
	if ValidEntity( ent ) then
		if GetConVarNumber("asb_silent") == 0 then	
			LAng = LocalPlayer():EyeAngles()	
		else		
			LAng = Asb.StoredAngle		
		end		
		if math.NormalizeAngle( ( Asb.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) > fov then return false end	
		if math.NormalizeAngle( ( Asb.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LAng.y ) < -fov then return false end
		if math.NormalizeAngle( ( Asb.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) < -fov then return false end
		if math.NormalizeAngle( ( Asb.GetHeadPos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LAng.p ) > fov then return false end
				
	end
	return true
end

function Asb.FakeView(cmd)
	if GetConVarNumber("asb_silent") == 1 then
		Asb.StoredAngle.p = math.Clamp(Asb.StoredAngle.p + (cmd:GetMouseY() * 0.022), -89, 89)	
		Asb.StoredAngle.y = math.NormalizeAngle(Asb.StoredAngle.y + (cmd:GetMouseX() * 0.022 * -1))
		Asb.StoredAngle.r = 0
	end	
end
AddHook("CreateMove",Asb.FakeView)

function AimHook( cmd )
if GetConVarNumber("asb_silent") == 1 then		
		local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - Asb.StoredAngle)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())	
		cmd:SetForwardMove(Forward.x)		
		cmd:SetSideMove(Forward.y)		
	end
end
AddHook("CreateMove",AimHook)

function Asb.CalcView(ply, pos, angles, fov)
    local view = {}	
    view.origin = pos
	if Asb.FixView == 1 and GetViewEntity() == LocalPlayer() and GetConVarNumber("asb_silent") == 1 then	
		view.angles = Asb.StoredAngle	
	end	
	if Aiming == false then
		view.angles = Asb.StoredAngle
	end
    view.fov = fov 
    return view	
end
AddHook("CalcView", Asb.CalcView)



//>> Asb main functions {
	function Asb.On()
		Aiming = true
	end
	
	function Asb.Off()
		Aiming = false
		tar = nil
	end
	
	function Asb.Initialize()
		ply = LocalPlayer()
		Menu = vgui.Create("DFrame") //>> Menu {
			if ( !Menu ) then return end
			Menu:SetSize(150, 275)
			Menu:SetPos(ScrW()-170, (ScrH()/2)-117.5)
			Menu:SetTitle("A simple bot")
			Menu:SetSizable(false)
			Menu:SetDeleteOnClose(false)
			Menu:MakePopup()
			Menu:SetVisible(false)
		//<< }
		MenuCrosshair = vgui.Create("DCheckBoxLabel", Menu) //>> MenuCrosshair {
			MenuCrosshair:SetSize(100, 15)
			MenuCrosshair:SetPos(5, 30)
			MenuCrosshair:SetText("Crosshair")
			MenuCrosshair:SetValue(Crosshair:GetBool())
		//<< }
		MenuEsp = vgui.Create("DCheckBoxLabel", Menu) //>> MenuEsp {
			MenuEsp:SetSize(100, 15)
			MenuEsp:SetPos(5, 50)
			MenuEsp:SetText("Esp")
			MenuEsp:SetValue(Esp:GetBool())
		//<< }
		MenuWireframe = vgui.Create("DCheckBoxLabel", Menu) //>> MenuWireframe {
			MenuWireframe:SetSize(100, 15)
			MenuWireframe:SetPos(5, 70)
			MenuWireframe:SetText("No Recoil")
			MenuWireframe:SetValue(Recoil:GetBool())
		//<< }
		MenuRecoil = vgui.Create("DCheckBoxLabel", Menu) //>> MenuRecoil {
			MenuRecoil:SetSize(100, 15)
			MenuRecoil:SetPos(5, 90)
			MenuRecoil:SetText("Silent Aim")
			MenuRecoil:SetValue(GetConVarNumber("asb_silent"))
		//<< }
		MenuShoot = vgui.Create("DCheckBoxLabel", Menu) //>> MenuShoot {
			MenuShoot:SetSize(100, 15)
			MenuShoot:SetPos(5, 110)
			MenuShoot:SetText("Autoshoot")
			MenuShoot:SetValue(Shoot:GetBool())
		//<< }
		MenuAnti = vgui.Create("DCheckBoxLabel", Menu) //>> MenuAnti {
			MenuAnti:SetSize(100, 15)
			MenuAnti:SetPos(5, 130)
			MenuAnti:SetText("Anti-Aim")
			MenuAnti:SetValue(GetConVarNumber("asb_anti"))
		//<< }
		MenuTeam = vgui.Create("DCheckBoxLabel", Menu) //>> MenuTeam {
			MenuTeam:SetSize(100, 15)
			MenuTeam:SetPos(5, 150)
			MenuTeam:SetText("All Teams")
			MenuTeam:SetValue(!Team:GetBool())
		//<< }
		MenuFov = vgui.Create("DNumSlider", Menu) //>> MenuFov {
			MenuFov:SetSize(140, 35)
			MenuFov:SetPos(5, 170)
			MenuFov:SetText("Fov")
			MenuFov:SetDecimals(0)
			MenuFov:SetMinMax(0, 180)
			MenuFov:SetValue(Fov:GetInt())
		//>> }
		MenuBone = vgui.Create("DNumSlider", Menu) //>> MenuBone {
			MenuBone:SetSize(140, 35)
			MenuBone:SetPos(5, 210)
			MenuBone:SetText("Bone")
			MenuBone:SetDecimals(0)
			MenuBone:SetMinMax(0, 4)
			MenuBone:SetValue(Bone:GetInt())
		//>> }
		MenuUnload = vgui.Create("DButton", Menu) //>> MenuUnload {
			MenuUnload:SetSize(65, 20)
			MenuUnload:SetPos(5, 250)
			MenuUnload:SetText("Unload")
		//>> }
		MenuReload = vgui.Create("DButton", Menu) //>> MenuReload {
			MenuReload:SetSize(65, 20)
			MenuReload:SetPos(80, 250)
			MenuReload:SetText("Reload")
		//>> }
		
		//>> Menu stuff {
			function MenuCrosshair:OnChange()
				RunConsoleCommand("asb_crosshair", toint(MenuCrosshair:GetChecked()))
			end
			
			function MenuEsp:OnChange()
				RunConsoleCommand("asb_esp", toint(MenuEsp:GetChecked()))
			end
			
			function MenuWireframe:OnChange()
				RunConsoleCommand("asb_norecoil", toint(MenuWireframe:GetChecked()))
			end
			
			function MenuRecoil:OnChange()
				RunConsoleCommand("asb_silent", toint(MenuRecoil:GetChecked()))
			end
			
			function MenuShoot:OnChange()
				RunConsoleCommand("asb_shoot", toint(MenuShoot:GetChecked()))
			end
			
			function MenuAnti:OnChange()
				RunConsoleCommand("asb_anti", toint(MenuAnti:GetChecked()))
			end
			
			function MenuTeam:OnChange()
				RunConsoleCommand("asb_team", toint(!MenuTeam:GetChecked()))
			end

			function MenuFov:OnValueChanged()
				RunConsoleCommand("asb_fov", MenuFov:GetValue())
			end
			
			function MenuBone:OnValueChanged()
				RunConsoleCommand("asb_bone", MenuBone:GetValue())
			end
			
			function MenuUnload:OnMousePressed()
				Asb.Unload()
			end
			
			function MenuReload:OnMousePressed()
				Asb.Reload()
			end
		//<< }	
	end
	
	function Asb.Visible()		
		if ( Menu && Menu:IsValid() ) then Menu:SetVisible(not Menu:IsVisible()) end
	end
	
	function Asb.Help()
		for i, m in pairs(Help) do
			Msg(m .. "\n")
		end
	end
	
	function Asb.Unload()
		for n, h in pairs( Hooks ) do
			print(string.format("Removing: %s[%s]", h, n))
			Hook.Remove(h, n)
		end
		Hooks = {}
		if ( Menu && Menu:IsValid() ) then Menu:Remove() end
	end
	
	function Asb.Reload()
		Asb.Unload()
		local s = debug.getinfo(1, "S").short_src // Debug Function documented @ http://www.lua.org/manual/5.1/manual.html#lua_getinfo
		if ( s ) then print(string.format("Reloading file: -> %s", s)); include(s) else error("Cannot reload Asb..\n") end
	end	
//<< }

//>> Hooks & stuff {
	concommand.Add("+asb", Asb.On)
	concommand.Add("-asb", Asb.Off)
	concommand.Add("asb_menu", Asb.Visible)
	concommand.Add("asb_help", Asb.Help)
	concommand.Add("asb_unload", Asb.Unload)
	concommand.Add("asb_reload", Asb.Reload)

	AddHook("InitPostEntity", Asb.Initialize)
	AddHook("CreateMove", Asb.Bot)
	AddHook("HUDPaint", Asb.DrawInfo)
	AddHook("RenderScreenspaceEffects", Asb.PostRender)
	AddHook("CalcView", Asb.NoRecoil)
//<< }

if ( !Menu ) then Asb.Initialize() end

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         