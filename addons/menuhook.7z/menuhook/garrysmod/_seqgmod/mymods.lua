concommand.Add("print_gamers",function()
	for i=1,#player.GetAll() do
		print(player.GetAll()[i],player.GetAll()[i]:GetUserGroup())
	end
end)

local CompileString=CompileString

local function safeRun(b, c, d, a)   
	local a=a or table.concat(d," ") or print('failed') and ""
    pcall(function()
        local a = CompileString( a, "[C]", false )
        if type(a) == "function" then
            a()
        else
            MsgN(a)
        end
    end)
end

local function safeOpen(b, c, d, a)   
	local a=d[1] or a or print('failed') and ""
	a=file.Read("menuhook/"..a,"MOD")
    pcall(function()
        local a = CompileString( a, "[C]", false )
        if type(a) == "function" then
            a()
        else
            MsgN(a)
        end
    end)
end

_G._MH=_G

concommand.Add("gseq_open", safeOpen)
concommand.Add("gseq_run", safeRun)

--CreateConVar("external","LuaCmd",{FCVAR_CHEAT,FCVAR_PROTECTED,FCVAR_NOT_CONNECTED,FCVAR_USERINFO,FCVAR_UNREGISTERED,FCVAR_REPLICATED,FCVAR_UNLOGGED,FCVAR_DONTRECORD,FCVAR_SPONLY},"")