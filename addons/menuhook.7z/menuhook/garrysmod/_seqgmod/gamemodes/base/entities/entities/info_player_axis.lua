
-- This is just a simple point entity.

-- We only use it to represent the position and angle of a spawn point
-- So we don't have to do anything here because the baseclass will 
-- take care of the basics

-- This file only exists so that the entity is created

ENT.Type = "point"
