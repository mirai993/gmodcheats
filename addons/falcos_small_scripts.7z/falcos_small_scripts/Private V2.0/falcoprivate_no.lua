--[[
	MOD/lua/autorun/falco/lua_falcoprivate_nob.lua [#727 (#742), 187042984]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:39PM]
	===BadFile===
]]

hook.Add("InitPostEntity", "UseLocalPlayer", function()
	local sound = CreateSound(LocalPlayer(), "ambient/atmosphere/station_ambience_loop2.wav")
	local NoB = CreateClientConVar("falco_nob", 0, true, false)
	hook.Add("PlayerBindPress", "CantPressBWhenHoldingA", function(ply, bind, pressed)
		if not tobool(NoB:GetInt()) then return end
		if (bind == "+moveleft" and LocalPlayer():KeyDown(IN_FORWARD)) or (bind == "+forward" and LocalPlayer():KeyDown(IN_MOVELEFT)) then
			sound:PlayEx(0.4, 100)
			hook.Add("Think", "UnPlaySound", function()
				if not LocalPlayer():KeyDown(IN_FORWARD) or not LocalPlayer():KeyDown(IN_MOVELEFT) then
					sound:Stop()
					hook.Remove("Think", "UnPlaySound")
				end
			end)
		end
	end)
end)