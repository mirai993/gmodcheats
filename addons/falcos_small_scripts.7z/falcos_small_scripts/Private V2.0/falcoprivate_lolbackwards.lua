--[[
	MOD/lua/autorun/falco/lua_falcoprivate_lolbackwards.lua [#1404 (#1452), 3482899735]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:36PM]
	===BadFile===
]]

local backwardsOn = false
concommand.Add("falco_lolbackwards", function()
	if backwardsOn then
		backwardsOn = not backwardsOn
		hook.Remove("CalcView", "Lolbackwards")
		hook.Remove("CreateMove", "Lolbackwards")
		return
	end
	backwardsOn = not backwardsOn
	
	local view = {}
	hook.Add("CalcView", "Lolbackwards", function(ply, origin, angles, fov)
		view.origin = origin
		return view
	end)
	
	local Wait = false
	hook.Add("CreateMove", "Lolbackwards", function(ucm)
		local a = ucm:GetViewAngles()
		--1/2048
		local button = ucm:GetButtons()
		
		if ucm:KeyDown(IN_ATTACK) or ucm:KeyDown(IN_ATTACK2) then
			local sensitivity = math.pow(3, GetConVarNumber("sensitivity"))
			view.angles = Angle(view.angles.p + ucm:GetMouseY()/sensitivity, view.angles.y - ucm:GetMouseX()/sensitivity, view.angles.r)
			ucm:SetViewAngles(view.angles)
			Wait = true
		else
			if Wait then
				ucm:SetViewAngles(Angle(view.angles.p, view.angles.y - 180, view.angles.r))
				Wait = false
			end
			view.angles = Angle(a.p, a.y-180, a.r)
			
			--print(ucm:GetSideMove())
			if ucm:KeyDown(IN_FORWARD) then
				ucm:SetForwardMove(-100000)
			elseif ucm:KeyDown(IN_BACK) then
				ucm:SetForwardMove(100000)
			elseif ucm:KeyDown(IN_MOVELEFT) then
				ucm:SetSideMove(100000)
			elseif ucm:KeyDown(IN_MOVERIGHT) then
				ucm:SetSideMove(-100000)
			end
		end
		--print(ucm:KeyDown(IN_FORWARD))
		--8 16 512 1024
	end)
end)