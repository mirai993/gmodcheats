--[[
	MOD/lua/autorun/falco/lua_falcoprivate_bypassse.lua [#285 (#295), 1232754118]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:24PM]
	===BadFile===
]]

//require("cvar2")

function Falco_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("falco_bypass", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
concommand.Add("falco_forcevar", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)