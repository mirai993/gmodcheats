--[[
	MOD/lua/autorun/falco/lua_falcoprivate_becomemedic.lua [#304 (#313), 4001536991]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:22PM]
	===BadFile===
]]

-- I use this every single time I join a server
local Medics = {"medic", "doctor", "krankenhaus"}

concommand.Add("falco_becomeMedic", function()
	for k,v in pairs(RPExtraTeams or {}) do
		if table.HasValue(Medics, string.lower(v.command)) then
			RunConsoleCommand("say", "/"..v.command)
		end
	end
end)