--[[
	MOD/lua/autorun/falco/lua_falcoprivate_pkdet.lua [#1038 (#1066), 2214797115]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:42PM]
	===BadFile===
]]

local wait = false
local enabled = CreateClientConVar("falco_PropKillDetector", 0, true, false)
local function GetPropKiller()
	if not LocalPlayer():Alive() and not wait then
		wait = true
		for k,v in pairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 100)) do
			--print(v:GetClass())
			if v:GetClass() == "prop_physics" and v:GetNWString("Owner") ~= "" and v:GetNWString("Owner") ~= LocalPlayer():Nick() and v:GetNWString("Owner") ~= "Shared" and v:GetNWString("Owner") ~= "World" then
				RunConsoleCommand("say", v:GetNWString("Owner") .. ", did you propkill me?")
			end
		end
		--LocalPlayer():ChatPrint("I died")
	elseif LocalPlayer():Alive() and wait then
		wait = false
		--LocalPlayer():ChatPrint("I spawned")
	end
end

if enabled:GetInt() == 1 then
	hook.Add("Think", "GetPropKiller", GetPropKiller)
end

cvars.AddChangeCallback("falco_PropKillDetector", function(cvar, prevvalue, newvalue)
	if newvalue == "1" then
		hook.Add("Think", "GetPropKiller", GetPropKiller)
	else
		hook.Remove("Think", "GetPropKiller")
	end
end)