--[[
	MOD/lua/autorun/falco/lua_falcoprivate_togglebinds.lua [#661 (#675), 1645604337]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:47PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Being able to toggle +/- commands can be useful at times
---------------------------------------------------------------------------*/
local togglecommands = {}
local function ToggleAPlusMinusCommand(ply,cmd,args)
	if not args[1] then print("enter an argument plz") return end
	if not togglecommands[args[1]] then togglecommands[args[1]] = false end
	if not togglecommands[args[1]] then
		RunConsoleCommand("+"..args[1])
	else
		RunConsoleCommand("-"..args[1])
	end
	togglecommands[args[1]] = not togglecommands[args[1]]
end
concommand.Add("falco_togglecmd", ToggleAPlusMinusCommand)