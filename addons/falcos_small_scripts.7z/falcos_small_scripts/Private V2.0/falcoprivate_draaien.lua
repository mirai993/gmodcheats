--[[
	MOD/lua/autorun/falco/lua_falcoprivate_draaien.lua [#3293 (#3387), 1545812128]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:59:26PM]
	===BadFile===
]]

local function DoeDraaiEen()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)
	
	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("falco_180", DoeDraaiEen)

local function DoeDraaiTwee()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)
	
	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, RunConsoleCommand, "-jump")
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, RunConsoleCommand, "-jump")
end
concommand.Add("falco_180up", DoeDraaiTwee)

concommand.Add("falco_180shot", function()
	local IsHook = hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	if IsHook then
		DoeDraaiEen()
		hook.Remove("CalcView", "180shot")
		timer.Destroy("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {}
		view.origin = origin
		view.angles = angle - Angle(0,180,0)
		view.fov = fov

		if not LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Remove("CalcView", "180shot")
			DoeDraaiEen()
			timer.Destroy("180shot")
		end

		return view
	end)
	DoeDraaiEen()
	timer.Create("180shot", 5, 1, function()
		hook.Remove("CalcView", "180shot")
		DoeDraaiEen()
	end)
end)

local AntiFallProp = "models/props/cs_office/table_meeting.mdl"
local function BreakFallMidAir()
	FALCO_NOAUTOPICKUP = true
	timer.Simple(0.5, function() FALCO_NOAUTOPICKUP = false end)
	
	FSpawnModel(AntiFallProp)
	RunConsoleCommand("+attack")
	hook.Add("OnEntityCreated", "SpawnAntiDrop", function(ent)
		if not ValidEntity(ent) or string.lower(ent:GetModel() or "") ~= AntiFallProp then return end
		hook.Remove("OnEntityCreated", "SpawnAntiDrop")
		
		local a = LocalPlayer():EyeAngles() 
		LocalPlayer():SetEyeAngles(Angle(-90, a.y-180, a.r))
		if ValidEntity(ent) and ValidEntity(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" and LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Add("Think", "BreakFallInMidAir", function()
				if not ValidEntity(ent) or not LocalPlayer():KeyDown(IN_ATTACK) then hook.Remove("Think", "BreakFallInMidAir") return end
				if ent:GetPos():Distance(LocalPlayer():GetPos()) < 650 then 
					RunConsoleCommand("+attack2")
					
					timer.Simple(0.1, RunConsoleCommand, "-attack2")
					timer.Simple(0.15, RunConsoleCommand, "-attack")
					hook.Remove("Think", "BreakFallInMidAir") 
				end
			end)
		end
	end)
	timer.Simple(1, hook.Remove, "OnEntityCreated", "SpawnAntiDrop")
end
concommand.Add("falco_180BreakFall", BreakFallMidAir)