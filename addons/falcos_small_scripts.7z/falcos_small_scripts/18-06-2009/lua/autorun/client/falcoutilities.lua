print("OPENING FALCO'S SCRIPTS!")
local cansay = true
FALCO_CHATTIME = 1.6
local OOC = CreateClientConVar("falco_ooc", 1, true, false)

function Falco_DelayedSay(text)
	if cansay then
		local add = ""
		if OOC:GetInt() == 1 then add = "/ooc " end
		local endresult = add.. tostring(text)
		if string.len(endresult) >= 126 then
			timer.Simple(1.62, Falco_DelayedSay, string.sub(endresult, 127))
		end
		LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
		cansay = false
		timer.Simple(FALCO_CHATTIME, function() cansay = true end)
	else
		timer.Simple(FALCO_CHATTIME, Falco_DelayedSay, text)
	end
end


FALCO_CHATCOMMANDS = {}

function falco_addchatcmd(text, func)
	FALCO_CHATCOMMANDS[text] = func
end

function FALCO_CHAT(ply, text, teamonly, dead)
	if ply == LocalPlayer() then
		cansay = false
		timer.Simple(2.1, function() cansay = true end)
		for k,v in pairs(FALCO_CHATCOMMANDS) do
			if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then 
				v(string.sub(text, string.len(k) + 2)) 
				break
			elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
				v(string.sub(text, string.len(k) + 8)) 
			end
		end
	end	
end
hook.Add( "OnPlayerChat", "Falco_chat", FALCO_CHAT)
falco_addchatcmd("FReloadScripts", function() include("autorun/client/falcoutilities.lua") end)

function fnotify(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if GAMEMODE.IsSandboxDerived then // in some gamemodes GAMEMODE:AddNotify() doesn't exist
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound( "ambient/water/drip2.wav") // I don't care about the other drips so no difficult concatenations or something
	end
end

include("falco/changedzoom.lua")
include("falco/ClientSideVote.lua")
include("falco/Concommands.lua")
include("falco/draaien.lua")
include("falco/FalcoSpectate.lua")
include("falco/FLolRot.lua")
include("falco/infomod.lua")
include("falco/NamesOnHeads.lua")
include("falco/NewXrayVision.lua")
include("falco/Noise.lua")
include("falco/pianovgui.lua")
include("falco/PKdet.lua")
include("falco/PlayerDetector.lua")
include("falco/tellmoney.lua")
include("falco/toggleduck.lua")
include("falco/ToKey.lua")
include("falco/Weaponwarning.lua")
include("falco/Dolua.lua")
include("falco/lyricsman.lua")
include("falco/falco_cameramode.lua")
include("falco/protect.lua")

