
resource.AddFile("materials/VGUI/entities/blackkey.vmt")
resource.AddFile("materials/VGUI/entities/blackkey.vtf")
resource.AddFile("materials/VGUI/entities/PianoPic.vmt")
resource.AddFile("materials/VGUI/entities/PianoPic.vtf")
resource.AddFile("materials/VGUI/entities/whitekey.vmt")
resource.AddFile("materials/VGUI/entities/whitekey.vtf")
for k,v in pairs(file.Find("../sound/Falco/*")) do resource.AddFile("sound/Falco/"..v) end

AddCSLuaFile("autorun/client/falcoutilities.lua") 
AddCSLuaFile("falco/pianovgui.lua")
AddCSLuaFile("falco/ToKey.lua")
AddCSLuaFile("falco/Concommands.lua")