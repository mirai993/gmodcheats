function DoeDraaiEen()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("falco_rotate1", DoeDraaiEen)

function DoeDraaiTwee()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, RunConsoleCommand, "-jump")
end
concommand.Add("falco_rotate2", DoeDraaiTwee)
