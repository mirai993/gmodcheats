local function FastUndo()
	hook.Add("Think", "fastundo", function()
		RunConsoleCommand("impulse", "100")
	end)	
end
concommand.Add("+falco_makesound", FastUndo)

local function UndoFastUndo()
	hook.Remove( "Think", "fastundo")
end
concommand.Add("-falco_makesound", UndoFastUndo)

local bool = false
local function fastsound()
	bool = not bool
	if bool then
		hook.Add("Think", "fastsound", function()
			RunConsoleCommand("impulse", "100")
		end)	
	else 
		hook.Remove( "Think", "fastsound")
	end
end
concommand.Add("falco_makesound", fastsound)