function DoeLua(ply,cmd,args)
	local Str = ""
	for k,v in pairs(args) do
		Str = Str .. "" .. string.gsub(v, "\"", "'")
	end
	print("RUNNING LUA!", Str)
	RunString(Str)
end
concommand.Add("falco_runlooah", DoeLua)

function OpenLua(ply,cmd,args)
	
	local Str = ""
	for k,v in pairs(args) do
		Str = Str .. "" .. string.gsub(v, "\"", "'")
		//print(Str)
	end
	print("OPENING FILE", Str)
	include(Str)
end
concommand.Add("falco_openlooah", OpenLua)