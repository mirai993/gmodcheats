local wait = false
local enabled = CreateClientConVar("falco_PropKillDetector", 0, true, false)
function GetPropKiller()
	if enabled:GetInt() == 1 then
		if not LocalPlayer():Alive() and not wait then
			wait = true
			for k,v in pairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 100)) do
				if v:GetClass() == "prop_physics" and v:GetNWString("Owner") ~= "" and v:GetNWString("Owner") ~= LocalPlayer():Nick() and v:GetNWString("Owner") ~= "Shared" and v:GetNWString("Owner") ~= "World" then
					RunConsoleCommand("say", v:GetNWString("Owner") .. ", did you propkill me?")
				end
			end
		elseif LocalPlayer():Alive() and wait then
			wait = false
		end
	end
end
hook.Add("Think", "GetPropKiller", GetPropKiller)