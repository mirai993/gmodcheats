function TellAllMoneyAmounts()
	local Rep = table.Copy(player.GetAll())
	table.sort(Rep, function(a, b) return a:GetNWInt("money") > b:GetNWInt("money") end)
	for k,v in pairs(Rep) do
		timer.Simple(k * 1.7, Falco_DelayedSay, tostring(k)..": "..v:Nick() .. " has $" .. v:GetNWInt("money") .. " in his/her wallet")
	end
end
concommand.Add("Falco_sayAllMoney", TellAllMoneyAmounts)
falco_addchatcmd("falco_sayallmoney", TellAllMoneyAmounts)

function TellAllHunger()
	local Rep = table.Copy(player.GetAll())
	table.sort(Rep, function(a, b) return a:GetNWInt("Energy") > b:GetNWInt("Energy") end)
	for k,v in pairs(Rep) do
		timer.Simple(k * 1.7, Falco_DelayedSay, tostring(k)..": "..v:Nick() .. " has " .. v:GetNWInt("Energy") .. "% energy(hunger) left")
	end
end
concommand.Add("falco_SayAllHunger", TellAllHunger)
falco_addchatcmd("falco_SayAllHunger", TellAllHunger)

local function FSayMoney(ply, text, teamonly, dead)
	if string.find(string.lower(text), "fsaymoney") ~= 1 then return end
	local nick = ply:Nick()
	local text2 = text
	if string.find(text, nick) then
		text2 = string.lower(string.sub(text, string.len("("..nick..") ") + 1))
	end
	local find = string.gsub(string.lower(text2), "fsaymoney ", "") 
	if string.find(find, " ") == 1 then find = string.sub(find, 2) end
	
	local found = false
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()), string.lower(find)) then
			found = v
		end
	end
	if not found then fnotify("Player not found", 1, 4) return end
	timer.Simple(1.7, Falco_DelayedSay, found:Nick() .. " has $" .. found:GetNWInt("money") .. " in his/her wallet")
end
hook.Add( "OnPlayerChat", "FSayMoney", FSayMoney)

function TellAllAdmins()
	local a = 0
	local Admins = ""
	local Superadmins = ""
	local ASSUsers = ""
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() and not v:IsSuperAdmin() then
			Admins = ", " .. v:Nick() .. Admins
			a = a + 1
		elseif v:IsSuperAdmin() then
			Superadmins = ", " .. v:Nick() .. Superadmins
			a = a + 1
		end
		if ASS_Initialized ~= nil or LevelToString ~= nil then -- Check if ASS is active on the server
			if v:GetNWInt("ASS_isAdmin") ~= 5 then
				ASSUsers = ", " .. v:Nick() .." = " .. LevelToString(v:GetNWInt("ASS_isAdmin"))  .. ASSUsers
			end
		end
	end
	if Admins ~= "" then
		Falco_DelayedSay( "Admins: " .. string.sub(Admins, 3))
	end
	if Superadmins ~= "" then
		timer.Simple(1.7, Falco_DelayedSay,  "SuperAdmins: " .. string.sub(Superadmins, 3))
	end
	if ASSUsers ~= "" then
		timer.Simple(1.8, Falco_DelayedSay,  "ASS: " .. string.sub(ASSUsers, 3))
	end
	if Admins == "" and Superadmins == "" then
		Falco_DelayedSay( "Falco's scripts: There are no admins on this server")
	end
end
concommand.Add("Falco_sayAllAdmins", TellAllAdmins)
falco_addchatcmd("falco_sayalladmins", TellAllAdmins)