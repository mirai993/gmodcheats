local enabled = CreateClientConVar("Falco_ArrestBatonWarning", 0, true, false)

local waits = {}

local function getAllWeapons()
	if enabled:GetInt() == 1 then
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() == "arrest_stick" and not waits[v] then
				print("ARREST BATON")
				Falco_DelayedSay(v:Nick() .. " pulled out his arrest baton")
				waits[v] = true
			elseif ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() ~= "arrest_stick" and waits[v] then
				print("NOT ARREST BATON")
				waits[v] = false
			end
		end
	end
end
hook.Add("Think", "falco_WeaponAlert", getAllWeapons)