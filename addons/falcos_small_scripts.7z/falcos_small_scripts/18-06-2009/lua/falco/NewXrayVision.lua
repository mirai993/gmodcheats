local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local FGetMat = _R.Entity.GetMaterial
local repmat = CreateClientConVar("falco_xraymaterial", "mat2", true, false)

local function TogglePoKiRay()
	if RayOn then
		surface.PlaySound("buttons/button19.wav") 
		for k,v in pairs(ents.GetAll()) do
			FSetMat(v, AllMats[v])
			local z = allcolors[v]
			if z and type(z) == "table" then
				FSetColor(v, z.r, z.g, z.b, z.a)
			else 
				FSetColor(v, 255,255,255,255)
			end
		end
		allcolors = {}
	else
		for k,v in pairs(ents.GetAll()) do
			ExecFRayOnce(v)
		end
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("falco_xray", TogglePoKiRay)

function ExecFRayOnce(v)
	local r,g,b,a = v:GetColor()
	local class = v:GetClass()
	local low = string.lower(class)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 0, 0, 255, 255)
	elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 140, 0, 255, 255)
	elseif string.find(class, "ghost") and a ~= 100 then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255,255,255,100)
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 0, 100, 50)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and not v:IsWeapon() and class ~= "viewmodel" and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 200, 0, 100)
	end
	if class ~= "viewmodel" and FGetMat(v) ~= repmat:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
		AllMats[v] = FGetMat(v)
		FSetMat(v, repmat:GetString())
	end
end

function DoPoKiRay()
	if not RayOn then return end
	for k,v in pairs(ents.FindByClass("prop_physics")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(ents.FindByClass("prop")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			FSetColor(v,255,0,0,255)
			FSetMat(v, repmat:GetString())
		end
	end
end 
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)

local function FDynamicLight()
	local dlight = DynamicLight( LocalPlayer():UserID() ) 
	if ( dlight ) then 
		dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
		dlight.r = 255
		dlight.g = 255 
		dlight.b = 255
		dlight.Brightness = 10 
		dlight.Size = 700
		dlight.Decay = 0 
		dlight.DieTime = CurTime() + 0.2
	end 
end  
 
local togglelight = true
concommand.Add("falco_light", function()
	togglelight = not togglelight
	LocalPlayer():EmitSound("items/flashlight1.wav",100,100)
	if togglelight then
		hook.Remove("Think", "Falco_Light")
	else
		hook.Add("Think", "Falco_Light", FDynamicLight)
	end
end)