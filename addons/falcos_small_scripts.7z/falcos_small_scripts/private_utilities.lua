--[[
	MOD/lua/autorun/client/falcoprivateutilities.lua [#9068 (#9343), 1633151941]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 03:57:50PM]
	===BadFile===
]]

local cansay = true
FALCO_CHATTIME = 1.6
local OOC = CreateClientConVar("falco_ooc", 1, true, false)

local _R = debug.getregistry()
FALCO_RPRealName = _R.Player.Nick

function Falco_DelayedSay(text)
	if cansay then
		local add = ""
		if OOC:GetInt() == 1 and GetGlobalInt("alltalk") == 0 then add = "/ooc " end
		local endresult = add.. tostring(text)
		if string.len(endresult) >= 126 then
			timer.Simple(1.62, function() Falco_DelayedSay(string.sub(endresult, 127)) end)
		end
		LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
		cansay = false
		timer.Simple(FALCO_CHATTIME, function() cansay = true end)
	else
		timer.Simple(FALCO_CHATTIME, function() Falco_DelayedSay(text) end)
	end
end
concommand.Add("Falco_delayedsay", function(_,_,args) Falco_DelayedSay(table.concat(args, " ")) end)

--Example:
concommand.Add("falco_hiall", function()
	local hiall = ""
	for k,v in pairs(player.GetAll()) do
		if v ~= LocalPlayer() then
			hiall = hiall ..", hi " .. v:Nick()
		end
	end
	hiall = string.sub(hiall, 3)
	Falco_DelayedSay(hiall)
end)

-- Nice chat print solution.
function fprint(...)
	local Printage = {}
	local arg = {...}
	for k,v in pairs(arg) do
		Printage[k] = tostring(arg[k]).."\t"
	end
	chat.AddText(Color(255,0,0,255), unpack(Printage))
end
usermessage.Hook("fprint", function(um)
	fprint(um:ReadString())
end)


local FALCO_CHATCOMMANDS = {}

function falco_addchatcmd(text, func)
	FALCO_CHATCOMMANDS[text] = func
end

local function FALCO_CHAT2(ply, text, teamonly, dead)
	if ply ~= LocalPlayer() then return end
	cansay = false
	timer.Simple(2.1, function() cansay = true end)
	for k,v in pairs(FALCO_CHATCOMMANDS) do
		if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then
			v(string.sub(text, string.len(k) + 2))
			break
		elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
			v(string.sub(text, string.len(k) + 8))
		end
	end
end
hook.Add( "OnPlayerChat", "Falco_chatter", FALCO_CHAT2)

--Reload itself
local function ReloadScripts()
	include("autorun/client/falcoprivateutilities.lua")
	hook.Call("InitPostEntity")
end
falco_addchatcmd("Falco_ReloadScripts", ReloadScripts)
falco_addchatcmd("FReloadScripts",  ReloadScripts)
concommand.Add("Falco_ReloadScripts", ReloadScripts)
concommand.Add("FReloadScripts", ReloadScripts)

function fnotify(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if FPP then FPP.AddNotify(text, true) return end
	if GAMEMODE.IsSandboxDerived then -- in some gamemodes GAMEMODE:AddNotify() doesn't exist
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound("ambient/water/drip2.wav") -- I don't care about the other drips so no difficult concatenations or something
	end
end

function Falco_FindPlayer(info)
	local pls = player.GetAll()

	-- Find by Index Number (status in console)
	for k, v in pairs(pls) do
		if tonumber(info) == v:UserID() then
			return v
		end
	end

	-- Find by RP Name
	for k, v in pairs(pls) do
		if v.DarkRPVars and string.find(string.lower(v.DarkRPVars.rpname or ""), string.lower(tostring(info))) ~= nil then
			return v
		end
	end

	-- Find by Partial Nick
	for k, v in pairs(pls) do
		if string.find(string.lower(v:Name()), string.lower(tostring(info))) ~= nil then
			return v
		end
	end
	return nil
end

hook.Add("OnPlayerChat", "Falco_chat", function(ply, text, teamonly, dead)
	if ply == LocalPlayer() and string.sub(text, 1,1) == ";" then
		RunString(string.sub(text, 2))
	end
end)

local files, folders = file.Find("lua/falcoprivate/*.lua", "GAME")
for k, v in pairs(files) do
	include("falcoprivate/" .. v)
end


local LogConCommands = CreateClientConVar("falco_logconcommands", 0, true, false)
local OldConsoleCommand = RunConsoleCommand
function RunConsoleCommand(...)
	local args = {...}
	if LogConCommands:GetInt() == 1 then
		print(debug.traceback())
		chat.AddText(Color(255,0,0,255), table.concat(args, " "))
	end
	if ... then
		OldConsoleCommand(...)
	end
end

local oldrun = concommand.Run
function concommand.Run(ply, command, args)
	if LogConCommands:GetInt() == 1 then
		print(debug.traceback())
		chat.AddText(Color(255,0,0,255), command)
	end
	oldrun(ply,command,args)
end

local oldinclude = include
local BlockMOTD = CreateClientConVar("falco_blockmotd", 1, true, false)
function include(File)
	if string.find(string.lower(File), "cl_utime") then return end
	if LogConCommands:GetInt() == 1  then
		print("include:", File)
	end

	if BlockMOTD:GetInt() == 1 and string.find(string.lower(File), "motd") and not string.find(string.lower(File), "fadmin") then
		error("BLOCKED MOTD FILE BY FPtje's awesome scripts!! "..File, 0)
		return
	end
	if string.find(string.lower(File), "falco/") then
		return
	end
	oldinclude(File)
end
if ulx then ulx.showMotdMenu = function() end end

-- Anti grapplehook error system. Because the maker of the grappelhook doesn't fix it himself.
local ENTITY = FindMetaTable("Entity")
ENTITY.oldgetattachment = ENTITY.oldgetattachment or ENTITY.GetAttachment
function ENTITY:GetAttachment(...)
	if not self.oldgetattachment then return {Pos = Vector(0,0,0)} end
	if self:GetClass() == "grapplehook" and not self:oldgetattachment(...) then return {Pos = Vector(0,0,0)} end
	--print(self.oldgetattachment)
	return self:oldgetattachment(...)
end

hook.Add("InitPostEntity", "LolDisableGag", function()
	timer.Simple(5, function()
		if ulx then function ulx.gagUser() fprint("Gag attempt") end end
		if hook.GetTable().HUDPaint then hook.Remove("HUDPaint","drawHudVital") end
		if hook.GetTable().CalcView then hook.Remove("CalcView", "CalcView") end
	end)
	-- Popup when I die
	concommand.Remove("NLRDeathMessage")
	concommand.Remove("OpenMotd") -- Evolve's shitty MOTD
	concommand.Remove("wesnlr") -- shitty NLR
	concommand.Remove("nlr_box")
	concommand.Add("wesnlr", function() RunConsoleCommand("wesspawn") end)
	concommand.Remove("EasyMOTD_Open") -- another shitty MOTD
	if hook.GetTable().HUDPaint then hook.Remove("HUDPaint", "FlashEffect") end -- Annoying flash effect
	if hook.GetTable().RenderScreenspaceEffects then hook.Remove("RenderScreenspaceEffects", "StunEffect") end
end)


concommand.Add("wire_keyboard_press", function() end)

local meta = FindMetaTable("Player")
function meta:CheckGroup( group_check )
	if not ULib.ucl then return false end
	if not ULib.ucl.groups[ group_check ] then return false end
	local group = self:GetUserGroup()
	if not ULib.ucl.groups[ group ] then return false end
	while group do
		if group == group_check then return true end
		group = ULib.ucl.groupInheritsFrom( group )
	end

	return false
end

function debug.getupvalues(f)
	local t, i, k, v = {}, 1, debug.getupvalue(f, 1)
	while k do
		t[k] = v
		i = i+1
		k,v = debug.getupvalue(f, i)
	end
	return t
end

--[[
--local CLUndos = debug.getupvalues(debug.getupvalues(debug.getupvalues(undo.SetupUI).CPanelUpdate).UpdateUI).ClientUndos
function undo.GetTable()-- Thanks deco da man
	return debug.getupvalues(debug.getupvalues(debug.getupvalues(undo.SetupUI).CPanelUpdate).UpdateUI).ClientUndos
end]]

timer.Simple(5, function() timer.Destroy("UTimeThink") end)

hook.Add("InitPostEntity", "PhysgunPickup", function()
	hook.Add("PhysgunPickup", "FPP_CL_PhysgunPickup", function(ply, ent)
		if not ent.IsMine then return false end
	end)--This looks weird, but whenever a client touches an ent he can't touch, without the code it'll look like he picked it up. WITH the code it really looks like he can't
	-- besides, when the client CAN pick up a prop, it also looks like he can.

	usermessage.Hook("EV_Notification", function() end) -- Fucking adverts
	hook.Remove("HUDPaint", "UpdateTimeHUD") -- Fucking rank mod
end)

timer.Simple(10, function() concommand.Remove("DrawDeathMsg") end)

hook.Add("ChatText", "RemoveSpawnIcon", function(idx, name, text, MessageType)
	if string.match(text, "Generated Spawn Icon .+ left in queue.") then return true end
	if text == "Item is protected!" or text == "[UCL] Access set." then print(text) return true end
	if string.find(text, "This server is running ULX Admin") then print(text) return true end
	if rp_languages and rp_languages[GetConVarString("rp_language")] and rp_languages[GetConVarString("rp_language")].hints
	and (table.HasValue(rp_languages[GetConVarString("rp_language")].hints, text) or table.HasValue(rp_languages[GetConVarString("rp_language")].hints, name)) then
		return true
	end
	if string.match(text, "Welcome to .+ We're playing .+\\.") then print(text) return true end
end)

local oldChatAddText = chat.AddText
local oldChatPlaySound = chat.PlaySound

function chat.AddText(color, text, ...)
	if LANGUAGE and LANGUAGE.hints and table.HasValue(LANGUAGE.hints, text) then
		chat.PlaySound = function() end
		print("Blocked: ", text)
		return
	end
	chat.PlaySound = oldChatPlaySound
	oldChatAddText(color, text, ...)
end

local OldGetConVarNumber = GetConVarNumber
function GetConVarNumber(convar, ...)
	return (convar == "globalshow" and 0) or OldGetConVarNumber(convar, ...)
end

timer.Simple(1, function() hook.Call("InitPostEntity") end)