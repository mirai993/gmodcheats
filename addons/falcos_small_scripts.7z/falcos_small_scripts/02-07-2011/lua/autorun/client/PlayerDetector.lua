local RadiusMode = false
//local detectmode = false
local detectors = {}
local NaarBeeldscherm = _R.Vector.ToScreen
//local DrawRadius = false
surface.CreateFont( "coolvetica", 32, 500, true, false, "FdetectorFont1" )
local FDetDoSay = CreateClientConVar("FDet_DoSay", 0, true, false)
local stopsay = false

local ChatTime = 2.1
local cansay = true
function SayShit(text)
	if cansay then
		//print("cansay")
		LocalPlayer():ConCommand("say " .. tostring(text))
		cansay = false
		timer.Simple(ChatTime, function() cansay = true end)
	elseif not cansay then
		//print("not cansay")
		if not stopsay then
			timer.Simple(0.1, SayShit, text) // just try again after 0.1 second :) 
		end
	end
end

function SetCanSay(id, name, text)
	if player.GetByID(id) == LocalPlayer() then
		cansay = false
		timer.Simple(2.1, function() cansay = true end)
	end	
end
hook.Add( "ChatText", "FResetCanSay", SetCanSay)

local function MakeDetector(ply, cmd, args)
	local center = ents.Create("prop_physics")
	center:SetPos(LocalPlayer():GetShootPos()--[[  - Vector(0,0,32) ]])
	center:SetModel("models/Items/AR2_Grenade.mdl")
	center:Spawn()
	LocalPlayer():ChatPrint("Select radius(use mouse button)")
	RadiusMode = true
	table.insert(detectors, center)
	detectors[table.Count(detectors)].pozizion = LocalPlayer():GetShootPos() - Vector(0,0,32)
	detectors[table.Count(detectors)].Entities = {}
	detectors[table.Count(detectors)].DrawRadius = false
	detectors[table.Count(detectors)].detectmode = false
	
	hook.Add("HUDPaint", "RadiusFDetector", function() 
		local trace = LocalPlayer():GetEyeTrace()
		local distance = center:GetPos():Distance(trace.HitPos)
		draw.DrawText(tostring(math.floor(distance)), "FdetectorFont1", ScrW() / 2, ScrH() / 2, Color(255,255,255,255), 1)
	end)
	
	if args[1] ~= nil then
		detectors[table.Count(detectors)].Naam = tostring(table.concat(args, " "))
	else
		detectors[table.Count(detectors)].Naam = "your detector"
	end
end
concommand.Add("FDetector",MakeDetector)

local function removedetectors()
	RadiusMode = false
	if detectors[table.Count(detectors)]:IsValid() then
		detectors[table.Count(detectors)]:Remove()
		table.remove(detectors, table.Count(detectors))
	end
	stopsay = true
	timer.Simple(2, function() stopsay = false end)
--[[ 	for k,v in pairs(detectors) do 
		v:Remove() 
		table.remove(detectors, k)
	end
 ]]	LocalPlayer():ChatPrint("Last detector removed")
end	
concommand.Add("FRemoveDetector",removedetectors)

local function RadiusSelection(ply, bind, pressed)
	if RadiusMode and ply == LocalPlayer() and pressed then
		if string.find(bind, "attack") then
			hook.Remove("HUDPaint", "RadiusFDetector")
			local trace = LocalPlayer():GetEyeTrace()
			detectors[table.Count(detectors)].radius = detectors[table.Count(detectors)]:GetPos():Distance(trace.HitPos)
			RadiusMode = false
			LocalPlayer():ChatPrint("Radius selected: " .. tostring(detectors[table.Count(detectors)].radius))
			detectors[table.Count(detectors)].detectmode = true
			return true
		end	
	end
end
hook.Add("PlayerBindPress", "Radiusselection", RadiusSelection)

local function DrawRadius()
	//print(v:GetPos(), v:GetPos() + Vector(v.radius, 0,0))
	for k,v in pairs(detectors) do
		//print(v.DrawRadius)
		if v.DrawRadius == true then
			surface.SetDrawColor(255,0,0,255)
			local pos1_1 = NaarBeeldscherm(v:GetPos() + Vector(v.radius, 0,0))
			local pos1_2 = NaarBeeldscherm(v:GetPos() - Vector(v.radius, 0,0))
			
			local pos2_1 = NaarBeeldscherm(v:GetPos() + Vector(0, v.radius,0))
			local pos2_2 = NaarBeeldscherm(v:GetPos() - Vector(0, v.radius,0))
			
			local pos3_1 = NaarBeeldscherm(v:GetPos() + Vector(0,0,v.radius))
			local pos3_2 = NaarBeeldscherm(v:GetPos() - Vector(0,0,v.radius))
			surface.DrawLine(pos1_1.x, pos1_1.y, pos1_2.x, pos1_2.y )
			surface.DrawLine(pos2_1.x, pos2_1.y, pos2_2.x, pos2_2.y )
			surface.DrawLine(pos3_1.x, pos3_1.y, pos3_2.x, pos3_2.y )
		end
	end
end
hook.Add("HUDPaint", "DrawRadiusOfDetectors", DrawRadius)

local function ThinkFunction()
	//if detectmode then
		local sound1 = Sound("ambient/alarms/siren.wav" )
		local sound = CreateSound(LocalPlayer(), sound1)
		for num, center in pairs(detectors) do
			if not center:IsValid() then return end
			center:SetPos(center.pozizion)
			if center.detectmode then
				local trace = {}
				trace.start = LocalPlayer():GetShootPos()
				trace.endpos = center.pozizion
				trace.filter = LocalPlayer()
				trace.mask = -1
				local TheTrace = util.TraceLine(trace)
				if TheTrace.Hit then
					center.DrawRadius = false
				else
					center.DrawRadius = true
				end
				
				for k,v in pairs(center.Entities) do
					if not table.HasValue(ents.FindInSphere( center:GetPos(), center.radius), v) then 
						table.remove(center.Entities, k)
					end
				end
				for k,v in pairs(ents.FindInSphere( center:GetPos(), center.radius)) do
					if v:GetClass() ==  "prop_physics" and not table.HasValue(center.Entities, v)  then
						table.insert(center.Entities, v)
						GAMEMODE:AddNotify(v:GetModel() .. " has entered " .. center.Naam, 1, 5 )

						local text = tostring(v:GetModel() .. " has entered " .. center.Naam)
						
						sound:Play()
						timer.Simple(1, function() sound:Stop() end)
						if v:GetNetworkedString("Owner") ~= "" then
							GAMEMODE:AddNotify("Prop belongs to: " .. v:GetNetworkedString("Owner"), 1, 5)
							text = tostring(v:GetModel() .. " of " .. v:GetNetworkedString("Owner") .. " has entered " .. center.Naam)
						elseif (ASS_PP_GetOwner and ASS_PP_GetOwner(v):IsValid()) then
							GAMEMODE:AddNotify("Prop belongs to: " .. ASS_PP_GetOwner(v):Nick(), 1, 5)
							text = tostring(v:GetModel() .. " of " .. ASS_PP_GetOwner(v):Nick() .. " has entered " .. center.Naam)
						end
						
						if FDetDoSay:GetInt() == 1 then
							SayShit(text)
						end
					elseif v:GetClass() == "player" and not table.HasValue(center.Entities, v) then
						table.insert(center.Entities, v)
						if v == LocalPlayer() then
							surface.PlaySound("buttons/button14.wav")
						else
							sound:Play()
							timer.Simple(1, function() sound:Stop() end)
							GAMEMODE:AddNotify(v:Nick() .. " has entered " ..  center.Naam, 1, 5 )
							
							if FDetDoSay:GetInt() == 1 then
								SayShit(tostring(v:Nick() .. " has entered " ..  center.Naam))
							end
						end
					elseif v:GetClass() ~= "player" and v:GetClass() ~= "worldspawn" and v:GetClass() ~= "prop_physics" and not v:IsWeapon() and v:GetClass() ~= "viewmodel"  and not table.HasValue(center.Entities, v) then
						table.insert(center.Entities, v)
						GAMEMODE:AddNotify(v:GetClass() .. " has entered " .. center.Naam, 1, 5)
						
						if FDetDoSay:GetInt() == 1 then
							SayShit(tostring(v:GetClass() .. " has entered " .. center.Naam))
						end

						timer.Simple(1, function() sound:Stop() end)
						sound:Play()
					end
				end
			end
		end
	//end
end
hook.Add("Think", "PlayerDetection", ThinkFunction)

local function PlayerDetector(id, name, text)
	if  LocalPlayer() == player.GetByID(id) then
		if string.lower(string.sub(text, 1, 9)) == "fdetector"  then
			LocalPlayer():ConCommand("FDetector " .. string.sub(text, 11))
		elseif string.lower(string.sub(text, 1, 4)) == "fdet"  then
			LocalPlayer():ConCommand("FDetector " .. string.sub(text, 6))
		elseif string.lower(text) == "fremovedetector" or string.lower(text) == "fremdet" then
			LocalPlayer():ConCommand("FRemoveDetector")
		end
	end
end
hook.Add( "ChatText", "PlayerDetector", PlayerDetector )