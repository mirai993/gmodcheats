local PlayersHaveVoted = {}
local IsVoting = false
local ChatTime = 2.1
local VoteResults = {}

VoteResults.yes = 0
VoteResults.no = 0

local function StartVote(id, name, text)
	if  LocalPlayer() == player.GetByID(id) and string.sub(string.lower(text), 1, 5) == "fvote" then
		IsVoting = true
		local text = string.sub(text, 7)
		timer.Simple(ChatTime, SayShit,"Falcovote: \"" .. text .. "\" Vote by saying !yes or !no")
		timer.Create("FVote", 60, 1, StopFalcoVote)
	end
end
hook.Add( "ChatText", "FVoteStart", StartVote)

local cansay = true
local function SayShit(text)
	if cansay then
		//print("cansay")
		LocalPlayer():ConCommand("say " .. tostring(text))
		cansay = false
		timer.Simple(ChatTime, function() cansay = true end)
	elseif not cansay then
		//print("not cansay")
		timer.Simple(0.1, SayShit, text) // just try again after 0.1 second :) 
	end
end

local function GetVotes(id, name, text)
	if player.GetByID(id) ~= LocalPlayer() and IsVoting and not table.HasValue(PlayersHaveVoted, id) then
		if string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") then
			table.insert(PlayersHaveVoted, id)
			VoteResults.yes = VoteResults.yes + 1
			SayShit("'" ..tostring( player.GetByID(id):Nick()) .. "' voted yes")
		elseif string.find(string.lower(text), "!no") or string.find(string.lower(text), "!no") then
			table.insert(PlayersHaveVoted, id)
			VoteResults.no = VoteResults.no + 1
			SayShit("'" .. tostring(player.GetByID(id):Nick()) .. "' voted no") 
		end
		if VoteResults.no + VoteResults.yes == #player.GetAll() - 1 then
			timer.Remove("FVote")
			StopFalcoVote()
		end
	elseif player.GetByID(id) ~= LocalPlayer() and IsVoting and table.HasValue(PlayersHaveVoted, id) and ( string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") or string.find(string.lower(text), "!no") or string.find(string.lower(text), "!no")) then
		SayShit("'" ..tostring( player.GetByID(id):Nick()) .. "' already voted. Can't vote twice")
	elseif player.GetByID(id) == LocalPlayer() and IsVoting then
		cansay = false
		timer.Simple(2.1, function() cansay = true end)
	end	
end
hook.Add( "ChatText", "FGetVotes", GetVotes)

function StopFalcoVote()
	IsVoting = false
	SayShit("The vote has stopped, These are the results:")
	if VoteResults.yes > VoteResults.no then 
		addition = "option yes won"
	elseif VoteResults.yes == VoteResults.no then
		addition = "no option won"
	elseif VoteResults.yes < VoteResults.no then
		addition = "option no won"
	end
	
	if VoteResults.yes == VoteResults.no and VoteResults.yes == 0 then
		addition = "Nobody voted :("
	end
	SayShit("Yes: " .. tostring(VoteResults.yes) .. ", no: " .. tostring(VoteResults.no) .. "    " ..  addition)
	VoteResults.yes = 0
	VoteResults.no = 0
	PlayersHaveVoted = {}
end
