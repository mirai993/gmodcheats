local enabled = CreateClientConVar("FArrestBatonWarning", 0, true, false)

local waits = {}
local cansay = true
local function SayTehShit(text)
	if cansay then
		//print("cansay")
		LocalPlayer():ConCommand("say " .. tostring(text))
		cansay = false
		timer.Simple(2.1, function() cansay = true end)
	elseif not cansay then
		//print("not cansay")
		timer.Simple(0.1, SayTehShit, text) // just try again after 0.1 second :) 
	end
end

local function TheCanSayThingInWeaponWarning(ply)
	if player.GetByID(id) == LocalPlayer() then
		cansay = false
		timer.Simple(2.2, function() cansay = true end)
	end	
end
hook.Add( "ChatText", "TheCanSayThingInWeaponWarning", TheCanSayThingInWeaponWarning)

local function getAllWeapons()
	if enabled:GetInt() == 1 then
		for k,v in pairs(player.GetAll()) do
			if ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() == "arrest_stick" and not waits[v] then
				SayTehShit(v:Nick() .. " pulled out his arrest baton")
				waits[v] = true
			elseif ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() ~= "arrest_stick" and waits[v] then
				waits[v] = false
			end
		end
	end
end
hook.Add("Think", "ArrestBatonAlert", getAllWeapons)