//local PoKiRayOn = CreateClientConVar("PoKiRayOn", 0, false, true)
local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local function TogglePoKiRay()
	if RayOn then
		surface.PlaySound("buttons/button19.wav") 
		for k,v in pairs(ents.GetAll()) do
			FSetMat(v, AllMats[v])
			//print(allcolors[v])
			local z = allcolors[v]
			if type(allcolors[v]) == "number" then print(v, v:GetClass()) end
			FSetColor(v, z.r, z.g, z.b, z.a)
		end
	else
		for k,v in pairs(ents.GetAll()) do
			allcolors[v] = v:GetColor()
		end
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("ToggleFRay", TogglePoKiRay)

function DoPoKiRay()
	if not RayOn then return end
	for k,v in pairs(ents.GetAll()) do
		local r,g,b,a = v:GetColor()
		if v:IsPlayer() and (r ~= 255 or g ~= 0 or b ~= 0 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v,255,0,0,255)
		elseif v:IsNPC() and (r ~= 0 or g ~= 255 or b ~= 0 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			//print(allcolors[v])
			FSetColor(v, 0, 255, 0, 255)
		elseif v:GetClass() == "prop_physics" and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 70) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, 0, 0, 255, 70)
		elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, 140, 0, 255, 255)
		elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, 0, 0, 0, 30)
		elseif not v:IsPlayer() and not v:IsNPC() and v:GetClass() ~= "prop_physics" and not v:IsWeapon() and v:GetClass() ~= "viewmodel" and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
			allcolors[v] = Color(r,g,b,a)
			FSetColor(v, 255, 200, 0, 100)
		end
		if v:GetClass() ~= "viewmodel" and v:GetMaterial() ~= "PoKiRayMat" then
			AllMats[v] = v:GetMaterial()
			FSetMat(v, "PoKiRayMat")
		end
		
	end
end
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)

local ColorMod ={}
ColorMod[ "$pp_colour_addr" ] = 0
ColorMod[ "$pp_colour_addg" ] = 0
ColorMod[ "$pp_colour_addb" ] = 0
ColorMod[ "$pp_colour_brightness" ] = -0.1
ColorMod[ "$pp_colour_contrast" ] = 1
ColorMod[ "$pp_colour_colour" ] = 1
ColorMod[ "$pp_colour_mulr" ] = 0
ColorMod[ "$pp_colour_mulg" ] = 0
ColorMod[ "$pp_colour_mulb" ] = 0

local function ChangeColours()
	if not RayOn then return end
	DrawColorModify( ColorMod ) 
end
hook.Add( "RenderScreenspaceEffects", "PoKiRayColour", ChangeColours)
//hook.Remove( "RenderScreenspaceEffects", "PoKiRayColour")