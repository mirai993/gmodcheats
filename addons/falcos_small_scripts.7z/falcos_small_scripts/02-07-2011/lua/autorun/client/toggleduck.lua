local toggle = false

local function toggleduck()
	if not toggle then	
		RunConsoleCommand("+duck")
	else
		RunConsoleCommand("-duck")
	end
	toggle = not toggle
end
concommand.Add("toggleduck", toggleduck)

local Btoggle = false

local function togglevoicerecord()
	if not Btoggle then	
		RunConsoleCommand("+voicerecord")
	else
		RunConsoleCommand("-voicerecord")
	end
	Btoggle = not Btoggle
end
concommand.Add("togglevoice", togglevoicerecord)