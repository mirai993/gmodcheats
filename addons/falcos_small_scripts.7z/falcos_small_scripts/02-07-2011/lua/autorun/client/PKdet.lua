local wait = false
local enabled = CreateClientConVar("FPropKillDetector", 0, true, false)
function GetPropKiller()
	if enabled:GetInt() == 1 then
		if not LocalPlayer():Alive() and not wait then
			wait = true
			for k,v in pairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 100)) do
				//print(v:GetClass())
				if v:GetClass() == "prop_physics" and v:GetNWString("Owner") ~= "" and v:GetNWString("Owner") ~= LocalPlayer():Nick() then
					LocalPlayer():ChatPrint(v:GetNWString("Owner") .. "could have killed you")
				end
			end
			//LocalPlayer():ChatPrint("I died")
		elseif LocalPlayer():Alive() and wait then
			wait = false
			//LocalPlayer():ChatPrint("I spawned")
		end
	end
end
hook.Add("Think", "GetPropKiller", GetPropKiller)