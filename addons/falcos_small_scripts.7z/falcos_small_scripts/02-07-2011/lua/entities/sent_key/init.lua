ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "key"
ENT.Author			= "FPtje"
ENT.Information		= "none"
ENT.Category		= "Fun + Games"
ENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

//local zelf 

function ENT:SpawnFunction( ply, tr ) 
   
 	if ( !tr.Hit ) then return end 
 	 
 	local SpawnPos = tr.HitPos + tr.HitNormal * 16 
 	 
 	local ent = ents.Create( "sent_key" ) 
 	ent:SetPos( SpawnPos ) 
 	ent:Spawn() 
 	ent:Activate() 
 	 
 	return ent 
 	 
end 

function FSpawnPianoKey(pos, args, color, parent)
	local ent = ents.Create( "sent_key" ) 
	ent:SetPos( pos ) 
	ent:SetAngles(Angle(0,90,0))
 	ent:Spawn() 
 	ent:Activate() 
	//ent:SetMoveType(MOVETYPE_NONE)
	ent.sound = args.sound
	ent.pitch = args.pitch
	ent:SetColor(color.r, color.b, color.g, color.a)
	//ent:SetParent(parent)
	return ent
	//constraint.Weld(ent,parent,0,0,0, true)
end


function ENT:Initialize() 
	self.Entity:SetModel( "models/props_trainstation/traincar_rack001.mdl" )
	//self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )
	--[[local phys = self.Entity:GetPhysicsObject() 
	if phys:IsValid() then
		phys:Wake()
	end]]
	self.Entity:SetMoveType( MOVETYPE_NONE ) 
end 

function ENT:OnTakeDamage(dmg)
	if not self.Entity:IsValid() then return end
	local r,g,b,a = self.Entity:GetColor()
	self.Entity:EmitSound(self.Entity.sound, 500, self.Entity.pitch)
	if r==255 and g == 0 and b == 0 and a == 255 then
		return
	elseif r==0 and g == 0 and b == 255 and a == 255 then
		return
	end
	
	if r==0 and g == 0 and b == 0 and a == 255 then
		self.Entity:SetColor(0,0,255,255)
	else
		self.Entity:SetColor(255,0,0,255)
	end
	timer.Simple(0.5, function() self.Entity:SetColor(r, g, b, a ) end)
end