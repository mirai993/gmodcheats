ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "key"
ENT.Author			= "FPtje"
ENT.Information		= "none"
ENT.Category		= "Fun + Games"
ENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

include( "shared.lua" )
 