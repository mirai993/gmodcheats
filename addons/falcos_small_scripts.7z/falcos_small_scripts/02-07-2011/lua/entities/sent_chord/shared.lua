ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "chord"
ENT.Author			= "FPtje"
ENT.Information		= "none"
ENT.Category		= "Fun + Games"
ENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

/*
function ENT:Initialize() 
	self.Entity:SetModel( "models/props_trainstation/traincar_rack001.mdl" )
end /*