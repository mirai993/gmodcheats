ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Piano"
ENT.Author			= "FPtje"
ENT.Information		= "none"
ENT.Category		= "Fun + Games"
ENT.RenderGroup 	= RENDERGROUP_TRANSLUCENT



ENT.Spawnable			= true
ENT.AdminSpawnable		= true
if CLIENT then
	language.Add ("Undone_Piano", "You just removed your piano!") 
end