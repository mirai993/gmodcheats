include('shared.lua')

SWEP.PrintName = "Piano player"
SWEP.Slot = 5
SWEP.SlotPos = 6
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false 