   AddCSLuaFile( "cl_init.lua" )
   AddCSLuaFile( "shared.lua" )
   include('shared.lua')
  
   SWEP.Weight = 0
   SWEP.AutoSwitchTo = true
   SWEP.AutoSwitchFrom = true 