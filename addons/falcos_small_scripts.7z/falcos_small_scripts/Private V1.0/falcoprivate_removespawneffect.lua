--[[
	MOD/lua/autorun/falcoprivate/lua_falcoprivate_removespawneffect.lua [#731 (#753), 4227894405]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 04:00:19PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Removes the spawn effect of props
---------------------------------------------------------------------------*/

if SERVER then
	AddCSLuaFile("cl_OverridePropEffect.lua")
	return
end

local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)
