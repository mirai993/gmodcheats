--[[
	MOD/lua/autorun/falcoprivate/lua_falcoprivate_hitmarker.lua [#1320 (#1344), 3243622524]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 04:00:08PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Shows you when the prop you're holding is close to another player
---------------------------------------------------------------------------*/

local HitMarker = CreateClientConVar("falco_hitmarker", 1, true, false)

local Size = 25
local Alpha = 0
hook.Add("HUDPaint", "HitMarker", function()
	if not tobool(HitMarker:GetInt()) then return end
	if not IsValid(LocalPlayer().IsHolding) or LocalPlayer().IsHolding:GetClass() ~= "prop_physics" or not LocalPlayer().IsHolding.IsMine or not input.IsMouseDown(MOUSE_FIRST) then return end

	Alpha = (Alpha + 4) % 255

	local ScrHeight, ScrWidth = ScrH(), ScrW()
	for k,v in pairs(player.GetAll()) do
		if LocalPlayer().IsHolding:GetPos():Distance(v:GetShootPos()) <= 220 and v ~= LocalPlayer() and v:Alive() then
			surface.SetDrawColor(255,255,255, Alpha)
			surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2 - Size, ScrWidth/2 - Size * 2, ScrHeight/2 - Size * 2)
			surface.DrawLine(ScrWidth/2 - Size, ScrHeight/2 + Size, ScrWidth/2 - Size * 2, ScrHeight/2 + Size * 2)
			surface.DrawLine(ScrWidth/2 + Size, ScrHeight/2 - Size, ScrWidth/2 + Size * 2, ScrHeight/2 - Size * 2)
			surface.DrawLine(ScrWidth/2 + Size, ScrHeight/2 + Size, ScrWidth/2 + Size * 2, ScrHeight/2 + Size * 2)
		end
	end
end)