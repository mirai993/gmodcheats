--[[
	MOD/lua/autorun/falcoprivate/lua_falcoprivate_rp_vote.lua [#660 (#684), 483709462]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 04:00:20PM]
	===BadFile===
]]

DoVoteAnswerQuestion = DoVoteAnswerQuestion or function(ply, cmd, args)
	if not args[1] or not VoteVGUI then return end
	
	local vote = 2
	if tonumber(args[1]) == 1 or string.lower(args[1]) == "yes" or string.lower(args[1]) == "true" then vote = 1 end
	
	for k,v in pairs(VoteVGUI) do
		if ValidPanel(v) then
			local ID = string.sub(k, 1, -5)
			VoteVGUI[k]:Close()
			RunConsoleCommand("vote", ID, vote)
			return
		end
	end
	
	for k,v in pairs(QuestionVGUI) do
		if ValidPanel(v) then
			local ID = string.sub(k, 1, -5)
			QuestionVGUI[k]:Close()
			RunConsoleCommand("ans", ID, vote)
			return
		end
	end
end
concommand.Add("rp_vote", DoVoteAnswerQuestion)