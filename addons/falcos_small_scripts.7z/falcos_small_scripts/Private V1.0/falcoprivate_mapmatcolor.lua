--[[
	MOD/lua/autorun/falcoprivate/lua_falcoprivate_mapmatcolor.lua [#2566 (#2629), 2123998117]
	wegweg | STEAM_0:1:9769081 <90.184.179.6:1024> | [29.12.13 04:00:12PM]
	===BadFile===
]]

function Falco_GetMapMats()
	local mats = table.Copy(FALCO_MAPMATS.ALL)
	if FALCO_MAPMATS[string.lower(game.GetMap())] then
		for k,v in pairs(FALCO_MAPMATS[string.lower(game.GetMap())]) do
			mats[k] = v
		end
	end
	return mats
end

local UsedMats = {}
function Falco_MapMat(texture, color)
	local Mat = UsedMats[string.lower(texture)] or Material(texture)
	UsedMats[string.lower(texture)] = UsedMats[string.lower(texture)] or Mat
	if Mat:IsError() then fprint(texture) return end
	Mat:SetMaterialVector("$color", Vector(color.r, color.g, color.b))
	Mat:SetMaterialFloat("$alpha", color.a)
end

local function SetMapMatColour(ply, cmd, args)
	local texture = Material(LocalPlayer():GetEyeTrace().HitTexture)
	texture:SetMaterialVector("$color", Vector(args[1] or 255, args[2] or 255, args[3] or 255, args[4]))
	texture:SetMaterialFloat("$alpha", tonumber(args[4]) or 1)
end
concommand.Add("falco_SetMapMatColor", SetMapMatColour)

local function AddMapColour(ply, cmd, args)
	local texture = string.lower(LocalPlayer():GetEyeTrace().HitTexture)
	local color = "Color("..(args[1] or 1) ..", ".. (args[2] or 1) ..", ".. (args[3] or 1) ..", ".. (args[4] or 1) ..")"
	local File = file.Read("MapMats.txt") or "{\n"
	local COLOR = Color(tonumber(args[1]) or 1, tonumber(args[2]) or 1, tonumber(args[3]) or 1, tonumber(args[4]) or 1)
	Falco_MapMat(LocalPlayer():GetEyeTrace().HitTexture, COLOR)
	
	if FALCO_MAPMATS[texture] or FALCO_MAPMATS.ALL[texture] or (FALCO_MAPMATS[string.lower(game.GetMap())] and FALCO_MAPMATS[string.lower(game.GetMap())][texture]) then return end
	FALCO_MAPMATS[texture] = COLOR
	
	file.Write("MapMats.txt", File.."[\""..texture.."\"] = "..color..",\n")
end
concommand.Add("falco_Addmapmatcolour", AddMapColour)

local sky = {
	"BK", "FT", -- Back, front
	"UP", "DN", -- Up, down
	"RT", "LF" -- Right, left
}
local curSky = GetConVar( "sv_skyname" ):GetString()
local SkyMats = {}
function Falco_ChangeSkyColor(col)
	for _, nm in pairs( sky ) do
		local SkyMat = SkyMats["skybox/" .. curSky .. nm] or Material( "skybox/" .. curSky .. nm )
		SkyMats["skybox/" .. curSky .. nm] = SkyMats["skybox/" .. curSky .. nm] or SkyMat
		SkyMat:SetMaterialVector("$color", Vector(col.r, col.g, col.b))
		SkyMat:SetMaterialFloat("$alpha", col.a)
	end
end

function Falco_ChangeSkyMaterial(mat)
	for _, nm in pairs( sky ) do
		local SkyMat = SkyMats["skybox/" .. curSky .. nm] or Material( "skybox/" .. curSky .. nm )
		SkyMats["skybox/" .. curSky .. nm] = SkyMats["skybox/" .. curSky .. nm] or SkyMat

		SkyMat:SetMaterialString("$basetexture", mat)
	end
end