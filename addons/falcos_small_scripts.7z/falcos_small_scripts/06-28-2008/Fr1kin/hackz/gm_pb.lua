/*
__________                       .__       .__             ___.           __   
\______   \_______   ____   ____ |__| _____|__| ____   ____\_ |__   _____/  |_ 
 |     ___/\_  __ \_/ __ \_/ ___\|  |/  ___/  |/  _ \ /    \| __ \ /  _ \   __\
 |    |     |  | \/\  ___/\  \___|  |\___ \|  (  <_> )   |  \ \_\ (  <_> )  |  
 |____|     |__|    \___  >\___  >__/____  >__|\____/|___|  /___  /\____/|__|   
                        \/     \/        \/               \/    \/            
-----------------
About:
-----------------
fr1kin's Private GMOD cheat, if you downloaded this it's eather
public or some retard gave it to you. Don't give this to anyone.
-----------------
Changelog: [1.6]
-----------------
New menu.
Added Chams
Added NPC ESP
Updated the autoload file.
Fixed dynamic lights because they where retarted like that.
-----------------
Credits:
-----------------
fr1kin		 - The dude who made the script.
kolbybrooks  - Hook Script
AzuiSleet    - ConVar Bypasser ( Module )
Eusion       - Box Script
Deco         - No-Spread ( Module )
Seth		 - Script Enforcer Bypass ( Module )
-----------------
*/

if ( SERVER ) then return end

if GetConVarNumber( "fr1kincl_enable" ) == 1 then

// Autoload stuff
local version = ( "v1.6" )
print( "\n\nPrecisionbot " .. version .. " loaded!\n\n" )

require( "fuckoff2" )
require( "deco2" )
require( "scriptenforcer2" )

local PB = {}
local hooks = {}

// Protection - Bypasses thirdparty anti-cheats.
function Random()
	local j, r = 0, ""

	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function NewHook( h, f )
	local n = Random()
	hooks[n] = h
	hook.Add( h, n, f )
end

local old_concommand = concommand.Add
local old_cvar 		 = GetConVar
local old_cvarnum 	 = GetConVarNumber
local old_hook 		 = hook.Add
local old_rcc 		 = RunConsoleCommand

// ********************
// Menu VGUI:
// ********************

function menuvgui()
local menu = vgui.Create( "DFrame" )
menu:SetPos( ScrW()/2-250/2,ScrH()/2-500/2 )
menu:SetSize( 250, 500 )
menu:SetTitle( "Precisionbot " .. version )
menu:SetVisible( true )
menu:SetDraggable( true )
menu:ShowCloseButton( true ) 
menu:MakePopup()
menu.Paint = function()
	draw.RoundedBox( 6, 0, 0, 250, 500, Color( 128, 128, 128, 255 ) )
	draw.RoundedBox( 6, 0, 0, 250, 21, Color( 0, 128, 255, 255 ) )
end

local panel = vgui.Create( "DPropertySheet" )
panel:SetParent( menu )
panel:SetPos( 5, 30 )
panel:SetSize( 240, 460 )
panel.Paint = function()
	draw.RoundedBox( 0, 0, 0, 250, 500, Color( 128, 128, 128, 255 ) )
end


// Aimbot
local aimpan = vgui.Create( "DPanel", panel )

local aimmethod = vgui.Create("DLabel", aimpan )
aimmethod:SetPos( 10, 10 )
aimmethod:SetWide( 200 )
aimmethod:SetText( "Aim Method:" )
aimmethod:SetTextColor( Color(255, 0, 0, 255) )

local aimenable = vgui.Create( "DCheckBoxLabel", aimpan )
aimenable:SetText( "Enable" )
aimenable:SetPos( 10, 30 )
aimenable:SetConVar( "" )
aimenable:SetTextColor( Color( 0, 0, 0, 255 ) )
aimenable:SizeToContents()

local aimtypet = vgui.Create("DLabel", aimpan )
aimtypet:SetPos( 10, 50 )
aimtypet:SetWide( 200 )
aimtypet:SetText( "Aim Type:" )
aimtypet:SetTextColor( Color(0, 0, 0, 255) )

local aimtype = vgui.Create( "DMultiChoice", aimpan )
aimtype:SetPos(80, 50)
aimtype:SetSize( 140, 20 )
aimtype:AddChoice("Bone")
aimtype:AddChoice("Vector")
aimtype:AddChoice("Bone Scan")

local aimbyt = vgui.Create("DLabel", aimpan )
aimbyt:SetPos( 10, 80 )
aimbyt:SetWide( 200 )
aimbyt:SetText( "Aim By:" )
aimbyt:SetTextColor( Color(0, 0, 0, 255) )

local aimby = vgui.Create( "DMultiChoice", aimpan )
aimby:SetPos(80, 80)
aimby:SetSize( 140, 20 )
aimby:AddChoice( "Distance" )
aimby:AddChoice( "Crosshair" )
aimby:AddChoice( "Health" )

// Extra Sensory
local esppan = vgui.Create( "DPanel", panel )

local playero = vgui.Create("DLabel", esppan )
playero:SetPos( 10, 10 )
playero:SetWide( 200 )
playero:SetText( "Player Options:" )
playero:SetTextColor( Color(255, 0, 0, 255) )

local name = vgui.Create( "DCheckBoxLabel", esppan )
name:SetText( "Name" )
name:SetPos( 10, 30 )
name:SetConVar( "cl_esp_name" )
name:SetTextColor( Color( 0, 0, 0, 255 ) )
name:SizeToContents()

local health = vgui.Create( "DCheckBoxLabel", esppan )
health:SetText( "Health" )
health:SetPos( 10, 50 )
health:SetConVar( "cl_esp_health" )
health:SetTextColor( Color( 0, 0, 0, 255 ) )
health:SizeToContents()

local weapon = vgui.Create( "DCheckBoxLabel", esppan )
weapon:SetText( "Weapon" )
weapon:SetPos( 10, 70 )
weapon:SetConVar( "cl_esp_weapon" )
weapon:SetTextColor( Color( 0, 0, 0, 255 ) )
weapon:SizeToContents()

local distance = vgui.Create( "DCheckBoxLabel", esppan )
distance:SetText( "Distance" )
distance:SetPos( 10, 90 )
distance:SetConVar( "cl_esp_distnace" )
distance:SetTextColor( Color( 0, 0, 0, 255 ) )
distance:SizeToContents()

local box = vgui.Create( "DCheckBoxLabel", esppan )
box:SetText( "Box" )
box:SetPos( 10, 110 )
box:SetConVar( "cl_esp_box_allow" )
box:SetTextColor( Color( 0, 0, 0, 255 ) )
box:SizeToContents()

function Boxtype()
local chamstype = vgui.Create( "DComboBox", esppan )
chamstype:SetPos( 100, 30 )
chamstype:SetSize( 90, 100 )
chamstype:SetMultiple( false )
local a = chamstype:AddItem( "Box" )
local b = chamstype:AddItem( "Dot" )
local c = chamstype:AddItem( "Cross" )
local d = chamstype:AddItem( "Sized Box" )
if GetConVarNumber( "cl_esp_box" ) == 1 then
chamstype:SelectItem(a)
elseif GetConVarNumber( "cl_esp_box"  ) == 2 then
chamstype:SelectItem(b)
elseif GetConVarNumber( "cl_esp_box"  ) == 3 then
chamstype:SelectItem(c)
elseif GetConVarNumber( "cl_esp_box"  ) == 4 then
chamstype:SelectItem(d)
end
a.DoClick = function() RunConsoleCommand( "cl_esp_box" , 1 ) chamstype:SelectItem(a) end
b.DoClick = function() RunConsoleCommand( "cl_esp_box" , 2 ) chamstype:SelectItem(b) end
c.DoClick = function() RunConsoleCommand( "cl_esp_box" , 3 ) chamstype:SelectItem(c) end
d.DoClick = function() RunConsoleCommand( "cl_esp_box" , 4 ) chamstype:SelectItem(d) end
end
Boxtype()

local npco = vgui.Create("DLabel", esppan )
npco:SetPos( 10, 130 )
npco:SetWide( 120 )
npco:SetText( "NPC Options:" )
npco:SetTextColor( Color(255, 0, 0, 255) )

local npc = vgui.Create( "DCheckBoxLabel", esppan )
npc:SetText( "NPC Name" )
npc:SetPos( 10, 150 )
npc:SetConVar( "cl_esp_npc" )
npc:SetTextColor( Color( 0, 0, 0, 255 ) )
npc:SizeToContents()

local npcm = vgui.Create( "DCheckBoxLabel", esppan )
npcm:SetText( "NPC Marker" )
npcm:SetPos( 10, 170 )
npcm:SetConVar( "cl_esp_npcmarker" )
npcm:SetTextColor( Color( 0, 0, 0, 255 ) )
npcm:SizeToContents()

local entityo = vgui.Create("DLabel", esppan )
entityo:SetPos( 10, 190 )
entityo:SetWide( 220 )
entityo:SetText( "Entity Options:" )
entityo:SetTextColor( Color(255, 0, 0, 255) )

local entitys = vgui.Create( "DCheckBoxLabel", esppan )
entitys:SetText( "Sandbox Entities" )
entitys:SetPos( 10, 210 )
entitys:SetConVar( "cl_esp_sbox" )
entitys:SetTextColor( Color( 0, 0, 0, 255 ) )
entitys:SizeToContents()

local entityr = vgui.Create( "DCheckBoxLabel", esppan )
entityr:SetText( "Roleplay Entities" )
entityr:SetPos( 10, 230 )
entityr:SetConVar( "cl_esp_rp" )
entityr:SetTextColor( Color( 0, 0, 0, 255 ) )
entityr:SizeToContents()

local maxdise = vgui.Create( "DNumSlider", esppan )
maxdise:SetPos( 10, 330 )
maxdise:SetWide( 200 )
maxdise:SetText( "" )
maxdise:SetMin( 0 )
maxdise:SetMax( 50000 )
maxdise:SetDecimals( 0 )
maxdise:SetConVar( "cl_esp_espmaxents" )
	local maxdiste = vgui.Create("DLabel", esppan )
	maxdiste:SetPos( 10, 330 )
	maxdiste:SetWide( 200 )
	maxdiste:SetText( "Max Distance Entitys" )
	maxdiste:SetTextColor( Color(0, 0, 0, 255) )

local maxdis = vgui.Create( "DNumSlider", esppan )
maxdis:SetPos( 10, 380 )
maxdis:SetWide( 200 )
maxdis:SetText( "" )
maxdis:SetMin( 0 )
maxdis:SetMax( 50000 )
maxdis:SetDecimals( 0 )
maxdis:SetConVar( "cl_esp_espmax" )
	local maxdist = vgui.Create("DLabel", esppan )
	maxdist:SetPos( 10, 380 )
	maxdist:SetWide( 200 )
	maxdist:SetText( "Max Distance Players" )
	maxdist:SetTextColor( Color(0, 0, 0, 255) )
	


// Other
local othpan = vgui.Create( "DPanel", panel )

local otherl = vgui.Create("DLabel", othpan )
otherl:SetPos( 10, 10 )
otherl:SetWide( 200 )
otherl:SetText( "Miscellaneous:" )
otherl:SetTextColor( Color(255, 0, 0, 255) )

local crosshair = vgui.Create( "DCheckBoxLabel", othpan )
crosshair:SetText( "Crosshair" )
crosshair:SetPos( 10, 30 )
crosshair:SetConVar( "cl_vis_crosshair"  )
crosshair:SetTextColor( Color( 0, 0, 0, 255 ) )
crosshair:SizeToContents()

local speedvalue = vgui.Create( "DNumSlider", othpan )
speedvalue:SetPos( 10, 90 )
speedvalue:SetWide( 200 )
speedvalue:SetText( "" )
speedvalue:SetMin( .1 )
speedvalue:SetMax( 1 )
speedvalue:SetDecimals( 1 )
speedvalue:SetConVar( "cl_misc_speedvalue" )
	local svlabel = vgui.Create("DLabel", othpan )
	svlabel:SetPos( 10, 90 )
	svlabel:SetText( "Speed Value" )
	svlabel:SetTextColor( Color(0, 0, 0, 255) )

// Dynamic Lighting
local dlsl = vgui.Create("DLabel", othpan )
dlsl:SetPos( 10, 130 )
dlsl:SetWide( 200 )
dlsl:SetText( "Dynamic Lights:" )
dlsl:SetTextColor( Color(255, 0, 0, 255) )

local dynamiclights = vgui.Create( "DCheckBoxLabel", othpan )
dynamiclights:SetText( "All Dynamic Lights" )
dynamiclights:SetPos( 10, 150 )
dynamiclights:SetConVar( "cl_vis_dynamiclights" )
dynamiclights:SetTextColor( Color( 0, 0, 0, 255 ) )
dynamiclights:SizeToContents()

local selfdl = vgui.Create( "DCheckBoxLabel", othpan )
selfdl:SetText( "Self Dynamic Lights" )
selfdl:SetPos( 10, 170 )
selfdl:SetConVar( "cl_vis_dynamiclightsself" )
selfdl:SetTextColor( Color( 0, 0, 0, 255 ) )
selfdl:SizeToContents()

local dlr = vgui.Create( "DNumSlider", othpan )
dlr:SetPos( 10, 190 )
dlr:SetWide( 200 )
dlr:SetText( "" )
dlr:SetMin( 1 )
dlr:SetMax( 1000 )
dlr:SetDecimals( 0 )
dlr:SetConVar( "cl_vis_dynamiclightsrad" )
	local dlrl = vgui.Create("DLabel", othpan )
	dlrl:SetPos( 10, 190 )
	dlrl:SetText( "Radius" )
	dlrl:SetTextColor( Color(0, 0, 0, 255) )

// Chams
local chamsl = vgui.Create("DLabel", othpan )
chamsl:SetPos( 10, 230 )
chamsl:SetText( "Chams:" )
chamsl:SetTextColor( Color(255, 0, 0, 255) )

local chams = vgui.Create( "DCheckBoxLabel", othpan )
chams:SetText( "Chams" )
chams:SetPos( 110, 250 )
chams:SetConVar( "cl_vis_chams" )
chams:SetTextColor( Color( 0, 0, 0, 255 ) )
chams:SizeToContents()

local chamsply = vgui.Create( "DCheckBoxLabel", othpan )
chamsply:SetText( "Include Players" )
chamsply:SetPos( 110, 270 )
chamsply:SetConVar( "cl_vis_chamsplayer" )
chamsply:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsply:SizeToContents()

local chamsn = vgui.Create( "DCheckBoxLabel", othpan )
chamsn:SetText( "Include NPC's" )
chamsn:SetPos( 110, 290 )
chamsn:SetConVar( "cl_vis_chamsnpc" )
chamsn:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsn:SizeToContents()

local chamsw = vgui.Create( "DCheckBoxLabel", othpan )
chamsw:SetText( "Include Weapons" )
chamsw:SetPos( 110, 310 )
chamsw:SetConVar( "cl_vis_chamsweapon" )
chamsw:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsw:SizeToContents()

local chamsr = vgui.Create( "DCheckBoxLabel", othpan )
chamsr:SetText( "Include Ragdolls" )
chamsr:SetPos( 110, 330 )
chamsr:SetConVar( "cl_vis_chamsragdoll" )
chamsr:SetTextColor( Color( 0, 0, 0, 255 ) )
chamsr:SizeToContents()

function Chamtype()
local chamstype = vgui.Create( "DComboBox", othpan )
chamstype:SetPos( 10, 250 )
chamstype:SetSize( 90, 120 )
chamstype:SetMultiple( false )
local a = chamstype:AddItem( "Wireframe" )
local b = chamstype:AddItem( "Soild" )
if GetConVarNumber( "cl_vis_materialtype" ) == 0 then
chamstype:SelectItem(a)
elseif GetConVarNumber( "cl_vis_materialtype"  ) == 1 then
chamstype:SelectItem(b)
end
a.DoClick = function() RunConsoleCommand( "cl_vis_materialtype" , 0 ) chamstype:SelectItem(a) end
b.DoClick = function() RunConsoleCommand( "cl_vis_materialtype" , 1 ) chamstype:SelectItem(b) end
end
Chamtype()

local cheats = vgui.Create( "DButton", othpan )
cheats:SetSize( 200, 20 )
cheats:SetPos( 10, 390 )
cheats:SetText( "Toggle Bypass" )
cheats.DoClick = function()
enabled = !enabled

if enabled then
SetConvar( CreateConVar("sv_cheats", ""), 1 )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[Precisionbot]: Cheats Enabled." )
else
SetConvar( CreateConVar("sv_cheats", ""), 0 )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[Precisionbot]: Cheats Disabled." )
end
end

// Radar
local radarpan = vgui.Create( "DPanel", panel )

local radar = vgui.Create( "DCheckBoxLabel", radarpan )
radar:SetText( "Radar" )
radar:SetPos( 10, 10 )
radar:SetConVar( "cl_misc_radar"  )
radar:SetTextColor( Color( 0, 0, 0, 255 ) )
radar:SizeToContents()

local ccRed = vgui.Create( "DNumSlider", radarpan )
ccRed:SetPos( 10, 50 )
ccRed:SetWide( 200 )
ccRed:SetText( "" )
ccRed:SetMin( 0 )
ccRed:SetMax( 255 )
ccRed:SetDecimals( 0 )
ccRed:SetConVar( "cl_misc_radar_r" )
	local cRed = vgui.Create("DLabel", radarpan )
	cRed:SetPos( 10, 50 )
	cRed:SetText( "Red" )
	cRed:SetTextColor( Color(0, 0, 0, 255) )
 
 local ccGreen = vgui.Create( "DNumSlider", radarpan )
ccGreen:SetPos( 10, 100 )
ccGreen:SetWide( 200 )
ccGreen:SetText( "" )
ccGreen:SetMin( 0 )
ccGreen:SetMax( 255 )
ccGreen:SetDecimals( 0 )
ccGreen:SetConVar( "cl_misc_radar_g" )
	local cGreen = vgui.Create("DLabel", radarpan )
	cGreen:SetPos( 10, 100 )
	cGreen:SetText( "Green" )
	cGreen:SetTextColor( Color(0, 0, 0, 255) )

 
 local ccBlue = vgui.Create( "DNumSlider", radarpan )
ccBlue:SetPos( 10, 150 )
ccBlue:SetWide( 200 )
ccBlue:SetText( "" )
ccBlue:SetMin( 0 )
ccBlue:SetMax( 255 )
ccBlue:SetDecimals( 0 )
ccBlue:SetConVar( "cl_misc_radar_b" )
	local cBlue = vgui.Create("DLabel", radarpan )
	cBlue:SetPos( 10, 150 )
	cBlue:SetText( "Blue" )
	cBlue:SetTextColor( Color(0, 0, 0, 255) )

local ccAlpha = vgui.Create( "DNumSlider", radarpan )
ccAlpha:SetPos( 10, 200 )
ccAlpha:SetWide( 200 )
ccAlpha:SetText( "" )
ccAlpha:SetMin( 0 )
ccAlpha:SetMax( 255 )
ccAlpha:SetDecimals( 0 )
ccAlpha:SetConVar( "cl_misc_radar_a" )
	local cAlpha = vgui.Create("DLabel", radarpan )
	cAlpha:SetPos( 10, 200 )
	cAlpha:SetText( "Alpha" )
	cAlpha:SetTextColor( Color(0, 0, 0, 255) )
	
local ccX = vgui.Create( "DNumSlider", radarpan )
ccX:SetPos( 10, 250 )
ccX:SetWide( 200 )
ccX:SetText( "" )
ccX:SetMin( 0 )
ccX:SetMax( ScrW() )
ccX:SetDecimals( 0 )
ccX:SetConVar( "cl_misc_radar_x" )
	local cX = vgui.Create("DLabel", radarpan )
	cX:SetPos( 10, 250 )
	cX:SetText( "Radar X" )
	cX:SetTextColor( Color(0, 0, 0, 255) )
	
local ccY = vgui.Create( "DNumSlider", radarpan )
ccY:SetPos( 10, 300 )
ccY:SetWide( 200 )
ccY:SetText( "" )
ccY:SetMin( 0 )
ccY:SetMax( ScrH() )
ccY:SetDecimals( 0 )
ccY:SetConVar( "cl_misc_radar_y" )
	local cY = vgui.Create("DLabel", radarpan )
	cY:SetPos( 10, 300 )
	cY:SetText( "Radar Y" )
	cY:SetTextColor( Color(0, 0, 0, 255) )
	
local crs = vgui.Create( "DNumSlider", radarpan )
crs:SetPos( 10, 350 )
crs:SetWide( 200 )
crs:SetText( "" )
crs:SetMin( 0 )
crs:SetMax( 10000 )
crs:SetDecimals( 0 )
crs:SetConVar( "cl_misc_radar_ra" )
	local ccrs = vgui.Create("DLabel", radarpan )
	ccrs:SetPos( 10, 350 )
	ccrs:SetText( "Radar Radius" )
	ccrs:SetTextColor( Color(0, 0, 0, 255) )

panel:AddSheet( "Aimbot", aimpan, "gui/silkicons/star", false, false, "Automatic Aiming" )
panel:AddSheet( "ESP", esppan, "gui/silkicons/group", false, false, "Extra Sensory" ) 
panel:AddSheet( "Misc", othpan, "gui/silkicons/plugin", false, false, "Other Stuff" )
panel:AddSheet( "Radar", radarpan, "gui/silkicons/wrench", false, false, "Radar stuff" ) 
end

concommand.Add( "cl_menu", menuvgui )

// ********************
// Main Functions:
// ********************

// Commands - Console commands.
CreateClientConVar( "cl_aim_aimbot", "1", true, false )
CreateClientConVar( "cl_aim_autoshoot", "0", true, false )
CreateClientConVar( "cl_aim_autowall", "0", true, false )
CreateClientConVar( "cl_aim_friendlyfire", "1", true, false )
CreateClientConVar( "cl_aim_bone", "1", true, false )
CreateClientConVar( "cl_esp_name", "1", true, false )
CreateClientConVar( "cl_esp_class", "1", true, false )
CreateClientConVar( "cl_esp_admin", "1", true, false )
CreateClientConVar( "cl_esp_health", "1", true, false )
CreateClientConVar( "cl_esp_weapon", "0", true, false )
CreateClientConVar( "cl_esp_distnace", "0", true, false )
CreateClientConVar( "cl_esp_box", "1", true, false )
CreateClientConVar( "cl_esp_box_allow", "1", true, false )
CreateClientConVar( "cl_esp_rp", "0", true, false )
CreateClientConVar( "cl_esp_sbox", "0", true, false )
CreateClientConVar( "cl_esp_color", "0", true, false )
CreateClientConVar( "cl_esp_npc", "1", true, false )
CreateClientConVar( "cl_esp_npcmarker", "1", true, false )
CreateClientConVar( "cl_esp_espmax", "10000", true, false )
CreateClientConVar( "cl_esp_espmaxents", "10000", true, false )
CreateClientConVar( "cl_vis_crosshair", "1", true, false )
CreateClientConVar( "cl_vis_dynamiclights", "0", true, false )
CreateClientConVar( "cl_vis_dynamiclightsself", "0", true, false )
CreateClientConVar( "cl_vis_dynamiclightsrad", "500", true, false )
CreateClientConVar( "cl_vis_chams", "1", true, false )
CreateClientConVar( "cl_vis_chamsplayer", "1", true, false )
CreateClientConVar( "cl_vis_chamsnpc", "0", true, false )
CreateClientConVar( "cl_vis_chamsweapon", "0", true, false )
CreateClientConVar( "cl_vis_chamsragdoll", "0", true, false )
CreateClientConVar( "cl_vis_materialtype", "0", true, false )
CreateClientConVar( "cl_misc_speedvalue", ".2", true, false )
CreateClientConVar( "cl_misc_fullbright", "0", true, false )
CreateClientConVar( "cl_misc_radar", "1", true, false )
CreateClientConVar( "cl_misc_radar_r", "0", true, false )
CreateClientConVar( "cl_misc_radar_g", "255", true, false )
CreateClientConVar( "cl_misc_radar_b", "0", true, false )
CreateClientConVar( "cl_misc_radar_a", "50", true, false )
CreateClientConVar( "cl_misc_radar_x", "10", true, false )
CreateClientConVar( "cl_misc_radar_y", "10", true, false )
CreateClientConVar( "cl_misc_radar_ra", "5000", true, false )

// LUA Commands - To make this easy.
local ply	   = LocalPlayer()
local e		   = ent
local x 	   = ScrW() / 2
local y 	   = ScrH() / 2

// Fonts - Main fonts used in the cheat. You must download visitor2 for this to work.
surface.CreateFont( "Visitor TT2 BRK", 10, 200, true, false, "VISITOR2" )
surface.CreateFont( "Visitor TT2 BRK", 27, 400, true, false, "VISITOR2" )

// Get Admin - Finds the current admins then then prints what level of admin they are.
function GetAdmin( e )
		if e:IsAdmin() and not e:IsSuperAdmin() then return ( " | Admin" )
		elseif e:IsSuperAdmin() then return ( " | Super Admin" )
		elseif not e:IsAdmin() and not e:IsSuperAdmin() then return ( "" ) 
	end
end

// Targets - Mainly for the chams, tells whats valid and whats not.
function BadTargets( e )
	if team.GetName(e:Team()) == "spectator" then return false end
	if team.GetName(e:Team()) == "spectators" then return false end
	return true
end

// Entitiess!!!!
local RolePlayEntitys = ( {
	"money_printer",
	"drug_lab",
	"drug",
	"microwave",
	"food",
	"gunlab",
	"spawned_shipment",
	"spawned_food",
	"spawned_weapon",
} )

local RPMoney = ( {
	"models/props/cs_assault/money.mdl",
} )

local Warnings = ( {
	"npc_grenade_frag",
	"crossbow_bolt",
	"rpg_missile",
	"grenade_ar2",
	"prop_combine_ball",
	"hunter_flechette",
	"ent_flashgrenade",
	"ent_explosivegrenade",
	"ent_smokegrenade",
} )

// ********************
// Aimbot:
// ********************

local Aim    = false
local Type	 = 0
local Target = nil

local SVector = Vector( 0, 0, 64 ) // Normal player(s)/NPC's hight.
local CVector = Vector( 0, 0, 48 ) // Crouching hight.
local HVector = Vector( 0, 0, 05 ) // Small vector hight. (Headcrabes/birds...)

local MainBones = ( {
	[1] = "ValveBiped.Bip01_Head1",
	[2] = "ValveBiped.Bip01_Neck1", 
	[3] = "ValveBiped.Bip01_Spine4",
	[4] = "ValveBiped.Bip01_Spine2",
	[5] = "ValveBiped.Bip01_Spine1",
	[6] = "ValveBiped.Bip01_Spine",
} )

local FullBody = ( {
	[01] = "ValveBiped.Bip01_Head1",
	[02] = "ValveBiped.Bip01_Neck1",
	[03] = "ValveBiped.Bip01_Spine4",
	[04] = "ValveBiped.Bip01_Spine2",
	[05] = "ValveBiped.Bip01_Spine1",
	[06] = "ValveBiped.Bip01_Spine",
	[07] = "ValveBiped.Bip01_R_UpperArm",
	[08] = "ValveBiped.Bip01_R_Forearm",
	[09] = "ValveBiped.Bip01_R_Hand",
	[10] = "ValveBiped.Bip01_L_UpperArm",
	[11] = "ValveBiped.Bip01_L_Forearm",
	[12] = "ValveBiped.Bip01_L_Hand",
	[13] = "ValveBiped.Bip01_R_Thigh",
	[14] = "ValveBiped.Bip01_R_Calf",
	[15] = "ValveBiped.Bip01_R_Foot",
	[16] = "ValveBiped.Bip01_R_Toe0",
	[17] = "ValveBiped.Bip01_L_Thigh",
	[18] = "ValveBiped.Bip01_L_Calf",
	[19] = "ValveBiped.Bip01_L_Foot",
	[20] = "ValveBiped.Bip01_L_Toe0",
} )

// ********************
// Extra Sensory:
// ********************
function PB.Display( e )
	for _, e in pairs(ents.GetAll()) do
		local ply = LocalPlayer()
		if ( e:IsPlayer() && e:Alive() == true ) && ( e ~=ply ) && ( BadTargets( e ) ) then
			local dis	= math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
			local pos	= e:GetPos():ToScreen()
			local tn	= team.GetName( e:Team() )
			local tc	= team.GetColor( e:Team() )
			
			if e:IsValid() then // I had to run this because the script was breaking.
			
			// If the player(s) are in this distance then it will draw everything below.
			if dis <= GetConVarNumber( "cl_esp_espmax" ) then
			
			// Extra sensory color type, if you want it to be based off their team color or allies/enemyies.
			local col
			local box_col
				if ( GetConVarNumber( "cl_esp_color" ) == 0 ) then
						col = Color( tc.r, tc.g, tc.b, 255 )
					end
				if ( GetConVarNumber( "cl_esp_color" ) == 1 ) then
					if e:Team() == ply:Team() then
						col = Color( 0, 255, 0, 255 )
					elseif e:Team() ~= ply:Team() then
						col = Color( 255, 0, 0, 255 )
					end
				end
				
			local pos
			local xval
			local yval
				if ( GetConVarNumber( "cl_esp_box" ) == 1 ) then 
					pos = e:GetPos():ToScreen()
					xval = pos.x
					yval = pos.y
				end
				if ( GetConVarNumber( "cl_esp_box" ) == 2 ) then
					pos = e:GetBonePosition( e:LookupBone( "ValveBiped.Bip01_Head1" )):ToScreen()
					xval = pos.x + 10
					yval = pos.y
				end
				if ( GetConVarNumber( "cl_esp_box" ) == 3 ) then
					pos = e:GetBonePosition( e:LookupBone( "ValveBiped.Bip01_Head1" )):ToScreen()
					xval = pos.x + 3
					yval = pos.y
				end
				if ( GetConVarNumber( "cl_esp_box" ) == 4 ) then
					pos = e:GetBonePosition( e:LookupBone( "ValveBiped.Bip01_Head1" )):ToScreen()
					xval = pos.x + 15
					yval = pos.y - 10
				end
				if ( GetConVarNumber( "cl_esp_box_allow" ) == 0 ) then
					pos = e:GetPos():ToScreen()
					xval = pos.x
					yval = pos.y
				end
				
			// Real Extra sensory code.
				if ( GetConVarNumber( "cl_esp_name" ) == 1 ) then
					draw.SimpleText( e:Nick() .. " | " .. tn .. GetAdmin( e ), "VISITOR2", xval, yval, col, 0, 2 )
				end
				
				if ( GetConVarNumber( "cl_esp_health" ) == 1 ) then
					draw.SimpleText( "HP: " .. e:Health(), "VISITOR2", xval, yval + 10, col, 0, 2 )
				end
				
				if ( GetConVarNumber( "cl_esp_weapon" ) == 1 ) then
					if e:GetActiveWeapon():IsValid() then
					local wep = e:GetActiveWeapon():GetPrintName()
					local wep = string.Replace( wep, "#HL2_", "" )
					local wep = string.Replace( wep, "#GMOD_", "" )
					local wep = string.upper( wep )
					draw.SimpleText( "W: " .. wep, "VISITOR2", xval, yval + 20, col, 0, 2 )
				end
			end
				if ( GetConVarNumber( "cl_esp_distnace" ) == 1 ) then
					local dis = math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
					draw.SimpleText( "D: " .. dis, "VISITOR2", xval, yval + 30, col, 0, 2 )
				end
				
			if ( GetConVarNumber( "cl_esp_box_allow" ) == 1 ) then	
				if ( GetConVarNumber( "cl_esp_box" ) == 1 ) then
					local center = e:LocalToWorld(e:OBBCenter())
					local min,max = e:WorldSpaceAABB()
					local dim = max-min

					local front = e:GetForward()*(dim.y/2)
					local right = e:GetRight()*(dim.x/2)
					local top = e:GetUp()*(dim.z/2)
					local back = (e:GetForward()*-1)*(dim.y/2)
					local left = (e:GetRight()*-1)*(dim.x/2)
					local bottom = (e:GetUp()*-1)*(dim.z/2)
					local FRT = center+front+right+top
					local BLB = center+back+left+bottom
					local FLT = center+front+left+top
					local BRT = center+back+right+top
					local BLT = center+back+left+top
					local FRB = center+front+right+bottom
					local FLB = center+front+left+bottom
					local BRB = center+back+right+bottom

					FRT = FRT:ToScreen()
					BLB = BLB:ToScreen()
					FLT = FLT:ToScreen()
					BRT = BRT:ToScreen()
					BLT = BLT:ToScreen()
					FRB = FRB:ToScreen()
					FLB = FLB:ToScreen()
					BRB = BRB:ToScreen()

					local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
					local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)

					surface.SetDrawColor( col.r, col.g, col.b, 255 )

					surface.DrawLine(xmax,ymax,xmax,ymin)
					surface.DrawLine(xmax,ymin,xmin,ymin)
					surface.DrawLine(xmin,ymin,xmin,ymax)
					surface.DrawLine(xmin,ymax,xmax,ymax)
				end
				
				if ( GetConVarNumber( "cl_esp_box" ) == 2 ) then
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					draw.RoundedBox( 0, pos.x, pos.y, 5, 5, col )
				end
							
				if ( GetConVarNumber( "cl_esp_box" ) == 3 ) then	
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawLine(pos.x, pos.y - 5, pos.x, pos.y + 5)
					surface.DrawLine(pos.x - 5, pos.y, pos.x + 5, pos.y)
				end
				
				if ( GetConVarNumber( "cl_esp_box" ) == 4 ) then	
					surface.SetDrawColor( col.r, col.g, col.b, 255 )
					surface.DrawOutlinedRect( pos.x - 25 / 2, pos.y - 10, 25, 75)
				end
			end
		end
			
			else
				if dis >= GetConVarNumber( "cl_esp_espmax" ) then
					if ( GetConVarNumber( "cl_esp_name" ) == 1 ) then
							draw.SimpleText( e:Nick() .. "(" .. e:Health() .. ")" .. GetAdmin( e ), "VISITOR2", pos.x, pos.y, col, 1, 1 )
						end
					end
				end
			end
		/*if e:IsValid() then
			
			// NPC ESP - The positioning works by the model type, then setting the vector according to the model.
			if e:IsNPC() and e:GetMoveType() !=0 then
				if ( GetConVarNumber( "cl_esp_npc" ) == 1 ) then
					local pos = e:GetPos():ToScreen()
					local npc = e:GetClass()
					local npc = string.Replace( npc, "npc_", "" )
					local npc = string.upper( npc )
					draw.SimpleText( npc, "VISITOR2", pos.x, pos.y + 10, Color( 255, 0, 0, 255 ), 1, 1 )
				end
				if ( GetConVarNumber( "cl_esp_npcmarker" ) == 1 ) then
					pos = e:GetPos() + Vector( 0, 0, 64 )
					pos = pos:ToScreen()
					if e:GetModel() == ( "models/crow.mdl" ) or e:GetModel() == ( "models/pigeon.mdl" ) or e:GetModel() == ( "models/seagull.mdl" ) then //or e:GetModel() == ( "models/combine_scanner.mdl" ) or e:GetModel() == ( "models/zombie/fast_torso.mdl" ) or e:GetModel() == ( "models/headcrabclassic.mdl" ) or e:GetModel() == ( "models/headcrabblack.mdl" ) or e:GetModel() == ( "models/headcrab.mdl" ) or e:GetModel() == ( "models/zombie/classic_torso.mdl" ) then
					pos = e:GetPos() + Vector( 0, 0, 7 )
					pos = pos:ToScreen()
					elseif e:GetModel() == ( "models/barnacle.mdl" ) then		
					pos = e:GetPos() + Vector( 0, 0, -10 )
					pos = pos:ToScreen()
					elseif e:GetModel() == ( "models/manhack.mdl" ) then
					pos = e:GetPos() + Vector( 0, 0, 2 )
					pos = pos:ToScreen()
					elseif e:GetModel() == ( "models/zombie/classic_torso.mdl" ) then
					pos = e:GetPos() + Vector( 5, 0, 20 )
					pos = pos:ToScreen()
					elseif e:GetModel() == ( "models/zombie/fast_torso.mdl" ) then
					pos = e:GetPos() + Vector( 0, 0, 10 )
					pos = pos:ToScreen()
					end
					draw.RoundedBox( 0, pos.x, pos.y, 5, 5, Color( 255, 0, 0, 255 ) )
				end
			end
			
			local dis	= math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
			if dis <= GetConVarNumber( "cl_esp_espmaxents" ) then
			
			// Sandbox ESP - Gets the weapons and vehicles on the map.
			if e:IsWeapon() and e:GetMoveType() !=0 or string.find( e:GetClass(), "prop_vehicle_" ) then
				if ( GetConVarNumber( "cl_esp_sbox" ) == 1 ) then
					local sbox = e:GetClass()
					local sbox = string.Replace(sbox, "prop_vehicle_", "")
					local sbox = string.Replace(sbox, "weapon_", "")
					local pos = e:GetPos():ToScreen()
					draw.SimpleText( sbox, "VISITOR2", pos.x, pos.y + 10, Color( 255, 0, 0, 255 ), 1, 1 )
				end
			end
			
			// Roleplay - Gets models that are roleplay.
			if table.HasValue( RolePlayEntitys, e:GetClass() ) then
				if ( GetConVarNumber( "cl_esp_rp" ) == 1 ) then
					local rpclass = e:GetClass()
					local rpclass = string.Replace(rpclass, "spawned_", "")
					local rpclass = string.Replace(rpclass, "shipment_", "Shipment ")
					local rpclass = string.Replace(rpclass, "dropped_", "")
					local rpclass = string.Replace(rpclass, "dropped_", "")
					local rpclass = string.Replace(rpclass, "smg_", "SMG ")
					local rpclass = string.Replace(rpclass, "money_", "Money ")
					local pos = e:GetPos():ToScreen()
					draw.SimpleText( rpclass, "VISITOR2", pos.x, pos.y, Color( 255, 0, 0, 255 ), 1 ,1)
				end
			end
			
			// Roleplay Money - Gets the money model and draws it, so now its easy to find money!
			if table.HasValue( RPMoney, e:GetModel() ) then
				if ( GetConVarNumber( "cl_esp_rp" ) == 1 ) then
					local money = e:GetModel()
					local money = string.Replace( money, "models/props/cs_assault/money.mdl", "Money" )
					local pos = e:GetPos():ToScreen()
					draw.SimpleText( money, "VISITOR2", pos.x, pos.y, Color( 255, 0, 0, 255 ), 1 ,1)
				end
			end
		end
	end*/
end
end
NewHook( "HUDPaint", PB.Display )

// ********************
// Visuals:
// ********************
function Drawvisuals()
	if GetConVarNumber( "cl_vis_crosshair" ) == 1 then
	local cross 	= {}
	cross.x			= x				  				// Centure screen.																DEF = x
	cross.y			= y 			  				// Centure screen.																DEF = y
	cross.tall		= 40					  		// Highth of the line.															DEF = 20
	cross.wide		= 40					  		// Width of the line.															DEF = 20
	cross.color		= Color( 0, 255, 0, 255 )		// Crosshair color.																DEF = Color( 0, 255, 0, 255 )
	cross.dotcol	= Color( 255, 0, 0, 255 )		// Crosshair dot color.															DEF = Color( 255, 0, 0, 255 )
	cross.xd		= cross.x - 2					// Crosshair dot - 2.															DEF = cross.x - 2
	cross.yd		= cross.y - 2					// Crosshair dot - 2.															DEF = cross.y - 2

		// GUI
			surface.SetDrawColor( cross.color )
			surface.DrawLine( cross.x, cross.y - cross.tall, cross.x, cross.y + cross.tall )
			surface.DrawLine( cross.x - cross.wide, cross.y, cross.x + cross.wide, cross.y )
			draw.RoundedBox( 1, cross.xd, cross.yd, 5, 5, cross.dotcol )
		end


// Dynamic Lights - Draws a light around the player, makes them easy to see if you don't want to bypass cheats.
	local ply = LocalPlayer()
	

		for _, e in pairs( player.GetAll() ) do
		
			local col
				if GetConVarNumber( "cl_esp_color" ) == 0 then
						local tc  = team.GetColor( e:Team() )
						col = Color( tc.r, tc.g, tc.b, 255 )
					end
				if GetConVarNumber( "cl_esp_color" ) == 1 then
						if e:Team() == ply:Team() then
						col = Color( 255, 0, 0, 255 )
						elseif e:Team() ~= ply:Team() then
						col = Color( 0, 255, 0, 255 )
					end
				end
				
				local ply = LocalPlayer()
				if e == ply then
				if ( GetConVarNumber( "cl_vis_dynamiclightsself" ) == 1 ) then
					local dlight = DynamicLight( ply )
					dlight.Pos = e:GetPos() + Vector( 0, 0, 32 )
					dlight.r = 255
					dlight.g = 255
					dlight.b = 255
					dlight.Size = GetConVarNumber( "cl_vis_dynamiclightsrad" )
					dlight.Decay = 20
					dlight.DieTime = CurTime() + .1
				end
			end
				if ( GetConVarNumber( "cl_vis_dynamiclights" ) == 1 ) then
				if ValidEntity(e) and e:Alive() and e ~=ply then
					local dlight = DynamicLight( player.GetAll() )
					dlight.Pos = e:GetPos() + Vector( 0, 0, 32 )
					dlight.r = col.r
					dlight.g = col.g
					dlight.b = col.b
					dlight.Size = GetConVarNumber( "cl_vis_dynamiclightsrad" )
					dlight.Decay = 20
					dlight.DieTime = CurTime() + .1
				end
			end
		end
	end
NewHook( "HUDPaint", Drawvisuals )

CreateClientConVar( "zee_max", 99999, true, false )
// Chams - Shows the player model though the walls.
function Chams( )
	for k, e in pairs( ents.GetAll() ) do
		if e:IsValid() then
			local ply = LocalPlayer()
			local c = ( 1/255 )
			local mat
			local col
			if e:IsPlayer() then
			if GetConVarNumber( "cl_esp_color" ) == 0 then
			local tc  = team.GetColor( e:Team() )
			col = Color( tc.r, tc.g, tc.b, 255 )
			end
			if GetConVarNumber( "cl_esp_color" ) == 1 then
			if e:Team() == ply:Team() then
			col = Color( 0, 255, 0, 255 )
			elseif e:Team() ~= ply:Team() then
			col = Color( 255, 0, 0, 255 )
			end
			end
			end
			if e:IsWeapon() or e:GetClass() == ( "prop_ragdoll" ) or e:GetClass() == ( "class C_ClientRagdoll" ) then
			col = Color( 255, 255, 255, 255 )
			end
			if e:GetClass() == ( "prop_ragdoll" ) or e:GetClass() == ( "class C_ClientRagdoll" ) then
			col = Color( 0, 255, 0, 255 )
			end
			if e:IsNPC() then
			col = Color( 255, 0, 0, 255 )
			end
			if ( GetConVarNumber( "cl_vis_chamsplayer" ) == 1 ) and ( e:IsPlayer() and e:Alive() == true ) and ( e ~=ply ) and ( BadTargets( e ) ) then//or ( GetConVarNumber( "cl_vis_chamsweapon" ) == 1 and e:GetMoveType() == 0 and e:IsWeapon() ) or ( GetConVarNumber( "cl_vis_chamsnpc" ) == 1 and e:IsValid() and e:IsNPC() and e:GetMoveType() !=0 ) or ( GetConVarNumber( "cl_vis_chamsragdoll" ) == 1 and e:GetClass() == ( "class C_ClientRagdoll" ) ) then
			local dis = math.floor( tostring( e:GetPos():Distance( ply:GetShootPos() ) ) )
			if dis <= GetConVarNumber( "zee_max" ) then
			cam.Start3D( EyePos(), EyeAngles() )
			if ( GetConVarNumber( "cl_vis_materialtype" ) == 0 ) then // Wireframe
			local mat = Material( "hlmv/debugmrmwireframe" )
			if mat ~= nil then
			render.SuppressEngineLighting( true )
			render.SetColorModulation((c*col.r), (c*col.g), (c*col.b))
			SetMaterialOverride( mat )
			e:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			SetMaterialOverride( 0 )
			e:DrawModel()
			end
			end
			if ( GetConVarNumber( "cl_vis_materialtype" ) == 1 ) then // Soild
			local mat = Material( "precisionbot/solid" )
			if mat ~= nil then
			render.SuppressEngineLighting( true )
			render.SetColorModulation((c*col.r), (c*col.g), (c*col.b))
			SetMaterialOverride( mat )
			e:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			SetMaterialOverride( 0 )
			e:DrawModel()
			end
			end
			cam.End3D()
			end
			end
		end
	end
end
NewHook( "RenderScreenspaceEffects", Chams )
// ********************
// Radar:
// ********************
function Drawradar()
	
if GetConVarNumber( "cl_misc_radar" ) == 1 then
	
// Radar Table - The table for the shit n shit.
local radar 	= {}
radar.x 		= GetConVarNumber( "cl_misc_radar_x" )	  		  // X postition of the radar.  												DEF = 10
radar.y			= GetConVarNumber( "cl_misc_radar_y" )	  		  // Y postition of the radar.  												DEF = 10
radar.round		= 0						  					  // The roundness of the radar.  												DEF = 0
radar.size 		= 200					  					  // Size of radar.  															DEF = 200
radar.selfsize	= 5						  					  // Your box size. 															DEF = 5
radar.selfround = 1						  					  // Roundness of your dot.														DEF = 1
radar.csize		= 90					  					  // Centure line size.															DEF = 90
red				= GetConVarNumber( "cl_misc_radar_r" )	  		  // Redcolor																	DEF =
green			= GetConVarNumber( "cl_misc_radar_g" )	  		  // Greencolor																	DEF =
blue			= GetConVarNumber( "cl_misc_radar_b" )	  		  // Bluecolor																	DEF =
alpha			= GetConVarNumber( "cl_misc_radar_a" )	 		  // Alphacolor																	DEF =
radar.col		= Color( red, green, blue, alpha ) 			  // Radar Color																DEF =
radar.outcol	= Color( 0, 0, 0, 255 )	  					  // Outline color.																DEF = Color( 0, 0, 0, 255 )
radar.selfcol	= Color( 0, 0, 255, 000 ) 					  // Your color.																DEF = Color( 0, 0, 255, 255 )
radar.radius	= GetConVarNumber( "cl_misc_radar_ra" )		 	  // How far the radar will scan.												DEF = 5000
radar.plyname	= true					  					  // Draws player's name.														DEF = false
radar.plydot	= true					  					  // Draws a player dot on the position of the radar.							DEF = true
radar.plycol	= Color( 0, 0, 255, 255 ) 					  // Color of the player's name and dot.										DEF = Color( 0, 0, 255, 255 )
radar.npcdot	= true					  					  // Draws a NPC dot on the position of the radar.								DEF = true
radar.npccol	= Color( 255, 0, 0, 255 ) 					  // Color of the NPC's name and dot.											DEF = Color( 0, 0, 255, 255 )
radar.enpcol	= Color( 255, 0, 0, 255 ) 					  // Enemies color.																DEF = Color( 255, 0, 0, 255 )
radar.half		= radar.size / 2		  					  // Divides the size by two to make a centured cross.
radar.selfhalf	= radar.selfsize / 2	 			 		  // Divides the box size by 2 to centure it.
radar.xm		= radar.x + radar.half	  					  // Center of radar. (x)
radar.ym		= radar.y + radar.half	  					  // Center of radar. (y)
radar.xo		= radar.x				  					  // Radar outline. (x)
radar.yo		= radar.y				  					  // Radar outline. (y)
  
// Radar GUI - Edit everything above to edit these.
draw.RoundedBox( radar.round, radar.x, radar.y, radar.size, radar.size, radar.col )
surface.SetDrawColor( radar.outcol )
surface.DrawLine( radar.xm, radar.ym - radar.csize, radar.xm, radar.ym + radar.csize )
surface.DrawLine( radar.xm - radar.csize, radar.ym, radar.xm + radar.csize, radar.ym )
surface.SetDrawColor( radar.outcol )
surface.DrawLine( radar.xo, radar.yo, radar.xo, radar.yo + radar.size )
surface.DrawLine( radar.xo + radar.size, radar.yo, radar.xo + radar.size, radar.yo + radar.size )
surface.DrawLine( radar.xo, radar.yo, radar.xo + radar.size, radar.yo )
surface.DrawLine( radar.xo, radar.yo + radar.size, radar.xo + radar.size, radar.yo + radar.size )
draw.RoundedBox( radar.selfround, radar.xm - radar.selfhalf, radar.ym - radar.selfhalf, radar.selfsize, radar.selfsize, radar.selfcol )
			
// Radar code thanks to Georg Schmid; I'm only good at creating GUI's n stuff.
	for _, v in pairs( ents.GetAll() ) do

		local ply = LocalPlayer()
		local gpos = v:GetPos() - LocalPlayer():GetPos()

if v:IsPlayer() and v:Alive() and v ~=ply and gpos:Length() <= radar.radius then
	if v:IsValid() then
		local col
		if GetConVarNumber( "cl_esp_color" ) == 0 then
		local tc  = team.GetColor( v:Team() )
		col = Color( tc.r, tc.g, tc.b, 255 )
		end
		if GetConVarNumber( "cl_esp_color" ) == 1 then
		if v:Team() == ply:Team() then
		col = Color( 255, 0, 0, 255 )
		elseif v:Team() ~= ply:Team() then
		col = Color( 0, 255, 0, 255 )
		end
		end
		local cenx = radar.x + radar.size / 2
		local ceny = radar.y + radar.size / 2
		local tc = team.GetColor( v:Team() )
		local gpos = v:GetPos() - LocalPlayer():GetPos()
		local pixx = gpos.x / radar.radius
		local pixy = gpos.y / radar.radius
		local root = math.sqrt( pixx * pixx + pixy * pixy )
		local find = math.Deg2Rad( math.Rad2Deg( math.atan2( pixx, pixy ) ) - math.Rad2Deg( math.atan2( LocalPlayer():GetAimVector().x, LocalPlayer():GetAimVector().y ) ) - 90)
		local pixx = math.cos( find ) * root
		local pixy = math.sin( find ) * root
		if radar.plydot then
		draw.RoundedBox( 1, cenx + pixx * radar.size / 2 - 0, ceny + pixy * radar.size / 2 - 4, 5, 5, col )
		end
		if radar.plyname then
		draw.SimpleText( v:Nick(), "DefaultSmall", cenx + pixx * radar.size / 2, ceny + pixy * radar.size / 2 - 10, col, 1, 1 )
	end
end
end
end
for _, v in pairs( ents.GetAll() ) do
	if v:IsValid() then
		local cenx = radar.x + radar.size / 2
		local ceny = radar.y + radar.size / 2
		local gpos = v:GetPos() - LocalPlayer():GetPos()
		if gpos:Length() <= radar.radius then
		local pixx = gpos.x / radar.radius
		local pixy = gpos.y / radar.radius
		local root = math.sqrt( pixx * pixx + pixy * pixy )
		local find = math.Deg2Rad( math.Rad2Deg( math.atan2( pixx, pixy ) ) - math.Rad2Deg( math.atan2( LocalPlayer():GetAimVector().x, LocalPlayer():GetAimVector().y ) ) - 90)
		local pixx = math.cos( find ) * root
		local pixy = math.sin( find ) * root
		if v:IsNPC() and v:GetMoveType() !=0 then
		if radar.npcdot then
		draw.RoundedBox( 1, cenx + pixx * radar.size / 2 - 4, ceny + pixy * radar.size / 2 - 4, 4, 4, radar.npccol )
	end
end
end
end
end
end
end
NewHook( "HUDPaint", Drawradar )


// ********************
// Miscellaneous:
// ********************

// Bunnyhop - Allows you to jump constantly. Note this will not work if a server blocks hooks.
concommand.Add( "+bhop", function()
	hook.Add( "Tick", "Bunnyhop", function()
		local ply = LocalPlayer()
			if !ply:IsOnGround() then
				RunConsoleCommand( "-jump" )
			elseif ply:IsOnGround() then
				RunConsoleCommand( "+jump" )
			end
		end )
	end )
concommand.Add( "-bhop", function()
	hook.Remove( "Tick", "Bunnyhop" )
end )
	
//Speed Hack - Lets you go faster than everyone else.
concommand.Add( "+speedhack", function()
	SetConvar( CreateConVar( "host_framerate", "" ), ( GetConVarNumber( "cl_misc_speedvalue" ) ) )
end)
concommand.Add( "-speedhack", function()
	SetConvar( CreateConVar( "host_framerate", "" ), 0 )
end)

// Nospread
/*function Cone()
	local wep	 = ply:GetActiveWeapon()
	local spread = wep.Cone
		if !spread and type( wep.Primary ) == ( "table" ) and type( spread ) == ( "number" ) then
			spread = wep.Primary.Cone
		end
		
		if !spread then
			spread = ( "0" )
		end
		
		


local function GetCone(wep)
	local cone = wep.Cone
	if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
		cone = wep.Primary.Cone
	end
	if not cone then cone = 0 end
	--CHeck if wep is HL2 then return corresponding cone
	if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
	if wep:GetClass() == "ose_turretcontroller" then return 0 end
	if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
	return cone or 0
end

require("deco")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
	cmd2, seed = hl2_ucmd_getprediciton(cmd)
	if cmd2 ~= 0 then
		currentseed = seed
	end
	wep = LocalPlayer():GetActiveWeapon()
	vecCone = Vector(0,0,0)
	if wep and wep:IsValid() and type(wep.Initialize) == "function" then
		valCone = GetCone(wep)
		if type(valCone) == "number" then
			vecCone = Vector(-valCone,-valCone,-valCone)
		elseif type(valCone) == "Vector" then
			vecCone = -1*valCone
		end
	end
	return hl2_shotmanip(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
//END OF ANTI SPREAD SCRIPT
end
end*/
end
//