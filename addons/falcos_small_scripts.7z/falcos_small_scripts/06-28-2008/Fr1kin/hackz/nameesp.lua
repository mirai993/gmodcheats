function EntMaterial() 
	local ent = LocalPlayer():GetEyeTrace().Entity 
 
	if (ent:IsValid()) then //yup, its a valid entity!
		local entmat = ent:GetMaterial()
		LocalPlayer():ChatPrint(entmat)
		print( "T: "..entmat )
	end 
end
concommand.Add("GetEntMaterial", EntMaterial)
