util.PrecacheSound("falco/piano.wav")
util.PrecacheSound("falco/pianohigh.wav")

local function DoSounds(ply,cmd,args)
	local sound = args[1]
	local pitch = tonumber(args[2]) or 100
	local vol = tonumber(args[3]) or falcoPianovolume:GetInt()
	LocalPlayer():EmitSound(sound,vol,pitch)
end
concommand.Add("falcoCLplay",DoSounds) 