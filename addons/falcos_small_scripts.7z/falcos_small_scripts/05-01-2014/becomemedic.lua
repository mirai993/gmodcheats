--[[
	MOD/lua/fscripts/becomemedic.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:30AM]
	===BadFile===
]]

-- I use this every single time I join a server
local Medics = {"medic", "doctor", "krankenhaus", "accro77doctor"}

concommand.Add("falco_becomeMedic", function()
	for k,v in pairs(RPExtraTeams or {}) do
		if table.HasValue(Medics, string.lower(v.command or "")) then
			RunConsoleCommand("say", "/"..v.command)
		end
	end
end)