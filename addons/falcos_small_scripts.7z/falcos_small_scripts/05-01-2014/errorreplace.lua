--[[
	MOD/lua/fscripts/errorreplace.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:33AM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Replaces eror models with a brick
---------------------------------------------------------------------------*/

CreateClientConVar("falco_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("falco_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/