--[[
	MOD/lua/fscripts/forcecommands.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:37AM]
	===BadFile===
]]

//require("cvar2")

function Falco_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("falco_bypass", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
concommand.Add("falco_forcevar", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)