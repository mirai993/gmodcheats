--[[
	MOD/lua/fscripts/newxrayvision.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:42AM]
	===BadFile===
]]

-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {
	["cluaeffect"] = true,
	["fog"] = true,
	["waterlodcontrol"] = true,
	["clientragdoll"] = true,
	["envtonemapcontroller"] = true,
	["entityflame"] = true,
	["func_tracktrain"] = true,
	["env_sprite"] = true,
	["env_spritetrail"] = true,
	["prop_effect"] = true,
	["class c_sun"] = true,
	["class C_ClientRagdoll"] = true,
	["class C_BaseAnimating"] = true,
	["clientside"] = true,
	["illusionary"] = true,
	["shadowcontrol"] = true,
	["keyframe"] = true,
	["wind"] = true,
	["gmod_wire_hologram"] = true,
	["effect"] = true,
	["stasisshield"] = true,
	["shadertest"] = true,
	["portalball"] = true,
	["portalskydome"] = true,
	["cattails"] = true
}

-- cvars
local repmat = CreateClientConVar("falco_xraymaterial", "mat1", true, false)
local PROPColor = CreateClientConVar("falco_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("falco_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("falco_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("falco_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("falco_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("falco_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off
	Falco_ForceVar("r_drawparticles", RayOn and 1 or 0)
	//Falco_ForceVar("r_3dsky", RayOn and 1 or 0)
	Falco_ForceVar("r_drawsprites", RayOn and 1 or 0)

	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end


			local model = ENTS[v]:GetModel() or ""
			local class = GetClass(ENTS[v])
			if NoDraws[class] or NoDraws[model] then -- Hide effects
				SetNoDraw(ENTS[v], false)
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("falcop_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	if NoDraws[class] or NoDraws[model] then
		SetNoDraw(v, true)
		return
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				PROPS[v]:SetRenderMode(RENDERMODE_TRANSALPHA)
				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				PLYS[v]:SetRenderMode(RENDERMODE_TRANSALPHA)
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end
