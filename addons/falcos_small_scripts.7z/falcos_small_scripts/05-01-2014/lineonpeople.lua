--[[
	MOD/lua/fscripts/lineonpeople.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:39AM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Drawing lines between the LocalPlayer and whatever target
with some gimmicks that really aren't that useful
---------------------------------------------------------------------------*/
FALCO_LineOnTarget = FALCO_LineOnTarget or {}

local function gunpos()
	local wep = LocalPlayer():GetViewModel()
	if not IsValid(wep) then return LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 100 end
	local att = wep:LookupAttachment("muzzle")
	if not wep:GetAttachment(att) then
		return LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 100
	end
	return wep:GetAttachment(att).Pos
end

local function Sanitize()
	for k,v in pairs(FALCO_LineOnTarget) do
		if not IsValid(v) then
			table.remove(FALCO_LineOnTarget, k)
		end
	end
end

local TargetLine = Material( "cable/new_cable_lit" )
local TargetColors = {Color(255, 0, 0, 255), Color(0, 0, 255, 255), Color(0, 255, 0, 255)}
local function DrawTargetLine()
	for k,v in pairs(FALCO_LineOnTarget) do

		if IsValid(v) then
			local APos, BPos = gunpos(), (v.GetShootPos and v:GetShootPos()) or v:GetPos()
			local distance = BPos:Distance(APos)
			cam.Start3D(EyePos(), EyeAngles())
				--render.SetMaterial(Material( "cable/chain" ))
				--render.SetMaterial(Material( "cable/new_cable_lit" ))
				--render.SetMaterial(Material("sprites/yellowlaser1"))
				--render.SetMaterial(Material("cable/cable_metalwinch01"))
				render.SetMaterial(TargetLine)
				render.DrawBeam(BPos, APos, 4, 0.01, distance/30, TargetColors[k % #TargetColors])
			cam.End3D()
		end
	end
end

local function settarget(ply, cmd, args)
	Sanitize()
	if args[1] == "all" then
		FALCO_LineOnTarget = table.Copy(player.GetAll())
		return
	else
		local target = Falco_FindPlayer(args[1]) or LocalPlayer():GetEyeTrace().Entity

		table.insert(FALCO_LineOnTarget, target)
	end

	hook.Add("HUDPaint", "LineOn", DrawTargetLine)
end
concommand.Add("falco_lineon", settarget)

local function RemoveTarget(ply, cmd, args)
	Sanitize()
	if args[1] and #FALCO_LineOnTarget > 1 then
		local target = Falco_FindPlayer(args[1])

		for a,b in pairs(FALCO_LineOnTarget) do
			if b == target then FALCO_LineOnTarget[a] = nil break end
		end
	else
		FALCO_LineOnTarget = {}
		hook.Remove("HUDPaint", "LineOn")
		hook.Remove("Think", "KillSurfer")
	end
end
concommand.Add("falco_lineoff", RemoveTarget)

hook.Add("PostGamemodeLoaded", "Falco_LineOnFAdmin", function()
	if not FAdmin then return end
	FAdmin.ScoreBoard.Player:AddActionButton("Falco Line", "FAdmin/icons/changeteam", Color(0, 200, 0, 255), true, function(ply, button)
		if not table.HasValue(FALCO_LineOnTarget, ply) then
			settarget(nil, nil, {ply:UserID()})
		else
			RemoveTarget(nil, nil, {ply:UserID()})
		end
	end)
end)