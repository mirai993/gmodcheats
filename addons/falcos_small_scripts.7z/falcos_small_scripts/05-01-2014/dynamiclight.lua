--[[
	MOD/lua/fscripts/dynamiclight.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:33AM]
	===BadFile===
]]

local function FDynamicLight()
	local dlight = DynamicLight( LocalPlayer():UserID() )
	if dlight then
		dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
		dlight.r = 255
		dlight.g = 255
		dlight.b = 255
		dlight.Brightness = 10
		dlight.Size = 700
		dlight.Decay = 0
		dlight.DieTime = CurTime() + 0.2
	end
end

local togglelight = true
concommand.Add("falcop_light", function()
	togglelight = not togglelight
	LocalPlayer():EmitSound("items/flashlight1.wav",100,100)
	if togglelight then
		Falco_ForceVar("mat_fullbright", 0)
		--hook.Remove("Think", "Falco_Light")
	else
		Falco_ForceVar("mat_fullbright", 1)
		--hook.Add("Think", "Falco_Light", FDynamicLight)
	end
end)