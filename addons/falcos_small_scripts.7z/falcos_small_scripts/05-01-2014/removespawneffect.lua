--[[
	MOD/lua/fscripts/removespawneffect.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:43AM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Removes the spawn effect of props
---------------------------------------------------------------------------*/

if SERVER then
	AddCSLuaFile("cl_OverridePropEffect.lua")
	return
end

local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)
