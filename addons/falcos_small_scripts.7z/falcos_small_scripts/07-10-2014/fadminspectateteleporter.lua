--[[
	MOD/lua/fscripts/fadminspectateteleporter.lua [#561 (#561), 4257944629, UID:751588758]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:46:30PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Teleport to a location where people won't annoy you
---------------------------------------------------------------------------*/
local locations = {
	["rp_downtown_v4c_v2"] = "1298, -4436, -198",
	["rp_downtown_v2"] = "1626, 2091, 225"
}
local function doTeleport()
	local map = string.lower(game.GetMap())

	if locations[map] then
		timer.Simple(0.2, function() RunConsoleCommand("FAdmin", "TPToPos", locations[map]) end)
	end
end
concommand.Add("falco_FAdminTeleport", doTeleport)