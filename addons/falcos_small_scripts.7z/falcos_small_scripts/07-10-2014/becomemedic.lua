--[[
	MOD/lua/fscripts/becomemedic.lua [#341 (#341), 2041540595, UID:2367281917]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:46:27PM]
	===BadFile===
]]

-- I use this every single time I join a server
local Medics = {"medic", "doctor", "krankenhaus", "accro77doctor", "paramedic"}

concommand.Add("falco_becomeMedic", function()
	for k,v in pairs(RPExtraTeams or {}) do
		if table.HasValue(Medics, string.lower(v.command or "")) then
			RunConsoleCommand("say", "/"..v.command)
		end
	end
end)
