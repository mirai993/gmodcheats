--[[
	MOD/lua/fscripts/togglebinds.lua [#661 (#661), 507957702, UID:1684360044]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:47:00PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Being able to toggle +/- commands can be useful at times
---------------------------------------------------------------------------*/
local togglecommands = {}
local function ToggleAPlusMinusCommand(ply,cmd,args)
	if not args[1] then print("enter an argument plz") return end
	if not togglecommands[args[1]] then togglecommands[args[1]] = false end
	if not togglecommands[args[1]] then
		RunConsoleCommand("+"..args[1])
	else
		RunConsoleCommand("-"..args[1])
	end
	togglecommands[args[1]] = not togglecommands[args[1]]
end
concommand.Add("falco_togglecmd", ToggleAPlusMinusCommand)