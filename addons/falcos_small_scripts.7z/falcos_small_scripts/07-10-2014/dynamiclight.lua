--[[
	MOD/lua/fscripts/dynamiclight.lua [#672 (#672), 1440563848, UID:1933151515]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:46:29PM]
	===BadFile===
]]

local function FDynamicLight()
	local dlight = DynamicLight( LocalPlayer():UserID() )
	if dlight then
		dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
		dlight.r = 255
		dlight.g = 255
		dlight.b = 255
		dlight.Brightness = 10
		dlight.Size = 700
		dlight.Decay = 0
		dlight.DieTime = CurTime() + 0.2
	end
end

local togglelight = true
concommand.Add("falcop_light", function()
	togglelight = not togglelight
	LocalPlayer():EmitSound("items/flashlight1.wav",100,100)
	if togglelight then
		Falco_ForceVar("mat_fullbright", 0)
		--hook.Remove("Think", "Falco_Light")
	else
		Falco_ForceVar("mat_fullbright", 1)
		--hook.Add("Think", "Falco_Light", FDynamicLight)
	end
end)