--[[
	MOD/lua/fscripts/forcecommands.lua [#285 (#285), 1542843843, UID:143092734]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:46:33PM]
	===BadFile===
]]

//require("cvar2")

function Falco_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("falco_bypass", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
concommand.Add("falco_forcevar", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)