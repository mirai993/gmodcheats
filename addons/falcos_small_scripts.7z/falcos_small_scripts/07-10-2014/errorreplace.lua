--[[
	MOD/lua/fscripts/errorreplace.lua [#1470 (#1470), 2266836079, UID:2841374090]
	Sleazy 90's Guy | STEAM_0:0:23754740 <109.146.41.66:27005> | [10.07.14 06:46:30PM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
Replaces eror models with a brick
---------------------------------------------------------------------------*/

CreateClientConVar("falco_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("falco_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/