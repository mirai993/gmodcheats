require("aspergers")

function AddFileCC( a, b, c )
	string.Replace(c[1], "/", "\\");
	Msg("Adding " .. c[1].. " data pack...\n")
	AddSEFile(c[1])
end

concommand.Add("se_add", AddFileCC)