concommand.Add("Players", function()
for k,v in pairs (player.GetAll()) do
print(v:Nick())
end
	end)

 local Convar = CreateClientConVar( "Nishack_Esp_Enabled", "0", true, false )
 local ConvarD = CreateClientConVar( "Nishack_Distance_Enabled", "0", true , false )
 local ConvarH = CreateClientConVar( "Nishack_Health_Enabled", "0" , true, false )
 local ConvarB = CreateClientConVar( "Nishack_Bunnyhop_Enabled" , "0" , true, false )
 local ConvarS = CreateClientConVar("Nishack_Skeleton_Enabled" , "0" , true , false)
 local ConvarC = CreateClientConVar("Nishack_Crosshair_Enabled" , "0" , true, false)
 local ConvarQ = CreateClientConVar("Nishack_Buyhealth_Enabled" , "0" , true, false)
 local ConvarR = CreateClientConVar("Nishack_Whenbuy" , "0" , true , false )
 local ConvarT = CreateClientConVar("Nishack_Triggerbot_Enabled", "0" , true , false)
 local ConvarR = CreateClientConVar("Nishack_Rphack_Enabled", "0" , true , false)
 local ConvarN = CreateClientConVar("Nishack_Npc_Enabled", "0", true, false)
 local ConvarP = CreateClientConVar("Nishack_Render_Enabled", "0" , true , false)
 local ConvarL = CreateClientConVar("Nishack_Barrel_Enabled", "0" , true , false)
 local ConvarZ = CreateClientConVar("Nishack_Light_Enabled" , "0" , true , false)
 local ConvarM = CreateClientConVar("Nishack_Light_Size" , "0" , true , false)
 local ConvarO = CreateClientConVar("Nishack_Light2_Enabled" , "0" , true , false)
 
 
 TrollTable={}
 TrollTable[1] = "~This server sucks!~"
 TrollTable[2] = "~Rick James.. Bitch~"
 TrollTable[3] = "~Lol~"
 TrollTable[4] = "~KAKAKAKAKAKAKAKAKAK~"
 TrollTable[5] = "~This ... Is ... SPARTAAAAA!!!~"
 TrollTable[6] = "MEN"
 TrollTable[7] = "WOMEN"
 TrollTable[8] = "FUCK YOU!"
 TrollTable[9] = "Wow, your cool BAITCH!"
 TrollTable[10] = "Nismo is the fucking best!"
 TrollTable[11] = "MEOOOOOOOOOOOW"
 
function Unlock()

for i = 1,5000 do achievements.Remover() end
for i = 1,1000 do achievements.BalloonPopped() end
for i = 1,200 do achievements.EatBall() end
for i = 1,1000 do achievements.IncBaddies() end
for i = 1,1000 do achievements.IncBystander() end
for i = 1,1000 do achievements.IncGoodies() end
for i = 1,1000 do achievements.SpawnedNPC() end
for i = 1,5000 do achievements.SpawnedProp() end
for i = 1,2000 do achievements.SpawnedRagdoll() end
for i = 1, 10000000 do achievements.SpawnMenuOpen() end

end

function Dynamiclight() -- A light that will follow you Good for Dark Places!!! - Nismo
local dlight = DynamicLight()
if ConvarZ:GetBool() then
if (dlight) then
dlight.Pos = LocalPlayer():GetPos()
dlight.r = 255
dlight.g = 255 
dlight.b = 255
dlight.Brightness = 4
dlight.Size = GetConVarNumber("Nishack_Light_Size")
dlight.Decay = 0 
dlight.DieTime = CurTime() + 0.1






			end
		end
	end
hook.Add("Think", "Dynamlight" , Dynamiclight)

function Dynamiclight2() -- A light that will follow you Good for Dark Places!!! - Nismo
local dlight = DynamicLight()
if ConvarO:GetBool() then
if (dlight) then
for k,v in pairs(player.GetAll()) do
NisColor211 = team.GetColor(v:Team())
dlight.Pos = v:GetPos()
dlight.r = NisColor211.r
dlight.g = NisColor211.g
dlight.b = NisColor211.b
dlight.Brightness = 4
dlight.Size = GetConVarNumber("Nishack_Light_Size")
dlight.Decay = 0 
dlight.DieTime = CurTime() + 0.1





				end
			end
		end
	end
hook.Add("Think", "Dynamlight2" , Dynamiclight2)




function playerRender()
if ConvarP:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles() ) 
v:DrawModel()
cam.End3D()
	end
   end
 end
end

hook.Add("HUDPaint" , "Notproud" , playerRender)

function Line()
if ConvarL:GetBool() then
for k,v in pairs(player.GetAll()) do
if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
cam.Start3D( EyePos() , EyeAngles())

render.SetMaterial( Material( "cable/physbeam" ) )

render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
cam.End3D()





	 end
	end
   end
 end
 hook.Add("HUDPaint","Linerzz", Line)


function Trigger()
local Target = LocalPlayer():GetEyeTrace().Entity
if (ConvarT:GetBool()) then
if (Target:IsNPC() or Target:IsPlayer()) then
RunConsoleCommand("+Attack")

else

RunConsoleCommand("-Attack")

end
end
end

hook.Add("Think", "Test", Trigger)

function Buyhealth()
if (ConvarQ:GetBool()) then
if (GetConVarNumber("Nishack_Whenbuy") > LocalPlayer():Health()) then
RunConsoleCommand("Say", "/buyhealth")



	end
   end
  end
hook.Add("Think","Nisbuyhealth",Buyhealth)

 
function Crosshair()
local x = ScrW() / 2
local y = ScrH() / 2
if ConvarC:GetBool() then

surface.SetDrawColor(255,174,0,255)

surface.DrawLine(x+5,y,x+25,y)
surface.DrawLine(x-5,y,x-25,y)
surface.DrawLine(x,y+5,x,y+25)
surface.DrawLine(x,y-5,x,y-25)

	end
	end
hook.Add("HUDPaint","Crosshair",Crosshair)


function Nisskeleton()
	if ConvarS:GetBool() then
	for k,v in pairs(player.GetAll()) do
NisColor21 = team.GetColor(v:Team())
		surface.SetDrawColor(NisColor21)
		local skelecore = {
		"ValveBiped.Bip01_Head1", 
		"ValveBiped.Bip01_Neck1", 
		"ValveBiped.Bip01_Spine4",
		"ValveBiped.Bip01_Spine2",
		"ValveBiped.Bip01_Spine1",
		"ValveBiped.Bip01_Spine"
		}	
		local skelearm_R = {
		"ValveBiped.Bip01_Neck1",
		"ValveBiped.Bip01_R_UpperArm", 
		"ValveBiped.Bip01_R_Forearm", 
		"ValveBiped.Bip01_R_Hand"
		}
		local skelearm_L = {
		"ValveBiped.Bip01_Neck1",
		"ValveBiped.Bip01_L_UpperArm",
		"ValveBiped.Bip01_L_Forearm",
		"ValveBiped.Bip01_L_Hand"
		}
		local skeleleg_R = {
		"ValveBiped.Bip01_Spine",
		"ValveBiped.Bip01_R_Thigh",
		"ValveBiped.Bip01_R_Calf",
		"ValveBiped.Bip01_R_Foot",
		"ValveBiped.Bip01_R_Toe0"
		}
		local skeleleg_L = {
		"ValveBiped.Bip01_Spine",
		"ValveBiped.Bip01_L_Thigh",
		"ValveBiped.Bip01_L_Calf",
		"ValveBiped.Bip01_L_Foot",
		"ValveBiped.Bip01_L_Toe0"
		}
		local curbone
		local nextbone
		for k,v in pairs (ents.GetAll()) do	
			if (v:IsPlayer()) and (v:Alive()) and (v:EntIndex() != LocalPlayer():EntIndex()) then
	
				for n,b in pairs(skelecore) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelecore[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end

				for n,b in pairs(skelearm_R) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_R[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				for n,b in pairs(skelearm_L) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skelearm_L[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
			
				for n,b in pairs(skeleleg_R) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_R[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
				for n,b in pairs(skeleleg_L) do
					curbone = v:GetBonePosition(v:LookupBone(b)):ToScreen()
					nextbone = v:GetBonePosition(v:LookupBone(tostring(skeleleg_L[n+1]))):ToScreen()
					surface.DrawLine( curbone.x, curbone.y, nextbone.x, nextbone.y)
				end
			end
		end
	end
 end
 end
 hook.Add("HUDPaint", "SkeletonHack", Nisskeleton)
 
function Bhop()
if ConvarB:GetBool() then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand("+Jump") 
timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
	end
	end
	end
	end
hook.Add("Think", "Nishack-Bunnyhoplol", Bhop)

function Drawesp()
if Convar:GetBool() then
for k, v in pairs ( player.GetAll() ) do
if ValidEntity( v ) then
if !( v == LocalPlayer() ) then
local playerlocation = v:EyePos():ToScreen()
NisColor1 = team.GetColor(v:Team())
if v:Alive() then

else
draw.SimpleText("*Dead*", "Nisfont15672", playerlocation.x, playerlocation.y-10,NisColor1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
draw.SimpleText(v:Nick(), "Nisfont15672", playerlocation.x, playerlocation.y,NisColor1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.CreateFont("coolvetica", 15 ,500, false ,false, "Nisfont15672")

if ConvarH:GetBool() then

local Playerhealth = v:Health()
surface.CreateFont("coolvetica", 14, 500, false , false, "My_font1561")
draw.SimpleText("Health: "..Playerhealth, "My_font1561", playerlocation.x, playerlocation.y+40,NisColor1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	end

if ConvarD:GetBool() then
local distance = v:GetShootPos():Distance(LocalPlayer():GetPos())
surface.CreateFont("coolvetica", 14, 500, false , false, "My_font1251")
draw.SimpleText("Distance: "..math.Round(distance), "My_font1251", playerlocation.x, playerlocation.y+20,NisColor1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	  end
     end
    end
   end
  end
 end

hook.Add( "HUDPaint", "Extra_sensory_perception", Drawesp )

NisColor = Color(0,255,255,255) 



function NpcEsp()
if ConvarN:GetBool() then
for k,v in pairs (ents.GetAll()) do

if (v:IsNPC()) then
surface.CreateFont("coolvetica", 14, 500, false , false, "My_fontQ15")
local Npclocation = v:EyePos():ToScreen()
local Npcname = v:GetClass()

draw.SimpleText(Npcname, "My_fontQ15", Npclocation.x , Npclocation.y,NisColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	end
   end
  end
 end
 hook.Add("HUDPaint", "NPC_ESP", NpcEsp)

 function NisRphack()
if ConvarR:GetBool() then
for k,v in pairs(ents.GetAll()) do
if ValidEntity(v) then
if (v:GetClass() == "reg_money_printer" or v:GetClass() == "money_printer" or v:GetClass() == "platinum_printer" or v:GetClass() == "golden_printer"
or v:GetClass() == "zz_money_printer" or v:GetClass() == "money_printer_commercial") then
local printerlocation = v:EyePos():ToScreen()
surface.CreateFont("coolvetica", 14, 500, false , false, "My_fontQ141")
draw.SimpleText("Printer", "My_fontQ141", printerlocation.x , printerlocation.y,Color(0,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	end
	end
	end
	end
hook.Add("HUDPaint","Rphack",NisRphack)

function Owner()
print("This hack was made by NISMO") -- MADE BY ME ( NISMO ) BIATCH!!
end
Owner()

NisMenuX = ScrW() / 2 - 250
NisMenuY = ScrH() / 2 - 200
NisMenuSizeX = 500
NisMenuSizeY = 450
concommand.Add("+Nis_Menu", function()
local Sheet = vgui.Create("DPropertySheet")
Sheet:SetPos( ScrW() / 2 - 220, ScrH() / 2 - 133 )
Sheet:SetSize( 400,400 )
Sheet:SetVisible( true )
Sheet:MakePopup()

local FirstTab = vgui.Create("DLabel")
FirstTab:SetParent( Sheet )
FirstTab:SetPos( 0 , 10 )
FirstTab:SetSize ( 360,430 )
FirstTab:SetText("")

local SecondTab = vgui.Create("DLabel")
SecondTab:SetParent( Sheet )
SecondTab:SetPos( 0 , 10 )
SecondTab:SetSize ( 360,430 )
SecondTab:SetText("")

local ThirdTab = vgui.Create("DLabel")
ThirdTab:SetParent( Sheet )
ThirdTab:SetPos( 0 , 10 )
ThirdTab:SetSize ( 360,430 )
ThirdTab:SetText("")

NisBack = vgui.Create("DImage", FirstTab)
NisBack:SetImage("Nishack/nismospray")
NisBack:SetSize(480,390)
NisBack:SetPos(2.5,15)

NisBack2 = vgui.Create("DImage", SecondTab)
NisBack2:SetImage("Nishack/nismospray")
NisBack2:SetSize(480,390)
NisBack2:SetPos(2.5,15)

NisBack3 = vgui.Create("DImage", ThirdTab)
NisBack3:SetImage("Nishack/nismospray")
NisBack3:SetSize(480,390)
NisBack3:SetPos(2.5,15)

NisLabel = vgui.Create("DLabel")
NisLabel:SetParent( FirstTab )
NisLabel:SetPos( 10 , 20 ) 
NisLabel:SetText("--Made by Nismo--")
NisLabel:SetTextColor( Color (255,204,0,255) )
NisLabel:SizeToContents()

NisLabel2 = vgui.Create("DLabel")
NisLabel2:SetParent( SecondTab )
NisLabel2:SetPos( 10 , 20 ) 
NisLabel2:SetText("--Miscellaneous Items--")
NisLabel2:SetTextColor( Color (255,204,0,255) )
NisLabel2:SizeToContents()

NisLabel3 = vgui.Create("DLabel")
NisLabel3:SetParent( FirstTab )
NisLabel3:SetPos( 10 , 190 ) 
NisLabel3:SetText("--Other Visuals--")
NisLabel3:SetTextColor( Color (255,204,0,255) )
NisLabel3:SizeToContents()

local NisSlider = vgui.Create( "DNumSlider", SecondTab )
NisSlider:SetPos(10,330)
NisSlider:SetWide(150)
NisSlider:SetText( "Rp Buyhealth Set" )
NisSlider:SetMin(0)
NisSlider:SetMax(100) 
NisSlider:SetDecimals(0) 
NisSlider:SetConVar("Nishack_Whenbuy") 

local NisSlider1 = vgui.Create( "DNumSlider", FirstTab )
NisSlider1:SetPos(288,330)
NisSlider1:SetWide(100)
NisSlider1:SetText( "Light-Size" )
NisSlider1:SetMin(0)
NisSlider1:SetMax(1000) 
NisSlider1:SetDecimals(0) 
NisSlider1:SetConVar("Nishack_Light_Size") 

local Box1 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box1:SetPos( 15,50 )
Box1:SetText( "Player Esp" )
Box1:SetConVar( "Nishack_Esp_Enabled" ) 
Box1:SetValue( GetConVarNumber("Nishack_Esp_Enabled") )
Box1:SizeToContents() 

local Box2 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box2:SetPos( 15,80 )
Box2:SetText( "Health detection" )
Box2:SetConVar( "Nishack_Health_Enabled" ) 
Box2:SetValue( GetConVarNumber("Nishack_Health_Enabled") )
Box2:SizeToContents() 

local Box3 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box3:SetPos( 15,110 )
Box3:SetText( "Distance detection" )
Box3:SetConVar( "Nishack_Distance_Enabled" ) 
Box3:SetValue( GetConVarNumber("Nishack_Distance_Enabled") )
Box3:SizeToContents() 

local Box4 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box4:SetPos( 15,140 )
Box4:SetText( "Npc Esp" )
Box4:SetConVar( "Nishack_Npc_Enabled" ) 
Box4:SetValue( GetConVarNumber("Nishack_Npc_Enabled") )
Box4:SizeToContents() 

local Box5 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box5:SetPos( 15,240 )
Box5:SetText( "Display Skeleton" )
Box5:SetConVar( "Nishack_Skeleton_Enabled" ) 
Box5:SetValue( GetConVarNumber("Nishack_Skeleton_Enabled") )
Box5:SizeToContents() 

local Box6 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box6:SetPos( 15,210 )
Box6:SetText( "Custom Crosshair" )
Box6:SetConVar( "Nishack_Crosshair_Enabled" ) 
Box6:SetValue( GetConVarNumber("Nishack_Crosshair_Enabled") )
Box6:SizeToContents() 

local Box7 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box7:SetPos( 15,170 )
Box7:SetText( "Money Printer Esp" )
Box7:SetConVar( "Nishack_Rphack_Enabled" ) 
Box7:SetValue( GetConVarNumber("Nishack_Rphack_Enabled") )
Box7:SizeToContents() 

local Box8 = vgui.Create( "DCheckBoxLabel", SecondTab )
Box8:SetPos( 15,50 )
Box8:SetText( "Bunnyhop" )
Box8:SetConVar( "Nishack_Bunnyhop_Enabled" ) 
Box8:SetValue( GetConVarNumber("Nishack_Bunnyhop_Enabled") )
Box8:SizeToContents() 

local Box9 = vgui.Create( "DCheckBoxLabel", SecondTab )
Box9:SetPos( 15,80 )
Box9:SetText( "Triggerbot" )
Box9:SetConVar( "Nishack_Triggerbot_Enabled" ) 
Box9:SetValue( GetConVarNumber("Nishack_Triggerbot_Enabled") )
Box9:SizeToContents() 

local Box10 = vgui.Create( "DCheckBoxLabel", SecondTab )
Box10:SetPos( 15,110 )
Box10:SetText( "Rp Autobuy health" )
Box10:SetConVar( "Nishack_Buyhealth_Enabled" ) 
Box10:SetValue( GetConVarNumber("Nishack_Buyhealth_Enabled") )
Box10:SizeToContents() 

local Box11 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box11:SetPos( 15,270 )
Box11:SetText( "Player - Chams" )
Box11:SetConVar( "Nishack_Render_Enabled" ) 
Box11:SetValue( GetConVarNumber("Nishack_Render_Enabled") )
Box11:SizeToContents() 

local Box12 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box12:SetPos( 15,300 )
Box12:SetText( "Barrel-Hack" )
Box12:SetConVar( "Nishack_Barrel_Enabled" ) 
Box12:SetValue( GetConVarNumber("Nishack_Barrel_Enabled") )
Box12:SizeToContents()

local Box13 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box13:SetPos( 15,325 )
Box13:SetText( "Dynamic-Light" )
Box13:SetConVar( "Nishack_Light_Enabled" ) 
Box13:SetValue( GetConVarNumber("Nishack_Light_Enabled") )
Box13:SizeToContents()

local Box14 = vgui.Create( "DCheckBoxLabel", FirstTab )
Box14:SetPos( 15,345 )
Box14:SetText( "On-Players" )
Box14:SetConVar( "Nishack_Light2_Enabled" ) 
Box14:SetValue( GetConVarNumber("Nishack_Light2_Enabled") )
Box14:SizeToContents()

local button = vgui.Create( "DButton", SecondTab )
	button:SetSize( 70, 20 )
	button:SetPos( 35, 140 )
	button:SetText( "Antigag" )
	button.DoClick = function()
	surface.PlaySound("buttons/button24.wav")
hook.Remove( "PlayerBindPress", "ULXGagForce" ) timer.Destroy( "GagLocalPlayer")
	end
	
local button1 = vgui.Create( "DButton", SecondTab )
	button1:SetSize( 70, 20 )
	button1:SetPos( 35, 170 )
	button1:SetText( "Troll" )
	button1.DoClick = function()
	surface.PlaySound("buttons/button24.wav")
local i = math.random(1,11)
RunConsoleCommand("Say", TrollTable[i])
	end
 
local button1 = vgui.Create( "DButton", SecondTab )
	button1:SetSize( 70, 20 )
	button1:SetPos( 35, 200 )
	button1:SetText( "Hl2 Song" )
	button1.DoClick = function()
surface.PlaySound( "/music/hl2_song20_submix0.mp3" )
	end
	
local button2 = vgui.Create( "DButton", SecondTab )
	button2:SetSize( 70, 20 )
	button2:SetPos( 35, 230 )
	button2:SetText( "Unlock All" )
	button2.DoClick = function()
surface.PlaySound( "buttons/button24.wav" )
Unlock()
	end
	
local button3 = vgui.Create( "DButton", SecondTab )
	button3:SetSize( 70, 20 )
	button3:SetPos( 35, 260 )
	button3:SetText( "BarrelBomb" )
	button3.DoClick = function()
surface.PlaySound( "buttons/button24.wav" )
for i = 1,100 do
LocalPlayer():ConCommand("Gm_spawn models/props_c17/oildrum001_explosive.mdl")
	end
   end



Sheet:AddSheet( "Visuals", FirstTab, "gui/silkicons/emoticon_smile", false, false, "Visual hacks" )
Sheet:AddSheet( "Misc", SecondTab, "gui/silkicons/star", false, false, "Misc" )
Sheet:AddSheet( "Coming Soon!", ThirdTab, "gui/silkicons/picture_edit", false, false, "Menu Settings" )





concommand.Add("-Nis_Menu",function()

Sheet:SetVisible(false)


end )

end )
















