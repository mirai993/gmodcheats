concommand.Add("Players", function()
for k,v in pairs (player.GetAll()) do
print(v:Nick())
end
	end)

 local Convar = CreateClientConVar( "Nishack_Esp_Enabled", "0", true, false )
 local ConvarD = CreateClientConVar( "Nishack_Distance_Enabled", "0", true , false )
 local ConvarH = CreateClientConVar( "Nishack_Health_Enabled", "0" , true, false )
function Drawesp()
local NisColor = Color(242,149,10,255)  

if Convar:GetBool() then
for k, v in pairs ( player.GetAll() ) do
if ValidEntity( v ) then
if !( v == LocalPlayer() ) then
local playerlocation = v:EyePos():ToScreen()

draw.SimpleText(v:Nick(), "Nisfont1", playerlocation.x, playerlocation.y,NisColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.CreateFont("coolvetica", 15 ,500, false ,false, "Nisfont1")

if ConvarH:GetBool() then
local Playerhealth = v:Health()
surface.CreateFont("coolvetica", 15, 500, false , false, "My_font1")
draw.SimpleText("Health: "..Playerhealth, "My_font1", playerlocation.x, playerlocation.y+40,NisColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

end

if ConvarD:GetBool() then
local distance = v:GetShootPos():Distance(LocalPlayer():GetPos())
surface.CreateFont("coolvetica", 15, 500, false , false, "My_font12")
draw.SimpleText("Distance: "..math.Round(distance), "My_font1", playerlocation.x, playerlocation.y+20,NisColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	  end
     end
    end
   end
  end
 end

hook.Add( "HUDPaint", "Extra_sensory_perception", Drawesp )

local ConvarN = CreateClientConVar("Nishack_Npc_Enabled", "0", true, false)
function NpcEsp()
local NisColor = Color(242,149,10,255)
if ConvarN:GetBool() then

for k,v in pairs (ents.GetAll()) do

if (v:IsNPC()) then
surface.CreateFont("coolvetica", 15, 500, false , false, "My_fontQ")
local Npclocation = v:EyePos():ToScreen()
local Npcname = v:GetClass()

draw.SimpleText(Npcname, "My_fontQ", Npclocation.x , Npclocation.y,NisColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

end
end
end
end
hook.Add("HUDPaint", "NPC_ESP", NpcEsp)

function NisHackMenu()
local NisMenu = vgui.Create( "DFrame" )
NisMenu:SetPos( 375,450 )
NisMenu:SetSize( 250, 250 )
NisMenu:SetTitle( "NisMenu" )
NisMenu:SetVisible( true )
NisMenu:SetDraggable( true )
NisMenu:ShowCloseButton( true )
NisMenu:MakePopup()

NisBack = vgui.Create("DImage", NisMenu)
NisBack:SetImage("Nishack/nismospray")
NisBack:SetSize(250,245)
NisBack:SetPos(0,18)

    local BoxOne = vgui.Create( "DButton")
	BoxOne:SetParent( NisMenu )
    BoxOne:SetText( "Player Esp" )
	BoxOne:SetPos(25,35)
	BoxOne:SetSize(75,25)
  BoxOne.DoClick = function()
  RunConsoleCommand("Nishack_Esp_Enabled", 1)
  end
  BoxOne.DoRightClick = function()
  RunConsoleCommand("Nishack_Esp_Enabled", 0)
  end
  
  local BoxTwo = vgui.Create( "DButton")
	BoxTwo:SetParent( NisMenu )
    BoxTwo:SetText( "Npc Esp" )
	BoxTwo:SetPos(150,35)
	BoxTwo:SetSize(50,25)
  BoxTwo.DoClick = function()
  RunConsoleCommand("Nishack_Npc_Enabled", 1)
  end
  BoxTwo.DoRightClick = function()
  RunConsoleCommand("Nishack_Npc_Enabled", 0)
  end
  
    local BoxThree = vgui.Create( "DButton")
	BoxThree:SetParent( NisMenu )
    BoxThree:SetText( "Health Esp" )
	BoxThree:SetPos(150,170)
	BoxThree:SetSize(65,25)
  BoxThree.DoClick = function()
  RunConsoleCommand("Nishack_Health_Enabled", 1 )
  end
  BoxThree.DoRightClick = function()
  RunConsoleCommand("Nishack_Health_Enabled",0)
  end
  
    local BoxFour = vgui.Create( "DButton")
	BoxFour:SetParent( NisMenu )
    BoxFour:SetText( "Distance Esp" )
	BoxFour:SetPos(25,170)
	BoxFour:SetSize(80,25)
  BoxFour.DoClick = function()
  RunConsoleCommand("Nishack_Distance_Enabled", 1)
  end
  BoxFour.DoRightClick = function()
  RunConsoleCommand("Nishack_Distance_Enabled", 0)
  end
 


end

concommand.Add("NisMenu", NisHackMenu)


















































