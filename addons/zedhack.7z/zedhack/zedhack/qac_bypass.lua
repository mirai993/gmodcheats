--[[
	MOD/lua/zedHack/qac_bypass.lua [#209 (#219), 1652883608, UID:1275165609]
	IZED | STEAM_0:0:45642859 <79.207.204.195:27006> | [29.06.14 09:28:33PM]
	===BadFile===
]]

debug.getinfo = function(v)
	return
end
local oldPairs = pairs
pairs = function(v)
	print(debug.getinfo(2).name)
	if(debug.getinfo(2).name == "scan_func")then
		return oldPairs({})
	end
	return oldPairs(v)
end