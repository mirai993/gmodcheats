--[[
	MOD/lua/zedHack/qac_banme.lua [#252 (#254), 43771716, UID:1047302089]
	IZED | STEAM_0:0:45642859 <79.207.204.195:27006> | [29.06.14 09:28:32PM]
	===BadFile===
]]

net.Start('checksaum')
	net.WriteString("Eine Ode an Neo: Du solltest mal wirklich zum Psychiater und dich auf deine narzistische Persönlichkeitsstöreung untersuchen lassen. Liebe Grüße: Deine Bekannten, die Communitygebannten.")
net.SendToServer()