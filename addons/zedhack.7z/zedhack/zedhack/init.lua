--[[
	MOD/lua/zedHack/init.lua [#22517 (#23215), 1597353264, UID:2932523382]
	IZED | STEAM_0:0:45642859 <79.207.204.195:27006> | [29.06.14 09:28:32PM]
	===BadFile===
]]


/******************************
Name: Notify/Prints
******************************/
function Print ( msg )
	print ("[ZED]: "..tostring(msg))
end

function ChatPrint ( msg, color )
	chat.AddText ( color, "[ZED] "..tostring(msg) )
end

function Notify ( msg, time )
	GAMEMODE:AddNotify ( tostring(msg), NOTIFY_GENERIC, time )
end


/*****************************
Name: Globals
*****************************/
--== Player ==--
ply												= LocalPlayer()

--== Colors ==--
local red                                       = ( Color(255,0,0,255) )
local lightred                                  = ( Color(255,100,100,255) )
local black                                     = ( Color(0,0,0,255) )
local green                                     = ( Color(0,255,0,255) )
local darkgreen                                 = ( Color(0,200,0,255) )
local white                                     = ( Color(255,255,255,255) )
local blue                                      = ( Color(0,0,255,255) )
local gold                                      = ( Color(255,228,0,255) )
local lightblue                                 = ( Color(116,187,251,255) )

--Transparent--
local tred                                      = ( Color(150,0,0,125) )
local tblack                                    = ( Color(0,0,0,225) )
local tgreen                                    = ( Color(0,150,0,125) )
local tblue                                     = ( Color(0,0,150,125) )
local trans                                     = ( Color(0,0,0,0) )

--Special--
local ttred                                     = ( Color(175,0,0,150) )


local volume									= 0.60
ply:ConCommand("volume 0.6")


--Tables--
SW = {}
Commands = {}
old = {}
Spectators = { }

--Keypad Logger--
KPL = {}
KPL.X = -50
KPL.Y = -100
KPL.KeyPos =  {      
        {KPL.X+5, KPL.Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
        {KPL.X+37.5, KPL.Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
        {KPL.X+70, KPL.Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
 
        {KPL.X+5, KPL.Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
        {KPL.X+37.5, KPL.Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
        {KPL.X+70, KPL.Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
 
        {KPL.X+5, KPL.Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
        {KPL.X+37.5, KPL.Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
        {KPL.X+70, KPL.Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
 
        {KPL.X+5, KPL.Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6},
        {KPL.X+60, KPL.Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}

--Fonts--
local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
end

/*****************************
Name: ConVars
*****************************/
CreateClientConVar( "zed_playeresp", 0, true, false )
CreateClientConVar( "zed_playeresp_money", 0, true, false )
CreateClientConVar( "zed_playeresp_job", 0, true, false )
CreateClientConVar( "zed_playeresp_health", 0, true, false )
CreateClientConVar( "zed_playeresp_range", 2000, true, false )
CreateClientConVar( "zed_keypadesp", 0, true, false )
CreateClientConVar( "zed_lognet_write", 0, true, false )
CreateClientConVar( "zed_lognet_read", 0, true, false )
CreateClientConVar( "zed_printeresp", 0, true, false )

/*****************************
Name: Functions
*****************************/

function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end
function FindDisplayText(ent)
        if ent.GetDisplayText then
                return ent:GetDisplayText()
        else
                return ent.Entity:GetNetworkedInt("keypad_num")
        end
end
function FindStatus(ent)
        if ent.GetStatus then
                return ent:GetStatus()
        elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 1
        elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
                return 2
        else
                return 0
        end
end
function HookNet()
	old.Receive = net.Receive
	net.Receive = function(name, callback)
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("Receive: " .. name) end
		return old.Receive(name,callback)
	end
	old.Start = net.Start
	net.Start = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("Start: " .. v) end
		return old.Start(v)
	end
	-- READ
	old.ReadAngle = net.ReadAngle
	net.ReadAngle = function()
		ret = old.ReadAngle()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadAngle: " .. tostring(ret)) end
		return ret
	end
	old.ReadBit = net.ReadBit
	net.ReadBit = function()
		ret = old.ReadBit()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadBit: " .. tostring(ret)) end
		return ret
	end
	old.ReadData = net.ReadData
	net.ReadData = function(v)
		ret = old.ReadData(v)
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadData: " .. tostring(ret)) end
		return ret
	end
	old.ReadDouble = net.ReadDouble
	net.ReadDouble = function()
		ret = old.ReadDouble()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadDouble: " .. tostring(ret)) end
		return ret
	end
	old.ReadEntity = net.ReadEntity
	net.ReadEntity = function()
		ret = old.ReadEntity()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadEntity: " .. tostring(ret)) end
		return ret
	end
	old.ReadFloat = net.ReadFloat
	net.ReadFloat = function()
		ret = old.ReadFloat()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadFloat: " .. tostring(ret)) end
		return ret
	end
	old.ReadHeader = net.ReadHeader
	net.ReadHeader = function()
		ret = old.ReadHeader()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadHeader: " .. tostring(util.NetworkIDToString(ret))) end
		return ret
	end
	old.ReadInt = net.ReadInt
	net.ReadInt = function(v)
		ret = old.ReadInt(v)
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadInt: " .. tostring(ret) .. " - " .. tostring(v)) end
		return ret
	end
	old.ReadNormal = net.ReadNormal
	net.ReadNormal = function()
		ret = old.ReadNormal()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadNormal: " .. tostring(ret)) end
		return ret
	end
	old.ReadString = net.ReadString
	net.ReadString = function()
		ret = old.ReadString()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadString: " .. tostring(ret)) end
		return ret
	end
	old.ReadTable = net.ReadTable
	net.ReadTable = function()
		ret = old.ReadTable()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadTable: " .. tostring(ret)) end
		return ret
	end
	old.ReadType = net.ReadType
	net.ReadType = function(v)
		ret = old.ReadType(v)
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadType: " .. tostring(ret) .. " - " .. tostring(v)) end
		return ret
	end
	old.ReadUInt = net.ReadUInt
	net.ReadUInt = function(v)
		ret = old.ReadUInt(v)
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadUInt: " .. tostring(ret) .. " - " .. tostring(v)) end
		return ret
	end
	old.ReadVector = net.ReadVector
	net.ReadVector = function()
		ret = old.ReadVector()
		if(GetConVarNumber("zed_lognet_read") == 1)then Print("ReadVector: " .. tostring(ret)) end
		return ret
	end
	-- WRITE
	old.WriteAngle = net.WriteAngle
	net.WriteAngle = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteAngle: " .. tostring(v)) end
		return old.WriteAngle(v)
	end
	old.WriteBit = net.WriteBit
	net.WriteBit = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteBit: " .. tostring(v)) end
		return old.WriteBit(v)
	end
	old.WriteData = net.WriteData
	net.WriteData = function(v, length)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteData: " .. tostring(v)) end
		return old.WriteData(v, length)
	end
	old.WriteDouble = net.WriteDouble
	net.WriteDouble = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteDouble: " .. tostring(v)) end
		return old.WriteDouble(v)
	end
	old.WriteEntity = net.WriteEntity
	net.WriteEntity = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteEntity: " .. tostring(v)) end
		return old.WriteEntity(v)
	end
	old.WriteFloat = net.WriteFloat
	net.WriteFloat = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteFloat: " .. tostring(v)) end
		return old.WriteFloat(v)
	end
	old.WriteInt = net.WriteInt
	net.WriteInt = function(v,v2)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteInt: " .. tostring(v) .. " - " .. tostring(v2)) end
		return old.WriteInt(v,v2)
	end
	old.WriteNormal = net.WriteNormal
	net.WriteNormal = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteNormal: " .. tostring(v)) end
		return old.WriteNormal(v)
	end
	old.WriteString = net.WriteString
	net.WriteString = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteString: " .. tostring(v)) end
		return old.WriteString(v)
	end
	old.WriteTable = net.WriteTable
	net.WriteTable = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteTable: " .. tostring(v)) end
		return old.WriteTable(v)
	end
	old.WriteType = net.WriteType
	net.WriteType = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteType: " .. tostring(v)) end
		return old.WriteType(v)
	end
	old.WriteUInt = net.WriteUInt
	net.WriteUInt = function(v,v2)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteUInt: " .. tostring(v) .. " - " .. tostring(v2)) end
		return old.WriteUInt(v,v2)
	end
	old.WriteVector = net.WriteVector
	net.WriteVector = function(v)
		if(GetConVarNumber("zed_lognet_write") == 1)then Print("WriteVector: " .. tostring(v)) end
		return old.WriteVector(v)
	end
end
function UnHookNet()
	net.Receive = old.Receive
	net.Start = old.Start
	
	net.ReadAngle = old.ReadAngle
	net.ReadBit = old.ReadBit
	net.ReadData = old.ReadData
	net.ReadDouble = old.ReadDouble
	net.ReadEntity = old.ReadEntity
	net.ReadFloat = old.ReadFloat
	net.ReadInt = old.ReadInt
	net.ReadNormal = old.ReadNormal
	net.ReadString = old.ReadString
	net.ReadTable = old.ReadTable
	net.ReadType = old.ReadType
	net.ReadUInt = old.ReadUInt
	net.ReadVector = old.ReadVector
	net.ReadHeader = old.ReadHeader
	
	net.WriteAngle = old.WriteAngle
	net.WriteBit = old.WriteBit
	net.WriteData = old.WriteData
	net.WriteDouble = old.WriteDouble
	net.WriteEntity = old.WriteEntity
	net.WriteFloat = old.WriteFloat
	net.WriteInt = old.WriteInt
	net.WriteNormal = old.WriteNormal
	net.WriteString = old.WriteString
	net.WriteTable = old.WriteTable
	net.WriteType = old.WriteType
	net.WriteUInt = old.WriteUInt
	net.WriteVector = old.WriteVector
end


/*****************************
Name: SpiritWalk
*****************************/

SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
 
function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles
               
                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 4 end
       
        SW.Velocity = SW.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        Print( "SpiritWalk " .. status[ SW.Enabled ] )
end


/*****************************
Name: ESP
*****************************/
function ESP()
	for _, ent in pairs(ents.GetAll()) do
		if IsValid(ent) then
			if(GetConVarNumber("zed_playeresp") == 1)then  --PlayerESP--
				if ent:IsPlayer() and ent != ply then
					PlayerESP(ent)
				end
			end
			if(GetConVarNumber("zed_printeresp") == 1)then  --PlayerESP--
				if ent:GetClass() == "money_pearl_printer" then
					PrinterESP(ent)
				end
			end
			if(GetConVarNumber("zed_keypadesp") == 1)then  --KeypadESP--
				KeypadESP(ent)
			end
		end
	end
end

function DrawText(text, posx, posy, color)
	draw.DrawText(text, "Herp", posx, posy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
end

function DrawOutlinedText(text, posx, posy, color)
	draw.SimpleTextOutlined(text, "ESPFont_Small", posx, posy, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black)
end

function DrawRoundedBox(posx, posy, sizex, sizey, color)
	draw.RoundedBox( 5, posx, posy, sizex, sizey, color) 
end

function PrinterESP(ent)
	local entpos = ent:GetPos():ToScreen()
	local X = entpos.x
	local Y = entpos.y - 50
	DrawText("Printer", X, Y, Color(100, 100, 220, 255))
end
function PlayerESP(ent)
	local dist = ply:GetPos():Distance(ent:GetPos()) / 50
	dist = round(dist, 0)
	if(dist <= GetConVarNumber("zed_playeresp_range"))then
		local entpos = ent:GetPos():ToScreen()
		local X = entpos.x
		local Y = entpos.y - 50
		if ent:GetFriendStatus() == "friend" then
			DrawText(ent:Nick() .. " [" .. dist .. "]", X, Y, Color(100, 255, 100, 255))
		else
			DrawText(ent:Nick() .. " [" .. dist .. "]", X, Y, Color(255, 100, 100, 255))
		end
		if(GetConVarNumber("zed_playeresp_money") == 1)then
			local playermoney = (ent.DarkRPVars and ent.DarkRPVars.money) or 0
			Y = Y + 10
			DrawText("$"..playermoney, X, Y, Color(255, 200, 200, 255))
		end
		if(GetConVarNumber("zed_playeresp_job") == 1)then
			if(ent.DarkRPVars and ent.DarkRPVars.job)then
				local job = ent.DarkRPVars.job
				Y = Y + 10
				DrawText(job, X, Y, Color(255, 200, 200, 255))
			end
		end
		if(GetConVarNumber("zed_playeresp_health") == 1)then
			Y = Y + 10
			DrawText(ent:Health() .. "%", X, Y, Color(255, 200, 200, 255))
		end
	end
end
function KeypadESP(ent)
	if string.find(ent:GetClass(), "keypad") and not(string.find(ent:GetClass(), "cracker") or string.find(ent:GetClass(), "checker")) then
		local screenPos = ent:GetPos():ToScreen()
		if screenPos.x > 0 and
		screenPos.y > 0 and
		screenPos.x < ScrW() and
		screenPos.y < ScrH() then
			local pos = screenPos
			if IsValid(ent) and ent.code and (SW.ViewOrigin:Distance(ent:GetPos())<500 or ply:GetPos():Distance(ent:GetPos())<500) then
					local ctext = ent.code or "Unkown"
					DrawText( ctext, pos.x-25, pos.y-25, Color(100,100,255,255) )
			elseif IsValid(ent) and ent.code then
				DrawRoundedBox( pos.x-5, pos.y-5, 10, 10, Color( 0, 255, 0, 150 ) )
			else
				DrawRoundedBox( pos.x-5, pos.y-5, 10, 10, Color( 255, 0, 0, 150 ) )
			end
		end
	end
	
	if ent:IsPlayer() then
		v = ent
		local kp = v:GetEyeTrace().Entity
		if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
			kp.tempCode = kp.tempCode or ""
			kp.tempText = kp.tempText or ""
			kp.tempStatus = kp.tempStatus or 0
	   
			if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
				kp.tempText = FindDisplayText(kp)
				kp.tempStatus = FindStatus(kp)
			   
				local tr = util.TraceLine({
						start = v:EyePos(),
						endpos = v:GetAimVector() * 32 + v:EyePos(),
						filter = v
				})
			   
				local pos = kp:WorldToLocal(tr.HitPos)
		   
				for i,p in pairs(KPL.KeyPos) do
					local x = (pos.y - p[5]) / (p[5] + p[6])
					local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
					if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
						if i == 11 then
							if kp.tempStatus == 1 then
								kp.code = kp.tempCode
								kp.tempCode = ""
							elseif kp.tempStatus == 2 then
								kp.tempCode = ""
							end
						elseif i == 10 then
							kp.tempCode = ""
						elseif i > 0 then
							kp.tempCode = kp.tempCode..i
						end
					end
				end
			end
		end
	end
end

/*****************************
Name: SpectatorCheck
*****************************/
function CheckSpectators()
		for k, v in pairs(player.GetAll()) do
                if IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() then
				    if(not table.HasValue(Spectators, v)) then
                        table.insert(Spectators, v);
					surface.PlaySound("buttons/blip1.wav")
					Notify(v:GetName().." is now spectating: "..v:GetObserverTarget():GetName())
					Print ( v:GetName().." is now spectating: "..v:GetObserverTarget():GetName())
					ChatPrint ( v:GetName().." is now spectating: "..v:GetObserverTarget():GetName())
				end
			end
		end
		
      for k, v in pairs(Spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() ) then
                        table.remove(Spectators, k);
							Notify(v:GetName().." is not spectating anymore!")
							Print ( v:GetName().." is not spectating anymore!")
							ChatPrint ( v:GetName().." is not spectating anymore!")
				end
		end
end
function PrintSpectators()
	for k, v in pairs(player.GetAll()) do
		if IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() then
			Notify(v:GetName().." is spectating: "..v:GetObserverTarget():GetName())
			Print ( v:GetName().." is spectating: "..v:GetObserverTarget():GetName())
			ChatPrint ( v:GetName().." is spectating: "..v:GetObserverTarget():GetName())
		end
	end
end


/*****************************
Name: Think
*****************************/

function Think()
	CheckSpectators()
end

/*****************************
Name: Hooks
*****************************/

function Hook()
	old.RunConsoleCommand = RunConsoleCommand;
	RunConsoleCommand = function(...)
		print("[ZED] Command: ",...)
		old.RunConsoleCommand(...)
	end
	HookNet()
	hook.Add( "CalcView", "ZED_SW", SW.CalcView )
	hook.Add( "CreateMove", "ZED_SW", SW.CreateMove )					
	hook.Add("Think", "ZED_THINK", Think )
	hook.Add("HUDPaint", "ZED_ESP", ESP )
	hook.Add("PlayerDeath", "ZED_PLAYERDEATH", PlayerDeath )
	Print("Hooked.")
end
function UnHook()
	RunConsoleCommand = old.RunConsoleCommand
	UnHookNet()
	hook.Remove( "CalcView", "ZED_SW" )
	hook.Remove( "CreateMove", "ZED_SW" )					
	hook.Remove("Think", "ZED_THINK" )
	hook.Remove("HUDPaint", "ZED_ESP" )
	hook.Remove("PlayerDeath", "ZED_PLAYERDEATH" )
	Print("Unhooked.")
end

/*****************************
Name: Commands
*****************************/	
concommand.Add("zed_togglesw", SW.Toggle)
concommand.Add("zed_vars", function() 
	for _, ent in pairs(ents.GetAll()) do
		if IsValid(ent) then
			Print(tostring(ent:GetClass()))
		end
	end
end)
concommand.Add("zed_swpos", function() print( SW.ViewOrigin ) end)
concommand.Add("zed_hook", Hook)
concommand.Add("zed_unhook", UnHook)
concommand.Add("zed_spectators", PrintSpectators)


/***************************
Name: GRP Commands
***************************/
local _IdentCode = "q&$]s9w=(fF~sDN4)QJ&nC&yF;fA(]?#7V8~s86;.,)pCp}c5n8}P}a/9ggH&[xT"
concommand.Add("grp_spawncar", function(ply,cmd,args)
	for k, v in pairs( player.GetAll() ) do
		if IsValid(v) then
			print(v:Name())
			if string.find(string.lower(v:Name()), string.lower(args[1])) then
				for unique, data in pairs(GetTheStoredTable()) do
					if string.find(string.lower(data.Name), string.lower(args[2])) then
						print(data.Name)
						net.Start('SpawnCar')
						net.WriteEntity(v)
						net.WriteString(data.Script)
						if not (args[3] == nil) then
							net.WriteString(args[3])
						else
							net.WriteString(data.Model)
						end
						net.WriteString(data.Name)
						net.WriteString(data.Class)
						net.WriteString(_IdentCode)
						net.SendToServer()
					end
				end	
			end
		end
	end
end)
concommand.Add("grp_givemoney", function(ply,cmd,args)
	for k, v in pairs( player.GetAll() ) do
		if IsValid(v) then
			if string.find(string.lower(v:Name()), string.lower(args[1])) then
				local bought = false
				for unique, data in pairs(GetTheStoredTable()) do
					if not bought then
						--[[net.Start('Sell')
							net.WriteFloat(tonumber(args[2]) * 2)
							net.WriteEntity(v)
							net.WriteString("your soul")
							net.WriteString(_IdentCode)
						net.SendToServer()]]
						net.Start('BuyCar')
							net.WriteFloat(-1 * tonumber(args[2]))
							net.WriteEntity(v)
							net.WriteString(data.Script)
							net.WriteString(data.Model)
							net.WriteString(data.Name)
							net.WriteString(_IdentCode)
						net.SendToServer()
						bought = true
					end
				end	
			end
		end
	end
end)
concommand.Add("grp_giveall", function(ply,cmd,args)
	for k, v in pairs( player.GetAll() ) do
		if IsValid(v) then
			local bought = false
			for unique, data in pairs(GetTheStoredTable()) do
				if not bought then
					net.Start('BuyCar')
						net.WriteFloat(-1 * tonumber(args[1]))
						net.WriteEntity(v)
						net.WriteString(data.Script)
						net.WriteString(data.Model)
						net.WriteString(data.Name)
						net.WriteString(_IdentCode)
					net.SendToServer()
					bought = true
				end
			end	
		end
	end
end)

 