--[[
	MOD/lua/chack/wallhack.lua
	Calver | STEAM_0:0:36375256 <2.101.7.227:27005> | [21-02-14 02:09:19AM]
	===BadFile===
]]

hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs ( player.GetAll() ) do
 local tblFonts = { }
tblFonts["DebugFixed"] = {
	font = "Courier New",
	size = 10,
	weight = 500,
	antialias = true,
	
	for k,v in SortedPairs( tblFonts ) do
	surface.CreateFont( k, tblFonts[k] );

	--print( "Added font '"..k.."'" );
end
}

		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Name = ""
 
		if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
		draw.DrawText( Name, "DebugFixed", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
	end
 
end )