/*************************************************************
	   __ __                        
	  / // /___  ____ __ _  ___  ___
	 / _  // -_)/ __//  ' \/ -_)(_-<
	/_//_/ \__//_/  /_/_/_/\__//___/
	
	Name: menusystem/_createitem.lua
	Purpose: Create new GUI item
*************************************************************/

HERMES.menusystem = {}

HERMES.include( "checkbox.lua" )
HERMES.include( "numberbox.lua" )

/* --------------------
	:: Menu
*/ --------------------
function HERMES.Menu()
	local panel = vgui.Create( "DFrame" )
	panel:SetPos( ScrW() / 2 - 450 / 2, ScrH() / 2 - 350 / 2 )
	panel:SetSize( 450, 350 )
	panel:SetTitle( "HERMES" )
	panel:SetVisible( true )
	panel:SetDraggable( true )
	panel:ShowCloseButton( true )
	panel:MakePopup()
	
	local checkbox = HERMES:CheckBox( "Recoil", "Recoil" )
	checkbox:SetParent( panel )
	checkbox:SetPos( 10, 50 )
	
	local checkbox = HERMES:CheckBox( "No Visual Recoil", "No Visual Recoil" )
	checkbox:SetParent( panel )
	checkbox:SetPos( 10, 70 )
	
	local numberbox = HERMES:NumberBox( "ss", "FOV" )
	numberbox:SetParent( panel )
	numberbox:SetPos( 10, 120 )
	numberbox:SetMin( 0 )
	numberbox:SetMax( 100 )
end

HERMES:AddCommand( "+hermes_menu", HERMES.Menu )