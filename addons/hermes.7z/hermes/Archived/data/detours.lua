/*************************************************************
	   __ __                        
	  / // /___  ____ __ _  ___  ___
	 / _  // -_)/ __//  ' \/ -_)(_-<
	/_//_/ \__//_/  /_/_/_/\__//___/
	
	Name: detours.lua
	Purpose: Hack protection
*************************************************************/
local ply, vars = HERMES.GetSelf, table.Copy( HERMES.vars )
local x, y = ScrW(), ScrH()

local detour = {}

vars._RAWSET( _G, "__metatable", false )
vars._RAWSET( hook, "__metatable", false )
vars._RAWSET( concommand, "__metatable", false )

vars._RAWSET( _G, "__eq", true )
vars._RAWSET( hook, "__eq", true )
vars._RAWSET( concommand, "__eq", true )

/* --------------------
	:: HERMES
*/ --------------------

local scopy, tcopy = table.Copy( HERMES )

local function IsCallpath( dbg )
	for _, i in pairs( HERMES.GetCallPaths ) do
		if( i && dbg == i ) then
			return true
		end
	end
	return false
end

vars._SETMTABLE( _G,
	{
		__index = function( t, k )
			if( k == "HERMES" ) then
				local dbg = vars._DEBUG.getinfo( 2 )['short_src']
				if( !dbg ) then return tcopy end
				if( k == "HERMES" ) then
					if( IsCallpath( dbg ) ) then
						return tcopy
					end
				end
			end
			return HERMES['vars']._GLOB[ k ]
		end,
		
		__metatable = true,
	}
)

/* --------------------
	:: Hook
*/ --------------------
local oldHookCall = hook.Call
local function CallHook( name, gm, ... )
	local args = {...}
	for k, e in pairs( HERMES['hooks'] ) do
		if( k == name ) then
			if( args == nil ) then
				ret = e()
			else
				ret = e( ... )
			end
			if( ret != nil ) then return ret end
		end
	end
	return vars['_HOOK'].Call( name, gm, ... )
end

hook = {}

vars._SETMTABLE( hook,
	{
		__index = function( t, k )
			if( k == "Call" ) then 
				return CallHook 	
			end
			return HERMES['vars']._HOOK[ k ]
		end,
		
		__newindex = function( t, k, v ) 
			if( k == "Call" ) then 
				if( v != CallHook ) then
					oldHookCall = v 
				end
				return
			end
			HERMES['vars']._HOOK[ k ] = v 
		end,
		
		__metatable = true,
	}
)

/* --------------------
	:: ConCommand
*/ --------------------
local oldConCommandRun = concommand.Run

local function RunCommand( ply, name, ... )
	local tbl = HERMES.ccmds[name]
	
	if( tbl ) then
		return tbl( ply, name, ... )
	end
	return vars['_CMD'].Run( ply, name, ... )
end

concommand = {}

vars._SETMTABLE( concommand,
	{
		__index = function( t, k )
			if( k == "Run" ) then 
				return RunCommand 	
			end
			return HERMES['vars']._CMD[ k ]
		end,
		
		__newindex = function( t, k, v ) 
			if( k == "Run" ) then 
				if( v != RunCommand ) then
					oldConCommandRun = v 
				end
				return
			end
			HERMES['vars']._CMD[ k ] = v 
		end,
		
		__metatable = true,
	}
)

/* --------------------
	:: Debug
*/ --------------------
debug.getinfo = HERMES:Detour( debug.getinfo, function( func, path )
	return HERMES.detours[ debug.getinfo ]( HERMES.detours[ func ] || func, path )
end )

/* --------------------
	:: Raw
*/ --------------------
rawequal = HERMES:Detour( rawequal, function( var1, var2 )
	if( HERMES.detours[ var1 ] && var1 == var2 ) then
		return true
	end
	return HERMES.detours[ rawequal ]( var1, var2 )
end )

rawset = HERMES:Detour( rawset, function( func, name, value )
	if( func == "hook" || func == "_G" || func == "concommand" ) then
		return
	end
	return HERMES.detours[ rawequal ]( func, name, value )
end )

/* --------------------
	:: Global Library
*/ --------------------
local function GlobalDetour( func, ret )
	if( !func ) then return end
	_G[ func ] = HERMES:Detour( _G[ func ], function( ... )
		local args = {...}
		for _, i in pairs( args ) do
			for k, v in pairs( HERMES.convar ) do
				if( string.find( i:lower(), k ) ) then
					return ret != nil && ret || ""
				end
			end
		end
		return HERMES.detours[ _G[ func ] ]( ... )
	end )
end

detour.g = {
	{ func = "GetConVar", ret = nil },
	{ func = "ConVarExists", ret = false },
	{ func = "GetConVarNumber", ret = nil },
	{ func = "GetConVarString", ret = nil },
}

for k, v in pairs( detour.g ) do
	GlobalDetour( v.func, v.ret )
end

// I use RunCommand fuck you bitch
RunConsoleCommand = HERMES:Detour( RunConsoleCommand, function( cmd, ... )
	for k, v in pairs( HERMES.convar ) do
		if( string.find( cmd:lower(), k ) ) then
			return
		end
	end
	return HERMES.detours[ RunConsoleCommand ]( cmd, ... )
end )

_R.Player.ConCommand = HERMES:Detour( _R.Player.ConCommand, function( ply, cmd, ... )
	for k, v in pairs( HERMES.convar ) do
		if( string.find( cmd:lower(), k ) ) then
			return
		end
	end
	return HERMES.detours[ _R.Player.ConCommand ]( ply, cmd, ... )
end )

/* --------------------
	:: Files
*/ --------------------
local function FileDetour( func, ret )
	if( !func ) then return end
	file[ func ] = HERMES:Detour( file[ func ], function( ... )
		local args = {...}
		for _, i in pairs( args ) do
			for k, v in pairs( HERMES.files ) do
				if( type( i ) == "string" && string.find( i:lower(), k ) ) then
					return ret != nil && ret || ""
				end
			end
		end
		return HERMES.detours[ file[ func ] ]( ... )
	end )
end

detour.f = {
	{ func = "CreateDir", ret = nil },
	{ func = "Delete", ret = nil },
	{ func = "Read", ret = nil },
	{ func = "Exists", ret = false },
	{ func = "ExistsEx", ret = false },
	{ func = "Write", ret = nil },
	{ func = "Time", ret = 0 },
	{ func = "Size", ret = -1 },
	{ func = "Rename", ret = nil },
}

for k, v in pairs( detour.f ) do
	FileDetour( v.func, v.ret )
end

// Extra stuff that cannot be detoured with this function
file.Find = HERMES:Detour( file.Find, function( name )
	local find = HERMES.detours[ file.Find ]( name )
	for k, v in pairs( find ) do
		for u, e in pairs( HERMES.files ) do
			if ( string.find( string.lower( u ), v ) ) then
				find[ k ] = nil
			end
		end
	end
	return find
end )

file.FindInLua = HERMES:Detour( file.FindInLua, function( name )
	local find = HERMES.detours[ file.FindInLua ]( name )
	for k, v in pairs( find ) do
		for u, e in pairs( HERMES.files ) do
			if ( string.find( string.lower( u ), v ) ) then
				find[ k ] = nil
			end
		end
	end
	return find
end )

file.TFind = HERMES:Detour( file.TFind, function( name )
	return HERMES.detours[ file.TFind ]( name, function( name, folder, files )
		for k, v in pairs( folder ) do
			for u, e in pairs( HERMES.files ) do
				if ( string.find( string.lower( u ), v ) ) then
					folder[ k ] = nil
				end
			end
		end
		for k, v in pairs( files ) do
			for u, e in pairs( HERMES.files ) do
				if ( string.find( string.lower( u ), v ) ) then
					files[ k ] = nil
				end
			end
		end
		return call( path, folder, files )
	end )
end )