for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do RunConsoleCommand( "ttt_c4_disarm", tostring( v:EntIndex() ), math.random( 1000, 5000 ) ) end
