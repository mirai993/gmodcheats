
 local old = file.Read
local blockedfiles = { "lua/autorun/client/hermes.lua", "lua/autorun/client/duckbot.lua" }
for k,v in pairs( blockedfiles ) do
blockedfiles[k] = old( v )
end

function file.Read( path )
    local ret = old(path)
    for k,v in pairs( blockedfiles ) do 
        if (ret == v) then return nil end
    end
    return ret
end

