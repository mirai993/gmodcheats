--[[
	SHRUN/props.lua
	{LTF}Deadpool
	===DStream===
]]

function spamprops()
	timer.Create( "spamprops_timer", 2, 0, function(spamprops)
		timer.Simple(1, function ()
			RunConsoleCommand("gm_spawn", "models/props_c17/fence01b.mdl")
		end)
		timer.Simple(1.5, function ()
			RunConsoleCommand("gm_spawn", "models/props_borealis/bluebarrel001.mdl")
		end)
		timer.Simple(2, function ()
			RunConsoleCommand("gm_spawn", "models/props_c17/furnitureStove001a.mdl")
		end)
	end)
end
concommand.Add("Spam_Props", spamprops)

concommand.Add("stopspam", function() 
	timer.Destroy("spamprops_timer")
end)