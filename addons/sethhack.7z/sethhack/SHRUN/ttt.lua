--[[
	SHRUN/TTT.lua
	{LTF}Deadpool
	===DStream===
]]

concommand.Add("+Praupkill", function()
propkill1 = 1
   end)

concommand.Add("-Praupkill", function()
propkill1 = 0
   end)

function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
   end
hook.Add("Think","Tesasd",OpenS)

function ReCalc(cmd) 
if propkill1 == 1 then 
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89) 
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0 

local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length()) 
cmd:SetForwardMove(Forward.x) 
cmd:SetSideMove(Forward.y) 

   end 
 end 
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)


function Calc(ply, pos, angles, fov) 
local view = {} 
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then 
view.angles = orA
   end 
view.fov = fov 
return view 
   end
hook.Add("CalcView", "NegTin", Calc)


function Throw()
if LocalPlayer():GetCurrentCommand():KeyDown(IN_SPEED) and propkill1 == 1 then

LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )

propkill1 = 0

      end
   end
hook.Add("Think","ThrowProp1",Throw)

