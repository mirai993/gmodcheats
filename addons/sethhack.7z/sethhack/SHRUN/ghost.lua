--[[
	SHRUN/ghost.lua
	{LTF}Deadpool
	===DStream===
]]

-- July 13 2008 
-- Ghost < lets you move like a ghost/noclip
-- Made from Jetboom's jetbot, all credits goes to him
-- Zinen --

-- Default flyspeed -Not working --

GHOSTSPEED = 400;

--  |             |
-- \|/ Core code \|/

CreateClientConVar("_ghost_speed", GHOSTSPEED, true, false)
GHOSTSPEED = GetConVarNumber("_ghost_speed")

function Ghost_SetSpeed(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		GHOSTSPEED = tonumber(arguments[1])
		RunConsoleCommand("_ghost_speed",GHOSTSPEED)
	end
end
concommand.Add("ghost_speed", Ghost_SetSpeed)

local function CamEnable()
	if ValidEntity(LocalPlayer()) then
	MY_VIEW = LocalPlayer():GetAimVector()
	MySelf = LocalPlayer()
	CAM_POS = MySelf:EyePos()
	CAM_ANG = MySelf:GetAimVector()
	hook.Add("CreateMove", "CamStopMove", function(cmd)
		cmd:SetForwardMove(0)
		cmd:SetUpMove(0)
		cmd:SetSideMove(0)
		return cmd
	end)
	function GAMEMODE:CalcView(ply, origin, angles, fov)
		angles = angles:Forward()
		local masktouse = COLLISION_GROUP_WORLD
		if MySelf:KeyDown(IN_FORWARD) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * GHOSTSPEED, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_BACK) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * GHOSTSPEED * -1, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVELEFT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * GHOSTSPEED * -1, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVERIGHT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * GHOSTSPEED, mask=masktouse})
			CAM_POS = tr.HitPos
		end

		local view = {}
		view.origin = CAM_POS
		view.angles = angles:Angle()
		view.fov = fov

		return view
	end
	end
end
concommand.Add("ghost_on", CamEnable)

local function CamDisable()
	hook.Remove("CreateMove", "CamStopMove")
	function GAMEMODE:CalcView(ply, origin, angles, fov)
		local view = {}
		view.origin = origin
		view.angles = angles
		view.fov = fov
		return view
	end
end
concommand.Add("ghost_off", CamDisable)
