--[[
	SHRUN/Cspam.lua
	{LTF}Deadpool
	===DStream===
]]

local phrases = {
			"Something",
			"Something else",
			"some other thing",
}
concommand.Add("startCspam", function(ply, command, args)
	if !args[1] and !args[2] then
		timer.Create("spamtimer", 1, 20, function()
			RunConsoleCommand("say", table.Random(phrases))
		end)
	elseif args[1] and !args[2] then
		timer.Create("spamtimer", 1, 20, function()
			RunConsoleCommand("say", tostring(args[1]))
		end)
	elseif !args[1] and args[2] then
		timer.Create("spamtimer", 1, tonumber(args[2]), function()
			RunConsoleCommand("say", table.Random(phrases))
		end)
	elseif args[1] and args[2] then
		timer.Create("spamtimer", 1, tonumber(args[2]), function()
			RunConsoleCommand("say", tostring(args[1]))
		end)
	end
end)