--[[
	SHRUN/propkiller.lua
	{LTF}Deadpool
	===DStream===
]]

function Propkill()
	local ply = LocalPlayer()
	local Angles = ply:EyeAngles()
	ply:SetEyeAngles(Angle(30, Angles.yaw + 180, Angles.roll))
	timer.Create("spawn", 0.1, 1, function()
		ply:ConCommand("gm_spawn models/props_junk/sawblade001a.mdl")
		ply:ConCommand("+attack")
	end)
	timer.Create("jump", 0.15, 1, function()
		ply:ConCommand("+jump")
	end)
	timer.Create("turnback", 0.35, 1, function()
		
		ply:SetEyeAngles(Angle(40, Angles.yaw, Angles.roll))
	end)
	timer.Create("release", 0.37, 1, function()
		ply:ConCommand("-attack")
	end)
	timer.Create("undo", 1.2, 1, function()
		ply:ConCommand("-jump")
		ply:ConCommand("undo")
	end)
end

concommand.Add("propkill", Propkill)

function Propboost()
	local ply = LocalPlayer()
	local Angles = ply:EyeAngles()
	ply:SetEyeAngles(Angle(60, Angles.yaw + 180, Angles.roll))
	timer.Create("spawn", 0.1, 1, function()
		ply:ConCommand("gm_spawn models/props_lab/blastdoor001b.mdl")
		ply:ConCommand("+attack")
	end)
	timer.Create("turnback", 0.25, 1, function()
		
		ply:SetEyeAngles(Angle(0, Angles.yaw, Angles.roll))
	end)
	timer.Create("release", 1, 1, function()
		ply:ConCommand("-attack")
		ply:ConCommand("undo")
	end)
end

concommand.Add("propboost", Propboost)

function Propboostup()
	local ply = LocalPlayer()
	local Angles = ply:EyeAngles()
	ply:SetEyeAngles(Angle(70, Angles.yaw + 180, Angles.roll))
	timer.Create("spawn", 0.1, 1, function()
		ply:ConCommand("gm_spawn models/props_lab/blastdoor001b.mdl")
		ply:ConCommand("+attack")
	end)
	timer.Create("turnback", 0.25, 1, function()
		
		ply:SetEyeAngles(Angle(-20, Angles.yaw, Angles.roll))
	end)
	timer.Create("release", 0.5, 1, function()
		ply:ConCommand("-attack")
		ply:ConCommand("undo")
	end)
end

concommand.Add("propboostup", Propboostup)

function Proplanding()
	local ply = LocalPlayer()
	local Angles = ply:EyeAngles()
	ply:SetEyeAngles(Angle(90, Angles.yaw + 180, Angles.roll))
	timer.Create("spawn", 0.1, 1, function()
		ply:ConCommand("gm_spawn models/props_wasteland/kitchen_counter001c.mdl")
		ply:ConCommand("+attack")
		ply:ConCommand("mwheelup")
	end)
	timer.Create("release", 2, 1, function()
		ply:ConCommand("-attack")
		ply:ConCommand("undo")
	end)
end

concommand.Add("proplanding", Proplanding)

function Crash()
	local ply = LocalPlayer()
	timer.Create("spam", 0.0000001, 0, function()
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x1x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x150x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x2x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x3x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x4x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x6x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube1x8x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube2x2x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube2x4x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube2x6x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube2x8x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube4x4x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube4x6x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube4x8x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube8x8x1.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube8x8x2.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube8x8x4.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube8x8x6.mdl")
		ply:ConCommand("gm_spawn models/hunter/blocks/cube8x8x8.mdl")
		ply:ConCommand("impulse 100")
		ply:ConCommand("say /buyammo pistol")
		ply:ConCommand("undo")
		ply:SetEyeAngles(Angle(math.random(0, 360), math.random(0, 360), math.random(0, 360) ))
	end)
end
function UnCrash()
	timer.Remove("spam")
end

concommand.Add("+crash", Crash)
concommand.Add("-crash", UnCrash)