local ESPDistance = 25000
local AllESPEntities = {"pot","shroom"}
local draw = draw
local team = team
local player = player
MsgN("Quick ESP by Alex on SethHack.net forums loaded!")
local function QuickESPHack()
   for k,v in pairs(player.GetAll()) do
      if v:IsValid() and v:GetPos():Distance(LocalPlayer():GetPos()) < ESPDistance then
         local pos = v:GetPos() + Vector(0,0,70)
         pos = pos:ToScreen()
         local cwep = "None"
         if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then cwep = v:GetActiveWeapon():GetClass() end
         draw.SimpleTextOutlined( tostring(v:GetName()), "UiBold", pos.x, pos.y, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
         draw.SimpleTextOutlined( "W: " .. cwep .. " | H: " .. v:Health(), "UiBold", pos.x, pos.y+15, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
      end
   end
   for k,v in pairs(ents.GetAll()) do
      if v:IsValid() and table.HasValue(AllESPEntities, string.lower(v:GetClass())) then
         local pos = v:GetPos() + Vector(0,0,5)
         pos = pos:ToScreen()
         draw.SimpleTextOutlined( tostring(v:GetClass()), "UiBold", pos.x, pos.y, Color(255,0,0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0) )
      end
   end
end
hook.Add("HUDPaint","Quick ESP script for SethHack forums",QuickESPHack)