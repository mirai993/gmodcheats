lolzihere = 0

function imhere()
if lolzihere == 1 then
-- RANDOMTURNSHERE
	timer.Simple(.05,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end )
	timer.Simple(.1,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.15,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.2,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.25,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.3,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.35,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.4,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.45,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.5,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.55,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.57,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.59,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.62,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.65,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.68,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.73,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.79,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(1,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,50,0)) end)
	timer.Simple(2,function() RunConsoleCommand("+forward") end)
	timer.Simple(3,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,23,0)) end)
	timer.Simple(3.5,function() RunConsoleCommand("+showscores") end)
	timer.Simple(4,function() RunConsoleCommand("-forward") end)
	timer.Simple(5,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,23,0)) end)
	timer.Simple(6,function() RunConsoleCommand("+jump") end)
	timer.Simple(8,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,23,0)) end)
	timer.Simple(8.1,function() RunConsoleCommand("-showscores") end)
	timer.Simple(8.5,function() RunConsoleCommand("-jump") end)
	timer.Simple(9,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(9.5,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(15,0,0)) end)
	timer.Simple(9.6,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(-15,0,0)) end)
	timer.Simple(9.7,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(15,0,0)) end)
	timer.Simple(9.8,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(-15,0,0)) end)
	timer.Simple(10,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,33,0)) end)
	timer.Simple(11,function() RunConsoleCommand("gm_showteam") end)
	timer.Simple(12,function() RunConsoleCommand("gm_showteam") end)
	timer.Simple(16,imhere)
end
end


function togglenothere()
if lolzihere == 1 then
lolzihere = 0
imhere()
elseif lolzihere == 0 then
lolzihere = 1
imhere()
end
end

concommand.Add("afktoggle",togglenothere)