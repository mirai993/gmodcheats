--[[
	myfiles/73.lua
	ÄMÇÕ3008 | (STEAM_0:0:39879112)
	===DStream===
]]

local tog = 0
local stop = 0
local enabled = CreateClientConVar( "af_enable", "1",  false,  false)
hook.Add("Think", "AutoFire", function()	
	if input.IsMouseDown(MOUSE_LEFT) && stop == 0 && enabled:GetInt() == 1 then
		if tog == 0 then
			tog = 1
		else
			tog = 0
		end
		if tog == 0 then
			RunConsoleCommand("+attack")
		else
			RunConsoleCommand("-attack")
		end
	elseif tog == 0 then
		RunConsoleCommand("-attack")
		if tog == 0 then
			tog = 1
		else
			tog = 0
		end
	end
end)

local stophooks = {
	"OnSpawnMenuOpen",
}
local gohooks = {
	"OnSpawnMenuClose",
}
	
for _,v in pairs(stophooks) do
	hook.Add(v, v.."af", function()
		stop = 1
	end)
end
for _,v in pairs(gohooks) do
	hook.Add(v, v.."af", function()
		stop = 0
	end)
end

