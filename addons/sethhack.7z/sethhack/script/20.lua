print("Loaded PERP exploits, These exploits were designed for PERP1 and may or may not work in new/updated/patched versions")
concommand.Add("sh_perp_finishfriends", function()
for k, v in pairs(player.GetAll()) do
if(v:GetFriendStatus() == "friend") then
if(v:Health() > 0) then
continue;
end

print("[SethHack] Respawned:", v:Nick());
RunConsoleCommand("perp_fpo", v:UniqueID());
end
end
end);

concommand.Add("sh_perp_finishme", function()
print("[SethHack] Respawned yourself");
RunConsoleCommand("perp_fpo", LocalPlayer():UniqueID());
end);

concommand.Add("sh_perp_cop_ammo", function()
print("[SethHack] Cop Ammo replenished");
RunConsoleCommand("perp_q_p");
RunConsoleCommand("perp_j_p");
end);

concommand.Add("sh_perp_swat_ammo", function()
print("[SethHack] S.W.A.T Ammo replenished");
RunConsoleCommand("perp_q_s");
RunConsoleCommand("perp_j_s");
end);