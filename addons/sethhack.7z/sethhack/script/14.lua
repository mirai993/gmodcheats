function ChatSpammerMenu()
if IsSpamming == true then
chat.AddText(255, 0, 0, "You are already spamming. If you want to stop spamming type kon_stopspam in the console.")
do return end
end

local SpamPanel = vgui.Create( "DFrame" )
SpamPanel:SetPos( 250,250 )
SpamPanel:SetSize( 500, 180 )
SpamPanel:SetTitle( "Simple Chat Spammer" )
SpamPanel:ShowCloseButton( true )
SpamPanel:SetVisible( true )
SpamPanel:MakePopup()

SpamText = vgui.Create( "DTextEntry", SpamPanel )
SpamText:SetPos( 20,30 )
SpamText:SetTall( 20 )
SpamText:SetWide( 450 )
SpamText:SetText( "Text to spam" )
SpamText:SetEnterAllowed( true )

SpamSlider = vgui.Create( "DNumSlider", SpamPanel )
SpamSlider:SetPos( 20,55 )
SpamSlider:SetSize( 450, 25 )
SpamSlider:SetText( "How many times to spam? (0 is infinite)" )
SpamSlider:SetMin( 1 )
SpamSlider:SetMax( 2000 )
SpamSlider:SetDecimals( 0 )

SpamSlider2 = vgui.Create( "DNumSlider", SpamPanel )
SpamSlider2:SetPos( 20,90 )
SpamSlider2:SetSize( 450, 25 )
SpamSlider2:SetText( "Interval between each chat (in seconds)" )
SpamSlider2:SetMin( 1 )
SpamSlider2:SetMax( 250 )
SpamSlider2:SetDecimals( 0 )

local SpamButton = vgui.Create( "DButton", SpamPanel )
SpamButton:SetPos( 20, 135 )
SpamButton:SetSize( 160, 30 )
SpamButton:SetText( "Start Spamming!" )
SpamButton.DoClick = function()
	if SpamText:GetValue() != "Text to spam" then
	ChatSpam()
	SpamPanel:SetVisible( false )
	else
	chat.AddText(255, 0, 0, "Please enter something to spam.")
	end
end
end
concommand.Add( "kon_chatspam", ChatSpammerMenu )

function ChatSpam()
SpamValue = SpamSlider:GetValue()
SpamInterval = SpamSlider2:GetValue()
TimesSpammed = 0
IsSpamming = true
	timer.Create("StartSpamming", SpamInterval, 0, function()
	LocalPlayer():ConCommand("say "..SpamText:GetValue())
	TimesSpammed = TimesSpammed + 1
	if TimesSpammed == SpamValue then
		timer.Stop("StartSpamming")
		IsSpamming = false
		chat.AddText(255, 0, 0, "Spammed successfully "..TimesSpammed.." times!")
	end
end )
end

function StopSpamming ()
if IsSpamming == true then
timer.Stop("StartSpamming")
IsSpamming = false
else
chat.AddText(255, 0, 0, "You are not spamming!")
end
end
concommand.Add( "kon_stopspam", StopSpamming )