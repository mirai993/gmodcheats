--[[
	myfiles/64.lua
	ÄMÇÕ3008 | (STEAM_0:0:39879112)
	===DStream===
]]

//Keypad cracker
local function Think()
	for _, e in pairs( ents.GetAll() ) do
		if ( ValidEntity( e ) ) then
			local class = e:GetClass()
			if ( class == "sent_keypad" || class == "sent_keypad_wire" ) then
				if ( e:GetNWBool( "keypad_access" ) && e:GetNWBool( "keypad_showaccess" ) ) then
					e.Password = e:GetNWInt( "keypad_num" )
				end
			end
		end
	end
end
hook.Add( "Think", "KeyPadH4X.Think", Think )

local function HUDPaint()
	local ply = LocalPlayer()
	if ( !ValidEntity( ply ) ) then return end
	
	local trace = util.QuickTrace( ply:GetShootPos(), ply:GetAimVector() * 100, ply )
	if ( ValidEntity( trace.Entity ) && trace.Entity.Password ) then
		local pos = ( trace.Entity:GetPos() + Vector( 0, 0, 6 ) ):ToScreen()
		local text = "Pass:" .. trace.Entity.Password,
		
		surface.SetFont( "Default" )
		local w = surface.GetTextSize( text ) + 16
		
		draw.WordBox( 8, ( ScrW() / 2 ) - ( w / 2 ), ( ScrH() / 2 ) + 40, text, "Default", Color(50,50,75,200), Color(255,255,255,255) )
	end
end
hook.Add( "HUDPaint", "KeyPadH4X.HUDPaint", HUDPaint )
		