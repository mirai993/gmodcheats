RunConsoleCommand("clientport", tostring(math.random(35000, 65500)));
RunConsoleCommand("net_start");