function Revival ()
local runUse
local iterations = 0
runUse = function()
if iterations != 13 then
RunConsoleCommand("+use")
timer.Simple(0.1, function() RunConsoleCommand("-use") end)
timer.Simple(1, runUse)
end
iterations = iterations + 1
end
runUse()
end
concommand.Add("revive",Revival)