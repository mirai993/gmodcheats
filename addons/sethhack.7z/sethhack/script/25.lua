
/*
	Author: Nomical
	Created: July 16, 12:19 am , 2011
	Version: 1.3
	Info: Walks You to a vector.
	This Script Was Made Out Of COMPLETE Boredom, And It's Messy.
*/

local x = CreateClientConVar("Walker_x",0,true,false)
local y = CreateClientConVar("Walker_y",0,true,false)
local DrawPos = CreateClientConVar("Walker_DrawDestination",0,true,false)

local Table = {
I = LocalPlayer(),
Ok = true,
}

local Logs = {}

function Table.Math()
	Table.x1 = x:GetInt() - 70
	Table.x2 = x:GetInt() + 70
	Table.y1 = y:GetInt() + 70
	Table.y2 = y:GetInt() - 70
end

function Table.Com(arg)
	Table.I:ConCommand(arg)
end


function Table.FixPos()
	if Table.I:GetPos().x < Table.x2 && Table.I:GetPos().x > Table.x1 && Table.I:GetPos().y > Table.y2 && Table.I:GetPos().y < Table.y1 then
		chat.AddText(Color(0,255,0,255),"[Walker] Position Ok, Stopping Script")
		Table.Ok = true
		else
		Table.Ok = false
		Table.Ang = (Vector(x:GetInt(),y:GetInt(),0) - Table.I:EyePos()):Angle()
		Table.I:SetEyeAngles(Angle(Table.Ang.p,Table.Ang.y,0))
		Table.Com("+forward")
		chat.AddText(Color(255,0,255,255),"[Walker] Position Invalid, Running reposition script")
	end
end

function Table.TroubleShoot()
	Table.EyeAngs = Table.I:EyeAngles()
	Table.Ang = (Vector(x:GetInt(),y:GetInt(),-60) - Table.I:EyePos()):Angle()
	if Table.I:EyePos():Distance(Table.I:GetEyeTrace().HitPos) < 45 && !Table.Ok then
		chat.AddText(Color(255,0,0,255),"[Walker] Object DETECTED , Attempting To TroubleShoot...")
		Table.I:SetEyeAngles(Table.EyeAngs - Angle(0,math.random(1,180),0))
		elseif Table.I:EyePos():Distance(Table.I:GetEyeTrace().HitPos) > 45 && Table.EyeAngs.y != Table.Ang.y && !Table.Ok then
		chat.AddText(Color(255,255,0,255),"[Walker] UnAligned Angle DETECTED, Re-Aligning")
		Table.I:SetEyeAngles(Angle(Table.Ang.p,Table.Ang.y,0))
	end
end

function Table.DestinationReached()
	if Table.I:GetPos().x < Table.x2 && Table.I:GetPos().x > Table.x1 && Table.I:GetPos().y > Table.y2 && Table.I:GetPos().y < Table.y1 && !Table.Ok then
		Table.Com("-forward")
		chat.AddText(Color(0,255,0,255),"[Walker] Position Ok, Stopping Script")
		Table.Ok = true
		timer.Destroy("Walker_TroubleShoot")
		timer.Destroy("Walker_Destination")
	end	
end


function Table.Run()
	Table.Math()
	Table.FixPos()
	timer.Create("Walker_TroubleShoot",3.2,0,Table.TroubleShoot)
	timer.Create("Walker_Destination",.1,0,Table.DestinationReached)
end

function Table.Square()
	if !Table.Ok && DrawPos:GetInt() >= 1 then
		local z = Table.I:EyePos()
		z = z.z - 25
		cam.Start3D(EyePos(),EyeAngles())
		render.SetMaterial( Material( "cable/physbeam" ) )
		render.DrawBeam(Vector(Table.x1,Table.y1,z),Vector(Table.x1,Table.y2,z) , 5, 0, 0, Color(255,255,255,255))
		render.DrawBeam(Vector(Table.x2,Table.y1,z),Vector(Table.x2,Table.y2,z) , 5, 0, 0, Color(255,255,255,255))
		render.DrawBeam(Vector(Table.x2,Table.y2,z),Vector(Table.x1,Table.y2,z) , 5, 0, 0, Color(255,255,255,255))
		render.DrawBeam(Vector(Table.x1,Table.y1,z),Vector(Table.x2,Table.y1,z) , 5, 0, 0, Color(255,255,255,255))
		cam.End3D()
	end
end

function Table.Menu()
	local Frame = vgui.Create("DFrame")
	Frame:SetSize(200,250)
	Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2 )
	Frame:SetTitle(" BASIC AUTO WALKER ")
	Frame:SetVisible(true)
	Frame:ShowCloseButton(true)	
	Frame:MakePopup()
	Frame.Paint = function()
		draw.RoundedBox(6,0,0,Frame:GetWide(),Frame:GetTall(),Color(0,0,0,185))
	end
	local Sheet = vgui.Create("DPropertySheet")
	Sheet:SetParent(Frame)
	Sheet:SetPos(5,25)
	Sheet:SetSize(190,220)
	Sheet:SetFadeTime(.3)

	local Tab1 = vgui.Create("DLabel")
	Tab1:SetParent(Sheet)
	Tab1:SetText("")
	Tab1:SizeToContents()
	Tab1.Paint = function()
		draw.RoundedBox(6,0,0,Sheet:GetWide(),Sheet:GetTall(),Color(0,0,0,185))
	end
	
	local Tab2 = vgui.Create("DLabel")
	Tab2:SetParent(Sheet)
	Tab2:SetText("")
	Tab2:SizeToContents()
	Tab2.Paint = function()
		draw.RoundedBox(6,0,0,Sheet:GetWide(),Sheet:GetTall(),Color(0,0,0,185))
	end	
		
	local X = vgui.Create("DTextEntry")
	X:SetParent(Tab1)
	X:SetSize(75,20)
	X:SetPos(50,10)
	X:SetText(tostring(x:GetInt()))

	local Y = vgui.Create("DTextEntry")
	Y:SetParent(Tab1)
	Y:SetSize(75,20)
	Y:SetPos(50,110)
	Y:SetText(tostring(y:GetInt()))
		
	local B = vgui.Create("DButton")
	B:SetParent(Tab1)
	B:SetSize(75,20)
	B:SetPos(50,40)
	B:SetText("Save X")
	B.DoClick = function()
		Table.Com("Walker_x "..X:GetValue())
	end
		
	local B2 = vgui.Create("DButton")
	B2:SetParent(Tab1)
	B2:SetSize(75,20)
	B2:SetPos(50,140)
	B2:SetText("Save Y")
	B2.DoClick = function()
		Table.Com("Walker_y "..Y:GetValue())
	end
		
	local B3 = vgui.Create("DButton")
	B3:SetParent(Tab1)
	B3:SetSize(75,30)
	B3:SetPos(50,70)
	B3:SetText("RunScript")
	B3.DoClick = function()
		Table.Com("Walker_x "..X:GetValue())
		Table.Com("Walker_y "..Y:GetValue())
		timer.Simple(0.01,function()
			Table.Run()
		end)
	end
		
	local O = vgui.Create("DCheckBoxLabel")
	O:SetParent(Tab1)
	O:SetPos(35,170)
	O:SetText("Draw Destination")
	O:SetConVar("Walker_DrawDestination")
	O:SetValue(DrawPos:GetInt())
	O:SetTextColor(Color(255,255,255,255))
	O:SizeToContents()
		
	local L = vgui.Create("DListView")
	L:SetParent(Tab2)
	L:SetPos(2,10)
	L:SetSize(175,150)
	L:SetMultiSelect(false)
	L:AddColumn("X")
	L:AddColumn("Y")
	L.OnRowSelected = function(panel , line)
		Table.A = L:GetLine(line):GetValue(1)
		Table.B = L:GetLine(line):GetValue(2)
	end
		
	local B4 = vgui.Create("DButton")
	B4:SetParent(Tab2)
	B4:SetSize(50,15)
	B4:SetPos(10,167)
	B4:SetText("Log")
	B4.DoClick = function()
		Logs[math.Round(Table.I:GetPos().x)] = math.Round(Table.I:GetPos().y)
		Frame:SetVisible(false)
		Table.Com("Walker_Menu")
	end
		
	local B5 = vgui.Create("DButton")
	B5:SetParent(Tab2)
	B5:SetSize(50,15)
	B5:SetPos(67.5,167)
	B5:SetText("Clear")
	B5.DoClick = function()
		Logs = {}
		Frame:SetVisible(false)
		Table.Com("Walker_Menu")
	end
		
	local B6 = vgui.Create("DButton")
	B6:SetParent(Tab2)
	B6:SetSize(50,15)
	B6:SetPos(125,167)
	B6:SetText("Run")
	B6.DoClick = function()
		Table.Com("Walker_x "..Table.A || 1)
		Table.Com("Walker_y "..Table.B || 1)
		X:SetText(tostring(x:GetInt()))
		Y:SetText(tostring(y:GetInt()))
		timer.Simple(0.1,function()
			Table.Run()
		end)
	end
		
		for k,v in pairs(Logs) do
			L:AddLine(k,v)
		end	
			
	Sheet:AddSheet("Walker",Tab1,"gui/silkicons/user",false,false,"AutoWalker")
	Sheet:AddSheet("Logger",Tab2,"gui/silkicons/user",false,false,"Logger")
end

hook.Add("HUDPaint","DrawBoxz",Table.Square)
concommand.Add("Walker_Menu",Table.Menu)
















