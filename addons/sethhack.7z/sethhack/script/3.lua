local barrelhax = false
function Barrelhax() 
	if barrelhax then
		for k,v in pairs(player.GetAll()) do
			if (v!=LocalPlayer() and v:Alive() and v:IsPlayer()) then
				cam.Start3D( EyePos() , EyeAngles())
					render.SetMaterial( Material( "cable/physbeam" ) )
					render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")) , v:GetEyeTrace().HitPos , 5, 0, 0, Color(255,255,255, 255 ))
				cam.End3D()
			end
		end
	end
end
 
 hook.Add("HUDPaint","Specline", Barrelhax)
concommand.Add("barrelhax", function()
	if barrelhax == true then
		barrelhax = false
	else
		barrelhax = true
	end
end)