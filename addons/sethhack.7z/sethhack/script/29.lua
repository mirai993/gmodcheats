lolzihere = 0

function imhere()
if lolzihere == 1 then
-- RANDOMTURNSHERE

	timer.Simple(.5,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,1,0)) end)
	timer.Simple(3,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,-1,0)) end)


	timer.Simple(450,imhere)
end
end


function togglenothere()
if lolzihere == 1 then
lolzihere = 0
imhere()
elseif lolzihere == 0 then
lolzihere = 1
imhere()
end
end

concommand.Add("afktoggle",togglenothere)