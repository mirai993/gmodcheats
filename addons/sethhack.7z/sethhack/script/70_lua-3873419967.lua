--[[
	Scripts/70.lua
	Coolman699 | (STEAM_0:1:11427632)
	===DStream===
]]

//	Created by C0BRA
//	(c) 2010 XiaTek
//	XiaTek.org

local X = -50
local Y = -100
local W = 100
local H = 200

local KeyPos =	{	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
					{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
					{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

					{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
					{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
					{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

					{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
					{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
					{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

					{X+5, Y+67.5, 40, 25, -2.2, 4.25, -0.3, 1.6},
					{X+55, Y+67.5, 40, 25, 0.3, 1.65, -0.3, 1.6}
				}

local KP = _R.Entity
//lua_run_cl p = LocalPlayer() KeyPressed(p:GetEyeTrace().Entity, p ) print( p:GetEyeTrace().Entity.log ) 
local function KeyPressed( kp, pl )
	if not ValidEntity(pl) or not pl:IsPlayer() then return end
	local t = {}
		t.start = pl:GetShootPos()
		t.endpos = pl:GetAimVector() * 32 + t.start
		t.filter = pl
	local tr = util.TraceLine(t)
	
	local pos = kp:WorldToLocal(tr.HitPos)
	local Num = tostring( kp:GetNetworkedInt("keypad_num") )
	
	for k,v in pairs(KeyPos) do
		local x = (pos.y - v[5]) / (v[5] + v[6])
		local y = 1 - (pos.z + v[7]) / (v[7] + v[8])
		
		if (x >= 0) and (y >= 0) and (x <= 1) and (y <= 1) then 
			// this is the shit our peeeps aiming at, x and y are between 0 and 1 if were on the correct square, took me some time to figgure out what he was doing
			local key = tostring(k)
			local log = kp.log or ""
			kp.log = string.Right( log .. k, 10 )
		end
	end
end

hook.Add("HUDPaint", "getdemcodes", function()
	for k,kp in pairs( ents.FindByClass("sent_keypa*") ) do
		local last = kp.last or 0
		local new = string.len( tostring( kp:GetNetworkedInt("keypad_num") ) )
		
		local hascode = kp:GetNetworkedInt("keypad_num")
		if hascode == 0 then new = 0 end
		
		local Access = kp:GetNetworkedBool("keypad_access") // if they got in
		local ShowAccess = kp:GetNetworkedBool("keypad_showaccess") // wether its showing
		
		
		if last != new or ShowAccess then
		
			if ShowAccess then // accept or cancle been pressed 
				
				if Access and ShowAccess then
					if kp.log != " " then
						local Num = string.len( tostring( kp:GetNetworkedInt("keypad_num") ) )
						kp.code = string.Right( kp.log, Num )
						kp.log = " "
						kp.last = 0
						print( "Code found: " .. kp.code )
					end
				else
					kp.log = ""
					kp.last = 0
				end
			elseif new > last then
				local pl
				for i, ply in pairs( player.GetAll() ) do
					tr = ply:GetEyeTrace()
					if tr.Entity == kp and (tr.HitPos - ply:GetShootPos()):Length() < 80 then
						pl = ply
					end
				end
				kp.last = new
				KeyPressed( kp, pl )
			end
		end
		kp.last = new
	end
end)

hook.Add( "HUDPaint", "crkpswd", function()
	local e = LocalPlayer():GetEyeTrace().Entity
	if ValidEntity(e) and string.find(e:GetClass(), "sent_keypad") then
		local text = "Code is %code"
		local code = e.code or "Not Found"
		
		text = string.Replace( text, "%code", code )
		draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
	if(code!="Not Found") then
	local pos = e:GetPos():ToScreen()
	draw.RoundedBox( 4, pos.x-5, pos.y-5, 10, 10, Color( 0, 255, 0, 150 ) )
	end
	end
	
end)
