local GWHack = { }
	GWHack.TradeSpamTarget = LocalPlayer( )
	GWHack.ConsoleCommands = { }
		GWHack.ConsoleCommands.Trade = { Request = "trade_request", Cancel = "trade_cancel" }
	GWHack.ButtonToggle = { }
		GWHack.ButtonToggle.InventorySpam = false
	GWHack.Derma = { }
		GWHack.Derma.MainFrame = vgui.Create( "DFrame" )
			GWHack.Derma.MainFrame:SetSize( 600, 55 )
			GWHack.Derma.MainFrame:SetPos(( ScrW( ) / 2 - 300 ), ( ScrH( ) / 2 - 27.5 ))
			GWHack.Derma.MainFrame:SetTitle( "GANG WARS Trade Spam" )
			GWHack.Derma.MainFrame:SetVisible( false )
			GWHack.Derma.MainFrame:SetDeleteOnClose( false )
			GWHack.Derma.MainFrame:SetDraggable( false )
			GWHack.Derma.MainFrame:ShowCloseButton( true )
			GWHack.Derma.MainFrame.Paint = function( )
				surface.SetDrawColor( 50, 50, 50, 240 ); surface.DrawRect( 0, 0, GWHack.Derma.MainFrame:GetWide( ), GWHack.Derma.MainFrame:GetTall( ));
			end
			
		-------------------------------------
		GWHack.Derma.TradeSpamButton = vgui.Create( "DButton", GWHack.Derma.MainFrame )
			GWHack.Derma.TradeSpamButton:SetSize( 200, 20 )
			GWHack.Derma.TradeSpamButton:SetPos( 5, 27 )
			GWHack.Derma.TradeSpamButton:SetText( "Trade Spamm [OFF]" )
			GWHack.Derma.TradeSpamButton.DoClick = function( )
				if GWHack.ButtonToggle.TradeSpam then
					GWHack.ButtonToggle.TradeSpam = false; GWHack.Derma.TradeSpamButton:SetText( "Trade Spamm [OFF]" );
					hook.Remove( "Think", "GWHack_TradeSpam_Think" )
				else
					GWHack.ButtonToggle.TradeSpam = true; GWHack.Derma.TradeSpamButton:SetText( "Trade Spamm [ON]" );
					hook.Add( "Think", "GWHack_TradeSpam_Think", function( )
						if GWHack.Derma.TradeSpamTarget != LocalPlayer( ) and GWHack.TradeSpamTarget:GetPos( ):Distance( LocalPlayer( ):GetPos( )) < 200 then
							LocalPlayer( ):ConCommand( GWHack.ConsoleCommands.Trade.Request.."; "..GWHack.ConsoleCommands.Trade.Request )
							LocalPlayer( ):SetEyeAngles((( GWHack.TradeSpamTarget:GetPos( ) + Vector( 0, 0, 40 )) - LocalPlayer( ):GetShootPos( )):Angle( ))
						end
					end )
				end
			end
			GWHack.Derma.TradeSpamButton.Paint = function( )
				if !GWHack.ButtonToggle.TradeSpam then surface.SetDrawColor( 30, 30, 30, 240 ) else surface.SetDrawColor( 0, 0, 0, 240 ) end
				surface.DrawRect( 0, 0, GWHack.Derma.TradeSpamButton:GetWide( ), GWHack.Derma.TradeSpamButton:GetTall( ));
			end
			
		GWHack.Derma.TradeSpamTarget = vgui.Create( "DTextEntry", GWHack.Derma.MainFrame )
			GWHack.Derma.TradeSpamTarget:SetSize( 384, 20 )
			GWHack.Derma.TradeSpamTarget:SetPos( 210, 27 )
			GWHack.Derma.TradeSpamTarget.OnEnter = function( )
				for _, ply in pairs( player.GetAll( )) do
					if string.find( ply:Nick( ) , GWHack.Derma.TradeSpamTarget:GetValue( )) then GWHack.TradeSpamTarget = ply end
				end
			end
		-------------------------------------
		-------------------------------------
hook.Add( "HUDPaint", "GWHack_TargetESP", function( )
	surface.SetTextColor( 255, 255, 255, 255 ); surface.SetFont( "ConsoleText" ); surface.SetTextPos( GWHack.TradeSpamTarget:GetPos( ):ToScreen( ).x, GWHack.TradeSpamTarget:GetPos( ):ToScreen( ).y )
	surface.DrawText( GWHack.TradeSpamTarget:Nick( ))
end )
			
concommand.Add( "gwh_menu", function( )
	GWHack.Derma.MainFrame:SetVisible( true ); GWHack.Derma.MainFrame:MakePopup( );
end )