--[[
	Scripts/DarkrpEsp.lua
	SnoopDogg | (STEAM_0:1:11427632)
	===DStream===
]]

local version = "0.5a"
local frame

--[[
	Author: That Guy ( adf.ly/1vv3k for SethHack Profile)

	If you aren't from SethHack, fuck you and the leacher who gave you this.

]]--
local function info()
	frame = vgui.Create("DFrame")
	frame:SetPos(5, 5)
	frame:SetSize(ScrW() -10, ScrH() -10)
	frame:SetTitle("[SETH HACK] Player Info v"..version)
	frame:SetVisible(true)
	frame:SetDraggable(false)
	frame:ShowCloseButton(true)
	frame:MakePopup()
	frame:SetSkin("DarkRP")
	frame:SetSizable(true)
	frame:SetBackgroundBlur(true)

	local infolist = vgui.Create("DListView", frame)
	infolist:SetPos(5, 25)
	infolist:SetSize(frame:GetWide() -10, frame:GetTall() -30)
	infolist:AddColumn("Steam Name")
	infolist:AddColumn("Nick Name")
	infolist:AddColumn("Health")
	infolist:AddColumn("Armor")
	infolist:AddColumn("Money")
	infolist:AddColumn("Salary")
	infolist:AddColumn("Job name")
	infolist:AddColumn("Kills")
	infolist:AddColumn("Deaths")
	infolist:AddColumn("Ping")
	infolist:AddColumn("Rank")
	infolist:AddColumn("SteamID")
	local rank = "Guest"
	local Money,Job,Salary
	for k,v in pairs(player.GetAll()) do
		if v:IsSuperAdmin()  then
			Rank = "Super Admin"
		elseif v:IsAdmin() and !v:IsSuperAdmin() then
			Rank = "Admin"
		end
		Money = v.DarkRPVars.money or 0
		Job = v.DarkRPVars.job or "Citizen"
		Salary = v.DarkRPVars.salary or 0
		infolist:AddLine(
		v:SteamName(),
		v:Nick(),
		v:Health(),
		v:Armor(),
		"$"..Money,
		"$"..Salary,
		Job,
		v:Frags(),
		v:Deaths(),
		v:Ping(),
		Rank,
		v:SteamID()
		)
	end
end

concommand.Add("+playerinfo", info)
concommand.Add("-playerinfo", function() frame:Remove() end)