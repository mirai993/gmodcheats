--[[
	myfiles/46.lua
	ÄMÇÕ3008 | (STEAM_0:0:39879112)
	===DStream===
]]

CreateClientConVar('esp_hpbars', 0, true, true)
if GetConVarNumber('esp_hpbars') >= 1 then

	for k,v in pairs(player.GetAll()) do
		if v and v:IsValid() and v:IsPlayer() and v:Alive() then
			local xdraw = v:GetPos():ToScreen().x - 25
			local ydraw = v:GetPos():ToScreen().y +5
			local VCol = Color(0,255,0)
				if v:Health() <= 100 then
					VCol = Color(0,255,0)
					draw.RoundedBox( 2, v:GetPos():ToScreen().x - 25, v:GetPos():ToScreen().y +5, ((100 + v:Health()) / 2) - 50, 10, VCol)
				elseif v:Health() >= 101 then
					VCol = Color(0,255,v:Health()-100)
					draw.RoundedBox( 2, v:GetPos():ToScreen().x - 25, v:GetPos():ToScreen().y +5, 50, 10, VCol)
				end
				
			
			surface.SetDrawColor(Color(80,80,80))
			surface.DrawOutlinedRect(xdraw, ydraw, 50, 10)
		end
	end

end