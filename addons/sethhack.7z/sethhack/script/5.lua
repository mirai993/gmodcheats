local function EntityInformation()
	local trace = LocalPlayer():GetEyeTrace()
	print("Class: "..trace.Entity:GetClass())
	if trace.Hit and trace.Entity:IsValid() and string.find(string.lower(trace.Entity:GetClass()), "prop") then 
		print("Model: "..trace.Entity:GetModel())
		if type(trace.Entity:GetOwner()) == "string" then
			print("Owner: "..trace.Entity:GetOwner())	
		end
		--print("Health:"..trace.Entity:Health())
		PrintTable(trace.Entity:GetTable())
	elseif trace.Hit and trace.Entity:IsValid() and trace.Entity:GetClass() == "player" then
		print("Name: "..trace.Entity:Nick())
		print("Health "..trace.Entity:Health())
		print("Active Weapon: "..trace.Entity:GetActiveWeapon():GetPrintName())
		print("Is Admin?:", trace.Entity:IsAdmin())
		
	end
end
concommand.Add("GetModel", EntityInformation)
