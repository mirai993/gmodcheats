if SERVER then return false end

local Speed = 0.06

function AutoFire()
RunConsoleCommand( "+attack" )
timer.Simple( Speed/2, function()
RunConsoleCommand( "-attack" )
end)
end

function AFon()
if !timer.IsTimer( "AF" ) then
timer.Create( "AF", Speed, 0, AutoFire )
end
end
concommand.Add( "+autofire", AFon )

function AFoff()
if timer.IsTimer( "AF" ) then
timer.Remove( "AF" )
end
end
concommand.Add( "-autofire", AFoff )