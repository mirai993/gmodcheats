Most important/biggest script: FSpectate!(clientside)
FSpectate is a script that makes you able to go OUTSIDE of your body and fly around in noclipped mode while NOONE can see you flying. Then you can press reload on a player or an object and then you will see through their eyes or spectate the object. You can even make screens!
"Wow what I don't get it"
VIDEO!!(explanation + instructions)
View YouTUBE video
http://youtube.com/watch?v=DL00xfRgsvk
TIP: bind a key to fspectate( do "bind m fspectate" in console where m is the key)
(This script was made in honour to Vampired who made the "cameras" mod about 1.5 years ago)

Piano(Shared, works clientside and if the server has it then everyone hears you)
Clientside: say !piano or do piano in console to start the piano. You can either click the tones or set up to play on your keyboard by going to the bottom right of your screen and click setup. You can change tones by using the options at the bottom. In the textbox at the bottom right you can enter a soundpath and then you can play a song with that sound( like playing still alive with vo/scout_specialcompleted03.wav)
Server: There is a piano entity in the entities tab and a piano player SWEP to play the piano with.
For people who know this mod:
I removed the drums because it sucked balls.
No more vmfs, pure Lua.

Xray vision!(clientside)Unlike my modified version of TetaBonita's X-ray I rejected TetaBonita's reality and substituted my own. SO NO CREDITS TO TETABONITA!
Do ToggleFRay in console to toggle the xray. TIP: bind it to a key.

FDetectors (Clientside)
Make an fdetector by saying fdet <name here> or fdetector <name here> and remove a made detector by doing fremdet or fremovedetector. Of course you can also do fdetector <name> and fremovedetector in console.
THEN WHAT IS THIS?
This device is like a detection gate at the airport. But it doesn't only detect metal, it detects EVERYTHING. When a player goes through it it warns you that <player name here> has entered your detector. You can select its radius with your mouse and NOONE will EVER be able to enter your base without YOU knowing it! And if you set FDet_DoSay to 1 you will automaticly say through chat what's going through the fdetector!

Clientside votes!
Do you HATE it that you have to be an admin to make ulx votes in most servers? WELL NOT ANYMORE!
Make a vote by saying fvote <question here> like:
fvote DO YOU LIKE THE ADMINGE?
A moment later it will automaticly make a vote. and EVERYONE can vote by saying either !yes or !no. Stupid people who can't read and to /yes or /no will vote too. After a minute or when everyone has voted the results will become clear and everyone will see how many voted yes and how many voted no.

Special zoom(clientside)
I HATE THAT SUIT ZOOM BECAUSE HALF OF MY SCREEN IS BLACK AND IT EITHER ZOOMS TOO FAR OR IT ZOOMS TO CLOSE!
That's why you should use FZoom instead of the normal zoom. Bind a key to +fzoom.
Zoom in and out by using your scroll wheel when being zoomed. At a certain point where you zoom in "too much" the zoom sounds will change When you hear that it does Extra zoom which means you will look through objects that are near you BUT you can zoom infinitely!
Reset your zoom with reload.

Other small shit(all clientside)
Flashlight spammer: Console command = makesound or +makesound. This annoys the shit out of people but it's funny.
Rotate script: same as flashlight spammer but then rotates with it: Concommands: Frotate, fyes, fno. Fyes and Fno make you say no or yes to people who are looking at you.
Infomod: type getmodel in the console while looking at an entity or player to see their model and lots of information in the console.
Prop kill detector: set FPropKillDetector to 1 to make gmod TRY to find out who prop killed you. This is not always accurate and can even find multiple results.
Toggle shit: Do toggleduck or togglevoice to Toggle duck or Toggle your mic. Might be useful. If you can change the Lua you can change +duck to +sprint and -duck to -sprint to make it toggle run... (or any other + - command)
Arrest baton warning: If FArrestBatonWarning is set to 1 then EVERYTIME anyone pulls out his arrest baton you will say it. Kinda like a warning system to warn you and other people if they are about to be arrested :)