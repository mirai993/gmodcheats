function MagnetoThrow()
-- Nice and easy, turn it slow 180 
	timer.Simple(.02,Turn)
	timer.Simple(.04,Turn)
	timer.Simple(.06,Turn)
	timer.Simple(.08,Turn)
	timer.Simple(.10,Turn)
	timer.Simple(.12,Turn)
	timer.Simple(.14,Turn)
	timer.Simple(.16,Turn)
	timer.Simple(.18,Turn)
	timer.Simple(.20,Turn)
	timer.Simple(.22,Turn)
	timer.Simple(.24,Turn)
	timer.Simple(.26,Turn)
	timer.Simple(.28,Turn)
	timer.Simple(.30,Turn)
	timer.Simple(.32,Turn)
	timer.Simple(.34,Turn)
	timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
	timer.Simple(.46,TurnBack)
-- And deliver the final blow by pressing right click
	timer.Simple(.7,function() RunConsoleCommand("+attack2") end)
	timer.Simple(.72,function() RunConsoleCommand("-attack2") end)
end

function Turn()
-- Turn function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
-- Turn 180 function
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
end
-- Making it a console command
concommand.Add("ThrowMagneto",MagnetoThrow)