--------------------
local IsLoopActive = false


concommand.Add( "loop" , function( ply, cmd, args )
	local NextRun = { CurTime( ), args[1] }
	local CommandCount = { #string.Explode( ";", args[2] ), 0 }
	local Commands = string.Explode( ";", args[2] )
	IsLoopActive = true
	
	hook.Add( "Think", "command_loop", function( )
		if NextRun[1] < CurTime( ) then
			NextRun[1] = CurTime( ) + NextRun[2]
			CommandCount[2] = CommandCount[2] + 1
			if CommandCount[2] > CommandCount[1] then CommandCount[2] = 1 end
			
			ply:ConCommand( Commands[CommandCount[2]] )
		end
	end )
end )

concommand.Add( "loop_break", function( )
	if IsLoopActive then
		IsLoopActive = false
		hook.Remove( "Think", "command_loop" )
	else
		print( " > Currently loop isn't active!" )
	end
end )

--------------------
local IsHaltActive = false

concommand.Add( "halt", function( ply, cmd, args )
	local NextRun = { CurTime( ), args[1] }
	local CommandCount = { #string.Explode( ";", args[2] ), 0 }
	local Commands = string.Explode( ";", args[2] )
	IsHaltActive = true
	
	hook.Add( "Think", "command_halt", function( )
		if NextRun[1] < CurTime( ) then
			NextRun[1] = CurTime( ) + NextRun[2]
			CommandCount[2] = CommandCount[2] + 1
			if CommandCount[2] > CommandCount[1] then hook.Remove( "Think", "command_halt" ) end
			
			ply:ConCommand( Commands[CommandCount[2]] )
		end
	end )
end )

concommand.Add( "halt_break", function( )
	if IsHaltActive then
		IsHaltActive = false
		hook.Remove( "Think", "command_halt" )
	else
		print( " > Currently loop isn't active!" )
	end
end )

--------------------

concommand.Add( "RLua", function( ply, cmd, args )
	local LuaLine = string.Implode( " ", args )
	
	RunString( LuaLine )
end )