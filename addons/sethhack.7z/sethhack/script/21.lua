/*
Yes all these scripts are based off each other since they're all just timers and since I'm an uncreative asshole
Oh and as you may notice by the setup and retarded function/variable names I am also the one that made the anti-afk script that "K0's father in law." Posted :)
*/

-- Nigger

/* Commands:

spinlol: Random spin script, you'll spin really fast and it'll be obvious it's a script

fleshlight: Flashlight spam

Orgflashstyle1, Orgflashstyle2, Orgflashstyle3: These change your org's name in perp in a fancy and entertaining fashion, you must be the org owner for this to work. Oh and it will spam the side of your screen but you'll get used to it. PROTIP: doing one of the orgflash commands then another will stop the first one after its cycle is over, but it will not start the cycle for the second orgflash. DO NOT FUCKING ENTER THE COMMAND OVER AND OVER OR SHIT WILL GET FUCKED UP, when you try to end it it will go the end of its cycle which may take a couple seconds. Also, you may have to change the command ran, since I've noticed some servers do not use "perp_o_c" for changing org name, just go to the org clerk and manually change the org name to log the command:)
*/



lolspin = 0

function derpderpderpspin()
if lolspin == 1 then
	timer.Simple(.001,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.002,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.003,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.004,function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0)) end)
	timer.Simple(.005,derpderpderpspin)
end
end

function gololspin()
if lolspin == 1 then
lolspin = 0
derpderpderpspin()
elseif lolspin == 0 then
lolspin = 1
derpderpderpspin()
end
end
concommand.Add("spinlol",gololspin)




lollight = 0

function derpderpderpflash()
if lollight == 1 then
	timer.Simple(.02,function() RunConsoleCommand("impulse", "100") end)
	timer.Simple(.04,function() RunConsoleCommand("impulse", "100") end)
	timer.Simple(.06,function() RunConsoleCommand("impulse", "100") end)
	timer.Simple(.08,function() RunConsoleCommand("impulse", "100") end)
	timer.Simple(.1,derpderpderpflash)
end
end

function golollight()
if lollight == 1 then
lollight = 0
derpderpderpflash()
elseif lollight == 0 then
lollight = 1
derpderpderpflash()
end
end
concommand.Add("fleshlight",golollight)

orgflashtoggle = 0

function perporgflashaltalt()
if orgflashtoggle == 1 then
timer.Simple(.5,function() RunConsoleCommand("perp_o_c", "!", "LOL") end)
timer.Simple(.7,function() RunConsoleCommand("perp_o_c", "!!", "HACKS") end)
timer.Simple(.9,function() RunConsoleCommand("perp_o_c", "!!T", "HOW I DO THIS") end)
timer.Simple(1.2,function() RunConsoleCommand("perp_o_c", "!!TH", "I DUNNO") end)
timer.Simple(1.4,function() RunConsoleCommand("perp_o_c", "!!THE", "U TELL ME") end)
timer.Simple(1.6,function() RunConsoleCommand("perp_o_c", "!!THE ", "NOU TELL ME") end)
timer.Simple(1.8,function() RunConsoleCommand("perp_o_c", "!!THE S", "LOL HOW U DO?") end)
timer.Simple(2,function() RunConsoleCommand("perp_o_c", "!!THE SL", "Dude I dn't know..") end)
timer.Simple(2.2,function() RunConsoleCommand("perp_o_c", "!!THE SLA", "Fuck off bro you do") end)
timer.Simple(2.4,function() RunConsoleCommand("perp_o_c", "!!THE SLAV", "NO RLLY I DONT") end)
timer.Simple(2.6,function() RunConsoleCommand("perp_o_c", "!!THE SLAVE", " sdaf") end)
timer.Simple(2.8,function() RunConsoleCommand("perp_o_c", "!!THE SLAVET", "sdgasder") end)
timer.Simple(3,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETR", "dfag4gf") end)
timer.Simple(3.2,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRA", "fghfvb5") end)
timer.Simple(3.4,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRAD", "adfgntyas") end)
timer.Simple(3.6,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADE", "fdagcvcxvr") end)
timer.Simple(3.8,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADER", "LOLWUT") end)
timer.Simple(4,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADERS", "JEWS") end)
timer.Simple(4.2,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADERS!", "LOLWUT") end)
timer.Simple(4.4,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADERS!!", "JEWS") end)
timer.Simple(5,function() RunConsoleCommand("perp_o_c", "   ", "LOLWUT") end)
timer.Simple(5.1,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADERS!!", "LOLWUTZ") end)
timer.Simple(5.3,function() RunConsoleCommand("perp_o_c", "    ", "JEWS") end)
timer.Simple(5.4,function() RunConsoleCommand("perp_o_c", "!!THE SLAVETRADERS!!", "NOU") end)
	timer.Simple(7,perporgflashaltalt)
end
end


function perporgflashtogglealtalt()
if orgflashtoggle == 1 then
orgflashtoggle = 0
perporgflashaltalt()
elseif orgflashtoggle == 0 then
orgflashtoggle = 1
perporgflashaltalt()
end
end

concommand.Add("Orgflashstyle1",perporgflashtogglealtalt)



function perporgflashaltalt2()
if orgflashtoggle == 1 then
timer.Simple(0.2,function() RunConsoleCommand("perp_o_c", "!!!!!!!!!!!", "I'm a nigger") end)
timer.Simple(0.4,function() RunConsoleCommand("perp_o_c", "!!!!!!!!!!D", "I'm a chigger") end)
timer.Simple(0.6,function() RunConsoleCommand("perp_o_c", "!!!!!!!!!DJ", "I'm a figger") end)
timer.Simple(0.8,function() RunConsoleCommand("perp_o_c", "!!!!!!!!DJ-", "I'm a higger") end)
timer.Simple(1,function() RunConsoleCommand("perp_o_c", "!!!!!!!DJ-O", "I'm a jigger") end)
timer.Simple(1.2,function() RunConsoleCommand("perp_o_c", "!!!!!!DJ-OS", "I like cock") end)
timer.Simple(1.4,function() RunConsoleCommand("perp_o_c", "!!!!!DJ-OSU", "I'm a SADFSDFSDAigger") end)
timer.Simple(1.6,function() RunConsoleCommand("perp_o_c", "!!!!DJ-OSUM", "watwatinthebutt") end)
timer.Simple(1.8,function() RunConsoleCommand("perp_o_c", "!!!DJ-OSUMF", "Do it") end)
timer.Simple(2,function() RunConsoleCommand("perp_o_c", "!!DJ-OSUMFA", "A") end)
timer.Simple(2.2,function() RunConsoleCommand("perp_o_c", "!DJ-OSUMFAE", "B") end)
timer.Simple(2.4,function() RunConsoleCommand("perp_o_c", "DJ-OSUMFAEC", "C") end)
timer.Simple(2.6,function() RunConsoleCommand("perp_o_c", "J-OSUMFAEC!", "D") end)
timer.Simple(2.8,function() RunConsoleCommand("perp_o_c", "-OSUMFAEC!!", "E") end)
timer.Simple(3,function() RunConsoleCommand("perp_o_c", "OSUMFAEC!!!", "F") end)
timer.Simple(3.2,function() RunConsoleCommand("perp_o_c", "SUMFAEC!!!!", "G") end)
timer.Simple(3.4,function() RunConsoleCommand("perp_o_c", "UMFAEC!!!!!", "H") end)
timer.Simple(3.6,function() RunConsoleCommand("perp_o_c", "FAEC!!!!!!!", "I") end)
timer.Simple(3.8,function() RunConsoleCommand("perp_o_c", "AEC!!!!!!!!", "J") end)
timer.Simple(4,function() RunConsoleCommand("perp_o_c", "EC!!!!!!!!!", "K") end)
timer.Simple(4.2,function() RunConsoleCommand("perp_o_c", "C!!!!!!!!!!", "Jv+Km;D") end)
	timer.Simple(4.4,perporgflashaltalt2)
end
end


function perporgflashtogglealtalt2()
if orgflashtoggle == 1 then
orgflashtoggle = 0
perporgflashaltalt2()
elseif orgflashtoggle == 0 then
orgflashtoggle = 1
perporgflashaltalt2()
end
end

concommand.Add("Orgflashstyle2",perporgflashtogglealtalt2)


function perporgflashaltalt3()
if orgflashtoggle == 1 then
timer.Simple(1,function() RunConsoleCommand("perp_o_c", "Musiek <3", "Dance") end)
timer.Simple(2,function() RunConsoleCommand("perp_o_c", "Muzik� <3", "Dance") end)
timer.Simple(3,function() RunConsoleCommand("perp_o_c", "Musiqi <3", "Dance") end)
timer.Simple(4,function() RunConsoleCommand("perp_o_c", "Musika <3", "Dance") end)
timer.Simple(5,function() RunConsoleCommand("perp_o_c", "Muzyka <3", "Dance") end)
timer.Simple(6,function() RunConsoleCommand("perp_o_c", "Muzika <3", "Dance") end)
timer.Simple(7,function() RunConsoleCommand("perp_o_c", "M�sica <3", "Dance") end)
timer.Simple(8,function() RunConsoleCommand("perp_o_c", "Glazba <3", "Dance") end)
timer.Simple(9,function() RunConsoleCommand("perp_o_c", "Hudba <3", "Dance") end)
timer.Simple(10,function() RunConsoleCommand("perp_o_c", "Musik <3", "Dance") end)
timer.Simple(11,function() RunConsoleCommand("perp_o_c", "Muziek <3", "Dance") end)
timer.Simple(12,function() RunConsoleCommand("perp_o_c", "Muusika <3", "Dance") end)
timer.Simple(13,function() RunConsoleCommand("perp_o_c", "Musiikki <3", "Dance") end)
timer.Simple(14,function() RunConsoleCommand("perp_o_c", "Musique <3", "Dance") end)
timer.Simple(15,function() RunConsoleCommand("perp_o_c", "Mousik�n <3", "Dance") end)
timer.Simple(16,function() RunConsoleCommand("perp_o_c", "Mizik <3", "Dance") end)
timer.Simple(17,function() RunConsoleCommand("perp_o_c", "Zene <3", "Dance") end)
timer.Simple(18,function() RunConsoleCommand("perp_o_c", "Ceol <3", "Dance") end)
timer.Simple(19,function() RunConsoleCommand("perp_o_c", "Musica <3", "Dance") end)
timer.Simple(20,function() RunConsoleCommand("perp_o_c", "Ongaku <3", "Dance") end)
timer.Simple(21,function() RunConsoleCommand("perp_o_c", "Muzikas <3", "Dance") end)
timer.Simple(22,function() RunConsoleCommand("perp_o_c", "Musikk <3", "Dance") end)
timer.Simple(23,function() RunConsoleCommand("perp_o_c", "Muzyka <3", "Dance") end)
timer.Simple(24,function() RunConsoleCommand("perp_o_c", "Muzica <3", "Dance") end)
timer.Simple(25,function() RunConsoleCommand("perp_o_c", "Muzyka <3", "Dance") end)
timer.Simple(26,function() RunConsoleCommand("perp_o_c", "Glasba <3", "Dance") end)
timer.Simple(27,function() RunConsoleCommand("perp_o_c", "M�sica <3", "Dance") end)
timer.Simple(28,function() RunConsoleCommand("perp_o_c", "Halisi <3", "Dance") end)
timer.Simple(29,function() RunConsoleCommand("perp_o_c", "Phelng <3", "Dance") end)
timer.Simple(30,function() RunConsoleCommand("perp_o_c", "M�zik <3", "Dance") end)
timer.Simple(31,function() RunConsoleCommand("perp_o_c", "Cerddoriaeth <3", "Dance") end)
timer.Simple(32,function() RunConsoleCommand("perp_o_c", "�m nhac <3", "Dance") end)
timer.Simple(33,function() RunConsoleCommand("perp_o_c", "Music <3", "Dance") end)
	timer.Simple(40,perporgflashaltalt3)
end
end


function perporgflashtogglealtalt3()
if orgflashtoggle == 1 then
orgflashtoggle = 0
perporgflashaltalt3()
elseif orgflashtoggle == 0 then
orgflashtoggle = 1
perporgflashaltalt3()
end
end

concommand.Add("Orgflashstyle3",perporgflashtogglealtalt3)


