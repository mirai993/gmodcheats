#pragma once

namespace detours {
	extern void hook();
	extern void postInit();
	extern void unHook();
} 