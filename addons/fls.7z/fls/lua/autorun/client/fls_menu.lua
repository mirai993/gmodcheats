function FLS.Internal.ShowMenu()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(ScrW() / 1.5, ScrH() / 1.5)
		Frame:Center()
		Frame:SetTitle("FLS Main Menu")
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:MakePopup()
	local Tabs = vgui.Create("DPropertySheet", Frame)
		Tabs:SetSize(Tabs:GetParent():GetWide() - 20, Tabs:GetParent():GetTall() - 40)
		Tabs:SetPos(10, 30)
	local ConfigPanel = vgui.Create("DPanel", Tabs)
		ConfigPanel:SetSize(ConfigPanel:GetParent():GetWide() - 20, ConfigPanel:GetParent():GetTall() - 20)
		ConfigPanel:SetPos(10, 10)
		Tabs:AddSheet("Config Panel", ConfigPanel, "gui/silkicons/box", "Config Panel")
	local PlayerPanel = vgui.Create("DPanel", Tabs)
		PlayerPanel:SetSize(PlayerPanel:GetParent():GetWide() - 20, PlayerPanel:GetParent():GetTall() - 20)
		PlayerPanel:SetPos(10, 10)
		Tabs:AddSheet("Player List", PlayerPanel, "gui/silkicons/user", "Player List")
	local UtilPanel = vgui.Create("DPanel", Tabs)
		UtilPanel:SetSize(UtilPanel:GetParent():GetWide() - 20, UtilPanel:GetParent():GetTall() - 20)
		UtilPanel:SetPos(10, 10)
		Tabs:AddSheet("Utilities", UtilPanel, "gui/silkicons/user", "Utilities")
	local UtilList = vgui.Create("DPanelList", UtilPanel)
		UtilList:SetSize(UtilList:GetParent():GetWide() - 20, UtilList:GetParent():GetTall() - 20)
		UtilList:SetPos(10, 10)
		UtilList:SetSpacing(5)
		UtilList:SetPadding(5)
		UtilList:EnableHorizontal(false)
		UtilList:EnableVerticalScrollbar(true)
		for k, v in pairs(FLS.Utilities) do
			local title = v.title or "Unknown"
			local button = vgui.Create("DButton")
				button:SetText(title)
				button.DoClick = function()
					v.func()
				end
			UtilList:AddItem(button)
		end

	local CFGColumn = vgui.Create("DColumnSheet", ConfigPanel)
		CFGColumn:SetSize(ConfigPanel:GetWide() - 200, ConfigPanel:GetTall())
		CFGColumn:SetPos(10, 10)
		for k, v in pairs(FLS.Modules) do
			if v.HasConfig then
				local panel = vgui.Create("DPanel", CFGColumn)
					panel:SetSize(CFGColumn:GetWide(), CFGColumn:GetTall())
					panel.Paint = function(self)
						surface.SetDrawColor(Color(48, 48, 48, 255))
						surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
					end
				local category = vgui.Create("DCollapsibleCategory", panel)
					category:SetLabel("Config")
					category:SetExpanded(0)
					category:SetSize(300, 300)
					category:SetPos(5, 5)
				local contents = vgui.Create("DPanelList")
					contents:SetAutoSize(true)
					contents:SetSpacing(5)
					contents:SetPadding(5)
					contents:EnableHorizontal(false)
					contents:EnableVerticalScrollbar(true)
				category:SetContents(contents)

				CFGColumn:AddSheet(v.Title or "Unknown", panel, "gui/silkicons/box", v.Title or "Unknown")

				for _, cbox in pairs(FLS.Data.CFGCheckBoxes) do
					if cbox.mod == v then
						local CheckBox = vgui.Create("DCheckBoxLabel")
							CheckBox:SetText(cbox.title or "Unknown")
							CheckBox:SetConVar(cbox.convar)
							CheckBox:SetValue(GetConVar(cbox.convar):GetBool())
							CheckBox:SizeToContents()
						contents:AddItem(CheckBox)
					end
				end
				for _, tbox in pairs(FLS.Data.CFGTextBoxes) do
					if tbox.mod == v then
						local TextArea = vgui.Create("DTextEntry")
							TextArea:SetText(tbox.title or "Unknown")
							TextArea:SetSize(150, 22)
							TextArea:SetValue(GetConVar(tbox.convar):GetString())
							TextArea.OnEnter = function()
								RunConsoleCommand(tbox.convar, TextArea:GetValue())
							end
						contents:AddItem(TextArea)
					end
				end
				for _, slider in pairs(FLS.Data.CFGSliders) do
					if slider.mod == v then
						local NumSlider = vgui.Create("DNumSlider")
							NumSlider:SetText(slider.title or "Unknown")
							NumSlider:SetSize(100, 40)
							NumSlider:SetMin(slider.min)
							NumSlider:SetMax(slider.max)
							NumSlider:SetDecimals(0)
							NumSlider:SetConVar(slider.convar)
							NumSlider:SetValue(GetConVar(slider.convar):GetFloat())
						contents:AddItem(NumSlider)
					end
				end
				for _, color in pairs(FLS.Data.CFGColors) do
					if color.mod == v then
						local label = vgui.Create("DLabel")
							label:SetText(color.title)
							label:SizeToContents()
						contents:AddItem(label)
						local ColorMix = vgui.Create("DColorMixer")
							ColorMix:SetSize(100, 100)
							ColorMix:SetColor(Color(GetConVar(color.convar .. "_r"):GetInt(), GetConVar(color.convar .. "_g"):GetInt(), GetConVar(color.convar .. "_b"):GetInt(), GetConVar(color.convar .. "_a"):GetInt()))
						local think = ColorMix.Think
						ColorMix.Think = function()
							think(ColorMix)
							RunConsoleCommand(color.convar .. "_r", ColorMix:GetColor().r)
							RunConsoleCommand(color.convar .. "_g", ColorMix:GetColor().g)
							RunConsoleCommand(color.convar .. "_b", ColorMix:GetColor().b)
							RunConsoleCommand(color.convar .. "_a", ColorMix:GetColor().a)
						end
						contents:AddItem(ColorMix)
					end
				end
			end
		end
end

concommand.Add("fls_menu", FLS.Internal.ShowMenu)