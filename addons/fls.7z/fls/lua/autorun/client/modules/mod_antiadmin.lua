local Mod = FLSModule("Anti Admin Effects")
	Mod.IsEnabled["Think"] = true
	Mod.HasConfig = true

local umh = usermessage.Hook
function usermessage.Hook(name, func)
	if FLS.Util.ModConVarEnabled(Mod, "antiblind") then
		if name != "ulx_blind" then
			umh(name, func)
		end
	else
		umh(name, func)
	end
end

function Mod:Think()
	if FLS.Util.ModConVarEnabled(Mod, "antimute") then
		if LocalPlayer():GetNWBool("Muted") then
			LocalPlayer():SetNWBool("Muted", false)
		end
		hook.Remove("PlayerBindPress", "ULXGagForce")
		timer.Destroy("GagLocalPlayer")
	end
	if FLS.Util.ModConVarEnabled(Mod, "antiblind") then
		if LocalPlayer():GetNWBool("EV_Blinded") then
			LocalPlayer():SetNWBool("EV_Blinded", false)
		end
	end
end

FLS.Util.AddCFGCheckBox(Mod, "Enable Anti-Gag/Anti-Mute", "antimute")
FLS.Util.AddCFGCheckBox(Mod, "Enable Anti-Blind", "antiblind")