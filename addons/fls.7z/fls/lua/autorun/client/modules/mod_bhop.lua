local Mod = FLSModule("Bunnyhop")

function FLS.Util.BunnyHop()
	if LocalPlayer():IsOnGround() then
		LocalPlayer():ConCommand("+jump")
	else
		LocalPlayer():ConCommand("-jump")
	end
end

concommand.Add("+fls_bhop", function()
	hook.Add("Think", "FLS.Util.BunnyHop", FLS.Util.BunnyHop)
end)

concommand.Add("-fls_bhop", function()
	hook.Remove("Think", "FLS.Util.BunnyHop")
	LocalPlayer():ConCommand("-jump")
end)