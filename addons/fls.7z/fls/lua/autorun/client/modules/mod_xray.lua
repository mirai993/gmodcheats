FLS.Data.XRayEnts = {}
FLS.Data.XRayEntTypes = {
	"player",
	"prop",
	"npc_",
	"spawned_",
	"func_door",
	"prop_door_rotating"
}

function FLS.Util.AddXRayEntity(ent)
	if ent and ent:IsValid() then
		table.insert(FLS.Data.XRayEnts, {entity = ent:EntIndex(), mat = ent:GetMaterial()})
	end
end

local Mod = FLSModule("X-Ray")
FLS.Util.SetConVarToggle(Mod, "xray", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.HasConfig = true

CreateClientConVar("fls_xray_showdata", "1", true, false)
	
function Mod:Draw()
	if GetConVar("fls_xray_showdata"):GetBool() then
		surface.SetDrawColor(Color(0, 0, 0, 128))
		surface.DrawRect(5, 5, 160, 40)
		surface.SetFont("DefaultFixed")
		surface.SetTextColor(Color(0, 255, 0, 255))
		surface.SetTextPos(10, 10)
		surface.DrawText("XRay entity count: " .. #FLS.Data.XRayEnts)
	end
	if FLS.Util.ModConVarEnabled(Mod, "drawlines") then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				cam.Start3D(LocalPlayer():GetShootPos(), LocalPlayer():EyeAngles())
					render.SetMaterial(Material("cable/blue_elec"))
					render.DrawBeam(v:GetShootPos(), v:GetEyeTrace().HitPos, 5, 1, 1, Color(255, 255, 255, 255))
					render.SetMaterial(Material("cable/hydra"))
					local t = {}
						t.start = v:GetShootPos()
						t.endpos = v:GetShootPos() + Vector(0, 0, 99999999)
						t.filter = v
					local trace = util.TraceLine(t)
					render.DrawBeam(trace.HitPos, v:GetShootPos(), 15, 1, 1, Color(255, 255, 255, 255))
				cam.End3D()
			end
		end
	end
	if #FLS.Data.XRayEnts <= 0 then
		RunConsoleCommand("rope_rendersolid", "0")
		surface.PlaySound("items/nvg_on.wav")
		FLS.Util.InitXRayEnts()
	end
	for k, v in pairs(FLS.Data.XRayEnts) do
		local xent = Entity(v.entity)
		if xent and xent:IsValid() then
			if xent:IsPlayer() then
				if FLS.Util.ModConVarEnabled(Mod, "drawplayers") then
					xent:SetMaterial("models/xray_wireframe")
					xent:SetColor(Color(0, 255, 0, 255))
				else
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
					table.remove(FLS.Data.XRayEnts, k)
				end
			elseif string.match(string.lower(xent:GetClass()), "prop_physics") then
				if FLS.Util.ModConVarEnabled(Mod, "drawprops") then
					xent:SetMaterial("models/xray_wireframe")
					xent:SetColor(Color(128, 0, 0, 128))
				else
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
					table.remove(FLS.Data.XRayEnts, k)
				end
			elseif string.match(string.lower(xent:GetClass()), "npc") then
				if FLS.Util.ModConVarEnabled(Mod, "drawnpcs") then
					xent:SetMaterial("models/xray_wireframe")
					xent:SetColor(Color(0, 0, 255, 255))
				else
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
					table.remove(FLS.Data.XRayEnts, k)
				end
			elseif string.match(string.lower(xent:GetClass()), "spawned") then
				if FLS.Util.ModConVarEnabled(Mod, "drawitems") then
					xent:SetMaterial("models/xray_wireframe")
					xent:SetColor(Color(255, 255, 0, 255))
				else
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
					table.remove(FLS.Data.XRayEnts, k)
				end
			else
				if FLS.Util.ModConVarEnabled(Mod, "drawother") then
					xent:SetMaterial("models/xray_wireframe")
					xent:SetColor(Color(0, 128, 0, 255))
				else
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
					table.remove(FLS.Data.XRayEnts, k)
				end
			end
		else
			table.remove(FLS.Data.XRayEnts, k)
		end
	end
end

function FLS.Util.InitXRayEnts()
	FLS.Data.XRayEnts = {}
	table.Empty(FLS.Data.XRayEnts)
	for k, v in pairs(ents.GetAll()) do
		for _, str in pairs(FLS.Data.XRayEntTypes) do
			if string.match(string.lower(v:GetClass()), string.lower(str)) then
				FLS.Util.AddXRayEntity(v)
			end
		end
	end
end

hook.Add("Think", "FLS.XRay.OnTurnedOff", function()
	if not FLS.Util.IsConVarEnabled(Mod) then
		if #FLS.Data.XRayEnts > 0 then
			RunConsoleCommand("rope_rendersolid", "1")
			surface.PlaySound("items/nvg_off.wav")
			for k, v in pairs(FLS.Data.XRayEnts) do
				local xent = Entity(v.entity)
				if xent and xent:IsValid() then
					xent:SetMaterial(v.mat)
					xent:SetColor(Color(255, 255, 255, 255))
				end
			end
			table.Empty(FLS.Data.XRayEnts)
		end
	end
end)

hook.Add("OnEntityCreated", "FLS.XRay.AddXRayEntity", function(ent)
	for _, str in pairs(FLS.Data.XRayEntTypes) do
		if ent and ent:IsValid() then
			if string.match(string.lower(ent:GetClass()), string.lower(str)) then
				FLS.Util.AddXRayEntity(ent)
			end
		end
	end
end)

FLS.Util.AddCFGCheckBox(Mod, "Enable XRay", "enabled")
FLS.Util.AddCFGCheckBox(Mod, "Draw Players", "drawplayers")
FLS.Util.AddCFGCheckBox(Mod, "Draw Props", "drawprops")
FLS.Util.AddCFGCheckBox(Mod, "Draw NPCs", "drawnpcs")
FLS.Util.AddCFGCheckBox(Mod, "Draw Items", "drawitems")
FLS.Util.AddCFGCheckBox(Mod, "Draw Other", "drawother")
FLS.Util.AddCFGCheckBox(Mod, "Tracer Lines", "drawlines")