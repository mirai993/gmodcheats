local Mod = FLSModule("ESP")
FLS.Util.SetConVarToggle(Mod, "esp", 1)
	Mod.IsEnabled["Draw"] = true
	Mod.HasConfig = true

function Mod:Draw()
	if FLS.Util.ModConVarEnabled(Mod, "drawplayers") then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				local boxsize = FLS.Util.GetModValue(Mod, "boxsize")
				local pos = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
					pos = pos:ToScreen()
				surface.SetDrawColor(FLS.Util.GetModColor(Mod, "boxcolor"))
				surface.DrawOutlinedRect(pos.x - (boxsize / 2), pos.y - (boxsize / 2), boxsize, boxsize)

				local colb = FLS.Util.GetModColor(Mod, "boxcolor")
					colb.a = colb.a - 128
				surface.SetDrawColor(colb)
				surface.DrawOutlinedRect(pos.x - (boxsize / 2) + 3, pos.y - (boxsize / 2) + 3, boxsize - 6, boxsize - 6)

				local coln = FLS.Util.GetModColor(Mod, "boxcolor")
					coln.a = 255
				surface.SetFont("DefaultBold")
				surface.SetTextColor(coln)
				surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2))
				surface.DrawText(v:Nick())
				if FLS.Util.ModConVarEnabled(Mod, "drawrank") then
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.DrawText(" ")
					local rank = ""
					if v:IsAdmin() and not v:IsSuperAdmin() then
						rank = "[Admin]"
					elseif v:IsSuperAdmin() then
						rank = "[Superadmin]"
					end
					surface.DrawText(rank)
				end
				if FLS.Util.ModConVarEnabled(Mod, "drawplayermoney") then
					local money = "???"
					if v.DarkRPVars then
						if v.DarkRPVars.money and v.DarkRPVars.money != nil then
							money = v.DarkRPVars.money
						end
					end
					surface.SetFont("DefaultSmall")
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 12)
					surface.DrawText("Money: " .. "$" .. money)
				end
				if FLS.Util.ModConVarEnabled(Mod, "drawplayerdist") then
					local dist = math.Round(LocalPlayer():GetEyeTrace().HitPos:Distance(LocalPlayer():GetShootPos()))
					surface.SetFont("DefaultSmall")
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 20)
					surface.DrawText("Distance: " .. dist)
				end
				if FLS.Util.ModConVarEnabled(Mod, "drawplayerweapon") then
					local wep = "Unknown"
					if v:Alive() then
						if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
							if v:GetActiveWeapon():GetPrintName() and v:GetActiveWeapon():GetPrintName() != nil then
								wep = v:GetActiveWeapon():GetPrintName()
							end
						end
					end
					surface.SetFont("DefaultSmall")
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 28)
					surface.DrawText("Weapon: " .. wep)
				end
				if FLS.Util.ModConVarEnabled(Mod, "drawplayerhealth") then
					local health = "DEAD"
					surface.SetFont("DefaultSmall")
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetTextPos(pos.x + (boxsize / 2) + 3, pos.y - (boxsize / 2) + 36)
					surface.DrawText("Health: ")
					if v:Alive() then
						surface.SetTextColor(Color(0, 255, 0, 255))
						if v:Health() and v:Health() != nil then
							health = v:Health() .. "%"
						end
					else
						surface.SetTextColor(Color(255, 0, 0, 255))
					end
					surface.DrawText(health)
				end
			end
		end
	end
	if FLS.Util.ModConVarEnabled(Mod, "drawcrosshair") then
		local dist = math.Round(LocalPlayer():GetEyeTrace().HitPos:Distance(LocalPlayer():GetShootPos()))
		surface.SetDrawColor(Color(255, 0, 0, 255))
		surface.DrawOutlinedRect((ScrW() / 2) - 4, (ScrH() / 2) - 4, 8, 8)
		surface.DrawRect((ScrW() / 2) - 1, (ScrH() / 2) - 1, 2, 2)

		surface.SetDrawColor(Color(128, 0, 0, 255))
		surface.DrawRect((ScrW() / 2) - 18 - (dist / 700), (ScrH() / 2) - 1, 10, 2)
		surface.DrawRect((ScrW() / 2) + 8 + (dist / 700), (ScrH() / 2) - 1, 10, 2)
		surface.DrawRect((ScrW() / 2) - 1, (ScrH() / 2) - 18 - (dist / 700), 2, 10)
		surface.DrawRect((ScrW() / 2) - 1, (ScrH() / 2) + 8 + (dist / 700), 2, 10)

		surface.SetFont("DefaultBold")
		surface.SetTextColor(Color(255, 0, 0, 255))
		surface.SetTextPos((ScrW() / 2) - (surface.GetTextSize("Distance: " .. dist) / 2), (ScrH() / 2) + 18 + (dist / 700))
		surface.DrawText("Distance: ")
		surface.SetFont("Default")
		surface.DrawText(dist)
	end
end

FLS.Util.AddCFGCheckBox(Mod, "Enable ESP", "enabled")
FLS.Util.AddCFGCheckBox(Mod, "Draw Players", "drawplayers", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Player Money", "drawplayermoney", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Player Distance", "drawplayerdist", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Player Weapon", "drawplayerweapon", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Player Health", "drawplayerhealth", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Player Rank", "drawrank", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Shipments", "drawshipments", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Printers", "drawprinters", 1)
FLS.Util.AddCFGCheckBox(Mod, "Draw Crosshair", "drawcrosshair", 1)
FLS.Util.AddCFGSlider(Mod, "Boxsize", "boxsize", 30, 10, 50)
FLS.Util.AddCFGColor(Mod, "Box Color", "boxcolor", 255, 0, 0, 255)