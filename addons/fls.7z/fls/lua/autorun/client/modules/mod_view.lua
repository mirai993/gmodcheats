local Mod = FLSModule("View Utils")

function FLS.Util.DrawForward()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(Angle(0, ang.y, ang.r))
end

concommand.Add("+drawfixed", function()
	hook.Add("Think", "FLS.Util.DrawForward", FLS.Util.DrawForward)
end)

concommand.Add("-drawfixed", function()
	hook.Remove("Think", "FLS.Util.DrawForward")
end)