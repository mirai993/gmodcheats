local Mod = FLSModule("Rotate")

function FLS.Util.Rotate()
	local ang = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles(ang - Angle(0, 180, 0))
end

concommand.Add("fls_rotate", FLS.Util.Rotate)