local List
local TextField

FLS.Util.Notepad = {}
FLS.Util.NotepadServerLua = false

function FLS.Util.Notepad.UpdateList()
	List:Clear()
	for k, v in pairs(file.Find("notepad/*.txt")) do
		List:AddLine(v)
	end
end

function FLS.Util.Notepad.LoadFile(value)
	if file.Exists("notepad/" .. value) then
		File = file.Read("notepad/" .. value)
		TextField:SetText(File)
	end
	FLS.Util.Notepad.UpdateList()
end

function FLS.Util.Notepad.SaveFile(value)
	file.Write("notepad/" .. value, TextField:GetValue())
	FLS.Util.Notepad.UpdateList()
end

function FLS.Notepad()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(ScrW() / 1.5, ScrH() / 1.5)
		Frame:Center()
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:SetTitle("Notepad for Gmod")
		Frame:MakePopup()
	local CloseButton = vgui.Create("DButton", Frame)
		CloseButton:SetSize(80, 20)
		CloseButton:SetPos(10, Frame:GetTall() - CloseButton:GetTall() - 10)
		CloseButton:SetText("Close")
		CloseButton.DoClick = function()
			Frame:Close()
		end
	local FileName = vgui.Create("DTextEntry", Frame)
		FileName:SetSize(200, 20)
		FileName:SetPos(10 + CloseButton:GetWide() + 5, Frame:GetTall() - FileName:GetTall() - 10)
		FileName:SetText("File Name or Path")
	local ManualLoad = vgui.Create("DButton", Frame)
		ManualLoad:SetSize(150, 20)
		ManualLoad:SetPos(10 + CloseButton:GetWide() + 5 + FileName:GetWide() + 5, Frame:GetTall() - ManualLoad:GetTall() - 10)
		ManualLoad:SetText("Load")
		ManualLoad.DoClick = function()
			FLS.Util.Notepad.LoadFile(FileName:GetValue())
		end
	local SaveButton = vgui.Create("DButton", Frame)
		SaveButton:SetSize(150, 20)
		SaveButton:SetPos(10 + CloseButton:GetWide() + 5 + FileName:GetWide() + 5 + SaveButton:GetWide() + 5, Frame:GetTall() - ManualLoad:GetTall() - 10)
		SaveButton:SetText("Save File")
		SaveButton.DoClick = function()
			FLS.Util.Notepad.SaveFile(FileName:GetValue())
		end
	local SelallButton = vgui.Create("DButton", Frame)
		SelallButton:SetSize(150, 20)
		SelallButton:SetPos(10 + CloseButton:GetWide() + 5 + FileName:GetWide() + 5 + SaveButton:GetWide() + 5 + SelallButton:GetWide() + 5, Frame:GetTall() - ManualLoad:GetTall() - 10)
		SelallButton:SetText("Select All")
		SelallButton.DoClick = function()
			TextField:SelectAll()
		end
	local ClearButton = vgui.Create("DButton", Frame)
		ClearButton:SetSize(150, 30)
		ClearButton:SetPos(Frame:GetWide() - 200 + 20, 30)
		ClearButton:SetText("Clear All Text")
		ClearButton.DoClick = function()
			TextField:SetText("")
		end
	local LuaButton = vgui.Create("DButton", Frame)
		LuaButton:SetSize(150, 30)
		LuaButton:SetPos(Frame:GetWide() - 200 + 20, 30 + ClearButton:GetTall() + 5)
		LuaButton:SetText("Run text as Lua")
		LuaButton.DoClick = function()
			if not FLS.Util.NotepadServerLua then
				RunString(TextField:GetValue())
			else
				datastream.StreamToServer("serverlua", {TextField:GetValue()})
			end
		end
	local label1 = vgui.Create("DLabel", Frame)
		label1:SetPos(Frame:GetWide() - 200 + 20, 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 8)
		label1:SetText("Search text")
		label1:SizeToContents()
	local textscan = vgui.Create("DTextEntry", Frame)
		textscan:SetPos(Frame:GetWide() - 200 + 20 + 70, 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 5)
		textscan:SetText("Text")
		textscan:SetSize(80, 20)
	local label2 = vgui.Create("DLabel", Frame)
		label2:SetPos(Frame:GetWide() - 200 + 20, 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 5 + label1:GetTall() + 13)
		label2:SetText("Replace With")
		label2:SizeToContents()
	local repwith = vgui.Create("DTextEntry", Frame)
		repwith:SetPos(Frame:GetWide() - 200 + 20 + 70, 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 5 + label1:GetTall() + 10)
		repwith:SetText("Text")
		repwith:SetSize(80, 20)
	local ReplaceButton = vgui.Create("DButton", Frame)
		ReplaceButton:SetSize(150, 30)
		ReplaceButton:SetPos(Frame:GetWide() - 200 + 20, 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 5 + label1:GetTall() + 5 + label2:GetTall() + 15)
		ReplaceButton:SetText("Replace Text")
		ReplaceButton.DoClick = function()
			local text = TextField:GetValue()
				text = string.Replace(text, textscan:GetValue(), repwith:GetValue())
			TextField:SetText(text)
		end
	List = vgui.Create("DListView", Frame)
		local sizey = 30 + ClearButton:GetTall() + 5 + LuaButton:GetTall() + 5 + label1:GetTall() + 5 + label2:GetTall() + 15 + ReplaceButton:GetTall() + 5
		List:SetSize(170, Frame:GetTall() - sizey - 40)
		List:SetPos(Frame:GetWide() - 200 + 20, sizey)
		List:AddColumn("Files")
		List.DoDoubleClick = function(line, index, value)
			FLS.Util.Notepad.LoadFile(value:GetValue(1))
		end
		FLS.Util.Notepad.UpdateList()
	TextField = vgui.Create("DTextEntry", Frame)
		TextField:SetSize(Frame:GetWide() - 200, Frame:GetTall() - 40 - FileName:GetTall() - 50)
		TextField:SetPos(10, 60)
		TextField:SetMultiline(true)
	local ChoiceButton = vgui.Create("DMultiChoice", Frame)
		ChoiceButton:SetSize(100, 20)
		ChoiceButton:SetPos(10, 30)
		ChoiceButton:SetText("Client Lua")
		ChoiceButton:AddChoice("Client Lua")
		ChoiceButton:AddChoice("Datastream Lua")
		ChoiceButton.OnSelect = function(index, value, data)
			print(value)
			if value == 1 then
				FLS.Util.NotepadServerLua = false
			elseif value == 2 then
				FLS.Util.NotepadServerLua = true
			end
		end
end

FLS.RegisterUtility("Notepad", FLS.Notepad, "notepad")