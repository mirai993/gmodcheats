FLSUM = {}

FLSUM.UserMessageHook = usermessage.Hook
FLSUM.UserMessages = {}

local Frame = vgui.Create("DFrame")
	Frame:SetSize(300, 200)
	Frame:SetPos(ScrW() - 300 - 20, ScrH() - 200 - 20)
	Frame:SetTitle("Usermessage List")
	Frame:MakePopup()

local List = vgui.Create("DListView", Frame)
	List:SetSize(Frame:GetWide() - 20, Frame:GetTall() - 40)
	List:SetPos(10, 30)
	List:AddColumn("Usermessage")
	List.OnClickLine = function(line, index, value)
		FLSUM.UserMessageHook(value, FLSUM.UserMessages[value].func())
	end

local function UpdateList()
	List:Clear()
	for k, v in pairs(FLSUM.UserMessages) do
		List:AddLine(k)
	end
end	

function usermessage.Hook(name, func)
	chat.AddText(Color(0, 255, 0), "Blocking Usermessage: ", Color(255, 255, 255), name, Color(0, 255, 0), "!")
	FLSUM.UserMessages[name].func = func
	UpdateList()
end