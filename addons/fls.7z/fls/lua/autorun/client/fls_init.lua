/*
	* The forline scripts pack v1.0
	* The first 'real' release of the scripts pack,
	* with effecient API for custom modules.
	* With Comments.
*/

// Initialization of the global table since this is object-oriented.
FLS = {}
FLS.Data = {}
FLS.Internal = {}
FLS.Modules = {}
FLS.Util = {}
FLS.Utilities = {}

FLS.Data.CFGCheckBoxes = {}
FLS.Data.CFGTextBoxes = {}
FLS.Data.CFGSliders = {}
FLS.Data.CFGColors = {}

function FLS.Util.AddCFGCheckBox(Mod, title, convar, default)
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar, default or "1", true, false)
	end
	table.insert(FLS.Data.CFGCheckBoxes, {mod = Mod, title = title or "Unknown", convar = "fls_" .. Mod.ConVar .. "_" .. convar})
end

function FLS.Util.AddCFGTextBox(Mod, title, convar, default)
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar, default or "Text", true, false)
	end
	table.insert(FLS.Data.CFGTextBoxes, {mod = Mod, title = title or "Unknown", convar = "fls_" .. Mod.ConVar .. "_" .. convar})
end

function FLS.Util.AddCFGSlider(Mod, title, convar, default, min, max)
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar) then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar, default or 0, true, false)
	end
	table.insert(FLS.Data.CFGSliders, {mod = Mod, title = title or "Unknown", convar = "fls_" .. Mod.ConVar .. "_" .. convar, min = min or 0, max = max or 1000})
end

function FLS.Util.AddCFGColor(Mod, title, convar, defaultr, defaultg, defaultb, defaulta)
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar .. "_r") then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar .. "_r", defaultr or 0, true, false)
	end
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar .. "_g") then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar .. "_g", defaultg or 0, true, false)
	end
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar .. "_b") then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar .. "_b", defaultb or 0, true, false)
	end
	if not ConVarExists("fls_" .. Mod.ConVar .. "_" .. convar .. "_a") then
		CreateClientConVar("fls_" .. Mod.ConVar .. "_" .. convar .. "_a", defaulta or 255, true, false)
	end
	table.insert(FLS.Data.CFGColors, {mod = Mod, title = title or "Unknown", convar = "fls_" .. Mod.ConVar .. "_" .. convar})
end

include("includes/FLSModule.lua")
include("fls_menu.lua")

CreateClientConVar("fls_debugmode", "0", true, false)

// Debug function
function FLS.Util.Debug(text)
	if GetConVar("fls_debugmode"):GetBool() then
		print("[FLS Debug] > " .. text)
	end
end

// Register an utility
function FLS.RegisterUtility(title, func, cmd)
	if cmd != "" and cmd != nil then
		concommand.Add("fls_" .. cmd, func)
	end
	table.insert(FLS.Utilities, {func = func, title = title})
end

// Get ConVar as boolean for modules
function FLS.Util.ModConVarEnabled(mod, convar)
	if not ConVarExists("fls_" .. mod.ConVar .. "_" .. convar) then
		return true
	else
		return GetConVar("fls_" .. mod.ConVar .. "_" .. convar):GetBool()
	end
end

// Get Module Slider ConVar
function FLS.Util.GetModValue(mod, convar)
	if not ConVarExists("fls_" .. mod.ConVar .. "_" .. convar) then
		return 0
	else
		return GetConVar("fls_" .. mod.ConVar .. "_" .. convar):GetInt()
	end
end

// Get Module Color ConVar
function FLS.Util.GetModColor(mod, convar)
	local r = 255
	local g = 255
	local b = 255
	local a = 255

	if ConVarExists("fls_" .. mod.ConVar .. "_" .. convar .. "_r") then
		r = GetConVar("fls_" .. mod.ConVar .. "_" .. convar .. "_r"):GetInt()
	end
	if ConVarExists("fls_" .. mod.ConVar .. "_" .. convar .. "_g") then
		g = GetConVar("fls_" .. mod.ConVar .. "_" .. convar .. "_g"):GetInt()
	end
	if ConVarExists("fls_" .. mod.ConVar .. "_" .. convar .. "_b") then
		b = GetConVar("fls_" .. mod.ConVar .. "_" .. convar .. "_b"):GetInt()
	end
	if ConVarExists("fls_" .. mod.ConVar .. "_" .. convar .. "_a") then
		a = GetConVar("fls_" .. mod.ConVar .. "_" .. convar .. "_a"):GetInt()
	end

	return Color(r, g, b, a)
end

// Function for adding a custom module
function FLS.Util.AddModule(mod)
	FLS.Util.Debug("Module added! \"" .. mod.Title .. "\"!")
	table.insert(FLS.Modules, mod)
end

// Internal Think function
function FLS.Internal.Think()
	for k, v in pairs(FLS.Modules) do
		if v and v != nil then
			if FLS.Util.IsConVarEnabled(v) then
				if v.IsEnabled["Think"] then
					v.Think()
				end
			end
		end
	end
end

// Internal Draw function
function FLS.Internal.Draw()
	for k, v in pairs(FLS.Modules) do
		if v and v != nil then
			if FLS.Util.IsConVarEnabled(v) then
				if v.IsEnabled["Draw"] then
					v.Draw()
				end
			end
		end
	end
end

// For Console Command toggling of modules
function FLS.Util.SetConVarToggle(mod, convar, default)
	CreateClientConVar("fls_" .. convar .. "_enabled", default or "1", true, false)
	mod.ConVar = convar
end

// Get if the module has a ConVar toggle and then check if it is enabled. Returns true if object has no ConVar toggling it.
function FLS.Util.IsConVarEnabled(mod)
	if mod.ConVar == "" then
		return true
	else
		return GetConVar("fls_" .. mod.ConVar .. "_enabled"):GetBool()
	end
end

// Included modules
include("modules/mod_esp.lua")
include("modules/mod_xray.lua")
include("modules/mod_bhop.lua")
include("modules/mod_rotate.lua")
include("modules/mod_view.lua")
include("modules/mod_antiadmin.lua")
include("modules/mod_weaponwarning.lua")

// Utilities
include("modules/util_notepad.lua")
include("modules/util_dupeupload.lua")
include("modules/util_specplayer.lua")

hook.Add("Think", "FLS.Internal.Think", FLS.Internal.Think)
hook.Add("HUDPaint", "FLS.Internal.Draw", FLS.Internal.Draw)