local function JoinSpam()
	RunConsoleCommand("retry")
end

concommand.Add("+fls_joinspam", function()
	hook.Add("Think", "JoinSpamming", JoinSpam)
end)

concommand.Add("-fls_joinspam", function()
	hook.Remove("Think", "JoinSpamming")
end)