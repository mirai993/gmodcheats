local t = {}
local m = {}
	t.__index = m

function FLSModule(title)
	local object = {}
		object.Title = title or "Unknown"
		object.ConVar = ""
		object.Think = function() end
		object.Draw = function() end
		object.IsEnabled = {Think = false, Draw = false}
		object.HasConfig = false
	setmetatable(object, t)
	FLS.Util.AddModule(object)
	return object
end