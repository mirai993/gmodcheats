/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/anti-cheat.lua (442 bytes)
*/
/*
=======================================
Name: Anti-Cheat bypasses
Purpose: don't get fucked 
======================================
*/


// Daz anti-cheat (thanks kirby)
Msg( ":: hake - bypassing Daz's Anti-Cheat, expect lag!\n" )
for i = 100, 100000 do 
	hook.Remove( "Think", tostring( i ) )
end

// GmodZ anti-cheat (thanks again kirby)
Msg( ":: hake - bypassing GModZ's anti-cheat\n" )
timer.Destroy( "AntiCheatTimer" )
