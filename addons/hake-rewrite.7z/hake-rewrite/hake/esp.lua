/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/esp.lua (4586 bytes)
*/
/*
==========================
hake: ESP 
Purpose: Wallhack/visuals
==========================
*/

hack:CreateConVar( "esp_info", 1 )
hack:CreateConVar( "esp_chams", 1 )
hack:CreateConVar( "esp_box", 1 )
hack:CreateConVar( "esp_ttt", 1 )
hack:CreateConVar( "esp_crosshair", 1 )
hack:CreateConVar( "esp_outline", 1 )
hack:CreateConVar( "esp_fov", 1 )

function hack:ESPColor( e )
local ESPColor = Color( 255, 255, 255, 255 )
	if hack:ShouldAim() && e == hack.Target then
		ESPColor = hack.Colors["Cyan"]
	elseif hack:IsAdmin( e ) then
		ESPColor = hack.Colors["FaggotRed"]
	elseif hack:IsFriend( e ) then
		ESPColor = hack.Colors["FaggotGreen"]
	elseif ( hack:IsTTT() && hack:IsTraitor( e ) ) then
		ESPColor = hack.Colors["Red"]
	elseif ( hack:IsTTT() && e:IsDetective() ) then 
		ESPColor = hack.Colors["Blue"]
	elseif ( hack:IsTTT() && !e:IsDetective() && !hack:IsTraitor( e ) ) then
		ESPColor = hack.Colors["Green"]
	elseif ( hack:IsDarkRP() && !hack:IsAdmin( e ) ) then
		ESPColor = team.GetColor( e:Team() )
	else
		ESPColor = hack.Colors["White"]
	end
	return ESPColor
end

function hack:ChamColor( e )
local ChamsColor = hack.Colors["White"]
	if ( hack:IsTTT() && hack:IsTraitor( e ) ) then
		ChamsColor = hack.Colors["Red"]
	else
		ChamsColor = team.GetColor( e:Team() )
	end
	return ChamsColor
end
		

function hack.ESP()
	for k, e in pairs( player.GetAll() ) do
		if e != LocalPlayer() and IsValid( e ) and e:Team() != TEAM_SPECTATOR then
			local Bottom = ( e:GetPos() + Vector( 0, 0, 1 ) ):ToScreen()
			local Top = ( e:GetPos() + Vector( 0, 0, 69 ) ):ToScreen()
			local Height = ( Bottom.y - Top.y )
			local Width = ( Height / 2 )
			
			if hack:GetVar( "esp_info" ) == 1 then
				if e:Alive() then
					if hack:IsPERP() then
						draw.SimpleTextOutlined( e:GetRPName(), "ESPFont", Top.x, Top.y - 16, hack:ESPColor( e ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, hack.Colors["Black"] )
					else
						draw.SimpleTextOutlined( e:Nick(), "ESPFont", Top.x, Top.y - 16, hack:ESPColor( e ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0 ) )
					end
					draw.SimpleTextOutlined( e:Health(), "ESPFont", Top.x, Top.y - 8, Color( 255, e:Health() * 2.55, e:Health() * 2.55, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, hack.Colors["Black"] )
				end
			end
			
			if hack:GetVar( "esp_box" ) == 1 then
				if e:Alive() then
					surface.SetDrawColor( hack:ESPColor( e ) )
					surface.DrawOutlinedRect( Top.x - Width, Top.y, Width * 2, Height )
					surface.SetDrawColor( hack.Colors["Black"] )
					if hack:GetVar( "esp_outline" ) == 1 then
						surface.DrawOutlinedRect( Top.x - Width - 1, Top.y - 1, Width * 2 + 2, Height + 2 )
						surface.DrawOutlinedRect( Top.x - Width + 1, Top.y + 1, Width * 2 - 2, Height - 2 )
					end
				end
			end
			
			if ( hack:IsTTT() && hack:GetVar( "esp_ttt" ) == 1 && hack:IsTraitor( e ) && e:Alive() ) then
				draw.SimpleTextOutlined( "Traitor", "DefaultSmall", Top.x, Top.y - 32, hack.Colors["Red"], TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, hack.Colors["Black"] )		
			end
			
			// asb's crosshair
			if hack:GetVar( "esp_crosshair" ) == 1 then
				local w, h = ScrW() / 2, ScrH() / 2
				surface.SetDrawColor( hack.Colors["Black"] )
				surface.DrawRect( w - 1, h - 3, 3, 7 )
				surface.DrawRect( w - 3, h - 1, 7, 3 )
				surface.SetDrawColor( team.GetColor( LocalPlayer():Team() ) )
				surface.DrawLine( w, h - 2, w, h + 2.75 )
				surface.DrawLine( w - 2, h, w + 2.75, h )
			end		
			
			if hack:GetVar( "esp_fov" ) == 1 then
				surface.DrawCircle( ScrW() / 2, ScrH() / 2, hack:GetVar( "aim_fov" ) * 10, Color( 255, 255, 255, 255 ) )
			end
			
		end
	end
end

function hack.Chams()
local material = hack.Material()
	for k, e in pairs( player.GetAll() ) do
		if ( IsValid( e ) && e != LocalPlayer() && e:Team() != TEAM_SPECTATOR && e:Alive() ) then
			local col = hack:ChamColor( e )
			if hack:GetVar( "esp_chams" ) == 1 then
				cam.Start3D( EyePos(), EyeAngles() )
				render.SuppressEngineLighting( true )
				render.SetColorModulation(col.r * 1 / 255, col.g * 1 / 255, col.b * 1 / 255)
				render.SetBlend( 0.65 )
				render.MaterialOverride( material )
				e:DrawModel()		
				render.SuppressEngineLighting( false )
				render.SetColorModulation(1,1,1)
				render.SetBlend( 1 )
				render.MaterialOverride()
				e:DrawModel()
				cam.End3D()
			end
		end
	end
end
			
			

--[ Hooks ]--
hack:AddHook( "RenderScreenspaceEffects", hack.Chams )
hack:AddHook( "HUDPaint", hack.ESP )

