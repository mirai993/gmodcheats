/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/speedhack.lua (590 bytes)
*/
/*
======================
Name: speedhack.lua
Purpose: fuck you
======================
*/

hack:CreateConVar( "misc_speed", 3 )

hack:AddCommand( "+speedhake", function()
	if hack.HasTarget == false then
		hack:SetValue( "sp00f_bs_sv_cheats", 1 )
		hack:SetValue( "sp00f_bs_host_timescale", hack:GetVar( "misc_speed" ) )
	else
		hack:SetValue( "sp00f_bs_sv_cheats", 0 )
		hack:SetValue( "sp00f_bs_host_timescale", 1 )
	end
end )

hack:AddCommand( "-speedhake", function()
	hack:SetValue( "sp00f_bs_sv_cheats", 0 )
	hack:SetValue( "sp00f_bs_host_timescale", 1 )
end )

