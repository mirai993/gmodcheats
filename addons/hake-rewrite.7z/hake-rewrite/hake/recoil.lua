/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/recoil.lua (240 bytes)
*/
/*
=====================
Name: recoil.lua
Purpose: recoil shit
=====================
*/

--[ ConVars ]--
hack:CreateConVar( "aim_recoil", 1 )

function hack.Recoil()
end

--[ Hooks ]--
hack:AddHook( "Think", hack.Recoil )
			
