/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/lefunnyjoke.lua (513 bytes)
*/
// LE SO FUNNY JOKE LE XDDDDDDDDDDDDDDDDDDDDDDDDDD

hack:AddCommand( "misc_forceadmin", function()

MsgC( hack.Colors["Random"], "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n~Attempting to force admin rights...\n" )

chat.AddText(
	hack.Colors["Black"], "(Console) ",
	hack.Colors["FaggotGreen"], "Added ",
	hack.Colors["Purple"], "you ",
	hack.Colors["FaggotGreen"], "to group ",
	hack.Colors["Purple"], "superadmin"
)

MsgC( hack.Colors["Random"], "~Admin rights forced\n" )
end )
