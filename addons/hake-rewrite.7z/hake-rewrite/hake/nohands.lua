/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/nohands.lua (539 bytes)
*/
/*
==============================
Name: nohands
Purpose: no fucking purpose
Credits: gmcl_hera is
mine, go fuck yourself
=============================
*/

--[ ConVars ]--
hack:CreateConVar( "misc_nohands", 0 )

//require( "hera" )

function hack.NoHands()
	if hack:GetVar( "misc_nohands" ) == 1 then
		hera.NoDraw( Material( "models/weapons/v_models/hands/v_hands" ), true )
	else
		hera.NoDraw( Material( "models/weapons/v_models/hands/v_hands" ), false )
	end
end

--[ Hooks ]--
hack:AddHook( "Think", hack.NoHands )
