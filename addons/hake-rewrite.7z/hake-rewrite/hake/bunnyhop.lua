/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/bunnyhop.lua (416 bytes)
*/
/*
=========================
Name: bunnyhop.lua
Purpose: bunnyhop...
========================
*/

--[ ConVars ]--
hack:CreateConVar( "misc_bunnyhop", 1 )

function hack.Bunnyhop( cmd, u )
	if hack:GetVar( "misc_bunnyhop" ) == 1 then
		if !LocalPlayer():IsOnGround() then
			cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		end
	end
end

--[ Hooks ]--
hack:AddHook( "CreateMove", hack.Bunnyhop )

