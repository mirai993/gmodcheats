/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/detours.lua (4131 bytes)
*/
/*
================================
Name: detours.lua
Purpose: detours and loggers
===============================
*/

usermessage.IncomingMessage = hack:Detour( usermessage.IncomingMessage, function( name, um, ... )
	if name == "ttt_role" then
		hack.Traitors = {}
	end
	return hack.Detours[ usermessage.IncomingMessage ]( name, um, ... )
end )

render.ReadPixel = hack:Detour( render.ReadPixel, function( x, y )
	return math.random( 1, 255 ), math.random( 1, 255 ), math.random( 1, 255 )
end )

file.Read = hack:Detour( file.Read, function( filename, dir )
	for k, file in pairs( hack.Files ) do
		if string.find( filename, file ) then	
			hack.AntiCheatNotify( "~ attempted to read " .. filename .. "" )
			return "go fuck yourself"
		else
			return hack.Detours[ file.Read ]( filename, dir )
		end
	end
end )

file.Find = hack:Detour( file.Find, function( filename, dir )
	for k, file in pairs( hack.Files ) do
		if string.find( filename, file ) then
			hack.AntiCheatNotify( "~ attempted to find " .. filename .. ", returning false" )
			return false
		else
			return hack.Detours[ file.Find ]( filename, dir )
		end
	end
end )

file.ExistsEx = hack:Detour( file.ExistsEx, function( filename, addons )	
	for k, file in pairs( hack.Files ) do
		if string.find( filename, file ) then
			hack.AntiCheatNotify( "~ attempted to find " .. filename .. ", returning false" )
			return false
		end
	end
	
	return hack.Detours[ file.ExistsEx ]( filename, addons )
end )

file.FindInLua = hack:Detour( file.FindInLua, function( filename )
	for k, file in pairs( hack.Files ) do
		if string.find( filename, file ) then
			hack.AntiCheatNotify( "~ attempted to find " .. filename .. ", returning false" )
			return false
		else
			return hack.Detours[ file.FindInLua ]( filename )
		end
	end
end )

file.IsDir = hack:Detour( file.IsDir, function( dir, path )
	for k, file in pairs( hack.Files ) do
		if string.find( dir, file ) then
			hack.AntiCheatNotify( "~ attempted to find directory " .. dir .. ", returning false" )
			return false
		else
			return hack.Detours[ file.IsDir ]( dir, path )
		end
	end
end )

file.Exists = hack:Detour( file.Exists, function( filename, dir )
	for k, file in pairs( hack.Files ) do
		if string.find( filename, file ) then
			hack.AntiCheatNotify( "~ attempted to find file " .. filename .. ", returning false" )
			return false
		else
			return hack.Detours[ file.Exists ]( filename, dir )
		end
	end
end )

GetConVarNumber = hack:Detour( GetConVarNumber, function( cvar )
	for k, v in pairs( hack.SpoofedVars ) do
		if cvar == k then
			hack.AntiCheatNotify( "~ attempted to get the value of " .. cvar .. " spoofing with value " .. v )
			return v
		else
			return hack.Detours[ GetConVarNumber ]( cvar )
		end
	end
end )

ConVarExists = hack:Detour( ConVarExists, function( cvar )
	for k, v in pairs( hack.ConVars ) do
		if cvar == v then
			hack.AntiCheatNotify( "~ ConVarExists: " .. cvar .. " returning false" )
			return false
		else
			return hack.Detours[ ConVarExists ]( cvar )
		end
	end
end )

GetConVarString = hack:Detour( GetConVarString, function( cvar )
	for k, v in pairs( hack.ConVars ) do
		if cvar == k then
			hack.AntiCheatNotify( "~ GetConVarString: " .. cvar .. " returning bullshit string" )
			return ""
		else
			return hack.Detours[ GetConVarString ]( cvar )
		end
	end
end )

hack.R.ConVar.GetInt = hack:Detour( hack.R.ConVar.GetInt, function( cvar )
	for k, v in pairs( hack.SpoofedVars ) do
		if cvar:GetName() == k then
			hack.AntiCheatNotify( "~ _R.ConVar.GetInt: " .. cvar .. " spoofing with value " .. v )
			return v
		else
			return hack.Detours[ hack.R.ConVar.GetInt ]( cvar )
		end
	end
end )

hack.R.ConVar.GetBool = hack:Detour( hack.R.ConVar.GetBool, function( cvar )
	for k, v in pairs( hack.SpoofedVars ) do
		if cvar:GetName() == k then
			hack.AntiCheatNotify( "~ _R.ConVar.GetBool: " .. cvar .. " spoofing with value " .. v )
			return v
		else
			return hack.Detours[ hack.R.ConVar.GetBool ]( cvar )
		end
	end
end )
