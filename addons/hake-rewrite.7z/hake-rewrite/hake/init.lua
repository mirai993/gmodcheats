/*
	cunt [STEAM_0:0:40143824 | 63.141.253.124:27005]
	hake/init.lua (7958 bytes)
*/
/*
======================================================
Name: init.lua

Purpose: Load other files, localize, and other fun stuff

Credits: 
	p0mf for gmcl_nyx
	fr1kin for esp box base
=======================================================
*/

if ( hack ) then _G.hack = nil end
hack 						= {}

/////// CHANGABLE SETTINGS HERE ///////
hack.DataFolder				= "hake"
hack.SpoofedVars			= {
	[ "sv_cheats" ] 		= 0,
	[ "sv_allowcslua" ]		= 0, 
	[ "r_drawothermodels" ] = 1,
	[ "mat_fullbrighht" ] 	= 0,
	[ "host_timescale" ]	= 1,
	[ "host_framerate" ]	= 1, 
}
hack.MaterialInfo = {
	[ "$basetexture" ]	 = "models/debug/debugwhite",
	[ "$model" ]      	 = 1,
	[ "$ignorez" ]		 = 1,
}	
///////////////////////////////////////

hack.Require				= _G.require
hack.Include				= _G.include
hack.Include( "!rewritefuncs.lua" )
hack.R						= _G.debug.getregistry()

hack.Hooks					= {}
hack.ConCommands			= {}
hack.ConVars				= {}
hack.Timers					= {}
hack.Stored					= {}

hack.ServerHooks			= {} -- Going to attempt a hook hijacker

hack.Detours				= {}

hack.Aimon					= 0
hack.Target					= nil
hack.AimPosition			= Vector( 0, 0, 0 )

hack.RecoilBackups			= {}
hack.Prediction				= {
	[ "weapon_crossbow" ] 	= 3485,
	[ "weapon_pistol" ] 	= 40000,
	[ "weapon_357" ] 		= 20500,
	[ "weapon_smg" ] 		= 39000,
	[ "weapon_ar2" ] 		= 39000,
	[ "weapon_shotgun" ] 	= 35000,
	[ "weapon_rpg" ] 		= 0,	
}

hack.Files					= {
	"hake/init.lua",
	"gmcl_nyx_win32.dll",
	"gmcl_cvar3_win32.dll",
	"gmcl_hera_win32.dll",
	"gmcl_extras_win32.dll",
}

hack.Modules				= { 
	"extras",
	"cvar3",
}

hack.TraitorWeapons			= {}
hack.Traitors				= {}

hack.Colors					= {
Black = Color( 0, 0, 0 ),
Blue = Color( 0, 0, 255 ),
Red = Color( 255, 0, 0 ),
White = Color( 255, 255, 255 ),
Grey = Color( 64, 64, 64 ),
Green = Color( 0, 255, 0 ),
Cyan = Color( 0, 255, 255 ),
SexyRed = Color( 255, 50, 63 ),
FaggotGreen = Color( 100, 255, 100 ),
FaggotRed = Color( 100, 255, 100 ),
Purple = Color( 129, 0, 255 ),
Teal = Color( 0, 102, 102 ),
Pink = Color( 255, 0, 127 ),
DarkBlue = Color( 0, 0, 207 ),
SexyBlue = Color( 51, 51, 255 ),
LightGreen = Color( 102, 255, 102 ),
Brown = Color( 51, 25, 0 ),
Random	= Color( math.random( 1, 255 ), math.random( 1, 255 ), math.random( 1, 255 ) ), // sets a random color when loaded
}

--[ FONTS ]--
surface.CreateFont( "ESPFont", { font = "Lucida Console", size = 12, weight = 400, antialias = 0 } )

function hack:RandomString()
	local An = math.random( 10, 20 )
	local String = ""       
	for i = 1, An do
		String = String .. string.char( math.random( 97, 122 ) )
	end		 
	return String
end

--[ MATERIALS ]--
function hack.Material()
	return CreateMaterial( hack:RandomString() , "VertexLitGeneric", hack.MaterialInfo )
end

/*
=============================
Init, load files, modules,
create files, and setup hooks
=============================
*/

function hack:LoadFiles()
	for k, v in pairs( file.Find( "lua/hake/*.lua", "GAME" ) ) do
		if v != "init.lua" then
			hack.Include( v )
			MsgC( Color( 255, 50, 50 ), ":: hake - Loaded " .. v ..  "\n" )
			table.insert( hack.Files, v )
		end
	end
end

function hack:CreateFiles()
	if !file.IsDir( hack.DataFolder, "DATA" ) then
		file.CreateDir( hack.DataFolder )
		Msg( ":: hake - Created /data/" .. hack.DataFolder .. "/\n" )
	end
	if !file.Exists( hack.DataFolder .. "/anti-cheat.txt", "DATA" ) then
		file.Write( hack.DataFolder .. "/anti-cheat.txt", ":: anti cheat log\n" )
	end
end

function hack:LoadModules()
	for k, v in pairs( hack.Modules ) do
		hack.Require( v )
		Msg( ":: hake - Loaded module " .. v .. "\n" )
		table.insert( hack.Files, v )
	end
end

--------------------------------------------------------

function hack:AddHook( Type, Function )
	Name = hack:RandomString()
	Msg( ":: hake - Added hook [ Type " .. Type .. " | Name " .. Name .. " ]\n" )
	table.insert( hack.Hooks, Name )
	hook.Add( Type, Name, Function )
end

function hack:AddCommand( Name, Function )
	Msg( ":: hake - Added command " .. Name .. "\n" )
	table.insert( hack.ConCommands, Name )
	concommand.Add( Name, Function )
end

function hack:AddTimer( sec, rep, func )
	local index = hack:RandomString()
	hack.Timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

function hack:CreateConVar( Name, Str )
	Msg( ":: hake - Added convar " .. Name .. "\n" )
	table.insert( hack.ConVars, Name )
	CreateClientConVar( Name, Str, true, false )
end

function hack:GetVar( ConVar )
	return GetConVarNumber( ConVar )
end

-------------------------------------------------------------


--[ useful checks ]--
function hack:IsAdmin( e )
	if e:IsAdmin() 
	or e:IsSuperAdmin() 
	or e:IsUserGroup( "Owner" )
	or e:IsUserGroup( "owner" )
	or e:IsUserGroup( "Superadmin" )
	or e:IsUserGroup( "superadmin" )
	or e:IsUserGroup( "Admin" )
	or e:IsUserGroup( "admin" )
	or e:IsUserGroup( "Moderator" )
	or e:IsUserGroup( "moderator" )
	or e:IsUserGroup( "Moderator" )
	or e:IsUserGroup( "moderator" ) then return true end
	return false
end

function hack:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function hack:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function hack:IsPERP()
	if string.find( string.lower( GAMEMODE.Name ), "perp" ) then return true end
	return false
end

function hack:IsStronghold()
	if string.find( string.lower( GAMEMODE.Name ), "stronghold" ) then return true end
	return false
end

function hack:IsDarkRP()
	if string.find( string.lower( GAMEMODE.Name ), "darkrp" ) then return true end
	return false
end

function hack:IsTraitor( e )
	local ply = LocalPlayer()
	if not hack:IsTTT() then return end
	if e:IsDetective() then return false end
	if table.HasValue( hack.Traitors, e ) then return true end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function hack.GetTraitors()
if !hack:IsTTT() then return end
	for _, e in pairs( ents.GetAll() ) do
		if( e.CanBuy && table.HasValue( e.CanBuy, ROLE_TRAITOR ) && !table.HasValue( hack.TraitorWeapons, e ) ) then
			if( e:GetMoveType() == MOVETYPE_NONE ) then
				table.insert( hack.TraitorWeapons, e )
				local v = e.Owner
				if( v:Alive() && !v:IsDetective() ) then
					if( !table.HasValue( hack.Traitors, v ) ) then
						table.insert( hack.Traitors, v )
					end
				end
			elseif( e:GetMoveType() != MOVETYPE_NONE ) then
				table.insert( hack.TraitorWeapons, e )
			end
		end
	end
end

--[ MODULE FUNCTIONS ]--

// gmcl_cvar3
function hack:SetValue( ConVar, Value )
	GetConVar( ConVar ):SetValue( Value )
end

// gmcl_extras
function hack:SetVar( ConVar, Value )
	console.Command( ConVar .. " " .. Value )
end

function hack:GetHostIP()
	return client.GetIP()
end

--[ DETOURS ]--
function hack:Detour( Old, New )
	hack.Detours[New] = Old
	return New
end

--[ unload ]--
hack:AddCommand( "hake_unload", function()
	for k,v in pairs( hack.ConVars ) do
		hack:SetVar( v, 0 )
	end
	for k, v in pairs( hack.ConCommands ) do
		Msg( ":: hake - Removing concommand " .. v .. "\n" )
		concommand.Remove( v )
	end
	for k, v in pairs( hack.Timers ) do
		Msg( ":: hake - Removing timer " .. v .. "\n" )
		timer.Remove( v )
	end
	for k, v in pairs( hack.Hooks ) do
		Msg( ":: hake - Removing hook " .. v .. "\n" )
		hook.Remove( v )
	end
MsgC( Color( 255, 0, 0 ), ":: hake - Unloaded\n" )
end )

function hack.AntiCheatNotify( msg ) 
	MsgC( Color( 255, 0, 0 ), msg .. "\n" )
	chat.PlaySound()
	file.Append( hack.DataFolder .. "/anti-cheat.txt", "[" .. os.date( "%m-%d-%y" ) .. " - " .. client.GetIP() .. " ]: " .. msg .. "\n" )
end
	
hack:CreateFiles()
hack:LoadFiles()
//hack:LoadModules()

hack:AddHook( "Think", hack.GetTraitors )
