--Just a simple fix to make the cheat run without modules.
--Enjoy even less protection.

_nyx = {}
console = {}
hera = {}

function _nyx.Init()
	print( "Shitty cheat loaded!\n" )
	return
end

function _nyx.RemoveSpread( cmd, angle, vector )
	return angle:Forward()
end

local cvarmeta = FindMetaTable( "ConVar" )

function cvarmeta:SetValue( n )
	return
end

function cvarmeta:SetFlags( n )
	return
end

function console.Command( ... )
	return
end

function hera.NoDraw( mat, bool )
	return
end