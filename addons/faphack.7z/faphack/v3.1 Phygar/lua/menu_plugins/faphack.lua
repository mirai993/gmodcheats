local FAPHACK_EDITED = false -- Set to true if you are editing FapHack. This will prevent your file from being overwritten.
local version = 31

if not FAPHACK_EDITED then
	local f = file.Exists("faphack_bot.txt") and file.Read("faphack_bot.txt") or ""
	local revision = tonumber(f:match("FapHack.Revision = (.-)\n")) or 0
	local retries = 0
	
	local function checkUpdate()
		if retries > 4 then return end
		http.Get("http://flapadar.co.uk/FapHackV31/check.txt" , ""  , function(c,s)
			if s == 0 or not string.find(c:lower(),"revision") then
				MsgN("[FapHack] Update check failed.. retrying.")
				checkUpdate()
			else
				local uprevision = tonumber(c:match("revision=(.-)\n")) or 1
				local upversion = tonumber(c:match("version=(.-)\n")) or 1
				local upcrc = c:match("crc=(.-)\n")
				local upurl = c:match("url=(.-)\n")
				local changelog = c:match("changelog=(.+)")
				
				if upversion > version then
					local function ShowUpdate(rev , url, clog)
						print(string.format("FapHack: Version %d is available at %s" , rev , url))
						
						local dframe = vgui.Create("DFrame")
						dframe:SetSize(300 , 202)
						dframe:SetTitle("FapHack: Update available")
						dframe:MakePopup()
						dframe:Center()
						
						local dlabel = vgui.Create("DLabel")
						dlabel:SetParent(dframe)
						dlabel:SetText(string.format("FapHack Version %d is available from the URL below!\nUpdating gives you more features and a more stable \nexperience. The old version will cease to work." , rev , url))
						dlabel:SizeToContents()
						dlabel:SetPos(5 , 25)
						
						local dtextentry = vgui.Create("DTextEntry")
						dtextentry:SetParent(dframe)
						dtextentry:SetPos(0 , 75)
						dtextentry:SetSize(300 , 25)
						dtextentry:SetText(url)
						dtextentry.OnMousePressed = function()
							SetClipboardText(url)
							MsgN("[FapHack] The URL is now in your clipboard.")
						end
						
						local dtextentry = vgui.Create("DTextEntry")
						dtextentry:SetParent(dframe)
						dtextentry:SetPos(0 , 102)
						dtextentry:SetSize(300 , 98)
						dtextentry:SetMultiline(true)
						dtextentry:SetText("Changelog:" .. clog)
						dtextentry:SetEditable(false)
					end
					
					ShowUpdate(upversion,upurl,changelog)
					
					if file.Exists("faphack_bot.txt") then
						file.Delete("faphack_bot.txt")
					end
					return;
				elseif uprevision > revision then
					http.Get("http://flapadar.co.uk/FapHackV31/bot.txt" , "" , function(c,s)
						file.Write("faphack_bot.txt" , c)
						MsgN("[FapHack] Updated to revision ".. uprevision)
					end )
				else
					MsgN("[FapHack] FapHack is up to date.")
				end
			end
			retries = retries + 1
		end )
	end
	checkUpdate()
	
	concommand.Add("_fap_reload_menu" , function() include("menu_plugins/faphack.lua") end )
end

if not ConVarExists("fap_shouldload") then CreateConVar("fap_shouldload" , 1) end
