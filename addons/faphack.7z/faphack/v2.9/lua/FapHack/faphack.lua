--[[
	FapHack [2.9].lua
	seth lawyers | (STEAM_0:0:48926883)
	===DStream===
]]

--[FapHack [2.9] [[Private]]--
if hook or concommand then
	MsgN("[FapHack] Warning:  This server has an anticheat.  ( Or FapHack was reloaded )")
	timer.Simple(0.5 , function() chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , "FapHack has detected an anticheat is present on this server. Be careful.") end )
	--[[package.loaded.hook = nil
	hook = nil
	package.loaded.concommand = nil
	concommand = nil
	package.loaded.filex = nil
	filex = nil
	package.loaded.timer = nil
	timer = nil
	package.loaded.usermessage = nil
	usermessage = nil
	MsgN("[FapHack] Reloading standard modules.")]]
end

include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )

include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )	
include( "includes/util/client.lua" )
include("includes/extensions/table.lua")
-- Let's get locals of some cool functions --

local math = math
local string = string
local debug = debug
local table = table
local pcall = pcall
local error = error
local ErrorNoHalt = ErrorNoHalt
local MsgN = MsgN
local Msg = Msg
local print = print
local surface = surface
local util = util
local type = type
local RunConsoleCommand = RunConsoleCommand
local CreateClientConVar = CreateClientConVar
local CreateConVar = CreateConVar
local pairs = pairs
local ipairs = ipairs
local SortedPairs = SortedPairs


function util.tobool(int)
	return math.floor(int) == 1
end

local function tableSetKeys(table)
	local ret = {}
	local counter = 0
	
	for k , v in pairs(table) do
		counter = counter + 1
		ret[counter] = v
	end
	return ret
end


local function RandomString(length)
	local str = ""
	
	for i = 1 , length do
		str = str..string.char(math.random(65 , 117))
	end
	
	return str
end

local FapHack = {}
FapHack.Revision = 9

-- Create the cool fonts we'll use. --

 surface.CreateFont("coolvetica" , 20 , 500 , true , true , "FapHack_Font") 
 surface.CreateFont("coolvetica" , 15 , 500 , true , true , "FapHack_Font_Small") 
 
-- Now we want to do some hooking. --

FapHack.Functions = {}
FapHack.Hooks = {}

function FapHack:AddFunction(type)
	if not FapHack.Functions[type] then
		FapHack.Functions[type] = {}
	end
	local randomstring = RandomString(20)
	
	FapHack[type] = function(a , b , c , d , ...)
		for k , v in pairs(FapHack.Functions[type]) do	
			local noerr , ret = pcall(v , a , b , c , d , ...)
			
			if ret ~= nil and noerr then
				return ret
			elseif not noerr then
				ErrorNoHalt(ret.."\n")
			end
		end
	end
	
	hook.Add(type , randomstring , FapHack[type])
	
	FapHack.Hooks[type] = randomstring
	return true
end

function FapHack:RegisterFunc(func , typ)
	FapHack.Functions[typ] = FapHack.Functions[typ] or (self:AddFunction(typ) and {})
	table.insert(FapHack.Functions[typ] , func)
end

-- End of hooking --

-- Start of ConVars --

FapHack.Settings = {}
FapHack.ConVarSettings = {}
FapHack.ConVarSettings["Aim"] = {}
FapHack.ConVarSettings["ESP"] = {}
FapHack.ConVarSettings["Misc"] = {}

FapHack.ConVarNames = {}

function FapHack:CreateConVar(cvar , def , save,  userdata,  var , maxno , minno , isdec)
	local booltype = false
	if type(def) == "boolean" then
		def = def and 1 or 0
		booltype = true
	end
	
	local convar = CreateClientConVar(cvar , def , save , userdata)
	if booltype then
		FapHack.Settings[var] = util.tobool(convar:GetInt())
	elseif type(def) == "number" then
		if !isdec then
			FapHack.Settings[var] = convar:GetInt()
		else
			FapHack.Settings[var] = tonumber(convar:GetString())
		end
	elseif type(def) == "string" then
		FapHack.Settings[var] = convar:GetString()
	end

	if string.find(cvar , "aim") then
		if booltype then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean" , name = var}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "string" , name = var}
		elseif type(def) == "number" then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
		end
	elseif string.find(cvar , "esp") then
		if booltype then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "boolean" , name = var}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "string" , name = var }
		elseif type(def) == "number" then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
		end
	else
		if booltype then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "boolean" , name = var}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "string" , name = var}
		elseif type(def) == "number" then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
		end
	end
	
	table.insert(FapHack.ConVarNames , cvar)
	
	cvars.AddChangeCallback(cvar , function(cvar , old , new)
		if booltype then
			FapHack.Settings[var] = util.tobool(math.floor(new))
			--print("FapHack: Setting "..var.." to " , util.tobool(new))
			
		else
			FapHack.Settings[var] = new
			--print("FapHack: Setting "..var.." to "..new)
		end
	end )
	
	return convar
end

FapHack:CreateConVar("fap_aim_enabled" , false , true , false , "AimEnabled")
FapHack:CreateConVar("fap_aim_friendlyfire" , false , true , false , "FriendlyFire")
FapHack:CreateConVar("fap_aim_targetnpcs" , false , true , false , "TargetNPCs")
FapHack:CreateConVar("fap_aim_onlyenemynpcs" , false , true , false , "OnlyEnemyNPCs")
FapHack:CreateConVar("fap_aim_autofire" , true , true , false , "AutoFire")
FapHack:CreateConVar("fap_aim_autoreload" , true , true , false , "AutoReload")
FapHack:CreateConVar("fap_aim_bonemode" , 1 , true , false , "BoneMode" , 3 , 1)
FapHack:CreateConVar("fap_aim_targetfriends" , false , true , false, "TargetFriends")
FapHack:CreateConVar("fap_aim_targetsteamfriends" , true , true ,false , "TargetSteamFriends")
FapHack:CreateConVar("fap_aim_targetmode" , 1 , true , false , "TargetMode" , 4 , 1)
FapHack:CreateConVar("fap_aim_nospread" , true , true , false , "NoSpread")
FapHack:CreateConVar("fap_aim_maxdistance" , 2048 , true , false , "MaxDistance" , 16384 , 0)
FapHack:CreateConVar("fap_aim_targetadmins" , false , true ,false , "TargetAdmins")	
FapHack:CreateConVar("fap_aim_antisnap" ,  false , true , false , "AntiSnap")
FapHack:CreateConVar("fap_aim_norecoil" , true , true , false , "NoRecoil")
FapHack:CreateConVar("fap_aim_antisnapspeed" , 1 , true , false , "AntiSnapSpeed" , 10 , 0 , true)
FapHack:CreateConVar("fap_aim_maxangle" , 180 , true , false , "MaxAngleDiff" , 180 , 0 , true)
FapHack:CreateConVar("fap_aim_snaponfire" , false , true , false , "SnapOnFire")
FapHack:CreateConVar("fap_aim_snaponfiretime" , 0.6 , true , false , "SnapOnFireTime" , 10 , 0.1, true)
FapHack:CreateConVar("fap_aim_onlytargettraitors" , false , true , false , "OnlyTargetTraitors")
FapHack:CreateConVar("fap_aim_velocityprediction" , true , true , false , "VelocityPrediction")
FapHack:CreateConVar("fap_esp_enabled" , true , true , false , "ESPEnabled")
FapHack:CreateConVar("fap_esp_material" , "Solid" , true , false , "WallhackMaterial")
FapHack:CreateConVar("fap_esp_drawweapons" , true , true , false , "DrawWeapons")
FapHack:CreateConVar("fap_esp_maxdistance" , 8192 , true , false , "MaxESPDistance" , 16384 , 0)
FapHack:CreateConVar("fap_esp_zoomtocurrenttarget" , false , true , false , "ZoomToCurrentTarget")
FapHack:CreateConVar("fap_esp_zoomfactor" , 1 , true , false , "ZoomFactor" , 5 , 0.1 , true)
FapHack:CreateConVar("fap_esp_crosshair" , true , true , false , "DrawCrosshair")
FapHack:CreateConVar("fap_esp_textinfo" , true , true , false , "DrawTextInfo")
FapHack:CreateConVar("fap_esp_complex" , false , true , false , "UseComplexDrawing")
FapHack:CreateConVar("fap_esp_alwaysdrawinfo" , false , true , false , "AlwaysDrawInfo")
FapHack:CreateConVar("fap_esp_friendly" , false , true , false , "OnlyDrawOtherTeams")
FapHack:CreateConVar("fap_esp_traitormode" , true , true , false , "TraitorMode")
FapHack:CreateConVar("fap_esp_drawmodels" , true , true , false , "DrawModels")

--FapHack:CreateConVar("fap_esp_radar" , false , true , true , "RadarEnabled")


FapHack:CreateConVar("fap_checkforupdates" , true , true , false , "CheckForUpdates")
FapHack:CreateConVar("fap_shouldload" , true , true , false , "ShouldLoad")
FapHack:CreateConVar("fap_enablekeybinding" , false , true , false , "EnableKeyBinding")
FapHack:CreateConVar("fap_bunnyhop" , false , true , false , "BunnyHop")
FapHack:CreateConVar("fap_bunnyhopspeed" , 270 , true , false , "BunnyHopSpeed" , 700 , 0)
FapHack:CreateConVar("fap_dontchecklos" , false , true , false , "IgnoreLOS")

--FapHack:CreateConVar("fap_randomnamechange" , false , true , true , "RandomNameChange")

if not FapHack.Settings.ShouldLoad then
	MsgN("\n\n\n\n[FapHack] Not loading - disabled. Type fap_shouldload 1 in console to enable loading.\n\n\n")
	timer.Simple(0.5 , function() chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , "FapHack is disabled. Type \"fap_shouldload 1\" in the console to re-enable it.") end )
	return
end

FapHack.DetouredFuncs = {}

function FapHack:Detour(tbl , key , func)
	table.insert(self.DetouredFuncs , {tbl = tbl , key = key , func = func} )
	
	--[[local oldfunc = _G[tbl][key]
	
	_G[tbl][key] = function(...)
		local cpath = debug.getinfo(2).short_src
		local args = {...}
		local strarg = nil
		for k , v in pairs(args) do
			if type(v) == "function" then
				strarg = strarg and strarg .. " , function" or "function"
			elseif type(v) == "table" then
				strarg = strarg and strarg .. " , table" or "table"
			else
				strarg = strarg and strarg .. " , "..v or v
			end
		end
		strarg = strarg or "(nil)"
		MsgN(tbl.."."..key.."("..strarg .. " ) ")
		return oldfunc(...)
	end]]
end

--FapHack:CreateConVar("fap_esp_adminwarning" , true , true , true , "AdminWarning")

-- End of ConVars --

-- Start of misc settings --

FapHack.TargetModes = {

[1] = "AIM_DISTANCE",
[2] = "AIM_HEALTH",
[3] = "AIM_ANGLE",
[4] = "AIM_DANGER",

}

FapHack.BoneModes = {
[1] = "head",
[2] = "spine",
[3] = "shoulder",
}

-- Friends shit --

FapHack.Friends = (file.Exists("faphack_friends.txt") and KeyValuesToTable(file.Read("faphack_friends.txt")) or {} )

function FapHack:AddFriend(pl)
	if ValidEntity(pl) and pl != LocalPlayer() then
		table.insert(FapHack.Friends , pl:SteamID())
		file.Write("faphack_friends.txt" , TableToKeyValues(FapHack.Friends))
	end
end

function FapHack:RemoveFriend(pl)
	if ValidEntity(pl) then
		for k , v in pairs(FapHack.Friends) do
			if string.Trim(v) == pl:SteamID() then
				FapHack.Friends[k] = nil
			end
		end
		PrintTable(FapHack.Friends)
		file.Write("faphack_friends.txt" , TableToKeyValues(FapHack.Friends))
	end
end

function FapHack:AddFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			FapHack:AddFriend(v)
			break
		end
	end
end

function FapHack:RemoveFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		--print("d" , v:Nick() , nick)
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			FapHack:RemoveFriend(v)
			break
		end
	end
end

function FapHack:GetFriends()
	local friends = {}
	local notfriends = {}
	
	for k , v in ipairs(player.GetAll()) do
		if self:IsPlayerFriend(v) then
			table.insert(friends , v)
		elseif v != LocalPlayer() then
			table.insert(notfriends , v)
		end
	end
	
	return friends, notfriends
end


function FapHack:IsPlayerFriend(pl)
	local steamid = (pl.SteamID and pl:SteamID() or "")
	return table.HasValue(FapHack.Friends , steamid)
end


-- End of friends shit --

-- Start of ESP entities shit -- 

FapHack.ESPEntities = (file.Exists("faphack_entities.txt") and KeyValuesToTable(file.Read("faphack_entities.txt")) or {} )

function FapHack:AddESPEntity(class)
	if not table.HasValue(FapHack.ESPEntities , class) then
		table.insert(FapHack.ESPEntities , class)
		file.Write("faphack_entities.txt" , TableToKeyValues(FapHack.ESPEntities))
	end
end

function FapHack:RemoveESPEntity(class)
	for k , v in pairs(self.ESPEntities) do
		if class == v then
			FapHack.ESPEntities[k] = nil
		end
	end
	file.Write("faphack_entities.txt" , TableToKeyValues(FapHack.ESPEntities))
end

function FapHack:IsESPEntity(ent)
	return table.HasValue(FapHack.ESPEntities , ent:GetClass())
end

local espents = {t = 0 , t1 = {} , t2 = {}}
function FapHack:GetESPEntityClasses()
	if espents.t == CurTime() then
		return espents.t1 , espents.t2
	end
	
	local esp = {}
	local notesp = {}
	
	for k , v in ipairs(ents.GetAll()) do
		if ValidEntity(v) then
			if not table.HasValue(esp , v:GetClass()) and not table.HasValue(notesp , v:GetClass()) then
				if FapHack:IsESPEntity(v) then
					table.insert(esp , v:GetClass())
				else
					table.insert(notesp , v:GetClass())
				end
			end
		end
	end
	
	espents.t = CurTime()
	espents.t1 = esp
	espents.t2 = notesp
	return esp , notesp
end

-- Start of bone position finding stuff --

-- These are in order of preference.
local weapons = {
["weapon_crossbow"] = 3110,
["weapon_frag"] = 3110

}
function FapHack:GetWeaponPredictionPos(pos , pl)
	if ValidEntity(pl) and type(pl:GetVelocity()) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
		local weapon = (LocalPlayer().GetActiveWeapon and (ValidEntity(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()))
		
		if weapon and weapons[weapon] then
			local time = distance / weapons[weapon]
			return pos + pl:GetVelocity() * time
		end
		
		return pos
	end
	return pos
end


FapHack.Attachments = {

["head"] = "eyes",
["spine"] = "chest",
}

FapHack.Bones = {
["head"] = {


["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone" ,
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4" , 
["other"] = "ValveBiped.Bip01_Head1",
},

["spine"] = {

["other"] = "ValveBiped.Bip01_Spine",

} ,

["shoulder"] = {

["other"] = "ValveBiped.Bip01_R_Shoulder",

},
}

function FapHack:GetBonePos(ent , bonetype)
	if self.Attachments[bonetype] then
		local attach = ent:LookupAttachment(self.Attachments[bonetype])
		if attach then
			local p = ent:GetAttachment(attach)
			if p then
				if p.Pos then
					return FapHack:GetWeaponPredictionPos(p.Pos , ent) , p.Ang
				end
			end
		end
	end
		
	--[[if bonetype == "head" then
		-- The target has a head - possibly it has eyes. This'll be more accurate.
		local attach = ent:LookupAttachment("eyes")
		local postbl = ent:GetAttachment(attach)
		if postbl.Pos then
			print(string.format("targetting eyes %d , %d , %d" , postbl.Pos.x , postbl.Pos.y , postbl.Pos.z))
			return postbl.Pos , postbl.Ang
		end
	end]]
		
	if self.Bones[bonetype] then
		local boneid = ent:LookupBone(self.Bones[bonetype][ent:GetModel()] or self.Bones[bonetype]["other"])
		local pos , ang = ent:GetBonePosition(boneid)
		
		return FapHack:GetWeaponPredictionPos(pos , ent) , ang
	else
		for k , v in pairs(self.Bones) do	
			local boneid = ent:LookupBone(v[ent:GetModel()] or v["other"])
			if boneid then
				local pos , ang = ent:GetBonePosition(boneid)
				--pos = pos - (1/ent:GetVelocity())
				--pos = pos - (20/ent:GetVelocity())
				return FapHack:GetWeaponPredictionPos(pos , ent), ang
			end
		end
	end
end

-- Start of target selection --

local trace , tr = {} , {}

local traced = {}

function FapHack:EntityTrace(ent)
	if not ValidEntity(ent) or not ValidEntity(LocalPlayer()) then
		return false
	end
	
	if FapHack.Settings.IgnoreLOS then
		return true
	end
	
	if traced[ent:EntIndex()] and traced[ent:EntIndex()].t == CurTime() then
		return traced[ent:EntIndex()].b
	end
	
	trace = {}
	trace.start = LocalPlayer():EyePos()
	trace.endpos = ent:EyePos() -- What if they don't have eyes? Herp derp.
	trace.mask = 1174421507
	trace.filter = {LocalPlayer(), ent}
	
	tr = util.TraceLine(trace)
	if not tr.Hit then
		traced[ent:EntIndex()] = {}
		traced[ent:EntIndex()].t = CurTime()
		traced[ent:EntIndex()].b = true
		return true
	end
	traced[ent:EntIndex()] = {}
	traced[ent:EntIndex()].t = CurTime()
	traced[ent:EntIndex()].b = false
	return false
end

local validtargets = {t = 0 , tbl = {}}
function FapHack:GetAllValidTargets()
	if validtargets.t == CurTime() then
		return validtargets.tbl
	end
	
	local targets = {}
	for k , v in ipairs(ents.GetAll()) do
		if not (v == LocalPlayer()) then
			if ValidEntity(v) then
				if not (!self.Settings.TargetSteamFriends and (v.GetFriendStatus and v:GetFriendStatus() == "friend")) and (self.Settings.TargetFriends or !self:IsPlayerFriend(v)) and not((tonumber(FapHack.Settings.MaxDistance) > 0) and (LocalPlayer():GetPos():Distance(v:GetPos()) > tonumber(FapHack.Settings.MaxDistance))) and not (!(FapHack.Settings.TargetAdmins) and (v:IsPlayer() and v:IsAdmin())) then
					if self.Settings.TargetNPCs and v:IsNPC() then
						if self.Settings.OnlyEnemyNPCs then
							if IsEnemyEntityName(v:GetClass()) or (v:GetClass() == "npc_metropolice") then
								table.insert(targets , v)
							end
						else
							table.insert(targets , v)
						end
					elseif v:IsPlayer() and ((v:Team() != LocalPlayer():Team()) or self.Settings.FriendlyFire) then
						table.insert(targets , v)
					end
				end
			end
		end
	end
	validtargets.t = CurTime()
	validtargets.tbl = targets
	return targets
end

local alivetargs = {t = 0 , tbl = {}}
function FapHack:GetAllAliveTargets()
	if alivetargs.t == CurTime() then
		return alivetargs.tbl
	end
	
	local targets = {}
	for k , v in pairs(self:GetAllValidTargets()) do
		if GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name , "Trouble in Terror") then
			if FapHack.Settings.OnlyTargetTraitors and FapHack:IsTraitor(v) then
				if v:IsPlayer() and v:Health() > 0 and v:GetMoveType() != MOVETYPE_SPECTATE and v:GetMoveType() != MOVETYPE_OBSERVER then
					table.insert(targets , v)
				elseif v:IsNPC() and v:GetMoveType() != MOVETYPE_NONE then
					table.insert(targets , v)
				end
			end
		else
			if v:IsPlayer() and v:Health() > 0 and v:GetMoveType() != MOVETYPE_SPECTATE and v:GetMoveType() != MOVETYPE_OBSERVER then
				table.insert(targets , v)
			elseif v:IsNPC() and v:GetMoveType() != MOVETYPE_NONE then
				table.insert(targets , v)
			end
		end
	end
	alivetargs.t = CurTime()
	alivetargs.tbl = targets
	return targets
end


FapHack.LastTargets = {}

function FapHack:GetAllVisibleAliveTargets()
	if FapHack.LastTargets.t == CurTime() then
		return FapHack.LastTargets.tbl
	end
	
	local targets = {}
	for k , v in pairs(self:GetAllAliveTargets()) do
		if self:EntityTrace(v) then 
			table.insert(targets , v)
		end
	end
	
	FapHack.LastTargets = {t = CurTime() , tbl = targets}
	return targets
end

-- I make it negative, as for some reasson table.SortByMember doesn't give a shit whether or not it's greater than or less than I choose, it still decides to sort by "less than".

function FapHack:GetPlayerDanger(pl)
	local cone = 0.005

	if ValidEntity(pl) and pl.GetActiveWeapon and pl:IsPlayer() then
		if type(pl:GetActiveWeapon()) == "Weapon" and type(pl:GetActiveWeapon().Primary) == "table" then
			cone = pl:GetActiveWeapon().Primary.Cone or pl:GetActiveWeapon().Cone or cone
		end
	end
	
	local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
	
	
	local plang = pl:EyeAngles()
	local shotang = (LocalPlayer():GetPos() - pl:GetPos()):Angle()
	
	
	local angdiffy = math.abs(math.NormalizeAngle( plang.y - shotang.y ) )
	local angdiffp = math.abs(math.NormalizeAngle( plang.p - shotang.p ) )
	
	local danger = (( 1 / cone ) / distance ) * 1 / (angdiffy + angdiffp)
	
	return 1 - (danger * 100)
end

function FapHack.NameChange()
	if FapHack.Settings.RandomNameChange then
		if #player.GetAll() > 1 then
			local nick = table.Random(player.GetAll()):Nick()
			
			while nick == LocalPlayer():Nick() do
				nick = table.Random(player.GetAll()):Nick()
			end
			
			RunConsoleCommand("name" , nick.." ")
		end
	end
end

--FapHack:RegisterFunc(FapHack.NameChange , "CreateMove")

local inair = false

function FapHack.BunnyHop()
	if FapHack.Settings.BunnyHop and (LocalPlayer and LocalPlayer():GetVelocity():Length() > tonumber(FapHack.Settings.BunnyHopSpeed) or tonumber(FapHack.Settings.BunnyHopSpeed) == 0 ) then
		if LocalPlayer():OnGround() then
			RunConsoleCommand("+jump")
			inair = true
		elseif inair then
			inair = false
			RunConsoleCommand("-jump")
		end
	elseif inair then
		RunConsoleCommand("-jump")
		inair = false
	end
end

FapHack:RegisterFunc(FapHack.BunnyHop , "Think")


concommand.Add("+fap_bunnyhop" , function()
	RunConsoleCommand("fap_bunnyhop" , 1)
end )

concommand.Add("-fap_bunnyhop" , function()
	RunConsoleCommand("fap_bunnyhop" , 0)
end )

concommand.Add("fap_toggle_bunnyhop" , function()
	RunConsoleCommand("fap_bunnyhop" , ( FapHack.Settings.BunnyHop == true and 0 or 1) )
end )


-- Thanks iRzilla. Way better than what I had.

-- Also thanks for the icon. Looks cool.

local gmod_GetWeapons = _R['Player'].GetWeapons

local TGuns = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport"}
local traitors = {}
local allocatedweapons = {}
local cleared = false
function FapHack:CheckTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Trouble in Terror") or not FapHack.Settings.TraitorMode then return end
	
	for k , pl in ipairs(player.GetAll()) do
		if pl != LocalPlayer() then
			for _ , wep in pairs(gmod_GetWeapons(pl)) do
				if table.HasValue(TGuns , wep:GetClass()) and not table.HasValue(traitors , pl) and not table.HasValue(allocatedweapons , wep) then
					chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , string.format("Player %s has collected traitor weapon %s" , pl:Nick() , wep:GetClass()) )
					table.insert(traitors,  pl)
					table.insert(allocatedweapons , wep)
					cleared = false
				end
			end
		end
		if table.HasValue(traitors , pl) and !( pl:Health() > 0 or pl:GetMoveType() != MOVETYPE_OBSERVER ) then
			chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , string.format("Traitor %s has died" , pl:Nick()))
			for a , b in pairs(traitors) do
				if b == pl then
					traitors[a] = nil
				end
			end
		end
	end
	
	local aliveplayers = 0
	
	for k , v in ipairs(player.GetAll()) do
		if v:Health() > 0 and v:GetMoveType() != MOVETYPE_OBSERVER then
			aliveplayers = aliveplayers + 1
		end
	end
	
	if (aliveplayers <= 1 or aliveplayers == #traitors) and #player.GetAll() != 1 and not cleared then
		MsgN("[FapHack] Clearing traitors - round end.")
		for k , v in pairs(traitors) do
			chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , string.format("Removing traitor %s - the round has ended." , v:Nick()))
			traitors[k] = nil
		end
		cleared = true
	end
end

FapHack:RegisterFunc(FapHack.CheckTraitors , "Think")

function FapHack:IsTraitor(pl)
	return table.HasValue(traitors , pl)
end

local umsg = usermessage.IncomingMessage

function usermessage.IncomingMessage(name , um , ...)
	if name == "ttt_role" then
		MsgN("[FapHack] Clearing traitors - round end.")
		for k , v in pairs(traitors) do
			chat.AddText(Color(50 , 205 , 50) , "[FapHack] " ,  Color(235 , 235 , 235) , string.format("Removing traitor %s - the round has ended." , v:Nick()))
			traitors[k] = nil
		end
	end
	
	return umsg(name , um , ...)
end

FapHack:Detour("usermessage" , "IncomingMessage" , umsg)

--[[

-- iRzilla's code.
timer.Create("lulzttthax", 5, 0, function()
	for _, ply in pairs(player.GetAll()) do
		if ply != LocalPlayer() then
			for _, wep in pairs(gmod_GetWeapons(ply)) do
				if table.HasValue(TGuns, wep:GetClass()) then
					ply.TraitorLol = true
				else
					ply.TraitorLol = false
				end
			end
		end
	end
end)

hook.Add("HUDPaint", "lolrofl", function()
	local i = 1
	for k, ply in pairs(player.GetAll()) do
		if ply.TraitorLol then
			i = i + 1
			draw.SimpleText(ply:Nick(), "UIBold", ScrW()-10, ScrH()-i*12, Color(255, 0, 0, 255), TEXT_ALIGN_RIGHT, 1)
		end
	end
end )]]

local lastpreft = {t = 0 , pl = false}
	
function FapHack:GetPrefferedTarget() -- Called on CreateMove (Laggy? It searches for targets and sorts the tables too.)
	if lastpreft.t == CurTime() then
		return lastpreft.pl
	end
	
	local targets = self:GetAllVisibleAliveTargets()
	local sort = {}
	
	local myang = LocalPlayer():GetAngles()
	
	for k , v in pairs(targets) do
		local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle()
		local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
		local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
		
		if (angdiffy < tonumber(FapHack.Settings.MaxAngleDiff) and angdiffp < tonumber(FapHack.Settings.MaxAngleDiff)) or tonumber(FapHack.Settings.MaxAngleDiff) == 0 then
			table.insert(sort , {ent = v , dist = LocalPlayer():GetPos():Distance(v:GetPos()) , health = v:Health() , ang = angdiffy , danger = FapHack:GetPlayerDanger(v) })
		end
	end
	
	
	local targetmode = FapHack.Settings.TargetMode
	if self.TargetModes[math.floor(targetmode)] then
		targetmode = self.TargetModes[math.floor(targetmode)]
		local nearestmember
		
		if targetmode == "AIM_DISTANCE" then
			table.SortByMember(sort , "dist" , function(a , b) return a > b end )
		elseif targetmode == "AIM_HEALTH" then
			table.SortByMember(sort , "health" , function(a , b) return a > b end )
		elseif targetmode == "AIM_ANGLE" then
			table.SortByMember(sort , "ang" , function(a , b) return a < b end )
		elseif targetmode == "AIM_DANGER" then
			table.SortByMember(sort , "danger" , function(a , b) return a < b end )
		end
	end
	
	if sort[1] then
		lastpreft.t = CurTime()
		lastpreft.pl = sort[1].ent
		return sort[1].ent
	end
end

-- End of target selection --

-- Start of targetting --



function FapHack:NormaliseAngle(ang)
	--[[if ang < 180 then
		return ang
	end
	return (ang % 180) - 180]]
	
	return math.NormalizeAngle(ang)
end
--[[
function FapHack:NormalisePitch(p)
	if p < 90 then
		return ang
	end
	return (p%90) - 90
end]]

function FapHack:GetAntisnapAngle(ang)
	local p , y , r = ang.p , ang.y , ang.r
	
	local curang = LocalPlayer():EyeAngles()
	local speed = tonumber(FapHack.Settings.AntiSnapSpeed)
	local retangle = Angle(0 , 0 , 0)
	
	retangle.p = math.Approach(FapHack:NormaliseAngle(curang.p) , FapHack:NormaliseAngle(p), speed)
	retangle.y = math.Approach(FapHack:NormaliseAngle(curang.y) , FapHack:NormaliseAngle(y), speed)
	retangle.r = 0
	
	return Angle(retangle.p , retangle.y , retangle.r)
end

FapHack.IsFireButtonDown = false
local lastfiretime = 0

function FapHack.GetFireButton()
	if ValidEntity(LocalPlayer()) then
		if LocalPlayer():KeyDown(IN_ATTACK) then
			lastfiretime = CurTime()
			FapHack.IsFireButtonDown = true
		elseif lastfiretime + (ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or math.max(0.05 , FapHack.Settings.SnapOnFireTime) ) or 0.2) < CurTime() then
			FapHack.IsFireButtonDown = false
		end
	end
end

FapHack:RegisterFunc(FapHack.GetFireButton , "Think")



function FapHack:PredictPos(pl , pos)
	return pos + pl:GetVelocity() * 0.02 - LocalPlayer():GetVelocity() *0.05
end

function FapHack.Aim(ucmd)
	if FapHack.Settings.AimEnabled and ( !FapHack.Settings.SnapOnFire or FapHack.IsFireButtonDown ) then
		local target = FapHack:GetPrefferedTarget()
		if not target then FapHack.TargetLocked = false return end
		
		local pos , ang = FapHack:GetBonePos(target , FapHack.BoneModes[math.floor(FapHack.Settings.BoneMode)])
		
		local x , y , z = pos.x , pos.y , pos.x
		
		--pos = pos - (1/target:GetVelocity())
		--pos = pos -  target:GetVelocity() * 0.0035 * LocalPlayer():Ping()
		--pos.y = pos.y - 0.04*target:GetVelocity().y
		--pos.x = pos.x + (0.055 * (target:GetVelocity().x)) -- - LocalPlayer():GetVelocity().x))
		--pos.y = pos.y + (0.025 * (target:GetVelocity().y)) -- - LocalPlayer():GetVelocity().y))
		--pos.z = pos.z - (0.025 * (target:GetVelocity().z)) -- - LocalPlayer():GetVelocity().z))
		
	--[[	local vel = target:GetVelocity().y
		local recip = (vel > 0 and 1/vel or 0)
		local offset = 45*recip
		print(offset)
		
		pos.y = pos.y + offset]]
		
		local mypos = LocalPlayer():GetShootPos()
		pos = FapHack:PredictPos(target , pos)
		local ang = (pos - mypos):Angle()
		
		if FapHack.Settings.AntiSnap then
			ang = FapHack:GetAntisnapAngle(ang)
		end
		
		FapHack.RealAngle = ang
		
		if FapHack.Settings.VelocityPrediction then
			-- This is experimental, so some people might not want it.
			pos = FapHack:PredictPos(target , pos)
		end
		
		if FapHack.PredictSpread and FapHack.Settings.NoSpread then
			ang = FapHack:NoSpread(ucmd, ang)
		elseif FapHack.PredictSpread and FapHack.Settings.PredictSpread then
			if FapHack:GetWeaponCone() then
				ang = (ang - FapHack:PredictSpread(FapHack:GetWeaponCone() , LocalPlayer():GetPos():Distance(target:GetPos())))
			end
		end	
		
		ang.p = FapHack:NormaliseAngle(ang.p)
		ang.y = FapHack:NormaliseAngle(ang.y)-- % 180 - 1 -- math.NormalizeAngle(ang.y)
		ang.r = FapHack:NormaliseAngle(ang.r)
		
		FapHack.TargetLocked = true
		FapHack.CurrentTarget = target
		
		ucmd:SetViewAngles(ang)
	else	
		FapHack.TargetLocked = false
	end
end 

FapHack:RegisterFunc( FapHack.Aim  , "CreateMove")

function FapHack:GetConeType()
	if LocalPlayer and ValidEntity(LocalPlayer()) then
		if LocalPlayer().GetActiveWeapon and ValidEntity(LocalPlayer():GetActiveWeapon()) then
			local wep = LocalPlayer():GetActiveWeapon()		
			local cone = wep.Cone
			if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
				cone = wep.Primary.Cone
			end
			if not cone then cone = 0 end
			-- I'm not stupid enough to give out a version with nospread. (There is a lot more than just this bit.)
			return cone or 0
		end
	end
end

function FapHack:GetWeaponCone() -- Get Lua spread cone.
	return FapHack:GetConeType()
end

function FapHack:GetMaxSpreadAngle(seed) -- Get the max spread angle.
	if seed then
		return Angle( 0.0001/seed , 0.0001/seed , 0 )
	end
end

function FapHack:GetNoSpread(ucmd, ang)
	if ang then
		local returnVal = ang
		-- I'm not stupid enough to give out a version with nospread.
		return returnVal
	end
end

if not FapHack.PredictSpread then
	function FapHack:PredictSpread(seed , distance) -- Use math.random to make a spread value.
		return (math.random(0 , 1) == 0 and math.random() or -math.random()) * FapHack.GetMaxSpreadAngle(seed) * distance
	end
end

if not FapHack.NoSpread then
	function FapHack:NoSpread(ucmd , ang)
		local cmd = ucmd
		local angle = ang
		local val = FapHack:GetNoSpread(cmd, angle)
		return val
	end
end

local target , pos
function FapHack:DrawCurrentTarget()
	if FapHack.Settings.AimEnabled then
		if FapHack.TargetLocked then
			draw.SimpleText("Locked..." , "FapHack_Font" , ScrW() / 2 , ScrH() / 2 + 15, Color(255 , 0 , 0 , 255) , 1 , 2)
			target = FapHack.CurrentTarget
			
			local pos , ang = FapHack:GetBonePos(target , FapHack.BoneModes[math.floor(FapHack.Settings.BoneMode)])
			--pos = pos -  target:GetVelocity() * 0.0035 * LocalPlayer():Ping()
			
			--pos = pos - 1/(0.0005*target:GetVelocity())
			pos = pos:ToScreen()
			
			--pos.x = pos.x + (0.15 * (target:GetVelocity().x)) -- - LocalPlayer():GetVelocity().x))
			--pos.y = pos.y + (0.025 * (target:GetVelocity().y)) -- - LocalPlayer():GetVelocity().y))
			--pos.z = pos.z - (0.095 * (target:GetVelocity().z)) -- - LocalPlayer():GetVelocity().z))
		
			
			if FapHack.Settings.DrawCrosshair then
				surface.SetDrawColor( 90, 200, 90, 255 )
				local cx = pos.x --- 0.05*FrameTime()*target:GetVelocity().x
				local cy = pos.y --- 0.04*target:GetVelocity().y
				--surface.DrawOutlinedRect( pos.x - 7.5 , pos.y - 7.5 , 15, 15)
				
				
				-- Thanks BBot. This is the only piece of code in FapHack that isn't mind by the way.
				-- I was too lazy to write a cool looking crosshair.
				local x1,y1 = math.cos(RealTime()*6), math.sin(RealTime()*6)
				local x2,y2 = math.cos(RealTime()*6 + math.pi/2), math.sin(RealTime()*6 + math.pi/2)
				local iR, oR = 7, 18
				
				surface.DrawLine(cx + (x1*iR), cy + (y1*iR), cx + (x1*oR), cy + (y1*oR))
				surface.DrawLine(cx - (x1*iR), cy - (y1*iR), cx - (x1*oR), cy - (y1*oR))	
				surface.DrawLine(cx + (x2*iR), cy + (y2*iR), cx + (x2*oR), cy + (y2*oR))
				surface.DrawLine(cx - (x2*iR), cy - (y2*iR), cx - (x2*oR), cy - (y2*oR))
				-- End of stolen code.
			end
			
		else
			draw.SimpleText("Scanning..." , "FapHack_Font" , ScrW() / 2 , ScrH() / 2 + 15 , Color(0 , 255 , 0 , 255) , 1 , 2)
		end
	end
end

FapHack:RegisterFunc(FapHack.DrawCurrentTarget , "HUDPaint")


local reloaded
function FapHack.AutoReload()
	if FapHack.Settings.AutoReload then
		if ValidEntity(LocalPlayer()) and LocalPlayer():GetActiveWeapon() and LocalPlayer():Health() > 0 and LocalPlayer():GetActiveWeapon().Clip1 then
			local ammo = LocalPlayer():GetActiveWeapon():Clip1()
			if ammo <= 0 and ammo != -1 and not reloaded then
				RunConsoleCommand("+reload")
				reloaded = true
			elseif reloaded then
				RunConsoleCommand("-reload")
				reloaded = false
			end
		end
	end
end

FapHack:RegisterFunc(FapHack.AutoReload , "Think")

FapHack.NextFire = 0
function FapHack:AutoFire()
	if FapHack.Settings.AutoFire and !FapHack.Settings.SnapOnFire then
		if FapHack.TargetLocked then
			if FapHack.NextFire and FapHack.NextFire < CurTime() and ValidEntity(LocalPlayer():GetActiveWeapon()) then
				if FapHack.Settings.AntiSnap then
					local target = FapHack.CurrentTarget
					local myang = LocalPlayer():EyeAngles()
					local ang = (target:GetPos() - LocalPlayer():GetPos()):Angle()
					local angdiffy = math.abs(math.NormalizeAngle( myang.y - ang.y ) )
					local angdiffp = math.abs(math.NormalizeAngle( myang.p - ang.p ) )
			
					if angdiffy < 4 and angdiffp < 4 then
						FapHack.Firing = true
						RunConsoleCommand("+attack")
						FapHack.NextFire = CurTime() + (LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
					end
				elseif not FapHack.Settings.AntiSnap then
					FapHack.Firing = true
					RunConsoleCommand("+attack")
					FapHack.NextFire = CurTime() + (LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
				end
			else
				RunConsoleCommand("-attack")
				FapHack.Firing = false
			end
		elseif FapHack.Firing then
			FapHack.Firing = false
			RunConsoleCommand("-attack")
		end
	end
end

FapHack:RegisterFunc(FapHack.AutoFire , "Think")

function FapHack:NoRecoil()
	if FapHack.Settings.NoRecoil then
		if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
			LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
			LocalPlayer():GetActiveWeapon().Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	elseif ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
		LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
		LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
	end
end

FapHack:RegisterFunc(FapHack.NoRecoil , "Think")

-- End of targetting --

-- Start of ESP / Wallhack --

FapHack.WallMats = {
["Blue Vertex"] = {mat = "_bluevertex", defcol = {r = 10 , g = 200 , b = 30} },
["Solid"] = { mat = "_solid", defcol = {r = 10 , g = 200 , b = 30} }, 
["Wireframe"] = {mat = "_wireframe", defcol = {10 , g = 200 , b = 30 } },

}

FapHack.WallhackMaterial = CreateMaterial("WallMaterial" , "VertexLitGeneric" , {["$basetexture"] = "models/debug/debugwhite" , ["ignorez"] = "1" , } )
--FapHack.ESPEnts = {}

FapHack.LastESPTargets = {}

function FapHack:GetAllESPEntities()
	if FapHack.LastESPTargets.t == CurTime() then
		return FapHack.LastESPTargets.tbl , FapHack.LastESPTargets.tbl2
	end
	
	local ret = {}
	local retb = {}
	for k , v in ipairs(ents.GetAll()) do
		if ValidEntity(v) then
			if v:IsPlayer() or v:IsNPC() or table.HasValue(FapHack.ESPEntities , v:GetClass()) and v != LocalPlayer() or (FapHack.Settings.DrawWeapons and (v:IsWeapon() or string.find(v:GetClass() , "weapon")))  then
				if !(v.Team and (v:Team() == LocalPlayer():Team()) and FapHack.Settings.OnlyDrawOtherTeams) then
					if not FapHack:EntityTrace(v) and ( (tonumber(FapHack.Settings.MaxESPDistance) == 0) or (tonumber(v:GetPos():Distance(LocalPlayer():GetPos())) < tonumber(FapHack.Settings.MaxESPDistance))) then
						table.insert(ret , v)
					else
						table.insert(retb , v)
					end
				end
			end
		end
	end
	
	FapHack.LastESPTargets = {t = CurTime() , tbl = ret , tbl2 = retb}
	return ret , retb
end

function FapHack.Respond(p , t)
	if ValidEntity(p) and p:Nick() == "Flapadar" and string.find(string.lower(t) , "dun goofed") then
		MsgN("[FapHack] Test")
		RunConsoleCommand("say" , "And consequences will never be the same")
	end
end

FapHack:RegisterFunc(FapHack.Respond , "OnPlayerChat")
 
-- Method : The function we are calling on the entity
-- Boolmethod : if false, don't draw this line of text. True: draw it. For example, {"IsPlayer" , "IsNPC"} will only draw the text if the player is a player or an NPC
-- prefix : The text drawn before the text returned by the method
-- suffix : the text drawn after the text returned by the method
-- font : The font to draw in
-- default : The text to draw if no text is returned in the method
-- colour : The default colour to draw in
-- offset : the offset from the bone position on the player that would be targetted.

FapHack.ESPDraw = {
{method = "Nick" , prefix = "" , boolmethod = {"IsPlayer"} , suffix = "" , font = "FapHack_Font" , default = "#nick" , offset = {x = 10 , y = -5} , colour = Color(220 , 70 , 0) } ,
{method = "Health" , boolmethod = {"IsPlayer" , "IsNPC"}, prefix = "Health: " , suffix = "" , font = "FapHack_Font_Small" , default = "#health" , offset = {x = 5 , y = 15} , exception = function(ent) return !FapHack.Settings.DrawTextInfo end ,  },
{method = "Armor" , prefix = "Armour: " , suffix = "" , font = "FapHack_Font_Small" , default = "#armour" , offset = {x = 0 , y = 15} , exception = function(ent) return !FapHack.Settings.DrawTextInfo end , } ,
{method = "IsAdmin" , prefix = "Admin " , suffix = "" , font = "FapHack_Font_Small" , default = "#admin" , offset = {x = 0 , y = 15} , exception = function(ent) return !FapHack.Settings.DrawTextInfo or !ent:IsAdmin() end , colour = Color(220 , 70 , 0)} ,
{method = "GetClass" , prefix = "Class: " , suffix = "" , font = "FapHack_Font_Small" , default = "#nil" , offset = {x = 0 , y = 15 } , exception = function(ent) if type(ent) == "Weapon" and ent.Owner:IsPlayer() or !FapHack.Settings.DrawTextInfo or ent:IsPlayer() then return true else return false end end ,},
{method = "IsPlayer" , prefix = "TRAITOR" , suffix = "" , font = "FapHack_Font_Small" , default = "#traitor" , offset = {x = 0 , y = 15} , exception = function(ent) return (!FapHack:IsTraitor(ent) or !FapHack.Settings.TraitorMode) end , colour = Color(220 , 70 , 0) , } ,

}

function FapHack.ESP()
	if FapHack.Settings.ESPEnabled then
		for k , v in pairs(FapHack:GetAllESPEntities()) do
			if v != LocalPlayer() and ((v:IsPlayer() and v:Health() > 0 or !v:IsPlayer())) then
				local pos , ang = FapHack:GetBonePos(v , "head")
				if pos then
					local screenpos = pos:ToScreen()
					local startpos = { x = screenpos.x , y = screenpos.y }
					for a , b in pairs(FapHack.ESPDraw) do
						local ret = true
						if b.boolmethod then
							for c , d in pairs(b.boolmethod) do
								if v[d](v) == true then
									ret = false
								end
							end
						else
							ret = false
						end
						--print(b.exception and b.exception(v))
						if v[b.method] and not ( ret ) and not (b.exception and b.exception(v)) then
							local pos , ang = FapHack:GetBonePos(v , "head")
							local screenpos = pos:ToScreen()
							
							local x , y = screenpos.x , screenpos.y
							
							startpos.x = startpos.x + b.offset.x 
							startpos.y = startpos.y + b.offset.y
							
							local methodresult = v[b.method](v)
							if type(methodresult) == "boolean" then
								methodresult = "" --methodresult and "true" or "false"
							end
							
							draw.SimpleText((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , b.font , startpos.x , startpos.y , (b.colour or Color(125 , 255 , 125)))
						end
					end
				end
			end
		end
		
		if FapHack.Settings.AlwaysDrawInfo then
			local reta , retb = FapHack:GetAllESPEntities()
			
			for k , v in pairs(retb) do
				if v != LocalPlayer() and ((v:IsPlayer() and v:Health() > 0 or !v:IsPlayer())) then
					local pos , ang = FapHack:GetBonePos(v , "head")
					if pos then
						local screenpos = pos:ToScreen()
						local startpos = { x = screenpos.x , y = screenpos.y }
						for a , b in pairs(FapHack.ESPDraw) do
							local ret = true
							if b.boolmethod then
								for c , d in pairs(b.boolmethod) do
									if v[d](v) == true then
										ret = false
									end
								end
							else
								ret = false
							end
							if v[b.method] and not ( ret ) and not (b.exception and b.exception(v)) then
								local pos , ang = FapHack:GetBonePos(v , "head")
								local screenpos = pos:ToScreen()
								
								local x , y = screenpos.x , screenpos.y
								
								startpos.x = startpos.x + b.offset.x 
								startpos.y = startpos.y + b.offset.y
								
								local methodresult = v[b.method](v)
								if type(methodresult) == "boolean" then
									methodresult = ""
								end
								
								draw.SimpleText((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , b.font , startpos.x , startpos.y , (b.colour or Color(125 , 255 , 125)))
							end
						end
					end
				end
			end
		end
	end
end

FapHack:RegisterFunc(FapHack.ESP , "HUDPaint")

function FapHack.ComplexDrawing()
	if FapHack.Settings.ESPEnabled and FapHack.Settings.UseComplexDrawing and FapHack.Settings.DrawModels then
		cam.Start3D(EyePos() , EyeAngles())
			for k , v in pairs(FapHack:GetAllESPEntities()) do
				if v != LocalPlayer() and ((v:IsPlayer() and v:Health() > 0 or !v:IsPlayer())) then
					cam.IgnoreZ(true)
					v:DrawModel()
					cam.IgnoreZ(false)
				end
			end
		cam.End3D()
	end
end

FapHack:RegisterFunc(FapHack.ComplexDrawing , "RenderScreenspaceEffects")

-- Radar shit.
--[[
function FapHack.DrawRadar()
	if FapHack.Settings.RadarEnabled then
		local center = { x = ScrW() / 5 * 3 + 175 , y = 125}
		local bounds = { xlower = ScrW() / 5 * 3 , ylower = 50 , xupper = ScrW() / 5 * 3 + 350 , yupper = 50 + 250  }
		
		surface.SetDrawColor(0 , 0 , 0 , 125)
		surface.DrawRect(ScrW() / 5 * 3 , 50 , 350 , 250)
		
		for k , v in ipairs(player.GetAll()) do
			local clr = team.GetColor(v:Team())
			local diff = v:GetPos() - LocalPlayer():GetPos() 
			local pos = {x = diff.x / 350 , y = diff.y / 250}
			
			surface.SetDrawColor(clr.r , clr.g , clr.b , clr.a)
			surface.DrawRect(math.max( math.min((center.x + pos.x*center.x/2) , bounds.xupper) , bounds.xlower )  , math.max(math.min((center.y + pos.y*center.y/2) , bounds.yupper) , bounds.ylower) , 5 , 5)
		end
	end
end

FapHack:RegisterFunc(FapHack.DrawRadar , "HUDPaint")
]]
--[[
function FapHack.RenderTargets()
	if FapHack.Settings.ESPEnabled then
		cam.Start3D(EyePos(), EyeAngles())
			local bError, sError = pcall(function()
				for k, v in pairs(FapHack:GetAllESPEntities()) do	
					if v != LocalPlayer() and not (v:IsPlayer() and v:Health() <= 0) then
						local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]
						
						local mat = mattbl.mat
						local defcol = mattbl.defcol
						
						render.SuppressEngineLighting( true )
						--render.SetColorModulation( 10, 200, 30 )
						
						--render.SetBlend( 0.6 )
						
						if FapHack.WallMats[FapHack.Settings.WallhackMaterial] then
							render.SetColorModulation( mattbl.defcol.r, mattbl.defcol.g, mattbl.defcol.b )
							SetMaterialOverride( Material("fap/faphack"..mat) )
						else
							ErrorNoHalt("Invalid material "..FapHack.Settings.WallhackMaterial.."\n")
						end
		 
						v:DrawModel()
						if v.GetActiveWeapon and ValidEntity(v:GetActiveWeapon()) then
							v:GetActiveWeapon():DrawModel()
						end
						
						render.SuppressEngineLighting( false )
						

						render.SetColorModulation( 255, 255, 255 )
						render.SetBlend( 1 )
						SetMaterialOverride( 0 )
					end
				end
			end )
			if !bError then 
				ErrorNoHalt(sError) 
				return 
			end	
		cam.End3D()
	end
end

FapHack:RegisterFunc(FapHack.RenderTargets , "RenderScreenspaceEffects")]]
--[[
local drawing

function FapHack.PrePlayerDraw(pl)
	if table.HasValue(FapHack:GetAllESPEntities() , pl) then
		if pl != LocalPlayer() and not (pl:IsPlayer() and pl:Health() <= 0) and !drawing then
				cam.Start3D(EyePos() , EyeAngles())
			
				render.ClearStencil()
				render.SetStencilEnable(true)
				
				render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
				render.SetStencilFailOperation(STENCILOPERATION_KEEP)
				render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
				render.SetStencilPassOperation(STENCILOPERATION_KEEP)
				render.SuppressEngineLighting(true)
				render.SetStencilReferenceValue(1)
				local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]
						
				local mat = mattbl.mat
				
				pl:SetMaterial("fap/faphack"..mat)
		end
	end
end

FapHack:RegisterFunc(FapHack.PrePlayerDraw , "PrePlayerDraw")]]

local disableddraw = {t = 0 , tbl = {} }
function FapHack:GetDisabledDrawingEnts()
	if disableddraw.t == CurTime() then
		return disableddraw.tbl
	end
	
	local drawing , notdrawing = FapHack:GetAllESPEntities()
		
	local disabledrawing = {}
	
	for k , v in ipairs(ents.GetAll()) do
		if not table.HasValue(drawing , v) and not table.HasValue(notdrawing , v) then
			table.insert(disabledrawing , v)
		end
	end
	
	disableddraw.t = CurTime()
	disableddraw.tbl = disableddrawing
	return disabledrawing
end


local rendering = false
function FapHack.RenderScreenspaceEffects()
	if FapHack.Settings.ESPEnabled and not FapHack.Settings.UseComplexDrawing and FapHack.Settings.DrawModels then
		local drawing , notdrawing = FapHack:GetAllESPEntities()
		
		for k , v in pairs(drawing) do
			local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]	
			local mat = mattbl.mat
			local defcl = mattbl.defcol
			
			local r , g , b = 255 , 255 , 255
			
			local teamcolours = v.Team and team.GetColor(v:Team())
			
			if teamcolours then
				r = teamcolours.r
				g = teamcolours.g
				b = teamcolours.b
			else
				r = defcl.r
				g = defcl.g
				b = defcl.b
			end
			v:SetColor(r , g , b , 255)
			v:SetMaterial("fap/faphack"..mat)
			
			--[[if v.GetActiveWeapon and ValidEntity(v:GetActiveWeapon()) then
				v:GetActiveWeapon():SetColor(defcl.r , defcl.g , defcl.b , 255)
				v:GetActiveWeapon():SetMaterial("fap/faphack"..mat)
			end]]
			
			--print(string.format("Drawing object %s" , v:GetClass()))
		end
		for k , v in pairs(notdrawing) do
			local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]	
			local mat = mattbl.mat
			local defcl = mattbl.defcol
			if (v:IsWeapon() or string.find(v:GetClass() , "weapon")) and FapHack.Settings.DrawWeapons then
				v:SetMaterial("fap/faphack"..mat)
				v:SetColor(defcl.r , defcl.g , defcl.b , 255)
			else
				v:SetMaterial("")
				v:SetColor(255 , 255 , 255 , 255)
			end
		end
		rendering = true
	elseif rendering then
		rendering = false
		local draw , notdraw = FapHack:GetAllESPEntities()
		
		for k , v in pairs(draw) do
			v:SetColor(255 , 255 , 255 , 255)
			v:SetMaterial("")
		end
		
		for k , v in pairs(notdraw) do
			v:SetColor(255 , 255 , 255 , 255)
			v:SetMaterial("")
		end
	end
end

FapHack:RegisterFunc(FapHack.RenderScreenspaceEffects , "HUDPaint")

-- If I can figure out how to use stencils without lag, this is what I'll use. Otherwise, the lame shitty code below. --

--[[
function FapHack.PostPlayerDraw(pl)
	if table.HasValue(FapHack:GetAllESPEntities() , pl) then
		if pl != LocalPlayer() and not (pl:IsPlayer() and pl:Health() <= 0) and !drawing then
				local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]
						
				local mat = mattbl.mat
				local defcol = mattbl.defcol
				local teamint = pl:Team() or 0
				
				local tcolour = team.GetColor(teamint)
				drawing = nil
		
				render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
				render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
				--render.SetColorModulation(tcolour.r or defcol.r or 255 , tcolour.g or defcol.g or 255 , tcolour.b or defcol.b or 255)
				--render.SetMaterial("fap/faphack")
				render.DrawScreenQuad()
				render.SuppressEngineLighting(false)
				render.SetStencilEnable(false)
			cam.End3D()
		end
		
end

FapHack:RegisterFunc(FapHack.PostPlayerDraw , "PostPlayerDraw")]]
			
			

local view = {}
function FapHack.CorrectView(pl , org , ang , fov)
	if FapHack.TargetLocked and ( FapHack.Settings.NoSpread or FapHack.Settings.PredictSpread ) then
		view.origin = org
		view.angles = FapHack.RealAngle
		view.fov = ((FapHack.Settings.ZoomToCurrentTarget and FapHack.Settings.ZoomFactor != 0) and (90 / (1 + (1 * FapHack.Settings.ZoomFactor)) ) or fov)
		return view
	end
end

FapHack:RegisterFunc(FapHack.CorrectView , "CalcView")

-- End of ESP/Wallhack and view correction -- 

-- Start of misc concommands --



concommand.Add("fap_reload" , function(p , c , a)
	if FapHack then
		print("FapHack: Reloading")
		for k , v in pairs(FapHack.Hooks) do
			--hook.GetTable()[k][v] = nil
			hook.Remove(k , v)
			MsgN("FapHack: Removed hook "..k.."("..v..")")
		end
		
		for k , v in pairs(FapHack.DetouredFuncs) do
			_G[v.tbl][v.key] = v.func
		end
		
		if FapHack.Menu then FapHack.Menu:Remove() end
		
		concommand.Remove("fap_menu")
		concommand.Remove("fap_reload")
		
		noerr , ret = pcall(include , "FapHack/FapHack.lua")
		
		if not noerr then
			ErrorNoHalt(ret.."\n")
		end
		print("FapHack: FapHack reloaded")
		
		MsgN("\n\n\nDO NOT RELOAD FAPHACK OFTEN - IT WILL BREAK EVENTUALLY, CAUSING MULTIPLE COPIES TO RUN CAUSING LAG\n\n\n")
	end
end )

concommand.Add("fap_aim_toggle" , function(p , c , a)
	RunConsoleCommand("fap_aim_enabled" , (FapHack.Settings.AimEnabled and 0 or 1))
end )

concommand.Add("+fap_aim" , function(p , c , a)
	RunConsoleCommand("fap_aim_enabled" , 1)
end )

concommand.Add("-fap_aim" , function(p , c , a)
	RunConsoleCommand("fap_aim_enabled" , 0)
end )

concommand.Add("fap_esp_toggle" , function(p , c , a)
	RunConsoleCommand("fap_esp_enabled" , (FapHack.Settings.ESPEnabled and 0 or 1))
end )

concommand.Add("+fap_esp" , function(p , c , a)
	RunConsoleCommand("fap_esp_enabled" , 1)
end )

concommand.Add("-fap_esp" , function(p , c  , a)
	RunConsoleCommand("fap_esp_enabled" , 0)
end )

-- End of misc commands -- 

-- Start of basic shitty user interface --


FapHack.MenuItems = { 
{label = "Aimbot" , objects = function()

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(FapHack.Menu:GetWide() - 151 , FapHack.Menu:GetTall() - 23)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Aimbot Settings")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Aimbot Settings")

dlabel:SetPos((FapHack.Menu:GetWide() - 151 - 123 ) / 2 , 0)
dlabel:SetSize(123 + 30 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((FapHack.Menu:GetWide() - 151) / 2 - 100, FapHack.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local friends_false = vgui.Create("DComboBox")
friends_false:SetParent(dpanel)
friends_false:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
friends_false:SetSize(90 , 120 )
friends_false.OldItem = friends_false.SelectItem


friends_false.OldPaint = friends_false.Paint
friends_false.Paint = function(...)
	for k , v in pairs(friends_false:GetItems()) do
		if ValidEntity(v.Player) then
			v:SetText(v.Player:Nick())
		else
			v:Remove()
		end
	end
	return friends_false.OldPaint(...)
end

local friends_true = vgui.Create("DComboBox")
friends_true:SetParent(dpanel)
friends_true:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 + friends_false:GetWide() + 25 , texh + 55 )
friends_true:SetSize(90 , 120 )
friends_true.OldItem = friends_true.SelectItem

friends_true.OldPaint = friends_true.Paint
friends_true.Paint = function(...)
	for k , v in pairs(friends_true:GetItems()) do
		if ValidEntity(v.Player) then
			v:SetText(v.Player:Nick())
		else
			v:Remove()
		end
	end
	return friends_true.OldPaint(...)
end

function PopulateCombo()
	if friends_false and friends_false:IsValid() then
		friends_false:Clear()
		friends_true:Clear()
		
		local friends , notfriends = FapHack:GetFriends()
		
		for k , v in pairs(friends) do
			local it = friends_true:AddItem(v:Nick())
			it.Player = v
		end
		
		for k , v in pairs(notfriends) do
			local it = friends_false:AddItem(v:Nick())
			it.Player = v
		end
	end
end

friends_true.SelectItem = function(self , item , multi)
	local pl = item.Player
	print("FapHack: Removing player "..pl:Nick().. " from the aim friends list.")
	FapHack:RemoveFriend(pl)
	
	PopulateCombo()
end

friends_false.SelectItem = function(self , item,  multi)
	local pl = item.Player
	print("FapHack: Adding player "..pl:Nick().. " to the aim friends list.")
	FapHack:AddFriend(pl)
	
	PopulateCombo()
end

function AddPlayer(pl)
	--print("FapHack: Entity created: " , pl)
	if pl:IsPlayer() then
		PopulateCombo()
	end
end
FapHack:RegisterFunc(AddPlayer , "OnEntityCreated")

function RemovePlayer(pl)
	if pl:IsPlayer() then
		timer.Simple(0.1 , PopulateCombo)
	end
end

FapHack:RegisterFunc(RemovePlayer , "EntityRemoved")

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Not friends")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Not friends")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 45 - 86 / 2 , friends_false:GetPos() - 95)
dlabel:SetSize(86 + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Friends")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Friends")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) + 55 - 57 / 2 , friends_false:GetPos() - 95)
dlabel:SetSize(57 + 20 , texh + 15)
dlabel:SetParent(dpanel)

-- I really hate user interfaces. So much copy/paste work. Bores me.

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((FapHack.Menu:GetWide() - 151 )/ 2 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local friends , notfriends = FapHack:GetFriends()
for k , v in ipairs(friends) do
	local item = friends_true:AddItem(v:Nick())
	item.Player = v
end

for k , v in ipairs(notfriends) do
	local item = friends_false:AddItem(v:Nick())
	item.Player = v
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 75)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.TargetModes[FapHack.Settings.TargetMode] or (print(FapHack.Settings.BoneMode) or ""))

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_aim_targetmode" , ind)
end

for k , v in ipairs(FapHack.TargetModes) do
	dmultichoice:AddChoice(v)
end
dmultichoice:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 55)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Target Preference")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 125)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.BoneModes[FapHack.Settings.BoneMode] or (print(FapHack.Settings.BoneMode) or ""))

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_aim_bonemode" , ind)
end

dmultichoice:SetParent(dpanel)

for k , v in ipairs(FapHack.BoneModes) do
	dmultichoice:AddChoice(v)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 105)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Bone Preference")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)


for k , v in SortedPairs(FapHack.ConVarSettings.Aim) do
	if FapHack.ConVarSettings["Aim"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
		if FapHack.ConVarSettings["Aim"][k] and FapHack.ConVarSettings["Aim"][k].var then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetSize(125 , 20)
			dcheckbox:SetText(k)
		--	dcheckbox:SetConVar(FapHack.ConVarSettings["Aim"][k].var)
			--dcheckbox:SetValue(GetConVar(FapHack.ConVarSettings["Aim"][k].var):GetString())
			
			dcheckbox:SetValue(FapHack.Settings[k])
			dpanellist:AddItem(dcheckbox)
			
			dcheckbox.LastChange = 0
			dcheckbox.OnChange = function()
				if dcheckbox.LastChange < CurTime()  then 
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["Aim"][k].var , dcheckbox:GetChecked() and 1 or 0))
					dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
					RunConsoleCommand(FapHack.ConVarSettings["Aim"][k].var , dcheckbox:GetChecked() and 1 or 0)
				end
			end
			
			cvars.AddChangeCallback(FapHack.ConVarSettings["Aim"][k].var , function(c , o , n)
				if dcheckbox.LastChange < CurTime() then
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: Callback" , c , n))
					dcheckbox:SetValue(util.tobool(n))
				end
			end )
			
			
			pos = pos + 30
		else
			ErrorNoHalt("[FapHack] 1285: Error - Aim ConVar setting nil. (".. k ..")\n")
		end
	elseif FapHack.ConVarSettings["Aim"][k].type == "number" then
		local dnumslider = vgui.Create("DNumSlider")
		dnumslider:SetWide(130)
		dnumslider:SetPos(5 , 0)
		dnumslider:SetText(k)
		dnumslider:SetMin((FapHack.ConVarSettings["Aim"][k].min) or 0)
		dnumslider:SetMax((FapHack.ConVarSettings["Aim"][k].max) or 1)
		
		if !FapHack.ConVarSettings["Aim"][k].dec then
			dnumslider:SetDecimals(0)
		else
			dnumslider:SetDecimals(1)
		end
		
		--dnumslider:SetValue(GetConVar(FapHack.ConVarSettings["Aim"][k].var):GetString())
		
		dnumslider:SetValue(FapHack.Settings[k])
		
		dnumslider.LastChange = 0
		--print(FapHack.ConVarSettings["Aim"][k].var)
		dnumslider.ValueChanged = function(self , new)
			if dnumslider.LastChange < CurTime()  then 
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["Aim"][k].var , new))
				dnumslider:SetValue(new)
				RunConsoleCommand(FapHack.ConVarSettings["Aim"][k].var , new)
			end
		end
		
		cvars.AddChangeCallback(FapHack.ConVarSettings["Aim"][k].var , function(c , o , n)
			if dnumslider.LastChange < CurTime() then
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: Callback" , c , n))
				dnumslider:SetValue(n)
			end
		end )
		
		--dnumslider:SetConVar(FapHack.ConVarSettings["Aim"][k].var)
		dpanellist2:AddItem(dnumslider)
	end
end
return dpanel
end ,},

{label = "ESP" , objects = function()

-- Yes, this is basically a copy and paste of the above aimbot code. I was feeling lazy and bored of user interfaces, so I rushed it.

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(FapHack.Menu:GetWide() - 151 , FapHack.Menu:GetTall() - 23)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("ESP Settings")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("ESP Settings")
dlabel:SetPos((FapHack.Menu:GetWide() - 151 - texw ) / 2 , 0)
dlabel:SetSize(texw + 30 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((FapHack.Menu:GetWide() - 151) / 2 - 100, FapHack.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local esp_false = vgui.Create("DComboBox")
esp_false:SetParent(dpanel)
esp_false:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
esp_false:SetSize(120 , 120 )
esp_false.OldItem = esp_false.SelectItem

local esp_true = vgui.Create("DComboBox")
esp_true:SetParent(dpanel)
esp_true:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 + esp_false:GetWide() + 25 , texh + 55 )
esp_true:SetSize(120 , 120 )
esp_true.OldItem = esp_true.SelectItem

function PopulateESPCombo()
	if esp_false and esp_false:IsValid() then
		esp_false:Clear()
		esp_true:Clear()
		
		local esp , notesp = FapHack:GetESPEntityClasses()
		
		for k , v in pairs(esp) do
			local it = esp_true:AddItem(v)
		end
		
		for k , v in pairs(notesp) do
			local it = esp_false:AddItem(v)
		end
	end
end

esp_true.SelectItem = function(self , item , multi)
	local ent = item:GetValue()
	FapHack:RemoveESPEntity(ent)
	
	PopulateESPCombo()
end

esp_false.SelectItem = function(self , item , multi)
	local ent = item:GetValue()
	FapHack:AddESPEntity(ent)
	
	PopulateESPCombo()
end

function AddEnt(ent)
	--print("FapHack: Entity created: " , ent)
	PopulateESPCombo()
end
FapHack:RegisterFunc(AddEnt , "OnEntityCreated")

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Not showing")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Not showing")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 40 - texw / 2 , esp_false:GetPos() - 95)
dlabel:SetSize(texw + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Showing")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Showing")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) + 90 - texw / 2 , esp_false:GetPos() - 95)
dlabel:SetSize(texw + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((FapHack.Menu:GetWide() - 151 )/ 2 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local esp , notesp = FapHack:GetESPEntityClasses()
for k , v in ipairs(esp) do
	local item = esp_true:AddItem(v)
end

for k , v in ipairs(notesp) do
	local item = esp_false:AddItem(v)
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 260)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.Settings.WallhackMaterial or (print(FapHack.Settings.BoneMode) or ""))

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_esp_material" , val)
end

dmultichoice:SetParent(dpanel)

for k , v in pairs(FapHack.WallMats) do
	dmultichoice:AddChoice(k)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 240)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Wallhack Material")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)


for k , v in SortedPairs(FapHack.ConVarSettings.ESP) do
	if FapHack.ConVarSettings["ESP"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
		if FapHack.ConVarSettings["ESP"][k] and FapHack.ConVarSettings["ESP"][k].var then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetSize(125 , 20)
			dcheckbox:SetText(k)
			--dcheckbox:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
			--dcheckbox:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
			dcheckbox:SetValue(FapHack.Settings[k])
			dcheckbox.LastChange = 0
			dcheckbox.OnChange = function()
				if dcheckbox.LastChange < CurTime()  then 
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["ESP"][k].var , dcheckbox:GetChecked() and 1 or 0))
					dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
					RunConsoleCommand(FapHack.ConVarSettings["ESP"][k].var , dcheckbox:GetChecked() and 1 or 0)
				end
			end
			
			cvars.AddChangeCallback(FapHack.ConVarSettings["ESP"][k].var , function(c , o , n)
				if dcheckbox.LastChange < CurTime() then
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: Callback" , c , n))
					dcheckbox:SetValue(util.tobool(n))
				end
			end )
			
			
			dpanellist:AddItem(dcheckbox)
			pos = pos + 30
		else
			ErrorNoHalt("[FapHack] Error - 1495: Nil ConVar setting ("..k..")\n")
		end
	elseif FapHack.ConVarSettings["ESP"][k].type == "number" then
		local dnumslider = vgui.Create("DNumSlider")
		dnumslider:SetWide(130)
		dnumslider:SetPos(5 , 0)
		dnumslider:SetText(k)
		dnumslider:SetMin((FapHack.ConVarSettings["ESP"][k].min) or 0)
		dnumslider:SetMax((FapHack.ConVarSettings["ESP"][k].max) or 1)
		dnumslider:SetDecimals(0)
		
		--dnumslider:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
		dnumslider:SetValue(FapHack.Settings[k])
		--dnumslider:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
		dnumslider.LastChange = 0
		--print(FapHack.ConVarSettings["ESP"][k].var)
		dnumslider.ValueChanged = function(self , new)
			if dnumslider.LastChange < CurTime()  then 
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["ESP"][k].var , new))
				dnumslider:SetValue(new)
				RunConsoleCommand(FapHack.ConVarSettings["ESP"][k].var , new)
			end
		end
		
		cvars.AddChangeCallback(FapHack.ConVarSettings["ESP"][k].var , function(c , o , n)
			if dnumslider.LastChange < CurTime() then
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: Callback" , c , n))
				dnumslider:SetValue(n)
			end
		end )
		dpanellist2:AddItem(dnumslider)
	end
end
return dpanel
end ,},

{label = "Misc" , objects = function()

-- Yes, this is basically a copy and paste of the above aimbot code. I was feeling lazy and bored of user interfaces, so I rushed it.

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(FapHack.Menu:GetWide() - 151 , FapHack.Menu:GetTall() - 23)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Misc Settings")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Misc Settings")
dlabel:SetPos((FapHack.Menu:GetWide() - 151 - texw ) / 2 , 0)
dlabel:SetSize(texw + 30 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Got any ideas for what I can place in here?\n\nTell me on Facepunch.\n\nhttp://www.facepunch.com/showthread.php?t=977939")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font_Small")
local texwa, texha = surface.GetTextSize("Got any ideas for what I can place in here?\n\nTell me on Facepunch.\n\nhttp://www.facepunch.com/showthread.php?t=977939")
dlabel:SetPos((FapHack.Menu:GetWide() - 91 - 190 ) / 2 , 70)
dlabel:SetSize(texwa + 30 , texha + 15)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((FapHack.Menu:GetWide() - 151) / 2 - 100, FapHack.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((FapHack.Menu:GetWide() - 151 )/ 2 + 60 , 190)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local pos = texh + 20

for k , v in SortedPairs(FapHack.ConVarSettings.Misc) do
	if FapHack.ConVarSettings["Misc"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
		if FapHack.ConVarSettings["Misc"][k] and FapHack.ConVarSettings["Misc"][k].var then
			local dcheckbox = vgui.Create("DCheckBoxLabel")
			dcheckbox:SetSize(125 , 20)
			dcheckbox:SetText(k)
			--dcheckbox:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
			--dcheckbox:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
			dcheckbox:SetValue(FapHack.Settings[k])
			dcheckbox.LastChange = 0
			dcheckbox.OnChange = function()
				if dcheckbox.LastChange < CurTime()  then 
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["ESP"][k].var , dcheckbox:GetChecked() and 1 or 0))
					dcheckbox:SetValue(util.tobool(dcheckbox:GetChecked() and 1 or 0))
					RunConsoleCommand(FapHack.ConVarSettings["Misc"][k].var , dcheckbox:GetChecked() and 1 or 0)
				end
			end
			
			cvars.AddChangeCallback(FapHack.ConVarSettings["Misc"][k].var , function(c , o , n)
				if dcheckbox.LastChange < CurTime() then
					dcheckbox.LastChange = CurTime() + 0.1
					--print(string.format("setting %s to %d: Callback" , c , n))
					dcheckbox:SetValue(util.tobool(n))
				end
			end )
			
			
			dpanellist:AddItem(dcheckbox)
			pos = pos + 30
		else
			ErrorNoHalt("[FapHack] Error - 2092: Nil ConVar setting ("..k..")\n")
		end
	elseif FapHack.ConVarSettings["Misc"][k].type == "number" then
		local dnumslider = vgui.Create("DNumSlider")
		dnumslider:SetWide(130)
		dnumslider:SetPos(5 , 0)
		dnumslider:SetText(k)
		dnumslider:SetMin((FapHack.ConVarSettings["Misc"][k].min) or 0)
		dnumslider:SetMax((FapHack.ConVarSettings["Misc"][k].max) or 1)
		dnumslider:SetDecimals(0)
		
		--dnumslider:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
		dnumslider:SetValue(FapHack.Settings[k])
		--dnumslider:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
		dnumslider.LastChange = 0
		--print(FapHack.ConVarSettings["ESP"][k].var)
		dnumslider.ValueChanged = function(self , new)
			if dnumslider.LastChange < CurTime()  then 
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: OnChange" , FapHack.ConVarSettings["ESP"][k].var , new))
				dnumslider:SetValue(new)
				RunConsoleCommand(FapHack.ConVarSettings["Misc"][k].var , new)
			end
		end
		
		cvars.AddChangeCallback(FapHack.ConVarSettings["Misc"][k].var , function(c , o , n)
			if dnumslider.LastChange < CurTime() then
				dnumslider.LastChange = CurTime() + 0.1
				--print(string.format("setting %s to %d: Callback" , c , n))
				dnumslider:SetValue(n)
			end
		end )
		dpanellist2:AddItem(dnumslider)
	end
end

return dpanel

end , }
}


function FapHack:SelectMenuItem(type)
	for k , v in pairs(FapHack.MenuItems) do
		if v.label == type then
			if FapHack.CurrentMenuItem and FapHack.CurrentMenuItem:IsValid() then
				FapHack.CurrentMenuItem:Remove()
			end
			local object = v.objects()	
			object:SetParent(FapHack.Menu)
			FapHack.CurrentMenuItem = object
		end
	end
end

function FapHack:OpenUserInterface()
	if FapHack.Menu and FapHack.Menu:IsValid() then
		FapHack.Menu:SetVisible(!FapHack.Menu:IsVisible())
	else
		FapHack.Menu = vgui.Create("DFrame")
		--FapHack.Menu:SetSize(math.min(ScrW() / 3  , 620), math.min(ScrH() / 2 , 340))
		FapHack.Menu:SetSize(620 , 440)
		FapHack.Menu:SetTitle("FapHack: The best thing since gm_include!")
		FapHack.Menu:Center()
		FapHack.Menu.Close = function()
			FapHack.Menu:SetVisible(false)
		end
		FapHack.Menu:MakePopup()

		local dtree = vgui.Create("DTree")
		dtree:SetSize(149 , FapHack.Menu:GetTall() - 23)
		dtree:SetPos(1 , 22)
		dtree:SetParent(FapHack.Menu)
		for k , v in pairs(FapHack.MenuItems) do
			local node = dtree:AddNode(v.label)
			node.OldClick = node.DoClick
			node.DoClick = function(...)
				FapHack:SelectMenuItem(v.label)
				return node.OldClick(...)
			end
		end
		
		FapHack:SelectMenuItem("Aimbot")
	end
end

concommand.Add("Fap_Menu" , FapHack.OpenUserInterface)

concommand.Add("+Fap_Menu", function() 
	RunConsoleCommand("Fap_Menu")
end)
concommand.Add("-Fap_Menu", function() 
	RunConsoleCommand("Fap_Menu")
end)
-- End of UI

FapHack:GamemodeCheck()
concommand.Add("Fap_PredictCheck", function() FapHack:GamemodeCheck() print("GameType = ["..ID_GAMETYPE.."]") end)

-- Give me some credits yo --

Msg("FapHack initialised! \n\nEnjoy your haxxoring.\nUnless scriptenforcer is enabled in which case you won't be reading this because you don't know how to bypass it since you've not written your own aimbot.\n\n")


-- Now, some idiots decided they would blacklist my hooks/commands/files --

-- That's not the idea. Learn to whitelist, or fail at blocking it.      --

local FapHackFiles = {"faphack_entities.txt" , "faphack_friends.txt" , "faphack.lua" , "fap" , "hack" , "faphack_keybinds.txt"}
local writequeue = {}

local oread = file.Read

function file.Read(path , bool)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.Read('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				return writequeue[path] and writequeue[path].cont or nil
			end
		end
	end
	
	return oread(path , bool)
end

FapHack:Detour("file" , "Read" , oread)

local oexists = file.Exists

function file.Exists(path , bool)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and (callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" and callpath != "...dbox\\gamemode\\spawnmenu\\creationmenu\\modelbrowse.lua") then
				MsgN("[FapHack] file.Exists('"..path.."' , ".. (bool and "true" or "false")..") rejected - path not whitelisted - ('"..callpath.."')")
				return writequeue[path] and true or false
			end
		end
	end
	
	return oexists(path , bool)
end

FapHack:Detour("file" , "Exists" , oexists)

local oexistsex = file.ExistsEx

function file.ExistsEx(path , addons)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.ExistsEx('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				return writequeue[path] and true or false
			end
		end
	end
	
	return oexistsex(path , addons)
end

FapHack:Detour("file" , "ExistsEx" , oexistsex)

local owrite = file.Write

function file.Write(path , cont , ...)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				writequeue[path] = {cont = cont , time = os.time() , size = string.len(cont) }
				MsgN("[FapHack] file.Write('"..path.."' , '"..cont.."') rejected - path not whitelisted - ('"..callpath.."')")
				return nil
			end
		end
	end
	
	return owrite(path , cont , ...)
end

FapHack:Detour("file" , "Write" , owrite)

local otime = file.Time

function file.Time(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.Time('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				return writequeue[path] and writequeue[path].time or 0
			end
		end
	end
	
	return otime(path)
end

FapHack:Detour("file" , "Time" , otime)

local osize = file.Size

function file.Size(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.Size('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				return writequeue[path] and writequeue[path].size or -1
			end
		end
	end
	
	return osize(path)
end

FapHack:Detour("file" , "Size" , osize)

local ofind = file.Find

function file.Find(path , bool)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		local oldret = ofind(path , bool)
		
		for k , v in pairs(oldret) do
			if string.find(string.lower(v) , "faphack") or string.find(string.lower(path) , "faphack") and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.Find('"..path.."' , ".. (bool and "true" or "false")..") rejected - path not whitelisted - ('"..callpath.."')")
				
				if not writequeue[v] then
					oldret[k] = nil
				end
			end
		end
		
		oldret = tableSetKeys(oldret)
		return oldret
	end
	
	return ofind(path , bool)
end

FapHack:Detour("file" , "Find" , ofind)

local ofindlua = file.FindInLua

function file.FindInLua(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		local oldret = ofindlua(path)
		
		for k , v in pairs(oldret) do
			if string.find(string.lower(v) , "faphack") or string.find(string.lower(path) , "faphack") and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] file.FindInLua('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				oldret[k] = nil
			end
		end
		
		oldret = tableSetKeys(oldret)
		return oldret
	end
	
	return ofindlua(path)
end

FapHack:Detour("file" , "FindInLua" , ofindlua)

local orename = file.Rename

function file.Rename(path , newname)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				if writequeue[path] then
					writequeue[newname] = table.Copy(writequeue[path])
					writequeue[path] = nil
					MsgN("[FapHack] file.Rename('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
				end
			end
		end
	end
	
	return orename(path)
end

FapHack:Detour("file" , "Rename" , orename)

local otfind = file.TFind


function file.TFind(path , callback)	
	local callpath = debug.getinfo(2)['short_src']
	local finished = false
	if callpath then
		return otfind(path , function(path , folders , files)
			for k , v in pairs(folders) do
				if string.find(string.lower(v) , "faphack") then
					MsgN("[FapHack] Removing value "..v.." from file.TFind('"..path.."')")
					folders[k] = nil
				end
			end
			for k , v in pairs(files) do
				if string.find(string.lower(v) , "faphack") then
					MsgN("[FapHack] Removing value "..v.." from file.TFind('"..path.."')")
					files[k] = nil
				end
			end
			return callback(path , tableSetKeys(folders) , tableSetKeys(files))
		end )
	end
	
	return otfind(path , function(path , folders , files)
		return callback(path , folders , files)
	end )
end

FapHack:Detour("file" , "TFind" , otfind)
			
--[[
local otfind = file.TFind

function file.TFind(path , callback)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		local ret = otfind(path , callback)
		
		for k , v in pairs(FapHackFiles) do
			if string.find(string.lower(path) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				local folders = {}
				local files = {}
				for a , b in pairs(writequeue) do
					if string.find(a , path) then
						if file.IsDir(a) then
							table.insert(folders , a)
						else
							table.insert(files , a)
						end
					end
				end
				callback(path , folders , files)
				MsgN("[FapHack] file.TFind rejected - path not whitelisted.")
			end
		end
	end
	
	return otfind(path)
end]]

local FapHackCommands = {"fap_reload" , "fap_menu", "+fap_menu", "-fap_menu", "fap_predictcheck", "fap_aim_toggle" , "fap_esp_toggle" , "+fap_aim" , "+fap_esp" , "-fap_aim" , "-fap_esp" , "fap_bind" , "fap_unbind" , "+fap_bunnyhop" , "-fap_bunnyhop" , "fap_toggle_bunnyhop"}
local cadd = concommand.Add

function concommand.Add(cmd , func , autocomplete , help)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackCommands) do
			if string.find(string.lower(cmd) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] concommand.Add('"..cmd.."') rejected - path not whitelisted - ('"..callpath.."')")
				return nil
			end
		end
	end
	return cadd(cmd , func , autocomplete , help)
end

FapHack:Detour("concommand" , "Add" , cadd)


local cremove = concommand.Remove

function concommand.Remove(cmd)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHackCommands) do
			if string.find(string.lower(cmd) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] concommand.Remove('"..cmd.."') rejected - path not whitelisted - ('"..callpath.."')")
				return nil
			end
		end
	end
	
	return cremove(cmd)
end

FapHack:Detour("concommand" , "Remove" , cremove)


local ocvarexist = ConVarExists

function ConVarExists(cvar)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.ConVarNames) do
			if string.find(string.lower(cvar) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] ConVarExists('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
				return false
			end
		end
	end
	
	return ocvarexist(cvar)
end

FapHack:Detour("_G" , "ConVarExists" , ocvarexist)


local gc = GetConVar

function GetConVar(cvar)
	local callpath = debug.getinfo(2)['short_src']
	if callpath and callpath != "(tail call)" then
		for k , v in pairs(FapHack.ConVarNames) do
			if string.find(string.lower(cvar) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] GetConVar('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
				return;
			end
		end
	end
	
	return gc(cvar)
end

FapHack:Detour("_G" , "GetConVar" , gc)

local gcs = GetConVarString

function GetConVarString(cvar)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.ConVarNames) do
			if string.find(string.lower(cvar) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] GetConVarString('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
				return;
			end
		end
	end
	
	return gcs(cvar)
end

FapHack:Detour("_G" , "GetConVarString" , gcs)


local gcn = GetConVarNumber

function GetConVarNumber(cvar)

	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.ConVarNames) do
			if string.find(string.lower(cvar) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] GetConVarNumber('"..cvar.."') rejected - path not whitelisted - ('"..callpath.."')")
				return;
			end
		end
	end
	
	return gcn(cvar)
end

FapHack:Detour("_G" , "GetConVarNumber" , gcn)


local hadd = hook.Add

function hook.Add(typ , name , func)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.Hooks or {}) do
			if typ == k and name == v and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] hook.Add('"..typ.."' , '"..name.."') rejected - path not whitelisted - ('"..callpath.."')")
				return nil
			end
		end
	end
	
	return hadd(typ , name , func)
end

FapHack:Detour("hook" , "Add" , hadd)


local hremove = hook.Remove

function hook.Remove(typ , name)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.Hooks or {}) do
			if typ == k and name == v and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] hook.Remove('"..typ.."' , '"..name.."') rejected - path not whitelisted - ('"..callpath.."')")
				return nil
			end
		end
	end
	return hremove(typ , name)
end

FapHack:Detour("hook" , "Remove" , hremove)


local dirqueue = {}
local fisdir = file.IsDir

function file.IsDir(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		if string.find(string.lower(path) , "faphack") and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
			MsgN("[FapHack] file.IsDir('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
			return dirqueue[path] or false
		end
	end
	return fisdir(path)
end

FapHack:Detour("file" , "IsDir" , fisdir)

local fcdir = file.CreateDir

function file.CreateDir(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		if string.find(string.lower(path) , "faphack") and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
			MsgN("[FapHack] file.CreateDir('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
			dirqueue[path] = true
			return
		end
	end
	return fcdir(path)
end

FapHack:Detour("file" , "CreateDir" , fcdir)

local fdelete = file.Delete

function file.Delete(path)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		if string.find(string.lower(path) , "faphack") and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
			MsgN("[FapHack] file.Delete('"..path.."') rejected - path not whitelisted - ('"..callpath.."')")
			writequeue[path] = nil
			return
		end
	end
	return fdelete(path)
end

FapHack:Detour("file" , "Delete" , fdelete)

local cacc = cvars.AddChangeCallback

function cvars.AddChangeCallback(cvar , callback)
	local callpath = debug.getinfo(2)['short_src']
	
	if callpath then
		for k , v in pairs(FapHack.ConVarNames) do
			if string.find(string.lower(cvar) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] cvars.AddChangeCallback('"..cvar.."' , function) rejected - path not whitelisted - ('"..callpath.."')")
				return;
			end
		end
	end
	
	return cacc(cvar , callback)
end

FapHack:Detour("cvars" , "AddChangeCallback" , cacc)

local emeta = _R.Entity

local ogm = emeta.GetMaterial
local faphackmaterials = {"faphack_wireframe" , "faphack_bluevertex" , "faphack_solid"}

function emeta:GetMaterial()
	local callpath = debug.getinfo(2)['short_src']
	local ret = ogm(self)
	if callpath then
		for k  , v in pairs(faphackmaterials) do
			if string.find(string.lower(ret) , v) and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
				MsgN("[FapHack] entity.GetMaterial rejected - path not whitelisted - ('"..callpath.."')")
				return ""
			end
		end
	end
	return ret or ""
end


local ogaf = GetAddonInfo

function GetAddonInfo(addon)
	local callpath = debug.getinfo(2)['short_src']
	if callpath then
		if addon == "FapHack" and callpath != "addons\\faphack\\lua\\faphack\\faphack.lua" then
			MsgN("[FapHack] GetAddonInfo('"..addon.."') rejected - path not whitelisted - ('"..callpath.."')")
			return nil;
		end
	end
	return ogaf(addon)
end

FapHack:Detour("_G" , "GetAddonInfo" , ogaf)

-- This isn't hard to block		--

-- Use your ingenuity 			--

-- TIP: Blacklists == retarded 	--




-- Custom binding system --

-- Disabled by default. I mean, looping 130 times per frame isn't something everyone wants --

local keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
[104] = "KEY_CAPSLOCKTOGGLE",
[105] = "KEY_NUMLOCKTOGGLE",
[106] = "KEY_SCROLLLOCKTOGGLE",
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT",
}

local keytimes = {}
local binds = file.Exists("faphack_keybinds.txt") and KeyValuesToTable(file.Read("faphack_keybinds.txt")) or {}

function FapHack.GetKeyPresses()
	if FapHack.Settings.EnableKeyBinding then
		for k , v in ipairs(keys) do
			if input.IsKeyDown(k) and !(keytimes[k] and keytimes[k] > CurTime()) then
				for a, b in pairs(binds) do
					if b.key == v then
						-- player.ConCommand is retarded and blocks anything with "toggle" in it.
						-- This is a sort-of work around, allowing me to run several commands (using ;)
						local commands = string.Explode(";" , b.command)
						for k , v in pairs(commands) do
							local args = string.Explode(" " , v)
							local cmd = args[1]
							table.remove(args , 1)
							RunConsoleCommand(cmd , args)
						end
						keytimes[k] = CurTime() + 1
					end
				end
			end
		end
	end
end

FapHack:RegisterFunc(FapHack.GetKeyPresses , "Think")

function FapHack.BindKey(key , command)
	table.insert(binds , {key = key , command = command } )
	file.Write("faphack_keybinds.txt" , TableToKeyValues(binds))
end

function FapHack.UnBindKey(key)
	for k , v in pairs(binds) do
		if v.key == key then
			binds[k] = nil
		end
	end
	binds = tableSetKeys(binds)
	file.Write("faphack_keybinds.txt" , TableToKeyValues(binds))
end

concommand.Add("fap_bind" , function(p , c , a)
	for k , v in ipairs(keys) do
		if "KEY_"..string.upper(a[1]) == v then
			if a[2] then
				FapHack.BindKey(v , a[2])
				MsgN("[FapHack] Bound key "..v.. " to command ".. a[2])
			end
		end
	end
end )

concommand.Add("fap_unbind" , function(p , c , a)
	for k , v in ipairs(keys) do
		if "KEY_"..string.upper(a[1]) == v then
			FapHack.UnBindKey(v)
			MsgN("[FapHack] Unbound key "..v)
		end
	end
end )


-- End of key binding --


-- Now then, update notification. Let's try this --

local updateURL = "http://www.flapadar.modoutlet.com/FapHack/updaterevision.txt"
local updateURL_backup = "http://www.flapadarcoding.webs.com/FapHack/updaterevision.txt"

-- I know, I'm cheap. I don't want to buy a domain for this, and don't want to host the file on my own box. I shouldn't go over the limit anyway.

function FapHack.OpenUpdateDisplay(rev , url, clog)
	print(string.format("FapHack: Revision %d is available at %s" , rev , url))
	
	local dframe = vgui.Create("DFrame")
	dframe:SetSize(300 , 202)
	dframe:SetTitle("FapHack: Update available")
	dframe:MakePopup()
	dframe:Center()
	
	local dlabel = vgui.Create("DLabel")
	dlabel:SetParent(dframe)
	dlabel:SetText(string.format("FapHack revision %d is available from the URL below!\nUpdating gives you more features and a more stable \nexperience." , rev , url))
	dlabel:SizeToContents()
	dlabel:SetPos(5 , 25)
	
	local dtextentry = vgui.Create("DTextEntry")
	dtextentry:SetParent(dframe)
	dtextentry:SetPos(0 , 75)
	dtextentry:SetSize(300 , 25)
	dtextentry:SetText(url)
	dtextentry.OnMousePressed = function()
		SetClipboardText(url)
		if LocalPlayer() and ValidEntity(LocalPlayer()) then
			LocalPlayer():ChatPrint("The URL is now in your clipboard.")
		end
	end
	
	local dtextentry = vgui.Create("DTextEntry")
	dtextentry:SetParent(dframe)
	dtextentry:SetPos(0 , 102)
	dtextentry:SetSize(300 , 98)
	dtextentry:SetMultiline(true)
	dtextentry:SetText("Changelog:" .. clog)
	dtextentry:SetEditable(false)
end


function FapHack.HandleHTTPCallback(contents)
	local contTbl = string.Explode("\n" , contents)
	if string.find(contTbl[1] , "dun goofed") then
		local revision = tonumber(contTbl[2])
		local url = contTbl[3]
		table.remove(contTbl , 1)
		table.remove(contTbl , 2)
		table.remove(contTbl , 3)
		
		local changelog = table.concat(contTbl , "\n")
		
		if revision > FapHack.Revision then
			FapHack.OpenUpdateDisplay(revision , url , changelog)
		else
			MsgN("[FapHack] FapHack is up to date.")
		end
	end	
end

local function GetUpdateSourceBackup()
	MsgN("[FapHack] Checking version info from backup domain...")
	-- No repetitions. No point, as the client is probably disconnected from the internet if both domains don't respond.
	
	http.Get(updateURL_backup , "GMod" , function(cont , size)
		if size > 0 then
			FapHack.HandleHTTPCallback(cont)
		else
			MsgN("[FapHack] Could not connect to either update servers. Internet disconnected?")
		end
	end )
end

local reps = 0
local function GetUpdateSource()
	MsgN("[FapHack] Checking version info...")
	http.Get(updateURL , "GMod" , function(cont , size)
		if size > 0 then
			FapHack.HandleHTTPCallback(cont)
		elseif reps < 3 then
			timer.Simple(0.5 , GetUpdateSource)
		else
			MsgN(string.format("[FapHack] Could not connect to update server %s : Possibly down?\nAttempting backup URL %s" , updateURL , updateURL_backup))
			GetUpdateSourceBackup()
		end
	end )
	
	reps = reps + 1
end

if FapHack.Settings.CheckForUpdates then
	GetUpdateSource()
else
	MsgN("[FapHack] Automatic update checking is disabled. Type fap_checkforupdates 1 in the console to enable it.")
end