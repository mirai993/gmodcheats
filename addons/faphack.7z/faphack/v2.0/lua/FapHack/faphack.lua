--[[

FapHack Public Version

It's shittier than the private version.


ToDo: Change ESP/Wallhack to use stencils instead of cam.3D
Write code for "Admin warning" convar
Team colours in the ESP, perhaps?

]]


-- Initial shit. Saving copies of functions --

include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )

include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )	
include( "includes/util/client.lua" )

function util.tobool(int)
	return math.floor(int) == 1
end

FapHack = {} -- Global until its ready.


-- Create the cool fonts we'll use.

 surface.CreateFont("coolvetica" , 20 , 500 , true , true , "FapHack_Font") 
 surface.CreateFont("coolvetica" , 15 , 500 , true , true , "FapHack_Font_Small") 
 
-- Now we want to do some hooking. --

FapHack.Functions = {["Think"] = {} , ["CreateMove"] = {} , ["CalcView"] = {} , ["RenderScene"] = {} ,  ["RenderScreenspaceEffects"] = {} , ["HUDPaint"] = {} , ["OnEntityCreated"] = {} , ["EntityRemoved"] = {} }
FapHack.Hooks = {}

function FapHack.Think(...)
	for k , v in pairs(FapHack.Functions.Think) do
		local noerr , ret = pcall(v , ...)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.CreateMove(ucmd)
	for k , v in pairs(FapHack.Functions.CreateMove) do
		if ucmd then
			local noerr , ret = pcall(v , ucmd)
			if ret ~= nil and noerr then
				return ret
			elseif not noerr then
				ErrorNoHalt(ret.."\n")
			end
		end
	end
end

function FapHack.CalcView(...)
	for k , v in pairs(FapHack.Functions.CalcView) do
		local noerr , ret = pcall(v , ...)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.RenderScene(...)
	for k , v in pairs(FapHack.Functions.RenderScene) do
		local noerr , ret = pcall(v , ...)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.RenderScreenspaceEffects(...)
	for k , v in pairs(FapHack.Functions.RenderScreenspaceEffects) do
		local noerr , ret = pcall(v , ...)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.HUDPaint(...)
	for k , v in pairs(FapHack.Functions.HUDPaint) do
		local noerr , ret = pcall(v , ...)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.OnEntityCreated(ent)
	for k , v in pairs(FapHack.Functions.OnEntityCreated) do
		local noerr , ret = pcall(v , ent)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

function FapHack.EntityRemoved(ent)
	for k , v in pairs(FapHack.Functions.EntityRemoved) do
		local noerr , ret = pcall(v , ent)
		if ret ~= nil and noerr then
			return ret
		elseif not noerr then
			ErrorNoHalt(ret.."\n")
		end
	end
end

for k , v in pairs(FapHack) do
	if k != "Hooks" then
		print("FapHack: Adding hook "..k)
		table.insert(FapHack.Hooks , k)
		hook.Add(k , "FapHack_"..k , FapHack[k])
	end
end

function FapHack:RegisterFunc(func , typ)
	table.insert(FapHack.Functions[typ] , func)
end

-- End of hooking --

-- Start of ConVars --

FapHack.Settings = {}
FapHack.ConVarSettings = {}
FapHack.ConVarSettings["Aim"] = {}
FapHack.ConVarSettings["ESP"] = {}
FapHack.ConVarSettings["Misc"] = {}

function FapHack:CreateConVar(cvar , def , save,  userdata,  var , maxno , minno , isdec)
	local booltype = false
	if type(def) == "boolean" then
		def = def and 1 or 0
		booltype = true
	end
	
	local convar = CreateConVar(cvar , def , save , userdata)
	if booltype then
		FapHack.Settings[var] = util.tobool(convar:GetInt())
	elseif type(def) == "number" then
		FapHack.Settings[var] = convar:GetInt()
	elseif type(def) == "string" then
		FapHack.Settings[var] = convar:GetString()
	end

	if string.find(cvar , "aim") then
		if booltype then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean"}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "string"}
		elseif type(def) == "number" then
			FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec}
		end
	elseif string.find(cvar , "esp") then
		if booltype then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "boolean"}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "string"}
		elseif type(def) == "number" then
			FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "number" , max = max , min = min , dec = isdec}
		end
	else
		if booltype then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "boolean"}
		elseif type(def) == "string" then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "string"}
		elseif type(def) == "number" then
			FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "number" , max = max , min = min , dec = isdec}
		end
	end
	
	cvars.AddChangeCallback(cvar , function(cvar , old , new)
		if booltype then
			FapHack.Settings[var] = util.tobool(math.floor(new))
			--print("FapHack: Setting "..var.." to " , util.tobool(new))
			
		else
			FapHack.Settings[var] = new
			--print("FapHack: Setting "..var.." to "..new)
		end
	end )
	
	return convar
end

FapHack:CreateConVar("fap_aim_enabled" , false , true , true , "AimEnabled")
FapHack:CreateConVar("fap_aim_friendlyfire" , false , true , true , "FriendlyFire")
FapHack:CreateConVar("fap_aim_targetnpcs" , false , true , true , "TargetNPCs")
FapHack:CreateConVar("fap_aim_autofire" , true , true , true , "AutoFire")
FapHack:CreateConVar("fap_aim_autoreload" , true , true , true , "AutoReload")
FapHack:CreateConVar("fap_aim_bonemode" , 1 , true , true , "BoneMode" , 3 , 1)
FapHack:CreateConVar("fap_aim_targetfriends" , true , true , true, "TargetFriends")
FapHack:CreateConVar("fap_aim_targetsteamfriends" , true , true , true , "TargetSteamFriends")
FapHack:CreateConVar("fap_aim_targetmode" , 1 , true , true , "TargetMode" , 2 , 1)
--FapHack:CreateConVar("fap_aim_nospread" , true , true , true , "NoSpread")
FapHack:CreateConVar("fap_aim_maxdistance" , 512 , true , true , "MaxDistance" , 16384 , 0)
FapHack:CreateConVar("fap_aim_targetadmins" , false , true , true , "TargetAdmins")
FapHack:CreateConVar("fap_aim_antisnap" ,  false , true , true , "AntiSnap")
FapHack:CreateConVar("fap_aim_norecoil" , true , true , true , "NoRecoil")
FapHack:CreateConVar("fap_aim_antisnapspeed" , 1 , true , true , "AntiSnapSpeed" , 5 , 0 , true)
FapHack:CreateConVar("fap_esp_enabled" , false , true , true , "ESPEnabled")
FapHack:CreateConVar("fap_esp_material" , "Blue Vertex" , true , true , "WallhackMaterial")
--FapHack:CreateConVar("fap_esp_adminwarning" , true , true , true , "AdminWarning")

-- End of ConVars --

-- Start of misc settings --

FapHack.TargetModes = {

[1] = "AIM_DISTANCE",
[2] = "AIM_HEALTH",

}

FapHack.BoneModes = {
[1] = "head",
[2] = "spine",
[3] = "shoulder",
}

-- Friends shit --

FapHack.Friends = (file.Exists("faphack_friends.txt") and KeyValuesToTable(file.Read("faphack_friends.txt")) or {} )

function FapHack:AddFriend(pl)
	if ValidEntity(pl) and pl != LocalPlayer() then
		table.insert(FapHack.Friends , pl:SteamID())
		file.Write("faphack_friends.txt" , TableToKeyValues(FapHack.Friends))
	end
end

function FapHack:RemoveFriend(pl)
	if ValidEntity(pl) then
		for k , v in pairs(FapHack.Friends) do
			if string.Trim(v) == pl:SteamID() then
				FapHack.Friends[k] = nil
			end
		end
		PrintTable(FapHack.Friends)
		file.Write("faphack_friends.txt" , TableToKeyValues(FapHack.Friends))
	end
end

function FapHack:AddFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			FapHack:AddFriend(v)
			break
		end
	end
end

function FapHack:RemoveFriendByName(nick)
	for k , v in ipairs(player.GetAll()) do
		--print("d" , v:Nick() , nick)
		if string.find(string.lower(v:Nick()) , string.lower(nick)) then
			FapHack:RemoveFriend(v)
			break
		end
	end
end

function FapHack:GetFriends()
	local friends = {}
	local notfriends = {}
	
	for k , v in ipairs(player.GetAll()) do
		if self:IsPlayerFriend(v) then
			table.insert(friends , v)
		elseif v != LocalPlayer() then
			table.insert(notfriends , v)
		end
	end
	
	return friends, notfriends
end


function FapHack:IsPlayerFriend(pl)
	local steamid = (pl.SteamID and pl:SteamID() or "")
	return table.HasValue(FapHack.Friends , steamid)
end


-- End of friends shit --

-- Start of ESP entities shit -- 

FapHack.ESPEntities = (file.Exists("faphack_entities.txt") and KeyValuesToTable(file.Read("faphack_entities.txt")) or {} )

function FapHack:AddESPEntity(class)
	if not table.HasValue(FapHack.ESPEntities , class) then
		table.insert(FapHack.ESPEntities , class)
		file.Write("faphack_entities.txt" , TableToKeyValues(FapHack.ESPEntities))
	end
end

function FapHack:RemoveESPEntity(class)
	for k , v in pairs(self.ESPEntities) do
		if class == v then
			FapHack.ESPEntities[k] = nil
		end
	end
	file.Write("faphack_entities.txt" , TableToKeyValues(FapHack.ESPEntities))
end

function FapHack:IsESPEntity(ent)
	return table.HasValue(FapHack.ESPEntities , ent:GetClass())
end

function FapHack:GetESPEntityClasses()
	local esp = {}
	local notesp = {}
	
	for k , v in ipairs(ents.GetAll()) do
		if not table.HasValue(esp , v:GetClass()) and not table.HasValue(notesp , v:GetClass()) then
			if FapHack:IsESPEntity(v) then
				table.insert(esp , v:GetClass())
			else
				table.insert(notesp , v:GetClass())
			end
		end
	end
	
	return esp , notesp
end

-- Start of bone position finding stuff --

-- These are in order of preference.

FapHack.Bones = {
["head"] = {


["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone" ,
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/poison.mdl"] = "ValveBiped.Bip01_Spine4" , 
["other"] = "ValveBiped.Bip01_Head1",
},

["spine"] = {

["other"] = "ValveBiped.Bip01_Spine",

} ,

["shoulder"] = {

["other"] = "ValveBiped.Bip01_R_Shoulder",

},
}

function FapHack:GetBonePos(ent , bonetype)
	if self.Bones[bonetype] then
		local boneid = ent:LookupBone(self.Bones[bonetype][ent:GetModel()] or self.Bones[bonetype]["other"])
		local pos , ang = ent:GetBonePosition(boneid)
		
		return pos , ang
	else
		for k , v in pairs(self.Bones) do	
			local boneid = ent:LookupBone(v[ent:GetModel()] or v["other"])
			if boneid then
				local pos , ang = ent:GetBonePosition(boneid)
				return pos, ang
			end
		end
	end
end

-- Start of target selection --

local trace , tr = {} , {}

function FapHack:EntityTrace(ent)
	if not ValidEntity(ent) or not ValidEntity(LocalPlayer()) then
		return false
	end
	
	trace = {}
	trace.start = LocalPlayer():EyePos()
	trace.endpos = ent:EyePos() -- What if they don't have eyes? Herp derp.
	trace.mask = 1174421507
	trace.filter = {LocalPlayer(), ent}
	
	tr = util.TraceLine(trace)
	if not tr.Hit then
		return true
	end
	return false
end

function FapHack:GetAllValidTargets()
	local targets = {}
	for k , v in ipairs(ents.GetAll()) do
		if not (v == LocalPlayer()) then
			if not (!self.Settings.TargetSteamFriends and (v.GetFriendStatus and v:GetFriendStatus() == "friend")) and not (self.Settings.TargetFriends and self:IsPlayerFriend(v)) and not((tonumber(FapHack.Settings.MaxDistance) > 0) and (LocalPlayer():GetPos():Distance(v:GetPos()) > tonumber(FapHack.Settings.MaxDistance))) and not (!(FapHack.Settings.TargetAdmins) and (v:IsPlayer() and v:IsAdmin())) then
				if self.Settings.TargetNPCs and v:IsNPC() then
					table.insert(targets , v)
				elseif v:IsPlayer() and ((v:Team() != LocalPlayer():Team()) or self.Settings.FriendlyFire) then
					table.insert(targets , v)
				end
			end
		end
	end
	return targets
end

function FapHack:GetAllAliveTargets()
	local targets = {}
	for k , v in pairs(self:GetAllValidTargets()) do
		if v:IsPlayer() and v:Health() > 0 and v:GetMoveType() != MOVETYPE_SPECTATE and v:GetMoveType() != MOVETYPE_OBSERVER then
			table.insert(targets , v)
		elseif v:IsNPC() and v:GetMoveType() != MOVETYPE_NONE then
			table.insert(targets , v)
		end
	end
	return targets
end

function FapHack:GetAllVisibleAliveTargets()
	local targets = {}
	for k , v in pairs(self:GetAllAliveTargets()) do
		if self:EntityTrace(v) then 
			table.insert(targets , v)
		end
	end
	return targets
end

function FapHack:GetPrefferedTarget()
	local targets = self:GetAllVisibleAliveTargets()
	local sort = {}
	
	for k , v in pairs(targets) do
		table.insert(sort , {ent = v , dist = LocalPlayer():GetPos():Distance(v:GetPos()) , health = v:Health()})
	end
	
	
	local targetmode = FapHack.Settings.TargetMode
	if self.TargetModes[targetmode] then
		targetmode = self.TargetModes[targetmode]
		
		if targetmode == "AIM_DISTANCE" then
			table.SortByMember(sort , "dist" , function(a , b) return a > b end )
		elseif targetmode == "AIM_HEALTH" then
			table.SortByMember(sort , "health" , function(a , b) return b > a end )
		end
	end
	if sort[1] then
		return sort[1].ent
	end
end

-- End of target selection --

-- Start of targetting --

function FapHack:NormaliseAngle(ang)
	if ang < 180 then
		return ang
	end
	return (ang % 180) - 180
end

function FapHack:GetAntisnapAngle(ang)
	local p , y , r = ang.p , ang.y , ang.r
	
	local curang = LocalPlayer():EyeAngles()
	local speed = tonumber(FapHack.Settings.AntiSnapSpeed)
	
	curang.p = p --math.Approach(curang.p , p, speed)
	curang.y = math.Approach(curang.y , y, speed)
	curang.r = 0
	
	return Angle(curang.p , curang.y , curang.r)
end


function FapHack.Aim(ucmd)
	if FapHack.Settings.AimEnabled then
		local target = FapHack:GetPrefferedTarget()
		if not target then FapHack.TargetLocked = false return end
		
		local pos , ang = FapHack:GetBonePos(target , FapHack.BoneModes[math.floor(FapHack.Settings.BoneMode)])
		
		local x , y , z = pos.x , pos.y , pos.z
		
		pos.x = pos.x - (0.095 * (target:GetVelocity().x)) -- - LocalPlayer():GetVelocity().x))
		pos.y = pos.y - (0.095 * (target:GetVelocity().y)) -- - LocalPlayer():GetVelocity().y))
		pos.z = pos.z - (0.095 * (target:GetVelocity().z)) -- - LocalPlayer():GetVelocity().z))
		
		local mypos = LocalPlayer():EyePos()
		
		local ang = (pos - mypos):Angle()
		
		if FapHack.Settings.AntiSnap then
			ang = FapHack:GetAntisnapAngle(ang)
		end
		
		FapHack.RealAngle = ang
		
		if FapHack.PredictSpread and FapHack.Settings.NoSpread then
			ang = FapHack.PredictSpread(ucmd , ang)
		end
		

		
		ang.p = FapHack:NormaliseAngle(ang.p)
		ang.y = FapHack:NormaliseAngle(ang.y)-- % 180 - 1 -- math.NormalizeAngle(ang.y)
		ang.r = FapHack:NormaliseAngle(ang.r)
		
		FapHack.TargetLocked = true
		FapHack.CurrentTarget = target
		
		ucmd:SetViewAngles(ang)
	else	
		FapHack.TargetLocked = false
	end
end 

FapHack:RegisterFunc( FapHack.Aim  , "CreateMove")

local target , pos
function FapHack:DrawCurrentTarget()
	if FapHack.Settings.AimEnabled then
		if FapHack.TargetLocked then
			draw.SimpleText("Locked..." , "FapHack_Font" , ScrW() / 2 , ScrH() / 2 + 15, Color(255 , 0 , 0 , 255) , 1 , 2)
			target = FapHack.CurrentTarget
			
			pos , ang = FapHack:GetBonePos(target , "head")
			
			pos = pos:ToScreen()
			
			surface.SetDrawColor( 255, 0, 0, 255 )
			surface.DrawOutlinedRect( pos.x - 14 , pos.y - 25 , 40, 40)
		else
			draw.SimpleText("Scanning..." , "FapHack_Font" , ScrW() / 2 , ScrH() / 2 , Color(0 , 255 , 0 , 255) , 1 , 2)
		end
	end
end

FapHack:RegisterFunc(FapHack.DrawCurrentTarget , "HUDPaint")
	

function FapHack.AutoReload()
	if FapHack.Settings.AutoReload then
		if ValidEntity(LocalPlayer()) and LocalPlayer():GetActiveWeapon() and LocalPlayer():Health() > 0 and LocalPlayer():GetActiveWeapon().Clip1 then
			local ammo = LocalPlayer():GetActiveWeapon():Clip1()
			if ammo <= 0 and ammo != -1 then
				RunConsoleCommand("+reload")
				timer.Simple(0.5 , function()
					RunConsoleCommand("-reload")
				end )
			end
		end
	end
end

FapHack:RegisterFunc(FapHack.AutoReload , "Think")

FapHack.NextFire = 0
function FapHack:AutoFire()
	if FapHack.Settings.AutoFire then
		if FapHack.TargetLocked then
			if FapHack.NextFire and FapHack.NextFire < CurTime() and ValidEntity(LocalPlayer():GetActiveWeapon()) then
				FapHack.Firing = true
				RunConsoleCommand("+attack")
				FapHack.NextFire = CurTime() + (LocalPlayer():GetActiveWeapon():GetTable().Primary and LocalPlayer():GetActiveWeapon():GetTable().Primary.Delay or 0.1 )
			else
				RunConsoleCommand("-attack")
				FapHack.Firing = false
			end
		elseif FapHack.Firing then
			FapHack.Firing = false
			RunConsoleCommand("-attack")
		end
	end
end

FapHack:RegisterFunc(FapHack.AutoFire , "Think")

function FapHack:NoRecoil()
	if FapHack.Settings.NoRecoil then
		if ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
			LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
			LocalPlayer():GetActiveWeapon().Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	elseif ValidEntity(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
		LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
		LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
	end
end

FapHack:RegisterFunc(FapHack.NoRecoil , "Think")

-- End of targetting --

-- Start of ESP / Wallhack --

FapHack.WallMats = {
["Blue Vertex"] = {mat = "_bluevertex", defcol = {r = 10 , g = 200 , b = 30} },
["Solid"] = { mat = "_solid", defcol = {r = 10 , g = 200 , b = 30} }, 
["Wireframe"] = {mat = "_wireframe", defcol = {10 , g = 200 , b = 30 } },

}

FapHack.WallhackMaterial = CreateMaterial("WallMaterial" , "VertexLitGeneric" , {["$basetexture"] = "models/debug/debugwhite" , ["ignorez"] = "1" , } )
--FapHack.ESPEnts = {}

function FapHack:GetAllESPEntities()
	local ret = {}
	for k , v in ipairs(ents.GetAll()) do
		if v:IsPlayer() or v:IsNPC() or table.HasValue(FapHack.ESPEntities , v:GetClass()) and v != LocalPlayer() then
			if not FapHack:EntityTrace(v) then
				table.insert(ret , v)
			end
		end
	end
	return ret
end

-- Method : The function we are calling on the entity
-- Boolmethod : if false, don't draw this line of text. True: draw it. For example, {"IsPlayer" , "IsNPC"} will only draw the text if the player is a player or an NPC
-- prefix : The text drawn before the text returned by the method
-- suffix : the text drawn after the text returned by the method
-- font : The font to draw in
-- default : The text to draw if no text is returned in the method
-- colour : The default colour to draw in
-- offset : the offset from the bone position on the player that would be targetted.

FapHack.ESPDraw = {
{method = "Nick" , prefix = "" , suffix = "" , font = "FapHack_Font" , default = "#nick" , offset = {x = 15 , y = -5} , colour = Color(220 , 70 , 0) } ,
{method = "Health" , boolmethod = {"IsPlayer" , "IsNPC"}, prefix = "Health: " , suffix = "" , font = "FapHack_Font_Small" , default = "#health" , offset = {x = 20 , y = 10} },
{method = "Armor" , prefix = "Armour: " , suffix = "" , font = "FapHack_Font_Small" , default = "#armour" , offset = {x = 20 , y = 25} } ,
{method = "IsAdmin" , prefix = "Admin: " , suffix = "" , font = "FapHack_Font_Small" , default = "#admin" , offset = {x = 20 , y = 40} } ,
}

function FapHack.ESP()
	if FapHack.Settings.ESPEnabled then
		for k , v in pairs(FapHack:GetAllESPEntities()) do
			if v != LocalPlayer() and ((v:IsPlayer() and v:Health() > 0 or !v:IsPlayer())) then
				for a , b in pairs(FapHack.ESPDraw) do
					local ret = true
					if b.boolmethod then
						for c , d in pairs(b.boolmethod) do
							if v[d](v) == true then
								ret = false
							end
						end
					else
						ret = false
					end
					if v[b.method] and not ( ret ) then
						local pos , ang = FapHack:GetBonePos(v , "head")
						local screenpos = pos:ToScreen()
						
						local x , y = screenpos.x , screenpos.y
						
						local methodresult = v[b.method](v)
						if type(methodresult) == "boolean" then
							methodresult = methodresult and "true" or "false"
						end
						
						draw.SimpleText((b.prefix or "") .. (methodresult or b.default) .. (b.suffix or "") , b.font , x + b.offset.x , y + b.offset.y , (b.colour or Color(125 , 255 , 125)))
					end
				end
			end
		end
	
	end
end

FapHack:RegisterFunc(FapHack.ESP , "HUDPaint")

function FapHack.RenderTargets()
	if FapHack.Settings.ESPEnabled then
		cam.Start3D(EyePos(), EyeAngles())
			local bError, sError = pcall(function()
				for k, v in pairs(FapHack:GetAllESPEntities()) do	
					if v != LocalPlayer() and not (v:IsPlayer() and v:Health() <= 0) then
						local mattbl = FapHack.WallMats[FapHack.Settings.WallhackMaterial]
						
						local mat = mattbl.mat
						local defcol = mattbl.defcol
						
						render.SuppressEngineLighting( true )
						--render.SetColorModulation( 10, 200, 30 )
						
						--render.SetBlend( 0.6 )
						
						if FapHack.WallMats[FapHack.Settings.WallhackMaterial] then
							render.SetColorModulation( mattbl.defcol.r, mattbl.defcol.g, mattbl.defcol.b )
							SetMaterialOverride( Material("fap/faphack"..mat) )
						else
							ErrorNoHalt("Invalid material "..FapHack.Settings.WallhackMaterial.."\n")
						end
		 
						v:DrawModel()
						if v.GetActiveWeapon and ValidEntity(v:GetActiveWeapon()) then
							v:GetActiveWeapon():DrawModel()
						end
						
						render.SuppressEngineLighting( false )
						

						render.SetColorModulation( 255, 255, 255 )
						render.SetBlend( 1 )
						SetMaterialOverride( 0 )
					end
				end
			end )
			if !bError then 
				ErrorNoHalt(sError) 
				return 
			end	
		cam.End3D()
	end
end

FapHack:RegisterFunc(FapHack.RenderTargets , "RenderScreenspaceEffects")

local view = {}
function FapHack.CorrectView(pl , org , ang , fov)
	if FapHack.TargetLocked then
		view.origin = org
		view.angles = FapHack.RealAngle
		view.fov = fov
		return view
	end
end

FapHack:RegisterFunc(FapHack.CorrectView , "CalcView")

-- End of ESP/Wallhack and view correction -- 

-- Start of misc concommands --

concommand.Add("fap_reload" , function(p , c , a)
	for k , v in pairs(FapHack.Hooks) do
		hook.Remove(v , "FapHack_"..v)
		print("FapHack: Removed hook FapHack_"..v)
	end
	
	if FapHack.Menu then FapHack.Menu:Remove() end
	
	for k , v in pairs(FapHack) do
		FapHack[k] = nil
	end
	
	include("FapHack/FapHack.lua")
	print("FapHack: FapHack reloaded")
end )

concommand.Add("fap_aim_toggle" , function(p , c , a)
	RunConsoleCommand("fap_aim_enabled" , (FapHack.Settings.AimEnabled and 0 or 1))
end )

concommand.Add("fap_esp_toggle" , function(p , c , a)
	RunConsoleCommand("fap_esp_enabled" , (FapHack.Settings.ESPEnabled and 0 or 1))
end )

-- End of misc commands -- 

-- Start of basic shitty user interface --


FapHack.MenuItems = { 
{label = "Aimbot" , objects = function()

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(FapHack.Menu:GetWide() - 151 , FapHack.Menu:GetTall() - 23)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Aimbot Settings")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Aimbot Settings")

dlabel:SetPos((FapHack.Menu:GetWide() - 151 - 123 ) / 2 , 0)
dlabel:SetSize(123 + 30 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((FapHack.Menu:GetWide() - 151) / 2 - 100, FapHack.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local friends_false = vgui.Create("DComboBox")
friends_false:SetParent(dpanel)
friends_false:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
friends_false:SetSize(90 , 120 )
friends_false.OldItem = friends_false.SelectItem


friends_false.OldPaint = friends_false.Paint
friends_false.Paint = function(...)
	for k , v in pairs(friends_false:GetItems()) do
		if ValidEntity(v.Player) then
			v:SetText(v.Player:Nick())
		else
			v:Remove()
		end
	end
	return friends_false.OldPaint(...)
end

local friends_true = vgui.Create("DComboBox")
friends_true:SetParent(dpanel)
friends_true:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 + friends_false:GetWide() + 25 , texh + 55 )
friends_true:SetSize(90 , 120 )
friends_true.OldItem = friends_true.SelectItem

friends_true.OldPaint = friends_true.Paint
friends_true.Paint = function(...)
	for k , v in pairs(friends_true:GetItems()) do
		if ValidEntity(v.Player) then
			v:SetText(v.Player:Nick())
		else
			v:Remove()
		end
	end
	return friends_true.OldPaint(...)
end

function PopulateCombo()
	friends_false:Clear()
	friends_true:Clear()
	
	local friends , notfriends = FapHack:GetFriends()
	
	for k , v in pairs(friends) do
		local it = friends_true:AddItem(v:Nick())
		it.Player = v
	end
	
	for k , v in pairs(notfriends) do
		local it = friends_false:AddItem(v:Nick())
		it.Player = v
	end
end

friends_true.SelectItem = function(self , item , multi)
	local pl = item.Player
	print("FapHack: Removing player "..pl:Nick().. " from the aim friends list.")
	FapHack:RemoveFriend(pl)
	
	PopulateCombo()
end

friends_false.SelectItem = function(self , item,  multi)
	local pl = item.Player
	print("FapHack: Adding player "..pl:Nick().. " to the aim friends list.")
	FapHack:AddFriend(pl)
	
	PopulateCombo()
end

function AddPlayer(pl)
	--print("FapHack: Entity created: " , pl)
	if pl:IsPlayer() then
		PopulateCombo()
	end
end
FapHack:RegisterFunc(AddPlayer , "OnEntityCreated")

function RemovePlayer(pl)
	if pl:IsPlayer() then
		timer.Simple(0.1 , PopulateCombo)
	end
end

FapHack:RegisterFunc(RemovePlayer , "EntityRemoved")

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Not friends")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Not friends")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 45 - 86 / 2 , friends_false:GetPos() - 95)
dlabel:SetSize(86 + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Friends")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Friends")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) + 55 - 57 / 2 , friends_false:GetPos() - 95)
dlabel:SetSize(57 + 20 , texh + 15)
dlabel:SetParent(dpanel)

-- I really hate user interfaces. So much copy/paste work. Bores me.

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((FapHack.Menu:GetWide() - 151 )/ 2 + 60 , 90)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local friends , notfriends = FapHack:GetFriends()
for k , v in ipairs(friends) do
	local item = friends_true:AddItem(v:Nick())
	item.Player = v
end

for k , v in ipairs(notfriends) do
	local item = friends_false:AddItem(v:Nick())
	item.Player = v
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 75)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.TargetModes[FapHack.Settings.TargetMode])

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_aim_targetmode" , ind)
end

for k , v in pairs(FapHack.TargetModes) do
	dmultichoice:AddChoice(v)
end
dmultichoice:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 55)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Target Preference")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 125)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.BoneModes[FapHack.Settings.BoneMode] or (print(FapHack.Settings.BoneMode) or ""))

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_aim_bonemode" , ind)
end

dmultichoice:SetParent(dpanel)

for k , v in pairs(FapHack.BoneModes) do
	dmultichoice:AddChoice(v)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 105)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Bone Preference")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)

for k , v in pairs(FapHack.ConVarSettings.Aim) do
	if FapHack.ConVarSettings["Aim"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
		local dcheckbox = vgui.Create("DCheckBoxLabel")
		dcheckbox:SetSize(125 , 20)
		dcheckbox:SetText(k)
		dcheckbox:SetConVar(FapHack.ConVarSettings["Aim"][k].var)
		dcheckbox:SetValue(GetConVar(FapHack.ConVarSettings["Aim"][k].var):GetString())
		dpanellist:AddItem(dcheckbox)
		pos = pos + 30
	elseif FapHack.ConVarSettings["Aim"][k].type == "number" then
		local dnumslider = vgui.Create("DNumSlider")
		dnumslider:SetWide(130)
		dnumslider:SetPos(5 , 0)
		dnumslider:SetText(k)
		dnumslider:SetMin((FapHack.ConVarSettings["Aim"][k].min) or 0)
		dnumslider:SetMax((FapHack.ConVarSettings["Aim"][k].max) or 1)
		
		if !FapHack.ConVarSettings["Aim"][k].dec then
			dnumslider:SetDecimals(0)
		else
			dnumslider:SetDecimals(1)
		end
		
		dnumslider:SetValue(GetConVar(FapHack.ConVarSettings["Aim"][k].var):GetString())
		dnumslider:SetConVar(FapHack.ConVarSettings["Aim"][k].var)
		dpanellist2:AddItem(dnumslider)
	end
end
return dpanel
end ,},

{label = "ESP" , objects = function()

-- Yes, this is basically a copy and paste of the above aimbot code. I was feeling lazy and bored of user interfaces, so I rushed it.

local dpanel = vgui.Create("DPanel")
dpanel:SetPos(151 , 23)
dpanel:SetSize(FapHack.Menu:GetWide() - 151 , FapHack.Menu:GetTall() - 23)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("ESP Settings")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("ESP Settings")
dlabel:SetPos((FapHack.Menu:GetWide() - 151 - texw ) / 2 , 0)
dlabel:SetSize(texw + 30 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist = vgui.Create("DPanelList")
dpanellist:SetPos(0 , texh + 25)
dpanellist:SetParent(dpanel)
dpanellist:SetSize((FapHack.Menu:GetWide() - 151) / 2 - 100, FapHack.Menu:GetTall() - texh - 26 - 30)
dpanellist:EnableVerticalScrollbar(true)
dpanellist:EnableHorizontal( false )
dpanellist:SetSpacing( 5 )
dpanellist.Paint = function() end

local esp_false = vgui.Create("DComboBox")
esp_false:SetParent(dpanel)
esp_false:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 , texh + 55 )
esp_false:SetSize(120 , 120 )
esp_false.OldItem = esp_false.SelectItem

local esp_true = vgui.Create("DComboBox")
esp_true:SetParent(dpanel)
esp_true:SetPos(((FapHack.Menu:GetWide() - 151) / 2 )- 90 + esp_false:GetWide() + 25 , texh + 55 )
esp_true:SetSize(120 , 120 )
esp_true.OldItem = esp_true.SelectItem

function PopulateCombo()
	esp_false:Clear()
	esp_true:Clear()
	
	local esp , notesp = FapHack:GetESPEntityClasses()
	
	for k , v in pairs(esp) do
		local it = esp_true:AddItem(v)
	end
	
	for k , v in pairs(notesp) do
		local it = esp_false:AddItem(v)
	end
end

esp_true.SelectItem = function(self , item , multi)
	local ent = item:GetValue()
	FapHack:RemoveESPEntity(ent)
	
	PopulateCombo()
end

esp_false.SelectItem = function(self , item , multi)
	local ent = item:GetValue()
	FapHack:AddESPEntity(ent)
	
	PopulateCombo()
end

function AddEnt(ent)
	--print("FapHack: Entity created: " , ent)
	PopulateCombo()
end
FapHack:RegisterFunc(AddEnt , "OnEntityCreated")

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Not showing")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Not showing")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 60 - texw / 2 , esp_false:GetPos() - 95)
dlabel:SetSize(texw + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dlabel = vgui.Create("DLabel")
dlabel:SetText("Showing")
dlabel:SetTextColor(Color(255 , 0 , 45))
dlabel:SetFont("FapHack_Font")
local texw, texh = surface.GetTextSize("Showing")
dlabel:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) + 75 - texw / 2 , esp_false:GetPos() - 95)
dlabel:SetSize(texw + 20 , texh + 15)
dlabel:SetParent(dpanel)

local dpanellist2 = vgui.Create("DPanelList")
dpanellist2:SetPos(((FapHack.Menu:GetWide() - 151) / 2 ) - 90 , 200)
dpanellist2:SetParent(dpanel)
dpanellist2:SetSize((FapHack.Menu:GetWide() - 151 )/ 2 + 60 , 90)
dpanellist2:EnableVerticalScrollbar(true)
dpanellist2:EnableHorizontal( true )
dpanellist2:SetSpacing( 5 )
dpanellist2.Paint = function() end

local esp , notesp = FapHack:GetESPEntityClasses()
for k , v in ipairs(esp) do
	local item = esp_true:AddItem(v)
end

for k , v in ipairs(notesp) do
	local item = esp_false:AddItem(v)
end

local pos = texh + 20

local dmultichoice = vgui.Create("DMultiChoice")
dmultichoice:SetPos(350 , 260)
dmultichoice:SetSize(100 , 20)
dmultichoice:SetText(FapHack.Settings.WallhackMaterial or (print(FapHack.Settings.BoneMode) or ""))

dmultichoice.OnSelect = function(self , ind , val)
	RunConsoleCommand("fap_esp_material" , val)
end

dmultichoice:SetParent(dpanel)

for k , v in pairs(FapHack.WallMats) do
	dmultichoice:AddChoice(k)
end

local dlabel = vgui.Create("DLabel")
dlabel:SetPos(350 , 240)
dlabel:SetSize(150 , 25)
dlabel:SetFont("FapHack_Font_Small")
dlabel:SetText("Wallhack Material")
dlabel:SetTextColor(Color(0 , 255 , 45))
dlabel:SetParent(dpanel)


for k , v in pairs(FapHack.ConVarSettings.ESP) do
	if FapHack.ConVarSettings["ESP"][k].type == "boolean" then -- It's a boolean convar, so a checkbox is suitable.
		local dcheckbox = vgui.Create("DCheckBoxLabel")
		dcheckbox:SetSize(125 , 20)
		dcheckbox:SetText(k)
		dcheckbox:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
		dcheckbox:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
		dpanellist:AddItem(dcheckbox)
		pos = pos + 30
	elseif FapHack.ConVarSettings["ESP"][k].type == "number" then
		local dnumslider = vgui.Create("DNumSlider")
		dnumslider:SetWide(130)
		dnumslider:SetPos(5 , 0)
		dnumslider:SetText(k)
		dnumslider:SetMin((FapHack.ConVarSettings["ESP"][k].min) or 0)
		dnumslider:SetMax((FapHack.ConVarSettings["ESP"][k].max) or 1)
		dnumslider:SetDecimals(0)
		dnumslider:SetValue(GetConVar(FapHack.ConVarSettings["ESP"][k].var):GetString())
		dnumslider:SetConVar(FapHack.ConVarSettings["ESP"][k].var)
		dpanellist2:AddItem(dnumslider)
	end
end
return dpanel
end ,},
}


function FapHack:SelectMenuItem(type)
	for k , v in pairs(FapHack.MenuItems) do
		if v.label == type then
			if FapHack.CurrentMenuItem and FapHack.CurrentMenuItem:IsValid() then
				FapHack.CurrentMenuItem:Remove()
			end
			local object = v.objects()
			object:SetParent(FapHack.Menu)
			FapHack.CurrentMenuItem = object
		end
	end
end

function FapHack:OpenUserInterface()
	if FapHack.Menu and FapHack.Menu:IsValid() then
		FapHack.Menu:SetVisible(!FapHack.Menu:IsVisible())
	else
		FapHack.Menu = vgui.Create("DFrame")
		--FapHack.Menu:SetSize(math.min(ScrW() / 3  , 620), math.min(ScrH() / 2 , 340))
		FapHack.Menu:SetSize(620 , 340)
		FapHack.Menu:SetTitle("FapHack: The best thing since gm_include!")
		FapHack.Menu:Center()
		FapHack.Menu.Close = function()
			FapHack.Menu:SetVisible(false)
		end
		FapHack.Menu:MakePopup()

		local dtree = vgui.Create("DTree")
		dtree:SetSize(149 , FapHack.Menu:GetTall() - 23)
		dtree:SetPos(1 , 22)
		dtree:SetParent(FapHack.Menu)
		for k , v in pairs(FapHack.MenuItems) do
			local node = dtree:AddNode(v.label)
			node.OldClick = node.DoClick
			node.DoClick = function(...)
				FapHack:SelectMenuItem(v.label)
				return node.OldClick(...)
			end
		end
		
		FapHack:SelectMenuItem("Aimbot")
	end
end

concommand.Add("Fap_Menu" , FapHack.OpenUserInterface)
-- End of UI

-- Give me some credits yo --

Msg("FapHack initialised! \n\nEnjoy your haxxoring.\nUnless scriptenforcer is enabled in which case you won't be reading this because you don't know how to bypass it\nOr if its my server because I'm supremely awesome and wrote a great anticheat\nFeel like playing some Zombie Survival? Go join my server and fail to use FapHack on it: 188.165.193.84:27023\n\n\n")


