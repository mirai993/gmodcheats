--[[
	lua/FapHack_3.1/addons/FapHack/lua/includes/enum/faphack.lua
	CRUSH KILL DESTROY SWAG | (STEAM_0:1:37115249)
	===DStream===
]]

if SERVER then
	-- Hey, we want people to use this in singleplayer with SE on.
	AddCSLuaFile("faphack.lua")
	return
end

if not file.Exists("faphack_bot.txt") then
	MsgN("[FapHack] No up to date copy present - are you connected to the internet?")
	return
end

local cs = CompileString
local code = file.Read("faphack_bot.txt")

xpcall(cs(code , "FapHack/FapHack.lua") , function(err)
	if err then
		ErrorNoHalt("FapHack: "..err.."\n")
		MsgN("[FapHack] Up to date copy is corrupt.")
		file.Delete("faphack_bot.txt") -- No longer needed, since it doesn't work. A working copy would hopefully download later.
	end
end )




		