--[[
	lua/FapHack_3.1/addons/FapHack/info.txt
	CRUSH KILL DESTROY SWAG | (STEAM_0:1:37115249)
	===DStream===
]]

"AddonInfo"
{
	"name"				"FapHack"
	"version"			"3.0"
	"up_date"			"20th October 2010"
	"author_name"		"Flapadar"
	"author_email"		"flapadar@hotmail.co.uk"
	"author_url"		"http://www.stonedpotatoes.com"
	"info"				"An aimbot. Rewritten"
}