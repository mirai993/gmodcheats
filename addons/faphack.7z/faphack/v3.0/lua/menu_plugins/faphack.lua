FapHack = {}

hook.Add("Think" , 0 , function()
	hook.Remove("Think" , 0)
	hook.Call("PostMenuLoaded")
end )

hook.Add("PostMenuLoaded" , "FapHack_Init" , function()
	MsgN("Menustate loaded. Initialising FapHack.")
	
	local deftbl = {	
		["default"] = {
			[1] = {c = "fap_shouldload" , val = 1},
			[2] = {c = "fap_aim_targetnpcs" , val = 1},
			[3] = {c = "fap_aim_friendlyfire" , val = 1},
			[4] = {c = "fap_esp_enabled" , val = 1},
			[5] = {c = "fap_esp_complex" , val = 1},
			[6] = {c = "fap_esp_traitormode" , val = 1},
			[7] = {c = "fap_esp_maxdistance" , val = 8192},
			[8] = {c = "fap_esp_drawmodels" , val = 1},
		},
		["ttt"] = {
			[1] = {c = "fap_shouldload" , val = 1},
			[2] = {c = "fap_esp_traitormode" , val = 1},
			[3] = {c = "fap_esp_complex" , val = 1},
			[4] = {c = "fap_esp_enabled" , val = 1},
			[5] = {c = "fap_aim_onlytargettraitors" , val = 1},
			[6] = {c = "fap_esp_drawweapons" , val = 1},
			[7] = {c = "fap_aim_friendlyfire" , val = 1},
		},
		
		["rage"] = {
			[1] = {c = "fap_shouldload" , val = 1},
			[2] = {c = "fap_aim_antisnap" , val = 0},
			[3] = {c = "fap_aim_maxdistance" , val = 0},
			[4] = {c = "fap_aim_autofire" , val = 1},
			[5] = {c = "fap_aim_targetadmins" , val = 1},
			[6] = {c = "fap_aim_targetfriends" , val = 1},
			[7] = {c = "fap_aim_targetmode" , val = 1},
			[8] = {c = "fap_aim_targetsteamfriends" , val = 1},
		},
		
		["team deathmatch"] = {
			[1] = {c = "fap_shouldload" , val = 1},
			[2] = {c = "fap_aim_targetnpcs" , val = 1},
			[3] = {c = "fap_aim_friendlyfire" , val = 0},
			[4] = {c = "fap_esp_enabled" , val = 1},
			[5] = {c = "fap_esp_complex" , val = 1},
			[6] = {c = "fap_esp_traitormode" , val = 1},
			[7] = {c = "fap_esp_maxdistance" , val = 8192},
			[8] = {c = "fap_esp_drawmodels" , val = 1},
		},
	}
	
	local presets = file.Exists("fap_presets.txt") and KeyValuesToTable(file.Read("fap_presets.txt")) or (file.Write("fap_presets.txt" , TableToKeyValues(deftbl)) or deftbl)
	
	function SavePreset(index , table)
		presets[index] = table
		file.Write("fap_presets.txt" , TableToKeyValues(presets))
	end
	
	
	FapHack.Version = 30
	FapHack.Settings = {}
	FapHack.ConVarSettings = {}
	FapHack.ConVarSettings["Aim"] = {}
	FapHack.ConVarSettings["ESP"] = {}
	FapHack.ConVarSettings["Misc"] = {}
	FapHack.ConVarNames = {}

	function tobool(int)
		if int == true then
			return true
		elseif int == false then
			return false
		else
			return math.floor(int) == 1
		end
	end
	
	function FapHack:CreateConVar(cvar , def , save,  userdata,  var , maxno , minno , isdec)
		local booltype = false
		if type(def) == "boolean" then
			def = def and 1 or 0
			booltype = true
		end
		
		local convar = CreateClientConVar(cvar , def , save , userdata)
		if booltype then
			FapHack.Settings[var] = tobool(convar:GetInt())
		elseif type(def) == "number" then
			if !isdec then
				FapHack.Settings[var] = convar:GetInt()
			else
				FapHack.Settings[var] = tonumber(convar:GetString())
			end
		elseif type(def) == "string" then
			FapHack.Settings[var] = convar:GetString()
		end

		if string.find(cvar , "aim") then
			if booltype then
				FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "boolean" , name = var}
			elseif type(def) == "string" then
				FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "string" , name = var}
			elseif type(def) == "number" then
				FapHack.ConVarSettings["Aim"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
			end
		elseif string.find(cvar , "esp") then
			if booltype then
				FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "boolean" , name = var}
			elseif type(def) == "string" then
				FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "string" , name = var }
			elseif type(def) == "number" then
				FapHack.ConVarSettings["ESP"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
			end
		else
			if booltype then
				FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "boolean" , name = var}
			elseif type(def) == "string" then
				FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "string" , name = var}
			elseif type(def) == "number" then
				FapHack.ConVarSettings["Misc"][var] = {var = cvar , type = "number" , max = maxno , min = minno , dec = isdec , name = var}
			end
		end
		
		table.insert(FapHack.ConVarNames , cvar)
		
		cvars.AddChangeCallback(cvar , function(cvar , old , new)
			if booltype then
				FapHack.Settings[var] = tobool(math.floor(new))
				--print("FapHack: Setting "..var.." to " , tobool(new))
				
			else
				FapHack.Settings[var] = new
				--print("FapHack: Setting "..var.." to "..new)
			end
		end )
		
		return convar
	end

	-- We want the same functionality as last time. So I'll just copy the convars too.

	FapHack:CreateConVar("fap_aim_checkpartialhits" , false , true , false , "CheckPartialHits")
	FapHack:CreateConVar("fap_aim_enabled" , false , true , false , "AimEnabled")
	FapHack:CreateConVar("fap_aim_friendlyfire" , false , true , false , "FriendlyFire")
	FapHack:CreateConVar("fap_aim_targetnpcs" , false , true , false , "TargetNPCs")
	FapHack:CreateConVar("fap_aim_autofire" , true , true , false , "AutoFire")
	FapHack:CreateConVar("fap_aim_autoreload" , true , true , false , "AutoReload")
	FapHack:CreateConVar("fap_aim_bonemode" , 1 , true , false , "BoneMode" , 3 , 1)
	FapHack:CreateConVar("fap_aim_targetfriends" , false , true , false, "TargetFriends")
	FapHack:CreateConVar("fap_aim_targetsteamfriends" , true , true ,false , "TargetSteamFriends")
	FapHack:CreateConVar("fap_aim_targetmode" , 1 , true , false , "TargetMode" , 4 , 1)
	--FapHack:CreateConVar("fap_aim_nospread" , true , true , false , "NoSpread")
	FapHack:CreateConVar("fap_aim_maxdistance" , 2048 , true , false , "MaxDistance" , 16384 , 0)
	FapHack:CreateConVar("fap_aim_targetadmins" , false , true ,false , "TargetAdmins")	
	FapHack:CreateConVar("fap_aim_antisnap" ,  false , true , false , "AntiSnap")
	FapHack:CreateConVar("fap_aim_norecoil" , true , true , false , "NoRecoil")
	FapHack:CreateConVar("fap_aim_antisnapspeed" , 1 , true , false , "AntiSnapSpeed" , 10 , 0 , true)
	FapHack:CreateConVar("fap_aim_maxangle" , 180 , true , false , "MaxAngleDiff" , 180 , 0 , true)
	FapHack:CreateConVar("fap_aim_snaponfire" , false , true , false , "SnapOnFire")
	FapHack:CreateConVar("fap_aim_snaponfiretime" , 0.6 , true , false , "SnapOnFireTime" , 10 , 0.1, true)
	FapHack:CreateConVar("fap_aim_onlytargettraitors" , false , true , false , "OnlyTargetTraitors")
	FapHack:CreateConVar("fap_aim_velocityprediction" , true , true , false , "VelocityPrediction")
	FapHack:CreateConVar("fap_aim_checknpcrelationship" , true , true, false , "CheckNPCRelationship") 

	FapHack:CreateConVar("fap_esp_enabled" , true , true , false , "ESPEnabled")
	FapHack:CreateConVar("fap_esp_material" , "Solid" , true , false , "WallhackMaterial")
	FapHack:CreateConVar("fap_esp_drawweapons" , true , true , false , "DrawWeapons")
	FapHack:CreateConVar("fap_esp_maxdistance" , 8192 , true , false , "MaxESPDistance" , 16384 , 0)
	FapHack:CreateConVar("fap_esp_zoomtocurrenttarget" , false , true , false , "ZoomToCurrentTarget")
	FapHack:CreateConVar("fap_esp_zoomfactor" , 1 , true , false , "ZoomFactor" , 5 , 0.1 , true)
	FapHack:CreateConVar("fap_esp_crosshair" , true , true , false , "DrawCrosshair")
	FapHack:CreateConVar("fap_esp_textinfo" , true , true , false , "DrawTextInfo")
	FapHack:CreateConVar("fap_esp_complex" , true , true , false , "UseComplexDrawing")
	FapHack:CreateConVar("fap_esp_alwaysdrawinfo" , false , true , false , "AlwaysDrawInfo")
	FapHack:CreateConVar("fap_esp_friendly" , false , true , false , "OnlyDrawOtherTeams")
	FapHack:CreateConVar("fap_esp_traitormode" , true , true , false , "TraitorMode")
	FapHack:CreateConVar("fap_esp_drawmodels" , true , true , false , "DrawModels")

	--FapHack:CreateConVar("fap_esp_radar" , false , true , true , "RadarEnabled")


	FapHack:CreateConVar("fap_checkforupdates" , true , true , false , "CheckForUpdates")
	FapHack:CreateConVar("fap_shouldload" , true , true , false , "ShouldLoad")
	FapHack:CreateConVar("fap_enablekeybinding" , false , true , false , "EnableKeyBinding")
	FapHack:CreateConVar("fap_bunnyhop" , false , true , false , "BunnyHop")
	FapHack:CreateConVar("fap_bunnyhopspeed" , 270 , true , false , "BunnyHopSpeed" , 700 , 0)
	FapHack:CreateConVar("fap_dontchecklos" , false , true , false , "IgnoreLOS")
	FapHack:CreateConVar("fap_alwaysloadhardcopy" , false , true , false , "AlwaysLoadHardCopy")
	FapHack:CreateConVar("fap_ucmdfire" , false , true , true , "UCMDFire") -- It's slightly slower than +attack for some reason, but it's more likely to bypass shitty anticheats.


	FapHack.Frame = vgui.Create("DFrame")
	FapHack.Frame:SetSize(300 , 376)
	FapHack.Frame:SetTitle("FapHack Menu")
	FapHack.Frame:SetPos(ScrW() - 310 , 5)
	FapHack.Frame:SetDraggable(false)
	FapHack.Frame:ShowCloseButton(false)
	FapHack.Frame:MakePopup()
	
	
	local dlistview = vgui.Create("DListView")
	dlistview:SetParent(FapHack.Frame)
	dlistview:SetPos(0 , 47)
	dlistview:SetSize(300 , 303)
	dlistview:AddColumn("ConVar")
	dlistview:AddColumn("Value")
	dlistview:SetMultiSelect(false)
	dlistview.oldselect = dlistview.OnClickLine
	
	for a , b in pairs(FapHack.ConVarSettings) do
		for k , v in pairs(FapHack.ConVarSettings[a]) do
			if v.type == "number" then
				if v.isdec then
					dlistview:AddLine(v.var , GetConVar(v.var):GetFloat())
				else
					dlistview:AddLine(v.var , GetConVar(v.var):GetInt())
				end
			elseif v.type == "string" then
				dlistview:AddLine(v.var , GetConVar(v.var):GetString())
			elseif v.type == "boolean" then
				dlistview:AddLine(v.var , GetConVar(v.var):GetInt())
			end
		end
	end
	
	dlistview:SortByColumn(1)
	
	local dtextentry = vgui.Create("DTextEntry")
	dtextentry:SetParent(FapHack.Frame)
	dtextentry:SetPos(0 , 22)
	dtextentry:SetSize(300 , 25)
	dtextentry:SetText("Select a ConVar below to edit.")
	
	dlistview.OnClickLine = function( self , line , ...)
		if dtextentry:GetValue() == "Enter a value for "..line:GetValue(1).." and press enter." then
			dtextentry:SetText("")
		else
			dtextentry:SetText("Enter a value for "..line:GetValue(1).." and press enter.")
		end
		dlistview.oldselect(self , line , ...)
	end
	
	dtextentry.OnMousePressed = function()
		if dtextentry:GetValue() == "Enter a value for "..dlistview:GetLine(dlistview:GetSelectedLine()):GetValue(1).." and press enter." then
			dtextentry:SetText("")
		end
	end
	
	dtextentry.OnEnter = function()
		RunConsoleCommand(dlistview:GetLine(dlistview:GetSelectedLine()):GetValue(1) , dtextentry:GetValue())
		dlistview:GetLine(dlistview:GetSelectedLine()):SetValue(2  , dtextentry:GetValue())
	end
	
	local dbutton = vgui.Create("DButton")
	dbutton:SetParent(FapHack.Frame)
	dbutton:SetPos(0, 350)
	dbutton:SetSize(150 , 25)
	dbutton:SetText("Save as preset")
	dbutton.DoClick = function()
		local preset = {}
		local x , y = gui.MousePos()
		for k , v in ipairs(dlistview:GetLines()) do
			table.insert(preset , {c=v:GetValue(1),val=v:GetValue(2)})
		end
		
		local dframe = vgui.Create("DFrame")
		dframe:SetTitle("Enter preset name")
		dframe:SetSize(150 , 73)
		dframe:SetPos(x - 100 , y)
		dframe:MakePopup()
		
		local dtextentry = vgui.Create("DTextEntry")
		dtextentry:SetParent(dframe)
		dtextentry:SetPos(0 , 22)
		dtextentry:SetSize(150 , 25)
		dtextentry:SetText("Enter preset name")
		dtextentry.OnMousePressed = function()	
			if dtextentry:GetValue() == "Enter preset name" then
				dtextentry:SetText("")
			end
		end
		
		dtextentry.OnEnter = function()
			SavePreset(dtextentry:GetValue() , preset)
			dframe:Remove()
		end
		
		local dbutton = vgui.Create("DButton")
		dbutton:SetParent(dframe)
		dbutton:SetPos(0 , 48)
		dbutton:SetSize(150 , 25)
		dbutton:SetText("Save.")
		dbutton.DoClick = function()
			SavePreset(dtextentry:GetValue() , preset)
			dframe:Remove()
		end
	end
	
	local dbutton = vgui.Create("DButton")
	dbutton:SetParent(FapHack.Frame)
	dbutton:SetPos(150 , 350)
	dbutton:SetSize(150 , 25)
	dbutton:SetText("Load preset")
	dbutton.DoClick = function()
		local x , y = gui.MousePos()
		local dframe = vgui.Create("DFrame")
		dframe:SetTitle("Enter preset name")
		dframe:SetSize(200, 220)
		dframe:SetPos(x - 100 , y )
		dframe:MakePopup()
		
		local dl = vgui.Create("DListView")
		dl:SetParent(dframe)
		dl:SetPos(0 , 22)
		dl:SetSize(200 , 173)
		dl:AddColumn("Preset")
		dl.OnRowRightClick = function(self , row)	
			local dm = DermaMenu()
			dm:AddOption("Delete selected preset" , function() 
				presets[dl:GetLine(row):GetValue(1)] = nil 
				file.Write("fap_presets.txt" , TableToKeyValues(presets)) 
				dl:Clear()
				for k , v in pairs(presets) do
					dl:AddLine(k)
				end
			end )
			dm:Open()
		end
		
		for k , v in pairs(presets) do
			dl:AddLine(k)
		end
		
		local db = vgui.Create("DButton")
		db:SetParent(dframe)
		db:SetPos(0 , 195)
		db:SetText("Load.")
		db:SetSize(200 , 25)
		db.DoClick = function()
			if dl:GetSelectedLine() then
				local preset = dl:GetLine(dl:GetSelectedLine()):GetValue(1)
				for k , v in pairs(presets[preset]) do
					
					RunConsoleCommand(v.c , v.val)
					for a , b in ipairs(dlistview:GetLines()) do
						if b:GetValue(1) == v.c then
							b:SetValue(2 , v.val)
						end
					end
				end
				dframe:Remove()
			end
		end
	end
	
	concommand.Add("_fap_menu_reload" , function()
		FapHack.Frame:Remove()
		include("menu_plugins/faphack.lua")
	end )
	
	
	if FapHack.Settings.CheckForUpdates then
		local version
		
		-- Get the local version from the file.
		if not file.Exists("faphack_bot.txt") then
			-- Version 10
			version = 10
		else
			local stuff = file.Read("faphack_bot.txt")
			local versionstart = string.find(stuff , "FapHack.Revision =")
			local versionend = string.find(string.sub(stuff , versionstart) , "\n")
			version = tonumber(string.sub(stuff , versionstart + string.len("FapHack.Revision =") , versionstart + versionend - 1))
		end
		
		-- If the below isn't available, then fuck it. freewebs is too slow for a 70kb file.
		local url = "http://flapadar.modoutlet.com/FapHackV3/check.txt"
		
		local function ShowUpdate(rev , url, clog)
			print(string.format("FapHack: Version %d is available at %s" , rev , url))
			
			local dframe = vgui.Create("DFrame")
			dframe:SetSize(300 , 202)
			dframe:SetTitle("FapHack: Update available")
			dframe:MakePopup()
			dframe:Center()
			
			local dlabel = vgui.Create("DLabel")
			dlabel:SetParent(dframe)
			dlabel:SetText(string.format("FapHack Version %d is available from the URL below!\nUpdating gives you more features and a more stable \nexperience." , rev , url))
			dlabel:SizeToContents()
			dlabel:SetPos(5 , 25)
			
			local dtextentry = vgui.Create("DTextEntry")
			dtextentry:SetParent(dframe)
			dtextentry:SetPos(0 , 75)
			dtextentry:SetSize(300 , 25)
			dtextentry:SetText(url)
			dtextentry.OnMousePressed = function()
				SetClipboardText(url)
				if LocalPlayer() and ValidEntity(LocalPlayer()) then
					LocalPlayer():ChatPrint("The URL is now in your clipboard.")
				end
			end
			
			local dtextentry = vgui.Create("DTextEntry")
			dtextentry:SetParent(dframe)
			dtextentry:SetPos(0 , 102)
			dtextentry:SetSize(300 , 98)
			dtextentry:SetMultiline(true)
			dtextentry:SetText("Changelog:" .. clog)
			dtextentry:SetEditable(false)
		end
		
		local function DownloadUpdate(rev , url , changelog)
			MsgN("[FapHack] Downloading revision "..rev..":\n"..changelog)
			
			local downreps = 0
			local function GetHTTPSource(url)
				http.Get(url , "" , function(cont , size)
					if size > 0 and string.find(cont , "FapHack = {}") then
						file.Write("faphack_bot.txt" , cont)
					elseif downreps < 5 then
						downreps = downreps + 1
						GetHTTPSource(url)
					end
				end)
			end 
			
			GetHTTPSource(url)
		end
		
		local function FormatVersion(str)
			local contTbl = string.Explode("\n" , str)
			if string.find(contTbl[1] , "dun goofed") then
				local revision = tonumber(contTbl[2])
				local fullversion = tonumber(contTbl[3])
				local revurl = contTbl[4]
				local fullurl = contTbl[5]
				table.remove(contTbl , 1)
				table.remove(contTbl , 2)
				table.remove(contTbl , 3)
				table.remove(contTbl , 4)
				table.remove(contTbl , 5)
				
				local changelog = table.concat(contTbl , "\n")
				
				if fullversion > FapHack.Version then
					MsgN("Out of date.")
					ShowUpdate(fullversion , fullurl , changelog)
				end
				
				if (version and (revision > version)) then
					DownloadUpdate(revision , revurl , changelog)
				else
					MsgN("[FapHack] FapHack is up to date.")
				end
			else
				CheckVersion()
			end
		end
		
		local checkreps = 0
		local function CheckVersion()
			http.Get(url , "" , function(cont , size)
				MsgN("[FapHack] Attempting to connect to update server.")
				if size > 0 and string.find(cont , "dun goofed") then
					FormatVersion(cont)
				elseif checkreps < 3 then
					checkreps = checkreps + 1
					CheckVersion()
				else
					MsgN("[FapHack] Could not connect to update server.")
				end
			end )
		end
		CheckVersion()
	end
		
end )


