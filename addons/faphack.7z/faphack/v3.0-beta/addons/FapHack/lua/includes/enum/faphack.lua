if SERVER then
	-- Hey, we want people to use this in singleplayer with SE on.
	AddCSLuaFile("faphack.lua")
	AddCSLuaFile("FapHack/faphack.lua")
	return
end

local cs = CompileString

if GetConVar("fap_shouldload"):GetInt() != 1 then return end

if GetConVar("fap_alwaysloadhardcopy"):GetInt() == 1 then
	MsgN("[FapHack] Loading hard copy.")
	include("FapHack/FapHack.lua")
	return
end

if not file.Exists("faphack_bot.txt") then
	MsgN("[FapHack] No up to date copy present, loading original.")
	include("FapHack/FapHack.lua")
	return
end

local code = file.Read("faphack_bot.txt")

xpcall(cs(code , "FapHack/FapHack.lua") , function(err)
	if err then
		ErrorNoHalt("FapHack: "..err.."\n")
		MsgN("Up to date copy is corrupt. Loading original backup.")
		file.Delete("faphack_bot.txt") -- No longer needed, since it doesn't work. A working copy would hopefully download later.
		include("FapHack/FapHack.lua")
	end
end )




		