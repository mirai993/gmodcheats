--[[
	EXECUTABLE_PATH/scripts/testfile.lua [#115 (#119), 3005923463, UID:2958554737]
	{W.Inc}-Santa | STEAM_0:1:69145936 <86.183.110.43:27005> | [11.05.14 04:46:47PM]
	===BadFile===
]]

if (_G["LeyAC"] == true) then
	print "LeyAC is on this server"
else
	print "LeyAC was not found on this server"
end