--[[
	EXECUTABLE_PATH/scripts/LuaShit.lua [#7993 (#8199), 1554353026, UID:3360162260]
	{W.Inc}-Santa | STEAM_0:1:69145936 <86.183.110.43:27005> | [11.05.14 04:46:44PM]
	===BadFile===
]]

/**************************************
Name: Rotater
Purpose: Makes the player 180
**************************************/

local function Rotate180()
	snow_NOAUTOPICKUP = true
	timer.Simple(0.5, function() snow_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("sh_180", Rotate180)

/**************************************
Name: Advanced Crosshair
Purpose: Displays players health when you look at them
**************************************/

 CreateClientConVar("sh_advcrosshair", 1, true, false)
CreateClientConVar("sh_advcrosshair_hitmarker", 1, true, false)
CreateClientConVar("sh_advcrosshair_info", 1, true, false)


function advcrosshair()
	if GetConVarNumber("sh_advcrosshair") == 1 then
		local x = ScrW()*.5
		local y = ScrH()*.5
			target = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and (target:IsPlayer() or target:IsNPC()) then
			crosscolor = Color(220,60,90, 150)
			surface.SetDrawColor(crosscolor)
			if GetConVarNumber("sh_advcrosshair_info") == 1 then
				draw.DrawText("Heath: "..target:Health(), "Trebuchet18", x, y +25, Color(255,255,255, 150), 1)

			end
			if GetConVarNumber("sh_advcrosshair_hitmarker") == 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) and LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					surface.SetDrawColor(255,255,255)
					surface.DrawLine(x+15, y+15, x+8, y+8)
					surface.DrawLine(x-15, y-15, x-8, y-8)
					surface.DrawLine(x-15, y+15, x-8, y+8)
					surface.DrawLine(x+15, y-15, x+8, y-8)
				end
			end

		else
			crosscolor = Color(255,255,255, 150)
		end
		
		surface.SetDrawColor(crosscolor)
		local gap = 15
		local length = gap + 10
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		surface.SetDrawColor(0, 255, 0)
		surface.DrawLine( x +2 , y, x -2, y)
		surface.DrawLine( x , y +2, x , y-2)
	end
end
hook.Add("HUDPaint", "advcrosshair", advcrosshair)

/**************************************
Name: Mirror
Purpose: Displays a mirror of what is behind you...
**************************************/

function sh_lookbehind_on( )

    hook.Add( "HUDPaint", "Mirror", function()

        local client = LocalPlayer()
        local CamData = {}
        local ang = client:EyeAngles()
        CamData.angles = Angle(0, ang.y - 180, 0)
        CamData.origin = client:GetShootPos()
        CamData.x = ScrW()/4
        CamData.y = 12
        CamData.w = ScrW()/2
        CamData.h = 250
        render.RenderView( CamData )

    end )

end

function sh_lookbehind_off( )

    hook.Remove( "HUDPaint", "Mirror" )

end

concommand.Add( "sh_lookbehind", snow_lookbehind_on )
concommand.Add( "sh_lookbehindoff", snow_lookbehind_off )

/**************************************
Name: Screen Protector
Purpose: Attempts to stop screenshots
**************************************/
_G.render.Capture = function( data )

	if ( data.format == "jpeg" ) then


		local f = file.Open( "Image.txt", "wb", "DATA" )
f:Write( data )
f:Close()

	elseif ( data.format == "png" ) then

		local f = file.Open( "Image.txt", "wb", "DATA" )
f:Write( data )
f:Close()

	end

end

/**************************************
Name: HUD
Purpose: Custom HUD
**************************************/
function siezehud()
    local client = LocalPlayer()
    if !client:Alive() then return end
    if(client:GetActiveWeapon() == NULL or client:GetActiveWeapon() == "Camera") then return end
    local mag_left = client:GetActiveWeapon():Clip1()
    local mag_extra = client:GetAmmoCount(client:GetActiveWeapon():GetPrimaryAmmoType())
    local secondary_ammo = client:GetAmmoCount(client:GetActiveWeapon():GetSecondaryAmmoType())
    MaxAmmo={}
	MaxAmmo["weapon_bugbait"]=0
	MaxAmmo["weapon_annabelle"]=2
	MaxAmmo["weapon_slam"]=0
	MaxAmmo["weapon_stunstick"]=0
    MaxAmmo["weapon_crowbar"]=0
    MaxAmmo["weapon_physcannon"]=0
    MaxAmmo["weapon_physgun"]=0
    MaxAmmo["weapon_pistol"]=18
    MaxAmmo["weapon_357"]=6
    MaxAmmo["weapon_smg1"]=45
    MaxAmmo["weapon_ar2"]=30
	MaxAmmo["weapon_shotgun"]=6
    MaxAmmo["weapon_crossbow"]=1
    MaxAmmo["weapon_frag"]=0
    MaxAmmo["weapon_rpg"]=0

local playermoney = (LocalPlayer().DarkRPVars and LocalPlayer().DarkRPVars.money) or "Not Set"
local playersalary = (LocalPlayer().DarkRPVars and LocalPlayer().DarkRPVars.salary) or "Not Set"
local playerjob = (LocalPlayer().DarkRPVars and LocalPlayer().DarkRPVars.job) or "Not Set"


    draw.RoundedBox(4, 1550, ScrH()-970, 200, 51, Color(25,  25, 25, 250))--main rounded box
	draw.RoundedBox(4, 1410, ScrH()-970, 130, 51, Color(25,  25, 25, 250))--main rounded box
    draw.SimpleText("Wallet: £ " ..playermoney.."", "Default", 1420, ScrH()-955, Color(0, 160, 214, 155), 0, 0) -- Wallet
    draw.SimpleText("Salery: £ " ..playersalary.."", "Default", 1420, ScrH()-945, Color(0, 160, 214, 155), 0, 0) -- Salery
    draw.SimpleText("Job : " ..playerjob.."", "Default", 1420, ScrH()-935, Color(0, 160, 214, 155), 0, 0) -- Job
	draw.SimpleText("   "..client:Nick() .."" , "Default",1412,ScrH()-967,Color(67, 255, 0, 150),0,0)-- your Hud text
	draw.SimpleText("ping: "..client:Ping(),"Default",1630,ScrH()-950,Color(126, 255, 0, 150),0,0)-- Ping text and value (Ping: 5)
	draw.SimpleText("ping: "..client:Ping(),"Default",1630,ScrH()-950,Color(126, 255, 0, 150),0,0)-- Ping text and value (Ping: 5)
    draw.RoundedBox(2, 1565, ScrH()-930, math.Clamp(client:Ping(),0,100)*1.8,1, Color(127, 255, 0, 150))--Ping Bar
	draw.SimpleText(os.date("Time: %I:%M:%S %p"), "Default",1560,ScrH()-965,Color(255, 0, 0, 150),0,0)-- Operating system time for ingame refference
	draw.SimpleText(os.date("%m/%d/20%y"), "Default",1670,ScrH()-965,Color(255, 0, 0, 150),0,0)-- Operating system date for ingame refference

    if mag_left <= 0 && mag_extra <= 0 then
        hasprim=0
    else
        hasprim=1
    end
    if secondary_ammo <= 0 then
        hassec=0
    else
        hassec=1
    end
    if(client:GetActiveWeapon().Primary)then
        ammobar=mag_left/client:GetActiveWeapon().Primary.ClipSize*180
    else
        ammobar=mag_left/MaxAmmo[client:GetActiveWeapon():GetClass()]*180
    end
    draw.RoundedBox(4, ScrW()-1000, ScrH()-35, 185, 10, Color(25,  25, 25, 240*hasprim))
	draw.RoundedBox(2, ScrW()-980, ScrH()-45, 125, 10, Color(25,  25, 25, 240*hasprim))
	draw.RoundedBox(4, ScrW()-1000, ScrH()-15, 185, 10, Color(25,  25, 25, 240*hassec))
    draw.RoundedBox(2, ScrW()-1200, ScrH()-24, 50, 9, Color(25,  25, 25, 240*hassec))
	draw.SimpleText("Mag: "..mag_left , "Default", ScrW()-970, ScrH()-46, Color(182, 182, 182, 145*hasprim), 0, 0)-- clip/magazine current ammount text
	draw.SimpleText("Ammo: " , "Default", ScrW()-915, ScrH()-46, Color(182, 182, 182, 145*hasprim), 0, 0)-- Ammo text
    draw.SimpleText(mag_extra , "Default", ScrW()-875, ScrH()-46, Color(182, 182, 182, 145*hasprim), 0, 0)
	draw.RoundedBox(2, ScrW()-998, ScrH()-30, ammobar, 1, Color(182, 182, 182, 145*hasprim), 0, 0)
    draw.SimpleText("Alt: "..secondary_ammo , "Default", ScrW()-1070, ScrH()-24, Color(215, 215, 215, 220*hassec), 0, 0)-- Secondary ammo text
    draw.RoundedBox(2, ScrW()-1275, ScrH()-10, math.Clamp(secondary_ammo,0,18)*10,1, Color(215, 215, 215, 145*hassec))-- Secondary ammo bar
		end
hook.Add("HUDPaint", "HUD", siezehud)


--function hidehud(name)
--    for k, v in pairs{"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo", "SHS", "SHsettings"} do
--        if name == v then return false end
--   end
--end
--hook.Add("HUDShouldDraw", "hidehud", hidehud)