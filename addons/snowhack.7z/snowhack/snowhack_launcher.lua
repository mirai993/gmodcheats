--[[
	EXECUTABLE_PATH/scripts/launcher.lua [#9690 (#9970), 1707999316, UID:3529629390]
	{W.Inc}-Santa | STEAM_0:1:69145936 <86.183.110.43:27005> | [11.05.14 04:46:47PM]
	===BadFile===
]]


-- Loading Bar
local Loadingbar = vgui.Create( "DProgress" )
Loadingbar:SetPos( 10, 30 )
Loadingbar:SetSize( 200, 20 )

timer.Create( "timer4", 0.25, 1, function()
	Loadingbar:SetFraction(0.40)
end)
timer.Create( "timer3", 0.55, 1, function()
	Loadingbar:SetFraction(0.75)
end)
timer.Create( "timer", 1.60, 1, function()
	Loadingbar:Remove()
	end)

-- Function checks for Anticheats
function ACCheck()
	-- This is where it will check for various anticheats...

if (QAC == 1) then
	AC=1
	stoprun = 0
	print "QAC Detected"
	chat.AddText( Color( 255, 0, 0 ), "QAC Detected." )
end

if (_G["LeyAC"] == true) then
	AC=1
	stoprun = 0
	print "LeyAC Detected"
	chat.AddText( Color( 255, 0, 0 ), "LeyAC Detected." )
end

end

chat.AddText( Color( 100, 50, 255 ), "--------SnowHack--------")
chat.AddText( Color( 10, 0, 255 ), "Checking For Anticheats...")
ACCheck()
if AC == 1 then
	chat.AddText( Color( 255, 0, 0 ), "An AntiCheat Was Detected!" )
end
if stoprun == 1 then
	chat.AddText( Color( 255, 0, 0 ), "Stopping!" )
	chat.AddText( Color( 100, 50, 255 ), "--------SnowHack--------")
	return false
end
chat.AddText( Color( 0, 0, 255 ), "Max Props: ", GetConVarNumber( "sbox_maxprops" ))
chat.AddText( Color( 100, 50, 255 ), "--------SnowHack--------")

-- Initial File Launching
include("LuaShit.lua")

/**************************************
Name: Clickable Interface
**************************************/

function clickable()
local clickable = vgui.Create( "DFrame" )
clickable:SetPos( 0,0 )
clickable:SetSize( 260, 260 )
clickable:SetTitle( " " )
clickable:SetVisible( true )
clickable:SetDraggable( false )
clickable:ShowCloseButton( false )
clickable:MakePopup()
clickable.Paint = function() -- To make the box invisible
Label = vgui.Create( "DLabel", clickable )
Label:SetText( "Clicking Enabled" ) -- Set Label text
Label:SizeToContents() -- Size Label aligned on into content
end

function clickableclose()
clickable:Remove()
end

concommand.Add("-mouseover", clickableclose)
end
concommand.Add("+mouseover", clickable)
/**************************************
Name: Options Tab
**************************************/
function optionstab() -- Create the function
optionstab = vgui.Create("DFrame") -- Create the frame
menu1 = vgui.Create("DButton") -- Create the button

	optionstab:SetPos(1640,395) -- set the frame's position on the screen
	optionstab:ShowCloseButton( true )
	optionstab:SetSize(128, 70) -- set the frame size
	optionstab:SetTitle( "Options" ) -- set the frame title
	optionstab:SetVisible( true ) -- Make the frame visible
	optionstab:SetSkin("Snows Skin");
	menu1:SetParent( optionstab ) -- parent the button to the frame
	menu1:SetText( "Options" ) -- set the button text
	menu1:SetPos(10, 25) -- set the button position in the frame
	menu1:SetSize( 110, 40 ) -- set the button size
	menu1.DoClick = function ( btn ) -- this will be called when the button is clicked
				local menu1 = DermaMenu() -- create a derma menu
				local gdaap = menu1:AddOption("gDaap", function() RunConsoleCommand("gdaap") end )
				gdaap:SetIcon("icon16/application_osx_terminal.png")
				local axrun = menu1:AddOption("Run AX", function() include("axprivate.lua") end )
				axrun:SetIcon("icon16/application_osx_terminal.png")
				local medic = menu1:AddOption("Medic", function() RunConsoleCommand("say", "/medic") end )
				medic:SetIcon("icon16/pill.png")
				local NetMenu = menu1:AddSubMenu ("Net Graphs")
				NetMenu:AddOption("Graph", function() RunConsoleCommand("net_graph", "1") end )
				NetMenu:AddOption("No Graph", function() RunConsoleCommand("net_graph", "2") end )
				local MenuSubMenu = menu1:AddSubMenu ("Tabs")
				MenuSubMenu:AddOption("Names", function() nametab() end )
				MenuSubMenu:AddOption("Props", function() proptab() end)
				local ropemat = menu1:AddOption("Rope Material", function() RunConsoleCommand("rope_material", "models/weapons/v_toolgun/screen") end )
				ropemat:SetIcon("icon16/wrench.png")
				local startspam = menu1:AddOption("Chat Spammer", function() spam() end)
				startspam:SetIcon("icon16/user_comment.png")
				local stopspam = menu1:AddOption("Stop Spammer", function() RunConsoleCommand("stopspam") end)
				stopspam:SetIcon("icon16/cancel.png")
				menu1:Open()
		end
end
concommand.Add("options_tab", optionstab) -- adding the console command
optionstab()
/**************************************
Name: Name Selection Tab
**************************************/
function nametab()
nametab = vgui.Create("DFrame")
menu1 = vgui.Create("DButton")

	nametab:SetPos(1620,315)
	nametab:ShowCloseButton( true )
	nametab:SetSize(150, 70)
	nametab:SetTitle( "Names" )
	nametab:SetVisible( true )
	nametab:SetSkin("Snows Skin");
	menu1:SetParent( nametab )
	menu1:SetText( "Names" )
	menu1:SetPos(10, 25)
	menu1:SetSize( 130, 40 )
	menu1.DoClick = function ( btn )
				local menu2 = DermaMenu()
				menu2:SetSkin("Snows Skin");
				menu2:AddOption("Benjamin Winston", function() RunConsoleCommand("say", "/rpname Jacob Winston") end )
				menu2:AddOption("Douglas", function() RunConsoleCommand("say", "/rpname Douglas Dooley") end )
				menu2:AddOption("Roberto", function() RunConsoleCommand("say", "/rpname Roberto Beebe") end )
				menu2:AddOption("Harvey", function() RunConsoleCommand("say", "/rpname Harvey Sweet") end )
				menu2:AddOption("Dickmunch", function() RunConsoleCommand("say", "/rpname Dr DickMunch") end )
				menu2:AddOption("Ron", function() RunConsoleCommand("say", "/rpname Ron Steele") end )
				menu2:AddOption("Jenifer", function() RunConsoleCommand("say", "/rpname Jenifer Lopez") end )
				menu2:AddOption("Michal", function() RunConsoleCommand("say", "/rpname Michal Jakson") end )
				menu2:AddOption("Jay Z", function() RunConsoleCommand("say", "/rpname Jay Z") end )
				menu2:AddOption("Jenny", function() RunConsoleCommand("say", "/rpname Jenny Penny") end )
				menu2:AddOption("Lenny", function() RunConsoleCommand("say", "/rpname Lenny Kizzi") end )
				menu2:AddOption("Amelia", function() RunConsoleCommand("say", "/rpname Amelia Chaplin") end )
				menu2:AddOption("Billy", function() RunConsoleCommand("say", "/rpname Billy Willy") end )
				menu2:AddOption("Steven", function() RunConsoleCommand("say", "/rpname Steven Hawkins") end )
				menu2:AddOption("Shawteen", function() RunConsoleCommand("say", "/rpname Shawteen McGregga") end )
				menu2:AddOption("Jopez", function() RunConsoleCommand("say", "/rpname Dr Jopez") end )
				menu2:AddOption("Josheph", function() RunConsoleCommand("say", "/rpname Joseph Mario") end )
				menu2:AddOption("Reaiel", function() RunConsoleCommand("say", "/rpname Rafiel Anglo") end )
				menu2:AddOption("Splinter", function() RunConsoleCommand("say", "/rpname Splinter Turtle") end )
				menu2:AddOption("Winkey", function() RunConsoleCommand("say", "/rpname Teletubby winkey") end )


				menu2:Open()
		end  -- ending the doclick function
end -- ending the function
concommand.Add("name_tab", nametab) -- adding the console command

/**************************************
Name: Prop Tab
**************************************/
function proptab() -- Create the function
proptab = vgui.Create("DFrame") -- Create the frame
menu1 = vgui.Create("DButton") -- Create the button


	proptab:SetPos(1620,475)
	proptab:ShowCloseButton( true )
	proptab:SetSize(150, 70)
	proptab:SetTitle( "PropTab" )
	proptab:SetVisible( true )
	proptab:SetSkin("Snows Skin");


	menu1:SetParent( proptab )
	menu1:SetText( "Props" )
	menu1:SetPos(10, 25)
	menu1:SetSize( 130, 40 )
	menu1.DoClick = function ( btn )
				local menu3 = DermaMenu()
				menu3:SetSkin("Snows Skin");
				menu3:AddOption("Canal Gate", function() SetClipboardText("bind mouse5 \"gm_spawn models/props_canal/canal_bars004.mdl\"") end)
				menu3:AddOption("BigAss Doors", function() SetClipboardText("bind mouse5 \"gm_spawn models/props/de_tides/gate_large.mdl\"") end)
				menu3:AddOption("Lockers", function() SetClipboardText("bind mouse5 \"gm_spawn models/props/de_train/lockers_long.mdl\"") end )
				menu3:AddOption("Fridge", function() SetClipboardText("bind mouse5 \"gm_spawn models/props/CS_militia/refrigerator01.mdl\"") end )
				menu3:Open()
		end
end
concommand.Add("proptab", proptab)

/**************************************
Name: Spammer
**************************************/
function spam()
	-- Create Local Table;
local SM = { };

-- Create GUI Elements;

local Panel = vgui.Create( "DFrame" )
Panel:SetPos( 250,250 )
Panel:SetSize( 500, 50 )
Panel:SetTitle( "Enter Text Below!" )
Panel:ShowCloseButton( true )
Panel:SetVisible( true )
Panel:MakePopup()
Panel:SetSkin("snowskin.lua")

local TextBox = vgui.Create( "DTextEntry", Panel )
TextBox:SetPos( 20,25 )
TextBox:SetTall( 20 )
TextBox:SetWide( 450 )
TextBox:SetEnterAllowed( true )
TextBox.OnEnter = function()

	SpamChat( TextBox:GetValue() )
    Panel:SetVisible( false )

end

-- Spam the Chat Repeatedly

function SpamChat( msg )

	timer.Create("spammer", 1, 0, function()

		RunConsoleCommand( "say", TextBox:GetValue() )

	end )

end

-- Remove Timer Command

concommand.Add( "stopspam", function()

	timer.Remove( "spammer" );

end )
end
/**************************************
Blocking Shit
**************************************/
-- Nlr Box
function Wesnlr()
	print "Hey Nigga Im digging the Nlr box, Bro"
	respawn()
end

function respawn()
	timer.Create( "timer", 0.000001, 1, function()
	RunConsoleCommand("wesspawn")
	RunConsoleCommand("wesspawn")
	end)
end

concommand.Add("wesnlr", respawn)

-- RDM manager
function RDMManager()
net.Receive("Playerdead", function(length)
return false
	end)
end
RDMManager()


-- Finishing loading bar
timer.Create( "timer2", 1.0, 1, function()
	Loadingbar:SetFraction(1)
	end)