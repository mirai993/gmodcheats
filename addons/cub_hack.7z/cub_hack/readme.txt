1. To bypass SE run config.exe
2. Then drag and drop cub_hack folder into addons once configured
3. Restart GMOD
4. Done

