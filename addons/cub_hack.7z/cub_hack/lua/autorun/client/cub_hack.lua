colors = {} -- small color table, add yours!
colors[ "red" ] = Color( 255, 0, 0, 255 )
colors[ "green" ] = Color( 0, 255, 0, 255 )
colors[ "blue" ] = Color( 0, 0, 255, 255 )

local isEnabled = true

function cub_toggle()
	isEnabled = !isEnabled
       if !isEnabled then
		for _, ply in pairs(player.GetAll()) do ply:SetMaterial("") ply:SetColor( 255, 255, 255, 255 ) end
	end
end
concommand.Add("cub_toggle", cub_toggle)


function cub_hack() -- core code

	if !isEnabled then return end

	ply = LocalPlayer() -- making things faster
	
	for k, v in pairs( player.GetAll() ) do -- getting everyone in the server
	
		if v == ply then -- if the target is ourselves
		
			-- do nothing
		
		else -- else
		
			if v:Alive() then -- check if the target is alive
			
				local vhead = v:LookupBone("ValveBiped.Bip01_Head1") -- getting the head of the player
				
				local vheadpos, vheadang = v:GetBonePosition( vhead ) -- getting its position
				
				local vscreenpos = vheadpos:ToScreen() -- converting it into vector
				
			
				
				   -- esp
				   if v:GetMoveType() != MOVETYPE_OBSERVER then 
					surface.SetTextColor ( 0, 255, 0, 255 )
					surface.SetFont("TabLarge") -- write some info
					surface.SetTextPos( vscreenpos.x, vscreenpos.y ) -- text positioning
					
					surface.SetTextColor (team.GetColor(v:Team())) surface.DrawText( v:Nick ()) -- name of player
				
					  if v:GetActiveWeapon():IsValid() then

		                surface.SetTextPos( vscreenpos.x, vscreenpos.y + 15 ) surface.SetTextColor (team.GetColor(v:Team()))  surface.DrawText(v:GetActiveWeapon( ):GetPrintName())  
				      
					  else
					  surface.SetTextPos( vscreenpos.x, vscreenpos.y + 15 ) surface.SetTextColor (team.GetColor(v:Team()))  surface.DrawText( "None" )  
				      end
					
					surface.SetFont("TabLarge") surface.SetTextColor( colors[ "green" ] ) -- font and color
					surface.SetTextPos( vscreenpos.x, vscreenpos.y + 30 ) -- HP positioning 
					surface.SetTextColor ( 255, 255, 255, 255 ) surface.DrawText( v:Health() .. " HP" ) -- his hp
					
					
					
					
					if v:IsAdmin() then -- checking if admin is admin and if not it shows nothing on the ESP

					surface.SetTextColor ( 255, 255, 255, 255 ) surface.SetTextPos( vscreenpos.x, vscreenpos.y + 45 ) surface.DrawText ("admin: ") surface.DrawText (tostring (v:IsAdmin() )) -- admin true
				    else
					surface.SetTextColor ( 255, 255 , 255 , 0 ) surface.SetTextPos( vscreenpos.x, vscreenpos.y + 45 ) surface.DrawText ("admin: ") surface.DrawText (tostring (v:IsAdmin() )) -- admin false
					end
					
					

                    
				      else
					 end
				
				   -- wallhacks
					v:SetColor( 255, 0, 0, 255 ) -- red enemy model
					v:SetMaterial( "cub_hack/esp" ) -- esp material
					
				
	
            -- other stuff : if v:Alive() and v:GetMoveType() != MOVETYPE_OBSERVER then
	              
	               
					
					
				
					
				
				
			end
			
		
		end
		
	end
	
end
hook.Add( "HUDPaint", "cub_hack", cub_hack ) -- activates the esp
