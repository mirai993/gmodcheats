--[[
	MOD/addons/SentinelHack v2.1/lua/lenny/propsurf.lua [#1884 (#1941), 2655290838, UID:2685708161]
	Devestator | STEAM_0:0:68235323 <86.25.90.82:61017> | [23.05.14 09:03:49PM]
	===BadFile===
]]

--[[
Lennys Scripts by Lenny. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("lenny_propsurf_model", "models/props_c17/gravestone002a.mdl")

local prop = GetConVarString("lenny_propsurf_model")
local lastwep = ""
local propent = Entity(-1) --No entity

local function startsurf()
	local ang = LocalPlayer():EyeAngles()
	local oriang = ang
	LocalPlayer():SetEyeAngles(Angle(30, ang.yaw+180,0))
	if LocalPlayer():GetActiveWeapon():GetClass() != "weapon_physgun" then
		lastwep = LocalPlayer():GetActiveWeapon():GetClass()
		RunConsoleCommand("use", "weapon_physgun")
	end
	timer.Simple(.1, function()
		RunConsoleCommand("+attack")
		RunConsoleCommand("gm_spawn", prop)
		timer.Simple(.1, function()
			if LocalPlayer():GetEyeTrace().Entity != Entity(0) then
				propent = LocalPlayer():GetEyeTrace().Entity
				if propent:GetCollisionGroup() == COLLISION_GROUP_WORLD then
					net.Start("properties")
						net.WriteUInt(56, 32)
						net.WriteUInt(propent:EntIndex(), 32)
					net.SendToServer()
				end
			end
			timer.Simple(.1, function()
				LocalPlayer():SetEyeAngles(oriang)
			end)
		end)
	end)
end

local function endsurf()
	hook.Remove("CreateMove", "propsurf")
	RunConsoleCommand("undo")
	RunConsoleCommand("-attack")
	if lastwep then
		timer.Simple(0.1, function() RunConsoleCommand("use", lastwep) lastwep = "" end)
	end
end

concommand.Add("+lenny_propsurf", startsurf)
concommand.Add("-lenny_propsurf", endsurf)

cvars.AddChangeCallback("lenny_propsurf_model", function() 
	prop = GetConVarString("lenny_propsurf_model")
end)


MsgC(Color(0,255,0), "\nLennys propsurf initialized!\n")