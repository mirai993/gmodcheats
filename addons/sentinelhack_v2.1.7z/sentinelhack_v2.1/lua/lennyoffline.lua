--[[
	MOD/addons/SentinelHack v2.1/lua/lennyoffline.lua [#777 (#799), 2235407646, UID:2773674963]
	Devestator | STEAM_0:0:68235323 <86.25.90.82:61017> | [23.05.14 09:03:38PM]
	===BadFile===
]]

--[[
Lennys Scripts by Lenny. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

Lenny = Lenny or {} -- ohoh global table.... watch out!!!!!

local function ReloadLennys()
	include("Lenny.lua")
end
concommand.Add("lenny_reload", ReloadLennys)

local files, folders = file.Find("lua/Lenny/*.lua", "GAME")
PrintTable(files)

local timebetweemloads = .25 -- some people crash when loading all files at once

for k, v in pairs(files) do
	timer.Simple(timebetweemloads * k, function()
		include("Lenny/" .. v)
	end)
end