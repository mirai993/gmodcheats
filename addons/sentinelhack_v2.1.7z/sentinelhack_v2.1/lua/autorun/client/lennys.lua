--[[
	MOD/addons/SentinelHack v2.1/lua/autorun/client/lennys.lua [#453 (#461), 2334050921, UID:4143126374]
	Devestator | STEAM_0:0:68235323 <86.25.90.82:61017> | [23.05.14 09:03:38PM]
	===BadFile===
]]

--[[
Lennys Scripts by Lenny. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]
CreateClientConVar("lenny_autorun", 1)
if GetConVarNumber("lenny_autorun") == 1 then
	include("Lenny.lua")
end