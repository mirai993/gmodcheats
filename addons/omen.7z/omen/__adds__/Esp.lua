--[[
	MOD/lua/Omen_Beta/__adds__/Esp.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:03PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

local y_fix = 0

function OMEN:getcoordinates( e )
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local num = 1
	local newtop, newbtm = top / num, btm / num
	
	local FRT 	= center + frt + rgt + newtop; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + newbtm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + newtop; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + newtop; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + newtop; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + newbtm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + newbtm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + newbtm; BRB = BRB:ToScreen()
	
	local maxX = self:call("math").max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = self:call("math").min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = self:call("math").max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	local minY = self:call("math").min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

function OMEN:istagged( ent )
	if ( self:call( "table" ).HasValue( self.Tags,ent:SteamID() ) ) then
		return true
	end
	return false
end

function OMEN:nick( ent,col,maxX,minY )
	local col = Color( col.r,col.g,col.b,col.a )
	if ( self.Convars[13] == "1" ) then if ( self:istraitor( ent ) ) then col = Color( 235,0,0,235 ) end end
	if ( self:istagged( ent ) ) then if ( self.flash ) then col = Color( 255 - col.r,255 - col.g,255 - col.b,235 ) end end
	self:call("draw").SimpleText( ent:IsAdmin() && "Admin: "..ent:Nick() || ent:Nick(),"DefaultSmallDropShadow", maxX + 5,minY + 5,Color( col.r,col.g,col.b,col.a ),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER )
end

function OMEN:hp( ent,maxX,minY )
	local hp = ent:Health()
	local col = Color( 255 - hp * 2.35,hp * 2.35,0,235 )
	self:call("draw").SimpleText( hp,"DefaultSmallDropShadow", maxX + 5,minY + 15,col,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER )
end

function OMEN:box( ent,col,maxX,minX,maxY,minY )	
	self:call("surface").SetDrawColor( col )
	self:call("surface").DrawLine( minX,minY,maxX,minY )
	self:call("surface").DrawLine( minX,minY,minX,maxY )
	self:call("surface").DrawLine( minX,maxY,maxX,maxY )
	self:call("surface").DrawLine( maxX,minY,maxX,maxY )		
end

function OMEN:radar( ent,col )
	local ang = ( ent:GetPos() - LocalPlayer():GetPos() ):Angle().y - LocalPlayer():EyeAngles().y + 90
	local dis = ( ent:GetPos() - LocalPlayer():GetPos() ):Length2D()	
	if ( dis <= self.Radar.radius ) then 
		local x = -self:call( "math" ).cos( self:call( "math" ).rad( ang ) ) * dis / self.Radar.scale
		local y = self:call( "math" ).sin( self:call( "math" ).rad( ang ) ) * dis / self.Radar.scale
		if ( self.Convars[13] == "1" ) then if ( self:istraitor( ent ) ) then col = Color( 235,0,0,235 ) end end
		self:call( "surface" ).SetDrawColor( col )
		self:call( "surface" ).DrawRect(  self.Radar.scrxpos - x - 2.5,self.Radar.scrypos - y - 2.5,5,5 )
	end
end

function OMEN:localplayerisvisible( ent ) // very basic...
	if ( self:visible( ent ) ) then
		local entang = ( LocalPlayer():GetPos() - ent:GetPos() ):Angle() - ent:EyeAngles()
		entang = self:normalize( entang )
		if ( self:call( "math" ).abs( entang.p ) <= 40 && self:call( "math" ).abs( entang.y ) <= 40 ) then
			return true
		end
	end
	return false
end

function OMEN:witnessfinder( ent )
	y_fix = self.Convars[11] == "1" && 120 || 0
	if ( self:localplayerisvisible( ent ) ) then
		if ( !self:call( "table" ).HasValue( self.witnesses, ent ) ) then
			self:call( "table" ).insert( self.witnesses, ent )
		end
	end
	self:call( "draw" ).SimpleText( "Witnesses: "..self:call( "tostring" )( #self.witnesses ),"Default",self.Radar.scrxpos,self.Radar.scrypos + y_fix,Color( 255,255,255,235 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
end

function OMEN:spectatorfinder( ent )
	if ( self:call( "getobservertarget" )( ent ) == LocalPlayer() ) then
		if ( !self:call( "table" ).HasValue( self.spectators, ent ) ) then
			self:call( "table" ).insert( self.spectators, ent )
		end
	end
	local y = self.Convars[12] == "1" && y_fix + 15 || y_fix
	self:call( "draw" ).SimpleText( "Spectators: "..self:call( "tostring" )( #self.spectators ),"Default",self.Radar.scrxpos,self.Radar.scrypos + y, Color( 255,255,255,235 ),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
end

function OMEN:esp()
	for k,v in pairs( self.esp_objs ) do
		if ( !v:IsValid() ) then continue end
		local scrpos = v:GetPos():ToScreen()
		local col = self:call("rawset")( self:call("team").GetColor( v:Team() ),"a",235 )
		if( scrpos.visible ) then
			// Execute Esp functions :: Make sure to fix lag issues later
			local maxX,minX,maxY,minY = self:getcoordinates( v )
			// Nick,2D Bounding Box,Hp
			if ( self.Convars[1] == "1" ) then
				self:nick( v,col,maxX,minY )
			end
			if ( self.Convars[2] == "1" ) then			
				self:hp( v,maxX,minY )
			end
			if ( self.Convars[3] == "1" ) then
				self:box( v,col,maxX,minX,maxY,minY )
			end
		end
		if ( self.Convars[11] == "1" ) then
			self:radar( v,col )
		end
		if ( self.Convars[12] == "1" ) then
			self:witnessfinder( v )
		end
		if ( self.Convars[16] == "1" ) then
			self:spectatorfinder( v )
		end
	end
end

function OMEN.hudpaint()
	OMEN:esp()
	/////////////////////////////
	if ( OMEN.Convars[11] == "1" ) then
		local wh2 = ( OMEN.Radar.radius / OMEN.Radar.scale )
		OMEN:call( "surface" ).SetDrawColor( 0,0,0,235 )
		OMEN:call( "surface" ).DrawLine( OMEN.Radar.scrxpos - wh2,OMEN.Radar.scrypos,OMEN.Radar.scrxpos + wh2,OMEN.Radar.scrypos )
		OMEN:call( "surface" ).DrawLine( OMEN.Radar.scrxpos,OMEN.Radar.scrypos - wh2,OMEN.Radar.scrxpos,OMEN.Radar.scrypos + wh2 )
		OMEN:call( "surface" ).DrawOutlinedRect( OMEN.Radar.scrxpos - wh2,OMEN.Radar.scrypos - wh2,wh2 * 2,wh2 * 2 )
	end
end

OMEN:addhook( "HUDPaint",OMEN.hudpaint )
OMEN:include( "Omen_Beta/__adds__/Misc.lua" )