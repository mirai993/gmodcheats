--[[
	MOD/lua/Omen_Beta/__adds__/Traitors.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:05PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Purpose : Predict Spread.
*/

local traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol"
}

local traitors,weps = {},{}

/* 
:
Find Traitors :
:
*/

function OMEN.Findtraitors() // =[] bugs.
	if ( !GAMEMODE ) then return end
	if ( !GAMEMODE.Name ) then return end
	if ( !OMEN:call( "string" ).match( GAMEMODE.Name , "Trouble in Terror" ) ) then return end
	if ( OMEN.Convars[13] == "1" ) then
		for k,v in ipairs( player.GetAll() ) do
			if ( OMEN:filter( v,"ttt" ) && !v:IsDetective() ) then
				for _,wep in ipairs( ents.FindByClass( "weapon_*" ) ) do 
					if ( ValidEntity( wep ) ) then
						if ( OMEN:call( "table" ).HasValue( traitorweapons,wep:GetClass() ) ) then
							if ( v:GetPos():Distance( wep:GetPos() ) <= 37 && !weps[wep] && !traitors[v] && !v:IsDetective() && GetRoundState() != 2 ) then		
								traitors[v] = true
								weps[wep] = true
								OMEN:call( "chat" ).AddText( Color( 80,80,80,235 ),"[Omen] ",Color( 255,255,255,235 ),v:Nick().." Has A Traitor Weapon, Weapon: "..wep:GetClass() )
							end
						end
					end
				end
			end
		end
		if ( GetRoundState() == 2 ) then
			traitors = {}
			weps = {}		
		end
	end
end

/* 
:
Is Traitor :
:
*/

function OMEN:istraitor(ent)
	if ( !GAMEMODE || !GAMEMODE.Name || !self:call( "string" ).find( GAMEMODE.Name , "Trouble in Terror" ) ) then return end
	if ( traitors[ent] || ent:IsActiveTraitor() ) then return true else return false end
end

/* */

OMEN:addtimer( .8,0,OMEN.Findtraitors )

OMEN:include( "Omen_Beta/__adds__/Menu.lua" )