--[[
	MOD/lua/Omen_Beta/__adds__/Misc.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:04PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

function OMEN:bunnyhop()
	if ( self.Convars[9] == "1" ) then
		if ( self:call( "input" ).IsKeyDown( KEY_SPACE ) ) then
			if ( LocalPlayer():OnGround() ) then
				self:call( "runconsolecommand" )( "+jump" )
			else
				self:call( "runconsolecommand" )( "-jump" ) 
			end
		else
			self:call( "runconsolecommand" )( "-jump" ) 
		end
	end
end

OMEN.turns = 0

function OMEN:propkill()
	if ( self.turns >= 18 ) then
		LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() - Angle( 0,180,0 ) )
		self:call( "timer" ).Simple( .1,function()
			self:call( "runconsolecommand" )( "+attack" )
			self:call( "timer" ).Simple( .1,function() self:call( "runconsolecommand" )( "-attack" ) end )
		end )
		self.turns = 0
		return
	end
	self.turns = self.turns + 1
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() - Angle( 0,10,0 ) )
	timer.Simple( .01,function() self:propkill() end )
end

function OMEN.misc()
	OMEN:bunnyhop()
	OMEN:norecoil()
end

OMEN:addtimer( .5,0,function()
	OMEN:procureobj()	
	OMEN.flash = !OMEN.flash 
	OMEN.spectators = {}
	OMEN.witnesses = {}
end )
OMEN:addhook( "Think",OMEN.misc )

OMEN:include( "Omen_Beta/__adds__/Traitors.lua" )