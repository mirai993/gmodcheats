--[[
	MOD/lua/Omen_Beta/__adds__/Aimbot.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:03PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

local shooting = false
OMEN.curtarg = nil
OMEN.ang = Angle( 0,0,0 )

function OMEN:filter( ent,typ )
	if ( !ValidEntity( ent ) || ent == nil ) then return false end
	if ( typ == "esp" ) then
		if ( ent == LocalPlayer() ) then return false
		elseif( ent:Health() < 1 ) then return false
		elseif( ent:Team() == TEAM_SPECTATOR ) then return false end
	elseif ( typ == "aimbot" ) then
		if ( self.exceptions[ent:SteamID()] ) then return false
		elseif ( ent:Health() < 1 ) then return false
		elseif ( ent == LocalPlayer() ) then return false
		elseif ( ent:Team() == TEAM_SPECTATOR ) then return false
		elseif ( OMEN.Convars[4] == "1" && ent:GetFriendStatus() == "friend" ) then return false
		elseif ( OMEN.Convars[5] == "1" && ent:Team() == LocalPlayer():Team() ) then return false
		elseif( GAMEMODE ) then 
			if( self:call( "string" ).find( GAMEMODE.Name , "Trouble in Terror" ) ) then 
				if ( ent:IsActiveTraitor() && LocalPlayer():IsActiveTraitor() ) then return false end
			end
		end
	elseif( typ == "ttt" ) then
		if ( ent:Health() < 1 ) then return false
		elseif ( ent:Team() == TEAM_SPECTATOR ) then return false end
	end
	return true
end

function OMEN:procureobj()
	self.objs = {}
	self.esp_objs = {}
	for k,v in ipairs( player.GetAll() ) do
		if ( self.aiming ) then
			if ( self:filter( v,"aimbot" ) ) then
				self:call( "table" ).insert( self.objs,v )
			end
		end
		if ( self:filter( v,"esp" ) ) then
			self:call( "table" ).insert( self.esp_objs,v )
		end
	end
end

function OMEN:getaimspot( ent )
    if ( ent:IsValid() ) then
		if ( ent:GetAttachment( ent:LookupAttachment( "eyes" ) ) != nil && ent:WaterLevel() < 1 ) then
           return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos
        end
		return ent:LocalToWorld( ent:OBBCenter() )
	else
		return Vector( 0,0,0 )
	end
end

function OMEN:visible( ent )
	local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = self:getaimspot( ent )
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ent , LocalPlayer()}
	local trace = self:call( "util" ).TraceLine( tracedata )
	if ( trace.Hit ) then return false else return true end
end

function OMEN:normalize( ang )
	ang.p = self:call( "math" ).NormalizeAngle( ang.p )
	ang.y = self:call( "math" ).NormalizeAngle( ang.y )
	ang.r = 0
	return ang
end

function OMEN:clamp( ucmd, ang )
	ang.y = self:call( "math" ).NormalizeAngle( ang.y + ( ucmd:GetMouseX() * -0.022 * 1 ) )
	ang.p = self:call( "math" ).Clamp( ang.p + ( ucmd:GetMouseY() * 0.022 * 1 ), -89, 90 )
	return ang
end

function OMEN:norecoil()
	local wep = LocalPlayer():GetActiveWeapon()
	if ( self.Convars[6] == "1" ) then
		if ( wep.Primary ) then
			if ( wep.Primary.Recoil ) then
				if ( !self.lrecoil[wep:GetModel()] ) then
					self.lrecoil[wep:GetModel()] = wep.Primary.Recoil
				end
				wep.Primary.Recoil = 0
			end
		end
	else
		if ( wep.Primary ) then
			if ( wep.Primary.Recoil ) then
				if ( wep.Primary.Recoil == 0 ) then // fix the recoil
					wep.Primary.Recoil = self.lrecoil[wep:GetModel()]
				end
			end
		end
	end
end

function OMEN:aimsystem()
	local tar,pos = {nil,0},LocalPlayer():GetShootPos()
	for k,v in ipairs( self.objs ) do
		if ( !v:IsValid() ) then continue end
		if ( !self:visible( v ) ) then continue end
		local dis = ( v:GetShootPos() - pos ):Normalize()
		dis = dis - LocalPlayer():GetAimVector()
		dis = dis:Length()
		dis = self:call( "math" ).abs( dis )
		if ( dis < tar[2] || tar[1] == nil ) then
			tar = {v,dis}				
		end
	end
	return tar[1]
end

function OMEN:triggerbot( ucmd )
	if ( self.Convars[8] == "1" ) then
		local eyetrace = LocalPlayer():GetEyeTrace()
		if ( eyetrace.Entity:IsPlayer() ) then
			if ( self:filter( eyetrace.Entity,"aimbot" ) ) then
				ucmd:SetButtons( ucmd:GetButtons() | IN_ATTACK )
				self:call( "timer" ).Simple( .1,function() self:call( "runconsolecommand" )( "-attack" ) end )
			end
		end
	end
end

function OMEN:aimbot( ucmd )
	if ( self.aiming ) then
		self.curtarg = self:aimsystem()
		if ( self.curtarg != nil ) then
			local vec = self:getaimspot( self.curtarg )
			vec = vec + ( self.curtarg:GetVelocity() / 45 ) - ( LocalPlayer():GetVelocity() / 45 ) - Vector( 0,0,tonumber( self.Convars[17] ) )
			self.ang = ( vec - LocalPlayer():GetShootPos() ):Angle()
			if ( self.Convars[7] == "1" ) then self.ang = self:PredictSpread( ucmd, self.ang ) end
			self.ang = self:normalize( self.ang )
			self.ang = self:clamp( ucmd,self.ang )
			self:call("setviewangles")( ucmd,self.ang )
			if ( self.Convars[10] == "1" ) then
				ucmd:SetButtons( ucmd:GetButtons() | IN_ATTACK )
				self:call( "timer" ).Simple( .1,function() self:call( "runconsolecommand" )( "-attack" ) end )
			end
		end
	end
end

function OMEN.CreateMove( ucmd )
	OMEN:aimbot( ucmd )
	OMEN:triggerbot( ucmd )
end

OMEN:addhook( "CreateMove",OMEN.CreateMove )

OMEN:include( "Omen_Beta/__adds__/Nospread.lua" )