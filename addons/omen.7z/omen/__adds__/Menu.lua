--[[
	MOD/lua/Omen_Beta/__adds__/Menu.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:03PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

///

local cmds = {}
cmds["var_printtable"] = function( tab )
	if ( OMEN[tab] ) then
		OMEN:call( "PrintTable" )( OMEN[tab] )
	end
end
cmds["var_print"] = function( var )
	if ( OMEN[var] ) then
		OMEN:call( "print" )( OMEN[var] )
	end
end
cmds["cvar_manip"] = function( cvar,value )
	if ( OMEN.Convars[OMEN:call( "tonumber" )( cvar )] ) then
		OMEN.Convars[OMEN:call( "tonumber" )( cvar )] = value
		OMEN:call( "print" )( "CvarChange Detected Appending Cvar File \n" )
		OMEN:appendconvars()
	else
		OMEN:call( "print" )( "Invalid Cvar INDEX" )
	end
end
cmds["bind_manip"] = function( bind,key )
	if ( OMEN.Binds[OMEN:call( "tonumber" )( bind )] && OMEN.KEYS[key] ) then
		OMEN.Binds[OMEN:call( "tonumber" )( bind )] = key
		OMEN:call( "print" )( "BindChange Detected Appending Bind File \n" )
		OMEN:appendbinds()
	else
		OMEN:call( "print" )( "Invalid Bind INDEX or KEY" )
	end
end
cmds["player_tag"] = function( steamID )
	for k,v in pairs( player.GetAll() ) do
		if ( v:SteamID() == steamID ) then
			OMEN.Tags[ v:Nick() ] = steamID
			OMEN:appendtags()
			OMEN:call( "print" )( "TagChange Detected Appending Tag File \n" )
		end
	end
end
cmds["reload"] = function( doreload )
	if ( doreload == "true" ) then
		OMEN:reload()
	end
end
cmds["exceptions"] = function( DO )
	if ( DO == "open" ) then
		OMEN:exceptionmenu()
	end
end

local cvarvalues = {}
cvarvalues[1] = "Esp_Nick"
cvarvalues[2] = "Esp_Health"
cvarvalues[3] = "Esp_Box"
cvarvalues[4] = "Ignore_SteamFriends"
cvarvalues[5] = "Ignore_Team"
cvarvalues[6] = "No_Recoil"
cvarvalues[7] = "No_Spread"
cvarvalues[8] = "Triggerbot"
cvarvalues[9] = "BunnyHop"
cvarvalues[10] = "AutoShoot"
cvarvalues[11] = "Radar"
cvarvalues[12] = "Witnesses"
cvarvalues[13] = "Traitor Check"
cvarvalues[14] = "Anti-Aim[ Removed ]"
cvarvalues[15] = "Function Logging[ Removed ]"
cvarvalues[16] = "Show Spectators"
cvarvalues[17] = "Aimbot Offset"

local bindvalues = {}
bindvalues[1] = "Menu"
bindvalues[2] = "Aimbot"
bindvalues[3] = "Propkill( TTT )"

--------------

function OMEN:menu()
	local dframe = vgui.Create( "DFrame" )
	dframe:SetSize( 350,300 )
	dframe:SetTitle( "OMEN:Developer Console" )
	dframe:Center()
	dframe:SetDraggable( true )
	dframe:ShowCloseButton( true )
	dframe:MakePopup()
	
	local dpanellist = vgui.Create( "DPanelList",dframe )
	dpanellist:SetPos( 10,25 )
	dpanellist:SetSize( 330,235 )
	dpanellist:SetSpacing( 1 )
	dpanellist:SetPadding( 20 )
	dpanellist:EnableHorizontal( false )
	dpanellist:EnableVerticalScrollbar( true )
	
	for k,v in pairs( cvarvalues ) do
		local dlabel = vgui.Create( "DLabel" )
		dlabel:SetText( "Cvar Index: "..k.." Name: "..v )
		dlabel:SetFont( "Candara" )
		dlabel:SetTextColor( Color( 50,255,255,255 ) )
		dpanellist:AddItem( dlabel )
	end
	
	for k,v in pairs( bindvalues ) do
		local dlabel = vgui.Create( "DLabel" )
		dlabel:SetText( "Bind Index: "..k.." Name: "..v )
		dlabel:SetFont( "Candara" )
		dlabel:SetTextColor( Color( 255,255,90,255 ) )
		dpanellist:AddItem( dlabel )
	end
	
	local dtextentry = vgui.Create( "DTextEntry",dframe )
	dtextentry:SetSize( 330,20 )
	dtextentry:SetPos( 10,270 )
	dtextentry:SetMultiline( false )
	dtextentry.OnEnter = function( self )
		local dlabel = vgui.Create( "DLabel" )
		dlabel:SetText( self:GetValue() )
		dlabel:SetFont( "Candara" )	
		
		// Finding cmds
		
		local explode = string.Explode( " ",self:GetValue() )
		for k,v in pairs( explode ) do
			if ( cmds[v] ) then
				local nstr,nnstr = explode[k+1],explode[k+2]
				if ( nnstr != nil ) then
					cmds[v]( nstr,nnstr )
				else
					cmds[v]( nstr )
				end
			end
		end
		
		if ( cmds[explode[1]] ) then
			dlabel:SetTextColor( Color( 0,255,0,255 ) )
		else
			dlabel:SetTextColor( Color( 255,0,0,255 ) )
		end
		dpanellist:AddItem( dlabel )
	end
end

function OMEN:exceptionmenu()
	local dframe = vgui.Create( "DFrame" )
	dframe:SetSize( 350,300 )
	dframe:SetTitle( "OMEN:Aimbot Exception Handler" )
	dframe:Center()
	dframe:SetDraggable( true )
	dframe:ShowCloseButton( true )
	dframe:MakePopup()
	
	local dlabelF = vgui.Create( "DLabel" )
	dlabelF:SetParent( dframe )
	dlabelF:SetPos( 65,25 )
	dlabelF:SetText( "Excluded" )
	dlabelF:SizeToContents()
	
	local dlabelE = vgui.Create( "DLabel" )
	dlabelE:SetParent( dframe )
	dlabelE:SetPos( 245,25 )
	dlabelE:SetText( "Inluded" )
	dlabelE:SizeToContents()

	local dpanellistF = vgui.Create( "DPanelList",dframe )
	dpanellistF:SetPos( 10,40 )
	dpanellistF:SetSize( 165,250 )
	dpanellistF:SetSpacing( 5 )
	dpanellistF:SetPadding( 1 )
	dpanellistF:EnableHorizontal( false )
	dpanellistF:EnableVerticalScrollbar( true )
	
	local dpanellistE = vgui.Create( "DPanelList",dframe )
	dpanellistE:SetPos( 180,40 )
	dpanellistE:SetSize( 165,250 )
	dpanellistE:SetSpacing( 5 )
	dpanellistE:SetPadding( 1 )
	dpanellistE:EnableHorizontal( false )
	dpanellistE:EnableVerticalScrollbar( true )
	
	function OMEN:loadincludes()
		for k,v in ipairs( player.GetAll() ) do
			if ( self.exceptions[v:SteamID()] ) then continue end
			if ( v == LocalPlayer() ) then continue end 
			local playerpanel = vgui.Create( "DPanel" )
			playerpanel:SetSize( 170,50 )
			
			local avatar = vgui.Create( "AvatarImage" )
			avatar:SetParent( playerpanel )
			avatar:SetPos( 10,5 )
			avatar:SetSize( 32,32 )
			avatar:SetPlayer( v )
			
			local name = vgui.Create( "DLabel" )
			name:SetParent( playerpanel )
			name:SetPos( 10,38 )
			name:SetText( v:IsAdmin() && "Admin: "..v:Nick() || v:Nick() )
			name:SetTextColor( Color( 0,0,0,255 ) )
			name:SizeToContents()
			
			local add = vgui.Create( "DButton" )
			add:SetParent( playerpanel)
			add:SetPos( 110,3 )
			add:SetSize( 25,15 )
			add:SetText( "Add" )
			add.DoClick = function()
				self.exceptions[v:SteamID()] = true	
				dpanellistE:Clear( true )
				dpanellistF:Clear( true )
				OMEN:loadincludes()
				OMEN:loadexcludes()
			end
			dpanellistE:AddItem( playerpanel )
		end
	end
	OMEN:loadincludes()
	
	function OMEN:loadexcludes()
		for k,v in ipairs( player.GetAll() ) do
			if ( self.exceptions[v:SteamID()] == nil ) then continue end
			if ( !self.exceptions[v:SteamID()] ) then continue end
			local playerpanel = vgui.Create( "DPanel" )
			playerpanel:SetSize( 170,50 )
			
			local avatar = vgui.Create( "AvatarImage" )
			avatar:SetParent( playerpanel )
			avatar:SetPos( 10,5 )
			avatar:SetSize( 32,32 )
			avatar:SetPlayer( v )
			
			local name = vgui.Create( "DLabel" )
			name:SetParent( playerpanel )
			name:SetPos( 10,38 )
			name:SetText( v:IsAdmin() && "Admin: "..v:Nick() || v:Nick() )
			name:SetTextColor( Color( 0,0,0,255 ) )
			name:SizeToContents()
			
			local remove = vgui.Create( "DButton" )
			remove:SetParent( playerpanel )
			remove:SetPos( 90,3 )
			remove:SetSize( 45,15 )
			remove:SetText( "Remove" )
			remove.DoClick = function()
				self.exceptions[v:SteamID()] = false
				dpanellistF:Clear( true )
				dpanellistE:Clear( true )
				OMEN:loadexcludes()
				OMEN:loadincludes()
			end
			dpanellistF:AddItem( playerpanel )
		end
	end
	OMEN:loadexcludes()
end

OMEN:include( "Omen_Beta/__core__/Cmds_convars.lua" )
