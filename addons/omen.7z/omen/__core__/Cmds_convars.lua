--[[
	MOD/lua/Omen_Beta/__core__/Cmds_convars.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:06PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

/* Concommand / ConVars */

function OMEN:updatebinds()
	local binds = self:call( "glon" ).decode( self:readfile( self.dir,"binds.txt" ) ) || {}
	for k,v in pairs( binds ) do
		self.Binds[k] = v
	end
end

function OMEN:updateconvars()
	local convars = self:call( "glon" ).decode( self:readfile( self.dir,"convars.txt" ) ) || {}
	for k,v in pairs( convars ) do
		self.Convars[k] = v
	end
end

function OMEN:updatetags()
	local tags = self:call( "glon" ).decode( self:readfile( self.dir,"tags.txt" ) ) || {}
	for k,v in pairs( tags ) do
		self.Tags[ k ] = v 
	end
end

function OMEN:appendbinds()
	self:writefile( self.dir,"binds.txt",self:call( "glon" ).encode( self.Binds ),true )
end

function OMEN:appendconvars()
	self:writefile( self.dir,"convars.txt",self:call( "glon" ).encode( self.Convars ),true )
end

function OMEN:appendtags()
	self:writefile( self.dir,"tags.txt",self:call( "glon" ).encode( self.Tags ),true )
end

function OMEN.keypressed()
	if ( OMEN:call( "input" ).IsKeyDown( OMEN.KEYS[ OMEN.Binds[1] ] ) ) then
		OMEN["menu"]()
	elseif ( OMEN:call( "input" ).IsKeyDown( OMEN.KEYS[ OMEN.Binds[2] ] ) ) then
		OMEN.aiming = true
	elseif ( OMEN:call( "input" ).IsKeyDown( OMEN.KEYS[ OMEN.Binds[3] ] ) ) then
		if ( OMEN.turns == 0 ) then
			OMEN:propkill()
		end
	else
		OMEN.aiming = false
	end
end

OMEN:updateconvars()
OMEN:updatebinds()
OMEN:updatetags()
OMEN:addtimer( .25,0,OMEN.keypressed )


OMEN:include( "Omen_Beta/__core__/Security.lua" )