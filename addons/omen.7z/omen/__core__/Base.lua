--[[
	MOD/lua/Omen_Beta/__core__/Base.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:05PM]
	===BadFile===
]]

/*
 ____                       
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
							
	Author : Wattled Walnut
	Version : 1.00 Beta
*/

local localized = {}
localized["table"] = table.Copy( table )
localized["math"] = table.Copy( math )
localized["string"] = table.Copy( string )
localized["surface"] = table.Copy( surface )
localized["draw"] = table.Copy( draw )
localized["timer"] = table.Copy( timer )
localized["chat"] = table.Copy( chat )
localized["hook"] = table.Copy( hook )
localized["input"] = table.Copy( input )
localized["team"] = table.Copy( team )
localized["file"] = table.Copy( file )
localized["util"] = table.Copy( util )
localized["os"] = table.Copy( os )
localized["gamemode"] = table.Copy( gamemode )
localized["glon"] = table.Copy( glon )
localized["debug"] = table.Copy( debug )
localized["rawset"] = rawset
localized["rawget"] = rawget
localized["require"] = require
localized["include"] = include
localized["print"] = print
localized["type"] = type
localized["runconsolecommand"] = RunConsoleCommand
localized["concommand"] = _R.Player.ConCommand
localized["tostring"] = tostring
localized["tonumber"] = tonumber
localized["PrintTable"] = PrintTable
localized["runstring"] = RunString
localized["setviewangles"] =  _R["CUserCmd"].SetViewAngles
localized["getobservertarget"] = _R["Player"].GetObserverTarget

OMEN = {
	hooks = {},
	timers = {},
	files = {},
	Tags = {},
	objs = {},
	esp_objs = {},
	witnesses = {},
	spectators = {},
	lrecoil = {},
	exceptions = {},
	badrcc = {
		"+forward",
		"-forward",
		"+right",
		"-right",
		"+left",
		"-left",
		"-voicerecord",
		"+voicerecord",
		"kill",
		"disconnect",
	},
	version = "1.01 Beta",
	aiming = false,
	dir = "_!_" ,
	flash = false,
}

OMEN.Radar = {
	radius = 1600,
	scale = 16,
	scrxpos = ScrW() - 120,
	scrypos = 120,
}

OMEN.Convars = {}
OMEN.Convars[1] = "0" // Esp_Nick
OMEN.Convars[2] = "0"	// Esp_Health
OMEN.Convars[3] = "0" // Esp_Box
OMEN.Convars[4] = "0" // Ignore SteamFriends
OMEN.Convars[5] = "0" // Ignore Team
OMEN.Convars[6] = "0" // No-Recoil
OMEN.Convars[7] = "0" // No-Spread
OMEN.Convars[8] = "0" // Triggerbot
OMEN.Convars[9] = "0" // BunnyHop
OMEN.Convars[10] = "0" // AutoShoot
OMEN.Convars[11] = "0" // Radar
OMEN.Convars[12] = "0" // Witnesses
OMEN.Convars[13] = "0" // TTT - Traitor Check
OMEN.Convars[14] = "0" // Anti-Aim [ Removed ]
OMEN.Convars[15] = "0" // Function Logging[ Removed ]
OMEN.Convars[16] = "0" // Find Spectators
OMEN.Convars[17] = "0" // Aimbot Offset

OMEN.Binds = {}
OMEN.Binds[1] = "Insert"
OMEN.Binds[2] = "Leftalt"
OMEN.Binds[3] = "G"

OMEN.KEYS = {} // Keys <-- cpt. obv
OMEN.KEYS["A"] = KEY_A
OMEN.KEYS["B"] = KEY_B
OMEN.KEYS["C"] = KEY_C
OMEN.KEYS["D"] = KEY_D
OMEN.KEYS["E"] = KEY_E
OMEN.KEYS["F"] = KEY_F
OMEN.KEYS["G"] = KEY_G
OMEN.KEYS["H"] = KEY_H
OMEN.KEYS["I"] = KEY_I
OMEN.KEYS["J"] = KEY_J
OMEN.KEYS["K"] = KEY_K
OMEN.KEYS["L"] = KEY_L
OMEN.KEYS["M"] = KEY_M
OMEN.KEYS["N"] = KEY_N
OMEN.KEYS["O"] = KEY_O
OMEN.KEYS["P"] = KEY_P
OMEN.KEYS["Q"] = KEY_Q
OMEN.KEYS["R"] = KEY_R
OMEN.KEYS["S"] = KEY_S
OMEN.KEYS["T"] = KEY_T
OMEN.KEYS["U"] = KEY_U
OMEN.KEYS["V"] = KEY_V
OMEN.KEYS["W"] = KEY_W
OMEN.KEYS["X"] = KEY_X
OMEN.KEYS["Y"] = KEY_Y
OMEN.KEYS["Z"] = KEY_Z
OMEN.KEYS["1"] = KEY_1
OMEN.KEYS["2"] = KEY_2
OMEN.KEYS["3"] = KEY_3
OMEN.KEYS["4"] = KEY_4
OMEN.KEYS["5"] = KEY_5
OMEN.KEYS["Insert"] = KEY_INSERT
OMEN.KEYS["Leftalt"] = KEY_LALT

function OMEN:log( log )
	localized[ "file" ].Append( self.dir.."/".."logs.txt","["..localized[ "os" ].date( "Month: %B Day: %d Time: %I:%M %p" ).."]".." "..log.."\n" )
end

function OMEN:call( lib )
	if ( localized[ lib ] != nil ) then
		return localized[ lib ]
	end
end

function OMEN:randstring( chars )
	local n = ""
	for i = 1,chars do
		n = n .. self:call( "string" ).char( self:call( "math" ).random( 65,91 ) )
	end
	return n
end

function OMEN:include( arg )
	self:call( "print" )( "File: "..arg.." Included \n" )
	self.files[ arg ] = " nil "
	self:call( "include" )( arg )
end

function OMEN:addhook( typ,func )
	local n = self:randstring( 26 )
	self.hooks[ typ ] = n
	self:call( "hook" ).Add( typ,n,func )
	self:call( "print" )( "Hook: "..typ.." created \n" )
end

function OMEN:addtimer( del,reps,func )
	local n = self:randstring( 28 )
	self:call( "timer" ).Create( n,del,reps,func )
	self:call( "print" )( "Timer: "..n.." created \n" )
	self.timers[ n ] = " nil "
end

function OMEN:killhook( typ )
	if ( OMEN.hooks[ typ ] != nil ) then
		self:call( "hook" ).Remove( typ,OMEN.hooks[ typ ] )
		self:call( "print" )( "Hook: "..typ.." removed \n" )
	end
end

function OMEN:killtimer( name )
	if ( OMEN.timers[ name ] != nil ) then
		self:call( "timer" ).Remove( name )
		self:call( "print" )( "Timer: "..name.." removed \n" )
	end
end

function OMEN:createdirectory( path )
	if ( !self:call("file").IsDir( path ) ) then
		self:call("file").CreateDir( path )
	end
end

function OMEN:writefile( path,fil,contents,arg )
	if ( arg ) then
		self:call("file").Write( path.."/"..fil,contents )
	else
		if ( !self:call( "file" ).Exists( path.."/"..fil ) ) then
			self:call("file").Write( path.."/"..fil,contents )
		end
	end
end

function OMEN:readfile( path,fil ) 
	if ( self:call( "file" ).Read( path.."/"..fil ) != nil ) then
		return self:call( "file" ).Read( path.."/"..fil )
	end
end

function OMEN:reload()
	for k,v in pairs( self.timers )  do
		self:killtimer( k )
	end
	for k,v in pairs( self.hooks ) do
		self:killhook( k )
	end
	self.files = {}
	self:include( "Omen_Beta/__core__/base.lua" )
	self:call( "chat" ).AddText( Color( 80,80,80,235 ),"[Omen] ","Reloaded" )
	self:log( "Omen has been reloaded by user" )
end

_G["gaysex"] = true
OMEN:call( "require" )( "mact" )
_G["gaysex"] = nil

OMEN:include( "Omen_Beta/__adds__/Aimbot.lua" )

OMEN:log( "Omen Initialized!" )