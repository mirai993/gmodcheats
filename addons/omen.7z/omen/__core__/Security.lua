--[[
	MOD/lua/Omen_Beta/__core__/Security.lua
	[Nyx]Boxedin123 | STEAM_0:0:21500578 <68.227.30.11:27005> | [26-10-13 09:36:22PM]
	===BadFile===
]]

/*
 ____                      
|  _  |                     
| | | |_ __ ___   ___ _ __  
| | | | '_ ` _ \ / _ \ '_ \ 
\ \_/ / | | | | |  __/ | | |
 \___/|_| |_| |_|\___|_| |_|
                         
	Author : Wattled Walnut
	Purpose : Self Explanitory
*/
// 

local OMENC = table.Copy( OMEN )

file.Find = function( path,usebasefolder )
	usebasefolder = usebasefolder || false
	path = OMENC:call("string").lower( path )
	if ( OMENC:call("string").match( path,"omen" ) || OMENC:call("string").match( path,"_!_" ) ) then
		OMENC:log( "file.find blocked" )
		return {" ","  ","   "}
	end
end

file.Read = function( path,usebasefolder )
	usebasefolder = usebasefolder || false
	path = OMENC:call("string").lower( path )
	if ( OMENC:call("string").match( path,"omen" ) || OMENC:call("string").match( path,"_!_" ) ) then
		OMENC:log( "file.Read blocked" )
		return nil
	end
	return OMENC:call("file").Read( path,usebasefolder )
end

file.Exists = function( path,usebasefolder )
	usebasefolder = usebasefolder || false
	path = OMENC:call("string").lower( path )
	if ( OMENC:call("string").match( path,"omen" ) || OMENC:call("string").match( path,"_!_" ) ) then
		OMENC:log( "file.Exists blocked" )
		return false
	end
	return 	OMENC:call("file").Exists( path,usebasefolder )
end

file.ExistsEx = function( path,addons )
	addons = addons || false
	path = OMENC:call("string").lower( path )
	if ( OMENC:call("string").match( path,"omen" ) || OMENC:call("string").match( path,"_!_" ) ) then
		OMENC:log( "file.ExistsEx blocked" )
		return false
	end
	return OMENC:call("file").ExistsEx( path,addons )
end

file.FindInLua = function( path )
	path = OMENC:call("string").lower( path )
	if ( OMENC:call("string").match( path,"omen" ) || string.match( path,"_!_" ) ) then
		OMENC:log( "file.FindInLua blocked" )
		return {}
	end
	return OMENC:call("file").FindInLua( path )
end

file.TFind = function( path,callback )
	OMENC:log( "file.TFind blocked" )
	callback( path,{},{} )
end

RunConsoleCommand = function( ... )
	if ( type( ... ) == "table" ) then
		local args = unpack( ... )
		for k,v in pairs( args ) do
			if ( OMENC:call( "table" ).HasValue( OMENC.badrcc,v ) ) then OMENC:log( "Bad RCC blocked" ) return end
		end
		OMENC:call( "runconsolecommand" )( args )
	else
		if ( OMENC:call( "table" ).HasValue( OMENC.badrcc,... ) ) then OMENC:log( "Bad RCC blocked" ) return end
		OMENC:call( "runconsolecommand" )( ... )
	end
end

/* 
:
Hide OMEN:
:
*/

local function Callpath( info )
	if ( !info ) then return true end
	if ( info && OMENC:call( "string" ).find( info.short_src, "omen_beta" ) ) then
		return true
	end
	return false
end

local function Protect()
	_G["OMEN"] = nil // Delete Omen from Global table

	setmetatable( _G,
		{
			__index = function( t, k )
				if( k == "OMEN" ) then
					if( Callpath( OMENC:call( "debug" ).getinfo( 2, "S" ) ) ) then
						return OMENC
					end
				end
				return OMENC:call( "rawget" )( t, k )
			end,
			
			__newindex = function( t, k, v )
				if( k == "OMEN" ) then
					if ( !Callpath( OMENC:call( "debug" ).getinfo( 2, "S" ) ) ) then
						return
					end
				end
				return OMENC:call( "rawset" )( t, k, v )
			end,
			
			__metatable = true,
		}
	)
end
Protect()

if ( OMENC:call( "table" ).HasValue( _G,OMEN ) ) then
	OMENC:call( "chat" ).AddText( Color( 80,80,80,150 ),"[Omen] ",Color( 255,255,255,150 ),">>> FAILED to load Omen:Security <<<" )
else
	OMENC:call( "chat" ).AddText( Color( 80,80,80,150 ),"[Omen] ",Color( 255,255,255,150 ),">>> Omen:Security loaded <<<" )
	OMENC:call( "chat" ).AddText( Color( 80,80,80,150 ),"[Omen] ",Color( 255,255,255,150 )," Version: "..OMENC.version.." Loaded!" )
end