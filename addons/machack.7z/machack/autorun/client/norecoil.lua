--[[
	autorun/client/norecoil(2).lua
	-[LCG]- Marvincmarvin™
	===DStream===
]]

local function norecoil()
	local ply = LocalPlayer()
	if GetViewEntity() != ply then return end
	if( ValidEntity( ply:GetActiveWeapon() ) && ply:GetActiveWeapon().Primary ) then
        ply:GetActiveWeapon().Primary.Recoil = 0
		ply:GetActiveWeapon().Primary.Cone = 0
		ply:GetActiveWeapon().Primary.Damage = 999
	end
end
concommand.Add("recoil",norecoil)
