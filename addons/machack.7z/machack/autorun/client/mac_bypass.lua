--[[
	autorun/client/mac_bypass.lua
	-[LCG]- Marvincmarvin™
	===DStream===
]]

openscript=arg[1]
nameofscript=arg[2]
command=arg[3]
value=arg[4]
runbypass="1"
--my way to make text in the middle in console
function print2(text,r,g,b)
   text_len=string.len(text)
   print(string.rep(" ", 40-math.ceil(text_len/2))..text.."\n",r,g,b)
end
function scripthelp()
   cmd("clear")
   runbypass="0"
   wait(50)
   print("\n",0,0,0)
   print2("Help and info about:",0,0,0)
   print2(nameofscript,0,0,0)
   print("\n\n",0,0,0)
   print2("About:",0,0,0)
   print("\n\n",0,0,0)
   print2("This script is a simple bypass",0,0,0)
   print2("script written in OBLSS a.k.a lua",0,0,0)
   print2("",0,0,0)
   print("\n\n",0,0,0)
   print2("Usage:",0,0,0)
   print2(openscript.." "..nameofscript.." 'command' 'value'",0,0,0)
   print2("",0,0,0)
   print("\n\n",0,0,0)
   print2("Notice:",0,0,0)
   print("\n\n",0,0,0)
   print2("1:",0,0,0)
   print("\n",0,0,0)
   print2("You cant use this",0,0,0)
   print2("for name change..",0,0,0)
   print("\n\n",0,0,0)
   print2("2:",0,0,0)
   print("\n",0,0,0)
   print2("You will be KAC Banned if",0,0,0)
   print2("you use this as sv_cheats",0,0,0)
   print2("bypasser (or other cheats)",0,0,0)
   print("\n\n",0,0,0)
   print2("3:",0,0,0)
   print("\n",0,0,0)
   print2("Enjoy!",0,0,0)
   print2("and please dont abuse this!",0,0,0)
   print("\n\n",0,0,0)
end
if value==nil then
   if command=="help" then scripthelp() else print2("Type a command and a value!",0,0,0) runbypass="0" end
end
if runbypass=="1" then
   setCVar(command, value)
   wait(500)
   check=getCVar(command)
   print2("The cvar - "..command.." - is now set to "..check,0,0,0)
if check==value then print2("Successful!",0,0,0) else print2("Sorry, it didnt work!",0,0,0) end
end