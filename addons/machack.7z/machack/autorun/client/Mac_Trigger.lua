--[[
	autorun/client/Mac_Trigger.lua
	-[LCG]- Marvincmarvin™
	===DStream===
]]

local TriggerBot = CreateClientConVar( "triggerbot_enabled", 0, true, false )
 
hook.Add( "Think", "Triggerbot", check())

function check()
    local Target = LocalPlayer():GetEyeTrace().Entity 
        if TriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() or Target:IsNPC() ) then
            if !Firing then
                RunConsoleCommand( "+attack" )
                LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( CurTime() + 0.01 )
                Firing = true
            else 
                RunConsoleCommand( "-attack" ) 
                Firing = false
            end
        end
    end
end

