--[[
	autorun/client/mac_menus.lua
	-[LCG]- Marvincmarvin™
	===DStream===
]]

--__________________________________________--
--| M     M     A        cCCCCc 		   |--
--| M M M M    A A     Cc                  |--
--| M  M  M   A   A   Cc				   |--
--| M     M  AaaaaaA   Cc     			   |--
--| M     M A       A   cCCCCCc   hack v1.0|--
--__________________________________________--
//--//--//--//--//--//--//--//--//--//
--| Made by: -[LCG]- Marvincmarvin |--
//--//--//--//--//--//--//--//--//--//
--| Don't give away this code we   |--
--| the less people that have it   |--
--| the less chances of lua anti   |--
--| cheats detecting this !!! Also |--
--| I'm not good at sharing :3     |--
//--//--//--//--//--//--//--//--//--//

function create()

	local DPanel1 = vgui.Create('DPanel')
	DPanel1:SetSize(294, 344)
	DPanel1:Center()
	DPanel1.Visible(0)
	
	local DLabel2 = vgui.Create('DLabel')
	DLabel2.SetParent(DPanel1)
	DLabel2:SetPos(180, 150)
	DLabel2:SetText('MAC Hack v1.0')
	DLabel2:SizeToContents()

	local DSysButton1 = vgui.Create('DSysButton')
	DSysButton1:SetParent(DPanel1)
	DSysButton1:SetSize(25, 25)
	DSysButton1:SetPos(257, 12)
	DSysButton1:SetType('close')
	DSysButton1.DoClick = function() 
							DPanel1.Visible(0) 
						end

	local DSysButton4 = vgui.Create('DSysButton')
	DSysButton4:SetParent(DPanel1)
	DSysButton4:SetSize(25, 25)
	DSysButton4:SetPos(227, 12)
	DSysButton4:SetType('question')
	DSysButton4.DoClick = function() 
							RunConsoleCommand("2a1f3e4r5678j9r9w8j7d54k6r2a84")
						end

	local DLabel1 = vgui.Create('DLabel')
	DLabel1:SetParent(DPanel1)
	DLabel1:SetPos(127, 332)
	DLabel1:SetText('made by: -[LCG]- Marvincmarvin')
	DLabel1:SizeToContents()

	local DImage1 = vgui.Create('DImage')
	DImage1:SetParent(DPanel1)
	DImage1:SetSize(50, 50)
	DImage1:SetPos(7, 12)
	DImage1:SetImage('mac/maclogo1')
	DImage1:SizeToContents()
	
end

function open()
	create()
end

concommand.Add("open_menu",open())
