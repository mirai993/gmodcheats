--[[
	autorun/client/mac_menu.lua
	-[LCG]- Marvincmarvin™
	===DStream===
]]


function create()

local DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(420, 420)
DFrame1:Center()
DFrame1:SetTitle('MAC hack v1.0')
DFrame1:SetSizable(true)
DFrame1:SetDeleteOnClose(false)
DFrame1:MakePopup()
DFrame1:SetVisible( true )

local PropertySheet = vgui.Create( "DPropertySheet")
PropertySheet:SetParent(DFrame1)
PropertySheet:SetSize(400, 370)
PropertySheet:SetPos(10, 29)

local DPanel1 = vgui.Create('DPanel')
DPanel1:SetVisible( true )

DCheckBox3 = vgui.Create('DCheckBoxLabel')
DCheckBox3:SetParent(DPanel1)
DCheckBox3:SetPos(9, 151)
DCheckBox3:SetText('Player Esp O\I')
DCheckBox3:SetTextColor(Color(10,10,10,255))
DCheckBox3.DoClick = function() end
DCheckBox3:SizeToContents()

DCheckBox2 = vgui.Create('DCheckBoxLabel')
DCheckBox2:SetParent(DPanel1)
DCheckBox2:SetPos(9, 111)
DCheckBox2:SetText('HUD Chams O\I')
DCheckBox2:SetTextColor(Color(10,10,10,255))
DCheckBox2.DoClick = function() end
DCheckBox2:SizeToContents()

DCheckBox1 = vgui.Create('DCheckBoxLabel')
DCheckBox1:SetParent(DPanel1)
DCheckBox1:SetPos(9, 71)
DCheckBox1:SetText('Crosshairs O\I')
DCheckBox1:SetTextColor(Color(10,10,10,255))
DCheckBox1.DoClick = function() end
DCheckBox1:SizeToContents()

DLabel2 = vgui.Create('DLabel')
DLabel2:SetParent(DPanel1)
DLabel2:SetPos(248, 36)
DLabel2:SetText('Esp Type')
DLabel2:SetTextColor(Color(10,10,10,255))
DLabel2:SizeToContents()

DComboBox1 = vgui.Create('DComboBox')
DComboBox1:SetParent(DPanel1)
DComboBox1:SetSize(200, 150)
DComboBox1:SetPos(178, 56)
--DComboBox1:SetTextColor(Color(10,10,10,255))
DComboBox1:EnableVerticalScrollbar(true)
DComboBox1.OnMousePressed = function() end
DComboBox1:SetMultiple(false)
DComboBox1:AddItem( "Full ESP" )
DComboBox1:AddItem( "Players' Name" )
DComboBox1:AddItem( "Players' Health" )
DComboBox1:AddItem( "Players' Model" )
DComboBox1:AddItem( "Box ESP" )
DComboBox1:AddItem( "Players' Head Position" )

DLabel3 = vgui.Create('DLabel')
DLabel3:SetParent(DPanel1)
DLabel3:SetPos(38, 36)
DLabel3:SetText('Esp Settings')
DLabel3:SetTextColor(Color(10,10,10,255))
DLabel3:SizeToContents()

DCheckBox4 = vgui.Create('DCheckBoxLabel')
DCheckBox4:SetParent(DPanel1)
DCheckBox4:SetPos(9, 191)
DCheckBox4:SetText('Check Admins O\I')
DCheckBox4:SetTextColor(Color(10,10,10,255))
DCheckBox4.DoClick = function() end
DCheckBox4:SizeToContents()

local DPanel2 = vgui.Create('DPanel')
DPanel2:SetVisible( true )

DCheckBox9 = vgui.Create('DCheckBoxLabel')
DCheckBox9:SetParent(DPanel2)
DCheckBox9:SetPos(10, 150)
DCheckBox9:SetTextColor(Color(10,10,10,255))
DCheckBox9:SetText('Norecoil O\I')
DCheckBox9.DoClick = function() end
DCheckBox9:SizeToContents()

DCheckBox8 = vgui.Create('DCheckBoxLabel')
DCheckBox8:SetParent(DPanel2)
DCheckBox8:SetPos(10, 110)
DCheckBox8:SetTextColor(Color(10,10,10,255))
DCheckBox8:SetText('Aim on fire O\I')
DCheckBox8.DoClick = function() end
DCheckBox8:SizeToContents()

DCheckBox7 = vgui.Create('DCheckBoxLabel')
DCheckBox7:SetParent(DPanel2)
DCheckBox7:SetPos(10, 70)
DCheckBox7:SetTextColor(Color(10,10,10,255))
DCheckBox7:SetText('Autoaim O\I')
DCheckBox7.DoClick = function() end
DCheckBox7:SizeToContents()

DLabel5 = vgui.Create('DLabel')
DLabel5:SetParent(DPanel2)
DLabel5:SetPos(240, 40)
DLabel5:SetText('Aimbone')
DLabel5:SetTextColor(Color(10,10,10,255))
DLabel5:SizeToContents()

DComboBox2 = vgui.Create('DComboBox')
DComboBox2:SetParent(DPanel2)
DComboBox2:SetSize(200, 150)
DComboBox2:SetPos(170, 70)
DComboBox2:SetPos(170, 70)
DComboBox2:EnableVerticalScrollbar(true)
DComboBox2.OnMousePressed = function() end
DComboBox2:SetMultiple(false)

DLabel4 = vgui.Create('DLabel')
DLabel4:SetParent(DPanel2)
DLabel4:SetPos(20, 40)
--DLabel4:SetTextColor(Color(10,10,10,255))
DLabel4:SetText('Aimbot Settings')
DLabel4:SizeToContents()

DCheckBox10 = vgui.Create('DCheckBoxLabel')
DCheckBox10:SetParent(DPanel2)
DCheckBox10:SetPos(10, 190)
DCheckBox10:SetTextColor(Color(10,10,10,255))
DCheckBox10:SetText('Nospread O\I -NOT WORKING YET')
DCheckBox10.DoClick = function() end
DCheckBox10:SizeToContents()

DCheckBox11 = vgui.Create('DCheckBoxLabel')
DCheckBox11:SetParent(DPanel2)
DCheckBox11:SetPos(10, 230)
DCheckBox11:SetTextColor(Color(10,10,10,255))
DCheckBox11:SetText('Exclude Admins O\I')
DCheckBox11.DoClick = function() end
DCheckBox11:SizeToContents()

--\\--//--\\--//--\\--//--\\--//--\\
DLabel1 = vgui.Create('DLabel')
DLabel1:SetParent(DFrame1)
DLabel1:SetPos(264, 406)
DLabel1:SetText('made by:-[LCG]-Marvincmarvin')
DLabel1:SizeToContents()
--\\--//--\\--//--\\--//--\\--//--\\

PropertySheet:AddSheet( "ESP Settings", DPanel1, "gui/silkicons/user", false, false, "ESP Settings" )
PropertySheet:AddSheet( "Aimbot Settings", DPanel2, "gui/silkicons/group", false, false, "Aimbot Settings" )

end

concommand.Add("open_mac_menu",create)
concommand.Run("open_mac_menu2")

function hide()
DFrame1.SetVisible( false )
end

--if GetConVarNumber("mac_hack") == 1 then
concommand.Add("close_mac_menu",hide)
--end
