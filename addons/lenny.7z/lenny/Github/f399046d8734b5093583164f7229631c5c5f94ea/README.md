Lennys
======

New collection of all the scripts I made.
License of usage: https://rawgithub.com/LennyPenny/Lennys/master/license.html
