--[[
	EXECUTABLE_PATH/readme.txt
	Ƹ̵̡Ӝ̵̨̄Ʒ | (STEAM_0:1:53737976) | [21-07-13 10:20:09PM]
	===BadFile===
]]

Hello!  Valkyrie is currently in beta, and not everything is done.

Since I haven't made any sort of way to autoupdate the dll, poke me on
steam for the newest version every so often

Becasue Windows is retarded, I can't create files here until I find a workaround.
You can find all files in your garry'smod folder.  The valkyrie folder is located in
the same place as hl2.exe (steam/steamapps/%yourusername%/garrysmod/)

