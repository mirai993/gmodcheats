Placing scripts in this folder will cause them to automatically run when you join a server

Note, that scripts run here have load priority, and are run before the lua libraries are made
.available.  You'regoing to have to manually include lua libraries required to use functions
in scripts ran here (see lua/includes/init.lua for examples)

