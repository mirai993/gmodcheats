Placing lua modules in this folder will cause them to load automatically when you join a server

