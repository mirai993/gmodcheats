Placing scripts in this folder will cause them to automatically run when you join a server
The scripts in here do not have access to gamemode content right away, so make sure to nil check
any content that will be included by the gamemode

