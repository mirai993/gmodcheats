**THIS FEATURE DOES NOT WORK RIGHT NOW**


Placing scripts in this folder will cause them to automatically run when you join a server

Note, that scripts run here have load priority, and are run first.  You're
going to have to manually include lua libraries required to use functions in scripts ran here

