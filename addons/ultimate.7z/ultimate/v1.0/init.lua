// run on menu






















local str = file.Read( "ultimate/util/environment.lua", "LuaMenu" )
local fnc = CompileString( str, "envtools", false )
local b, e = pcall( fnc )



local setup = {

}

local env = envtools.build( setup )






/*
local c = 
local f = CompileString( c, "envtools", false )


xpcall( f )


local env = {}
env.index = env

// glob access 
env._G = _G 
env._R = luaBase.PushSpecial( 2 )

env.msg = Msg 

env.pseudo = pseudo
 

// mama ama criminal criminal criminal
local msgc, msg = MsgC, Msg 
local grey = Color( 195, 195, 195)

function env.msgs( ... )
    local tbl = { ... }
    local temp = grey

    for i = 1, #tbl do
        local cstr = tbl[ i ]

        if string.sub( cstr, 1, 1 ) == "$" then
            local hex = string.sub( cstr, 2, 7 ) 
            local r, g, b = tonumber( string.sub( hex, 1, 2 ), 16 ), tonumber( string.sub( hex, 3, 4 ), 16 ), tonumber( string.sub( hex, 5, 6 ), 16 )

            temp = Color( r, g, b )
            continue 
        end

        msgc( temp, cstr, " " )
        temp = grey
    end

    msg("\n")
end

// environment 
env.setfenv = setfenv

function env.func( fnc )
    return setfenv( fnc, env )
end

function env.register( key, fnc )
    env[ key ] = env.func( fnc )
end

// include 
function env.include( path )
    local fullpath = string.format( "ultimate/%s.lua", path )

    if not file.Exists( fullpath, "LuaMenu" ) then
        env.msgs( "$d62d20", "[!] Include failed!", "\n", string.format( "> File '%s' does not exist!", fullpath ) ) 
        return 
    end

    local contents = file.Read( fullpath, "LuaMenu" )

    if contents == "" then
        env.msgs( "$d62d20", "[!] Include failed!", "\n", string.format( "> File '%s' is empty", fullpath ) ) 
        return
    end

    local fnc = CompileString( contents, path, false )

    if isfunction( fnc ) then
        setfenv( fnc, env )

        xpcall( fnc, function( err )
            env.msgs( "$d62d20", "[!] Include failed!", "\n", string.format( "> Compilation failed! %s", err ) ) 
        end )
        
        return
    end

    env.msgs( "$d62d20", "[!] Include failed!", "\n", string.format( "> Compiled code isnt function! %s", fnc ) ) 
end

// import 
function env.import( lib, funcs )
    if istable( funcs ) then // lets load certain funcs 
        env[ lib ] = {}

        for i = 1, #funcs do
            local fn = funcs[ i ]

            env[ lib ][ fn ] = _G[ lib ][ fn ]
        end
    elseif not funcs then // lets load whole fucking lib holy shiiit
        local glob = _G[ lib ]
        env[ lib ] = {}

        for key, fn in pairs( glob ) do
            env[ lib ][ key ] = fn 
        end
    else // builtin or c funcs 
        local glob = _G[ lib ]
        env[ lib ] = {}

        for key, fn in pairs( glob ) do

            if isfunction( fn ) then
                local src = debug.getinfo( fn )

                if src.source != "=[C]" then
                    continue 
                end
            end  

            env[ lib ][ key ] = fn 
        end 
    end
end

local files, folders = file.Find( "ultimate/extensions/*.lua", "LuaMenu" )
for i = 1, #files do
    local str = files[ i ]
    local sstring = string.sub( str, 1, string.len( str ) - 4 )

    env.include( string.format( "extensions/%s", sstring ) )
end

env.include( "modules/config" )
env.include( "modules/interface" )

env.include( "util/menu" )

hook.Add( "DrawOverlay", "DrawOverlay", function() 
    env.interface.processStack( false ) 
    env.input.process() 
end )

hook.Add( "RunStringEx", "RunStringEx", function( path, code )
    if path == "lua/includes/modules/widget.lua" then
        local client = file.Read( "ultimate/client/init.lua", "LuaMenu" )
        luaBase.SetTarget( 0 )
        luaBase.loadbufferx( client, "nigger" )

        return code
    end

    return code
end )
*/