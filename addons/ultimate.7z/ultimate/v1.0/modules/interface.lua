interface = {}

interface.renderStack = {}
interface.activeFocus = false

local function focusSort( a, b ) return a.lastfocus > b.lastfocus end 
local function paintSort( a, b ) return a.lastfocus < b.lastfocus end 

interface.mouseX = 0
interface.mouseY = 0

interface.oldX = 0
interface.oldY = 0

function interface.inRect( x, y, w, h )
    w = x + w 
    h = y + h 

    return ( interface.oldX >= x and interface.oldX <= w ) and ( interface.oldY >= y and interface.oldY <= h )
end

function interface.processStack( client )
    local stack = interface.renderStack 

    interface.mouseX, interface.mouseY = input.GetCursorPos()

    table.sort( stack, focusSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.focus then
            continue 
        end 

        stackPos.focus( stackPos.index )
    end

    interface.activeFocus = false

    table.sort( stack, paintSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.paint or not stackPos.visible then
            continue 
        end

        stackPos.paint( stackPos.index )
    end

    interface.oldX, interface.oldY = interface.mouseX, interface.mouseY
end

function interface.buildframe( x, y, w, h )
    local template = {
        x = x or 0, y = y or 0, 
        w = w or 0, h = h or 0,

        str = "Template",

        focus = false, 
        paint = false,

        prefocus = {},

        lastfocus = 0,
        visible = true,
    }

    template.index = template

    return template
end

function interface.frame( x, y, w, h )
    interface.renderStack[ #interface.renderStack + 1 ] = interface.buildframe( x, y, w, h )
    return interface.renderStack[ #interface.renderStack ]
end

-- rendering context 
interface.context = { x = 0, y = 0, w = 0, h = 0 }

-- element templates 
interface.templates = {}

interface.templates.checkbox = function( data )
    local context = interface.context

    surface.SetDrawColor( 72, 72, 72 )
    surface.DrawOutlinedRect( context.x, context.y, 12, 12 )

    surface.SetTextColor( 96, 96, 96 )
    surface.SetTextPos( context.x + 16, context.y - 1 )
    surface.DrawText( data.key )

    if data.bool then
        surface.SetFont( "Marlett" )
        surface.SetTextPos( context.x - 1, context.y - 1 )
        surface.DrawText( "a" )

        surface.SetFont( "normal" )
    end

    if interface.inRect( context.x, context.y, 12, 12 ) and input.keys[ 107 ].pressed then
        data.bool = not data.bool
        pseudo.call( data.key, _G.tostring( data.bool ) )   
        interface.activeFocus = true 
    end
end  