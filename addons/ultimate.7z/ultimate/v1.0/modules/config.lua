settings = {
    ["Bounding box"] = { template = "checkbox", bool = false, str = "Outlines player collision box" },
    ["Player names"] = { template = "checkbox", bool = false, str = "Player name" },
}

for key, val in _G.pairs( settings ) do
    val.key = key
end