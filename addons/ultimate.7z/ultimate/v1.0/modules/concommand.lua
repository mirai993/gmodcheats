consolecommand = {}

consolecommand.list = {}

function consolecommand.list()

end

function consolecommand.add( str, fnc, help, flags )
    consolecommand.list[ str ] = { fn = fnc, str = help, flags = flags }
    AddConsoleCommand( str, help, flags )
end

// detour 
local oRun = concommand.Run
function concommand.Run( ... )

end