// Construct menu layout 
local showMenu = false

// Setting up material
local gradient = _G.Material( "gui/gradient_down" )
local gradient_up = _G.Material( "gui/gradient_up" )
local gradient_l = _G.Material( "vgui/gradient-l" )

// Frame control panel
local commandPanel = interface.frame( 0, 0, scrw, 24 )
local commands = { "Configuration", "Session", "Activity", "Editor" }
local strCmds = {}
 
surface.SetFont( "outlined" )

local x = 0
for i = 1, #commands do
    local str = commands[ i ]
    local tw, th = surface.GetTextSize( str )

    local tbl = {
        str = str,
        width = tw + 32,
        visible = false,
    }

    tbl.x = x
    tbl.pad = x + math.floor( tbl.width / 2 - tw / 2 )
    x = x + tbl.width

    commands[ i ] = tbl 
    strCmds[ str ] = i
end

function commandPanel.paint( self )
    local x, y, w, h = self.x, self.y, self.w, self.h

    surface.SetDrawColor( 16, 16, 16 )
    surface.DrawRect( x, y, w, h )

    surface.SetDrawColor( 32, 32, 32 )
    surface.SetMaterial( gradient )
    surface.DrawTexturedRect( x, y, w, h )

    surface.SetFont( "outlined" )

    for i = 1, #commands do
        local cmd = commands[ i ]

        if interface.inRect( cmd.x, 0, cmd.width, 24 ) and input.keys[ 107 ].pressed then
            cmd.visible = not cmd.visible
            interface.activeFocus = true
        end

        if cmd.visible then
            surface.SetDrawColor( 48, 48, 48 )
            surface.SetMaterial( gradient_up )
            surface.DrawTexturedRect( cmd.x, y, cmd.width, h )

            surface.SetTextColor( 232, 232, 232 )
        else
            surface.SetTextColor( 156, 156, 156 )
        end

        surface.SetTextPos( cmd.pad, 5 )
        surface.DrawText( cmd.str )
    end

    surface.SetDrawColor( 72, 72, 72 )
    surface.DrawRect( x, h, w, 1 )

    surface.SetTextColor( 156, 156, 156 )
    surface.SetTextPos( w - 122, 5 )
    surface.DrawText( "powered by sublime" )
end

// Configuration frame 
local configPanel = interface.frame( 16, 40, 512, 640 )

local configTabs = { "Combat", "Rage", "Visuals", "Render", "Misc", "Settings" }
local configTab = 1

for i = 1, #configTabs do
    local str = configTabs[ i ]
    local w, h = surface.GetTextSize( str )

    configTabs[ i ] = {
        str = str,
        x = math.floor( 84 / 2 - w / 2 ),
        y = math.floor( 12 - h / 2 )
    }
end

local configLayout = {
    {
        {
            str = "container #1",
            items = { "Bounding box", "Player names", "Player names" }
        },
        {
            str = "container #2",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        {
            str = "container #3",
            items = { "Player names" }
        },
        
    },
    {},
    {},
    {},
    {},
    {},
}

function configPanel.paint( self )
    local x, y, w, h = self.x, self.y, self.w, self.h

    surface.SetDrawColor( 16, 16, 16 )
    surface.DrawRect( x, y, w, h )

    surface.SetDrawColor( 48, 48, 48 )
    surface.DrawOutlinedRect( x, y, w, h, 4 )
    surface.DrawRect( x, y, w, 26 )

    surface.SetDrawColor( 64, 64, 64 )
    surface.SetMaterial( gradient )
    surface.DrawTexturedRect( x, y, w, 26 )

    surface.SetFont( "normal" )

    surface.SetTextColor( 164, 164, 172 )
    surface.SetTextPos( x + 6, y + 6 )
    surface.DrawText( "Configuration" )

    local aX = x + 4 
    for i = 1, #configTabs do
        local tab = configTabs[ i ] 
        local cur = configTab == i

        surface.SetDrawColor( 64, 64, 64 )
        surface.SetMaterial( cur and gradient_up or gradient )
        surface.DrawTexturedRect( aX, y + 27, 84, 24 )

        local clr = cur and 164 or 128 
        surface.SetTextColor( clr, clr, clr )
        surface.SetTextPos( aX + tab.x, y + 27 + tab.y )
        surface.DrawText( tab.str )

        if interface.inRect( aX, y + 27, 84, 24 ) and input.keys[ 107 ].pressed then
            configTab = i
            interface.activeFocus = true 
        end

        aX = aX + 84
    end

    surface.SetDrawColor( 72, 72, 72 )
    surface.DrawOutlinedRect( x, y, w, h )
    surface.DrawOutlinedRect( x + 4, y + 26, w - 8, h - 30 )
    surface.DrawRect( x + 4, y + 50, w - 8, 1 )

    surface.SetFont( "normal" )
    surface.SetTextColor( 196, 196, 196 )

    local current = configLayout[ configTab ]

    local cC = 1
    local cY = { y + 56, y + 56 }

    for i = 1, #current do
        local conteiner = current[ i ]
        local cX = x + ( cC == 1 and 10 or 259 )
        local cH = #conteiner.items * 14 + 22

        surface.SetDrawColor( 24, 24, 24 )
        surface.DrawRect( cX, cY[cC], 244, cH )

        surface.SetDrawColor( 48, 48, 48 )
        surface.SetMaterial( gradient_l )
        surface.DrawTexturedRect(cX, cY[cC], 244, 18 )

        surface.SetDrawColor( 72, 72, 72 )
        surface.DrawOutlinedRect( cX, cY[cC], 244, cH )

        surface.SetTextColor( 96, 96, 96 )
        surface.SetTextPos( cX + 4, cY[cC] + 2 )
        surface.DrawText( conteiner.str )

        surface.DrawRect( cX, cY[cC] + 18, 244, 1 )

        local iX, iY = cX + 3, cY[cC] + 21
        for item = 1, #conteiner.items do
            local data = settings[ conteiner.items[ item ] ] 
            local context = interface.context

            context.x = iX
            context.y = iY

            interface.templates[ data.template ]( data )

            iY = iY + 14
        end 

        cY[cC] = cY[cC] + cH + 6
        cC = ( cC == 1 and 2 ) or 1 
    end
end

function configPanel.focus( self )
    self.visible = commandPanel.visible and commands[ strCmds[ "Configuration" ] ].visible 

    if interface.inRect( self.x, self.y, self.w, self.h ) and input.keys[ 107 ].down and not interface.activeFocus then
        self.x = self.x + ( interface.mouseX - interface.oldX )
        self.y = self.y + ( interface.mouseY - interface.oldY )
    end 
end

// Editor panel
local editorPanel = interface.frame( 548, 40, 720, 480 )

function editorPanel.paint( self )
    local x, y, w, h = self.x, self.y, self.w, self.h

    surface.SetDrawColor( 16, 16, 16 )
    surface.DrawRect( x, y, w, h )

    surface.SetDrawColor( 48, 48, 48 )
    surface.DrawOutlinedRect( x, y, w, h, 4 )
    surface.DrawRect( x, y, w, 26 )

    surface.SetDrawColor( 64, 64, 64 )
    surface.SetMaterial( gradient )
    surface.DrawTexturedRect( x, y, w, 26 )

    surface.SetFont( "normal" )

    surface.SetTextColor( 164, 164, 172 )
    surface.SetTextPos( x + 6, y + 6 )
    surface.DrawText( "Editor" )


    surface.SetDrawColor( 72, 72, 72 )
    surface.DrawOutlinedRect( x, y, w, h )
    surface.DrawOutlinedRect( x + 4, y + 26, w - 8, h - 30 )
    surface.DrawRect( x + 4, y + 50, w - 8, 1 )
end

function editorPanel.focus( self )
    self.visible = commandPanel.visible and commands[ strCmds[ "Editor" ] ].visible 

    if interface.inRect( self.x, self.y, self.w, self.h ) and input.keys[ 107 ].down and not interface.activeFocus then
        self.x = self.x + ( interface.mouseX - interface.oldX )
        self.y = self.y + ( interface.mouseY - interface.oldY )
    end 
end

// Key listener 
input.listen( 73, function() 
    commandPanel.visible = not commandPanel.visible
end )

