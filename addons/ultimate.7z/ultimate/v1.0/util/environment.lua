envtools = {}

local fnSwitch = {
    [""] = function( env, var )

    end,
}

function envtools.build( data )
    local env = {}
    env.index = env 

    env._G = _G 
    env._R = _R

    for key, tbl in pairs( data ) do
        fnSwitch[ key ]( env, tbl )
    end

    return env 
end

