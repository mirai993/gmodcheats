detour = {}

detour.original = {}

function detour.func( original, override )
    detour.original[ override ] = original
    original = override
end