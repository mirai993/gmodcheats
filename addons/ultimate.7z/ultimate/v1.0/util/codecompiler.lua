codecompiler = {}

function codecompiler.CompileFile( path )
    if not file.Exists( string.format( "ultimate/%s.lua", path ), "LuaMenu" )
end