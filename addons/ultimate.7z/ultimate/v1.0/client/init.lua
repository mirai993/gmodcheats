local settings = {}
settings[ "Player names" ] = false

print( sublime )

sublime.pseudo.init( function( str, var ) 
    print("pseudo called")
    print( "Set " .. str .. " to " .. var )
    settings[ "Player names" ] = not settings[ "Player names" ]
end )
 
local function DrawShit()
    if settings[ "Player names" ] then
        for _, ent in ipairs( player.GetAll() ) do

            local point = ent:GetPos() + ent:OBBCenter() 
            local data2D = point:ToScreen() 
    
            if ( not data2D.visible ) then continue end
    
            surface.SetTextColor( 255, 255, 255 )
            surface.SetFont( "BudgetLabel" )
            surface.SetTextPos( data2D.x, data2D.y )
            surface.DrawText( ent:Name() )
        end
    end
end

hook.Add( "PreViewRender", "DrawShit", DrawShit )