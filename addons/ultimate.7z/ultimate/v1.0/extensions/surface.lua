import( "surface", true )

local fonts = {
    ["outlined"] = {
        font = "Verdana", 
        extended = true,
        size = 13,
        weight = 500,
        antialias = false,
        outline = true,
    },
    ["normal"] = {
        font = "Verdana", 
        extended = true,
        size = 13,
        weight = 500,
        antialias = false,
    }
}
 
for key, val in _G.pairs( fonts ) do
    surface.CreateFont( key, val )
end