import( "string", true )

local jPat = { 
    ["\\"] = "\\\\", 
    ["\0"] = "\\x00", 
    ["\b"] = "\\b",
	["\t"] = "\\t",
	["\n"] = "\\n",
	["\v"] = "\\v",
	["\f"] = "\\f",
	["\r"] = "\\r",
	["\""] = "\\\"",
	["\'"] = "\\\'",
	["`"] = "\\`",
	["$"] = "\\$",
	["{"] = "\\{",
	["}"] = "\\}"
}
 
function string.jss( str )
	str = string.gsub( str, ".", jPat )
	str = string.gsub( str, "\226\128\168", "\\\226\128\168" )
	str = string.gsub( str, "\226\128\169", "\\\226\128\169" )

	return str
end

function string.start( str, start )
    return string.sub( str, 1, string.len( start ) ) == start
end

function string.random( len )
    local res = {}

    for i = 1, len do
        result[ i ] = string.char( math.random( 32, 126 ) )
    end

    return table.concat( result )
end

function string.table( str )
    local tbl = {}

    for i = 1, #str do
        tbl[ i ] = string.sub( str, i, i )
    end

    return tbl
end

scrw = _G.ScrW()
scrh = _G.ScrH()