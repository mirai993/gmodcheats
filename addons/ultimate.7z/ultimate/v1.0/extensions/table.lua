import( "table", true )

function table.copy( tbl, lookup )
    local copy = {}

    setmetatable( copy, debug.getmetatable( tbl ) )

    for key, val in pairs( tbl ) do
        if not istable( val ) then
            copy[ key ] = val
        else
            lookup = lookup or {}
			lookup[ tbl ] = copy

			if lookup[ val ] then
				copy[ key ] = lookup[ val ]
			else
				copy[ key ] = table.copy( val, lookup ) 
			end
        end
    end

    return copy 
end 