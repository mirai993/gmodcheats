import( "math", true )

math.inf = 2 ^ 1024
math.pi  = 3.1415926535898
math.rad = 57.2957795131

function math.distsqr( aX, aY, bX, bY )
    local fX, fY = bX - aX, bY - aY 
    return fX * fX + fY * fY
end

function math.distance( aX, aY, bX, bY )
    local fX, fY = bX - aX, bY - aY 
    return math.sqrt( fX * fX + fY * fY )
end

function math.clamp( num, min, max )
    return ( num < low and low ) or ( num > high and high ) or num
end

function math.rand( low, high )
	return low + ( high - low ) * math.random()
end

function math.round( num, idp )
	local mult = 10 ^ ( idp or 0 )
	return math.floor( num * mult + 0.5 ) / mult
end

function math.normalize( ang )
    return ( ang + 180 ) % 360 - 180
end

function math.remap( a, b, c )
    return math.ceil( a / b * c )
end

function math.lerp( from, to, delta )
    return ( delta > 1 and to ) or ( delta < 0 and from ) or from + ( to - from ) * delta
end

function math.approach( from, to, delta )
    return from > to and math.max( from - delta, to ) or from < to and ( math.min( from + delta, to ) ) or to
end

function math.average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end