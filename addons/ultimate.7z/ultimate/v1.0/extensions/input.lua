import( "input", true )

function input.IsDown( key )
    if key > 106 then
        return _G.input.IsMouseDown( key )
    end

    return _G.input.IsKeyDown( key )
end

input.keys = {}
for key = 1, 113 do
    input.keys[ key ] = { down = false, pressed = false, released = false, listener = false }
end

input.mouse = { x = 0, y = 0, deltaX = 0, deltaY = 0, savedX = 0, savedY = 0 }

function input.mouseInRect( x, y, w, h )
    local mx, my = input.mouse.x, input.mouse.y

    w = x + w 
    h = y + h 

    return mx >= x and mx <= w and my >= y and my <= h 
end

function input.saveMousePos()
    input.mouse.savedX = input.mouse.x
    input.mouse.savedY = input.mouse.y
end

function input.restoreMousePos()
    _G.input.SetCursorPos( input.mouse.savedX, input.mouse.savedY )
end

function input.isBindDown( key )
    local lookup = _G.input.LookupBinding( key )

    if not lookup then 
        return false 
    end 

    return _G.input.IsKeyDown( _G.input.GetKeyCode( lookup( key ) ) ) 
end

function input.listen( key, fnc )
    input.keys[ key ].listener = fnc
end

function input.process()
    local data = input.mouse    

    local mx, my = _G.input.GetCursorPos()
    data.deltaX, data.deltaY = mx - data.x, my - data.y
    data.x, data.y = mx, my

    for key = 1, 113 do
        data = input.keys[ key ]

        data.down = input.IsDown( key )
        data.pressed = data.down and not data.released
        data.released = data.down

        if data.listener and data.pressed then       
            data.listener()
        end
    end
end