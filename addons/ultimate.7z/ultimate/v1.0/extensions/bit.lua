import( "bit", true )

function bit.bmask( bnum, mask )
    return bit.band( bnum, mask ) == mask 
end

function bit.gbnot( bnum, mask )
    return bit.band( bnum, bit.bnot( mask ) )
end

function bit.gbor( bnum, mask )
    return bit.bor( bnum, mask )
end