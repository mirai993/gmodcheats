import( "hook", true )

hook.list = {}

function hook.attach( event, func )
    hook.list[ event ] = func
    hook.Add( event, string.format( "hk.%s", event ), func )
end