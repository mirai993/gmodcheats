envtools = {}

function envtools.import( env, ... )
    local glob = env._G 

    local tbl = { ... }
    for 
end

















envtools.list = {}

local fnSwitch = {
    ["import"] = function( value, env )

    end,
    ["include"] = function( value, env )

    end
}

function envtools.build( data )
    local env = {}

    env.index = env 

    env._G = _G 
    env._R = _R 

    for key, value in pairs( data ) do
        fnSwitch[ key ]( value, env )
    end
    
    return env 
end


















envtools.index = envtools