interface = { focus = false }

// interface stack 
interface.stack = {}

local function normalSort( a, b )
    return a.lastThink > b.lastThink 
end

local function invertedSort( a, b )
    return a.lastThink < b.lastThink 
end

// processing context 
interface.context = { x = 0, y = 0, w = 0, h = 0, index = 0 }

// interface panel 
function interface.construct( x, y, w, h )
    local struct = {
        x = x or 0, y = y or 0, 
        w = w or 0, h = h or 0,

        think   = false,
        paint   = false,
        visible = true,

        lastThink = 0,
    }

    struct.self = struct

    return struct 
end

function interface.push( x, y, w, h )
    interface.stack[ #interface.stack + 1 ] = interface.construct( x, y, w, h )
    return interface.stack[ #interface.stack ]
end

// interface input
uinput = {
    cursorX = 0,    cursorXp = 0,
    cursorY = 0,    cursorYp = 0,
}

function uinput.inRect( x, y, w, h )
    return uinput.cursorXp >= x  
        and uinput.cursorXp <= x + w  
        and uinput.cursorYp >= y  
        and uinput.cursorYp <= y + h
end

// stack processing 

function interface.process()
    local stack = interface.stack 

    uinput.cursorX, uinput.cursorY = input.GetCursorPos()

    table.sort( stack, focusSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.think then
            continue 
        end 

        stackPos.think( stackPos.self )
    end

    interface.focus = false

    table.sort( stack, paintSort )
    for pos = 1, #stack do
        local stackPos = stack[ pos ]

        if not stackPos.paint or not stackPos.visible then
            continue 
        end

        stackPos.paint( stackPos.self )
    end

    uinput.cursorXp, uinput.cursorYp = uinput.cursorX, uinput.cursorY
end
















