










detour = { 
    vardata = {},
    fn = {}
}



// Extra copy 
local _tostring = tostring
local _getinfo  = debug.getinfo

function detour.store( key, fnc, orig )
    detour.vardata[ key ] = {
        call = orig,
        str = _tostring( orig ),
        info = _getinfo( orig ),
    }

    detour.fn[ fnc ] = detour.vardata[ key ]
end

// Override
local G = table.Copy( _G )

function tostring( any )
    local ret = detour.fn[ any ] and detour.fn[ any ].str or detour.vardata[ "tostring" ].call( any )
    return ret
end 

detour.store( "tostring", tostring, G.tostring ) 

function debug.getinfo( stack, fields, func )
    local ret = detour.fn[ stack ] and detour.fn[ stack ].info or detour.vardata[ "debug.getinfo" ].call( stack )
    return ret  
end

detour.store( "debug.getinfo", debug.getinfo, G.debug.getinfo ) 