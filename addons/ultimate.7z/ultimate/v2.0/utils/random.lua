random = {}
random.uniform = {

    author = "Serejaga",
    about = "Made for easy code compilation.",

    concommands = {
        cmd = function() end
    },
}