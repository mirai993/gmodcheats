/*
     ██████   ██████  ██████  ███    ███ ██████  ██ ██      ███████ 
    ██    ██ ██      ██    ██ ████  ████ ██   ██ ██ ██      ██      
    ██    ██ ██      ██    ██ ██ ████ ██ ██████  ██ ██      █████   
    ██ ▄▄ ██ ██      ██    ██ ██  ██  ██ ██      ██ ██      ██      
     ██████   ██████  ██████  ██      ██ ██      ██ ███████ ███████ by replica
        ▀▀                                                            
*/

qCompile = {}

// List all compilation tasks 
qCompile.task = {}

// CompileString handler 
local strCompileString = "qCompile.task #%i"

function qCompile.CompileString( str )
    local lastTask = #qCompile.task 
    local identifier = string.format( strCompileString, lastTask )

    return CompileString( str, identifier, false )
end

// pcall handler, function execution
function qCompile.CallFunction( func, env )
    setfenv( func, env )

    return pcall( func )
end

// Error string table
local fail = {
    exist = "[qCompile] File '%s' not found. Compilation aborted!",
    read = "[qCompile] Cant read file '%s'. Compilation aborted!",
    compile = "[qCompile] Cant compile '%s', ERROR: '%s'. Compilation failed!",
}

// RunString func 
function qCompile.RunString( str, env )
    -- check for environment table 
    env = env or 1 

    if isnumber( env ) then
        env = getfenv( env )
    end

    -- compile damn string
    local cRet = qCompile.CompileString( str )

    -- succeded
    if isfunction( cRet ) then
        local succ, err = qCompile.CallFunction( cRet, env )

        return succ, err
    end

    -- failed 
    return false, cRet 
end

// RunFile func 
local gamePath = IsInGame() and "lcl" or "LuaMenu"

function qCompile.RunFile( filePath, env )
    -- check for environment table 
    env = env or 1 

    if isnumber( env ) then
        env = getfenv( env )
    end

    -- validate file 
    local fExists = file.Exists( filePath, gamePath )

    if not fExists then
        local str = string.format( fail.exist, filePath )
        Msg( str )

        return false
    end

    -- read file contents 
    local fRead = file.Read( filePath, gamePath )

    if string.len( fRead ) == 0 then
        local str = string.format( fail.exist, filePath )
        Msg( str )

        return false
    end

    -- compile and run string 
    local succ, err = qCompile.RunString( fRead, env )
 
    if not succ then
        local str = string.format( fail.compile, filePath, err )
        Msg( str )

        return false
    end

    return true
end

// Uniform module
local uniform = {
    sRun        = "[qCompile] Running module '%s' ( %s ) with following uniform info: \n",
    sLine       = "> %s: %s \n",
    sSubLine    = "\t > %s: %s \n",

    funcs = {
        
    }
}






function qCompile.Module( moduleName, filePath, env )
    local str = string.format( strmodule, moduleName, filePath )

    qCompile.RunFile( filePath, env )

    -- check for uniform 
    local fmodule = _G[ moduleName ] or false

    if fmodule and fmodule.uniform then
        local str = string.format( strmodule, moduleName, filePath )
        Msg( str )

        for key, value in pairs( fmodule.uniform ) do
            str = string.format( unipattern, key, value )
            Msg( str )

            if not istable( value ) then
                continue 
            end
                
            for subKey, subValue in pairs( value ) do
                str = string.format( utpattern, subKey, subValue )
                Msg( str )  
            end
        end
    end
end

// follow uniform rules :D
qCompile.uniform = {
    author = "Serejaga",
    about = "Made for easy code compilation.",

    concommands = {
        qc_compile = { fn = function() end, help = "nope :D" },

    }, 
}

