cprint = {}

// needed locals 
local MsgC      = MsgC 
local Msg       = Msg 
local tostring  = tostring 
local type      = type 

// Message color support, i use Color( 255, ... ) cuz ill dont ever trust rubat again :skull:
local palette = palette or {}
palette.white = palette.white or Color( 255, 255, 255 ) 

local msgcol  = palette.white

































// Staged variable processing: 
// 1. Check if variable isnt string and start processing, store pre-processed variable data.
// 2. Process data, store additional information.
// 3. All informatino processed, push it back to user.
local stages = { pre = {}, proc = {}, post = {} }















// IN stack is being used to store per arg variables
// OUT stack is going to be used after all args processed
local mIn   = {}
local mOut  = {}

// Var arg wasnt string so we need to process without loosing data
local mTypeCase = {}

// Table variable passed, store its addr and information
mTypeCase["table"] = function( var, i )
    mIn[ #mIn + 1 ] = var 

    // parse table
    local outTable = {}
    local keysCount = 0

    for k, v in pairs( var ) do
        outTable[ #outTable + 1 ] = v
        keysCount = keysCount + 1

        if keysCount > 5 then
            break 
        end
    end

    mOut[ #mOut + 1 ] = outTable

    return true 
end

// Post-processing passed or processed variables
local inTypeCase = {}



// print function 
function cprint.out( ... )
    local out = { ... }

    mIn     = {}
    mOut    = {}

    for i = 1, #out do
        local var = out[ i ]

        local t = type( var )
        if mTypeCase[ t ] and mTypeCase[ t ]( var, i ) then
            msgcol = palette.white
            continue 
        end

        MsgC( msgcol,  )
    end
end