-- Menu made by Bmthrules
-- Delete this file if you want to remove the menu

 

function ShowInvisible (Panel)
Panel:AddControl("Label", {Text = "Show invisible props"})
Panel:AddControl("Button", {Label = "On/Off", Text = "...", Command = "showinvis"})
Panel:AddControl("Label", {Text = "Color of the invisible props"})
Panel:AddControl( "Color", {
	Label = "Color",
	Red = "showinvis_red",
	Green = "showinvis_green",
	Blue = "showinvis_blue",
	Alpha = "showinvis_alpha",
	ShowAlpha = "1",
	ShowHSV = "0",
	ShowRGB = "1",
	Multiplier = "255"} )
Panel:AddControl("Label", {Text = "(Changes will apply on press of 'On/Off' button."})
Panel:AddControl("Label", {Text = "Default value is color(255, 255, 255, 180) )"})
end 

function GhostControlmenu()

spawnmenu.AddToolMenuOption( "[GzF]Hacks", "[GzF]SeeAll by Bmthrules", "Show Invisible", "#Show Invisible", "", "", ShowInvisible )
end
hook.Add("PopulateToolMenu", "PopulateToolMenu", GhostControlmenu)