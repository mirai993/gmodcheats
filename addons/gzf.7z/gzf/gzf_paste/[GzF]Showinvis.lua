--[[
	autorun/client/[GzF]Showinvis.lua
	bhop| kenny
	===DStream===
]]

--[[

Type showinvis into the console and all invisible props will be revealed with slight transparency.

Every 5 seconds it will look for more invisible props and will reveal them too.

Type showinvis again to turn it off.

]]

if(!CLIENT) then return end

ShowInvisLoaded = true;
ShowColor = Color(255,255,255,180);
showinvis_red = 255;
showinvis_green = 255;
showinvis_blue = 255;
showinvis_alpha = 180;

local clprops = {}
local showing = false
local showinvisred = CreateClientConVar( "showinvis_red", tostring(ShowColor.r), true, false );
local showinvisgreen = CreateClientConVar( "showinvis_green", tostring(ShowColor.g), true, false );
local showinvisblue = CreateClientConVar( "showinvis_blue", tostring(ShowColor.b), true, false );
local showinvisalpha = CreateClientConVar( "showinvis_alpha", tostring(ShowColor.a), true, false );

ShowColor = Color(GetConVarNumber("showinvis_red"),GetConVarNumber("showinvis_green"),GetConVarNumber("showinvis_blue"),GetConVarNumber("showinvis_alpha"))

local function bettercount(tab)
	count = 0
	for k, v in pairs(tab) do
		count = count + 1
	end
	return count
end
local function getalpha(ent)
	if(!ent or !ent:IsValid()) then return end
	_, _, _, alpha = ent:GetColor()
	return alpha
end

local function showprops(pl, cmd, args)
	if(showing) then
		for k, v in pairs(clprops) do
			v[1]:Remove()
		end
		clprops = {} 
		
		GAMEMODE:AddNotify("Hidden props again", NOTIFY_GENERIC, 3)
		print("Hidden props again")
		
		showing = false
		return
	end
	
	findhidden()
	
	GAMEMODE:AddNotify("Found "..bettercount(clprops).." invisible props", NOTIFY_GENERIC, 3)
	print("Found "..bettercount(clprops).." invisible props. Will now check every 5 seconds")
	
	showing = true
end
concommand.Add("showinvis", showprops)

function findhidden()

	for i=1,1000 do
	
		local ent = ents.GetByIndex(i)
		local ID = ent:EntIndex()
		if(!clprops[ID] and ent and ent:IsValid() and ent != LocalPlayer()) then
		
			if(getalpha(ent) < 10) then
			
				local newent = ents.Create("prop_physics")
				if(newent and newent:IsValid() and ent:GetModel()) then
				
					newent:SetModel(ent:GetModel())
					newent:SetPos(ent:GetPos())
					newent:SetAngles(ent:GetAngles())
					newent:SetColor(GetConVarNumber("showinvis_red"),GetConVarNumber("showinvis_green"),GetConVarNumber("showinvis_blue"),GetConVarNumber("showinvis_alpha"))
					
					AddWorldTip(ID, "Invisible", 3, newent:GetPos(), newent)
					
					clprops[ID] = {newent, ent}
				
				end
			end
		end
		
		if(!ent) then break end
		
	end
	
end

local nextupdate = 0
local function updateprops()
	if(!showing) then return end
	
	-- Every 5 seconds
	if(CurTime() > nextupdate) then
	
		findhidden()
		nextupdate = CurTime()+5
		
	end
	
	-- Always
	for k, v in pairs(clprops) do
	
		if(v[2]:IsValid() and getalpha(v[2]) < 10) then		-- Might have deleted prop
		
			v[1]:SetPos(v[2]:GetPos())
			v[1]:SetAngles(v[2]:GetAngles())
			
			if(getalpha(v[2]) == 0 and LocalPlayer():GetEyeTrace().Entity == v[2] and EyePos():Distance(v[2]:GetPos() ) < 512 ) then
			
				if(v[2].GetOverlayText and v[2]:GetOverlayText() != "") then
				
					AddWorldTip(v[2]:EntIndex(), v[2]:GetOverlayText(), 0.5, v[2]:GetPos(), v[1])
					
				end
			end
			
		else
		
			v[1]:Remove()
			clprops[k] = nil
			
		end
	end
end
hook.Add("HUDPaint", "updateprops", updateprops)