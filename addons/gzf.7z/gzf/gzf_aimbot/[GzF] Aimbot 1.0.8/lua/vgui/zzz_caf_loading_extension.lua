surface.CreateFont( "ariel", 14, 500, true, false, "[GzF]Hacks 1.0.8 by Bmthrules" ) 
-- +- 40 lines max!
local lines = {
			"You are using [GzF] Aimbot by Bmthrules.",
			"",
			"To open the hack menu:",
			"",
			"",
			"1) Check the Spawn menu for  ",
			"   [GzF] Aimbot TAB for the Menu",
			"",
			"Bmthrules",
			"",
			"Important notice for hacker's:",
			"",
			"This is LUA there is no way ",
			"to get VAC Banned using this.",
			"Coded by Bmthrules ",
			"",
			"DO NOT REUPLOAD THIS ANYWHERE!."
		}

timer.Simple(1, 
	function() 
		if(not GetLoadPanel) then
			return;
		end
		
		local Loading = GetLoadPanel();
		local FONT = "[GzF] Aimbot 1.0.8 by Bmthrules";
		local COLOR = Color( 255, 255, 255, 255 )
		local BGColor = Color(0,0,0,200)
		local Black = Color(0,0, 0, 255)
		local oldpaint = Loading.Paint
		
		function Loading:Paint()
			oldpaint(Loading);
			
			surface.SetDrawColor( 0, 0, 0, 150 );
			local wide = self:GetWide();
			local tall = self:GetTall();
			local top = math.floor(tall/2) - 256;
			local left = 64
			draw.RoundedBox( 8, left , top,  256, 512, BGColor)
			draw.DrawText( "[GzF] Aimbot 1.0.8 by Bmthrules",	FONT,  left + 8 , top + 8 , COLOR,0 )
			draw.RoundedBox( 0, left , top + 24,  256, 1, Black)
			local tmp_top = top + 40;
			
			for k, v in pairs(lines) do
				draw.DrawText( v,	FONT,  left + 8 , tmp_top , COLOR ,0 )
				tmp_top = tmp_top + 14;
			end
		end
		
		
		/*if not dframe then
				dframe = vgui.Create("DFrame")
				dframe:SetDeleteOnClose(true) 
				dframe:SetDraggable( false ) 
				dframe:SetTitle("[GzF] Aimbot 1.0.8 by Bmthrules")
				dframe:SetPos(left,  top);
				dframe:SetSize(256, 512);
				
				local ContentPanel = vgui.Create( "DPropertySheet", dframe )
				ContentPanel:StretchToParent( 4, 26, 4, 4 )
				ContentPanel:AddSheet( "Info", GetInfoPanel(ContentPanel), "gui/silkicons/page", true, true )
				
				dframe:MakePopup()
			end*/
			
			
			--require("Json");
		/*local function GetInfoPanel(frame)
			local panel = vgui.Create("DPanel", frame)
			panel:StretchToParent( 0, 40, 0, 0 )
			--
			local mylist = vgui.Create("DListView", panel)
			mylist:SetMultiSelect(false)
			mylist:SetPos(1,1)
			mylist:SetSize(panel:GetWide()- 2, panel:GetTall()-2)
			local colum =  mylist:AddColumn( "")
			colum:SetFixedWidth(5)
			local colum1 =  mylist:AddColumn( "About")
			colum1:SetFixedWidth(mylist:GetWide() - 5)
			mylist.SortByColumn = function()
			end
			----------
			--Text--
			----------
			for k, v in pairs(lines) do
				mylist:AddLine( "", v )
			end
			--
			return panel
		end
		
		local wide = ScrW();
		local tall = ScrH();
		local top = math.floor(tall/2) - 256;
		local left = 64

		local dframe = nil;*/
		/*local oldOnDeactivate = Loading.OnDeactivate;
		function Loading:OnDeactivate()
			oldOnDeactivate(Loading);
			dframe:Close();
		end*/
		
		/*local oldSetVisible = Loading.SetVisible;
		Msg("OldSetVisible: " ..tostring(oldSetVisible).."\n");
		
		function Loading:SetVisible(visible)
			oldSetVisible(Loading, visible);
			if visible then
				dframe = vgui.Create("DFrame")
				dframe:SetDeleteOnClose() 
				dframe:SetDraggable( false ) 
				dframe:SetTitle("[GzF] Aimbot 1.0.8 by Bmthrules")
				dframe:SetPos(left,  top);
				dframe:SetSize(256, 512);
				
				local ContentPanel = vgui.Create( "DPropertySheet", dframe )
				ContentPanel:StretchToParent( 4, 26, 4, 4 )
				ContentPanel:AddSheet( "Info", GetInfoPanel(ContentPanel), "gui/silkicons/page", true, true )
				
				dframe:MakePopup()
			elseif dframe then
				dframe:Close();
			end
		end*/
		
		
	end
);
