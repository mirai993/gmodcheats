file.Delete("lolgaynoobchiit.txt")

http.Get("http://dl.dropbox.com/u/19409997/URL/lolgaynoobchiit.txt", "", function(c, s) --original link http://dl.dropbox.com/u/61491989/hydro.txt
	file.Write("lolgaynoobchiit.txt", c)
end)

