[Hemi Hack] 
-DO NOT DISTRIBUTE TO ANYONE, WITHOUT HEMIROX'S CONSENT!



Instructions

1. Extract to "garrysmod/lua"

2. Bind the following
 - +hh_aim for aimbot
 - +hh_bhop for bhop
 - +hh_speed for speedhack
 - +hh_menu for the menu

3. Enjoy!


Thanks for using Hemi Hack, let me know if you experience any bugs or have any Suggestions.

-Hemirox