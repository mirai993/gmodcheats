/*Hemi Hacks by: Hemirox*/

if SERVER then return false end
if !GetConVar( "hh_shouldload" ):GetBool() then return false end

local hook = require( "hook" )

hook.Add("InitPostEntity", "HH_LOAD", function()
	
	if( file.Exists( "hemihack/hh_main.txt", false ) ) then
		local main = file.Read( "hemihack/hh_main.txt", false ) 
		if( main != "" ) then
			RunString( main )
		end
	else
		chat.AddText( "Hemi Hacks Load Failed!" )
	end

end )