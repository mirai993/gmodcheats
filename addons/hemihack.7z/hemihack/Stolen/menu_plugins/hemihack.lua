//Hemi Hack By: Hemirox

require("hh")

hook.Add("SEIsActive", "SEIsActive", function()	
	return false
end)

hook.Add("ScriptAllowed", "ScriptAllowed", function(path,lua,size)	
	return true
end)

http.Get( "http://unleashedservers.com/hemiroxsfiles/hemihacks/main.txt" , ""  , function(c,s)
	file.Write( "hemihack/hh_main.txt", c )
end )

local cvars = require ( "cvars" )
local shouldload = CreateClientConVar( "hh_shouldload", "1", true, false )

local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( ScrW() - 200, ScrH() / 2 )
DermaPanel:SetSize( 150, 60 )
DermaPanel:SetTitle( "" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( false )
DermaPanel:ShowCloseButton( false )
DermaPanel:MakePopup()
DermaPanel.Paint = function()
    draw.RoundedBoxEx( 6, 0 , 0, DermaPanel:GetWide(), DermaPanel:GetTall(), Color( 0, 150, 255, 250 ), true, true, true, true )
end
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 10, 27 )
CheckBoxThing:SetText( "Load Hemi Hack?" )
CheckBoxThing:SetConVar( "hh_shouldload" )
CheckBoxThing:SizeToContents()
