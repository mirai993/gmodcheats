--[[
	EXECUTABLE_PATH/hemihack/hh_binds.txt [#92 (#99), 1021000572, UID:2105200227]
	Cheef Beef | STEAM_0:0:18495232 <75.84.250.105:27005> | [08.07.14 03:24:29AM]
	===BadFile===
]]

"TableToKeyValues"
{
	"speedhack"		"32"
	"bunny-hop"		"109"
	"aimbot"		"111"
	"zoom"		"0"
}
