--[[
	EXECUTABLE_PATH/hemihack/hh_ents.txt [#134 (#141), 3340759355, UID:2010925316]
	Cheef Beef | STEAM_0:0:18495232 <75.84.250.105:27005> | [08.07.14 03:24:37AM]
	===BadFile===
]]

"TableToKeyValues"
{
	"1"		"vrondakis_printer"
	"2"		"money_printer_silver"
	"3"		"money_printer_gold"
	"4"		"money_printer_bronze"
}
