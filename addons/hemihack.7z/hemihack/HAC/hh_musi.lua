--[[
	EXECUTABLE_PATH/hemihack/hh_music.txt [#127 (#135), 188848191, UID:1870851372]
	Cheef Beef | STEAM_0:0:18495232 <75.84.250.105:27005> | [08.07.14 03:24:40AM]
	===BadFile===
]]

"TableToKeyValues"
{
	"1"
	{
		"name"		"Radio Electro"
		"url"		"http://yp.shoutcast.com/sbin/tunein-station.pls?id=4123"
	}
}
