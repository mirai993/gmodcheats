--[[
	EXECUTABLE_PATH/hemihack/hh_bone.txt [#22 (#22), 1543389782, UID:1270747983]
	Cheef Beef | STEAM_0:0:18495232 <75.84.250.105:27005> | [08.07.14 03:24:29AM]
	===BadFile===
]]

ValveBiped.Bip01_Head1