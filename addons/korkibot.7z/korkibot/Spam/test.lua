local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team
local timer = timer
local _G                                        = table.Copy( _G )
local _R                                        = _G.debug.getregistry()
local math                                      = _G.math
local string                            = _G.string
local hook                                      = _G.hook
local table                             = _G.table
local timer                             = _G.timer
local surface                           = _G.surface
local concommand                        = _G.concommand
local cvars                             = _G.cvars
local ents                                      = _G.ents
local player                            = _G.player
local team                                      = _G.team
local util                                      = _G.util
local draw                                      = _G.draw
local usermessage                       = _G.usermessage
local vgui                                      = _G.vgui
local http                                      = _G.http
local cam                                       = _G.cam
local render                            = _G.render
local MsgN                                      = _G.MsgN
local Msg                                       = _G.Msg
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local pairs                             = _G.pairs
local ipairs                            = _G.ipairs
local CreateSound                       = _G.CreateSound
local setmetatable                      = _G.setmetatable
local Sound                             = _G.Sound
local print                             = _G.print
local pcall                             = _G.pcall
local type                                      = _G.type
local LocalPlayer                       = _G.LocalPlayer
local KeyValuesToTable          = _G.KeyValuesToTable
local TableToKeyValues          = _G.TableToKeyValues
local Color                             = _G.Color

CreateClientConVar("Korki_spam_time" , 3)
CreateClientConVar("Korki_spam_namechange", 1)
CreateClientConVar("Korki_spam_message", "Hi")

local cname = 0
local namechange = GetConVarNumber("Korki_spam_namechange")
local time = GetConVarNumber("Korki_spam_time")
local message = GetConVarString("Korki_spam_message")

local nextspam = CurTime()
local nextnamechange = CurTime()
local function spammer()

	if namechange  == 1 then
		if nextnamechange <= CurTime() then
			RunConsoleCommand("Korki_namechange") --This runs first so it doesn't get missed by the chat delay. namechange.Priority > spam.Priority
			nextnamechange = CurTime() + 5.5
		end
	end

	if nextspam <= CurTime() then
		LocalPlayer():ConCommand("say "..message)
		nextspam = CurTime() + time
	end

end



local toggler  = 0
local function spam()
	if toggler == 0 then
		cname  = 0
		
		hook.Add("Think", "Spammer", spammer)

		toggler = 1
	else
		hook.Remove("Think", "Spammer")
		toggler = 0
	end
end

concommand.Add("Korki_spam", spam)

cvars.AddChangeCallback("Korki_spam_namechange", function(name, old, new)
	namechange = new
end)
cvars.AddChangeCallback("Korki_spam_time", function(name, old, new)
	time = new
end)
cvars.AddChangeCallback("Korki_spam_message", function(name, old, new)
	message  = new
end)
MsgC(Color(0,255,0), "Korki Chatspammer\n")