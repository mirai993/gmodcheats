concommand.Add("DarkRP_Showmoney", function()
	local darkrpvar = true
	print("Player Cash Amounts")
	for k,v in pairs(player.GetAll()) do
		if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
			darkrpvar = false
		end
		if v ~= LocalPlayer() then
			print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
		end
	end
	if darkrpvar == false then
		print("    Unable to get player cash amounts.")
	end
end)