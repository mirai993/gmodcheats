function newcvar( Name, Str )
	CreateClientConVar( Name, Str, true, false )
end

function muscle()
if GetConVarNumber( "auto_muscle" ) == 1 then
RunConsoleCommand( "act", "muscle" )
end
end
hook.Add( "Think", "muscle", muscle )

function dance()
if GetConVarNumber( "auto_dance" ) == 1 then
RunConsoleCommand( "act", "dance" )
end
end
hook.Add( "Think", "dance", dance )

function robot()
if GetConVarNumber( "auto_robot" ) == 1 then
RunConsoleCommand( "act", "robot" )
end
end
hook.Add( "Think", "robot", robot )

function wave()
if GetConVarNumber( "auto_wave" ) == 1 then
RunConsoleCommand( "act", "wave" )
end
end
hook.Add( "Think", "wave", wave )

function zombie()
if GetConVarNumber( "auto_zombie" ) == 1 then
RunConsoleCommand( "act", "zombie" )
end
end
hook.Add( "Think", "zombie", zombie )

function disagree()
if GetConVarNumber( "auto_disagree" ) == 1 then
RunConsoleCommand( "act", "disagree" )
end
end
hook.Add( "Think", "disagree", disagree )

function bow()
if GetConVarNumber( "auto_bow" ) == 1 then
RunConsoleCommand( "act", "bow" )
end
end
hook.Add( "Think", "bow", bow )

function laugh()
if GetConVarNumber( "auto_laugh" ) == 1 then
RunConsoleCommand( "act", "laugh" )
end
end
hook.Add( "Think", "laugh", laugh )

newcvar( "auto_muscle", 0 )
newcvar( "auto_dance", 0 )
newcvar( "auto_robot", 0 )
newcvar( "auto_wave", 0 )
newcvar( "auto_zombie", 0 )
newcvar( "auto_disagree", 0 )
newcvar( "auto_bow", 0 )
newcvar( "auto_laugh", 0 )

MsgC(Color(0,255,0), "Korki Acter\n")