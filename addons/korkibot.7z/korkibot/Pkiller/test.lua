CreateClientConVar("pkill_speed", 100)
CreateClientConVar("pkill_prop", "models/props/de_train/lockers_long.mdl")
CreateClientConVar("pkill_remover", 1)
CreateClientConVar("pkill_delay", 0.3)

local function propkill()
	local atttime = GetConVarNumber("pkill_delay")
	if LocalPlayer():GetActiveWeapon():GetClass() != "weapon_physgun" then
		local lastwep = LocalPlayer():GetActiveWeapon()
		RunConsoleCommand("use", "weapon_physgun")
		atttime = 0.2
		timer.Simple(atttime+.6, function()
		RunConsoleCommand("use", lastwep:GetClass())
		end)
	end
	hook.Add( "CreateMove", "PKill", function(cmd)
		cmd:SetMouseWheel(GetConVarNumber("pkill_speed"))
	end)
	timer.Simple(atttime, function()
		RunConsoleCommand("+attack")
	end)
	RunConsoleCommand("gm_spawn", GetConVarString("pkill_prop"))
	
	timer.Simple(atttime+0.1, function()
		RunConsoleCommand("-attack")
	end)
	timer.Simple(atttime+GetConVarNumber("pkill_remover"), function()
		hook.Remove("CreateMove", "PKill")
		RunConsoleCommand("undo")
	end )
end

hook.Add( "Think", "pkill", pkill )

concommand.Add("pkill", propkill)

MsgC(Color(0,255,0), "Korki Pkiller\n")