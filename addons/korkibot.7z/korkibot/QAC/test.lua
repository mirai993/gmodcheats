if ( not CLIENT ) then return end

local printShit = true

local hooker = hook.GetTable
local receive = net.Receive
local sendtoserv = net.SendToServer
local writeint = net.WriteInt
local writebit = net.WriteBit

local start = net.Start

local prant = print
local hairs = pairs
local undack = unpack

local info = debug.getinfo

local shitfunc = function()

	if ( not printShit ) then return end

	prant("Fuck the cvar check")

end

local shitfunc2 = function()

	local poop = readint(10)
	
	start("Debug1")
		
	writeint(poop, 16)
		
	sendtoserv()

	if ( not printShit ) then return end

	prant("Spoofed Ping")

end


hooker()["Think"]["penis"] = function()

	hook.Remove("OnGamemodeLoaded", "___scan_g_init")
	hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc
	receive("Debug2", shitfunc2)
	receive("gcontrol_vars", shitfunc)
	receive("control_vars", shitfunc)
	receive("checksaum", shitfunc)

	net.Receivers["Debug2"] = shitfunc2
	net.Receivers["gcontrol_vars"] = shitfunc
	net.Receivers["control_vars"] = shitfunc
	net.Receivers["checksaum"] = shitfunc

end

hook.Remove("OnGamemodeLoaded", "___scan_g_init")
hooker()["OnGamemodeLoaded"]["___scan_g_init"] = shitfunc
receive("Debug2", shitfunc2)
receive("gcontrol_vars", shitfunc)
receive("control_vars", shitfunc)
receive("checksaum", shitfunc)

net.Receivers["Debug2"] = shitfunc2
net.Receivers["gcontrol_vars"] = shitfunc
net.Receivers["control_vars"] = shitfunc
net.Receivers["checksaum"] = shitfunc


start("gcontrol_vars")	
	writebit()
sendtoserv()

function pairs( ... )

	local tbl = { ... }
	
	local dbg = info(2)
	if ( dbg ) then
		local src = dbg.short_src
		if src:find("cl_qac") then
			return hairs( { } ) -- nop
		end
		
	end
	
	return hairs(undack(tbl))
end
MsgC(Color(0,255,255), "Daz's QAC bypass loaded\n")