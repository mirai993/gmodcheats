local damnBot					= {}
damnBot.timers					= {}
local local_timerc			= timer.Create;

local RPNameChanger = CreateClientConVar("korki_RPNameChanger",0)
local RPNameChangerTime = CreateClientConVar("korki_RPNameChanger_time",5)
local local_rcc 				= RunConsoleCommand;

local_rcc("korki_RPNameChanger","0")

function damnBot:RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

function damnBot:AddTimer( sec, rep, func )
	local index = damnBot:RandomString( 10 )	
	damnBot.timers[ index ] = sec	
	local_timerc( index, sec, rep, func )
end

local next_change = GetConVarNumber("korki_RPNameChanger_time") + 0.5
function NameChanger()
local ply = LocalPlayer()
local e = player.GetAll()[ math.random( 1, #player.GetAll() ) ]
local curtime = CurTime()
	if GetConVarNumber("korki_RPNameChanger") == 1 then
		if next_change < curtime then
			if ( !e:IsAdmin() && e != ply ) then
				damnBot:AddTimer( 1, 1 , function()
					LocalPlayer():ConCommand("say /rpname ".. e:Nick() .. " " ) 
					MsgC(Color(0,0,255), "Changing DarkRP name")
				end)
			end
		end
	end
end
damnBot:AddTimer( next_change , 0 , function() NameChanger() end )

MsgC(Color(0,255,255), "Damnbot namechanger loaded\n")