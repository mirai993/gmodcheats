local NoRecoil = CreateClientConVar("korki_norecoil", 1, true, false)

function MyCalcView( ply, pos, angles, fov )
	if GetConVarNumber("korki_norecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
		return GAMEMODE:CalcView( ply, LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), fov, 0.1 );
	else
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0.1
		end
	end
end

hook.Add( "CalcView", "MyCalcView", MyCalcView )