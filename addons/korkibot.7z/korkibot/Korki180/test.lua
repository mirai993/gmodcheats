﻿local toggler = 0
local ang
local view = {}
local hook = hook
local timer = timer
local string                            = _G.string
local concommand                        = _G.concommand
local cvars                             = _G.cvars
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local LocalPlayer                       = _G.LocalPlayer

    local function Proplaunch()
	if LocalPlayer():GetActiveWeapon():GetClass() != "weapon_physgun" then
	local lastwep = LocalPlayer():GetActiveWeapon()
	RunConsoleCommand("use", "weapon_physgun")
	atttime = 0.55
	timer.Simple(atttime, function()
	RunConsoleCommand("use", lastwep:GetClass())
	end)
	end
	timer.Simple(0.05, function()
	RunConsoleCommand("+jump")
	end)
	timer.Simple(0.1, function()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+attack")
	RunConsoleCommand("+jump")
	end)
	timer.Simple(0.12, function()
	RunConsoleCommand("-jump")
	end)
	timer.Simple(0.22, function()
	RunConsoleCommand("gm_spawn", GetConVarString("Korki_180prop"))
	end)
    timer.Simple(0.30, function()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
    end)
    timer.Simple(0.5, function()
	RunConsoleCommand("-attack")
	RunConsoleCommand("undo")
    end)
    end
	
	CreateClientConVar("Korki_180prop", "models/food/burger.mdl")
    concommand.Add("Korki_180launch", Proplaunch)
	
concommand.Add("Korki_180", function() LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()+Angle(0,180,0)) end)
	
	local function Buyglock()
	LocalPlayer():ConCommand("say /buy glock")
	timer.Simple(0.1, function()
	RunConsoleCommand("+use")
	end)
	timer.Simple(0.2, function()
	RunConsoleCommand("-use")
	end)
    end
	
    concommand.Add("Korki_glock", Buyglock)
	
MsgC(Color(0,255,0), "Korki 180°\n")



