Navigate to your GMod folder:


Copy npc_esp to GarrysMod/garrysmod/lua/autorun/client/

Edit

GarrysMod/garrysmod/lua/autorun/client/
If the client folder doesn’t exist, create it.

Create a new file, e.g.:

npc_esp.lua
Paste the full ESP script (the one I gave you with boxes and health bars) into that file.

Save the file.

Launch GMod → Start a Sandbox map.

The ESP should work automatically once NPCs are spawned.