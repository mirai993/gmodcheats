hook.Add("HUDPaint", "NPC_BoxESP_WithHealth", function()
    for _, ent in ipairs(ents.FindByClass("npc_*")) do
        if IsValid(ent) and ent:Health() > 0 then
            local mins = ent:OBBMins()
            local maxs = ent:OBBMaxs()

            local corners = {
                Vector(mins.x, mins.y, mins.z),
                Vector(maxs.x, mins.y, mins.z),
                Vector(maxs.x, maxs.y, mins.z),
                Vector(mins.x, maxs.y, mins.z),
                Vector(mins.x, mins.y, maxs.z),
                Vector(maxs.x, mins.y, maxs.z),
                Vector(maxs.x, maxs.y, maxs.z),
                Vector(mins.x, maxs.y, maxs.z),
            }

            local screenPoints = {}
            for _, corner in ipairs(corners) do
                local world = ent:LocalToWorld(corner)
                local screen = world:ToScreen()
                table.insert(screenPoints, screen)
            end

            local left, top = math.huge, math.huge
            local right, bottom = -math.huge, -math.huge

            for _, point in ipairs(screenPoints) do
                if point.visible then
                    left = math.min(left, point.x)
                    top = math.min(top, point.y)
                    right = math.max(right, point.x)
                    bottom = math.max(bottom, point.y)
                end
            end

            if left < right and top < bottom then
                -- Draw 2D Box
                surface.SetDrawColor(255, 0, 0, 255)
                surface.DrawOutlinedRect(left, top, right - left, bottom - top)

                -- Draw Label
                draw.SimpleTextOutlined(
                    ent:GetClass(),
                    "DermaDefault",
                    (left + right) / 2,
                    top - 15,
                    Color(255, 0, 0),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM,
                    1, Color(0, 0, 0, 200)
                )

                -- Draw Health Bar
                local barHeight = bottom - top
                local barWidth = 5
                local x = left - 8
                local y = top
                local hp = math.Clamp(ent:Health(), 0, ent:GetMaxHealth())

                local healthPercent = hp / ent:GetMaxHealth()
                local filled = barHeight * healthPercent

                -- Background bar
                surface.SetDrawColor(50, 50, 50, 200)
                surface.DrawRect(x, y, barWidth, barHeight)

                -- Filled health
                surface.SetDrawColor(0, 255, 0, 255)
                surface.DrawRect(x, y + barHeight - filled, barWidth, filled)
            end
        end
    end
end)
