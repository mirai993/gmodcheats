--[[
	EXECUTABLE_PATH/scripts/l2/ropespam.lua [#895 (#926), 3599153863, UID:1728582023]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:31AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
Modified and improved by Ott (STEAM_0:0:36527860)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

local counter = 0

local function ropespam(cmd)
	local buttonsetter = cmd:GetButtons()
	if counter == 0 then
		bit.band(buttonsetter, IN_ATTACK)
		counter = counter +1
	end
	if counter == 1 then
		counter = counter - counter
	end
	cmd:SetButtons(buttonsetter)
end


concommand.Add("+dip_ropespam", function()
	hook.Add("CreateMove", "RopeSpam", ropespam)
end)


concommand.Add("-dip_ropespam", function()
	hook.Remove("CreateMove", "RopeSpam")
end)

MsgC(Color(0,255,0), "\ndips Rope Spam initialized!\n")