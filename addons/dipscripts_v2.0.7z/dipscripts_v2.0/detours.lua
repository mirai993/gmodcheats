--[[
	EXECUTABLE_PATH/scripts/l2/detours.lua [#392 (#398), 4008388646, UID:730837005]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:23AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

MsgC(Color(0,255,0), "\ndip Detours initialized!\n")