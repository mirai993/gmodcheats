--[[
	EXECUTABLE_PATH/scripts/l2/triggerbot.lua [#1396 (#1446), 2378021650, UID:939417301]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:32AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_triggerbot", 0)

local toggler = 0

local function triggerbot(cmd)
	if LocalPlayer():Alive() then
		local target = LocalPlayer():GetEyeTrace().Entity
		if target:IsValid() then
			if IsValid(LocalPlayer():GetActiveWeapon()) then
				if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					if target:IsPlayer() or target:IsNPC() then
						if toggler == 0 then
							cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
							toggler = 1
						else
							cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
							toggler = 0
						end
					end	
				end
			end
		end
	end
end


-- prepping
hook.Remove("CreateMove", "triggerbot")

if GetConVarNumber("dip_triggerbot") == 1 then
	hook.Add("CreateMove", "triggerbot", triggerbot)
end
--end of prep

cvars.AddChangeCallback("dip_triggerbot", function() 
	if GetConVarNumber("dip_triggerbot") == 1 then
		hook.Add("CreateMove", "triggerbot", triggerbot)
	else
		hook.Remove("CreateMove", "triggerbot")
	end
end)


MsgC(Color(0,255,0), "\ndips Triggerbot initialized!\n")
