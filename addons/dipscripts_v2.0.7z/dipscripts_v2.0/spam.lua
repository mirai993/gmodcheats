--[[
	EXECUTABLE_PATH/scripts/l2/spam.lua [#1800 (#1862), 3914569634, UID:1488728244]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:32AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_spam_time" , 3)
CreateClientConVar("dip_spam_namechange", 1)
CreateClientConVar("dip_spam_message", "/advert Server now owned by NoN-Anonymous. steamcommunity.com/groups/nonanonpub")

local cname = 0
local namechange = GetConVarNumber("dip_spam_namechange")
local time = GetConVarNumber("dip_spam_time")
local message = GetConVarString("dip_spam_message")

--uuurgh using think is ugly, but we can't manage to namechange everytime the game allowes us to otherwise

-- TODO find a better solution for this


local nextspam = CurTime()
local nextnamechange = CurTime()
local function spammer()

	if namechange  == 1 then
		RunConsoleCommand("dip_namechange") --This runs first so it doesn't get missed by the chat delay. namechange.Priority > spam.Priority
	end

	if nextspam <= CurTime() then
		LocalPlayer():ConCommand("say "..message)
		nextspam = CurTime() + time
	end

end



local toggler  = 0
local function spam()
	if toggler == 0 then
		cname  = 0
		
		hook.Add("Think", "Spammer", spammer)

		toggler = 1
	else
		hook.Remove("Think", "Spammer")
		toggler = 0
	end
end

concommand.Add("dip_spam", spam)

cvars.AddChangeCallback("dip_spam_namechange", function(name, old, new)
	namechange = new
end)
cvars.AddChangeCallback("dip_spam_time", function(name, old, new)
	time = new
end)
cvars.AddChangeCallback("dip_spam_message", function(name, old, new)
	message  = new
end)
MsgC(Color(0,255,0), "\ndips Chatspammer initialized!\n")