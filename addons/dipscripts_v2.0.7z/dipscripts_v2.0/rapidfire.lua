--[[
	EXECUTABLE_PATH/scripts/l2/rapidfire.lua [#1288 (#1334), 1254576753, UID:571113705]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:30AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
Rapidfire script recycled from dip's triggerbot by Ott (STEAM_0:0:36527860)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_rapidfire", 0)

local toggler = 0

local function rapidfire(cmd)
	if LocalPlayer():KeyDown(IN_ATTACK) then
		if LocalPlayer():Alive() then
			if IsValid(LocalPlayer():GetActiveWeapon()) then
				if toggler == 0 then
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
					toggler = 1
				else
					cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
					toggler = 0
				end
			end
		end
	end
end


-- prepping
hook.Remove("CreateMove", "rapidfire")

if GetConVarNumber("dip_rapidfire") == 1 then
	hook.Add("CreateMove", "rapidfire", rapidfire)
end
--end of prep

cvars.AddChangeCallback("dip_rapidfire", function() 
	if GetConVarNumber("dip_rapidfire") == 1 then
		hook.Add("CreateMove", "rapidfire", rapidfire)
	else
		hook.Remove("CreateMove", "rapidfire")
	end
end)


MsgC(Color(0,255,0), "\nOtt's rapidfire initialized!\n")
