--[[
	EXECUTABLE_PATH/scripts/l2/norecoil.lua [#1140 (#1179), 3112473581, UID:3756747287]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:28AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_norecoil", 1)


local function norecoil()
	if LocalPlayer():GetActiveWeapon():Clip1() > 0  then
		if LocalPlayer():GetActiveWeapon().Recoil then
			LocalPlayer():GetActiveWeapon().Recoil = 0
		end
		if LocalPlayer():GetActiveWeapon().Primary.Recoil then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end



-- prepping
hook.Remove("PlayerSwitchWeapon", "norecoil")

if GetConVarNumber("dip_norecoil") == 1 then
	hook.Add("PlayerSwitchWeapon", "norecoil", norecoil)
end
--end of prep

cvars.AddChangeCallback("dip_norecoil", function() 
	if GetConVarNumber("dip_norecoil") == 1 then
		hook.Add("PlayerSwitchWeapon", "norecoil", norecoil)
	else
		hook.Remove("PlayerSwitchWeapon", "norecoil")
	end
end)


MsgC(Color(0,255,0), "\ndips NoRecoil initialized!\n")