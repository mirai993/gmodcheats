detours = {}

