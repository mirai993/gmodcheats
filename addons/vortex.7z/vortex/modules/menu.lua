menu = { -- fuck the default retarded menu library "RecordFrame" lookin' ass
	open = false,

	fontName = tostring(math.Rand(0, 1)) .. "Fuck",

	gradients = {
		up = Material("vgui/gradient-u"),
		down = Material("vgui/gradient-d")
	}
}

do
	surface.CreateFont(menu.fontName, {
		font = "Tahoma",
		weight = 700,
		antialias = false,
		shadow = true
	})
end

function menu.gradientPaint(self, outlined, flip)
	local width, height = self:GetSize()

	surface.SetDrawColor(vortex.colors.black)
	if outlined then
		surface.DrawRect(1, 1, width - 2, height - 2)
	else
		surface.DrawRect(0, 0, width, height)
	end

	surface.SetMaterial(flip and menu.gradients.down or menu.gradients.up)
	surface.SetDrawColor(vortex.colors.darkGray)
	if outlined then
		surface.DrawTexturedRect(1, 1, width - 2, height - 2)
	else
		surface.DrawTexturedRect(0, 0, width, height)
	end

	if outlined then
		surface.SetDrawColor(vortex.colors.black)
		surface.DrawOutlinedRect(0, 0, width, height)
	end
end

function menu.createLabel(parent, text)
	local label = vgui.Create("DLabel", parent)

	label.DoClick = cache.noop -- Remove useless things
	label.OnCursorEntered = cache.noop
	label.OnCursorExited = cache.noop
	label.OnMousePressed = cache.noop
	label.OnMouseReleased = cache.noop
	label.Think = cache.noop

	surface.SetFont(menu.fontName)
	local width, height = surface.GetTextSize(text)

	label:SetSize(width, height)
	label:SetMinimumSize(nil, 15)
	label:SetFont(menu.fontName)
	label:SetText(text)
	label:SetTextColor(vortex.colors.white)

	return label
end

function menu.createTopBar()
	if menu.topBar then
		menu.topBar:CloseAllWindows()
		menu.topBar:Remove()
	end

	local topBar = vgui.Create("DPanel")
	topBar:SetPos(0, 0)
	topBar:SetSize(cache.screenSize.width, 32)

	function topBar:Paint(width, height)
		menu.gradientPaint(self, width, height)
	end

	menu.topBar = topBar

	return topBar
end

do
	local topBar = menu.createTopBar()
end