// Main Aimbot
function vortex.Aimbot(cmd)

end

// Hooks
hook.Create("CreateMove", vortex.Aimbot, 0) -- TODO: Add priority when relating to fake angles and stuffs
-- or make a master function whichever floats ya boat 
