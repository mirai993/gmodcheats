-------------------------// Setup Stuff \\-------------------------

// Globals
local _GPointer = _G
local _G = table.Copy(_G)

// Modules & Cheats
local modules = file.Find("lua/vortex/modules/*.lua", "GAME")
local cheats = file.Find("lua/vortex/cheats/*.lua", "GAME")

// Table
local vortex = {
    // Constants
    colors = {
        ["white"] = _G.color_white,
        ["black"] = _G.color_black, 

        ["red"] = _G.Color(255,0,0),
        ["green"] = _G.Color(0,255,0),
        ["blue"] = _G.Color(0,0,255),

        ["gray"] = _G.Color(105,105,105), 
        ["cyan"] = _G.Color(0,210,255),

        ["vortex blue"] = _G.Color(59, 153, 240),
        ["vortex purple"] = _G.Color(110, 70, 210),
		
		["cool blue"] = _G.Color(82, 170, 247, 255),
		["cool purple"] = _G.Color(180, 30, 180, 255),
    },

    player = _G.LocalPlayer(),
    log_location = "vortex/" .. _G.os.date("%d-%m-%y") .. ".txt",
    version = "0.1b",

    // Variables
    hooks = {},
	convars = {},
}

-------------------------// Environment setup \\-------------------------

vortex.environment = _G.setmetatable({
	vortex = vortex, -- EZ access

	R_G = _GPointer, -- Real _G
	_G = _G,
	_R = _G.debug.getregistry(),

    files = { modules, cheats },

	cache = {
		nothing = function() return end,

		screenSize = {
			width = _G.ScrW(),
			height = _G.ScrH()
		}
	}
},{
	__index = _G
})
vortex.environment._This = vortex.environment -- Self reference

local function runInEnvironment(thing)
    thing = _G.isstring(thing) && _G.CompileString(thing) || thing 
	_G.setfenv(thing, vortex.environment)() -- Set enviroment and run it
end

runInEnvironment(function()
    function runOutside(thing)
	    thing = isstring(thing) && CompileString(thing) || thing 
	    setfenv(thing, R_G)()
	end
end)

-------------------------// Console Variables \\-------------------------

runInEnvironment(function()
    function vortex.CreateConVar(convar, value)
        vortex.convars[convar] = CreateClientConVar("vortex_" .. convar, value)
        return vortex.convars[convar]
    end

    function vortex.GetConVar(convar)
        return vortex.convars[convar]
    end
end)    

-------------------------// Print Message & Logs \\-------------------------

runInEnvironment(function()
    function lerpColor(step, startColor, endColor)
        return Color(startColor.r + (endColor.r - startColor.r) * step, startColor.g + (endColor.g - startColor.g) * step, startColor.b + (endColor.b - startColor.b) * step, startColor.a + (endColor.a - startColor.a) * step)
    end

    function vortex.Print(str, prefix, startColor, endColor)
        prefix = prefix || "vortex"
        
        startColor = startColor || vortex.colors["cool blue"]
		endColor = endColor || vortex.colors["cool purple"]

        MsgC(vortex.colors["gray"], "| ")

        for i = 1, #prefix do
            MsgC(lerpColor(i/#prefix, startColor, endColor), prefix[i])
        end

        MsgC(color_white, " : " .. str .. ".\n")
    end

    function vortex.Log(str, prefix, print)
        prefix = prefix || "vortex"

        if !str then return end 

        file.CreateDir("vortex")

        if !file.Exists(vortex.log_location, "DATA") then 
            local day = os.date("%d")
            local standard = day .. STNDRD(day) -- nd or st
            
            file.Write(vortex.log_location, "VORTEX [" .. os.date(standard .. " of %B in %Y") .. "]\nFile created on server: " .. GetConVarString("hostname") .. "\n\n")
        end

        file.Append(vortex.log_location, "| " .. prefix .. " : " .. str .. ".\n")

        if print then 
            vortex.Print(str, prefix)
        end
    end 
end)

-------------------------// Hooking System \\-------------------------

runInEnvironment(function()
    function hook.Loop(event, ...)
        for i = 1, #vortex.hooks[event] do 
            vortex.hooks[event][i]( ... )
        end
    end

    function hook.Create(event, callback, priority)
        if !callback then return end 

        if !vortex.hooks[event] then 
            vortex.hooks[event] = {} 
                        
            do -- I'm taking your word for it
                local encapEvent = event 

                hook.Add(encapEvent, "vortex", function( ... )
                    hook.Loop(encapEvent, ...)
                end)
            end
        end 

        priority = math.Clamp(priority, 1, (#vortex.hooks[event]+1))
        table.insert(vortex.hooks[event], priority, callback)
    end
end)

-------------------------// Modules & Cheats \\-------------------------

runInEnvironment(function()
    for i = 1,#modules do 
		local moduleFunction = CompileFile("vortex/modules/" .. modules[i])

		if isfunction(moduleFunction) then
			setfenv(moduleFunction, _This)()
			vortex.Print("Loaded module '" .. string.StripExtension(modules[i]) .. "'", "module")
		end
    end 

    for i = 1,#cheats do 
		local cheatsFunction = CompileFile("vortex/cheats/" .. cheats[i])
        
		if isfunction(cheatsFunction) then
			setfenv(cheatsFunction, _This)()
			vortex.Print("Loaded cheat '" .. string.StripExtension(cheats[i]) .. "'", "cheat")
		end    
    end

    vortex.Print("Loaded everything & ready to go!") -- We did it! :D
end)
-- Now leave this file theres nothing else here for you ;^)
