local function co_func( f )
    local b, co = pcall( coroutine.create, f )
    if not b then
        return "cfunc"
    end
 
    debug.sethook( co, function()
        error("bye!")
    end, 'c' )
 
    local b, res, err = pcall( coroutine.resume, co )
    if not b then
        return "coerror"
    end
 
    if res then
        error( "what the fuck.", 2 )
    elseif tostring( err ):sub( -4 ) ~= "bye!" then
        error( "function caused an error: " .. tostring( err ) )
    end
 
    local strt = {
        debug.traceback( co, "", 2 )
    }
 
    local i, l = 2, debug.getlocal( co, 2, 1 )
    while l ~= nil and l ~= "(*temporary)" do
        strt[#strt + 1] = tostring( l )
        l = debug.getlocal( co, 2, i )
        i = i + 1
    end
 
    return table.concat( strt, "" )
end