if not CLIENT then return end

local function sort_blah( a, b )
	if type( a ) == "number" and type( b ) == "number" then
		return a < b
	else
		return tostring( a ) < tostring( b )
	end
end

local function sorted_keys( tbl )
	local tmp = {}
	for k, v in pairs( tbl ) do
		tmp[#tmp + 1] = k
	end
	table.sort( tmp, sort_blah )
	return tmp
end

-- lighter check for _R crc, since it changes when coroutines are used.
-- besides, there's not much to override in _R
local num_R = 0
local strt_R = {}
for k, v in pairs( sorted_keys( _R ) ) do
	num_R = num_R + 1
	strt_R[#strt_R + 1] = k
	strt_R[#strt_R + 1] = type( v )
end
local crc_R = util.CRC( table.concat( strt_R, "" ) )

if num_R ~= 103 then
	print()
	print(('='):rep( 30 ))
	print("DETECTED! EXPECTED _R COUNT 103, GOT " .. num_R)
	print(('='):rep( 30 ))
	print()
else
	print( "_R count matches." )
end
if crc_R ~= "2899444870" then
	print()
	print(('='):rep( 30 ))
	print("DETECTED! EXPECTED _R CRC 2899444870, GOT " .. crc_R)
	print(('='):rep( 30 ))
	print()
else
	print( "_R crc matches." )
end

local table_str

local function co_func( f )
	local b, co = pcall( coroutine.create, f )
	if not b then
		return "cfunc"
	end

	debug.sethook( co, function()
		error("bye!")
	end, 'c' )

	local res, err = coroutine.resume( co )
	if res then
		error( "what the fuck.", 2 )
	elseif tostring( err ):sub( -4 ) ~= "bye!" then
		error( "function caused an error: " .. tostring( err ) )
	end

	local strt = {
		debug.traceback( co, "", 2 )
	}

	local i, l = 2, debug.getlocal( co, 2, 1 )
	while l ~= nil and l ~= "(*temporary)" do
		strt[#strt + 1] = tostring( l )
		l = debug.getlocal( co, 2, i )
		i = i + 1
	end

	return table.concat( strt, "" )
end

local function func_str( f, done )
	local info = debug.getinfo( f, 'nfSlu' )
	local ups = {}
	for i=1, info.nups do
		ups[#ups + 1] = debug.getupvalue( f, i )
	end
	local strt = {
		tostring( info.source ),
		tostring( info.short_src ),
		tostring( info.linedefined ),
		tostring( info.what ),
		tostring( info.name ),
		tostring( info.namewhat ),
		tostring( info.nups ),
		tostring( info.func == f ),
		table_str( ups, done ),
		co_func( f )
	}

	return table.concat( strt, "" )
end

local function mt_str( thing, done )
	done[thing] = true
	local strt = {}
	local mt = debug.getmetatable( tbl )
	if mt ~= nil and type( mt ) ~= "table" then
		print "UMM WUT, METATABLE WRONG TYPE."
		strt[#strt + 1] = "welp"
	elseif type( mt ) == "table" then
		strt[#strt + 1] = table_str( mt, done )
	end

	return table.concat( strt, "" )
end

function table_str( tbl, done ) -- not global, declared earlier
	done = done or {}
	done[tbl] = true

	local strt = {}
	for i, k in pairs( sorted_keys( tbl ) ) do
		local v = tbl[k]

		strt[#strt + 1] = k
		strt[#strt + 1] = type( v )
		if type( v ) == "table" and not done[v] then
			strt[#strt + 1] = table_str( v, done )
		elseif type( v ) == "function" then
			strt[#strt + 1] = func_str( v, done )
		else
			strt[#strt + 1] = mt_str( v, done )
		end
	end
	local mt = debug.getmetatable( tbl )
	if mt ~= nil and type( mt ) ~= "table" then
		print "UMM WUT, METATABLE WRONG TYPE."
		strt[#strt + 1] = "welp"
	elseif type( mt ) == "table" then
		strt[#strt + 1] = table_str( mt, done )
	end

	return table.concat( strt, "" )
end

local function check_count_crc( name, tbl, realnum, realcrc )
	local num = 0
	for k, v in pairs( tbl ) do
		num = num + 1
	end
	local str = table_str( tbl, { [_R] = true } )
	local crc = util.CRC( str )

	file.Write( name .. ".txt", str )

	if num ~= realnum then
		print()
		print(('='):rep( 30 ))
		print("DETECTED! EXPECTED " .. name .. " COUNT " .. realnum .. ", GOT " .. num)
		print(('='):rep( 30 ))
		print()
	else
		print( name .. " count matches." )
	end
	if crc ~= realcrc then
		print()
		print(('='):rep( 30 ))
		print("DETECTED! EXPECTED " .. name .. " CRC " .. realcrc .. ", GOT " .. crc)
		print(('='):rep( 30 ))
		print()
	else
		print( name .. " crc matches." )
	end
end

check_count_crc( "_G", _G, 2214, "1772229050" )

local hook = require "hook"
hook.Add( "Initialize", "dsa", function()
	check_count_crc( "_G init", _G, 2441, "789053972" )
end )
