--[[
	menu_plugins/iris.lua
	pollyzoid | (STEAM_0:1:15750448)
	===DStream===
]]

if not CLIENT then return end

require 'iris'
