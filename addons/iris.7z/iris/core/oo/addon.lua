local iris = ...
iris:lib 'addon'

iris:class 'Addon'
local Addon = iris._R.Addon

iris.addon.listpath = "config/addons.json"
iris.addon.disabled = {}
iris.addon.path = "addons/" -- we'll read these from config later
iris.addon.info = "info.json"

--[[
--		Addon library
--]]

local _addons = {}

function iris.addon.read_disabled()
	local f = iris.file.open( iris.addon.listpath )
	if not f then
		iris.addon.disabled = {}
	else
		iris.addon.disabled = iris.json:decode( f:read() )
	end
end

function iris.addon.write_disabled()
	local f = iris.file.open( iris.addon.listpath, 'w' )
	f:write( iris.json:encode_pretty( iris.addon.disabled ) )
end

iris.addon.read_disabled()
--iris.print_table( iris.addon.disabled )
--iris.addon.disabled['foobar'] = true
--iris.addon.write_disabled()

function iris.addon.read_info( path )
	local f = iris.file.open( path )
	return iris.json:decode( f:read() )
end

function iris.addon.register_all()
	for _, dir in pairs( iris.file.find( iris.addon.path .. "*" ) ) do
		local path = iris.addon.path .. dir .. '/'
		local infof = path .. iris.addon.info

		if iris.file.isdir( path ) and iris.file.exists( infof ) then
			local info_list = iris.addon.read_info( infof )
			for _, info in pairs(info_list) do
				info.path = path
				local disabled = iris.addon.disabled[info.name]
				_addons[info.name] = iris.addon.register( info, disabled )
			end
		end
	end
end

function iris.addon.unregister_all()
	for k, v in pairs( _addons ) do
		v:unload()
	end
	_addons = {}
end

function iris.addon.register( info, disabled )
	print( "addon", info.name )

	for i, m in ipairs( info.mixin ) do
		info.mixin[i] = iris.mixins.get( m )

		if not info.mixin[i] then
			print( "Error while loading addon " .. info.name ..
					": invalid mixin " .. m )
			return
		end
	end

	return iris.new( 'Addon', info )( disabled )
end

--[[
--		Addon metatable
--]]

function Addon:__init( disabled )
	self.disabled = disabled

	if disabled then return end

	for _, m in ipairs( self.mixin ) do
		m:mix( self )
	end

	for _, f in ipairs( self.scripts ) do
		local func = iris.run_script( self.path .. f, false )
		func( iris, self )
	end

	self:load()
end

function Addon:load()
	for _, m in ipairs( self.mixin ) do
		if type( m.__load ) == "function" then
			m.__load( self )
		end
	end

	if type( self.__load ) == "function" then
		self:__load()
	end
end

function Addon:unload()
	if type( self.__unload ) == "function" then
		self:__unload()
	end

	for _, m in ipairs( self.mixin ) do
		if type( m.__unload ) == "function" then
			m.__unload( self )
		end
	end
end

--iris.PrintTable( _addons )
iris.addon.register_all()
