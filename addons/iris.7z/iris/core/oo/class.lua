local iris = ...

-- weeee
iris._R = {}

local function __index( tbl, key )
	local mt = getmetatable( tbl )
	return rawget( mt, key ) or rawget( mt, "base" ) and rawget( mt.base, key )
end

local function new( name, tbl )
	local o = setmetatable( tbl or {}, iris._R[name] )

	return function( ... )
		local init = o.__init
		if init then
			init( o, ... )
		end

		return o
	end
end

iris.new = new

function iris:class( name )
	local c = {}

	c.__index = __index
	c.new = function( tbl, ... )
		return new( name, tbl )( ... )
	end

	iris._R[name] = setmetatable( c, {
		__call = function( self, ... )
			return new( name )( ... )
		end
	} )

	return function( parent )
		c.base = iris._R[parent]
		c.super = iris._R[parent].__init
	end
end
