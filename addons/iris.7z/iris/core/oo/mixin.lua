local iris = ...
iris:lib	'mixins'
iris:class	'Mixin'
local Mixin = iris._R.Mixin

local _mixins = {}

function iris.mixins.get( name )
	return _mixins[name]
end

-- Monkeypatching woo
function iris._R.Lib:mixin( name )
	local m = iris.new 'Mixin'()

	m.name		= name
	m.fullname	= self.__meta.name .. '.' .. m.name
	m.type		= "mixin"

	print( "lib:mixin", m.fullname )

	if self[name] ~= nil then
		-- We're probably a library already
		self[name].mixin = m
	else
		self[name] = m
	end

	_mixins[m.fullname] = m

	self.__meta.mixins[name] = m
	return m
end

function Mixin:mix( addon )
	print( "mixing", self.name, addon.name )
	for k, v in pairs( self ) do
		if	type( v ) == "function"
			and k:sub( 1, 2 ) ~= "__"
			and not addon[k] then

			print( "mix", k )
			addon[k] = v
		end
	end

	if self.__mix then
		self.__mix( addon )
	end
end
