local iris = ...
iris.library = {}

iris:class 'Lib'
local Lib = iris._R.Lib

local _libs = {}

function iris.library.get( name )
	return _libs[name]
end

local function _lib( _, name, tbl, nomember, parent )
	local l = iris.new('Lib', tbl)()
	l.__meta = {
		name	= name,
		fullname= parent and parent.__meta.fullname..'.'..name or name,
		type	= "library",
		mixins = {}
	}

	if not nomember then
		iris[l.__meta.fullname] = l
	end

	_libs[l.__meta.fullname] = l

	return l
end

function Lib:lib( name, tbl, nomember )
	local l = iris.library( name, tbl, true, self )

	if not nomember then
		self[name] = l
	end

	return l
end

local _mt = { __call = _lib }
_mt.__index = _mt
setmetatable( iris.library, _mt )

-- IRIS IS NOW A LIBRARY
iris.library( 'core', iris, true )
