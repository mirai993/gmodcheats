local iris = ...

local n = 0
for k, v in pairs( _R ) do
	n = n + 1
	if v == iris then
		iris.ref = k
	end
end
print( "R:", n ) -- should be 104 here, 103 in enum
--print( _R[iris.ref] )

--iris.run_string([[print "Hello, world!"]], true)

--iris.print_table( iris.file )
--local f = iris.file.open( "test.json", "w" )
--print( f, getmetatable( f ) )
--f:write( iris.json:encode_pretty { foo = "bar" } )

--iris.print_table( iris.json:decode( iris.file.open( "config/iris.json" ):read() ) )

--iris.print_table( iris.file.find( "*" ) )
--iris.print_table( iris.file.find( "*", "MOD" ) )
--iris.print_table( iris.file.find( "*", "GAMEBIN" ) )

--iris.print_table( f )
--iris.print_table( getmetatable( f ) )

--iris.print_table( iris )

iris.event.call( "blah" )
