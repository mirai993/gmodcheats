local iris = ...
iris:lib	'event'
iris:mixin	'event'

local _hooks = setmetatable( {}, {
	__index = function( t, k )
		local r = {}
		rawset( t, k, r )
		return r
	end
} )

function iris.event.hook( event, id, func )
	print( "hook", event, id )
	_hooks[event][id] = func
end

function iris.event.unhook( event, id )
	print( "unhook", event, id )
	_hooks[event][id] = nil
end

function iris.event.call( event, ... )
	for id, f in pairs( _hooks[event] ) do
		if type( f ) ~= "function" then
			print( "[event]", "Removed non-function " .. tostring( id ) )
			_hooks[event][id] = nil
			return
		end

		f( ... )
	end
end

--[[
--		Mixin
--]]

function iris.event.mixin:__mix()
	self.hooks = {}
end

function iris.event.mixin:__load()
	for e, f in pairs( self.hooks ) do
		iris.event.hook( e, self.name..'.'..e, f )
	end
end

function iris.event.mixin:__unload()
	for e, f in pairs( self.hooks ) do
		iris.event.unhook( e, self.name..'.'..e )
	end
end
