local iris = ...

local function sort_blah( a, b )
	if type( a ) == "number" and type( b ) == "number" then
		return a < b
	else
		return tostring( a ):lower() < tostring( b ):lower()
	end
end

function iris.sorted_keys( tbl )
	local tmp = {}
	for k, v in pairs( tbl ) do
		tmp[#tmp + 1] = k
	end
	table.sort( tmp, sort_blah )
	return tmp
end

function iris.print_table( tbl, indent, done )
	done = done or {}
	indent = indent or 0
	local keys = iris.sorted_keys( tbl )
	for i, k in ipairs( keys ) do
		local v = tbl[k]

		if type( v ) == "table" and not done[v] then
			done[v] = true
			print( ('\t'):rep( indent ) .. tostring( k ) .. ":" )
			iris.print_table( v, indent + 1, done )
		else
			print( ('\t'):rep( indent ) .. tostring( k ), "=", tostring( v ) )
		end
	end
end
