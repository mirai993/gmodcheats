local iris, dummy = ...

print "wee"

-- dummy is also stored under iris.dummy["Dummy Addon"]
-- all addons follow the same pattern: iris.<namespace>[<addon name>]
-- namespace represents an addon folder, values under it are individiual addons
-- This allows us to keep for example a menu addon for configuring an in-game addon
-- under the same folder and namespace.

function dummy:__load()
	print "Hello, World!"
end

function dummy:__unload()
	print "Goodbye, World!"
end

function dummy.hooks.blah()
	print "dummy blah"
end

function dummy.hooks.HUDPaint()
	draw.SimpleText(
		string.format( "%s says %q!", dummy.name, dummy.db.text ),
		"TargetID",
		10, 10,
		clr_white,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP
	)
end

-- Remove the hook
-- dummy.hooks.HUDPaint = nil

--[[
dummy.db.text = "Hi!"

local clr_white = { r = 255, g = 255, b = 255, a = 255 }

dummy.commands["test"] = function( cmd, arg1 )
print( cmd, "says", arg1 )
end

dummy.commands[{"hi", "hello", "gday"}] = function( cmd, name )
print( cmd .. ", " .. name .. "." )
end
]]
