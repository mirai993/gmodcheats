setfenv(1, getfenv(3)) --setting the fenv to the one we created

local modules, _ = file.Find(name.."/modules/*.lua", "lsv") --why is it 'lsv' and not 'LUA'??
for k, modul in pairs(modules) do --loading the file and saving the names of the modules
	if modul == "modules.lua" then continue end
	include(name.."/modules/"..modul)

	modul = string.TrimRight(modul, ".lua")
	table.insert(penthus.mods, modul)
end

for k, modul in pairs(penthus.mods) do --initializing the modules
	penthus:add(modul, _G[modul])
end

for k, mod in pairs(penthus.mod) do --all modules are now initialized and can begin operation
	if mod.___onLoaded then
		mod:___onLoaded()
	end
end