---Bypasser---

1. Place gmcl_dead_win32 into garrysmod/garrysmod/lua
2. Place autoexec into garrysmod/garrysmod/cfg
3. Open Garrys mod
4. Type sv_allowcslua 1 into the Console
5. Type lua_run_cl require("Dead") into the Console
6. WIN!

*I suggest the Cheat Engine Bypasser*