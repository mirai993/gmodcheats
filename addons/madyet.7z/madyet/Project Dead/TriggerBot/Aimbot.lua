--###########
--#BY MaXx0r#
--###########

if not CLIENT then
	return
end

local Language_English = {}
Language_English["chat_loaded"]="Aimbot successfully loaded..."
Language_English["chat_whitelist_added"]="Player added to whitelist: "
Language_English["chat_whitelist_removed"]="Player removed from whitelist: "
Language_English["chat_run_error"]="Please run the script ONLY with 'lua_openscript_cl aimbot.lua'"
Language_English["chat_wallhack_activated"]="Wallhack activated..."
Language_English["chat_wallhack_deactivated"]="Wallhack deactivated..."
Language_English["chat_aimbot_activated"]="Aimbot activated..."
Language_English["chat_aimbot_deactivated"]="Aimbot deactivated..."
Language_English["chat_search"]="Searching for: "
Language_English["chat_target_changed"]="Target changed..."
Language_English["chat_target_lost"]="Target lost..."
Language_English["chat_trigger_activated"]="Trigger activated..."
Language_English["chat_trigger_deactivated"]="Trigger deactivated..."

Language_English["label_trigger"]="Trigger"
Language_English["label_target_locked"]="Target locked"
Language_English["label_aimbot"]="Aimbot"
Language_English["label_trigger"]="Trigger"
Language_English["label_wallhack"]="Wallhack"
Language_English["label_target_type"]="Target type"
Language_English["label_active"]="X"
Language_English["label_inactive"]=""

Language_English["sound_toggle"]="/buttons/button16.wav"
Language_English["sound_target_changed"]="/buttons/button15.wav"

local Language_German = {}
Language_German["chat_loaded"]="Aimbot erfolgreich geladen.."
Language_German["chat_whitelist_added"]="Spieler zur Whitelist hinzugefuegt: "
Language_German["chat_whitelist_removed"]="Spieler von der Whitelist entfernt: "
Language_German["chat_run_error"]="Bitte starte das Script NUR mit 'lua_openscript_cl aimbot.lua'"
Language_German["chat_wallhack_activated"]="Wallhack aktiviert..."
Language_German["chat_wallhack_deactivated"]="Wallhack deaktiviert..."
Language_German["chat_aimbot_activated"]="Aimbot aktiviert..."
Language_German["chat_aimbot_deactivated"]="Aimbot deaktiviert..."
Language_German["chat_search"]="Suche nach: "
Language_German["chat_target_changed"]="Ziel gewechselt..."
Language_German["chat_target_lost"]="Ziel verloren..."
Language_German["chat_trigger_activated"]="Trigger aktiviert..."
Language_German["chat_trigger_deactivated"]="Trigger deaktiviert..."

Language_German["label_trigger"]="Ziel"
Language_German["label_target_locked"]="Ziel gesperrt"
Language_German["label_aimbot"]="Aimbot"
Language_German["label_trigger"]="Trigger"
Language_German["label_wallhack"]="Wallhack"
Language_German["label_target_type"]="Ziel Typ"
Language_German["label_active"]="X"
Language_German["label_inactive"]=""

Language_German["sound_toggle"]="/buttons/button16.wav"
Language_German["sound_target_changed"]="/buttons/button15.wav"

local Language_Finnish = {}
Language_Finnish["chat_loaded"]="Aimbot ladattiin onnistuneesti..."
Language_Finnish["chat_whitelist_added"]="Pelaaja lis?ttiin whitelistille: "
Language_Finnish["chat_whitelist_removed"]="Pelaaja poistettiin whitelistilt?: "
Language_Finnish["chat_run_error"]="Lataa aimbot VAIN seuraavalla: lua_openscript_cl aimbot.lua"
Language_Finnish["chat_wallhack_activated"]="Wallhack aktivoitu..."
Language_Finnish["chat_wallhack_deactivated"]="Wallhack deaktivoitu..."
Language_Finnish["chat_aimbot_activated"]="Aimbot aktivoitu..."
Language_Finnish["chat_aimbot_deactivated"]="Aimbot deaktivoitu..."
Language_Finnish["chat_search"]="Etsit??n: "
Language_Finnish["chat_target_changed"]="Kohde muuttunut..."
Language_Finnish["chat_target_lost"]="Kohde kadonnut..."
Language_Finnish["chat_trigger_activated"]="Trigger aktivoitu..."
Language_Finnish["chat_trigger_deactivated"]="Trigger deaktivoitu..."

Language_Finnish["label_trigger"]="Trigger"
Language_Finnish["label_target_locked"]="Kohde lukittu"
Language_Finnish["label_aimbot"]="Aimbot"
Language_Finnish["label_trigger"]="Trigger"
Language_Finnish["label_wallhack"]="Wallhack"
Language_Finnish["label_target_type"]="Kohteen tyyppi"
Language_Finnish["label_active"]="X"
Language_Finnish["label_inactive"]=""

Language_Finnish["sound_toggle"]="/buttons/button16.wav"
Language_Finnish["sound_target_changed"]="/buttons/button15.wav"

--####SET THE LANGUAGE###
local Language = Language_English --English
--local Language = Language_German --German
--###################

local t_aim = false
local t_trigger = false
local t_wallhack = false
local target = nil
local oldtarget = nil
local target_type = "player"
local attack = false
local aim_text = ""
local trigger_text = ""
local wallhack_text = ""
local aim_locked_text = ""
local target_text = ""

local Player_Whitelist = {}

local MainFrame = vgui.Create("DFrame")

if not MainFrame then
	chat.AddText(Color(255, 0, 0), Language["chat_run_error"])
	return
end

local AimLabel = vgui.Create("DLabel", MainFrame)
local TriggerLabel = vgui.Create("DLabel", MainFrame)
local TargetTypeLabel = vgui.Create("DLabel", MainFrame)
local AimLockedLabel = vgui.Create("DLabel", MainFrame)
local WallhackLabel = vgui.Create("DLabel", MainFrame)
local TargetLabel = vgui.Create("DLabel", MainFrame)
local ModelIcon = vgui.Create("DModelPanel", MainFrame)

function toggle_aimbot()
	t_aim =! t_aim
	
	if t_aim then
		chat.AddText(Color(0, 255, 0), Language["chat_aimbot_activated"])
		aim_text=Language["label_active"]
	else
		chat.AddText(Color(255, 0, 0), Language["chat_aimbot_deactivated"])
		aim_text=Language["label_inactive"]
	end
	
	AimLabel:SetText("["..aim_text.."]"..Language["label_aimbot"])
	surface.PlaySound(Language["sound_toggle"])
end

function toggle_trigger()
	t_trigger =! t_trigger
	
	if t_trigger then
		chat.AddText(Color(0, 255, 0), Language["chat_trigger_activated"])
		trigger_text=Language["label_active"]
	else
		chat.AddText(Color(255, 0, 0), Language["chat_trigger_deactivated"])
		trigger_text=Language["label_inactive"]
	end
	
	TriggerLabel:SetText("["..trigger_text.."]"..Language["label_trigger"])
	surface.PlaySound(Language["sound_toggle"])
end

function toggle_wallhack()
	t_wallhack =! t_wallhack
	
	if t_wallhack then
		chat.AddText(Color(0, 255, 0), Language["chat_wallhack_activated"])
		wallhack_text=Language["label_active"]
	else
		chat.AddText(Color(255, 0, 0), Language["chat_wallhack_deactivated"])
		wallhack_text=Language["label_inactive"]
	end
	
	WallhackLabel:SetText("["..wallhack_text.."]"..Language["label_wallhack"])
	surface.PlaySound(Language["sound_toggle"])
end

function change_target_type()
	if target_type=="player" then
		target_type = "npc"
	else
		target_type = "player"
	end
	chat.AddText(Color(0, 0, 255), Language["chat_search"]..target_type.."...")
	
	TargetTypeLabel:SetText("["..target_type.."]"..Language["label_target_type"])
	surface.PlaySound(Language["sound_toggle"])
end

function check_npc(ent)
	if ent!=nil and ent:IsValid() and target_type=="npc" and ent:IsNPC() then
		return true
	else
		return false
	end
end

function check_player(ent)
	if ent!=nil and ent:IsValid() and target_type=="player" and ent:IsPlayer() and ent:Alive() then
		return true
	else
		return false
	end
end

function whitelist_handle_player()
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace(ply)
	local traceRes = util.TraceLine(trace)
	
	if traceRes.HitNonWorld and check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
		file.Write("aimbot_whitelist.txt", file.Read("aimbot_whitelist.txt")..","..traceRes.Entity:SteamID())
		chat.AddText(Color(0, 0, 255), Language["chat_whitelist_added"].."["..traceRes.Entity:GetName().." / "..traceRes.Entity:SteamID().."]")
		surface.PlaySound(Language["sound_toggle"])
	elseif traceRes.HitNonWorld and check_player(traceRes.Entity) and table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
		file.Write("aimbot_whitelist.txt", string.Replace(file.Read("aimbot_whitelist.txt"),","..traceRes.Entity:SteamID(), ""))
		chat.AddText(Color(0, 0, 255), Language["chat_whitelist_removed"].."["..traceRes.Entity:GetName().." / "..traceRes.Entity:SteamID().."]")
		surface.PlaySound(Language["sound_toggle"])
	end
end

function update()
	if(file.Exists("aimbot_whitelist.txt", "DATA")) then
		Player_Whitelist = string.Explode(",",file.Read("aimbot_whitelist.txt"))
	else
		file.Write("aimbot_whitelist.txt", "")
	end
	
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace(ply)
	local traceRes = util.TraceLine(trace)
	local aimbone = traceRes.PhysicsBone
	
	if target==nil and traceRes.HitNonWorld and t_aim then
		if t_aim and check_npc(traceRes.Entity) or (check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) then
			target = traceRes.Entity
			if target != oldtarget then
				oldtarget = target
				chat.AddText(Color(0, 0, 255), Language["chat_target_changed"])
				surface.PlaySound(Language["sound_target_changed"])
			end
		end
	end

	
	if target!=nil and t_aim and (check_npc(target) or (check_player(target)) and !table.HasValue(Player_Whitelist, target:SteamID())) then
		local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
		local targetheadpos,targetheadang = target:GetBonePosition(targethead)
		ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
		aim_locked_text=Language["label_active"]
	else
		if oldtarget!=target then
			oldtarget = target
			chat.AddText(Color(255, 0, 0), Language["chat_target_lost"])
			surface.PlaySound(Language["sound_target_changed"])
			aim_locked_text=Language["label_inactive"]
		end
		target = nil
	end
	
	AimLockedLabel:SetText("["..aim_locked_text.."]"..Language["label_target_locked"])
	
	if !attack and (check_npc(traceRes.Entity) or (check_player(traceRes.Entity)) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) and t_trigger and aimbone==10 then
		RunConsoleCommand("+attack")
		attack=true
	elseif attack and (t_trigger or t_aim) then
		RunConsoleCommand("-attack")
		attack=false
	end
	
	for k,v in pairs(player.GetAll()) do
		if table.HasValue(Player_Whitelist, v:SteamID()) then
			v:SetMaterial("models/wireframe")
			v:SetColor(Color(0, 255, 0, 255))
		else
			v:SetMaterial("")
			v:SetColor(Color(255, 255, 255, 255))
		end
	end
end

function HudPaint()
	if t_wallhack then
		for k,v in pairs(player.GetAll()) do
			draw.DrawText(v:Name().." ["..math.Round(LocalPlayer():GetPos():Distance(v:GetPos())).."]", "Default", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y-100, Color(-math.sin(RealTime()*10)*255, 0, math.sin(RealTime()*10)*255, 255), 1)
		end
	end
end

function print_whitelist()
	for k,v in pairs(Player_Whitelist) do
		print(v)
	end
end

function draw_menu()
	local item_count = 7
	local label_size = {96, 32}
	local item_pos_multiplier = 34
	local frame_height = item_count*34+128+22
	
	MainFrame:SetSize(110, frame_height)
	MainFrame:SetPos(0, ScrH()/2-256)
        MainFrame:SetVisible(true)
	MainFrame:SetDraggable(true)
	MainFrame:ShowCloseButton(true)
        MainFrame:SetTitle("TriggerBot")
	
	AimLabel:SetSize(label_size[1], label_size[2])
	AimLabel:SetPos(8, 4+item_pos_multiplier*1)
	AimLabel:SetText("["..aim_text.."]"..Language["label_aimbot"])

	TriggerLabel:SetSize(label_size[1], label_size[2])
	TriggerLabel:SetPos(8, 4+item_pos_multiplier*2)
	TriggerLabel:SetText("["..trigger_text.."]"..Language["label_trigger"])
	
	WallhackLabel:SetSize(label_size[1], label_size[2])
	WallhackLabel:SetPos(8, 4+item_pos_multiplier*3)
	WallhackLabel:SetText("["..wallhack_text.."]"..Language["label_wallhack"])
	
	AimLockedLabel:SetSize(label_size[1], label_size[2])
	AimLockedLabel:SetPos(8, 4+item_pos_multiplier*4)
	AimLockedLabel:SetText("["..aim_locked_text.."]"..Language["label_target_locked"])
	
	TargetTypeLabel:SetSize(label_size[1], label_size[2])
	TargetTypeLabel:SetPos(8, 4+item_pos_multiplier*5)
	TargetTypeLabel:SetText("["..target_type.."]"..Language["label_target_type"])
	
	TargetLabel:SetSize(label_size[1], label_size[2])
	TargetLabel:SetPos(4, item_pos_multiplier*7+120)
	TargetLabel:SetText(target_text)
	TargetLabel:SetColor(Color(255,0,0))
end

draw_menu()

concommand.Add("toggle_aimbot", toggle_aimbot)
concommand.Add("toggle_trigger", toggle_trigger)
concommand.Add("toggle_wallhack", toggle_wallhack)
concommand.Add("change_target_type", change_target_type)
concommand.Add("whitelist_handle_player", whitelist_handle_player)
concommand.Add("print_whitelist", print_whitelist)

hook.Add("Think", "update", update)
hook.Add("HUDPaint", "paint_hud", HudPaint)

chat.AddText(Color(0, 0, 255), Language["chat_loaded"])
chat.AddText(Color(0, 0, 255), Language["chat_search"]..target_type.."...")