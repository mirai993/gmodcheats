---Trigger Bot---

1. Place it in garrysmod/garrysmod/lua
2. Open gmod, and join a server
3. Type lua_openscript_cl Aimbot.lua into console
4. Type bind *key* "toggle_trigger"
5. Aim @ Head
6. WIN!


---The rest of the hacks on this is USELESS and shit---