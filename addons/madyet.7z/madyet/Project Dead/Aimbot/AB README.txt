---Aimbot---

1. Place it in garrysmod/garrysmod/lua
2. Open garrys mod, and join a server
3. Type lua_openscript_cl Project-Dead.lua into the Console
4. Type bind *key* "toggle dead_aimbot 1 0" into the Console
5. WIN!