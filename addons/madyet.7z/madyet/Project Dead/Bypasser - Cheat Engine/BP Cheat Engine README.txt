---Bypasser - Cheat Engine---

1. Open Garry's Mod
2. Open Cheat Engine
3. Hit the box with a Man and a Computer *Top Left Corner*
4. Select hl2.exe process
5. Type sv_allowcslua 1 into the Console
6. Go to the bottom and click the box where it says sv_allowcslua 1 
*make sure it has a X*
7. Join a Server
8. WIN!

---OPTIONAL---

1. Type sv_cheats 1 into the Console
2. Freeze it *Hit the box and make sure it has a X*
3. Join a Server
4. WIN!