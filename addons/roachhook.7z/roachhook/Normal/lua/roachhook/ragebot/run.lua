RoachHook_IncludeFile("cheats/typical/addons/roachhook/lua/roachhook/ragebot/aimbot.lua")
RoachHook_IncludeFile("cheats/typical/addons/roachhook/lua/roachhook/ragebot/antiaim.lua")