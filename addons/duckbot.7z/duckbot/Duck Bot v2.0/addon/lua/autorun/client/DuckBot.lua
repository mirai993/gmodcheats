//localasing

local CreateClientConVar = CreateClientConVar;


local tinsert = table.insert;


local cAddChangeCallback = cvars.AddChangeCallback;

//other shit




local DUCKBOT = {
	Hooks = {},
	ConVars = {},
	Timers = {}
	Config = {}
};

--what to do now

--I used a nice system that looks clean etc


function DUCKBOT:Hook(name,...)
	if(!self.Hooks[name]) then
		self.Hooks[name] = {};
	end
	for k,v in pairs({...}) do
		tinsert(self.Hooks[name],v);
	end
end

function DUCKBOT:UnHook(name)
	for k,v in pairs({...}) do
		self.Hooks[name] = nil;
	end
end

local function mainCVarCallback(cvar,old,new)
	--whats supposed to be done here?
end
	
	
function DUCKBOT:AddConvar(cvar,default,shouldsave,callback)
	local cvar = CreateClientConVar("Duck_" .. cvar, default, true, false);
	cAddChangeCallback(cvar,mainCVarCallback)
	self.ConVars[name] = {cvar,callback};
	--fuck, got distracted by fp
	--too sleepy, will do tomorrow
end

