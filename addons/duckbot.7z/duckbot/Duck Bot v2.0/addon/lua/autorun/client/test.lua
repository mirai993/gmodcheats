
/*
local ent = Entity(127);
local mat = Material("models/debug/debugwhite");


--looking up these is quite expensive
local cmp = STENCILCOMPARISONFUNCTION_EQUAL;
local keep = STENCILOPERATION_KEEP;
local always = STENCILCOMPARISONFUNCTION_ALWAYS;
local zero = STENCILOPERATION_ZERO;

--From the wiki, made by me however...
local sin,cos,rad = math.sin,math.cos,math.rad; --Only needed when you constantly calculate a new polygon, it slightly increases the speed.
local function GeneratePoly(x,y,radius,quality)
    local circle = {};
    for i=1,quality do
        circle[i] = {x = x + cos(rad(i*360)/quality)*radius,y = y + sin(rad(i*360)/quality)*radius};
    end
    return circle;
end

local poly = GeneratePoly(ScrW()/2,ScrH()/2,150,48);


--The stencil costs us about 0.5fps so we can get something back of this :o
local rSetStencilEnabled = render.SetStencilEnable;
local rClearStencil = render.ClearStencil;
local rSetStencilReferenceValue = render.SetStencilReferenceValue;
local rSetStencilPassOperation = render.SetStencilPassOperation;
local rSetStencilFailOperation = render.SetStencilFailOperation;
local rSetStencilCompareFunction = render.SetStencilCompareFunction;

local sSetDrawColor = surface.SetDrawColor;
local sDrawPoly = surface.DrawPoly;

local cStart3D = cam.Start3D;
local cStart3D = cam.End3D;

local EyePos = EyePos;
local EyeAngles = EyeAngles;
local SetMaterialOverride = SetMaterialOverride;

hook.Add("HUDPaint","stenciltest",function()
	rSetStencilEnable(true);
		rClearStencil();
		rSetStencilReferenceValue(3);
		sSetDrawColor(0,0,0,10)
		sDrawPoly(poly);
		rSetStencilPassOperation(replace);
		rSetStencilFailOperation(keep);
		rSetStencilCompareFunction(cmp);
		cStart3D(EyePos(),EyeAngles());
			SetMaterialOverride(mat);
				ent:DrawModel();
			SetMaterialOverride(nil);
		cEnd3D();
	rSetStencilEnable(false);
end);
function ReloadFunction(func)
    local inf = debug.getinfo(value);
    if(inf.what == "C") then
        return "Cannot reload C function!";
    elseif(inf.short_src == "LuaCmd") then
        return "Cannot reload console defined function!";
    elseif(file.Exists(inf.short_src,true)) then
        local res,res = pcall(CompileString,table.concat(data,"\n",inf.linedefined,inf.lastlinedefined),info.short_src);
        return res;
    else
        return "Cannot reload function, source does not exist!";
    end
end*/

/*
local function GetBase( ... )
	local ply = LocalPlayer()
	
	local w = ply:GetActiveWeapon()
	if ( !ply || !w ) then return false end
	local args = { ... }
	
	for k, v in pairs( args ) do
		if ( w.Base && w.Base == v ) then
			return true
		end
	end
	return false
end

Hermes.BaseWeapons = {
	{
		Base = function() 
			return GetBase( "gta_base", "as_swep_base" )
		end,
		
		GetInfo = function()
			local ply = LocalPlayer()
			local w = ply:GetActiveWeapon()
			if ( !ply || !w ) then return end
			if ( !Hermes.Bullet[ w:GetClass() ] ) then return end
			local bullet = Hermes.Bullet[ w:GetClass() ]
			
			local damage = bullet.Damage || w.Primary.Damage
			local t = Hermes:SimpleTrace()
			
			if ( !t || !damage ) then return end
			
			local bouncenum = 0
			local function Trace( trc, getdmg )
				local dir = trc.Normal * ( w.GetPenetrationDistance && w:GetPenetrationDistance( trc.MatType ) || 0 )
				
				local trace = {}
				trace.endpos = trc.HitPos
				trace.start = trc.HitPos + dir
				trace.mask = MASK_SHOT
				trace.filter = { ply }
				
				local trace = util.TraceLine( trace ) 
				
				if ( trace.StartSolid || trace.Fraction >= 1.0 || trc.Fraction <= 0.0 ) then return end
				if ( !getdmg ) then return true end
				
				if ( getdmg ) then
					local dist = ( trace.HitPos - trc.HitPos ):Length()
					local ret_damage = w:GetPenetrationDamageLoss( trc.MatType, dist, damage )
					
					if ( Trace( trace, false ) ) then
						return ret_damage
					end
				end
			end
			
			return Trace( t, true )
		end
	},
	
	{
		Base = function()
			return GetBase( "weapon_mad_base", "weapon_mad_base_sniper" )
		end,
		
		GetInfo = function()
			local ply = LocalPlayer()
			local w = ply:GetActiveWeapon()
			if ( !ply || !w ) then return end
			if ( !Hermes.Bullet[ w:GetClass() ] ) then return end
			local bullet = Hermes.Bullet[ w:GetClass() ]
			
			local damage = bullet.Damage || 0
			local t = Hermes:SimpleTrace()
			
			if ( !t || !damage ) then return end
			local max

			if w.Primary.Ammo == "AirboatGun" then // 5.56MM Ammo
				max = 18
			elseif w.Primary.Ammo == "Gravity" then // 4.6MM Ammo
				max = 8
			elseif w.Primary.Ammo == "AlyxGun" then // 5.7MM Ammo
				max = 12
			elseif w.Primary.Ammo == "Battery" then // 9MM Ammo
				max = 14
			elseif w.Primary.Ammo == "StriderMinigun" then // 7.62MM Ammo
				max = 20
			elseif w.Primary.Ammo == "SniperPenetratedRound" then // .45 Ammo
				max = 16
			elseif w.Primary.Ammo == "CombineCannon" then // .50 Ammo
				max = 20
			else
				max = 16
			end

			
			local bouncenum = 0
			local function Trace( trc, getdmg )
				if ( ( trc.MatType == MAT_METAL && w.Ricochet) || ( trc.MatType == MAT_SAND ) || ( trc.Entity:IsPlayer() ) ) then return end
				
				if ( bouncenum > 3 ) then return end
				bouncenum = bouncenum + 1
				
				local dir = trc.Normal * max
				
				if ( trc.MatType == MAT_GLASS || trc.MatType == MAT_PLASTIC || trc.MatType == MAT_WOOD || trc.MatType == MAT_FLESH || trc.MatType == MAT_ALIENFLESH ) then
					dir = trc.Normal * ( max * 2 )
				end
				
				local trace 	= {}
				trace.endpos 	= trc.HitPos
				trace.start 	= trc.HitPos + dir
				trace.mask 		= MASK_SHOT
				trace.filter 	= { ply }
				
				local tr 	= util.TraceLine(trace) 
				
				if ( tr.StartSolid or tr.Fraction >= 1.0 or trc.Fraction <= 0.0) then return end
				
				if ( !getdmg ) then return true end 
				
				local ret_damage = 0.5
					
				if (tr.MatType == MAT_CONCRETE) then
					ret_damage = 0.3
				elseif (tr.MatType == MAT_WOOD or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_GLASS) then
					ret_damage = 0.8
				elseif (tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH) then
					ret_damage = 0.9
				end
				
				if ( getdmg ) then
					if ( Trace( tr, false ) ) then
						return ret_damage
					end
				end
			end
			return Trace( t, true )
		end
	},
}

function Hermes.AutoWall()
	if ( !Hermes.features['autowall'] ) then return false end
	for k, v in pairs( Hermes.BaseWeapons ) do
		if ( v.Base && v.Base() ) then
			if ( v.GetInfo && v.GetInfo() ) then
				if ( tonumber( Hermes.features['autowalldamage'] ) == 0 ) then return true end
				local dmg = v.GetInfo() * 100
				return dmg > tonumber( Hermes.features['autowalldamage'] ) && true || false
			end
		end
	end
end*/


/*

local hook_table = {}
local oldHookCall = hook.Call
function hook.Call(name, gm, ...)
	for k,tbl in pairs(hook_table) do
		if tbl.name == name then
			if ... == nil then
				ret = tbl.func()
			//elseif type(...) == "table" then
			//	return tbl.func(unpack(arg))
			else
				ret = tbl.func(...)
			end
			if ret != nil then // this is so we dont always return a value, EG HUDPaint should not have a return unless overidden
				return ret
			end
		end
	end
	return oldHookCall(name, gm, ...)
end
local function hook.Add(name, id, func)
	hook_table[id] = {name=name, func=func}
	//hook.Add(name,id,func)
end

local cmd_table = {}
local oldCmdRun = concommand.Run
function concommand.Run( pl, name, ... )
	local tbl = cmd_table[name]
	if tbl != nil then
		return tbl.func(pl,name,...)
	else
		return oldCmdRun(pl, name, ...)
	end
end
local function concommand.Add(name, func, afunc, help)
	AddConsoleCommand(name,help)
	cmd_table[name] = {func=func,afunc=afunc,help=help}
	//concommand.Add(name,func,afunc,help)
end
*/

/*// make sure this is always reachacble
if not self:Enabled() and WasSilentAimed then
	WasSilentAimed = false
	CmdM.SetViewAngles(cmd, self:GetView())
end

// in hax

local times = 1
if qq:Setting("silentaim") then
	WasSilentAimed = true
	times = -1
	aim.p = (aim.p - 180) * -1
	aim.y = aim.y + 180
end

// when u set ur shit

CmdM.SetSideMove(cmd, set.y * times)*/