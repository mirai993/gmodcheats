if(true) then return end
local derpherp = file.Read;
local function dummy1() return "ydfgdASDASDsySADFASDfgdy" end
local function dummy2() return "ydsfgdSDfgdfSDGghdfhgydfgdfg" end
local function dummy3() return "ydsfSgdfgAdfghSFDdfhgydfgdfg"  end
local function dummy4() return "ydsfgdFSDGSDgdfghdSDADfhgydfgdfg"  end
local function dummy5(lol,xDDD)
	if((string.find(string.lower(xDDD),"lua",1,true)  != nil) or lol != 421337) then
		return "_G['\\112\\114\\105\\110\\116']('\\116\\104\\101\\32\\103\\97\\109\\101');"
	else
		return derpherp(path);
	end
end--aaaaaaaaaa
//aaaaaaaaaa
local function dummy6() return "ydsfgdfgdSDFSDFSfghdfhgydfgdfg"  end
local function dummy7() return "ydsfgdfgASFDAdfghdfhgydfgdfg"  end
local function dummy8() return "DFGSDFSAFDDFH"  end
local function dummy9()  return "ydsfgdfgSAdfghdfhgydfgdfg" end
local function dummy10() return "ydsfgdfgdFSGDDFGASDFAfghdfhgydfgdfg"  end


function file.Read(path,421337)
	dummy1();
	dummy2();
	dummy3();
	dummy4();
	if(string.find(string.lower(path),"lua",1,true) != nil) then
		return "_G['\\112\\114\\105\\110\\116']('\\116\\104\\101\\32\\103\\97\\109\\101');"
	else
		dummy6();
		dummy7();
		dummy8();
		dummy9();
		dummy10();
		return dummy5(421337,path);
	end
end


local tobefaked = {};

local signature = {
	nups	=	0,
	what	=	C[1].
	func	=	print,--dummy
	lastlinedefined	=	-1.
	source	=	= [C].
	currentline	=	-1.
	namewhat	=	"".
	linedefined	=	-1.
	short_src	=	"[C]"
}


function FakeCSignature(func)
	tobefaked[func] = true;
end

local dgetinfo = debug.getinfo; --that should be secure, I think...
function debug.getinfo(thread,func,...)
	if(type(thread) == "function") then
		if(tobefaked[thread]) then
		local newsig = table.Copy(signature);--HAHA FAGGOT
		newsig.func = thread;--L O L
		return newsig;
	elseif(func) then
		if(tobefaked[func]) then
			local newsig = table.Copy(signature);--HAHA FAGGOT
			newsig.func = func;--L O L
			return newsig;
		end
	end
	return dgetinfo(thread,func,...);
end

local dgetupvalue = debug.getupvalue;
function debug.getupvalue(func,up)
	if(tobefaked[func]) then
		return nil;
	end
	return dgetupvalue(func,up);
end

local dsetupvalue = debug.setupvalue;
function debug.setupvalue(func,up,val)
	if(tobefaked[func]) then
		return nil;
	end
	return dsetupvalue(func,up,val);
end

--TODO: debug.traceback, use regex to remove bot signature what is regex the only thing i got from here is that youre faking sigs tbh