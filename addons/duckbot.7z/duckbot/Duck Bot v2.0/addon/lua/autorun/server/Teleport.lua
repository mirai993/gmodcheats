local enter = ents.Create("point_tesla")
enter:SetKeyValue("texture", "sprites/bluelight1.spr")
enter:SetKeyValue("m_Color", "255 255 255")
enter:SetKeyValue("m_flRadius", "200")
enter:SetKeyValue("beamcount_min", "10")
enter:SetKeyValue("beamcount_max", "20")
enter:SetKeyValue("thick_min", "1")
enter:SetKeyValue("thick_max", "5")
enter:SetKeyValue("interval_min", "0.01")
enter:SetKeyValue("interval_max", "0.01")

local exit = ents.Create("point_tesla")
exit:SetKeyValue("texture", "sprites/grav_beam_noz.spr")
exit:SetKeyValue("m_Color", "255 255 255")
exit:SetKeyValue("m_flRadius", "200")
exit:SetKeyValue("beamcount_min", "10")
exit:SetKeyValue("beamcount_max", "20")
exit:SetKeyValue("thick_min", "1")
exit:SetKeyValue("thick_max", "5")
exit:SetKeyValue("interval_min", "0.01")
exit:SetKeyValue("interval_max", "0.01")

local function Teleport(ply, key)
	local dest = ply:GetEyeTrace().HitPos
	if ply:KeyDown(IN_WALK) then 
		enter:SetPos(ply:GetPos() + Vector(0,0,50))
		enter:Spawn()
		enter:Fire("DoSpark", "", 0)
		enter:Fire("DoSpark", "", 0.3)
		enter:Fire("DoSpark", "", 0.7)
		enter:Fire("DoSpark", "", 1)
		if key == IN_USE then
			ply:SetPos(dest + Vector(0,0,50)) 
			exit:SetPos(ply:GetPos())
		    exit:Spawn()
		    exit:Fire("DoSpark", "", 0)
		    exit:Fire("DoSpark", "", 0.3)
		    exit:Fire("DoSpark", "", 0.7)
		    exit:Fire("DoSpark", "", 1)
			ply:EmitSound("ambient/machines/teleport4.wav",100,100)
		end
	end
end

hook.Add("KeyPress", "Tele", Teleport) 
