print( "DuckBot Loading" )

require( "syshack" );
require("localcommand")
CreateClientConVar("Duck_Wallhack_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Material", 0, true, false)
CreateClientConVar("duck_crosshair_red", 255, true, false)
CreateClientConVar("duck_crosshair_green", 255, true, false)
CreateClientConVar("duck_crosshair_blue", 255, true, false)
CreateClientConVar("duck_crosshair_opacity", 255, true, false)
CreateClientConVar("duck_name", 0, true, false)
CreateClientConVar("duck_esp", 0, true, false)
CreateClientConVar("duck_esp_pvisible", 0, true, false)
CreateClientConVar("duck_esp_pweapon", 0, true, false)
CreateClientConVar("duck_esp_phealth", 0, true, false)
CreateClientConVar("duck_esp_weapon", 0, true, false)
CreateClientConVar("duck_esp_npc", 0, true, false)
CreateClientConVar("duck_esp_ttt", 0, true, false)
CreateClientConVar("duck_faggot", 0, true, false)
CreateClientConVar("duck_laser", 0, true, false)
CreateClientConVar("duck_laser_dot", 0, true, false)
CreateClientConVar("duck_crosshair", 1, true, false)
CreateClientConVar("duck_crosshair_style", 1, true, false)
CreateClientConVar("duck_zoom", 0, true, false)
CreateClientConVar("duck_zoom_amout", 75, true, false)
CreateClientConVar("duck_team", 0, true, false)
CreateClientConVar("duck_teamw", 0, true, false)
CreateClientConVar( "ms_name", 2, false, false )
CreateClientConVar( "duck_dark", 0, false, false )
CreateClientConVar( "duck_darkthem", 0, false, false )
CreateClientConVar("duck_aim_friends", 0, true, false) 
CreateClientConVar("duck_aim_team", 0, true, false)     
CreateClientConVar("duck_trigger", 0, true, false) 
CreateClientConVar("duck_hud", 1, true, false)
CreateClientConVar("duck_recoil", 1, true, false)
CreateClientConVar("duck_cone", 0.02, true, false)	
CreateClientConVar("duck_sys_nospread", 0, true, false)
CreateClientConVar("duck_sys_nospread_onmethod", 0, true, false)
CreateClientConVar( "duck_aimplus", 4, true, false )
CreateClientConVar( "duck_aim_compensate", 2, true, false )

local function head(npc) 
        local headbone = npc:LookupBone("ValveBiped.Bip01_Head1") 
        return npc:GetBonePosition(headbone) 
end 

local function visible(npc) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = head(npc),filter = {LocalPlayer(), npc}} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end 
	

local cone,view_adjust,num_shots,C_WEP,last_wep,ME
 
NOSPREAD = false 
ME = LocalPlayer()
 
CONFIG = {}
CONFIG.weapons = {}

CONFIG.weapons["^weapon_ar2$"] = {cone = 0.02618}
CONFIG.weapons["^weapon_shotgun$"] = {cone = 0.08716}
CONFIG.weapons["^weapon_smg1$"] = {cone = 0.04362}
CONFIG.weapons["^weapon_zs_zombie$"] = {cone = 0.00000}
CONFIG.weapons["^weapon_zs_fastzombie$"] = {cone = 0.00000}
CONFIG.weapons["^weapon_zs_fastzombie$"] = {cone = 0.00000}
 
local function GetWepVal(t, v, i)
        if not t then return "NULL" end
        if t[v] then
                return t[v]
        end
        if t.Primary and t.Primary[v] then
                return t.Primary[v]
        end
        if t["Primary"..v] then
                return t["Primary"..v]
        end
        if t["data"] then
                for _,d in pairs(t["data"]) do
                        if type(d)=="table" and d[v] then return d[v] end
                end
        end
        if t.BaseClass and (i or 0)<10 then
                return GetWepVal(t.BaseClass, v, (i or 0)+1)
        end
        return nil
end
 
hook.Add("Think","SH_Think",function()
        if not ValidEntity(ME) then return end
        if not ME:IsPlayer() then return end
        C_WEP = ME:GetActiveWeapon()
        if not C_WEP then return end
        if C_WEP ~= last_wep then
                last_wep = C_WEP
                if C_WEP and C_WEP:IsValid() then
                        local tab = C_WEP:GetTable()
                        function tab:ViewModelDrawn()
                                if WinIsOn and OnViewModelRender then
                                        OnViewModelRender()
                                end
                        end
                        local override = {}
                        for class, settings in pairs(CONFIG.weapons) do
                                if string.match(string.lower(C_WEP:GetClass()), class) then
                                        override = settings
                                        break
                                end
                        end
                        cone = override.cone or tonumber(GetWepVal(tab, "Cone")) or 0
                        num_shots = override.num_shots or tonumber(GetWepVal(tab, "NumShots")) or 0
                        inverse_vm_yaw = tab.Base--override.inverse_vm_yaw
                        inverse_vm_pitch = override.inverse_vm_pitch
                        strange_weapon = override.no_rapid
                        muzzle = C_WEP:LookupAttachment("muzzle")
                        if override.automatic ~= nil then
                                automatic = override.automatic
                        else
                                automatic = GetWepVal(tab, "Automatic")
                        end
                        if tab and tab.Primary then  end
                else
                        cone = 0
                        automatic = true
                end
        end
end)
 
local inited = false
local real_view,cv_sensitivity,sensitivity

hook.Add("CreateMove","SH_CreateMove",function(UCMD)
        if not inited then
                inited = true
                real_view = UCMD:GetViewAngles()
                cv_sensitivity = GetConVar("sensitivity")
        end
        sensitivity = cv_sensitivity:GetFloat()/200
        real_view = strange_weapon and UCMD:GetViewAngles() or Angle(math.max(math.min(real_view.p+UCMD:GetMouseY()*sensitivity, 90), -90),real_view.y-UCMD:GetMouseX()*sensitivity,0)


		
	function asa()
	 	local viewpos = {} 
	
	viewpos.angles = (LocalPlayer():EyeAngles() + real_view) - LocalPlayer():EyeAngles() 

			viewpos.fov = FOV
		return viewpos
end

		met = UCMD:GetButtons() & IN_ATTACK ~= IN_ATTACK	
		if met then real_view = UCMD:GetViewAngles() return end
	
	

      
	  
concommand.Add("+duck_ns", function()
if GetConVarNumber("duck_sys_nospread") == 1 then

  hook.Add("CalcView", "Na", asa) 	
   hook.Add("Think", "Norecosil", asa)
   else
end   	  
	  end)
concommand.Add("-duck_ns", function()	  
	
	hook.Remove("CalcView", "Na") 	
   hook.Remove("Think", "Norecosil")

   end)

        cone = cone or 0
       
	   if GetConVarNumber("duck_sys_nospread") == 1
        then
		NOSPREAD = true
	
		if cone == 0  then return end
       
        view_adjust = Angle(real_view.p, real_view.y, real_view.r)
 
        view_adjust = hack.CompensateWeaponSpread(UCMD, Vector(-cone, -cone, -cone), view_adjust:Forward()):Angle()
        UCMD:SetViewAngles(view_adjust)



		end
		end)

function ToggleF()
if GetConVarNumber("duck_sys_nospread") == 1 then
LocalCommand("bind mouse1 +duck_nospread")
 else
LocalCommand("bind mouse1 +attack")
 end
 end
	  
	   
	   hook.Add("Think","Acurracy",function()
      
      ToggleF() //I'm just leaving this here so i don't have to add a new hook. I know this is a messy way, i can't think of anyother method
    
        local wep = LocalPlayer():GetActiveWeapon()
        if not wep then return end      
	   if wep and wep:IsValid() then
	  local tabe = wep:GetTable()
 function tabe:ViewModelDrawn()
                                if WinIsOn and OnViewModelRender then
                                        OnViewModelRender()
                                end
                        end
        
                        if tabe and tabe.Primary then tabe.Primary.Recoil = GetConVarNumber("duck_recoil")  end
        end
                
end)


		

	


hook.Add("Think", "nigger", function()
if GetConVarNumber("duck_trigger") == 1 then
local tr = util.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector())
		local trace = util.TraceLine(tr)
		if trace.Hit and trace.HitNonWorld then
			local hit = trace.Entity
			if hit:IsNPC() or hit:IsPlayer() then
 RunConsoleCommand("+attack") 
 timer.Simple(0.01, function()  RunConsoleCommand("-attack")  end)

end
end
end
end)



local PredictSpread = function() end
local mysetupmove = function() end
local Check = function() end
 
local CL = LocalPlayer()
 
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_decz.dll")>=1 then
NoSpreadHere=true
// ANTI SPREAD SCRIPT
 
local MoveSpeed = 1
 
mysetupmove = function(objPl, move)
        if move then
                MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
        end
end
 
local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
        {check=function ()
                return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
        end,getcone=function (wep,cone)
                if type(wep.Base) == "string" then
                        if wep.Base == "civilian_base" then
                                local scale = cone
                                if CL:KeyDown(IN_DUCK) then
                                        scale = math.Clamp(cone/1.5,0,10)
                                elseif CL:KeyDown(IN_WALK) then
                                        scale = cone
                                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
                                        scale = cone + (cone*2)
                                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
                                        scale = cone + (cone*1.5)
                                end
                                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                                return Vector(scale,0,0)
                        end
                end
                return Vector(cone,cone,cone)
        end},
        {check=function ()
                return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
        end,getcone=function (wep,cone)
                if wep:GetNetworkedBool("Ironsights",false) then
                        if CL:Crouching() then
                                return wep.ConeIronCrouching or cone
                        end
                        return wep.ConeIron or cone
                elseif 25 < LocalPlayer():GetVelocity():Length() then
                        return wep.ConeMoving or cone
                elseif CL:Crouching() then
                        return wep.ConeCrouching or cone
                end
                return cone
        end},
        {check=function ()
                return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
        end,getcone=function (wep,cone)
                if CL:GetVelocity():Length() > 25 then
                        return wep.ConeMoving or cone
                elseif CL:Crouching() then
                        return wep.ConeCrouching or cone
                end
                return cone
        end},
        {check=function ()
                return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
        end,getcone=function (wep, cone)
                if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
                        if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                                print("using scopecone")
                                return wep.Primary.Cone
                        end
                        print("using unscoped cone")
                        return wep.Primary.UnscopedCone
                end
                if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
                        return cone
                end
                return cone + .05
        end},
        {check=function ()
                return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
        end,getcone=function(wep,cone)
                if wep.Primary then
                        local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
                        local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
                        local accuracy = wep.Primary.Accuracy
                        if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
                        if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
                        accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
                        if CL:KeyDown(IN_DUCK) then
                                return accuracy*wep.CrouchModifier*lastshootmod
                        else
                                return accuracy*lastshootmod
                        end
                end
        end}
}
Check = function()
        for k, v in pairs(GameTypes) do
                if v.check() then
                        ID_GAMETYPE = k
                        break
                end
        end
end
 
concommand.Add("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)
 
local tblNormalConeWepBases = {
        ["weapon_cs_base"] = true
}
local function GetCone(wep)
        local cone = wep.Cone
        if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
                cone = wep.Primary.Cone
        end
        if not cone then cone = 0 end
        --CHeck if wep is HL2 then return corresponding cone
        if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
        if wep:GetClass() == "ose_turretcontroller" then return 0 end
        if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
        return cone or 0
end
 
require("decz")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
        cmd2, seed = hl2_ucmd_getprediciton(cmd)
        if cmd2 ~= 0 then
                currentseed = seed
        end
        wep = LocalPlayer():GetActiveWeapon()
        vecCone = Vector(0,0,0)
        if wep and wep:IsValid() and type(wep.Initialize) == "function" then
                valCone = GetCone(wep)
                if type(valCone) == "number" then
                        vecCone = Vector(-valCone,-valCone,-valCone)
                elseif type(valCone) == "Vector" then
                        vecCone = -1*valCone
                end
        end
        return hl2_shotmanip(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
//END OF ANTI SPREAD SCRIPT
end
 
 
 
 local Friends = {""}

  
 function TeamA(ent)
	if GetConVarNumber("duck_aim_team") >= 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end
	return true
end


function EnemiesA(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and ent:Health() <0 then return false end
	if ent:IsPlayer() and table.HasValue(Friends,ent:Nick()) then return false end
	if ent:IsPlayer() and !TeamA(ent) then return false end
	if GetConVarNumber("duck_aim_friends") == 1 then if ent:IsPlayer() and ent:GetFriendStatus() == "friend" then return nil end end 
	if ent:IsNPC() and ent:GetMoveType() == 0 then return false end 
	return true
end



function Target()
	local position = LocalPlayer():EyePos()
	local angle = LocalPlayer():GetAimVector()
	local tar = {0,0}
	for _, ent in pairs(ents.GetAll()) do
		if EnemiesA(ent) and visible(ent) then
			local targetpos = ent:EyePos()
			local difr = (targetpos-position):Normalize()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs(difr)
			if difr < tar[2] or tar[1] == 0 then
				tar = {ent, difr}
			end
		end
	end
	return tar[1]
end

//locals
local SetViewAngles = _R.CUserCmd.SetViewAngles
local AimBot 
local ent
local pos
local Prediction
local Compensation
local Mypos 
local NSPos
local AntiSpread

function DuckAim(cmd)
	if NoSpreadHere then
	ent = Target()
	
	if ent != 0 then
    pos = ent:GetPos() + Vector(0,0,70)
	pos = pos:ToScreen()
  
  	Prediction = ent:GetVelocity() or Vector(0,0,0)
  
    Compensation = (ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))+Vector(0,0,GetConVarNumber("duck_aimplus")) + (Prediction *GetConVarNumber( "duck_aim_compensate") * FrameTime())
    Mypos = LocalPlayer():EyePos()
    NSPos = (Compensation - Mypos):Angle()		
	
	
	if AimBot == true then
    AntiSpread = PredictSpread(cmd, NSPos)
    SetViewAngles(cmd,AntiSpread)			
   
	
	end
	end
	end
	end
	
	
	concommand.Add("+duck_aimbot", function()
	hook.Add("Initialize", "NSCheck", Check)
    hook.Add("SetupMove", "NSMySetUpMove", mysetupmove)
    AimBot = true
	hook.Add("CreateMove", "Aim", DuckAim)

    end)
	 
	concommand.Add("-duck_aimbot", function() 
	hook.Remove("Initialize", "NSCheck")
    hook.Remove("SetupMove", "NSMySetUpMove")
    AimBot = true
	hook.Remove("CreateMove", "Aim")
	 
    end)

	//zoom
local function zoomy()
hook.Add("CalcView", "cool", function() 		 
	if GetConVarNumber("duck_zoom") == 1
	then
local FOV1 = GetConVarNumber("duck_zoom_amout")
		
		local viewpos1 = {} 
	
		viewpos1.angles = LocalPlayer():EyeAngles() 
			viewpos1.origin = LocalPlayer():GetShootPos() - LocalPlayer():GetAimVector():Angle():Forward()
              		viewpos1.fov = FOV1
	

		return viewpos1
end
end)
end
concommand.Add("duck_zoomy", zoomy)

local function zoom()
hook.Add("CalcView", "NR", function() 		 

		if GetConVarNumber("duck_zoom") == 1
then

		
local FOV = 90		
		
		if LocalPlayer():KeyDown(IN_USE) then
					RunConsoleCommand("duck_zoomy")

LocalPlayer():ConCommand("sensitivity " .. 1)

					else 
local FOV = 90
LocalPlayer():ConCommand("sensitivity " .. 4)

	local viewpos = {} 
	
	viewpos.angles = LocalPlayer():EyeAngles() 
	viewpos.origin = LocalPlayer():GetShootPos() - LocalPlayer():GetAimVector():Angle():Forward()
			viewpos.fov = FOV
		return viewpos

		
		
end
end
end)
end
hook.Add("Think", "zoom", zoom)





// END OF NO RECOIL





hook.Add( "HUDPaint", "Sex", function()

	local reds = Color(255, 255, 255, 0) 

		if GetConVarNumber("duck_laser_dot") == 1
then
reds = Color( 0, 255, 0, 10 )
else if GetConVarNumber("duck_laser_dot") == 0
then
  reds = Color( 0, 255, 0, 255 )
  end
  end
  
  if GetConVarNumber("duck_laser") == 1
  then
 local sex = LocalPlayer():GetViewModel()
 if sex == " " then
 
 else



		local bone = sex:LookupAttachment("muzzle")
 

	
	if bone == 0 then bone = sex:LookupAttachment("1") 
		end 
        if bone == 0 then bone = sex:LookupAttachment("laser") 
		 end
		 
		     if bone == 0 then bone = sex:LookupAttachment("spark") 
		 end
		 
		   if bone == 0 then bone = sex:LookupAttachment("0") 
		 end
	   if bone == 0 then bone = LocalPlayer():LookupAttachment("chest")
		 sex = LocalPlayer()
		 end

		 	   if bone == 0 then bone = LocalPlayer():LookupAttachment("chest")
		 sex = LocalPlayer()
		 end
	
	
	
	        cam.Start3D(EyePos(), EyeAngles())
	
		render.SetMaterial(Material("sprites/bluelaser1"))

		render.DrawBeam(sex:GetAttachment(bone).Pos, LocalPlayer():GetEyeTrace().HitPos, 3, 0, 0, reds)


		render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
		render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() - LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 20, 20, Color(0, 255, 0, 255), 0)
		cam.End3D()



end
end
end)

	


function Teamw(ent)    
	if GetConVarNumber("duck_teamw") >= 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end	
	return true	
end


function Enemiesw(ent)
	if !ent:IsValid() then return false end
	  if !ent:IsPlayer()  then return false end

 	  	if ent:IsPlayer() and !Teamw(ent) then return false end
	return true
end	
	

function Team(ent)    
	if GetConVarNumber("duck_team") >= 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end	
	return true	
end


function Enemies(ent)
	if !ent:IsValid() then return false end
	if !ent:Alive() then return false end
	if ent:Health() <1 then return false end
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end	 
	 if !ent:IsPlayer()  then return false end
 	  	if ent:IsPlayer() and !Team(ent) then return false end
	return true
end	



local Tagged = {""}
hook.Add("HUDPaint", "ESP", function()
			

	
				for _, ent in pairs(ents.GetAll()) do						  
			if ent:IsPlayer() then
			if Enemies(ent) then
			
	//pos		
			local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()
	
	//colors
local alpha = math.Clamp((10000 - ent:GetPos():Distance(LocalPlayer():GetShootPos())) * (25 / (500 - 100)), 100, 255)
local tc = team.GetColor(ent:Team())	
local vs 
local hp
local wbflash = (math.sin(RealTime()*3)+1)*122.5 
 
local weap
if ent.GetActiveWeapon then
							weap = ent:GetActiveWeapon()
						else
							weap = nil 
							end
 
	//color extensions
if ent:Health() <20 then hp = Color(255,0,0,alpha) elseif ent:Health() <50 then hp = Color(255,255,0,alpha) elseif ent:Health() >49 then hp = Color(0,255,0,alpha) end
if visible(ent) then vs = Color( 0, 255, 0, alpha ) else vs = Color( 255, 0, 0, alpha ) end
		
		//teh draw
		if GetConVarNumber("duck_esp") == 1 then
		
	
		draw.SimpleTextOutlined(ent:GetName(), "ScoreboardText", pos.x, pos.y, Color(tc.r, tc.g, tc.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
        end
     
	    if table.HasValue(Tagged, ent:Nick()) then
		draw.SimpleTextOutlined("FAGGOT", "ScoreboardText", pos.x, pos.y-60, Color(wbflash, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	    end
	 
		if GetConVarNumber("duck_esp_pvisible") == 1 && GetConVarNumber("duck_esp") == 1 then	
		draw.RoundedBox( 1, pos.x, pos.y+20, 20, 20, vs )
		end
		 
         if GetConVarNumber("duck_esp_pweapon") == 1 && GetConVarNumber("duck_esp") == 1 then			
		if ValidEntity(weap) then
		draw.SimpleTextOutlined(weap:GetPrintName(), "ScoreboardText", pos.x, pos.y-20, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		else
		draw.SimpleTextOutlined("NONE", "ScoreboardText", pos.x, pos.y-20, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		end      
end

	  if GetConVarNumber("duck_esp_phealth") == 1 && GetConVarNumber("duck_esp") == 1 then			
		draw.SimpleTextOutlined(ent:Health(), "ScoreboardText", pos.x, pos.y-40, hp, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		end
		
		
			if ent:GetFriendStatus() == "friend" && GetConVarNumber("duck_esp") == 1 then 
					Pos = ent:LocalToWorld(ent:OBBCenter())
					ScreenPos = Pos:ToScreen()
					if ScreenPos.visible then	     	   	   	   	
						center = ent:LocalToWorld(ent:OBBCenter())
						min,max = ent:WorldSpaceAABB()
						dim = max-min
	   
						front = ent:GetForward()*(dim.y/2)
						right = ent:GetRight()*(dim.x/2)
						top = ent:GetUp()*(dim.z/2)
						back = (ent:GetForward()*-1)*(dim.y/2)
						left = (ent:GetRight()*-1)*(dim.x/2)
						bottom = (ent:GetUp()*-1)*(dim.z/2)
						FRT = center+front+right+top
						BLB = center+back+left+bottom
						FLT = center+front+left+top
						BRT = center+back+right+top
						BLT = center+back+left+top
						FRB = center+front+right+bottom
						FLB = center+front+left+bottom
						BRB = center+back+right+bottom
			   
						FRT = FRT:ToScreen()
						BLB = BLB:ToScreen()
						FLT = FLT:ToScreen()
						BRT = BRT:ToScreen()
						BLT = BLT:ToScreen()
						FRB = FRB:ToScreen()
						FLB = FLB:ToScreen()
						BRB = BRB:ToScreen()					
						xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
						xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
						ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
						ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
						

							surface.SetDrawColor(wbflash, 0, 0, 255)
						surface.DrawOutlinedRect(xmin,ymin,xmax-xmin,ymax-ymin)
		end
		end
		
		end
	
	elseif ent:IsNPC() then
  
    local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()  
 
	if GetConVarNumber("duck_esp") == 1 &&  GetConVarNumber("duck_esp_npc") == 1 then
	draw.SimpleTextOutlined(ent:GetClass(), "DefaultSmall", pos.x + 27, pos.y - 10, Color(255,255,255,255), 2, 1, 1, Color(0, 0, 0, 255 ))
	end	
	
	elseif ent:IsWeapon() then
	
	    local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()  
	
	if GetConVarNumber("duck_esp") == 1 && GetConVarNumber("duck_esp_weapon") == 1 then
	if ent:GetMoveType() == 0 then
	else
		draw.SimpleTextOutlined(ent:GetPrintName(), "ScoreboardText", pos.x, pos.y+100, Color(255,0,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	end
	end
	end
	end

	for _, ent in pairs(ents.GetAll()) do						  
	if ent:IsWeapon() then
local position = ent:GetPos():ToScreen() 
	
local Weapons = {"weapon_ttt_teleport", "weapon_ttt_sipistol", "weapon_ttt_push", "weapon_ttt_phammer", "weapon_ttt_knife", "weapon_ttt_flaregun", "weapon_ttt_c4"}
	
	local gayfag = {"0", "255"}
	
	if GetConVarNumber("duck_esp_ttt") == 1 && GetConVarNumber("duck_esp") == 1 and table.HasValue(Weapons, ent:GetClass()) then

	draw.DrawText("TRAITOR", "ScoreboardText", position.x, position.y - 30, Color(table.Random(gayfag),table.Random(gayfag),table.Random(gayfag),255),1)		  
	 
	
	end
		end
         
			end
	
	
	
	end)
	
	


	hook.Add("HUDPaint", "crosshair", function()
		  if GetConVarNumber("duck_crosshair") == 1	
	then


	if GetConVarNumber("duck_crosshair_style") == 1
 then


 surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), GetConVarNumber("duck_crosshair_opacity"))  
  surface.DrawRect( ScrW() / 2 - 15, ScrH() / 2, 31, 1)
    	surface.DrawRect( ScrW() / 2, ScrH() / 2 - 14, 1, 30)

else 
	surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), GetConVarNumber("duck_crosshair_opacity"))  
	surface.DrawRect( (ScrW()/2)-1, (ScrH()/2)-5, 2, 10)
		surface.DrawRect( (ScrW()/2)-1, (ScrH()/2)-5, 2, 10)
		surface.DrawRect( (ScrW()/2)-5, (ScrH()/2)-1, 10, 2)
		surface.DrawRect( (ScrW()/2)-5, (ScrH()/2)-1, 10, 2)

if GetConVarNumber("duck_crosshair_style") == 2
then
surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), GetConVarNumber("duck_crosshair_opacity"))  	
	surface.DrawRect( (ScrW()/2)- 1, (ScrH()/2)-47, 2, 100 )
		surface.DrawRect( (ScrW()/2)-50, (ScrH()/2)-1, 100, 2 )
	
end
	end
	end
	
	if GetConVarNumber("duck_hud") == 1
	then
	

			
 
	draw.RoundedBox(30, 250, 10, 500, 80, Color(0, 0, 0, 200))  
draw.SimpleTextOutlined("No Aim at Team:" .. " " .. GetConVarNumber("duck_aim_team"), "ScoreboardText", 420, 30, Color(255, 0, 0, 255), 2, 1, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined("Name:" .. " " .. LocalPlayer():Nick(), "ScoreboardText", 410, 60, Color(0, 255, 0, 255), 2, 1, 1, Color(0, 0, 0, 255))
draw.SimpleTextOutlined("Recoil:" .. " " .. GetConVarNumber("duck_recoil"), "ScoreboardText", 550, 30, Color(255, 255, 0, 255), 2, 1, 1, Color(0, 0, 0, 255))
draw.SimpleTextOutlined("Trigger Bot:" .. " " .. GetConVarNumber("duck_trigger"), "ScoreboardText", 560, 60, Color(0, 0, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
draw.SimpleTextOutlined("Sv_Cheats:" .. " " .. GetConVarNumber("sv_cheats"), "ScoreboardText", 710, 60, Color(0, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
local tr = util.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector())
		local trace = util.TraceLine(tr)
		if trace.Hit and trace.HitNonWorld then
			local hite = trace.Entity
			local infoc = hite:GetClass()
			local infoh = hite:GetMaxHealth()

			
			draw.SimpleTextOutlined("Entity:" .. " " .. infoc, "ScoreboardText", 710, 30, Color(0, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))


end

	end
	end)
	

	
local Mat	
	local function Wallhack(ent)
 hook.Add("HUDPaint", "Wallhack", function()
	WallToggle = true 

if GetConVarNumber("Duck_Wallhack_Material") == 0 then
Mat = ""

elseif GetConVarNumber("Duck_Wallhack_Material") == 1 then
Mat = "debug/debugportals"

elseif GetConVarNumber("Duck_Wallhack_Material") == 2 then
Mat = "hlmv/debugmrmwireframe"
end
		
		if WallToggle then
		cam.Start3D(EyePos(),EyeAngles())
			for _, ent in pairs(ents.GetAll()) do		  
		 render.SetBlend( 1 )
				
				if ent:IsNPC() then
				if ent:GetMoveType() == 0
				then
				else
				if ValidEntity(ent) then
						if (not visible(ent)) then 
				 if GetConVarNumber("Duck_Wallhack_Material") == 1 or GetConVarNumber("Duck_Wallhack_Material") == 2
				 then
				 SetMaterialOverride( Material(Mat) )
                render.SetColorModulation( GetConVarNumber("Duck_Wallhack_Red"), GetConVarNumber("Duck_Wallhack_Green"), GetConVarNumber("Duck_Wallhack_Blue") )	
					ent:DrawModel()
                else
				ent:DrawModel()
				end
				end
				end
				end
				
		elseif ent:IsPlayer() and Enemiesw(ent) and ent:Alive() then 
	if (not visible(ent)) then 					
					if GetConVarNumber("Duck_Wallhack_Material") == 1 or GetConVarNumber("Duck_Wallhack_Material") == 2
				 then
					 SetMaterialOverride( Material(Mat) )
					        render.SetColorModulation( GetConVarNumber("Duck_Wallhack_Red"), GetConVarNumber("Duck_Wallhack_Green"), GetConVarNumber("Duck_Wallhack_Blue") )
					ent:DrawModel()
					   else
				ent:DrawModel()
				end
							end
						end
			end
			
		cam.End3D()


	end
   end)
end

	
	

	
concommand.Add("Duck_Wallhack_Toggle", function()
    if WallToggle then
   
   hook.Remove("HUDPaint", "Wallhack")
   
	WallToggle = false
    LocalPlayer():ChatPrint("Wallhack is now Off!")
	
	elseif !WallToggle then	
    LocalPlayer():ChatPrint("Wallhack is now On!")
	Wallhack()
	WallToggle = true		
    end

	end)

		
	

	
require("funcsolver")
CreateClientConVar("speedhack_slowspeed", 5, true, false)
CreateClientConVar("speedhack_speed", 5, true, false)
SetConvar(CreateConVar("sv_cheats", ""), 1)




function spo2()
		flash = (math.sin(RealTime()*3)+1)*122.5
	draw.SimpleTextOutlined("SpeedHack ON", "ScoreboardText",  1000, 599, Color(flash, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
end

function spo()
		flash = (math.sin(RealTime()*3)+1)*122.5
	draw.SimpleTextOutlined("SlowHack ON", "ScoreboardText",  1000, 599, Color(flash, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
end

concommand.Add("+wowspeed", function()
hook.Add("HUDPaint", "speedmeter", spo)
SetConvar(CreateConVar("host_timescale",""), GetConVarNumber("speedhack_slowspeed")) 
end)


concommand.Add("-wowspeed", function()
hook.Remove("HUDPaint", "speedmeter")
SetConvar(CreateConVar("host_timescale",""), 1) 
end)



concommand.Add("+gofast", function()
hook.Add("HUDPaint", "speedmeter", spo2)
SetConvar(CreateConVar("host_framerate",""), 0.1) 
end)


concommand.Add("-gofast", function()
hook.Remove("HUDPaint", "speedmeter")
SetConvar(CreateConVar("host_framerate",""), 0) 
end)


concommand.Add("+goslow", function()
SetConvar(CreateConVar("host_timescale",""), 0.08)
end)


concommand.Add("-goslow", function()
SetConvar(CreateConVar("host_timescale",""), 1)
end)


function unload()
 	hook.Remove("HUDPaint", "ESPWEAPON")
	hook.Remove("HUDPaint","lalwl")
 hook.Remove("CreateMove","SH_CreateMove")
 hook.Remove("Think","SH_Think")
 hook.Remove("HUDPaint", "hudd")
 hook.Remove("Think", "nigger")
	hook.Remove("Think", "lightt")		
 hook.Remove("HUDPaint", "Line")
hook.Remove("CalcView", "cool") 	
hook.Remove("CalcView", "NR") 		
hook.Remove("Think", "Norecoil", NoRecoil)
hook.Remove( "HUDPaint", "Sex")
 hook.Remove("HUDPaint", "ESPCROSS")
hook.Remove("HUDPaint", "ESPNPC")
	hook.Remove("Think","Acurracy")
	hook.Remove("Think", "light")
	hook.Remove("Think", "lighta")
	hook.Remove("Think", "lightb")
hook.Remove("HUDPaint", "ESPBEAM")
hook.Remove("HUDPaint", "ESPTTT")
	hook.Remove("Think", "fancy")
hook.Remove("HUDPaint", "ESP")
		hook.Remove("HUDPaint", "crosshair")
	hook.Remove("RenderScene", "Wallhack")
	hook.Remove("RenderScene", "Wallhack2")
hook.Remove("HUDPaint", "zedmin")
end


local FuncsolverPanel
local FuncsolverList

function CreateElitedButton(a, b)
    FUNCSOLVERBUTTON = vgui.Create("DButton")
    FUNCSOLVERBUTTON:SetSize(0, 10)
    FUNCSOLVERBUTTON:SetText(a)
    FUNCSOLVERBUTTON.DoClick = function()
        RunConsoleCommand(b)
    end	
    FuncsolverList:AddItem(FUNCSOLVERBUTTON)
end	


concommand.Add("duck_menu", function()


	
	FuncsolverPanel = vgui.Create("DFrame", TESTs)
    FuncsolverPanel:SetParent(TESTs)

	FuncsolverPanel:SetPos(20, 20)
	FuncsolverPanel:SetSize(450, 600)
	FuncsolverPanel:SetTitle("Duck Bot")
	FuncsolverPanel:SetVisible(true)
	FuncsolverPanel:SetDraggable(true)
	FuncsolverPanel:ShowCloseButton(true)
	FuncsolverPanel.Paint = function()
		draw.RoundedBox(0, 2, 2, FuncsolverPanel:GetWide(), FuncsolverPanel:GetTall(), Color(1, 1, 11, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, FuncsolverPanel:GetWide(), FuncsolverPanel:GetTall())	
	end	
	FuncsolverPanel:MakePopup() 
		

	
	FuncsolverList = vgui.Create("DPanelList", FuncsolverPanel)
	FuncsolverList:SetPos(30, 30)
	FuncsolverList:SetSize(400, 525)
	FuncsolverList.Paint = function()
		draw.RoundedBox(20, 2, 2, FuncsolverPanel:GetWide(), FuncsolverPanel:GetTall(), Color(55, 50, 55, 100),1)
		surface.SetDrawColor(color_white)
	end	
	FuncsolverList:SetSpacing(20)
	FuncsolverList:SetPadding(10)	
	FuncsolverList:EnableHorizontal(false)
	FuncsolverList:EnableVerticalScrollbar(true)	


local HelpImage = vgui.Create("DImageButton")
HelpImage:SetSize(10, 150)
HelpImage:SetImage("VGUI/entities/menu2")
 HelpImage.DoRightClick = function()
        
	unload()
	end
HelpImage.DoClick = function()
include("autorun/client/DuckBot.lua")
LocalPlayer():ChatPrint("Script loaded, check the console for instructions")
surface.PlaySound( "/quack/duck_1.mp3" )
print("---------------------------------------")
 print("||||||||||||||||")
  print("DUCK BOT")
   print("||||||||||||||||")
    print(" ")
     print("_____") 
     print("Binds:")    		 	 
     print(" ")	
      print("Use this bind for the host_timescale speedhack:")
       print(" ")
        print("Bind key +wowspeed")  
		   print(" ")	
      print("Use this bind for the host_framerate speedhack:")
       print(" ")
        print("Bind key +gofast")
   print(" ")	
      print("Use this bind for the aimbot:")
       print(" ")
        print("Bind key +duck_aimbot")  		
     print("_____")		
	
	print(" ")   
      print("______")    
	  print("AimBot: ")
      print(" ")	  
	   print("---The NoSpread Only works for css weapons & similar---, The nospread works by twiching your view to the exact spot where the bullet would hit the center due to the spread, this makes it hard for the target selection so be careful.")        
        print(" ")   
         print("You can add friends for the aimbot, other than steam friends. Double click someone's name in the List Players menu.")		
      print("______")		

	   print(" ")		
         print("_____________")		
         print("Miscellaneous:")		 	 
         print(" ")
          print("The NoSpread will take over your mouse1 bind, it will bind mouse1 to '+attack' if you have it off.")      
           print(" ")
	        print("The laser pointer can be turned on and off in the Misc menu. You can choose if you want it to draw a beam. ----The Laser Pointer MAY break on some weapons due to attachments problems. When this happens just select another weapon and reload the bot.----")
             print(" ")
              print("The Shoot Automaticly option will shoot if you have your crosshair on your target, this is very usefull for saving bullets")  
	 print("_____________")    
			 
			 print(" ")
             print("_________")
			 print("CrossHair: ")
			 print(" ") 
			 print("To change the size of the crosshair press the button in the crosshair menu and select a size. You can also change the color in the same menu.")	
             print("_________")  
			   
			    print(" ")
                print("___")
				print("ESP:")
				print(" ")
				 print("The Visible Box will turn green if you can see your targets.")  
                  print(" ")
					 print("The TTT ESP will search for any weapons that traitors can buy, this is inaccurate because some one may have killed a traitor and taken his weapon so pay attention on the start of the round.")
				print("___")     
				  
				  print(" ")
				  print("________")
				  print("WallHack:")
				   print(" ")
				   print("In the WallHack menu you can change the Wallhack's color and material.")
		          print("________")
						                  
					  print(" ")
					  print("_____")
					  print("CVars:")
					  print(" ")
					   print("You can change any Cvar value on the client, by entering the Cvar's name in the text box on the Cvars menu and selecting the value on the wang, this also has a sv_cheats 1 shortcut.")
			  	      print("_____")
					   
					   print(" ")
                       print("____")
					   print("Spam:")	                   
					   print(" ")
					   print("When you click Spam On, in the Spammer menu. You will spam tall buildings automaticly. Crashing the server if you let it on for an extensive period of time.")
	  	               print("____")
					   
					   print("R.I.P setinfo name")
					   
print(" ")
print(" ")
print(" ")

										print(" ")
										print("GIVE HIM BREAD MOTHERFUCKER")
							
print("---------------------------------------")


 end
	FuncsolverList:AddItem(HelpImage)	



	
	local SPS = vgui.Create("DNumSlider")
	SPS:SetSize(150, 50)
	SPS:SetText("Speedhack Speed")
	SPS:SetMin(0.1)
	SPS:SetMax(10)
	SPS:SetDecimals(1)
	SPS:SetConVar("speedhack_slowspeed")
	FuncsolverList:AddItem(SPS)	

local aimb = vgui.Create("DButton") 
aimb:SetToolTip("General Aimbot options")
aimb:SetText( "Aimbot" )
aimb:SetSize( 20, 20 )
aimb.DoClick = function ()
	Aimbotpanel = vgui.Create("DFrame", FuncsolverPanel)

	Aimbotpanel:Center()
	Aimbotpanel:SetSize(300, 250)
	Aimbotpanel:SetTitle("Aimbot")
	Aimbotpanel:SetVisible(true)
	Aimbotpanel:SetDraggable(true)
	Aimbotpanel:ShowCloseButton(true)
	Aimbotpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, Aimbotpanel:GetWide(), Aimbotpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, Aimbotpanel:GetWide(), Aimbotpanel:GetTall())	
	end	
	
	
		AimbotList = vgui.Create("DPanelList", Aimbotpanel)
	AimbotList:SetPos(30, 30)
	AimbotList:SetSize(250, 190)
	AimbotList:SetSpacing(10)
	AimbotList:SetPadding(10)	
	AimbotList:EnableHorizontal(false)
	AimbotList:EnableVerticalScrollbar(true)	

		local AimbotCat = vgui.Create("DCheckBoxLabel")
	AimbotCat:SetText("No Aim at Steam Friends")
	AimbotCat:SetConVar("duck_aim_friends")
	AimbotCat:SetValue(GetConVarNumber("duck_aim_friends"))
	AimbotCat:SizeToContents()
	AimbotList:AddItem(AimbotCat) 			

			
			local SPS = vgui.Create("DNumSlider")
	SPS:SetSize(150, 50)
	SPS:SetText("Offset(4 is default)")
	SPS:SetMin(-10)
	SPS:SetMax(30)
	SPS:SetDecimals(0)
	SPS:SetConVar("duck_aimplus")
AimbotList:AddItem(SPS)	
		
			local SPS = vgui.Create("DNumSlider")
	SPS:SetSize(150, 50)
	SPS:SetText("Compensation Offset(2 is default)")
	SPS:SetMin(2)
	SPS:SetMax(10)
	SPS:SetDecimals(0)
	SPS:SetConVar("duck_aim_compensate")
AimbotList:AddItem(SPS)	
				
			
			local AimbotCat = vgui.Create("DCheckBoxLabel")
	AimbotCat:SetText("No Aim at Team Mates")
	AimbotCat:SetConVar("duck_aim_team")
	AimbotCat:SetValue(GetConVarNumber("duck_aim_team"))
	AimbotCat:SizeToContents()
	AimbotList:AddItem(AimbotCat) 
	
		  
	Aimbotpanel:MakePopup()
end
FuncsolverList:AddItem(aimb)


	
  
local miscb = vgui.Create("DButton") 
miscb:SetToolTip("Removals and LaserSights Options")
miscb:SetText( "Misc" )
miscb:SetSize( 20, 20 )
miscb.DoClick = function ()
	Miscpanel = vgui.Create("DFrame", FuncsolverPanel)

	Miscpanel:Center()
	Miscpanel:SetSize(300, 375)
	Miscpanel:SetTitle("Miscellaneous")
	Miscpanel:SetVisible(true)
	Miscpanel:SetDraggable(true)
	Miscpanel:ShowCloseButton(true)
	Miscpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, Miscpanel:GetWide(), Miscpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, Miscpanel:GetWide(), Miscpanel:GetTall())	
	end	
	
	
		MiscList = vgui.Create("DPanelList", Miscpanel)
	MiscList:SetPos(30, 30)
	MiscList:SetSize(250, 315)
	MiscList:SetSpacing(10)
	MiscList:SetPadding(10)	
	MiscList:EnableHorizontal(false)
	MiscList:EnableVerticalScrollbar(true)	



			local ZA = vgui.Create("DNumSlider")
	ZA:SetSize(150, 50)
	ZA:SetText("Recoil")
	ZA:SetMin(0)
	ZA:SetMax(10)
	ZA:SetDecimals(0)
	ZA:SetConVar("duck_recoil")
		MiscList:AddItem(ZA)	

	local NSCat = vgui.Create("DCheckBoxLabel")
	NSCat:SetText("NoSpread")
	NSCat:SetConVar("duck_sys_nospread")
	NSCat:SetValue(GetConVarNumber("duck_sys_nospread"))
    NSCat:SizeToContents()
	MiscList:AddItem(NSCat) 

	
	
	local NoRecoilCat = vgui.Create("DCheckBoxLabel")
	NoRecoilCat:SetText("Zoom")
	NoRecoilCat:SetConVar("duck_zoom")
	NoRecoilCat:SetValue(GetConVarNumber("duck_zoom"))
	NoRecoilCat:SizeToContents()
	MiscList:AddItem(NoRecoilCat) 

		local ZA = vgui.Create("DNumSlider")
	ZA:SetSize(150, 50)
	ZA:SetText("Zoom Amout")
	ZA:SetMin(1)
	ZA:SetMax(100)
	ZA:SetDecimals(0)
	ZA:SetConVar("duck_zoom_amout")
		MiscList:AddItem(ZA)	



		
	
	 local LaserPointerCat = vgui.Create("DCheckBoxLabel")
	LaserPointerCat:SetText("Laser Pointer")
	LaserPointerCat:SetConVar("duck_laser")
	LaserPointerCat:SetValue(GetConVarNumber("duck_laser"))
	LaserPointerCat:SizeToContents()
	MiscList:AddItem(LaserPointerCat) 
	 
	 	 local LaserPointerCatCat = vgui.Create("DCheckBoxLabel")
	LaserPointerCatCat:SetText("Laser Pointer Night Mode")
	LaserPointerCatCat:SetConVar("duck_laser_dot")
	LaserPointerCatCat:SetValue(GetConVarNumber("duck_laser_dot"))
	LaserPointerCatCat:SizeToContents()
	MiscList:AddItem(LaserPointerCatCat) 
	
	local ShowRagdollsCat = vgui.Create("DCheckBoxLabel")
	ShowRagdollsCat:SetText("Show ragdolls")
	ShowRagdollsCat:SetConVar("cl_phys_timescale")
	ShowRagdollsCat:SetValue(GetConVarNumber("cl_phys_timescale"))
	ShowRagdollsCat:SizeToContents()
MiscList:AddItem(ShowRagdollsCat) 


	local ShowRagdollsCat = vgui.Create("DCheckBoxLabel")
	ShowRagdollsCat:SetText("Shoot Automaticly")
	ShowRagdollsCat:SetConVar("duck_trigger")
	ShowRagdollsCat:SetValue(GetConVarNumber("duck_trigger"))
	ShowRagdollsCat:SizeToContents()
MiscList:AddItem(ShowRagdollsCat) 
	


 TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Admins")
	TEB.DoClick = function()
	for _, ent in pairs( player.GetAll() ) do
		local admin = team.GetName( ent:Team() )
		
		if string.find( admin, "vip" ) then
			LocalPlayer():ChatPrint(  ent:Nick() .. " is a VIP" )
		
		elseif string.find( admin, "donator" ) then
			LocalPlayer():ChatPrint( ent:Nick() .. " is an Donator" )
		
		elseif string.find( admin, "operator" ) then
			LocalPlayer():ChatPrint(  ent:Nick() .. " is an Operator" )
		
		elseif string.find( admin, "moderator" ) then
			LocalPlayer():ChatPrint( ent:Nick() .. " is a Moderator" )
	
	
	   elseif ent:IsAdmin() and not ent:IsSuperAdmin( ) then
			LocalPlayer():ChatPrint(  ent:Nick() .. " is an Admin" )
		
		elseif ent:IsSuperAdmin() then
			LocalPlayer():ChatPrint( ent:Nick() .. " is a Superadmin" )
		
		end
	end
end

	MiscList:AddItem(TEB)


Miscpanel:MakePopup()
end
FuncsolverList:AddItem(miscb)


	
	
	
	

			
	CHAIR = vgui.Create("DButton")
	CHAIR:SetSize(0, 20)
	CHAIR:SetText("CrossHair")
	CHAIR:SetToolTip("Change Size and Color of the Crosshair")
	CHAIR.DoClick = function()
	
	Crosshairpanel = vgui.Create("DFrame", FuncsolverPanel)

	Crosshairpanel:Center()
	Crosshairpanel:SetSize(300, 400)
	Crosshairpanel:SetTitle("Crosshair")
	Crosshairpanel:SetVisible(true)
	Crosshairpanel:SetDraggable(true)
	Crosshairpanel:ShowCloseButton(true)
	Crosshairpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, Crosshairpanel:GetWide(), Crosshairpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, Crosshairpanel:GetWide(), Crosshairpanel:GetTall())	
	end	
	
	
		CrosshairList = vgui.Create("DPanelList", Crosshairpanel)
	CrosshairList:SetPos(30, 30)
	CrosshairList:SetSize(250, 335)
	CrosshairList:SetSpacing(10)
	CrosshairList:SetPadding(10)	
	CrosshairList:EnableHorizontal(false)
	CrosshairList:EnableVerticalScrollbar(true)	

	local CR = vgui.Create("DNumSlider")
	CR:SetSize(150, 50)
	CR:SetText("CrossHair Red")
	CR:SetMin(0)
	CR:SetMax(255)
	CR:SetDecimals(1)
	CR:SetConVar("duck_crosshair_red")
	CrosshairList:AddItem(CR)	
	
	local CR = vgui.Create("DNumSlider")
	CR:SetSize(150, 50)
	CR:SetText("CrossHair Green")
	CR:SetMin(0)
	CR:SetMax(255)
	CR:SetDecimals(1)
	CR:SetConVar("duck_crosshair_green")
	CrosshairList:AddItem(CR)	
	
	local CR = vgui.Create("DNumSlider")
	CR:SetSize(150, 50)
	CR:SetText("CrossHair Blue")
	CR:SetMin(0)
	CR:SetMax(255)
	CR:SetDecimals(1)
	CR:SetConVar("duck_crosshair_blue")
	CrosshairList:AddItem(CR)	
	
	local CR = vgui.Create("DNumSlider")
	CR:SetSize(150, 50)
	CR:SetText("CrossHair Opacity")
	CR:SetMin(0)
	CR:SetMax(255)
	CR:SetDecimals(0)
	CR:SetConVar("duck_crosshair_opacity")
	CrosshairList:AddItem(CR)	


  
local CRSTbutton = vgui.Create("DButton") 
CRSTbutton:SetText( "Size" )
CRSTbutton:SetSize( 20, 20 )
CRSTbutton.DoClick = function ()
    local CRSTbuttonChoice = DermaMenu()
    CRSTbuttonChoice:AddOption("Small", function() 	RunConsoleCommand("duck_crosshair_style", "0") end ) 
    CRSTbuttonChoice:AddOption("Medium", function() 	RunConsoleCommand("duck_crosshair_style", "1") end )
    CRSTbuttonChoice:AddOption("Large", function() 	RunConsoleCommand("duck_crosshair_style", "2") end )
CRSTbuttonChoice:Open() 
end
CrosshairList:AddItem(CRSTbutton)		
	
	local CrosshairCat = vgui.Create("DCheckBoxLabel")
	CrosshairCat:SetText("Crosshair")
	CrosshairCat:SetConVar("duck_crosshair")
	CrosshairCat:SetValue(GetConVarNumber("duck_crosshair"))
	CrosshairCat:SizeToContents()
	CrosshairList:AddItem(CrosshairCat) 
	
	
		local ShowRagdollsCat = vgui.Create("DCheckBoxLabel")
	ShowRagdollsCat:SetText("Head Up Display")
	ShowRagdollsCat:SetConVar("duck_hud")
	ShowRagdollsCat:SetValue(GetConVarNumber("duck_hud"))
	ShowRagdollsCat:SizeToContents()
CrosshairList:AddItem(ShowRagdollsCat) 
	
	
	Crosshairpanel:MakePopup() 
	end	

	
	FuncsolverList:AddItem(CHAIR)	
	

		
TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("ESP")
	TEB:SetToolTip("Show Name, Health & other useful information about targets.")
	TEB.DoClick = function()
    	ESPpanel = vgui.Create("DFrame")
	ESPpanel:SetParent(FuncsolverPanel)
	ESPpanel:Center()
	ESPpanel:SetSize(260, 250)
	ESPpanel:SetTitle("ESP")
	ESPpanel:SetVisible(true)
	ESPpanel:SetDraggable(true)
	ESPpanel:ShowCloseButton(true)
	ESPpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, ESPpanel:GetWide(), ESPpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, ESPpanel:GetWide(), ESPpanel:GetTall())	
	end	
	
	
		ESPList = vgui.Create("DPanelList", ESPpanel)
	ESPList:SetPos(30, 30)
	ESPList:SetSize(210, 210)
	ESPList:SetSpacing(10)
	ESPList:SetPadding(10)	
	ESPList:EnableHorizontal(false)
	ESPList:EnableVerticalScrollbar(true)	
	
	

	

	local ESPCatCat = vgui.Create("DCheckBoxLabel")
	ESPCatCat:SetText("ESP On")
	ESPCatCat:SetConVar("duck_esp")
	ESPCatCat:SetValue(GetConVarNumber("duck_esp"))
	ESPCatCat:SizeToContents()
	ESPList:AddItem(ESPCatCat) 

	
		local ESPCat = vgui.Create("DCheckBoxLabel")
	ESPCat:SetText("Only Draw Enemies")
	ESPCat:SetConVar("duck_team")
	ESPCat:SetValue(GetConVarNumber("duck_team"))
	ESPCat:SizeToContents()
	ESPList:AddItem(ESPCat) 
	
		local ESPCat = vgui.Create("DCheckBoxLabel")
	ESPCat:SetText("Show Health")
	ESPCat:SetConVar("duck_esp_phealth")
	ESPCat:SetValue(GetConVarNumber("duck_esp_phealth"))
	ESPCat:SizeToContents()
	ESPList:AddItem(ESPCat) 


	local ESPCatCatCatCat = vgui.Create("DCheckBoxLabel")
	ESPCatCatCatCat:SetText("Show NPCs")
	ESPCatCatCatCat:SetConVar("duck_esp_npc")
	ESPCatCatCatCat:SetValue(GetConVarNumber("duck_esp_npc"))
	ESPCatCatCatCat:SizeToContents()
	ESPList:AddItem(ESPCatCatCatCat) 
	
    	
	local ESPESPbEAM = vgui.Create("DCheckBoxLabel")
	ESPESPbEAM:SetText("Show Weapons")
	ESPESPbEAM:SetConVar("duck_esp_pweapon")
	ESPESPbEAM:SetValue(GetConVarNumber("duck_esp_pweapon"))
	ESPESPbEAM:SizeToContents()
	ESPList:AddItem(ESPESPbEAM) 
   
	local ESPESPbEAM = vgui.Create("DCheckBoxLabel")
	ESPESPbEAM:SetText("Show Weapons On The Ground")
	ESPESPbEAM:SetConVar("duck_esp_weapon")
	ESPESPbEAM:SetValue(GetConVarNumber("duck_esp_weapon"))
	ESPESPbEAM:SizeToContents()
	ESPList:AddItem(ESPESPbEAM) 

	


		local ShowRagdollsCat = vgui.Create("DCheckBoxLabel")
	ShowRagdollsCat:SetText("Show Visible Box")
	ShowRagdollsCat:SetConVar("duck_esp_pvisible")
	ShowRagdollsCat:SetValue(GetConVarNumber("duck_esp_pvisible"))
	ShowRagdollsCat:SizeToContents()
ESPList:AddItem(ShowRagdollsCat) 


			local ShowRagdollsCat = vgui.Create("DCheckBoxLabel")
	ShowRagdollsCat:SetText("TTT Mode")
	ShowRagdollsCat:SetConVar("duck_esp_ttt")
	ShowRagdollsCat:SetValue(GetConVarNumber("duck_esp_ttt"))
	ShowRagdollsCat:SizeToContents()
ESPList:AddItem(ShowRagdollsCat) 


	
	ESPpanel:MakePopup() 
 	end	
	FuncsolverList:AddItem(TEB)	
	


		
	  TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Wall Hack")
    TEB:SetToolTip("Change the Color of the Wallhack")
	TEB.DoClick = function()
	
	Wallhackpanel = vgui.Create("DFrame")
	Wallhackpanel:SetParent(FuncsolverPanel)
	Wallhackpanel:Center()
	Wallhackpanel:SetSize(300, 240)
	Wallhackpanel:SetTitle("Wallhack")
	Wallhackpanel:SetVisible(true)
	Wallhackpanel:SetDraggable(true)
	Wallhackpanel:ShowCloseButton(true)
	Wallhackpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, Wallhackpanel:GetWide(), Wallhackpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, Wallhackpanel:GetWide(), Wallhackpanel:GetTall())	
	end	
	
	
		WallhackList = vgui.Create("DPanelList", Wallhackpanel)
	WallhackList:SetPos(30, 30)
	WallhackList:SetSize(250, 195)
	WallhackList:SetSpacing(10)
	WallhackList:SetPadding(10)	
	WallhackList:EnableHorizontal(false)
	WallhackList:EnableVerticalScrollbar(true)	
	
	local WallhackCat = vgui.Create("DCheckBoxLabel")
	WallhackCat:SetText("Only Draw Enemies")
	WallhackCat:SetConVar("duck_teamw")
	WallhackCat:SetValue(GetConVarNumber("duck_teamw"))
	WallhackCat:SizeToContents()
	
	WallhackList:AddItem(WallhackCat) 
	
	local label = vgui.Create("DLabel")
label:SetText("Material")
label:SizeToContents()
WallhackList:AddItem(label)	

	
	local SM 
	if GetConVarNumber("duck_wallhack_material") == 0 then
	SM = "No Wall"
	elseif GetConVarNumber("duck_wallhack_material") == 1 then
	SM = "Full"
    elseif GetConVarNumber("duck_wallhack_material") == 2 then
	SM = "WireFrame"
	end
		local Wallhackbutton = vgui.Create("DButton") 
Wallhackbutton:SetText( SM )
Wallhackbutton:SetSize( 20, 20 )
Wallhackbutton.DoClick = function ()
    local WallhackbuttonChoice = DermaMenu()
      WallhackbuttonChoice:AddOption("No Wall", function() 	RunConsoleCommand("duck_wallhack_material", "0") end ) 
	WallhackbuttonChoice:AddOption("Full", function() 	RunConsoleCommand("duck_wallhack_material", "1")  end ) 
 WallhackbuttonChoice:AddOption("WireFrame", function() 	RunConsoleCommand("duck_wallhack_material", "2")  end ) 

 
 WallhackbuttonChoice:Open() 
end
	WallhackList:AddItem(Wallhackbutton)		
	
	
	
			local WallhackCat = vgui.Create("DCheckBoxLabel")
	WallhackCat:SetText("Red")
	WallhackCat:SetConVar("duck_wallhack_Red")
	WallhackCat:SetValue(GetConVarNumber("duck_wallhack_Red"))
	WallhackCat:SizeToContents()
	
	WallhackList:AddItem(WallhackCat) 


		
			local WallhackCat = vgui.Create("DCheckBoxLabel")
	WallhackCat:SetText("Green")
	WallhackCat:SetConVar("duck_wallhack_Green")
	WallhackCat:SetValue(GetConVarNumber("duck_wallhack_Green"))
	WallhackCat:SizeToContents()
	
	WallhackList:AddItem(WallhackCat) 
	
		
			local WallhackCat = vgui.Create("DCheckBoxLabel")
	WallhackCat:SetText("Blue")
	WallhackCat:SetConVar("duck_wallhack_Blue")
	WallhackCat:SetValue(GetConVarNumber("duck_wallhack_Blue"))
	WallhackCat:SizeToContents()
	
	WallhackList:AddItem(WallhackCat) 


	

	
		WLON = vgui.Create("DButton")
	WLON:SetSize(0, 20)
	WLON:SetText("Wall Hack On")
	WLON.DoClick = function()
	RunConsoleCommand("duck_wallhack_toggle")
 	end	
WallhackList:AddItem(WLON)	
	

	

	Wallhackpanel:MakePopup() 
 	end
	
	FuncsolverList:AddItem(TEB)	

	
	 TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Cvars")
    TEB:SetToolTip("Change any CVar, Clientside!")
	TEB.DoClick = function()
    
	
		CVarspanel = vgui.Create("DFrame")
	CVarspanel:SetParent(FuncsolverPanel)
	CVarspanel:Center()
	CVarspanel:SetSize(260, 200)
	CVarspanel:SetTitle("Cvars")
	CVarspanel:SetVisible(true)
	CVarspanel:SetDraggable(true)
	CVarspanel:ShowCloseButton(true)
	CVarspanel.Paint = function()
		draw.RoundedBox(2, 2, 2, CVarspanel:GetWide(), CVarspanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, CVarspanel:GetWide(), CVarspanel:GetTall())	
	end	
	
	
		CVarsList = vgui.Create("DPanelList", CVarspanel)
	CVarsList:SetPos(30, 30)
	CVarsList:SetSize(210, 155)
	CVarsList:SetSpacing(10)
	CVarsList:SetPadding(10)	
	CVarsList:EnableHorizontal(false)
	CVarsList:EnableVerticalScrollbar(true)	

 	
	
	OverwriteTextEntry = vgui.Create("DTextEntry")
    OverwriteTextEntry:SetText("Enter Convar")
	OverwriteTextEntry.Think = function()
    
	end
    CVarsList:AddItem(OverwriteTextEntry)	
	
    label= vgui.Create("DLabel", myParent)
    label:SetText("Select the CVar value")
    label:SizeToContents() 
	CVarsList:AddItem(label)	
	 
	local Wang = vgui.Create( "DNumberWang")
	Wang:SetMinMax( 0 , 1000)
    Wang:SetDecimals(0)	
	CVarsList:AddItem(Wang)
    

	
	CVSET = vgui.Create("DButton")
	CVSET:SetSize(0, 20)
	CVSET:SetText("Set it!")
	CVSET.DoClick = function()
	SetConvar(CreateConVar(OverwriteTextEntry:GetValue(),""), Wang:GetValue())
 	end	
	 CVarsList:AddItem(CVSET)	

	TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Sv_cheats 1")
	TEB.DoClick = function()
	SetConvar(CreateConVar("sv_cheats", ""), 1)
 	end	
	 CVarsList:AddItem(TEB)	

	
	CVarspanel:MakePopup() 
 	end	
	FuncsolverList:AddItem(TEB)	
	 
	
	  
	 
	 
	TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Spammer")
    TEB:SetToolTip("Spam Tall buildings")
	TEB.DoClick = function()
	
		Spamerpanel = vgui.Create("DFrame")
	Spamerpanel:SetParent(FuncsolverPanel)
	Spamerpanel:Center()
	Spamerpanel:SetSize(160, 120)
	Spamerpanel:SetTitle("Spammer")
	Spamerpanel:SetVisible(true)
	Spamerpanel:SetDraggable(true)
	Spamerpanel:ShowCloseButton(true)
	Spamerpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, Spamerpanel:GetWide(), Spamerpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, Spamerpanel:GetWide(), Spamerpanel:GetTall())	
	end	
	
	
		SpamerList = vgui.Create("DPanelList", Spamerpanel)
	SpamerList:SetPos(30, 30)
	SpamerList:SetSize(100, 70)
	SpamerList:SetSpacing(10)
	SpamerList:SetPadding(10)	
	SpamerList:EnableHorizontal(false)
	SpamerList:EnableVerticalScrollbar(true)	

	
		
	
function spamon()
timer.Create("spam1", 0.001, 0, function() RunConsoleCommand("gm_spawn", "models/props_buildings/building_002a.mdl") end)
end
concommand.Add("spama", spamon)
	
	TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Spam on")
	TEB.DoClick = function()
	RunConsoleCommand("spama")
	end	
	SpamerList:AddItem(TEB)	
	
	
function spamoff()
timer.Destroy("spam1")
end
concommand.Add("spamb", spamoff)
	
	TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Spam off")
	TEB.DoClick = function()
	RunConsoleCommand("spamb")
	end	
	SpamerList:AddItem(TEB)		
	
	
	
			
function crashon()
timer.Create("crash", 0.001, 0, function() RunConsoleCommand("gm_spawn", "models/props_junk/wood_pallet001a.mdl") end)
end
concommand.Add("crashlol", crashon)

function crashoff()
timer.Destroy("crash")
end
concommand.Add("nocrashlol", crashoff)
	
	Spamerpanel:MakePopup() 
 	end	
	FuncsolverList:AddItem(TEB)	
		

	
	  TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("List Players")
	TEB:SetToolTip("Misc Actions On Players")
	TEB.DoClick = function()

	


	LPpanel = vgui.Create("DFrame")
	LPpanel:SetParent(FuncsolverPanel)
	LPpanel:Center()
	LPpanel:SetSize(350, 440)
	LPpanel:SetTitle("Player List")
	LPpanel:SetVisible(true)
	LPpanel:SetDraggable(true)
	LPpanel:ShowCloseButton(true)
	LPpanel.Paint = function()
		draw.RoundedBox(2, 2, 2, LPpanel:GetWide(), LPpanel:GetTall(), Color(0, 0, 0, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, LPpanel:GetWide(), LPpanel:GetTall())	
	end	
	
	
		LPList = vgui.Create("DPanelList", LPpanel)
	LPList:SetPos(30, 30)
	LPList:SetSize(300, 390)
	LPList:SetSpacing(10)
	LPList:SetPadding(10)	
	LPList:EnableHorizontal(false)
	LPList:EnableVerticalScrollbar(true)	

 
local DermaListView = vgui.Create("DListView")
DermaListView:SetSize(450, 300)
DermaListView:SetMultiSelect(false)
DermaListView:AddColumn("Name") -- Add column
DermaListView:AddColumn("Friend") -- Add column


for k,ent in pairs(player.GetAll()) do 

 local check

 if table.HasValue(Friends, ent:Nick())
 then check = "YES!"
 else
 check = "NO!"
 end

 DermaListView:AddLine(ent:Nick(), check) -- Add lines
 end

 
 DermaListView.DoDoubleClick = function(parent, index, list)
    local MenuButtonOptions = DermaMenu() -- Creates the menu
    MenuButtonOptions:AddOption("Add To AimBot Friends", function() table.insert(Friends,list:GetValue(1)) end) 
					  MenuButtonOptions:AddOption("Tag", function() table.insert(Tagged,list:GetValue(1)) end) 
	MenuButtonOptions:Open() -- Open the menu AFTER adding your options
end

 LPList:AddItem(DermaListView)
 	
	TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Clear AimBot Friends")
	TEB.DoClick = function()
	table.Empty(Friends)
	end	
	LPList:AddItem(TEB)		

		TEB = vgui.Create("DButton")
	TEB:SetSize(0, 20)
	TEB:SetText("Clear Tagged Players")
	TEB.DoClick = function()
	table.Empty(Tagged)
	end	
	LPList:AddItem(TEB)		
	
	
	
	LPpanel:MakePopup() 

	
	end
	FuncsolverList:AddItem(TEB)	
		


	 
	concommand.Add("duck_menu_close", function()
	FuncsolverPanel:Close()
	
end)
end)

print("DuckBot Loaded")