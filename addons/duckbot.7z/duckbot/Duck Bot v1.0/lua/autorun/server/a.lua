concommand.Add("qwerty", function() 
local winsound = "dr/the_horror1.wav"
for _, ent in pairs(player.GetAll()) do						  
ent:SendLua("LocalPlayer():EmitSound(\"" .. winsound .. "\", 100, 100)")
end
end)