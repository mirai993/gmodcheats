require("localcommand")

  surface.CreateFont("tf2build", 20, 550, true, false, "crit")
 local weapon = LocalPlayer():GetViewModel()
 local sound 
 local critcolor 
 local effectdata = EffectData()

 function dot()
   cam.Start3D(EyePos(), EyeAngles())
		render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
		render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() - LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 20, 20, Color(255, 0, 0, 255), 0)
		cam.End3D()
end
 
 
 concommand.Add("+chargeshot", function() hook.Add("HUDPaint", "pcharge", dot) end)
 concommand.Add("-chargeshot", function() hook.Remove("HUDPaint", "pcharge") 
  RunConsoleCommand("+attack") 
 timer.Simple(0.02, function()  RunConsoleCommand("-attack")  end)
 end)

						

 function crit()
 draw.DrawText("CRIT HIT", "crit", ScrW() / 2, ScrH() / 2, critcolor ,1)
 end

 
 
   function wepnom()
  hook.Remove("RenderScene", "Wep")
  weapon:SetMaterial("")
   weapon:SetColor(255,255,255,255)
 end

 function wepyesm()
 	 hook.Add("RenderScene", "Wep", function()
 weapon:SetMaterial("models/shiny")
  weapon:SetColor(0,255,0,255)
 end)  
end
 
 
 function wepno()
  hook.Remove("RenderScene", "Wep")
  weapon:SetMaterial("")
   weapon:SetColor(255,255,255,255)
 end

 function wepyes()
 	 hook.Add("RenderScene", "Wep", function()
 weapon:SetMaterial("models/shiny")
  weapon:SetColor(255,0,0,255)
 end)  
end
 
 
function GAMEMODE:ScalePlayerDamage(ply,hitgroup,dmginfo)
      
		
		if dmginfo:GetAttacker() == LocalPlayer() then
			      
						if ( hitgroup == HITGROUP_HEAD ) then
							critcolor = Color(255,0,0,255)
							sound = Sound( "player/crit_hit5.wav" )
							
							effectdata:SetStart( ply:GetPos()+Vector(0,0,70)) 
                            effectdata:SetOrigin(ply:GetPos()+Vector(0,0,70))
						    effectdata:SetScale( 1 )
                            util.Effect( "StriderBlood", effectdata )	
							
							wepyes()
							
							hook.Add("HUDPaint", "TF2", crit)
							timer.Simple(0.3, function() hook.Remove("HUDPaint", "TF2") wepno() end)
							
							LocalPlayer():EmitSound( sound )
						end			   


						if dmginfo:GetDamage() >40 and not( hitgroup == HITGROUP_HEAD ) then     
						critcolor = Color(0,255,0,255)
						sound = Sound( "player/crit_hit_mini3.wav" )
						
							wepyesm()
						hook.Add("HUDPaint", "TF2", crit)
						timer.Simple(0.3, function() hook.Remove("HUDPaint", "TF2") wepnom() end)
						
						LocalPlayer():EmitSound( sound )
						end
					end
				end
