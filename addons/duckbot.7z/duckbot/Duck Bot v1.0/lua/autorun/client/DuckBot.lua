
print( "DuckBot Loading" )

local include = include;
local require = require;

require ( "concommand" );
require ( "saverestore" );
require ( "gamemode" );
require ( "weapons" );
require ( "hook" );
require ( "timer" );
require ( "schedule" );
require ( "scripted_ents" );
require ( "player_manager" );
require ( "numpad" );
require ( "team" );
require ( "undo" );
require ( "cleanup" );
require ( "duplicator" );
require ( "constraint" );
require ( "construct" );
require ( "filex" );
require ( "vehicles" );
require ( "usermessage" );
require ( "list" );
require ( "cvars" );
require ( "http" );
require ( "datastream" );
require ( "draw" );
require ( "markup" );
require ( "effects" );
require ( "killicon" );
require ( "spawnmenu" );
require ( "controlpanel" );
require ( "presets" );
require ( "cookie" );

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
local surface = surface
local draw = draw
local cam = cam
local input = input
local os = os
local render = render

local Entity = Entity
local Player = Player
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector
local GetConVarNumber = GetConVarNumber


require( "syshack" );
require("localcommand")
CreateClientConVar("duck_speed", 5, true, false)

CreateClientConVar("Duck_Wallhack_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Thickness", 0, true, false)
CreateClientConVar("Duck_Wallhack_Material", 0, true, false)
CreateClientConVar("Duck_Wallhack_Relative", 0, true, false)

CreateClientConVar("duck_crosshair_red", 255, true, false)
CreateClientConVar("duck_crosshair_green", 255, true, false)
CreateClientConVar("duck_crosshair_blue", 255, true, false)

CreateClientConVar("Duck_crosshair_R", 0, true, false)
CreateClientConVar("Duck_crosshair_G", 0, true, false)
CreateClientConVar("Duck_crosshair_B", 0, true, false)
//wtf messy way lol 



CreateClientConVar("duck_esp", 0, true, false)
CreateClientConVar("duck_esp_type", 0, true, false)
CreateClientConVar("duck_esp_pvisible", 0, true, false)
CreateClientConVar("duck_esp_pweapon", 0, true, false)
CreateClientConVar("duck_esp_phealth", 0, true, false)
CreateClientConVar("duck_esp_weapon", 0, true, false)
CreateClientConVar("duck_esp_npc", 0, true, false)
CreateClientConVar("duck_esp_ttt", 0, true, false)

CreateClientConVar("duck_laser", 0, true, false)
CreateClientConVar("duck_laser_dot", 0, true, false)

CreateClientConVar("duck_crosshair", 1, true, false)
CreateClientConVar("duck_crosshair_style", 1, true, false)
CreateClientConVar("duck_fullbright", 0, true, false)

CreateClientConVar("duck_zoom", 0, true, false)

CreateClientConVar("duck_team", 0, true, false)
CreateClientConVar("duck_teamw", 0, true, false)


CreateClientConVar("duck_trigger", 0, true, false) 
CreateClientConVar("duck_hud", 1, true, false)

CreateClientConVar("duck_sys_nospread", 0, true, false)
CreateClientConVar("duck_sys_nospread_onmethod", 0, true, false)

CreateClientConVar("duck_aim_friends", 0, true, false) 
CreateClientConVar("duck_aim_fov", 0, true, false)  
CreateClientConVar("duck_aim_team", 0, true, false)     
CreateClientConVar("duck_aim_plus", 4, true, false )
CreateClientConVar("duck_aim_comp", 45, true, false )
CreateClientConVar("duck_aim_mode", 0, true, false)  
CreateClientConVar("duck_aim_npc", 0, true, false)   
CreateClientConVar("duck_aim_auto", 0, true, false)   
CreateClientConVar("duck_aim_reload", 0, true, false) 
CreateClientConVar("duck_recoil", 0, true, false) 
CreateClientConVar("duck_radar", 0, true, false) 

CreateClientConVar("duck_spam_time", 0.01, true, false) 

CreateClientConVar("duck_cvar_spoof", 0, true, false) 
CreateClientConVar("duck_spin", 0, true, false) 
CreateClientConVar("duck_autofire", 0, true, false) 
CreateClientConVar("duck_barrel", 0, true, false) 


local function head(ent) 
        local headbone = ent:LookupBone("ValveBiped.Bip01_Head1") 
        return ent:GetBonePosition(headbone) 
end 

local function visible(ent) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = head(ent),filter = {LocalPlayer(), ent}} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end 
	
/*
local cone,view_adjust,num_shots,C_WEP,last_wep,ME
 
NOSPREAD = false 
ME = LocalPlayer()
 
CONFIG = {}
CONFIG.weapons = {}

CONFIG.weapons["^weapon_pistol$"] = {cone = 0.00873}
CONFIG.weapons["^weapon_ar2$"] = {cone = 0.02618}
CONFIG.weapons["^weapon_shotgun$"] = {cone = 0.08716}
CONFIG.weapons["^weapon_smg1$"] = {cone = 0.04362}
CONFIG.weapons["^weapon_zs_zombie$"] = {cone = 0.00000}
CONFIG.weapons["^weapon_zs_fastzombie$"] = {cone = 0.00000}
CONFIG.weapons["^weapon_zs_fastzombie$"] = {cone = 0.00000}
 
local function GetWepVal(t, v, i)
        if not t then return "NULL" end
        if t[v] then
                return t[v]
        end
        if t.Primary and t.Primary[v] then
                return t.Primary[v]
        end
        if t["Primary"..v] then
                return t["Primary"..v]
        end
        if t["data"] then
                for _,d in pairs(t["data"]) do
                        if type(d)=="table" and d[v] then return d[v] end
                end
        end
        if t.BaseClass and (i or 0)<10 then
                return GetWepVal(t.BaseClass, v, (i or 0)+1)
        end
        return nil
end
 
hook.Add("Think","SH_Think",function()
        if not ValidEntity(ME) then return end
        if not ME:IsPlayer() then return end
        C_WEP = ME:GetActiveWeapon()
        if not C_WEP then return end
        if C_WEP ~= last_wep then
                last_wep = C_WEP
                if C_WEP and C_WEP:IsValid() then
                        local tab = C_WEP:GetTable()
                        function tab:ViewModelDrawn()
                                if WinIsOn and OnViewModelRender then
                                        OnViewModelRender()
                                end
                        end
                        local override = {}
                        for class, settings in pairs(CONFIG.weapons) do
                                if string.match(string.lower(C_WEP:GetClass()), class) then
                                        override = settings
                                        break
                                end
                        end
                        cone = override.cone or tonumber(GetWepVal(tab, "Cone")) or 0
                        num_shots = override.num_shots or tonumber(GetWepVal(tab, "NumShots")) or 0
                        inverse_vm_yaw = tab.Base--override.inverse_vm_yaw
                        inverse_vm_pitch = override.inverse_vm_pitch
                        strange_weapon = override.no_rapid
                        muzzle = C_WEP:LookupAttachment("muzzle")
                        if override.automatic ~= nil then
                                automatic = override.automatic
                        else
                                automatic = GetWepVal(tab, "Automatic")
                        end
                        if tab and tab.Primary then  end
                else
                        cone = 0
                        automatic = true
                end
        end
end)
 
local inited = false
local real_view,cv_sensitivity,sensitivity

hook.Add("CreateMove","SH_CreateMove",function(UCMD)
        if not inited then
                inited = true
                real_view = UCMD:GetViewAngles()
                cv_sensitivity = GetConVar("sensitivity")
        end
        sensitivity = cv_sensitivity:GetFloat()/200
        real_view = strange_weapon and UCMD:GetViewAngles() or Angle(math.max(math.min(real_view.p+UCMD:GetMouseY()*sensitivity, 90), -90),real_view.y-UCMD:GetMouseX()*sensitivity,0)


		
	function asa()
	 	local viewpos = {} 
	
	viewpos.angles = (LocalPlayer():EyeAngles() + real_view) - LocalPlayer():EyeAngles() 

			viewpos.fov = FOV
		return viewpos
end

		met = UCMD:GetButtons() & IN_ATTACK ~= IN_ATTACK	
		if met then real_view = UCMD:GetViewAngles() return end
	
	

      
	  
concommand.Add("+duck_ns", function()
if GetConVarNumber("duck_sys_nospread") == 1 then

  hook.Add("CalcView", "Na", asa) 	
   hook.Add("Think", "Norecosil", asa)
   else
end   	  
	  end)
concommand.Add("-duck_ns", function()	  
	
	hook.Remove("CalcView", "Na") 	
   hook.Remove("Think", "Norecosil")

   end)

        cone = cone or 0
       
	   if GetConVarNumber("duck_sys_nospread") == 1
        then
		NOSPREAD = true
	
		if cone == 0  then return end
       
        view_adjust = Angle(real_view.p, real_view.y, real_view.r)
 
        view_adjust = hack.CompensateWeaponSpread(UCMD, Vector(-cone, -cone, -cone), view_adjust:Forward()):Angle()
        UCMD:SetViewAngles(view_adjust)



		end
		end)

function ToggleF()
if GetConVarNumber("duck_sys_nospread") == 1 then
LocalCommand("bind mouse1 +duck_nospread")
 else
LocalCommand("bind mouse1 +attack")
 end
 end
	*/  
	   
	  local function NoRecoil()
       //I'm just leaving this here so i don't have to add a new hook. I know this is a messy way, i can't think of anyother method
local wep = LocalPlayer():GetActiveWeapon()
if not wep then return end      
if wep and wep:IsValid() then

local tabe = wep:GetTable()

        
                        if tabe and tabe.Primary && GetConVarNumber("duck_recoil") == 1 then tabe.Primary.Recoil = 0  end
        end
                
end

hook.Add("Think","Acurracy", NoRecoil)


 
/*

function ReturnSeed(weapon) //get the seed
	local Normalseed = {["weapon_cs_base"] = true} //normal css weapons
	local cone = weapon.Cone
	
	if !cone && type(weapon.Primary) == "table" && type(weapon.Primary.Cone) == "number" then
		cone = weapon.Primary && weapon.Primary.Cone end
	if !cone then cone = 0 end //sweps
	
	// the filter
	if type(weapon.Base) == "string" and Normalseed[weapon.Base] then return cone end //normal
	if weapon:GetClass() == "ose_turretcontroller" then return 0 end //wut
    
	adsfg
	return cone or 0
end


		
require("decz")

CONFIGDECO = {} //hl2 weapon predef cones
CONFIGDECO.weapons = {}
CONFIGDECO.weapons["weapon_smg1"]        = Vector( -0.04362, -0.04362, -0.04362 )
CONFIGDECO.weapons["weapon_pistol"]      = Vector( -0.0100, -0.0100, -0.0100 )
CONFIGDECO.weapons["weapon_ar2"]         = Vector( -0.02618, -0.02618, -0.02618 )
CONFIGDECO.weapons["weapon_shotgun"]     = Vector( -0.08716, -0.08716, -0.08716 )

local seedinVector = Vector( 0, 0, 0 )
local seedinValue = Vector( 0, 0, 0 )
local currentseed, cmd2, seed = currentseed or 0, 0, 0

 function DuckNospread( cmd, aimAngle )
   
        cmd2, seed = hl2_ucmd_getprediciton(cmd)
		if( cmd2 != 0 ) then currentseed =  seed end
        
		local weapon = LocalPlayer():GetActiveWeapon()
		
        if weapon:IsValid() then 
	 if type(weapon.Initialize) == "function" then 
               //checking if the cones are given in a value or in a vector 
                //turn it in to a vector
			   seedinValue = ReturnSeed(weapon)
			   if type(seedinValue) == "number" then 
                        seedinVector = Vector(-seedinValue,-seedinValue,-seedinValue)
                
			   elseif type(seedinValue) == "Vector" then 
                        seedinVector = -1*seedinValue
                end
				
				else
// checking if its a hl2 weapon and seting the seed to it's predefined seed. It wouldnt work when i did this in ReturnSeed(                    
					if( CONFIGDECO.weapons[weapon:GetClass()] ) then seedinVector = CONFIGDECO.weapons[weapon:GetClass()] end
                end
           end
     return hl2_shotmanip(currentseed or 0, (aimAngle or LocalPlayer():GetAimVector():Angle()):Forward(), seedinVector):Angle()  //magic
end	 */  
 

 	   
 
 local Friends = {""}

  
 function TeamA(ent)
	if GetConVarNumber("duck_aim_team") == 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end
	return true
end


function EnemiesA(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and ent:Health() <0 then return false end
	if ent:IsPlayer() and table.HasValue(Friends,ent:Nick()) then return false end
	if ent:IsNPC() and ent:GetClass() == "npc_alyx" or ent:GetClass() == "npc_vortigaunt" then return false end 
	if ent:IsPlayer() and !TeamA(ent) then return false end
	if GetConVarNumber("duck_aim_friends") == 1 then if ent:IsPlayer() and ent:GetFriendStatus() == "friend" then return nil end end 
	if ent:IsNPC() and ent:GetMoveType() == 0 then return false end 
	if GetConVarNumber("duck_aim_npc") == 0 then if ent:IsNPC() then return false end end
return true
end
	
	function FovCheck(ent)
if (GetConVarNumber("duck_aim_fov") == 0) or (GetConVarNumber("duck_aim_fov") == 180) then return true end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) > GetConVarNumber("duck_aim_fov")/2 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) < -GetConVarNumber("duck_aim_fov")/2 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) > GetConVarNumber("duck_aim_fov")/2 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) < -GetConVarNumber("duck_aim_fov")/2 then return false end
return true
end
	

	function OnScreen(ent)
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) > 38 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().y-LocalPlayer():EyeAngles().y) < -38 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) > 38 then return false end
if math.NormalizeAngle((ent:GetPos()-LocalPlayer():GetPos()):Angle().p-LocalPlayer():EyeAngles().p) < -38 then return false end
return true
end
	

		
	  function Target()
	local position = LocalPlayer():EyePos() 
	local angle = LocalPlayer():GetCursorAimVector()
	local tar = {0,0}
	for _, ent in pairs(ents.GetAll()) do
		if EnemiesA(ent) and visible(ent) and FovCheck(ent) then
			local targetpos = ent:EyePos()
			local difr = (targetpos-position):Normalize()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs(difr)
			if difr < tar[2] or tar[1] == 0 then
				tar = {ent, difr}
			end
		end
	end
	return tar[1]
end  



	
//locals
local SetViewAngles = _R.CUserCmd.SetViewAngles
local AimBot 
local ent
local pos
local Prediction
local Compensation
local Mypos 
local NSPos
local AntiSpread
local trace
local mode
local moderror
local spt
local m
local Victor = Vector(0,0,0) 

function DuckAim(cmd)
	

trace = LocalPlayer():GetEyeTraceNoCursor()
    
if GetConVarNumber("duck_aim_mode") == 1 then
   mode = Target()
   moderror = Target()

elseif GetConVarNumber("duck_aim_mode") == 0 then
   mode = ClosestTarget()
   moderror = ClosestTarget()
end
 
	ent = mode
	
 

 
	if ent != 0 && moderror then
 
    m = ent:GetModel()  
    
	spt = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
	 
	if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then spt = ent:LocalToWorld( Vector( 0, 0, 5 ) )  end
	if ( m == "models/seagull.mdl" ) then spt = ent:LocalToWorld( Vector( 0, 0, 6 ) ) end
	if ( m == "models/combine_scanner.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Scanner.Body" ) ) end
	if ( m == "models/hunter.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "MiniStrider.body_joint" ) ) end
	if ( m == "models/combine_turrets/floor_turret.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Barrel" ) ) end
	if ( m == "models/dog.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Dog_Model.Eye" ) ) end
	if ( m == "models/vortigaunt.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
	if ( m == "models/antlion.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion.Body_Bone" ) ) end
	if ( m == "models/antlion_guard.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion_Guard.Body" ) ) end
	if ( m == "models/antlion_worker.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Antlion.Head_Bone" ) ) end
	if ( m == "models/zombie/fast_torso.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
	if ( m == "models/zombie/fast.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
	if ( m == "models/headcrabclassic.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
	if ( m == "models/headcrabblack.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HCBlack.body" ) ) end
	if ( m == "models/headcrab.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HCFast.body" ) ) end
	if ( m == "models/zombie/poison.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Headcrab_Cube1" ) ) end
	if ( m == "models/zombie/classic.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/zombie/classic_torso.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/zombie/zombie_soldier.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
	if ( m == "models/combine_strider.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Combine_Strider.Body_Bone" ) ) end
	if ( m == "models/combine_dropship.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "D_ship.Spine1" ) ) end
	if ( m == "models/combine_helicopter.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Chopper.Body" ) ) end
	if ( m == "models/gunship.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Gunship.Body" ) ) end
	if ( m == "models/lamarr.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
	if ( m == "models/mortarsynth.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Root Bone" ) ) end
	if ( m == "models/synth.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "Bip02 Spine1" ) ) end
	if ( m == "mmodels/vortigaunt_slave.mdl" ) then spt = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
	
	
  Victor = Vector(0,0,GetConVarNumber("Duck_aim_plus"))
  Compensation = spt+Victor
  Compensation = Compensation + (ent:GetVelocity() / GetConVarNumber("Duck_aim_comp") - LocalPlayer():GetVelocity() / GetConVarNumber("Duck_aim_comp")) 

	

	Mypos = LocalPlayer():EyePos()
    NSPos = (Compensation - Mypos):Angle()

	if AimBot == true then
 if GetConVarNumber("duck_aim_auto") == 1 then
 RunConsoleCommand("+attack") 
 timer.Simple(0.01, function()  RunConsoleCommand("-attack")  end)
 end

 
	/*AntiSpread =  DuckNospread(cmd, NSPos)*/
    SetViewAngles(cmd,NSPos)			
    end
	end
	end

	
	
		
	function NoTwitch()
	 	if ent != 0 then
		local viewpos = {} 
	
	viewpos.angles = (LocalPlayer():EyeAngles() ) * LocalPlayer():EyeAngles() + NSPos
			viewpos.fov = FOV
		return viewpos
end
end
		
      

	concommand.Add("+duck_aimbot", function()
	hook.Add("CalcView", "Twich", NoTwitch) 	
    AimBot = true
	hook.Add("CreateMove", "Aim", DuckAim)

    end)
	 
	concommand.Add("-duck_aimbot", function() 
	hook.Remove("CalcView", "Twich") 	
    AimBot = true
	hook.Remove("CreateMove", "Aim")
	 
    end)


	
	function Trigger()

	 if  GetConVarNumber("duck_aim_reload") == 1 and LocalPlayer():GetActiveWeapon():Clip1() <5 then
  RunConsoleCommand("+reload") 
 timer.Simple(0.05, function()  RunConsoleCommand("-reload")  end)
 end // omg i use dis think hook !!!1
	
	if GetConVarNumber("duck_trigger") == 1 then

local tr = util.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector())
local trace = util.TraceLine(tr)

if trace.Hit and trace.HitNonWorld then
local hit = trace.Entity

if EnemiesA(hit) then
 RunConsoleCommand("+attack") 
 timer.Simple(0.01, function()  RunConsoleCommand("-attack")  end)
end

end

end

end
hook.Add("Think", "Trigger", Trigger)
	
	

local function zoom()
hook.Add("CalcView", "NR", function() 		 

		if GetConVarNumber("duck_zoom") == 1 then


	local viewpos = {} 

	
	if LocalPlayer():KeyDown(IN_USE) then
	
	viewpos.fov = 30
	else 
	viewpos.fov = 70
    end
    viewpos.angles = LocalPlayer():EyeAngles() 
    viewpos.origin = LocalPlayer():GetShootPos() - LocalPlayer():GetAimVector():Angle():Forward() 
	
	return viewpos

		
		
end
end)
end
hook.Add("Think", "zoom", zoom)

function SpinBot(cmd)
if GetConVarNumber("duck_spin") == 1 && cmd:GetButtons() & ( IN_ATTACK | IN_ATTACK2 | IN_FORWARD | IN_BACK | IN_MOVELEFT | IN_MOVERIGHT )  == 0  then

local myview = cmd:GetViewAngles()
local spinangle = myview
spinangle.y = spinangle.y + 20
SetViewAngles(cmd, spinangle)

local diff = math.Deg2Rad(math.NormalizeAngle(spinangle.y - myview.y))

local absf = math.Clamp(cmd:GetForwardMove(), -1, 1)
local abss = math.Clamp(cmd:GetSideMove(), -1, 1)

cmd:SetForwardMove(-1000 * math.sin(diff) * abss)
cmd:SetSideMove(1000 * math.sin(diff) * absf)
end


hook.Add("CreateMove", "spinny", SpinBot)
end



	



local function Laser()

local vm = LocalPlayer():GetViewModel()
local alpha = Color(255, 255, 255, 0) 
local bone = vm:LookupAttachment("muzzle")

if GetConVarNumber("duck_laser_dot") == 1 then
alpha = Color( 0, 255, 0, 10 )

elseif GetConVarNumber("duck_laser_dot") == 0 then
alpha = Color( 0, 255, 0, 255 )

end
  
  
if GetConVarNumber("duck_laser") == 1 then
   if not vm then return end      
   if vm and vm:IsValid() then
                



				
	if bone == 0 then bone = vm:LookupAttachment("1") end
	if bone == 0 then bone = vm:LookupAttachment("laser") end
    if bone == 0 then bone = vm:LookupAttachment("spark") end
	if bone == 0 then bone = vm:LookupAttachment("0") end
    if bone == 0 then bone = LocalPlayer():LookupAttachment("chest")  end 
	
	
	        cam.Start3D(EyePos(), EyeAngles())
	
		render.SetMaterial(Material("sprites/bluelaser1"))

		render.DrawBeam(vm:GetAttachment(bone).Pos, LocalPlayer():GetEyeTrace().HitPos, 3, 0, 0, alpha)


		render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
		render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() - LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 20, 20, Color(0, 255, 0, 255), 0)
		cam.End3D()



end

end
end


hook.Add("HUDPaint", "Sex", Laser)

function Teamw(ent)    
	if GetConVarNumber("duck_teamw") >= 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end	
	return true	
end


function Enemiesw(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent or !ent:GetClass() == "prop_physics" then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and ent:Health() <0 then return false end
	if ent:IsPlayer() and !Teamw(ent) then return false end
    if ent:IsNPC() and ent:GetMoveType() == 0 then return false end 
	if ent:GetClass() == "prop_physics" then return true end
	return true
end	
	

function Team(ent)    
	if GetConVarNumber("duck_team") >= 1 then
		if ent:Team() != LocalPlayer():Team() then
			return true
		else
			return false
		end
	end	
	return true	
end


function Enemies(ent )
	if !ent:IsValid() then return false end
	if !ent:Alive() then return false end
	if ent:Health() <1 then return false end
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end	 
	if !ent:IsPlayer()  then return false end
 	if ent:IsPlayer() and !Team(ent) then return false end
	return true
end	




	



local Tagged = {""}
local function ESP()

local health

for _, ent in pairs(ents.GetAll()) do						  

//ply

if ent:IsPlayer() && Enemies(ent) && GetConVarNumber("duck_esp") == 1 then 
	if OnScreen(ent) then
	
local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
local headpos = ent:GetBonePosition(bone):ToScreen()
	
local alpha = math.Clamp((10000 - ent:GetPos():Distance(LocalPlayer():GetShootPos())) * (25 / (500 - 100)), 100, 255)
local tc = team.GetColor(ent:Team())	
local vs 
local hp
local wbflash = (math.sin(RealTime()*3)+1)*122.5 


local weap
if ent.GetActiveWeapon then
							weap = ent:GetActiveWeapon()
						else
							weap = nil 
end
 
if ent:Health() <20 then hp = Color(255,0,0,alpha) elseif ent:Health() <50 then hp = Color(255,255,0,alpha) elseif ent:Health() >49 then hp = Color(0,255,0,alpha) end
if visible(ent) then vs = Color( 0, 255, 0, alpha ) else vs = Color( 255, 0, 0, alpha ) end

	
	if GetConVarNumber("duck_barrel") == 1 then	
local hd = ent:LookupBone("ValveBiped.Bip01_Head1")
local bone = ent:GetBonePosition(hd)

	
	        cam.Start3D(EyePos(), EyeAngles())
	
		render.SetMaterial(Material("cable/redlaser"))

	
		render.DrawBeam(bone, ent:GetEyeTrace().HitPos, 3, 0, 0, Color(255,255,255,255))


		cam.End3D()



end
	
		
	surface.SetDrawColor(tc)
	surface.DrawLine(headpos.x, headpos.y, headpos.x,headpos.y-75)
	draw.SimpleTextOutlined(ent:GetName(), "Default" , headpos.x, headpos.y-80, Color(tc.r, tc.g, tc.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	

	  
     
	    if table.HasValue(Tagged, ent:Nick()) then
		surface.SetDrawColor(wbflash,0,0,alpha) 
		 surface.DrawLine(headpos.x-50,headpos.y,headpos.x+50,headpos.y)
		  surface.DrawLine(headpos.x,headpos.y-50,headpos.x,headpos.y+50)
	    end
	 
		if GetConVarNumber("duck_esp_pvisible") == 1 && GetConVarNumber("duck_esp") == 1 then	
		draw.RoundedBox( 9, headpos.x-6, headpos.y, 15, 15, vs )
		end
		 
         if GetConVarNumber("duck_esp_pweapon") == 1 && GetConVarNumber("duck_esp") == 1 then			
		if ValidEntity(weap) then
		draw.SimpleTextOutlined(weap:GetPrintName(), "DefaultSmall", headpos.x, headpos.y-60, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		else
		draw.SimpleTextOutlined("NONE", "Default", headpos.x, headpos.y, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
		end      
			end

	  if GetConVarNumber("duck_esp_phealth") == 1 && GetConVarNumber("duck_esp") == 1 then			
      
	    if GetConVarNumber("duck_esp_typehealth") == 0 then	
	    draw.RoundedBox(1, headpos.x, headpos.y-101, 31, 12, Color(100, 100, 100, alpha),TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
		draw.RoundedBox(0, headpos.x+3, headpos.y-100, ent:Health()/4, 10, hp,TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
		end
			end
		
			if ent:GetFriendStatus() == "friend" && GetConVarNumber("duck_esp") == 1 then 
		surface.DrawCircle(headpos.x,headpos.y+5,20,Color(wbflash,0,0,255))
		end
			end
	//npc
	elseif ent:IsNPC() && GetConVarNumber("duck_esp") == 1 &&  GetConVarNumber("duck_esp_npc") == 1 then
	if OnScreen(ent) then
  
  	local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
	local headpos = ent:GetBonePosition(bone):ToScreen()
 
	
	draw.SimpleTextOutlined(ent:GetClass(), "Default" , headpos.x + 30, headpos.y - 20, Color(255,255,255,255), 2, 1, 1, Color(0, 0, 0, 255 ))
	end
	
	//weapon
	elseif ent:IsWeapon() && GetConVarNumber("duck_esp") == 1 && GetConVarNumber("duck_esp_weapon") == 1 then
	if OnScreen(ent) then
	local pos = ent:GetPos() + Vector(0,0,70)
	pos = pos:ToScreen()  
	
	
	if ent:GetMoveType() == 0 then
	else
		draw.SimpleTextOutlined(ent:GetPrintName(), "DefaultSmall" , pos.x, pos.y+100, Color(255,0,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	end
		end
	
	//ttt
	elseif ent:IsWeapon() && GetConVarNumber("duck_esp") == 1 && GetConVarNumber("duck_esp_ttt") == 1  then
	if OnScreen(ent) then
	local position = ent:GetPos():ToScreen() 
	
	local Weapons = {"weapon_ttt_teleport", "weapon_ttt_sipistol", "weapon_ttt_push", "weapon_ttt_phammer", "weapon_ttt_knife", "weapon_ttt_flaregun", "weapon_ttt_c4"}
	
	local gayfag = {"0", "255"}
	if table.HasValue(Weapons, ent:GetClass()) then
	draw.DrawText("TRAITOR", "Default" , position.x, position.y - 30, Color(table.Random(gayfag),table.Random(gayfag),table.Random(gayfag),255),1)		  
	end
		end
	
	end
		end
			end
	hook.Add("HUDPaint", "ESP", ESP)

	
function CrosshairnHUD()

if GetConVarNumber("duck_crosshair") == 1 && GetConVarNumber("duck_crosshair_style") == 0 then
	surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), 255)  
		surface.DrawRect( (ScrW()/2)-1, (ScrH()/2)-5, 2, 10)
				surface.DrawRect( (ScrW()/2)-5, (ScrH()/2)-1, 10, 2)
			
	

elseif GetConVarNumber("duck_crosshair") == 1 && GetConVarNumber("duck_crosshair_style") == 1 then 
surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), 255)
		surface.DrawRect( ScrW() / 2 - 14, ScrH() / 2, 30, 2)
			surface.DrawRect( ScrW() / 2, ScrH() / 2 - 14, 2, 30)
			
			
elseif GetConVarNumber("duck_crosshair") == 1 && GetConVarNumber("duck_crosshair_style") == 2 then
	surface.SetDrawColor(GetConVarNumber("duck_crosshair_red"), GetConVarNumber("duck_crosshair_green"), GetConVarNumber("duck_crosshair_blue"), 255)  	
		surface.DrawRect( (ScrW()/2)- 1, (ScrH()/2)-47, 2, 100 )
			surface.DrawRect( (ScrW()/2)-50, (ScrH()/2)-1, 100, 2 )
			
end

if GetConVarNumber("duck_crosshair_r") == 1 then RunConsoleCommand("Duck_crosshair_red", "255") 
elseif GetConVarNumber("duck_crosshair_r") == 0 then  RunConsoleCommand("Duck_crosshair_red", "0")
end

if GetConVarNumber("duck_crosshair_g") == 1 then RunConsoleCommand("Duck_crosshair_green", "255") 
elseif GetConVarNumber("duck_crosshair_g") == 0 then  RunConsoleCommand("Duck_crosshair_green", "0")
end

if GetConVarNumber("duck_crosshair_b") == 1 then RunConsoleCommand("Duck_crosshair_blue", "255") 
elseif GetConVarNumber("duck_crosshair_b") == 0 then  RunConsoleCommand("Duck_crosshair_blue", "0")
end
// noes!


local ang = LocalPlayer():EyeAngles()


				
local Mirror = {} 
	


 Mirror.origin =  LocalPlayer():GetPos() + Vector(0,0,60)
  Mirror.angles = Angle(0, ang.y-180, 0)
	Mirror.w = 200
		Mirror.h = 60
			Mirror.x = 400
				Mirror.y = 20
		

	if GetConVarNumber("duck_hud") == 1 then
		
		local danger 
		if LocalPlayer():Health() <20 then danger = Color(100,0,0,100) 
		elseif LocalPlayer():Health() <50 then danger = Color(100,100,0,100) 
		elseif LocalPlayer():Health() >49 then danger = Color(0,100,0,100)  end
		
	draw.RoundedBox(0, 250, 10, 500, 80, danger)  
     surface.SetDrawColor( 0,0,0,255 )
      surface.DrawOutlinedRect( 250, 10, 500, 80)
	   surface.DrawOutlinedRect( 399, 19, 202, 62)
		
		draw.SimpleTextOutlined("Time: " .. os.date("%a") .. " " .. os.date("%H") .. ":" .. os.date("%M") .. " " .. os.date("%p"), "ScoreboardText", 390, 30, Color(0, 100, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
		 draw.SimpleTextOutlined("Name:" .. " " .. LocalPlayer():Nick(), "ScoreboardText", 390, 60, Color(0, 255, 0, 255), 2, 1, 1, Color(0, 0, 0, 255))

				render.RenderView(Mirror)
						
						draw.SimpleTextOutlined("Entity Class Name:", "ScoreboardText",  740, 30, Color(0, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))
							local tr = util.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector())
local trace = util.TraceLine(tr)
 if trace.Hit and trace.HitNonWorld then
			local hite = trace.Entity
			local infoc = hite:GetClass()
	draw.SimpleTextOutlined(infoc, "ScoreboardText", 705, 60, Color(255, 255, 255, 255), 2, 1, 1, Color(0, 0, 0, 255))
			end
						
	
	
	end


	
	if GetConVarNumber("duck_radar") == 1 then
	
	
	local rW, rH, x, y = 200, 200, ScrW() / 2, ScrH() / 2
	    draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 0, 0, 50 ) )
		draw.RoundedBox( 0, 0, 0, rW, rH, Color( 0, 255, 0, 50 ) )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( 0, 0, rW, rH )
		
		local ply = LocalPlayer()
		
		local radar = {}
		radar.h		= 200
		radar.w		= 200
		radar.org	= 5000
		
		local x, y = ScrW() / 2, ScrH() / 2
		
		local half = rH / 2
		local xm = half
		local ym = half
		
	
		
		for k, e in pairs( ents.GetAll() ) do
			if (e:IsNPC() and e:GetMoveType() != 0) or (e:IsPlayer() and e:Alive() ) then
				
				local s = 6
				local color
			
				
				if e:IsPlayer() then
				color = team.GetColor(e:Team())	
				elseif e:IsNPC() then
			    color = Color(255,255,255,255)
				end
				
		
				if e == ply then
				color = Color(0,0,0,255)
				
				elseif e != ply and e:IsPlayer() then
				color = Color(color.r, color.g, color.b, 255)
				end
				
				
				
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )
				
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				
				
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )
				
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )
				
				local text = e:GetClass():sub(5,-1)
				
				if ( e:IsPlayer() ) then 
					text = e:Nick() 
				end
				
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then
				
					draw.RoundedBox( 1, posX, posY, s, s, color )
					draw.SimpleText(text,"DefaultSmall",pX - iY - 4,pY - iX - 15 - ( s / 2 ),color,1,TEXT_ALIGN_TOP)
				end
			end
		end
	end

	if GetConVarNumber("duck_fullbright") == 1 then
	render.SuppressEngineLighting( true )
	
	elseif GetConVarNumber("duck_fullbright") == 0 then
    render.SuppressEngineLighting( false )

	
	end
	
	end

	
	hook.Add("HUDPaint", "crosshair",  CrosshairnHUD)

local WM
local Walltoggle

local function Wallhack()
hook.Add("HUDPaint", "Wallhack", function()

	WallToggle = true 


	
if GetConVarNumber("Duck_Wallhack_Material") == 0 then
Mat = ""

elseif GetConVarNumber("Duck_Wallhack_Material") == 1 then
Mat = "debug/debugportals"

elseif GetConVarNumber("Duck_Wallhack_Material") == 2 then
Mat = "hlmv/debugmrmwireframe"
end
	
local friendtag = {"0", "255"}	
		
		if WallToggle then
		cam.Start3D(EyePos(),EyeAngles())
		for _, ent in pairs(ents.GetAll()) do		  
		local col = Color(255,255,255,255)
		local ocol = Color(255,255,255,255)
		local thick = Vector(1.05,1.1,1.01)
		
	if GetConVarNumber("Duck_Wallhack_Material") == 0 or GetConVarNumber("Duck_Wallhack_Material") == 1 or GetConVarNumber("Duck_Wallhack_Material") == 2 then
		
		if ent:IsPlayer() and ent:GetFriendStatus() == "friend" then
		  col = Color(math.random(1,255),math.random(1,255),math.random(1,255),255)	
          ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    
			   
		elseif ent:IsNPC() then
		  col = Color(1,1,1,255)	             				
		  ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    		
			
		elseif ent:IsPlayer() then
		    local tcol = team.GetColor(ent:Team()) 
			
			if GetConVarNumber("Duck_Wallhack_Relative") == 1 then
			ocol = Color(tcol.r/255,tcol.g/255,tcol.b/255,255)	               				
		    col = Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)    
			else
			col = Color(GetConVarNumber("Duck_Wallhack_Red"), GetConVarNumber("Duck_Wallhack_Green"), GetConVarNumber("Duck_Wallhack_Blue"),255)	               				
		    ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    
			end
			
			if GetConVarNumber("Duck_Wallhack_Relative") == 1 && GetConVarNumber("Duck_Wallhack_Material") == 0 then 
			col = Color(1,1,1,1)	               				
		    ocol = Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)    
			end
			
			
			end
			
		if Enemiesw(ent) then
		if !visible(ent) then
		
		/*SWEP.VElements = {
	["barrel"] = { type = "Model", model = "models/props_c17/TrapPropeller_Lever.mdl", bone = "ValveBiped.base", pos = Vector(0.061, -0.695, 17.068), angle = Angle(0, 0, 90), size = Vector(1.375, 1.424, 1.43), color = Color(255, 255, 255, 255), surpresslightning = false, material = ""},
}*/

		render.SetColorModulation(ocol.r,ocol.g,ocol.b)	           
		ent:SetModelScale(thick)
		ent:SetMaterial("debug/debugportals")
		ent:DrawModel()
	
		render.SetColorModulation(col.r,col.g,col.b)
		ent:SetModelScale(Vector(1,1,1))
		ent:SetMaterial(Mat)
		ent:DrawModel()
		
		else 
		ent:SetMaterial("")
		end
		end
		
		end
			end
	    cam.End3D()			   
		end
   end)
		end	

	
concommand.Add("Duck_Wallhack_Toggle", function()
    if WallToggle then

   hook.Remove( "HUDPaint", "Wallhack")
   
	WallToggle = false
    LocalPlayer():ChatPrint("Wallhack is now Off!")
	 
	 for _, ent in pairs(ents.GetAll()) do		
	 if Enemiesw(ent) then
	 ent:SetMaterial("")
	 end
	 end
	
	elseif !WallToggle then	
    LocalPlayer():ChatPrint("Wallhack is now On!")
	Wallhack()
	WallToggle = true		
    end

	end)

	/*
require("funcsolver")
function spoof(cmd)
if string.find( string.lower( "host_timescale" ), cmd ) then return 1 end
if string.find( string.lower( "host_framerate" ), cmd ) then return 0 end
if string.find( string.lower( "sv_cheats" ), cmd ) then return 0 end
end


local function AdjustablespeedOn()
SetConvar(CreateConVar("sv_cheats", ""), 1)
SetConvar(CreateConVar("host_timescale", ""), GetConVarNumber("duck_speed"))
end

local function AdjustablespeedOff()
SetConvar(CreateConVar("sv_cheats", ""), 0)
SetConvar(CreateConVar("host_timescale", ""), 1)
end

local function speedOn()
SetConvar(CreateConVar("sv_cheats", ""), 1)
SetConvar(CreateConVar("host_framerate", ""), 0.1)
end

local function speedOff()
SetConvar(CreateConVar("sv_cheats", ""), 0)
SetConvar(CreateConVar("host_framerate", ""), 0)
end

concommand.Add("+duck_speed", AdjustablespeedOn)
concommand.Add("-duck_speed", AdjustablespeedOff)

concommand.Add("+duck_rspeed", speedOn)
concommand.Add("-duck_rspeed", speedOff)
*/


function unload()


 hook.Remove("HUDPaint", "Line")	
hook.Remove( "HUDPaint", "Sex")

			hook.Remove("HUDPaint", "ESP")

		hook.Remove("HUDPaint", "crosshair")
	hook.Remove("RenderScene", "Wallhack")
	hook.Remove("RenderScene", "Wallhack2")

end

//sexy admin check made by fr1kin, sexy like him
 function IsAdmin(e)
	
	if ( e:IsAdmin() ) then 
		return true
	
	elseif ( e:IsSuperAdmin() ) then 
		return true
		
	end
	
	return false
end

function GetAdminType(e)

	local ply = LocalPlayer()
	
	if ( e:IsAdmin() && !e:IsSuperAdmin() ) then
		return "Admin"
		
	elseif ( e:IsSuperAdmin() ) then
		return "Super Admin"
	
	elseif ( !e:IsSuperAdmin() or !e:IsAdmin() ) then
		return "Guest"
	end
	
	return ""

             

      end


concommand.Add("duck_menu", function()

//made the idea with dermadesigner. parented, linked and adjusted everything my self

local esp
local wallhack
local spam
local cvars
local listplayers
local chair
local misc
local mainimage
local speed
local fovaim
local aimbot
local mainpanel
local helpmainpanel
local helplabel10
local helplabel9
local helplabel8
local helplabel7
local helplabel6
local helplabel5
local helplabel4
local helplabel3
local helplabel2
local helplabel1
local helpmainframe
local address
local favorites
local mainbrowserpanel
local mainaimbotframe
local go
local refresh
local html
local forwards
local backwards
local url

local sizegrow = 10
local posgrow = -300
local alphagrow = 2
local zigzag1, zig1color = 100, Color(255,255,0,255)
local zigzag2, zig2color = 295, Color(0,0,0,0)

mainframe = vgui.Create("DFrame")

mainframe:SetPos(-300, 230)
mainframe:SetTitle("DuckBot Menu")
mainframe:SetDeleteOnClose(false)
mainframe:SetDraggable(false)
mainframe.Paint = function() 

sizegrow = sizegrow + 10
if sizegrow >256 then sizegrow = 256 end
mainframe:SetSize(323 , sizegrow )

alphagrow = alphagrow + 0.2
zigzag1 = zigzag1 + 1




if zigzag1  > 295 then 
zig1color = Color(0,0,0,0)
zig2color = Color(255,255,0,255)
zigzag2 = zigzag2 - 1 end



if alphagrow > 25 then alphagrow = 25 end

draw.RoundedBox(0, 2, 2, mainframe:GetWide(), mainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(255,255,255,alphagrow*10)
surface.DrawOutlinedRect(0, 0, mainframe:GetWide(), mainframe:GetTall()) 
surface.DrawLine( 6, 20, 78,20 )
draw.RoundedBox(1, zigzag1, 15, 5, 5, zig1color)
draw.RoundedBox(1, zigzag2, 15, 5, 5, zig2color)
posgrow = posgrow + 19
mainframe:SetPos(posgrow, 230)
if zigzag2  < 100 then 
zigzag2 = 100
draw.SimpleText("DuckBot","Default",110,10,Color(255,255,255,255),0)
end
if posgrow > 100 then posgrow = 100 end
end
mainframe:MakePopup()


mainpanel = vgui.Create("DPanel")
mainpanel:SetParent(mainframe)
mainpanel:SetSize(312, 221)
mainpanel:ColorTo(Color(0,0,0,255), 4, 1)
 
mainpanel:SetPos(6, 27)
mainpanel.Paint = function() 

draw.RoundedBox(0, 2, 2, mainpanel:GetWide(), mainpanel:GetTall(), Color(255, 255, 255, alphagrow))

end


mainpanel:SetDisabled(false)

mainimage = vgui.Create("DImageButton")
mainimage:SetParent(mainpanel)
mainimage:SetSize(215, 76)
mainimage:SetPos(93, 3)
mainimage:SetImage("VGUI/entities/DuckBotNew")
mainimage.Paint = function()
surface.SetDrawColor( Color(255, 255, 255, 225)) 
surface.DrawOutlinedRect( 0, 0, mainimage:GetWide(), mainimage:GetTall())
end

mainimage.DoClick = function() 
    local Choice = DermaMenu()
   
   Choice:AddOption("Load", function() include("autorun/client/DuckBot.lua")
   LocalPlayer():ChatPrint("DuckBot Loaded")
   surface.PlaySound( "/quack/duck_1.mp3" ) end ) 
   
   Choice:AddOption("Unload", function()     
   unload()
   LocalPlayer():ChatPrint("DuckBot Unloaded")
   surface.PlaySound( "/quack/duck_1.mp3" ) end )
	
  
	/*below is the help and web browser, i had to do it this way or else 
	it would bug out when you tried to open more than one panel
	*/
   Choice:AddOption("Help", function()
   surface.PlaySound( "/quack/duck_1.mp3" )

helpmainframe = vgui.Create('DFrame')
helpmainframe:SetParent(mainframe)
helpmainframe:SetSize(229, 265)
helpmainframe:SetPos(158, 103)
helpmainframe:SetTitle('Help')
helpmainframe:SetSizable(true)
helpmainframe:SetDeleteOnClose(false)
helpmainframe:SetVisible(true)
helpmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, helpmainframe:GetWide(), helpmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, helpmainframe:GetWide(), helpmainframe:GetTall()) end
helpmainframe:MakePopup()


helpmainpanel = vgui.Create('DPanel')
helpmainpanel:SetParent(helpmainframe)
helpmainpanel:SetSize(216, 228)
helpmainpanel:SetPos(7, 30)
helpmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, helpmainpanel:GetWide(), helpmainpanel:GetTall(), Color(255, 255, 255, 20))
end

helplabel1 = vgui.Create('DLabel')
helplabel1:SetParent(helpmainpanel)
helplabel1:SetPos(3, 7)
helplabel1:SetText('Binds: ')
helplabel1:SizeToContents()

helplabel2 = vgui.Create('DLabel')
helplabel2:SetParent(helpmainpanel)
helplabel2:SetPos(3, 27)
helplabel2:SetText('bind "key" "+duck_rspeed"')
helplabel2:SizeToContents()
helplabel2:SetTextColor(Color(65, 105, 225, 255))
helplabel3 = vgui.Create('DLabel')
helplabel3:SetParent(helpmainpanel)
helplabel3:SetPos(3, 47)
helplabel3:SetText('To run 2x the normal speed')
helplabel3:SizeToContents()
helplabel3:SetTextColor(Color(65, 105, 225, 255))
helplabel4 = vgui.Create('DLabel')
helplabel4:SetParent(helpmainpanel)
helplabel4:SetPos(3, 67)
helplabel4:SetText('bind "key" "+duck_speed"')
helplabel4:SizeToContents()
helplabel4:SetTextColor(Color(124, 252, 0, 255))
helplabel5 = vgui.Create('DLabel')
helplabel5:SetParent(helpmainpanel)
helplabel5:SetPos(3, 88)
helplabel5:SetText('To run at the given speed in the main menu')
helplabel5:SizeToContents()
helplabel5:SetTextColor(Color(124, 252, 0, 255))
helplabel6 = vgui.Create('DLabel')
helplabel6:SetParent(helpmainpanel)
helplabel6:SetPos(3, 121)
helplabel6:SetText('bind "key" "+duck_aimbot"')
helplabel6:SizeToContents()
helplabel6:SetTextColor(Color(255, 0, 0, 255))
helplabel7 = vgui.Create('DLabel')
helplabel7:SetParent(helpmainpanel)
helplabel7:SetPos(3, 137)
helplabel7:SetText('To start the aimbot')
helplabel7:SizeToContents()
helplabel7:SetTextColor(Color(255, 0, 0, 255))
helplabel8 = vgui.Create('DLabel')
helplabel8:SetParent(helpmainpanel)
helplabel8:SetPos(3, 168)
helplabel8:SetText('bind "key" "duck_menu"')
helplabel8:SizeToContents()
helplabel8:SetTextColor(Color(255, 255, 0, 255))
helplabel9 = vgui.Create('DLabel')
helplabel9:SetParent(helpmainpanel)
helplabel9:SetPos(3, 189)
helplabel9:SetText('To Pop up the menu but of course')
helplabel9:SizeToContents()
helplabel9:SetTextColor(Color(255, 255, 0, 255))
helplabel10 = vgui.Create('DLabel')
helplabel10:SetParent(helpmainpanel)
helplabel10:SetPos(3, 209)
helplabel10:SetText('You already know that')
helplabel10:SizeToContents()
helplabel10:SetTextColor(Color(255, 255, 0, 255))
   end ) 
   
   Choice:AddOption("Web Browser", function()
surface.PlaySound( "/quack/duck_1.mp3" )

mainbrowserframe = vgui.Create('DFrame')
mainbrowserframe:SetParent(mainframe)
mainbrowserframe:SetSize(777, 617)
mainbrowserframe:SetPos(9, 8)
 mainbrowserframe:SetVisible(true)
mainbrowserframe:SetTitle('DuckBot Web Browser')
mainbrowserframe.Paint = function() 
draw.RoundedBox(0, 2, 2, mainbrowserframe:GetWide(), mainbrowserframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, mainbrowserframe:GetWide(), mainbrowserframe:GetTall()) end
mainbrowserframe:MakePopup()

mainbrowserpanel = vgui.Create('DPanel')
mainbrowserpanel:SetParent(mainbrowserframe)
mainbrowserpanel:SetSize(765, 580)
mainbrowserpanel:SetPos(6, 30)
mainbrowserpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, mainbrowserpanel:GetWide(), mainbrowserpanel:GetTall(), Color(255, 255, 255, 20))
end


favorites = vgui.Create("DButton")
favorites:SetParent(mainbrowserpanel)
favorites:SetSize(60, 40)
favorites:SetPos(5, 5)
favorites:SetText("Favorites")
favorites.DoClick = function()
 local favs = DermaMenu()
   
   favs:AddOption("FacePunch Studios", function() html:OpenURL("http://www.facepunch.com") end ) 
   
   favs:AddOption("YouTube", function()  html:OpenURL("http://www.youtube.com") end )
   
   favs:AddOption("Wiki", function()  html:OpenURL("http://wiki.garrysmod.com/?title=Main_Page") end )

   favs:AddOption("Google", function()  html:OpenURL("http://www.google.com") end )
      favs:Open() 
   
 end
favorites.DoRightClick = function()

end

address = vgui.Create('DTextEntry')
address:SetParent(mainbrowserpanel)
address:SetSize(610, 40)
address:SetPos(70, 5)
address:SetText("http://www.google.com")



go = vgui.Create('DImageButton')
go:SetParent(mainbrowserpanel)
go:SetSize(100, 100)
go:SetPos(702, 20)
go:SetImage("VGUI/entities/world_go")
go:SizeToContents()
go.DoClick = function() html:OpenURL(address:GetValue()) end

refresh = vgui.Create('DImageButton')
refresh:SetParent(mainbrowserpanel)
refresh:SetSize(40, 40)
refresh:SetPos(682, 20)
refresh:SetImage("gui/silkicons/arrow_refresh")
refresh:SizeToContents()
refresh.DoClick = function() html:Refresh() 
end

backwards = vgui.Create('DImageButton')
backwards:SetParent(mainbrowserpanel)
backwards:SetSize(40, 40)
backwards:SetPos(722, 20)
backwards:SetImage("VGUI/entities/arrow_left")
backwards:SizeToContents()
backwards.DoClick = function() html:HTMLBack() end

forwards = vgui.Create('DImageButton')
forwards:SetParent(mainbrowserpanel)
forwards:SetSize(40, 40)
forwards:SetPos(742, 20)
forwards:SetImage("VGUI/entities/arrow_right")
forwards:SizeToContents()
forwards.DoClick = function() html:HTMLForward() end

html = vgui.Create("HTML", Panel )
html:SetParent(mainbrowserpanel)
html:SetPos( 5, 48 )
html:SetSize( 765, 535 )
html:OpenURL("http://www.google.com")
			
 end ) 
   

   Choice:Open() 
   end
mainimage.DoRightClick = function() 
LocalPlayer():ChatPrint("Player Information Printed Into The Console")	
print("Name  State  Frags  Deaths  Status  Ping  SteamID")
local alive
for _, ent in pairs(player.GetAll()) do		
if ent:Alive() then alive = "Alive" else alive = "Dead" end
print(ent:Nick().."  "..alive.."  "..ent:Frags().."  "..ent:Deaths().."  "..GetAdminType(ent).."  "..ent:Ping().."  "..ent:SteamID())
end
end



speed = vgui.Create("DNumSlider")
speed:SetSize(86, 40)
speed:SetParent(mainpanel)
speed:SetPos(2, 7)
speed:SetText("Speed")
speed:SetMin(0.1)
speed:SetMax(10)
speed:SetConVar("duck_speed")
speed:SetDecimals(2)
speed:SetValue(GetConVarNumber("duck_speed"))
speed.Paint = function()
draw.RoundedBox(1, 1, 35, 100, 3, Color(speed:GetValue()*50, 255-speed:GetValue()*20, 0, 225))
end


fovaim = vgui.Create("DNumSlider")
fovaim:SetSize(86, 40)
fovaim:SetParent(mainpanel)
fovaim:SetPos(2, 45)
fovaim:SetText("FOV")
fovaim:SetMin(1)
fovaim:SetMax(180)
fovaim:SetConVar("duck_aim_fov")
fovaim:SetDecimals(0)
fovaim:SetValue(GetConVarNumber("duck_aim_fov"))




aimbot = vgui.Create("DButton")
aimbot:SetParent(mainpanel)
aimbot:SetSize(50, 50)
aimbot:SetPos(10, 84)
aimbot:SetText("Aimbot")

aimbot.DoClick = function()


/////////////////
/////////////////
/////////////////
/////////////////
local aimbotsteamcat
local aimbotteamcat
local aimbotoffset
local aimbotcomp
local aimbotauto
local aimbotnpccat
local mainaimbotpanel
local mainaimbotframe

mainaimbotframe = vgui.Create("DFrame")
mainaimbotframe:SetParent(aimbot)
mainaimbotframe:SetSize(229, 265)
mainaimbotframe:SetPos(158, 104)
mainaimbotframe:SetTitle("Aimbot")
mainaimbotframe:SetSizable(true)
mainaimbotframe:SetDeleteOnClose(false)
mainaimbotframe.Paint = function() 
draw.RoundedBox(0, 2, 2, mainaimbotframe:GetWide(), mainaimbotframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, mainaimbotframe:GetWide(), mainaimbotframe:GetTall()) end
mainaimbotframe:MakePopup()

mainaimbotpanel = vgui.Create("DPanel")
mainaimbotpanel:SetParent(mainaimbotframe)
mainaimbotpanel:SetSize(216, 228)
mainaimbotpanel:SetPos(7, 29)
mainaimbotpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, mainaimbotpanel:GetWide(), mainaimbotpanel:GetTall(), Color(255, 255, 255, alphagrow))
end

aimbotsteamcat = vgui.Create("DCheckBoxLabel")
aimbotsteamcat:SetParent(mainaimbotpanel)
aimbotsteamcat:SetPos(17, 13)
aimbotsteamcat:SetText("Ignore Steam Friends")
aimbotsteamcat:SetConVar("duck_aim_friends")
aimbotsteamcat:SetValue(GetConVarNumber("duck_aim_friends"))
aimbotsteamcat:SizeToContents()

aimbotteamcat = vgui.Create("DCheckBoxLabel")
aimbotteamcat:SetParent(mainaimbotpanel)
aimbotteamcat:SetPos(17, 43)
aimbotteamcat:SetText("Ignore Team Mates")
aimbotteamcat:SetConVar("duck_aim_team")
aimbotteamcat:SetValue(GetConVarNumber("duck_aim_team"))
aimbotteamcat:SizeToContents()

aimbotoffset = vgui.Create("DNumSlider")
aimbotoffset:SetSize(154, 40)
aimbotoffset:SetParent(mainaimbotpanel)
aimbotoffset:SetPos(17, 73)
aimbotoffset:SetDecimals(0)
aimbotoffset:SetText("Aim Offset")
aimbotoffset:SetMinMax( -10, 10)
aimbotoffset:SetConVar("duck_aim_plus")



aimbotcomp = vgui.Create("DNumSlider")
aimbotcomp:SetSize(154, 40)
aimbotcomp:SetParent(mainaimbotpanel)
aimbotcomp:SetPos(17, 123)
aimbotcomp:SetDecimals(0)
aimbotcomp:SetText("Compensation Offset")
aimbotcomp:SetMinMax( 1, 45)
aimbotcomp:SetConVar("duck_aim_comp")

aimbotnpccat = vgui.Create("DCheckBoxLabel")
aimbotnpccat:SetParent(mainaimbotpanel)
aimbotnpccat:SetPos(17, 173)
aimbotnpccat:SetText("Aim At NPCs")
aimbotnpccat:SetConVar("duck_aim_npc")
aimbotnpccat:SetValue(GetConVarNumber("duck_aim_npc"))
aimbotnpccat:SizeToContents()

aimbotauto = vgui.Create("DCheckBoxLabel")
aimbotauto:SetParent(mainaimbotpanel)
aimbotauto:SetPos(17, 203)
aimbotauto:SetText("Auto Fire")
aimbotauto:SetConVar("duck_aim_auto")
aimbotauto:SetValue(GetConVarNumber("duck_aim_auto"))
aimbotauto:SizeToContents()

 end
/////////////////
/////////////////
/////////////////
/////////////////
 
 
  local DSpritea = vgui.Create( "DSprite" )
DSpritea:SetParent(mainpanel)
DSpritea:SetPos( 19, 126 )
DSpritea:SetSize( 15, 15 )
DSpritea:SetMaterial( Material( "gui/silkicons/add" ) )
 
 
 
misc = vgui.Create("DButton")
misc:SetParent(mainpanel)
misc:SetSize(50, 50)
misc:SetPos(90, 84)
misc:SetText("Misc")

misc.DoClick = function() 
/////////////////
/////////////////
/////////////////
/////////////////
local adminlist
local miscns
local misctrigger
local misczoom
local miscmainpanel
local miscmainframe


miscmainframe = vgui.Create("DFrame")
miscmainframe:SetParent(misc)
miscmainframe:SetSize(229, 265)
miscmainframe:SetPos(158, 104)
miscmainframe:SetTitle("Misc")
miscmainframe:SetSizable(true)
miscmainframe:SetDeleteOnClose(false)
miscmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, miscmainframe:GetWide(), miscmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, miscmainframe:GetWide(), miscmainframe:GetTall()) end
miscmainframe:MakePopup()


miscmainpanel = vgui.Create("DPanel")
miscmainpanel:SetParent(miscmainframe)
miscmainpanel:SetSize(216, 228)
miscmainpanel:SetPos(7, 29)
miscmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, miscmainpanel:GetWide(), miscmainpanel:GetTall(), Color(255, 255, 255, 20))
end


miscns = vgui.Create("DCheckBoxLabel")
miscns:SetParent(miscmainpanel)
miscns:SetPos(17, 13)
miscns:SetText("NoSpread")
miscns:SetConVar("duck_recoil")
miscns:SetValue(GetConVarNumber("duck_recoil"))
miscns:SizeToContents()

misczoom = vgui.Create("DCheckBoxLabel")
misczoom:SetParent(miscmainpanel)
misczoom:SetPos(17, 43)
misczoom:SetText("Zoom")
misczoom:SetConVar("duck_zoom")
misczoom:SetValue(GetConVarNumber("duck_zoom"))
misczoom:SizeToContents()

misctrigger = vgui.Create("DCheckBoxLabel")
misctrigger:SetParent(miscmainpanel)
misctrigger:SetPos(17, 73)
misctrigger:SetText("Trigger Bot")
misctrigger:SetConVar("duck_trigger")
misctrigger:SetValue(GetConVarNumber("duck_trigger"))
misctrigger:SizeToContents()

adminslist = vgui.Create("DListView")
adminslist:SetParent(miscmainpanel)
adminslist:SetSize(182, 101)
adminslist:SetPos(17, 105)
adminslist:SetMultiSelect(false)
adminslist:AddColumn("Admins") 
adminslist:AddColumn("Status") 

for k,v in pairs(player.GetAll()) do
  if IsAdmin(v) then
  adminslist:AddLine(v:Nick(),GetAdminType(v)) 
end
end

/////////////////
/////////////////
/////////////////
/////////////////
end


  local DSpritem = vgui.Create( "DSprite" )
DSpritem:SetParent(mainpanel)
DSpritem:SetPos( 99, 127)
DSpritem:SetSize( 15, 15 )
DSpritem:SetMaterial( Material( "gui/silkicons/box" ) )


chair = vgui.Create("DButton")
chair:SetParent(mainpanel)
chair:SetSize(50, 50)
chair:SetPos(170, 84)
chair:SetText("Visuals")
chair.DoClick = function() 

/////////////////
/////////////////
/////////////////
/////////////////

local visualcross
local visualfb
local visualradar
local visualhud
local visualsize
local visualcb
local visualcg
local visualcr
local visuallaser1
local visuallaser2
local visualmainpanel
local visualmainframe

visualmainframe = vgui.Create("DFrame")
visualmainframe:SetParent(chair)
visualmainframe:SetSize(229, 265)
visualmainframe:SetPos(158, 104)
visualmainframe:SetTitle("Visuals")
visualmainframe:SetSizable(true)
visualmainframe:SetDeleteOnClose(false)
visualmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, visualmainframe:GetWide(), visualmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, visualmainframe:GetWide(), visualmainframe:GetTall()) end
visualmainframe:MakePopup()

visualmainpanel = vgui.Create("DPanel")
visualmainpanel:SetParent(visualmainframe)
visualmainpanel:SetSize(216, 228)
visualmainpanel:SetPos(7, 29)
visualmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, visualmainpanel:GetWide(), visualmainpanel:GetTall(), Color(255, 255, 255, 20))
end

visualcr = vgui.Create("DCheckBoxLabel")
visualcr:SetParent(visualmainpanel)
visualcr:SetPos(17, 43)
visualcr:SetText("Red")
visualcr:SetConVar("duck_crosshair_r")
visualcr:SetValue(GetConVarNumber("duck_crosshair_r"))
visualcr:SizeToContents()

visualcg = vgui.Create("DCheckBoxLabel")
visualcg:SetParent(visualmainpanel)
visualcg:SetPos(67, 43)
visualcg:SetText("Green")
visualcg:SetConVar("duck_crosshair_g")
visualcg:SetValue(GetConVarNumber("duck_crosshair_g"))
visualcg:SizeToContents()

visualcb = vgui.Create("DCheckBoxLabel")
visualcb:SetParent(visualmainpanel)
visualcb:SetPos(127, 43)
visualcb:SetText("Blue")
visualcb:SetConVar("duck_crosshair_b")
visualcb:SetValue(GetConVarNumber("duck_crosshair_b"))
visualcb:SizeToContents()


visualsize = vgui.Create("DButton") 
visualsize:SetParent(visualmainpanel)
visualsize:SetText( "Size" )
visualsize:SetSize(191, 18)
visualsize:SetPos(12, 73)
visualsize.DoClick = function ()
    local visualsizeChoice = DermaMenu()
    visualsizeChoice:AddOption("Small", function() 	RunConsoleCommand("duck_crosshair_style", "0") end ) 
    visualsizeChoice:AddOption("Medium", function() 	RunConsoleCommand("duck_crosshair_style", "1") end )
    visualsizeChoice:AddOption("Large", function() 	RunConsoleCommand("duck_crosshair_style", "2") end )
visualsizeChoice:Open() 
end

visuallaser1 = vgui.Create("DCheckBoxLabel")
visuallaser1:SetParent(visualmainpanel)
visuallaser1:SetPos(97, 153)
visuallaser1:SetText("Laser ")
visuallaser1:SetConVar("duck_laser")
visuallaser1:SetValue(GetConVarNumber("duck_laser"))
visuallaser1:SizeToContents()

visuallaser2 = vgui.Create("DCheckBoxLabel")
visuallaser2:SetParent(visualmainpanel)
visuallaser2:SetPos(97, 193)
visuallaser2:SetText("Laser Dot")
visuallaser2:SetConVar("duck_laser_dot")
visuallaser2:SetValue(GetConVarNumber("duck_laser_dot"))
visuallaser2:SizeToContents()
	
visualhud = vgui.Create("DCheckBoxLabel")
visualhud:SetParent(visualmainpanel)
visualhud:SetPos(17, 113)
visualhud:SetText("Heads Up Display")
visualhud:SetConVar("duck_hud")
visualhud:SetValue(GetConVarNumber("duck_hud"))
visualhud:SizeToContents()

visualradar = vgui.Create("DCheckBoxLabel")
visualradar:SetParent(visualmainpanel)
visualradar:SetPos(17, 153)
visualradar:SetText("Radar")
visualradar:SetConVar("duck_radar")
visualradar:SetValue(GetConVarNumber("duck_radar"))
visualradar:SizeToContents()

visualfb = vgui.Create("DCheckBoxLabel")
visualfb:SetParent(visualmainpanel)
visualfb:SetPos(17, 193)
visualfb:SetText("Full-Bright")
visualfb:SetConVar("duck_fullbright")
visualfb:SetValue(GetConVarNumber("duck_fullbright"))
visualfb:SizeToContents()

visualcross = vgui.Create("DCheckBoxLabel")
visualcross:SetParent(visualmainpanel)
visualcross:SetPos(17, 13)
visualcross:SetText("Crosshair")
visualcross:SetConVar("duck_crosshair")
visualcross:SetValue(GetConVarNumber("duck_crosshair"))
visualcross:SizeToContents()
/////////////////
/////////////////
/////////////////
/////////////////
end


  local DSpritev = vgui.Create( "DSprite" )
DSpritev:SetParent(mainpanel)
DSpritev:SetPos( 179, 125)
DSpritev:SetSize( 15, 15 )
DSpritev:SetMaterial( Material( "gui/silkicons/palette" ) )




listplayers = vgui.Create("DButton")
listplayers:SetParent(mainpanel)
listplayers:SetSize(50, 50)
listplayers:SetPos(250, 84)
listplayers:SetText("List")
listplayers.DoClick = function() 

/////////////////
/////////////////
/////////////////
/////////////////
local listplayerlist
local listplayerclearaim
local listplayercleartag
local listplayermainframe
local listplayermainpanel

listplayermainframe = vgui.Create("DFrame")
listplayermainframe:SetParent(listplayers)
listplayermainframe:SetSize(229, 265)
listplayermainframe:SetPos(158, 104)
listplayermainframe:SetTitle("Player List")
listplayermainframe:SetSizable(true)
listplayermainframe:SetDeleteOnClose(false)
listplayermainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, listplayermainframe:GetWide(), listplayermainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, listplayermainframe:GetWide(), listplayermainframe:GetTall()) end
listplayermainframe:MakePopup()

listplayermainpanel = vgui.Create("DPanel")
listplayermainpanel:SetParent(listplayermainframe)
listplayermainpanel:SetSize(216, 228)
listplayermainpanel:SetPos(7, 29)
listplayermainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, listplayermainpanel:GetWide(), listplayermainpanel:GetTall(), Color(255, 255, 255, 20))
end

listplayerclearaim = vgui.Create("DButton")
listplayerclearaim:SetParent(listplayermainpanel)
listplayerclearaim:SetSize(202, 18)
listplayerclearaim:SetPos(7, 198)
listplayerclearaim:SetText("Clear Ignored Players")
listplayerclearaim.DoClick = function() table.Empty(Friends) end




listplayercleartag = vgui.Create("DButton")
listplayercleartag:SetParent(listplayermainpanel)
listplayercleartag:SetSize(202, 18)
listplayercleartag:SetPos(7, 175)
listplayercleartag:SetText("Clear Tagged Players")
listplayercleartag.DoClick = function() table.Empty(Tagged) end

local listplayerlist = vgui.Create("DListView")
listplayerlist:SetParent(listplayermainpanel)
listplayerlist:SetSize(202, 157)
listplayerlist:SetPos(7, 8)
listplayerlist:SetMultiSelect(false)
listplayerlist:AddColumn("Name") 
listplayerlist:AddColumn("Friend") 


for k,ent in pairs(player.GetAll()) do 
if ent == LocalPlayer() then else

 local check



 if table.HasValue(Friends, ent:Nick())
 then check = "YES!"
 else
 check = "NO!"
 end
 listplayerlist:AddLine(ent:Nick(), check) 
 end
 end

 
listplayerlist.DoDoubleClick = function(parent, index, list)
local listplayerlistOptions = DermaMenu()
listplayerlistOptions:AddOption("Add To AimBot Friends", function() table.insert(Friends,list:GetValue(1)) end) 
listplayerlistOptions:AddOption("Tag", function() table.insert(Tagged,list:GetValue(1)) end) 
listplayerlistOptions:Open() 
end



/////////////////
/////////////////
/////////////////
/////////////////
end

 local DSpritel = vgui.Create( "DSprite" )
DSpritel:SetParent(mainpanel)
DSpritel:SetPos( 259, 127)
DSpritel:SetSize( 15, 15 )
DSpritel:SetMaterial( Material( "gui/silkicons/application_view_detail" ) )


cvars = vgui.Create("DButton")
cvars:SetParent(mainpanel)
cvars:SetSize(50, 50)
cvars:SetPos(250, 169)
cvars:SetText("CVars")
cvars.DoClick = function()
/////////////////
/////////////////
/////////////////
/////////////////

local cvarmainpanel
local cvarlabel3
local cvarforce
local cvarvalue
local cvarlabel2
local cvarcvar
local cvarlabel1
local cvarmainframe

cvarmainframe = vgui.Create("DFrame")
cvarmainframe:SetParent(cvars)
cvarmainframe:SetSize(229, 265)
cvarmainframe:SetPos(158, 104)
cvarmainframe:SetTitle("CVar Forcer")
cvarmainframe:SetSizable(true)
cvarmainframe:SetDeleteOnClose(false)
cvarmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, cvarmainframe:GetWide(), cvarmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, cvarmainframe:GetWide(), cvarmainframe:GetTall()) end
cvarmainframe:MakePopup()

cvarmainpanel = vgui.Create("DPanel")
cvarmainpanel:SetParent(cvarmainframe)
cvarmainpanel:SetSize(216, 228)
cvarmainpanel:SetPos(7, 29)
cvarmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, cvarmainpanel:GetWide(), cvarmainpanel:GetTall(), Color(255, 255, 255, 20))
end

cvarlabel1 = vgui.Create("DLabel")
cvarlabel1:SetParent(cvarmainpanel)
cvarlabel1:SetPos(17, 10)
cvarlabel1:SetText("CVar:")
cvarlabel1:SizeToContents()

cvarcvar = vgui.Create("DTextEntry")
cvarcvar:SetParent(cvarmainpanel)
cvarcvar:SetSize(172, 21)
cvarcvar:SetPos(17, 33)
cvarcvar:SetText("Fill me!")


cvarlabel2 = vgui.Create("DLabel")
cvarlabel2:SetParent(cvarmainpanel)
cvarlabel2:SetPos(17, 73)
cvarlabel2:SetText("CVar Value:")
cvarlabel2:SizeToContents()

cvarvalue = vgui.Create("DNumberWang")
cvarvalue:SetParent(cvarmainpanel)
cvarvalue:SetPos(17, 103)
cvarvalue:SetDecimals(1)
cvarvalue:SetMinMax( 0 , 1000)
cvarvalue:SetDecimals(0)	


cvarforce = vgui.Create("DButton")
cvarforce:SetParent(cvarmainpanel)
cvarforce:SetSize(172, 25)
cvarforce:SetPos(17, 148)
cvarforce:SetText("Force!")
cvarforce.DoClick = function() /*SetConvar(CreateConVar(cvarcvar:GetValue(),""), cvarvalue:GetValue()) */end

/*
function IsSpoofed(cmd)
if GetConVarNumber("duck_cvar_spoof") == 1 then
if string.find( string.lower( cvarcvar:GetValue()), cmd ) then return cvarcvar:GetValue():GetDefault() end

end
end
*/

cvarlabel3 = vgui.Create("DCheckBoxLabel")
cvarlabel3:SetParent(cvarmainpanel)
cvarlabel3:SetPos(17, 190)
cvarlabel3:SetText("Spoof CVar")
cvarlabel3:SetConVar("duck_cvar_spoof")
cvarlabel3:SetValue(GetConVarNumber("duck_cvar_spoof"))
cvarlabel3:SizeToContents()
/////////////////
/////////////////
/////////////////
/////////////////

 end

  local DSpritec = vgui.Create( "DSprite" )
DSpritec:SetParent(mainpanel)
DSpritec:SetPos( 258, 211)
DSpritec:SetSize( 15, 15 )
DSpritec:SetMaterial( Material( "gui/silkicons/table_edit" ) )
 
spam = vgui.Create("DButton")
spam:SetParent(mainpanel)
spam:SetSize(50, 50)
spam:SetPos(170, 169)
spam:SetText("Spammer")
spam.DoClick = function()
/////////////////
/////////////////
/////////////////
/////////////////
local spampropoff
local spampropon
local spamlabel2
local spammodel
local spamchatoff
local spamchaton
local spamtime1
local spamchat
local spamlabel1
local spammainpanel
local spammainframe

spammainframe = vgui.Create("DFrame")
spammainframe:SetParent(spam)
spammainframe:SetSize(229, 265)
spammainframe:SetPos(158, 104)
spammainframe:SetTitle("Spammer Bot")
spammainframe:SetSizable(true)
spammainframe:SetDeleteOnClose(false)
spammainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, spammainframe:GetWide(), spammainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, spammainframe:GetWide(), spammainframe:GetTall()) end
spammainframe:MakePopup()

spammainpanel = vgui.Create("DPanel")
spammainpanel:SetParent(spammainframe)
spammainpanel:SetSize(216, 228)
spammainpanel:SetPos(7, 29)
spammainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, spammainpanel:GetWide(), spammainpanel:GetTall(), Color(255, 255, 255, 20)) 
end

spamlabel1 = vgui.Create("DLabel")
spamlabel1:SetParent(spammainpanel)
spamlabel1:SetPos(17, 13)
spamlabel1:SetText("Chat Spam: ")
spamlabel1:SizeToContents()

spamchat = vgui.Create("DTextEntry")
spamchat:SetParent(spammainpanel)
spamchat:SetSize(182, 31)
spamchat:SetPos(17, 34)
spamchat:SetText("Insert Spam Message Here")


spamtime1 = vgui.Create("DNumSlider")
spamtime1:SetSize(182, 40)
spamtime1:SetParent(spammainpanel)
spamtime1:SetPos(16, 68)
spamtime1:SetDecimals(3)
spamtime1:SetText("Frequency")
spamtime1:SetConVar("duck_spam_time")
spamtime1:SetValue(GetConVarNumber("duck_spam_time"))
spamtime1:SetMinMax( 0.001, 3)

spamchaton = vgui.Create("DButton")
spamchaton:SetParent(spammainpanel)
spamchaton:SetSize(91, 25)
spamchaton:SetPos(17, 111)
spamchaton:SetText("Spam Chat")
spamchaton.DoClick = function() 
timer.Create("SpamChat", GetConVarNumber("duck_spam_time"), 0, function() RunConsoleCommand("say", spamchat:GetValue()) end)
end

spamchatoff = vgui.Create("DButton")
spamchatoff:SetParent(spammainpanel)
spamchatoff:SetSize(91, 25)
spamchatoff:SetPos(109, 111)
spamchatoff:SetText("Stop Spam")
spamchatoff.DoClick = function()
timer.Destroy("SpamChat")
 end

spammodel = vgui.Create("DTextEntry")
spammodel:SetParent(spammainpanel)
spammodel:SetSize(182, 23)
spammodel:SetPos(17, 162)
spammodel:SetText("Insert Model Path Here")


spamlabel2 = vgui.Create("DLabel")
spamlabel2:SetParent(spammainpanel)
spamlabel2:SetPos(17, 141)
spamlabel2:SetText("Prop Spam")
spamlabel2:SizeToContents()

spampropon = vgui.Create("DButton")
spampropon:SetParent(spammainpanel)
spampropon:SetSize(91, 25)
spampropon:SetPos(17, 189)
spampropon:SetText("Spam Prop")
spampropon.DoClick = function() 
timer.Create("SpamProp", 0.001, 0, function() RunConsoleCommand("gm_spawn", spammodel:GetValue()) end)
end

spampropoff = vgui.Create("DButton")
spampropoff:SetParent(spammainpanel)
spampropoff:SetSize(91, 25)
spampropoff:SetPos(109, 189)
spampropoff:SetText("Stop Spam")
spampropoff.DoClick = function() 
timer.Destroy("SpamProp")
end
/////////////////
/////////////////
/////////////////
/////////////////
end

  local DSprites = vgui.Create( "DSprite" )
DSprites:SetParent(mainpanel)
DSprites:SetPos( 178, 211)
DSprites:SetSize( 15, 15 )
DSprites:SetMaterial( Material( "gui/silkicons/exclamation" ) )

wallhack = vgui.Create("DButton")
wallhack:SetParent(mainpanel)
wallhack:SetSize(50, 50)
wallhack:SetPos(90, 169)
wallhack:SetText("WallHack")
wallhack.DoClick = function() 
/////////////////
/////////////////
/////////////////
/////////////////
local whmainpanel
local whmat
local whb
local whg
local whr
local whob
local whog
local whor
local whre
local whteam
local whon
local whmainframe

whmainframe = vgui.Create("DFrame")
whmainframe:SetParent(wallhack)
whmainframe:SetSize(229, 265)
whmainframe:SetPos(158, 104)
whmainframe:SetTitle("WallHack")
whmainframe:SetSizable(true)
whmainframe:SetDeleteOnClose(false)
whmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, whmainframe:GetWide(), whmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, whmainframe:GetWide(), whmainframe:GetTall()) end
whmainframe:MakePopup()

whmainpanel = vgui.Create("DPanel")
whmainpanel:SetParent(whmainframe)
whmainpanel:SetSize(216, 228)
whmainpanel:SetPos(7, 29)
whmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, whmainpanel:GetWide(), whmainpanel:GetTall(), Color(255, 255, 255, 20))
end

whon =  vgui.Create("DButton")
whon:SetParent(whmainpanel)
whon:SetSize(190,25)
whon:SetPos(17, 13)
whon:SetText("WallHack Toggle")
whon.DoClick = function() 	RunConsoleCommand("duck_wallhack_toggle") end


whteam = vgui.Create("DCheckBoxLabel")
whteam:SetParent(whmainpanel)
whteam:SetPos(17, 43)
whteam:SetText("Only Draw On Enemies")
whteam:SetConVar("duck_teamw")
whteam:SetValue(GetConVarNumber("duck_teamw"))
whteam:SizeToContents()

whre = vgui.Create("DCheckBoxLabel")
whre:SetParent(whmainpanel)
whre:SetPos(17, 78)
whre:SetText("Relative To Team And Health")
whre:SetConVar("duck_wallhack_Relative")
whre:SetValue(GetConVarNumber("duck_wallhack_Relatives"))
whre:SizeToContents()
function whre:OnChange() 
						if whre:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Red", "0" )
								RunConsoleCommand( "Duck_Wallhack_Green", "0" )
								RunConsoleCommand( "Duck_Wallhack_Blue", "0" )
								RunConsoleCommand( "Duck_Wallhack_Outline_Red", "0" )
								RunConsoleCommand( "Duck_Wallhack_Outline_Green", "0" )
								RunConsoleCommand( "Duck_Wallhack_Outline_Blue", "0" )
								whr:SetValue(0)
								whg:SetValue(0)
								whb:SetValue(0)
								whor:SetValue(0)
								whog:SetValue(0)
								whob:SetValue(0)								
							end
						end


whr = vgui.Create("DCheckBoxLabel")
whr:SetParent(whmainpanel)
whr:SetPos(17, 113)
whr:SetText("Red")
whr:SetConVar("duck_wallhack_Red")
whr:SetValue(GetConVarNumber("duck_wallhack_Red"))
whr:SizeToContents()
function whr:OnChange() 
						if whr:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end

whor = vgui.Create("DCheckBoxLabel")
whor:SetParent(whmainpanel)
whor:SetPos(107, 113)
whor:SetText("Outline Red")
whor:SetConVar("duck_wallhack_outline_Red")
whor:SetValue(GetConVarNumber("duck_wallhack_outline_Red"))
whor:SizeToContents()
function whor:OnChange() 
						if whor:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end


whg = vgui.Create("DCheckBoxLabel")
whg:SetParent(whmainpanel)
whg:SetPos(17, 143)
whg:SetText("Green")
whg:SetConVar("duck_wallhack_green")
whg:SetValue(GetConVarNumber("duck_wallhack_green"))
whg:SizeToContents()
function whg:OnChange() 
						if whg:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end


whog = vgui.Create("DCheckBoxLabel")
whog:SetParent(whmainpanel)
whog:SetPos(107, 143)
whog:SetText("Outline Green")
whog:SetConVar("duck_wallhack_outline_Green")
whog:SetValue(GetConVarNumber("duck_wallhack_outline_Green"))
whog:SizeToContents()
function whog:OnChange() 
						if whog:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end


whb = vgui.Create("DCheckBoxLabel")
whb:SetParent(whmainpanel)
whb:SetPos(17, 173)
whb:SetText("Blue")
whb:SetConVar("duck_wallhack_blue")
whb:SetValue(GetConVarNumber("duck_wallhack_blue"))
whb:SizeToContents()
function whb:OnChange() 
						if whb:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end


whob = vgui.Create("DCheckBoxLabel")
whob:SetParent(whmainpanel)
whob:SetPos(107, 173)
whob:SetText("Outline Blue")
whob:SetConVar("duck_wallhack_outline_Blue")
whob:SetValue(GetConVarNumber("duck_wallhack_outline_Blue"))
whob:SizeToContents()
function whob:OnChange() 
						if whob:GetChecked() then
								RunConsoleCommand( "Duck_Wallhack_Relative", "0" )
								whre:SetValue( 0 )
							end
						end


		whmat = vgui.Create("DButton") 
        whmat:SetParent(whmainpanel)
        whmat:SetSize(188, 28)
        whmat:SetPos(15, 198)
		whmat:SetText("Material")
       whmat.DoClick = function ()
    local whmatChoice = DermaMenu()
      whmatChoice:AddOption("No Wall", function() 	RunConsoleCommand("duck_wallhack_material", "0") end ) 
	whmatChoice:AddOption("Full", function() 	RunConsoleCommand("duck_wallhack_material", "1")  end ) 
 whmatChoice:AddOption("WireFrame", function() 	RunConsoleCommand("duck_wallhack_material", "2")  end ) 

 
 whmatChoice:Open() 
end
/////////////////
/////////////////
/////////////////
/////////////////
end
 
 local DSpritew = vgui.Create( "DSprite" )
DSpritew:SetParent(mainpanel)
DSpritew:SetPos( 98, 211)
DSpritew:SetSize( 15, 15 )
DSpritew:SetMaterial( Material( "gui/silkicons/user" ) )

esp = vgui.Create("DButton")
esp:SetParent(mainpanel)
esp:SetSize(50, 50)
esp:SetPos(10, 169)
esp:SetText("ESP")
esp.DoClick = function()

/////////////////
/////////////////
/////////////////
/////////////////

local espmainpanel
local espttt
local espvisible
local espweaps
local espweapp
local espnpc
local esphealth
local espteam
local espon
local espfont
local espmainframe

espmainframe = vgui.Create("DFrame")
espmainframe:SetParent(esp)
espmainframe:SetSize(229, 265)
espmainframe:SetPos(158, 104)
espmainframe:SetTitle("ESP")
espmainframe:SetSizable(true)
espmainframe:SetDeleteOnClose(false)
espmainframe.Paint = function() 
draw.RoundedBox(0, 2, 2, espmainframe:GetWide(), espmainframe:GetTall(), Color(1, 1, 11, 225))
surface.SetDrawColor(color_white)
surface.DrawOutlinedRect(0, 0, espmainframe:GetWide(), espmainframe:GetTall()) end
espmainframe:MakePopup()

espmainpanel = vgui.Create("DPanel")
espmainpanel:SetParent(espmainframe)
espmainpanel:SetSize(216, 228)
espmainpanel:SetPos(7, 29)
espmainpanel.Paint = function() 
draw.RoundedBox(0, 2, 2, espmainpanel:GetWide(), espmainpanel:GetTall(), Color(255, 255, 255, 20))
end



espon = vgui.Create("DCheckBoxLabel")
espon:SetParent(espmainpanel)
espon:SetPos(17, 13)
espon:SetText("ESP")
espon:SetConVar("duck_esp")
espon:SetValue(GetConVarNumber("duck_esp"))
espon:SizeToContents()

espteam = vgui.Create("DCheckBoxLabel")
espteam:SetParent(espmainpanel)
espteam:SetPos(17, 43)
espteam:SetText("Only Draw On Enemies")
espteam:SetConVar("duck_team")
espteam:SetValue(GetConVarNumber("duck_team"))
espteam:SizeToContents()

esphealth = vgui.Create("DCheckBoxLabel")
esphealth:SetParent(espmainpanel)
esphealth:SetPos(17, 73)
esphealth:SetText("Show Health")
esphealth:SetConVar("duck_esp_phealth")
esphealth:SetValue(GetConVarNumber("duck_esp_phealth"))
esphealth:SizeToContents()

espnpc = vgui.Create("DCheckBoxLabel")
espnpc:SetParent(espmainpanel)
espnpc:SetPos(17, 103)
espnpc:SetText("Show NPCs")
espnpc:SetConVar("duck_esp_npc")
espnpc:SetValue(GetConVarNumber("duck_esp_npc"))
espnpc:SizeToContents()

espweapp = vgui.Create("DCheckBoxLabel")
espweapp:SetParent(espmainpanel)
espweapp:SetPos(17, 133)
espweapp:SetText("Show Inventory")
espweapp:SetConVar("duck_esp_pweapon")
espweapp:SetValue(GetConVarNumber("duck_esp_pweapon"))
espweapp:SizeToContents()

espweaps = vgui.Create("DCheckBoxLabel")
espweaps:SetParent(espmainpanel)
espweaps:SetPos(121, 133)
espweaps:SetText("Show Weaps")
espweaps:SetConVar("duck_esp_weapon")
espweaps:SetValue(GetConVarNumber("duck_esp_weapon"))
espweaps:SizeToContents()

espvisible = vgui.Create("DCheckBoxLabel")
espvisible:SetParent(espmainpanel)
espvisible:SetPos(17, 163)
espvisible:SetText("Show Visible Box")
espvisible:SetConVar("duck_esp_pvisible")
espvisible:SetValue(GetConVarNumber("duck_esp_pvisible"))
espvisible:SizeToContents()

espttt = vgui.Create("DCheckBoxLabel")
espttt:SetParent(espmainpanel)
espttt:SetPos(17, 193)
espttt:SetText("Trouble in Terrorist Town Mode")
espttt:SetConVar("duck_esp_ttt")
espttt:SetValue(GetConVarNumber("duck_esp_ttt"))
espttt:SizeToContents()

/////////////////
/////////////////
/////////////////
/////////////////

 end

  local DSpritee = vgui.Create( "DSprite" )
DSpritee:SetParent(mainpanel)
DSpritee:SetPos( 19, 212)
DSpritee:SetSize( 15, 15 )
DSpritee:SetMaterial( Material( "gui/silkicons/application_view_tile" ) )
 
end)
print("DuckBot Loaded")


