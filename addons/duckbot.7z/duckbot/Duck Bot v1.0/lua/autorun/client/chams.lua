
askfgaksdlocal MaterialBlurX = Material( "pp/blurx" );
local MaterialBlurY = Material( "pp/blury" );
local MaterialWhite = CreateMaterial( "WhiteMaterial", "VertexLitGeneric", {
    ["$basetexture"] = "color/white",
    ["$vertexalpha"] = "1",
    ["$model"] = "1",
} );
local MaterialComposite = CreateMaterial( "CompositeMaterial", "UnlitGeneric", {
    ["$basetexture"] = "_rt_FullFrameFB",
    ["$additive"] = "1",
} );
 
// we need two render targets, if you don't want to create them yourself, you can
// use the bloom textures, they are quite low resolution though.
// render.GetBloomTex0() and render.GetBloomTex1();
local RT1 = GetRenderTarget( "L4D1" );
local RT2 = GetRenderTarget( "L4D2" );
 
/*------------------------------------
   RenderToStencil()
------------------------------------*/
local function RenderToStencil( entity )
 
   // tell the stencil buffer we're going to write a value of one wherever the model
    // is rendered
    render.SetStencilEnable( true );
    render.SetStencilFailOperation( STENCILOPERATION_KEEP );
    render.SetStencilZFailOperation( STENCILOPERATION_KEEP );
    render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS );
    render.SetStencilWriteMask( 1 );
    render.SetStencilReferenceValue( 1 );
     
    // this uses a small hack to render ignoring depth while not drawing color
    // i couldn't find a function in the engine to disable writing to the color channels
   // i did find one for shaders though, but I don't feel like writing a shader for this.
    cam.IgnoreZ( true );
        render.SetBlend( 0 );
			local weap = nil
			if entity:GetActiveWeapon() != nil then
					weap = entity:GetActiveWeapon()
			end
			
            SetMaterialOverride( MaterialWhite );
                entity:DrawModel();
				if weap != nil and ValidEntity(weap) then
					weap:DrawModel();
				end
            SetMaterialOverride();
             
        render.SetBlend( 1 );
    cam.IgnoreZ( false );
     
    // don't need this for the next pass
   render.SetStencilEnable( false );
 
end
 
/*------------------------------------
   RenderToGlowTexture()
------------------------------------*/
local function RenderToGlowTexture( entity )

	local w, h = ScrW(), ScrH();

	// draw into the white texture
	local oldRT = render.GetRenderTarget();
	render.SetRenderTarget( RT1 );
		render.SetViewPort( 0, 0, 512, 512 );
		
		cam.IgnoreZ( true );
			local weap = nil
			render.SuppressEngineLighting( true );
			if entity:IsPlayer() then
				local col = team.GetColor(entity:Team())
				render.SetColorModulation( col.r/255, col.g/255, col.b/255);
				
				if entity:GetActiveWeapon() != nil then
					weap = entity:GetActiveWeapon()
				end
			else
				render.SetColorModulation(1,1,1);
			end
			
				SetMaterialOverride( MaterialWhite );
					entity:DrawModel();
					if weap != nil and ValidEntity(weap) then
						weap:DrawModel();
					end
				SetMaterialOverride();
				
			render.SetColorModulation( 1, 1, 1 );
			render.SuppressEngineLighting( false );
			
		cam.IgnoreZ( false );
		
		render.SetViewPort( 0, 0, w, h );
	render.SetRenderTarget( oldRT );

end
 
/*------------------------------------
   RenderScene()
------------------------------------*/
local function RenderScene( Origin, Angles )
 
   local oldRT = render.GetRenderTarget();
        render.SetRenderTarget( RT1 );
        render.Clear( 0, 0, 0, 255, true );
        render.SetRenderTarget( oldRT );
 
end
hook.Add( "RenderScene", "ResetGlow", RenderScene );
 
/*------------------------------------
   RenderScreenspaceEffects()
------------------------------------*/
local function RenderScreenspaceEffects( )
 
   MaterialBlurX:SetMaterialTexture( "$basetexture", RT1 );
   MaterialBlurY:SetMaterialTexture( "$basetexture", RT2 );
   MaterialBlurX:SetMaterialFloat( "$size", 2 );
   MaterialBlurY:SetMaterialFloat( "$size", 2 );
       
   local oldRT = render.GetRenderTarget();
   
   // blur horizontally
   render.SetRenderTarget( RT2 );
   render.SetMaterial( MaterialBlurX );
   render.DrawScreenQuad();
 
   // blur vertically
   render.SetRenderTarget( RT1 );
   render.SetMaterial( MaterialBlurY );
   render.DrawScreenQuad();
 
   render.SetRenderTarget( oldRT );
   
   // tell the stencil buffer we're only going to draw
    // where the player models are not.
    render.SetStencilEnable( true );
    render.SetStencilReferenceValue( 0 );
    render.SetStencilTestMask( 1 );
    render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL );
    render.SetStencilPassOperation( STENCILOPERATION_ZERO );
     
    // composite the scene
    MaterialComposite:SetMaterialTexture( "$basetexture", RT1 );
    render.SetMaterial( MaterialComposite );
    render.DrawScreenQuad();
 
    // don't need this anymore
   render.SetStencilEnable( false );
 
end
hook.Add( "RenderScreenspaceEffects", "CompositeGlow", RenderScreenspaceEffects );
 
/*------------------------------------
   PrePlayerDraw()
------------------------------------*/
local function PostPlayerDraw( pl )
       
   // prevent recursion
   if( OUTLINING_PLAYER ) then return; end
   OUTLINING_PLAYER = true;
   
   RenderToStencil( pl );
   RenderToGlowTexture( pl );
   
   // prevents recursion time
   OUTLINING_PLAYER = false;
   
    if( ScrW() == ScrH() ) then return; end

end //PostDrawOpaqueRenderables
hook.Add( "PostPlayerDraw", "RenderGlow", PostPlayerDraw );

				for _, ent in pairs(ents.GetAll()) do						  
			if ent:IsPlayer() then
			if Enemies(ent) then
			
	//pos		
			local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()
	
	//colors
local alpha = math.Clamp((10000 - ent:GetPos():Distance(LocalPlayer():GetShootPos())) * (25 / (500 - 100)), 100, 255)
local tc = team.GetColor(ent:Team())	
local vs 
local hp
local wbflash = (math.sin(RealTime()*3)+1)*122.5 
local tagged = Color(0,0,0,255)
local outline 



if ent.GetActiveWeapon then
							weap = ent:GetActiveWeapon()
						else
							weap = nil 
							end
 
	//color extensions
if ent:Health() <20 then hp = Color(255,0,0,alpha) elseif ent:Health() <50 then hp = Color(255,255,0,alpha) elseif ent:Health() >49 then hp = Color(0,255,0,alpha) end
if visible(ent) then vs = Color( 0, 255, 0, alpha ) else vs = Color( 255, 0, 0, alpha ) end
if Target() == ent then outline = Color(255,0,0,alpha) else outline = Color(0,0,0,alpha) end
local health =  math.Clamp( ent:Health(), -1, 100 ) 

		
		//teh draw
		if GetConVarNumber("duck_esp") == 1 then
		
	
		draw.SimpleTextOutlined(ent:GetName(), font , pos.x, pos.y-20, Color(tc.r, tc.g, tc.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, outline)
        end
     
	    if table.HasValue(Tagged, ent:Nick()) then
		surface.SetDrawColor(wbflash,0,0,alpha) 
		 surface.DrawLine(pos.x-50,pos.y,pos.x+50,pos.y)
		  surface.DrawLine(pos.x,pos.y-50,pos.x,pos.y+50)
	      tagged = Color(wbflash,0,0,alpha)
		end
	 
		if GetConVarNumber("duck_esp_pvisible") == 1 && GetConVarNumber("duck_esp") == 1 then	
		draw.RoundedBox( 1, pos.x+surface.GetTextSize(ent:GetName()), pos.y-16, 10, 10, vs )
		  surface.SetDrawColor( tagged )
			surface.DrawOutlinedRect(  pos.x+surface.GetTextSize(ent:GetName()), pos.y-16, 11, 11)

		end
		 
         if GetConVarNumber("duck_esp_pweapon") == 1 && GetConVarNumber("duck_esp") == 1 then			
		if ValidEntity(weap) then
		draw.SimpleTextOutlined(weap:GetPrintName(), font ,(pos.x+surface.GetTextSize(ent:GetName()))+13, pos.y-20, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, tagged)
		else
		draw.SimpleTextOutlined("NONE", font , pos.x+surface.GetTextSize(ent:GetName())+13, pos.y-20, Color(255, 255, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, tagged)
		end      
end

	  if GetConVarNumber("duck_esp_phealth") == 1 && GetConVarNumber("duck_esp") == 1 then			
      
	    if GetConVarNumber("duck_esp_typehealth") == 0 then	
	    draw.RoundedBox(1, pos.x-3, pos.y-4, 106, 10, tagged,TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
		draw.RoundedBox(1, pos.x, pos.y-1, health, 4, hp,TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT) 
		elseif GetConVarNumber("duck_esp_typehealth") == 1 then
	    draw.SimpleTextOutlined(ent:Health(), font , pos.x, pos.y-40, hp, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1,  Color(0, 0, 0, alpha))
		end
		end
		
			if ent:GetFriendStatus() == "friend" && GetConVarNumber("duck_esp") == 1 then 
				surface.SetDrawColor(wbflash, 0, 0, 255)
				surface.DrawOutlinedRect( pos.x-10, pos.y, 30, 70)
		end
		
		end
	
	elseif ent:IsNPC() then
  
    local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()  
 
	if GetConVarNumber("duck_esp") == 1 &&  GetConVarNumber("duck_esp_npc") == 1 then
	draw.SimpleTextOutlined(ent:GetClass(), font , pos.x + 27, pos.y - 10, Color(255,255,255,255), 2, 1, 1, Color(0, 0, 0, 255 ))
	end	
	
	elseif ent:IsWeapon() then
	
	    local pos = ent:GetPos() + Vector(0,0,70)
			pos = pos:ToScreen()  
	
	if GetConVarNumber("duck_esp") == 1 && GetConVarNumber("duck_esp_weapon") == 1 then
	if ent:GetMoveType() == 0 then
	else
		draw.SimpleTextOutlined(ent:GetPrintName(), font , pos.x, pos.y+100, Color(255,0,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,255))
	end
	end
	end
	end
