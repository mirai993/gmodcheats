-- fagkirby "STEAM_0:0:25093119" -- http://steamcommunity.com/id/HookerSometimes/

--derp some stuff isnt mine, im like the only one who uses it so. Will remake fully when i have time kthx
--stuff that has no indent is old

print("DuckBot Loading...")

local include = include
local require = require

require("concommand")
require("gamemode")
require("weapons")
require("hook")
require("timer")
require("list")
require("cvars")
require("http")
require("datastream")
require("draw")
require( "markup" )
require("controlpanel")
require("presets")
require("cookie")

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
local surface = surface
local draw = draw
local cam = cam
local input = input
local os = os
local render = render

local Entity = Entity
local Player = Player
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = ValidEntity
local Vector = Vector
local GetConVarNumber = GetConVarNumber


CreateClientConVar("duck_speed", 5, true, false)
CreateClientConVar("duck_menu_fadeout", 0, true, false)
CreateClientConVar("Duck_Wallhack_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_team", 0, true, false)
CreateClientConVar("Duck_Wallhack_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Alpha", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Red", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Green", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Blue", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Alpha", 0, true, false)
CreateClientConVar("Duck_Wallhack_Material", 1, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Material", 1, true, false)
CreateClientConVar("Duck_Wallhack_OC_Style", 1, true, false)
CreateClientConVar("Duck_Wallhack_C_Style", 1, true, false)
CreateClientConVar("Duck_Wallhack_Outline", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Thick", 0, true, false)
CreateClientConVar("Duck_Wallhack_Pass", 0, true, false)
CreateClientConVar("Duck_Wallhack_Outline_Pass", 0, true, false)

CreateClientConVar("duck_crosshair_dot", 0, true, false)
CreateClientConVar("duck_crosshair_circle", 0, true, false)
CreateClientConVar("duck_crosshair_cross", 0, true, false)
CreateClientConVar("duck_crosshair_r", 0, true, false)
CreateClientConVar("duck_crosshair_g", 0, true, false)
CreateClientConVar("duck_crosshair_b", 0, true, false)
CreateClientConVar("duck_hands", 1, true, false)
CreateClientConVar("duck_hud", 0, true, false)
CreateClientConVar("duck_spec", 0, true, false)
CreateClientConVar("duck_hud_mirror", 0, true, false)


CreateClientConVar("duck_esp", 0, true, false)
CreateClientConVar("duck_esp_font", 1, true, false)
CreateClientConVar("duck_esp_team", 0, true, false)
CreateClientConVar("duck_esp_pvisible", 0, true, false)
CreateClientConVar("duck_esp_pvisibletype", 1, true, false)
CreateClientConVar("duck_esp_pweapon", 0, true, false)
CreateClientConVar("duck_esp_pweaponicon", 0, true, false)
CreateClientConVar("duck_esp_phealth", 0, true, false)
CreateClientConVar("duck_esp_phtype", 1, true, false)
CreateClientConVar("duck_esp_pskeleton", 0, true, false)
CreateClientConVar("duck_esp_pskeletoncol", 1, true, false)
CreateClientConVar("duck_esp_ttt_traitor", 0, true, false)
CreateClientConVar("duck_esp_ttt_c4", 0, true, false)
CreateClientConVar("duck_esp_ttt_nade", 0, true, false)
CreateClientConVar("duck_ttt_boom", 0, true, false)
CreateClientConVar("duck_esp_aimpos", 0, true, false)
CreateClientConVar("duck_esp_track", 0, true, false)

CreateClientConVar("duck_laser", 0, true, false)
CreateClientConVar("duck_laser_dot", 0, true, false)

CreateClientConVar("duck_crosshair", 1, true, false)
CreateClientConVar("duck_crosshair_style", 1, true, false)
CreateClientConVar("duck_fullbright", 0, true, false)

CreateClientConVar("duck_zoom", 0, true, false)

CreateClientConVar("duck_trigger", 0, true, false) 
CreateClientConVar("duck_trigger_head", 0, true, false) 

CreateClientConVar("duck_sys_nospread", 0, true, false)
CreateClientConVar("duck_sys_nospread_onmethod", 1, true, false)
CreateClientConVar("duck_sys_nospread_aim", 0, true, false)

CreateClientConVar("duck_aim_friends", 0, true, false) 
CreateClientConVar("duck_aim_fov", 0, true, false)  
CreateClientConVar("duck_aim_team", 0, true, false)     
CreateClientConVar("duck_aim_plus", 4, true, false )
CreateClientConVar("duck_aim_comp", 45, true, false )
CreateClientConVar("duck_aim_slow", 0, true, false)  
CreateClientConVar("duck_aim_slow_speed", 0, true, false)   
CreateClientConVar("duck_aim_npc", 0, true, false)   
CreateClientConVar("duck_aim_player", 0, true, false)   
CreateClientConVar("duck_aim_auto", 0, true, false)   
CreateClientConVar("duck_aim_draw", 0, true, false) 
CreateClientConVar("duck_aim_ttt", 0, true, false) 
CreateClientConVar("duck_radar", 0, true, false) 

CreateClientConVar("duck_spam_time", 0.01, true, false) 

CreateClientConVar("duck_spin", 0, true, false) 
CreateClientConVar("duck_autofire", 0, true, false) 
CreateClientConVar("duck_bhop", 0, true, false) 
CreateClientConVar("duck_view", 0, true, false) 

local oldfl = file.Read--not gonna do anything but oh well


--fuckingfile.Read("../DuckBot.lua") 

local oldget = http.Get;

function mycallback(args, contents , size)
	file.Write("data/https_callback.txt", "Size: " .. size .. "\nContents:\n" .. contents .. "\n\nArgs:\n");
	
	for k,v in pairs(args) do
		file.Append("data/https_callback.txt", k .. " : " .. v .. "\n");
	end
end

function http.Get(url, headers, callback, ...)

	file.Write("data/https.txt", "Url: " .. url .. "\nHeaders:" .. headers)
	
    oldget(url, headers, mycallback, ..)

end




function file.Read(name, usePath)--lol
    if name == "DuckBot.lua" then
        return "You sneaky doody."
    else
        return oldfl(name, usePath)
    end
end

Player.Ban(time, reason)
	
	return nil

end


function render.ReadPixel(x,y)
    return Color(x/y*math.Rand(0,255),y^x*5,x/y^math.Rand(0,255),255)--its my graphics card!
end
	
local function head(ent) 
        local headbone = ent:LookupBone("ValveBiped.Bip01_Head1") 
        return ent:GetBonePosition(headbone) 
end 

local function visible(ent) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = head(ent)+ent:GetVelocity()*RealFrameTime(),filter = {LocalPlayer(), ent}, mask = MASK_SHOT} 
    local tr = util.TraceLine(trace) 
    if tr.Fraction == 1 then 
        return true 
    else 
        return false 
    end     
end 
	
	local function IsAdmin(ent)
	if ent:IsAdmin() || ent:IsSuperAdmin() then 
		return true
		end
	return false
end

local function GetAdminType(ent)

	
	if ent:IsAdmin() && !ent:IsSuperAdmin()  then
		return "Admin"
		
	elseif ent:IsSuperAdmin() then
		return "Super Admin"
	
	elseif !ent:IsSuperAdmin() || !ent:IsAdmin() then
		return "Guest"
	end
	
	return ""

      end

require("localcommand")//name blocked, fuck
require("syshack")
require("hermes")

--cheat.ReloadMaterials()
--cheat.GetMaterials()

local function HL2Cones( value, typ, vec )
	if ( !vec ) then return tonumber( value ) end
	local s = ( tonumber( -value ) )
	
	if ( typ == true ) then
		s = ( tonumber( -value ) )
	elseif ( typ == false ) then
		s = ( tonumber( value ) )
	else
		s = ( tonumber( value ) )
	end
	return Vector( s, s, s )
end

local HL2 	= {}
HL2.weapons = {}
HL2.weapons [ "weapon_pistol" ]			= { cone = HL2Cones( 0.0100, true, false ) }	// HL2 Pistol
HL2.weapons [ "weapon_smg1" ]			= { cone = HL2Cones( 0.04362, true, false ) }	// HL2 SMG1
HL2.weapons [ "weapon_ar2" ]			= { cone = HL2Cones( 0.02618, true, false ) }	// HL2 AR2
HL2.weapons [ "weapon_shotgun" ]		= { cone = HL2Cones( 0.08716, true, false ) }	// HL2 SHOTGUN



local function ReturnSeed(weapon) //get the seed
	local Normalseed = {["weapon_cs_base"] = true} //normal css weapons
	local cone = weapon.Cone
	
	if !cone && type(weapon.Primary) == "table" && type(weapon.Primary.Cone) == "number" then
		cone = weapon.Primary && weapon.Primary.Cone end
	if !cone then cone = 0 end //sweps
	
	// the filter
	if type(weapon.Base) == "string" && Normalseed[weapon.Base] then return cone end //normal

	
	return cone || 0
end

local function DuckNospread()
	
	if  !ValidEntity(LocalPlayer()) || !LocalPlayer():IsPlayer()  then return end
	local weapon = LocalPlayer():GetActiveWeapon()

		
	if !( weapon ) then return end
	
			
		if ( weapon && weapon:IsValid() ) then
			local weptable = weapon:GetTable()
				
						
			local override = {}
			for c, s in pairs( HL2.weapons ) do
				if ( string.match( string.lower( weapon:GetClass() ), c ) ) then
					override = s
					break
				end
			end
			
			cone = ( override.cone || tonumber( ReturnSeed( weptable, "Cone" ) ) || 0 )
			numshots = ( override.numshots || tonumber( ReturnSeed( weptable, "NumShots" ) ) || 0 )
			strange_weapon = override.no_rapid
		
				
			if ( override.automatic != nil ) then
				automatic = override.automatic
			else automatic = ReturnSeed( weptable, "Automatic" ) end
				
			if ( weptable && weptable.Primary ) then end
						
		else
			cone = 0
			automatic = true
		end
			end
hook.Add("HUDPaint", "NoSpread", DuckNospread)

local inited = false

function ConstantNospread(UCMD)
if not inited then
                inited = true
                myangles = UCMD:GetViewAngles()
             cv_sensitivity = GetConVar("sensitivity")
        end
        

		local sensitivity = cv_sensitivity:GetFloat()/200
        myangles = override && UCMD:GetViewAngles() || Angle(math.max(math.min(myangles.p+UCMD:GetMouseY()*sensitivity, 90), -90),myangles.y-UCMD:GetMouseX()*sensitivity,0)


		if GetConVarNumber("duck_sys_nospread_onmethod") == 1 && !UCMD:KeyDown(IN_ATTACK) then myangles = UCMD:GetViewAngles() return end
		if GetConVarNumber("duck_sys_nospread_onmethod") == 2 && !UCMD:KeyDown(IN_ATTACK2) then myangles = UCMD:GetViewAngles() return end
		
	   if GetConVarNumber("duck_sys_nospread") == 1
        then
	  
      local  Constant = Angle(myangles.p, myangles.y, myangles.r)
 
        Constant = hack.CompensateWeaponSpread(UCMD, Vector(-cone, -cone, -cone), Constant:Forward()):Angle()
        UCMD:SetViewAngles(Constant)
		hook.Add("CalcView", "Spin", NoSpin)	
		end
		end
 hook.Add("CreateMove","ConstantNospread", ConstantNospread)
 
function NoSpin()
if GetConVarNumber("duck_sys_nospread") == 1 then
local viewpos = {} 
	
viewpos.angles = LocalPlayer():EyeAngles() + myangles - LocalPlayer():EyeAngles()
viewpos.fov = FOV
return viewpos
end
end


local function AutoJump(UCMD)
    if GetConVarNumber("duck_bhop") == 1 && !LocalPlayer():IsOnGround() then
    if  LocalPlayer():GetMoveType() == 9 then else
	if UCMD:KeyDown(IN_JUMP) then
    UCMD:SetButtons(UCMD:GetButtons() - IN_JUMP)
	end
        end	
			end
end
hook.Add("CreateMove", "jump", AutoJump)


local Friends = {}

local function AimFilter(ent)
	if !ent:IsValid() || (!ent:IsNPC() && !ent:IsPlayer()) || ent == LocalPlayer() || !LocalPlayer():Alive() then return false end
	
	if ent:IsPlayer() then 
	if !ent:Alive() || ent:Health() < 1 then return false end
	if ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_aim_team") == 1 then return false end
	if table.HasValue(Friends,ent:Nick()) then return false end
	if GetConVarNumber("duck_aim_friends") == 1 && ent:GetFriendStatus() == "friend" then return false end  
	if ent:GetModel() == "models/player.mdl" then return false end--fuck off spectators!
	if GetConVarNumber("Duck_aim_ttt") == 1 && string.find(GAMEMODE.Name,"Trouble in Terrorist Town") && LocalPlayer():IsTraitor() && ent:IsTraitor() then return false end
	end
	
	if ent:IsNPC() then
	if GetConVarNumber("duck_aim_npc") == 1 then if ent:IsNPC() then return false end end
	if ent:GetMoveType() == 0 then return false end 
	end
	return true
end

local function FOVRestrict(ent, value)
	return LocalPlayer():GetAimVector():DotProduct((ent:GetPos() - LocalPlayer():GetPos()):Normalize()) > value
end

local function Target()
	local e = ents.GetAll()
	local lastang = 0
	local target = 0
	for i = 1, table.Count( e ) do
		local ent = e[i]
		if AimFilter(ent) && visible(ent) && FOVRestrict(ent, GetConVarNumber("duck_aim_fov")) then
			local ang = (head(ent)-LocalPlayer():EyePos()):Normalize()
			ang = ang - LocalPlayer():GetAimVector()
			ang = ang:Length()
			if ang < lastang || target == 0 then
				lastang = ang
				target = ent
			end
		end
	end
	return target
end

local Aim = false
local targpos--for view fix
local ent-- same as above
local spinfix--for 360calcview
local spinside
local aimat
local function Aimbot(UCMD)
	ent = Target()
	if ent != 0 then
		local m = ent:GetModel()
		local modelfix = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))	
		if ( m == "models/crow.mdl" || m == "models/pigeon.mdl" ) then modelfix = ent:LocalToWorld( Vector( 0, 0, 5 ) )  end
		if ( m == "models/seagull.mdl" ) then modelfix = ent:LocalToWorld( Vector( 0, 0, 6 ) ) end
		if ( m == "models/combine_scanner.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Scanner.Body" ) ) end
		if ( m == "models/hunter.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "MiniStrider.body_joint" ) ) end
		if ( m == "models/combine_turrets/floor_turret.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Barrel" ) ) end
		if ( m == "models/dog.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Dog_Model.Eye" ) ) end
		if ( m == "models/vortigaunt.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
		if ( m == "models/antlion.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Antlion.Body_Bone" ) ) end
		if ( m == "models/antlion_guard.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Antlion_Guard.Body" ) ) end
		if ( m == "models/antlion_worker.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Antlion.Head_Bone" ) ) end
		if ( m == "models/zombie/fast_torso.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
		if ( m == "models/zombie/fast.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_BodyCube" ) ) end
		if ( m == "models/headcrabclassic.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
		if ( m == "models/headcrabblack.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "HCBlack.body" ) ) end
		if ( m == "models/headcrab.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "HCFast.body" ) ) end
		if ( m == "models/zombie/poison.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Headcrab_Cube1" ) ) end
		if ( m == "models/zombie/classic.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
		if ( m == "models/zombie/classic_torso.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
		if ( m == "models/zombie/zombie_soldier.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.HC_Body_Bone" ) ) end
		if ( m == "models/combine_strider.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Combine_Strider.Body_Bone" ) ) end
		if ( m == "models/combine_dropship.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "D_ship.Spine1" ) ) end
		if ( m == "models/combine_helicopter.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Chopper.Body" ) ) end
		if ( m == "models/gunship.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Gunship.Body" ) ) end
		if ( m == "models/lamarr.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "HeadcrabClassic.SpineControl" ) ) end
		if ( m == "models/mortarsynth.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Root Bone" ) ) end
		if ( m == "models/synth.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "Bip02 Spine1" ) ) end
		if ( m == "mmodels/vortigaunt_slave.mdl" ) then modelfix = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Head" ) ) end
		//huge model list with offset fix by fr1kin
		
		targpos = modelfix + Vector(0,0,GetConVarNumber("Duck_aim_plus")/3)
		targpos = targpos + (ent:GetVelocity() / GetConVarNumber("Duck_aim_comp") - LocalPlayer():GetVelocity() / GetConVarNumber("Duck_aim_comp")) 
		targpos = (targpos - LocalPlayer():EyePos()):Angle()
				
		if Aim == true then
			
			if GetConVarNumber("duck_aim_auto") == 1 && GetConVarNumber("duck_aim_360") != 1 then
				UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)		
			end
			
			if GetConVarNumber("duck_sys_nospread_aim") == 1 then
				aimat = hack.CompensateWeaponSpread(UCMD, Vector(-cone, -cone, -cone), targpos:Forward()):Angle()
				aimat.p = math.NormalizeAngle(aimat.p)
				aimat.y = math.NormalizeAngle(aimat.y)
			else
				aimat = targpos
			end
						
			if GetConVarNumber("duck_aim_slow") == 1 then
				aimat =  LerpAngle(RealFrameTime()/GetConVarNumber("duck_aim_slow_speed")*2, LocalPlayer():EyeAngles(), aimat)
				aimat.r = 0
			end
			
			UCMD:SetViewAngles(aimat)
		end
	end
end	
	
local function viewfix(angle)
	if ent != 0 && Aim == true then
		local viewpos = {} 
		if GetConVarNumber("duck_aim_slow") == 1 then
			viewpos.angles = LocalPlayer():EyeAngles()//cant think of anything to fix it
		else
			viewpos.angles = targpos		
		end
		return viewpos
	end
end
	
	concommand.Add("+duck_aimbot", function()
	Aim = true
	hook.Add("CalcView", "Twich", viewfix) 	
    hook.Add("CreateMove", "Aim", Aimbot)
	local wep = LocalPlayer():GetActiveWeapon()
	if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 0 end
	end)
	 
	concommand.Add("-duck_aimbot", function() 
	Aim = false
	hook.Remove("CalcView", "Twich") 	
	hook.Remove("CreateMove", "Aim")
	local wep = LocalPlayer():GetActiveWeapon()
	if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 1 end
	end)
	
local trigger
local function Trigger(UCMD)
 
	if GetConVarNumber("duck_trigger") == 1 && trigger == true then
		
 
		local nospreadvec = hack.CompensateWeaponSpread(UCMD, Vector(cone, cone, cone), UCMD:GetViewAngles():Forward()):Angle()
		local tracedata = {}
		tracedata.start = LocalPlayer():GetShootPos()
		tracedata.endpos = tracedata.start + (nospreadvec:Forward() * 8192 ) 
		tracedata.filter = LocalPlayer()
		tracedata.mask = MASK_SHOT
		local trace = util.TraceLine(tracedata)
		
		if trace.Hit && trace.HitNonWorld then
			local hit = trace.Entity
			if AimFilter(hit)  then
				if GetConVarNumber("duck_trigger_head") == 1 && trace.HitGroup == 1 then		  
					UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)	
				elseif GetConVarNumber("duck_trigger_head") == 0 then
					UCMD:SetButtons(UCMD:GetButtons() | IN_ATTACK)	
				end
			end
		end
	end
end

concommand.Add("+duck_trigger", function() trigger = true
local wep = LocalPlayer():GetActiveWeapon()
--if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 0 end
end)
concommand.Add("-duck_trigger", function() trigger = false 
local wep = LocalPlayer():GetActiveWeapon()
--if wep && wep.Primary && wep.Primary.Recoil then wep.Primary.Recoil = 1 end
end)

hook.Add("CreateMove", "Trigger", Trigger)

local fakeview = false
local propthrown = false
local modang = Angle( 0, 0, 0 )
local realang = Angle( 0, 0, 0 )



function propkill( ucmd )
	if !fakeview and propthrown then		
		propthrown = false
		ucmd:SetViewAngles(modang)
	elseif !fakeview then
		local realang = ucmd:GetViewAngles()
		modang = realang
	else	
		local realang = ucmd:GetViewAngles()
		modang = realang
		modang.y = realang.y - 180
		local move = Vector( ucmd:GetForwardMove(), ucmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( modang - realang ) ):Forward() * move:Length()
		ucmd:SetForwardMove( -set.x )
		ucmd:SetSideMove( -set.y )
	end
end

function decalcview( ucmd, origin, angles )
	local ply = LocalPlayer()
	if fakeview then
		return{
			origin = origin,
			angles = modang 
		}
	else
		return
	end
end

	hook.Add("CalcView", "tttc", decalcview) 
	hook.Add("CreateMove", "tttcm", propkill)
	concommand.Add("+duck_prop", function()
	fakeview = true

		end)
	 
	concommand.Add("-duck_prop", function() 
	fakeview = false
	propthrown = true
	end)


local function WallFilter(ent)
	if !ent:IsValid() || (!ent:IsNPC() && !ent:IsPlayer()) || ent == LocalPlayer() then return false end
	
	if ent:IsPlayer() then 
	if !ent:Alive() || ent:Health() < 1 then return false end
	if ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_wallhack_team") == 1 then return false end 
	if ent:GetModel() == "models/player.mdl" then return false end  
	end
	
	if ent:IsNPC() then
	if ent:GetMoveType() == 0 then return false end 
	end
	return true
end	

local function ESPFilter(ent)
if !ent:IsValid() || !ent:IsPlayer() || ent == LocalPlayer() then return false end
	if ent:IsPlayer() then --double check lol
		if !ent:Alive() || ent:Health() < 1 then return false end
		if ent:Team() == LocalPlayer():Team() && GetConVarNumber("duck_esp_team") == 1 then return false end
		if ent:GetModel() == "models/player.mdl" then return false end  
	end
return true
end

function surface.DrawPolyEasy( textureid, color, ... )--by noPE	
	local vertextable = {{}, {}, {}, {}, {}}
	
	for num, data in pairs( { ... } ) do
		vertextable[num]['x'] = data[1]
		vertextable[num]['y'] = data[2]
		vertextable[num]['u'] = data[3]
		vertextable[num]['v'] = data[4]
	end
	
	surface.SetTexture( textureid )
	surface.SetDrawColor( color )
	surface.DrawPoly( vertextable )
end

local Tags = {}

local skeleton = {
	{"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Spine4"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2"},
	{"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm"},
	{"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm"},
	{"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},
	{"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},
	{"ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand"},
	{"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand"},
	{"ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis"},
	{"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh"},
	{"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh"},
	{"ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf"},
	{"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf"},
	{"ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot"},
	{"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot"},
	{"ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0"},
	{"ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0"},
	}--this is from hades + messed around a bit

local Fonts = {
 "TabLarge",
 "Default",
 "DefaultFixedOutline",
 "DefaultSmallDropShadow",
 "TargetID",
 "CloseCaption_BoldItalic",
}
local font = Fonts[GetConVarNumber("duck_esp_font")]


local function ESP()
	for k,ent in pairs(ents.GetAll()) do
		if ent:IsPlayer() && ESPFilter(ent) && FOVRestrict(ent,0.80) then
			
			local pos = head(ent)
			pos = pos:ToScreen()
			local tc = team.GetColor(ent:Team())
			local hp = math.Clamp(ent:Health(),0,100)
			local hpcol = math.Clamp(ent:Health(), 0, 100) / 100
			hpcol = hpcol * 120
			hpcol = math.Clamp(hpcol, 0, 120) // 120 is green
			hpcol = HSVToColor(hpcol, 1, 1)
			local skeletoncol = color_white
			local wep
			if ent.GetActiveWeapon then
				wep = ent:GetActiveWeapon()
			else
				wep = nil
			end
			wepcol = color_white		
			vs = color_white
			if visible(ent) then vs = Color( 0, 255, 0, 255 ) else vs = Color( 255, 0, 0, 255 ) end
			
			if GetConVarNumber("duck_esp") == 1 then
				draw.SimpleText(ent:GetName(), font, pos.x-20, pos.y-10, tc)
				if IsAdmin(ent) then
					draw.SimpleText("Admin", font, pos.x-40, pos.y-3, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
				
			if GetConVarNumber("duck_esp_phealth") == 1 then
				if GetConVarNumber("duck_esp_phtype") == 1 then
					surface.DrawPolyEasy(surface.GetTextureID("vgui/white"),Color(50,50,50,255 ),
					{pos.x-10,pos.y-20,1,0},{pos.x+30,pos.y-10,0,1},{pos.x-22,pos.y-10,1,0},{pos.x+40,pos.y-20,0,1},{pos.x+30,pos.y-10,0,1})
					surface.DrawPolyEasy(surface.GetTextureID("vgui/white"),Color(hpcol.r,hpcol.g,hpcol.b,255 ),
					{pos.x-10,pos.y-19,1,0},{pos.x+hp/2-19,pos.y-11,0,1},{pos.x-20,pos.y-11,1,0},{pos.x+hp/2-12,pos.y-19,0,1},{pos.x+hp/2-20,pos.y-11,0,1})
				elseif GetConVarNumber("duck_esp_phtype") == 2 then
						surface.SetDrawColor(50,50,50,255)
						surface.DrawRect(pos.x-20,pos.y-20,50,10)
						surface.SetDrawColor(hpcol)
						surface.DrawRect(pos.x-20,pos.y-20,hp/2,10)
				elseif GetConVarNumber("duck_esp_phtype") == 3 then
						surface.SetDrawColor(50,50,50,255)
						surface.DrawRect(pos.x-22,pos.y-22,54,14)
						surface.SetDrawColor(hpcol)
						surface.DrawRect(pos.x-20,pos.y-20,hp/2,10)
				end
			end
			
			if GetConVarNumber("duck_esp_pskeleton") == 1 then
				for k,v in pairs(skeleton) do
				
					local bone1 = ent:GetBonePosition(ent:LookupBone(v[1])):ToScreen()
					local bone2 = ent:GetBonePosition(ent:LookupBone(v[2])):ToScreen()
					
					if GetConVarNumber("duck_esp_pskeletoncol") == 1 then
						skeletoncol = hpcol
					elseif GetConVarNumber("duck_esp_pskeletoncol") == 2 then
						skeletoncol = tc
					elseif GetConVarNumber("duck_esp_pskeletoncol") == 3 then
						if visible(ent) then
							skeletoncol = Color(0,255,0,255)
						else
							skeletoncol = Color(255,0,0,255)
						end
					end
					surface.SetDrawColor(skeletoncol)
					surface.DrawLine(bone1.x,bone1.y,bone2.x,bone2.y)
				end
			end
			
			if GetConVarNumber("duck_esp_pweapon") == 1 then
				if ValidEntity(wep) then
					if GetConVarNumber("duck_esp_pweaponicon") == 0 then
						draw.SimpleText(wep:GetPrintName(), font, pos.x, pos.y+15, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					elseif  GetConVarNumber("duck_esp_pweaponicon") == 1 then
						
						if wep.IconLetter != nil then
							draw.SimpleText(wep.IconLetter, "CSKillIcons", pos.x, pos.y + 30, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(wep:GetPrintName(), font, pos.x, pos.y+15, wepcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end
				end
			end	
			
			if GetConVarNumber("duck_esp_pvisible") == 1 then
				if GetConVarNumber("duck_esp_pvisibletype") == 1 then
					draw.RoundedBox(6 , pos.x-4, pos.y-34, 10, 10, vs )
				elseif GetConVarNumber("duck_esp_pvisibletype") == 2 then
					surface.SetDrawColor(vs)
					surface.DrawRect(pos.x-4, pos.y-34,10,10)
				end
			end
			
			if ent:GetFriendStatus() == "friend"  then
				draw.SimpleText(ent:GetName(), font, pos.x-20, pos.y-10, Color(255,0,0,255))
			end
			
			if table.HasValue(Tags, ent:GetName()) then
				draw.SimpleText(ent:GetName(), font, pos.x-20, pos.y-10, Color(math.Rand(0,255),math.Rand(0,255),math.Rand(0,255),255))
			end
			
			if GetConVarNumber("duck_aim_draw") == 1  then //just using this hook
				if FOVRestrict(ent, GetConVarNumber("duck_aim_fov")) && visible(ent) && AimFilter(ent) then 
					local ent = Target()
					pos = head(ent)
					pos = pos:ToScreen()
					surface.SetDrawColor(255,0,0,255)
					surface.DrawLine(ScrW()/2, ScrH()/2, pos.x, pos.y)
				end
			end
			
		end
		
		local classes = {crossbow_bolt = true,--from wizbot
		npc_grenade_frag = true,
		rpg_missile = true,
		prop_combine_ball = true,
		grenade_ar2 = true}

		if GetConVarNumber("duck_esp_track") == 1 then
			if classes[ent:GetClass()] == true then
				if ent.tracking == nil then
					ent.tracking = {}
				end
				local pos = ent:GetPos()
				table.insert(ent.tracking, pos)
				for dist, pos in pairs(ent.tracking) do
					if dist > 10 then
						local pos = pos:ToScreen()
						local pos2 = ent.tracking[dist-1]:ToScreen()
						local tc = team.GetColor(ent:GetOwner():Team())
						surface.SetDrawColor(tc.r, tc.g, tc.b, 255)
						surface.DrawLine(pos.x,pos.y,pos2.x,pos2.y)
					end
				end
			end
		end
		
		
		if string.find(GAMEMODE.Name,"Trouble in Terrorist Town") then
			if GetConVarNumber("duck_esp_ttt_traitor") == 1 then
				if ent:IsWeapon() && ValidEntity(ent) then
					local Weapons = ent.CanBuy 
					local pos = ent:GetPos():ToScreen()
					local glow = (1+0.5*math.sin(RealTime()*15))*255
						
					if table.HasValue(Weapons, ROLE_TRAITOR)  then
						draw.SimpleText("Traitor", font, pos.x, pos.y, Color(glow,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end
			end
	
				if ValidEntity(ent) && ent:GetClass() == "ttt_c4"  then 
					local pos = ent:GetPos():ToScreen() 
					local glow = (1+0.5*math.sin(RealTime()*15))*255
					if GetConVarNumber("duck_esp_ttt_c4") == 1 then
						draw.SimpleText("C4 Explosion In: " .. string.FormattedTime(math.max(0, ent:GetExplodeTime() - CurTime()),"%02i:%02i"), "TabLarge", pos.x, pos.y, Color(glow,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				--	if ent:GetOwner() != LocalPlayer() && ent:GetFriendStatus() != "friend" then
						if GetConVarNumber("duck_ttt_boom") == 1 then--none
							draw.SimpleText("Exploding " .. ent:GetOwner():Nick() .. "'s C4", "TabLarge", ScrW()/2, ScrH()/2+20, Color(glow,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
							if ent:GetArmed() then
								RunConsoleCommand("ttt_c4_disarm", tostring(ent:EntIndex()), math.random(0, 5))
							end
						end
					--end
				end

			if GetConVarNumber("duck_esp_ttt_nade") == 1 then
				if (ent.Base || "") == "ttt_basegrenade_proj" then
					local size = (ent:GetExplodeTime() - CurTime()) * 15
					if size > 0 then
						local pos = ent:GetPos():ToScreen()
						surface.SetDrawColor(Color(255,0,0,200))
						surface.DrawRect(pos.x - size/2, pos.y - 10, size, 5)
					end
				end
			end
		end
	end
	//HUD Stuff
	if GetConVarNumber("duck_crosshair_cross") == 1 then
		surface.SetDrawColor(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255)
	    surface.DrawRect(ScrW()/2,ScrH()/2, 1,11)
        surface.DrawRect(ScrW()/2,ScrH()/2, 11,1) 
	    surface.DrawRect(ScrW()/2,ScrH()/2-10, 1,10)
        surface.DrawRect(ScrW()/2-10,ScrH()/2, 10,1) 
	end
	
	if GetConVarNumber("duck_crosshair_dot") == 1 then
		draw.RoundedBox(4, ScrW()/2-3,ScrH()/2-3, 7,7, Color(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255))
	end
	
	if GetConVarNumber("duck_crosshair_circle") == 1 then
		surface.SetTexture(surface.GetTextureID("vgui/white"))
		surface.DrawCircle( ScrW()/2, ScrH()/2, 10, Color(GetConVarNumber("duck_crosshair_r")*1000,GetConVarNumber("duck_crosshair_g")*1000,GetConVarNumber("duck_crosshair_b")*1000,255) ) 
	end

	if GetConVarNumber("duck_hud") == 1 then
		surface.DrawPolyEasy(surface.GetTextureID("vgui/white"),Color(50,50,50,200),
		{ScrW()/3,ScrH()/100,0,1},{ScrW()/2+170,ScrH()/100,0,1},{ScrW()/2+250,ScrH()/8,0,1},{ScrW()/2+200,ScrH()/8,0,1},{ScrW()/4,ScrH()/8,0,1})
		--FUCK
		local Mirror = {} 
		Mirror.origin =  LocalPlayer():GetShootPos()
		Mirror.angles = Angle(0, LocalPlayer():EyeAngles().y-180, 0)
		Mirror.w = 200
		Mirror.h = 60
		Mirror.x = ScrW()/2-100
		Mirror.y = ScrH()/60
		local name = ""
		local w,h = surface.GetTextSize(LocalPlayer():GetName())
		if w > 126 then
			name = string.sub(LocalPlayer():Name(), 0, 17) .. "..."
		else
			name = LocalPlayer():Name()
		end
		local trace = LocalPlayer():GetEyeTrace()
		local hitent = ""
		if trace.Hit && trace.HitNonWorld then
			hitent = trace.Entity:GetClass()
			local w2,h2 = surface.GetTextSize(hitent)
			if w2 > 126 then
				hitent = string.sub(trace.Entity:GetClass(), 0, 17) .. "..."
			else
				hitent = trace.Entity:GetClass()
			end
		end

		local fire,steam,teams = ""
		local firec,steamc,teamsc = color_white 
		
		if GetConVarNumber("duck_aim_auto") == 1 then
			fire = "ON"
			firec = Color(255,0,0,255)
		else
			fire = "OFF"
			firec = Color(0,255,0,255)
		end
		
		if GetConVarNumber("duck_aim_friends") == 1 then
			steam = "ON"
			steamc = Color(0,255,0,255)
		else
			steam = "OFF"
			steamc = Color(255,0,0,255)
		end
		
		if GetConVarNumber("duck_aim_team") == 1 then
			teams = "ON"
			teamsc = Color(0,255,0,255)
		else
			teams = "OFF"
			teamsc = Color(255,0,0,255)
		end
		
		render.RenderView(Mirror)
		draw.SimpleText("Autofire:", font, ScrW()/3, ScrH()/90, Color(255,255,255,255))
		draw.SimpleText(fire, font, ScrW()/3+15, ScrH()/35, firec)
		draw.SimpleText("Steam Friends:", font, ScrW()/4+55, ScrH()/19, Color(255,255,255,255))
		draw.SimpleText(steam, font, ScrW()/4+85, ScrH()/14, steamc)
		draw.SimpleText("Team:", font, ScrW()/4+370, ScrH()/90, Color(255,255,255,255))
		draw.SimpleText(teams, font, ScrW()/4+380, ScrH()/35, teamsc)
		draw.SimpleText("SpeedHack:", font, ScrW()/4+385, ScrH()/19, Color(255,255,255,255))
		draw.SimpleText(string.sub(GetConVarNumber("duck_speed"),0,3), font, ScrW()/4+410, ScrH()/14, Color(string.sub(GetConVarNumber("duck_speed"),0,3)*50, 255-string.sub(GetConVarNumber("duck_speed"),0,3)*20, 0, 225))
		draw.SimpleText("Name:", font, ScrW()/4+30, ScrH()/10, Color(255,255,255,255))
		draw.SimpleText(name, font, ScrW()/4+70, ScrH()/10, Color(255,255,255,255))
		draw.SimpleText("Ent:", font, ScrW()/4+200, ScrH()/10, Color(255,255,255,255))
		draw.SimpleText(hitent, font, ScrW()/4+225, ScrH()/10, Color(255,255,255,255))
		draw.SimpleText("Date: " .. os.date("%d/%m/%y-%H:%M:%S"), font, ScrW()/4+345, ScrH()/10, Color(255,255,255,255))
		
		local y = 95
		if GetConVarNumber("duck_spec") == 1 then
			surface.SetDrawColor(Color(50,50,50,200))
			surface.DrawRect(ScrW()/4, ScrH()/8, 120,16)
			draw.SimpleText("Spectating You: ", font, ScrW()/4+5, ScrH()/8, Color(255,255,255,255))
			for _,ent in pairs(player.GetAll()) do		
				if ent:GetObserverTarget() == LocalPlayer() then
					y = y + 15
					local hisname = ""
					local w3,h3 = surface.GetTextSize(ent:Name())
					if w3 > 95 then
						hisname = string.sub(ent:Name(), 0, 14) .. "..."
					else
						hisname = ent:Name()
					end
					surface.DrawRect(ScrW()/4, ScrH()/500+y, 120,15)
					draw.SimpleText(hisname, font, ScrW()/4+5, ScrH()/500+y, Color(255,255,255,255))
				end
			end
		end	
	end
end
hook.Add("HUDPaint", "ESP", ESP)
	
local function Chams()
	hook.Add("RenderScreenspaceEffects", "Chams", function()

		if GetConVarNumber("Duck_Wallhack_Material") == 1 then
			ChamMaterial = ""

		elseif GetConVarNumber("Duck_Wallhack_Material") == 2 then
			ChamMaterial = "models/debug/debugwhite"

		elseif GetConVarNumber("Duck_Wallhack_Material") == 3 then
			ChamMaterial = "debug/debugportals"

		elseif GetConVarNumber("Duck_Wallhack_Material") == 4 then
			ChamMaterial = "hlmv/debugmrmwireframe"

		elseif GetConVarNumber("Duck_Wallhack_Material") == 5 then
			ChamMaterial = "effects/flashlight/tech"

		end

		if GetConVarNumber("Duck_Wallhack_Outline_Material") == 1 then
			OutlineMaterial = "debug/debugportals"

		elseif GetConVarNumber("Duck_Wallhack_Outline_Material") == 2 then
			OutlineMaterial = "hlmv/debugmrmwireframe"

		end
		
		for _, ent in pairs(ents.GetAll()) do		
			if WallToggle then
				if ent:IsNPC() then
					col = Color(1,1,1,255)	    
					ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    		

				elseif ent:IsPlayer() then

					local tcol = team.GetColor(ent:Team()) 

					if GetConVarNumber("Duck_Wallhack_C_Style") == 1 then//user defined
						col = Color(GetConVarNumber("Duck_Wallhack_Red"), GetConVarNumber("Duck_Wallhack_Green"), GetConVarNumber("Duck_Wallhack_Blue"),255)	

					elseif GetConVarNumber("Duck_Wallhack_C_Style") == 2 then//team	 
						col =  Color(tcol.r/255,tcol.g/255,tcol.b/255,255)	           				

					elseif GetConVarNumber("Duck_Wallhack_C_Style") == 3 then//health	          				
						col =  Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)  	           				

					elseif GetConVarNumber("Duck_Wallhack_C_Style") == 4 then//chameleon
						col = Color(0, 1, 0,255)
					end
						
					if GetConVarNumber("Duck_Wallhack_OC_Style") == 1 then//user defined
						ocol = Color(GetConVarNumber("Duck_Wallhack_Outline_Red"), GetConVarNumber("Duck_Wallhack_Outline_Green"), GetConVarNumber("Duck_Wallhack_Outline_Blue"),255)    

					elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 2 then//team
						ocol = Color(tcol.r/255,tcol.g/255,tcol.b/255,255)	               				

					elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 3 then//health		 
						ocol = Color( 1 - ( ent:Health() / 100 ), ( ent:Health() / 100 ), 0 ,255)  		 

					elseif GetConVarNumber("Duck_Wallhack_OC_Style") == 4 then//chameleon
						ocol = Color(1, 0, 0,255)
					end

					if ent:GetFriendStatus() == "friend" then
						col = Color(math.random(0,1),math.random(0,1),math.random(0,1),255)
						ocol = Color(math.random(0,1),math.random(0,1),math.random(0,1),255)
					end
						
				end

				cam.Start3D(EyePos(),EyeAngles())	
				if WallFilter(ent) then
					cam.IgnoreZ(true)

					render.SetColorModulation(ocol.r,ocol.g,ocol.b)	           
					render.SetBlend(GetConVarNumber("duck_wallhack_outline_alpha"))	           
					ent:SetModelScale(Vector(1.02,1.1,1.01))

					ent:SetMaterial(OutlineMaterial)

					ent:DrawModel()


					if GetConVarNumber("Duck_Wallhack_OC_Style") == 4 || GetConVarNumber("Duck_Wallhack_C_Style") == 4 then
						cam.IgnoreZ(false)
					end

					render.SetColorModulation(col.r,col.g,col.b)
					render.SetBlend(GetConVarNumber("duck_wallhack_alpha"))	   
					ent:SetModelScale(Vector(1,1,1))
					ent:SetMaterial(ChamMaterial)
					ent:DrawModel()

					cam.IgnoreZ(false)
				end
				cam.End3D()
			end
		end
	end)
end
	
	
concommand.Add("Duck_Wallhack_Toggle", function()
    if WallToggle then

   hook.Remove( "RenderScreenspaceEffects", "Chams")
   
	WallToggle = false
    LocalPlayer():ChatPrint("Chams OFF")
	 
	 for _, ent in pairs(ents.GetAll()) do		
	 if WallFilter(ent) then
	 ent:SetMaterial("")
	 end
	 end
	
	elseif !WallToggle then	
    LocalPlayer():ChatPrint("Chams ON")
	Chams()
	WallToggle = true		
    end

	end)


	
	if !ConVarExists("duck_cheats") && !ConVarExists("duck_host_timescale") then
	RunConsoleCommand("aah_renamevar", "sv_cheats", "duck_cheats", 0)
	RunConsoleCommand("aah_renamevar", "host_timescale", "duck_host_timescale", 1)
	RunConsoleCommand("aah_renamevar", "host_framerate", "duck_host_framerate", 0)
	end
	RunConsoleCommand("duck_cheats", 1)

local function AdjustablespeedOn()
RunConsoleCommand("duck_host_timescale", GetConVarNumber("duck_speed"))
end

local function AdjustablespeedOff()
RunConsoleCommand("duck_host_timescale", 1)
end

local function speedOn()
RunConsoleCommand("duck_host_framerate", 0.1)
end

local function speedOff()
RunConsoleCommand("duck_host_framerate", 0)
end

concommand.Add("+duck_speed", AdjustablespeedOn)
concommand.Add("-duck_speed", AdjustablespeedOff)

concommand.Add("+duck_rspeed", speedOn)
concommand.Add("-duck_rspeed", speedOff)



local function unload()
hook.Remove( "HUDPaint", "Laser")
hook.Remove("HUDPaint", "ESP")
hook.Remove("HUDPaint", "crosshair")
end

local IP = {}
hook.Add("PlayerConnect", "ips", function(name, address) 
    if !table.HasValue(IP, name .. ": " .. address) then
		table.insert(IP, name .. ": " .. address .. " at: " .. os.date())
		file.Write("ips/iplist.txt", util.TableToKeyValues(IP))
	end
end) 




























concommand.Add("duck_menu", function()
	local menuframe = vgui.Create("DFrame")
	menuframe:SetSize(500,300)
	menuframe:Center()
	local fade = 0
	local bally = 50
	local bally2, bally2col = 470, Color(0,0,0,0)
	menuframe:SetTitle("")
	menuframe.Paint = function() 
		fade = fade + 3
		if fade > 150 then fade = 150 end
		ballycol = Color((1+0.5*math.sin(RealTime()*1))*255,255,0,fade)
		bally = bally + 2
		if bally > 470 then 
		ballycol = Color(0,0,0,0)
		bally2col = Color((1+0.5*math.sin(RealTime()*1))*255,255,0,fade*2)
		bally2 = bally2 - 2 end
		if bally2 < 50 then 
		bally2 = 50 
		menuframe:SetTitle("DuckBot")
		end
		
		draw.RoundedBox(4, 2, 2, menuframe:GetWide()-3, menuframe:GetTall()-3, Color(50,50,50,fade))
		draw.RoundedBox(4, bally, 10, 5, 5, ballycol)
		draw.RoundedBox(4, bally2, 10, 5, 5, bally2col)
		
	end
	menuframe.Close = function()
		if GetConVarNumber("duck_menu_fadeout") == 1 then
			timer.Create("fadeout", 0.01, 0, function() 
				menuframe:SetKeyBoardInputEnabled()
				menuframe:SetMouseInputEnabled()
				fade = fade - 10
				if fade < 10 then 
					fade = 10
					menuframe:SetVisible(false)
				end
			end)
		else
			menuframe:SetVisible(false)
		end
	end
	menuframe:SetDraggable(true)
	menuframe:MakePopup()

	local sheet = vgui.Create("DColumnSheet", menuframe)
	sheet:SetPos(0,25)
	sheet:SetSize(495,270)

	local main = vgui.Create("DPanel")
	main:SetPos(-2,-2)
	main:SetSize(400,400)
	main.Paint = function()
		draw.RoundedBox(0, 2, 2, main:GetWide(), main:GetTall(), Color(50,50,50,255))
	end
		
	local speedtimescale = vgui.Create("DNumSlider", main)
	speedtimescale:SetSize(363, 40)
	speedtimescale:SetPos(10, 158)
	speedtimescale:SetText("SpeedHack")
	speedtimescale:SetMin(0.1)
	speedtimescale:SetMax(10)
	speedtimescale:SetConVar("duck_speed")
	speedtimescale:SetDecimals(2)
	speedtimescale:SetValue(GetConVarNumber("duck_speed"))
	speedtimescale:NoClipping(true)
	speedtimescale.Paint = function()
	draw.RoundedBox(4, 0, 35, speedtimescale:GetWide(), 5, Color(speedtimescale:GetValue()*50, 255-speedtimescale:GetValue()*20, 0, 225))
	end
	
	local load = vgui.Create("DButton", main)
	load:SetPos(10, 200)
	load:SetSize(180,68)
	load:SetText(" ")
	load.PaintOver = function()
		draw.SimpleText("Reload", "TabLarge", load:GetWide()/2, load:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	load.DoClick = function()
		include("autorun/client/DuckBot.lua")
		surface.PlaySound("/quack/duck_1.mp3")
	end
	
	local unload1 = vgui.Create("DButton", main)
	unload1:SetPos(190,200)
	unload1:SetSize(180,68)
	unload1:SetText(" ")
	unload1.PaintOver = function()
		draw.SimpleText("Unload", "TabLarge", unload1:GetWide()/2, unload1:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	unload1.DoClick = function()
		unload()
		surface.PlaySound("/quack/duck_1.mp3")
	end
	
	local image = vgui.Create("DImage", main)
	image:SetSize(150, 150)
	image:SetPos(225, 5)
	image:SetImage("VGUI/entities/DuckBotNew")
	image:NoClipping(true)
	image.PaintOver = function()
	surface.SetDrawColor(Color(255, 255, 255, 225)) 
	surface.DrawOutlinedRect(0, 0, image:GetWide(), image:GetTall())
	end
	
	local ips = vgui.Create("DComboBox", main)
	ips:SetPos(5,4)
	ips:SetSize(220,133)
	ips:SetMultiple(false)
	for k,v in pairs(IP) do
		ips:AddItem(v)
	end
	
	local ipscopy = vgui.Create("DButton", main)
	ipscopy:SetPos(5,136)
	ipscopy:SetSize(220, 20)
	ipscopy:SetText("")
	ipscopy.DoClick = function()
		if ips:GetSelected() then
			SetClipboardText(ips:GetSelectedItems()[1]:GetValue())
		end
	end
	ipscopy.PaintOver = function()
		draw.SimpleText("Copy To ClipBoard", "TabLarge", ipscopy:GetWide()/2, ipscopy:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	sheet:AddSheet("Main", main, "gui/silkicons/world")
	
	local aimbot = vgui.Create("DPanel")
	aimbot:SetPos(-2,-2)
	aimbot:SetSize(400,400)
	aimbot.Paint = function()
		draw.RoundedBox(0, 2, 2, aimbot:GetWide(), aimbot:GetTall(), Color(50,50,50,255))
	end
	
	local aim = vgui.Create("DComboBox", aimbot)
	aim:SetPos(215,150)
	aim:SetSize(160,115)
	aim:SetMultiple(false)
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() && !table.HasValue(Friends,v:Nick())  then
			aim:AddItem(v:Nick())
		end
	end
		
	local aimtext = vgui.Create("DLabel", aimbot)
	aimtext:SetPos(260, 135)
	aimtext:SetSize(100,10)
	aimtext:SetFont("TabLarge")
	aimtext:SetText("Enemies")
	aimtext:SetColor(Color(200,70,70,255))
	
	local ignore = vgui.Create("DComboBox", aimbot)
	ignore:SetPos(10,150)
	ignore:SetSize(160,115)
	ignore:SetMultiple(false)
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() && table.HasValue(Friends,v:Nick())  then
			ignore:AddItem(v:Nick())
		end
	end
	
	local ignoretext = vgui.Create("DLabel", aimbot)
	ignoretext:SetPos(65,135)
	ignoretext:SetSize(100,10)
	ignoretext:SetFont("TabLarge")
	ignoretext:SetText("Friends")
	ignoretext:SetColor(Color(30,150,40,255))
	
		local ignoreadd = vgui.Create("DSysButton", aimbot)
	ignoreadd:SetPos(170, 150)
	ignoreadd:SetSize(45, 57.5)
	ignoreadd:SetType("left") 
	ignoreadd.DoClick = function()
		if aim:GetSelected() then
			table.insert(Friends,aim:GetSelectedItems()[1]:GetValue())
			ignore:Clear()
			aim:Clear()
			for k,v in pairs(player.GetAll()) do
				if v != LocalPlayer() && table.HasValue(Friends,v:Nick()) then
					ignore:AddItem(v:Nick())
				elseif v != LocalPlayer() && !table.HasValue(Friends,v:Nick()) then
					aim:AddItem(v:Nick())
				end
			end
		end
	end
	

	local ignoreremove = vgui.Create("DSysButton", aimbot)
	ignoreremove:SetPos(170, 208)
	ignoreremove:SetSize(45, 57.5)
	ignoreremove:SetType("right") 
	ignoreremove.DoClick = function()
		for k,v in pairs(Friends) do 
			if v == ignore:GetSelectedItems()[1]:GetValue() then
				Friends[k] = nil
			end
		end
		ignore:Clear()
		aim:Clear()
		for k,v in pairs(player.GetAll()) do
			if v != LocalPlayer() && table.HasValue(Friends,v:Nick()) then
				ignore:AddItem(v:Nick())
			elseif v != LocalPlayer() && !table.HasValue(Friends,v:Nick()) then
				aim:AddItem(v:Nick())
			end
		end
	end//the fuck tables, this was hard. Thanks fr1kin
	
	local fov = vgui.Create("DNumSlider", aimbot)
	fov:SetSize(170, 40)
	fov:SetPos(10, 5)
	fov:SetText("+   FOV   -")
	fov:SetMin(-1)
	fov:SetMax(0.99)
	fov:SetConVar("duck_aim_fov")
	fov:SetDecimals(2)
	fov:SetValue(GetConVarNumber("duck_aim_fov"))
		
	local prediction = vgui.Create("DNumSlider", aimbot)
	prediction:SetSize(170, 40)
	prediction:SetPos(10, 40)
	prediction:SetDecimals(0)
	prediction:SetText("Compensation Offset")
	prediction:SetMinMax(10, 70)
	prediction:SetConVar("duck_aim_comp")
	
	local highlight = vgui.Create("DCheckBoxLabel", aimbot)
	highlight:SetPos(10, 120)
	highlight:SetText("Line To Target")
	highlight:SetConVar("duck_aim_draw")
	highlight:SetValue(GetConVarNumber("duck_aim_draw"))
	highlight:SizeToContents()
		
	local autofire = vgui.Create("DCheckBoxLabel", aimbot)
	autofire:SetPos(10, 100)
	autofire:SetText("Auto Fire")
	autofire:SetConVar("duck_aim_auto")
	autofire:SetValue(GetConVarNumber("duck_aim_auto"))
	autofire:SizeToContents()
	
	local steamignore = vgui.Create("DCheckBoxLabel", aimbot)
	steamignore:SetPos(110, 120)
	steamignore:SetText("Steam Friends")
	steamignore:SetConVar("duck_aim_friends")
	steamignore:SetValue(GetConVarNumber("duck_aim_friends"))
	steamignore:SizeToContents()

	local teamignore = vgui.Create("DCheckBoxLabel", aimbot)
	teamignore:SetPos(205, 120)
	teamignore:SetText("Team")
	teamignore:SetConVar("duck_aim_team")
	teamignore:SetValue(GetConVarNumber("duck_aim_team"))
	teamignore:SizeToContents()
	
	local npcignore = vgui.Create("DCheckBoxLabel", aimbot)
	npcignore:SetPos(257, 120)
	npcignore:SetText("NPCs")
	npcignore:SetConVar("duck_aim_npc")
	npcignore:SetValue(GetConVarNumber("duck_aim_npc"))
	npcignore:SizeToContents()
	
	if string.find(GAMEMODE.Name,"Trouble in Terrorist Town") then
		local ignoret = vgui.Create("DCheckBoxLabel", aimbot)
		ignoret:SetPos(307, 120)
		ignoret:SetText("Traitors")
		ignoret:SetConVar("duck_aim_ttt")
		ignoret:SetValue(GetConVarNumber("duck_aim_ttt"))
		ignoret:SizeToContents()
	end
	
	local filtertext = vgui.Create("DLabel", aimbot)
	filtertext:SetPos(110, 100)
	filtertext:SetSize(100, 10)
	filtertext:SetFont("TabLarge")
	filtertext:SetText("Do Not Aim At:")
	
	aimoffset = vgui.Create("DNumSlider", aimbot)
	aimoffset:SetSize(160, 40)
	aimoffset:SetPos(210, 80)
	aimoffset:SetDecimals(0)
	aimoffset:SetText("Aim Offset")
	aimoffset:SetMinMax(-30, 30)
	aimoffset:SetConVar("duck_aim_plus")
	
	local previewoffset = vgui.Create("DModelPanel", aimbot)
	previewoffset:SetModel(LocalPlayer():GetModel())
	previewoffset:SetPos(300,10)
	previewoffset:SetSize(70, 70)
	previewoffset:SetCamPos(Vector(50, 0, 50))
	previewoffset:SetLookAt(Vector(0, 0, 65))
	previewoffset:SetFOV(30)
	previewoffset.PaintOver = function()
		surface.SetDrawColor(Color(255, 255, 255, 225)) 
		surface.DrawOutlinedRect(0, 0, previewoffset:GetWide(), previewoffset:GetTall())
		surface.SetDrawColor(Color(255, 0, 0, 225)) 
		surface.DrawRect(30,30-GetConVarNumber("duck_aim_plus")+1,10,1)
		surface.DrawRect(35,25-GetConVarNumber("duck_aim_plus")+1,1,10)
	end
	previewoffset.LayoutEntity = function()
	end
	
	local slow = vgui.Create("DCheckBoxLabel", aimbot)
	slow:SetPos(190, 10)
	slow:SetText("Smooth Aim")
	slow:SetConVar("duck_aim_slow")
	slow:SetValue(GetConVarNumber("duck_aim_slow"))
	slow:SizeToContents()
	
	spinspeed = vgui.Create("DNumSlider", aimbot)
	spinspeed:SetSize(100, 40)
	spinspeed:SetPos(190, 30)
	spinspeed:SetDecimals(1)
	spinspeed:SetText("+ Speed -")
	spinspeed:SetMinMax(0.1, 3)
	spinspeed:SetConVar("duck_aim_slow_speed")
		
		
		
	local nospreadaim = vgui.Create("DCheckBoxLabel", aimbot)
	nospreadaim:SetPos(10, 80)
	nospreadaim:SetText("NoSpread")
	nospreadaim:SetConVar("duck_sys_nospread_aim")
	nospreadaim:SetValue(GetConVarNumber("duck_sys_nospread_aim"))
	nospreadaim:SizeToContents()
	
	sheet:AddSheet("AimBot", aimbot, "gui/silkicons/add")
	
	local misc = vgui.Create("DPanel")
	misc:SetPos(-2,-2)
	misc:SetSize(400,400)
	misc.Paint = function()
		draw.RoundedBox(0, 2, 2, misc:GetWide(), misc:GetTall(), Color(50,50,50,255))
	end
	
	local nospread = vgui.Create("DCheckBoxLabel", misc)
	nospread:SetPos(10, 10)
	nospread:SetText("No Spread")
	nospread:SetConVar("duck_sys_nospread")
	nospread:SetValue(GetConVarNumber("duck_sys_nospread"))
	nospread:SizeToContents()
	
	local nospreadtyptext = vgui.Create("DLabel", misc)
	nospreadtyptext:SetPos(100, 7)
	nospreadtyptext:SetSize(100, 20)
	nospreadtyptext:SetFont("TabLarge")
	nospreadtyptext:SetText("No Spread Type:")
	
	local nospreadtype = vgui.Create("DMultiChoice", misc)
	nospreadtype:SetPos(200, 7)
	nospreadtype:SetSize(170, 20)
	nospreadtype:SetEditable(false)
	nospreadtype:AddChoice("On Fire")
	nospreadtype:AddChoice("On Alt Fire")
	nospreadtype:AddChoice("Always")
	nospreadtype:ChooseOptionID(GetConVarNumber("duck_sys_nospread_onmethod"))
	nospreadtype.OnSelect = function(Index, Value, Data) 
		RunConsoleCommand("duck_sys_nospread_onmethod", Value)
	end
	
		
	local triggerbot = vgui.Create("DCheckBoxLabel", misc)
	triggerbot:SetPos(10, 50)
	triggerbot:SetText("Trigger Bot")
	triggerbot:SetConVar("duck_trigger")
	triggerbot:SetValue(GetConVarNumber("duck_trigger"))
	triggerbot:SizeToContents()
	
	local triggerbothead = vgui.Create("DCheckBoxLabel", misc)
	triggerbothead:SetPos(100, 50)
	triggerbothead:SetText("Trigger Bot Head Only")
	triggerbothead:SetConVar("duck_trigger_head")
	triggerbothead:SetValue(GetConVarNumber("duck_trigger_head"))
	triggerbothead:SizeToContents()
	
	local bhop = vgui.Create("DCheckBoxLabel", misc)
	bhop:SetPos(10, 90)
	bhop:SetText("Auto Jump")
	bhop:SetConVar("duck_bhop")
	bhop:SetValue(GetConVarNumber("duck_bhop"))
	bhop:SizeToContents()
	
	local zoom = vgui.Create("DCheckBoxLabel", misc)
	zoom:SetPos(100, 90)
	zoom:SetText("Zoom")
	zoom:SetConVar("duck_zoom")
	zoom:SetValue(GetConVarNumber("duck_zoom"))
	zoom:SizeToContents()
	
	local adminslist = vgui.Create("DListView", misc)
	adminslist:SetSize(215, 190)
	adminslist:SetPos(155, 70)
	adminslist:SetMultiSelect(false)
	adminslist:AddColumn("Admins") 
	adminslist:AddColumn("Status") 
	for k,v in pairs(player.GetAll()) do
		if IsAdmin(v) then
			adminslist:AddLine(v:Nick(),GetAdminType(v)) 
		end
	end
	adminslist.PaintOver = function()
		draw.RoundedBox(4, 0,0, adminslist:GetWide(), adminslist:GetTall(), Color(0,0,0,150))
	end
	
	local gamemodes = vgui.Create("DLabel", misc)
	gamemodes:SetPos(10, 110)
	gamemodes:SetSize(1000, 40)
	gamemodes:SetFont("TabLarge")
	gamemodes:SetText("GameMode: \n" .. GAMEMODE.Name)
	
		
	if string.find(GAMEMODE.Name,"Trouble in Terrorist Town") then
	local esptraitor = vgui.Create("DCheckBoxLabel", misc)
	esptraitor:SetPos(10, 150)
	esptraitor:SetText("ESP Traitors")
	esptraitor:SetConVar("duck_esp_ttt_traitor")
	esptraitor:SetValue(GetConVarNumber("duck_esp_ttt_traitor"))
	esptraitor:SizeToContents()

	local espc4 = vgui.Create("DCheckBoxLabel", misc)
	espc4:SetPos(10, 180)
	espc4:SetText("ESP C4")
	espc4:SetConVar("duck_esp_ttt_c4")
	espc4:SetValue(GetConVarNumber("duck_esp_ttt_c4"))
	espc4:SizeToContents()
	
	local c4text = vgui.Create("DCheckBoxLabel", misc)
	c4text:SetPos(10, 210)
	c4text:SetText("C4 Explode")
	c4text:SetConVar("duck_ttt_boom")
	c4text:SetValue(GetConVarNumber("duck_ttt_boom"))
	c4text:SizeToContents()
	
	
	local espnades = vgui.Create("DCheckBoxLabel", misc)
	espnades:SetPos(10, 240)
	espnades:SetText("ESP Grenades")
	espnades:SetConVar("duck_esp_ttt_nade")
	espnades:SetValue(GetConVarNumber("duck_esp_ttt_nade"))
	espnades:SizeToContents()
	else
	
	local none = vgui.Create("DLabel", misc)
	none:SetPos(10, 170)
	none:SetSize(100, 20)
	none:SetFont("TabLarge")
	none:SetText("NO EXTRAS")
	none:SetColor(Color(200,70,70,255))
	end
		
	sheet:AddSheet("Misc", misc, "gui/silkicons/brick_add")
	
	local visuals = vgui.Create("DPanel")
	visuals:SetPos(-2,-2)
	visuals:SetSize(400,400)
	visuals.Paint = function()
		draw.RoundedBox(0, 2, 2, visuals:GetWide(), visuals:GetTall(), Color(50,50,50,255))
	end	
	
	local hudtext = vgui.Create("DLabel", visuals)
	hudtext:SetPos(10,10)
	hudtext:SetSize(100,20)
	hudtext:SetFont("TabLarge")
	hudtext:SetText("HUD Elements:")
	
	local dot = vgui.Create("DCheckBoxLabel", visuals)
	dot:SetPos(10, 30)
	dot:SetText("Dot")
	dot:SetConVar("duck_crosshair_dot")
	dot:SetValue(GetConVarNumber("duck_crosshair_dot"))
	dot:SizeToContents()
	
	local cross = vgui.Create("DCheckBoxLabel", visuals)
	cross:SetPos(70, 30)
	cross:SetText("Cross")
	cross:SetConVar("duck_crosshair_cross")
	cross:SetValue(GetConVarNumber("duck_crosshair_cross"))
	cross:SizeToContents()
	
	local circle = vgui.Create("DCheckBoxLabel", visuals)
	circle:SetPos(130, 30)
	circle:SetText("Cricle")
	circle:SetConVar("duck_crosshair_circle")
	circle:SetValue(GetConVarNumber("duck_crosshair_circle"))
	circle:SizeToContents()
	
	local spec = vgui.Create("DCheckBoxLabel", visuals)
	spec:SetPos(190, 30)
	spec:SetText("Show Spectators")
	spec:SetConVar("duck_spec")
	spec:SetValue(GetConVarNumber("duck_spec"))
	spec:SizeToContents()
	
	local hud = vgui.Create("DCheckBoxLabel", visuals)
	hud:SetPos(310, 30)
	hud:SetText("HUD")
	hud:SetConVar("duck_hud")
	hud:SetValue(GetConVarNumber("duck_hud"))
	hud:SizeToContents()

	local crossred = vgui.Create("DCheckBoxLabel", visuals)
	crossred:SetPos(10, 60)
	crossred:SetText("Red")
	crossred:SetConVar("duck_crosshair_r")
	crossred:SetValue(GetConVarNumber("duck_crosshair_r"))
	crossred:SizeToContents()
	
	local crossgreen = vgui.Create("DCheckBoxLabel", visuals)
	crossgreen:SetPos(70, 60)
	crossgreen:SetText("Green")
	crossgreen:SetConVar("duck_crosshair_g")
	crossgreen:SetValue(GetConVarNumber("duck_crosshair_g"))
	crossgreen:SizeToContents()
	
	local crossblue = vgui.Create("DCheckBoxLabel", visuals)
	crossblue:SetPos(130, 60)
	crossblue:SetText("Blue")
	crossblue:SetConVar("duck_crosshair_b")
	crossblue:SetValue(GetConVarNumber("duck_crosshair_b"))
	crossblue:SizeToContents()
	
	local laserdot = vgui.Create("DCheckBoxLabel", visuals)
	laserdot:SetPos(190, 60)
	laserdot:SetText("Laser Dot")
	laserdot:SetConVar("duck_laser_dot")
	laserdot:SetValue(GetConVarNumber("duck_laser_dot"))
	laserdot:SizeToContents()
	
	local laser = vgui.Create("DCheckBoxLabel", visuals)
	laser:SetPos(280, 60)
	laser:SetText("Laser Line")
	laser:SetConVar("duck_laser")
	laser:SetValue(GetConVarNumber("duck_laser"))
	laser:SizeToContents()
	
	local misctext = vgui.Create("DLabel", visuals)
	misctext:SetPos(10,90)
	misctext:SetSize(100,20)
	misctext:SetFont("TabLarge")
	misctext:SetText("Misc:")
	
	local fb = vgui.Create("DCheckBoxLabel", visuals)
	fb:SetPos(10, 110)
	fb:SetText("Full Bright")
	fb:SetConVar("mat_fullbright")
	fb:SetValue(GetConVarNumber("mat_fullbright"))
	fb:SizeToContents()
	
	local asus = vgui.Create("DButton", visuals)
	asus:SetPos(100, 110)
	asus:SetSize(50, 20)
	asus:SetText("")
	asus.PaintOver = function()
		draw.SimpleText("Asus", "TabLarge", asus:GetWide()/2, asus:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	asus.DoClick = function()
	--RunConsoleCommand("Duck_asus_toggle")
	end
	
	local handstext = vgui.Create("DLabel", visuals)
	handstext:SetPos(160, 108)
	handstext:SetSize(100, 20)
	handstext:SetFont("TabLarge")
	handstext:SetText("Hands:")
	
	local hands = vgui.Create("DMultiChoice", visuals)
	hands:SetPos(200, 108)
	hands:SetSize(170, 20)
	hands:SetEditable(false)
	hands:AddChoice("Normal")
	hands:AddChoice("None")
	hands:AddChoice("See-Trough")
	hands:AddChoice("WireFrame")
	hands:AddChoice("WireFrame See-Trough")
	hands:ChooseOptionID(GetConVarNumber("duck_hands"))
	hands.OnSelect = function(Index, Value, Data) 
	--	RunConsoleCommand("duck_hands", Value)
		--cheat.SetHands(Value-1)
	end
	
	local esptext = vgui.Create("DLabel", visuals)
	esptext:SetPos(10,135)
	esptext:SetSize(1000,20)
	esptext:SetFont("TabLarge")
	esptext:SetText("ESP:")
	
	local espteam = vgui.Create("DCheckBoxLabel", visuals)
	espteam:SetPos(40,138)
	espteam:SetText("Team Mode")
	espteam:SetConVar("duck_esp_team")
	espteam:SetValue(GetConVarNumber("duck_esp_team"))
	espteam:SizeToContents()
	
	local esptrack = vgui.Create("DCheckBoxLabel", visuals)
	esptrack:SetPos(125,138)
	esptrack:SetText("Entity Tracker")
	esptrack:SetConVar("duck_esp_track")
	esptrack:SetValue(GetConVarNumber("duck_esp_track"))
	esptrack:SizeToContents()
	
	local espname = vgui.Create("DCheckBoxLabel", visuals)
	espname:SetPos(10, 160)
	espname:SetText("Name")
	espname:SetConVar("duck_esp")
	espname:SetValue(GetConVarNumber("duck_esp"))
	espname:SizeToContents()
	
	local espnamec = vgui.Create("DMultiChoice", visuals)
	espnamec:SetPos(80, 157)
	espnamec:SetSize(90, 20)
	espnamec:SetEditable(false)
	espnamec:AddChoice("AVP")
	espnamec:AddChoice("Simple")
	espnamec:AddChoice("Simple Outlined")
	espnamec:AddChoice("Simple Shadow")
	espnamec:AddChoice("Big")
	espnamec:AddChoice("Bold Italic")
	espnamec:ChooseOptionID(GetConVarNumber("duck_esp_font"))
	espnamec.OnSelect = function(Index, Value, Data) 
	RunConsoleCommand("duck_esp_font", Value)
	end

	
	local esphealth = vgui.Create("DCheckBoxLabel", visuals)
	esphealth:SetPos(10, 180)
	esphealth:SetText("Health")
	esphealth:SetConVar("duck_esp_phealth")
	esphealth:SetValue(GetConVarNumber("duck_esp_phealth"))
	esphealth:SizeToContents()
	
	local esphealthc = vgui.Create("DMultiChoice", visuals)
	esphealthc:SetPos(80, 177)
	esphealthc:SetSize(90, 20)
	esphealthc:SetEditable(false)
	esphealthc:AddChoice("Sharp")
	esphealthc:AddChoice("Rectangle")
	esphealthc:AddChoice("Outlined Rectangle")
	esphealthc:ChooseOptionID(GetConVarNumber("duck_esp_phtype"))
	esphealthc.OnSelect = function(Index, Value, Data) 
	RunConsoleCommand("duck_esp_phtype", Value)
	end

	local espskeleton = vgui.Create("DCheckBoxLabel", visuals)
	espskeleton:SetPos(10, 200)
	espskeleton:SetText("Skeleton")
	espskeleton:SetConVar("duck_esp_pskeleton")
	espskeleton:SetValue(GetConVarNumber("duck_esp_pskeleton"))
	espskeleton:SizeToContents()
	
	local espskeletonc = vgui.Create("DMultiChoice", visuals)
	espskeletonc:SetPos(80, 197)
	espskeletonc:SetSize(90, 20)
	espskeletonc:SetEditable(false)
	espskeletonc:AddChoice("Health")
	espskeletonc:AddChoice("Team Color")
	espskeletonc:AddChoice("Visibility")
	espskeletonc:ChooseOptionID(GetConVarNumber("duck_esp_pskeletoncol"))
	espskeletonc.OnSelect = function(Index, Value, Data) 
	RunConsoleCommand("duck_esp_pskeletoncol", Value)
	end
	
	local espweapon = vgui.Create("DCheckBoxLabel", visuals)
	espweapon:SetPos(10, 220)
	espweapon:SetText("Weapon")
	espweapon:SetConVar("duck_esp_pweapon")
	espweapon:SetValue(GetConVarNumber("duck_esp_pweapon"))
	espweapon:SizeToContents()
		
	local espweaponc = vgui.Create("DCheckBoxLabel", visuals)
	espweaponc:SetPos(80, 220)
	espweaponc:SetText("Show Icon")
	espweaponc:SetConVar("duck_esp_pweaponicon")
	espweaponc:SetValue(GetConVarNumber("duck_esp_pweaponicon"))
	espweaponc:SizeToContents()
	
	local espvisible = vgui.Create("DCheckBoxLabel", visuals)
	espvisible:SetPos(10, 240)
	espvisible:SetText("Visibility")
	espvisible:SetConVar("duck_esp_pvisible")
	espvisible:SetValue(GetConVarNumber("duck_esp_pvisible"))
	espvisible:SizeToContents()
	
	local espvisiblec = vgui.Create("DMultiChoice", visuals)
	espvisiblec:SetPos(80, 237)
	espvisiblec:SetSize(90, 20)
	espvisiblec:SetEditable(false)
	espvisiblec:AddChoice("Circle")
	espvisiblec:AddChoice("Square")
	espvisiblec:ChooseOptionID(GetConVarNumber("duck_esp_pvisibletype"))
	espvisiblec.OnSelect = function(Index, Value, Data) 
	RunConsoleCommand("duck_esp_pvisibletype", Value)
	end
	
	local taglist = vgui.Create("DListView", visuals)
	taglist:SetSize(190, 105)
	taglist:SetPos(180, 157)
	taglist:SetMultiSelect(false)
	taglist:AddColumn("Player") 
	taglist:AddColumn("Taged") 
	taglist.PaintOver = function()
		draw.RoundedBox(4, 0,0, taglist:GetWide(), taglist:GetTall(), Color(0,0,0,150))
	end
	local tagged 
	
	for k,v in pairs(player.GetAll()) do
		if table.HasValue(Tags, v:Nick()) then
			tagged = "True"
		else
			tagged = "False"
		end
		if v != LocalPlayer() then 
			taglist:AddLine(v:Nick(), tagged) 
		end
	end
	
	taglist.DoDoubleClick = function(parent, index, list)
		local taglistOptions = DermaMenu()
		
		taglistOptions:AddOption("Tag", function()
			table.insert(Tags, list:GetValue(1)) 
			taglist:Clear()
			for k,v in pairs(player.GetAll()) do
				if table.HasValue(Tags, v:Nick()) then
					tagged = "True"
				else
					tagged = "False"
				end
				if v != LocalPlayer() then 
					taglist:AddLine(v:Nick(), tagged) 
				end
			end
		end)
		
		taglistOptions:AddOption("UnTag", function()
			for k,v in pairs(Tags) do 
				if v == list:GetValue(1) then
					Tags[k] = nil
				end
			end
			taglist:Clear()
			for k,v in pairs(player.GetAll()) do
				if table.HasValue(Tags, v:Nick()) then
					tagged = "True"
				else
					tagged = "False"
				end
				if v != LocalPlayer() then 
					taglist:AddLine(v:Nick(), tagged) 
				end
			end
		end)
		
		taglistOptions:Open()
	end
	
	sheet:AddSheet("Visuals", visuals, "gui/silkicons/palette")
	
	local wallhack = vgui.Create("DPanel")
	wallhack:SetPos(-2,-2)
	wallhack:SetSize(400,400)
	wallhack.Paint = function()
		draw.RoundedBox(0, 2, 2, wallhack:GetWide(), wallhack:GetTall(), Color(50,50,50,255))
	end	
	
	local togglewallhack = vgui.Create("DButton", wallhack)
	togglewallhack:SetPos(10, 240)
	togglewallhack:SetSize(360, 20)
	togglewallhack:SetText("")
	togglewallhack.PaintOver = function()
		draw.SimpleText("Toggle Wallhack", "TabLarge", togglewallhack:GetWide()/2, togglewallhack:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	togglewallhack.DoClick = function()
		RunConsoleCommand("Duck_Wallhack_Toggle")
	end
	
	local intext = vgui.Create("DLabel", wallhack)
	intext:SetPos(70, 30)
	intext:SetSize(1000, 20)
	intext:SetFont("TabLarge")
	intext:SetText("Inside:")

	local incol = vgui.Create("DColorCircle", wallhack)
	incol:SetSize(130, 130)
	incol:SetPos(25, 50)
	incol.PaintOver = function()
		if col1 != incol:GetRGB() then
			RunConsoleCommand("duck_wallhack_red", incol:GetRGB().r/255)		
			RunConsoleCommand("duck_wallhack_green", incol:GetRGB().g/255)		
			RunConsoleCommand("duck_wallhack_blue", incol:GetRGB().b/255)		
		end
	end
	
	local inalpha = vgui.Create("DNumSlider", wallhack)
	inalpha:SetSize(86, 40)
	inalpha:SetPos(40, 190)
	inalpha:SetText("Alpha")
	inalpha:SetMin(0)
	inalpha:SetMax(1)
	inalpha:SetConVar("duck_wallhack_alpha")
	inalpha:SetDecimals(2)
	inalpha:SetValue(GetConVarNumber("duck_wallhack_alpha"))
	inalpha:NoClipping(true)
	inalpha.Paint = function()
	draw.RoundedBox(1, 0, 35, 86, 5, Color(GetConVarNumber("Duck_Wallhack_Red")*255, GetConVarNumber("Duck_Wallhack_Green")*255, GetConVarNumber("Duck_Wallhack_Blue")*255, GetConVarNumber("Duck_Wallhack_Alpha")*255))
	end
	
	local outtext = vgui.Create("DLabel", wallhack)
	outtext:SetPos(270, 30)
	outtext:SetSize(1000, 20)
	outtext:SetFont("TabLarge")
	outtext:SetText("Outside:")
	
	local outcol = vgui.Create("DColorCircle", wallhack)
	outcol:SetSize(130, 130)
	outcol:SetPos(230, 50)
	outcol.PaintOver = function()
		if col1 != outcol:GetRGB() then
			RunConsoleCommand("duck_wallhack_outline_red", outcol:GetRGB().r/255)		
			RunConsoleCommand("duck_wallhack_outline_green", outcol:GetRGB().g/255)		
			RunConsoleCommand("duck_wallhack_outline_blue", outcol:GetRGB().b/255)		
		end
	end
	
	local outcol = vgui.Create("DNumSlider", wallhack)
	outcol:SetSize(86, 40)
	outcol:SetPos(245, 190)
	outcol:SetText("Alpha")
	outcol:SetMin(0)
	outcol:SetMax(1)
	outcol:SetConVar("duck_wallhack_outline_alpha")
	outcol:SetDecimals(2)
	outcol:SetValue(GetConVarNumber("duck_wallhack_outline_alpha"))
	outcol:NoClipping(true)
	outcol.Paint = function()
	draw.RoundedBox(1, 0, 35, 86, 5, Color(GetConVarNumber("duck_wallhack_outline_red")*255, GetConVarNumber("duck_wallhack_outline_green")*255, GetConVarNumber("duck_wallhack_outline_blue")*255, GetConVarNumber("Duck_Wallhack_outline_Alpha")*255))
	end
	
	local inmat = vgui.Create("DMultiChoice", wallhack)
	inmat:SetPos(10, 10)
	inmat:SetSize(75, 20)
	inmat:SetEditable(false)
	inmat:AddChoice("No Wall")
	inmat:AddChoice("Full")
	inmat:AddChoice("Full 2D")
	inmat:AddChoice("WireFrame")
	inmat:AddChoice("Tech")
	inmat:ChooseOptionID(GetConVarNumber("duck_wallhack_material"))
	inmat.OnSelect = function(Index, Value, Data) 
		RunConsoleCommand("duck_wallhack_material", Value)
	end
	
	local incolt = vgui.Create("DMultiChoice", wallhack)
	incolt:SetPos(85, 10)
	incolt:SetSize(75, 20)
	incolt:SetEditable(false)
	incolt:AddChoice("Self Defined")
	incolt:AddChoice("Team Color")
	incolt:AddChoice("Health")
	incolt:AddChoice("Visibility")
	incolt:ChooseOptionID(GetConVarNumber("Duck_Wallhack_C_Style"))
	incolt.OnSelect = function(Index, Value, Data) 
		RunConsoleCommand("Duck_Wallhack_C_Style", Value)
	end
	
	local outmat = vgui.Create("DMultiChoice", wallhack)
	outmat:SetPos(210, 10)
	outmat:SetSize(75, 20)
	outmat:SetEditable(false)
	outmat:AddChoice("Full")
	outmat:AddChoice("WireFrame")
	outmat:ChooseOptionID(GetConVarNumber("duck_wallhack_outline_material"))
	outmat.OnSelect = function(Index, Value, Data) 
		RunConsoleCommand("duck_wallhack_outline_material", Value)
	end
	
	local outcolt = vgui.Create("DMultiChoice", wallhack)
	outcolt:SetPos(285, 10)
	outcolt:SetSize(75, 20)
	outcolt:SetEditable(false)
	outcolt:AddChoice("Self Defined")
	outcolt:AddChoice("Team Color")
	outcolt:AddChoice("Health")
	outcolt:AddChoice("Visibility")
	outcolt:ChooseOptionID(GetConVarNumber("Duck_Wallhack_OC_Style"))
	outcolt.OnSelect = function(Index, Value, Data) 
		RunConsoleCommand("Duck_Wallhack_OC_Style", Value)
	end
	
	local teamwall = vgui.Create("DCheckBoxLabel", wallhack)
	teamwall:SetPos(170, 120)
	teamwall:SetText("Team")
	teamwall:SetConVar("duck_wallhack_team")
	teamwall:SetValue(GetConVarNumber("duck_wallhack_team"))
	teamwall:SizeToContents()
	
	sheet:AddSheet("WallHack", wallhack, "gui/silkicons/user")
	
	local spam = vgui.Create("DPanel")
	spam:SetPos(-2,-2)
	spam:SetSize(400,400)
	spam.Paint = function()
		draw.RoundedBox(0, 2, 2, spam:GetWide(), spam:GetTall(), Color(50,50,50,255))
	end	

	local model = vgui.Create("DTextEntry", spam)
	model:SetPos(10, 10)
	model:SetSize(240, 30)
	model:SetText("Insert Model Here")

	modelpreset = vgui.Create("DSysButton", spam)
	modelpreset:SetPos(250, 10) 
	modelpreset:SetSize(20, 30) 
	modelpreset:SetType("down") 
	modelpreset.DoClick = function()
		local modlepresets = DermaMenu()
		modlepresets:AddOption("Crane", function() model:SetText("models/Cranes/crane_frame.mdl") end)
		modlepresets:AddOption("Barrel", function() model:SetText("models/props_c17/oildrum001_explosive.mdl") end)
		modlepresets:AddOption("Bridge", function() model:SetText("models/props_canal/canal_bridge03a.mdl") end)
		modlepresets:Open()
	end
	
	local beginspam = vgui.Create("DButton", spam)
	beginspam:SetPos(270, 10)
	beginspam:SetSize(40, 30)
	beginspam:SetText("")
	beginspam.PaintOver = function()
		draw.SimpleText("Spam", "TabLarge", beginspam:GetWide()/2, beginspam:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	beginspam.DoClick = function()
	timer.Create("spam", GetConVarNumber("duck_spam_time"), 0, function() RunConsoleCommand("gm_spawn", model:GetValue()) end)
	end
	
	local stopspam = vgui.Create("DButton", spam)
	stopspam:SetPos(310, 10)
	stopspam:SetSize(65, 30)
	stopspam:SetText("")
	stopspam.PaintOver = function()
		draw.SimpleText("Stop Spam", "TabLarge", stopspam:GetWide()/2, stopspam:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	stopspam.DoClick = function()
	timer.Destroy("spam")
	end
	
	local spamfrequency = vgui.Create("DNumSlider", spam)
	spamfrequency:SetSize(363, 40)
	spamfrequency:SetPos(10, 40)
	spamfrequency:SetText("Frequency")
	spamfrequency:SetMin(0.01)
	spamfrequency:SetMax(3)
	spamfrequency:SetConVar("duck_spam_time")
	spamfrequency:SetDecimals(2)
	spamfrequency:SetValue(GetConVarNumber("duck_spam_time"))

	local namelist = vgui.Create("DListView", spam)
	namelist:SetSize(360, 135)
	namelist:SetPos(10, 80)
	namelist:SetMultiSelect(false)
	namelist:AddColumn("Names") 
	namelist.PaintOver = function()
		draw.RoundedBox(4, 0,0, namelist:GetWide(), namelist:GetTall(), Color(0,0,0,150))
	end
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() then
			namelist:AddLine(v:Nick())
		end
	end
	namelist.DoDoubleClick = function(parent, index, list)
		LocalCommand("name " .. list:GetValue(1) .. string.char(1))
		hook.Remove("Think", "sweep")
	end
	
	local default = vgui.Create("DButton", spam)
	default:SetPos(10, 220)
	default:SetSize(65, 30)
	default:SetText("")
	default.PaintOver = function()
		draw.SimpleText("Default", "TabLarge", default:GetWide()/2, default:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	default.DoClick = function()
		LocalCommand("name " .. "Victormeriqui")
		hook.Remove("Think", "sweep")
	end
	
	local blank = vgui.Create("DButton", spam)
	blank:SetPos(80, 220)
	blank:SetSize(65, 30)
	blank:SetText("")
	blank.PaintOver = function()
		draw.SimpleText("Blank", "TabLarge", blank:GetWide()/2, blank:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	blank.DoClick = function()
		LocalCommand("name " .. string.char(1))
		hook.Remove("Think", "sweep")					
	end
	
	local all = vgui.Create("DButton", spam)
	all:SetPos(150, 220)
	all:SetSize(65, 30)
	all:SetText("")
	all.PaintOver = function()
		draw.SimpleText("Sweep", "TabLarge", all:GetWide()/2, all:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	all.DoClick = function()	
		local nicks = {}
		for k,v in pairs (player.GetAll()) do
			if v != LocalPlayer() then
				table.insert(nicks,v:Nick())
				hook.Add("Think","sweep",function()
					LocalCommand("name " .. table.Random(nicks) .. string.char(1))
				end)
			end
		end
	end
	
	local custom = vgui.Create("DTextEntry", spam)
	custom:SetPos(220, 220)
	custom:SetSize(90, 30)
	custom:SetText("Fill Me")
		
	local customset = vgui.Create("DButton", spam)
	customset:SetPos(310, 220)
	customset:SetSize(60, 30)
	customset:SetText("")
	customset.PaintOver = function()
		draw.SimpleText("Set", "TabLarge", customset:GetWide()/2, customset:GetTall()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	customset.DoClick = function()
		LocalCommand("name " .. custom:GetValue())
		hook.Remove("Think", "sweep")		
	end
	
	sheet:AddSheet("Spammer", spam, "gui/silkicons/exclamation")

	
end)
print("DuckBot Loaded")
// fr1kin was here lol my hake is almost 4000 lines long its crazylol

