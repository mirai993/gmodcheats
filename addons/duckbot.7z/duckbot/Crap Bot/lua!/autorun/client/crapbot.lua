local cb = {}
cb.Hooks = {}
cb.Commands = {}
cb.Info = {}
cb.Timers = {}
require("cvarforcer")--not gonna bother checking if its loaded
--ColorPrint(Color(255, 0, 0, 255), "--CRAPBOT-- POWERED BY MY ANUS \n")

local CreateClientConVar = CreateClientConVar

cb.RandomString = function(lenght)
	local rs = ""	
	for i = 1, lenght do
		rs = string.lower(rs .. string.char(math.random(65, 90)))
	end
	return rs
end

cb.AddHook = function(name, func)
	local randomstring = cb.RandomString(math.random(10,15))
	cb.Hooks[randomstring] = name
	hook.Add(name, randomstring, func)
	ColorPrint(Color(0, 255, 255, 255), "[Added]")
	ColorPrint(Color(0, 0, 255, 255), " Hook ")
	ColorPrint(Color(255, 255, 255, 255), name .. " with the name: " .. randomstring .. "\n")
end

cb.RemoveHooks = function()
	for k, v in pairs(cb.Hooks) do
		ColorPrint(Color(255, 255, 0, 255), "[Removed]")
		ColorPrint(Color(0, 0, 255, 255), " Hook ")
		ColorPrint(Color(255, 255, 255, 255), v .. " with the name: " .. k .. "\n")
		hook.Remove(v, k) 
		cb.Hooks[k] = nil
	end
end

cb.MakeOption = function(name, val, sec, info, panel, mouseover, mouseovert)
	CreateClientConVar("cb_" .. sec .. "_" .. name, val, true, false)
	cb.Info[name] = {
	name = name,
	defval = val,
	section = sec,
	desc = info,
	panel = pn,
	mo = mouseover,
	mot = mouseovert
	}
	--PrintTable(cb.Info)
end

cb.GetOption = function(name, val)
	if GetConVarNumber("cb_" .. name) == val then
		return true
	else
		return false
	end
end
	
cb.AddCommand = function(name, sec, func, desc)
	concommand.Add("cb_" .. sec .. "_" .. name, func)
	cb.Commands[name] =  {
	desc,
	sec,
	func
	}
	ColorPrint(Color(0, 255, 255, 255), "[Added]")
	ColorPrint(Color(0, 255, 0, 255), " Command ")
	ColorPrint(Color(255, 255, 255, 255),name .. " with the description: " .. desc ..  "\n")
	--PrintTable(cb.Commands)
end

cb.RemoveCommands = function()
	for k,v in pairs(cb.Commands) do
		concommand.Remove("cb_" .. v[2] .. "_" .. k)
		ColorPrint(Color(255, 255, 0, 255), "[Removed]")
		ColorPrint(Color(0, 255, 0, 255), " Command ")
		ColorPrint(Color(255, 255, 255, 255),"cb_" .. v[2] .. "_" .. k .. "\n")
	end
end

cb.MakeTimer = function(delay, rep, func)
	local randomstring = cb.RandomString(math.random(10,15))
	cb.Timers[randomstring] = delay
	timer.Create(randomstring, delay, rep, func)
	ColorPrint(Color(0, 255, 255, 255), "[Added]")
	ColorPrint(Color(255, 0, 255, 255), " Timer ")
	ColorPrint(Color(255, 255, 255, 255), randomstring .. " with the delay: " .. delay .. "\n")
end

cb.RemoveTimers = function()
	for k,v in pairs(cb.Timers) do
		timer.Remove(k)
		ColorPrint(Color(255, 255, 0, 255), "[Removed]")
		ColorPrint(Color(255, 0, 255, 255), " Timer ")
		ColorPrint(Color(255, 255, 255, 255), k .. " with the delay: " .. v .. "\n")
	end
end


cb.Reload = function()
	cb.RemoveHooks()
	cb.RemoveCommands()
	cb.RemoveTimers()
	include("autorun/client/crapbot.lua")
end
cb.AddCommand("Reload", "General", cb.Reload, "Reload the bot!")

cb.MakeOption("team", 1, "General", "Ignore team mates", "DCheckBox", false, "")
cb.MakeOption("steam", 1, "General", "Ignore Steam friends", "DCheckBox", false, "")

cb.Filter = function(ent)
	if ValidEntity(ent) == false then return end
	if ent == LocalPlayer() then return end
	if ent:IsNPC() then return end
	if ent:Health() < 1 then return end
	if cb.GetOption("General_team", 1) && ent:Team() == LocalPlayer():Team() then return end 
	if cb.GetOption("General_steam", 1) && ent:GetFriendStatus() == "friend" then return end 
	if ent:GetModel() == "models/player.mdl" then return end--players who join and are waiting for another round dont have health
	
	return true
end




cb.MakeOption("names", 1, "Visuals", "Show names above players heads", "DCheckBox", false, "")
cb.HUDPaint = function()
	if cb.GetOption("Visuals_names", 1) then
		local e = player.GetAll()
		for i = 1, #e do
			local ent = e[i]
			if cb.Filter(ent) then
				local tc = team.GetColor(ent:Team())
				
				local pos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
				pos = pos:ToScreen()
				draw.SimpleText(ent:GetName(), "TabLarge", pos.x, pos.y, tc)		
			end
		end
	end
end
cb.AddHook("HUDPaint", cb.HUDPaint)

cb.MakeOption("walls", 1, "Visuals", "Render players through walls", "DCheckbox", true, "cb_Visuals_Wallst to toggle!")

local togglew = true
cb.ToggleWalls = function()
	if togglew == true then
		RunConsoleCommand("cb_Visuals_walls", "1")
	else
		RunConsoleCommand("cb_Visuals_walls", "0")
	end
	togglew = !togglew
end

cb.AddCommand("Wallst", "Visuals", cb.ToggleWalls, "Toggle Wallhack")--fps heavy so decided to add a command

cb.Render = function()
	if cb.GetOption("Visuals_walls", 1) then
		cam.Start3D(EyePos(),EyeAngles())	
		SetMaterialOverride(Material("models/debug/debugwhite"))
			
		local e = player.GetAll()
		for i = 1, #e do
			local ent = e[i]
			local hc = Color(1-(ent:Health()/100), ent:Health()/100, 0, 255)
			if cb.Filter(ent) then
				cam.IgnoreZ(true)
				render.SetColorModulation(hc.r,hc.g,hc.b)	    
				ent:DrawModel()
				cam.IgnoreZ(false)
			end
		end
		
		render.SetColorModulation(1,1,1)
		SetMaterialOverride(0)
		cam.End3D()
	end
end
cb.AddHook("RenderScreenspaceEffects", cb.Render)


cb.MakeOption("bhop", 1, "Misc", "Auto Jump", "DCheckbox", false, "")
cb.MakeOption("tb", 1, "Misc", "Trigger Bot", "DCheckbox", false, "")
cb.CreateMove = function(cmd)
	if cb.GetOption("Misc_bhop", 1) then
		if cmd:GetButtons() & IN_JUMP > 0 && LocalPlayer():GetMoveType() == MOVETYPE_WALK then
			if LocalPlayer():IsOnGround() then
				cmd:SetButtons(cmd:GetButtons() | IN_JUMP)
			else
				cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
			end
		end
	end
	if cb.GetOption("Misc_tb", 1) then
		
	end
end

cb.AddHook("CreateMove", cb.CreateMove)

local mainframe
cb.MenuOpen = function()
	mainframe = vgui.Create("DFrame")
	mainframe:SetSize(300,400)
	mainframe:SetPos(200,200)
	mainframe:ShowCloseButton(true)
	mainframe:SetDraggable(true)
	mainframe:SetSizable(false)
	mainframe:SetTitle("--CRAPBOT-- POWERED BY MY ANUS")
	mainframe.Paint = function()
		draw.RoundedBox(4, 2, 2, mainframe:GetWide()-3, mainframe:GetTall()-3, Color(100,100,100,155))
	end
	mainframe:MakePopup()
	
	local sheet = vgui.Create("DColumnSheet", mainframe)
	sheet:SetPos(-5,25)
	sheet:SetSize(300,370)
	
	local general = vgui.Create("DPanel")
	general:SetPos(-2, -2)
	general:SetSize(182,372)
	general.Paint = function()
		surface.SetDrawColor(Color(50,50,50,255))
		surface.DrawRect(2, 2, general:GetWide(), general:GetTall())
	end
	
	sheet:AddSheet("Main", general, "gui/silkicons/world")
end

cb.MenuClose = function()
	mainframe:Remove()
end


concommand.Add("+cb_menu", cb.MenuOpen)--Only command that wont get added to the table because we will do everthing in the menu
concommand.Add("-cb_menu", cb.MenuClose)

