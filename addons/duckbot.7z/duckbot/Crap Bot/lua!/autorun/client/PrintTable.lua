local type = type;
local tostring = tostring;
local Msg = Msg;
local slen = string.len;
local srep = string.rep;
local tCount = table.Count;
local dgetinfo =  debug.getinfo;
local fExists = file.Exists;
local sExplode = string.Explode;
local fRead = file.Read;



function PrintTable (t, printfuncs, maxrepeats, indent, done)
	if(type(t) != "table") then
		Msg("Not a table!");
		t = {t};
	end
	done = done or {};
	indent = indent or 1;
	maxrepeats = maxrepeats or 500;
	if(indent == 1) then
		Msg(tostring(t).."["..tCount(t).."]:\n");
	end
	for key, value in pairs (t) do
		Msg(srep ("\t", indent));
		local ty = type(value);
		local skey = tostring(key);
		local sval = tostring(value);
		if(ty== "table") and (done[value] == nil) then
			done[value] = true;
			if(value == t) then
				Msg (skey.."\t=\t\t[table contains self]");
			else
				Msg(skey.." = ");
				Msg (sval.."["..tCount(value).."]:\n");
				if(maxrepeats > 0) then
					PrintTable(value, printfuncs,maxrepeats-1, indent + 1, done);
				end
			end
		else
			Msg(skey.."\t=\t");
			if(ty == "function") then
				Msg(sval.." ");
				local inf = dgetinfo(value);
				if(inf == nil) then
					Msg("[function No debug information found!(clua?)]");
				elseif(inf.what == "C") then
					Msg("[C function]");
				elseif(inf.short_src == "LuaCmd") then
					Msg("[Con function]");
				else
					Msg("["..inf.linedefined..","..inf.lastlinedefined..",\""..inf.short_src.."\"]");
					if(printfuncs == true) then
						if(fExists(inf.short_src,true) == true) then
							local data = sExplode("\n",fRead(inf.short_src,true));
							for i = inf.linedefined,inf.lastlinedefined do
								Msg(srep("\t", indent)..data[i].."\n");
							end
						end
					end
				end
			elseif(ty == "string") then
				Msg(sval.."["..slen(value).."]");
			elseif(ty == "Vector") then
				Msg("Vector("..value.x..","..value.y..","..value.z..")");
			elseif(ty == "Angle") then
				Msg("Angle("..value.p..","..value.y..","..value.r..")");
			elseif(ty == "ConVar") then
				Msg(sval.."["..value:GetName().." : "..value:GetString());
			elseif(ty == "Panel") then
				Msg(sval.."["..value:GetClassName().."]");
			elseif(ty == "IMaterial") then
				Msg(sval.."["..value:GetName().."]");
			else
				Msg(sval);
			end
		end
		Msg("\n");
	end
end