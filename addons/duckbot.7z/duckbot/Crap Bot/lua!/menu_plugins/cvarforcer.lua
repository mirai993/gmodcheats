local forcer = nil or require("cvarforcer")

if forcer != nil then
	ColorPrint(Color(0, 255, 0, 255), "ConVar Forcer Initialized (!)\n")
	
	concommand.Add("cvarforcer_force", function(p,cmd,args)
		local cvar = args[1]
		local val = args[2]
		Force(GetConVar(cvar), val)
		ColorPrint(Color(0, 0, 255, 255), "Forced " .. cvar .. " to " .. val .. "\n")
	end)
	
	/*
	local speedused = false -- never mind, messing with sv_cheats fucks stuff up 
	
	concommand.Add("cvarforcer_cheats", function()
		if speedused then return end
		Force(GetConVar("sv_cheats"), "1")
		ColorPrint(Color(100, 100, 255, 255), "Forced sv_cheats to 1\n")
		speedused = true
	end)*/
	
	CreateClientConVar("cvarforcer_speed", "0", false, false)	
	
	concommand.Add("+cvarforcer_speed1", function()
		Force(GetConVar("sv_cheats"), "1")
		Force(GetConVar("host_timescale"), tostring(GetConVarNumber("cvarforcer_speed")))
	end)
	
	concommand.Add("-cvarforcer_speed1", function()
		Force(GetConVar("host_timescale"), "1")
	end)
	
	concommand.Add("+cvarforcer_speed2", function()
		Force(GetConVar("sv_cheats"), "1")
		Force(GetConVar("host_framerate"), "0.05")
	end)
	
	concommand.Add("-cvarforcer_speed2", function()
		Force(GetConVar("host_framerate"), "0")
	end)
	
else
	Msg("Error, ConVar Forcer module not found (Notice this is green and not red (!!!!!)\n")
end

