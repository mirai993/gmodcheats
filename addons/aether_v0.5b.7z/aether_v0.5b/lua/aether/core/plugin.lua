local aether = aether
local plugin = {}
aether.plugin = plugin

local _pl = {}
_pl.__index = _pl

function _pl:command( cmd, func, bind )

end

function plugin.register( name )
    local p = setmetatable( { Name = name }, _pl )
    p.var = {}
    p.hook = setmetatable( {}, {
        __newindex = function( tbl, k, v )
            print( "hook", k )
            --aether.hook.add( k, name .. ":" .. k, v )
        end
    } )

    print( "registered plugin", name )

    return p
end

function plugin.loaddir( dir )
    for _, f in ipairs( file.FindInLua( "aether/" .. dir .. "/*.lua" ) ) do
        include( "aether/" .. dir .. "/" .. f )
    end
end