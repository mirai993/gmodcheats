local aether = aether
aether.detour = {}
local detour = aether.detour

detour.functions = {}

function detour.func( tbl, func, new )
    local old = tbl[func]
    local newFunc = function( ... )
        --# EWW EWW EWW EWW
        --  but we have to do this, otherwise errors come from the wrong place
        local ret = { pcall( new, old, ... ) }
        if ret[1] then
            return unpack( ret, 2 )
        else
            local b, err = pcall( old, ... )

            if not b then
                error( err:gsub( "'%?'", "'" .. func .. "'" ), 2 )
            else
                error( ret[2], 0 )
            end
        end
    end

    detour.functions[newFunc] = old

    tbl[func] = newFunc

    return newFunc
end

local _modSpoof, _modReal = {}, {}

--# this is used only for detouring functions inside modules,
--  mainly for convenience

--[[#
--  Usage:
--      aether.detour.module( "hook", "Add", function( old, ... )
--          print( ... )
--          return old( ... )
--      end )
--]]

function detour.module( mod, func, new )
    _modSpoof[mod] = _modSpoof[mod] or {}

    _modSpoof[mod][func] = function( ... )
        return new( _modReal[mod][func], ... )
    end
end

--# our first detour, needed for modules

require = detour.func( _G, "require", function( old, name )
    --# require does this, yes, but we want to run our code only once
    if package.loaded[name] then return package.loaded[name] end

    local spoof = _modSpoof[name]
    local ret = old( name )

    --# some modules return a bool for this, not sure why
    --  sqlite and numpad at least
    if type( ret ) ~= "table" then return ret end

    --# _modReal holds the original module members
    _modReal[name] = {}
    for k, v in pairs( ret ) do
        _modReal[name][k] = v
    end

    if spoof then
        --# let's write our functions over them!
        for k, v in pairs( _modSpoof[name] ) do
            detour.functions[v] = ret[k]
            ret[k] = v
        end
    end

    return ret
end )
