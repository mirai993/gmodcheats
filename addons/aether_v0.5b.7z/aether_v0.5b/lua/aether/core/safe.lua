--[[#
--  This file should contain stuff to avoid detection,
--  like detours and function backups
--]]

local aether = aether
local detour = aether.detour

aether.safe = {}
local safe = aether.safe

--# first, backup important functions

aether.safe = {
    setmetatable = setmetatable;
    getmetatable = getmetatable;
    rawset = rawset;
    rawget = rawget;
    coroutine = {
        create = coroutine.create;
        resume = coroutine.resume;
    };
    debug = {
        getinfo = debug.getinfo;
        setinfo = debug.setinfo;
        getupvalue = debug.getupvalue;
        setupvalue = debug.setupvalue;
        setmetatable = debug.setmetatable;
        getmetatable = debug.getmetatable;
    };
}

--# then, safety from my own testing "anti-cheat"

--# this can be used with debug.getlocal to detect cheats
detour.func( coroutine, "create", function( old, func )
    return old( detour.functions[func] or func )
end )

detour.func( debug, "getinfo", function( old, func, what )
    local info = old( detour.functions[func] or func, what )
    info.func = func
    return info
end )

detour.func( debug, "getupvalue", function( old, func, i )
    return old( detour.functions[func] or func, i )
end )
