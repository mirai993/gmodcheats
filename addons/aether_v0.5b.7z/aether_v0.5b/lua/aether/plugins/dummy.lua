local aether = aether
local dummy = aether.plugin.register "Dummy"

dummy.var.somevar = "test"

local clr = { r = 255, g = 255, b = 255, a = 255 }
function dummy.hook.HUDPaint()
    draw.SimpleText( "Dummy says HI!", "TargetID", 10, 10, clr, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
end