print "Aether initialized"

aether = {}

--# we should do core loading manually,
--  to ensure load order

include "core/detour.lua"
include "core/safe.lua"
include "core/plugin.lua"

aether.plugin.loaddir "plugins"

--# <insert loading here>

--# to avoid getting detected
--  REMEMBER TO STORE A LOCAL REFERENCE
aether = nil
