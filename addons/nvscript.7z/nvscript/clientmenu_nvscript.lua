--[[
	autorun/client/clientmenu_nvscript.lua
	a naked 12 year old girl | (STEAM_0:1:30473979)
	===DStream===
]]

nvspanel = {}
nvspanel.NVSPanelB = nil

function nvspanel.NVSPanelA(panel)
	panel:ClearControls()
	
	panel:AddControl("Label", {Text = "Main Controls"})
	panel:AddControl("Button", {Label = "Toggle Night Vision", Command = "nv_togg"})
	panel:AddControl("Slider", {Label = "Toggle Speed (higher = faster)", Command = "nv_toggspeed", Type = "Float", Min = "0.02", Max = "1"})
	panel:AddControl("Slider", {Label = "Illumination Radius (in units)", Command = "nv_illum_area", Type = "Integer", Min = "64", Max = "1024"})
	panel:AddControl("Slider", {Label = "Illumination Brightness (1 = 100%)", Command = "nv_illum_bright", Type = "Float", Min = "0.2", Max = "1"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Alternate Illumination Method (AIM)"})
	panel:AddControl("CheckBox", {Label = "AIM Status", Description = "", Command = "nv_aim_status"})
	panel:AddControl("Slider", {Label = "AIM Range", Command = "nv_aim_range", Type = "Integer", Min = "50", Max = "300"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Illumination-Detection (ID) Controls"})
	panel:AddControl("Slider", {Label = "ID Darkness Sensivity (lower = darker)", Command = "nv_id_sens_darkness", Type = "Float", Min = "0.05", Max = "1"})
	panel:AddControl("Slider", {Label = "ID Reaction Time (in secs (higher = slower))", Command = "nv_id_reaction_time", Type = "Float", Min = "0.1", Max = "1.5"})
	panel:AddControl("CheckBox", {Label = "ID Status", Description = "", Command = "nv_id_status"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Eye Trace Illumination-Sensitive Detection (ETISD) Controls"})
	panel:AddControl("Slider", {Label = "ETISD Range (in units)", Command = "nv_etisd_sensivity_range", Type = "Integer", Min = "100", Max = "500"})
	panel:AddControl("CheckBox", {Label = "ETISD Status", Description = "", Command = "nv_etisd_status"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Illumination-Smart Intensity Balancing (ISIB) Controls"})
	panel:AddControl("Slider", {Label = "ISIB Sensivity", Command = "nv_isib_sensivity", Type = "Float", Min = "2", Max = "10"})
	panel:AddControl("CheckBox", {Label = "ISIB Status", Description = "", Command = "nv_isib_status"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Night Vision FX Controls"})
	panel:AddControl("CheckBox", {Label = "FX: Use Distortion Effect?", Description = "Use Distortion Effect?", Command = "nv_fx_distort_status"})
	panel:AddControl("CheckBox", {Label = "FX: Use Blur Effect?", Description = "Use Blur Effect?", Command = "nv_fx_blur_status"})
	panel:AddControl("CheckBox", {Label = "FX: Use Green Overlay Effect? (Recommended)", Description = "Use Green Overlay Effect?", Command = "nv_fx_colormod_status"})
	panel:AddControl("CheckBox", {Label = "FX:Use Goggle Effect?", Description = "Use Camera Effect?", Command = "nv_fx_goggle_status"})
	panel:AddControl("CheckBox", {Label = "FX: Use Goggle Overlay Effect?", Description = "Use Goggle Effect?", Command = "nv_fx_goggle_overlay_status"})
	panel:AddControl("CheckBox", {Label = "FX: Use Tonemap Effect?", Description = "Use Tonemap Effect?", Command = "nv_fx_tonemap_status"})
	panel:AddControl("CheckBox", {Label = "FX: Use Delayed Tonemap Tracing? (Recommended - YES)", Description = "FX: Use Delayed Tonemap Tracing? (Recommended - YES)", Command = "nv_fx_tonemap_delayed"})
	
	panel:AddControl("Label", {Text = "Tonemap Quality"})
	
	local Quality = vgui.Create("DMultiChoice", panel)
	Quality:SetText("Tonemap Quality")
	Quality:AddChoice("low")
	Quality:AddChoice("medium")
	Quality:AddChoice("high")
	Quality.OnSelect = function(panel, index, value, data)
		RunConsoleCommand("nv_fx_tonemap_quality", tonumber(index))
	end
	
	panel:AddItem(Quality)
	
	panel:AddControl("Slider", {Label = "FX: Blur Effect Intensity", Command = "nv_fx_blur_intensity", Type = "Float", Min = "0.2", Max = "1.75"})
	panel:AddControl("Label", {Text = ""})
	
	panel:AddControl("Label", {Text = "Miscellaneous"})
	panel:AddControl("Button", {Label = "Reset Controls", Command = "nv_reset_everything"})
end

function nvspanel.OpenMySpawnMenu()
	if(nvspanel.NVSPanelB) then
		nvspanel.NVSPanelA(nvspanel.NVSPanelB)
	end
end
hook.Add("SpawnMenuOpen", "nvspanel.OpenMySpawnMenu", nvspanel.OpenMySpawnMenu)

local function PopulateMyMenu_NVS()
	spawnmenu.AddToolMenuOption("Options", "NVScript", "Night Vision Script", "Client", "", "", nvspanel.NVSPanelA)
end
hook.Add("PopulateToolMenu", "PopulateMyMenu_NVS", PopulateMyMenu_NVS)