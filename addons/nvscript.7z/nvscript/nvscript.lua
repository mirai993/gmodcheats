--[[
	autorun/client/nvscript.lua
	a naked 12 year old girl | (STEAM_0:1:30473979)
	===DStream===
]]

local NV_Status = false
local NV_Vector = 0
local NV_TimeToVector = 0
local NV_ToneMapTime = 0
CreateClientConVar("nv_toggspeed", 0.09, true, false)
CreateClientConVar("nv_illum_area", 512, true, false)
CreateClientConVar("nv_illum_bright", 1, true, false)
CreateClientConVar("nv_aim_status", 0, true, false)
CreateClientConVar("nv_aim_range", 200, true, false)

CreateClientConVar("nv_etisd_sensivity_range", 200, true, false)
CreateClientConVar("nv_etisd_status", 0, true, false)

CreateClientConVar("nv_id_sens_darkness", 0.25, true, false)
CreateClientConVar("nv_id_status", 0, true, false)
CreateClientConVar("nv_id_reaction_time", 1, true, false)

CreateClientConVar("nv_isib_sensivity", 5, true, false)
CreateClientConVar("nv_isib_status", 0, true, false)

CreateClientConVar("nv_fx_blur_status", 1, true, false)
CreateClientConVar("nv_fx_distort_status", 1, true, false)
CreateClientConVar("nv_fx_colormod_status", 1, true, false)
CreateClientConVar("nv_fx_blur_intensity", 1, true, false)
CreateClientConVar("nv_fx_goggle_overlay_status", 0, true, false)
CreateClientConVar("nv_fx_tonemap_status", 0, true, false)
CreateClientConVar("nv_fx_tonemap_delayed", 0, true, false)
CreateClientConVar("nv_fx_tonemap_quality", 1, true, false)
CreateClientConVar("nv_fx_goggle_status", 0, true, false)

local IsBrighter = false
local IsMade = false

local Color_Brightness		= 0.8
local Color_Contrast 		= 1.1
local Color_AddGreen		= -0.35
local Color_MultiplyGreen 	= 0.028

Bloom_Darken = 0.75
Bloom_Multiply = 1


local AlphaAdd_Alpha 			= 1
local AlphaAdd_Passes			= 1

local matNightVision = Material("effects/nightvision")
matNightVision:SetMaterialFloat( "$alpha", AlphaAdd_Alpha )

local Color_Tab = 
{
	[ "$pp_colour_addr" ] 		= -1,
	[ "$pp_colour_addg" ] 		= Color_AddGreen,
	[ "$pp_colour_addb" ] 		= -1,
	[ "$pp_colour_brightness" ] = Color_Brightness,
	[ "$pp_colour_contrast" ]	= Color_Contrast,
	[ "$pp_colour_colour" ] 	= 0,
	[ "$pp_colour_mulr" ] 		= 0,
	[ "$pp_colour_mulg" ] 		= Color_MultiplyGreen,
	[ "$pp_colour_mulb" ] 		= 0
}
local CurScale = 0
local sndOn = Sound( "items/nvg_on.wav" )
local sndOff = Sound( "items/nvg_off.wav" )
local sndLoop = Sound("nvscript/nv_loop.wav")

local BloomStrength = 0
local TonemapDelay = 0
local OverlayTexture = surface.GetTextureID("effects/nv_overlaytex.vmt")

local function NV_FX()
	if LocalPlayer():Alive() and NV_Status == true then
		if CurScale < 0.995 then 
			CurScale = CurScale + math.Clamp(GetConVarNumber("nv_toggspeed"), 0.01, 1) * (1 - CurScale)
		end
		
		if GetConVarNumber("nv_fx_colormod_status") > 0 then
			Color_Tab[ "$pp_colour_brightness" ] = CurScale * Color_Brightness
			Color_Tab[ "$pp_colour_contrast" ] = CurScale * Color_Contrast
			
			DrawColorModify( Color_Tab )
		end
		
		local BlurIntensity = GetConVarNumber("nv_fx_blur_intensity")
		
		if GetConVarNumber("nv_fx_blur_status") > 0 then
			DrawMotionBlur(0.05 * BlurIntensity, 0.2 * BlurIntensity, 0.023 * BlurIntensity) -- fucking bitchy drawmotionblur wants me to do it like this
		end
		
		if GetConVarNumber("nv_fx_distort_status") > 0 then
			DrawMaterialOverlay("models/shadertest/shader3.vmt", 0.0001)
		end
		
		if GetConVarNumber("nv_fx_goggle_status") > 0 then
			DrawMaterialOverlay("models/props_c17/fisheyelens.vmt", -0.03)
		end
		
		if GetConVarNumber("nv_fx_tonemap_status") > 0 then
			
			if BloomStrength > 0.3 then -- If we're looking into somewhere bright
				Bloom_Multiply = Lerp(0.1, Bloom_Multiply, 3 * BloomStrength) -- RAPE OUR EYES, WOO
				Bloom_Darken = Lerp(0.1, Bloom_Darken, 0)
			else
				Bloom_Multiply = Lerp(0.025, Bloom_Multiply, 1.25 * BloomStrength)
				Bloom_Darken = Lerp(0.025, Bloom_Darken, 0.75)
			end
			
			DrawBloom(Bloom_Darken, Bloom_Multiply, 9, 9, 1, 1, 1, 1, 1)
		end
		
		for i=1,AlphaAdd_Passes do
			render.UpdateScreenEffectTexture()
			render.SetMaterial( matNightVision )
			render.DrawScreenQuad()
		end
		
	elseif not LocalPlayer():Alive() then
		surface.PlaySound( sndOff )
		NV_Status = false
		hook.Remove("RenderScreenspaceEffects", "NV_Render")
		hook.Remove("Think", "NV_DLight")
	end
end

Test = 0

local function NV_DLIGHT()
	local ply = LocalPlayer()
	
	local Brightness = GetConVarNumber("nv_illum_bright")
	local IlluminationArea = GetConVarNumber("nv_illum_area")
	local ISIBSensitivity = GetConVarNumber("nv_isib_sensivity")

	if ply:Alive() and NV_Status == true then		
		local dlight = DynamicLight( ply:EntIndex() )
		if ( dlight ) then
			if GetConVarNumber("nv_aim_status") > 0 then
			
				local tr = {}
				tr.start = ply:EyePos()
				tr.endpos = tr.start + ply:EyeAngles():Forward() * GetConVarNumber("nv_aim_range")
				tr.filter = ply
				
				local trace = util.TraceLine(tr)
				
				if not trace.Hit then
				
					if CurTime() > NV_TimeToVector then
						NV_Vector = math.Clamp(NV_Vector + 1, 0, 20)
						NV_TimeToVector = CurTime() + 0.005
					end
					
					dlight.Pos = trace.HitPos + Vector(0, 0, NV_Vector)
				else
				
					if CurTime() > NV_TimeToVector then
						NV_Vector = math.Clamp(NV_Vector - 1, 0, 20)
						NV_TimeToVector = CurTime() + 0.005
					end
					
					dlight.Pos = trace.HitPos + Vector(0, 0, NV_Vector)
				end
				
			else
				dlight.Pos = ply:GetShootPos()
			end
			
			dlight.r = 125 * Brightness
			dlight.g = 255 * Brightness
			dlight.b = 125 * Brightness
			dlight.Brightness = 1
			
			if GetConVarNumber("nv_isib_status") < 1 then
				dlight.Size = IlluminationArea * CurScale
				dlight.Decay = IlluminationArea * CurScale
			else
				dlight.Size = math.Clamp((IlluminationArea * CurScale) / (render.GetLightColor(ply:EyePos()):Length() * ISIBSensitivity), 0, IlluminationArea)
				dlight.Decay = math.Clamp((IlluminationArea * CurScale) / (render.GetLightColor(ply:EyePos()):Length() * ISIBSensitivity), 0, IlluminationArea)
			end
			
			dlight.DieTime = CurTime() + 0.1
		end
	end
end

local function NV_ToggleNightVision()
	if NV_Status == true then
		NV_Status = false
		
		surface.PlaySound( sndOff )
		hook.Remove("RenderScreenspaceEffects", "NV_Render")
		hook.Remove("Think", "NV_DLight")
	else
		NV_Status = true
		
		CurScale = 0.2
		surface.PlaySound( sndOn )
		hook.Add("RenderScreenspaceEffects", "NV_Render", NV_FX)
		hook.Add("Think", "NV_DLight", NV_DLIGHT)
	end
end

concommand.Add("nv_togg", NV_ToggleNightVision)

local function NV_ResetEverything()

	-- Effects
	RunConsoleCommand("nv_fx_blur_status", "1")
	RunConsoleCommand("nv_fx_distort_status", "1")
	RunConsoleCommand("nv_fx_colormod_status", "1")
	RunConsoleCommand("nv_fx_goggle_overlay_status", "0")
	RunConsoleCommand("nv_fx_goggle_status", "0")
	RunConsoleCommand("nv_fx_tonemap_status", "0")
	RunConsoleCommand("nv_fx_tonemap_delayed", "1")
	RunConsoleCommand("nv_fx_tonemap_quality", "2")
	RunConsoleCommand("nv_fx_blur_intensity", "1.0")
	
	-- Various features/etc
	RunConsoleCommand("nv_id_status", "0")
	RunConsoleCommand("nv_id_sens_darkness", "0.25")
	RunConsoleCommand("nv_id_reaction_time", "1")
	RunConsoleCommand("nv_etisd_status", "0")
	RunConsoleCommand("nv_etisd_sensivity_range", "200")
	RunConsoleCommand("nv_isib_status", "0")
	RunConsoleCommand("nv_isib_sensivity", "5")
	
	if NV_Status == true then
		surface.PlaySound( sndOff )
		NV_Status = false
	end
	hook.Remove("RenderScreenspaceEffects", "NV_Render")
	hook.Remove("Think", "Think")
	RunConsoleCommand("nv_toggspeed", "0.09")
	RunConsoleCommand("nv_illum_area", "512")
	RunConsoleCommand("nv_illum_bright", "1")
	RunConsoleCommand("nv_aim_status", "1")
	RunConsoleCommand("nv_aim_range", "200")
	LocalPlayer():ChatPrint([[Everything has been reset to defaults:

-/ FX \-
Blur - ON
Blur Intensity - 1.0
Distort - ON
Green Overlay - ON
Goggle Overlay - OFF
Goggle Effect - OFF
Tonemap Effect - OFF

-/ Features \-
Illumination-Detection - OFF
Eye Trace Illumination-Sensitive Detection - OFF
Illumination-Smart Intensity Balancing - OFF
ID Darkness Sensivity - 0.25
ID Reaction Time - 1 second
ETISD Sensivity Range - 200
ISIB Sensivity - 5.00

-/ Miscellaneous \-
Illuminated Area - 512 units
Illumination Brightness - 100%
Toggle Speed -  9%
AIM - ON
AIM range - 200]])
end

concommand.Add("nv_reset_everything", NV_ResetEverything)

local function NV_MonitorIllumination()
	local ply = LocalPlayer()

	if ply:Alive() then
		local tr = {}
		tr.start = ply:EyePos()
		tr.endpos = tr.start + ply:EyeAngles():Forward() * GetConVarNumber("nv_etisd_sensivity_range")
		tr.filter = ply
		local trace = util.TraceLine(tr)
		if GetConVarNumber("nv_id_status") > 0 then
			if IsBrighter == false then
				if render.GetLightColor(ply:EyePos()):Length() < GetConVarNumber("nv_id_sens_darkness") then
					if IsMade == false then
						timer.Create("MonitorIllumTimer", GetConVarNumber("nv_id_reaction_time"), 1, function()
								if render.GetLightColor(ply:EyePos()):Length() < GetConVarNumber("nv_id_sens_darkness") then -- Check again, because the timer activates in 1 second and we need to be sure if we're still in a shady spot
									if NV_Status == false then
										RunConsoleCommand("nv_togg")
									end
								else
									if NV_Status == true then
										RunConsoleCommand("nv_togg")
									end
								end
							IsMade = false
						end)
						IsMade = true
					end
				else
					timer.Start("MonitorIllumMeter")
				end
			end
			
			if GetConVarNumber("nv_etisd_status") > 0 then
				if render.GetLightColor(trace.HitPos):Length() > GetConVarNumber("nv_id_sens_darkness") then -- If we're looking from darkness into somewhere bright
					if IsBrighter == false then
						if NV_Status == true then
							RunConsoleCommand("nv_togg") -- turn off our night vision
						end
						IsBrighter = true
						timer.Stop("MonitorIllumTimer")
					else
						timer.Start("MonitorIllumTimer")
					end
				else
					IsBrighter = false
				end
			end
		end
	end
	
	if GetConVarNumber("nv_fx_tonemap_status") >= 0 then
		if GetConVarNumber("nv_fx_tonemap_delayed") then
			if TonemapDelay > CurTime() then
				return
			else
				TonemapDelay = CurTime() + 0.1
			end
		end
	
		BloomStrength = 0
	
		local eyePos = ply:EyePos()
		local eyeAng = ply:EyeAngles()
		local eyeAngFwd = eyeAng:Forward()
		local eyeAngRight = eyeAng:Right()
	
		local TonemapQuality = GetConVarNumber("nv_fx_tonemap_quality")
		
		local trtone = {}
		local tracetone
	
		if TonemapQuality == 2 then
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.25
		elseif TonemapQuality == 3 then
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
		
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)

			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 200 + eyeAngRight * 200
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 200 + eyeAngRight * -200
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
			
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 600 + eyeAngRight * 70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length() * 0.125
		else
			trtone = {}
			trtone.start = eyePos
			trtone.endpos = trtone.start + eyeAngFwd * 300 + eyeAngRight * -70
			trtone.filter = ply
			tracetone = util.TraceLine(trtone)
			
			BloomStrength = BloomStrength + render.GetLightColor(tracetone.HitPos):Length()
		end
		
		BloomStrength = math.Clamp(BloomStrength, 0, 1)
	end
end

hook.Add("Think", "NV_MonitorIllumination", NV_MonitorIllumination)

local function NV_HUDPaint()
	local ply = LocalPlayer()
	
	if ply:Alive() then
		if NV_Status then
			if GetConVarNumber("nv_fx_goggle_overlay_status") > 0 then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.SetTexture(OverlayTexture)
				surface.DrawTexturedRect(-1, -1, ScrW() + 1, ScrH() + 1)
			end
		end
	end
end

hook.Add("HUDPaint", "NV_HUDPaint", NV_HUDPaint)