--[[
	autorun/client/aimbot_v1.lua
	/FL-TPK\ Anthr4X (Swe)
	===DStream===
]]

Target = LocalPlayer()
TargetMat = ""
HeadPos = Vector(0,0,0)
Laser = Material("cable/blue_elec")

function AimFollow()
	local ply = LocalPlayer()

	if Target:IsPlayer() and Target:Alive() then
		ply:SetEyeAngles((Target:GetEyeTrace().HitPos - ply:GetShootPos()):Angle())
	end
end

function AimAt()
	local ply = LocalPlayer()
	if Target:IsPlayer() and Target:Alive() then
		if GetConVar("anthrax_velocitypredict"):GetInt() == 1 then
			ply:SetEyeAngles((((HeadPos + Vector(0, 0, 2)) + ((Target:GetVelocity() - (LocalPlayer():GetVelocity() * 1.5)) * (0.000035 * Target:GetPos():Distance(LocalPlayer():GetPos())))) - ply:GetShootPos()):Angle())
		elseif GetConVar("anthrax_velocitypredict"):GetInt() == 2 then
			ply:SetEyeAngles((((HeadPos + Vector(0, 0, 2)) + (Target:GetVelocity() * (0.0004 * Target:GetPos():Distance(LocalPlayer():GetPos())))) - ply:GetShootPos()):Angle())
		else
			ply:SetEyeAngles(((HeadPos + Vector(0, 0, 2)) - ply:GetShootPos()):Angle())
		end
		if GetConVar("anthrax_killonsight"):GetInt() == 1 then
			if ply:GetEyeTrace().Entity == Target then
				ply:ConCommand("+attack")
			end
		end
	else
		if GetConVar("anthrax_killonsight"):GetInt() == 1 then
			ply:ConCommand("-attack")
		end
	end
end

function PaintHud()
	for k, v in pairs(player.GetAll()) do
		cam.Start3D(LocalPlayer():GetShootPos(), LocalPlayer():EyeAngles())
			render.SetMaterial(Material("cable/redlaser"))
			local trace = {}
			trace.start = v:GetShootPos()
			trace.endpos = v:GetShootPos() + Vector(0, 0, 10000)
			local tr = util.TraceLine(trace)
			local Uptrace = tr.HitPos
			if tr.Entity and tr.Entity:IsValid() and tr.Entity:GetClass() == "prop_physics" and tr.Entity:GetModel() == "models/props_phx/construct/metal_plate4x4.mdl" then
				render.DrawBeam(Uptrace, v:GetShootPos(), 300, 1, 1, Color(255,255,255,255))
			else
				render.DrawBeam(Uptrace, v:GetShootPos(), 50, 1, 1, Color(255,255,255,255))
			end
		cam.End3D()
	end
	if Target and Target:IsValid() then
		local THead = Target:LookupBone("ValveBiped.Bip01_Head1")
		HeadPos, HeadAng = Target:GetBonePosition(THead)
		local PHead = LocalPlayer():LookupBone("ValveBiped.Bip01_Head1")
		local HP2 = (HeadPos - Vector(0, 0, 10)):ToScreen()
		local SP = Target:GetEyeTrace().HitPos:ToScreen()
		cam.Start3D(ply:GetShootPos(), LocalPlayer():EyeAngles())
			render.SetMaterial(Laser)
			render.DrawBeam(Target:GetShootPos(), Target:GetEyeTrace().HitPos, 10, 1, 1, Color(255,255,255,255))
		cam.End3D()
	end
end

function FollowAim()
	hook.Add("Think", "AimFollow", AimFollow)
end

function StopFollowAim()
	hook.Remove("Think", "AimFollow")
end

function Aim()
	hook.Add("Think", "Aim", AimAt)
end

function StopAim()
	hook.Remove("Think", "Aim")
	if GetConVar("anthrax_killonsight"):GetInt() == 1 then
		ply:ConCommand("-attack")
	end
end

function ToggleTarget()
	local ply = LocalPlayer()
	local tr = ply:GetEyeTrace()

	if tr and tr.Entity and tr.Entity and tr.Entity:IsValid() and tr.Entity:IsPlayer() then
		if tr.Entity != Target then
			Target:SetMaterial(TargetMat)
			TargetMat = Target:GetMaterial()
			Target = tr.Entity
			chat.AddText(Color(255, 255, 255), "Set your target to ", team.GetColor(Target:Team()), Target:Nick(), Color(255, 255, 255), "!")
			Target:SetMaterial("phoenix_storms/pack2/redlight")
			surface.PlaySound("buttons/button24.wav")
		else
			surface.PlaySound("buttons/button17.wav")
			chat.AddText(team.GetColor(Target:Team()), Target:Nick(), Color(255, 255, 255), " is already your current target.")
		end
	end
end

function ChangeTarget(ply)
	if Target and Target:IsValid() then
		Target:SetMaterial(TargetMat)
		TargetMat = Target:GetMaterial()
	end
	Target = ply
	chat.AddText(Color(255, 255, 255), "Set your target to ", team.GetColor(ply:Team()), ply:Nick(), Color(255, 255, 255), "!")
	ply:SetMaterial("phoenix_storms/pack2/redlight")
	surface.PlaySound("buttons/button24.wav")
end

function ChangeTargetMenu()
	local TargetUserID = 0
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(300, 400)
		Frame:SetPos(ScrW() - 310, ScrH() - 410)
		Frame:SetTitle("Player Targetting")
		Frame:MakePopup()
	local List = vgui.Create("DListView", Frame)
		List:SetSize(290, 308)
		List:SetPos(5, 27)
		List:AddColumn("Player Name")
		List:AddColumn("UserID")
		List:SetMultiSelect(false)
		for k, v in pairs(player.GetAll()) do
			List:AddLine(v:Nick(), v:UserID())
		end
		List.OnClickLine = function(this, line, isSelected)
			TargetUserID = line:GetValue(2)
		end
	local TargetButton = vgui.Create("DButton", Frame)
		TargetButton:SetSize(160, 30)
		TargetButton:SetPos((Frame:GetWide() / 2) - 80, Frame:GetTall() - 50)
		TargetButton:SetText("Target selected player")
		TargetButton.DoClick = function()
			for k, v in ipairs(player.GetAll()) do
				if v:UserID() == TargetUserID and Target != v then
					ChangeTarget(v)
					break
				elseif k >= #player.GetAll() and v:UserID() != TargetUserID then
					chat.AddText(Color(255, 0, 0), "Target Error! ", Color(255, 255, 255), "(Maybe you didn't select a player?)")
					surface.PlaySound("buttons/button17.wav")
					break
				elseif Target == v and v:UserID() == TargetUserID then
					surface.PlaySound("buttons/button17.wav")
					chat.AddText(team.GetColor(Target:Team()), Target:Nick(), Color(255, 255, 255), " is already your current target.")
					break
				end
			end
		end
end

concommand.Add("target_menu", ChangeTargetMenu)
concommand.Add("toggle_target", ToggleTarget)
concommand.Add("+follow_aim", FollowAim)
concommand.Add("-follow_aim", StopFollowAim)
concommand.Add("+aim", Aim)
concommand.Add("-aim", StopAim)
CreateClientConVar("anthrax_killonsight", "0", false, false)
CreateClientConVar("anthrax_velocitypredict", "0", false, false)

hook.Add("HUDPaint", "PaintHUD_Target", PaintHud)