umsgh = usermessage.Hook

if !file.Exists("allowedusermessages.txt") then
	file.Write("allowedusermessages.txt", "")
end

function usermessage.Hook(name, func)
	local _file = file.Read("allowedusermessages.txt")
	local _lines = string.Explode(_file, "\n")

	for k, v in ipairs(_lines) do
		if name == line then
			chat.AddText(Color(255, 255, 255), "The hook '", Color(0, 0, 255), name, Color(255, 255, 255), "' was allowed and added!")
			umsgh(name, func)
		elseif k >= #_lines and v != name then
			local Frame = vgui.Create("DFrame")
				Frame:SetSize(240, 400)
				Frame:SetPos(ScrW()- 240 - 40, ScrH() - 400 - 40)
				Frame:SetTitle("Non-Whitelisted Usermessage!")
				Frame:ShowCloseButton(true)
				Frame:MakePopup()
			local Panel = vgui.Create("DPanel", Frame)
				Panel:SetPos(10, 30)
				Panel:SetSize(220, 360)
				Panel.Paint = function()
					surface.SetDrawColor(Color(96, 96, 96, 255))
					surface.DrawRect(0, 0, Panel:GetWide(), Panel:GetTall())
					surface.SetTextColor(Color(255, 255, 255, 255))
					surface.SetFont("Default")
					surface.SetTextPos(10, 10)
					surface.DrawText("A new usermessage which was")
					surface.SetTextPos(10, 22)
					surface.DrawText("NOT whitelisted with name '" .. name .. "'")
					surface.SetTextPos(10, 34)
					surface.DrawText("tried to be added, allow?")
				end
			local Yes = vgui.Create("DButton", Frame)
				Yes:SetPos(10, 360)
				Yes:SetSize(60, 30)
				Yes:SetText("Yes")
				Yes.DoClick = function()
					umsgh(name, func)
					Frame:Close()
				end
			local No = vgui.Create("DButton", Frame)
				No:SetPos(80, 360)
				No:SetSize(60, 30)
				No:SetText("No")
				No.DoClick = function()
					Frame:Close()
				end
			local PermaYes = vgui.Create("DButton", Frame)
				PermaYes:SetPos(170, 360)
				PermaYes:SetSize(60, 30)
				PermaYes:SetText("Perma-Allow")
				PermaYes.DoClick = function()
					umsgh(name, func)
					filex.Append("allowedusermessages.txt", name .. "\n")
					Frame:Close()
				end
		end
	end
end