Coffee.Gamemodes = { 
    Client = Coffee.Client,

    Cache = { }
}

Coffee:LoadFile( 'lua/coffee/libraries/gamemodes/ttt.lua' )