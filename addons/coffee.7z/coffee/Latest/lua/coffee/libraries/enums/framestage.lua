return {
    [ 'FRAME_UNDEFINED' ]                       = -1,
	[ 'FRAME_START' ]                           = 0,
	[ 'FRAME_NET_UPDATE_START' ]                = 1,
	[ 'FRAME_NET_UPDATE_POSTDATAUPDATE_START' ] = 2,
	[ 'FRAME_NET_UPDATE_POSTDATAUPDATE_END' ]   = 3,
	[ 'FRAME_NET_UPDATE_END' ]                  = 4,
	[ 'FRAME_RENDER_START' ]                    = 5,
	[ 'FRAME_RENDER_END' ]                      = 6
}