return {
    [ 'ROLE_NONE' ]      = -1,
	[ 'ROLE_INNOCENT' ]  = 0,
	[ 'ROLE_TRAITOR' ]   = 1,
	[ 'ROLE_DETECTIVE' ] = 2,
}