return {
	[ 'MOVE_START' ]           = 0,
	[ 'MOVE_PRE_PREDICTED' ]   = 1,
    [ 'MOVE_PREDICTED' ]       = 2,
    [ 'MOVE_LATE_PREDICTED' ]  = 3,
    [ 'MOVE_POST_PREDICTED' ]  = 4,
	[ 'MOVE_END' ]             = 5
}