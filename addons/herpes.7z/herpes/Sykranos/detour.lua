--[[
	MOD/lua/providers/herpes/detours.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:48:42AM]
	===BadFile===
]]

/*************************************************************
	   __ __                        
	  / // /___  ____ __ _  ___  ___
	 / _  // -_)/ __//  ' \/ -_)(_-<
	/_//_/ \__//_/  /_/_/_/\__//___/
	
	Name: detours.lua
	Purpose: Hack protection
*************************************************************/
local ply, vars = HERMES.GetSelf, table.Copy( HERMES.vars )
local x, y = ScrW(), ScrH()

local detour = {}

/* --------------------
	:: Anti-screenshot
*/ --------------------
local fvars = {
	["r_drawparticles"] = { last = 1, off = 1 },
	["r_drawothermodels"] = { last = 1, off = 1 },
	["mat_fullbright"] = { last = 0, off = 0 },
}

local function __RELOAD__()
	HERMES._lock = false;
	for k, v in ipairs( fvars ) do
		HERMES.hermes.RunCommand( string.format( "_hermes_%s %c", k, v.last ) )
	end
end

local function __SHUTDOWN__()
	HERMES._lock = true;
	for k, v in ipairs( fvars ) do
		HERMES.hermes.RunCommand( string.format( "_hermes_%s %c", k, v.off ) )
		v.last = vars._GETNUMBER( string.format( "_hermes_%s", k ) )
	end
end

// Got to work on this some more...
render.ReadPixel = HERMES:Detour( render.ReadPixel, function( x, y )
	__SHUTDOWN__();
	local r, g, b = HERMES.detours[ render.ReadPixel ]( x, y );
	__RELOAD__();
	
	return r, g, b
end )

/* --------------------
	:: Unlock
*/ --------------------
local function Unlock()
	if( _G['rawset'] ) then
		vars._RAWSET( _G, "__metatable", nil )
		vars._RAWSET( hook, "__metatable", nil )
		vars._RAWSET( concommand, "__metatable", nil )
	end
	
	// worth a try
	_G['__metatable'] = nil;
	hook['__metatable'] = nil;
	concommand['__metatable'] = nil;
end
Unlock()

/* --------------------
	:: HERMES
*/ --------------------
local scopy = table.Copy( HERMES )

local function IsCallpath( info )
	if( !info ) then return true end
	if( info && string.find( info.short_src, "__autoload__" ) ) then
		return true
	end
	return false
end

local function ProtectTable()
	if( !rawget || !rawset ) then return end // its like we're allways having gay sex
	_G['HERMES'] = nil

	vars._SETMTABLE( _G,
		{
			__index = function( t, k )
				if( k == "HERMES" ) then
					if( IsCallpath( vars._DEBUG.getinfo( 2, "S" ) ) ) then
						return scopy
					end
				end
				return vars._RAWGET( t, k )
			end,
			
			__newindex = function( t, k, v )
				if( k == "HERMES" ) then
					if( !IsCallpath( vars._DEBUG.getinfo( 2, "S" ) ) ) then
						return
					end
				end
				return vars._RAWSET( t, k, v )
			end,
			
			__metatable = true,
		}
	)
end
ProtectTable()

/* --------------------
	:: Hook
*/ --------------------
local oldHookCall = hook.Call
local function IsValidCommand( ply, bind, press ) 
	if( HERMES.ccmds[bind:lower()] ) then
		return true
	end
	return false
end

local function CallHook( name, gm, ... )
	local args = {...}
	
	if( name == "PlayerBindPress" && !HERMES._lock && IsValidCommand( ... ) ) then return false end
	for k, e in pairs( HERMES['hooks'] ) do
		if( k == name ) then
			if( args == nil ) then
				ret = e()
			else
				ret = e( ... )
			end
			if( ret != nil ) then return ret end
		end
	end
	return vars['_HOOK'].Call( name, gm, ... )
end

hook = {}

vars._SETMTABLE( hook,
	{
		__index = function( t, k )
			if( k == "Call" ) then 
				return CallHook 	
			end
			return HERMES['vars']._HOOK[ k ]
		end,
		
		__newindex = function( t, k, v ) 
			if( k == "Call" ) then 
				if( v != CallHook ) then
					oldHookCall = v 
				end
				return
			end
			HERMES['vars']._HOOK[ k ] = v 
		end,
		
		__metatable = true,
	}
)

/* --------------------
	:: ConCommand
*/ --------------------
local oldConCommandRun = concommand.Run

local function RunCommand( ply, name, ... )
	local tbl = HERMES.ccmds[name]
	
	if( tbl ) then
		return tbl( ply, name, ... )
	end
	return vars['_CMD'].Run( ply, name, ... )
end

concommand = {}

vars._SETMTABLE( concommand,
	{
		__index = function( t, k )
			if( k == "Run" ) then 
				return RunCommand 	
			end
			return HERMES['vars']._CMD[ k ]
		end,
		
		__newindex = function( t, k, v ) 
			if( k == "Run" ) then 
				if( v != RunCommand ) then
					oldConCommandRun = v 
				end
				return
			end
			HERMES['vars']._CMD[ k ] = v 
		end,
		
		__metatable = true,
	}
)

/* --------------------
	:: cvars
*/ --------------------
cvars.OnConVarChanged = HERMES:Detour( cvars.OnConVarChanged, function( name, old, new )
	for k, v in pairs( HERMES.convar ) do
		if( string.find( name:lower(), v ) ) then
			return;
		end
	end
	return HERMES.detours[ cvars.OnConVarChanged ]( name, old, new )
end )

/* --------------------
	:: GetMeta
*/ --------------------



/* --------------------
	:: Global Library
*/ --------------------
local function GlobalDetour( func, ret )
	if( !func ) then return end
	_G[ func ] = HERMES:Detour( _G[ func ], function( ... )
		local args = {...}
		for _, i in pairs( args ) do
			for k, v in pairs( HERMES.convar ) do
				if( string.find( i:lower(), v ) ) then
					return ret != nil && ret || ""
				end
			end
		end
		return HERMES.detours[ _G[ func ] ]( ... )
	end )
end

detour.g = {
	{ func = "GetConVar", ret = nil },
	{ func = "ConVarExists", ret = false },
	{ func = "GetConVarNumber", ret = nil },
	{ func = "GetConVarString", ret = nil },
}

for k, v in pairs( detour.g ) do
	GlobalDetour( v.func, v.ret )
end

