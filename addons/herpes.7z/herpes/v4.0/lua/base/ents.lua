// ########################################
// Name: ents.lua
// Purpose: Finding entities and some useful
// functions of use beyond that.
// ########################################

local dll = InitializeTable();

dll.Log( "[Lua]: ents.lua loading...\n" );

