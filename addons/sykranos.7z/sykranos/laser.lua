--[[
	MOD/lua/laser.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:47:48AM]
	===BadFile===
]]



local bluelaser = Material("sprites/bluelaser1")
local laserdot = Material("Sprites/light_glow02_add_noz")

local attachs = {
	[1] = "1",
	[2] = "laser",
	[3] = "spark",
	[4] = "0",
}

local function getbone()
	for k, at in ipairs(attachs) do
		if (LocalPlayer():GetViewModel():LookupAttachment(at)) then
		local pos = LocalPlayer():GetViewModel():LookupAttachment(at)
		return pos
		end
	end
end

local function Laser()
	if (LocalPlayer():Alive()) then
	local weap = LocalPlayer():GetActiveWeapon()
		if (LocalPlayer():GetActiveWeapon()) then
		local vm = LocalPlayer():GetViewModel()
			--if (vm) then
			local bone = vm:LookupAttachment("muzzle")
			if bone == nil || bone == 0 then bone = vm:LookupAttachment("1") end
			if bone == nil || bone == 0 then bone = vm:LookupAttachment("laser") end
			if bone == nil || bone == 0 then bone = vm:LookupAttachment("spark") end
			if bone == nil || bone == 0 then bone = vm:LookupAttachment("0") end
			if bone == nil || bone == 0 then return end
			
		
			local col = team.GetColor(LocalPlayer():Team())
	
			--local boneangpos = EntM.GetAttachment(vm, bone)
			local boneangpos = vm:GetAttachment(bone)
	
				if (boneangpos) then
	
				local bonepos = boneangpos.Pos
				local hitpos = LocalPlayer():GetEyeTrace().HitPos
				cam.Start3D(EyePos(), EyeAngles())
					render.SetMaterial(laserdot)
					--render.DrawQuadEasy(hitpos, VecM.GetNormal(eyepos - hitpos), 20, 20, col, 0)
					render.DrawQuadEasy(hitpos, (EyePos() - hitpos):GetNormal(), 20, 20, col, 0)
					render.SetMaterial(bluelaser)
					render.DrawBeam(bonepos, hitpos, 3, 0, 0, col)
				cam.End3D()
				--end
			end
		end
	end
end
	

hook.Add("RenderScreenspaceEffects", "Laser",Laser)