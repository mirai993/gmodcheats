--[[
	MOD/lua/bones.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:47:46AM]
	===BadFile===
]]

function getbones(ent)
	for bone = 0, ent:GetBoneCount() do
		if (ent:LookupBone(bone)) then
		MsgN(tostring(ent))
		MsgN(tostring(ent:GetBoneName(bone)))
		PrintTable(ent:GetAttachments())
		end
	end
end

