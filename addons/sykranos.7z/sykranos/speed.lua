--[[
	MOD/lua/speed.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:46:20AM]
	===BadFile===
]]

require("replicator")

local _R = debug.getregistry()
local get = GetConVar

local protected = {}

local function addcvar(cvar)
table.insert(protected,cvar)
GetConVar(cvar):SetFlags(FCVAR_NONE)
end

addcvar("sv_cheats")
addcvar("host_timescale")

local function setspeed(int,bool)
if int == nil then int = GetConVar("host_timescale"):GetDefault() end
if bool == nil then return end
if (bool) then
GetConVar("host_timescale"):SetValue(int)
elseif (!bool) then
GetConVar("host_timescale"):SetValue(GetConVar("host_timescale"):GetDefault())
end
end

concommand.Add("+noob",function() GetConVar("sv_cheats"):SetValue(1) setspeed(6,true)
end)


concommand.Add("-noob", function()  GetConVar("sv_cheats"):SetValue(0) setspeed(1,false)
end)