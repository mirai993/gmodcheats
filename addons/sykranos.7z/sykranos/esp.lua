--[[
	MOD/lua/esp.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:47:48AM]
	===BadFile===
]]

local function drawdicks( ply )

	if ( !ply || !IsValid( ply ) ) then return; end

	local health = ply:Health();
	local teamcol = team.GetColor( ply:Team() );

	local origin = ply:GetPos();
	local originscr = origin:ToScreen();

	origin.z = origin.z + ( ply:Crouching() and 50.0 or 70.0 );

	local topscr = origin:ToScreen();

	local h = originscr.y - topscr.y;
	local w = h * 0.25;

--	if ( SOME_VALUE_THAT_IS_THE_ESP ) then 

		surface.SetDrawColor( 0, 0, 0, 205 );

		// Draw outline
		surface.DrawOutlinedRect( topscr.x - w - 2.0, topscr.y - 4.0, (w * 2.0) + 5.0, h + 12.0 );
		surface.DrawOutlinedRect( topscr.x - w, topscr.y - 2.0, (w * 2.0) + 1.0, h + 8.0 );

		// Draw teamcoloured box
		surface.SetDrawColor( teamcol.r, teamcol.g, teamcol.b, teamcol.a );
        surface.DrawOutlinedRect( topscr.x - w - 1.0, topscr.y - 3.0, (w * 2.0) + 3.0, h + 10.0 );


--
	--if ( SOME_VALUE_THAT_IS_WEAPON_ESP ) then 

		if ( ply:IsPlayer() && ply:GetActiveWeapon() ) then 

			draw.DrawText( ply:GetActiveWeapon():GetPrintName(), "default", topscr.x, topscr.y, teamcol );
			topscr.y = topscr.y + 12.0;

		--end
		

	end

	--if ( SOME_VALUE_THAT_IS_HEALTH ) then 

		local healthcol = Color( 255, health * 2.55, health * 2.55, 225 );
		draw.DrawText( health, "default", topscr.x, topscr.y, teamcol );

	--end

	// Calls to functions we don't have source for

end

hook.Add("HUDPaint","noob", function()
for k, v in pairs(player.GetAll()) do  if v != LocalPlayer() then 
drawdicks(v) 
end 
end
end)