--[[
	MOD/lua/dynamic_esp.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:47:47AM]
	===BadFile===
]]


local dimaentities = CreateClientConVar("dima_esp_entities",1,true,false)

surface.CreateFont("printerfont", {
	font = "Verdana",
	size = 10,
	weight = 900,
	dropshadow = true,
	}
)


local entitytab = {}
local tab = {"spawned_weapon","spawned_shipment","spawned_money"}

for k, v in pairs(DarkRPEntities) do table.insert(entitytab,v.ent) end

local function isprinter(ent)
	if string.find(string.lower(ent:GetClass()),"printer") then
	return true
end
return false
end

local function getprinteramount(ent)
	if tobool(ent:GetNWInt("PrintA")) then
		return ent:GetNWInt("PrintA")
	end
return ""
end

local lnext = next
local noob = ents.GetAll

local function esp()
	if dimaentities:GetBool() then
		for k, v in lnext, noob() do
		if (!IsValid(v)) then
			continue
		end
		if (v:IsPlayer()) then
			continue
		end
		if table.HasValue(LocalPlayer():GetTable().Pocket || {}, v) then
			continue
		end
			for c, ent in pairs(entitytab) do
			--print(ent)
				if v:GetClass() == ent or table.HasValue(tab,v:GetClass()) then
					if (!v.IsPocketed) then
					local pos = (v:LocalToWorld(v:OBBCenter()):ToScreen())
				
					if isprinter(v) then
					draw.SimpleText(v:GetClass() .. " - $"..getprinteramount(v) ,"printerfont",pos.x,pos.y,Color(0,255,0),1)
					elseif v:GetClass() == "spawned_money" then
					draw.SimpleText(v:GetClass() ,"printerfont",pos.x,pos.y,Color(255,99,71),1)
					elseif v:GetClass() == "spawned_shipment" then
					draw.SimpleText(v:GetClass() ,"printerfont",pos.x,pos.y,Color(255,255,71),1)
					end
				
				end
				
				
				end
			end
		end
	end
end

hook.Add("HUDPaint","fsdf",esp)

--ent:GetNWInt("PrintA")
--CustomShipments
--Entity:Getamount()