--[[
	MOD/lua/beam.lua
	Woto | STEAM_0:1:16770039 <37.221.173.228:27005> | [23-10-13 04:47:45AM]
	===BadFile===
]]


local props = {
	"models/props/de_train/lockers_long.mdl",
	"models/props/de_train/utility_truck.mdl",
	"models/props/de_tides/gate_large.mdl",
	"models/props_canal/canal_bars001.mdl",
	"models/props_canal/canal_bars004.mdl",
	"models/props_c17/Lockers001a.mdl",
	"models/props_c17/FurnitureWashingmachine001a.mdl",
	"models/props_c17/FurnitureCouch002a.mdl",
	"models/props_c17/FurnitureBathtub001a.mdl",
	"models/props_interiors/BathTub01a.mdl",
	"models/props_lab/blastdoor001c.mdl",
	"models/props_lab/blastdoor001b.mdl",
	"models/props_lab/blastdoor001a.mdl",
}

local surfprops = {
	"models/props_phx/construct/metal_angle360.mdl",
	"models/props_phx/construct/glass/glass_angle360.mdl",
	"models/props_phx/construct/windows/window_angle360.mdl",
	"models/hunter/tubes/circle2x2.mdl",
	"models/props/de_inferno/wine_barrel_p10.mdl",
	"models/props/de_inferno/wine_barrel_p11.mdl",
	"models/props_junk/sawblade001a.mdl",
}


				
local lgetconvarstring = GetConVarString

function GetConVarString(str)
if tostring(str) == "sv_cheats" then 
return GetConVar(str):GetDefault()
end
return lgetconvarstring(tostring(str))
end