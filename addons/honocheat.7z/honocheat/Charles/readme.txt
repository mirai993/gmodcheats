no module required 
this isn't full honocheat because it requires proxi 
put everything into lua folder

also it may be really hard to config and get it to work

File stolen by mr Charles
Stolen from mr charles
(dont tell Charles you got it from us)