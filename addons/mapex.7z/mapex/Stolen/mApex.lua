--[[
	lua/autorun/client/mApex.lua
	Mythik | (STEAM_0:1:34050149)
	===DStream===
]]

--apex by Muffin
--mHack by Mythik
--local _espon = false -- handled using gui, but you can still check for _espon in this script because _espon is global in the gui script
--local _wallon = false -- do the same for this and replace my example, you can put the right tab names and delete items or add new ones
--local _enton = false
--local _crosson = false


if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

orange = Color(255,106,0)
lightblue = Color(0,150,255)
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
white = Color(255,255,255)
yellow = Color(0,255,255)
local mapex = {}

function mapex.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(lightblue, "[mApex] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end
 
 
mapex.Notify(true,green,"has sucessfully loaded!")
 
function CreateTimer( sec, rep, func )
        local index = RandomString( 10 )       
        mapex.timers[ index ] = sec     
        timer.Create( index, sec, rep, func )
end
function RandomString( len )
        local ret = ""
                for i = 1 , len do
                        ret = ret .. string.char( math.random( 65 , 116 ) )
       end
        return ret
end
mapex.timers = {}
CreateClientConVar( "mapex_showadmins", 1, true, false )
CreateClientConVar( "mapex_showspecs", 1, true, false )
CreateClientConVar( "mapex_sniper", 1, true, false )
CreateClientConVar( "mapex_weed", 1, true, false )
CreateClientConVar( "mapex_coke", 1, true, false )
CreateClientConVar( "mapex_printer", 1, true, false )
CreateClientConVar( "mapex_gmodz", 1, true, false )
CreateClientConVar( "mapex_norecoil", 1, true, false )
CreateClientConVar( "mapex_lazer", 1, true, false )
CreateClientConVar( "mapex_dd", 1, true, false )
CreateClientConVar( "mapex_box", 0, true, false )
CreateClientConVar( "mapex_c4", 1, true, false )
CreateClientConVar( "mapex_nospread", 1, true, false )
CreateClientConVar( "mapex_showspec", 1, true, false )
CreateClientConVar( "mapex_antiafk", 0, true, false )
CreateClientConVar( "mapex_autoreload", 1, true, false )
speedhack_speed = CreateClientConVar( "mapex_speedhack_speed", 1, true, false )
mapex_speed = 1

--Check if player is alive or dead
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

concommand.Add("mapex_dancin", function() _dancin = !_dancin  end)
concommand.Add("mapex_esp", function() _espon = !_espon  end)
concommand.Add("mapex_allents", function() _allents = !_allents  end)
concommand.Add("mapex_crosshair", function() _crosson = !_crosson  end)
concommand.Add("mapex_wall", function() _wallon = !_wallon surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("mapex_ent", function() _enton = !_enton surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("mapex_printents", function() _printent = !_printent end)

local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end

--Speed
require("cvar3")
cvar3 = cvars
VO = GetConVar('sv_allow_voice_from_file')
HT = GetConVar('host_timescale')
SC = GetConVar('sv_cheats')
KI = GetConVar('sv_kickerrornum')



forcevoice = function()
VO:SetValue(1.0)
mapex.Notify(true,orange,"Forced CVAR sv_allow_voice_from_file to ", green, "1")
surface.PlaySound("buttons/blip1.wav")
end

forceluakick = function()
KI:SetValue(0.0)
mapex.Notify(true,orange,"Forced CVAR sv_kickerrornum to "..KI:GetInt())
surface.PlaySound("buttons/blip1.wav")
end

speedon = function()
SC:SetValue(1.0)
HT:SetValue(speedhack_speed:GetInt())
end

speedoff = function()
SC:SetValue(0)
HT:SetValue(1.0)
end


concommand.Add("forceluakick", forceluakick)
concommand.Add("forcevoice", forcevoice)
concommand.Add("+mapex_speed", speedon)
concommand.Add("-mapex_speed", speedoff)

mapex.spectators = {}
mapex.admins = {}
mapex.superadmins = {}


 function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(mapex.spectators, v)) then
                                table.insert(mapex.spectators, v);
                                        mapex.Notify(true,orange,""..v:Name().. " has begun to spectate you.")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
				
        for k, v in pairs(mapex.spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(mapex.spectators, k);
                                mapex.Notify(true,green,""..v:Name().." has stopped spectating you.")
                        end
                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(mapex.superadmins, v)) then
                                table.insert(mapex.superadmins, v);
                                mapex.Notify(true,white,"Super Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(mapex.admins, v) and not v:IsSuperAdmin()) then
                                table.insert(mapex.admins, v);
                                mapex.Notify(true,white,"Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)



if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

local mapex    = {} 
mapex.Commands = {}
mapex.ConVars  = {}
mapex.Hooks    = {}
mapex.MenuInfo = {}
mapex.Meta	   = { _G, hook, concommand, debug, file }
mapex.Settings = {}
mapex.World	   = { players = {} }



function mapex:UnlockMeta()
	for i = 1, table.Count( mapex.Meta ) do
		rawset( mapex.Meta[i], "__metatable", false )
	end
end
mapex:UnlockMeta()

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand


mapex.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

mapex.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "mapex_"
}

function mapex:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

function mapex:AddCommand( name, func )
	return concommand.Add(name,func);
end


mapex.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_silent", Value = 1, Desc = "Silent Aim", Type = "bool", Table = "aimsilent", Menu = "aim" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_bunnyhop", Value = 0, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },

	}

function mapex:CreateConVars()
	local tbl = mapex.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = mapex.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		mapex.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		mapex.MenuInfo[pvar] = cvarinfo
		mapex.MenuInfo[#mapex.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			mapex.Settings[v.Table] = new
		end )
	
		mapex.ConVars[pvar] = convar
	end
end
mapex:CreateConVars()

MsgC( Color( 255, 255, 255 ),":: " )
MsgC(  Color( 255, 0, 0 ),"Convars created.\n" )


function mapex:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

function mapex:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function mapex:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function mapex:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function mapex:IsTraitor( e )
	local ply = LocalPlayer()
	if not mapex:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function mapex:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( mapex.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if mapex:IsAdmin( e ) and mapex:G( mapex.Settings['ignoreadmins'], 1 ) then return false end
		if mapex:IsTraitor( e ) and mapex:G( mapex.Settings['ignoretraitors'], 1 ) then return false end
		if mapex:IsFriend( e ) and mapex:G( mapex.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and mapex:G( mapex.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not mapex:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if mapex:IsAdmin( e ) and mapex:G( mapex.Settings['ignoreadmins'], 1 ) then return false end
		if mapex:IsTraitor( e ) and mapex:G( mapex.Settings['ignoretraitors'], 1 ) then return false end
		if mapex:IsFriend( e ) and mapex:G( mapex.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and mapex:G( mapex.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--Aimbot

mapex.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function mapex:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function mapex:GetTargetLocation( e )
	for i = 1, table.Count( mapex.ZombieModels ) do
		if ( e:GetModel() == mapex.ZombieModels[i][1] ) then return mapex:GetPosition( e, mapex.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = mapex:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = mapex:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return mapex:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end


function mapex:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

function mapex:TargetVisible( e )
	local ply = LocalPlayer()
	if mapex:G( mapex.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( mapex:G( mapex.Settings['autowall'], 1 ) and mapex:IsPenetrable( trace ) ) then return true end
	return false
end


function mapex:GetAimTarget()
	if mapex:IsTargetValid( mapex.Vars.target, "aim" ) and mapex:TargetVisible( mapex.Vars.target ) then return mapex.Vars.target else mapex.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 }
	if mapex:G( mapex.Settings['aim'], 1 ) then
		for i = 1, table.Count( mapex.World.players ) do
			local e = mapex.World.players[i]
			if mapex:IsTargetValid( e, "aim" ) and mapex:TargetVisible( e ) then
				local pos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) )
				if ( d < tar[2] ) or ( tar[1] == 0 ) then
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end


function mapex:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if mapex:G( mapex.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( mapex.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

function mapex.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	mapex.Vars.aacorrectang = ply:GetAimVector():Angle()
	mapex.Vars.fakeang = ply:GetAimVector():Angle()
end
mapex:AddHook( "OnToggled", mapex.OnToggled )


function mapex.Aimbot( cmd )
	local ply, tar = LocalPlayer(), mapex:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	mapex.Vars.fakeang.p = math.Clamp( mapex.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	mapex.Vars.fakeang.y = math.NormalizeAngle( mapex.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex:G( mapex.Settings['antiaim'], 0 ) then
		mapex.Copy.SetViewAngles( cmd, mapex.Vars.fakeang )
	end
	if mapex:G( mapex.Settings['aim'], 1 ) and ply:Alive() and tar then
		mapex.Vars.target = tar
		mapex.Vars.found = true
		local pos = mapex:GetTargetLocation( tar ) + mapex:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( mapex.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		mapex.Vars.aimingang = ang
		ang = mapex:GetSmoothAngle( ang )
		if mapex:G( mapex.Settings['nospread'], 1 ) and mapex:G( mapex.Settings['aimsmooth'], 0 ) then
			ang = mapex:PredictSpread( cmd, ang )
		end
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		if mapex:G( mapex.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				mapex.Copy.SetViewAngles( cmd, ang )
				mapex.Vars.aimlocked = true
			else
				mapex.Vars.aimlocked = false
			end
		else
			mapex.Copy.SetViewAngles( cmd, ang )
			mapex.Vars.aimlocked = true
		end
		if mapex:G( mapex.Settings['autoshoot'], 1 ) and not mapex.Vars.firing then
			RunConsoleCommand( "+attack" )
			mapex.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				mapex.Vars.firing = false
			end )
		end
	else
		mapex.Vars.target = nil
		mapex.Vars.aimlocked = false
		mapex.Vars.found = false
	end
	if mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( mapex.Vars.aimingang - mapex.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end
concommand.Add("+mapex_derp", mapex.Aimbot)

function mapex.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {}
	if mapex:G( mapex.Settings['calcview'], 1 ) then
		if mapex.Vars.pkfake and mapex:IsTTT() then
			view.angles = mapex.Vars.pkfakeang
		elseif mapex.Vars.aimlocked and mapex:G( mapex.Settings['aimsmooth'], 1 ) and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		elseif mapex.Vars.aimlocked and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = mapex.Vars.aimingang
		elseif mapex:G( mapex.Settings['aimsilent'], 1 ) or mapex:G( mapex.Settings['antiaim'], 1 ) then
			view.angles = mapex.Vars.fakeang
		elseif mapex:G( mapex.Settings['aimsilent'], 1 ) and mapex:G( mapex.Settings['novisrecoil'], 1 ) then
			view.angles = mapex.Vars.fakeang
		elseif mapex:G( mapex.Settings['novisrecoil'], 1 ) and mapex:G( mapex.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		else
			view = GAMEMODE:CalcView( e, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
mapex:AddHook( "CalcView", mapex.CalcView )

mapex.ply = LocalPlayer;
function NoVisRecoil( ply, pos, angles, fov )
if GetConVarNumber( "mapex_misc_novisrecoil" ) >= 1 && mapex.ply():Health() > 0 && mapex.ply():Team() != TEAM_SPECTATOR && mapex.ply():Alive() then
 return GAMEMODE:CalcView( ply, mapex.ply():EyePos(), mapex.ply():EyeAngles(), fov, 0.1 ) ; 
  end
	end
mapex:AddHook( "CalcView", NoVisRecoil )

function NoRecoill()
if GetConVarNumber( "mapex_norecoil" ) >= 1 then
                if IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil != 0) then
                        LocalPlayer():GetActiveWeapon().OldRecoil = LocalPlayer():GetActiveWeapon().Recoil or (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil)
                        LocalPlayer():GetActiveWeapon().Recoil = 0
                        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        elseif IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.Recoil == 0) and LocalPlayer():GetActiveWeapon().OldRecoil then
                LocalPlayer():GetActiveWeapon().Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
                LocalPlayer():GetActiveWeapon().Primary.Recoil = LocalPlayer():GetActiveWeapon().OldRecoil
        end
 end
 mapex:AddHook( "Think", NoRecoill )
 
function mapex.GetAllPlayers()
	mapex.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( mapex.World.players, e ) end
	end
end


function mapex.CreateMove( cmd )
	mapex.Aimbot( cmd )
	mapex.Bunnyhop( cmd )
end
mapex:AddHook( "CreateMove", mapex.CreateMove )

function mapex.ThinkHook()
	mapex.GetAllPlayers()
end
mapex:AddHook( "Think", mapex.ThinkHook )


--ESP
hook.Add("HUDPaint", "ESP", function()
	for k,v in pairs(player.GetAll()) do
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				if v:IsAdmin() then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("Admin", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				elseif (v:IsSuperAdmin() and not table.HasValue(mapex.superadmins, v)) then
                    table.insert(mapex.superadmins, v);
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("Super Admin", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				else
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("User", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				draw.DrawText("HP: " .. v:Health(), "Herp", ESP.x, ESP.y +40, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
		end
	end
	end)
hook.Add("HUDPaint", "PERP", function()
	for k,v in pairs(player.GetAll()) do
	if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetRPName(), "Herp", ESP.x, ESP.y +7, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end)

	
 --Crosshair
hook.Add("HUDPaint", "Crosshair", function()
if _crosson then
	 surface.SetDrawColor( Color(0, 80, 255, 255) );
     surface.SetMaterial( Material("vgui/hack/crosshair.png") );
     surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 end
 end)
 

--Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxESP", function()
if(GetConVarNumber("mapex_box") == 1) and _espon then
for k,v in pairs(player.GetAll()) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
    local Box1x,Box1y,Box2x,Box2y = coordinates(v)
    surface.SetDrawColor(team.GetColor(v:Team()))
    surface.DrawLine( Box1x, Box1y, math.min( Box1x + 5, Box2x ), Box1y )
    surface.DrawLine( Box1x, Box1y, Box1x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box2x, Box1y, math.max( Box2x - 5, Box1x ), Box1y )
    surface.DrawLine( Box2x, Box1y, Box2x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box1x, Box2y, math.min( Box1x + 5, Box2x ), Box2y )
    surface.DrawLine( Box1x, Box2y, Box1x, math.max( Box2y - 5, Box1y ) )
    surface.DrawLine( Box2x, Box2y, math.max( Box2x - 5, Box1x ), Box2y )
    surface.DrawLine( Box2x, Box2y, Box2x, math.max( Box2y - 5, Box1y ) )
end
end
end
end)
--I know, I was lazy so I used Skittles.


local t = getfenv( 0 )
_R = t.debug.getregistry()
m = t.LocalPlayer()


--AntiAFK
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
        if GetConVarNumber("mapex_antiafk") == 1 then
                local command1 = table.Random( commands )
                local command2 = table.Random( commands )
                CreateTimer( 1, 1, function()
                        RunConsoleCommand( "+"..command1 )
                        RunConsoleCommand( "+"..command2 )
                end )
                CreateTimer( 2, 1, function()
                        RunConsoleCommand("-"..command1 )
                        RunConsoleCommand("-"..command2 )
                end )
        end
end
CreateTimer( 5 , 0 , function() AntiAfk() end )


do --Convenience functions
	function mapex.BonePos( pl, bone )
		return pl:GetBonePosition( pl:LookupBone( bone ) )
	end
	function mapex.Dist( p1, p2 )
		return p1:GetPos():Distance( p2:GetPos() )
	end
	function mapex.Concat( ... )
		return t.string.format( t.string.rep( '%s', t.table.Count( { ... } ) ), ... )
	end
	function mapex.RandString()
		local str, len = '', t.math.random( 1, 7 )
 
		while #str < len do
			mapex.Concat( str, t.string.char( t.math.random( 97, 122 ) ) )
		end
		return str
	end
	function mapex.IsInSight( pl )
		local tr = t.util.TraceLine( { start = t.LocalPlayer():GetShootPos(), endpos = pl:GetPos() + t.Vector( 0, 0, 40 ), filter = { t.LocalPlayer(), pl } } )
    	return tr.Fraction == 1
    end
	
    function mapex.CalcVelocity( target )
    	local hcbow = m:GetActiveWeapon():GetClass() == 'weapon_crossbow'
    	if hcbow then
    		local dist = mapex.Dist( target, m )
    		return target:GetVelocity() * ( dist / 3100 ) + t.Vector( 0, 0, dist / 500 )
    	end
    	return target:GetVelocity() * 0.01
    end
	function mapex.RankInfo( pl )
		if mapex.vars.amod == 1 then
			local rank = evolve.ranks[ pl:EV_GetRank() ]
			return {
				name = rank.Title,
				color = t.Color( rank.Color.r, rank.Color.g, rank.Color.b, 255 )
			}
		elseif mapex.vars.amod == 2 then
			return {
				name = t.team.GetName( pl:Team() ),
				color = t.team.GetColor( pl:Team() )
			}
		else
			return {
				name = pl:IsSuperAdmin() and 'Super Admin' or ( pl:IsAdmin() and 'Admin' or 'Player' ),
				color = t.team.GetColor( pl:Team() )
			}
		end
	end
end

mapex.RCC = RunConsoleCommand



--TTT Propkill
 
concommand.Add("+Propkill", function()
propkill1 = 1
        end)
 
concommand.Add("-Propkill", function()
propkill1 = 0
        end)
 
function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
        end
hook.Add("Think","Tesasd",OpenS)
 
function ReCalc(cmd)
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89)
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove(Forward.x)
cmd:SetSideMove(Forward.y)
 
        end
 end
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)
 
 
function Calc(ply, pos, angles, fov)
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
        end
view.fov = fov
return view
        end
hook.Add("CalcView", "NegTin", Calc)
 
function Throw()
if (LocalPlayer():KeyDown(IN_SPEED)) and propkill1 == 1 then
 
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
 
propkill1 = 0
 
                end
        end
hook.Add("Think","ThrowProp1",Throw)


--Traitor Detector
CreateClientConVar( "mapex_traitor", 0, true, false )              
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" and GetConVarNumber("mapex_traitor") == 1 then

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
function mapex.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(Color(0,150,255), "[mApex] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
										mapex.Notify(true,red,"Player "..pl:Name().." has traitor weapon ".. "[ ".. v:GetClass().." ]")
										surface.PlaySound("buttons/blip1.wav")

                                end
                        end
                end
        end
   end)
   end
                          

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if GetConVarNumber( "mapex_c4" ) >= 1 then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 256 then
draw.DrawText( "Range of C4 Disarm", "Herp", ScrW() / 2 - 115, ScrH()/2 + 300, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "Herp", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )
 
function TraitorESP()
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
for k,v in pairs ( player.GetAll() ) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
if _espon and v.HatTraitor and GetConVarNumber( "mapex_traitor" ) >= 1 then 
local ESP = (v:GetPos()):ToScreen()
draw.DrawText("Traitor", "Herp", ESP.x, ESP.y +51, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end
hook.Add( "HUDPaint", "TraitorESP", TraitorESP )


--Wallhax
hook.Add("HUDPaint", "WallHax", function()
if not _wallon then return end
	for k,v in pairs(player.GetAll()) do
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
				cam.End3D()
				elseif ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
				for k,v in pairs(player.GetAll()) do
				if MESPCheck(v) then
				if v.HatTraitor and GetConVarNumber( "mapex_traitor" ) >= 1 then 
				cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 0, 0, 255))
				render.SetColorModulation( 1, 0, 0 )
				v:DrawModel()
			cam.End3D()
		end
	end
	end
	end
	end
	end)
	

function WeedESP()
if _enton and GetConVarNumber( "mapex_weed" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_pot" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Weed", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "WeedESP", WeedESP )

--Coke ESP
function CokeESP()
	if _enton and GetConVarNumber( "mapex_coke" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_coca" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Coke", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "CokeESP", CokeESP )


function SniperESP()
	if _enton and GetConVarNumber( "mapex_sniper" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "weapon_zm_rifle" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sniper", "Herp", DrugPos.x, DrugPos.y, Color( 0, 200, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "SniperESP", SniperESP )


hook.Add("HUDPaint", "PERPY", function()
	CreateClientConVar( "mapex_dd", 1, true, false )
	if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
			local posx = 17
		local posy = 15
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 80, Color(45,45,45,180) )
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 20, lightblue )
		draw.SimpleText("Dealer", "Herp", ScrW() /2 * 2 - 75, 45, white, TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				--"Buying LSD",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "Herp", ScrW() /2 * 2 - 75, posy + 65, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				--"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "Herp", ScrW() /2 * 2 - 75, posy + 95, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

--tiny dancin man
function dance()
if _dancin then
       RunConsoleCommand("act", "dance")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function PrinterESP()
	if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "silver_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Silver Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end

	if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "money_printer_standard" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Standard Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	
	
		if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
		for k, v in pairs( ents.FindByClass( "gold_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Gold Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 255, 225, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "platinum_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Platinum Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 191, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
			
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "emerald_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Emerald Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
			
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "diamond_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
				
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "tuned_diamond_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Tuned Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
				
			end
			
		if _enton and GetConVarNumber( "mapex_gmodz" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "gmodz_item" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Item", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
		end
		
hook.Add( "HUDPaint", "PrinterESP", PrinterESP )


hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if _allents then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props_c17/consolebox01a.mdl"  or ent:GetModel() != "models/props_c17/consolebox03a.mdl" then
						draw.DrawText("Class: " .. ent:GetClass(), "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money Printer", "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)


function mapex.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if mapex:G( mapex.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end



		hook.Add("HUDPaint", "ShowAdmins", function()
		if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			Adminy = 140
			Admintext = 145
		else
			Adminy = 40
			Admintext = 45
		end
		end)

 hook.Add("HUDPaint", "ShowAdminss", function()
if GetConVarNumber("mapex_showadmins") == 1 then
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Adminy, 100, 80 + textLength, Color(45,45,45,180))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, Adminy, 100, 20, lightblue )
draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, Admintext, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, Admintext + 25 + x, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end

		if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (GetConVarNumber("mapex_showadmins") == 1) then
			Specy = 240 
			Spectext = 245
		elseif GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (GetConVarNumber("mapex_showadmins") == 1) then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
			end
			
if GetConVarNumber("mapex_showspecs") == 1 then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color(45,45,45,180))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, lightblue )
draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, Spectext + textLength, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)



