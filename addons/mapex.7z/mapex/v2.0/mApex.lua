--apex by Muffin
--mHack by Mythik
--local _espon = false -- handled using gui, but you can still check for _espon in this script because _espon is global in the gui script
--local _wallon = false -- do the same for this and replace my example, you can put the right tab names and delete items or add new ones
--local _enton = false
--local _crosson = false

orange = Color(255,106,0)
lightblue = Color(0,150,255)
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
white = Color(255,255,255)
yellow = Color(0,255,255)
local mapex = {}
require( "nyx" )
_nyx.Init()

function mapex.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(lightblue, "[mApex] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end
 
 
mapex.Notify(true,green,"has sucessfully loaded!")
 
function CreateTimer( sec, rep, func )
        local index = RandomString( 10 )       
        mapex.timers[ index ] = sec     
        timer.Create( index, sec, rep, func )
end
function RandomString( len )
        local ret = ""
                for i = 1 , len do
                        ret = ret .. string.char( math.random( 65 , 116 ) )
       end
        return ret
end
mapex.timers = {}
CreateClientConVar( "mapex_showadmins", 1, true, false )
CreateClientConVar( "mapex_showspecs", 1, true, false )
CreateClientConVar( "mapex_sniper", 1, true, false )
CreateClientConVar( "mapex_weed", 1, true, false )
CreateClientConVar( "mapex_coke", 1, true, false )
CreateClientConVar( "mapex_printer", 1, true, false )
CreateClientConVar( "mapex_gmodz", 1, true, false )
CreateClientConVar( "mapex_norecoil", 1, true, false )
CreateClientConVar( "mapex_lazer", 1, true, false )
CreateClientConVar( "mapex_dd", 1, true, false )
CreateClientConVar( "mapex_box", 0, true, false )
CreateClientConVar( "mapex_c4", 1, true, false )
CreateClientConVar( "mapex_nospread", 1, true, false )
CreateClientConVar( "mapex_showspec", 1, true, false )
CreateClientConVar( "mapex_antiafk", 0, true, false )
CreateClientConVar( "mapex_autoreload", 1, true, false )
speedhack_speed = CreateClientConVar( "mapex_speedhack_speed", 1, true, false )
mapex_speed = 1

--Check if player is alive or dead
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

concommand.Add("mapex_dancin", function() _dancin = !_dancin  end)
concommand.Add("mapex_esp", function() _espon = !_espon  end)
concommand.Add("mapex_allents", function() _allents = !_allents  end)
concommand.Add("mapex_crosshair", function() _crosson = !_crosson  end)
concommand.Add("mapex_wall", function() _wallon = !_wallon surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("mapex_ent", function() _enton = !_enton surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("mapex_printents", function() _printent = !_printent end)

local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end

--Speed
require("cvar3")
cvar3 = cvars
VO = GetConVar('sv_allow_voice_from_file')
HT = GetConVar('host_timescale')
SC = GetConVar('sv_cheats')
KI = GetConVar('sv_kickerrornum')



forcevoice = function()
VO:SetValue(1.0)
mapex.Notify(true,orange,"Forced CVAR sv_allow_voice_from_file to ", green, "1")
surface.PlaySound("buttons/blip1.wav")
end

forceluakick = function()
KI:SetValue(0.0)
mapex.Notify(true,orange,"Forced CVAR sv_kickerrornum to "..KI:GetInt())
surface.PlaySound("buttons/blip1.wav")
end

speedon = function()
SC:SetValue(1.0)
HT:SetValue(speedhack_speed:GetInt())
end

speedoff = function()
SC:SetValue(0)
HT:SetValue(1.0)
end


concommand.Add("forceluakick", forceluakick)
concommand.Add("forcevoice", forcevoice)
concommand.Add("+mapex_speed", speedon)
concommand.Add("-mapex_speed", speedoff)

mapex.spectators = {}
mapex.admins = {}
mapex.superadmins = {}


 function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(mapex.spectators, v)) then
                                table.insert(mapex.spectators, v);
                                        mapex.Notify(true,orange,""..v:Name().. " has begun to spectate you.")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
				
        for k, v in pairs(mapex.spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(mapex.spectators, k);
                                mapex.Notify(true,green,""..v:Name().." has stopped spectating you.")
                        end
                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(mapex.superadmins, v)) then
                                table.insert(mapex.superadmins, v);
                                mapex.Notify(true,white,"Super Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(mapex.admins, v) and not v:IsSuperAdmin()) then
                                table.insert(mapex.admins, v);
                                mapex.Notify(true,white,"Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)

--ESP
hook.Add("HUDPaint", "ESP", function()
	for k,v in pairs(player.GetAll()) do
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				if v:IsAdmin() then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("Admin", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				elseif (v:IsSuperAdmin() and not table.HasValue(mapex.superadmins, v)) then
                    table.insert(mapex.superadmins, v);
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("Super Admin", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				else
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					draw.DrawText("User", "Herp", ESP.x, ESP.y +29, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				draw.DrawText("HP: " .. v:Health(), "Herp", ESP.x, ESP.y +40, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
		end
	end
	end)
hook.Add("HUDPaint", "PERP", function()
	for k,v in pairs(player.GetAll()) do
	if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetRPName(), "Herp", ESP.x, ESP.y +7, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end)

	
 --Crosshair
hook.Add("HUDPaint", "Crosshair", function()
if _crosson then
	 surface.SetDrawColor( Color(0, 80, 255, 255) );
     surface.SetMaterial( Material("vgui/hack/crosshair.png") );
     surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 end
 end)
 

--Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxESP", function()
if(GetConVarNumber("mapex_box") == 1) and _espon then
for k,v in pairs(player.GetAll()) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
    local Box1x,Box1y,Box2x,Box2y = coordinates(v)
    surface.SetDrawColor(team.GetColor(v:Team()))
    surface.DrawLine( Box1x, Box1y, math.min( Box1x + 5, Box2x ), Box1y )
    surface.DrawLine( Box1x, Box1y, Box1x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box2x, Box1y, math.max( Box2x - 5, Box1x ), Box1y )
    surface.DrawLine( Box2x, Box1y, Box2x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box1x, Box2y, math.min( Box1x + 5, Box2x ), Box2y )
    surface.DrawLine( Box1x, Box2y, Box1x, math.max( Box2y - 5, Box1y ) )
    surface.DrawLine( Box2x, Box2y, math.max( Box2x - 5, Box1x ), Box2y )
    surface.DrawLine( Box2x, Box2y, Box2x, math.max( Box2y - 5, Box1y ) )
end
end
end
end)
--I know, I was lazy so I used Skittles.


local t = getfenv( 0 )
_R = t.debug.getregistry()
m = t.LocalPlayer()
local mapex = {
	aim = {
		enabled = false,
		maxdist = 99999,
		triggerbot = 1, 
		norecoil = true
	},
	esp = {
		enabled = true,
		maxdist = 99999,
		showname = true, 
		showrank = false,
		showhealth = true, 
		showdist = false
	},
	misc = {
		thirdperson = false,
	},
	vars = {
		amod = evolve and 1 or ( ulx and 2 or 0 ),
		view = Angle(),
		fakeview = Angle(),
		locked = false
	}
}

--AntiAFK
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
        if GetConVarNumber("mapex_antiafk") == 1 then
                local command1 = table.Random( commands )
                local command2 = table.Random( commands )
                CreateTimer( 1, 1, function()
                        RunConsoleCommand( "+"..command1 )
                        RunConsoleCommand( "+"..command2 )
                end )
                CreateTimer( 2, 1, function()
                        RunConsoleCommand("-"..command1 )
                        RunConsoleCommand("-"..command2 )
                end )
        end
end
CreateTimer( 5 , 0 , function() AntiAfk() end )


do --Convenience functions
	function mapex.BonePos( pl, bone )
		return pl:GetBonePosition( pl:LookupBone( bone ) )
	end
	function mapex.Dist( p1, p2 )
		return p1:GetPos():Distance( p2:GetPos() )
	end
	function mapex.Concat( ... )
		return t.string.format( t.string.rep( '%s', t.table.Count( { ... } ) ), ... )
	end
	function mapex.RandString()
		local str, len = '', t.math.random( 1, 7 )
 
		while #str < len do
			mapex.Concat( str, t.string.char( t.math.random( 97, 122 ) ) )
		end
		return str
	end
	function mapex.IsInSight( pl )
		local tr = t.util.TraceLine( { start = t.LocalPlayer():GetShootPos(), endpos = pl:GetPos() + t.Vector( 0, 0, 40 ), filter = { t.LocalPlayer(), pl } } )
    	return tr.Fraction == 1
    end
	
    function mapex.CalcVelocity( target )
    	local hcbow = m:GetActiveWeapon():GetClass() == 'weapon_crossbow'
    	if hcbow then
    		local dist = mapex.Dist( target, m )
    		return target:GetVelocity() * ( dist / 3100 ) + t.Vector( 0, 0, dist / 500 )
    	end
    	return target:GetVelocity() * 0.01
    end
	function mapex.RankInfo( pl )
		if mapex.vars.amod == 1 then
			local rank = evolve.ranks[ pl:EV_GetRank() ]
			return {
				name = rank.Title,
				color = t.Color( rank.Color.r, rank.Color.g, rank.Color.b, 255 )
			}
		elseif mapex.vars.amod == 2 then
			return {
				name = t.team.GetName( pl:Team() ),
				color = t.team.GetColor( pl:Team() )
			}
		else
			return {
				name = pl:IsSuperAdmin() and 'Super Admin' or ( pl:IsAdmin() and 'Admin' or 'Player' ),
				color = t.team.GetColor( pl:Team() )
			}
		end
	end
end

mapex.RCC = RunConsoleCommand



--Aimboate

if not CLIENT then
	return
end
pop="/garrysmod/balloon_pop_cute.wav"
mapex_autoshoot = CreateClientConVar( 'mapex_autoshoot', 1, true, false )

--local t_aim = false
--local t_trigger = false
local t_wallhack = false
local target = nil
local oldtarget = nil
local target_type = "player"
local attack = false
local aim_text = ""
local trigger_text = ""
local wallhack_text = ""
local aim_locked_text = ""
local target_text = ""
local autoshoot = 0
local Player_Whitelist = {}

function toggle_aimbot()
	t_aim =! t_aim
	if t_aim then
		draw.DrawText("Aimbot ON", "Herp", 10, 40, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		surface.PlaySound(pop)
	end
	surface.PlaySound(pop)
end

function toggle_trigger()
	t_trigger =! t_trigger
	surface.PlaySound(pop)
end

function toggle_wallhack()
	t_wallhack =! t_wallhack
end

function change_target_type()
	if target_type=="player" then
		target_type = "npc"
	else
		target_type = "player"
	end
end

function check_npc(ent)
	if ent!=nil and ent:IsValid() and target_type=="npc" and ent:IsNPC() then
		return true
	else
		return false
	end
end

function check_player(ent)
	if ent!=nil and ent:IsValid() and target_type=="player" and ent:IsPlayer() and ent:Alive() then
		return true
	else
		return false
	end
end

function whitelist_handle_player()
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace(ply)
	local traceRes = util.TraceLine(trace)
	
	if traceRes.HitNonWorld and check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
		file.Write("aimbot_whitelist.txt", file.Read("aimbot_whitelist.txt")..","..traceRes.Entity:SteamID())
		mapex.Notify(true,green,"Added player "..traceRes.Entity:GetName().." to the aimbot whitelist.")
		elseif traceRes.HitNonWorld and check_player(traceRes.Entity) and table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
		file.Write("aimbot_whitelist.txt", string.Replace(file.Read("aimbot_whitelist.txt"),","..traceRes.Entity:SteamID(), ""))
		mapex.Notify(true,red,"Removed player "..traceRes.Entity:GetName().." from the aimbot whitelist.")
	end
end

function update()
	if(file.Exists("aimbot_whitelist.txt", "DATA")) then
		Player_Whitelist = string.Explode(",",file.Read("aimbot_whitelist.txt"))
	else
		file.Write("aimbot_whitelist.txt", "")
	end
	
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace(ply)
	local traceRes = util.TraceLine(trace)
	local aimbone = traceRes.PhysicsBone
	
	if target==nil and traceRes.HitNonWorld and t_aim then
		if t_aim and check_npc(traceRes.Entity) or (check_player(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) then
			target = traceRes.Entity
			if target != oldtarget then
				oldtarget = target
			end
		end
	end

	
	if target!=nil and t_aim and (check_npc(target) or (check_player(target)) and !table.HasValue(Player_Whitelist, target:SteamID())) then
		local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
		local targetheadpos,targetheadang = target:GetBonePosition(targethead)
		ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
	else
		if oldtarget!=target then
			oldtarget = target
		end
		target = nil
	end
	
	if !attack and (check_npc(traceRes.Entity) or (check_player(traceRes.Entity)) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID())) and t_trigger and aimbone==10 then
		RunConsoleCommand("+attack")
		attack=true
	elseif attack and (t_trigger or t_aim) then
		RunConsoleCommand("-attack")
		attack=false
	end
	
		if !attack and target and t_aim and mapex_autoshoot:GetInt() == 1 then
		RunConsoleCommand("+attack")
		attack=true
	elseif attack or target!=nil then
		RunConsoleCommand("-attack")
		attack=false
	end
	
	
end

function HudPaint()
	if t_wallhack then
		for k,v in pairs(player.GetAll()) do
			draw.DrawText(v:Name().." ["..math.Round(LocalPlayer():GetPos():Distance(v:GetPos())).."]", "Default", v:GetPos():ToScreen().x, v:GetPos():ToScreen().y-100, Color(-math.sin(RealTime()*10)*255, 0, math.sin(RealTime()*10)*255, 255), 1)
		end
	end
end



function print_whitelist()
	for k,v in pairs(Player_Whitelist) do
		print(v)
	end
end




concommand.Add("+mapex_aim", toggle_aimbot)
concommand.Add("-mapex_aim", toggle_aimbot)
concommand.Add("toggle_mapex_aim", toggle_aimbot)
concommand.Add("mapex_change_target_type", change_target_type)
concommand.Add("mapex_add", whitelist_handle_player)
concommand.Add("mapex_print_whitelist", print_whitelist)


hook.Add("Think", "update", update)
hook.Add("HUDPaint", "paint_hud", HudPaint)


/// TTT Beta PropKill Script ///
 
concommand.Add("+Propkill", function()
propkill1 = 1
        end)
 
concommand.Add("-Propkill", function()
propkill1 = 0
        end)
 
function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
        end
hook.Add("Think","Tesasd",OpenS)
 
function ReCalc(cmd)
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89)
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove(Forward.x)
cmd:SetSideMove(Forward.y)
 
        end
 end
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)
 
 
function Calc(ply, pos, angles, fov)
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
        end
view.fov = fov
return view
        end
hook.Add("CalcView", "NegTin", Calc)
 
 
 
 
function Throw()
if (LocalPlayer():KeyDown(IN_SPEED)) and propkill1 == 1 then
 
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
 
propkill1 = 0
 
                end
        end
hook.Add("Think","ThrowProp1",Throw)

do --Misc

	function mapex.CalcView( ply, pos, ang, fov )
		if mapex.misc.thirdperson then
			return {
				origin = pos - ( ang:Forward() * 100 ),
				angles = ang,
				fov = fov
			}
		else
			if mapex.misc.fov then
				return {
					fov = mapex.misc.fov
				}
			end
		end
	end

	function mapex.ShouldDrawLocalPlayer()
		return mapex.misc.thirdperson or false
	end

	function mapex.BunnyHop( ucmd )
		if mapex.misc.bunnyhop and m:IsOnGround() then
			ucmd:SetButtons( bit.bor( ucmd:GetButtons(), IN_JUMP ) )
		end
	end
	
	concommand.Add( '+mapex_bunnyhop', function() mapex.misc.bunnyhop = true end )
	concommand.Add( '-mapex_bunnyhop', function() mapex.misc.bunnyhop = false end )

	t.hook.Add( 'CreateMove', 'bannehaep', mapex.BunnyHop )	
	t.hook.Add( 'CalcView', 'cawlcveiew', mapex.CalcView )
	t.hook.Add( 'ShouldDrawLocalPlayer', 'shulddraewlokallpleayr', mapex.ShouldDrawLocalPlayer )
end


--Traitor Detector
CreateClientConVar( "mapex_traitor", 0, true, false )              
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" and GetConVarNumber("mapex_traitor") == 1 then

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
function mapex.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(Color(0,150,255), "[mApex] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
										mapex.Notify(true,red,"Player "..pl:Name().." has traitor weapon ".. "[ ".. v:GetClass().." ]")
										surface.PlaySound("buttons/blip1.wav")

                                end
                        end
                end
        end
   end)
   end
                          

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if GetConVarNumber( "mapex_c4" ) >= 1 then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 256 then
draw.DrawText( "Range of C4 Disarm", "Herp", ScrW() / 2 - 115, ScrH()/2 + 300, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "Herp", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )
 
function TraitorESP()
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
for k,v in pairs ( player.GetAll() ) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
if _espon and v.HatTraitor and GetConVarNumber( "mapex_traitor" ) >= 1 then 
local ESP = (v:GetPos()):ToScreen()
draw.DrawText("Traitor", "Herp", ESP.x, ESP.y +51, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end
hook.Add( "HUDPaint", "TraitorESP", TraitorESP )


--Wallhax
hook.Add("HUDPaint", "WallHax", function()
if not _wallon then return end
	for k,v in pairs(player.GetAll()) do
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 255, 255, 255))
				render.SuppressEngineLighting( false )
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
				cam.End3D()
				elseif not _wallon then return end
				if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
				for k,v in pairs(player.GetAll()) do
				if MESPCheck(v) then
				if v.HatTraitor and GetConVarNumber( "mapex_traitor" ) >= 1 then 
				cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 255, 255, 255))
				v:SetMaterial("models/debug/debugwhite")
				render.MaterialOverride("models/debug/debugwhite")
				render.SuppressEngineLighting( false )
				render.SetColorModulation( 1, 0, 0 )
				v:DrawModel()
			cam.End3D()
		end
	end
	end
	end
	end
	end)
	

function WeedESP()
if _enton and GetConVarNumber( "mapex_weed" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_pot" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Weed", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "WeedESP", WeedESP )

--Coke ESP
function CokeESP()
	if _enton and GetConVarNumber( "mapex_coke" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_coca" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Coke", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "CokeESP", CokeESP )


function SniperESP()
	if _enton and GetConVarNumber( "mapex_sniper" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "weapon_zm_rifle" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sniper", "Herp", DrugPos.x, DrugPos.y, Color( 0, 200, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "SniperESP", SniperESP )

--No Recoil
hook.Add( "Think", "NoRecoil", function()
if GetConVarNumber( "mapex_norecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                        end
                end
        end )

		
		

hook.Add("HUDPaint", "PERPY", function()
	CreateClientConVar( "mapex_dd", 1, true, false )
	if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
			local posx = 17
		local posy = 15
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 80, Color(45,45,45,180) )
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 20, lightblue )
		draw.SimpleText("Dealer", "Herp", ScrW() /2 * 2 - 75, 45, white, TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				--"Buying LSD",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "Herp", ScrW() /2 * 2 - 75, posy + 65, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				--"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "Herp", ScrW() /2 * 2 - 75, posy + 95, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

--tiny dancin man
function dance()
if _dancin then
       RunConsoleCommand("act", "dance")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function PrinterESP()
	if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "silver_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Silver Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end

	if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "money_printer_standard" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Standard Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	
	
		if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
		for k, v in pairs( ents.FindByClass( "gold_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Gold Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 255, 225, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "platinum_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Platinum Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 191, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
			
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "emerald_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Emerald Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
			
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "diamond_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
				
			if _enton and GetConVarNumber( "mapex_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "tuned_diamond_money_printer" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Tuned Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
				
			end
			
		if _enton and GetConVarNumber( "mapex_gmodz" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "gmodz_item" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Item", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
		end
		
hook.Add( "HUDPaint", "PrinterESP", PrinterESP )


hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if _allents then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props_c17/consolebox01a.mdl"  or ent:GetModel() != "models/props_c17/consolebox03a.mdl" then
						draw.DrawText("Class: " .. ent:GetClass(), "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money Printer", "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)



		hook.Add("HUDPaint", "ShowAdmins", function()
		if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			Adminy = 140
			Admintext = 145
		else
			Adminy = 40
			Admintext = 45
		end
		end)

 hook.Add("HUDPaint", "ShowAdminss", function()
if GetConVarNumber("mapex_showadmins") == 1 then
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Adminy, 100, 80 + textLength, Color(45,45,45,180))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, Adminy, 100, 20, lightblue )
draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, Admintext, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, Admintext + 25 + x, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end

		if GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (GetConVarNumber("mapex_showadmins") == 1) then
			Specy = 240 
			Spectext = 245
		elseif GetConVarNumber("mapex_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (GetConVarNumber("mapex_showadmins") == 1) then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
			end
			
if GetConVarNumber("mapex_showspecs") == 1 then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color(45,45,45,180))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, lightblue )
draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, Spectext + textLength, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)



