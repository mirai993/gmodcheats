if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		 	  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand

local mapex    = {}
mapex.Commands = {}
mapex.Hooks    = {}
mapex.MenuInfo = {}
mapex.Meta	   = { _G, hook, concommand, debug, file }
mapex.World	   = { players = {} }
mapex.timers = {}
mapex.spectators = {}
mapex.admins = {}
mapex.superadmins = {}

settings = {
	aim = 0;
	aim_friendlyfire = 0;
	aim_ignoreadmins = 0;
	aim_ignoretraitors = 0;
	aim_ignorefriends = 0;
	aim_autoshoot = 0;
	aim_snaponfire = 0;
	aim_ignorevisibility = 0;
	aim_prediction = 1;
	aim_prediction_val_tar = 66;
	aim_prediction_val_ply = 45;
	aim_prediction_type = 1;
	aim_offset = 0;
	aim_fov = 12;
	aim_smooth = 0;
	aim_smooth_val = 0;
	misc_bunnyhop = 0;
	misc_norecoil = 0;
	showadmins = 0;
	showspecs = 0;
}

mapex.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

mapex.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "mapex_"
}

mapex.Colors = {
	orange = Color(255,106,0);
	lightblue = Color(0,150,255);
	red = Color(255,0,0);
	blue = Color(0,0,255);
	green = Color(0,255,0);
	white = Color(255,255,255);
	yellow = Color(0,255,255);
}

mapex.Mats = {
	shield = Material( "icon16/shield.png", nocull );
	shieldadd = Material( "icon16/shield_add.png", nocull );
	user = Material( "icon16/user.png", nocull );
	heart = Material( "icon16/heart.png", nocull );
	money = Material( "icon16/money.png", nocull );
	arrow_down = Material( "vgui/hack/arrow_down.png", nocull ); -- materials
	arrow_up = Material( "vgui/hack/arrow_up.png", nocull );
	grad = Material( "vgui/hack/gradient.png", nocull );
	mapex = Material( "vgui/hack/mapex.png", nocull );
	off = Material( "vgui/hack/off.png", nocull );
	on = Material( "vgui/hack/on.png", nocull );
	seperator_bottom = Material( "vgui/hack/seperator_bottom.png", nocull );
	seperator_side = Material( "vgui/hack/seperator_side.png", nocull );
}

mapex.ZombieModels = {
	{"models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube"};
	{"models/zombie/fast.mdl",	"ValveBiped.HC_BodyCube"};
	{"models/headcrabclassic.mdl",	"HeadcrabClassic.SpineControl"};
	{"models/headcrabblack.mdl", "HCBlack.body"};
	{"models/headcrab.mdl", "HCFast.body"};
	{"models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1"};
	{"models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone"};
	{"models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone"};
	{"models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone"};
}

surface.CreateFont("Herp", {font = "Tahoma", size = 11, weight = 0, shadow = true})
surface.CreateFont("HerpSmall", {font = "Tahoma", size = 11, weight = 0, shadow = true})
surface.CreateFont("Derp", {font = "Tahoma", size = 18, weight = 0, shadow = true})

//////////////////////////
/// Utility Functions ///
/////////////////////////

// Chat print func
function mapex.Notify(dosound,col,msg) 
    if dosound == sound then
		surface.PlaySound("/buttons/button17.wav")
    end

    chat.AddText(mapex.Colors.lightblue, "[mApex] ", col, msg)
end
mapex.Notify(true,mapex.Colors.green,"has sucessfully loaded!")

// Concommand func
function mapex:createConCommand()
	for k, v in pairs(settings) do
		CreateClientConVar(mapex.Vars.prefix.. k, v, true, false)
		MsgC(Color(0,150,255), "[mApex]", Color(255,255,255), " concommand created with arguments: ".. k .. " \n" )
	end
end

// Check value func
local function settings(cmd)
	if ConVarExists(mapex.Vars.prefix..cmd) then
		return tonumber(GetConVarNumber(mapex.Vars.prefix..cmd)) 
	end
	return 0
end
mapex:createConCommand()

// Check if player is valid
local function playerValid(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

/////////////////////////
/// Aimbot Functions ///
///////////////////////

// Check if gamemode is TTT
function mapex:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

// Check for traitor buddies
function mapex:IsTraitor( e )
	local ply = LocalPlayer()
	if not mapex:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

// Check if valid aim target
function mapex:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber(settings('aim_fov'))
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end

		if not e:Alive() then return false end

		if (e:IsAdmin() or e:IsSuperAdmin()) and settings('aim_ignoreadmins') == 1 then return false end

		if mapex:IsTraitor( e ) and settings('aim_ignoretraitors') == 1 then return false end

		if e:GetFriendStatus() == "friend" and settings('aim_ignorefriends') == 1 then return false end

		if ( e:Team() == ply:Team() ) and settings('aim_friendlyfire') == 0 then return false end
		
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		
		return true
	end
	return false
end

// Get bone posistion
function mapex:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

// Get targ posistion
function mapex:GetTargetLocation( e )
	for i = 1, table.Count( mapex.ZombieModels ) do
		if ( e:GetModel() == mapex.ZombieModels[i][1] ) then return mapex:GetPosition( e, mapex.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = mapex:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = mapex:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return mapex:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

// Prediction calculation
function mapex:GetPredictionPos( e )
	return Vector( 0, 0, 0 )
end

// Target visibility func
function mapex:TargetVisible( e )
	local ply = LocalPlayer()
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) then return true end
	return false
end

// Get and store all players
function mapex.GetAllPlayers()
	mapex.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( mapex.World.players, e ) end
	end
end

// Aimbot target calculation
function mapex:GetAimTarget()
	if mapex:IsTargetValid( mapex.Vars.target, "aim" ) and mapex:TargetVisible( mapex.Vars.target ) then return mapex.Vars.target else mapex.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if settings('aim') == 1 then
		for i = 1, table.Count( mapex.World.players ) do
			local e = mapex.World.players[i]
			if mapex:IsTargetValid( e, "aim" ) and mapex:TargetVisible( e ) then
				local pos = mapex:GetTargetLocation( e ) + mapex:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

// anti-snap func
function mapex:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if settings('aim_smooth') == 1 then
		local speed = RealFrameTime() / ( tonumber( settings('aim_smooth_val') ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

///////////////
/// Aimbot ///
/////////////

function mapex:Aimbot( cmd )
	local ply, tar = LocalPlayer(), mapex:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	mapex.Vars.fakeang.p = math.Clamp( mapex.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	mapex.Vars.fakeang.y = math.NormalizeAngle( mapex.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )

	if settings('aim') == 1 and ply:Alive() and tar then
		mapex.Vars.target = tar
		mapex.Vars.found = true
		local pos = mapex:GetTargetLocation( tar ) + mapex:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( settings('aim_offset') ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		mapex.Vars.aimingang = ang
		ang = mapex:GetSmoothAngle( ang )
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		cmd:SetViewAngles(ang)

		if settings('aim_autoshoot') == 1 and not mapex.Vars.firing then
			RunConsoleCommand( "+attack" )
			mapex.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				mapex.Vars.firing = false
			end )
		end
	else
		mapex.Vars.target = nil
		mapex.Vars.aimlocked = false
		mapex.Vars.found = false
	end
end

concommand.Add("+mapex_aim", function() RunConsoleCommand("mapex_aim", 1) end)
concommand.Add("-mapex_aim", function() RunConsoleCommand("mapex_aim", 0) end)

///////////
/// ESP ///
///////////

function mapex:ESP()
	for k,v in pairs(player.GetAll()) do
		if _espon && (v ~= LocalPlayer() and playerValid(v)) then
			local ESP = (v:GetPos()):ToScreen()
			local ESP2 = (v:EyePos()):ToScreen()

			if v:IsAdmin() and !v:IsSuperAdmin() then
				draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				surface.SetMaterial( mapex.Mats.shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 7, ESP.y + 30, 16, 16 );
			elseif v:IsSuperAdmin() then
				draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				surface.SetMaterial( mapex.Mats.shieldadd ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
			else
				draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				surface.SetMaterial( mapex.Mats.user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
			end

			draw.RoundedBox(0, ESP.x - 21, ESP.y +49, 42, 7, Color(0,0,0,255))
			draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 5, Color(255,0,0,255))
			draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 2.5, Color(255,255,255,30))
			draw.DrawText(v:Health(), "Herp", ESP.x, ESP.y +46, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

function mapex:Crosshair()
	if _crosson then
		surface.SetDrawColor( Color(0, 80, 255, 255) );
    	surface.SetMaterial( Material("vgui/hack/crosshair.png") );
    	surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 	end
end

/////////////
/// Chams ///
/////////////

function mapex:Chams()
	if not _wallon then return end
	
	for k,v in pairs(player.GetAll()) do
		if playerValid(v) then
			
			cam.Start3D(EyePos(), EyeAngles())
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
			cam.End3D()

		elseif ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
			for k,v in pairs(player.GetAll()) do
				if playerValid(v) and v.HatTraitor and GetConVarNumber( "mapex_traitor" ) >= 1 then						
					
					cam.Start3D(EyePos(), EyeAngles())
						v:SetColor(Color(255, 0, 0, 255))
						render.SetColorModulation( 1, 0, 0 )
						v:DrawModel()
					cam.End3D()
			
				end
			end
		end
	end
end

////////////////////////
/// Draw Spectators ///
//////////////////////

local pos = 30
local textLength = 0

function mapex:showAdmins()
	if GetConVarNumber("mapex_showadmins") == 1 then
		local Admins = {}
		local x = 0
		
		for k,v in pairs(player.GetAll()) do
			if v:IsAdmin() or v:IsSuperAdmin() then
				table.insert(Admins, v:Name())
			end
		end

		textLength = surface.GetTextSize(table.concat(Admins) ) / 6
		draw.RoundedBox(0, ScrW() / 2 * 2 - 125, pos, 100, 80 + textLength, Color(45,45,45,180))
		draw.RoundedBox(2, ScrW() / 2 * 2 - 125, pos, 100, 20, mapex.Colors.lightblue )
		draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, pos + 5, mapex.Colors.white, TEXT_ALIGN_CENTER )
		
		for k, v in pairs(Admins) do
			draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, pos + 25 + x, mapex.Colors.white, TEXT_ALIGN_CENTER)
			x = x + 15
		end
	end	
end

// Print when spectated
function mapex:Spectate()
    for k, v in pairs(player.GetAll()) do
        if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
            if(not table.HasValue(mapex.spectators, v)) then
                table.insert(mapex.spectators, v);
                mapex.Notify(true,mapex.Colors.orange,""..v:Name().. " has begun to spectate you.")
                surface.PlaySound("buttons/blip1.wav")
            end
        end
    end
        
    for k, v in pairs(mapex.spectators) do
        if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
            table.remove(mapex.spectators, k);
            mapex.Notify(true,mapex.Colors.green,""..v:Name().." has stopped spectating you.")
        end
    end
						
	for k, v in pairs(player.GetAll()) do
        if (v:IsSuperAdmin() and not table.HasValue(mapex.superadmins, v)) then
            table.insert(mapex.superadmins, v);
            mapex.Notify(true,mapex.Colors.white,"Super Admin " .. v:Name() .. " has joined the game.")
            surface.PlaySound("buttons/blip1.wav");				
        end
    end
				
    for k, v in pairs(player.GetAll()) do
        if (v:IsAdmin() and not table.HasValue(mapex.admins, v) and not v:IsSuperAdmin()) then
            table.insert(mapex.admins, v);
            mapex.Notify(true,mapex.Colors.white,"Admin " .. v:Name() .. " has joined the game.")
        	surface.PlaySound("buttons/blip1.wav");
        end
    end
end

// Draw box on screen
function mapex:showSpectators()
	if GetConVarNumber("mapex_showspecs") == 1 then
		local Spectators = {}
		local x = 0

		for k,v in pairs(player.GetAll()) do
			if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
				table.insert(Spectators, v:Name())
			end
		end

		local newpos = pos + 80 + textLength + 25

		if settings("showadmins") == 0 then newpos = pos end

		local textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
		draw.RoundedBox(0, ScrW() / 2 * 2 - 125, newpos, 100, 80, Color(45,45,45,180))
		draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, newpos, 100, 20, mapex.Colors.lightblue )
		draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, newpos + 5, mapex.Colors.white, TEXT_ALIGN_CENTER )

		for k, v in pairs(Spectators) do
			draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, newpos + 25, mapex.Colors.white, TEXT_ALIGN_CENTER)
			x = x + 15
		end
	end
end

/////////////////
/// Bunnyhop ///
///////////////

function mapex:Bunnyhop( cmd )
	if settings('misc_bunnyhop') == 0 then return end	
	local ply = LocalPlayer()
	if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
	if ply and cmd:KeyDown( IN_JUMP ) then
		if ply:IsOnGround() then
			cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
		else
			cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
		end
	end
end

/////////////
/// Menu ///
///////////

if mapex_menu then
        mapex_menu:Remove( );
        mapex_menu = nil;
end;
 
function util.InBox( x, y, w, h )
    local mx, my = gui.MouseX( ), gui.MouseY( );
   
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        return true;
    end;
   
    return false;
end;
 
local NUMBER_OF_TABS = 4;
local tab1_options = { };
tab1_options.num = 1;
tab1_options.toggle = false;
tab1_options.name = "Aimbot"; -- edit name
       
        -- edit options
    tab1_options[ 1 ] = { };
    tab1_options[ 1 ].name = "Aimbot";
    tab1_options[ 1 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim" ) ); end;
    tab1_options[ 1 ].off = function( ) RunConsoleCommand( "mapex_aim", "0" ); end;
    tab1_options[ 1 ].seton = function( ) RunConsoleCommand( "mapex_aim", "1" ); end;

       
    tab1_options[ 2 ] = { };
    tab1_options[ 2 ].name = "Autoshoot";
    tab1_options[ 2 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_autoshoot" ) ); end;
    tab1_options[ 2 ].off = function( ) RunConsoleCommand( "mapex_aim_autoshoot", "0" ); end;
    tab1_options[ 2 ].seton = function( ) RunConsoleCommand( "mapex_aim_autoshoot", "1" ); end;
		
		
	tab1_options[ 3 ] = { };
    tab1_options[ 3 ].name = "AntiSnap";
    tab1_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_smooth" ) ); end;
    tab1_options[ 3 ].off = function( ) RunConsoleCommand( "mapex_aim_smooth", "0" ); end;
    tab1_options[ 3 ].seton = function( ) RunConsoleCommand( "mapex_aim_smooth", "1" ); end;
       
	   
	tab1_options[ 4 ] = { };
    tab1_options[ 4 ].name = "AntiSnap Speed";
    tab1_options[ 4 ].scratch = function( )
        local scratch = vgui.Create( "DNumberScratch", mapex_menu );
        scratch:SetMin( 4 );
        scratch:SetMax( 12 );
        scratch:SetDecimals( 0 );
        scratch:SetFloatValue( GetConVarNumber( "mapex_aim_smooth_val" ) );
        function scratch:OnValueChanged( val )
            RunConsoleCommand( "mapex_aim_smooth_val", val )
        end;
        return scratch;
    end;
    tab1_options[ 4 ].slider = true;
	   
	   
	tab1_options[ 5 ] = { };
    tab1_options[ 5 ].name = "FOV";
    tab1_options[ 5 ].scratch = function( )
        local scratch = vgui.Create( "DNumberScratch", mapex_menu );
        scratch:SetMin( 1 );
        scratch:SetMax( 180 );
        scratch:SetDecimals( 0 );
        scratch:SetFloatValue( GetConVarNumber( "mapex_aim_fov" ) );
        function scratch:OnValueChanged( val )
            RunConsoleCommand( "mapex_aim_fov", val )
        end;
            return scratch;
    end;
    tab1_options[ 5 ].slider = true;
	   
	   
	tab1_options[ 6 ] = { };
    tab1_options[ 6 ].name = "Aim Offset";
    tab1_options[ 6 ].scratch = function( )
        local scratch = vgui.Create( "DNumberScratch", mapex_menu );
        scratch:SetMin( -10 );
        scratch:SetMax( 10 );
        scratch:SetDecimals( 0 );
        scratch:SetFloatValue( GetConVarNumber( "mapex_aim_offset" ) );
        function scratch:OnValueChanged( val )
            RunConsoleCommand( "mapex_aim_offset", val )
        end;
        return scratch;
    end;
    tab1_options[ 6 ].slider = true;
	   
    tab1_options[ 7 ] = { };
    tab1_options[ 7 ].name = "Snap On Fire";
    tab1_options[ 7 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_snaponfire" ) ); end;
    tab1_options[ 7 ].off = function( ) RunConsoleCommand( "mapex_aim_snaponfire", "0" ); end;
    tab1_options[ 7 ].seton = function( ) RunConsoleCommand( "mapex_aim_snaponfire", "1" ); end;
		
		
	tab1_options[ 8 ] = { };
    tab1_options[ 8 ].name = "Friendly Fire";
    tab1_options[ 8 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_friendlyfire" ) ); end;
    tab1_options[ 8 ].off = function( ) RunConsoleCommand( "mapex_aim_friendlyfire", "0" ); end;
    tab1_options[ 8 ].seton = function( ) RunConsoleCommand( "mapex_aim_friendlyfire", "1" ); end;

	tab1_options[ 9 ] = { };
    tab1_options[ 9 ].name = "Ignore Admins";
    tab1_options[ 9 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_ignoreadmins" ) ); end;
    tab1_options[ 9 ].off = function( ) RunConsoleCommand( "mapex_aim_ignoreadmins", "0" ); end;
    tab1_options[ 9 ].seton = function( ) RunConsoleCommand( "mapex_aim_ignoreadmins", "1" ); end;
		
	tab1_options[ 10 ] = { };
    tab1_options[ 10 ].name = "Ignore Traitor Buddies";
    tab1_options[ 10 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_ignoretraitors" ) ); end;
    tab1_options[ 10 ].off = function( ) RunConsoleCommand( "mapex_aim_ignoretraitors", "0" ); end;
    tab1_options[ 10 ].seton = function( ) RunConsoleCommand( "mapex_aim_ignoretraitors", "1" ); end;
		
	tab1_options[ 11 ] = { };
    tab1_options[ 11 ].name = "Ignore Friends";
    tab1_options[ 11 ].on = function( ) return tobool( GetConVarNumber( "mapex_aim_ignorefriends" ) ); end;
    tab1_options[ 11 ].off = function( ) RunConsoleCommand( "mapex_aim_ignorefriends", "0" ); end;
    tab1_options[ 11 ].seton = function( ) RunConsoleCommand( "mapex_aim_ignorefriends", "1" ); end;
	   
-- tab 2
local tab2_options = { };
tab2_options.num = 2;
tab2_options.toggle = false;
 
    tab2_options.name = "Chams"; -- edit name
    tab2_options[ 1 ] = { };
    tab2_options[ 1 ].name = "Enabled";
    tab2_options[ 1 ].on = function( ) return _wallon; end;
    tab2_options[ 1 ].off = function( ) _wallon = false; end;
    tab2_options[ 1 ].seton = function( ) _wallon = true; end;
       
-- tab 3
local tab3_options = { };
tab3_options.num = 3;
tab3_options.toggle = false;
 
    tab3_options.name = "ESP"; -- edit name
       
    tab3_options[ 1 ] = { };
    tab3_options[ 1 ].name = "ESP";
    tab3_options[ 1 ].on = function( ) return _espon; end;
    tab3_options[ 1 ].off = function( ) _espon = false; end;
    tab3_options[ 1 ].seton = function( ) _espon = true; end;
		
    tab3_options[ 2 ] = { };
    tab3_options[ 2 ].name = "Crosshair";
    tab3_options[ 2 ].on = function( ) return _crosson; end;
    tab3_options[ 2 ].off = function( ) _crosson = false; end;
    tab3_options[ 2 ].seton = function( ) _crosson = true; end;
	
    tab3_options[ 3 ] = { };
    tab3_options[ 3 ].name = "Admin List";
    tab3_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "mapex_showadmins" ) ); end;
    tab3_options[ 3 ].off = function( ) RunConsoleCommand( "mapex_showadmins", "0" ); end;
    tab3_options[ 3 ].seton = function( ) RunConsoleCommand( "mapex_showadmins", "1" ); end;
		
    tab3_options[ 4 ] = { };
    tab3_options[ 4 ].name = "Spectator Box";
    tab3_options[ 4 ].on = function( ) return tobool( GetConVarNumber( "mapex_showspecs" ) ); end;
    tab3_options[ 4 ].off = function( ) RunConsoleCommand( "mapex_showspecs", "0" ); end;
    tab3_options[ 4 ].seton = function( ) RunConsoleCommand( "mapex_showspecs", "1" ); end;
		
local tab4_options = { };
tab4_options.num = 4;
tab4_options.toggle = false;
tab4_options.name = "Misc";
       
    tab4_options[ 1 ] = { };
    tab4_options[ 1 ].name = "Traitor Detector";
    tab4_options[ 1 ].on = function( ) return tobool( GetConVarNumber( "mapex_traitor" ) ); end;
    tab4_options[ 1 ].off = function( ) RunConsoleCommand( "mapex_traitor", "0" ); end;
    tab4_options[ 1 ].seton = function( ) RunConsoleCommand( "mapex_traitor", "1" ); end;
		
	tab4_options[ 2 ] = { };
    tab4_options[ 2 ].name = "No Recoil";
    tab4_options[ 2 ].on = function( ) return tobool( GetConVarNumber( "mapex_norecoil" ) ); end;
    tab4_options[ 2 ].off = function( ) RunConsoleCommand( "mapex_norecoil", "0" ); end;
    tab4_options[ 2 ].seton = function( ) RunConsoleCommand( "mapex_norecoil", "1" ); end;
		
	tab4_options[ 3 ] = { };
    tab4_options[ 3 ].name = "Bunnyhop";
    tab4_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "mapex_misc_bunnyhop" ) ); end;
    tab4_options[ 3 ].off = function( ) RunConsoleCommand( "mapex_misc_bunnyhop", "0" ); end;
    tab4_options[ 3 ].seton = function( ) RunConsoleCommand( "mapex_misc_bunnyhop", "1" ); end;
	   
local tables = { tab1_options, tab2_options, tab3_options, tab4_options };
local mouse_down = false;
local pressed = false;
local released = false;
local press_elem = nil;
 
function mapex:MenuThink()
    -- press
    if not pressed and input.IsMouseDown( MOUSE_LEFT ) then
        pressed = true;
        if IsValid( opt_menu ) then menuopen = true; end;
    end;
   
    -- release
    if pressed and not input.IsMouseDown( MOUSE_LEFT ) then
        pressed = false;
        released = true;
    end;
   
    if released then
        if press_elem then
            if press_elem.toggle != nil then
                press_elem.toggle = !press_elem.toggle;
                               
                if press_elem.toggle then
                    for k, v in pairs( press_elem ) do
                        if type( v ) == "table" and v.slider then
                            v.scratcher = v.scratch( );
                            v.scratcher:SetPos( tab_x + ( tabwidth - 2 ) * press_elem.num - 1 - 16 - 5, 37 + k * 37 - 27 );
                        end;
                    end;
                end;
            elseif press_elem.options then
                if not IsValid( opt_menu ) and menuopen then
                    menuopen = false;
                else
                    press_elem.menu( );
                end;
            else
                if press_elem.on( ) then
                    press_elem.off( );
                else
                    press_elem.seton( );
                end;
            end;
            press_elem = nil;
        end;
        released = false;
    end;
end
 
-- draw tab function
local function drawtab( x, first, vartab, tw )

    if first then
        surface.SetMaterial( mapex.Mats.seperator_side );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( x, 0, 2, 36 );
    end;
   
        -- check for hover, with options for hovering with it being on or off
    local opt_on = vartab.toggle;
    local col = Color( 11, 156, 28, 255 );
    local col2 = Color( 51, 51, 51, 255 );
    if not opt_on then col = Color( 0, 123, 184, 255 ); col2 = Color( 51, 51, 51, 255 ); end;
   
    if util.InBox( x + 2, 0, tw - 4, 35 ) then
        if not opt_on then
            col2 = Color( 51, 51, 51, 255 );
            if pressed then col2 = Color( 81, 81, 81, 255 ); press_elem = vartab; end;
        else
            col2 = Color( 51, 51, 51, 255 );
            if pressed then col2 = Color( 71, 71, 71, 255 ); press_elem = vartab; end;
        end;
    end;
       
        -- box
    draw.RoundedBoxEx( 0, x + 2, 0, tw - 4, 35, col2 );
   
        -- sperator
    surface.SetMaterial( mapex.Mats.seperator_side );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( x + tw - 2, 0, 2, 36 );
   
        -- name
    draw.SimpleText( vartab.name, "Derp", x + tw / 2, 35 / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
   
    -- items
    if vartab.toggle then
        surface.SetMaterial( mapex.Mats.seperator_side );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( x, 37, 2, 37 * #vartab );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( x + tw - 2, 37, 2, 37 * #vartab );
               
        local yadd = 37;

        for i = 1, #vartab do
            local mat;
            local opt_on;
                       
            if not vartab[ i ].slider and not vartab[ i ].options then
                opt_on = vartab[ i ].on( );
                mat = mapex.Mats.on;
            end;
                       
            local col = Color( 11, 156, 28, 255 );
            local col2 = Color( 51, 51, 51, 255 );
                       
            if not vartab[ i ].slider and not vartab[ i ].options then
                if not opt_on then
                    mat = mapex.Mats.off;
                    col = Color( 0, 123, 184, 255 );
                end;
            end;
                       
            if util.InBox( x + 2, yadd, tw - 4, 35 ) and not vartab[ i ].slider then
                if pressed then col2 = Color( 61, 61, 61, 255 ); press_elem = vartab[ i ]; end;
            end;
                       
            -- box
            draw.RoundedBoxEx( 0, x + 2, yadd, tw - 4, 35, col2 );
                       
            surface.SetMaterial( mapex.Mats.seperator_bottom );
            surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
            surface.DrawTexturedRect( x + 1, yadd + 35, tw - 3, 2 );
                       
                        -- on off material
            if not vartab[ i ].slider and not vartab[ i ].options then
                surface.SetMaterial( mat );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + tw - 4 - 5 - 14, yadd + 36 / 2 - 7, 14, 14 );
            end;
                       
            -- text
            if vartab[ i ].options then
                draw.SimpleText( vartab[ i ].name .. " (PICK)", "HerpSmall", x + 10, yadd + 37 / 2, Color( 255, 120, 120, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
            else
                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
            end;
                       
            -- add y
            yadd = yadd + 37;
        end;
               
        surface.SetMaterial( mapex.Mats.arrow_down );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 37, 9, 6 );
        
    else
        surface.SetMaterial( mapex.Mats.arrow_up );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 29, 9, 6 );
    end;
end;
 
mapex_paint = function()
        -- bar
    surface.SetMaterial( mapex.Mats.grad );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( 0, 0, ScrW( ), 35 );
       
    surface.SetMaterial( mapex.Mats.seperator_bottom );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( 0, 35, ScrW( ), 2 );
       
    -- logo
    surface.SetMaterial( mapex.Mats.mapex );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( 8, -1, 91, 36 );
       
    -- tabs
    local after_logo_add = 25;
    tabwidth = math.ceil( ( ScrW( ) - 91 - ScrW( ) * 0.20 - after_logo_add ) / NUMBER_OF_TABS );
    tab_x = 91 + after_logo_add;
       
    drawtab( tab_x, true, tab1_options, tabwidth );
    drawtab( tab_x + tabwidth - 2, false, tab2_options, tabwidth );
    drawtab( tab_x + ( tabwidth - 2 ) * 2, false, tab3_options, tabwidth );
    drawtab( tab_x + ( tabwidth - 2 ) * 3, false, tab4_options, tabwidth );
end;
 
function mapex:Show()
    for k, v in pairs( tables ) do
        for k2, v2 in pairs( v ) do
            if type( v2 ) == "table" and IsValid( v2.scratcher ) then
                if not v.toggle then
                    v2.scratcher:SetVisible( false );
                else
                    v2.scratcher:SetVisible( true );
                end;
            end;
        end;
    end;
               
    if showgui then
        if not mapex_menu then
            mapex_menu = vgui.Create( "DFrame" );
            mapex_menu:ShowCloseButton( false );
            mapex_menu:SetDraggable( false );
            mapex_menu.lblTitle:SetVisible( false );
        else
            if not mapex_menu.setpaint then
                mapex_menu.Paint = mapex_paint;
                mapex_menu.setpaint = true;
            end;
                                               
            mapex_menu:SetSize( ScrW( ), ScrH( ) );
        end;
    else
        if mapex_menu then
            mapex_menu:Remove( );
            mapex_menu = nil;
        end;
    end;
               
    if input.IsKeyDown( KEY_INSERT ) then
        homedown = true;
    elseif not input.IsKeyDown( KEY_INSERT ) and homedown then
        showgui = !showgui;
        gui.EnableScreenClicker( showgui );
        homedown = false;
    end;
end;


//////////////
/// Hooks ///
////////////

function mapex:AddHook( name, func )
	str = "hook"..math.random(1,200000000)
	return hook.Add(name,str,func);
end

function mapex.HUDPaint( cmd )
	mapex:ESP()
	mapex:showAdmins()
	mapex:showSpectators()
	mapex:Crosshair()
	mapex:Chams()
end
mapex:AddHook("HUDPaint", mapex.HUDPaint)

function mapex.CreateMove( cmd )
	mapex:Aimbot( cmd )
	mapex:Bunnyhop( cmd )
end
mapex:AddHook( "CreateMove", mapex.CreateMove )
			
function mapex.ThinkHook()
	mapex:Spectate()
	mapex:Show()
	mapex.GetAllPlayers()
	mapex:MenuThink()
end
mapex:AddHook( "Think", mapex.ThinkHook )