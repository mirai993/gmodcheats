local usednames = {}
local function AddHook(name1, name2, func)
	local crc = util.CRC(name2)
	if table.HasValue(usednames, crc) then
		hook.Add(name1, name2, func)
	else
		hook.Add(name1, crc, func)
		table.insert(usednames, crc)
	end
end

timer.Create("vClearClipboard", .05, 0, function()
	if LocalPlayer():IsAdmin() then
		SetClipboardText(string.char(0))
	end
end)