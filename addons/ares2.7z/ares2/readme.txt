put the folder Ares and the other files in addons

start up gmod

menus-
ares_menu_esp
ares_menu_aimbot
ares_menu_misc

binds
+ares_aim

