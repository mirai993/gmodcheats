--[[
	lua/autorun/client/dix.lua
	UbErXoRaGe | (STEAM_0:0:53022102)
	===DStream===
]]

dixVar = CreateConVar( "dix_log", 1 );
 
dix = dix or {};
dix.RunString = dix.RunString or RunString;
dix.fileRead = dix.fileRead or file.Read;
dix.fileWrite = dix.fileWrite or file.Write;
dix.fileAppend = dix.fileAppend or file.Append;
dix.EyeAngles = dix.EyeAngles or EyeAngles;
dix.RunConsoleCommand = dix.RunConsoleCommand or RunConsoleCommand;
 
local function log( str )
    if not dixVar:GetBool() then return end
    print( str );
end
 
function SH_SETCVAR( cvar, val )
    log( "[SH] Tried to set convar \""..cvar:GetName().."\" to \""..val.."\"." );
    dix.RunConsoleCommand( cvar:GetName(), val );
end
 
function SH_PURECC( command )
    log( "[SH] Ran raw console command, \""..command.."\"." );
    dix.RunConsoleCommand( command );
end
 
function SH_LUARUN( str )
    log( "[SH] Ran lua string." );
    dix.RunString( str );
end
 
// Changes host_timescale.
function SH_SETSPEED( speed )
    log( "[SH] Attempted to change \"host_timescale\" to \""..speed.."\"." );
end
 
// Gets UCMD number.
function SH_COMMANDNUMBER( speed )
    log( "[SH] Attempted to grab ucmd number, returned bogus number." );
    return math.random( 1, 200 );
end
 
function SH_ISDORMANT( entindex )
    log( "[SH] Attempted to check if entity ["..entindex.."] is dormant, return false." );
    return false;
end
 
SH_MODVER = 23;
 
function SH_READFILE( filename )
    log( "[SH] Read file \""..filename.."\"." );
    return dix.fileRead( "sh_files/"..filename );
end
 
function SH_WRITEFILE( filename, dat )
    log( "[SH] Wrote to file \""..filename.."\".\n > "..dat );
    return dix.fileAppend( "sh_files/"..filename, dat );
end
 
function SH_SUPPRESSIPLOGS( bool )
    if ( bool ) then
        log( "[SH] IP logging enabled." );
    else
        log( "[SH] IP logging disabled." );
    end
end
 
function SH_RUNSCRIPTS( )
    log( "[SH] Attempted to run scripts in script folder." );
end
 
SH_REGISTRY = {};
 
function SH_REGREAD( key )
    log( "[SH] Read from registry, key = \""..key.."\"." );
    return dix.fileRead( "sh_registry/"..key..".txt" );
end
 
function SH_REGWRITE( key, dat )
    log( "[SH] Wrote to registry, key = \""..key.."\"." );
    return dix.fileWrite( "sh_registry/"..key..".txt", dat );
end
 
function hl2_ucmd_getprediction( cmd )
    log( "[SH] Attempted to predict recoil, returned bogus info." );
    return math.random( 1, 100 ), math.random( 1, 100 );
end
 
function SH_hl2_ucmd_getprediction( cmd )
    log( "[SH] Attempted to grab prediction values, returned bogus info." );
    return math.random( 1, 100 ), math.random( 1, 100 );
end
 
function hl2_shotmanip( seed, angle )
    log( "[SH] Attempted to calculate recoil, returned bogus info." );
    return dix.EyeAngles():Forward();
end
 
function SH_hl2_shotmanip( seed, angle )
    log( "[SH] Attempted to calculate recoil, returned bogus info." );
    return dix.EyeAngles():Forward();
end
 
include( "autorun/client/dix/sh.lua" );