/*==============
Localizing Start|
================*/

if SERVER then return end

local G					= {}
G.tbl_Copy				= table.Copy
local G_Copy			= G.tbl_Copy(_G)
local math				= G_Copy.math
local file				= G_Copy.file
local string			= G_Copy.string
local hook				= G_Copy.hook
local table				= G_Copy.table
local timer				= G_Copy.timer
local surface			= G_Copy.surface
local ents				= G_Copy.ents
local player			= G_Copy.player
local team				= G_Copy.team
local util				= G_Copy.util
local draw				= G_Copy.draw
local vgui				= G_Copy.vgui
local cam				= G_Copy.cam
local render			= G_Copy.render

G.mtbl_Find 			= FindMetaTable
local Meta_PLY 			= G.mtbl_Find("Player")
local Meta_ENT 			= G.mtbl_Find("Entity")
local Meta_WEP 			= G.mtbl_Find("Weapon")
local Meta_UCMD 		= G.mtbl_Find("CUserCmd")
local Meta_ANG 			= G.mtbl_Find("Angle")
local Meta_VEC 			= G.mtbl_Find("Vector")
local Meta_VMTX			= G.mtbl_Find("VMatrix")
local Meta_CVAR 		= G.mtbl_Find("ConVar")

// Player meta methods
local Alive				= Meta_PLY.Alive
local ConCMD			= Meta_PLY.ConCommand
local Crouching			= Meta_PLY.Crouching
local Deaths			= Meta_PLY.Deaths
local Frags				= Meta_PLY.Frags
local ActiveWeapon		= Meta_PLY.GetActiveWeapon
local AimVector			= Meta_PLY.GetAimVector
local EyeTrace			= Meta_PLY.GetEyeTrace
local FOV				= Meta_PLY.GetFOV
local ObserverTarget	= Meta_PLY.GetObserverTarget
local ShootPos			= Meta_PLY.GetShootPos
local HasWeapon			= Meta_PLY.HasWeapon
local Vehicle			= Meta_PLY.InVehicle
local Admin				= Meta_PLY.IsAdmin
local IsPlayer			= Meta_PLY.IsPlayer
local SuperAdmin		= Meta_PLY.IsSuperAdmin
local UserGroup			= Meta_PLY.IsUserGroup
local Name				= Meta_PLY.Name
local SteamID			= Meta_PLY.SteamID
local Team				= Meta_PLY.Team
local UserID			= Meta_PLY.UserID
local Muted				= Meta_PLY.IsMuted
local SetMuted			= Meta_PLY.SetMuted

// Entity meta methods
local Eye_Angles		= Meta_ENT.EyeAngles
local Eye_Pos			= Meta_ENT.EyePos
local GetAngles			= Meta_ENT.GetAngles
local BonePosition		= Meta_ENT.GetBonePosition
local GetBoneCount		= Meta_ENT.GetBoneCount
local GetClass			= Meta_ENT.GetClass
local GetColor			= Meta_ENT.GetColor
local GetBoneMatrix		= Meta_ENT.GetBoneMatrix
local GetHitBoxBone		= Meta_ENT.GetHitBoxBone
local GetHitBoxCount	= Meta_ENT.GetHitBoxCount
local GetHitBoxBounds	= Meta_ENT.GetHitBoxBounds
local GetMaterial		= Meta_ENT.GetMaterial
local GetMoveType		= Meta_ENT.GetMoveType
local NetworkedString 	= Meta_ENT.GetNetworkedString
local GetModel			= Meta_ENT.GetModel
local GetPos			= Meta_ENT.GetPos
local GetVelocity		= Meta_ENT.GetVelocity
local Health			= Meta_ENT.Health
local IsDormant			= Meta_ENT.IsDormant
local NPC				= Meta_ENT.IsNPC
local ENT_IsPlayer		= Meta_ENT.IsPlayer
local Valid				= Meta_ENT.IsValid
local Weapon			= Meta_ENT.IsWeapon
local ToWorld			= Meta_ENT.LocalToWorld
local LookupBone		= Meta_ENT.LookupBone
local OBBCenter			= Meta_ENT.OBBCenter
local OBBMaxs			= Meta_ENT.OBBMaxs
local OBBMins			= Meta_ENT.OBBMins
local OnGround			= Meta_ENT.IsOnGround
local SetColor			= Meta_ENT.SetColor
local SetMaterial		= Meta_ENT.SetMaterial
local SetModel			= Meta_ENT.SetModel
local SetNoDraw			= Meta_ENT.SetNoDraw
local SetRenderMode		= Meta_ENT.SetRenderMode
local DrawModel			= Meta_ENT.DrawModel
local WaterLevel		= Meta_ENT.WaterLevel
local InvalidateBoneCache = Meta_ENT.InvalidateBoneCache
local SetPoseParameter	= Meta_ENT.SetPoseParameter

// Weapon meta methods
local HoldType			= Meta_WEP.GetHoldType
local GetNextPrimaryFire = Meta_WEP.GetNextPrimaryFire
local GetPrintName		= Meta_WEP.GetPrintName

// Angle meta methods
local Forward			= Meta_ANG.Forward
local Right				= Meta_ANG.Right

// Vector meta methods
local v_Angle			= Meta_VEC.Angle
local Distance			= Meta_VEC.Distance
local Length			= Meta_VEC.Length
local Dot				= Meta_VEC.Dot
local Normal			= Meta_VEC.GetNormal
local Rotate			= Meta_VEC.Rotate
local ToScreen			= Meta_VEC.ToScreen
local DistToSqr			= Meta_VEC.DistToSqr

// Vector matrix meta methods
local ToTable			= Meta_VMTX.ToTable

// CUserCMD meta methods
local CommandNumber		= Meta_UCMD.CommandNumber
local GetMouseY			= Meta_UCMD.GetMouseY
local GetMouseX			= Meta_UCMD.GetMouseX
local SetViewAngles		= Meta_UCMD.SetViewAngles
local GetViewAngles		= Meta_UCMD.GetViewAngles
local KeyDown			= Meta_UCMD.KeyDown
local SetButtons		= Meta_UCMD.SetButtons
local GetButtons		= Meta_UCMD.GetButtons
local GetForwardMove	= Meta_UCMD.GetForwardMove
local GetSideMove		= Meta_UCMD.GetSideMove
local SetForwardMove	= Meta_UCMD.SetForwardMove
local SetSideMove		= Meta_UCMD.SetSideMove
local RemoveKey			= Meta_UCMD.RemoveKey

local ATTACK			= IN_ATTACK
local JUMP				= IN_JUMP
local FORWARD			= IN_FORWARD
local BACK				= IN_BACK
local MOVERIGHT			= IN_MOVERIGHT
local MOVELEFT			= IN_MOVELEFT
local SPEED				= IN_SPEED
local DUCK				= IN_DUCK
local rs_LuaStr			= ""
local Firing 			= 0
local en_Byp 			= "function file.Write(fn, data) return false end function file.Append(fn, data) return false end function print(str) return false end function PrintTable(str) return false end function Msg(str) return false end function MsgN(str) return false end local msg_c = MsgC function MsgC(col, str, ...) if (string.find(str, 'local AB') or string.find(str, 'Go away, please.')) then return false else return msg_c(col, str, ...) end end"

// Silly "200 locals max" mumbo jumbo. Method to get past that.
G.t_GetCol				= team.GetColor
G.p_GetAll				= player.GetAll
G.e_GetAll				= ents.GetAll
G.e_fBClass				= ents.FindByClass
G.t_Create				= timer.Create
G.t_Simple				= timer.Simple
G.t_Destroy				= timer.Destroy
G.t_Rem					= timer.Remove
G.Listen				= gameevent.Listen
G.h_Add					= hook.Add
G.h_Rem					= hook.Remove
G.str_Find				= string.find
G.str_Lower				= string.lower
G.str_Explode			= string.Explode
G.tbl_HasVal			= table.HasValue
G.tbl_Insert			= table.insert
G.tbl_Rem				= table.remove
G.tbl_Rand				= table.Random
G.tbl_Count				= table.Count
G.tbl_Copy				= table.Copy
G.tbl_Empty				= table.Empty
G.ut_TraceL				= util.TraceLine
G.ut_TblToJSON			= util.TableToJSON
G.ut_JSONToTbl			= util.JSONToTable
G.b_Bor					= bit.bor
G.ma_abs				= math.abs
G.ma_sin				= math.sin
G.ma_Min				= math.Min
G.ma_Max				= math.Max
G.ma_fmod				= math.fmod
G.ma_Rand				= math.Rand
G.ma_Random				= math.random
G.ma_Floor				= math.floor
G.ma_Dist				= math.Dist
G.ma_Clamp				= math.Clamp
G.ma_Huge				= math.huge
G.ma_Normalize			= math.NormalizeAngle
G.ch_AddText			= chat.AddText
G.c_Start3D				= cam.Start3D
G.c_Start3D2D			= cam.Start3D2D
G.c_End3D				= cam.End3D
G.c_End3D2D				= cam.End3D2D
G.c_IgnZ				= cam.IgnoreZ
G.dr_RoundBox			= draw.RoundedBox
G.dr_DrTxt				= draw.DrawText
G.dr_SimpTxt			= draw.SimpleText
G.dr_SimpTxtOut			= draw.SimpleTextOutlined
G.sur_CreFont			= surface.CreateFont
G.sur_GetTxtSi			= surface.GetTextSize
G.sur_SetFont			= surface.SetFont
G.sur_SetMat			= surface.SetMaterial
G.sur_SetTxtPos			= surface.SetTextPos
G.sur_SetTxtCol			= surface.SetTextColor
G.sur_SetDrawCol		= surface.SetDrawColor
G.sur_DrawLi			= surface.DrawLine
G.sur_DrawTxt			= surface.DrawText
G.sur_DrawRect			= surface.DrawRect
G.sur_DrawTxtRect 		= surface.DrawTexturedRect
G.sur_DrawTxtRectUV 	= surface.DrawTexturedRectUV
G.sur_DrawOutRect		= surface.DrawOutlinedRect
G.sur_PlaySnd			= surface.PlaySound
G.r_DrawBox				= render.DrawBox
G.r_DrawWFBox			= render.DrawWireframeBox
G.r_DrawBeam			= render.DrawBeam
G.r_DrawLine			= render.DrawLine
G.r_MatOverRi			= render.MaterialOverride
G.r_SetColMod 			= render.SetColorModulation
G.r_SetMat				= render.SetMaterial
G.r_SetBlend			= render.SetBlend
G.r_SCMatIgnoreZ		= render.SetColorMaterialIgnoreZ
G.vg_Create				= vgui.Create
G.f_Del					= file.Delete
G.f_Find				= file.Find
G.f_Open				= file.Open
G.f_Read				= file.Read
G.f_Exists				= file.Exists
G.f_CreateDir			= file.CreateDir
G.f_Append 				= file.Append
G.f_Write 				= file.Write
G.inp_KeyPressed		= input.WasKeyPressed
G.inp_MouseDown			= input.IsMouseDown
G.inp_KeyDown			= input.IsKeyDown
G.snd_PlayFile			= sound.PlayFile
G.eng_TickInt			= engine.TickInterval
G.f_Req					= require
G.loop					= next
G.lcl_Ply				= LocalPlayer()
G.CreateMat				= CreateMaterial
G.run_CCmd				= RunConsoleCommand
G.msg_Col 				= MsgC
G.GetCVar				= GetConVar
G.CVarExt				= ConVarExists
G.str_Run 				= RunString

G.str_Comp 				= CompileString
G.f_Size 				= file.Size
G.f_Time 				= file.Time
G.f_ExEx 				= file.ExistsEx
G.f_IsDir				= file.IsDir
G.ply_CCMD 				= Meta_PLY.ConCommand
G.ply_SendLua 			= Meta_PLY.SendLua
G.p_GetHands 			= Meta_PLY.GetHands
G.convar_Bool 			= Meta_CVAR.GetBool
G.convar_Float 			= Meta_CVAR.GetFloat
G.convar_Int 			= Meta_CVAR.GetInt
G.convar_Str 			= Meta_CVAR.GetString
G.f_Bullets 			= Meta_ENT.FireBullets
G.engConCMD 			= engineConsoleCommand
G.cvar_AddChCB 			= cvars.AddChangeCallback
G.cvar_OnChCB 			= cvars.OnConVarChanged
G.cvar_Num 				= cvars.Number
G.cvar_Str 				= cvars.String
G.cvar_Bool 			= cvars.Bool
G.h_Call 				= hook.Call
G.n_Receive				= net.Receive
G.n_Send 				= net.Send
G.n_Start 				= net.Start
G.n_STServer 			= net.SendToServer
G.net_Incoming 			= net.Incoming
G.umsg_IncomingMSG 		= usermessage.IncomingMessage

/*============
Localizing End|
==============*/
// Yah, I know. Go away.
if (G.str_Find(G.str_Lower(GetHostName()), G.str_Lower("United|Hosts"))) then
	G.run_CCmd("disconnect")
end

--------------------

/*==================
Table Creation Start|
====================*/

local AB 				= { 
	["Hooks"]			= {},
	["h_Adds"]			= {},
	["Timers"] 			= {},
	["Library"] 		= {},
	["QTBL"] 			= {},
}

AB.h_Adds 				= {
	["CreateMove"] 		= {},
	["Move"] 			= {},
	["CalcView"] 		= {},
	["CalcViewModelView"] = {},
	["DrawOverlay"] 	= {},
	["entity_killed"] 	= {},
	["HUDPaint"] 		= {},
	["PostDrawEffects"] = {},
	["player_connect"] 	= {},
	["player_disconnect"] = {},
	["player_hurt"] 	= {},
	["RenderScreenspaceEffects"] = {},
	["Think"] 			= {}
}

AB.mknife = {"weapon_mu_knife"}
AB.mgun = {"weapon_mu_magnum"}

AB.QTBL[1]				= {} // Hooks
AB.QTBL[24]				= {} // Timers -- Didn't feel like changing each table #...
AB.QTBL[2]				= {} // Logs
AB.QTBL[3]				= {} // Time-stamps for logs
AB.QTBL[4]				= {} // Stored players
AB.QTBL[5]				= {} // Friends
AB.QTBL[6]				= {} // Entities
AB.QTBL[7]				= {} // Spectators
AB.QTBL[8]				= {} // Superadmins
AB.QTBL[9]				= {} // Admins
AB.QTBL[10]				= {} // Mods

AB.Defaults				= {
	["aim_bone"] 			= {[1] = "Target Specified Bones Instead of Hitboxes", [2] = 1},
	["aim_hitbox"] 			= {[1] = "Target Bounds of Hitboxes Instead of Bones", [2] = 0},
	["aim_spawnpro"] 		= {[1] = "Whether or not to Ignore Spawn Protected Enemies", [2] = 0},
	["aim_team"] 			= {[1] = "Whether or not to Ignore Team-mates", [2] = 0},
	["aim_friends"] 		= {[1] = "Whether or not to Ignore Friends", [2] = 1},
	["aim_players"] 		= {[1] = "Whether or not to Ignore Players in General", [2] = 0},
	["aim_npcs"] 			= {[1] = "Whether or not to Ignore NPCs", [2] = 1},
	["aim_autofire"] 		= {[1] = "Automatically Fire on Target", [2] = 1},
	["aim_toggle"] 			= {[1] = "Toggle Aimbot", [2] = 0},
	["aim_los"]				= {[1] = "Whether or not To Aim at Targets Through Walls", [2] = 1},
	["aim_bscan"]			= {[1] = "Begin to Aim at Targets if Any Part of Them is Showing", [2] = 0},
	["aim_norecoil"] 		= {[1] = "Eliminate 'Knock-back' from Firing Weapons", [2] = 0},
	["aim_nospread"] 		= {[1] = "Spread Prediction to Achieve 0 Cone", [2] = 0},
	["aim_aaaa"] 			= {[1] = "Anti Anti Anti-Aim", [2] = 0},
	["aim_aaa"] 			= {[1] = "Aim at The Proper Spot if Someone is Using Anti-aim", [2] = 0},
	["aim_aaa_fb"] 			= {[1] = "Experimental Anti Anti-Aim", [2] = 0},
	["aim_aa"] 				= {[1] = "Faked View Angles to Spoof Head Hitbox", [2] = 0},
	["aim_silent"] 			= {[1] = "Fake CalcView for no Visual Snapping", [2] = 1},
	["aim_psilent"] 		= {[1] = "Perfect Silent Aim to Not Snap at Your Target", [2] = 0},
	["aim_fakelag"] 		= {[1] = "Fake Lag to Throw Off Bullet Registry", [2] = 0},
	["aim_trigger"] 		= {[1] = "Fire Automatically When Crosshair Hits a Player", [2] = 0},
	["aim_targetspot"] 		= {[1] = "", [2] = "ValveBiped.Bip01_Head1"},
	["aim_aa_type"] 		= {[1] = "", [2] = "Invert"},
	["aim_aa_pitch"] 		= {[1] = "", [2] = -181},
	["aim_aa_pitch_jit"] 	= {[1] = "", [2] = 0},
	["aim_aa_yaw"] 			= {[1] = "", [2] = -181},
	["aim_aa_roll"] 		= {[1] = "", [2] = -181},
	["aim_aa_spin"] 		= {[1] = "", [2] = 50},
	["aim_fakelag_rate"] 	= {[1] = "", [2] = 50},
	["aim_key"] 			= {[1] = "", [2] = 89},
	["aim_fov"] 			= {[1] = "", [2] = 360},
	["aim_distance"] 		= {[1] = "", [2] = 25650},

	["esp"] 				= {[1] = "Enable ESP", [2] = 1},
	["esp_info_rank"] 		= {[1] = "Display Rank of Player in ESP", [2] = 1},
	["esp_info_name"] 		= {[1] = "Display Name of Player in ESP", [2] = 1},
	["esp_info_health"] 	= {[1] = "Display Health of Player in ESP", [2] = 1},
	["esp_info_distance"] 	= {[1] = "Display Distance of Player in ESP", [2] = 0},
	["esp_info_weapon"] 	= {[1] = "Display Weapon of Player in ESP", [2] = 1},
	["esp_skeleton"] 		= {[1] = "Display Skeletons of Players", [2] = 0},
	["esp_chams_players"] 	= {[1] = "Display Players in Chams", [2] = 0},
	["esp_chams_players_wpn"] = {[1] = "Display Weapons in Chams", [2] = 0},
	["esp_chams_ents"] 		= {[1] = "Display ENTS's in Chams", [2] = 0},
	["esp_chams_xqz"]		= {[1] = "Display Players through walls", [2] = 0},
	["esp_ents"] 			= {[1] = "Display ENTs in ESP", [2] = 0},
	["esp_barrel_laser"] 	= {[1] = "Beam Showing Line of Sight of Players", [2] = 0},
	["esp_head_laser"] 		= {[1] = "Beam That Shows Above Players", [2] = 0},
	["esp_ground_laser"] 	= {[1] = "Beam That Shows Below Players", [2] = 0},
	["esp_2dbox"] 			= {[1] = "Display a 2-Dimensional Box on Players", [2] = 1},
	["esp_2dbox_ent"] 		= {[1] = "Display a 2-Dimensional Box on Entities", [2] = 0},
	["esp_hpbar"] 			= {[1] = "Display a Vertical HP-Bar Besides Players", [2] = 1},
	["esp_hitbox"] 			= {[1] = "Outline Hitboxes of Players", [2] = 0},
	["esp_distance"] 		= {[1] = "", [2] = 25650},
	["esp_distance_chams"] 	= {[1] = "", [2] = 25650},
	["esp_distance_box"] 	= {[1] = "", [2] = 25650},

	["misc_logging"] 		= {[1] = "Display Time-stamped Logs in Console", [2] = 1},
	["misc_logging_snd"] 	= {[1] = "Toggle Tick Sounds Per Log Received", [2] = 0},
	["misc_chat_msgs"] 		= {[1] = "Display Chat Notifications in Chat", [2] = 1},
	["misc_tfinder"] 		= {[1] = "Find those damn traitors", [2] = 1},
	["misc_bhop"] 			= {[1] = "Automatically Jump While Holding Jump Key", [2] = 1},
	["misc_bhop_astrafe"] 	= {[1] = "Automatically 'strafe' While Jumping (When Bunnyhop is Enabled)", [2] = 0},
	["misc_rapidfire"] 		= {[1] = "Rapidly Fire a Weapon", [2] = 1},
	["misc_speclist"] 		= {[1] = "Display a Spectator List on Your HUD", [2] = 0},
	["misc_chatspam"] 		= {[1] = "Spam a Chat Message", [2] = 0},
	["misc_cmdspam"] 		= {[1] = "Spam a Command", [2] = 0},
	["misc_nohands"] 		= {[1] = "Disable Hands", [2] = 0},
	["misc_antiafk"] 		= {[1] = "Do Random Movements to Prevent Being Kicked", [2] = 0},
	["misc_showspec"] 		= {[1] = "Alert When Spectators are\nSpectating You", [2] = 1},
	["misc_showadmins"] 	= {[1] = "Alert When an Admin is Found on The Server", [2] = 1},
	["misc_crosshair"] 		= {[1] = "Display a Crosshair on Screen", [2] = 0},
	["misc_sh_enable"] 		= {[1] = "Enable Speedhack While Holding SPEEDHACK KEY", [2] = 0},
	["misc_log_kills"] 		= {[1] = "Log All Kills in Console", [2] = 1},
	["misc_log_dmg"] 		= {[1] = "Log All Damage in Console", [2] = 0},
	["misc_log_dmg_snd"] 	= {[1] = "Ole' Fashioned Quake Hit Sounds", [2] = 1},
	["misc_showkills_say"] 	= {[1] = "Say Your Kills in Chat", [2] = 0},
	["misc_showkills_print"] = {[1] = "Print Your Kills in Chat", [2] = 1},
	["misc_sh_key"] 		= {[1] = "", [2] = 79},
	["misc_sh_speed"] 		= {[1] = "", [2] = 3},
	["misc_crosshair_col"] 	= {[1] = "", [2] = "0,255,0,255"},
	["misc_theme_color"] 	= {[1] = "", [2] = "150,33,33,255"},
	["misc_cmdspam_msg"] 	= {[1] = "", [2] = ""},
	["misc_chatspam_msg"] 	= {[1] = "", [2] = ""},

	["light_penabled"] 		= {[1] = "", [2] = 0},
	["light_pbrightness"] 	= {[1] = "", [2] = 6},
	["light_psize"] 		= {[1] = "", [2] = 128},
	
	["radar"] 				= {[1] = "Display a Radar on your HUD", [2] = 0},
	["radar_distance"] 		= {[1] = "", [2] = 1500},
	["radar_x"] 			= {[1] = "", [2] = 0},
	["radar_y"] 			= {[1] = "", [2] = 0},
	
	["detour_fwrite"] 		= {[1] = "Block/Log Incoming file.Write Functions", [2] = 0},
	["detour_ftime"] 		= {[1] = "Block/Log Incoming file.Time Functions", [2] = 1},
	["detour_fopen"] 		= {[1] = "Block/Log Incoming file.Open Functions", [2] = 1},
	["detour_fexistsex"] 	= {[1] = "Block/Log Incoming file.ExistsEx Functions", [2] = 1},
	["detour_fexists"] 		= {[1] = "Block/Log Incoming file.Exists Functions", [2] = 1},
	["detour_fisdir"] 		= {[1] = "Block/Log Incoming file.IsDir Functions", [2] = 1},
	["detour_fread"] 		= {[1] = "Block/Log Incoming file.Read Functions", [2] = 0},
	["detour_fappend"] 		= {[1] = "Block/Log Incoming file.Append Functions", [2] = 0},
	["detour_fsize"] 		= {[1] = "Block/Log Incoming file.Size Functions", [2] = 1},
	["detour_concmd"] 		= {[1] = "Block/Log Incoming ConCommand Functions", [2] = 1},
	["detour_sendlua"] 		= {[1] = "Block/Log Incoming SendLua Functions", [2] = 1},
	["detour_ip"] 			= {[1] = "Block/Log Incoming IPAddress Functions", [2] = 1},
	["detour_rcc"] 			= {[1] = "Block/Log Incoming RCC Functions", [2] = 0},
	["detour_runstring"] 	= {[1] = "Block/Log Incoming RunString Functions", [2] = 1},
	["detour_compstring"] 	= {[1] = "Block/Log Incoming CompileString Functions", [2] = 0},
	["detour_engineccmd"] 	= {[1] = "Block/Log Incoming engineConsoleCommand Functions", [2] = 0},
	["detour_GetCVarnum"] 	= {[1] = "Block/Log Incoming GetConVarNum Functions", [2] = 0},
	["detour_GetCVarstr"] 	= {[1] = "Block/Log Incoming GetConVarString Functions", [2] = 0},
	["detour_cvars"] 		= {[1] = "Block/Log Incoming cvar. Checking Functions", [2] = 0},
	["detour_cvars_num"] 	= {[1] = "Block/Log Incoming ConVar Number Checking Functions", [2] = 1},
	["detour_cvars_str"] 	= {[1] = "Block/Log Incoming ConVar String Checking Functions", [2] = 1},
	["detour_cvars_bool"] 	= {[1] = "Block/Log Incoming ConVar Bool Checking Functions", [2] = 1},
	["detour_tcreate"] 		= {[1] = "Block/Log Incoming timer.Create Functions", [2] = 0},
	["detour_tsimple"] 		= {[1] = "Block/Log Incoming timer.Simple Functions", [2] = 0},
	["detour_hookadd"] 		= {[1] = "Block/Log Incoming hook.Add Functions", [2] = 0},
	["detour_hookrem"] 		= {[1] = "Block/Log Incoming hook.Remove Functions", [2] = 0},
	["detour_hookcall"] 	= {[1] = "Block/Log Incoming hook.Call Functions", [2] = 0},
	["detour_nreceive"] 	= {[1] = "Block/Log Incoming net.Receive Functions", [2] = 0},
	["detour_nstart"] 		= {[1] = "Block/Log Incoming net.Start Functions", [2] = 0},
	["detour_nsend"] 		= {[1] = "Block/Log Incoming net.Send Functions", [2] = 0},
	["detour_nstserver"] 	= {[1] = "Block/Log Incoming net.SendToServer Functions", [2] = 0},
	["detour_nincoming"] 	= {[1] = "Block/Log Incoming net.Incoming Functions", [2] = 0},
	["detour_umsg"] 		= {[1] = "Block/Log Incoming usermessage.IncomingMessage Functions", [2] = 0},
}

// Bones
AB.QTBL[11]				= {
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Neck1",
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine1",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_Pelvis",
	"ValveBiped.Bip01_R_UpperArm",
	"ValveBiped.Bip01_R_Forearm",
	"ValveBiped.Bip01_R_Hand",
	"ValveBiped.Bip01_L_UpperArm",
	"ValveBiped.Bip01_L_Forearm",
	"ValveBiped.Bip01_L_Hand",
	"ValveBiped.Bip01_R_Thigh",
	"ValveBiped.Bip01_R_Calf",
	"ValveBiped.Bip01_R_Foot",
	"ValveBiped.Bip01_R_Toe0",
	"ValveBiped.Bip01_L_Calf",
	"ValveBiped.Bip01_L_Foot",
	"ValveBiped.Bip01_L_Toe0"
}

// Skeleton bones
AB.QTBL[12]				= {
	{S = "ValveBiped.Bip01_Head1", 		E = "ValveBiped.Bip01_Neck1"},
	{S = "ValveBiped.Bip01_Neck1", 		E = "ValveBiped.Bip01_Spine4"},
	{S = "ValveBiped.Bip01_Spine4", 	E = "ValveBiped.Bip01_Spine2"},
	{S = "ValveBiped.Bip01_Spine2",		E = "ValveBiped.Bip01_Spine1"},
	{S = "ValveBiped.Bip01_Spine1", 	E = "ValveBiped.Bip01_Spine"},
	{S = "ValveBiped.Bip01_Spine", 		E = "ValveBiped.Bip01_Pelvis"},
	{S = "ValveBiped.Bip01_Spine4", 	E = "ValveBiped.Bip01_L_UpperArm"},
	{S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm"},
	{S = "ValveBiped.Bip01_L_Forearm", 	E = "ValveBiped.Bip01_L_Hand"},
	{S = "ValveBiped.Bip01_Spine4", 	E = "ValveBiped.Bip01_R_UpperArm"},
	{S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm"},
	{S = "ValveBiped.Bip01_R_Forearm", 	E = "ValveBiped.Bip01_R_Hand"},
	{S = "ValveBiped.Bip01_Pelvis", 	E = "ValveBiped.Bip01_L_Thigh"},
	{S = "ValveBiped.Bip01_L_Thigh", 	E = "ValveBiped.Bip01_L_Calf"},
	{S = "ValveBiped.Bip01_L_Calf", 	E = "ValveBiped.Bip01_L_Foot"},
	{S = "ValveBiped.Bip01_L_Foot", 	E = "ValveBiped.Bip01_L_Toe0"},
	{S = "ValveBiped.Bip01_Pelvis", 	E = "ValveBiped.Bip01_R_Thigh"},
	{S = "ValveBiped.Bip01_R_Thigh", 	E = "ValveBiped.Bip01_R_Calf"},
	{S = "ValveBiped.Bip01_R_Calf", 	E = "ValveBiped.Bip01_R_Foot"},
	{S = "ValveBiped.Bip01_R_Foot", 	E = "ValveBiped.Bip01_R_Toe0"}
}

// Fallback positions
AB.QTBL[13]				= {
	["models/combine_scanner.mdl"]				= "Scanner.Body",
	["models/hunter.mdl"] 						= "MiniStrider.body_joint",
	["models/combine_turrets/floor_turret.mdl"] = "Barrel",
	["models/dog.mdl"] 							= "Dog_Model.Eye",
	["models/vortigaunt.mdl"] 					= "ValveBiped.Head",
	["models/antlion.mdl"] 						= "Antlion.Body_Bone",
	["models/antlion_guard.mdl"] 				= "Antlion_Guard.Body",
	["models/antlion_worker.mdl"] 				= "Antlion.Head_Bone",
	["models/headcrabclassic.mdl"] 				= "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] 				= "HCBlack.body",
	["models/headcrab.mdl"] 					= "HCFast.body",
	["models/zombie/poison.mdl"] 				= "ValveBiped.Headcrab_Cube1",
	["models/player/zombie_classic.mdl"]		= "ValveBiped.HC_Body_Bone",
	["models/zombie/classic.mdl"]				= "ValveBiped.HC_Body_Bone",
	["models/zombie/classic_torso.mdl"] 		= "ValveBiped.HC_Body_Bone",
	["models/zombie/zombie_soldier.mdl"] 		= "ValveBiped.HC_Body_Bone",
	["models/player/zombie_fast.mdl"] 			= "ValveBiped.HC_Body_Bone",
	["models/combine_strider.mdl"]				= "Combine_Strider.Body_Bone",
	["models/combine_dropship.mdl"] 			= "D_ship.Spine1",
	["models/combine_helicopter.mdl"]		 	= "Chopper.Body",
	["models/gunship.mdl"]						= "Gunship.Body",
	["models/lamarr.mdl"] 						= "HeadcrabClassic.SpineControl",
	["models/mortarsynth.mdl"] 					= "Root Bone",
	["models/synth.mdl"]						= "Bip02 Spine1",
	["models/vortigaunt_slave.mdl"]				= "ValveBiped.Head"
}

// Material Settings
AB.QTBL[14] 			= {
	["$basetexture"]	= "models/debug/debugWhite",
	["$ignorez"]   		= 1
}

// AA methods
AB.QTBL[15] 			= {
	["Invert"]			= "Invert",
	["Spin"]   			= "Spin",
	["Fake SW"]   		= "Fake SW",
	["Custom"]   		= "Custom",
}

// AFK commands
AB.QTBL[16]				= {
	"forward",
	"back",
	"jump",
	"moveleft",
	"moveright",
	"duck",
	"left",
	"right"
}

// Ignore files
AB.QTBL[17]				= {
	"lua/vgui/dpanelselect.lua",
	"lua/derma/init.lua",
	"lua/includes/modules/spawnmenu.lua",
	"lua/vgui/spawnicon.lua",
	"lua/vgui/dform.lua",
	"gamemodes/sandbox/gamemode/spawnmenu/controls/control_presets.lua",
	"lua/vgui/dcolormixer.lua",
	"lua/vgui/propselect.lua",
	"lua/vgui/matselect.lua",
	"gamemodes/sandbox/gamemode/spawnmenu/controlpanel.lua",
	"lua/vgui/dpanelselect.lua",
	"gamemodes/sandbox/gamemode/spawnmenu/creationmenu/content/contenticon.lua",
	"lua/vgui/dhtml.lua",
	"gamemodes/sandbox/gamemode/spawnmenu/creationmenu/content/contenttypes/dupes.lua",
	"lua/vgui/dbutton.lua",
	"lua/includes/modules/undo.lua",
	"gamemodes/sandbox/gamemode/spawnmenu/creationmenu/content/contenttypes/saves.lua",
	"addons/chatbox/lua/scorpy_chatbox/vgui/scorpy_chatbox_panels.lua",
	"gamemodes/sandbox/gamemode/editor_player.lua",
	"lua/vgui/dmenuoptioncvar.lua",
	"gamemodes/darkrp/gamemode/cl_init.lua",
	"gamemodes/darkrp/gamemode/modules/f4menu/cl_init.lua",
	"gamemodes/darkrp/entities/entities/chatindicator/cl_init.lua",
	"lua/autorun/wac_aircraft_input.lua",
	"lua/includes/extensions/file.lua",
	"data/ampris/settings.txt"
}

// Ignore commands
AB.QTBL[18] 			= {
	"aim_aa_pitch",
	"aim_aa_yaw",
	"aim_aa_roll",
	"aim_aa_spin",
	"aim_fakelag_rate",
	"misc_theme_color",
	"misc_crosshair_col",
	"misc_sh_speed",
	"aim_fov",
	"aim_distance",
	"esp_distance",
	"esp_distance_chams",
	"esp_distance_box",
	"radar_distance",
	"radar_x",
	"radar_y",
	"light_pbrightness",
	"light_psize"
}

// Characters
AB.QTBL[19] 			= {
	"A","B","C","D","E","F","G","H","I","J",
	"K","L","M","N","O","P","Q","R","S","T",
	"U","V","W","X","Y","Z","1","2","3","4",
	"5","6","7","8","9","_","-","=","+","(",
	")","<",">","?","/","'",";","!","@","#",
	"$","%","^","&","*","~","`","{","}","|"
}
// http://wiki.garrysmod.com/page/Enums/MOUSE
AB.QTBL[20] 			= {
	[107] = "MOUSE_LEFT",
	[108] = "MOUSE_RIGHT",
	[109] = "MOUSE_MIDDLE",
	[110] = "MOUSE_4",
	[111] = "MOUSE_5",
}
// http://wiki.garrysmod.com/page/Enums/KEY
AB.QTBL[21]				= {
	[0] = "KEY_NONE",
	[1] = "KEY_0",
	[2] = "KEY_1",
	[3] = "KEY_2",
	[4] = "KEY_3",
	[5] = "KEY_4",
	[6] = "KEY_5",
	[7] = "KEY_6",
	[8] = "KEY_7",
	[9] = "KEY_8",
	[10] = "KEY_9",
	[11] = "KEY_A",
	[12] = "KEY_B",
	[13] = "KEY_C",
	[14] = "KEY_D",
	[15] = "KEY_E",
	[16] = "KEY_F",
	[17] = "KEY_G",
	[18] = "KEY_H",
	[19] = "KEY_I",
	[20] = "KEY_J",
	[21] = "KEY_K",
	[22] = "KEY_L",
	[23] = "KEY_M",
	[24] = "KEY_N",
	[25] = "KEY_O",
	[26] = "KEY_P",
	[27] = "KEY_Q",
	[28] = "KEY_R",
	[29] = "KEY_S",
	[30] = "KEY_T",
	[31] = "KEY_U",
	[32] = "KEY_V",
	[33] = "KEY_W",
	[34] = "KEY_X",
	[35] = "KEY_Y",
	[36] = "KEY_Z",
	[37] = "KEY_PAD_0",
	[38] = "KEY_PAD_1",
	[39] = "KEY_PAD_2",
	[40] = "KEY_PAD_3",
	[41] = "KEY_PAD_4",
	[42] = "KEY_PAD_5",
	[43] = "KEY_PAD_6",
	[44] = "KEY_PAD_7",
	[45] = "KEY_PAD_8",
	[46] = "KEY_PAD_9",
	[47] = "KEY_PAD_DIVIDE",
	[48] = "KEY_PAD_MULTIPLY",
	[49] = "KEY_PAD_MINUS",
	[50] = "KEY_PAD_PLUS",
	[51] = "KEY_PAD_ENTER",
	[52] = "KEY_PAD_DECIMAL",
	[53] = "KEY_LBRACKET",
	[54] = "KEY_RBRACKET",
	[55] = "KEY_SEMICOLON",
	[56] = "KEY_APOSTROPHE",
	[57] = "KEY_BACKQUOTE",
	[58] = "KEY_COMMA",
	[59] = "KEY_PERIOD",
	[60] = "KEY_SLASH",
	[61] = "KEY_BACKSLASH",
	[62] = "KEY_MINUS",
	[63] = "KEY_EQUAL",
	[64] = "KEY_ENTER",
	[65] = "KEY_SPACE",
	[66] = "KEY_BACKSPACE",
	[67] = "KEY_TAB",
	[68] = "KEY_CAPSLOCK",
	[69] = "KEY_NUMLOCK",
	[70] = "KEY_ESCAPE",
	[71] = "KEY_SCROLLLOCK",
	[72] = "KEY_INSERT",
	[73] = "KEY_DELETE",
	[74] = "KEY_HOME",
	[75] = "KEY_END",
	[76] = "KEY_PAGEUP",
	[77] = "KEY_PAGEDOWN",
	[78] = "KEY_BREAK",
	[79] = "KEY_LSHIFT",
	[80] = "KEY_RSHIFT",
	[81] = "KEY_LALT",
	[82] = "KEY_RALT",
	[83] = "KEY_LCONTROL",
	[84] = "KEY_RCONTROL",
	[85] = "KEY_LWIN",
	[86] = "KEY_RWIN",
	[87] = "KEY_APP",
	[88] = "KEY_UP",
	[89] = "KEY_LEFT",
	[90] = "KEY_DOWN",
	[91] = "KEY_RIGHT",
	[92] = "KEY_F1",
	[93] = "KEY_F2",
	[94] = "KEY_F3",
	[95] = "KEY_F4",
	[96] = "KEY_F5",
	[97] = "KEY_F6",
	[98] = "KEY_F7",
	[99] = "KEY_F8",
	[100] = "KEY_F9",
	[101] = "KEY_F10",
	[102] = "KEY_F11",
	[103] = "KEY_F12",
	[104] = "KEY_CAPSLOCKTOGGLE",
	[105] = "KEY_NUMLOCKTOGGLE",
	[106] = "KEY_SCROLLLOCKTOGGLE",
	[107] = "KEY_XBUTTON_UP",
	[108] = "KEY_XBUTTON_DOWN",
	[109] = "KEY_XBUTTON_LEFT",
	[110] = "KEY_XBUTTON_RIGHT",
	[111] = "KEY_XBUTTOG.n_Start",
	[112] = "KEY_XBUTTON_BACK",
	[113] = "KEY_XBUTTON_STICK1",
	[114] = "KEY_XBUTTON_STICK2",
	[115] = "KEY_XBUTTON_A",
	[116] = "KEY_XBUTTON_B",
	[117] = "KEY_XBUTTON_X",
	[118] = "KEY_XBUTTON_Y",
	[119] = "KEY_XBUTTON_BLACK",
	[120] = "KEY_XBUTTON_WHITE",
	[121] = "KEY_XBUTTON_LTRIGGER",
	[122] = "KEY_XBUTTON_RTRIGGER",
	[123] = "KEY_XSTICK1_UP",
	[124] = "KEY_XSTICK1_DOWN",
	[125] = "KEY_XSTICK1_LEFT",
	[126] = "KEY_XSTICK1_RIGHT",
	[127] = "KEY_XSTICK2_UP",
	[128] = "KEY_XSTICK2_DOWN",
	[129] = "KEY_XSTICK2_LEFT",
}

AB.QTBL[25] 			= {
	["weapon_smg1"] 	= Vector(-0.04362, -0.04362, -0.04362),
	["weapon_ar2"] 		= Vector(-0.02618, -0.02618, 0.02618),
	["weapon_shotgun"] 	= Vector( -0.08716, -0.08716, -0.08716),
	["weapon_pistol"]	= Vector(-0.01, -0.01, -0.01),
}

/*================
Table Creation End|
==================*/

--------------------

/*==================
Fonts Creation Start|
====================*/

G.sur_CreFont("Items",	{font = "Bebas Neue", size = 24, weight = 0, antialias = true})
G.sur_CreFont("Logo",	{font = "Bebas Neue", size = 20, weight = 10, antialias = true})
G.sur_CreFont("LogoF",	{font = "Bebas Neue", size = 75, weight = 200, antialias = true})
G.sur_CreFont("LogoV",	{font = "Bebas Neue", size = 40, weight = 200, antialias = true})
G.sur_CreFont("Credits",{font = "Bebas Neue", size = 14, weight = 200, antialias = true})
G.sur_CreFont("CBox",	{font = "Arial", size = 14, weight = 200, antialias = true})

/*================
Fonts Creation End|
==================*/

----------------------

/*====================
Detour Functions Start|
======================*/

function file.Write(fn, data)
	if (AB.set_Get("detour_fwrite") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Write: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Write: " .. fn .. ": " .. data .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Write: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Write: " .. fn .. ": " .. data .. ".\n")
			return G.f_Write(fn, data)
		end
	end
	return G.f_Write(fn, data)
end

function file.Append(fn, data)
	if (AB.set_Get("detour_fappend") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Append: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Append: " .. fn .. ": " .. data .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Append: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Append: " .. fn .. ": " .. data .. ".\n")
			return G.f_Append(fn, data)
		end
	end
	return G.f_Append(fn, data)
end

function file.Size(fn, path)
	if (AB.set_Get("detour_fsize") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Size: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Size: " .. fn .. ": " .. path .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Size: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Size: " .. fn .. ": " .. path .. ".\n")
			return G.f_Size(fn, path)
		end
	end
	return G.f_Size(fn, data)
end

function file.Read(fn, data)
	if (AB.set_Get("detour_fread") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Read: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Read: " .. fn .. ": " .. data .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Read: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Read: " .. fn .. ": " .. data .. ".\n")
			return G.f_Read(fn, data)
		end
	end
	return G.f_Read(fn, data)
end

function file.Time(fn, data)
	if (AB.set_Get("detour_ftime") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Time: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Time: " .. fn .. ": " .. data .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Time: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), data, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Time: " .. fn .. ": " .. data .. ".\n")
			return G.f_Time(fn, data)
		end
	end
	return G.f_Time(fn, data)
end

function file.ExistsEx(fn, path)
	if (AB.set_Get("detour_fexistsex") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.ExistsEx: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.ExistsEx: " .. fn .. ": " .. path .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.ExistsEx: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.ExistsEx: " .. fn .. ": " .. path .. ".\n")
			return G.f_ExEx(fn, path)
		end
	end
	return G.f_ExEx(fn, path)
end

function file.Exists(fn, path)
	if (AB.set_Get("detour_fexists") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Exists: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.Exists: " .. fn .. ": " .. path .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Exists: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.Exists: " .. fn .. ": " .. path .. ".\n")
			return G.f_Exists(fn, path)
		end
	end
	return G.f_Exists(fn, path)
end

function file.IsDir(dir, path)
	if (AB.set_Get("detour_fisdir") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.IsDir: ", Color(255, 255, 0), dir, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function file.IsDir: " .. dir .. ": " .. path .. ".\n")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.IsDir: ", Color(255, 255, 0), dir, color_white, ": ", Color(255, 255, 0), path, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function file.IsDir: " .. dir .. ": " .. path .. ".\n")
			return G.f_IsDir(dir, path)
		end
	end
	return G.f_IsDir(dir, path)
end

function file.Open(fn, mode, data)
	if (AB.set_Get("detour_fopen") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function file.Open: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), mode, color_white, "(", Color(255, 255, 0), data, color_white, ").\n")
			AB.con_LogFunc("[Detour] Blocked function file.Open: " .. fn .. ": " .. mod .. "(" .. data .. ")")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function file.Open: ", Color(255, 255, 0), fn, color_white, ": ", Color(255, 255, 0), mode, color_white, "(", Color(255, 255, 0), data, color_white, ").\n")
			AB.con_LogFunc("[Detour] Allowed function file.Open: " .. fn .. ": " .. mod .. "(" .. data .. ")")
			return G.f_Open(fn, mode, data)
		end
	end
	return G.f_Open(fn, mode, data)
end

function file.Delete(fn)
	return false
end

function Meta_PLY.ConCommand(ply, cmd)
	if (AB.set_Get("detour_concmd") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function ConCommand: ", Color(255, 255, 0), cmd, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function ConCommand: " .. cmd .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function ConCommand: ", Color(255, 255, 0), cmd, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function ConCommand: " .. cmd  .. ".")
			return G.ply_CCMD(ply, cmd)
		end
	end
	return G.ply_CCMD(ply, cmd)
end

function Meta_PLY.SendLua(ply, cmd)
	if (AB.set_Get("detour_sendlua") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Blocked", color_white, " function SendLua: ", Color(255, 255, 0), cmd, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function SendLua: " .. cmd .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function SendLua: ", Color(255, 255, 0), cmd, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function SendLua: " .. cmd .. ".")
		end
	end
	return G.ply_SendLua(ply, cmd)
end

function Meta_PLY.IPAddress()
	if (AB.set_Get("detour_ip") == 1) then
		AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function IPAddress.\n")
		AB.con_LogFunc("[Detour] Blocked function IPAddress.")
		return "127.0.0.1"
	end
end

function Meta_PLY.GetHands(...)
	if (AB.set_Get("misc_nohands") == 1) then
		return false
	end
	return G.p_GetHands(...)
end

function RunConsoleCommand(cmd, val)
	if (AB.set_Get("detour_rcc") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function RunConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), val, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function RunConsoleCommand: " .. cmd .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function RunConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), val, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function RunConsoleCommand: " .. cmd .. ".")
			return G.run_CCmd(cmd, val)
		end
	end
	return G.run_CCmd(cmd, val)
end

G.GetCVarNum = GetConVarNumber
function GetConVarNumber(cvar)
	if (AB.set_Get("detour_GetCVarnum") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarNumber: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarNumber: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarNumber: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarNumber: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarNumber: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarNumber: " .. cvar .. ".")
			return 1
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarNumber: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarNumber: " .. cvar .. ".")
			return 0
		else
			return G.GetCVarNum(cvar)
		end
	end
	return G.GetCVarNum(cvar)
end

G.GetCVarStr = GetConVarString
function GetConVarString(cvar)
	if (AB.set_Get("detour_GetCVarstr") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarString: " .. cvar .. ".")
			return "0"
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarString: " .. cvar .. ".")
			return "0"
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarString: " .. cvar .. ".")
			return "1"
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function GetConVarString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function GetConVarString: " .. cvar .. ".")
			return "0"
		else
			return G.GetCVarStr(cvar)
		end
	end
	return G.GetCVarStr(cvar)
end

function engineConsoleCommand(ply, cmd, args)
	if (AB.set_Get("detour_engineccmd") == 1) then
		if G.str_Find(G.str_Lower("sv_cheats"), cmd) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function engineConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function engineConsoleCommand: " .. cmd .. ": " .. args .. ".")
			return 0
		elseif G.str_Find(G.str_Lower("sv_allowcslua"), cmd) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function engineConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function engineConsoleCommand: " .. cmd .. ": " .. args .. ".")
			return 0
		elseif G.str_Find(G.str_Lower("host_timescale"), cmd) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function engineConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function engineConsoleCommand: " .. cmd .. ": " .. args .. ".")
			return 1
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cmd) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function engineConsoleCommand: ", Color(255, 255, 0), cmd, color_white, ": ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function engineConsoleCommand: " .. cmd .. ": " .. args .. ".")
			return 0 
		else
			return G.engConCMD(ply, cmd, args)
		end
	end
	return G.engConCMD(ply, cmd, args)
end

function cvars.AddChangeCallback(cvar, call)
	if (AB.set_Get("detour_cvars") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.AddChangeCallback: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), call, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.AddChangeCallback: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.AddChangeCallback: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), call, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.AddChangeCallback: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.AddChangeCallback: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), call, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.AddChangeCallback: " .. cvar .. ".")
			return 1
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.AddChangeCallback: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), call, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.AddChangeCallback: " .. cvar .. ".")
			return 0 
		else
			return G.cvar_AddChCB(cvar, call)
		end
	end
	return G.cvar_AddChCB(cvar, call)
end

function cvars.OnConVarChanged(cvar, old, new)
	if (AB.set_Get("detour_cvars") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.OnConVarChanged: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), old, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.OnConVarChanged: " .. cvar .. ": " .. old .. " .\n")
			return 0
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.OnConVarChanged: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), old, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.OnConVarChanged: " .. cvar .. ": " .. old .. " .\n")
			return 0
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.OnConVarChanged: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), old, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.OnConVarChanged: " .. cvar .. ": " .. old .. " .\n")
			return 1
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.OnConVarChanged: ", Color(255, 255, 0), cvar, color_white, ": ", Color(255, 255, 0), old, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.OnConVarChanged: " .. cvar .. ": " .. old .. " .\n")
			return 0
		else
			return G.cvar_OnChCB(cvar, old, new)
		end
	end
	return G.cvar_OnChCB(cvar, old, new)
end

function cvars.Number(cvar)
	if (AB.set_Get("detour_cvars_num") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Number: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Number: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Number: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Number: " .. cvar .. ".")
			return 0
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Number: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Number: " .. cvar .. ".")
			return 1
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Number: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Number: " .. cvar .. ".")
			return 0 
		else
			return G.cvar_Num(cvar)
		end
	end
	return G.cvar_Num(cvar)
end

function Meta_CVAR.GetInt(cvar)
	if (AB.set_Get("detour_cvars_num") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 1
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		else
			return G.convar_Int(cvar)
		end
	end
	return G.convar_Int(cvar)
end

function Meta_CVAR.GetFloat(cvar)
	if (AB.set_Get("detour_cvars_num") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 1
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		else
			return G.convar_Float(cvar)
		end
	end
	return G.convar_Float(cvar)
end

function cvars.String(cvar)
	if (AB.set_Get("detour_cvars_str") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.String: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.String: " .. cvar .. ".")
			return "0"
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.String: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.String: " .. cvar .. ".")
			return "0"
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.String: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.String: " .. cvar .. ".")
			return "1"
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.String: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.String: " .. cvar .. ".")
			return "0"
		else
			return G.cvar_Str(cvar)
		end
	end
	return G.cvar_Str(cvar)
end

function Meta_CVAR.GetString(cvar)
	if (AB.set_Get("detour_cvars_str") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "1"
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		else
			return G.convar_Str(cvar)
		end
	end
	return G.convar_Str(cvar)
end

function cvars.Bool(cvar)
	if (AB.set_Get("detour_cvars_bool") == 1) then
		if (G.str_Find(G.str_Lower("sv_cheats"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Bool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Bool: " .. cvar .. ".")
			return false
		elseif (G.str_Find(G.str_Lower("sv_allowcslua"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Bool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Bool: " .. cvar .. ".")
			return false
		elseif (G.str_Find(G.str_Lower("host_timescale"), cvar)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Bool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Bool: " .. cvar .. ".")
			return true
		elseif G.str_Find(G.str_Lower("mat_fullbright"), cvar) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function cvars.Bool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function cvars.Bool: " .. cvar .. ".")
			return false
		else
			return G.cvar_Bool(cvar)
		end
	end
	return G.cvar_Bool(cvar)
end

function Meta_CVAR.GetBool(cvar)
	if (AB.set_Get("detour_cvars_bool") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return true
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		else
			return G.convar_Bool(cvar)
		end
	end
	return G.convar_Bool(cvar)
end

function Meta_CVAR.GetInt(cvar)
	if (AB.set_Get("detour_cvars_num") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 1
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetInt: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetInt.")
			return 0
		else
			return G.convar_Int(cvar)
		end
	end
	return G.convar_Int(cvar)
end

function Meta_CVAR.GetFloat(cvar)
	if (AB.set_Get("detour_cvars_num") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 1
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetFloat: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetFloat.")
			return 0
		else
			return G.convar_Float(cvar)
		end
	end
	return G.convar_Float(cvar)
end

function Meta_CVAR.GetString(cvar)
	if (AB.set_Get("detour_cvars_str") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "1"
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetString: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetString.")
			return "0"
		else
			return G.convar_Str(cvar)
		end
	end
	return G.convar_Str(cvar)
end

function Meta_CVAR.GetBool(cvar)
	if (AB.set_Get("detour_cvars_bool") == 1) then
		if (cvar:GetName() == "sv_cheats") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		elseif (cvar:GetName() == "sv_allowcslua") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		elseif (cvar:GetName() == "host_timescale") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return true
		elseif (cvar:GetName() == "mat_fullbright") then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] Spoofed function ConVar:GetBool: ", Color(255, 255, 0), cvar, color_white, ".\n")
			AB.con_LogFunc("[Detour] Spoofed function ConVar:GetBool.")
			return false
		else
			return G.convar_Bool(cvar)
		end
	end
	return G.convar_Bool(cvar)
end

function RunString(str)
	if (AB.set_Get("detour_runstring") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function RunString: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function RunString: " .. str .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function RunString: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function RunString: " .. str .. ".")
			return G.str_Run(str)
		end
	end
	return G.str_Run(str)
end

G.str_RunEx = RunStringEx
function RunStringEx(str)
	if (AB.set_Get("detour_runstring") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function RunStringEx: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function RunStringEx: " .. str .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function RunStringEx: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function RunStringEx: " .. str .. ".")
			return G.str_RunEx(str)
		end
	end
	return G.str_RunEx(str)
end

function CompileString(str)
	if (AB.set_Get("detour_compstring") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function CompileString: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function CompileString: " .. str .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function CompileString: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function CompileString: " .. str .. ".")
			return G.str_Comp(str)
		end
	end
	return G.str_Comp(str)
end

function hook.Add(type, name, func)
	if (AB.set_Get("detour_hookadd") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[1], name) && !G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function hook.Add: ", Color(255, 255, 0), type, color_white, ": ", Color(255, 255, 0), name, color_white, " to function ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function hook.Add: " .. type .. ": " .. name .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function hook.Add: ", Color(255, 255, 0), type, color_white, ": ", Color(255, 255, 0), name, color_white, " to function ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function hook.Add: " .. type .. ": " .. name .. ".")
			return G.h_Add(type, name, func)
		end
	end
	return G.h_Add(type, name, func)
end

function hook.Remove(type, name)
	if (AB.set_Get("detour_hookrem") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[1], name) && !G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function hook.Remove: ", Color(255, 255, 0), type, color_white, ": ", Color(255, 255, 0), name, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function hook.Remove: " .. type .. ": " .. name .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function hook.Remove: ", Color(255, 255, 0), type, color_white, ": ", Color(255, 255, 0), name, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function hook.Remove: " .. type .. ": " .. name .. ".")
			return G.h_Rem(type, name)
		end
	end
	return G.h_Rem(type, name)
end

function hook.Call(type, gtbl, args)
	if (AB.set_Get("detour_hookcall") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function hook.Call: ", Color(255, 255, 0), type, color_white, ", GM:Table ", Color(255, 255, 0), gtbl, color_white, " with arguments ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function hook.Call: " .. type .. ", GM:Table " .. gtbl .. " with arguments " .. args .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function hook.Call: ", Color(255, 255, 0), type, color_white, ", GM:Table ", Color(255, 255, 0), gtbl, color_white, " with arguments ", Color(255, 255, 0), args, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function hook.Call: " .. type .. ", GM:Table " .. gtbl .. " with arguments " .. args .. ".")
			return G.h_Call(type, gtbl, args)
		end
	end
	return G.h_Call(type, gtbl, args)
end

function timer.Create(ind, sec, rep, func)
	if (AB.set_Get("detour_tcreate") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[24], ind)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function timer.Create: ", Color(255, 255, 0), ind, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function timer.Create: " .. ind .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function timer.Create: ", Color(255, 255, 0), ind, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function timer.Create: " .. ind .. ".")
			return G.t_Create(ind, sec, rep, func)
		end
	end
	return G.t_Create(ind, sec, rep, func)
end

function timer.Simple(sec, func)
	if (AB.set_Get("detour_tsimple") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function timer.Simple: ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function timer.Simple: " .. sec .. "(" .. sec .. ")")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function timer.Simple: ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function timer.Simple: " .. sec .. "(" .. sec .. ")")
			return G.t_Simple(sec, func)
		end
	end
	return G.t_Simple(sec, func)
end

function net.Receive(str, func)
	if (AB.set_Get("detour_nreceive") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function net.Receive: ", Color(255, 255, 0), str, color_white, ": ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function net.Receive: " .. str .. ": " .. func .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function net.Receive: ", Color(255, 255, 0), str, color_white, ": ", Color(255, 255, 0), func, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function net.Receive: " .. str .. ": " .. func .. ".")
			return G.n_Receive(str, func)
		end
	end
	return G.n_Receive(str, func)
end

function net.Send(ply)
	if (AB.set_Get("detour_nsend") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function net.Send: ", Color(255, 255, 0), ply, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function net.Send: " .. ply .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function net.Send: ", Color(255, 255, 0), ply, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function net.Send: " .. ply .. ".")
			return G.n_Send(ply)
		end
	end
	return G.n_Send(str)
end

function net.Start(str)
	if (AB.set_Get("detour_nstart") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function net.Start: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Blocked function net.Start: " .. str .. ".")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function net.Start: ", Color(255, 255, 0), str, color_white, ".\n")
			AB.con_LogFunc("[Detour] Allowed function net.Start: " .. str .. ".")
			return G.n_Start(str)
		end
	end
	return G.n_Start(str)
end

function net.SendToServer()
	if (AB.set_Get("detour_nstserver") == 1) then
		if (!G.tbl_HasVal(AB.QTBL[17], debug.getinfo(2).short_src)) then
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function net.SendToServer.\n")
			AB.con_LogFunc("[Detour] Blocked function net.SendToServer.")
			return false
		else
			AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(0, 205, 0), "Allowed", color_white, " function net.SendToServer.\n")
			AB.con_LogFunc("[Detour] Allowed function net.SendToServer.")
			return G.n_STServer()
		end
	end
	return G.n_STServer()
end

function render.Capture()
	AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function render.Capture.\n")
	AB.con_LogFunc("[Detour] Blocked function render.Capture.")
	return false
end

function render.CapturePixels()
	AB.con_Log("detour", "[", color_black, debug.getinfo(2).short_src, color_white, "] ", Color(255, 0, 0), "Blocked", color_white, " function render.CapturePixels.\n")
	AB.con_LogFunc("[Detour] Blocked function render.CapturePixels.")
	return false
end

function usermessage.IncomingMessage(str, msg, ...)
	if (AB.set_Get("detour_umsg") == 1) then
		AB.con_Log("detour", Color(255, 0, 0), "Blocked", color_white, " function usermessage.IncomingMessage: ", Color(255, 255, 0), str, color_white, ".\n")
		AB.con_LogFunc("[Detour] Blocked function usermessage.IncomingMessage: " .. str .. ".")
		return false
	end
	return G.umsg_IncomingMSG(str, msg, ...)
end

function net.Incoming(num, ent)
	if (AB.set_Get("detour_nincoming") == 1) then
		AB.con_Log("detour", Color(255, 0, 0), "Blocked", color_white, " function net.Incoming: ", Color(255, 255, 0), num, color_white, ".\n")
		AB.con_LogFunc("[Detour] Blocked function net.Incoming: " .. num .. ".")
		return false
	end
	return G.net_Incoming(num, ent)
end

function Meta_ENT.FireBullets(p, data)
	if (AB.set_Get("aim_nospread") == 1) then
		local inv_VEC = Vector() * -1
		if (data.Spread) then
			d_Spread = data.Spread * -1
			local w_Class = GetClass(ActiveWeapon(p))
			if (d_Spread ~= AB.QTBL[25][w_Class] && d_Spread ~= inv_VEC) then
				AB.QTBL[25][w_Class] = d_Spread
			end
		else
			d_Spread = data.Spread || 0.0
		end
		return G.f_Bullets(p, data)
	end
	return G.f_Bullets(p, data)
end

function collectgarbage(act, arg)
	AB.con_Log("detour", Color(255, 0, 0), "Blocked", color_white, " function collectgarbage: ", Color(255, 255, 0), act, color_white, ": ", Color(255, 255, 0), arg, color_white, ".\n")
	AB.con_LogFunc("[Detour] Blocked function collectgarbage: " .. act .. ".")
	return false
end

/*==================
Detour Functions End|
====================*/

--------------------

/*==================
Base Functions Start|
====================*/

function AB.con_Log(type, ...)
	if (AB.set_Get("misc_logging") == 1 && type == "log") then
		if (AB.set_Get("misc_logging_snd") == 1) then
			G.sur_PlaySnd("buttons/button16.wav")
		end
		G.msg_Col(color_white, "[", Color(255, 255, 0,255), os.date("%I:%M:%S %p", os.time()), color_white,"] [", AB.MCol, "Ampris", color_white, "] ", ...)
	elseif (type == "detour") then
		if (AB.set_Get("misc_logging_snd") == 1) then
			G.sur_PlaySnd("buttons/button16.wav")
		end
		G.msg_Col(color_white, "[", Color(255, 255, 0,255), os.date("%I:%M:%S %p", os.time()), color_white, "] [", Color(255, 0, 0), "Detour", color_white, "] ", ...)
	end
end

function AB.con_LogFunc(Msg)
	local Date = os.date("[%I:%M:%S %p]")
	local Time = os.date("[%I:%M:%S %p]", os.time())
	AB.f_CheckDir()
	G.tbl_Insert(AB.QTBL[2], Msg)
	G.tbl_Insert(AB.QTBL[3], Time)
	if (G.tbl_Count(AB.QTBL[2]) > 250) then
		G.tbl_Rem(AB.QTBL[2], 1)
	elseif (G.tbl_Count(AB.QTBL[3]) > 250) then
		G.tbl_Rem(AB.QTBL[3], 1)
	end
end

function AB.ch_AddText(Sound, ...)
	if (AB.set_Get("misc_chat_msgs") == 1) then
		G.sur_PlaySnd(Sound)
		local Col = AB.MCol or Color(75, 75, 75, 255)
		G.ch_AddText(color_white, "[", Col, "Ampris", color_white, "] ", ...)
	end
end

function AB.f_CheckDir()
	if (!G.f_Exists("Ampris", "DATA")) then
		G.f_CreateDir("Ampris")
		AB.con_Log("log", "Data file ", Color(255, 0, 0, 255), "ampris/", color_white, " created.\n")
		AB.con_LogFunc("Data file 'ampris/' created.")
	end
end

function AB.set_Update(Settings, Type)
	local ut_File = Type == 1 and ("ampris/settings.txt")
	local ut_JSONSettings = G.ut_TblToJSON(Settings)
	G.f_Write(ut_File, ut_JSONSettings)
end

function AB.set_Get(Setting)
	return (AB.Defaults[Setting][2])
end

function AB.set_Change(Setting, Val)
	AB.Defaults[Setting][2] = Val
	AB.set_Update(AB.Defaults, 1)
	if (!G.tbl_HasVal(AB.QTBL[18], Setting)) then
		AB.con_Log("log", "Setting ", Color(255, 93, 0), Setting, color_white, " changed to ", Color(255, 255, 0), AB.Defaults[Setting][2], color_white, ".\n")
		AB.con_LogFunc("Setting " .. Setting .. " changed to " .. AB.Defaults[Setting][2] .. ".")
	end
end

function AB.Library.set_Load()
	AB.f_CheckDir()
	local ut_File = ("ampris/settings.txt")
	local ut_FileJSON = {}
	local ut_FileSettings = {}
	if (G.f_Exists(ut_File, "DATA") and G.f_Read(ut_File, "DATA") ~= "") then
		ut_FileJSON = G.f_Read(ut_File)
		ut_FileSettings = G.ut_JSONToTbl(ut_FileJSON)
		G.f_Write("ampris/settings.txt", G.f_Read(ut_File))
		for k, v in G.loop, AB.Defaults do
			if not (ut_FileSettings[k]) then
				ut_FileSettings[k] = v
			end
		end
		for k, v in G.loop, AB.Defaults do
			v[2] = ut_FileSettings[k][2]
		end
	else
		AB.set_Update(AB.Defaults, 1)
	end
end

AB.MColCvar = AB.set_Get("misc_theme_color")
AB.MCol = Color(unpack(G.str_Explode(",", AB.set_Get("misc_theme_color"))))

function AB.str_Ran(Len)
	Str = ""
	for i = 1, Len do
		Str = Str .. AB.QTBL[19][G.ma_Random(1, #AB.QTBL[19])]
	end
    return Str
end

function AB.t_Create(Sec, Rep, Func)
	local Ind = AB.str_Ran(G.ma_Rand(8, 16))
	G.tbl_Insert(AB.QTBL[24], Ind)
	G.t_Create(Ind, Sec, Rep, Func)
	AB.Timers[Ind] = {
		["index"]    = Ind,
		["type"]     = Sec,
		["delay"]    = Rep,
		["function"] = Func
	}
	AB.con_Log("log", "Timer ", Color(255, 93, 0), Ind, color_white, " created.\n")
	AB.con_LogFunc("Timer " .. Ind .. " created.")
end

function AB.ma_Format(Num)
    Num = tostring(Num)
    Sep = Sep or ","
	Deci = G.str_Find(Num, "%.") or #Num + 1
		for i = Deci - 4, 1, -3 do
			Num = Num:sub(1, i) .. Sep .. Num:sub(i + 1)
		end
    return Num
end

G.f_Req("cvar3")

function AB.mod_CVar_Force(cvar, value)
	G.GetCVar(cvar):SetValue(value)
	AB.ch_AddText("common/null.wav", "Forced ConVar ", Color(255, 93, 0), cvar, color_white, " to ", Color(116, 187, 251), value, color_white, ".")
end

/*================
Base Functions End|
==================*/

--------------------

/*==================
Hook Functions Start|
====================*/

function AB.h_Add(Type, Func)
	local Str = AB.str_Ran(G.ma_Rand(8, 16))
	G.tbl_Insert(AB.QTBL[1], Str)
	G.h_Add(Type, Str, Func)
	AB.Hooks[Str] = { 
		["type"]     = Type,
		["name"]     = Str,
		["function"] = Func
	}
	AB.con_Log("log", color_white, "Hook ", Color(255, 0, 0, 255), Type, color_white, ": ", Color(255, 93, 0), Str, color_white, " created.\n")
	AB.con_LogFunc("Hook " .. Type .. ": " .. Str .. " created.")
end

function AB.CreateMove(ucmd)
	for _, func in G.loop, AB.h_Adds.CreateMove do
		func(ucmd)
	end
end

function AB.DrawOverlay()
	for _, func in G.loop, AB.h_Adds.DrawOverlay do
		func()
	end
end

function AB.entity_killed(data)
	for _, func in G.loop, AB.h_Adds.entity_killed do
		func(data)
	end
end

function AB.HUDPaint()
	for _, func in G.loop, AB.h_Adds.HUDPaint do
		func()
	end
end

function AB.Move()
	for _, func in G.loop, AB.h_Adds.Move do
		func()
	end
end

function AB.PostDrawEffects()
	for _, func in G.loop, AB.h_Adds.PostDrawEffects do
		func()
	end
end

function AB.player_connect(data)
	for _, func in G.loop, AB.h_Adds.player_connect do
		func(data)
	end
end

function AB.player_disconnect(data)
	for _, func in G.loop, AB.h_Adds.player_disconnect do
		func(data)
	end
end

function AB.player_hurt(data)
	for _, func in G.loop, AB.h_Adds.player_hurt do
		func(data)
	end
end

function AB.RenderScreenspaceEffects()
	for _, func in G.loop, AB.h_Adds.RenderScreenspaceEffects do
		func()
	end
end

function AB.Think()
	for _, func in G.loop, AB.h_Adds.Think do
		func()
	end
end

function AB.Library.h_GetFuncs()
	AB.h_Add("CreateMove", AB.CreateMove)
	AB.h_Add("DrawOverlay", AB.DrawOverlay)
	AB.h_Add("entity_killed", AB.entity_killed)
	AB.h_Add("HUDPaint", AB.HUDPaint)
	AB.h_Add("Move", AB.Move)
	AB.h_Add("player_connect", AB.player_connect)
	AB.h_Add("player_disconnect", AB.player_disconnect)
	AB.h_Add("player_hurt", AB.player_hurt)
	AB.h_Add("PostDrawEffects", AB.PostDrawEffects)
	AB.h_Add("RenderScreenspaceEffects", AB.RenderScreenspaceEffects)
	AB.h_Add("Think", AB.Think)
end

/*================
Hook Functions End|
==================*/

----------------------------

/*==========================
Player Check Functions Start|
============================*/

function AB.check_Player(ply)
	if (ply ~= G.lcl_Ply && Alive(ply) && Team(ply) ~= TEAM_SPECTATOR) then
		return true
	end
	return false
end

function AB.check_Super(ply)
	if (SuperAdmin(ply)) then
		return true
	end
	return false
end

function AB.check_Admin(ply)
	if (Admin(ply) && !SuperAdmin(ply)) then
		return true
	end
	return false
end

function AB.check_Mod(ply)
	if (UserGroup(ply, "moderator")
	||	UserGroup(ply, "mod")
	||	UserGroup(ply, "donormod")
	||	UserGroup(ply, "donormoderator")
	||	UserGroup(ply, "donatormod")
	||	UserGroup(ply, "trialadmin")
	||	UserGroup(ply, "trial-admin")
	||	UserGroup(ply, "trialmod")
	||	UserGroup(ply, "trial-mod")
	||	UserGroup(ply, "operator")
	||	UserGroup(ply, "donoradmin")) then
		return true
	end
	return false
end

function AB.check_User(ply)
	if (UserGroup(ply, "user")
	||	UserGroup(ply, "guest")) then
		return true
	end
	return false
end

function AB.check_Other(ply)
	if (UserGroup(ply, "donator")
	||	UserGroup(ply, "donor")
	||	UserGroup(ply, "vip")
	||	UserGroup(ply, "vip+")
	||	UserGroup(ply, "donor+")
	||	UserGroup(ply, "donator+")
	||	UserGroup(ply, "member")
	||	UserGroup(ply, "respected")
	||	UserGroup(ply, "premiumvip")
	||	UserGroup(ply, "standardvip")
	||	UserGroup(ply, "trusted")) then
		return true
	else
		return false
	end
end

/*========================
Player Check Functions End|
==========================*/

--------------------------

/*=================
ESP Functions Start|
===================*/

// Credit to whoever made Naisho
function AB.GCoords(ply)
	local min, max = OBBMins(ply), OBBMaxs(ply)
	AB.QTBL[30] = {
		Vector(min.x, min.y, min.z),
		Vector(min.x, min.y, max.z),
		Vector(min.x, max.y, min.z),
		Vector(min.x, max.y, max.z),
		Vector(max.x, min.y, min.z),
		Vector(max.x, min.y, max.z),
		Vector(max.x, max.y, min.z),
		Vector(max.x, max.y, max.z)
	}
	local minx, miny, maxx, maxy = ScrW() * 2, ScrH() * 2, 0, 0
	for _, corner in pairs(AB.QTBL[30]) do
		local screen = ToScreen(ToWorld(ply, corner))
		minx, miny = G.ma_Min(minx, screen.x), G.ma_Min(miny, screen.y)
		maxx, maxy = G.ma_Max(maxx, screen.x), G.ma_Max(maxy, screen.y)
	end
	return minx, miny, maxx, maxy
end

/*===============
ESP Functions End|
=================*/

----------------------

/*====================
Aimbot Functions Start|
======================*/

// Credit to Styles
function AB.Transform(pos, matrix)
	local matA, matB, matC = matrix[1], matrix[2], matrix[3]
	local x = Vector(matA[1], matA[2], matA[3])
	local y = Vector(matB[1], matB[2], matB[3])
	local z = Vector(matC[1], matC[2], matC[3])
	return Vector(Dot(pos, x) + matA[4], Dot(pos, y) + matB[4], Dot(pos, z) + matC[4])
end

function AB.aim_FindBone(ply)
	if (AB.set_Get("aim_bone") == 1) then
		local BUBone = AB.QTBL[13][GetModel(ply)]
		if not (BUBone) then
			BoneType = AB.set_Get("aim_targetspot")
		end
		local lBone = LookupBone(ply, BoneType)
		if (lBone) then
			local pos, ang = BonePosition(ply, lBone)
			return pos, ang
		end
		return ToWorld(ply, OBBCenter(ply))
	end
end

// Credit to Styles
function AB.GetPosition(ply)
	if (AB.set_Get("aim_hitbox") == 1) then
		local Index = G.str_Find(GetModel(ply), "combine") and 1 or 0
		local Bone = GetHitBoxBone(ply, Index,0)
		if not BonePosition(ply, Bone) then 
			return 
		end
		local _Matrix = GetBoneMatrix(ply, Bone)
		if not _Matrix then 
			return 
		end
		_Matrix = ToTable(_Matrix)
		local min, max = GetHitBoxBounds(ply, Index, 0)
		return (AB.Transform(min, _Matrix) + AB.Transform(max, _Matrix)) * .5
	end
end

function AB.aim_Exceptions(ply)
	if (AB.check_Player(ply)) then
		if (Vehicle(ply)) then
			return false
		end
		--if (IsDormant(ply)) then
			--return false
		--end
		if (AB.set_Get("aim_players") == 1 && IsPlayer(ply)) then 
			return false
		end
		if (AB.set_Get("aim_team") == 1 && Team(ply) == Team(G.lcl_Ply)) then 
			return false
		end
		if (AB.set_Get("aim_friends") == 1 && G.tbl_HasVal(AB.QTBL[5], Name(ply))) then 
			return false
		end
		local ply_Col = GetColor(ply, r, g, b, a)
		if (AB.set_Get("aim_spawnpro") == 1 && ply_Col.a < 255) then 
			return false
		end
	end
	return true
end

function AB.aim_IsVisible(ply)
	if (AB.set_Get("aim_los") == 0) then
		return true
	end
	if (AB.set_Get("aim_bscan") == 1) then
		for bone = 0, GetBoneCount(ply) do
			local bPos = BonePosition(ply, bone)
			trace = {
				start = ShootPos(G.lcl_Ply),
				endpos = bPos,
				filter = G.lcl_Ply,
				mask = MASK_SHOT
			}
			TRes = G.ut_TraceL(trace)
			if (TRes.Entity == ply) then 
				return true
			end
		end
	else
		if (AB.set_Get("aim_bone") == 1) then
			pos = AB.aim_FindBone(ply)
		elseif (AB.set_Get("aim_hitbox") == 1) then
			pos = AB.GetPosition(ply)
		end
		trace = {
			start = ShootPos(G.lcl_Ply),
			endpos = pos,
			filter = G.lcl_Ply,
			mask = MASK_SHOT
		}
		TRes = G.ut_TraceL(trace)
		if (TRes.Entity == ply) then 
			return true
		end
	end
	return false
end

local FakeAng = nil
function AB.aim_GetAng()
	local EyeAng = Eye_Angles(G.lcl_Ply)
	if FakeAng ~= nil then
		return FakeAng
	end
	return Angle(EyeAng.p, EyeAng.y, EyeAng.r)
end

// Credit to whoever made 'dickwrap'
function AB.PredictSpread(ucmd, ang)
	local Wep = ActiveWeapon(G.lcl_Ply)
	if (!Wep || !Valid(Wep) || !AB.QTBL[25][GetClass(Wep)]) then 
		return ang
	end
	local ang = v_Angle(dickwrap.Predict(ucmd, Forward(ang), AB.QTBL[25][GetClass(Wep)]))
	ang.p, ang.y, ang.x = G.ma_Normalize(ang.p), G.ma_Normalize(ang.y), G.ma_Normalize(ang.x)
	return ang
end

// Credit to Kelse/Daz
function AB.VeloPredict(ply, vec)
	ply_Pos = ShootPos(G.lcl_Ply) + GetVelocity(G.lcl_Ply) * G.eng_TickInt()
	local ply_Frames = RealFrameTime() / 66 || 0
	local tgt_Frames = RealFrameTime() / 25 || 0
	local ply_Velo = GetVelocity(G.lcl_Ply) || Vector(0, 0, 0)
	local tgt_Velo = GetVelocity(ply) || Vector(0, 0, 0)
    return vec + (tgt_Velo * (tgt_Frames) - (ply_Velo * (ply_Frames))) || Vector(0, 0, 0)
end

function AB.aim_FoV(ply)
	local FoV = AB.set_Get("aim_fov")
	if (FoV ~= 360 && AB.set_Get("aim_aa") == 0) then
		local Ang = (v_Angle(GetPos(ply) - Eye_Pos(G.lcl_Ply)))
		local myAng = GetAngles(G.lcl_Ply)
		local Yaw, Pitch = G.ma_abs(G.ma_Normalize(myAng.y - Ang.y)), G.ma_abs(G.ma_Normalize(myAng.p - Ang.p))
		if (Yaw > FoV || Pitch > FoV) then 
			return false
		end
	elseif (AB.set_Get("aim_aa") == 1) then
		return true
	end
	return true
end

function AB.aim_GetTgt()
	local Target
	if Target == nil then 
		Target = G.lcl_Ply
	else 
		Target = Target
	end
	local AngA, AngB = 0
	local x, y = ScrW(), ScrH()
	for _, v in G.loop, G.p_GetAll() do
		local Distance = Distance(GetPos(v), GetPos(G.lcl_Ply))
		if (AB.aim_Exceptions(v) && AB.aim_IsVisible(v) && AB.aim_FoV(v) && Distance <= AB.set_Get("aim_distance") && GetPos(v) ~= Vector(0, 0, 0)) then
			local EyePos, EyePosTS, EyeAng = ToScreen(Eye_Pos(v)), ToScreen(Eye_Pos(Target)), GetAngles(G.lcl_Ply)
			local AimDist = DistToSqr(GetPos(v), GetPos(G.lcl_Ply))
			AngA = G.ma_Dist(x / 10, y / 10, EyePosTS.x, EyePosTS.y)
			AngB = G.ma_Dist(x / 10, y / 10, EyePos.x, EyePos.y)
			if (AngB <= AngA) then
				Target = v
			elseif Target == G.lcl_Ply then
				Target = v
			end
		end
	end

	if (AB.set_Get("aim_npcs") == 0) then
		for _, v in G.loop, G.e_GetAll() do
			local Distance = Distance(GetPos(v), GetPos(G.lcl_Ply))
			if (v:IsNPC() && AB.aim_IsVisible(v) && AB.aim_FoV(v) && Distance <= AB.set_Get("aim_distance") && GetPos(v) ~= Vector(0, 0, 0)) then
				local EyePos, EyePosTS, EyeAng = ToScreen(Eye_Pos(v)), ToScreen(Eye_Pos(Target)), GetAngles(G.lcl_Ply)
				local AimDist = DistToSqr(GetPos(v), GetPos(G.lcl_Ply))
				AngA = G.ma_Dist(x / 10, y / 10, EyePosTS.x, EyePosTS.y)
				AngB = G.ma_Dist(x / 10, y / 10, EyePos.x, EyePos.y)
				if (AngB <= AngA) then
					Target = v
				elseif Target == G.lcl_Ply then
					Target = v
				end
			end
		end
	end
	return Target
end

function AB.WepVector(num)
	num = -num
    return Vector(num, num, num)
end

function AB.GetCone()
	local Wep = ActiveWeapon(G.lcl_Ply)
	if (!Valid(Wep)) then return Vector(0, 0, 0) end
		if (!Wep.Primary) then return Vector(0, 0, 0) end
		if (!Wep.Primary.Cone) then return Vector(0, 0, 0) end
		if (type(Wep.Primary.Cone) ~= "Vector") then
			return AB.WepVector(Wep.Primary.Cone)
		end
	return Wep.Primary.Cone * -1
end

function AB.AngleBetween(a, b)
	local dot = Dot(a,b)
	if dot > 1.0 then
		return 0
	end
	return math.deg(math.acos(dot))
end

// Credits to C0bra
function AB.PlyBlocked(ply, offset)
	local AimVector = Forward(Eye_Angles(G.lcl_Ply))
	local ShootPos = ShootPos(G.lcl_Ply)
	local TargetPos = GetPos(ply)
	if (offset) then 
		TargetPos = TargetPos + offset
	end
	local trace = {
		start = ShootPos, 
		endpos = TargetPos, 
		filter = {G.lcl_Ply, ply}, 
		mask = MASK_SHOT
	}
	local TRes = G.ut_TraceL(trace)
	local AimVec = AimVector or AimVector(G.lcl_Ply)
	local WrongAim = AB.AngleBetween(AimVec, Normal(TargetPos - ShootPos)) > 2
	if (TRes.Hit and TRes.Entity ~= ply) then
		return true, WrongAim
	end
	return false, WrongAim
end

function AB.GetDangerLevel()
	local perc = 0
	local lBone = LookupBone(G.lcl_Ply, "ValveBiped.Bip01_Head1")
	local lp_sPos = BonePosition(G.lcl_Ply, lBone)	
	for _, v in G.loop, G.p_GetAll() do
		if (v == G.lcl_Ply or not Valid(v)) then 
			continue
		end
		local notVisible, _ = AB.PlyBlocked(v)
		local sPos = ShootPos(v)
		local level = AB.AngleBetween(AimVector(v), Normal(sPos - lp_sPos)) / 180
		
		if (notVisible) then
			level = level * 0.33
		end
		perc = math.max(perc, level)
	end
	return perc
end

/*==================
Aimbot Functions End|
====================*/

--------------------

/*==================
Misc Functions Start|
====================*/

function AB.ServerStats()
	AB.con_LogFunc("Current GameMode: " .. GAMEMODE.Name .. ".")
	AB.con_LogFunc("Total players: " .. tostring(#G.p_GetAll()) .. "/" .. tostring(game.MaxPlayers()) .. ".")
	AB.ch_AddText("common/null.wav", "Current GameMode: ", Color(116, 187, 251), GAMEMODE.Name, color_white, ".")
	AB.ch_AddText("common/null.wav", "Total players: ", Color(116, 187, 251), tostring(#G.p_GetAll()), color_white, "/", Color(116, 187, 251), tostring(game.MaxPlayers()), color_white, ".")
end

function AB.GMRP()
    if G.str_Find(G.str_Lower(GAMEMODE.Name), "dark") then return true end
    return false
end

/*================
Misc Functions End|
==================*/

------------------

/*===============
Hook Adding Start|
=================*/

function AB.h_Adds.DrawOverlay.ESP()
	if (AB.set_Get("esp") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			local hp = Health(ply)
			local hCol = Color(255 - 2.2 * hp, 2.2 * hp, 0, 255)
			local Wep = "None/Unknown"
				if (ActiveWeapon(ply) ~= nil) then
					if (type(ActiveWeapon(ply)) == "Weapon") then
						if (ActiveWeapon(ply) && Valid(ActiveWeapon(ply))) then
							Wep = GetPrintName(ActiveWeapon(ply))
						end
					end
				end
			local UGroup = G.str_Lower(NetworkedString(ply, "UserGroup"))
			local ePos = ToScreen(Eye_Pos(ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance")) then
				if (G.tbl_HasVal(AB.QTBL[5], Name(ply))) then
					G.dr_DrTxt("[FRIEND]", "BudgetLabel", ePos.x, ePos.y - 61, Color(0, 201, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				if (AB.set_Get("esp_info_rank") == 1) then
					G.dr_DrTxt("["..UGroup.."]", "BudgetLabel", ePos.x, ePos.y - 50, Color(116, 187, 251), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				if (AB.set_Get("esp_info_name") == 1) then
					G.dr_DrTxt(Name(ply), "BudgetLabel", ePos.x, ePos.y - 39, G.t_GetCol(Team(ply)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				if (AB.set_Get("esp_info_health") == 1) then
					G.dr_DrTxt(Health(ply), "BudgetLabel", ePos.x, ePos.y - 29, hCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				if (AB.set_Get("esp_info_weapon") == 1) then
					G.dr_DrTxt(Wep, "BudgetLabel", ePos.x, ePos.y - 19, Color(116, 187, 251), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				if (AB.set_Get("esp_info_distance") == 1 and AB.set_Get("esp_info_weapon") == 0) then
					G.dr_DrTxt(AB.ma_Format(G.ma_Floor(Distance)), "BudgetLabel", ePos.x, ePos.y - 19, Color(116, 187, 251), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				elseif (AB.set_Get("esp_info_distance") == 1 and AB.set_Get("esp_info_weapon") == 1) then
					G.dr_DrTxt(AB.ma_Format(G.ma_Floor(Distance)), "BudgetLabel", ePos.x, ePos.y - 9, Color(116, 187, 251), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
		end
	end

	if (AB.set_Get("esp_ents") == 1) then
		for _, ent in G.loop, G.e_GetAll() do
			if (Valid(ent) && G.tbl_HasVal(AB.QTBL[6], GetClass(ent))) then
				local x1, y1, x2, y2 = AB.GCoords(ent)
				G.dr_DrTxt(GetClass(ent), "BudgetLabel", x1 + 38, y1 - 17, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end                    
	end

	if (AB.set_Get("esp_skeleton") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance")) then
				for _, v in G.loop, AB.QTBL[12] do
					local sPos, ePos = ToScreen(BonePosition(ply, LookupBone(ply, v.S))), ToScreen(BonePosition(ply, LookupBone(ply, v.E)))
					G.sur_SetDrawCol(G.t_GetCol(Team(ply)))
					G.sur_DrawLi(sPos.x, sPos.y, ePos.x, ePos.y)
				end
			end
		end
	end

	if (AB.set_Get("esp_2dbox") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance_box")) then
				local x1, y1, x2, y2 = AB.GCoords(ply)
				if (x2 > x1) then 
					diff = x2 - x1 
				else 
					diff = x1 - x2 
				end
				if (y2 > y1) then
					diff2 = y2 - y1 
				else 
					diff2 = y1 - y2 
				end
				G.sur_SetDrawCol(color_black)
				G.sur_DrawOutRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				G.sur_DrawOutRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				G.sur_SetDrawCol(G.t_GetCol(Team(ply)))
				G.sur_DrawOutRect(x1, y1, diff, diff2)
			end
		end
	end

	if (AB.set_Get("esp_2dbox_ent") == 1) then
		for _, ent in G.loop, G.e_GetAll() do
			local Distance = Distance(GetPos(ent), GetPos(G.lcl_Ply))
			if (Valid(ent) && G.tbl_HasVal(AB.QTBL[6], GetClass(ent)) && Distance <= AB.set_Get("esp_distance_box")) then
				local x1, y1, x2, y2 = AB.GCoords(ent)
				if (x2 > x1) then 
					diff = x2 - x1 
				else 
					diff = x1 - x2 
				end
				if (y2 > y1) then
					diff2 = y2 - y1 
				else 
					diff2 = y1 - y2 
				end
				G.sur_SetDrawCol(color_black)
				G.sur_DrawOutRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
				G.sur_DrawOutRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
				G.sur_SetDrawCol(color_white)
				G.sur_DrawOutRect(x1, y1, diff, diff2)
			end
		end
	end

	if (AB.set_Get("esp_hpbar") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance_box")) then
				local hp = Health(ply)
				local hCol = Color(255 - 2.2 * hp, 2.2 * hp, 0, 255)
				local x1, y1, x2, y2 = AB.GCoords(ply)
				local diff
				local health
				if (y2 > y1) then 
					diff = y2 - y1 
				else 
					diff = y1 - y2 
				end
				local height = (G.ma_Clamp(Health(ply), 0, 100) * diff) / 100
				G.sur_SetDrawCol(color_black)
				G.sur_DrawLi(x1 - 6 , y2 - 2, x1 - 6, y1 - 2)
				G.sur_DrawLi(x1 - 6 , y2 + 0, x1 - 3, y2 + 0)
				G.sur_DrawLi(x1 - 6 , y1, x1 - 3, y1 - 2)
				G.sur_DrawLi(x1 - 3 , y2, x1 - 3, y1 - 2)
				G.sur_SetDrawCol(hCol)
				G.sur_DrawLi(x1 - 5, y2, x1 - 5, y2 - height - 2)
				G.sur_DrawLi(x1 - 4, y2, x1 - 4, y2 - height - 2)
			end
		end
	end
end

function AB.h_Adds.DrawOverlay.Radar()
	if (AB.set_Get("radar") == 1) then
		G.dr_RoundBox(0, AB.set_Get("radar_x"), AB.set_Get("radar_y"), 250, 250, Color(0, 0, 0, 185))
		G.dr_RoundBox(0, AB.set_Get("radar_x"), AB.set_Get("radar_y"), 250, 5, AB.MCol)
		G.dr_RoundBox(0, AB.set_Get("radar_x"), AB.set_Get("radar_y") + 250, 250, 5, AB.MCol)
		for _, ply in G.loop, G.p_GetAll() do
			if (AB.check_Player(ply)) then
				local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
				local FOV = FOV(ply) / 65
				local zPos, plyPos = GetPos(G.lcl_Ply).z - (GetPos(ply).z), (GetPos(G.lcl_Ply) - GetPos(ply))
				Rotate(plyPos, Angle(180, (Eye_Angles(G.lcl_Ply).y) * -1, -180))
				local scrY = plyPos.y * (250 / ((AB.set_Get("radar_distance") * (FOV  * (ScrW() / ScrH()))) + zPos * (FOV  * (ScrW() / ScrH()))))
				local scrX = plyPos.x * (250 / ((AB.set_Get("radar_distance") * (FOV  * (ScrW() / ScrH()))) + zPos * (FOV  * (ScrW() / ScrH()))))
				local pX = AB.set_Get("radar_x") + 120 - scrY
				local pY = AB.set_Get("radar_y") + 120 - scrX
				if scrX < 120 && scrY < 120 && scrX > -120 && scrY > -120 then
					G.dr_RoundBox(0, pX, pY, 6, 6, G.t_GetCol(Team(ply)))
					G.dr_DrTxt(Name(ply), "Items", pX, pY - 20, G.t_GetCol(Team(ply)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					G.dr_DrTxt(AB.ma_Format(G.ma_Floor(Distance)), "Items", pX, pY + 5, G.t_GetCol(Team(ply)), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
		end
		G.dr_RoundBox(0, AB.set_Get("radar_x"), AB.set_Get("radar_y"), 5, 250, AB.MCol)
		G.dr_RoundBox(0, AB.set_Get("radar_x") + 250, AB.set_Get("radar_y"), 5, 255, AB.MCol)

		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawLi(AB.set_Get("radar_x") + 125, AB.set_Get("radar_y") + 125 - 120, AB.set_Get("radar_x") + 125, AB.set_Get("radar_y") + 125 + 125)
		G.sur_DrawLi(AB.set_Get("radar_x") +125 - 120, AB.set_Get("radar_y") + 125, AB.set_Get("radar_x") + 125 + 125, AB.set_Get("radar_y") + 125)

		G.sur_SetDrawCol(color_white)
		G.sur_DrawLi(AB.set_Get("radar_x") + 125, AB.set_Get("radar_y") + 125 - 10, AB.set_Get("radar_x") + 125, AB.set_Get("radar_y") + 125 + 10)
		G.sur_DrawLi(AB.set_Get("radar_x") + 125 - 10, AB.set_Get("radar_y") + 125, AB.set_Get("radar_x") + 125 + 10, AB.set_Get("radar_y") + 125)
	end
end

function AB.h_Adds.DrawOverlay.SpecList()
	if (AB.set_Get("misc_speclist") == 1) then
		local Width = 0
		local Height = 20
		G.sur_SetFont("Items")
		G.sur_SetTxtCol(color_white)
		for _, v in G.loop, AB.QTBL[7] do
			local W, H = G.sur_GetTxtSi(Name(v))
			if W > Width then
				Width = W
			end
			Height = Height + H
		end
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(ScrW() - Width - 30, 10, Width + 20, Height + 20, 0, 0, Width / 32, Height / 32)
		G.dr_RoundBox(0, ScrW() - Width - 30, 10, Width + 20, 18, AB.MCol)
		G.dr_SimpTxt("Spectators", "Items",  ScrW() - Width - 20, 10, color_white)
		for _, v in G.loop, AB.QTBL[7] do
			local Text = Name(v)
			local W, H = G.sur_GetTxtSi(Text)
			G.sur_SetTxtPos(ScrW() - 20 - Width, Height)
			G.sur_DrawTxt(Text)
			Height = Height - H
		end
	end
end

function AB.h_Adds.DrawOverlay.Chams()
	if (AB.set_Get("esp_chams_players") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance_chams")) then
				local t_Col = G.t_GetCol(Team(ply))
				G.c_Start3D()
					SetMaterial(ply, "models/debug/debugwhite")
					G.r_SetColMod(t_Col.r / 255, t_Col.g / 255, t_Col.b / 255)
					G.r_SetBlend(t_Col.a / 255)
					DrawModel(ply)
				G.c_End3D()
			end
		end
	end

	if (AB.set_Get("esp_chams_players_wpn") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Wep = ActiveWeapon(ply)
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Valid(Wep) && Distance <= AB.set_Get("esp_distance_chams")) then
				G.c_Start3D()
					SetMaterial(Wep, "models/debug/debugwhite")
					G.r_SetColMod(255, 0, 0)
					G.r_SetBlend(1)
					DrawModel(Wep)
				G.c_End3D()
			end
		end
	end

	if (AB.set_Get("esp_chams_ents") == 1) then
		for _, ent in G.loop, G.e_GetAll() do
			local Distance = Distance(GetPos(ent), GetPos(G.lcl_Ply))
			if (G.tbl_HasVal(AB.QTBL[6], GetClass(ent)) && Distance <= AB.set_Get("esp_distance_chams") && GetPos(ent) ~= Vector(0, 0, 0)) then
				G.c_Start3D()
					SetMaterial(ent, "models/debug/debugwhite")
					G.r_SetColMod(1, 1, 1)
					DrawModel(ent)
				G.c_End3D()
			end
		end
	end

	if (AB.set_Get("esp_chams_players") == 0 or AB.set_Get("esp_chams_ents") == 0 or AB.set_Get("esp_chams_players_wpn") == 0) then
		for _, ent in G.loop, G.e_GetAll() do
			SetMaterial(ent, "")
			G.r_SetColMod(1, 1, 1)
			G.r_SetBlend(1)
		end
	end

	if AB.set_Get("esp_chams_xqz") == 1 then
		for _, ply in G.loop, G.p_GetAll() do
			G.c_Start3D()
				G.c_IgnZ(true)
				ply:DrawModel()
			G.c_End3D()
		end
	end

end

function AB.h_Adds.HUDPaint.CHair()
	if (AB.set_Get("misc_crosshair") == 1) then
		local CHCol = Color(unpack(G.str_Explode(",", tostring(AB.set_Get("misc_crosshair_col")))))
		G.sur_SetDrawCol(CHCol)
		G.sur_DrawLi(ScrW() / 2 + 22, ScrH() / 2, ScrW() / 2 - 23, ScrH() / 2)
		G.sur_DrawLi(ScrW() / 2, ScrH() / 2 + 22, ScrW() / 2, ScrH() / 2 - 23)
	end
end

function AB.h_Adds.RenderScreenspaceEffects.Beams()
	if (AB.set_Get("esp_barrel_laser") == 1 or AB.set_Get("esp_ground_laser") == 1 or AB.set_Get("esp_head_laser") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance")) then
				G.c_Start3D(EyePos(), EyeAngles())
					if (AB.set_Get("esp_barrel_laser") == 1) then
						local Ang_Eye = Eye_Angles(ply)
						local trace = {}
						trace.start = ShootPos(ply)
						trace.endpos = ShootPos(ply) + Forward(Ang_Eye) * 25650
						trace.filter = ply
						local tr = G.ut_TraceL(trace)
						G.r_DrawLine(tr.StartPos, tr.HitPos, G.t_GetCol(Team(ply)), true)
					end

					if (AB.set_Get("esp_ground_laser") == 1) then
						local Ang_Down = Angle(90, 0, 0)
						local trace = {}
						trace.start = ShootPos(ply)
						trace.endpos = ShootPos(ply) + Forward(Ang_Down) * 25650
						trace.filter = ply
						local tr = G.ut_TraceL(trace)
						G.r_DrawLine(tr.StartPos, tr.HitPos, G.t_GetCol(Team(ply)), true)
					end

					if (AB.set_Get("esp_head_laser") == 1) then
						local Ang_Up = Angle(-90, 0, 0)
						local trace = {}
						trace.start = ShootPos(ply)
						trace.endpos = ShootPos(ply) + Forward(Ang_Up) * 25650
						trace.filter = ply
						local tr = G.ut_TraceL(trace)
						G.r_DrawLine(tr.StartPos, tr.HitPos, G.t_GetCol(Team(ply)), true)
					end
				G.c_End3D()
			end
		end
	end

	if (AB.set_Get("esp_hitbox") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			local Distance = Distance(GetPos(ply), GetPos(G.lcl_Ply))
			if (AB.check_Player(ply) && Distance <= AB.set_Get("esp_distance_box")) then
				for i = 0, GetHitBoxCount(ply, 0) do
					local ply_Bone = GetHitBoxBone(ply, i, 0)
					if (ply_Bone ~= nil) then
						G.c_Start3D(EyePos(), EyeAngles())
							local t_Col = G.t_GetCol(Team(ply))
							local BCol = Color(t_Col.r, t_Col.g, t_Col.b, 35)
							local BCol_Al = Color(BCol.r, BCol.g, BCol.b, 255)
							local ply_BPos, ply_BAng = BonePosition(ply, ply_Bone)
							local Min, Max = GetHitBoxBounds(ply, i, 0)
							if Min ~= nil and Max ~= nil then
								G.r_SCMatIgnoreZ()
								G.r_SetBlend(BCol.a / 255)
								G.r_DrawBox(ply_BPos, ply_BAng, Min, Max, BCol, false)
								G.r_DrawWFBox(ply_BPos, ply_BAng, Min, Max, BCol_Al, false)
							end
						G.c_End3D()
					end
				end
			end
		end
	end
end

local ProperCurTime = 0
function AB.h_Adds.Move.FixCurTime()
	if IsFirstTimePredicted() then
		ProperCurTime = CurTime()
	end
end

ConCMD(G.lcl_Ply, "cl_updaterate 200;cl_cmdrate 200;cl_interp 0;cl_interp_ratio 0")

local Dead = {}
local aaCenter = {}
local aaNone = {}
local aaMeth = "default"
local bDelay = 0
local bDelay_AA = 0
local bQueued = 0
local t_Acq = false
local bSendPacket = true
local bBulletTime = true
function AB.h_Adds.CreateMove.BaseCMoves(ucmd)
	if (FakeAng) then
		if (AB.set_Get("aim_silent") == 1 or AB.set_Get("aim_psilent") == 1 or AB.set_Get("aim_aa") == 1) then
			FakeAng.p = G.ma_Normalize(G.ma_Clamp(FakeAng.p + (GetMouseY(ucmd) * 0.02), -89, 89))
			FakeAng.y = G.ma_Normalize(FakeAng.y + (GetMouseX(ucmd) * 0.02 * -1))
			SetViewAngles(ucmd, FakeAng)
		end
	end

	if (AB.set_Get("aim_aa") == 1) then
		if (bSendPacket) then
			FakeAng = GetViewAngles(ucmd)
		end
	end

	if (AB.set_Get("aim_nospread") == 1) then
		if (KeyDown(ucmd, ATTACK) && t_Acq == false) then
			FakeAng = GetViewAngles(ucmd)
			FakeAng.p = G.ma_Normalize(G.ma_Clamp(FakeAng.p + (GetMouseY(ucmd) * 0.011), -89, 89))
			FakeAng.y = G.ma_Normalize(FakeAng.y + (GetMouseX(ucmd) * 0.011 * -1))
			SetViewAngles(ucmd, AB.PredictSpread(ucmd, FakeAng))
		end
	end

	if (AB.set_Get("aim_fakelag") == 1) then
		if (Checked_CV == true) then
			bQueued = bQueued + 1
			if (bQueued >= 0) then
				if (bQueued < AB.set_Get("aim_fakelag_rate")) then
					G.GetCVar("host_timescale"):SetValue(0)
				else
					G.GetCVar("host_timescale"):SetValue(1)
				end
				--print(bQueued)
			else
				G.GetCVar("host_timescale"):SetValue(1)
			end
			if (bQueued == (AB.set_Get("aim_fakelag_rate") + 7)) then
				bQueued = 0
			end
		end
	else
		bQueued = 0
	end
	
	if (AB.set_Get("aim_aaa") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			// 'Best' you can get to AAA in pure Lua. At least to my knowledge... -- Why don't you fucking credit me noob?
			local EyeAng = Eye_Angles(ply)
			local rAng = {
				EyeAng.p + 180,
				EyeAng.p - 180
			}
			if (G.tbl_HasVal(aaNone, Name(ply))) then
				SetPoseParameter(ply, "aim_pitch", EyeAng.p)
				InvalidateBoneCache(ply)
			else
				if (EyeAng.p < -89) then
					if (AB.set_Get("aim_aaa_fb") == 1) then
						SetPoseParameter(ply, "aim_pitch", G.tbl_Rand(rAng))
						InvalidateBoneCache(ply)
					else
						SetPoseParameter(ply, "aim_pitch", EyeAng.p + 180)
						InvalidateBoneCache(ply)
					end
				elseif (EyeAng.p > 89) then
					if (AB.set_Get("aim_aaa_fb") == 1) then
						SetPoseParameter(ply, "aim_pitch", G.tbl_Rand(rAng))
						InvalidateBoneCache(ply)
					else
						SetPoseParameter(ply, "aim_pitch", EyeAng.p - 180)
						InvalidateBoneCache(ply)
					end
				end
				/*
				if (EyeAng.y <= -360) then
					SetPoseParameter(ply, "aim_yaw", G.ma_Normalize(-360))
				elseif (EyeAng.y >= 360) then
					SetPoseParameter(ply, "aim_yaw", G.ma_Normalize(360))
				end
				*/
			end
		end
	end

	local fbSafe = true
	if (AB.set_Get("aim_aaaa") == 1) then
		if (AB.GetDangerLevel() <= .90) then 
			fbSafe = true
		else 
			fbSafe = false
		end
	else
		fbSafe = true
	end

	if (G.inp_KeyDown(AB.set_Get("aim_key")) or AB.set_Get("aim_toggle") == 1) then
		local Target = AB.aim_GetTgt()
		if (Alive(G.lcl_Ply) && Target ~= nil && Target ~= G.lcl_Ply) then
			t_Acq = true
			local Wep = ActiveWeapon(G.lcl_Ply)
			if (!Target:IsNPC()) then
				if (G.tbl_HasVal(aaCenter, Name(Target))) then
					fBoneF = ToWorld(Target, OBBCenter(Target))
				else
					if (AB.set_Get("aim_bone") == 1) then
						fBoneF = AB.aim_FindBone(Target) - Vector(0, 0, -3)
					elseif (AB.set_Get("aim_hitbox") == 1) then
						fBoneF = AB.GetPosition(Target)
					end
				end
			else
				if (AB.set_Get("aim_npcs") == 0) then
					fBoneF = AB.aim_FindBone(Target)
				end
			end
			--print(bDelay)
			Ang = (AB.VeloPredict(Target, fBoneF))
			Ang = v_Angle(Ang - ply_Pos)
			if (AB.set_Get("aim_silent") == 1 or AB.set_Get("aim_psilent") == 1) then
				if (bSendPacket) then
					FakeAng = GetViewAngles(ucmd)
				end
				if (GetNextPrimaryFire(Wep) >= ProperCurTime) then
					bBulletTime = false
				else
					bBulletTime = true
				end
				if (CommandNumber(ucmd) == 0) then
					bSendPacket = true
				else
					bSendPacket = false
					bDelay = bDelay + 1
					if (AB.set_Get("aim_psilent") == 1) then
						G.GetCVar("host_timescale"):SetValue(0)
					end
				end
				if (bBulletTime && !bSendPacket) then
					if (AB.set_Get("aim_psilent") == 1) then
						if (bDelay >= 4) then
							if (AB.set_Get("aim_nospread") == 1) then
								Ang = AB.PredictSpread(ucmd, Ang)
								SetViewAngles(ucmd, Ang)
							else
								AimAngle = Angle(G.ma_Normalize(Ang.p), G.ma_Normalize(Ang.y), 0)
								SetViewAngles(ucmd, AimAngle)
							end
							if (AB.set_Get("aim_autofire") == 1) then
								SetButtons(ucmd, G.b_Bor(GetButtons(ucmd), ATTACK))
							end
							bDelay = 0
							G.GetCVar("host_timescale"):SetValue(1)
						end
					else
						if (AB.set_Get("aim_nospread") == 1) then
							Ang = AB.PredictSpread(ucmd, Ang)
							SetViewAngles(ucmd, Ang)
						else
							AimAngle = Angle(G.ma_Normalize(Ang.p), G.ma_Normalize(Ang.y), 0)
							SetViewAngles(ucmd, AimAngle)
						end
						if (AB.set_Get("aim_autofire") == 1) then
							SetButtons(ucmd, G.b_Bor(GetButtons(ucmd), ATTACK))
						end
					end
				else 
					FakeAng.p = G.ma_Normalize(G.ma_Clamp(FakeAng.p + (GetMouseY(ucmd) * 0.02), -89, 89))
					FakeAng.y = G.ma_Normalize(FakeAng.y + (GetMouseX(ucmd) * 0.02 * -1))
					SetViewAngles(ucmd, FakeAng)
				end
			else
				if (AB.set_Get("aim_nospread") == 1) then
					Ang = AB.PredictSpread(ucmd, Ang)
					SetViewAngles(ucmd, Ang)
				else
					AimAngle = Angle(G.ma_Normalize(Ang.p), G.ma_Normalize(Ang.y), 0)
					SetViewAngles(ucmd, AimAngle)
				end
				if (AB.set_Get("aim_autofire") == 1) then
					SetButtons(ucmd, G.b_Bor(GetButtons(ucmd), ATTACK))
				end
			end
			if (AB.set_Get("aim_silent") == 1 or AB.set_Get("aim_psilent") == 1) then
				local a_Dir = Vector(GetForwardMove(ucmd), GetSideMove(ucmd), 0 )
				local a_Vec = Forward((v_Angle(a_Dir) + (GetViewAngles(ucmd) - AB.aim_GetAng()))) * Length(a_Dir)
				SetForwardMove(ucmd, a_Vec[1])
				SetSideMove(ucmd, a_Vec[2])
			end
			if (AB.set_Get("aim_psilent") == 1) then
				-- Fallback
				if (bDelay >= 4) then
					bDelay = 0
					G.GetCVar("host_timescale"):SetValue(1)
				end
			end
		else
			t_Acq = false
			if (AB.set_Get("aim_psilent") == 1) then
				-- Fallback
				bDelay = 0
				G.GetCVar("host_timescale"):SetValue(1)
			end
		end
	else
		Target = nil
		t_Acq = false
		if (AB.set_Get("aim_psilent") == 1) then
			-- Fallback
			if (bDelay >= 4) then
				bDelay = 0
				G.GetCVar("host_timescale"):SetValue(1)
			elseif (AB.set_Get("aim_fakelag") == 0 or AB.set_Get("aim_aa") == 0) then
				G.GetCVar("host_timescale"):SetValue(1)
			end
		end
	end

	local r_Ang = GetViewAngles(ucmd)
	local jit_Ang = {-181, 345}
	local rSpeed = G.ma_abs(G.ma_sin(CurTime() * 25))
	if (AB.set_Get("aim_aa") == 1) then
		if (AB.set_Get("aim_aa_type") == "Invert") then
			r_Ang.p = -181
			r_Ang.y = r_Ang.y - 180
			r_Ang.r = r_Ang.r
		elseif (AB.set_Get("aim_aa_type") == "Spin") then
			r_Ang.p = -271
			r_Ang.y = G.ma_fmod(CurTime() / .1 * 35 * 6, 360)
			r_Ang.r = -181
		elseif (AB.set_Get("aim_aa_type") == "Fake SW") then
			bDelay_AA = bDelay_AA + 1
			if (bDelay_AA < 3) then
				G.GetCVar("host_timescale"):SetValue(0)
				r_Ang.p = -541
				r_Ang.y = -620
				r_Ang.r = r_Ang.r
			else 
				r_Ang.p = 541
				r_Ang.y = 720
				r_Ang.r = r_Ang.r
			end
			if (bDelay_AA == 5) then
				G.GetCVar("host_timescale"):SetValue(1)
				bDelay_AA = 0
			end
		elseif (AB.set_Get("aim_aa_type") == "Custom") then
			if (AB.set_Get("aim_aa_pitch") == 0) then
				r_Ang.p = r_Ang.p
			elseif (AB.set_Get("aim_aa_pitch_jit") == 1) then
				r_Ang.p = G.tbl_Rand(jit_Ang)
			elseif (fbSafe == false or fbSafe == true) then
				r_Ang.p = AB.set_Get("aim_aa_pitch")
				if (fbSafe == false) then
					r_Ang.p = G.tbl_Rand(jit_Ang)
					r_Ang.y = r_Ang.y - 362
					r_Ang.r = 0
				elseif (fbSafe == true) then
					r_Ang.p = AB.set_Get("aim_aa_pitch")
					r_Ang.y = r_Ang.y + AB.set_Get("aim_aa_yaw")
				end
			end

			if (AB.set_Get("aim_aa_yaw") == 0 && AB.set_Get("aim_aa_spin") == 0) then
				r_Ang.y = r_Ang.y
			elseif (AB.set_Get("aim_aa_spin") == 0) then
				r_Ang.y = r_Ang.y + AB.set_Get("aim_aa_yaw")
				if (fbSafe == false) then
					r_Ang.y = r_Ang.y - AB.set_Get("aim_aa_yaw")
				elseif (fbSafe == true) then
					r_Ang.y = r_Ang.y + AB.set_Get("aim_aa_yaw")
				end
			else
				if (fbSafe == false) then
					r_Ang.y = r_Ang.y + G.ma_fmod(CurTime() / .1 * 100 * 6, 360)
				elseif (fbSafe == true) then
					r_Ang.y = r_Ang.y - G.ma_fmod(CurTime() / .1 * AB.set_Get("aim_aa_spin") * 6, -360)
				end
			end

			if (AB.set_Get("aim_aa_roll") == 0) then
				r_Ang.r = r_Ang.r
			else
				r_Ang.r = AB.set_Get("aim_aa_roll")
			end
		end

		if (!bBulletTime) then
			SetViewAngles(ucmd, r_Ang)
			a_Dir = Vector(GetForwardMove(ucmd), GetSideMove(ucmd), 0)
			a_Vec = Forward((v_Angle(a_Dir) + (GetViewAngles(ucmd) - FakeAng))) * Length(a_Dir)
			SetForwardMove(ucmd, a_Vec[1])
			SetSideMove(ucmd, -a_Vec[2])
		elseif (t_Acq == false) then
			SetViewAngles(ucmd, r_Ang)
			a_Dir = Vector(GetForwardMove(ucmd), GetSideMove(ucmd), 0)
			a_Vec = Forward((v_Angle(a_Dir) + (GetViewAngles(ucmd) - FakeAng))) * Length(a_Dir)
			SetForwardMove(ucmd, a_Vec[1])
			SetSideMove(ucmd, -a_Vec[2])
		end
	end
end

function AB.h_Adds.CreateMove.TriggerBot(ucmd)
	if (AB.set_Get("aim_trigger") == 1) then
		local Target = EyeTrace(G.lcl_Ply).Entity
		if (Valid(Target) && IsPlayer(Target)) then
			SetButtons(ucmd, G.b_Bor(GetButtons(ucmd), ATTACK))
		else
			RemoveKey(ucmd, ATTACK)
		end
	end
end

function AB.h_Adds.CreateMove.RapidFire(ucmd)
	if (AB.set_Get("misc_rapidfire") == 1) then
		local Wep = ActiveWeapon(G.lcl_Ply)
		if (Valid(Wep)) then
			if (HoldType(Wep) ~= "physgun") then
				if (G.b_Bor(GetButtons(ucmd), ATTACK)) then
					if (GetNextPrimaryFire(Wep) >= ProperCurTime) then
						RemoveKey(ucmd, ATTACK)
					end
				end
			end
		end
	end
end

function AB.h_Adds.CreateMove.SpeedHack()
	if (AB.set_Get("misc_sh_enable") == 1) then
		if (G.inp_KeyDown(AB.set_Get("misc_sh_key"))) then
			G.GetCVar("sv_cheats"):SetValue(1)
			G.GetCVar("host_timescale"):SetValue(AB.set_Get("misc_sh_speed"))
		else
			G.GetCVar("sv_cheats"):SetValue(0)
			G.GetCVar("host_timescale"):SetValue(1)
		end
	end
end

function AB.h_Adds.CreateMove.BunnyHop(ucmd)
	if (AB.set_Get("misc_bhop") == 1) then
		if (KeyDown(ucmd, JUMP)) then
			if (OnGround(G.lcl_Ply)) then
				SetButtons(ucmd, GetButtons(ucmd), JUMP)
			elseif (WaterLevel(G.lcl_Ply) < 2 && GetMoveType(G.lcl_Ply) ~= MOVETYPE_LADDER && !OnGround(G.lcl_Ply)) then
				RemoveKey(ucmd, JUMP)
			end
			if (AB.set_Get("misc_bhop_astrafe") == 1) then
				if (GetMouseX(ucmd) < 0) then
					SetSideMove(ucmd, -10000)
				elseif (GetMouseX(ucmd) > 0) then
					SetSideMove(ucmd, 10000)
				end
			end
		end
	end
end

local Streak = 0
function AB.h_Adds.entity_killed.Kills(data)
	local killer = Entity(data.entindex_attacker)
	local inflictor = Entity(data.entindex_inflictor)
	local victim = Entity(data.entindex_killed)
	if (AB.set_Get("misc_showkills_say") == 1 or AB.set_Get("misc_showkills_print") == 1) then
		if (IsValid(victim) && IsValid(killer) && victim:IsPlayer() && killer:IsPlayer()) then
			if (killer == G.lcl_Ply && victim ~= G.lcl_Ply) then
				Streak = Streak + 1
				if (AB.set_Get("misc_showkills_say") == 1) then
					ConCMD(G.lcl_Ply, "say killed " .. Name(victim) .. " using " .. GetClass(ActiveWeapon(killer)) .. ". Killstreak: " .. Streak .. "!")
				end
				if (AB.set_Get("misc_showkills_print") == 1) then
					AB.ch_AddText("common/null.wav", "Killed ", G.t_GetCol(Team(victim)), Name(victim), color_white, " using ", Color(255, 93, 0), GetClass(ActiveWeapon(killer)), color_white, ". Killstreak: " .. Streak .. "!")
				end
			elseif (killer ~= G.lcl_Ply && victim == G.lcl_Ply && Streak >= 1) then
				if (AB.set_Get("misc_showkills_say") == 1) then
					ConCMD(G.lcl_Ply, "say Killstreak of " .. Streak .. " ended by " .. Name(killer) .. "!")
				end
				if (AB.set_Get("misc_showkills_print") == 1) then
					AB.ch_AddText("common/null.wav", "Killstreak of " .. Streak .. " ended by " .. Name(killer) .. "!")
				end
				Streak = 0
			elseif (killer == G.lcl_Ply && victim == G.lcl_Ply && Streak >= 1) then
				if (AB.set_Get("misc_showkills_say") == 1) then
					ConCMD(G.lcl_Ply, "say suicided! Ending his Killstreak of " .. Streak .. "!")
				end
				if (AB.set_Get("misc_showkills_print") == 1) then
					AB.ch_AddText("common/null.wav", "Suicided! Ending your Killstreak of " .. Streak .. "!")
				end
				Streak = 0
			end
		elseif (IsValid(victim) && victim:IsPlayer() && !killer:IsPlayer()) then
			if (victim == G.lcl_Ply && Streak >= 1) then
				if (AB.set_Get("misc_showkills_say") == 1) then
					ConCMD(G.lcl_Ply, "say died mysteriously! Ending his Killstreak of " .. Streak .. "!")
				end
				if (AB.set_Get("misc_showkills_print") == 1) then
					AB.ch_AddText("common/null.wav", "Died mysteriously! Ending your Killstreak of " .. Streak .. "!")
				end
				Streak = 0
			end
		end
	end

	if (AB.set_Get("misc_log_kills") == 1) and victim:IsPlayer() then
		if !killer:IsPlayer() then
			AB.con_Log("log", "Player ", Color(116, 187, 251), Name(killer), color_white, " was killed by the world. Dumbass. ", color_white, "!\n")
		else
			AB.con_Log("log", "Player ", Color(116, 187, 251), Name(killer), color_white, " killed ", Color(255, 93, 0), Name(victim), color_white, " using ", Color(255, 93, 0), GetClass(ActiveWeapon(killer)), color_white, "!\n")
		end
	end
end
G.Listen("entity_killed")

function AB.h_Adds.player_hurt.Damage(data)
	local userid = data.userid
	local attacker = data.attacker
	local hurter = nil
	if (AB.set_Get("misc_log_dmg") == 1) then
		for _, ply in G.loop, G.p_GetAll() do
			if (attacker == ply:UserID()) then
				hurter = ply
			end
		end
		for _, ply in G.loop, G.p_GetAll() do
			local health = Health(ply) - data.health
			if (userid == ply:UserID()) then
				AB.con_Log("log", "Player ", Color(116, 187, 251), Name(hurter), color_white, " hurt ", Color(255, 93, 0), Name(ply), color_white, " using ", Color(255, 93, 0), GetClass(ActiveWeapon(hurter)), color_white, " with ", Color(116, 187, 251), health, color_white, " damage!\n")
			end
		end
	end

	if (AB.set_Get("misc_log_dmg_snd") == 1) then
		if (attacker == G.lcl_Ply:UserID()) then
			G.snd_PlayFile("sound/hit_snd.wav", "", function(snd)
				if (IsValid(snd)) then snd:Play() end
			end)
		end
	end
end
G.Listen("player_hurt")

function AB.h_Adds.player_connect.Connect(data)
	local name = data.name
	local steamid = data.networkid
	local ip = data.address
	local index = data.index
	AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), name, color_white, "(", Color(255, 93, 0), steamid, color_white, ") joined the server.")
end
G.Listen("player_connect")

function AB.h_Adds.player_disconnect.Disconnect(data)
	local name = data.name
	local steamid = data.networkid
	local reason = data.reason
	AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), name, color_white, "(", Color(255, 93, 0), steamid, color_white, ") left the server(" .. reason .. ")")
end
G.Listen("player_disconnect")

function AB.FakeAim(ply, pos, ang, fov, nearZ, farZ)
	if (AB.set_Get("aim_silent") == 1 or AB.set_Get("aim_psilent") == 1 or AB.set_Get("aim_aa") == 1) then
		local view = {}
			view.origin = pos
			view.angles = AB.aim_GetAng()
			view.fov = fov
		return view
	end
end
AB.h_Add("CalcView", AB.FakeAim)

function AB.FixAim(wep, vm, oldPos, oldAng, pos, ang)
	if (AB.set_Get("aim_silent") == 1 or AB.set_Get("aim_psilent") == 1 or AB.set_Get("aim_aa") == 1) then
		return oldPos, AB.aim_GetAng()
	end
end
AB.h_Add("CalcViewModelView", AB.FixAim)

function AB.h_Adds.Think.ColorUpdate()
	AB.MColCvar = AB.set_Get("misc_theme_color")
	AB.MCol = Color(unpack(G.str_Explode(",", AB.set_Get("misc_theme_color"))))
	AB.Var = G.ma_abs(G.ma_sin( CurTime() * 3))
	AB.DLTCol = Color(AB.MCol.r, AB.MCol.g, AB.MCol.b, AB.Var * AB.MCol.a)
end

function AB.h_Adds.Think.NoRecoil()
	if (AB.set_Get("aim_norecoil") == 1) then
		if (Valid(ActiveWeapon(G.lcl_Ply))) then
			local Wep = ActiveWeapon(G.lcl_Ply)	
			if (Wep.Primary) then
				Wep.Primary.CalcView = function(ply, origin, angles, fov) end
				Wep.Primary.HipCone = 0
				Wep.Primary.AimCone = 0
				Wep.Primary.SpreadPerShot = 0
				Wep.Primary.MaxSpreadInc = 0
				Wep.Primary.SpreadCooldown = 0
				Wep.Primary.VelocitySensitivity = 0
				Wep.Primary.AimFOV = 0
				Wep.Primary.ViewKick = 0
				Wep.Primary.Recoil = 0
				if (Wep.Primary.KickUp) then
					Wep.Primary.KickUp = 0
					Wep.Primary.KickDown = 0
					Wep.Primary.KickHorizontal = 0
				end
			end
			if (Wep.Secondary) then
				Wep.Secondary.CalcView = function(ply, origin, angles, fov) end
				Wep.Secondary.HipCone = 0
				Wep.Secondary.AimCone = 0
				Wep.Secondary.SpreadPerShot = 0
				Wep.Secondary.MaxSpreadInc = 0
				Wep.Secondary.SpreadCooldown = 0
				Wep.Secondary.VelocitySensitivity = 0
				Wep.Secondary.AimFOV = 0
				Wep.Secondary.ViewKick = 0
				Wep.Secondary.Recoil = 0
			end
		end
	elseif Valid(ActiveWeapon(G.lcl_Ply)) then
		local Wep = ActiveWeapon(G.lcl_Ply)
		if (Wep.Primary) then
			Wep.Primary.Recoil = Wep.OldRecoil or Wep.Primary.Recoil or Wep.Recoil
			Wep.Recoil = Wep.OldRecoil or Wep.Recoil or Wep.Primary.Recoil
		else
			Wep.Recoil = Wep.OldRecoil or Wep.Recoil
		end
	end
end

function AB.h_Adds.Think.Spam()
	if (AB.set_Get("misc_chatspam") == 1) then
		G.run_CCmd("say", AB.set_Get("misc_chatspam_msg"))
	end
	if (AB.set_Get("misc_cmdspam") == 1) then
		ConCMD(G.lcl_Ply, AB.set_Get("misc_cmdspam_msg"))
	end
end

function AB.h_Adds.Think.Lights()
	if (AB.set_Get("light_penabled") == 1) then
		G.lcl_Ply = G.lcl_Ply
		if (!Valid(G.lcl_Ply)) then 
			return 
		end
		local PBrightness = AB.set_Get("light_pbrightness")
		local PSize = AB.set_Get("light_psize")
		for _, ply in G.loop, G.p_GetAll() do
			if AB.check_Player(ply) then
				local pLight = DynamicLight(ply:EntIndex())
				if (pLight) then
				local colour = G.t_GetCol(Team(ply))
					pLight.Pos = GetPos(ply) + Vector(0, 0, 10)
					pLight.r = colour.r
					pLight.g = colour.g
					pLight.b = colour.b
					pLight.Brightness = PBrightness
					pLight.Decay = PSize * 5
					pLight.Size = PSize
					pLight.DieTime = CurTime() + 1
				end
			end
		end
	end
end

AB.t_Create(1, 0, function()
	for _, ply in G.loop, G.p_GetAll() do
		if (GetModel(ply) == "models/error.mdl") then
			SetModel(ply, "models/player/group01/female_02.mdl")
		end
	end
end)

AB.t_Create(1, 0, function()
	if (AB.set_Get("misc_showspec") == 1) then
		for _, v in G.loop, G.p_GetAll() do
			if (Valid(ObserverTarget(v)) && IsPlayer(ObserverTarget(v)) && ObserverTarget(v) == G.lcl_Ply) then
				if (not G.tbl_HasVal(AB.QTBL[7], v)) then
					G.tbl_Insert(AB.QTBL[7], v)
					AB.ch_AddText("npc/scanner/combat_scan3.wav", G.t_GetCol(Team(v)), Name(v), color_white, " is now spectating you.")
				end
			end
		end
	end

	if (AB.set_Get("misc_showspec") == 1) then
		for k, v in G.loop, AB.QTBL[7] do
			if (not Valid(v) or not Valid(ObserverTarget(v)) or not IsPlayer(ObserverTarget(v)) or (ObserverTarget(v) ~= G.lcl_Ply)) then
				G.tbl_Rem(AB.QTBL[7], k)
				AB.ch_AddText("npc/scanner/combat_scan2.wav", Color(0, 201, 0), Name(v), color_white, " is no longer spectating you.")
			end
		end
	end

	if (AB.set_Get("misc_showadmins") == 1) then
		for _, v in G.loop, G.p_GetAll() do
			if (AB.check_Admin(v) && not G.tbl_HasVal(AB.QTBL[9], v)) then
				G.tbl_Insert(AB.QTBL[9], v)
				AB.ch_AddText("npc/scanner/combat_scan1.wav", color_white, "Admin ", G.t_GetCol(Team(v)), Name(v), color_white, " detected.")
			elseif (AB.check_Super(v) && not G.tbl_HasVal(AB.QTBL[8], v)) then
				G.tbl_Insert(AB.QTBL[8], v)
				AB.ch_AddText("npc/scanner/combat_scan1.wav", color_white, "Super Admin ", G.t_GetCol(Team(v)), Name(v), color_white, " detected.")
			elseif (AB.check_Mod(v) && not G.tbl_HasVal(AB.QTBL[10], v)) then
				G.tbl_Insert(AB.QTBL[10], v)
				AB.ch_AddText("npc/scanner/combat_scan1.wav", color_white, "Moderator ", G.t_GetCol(Team(v)), Name(v), color_white, " detected.")
			 end
		end
	end

	for k, v in SortedPairs(AB.QTBL[10], true) do
		if not Valid(v) then
			G.tbl_Rem(AB.QTBL[10], k)
		end
	end

	for k, v in SortedPairs(AB.QTBL[9], true) do
		if not Valid(v) then
			G.tbl_Rem(AB.QTBL[9], k)
		end
	end

	for k, v in SortedPairs(AB.QTBL[8], true) do
		if not Valid(v) then
			G.tbl_Rem(AB.QTBL[8], k)
		end
	end
end)

AB.t_Create(2, 0, function()
	if (AB.set_Get("misc_antiafk") == 1) then
		local CMD1 = G.tbl_Rand(AB.QTBL[16])
		local CMD2 = G.tbl_Rand(AB.QTBL[16])
		G.t_Simple(1, function()
			G.run_CCmd("+" .. CMD1)
			G.run_CCmd("+" .. CMD2)
		end)
		G.t_Simple(2, function()
			G.run_CCmd("-" .. CMD1)
			G.run_CCmd("-" .. CMD2)
		end)
	end
end)

/*=============
Hook Adding End|
===============*/

---------------------

/*===================
Derma/GUI Menus Start|
=====================*/

function AB.ENTMenu()
	local EntMe = G.vg_Create("DFrame")
	EntMe:SetSize(400, 400)
	EntMe:SetTitle("")
	EntMe:Center()
	EntMe.btnMaxim:Hide()
	EntMe.btnMinim:Hide() 
	EntMe:MakePopup()
	function EntMe:Paint()
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide() / 32, self:GetTall() / 32)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, self:GetWide(), 22)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawOutRect(0, 0, self:GetWide(), self:GetTall())
	end
	
	local EntLi = G.vg_Create("DPanelList", EntMe)
	EntLi:SetSize(EntMe:GetWide() - 20, EntMe:GetTall() - 30)
	EntLi:SetPos(5, 50)
	EntLi:SetSpacing(0)
	
	local EntPa = G.vg_Create("DPanel", EntMe)
	EntPa:SetSize(EntMe:GetWide() - 10, EntMe:GetTall() - 10)
	EntPa.Paint = function()
		G.dr_RoundBox(0, 0, 0, 0, 0, color_black)
	end
	EntLi:AddItem(EntPa)
	
	local VisibleLi = {}
	local NotVisibleLi = {}
	local All = G.e_GetAll()
	for k = 1, #All do
		local v = All[k]	
		if G.tbl_HasVal(AB.QTBL[6], GetClass(v)) then
			if not G.tbl_HasVal(VisibleLi, GetClass(v)) then
				G.tbl_Insert(VisibleLi, GetClass(v))
			end
		elseif not G.tbl_HasVal(NotVisibleLi, GetClass(v)) then
			G.tbl_Insert(NotVisibleLi, GetClass(v))
		end
	end
	
	local NotVisible = G.vg_Create("DListView", EntPa)
	local Visible = G.vg_Create("DListView", EntPa)
	Visible:SetSize(150, 320)
	Visible:SetPos(EntPa:GetWide() * 0.25 - Visible:GetWide() / 2, 0)
	Visible:SetMultiSelect(false)
	Visible:AddColumn("Visible")
	for k = 1, #VisibleLi do
		Visible:AddLine(VisibleLi[k])
	end
	
	Visible.DoDoubleClick = function(panel, index, line)
		G.tbl_Insert(NotVisibleLi, VisibleLi[index])
		G.tbl_Rem(VisibleLi, index)
		Visible:Clear()
		NotVisible:Clear()
		for k = 1, #VisibleLi do
			Visible:AddLine(VisibleLi[k])
		end
		for k = 1, #NotVisibleLi do
			NotVisible:AddLine(NotVisibleLi[k])
		end
		AB.QTBL[6] = {}
		for k = 1, #VisibleLi do
			G.tbl_Insert(AB.QTBL[6], VisibleLi[k])
		end
	end
	
	NotVisible:SetSize(150, 320)
	NotVisible:SetPos(EntPa:GetWide() * 0.75 - NotVisible:GetWide() / 2, 0)
	NotVisible:SetMultiSelect(false)
	NotVisible:AddColumn("Not Visible")
	for k = 1, #NotVisibleLi do
		NotVisible:AddLine(NotVisibleLi[k])
	end
	NotVisible.DoDoubleClick = function(panel, index, line)
		G.tbl_Insert(VisibleLi, NotVisibleLi[index])
		G.tbl_Rem(NotVisibleLi, index)
		Visible:Clear()
		NotVisible:Clear()
		for k = 1, #VisibleLi do
			Visible:AddLine(VisibleLi[k])
		end
		for k = 1, #NotVisibleLi do
			NotVisible:AddLine(NotVisibleLi[k])
		end
		AB.QTBL[6] = {}
		for k = 1, #VisibleLi do
			G.tbl_Insert(AB.QTBL[6], VisibleLi[k])
		end
	end
end

function AB.PLYMenu()
	local PlyMe = G.vg_Create("DFrame")
	PlyMe:SetSize(600, 400)
	PlyMe:SetTitle("")
	PlyMe:Center()
	PlyMe.btnMaxim:Hide()
	PlyMe.btnMinim:Hide() 
	PlyMe:MakePopup()
	function PlyMe:Paint()
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide() / 32, self:GetTall() / 32)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, self:GetWide(), 22)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawOutRect(0, 0, self:GetWide(), self:GetTall())
	end

	local PlyPanel = G.vg_Create("DPanelList", PlyMe)
	PlyPanel:SetName("log_tab")
	PlyPanel:SetPos(2, 27)
	PlyPanel:SetSize(PlyMe:GetWide() - 4, PlyMe:GetTall() - 40)
	PlyPanel:SetSpacing(10)
	PlyPanel:EnableHorizontal(false)
	PlyPanel:EnableVerticalScrollbar(false)

	local PlyView = G.vg_Create("DListView", PlyPanel)
	PlyView:SetPos(10, 2)
	PlyView:SetMultiSelect(false)
	PlyView:SetSize(PlyPanel:GetWide() - 20, PlyPanel:GetTall() - 5)
	local line1 = PlyView:AddColumn("Name")
	PlyView:AddColumn("Rank")
	PlyView:AddColumn("SteamID")
	PlyView:AddColumn("Kills")
	PlyView:AddColumn("Deaths")
	if AB.GMRP() then
		PlyView:AddColumn("Job")
		PlyView:AddColumn("Money")
	end
	local CPlys = G.tbl_Copy(G.p_GetAll())
	for _, v in G.loop, CPlys do
		local Money = v:GetNetworkedInt("money")
		if v.DarkRPVars and v.DarkRPVars.money then
			Money = v.DarkRPVars.money
		end
		PlyView:AddLine(Name(v), G.str_Lower(NetworkedString(v, "UserGroup")), SteamID(v), Frags(v), Deaths(v), team.GetName(Team(v)), "$" ..  AB.ma_Format(Money), v)
	end

	PlyView.OnRowSelected = function(Par, Line) 
		local DFrame = DermaMenu()
		local ply = PlyView:GetLine(Line):GetValue(8)
		if not (G.tbl_HasVal(AB.QTBL[5], Name(ply))) then
			DFrame:AddOption("Add to Friends(Aimbot)", function() 
				G.tbl_Insert(AB.QTBL[5], Name(ply))
				AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), Name(ply), color_white, " added to friends list(aimbot).")
			end):SetIcon("icon16/user_add.png")
		end
		
		local aaSubM, aaSubM_ = DFrame:AddSubMenu("AAA", function() end)
		aaSubM_:SetIcon("icon16/arrow_in.png")
		
		aaSubM:AddOption("None", function()
			G.tbl_Rem(aaCenter, #PlyView:GetLine(Line):GetValue(1)[1])
			G.tbl_Insert(aaNone, Name(ply))
			AB.ch_AddText("common/null.wav", "AAA method 'none' applied to ", Color(116, 187, 251), Name(ply), color_white, ".")
		end):SetIcon("icon16/cross.png")
		
		aaSubM:AddOption("Default", function()
			G.tbl_Rem(aaNone, #PlyView:GetLine(Line):GetValue(1)[1])
			G.tbl_Rem(aaCenter, #PlyView:GetLine(Line):GetValue(1)[1])
			AB.ch_AddText("common/null.wav", "AAA method 'default' applied to ", Color(116, 187, 251), Name(ply), color_white, ".")
		end):SetIcon("icon16/arrow_rotate_clockwise.png")

		aaSubM:AddOption("OBBCenter", function()
			G.tbl_Rem(aaNone, #PlyView:GetLine(Line):GetValue(1)[1])
			G.tbl_Insert(aaCenter, Name(ply))
			AB.ch_AddText("common/null.wav", "AAA method 'OBBCenter' applied to ", Color(116, 187, 251), Name(ply), color_white, ".")
		end):SetIcon("icon16/arrow_rotate_anticlockwise.png")
		
		if (G.tbl_HasVal(AB.QTBL[5], PlyView:GetLine(Line):GetValue(1))) then
			DFrame:AddOption("Remove From Friends(Aimbot)", function()
				G.tbl_Rem(AB.QTBL[5], #PlyView:GetLine(Line):GetValue(1)[1])
				AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), Name(ply), color_white, " removed from friends list(aimbot).")
			end):SetIcon("icon16/user_delete.png")
		end

		DFrame:AddOption("Copy Name", function() 
			SetClipboardText(PlyView:GetLine(Line):GetValue(1))
			AB.ch_AddText("common/null.wav", "Player name ", Color(116, 187, 251), Name(ply), color_white, " copied to clipboard.")
		end):SetIcon("icon16/user_go.png")

		DFrame:AddOption("Copy SteamID", function() 
			SetClipboardText(PlyView:GetLine(Line):GetValue(3))
			AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), Name(ply), color_white, " SteamID ", Color(255, 93, 0), SteamID(ply), color_white, " copied to clipboard.")			
		end):SetIcon("icon16/table_go.png")

		DFrame:AddOption("Open Profile", function() 
			ply:ShowProfile()
			AB.ch_AddText("common/null.wav", "Opened ", Color(116, 187, 251), Name(ply), color_white, " Steam profile.")
		end):SetIcon("icon16/world_link.png")

		if (Muted(ply) == false) then
			DFrame:AddOption("Mute", function()
				SetMuted(ply, true)
				AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), Name(ply), color_white, " has been muted.")
			end):SetIcon("icon16/sound_mute.png")
		end

		if (Muted(ply) == true) then
			DFrame:AddOption("Unmute", function()
				SetMuted(ply, false)
				AB.ch_AddText("common/null.wav", "Player ", Color(116, 187, 251), Name(ply), color_white, " has been unmuted.")
			end):SetIcon("icon16/sound.png")
		end

		if (AB.GMRP()) then
			DFrame:AddOption("Copy Money", function() 
				SetClipboardText(PlyView:GetLine(Line):GetValue(7))
				AB.ch_AddText("common/null.wav", "Copied ", Color(116, 187, 251), Name(ply), color_white, " money of ", Color(0, 201, 0), PlyView:GetLine(Line):GetValue(7), color_white, " copied to clipboard.")
			end):SetIcon("icon16/money.png")
		end
		DFrame:Open() 
	end
end

function AB.FrMenu()
	local FriMe = G.vg_Create("DFrame")
	FriMe:SetSize(400, 400)
	FriMe:SetTitle("")
	FriMe:Center()
	FriMe.btnMaxim:Hide()
	FriMe.btnMinim:Hide() 
	FriMe:MakePopup()
	function FriMe:Paint()
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide() / 32, self:GetTall() / 32)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, self:GetWide(), 22)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawOutRect(0, 0, self:GetWide(), self:GetTall())
	end
	
	local FriLi = G.vg_Create("DPanelList", FriMe)
	FriLi:SetSize(FriMe:GetWide() - 20, FriMe:GetTall() - 30)
	FriLi:SetPos(5, 50)
	FriLi:SetSpacing(0)
	
	local FriPa = G.vg_Create("DPanel", FriMe)
	FriPa:SetSize(FriMe:GetWide() - 10, FriMe:GetTall() - 10)
	FriPa.Paint = function()
		G.dr_RoundBox(0, 0, 0, 0, 0, AB.MCol)
	end
	FriLi:AddItem(FriPa)
	
	local Friends = {}
	local Enemies = {}
	for k = 1, #G.p_GetAll() do
		local v = G.p_GetAll()[k]	
		if (G.tbl_HasVal(AB.QTBL[5], Name(v))) then
			if not G.tbl_HasVal(Friends, Name(v)) then
				G.tbl_Insert(Friends, Name(v))
			end
		elseif not (G.tbl_HasVal(Enemies, Name(v))) then
			G.tbl_Insert(Enemies, Name(v))
		end
	end
	
	local MEnemies = G.vg_Create("DListView", FriPa)
	local MFriends = G.vg_Create("DListView", FriPa)
	MFriends:SetSize(150, 320)
	MFriends:SetPos(FriPa:GetWide() * 0.25 - MFriends:GetWide() / 2, 0)
	MFriends:SetMultiSelect(false)
	MFriends:AddColumn("Friends")
	for k = 1, #Friends do
		MFriends:AddLine(Friends[k])
	end
	
	MFriends.DoDoubleClick = function(panel, index, line)
		G.tbl_Insert(Enemies, Friends[index])
		G.tbl_Rem(Friends, index)
		MFriends:Clear()
		MEnemies:Clear()
		for k = 1, #Friends do
			MFriends:AddLine(Friends[k])
		end
		for k = 1, #Enemies do
			MEnemies:AddLine(Enemies[k])
		end
		AB.QTBL[5] = {}
		for k = 1, #Friends do
			G.tbl_Insert(AB.QTBL[5], Friends[k])
		end
	end
	
	MEnemies:SetSize(150, 320)
	MEnemies:SetPos(FriPa:GetWide() * 0.75 - MEnemies:GetWide() / 2, 0)
	MEnemies:SetMultiSelect(false)
	MEnemies:AddColumn("Enemies")
	for k = 1, #Enemies do
		MEnemies:AddLine(Enemies[k])
	end
	MEnemies.DoDoubleClick = function(panel, index, line)
		G.tbl_Insert(Friends, Enemies[index])
		G.tbl_Rem(Enemies, index)
		MFriends:Clear()
		MEnemies:Clear()
		for k = 1, #Friends do
			MFriends:AddLine(Friends[k])
		end
		for k = 1, #Enemies do
			MEnemies:AddLine(Enemies[k])
		end
		AB.QTBL[5] = {}
		for k = 1, #Friends do
			G.tbl_Insert(AB.QTBL[5], Friends[k])
		end
	end
end

function AB.FindMurder()
	for _, ply in pairs (ents.GetAll()) do 
		local owner = ply.Owner
		if IsValid(owner) then
			if table.HasValue(AB.mknife, ply:GetClass()) then
				AB.ch_AddText("common/null.wav", owner:GetNWString("bystanderName"), " is probably the murderer!")
			end
		end
	end
end

function AB.LogMenu()
	local LFrame = G.vg_Create("DFrame")
	LFrame:SetSize(650, 360)
	LFrame:SetTitle("")
	LFrame:Center()
	LFrame.btnMaxim:Hide()
	LFrame.btnMinim:Hide()
	LFrame:MakePopup()
	function LFrame:Paint()
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(0, 0, LFrame:GetWide(), LFrame:GetTall(), 0, 0, LFrame:GetWide() / 32, LFrame:GetTall() / 32)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, LFrame:GetWide(), 22)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawOutRect(0, 0, LFrame:GetWide(), LFrame:GetTall())
	end

	local LogPanel = G.vg_Create("DPanelList", LFrame)
	LogPanel:SetName("log_tab")
	LogPanel:SetPos(2, 27)
	LogPanel:SetSize(LFrame:GetWide() - 4, LFrame:GetTall() - 40)
	LogPanel:SetSpacing(10)
	LogPanel:EnableHorizontal(false)
	LogPanel:EnableVerticalScrollbar(false)

	local LogView = G.vg_Create("DListView", LogPanel)
	LogView:SetPos(122, 2)
	LogView:SetMultiSelect(false)
	LogView:SetSize(LogPanel:GetWide() - 139, LogPanel:GetTall() - 3)
	LogView:AddColumn("Time"):SetFixedWidth(80)
	LogView:AddColumn("Logs (" .. G.tbl_Count(AB.QTBL[2]) .. ")")
	for i = #AB.QTBL[2], 1, -1 do
		LogView:AddLine(AB.QTBL[3][i], AB.QTBL[2][i])
	end
	
	LogView.OnRowSelected = function(Par, Line) 
		local DFrame = DermaMenu()
		DFrame:AddOption("Copy Line", function() 
			SetClipboardText(LogView:GetLine(Line):GetValue(1) .. " " .. LogView:GetLine(Line):GetValue(2)) 
		end)
		DFrame:Open() 
	end

	local Clear = G.vg_Create("DButton", LogPanel)
	Clear:SetText("Clear")
	Clear:SetSize(100, 20)
	Clear:SetPos(10, 10)
	Clear:SetTextColor(color_white)
	Clear.DoClick = function()
		G.sur_PlaySnd("UI/buttonclickrelease.wav")
		LogView:Clear()
		AB.QTBL[2] = {}
	end
	Clear.OnCursorEntered = function()
		G.sur_PlaySnd("UI/buttonrollover.wav")
		Clear:SetTextColor(Color(150, 150, 150, 255))
	end
	Clear.OnCursorExited = function()
		Clear:SetTextColor(color_white)
	end
	Clear.Paint = function()
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, Clear:GetWide(), Clear:GetTall())
	end
	
	local Update = G.vg_Create("DButton", LogPanel)
	Update:SetText("Update")
	Update:SetSize(100, 20)
	Update:SetPos(10, 40)
	Update:SetTextColor(color_white)
	Update.DoClick = function()
		G.sur_PlaySnd("UI/buttonclickrelease.wav")
		LogView:Clear()
		for i = #AB.QTBL[2], 1, -1 do
			LogView:AddLine(AB.QTBL[3][i], AB.QTBL[2][i])
		end
	end
	Update.OnCursorEntered = function()
		G.sur_PlaySnd("UI/buttonrollover.wav")
		Update:SetTextColor(Color(150, 150, 150, 255))
	end
	Update.OnCursorExited = function()
		Update:SetTextColor(color_white)
	end
	Update.Paint = function()
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, Update:GetWide(), Update:GetTall())
	end
end

local MENU_TABS = {}
	MENU_TABS[1] = "Aimbot"
	MENU_TABS[2] = "Visuals"
	MENU_TABS[3] = "Misc"
	MENU_TABS[4] = "HvH"
	MENU_TABS[5] = "Logging"
	MENU_TABS[6] = "Design"

local MENU_ITEMS = {}
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_toggle", text = "Toggle", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_autofire", text = "Auto Fire", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_los", text = "Check LOS", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_trigger", text = "Trigger Bot", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_psilent", text = "Perfect Silent Aim", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_silent", text = "Silent Aim", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_players", text = "Ignore Players", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_npcs", text = "Ignore NPCs", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_friends", text = "Ignore Friends", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_team", text = "Ignore Teammates", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_spawnpro", text = "Ignore Spawn Protection", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_fov", text = "Field of View", t = "slider", deci = 1, min = 0, max = 360})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_distance", text = "Distance", t = "slider", deci = 0, min = 0, max = 25650})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", func = AB.FrMenu, text = "Friends Menu", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", text = "Aim Key", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_key", text = "Aim Key", t = "combobox_keys", tbl = AB.QTBL[21]})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", text = "Bone Position", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_targetspot", text = "Bone Position", t = "combobox", tbl = AB.QTBL[11]})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", text = "Player Info", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp", text = "Enable ESP", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_info_rank", text = "Rank", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_info_name", text = "Name", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_info_health", text = "Health", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_info_weapon", text = "Weapon", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_info_distance", text = "Distance", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_ents", text = "ENTs", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_distance", text = "Distance", t = "slider", deci = 0, min = 0, max = 25650})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", text = "Chams", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_chams_players", text = "Players", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_chams_players_wpn", text = "Weapons", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_chams_ents", text = "ENTs", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_chams_xqz", text = "XQZ", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_distance_chams", text = "Distance", t = "slider", deci = 0, min = 0, max = 25650})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", text = "Lasers", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_barrel_laser", text = "Barrel Laser", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_head_laser", text = "Head Laser", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_ground_laser", text = "Ground Laser", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", text = "Lights", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "light_penabled", text = "Dynamic Lights", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "light_psize", text = "Dynamic Lights Size", t = "slider", deci = 0, min = 0, max = 1000})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "light_pbrightness", text = "Dynamic Lights Brightness", t = "slider", deci = 1, min = 0, max = 10})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", text = "Misc", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_skeleton", text = "Skeleton", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_hitbox", text = "Hitboxes", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_2dbox", text = "2DBox", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_2dbox_ent", text = "2DBox - ENTs", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_hpbar", text = "HP-Bar", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", convar = "esp_distance_box", text = "Distance", t = "slider", deci = 0, min = 0, max = 25650})
	G.tbl_Insert(MENU_ITEMS, {tab = "Visuals", func = AB.ENTMenu, text = "Entity Finder Menu", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", text = "Radar", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "radar", text = "Enable Radar", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "radar_x", text = "Position X", t = "slider", deci = 0, min = 0, max = ScrW() - 255})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "radar_y", text = "Position Y", t = "slider", deci = 0, min = 0, max = ScrH() - 255})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "radar_distance", text = "Distance", t = "slider", deci = 0, min = 0, max = 25650})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", text = "Speedhack", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_sh_enable", text = "Speedhack", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_sh_key", text = "Speedhack Key", t = "combobox_keys", tbl = AB.QTBL[21]})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_sh_speed", text = "Speedhack Speed", t = "slider", deci = 1, min = 1, max = 10})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", text = "Spam", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_cmdspam", text = "Command Spam", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_cmdspam_msg", text = "Command Spam", t = "tentry"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_chatspam", text = "Chat Spam", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_chatspam_msg", text = "Chat Spam", t = "tentry"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", text = "Other", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_crosshair", text = "Crosshair", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_rapidfire", text = "Rapid Fire", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_log_dmg_snd", text = "Hit Sounds", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_nohands", text = "No Hands", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_bhop", text = "Bunnyhop", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_tfinder", text = "Traitor Finder", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_bhop_astrafe", text = "Autostrafe", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showkills_say", text = "Say Kills", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showkills_print", text = "Print Kills", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_antiafk", text = "Anti-AFK", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_speclist", text = "Display Spectators", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showspec", text = "Spectator Alerts", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showadmins", text = "Admin Alerts", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc",  text = "Force CVar", t = "dbutton_cv"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", func = AB.PLYMenu, text = "Player Info Menu", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", func = AB.ServerStats, text = "Server Stats", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Misc", func = AB.FindMurder, text = "Find Murderer", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_fakelag", text = "Fake Lag", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_fakelag_rate", text = "Fake Lag Rate", t = "slider", deci = 0, min = 1, max = 100})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_bone", text = "Target Bones", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_hitbox", text = "Target Hitboxes", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_bscan", text = "Bone Scan", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aaaa", text = "Anti Anti Anti-Aim", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aaa", text = "Anti Anti-Aim", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aaa_fb", text = "Anti Anti-Aim - Fallback", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa", text = "Anti-Aim", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa_pitch", text = "Pitch", t = "slider", deci = 0, min = -360, max = 360})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa_yaw", text = "Yaw", t = "slider", deci = 0, min = -360, max = 360})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa_roll", text = "Roll", t = "slider", deci = 0, min = -360, max = 360})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa_spin", text = "Spin Speed", t = "slider", deci = 0, min = 0, max = 500})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", text = "Anti-Aim Method", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "HvH", convar = "aim_aa_type", text = "Anti-Aim Method", t = "combobox_keys", tbl = AB.QTBL[15]})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "misc_chat_msgs", text = "Chat Notifications", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "misc_logging", text = "Console Logging", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "misc_logging_snd", text = "Console Logging Sounds", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "misc_log_kills", text = "Kills", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "misc_log_dmg", text = "Damage", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fwrite", text = "file.Write", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_ftime", text = "file.Time", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fappend", text = "file.Append", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fsize", text = "file.Size", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fopen", text = "file.Open", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fread", text = "file.Read", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fexistsex", text = "file.ExistsEx", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fexists", text = "file.Exists", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_fisdir", text = "file.IsDir", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_concmd", text = ":ConCommand()", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_sendlua", text = ":SendLua()", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_ip", text = ":IPAddress()", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_rcc", text = "RunConsoleCommand", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_GetCVarnum", text = "GetConVarNum", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_GetCVarstr", text = "GetConVarString", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_cvars", text = "cvar.", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_cvars_num", text = "ConVar Number", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_cvars_str", text = "ConVar String", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_cvars_bool", text = "ConVar Bool", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_tcreate", text = "timer.Create", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_tsimple", text = "timer.Simple", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_hookadd", text = "hook.Add", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_hookrem", text = "hook.Remove", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_hookcall", text = "hook.Call", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_runstring", text = "RunString", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_compstring", text = "CompileString", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_nreceive", text = "net.Receive", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_nincoming", text = "net.Incoming", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_nsend", text = "net.Send", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_nstserver", text = "net.SendToServer", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_nstart", text = "net.Start", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", convar = "detour_umsg", text = "usermessage.IncomingMessage", t = "checkbox"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Logging", func = AB.LogMenu, text = "Log Menu", t = "dbutton"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Design", text = "Theme Color", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Design", convar = "misc_theme_color", text = "Theme Color", t = "cmixer"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Design", text = "Crosshair Color", t = "label"})
	G.tbl_Insert(MENU_ITEMS, {tab = "Design", convar = "misc_crosshair_col", text = "Crosshair Color", t = "cmixer"})

local AOpen = false
function AB.Menu()
	local Frame = G.vg_Create("DFrame")
	Frame:SetPos(ScrW()/2 - 300, ScrH()/2 - 233)
	Frame:SizeTo(600, 465, .3, 0, .3)
	Frame:SetTitle("")
	Frame:SetSizable(false)
	Frame:SetDraggable(false)
	Frame:ShowCloseButton(false)
	Frame.btnMaxim:Hide()
	Frame.btnMinim:Hide() 
	Frame:MakePopup()
	function Frame:Paint()
		G.sur_SetMat(Material("background.png", "noclamp"))
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawTxtRectUV(0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide()/32, self:GetTall()/32)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawRect(0, 0, self:GetWide(), 22)
		G.sur_SetDrawCol(AB.MCol)
		G.sur_DrawOutRect(0, 0, self:GetWide(), self:GetTall())
	end

	G.t_Simple(.4, function()
		local CloseB = G.vg_Create("DButton", Frame)
		CloseB:SetPos(Frame:GetWide() - 35, 5)
		CloseB:SetSize(30, 15)
		CloseB:SetText("X")
		CloseB:SetTextColor(color_white)
		CloseB.DoClick = function(self)
			G.sur_PlaySnd("UI/buttonclickrelease.wav")
			Frame:SizeTo(0, 0, .2, 0, .2)
			G.t_Simple(.3, function()
				Frame:Close()
				AOpen = false
			end)
		end
		CloseB.OnCursorEntered = function()
			G.sur_PlaySnd("UI/buttonrollover.wav")
			CloseB:SetTextColor(Color(150, 150, 150, 255))
		end
		CloseB.OnCursorExited = function()
			CloseB:SetTextColor(color_white)
		end
		CloseB.Paint = function()
			local Col = AB.MCol
			G.sur_SetDrawCol(Color(Col.r/2, Col.g/2, Col.b/2))
			G.sur_DrawRect(0, 0, CloseB:GetWide(), CloseB:GetTall())
		end

		local Logo = G.vg_Create("DLabel", Frame)
		Logo:SetFont("LogoF")
		Logo:SetText("Ampris")
		Logo:SetPos(35, 180)
		Logo:SetSize(200, 200)
		function Logo:Paint() // Only way for DLabels to be 'updated'
			Logo:SetTextColor(AB.MCol)
		end

		local Cred = G.vg_Create("DLabel", Frame)
		Cred:SetFont("Credits")
		Cred:SetText("A private gLua cheat by Robby.")
		Cred:SetPos(20, 210)
		Cred:SetSize(200, 200)
		function Cred:Paint()
			Cred:SetTextColor(AB.MCol)
		end

		local TabList = G.vg_Create("DColumnSheet", Frame)
		TabList:SetSize(Frame:GetWide() - 40, Frame:GetTall() - 30)
		TabList:SetPos(10, 30)
		TabList.ButtonOnly = true

		function TabList.Content:Paint() end

		for _, v in G.loop, MENU_TABS do
			local Panel = G.vg_Create("DPanelList", TabList)
			local p_Item = TabList:AddSheet(v, Panel , "models/effects/vol_light001")
			Panel:SetSize(TabList:GetWide() - 200, TabList:GetTall() - 10)
			Panel:EnableVerticalScrollbar(true)
			Panel:SetSpacing(5)
			Panel:SetPadding(5)
			function Panel:Paint()
				G.sur_SetDrawCol(Color(0, 0, 0, 102))
				G.sur_DrawRect(0, 0, self:GetWide(), self:GetTall())
			end

			for _, _v in G.loop, MENU_ITEMS do
				if (_v.tab == v) then
					if (_v.t == "checkbox") then
						local Item = G.vg_Create("DButton")
						Item:SetText("")
						Item:SetSize(15, 15)
						if (AB.set_Get(_v.convar) == 1) then
							Item:SetTextColor(color_white)
						elseif (AB.set_Get(_v.convar) == 0) then
							Item:SetTextColor(color_black)
						end
						Item.DoClick = function(self)
							G.sur_PlaySnd("UI/buttonclickrelease.wav")
							if (AB.set_Get(_v.convar) == 1) then
								AB.set_Change(_v.convar, 0)
								Item:SetTextColor(color_black)
							elseif (AB.set_Get(_v.convar) == 0) then
								AB.set_Change(_v.convar, 1)
								Item:SetTextColor(color_white)
							end
						end
						Item.Paint = function()
							local Col = AB.MCol
							G.dr_DrTxt(_v.text, "CBox", 0, 2, Color(255,255,255,255), TEXT_ALIGN_LEFT )
							if (AB.set_Get(_v.convar) == 1) then
								G.sur_SetDrawCol(AB.MCol)
								G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
								G.sur_SetDrawCol(color_white)
								G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
							elseif (AB.set_Get(_v.convar) == 0) then
								G.sur_SetDrawCol(color_white)
								G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
								G.sur_SetDrawCol(AB.MCol)
								G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
							end
						end
						Item.OnCursorEntered = function()
							if (AB.set_Get(_v.convar) == 1) then
								Item:SetTextColor(color_black)
							elseif (AB.set_Get(_v.convar) == 0) then
								Item:SetTextColor(Color(150, 150, 150, 255))
							end
							Item.Paint = function()
								local Col = AB.MCol
								G.dr_DrTxt(_v.text, "CBox", 0, 2, Color(255,255,255,255), TEXT_ALIGN_LEFT )
								if (AB.set_Get(_v.convar) == 1) then
									G.sur_SetDrawCol(Color(Col.r/1.25, Col.g/1.25, Col.b/1.25))
									G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
									G.sur_SetDrawCol(color_white)
									G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
								elseif (AB.set_Get(_v.convar) == 0) then
									G.sur_SetDrawCol(Color(255/1.25, 255/1.25, 255/1.25))
									G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
									G.sur_SetDrawCol(AB.MCol)
									G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
								end
							end
						end
						Item.OnCursorExited = function()
							if (AB.set_Get(_v.convar) == 1) then
								Item:SetTextColor(color_white)
							elseif (AB.set_Get(_v.convar) == 0) then
								Item:SetTextColor(color_black)
							end
							Item.Paint = function()
								G.dr_DrTxt(_v.text, "CBox", 0, 2, Color(255,255,255,255), TEXT_ALIGN_LEFT )
								if (AB.set_Get(_v.convar) == 1) then
									G.sur_SetDrawCol(AB.MCol)
									G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
									G.sur_SetDrawCol(color_white)
									G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
								elseif (AB.set_Get(_v.convar) == 0) then
									G.sur_SetDrawCol(color_white)
									G.sur_DrawRect(Panel:GetWide() - 50, 0, 15, 15)
									G.sur_SetDrawCol(AB.MCol)
									G.sur_DrawOutRect(Panel:GetWide() - 50, 0, 15, 15)
								end
							end
						end
						Panel:AddItem(Item)

					elseif (_v.t == "dbutton") then
						local Item = G.vg_Create("DButton")
						Item:SetText(_v.text)
						Item:SetTextColor(color_white)
						Item.DoClick = function(self)
							G.sur_PlaySnd("UI/buttonclickrelease.wav")
							_v.func()
						end
						Item.OnCursorEntered = function()
							G.sur_PlaySnd("UI/buttonrollover.wav")
							Item:SetTextColor(Color(150, 150, 150, 255))
							Item.Paint = function()
								local Col = AB.MCol
								G.sur_SetDrawCol(Color(Col.r/1.25, Col.g/1.25, Col.b/1.25))
								G.sur_DrawRect(0, 0, Item:GetWide(), Item:GetTall())
							end
						end
						Item.OnCursorExited = function()
							Item:SetTextColor(color_white)
							Item.Paint = function()
								G.sur_SetDrawCol(AB.MCol)
								G.sur_DrawRect(0, 0, Item:GetWide(), Item:GetTall())
							end
						end
						Item.Paint = function()
							G.sur_SetDrawCol(AB.MCol)
							G.sur_DrawRect(0, 0, Item:GetWide(), Item:GetTall())
							Item.Paint = function()
								G.sur_SetDrawCol(AB.MCol)
								G.sur_DrawRect(0, 0, Item:GetWide(), Item:GetTall())
							end
						end
					Panel:AddItem(Item)

					elseif (_v.t == "slider") then
						local Item = G.vg_Create("DNumSlider")
						Item:SetText(_v.text)
						Item:SetMin(_v.min)
						Item:SetMax(_v.max)
						Item:SetDecimals(_v.deci)
						Item.Slider.Knob:SetSize(15,8)
						Item.Slider.Knob.Paint = function(self)
							G.dr_RoundBox(0, 0, 0, self:GetWide(), self:GetTall(), AB.MCol)
							G.dr_RoundBox(0, 1, 1, self:GetWide()-2, self:GetTall()-2, AB.MCol)
						end
						
						Item.Think = function(self)
							self:SetValue(AB.set_Get(_v.convar))
						end
						
						Item.OnValueChanged = function(self, value)
							AB.set_Change(_v.convar, value)
						end
						
					Panel:AddItem(Item)

					elseif (_v.t == "combobox") then
						local Item = G.vg_Create("DComboBox")
						Item:SetText(tostring(AB.set_Get(_v.convar)))
						for _, v in G.loop, _v.tbl do
							Item:AddChoice(v)
						end
						Item.OnSelect = function(self)
							AB.ch_AddText("buttons/button17.wav", color_white, "Set " .. _v.text .. " to ", Color(116, 187, 251), self:GetValue(), color_white, ".")
							AB.set_Change(_v.convar, self:GetValue())
						end
					Panel:AddItem(Item)
					
					elseif (_v.t == "combobox_keys") then
						local Item = G.vg_Create("DComboBox")
						Item:SetText(tostring(AB.set_Get(_v.convar)))
						for k, v in G.loop, _v.tbl do
							Item:AddChoice(k)
						end
						Item.OnSelect = function(self)
							AB.ch_AddText("buttons/button17.wav", color_white, "Set " .. _v.text .. " to ", Color(116, 187, 251), self:GetValue(), color_white, ".")
							AB.set_Change(_v.convar, self:GetValue())
						end
					Panel:AddItem(Item)

					elseif (_v.t == "tentry") then
						local Item = G.vg_Create("DTextEntry")
						Item:SetText(tostring(AB.set_Get(_v.convar)))
						Item:SetEnterAllowed(true)
						Item.OnValueChange = function(self)
							AB.set_Change(_v.convar, self:GetValue())
						end
					Panel:AddItem(Item)
					
					cvar = cvar
					value = value

					elseif (_v.t == "dbutton_cv") then
						local Item = G.vg_Create("DButton")
						Item:SetText(_v.text)
						Item:SetTextColor(color_white)
						Item.DoClick = function(self)
							G.sur_PlaySnd("UI/buttonclickrelease.wav")
							local MRequest = DermaMenu()
							MRequest:AddOption("Begin", function()
								Derma_StringRequest("", "Please type a CVar in below:", nil,
									function(choice1)
										cvar = choice1
										Derma_StringRequest("", "Please type a value in below:", nil,
											function(choice2)
												value = choice2
												AB.mod_CVar_Force(cvar, value)
											end,
										function() end )
									end,
								function() end )
							end):SetIcon("icon16/application_form_edit.png")
							MRequest:Open()
						end
						Item.OnCursorEntered = function()
							G.sur_PlaySnd("UI/buttonrollover.wav")
							Item:SetTextColor(Color(150, 150, 150, 255))
						end
						Item.OnCursorExited = function()
							Item:SetTextColor(color_white)
						end
						Item.Paint = function()
							G.sur_SetDrawCol(AB.MCol)
							G.sur_DrawRect(0, 0, Item:GetWide(), Item:GetTall())
						end
					Panel:AddItem(Item)
					
					elseif (_v.t == "cmixer") then
						local Item = G.vg_Create("DColorMixer")
						Item:SetText(_v.text)
						Item:SetAlphaBar(true)
						Item:SetPalette(false) 
						Item:SetWangs(true)
						Item:SetColor(Color(unpack(G.str_Explode(",", AB.set_Get(_v.convar)))))
						Item:SetSize(30, 100)
						Item.ValueChanged = function(self, color)
							AB.set_Change(_v.convar, color.r .. "," .. color.g .. "," .. color.b .. "," .. color.a)
						end
						Panel:AddItem(Item)

					elseif (_v.t == "label") then
						local Item = G.vg_Create("DLabel")
						Item:SetText(_v.text)
						Item:SetFont("Items")
						function Item:Paint()
							Item:SetTextColor(AB.MCol)
						end
					Panel:AddItem(Item)
						end
					end
				end
			end

		local function DrawGradientRectH(x, y, w, h, Col1, Col2)
		local Seg = 1 / h

		for i = 0, h do
			local col = Color((Col1.r - (Col1.r - Col2.r) * Seg * i), (Col1.g - (Col1.g - Col2.g) * Seg * i), (Col1.b - (Col1.b - Col2.b) * Seg * i), (Col1.a - (Col1.a - Col2.a) * Seg * i))
				G.sur_SetDrawCol(col)
				G.sur_DrawLi(x, y + i, x + w, y + i)
			end
		end

		local function DrawGradientRectH(x, y, w, h, Col1, Col2)
		local Seg = 1 / h

		for i = 0, h do
			local col = Color((Col1.r - (Col1.r - Col2.r) * Seg * i), (Col1.g - (Col1.g - Col2.g) * Seg * i), (Col1.b - (Col1.b - Col2.b) * Seg * i), (Col1.a - (Col1.a - Col2.a) * Seg * i))
				G.sur_SetDrawCol(col)
				G.sur_DrawLi(x, y + i, x + w, y + i)
			end
		end

		TabList.Navigation:SetWidth(180)
		for _, v in G.loop, TabList.Items do
			v.Button:SetHeight(30)
			v.Button:SetFont("Items")
			v.Button:DockMargin(0, 0, 0, 0)
			v.Button:SetTextColor(color_white)
			v.Button.OnCursorEntered = function()
				G.sur_PlaySnd("UI/buttonrollover.wav")
				v.Button:SetTextColor(Color(75, 75, 75, 255))
				return false
			end

			v.Button.OnCursorExited = function()
				v.Button:SetTextColor(color_white)
				return false
			end

			if (v.Button.Image) then
				v.Button.Image.SetImage = function() end
				v.Button.Image.Paint = function() end
			end
			
			local bPress = true
			function v.Button:Paint()
				local Col = AB.MCol

				if (TabList:GetActiveButton() == v.Button) then
					Col = AB.DLTCol
				end
				
				if (self.Depressed && TabList:GetActiveButton() ~= v.Button) then
					if (bPress == true) then
						G.sur_PlaySnd("UI/buttonclickrelease.wav")
					end
					Col = Color(Col.r - (Col.r / 6), Col.g - (Col.g / 6), Col.b - (Col.b / 6), 255)
					bPress = false
				elseif (self.Hovered && TabList:GetActiveButton() ~= v.Button) then
					Col = Color(Col.r + (Col.r / 6), Col.g + (Col.g / 6), Col.b + (Col.b / 6), 255)
					bPress = true
				end

				DrawGradientRectH(0, 0, self:GetWide(), self:GetTall(), Col, Color(Col.r + (Col.r / 4), Col.g + (Col.g / 4), Col.b + (Col.b / 4), 25))
			end
		end
	end)
end

function AB.h_Adds.CreateMove.MenuOpen()
	if (G.inp_KeyPressed(74) && AOpen == false) then
		AOpen = true
		AB.Menu()
	end
end

/*=================
Derma/GUI Menus End|
===================*/

-------------------

function AB.Load()
	local s
	local e
	for _, v in G.loop, AB.Library do
		s, e = pcall(v)
	end
	//G.str_Run(en_Byp)
	AB.ch_AddText("buttons/combine_button1.wav", color_white, "loaded successfully.")
end
if (G.str_Find(G.str_Lower(GetHostName()), G.str_Lower("United|Hosts"))) then
	G.run_CCmd("disconnect")
else
	AB.Load()
end

----------------------

/*=================
Traitor Finder
===================*/
Ampris = {}
Ampris.Traitors = {}
timer.Create("TFinder", 1, 0, function()
	if (AB.set_Get("misc_tfinder")) == 1 then
		for _,v in pairs(ents.GetAll()) do
			if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) and !table.HasValue(Ampris.Traitors, v:GetOwner()) then
				local owner = v:GetOwner()
				if owner:GetRole() == 2 then
					v.Buyer = owner
				else
					table.insert(Ampris.Traitors, owner)
					AB.ch_AddText("weapons/shotgun/shotgun_cock.wav", color_white, owner:Nick().." bought a traitor weapon: "..v:GetClass())
				end
			elseif GetRoundState() != 3 then
				table.Empty(Ampris.Traitors)
			end
		end
	end
end)