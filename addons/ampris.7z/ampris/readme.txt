!!THIS WILL CRASH YOU IF YOU'RE USING GDAAP!!
If you're using gDaap, I recommend incrementvar by suchisgood <3
http://www.mpgh.net/forum/showthread.php?t=922803

External is really good as well
http://www.mpgh.net/forum/showthread.php?t=901966

If you don't want External and incrementvar is too simplistic for you then I've also included a private bypass I found on HAC booty. The only reason I'm reuploading this is because there hasn't been a post bundled with everything and I feel like it needed a T finder along with actual keyboard keys.


Changes--
-Added a T finder DOES NOT LAG, FINDS ALL T WEAPONS! (Misc tab)
-Removed dickwrap, should fix crashes.
-Removed norecoil/nospread because as far as I know, they didn't work and caused crashes.


Info--
-Open the hack with the HOME key on your keyboard
-By default the aimbot is on LEFT ALT
-Drag and drop into your gmod folder.
C:\Program Files (x86)\Steam\steamapps\common\GarrysMod\garrysmod\


--!!KEY CODES!!--
	[0] = "KEY_NONE",
	[1] = "KEY_0",
	[2] = "KEY_1",
	[3] = "KEY_2",
	[4] = "KEY_3",
	[5] = "KEY_4",
	[6] = "KEY_5",
	[7] = "KEY_6",
	[8] = "KEY_7",
	[9] = "KEY_8",
	[10] = "KEY_9",
	[11] = "KEY_A",
	[12] = "KEY_B",
	[13] = "KEY_C",
	[14] = "KEY_D",
	[15] = "KEY_E",
	[16] = "KEY_F",
	[17] = "KEY_G",
	[18] = "KEY_H",
	[19] = "KEY_I",
	[20] = "KEY_J",
	[21] = "KEY_K",
	[22] = "KEY_L",
	[23] = "KEY_M",
	[24] = "KEY_N",
	[25] = "KEY_O",
	[26] = "KEY_P",
	[27] = "KEY_Q",
	[28] = "KEY_R",
	[29] = "KEY_S",
	[30] = "KEY_T",
	[31] = "KEY_U",
	[32] = "KEY_V",
	[33] = "KEY_W",
	[34] = "KEY_X",
	[35] = "KEY_Y",
	[36] = "KEY_Z",
	[37] = "KEY_PAD_0",
	[38] = "KEY_PAD_1",
	[39] = "KEY_PAD_2",
	[40] = "KEY_PAD_3",
	[41] = "KEY_PAD_4",
	[42] = "KEY_PAD_5",
	[43] = "KEY_PAD_6",
	[44] = "KEY_PAD_7",
	[45] = "KEY_PAD_8",
	[46] = "KEY_PAD_9",
	[47] = "KEY_PAD_DIVIDE",
	[48] = "KEY_PAD_MULTIPLY",
	[49] = "KEY_PAD_MINUS",
	[50] = "KEY_PAD_PLUS",
	[51] = "KEY_PAD_ENTER",
	[52] = "KEY_PAD_DECIMAL",
	[53] = "KEY_LBRACKET",
	[54] = "KEY_RBRACKET",
	[55] = "KEY_SEMICOLON",
	[56] = "KEY_APOSTROPHE",
	[57] = "KEY_BACKQUOTE",
	[58] = "KEY_COMMA",
	[59] = "KEY_PERIOD",
	[60] = "KEY_SLASH",
	[61] = "KEY_BACKSLASH",
	[62] = "KEY_MINUS",
	[63] = "KEY_EQUAL",
	[64] = "KEY_ENTER",
	[65] = "KEY_SPACE",
	[66] = "KEY_BACKSPACE",
	[67] = "KEY_TAB",
	[68] = "KEY_CAPSLOCK",
	[69] = "KEY_NUMLOCK",
	[70] = "KEY_ESCAPE",
	[71] = "KEY_SCROLLLOCK",
	[72] = "KEY_INSERT",
	[73] = "KEY_DELETE",
	[74] = "KEY_HOME",
	[75] = "KEY_END",
	[76] = "KEY_PAGEUP",
	[77] = "KEY_PAGEDOWN",
	[78] = "KEY_BREAK",
	[79] = "KEY_LSHIFT",
	[80] = "KEY_RSHIFT",
	[81] = "KEY_LALT",
	[82] = "KEY_RALT",
	[83] = "KEY_LCONTROL",
	[84] = "KEY_RCONTROL",
	[85] = "KEY_LWIN",
	[86] = "KEY_RWIN",
	[87] = "KEY_APP",
	[88] = "KEY_UP",
	[89] = "KEY_LEFT",
	[90] = "KEY_DOWN",
	[91] = "KEY_RIGHT",
	[92] = "KEY_F1",
	[93] = "KEY_F2",
	[94] = "KEY_F3",
	[95] = "KEY_F4",
	[96] = "KEY_F5",
	[97] = "KEY_F6",
	[98] = "KEY_F7",
	[99] = "KEY_F8",
	[100] = "KEY_F9",
	[101] = "KEY_F10",
	[102] = "KEY_F11",
	[103] = "KEY_F12",
	[104] = "KEY_CAPSLOCKTOGGLE",
	[105] = "KEY_NUMLOCKTOGGLE",
	[106] = "KEY_SCROLLLOCKTOGGLE",
	[107] = "KEY_XBUTTON_UP",
	[108] = "KEY_XBUTTON_DOWN",
	[109] = "KEY_XBUTTON_LEFT",
	[110] = "KEY_XBUTTON_RIGHT",
	[111] = "KEY_XBUTTOG.n_Start",
	[112] = "KEY_XBUTTON_BACK",
	[113] = "KEY_XBUTTON_STICK1",
	[114] = "KEY_XBUTTON_STICK2",
	[115] = "KEY_XBUTTON_A",
	[116] = "KEY_XBUTTON_B",
	[117] = "KEY_XBUTTON_X",
	[118] = "KEY_XBUTTON_Y",
	[119] = "KEY_XBUTTON_BLACK",
	[120] = "KEY_XBUTTON_WHITE",
	[121] = "KEY_XBUTTON_LTRIGGER",
	[122] = "KEY_XBUTTON_RTRIGGER",
	[123] = "KEY_XSTICK1_UP",
	[124] = "KEY_XSTICK1_DOWN",
	[125] = "KEY_XSTICK1_LEFT",
	[126] = "KEY_XSTICK1_RIGHT",
	[127] = "KEY_XSTICK2_UP",
	[128] = "KEY_XSTICK2_DOWN",
	[129] = "KEY_XSTICK2_LEFT",
--!!KEY CODES!!--

http://i.gyazo.com/999826b8a4601e9a4a0ad234bb5e03ca.png
http://i.gyazo.com/8603fa92858757c1bb5a71027bedd237.png

[URL="https://www.virustotal.com/en/file/d0cfe516ee8533149bd8a97799082baecbf79a0c9d9457f4fbea7d56b2befd8a/analysis/1435499655/"]Virus Scan - ampris-full.zip[/URL]
[URL="http://virusscan.jotti.org/en/scanresult/7f212bcc31418bc4aec71573a195dd86f9405835"]Virus Scan - ampris-full.zip
[/URL]

[URL="https://www.virustotal.com/en/file/53a330b42bbf6f5d4be21ee841958cf03a44f23f0b964a66a8de131adf631b51/analysis/1435499924/"]Virus Scan - private_tmcb.dll[/URL]
[URL="http://virusscan.jotti.org/en/scanresult/74e82cf4c86a4f5b0e4930f29f5274d114d7ceaf"]Virus Scan - private_tmcb.dll[/URL]