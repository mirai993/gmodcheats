---------------------------------------------------------------------------------------------------
-- NAME:     Sqirril's Salty Chocolate Nuts (Epic.)
-- VERSION:  1.6.6 (Now with increased penetration and ease-of-use!)
-- DESC:     An ESP/aimbot designed around TTT/DarkRP/GmodDM
-- AUTHOR:   FAGGOTS  (Alex && Humil)
-- VAC:      Incident Free for... ever.... muahahahah
---------------------------------------------------------------------------------------------------
-- CONTENTS (currently out-of-date)
--  Start Loading:
--      (0) Pre-module Variables (local copys)
--      (1) Post-Module Variables (ALL of them)
--      (2) Anti-Anti-Cheats / Function Re-routing
--      (3) Saving/Loading System
--      (4) Functions Functions Functions
--      (5) ConCommand System
--      (6) Console commands (All of them)
--		(7) Plugins *RELOCATED*
--      (8) Hooks && Timers
--  Finished Loading
---------------------------------------------------------------------------------------------------

--WARNING: NO ENUMERATION VARIABLES, LITERALS REQUIRED

if SERVER then return end
include('includes/extensions/table.lua');

Msg("\n\n[epic] ----------EPIC SCRIPT LOADING---------\n");
Msg("[epic] --------------------------------------\n");

--This particular anti-anti-cheat method is no longer needed as long as this script runs first
--[[
--Some scripts can load before us, so we must refresh all commands we use that we don't
--want tampered with. includes/init.lua contains all the requires and includes we need so we use it
--to get fresh copies of all functions and use them instead of potentially tampered with ones.
--We restore the old functions so anti-cheats checking for changed functions won't see a difference.
--UPDATE: This is probably not need since we load at enums now
local old = { };
local function _require(str)
	old[str] = table.Copy(package.loaded[str]);
	package.loaded[str] = nil;
end

_require('hook');
_require('concommand');
_require('timer');
_require('team');
_require('draw');
_require('usermessage');]]
--enums........................ can't read the files...................
HUD_PRINTNOTIFY = 1 HUD_PRINTCONSOLE = 2 HUD_PRINTTALK = 3 HUD_PRINTCENTER = 4
TEAM_CONNECTING	= 0 TEAM_UNASSIGNED	= 1001 TEAM_SPECTATOR = 1002
include("includes/init.lua");
include('includes/extensions/string.lua');
include('includes/extensions/util.lua');

---------------------------------------------------------------------------------------------------
--[STAGE 0]:  PRE-MODULE.
---------------------------------------------------------------------------------------------------
-- Every function we use must be localized for our own safety  
require("cvar2");
require("disconnect");

local _G = _G;
local pairs = pairs;
local ipairs = ipairs;
local tostring = tostring;
local tonumber = tonumber;
local string = string;
local table = table;
local print = print;
local math = math;
local type = type;
local util = util;
local Vector = Vector;
local Angle = Angle;
local FrameTime = FrameTime;
local IsValid = IsValid;
local player = player;
local ents = ents;
local timer = timer;
local LocalPlayer = LocalPlayer;
local ValidEntity = ValidEntity;
local package = package;
local CurTime = CurTime;
local Color = Color;
local concommand = concommand;
local Msg = Msg;
local CreateClientConVar = CreateClientConVar;
local CreateConVar = CreateConVar;
local RunString = RunString;
local RunConsoleCommand = RunConsoleCommand;
local file = file;
local fileR = file.Read;
local fileE = file.Exists;
local fileW = file.Write;
local fileZ = file.FindInLua;
local fileD = file.Delete;
local traceline = util.TraceLine
local surface = surface;
local DrawRect = surface.DrawRect;
local DrawLine = surface.DrawLine;
local SetDrawColor = surface.SetDrawColor;
local hookAdd = hook.Add;
local hookRemove = hook.Remove;
local usermessage = usermessage;
local hooktable = hook.GetTable;
local tblremove = table.remove;
local cumsg = usermessage.IncomingMessage;
local nullfunc = function() error("this shouldn't be called\n"); end;
local debuggetinfo = debug.getinfo;
local ApplySpread = engApplySpread;
engApplySpread = nil;
local GetSeedFromUserCmd = engGetSeedFromUserCmd;
engGetSeedFromUserCmd = nil;
local NoSpreadInstalled = ApplySpread && GetSeedFromUserCmd;

local ResetTraitors = nullfunc;
local ResetWeaponsCache = nullfunc;

local foldern = "sqirrils_salty_chocolate_nuts";
local pfile = "alexs_large_shlong.txt";
local ScrH = ScrH;
local ScrW = ScrW;
local draw = draw;
local name = "epic" -- name of our concommand for everything

local vectormeta = FindMetaTable("Vector");
local plymeta = FindMetaTable("Player");
local entitymeta = FindMetaTable("Entity");
local ucmdmeta = FindMetaTable("CUserCmd");

local hooks = { };

--[[
--revert reloaded functions to their previous versions
for k, v in pairs(old) do
	package.loaded[k] = v;
end


if (old.concommand) then
    --Link the current concommand run to safe concommand run (detectable)
	local blankfunc = function() end;
    local ccr = concommand.Run;
	function _G.concommand.Run(p, c, a)
		local op = plymeta.ChatPrint;
		plymeta.ChatPrint = blankfunc;
		local ret = ccr(p, c, a);
		if (!ret) then
			p.ChatPrint = op;
			return old.concommand.Run(p, c, a);
		end
		plymeta.ChatPrint = op;
		return ret;
	end
end

if (old.hook) then
    local hc = hook.Call;
    function hook.Call(name, gm, ...)
		--Call normal hook environment
		local rA, rB, rC, rD, rE, rF, rG, rH = hc(name, gm, ...);
		if (rA == nil || name == "PlayerConnect") then
			--No override, check environment where our hooks reside
            return old.hook.Call(name, gm, ...);
        end
		return rA, rB, rC, rD, rE, rF, rG, rH;
    end
end]]

module("epic");
package.loaded.epic = nil;

---------------------------------------------------------------------------------------------------
--[STAGE 1]:  POST MODULE VARIABLES
---------------------------------------------------------------------------------------------------
--Metatable functions we need to copy:
vectormeta.cToScreen = vectormeta.ToScreen;
vectormeta.cAngle = vectormeta.Angle;
plymeta.cConCommand = plymeta.ConCommand;
plymeta.IsDetective = plymeta.IsDetective or function(self) return false end;
plymeta.IsTraitor = plymeta.IsTraitor or function(self) return false end;
plymeta.IsSpectator = plymeta.IsSpectator or function(self) return false end;
plymeta.cSetAimVector = plymeta.SetEyeAngles;
plymeta.cGetWeapons = plymeta.GetWeapons;
plymeta.cGetVelocity = plymeta.GetVelocity;
plymeta.cNick = plymeta.Nick;
plymeta.cAlive = plymeta.Alive;
plymeta.cGetAimVector = plymeta.GetAimVector;
plymeta.cGetShootPos = plymeta.GetShootPos;
plymeta.cSetEyeAngles = plymeta.SetEyeAngles;
plymeta.cViewPunch = plymeta.ViewPunch;
entitymeta.cEyePos = entitymeta.EyePos;
entitymeta.cGetPos = entitymeta.GetPos;
entitymeta.cGetNWBool = entitymeta.GetNWBool;
entitymeta.cLookupAttachment = entitymeta.LookupAttachment;
entitymeta.cGetAttachment = entitymeta.GetAttachment;
entitymeta.cGetVelocity = entitymeta.GetVelocity;
ucmdmeta.cSetViewAngles = ucmdmeta.SetViewAngles;

local cmdblock = { }; --These console commands are blocked (format cmd = true, othercmd = true, ect)
local alpha = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","_"};
local quickbone = {
    ["head"] = "ValveBiped.Bip01_Head1",
    ["body"] = "ValveBiped.Bip01_Spine2",
    ["upper body"] = "ValveBiped.Bip01_Spine4",
    ["neck"] = "ValveBiped.Bip01_Neck",
    ["pelvis"] = "ValveViped.Vip01_Pelvis"
};

local cmds = {}; -- our concommands table (run everything through 1 concommand)
local fonts = {}; -- containts different sizes of our scripts font.
local hooksrmv = {};
local hookcalls = {};
local strings = {}; -- list of generated rndstrings
local canseeme = {};
local traitors = {}; -- 95% sure these are traitors
	
--color translation for concommands
local colors = {
red = Color(255, 0, 0),
blue = Color(0, 0, 255),
green = Color(0, 255, 0),
yellow = Color(255,0,128),
orange = Color(255,180,20),
teal = Color(70,200,255),
pink = Color(255,192,189),
purple = Color(240,20,240),
brown = Color(70,60,20),
white = Color(255,255,255),
black = Color(0,0,0),
gray = Color(180,180,180),
Traitor_Red = Color(255,20,20),
Sqirril_Purple = Color(240,20,240),
Wronkles_Black = Color(20,20,20),
Obama_Brown = Color(70,60,20),
Pac_Blue = Color(25,25,255),
Panties_Pink = Color(255,192,189),
Duck_Fuck_Orange = Color(255,180,20),
Tittie_Teal = Color(70,200,255),
Alex_Asian_Assporn = Color(238,221,130)
};

local fontmin = 10;
local fontmax = 16;
local newcolinc = 200;
local fontdetail = (fontmax - fontmin)

local target = NULL;
local target_team = true;
local targetoff;
local snap_starttime = 0;
local snap_endtime = 0;
local snap_startang = Vector(0,0,0);

--Bot settings
local preflist = { };
local settings = { };
settings.currentgame = "base";
settings.showply = true;
settings.showent = true;
settings.allowHTML = 1;
settings.Debug = false;
settings.AdminName = "Admin";
settings.SuperAdminName = "SuperAdmin";
settings.enablelagcomp = false;
settings.lagcomp = 0.00001;
settings.range = 4096;
settings.targetbone = "ValveBiped.Bip01_Head1";
settings.targetfov = 45;
settings.lockonfire = false;
settings.whoshotme_snaphp = 0; -- if your hp drops below this #, it'll snap to your attacker.
settings.whoshotme_enabled = true;
settings.weaponhistory_print = false;
settings.snaptime = 2.0; 
settings.autoshoot = 0;
settings.autojump = 0;
settings.name = "default";
settings.enttbl = { };
settings.wepnodraw = { };
settings.nospread = 0;
settings.norecoil = 0;
settings.targetoff = 0;
--Bot preferences
local preferences = { };
preferences.gametriggers = { ["ttt"] = {"[Tt]rouble [Ii]n [Tt]errorist [Tt]own"}, ["darkrp"] = {"DarkRP.+"}};
preferences.override = "";
preferences.autocreate = true;
--Short descript names for the show_settings command, put (#) where # is the order the setting should be listed
local settingnames = { };
settingnames.name = "(1) Preference Name";
settingnames.currentgame = "(2) Current Game";
settingnames.showply = "(3) ESP Show Players";
settingnames.showent = "(4) ESP Show Ents";
settingnames.range = "(5) ESP Range";
settingnames.targetbone = "(6) Target Bone";
settingnames.targetfov = "(7) Aim Field of View";
settingnames.lockonfire = "(8) Lock on Fire";
settingnames.nospread = "(9) Nospread";
settingnames.norecoil = "(10) Norecoil";
settingnames.enablelagcomp = "(11) Lag Comp. Enabled";
settingnames.lagcomp = "(12) Lag Compensation";
settingnames.AdminName = "(13) Admin Name";
settingnames.SuperAdminName = "(14) SuperAdmin Name";
settingnames.Debug = "(15) Debug Level";

local function Print(msg, priority)
    local msg = msg or "";
    local priority = priority or 0;
    if (priority <= (settings.Debug or 10)) then
        Msg("["..name.."] "..msg.."\n")
    end
end

--Generates a random string while avoiding duplicates
local function RndString()
	local str = ""
	for i=1, math.random(6,12) do
		str = str..alpha[math.random(1,#alpha)]
	end
	if strings[str] then
		return RndString()
	else
		strings[str] = true
		return str
	end
end

---------------------------------------------------------------------------------------------------
--[STAGE 2]:  ANTI-ANTI HAX
---------------------------------------------------------------------------------------------------

local foverrides = { };
function _G.debug.getinfo(thread, func, ...)
	if (tonumber(thread) && foverrides[func]) then
		return debuggetinfo(foverrides[func], func, ...);
	elseif (foverrides[thread]) then
		return debuggetinfo(foverrides[thread], func, ...);
	else
		return debuggetinfo(thread, func, ...);
	end
end
foverrides[_G.debug.getinfo] = debuggetinfo;

local function RegisterOverride(name, orig, new)
	foverrides[new] = orig;
	local t = string.Explode(".", name);
	local tn = #t;
	local tt = _G;
	for n=1, tn-1, 1 do
		tt = tt[ t[n] ];
		if (!tt) then
			Print("Failed to register override "..name.."; no such index "..v);
			return;
		end
	end
	tt[ t[tn] ] = new;
end

--Override functions
--------------------
RegisterOverride("RunString", _G.RunString, function(s)
	Print("[RunString]: "..(tostring(s) or "") );
	RunString(s);
end);

RegisterOverride("RunConsoleCommand", _G.RunConsoleCommand, function(...)
	local t = {...};
	if (cmdblock[ t[1] ]) then
		Print("RunCC: **Blocked** "..table.concat(t, " "));
	else
		Print("RunCC: "..table.concat(t, " "));
		
		RunConsoleCommand(...);
	end
end);

RegisterOverride("file.Read", _G.file.Read, function(filename, dir)
	Print("[file] Reading File: '"..tostring(filename).."'");
	return fileR(filename, dir);
end);

RegisterOverride("usermessage.IncomingMessage", usermessage.IncomingMessage, function(name , um , ...)
	if (name == "ttt_role") then
		ResetTraitors();
	end
	return cumsg(name , um , ...);
end);

--Prevents attempts to override run after we redefine it
local rcc = concommand.Run;
RegisterOverride("engineConsoleCommand", _G.engineConsoleCommand, function(p, c, a)
	if (c == name) then
		rcc(p, c, a);
	else
		concommand.Run(p, c, a);
	end
end);

function plymeta:ConCommand(str)
	--a rittle too shimpal but ve vill change et lat0r
	local t = string.Explode(" ", str);
    if (cmdblock[t[1]]) then
		Print("RunPlyCC: **Blocked** "..str);
	else
        Print( "RunPlyCC: "..str );
        self:cConCommand(str);
    end
end
foverrides[plymeta.cConCommand] = plymeta.ConCommand;

--Safe hook.Add function
local function hookA(name, uniquename, func)
    Print("[hooks] Attempting to add hook:\t"..name.."."..uniquename);
    hooks[uniquename] = true;
    hooksrmv[uniquename] = name;
    hookcalls[uniquename] = func;
    hookAdd(name, uniquename, func);
end

RegisterOverride("hook.Remove", _G.hook.Remove, function(name,uniquename) 
    if (hooks[uniquename]) then
        if (hooks[uniquename] != 1) then
            Print("[hook] BLOCKED removing hook ["..uniquename.."] of type ["..name.."] !!!");
            hooks[uniquename] = 1; --telling us that we succeded once, is enough... most gamemodes will constantly try to remove this
        end
    else
        hookRemove(name,uniquename);
    end
end);

RegisterOverride("hook.GetTable", _G.hook.GetTable, function() --makes our hooks invisible to people snooping around
    local tbl = {}
    local hookcopy = hooktable();
    
    -- because (tbl[index] = nil)  breaks garrys code, I have to do a deep copy of the table.
    for hookname,subtbl in pairs(hookcopy) do
        tbl[hookname] = {};
        if ( type(subtbl) == "table" ) then
            for subhookname,subcall in pairs(subtbl) do
                for uniquename,truthiness in pairs (hooks) do
                    if (subhookname != uniquename) then
                        tbl[hookname][subhookname] = subcall;
                    end
                end
            end
        else
            tbl[hookname] = subtbl;
        end
    end
    return tbl;
end);

---------------------------------------------------------------------------------------------------
--[STAGE 3]:  SAVING / LOADING
---------------------------------------------------------------------------------------------------
--nil counts as a number
local typetobyte = { ["string"] = "s", ["boolean"] = "b", ["number"] = "n", ["nil"] = "n" };
local function SaveTable(tbl, fname)
	local str = "";
	local istr = "";
	local t, getsegnum;
	local segnum = 0;
	for k, v in pairs(tbl) do
		t = type(v);
		if (t == "table") then
			istr, getsegnum = SaveTable(v);
			segnum = segnum+getsegnum+2;
			str = str.."\2"..typetobyte[type(k)]..tostring(k).."\1\3"..tostring(getsegnum).."\1"..istr.."\1";
		else
			str = str..typetobyte[t]..typetobyte[type(k)]..k.."="..tostring(v).."\1";
			segnum = segnum+1;
		end
	end
	str = str:sub(1,-2);
	
	if (fname) then
		fileW(fname, str);
	else
		return str, segnum;
	end
end

--fname (file name) is required, deftbl is optional, the remaining arguments are internal only
--returns the table if successful or nil on failure
--currently supports types integer, boolean, nil, string, and table as value and string and integer as key
--passing deftbl will cause this function to only load key values present in deftbl
--keyvalues are also inherited from deftbl if they are nil or not present in the file
local function LoadTable(fname, deftbl, segtbl, segpos, segmax)
	local tbl = { };
	segpos = segpos or 1;
	if (!segtbl) then
		if (fileE(fname)) then
			segtbl = string.Explode("\1", fileR(fname));
			segmax = #segtbl;
		else
			return;
		end
	end
	
	local b, n, epos, err, data, seg, segcount, key;
	n = segpos;
	while (n <= segmax) do
		seg = segtbl[n];
		b = seg:sub(1, 1);
		if (b == "\2") then
			b = seg:sub(2, 2);
			if (b == "n") then
				key = tonumber(seg:sub(3));
			else
				key = seg:sub(3);
			end
			n = n+1;
			continue;
		elseif (b == "\3") then
			segcount = tonumber(seg:sub(2));
			if (segcount == 0) then
				data = { };
				segcount = 1;
			else
				--for now we're not passing in a deftbl for tables inside tables until the need for this functionality arises
				data = LoadTable(fname, nil, segtbl, n+1, n+segcount);
			end
			n = n+segcount; --not right now, but will be when incremented
		else
			epos = seg:find("=");
			if (epos) then
				if (b == "s") then
					data = seg:sub(epos+1);
				elseif (b == "b") then
					data = util.tobool(seg:sub(epos+1));
				elseif (b == "n") then
					data = tonumber(seg:sub(epos+1));
				else
					err = true;
				end
				b = seg:sub(2, 2);
				if (b == "n") then
					key = tonumber(seg:sub(3, epos-1));
				else
					key = seg:sub(3, epos-1);
				end
			else
				err = true;
			end
		end
		
		if (err) then
			Print("Error reading save file segment! ('"..seg.."') (Preference: '"..fname.."')");
			err = false;
		else
			if (deftbl) then
				if (deftbl[key] != nil) then
					--use default value if data is nil
					if (data == nil) then data = deftbl[key]; end
					tbl[key] = data;
				else
					Print("Warning! Encounter unused or obsolete variable in save file. ('"..key.."') (Preference: '"..fname.."')");
				end
			else
				tbl[key] = data;
			end
		end
		n = n+1;
	end
	if (deftbl) then
		--fill in any missing variables
		for k, v in pairs(deftbl) do
			if (tbl[k] == nil) then
				tbl[k] = v;
			end
		end
	end
	return tbl;
end

local function PrefExists(name)
	return fileE(foldern.."/"..name..".txt");
end

local function SavePrefSettings()
	SaveTable(preferences, pfile);
end

local function SavePreference(pref)
	if (!pref) then
		if (preferences.autocreate) then
			pref = _G.GAMEMODE.Name:gsub("[/\\:%*%?\"%<%>%|]", ""):lower();
			if (!PrefExists(pref)) then
				local ptrig = _G.GAMEMODE.Name:gsub("([^a-zA-Z0-9_])","%%%1");
				Print("No preference name specified, use pref_name to set name and pref_trigger to set gamemode name trigger.");
				Print("Defaulting name to '"..pref.."' and preference trigger as '"..ptrig.."'");
				preferences.gametriggers[pref] = { ptrig };
				settings.name = pref;
				table.insert(preflist, pref);
				SavePrefSettings();
			else
				return;
			end
		else
			return;
		end
	end
	SaveTable(settings, foldern.."/"..pref..".txt");
	Print("'"..pref.."' preference saved!");
end

local function SaveData()
	if (settings.name == "default") then
		SavePreference();
	else
		SavePreference(settings.name);
	end
	SavePrefSettings();
end

local gamehooks = { };
--returns true if loading was succesful
local function LoadPreference(pref)
	local tbl = LoadTable(foldern.."/"..pref..".txt", settings);
	if (tbl) then
		Print("Loaded preference '"..pref.."'");
		SetGametype(tbl.currentgame);
		settings = tbl;
		return true;
	else
		Print("Failed to load preference '"..pref.."', using defaults");
		return false;
	end
end

local SetGameType = nullfunc;
local function LoadPrefSettings()
	local tbl = LoadTable(pfile, preferences);
	if (tbl) then
		preferences = tbl;
	else
		Print("No preference file found, creating default...");
		SavePrefSettings();
	end
end

---------------------------------------------------------------------------------------------------
--[STAGE derp]:  PREFERENCES AND GAMETYPES
---------------------------------------------------------------------------------------------------

local games  = {
base = true,
ttt = true,
darkrp = true
}

local function GameSetCallback(pref, onloadfunc, onunloadfunc)
	gamehooks[pref] = { onloadfunc, onunloadfunc };
end

function SetGametype(game)
	local phook = gamehooks[settings.currentgame];
	if (phook && phook[2]) then
		phook[2]();
	end
	settings.currentgame = game;
	phook = gamehooks[game];
	if (phook && phook[1]) then
		phook[1]();
	end
end

--Create default preferences if they don't exist
--keep default on top
if (!PrefExists("default")) then
	SavePreference("default");
end
if (!PrefExists("ttt")) then
	local wcol = colors.brown;
	local wcolt = Color(wcol.r+newcolinc, wcol.g+newcolinc, wcol.b+newcolinc);
	local swcol = Color(180, 40, 40);
	local swcolt = Color(swcol.r+newcolinc, swcol.g+newcolinc, swcol.b+newcolinc);
	settings.name = "ttt";
	settings.currentgame = "ttt";
	settings.wepnodraw = {weapon_zm_carry = true, weapon_ttt_unarmed = true, weapon_zm_improvised = true};
	settings.enttbl = {ttt_health_station = {swcol, swcolt}, weapon_ttt_m16 = {wcol, wcolt}, weapon_ttt_revolver = {wcol, wcolt}, weapon_zm_mac10 = {wcol, wcolt},
                    weapon_ttt_knife = {swcol, swcolt}, weapon_ttt_phammer = {wcol, wcolt}, weapon_ttt_c4 = {swcol, swcolt}, weapon_zm_rifle = {wcol, wcolt}, weapon_ttt_radio = {swcol, swcolt},
					weapon_ttt_sipistol = {swcol, swcolt}, weapon_ttt_teleport = {swcol, swcolt}, weapon_ttt_push = {swcol, swcolt}, ttt_c4 = {colors.Panties_Pink, colors.white, "[C4] - Run motherfucker! It's gon' keel yew!"}};
	SavePreference("ttt");
end
if (!PrefExists("darkrp")) then
	local wcol = colors.brown;
	local wcolt = Color(wcol.r+newcolinc, wcol.g+newcolinc, wcol.b+newcolinc);
	local swcol = colors.purple;
	local swcolt = Color(swcol.r+newcolinc, swcol.g+newcolinc, swcol.b+newcolinc);
	settings.name = "darkrp";
	settings.currentgame = "darkrp";
	settings.wepnodraw = { keys = true, hands = true, pocket = true, gmod_tool = true };
	settings.enttbl = { spawned_money = {swcol, swcolt}, money_printer = {swcol, swcolt}, drug_lab = {swcol, swcolt}, spawned_weapon = {swcol, wcolt}, weapon_ak472 = {swcol, swcolt}, weapon_cs_base2 = {swcol, swcolt},
						weapon_deagle2 = {swcol, swcolt}, weapon_mac102 = {swcol, swcolt}, weapon_m42 = {swcol, swcolt}, weapon_mp52 = {swcol, swcolt}, weapon_glock2 = {swcol, swcolt}, weapon_p2282 = {swcol, swcolt} };
	SavePreference("darkrp");
end
--avoid potential issues, we could just LoadPreference("default") here but that's handled in PostGamemodeLoaded
settings.currentgame = "default";

GameSetCallback("ttt", function()
	traitorwepclass = { weapon_ttt_c4 = true, weapon_ttt_flaregun = true, weapon_ttt_knife = true, weapon_ttt_phammer = true, weapon_ttt_push = true, weapon_ttt_radio = true,
					weapon_ttt_sipistol = true, weapon_ttt_teleport = true, weapon_ttt_decoy = true };
	
	--weapon history timer
	weaponhistory_timer = RndString().."history";
	timer.Create(weaponhistory_timer, 1, 0, function()
		for k, ent in ipairs(ents.FindByClass("weapon*")) do
			if (ValidEntity(ent) && ent:IsWeapon()) then   
				local owner = ent:GetOwner();
				if (ValidEntity(owner)) then
					--weapon has an owner, is it a new owner?
					ent.owners = ent.owners or { };
					if (ent.lastowner != owner) then
						--new owner, add previous to history
						table.insert(ent.owners, owner:Nick());
						ent.lastownername = owner:Nick();
						ent.lastowner = owner;
					end
				elseif (ent.lastownername) then
					--weapon has no owner, add the last owner
					table.insert(ent.owners, ent.lastownername);
					local ply = ent.lastowner;
					ent.lastownername = nil;
					if (ValidEntity(ply)) then
						--add weapon to weapon's last owner's history
						ply.previousguns = ply.previousguns or { };
						
						table.insert(ply.previousguns, ent:GetClass());
						if (settings.weaponhistory_print && ply:Alive()) then
							LocalPlayer():ChatPrint(ply:Nick().." has dropped " ..ent:GetClass()..".");
						end
					end
				end
			end
		end
	end);
	
	--traitor weapon scanner
	traitorscanner_timer = RndString().."trsc";
	timer.Create(traitorscanner_timer, 3, 0, function()
		--Checks for traitor weapons
		for class, v in pairs(traitorwepclass) do
			for k, ent in ipairs(ents.FindByClass(class)) do
				if (!traitorweapons[ent]) then
					local owner = ent:GetOwner();
					if (ValidEntity(owner)) then
						traitors[owner] = true;
					end
					traitorweapons[ent] = true;
				end
			end
		end
	end);
	
	ResetWeaponsCache = function ()
		for k, ent in ipairs(ents.GetAll()) do
			if (ValidEntity(ent)) then
				local classname = ent:GetClass();
				if (ent:IsWeapon() && ent.owners) then
					ent.owners = nil;
					ent.lastowner = nil;
					ent.lastownername = nil;
				elseif (ent:IsPlayer()) then
					ent.previousguns = nil;
				end
			end
		end
	end
	
	ResetTraitors = function (p,c,a)
		traitors = {};
		traitorweapons = {};
		Print("[TTT] Traitors Cleared!");
		for k,v in ipairs(player.GetAll()) do
			v.targetbone = nil;
		end
		ResetWeaponsCache();
	end
	
	GetTTTColors = function (ply)
		if (ply:IsDetective()) then
			return colors.Pac_Blue;
		elseif traitors[ply] then
			return colors.Traitor_Red;
		else
			return colors.Tittie_Teal;
		end
	end
	
	ResetTraitors();
	ResetWeaponsCache();
end, function()
	timer.Remove(weaponhistory_timer);
	timer.Remove(traitorscanner_timer);
	ResetTraitors = nil;
	ResetWeaponsCache = nil;
	GetTTTColors = nil;
	traitorweapons = nil;
	traitors = nil;
end);

---------------------------------------------------------------------------------------------------
--[STAGE 4]:  ESP/AIMBOT/HELPER FUNCTIONS
---------------------------------------------------------------------------------------------------
local function PlyInRange(ply)
    local dist = LocalPlayer():cGetPos():Distance(ply:cGetPos())
    if (dist < settings.range) then
        return dist;
    else
        return false;
    end
end

--Returns the angle difference between two vectors
function vectormeta:AngularDifference(vect,dir)
	return math.deg(math.acos(dir:Dot((vect-self):GetNormal())));
end

--a smart trace, which actually calculates twice, for aimingbotting past windows/fences
--"its actually not smart, its fucking brilliant" -Alex Howe
local function trace(tbl, penetrate)
    local tr = traceline(tbl);
    if (penetrate && tr.HitNonWorld && !tr.Entity:IsPlayer()) then
        tr = traceline({start=tr.HitPos+((tr.HitPos-tr.StartPos):Normalize()*16), endpos = tbl.endpos, filter=tbl.filter} );
    end
	return tr;
end 

local sfont = RndString();
surface.CreateFont( "Arial",12,500,true,false,sfont );
for i=1,fontdetail do
	fonts[i] = RndString();
    surface.CreateFont( "Arial",fontmin + ((i / fontdetail) * (fontmax - fontmin)), 500, true, false, fonts[i] );
end

local function DrawShadowText( x, y, col, text, font, dist )
    surface.SetFont( font or sfont );
    surface.SetTextColor(0,0,0,col.a*0.625);
    surface.SetTextPos( x+(dist or 1), y+(dist or 1) );
    surface.DrawText( text );
    surface.SetTextColor(col.r,col.g,col.b,col.a);
    surface.SetTextPos( x, y );
    surface.DrawText( text );
end

local function getsortedkeys(tbl, desc)
	local temp = {};

	for key, _ in pairs(tbl) do table.insert(temp, key); end
	if (desc) then
		table.sort(temp, function(a, b) return a < b end);
	else
		table.sort(temp, function(a, b) return a > b end);
	end

	return temp;
end

--Grabs the position the bot should target on a given player based on targetbone
--caches bone minimizing number of bone lookups
--currently defaults to EyePos() if bone doesn't exist on target
local GetAimPos;
do
local tpos, tbone, tang;
GetAimPos = function(ply)
	tpos, tbone = 0, ply.targetbone;
	if (!tbone) then
		tbone = ply:LookupBone(settings.targetbone) or -1;
		ply:InvalidateBoneCache();
		ply.targetbone = tbone;
	end
	if (ply.targetbone == -1) then
		tpos = ply:EyePos();
	else
		tpos, tang = ply:GetBonePosition(tbone);
		if (settings.targetoff != 0) then
			tpos = tpos + tang:Forward()*settings.targetoff;
		end
		ply:InvalidateBoneCache();
	end
	return tpos;
end
end

local function clampang( a )    -- sets ang between -180 and 180, to fix engine errors with CreateMove
    while ( a > 180 ) do
        a = a - 360;
    end
    while ( a < -180 ) do
        a = a + 360;
    end
    return a;
end

local function clampviewang( ang )  -- sets ang between -180 and 180, to fix engine errors with CreateMove
    ang.p = clampang(ang.p);
    ang.y = clampang(ang.y);
    ang.r = 0;
    return ang;
end



local function GetSnapTimeTo(ply)
    local ang = LocalPlayer():cEyePos():AngularDifference(ply:cEyePos(),LocalPlayer():cGetAimVector());
    return (( ang / 45.0 ) * settings.snaptime);
end

local function ResetSnap()
    snap_starttime = 0;
    snap_endtime = 0;
end
	
local CalcAim;
do
local lply, goal_vec, smooth_vec, smooth_frac;
--Main aimbot function; calculates view angles base on current target or nil if disabled/error
	CalcAim = function()
		
		if (target != NULL) then
			if (target && target:IsValid() && target:IsPlayer() && target:Alive()) then
				lply = LocalPlayer();
				--[[if (settings.enablelagcomp) then
					offset = target:cGetVelocity() * settings.lagcomp * lply:Ping();
					loffset = lply:GetVelocity() * settings.lagcomp * lply:Ping();
				end]]
				
				if ( snap_starttime == 0 ) then
					snap_starttime = CurTime();
					snap_endtime = snap_starttime + GetSnapTimeTo(target);
					snap_startang = lply:cGetAimVector();
				end
				
				smooth_frac = 0.0;
				if ( CurTime() <= snap_endtime ) then
					smooth_frac = 1.0 - ( (1.0 + math.cos( math.pi * ( 1.0 + ( (CurTime()-snap_starttime) / (snap_endtime - snap_starttime ) ) ) ) ) * 0.5 );
				end
				
				goal_vec = (GetAimPos(target) - lply:cGetShootPos()):Normalize();
				smooth_vec = goal_vec - ((goal_vec - snap_startang) * smooth_frac); --looks unoptimized but isnt.
				return smooth_vec;
			end
		end
	end
end

--Retrives a weapons spread cone or nil if it couldn't find one or it has none/is null
--Given this function's use within its context it will return nil if the weapon fires more than 1 shot at once (ie a shotgun)
local function GetWepCone(wep)
	if (wep && wep.__gcone) then
		return wep:__gcone();
	elseif (!wep.__notice && wep:IsValid()) then
		wep.__notice = true;
		Msg("****** No cone func for ",wep,"! Can't calculate nospread! ******\n");
	end
end

-- smooth-fraction = (math.sin(math.pi + (CurTime()-startsnaptime)*math.pi/finishtime ) + 1.0) * 0.5;
local function TraceAim(dist, penetrate)
	return trace({start = LocalPlayer():cEyePos(), endpos = (LocalPlayer():cEyePos() + LocalPlayer():cGetAimVector() * dist), filter = LocalPlayer()}, penetrate);
end

local function TraceToTargetEyes(target, penetrate)
	return trace({start = LocalPlayer():cEyePos(), endpos = target:cEyePos(), filter = LocalPlayer()}, penetrate);
end

local function TraceToTargetBone(target, penetrate)
	return trace({start = LocalPlayer():cEyePos(), endpos = GetAimPos(target), filter = LocalPlayer()}, penetrate);
end

--TODO: This may not work for some gamemodes as SetEyeAngles is serverside as well
--Those packets that request new eye angles would need to be blocked along with viewpunch requests
local function EnableNoRecoil(bool)
	if (bool) then
		local recoil;
		for k, swep in ipairs(_G.weapons.GetList()) do
			recoil = swep.Primary and swep.Primary.Recoil or nil;
			if (recoil) then
				swep.bakrecoil = swep.bakrecoil or recoil;
				swep.Primary.Recoil = 0;
			end
		end
		for k, ent in ipairs(ents.GetAll()) do
			recoil = ent.Primary and ent.Primary.Recoil or nil;
			if (recoil) then
				ent.bakrecoil = ent.bakrecoil or recoil;
				ent.Primary.Recoil = 0;
			end
		end
	else
		for k, swep in ipairs(_G.weapons.GetList()) do
			if (swep.bakrecoil) then
				swep.Primary.Recoil = swep.bakrecoil;
			end
		end
		for k, ent in ipairs(ents.GetAll()) do
			if (ent.bakrecoil) then
				ent.Primary.Recoil = ent.bakrecoil;
			end
		end
	end
end

---------------------------------------------------------------------------------------------------
--[STAGE 5]:  CONSOLE COMMAND SYSTEM
---------------------------------------------------------------------------------------------------
--TODO: Allow epic commands to have auto-complete functions
concommand.Add(name, function (ply,cmd,args)
	if (args[1]) then
		if (cmds[string.lower(args[1])]) then
			cmds[string.lower(args[1])](ply,cmd,args);
		else
			Print("Invalid command '"..args[1].."'");
			Print("Type 'epic' for a list of valid commands.");
		end
	else
		Print("Commands List:");
		for _, c in ipairs(getsortedkeys(cmds, true)) do
			Print("  - "..c);
		end
	end
end, function(c, a)
	local tbl = { };
	for cmd, func in pairs(cmds) do
		if ((" "..cmd):find(a, 1, true)) then
			table.insert(tbl, "epic "..cmd);
		end
	end
	return tbl;
end);

local function AddConCommand( name, func )
    cmds[string.lower(name)] = func;
end

---------------------------------------------------------------------------------------------------
--[STAGE 6]:  CONSOLE COMMANDS (or How I learned to stop worrying and Love ESP)
---------------------------------------------------------------------------------------------------

concommand.Add("+epic_auto", function() settings.autoshoot = 1 end)
concommand.Add("-epic_auto", function() settings.autoshoot = 0 end)
concommand.Add("+ejump", function() settings.autojump = 1 end)
concommand.Add("-ejump", function() settings.autojump = 0 end)

AddConCommand("save", function(p,c,a)
	SaveData();
end);

AddConCommand("misc_time", function(p,c,a)
	if (!a[2]) then
		Print("Stop doing it rong fukkin faggit.");
	else
		RunConsoleCommand("epic run cvar2.SetValue([[host_timescale]], [[" .. a[2] .. "]])")
	end
end);

AddConCommand("load", function(p,c,a)
	if (!a[2]) then
		Print("usage: load <name> - loads the preference by name or quick index");
		Print("Preferences:");
		Print("----------------------------------");
		for k, pref in ipairs(preflist) do
			Print(tostring(k).." = "..pref);
		end
		Print("----------------------------------");
		return;
	elseif (tonumber(a[2])) then
		a = tonumber(a[2]);
		if (!preflist[a]) then
			Print("Invalid index");
			return;
		end
	else
		a = table.concat(a, " ", 2):lower();
		local found;
		for k, pref in ipairs(preflist) do
			if (pref == a) then
				a = k;
				found = true;
				break;
			end
		end
		
		if (!found) then
			Print("No preference named '"..a.."' exists");
			return;
		end
	end
	LoadPreference(preflist[a]);
end);

--TODO: Sort table before printing
AddConCommand("show_settings", function(p,c,a)
	Print("\tCurrent Settings\n-------------------------");
	for k, name in pairs(settingnames) do
		Print("\t"..name..":\t"..tostring(settings[k]));
	end
end);

AddConCommand("pref_autocreate", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_autocreate <bool> - specifies whether or not preferences should be automatically created for new gamemodes");
		Print("Currently set to "..tostring(preferences.autocreate));
	else
		preferences.autocreate = util.tobool(a[2]);
		Print("Autocreate set");
	end
end);

AddConCommand("pref_override", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_override <name> - the preference name that should be used at all times regardless of gamemode triggers");
		Print("use \"\" to disable override");
	else
		preferences.override = table.concat(a, " ", 2):lower();
		Print("Override set");
	end
end);

AddConCommand("pref_name", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_name <name> [<override?>] - sets the name of the current preference so it can be loaded with perf_load");
		Print("If override is defined the name will override any existing names if there is a conflict");
	else
		a = table.concat(a, " ", 2):gsub("[/\\:%*%?\"%<%>%|]", ""):Trim():lower();
		if (a == "") then
			Print("Invalid name dickwad");
			return;
		end
		if (table.HasValue(preflist, a)) then
			if (a[3]) then
				Print("Preference overridden");
			else
				Print("In order to override '"..a.."' you must call: pref_name \""..a[2].."\" true");
				return;
			end
		else
			preferences.gametriggers[a] = preferences.gametriggers[settings.name];
			preferences.gametriggers[settings.name] = nil;
			for k, name in ipairs(preflist) do
				if (name == settings.name) then
					table.remove(preflist, k);
					break;
				end
			end
			table.insert(preflist, a);
			Print("Preference renamed");
		end
		if (a != settings.name && settings.name != "default") then
			fileD(foldern.."/"..settings.name..".txt");
		end
		settings.name = a;
		SaveData();
	end
end, function(c,a)
	local tbl = { };
	a = table.concat(a, " ");
	for k, pref in ipairs(preflist) do
		if (pref:find(a, 1, true)) then
			table.insert(tbl, pref);
		end
	end
	
	return tbl;
end);

--id based on preflist
local function RemovePreference(id)
	fileD(foldern.."/"..preflist[id]..".txt");
	preferences.gametriggers[preflist[id]] = nil;
	table.remove(preflist, id);
	settings.name = "default";
end

AddConCommand("pref_remove", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_remove <name> - removes the preference by name or number");
		Print("You may type the whole name or use a quick index");
		Print("Preferences:\n");
		Print("----------------------------------");
		for k, v in ipairs(preflist) do
			Print(tostring(k).." = "..v);
		end
		Print("----------------------------------");
		return;
	elseif (tonumber(a[2])) then
		a = tonumber(a[2]);
		if (!preflist[a]) then
			Print("Invalid index");
			return;
		end
	else
		a = table.concat(a, " ", 2):lower();
		local found;
		for k, pref in ipairs(preflist) do
			if (pref == a) then
				a = k;
				found = true;
				break;
			end
		end
		if (!found) then
			Print("No preference exists named '"..a.."'");
			return;
		end
	end
	RemovePreference(a);
	Print("Preference removed");
end, function(a,c)
	local tbl = { };
	a = table.concat(a, " ");
	for k, pref in ipairs(preflist) do
		if (pref:find(a, 1, true)) then
			table.insert(tbl, pref);
		end
	end
	
	return tbl;
end);

AddConCommand("pref_trigger", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_trigger <string> - adds the trigger string for the current preference");
		Print("The string should be a lua pattern which is similar to regular expressions (ex .+ matches 1 or more of any character aka wildcard)");
		Print("More info on patterns at http://lua-users.org/wiki/PatternsTutorial");
		Print("You MUST use % in front of non-alphanumeric characters use %% for a single percent sign.");
	else
		table.insert(preferences.gametriggers[settings.name], a[2]);
		Print("Trigger added to '"..settings.name.."' preference");
	end
end);

AddConCommand("pref_trigger_remove", function(p,c,a)
	if (!a[2]) then
		Print("usage: pref_trigger_remove <string> - removes the trigger string for the current preference");
		Print("You may enter the trigger exactly (no quotes needed) or you may enter its numeratical equivalent");
		Print("Current trigger strings:");
		Print("----------------------------------");
		for k, v in ipairs(preferences.gametriggers[settings.name]) do
			Print(tostring(k).." = "..v);
		end
		Print("----------------------------------");
		return;
	elseif (tonumber(a[2])) then
		a = tonumber(a[2]);
		if (!preferences.gametriggers[settings.name][a]) then
			Print("Invalid index, type pref_remove for list");
			return;
		end
	else
		a = table.concat(a, " ", 2);
		local found;
		for k, trig in ipairs(preferences.gametriggers[settings.name]) do
			if (trig:find(a, 1, true)) then
				a = k;
				found = true;
			end
		end
		
		if (!found) then
			Print("Cannot find trigger, type pref_remove for list");
			return;
		end
	end
	table.remove(preferences.gametriggers[settings.name], a);
	Print("Removed trigger");
end, function(c,a)
	a = table.concat(a, " ");
	local tbl = { };
	for k, trig in ipairs(preferences.gametriggers[settings.name]) do
		if (trig:find(a, 1, true)) then
			table.insert(tbl, trig);
		end
	end
	
	return tbl;
end);

AddConCommand("esp_addent", function(p, c, a)
	if (!a[2]) then
		Print("usage: esp_addent <classname> [<color> [<text>]] - adds entities of classname to the esp, if classname is ! adds the entities of the type you're looking at");
		Print("color may be a predefined basic color(ie red, blue, ect) or an RGB value (Do not use \"\")");
		Print("text can be a string to display on the esp instead of the usual classname");
	else
		local class = a[2];
		local c, text;
		if (a[3]) then
			if (a[4] && a[5] && tonumber(a[5])) then
				if (tonumber(a[3]) && tonumber(a[4])) then
					c = Color(math.Clamp(tonumber(a[3]), 0, 255), math.Clamp(tonumber(a[4]), 0, 255), math.Clamp(tonumber(a[5]), 0, 255));
				else
					Print("RGB values must be numbers");
					return;
				end
			else
				c = a[3]:lower();
				if (colors[a[3]]) then
					c = colors[a[3]];
				else
					Print("No color found named '"..a[3].."' you can use rgb values instead if you still want to use it");
					return;
				end
				c = colors[(a[3] or "gray"):lower()] or colors.gray;
				
				if (a[4]) then
					text = table.concat(a, " ", 4);
				end
			end
		else
			c = colors.gray;
		end
		if (class == "!") then
			class = TraceAim(16000);
			if (class.HitNonWorld && !class.Entity:IsPlayer()) then
				class = class.Entity:GetClass();
			else
				Print("You're not looking at an entity");
				return;
			end
		end
		if (settings.enttbl[class]) then
			Print("Entities of class '"..class.."' are already being drawn!");
			return;
		end
		settings.enttbl[class] = { c, Color(c.r+newcolinc, c.g+newcolinc, c.b+newcolinc), text };
		Print("Now drawing entities of class '"..class.."' on the ESP");
	end
end);

AddConCommand("esp_removeent", function(p, c, a)
	if (!a[2]) then
		Print("usage: esp_removeent <classname> - removes the entity class from the esp, you may also use a quickindex from the list below");
		Print("Current entities:");
		local n = 1;
		for class, v in pairs(settings.enttbl) do
			Print("\t"..tostring(n).." = "..class);
			n = n+1;
		end
	elseif (tonumber(a[2])) then
		local n = 1;
		a = tonumber(a[2]);
		for class, v in pairs(settings.enttbl) do
			if (n == a) then
				settings.enttbl[class] = nil;
				Print("Removed "..class.." from ESP");
				return;
			end
			n = n+1;
		end
		Print("Invalid index");
	else
		if (settings.enttbl[a[2]]) then
			settings.enttbl[a[2]] = nil;
			Print("Removed "..a[2].." from ESP");
		else
			Print("Entity class '"..a[2].."' is not in the ESP list");
		end
	end
end);

AddConCommand("esp_set", function (p, c, a)
	if (!a[2] || !a[3]) then
		Print("usage: esp_set <filter> <state> - filter can be 'players', 'ents', or 'all' and state is whether to enable/disable the given filter");
		Print("ex. esp_set all 1 - shows entities and players\nCurrent settings:");
		Print("Show players: "..tostring(settings.showply));
		Print("Show entities: "..tostring(settings.showent));
	else
		if (a[2] == "players") then
			settings.showply = util.tobool(a[3]);
		elseif (a[2] == "ents") then
			settings.showent = util.tobool(a[3]);
		elseif (a[2] == "all") then
			local en = util.tobool(a[3]);
			settings.showply = en;
			settings.showent = en;
		else
			RunConsoleCommand("esp_set");
			return;
		end
		Print("ESP filter applied for '"..a[2]);
	end
end);

AddConCommand("range", function (ply,cmd,args)
	if (args[2] && tonumber(args[2])) then
		settings.range = math.Clamp(math.floor(tonumber(args[2])),100,100000)
		Print("ESP Range set to "..tostring(settings.range).." units.")
	else
		Print("Usage:  set_range <number>, sets maximum range for ESP.")
		Print("Current range is '"..tostring(settings.range).."' units.")
	end
end);

AddConCommand("Debug_reload_hooks", function (p,c,a)
    for u,n in pairs(hooksrmv) do
        hookA(n,u,hookcalls[u]);
    end
end);

AddConCommand("clear_traitors", ResetTraitors);

local function TargetCone(p,c,a)
    if (a && a[2] && (tostring(a[2]):lower() == "toggle") && (target != NULL)) then
        target = NULL;
        return;
    end

    local temp_ang = settings.targetfov;
    local temp_ent = NULL;
    for _, ply in ipairs(player.GetAll()) do
        if (ply != LocalPlayer()) then
            local tr = TraceToTargetBone(ply, true);
            if (tr && tr.Entity && ValidEntity(tr.Entity) && tr.Entity:IsPlayer() && (target_team || (tr.Entity:Team() == LocalPlayer():Team()) )) then
                local ang = LocalPlayer():cEyePos():AngularDifference(ply:cEyePos(),LocalPlayer():cGetAimVector());
                if (ang <= temp_ang) then
                    temp_ang = ang;
                    temp_ent = ply;
                end
            end
        end
    end

    if (temp_ent != NULL) then
        ResetSnap();
        target = temp_ent;
	end
end
AddConCommand("target_cone", TargetCone);

AddConCommand("target_team", function (p,c,a)
    if (a[2] == "1") then
        target_team = true;
        Print("Now targetting teammates!");
    else 
        if (a[2] == "0") then
            target_team = false;
            Print("Now -NOT- targetting teammates!");
        else
            Print("Toggle targetting teammates <1 or 0>");
        end
    end
end);

local flingactive;
AddConCommand("fling_prop",function(p,c,a)
    if (!a[2]) then
		Print("usage: fling_prop <anything> - enter with args to use, first use enter aim mode, second use release prop. Enter with no args to cancel throw or just drop the prop and release");
		flingactive = false;
	elseif (flingactive) then
		local aim = LocalPlayer():cGetAimVector():Angle();
		aim.y = aim.y+180;
		LocalPlayer():cSetEyeAngles(aim);
		flingactive = false;
	else
		flingactive = true;
	end
	RunConsoleCommand("-forward");
	RunConsoleCommand("-back");
	RunConsoleCommand("-moveleft");
	RunConsoleCommand("-moveright");
end);

AddConCommand("target_clear", function ()
    target = NULL;
end);

local function ClearBoneCache()
	for k, pl in ipairs(player.GetAll()) do
		pl.targetbone = nil;
	end
end

AddConCommand("target_bone", function (p,c,a)
	if (!a[2]) then
      	Print("usage:   target_bone <bonename> - enter the name of the bone (ex. ValveBiped.Bip01_Head1)");
		Print("You may also use one of these shortcuts:");
		Print("\thead - ValveBiped.Bip01_Head1");
		Print("\tbody - ValveBiped.Bip01_Spine2");
		Print("\tupper body - ValveBiped.Bip01_Spine4");
		Print("\tneck - ValveBiped.Bip01_Neck");
		Print("\tpelvis - ValveBiped.Bip01_Pelvis");
		Print("Note: If the bone doesn't exist on a particular model, the next closest bone will be targeted");
    else
		a = (a[2] or ""):lower()..(a[3] or ""):lower();
		settings.targetbone = quickbone[a] or a;
		--lazy head bone accuracy fix
		if (settings.targetbone:lower() == "valvebiped.bip01_head1") then
			settings.targetoff = 4;
		else
			settings.targetoff = 0;
		end
		--clear players bone index cache
		ClearBoneCache();
	end
end);

--Update the bone index cache with a new search every 10 seconds in case the player model changed
--there is currently no way to tell if a entity's model has changed without comparing their GetModel() names
timer.Create(RndString().."update", 10, 0, function()
	ClearBoneCache();
end);

AddConCommand("target_lockonfire", function (p,c,a)
	if (!a[2]) then
		Print("usage:	target_lockonfire <bool> - whether to auto target while holding primary fire (no accuracy loss)");
	else
		settings.lockonfire = util.tobool(a[2]);
		if (settings.lockonfire) then
			Print("Lock on fire enabled\n");
		else
			Print("Lock on fire disabled\n");
		end
	end
end);

AddConCommand("target_fov", function (p,c,a)
	if (!a[2] || !tonumber(a[2])) then
		Print("usage: target_fov <integer> - field of view when finding new targets to lockon to (default: 45)");
	else
		settings.targetfov = tonumber(a[2]);
		Print("fov is now "..settings.targetfov);
	end
end);

AddConCommand("show_admins", function (p,c,a)
    for k,v in ipairs(player.GetAll()) do
        if (v:IsAdmin()) then
            Print("("..settings.AdminName..") "..v:cNick());
        elseif (v:IsSuperAdmin()) then
            Print("("..settings.AdminName..") "..v:cNick());
        end            
    end
end);

AddConCommand("set_admin_name", function (p,c,a)
    if (a[2]) then
        settings.AdminName = a[2];
    end
end);

AddConCommand("set_superadmin_name", function (p,c,a)
    if (a[2]) then
        settings.AdminName = a[2];
    end
end);

AddConCommand("whocanseeme", function (ply,cmd,args)
    if (args[2] && args[2] == "1") then
        bseeme = true;
    elseif (args[2] && args[2] == "0") then
        bseeme = false;
    else
        bseeme = !bseeme;
    end
    
    if (bseeme) then
        Print("[ESP] Now showing players who can see you...");
    else
        Print("[ESP] Now NOT showing players who see you...");
    end
end);

AddConCommand("run", function (p, c, a)
	if (!a[2]) then
		Print("usage: run <string> - runs a lua string");
	else
		RunString(table.concat(a, " ", 2));
	end
end);

AddConCommand("setgame", function (p, c, a)
	if (!a[2]) then
		Print("usage: setgame <game> - sets the internal gametype, this enables/disables gamemode specific functionality and console commands");
		Print("it is likley that new console commands will be available when you switch gametypes, use base for generic functionality");
		Print("Available Gametypes:");
		for name, v in pairs(games) do
			Print("\t"..name);
		end
	else
		if (games[a[2]]) then
			SetGametype(a[2]);
			Print("Gametype set to '"..a[2].."'");
		else
			Print("No such gametype '"..a[2].."'");
		end
	end
end);

AddConCommand("lagcompensation", function(p, c, a)
	a = tonumber(a[2]);
	if (a) then
		if (a <= 0) then
			settings.enablelagcomp = false;
			Print("Lag compensation disabled");
		else
			settings.enablelagcomp = true;
			settings.lagcomp = a;
			Print("Lag compensation enabled with a value of "..tostring(a));
		end
	else
		Print("Usage: lagcompensation <value> - disables lag compensation if value is 0 or negative, otherwise should be between 0 and 1 (default: 0.00001)");
		Print("Seems to be sort of useless right now.");
	end
end);

AddConCommand("whoshotme", function (p,c,a)
    if (a[2] == "1") then
        settings.whoshotme_enabled = true;
        Print("Now showing who shoots you!");
    elseif (a[2] == "0") then
        settings.whoshotme_enabled = false;
        Print("Now -NOT- showing who shoots you, good luck!");
    else
        Print("Beta feature... prints who the script thinks shot at you");
        Print("You can use epic whoshotme_snaphp to set an hp threshold to snap to an attacker");
    end
end);

AddConCommand("whoshotme_snaphp", function(p,c,a)
    if (a[2] && tonumber(a[2])) then
        settings.whoshotme_snaphp = tonumber(a[2])
        Print("Set whoshotme_snaphp = "..a[2]..".");
    else
        Print("Sets an hp threshold to snap to an attacker if your health drops below this number.");
        Print("For Example:  '0' effectively disables this feature, '100' keeps it on all of the time.");
        Print("Current seting: " ..settings.whoshotme_snaphp..".");
    end
end);

AddConCommand("weapon_msgs", function(p,c,a)
    if (a[2] && a[2] == "0") then
        settings.weaponhistory_print = false;
        Print("Now hiding weapon usages from chat.");
    elseif ( a[2] == "1") then
        settings.weaponhistory_print = true;
        Print("Now printing weapon usage message in chat.");
    else
        Print("Set whether to display weapon 'drops' in chat. (1 or 0)");
    end
end);

AddConCommand("target_snaptime",function(p,c,a)
    if ( a[2] && tonumber(a[2]) ) then
        settings.snaptime = tonumber(a[2]);
        Print("Snap time now set to: "..a[2]..".");
    else
        Print("target_snaptime <float/seconds>");
        Print("Sets the time it takes to snap to a target.  Measured in (Seconds / 45 Degrees)");
    end
end);

AddConCommand("target_autoshoot",function(p,c,a)
    if ( a[2] && tonumber(a[2]) ) then
        settings.autoshoot = tonumber(a[2]);
        Print("Autoshoot now set to: "..a[2]..".");
    else
        Print("target_snaptime <1/0>");
        Print("Makes it so you automatically shoot while looking at someone.");
    end
end);

AddConCommand("allowHTML", function(p,c,a)
	if (!a[2]) then
		Print("Usage: allowHTML <bool> - temporarily allows/disallows html panels which can sometimes cause crashes or other unpleasantries");
	else
		local b = util.tobool(a[2]);
		settings.allowHTML = b;
		Print("HTML allowance is set to "..tostring(b));
	end
end);

AddConCommand("cmd_block", function(p,c,a)
	if (!a[2]) then
		Print("Usage: cmd_block <cmd> <allow> - blocks/unblocks the given cmd from being ran through clientside lua - these do not save");
	else
		local b = util.tobool(a[3] or true);
		cmdblock[ a[2] ] = b;
		if (b) then
			Print("Blocking console command "..a[2]);
		else
			Print("Unblocking console command "..a[2]);
		end
	end
end);

if (NoSpreadInstalled) then
	AddConCommand("aim_nospread", function(p,c,a)
		local num = tonumber(a[2]);
		if (!num || num > 1 || num < 0) then
			Print("Usage: aim_nospread <mode> - mode 0 disables nospread, mode 1 enables nospread when firing, mode 2 (TODO) always enabled");
			Print("Be warned. Nospread is obvious to spectators because it makes your screen shake to them.");
		else
			settings.nospread = num;
		end
	end);
else
	Print("Warning: Nospread functions not found! Not loading nospread.");
end

AddConCommand("aim_norecoil", function(p,c,a)
	if (!a[2]) then
		Print("Usage: aim_norecoil <enabled> - enables/disables norecoil when firing (no recoil is always on when tracking a target regardless of this)");
	else
		local b = util.tobool(a[2]);
		settings.norecoil = b;
		if (b) then Print("Norecoil enabled"); EnableNoRecoil(true); else Print("Norecoil disabled"); EnableNoRecoil(false); end
	end
end);

---------------------------------------------------------------------------------------------------
--[STAGE 8]:  HOOKS/TIMERS:
---------------------------------------------------------------------------------------------------
do
local lply, trent, vec, tr, int, dpoint, dpos;
--HUDPAINT:
local function PaintHUD()
	lply = LocalPlayer();

	--Calc eye angles here too for smoothness
	vec = CalcAim();
	if (vec && !settings.lockonfire) then
		lply:cSetEyeAngles(clampviewang(vec:cAngle()));
	end
	
	if (dpoint) then
		SetDrawColor(255, 0, 0, 255);
		dpos = dpoint:cToScreen()
		DrawRect(dpos.x-2, dpos.y-2, 4, 4);
	end
	
	--Draw fling notification
	if (flingactive) then
		local flingcol = colors.red
		flingcol.a = math.abs(math.sin(CurTime()*math.pi))*255;
		DrawShadowText(ScrW()/2 - 30, ScrH()/2 + 10, flingcol, "-=reverse aiming=-");
	end

	tr = TraceAim(2048);
	trent = tr.Entity;
	
	if (settings.showply) then
		--Highlighted player/entity esp
		if (tr.HitNonWorld && trent:IsPlayer()) then
			local pos = trent:cEyePos():cToScreen();
			
			--Draw highlighted player's network variables
			--TODO: Unsupported until custom paint hooks are made for gametypes
			--[[
			local int = 0
			for _, tbl in ipairs(gametable.Float) do
				DrawShadowText( pos.x+10,pos.y+14+(int * 15)+1,Color(25,165,40,255), tostring(tbl[1])..": "..tostring(math.Round(trent:GetNWFloat(tbl[2]))) );
				int = int + 1;
			end
			for _, tbl in pairs(gametable.String) do
				DrawShadowText( pos.x+10,pos.y+14+(int * 15)+1,Color(25,165,40,255), tostring(tbl[1])..": "..tostring(math.Round(trent:GetNWString(tbl[2]))) );
				int = int + 1;
			end
			for _, tbl in pairs(gametable.Bool) do
				DrawShadowText( pos.x+10,pos.y+14+(int * 15)+1,Color(25,165,40,255), tostring(tbl[1])..": "..tostring(math.Round(trent:GetNWBool(tbl[2]))) );
				int = int + 1;
			end]]

			--Draw highlighted player's weapons
			int = 0;
			for k, wep in ipairs(trent:cGetWeapons()) do
				if (!settings.wepnodraw[wep:GetClass()]) then
					DrawShadowText( pos.x+64,pos.y+14+(int*15),Color(255,20,20,255), wep:GetClass() );
					int = int + 1;
				end
			end   

			if (trent.previousguns) then
				for i, gunname in ipairs(trent.previousguns) do
					DrawShadowText(pos.x+64, pos.y+14+(int*15)+(i*15), colors.Alex_Asian_Assporn, "#"..i.." "..gunname);
				end
			end
		end
	 
		--player ESP        
        for k, v in ipairs(player.GetAll()) do
            if (v != lply && v:cAlive() && !v:IsSpectator() ) then
                local dist = PlyInRange(v);
                if (dist) then
                    local scale = 16 * (1 - (dist / settings.range));
					--TODO: avoid doing gametype checks, custom player draw hook given player and screen position??
					local col;
					if (settings.currentgame == "ttt") then
						col = GetTTTColors(v);
					else
						col = _G.team.GetColor(v:Team());
					end
                    local pos = v:cEyePos():cToScreen();

                    local hpfrac = (100 - math.Clamp(v:Health(),0,100)) * 0.01;                    
                    
                    if (hpfrac != 0) then
                        SetDrawColor( col.r*0.5,col.g*0.5, col.b*0.5, 255 );
                        DrawRect( pos.x - (scale*.25),pos.y-(scale*.25),scale,hpfrac*scale) -- darker part
                    end 
                    
                    SetDrawColor( col.r,col.g,col.b,255 ); --lighter part
                    DrawRect( pos.x - (scale*.25),pos.y-(scale*.25)+(hpfrac*scale),scale,scale - (hpfrac*scale) );  
                    
					--Draw highlight border
                    if (trent != NULL && v == trent) then
                        SetDrawColor(255, 255, 255, 200);
                        local n1 = (math.floor(scale*.25));
                        local n2 = (math.floor(scale*.75));
                        DrawLine( pos.x-n1,pos.y-n1,pos.x-n1,pos.y+n2 ); -- left edge
                        DrawLine( pos.x-n1,pos.y-n1,pos.x+n2,pos.y-n1 ); -- top edge
                        DrawLine( pos.x+n2,pos.y-n1,pos.x+n2,pos.y+n2 ); -- right edge
                        DrawLine( pos.x-n1,pos.y+n2,pos.x+n2,pos.y+n2 ); -- bottom edge
                    end
                    
					local str = "";
                    if (v:IsSuperAdmin()) then
						str = "("..settings.AdminName..")";
					elseif (v:IsAdmin()) then
						str = "("..settings.AdminName..")";
					end
                    str = str..v:cNick();
                    DrawShadowText( pos.x+scale,pos.y,Color(245,245,255,255), str, fonts[math.ceil(scale * .0625 * fontdetail) ], 1 );
				end
			end
		end
	end
	
	if (settings.showent) then
		--highlighted weapon ESP
		if (tr.HitNonWorld && trent:IsWeapon()) then
			if (trent.owners) then
				--Draw highlighted weapon's owner history
				local pos = trent:cGetPos():cToScreen();
				DrawShadowText(pos.x+32, pos.y+32, colors.red, "Previous owners:");
				for k, name in ipairs(trent.owners) do
					DrawShadowText(pos.x+32, pos.y+32+(k*15), colors.red, "#"..k.." "..name);
				end
			end
		end
		
        --entity ESP
		local dist, pos, scale, col, owner;
		for class, dtbl in pairs(settings.enttbl) do
			for k, ent in ipairs(ents.FindByClass(class)) do
				owner = ent:GetOwner();
				if (!ValidEntity(owner) || !owner:IsPlayer() || !ent:IsWeapon() ) then
					dist = PlyInRange(ent);
					if (dist) then
						col = dtbl[1];
						SetDrawColor(col.r, col.g, col.b, 255);
						pos = ent:GetPos():cToScreen();
						scale = 16 * (1 - (dist / settings.range));
						DrawRect(pos.x - (scale * 0.25), pos.y - (scale * 0.25), scale, scale);
						
						col = dtbl[2];
						owner = "";
						if (ent.owners) then
							owner = "*";
						end
						DrawShadowText(pos.x+scale, pos.y+scale, col, dtbl[3] or (owner..class), fonts[math.ceil(scale * .0625 * fontdetail)], 1);
					end
				end
			end
		end
    end
	
	if (bseeme) then
		local n = 0;
		for plyid,bcanseeme in pairs(canseeme) do
			if (bcanseeme) then
				n = n + 1;
			end                    
		end
		
		local ydist = 16 * (1 + n);
		local yfrac = ScrH()*.2
		
		SetDrawColor(0,0,0,128);
		DrawRect( 0, yfrac, 128, ydist );
		DrawShadowText( 2,2+yfrac,colors.Traitor_Red,"WHO CAN SEE YOU:");
		
		local i = 0;
		for id,bool in pairs(canseeme) do
			if (bool) then
				local p = ents.GetByIndex(id)
				if (p && IsValid(p) && p:IsPlayer()) then
					i = i + 1;
					DrawShadowText( 2,2+yfrac+i*16,Color(255,255,255,255)," - " .. p:cNick());
				end
			end
		end
	end
end
hookA("HUDPaint", RndString().."paint", PaintHUD);
end

local function AutoShit()
	if(!ValidEntity(LocalPlayer())) then return end
	if( !LocalPlayer():Alive() ) then return end
		
	local ent = LocalPlayer():GetEyeTrace().Entity;

	if(ValidEntity(ent) && settings.autoshoot == 1 && (ent:IsPlayer() || ent:IsNPC())) then
		RunConsoleCommand("+attack")
		timer.Simple(0.01, function() RunConsoleCommand("-attack") end)
    end
end
hookA("Think", RndString().."auto", AutoShit);

--CalcView
hookA("CalcView", RndString().."view", function(ply, org, ang, fov)
	if (flingactive) then
		--flip the view 180
		ang.y = ang.y+180;
		return { origin = org, angles = ang, fov = fov};
	end
end);

do
local lply, curcmd, vec, cwep, seed, ang, _;
--CreateMove:
hookA("CreateMove", RndString().."createmove", function (ucmd)
	lply = LocalPlayer();
	curcmd = lply:GetCurrentCommand();
	vec, ang = nil, nil;
    if (curcmd:KeyDown(1)) then -- IN_ATTACK is down
		if (settings.lockonfire && target == NULL) then
			TargetCone();
		end
		vec = CalcAim();
		if (settings.nospread == 2 || (vec && settings.nospread == 1)) then
			if (vec && settings.nospread == 1) then
				cwep = GetWepCone(lply:GetActiveWeapon());
				if (cwep) then
					vec = vec or lply:GetAimVector();
					_, seed = GetSeedFromUserCmd(ucmd);
					if (seed != 119) then
						ang = ApplySpread(seed, vec, Vector(cwep, cwep, 0)):Angle();
						ang:RotateAroundAxis(vec, 180);
					end
				end
			end
		end
	elseif (settings.lockonfire) then
		target = NULL;
	end
	if (vec) then
		ang = ang or vec:cAngle();
		ucmd:cSetViewAngles(clampviewang(ang));
	end
end);
end

hookA("PlayerBindPress", RndString().."press", function(ply, bind, pressed)
	if (flingactive) then
		--invert movement
		if (bind == "+forward") then
			if (pressed) then
				RunConsoleCommand("+back");
			else
				RunConsoleCommand("-back");
			end
			return true;
		elseif (bind == "+back") then
			if (pressed) then
				RunConsoleCommand("+forward");
			else
				RunConsoleCommand("-forward");
			end
			return true;
		elseif (bind == "+moveleft") then
			if (pressed) then
				RunConsoleCommand("+moveright");
			else
				RunConsoleCommand("-moveright");
			end
			return true;
		elseif (bind == "+moveright") then
			if (pressed) then
				RunConsoleCommand("+moveleft");
			else
				RunConsoleCommand("-moveleft");
			end
			return true;
		end
	end
end);

--PostGamemodeLoaded
--Good place for delayed overrides too
hookA("PostGamemodeLoaded", RndString().."postloaded", function()
	LoadPrefSettings();
	if (preferences.override == "") then
		--load preference based off gamemode
		local done;
		for pref, trigtbl in pairs(preferences.gametriggers) do
			for k, trig in ipairs(trigtbl) do
				if (_G.GAMEMODE.Name:find(trig)) then
					Print("Gamemode identified...");
					if (LoadPreference(pref)) then
						done = true;
						break;
					else
						Print("Unable to load preference '"..pref.."'! Missing/Corrupt file.");
						LoadPreference("default");
						done = true;
						break;
					end
				end
			end
			if (done) then break; end
		end
		if (!done) then
			LoadPreference("default");
		end
	else
		if (LoadPreference(preferences.override)) then
			Print("Loaded override preference '"..preferences.override.."'");
		else
			Print("Unable to load override preference '"..preferences.override.."'! Missing/Corrupt file.");
			LoadPreference("default");
		end
	end
	--populate the preference list
	preflist = fileZ("../data/"..foldern.."/*");
	for k, v in ipairs(preflist) do
		preflist[k] = v:gsub("%.txt$", "");
	end
	table.remove(preflist, 1);
	table.remove(preflist, 1);
	
	local oldcreate = _G.vgui.Create;
	_G.vgui.Create = function(name, parent, whatever, blah, blaah, blaaah)
		if (!settings.allowHTML && name == "HTML") then
			Print("Blocked vgui element 'html' from being created because its fucking glitchy as hell");
			local panel = oldcreate("Panel", parent, whatever, blah, blaah, blaaah);
			panel.OpenURL = function(url)
				Print("Blocked url request for "..tostring(url));
			end
			panel.SetHTML = function(html)
				Print("Block html parse request");
			end
			return panel;
		else
			return oldcreate(name, parent, whatever, blah, blaah, blaaah);
		end
	end
	
	local plyconnect = _G.GAMEMODE.PlayerConnect;
	function _G.GAMEMODE:PlayerConnect(name, ip)
		Msg("PLAYER CONNECTED: ",name," ",ip,"\n");
		if (plyconnect) then
			plyconnect(self, name, ip);
		end
	end
	
	if (NoSpreadInstalled) then
		local cone;
		--Cache all single-shot swep cones
		for k, swep in ipairs(_G.weapons.GetList()) do
			if (swep.Primary && swep.Primary.NumShots == 1) then
				if (swep.GetPrimaryCone) then
					swep.__gcone = swep.GetPrimaryCone;
				elseif (swep.Primary.Cone) then
					swep.__gcone = swep.Get.Primary.Cone;
				end
			end
		end
	end
	
	if (settings.norecoil) then
		EnableNoRecoil(true);
	end
end);

--InitPostEntity
--[[hookA("InitPostEntity", RndString().."initpe", function()
	if (ApplySpread && GetSeedFromUserCmd) then
		--Cache all single-shot swep cones
		for k, swep in ipairs(weapons.GetList()) do
			Msg("Looping ", k, " = ", swep,"\n");
			if (swep.Primary && swep.Primary.NumShots == 1) then
				Msg("Single shot\n");
				if (swep.GetPrimaryCone) then
					Msg("Primary cone function found\n");
					swep.__gcone = swep.GetPrimaryCone;
				end
			end
		end
	end
end);]]

--ShutDown
hookA("ShutDown", RndString().."shutdown", function()
	SaveData();
end);

--Think
whoshotme_think = RndString();
whoshotme_lasthp = 100;
hookA("Think",whoshotme_think,function()
    if (settings.whoshotme_enabled) then
        local lply = LocalPlayer()
        if ( lply && lply:Alive() && !lply:IsSpectator() ) then
            if ( (math.floor(lply:Health()) < math.floor(whoshotme_lasthp or 100)) && lply:Health() > 0 ) then
                whoshotme_lasthp = math.floor(LocalPlayer():Health());
                Print(" [debug] You got shot! -> HP = " .. whoshotme_lasthp );
                local lowest_ply = NULL;
                local lowest_ang = 180;
                for k,v in pairs(player.GetAll()) do
                    if ( v != lply ) then
                        if ( v && v != NULL && ValidEntity(v) && v:Alive() && !v:IsSpectator() && 
                                v:GetActiveWeapon() && ValidEntity(v:GetActiveWeapon()) && 
                                v:GetActiveWeapon():GetClass() && (v:GetActiveWeapon():GetClass() or ""):lower():find("weapon") ) then
                            local dist = v:cEyePos():Distance(lply:cEyePos());
                            local tr = trace({start=v:cGetShootPos(),endpos=v:cGetShootPos()+(v:cGetAimVector()*dist),filter=v});
                            if ( !tr.Hit ) then
                                local ang = v:cEyePos():AngularDifference( (lply:cEyePos()+Vector(0,0,-24)),v:cGetAimVector() );
                                if ( ang < lowest_ang ) then
                                    lowest_ang = ang;
                                    lowest_ply = v;
                                end
                            end
                        end
                    end
                end
                if ( lowest_ang < 30 ) then
                    lply:ChatPrint(lowest_ply:Nick().. " seems to have shot you!");
                    if ( settings.whoshotme_snaphp >= (whoshotme_lasthp or 100)) then
                        target = lowest_ply;
                    end
                end
            end            
        elseif ( whoshotme_lasthp != 100 ) then
            whoshotme_lasthp = 100;
        end
    end    
end);
    
--"WHO CAN SEE ME" TIMER:
timer.Create(RndString(),1.0,0, function ()
	if (bseeme) then
		for pId,bbool in pairs(canseeme) do
			if ( ents.GetByIndex(pId) == NULL ) then
				canseeme[pId] = false;
			end
		end
		
		for k,v in ipairs(player.GetAll()) do
			if (v != LocalPlayer()) then 
				local ctr = TraceToTargetEyes( v );
				
				if (ctr && ctr.Entity && ValidEntity(ctr.Entity) && ctr.Entity:IsPlayer() && (25 > (v:cEyePos():AngularDifference(LocalPlayer():cEyePos(),v:cGetAimVector())))) then
					canseeme[v:EntIndex()] = true;
				else
					canseeme[v:EntIndex()] = false;
				end
			end
		end
	end
end);

---------------------------------------------------------------------------------------------------
--[STAGE 9]:  FINISHING UP
---------------------------------------------------------------------------------------------------
Print("--------------------------------------")
Print("Script loaded...")
Print("Type '"..name.."' for a list of commands.")
Print("Type '"..name.." help' for more info.")
Print("--------------------------------------")
Print("-----------LOADING FINISHED-----------")