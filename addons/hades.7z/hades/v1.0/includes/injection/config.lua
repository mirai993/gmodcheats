local hades = hades
local cfg = {}
local funcs = {}
hades.Config = {}

local _C = {}
_C.__index = _C

function _C:SetValue( val )
	hades.Config.Set( self.Set, self.ID, val )
end

function _C:GetValue()
	return hades.Config.Get( self.Set, self.ID )
end

function _C:GetBool()
	return tobool( self:GetValue() )
end

function _C:GetFloat()
	return tonumber( self:GetValue() )
end

function _C:GetInt()
	return math.Round( self:GetFloat() )
end

function _C:GetString()
	return tostring( self:GetValue() )
end

local function Save()
	hades.Safe.file.Write( "hades/cfg.txt", glon.encode( cfg ) )
end

local function Load()
	cfg = glon.decode( hades.Safe.file.Read( "hades/cfg.txt" ) or "" ) or {}
end
Load()

function hades.Config.Wrap( set, id )
	local o = setmetatable( {}, _C )
	o.Set = set
	o.ID = id
	return o
end

function hades.Config.Create( set, id, val )
	if val == nil then return end
	cfg[set] = cfg[set] or {}
	
	if cfg[set][id] == nil then
		cfg[set][id] = val
	end
	
	Save()
end

function hades.Config.Set( set, id, val )
	if val == nil then
		if id == nil then return end
		val = id
		id = set
		set = "Main"
	end
	cfg[set] = cfg[set] or {}
	local old = cfg[set][id]
	val = tostring( val )
	cfg[set][id] = val
	
	if old ~= nil then
		for k,v in pairs( (funcs[set] or {})[id] or {} ) do
			v( id, old, val )
		end
	end

	Save()
end

function hades.Config.GetAll( set )
	cfg[set] = cfg[set] or {}
	return cfg[set]
end

function hades.Config.Get( set, id )
	if id == nil then
		id = set
		set = "Main"
	end
	cfg[set] = cfg[set] or {}
	return cfg[set][id]
end

function hades.Config.AddCallback( set, id, func )
	funcs[set] = funcs[set] or {}
	funcs[set][id] = funcs[set][id] or {}
	table.insert( funcs[set][id], func )
end