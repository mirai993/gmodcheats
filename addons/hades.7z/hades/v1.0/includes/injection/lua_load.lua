hades.Scripts = {}

local function ParsePath( path, data )
	local base = hades.Scripts
	for b in path:gmatch( "[^/\\]+" ) do
		local f = b:match( "([^/\\]+%.lua)" )
		if f then
			base[b] = data
			return
		else
			base[b] = base[b] or {}
			base = base[b]
		end
	end
end

local greylist = {}

local folders = {
	"lua/includes/",
	"lua/includes/enum/",
	"lua/includes/extensions/",
	"lua/includes/modules/",
	"lua/includes/util/"
}

for _,dir in ipairs( folders ) do
	for _,f in pairs( hades.Safe.file.Find( "../" .. dir .. "*.lua" ) ) do
		greylist[dir .. f] = true
	end
end

--Blocked files go here for now
greylist["lua/includes/!.lua"] = false
greylist["lua/includes/enum/!.lua"] = false
greylist["lua/STBase/gamemode/modules/antihack/client.lua"] = false
greylist["lua/blackadmin/client/cl_voice.lua"] = false
greylist["lua/blackadmin/client/cl_huh.lua"] = false

hades.Hook.Add("CanLuaLoad", "[Hades][CanLuaLoad]", function( path, data )
	if path == "" or path == "@" then return true end
	if path:sub(1,1) == "@" then
		path = path:gsub( "%@", "garrysmod/lua/", 1 )
	end
	path = path:gsub( "garrysmod/", "" ):gsub( "\\" , "/" ):lower()
	
	if path:match( "^hades" ) then return true end
	
	ParsePath( path, data )
	
	local grey = greylist[path]
	
	if grey == true then
		return true
	elseif grey == false then
		hades.Log(LOG_INFO, "Blocked %s", path)
		return false --Gbps 1 x Tool for effort <3
	end
	
	return hades.ScanLua( path, data )
end )

local keywords = {
}

local function Block( path, data )
	hades.Log(LOG_INFO, "LuaFirewall blocked %s", path)
	hades.Safe.file.Write( "hades/blocked/" .. path:gsub("%.lua", ".txt"), data )
end

function hades.ScanLua( path, data )
	for k,v in pairs( keywords ) do
		if data:lower():find( v ) then
			Block( path, data )
			return false
		end
	end
	return true
end