local _spoof = {
	"sv_cheats",
	"host_timescale",
	"host_framerate"
}

local _spoofed = {}

function _R.CVar:Spoof()
	local oldName = self:GetName()
	local oldFlags = self:GetFlags()
	local oldDefault = self:GetDefault()
	
	_spoofed[oldName] = "h_" .. oldName
	
	--No multiple spoofing, it's no good
	if hades.CVar.Get( "h_" .. oldName ) then return end
	print( "Spoofing", oldName )
	
	self:Rename( "h_" .. oldName )
	self:SetFlags( FCVAR_NONE )
	CreateConVar( oldName, oldDefault, oldFlags )
end

function hades.CVar.GetSpoofed( cvar )
	return hades.CVar.Get( _spoofed[cvar] ) or hades.CVar.Get( cvar )
end

function hades.Spoof()
	for k,v in pairs( _spoof ) do
		local cvar = hades.CVar.Get(v)
		if cvar then
			cvar:Spoof()
		end
	end
end
hades.Spoof()