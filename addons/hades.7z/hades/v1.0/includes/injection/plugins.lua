local hades = hades
local _hacks = {}

local _H = {}
_H.__index = _H

function _H:__newindex( k, v )
	if k:sub( 1, 1 ) == "_" then
		self:AddHook( k:sub( 2 ), v )
		return
	end
	rawset( self, k, v )
end

function _H:AddHook( id, func )
	hades.Hook.Add( id, self.Name .. "." .. id, function( ... )
		return func( self, ... )
	end	)
end

function _H:AddConfig( id, val )
	hades.Config.Create( self.Name, id, val )
	self[id] = hades.Config.Wrap( self.Name, id )
end

function _H:AddCommand( cmd, func, bind )
	hades.AddCommand( cmd, function() func( self ) end, bind )
end

function _H:AddTab( label, icon, help, num )
	hades.Tabs = hades.Tabs or {}
	if num then
		table.insert( hades.Tabs, num, { Hack = self, Text = label, Icon = icon, Help = help } )
	else
		table.insert( hades.Tabs, { Hack = self, Text = label, Icon = icon, Help = help } )
	end
end

function hades.Register( name )
	_hacks[name] = setmetatable( { Name = name }, _H )
	return _hacks[name]
end