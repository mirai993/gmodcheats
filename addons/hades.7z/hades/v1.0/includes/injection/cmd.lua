local _cmds = {}

local _C = {}
_C.__index = _C

_C.Command = nil
_C.Bind = nil
_C.Function = nil

function _C:__tostring()
	return string.format( "[Command: %s]", self.Command )
end

function _C:Run( ... )
	local ret = { self.Function( ... ) }
	if ret[1] and ret[1] != "" then
		hades.Notify( LOG_INFO, unpack( ret ) )
	end
end

function _C:Remove()
	_cmds[self.Command] = nil
end

function _C:SetBind( key )
	if self.Bind then
		hades.RemoveBind( self.Bind )
	end
	local oldKey = self.Bind
	self.Bind = key
	
	local wasDown = false
	if oldKey then
		hades.RemoveBind( oldKey )
	end
	
	local ret = hades.CreateBind( key, self.Command )
	if ret == false then
		self.Bind = hades.GetBind( self.Command )
	end
end

function _C:GetBind()
	return self.Bind
end

function hades.AddCommand( cmd, func, bind )
	local tbl = setmetatable( {}, _C )
	tbl.Command = cmd
	tbl.Function = func
	_cmds[cmd] = tbl
	if bind then
		tbl:SetBind( bind )
	end
	return tbl
end

function hades.GetCommand( cmd )
	return _cmds[cmd]
end

function hades.GetCommands()
	return _cmds
end

local _binds = hades.Config.GetAll( "Binds" ) or {}

function hades.GetBind( cmd )
	if type( cmd ) == "number" then
		return _binds[cmd]
	else
		for k,v in pairs( _binds ) do
			if v == tostring( cmd ) then
				return k, v
			end
		end
	end
end

function hades.CreateBind( key, cmd )
	if table.HasValue( _binds, cmd ) then return false end
	hades.AddBind( key, cmd )
end

function hades.AddBind( key, cmd )
	_binds[key] = cmd
	hades.Config.Set( "Binds", key, cmd )
end

function hades.RemoveBind( key )
	_binds[key] = nil
	hades.Config.Set( "Binds", key, nil )
end

hades.Hook.Add( "KeyEvent", "[Hades][KeyEvent]", function( event, key, bind )
	local c = _binds[key]
	if c and hades.GetCommand( c ) then
		local cmd = hades.GetCommand( c )
		if event == 1 then
			cmd:Run()
		elseif c:sub( 1, 1 ) == "+" then
			cmd = hades.GetCommand( "-" .. c:sub( 2 ) )
			if cmd then
				cmd:Run()
			end
		end
		return true
	end
end )