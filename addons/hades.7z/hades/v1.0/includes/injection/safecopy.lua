hades.Safe = {}

hades.Safe.rawget = rawget
hades.Safe.rawset = rawset
hades.Safe.getmetatable = getmetatable
hades.Safe.setmetatable = setmetatable
hades.Safe.RunConsoleCommand = RunConsoleCommand
hades.Safe.ConCommand = _R.Player.ConCommand
hades.Safe.require = require
hades.Safe.include = include
hades.Safe.vguiCreate = vgui.Create
hades.Safe.CreateConVar = CreateConVar
hades.Safe.CreateClientConVar = CreateClientConVar
hades.Safe.file = {}
hades.Safe.file.Exists = file.Exists
hades.Safe.file.Find = file.Find
hades.Safe.file.FindDir = file.FindDir
hades.Safe.file.IsDir = file.IsDir
hades.Safe.file.Read = file.Read
hades.Safe.file.Write = file.Write
hades.Safe.file.ExistsEx = file.ExistsEx

hades.MT = {}

local _safeList = {
	"[GS]etViewAngles",
	"[GS]etButtons",
	"GetAimVector",
	"EyeAngles",
	"GetPos",
	"GetShootPos"
}

local function IsSafe( var )
	for k,v in pairs( _safeList ) do
		if var:find( v ) then
			return true
		end
	end
	return false
end

local function CopyMeta( var )
	local tbl = _R[var]
	local _mt = {}
	for k,v in pairs( tbl ) do
		_mt[k] = v
	end
	_mt.__index = _mt
	hades.MT[var] = _mt
	for k,v in pairs( _R[var] ) do
		if IsSafe( k ) then
			_R[var][k] = nil
		end
	end
	setmetatable( _R[var], {
		__index = function( t, k )
			return hades.MT[var][k]
		end,
		__newindex = function( t, k, v )
			if IsSafe( k ) then
				print( k )
				return
			end
			return rawset( t, k, v )
		end,
		__metatable = {}
	} )
end

CopyMeta( "CUserCmd" )
CopyMeta( "Entity" )
CopyMeta( "Player" )
CopyMeta( "Weapon" )
CopyMeta( "NPC" )