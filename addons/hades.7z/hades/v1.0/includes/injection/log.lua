LOG_DEBUG	= 0
LOG_INFO	= 1
LOG_WARNING	= 2
LOG_ERROR	= 3

local function Color( r, g, b, a )
	a = a or 255
	return { r = tonumber(r), g = tonumber(g), b = tonumber(b), a = tonumber(a) }
end

local clr = {
	[LOG_DEBUG]		= Color( 80, 80, 255 ),
	[LOG_INFO]		= Color( 80, 255, 80 ),
	[LOG_WARNING]	= Color( 255, 255, 80 ),
	[LOG_ERROR]		= Color( 255, 80, 80 )
}

function hades.Log( lvl, str, ... )
	if lvl < LOG_DEBUG or lvl > LOG_ERROR then return end
	hades.WriteLog( lvl, string.format( str, ... ) )
end

function hades.Notify( lvl, str, ... )
	if lvl < LOG_DEBUG or lvl > LOG_ERROR then return end
	chat.AddText( clr[lvl], "[Hades] ", Color( 255, 255, 255 ), string.format( str, ... ) )
end