local _hide = {
	"hades",
	"gmcl_deco",
	"gmcl_luamd5"
}

local function IsSafe( f )
	for k,v in pairs( _hide ) do
		if f:lower():find( v ) then
			return false
		end
	end
	return true
end

function file.Exists( f )
	return IsSafe( f ) and hades.Safe.file.Exists( f ) or false
end

function file.ExistsEx( f, a )
	return IsSafe( f ) and hades.Safe.file.ExistsEx( f, a ) or false
end

function file.IsDir( f )
	return IsSafe( f ) and hades.Safe.file.IsDir( f ) or false
end

function file.IsDir( f )
	return IsSafe( f ) and hades.Safe.file.IsDir( f ) or false
end

function file.Find( f )
	if f:lower():find( "hades" ) or f:lower():find( "gmcl_deco" ) then return {} end
	local l = hades.Safe.file.Find( f )
	for k,v in pairs( l ) do
		if v:lower():find( "hades" ) then
			table.remove( l, k )
		end
	end
	return l
end

function file.FindDir( f )
	if f:lower():find( "hades" ) then return {} end
	local l = hades.Safe.file.FindDir( f )
	for k,v in pairs( l ) do
		if v:lower():find( "hades" ) then
			table.remove( l, k )
		end
	end
	return l
end

function file.Read( f )
	if not IsSafe( f ) then return "" end
	return hades.Safe.file.Read( f )
end

function file.Write( f, w )
	if not IsSafe( f ) then return end
	return hades.Safe.file.Write( f, w )
end

local _list = {
	cl_website = true,
	cl_location = true,
	cl_email = true,
	cl_msn = true,
	cl_aim = true,
	cl_gtalk = true,
	cl_xfire = true
}

function CreateClientConVar( cv, def, save, data )
	if hades.Cmd.Get( cv ) and _list[cv] == nil then
		--hades.Log( LOG_INFO, "Blocked attempt to overwrite command %s", cv )
		--Too much spam
		return GetConVar( "sv_cheats" )
	end
	return hades.Safe.CreateClientConVar( cv, def, save, data )
end

function CreateConVar( cv, def, flags )
	if hades.Cmd.Get( cv ) and _list[cv] == nil then
		--hades.Log( LOG_INFO, "Blocked attempt to overwrite command %s", cv )
		--Too much spam
		return GetConVar( "sv_cheats" )
	end
	return hades.Safe.CreateConVar( cv, def, flags )
end