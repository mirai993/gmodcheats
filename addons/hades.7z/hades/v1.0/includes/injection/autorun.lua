hades.Hook.Add( "EnterGame", "[Hades][EnterGame]", function()
	for _,f in ipairs( hades.Safe.file.Find( "../hades/includes/*.lua" ) ) do
		hades.Include( "hades/includes/" .. f )
	end
	for _,f in ipairs( hades.Safe.file.Find( "../hades/autorun/*.lua" ) ) do
		hades.Include( "hades/autorun/" .. f )
	end
end )