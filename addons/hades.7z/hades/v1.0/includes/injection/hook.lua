hades.Hook = {}

require "hook"
--require "gamemode"
--[[
local function InjectGM( tbl, der )
	for k,v in pairs( tbl ) do
		if type( v ) == "function" then
			tbl[k] = function( gm, ... )
				local newRet = { hades.Hook.Call( k, gm, ... ) }
				if newRet[1] ~= nil then
					return unpack( newRet )
				end
				return v( gm, ... )
			end
		end
	end
end

local oldRegister = gamemode.Register
function gamemode.Register( tab, name, der )
	InjectGM( tab, name )
	return oldRegister( tab, name, der )
end
]]

local oldCall = hook.Call
function hook.Call( name, gm, ... )
	local newRet = { hades.Hook.Call( name, gm, ... ) }
	if newRet[1] ~= nil then
		return unpack( newRet )
	end
	return oldCall( name, gm, ... )
end

local _hooks = {}

function hades.Hook.Add( id, name, func )
	_hooks[id] = _hooks[id] or {}
	_hooks[id][name] = func
end

function hades.Hook.Remove( id, name )
	(_hooks[id] or {})[name] = nil
end

function hades.Hook.Call( id, gm, ... )
	local b, ret
	local HookTable = _hooks[id]
	
	if ( HookTable != nil ) then
		for k, v in pairs( HookTable ) do
			if ( v == nil ) then
				ErrorNoHalt("Hook '"..tostring(k).."' tried to call a nil function!\n")
				HookTable[ k ] = nil // remove this hook
				break;
			else
				// Call hook function
				ret = { pcall( v, gm, ... ) }
				b = ret[1]
				table.remove( ret, 1 )

				if (!b) then
					ErrorNoHalt( "Hook '" .. tostring(k) .. "' Failed: " .. tostring(ret[1]) .. "\n" )
					HookTable[ k ] = nil // remove this hook
				else
					// Allow hooks to override return values
					if (ret[1] != nil) then
						return unpack( ret )
					end
				end
			end
		end
	end

	return unpack( ret or {} )
end