require "glon"

local _h = hades
local function GetHades()
	--Block lua files outside hades from accessing this?
	return _h
end
hades = nil

setmetatable( _G, {
	__index = function( t, k )
		if k == "hades" then
			return GetHades()
		end
		return rawget( t, k )
	end,
	__metatable = {}
} )

hades.Include "hades/includes/injection/log.lua"
hades.Include "hades/includes/injection/hook.lua"
hades.Include "hades/includes/injection/safecopy.lua"
hades.Include "hades/includes/injection/config.lua"

local enabled = hades.Config.Get( "Enabled" )
if not enabled then
	return
end

hades.Include "hades/includes/injection/safe.lua"
hades.Include "hades/includes/injection/cvar.lua"
hades.Include "hades/includes/injection/cmd.lua"
hades.Include "hades/includes/injection/plugins.lua"
hades.Include "hades/includes/injection/lua_load.lua"
hades.Include "hades/includes/injection/autorun.lua"