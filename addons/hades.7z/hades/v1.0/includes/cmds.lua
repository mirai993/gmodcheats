concommand.Add( "h", function( p, c, a )
	local cmd = hades.GetCommand( a[1] )
	if not cmd then
		//hades.Notify( LOG_ERROR, "Invalid command %s.", tostring( a[1] ) )
		return
	end
	
	table.remove( a, 1 )
	local args = a
	
	cmd:Run( unpack( args ) )
end, function( cmd, args )
	local ret = {}
	args = string.Trim( args )
	for k,v in pairs( hades.GetCommands() ) do
		if k:match( "^" .. args ) == args then
			table.insert( ret, string.format("%s %s", cmd, k ) )
		end
	end
	table.sort( ret )
	return ret
end )