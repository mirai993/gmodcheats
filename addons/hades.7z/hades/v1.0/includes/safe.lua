local greylist = {}
local safeTables = {}

local function Safetize( tbl, name )
	tbl.__Name = name
	safeTables[name] = table.Copy( tbl )
	
	for k,v in pairs( tbl ) do
		print( k )
		
		tbl[k] = nil
	end
	
	hades.Safe.setmetatable( tbl, {
		__index = function( t, k )
			return safeTables[name][k]
		end,
		__newindex = function( t, k, v )
			print( t, k, v, safeTables[t.__Name][k] )
			if safeTables[t.__Name][k] ~= nil then
				hades.Log( LOG_WARNING, "Blocked attempt to overwrite %s in %s!", k, t.__Name )
				return false
			end
			safeTables[t.__Name][k] = v
		end,
		__metatable = true
	} )
end

--Safetize( hades, "hades" )

local function IsSafe( t )
	for k,v in pairs( safeTables ) do
		if v == t then return true end
	end
	return false
end

function rawget( t, k )
	return hades.Safe.rawget( t, k )
end

function rawset( t, k, v )
	if IsSafe( t ) then
		hades.Log( LOG_WARNING, "Blocked attempt to overwrite %s in table %s!", k, t.__Name )
		return false
	end
	return hades.Safe.rawset( t, k, v )
end
--[[
local oldAdd = concommand.Add
print( "oldAdd = " .. tostring( concommand.Add ) )
function concommand.Add( cmd, func, auto )
	if cmd == "GbpsAntiCheat" then return end
	oldAdd( cmd, func, auto )
end]]