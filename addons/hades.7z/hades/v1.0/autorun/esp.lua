local HACK = hades.Register( "Wallhack" )

HACK:AddConfig( "Enabled", true )

--Players
local STYLE_WIREFRAME = 1
local STYLE_SKELETON = 2
local STYLE_FULLBRIGHT = 3
local STYLE_TEAMCOLOR = 4
local STYLE_L4D = 5

--Projectiles
local Projectiles = {
	"rpg_missile",
	"crossbow_bolt",
	"npc_grenade_frag",
	"grenade_ar2",
	"prop_combine_ball",
	"npc_satchel",
}

--Thanks Gbps for the idea :D
local Deathrun_Hax = {
	"func_door",
	"func_door_rotating",
	"func_movelinear",
	"func_rotating",
	"func_illusionary",
	"ent_laser",
}

HACK:AddConfig( "Draw_Style", STYLE_SKELETON )
HACK:AddConfig( "Draw_Players", true )
HACK:AddConfig( "Draw_Box", true )
HACK:AddConfig( "NoDraw_Players", false )
HACK:AddConfig( "Draw_Dead", false )
HACK:AddConfig( "Draw_Team", true )
HACK:AddConfig( "Draw_Reticle", false )
HACK:AddConfig( "Draw_Box_Projectile", false )
HACK:AddConfig( "Draw_Deathrun_Hax", false )
HACK:AddConfig( "Draw_Light", true )
HACK:AddConfig( "S_Light", true )
HACK:AddConfig( "Draw_Self_Light", true )
HACK:AddConfig( "Light_Radius", 80.0 )
HACK:AddConfig( "Light_Brightness", 1.0 )
HACK:AddConfig( "Self_Light_Radius", 80.0 )

--Player info
HACK:AddConfig( "Draw_Info_Name", true )
HACK:AddConfig( "Draw_Info_Health", true )
HACK:AddConfig( "Draw_Info_Weapon", true )

hades.ESP = HACK
--Contains player drawing stuff
hades.Include "hades/autorun/esp/player.lua"
hades.ESP = nil

function HACK:DrawBox( ply )
	local center = ply:LocalToWorld( ply:OBBCenter() )
	local min,max = ply:WorldSpaceAABB()
	local dim = max - min
			
	local front = ply:GetForward()*(dim.y/2)
	local right = ply:GetRight()*(dim.x/2)
	local top = ply:GetUp()*(dim.z/2)
	local back = (ply:GetForward()*-1)*(dim.y/2)
	local left = (ply:GetRight()*-1)*(dim.x/2)
	local bottom = (ply:GetUp()*-1)*(dim.z/2)
	local FRT = center+front+right+top
	local BLB = center+back+left+bottom
	local FLT = center+front+left+top
	local BRT = center+back+right+top
	local BLT = center+back+left+top
	local FRB = center+front+right+bottom
	local FLB = center+front+left+bottom
	local BRB = center+back+right+bottom
			
	FRT = FRT:ToScreen()
	BLB = BLB:ToScreen()
	FLT = FLT:ToScreen()
	BRT = BRT:ToScreen()
	BLT = BLT:ToScreen()
	FRB = FRB:ToScreen()
	FLB = FLB:ToScreen()
	BRB = BRB:ToScreen()
	
	local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	
	surface.SetDrawColor( 255, 0, 0, 255 )
	
	surface.DrawLine( xmax, ymax, xmax, ymin )
	surface.DrawLine( xmax, ymin, xmin, ymin )
	surface.DrawLine( xmin, ymin, xmin, ymax )
	surface.DrawLine( xmin, ymax, xmax, ymax )
end

function HACK:_Think()
	if self.Draw_Self_Light:GetBool() then
		local dlight = DynamicLight( LocalPlayer():EntIndex() )
		if not LocalPlayer():Alive() then return end
		if ( dlight ) then
			dlight.Pos = LocalPlayer():GetPos()
			dlight.r = 255
			dlight.g = 255
			dlight.b = 255
			dlight.Brightness = self.Light_Brightness:GetFloat()
			dlight.Size = self.Self_Light_Radius:GetFloat()
			dlight.Decay = self.Self_Light_Radius:GetFloat() * 5
			dlight.DieTime = CurTime() + 1
		end
	end
	if self.Draw_Light:GetBool() then
		for k, v in pairs( player.GetAll() ) do
			if v == LocalPlayer() then return end
			if not v:Alive() then return end
			local dlight = DynamicLight( v:EntIndex() )
			if ( dlight ) then
				dlight.Pos = v:GetPos()
				dlight.r = 255
				dlight.g = 255
				dlight.b = 255
				dlight.Brightness = self.Light_Brightness:GetFloat()
				dlight.Size = self.Light_Radius:GetFloat()
				dlight.Decay = self.Light_Radius:GetFloat() * 5
				dlight.DieTime = CurTime() + 1
			end
		end
	end
end

function HACK:_HUDPaint()
	if self.Draw_Box_Projectile:GetBool() then
		for _, ent in pairs( ents.GetAll() ) do
			for k, v in pairs( Projectiles ) do
				if ent:GetClass():lower():find( v ) then
					self:DrawBox( ent )
				end
			end
		end
	end
	if self.Draw_Deathrun_Hax:GetBool() then
		for _, ent in pairs( ents.GetAll() ) do
			for k, v in pairs( Deathrun_Hax ) do
				if ent:GetClass():lower():find( v ) then
					self:DrawBox( ent )
				end
			end
		end
	end
end

function HACK:_PostDrawOpaqueRenderables()
	if not self.Draw_Reticle:GetBool() then return end
	local tr = LocalPlayer():GetEyeTrace()
	local Pos,Normal = tr.HitPos, tr.HitNormal
	
	Pos = Pos + Normal
	
	cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( Material( "sprites/reticle" ) )
		render.DrawQuadEasy( Pos, Normal, 64, 64, Color( 255, 255, 255, 255 ) )
	cam.End3D()
end

function HACK:_RenderScreenspaceEffects( gm )
	gm:RenderScreenspaceEffects()
	if self.S_Light:GetBool() then
		render.SuppressEngineLighting( true )
	else
		render.SuppressEngineLighting( false )
	end
	if not self.Enabled:GetBool() then return end
	if self.Draw_Players:GetBool() then
		self:DrawPlayers()
	end
	for _,ent in ipairs( ents.GetAll() ) do
		if ent and IsValid( ent ) and ent != LocalPlayer() then
			self:DrawESP( ent )
		end
	end
end

function HACK:DrawESP( ent )
	if ent:IsPlayer() and self.Draw_Players:GetBool() then
		self:DrawPlayer( ent )
	end
end

function HACK:BuildMenu( panel )
	panel:CheckBox( "Enabled", self.Enabled )
	local cat = panel:Category( "Players" )
		local c = cat:MultiChoice()
			c:AddChoice( "Wireframe" )
			c:AddChoice( "Skeleton" )
			c:AddChoice( "Fullbright" )
			c:AddChoice( "Team colored" )
			c:AddChoice( "L4D glow" )
			c:SetConfig( self.Draw_Style )
		
		cat:CheckBox( "Draw players", self.Draw_Players )
		cat:CheckBox( "NoDraw players", self.NoDraw_Players )
		cat:CheckBox( "Draw dead players", self.Draw_Dead )
		cat:CheckBox( "Draw teammates", self.Draw_Team )
	
	cat = panel:Category( "ESP" )
		cat:CheckBox( "Draw name", self.Draw_Info_Name )
		cat:CheckBox( "Draw health", self.Draw_Info_Health )
		cat:CheckBox( "Draw weapon", self.Draw_Info_Weapon )
	cat = panel:Category( "Lighting" )
			
		cat:CheckBox( "Suppress Engine Lighting", self.S_Light )
		cat:CheckBox( "Draw light", self.Draw_Light )
		cat:CheckBox( "Draw light on self", self.Draw_Self_Light )
		cat:Slider( "Light radius", self.Light_Radius, 60, 600 )
		cat:Slider( "Light radius on self", self.Self_Light_Radius, 60, 600 )
		cat:Slider( "Light Brightness", self.Light_Brightness, 1, 10 )
	cat = panel:Category( "Other" )
		cat:CheckBox( "Draw reticle", self.Draw_Reticle )
		cat:CheckBox( "Highlight projectiles", self.Draw_Box_Projectile )
		cat:CheckBox( "Deathrun", self.Draw_Deathrun_Hax )
end

HACK:AddTab( "Wallhack", "gui/silkicons/world", "See through walls" )