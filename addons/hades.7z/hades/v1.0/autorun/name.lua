--[[local HACK = hades.Register( "Name" )

HACK:AddConfig( "Hide_Name", false )

function HACK:_Think()
	if self.Hide_Name:GetBool() then
		LocalPlayer():ConCommand( "setinfo", "name", " " )
	end
end

function HACK:BuildMenu( panel )
	panel:CheckBox( "Hide name", self.Hide_Name )
end

HACK:AddTab( "Name", "gui/silkicons/user", "Change your name" )--]]