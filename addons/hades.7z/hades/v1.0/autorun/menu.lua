hades.Include "hades/autorun/menu/panel.lua"

local HACK = hades.Register( "Menu" )
local MENU = derma.DefineControl( "HMenu", "Hades configuration menu", {}, "DFrame" )
--local admin = _R.Player:IsAdmin()
--local sadmin = _R.Player:IsSuperAdmin()
HACK:AddConfig( "Spamflashlight", false )
HACK:AddConfig( "Spamattack", false )
HACK:AddConfig( "Spamchat", false )
HACK:AddConfig( "Client_Admin", false )
HACK:AddConfig( "Bhoping", false )
HACK:AddConfig( "Bhop", false )

local _greylist = {
	"hax",
	"hack",
	"kickme",
	"_f_",
	"azucheck",
	"bbot",
	"deco",
	"gbps",
	"say",
	"quti",
	"quit",
	"exit",
	"toggleconsole",
	"gameui",
	"exec",
	"disconnect",
	"hades",
	"sv_cheats",
	"sv_scriptenforcer",
}

function MENU:Init()
	self.PropertySheet = vgui.Create( "DPropertySheet", self )
	self:SetTitle( "Hades Config" )
	self:Center()
	self:MakePopup()
	self:ShowCloseButton( false )
	self:LoadTabs()
end

function MENU:OnKeyCodePressed( key )
	local cmd = hades.GetCommand( "menu" )
	if key == cmd:GetBind() then
		cmd:Run()
		return
	end
end

function MENU:LoadTabs()
	self.PropertySheet.Items = {}
	for k,v in ipairs( hades.Tabs ) do
		local panel = vgui.Create( "HPanel" )
		v.Hack:BuildMenu( panel.List )
		self.PropertySheet:AddSheet( v.Text, panel, v.Icon, false, false, v.Help )
	end
end

function MENU:PerformLayout()
	DFrame.PerformLayout( self )
	self:SetSize( 640, 400 )
	self.PropertySheet:StretchToParent( 5, 25, 5, 5 )
end

function MENU:Close()
	self:SetVisible( false )
end

function HACK:Toggle( b )
	if not self.Menu then
		self.Menu = vgui.Create( "HMenu" )
	end
	self.Enabled = (b != nil) and b or (not self.Enabled)
	self.Menu:SetVisible( self.Enabled )
end

HACK:AddCommand( "menu", function( self )
	self:Toggle()
end, KEY_X )

function HACK:RandomString()
	local j, r = 0, ""
		
	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function HACK:StartBhop()
	self.BhopingEn = true
end

function HACK:StopBhop()
	self.BhopingEn = false
end

HACK:AddCommand( "+bhop", function( self )
	self:StartBhop()
end )

HACK:AddCommand( "-bhop", function( self )
	self:StopBhop()
end )

function HACK:_CreateMove( gm, cmd )
	gm:CreateMove( cmd )
	if self.BhopingEn and ( cmd:GetButtons() & IN_JUMP > 0 ) then
		hades.Log( 1, "Bhopen" )
		cmd:SetButtons( cmd:GetButtons() | IN_JUMP )
		if cmd:GetButtons() & IN_JUMP > 0 then
			cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
		end
	end
end

--[[
function usermessage.IncomingMessage( name, msg )
	if not HACK.Logumsg:GetBool() then return end
	hades.Log( 1, "Incoming Usermessage %q", name )
	incoming( name, msg )
end
--[
function HACK:_ProcessUserMessage( id, msg )
	if id == 29 then
		if self.Logumsg:GetBool() then
			hades.Log( 3, "Incoming sendlua usermessage, contents: %s", msg:ReadString() )
		end
		if self.Sendluafirewall:GetBool() then
			for k, v in pairs( _greylist ) do
				if msg:ReadString():lower():find( v ) then
					hades.Log( 3, "Sendlua firewall packet caught: %s", msg:ReadString() )
					return false
				end
			end
		end
		if self.Blocksendlua:GetBool() then
			return false
		end
		return
	end
end


function _R.Player:IsAdmin()
	if HACK.Client_Admin:GetBool() then
		return true
	end
	return admin
end

function _R.Player:IsSuperAdmin()
	if HACK.Client_Admin:GetBool() then
		return true
	end
	return sadmin
end
--]]
function HACK:_Think()
	if self.Spamflashlight:GetBool() then
		RunConsoleCommand( "impulse", "100" )
	end
	if self.Spamattack:GetBool() then
		RunConsoleCommand( "+attack" )
		timer.Simple( 0.1, function()
			RunConsoleCommand( "-attack" )
		end )
	end
	if self.Spamchat:GetBool() then
		RunConsoleCommand( "say", self:RandomString() )
	end
end

function HACK:BuildMenu( panel )
	panel:Bind( "Menu toggle", "menu" )
	panel:Bind( "Bunny hop", "+bhop" )
	cat = panel:Category( "Spam" )
		cat:CheckBox( "Spam flashlight", self.Spamflashlight )
		cat:CheckBox( "Spam attack", self.Spamattack )
		cat:CheckBox( "Spam chat", self.Spamchat )
	cat = panel:Category( "Commands" )
		cat:Button( "Dump Lua", "dumplua" )
end
HACK:AddTab( "Hades", "hades/logo_small", "General Hades options", 1 )