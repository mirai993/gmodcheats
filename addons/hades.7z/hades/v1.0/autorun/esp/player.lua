local esp = hades.ESP

local Color = Color

local colPlayer = Color( 255, 255, 255 )
local colEntity = Color( 255, 0, 0 )
local colShadow = Color( 40, 40, 40 )

local STYLE_WIREFRAME = 1
local STYLE_SKELETON = 2
local STYLE_FULLBRIGHT = 3
local STYLE_TEAMCOLOR = 4
local STYLE_L4D = 5

local _bones = {
	{ "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
}

local function GetBonePos( ply, bone )
	return ply:GetBonePosition( ply:LookupBone( bone ) )
end

local function GetBoneScreenPos( ply, bone )
	return GetBonePos( ply, bone ):ToScreen()
end

local function Filter( ply )
	return (
		( ply:Alive() or esp.Draw_Dead:GetBool() ) and
		( ply:Team() != LocalPlayer():Team() or esp.Draw_Team:GetBool() )
	)
end

local function GetDrawAlpha( ply )
	local dist = LocalPlayer():GetPos():Distance( ply:GetPos() )
	return math.Clamp( 255/(dist/1000), 0, 255 )
end

function GetDrawColor( ply )
	local t = ply:Team()
	local col = team.GetColor( t ) or colPlayer
	
	col.a = GetDrawAlpha( ply )

	return col
end

--[[
--		ESP
--]]
local surface = surface
local function DrawHealthBar( fr, x, y, w, h, a )
	x = (x - (w/2))
	--Draw bar
	surface.SetDrawColor( 80, 255, 80, a )
	surface.DrawRect( x+1, y+1, (w*fr)-2, h-2 )
	--Draw background
	surface.SetDrawColor( 180, 180, 180, a/2 )
	surface.DrawRect( x, y, w, h )
	--Draw shadow
	local col = colShadow
	surface.SetDrawColor( col.r, col.g, col.b, a )
    surface.DrawOutlinedRect( x, y, w, h)
end

function DrawPlayerInfo( ply, bone )
	local pos = GetBonePos( ply, bone )
	
	--Info
	local col = Color( 255, 255, 255 )
	
	local shadow = colShadow
	shadow.a = GetDrawAlpha( ply )
	
	if esp.Draw_Info_Name:GetBool() then
		local namePos = pos:ToScreen()
		draw.SimpleTextOutlined(
			ply:Name(),		--Text
			"default",			--Font
			namePos.x,				--X coordinate
			namePos.y,				--Y coordinate
			col,				--Color
			TEXT_ALIGN_CENTER,	--Text horiz. align
			TEXT_ALIGN_CENTER,	--Text vert. align
			1,					--Shadow offset in px
			shadow				--Shadow colour
		)
	end
	
	if esp.Draw_Info_Health:GetBool() then
		local barPos = pos:ToScreen()
		barPos.y = barPos.y + 7
		DrawHealthBar(
			math.Clamp( ply:Health()/100, 0, 1 ),			--Fraction
			barPos.x,			--X coordinate
			barPos.y,		--Y coordinate
			50,			--Width
			10,				--Height
			GetDrawAlpha( ply )
		)
	end
	
	if esp.Draw_Info_Weapon:GetBool() then
		local weaponPos = pos:ToScreen()
		weaponPos.y = weaponPos.y + 23
		
		local weapon = ply:GetActiveWeapon()
		if not weapon or not weapon:IsValid() then return end
		
		local text = weapon:GetPrintName()
		draw.SimpleTextOutlined(
			text,		--Text
			"default",			--Font
			weaponPos.x,		--X coordinate
			weaponPos.y,		--Y coordinate
			col,				--Color
			TEXT_ALIGN_CENTER,	--Text horiz. align
			TEXT_ALIGN_CENTER,	--Text vert. align
			1,					--Shadow offset in px
			shadow				--Shadow colour
		)
	end
end

local _mats = {}

local function AddMaterial( name, base, shader )
	if !shader then shader = "VertexLitGeneric" end
	name = name:lower()
	
	local mat = CreateMaterial("hades_" .. name, shader, {
		["$basetexture"] = base,
		["$ignorez"] = 1
	})
	_mats[name] = mat
end

AddMaterial( "solid", "models/debug/debugwhite" )
AddMaterial( "wireframe", "models/wireframe", "Wireframe" )

local getall = player.GetAll
local white = Color( 255, 255, 255 )
local cam = cam
local render = render
local FullBright = render.SuppressEngineLighting
local IgnoreZ = cam.IgnoreZ
local SetMaterialOverride = SetMaterialOverride

local function Draw(ent, r, g, b, a)
	render.SetColorModulation(r / 255, g / 255, b / 255)
	render.SetBlend(a / 255)
	
	ent:DrawModel()
end

local function DrawMaterialStuff( style )
	FullBright( true )
	cam.Start3D( EyePos(), EyeAngles() )
	pcall( function()
		local mat = _mats.wireframe
		if style == STYLE_TEAMCOLOR then
			mat = _mats.solid
		elseif style == STYLE_FULLBRIGHT then
			mat = nil
		end
		IgnoreZ( true )
		SetMaterialOverride( mat )
		for k,v in pairs( getall() ) do
			if not Filter( v ) then
				SetMaterialOverride( nil )
				IgnoreZ( false )
				FullBright( false )
				
				v:DrawModel()
				
				FullBright( true )
				IgnoreZ( true )
				SetMaterialOverride( mat )
			else
				local clr = (style == STYLE_FULLBRIGHT or style == STYLE_WIREFRAME) and white or GetDrawColor( v )
				Draw( v, clr.r, clr.g, clr.b, 255 )
			end
		end
		SetMaterialOverride( nil )
		IgnoreZ( false )
	end )
	cam.End3D()
	FullBright( false )
end

--[[
--		SKELETON
--]]
local drawline = surface.DrawLine
local function DrawSkeleton( ply )
	for _,t in ipairs( _bones ) do
		pos1 = GetBoneScreenPos( ply, t[1] )
		pos2 = GetBoneScreenPos( ply, t[2] )
		drawline( pos1.x, pos1.y, pos2.x, pos2.y )
	end
end

function esp:DrawPlayers()
	local style = self.Draw_Style:GetInt()
	if style == STYLE_WIREFRAME or style == STYLE_FULLBRIGHT or style == STYLE_TEAMCOLOR then
		DrawMaterialStuff( style )
	end
end
local setdrawcolor = surface.SetDrawColor
function esp:DrawPlayer( ent )
	if not Filter( ent ) then
		ent:SetRenderMode( RENDERMODE_NORMAL )
		return
	end
	
	if self.NoDraw_Players:GetBool() then
		ent:SetRenderMode( RENDERMODE_NONE )
	else
		ent:SetRenderMode( RENDERMODE_NORMAL )
	end
	
	local col = GetDrawColor( ent )
	setdrawcolor( col.r, col.g, col.b, col.a )
	
	if self.Draw_Style:GetInt() == STYLE_SKELETON then
		DrawSkeleton( ent )
	end
	
	DrawPlayerInfo( ent, "ValveBiped.Bip01_Pelvis" )
end