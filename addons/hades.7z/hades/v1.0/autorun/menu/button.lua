local BUTTON = derma.DefineControl( "HButton", "", {}, "DButton" )

AccessorFunc( BUTTON, "Command", "Command", FORCE_STRING )

function BUTTON:DoClick()
	if self.Command and self.Command:len() > 0 then
		local cmd = hades.GetCommand( self.Command )
		if cmd then
			cmd:Run()
		end
	end
end