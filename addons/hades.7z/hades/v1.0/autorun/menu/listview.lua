local LISTVIEW = derma.DefineControl( "HListView", "", {}, "DListView" )

AccessorFunc( LISTVIEW, "Column", "Column", FORCE_STRING )
AccessorFunc( LISTVIEW, "Line", "Line", FORCE_STRING )

function LISTVIEW:AddColumn( c )
	self.Column = c
	self:AddColumn( c )
end

function LISTVIEW:AddLine( ... )
	self.Line = ...
	self:AddLine( ... )
end