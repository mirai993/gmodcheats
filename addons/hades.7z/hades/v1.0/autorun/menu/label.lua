local LABEL = derma.DefineControl( "HLabel", "", {}, "DLabel" )

AccessorFunc( LABEL, "Text", "Text", FORCE_STRING )

function LABEL:SetText( txt )
	self.Text = txt
	self:SetText( txt )
end