local BIND = derma.DefineControl( "HBind", "", {} )

AccessorFunc( BIND, "Label", "Label", FORCE_STRING )
AccessorFunc( BIND, "Command", "Command" )

BIND.SetText = BIND.SetLabel

function BIND:Init()
end

function BIND:PerformLayout()
	self:SetTall( 20 )
end

function BIND:SetBind( k )
	if not self.Command then return end
	if k == KEY_BACKSPACE then
		k = nil
	end
	if not hades.GetBind( k ) then
		self.Command:SetBind( k )
	elseif hades.GetBind( k ) != self.Command.Command then
		self.Failed = true
		self.FailTime = RealTime()
	end
end

local block
function BIND:WaitForKey( k )
	if not k then
		self.Waiting = true
		block = vgui.Create( "DPanel" )
		block:SetPos( 0, 0 )
		block:SetSize( ScrW(), ScrH() )
		block:MakePopup()
		block.Paint = function()
			return true
		end
		block.OnMousePressed = function( bl, mcode )
			self:WaitForKey( mcode )
		end
		block.OnKeyCodePressed = function( bl, kcode )
			self:WaitForKey( kcode )
		end
	else
		self.Waiting = false
		if block then
			block:Remove()
			block = nil
		end
		self:SetBind( k )
	end
end

function BIND:OnMousePressed( mcode )
	if mcode == MOUSE_LEFT then
		self:WaitForKey()
	end
end

local _keys = {}

_keys[MOUSE_LEFT] = "MOUSE1"
_keys[MOUSE_RIGHT] = "MOUSE2"
_keys[MOUSE_MIDDLE] = "MOUSE3"
_keys[MOUSE_4] = "MOUSE4"
_keys[MOUSE_5] = "MOUSE5"

for k,v in pairs( _G ) do
	if k:sub( 1, 4 ) == "KEY_" or k:sub( 1, 3 ) == "IN_" then
		_keys[v] = k:gsub( "KEY_", "" ):gsub( "IN_", "" )
	end
end

local icon = Material( "gui/silkicons/brick_add" )

function BIND:Paint()
	local color
	local skin = derma.GetDefaultSkin()
	skin:DrawGenericBackground( 0, 0, self:GetWide(), self:GetTall(), skin.bg_color )
	if self.Waiting then
		color = skin.control_color_active
	elseif not self.Hovered then
		color = skin.colTab
	else
		color = skin.colTabInactive
	end
	skin:DrawGenericBackground( 0, 0, self:GetWide(), self:GetTall(), color )
	if self.Command then
		surface.SetMaterial( icon )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRect( 10, 2, 16, 16 )
		
		draw.SimpleText( self.Label, "default", 31, self:GetTall()/2 - 1, skin.colTabText, nil, TEXT_ALIGN_CENTER )
		local key = _keys[self.Command:GetBind()]
		if not key then
			key = "<NOT BOUND>"
		end
		if self.Waiting then
			key = "Waiting for input... press BACKSPACE to clear"
		end
		if self.Failed and RealTime() < self.FailTime + 4 then
			key = "Key already bound to another command"
		end
		draw.SimpleText( key, "default", self:GetWide() - 10, self:GetTall()/2 - 1, skin.colTabText, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
	end
end