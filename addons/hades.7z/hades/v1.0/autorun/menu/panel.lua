hades.Include "hades/autorun/menu/button.lua"
hades.Include "hades/autorun/menu/checkbox.lua"
hades.Include "hades/autorun/menu/bind.lua"
hades.Include "hades/autorun/menu/infobox.lua"
--hades.Include "hades/autorun/menu/listview.lua"
hades.Include "hades/autorun/menu/list.lua"
hades.Include "hades/autorun/menu/textbox.lua"
hades.Include "hades/autorun/menu/multichoice.lua"
hades.Include "hades/autorun/menu/label.lua"

local PANEL = derma.DefineControl( "HPanel", "", {}, "DPanel" )

function PANEL:Init()
	self.BaseClass.Init( self )
	self.List = vgui.Create( "HPanelList", self )
	self.List:SetAutoSize( false )
	self.List:EnableVerticalScrollbar( true )
end

function PANEL:PerformLayout()
	self.BaseClass.PerformLayout( self )
	self.List:StretchToParent( 0, 0, 0, 0 )
end