local LIST = derma.DefineControl( "HPanelList", "", {}, "DPanelList" )

function LIST:Init()
	self.BaseClass.Init( self )
	self:SetSpacing( 5 )
	self:SetPadding( 5 )
	self:SetAutoSize( true )
	self:EnableHorizontal( false )
	self:EnableVerticalScrollbar( false )
end

function LIST:PerformLayout()
	self.BaseClass.PerformLayout( self )
end

function LIST:Paint()
	return true
end

function LIST:MultiChoice()
	local mul = vgui.Create( "HMultiChoice" )
	mul:SetEditable( false )
	self:AddItem( mul )
	return mul
end

function LIST:Category( label )
	local cat = vgui.Create( "DCollapsibleCategory" )
	cat:SetExpanded( false )
	cat:SetLabel( label )
	
	cat.Panel = vgui.Create( "HPanelList" )
	cat:SetContents( cat.Panel )
	
	self:AddItem( cat )
	return cat.Panel
end

function LIST:Button( label, cmd )
	local btn = vgui.Create( "HButton" )
	btn:SetText( label )
	btn:SetCommand( cmd )
	self:AddItem( btn )
	return btn
end

function LIST:CheckBox( label, cfg )
	local box = vgui.Create( "HCheckBox" )
	box:SetText( label )
	box:SetTextColor( Color( 0, 0, 0, 255 ) )
	box:SetConfig( cfg )
	self:AddItem( box )
	return box
end

function LIST:TextBox( cfg )
	local txt = vgui.Create( "HTextBox" )
	txt:SetConfig( cfg )
	self:AddItem( txt )
	return txt
end
--[[
function LIST:ListView( column, column2, ... )
	local lis = vgui.Create( "HListView" )
	lis:AddColumn( column )
	lis:AddColumn( column2 )
	lis:AddLine( ... )
	self:AddItem( lis )
	return lis
end
--]]
function LIST:Slider( label, cfg, min, max, dec )
	local num = vgui.Create( "DNumSlider" )
	num:SetText( label or "" )
	num.Label:SetTextColor( Color( 0, 0, 0, 255 ) ) 
	num.Config = cfg
	num:SetValue( cfg:GetFloat() )
	
	local oldValue = num.ValueChanged
	num.ValueChanged = function( sli, val )
		sli.Config:SetValue( val )
		return oldValue( sli, val )
	end
	
	num:SetMin( min or 0 )
	num:SetMax( max or 100 )
	num:SetDecimals( dec or 0 )
	self:AddItem( num )
	return num
end

function LIST:Bind( label, cmd )
	local bind = vgui.Create( "HBind" )
	bind:SetText( label )
	bind:SetCommand( hades.GetCommand( cmd ) )
	self:AddItem( bind )
	return bind
end

function LIST:Infobox( label )
	local infobox = vgui.Create( "HInfobox" )
	infobox:SetText( label )
	self:AddItem( infobox )
	return infobox
end

function LIST:Label( text )
	local label = vgui.Create( "HLabel" )
	label:SetText( text )
	self:AddItem( label )
	return label
end