local INFOBOX = derma.DefineControl( "HInfobox", "", {} )

AccessorFunc( INFOBOX, "Label", "Label", FORCE_STRING )

INFOBOX.SetText = INFOBOX.SetLabel

function INFOBOX:Init()
end

function INFOBOX:PerformLayout()
	self:SetTall( 20 )
end

local block

local icon = Material( "hades/information" )

function INFOBOX:Paint()
	local color
	local skin = derma.GetDefaultSkin()
	skin:DrawGenericBackground( 0, 0, self:GetWide(), self:GetTall(), skin.bg_color )
	if self.Waiting then
		color = skin.control_color_active
	elseif not self.Hovered then
		color = skin.colTab
	else
		color = skin.colTabInactive
	end
	skin:DrawGenericBackground( 0, 0, self:GetWide(), self:GetTall(), color )
	surface.SetMaterial( icon )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( 10, 2, 16, 16 )
		
	draw.SimpleText( self.Label, "default", 31, self:GetTall()/2 - 1, skin.colTabText, nil, TEXT_ALIGN_CENTER )
end