local MULTI = derma.DefineControl( "HMultiChoice", "", {}, "DMultiChoice" )

AccessorFunc( MULTI, "Config", "Config" )
function MULTI:SetConfig( cfg )
	self.Config = cfg
	self:ChooseOptionID( cfg:GetInt() )
end

function MULTI:OnSelect( i, value, data )
	self.Config:SetValue( i )
end