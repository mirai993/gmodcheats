local BOX = derma.DefineControl( "HTextBox", "", {}, "DTextEntry" )

AccessorFunc( BOX, "Config", "Config" )
function BOX:SetConfig( cfg )
	self.Config = cfg
	self:SetValue( cfg:GetString() )
end

function BOX:OnEnter()
	DTextEntry.OnEnter( self )
	if self.Config then
		self.Config:SetValue( self:GetValue() )
	end
end