local BOX = derma.DefineControl( "HCheckBox", "", {}, "DCheckBoxLabel" )

AccessorFunc( BOX, "Config", "Config" )
function BOX:SetConfig( cfg )
	self.Config = cfg
	self:SetValue( cfg:GetBool() )
end

function BOX:OnChange( val )
	DCheckBoxLabel.OnChange( self, val )
	if self.Config then
		self.Config:SetValue( val )
	end
end