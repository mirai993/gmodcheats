local HACK = hades.Register( "DumpLua" )

function HACK:DumpLua( t, path )
	path = path .. "/"
	for k,v in pairs( t ) do
		if type( v ) ~= "table" then
			if file.Exists( v ) then return end
			hades.Safe.file.Write( path .. k:gsub("%.lua", "%.txt"), v )
		else
			self:DumpLua( v, path .. k .. "/" )
		end
	end
end

HACK:AddCommand( "dumplua", function( self )
	self:DumpLua( hades.Scripts, "hades/dump" )
end )