local HACK = hades.Register( "Script Editor" )

HACK:AddConfig( "scriptname", "" )
HACK:AddConfig( "script", "" )

HACK:AddCommand( "runscript", function( self )
	hades.RunString( self.script )
end )

HACK:AddCommand( "savescript", function( self )
	file.Write( "hades/se/" .. self.scriptname .. ".txt", self.script )
end )

function HACK:SetScript( )
	self.script = file.Read( "hades/se/" .. self.scriptname .. ".txt" )
end

function HACK:BuildMenu( panel )
	for k, v in pairs( file.Find( "hades/se/*.txt" ) ) do
		panel:InfoBox( v )
	end
	local cat = panel:Category( "Environment" )
		cat:TextBox( self.scriptname )
		cat:TextBox( self.script )
		cat:Button( "Save", "savescript" )
	panel:Button( "Compile", "runscript" )
end

HACK:AddTab( "Script Editor", "hades/code", "Script Editor" )