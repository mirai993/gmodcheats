local HACK = hades.Register( "Cryptosystem" )

-- Hashes
local HASH_SHA1 = 1
local HASH_CSA = 2

-- Alphabet
local ALPHA_KRYPTOS = 1

-- Block Ciphering
local BLOCK_BINARY = 1
local BLOCK_AES = 1

HACK:AddConfig( "Alpha", ALPHA_KRYPTOS )
HACK:AddConfig( "Binary", BLOCK_BINARY )
HACK:AddConfig( "Hash", HASH_SHA1 )
HACK:AddConfig( "MIN", "0" )
HACK:AddConfig( "MAX", "10" )
HACK:AddConfig( "KEY", "" )
HACK:AddConfig( "STRING", "" )
HACK:AddConfig( "CIPHERTEXT", "" )

local alpha			= {	"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" }
local ROCon			= { 0x01000000,
						0x02000000,
						0x04000000,
						0x08000000,
						0x10000000,
						0x20000000,
						0x40000000,
						0x80000000,
						0x1b000000,
						0x36000000,
						0x6c000000,
						0xd8000000,
						0xab000000,
						0x4d000000,
						0x9a000000,
						0x2f000000 }
local pseudotab		= {}
local mod			= math.fmod
local floor			= math.floor
local H0, H1, H2, H3, H4 -- SHA1
local D0, D1, D2, D3, D4, D5, D6, D7 -- CSA3
-- Thanks Martin Huesser for the compact Bitlib and misc hex/crypto functions
function HACK:Cap( x )
	return mod( x, 4294967296 )
end

function HACK:bnot( x )
	return 4294967295 - self:Cap( x )
end

function HACK:lshift( x, n )
	return self:Cap( self:Cap( x ) * 2^n )
end

function HACK:rshift( x, n )
	return floor( self:Cap( x ) / 2^n )
end

function HACK:band( x, y )
	local z, i, j = 0, 1
	for j = 0,31 do
		if ( mod( x, 2 ) == 1 and mod( y, 2 ) == 1 ) then
			z = z + i
		end
		x = self:rshift( x, 1 )
		y = self:rshift( y, 1 )
		i = i * 2
	end
	return z
end

function HACK:bor( x, y )
	local z, i, j = 0, 1
	for j = 0, 31 do
		if ( mod( x, 2 ) == 1 or mod( y, 2 ) == 1 ) then
			z = z + i
		end
		x = self:rshift( x, 1 )
		y = self:rshift( y, 1 )
		i = i * 2
	end
	return z
end

function HACK:bxor( x, y )
	local z, i, j = 0, 1
	for j = 0, 31 do
		if ( mod( x, 2 ) ~= mod( y, 2 ) ) then
			z = z + i
		end
		x = self:rshift( x, 1 )
		y = self:rshift( y, 1 )
		i = i * 2
	end
	return z
end

function HACK:LRotate( val, n )
	return self:lshift( val, n ) + self:rshift( val, 32 - n )
end

function HACK:Hex( val )
	local i, k
	local str = ""
	for i = 1, 8 do
		k = self:band( val, 15 )
		if ( k < 10 ) then
			str = string.char( k + 48 ) .. str
		else
			str = string.char( k + 87 ) .. str
		end
		val = floor( val / 16 )
	end
	return str
end

function HACK:ByteParity( byte )
	byte = self:bxor( byte, self:rshift( byte, 4 ) )
	byte = self:bxor( byte, self:rshift( byte, 2 ) )
	byte = self:bxor( byte, self:rshift( byte, 1 ) )
	
	return self:band( byte, 1 )
end

function HACK:GetByte( num, x )
    if ( x == 0 ) then
        return self:band( num, 0xff )
    else
        return self:band( self:rshift( num, x * 8 ), 0xff )
    end
end

function HACK:PutByte( num, x )
    if ( x == 0 ) then
        return self:band( num, 0xff );
    else
        return self:lshift( self:band( num, 0xff ), x * 8 )
    end
end

function HACK:BytesToInts( bytes, start, n )
    local ints = {}
    for i = 0, n - 1 do
        ints[ i ] = self:PutByte( bytes[ start + ( i * 4 )    ], 3 )
                + self:PutByte( bytes[ start + ( i * 4 ) + 1 ], 2 ) 
                + self:PutByte( bytes[ start + ( i * 4 ) + 2 ], 1 )    
                + self:PutByte( bytes[ start + ( i * 4 ) + 3 ], 0 )
    end
    return ints
end

function HACK:IntsToBytes( ints, output, outputOffset, n )
    n = n or #ints
    for i = 0, n do
        for j = 0,3 do
            output[ outputOffset + i * 4 + ( 3 - j ) ] = self:GetByte( ints[ i ], j )
        end
    end
    return output
end

function HACK:BytesToHex( bytes )
    local HexBytes = ""
    
    for i, byte in ipairs( bytes ) do 
        HexBytes = HexBytes .. string.format( "%02x ", byte )
    end

    return HexBytes
end

function HACK:HexString( data )
    local type = type( data );
    if ( type == "number" ) then
        return string.format( "%08x", data )
    elseif ( type == "table" ) then
        return self:BytesToHex( data )
    elseif ( type == "string" ) then
        local bytes = { string.byte( data, 1, #data ) }

        return self:BytesToHex( bytes )
    else
        return data
    end
end

function HACK:PadByteString(data)
    local dataLength = #data;
    
    local random1 = math.random(0,255);
    local random2 = math.random(0,255);

    local prefix = string.char( random1,
                               random2,
                               random1,
                               random2,
                               self:getByte( dataLength, 3 ),
                               self:getByte( dataLength, 2 ),
                               self:getByte( dataLength, 1 ),
                               self:getByte( dataLength, 0 ) )

    data = prefix .. data

    local paddingLength = math.ceil( #data / 16 ) * 16 - #data
    local padding = ""
    for i = 1, paddingLength do
        padding = padding .. string.char( math.random( 0, 255 ) )
    end 

    return data .. padding
end

function HACK:ProperlyDecrypted( data )
    local random = { string.byte( data, 1, 4 ) }

    if ( random[ 1 ] == random[ 3 ] and random[ 2 ] == random[ 4 ] ) then
        return true
    end
    
    return false
end

function HACK:UnpadByteString( data )
    if ( not self:properlyDecrypted( data ) ) then
        return nil
    end

    local dataLength = self:PutByte( string.byte( data, 5 ), 3 )
                     + self:PutByte( string.byte( data, 6 ), 2 ) 
                     + self:PutByte( string.byte( data, 7 ), 1 )    
                     + self:PutByte( string.byte( data, 8 ), 0 )
    
    return string.sub( data, 9, 8 + dataLength )
end

function HACK:XORIV( data, iv )
    for i = 1, 16 do
        data[ i ] = self:bxor( data[ i ], iv[ i ] )
    end
end

function HACK:NewBuffer( )
	return {}
end

function self:BufferAddString( stack, s )
	table.insert( stack, s )
	for i = #stack - 1, 1, -1 do
		if #stack[ i ] > #stack[ i + 1 ] then 
			break
		end
		stack[ i ] = stack[ i ] .. table.remove( stack )
	end
end

function HACK:BufferToString( stack )
	for i = #stack - 1, 1, -1 do
		stack[ i ] = stack[ i ] .. table.remove( stack )
	end
	return stack[ 1 ]
end

function HACK:AESEncryptString( key, data, modeFunction )
	local iv = iv or { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
	local keySched = self:AESExpandEncryptionKey( key )
	local encryptedData = buffer.new()
    
	for i = 1, #data / 16 do
		local offset = ( i - 1 ) * 16 + 1
		local byteData = { string.byte( data, offset, offset + 15 ) }
		
		self:ModeFunction( keySched, byteData, iv )
		
		self:BufferAddString( encryptedData, string.char( unpack( byteData ) ) )
	end
	return buffer.toString( encryptedData )
end

function HACK:PreProcess( str )
	local bitlen, i
	local str2 = ""
	bitlen = string.len( str ) * 8
	str = str .. string.char( 128 )
	i = 56 - self:band( string.len( str ), 63 )
	if ( i < 0 ) then
		i = i + 64
	end
	for i = 1, i do
		str = str .. string.char( 0 )
	end
	for i = 1, 8 do
		str2 = string.char( self:band( bitlen, 255 ) ) .. str2
		bitlen = floor( bitlen / 256 )
	end
	return str .. str2
end

function HACK:Loop( str )
	local a, b, c, d, e, f, k, t
	local i, j
	local w = { }
	while ( str ~= "" ) do
		for i = 0, 15 do
			w[ i ] = 0
			for j = 1, 4 do
				w[ i ] = w[ i ] * 256 + string.byte( str, i * 4 + j )
			end
		end
		for i = 16, 79 do
			w[ i ] = self:LRotate( self:bxor( self:bxor( w[ i - 3 ], w[ i - 8 ] ), self:bxor( w[ i - 14 ], w[ i - 16 ] ) ), 1 )
		end
		a = H0
		b = H1
		c = H2
		d = H3
		e = H4
		for i = 0, 79 do
			if ( i < 20 ) then
				f = self:bor( self:band( b, c ), self:band( self:bnot( b ), d ) )
				k = 1518500249
			elseif ( i < 40 ) then
				f = self:bxor( self:bxor( b, c ), d )
				k = 1859775393
			elseif ( i < 60 ) then
				f = self:bor( self:bor( self:band( b, c ), self:band( b, d ) ), self:band( c, d ) )
				k = 2400959708
			else
				f = self:bxor( self:bxor( b, c ), d )
				k = 3395469782
			end
			t = self:LRotate( a, 5 ) + f + e + k + w[ i ]	
			e = d
			d = c
			c = self:LRotate( b, 30 )
			b = a
			a = t
		end
		H0 = self:band( H0 + a, 4294967295 )
		H1 = self:band( H1 + b, 4294967295 )
		H2 = self:band( H2 + c, 4294967295 )
		H3 = self:band( H3 + d, 4294967295 )
		H4 = self:band( H4 + e, 4294967295 )
		str = string.sub( str, 65 )
	end
end

function HACK:CSALoop( str )
	local a, b, c, d, e, f, k, t
	local i, j
	local w = { }
	while ( str ~= "" ) do
		for i = 0, 15 do
			w[ i ] = 0
			for j = 1, 4 do
				w[ i ] = w[ i ] * 256 + string.byte( str, i * 4 + j )
			end
		end
		for i = 16, 79 do
			w[ i ] = self:LRotate( self:bxor( self:bxor( w[ i - 3 ], w[ i - 8 ] ), self:bxor( w[ i - 14 ], w[ i - 16 ] ) ), 1 )
		end
		a = D0
		b = D1
		c = D2
		d = D3
		e = D4
		f = D5
		g = D6
		h = D7
		for i = 0, 79 do
			if ( i < 20 ) then
				f = self:bor( self:band( b, c ), self:band( self:bnot( b ), d ) )
				k = 1518500249
			elseif ( i < 40 ) then
				f = self:bxor( self:bxor( b, c ), d )
				k = 1859775393
			elseif ( i < 60 ) then
				f = self:bor( self:bor( self:band( b, c ), self:band( b, d ) ), self:band( c, d ) )
				k = 2400959708
		--	elseif ( i < 80 )
		--		f = self:bor( self:band( self:bor( self:bnot( b, c ), d ), self:band( b, c ) ), self:bxor( self:bxor( b, c ), d ) )
		--		k = 4239176413
			else
				f = self:bxor( self:bxor( b, c ), d )
				k = 3395469782
			end
			t = self:LRotate( a, 5 ) + f + e + k + w[ i ]	
			e = d
			d = c
			c = self:LRotate( b, 30 )
			b = a
			a = t
		end
		D0 = self:band( D0 + a, 6793431234 )
		D1 = self:band( D1 + b, 3237459287 )
		D2 = self:band( D2 + c, 1297864391 )
		D3 = self:band( D3 + d, 8581273813 )
		D4 = self:band( D4 + e, 5745324237 )
		D5 = self:band( D5 + e, 1472633412 )
		D6 = self:band( D6 + e, 8975421187 )
		D7 = self:band( D7 + e, 5366213687 )
		str = string.sub( str, 65 )
	end
end

function HACK:IsEven( val )
    return ( ( val[ 1 ] % 2 ) == 0 )
end

function HACK:IsOdd( val )
    return not ( self:IsEven( val ) )
end

function HACK:Copy( a, b ) --Get digits from A to B
    while #a > #b do
        a[ #a ] = nil
    end

    for ix = 1, #b do
        a[ ix ] = b[ ix ]
    end
end

function HACK:Noise( x, y ) --Always returns 1 :(
	n = x + y * 57
	n = self:lshift( n, 13 ) ^ n
	n2 = ( 1.0 - ( self:band( math.Round( ( n * ( n * n * 15731 + 789221 ) + 1376312589 ) ), 2147483647 ) ) / 1073741824.0 )
	return n2
end


function HACK:PseudoRandom( min, max )
	local time = CurTime()
	local noise = min + max * 57
	math.randomseed( tonumber( self:SHA1( os.time() ):lower():gsub( "[a-z]", "" ) + self:lshift( noise, 13 ) ^ noise - 1.0 - self:band( math.Round( ( noise * ( noise * noise * 15731 + 789221 ) + 1376312589 ) ), 2147483647 / 1073741824.0 ) ) )
	for i = 1, 1024 do
		table.insert( pseudotab, math.random( min, max ) )
	end
	local out = table.Random( pseudotab )
	table.Empty( pseudotab )
	print( CurTime() - time ) --Testing time it takes to do it
	return out
end

function HACK:NumToBin( num ) -- Number to Binary
	local ret = ""
	while( num > 0 ) do
		ret = tostring( num % 2 ) .. ret
		num = floor( num / 2 )
	end
	return ret
end
	
function HACK:StrToBin( str ) -- String to Number to Binary
	local ret = ""
	for b in str:gmatch( "%S+" ) do
		for c in b:gmatch( "." ) do
			ret = ret .. "0" .. self:NumToBin( c:byte() )
			ret = ret .. " "
		end
	end
	return ret
end

function HACK:SHA1( str )
	str = self:PreProcess( str )
	H0  = 1732584193
	H1  = 4023233417
	H2  = 2562383102
	H3  = 0271733878
	H4  = 3285377520
	self:Loop( str )
	return	self:Hex( H0 ) ..
		self:Hex( H1 ) ..
		self:Hex( H2 ) ..
		self:Hex( H3 ) ..
		self:Hex( H4 )
end

--SHA1 variation CSA (Arbitrarily long) 
function HACK:CSA( str )
	str = self:PreProcess( str )
	D0  = 2144564482
	D1  = 3120854564
	D2  = 8018112247
	D3  = 4476567208
	D4  = 9491601984
	D5  = 7252612821
	D6  = 2144601511
	D7  = 0179412811
	self:CSALoop( str )
	return	self:Hex( D0 ) ..
		self:Hex( D1 ) ..
		self:Hex( D2 ) ..
		self:Hex( D3 ) ..
		self:Hex( D4 ) ..
		self:Hex( D5 ) ..
		self:Hex( D6 ) ..
		self:Hex( D7 )
end

--http://realmoftwelve.kryptos.info/speculation/k1solution.html
function HACK:Kryptos1( key )
	local a
	for k, v in pairs( alpha )
		a = a or "" .. v
	end
	return key .. a:lower():gsub( "[a-z]", "" )
end

function HACK:CShift( str, amt ) -- Caeser Shift
	local byte_a, byte_A = strbyte( 'a' ), strbyte( 'A' )
	str = gsub( str, "(%a)", function ( c )
        c = strbyte( c )
        local offset = ( c >= 97 ) and %byte_a or %byte_A
        c = mod( c + amt - offset, 26 )
        return strchar( c + offset )
    end )
	return str
end

function HACK:RandomString() -- Rabidtoaster's
	local j, r = 0, ""
		
	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function HACK:BinaryEnc( plaintext, key )
	while ( #key < #plaintext ) do
		key = key .. key
	end
	if ( #key > #plaintext ) then
		key = key:Left( #plaintext )
	end
	return self:BXOR( plaintext, key )
end
--MPI :V
--[[
function HACK:IsPrime( a, nt )

    local x = {0, sign='+'};
    local m = {0, sign='+'};
    local z = {0, sign='+'};
    local amo = {0, sign='+'};

    -- Initialize temporaries...
    self:Copy( amo, a );
    s_mpi_size(x, #a);

    -- Compute m = a - 1 for what follows...
    mpi_sub_d(amo, 1, amo);
    mpi_copy(m, amo);

    -- How many times does 2 divide (a - 1)?
    local b = 0;
    while ((m[1] % 2) == 0) do
        mpi_div_2(m, m);
        b = b + 1;
    end

    local res = true;

    -- Do the test nt times...
    for iter=1,nt do
        -- Choose a random value for x < a
        mpi_random_size(x, #a);
        mpi_mod(x, a, x);

        -- Compute z = (x ** m) mod a
        mpi_exptmod(x, m, a, z);

        if (mpi_cmp_d(z, 1) == MPI_EQ or mpi_cmp(z, amo) == MPI_EQ) then
             return true;
        end

        local jx = 0;

        -- If the test passes, we will continue iterating, but a failed
        -- test means the candidate is definitely NOT prime, so we will
        -- immediately return.
        while (1) do
            if (jx > 0 and mpi_cmp_d(z, 1) == MPI_EQ) then
                return false;
            end

            jx = jx + 1;

            if (jx < b and mpi_cmp(z, amo) ~= MPI_EQ) then
	            -- z = z^2 (mod a)
	            mpi_sqrmod(z, a, z);
	        elseif (mpi_cmp(z, amo) == MPI_EQ) then
	            break;
            elseif (jx == b and mpi_cmp(z, amo) ~= MPI_EQ) then
                return false;
	        end
	    end
    end

    return true;
end--]]

function HACK:ROT13( str )
	local byte_a, byte_A = strbyte( 'a' ), strbyte( 'A' )
	str = gsub( str, "(%a)", function ( c )
        c = strbyte( c )
        local offset = ( c >= 97 ) and %byte_a or %byte_A
        c = mod( c + 13 - offset, 26 )
        return strchar( c + offset )
      end )
  return str
end

--[[
function HACK:BinaryDec( ciphertext, key )
	return self:BXNOR( plaintext, key ) -- Not done yet
end
--]]
HACK:AddCommand( "crypto_hash_compute", function( self )
	if self.Hash:GetInt() == 1 then
		hades.Log( 1, self:SHA1( self.STRING:GetString() ) )
		self.CIPHERTEXT = self:SHA1( self.STRING:GetString() )
	else
		hades.Log( 1, self:CSA( self.STRING:GetString() ) )
		self.CIPHERTEXT = self:CSA( self.STRING:GetString() )
	end
end )

HACK:AddCommand( "crypto_alpha_compute", function( self )
	--if self.Alpha:GetInt() == 1 then
		hades.Log( 1, self:Kryptos( self.KEY:GetString() ) )
		self.CIPHERTEXT = self:Kryptos( self.KEY:GetString() )
	--else
	--	hades.Log( 1, self:CSA( self.STRING:GetString() ) )
	--	self.CIPHERTEXT = self:CSA( self.STRING:GetString() )
	--end
end )

HACK:AddCommand( "crypto_block_binary_compute", function( self )
	--if self.Alpha:GetInt() == 1 then
		hades.Log( 1, self:BinaryEnc( self.STRING:GetString(), self.KEY:GetString() ) )
		self.CIPHERTEXT = self:BinaryEnc( self.STRING:GetString(), self.KEY:GetString() ) )
	--else
	--	hades.Log( 1, self:CSA( self.STRING:GetString() ) )
	--	self.CIPHERTEXT = self:CSA( self.STRING:GetString() )
	--end
end )

HACK:AddCommand( "crypto_random_string", function( self )
	hades.Log( 1, self:RandomString() )
end )

HACK:AddCommand( "crypto_random", function( self )
	hades.Log( 1, math.random( self.MIN:GetInt(), self.MAX:GetInt() ) )
end )

HACK:AddCommand( "crypto_random_pseudo", function( self )
	hades.Log( 1, self:PseudoRandom( self.MIN:GetInt(), self.MAX:GetInt() ) )
end )

function HACK:BuildMenu( panel )
	local cat = panel:Category( "Alphabet" )
		local c1 = cat:MultiChoice()
			c1:AddChoice( "Kryptos" )
			c1:SetConfig( self.Alpha )
			
		cat:TextBox( self.KEY )
		cat:TextBox( self.STRING )
		cat:Button( "Generate", "crypto_alpha_compute" )
	cat = panel:Category( "Block Ciphering" )
		c1 = cat:MultiChoice()
			c1:AddChoice( "Binary" )
			c1:AddChoice( "AES" )
			c1:SetConfig( self.Binary )
			
		cat:TextBox( self.KEY )
		cat:TextBox( self.STRING )
		cat:Button( "Generate", "crypto_block_binary_compute" )
	cat = panel:Category( "Hashes" )
		local c = cat:MultiChoice()
			c:AddChoice( "SHA1" )
			c:AddChoice( "CSA" )
			c:SetConfig( self.Hash )
			
		cat:TextBox( self.KEY )
		cat:Button( "Generate", "crypto_hash_compute" )
	cat = panel:Category( "Random" )
		cat:TextBox( self.MIN )
		cat:TextBox( self.MAX )
		cat:Button( "Random", "crypto_random" )
		cat:Button( "String Random", "crypto_random_string" )
		cat:Button( "Pseudorandom", "crypto_random_pseudo" )
	panel:Infobox( self.CIPHERTEXT:GetString() )
end

HACK:AddTab( "Cryptosystem", "hades/square", "Crypto Library" )