--require "sourcenet"

local HACK = hades.Register( "Firewall" )
local oldrcc = RunConsoleCommand

HACK:AddConfig( "Enabled", true )
HACK:AddConfig( "Block_Usermessages", false )
HACK:AddConfig( "Log_Usermessages", false )
HACK:AddConfig( "Usermessages", false )
HACK:AddConfig( "Log_Sendlua", false )
HACK:AddConfig( "Block_Sendlua", false )
HACK:AddConfig( "Sendlua", false )
HACK:AddConfig( "Log_Commands", false )
HACK:AddConfig( "Block_Commands", false )
HACK:AddConfig( "Commands", false )

local recentlogs = {}
local umsg_greylist = {
	"hax",
	"hack",
	"kickme",
	"_f_",
	"azucheck",
	"bbot",
	"deco",
	"gbps",
	"say",
	"quti",
	"quit",
	"exit",
	"toggleconsole",
	"gameui",
	"exec",
	"disconnect",
	"hades",
	"sv_cheats",
	"sv_scriptenforcer",
	"host_timescale",
	"host_framerate",
}
local slua_greylist = {
	"hax",
	"hack",
	"kickme",
	"_f_",
	"azucheck",
	"bbot",
	"deco",
	"gbps",
	"say",
	"quti",
	"quit",
	"exit",
	"toggleconsole",
	"gameui",
	"exec",
	"disconnect",
	"hades",
	"sv_cheats",
	"sv_scriptenforcer",
	"host_timescale",
	"host_framerate",
	"render.addbeam"
}
local cmd_greylist = {
	"se fail",
	"azucheck",
	"bbot",
	"deco",
	"hax",
	"_f_",
	"jpeg",
--	"say",
	"quti",
	"quit",
	"exit",
	"gameui",
	"toggleconsole"
}

function HACK:AddLog( sev, typ, msg )
	hades.Log( sev, typ .. " | " .. msg )
	table.insert( recentlogs, typ .. " | " .. msg )
end
--Crash causer?
function HACK:_ProcessStringCmd( msg )
	for k, v in ipairs( cmd_greylist ) do
		local lower = string.lower( v )
		local len = string.len( lower )
		
		if ( string.sub( string.lower( msg:GetCommand() ), 0, len ) == lower ) then
			local netchannel = msg:ToBase():GetNetChannel()
			if self.Log_Commands:GetBool() then
				self:AddLog( 1, "Command", lower )
			end
			if self.Commands:GetBool() then
				return false
			end
		end
	end
end
--Crash causer?
--[[
function RunConsoleCommand( ... )
	local cmd = table.concat( { ... } , " " )
	if HACK.Log_Commands:GetBool() then
		HACK:AddLog( 1, "Command", cmd )
	end
	for k, v in ipairs( cmd_greylist ) do
		if cmd:lower():find( v ) then
			if HACK.Commands:GetBool() then
				return false
			end
		end
	end
	return oldrcc( cmd )
end
--]]
function HACK:_ProcessUserMessage( id, msg )
	if not self.Enabled:GetBool() then return end
	if self.Log_Usermessages:GetBool() then
		--self:AddLog( 1, "Usermessage", id )
	end
	if self.Log_Sendlua:GetBool() then
		if id == 29 then
			self:AddLog( 1, "Sendlua", msg:ReadString() )
		end
	end
	--[[if self.Usermessages:GetBool() then
		for k, v in pairs( umsg_greylist ) do
			if msg:ReadString():lower():find( v ) then
				HACK:AddLog( 3, "Blocked Usermessage", msg:ReadString() )
				return false
			end
		end
	end
	if self.Sendlua:GetBool() then
		for k, v in pairs( slua_greylist ) do
			if msg:ReadString():lower():find( v ) then
				HACK:AddLog( 3, "Blocked Sendlua", msg:ReadString() )
				--return false
			end
		end
	end--]]
	if self.Block_Usermessages:GetBool() then
		HACK:AddLog( 2, "Blocked Usermessage", msg:ReadString() )
		return false
	end
	if self.Block_Sendlua:GetBool() then
		if id == 29 then
			HACK:AddLog( 2, "Blocked Sendlua", msg:ReadString() )
			return false
		end
	end
end
--[[
function RunConsoleCommand( ... )
	if HACK.Commands:GetBool() then
		local cmd = unpack( { ... } )
		for k, v in pairs( cmd_greylist ) do
			if cmd:lower():find( v ) then
				HACK:AddLog( 2, "Blocked Command", ... )
				return false
			end
		end
	end
	if HACK.Log_Commands:GetBool() then
		HACK:AddLog( 1, "Command", ... )
	end
	if HACK.Block_Commands:GetBool() then
		return false
	end
	return oldrcc( ... )
end
--]]
function HACK:BuildMenu( panel )
	panel:CheckBox( "Enabled", self.Enabled )
	local cat = panel:Category( "Usermessages" )
		cat:CheckBox( "Log Usermessages", self.Log_Usermessages )
		cat:CheckBox( "Block Usermessages", self.Block_Usermessages )
--		cat:CheckBox( "Scan Usermessages", self.Usermessages )
		cat:CheckBox( "Log Sendlua", self.Log_Sendlua )
		cat:CheckBox( "Block Sendlua", self.Block_Sendlua )
		cat:CheckBox( "Scan Sendlua", self.Sendlua )
	cat = panel:Category( "Commands" )
		cat:CheckBox( "Log Commands", self.Log_Commands )
		cat:CheckBox( "Block Commands", self.Block_Commands )
		cat:CheckBox( "Scan Commands", self.Commands )
	cat = panel:Category( "Logs" )
		for k, v in pairs( recentlogs ) do
			cat:Infobox( v )
		end
end

HACK:AddTab( "Firewall", "gui/silkicons/exclamation", "Block commands and stuff" )