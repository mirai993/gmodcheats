local HACK = hades.Register( "Speedhack" )

HACK:AddCommand( "+speed", function( self )
	local speed = self.Speed:GetFloat()
	if speed > 1 then
		hades.CVar.GetSpoofed("sv_cheats"):SetValue("1")
		hades.CVar.GetSpoofed("host_timescale"):SetValue( tostring( speed ) )
	end
end, KEY_LALT )

HACK:AddCommand( "-speed", function( self )
	hades.CVar.GetSpoofed("host_timescale"):SetValue("1.0")
	hades.CVar.GetSpoofed("sv_cheats"):SetValue("0")
end )

HACK:AddConfig( "Speed", 2.0 )

function HACK:BuildMenu( panel )
	panel:Bind( "Run!", "+speed" )
	panel:Slider( "Speed", self.Speed, 1, 20, 1 )
end

HACK:AddTab( "Speedhack", "gui/silkicons/car", "WROOOOOOOOOM" )