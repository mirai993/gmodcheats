local HACK = hades.Register( "Information" )
--[[
HACK:AddConfig( Name_Disguise_Toggle, false )
HACK:AddConfig( Name_Disguise, "" )
--]]
function HACK:IsULX()
	if file.Find( "../lua_temp/ulx/*.lua" ) then
		return true
	end
	return false
end

function HACK:IsASSMod()
	if file.Find( "../lua_temp/ass_client.lua" ) then
		return true
	end
	return false
end

function HACK:IsBlackAdmin()
	if file.Find( "../lua_temp/BlackAdmin/client/*.lua" ) then
		return true
	end
	return false
end

function HACK:IsEvolve()
	if evolve and evolve.installed then
		return true
	end
	return false
end

function HACK:IsAIDS()
	if file.Find( "../lua_temp/autorun/aids.lua" ) then
		return true
	end
	return false
end

function HACK:GetAdminMod()
	if self:IsEvolve() then
		return "Evolvemod"
	elseif self:IsULX() then
		return "ULX"
	elseif self:IsASSMod() then
		return "ASSMod"
	elseif self:IsBlackAdmin() then
		return "Blackadmin"
	elseif self:IsAIDS() then
		return "AIDS"
	else
		return "Unknown"
	end
end

function HACK:GetRank( ply )
	if self:IsULX() then
		if ply:IsSuperAdmin() then
			return "Super-Admin"
		elseif ply:IsAdmin() then
			return "Admin"
		else
			return "Guest"
		end
	elseif self:IsEvolve() then
		if ply:EV_IsOwner() then
			return "Owner"
		elseif ply:EV_IsSuperAdmin() then
			return "Super-Admin"
		elseif ply:EV_IsAdmin() then
			return "Admin"
		elseif ply:EV_IsRespected() then
			return "Respected"
		else
			return "Guest"
		end
	elseif self:IsASSMod() then
		if ply:IsSuperAdmin() then
			return "Super-Admin"
		elseif ply:IsAdmin() then
			return "Admin"
		elseif ply:IsRespected() then
			return "Respected"
		else
			return "Guest"
		end
	else
		if ply:IsSuperAdmin() then
			return "Super-Admin"
		elseif ply:IsAdmin() then
			return "Admin"
		else
			return "Guest"
		end
	end
end
--[[
function HACK:_Think()
	if self.Name_Disguise_Toggle:GetBool() then
		RunConsoleCommand( "setinfo", "name", self.Name_Disguise:GetString() )
	end
end--]]
--[[
function HACK:Disguise( victim )
	for k, v in pairs( player.GetAll() ) do
		if v:Nick():lower():find( victim ) then
			self.Name_Disguise = v:Nick()
		end
	end
end
--]]
function HACK:BuildMenu( panel )
	panel:Infobox( self:GetAdminMod() )
	local cat = panel:Category( "Players" )
		for k, v in pairs( player.GetAll() ) do
			cat:Infobox( v:Nick() .. " | " .. self:GetRank( v ) )
		end
	cat = panel:Category( "Admins" )
		for k, v in pairs( player.GetAll() ) do
			if v:IsAdmin() then
				cat:Infobox( v:Nick() .. " | " .. self:GetRank( v ) )
			end
		end
--	panel:Checkbox( "Disguise as: " .. self.Name_Disguise, self.Name_Disguise_Toggle )
end

HACK:AddTab( "Information", "hades/information", "Lots of useful information" )