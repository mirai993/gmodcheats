local HACK = hades.Register( "WeaponStuff" )

local TARGET_XHAIR = 1
local TARGET_HP = 2
local TARGET_DIST = 3

local GROUP_HEAD = 1
local GROUP_BODY = 2
local GROUP_CENTER

hades.Safe.require "deco"

HACK:AddConfig( "AimEnabled", true )
HACK:AddConfig( "DrawTarget", true )
--HACK:AddConfig( "OnlyVisible", true )
HACK:AddConfig( "AimPlayers", true )
HACK:AddConfig( "AimTeam", false )
HACK:AddConfig( "AimNPC", true )
HACK:AddConfig( "AimSmooth", 0.0 )
HACK:AddConfig( "Compensation", 45 )
HACK:AddConfig( "TriggerBot", false )
HACK:AddConfig( "TargetPrio", TARGET_XHAIR )
HACK:AddConfig( "AimGroup", GROUP_HEAD )

HACK:AddConfig( "SmoothView", false )
HACK:AddConfig( "NoSpread", false )
HACK:AddConfig( "AutoFire", false )

HACK.Botting = false
HACK.Target = nil

local shotmanip = hl2_shotmanip
local getpred = hl2_ucmd_getprediciton
hl2_shotmanip = nil
hl2_ucmd_getprediciton = nil

package.loaded.deco = nil

local ME = LocalPlayer

--[[
--		START OF WEAPON
]]

local _hl2 = {
	weapon_crowbar = true,
	weapon_pistol = true,
	weapon_smg1 = true,
	weapon_frag = true,
	weapon_physcannon = true,
	weapon_crossbow = true,
	weapon_shotgun = true,
	weapon_357 = true,
	weapon_rpg = true,
	weapon_ar2 = true
}

local _exclude = {
	gmod_tool = true,
	gmod_camera = true,
	weapon_physgun = true
}

local _weaponCones = {
	weapon_zs_base = function( wep )
		local cone = wep.Cone
		if wep:GetNWBool( "Ironsights", false ) then
			if ME():Crouching() then
				cone = wep.ConeIronCrouching
			else
				cone = wep.ConeIron
			end
		elseif ME():GetVelocity():Length() > 25 then
			cone = wep.ConeMoving
		elseif ME():Crouching() then
			cone = wep.ConeCrouching
		end
		return cone
	end,
	weapon_cs_base = function( wep )
		return wep.Primary.Cone
	end,
	darkland_base = function( wep )
		return wep.Primary.Cone
	end,
	weapon_sniper_rifle = function( wep )
		return (1.0 - wep.zoom) * 0.25
	end
}

local function IsAutomatic( wep )
	if wep and wep.Primary and wep.Primary.Automatic ~= nil then
		return wep.Primary.Automatic
	end
	return true
end

local function GetSpread( seed, wep, forw )
	local vecCone = Vector( 0, 0, 0 )
	if type( wep.Base ) == "string" and _weaponCones[wep.Base] then
		local cone = _weaponCones[wep.Base]( wep )
		if type( cone ) == "number" then
			vecCone = Vector( -cone, -cone, -cone )
		elseif type( cone ) == "Vector" then
			vecCone = -1 * cone
		end
	elseif _weaponCones[wep:GetClass()] then
		local cone = _weaponCones[wep:GetClass()]( wep )
		if type( cone ) == "number" then
			vecCone = Vector( -cone, -cone, -cone )
		elseif type( cone ) == "Vector" then
			vecCone = -1 * cone
		end
	end
	return shotmanip( seed or 0, (forw or LocalPlayer():GetAimVector():Angle()):Forward(), vecCone ):Angle()
end
--[[
--		END OF WEAPON
]]
local function GetPrediction( ent )
	local comp = HACK.Compensation:GetInt()
	if comp == 0 then
		return Vector()
	end
	return ent:GetVelocity()/comp - LocalPlayer():GetVelocity()/comp
end

local function GetAimPos( ent )
	local group = HACK.AimGroup:GetInt()
	local id
	local pos = ent:LocalToWorld( ent:OBBCenter() )
	
	if group == GROUP_HEAD then
		id = ent:LookupAttachment( "eyes" )
		if id and id != 0 and ent:GetAttachment( id ) then
			pos = ent:GetAttachment( id ).Pos
		else
			group = GROUP_BODY
		end
	end
	if group == GROUP_BODY then
		id = ent:LookupBone( "ValveBiped.Bip01_Spine" )
		if id and id != 0 and ent:GetBonePosition( id ) then
			pos = ent:GetBonePosition( id )
		end
	end
	if ent:GetModel():lower():find( "headcrab" ) then
		pos = ent:GetPos() + Vector( 0, 0, 6 )
	end
	return pos + GetPrediction( ent )
end

local pow = math.pow
local sqrt = math.sqrt
local abs = math.abs
local function GetXHairDistance( ent )
	local pos = GetAimPos( ent ):ToScreen()
	--return abs( sqrt( pow( (ScrW()/2 - pos.x), 2 ), pow( (ScrH()/2 - pos.y), 2 ) ) )
	--return sqrt( abs( pow( (ScrW()/2 - pos.x), 2 ) ), abs( pow( (ScrH()/2 - pos.y), 2 ) ) )
	return math.Dist( ScrW()/2, ScrH()/2, pos.x, pos.y )
end

local function IsAlive( ent )
	return (
		(ent:IsPlayer() and (ent:Alive() or ent:Health() > 0 or ent:GetMoveType() != 0)) or 
		(ent:IsNPC() and ent:GetMoveType() != 0)
	)
end
--[[
local function IsVisible( ent )
	local pos = GetAimPos( ent )
	local tr = util.TraceLine {
		start = EyePos(),
		endpos = pos,
		filter = { LocalPlayer(), ent },
		mask = MASK_SHOT --Solid to bullets
	}
	return not tr.Hit
end
]]
local function Filter( trg )
	return (
		trg and ValidEntity( trg ) and trg != LocalPlayer() and (
			( HACK.AimPlayers:GetBool() and trg:IsPlayer() and (trg:Team() != LocalPlayer():Team() or HACK.AimTeam:GetBool()) )
			or (HACK.AimNPC:GetBool() and trg:IsNPC())
		) and IsAlive( trg ) -- and (IsVisible( trg ) or not HACK.OnlyVisible:GetBool())
	)
end

local function SortTargets( a, b )
	local pri = HACK.TargetPrio:GetInt()
	if pri == TARGET_XHAIR then
		local da = GetXHairDistance( a )
		local db = GetXHairDistance( b )
		return da < db
	elseif pri == TARGET_HP then
		return a:Health() < b:Health()
	elseif pri == TARGET_DIST then
		local pos = LocalPlayer():GetPos()
		return pos:Distance( a:GetPos() ) < pos:Distance( b:GetPos() )
	else
		return true
	end
end

local function TriggerTrace()
	local tr = util.TraceLine {
		start = LocalPlayer():GetShootPos(),
		endpos = LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 65535,
		filter = { LocalPlayer() },
		mask = MASK_SHOT --Solid to bullets
	}
	return tr.Entity
end

local GetAllEnts = ents.GetAll
function HACK:NextTarget()
	local _targ = {}
	for k,v in pairs( GetAllEnts() ) do
		if Filter( v ) and self.Target ~= v then
			_targ[#_targ + 1] = v
		end
	end
	if #_targ == 0 then return end
	table.sort( _targ, SortTargets )
	return _targ[1]
end

function HACK:StartBot()
	if not self.AimEnabled:GetBool() then self.Botting = false return end
	self.Botting = true
	self.Target = nil
end

function HACK:StopBot()
	if not self.AimEnabled:GetBool() then self.Botting = false return end
	self.Target = nil
	self.Botting = false
end

function HACK:GetTargetAngle()
	local target = self.Target
	if not target then return Angle() end
	local diff = GetAimPos( target ) - LocalPlayer():GetShootPos()
	return diff:Angle()
end

local autoFire = false

local angFire = Angle()
local angDiff = Angle()

local currentseed, cmd2, seed = currentseed or 0, 0, 0
function HACK:_CreateMove( gm, cmd )
	gm:CreateMove( cmd )
	local wep = ME():GetActiveWeapon()
	angFire = cmd:GetViewAngles() - angDiff
	
	if wep and wep:IsValid() and not _exclude[wep:GetClass()] then
		if self.AimEnabled:GetBool() and self.Botting then
			self.Target = Filter( self.Target ) and self.Target or self:NextTarget()
			if self.Target then
				local smooth = self.AimSmooth:GetFloat()
				if smooth > 0 then
					angFire = LerpAngle( FrameTime()/smooth, angFire, self:GetTargetAngle() )
				else
					angFire = self:GetTargetAngle()
				end
				angFire.r = 0
				if not self.NoSpread:GetBool() then
					cmd:SetViewAngles( angFire )
				end
			end
		end
		local trigger = self.TriggerBot:GetBool() and Filter( TriggerTrace() )
		local canAuto = self.AutoFire:GetBool() and not IsAutomatic( wep )
		if canAuto and ( cmd:GetButtons() & IN_ATTACK > 0 or trigger )  then
			if autoFire then
				cmd:SetButtons( cmd:GetButtons() | IN_ATTACK )
			elseif cmd:GetButtons() & IN_ATTACK > 0 then
				cmd:SetButtons( cmd:GetButtons() - IN_ATTACK )
			end
			autoFire = not autoFire
		end
		if trigger and not canAuto then
			cmd:SetButtons( cmd:GetButtons() | IN_ATTACK )
		end
		if self.NoSpread:GetBool() then
			cmd2, seed = getpred( cmd )
			if cmd2 ~= 0 then
				currentseed = seed
			end
			local angSpread = angFire
			if cmd:GetButtons() & IN_ATTACK > 0 then
				angSpread = GetSpread( currentseed, wep, angFire )
				angSpread.r = 0
			end			
			angDiff = Angle( math.AngleDifference( angSpread.p, angFire.p ), math.AngleDifference( angSpread.y, angFire.y ), 0 )
			cmd:SetViewAngles( angSpread )
		end
	end
end

function HACK:_CalcView( gm, ply, origin, angles, fov )
	if self.SmoothView:GetBool() then
		local wep = ply:GetActiveWeapon()
		if wep and wep.Primary and wep.Primary.Recoil then
			wep.Primary.Recoil = 0
		end
		
		local rec = ply:GetPunchAngle()
		angles = (angles - angDiff) - rec
		angles.r = 0
	end
	return gm:CalcView( ply, origin, angles, fov )
	--return { angles = angles }
end

local function GetBoxCorners( ent )
	local center = ent:LocalToWorld( ent:OBBCenter() )
	local min,max = ent:OBBMins(), ent:OBBMaxs()
	local dim = max-min
	
	local front = ent:GetForward()*(dim.y/2)
	local right = ent:GetRight()*(dim.x/2)
	local top = ent:GetUp()*(dim.z/2)
	local back = (ent:GetForward()*-1)*(dim.y/2)
	local left = (ent:GetRight()*-1)*(dim.x/2)
	local bottom = (ent:GetUp()*-1)*(dim.z/2)
	local FRT = center+front+right+top
	local BLB = center+back+left+bottom
	local FLT = center+front+left+top
	local BRT = center+back+right+top
	local BLT = center+back+left+top
	local FRB = center+front+right+bottom
	local FLB = center+front+left+bottom
	local BRB = center+back+right+bottom
	
	FRT = FRT:ToScreen()
	BLB = BLB:ToScreen()
	FLT = FLT:ToScreen()
	BRT = BRT:ToScreen()
	BLT = BLT:ToScreen()
	FRB = FRB:ToScreen()
	FLB = FLB:ToScreen()
	BRB = BRB:ToScreen()
	
	local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	
	return xmax, xmin, ymax, ymin
end

function HACK:_HUDPaint()
	if self.DrawTarget:GetBool() then
		local target = self.Target or self:NextTarget()
		if target and ValidEntity( target ) then
			local xmax, xmin, ymax, ymin = GetBoxCorners( target )
			
			surface.SetDrawColor( 0, 255, 0, 255 )
		
			surface.DrawLine( xmax, ymax, xmax, ymin )
			surface.DrawLine( xmax, ymin, xmin, ymin )
			surface.DrawLine( xmin, ymin, xmin, ymax )
			surface.DrawLine( xmin, ymax, xmax, ymax )
		end
	end
end

HACK:AddCommand( "+aim", function( self )
	self:StartBot()
end )

HACK:AddCommand( "-aim", function( self )
	self:StopBot()
end )

function HACK:BuildMenu( panel, text )
		local cat = panel:Category( "Weapons" )
		cat:CheckBox( "Smooth View", self.SmoothView )
		cat:CheckBox( "No-Spread", self.NoSpread )
		cat:CheckBox( "AutoFire", self.AutoFire )
		cat:CheckBox( "Triggerbot", self.TriggerBot )
		
		cat = panel:Category( "Aimbot" )
		cat:Bind( "Aim", "+aim" )
		cat:CheckBox( "Enabled", self.AimEnabled )
		cat:CheckBox( "Draw box around target", self.DrawTarget )
		cat:CheckBox( "Aim players", self.AimPlayers )
		cat:CheckBox( "Aim teammates", self.AimTeam )
		cat:CheckBox( "Aim NPCs", self.AimNPC )
		--panel:CheckBox( "Only visible", self.OnlyVisible )
		
		local c = cat:MultiChoice()
			c:AddChoice( "Crosshair" )
			c:AddChoice( "Health" )
			c:AddChoice( "Distance" )
			c:SetConfig( self.TargetPrio )
		
		c = cat:MultiChoice()
			c:AddChoice( "Head" )
			c:AddChoice( "Body" )
			c:AddChoice( "Center" )
			c:SetConfig( self.AimGroup )
		
		cat:Slider( "Smooth aim", self.AimSmooth, 0, 1, 2 )
		cat:Slider( "Lag compensation", self.Compensation, 0, 100, 0 )
end

HACK:AddTab( "Weapons", "gui/silkicons/bomb", "Weapon Stuff" )