require "glon"

local TOGGLE = vgui.Register( "HToggle", {}, "Button" )

AccessorFunc( TOGGLE, "Material", "Material", FORCE_STRING )
AccessorFunc( TOGGLE, "Enabled", "Enabled", FORCE_BOOL )
function TOGGLE:SetMaterial( mat )
	self.Material = Material( mat )
	local w, h = surface.GetTextureSize( surface.GetTextureID( mat ) )
	self.MatW = w
	self.MatH = h
end
function TOGGLE:SetEnabled( bool )
	self.Enabled = bool
	
	local cfg = glon.decode( file.Read( "hades/cfg.txt" ) or "" ) or {}
	cfg.Main = cfg.Main or {}
	cfg.Main.Enabled = self.Enabled
	file.Write( "hades/cfg.txt", glon.encode( cfg ) )
	
	hades.Bypass.SE( bool )
	hades.Bypass.GF( bool )
	
	if not bool then
--		hades.Msg( Color( 255, 80, 80 ), "[Hades]" )
--		hades.Msg( Color( 255, 255, 255 ), " Disabled!\n" )
		self:SetMaterial( self.ImageDisabled )
	else
--		hades.Msg( Color( 80, 255, 80 ), "[Hades]" )
--		hades.Msg( Color( 255, 255, 255 ), " Enabled!\n" )
		self:SetMaterial( self.ImageEnabled )
	end
end

TOGGLE.ImageEnabled = "hades/button"
TOGGLE.ImageDisabled = "hades/button_disabled"

function TOGGLE:Init()
	self.Enabled = true
	self:MakePopup()
	self:SetZPos( -99999 )
	
	if not self.Enabled then
		self:SetMaterial( self.ImageDisabled )
	else
		self:SetMaterial( self.ImageEnabled )
	end
end

function TOGGLE:PerformLayout()	
	self:SetSize( self.MatW, self.MatH )
end

function TOGGLE:Paint()
	surface.SetMaterial( self:GetMaterial() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( 0, 0, self:GetWide(), self:GetTall() )
	return true
end

function TOGGLE:DoClick()
	self:SetEnabled( not self.Enabled )
end

local cfg = glon.decode( file.Read( "hades/cfg.txt" ) or "" ) or {}
cfg.Main = cfg.Main or {}

if cfg.Main.Enabled == nil then
	cfg.Main.Enabled = true
end

local enabled = cfg.Main.Enabled

local toggle = vgui.Create( "HToggle" )
toggle:SetPos( ScrW() * 0.1, ScrH() * 0.05 )
toggle:SetEnabled( enabled )