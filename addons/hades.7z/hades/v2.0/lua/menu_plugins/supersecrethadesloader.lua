print "Loading Hades2..."
require "hades2";