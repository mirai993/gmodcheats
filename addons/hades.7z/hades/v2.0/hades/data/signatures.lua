--^$@

local function AddSignature( name, module, sig )
	local mask = sig:gsub( "[0-9A-F]+%s*", "x" ):gsub( "%?%s*", "?" )
	sig = sig:gsub( "%?", "00" ):gsub( "(%S+)%s*", function( byte )
		return string.char( tonumber( byte, 16 ) )
	end )

	Signatures[name] = {
		Signature = sig;
		Mask = mask;
		Module = module;
		Length = sig:len();
	}
end

--[[
Not needed anymore
AddSignature(
	"CLuaInterface::Init",
	"lua_shared",
	"? ? ? ? ? 56 8B F1 40 57 ? ? ? ? ? 89 46 5C 8D 7E 1C"
)
]]

AddSignature(
	"CUserMessages::DispatchUserMessage",
	"client",
	"8B 44 24 04 83 EC 24 85  C0"
)

AddSignature(
	"CLuaInterface::MD5EatData",
	"lua_shared",
	"53 56 57 8B F9 6A 58 ? ? ? ? ? ? 6A 00 56"
)

AddSignature(
	"CLua::RunScriptsInFolder",
	"client",
	"81 EC 0C 02 00 00 83 3D ? ? ? ? 00 75 17 68 ? ? ? ? FF 15 ? ? ? ? 83 C4 04 81 C4 0C 02 00 00"
)

AddSignature(
	"ExecuteString",
	"engine",
	"55 8B 6C 24 ? 8B ? 00 85 ? 75 ? 5D C3 85 ? ? BE"
)

AddSignature(
	"CLuaGameCallback::CanRunScript",
	"client",
	"A1 ? ? ? ? 83 78 14  01 7F 05 B0 01 C2 10 00"
)