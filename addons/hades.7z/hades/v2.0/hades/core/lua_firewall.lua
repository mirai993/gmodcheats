hades.Lua = { };
hades.Lua.Keywords = {
	"hack";
	"hax";
	"hades";
	"sv_cheats";
	"sv_scriptenforcer";
	"host_timescale";
	"host_framerate";
};
hades.Lua.SKeywords = {
	"string.char";
	"_G[ \"string\" ][ \"char\" ]";
	"_G[\"string\"][\"char\"]";
	"_G[ \"\115\116\114\105\110\103\" ][ \"\" ]";
	"_G[\"\115\116\114\105\110\103\"][\"\"]";
};
hades.Lua.Blockedfiles = {
	[ "BlackAdmin/client/cl_derp.lua" ] = true;
	[ "BlackAdmin/client/cl_cmd.lua" ] = true;
	[ "STBase/gamemode/modules/antihack/client.lua" ] = true;
};
hades.Lua.Checksums = {
	[ "lua/includes/enum/class.lua" ] = "2374191172";
	[ "lua/includes/enum/print_types.lua" ] = "415004753";
	[ "lua/includes/enum/rendergroup.lua" ] = "2968868839";
	[ "lua/includes/enum/rendermode.lua" ] = "1657342986";
	[ "lua/includes/enum/sim_phys.lua" ] = "907736137";
	[ "lua/includes/enum/teams.lua" ] = "286319339";
	[ "lua/includes/enum/text_align.lua" ] = "1692212567";
	[ "lua/includes/enum/transmit.lua" ] = "2164775934";
	[ "lua/includes/enum/use_types.lua" ] = "1431895565";
};

function hades.Lua:ParseData( data )
	if data:match( "include%(\"[%w_%.]-\"%)" ) then
		hades.Log( "Debug", "Lua", "Included hash modifier %s", data );
		hades.RunString( data:match( "include%(\"[%w_%.]-\"%)" ) );
	end;
end;

hades.Hook.Add( "LuaRunString", "HadesLuaLoader", function( path, data )
	path = path:gsub( "[\\/]", "/" )
	if path:sub( 1, 9 ) ~= "lua/menu/" then
		if path:sub( 1, 18 ) == "lua/includes/enum/" then
			if hades.Lua.Checksums[ path ] ~= util.CRC( data ) then
				hades.Log( "Warning", "Lua", "Enumeration checksum mismatch %s with handshake %s", path, util.CRC( data ) );
			end;
		end;
		--[[
		if path == "includes/enum/!.lua" then
			if file.Exists( "../lua_temp/util.lua" ) then
				hades.RoTFQueue = "RoTF";
			elseif _R.Player.FileFormat then
				hades.RoTFQueue = "Flap Anticheat";
			else
				hades.RoTFQueue = "Other";
			end;
			if hades.RoTFQueue:lower( ) ~= "rotf" then
				hades.Log( "Warning", "Lua-Blocked-Enumeration", "Blocked enumeration anti-hack: %s", hades.RoTFQueue );
				return false;
			else
				-- Only temporary until I can get timers working here^
				hades.Log( "Warning", "Lua-Blocked-Enumeration", "RoTF Enumeration anti-hack found, allowing.", hades.RoTFQueue );
			end;
		end;
		--]]
		for k, v in pairs( hades.Lua.Keywords ) do
			if data:lower( ):find( v ) and not path:sub( 1, 6 ) == "hades/" then
				hades.Log( "Warning", "Lua", "Blocked file %s with keyword %s", path, v );
				hades.Lua:ParseData( data );
				return false;
			end;
		end;
		for k, v in pairs( hades.Lua.SKeywords ) do
			if data:lower( ):find( v ) then
				hades.Log( "Warning", "Lua", "Found suspicious keyword %s from %s", v, path );
			end;
		end;
		if hades.Lua.Blockedfiles[ path ] then
			hades.Log( "Warning", "Lua", "Blocking blacklisted file %s", path );
			hades.Lua:ParseData( data );
			return false;
		end;
	end;
end );