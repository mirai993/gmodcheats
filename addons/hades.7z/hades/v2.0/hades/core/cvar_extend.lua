local CVar = _R.CVar

local FCVAR_UNREGISTERED = 1 << 0
local FCVAR_DEVELOPMENTONLY = 1 << 1
local FCVAR_HIDDEN = 1 << 4

if not CVar then return end

function CVar:RemoveFlags( flags )
	local newFlags = self:GetFlags()
	
	for k,v in pairs( flags ) do
		if newFlags & v == v then
			newFlags = newFlags - v
		end
	end
end

function CVar:Spoof()
	local oldName = self:GetName()
	local oldValue = self:GetString()
	local oldFlags = self:GetFlags()
	
	self:RemoveFlags {
		FCVAR_UNREGISTERED,
		FCVAR_DEVELOPMENTONLY,
		FCVAR_HIDDEN,
		FCVAR_CHEAT,
		FCVAR_REPLICATED
	}
	
	self:SetName( "h_" .. oldName )
	
	CreateConVar( oldName, oldValue, oldFlags )
end