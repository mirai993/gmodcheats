hades.Require = require;
hades.Rawget = rawget;
hades.Rawset = rawset;
hades.Whitelist = {
	"STEAM_0:1:15750448"; -- Polly^
	"STEAM_0:0:16458788 "; -- Helix^
	"STEAM_0:1:15858852"; -- Stoned^
};

function hades.HasValue( tab, object )
	for k, v in pairs( tab ) do
		if v == object then
			return true;
		end;
	end;
	return false;
end;