hades.Bit = { };

function hades.Bit:XOR( a, b )
	local calc = 0;

	for i = 32, 0, -1 do
		local val = 2 ^ i;
		local aa = false;
		local bb = false;

		if a == 0 then
			calc = calc + b;
			break;
		end;

		if b == 0 then
			calc = calc + a;
			break;
		end;

		if a >= val then
			aa = true;
			a = a - val;
		end;

		if b >= val then
			bb = true;
			b = b - val;
		end;

		if not ( aa and bb ) and ( aa or bb ) then
			calc = calc + val;
		end;
	end;

	return calc;
end;

function hades.Bit:LShift( num, bits )
	return math.fmod( math.fmod( num, 4294967296 ) * 2 ^ bits, 4294967296 );
end;

function hades.Bit:RShift( num, bits )
	return math.floor( math.fmod( num, 4294967296 ) / 2 ^ bits );
end;