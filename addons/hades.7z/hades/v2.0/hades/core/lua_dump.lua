hades.Hook.Add( "LuaRunString", "loltestwut", function( path, data )
	if #path == 0 or not GetHostName then return end
	
	local fullPath = ("hades/data/lua/" .. GetHostName():gsub( "[^A-Za-z0-9%s#%[%]]", "" ):gsub( "%s+", " " ):gsub( "^%s*", "" ):gsub( "%s*$", "" ) .. "/" .. path):gsub( "[/\\]", "/" )
	
	local file = hades.IO.Open( fullPath, "r" )
	
	if file ~= nil then return end
	
	local dir = fullPath:gsub( "[/\\][^/\\]+$", "" )
	
	if not dir then return end
	
	hades.IO.CreateDir( dir )
	
	local file = hades.IO.Open( fullPath, "w" )
	if not file then return end
	
	file:Write( data:gsub( "[\n\r][\n\r]", "\n" ), true )
end )