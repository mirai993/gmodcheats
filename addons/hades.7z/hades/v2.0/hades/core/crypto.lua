hades.Crypto = { };
hades.Crypto.Bit = { };
hades.RandomIdentifiers = {
	"A";
	"Z";
	"x";
	"b";
	"E";
	"3";
	"5";
	"x";
	"T";
	"r";
	"G";
	"Y";
	"P";
	"q";
	"1";
	"f";
	"0";
	"H";
	"l";
	"i";
	"I";
	"O";
	"4";
	"7";
	"S";
	"b";
};

function hades.Crypto.Bit.Cap( num )
	return math.fmod( num, 4294967296 );
end

function hades.Crypto.Bit.BNot( num )
	return 4294967295 - hades.Bit.Cap( num );
end

function hades.Crypto.Bit.LShift( amt, num )
	return hades.Crypto.Bit.Cap( hades.Crypto.Bit.Cap( num ) * 2 ^ num );
end

function hades.Crypto.Bit.RShift( amt, num )
	return math.floor( hades.Crypto.Bit.Cap( num ) / 2 ^ num )
end

function hades.Crypto.Bit.Band( min, max )
	local a, b, c = 0, 1
	for i = 0, 31 do
		if ( math.fmod( min, 2 ) == 1 and math.fmod( max, 2 ) == 1 ) then
			a = a + b
		end
		min = hades.Crypto.Bit.RShift( min, 1 )
		max = hades.Crypto.Bit.RShift( max, 1 )
		b = b * 2
	end
	return a
end

function hades.Crypto.Bit.Bor( min, max )
	local a, b, c = 0, 1
	for i = 0, 31 do
		if ( math.fmod( min, 2 ) == 1 or math.fmod( max, 2 ) == 1 ) then
			a = a + b
		end
		min = hades.Crypto.Bit.RShift( min, 1 )
		max = hades.Crypto.Bit.RShift( max, 1 )
		b = b * 2
	end
	return a
end

function hades.Crypto.Bit.Bxor( min, max )
	local a, b, c = 0, 1
	for i = 0, 31 do
		if ( math.fmod( min, 2 ) ~= math.fmod( max, 2 ) ) then
			a = a + b
		end
		min = hades.Crypto.Bit.RShift( min, 1 )
		max = hades.Crypto.Bit.RShift( max, 1 )
		b = b * 2
	end
	return a
end

function hades.RandomString( len )
	local str = "";
	for i = 1, len do
		str = str .. hades.RandomIdentifiers[ math.random( 26 ) ]
	end;
	return str;
end;