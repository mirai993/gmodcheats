hades.Config = { };
hades.Config.Data = { };

local cfgfile = hades.IO.Open( "hades/data/config.ini", "r+" );
	hades.Config.Data = hades.INI.Parse( cfgfile:Read( ) );
	
function hades.Config.Save( )
	local cfgfile = hades.IO.Open( "hades/data/config.ini", "r+" );
		cfgfile:Write( hades.INI.Write( hades.Config.Data ) );
end;

function hades.Config.Get( sector, name )
	if not hades.Config.Data[ sector ] then
		-- error "Sector not found!";
		return;
	elseif not hades.Config.Data[ sector ][ name ] then
		-- error "Data not found!";
		return;
	end;
	if hades.Config.Data[ sector ][ name ] == "false" or hades.Config.Data[ sector ][ name ] == "true" then
		return tobool( hades.Config.Data[ sector ][ name ] );
	end;
	return hades.Config.Data[ sector ][ name ];
end;

function hades.Config.Set( sector, name, value )
	hades.Config.Data[ sector ] = hades.Config.Data[ sector ] or { };
	if type( value ) == "boolean" then
		hades.Config.Data[ sector ][ name ] = tostring( value );
	else
		hades.Config.Data[ sector ][ name ] = value;
	end;
	hades.Config.Save( );
end;