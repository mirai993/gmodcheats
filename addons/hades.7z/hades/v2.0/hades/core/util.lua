function hades.Byte( str )
	local tbl = { };
	for i=1, #str do
		tbl[ i ] = string.byte( str:sub( i, i ) );
	end;
	return "\\" .. table.concat( tbl, "\\" );
end;

function hades.DumpTable( tab, name )
	debug.sethook( );
	
	if not name then
		error( "No name specified!" );
		return;
	end;
	
	hades.IO.CreateDir( "hades/data/tables" )
	local tabfile = hades.IO.Open( string.format( "hades/data/tables/%s.dat", name ), "a+" );
	for k, v in pairs( tab ) do
		if v ~= "_G" then
				tabfile:Write( tostring( k ) .. "\t" .. tostring( v ) .. "\n" );
		end;
	end;
	
	hades.Notify( "Info", "Table Dumper", "Successfully dumped %s!", name );
end;

hades.Command.Add( "h_byte", function( cmd, args, argv )
	if #args > 0 and args[ 1 ] ~= "" then
		print( hades.Byte( argv ) );
	end;
end );