hades.ConVar = { };
hades.ConVar.SpoofList = {
	"sv_cheats";
	"host_timescale";
	"host_framerate";
};