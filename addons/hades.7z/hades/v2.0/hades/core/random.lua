function hades.RandomBits( len )
	len = len or 255;
	local bits = "";
	
	for i = 1, len do
		bits = bits .. string.char( math.random( 255 ) );
	end;
	return bits;
end;

function hades.RandomString( len )
	len = len or 255;
	local bits = "";
	
	for i = 1, len do
		bits = bits .. string.char( math.random( 65, 122 ) ):gsub( "\\", "" ):gsub( "^", "" ):gsub( "`", "" );
	end;
	return bits;
end;