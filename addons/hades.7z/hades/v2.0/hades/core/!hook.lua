local hook = hook

if not hook then
	-- Re-create hook table
	hook = {}
	
	local Hooks = {}

	function hook.GetTable() return Hooks end

	function hook.Add( event_name, name, func )  
	  
		if (Hooks[ event_name ] == nil) then  
			Hooks[ event_name ] = {}  
		end
		
		Hooks[ event_name ][ name ] = func  
	end

	function hook.Remove( event_name, name )
		Hooks[ event_name ][ name ] = nil  
	end

	function hook.Call( name, gm, ... )  
		
		local b, rA, rB, rC, rD, rE, rF, rG, rH  
		local HookTable = Hooks[ name ]  
		  
	  
		if ( HookTable != nil ) then  
		  
			for k, v in pairs( HookTable ) do
				if ( v == nil ) then  
				  
					ErrorNoHalt("Hook '"..tostring(k).."' tried to call a nil function!\n")  
					HookTable[ k ] = nil -- remove this hook  
					break;  
				  
				else
					b, rA, rB, rC, rD, rE, rF, rG, rH = pcall( v, ... )  
					  
					if (!b) then  
					  
							ErrorNoHalt("Hook '"..tostring(k).."' Failed: "..tostring(rA).."\n")  
							HookTable[ k ] = nil -- remove this hook  
					  
					else  
					  
						// Allow hooks to override return values  
						if (rA != nil) then  
							return rA, rB, rC, rD, rE, rF, rG, rH  
						end  
						  
					end  
				end  
				  
			end  
		end  
		  
		if ( gm ) then  
		  
			local GamemodeFunction = gm[ name ]  
			if ( GamemodeFunction == nil ) then return nil end  
			
			if ( type( GamemodeFunction ) != "function" ) then  
				Msg( "Calling Non Function!? ", GamemodeFunction, "\n" )  
			end
			  
			-- This calls the actual gamemode function - after all the hooks have had chance to override  
			b, rA, rB, rC, rD, rE, rF, rG, rH = pcall( GamemodeFunction, gm, ... )  
			  
			if (!b) then  
			  
				gm[ name .. "_ERRORCOUNT" ] = gm[ name .. "_ERRORCOUNT" ] or 0  
				gm[ name .. "_ERRORCOUNT" ] = gm[ name .. "_ERRORCOUNT" ] + 1  
				ErrorNoHalt( "ERROR: GAMEMODE:'"..tostring(name).."' Failed: "..tostring(rA).."\n" )  
				return nil  
				
			end  
			  
		end  
		  
		return rA, rB, rC, rD, rE, rF, rG, rH
	end
end

--// Rewrite ends

local oldHook = {
	GetTable = hook.GetTable;
	Add = hook.Add;
	Remove = hook.Remove;
	Call = hook.Call;
}

local function CallProxy( name, gm, ... )
	local newRet = { hades.Hook.Call( name, gm, ... ) }
	--print( "Hook:", name, ..., newRet[1])
	if newRet[1] ~= nil then
		return unpack( newRet )
	end
	return oldHook.Call( name, gm, ... )
end

hook.Call = CallProxy

hades.Hook = {}

local _hooks = {}

function hades.Hook.Add( id, name, func )
	_hooks[id] = _hooks[id] or {}
	_hooks[id][name] = func
end

function hades.Hook.Remove( id, name )
	(_hooks[id] or {})[name] = nil
end

local b, ret, h_tbl
function hades.Hook.Call( id, gm, ... )
	h_tbl = _hooks[id]
	
	if ( h_tbl != nil ) then
		for k, v in pairs( h_tbl ) do
			if ( v == nil ) then
				ErrorNoHalt("Hook '"..tostring(k).."' tried to call a nil function!\n")
				h_tbl[ k ] = nil -- remove this hook
				break;
			else
				-- Call hook function
				if gm then
					ret = { pcall( v, gm, ... ) }
				else
					ret = { pcall( v, ... ) }
				end
				b = ret[1]
				table.remove( ret, 1 )

				if (!b) then
					ErrorNoHalt( "Hook '" .. tostring( k ) .. "' Failed: " .. tostring( ret[1] ) .. "\n" )
					h_tbl[k] = nil -- remove this hook
				else
					-- Allow hooks to override return values
					if (ret[1] != nil) then
						return unpack( ret )
					end
				end
			end
		end
	end

	return unpack( ret or {} )
end

hades.Hook.Add( "_G.__index", "asdasdblah", function( t, k )
	if k == "hook" then return hook end
end )

hades.Hook.Add( "_G.__newindex", "asdadfs", function( t, k, v )
	if k == "hook" then return true end
end )

hades.Hook.Add( "KeyEvent", "lolwatlol", function( event, key, bind )
	print( "KeyEvent", event, key, bind );
end )

hades.Hook.Add( "DispatchUserMessage", "kekekekeke", function( msg, um )
	print( msg )
	
	if msg == 35 then
		-- SendLua
		print( "SendLua", um:ReadString() )
		
		--return false
	end
end )