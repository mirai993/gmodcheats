hades.Command = {}

local _commands = {}

function hades.Command.Add( cmd, func )
	_commands[cmd] = func
end

function hades.Command.Remove( cmd )
	_commands[cmd] = nil
end

function hades.Command.Run( cmd, args, argv )
	if type( _commands[cmd] ) == "function" then
		_commands[cmd]( cmd, args, argv )
		
		return true
	end
end

hades.Hook.Add( "ExecuteString", "Command.Run", function( str )
	local cmd = str:match( "%s*(%S+)" )
	
	local argv = str:gsub( "%s*%S+%s*(.*)", "%1" )

	local quote = argv:sub( 1, 1 ) ~= '"'
	local ret = {}
	for chunk in argv:gmatch( '[^"]+' ) do
		quote = not quote
		if quote then
			table.insert( ret, chunk )
		else
			for chunk in chunk:gmatch( "%S+" ) do
				table.insert( ret, chunk )
			end
		end
	end
	
	return hades.Command.Run( cmd, ret, argv )
end )

hades.Command.Add( "h_runscript", function( cmd, args, argv )
	hades.RunString( argv )
end )

hades.Command.Add( "h_openscript", function( cmd, args )
	if #args > 0 and args[1] ~= "" then
		hades.Include( args[1] )
	end
end )