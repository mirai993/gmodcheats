hades.LogTypes = { };
hades.LogTypes.Types = {
	Info = 1;
	Debug = 2;
	Warning = 3;
	Error = 4;
	Fatal = 5;
};
hades.LogTypes.Colors = {
	Info = { 81, 81, 255 };
	Debug = { 81, 255, 81 };
	Warning = { 120, 81, 81 };
	Error = { 255, 81, 81 };
	Fatal = { 255, 0, 0 };
};

function hades.Notify( Type, String, ... )
	print( string.format( "[ Hades ] [ %s ] %s", string.upper( Type:sub( 1, 1 ) ) .. Type:sub( 2, #Type ), string.format( String, ... ) ) );
end;

function hades.Log( Color, Type, String, ... )
	local clr;
	local str;
	for k, v in pairs( hades.LogTypes.Colors ) do
		if Color == k then
			str = k;
			clr = v;
		end;
	end;
	local _String = string.format( String, ... );
	String = string.format( "[ %s:%s:%s:%s ] [ %s ] %s\n", os.date( "%I" ), os.date( "%M" ), os.date( "%S" ), os.date( "%p" ), str, _String );
	
	hades.IO.CreateDir( "hades/data/logs" )
	local logfile = hades.IO.Open( string.format( "hades/data/logs/%s.log", Type ), "a+" );
		logfile:Write( String );
	hades.Notify( Type, _String );
end;