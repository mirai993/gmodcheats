-- Safe
local debug = {}
debug.getinfo = _G.debug.getinfo

local string = {}
string.match = _G.string.match

local setmetatable = setmetatable
local rawget = rawget
local rawset = rawset

local hades = {}

local function IsHades( info )
	return (not info or info.what == "C" or info.short_src == "" or info.short_src == "[C]" or string.match( info.short_src, "^hades/" ))
end

setmetatable( _G, {
	__index = function( t, k )
		if k == "hades" then
			if IsHades( debug.getinfo( 2, "S" ) ) then
				-- Called from inside Hades, allow
				return hades
			end
			
			print "Unauthorized access blocked!"
			
			return nil
		end
		
		if hades and hades.Hook and hades.Hook.Call then
			local ret = hades.Hook.Call( "_G.__index", t, k )
			if ret ~= nil then return ret end
		end
		
		return rawget( t, k )
	end;
	
	__newindex = function( t, k, v )
		if k == "hades" then
			if not IsHades( debug.getinfo( 2, "S" ) ) then
				return
			end
		end
		
		if hades and hades.Hook and hades.Hook.Call then
			hades.Hook.Call( "_G.__newindex", t, k, v )
			if ret ~= nil then return ret end
		end
		
		rawset( t, k, v )
	end;
	
	__metatable = {};
} )

setmetatable( _R, {
	__index = function( t, k )
		if k == "Umsg" then
			if IsHades( debug.getinfo( 2, "S" ) ) then
				-- Called from inside Hades, allow
				return _R.Umsg;
			end;
						
			print "Unauthorized access blocked!";
			
			return nil;
		end;
		if k == "CVar" then
			if IsHades( debug.getinfo( 2, "S" ) ) then
				-- Called from inside Hades, allow
				return _R.Umsg;
			end;
						
			print "Unauthorized access blocked!";
			
			return nil;
		end;
		if k == "File" then
			if IsHades( debug.getinfo( 2, "S" ) ) then
				-- Called from inside Hades, allow
				return _R.Umsg;
			end;
						
			print "Unauthorized access blocked!";
			
			return nil;
		end;
		
		if hades and hades.Hook and hades.Hook.Call then
			local ret = hades.Hook.Call( "_R.__index", t, k )
			if ret ~= nil then return ret end
		end
		return rawget( t, k )
	end;
	__newindex = function( t, k, v )
		if k == "Umsg" then
			if not IsHades( debug.getinfo( 2, "S" ) ) then
				return;
			end;
		end;
		if k == "CVar" then
			if not IsHades( debug.getinfo( 2, "S" ) ) then
				return;
			end;
		end;
		if k == "File" then
			if not IsHades( debug.getinfo( 2, "S" ) ) then
				return;
			end;
		end;
		
		if hades and hades.Hook and hades.Hook.Call then
			hades.Hook.Call( "_R.__newindex", t, k, v )
			if ret ~= nil then return ret end
		end
		
		rawset( t, k, v )
	end;
} );