--^$@

hades.Firewall = { };
hades.Firewall.IncomingMessage = usermessage.IncomingMessage;
hades.Firewall.MessageTypes = {
	[ 29 ] = "SendLua";
};
hades.Firewall.InternalCommands = {
	[ "^%+" ] = true;
	[ "^%-" ] = true;
	[ "^h_" ] = true;
	[ "^connect" ] = true;
	[ "^changeteam" ] = true;
	[ "^impulse" ] = true;
	[ "^say" ] = true;
	[ "^myinfo" ] = true;
	[ "^gameui" ] = true;
	[ "^vote" ] = true;
	[ "^dsp" ] = true;
	[ "^change" ] = true;
	[ "^cl_" ] = true;
	[ "^wepswitch" ] = true;
	[ "^rcon" ] = true;
	[ "^bind" ] = true;
	[ "^cursor_" ] = true;
	[ "^gm_spawn" ] = true;
};
hades.Firewall.Commands = { };
hades.Firewall.TCommands = { };
hades.Firewall.Usermessages = { };

local dfile = hades.IO.Open( "hades/data/firewall.dat", "rb+" );
	hades.Firewall.Commands = glon.decode( dfile:Read( ) );

function hades.Firewall.Save( )
	local _firewallData = hades.IO.Open( "hades/data/firewall.dat", "rb+" )
		_firewallData:Write( glon.encode( hades.Firewall.Commands ) );
end;

local DListView1;
local DListView2;
local DListView3;
local DPropertySheet1;
local DFrame1;

local _bcmds = { };
local _bumsg = { };
local _bfiles = { };

function hades.Firewall.RefreshMenu( cmd )
	if DListView1 then
		DListView1:Clear( );
		for k, v in pairs( _bcmds ) do
			DListView1:AddLine( v )
		end;
	end;
	if DListView2 then
		DListView2:Clear( );
		for k, v in pairs( _bumsg ) do
			DListView2:AddLine( v.Name, v.Contents, v.Size, v.Type );
		end;
	end;
	if DListView3 then
		DListView3:Clear( );
		for k, v in pairs( _bfiles ) do
			DListView3:AddLine( v.Path, v.Key, v.Priority );
		end;
	end;
end;

function hades.Firewall.AllowForever( cmd )
	_bcmds[ cmd ] = nil;
	hades.Firewall.Commands[ cmd ] = true;
	LocalPlayer( ):ConCommand( cmd );
	hades.Firewall.Save( );
	hades.Firewall.RefreshMenu( );
end;

function hades.Firewall.Allow( cmd )
	_bcmds[ cmd ] = nil;
	hades.Firewall.TCommands[ cmd ] = true;
	LocalPlayer( ):ConCommand( cmd );
	hades.Firewall.Save( );
	hades.Firewall.RefreshMenu( );
end;

function hades.Firewall.Block( cmd )
	_bcmds[ cmd ] = nil;
	hades.Firewall.TCommands[ cmd ] = false;
	hades.Firewall.Save( );
	hades.Firewall.RefreshMenu( );
end;

function hades.Firewall.BlockForever( cmd )
	_bcmds[ cmd ] = nil;
	hades.Firewall.Commands[ cmd ] = false;
	hades.Firewall.Save( );
	hades.Firewall.RefreshMenu( );
end;

function hades.Firewall.Menu( )
	DFrame1 = vgui.Create( "DFrame" );
	DFrame1:SetSize( 729, 423 );
	DFrame1:SetPos( 125, 58 );
	DFrame1:SetTitle( "Hades Firewall" );
	DFrame1:SetSizable( false );
	DFrame1:SetDeleteOnClose( false );
	DFrame1:MakePopup( );

	DPropertySheet1 = vgui.Create( "DPropertySheet", DFrame1 );
	DPropertySheet1:SetSize( 717, 388 );
	DPropertySheet1:SetPos( 5, 28 );
	
	DListView1 = vgui.Create( "DListView" );
	DListView1:SetSize( 709, 380 );
	DListView1:SetPos( 5, 6 );
	DListView1.DoDoubleClick = function( parent, ind, list )
		Derma_Query(
				"What access should this command have?",
				"Query",
				"Allow",
				function( )
					DListView1:RemoveLine( DListView1:GetSelectedLine( ) );
					hades.Firewall.Allow( list:GetValue( 1 ) );
				end,
				"Allow Forever",
				function( )
					DListView1:RemoveLine( DListView1:GetSelectedLine( ) );
					hades.Firewall.AllowForever( list:GetValue( 1 ) );
				end,
				"Block",
				function( )
					DListView1:RemoveLine( DListView1:GetSelectedLine( ) );
					hades.Firewall.Block( list:GetValue( 1 ) );
				end,
				"Block Forever",
				function( )
					DListView1:RemoveLine( DListView1:GetSelectedLine( ) );
					hades.Firewall.BlockForever( list:GetValue( 1 ) );
				end,
				"Cancel",
				function( ) end
			);
	end;
	
	DListView1:AddColumn( "Command" );
	
	DListView1:Clear( );
	for k, v in pairs( _bcmds ) do
		DListView1:AddLine( v );
	end;

	DListView2 = vgui.Create( "DListView" );
	DListView2:SetSize( 709, 380 );
	DListView2:SetPos( 5, 6 );
	
	DListView2:AddColumn( "Name" );
	DListView2:AddColumn( "Contents" );
	DListView2:AddColumn( "Size" );
	DListView2:AddColumn( "Type" );
	
	DListView2:Clear( );
	for k, v in pairs( _bumsg ) do
		DListView2:AddLine( v.Name, v.Contents, v.Size, v.Type );
	end;

	DListView3 = vgui.Create( "DListView" );
	DListView3:SetSize( 709, 380 );
	DListView3:SetPos( 5, 6 );
	
	DListView3:AddColumn( "Path" );
	DListView3:AddColumn( "Keyword" );
	DListView3:AddColumn( "Priority" );
	
	DListView3:Clear( );
	for k, v in pairs( _bfiles ) do
		DListView3:AddLine( v.Path, v.Key, v.Priority );
	end;
	
	DPropertySheet1:AddSheet( "Commands", DListView1, "gui/silkicons/application_go", false, false, "View and manage your ExecuteString objects." );
	DPropertySheet1:AddSheet( "Usermessages", DListView2, "gui/silkicons/server_go", false, false, "View and manage your Usermessage objects." );
	DPropertySheet1:AddSheet( "Lua", DListView3, "gui/silkicons/script_go", false, false, "View and manage your Lua objects." );
end;
hades.Command.Add( "h_firewall", hades.Firewall.Menu );

--[[
function usermessage.IncomingMessage( name, object )
	print( string.format( "[ Hades ] [ Firewall ] Incoming usermessages %s with the size of 255 and the contents %s", name, object:ReadString( ) ) );
	return hades.Firewall.IncomingMessage( name, object );
end;

hades.Hook.Add( "ProcessUserMessage", "SendLuaLogging", function( name, id, msg )
	if id == 29 then
		hades.Log( "Info", "Firewall-SendLua", "SendLua > %s > %s > %s", name, hades.Umsg.ReadString( msg ), hades.Umsg.GetSize( msg )  );
	end;
	table.insert( _bumsg, { Type = hades.Firewall.MessageTypes[ id ], Contents = hades.Umsg.ReadString( msg ), Name = name, Size = hades.Umsg.GetSize( msg ) } );
end );
--]]

hades.Hook.Add( "ExecuteString", "HadesFirewall", function( cmd )
	if hades.Firewall.Commands[ cmd ] == false or hades.Firewall.TCommands[ cmd ] == false then
		hades.Log( "Warning", "Firewall", "Blocked command %s", cmd );
		return false;
	end;
	if hades.Firewall.Commands[ cmd ] == nil and not hades.Firewall.TCommands[ cmd ]
		and not cmd:find( "+" ) and not cmd:find( "-" ) and not cmd:find( "[$&*,`]" ) and not cmd:find( "connect" ) and not cmd:find( "changeteam" )
		and not cmd:find( "impulse" ) and not cmd:find( "say" ) and not cmd:find( "say" ) and not cmd:find( "myinfo" ) and not cmd:find( "h_" )
		and not cmd:find( "ev" ) and not cmd:find( "gameui" ) and not cmd:find( "votegamemode" ) and not cmd:find( "votemap" ) and not cmd:find( "dsp_" )
		and not cmd:find( "changeclass" ) and not cmd:find( "spec_" ) and not cmd:find( "cl_" ) and not cmd:find( "ttt_" ) and not cmd:find( "wepswitch" )
		and not cmd:find( "rot_" ) and not cmd:find( "rcon" ) and not cmd:find( "bind" ) and not cmd:find( "slot" ) and not cmd:find( "gm_" ) and not cmd:find( "cursor" ) then
			hades.Log( "Info", "Firewall", "Blocked non-greylisted command %s", cmd );
			
			table.insert( _bcmds, cmd );
			hades.Firewall.Save( );
			hades.Firewall.RefreshMenu( );
			return false;
	end;
end );

hades.Hook.Add( "PlayerInitialSpawn", function( )
	timer.Simple( 0, function( )
		if hades.RoTFQueue then
			RunConsoleCommand( "~~rot~init" );
		end;
	end );
end );

hades.Notify( "Info", "Loaded Firewall" );