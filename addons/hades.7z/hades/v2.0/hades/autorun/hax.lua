local gtowerdebug = CreateClientConVar( "h_gtower_debug", "1", true, false );

hades.Command.Add( "h_bo_thirdperson", function( cmd, args, argv )
	LocalPlayer( ):SetNWBool( "HasThirdperson", argv );
	RunConsoleCommand( "thirdperson_enabled", argv );
end );

usermessage.Hook( "BA:GetCommand", function( um )
	hades.Notify( "Info", "Blackops hack command: %s", um:ReadString( ) );
end );

if CurMap then
	usermessage.Hook( "GTDebug", function( um )
		local name = um:ReadString( );
		local msg = um:ReadString( );
		
		if ( gtowerdebug:GetBool( ) ) then
			hades.Notify( "Info", "Incoming GTower debug message %s with contents %s", name, msg );
		end;
	end );
end;