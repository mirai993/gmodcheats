local BAR = derma.DefineControl( "HFirewallBar", "", { } );

AccessorFunc( BAR, "Command", "Command", FORCE_STRING );

BAR.SetText = BAR.SetCommand

function BAR:Init( ) end;

function BAR:PerformLayout( )
	self:SetTall( 20 );
end;

local block;
local allowc = Material( "gui/silkicons/checkmark" );
local blockc = Material( "gui/silkicons/delete" );

function BAR:Paint()
	local color;
	local skin = derma.GetDefaultSkin( );
	skin:DrawGenericBackground( 0, 0, self:GetWide( ), self:GetTall( ), skin.bg_color );
	if self.Waiting then
		color = skin.control_color_active;
	elseif not self.Hovered then
		color = skin.colTab;
	else
		color = skin.colTabInactive;
	end;
	skin:DrawGenericBackground( 0, 0, self:GetWide( ), self:GetTall( ), color );
	
	surface.SetMaterial( allowc );
	surface.SetDrawColor( 255, 255, 255, 255 );
	surface.DrawTexturedRect( 10, 2, 16, 16 );
	
	surface.SetMaterial( blockc );
	surface.SetDrawColor( 255, 255, 255, 255 );
	surface.DrawTexturedRect( 31, 2, 16, 16 );
		
	draw.SimpleText( self.Command, "default", 47, self:GetTall( ) / 2 - 1, skin.colTabText, nil, TEXT_ALIGN_CENTER );
end;