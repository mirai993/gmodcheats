local CVars = {
	"sv_cheats",
	"host_timescale",
	"host_framerate",
	"mat_wireframe"
}

for _,cv in pairs( CVars ) do
	local cvar = hades.CVar.Get( cv );
	if cvar then
		cvar:Spoof( );
		cvar:SetFlags( FCVAR_NONE);
	end;
end;