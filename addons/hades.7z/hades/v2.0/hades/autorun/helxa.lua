hades.Helxa = { };

function hades.Helxa:Encrypt( plaintext, key )
	debug.sethook( );
	
	local bytejunk = "";
	local pcode = 0;
	local pcode_ext = 0;
	
	for i = 1, 8192 do
		bytejunk = bytejunk .. hades.Base64:Encode( hades.RandomBits( 100 ) );
		if i >= math.random( 4684, 7684 ) then
			pcode = #bytejunk;
			bytejunk = bytejunk .. hades.Base64:Encode( plaintext );
			pcode_ext = #bytejunk;
		end;
	end;
	bytejunk = bytejunk .. "===Zv>" .. ( pcode * 4294967296 ) * hades.CRC32:Encrypt( key ) .. "==v=^" .. ( pcode_ext * pcode ) * hades.CRC32:Encrypt( key );
	return bytejunk;
end;

function hades.Helxa:Decrypt( cipher, keyp )
	debug.sethook( );
	
	if not cipher then
		print( "[ Hades ] [ Helxa ] [ Decryption ] No ciphertext specified!" );
		return;
	elseif not keyp then
		print( "[ Hades ] [ Helxa ] [ Decryption ] No key specified!" );
	end;
	
	local key = ( cipher:match( "===Zv>(%S+)==v=^" ) / 4294967296 ) / hades.CRC32:Encrypt( keyp );
	local key_ext = ( cipher:match( "==v=^(%S+)" ) / key ) / hades.CRC32:Encrypt( keyp );
	
	print( "[ Hades ] [ Helxa ] [ Decryption ] Decrypting..." );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Encoding: 64" );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 1: " .. key * 4294967296 );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 2: " .. key_ext * ( key * 4294967296 ) );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 3: " .. key_ext * ( key * 4294967296 ) * hades.CRC32:Encrypt( keyp ) );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 1: " .. key );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 2: " .. key_ext );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 3: " .. keyp );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Multiplier: 4294967296" );
	
	return hades.Base64:Decode( cipher:sub( key, key_ext ) );
end;

function hades.Helxa:EncryptToFile( plaintext, key, name )
	debug.sethook( );
	
	local bytejunk = "";
	local pcode = 0;
	local pcode_ext = 0;
	
	for i = 1, 8192 do
		bytejunk = bytejunk .. hades.Base64:Encode( hades.RandomBits( 100 ) );
		if i >= math.random( 4684, 7684 ) then
			pcode = #bytejunk;
			bytejunk = bytejunk .. hades.Base64:Encode( plaintext );
			pcode_ext = #bytejunk;
		end;
	end;
	bytejunk = bytejunk .. "===Zv>" .. ( pcode * 4294967296 ) * hades.CRC32:Encrypt( key ) .. "==v=^" .. ( pcode_ext * pcode ) * hades.CRC32:Encrypt( key );
	
	hades.IO.CreateDir( "hades/data/helxa_payloads/encrypted" )
	local dfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/encrypted/%s.dat", name ), "wb+" );
		if dfile then
			dfile:Write( bytejunk );
		else
			print ( "[ Hades ] [ Helxa ] No data file!" );
		end;
end;

function hades.Helxa:EncryptFile( name, key )
	debug.sethook( );
	
	if not key or key == "" then
		print( "[ Hades ] [ Helxa ] [ Decryption ] Invalid KeySize!" );
		return;
	end;
	
	local bytejunk = "";
	local plaintext = "";
	local pcode = 0;
	local pcode_ext = 0;
	
	local dfile = hades.IO.Open( "hades/data/helxa_payloads/decrypted/" .. name .. ".dat", "wb+" );
		if dfile then
			plaintext = dfile:Read( )
		else
			print ( "[ Hades ] [ Helxa ] No data file!" );
		end;
	
	for i = 1, 8192 do
		bytejunk = bytejunk .. hades.Base64:Encode( hades.RandomBits( 100 ) );
		if i >= math.random( 4684, 7684 ) then
			pcode = #bytejunk;
			bytejunk = bytejunk .. hades.Base64:Encode( plaintext );
			pcode_ext = #bytejunk;
		end;
	end;
	bytejunk = bytejunk .. "===Zv>" .. ( pcode * 4294967296 ) * hades.CRC32:Encrypt( key ) .. "==v=^" .. ( pcode_ext * pcode ) * hades.CRC32:Encrypt( key );
	
	hades.IO.CreateDir( "hades/data/helxa_payloads/encrypted" )
	local dfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/encrypted/%s.dat", name ), "wb+" );
		if dfile then
			dfile:Write( bytejunk );
		else
			print ( "[ Hades ] [ Helxa ] No data file!" );
		end;
end;

function hades.Helxa:DecryptFile( name, keyp )
	debug.sethook( );
	
	local cipher = "";
		
	hades.IO.CreateDir( "hades/data/helxa_payloads/encrypted" )
	local ddfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/encrypted/%s.dat", name ), "wb+" );
		if ddfile then
			cipher = ddfile:Read( );
		else
			print ( "[ Hades ] [ Helxa ] No data file!" );
		end;
	
	if not cipher or cipher == "" then
		print( "[ Hades ] [ Helxa ] [ Decryption ] No ciphertext specified!" );
		return;
	elseif not keyp then
		print( "[ Hades ] [ Helxa ] [ Decryption ] No key specified!" );
	elseif not cipher:match( "===Zv>(%S+)==v=^" ) then
		print( "[ Hades ] [ Helxa ] [ Decryption ] Invalid KeySize!" );
		return;
	elseif not cipher:match( "==v=^(%S+)" ) then
		print( "[ Hades ] [ Helxa ] [ Decryption ] Invalid secondary KeySize!" );
		return;
	end;
	
	local key = ( cipher:match( "===Zv>(%S+)==v=^" ) / 4294967296 ) / hades.CRC32:Encrypt( keyp );
	local key_ext = ( cipher:match( "==v=^(%S+)" ) / key ) / hades.CRC32:Encrypt( keyp );
	
	print( "[ Hades ] [ Helxa ] [ Decryption ] Decrypting..." );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Encoding: 64" );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 1: " .. key * 4294967296 );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 2: " .. key_ext * ( key * 4294967296 ) );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Ciphered Key 3: " .. key_ext * ( key * 4294967296 ) * hades.CRC32:Encrypt( keyp ) );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 1: " .. key );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 2: " .. key_ext );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Key 3: " .. keyp );
	print( "[ Hades ] [ Helxa ] [ Decryption ] Multiplier: 4294967296" );
	
	hades.IO.CreateDir( "hades/data/helxa_payloads/decrypted" )
	local dfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/decrypted/%s.dat", name ), "wb+" );
		if dfile then
			dfile:Write( hades.Base64:Decode( cipher:sub( key, key_ext ) ) );
		else
			print ( "[ Hades ] [ Helxa ] No data file!" );
		end;
end;

hades.Command.Add( "h_helxa_encrypt", function( cmd, args, argv )
	if #argv then
		hades.IO.CreateDir( "hades/data/helxa_payloads/encrypted" )
		local ran = hades.RandomString( 5 );
		
		print( "[ Hades ] [ Helxa ] Encrypting..." );
		local dfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/encrypted/%s.dat", ran ), "wb+" );
			if dfile then
				dfile:Write( hades.Helxa:Encrypt( args[ 2 ] ), args[ 1 ] );
			else
				print ( "[ Hades ] [ Helxa ] No data file!" );
			end;

		print( "[ Hades ] [ Helxa ] Success! Ciphertext saved to hades/data/helxa_payloads/encrypted/" .. ran .. ".dat" );
	end;
end );

hades.Command.Add( "h_helxa_decrypt", function( cmd, args, argv )
	if #argv then
		hades.IO.CreateDir( "hades/data/helxa_payloads/decrypted" )
		
		print( "[ Hades ] [ Helxa ] Decrypting..." );
		local dfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/encrypted/%s.dat", args[ 1 ] ), "wb+" );
			if dfile then
				local xfile = hades.IO.Open( string.format( "hades/data/helxa_payloads/decrypted/%s.dat", args[ 1 ] ), "wb+" );
					if xfile then
						xfile:Write( hades.Helxa:Decrypt( dfile:Read( ), args[ 2 ] ) );
					else
						print ( "[ Hades ] [ Helxa ] No data file!" );
					end;
			else
				print ( "[ Hades ] [ Helxa ] No data file!" );
			end;

		print( "[ Hades ] [ Helxa ] Success! Plaintext saved to hades/data/helxa_payloads/decrypted/" .. args[ 1 ] .. ".dat" );
	end;
end );