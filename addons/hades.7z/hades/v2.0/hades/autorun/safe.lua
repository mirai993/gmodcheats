hades.Safe.Spoof = {
	[ "require" ] = require;
	[ "rawset" ] = rawset;
	[ "rawget" ] = rawget;
	[ "setmetatable" ] = setmetatable;
	[ "getmetatable" ] = getmetatable;
	[ "engineConsoleCommand" ] = engineConsoleCommand;
	[ "engineCommandComplete" ] = engineCommandComplete;
	[ "debug.getupvalue" ] = debug.getupvalue;
	[ "cvars.OnConVarChanged" ] = cvars.OnConVarChanged;
	[ "cvars.AddChangeCallback" ] = cvars.AddChangeCallback;
};
local address = "";
for k, v in pairs( hades.Safe.Spoof ) do
	address = 0 .. "x" .. tostring( v ):match( "([0-9A-F]+)$" );
	for i, p in pairs( hades.Safe.GetUpValues( v ) ) do
		if i:lower( ):find( "old" ) then
			_G[ v ] = i;
			print( string.format( "[ Hades ] [ Safe ] Set detoured function %s at address %s to manifestation %s", k, address, i ) );
		end;
		print( string.format( "[ Hades ] [ Safe ] Upvalue %s found in function %s at address %s", i, k, address ) );
	end;
end;