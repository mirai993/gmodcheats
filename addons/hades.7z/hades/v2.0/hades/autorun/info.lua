--^$@

hades.Info = { };
hades.Info.Systems = {
	"Evolvemod";
	"ASSMod";
	"ULX";
	"AIDs";
	"BlackAdmin";
	"RoTF";
	"Exsto";
	"Sassilization";
	"Other";
};

local function fe( f )
	if file.Exists( "../lua_temp/" .. f .. ".lua" ) then
		return true;
	end;
	return false;
end;

local function AdminSystem( )
	if fe( "ev_cl_init" ) then
		return hades.Info.Systems[ 1 ];
	elseif fe( "ass_client" ) then
		return hades.Info.Systems[ 2 ];
	elseif fe( "ulx/cl_init" ) then
		return hades.Info.Systems[ 3 ];
	elseif fe( "autorun/aids" ) then -- Might not be correct^
		return hades.Info.Systems[ 4 ];
	elseif fe( "BlackAdmin/client/cl_admin" ) then
		return hades.Info.Systems[ 5 ];
	elseif fe( "rot/modules/cl_globalmenu" ) then
		return hades.Info.Systems[ 6 ];
	elseif fe( "exsto/cl_init" ) then
		return hades.Info.Systems[ 7 ];
	elseif fe( "STBase/gamemode/modules/admin/client" ) then
		return hades.Info.Systems[ 8 ];
	end;
	return hades.Info.Systems[ 9 ];
end;

-- Why does this not work? :(^
--[[

local playerdata = { };

hades.Hook.Add( "PlayerAuthed", "HadesInformationAuth", function( ply, steamid, unique )
	playerdata[ ply:Nick( ) ] = {
		SteamID = steamid;
		UniqueID = unique;
	};
end );

hades.Hook.Add( "PlayerConnect", "HadesInformationConnect", function( name, ip )
	hades.Notify( "Info", "%s > %s > %s > %s > Has connected", name, playerdata[ ply:Nick( ) ].SteamID, playerdata[ ply:Nick( ) ].UniqueID, ip );
end );
--]]

hades.Notify( "Info", "Current admin system: %s", AdminSystem( ) );