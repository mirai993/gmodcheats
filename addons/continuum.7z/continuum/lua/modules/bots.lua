local CE = CE

MODULE.Enabled = true
MODULE.ID = "com.continuum.bots"
MODULE.Dependencies = { }

MODULE.Name="Bots"
MODULE.Info="Bots for DarkRP"
MODULE.cvars = { {name="hacks_bots", nick="Bots", info="Use bots for random situations"}, {name="hacks_verboseumsg", nick="Verbose UMSG", info="Logs umsgs to console"}, {name="hacks_verbosenet", nick="Verbose Net", info="Logs net messages to console"} }

MODULE.Init=function(CE)
  local handlers
  local status = ""
  CE.Hook.Add("Think", "BotHandler", function()
  	for _,handler in pairs(handlers) do
  		if handler.Active then
  			if handler.ShouldDeactivate and handler.ShouldDeactivate() then
  				handler.Active = false
  			else
  				local ret = handler.Loop()
  				if type(ret) == "string" then
  					status = ret
  				elseif ret == true then
  					handler.Active = false
  					status = ""
  				end
  				print(ret)
  			end
  		elseif handler.ShouldActivate() then
  			handler.Active = true
  		end
  	end
  end)
  CE.Hook.Add("HUDPaint", "BotHandler", function()
  	draw.DrawText("Status: " .. status, "Default", 15,15, CE.Colors.GREEN, TEXT_ALIGN_LEFT )
  end)
  local _Reload = false
  local _Attack = false
  local function Reload()
  	_Reload = true
  end
  local function Attack()
  	_Attack = true
  end
  CE.Hook.Add("CreateMove", "BotHandler", function(cmd)
  	if _Reload then
  		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))
  	end
  	if _Attack then
  		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
  	end
  	_Reload = false
  	_Attack = false
  end, -1)
  
  local function DPS(weapon)
  	if not IsValid(weapon) or not weapon.Primary or not weapon.Primary.Damage then return -1 end
  	local Delay = weapon.Delay
  	if Delay == 0 or Delay == nil then Delay = 1 end
  	return weapon.Primary.Damage / Delay
  end
  local function FindBestWeapon()
  	local BestWeapon
  	for _,Weapon in pairs(LocalPlayer():GetWeapons()) do
  		local dps = DPS(Weapon)
  		if dps ~= -1 and not IsValid(BestWeapon) or dps > DPS(BestWeapon) then
  			BestWeapon = Weapon
  		end
  	end
  	return BestWeapon
  end
  local function SwitchToWeapon()
  	local currentWeapon = LocalPlayer():GetActiveWeapon()
  	if DPS(currentWeapon) < 0 then
  		local weapon = FindBestWeapon()
  		if not IsValid(weapon) then
  			return "No good weapon found!"
  		end
  		RunConsoleCommand("use", weapon:GetClass())
  		return "Switching weapons..."
  	end
  	if currentWeapon.IdleDelay  and currentWeapon.IdleDelay >= CurTime() and not currentWeapon.IdleApply then
  		return "Animating..."
  	end
  	if currentWeapon:Clip1() <= 0 then
  		Reload()
  		return "Reloading..."
  	end
  	return true
  end
  
  local MugHandler = {
  	ShouldActivate = function()
  		return LocalPlayer():Alive() and CE.Muggers
  	end,
  	ShouldDeactivate = function()
  		return not LocalPlayer():Alive()
  	end,
  	Loop = function()
  		local ret = SwitchToWeapon()
  		if ret ~= true then
  			return ret
  		end
  		local Alive = false
  		for k,v in pairs(CE.Muggers) do
  			if v:Alive() then
  				Alive = v
  				local absVel = v:GetAbsVelocity() * .03
  				local hitbox = CE.FindHead(v)
  				local bone
  				if hitbox then
  					bone = v:GetHitBoxBone( hitbox, 0 );
  				else
  					bone = v:LookupBone("ValveBiped.Bip01_Head1") or CE.Constants.BONE_HEAD
  				end
  				local TargetHeadPosition = v:GetBonePosition( bone );
  				TargetHeadPosition = TargetHeadPosition  + absVel
  				absVel = LocalPlayer():GetAbsVelocity() * .03
  				local CurrentAngles = LocalPlayer():EyeAngles()
  				local NewAngles = (LocalPlayer():GetShootPos()+absVel):AngleTo(TargetHeadPosition)
  				local BetweenAngles = LerpAngle(.5, CurrentAngles, NewAngles)
  				CE.SetEyeAngles(BetweenAngles)
  				Attack()
  				break
  			end
  		end
  		if Alive then
  			return "Attacking " .. Alive:Nick()
  		end
  		CE.Muggers = nil
  		return false
  	end
  }
  handlers = { MugHandler }
  
  --TODO: Add the following handlers
  --      	- Mugging someone else (shoots on movement / drawing weapon)
  --      	- Being pickpocketed (Detects nearby pickpocketer / noise / animation / something, idk)
  -- 			- Possibly raid, but thatd be tough
  -- 			- Idk what else. Dont forget to test being mugged tho
end