MODULE.ID = "com.continuum.murder.flag"
MODULE.Dependencies = { "com.continuum.notify" }

MODULE.Name = "Murderer Flagger"
MODULE.Init = function(CE)
  CE.Hook.Add("Think", "CE.MurderFlagger", function()
    for k,v in pairs(player.GetAll()) do
        v._MurderStatus = 0
      if v.MurderStatus == 2 then
        v._MurderStatus = 2
      end
    end
    for _,v in pairs(ents.GetAll() ) do
      local pl = v:GetOwner()
      if v:GetClass() == "weapon_mu_magnum" then
        pl._MurderStatus = 1 -- detective
      end
      if v:GetClass() == "weapon_mu_knife" then
        pl._MurderStatus = 2
      end
    end
    for k,v in pairs(player.GetAll()) do
      v.MurderStatus = v._MurderStatus
    end
  end)
end