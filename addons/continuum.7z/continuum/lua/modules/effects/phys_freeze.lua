if RequireEffect("phys_freeze") then
	local effects_freeze = CreateClientConVar( "effects_freeze", "1", true, false )

	--[[---------------------------------------------------------
	Initializes the effect. The data is a table of data
	which was passed from the server.
	-----------------------------------------------------------]]
	function EFFECT:Init( data )

		if ( effects_freeze:GetBool() == false ) then return end

		self.Target = data:GetEntity()
		self.Target.Frozen = true
		self.StartTime	= CurTime()
		self.Length		= 2 -- because .3 is too damn low
	end


	--[[---------------------------------------------------------
	THINK
	-----------------------------------------------------------]]
	function EFFECT:Think( )

		if ( effects_freeze:GetBool() == false ) then return false end
		return self.StartTime + self.Length > CurTime()

	end


-- Cool functions: 

-- Code: 1 - ((CurTime() - self.StartTime) / self.Length) ^ .5
-- Function: 1 - (x^.5)
-- Graph: http://www.wolframalpha.com/input/?i=graph+%281-x%5E.5%29++0+to+1

-- Code: 
-- Function: -2.166666667 x^2 + 1.366666667 x + 0.8

-- -3.988095238 x3 + 3.160714286 x2 + 2.738095238�10-2 x + 0.8
local function SlowDecrease(x)
	return 1 - (x^.5)
end
local function QuadraticDecrease(x)
	return -2.166666667 * x * x + 1.366666667 * x + 0.8
end
local Function = QuadraticDecrease
	--[[---------------------------------------------------------
	Draw the effect
	-----------------------------------------------------------]]
	function EFFECT:Render()

		if ( not IsValid( self.Target ) ) then return end
		local x = (CurTime() - self.StartTime) / self.Length
		local y = Function(x)

		local size = 1
		effects.halo.Add( {self.Target}, Color( 0, 255, 0, 255 * y ), size, size, 1, true, false )
	end
end