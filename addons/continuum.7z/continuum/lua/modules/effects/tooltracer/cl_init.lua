if RequireEffect("tooltracer") then
	EFFECT.Mat = Material("effects/tool_tracer")

	--[[---------------------------------------------------------
	Init( data table )
	-----------------------------------------------------------]]
	function EFFECT:Init( data )

		self.Position = data:GetStart()
		self.WeaponEnt = data:GetEntity()
		self.Attachment = data:GetAttachment()
		

		-- Keep the start and end pos - we're going to interpolate between them
		self.StartPos = self:GetTracerShootPos( self.Position, self.WeaponEnt, self.Attachment )
		self.EndPos = data:GetOrigin()

		self.Alpha = 255
		self.Life = 0.0;

		self:SetRenderBoundsWS( self.StartPos, self.EndPos )

		--[[if self.WeaponEnt:GetOwner() == LocalPlayer() and self.WeaponEnt.Mode == "material" then
			local mat = GetConVarString("material_override")
			if mat ~= "models/effects/comball_glow2" then
				self.MaterialMat = Material(mat)
			end
		end]]
	end

	--[[---------------------------------------------------------
	THINK
	-----------------------------------------------------------]]
	function EFFECT:Think( )

		self.Life = self.Life + FrameTime() * 4;
		self.Alpha = 255 * ( 1 - self.Life )

		return (self.Life < 1)

	end

	--[[---------------------------------------------------------
	Draw the effect
	-----------------------------------------------------------]]
	local CachedMaterials = { }
	function EFFECT:Render( )
		if ( self.Alpha < 1 ) then return end
		local mat = self.MaterialMat or self.Mat
		render.SetMaterial( mat )
		local texcoord = math.Rand( 0, 1 )

		local norm = (self.StartPos - self.EndPos) * self.Life

		self.Length = norm:Length()

		for i=1, 3 do

			render.DrawBeam( self.StartPos - norm, 										-- Start
			self.EndPos,											-- End
			8,													-- Width
			texcoord,														-- Start tex coord
			texcoord + self.Length / 128,									-- End tex coord
			Color( 255, 255, 255, 255 ) )		-- Color (optional)
		end

		render.DrawBeam( self.StartPos,
		self.EndPos,
		8,
		texcoord,
		texcoord + ((self.StartPos - self.EndPos):Length() / 128),
		Color( 255, 255, 255, 128 * ( 1 - self.Life ) )	)

	end
end