MODULE.ID = "com.continuum.effects"
MODULE.Dependencies = { }

MODULE.Name = "Effects"
MODULE.Info = "Allows for effect mods to be placed in modules/effects folder"

MODULE.Init = function(CE)
  local files,folders = file.Find( "lua/modules/effects/*", "MOD" )
  for key,file in pairs(files) do
  	local simpleName = string.StripExtension(file)
  	EFFECT = { }
  	EFFECT.Folder = "modules/effects/"..simpleName
  	function LoadEffect(name)
  		EFFECT = effects.EffectList[name]
  	end
  	local Cancel = false
  	function RequireEffect(name)
  		EFFECT = effects.EffectList[name]
  		if not EFFECT then Cancel = true end
  		return not Cancel
  	end
    CE.RevealGlobal()
  	CE.include("modules/effects/"..file)
    CE.HideGlobal()
  	if not Cancel then
  		effects.Register(EFFECT, simpleName)
  	end
  	RequireEffect = nil
  	LoadEffect = nil
  	EFFECT = nil
  end
  for key,folder in pairs(folders) do
  	local luaFiles = file.Find("lua/modules/effects/"..folder.."/*.lua", "MOD")
  	EFFECT = { }
  	EFFECT.Folder = "modules/effects/"..folder
  	function LoadEffect(name)
  		Effect = effects.EffectList[name]
  	end
  	local Cancel = false
  	function RequireEffect(name)
  		Effect = effects.EffectList[name]
  		if not Effect then Cancel = true end
  		return not Cancel
  	end
  	for key, val in pairs( luaFiles ) do
      CE.RevealGlobal()
  		CE.include( "modules/effects/"..folder.."/"..val )
      CE.HideGlobal()
  	end
  	if not Cancel then
  		effects.Register(EFFECT, folder)
  		print("Added effect ", folder)
  	end
  	RequireEffect = nil
  	LoadEffect = nil
  	EFFECT = nil
  end
end