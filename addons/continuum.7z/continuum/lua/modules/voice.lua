local CE = CE
MODULE.ID="com.continuum.voice"
MODULE.Dependencies = { }
MODULE.Name="Voice HUD"
local I_Vis = {}

-- If you're using ttt you should set this to true.
I_Vis.VisIsTTT                       = CE.IsTTT()

-- Visualizer mode 
-- 0 = Nothing
-- 1 = Semi-Circles
-- 2 = Moving Bars
-- 3 = Pin point Bar Graph
-- 4 = Line graph
-- 5 = Simple wave
I_Vis.Visualizer                     = 3

-- You can change the color scheme for your visualizer here.
-- 0 = Use default color for the visualizer 
-- 1 = Use Colors depending on the player (Set Colors in GetPlayersColor below.)
-- 2 = Use a fade from red - green depending on the how loud the player is.
-- 3 = rainbow...
I_Vis.VisColorMode                   = 3

-- Controls the opacity of the visualizer.
I_Vis.VisualizerOpac                 = 100

-- Default color for the Visualizers
I_Vis.VisDefaultCol                  = Color(50,50,50,100)

-- Do you want to display player models on the panel? ( NOTE: This will replace avatar icons)
I_Vis.ShowPlayerModel                = false

------------------------------------------------------------------------------
----------------------------Main Color Settings-------------------------------
------------------------------------------------------------------------------

I_Vis.VisBorderColor                 = Color(40,40,40,255)

I_Vis.VisBGColor                     = Color(25,25,25,255)

I_Vis.VisNameColor                   = Color(160,160,160,120)

I_Vis.VisTagColor                    = Color(160,160,160,60)

I_Vis.VisSteamIDColor                = Color(160,160,160,10)

-- The avatar background color if a friend talks
I_Vis.vFriendColor           = Color(129,214,171)

-- The avatar background color if a non friend talks
I_Vis.vNotFriendColor                = Color(129,196,214)

------------------------------------------------------------------------------
------------Below Here You Can Edit Some More Advanced Settings---------------
------------------------------------------------------------------------------

-- This is the multiplier for player voices. Recommended to keep
-- at 300 or lower
I_Vis.VisMultiplier                  = 300

-- Controls how many circles there are in visualizer 1
I_Vis.VisAmountOfCircles             = 60

-- Controls the width of each bar on visualizer 2
I_Vis.Vis2Width              = 3

-- This will enable the gradient on the left side of the voice box. (true = yes, false = no)
I_Vis.UseGradient                    = false

------------------------------------------------------------------------------
--------Here You Can Enable And Set Player Tags For Groups Or a Person--------
------------------------------------------------------------------------------

-- Do you want to have custom tags for players?
I_Vis.UsePlayerTags                  = true

-- Here is where you may set them, to groups or individual players.
local function GetTagForPlayer(ply)
  local usergroup = ply:GetUserGroup()
  if ply:SteamID() == "STEAM_0:1:30917314" or ply:SteamID() == "STEAM_0:1:45204579" or ply:SteamID() == "STEAM_0:1:81307998" then
    return "Developer" -- Developer tag for me.
  elseif usergroup and usergroup ~= "" and usergroup ~= "user" then
    return (usergroup:gsub("^%l", string.upper))
  elseif ply:IsSuperAdmin() then -- You can use user groups.
    return "SAdmin" -- Admins will have the tag Admin. 
  elseif ply:IsAdmin() then -- You can use user groups.
    return "Admin" -- Admins will have the tag Admin. 
  else
    return "" -- If you want you can set this to guest or w/e
  end
end

------------------------------------------------------------------------------
-----------Here You Can Set A Custom Color For A Player's Visualizer----------
------------------------------------------------------------------------------

-- This is where you can change who gets what colors when they talk. (Visualizer #2 and #4)
-- UsePlayers must be true.
local function GetPlayersColor(ply)
  if ply:SteamID() == "STEAM_0:1:30917314" or ply:SteamID() == "STEAM_0:1:45204579" or ply:SteamID() == "STEAM_0:1:81307998" then
    return HSVToColor( math.sin(0.5*RealTime())*128+127, 1, 1 ) -- This is rainbow.
  elseif ply:IsAdmin() then -- You can use user groups.
    return Color(100,10,10,200) -- Admins will have a dark red color.
  else
    return I_Vis.VisDefaultCol
  end
end

-- If you don't know what a specific function does, you can
-- message me on coderhire or steam and I'll explain the use of
-- it. All variables here in the config can be edited freely.

------------------------------------------------------------------------------
--------------------------------More Advanced---------------------------------
------------------------------------------------------------------------------

-- ADVANCED OPTIONS FOR VISUALIZER #4
I_Vis.VisLinWid                     = 1       -- Width of the line
I_Vis.VisUseRough                   = false   -- Use Rough line
I_Vis.VisOpacity                    = 100     -- Opacity
I_Vis.Vis4Freq                      = 5       -- Frequency (set to 10 or higher for dotted line)

function MODULE.Init(CE)
  local PANEL = {}
  local PlayerVoicePanels = {}
  local ycord = ScrH()-250
  surface.CreateFont( "playername", {font = "DermaLarge",size = 14,weight = 400,blursize = 0,scanlines = 200,antialias = true,underline = false,italic = false} )
  surface.CreateFont( "playerrank", {font = "DermaLarge",size = 70,weight = 400,blursize = 0,scanlines = 200,antialias = true,underline = false,italic = false} )
  surface.CreateFont( "steamid", {font = "DermaLarge",size = 12,weight = 400,blursize = 0,scanlines = 200,antialias = true,underline = false,italic = false} )
  surface.CreateFont( "rank", {font = "DermaLarge",size = 13,weight = 550,blursize = 0,scanlines = 200,antialias = true,underline = false,italic = true} )

  function PANEL:Init()

    self.Audio = vgui.Create("AUDIO_WAVE", self)
    self.Audio:SetSize(250, 52)

    if I_Vis.UseGradient then
      self.Gradient = vgui.Create( "AUDIO_GRAD", self )
      self.Gradient:SetSize(250,52)
    end

    self.LabelName = vgui.Create( "DLabel", self )
    self.LabelName:SetFont( "playername" )
    self.LabelName:Dock( NODOCK )
    self.LabelName:DockMargin( 40, 10, -12, 8 )
    self.LabelName:SetTextColor( I_Vis.VisNameColor )
    self.LabelName:SetPos(48, -5)
    self.LabelName:SetSize(230, 40)

    self.Tag = vgui.Create( "DLabel", self )
    self.Tag:SetFont( "playername" )
    self.Tag:Dock( NODOCK )
    self.Tag:DockMargin( 40, 10, -12, 8 )
    self.Tag:SetTextColor( I_Vis.VisTagColor )
    self.Tag:SetPos(48, 10)
    self.Tag:SetSize(230, 40)

    self.stmid = vgui.Create( "DLabel", self )
    self.stmid:SetFont( "steamid" )
    self.stmid:Dock( NODOCK )
    self.stmid:DockMargin( 40, 0, 0, 0 )
    self.stmid:SetPos(100, -2)
    self.stmid:SetTextColor( I_Vis.VisSteamIDColor )
    self.stmid:SetSize(195, 15)

    if not I_Vis.ShowPlayerModel then
      self.Friend = VGUIRect( 7, 7, 36, 36)
      self.Friend:SetParent(self)
      self.Friend:SetColor(I_Vis.vFriendColor)

      self.Avatar = vgui.Create( "AvatarImage", self )
      self.Avatar:Dock( NODOCK );
      self.Avatar:SetSize( 32, 32 )
      self.Avatar:DockMargin( 3, 1, 1, 0 )
      self.Avatar:SetPos( 9, 9)
    end

    if I_Vis.ShowPlayerModel then
      self.PlayerModel = vgui.Create( "SpawnIcon", self )
      self.PlayerModel:Dock( NODOCK )
      self.PlayerModel:SetSize( 52, 52 )
    end

    self.Color = color_transparent

    self:SetSize( 250, 52 )
    self:DockPadding( 4, 4, 4, 4 )
    self:DockMargin( 2, 2, 2, 2 )
    self:Dock( BOTTOM )
  end

  function PANEL:Setup( ply )

    self.ply = ply
    self.LabelName:SetText( ply:Nick() )
    self.stmid:SetText( ply:SteamID() )
    if not I_Vis.ShowPlayerModel then
      self.Avatar:SetPlayer( ply )
    end
    self.Audio:SetPly(ply)
    if I_Vis.UsePlayerTags then
      self.Tag:SetText(GetTagForPlayer(ply) or "")
    else
      self.Tag:SetText("")
    end

    if I_Vis.ShowPlayerModel then
      self.PlayerModel:SetModel(ply:GetModel())
    end

    self.Color = team.GetColor( ply:Team() )

    self:InvalidateLayout()
  end

  function PANEL:PaintDetour( w, h )

    if ( not IsValid( self.ply ) ) then return end

    if I_Vis.VisIsTTT then
      self.VisCol = self.Color
      self.VisColS = Color(0, 0, 0, 150)
    else
      self.VisCol = I_Vis.VisBorderColor
      self.VisColS = I_Vis.VisBGColor
    end

    draw.RoundedBox( 0, 0, 0, 250, 52, self.VisCol )
    draw.RoundedBox( 0, 1, 1, 244, 50, I_Vis.VisBGColor )

    if I_Vis.ShowPlayerModel then return end
    if self.ply:GetFriendStatus() == "friend" then
      self.Friend:SetColor(I_Vis.vFriendColor)
    else
      self.Friend:SetColor(I_Vis.vNotFriendColor)
    end
  end
  function PANEL:Think( )
    self.Paint = self.PaintDetour
    if ( self.fadeAnim ) then
      self.fadeAnim:Run()
    end

  end

  function PANEL:FadeOut( anim, delta, data )
    if ( anim.Finished ) then
      if ( IsValid( PlayerVoicePanels[ self.ply ] ) ) then
        PlayerVoicePanels[ self.ply ]:Remove()
        PlayerVoicePanels[ self.ply ] = nil
        return
      end
      return end
    self:SetAlpha( 255 - (255 * delta*5) )
  end

  derma.DefineControl( "VoiceNotify", "", PANEL, "DPanel" )

  hook.Add("Think", "ConstantlyOverrideSize", function()
    if not IsValid(g_VoicePanelList) then return end
    g_VoicePanelList:SetSize( 250, ScrH() - 200 )
  end)

  function CreateVoiceVGUI()
    for k ,v in pairs(PlayerVoicePanels)do
      if k == ply then
        return
      end
    end
    g_VoicePanelList = vgui.Create( "DPanel" )
    g_VoicePanelList:ParentToHUD()
    g_VoicePanelList:SetPos( ScrW() - 300, 100 )
    g_VoicePanelList:SetSize( 250, ScrH() - 200 )
    g_VoicePanelList:SetDrawBackground( false )
  end
  hook.Add( "InitPostEntity", "CreateVoiceVGUI", CreateVoiceVGUI )

  local white = surface.GetTextureID("vgui/white")

  function surface.DrawLineEx(x1,y1, x2,y2, w, col)
    w = w or 1

    local dx,dy = x1-x2, y1-y2
    local ang = math.atan2(dx, dy)
    local dst = math.sqrt((dx * dx) + (dy * dy))

    x1 = x1 - dx * 0.5
    y1 = y1 - dy * 0.5

    surface.SetTexture(white)
    surface.SetDrawColor(col)
    surface.DrawTexturedRectRotated(x1, y1, w, dst, math.deg(ang))
  end

  local AUDIO = {}

  AccessorFunc( AUDIO, "m_ply", "Ply")

  function AUDIO:Init()
    self.Vis = {}
    self.StartPos = 244
    self.nextSHOWtime = CurTime()
  end

  function AUDIO:Paint()

    -- Choose color
    if not self:GetPly() or not IsValid(self:GetPly()) or not self:GetPly():IsPlayer() then return end
    self.playervoice = self:GetPly():VoiceVolume()*I_Vis.VisMultiplier
    if I_Vis.VisColorMode == 1 then
      self.c = GetPlayersColor(self:GetPly())
      self.col = Color(self.c.r,self.c.g,self.c.b,I_Vis.VisualizerOpac) or I_Vis.VisDefaultCol
    elseif I_Vis.VisColorMode == 3 then
      self.c = HSVToColor( math.sin(0.3*RealTime())*128+127, 1, 1 )
      self.col = Color(self.c.r,self.c.g,self.c.b,I_Vis.VisualizerOpac) or I_Vis.VisDefaultCol
    elseif I_Vis.VisColorMode == 2 then
      self.lc = Lerp(1-(15/self.playervoice), 120, 0)
      self.c = HSVToColor( self.lc, 1, 1)
      self.col = Color(self.c.r,self.c.g,self.c.b,I_Vis.VisualizerOpac) or I_Vis.VisDefaultCol
    elseif I_Vis.VisColorMode == 4 then
      self.col = Color(math.random(255),math.random(255),math.random(255),I_Vis.VisualizerOpac) or I_Vis.VisDefaultCol
    else
      self.col = I_Vis.VisDefaultCol
    end

    -- Make shit
    if I_Vis.Visualizer == 1 then
      for i = 0, I_Vis.VisAmountOfCircles, 2 do
        surface.DrawCircle( 246, 50, math.Clamp(self:GetPly():VoiceVolume()*I_Vis.VisMultiplier, 0, i), self.col )
      end
    elseif I_Vis.Visualizer == 2 then
      if #self.Vis == 0 then
        self.Move = true
      else
        local x, y = 0, 50
        if type(self.Vis[#self.Vis]) then
          x, y = self.Vis[#self.Vis]:GetPos()
        end
        if x == self.StartPos-(I_Vis.Vis2Width+1) then
          self.Move = true
        end
      end
      if self.Move then
        self.Vis[#self.Vis+1] = VGUIRect( self.StartPos, 52-self.playervoice, I_Vis.Vis2Width, self.playervoice)
        self.Vis[#self.Vis]:SetParent(self)
        self.Vis[#self.Vis]:SetColor(self.col)
        self.Move = false
      end
    elseif I_Vis.Visualizer == 3 then
      self.Vis[#self.Vis+1] = VGUIRect( self.StartPos, 52-self.playervoice, 1, self.playervoice)
      self.Vis[#self.Vis]:SetParent(self)
      self.Vis[#self.Vis]:SetColor(self.col)
    elseif I_Vis.Visualizer == 4 then
      if #self.Vis == 0 then
        point_2 = 50
        self.Move = true
      else
        point_2 = self.SaveP4
        local x, y = 0, 50
        if type(self.Vis[#self.Vis]) then
          x, y = self.Vis[#self.Vis]:GetPos()
        end
        if x <= -I_Vis.Vis4Freq then
          self.Move = true
        end
      end
      if self.Move then
        point_1 = self.StartPos
        point_3 = self.StartPos+I_Vis.Vis4Freq
        point_4 = -self.playervoice + 50
        self.Vis[#self.Vis+1] = vgui.Create("AUDIO_LINE", self)
        self.Vis[#self.Vis]:SetSize(250,52)
        self.Vis[#self.Vis]:SetColor(self.col)
        self.Vis[#self.Vis]:SetP({point_1,point_2,point_3,point_4})
        self.SaveP4 = point_4
        self.Move = false
      end
    elseif I_Vis.Visualizer == 5 then
      local sinewave = math.sin(2*RealTime()) * 25 + 26
      self.Vis[#self.Vis+1] = VGUIRect( self.StartPos, sinewave, 1, 1)
      self.Vis[#self.Vis]:SetParent(self)
      self.Vis[#self.Vis]:SetColor(self.col)
    end
  end

  function AUDIO:Think()
    if I_Vis.Visualizer ~= 1 then
      for _, bar in pairs(self.Vis)do
        if IsValid(bar) then
          local x, y = bar:GetPos() --  or 0,50
          if not vgui.CursorVisible() then
            bar:SetPos(x-3, y)
          else
            bar:SetAlpha(bar:GetAlpha()-1)
          end
          local endpos = 0
          if I_Vis.Visualizer == 4 then
            endpos = -250
          end
          if x < endpos then
            bar:Remove()
          end
        end
      end
    end
  end
  vgui.Register("AUDIO_WAVE", AUDIO)

  local GRAD = {}
  function GRAD:Paint( w, h )
    draw.TexturedQuad{texture = surface.GetTextureID "gui/gradient",color = Color( 25, 25, 25, 255 ),x = 0,y = 0,w = w,h = h}
  end
  vgui.Register("AUDIO_GRAD", GRAD)

  local LINE = {}
  AccessorFunc( LINE, "m_p", "P")
  AccessorFunc( LINE, "m_col", "Color")
  function LINE:Paint()
    if I_Vis.VisUseRough then
      surface.SetDrawColor(self:GetColor())
      surface.DrawLine(self:GetP()[1],self:GetP()[2], self:GetP()[3],self:GetP()[4])
    else
      surface.DrawLineEx(self:GetP()[1],self:GetP()[2], self:GetP()[3],self:GetP()[4], I_Vis.VisLinWid, Color(self:GetColor().r,self:GetColor().g,self:GetColor().b,I_Vis.VisOpacity))
    end
  end
  vgui.Register("AUDIO_LINE", LINE)
end