MODULE.ID = "com.continuum.ttt.dna"
MODULE.Dependencies = { }

MODULE.Name = "TTT DNA"
MODULE.Info = "Tracks DNA scans in TTT to follow target"

MODULE.Init = function(CE)
  local Colors = CE.Colors

  local beep_success = Sound("buttons/blip2.wav")
  --local beep_fail = Sound("buttons/button11.wav")
  local function RecvScan(um)
    local clear = um:ReadBool()
    if clear then
      RADAR.samples = {}
      RADAR.samples_count = 0
      return
    end

    local target_pos = um:ReadVector()
    if not target_pos then return end
    local closest = nil
    for _,target in pairs(player.GetAll()) do
      local dist = target_pos:Distance(target:LocalToWorld(target:OBBCenter()))
      if closest == nil or closest.dist > dist then
        closest = { ent=target, dist=dist}
      end
    end
    for _,target in pairs(ents.GetAll()) do
      if target:IsValid() and (target:GetClass() == "ttt_decoy" or (target:IsRagdoll() and CORPSE.GetPlayerNick(target) ~= nil and CORPSE.GetPlayerNick(target) ~= "")) then
        local dist = target_pos:Distance(target:LocalToWorld(target:OBBCenter()))
        if closest == nil or closest.dist > dist then
          closest = { ent=--[[target:GetClass() == "ttt_decoy" and target:GetOwner() or ]]target, dist=dist}
        end
      end
    end
    if closest ~= nil then
      RADAR.samples = { {pos=target_pos, ent=closest.ent} }
      print("Found DNA target with error of "..tostring(closest.dist))
    else

      RADAR.samples = {
        {pos = target_pos}
      };
    end
    RADAR.samples_count = 1

    surface.PlaySound(beep_success)
  end
  usermessage.Hook("scanresult", RecvScan)
  local sample_scan = surface.GetTextureID("VGUI/ttt/sample_scan")
  function RADAR:DrawRadarPlus()
    if RADAR.samples_count ~= 0 then
      surface.SetTexture(sample_scan)
      surface.SetTextColor(200, 50, 50, 255)
      surface.SetDrawColor(255, 255, 255, 150)
      for k, sample in pairs(RADAR.samples or { }) do
        if sample.ent then
          CE.DrawTarget(sample.ent, 16, 0.5, true, nil, nil, false, 1)
        end
      end
    end
  end
end