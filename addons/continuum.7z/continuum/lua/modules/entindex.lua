MODULE.ID = "com.continuum.entindex"
MODULE.Dependencies = { }

MODULE.Name = "ConCommand EntIndex"
MODULE.Info = "Adds various commands for concommands that take in entindex's"
MODULE.cvars = {
  {name="hacks_autodefusec4", nick="Auto-defuse C4", info="Automatically defuses C4 if not a traitor", default=1},
  {name="hacks_autopickup4", nick="Auto-pickup C4", info="Automatically picks up C4 if not a traitor"}
}
MODULE.Init = function(CE)
  MODULE.AddCmd({Nick="EntIndex", Info="Allows you to run con commands (ex. ttt_c4_pickup or ttt_c4_disarm 1 [cuts wire 1]) with the index of what your looking at", name="hacks_entindex", func = function(ply,name,args)
    if #args ~= 1 and #args ~= 2 then
      chat.AddText(CE.Colors.RED, "Command expects one or two arguments, the concommand to run with the ent index (ex. ttt_c4_pickup or ttt_c4_disarm 1 [cuts wire 1])")
    end
    local lookingAt = util.TraceLine(util.GetPlayerTrace(LocalPlayer())).Entity
    if lookingAt == nil then
      chat.AddText(CE.Colors.RED, "No entity found at crosshairs")
      return
    end
    if #args == 1 then
      RunConsoleCommand(args[1], lookingAt:EntIndex())
    else
      RunConsoleCommand(args[1], lookingAt:EntIndex(), args[2])
    end
  end, autocomplete = function(commandName,args)
    return {"hacks_entindex [concommand name]"}
  end})
  MODULE.AddCmd({ name="hacks_defusec4", nick="Defuse C4", info="Defuses nearby C4 (wire1)", NoArgs=true, func=function()
    for k,v in pairs(ents.FindByClass("ttt_c4")) do
      for i = 1,6 do
        RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), tostring(i))
      end
    end
  end})
  MODULE.AddCmd({ name="hacks_pickupc4", nick="Pickup C4", info="Picks up nearby C4", NoArgs=true, func=function()
    for k,v in pairs(ents.FindByClass("ttt_c4")) do
      RunConsoleCommand("ttt_c4_pickup", v:EntIndex())
    end
  end})
  MODULE.AddCmd({ name="hacks_defusepickc4", nick="Defuse+Pickup C4", info="Defuses + Picks up nearby C4", NoArgs=true, func=function()
    for k,v in pairs(ents.FindByClass("ttt_c4")) do
      for i = 1,6 do
        RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), tostring(i))
      end
      RunConsoleCommand("ttt_c4_pickup", v:EntIndex())
    end
  end})
  timer.Create("C4Defuser", .5, 0, function()
    if CE.IsTTT() and LocalPlayer():GetRole() ~= ROLE_TRAITOR then
      for k,v in pairs(ents.FindByClass("ttt_c4")) do
        if CE.GetConVarBool("hacks_autodefusec4") then
          RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), 1)
        end
        if CE.GetConVarBool("hacks_autopickup4") then
          RunConsoleCommand("ttt_c4_pickup", v:EntIndex())
        end
      end
    end
  end)
end