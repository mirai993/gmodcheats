MODULE.ID = "com.continuum.wallhack"
MODULE.Dependencies = { }

MODULE.Name = "Wallhacks"
MODULE.Info = "Collection of things that draw on the screen things you shouldn't know/see"
MODULE.Init = function(CE)

  local Colors = CE.Colors
  MODULE.AddCVars({
    { name="hacks_eyetrace",nick="Eyetrace", info="Show where players are looking with lasers", default=1, HUD={ Category="ESP", Type="ToggleButton"}},
    { name="hacks_wallhack_info",nick="Wallhack Extra Info", info="Show more info in wallhack", default=0, HUD={ Category="ESP", Type="ToggleButton"}},
    { name="hacks_wallhack",nick="Wallhack", info="Toggles all wallhack items", default=1, HUD={ Category="ESP", Type="ToggleButton"} },
    { name="hacks_wallhack_ents",nick="Wallhack Ents", info="Show special entities", default=1, HUD={ Category="ESP", Type="ToggleButton"} },
    { name="hacks_wallhack_players",nick="Wallhack Players", info="Show all player names, and radar icons", default=1, HUD={ Category="ESP", Type="ToggleButton"} },
    { name="hacks_wallhack_spec",nick="Wallhack spectators", info="Show spectators in the wallhack", default=0, HUD={ Category="ESP", Type="ToggleButton"} },
    { name="hacks_wireframe",nick="Wireframe", info="Draw wireframe for different groups of models", default=0, options={ {  "Wireframe set to ", Colors.GetTrafficColor(0), "off"},{"Wireframe set to ", Colors.GetTrafficColor(50), "weapons" },
      { "Wireframe set to ", Colors.GetTrafficColor(50), "players" }, {"Wireframe set to ", Colors.GetTrafficColor(50), "gamemode"},{"Wireframe set to ", Colors.GetTrafficColor(100), "all"} }, HUD={ Category="ESP", Type="ToggleButton", Min=0, Max=4, Options={"Off", "Weapons", "Players", "Gamemode", "All"}} },
    { name="hacks_laser", nick="Laser", info="Draws a laser out of your gun", default=1, HUD={ Category="ESP", Type="ToggleButton"}},
    { name="hacks_wallhack_maxdist", nick="Max wallhack distance", info="Maximum distance for wallhack, 0 for no max", default=0, NoToggle=true, HUD={ Category="ESP", Type="Slider", Min=0, Max=10000}},
    { name="hacks_chams", nick="Player Chams", info="Mode of chams to use", default=0, options={{"Player Chams set to ", Colors.RED, "off"}, {"Player Chams set to ", Colors.GREEN, " solid"}, {"Player Chams set to ", Colors.GREEN, " skeleton"}, {"Player Chams set to ", Colors.GREEN, " hitbox"}}, HUD={ Category="ESP", Type="ToggleButton", Min=0, Max=3, Options={"Off", "Solid", "Skeleton", "Hitbox"}}},
    { name="hacks_trajectory", nick="Trajectory", info="Traces trajectory of thrown projectiles", default=0, options={{"Projectiles set to ", Colors.RED, "off"}, {"Projectiles set to ", Colors.GREEN, "on"}}, HUD={ Category="ESP", Type="ToggleButton"}},
    { name="hacks_wallhack_filter", nick="Wallhack Filter", Info="Filter out names in the wallhack", default="", NoToggle=true},
    {Nick="ESP Mode", Name="hacks_espmode", Info="ESP Mode (0=off, 1-4=modes)", Default="1",
      HUD={Category="ESP", Type="ToggleButton", Options={"Off", "Radar", "Box", "Corners", "Shaded"}},
      options={{"ESP set to ", Colors.RED, "off"}, {"ESP set to ", Colors.GREEN, "Radar"}, {"ESP set to ", Colors.GREEN, "Boxes"}, {"ESP set to ", Colors.GREEN, "Corners"}, {"ESP set to ", Colors.GREEN, "Shaded"}}
    }
  })
  local indicator   = Material("effects/select_ring")
  local c4warn      = Material("continuum/VGUI/ttt/icon_c4warn")
  local explosionWarn      = Material("continuum/explosion.png")
  local discombobulatorWarn      = Material("continuum/Discombobulator.png")
  local smokeWarn      = Material("continuum/Smoke.png")
  local arrow      = Material("continuum/arrow.png")
  local incendiaryWarn      = Material("continuum/Incendiary.png")
  local wallhackMat = CreateMaterial( "WallhackMat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } );
  local sample_scan = Material("continuum/VGUI/ttt/sample_scan")
  local det_beacon  = Material("continuum/VGUI/ttt/det_beacon")
  local render = render
  local draw = draw
  local surface = surface
  local math = math
  local espbones = {
    { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
    { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
    { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
    { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
    { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
    { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
    { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
    { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
    { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
    { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
    { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
    { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
    { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
    { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
    { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
    { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
    { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
    { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
    { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
    { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
  }
  surface.CreateFont( "WallhackFont", {
    font = "ChatFont",
    size = 15,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = true
  })
  local LocalPlayer = LocalPlayer
  local function GetTracerShootPos( ply )
    local Ent = ply:GetActiveWeapon()
    if (not Ent:IsValid()) then return end
    if ( Ent:IsCarriedByLocalPlayer() and not LocalPlayer():ShouldDrawLocalPlayer() ) then
      local ViewModel = LocalPlayer():GetViewModel()
      if ( ViewModel:IsValid() ) then
        local Attach = ViewModel:LookupAttachment("1")
        if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
        local att = ViewModel:GetAttachment( Attach )
        if ( att ) then
          return att.Pos
        end
      end
    else
      local Attach = Ent:LookupAttachment("1")
      if ( Attach == 0 ) then Attach = Ent:LookupAttachment("muzzle") end
      local att = Ent:GetAttachment( Attach )
      if ( att ) then
        return att.Pos
      end
    end
    return nil

  end

  local badLaser = {
    "weapon_pocket",
    "weapon_crowbar",
    "keys",
    "pocket",
    "weapon_toolgun",
    "weapon_physgun",
    "weapon_camera",
    "camera"
  }
  local function CalculateAngle(initialPosition, targetPosition)
    -- p = 1500
    local dif = targetPosition - initialPosition
    local ply = LocalPlayer()
    --(x/t)^2 + (y/t)^2 + ((z-.5gt^2)/t)^2 = 2250000
    --0 = (-.25g^2)t^4 + (2250000-gz)t^2 - (x^2+y^2+z^2)
    local g=physenv.GetGravity().z
    local x,y,z = dif.z,dif.y,dif.z

    local t = math.sqrt((-(2250000-g*z)+math.sqrt((2250000-g*z)^2-4*(-.25*g^2)*(x^2+y^2+z^2)))/(2*(-.25*g^2)))
    local vox = x/t
    local voy = y/t
    local voz = (z-.5*g*t^2)/t

    local pitch = math.deg(math.acos(voz/1500))
    local yaw = math.deg(math.atan(voy/vox))
    local roll = 0
    return Angle(pitch, yaw, roll)
  end
  local function displacement(so, vo, t, a)
    return .5 * a * t^2 + vo*t + so
  end
  function CE.CalculateTrajectory(initialPosition, initialVelocity, time)
    local gravity = physenv.GetGravity()
    return Vector(displacement(initialPosition.x, initialVelocity.x, time, gravity.x),
      displacement(initialPosition.y, initialVelocity.y, time, gravity.y),
      displacement(initialPosition.z, initialVelocity.z, time, gravity.z))
  end
  local function drawTrajectory(initialPosition, initialVelocity)
    cam.Start3D( EyePos() , EyeAngles())
    local lastPosition = initialPosition
    for time=.01,2,.01 do
      local position = CE.CalculateTrajectory(initialPosition, initialVelocity, time)
      render.SetMaterial( Material( "trails/laser" ) )
      render.DrawBeam(lastPosition, position, 3, 0, 0, Colors.Random())
      --render.DrawBeam(initialPosition, initialPosition + initialVelocity * 10, 3, 0, 0, Colors.BLUE)
      lastPosition = position
    end
    cam.End3D()
  end
  local function drawLaserTrace(ply)
    if not ply:Alive() then return end;
    local wep = ply:GetActiveWeapon()
    local width = ply == LocalPlayer() and 2 or 5
    if( ply:Alive() and IsValid(wep)) then
      if( not table.HasValue( badLaser, wep:GetClass() ) ) then
        cam.Start3D( EyePos() , EyeAngles())
        local StartPos = GetTracerShootPos(ply)
        if StartPos then
          local trace = util.GetPlayerTrace( ply )
          trace.mask = MASK_SHOT
          local tr = util.TraceLine( trace )
          local LaserColor = Color(255,0,0,255)
          if ply == LocalPlayer() then
            if IsValid(tr.Entity) then
              LaserColor = Color(0,255,0,255)
            end
          else
            LaserColor = ply:GetRoleColor()
          end
          local EndPos = tr.HitPos
          render.SetMaterial(Material( "trails/laser" ) )
          render.DrawBeam(StartPos, EndPos, width, 0, 0, LaserColor)
          render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
          EndPos = EndPos -- - LocalPlayer():GetAimVector() * 100
          render.DrawQuadEasy(tr.HitPos, (EyePos() - EndPos), 10, 10, LaserColor, 0 )
        end
        cam.End3D()
      end
    end
  end
  local function drawBomb(bomb, width,height)
    if bomb.GetExplodeTime then
      bomb.t=bomb:GetExplodeTime()
      if bomb.t == 0 then
        bomb.t = nil
      end
    end
    bomb.pos=bomb:GetPos()
    CE.DrawTarget(bomb, 0, 0, true, height, width, false, 1, Color(255,255,255,255))
    if bomb.GetOwner ~= nil and IsValid(bomb:GetOwner()) then
      local o = bomb:GetOwner()
      local scrpos = bomb:GetPos():ToScreen()
      if not CE.IsOffScreen(scrpos) then
        local w, h = surface.GetTextSize(o:Nick())
        surface.SetTextPos(scrpos.x - w / 2, scrpos.y + 43 / 2)
        surface.DrawText(o:Nick())
      end
    end
  end
  local function BlastDamage(ent, ply)
    ply = ply or LocalPlayer()
    local damage = ent:GetDmg()
    local radius = ent:GetRadius()
    return (damage - (ply:GetPos():Distance(ent:GetPos()) / (radius / damage)))
  end
  local function EstimateExplosionDamage(self, ply)
    ply = ply or LocalPlayer()
    local center = self:GetPos()
    local r = (self:GetRadius() or 1000) ^ 2

    -- pre-declare to avoid realloc
    local d = 0.0
    local diff = nil
    local dmg = 0
    local ent = ply
    -- dot of the difference with itself is distance squared
    diff = center - ent:GetPos()
    d = diff:DotProduct(diff)
    if d < r then
      -- deadly up to a certain range, then a quick falloff within 100 units
      d = math.max(0, math.sqrt(d) - 490)
      dmg = -0.01 * (d^2) + 125
    end

    return math.Clamp(dmg, 0, 10000)
  end
  local PM = FindMetaTable("Player") -- Player MetaTable
  function PM:BoomHealth()
    local health = self:Health()
    for _,ent in pairs(ents.FindByClass("ttt_c4")) do
      local time = ent:GetExplodeTime()
      if time ~= 0 then time = time - CurTime() end
      time = math.round(time)
      --chat.AddText("C4 in "..tostring(time).."; last warned at "..tostring(ent.timeFlagged))
      local dist = self:GetPos():Distance(ent:GetPos())
      if dist == 0 then dist = .01 end
      local dmg = math.max(EstimateExplosionDamage(ent, self), 0)
      local fulldmg = math.max((dmg + BlastDamage(ent, self)), 0)
      local IsClose = dist <= 1000
      local IsBehindWall = util.TraceLine({start=self:GetPos(), endpos=ent:GetPos()}).Entity ~= ent
      if IsBehindWall then
        health = health - dmg
      else
        health = health - fulldmg
      end
    end
    return math.round(math.max(health, 0))
  end
  function CE.GetFilteredPlayers()
    local sort = function(a,b) return LocalPlayer():GetPos():Distance(a:GetPos()) > LocalPlayer():GetPos():Distance(b:GetPos()) end
    local players = GetConVarString("hacks_wallhack_filter");
    if players == "0" or players == "" then
      players = player.GetAll()
    else
      players = CE.AutocompletePlayers(GetConVarString("hacks_wallhack_filter"), true)
      if not players or #players < 0 then
        players = player.GetAll()
      end
    end
    table.sort(players, sort)
    return players
  end
  --[[CE.Hook.Add("Tick", "CE.LoadEnts", function()

  end)]]
  local RelevantEnts = { }
  timer.Create("CE.FindEnts", .5, 0, function()
    if not CE.GetConVarBool("hacks_wallhack") then return end
    local _RelevantEnts = { }
    for _,ent in pairs(ents.GetAll()) do
      local isC4 = ent:GetClass() == "ttt_c4" or ent:GetClass() == "sent_c4"
      local isDiscombob = ent:GetClass() == "ttt_confgrenade_proj" or ent:GetClass() == "sent_flashgrenade"
      local isSmoke = ent:GetClass() == "ttt_smokegrenade_proj" or ent:GetClass() == "sent_smokegrenade"
      local isIncen = ent:GetClass() == "ttt_firegrenade_proj" or ent:GetClass() == "sent_explosivegrenade" or ent:GetClass() == "ent_mad_grenade"
      local isTripmine = ent:GetClass() == "npc_tripmine" or ent:GetClass() == "sent_tripmine"
      local isBomb = ent.GetExplodeTime ~= nil or isDiscombob or isSmoke or isIncen or isTripmine
      --[[if isC4 then
      ent.isC4 = true
      end
      if isDiscombob then
      ent.isDiscombob = true
      end
      if isSmoke then
      ent.isSmoke = true
      end
      if isIncen then
      ent.isIncen = true
      end
      if isTripmine then
      ent.isTripmine = true
      end
      if isBomb then
      ent.isBomb = true
      end]]

      if CE.IsDarkRP() and (ent:GetClass():ends("printer") or ent:GetClass() == "spawned_money" or ent:GetClass() == "gmod_cameraprop" or ent:GetClass() == "darkrp_moneypot" or ent.CrackData) then
        table.insert(_RelevantEnts, ent)
        ent.IsGamemodeProp = true
      end
      if isBomb or isC4 or isDiscombob or isSmoke or isIncen  then
        table.insert(_RelevantEnts, ent)
      end
    end
    RelevantEnts = _RelevantEnts
  end)
  CE.Hook.Add( "RenderScreenspaceEffects", "CE.Wallhack", function()
    if not CE.GetConVarBool("hacks_wallhack") then return end
    local includeSpectators = CE.GetConVarBool("hacks_wallhack_spec")
    local LP = LocalPlayer()
    if CE.GetConVarBool("hacks_wallhack_players") then
      if CORPSE ~= nil then
        for k,ent in pairs(ents.FindByClass('prop_ragdoll')) do
          if ent:IsValid() and ent:IsRagdoll() and not ent:GetNoDraw() then
            local nick  = CORPSE.GetPlayerNick(ent)
            local found = CORPSE.GetFound(ent, false)
            if nick ~= nil and nick ~= "" and not found then
              surface.SetDrawColor(255, 255, 255, 255)
              surface.SetTextColor(255, 255, 255, 255)
              CE.DrawRadar(ent, Color(255,255,255,255))
            end
          end
        end
      end
      local players = CE.GetFilteredPlayers()
      for k,v in pairs(players) do
        if v ~= LP then
          local isSpectating = (v.IsSpec and v:IsSpec()) or v:IsSpectating()
          local isLPSpectating = LP.IsSpec and LP:IsSpec()
          if (isSpectating and not isLPSpectating) then
            local tgt = nil
            local scrpos = nil
            local w = 0
            if v.IsSpec ~= nil and v:IsSpec() then
              surface.SetTextColor(220,200,0,120)
              tgt = v:GetObserverTarget()
              if IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == v then
                scrpos = tgt:GetPos():ToScreen()
              else
                scrpos = nil
              end
            end
          end
          if ( v ~= LocalPlayer() and (not isSpectating or includeSpectators)) then
            local role = v:GetHackRoleSpec()
            local textColor = v:GetRoleColorSpec()
            surface.SetDrawColor(textColor.r,textColor.g,textColor.b, 255)
            surface.SetTextColor(textColor.r,textColor.g,textColor.b, 255)
            CE.DrawRadar(v, textColor)
            -- Draw their player name information here
            if (not isSpectating or CE.GetConVarBool("hacks_wallhack_spec")) then
              local Position = (v:GetPos() + Vector( 0,0,80 )):ToScreen()
              local Health = math.Clamp(v:Health(), 0, 100)
              local textColor = Colors.GetTrafficColor(Health)
              textColor = Color(textColor.r, textColor.g, textColor.b, 200)
              local txt = CE.IsMurder() and v:GetBystanderName() or v:Name()
              if CE.IsTTT() and v:GetNWBool("disguised", false) then txt=txt.." (DISGUISED)" end
              if v:GetTag() then txt = txt .. " "..v:GetTag() end
              draw.DrawText( txt, "WallhackFont", Position.x, Position.y, textColor, 1 )
            end
          end
        end
      end
    end

    -- If you want to disable monitors, just remove them...
    for name,data in pairs(CE.Session.Monitors) do
      local ent = data.ent
      if not IsValid(ent) then
        CE.Session.Monitors[name] = nil
      else
        local surface = surface
        local text = "Monitor '"..data.Name.."'"
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetTextColor(255, 255, 255, 255)
        CE.DrawRadar(data.ent, Color(255,255,255))
        local scrpos = data.ent:GetPos():ToScreen()
        local w, h = surface.GetTextSize(text)
        surface.SetTextPos(scrpos.x - w / 2, scrpos.y + 22 / 2)
        surface.DrawText(text)
      end
    end
    if CE.GetConVarBool("hacks_wallhack_ents") then
      surface.SetTextColor(200, 55, 55, 220)
      for _,ent in pairs(RelevantEnts) do
        --if CE.IsDarkRP() and (ent:GetClass():ends("printer") or ent:GetClass() == "spawned_money" or ent:GetClass() == "gmod_cameraprop" or ent:GetClass() == "darkrp_moneypot")  then
        if IsValid(ent) then
          if ent.IsGamemodeProp then
            local surface = surface
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetTextColor(255, 255, 255, 255)
            CE.DrawRadar(ent, Color(255,255,255), 4)
            local text = nil
            if ent:GetClass() == "gmod_cameraprop" and IsValid(ent:GetPlayer()) then
              text = "Camera [" .. (ent:GetPlayer():GetViewEntity() == ent and "Active" or "Off") .. "]"
            elseif ent.CrackData then
              text = "Keypad"
              if ent.CrackData.Pass then text = text .. " ["..ent.CrackData.Pass.."]" end
            elseif ent.dt then
              if ent.dt.amount then
                text = "$"..(ent.dt.amount or "0")
              elseif ent.dt.Money then
                text = ent:GetPlayerName().."'s MP [$"..ent.dt.Money.."]"
              else
                local nick = ent.dt.owning_ent
                if not nick or not nick.Nick then
                  nick = "?"
                else
                  nick = nick:Nick()
                end
                nick = "["..nick.."]"
                if ent:GetNWInt("PrintA",-1) >= 0 then
                  text = " $"..(ent:GetNWInt("PrintA",0) or "0").." "..(ent.PrintName or "?")..nick
                elseif ent:GetNWInt("StoredAmount",-1) >= 0 then
                  text = " $"..(ent:GetNWInt("StoredAmount",0) or "0").." "..(ent.PrintName or "?")..nick
                else
                  text = (ent.PrintName or "?")..nick
                end
                if ent:GetNWInt("PrintB", -1) >= 0 then
                  text = ent:GetNWInt("PrintB") .. "HP "..text
                end
              end
            end
            if text then
              local scrpos = ent:GetPos():ToScreen()
              local w, h = surface.GetTextSize(text)
              surface.SetTextPos(scrpos.x - w / 2, scrpos.y + 43 / 2)
              surface.DrawText(text)
            end
          end
          local isC4 = ent:GetClass() == "ttt_c4" or ent:GetClass() == "sent_c4"
          local isDiscombob = ent:GetClass() == "ttt_confgrenade_proj" or ent:GetClass() == "sent_flashgrenade"
          local isSmoke = ent:GetClass() == "ttt_smokegrenade_proj" or ent:GetClass() == "sent_smokegrenade"
          local isIncen = ent:GetClass() == "ttt_firegrenade_proj" or ent:GetClass() == "sent_explosivegrenade" or ent:GetClass() == "ent_mad_grenade"
          local isTripmine = ent:GetClass() == "npc_tripmine" or ent:GetClass() == "sent_tripmine"
          local isBomb = ent.GetExplodeTime ~= nil or isDiscombob or isSmoke or isIncen or isTripmine
          if (isBomb or isC4 or isDiscombob or isSmoke or isIncen) then
            local width = 24
            local height = 24
            if isC4 and ent.GetExplodeTime then
              surface.SetMaterial(c4warn)
              surface.SetDrawColor(255, 255, 255, 200)
              local time = ent:GetExplodeTime()
              if time ~= 0 then time = time - CurTime() end
              time = math.round(time)

              local dist = LP:GetPos():Distance(ent:GetPos())
              if dist == 0 then dist = .01 end
              local dmg = EstimateExplosionDamage(ent)
              local fulldmg = (dmg + BlastDamage(ent))
              local IsClose = dist <= 1000
              local IsBehindWall = util.TraceLine({start=LP:GetPos(), endpos=ent:GetPos()}).Entity ~= ent
              if ent:GetArmed() and ent.timeFlagged ~= time and time <= 20 and IsClose then
                local hpleft = math.round(LP:Health() - dmg)
                local hpleftfull = math.round(LP:Health() - fulldmg)
                if IsBehindWall then
                  if LP:Health() <= dmg then
                    chat.AddText(Colors.RED, "You will be killed by C4 if you don't run, you'll take "..dmg.." damage! "..time.." seconds left!")
                  else
                    chat.AddText(Colors.RED, "You're near C4, you will drop to "..hpleft.." health! "..time.." seconds left!")
                  end
                else
                  if LP:Health() <= fulldmg then
                    chat.AddText(Colors.RED, "You're near C4, get behind a wall or else you will die by taking ", tostring(fulldmg), " damage! "..time.." seconds left!")
                  else
                    chat.AddText(Colors.RED, "You're near C4, you'll drop to "..hpleftfull.." health, or "..hpleft.." if you get behind a wall! "..time.." seconds left!")
                  end
                end
                ent.timeFlagged = time
              end
            elseif isIncen then
              surface.SetMaterial(incendiaryWarn)
              surface.SetDrawColor(255, 255, 255, 200)
              width = 13
              height = 20
            elseif isDiscombob then
              surface.SetMaterial(discombobulatorWarn)
              surface.SetDrawColor(255, 255, 255, 200)
              width = 15
              height = 15
            elseif isSmoke then
              surface.SetMaterial(smokeWarn)
              surface.SetDrawColor(255, 255, 255, 200)
              width = 13
              height = 20
            elseif isTripmine then
              surface.SetMaterial(c4warn)
              surface.SetDrawColor(255, 255, 255, 200)
              ent.nick = "Tripmine"
            elseif isBomb then
              surface.SetMaterial(explosionWarn)
              surface.SetDrawColor(255, 100, 0, 75)
            end
            if (isC4 and (not LP.GetRole or LP:GetRole() ~= ROLE_TRAITOR)) or (not isC4 and isBomb) then
              drawBomb(ent,width,height)
            end
          end
        end
      end
    end
  end)
  CE.Hook.Add("PostDrawTranslucentRenderables","CE.DrawEyetraces", function()
    if CE.GetConVarBool("hacks_eyetrace") then
      for k,ply in pairs (player.GetAll()) do
        if (ply ~= LocalPlayer() and (not ply.IsSpec or not ply:IsSpec())) then
          drawLaserTrace(ply)
        end
      end
    end
    if CE.GetConVarBool("hacks_laser") then
      drawLaserTrace(LocalPlayer())
    end
    if CE.GetConVarBool("hacks_trajectory") and IsValid(LocalPlayer():GetActiveWeapon()) then
      if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_mad_knife" then
        local ply = LocalPlayer()
        local vel = ply:GetAimVector() * 1500
        local pos = ply:GetShootPos()
        pos = pos + ply:GetForward() * 5
        pos = pos + ply:GetRight() * 9
        pos = pos + ply:GetUp() * -5
        drawTrajectory(pos,vel)
      elseif LocalPlayer():GetActiveWeapon():GetClass() == "weapon_throwingaxe" then
        local ply = LocalPlayer()
        local vel = ply:GetAimVector() * 1500
        local pos = ply:GetShootPos()
        pos = pos + ply:GetForward() * 5
        pos = pos + ply:GetRight() * 9
        pos = pos + ply:GetUp() * -5
        drawTrajectory(pos,vel)
      elseif LocalPlayer():GetActiveWeapon():GetClass() == "weapon_throwingknife" then
        local ply = LocalPlayer()
        local vel = ply:GetAimVector() * 1500
        local pos = ply:GetShootPos()
        pos = pos + ply:GetForward() * 5
        pos = pos + ply:GetRight() * 9
        pos = pos + ply:GetUp() * -5
        drawTrajectory(pos,vel)
      end
    end
  end)
  local WallhackItems = { } -- List of wireframe objects
  local shift = 0 -- Position of the arrow
  local dshift = 1
  local dratio = .05
  CE.Hook.Add("RenderScreenspaceEffects", "CE.WallhackMatHook", function()
    local wireframeMode = GetConVarNumber("hacks_wireframe")
    local playerespMode = GetConVarNumber("hacks_chams")
    if (playerespMode == 1)  then
      cam.Start3D( EyePos(),EyeAngles() );
      render.SuppressEngineLighting( true );
      for _, ply in pairs(player.GetAll()) do
        if ply:Alive() and ply ~= LocalPlayer() then
          local color = ply:GetRoleColorSpec() or Colors.WHITE
          local inverse = Color(Colors.AddToColor( color.r, 150 ), Colors.AddToColor( color.g, 150 ), Colors.AddToColor( color.b, 150 ), 255)
          render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
          render.MaterialOverride( wallhackMat );
          ply:DrawModel();
          render.SetColorModulation( inverse.r/255, inverse.g/255, inverse.b/255, 1 );
          if (IsValid( ply:GetActiveWeapon() )) then
            ply:GetActiveWeapon():DrawModel()
          end
          if (CE.IsTTT() and ply:IsTraitor()) then
            render.SetColorModulation( 1, 0, 0, 1 );
          else
            render.SetColorModulation( 1, 1, 1, 1 );
          end
          render.MaterialOverride();
          render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
          ply:DrawModel();
          render.SetModelLighting( 1, 0, 0, 0, 0 );
        end
      end
      render.SuppressEngineLighting( false );
      cam.End3D();
    elseif playerespMode == 2 then
      for _,e in pairs(player.GetAll()) do
        if e ~= LocalPlayer() and e:Alive() then
          for k, v in pairs( espbones ) do
            local sBone = e:LookupBone( v.S )
            local eBone = e:LookupBone( v.E )
            if sBone and eBone then
              local sPos, ePos = e:GetBonePosition( sBone ):ToScreen(), e:GetBonePosition( eBone ):ToScreen()
              if e:IsPlayer() and not e:IsNPC() then
                surface.SetDrawColor(team.GetColor(e:Team()))
              end
              surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
            end
          end
        end
      end
    end
    -- Bouncing arrows
    --print(#WallhackItems)
    if table.GetFirstKey(WallhackItems) ~= nil then
      dratio = 1
      if shift < .1 then dratio = .7 end
      shift = shift + dshift * dratio
      if shift > 1 then dshift = -.05 end
      if shift < 0 then dshift = .05 end
      for k,v in pairs(WallhackItems) do
        if k:IsValid() then
          surface.SetMaterial(arrow)
          surface.SetDrawColor(255, 255, 255, 200)
          local sz = math.Clamp(10000 / LocalPlayer():GetPos():Distance(k:GetPos()), 0, 32)
          local pos = k:GetPos()+Vector(0,0,30+shift*10)
          if k:IsPlayer() then pos = pos + Vector(0,0,50) end
          CE.DrawTarget(pos, 0, 0, false, sz, sz, true, 1, Color(255,255,255,200))
        end
      end
    end
  end)
  --PostDrawOpaqueRenderables
  local matColor	= Material( "model_color" )
  local mat_Copy	= Material( "pp/copy" )
  local mat_Add	= Material( "pp/add" )
  local mat_Sub	= Material( "pp/sub" )
  local rt_Stencil	= render.GetBloomTex0()
  local rt_Store		= render.GetScreenEffectTexture( 0 )
  local ScaleBrightness, ScaleDarkness
  function ScaleBrightness(col, brightness)
    if brightness == 0 then return Color(255,255,255) end
    brightness = 1/brightness
    if brightness > 1 then return ScaleDarkness(col,brightness) end
    return Color(255-((255-col.r)*brightness), 255-((255-col.g)*brightness), 255-((255-col.b)*brightness), col.a)
  end
  function ScaleDarkness(col, brightness)
    if brightness == 0 then return Color(0,0,0) end
    brightness = 1/brightness
    if brightness > 1 then return ScaleBrightness(col,brightness) end
    return Color(col.r*brightness, col.g*brightness, col.b*brightness, col.a)
  end
  local Entity = FindMetaTable("Entity")
  if not Entity._GetColor then
    Entity._GetColor = Entity.GetColor
  end
  if not Entity._SetColor then
    Entity._SetColor = Entity.SetColor
  end
  if not Entity._GetMaterial then
    Entity._GetMaterial = Entity.GetMaterial
  end
  if not Entity._SetMaterial then
    Entity._SetMaterial = Entity.SetMaterial
  end
  function Entity:SetColor(color)
    if Entity:UpdateWallhackColor() then
      self.QueuedColor=color
      return false
    end
    self:_SetColor(color)
  end
  function Entity:SetMaterial(material)
    if Entity:UpdateWallhackColor() then
      self.QueuedMaterial=material
      return false
    end
    self:_SetMaterial(material)
  end
  function Entity:UpdateWallhackColor()
    if not self:IsValid() then return false end
    local wep = self:GetClass():starts("weapon_") or self:GetClass():starts("item_ammo_") or self:GetClass():starts("item_box_") or self:GetClass():ends("_money_printer")or self:GetClass():ends("moneyprinter");
    local door = self:GetClass():find("door") ~= nil;
    local body = self:GetClass() == "prop_ragdoll" and not self:GetNoDraw();
    local gamemode = (CE.IsDarkRP() and (self:GetClass():ends("moneyprinter") or self:GetClass():ends("_money_printer") or self:GetClass():starts("spawned_") or self:GetClass():find("gunlab") or self:GetClass():find("keypad"))) or (CE.IsTTT() and (self:GetClass() == "ttt_health_station")) or (CE.IsStronghold() and self:GetClass() == "sent_spawnpoint")
    local wireframeMode = GetConVarNumber("hacks_wireframe")
    local opt1 = (wireframeMode == 1 or wireframeMode == 4) and wep
    local opt2 = (wireframeMode == 2 or wireframeMode == 4) and body
    local opt3 = (wireframeMode == 3 or wireframeMode == 4) and gamemode
    local option = opt1 and 1 or opt2 and 2 or opt3 and 3 or -1
    if (self.Primary == nil or self.Owner ~= LocalPlayer()) and (opt1 or opt2 or opt3)  then
      local color = Color(255,255,255)
      if wep then
        color = Colors.GetTrafficColor(25)
      elseif self:GetClass() == "player" then
        color = self:GetRoleColorSpec()
      end
      if not self.QueuedColor then
        self.QueuedColor = self:GetColor()
      end
      if not self.QueuedMaterial then
        self.QueuedMaterial = self:GetMaterial()
      end
      self:_SetColor(color)
      self:_SetMaterial("hlmv/debugmrmwireframe")
      return true
    end
    return false
  end
  timer.Create("CE.WireFrame", 1, 0, function()
    if GetConVarNumber("hacks_wireframe") == 0 then
      for ent,_ in pairs(WallhackItems) do
        if IsValid(ent) then
          if ent.QueuedColor then
            ent:SetColor(ent.QueuedColor)
            ent.QueuedColor=nil
          end
          if ent.QueuedMaterial then
            ent:SetMaterial(ent.QueuedMaterial)
            ent.QueuedMaterial=nil
          end
        end
      end
      WallhackItems = { }
      return
    end
    local LocalWallhackItems = { }
    for _, ent in pairs(ents.GetAll()) do
      if ent:IsValid() then
        local IsWallhack = ent:UpdateWallhackColor()
        if IsWallhack then
          LocalWallhackItems[ent] = { material="hlmv/debugmrmwireframe" }
        else
          if ent.QueuedColor then
            ent:SetColor(ent.QueuedColor)
            ent.QueuedColor=nil
          end
          if ent.QueuedMaterial then
            ent:SetMaterial(ent.QueuedMaterial)
            ent.QueuedMaterial=nil
          end
        end
      end
    end
    WallhackItems = LocalWallhackItems
  end)
end