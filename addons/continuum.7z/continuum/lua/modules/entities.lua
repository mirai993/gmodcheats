MODULE.ID = "com.continuum.entities"
MODULE.Dependencies = { }
MODULE.Enabled = false

MODULE.Name = "Entities"
MODULE.Info = "Allows for entity mods to be placed in modules/entities folder"
-- TODO: Finish converting effects to entities, and reenable
MODULE.Init = function(CE)
  local files,folders = file.Find( "lua/modules/entities/*", "MOD" )
  for key,file in pairs(files) do
    local simpleName = string.StripExtension(file)
    ENT = { }
    ENT.Folder = "modules/entities/"..simpleName
    function LoadEntity(name)
      ENT = effects.EffectList[name]
    end
    local Cancel = false
    function RequireEntity(name)
      ENT = effects.EffectList[name]
      if not ENT then Cancel = true end
      return not Cancel
    end
    CE.RevealGlobal()
    CE.include("modules/effects/"..file)
    CE.HideGlobal()
    if not Cancel then
      effects.Register(ENT, simpleName)
    end
    RequireEffect = nil
    LoadEffect = nil
    ENT = nil
  end
  for key,folder in pairs(folders) do
    local luaFiles = file.Find("lua/modules/effects/"..folder.."/*.lua", "MOD")
    ENT = { }
    ENT.Folder = "modules/effects/"..folder
    function LoadEffect(name)
      Effect = effects.EffectList[name]
    end
    local Cancel = false
    function RequireEffect(name)
      Effect = effects.EffectList[name]
      if not Effect then Cancel = true end
      return not Cancel
    end
    for key, val in pairs( luaFiles ) do
      CE.RevealGlobal()
      CE.include( "modules/effects/"..folder.."/"..val )
      CE.HideGlobal()
    end
    if not Cancel then
      effects.Register(ENT, folder)
      print("Added effect ", folder)
    end
    RequireEffect = nil
    LoadEffect = nil
    ENT = nil
  end
end