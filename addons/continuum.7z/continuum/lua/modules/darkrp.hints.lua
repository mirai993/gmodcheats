MODULE.ID = "com.continuum.drp.hints"
MODULE.Dependencies = { }

MODULE.Name = "DarkRP Hints"
MODULE.Info = "Collection of hints for different entities"

MODULE.Init = function(CE)
  local GM = GAMEMODE
  
  local util = util
  local render = render
  local draw = draw
  local surface = surface
  
  local ClassHint = {
  	prop_ragdoll = {
  		name= "corpse",
  		hint= "corpse_hint",
  
  		fmt = function(ent, txt) return txt end
  	}
  
  };
  
  -- Basic access for servers to add/modify hints. They override hints stored on
  -- the entities themselves.
  function GM:AddClassHint(cls, hint)
  	ClassHint[cls] = table.Copy(hint)
  end
  
  
  ---- "T" indicator above traitors
  
  local indicator_mat = Material("VGUI/ttt/sprite_traitor")
  local indicator_col = Color(255, 255, 255, 130)
  
  local client, plys, ply, pos, dir
  local GetPlayers = player.GetAll
  
  local propspec_outline = Material("models/props_combine/portalball001_sheet")
  
  ---- Crosshair affairs
  
  surface.CreateFont("TargetIDSmall2", {font = "TargetID",
  	size = 16,
  	weight = 1000})
  
  local minimalist = CreateConVar("ttt_minimal_targetid", "0", FCVAR_ARCHIVE)
  
  local magnifier_mat = Material("icon16/magnifier.png")
  local ring_tex = surface.GetTextureID("effects/select_ring")
  
  local rag_color = Color(200,200,200,255)
  local names = {
  	gmod_button="Button",
  	gmod_cameraprop="Camera",
  	gmod_rtcameraprop="RT Camera",
  	keypad="Keypad",
  	darkrp_moneypot="Money Pot"
  }
  function GM:HUDDrawTargetID()
  	local client = LocalPlayer()
  
  	local trace = client:GetEyeTrace(MASK_SHOT)
  	local ent = trace.Entity
  	if (not IsValid(ent)) or ent.NoTarget or (ent.IsDoor and ent:IsDoor()) then return end
  	-- some bools for caching what kind of ent we are looking at
  	local target_traitor = false
  	local target_detective = false
  	local target_corpse = false
  
  	local text = nil
  	local color = CE.Colors.WHITE
  
  	-- if a vehicle, we identify the driver instead
  	if IsValid(ent:GetNWEntity("ttt_driver", nil)) then
  		ent = ent:GetNWEntity("ttt_driver", nil)
  
  		if ent == client then return end
  	end
  
  	local cls = ent:GetClass()
  	local minimal = minimalist:GetBool()
  	local hint = (not minimal) and (ent.TargetIDHint or ClassHint[cls])
  	if not hint and cls == "spawned_weapon" and ent.dt then
  		hint = { }
  		hint.name = ent.PrintName or ent:GetClass()
  		hint.hint = ent.dt.owning_ent and ("Owner: "..ent.dt.owning_ent:Nick()) or nil
  		if ent.Primary ~= nil and ent.Primary.Delay ~= 0 then
  			local dps = ent.Primary.Damage / ent.Primary.Delay
  			if ent.Primary.NumberofShots ~= nil then
  				dps = dps * (ent.Primary.NumberofShots)
  			end
  			if ent.Primary.Spread ~= nil then
  				dps = dps * 10 / ent.Primary.Spread
  			end
  			dps = math.round(dps, 2)
  			hint.hint2 = dps .." dps"
  		end
  	end
  	if not hint and ent.DoorData and LocalPlayer():EyePos():Distance(ent:GetPos()) > 195 and ent.IsDoor and ent:IsDoor() then
  		hint = { }
  		hint.name = "Door"
  		hint.hint = (IsValid(ent.DoorData.Owner) and "Owned by: ".. ent.DoorData.Owner:Nick()) or "No owner"
  		hint.hint2 = ent.DoorData.title
  	end
  	if not hint and cls == "gmod_cameraprop" then
  		hint = { }
  		hint.name = "Camera"
  		hint.hint = ent:GetPlayer():IsValid() and ent:GetPlayer():Nick() or "No Owner"
  		local IsOn = ent:GetPlayer():IsValid() and ent:GetPlayer():GetViewEntity() == ent
  		hint.hint2 = IsOn and "ACTIVE" or "Off"
  		hint.hint2clr = IsOn and CE.Colors.GREEN or CE.Colors.RED
  	elseif ent.dt and ent.dt.On ~= nil then
  		hint = { }
  		hint.name = ent.GetPlayerName and ent:GetPlayerName() or "Someone" .. "'s "..(names[ent:GetClass()] or ent.PrintName)
  		hint.hint = ent.dt.On and "Active" or "Off"
  		hint.hintclr = ent.dt.On and CE.Colors.GREEN or CE.Colors.RED
  		hint.hint2 = ent.dt.IsToggle and "Toggle" or "Hold"
  		if ent.dt.Key then
  			hint.hint2 = hint.hint2 .. "s '" .. input.GetKeyName(ent.dt.Key).."'"
  		end
  		hint.hint2clr = CE.Colors.GREEN
  	end
  	if ent.dt and ent.dt.Money then
  		hint = { }
  		hint.name = ent:GetPlayerName() .. "'s "..(names[ent:GetClass()] or ent.PrintName)
  		hint.hint = "$"..ent.dt.Money
  		hint.hintclr = CE.Colors.GREEN
  	end
  	if not hint and ent.dt and ent.dt.PrintA then
  		hint = { }
  		hint.name = ent.PrintName
  		hint.hint = ent.dt.owning_ent and ent.dt.owning_ent.Nick and ("Owner: "..ent.dt.owning_ent:Nick()) or nil
  		hint.hintclr = CE.Colors.YELLOW
  		hint.hint2 = "$"..ent.dt.PrintA
  		hint.hint2clr = CE.Colors.GREEN
  	end
  	if not hint and ent.dt and ent.dt.owning_ent then
  		hint = { }
  		hint.name = names[ent:GetClass()] or ent.PrintName
  		hint.hint = ent.dt.owning_ent and ent.dt.owning_ent.Nick and ("Owner: "..ent.dt.owning_ent:Nick()) or nil
  		hint.hintclr = CE.Colors.YELLOW
  	end
  	if ent:IsPlayer() then
  		hint = { }
  		hint.name = ent:Nick()
  		hint.hint = ent:Health()..""
  		hint.hintclr = CE.Colors.GetTrafficColor(ent:Health())
  		hint.hint2 = ent:GetTeamName()
  		hint.hint2clr = ent:GetRoleColor()
  	elseif not hint then
  		-- Not something to ID and not something to hint about
  		return
  	end
  
  	local x_orig = ScrW() / 2.0
  	local x = x_orig
  	local y = ScrH() / 2.0
  
  	local w, h = 0,0 -- text width/height, reused several times
  
  	if target_traitor or target_detective then
  		surface.SetTexture(ring_tex)
  
  		if target_traitor then
  			surface.SetDrawColor(255, 0, 0, 200)
  		else
  			surface.SetDrawColor(0, 0, 255, 220)
  		end
  		surface.DrawTexturedRect(x-32, y-32, 64, 64)
  	end
  
  	y = y + 30
  	local font = "TargetID"
  	surface.SetFont( font )
  
  	-- Draw main title, ie. nickname
  	if text then
  		w, h = surface.GetTextSize( text )
  
  		x = x - w / 2
  
  		draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
  		draw.SimpleText( text, font, x, y, color )
  
  		-- for ragdolls searched by detectives, add icon
  		if ent.search_result then
  			-- if I am detective and I know a search result for this corpse, then I
  			-- have searched it or another detective has
  			surface.SetMaterial(magnifier_mat)
  			surface.SetDrawColor(200, 200, 255, 255)
  			surface.DrawTexturedRect(x + w + 5, y, 16, 16)
  		end
  
  		y = y + h + 4
  	end
  
  	-- Minimalist target ID only draws a health-coloured nickname, no hints, no
  	-- karma, no tag
  	if minimal then return end
  
  	-- Draw subtitle: health or type
  	local clr = hint.nameclr or rag_color
  	if hint then
  		text = hint.name
  	else
  		return
  	end
  	font = "TargetIDSmall2"
  
  	surface.SetFont( font )
  	w, h = surface.GetTextSize( text )
  	x = x_orig - w / 2
  
  	draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
  	draw.SimpleText( text, font, x, y, clr )
  
  	font = "TargetIDSmall"
  	surface.SetFont( font )
  
  	-- Draw key hint
  	clr =  hint.hintclr or CE.Colors.LGRAY
  	if hint and hint.hint then
  		if not hint.fmt then
  			text = hint.hint
  		else
  			text = hint.fmt(ent, hint.hint)
  		end
  
  		w, h = surface.GetTextSize(text)
  		x = x_orig - w / 2
  		y = y + h + 5
  		draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
  		draw.SimpleText( text, font, x, y, clr )
  	end
  
  
  	clr =  hint.hint2clr or rag_color
  	if hint and hint.hint2 then
  		text = hint.hint2
  
  		w, h = surface.GetTextSize( text )
  		y = y + h + 5
  		x = x_orig - w / 2
  
  		draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
  		draw.SimpleText( text, font, x, y, clr )
  	end
  end
end