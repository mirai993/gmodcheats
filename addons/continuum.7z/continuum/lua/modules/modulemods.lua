MODULE.ID = "com.continuum.modulemods"
MODULE.Dependencies = { }

MODULE.Name="Module mods"
MODULE.Info="Modifications to modules"
MODULE.cvars = { {name="hacks_verbose_console", nick="Verbose ConCommands", info="Logs commands to CE.Console", HUD={ Category="Utility", Type="ToggleButton"}}, {name="hacks_verboseumsg", nick="Verbose UMSG", info="Logs umsgs to CE.Console", HUD={ Category="Utility", Type="ToggleButton"}}, {name="hacks_verbosenet", nick="Verbose Net", info="Logs net messages to CE.Console", HUD={ Category="Utility", Type="ToggleButton"}} }

MODULE.Init = function(CE)
  local GM = GAMEMODE
  local Colors = CE.Colors
  local Hooks = usermessage.GetTable()
  if not gamemode._Call then gamemode._Call = gamemode.Call end
  function gamemode.Call(...)
    local args = {...}

    -- Let's give our STOOLs a chance to decide whether or not they can tool!
    if args[1] == "CanTool" and SWEP then
      local SWEP = weapons.GetStored("gmod_tool")
      local Tool = SWEP.Tool[args[4]]
      local caller = debug.getinfo(2).name
      local mode
      if caller then
        if caller:starts("_") then caller = caller:sub(2) end
        if caller == "PrimaryAttack" then mode = "LeftClick"
        elseif caller == "SecondaryAttack" then mode = "RightClick"
        elseif caller == "Reload" then mode = "Reload" end
      elseif debug.getinfo(2).linedefined == 261 then
        mode = "RightClick"
      elseif debug.getinfo(2).linedefined == 123 then
        mode = "Reload"
      end
      if mode and Tool['Can'..mode] then
        return Tool['Can'..mode](Tool, args[3].Entity)-- self, ent
      end

      if Tool.CanTool then return Tool:CanTool(args[3].Entity, caller) end
    end
    return gamemode._Call(...)
  end

  if not surface._SetFont then surface._SetFont = surface.SetFont end
  surface.currentFont = "Default"
  function surface.SetFont(fontName)
    surface.currentFont = fontName
    surface._SetFont(fontName)
  end
  function surface.GetFont()
    return surface.currentFont
  end

  function usermessage.GetTable()

    return Hooks

  end
  if Bank and Bank.GUI then
    if not Bank._GUI then Bank._GUI = Bank.GUI end
    function Bank.GUI()
      TempGlobal = debug.getinfo(2)
      PrintTable(debug.getinfo(2))
      Bank._GUI()
    end
  end

  function usermessage.Hook( messagename, func, ... )
    Hooks[ messagename ] = {}

    Hooks[ messagename ].Function 	= func
    Hooks[ messagename ].PreArgs	= {...}

  end
  local names = { }
  local msg = FindMetaTable("bf_read")

  if not msg._ReadAngle then msg._ReadAngle = msg.ReadAngle end
  if not msg._ReadBool then msg._ReadBool = msg.ReadBool end
  if not msg._ReadChar then msg._ReadChar = msg.ReadChar end
  if not msg._ReadEntity then msg._ReadEntity = msg.ReadEntity end
  if not msg._ReadFloat then msg._ReadFloat = msg.ReadFloat end
  if not msg._ReadEntity then msg._ReadEntity = msg.ReadEntity end
  if not msg._ReadLong then msg._ReadLong = msg.ReadLong end
  if not msg._ReadShort then msg._ReadShort = msg.ReadShort end
  if not msg._ReadString then msg._ReadString = msg.ReadString end
  if not msg._ReadVector then msg._ReadVector = msg.ReadVector end
  if not msg._ReadVectorNormal then msg._ReadVectorNormal = msg.ReadVectorNormal end

  local list = {"DarkRP_Chat", "DarkRP_PlayerVar", "anim_keys", "anim_sayhi"}
  msg.ReadAngle = function(self)
    local val = self:_ReadAngle()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Angle: "..tostring(val))
    end
    return val
  end
  msg.ReadBool = function(self)
    local val = self:_ReadBool()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Bool: "..tostring(val))
    end
    return val
  end
  msg.ReadEntity = function(self)
    local val = self:_ReadEntity()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Entity: "..tostring(val))
    end
    return val
  end
  msg.ReadFloat = function(self)
    local val = self:_ReadFloat()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Float: "..tostring(val))
    end
    return val
  end
  msg.ReadString = function(self)
    local val = self:_ReadString()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".String: "..tostring(val))
    end
    return val
  end
  msg.ReadVector = function(self)
    local val = self:_ReadVector()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Vector: "..tostring(val))
    end
    return val
  end
  msg.ReadVectorNormal = function(self)
    local val = self:_ReadVectorNormal()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".VectorNormal: "..tostring(val))
    end
    return val
  end
  msg.ReadLong = function(self)
    local val = self:_ReadLong()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Long: "..tostring(val))
    end
    return val
  end
  --[[
  Scratch Pools:

  ]]
  local ScratchResults = {
    "Lose",
    "Double money",
    "Lose",
    "Lose",
    "Double money",
    "Lose",
    "Lose",
    "Lose",
    "Double money",
    "Lose"
  }
  if not _ScratchPool then _ScratchPool = usermessage.GetTable().ScratchPool end
  if _ScratchPool then
    local hacks_scratching = false
    usermessage.Hook("ScratchPool", function(msg)
      if hacks_scratching then
        local val = msg:ReadShort()
        chat.AddText("Got pool ", tostring(val), ", result: ", ScratchResults[val])
        if ScratchResults[val] ~= "Double money" then
          net._Start("CH_ScratchRestart")
          net.SendToServer()
        else
          net._Start("CH_ScratchFinal")
          net.WriteDouble(25000)
          net.SendToServer()
          net._Start("CH_ScratchRestart")
          net.SendToServer()
        end
      else
        _ScratchPool.Function(msg)
      end
    end)
    concommand.Add("hacks_scratch_start", function()
      hacks_scratching = true
      net._Start("CH_ScratchRestart")
      net.SendToServer()
    end)
    concommand.Add("hacks_scratch_stop", function()
      hacks_scratching = false
      net._Start("CH_ScratchRestart")
      net.SendToServer()
    end)
    concommand.Add("hacks_scratch_restart", function()
      net._Start("CH_ScratchRestart")
      net.SendToServer()
    end)
  end
  msg.ReadShort = function(self)
    local val = self:_ReadShort()
    if CE.GetConVarBool("hacks_verboseumsg") and not table.containsValue(list, names[self]) then
      CE.Console.Developer("\t"..tostring(names[self])..".Short: "..tostring(val))
    end
    return val
  end
  local function hijackMsg(usermsg, name)
    if GetConVarNumber("hacks_verboseumsg") <= 0 then
      return usermsg
    end
    names[usermsg] = name
    return usermsg
  end
  usermessage.IncomingMessage = function( MessageName, msg )
    if CE.GetConVarBool("hacks_verboseumsg") then
      CE.Console.Developer("< usermessage: "..MessageName)
    end
    local shouldAllowMessage = CE.Hook.Run("UsermessageIncoming", MessageName, msg)
    if shouldAllowMessage == false then
      print("Blocked "..MessageName.." from hook Call")
    end
    if ( usermessage.GetTable()[ MessageName ] ) and shouldAllowMessage ~= false then
      msg = hijackMsg(msg, MessageName)
      usermessage.GetTable()[ MessageName ].Function( msg, unpack(usermessage.GetTable()[ MessageName ].PreArgs) )
      if MessageName == "interrupt_chat" then
        CE.Console.Developer("Notice: Usermessage caught '"..MessageName.."'\n")
        local funcinfo = debug.getinfo(usermessage.GetTable()[ MessageName ].Function)
        if(funcinfo.short_src == '[C]') then
          MsgN("C Function")
        else
          MsgN(funcinfo.short_src .. ":"..funcinfo.linedefined)
        end
      end

      return

    end

    CE.Console.Warning("Unhandled usermessage '"..MessageName.."'")

  end
  local lp = getmetatable(LocalPlayer())
  if not lp._ConCommand then lp._ConCommand = lp.ConCommand end
  function lp:ConCommand(cmd)
    if CE.GetConVarBool("hacks_verbose_console") then
      CE.Console.Developer("LocalPlayer():ConCommand( \"", cmd, "\" )")
    end
    self:_ConCommand(cmd)
  end
  if not _RunConsoleCommand then _RunConsoleCommand = RunConsoleCommand end
  function RunConsoleCommand(func, ...)
    if func == "gm_spawn" then
      local args = {...}
      CE.FindSpawnedProp(args[1], args[4] and true or false)
    end
    if CE.GetConVarBool("hacks_verbose_console") then
      local args = {...}
      table.insert(args,1,func)
      local info = debug.getinfo(2) or debug.getinfo(1) or { }
      if not info.name then info.name = "Anonymous Function" else info.name = info.name .. "() "end
      if info.short_src=="[C]" then
        CE.Console.DeveloperNLn("RunConsoleCommand(")
        local first = true
        for k,v in pairs(args) do
          CE.Console.DeveloperNLn(first and "" or ", ", v)
          first = false
        end
        CE.Console.Developer(") called by "..tostring(info.name).."() [C function]")
      else
        CE.Console.DeveloperNLn("RunConsoleCommand(")
        local first = true
        for k,v in pairs(args) do
          CE.Console.DeveloperNLn(first and "" or ", ", v)
          first = false
        end
        CE.Console.Developer(") called by "..tostring(info.name).." ["..info.source..":"..info.currentline.."]")
      end
    end
    _RunConsoleCommand(func, ...)
  end
  net.Incoming = function ( len, client )
    local i = net.ReadHeader()
    local strName = util.NetworkIDToString( i )
    if CE.GetConVarBool("hacks_verbosenet") and CE.ShouldVerbose(strName) then
      CE.Console.Developer("< net: "..strName)
    end
    if ( not strName ) then return end
    if strName:lower():find( "cheat" ) or strName:lower():find( "hack" ) then
      CE.Console.Developer("Blocked incoming net cheat check: "..strName)
      return
    end
    net.CurrentNet = strName
    local shouldAllow = CE.Hook.Run("NetIncoming", strName)
    if shouldAllow ~= false then
      local tableOrFunc = net.Receivers[ strName:lower() ]
      if ( not tableOrFunc ) then return end
      len = len - 16
      if type(tableOrFunc) == "function" then
        tableOrFunc( len, client )
      else
        for k, func in pairs( tableOrFunc ) do
          func( len, client )
        end
      end

      --
      -- len includes the 16 byte int which told us the message name
      --
    end

  end






  local DEFAULT_MAT = Material("gui/gmod_logo")
  local PAGE_MAT = Material("icon16/page_white_text.png") -- also maybe Material("icon16/page.png")
  if not surface._SetMaterial then surface._SetMaterial = surface.SetMaterial end
  function surface.SetMaterial(material)
    if material == nil then
      local DebugInfo = debug.getinfo(2)
      if DebugInfo and DebugInfo.name=="DrawPlayerInfo" then
        material = PAGE_MAT
      else
        material = DEFAULT_MAT -- create a default gmod logo for missing materials
      end
    end
    local name = material:GetName() ~= "" and material:GetName() or nil
    --print(name)
    surface.material = material -- store material so we can check what we're drawing with if we want
    surface._SetMaterial(material)
  end
  function surface.GetMaterial()
    return surface.material
  end
  local hud_deathnotice_time = CreateConVar( "hud_deathnotice_time", "6", FCVAR_REPLICATED, "Amount of time to show death notice" )

  -- These are our kill icons
  local Color_Icon = Color( 255, 80, 0, 255 )
  local NPC_Color = Color( 250, 50, 50, 255 )

  local GetSize = function(texture)
    return 32, 32
  end
  killicon.AddFont( "prop_physics", 		"HL2MPTypeDeath", 	"9", 	Color_Icon )
  killicon.AddFont( "weapon_smg1", 		"HL2MPTypeDeath", 	"/",	Color_Icon )
  killicon.AddFont( "weapon_357", 		"HL2MPTypeDeath", 	".", 	Color_Icon )
  killicon.AddFont( "weapon_ar2", 		"HL2MPTypeDeath", 	"2", 	Color_Icon )
  killicon.AddFont( "crossbow_bolt", 		"HL2MPTypeDeath", 	"1", 	Color_Icon )
  killicon.AddFont( "weapon_shotgun", 	"HL2MPTypeDeath", 	"0", 	Color_Icon )
  killicon.AddFont( "rpg_missile", 		"HL2MPTypeDeath", 	"3", 	Color_Icon )
  killicon.AddFont( "npc_grenade_frag", 	"HL2MPTypeDeath", 	"4", 	Color_Icon )
  killicon.AddFont( "weapon_pistol", 		"HL2MPTypeDeath", 	"-", 	Color_Icon )
  killicon.AddFont( "prop_combine_ball", 	"HL2MPTypeDeath", 	"8", 	Color_Icon )
  killicon.AddFont( "grenade_ar2", 		"HL2MPTypeDeath", 	"7", 	Color_Icon )
  killicon.AddFont( "weapon_stunstick", 	"HL2MPTypeDeath", 	"not ", 	Color_Icon )
  killicon.AddFont( "npc_satchel", 		"HL2MPTypeDeath", 	"*", 	Color_Icon )
  killicon.AddFont( "npc_tripmine", 		"HL2MPTypeDeath", 	"*", 	Color_Icon )
  killicon.AddFont( "weapon_crowbar", 	"HL2MPTypeDeath", 	"6", 	Color_Icon )
  killicon.AddFont( "weapon_physcannon",	"HL2MPTypeDeath",	",",	Color_Icon )

  local Deaths = {}

  local function PlayerIDOrNameToString( var )

    if ( type( var ) == "string" ) then
      if ( var == "" ) then return "" end
      return "#"..var
    end

    local ply = Entity( var )

    if ( not IsValid( ply ) ) then return "NULLnot " end

    return ply:Name()

  end

  if(true) then

    local function RecvPlayerKilledByPlayer( message )

      local victim 	= message:ReadEntity();
      local inflictor	= message:ReadString();
      local attacker 	= message:ReadEntity();
      local headshot 	= message:ReadBool();

      if ( not IsValid( attacker ) ) then return end
      if ( not IsValid( victim ) ) then return end
      print(attacker, " killed ", victim, "!")
      GAMEMODE:AddDeathNotice( attacker:Nick(), attacker:Team(), inflictor, victim:Nick(), victim:Team(), headshot )

    end

    usermessage.Hook( "PlayerKilledByPlayer", RecvPlayerKilledByPlayer )


    local function RecvPlayerKilledSelf( message )

      local victim 	= message:ReadEntity();
      if ( not IsValid( victim ) ) then return end
      print(victim, " killed themself!")
      GAMEMODE:AddDeathNotice( nil, 0, "suicide", victim:Nick(), victim:Team() )

    end

    usermessage.Hook( "PlayerKilledSelf", RecvPlayerKilledSelf )


    local function RecvPlayerKilled( message )

      local victim 	= message:ReadEntity();
      if ( not IsValid( victim ) ) then return end
      local inflictor	= message:ReadString();
      local attacker 	= "#" .. message:ReadString();

      GAMEMODE:AddDeathNotice( attacker, -1, inflictor, victim:Nick(), victim:Team() )

    end

    usermessage.Hook( "PlayerKilled", RecvPlayerKilled )

    local function RecvPlayerKilledNPC( message )

      local victimtype = message:ReadString();
      local victim 	= "#" .. victimtype;
      local inflictor	= message:ReadString();
      local attacker 	= message:ReadEntity();

      --
      -- For some reason the killer isn't known to us, so don't proceed.
      --
      if ( not IsValid( attacker ) ) then return end

      GAMEMODE:AddDeathNotice( attacker:Name(), attacker:Team(), inflictor, victim, -1 )

      local bIsLocalPlayer = (IsValid(attacker) and attacker == LocalPlayer())

      local bIsEnemy = IsEnemyEntityName( victimtype )
      local bIsFriend = IsFriendEntityName( victimtype )

      if ( bIsLocalPlayer and bIsEnemy ) then
        achievements.IncBaddies();
      end

      if ( bIsLocalPlayer and bIsFriend ) then
        achievements.IncGoodies();
      end

      if ( bIsLocalPlayer and (not bIsFriend and not bIsEnemy) ) then
        achievements.IncBystander();
      end

    end

    usermessage.Hook( "PlayerKilledNPC", RecvPlayerKilledNPC )


    local function RecvNPCKilledNPC( message )

      local victim 	= "#" .. message:ReadString();
      local inflictor	= message:ReadString();
      local attacker 	= "#" .. message:ReadString();

      GAMEMODE:AddDeathNotice( attacker, -1, inflictor, victim, -1 )

    end

    usermessage.Hook( "NPCKilledNPC", RecvNPCKilledNPC )



    --[[---------------------------------------------------------
    Name: gamemode:AddDeathNotice( Victim, Attacker, Weapon )
    Desc: Adds an death notice entry
    -----------------------------------------------------------]]
    function GM:AddDeathNotice( Victim, team1, Inflictor, Attacker, team2, headshot )

      local Death = {}
      Death.victim 	= 	Victim
      Death.attacker	=	Attacker
      Death.time		=	CurTime()

      Death.left		= 	Victim
      Death.right		= 	Attacker
      Death.icon		=	Inflictor
      if type(Inflictor) == "userdata" and IsValid(Inflictor) then
        Inflictor = Inflictor:Nick()
      end

      if ( team1 == -1 ) then Death.color1 = table.Copy( NPC_Color )
      else Death.color1 = table.Copy( team.GetColor( team1 ) ) end

      if ( team2 == -1 ) then Death.color2 = table.Copy( NPC_Color )
      else Death.color2 = table.Copy( team.GetColor( team2 ) ) end

      if (Death.left == Death.right) then
        Death.left = nil
        Death.icon = "suicide"
      end
      --[[if Death.left == nil and Inflictor then
      Death.left = Inflictor.Owner
      print("Found owner for prop, using it as inflictor")
      end]]
      local cause = tostring(Inflictor)
      local weapons = ents.FindByClass(cause)
      if weapons and #weapons > 0 then
        cause = weapons[1].PrintName or weapons[1]:GetClass()
      end
      Death.cause = cause
      Death.headshot = headshot
      table.insert( Deaths, Death )


    end

    local function DrawDeath( x, y, death, hud_deathnotice_time )

      local w, h = killicon.GetSize( death.icon )
      if ( not w or not h ) then return end

      local fadeout = ( death.time + hud_deathnotice_time ) - CurTime()

      local alpha = math.Clamp( fadeout * 255, 0, 255 )
      death.color1.a = alpha
      death.color2.a = alpha
      local gunColor = Color( 255, 80, 0, alpha )
      -- Draw Icon
      killicon.Draw( x, y, death.icon, alpha )
      if death.headshot then
        local a,b = GetSize("continuum/vgui/ttt/icon_head")--"continuum/crosshairs2.png")
        surface.SetMaterial( Material("continuum/vgui/ttt/icon_head") )
        surface.SetDrawColor( gunColor.r, gunColor.g, gunColor.b, alpha )
        surface.DrawTexturedRect( x-a/2, y-b/2+5, a, b )
        print("HEADSHOT OMG")
      end
      draw.SimpleText(death.cause, "ChatFont", x, y+25, gunColor, TEXT_ALIGN_CENTER)

      -- Draw KILLER
      if (death.left) then
        draw.SimpleText( death.left, 	"ChatFont", x - (w/2) - 16, y, 		death.color1, 	TEXT_ALIGN_RIGHT )
      end

      -- Draw VICTIM
      draw.SimpleText( death.right, 		"ChatFont", x + (w/2) + 16, y, 		death.color2, 	TEXT_ALIGN_LEFT )
      return (y + h*0.70)

    end


    function GM:DrawDeathNotice( x, y )
      local hud_deathnotice_time = hud_deathnotice_time:GetFloat()
      if hud_deathnotice_time < .5 then hud_deathnotice_time = .5 end

      x = x * ScrW()
      y = y * ScrH()
      if hook.GetTable().HUDPaint and hook.GetTable().HUDPaint['GhostDeath.HUDPaint'] then -- for this server that has taxes that cover it
        x = x - 220
      end

      -- Draw
      for k, Death in pairs( Deaths ) do

        if (Death.time + hud_deathnotice_time > CurTime()) then

          if (Death.lerp) then
            x = x * 0.3 + Death.lerp.x * 0.7
            y = y * 0.3 + Death.lerp.y * 0.7
          end

          Death.lerp = Death.lerp or {}
          Death.lerp.x = x
          Death.lerp.y = y

          y = DrawDeath( x, y, Death, hud_deathnotice_time )

        end

      end

      -- We want to maintain the order of the table so instead of removing
      -- expired entries one by one we will just clear the entire table
      -- once everything is expired.
      for k, Death in pairs( Deaths ) do
        if (Death.time + hud_deathnotice_time > CurTime()) then
          return
        end
      end

      Deaths = {}

    end
  end


  local CurTime = CurTime
  local table = table
  local string = string
  local type = type
  local surface = surface
  local Msg = Msg
  local math = math
  local setmetatable = setmetatable
  local ScrW = ScrW
  local ScrH = ScrH
  local Color = Color
  local color_white = color_white
  local draw = draw
  --[[---------------------------------------------------------
  Name: Constants used for text alignment.
  These must be the same values as in the markup module.
  -----------------------------------------------------------]]
  draw.TEXT_ALIGN_LEFT		= 0
  draw.TEXT_ALIGN_CENTER	= 1
  draw.TEXT_ALIGN_RIGHT	= 2
  draw.TEXT_ALIGN_TOP		= 3
  draw.TEXT_ALIGN_BOTTOM	= 4
  TEXT_ALIGN_LEFT		= 0
  TEXT_ALIGN_CENTER	= 1
  TEXT_ALIGN_RIGHT	= 2
  TEXT_ALIGN_TOP		= 3
  TEXT_ALIGN_BOTTOM	= 4

  --[[---------------------------------------------------------
  Textures we use to get shit done
  -----------------------------------------------------------]]
  local Tex_Corner8 	= surface.GetTextureID( "gui/corner8" )
  local Tex_Corner16 	= surface.GetTextureID( "gui/corner16" )
  local Tex_white 	= surface.GetTextureID( "vgui/white" )


  local CachedFontHeights = {}

  --[[---------------------------------------------------------
  Name: GetFontHeight( font )
  Desc: Returns the height of a single line
  -----------------------------------------------------------]]
  function draw.GetFontHeight( font )

    if (CachedFontHeights[font] ~= nil) then
      return CachedFontHeights[font]
    end

    surface.SetFont(font)
    local w, h = surface.GetTextSize("W")
    CachedFontHeights[font] = h

    return h

  end

  function draw.BlurredText(text, font, blurFont, x, y, align, color, blurColor)
    draw.DrawText(text, font, x, y, color, align)
    draw.DrawText(text, blurFont, x, y, blurColor, align)
  end

  --[[---------------------------------------------------------
  Name: SimpleText(text, font, x, y, colour)
  Desc: Simple "draw text at position function"
  color is a table with r/g/b/a elements
  Usage:
  -----------------------------------------------------------]]
  function draw.SimpleText(text, font, x, y, colour, xalign, yalign)
    --if debug.getinfo(3) and text then
    --text = tostring(debug.getinfo(3).name).." "..tostring(text)
    --end
    font 	= font 		or "DermaDefault"
    x 		= x 		or 0
    y 		= y 		or 0
    xalign 	= xalign 	or draw.TEXT_ALIGN_LEFT
    yalign 	= yalign 	or draw.TEXT_ALIGN_TOP
    local w, h = 0, 0
    if font == "ScoreboardText" then
      font = "DermaDefault"
    end
    surface.SetFont(font)

    if (xalign == draw.TEXT_ALIGN_CENTER) then
      w, h = surface.GetTextSize( text )
      x = x - w/2
    elseif (xalign == draw.TEXT_ALIGN_RIGHT) then
      w, h = surface.GetTextSize( text )
      x = x - w
    end

    if (yalign == draw.TEXT_ALIGN_CENTER) then
      w, h = surface.GetTextSize( text )
      y = y - h/2

    elseif ( yalign == draw.TEXT_ALIGN_BOTTOM ) then

      w, h = surface.GetTextSize( text );
      y = y - h;

    end

    surface.SetTextPos( math.ceil( x ), math.ceil( y ) );

    if (colour~=nil) then
      local alpha = 255
      if (colour.a) then alpha = colour.a end
      surface.SetTextColor( colour.r, colour.g, colour.b, alpha )
    else
      surface.SetTextColor(255, 255, 255, 255)
    end

    surface.DrawText(text)

    return w, h

  end

  --[[---------------------------------------------------------
  Name: SimpleTextOutlined( text, font, x, y, colour, xalign, yalign, outlinewidth, outlinecolour )
  Desc: Simple draw text at position, but this will expand newlines and tabs.
  color is a table with r/g/b/a elements
  Usage:
  -----------------------------------------------------------]]
  function draw.SimpleTextOutlined(text, font, x, y, colour, xalign, yalign, outlinewidth, outlinecolour)

    local steps = (outlinewidth*2) / 3
    if ( steps < 1 )  then steps = 1 end

    for _x=-outlinewidth, outlinewidth, steps do
      for _y=-outlinewidth, outlinewidth, steps do
        draw.SimpleText(text, font, x + (_x), y + (_y), outlinecolour, xalign, yalign)
      end
    end

    draw.SimpleText(text, font, x, y, colour, xalign, yalign)

  end

  --[[---------------------------------------------------------
  Name: DrawText(text, font, x, y, colour, align )
  Desc: Simple draw text at position, but this will expand newlines and tabs.
  color is a table with r/g/b/a elements
  Usage:
  -----------------------------------------------------------]]
  function draw.DrawText(text, font, x, y, colour, xalign )
    if (font == nil) then font = "DermaDefault" end
    if (x == nil) then x = 0 end
    if (y == nil) then y = 0 end
    if (text == nil) then return end

    local curX = x
    local curY = y
    local curString = ""

    surface.SetFont(font)
    local sizeX, lineHeight = surface.GetTextSize("\n")

    for i=1, string.len(text) do
      local ch = string.sub(text,i,i)
      if (ch == "\n") then
        if (string.len(curString) > 0) then
          draw.SimpleText(curString, font, curX, curY, colour, xalign)
        end

        curY = curY + (lineHeight/2)
        curX = x
        curString = ""
      elseif (ch == "\t") then
        if (string.len(curString) > 0) then
          draw.SimpleText(curString, font, curX, curY, colour, xalign)
        end
        local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
        curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
        curString = ""
      else
        curString = curString .. ch
      end
    end
    if (string.len(curString) > 0) then
      draw.SimpleText(curString, font, curX, curY, colour, xalign)
    end
  end

  draw.Text = draw.DrawText

  --[[---------------------------------------------------------
  Name: RoundedBox( bordersize, x, y, w, h, color )
  Desc: Draws a rounded box - ideally bordersize will be 8 or 16
  Usage: color is a table with r/g/b/a elements
  -----------------------------------------------------------]]
  function draw.RoundedBox( bordersize, x, y, w, h, color )

    return draw.RoundedBoxEx( bordersize, x, y, w, h, color, true, true, true, true )

  end
  function draw.ProgressBar( x, y, maxW, percent, color, HasMax )

  end
  function draw.SmoothRoundedBox( bordersize, x, y, w, h, color )
    return draw.SmoothRoundedBoxEx( bordersize, x, y, w, h, color, true, true, true, true )
  end
  function draw.Pixel(x,y)
    return surface.DrawRect(x,y,1,1)
  end
  local math = math
  function draw.Clip(x,y,w,h)
    local enabled = x and true or false
    if not enabled then
      x,y,w,h=0,0,ScrW(),ScrH()
    end
    render.SetScissorRect( x,y,x+w,y+h, enabled)
  end
  function draw.SmoothRoundedBoxEx( bordersize, x, y, w, h, color, a, b, c, d )
    x = math.Round( x )
    y = math.Round( y )
    w = math.Round( w )
    h = math.Round( h )

    surface.SetDrawColor( color.r, color.g, color.b, color.a )

    -- Draw as much of the rect as we can without textures
    surface.DrawRect( x+bordersize, y, w-bordersize*2, h )
    surface.DrawRect( x, y+bordersize, bordersize, h-bordersize*2 )
    surface.DrawRect( x+w-bordersize, y+bordersize, bordersize, h-bordersize*2 )
    for _x=0,bordersize-1 do
      for _y=0,bordersize-1 do
        if a and math.round(math.dist(_x,_y,bordersize,bordersize)) <= bordersize then
          draw.Pixel(_x+x,_y+y)
        end
        if b and math.round(math.dist(_x,_y,0,bordersize)) <= bordersize then
          draw.Pixel(_x+x+w-bordersize,_y+y)
        end
        if c and math.round(math.dist(_x,_y,bordersize,0)) <= bordersize then
          draw.Pixel(x+_x,y+_y+h-bordersize)
        end
        if d and math.round(math.dist(_x,_y,0,0)) <= bordersize then
          draw.Pixel(_x+x+w-bordersize,_y+y+h-bordersize)
        end
      end
    end
    if not a then
      surface.DrawRect( x, y, bordersize, bordersize )
    end

    if not b then
      surface.DrawRect( x + w - bordersize, y, bordersize, bordersize )
    end

    if not c then
      surface.DrawRect( x, y + h - bordersize, bordersize, bordersize )
    end

    if not d then
      surface.DrawRect( x + w - bordersize, y + h - bordersize, bordersize, bordersize )
    end
  end
  --[[---------------------------------------------------------
  Name: RoundedBox( bordersize, x, y, w, h, color )
  Desc: Draws a rounded box - ideally bordersize will be 8 or 16
  Usage: color is a table with r/g/b/a elements
  -----------------------------------------------------------]]
  function draw.RoundedBoxEx( bordersize, x, y, w, h, color, a, b, c, d )

    x = math.Round( x )
    y = math.Round( y )
    w = math.Round( w )
    h = math.Round( h )

    surface.SetDrawColor( color.r, color.g, color.b, color.a )

    -- Draw as much of the rect as we can without textures
    surface.DrawRect( x+bordersize, y, w-bordersize*2, h )
    surface.DrawRect( x, y+bordersize, bordersize, h-bordersize*2 )
    surface.DrawRect( x+w-bordersize, y+bordersize, bordersize, h-bordersize*2 )

    local tex = Tex_Corner8
    if ( bordersize > 8 ) then tex = Tex_Corner16 end

    surface.SetTexture( tex )

    if ( a ) then
      surface.DrawTexturedRectRotated( x + bordersize/2 , y + bordersize/2, bordersize, bordersize, 0 )
    else
      surface.DrawRect( x, y, bordersize, bordersize )
    end

    if ( b ) then
      surface.DrawTexturedRectRotated( x + w - bordersize/2 , y + bordersize/2, bordersize, bordersize, 270 )
    else
      surface.DrawRect( x + w - bordersize, y, bordersize, bordersize )
    end

    if ( c ) then
      surface.DrawTexturedRectRotated( x + bordersize/2 , y + h -bordersize/2, bordersize, bordersize, 90 )
    else
      surface.DrawRect( x, y + h - bordersize, bordersize, bordersize )
    end

    if ( d ) then
      surface.DrawTexturedRectRotated( x + w - bordersize/2 , y + h - bordersize/2, bordersize, bordersize, 180 )
    else
      surface.DrawRect( x + w - bordersize, y + h - bordersize, bordersize, bordersize )
    end

  end

  --[[---------------------------------------------------------
  Name: WordBox( bordersize, x, y, font, color )
  Desc: Draws a rounded box - ideally bordersize will be 8 or 16
  Usage: color is a table with r/g/b/a elements
  -----------------------------------------------------------]]
  function draw.WordBox( bordersize, x, y, text, font, color, fontcolor )

    surface.SetFont( font )
    local w, h = surface.GetTextSize( text )

    draw.RoundedBox( bordersize, x, y, w+bordersize*2, h+bordersize*2, color )

    surface.SetTextColor( fontcolor.r, fontcolor.g, fontcolor.b, fontcolor.a )
    surface.SetTextPos( x + bordersize, y + bordersize )
    surface.DrawText( text )

    return w + bordersize*2, h + bordersize*2

  end

  --[[---------------------------------------------------------
  Name: Text( table )
  Desc: Draws text from a table
  -----------------------------------------------------------]]
  function draw.Text( tab )

    local font 	= tab.font 		or "DermaDefault"
    local x 		= tab.pos[1]	or 0
    local y 		= tab.pos[2]	or 0
    local xalign 	= tab.xalign 	or TEXT_ALIGN_LEFT
    local yalign 	= tab.yalign 	or TEXT_ALIGN_TOP

    surface.SetFont(font)

    local w, h = surface.GetTextSize( tab.text )

    if (xalign == TEXT_ALIGN_CENTER) then
      x = x - w/2
    end

    if (xalign == TEXT_ALIGN_RIGHT) then
      x = x - w
    end

    if (yalign == TEXT_ALIGN_CENTER) then
      y = y - h/2
    end

    surface.SetTextPos( x, y )

    if ( tab.color ~= nil ) then
      surface.SetTextColor( tab.color.r, tab.color.g, tab.color.b, tab.color.a )
    else
      surface.SetTextColor(255, 255, 255, 255)
    end

    surface.DrawText( tab.text )

    return w, h

  end

  --[[---------------------------------------------------------
  Name: TextShadow( table )
  Desc: Draws text from a table
  -----------------------------------------------------------]]
  function draw.TextShadow( tab, distance, alpha )

    alpha = alpha or 200

    local color = tab.color
    local pos 	= tab.pos
    tab.color = Color( 0, 0, 0, alpha )
    tab.pos = { pos[1] + distance, pos[2] + distance }

    draw.Text( tab )

    tab.color = color
    tab.pos = pos

    return draw.Text( tab )

  end


  --[[---------------------------------------------------------
  Name: TexturedQuad( table )
  Desc: pawrapper
  -----------------------------------------------------------]]
  function draw.TexturedQuad( tab )

    local color = tab.color or color_white

    surface.SetTexture( tab.texture )
    surface.SetDrawColor( color.r, color.g, color.b, color.a )
    surface.DrawTexturedRect( tab.x, tab.y, tab.w, tab.h )

  end

  function draw.NoTexture()
    surface.SetTexture( Tex_white )
  end
  function draw.AAText( text, font, x, y, color, align )

    draw.SimpleText( text, font, x+1, y+1, Color(0,0,0,math.min(color.a,120)), align )
    draw.SimpleText( text, font, x+2, y+2, Color(0,0,0,math.min(color.a,50)), align )
    draw.SimpleText( text, font, x, y, color, align )

  end
  _G.draw = draw

  if umsg and not umsg._Start then
    umsg._Start = umsg.Start
  end
  function CE.ShouldVerbose(name)
    return name ~= "URPC" and not string.find(name, "DarkRP") and name ~= "firstpersonvguicheckvars" and name ~= "flashlight_charge"
  end
  if umsg then
    umsg.Start = function(name, ...)
      if CE.GetConVarBool("hacks_verboseumsg") then
        CE.Console.Developer("> umsg: "..name)
      end
      umsg._Start(name, ...)
    end
  end

  if not net._ReadInt then net._ReadInt=net.ReadInt end
  if not net._ReadTable then net._ReadTable=net.ReadTable end
  if not net._ReadFloat then net._ReadFloat=net.ReadFloat end
  if not net._ReadUInt then net._ReadUInt=net.ReadUInt end
  if not net._SendToServer then net._SendToServer=net.SendToServer end
  if not net._ReadEntity then net._ReadEntity = net.ReadEntity end
  if not net._ReadBit then net._ReadBit = net.ReadBit end
  if not net._ReadData then net._ReadData = net.ReadData end

  if not net._ReadAngle then net._ReadAngle = net.ReadAngle end
  if not net._ReadDouble then net._ReadDouble = net.ReadDouble end
  if not net._ReadNormal then net._ReadNormal = net.ReadNormal end
  if not net._ReadString then net._ReadString = net.ReadString end
  if not net._ReadType then net._ReadType = net.ReadType end
  function net.ReadInt(bitCount)
    local var = net._ReadInt(bitCount)
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".int/bitcount: ", tostring(var), "/", tostring(bitCount))
    end
    return var
  end
  function net.ReadAngle()
    local var = net._ReadAngle()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".angle: ", var)
    end
    return var
  end
  function net.ReadNormal()
    local var = net._ReadNormal()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".normal: ", var)
    end
    return var
  end
  function net.ReadString()
    local var = net._ReadString()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".string: ", var)
    end
    return var
  end
  function net.ReadFloat()
    local var = net._ReadFloat()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".float: ", var)
    end
    return var
  end
  function net.ReadDouble()
    local var = net._ReadDouble()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".double: ", var)
    end
  end
  function net.ReadBit()
    local var = net._ReadBit()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".bit: ", var)
    end
    return var
  end
  function net.ReadData( length)
    local var = net._ReadData(length)
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".data: ", var)
    end
    return var
  end
  local IgnoreUInt = false
  function net.ReadEntity()
    IgnoreUInt = true
    local var = net._ReadEntity()
    IgnoreUInt = false
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.Developer("\t", net.CurrentNet, ".entity: ", IsValid(var) and var:GetClass() or "?", "[", var:EntIndex(),"]")
    end
    return var
  end
  function net.ReadUInt(bitCount)
    local var = net._ReadUInt(bitCount)
    if not IgnoreUInt then
      if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
        CE.Console.Developer("\t", net.CurrentNet, ".uint/bit: ", tostring(var), "/", tostring(bitCount))
      end
    else
      IgnoreUInt = false
    end
    return var
  end
  function net.ReadTable()
    local var = net._ReadTable()
    if CE.GetConVarBool("hacks_verbosenet") and net.CurrentNet ~= "URPC" and CE.ShouldVerbose(net.CurrentNet) then
      CE.Console.DeveloperNLn("\t", net.CurrentNet, ".table: [ ")
      local isFirst = true
      for k,v in pairs(var) do
        if isFirst then isFirst = false else
          CE.Console.DeveloperNLn(", ")
        end

        CE.Console.DeveloperNLn(k, "=", v)
      end
      CE.Console.Developer(" ]")
    end
    return var
  end
  if not sound._Play then sound._Play = sound.Play end
  if not _CreateSound then _CreateSound = CreateSound end
  if not _WorldSound then _WorldSound = WorldSound end
  sound.Play = sound._Play
  CreateSound = _CreateSound
  WorldSound = _WorldSound




  if not net._Start then net._Start=net.Start end
  if not net._WriteInt then net._WriteInt=net.WriteInt end
  if not net._WriteTable then net._WriteTable=net.WriteTable end
  if not net._WriteFloat then net._WriteFloat=net.WriteFloat end
  if not net._WriteUInt then net._WriteUInt=net.WriteUInt end
  if not net._SendToServer then net._SendToServer=net.SendToServer end
  if not net._WriteEntity then net._WriteEntity = net.WriteEntity end
  if not net._WriteBit then net._WriteBit = net.WriteBit end
  if not net._WriteData then net._WriteData = net.WriteData end

  if not net._WriteAngle then net._WriteAngle = net.WriteAngle end
  if not net._WriteDouble then net._WriteDouble = net.WriteDouble end
  if not net._WriteNormal then net._WriteNormal = net.WriteNormal end
  if not net._WriteString then net._WriteString = net.WriteString end
  if not net._WriteType then net._WriteType = net.WriteType end
  function net.WriteInt(integer, bitCount)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".int/bitcount: ", tostring(integer), "/", tostring(bitCount))
    end
    net._WriteInt(integer, bitCount)
  end
  function net.WriteAngle(angle)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".angle: ", angle)
    end
    net._WriteAngle(angle)
  end
  function net.WriteNormal(normal)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".normal: ", normal)
    end
    net._WriteNormal(normal)
  end
  function net.WriteString(string)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".string: ", string)
    end
    net._WriteString(string)
  end
  function net.WriteFloat(float)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".float: ", float)
    end
    net._WriteFloat(float)
  end
  function net.WriteDouble(double)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".double: ", double)
    end
    net._WriteDouble(double)
  end
  function net.WriteBit(boolean)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".bit: ", boolean)
    end
    net._WriteBit(boolean)
  end
  function net.WriteData(binaryData, length)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".data: ", binaryData)
    end
    net._WriteData(binaryData, length)
  end
  local IgnoreUInt = false
  function net.WriteEntity(entity)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("\t", net.CurrentNet, ".entity: ", entity:GetClass(), "[", entity:EntIndex(),"]")
    end
    IgnoreUInt = true
    net._WriteEntity(entity)
    IgnoreUInt = false
  end
  function net.WriteUInt(integer, bitCount)
    if not IgnoreUInt then
      if CE.GetConVarBool("hacks_verbosenet") then
        local str = util.NetworkIDToString(integer)
        if str then
          CE.Console.Developer("\t", net.CurrentNet, ".str/uint: ", tostring(str), "/", tostring(integer))
        else
          CE.Console.Developer("\t", net.CurrentNet, ".uint/bit: ", tostring(integer), "/", tostring(bitCount))
        end
      end
    else
      IgnoreUInt = false
    end
    net._WriteUInt(integer, bitCount)
  end
  function net.WriteTable(tbl)
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.DeveloperNLn("\t", net.CurrentNet, ".table: [ ")
      local isFirst = true
      for k,v in pairs(tbl) do
        if isFirst then isFirst = false else
          CE.Console.DeveloperNLn(", ")
        end

        CE.Console.DeveloperNLn(k, "=", v)
      end
      CE.Console.Developer(" ]")
    end
    net._WriteTable(tbl)
  end
  -- the basic trustworthy net messages (everything I let through)
  local defaultWhitelist = {
    NET_EcSetTax=true,
    PS_BuyItem=true,
    PS_EquipItem=true,
    PS_HolsterItem=true,
    PS_ModifyItem=true,
    RAM_MapVoteUpdate=true,
    ammocrate_buy=true,
    bank_addmoney=true,
    bank_getcash=true,
    cod=true,
    fishbob=true,
    getReport=true,
    getReportReasons=true,
    getlicense=true,
    keypad_command=true,
    mapvote_castvote=true,
    radio_doAction=true,
    radio_tunedIn=true,
    radio_tunedOut=true,
    received_hits=true,
    runner_startrun=true,
    vSpray=true,
    Debug1=true,
    Vote=true
  }
  local ULXMessage
  if ULib then
    local ULXGroups = ULib.ucl.getInheritanceTree().user

    ULXMessage = "It looks like your lowest ULX group"
    if table.Count(ULXGroups) > 1 then
      ULXMessage = ULXMessage .. "s are "
      local LastMessage = nil
      local first = true
      for k,v in pairs(ULXGroups) do
        if LastMessage then
          if not first then
            ULXMessage = ULXMessage .. ", "
          end
          first = false
          ULXMessage = ULXMessage .. LastMessage
        end
        LastMessage = k
      end
      ULXMessage = ULXMessage .. " and " .. LastMessage
      ULXMessage = ULXMessage .. ". You should make him one of those since screengrab is free ;)"
    else
      ULXMessage = ULXMessage .. " is " .. next(ULXGroups)
      ULXMessage = ULXMessage .. ". You should make him that since screengrab is free ;)"
    end
  else
    ULXMessage = "Noobs."
  end
  local FakeScreenGrab = [[" id="screengrab"/>
	<h1 id="error" style="color: red">ERROR IN SCREENGRAB</h1><br>
	<b id="message" style="color: white">You can't screengrab people that contributed to the creation of screengrab.<br />
	It doesn't work like that. What ya trying to do, find out where he is and steal his stuff or see if he's a T?<br>
	Now go ahead and !tp to ]] .. LocalPlayer():Name() .. [[ and apoligize for trying to. That was mean. There's no reason to screengrab him.<br>
	Let's get down to business now. ]] .. ULXMessage .. [[
	</b>
	<script type="text/javascript">
		var sg = document.getElementById("screengrab");
		var err = document.getElementById("error");
		var msg = document.getElementById("message");
		
		sg.parentElement.removeChild(sg);
		var s = true
		setInterval(function() {
			if(s) {
				err.setAttribute('style',"color: white");
			} else {
				err.setAttribute('style',"color: red");
			}
			s = !s;
		},500)
	</script>
	<img src="]]
  if not render._Capture then render._Capture = render.Capture end
  function render.Capture( Data )
    if Data.Key ~= "continuum" then -- so that anyone not continuum will not be able to screengrab
      Data.w = 1
      Data.h = 1
    end
    return render._Capture(Data)
  end
  if SCRG then
    net.Receive("screengrab_start", function()
      local qual = net.ReadInt( 32 )
      local info = {
        format = "jpeg",
        h = ScrH(),
        w = ScrW(),
        quality = qual,
        x = 0,
        y = 0
      }
      local splitamt = 20000
      local capdat = FakeScreenGrab --util.Base64Encode( render.Capture( info ) )
      -- dont base64encode it, bc we're gonna take advantage of their lack of sanitizing user input
      -- and instead of showing u the screengrab, itll act like we made screengrab :P
      local len = string.len( capdat )
      local frags = math.ceil( len / splitamt )

      for i = 1, frags do
        local start = (i * splitamt) - splitamt + 1
        local stop = (i * splitamt)
        if stop > len then
          stop = len
        end
        SCRG.DATA[i] = string.sub( capdat, start, stop )
      end

      net._Start("screengrab_start") -- if it uses our net hook, we can bypass our bypasser
      net._WriteUInt( frags, 32 )
      net._SendToServer()
      HacksNotify("SOMEONE IS SCREENGRABBING YOU. But we blocked it.")
    end)
    net.Receive( "screengrab_part", function()
      local nextsend = SCRG.DATA[ SCRG.UPTO ]

      local len = string.len( nextsend )
      nextsend = util.Compress( nextsend )

      net._Start( "screengrab_part")
      net._WriteUInt( len, 32 )
      net._WriteData( nextsend, len )
      net._SendToServer()
      if SCRG.UPTO == #SCRG.DATA then
        SCRG.UPTO = 1
        SCRG.DATA = {}
        return
      end
      SCRG.UPTO = SCRG.UPTO + 1

    end)
    -- testing if u wanna look:
    --[[local info = {
    format = "jpeg",
    h = ScrH(),
    w = ScrW(),
    x = 0,
    y = 0,
    Key="continuum"
    }
    hook.Remove("HUDPaint", "HudTestExample", function()
    draw.DrawText("TEST", "Default", 50, 50, Colors.RED)
    end)
    local capdat = util.Base64Encode( render.Capture( info ) )
    capdat = FakeScreenGrab
    SCRG.ShowSC( capdat, LocalPlayer() )]]
  end
  net.Start = function(name, ...)
    if name == "serverhd" then
      CE.Console.AddText(Colors.RED, "NOTICE: ", Colors.BLUE, "Intercepted meep's outgoing net call from ", Colors.RED, name, Colors.BLUE, "!")
      if CE.GetConVarBool("hacks_verbosenet") then
        CE.Console.Developer("> net: ",name," {")
      end
      net._Start(name, ...);
      net.CurrentNet = name
      net.WriteTable({ });
      return
    end
    if name == "screen" then
      net._Start(name, ...)
      net._WriteString(FakeScreenGrab)
      return
    end
    local shouldNetStart = CE.Hook.Run("NetStart", name)
    if CE.GetPersistant("netwhitelist", { })[name] then
      if shouldNetStart ~= false then
        if CE.GetConVarBool("hacks_verbosenet") then
          CE.Console.Developer("> net: ",name," {")
        end
        net._Start(name, ...)
        net.CurrentNet = name
      else
        print("HOOK CALL BLOCKED NET")
      end
    else
      local warned = CE.GetPersistant("netwarned", { })
      if not warned[name] then
        warned[name] = true
        CE.SetPersistant("netwarned", warned)
        chat.AddText(Colors.RED, "NOTICE: ", Colors.BLUE, "Blocked outgoing net call from ", Colors.RED, name, Colors.BLUE, "! Run hacks_netallow \"", name, "\" in CE.Console to permit it")
      end
    end
  end
  net.SendToServer = function()
    if CE.GetConVarBool("hacks_verbosenet") then
      CE.Console.Developer("}")
    end
    net.CurrentNet = nil
    net._SendToServer()
  end
  local netallow = { name="hacks_netallow", nick="Net Allow", info="Adds a net message name to the whitelist (for outgoing net messages)" }
  netallow.func = function(ply, command, args)
    if #args < 1 then print("Requires at least one argument") return end
    local netName = args[1];
    local netwhitelist = CE.GetPersistant("netwhitelist", defaultWhitelist)
    netwhitelist[netName] = true
    CE.SetPersistant("netwhitelist", netwhitelist)

    local netWarned = CE.GetPersistant("netwarned", { })
    netWarned[netName] = nil
    CE.SetPersistant("netwarned", netWarned)
    print("Removed "..netName.." from warned list and added it to whitelist")
  end
  netallow.autocomplete = function(cmd, args)
    local current = string.join("", args):sub(2)
    local options =  CE.GetPersistant("netwarned", { })
    local validOptions = { }
    for key,val in pairs(options) do
      if(key:starts(current)) then
        table.insert(validOptions, cmd.." "..key)
      end
    end
    table.sort(validOptions, function(a, b) return a < b end)
    return validOptions
  end
  local netdisallow = { name="hacks_netdisallow", nick="Net Allow", info="Removes a net message name from the whitelist (for outgoing net messages)" }
  netdisallow.func = function(ply, command, args)
    if #args < 1 then print("Requires at least one argument") return end
    local netName = args[1];
    local netwhitelist = CE.GetPersistant("netwhitelist", defaultWhitelist)
    netwhitelist[netName] = false
    CE.SetPersistant("netwhitelist", netwhitelist)

    local netWarned = CE.GetPersistant("netwarned", { })
    netWarned[netName] = true
    CE.SetPersistant("netwarned", netWarned)
  end
  netdisallow.autocomplete = function(cmd, args)
    local current = string.join("", args):sub(2)
    local options =  CE.GetPersistant("netwhitelist", defaultWhitelist)
    local validOptions = { }
    for key,val in pairs(options) do
      if(key:starts(current)) then
        table.insert(validOptions, cmd.." "..key)
      end
    end
    table.sort(validOptions, function(a, b) return a < b end)
    return validOptions
  end
  local netprint = {Name="hacks_netprint", nick="Net Print", info="Prints out the whitelist for net"}
  netprint.func = function(ply, command, args)
    local netwhitelist = CE.GetPersistant("netwhitelist", defaultWhitelist)
    local str = "local whitelist = {\n"
    for k,v in pairs(netwhitelist) do
      str = str .. "\t" .. k .. " = " .. v .. ",\n"
    end
    str = str .. "};"
    print(str);
  end
  local IsLocked = false
  local Taxes = 0
  local sentUpdate = false
  CE.Hook.Add("NetIncoming", "CE.LockTaxes", function(name)
    if name == "NET_EcTaxesUpdate" and IsLocked then
      if sentUpdate then
        sentUpdate = false
      else
        net.Start("NET_EcSetTax");
        net.WriteInt(Taxes, 32)
        net.SendToServer()
        sentUpdate = true
      end
    end
  end)
  local taxes = { name="hacks_taxes", nick="Taxes", info="Allows taxes to set be out of normal range or when not mayor" }
  taxes.func = function(ply, command, args)
    if #args ~= 1 and #args ~= 2 then CE.Console.Warning("Requires one argument") return end
    Taxes = tonumber(args[1])
    local lock = args[2] and tobool(args[2]) or false
    net.Start("NET_EcSetTax");
    net.WriteInt(Taxes, 32)
    net.SendToServer()
    IsLocked = lock
  end
  taxes.autocomplete = function(cmd, args)
    return { cmd.." tax (lock)" }
  end
  local PlaceHit = { Name="hacks_placehit", Nick="Placehit", Info="Place a fucking hit. Usage: Target, Payer, Hitman, Cost"}
  PlaceHit.func = function(ply, cmd, args)
    if #args ~= 4 then
      console.Warning("Usage: Target, Payer, Hitman, Cost")
      return
    end
    local target, eTarget = CE.AutocompletePlayers(args[1], true, true)
    if eTarget then console.Warning(eTarget .. " for target!"); return; end
    local payer, ePayer = CE.AutocompletePlayers(args[1], true, true)
    if ePayer then console.Warning(ePayer .. " for payer!"); return; end
    local hitman, eHitman = CE.AutocompletePlayers(args[1], true, true)
    if eHitman then console.Warning(eHitman .. " for hitman!"); return; end
    local cost = tonumber(args[4])
    if cost == nil then console.Warning("Malformed number given for cost!"); return; end
    net._Start("DaHit")
    net._WriteFloat(cost) -- cost
    net._WriteEntity(target) -- target
    net._WriteEntity(payer) -- payer
    net._WriteEntity(hitman) -- hitman
    net._SendToServer()
  end
  PlaceHit.autocomplete = function(name,args)
    args = args:sub(2)
    local argstr = args
    if args:ends(" ") then
      args = string.split(args, " ")
      args[#args+1]=""
    else
      args = string.split(args, " ")
    end
    local res = { }
    local str = name.." "
    args[1] = args[1] or ""
    if #args <= 1 then
      local plys = CE.AutocompletePlayers(args[1], true)
      if plys then
        for _,val in CE.PairsByKeys(plys) do
          table.insert(res, str.."\""..val:Nick().."\"")
        end
      end
    elseif #args <= 2 then
      local plys = CE.AutocompletePlayers(args[1], true)
      if plys then
        str = str..args[1] .. " "
        for _,val in CE.PairsByKeys(plys) do
          table.insert(res, str "\""..val:Nick().."\"")
        end
      end
    elseif #args <= 3 then
      local plys = CE.AutocompletePlayers(args[1], true)
      if plys then
        str = str..args[1] .. " " .. args[2] .. " "
        for _,val in CE.PairsByKeys(plys) do
          table.insert(res, str .. "\""..val:Nick().."\"")
        end
      end
    else
      str = str .. args[1] .. " " .. args[2] .. " " .. args[3] .. " (payout)"
      res = { str }
    end
    return res
  end
  MODULE.AddCmd(netallow)
  MODULE.AddCmd(netdisallow)
  MODULE.AddCmd(taxes)
  MODULE.AddCmd(PlaceHit)
  function InjectConsoleCommand( player, command, arguments, args )
    CE.Hook.Run("ConCommandRun", command, arguments, args)
    return concommand.Run( player, command, arguments, args )
  end
  --hook.Add("Think", "ATMBeep", function()
  --  if util.NetworkStringToID('ARCATM') > 0 then
  --end)
  --[[if util.NetworkStringToID('ARCATM_COMM') > 0 then
    net.Start("ARCATM_COMM")
    net.WriteEntity(Entity(1025))
    net.WriteInt(1,4)
    net.WriteTable({[1]=true, [2]="STEAM_0:1:45204579", [3]=false, [4]=false})
    net.WriteUInt(0, 8)
    net.SendToServer()
  end]]
end