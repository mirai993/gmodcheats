local CE = CE

MODULE.Enabled = true
MODULE.ID = "com.continuum.drp.atm"
MODULE.Dependencies = { }

MODULE.Name="ATM"
MODULE.Info="Brute-forces ATM codes"

MODULE.Init = function(CE)
  local function CommaTheCash( num )
  	if ( not num ) then return end
  	for i = string.len( num ) - 3, 1, -3 do
  		num = string.sub( num, 1, i ) .. "," .. string.sub( num, i + 1 )
  	end
  	return num
  end
  
  local function AreWeNearATM()
  	for id, ent in pairs( ents.FindInSphere( LocalPlayer():GetPos(), 64 ) ) do
  		if ( ent:GetClass() == "atm_machine" ) then
  			return true
  		end
  	end
  	return false
  end
  
  concommand.Add( "rp_atm_nopin", function( ply, cmd, args )
  	if ( not AreWeNearATM() ) then chat.AddText( "You must be near an ATM to use it!" ) return end
  	if ( IsValid( DermaPanel5 ) ) then
  		DermaPanel5:SetVisible( false )
  		DermaPanel5:Close()
  	end
  
  	DermaPanel4 = vgui.Create( "DFrame" )
  	DermaPanel4:SetSize( 150, 110 )
  	DermaPanel4:SetTitle( "ATM" )
  	DermaPanel4:Center()
  	DermaPanel4:MakePopup()
  
  	local DLabel5 = vgui.Create( "DLabel", DermaPanel4 )
  	DLabel5:SetPos( 26, 25 )
  	DLabel5:SetColor( Color( 255, 255, 255, 255 ) )
  	DLabel5:SetFont( "TabLarge" )
  	DLabel5:SetText( "Please Create a PIN." )
  	DLabel5:SizeToContents()
  
  	local DLabel6 = vgui.Create( "DLabel", DermaPanel4 )
  	DLabel6:SetPos( 37, 40 )
  	DLabel6:SetColor( Color( 255, 0, 0, 255 ) )
  	DLabel6:SetFont( "TabLarge" )
  	DLabel6:SetText( "*4 Digits Only!*" )
  	DLabel6:SizeToContents()
  
  	local myText5 = vgui.Create( "DTextEntry", DermaPanel4 )
  	myText5:SetSize( 80, 20 )
  	myText5:SetPos( 36, 60 )
  	myText5:RequestFocus()
  
  	local button5 = vgui.Create( "DButton", DermaPanel4 )
  	button5:SetSize( 80, 18 )
  	button5:SetPos( 36, 85 )
  	button5:SetText( "Set PIN" )
  	button5.DoClick = function()
  		local PIN = myText5:GetValue()
  		RunConsoleCommand( "rp_atm_setpin", PIN )
  		if isnumber( tonumber( PIN ) ) and string.len( PIN ) == 4 then
  			-- for convenience, save their own code so we don't have to crack it
  			local ATMCodes = CE.GetPersistant("ATMCodes", { })
  			ATMCodes[LocalPlayer():SteamID()] = PIN
  			CE.SetPersistant("ATMCodes", ATMCodes)
  		end
  	end
  
  end )
  
  concommand.Add( "rp_atm_open", function( ply, cmd, args )
  	if ( not AreWeNearATM() ) then chat.AddText( "You must be near an ATM to use it!" ) return end
  
  	if ( IsValid( DermaPanel4 ) ) then
  		DermaPanel4:SetVisible( false )
  		DermaPanel4:Close()
  	end
  
  	DermaPanel5 = vgui.Create( "DFrame" )
  	DermaPanel5:SetSize( 160, 250 )
  	DermaPanel5:SetTitle( "ATM" )
  	DermaPanel5:Center()
  	DermaPanel5:MakePopup()
  	local PropertySheet = vgui.Create( "DPropertySheet", DermaPanel5 )
  	PropertySheet:SetPos( 0, 25 )
  	PropertySheet:SetSize( 160, 225 )
  
  	local TabA = vgui.Create( "DPanelList", PropertySheet )
  	local PlayerList
  	local SelectAccountLabel = vgui.Create( "DLabel", TabA )
  	SelectAccountLabel:SetPos( 24, 20 )
  	SelectAccountLabel:SetColor( Color( 255, 255, 255, 255 ) )
  	SelectAccountLabel:SetFont( "TabLarge" )
  	SelectAccountLabel:SetText( "Select Account:" )
  	SelectAccountLabel:SizeToContents()
  
  	local EnterPinLabel = vgui.Create( "DLabel", TabA )
  	EnterPinLabel:SetPos( 24, 70  )
  	EnterPinLabel:SetColor( Color( 255, 255, 255, 255 ) )
  	EnterPinLabel:SetFont( "TabLarge" )
  	EnterPinLabel:SetText( "Enter PIN:" )
  	EnterPinLabel:SizeToContents()
  
  	local PINTextEntry = vgui.Create( "DTextEntry", TabA )
  	PINTextEntry:SetSize( 100, 20 )
  	PINTextEntry:SetPos( 22, 85 )
  	PINTextEntry:RequestFocus()
  	PINTextEntry.OnEnter = function()
  		RunConsoleCommand( "rp_atm_login", util.CRC( PINTextEntry:GetValue() ), PlayerList.CurData )
  	end
  
  	PlayerList = vgui.Create( "DComboBox", TabA )
  	PlayerList:SetPos( 22, 36 )
  	PlayerList:SetSize( 100, 20 )
  	PlayerList.OnSelect = function( self, index, value, data )
  		PlayerList.CurData = data:UniqueID()
  		local ATMCode = CE.GetPersistant("ATMCodes", { })[data:SteamID()]
  		PINTextEntry:SetText(ATMCode and ATMCode or "")
  	end
  	for k, v in pairs( player.GetAll() ) do
  		local id = PlayerList:AddChoice( v:Nick(), v )
  		if v == LocalPlayer() then
  			PlayerList:ChooseOptionID(id)
  		end
  	end
  	LIST = PlayerList
  
  	local LoginButton = vgui.Create( "DButton", TabA )
  	LoginButton:SetSize( 100, 18 )
  	LoginButton:SetPos( 22, 106 )
  	LoginButton:SetText( "Enter" )
  	LoginButton.DoClick = function()
  		RunConsoleCommand( "rp_atm_login", util.CRC( PINTextEntry:GetValue() ), PlayerList.CurData )
  	end
  
  	local ChangePINButton = vgui.Create( "DButton", TabA )
  	ChangePINButton:SetSize( 100, 25 )
  	ChangePINButton:SetPos( 22, 150 )
  	ChangePINButton:SetText( "Change my PIN" )
  	ChangePINButton.DoClick = function()
  		RunConsoleCommand( "rp_atm_nopin" )
  	end
  
  	PropertySheet:AddSheet( "ATM", TabA, "icon16/shield.png", false, false, "ATM Security" )
  
  
  
  	local TabB = vgui.Create( "DPanelList", PropertySheet )
  
  	local button1 = vgui.Create( "DButton", TabB )
  	button1:SetSize( 120, 18 )
  	button1:SetPos( 12, 5 )
  	button1:SetText( "Print PIN Codes" )
  	button1.DoClick = function()
  		RunConsoleCommand( "rp_atm_pincodes_send" )
  	end
  
  	local button2 = vgui.Create( "DButton", TabB )
  	button2:SetSize( 120, 18 )
  	button2:SetPos( 12, 25 )
  	button2:SetText( "Print Banked Money" )
  	button2.DoClick = function()
  		RunConsoleCommand( "rp_atm_money_send" )
  	end
  
  	local DLabel2 = vgui.Create( "DLabel", TabB )
  	DLabel2:SetPos( 20, 48 )
  	DLabel2:SetColor( Color( 255, 255, 255, 255 ) )
  	DLabel2:SetFont( "TabLarge" )
  	DLabel2:SetText( "ATMs:" )
  	DLabel2:SizeToContents()
  
  	local button3 = vgui.Create( "DButton", TabB )
  	button3:SetSize( 70, 18 )
  	button3:SetPos( 0, 64 )
  	button3:SetText( "Remove" )
  	button3:SetTooltip( "Remove all ATMs on the map" )
  	button3.DoClick = function()
  		RunConsoleCommand( "rp_atm_removeall" )
  	end
  
  	local button4 = vgui.Create( "DButton", TabB )
  	button4:SetSize( 70, 18 )
  	button4:SetPos( 0, 84 )
  	button4:SetText( "Respawn" )
  	button4:SetTooltip( "Respawn ATMs from a saved file" )
  	button4.DoClick = function()
  		RunConsoleCommand( "rp_atm_respawnall" )
  	end
  
  	local DLabel2 = vgui.Create( "DLabel", TabB )
  	DLabel2:SetPos( 86, 48 )
  	DLabel2:SetColor( Color( 255, 255, 255, 255 ) )
  	DLabel2:SetFont( "TabLarge" )
  	DLabel2:SetText( "Spawns:" )
  	DLabel2:SizeToContents()
  
  	local button3_add = vgui.Create( "DButton", TabB )
  	button3_add:SetSize( 70, 18 )
  	button3_add:SetPos( 72, 64 )
  	button3_add:SetText( "Save" )
  	button3_add:SetTooltip( "Save all ATM positions to a file" )
  	button3_add.DoClick = function()
  		RunConsoleCommand( "rp_atm_savespawns" )
  	end
  
  	local button4_add = vgui.Create( "DButton", TabB )
  	button4_add:SetSize( 70, 18 )
  	button4_add:SetPos( 72, 84 )
  	button4_add:SetText( "Delete" )
  	button4_add:SetTooltip( "Delete ATM positions for this map" )
  	button4_add.DoClick = function()
  		RunConsoleCommand( "rp_atm_removespawns" )
  	end
  
  	local List2 = vgui.Create( "DComboBox", TabB )
  	List2:SetSize( 120, 18 )
  	List2:SetPos( 12, 116 )
  	List2:SetText( tostring( LocalPlayer():Nick() ) )
  	List2.CurData = LocalPlayer():UniqueID()
  	List2.OnSelect = function( self, index, value, data )
  		List2.CurData = data
  	end
  	for k, v in pairs( player.GetAll() ) do
  		List2:AddChoice( v:Nick(), v:UniqueID() )
  	end
  
  	local myText11 = vgui.Create( "DTextEntry", TabB )
  	myText11:SetSize( 58, 16 )
  	myText11:SetPos( 12, 136 )
  	myText11.OnEnter = function()
  		RunConsoleCommand( "rp_atm_admin_setpin", List2.CurData, myText11:GetValue() )
  	end
  
  	local button5 = vgui.Create( "DButton", TabB )
  	button5:SetSize( 58, 16 )
  	button5:SetPos( 74, 136 )
  	button5:SetText( "Set PIN" )
  	button5:SetTooltip( "Set PIN for selected account" )
  	button5.DoClick = function()
  		RunConsoleCommand( "rp_atm_admin_setpin", List2.CurData, myText11:GetValue() )
  	end
  
  	local button6 = vgui.Create( "DButton", TabB )
  	button6:SetSize( 58, 16 )
  	button6:SetPos( 12, 154 )
  	button6:SetText( "Enter Valut" )
  	button6:SetTooltip( "Enter selected account without entering PIN" )
  	button6.DoClick = function()
  		RunConsoleCommand( "rp_atm_admin_account", List2.CurData )
  	end
  
  	local button7 = vgui.Create( "DButton", TabB )
  	button7:SetSize( 58, 16 )
  	button7:SetPos( 74, 154 )
  	button7:SetText( "Reset PIN" )
  	button7:SetTooltip( "Reset PIN for selected account" )
  	button7.DoClick = function()
  		RunConsoleCommand( "rp_atm_admin_resetpin", List2.CurData )
  	end
  
  	local button8 = vgui.Create( "DButton", TabB )
  	button8:SetSize( 120, 16 )
  	button8:SetPos( 12, 172 )
  	button8:SetText( "Reset Money" )
  	button8:SetTooltip( "Reset money for selected account" )
  	button8.DoClick = function()
  		RunConsoleCommand( "rp_atm_admin_resetmoney", List2.CurData )
  	end
  
  	PropertySheet:AddSheet( "Admin", TabB, "icon16/shield_add.png", false, false, "ATM Admin Settings" )
  end )
  local PlayerToCrack = nil
  local IsBruteForcing = false
  local CRCToPassTable = { }
  local PassToCRCTable = { }
  local NumberToPassTable = { }
  local CurrentPassword = 0
  local function MakeString(number)
  	if type(number) == "number" then
  		-- print("Key was number (" .. number .. "), got val of " .. tostring(NumberToPassTable[number]) )
  		return NumberToPassTable[number]
  	end
  	return number
  end
  for i=0,9999 do
  	local PassString = tostring(i)
  	while #PassString < 4 do
  		PassString = "0" .. PassString
  	end
  	NumberToPassTable[i] = PassString
  	CRCToPassTable[util.CRC(PassString)] = PassString
  	PassToCRCTable[PassString] = util.CRC(PassString)
  end
  
  local function CRCToPass(crc)
  	return CRCToPassTable[crc]
  end
  local function PassToCRC(code)
  	return PassToCRCTable[MakeString(code)]
  end
  local RunConsoleCommand = _RunConsoleCommand or RunConsoleCommand
  local function TryPassword(ply, code)
  	local User = ply:UniqueID()
  	local PassString = MakeString(code)
  	print(PassString)
  	local CRC = util.CRC( PassString )
  	RunConsoleCommand( "rp_atm_login", CRC, User )
  end
  local CrackCommand = { Name="hacks_atmcrack", Nick="ATM Cracker", HUD={ Category="Misc", Type="CommandButton"} }
  local StopCrackCommand = { Name="hacks_atmcrack_stop", Nick="ATM Stop Crack", HUD={ Category="Misc", Type="CommandButton"} }
  StopCrackCommand.Function = function()
  	timer.Destroy("ATMCrackTimer")
  	PlayerToCrack = nil
  	IsBruteForcing = false
  	print("Stopped crack")
  end
  CrackCommand.Function = function(ply, cmd, args)
  	local plys = CE.AutocompletePlayers(args[1], true)
  	if #plys == 0 then print("No players found matching argument") return end
  	if #plys > 1 then print("Multiple players found matching argument, refine your search") return end
  	print("Cracking ", plys[1], ", trying basics first. Beginning bruteforce in 5 seconds; type hacks_atmcrack_stop to stop")
  	timer.Destroy("ATMCrackTimer")
  	IsBruteForcing = nil
  	PlayerToCrack = plys[1]
  	local ATMCodes = CE.GetPersistant("ATMCodes", { })
  	-- First let's try to see if we cracked their password before
  	if ATMCodes[plys[1]:SteamID()] then
  		TryPassword(plys[1], ATMCodes[plys[1]:SteamID()])
  	else -- if we didn't, maybe theyre still using the default, or a popular one?
  		TryPassword(plys[1], "1234")
  		TryPassword(plys[1], "1111")
  		TryPassword(plys[1], "0000")
  		TryPassword(plys[1], "1212")
  		TryPassword(plys[1], "7777")
  		TryPassword(plys[1], "1337")
  		TryPassword(plys[1], "1225")
  		TryPassword(plys[1], "1010")
  		TryPassword(plys[1], "1234")
  
  		-- And let's cover some popular birthday years, and just in case
  		--this thing lasts more than a year, we'll dynamically
  		-- load the year from the OS
  		local year = tonumber(os.date('%Y'))
  		TryPassword(plys[1], tostring(year - 10))
  		TryPassword(plys[1], tostring(year - 11))
  		TryPassword(plys[1], tostring(year - 12))
  		TryPassword(plys[1], tostring(year - 13))
  		TryPassword(plys[1], tostring(year - 14))
  		TryPassword(plys[1], tostring(year - 15))
  		TryPassword(plys[1], tostring(year - 16))
  	end
  	timer.Create("ATMCrackTimer", 3, 1, function()
  		CurrentPassword = 0
  		if IsBruteForcing == nil then
  			-- And now we'll enable our brute-forcer until it finds the password!
  			IsBruteForcing = true
  		end
  	end)
  end
  CrackCommand.autocomplete = function(name,args)
  	args = args:sub(2)
  	local argstr = args
  	if args:ends(" ") then
  		args = string.split(args, " ")
  		args[#args+1]=""
  	else
  		args = string.split(args, " ")
  	end
  	local res = { }
  	local str = name.." "
  	args[1] = args[1] or ""
  	local plys = CE.AutocompletePlayers(args[1], true)
  	if plys then
  		for _,val in CE.PairsByKeys(plys) do
  			table.insert(res, str.."\""..val:Nick().."\"")
  		end
  	end
  	return res
  end
  MODULE.AddCmd(CrackCommand)
  MODULE.AddCmd(StopCrackCommand)
  
  CE.Hook.Add("Think", "ATMCracker", function()
  	if IsValid(PlayerToCrack) and CurrentPassword <= 9999 and IsBruteForcing then
  		TryPassword(PlayerToCrack, CurrentPassword)
  		CurrentPassword = CurrentPassword + 1
  	end
  end)
  
  concommand.Add("rp_atm_account",function ( ply, cmd, args )
  	if ( not AreWeNearATM() ) then chat.AddText( "You must be near an ATM to use it!" ) return end
  	local Pass = CRCToPass(args[1])
  	if IsValid(PlayerToCrack) then
  		PlayerToCrack = nil
  		print("Password cracked: ", Pass, " (CRC ", args[1], "). Money found: ", args[3])
  		IsBruteForcing = false
  	end
  	local ATMCodes = CE.GetPersistant("ATMCodes", { })
  	local ply = player.GetByUniqueID(args[2])
  	if ply then
  		ATMCodes[ply:SteamID()] = Pass
  	end
  	CE.SetPersistant("ATMCodes", ATMCodes)
  
  	if ( IsValid( DermaPanel5 ) ) then
  		DermaPanel5:SetVisible( false )
  		DermaPanel5:Close()
  	end
  
  	if ( IsValid( DermaPanel ) ) then
  		DermaPanel:SetVisible( false )
  		DermaPanel:Close()
  	end
  
  	DermaPanel = vgui.Create( "DFrame" )
  	DermaPanel:SetSize( 160, 225 )
  	DermaPanel:SetTitle( "ATM" )
  	DermaPanel:Center()
  	DermaPanel:MakePopup()
  
  	local PassLabel = vgui.Create( "DLabel", DermaPanel )
  	PassLabel:SetPos( 20, 30 )
  	PassLabel:SetColor( Color( 255, 204, 51, 255 ) )
  	PassLabel:SetFont( "TabLarge" )
  	PassLabel:SetText( "Pass: " .. Pass )
  	PassLabel:SizeToContents()
  
  	local DLabel8 = vgui.Create( "DLabel", DermaPanel )
  	DLabel8:SetPos( 20, 42 )
  	DLabel8:SetColor( Color( 51, 204, 255, 255 ) )
  	DLabel8:SetFont( "TabLarge" )
  	for k, v in pairs( player.GetAll() ) do
  		if tostring( v:UniqueID() ) == tostring( args[2] ) then
  			DLabel8:SetText( v:Nick() )
  		end
  	end
  	DLabel8:SizeToContents()
  
  	local DLabel9 = vgui.Create( "DLabel", DermaPanel )
  	DLabel9:SetPos( 20, 54 )
  	DLabel9:SetColor( Color( 0, 255, 0, 255 ) )
  	DLabel9:SetFont( "TabLarge" )
  	DLabel9:SetText( "$" .. CommaTheCash( tonumber( args[3] ) ) )
  	DLabel9:SizeToContents()
  
  	local DLabel1 = vgui.Create( "DLabel", DermaPanel )
  	DLabel1:SetPos( 20, 78 )
  	DLabel1:SetColor( Color( 255, 255, 255, 255 ) )
  	DLabel1:SetFont( "TabLarge" )
  	DLabel1:SetText( "Deposit:" )
  	DLabel1:SizeToContents()
  
  	local myText = vgui.Create( "DTextEntry", DermaPanel )
  	myText:SetSize( 120, 20 )
  	myText:SetPos( 19, 93 )
  	myText.OnEnter = function()
  		RunConsoleCommand("rp_atm_deposit", args[1], args[2], tonumber( myText:GetValue() ) )
  	end
  	myText:SetText(LocalPlayer().DarkRPVars["money"] or 0)
  	myText:RequestFocus()
  
  	local button = vgui.Create( "DButton", DermaPanel )
  	button:SetSize( 120, 18 )
  	button:SetPos( 19, 114 )
  	button:SetText( "Deposit" )
  	button.DoClick = function()
  		RunConsoleCommand("rp_atm_deposit", args[1], args[2], tonumber( myText:GetValue() ) )
  	end
  
  	local DLabel2 = vgui.Create( "DLabel", DermaPanel )
  	DLabel2:SetPos( 20, 144 )
  	DLabel2:SetColor( Color( 255, 255, 255, 255 ) )
  	DLabel2:SetFont( "TabLarge" )
  	DLabel2:SetText( "Withdraw:" )
  	DLabel2:SizeToContents()
  
  	local myText2 = vgui.Create( "DTextEntry", DermaPanel )
  	myText2:SetSize( 120, 20 )
  	myText2:SetPos( 19, 159 )
  	myText2.OnEnter = function()
  		RunConsoleCommand("rp_atm_withdraw", args[1], args[2], tonumber( myText2:GetValue() ) )
  	end
  	myText2:SetText(args[3])
  
  	local button = vgui.Create( "DButton", DermaPanel )
  	button:SetSize( 120, 20 )
  	button:SetPos( 19, 180 )
  	button:SetText( "Withdraw" )
  	button.DoClick = function()
  		RunConsoleCommand("rp_atm_withdraw", args[1], args[2], tonumber( myText2:GetValue() ) )
  	end
  end )
end