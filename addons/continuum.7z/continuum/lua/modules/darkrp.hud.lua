MODULE.ID = "com.continuum.drp.hud"
MODULE.Dependencies = { "com.continuum.drp.fixes" }

MODULE.Name = "DarkRP HUD"
MODULE.Info = "Improved Heads Up Display for DarkRP"

MODULE.Init = function(CE)
  local debugger = CE.Debugger
  local Colors = CE.Colors
  local EM = FindMetaTable("Entity")
  local GAMEMODE = GAMEMODE
  local GM = GAMEMODE
  local math = math
  local draw = draw
  local FrameTime = FrameTime
  
  local HUDPaint = GM.HUDPaint
  local DrawHUD = debugger.GetUpvalue(HUDPaint, "DrawHUD")
  local DrawEntityDisplay = debugger.GetUpvalue(HUDPaint, "DrawEntityDisplay")
  local Page = Material("icon16/page_white_text.png")
  local ExpandX = 0
  local ExpandY = 0
  function math.sign(a)
  	return tostring(a):sub(1,1) == "-" and -1 or 1
  end
  if DrawHUD and DrawEntityDisplay then
  	local Clip1, Clip2, PAmmoCount, SAmmoCount, PClipSize, SClipSize, WeaponName, Velocity, car, CarName, dev
  	local function DrawProgressBar(x,y,maxW,percent, color, HasMax)
  		local h = 5
  		if HasMax then
  			draw.RoundedBox( 0, x, y, maxW, h, Colors.Darker(Colors.Darker(Colors.Darker(color))) )
  		end
  		draw.RoundedBox( 0, x, y, maxW * math.Clamp(percent, 0, 100) / 100, h, color )
  	end
  
  	-- loop like runescape bot, have stuff for things like raid protection (select a player, itll group them or w/e), or mug defense, make a folder called bots
  	-- also make the GUI prettier / make color schemes
  	local JobTitle, Info1Title, Info2Title
  	local JobFunction, Info1Function, Info2Function
  	local ColorScheme
  	if CE.IsTTT() then
  		JobTitle, Info1Title, Info2Title = "Role", "Karma", "Credits"
  		local roles = { "Innocent", "Traitor", "Detective" }
  		JobFunction = function(ply) return roles[ply:GetRole()] end
  		Info1Function = function(ply) return ply:GetNWFloat("karma", 1000) end
  		Info2Function = function(ply) return ply:GetCredits() end
  	elseif CE.IsDarkRP() then
  		JobTitle, Info1Title, Info2Title = "Job", "Salary", "Wallet"
  		local RP = LocalPlayer().DarkRPVars
  		JobFunction = function(ply)
  		RP = RP or LocalPlayer().DarkRPVars
  		return RP and RP.job or "Loading" end
  		Info1Function = function(ply)
      RP = RP or LocalPlayer().DarkRPVars
      return GAMEMODE.Config.currency .. tostring(RP and RP.salary or 0):FormatMoney() end
  		Info2Function = function(ply)
      RP = RP or LocalPlayer().DarkRPVars
      return GAMEMODE.Config.currency .. tostring(RP and RP.money or 0):FormatMoney() end
  	else
  		JobTitle, Info1Title, Info2Title = "Team", "Frags", "Deaths"
  		JobFunction = function(ply) return team.GetName(ply:Team()) end
  		Info1Function = function(ply) return tostring(ply:Frags()) end
  		Info2Function = function(ply) return tostring(ply:Deaths()) end
  	end
  	local Scrh, Scrw, BaseX, BaseY, Width, Height
  	CE.Hook.Add("HUDPaint", "HUD", function()
  		if not CE.Session.HUDFrame or CE.Session.HUDFrame:IsVisible() then
  			local LP = LocalPlayer()
  			local Time = os.date("%I:%M:%S %p")
  			local Date = os.date( "%m/%d/20%y" )
  			local Ping = LP:Ping()
  			local FPS = math.floor(1/FrameTime())
  			local Health = LP:Health()
  			local Armor = LP:Armor()
  			local weapon = LP:GetActiveWeapon()
  			local vehicle = LP:GetVehicle()
  
  
  			Scrh, Scrw = ScrH(), ScrW()
  			BaseX, BaseY = 3, Scrh-67
  			Width, Height = 375, 65
  
  			local HostName = GetHostName()
  			local FullHostName = HostName
  			if HostName:find("|") then
  				HostName = HostName:sub(1,HostName:find("|")-1)
  			end
  			if HostName:find("\\(") then
  				HostName = HostName:sub(1,HostName:find("\\(")-1)
  			end
  			HostName = HostName:Trim()
  			local SteamID = LP:SteamID()
  
  			local ShowWeaponInfo = IsValid(weapon) and weapon.Primary and (weapon.Primary.ClipSize >= 0 or weapon.Secondary.ClipSize >= 0)
  			local ShowCarInfo = IsValid(vehicle)
  			if ShowWeaponInfo or ShowCarInfo then
  				ExpandX = math.Clamp(ExpandX+10, 0, 130)
  			else
  				ExpandX = math.Clamp(ExpandX-10, 0, 130)
  			end
  
  			-- Hostname Box + Text
  			draw.SmoothRoundedBoxEx( 3, BaseX, BaseY-12, Width, 12, Color( 0, 169, 255, 200 ), true, true, false, false )
  			draw.SimpleText( HostName, "Default", BaseX + math.floor(Width / 2), BaseY-13, Color( 0, 0, 0 ), TEXT_ALIGN_CENTER, 0 )
  
  			-- Weapon Box
  			if ExpandX > 0 then
  				draw.SmoothRoundedBoxEx( 0, BaseX+Width,BaseY,ExpandX,Height, Color( 50, 50, 50, 250 ), false, true, false, true )
  			end
  
  			-- Background Box
  			draw.SmoothRoundedBoxEx( 4, BaseX, BaseY, Width, Height, Color( 25, 25, 25, 250 ), false, false, true, true )
  
  			draw.SimpleText( "Health: " .. tostring(Health) .. "%", "Default", BaseX+12, BaseY+7, Color( 255, 0, 0, 155 ), 0, 0 )
  			DrawProgressBar(BaseX+12,BaseY+18,180,Health,Colors.RED,true)
  
  			draw.SimpleText( "Armor: " .. tostring(Armor) .. "%", "Default", BaseX+132, BaseY+7, Color( 200, 200, 0, 155 ), 0, 0 )
  			if Armor > 0 then
  				DrawProgressBar(BaseX+12,BaseY+24,180,Armor,Color( 200, 200, 0, 155 ), true)
  			end
  
  
  			draw.SimpleText( "Ping: " .. Ping, "Default", 15, Scrh-27, Color( 127, 255, 0, 150 ), 0, 0 )
  			DrawProgressBar(BaseX+12,Scrh-15,180,Ping,Color( 127, 255, 0, 155 ))
  
  			draw.SimpleText( "FPS:" .. FPS, "Default", 70, Scrh-27, Color( 255, 200, 0, 150 ), 0, 0 )
  			DrawProgressBar(BaseX+12,Scrh-9,270,FPS,Color( 255, 200, 0, 155 ))
  
  			draw.SimpleText( "Time: " .. Time, "Default", BaseX+3, Scrh-38, Color( 0, 169, 255, 150 ), 0, 0 )
  			draw.SimpleText( Date, "Default", BaseX+122, Scrh-38, Color( 0, 169, 255, 150 ), 0, 0 )
  
  
  			draw.SimpleText( JobTitle .. ":", "Default", BaseX+207, Scrh-60, Color( 0, 169, 255, 150 ), 0, 0 )
  			draw.SimpleText( JobFunction(LP), "Default", BaseX+232, Scrh-60, Color( 0, 169, 255, 150 ), 0, 0 )
  
  			draw.SimpleText( Info1Title .. ":", "Default", BaseX+207, Scrh-45, Color( 0, 169, 255, 150 ), 0, 0 )
  			draw.SimpleText( Info1Function(LP), "Default", BaseX+247, Scrh-45, Color( 0, 169, 255, 150 ), 0, 0 )
  
  			draw.SimpleText( Info2Title .. ":", "Default", BaseX+207, Scrh-30, Color( 0, 169, 255, 150 ), 0, 0 )
  			draw.SimpleText( Info2Function(LP), "Default", BaseX+247, Scrh-30, Color( 0, 169, 255, 150 ), 0, 0 )
  
  			draw.SimpleText( "SteamID: " .. SteamID, "Default", BaseX+207, Scrh-15, Color( 0, 169, 255, 150 ), 0, 0 )
  
  			if CE.IsDarkRP() then
  				local RP = LP.DarkRPVars or { }
  				if RP.HasGunlicense then
  					draw.SimpleText( "Gun License", "Default", BaseX+9, Scrh-92, Color( 255, 180, 0, 255 ), 0, 0 )
  				end
  				if RP.wanted then
  					draw.SimpleText( "You are wanted for: " .. ( RP.wantedReason or "Unknown reasons" ), "Default", BaseX+9, Scrh-101, Color( 255, 0, 0, 255 ), 0, 0 )
  				end
  			end
  
  			if ExpandX > 0 then
  				draw.Clip(378,Scrh-67,ExpandX,65)
  				if ShowCarInfo then
  					Clip1 = nil
  					car = vehicle
  				elseif ShowWeaponInfo then
  					Velocity = nil
  					Clip1 = weapon:Clip1()
  					Clip2 = weapon:Clip2()
  					PAmmoCount = LocalPlayer():GetAmmoCount(weapon:GetPrimaryAmmoType())
  					SAmmoCount = LocalPlayer():GetAmmoCount(weapon:GetSecondaryAmmoType())
  					PClipSize = weapon.Primary.ClipSize
  					SClipSize = weapon.Secondary.ClipSize
  					if SClipSize < 0 then SAmmoCount = -1 end
  					if PClipSize < 0 then PAmmoCount = -1 end
  					WeaponName = weapon:GetPrintName()
  				end
  				if not ShowWeaponInfo and IsValid(car) then
  					local Vehicles = list.Get('Vehicles')
  					CarName = "Car"
  					for k,v in pairs(Vehicles) do
  						if v.Model == car:GetModel() then
  							CarName = v.Name
  							break
  						end
  					end
  					local a = car:GetAngles()
  					local v = car:GetVelocity():Angle()
  					dev = math.sign(a.p) + math.sign(v.p)
  					Velocity = car:GetVelocity():Distance(Vector(0,0,0)) / 10
  				end
  				if Clip1 then
  					if Clip1 and Clip1 >= 0 then
  						draw.SimpleText( WeaponName, "Default", 380, Scrh-68, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( "Primary:", "Default", 380, Scrh-48, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( Clip1 .. " / " .. PAmmoCount, "Default", 450, Scrh-48, Color( 255, 255, 255, 255 ), 0, 0 )
  						DrawProgressBar(385,Scrh-34,110,Clip1 / PClipSize * 100, Color( 255, 200, 0, 155 ), true)
  					end
  					if Clip2 and Clip2 >= -1 then
  						draw.SimpleText( "Secondary:", "Default", 380, Scrh-29, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( Clip2 .. " / " .. SAmmoCount, "Default", 450, Scrh-29, Color( 255, 255, 255, 255 ), 0, 0 )
  						DrawProgressBar(385,Scrh-15,110,Clip2 / SClipSize * 100, Color( 255, 200, 0, 155 ), true)
  					end
  				elseif Velocity then
  						draw.SimpleText( CarName, "Default", 380, Scrh-60, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( dev, "Default", 430, Scrh-40, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( "Speed:", "Default", 380, Scrh-29, Color( 255, 255, 255, 255 ), 0, 0 )
  						draw.SimpleText( math.Round(Velocity) .. "m.p.h.", "Default", 430, Scrh-29, Color( 255, 255, 255, 255 ), 0, 0 )
  						DrawProgressBar(385,Scrh-15,110,Velocity / 200 * 100, Color( 255, 200, 0, 155 ), true)
  				end
  			end
  			draw.Clip()
  		end
  
  	end)
  
  	--debugger.SetUpvalue(HUDPaint, "DrawEntityDisplay", DrawEntityDisplay)
  	--debugger.SetUpvalue(DrawHUD, "Agenda", Agenda)
  end
  
  local lastDataRequested = 0
  function EM:DrawOwnableInfo()
  	if LocalPlayer():InVehicle() then return end
  
    -- Look, if you want to change the way door ownership is drawn, don't edit this file, use the hook instead!
    local doorDrawing = hook.Call("HUDDrawDoorData", nil, self)
    if doorDrawing == true then return end
  
    local blocked = self.getKeysNonOwnable and self:getKeysNonOwnable()
    local superadmin = LocalPlayer():IsSuperAdmin()
    local doorTeams = self:getKeysDoorTeams()
    local doorGroup = self:getKeysDoorGroup()
    local owned = self:isKeysOwned() or doorGroup or doorTeams
  
    local doorInfo = {}
      if self.DoorData == nil and lastDataRequested < (CurTime() - 0.7) then
        RunConsoleCommand("_RefreshDoorData", self:EntIndex())
        lastDataRequested = CurTime()
    
        return
      end
    local title = self:getKeysTitle()
    if title then table.insert(doorInfo, title) end
  
    if owned then
      table.insert(doorInfo, DarkRP.getPhrase("keys_owned_by"))
    end
  
    if self:isKeysOwned() then
      table.insert(doorInfo, self:getDoorOwner():Nick())
      for k,v in pairs(self:getKeysCoOwners() or {}) do
        local ent = Player(k)
        if IsValid(ent) and ent:IsPlayer() then
          table.insert(doorInfo, ent:Nick())
        end
      end
  
      local allowedCoOwn = self:getKeysAllowedToOwn()
      if allowedCoOwn and allowedCoOwn ~= nil then
        table.insert(doorInfo, DarkRP.getPhrase("keys_other_allowed"))
  
        for k,v in pairs(allowedCoOwn) do
          local ent = Player(k)
          if IsValid(ent) and ent:IsPlayer() then
            table.insert(doorInfo, ent:Nick())
          end
        end
      end
    elseif doorGroup then
      table.insert(doorInfo, doorGroup)
    elseif doorTeams then
      for k, v in pairs(doorTeams) do
        if v and RPExtraTeams[k] then
          table.insert(doorInfo, RPExtraTeams[k].name)
        end
      end
    elseif blocked and superadmin then
      table.insert(doorInfo, DarkRP.getPhrase("keys_allow_ownership"))
    elseif not blocked then
      table.insert(doorInfo, DarkRP.getPhrase("keys_unowned"))
      if superadmin then
        table.insert(doorInfo, DarkRP.getPhrase("keys_disallow_ownership"))
      end
    end
  
    if self:IsVehicle() then
      for k,v in pairs(player.GetAll()) do
        if v:GetVehicle() == self then
          table.insert(doorInfo, DarkRP.getPhrase("driver", v:Nick()))
        end
      end
    end
    if LocalPlayer():GetPos():Distance(self:GetPos()) > 200 then
      table.insert(doorInfo, "\n* Out of range *")
    end
  
    local x, y = ScrW()/2, ScrH() / 2
    draw.DrawText(table.concat(doorInfo, "\n"), "TargetID", x , y + 1 , CE.Colors.BLACK, 1)
    draw.DrawText(table.concat(doorInfo, "\n"), "TargetID", x, y, (blocked or owned) and CE.Colors.WHITE or CE.Colors.RED, 1)
  end
    
    
  local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
  local localplayer = LocalPlayer()
  local function DrawVoiceChat()
  	if localplayer.DRPIsTalking then
  		local chbxX, chboxY = chat.GetChatBoxPos()
  
  		local Rotating = math.sin(CurTime()*3)
  		local backwards = 0
  		if Rotating < 0 then
  			Rotating = 1-(1+Rotating)
  			backwards = 180
  		end
  		surface.SetTexture(VoiceChatTexture)
  		surface.SetDrawColor(Colors.YELLOW)
  		surface.DrawTexturedRectRotated(ScrW() - 100, chboxY, Rotating*96, 96, backwards)
  	end
  end
  
  local function LockDown()
  	local chbxX, chboxY = chat.GetChatBoxPos()
  	if CE.GetConVarBool("DarkRP_LockDown") then
  		local cin = (math.sin(CurTime()) + 1) / 2
  		local chatBoxSize = math.floor(ScrH() / 4)
  		draw.DrawText(DarkRP.getPhrase("lockdown_started"), "ScoreboardSubtitle", chbxX, chboxY + chatBoxSize, Color(cin * 255, 0, 255 - (cin * 255), 255), TEXT_ALIGN_LEFT)
  	end
  end
  
  local Arrested = function() end
  
  usermessage.Hook("GotArrested", function(msg)
  	local StartArrested = CurTime()
  	local ArrestedUntil = msg:ReadFloat()
  
  	Arrested = function()
  		if CurTime() - StartArrested <= ArrestedUntil and localplayer:getDarkRPVar("Arrested") then
  			draw.DrawText(DarkRP.getPhrase("youre_arrested", math.ceil(ArrestedUntil - (CurTime() - StartArrested))), "DarkRPHUD1", ScrW()/2, ScrH() - ScrH()/12, Color(255,255,255,255), 1)
  		elseif not localplayer:getDarkRPVar("Arrested") then
  			Arrested = function() end
  		end
  	end
  end)
  
  local AdminTell = function() end
  
  usermessage.Hook("AdminTell", function(msg)
  	local Message = msg:ReadString()
  
  	AdminTell = function()
  		draw.RoundedBox(4, 10, 10, ScrW() - 20, 100, Color(0, 0, 0, 200))
  		draw.DrawText(DarkRP.getPhrase("listen_up"), "GModToolName", ScrW() / 2 + 10, 10, Color(255, 255, 255, 255), 1)
  		draw.DrawText(Message, "ChatFont", ScrW() / 2 + 10, 80, Color(200, 30, 30, 255), 1)
  	end
  
  	timer.Simple(10, function()
  		AdminTell = function() end
  	end)
  end)
  
  local function DrawHUD()
  	localplayer = localplayer and IsValid(localplayer) and localplayer or LocalPlayer()
  	if not IsValid(localplayer) then return end
  
  	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_HUD")
  	if shouldDraw == false then return end
  
  	DrawVoiceChat()
  	LockDown()
  
  	Arrested()
  	AdminTell()
  end
  
  
  
  local function DrawWantedInfo(ply)
  	if not ply:Alive() then return end
  
  	local pos = ply:EyePos()
  	if not pos:RPIsInSight({localplayer, ply}) then return end
  
  	pos.z = pos.z + 14
  	pos = pos:ToScreen()
  
  	draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
  	draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
  
  	local wantedText = DarkRP.getPhrase("wanted", tostring(ply:getDarkRPVar("wantedReason")))
  
  	draw.DrawText(wantedText, "DarkRPHUD2", pos.x, pos.y - 40, Color(255, 255, 255, 200), 1)
  	draw.DrawText(wantedText, "DarkRPHUD2", pos.x + 1, pos.y - 41, Color(255, 0, 0, 255), 1)
  end
  
  
  local function DrawPlayerInfo(ply)
  	local pos = ply:EyePos()
  
  	pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
  	pos = pos:ToScreen()
  	pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text
  
  	if not ply:getDarkRPVar("wanted") then
  		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
  		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
  		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
  		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
  	end
  
  	local teamname = team.GetName(ply:Team()) .. " " .. ply:GetTag()
  	draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
  	draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
  
  
  	if ply:getDarkRPVar("HasGunlicense") then
  		surface.SetMaterial(Page)
  		surface.SetDrawColor(255,255,255,255)
  		surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
  	end
  end
  local function DrawEntityDisplay()
  	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_EntityDisplay")
  	if shouldDraw == false then return end
  
  	local shootPos = localplayer:GetShootPos()
  	local aimVec = localplayer:GetAimVector()
  
  	for k, ply in pairs(player.GetAll()) do
  		if ply:Alive() then
  			local hisPos = ply:GetShootPos()
  			if ply:getDarkRPVar("wanted") then DrawWantedInfo(ply) end
  
  			if GAMEMODE.Config.globalshow and ply ~= localplayer then
  				DrawPlayerInfo(ply)
  				-- Draw when you're (almost) looking at him
  			elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
  				local pos = hisPos - shootPos
  				local unitPos = pos:GetNormalized()
  				if unitPos:Dot(aimVec) > 0.97 then
  					local trace = util.QuickTrace(shootPos, pos, localplayer)
  					if trace.Hit and trace.Entity ~= ply then return end
  					DrawPlayerInfo(ply)
  				end
  			end
  		end
  	end
  
  	local tr = localplayer:GetEyeTrace()
  
  	-- Because it never checks serverside if you're close enough
  	if IsValid(tr.Entity) and tr.Entity:IsOwnable() and tr.Entity:GetPos():Distance(localplayer:GetPos()) < 2000 then
  		tr.Entity:DrawOwnableInfo()
  	end
  end
  local function Agenda()
  	local DrawAgenda, AgendaManager = DarkRPAgendas[localplayer:Team()], localplayer:Team()
  	if not DrawAgenda then
  		for k,v in pairs(DarkRPAgendas) do
  			if table.HasValue(v.Listeners or {}, localplayer:Team()) then
  				DrawAgenda, AgendaManager = DarkRPAgendas[k], k
  				break
  			end
  		end
  	end
  	draw.RoundedBox(10, 10, 10, 460, 110, Color(0, 0, 0, 155))
  	draw.RoundedBox(10, 12, 12, 456, 106, Color(51, 58, 51,100))
  	draw.RoundedBox(10, 12, 12, 456, 20, Color(0, 0, 70, 100))
  
  	draw.DrawText(DrawAgenda and DrawAgenda.Title or "Agendas", "DarkRPHUD1", 30, 12, Color(255,0,0,255),0)
  	local FootnoteSymbols = {"¹","²","³","⁴","⁵","⁶","⁷","⁸","⁹"}
  	local Footnotes = { }
  	local AgendaText = { }
  	local teamPlayers = team.GetPlayers(AgendaManager)
  	if not DrawAgenda then teamPlayers = { } end
  	for k,v in pairs(teamPlayers) do
  		if v.DarkRPVars and v:getDarkRPVar("agenda") then
  			table.insert(AgendaText, v:Nick()..": "..tostring(v:getDarkRPVar("agenda")))
  		end
  	end
  	for k,v in pairs(player.GetAll()) do
  		if v.DarkRPVars and not table.containsValue(teamPlayers, v) and DarkRPAgendas[v:Team()] and v:getDarkRPVar("agenda") then
  			local footnote = table.KeyFromValue(Footnotes, v:Team())
  			if not footnote then
  				footnote = #Footnotes+1
  				Footnotes[footnote]=DarkRPAgendas[v:Team()].Title
  			end
  			footnote = FootnoteSymbols[footnote]
  			table.insert(AgendaText, v:Nick()..footnote..": "..tostring(v:getDarkRPVar("agenda")))
  		end
  	end
  	for idx,title in pairs(Footnotes) do
  		table.insert(AgendaText, FootnoteSymbols[idx]..title)
  	end
  
  	local text = table.concat(AgendaText, "\n")
  	text = text:gsub("//", "\n"):gsub("\\n", "\n")
  	text = GAMEMODE:TextWrap(text, "DarkRPHUD1", 440)
  	draw.DrawText(text, "DarkRPHUD1", 30, 35, Color(255,255,255,255),0)
  end
  
  local function DrawEntityDisplay()
  	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_EntityDisplay")
  	if shouldDraw == false then return end
  	local shootPos = localplayer:GetShootPos()
  	local aimVec = localplayer:GetAimVector()
  
  	for k, ply in pairs(player.GetAll()) do
  		if ply:Alive() then
  			local hisPos = ply:GetShootPos()
  			if ply:getDarkRPVar("wanted") then DrawWantedInfo(ply) end
  
  			if GAMEMODE.Config.globalshow and ply ~= localplayer then
  				DrawPlayerInfo(ply)
  				-- Draw when you're (almost) looking at him
  			elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
  				local pos = hisPos - shootPos
  				local unitPos = pos:GetNormalized()
  				if unitPos:Dot(aimVec) > 0.97 then
  					local trace = util.QuickTrace(shootPos, pos, localplayer)
  					if trace.Hit and trace.Entity ~= ply then return end
  					DrawPlayerInfo(ply)
  				end
  			end
  		end
  	end
  
  	local tr = localplayer:GetEyeTrace()
  
  	-- Because it never checks serverside if you're close enough
  	if IsValid(tr.Entity) and tr.Entity.IsOwnable and tr.Entity:IsOwnable() and tr.Entity:GetPos():Distance(localplayer:GetPos()) < 2000 then
  		tr.Entity:DrawOwnableInfo()
  	end
  end
  if not GM._HUDPaint then GM._HUDPaint = GM.HUDPaint end
  
  function GM:HUDPaint()
  	DrawHUD()
  	DrawEntityDisplay()
  	
  	self.BaseClass:HUDPaint()
  end
end