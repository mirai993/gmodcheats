MODULE.ID = "com.continuum.radar"
MODULE.Dependencies = { }

MODULE.Name = "Radar"
MODULE.Info = "Radar with people on it"
MODULE.cvars = {{ Name="hacks_radar", Nick="Radar", Info="Draws a radar map on your screen", Default="0", HUD={ Category="Misc", Type="ToggleButton"}}}

MODULE.Init = function(CE)
  local width = ScrW()
  local height = ScrH()
  local RadarOffset = {x= 20--[[width-340]],y=30}
  local function VectorToLPCameraScreen( vDir, iScreenW, iScreenH, angCamRot, fFoV )
    --Same as we did above, we found distance the camera to a rectangular slice of the camera's frustrum, whose width equals the "4:3" width corresponding to the given screen height.
    local d = 4 * iScreenH / ( 6 * math.tan( 0.5 * fFoV ) );
    local fdp = angCamRot:Forward():Dot( vDir );

    --fdp must be nonzero ( in other words, vDir must not be perpendicular to angCamRot:Forward() )
    --or we will get a divide by zero error when calculating vProj below.
    if fdp == 0 then
      return 0, 0, -1
    end

    --Using linear projection, project this vector onto the plane of the slice
    local vProj = ( d / fdp ) * vDir;

    --Dotting the projected vector onto the right and up vectors gives us screen positions relative to the center of the screen.
    --We add half-widths / half-heights to these coordinates to give us screen positions relative to the upper-left corner of the screen.
    --We have to subtract from the "up" instead of adding, since screen coordinates decrease as they go upwards.
    local x = 0.5 * iScreenW + angCamRot:Right():Dot( vProj );
    local y = 0.5 * iScreenH - angCamRot:Up():Dot( vProj );

    --Lastly we have to ensure these screen positions are actually on the screen.
    local iVisibility
    if fdp < 0 then     --Simple check to see if the object is in front of the camera
      iVisibility = -1;
    elseif x < 0 or x > iScreenW or y < 0 or y > iScreenH then  --We've already determined the object is in front of us, but it may be lurking just outside our field of vision.
      iVisibility = 0;
    else
      iVisibility = 1;
    end

    return x --[[* 3/4.8]], y, iVisibility;
  end
  local angleDistances = { }
  local theta = 0
  --local radarMat = CreateMaterial( "hacks/mat/radar", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite" } );

  CE.Hook.Remove("Think", "RadarRender")
  surface.CreateFont("RadarListFont2", {
    font="Tahoma",
    size=15,
    weight=300,
    antialias=true
  })
  surface.CreateFont("RadarIDFont3", {
    font="Tahoma",
    size=10,
    weight=300,
    antialias=true
  })
  CE.Hook.Add("HUDPaint", "Radar", function()
    if not CE.GetConVarBool("hacks_radar") then return end
    local SIZE = 160
    local Data = hook.Run( "CalcView", LocalPlayer(), EyePos(), EyeAngles(), 75 )
    local Position = Data.origin or EyePos()
    local Angles = Data.angles or EyeAngles()
    local FOV = LocalPlayer():GetFOV() == 75 and Data.fov or LocalPlayer():GetFOV()
    local ratio = math.pow(FOV,1.1) / 115
    local CamData = {}
    CamData.origin = Vector(Position.x,Position.y, 10000)
    CamData.angles = CamData.origin:AngleTo(LocalPlayer():GetPos())
    CamData.angles.y = Angles.y
    CamData.x = RadarOffset.x
    CamData.y = RadarOffset.y
    CamData.w = SIZE * 2-- * 4.8/3
    CamData.h = SIZE * 2
    CamData.ortholeft = -2000;
    CamData.orthoright = 2000;
    CamData.orthotop = -2000;
    CamData.orthobottom = 2000;
    --CamData.fov = 6
    CamData.ortho = true
    CamData.drawviewmodel = false
    CamData.drawhud = false
    LocalPlayer():SetNoDraw(false)
    render.DrawLocalPlayer = true
    render.RenderView( CamData )
    render.DrawLocalPlayer = nil
    surface.SetDrawColor(CE.Colors.WithAlpha(CE.Colors.GREEN, 100))
    surface.SetMaterial()
    surface.SetTexture(0)
    surface.DrawLine( CamData.x, CamData.y+CamData.h/2, CamData.x+CamData.w, CamData.y+CamData.h/2)
    surface.DrawLine( CamData.x+CamData.w/2, CamData.y, CamData.x+CamData.w/2, CamData.y+CamData.h)

    surface.DrawLine( CamData.x+CamData.w/2, CamData.y+CamData.h/2, CamData.x+CamData.w/2, CamData.y)
    surface.DrawLine( CamData.x+CamData.w/2, CamData.y+CamData.h/2, CamData.x+CamData.w/2-math.tan(math.rad(42))*CamData.h/2, CamData.y)
    surface.DrawLine( CamData.x+CamData.w/2, CamData.y+CamData.h/2, CamData.x+CamData.w/2+math.tan(math.rad(42))*CamData.h/2, CamData.y)
    
    
    Angles.p = 0
    Position.z = 0
    Angles.y = Angles.y + 180
    --theta = theta+.2
    --if theta > math.pi * 2 then theta = theta - math.pi * 2 end
    --angleDistances[theta]=-1
    --local x = math.cos(theta) * CamData.h/2
    --local y = math.sin(theta) * CamData.h/2
    --surface.DrawLine(CamData.x+CamData.w/2, CamData.y+CamData.h/2, CamData.x+CamData.w/2+x, CamData.y+CamData.h/2+y)
    --surface.DrawLine(Relative.x + x, Relative.y + y)
    local tbl = player.GetAll()
    if CE.Session.WorldEdit then
      tbl[CE.Session.WorldEdit:EntIndex()] = CE.Session.WorldEdit
      --[[for i=200,250 do
        if IsValid(Entity(i)) then
        tbl[i] = Entity(i)
        end
      end]]
    end
    local function describe(k,v)
      return "[" .. v:EntIndex() .. "] " .. (v.Name and v:Name() or v:GetClass())
    end
    local widthNeeded = 0
    local columnWidth = 0
    local y = 10
    surface.SetFont("RadarListFont2")
    for k,v in pairs(tbl) do
      local text = describe(k,v)
      local w,h = surface.GetTextSize(text)
      h = 15
      columnWidth = math.max(w+30, columnWidth)
      if y+h > CamData.h then
        widthNeeded = widthNeeded + columnWidth
        columnWidth = 0
        y = 0
      end
      y = y + h
    end
    widthNeeded = widthNeeded + columnWidth
    draw.RoundedBox(0, CamData.x+CamData.w, CamData.y, widthNeeded, SIZE*2, Color(25,25,25,150))
    
    local x = 10
    columnWidth = 0
    y = 10
    for k,v in pairs(tbl) do
      local text = describe(k,v)
      local w,h = surface.GetTextSize(text)
      h = 15
      if y+h > CamData.h then
        y = 10
        x = x + columnWidth
      end
      columnWidth = math.max(w+30, columnWidth)
      local col = CE.Colors.WHITE
      if v:IsPlayer() then
        if not v:Alive() then
          col = CE.Colors.DGRAY
        elseif v:IsSpectating() then
          col = CE.Colors.DGRAY
        else
          col = v:GetRoleColor()
        end
        --col = (v:Alive() and not v:IsSpectating()) and CE.Colors.GREEN or CE.Colors.GREY
      end
      
      draw.DrawText(text, "RadarListFont2", CamData.x+CamData.w+x+10, CamData.y+y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
      y = y + h
      if (not v.Alive or v:Alive()) and (not v.IsSpec or not v:IsSpec()) then
        local Relative = v:EyePos() - Position
        --Relative.z = 0
        local col
        if v == LocalPlayer() then
          col = CE.Colors.WHITE
        else
          col = v.GetRoleColor and v:GetRoleColor() or CE.Colors.BLACK
        end
        surface.SetDrawColor(col)
        --local AnglesClone = Angle(0, Angles.y, 0)
        --Relative:Rotate(AnglesClone)
        local t = v:GetPos()
        --t.z = 0
        local a = Angle(90, CamData.angles.y, CamData.angles.r)
        --a.y = t:AngleTo(CamData.origin).y
        local x,y, vis = (CamData.origin-t).x/CamData.orthobottom, (CamData.origin-t).y/CamData.orthobottom, true--VectorToLPCameraScreen(CamData.origin - t, CamData.w--[[* 4.8/3]]--[[ * 4.8/3]], CamData.h, a, math.rad(5)--[\[math.rad(CamData.fov or 75)]\])
        --print(x, ";", y)
        local flip = false
        if x < 0 then
          flip = true
        end
        local otheta = math.pi/2
        if x ~= 0 then
          otheta = math.atan(y/x)
        end
        local r = math.sqrt(x^2+y^2)
        local theta = math.rad(CamData.angles.y) - otheta
        --print(math.deg(theta))
        x = -math.sin(theta)*r
        y = math.cos(theta)*r
        if flip then
          local ox = x
          local oy = y
          x = -x
          y = -y
        end
        x = (x+1) * CamData.w/2
        y = (y+1) * CamData.h/2
        --print(x)
        --print(y)
        --x = (x-SIZE) * 3 / 4.8 + SIZE
        --y = (y-SIZE) * 3 / 4.8 + SIZE
        --y = ((y - SIZE) / 2) + SIZE
        Relative = {x = x - CamData.w/2,y = y - CamData.h/2}

        Relative.x = Relative.x
        Relative.y = Relative.y


        if vis and math.abs(Relative.x) < SIZE --[[* 4.8/3]] and math.abs(Relative.y) < SIZE then
          -- console.Print(x, " ", y)
          -- Relative:Rotate(Angle(0,Angles.y,0))
          Relative.x = Relative.x + RadarOffset.x + SIZE
          Relative.y = Relative.y + RadarOffset.y + SIZE
          local length = 5
          for dy=-length,length do
            surface.DrawLine( Relative.x - length - 1, Relative.y + dy, Relative.x + length + 1, Relative.y + dy )
          end
          surface.SetDrawColor(CE.Colors.Darker(v.GetRoleColor and v:GetRoleColor() or CE.Colors.BLACK))
          surface.DrawLine( Relative.x - length - 1, Relative.y - length - 1, Relative.x + length + 1, Relative.y-length-1)
          surface.DrawLine( Relative.x - length - 1, Relative.y + length + 1, Relative.x + length + 1, Relative.y+length+1)
          surface.DrawLine( Relative.x - length - 1, Relative.y - length - 1, Relative.x - length - 1, Relative.y+length+1)
          surface.DrawLine( Relative.x + length + 1, Relative.y - length - 1, Relative.x + length + 1, Relative.y+length+1)


          local mod = math.abs(math.sin(SysTime() * 2))
          local col = CE.Colors.Darker(v.GetRoleColor and v:GetRoleColor() or CE.Colors.BLACK)
          --[[if SysTime() * 2 % math.pi * 2 < math.pi then
            surface.DrawCircle(Relative.x, Relative.y, mod * 10 + length + 1, CE.Colors.WithAlpha(col, 50))
          end]]
          local inverse = CE.Colors.Inverse(col)
          draw.DrawText(v:EntIndex(), "RadarIDFont3", Relative.x - 2,Relative.y - 7, inverse, TEXT_ALIGN_CENTER)

          --surface.DrawLine( Relative.x - length, Relative.y - length, Relative.x + length, Relative.y + length )
          --surface.DrawLine( Relative.x - length, Relative.y + length, Relative.x + length, Relative.y - length )
        end
      end
      
    end

  end)
end