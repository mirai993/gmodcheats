MODULE.ID = "com.continuum.antiban"
MODULE.Dependencies = { "com.continuum.notify", "com.continuum.modulemods"}

MODULE.Name="Antiban"
MODULE.Info="Antiban collection"
MODULE.Init = function(CE)
  local CurTime = CurTime
  local time = os.time
  
  local admins = CE.GetAdmins()
  local names = { }
  for k,v in pairs(admins) do
    v._CEAdminFlagged = true
    names[v] = v:Nick()
  end
  CE.SetPersistant("UsersData", {})
  timer.Create("CE.PrintAdminStateChange", 1, 0, function()
    --[[local UsersData = CE.GetPersistant("UsersData", { })
    local RequiresSave = false
    local CurrentTimeStamp = time()
    local players = player.GetAll()
    for k,v in pairs(players) do
      local UserData = UsersData[v:SteamID()]
      if v:IsConnected() and (not UserData or UserData[5] + 60 <= CurrentTimeStamp) then
        RequiresSave = true
        break
      end
    end
    if RequiresSave then
      for k,v in pairs(players) do
        local Data = {
          [0]=v:SteamID(),
          [1]=v.SteamName and v:SteamName() or v:Nick(),
          [2]=v:Nick(),
          [3]=v:GetFriendStatus(),
          [4]=v.GetUserGroup and v:GetUserGroup() or "None",
          [5]=CurrentTimeStamp,
        }
        Data[6] = CE.IsDarkRP() and v:GetMoney() or UsersData[v:SteamID()] and UsersData[v:SteamID()][6] or 0
  
        UsersData[v:SteamID()] = Data
      end
      CE.SetPersistant("UsersData", UsersData)
    end]]
  
    local newadmins = CE.GetAdmins()
    local adminsDidChange = false
    for _,admin in pairs(admins) do
      local foundAdmin = false
      for __,newadmin in pairs(newadmins) do
        if not newadmin._CEAdminFlagged then
          CE.Notify.All(CE.Colors.BLUE, newadmin:GetAdminType().." ",CE.Colors.RED, newadmin:Nick(),CE.Colors.BLUE, " has joined the server!")
          names[newadmin] = newadmin:Nick()
          adminsDidChange = true
          newadmin._CEAdminFlagged = true
        end
        if admin == newadmin then
          foundAdmin = true
          break
        end
      end
      if not foundAdmin then
        CE.Notify.All(CE.Colors.BLUE, "Admin", " ",CE.Colors.RED, names[admin],CE.Colors.BLUE, " has left the server!")
        adminsDidChange = true
      end
      if IsValid(admin) then
        admin.FriendStatus = admin.FriendStatus or admin:GetFriendStatus()
    
        if (admin:CanBan() or admin:IsAdmin()) and admin:IsSpectatingLocalPlayer() and admin.FriendStatus ~= "friend" then
          RunConsoleCommand("-hacks_speedhack")
          RunConsoleCommand("hacks_aimbot", "0")
          RunConsoleCommand("hacks_aimbotv2", "0")
        end
      end
    end
    if adminsDidChange then
      CE.Notify.All(CE.Colors.BLUE, "There are now ",CE.Colors.RED, tostring(#newadmins),CE.Colors.BLUE, " admins in the server!")
    end
    admins = newadmins
  end)
  timer.Create("CE.AFKCheck", 1, 0, function()
    for k,v in pairs(player.GetAll()) do
      local Position = v:GetPos()
      local Angles = v:EyeAngles()
      local MousePos = v.GetCursorAimVector and v:GetCursorAimVector()
      local IsTyping = v.IsTyping and v:IsTyping()
      local IsSpeaking = v.IsSpeaking and v:IsSpeaking()
      if MousePos == v:GetAimVector() then MousePos = nil end
      if v.AFKTracking then
        local DidMove = false
        DidMove = DidMove or Position ~= v.LastPosition
        DidMove = DidMove or Angles ~= v.LastAngles
        DidMove = DidMove or MousePos ~= v.LastMousePos
        DidMove = DidMove or IsTyping ~= v.LastIsTyping
        DidMove = DidMove or IsSpeaking ~= v.LastIsSpeaking
        if DidMove then v.LastMovement = CurTime() end
      else
        v.AFKTracking = true
        v.LastMovement = CurTime()
      end
      v.LastPosition = Position
      v.LastAngles = Angles
      v.LastMousePos = MousePos
      v.LastIsTyping = IsTyping
      v.LastIsSpeaking = IsSpeaking
      v.AFK = CurTime() > v.LastMovement + 20 -- 20 seconds of no apparent movement = AFK
    end
  end)
  local PM = FindMetaTable("Player")
  local TAngles = Angle(0,0,0)
  local LaserStart = Vector(0,0,0)
  local LaserEnd = Vector(0,0,0)
  function PM:IsLookingAt(Player)
    local originalSelf = self
    if self:GetViewEntity() ~= self then self = self:GetViewEntity() end
    if self == Player then return false end
    local selfAngles-- = self:GetAngles()
    if Player:IsPlayer() or true then selfAngles = self:EyeAngles() end
    local angleBetween = (self:EyePos()-Player:GetShootPos()):Angle() - self:EyeAngles()
    angleBetween = angleBetween + Angle(0,180,0)
    angleBetween.p = angleBetween.p % 360
    angleBetween.y = angleBetween.y % 360
    if angleBetween.p > 180 then angleBetween.p = angleBetween.p - 360 end
    if angleBetween.y > 180 then angleBetween.y = angleBetween.y - 360 end
    angleBetween = angleBetween * -1
    local pos = Player:LocalToWorld(Player:OBBCenter())
    local tracedata = {}
    tracedata.endpos = self:EyePos()
    local plys = { }
    for k,v in pairs(player.GetAll()) do
      if v ~= self then table.insert(plys, v) end
    end
    tracedata.filter = plys
    tracedata.mask = MASK_SHOT - CONTENTS_TRANSLUCENT--CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
    local DidHit = false
    tracedata.start = pos
    DidHit = DidHit or util.TraceLine(tracedata).Entity == self
    tracedata.start = pos + Vector(0,0,20)
    DidHit = DidHit or util.TraceLine(tracedata).Entity == self
    tracedata.start = pos - Vector(0,0,20)
    DidHit = DidHit or util.TraceLine(tracedata).Entity == self
    -- Why do 3 traces? Bc we cant define being visible as just our chest being visible; we should fire traces to our legs and upper body too
    angleBetween.p = math.abs(angleBetween.p)
    angleBetween.y = math.abs(angleBetween.y)
    local p,y=math.abs(angleBetween.p),math.abs(angleBetween.y)
    if p > 180 then p = math.abs(p - 360) end
    if self == CE.WorldEdit or Player == CE.WorldEdit then
      TAngles=angleBetween
    end
    local fov = 75
    return p < originalSelf:GetFOV()*.43 and y < originalSelf:GetFOV()*.6 and DidHit
  end
  timer.Create("CE.FriendStatusUpdate", 120, 0, function()
    for _,ply in pairs(player.GetAll()) do
      ply.FriendStatus = ply:GetFriendStatus()
    end
  end)
  function PM:GetTag()
    local tag = ""
    if self.AFK then tag = tag .. " AFK" end
    if self:GetUserGroup() and self:GetUserGroup() ~= "user" then tag = tag .. " " .. self:GetUserGroup() end
    self.FriendStatus = self.FriendStatus or self:GetFriendStatus()
    if self.FriendStatus ~= "none" then tag = tag .. " " .. self.FriendStatus end
    if self:GetViewEntity():GetClass():lower():find("camera") then tag = tag .. " Camera" end
    if tag == "" then return tag end
    return "[" .. tag:sub(2) .. "]"
  end
  MODULE.AddCmd({
    name="hacks_admins",
    nick="Admin Print",
    NoArgs=true,
    info="Prints a list of admins",
    func=function()
      for k,v in pairs(player.GetAll()) do
        if v:IsSuperAdmin() then
          print(v:Nick().." is a Super Admin")
        elseif v:IsAdmin() then
          print(v:Nick().." is an Admin")
        elseif v:CanBan() then
          print(v:Nick().." can ban people")
        elseif v:CanKick() then
          print(v:Nick().." can kick people")
        elseif v:CanSlay() then
          print(v:Nick().." can slay people")
        end
      end
    end
  })
  -- TODO: Fix this
  local function pad(str, tablength)
    str = tostring(str)
    for tabcount=math.round(#str / 5),tablength do
      str = str.."\t"
    end
    return str
  end
  local function padSpaces(str, length)
    str = tostring(str)
    for _=#str,length do
      str = str.." "
    end
    return str
  end
  MODULE.AddCmd({
    name="hacks_who",
    nick="Who",
    NoArgs=true,
    info="Prints a list of players (essentially ulx who)",
    func=function()
      CE.Console.AddText(CE.Colors.CONTINUUM,"Nick\t\t\t\t\t\tGroup\t\tSteam ID\t\t\t\tTeam\n")
      CE.Console.AddText(CE.Colors.CONTINUUM,"-------------------------------------------------------------------------------\n")
      for k,v in pairs(player.GetAll()) do
        local nick = pad(v:Nick(), 6)
        if #v:Nick() == 12 then nick = string.sub(nick, 0, #nick-1) end
        if #v:Nick() == 8 or #v:Nick() == 9 then nick = nick .. "\t" end
        nick = nick .. " "
        local group = pad(v.GetUserGroup and v:GetUserGroup() or "none", 3).." "
        local groupclr = CE.Colors.GREEN
        if ULib and ULib.ucl and (ULib.ucl.query(v, "ulx kick") or ULib.ucl.query(v, "ulx voteban")) then
          groupclr = CE.Colors.YELLOW
        end
        if ULib and ULib.ucl and ULib.ucl.query(v, "ulx ban") then
          groupclr = CE.Colors.RED
        end
        local steamid = pad(padSpaces(v:SteamID(), 18), 5)
        local teamclr = v:GetRoleColor()
        local team = pad(v:GetTeamName(), 2)
        CE.Console.AddText(CE.Colors.BLACK, nick, groupclr, group, CE.Colors.BLACK, steamid)
  
        MsgC(teamclr, team, "\n")
      end
    end
  })
  MODULE.AddCmd({
    name="hacks_propcheck",
    nick="Prop Check",
    NoArgs=true,
    info="Checks how many props each player has",
    func=function()
      for k,v in pairs(player.GetAll()) do
        CE.Console.AddText(v:Nick(), ": PropCount=", v:GetNetworkedInt('Count.Props'), "\n")
      end
    end
  })
  local function getCommand(commandName)
    for category, cmds in pairs( ulx.cmdsByCategory ) do
      for _, cmd in ipairs( cmds ) do
        if cmd.cmd == commandName then
          return cmd
        end
      end
    end
    return nil
  end
  MODULE.AddCmd({
    name="hacks_ulxcheck",
    nick="ULX Check",
    NoArgs=true,
    info="Checks what ULX commands a player can use",
    func=function(ply,name,args)
      if #args > 1 then
        print("Command expects 0 or 1 arguments, the player to spectate (none defaults to self)")
        return
      end
      local plys = CE.AutocompletePlayers(args[1], true)
      if plys then
        if #plys > 1 then
          CE.Console.Warning("Found multiple players matching '"..args[1].."'")
          return
        end
        local ply = plys[1]
        local commands = ply:GetCommands()
        CE.Console.AddText("Commands for ",ply:Nick()," [", ply:GetUserGroup() or "none", "]:\n")
        for _,command in pairs(ply:GetCommands()) do
          local cmd = getCommand(command)
          if cmd then
            local usage
            if not cmd.manual then
              usage = cmd:getUsage( ply )
            else
              usage = cmd.helpStr
            end
            CE.Console.AddText("\to ", command, " ", usage, "\n")
          else
            CE.Console.AddText("\to ", command, "\n")
          end
        end
      else
        CE.Console.Warning("No players matching '"..args[1].."' found!")
        return
      end
    end,
    autocomplete=function(name,args)
      args = args:sub(2)
      local argstr = args
      if args:ends(" ") then
        args = string.split(args, " ")
        args[#args+1]=""
      else
        args = string.split(args, " ")
      end
      local res = { }
      local str = name.." "
      args[1] = args[1] or ""
      if #args <= 1 then
        local plys = CE.AutocompletePlayers(args[1], true)
        if plys then
          for _,val in CE.PairsByKeys(plys) do
            table.insert(res, str.."\""..val:Nick().."\"")
          end
        end
      end
      return res
    end
  })
  local CATEGORIES = false
  local function FindMatches(searchArgs)
    local matches = { }
    local autocompletes = { }
    local IsMatch
    if CATEGORIES and searchArgs:find(":") then
      local category,text = searchArgs:sub(1,searchArgs:find(":")-1), searchArgs:sub(searchArgs:find(":")+1)
      category = category:lower()
      IsMatch = function(v)
        if category == "steamid" then
          return v.SteamID:search(text), category .. ":" .. v.SteamID
        elseif category == "steamname" or category == "name" then
          return v.SteamName:search(text), category .. ":" .. v.SteamName
        elseif category == "nick" then
          return v.Nick:search(text), category .. ":" .. v.Nick
        elseif category == "group" or category == "ulx" or category == "rank" or category == "usergroup" then
          return v.ULXGroup and v.ULXGroup:search(text), category .. ":" .. tostring(v.ULXGroup)
        elseif category == "friend" then
          return v.FriendStatus and v.FriendStatus:search(text), category .. ":" .. tostring(v.FriendStatus)
        else
          return v.SteamID:search(searchArgs) or v.Nick:search(searchArgs) or v.SteamName:search(searchArgs) or v.ULXGroup and v.ULXGroup:search(searchArgs), v.Nick
        end
      end
    else
      IsMatch = function(v)
        return v.SteamID:search(searchArgs) or v.Nick:search(searchArgs) or v.SteamName:search(searchArgs) or v.ULXGroup and v.ULXGroup:search(searchArgs), v.Nick
      end
    end
    for k,v in pairs(CE.GetPersistant("UsersData")) do
      v.SteamID = v[0]
      v.SteamName = v[1]
      v.Nick = v[2]
      v.FriendStatus = v[3]
      v.ULXGroup = v[4]
      v.Timestamp = v[5]
      v.Money = v[6]
      local match, autocomplete = IsMatch(v)
      if match then
        autocompletes[autocomplete .. "_" .. v.SteamID] = autocomplete
        matches[v.Nick .. "_" .. v.SteamID] = v
      end
    end
    return matches, autocompletes
  end
  MODULE.AddCmd({
    name="hacks_lookup",
    Nick="Lookup",
    Function=function(ply,cmd,args, argString)
      argString = argString:Replace("\"", "")
      local tbl = FindMatches(argString)
      for _,v in CE.PairsByKeys(tbl) do
        CE.Console.AddText(CE.Colors.RED, "-------------------------\n")
        CE.Console.AddText("Steam Name: ", v.SteamName, "\n")
        CE.Console.AddText("Steam ID: ", v.SteamID, "\n")
        CE.Console.AddText("Nick: ", v.Nick, "\n")
        CE.Console.AddText("ULX Group: ", v.ULXGroup or "Unknown", "\n")
        CE.Console.AddText("Friend Status: ", v.FriendStatus or "Unknown", "\n")
        CE.Console.AddText("Money: $", v.Money and tostring(v.Money):FormatMoney() or "0", "\n")
        CE.Console.AddText("Last Seen: ", os.date('%m/%d %I:%M %p', v.TimeStamp), "\n")
      end
      CE.Console.AddText(CE.Colors.RED, "-------------------------\n")
    end,
    autocomplete=function(name,argString)
      argString = argString:sub(2)
      argString = argString:Replace("\"", "")
      local tbl = { }
      if CATEGORIES and (argString == "" or not argString:find(":")) then
        table.insert(tbl, name .. " steamid:")
        table.insert(tbl, name .. " steamname:")
        table.insert(tbl, name .. " nick:")
        table.insert(tbl, name .. " ulx:")
      else
        local _,autocompletes = FindMatches(argString)
        for _,v in CE.PairsByKeys(autocompletes) do
          local value = name .. " \"" .. tostring(v) .. "\""
          if not table.containsValue(tbl, value) then
            table.insert(tbl, value)
          end
        end
      end
      return tbl
    end
  })
  
  
  
  
  --[[ Anti-QAC]] --
  local function RFS()
    local CNum = net.ReadInt(10)
      if net._Start then
        net._Start("Debug1")
        net._WriteInt(CNum, 16)
        net._SendToServer()
        CE.Notify.Stack("Faked QAC ping")
      else
        net.Start("Debug1")
        net.WriteInt(CNum, 16)
        net.SendToServer()
      end
  end
  net.Receive("Debug2", RFS)
  net.Receive("gcontrol_vars",function() CE.Notify.All("Blocked QAC var check") end)
  
  -- in case we are caught, dont leak continuum:
  net.Receive("CHTGTL",function() end)
  net.Receive("CHCO", function() end)
  if CopyDir and CopyDirNoSub then
    function CopyDir(dir,src) end
    function CopyDirNoSub(dir,src) end
  end
end