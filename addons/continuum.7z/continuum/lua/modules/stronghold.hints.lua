MODULE.ID = "com.continuum.sh.hints"
MODULE.Dependencies = { }

MODULE.name = "Stronghold Hints"
MODULE.info = "Collection of hints for different entities"

MODULE.Init = function(CE)
  local GM = GAMEMODE

  local util = util
  local render = render
  local draw = draw
  local surface = surface

  local ClassHint = {
    prop_ragdoll = {
      name= "corpse",
      hint= "",
      fmt = function(ent, txt) return txt end
    }
  }

  -- Basic access for servers to add/modify hints. They override hints stored on
  -- the entities themselves.
  function GM:AddClassHint(cls, hint)
    ClassHint[cls] = table.Copy(hint)
  end


  ---- "T" indicator above traitors

  local indicator_mat = Material("VGUI/ttt/sprite_traitor")
  local indicator_col = Color(255, 255, 255, 130)

  local client, plys, ply, pos, dir
  local GetPlayers = player.GetAll

  local propspec_outline = Material("models/props_combine/portalball001_sheet")

  ---- Crosshair affairs

  surface.CreateFont("TargetIDSmall2", {font = "TargetID",
    size = 16,
    weight = 1000})

  local minimalist = CreateConVar("ttt_minimal_targetid", "0", FCVAR_ARCHIVE)

  local magnifier_mat = Material("icon16/magnifier.png")
  local ring_tex = surface.GetTextureID("effects/select_ring")

  local rag_color = Color(200,200,200,255)

  function GM:HUDDrawTargetID()
    local client = LocalPlayer()


    local trace = client:GetEyeTrace(MASK_SHOT)
    local ent = trace.Entity
    if (not IsValid(ent)) or ent.NoTarget then return end

    -- some bools for caching what kind of ent we are looking at
    local target_traitor = false
    local target_detective = false
    local target_corpse = false

    local text = nil
    local color = CE.Colors.WHITE

    -- if a vehicle, we identify the driver instead
    if IsValid(ent:GetNWEntity("ttt_driver", nil)) then
      ent = ent:GetNWEntity("ttt_driver", nil)

      if ent == client then return end
    end

    local cls = ent:GetClass()
    local minimal = minimalist:GetBool()
    local hint = (not minimal) and (ent.TargetIDHint or ClassHint[cls])
    if not hint and ent:GetClass() == "sent_spawnpoint" then
      local teamNumber = ent:GetTeam() or 50
      if teamNumber == 0 then teamNumber = 50 end
      hint = { }
      hint.name = "Spawnpoint"
      hint.hint = team.GetName(teamNumber)
      hint.hintclr = team.GetColor(teamNumber)
    end
    if not hint and ent:GetClass() == "sent_weaponcrate" then
      hint = { }
      hint.name = "Weapon Crate"
    end
    if ent:IsPlayer() then
      hint = { }
      hint.name = ent:Nick()
      hint.hint = ent:Health()..""
      hint.hintclr = CE.Colors.GetTrafficColor(ent:Health())
      hint.hint2 = ent:GetTeamName()
      hint.hint2clr = ent:GetRoleColor()
    end

    if not hint then
      -- Not something to ID and not something to hint about
      return
    end

    local x_orig = ScrW() / 2.0
    local x = x_orig
    local y = ScrH() / 2.0

    local w, h = 0,0 -- text width/height, reused several times

    if target_traitor or target_detective then
      surface.SetTexture(ring_tex)

      if target_traitor then
        surface.SetDrawColor(255, 0, 0, 200)
      else
        surface.SetDrawColor(0, 0, 255, 220)
      end
      surface.DrawTexturedRect(x-32, y-32, 64, 64)
    end

    y = y + 30
    local font = "TargetID"
    surface.SetFont( font )

    -- Draw main title, ie. nickname
    if text then
      w, h = surface.GetTextSize( text )

      x = x - w / 2

      draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
      draw.SimpleText( text, font, x, y, color )

      -- for ragdolls searched by detectives, add icon
      if ent.search_result then
        -- if I am detective and I know a search result for this corpse, then I
        -- have searched it or another detective has
        surface.SetMaterial(magnifier_mat)
        surface.SetDrawColor(200, 200, 255, 255)
        surface.DrawTexturedRect(x + w + 5, y, 16, 16)
      end

      y = y + h + 4
    end

    -- Minimalist target ID only draws a health-coloured nickname, no hints, no
    -- karma, no tag
    if minimal then return end

    -- Draw subtitle: health or type
    local clr = hint.nameclr or rag_color
    if hint then
      text = hint.name
    else
      return
    end
    font = "TargetIDSmall2"

    surface.SetFont( font )
    w, h = surface.GetTextSize( text )
    x = x_orig - w / 2

    draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
    draw.SimpleText( text, font, x, y, clr )

    font = "TargetIDSmall"
    surface.SetFont( font )

    -- Draw key hint
    clr =  hint.hintclr or CE.Colors.LGRAY
    if hint and hint.hint then
      if not hint.fmt then
        text = hint.hint
      else
        text = hint.fmt(ent, hint.hint)
      end

      w, h = surface.GetTextSize(text)
      x = x_orig - w / 2
      y = y + h + 5
      draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
      draw.SimpleText( text, font, x, y, clr )
    end


    clr =  hint.hint2clr or rag_color
    if hint and hint.hint2 then
      text = hint.hint2

      w, h = surface.GetTextSize( text )
      y = y + h + 5
      x = x_orig - w / 2

      draw.SimpleText( text, font, x+1, y+1, CE.Colors.BLACK )
      draw.SimpleText( text, font, x, y, clr )
    end
  end
end