MODULE.ID = "com.continuum.aimbot"
MODULE.Dependencies = { "com.continuum.buddies" }

MODULE.Name = "Basic Aimbot"
MODULE.Info = "Moves cursor to head if you point at a person in soft mode, in hard mode locks on until turned off/target dies."
MODULE.Options = {
  [""]={ Default=0, Options={{ "Aimbot set to ", Color(255, 30, 30), "off" },
  {"Aimbot set to ", Color(120, 120, 30), "weak" },
  { "Aimbot set to ", Color(30, 255, 30), "strong" }}, HUD={
    Category = "Weaponry", Type="ToggleButton", Min=0, Max=2, Options={"Off","Weak","Strong"}
  }}
}
MODULE.Init = function(CE)
  CE.Session.BONE = CE.Session.BONE or "BONE_HEAD"
  function CE.GetPriorityBone()
    return CE.Constants[CE.Session.BONE]
  end
  MODULE.AddCmd({ Name="hacks_aimbot_bone", Nick="Select aimbot bone", Function=function(ply,name, arguments, args)
      if CE.Constants["BONE_" .. args:upper()] then
        CE.Session.BONE = "BONE_" .. args:upper()
        return
      end
      print("Bone not found: BONE_" .. args:upper())
    end, autocomplete=function(name, args)
      args = args:sub(2)
      local tbl = { }
      for k,v in pairs(CE.Constants) do
        if string.starts(k, "BONE") then
          local trim = k:sub(6):lower()
          if (trim:upper()):starts(args:upper()) then
            table.insert(tbl, "hacks_aimbot_bone " .. trim)
          end
        end
      end
      return tbl
  end})
  CE.AimbotTarget = nil
  local IGNOREZ = 0;
  local Hitboxes = {
    HEAD=0,
    LEFT_ARM=1,
    LEFT_FOREARM=2,
    LEFT_HAND=3,
    RIGHT_ARM=4,
    RIGHT_FOREARM=5,
    RIGHT_HAND=6,
    LEFT_THIGH=7,
    LEFT_CALF=8,
    LEFT_ANKLE=9,
    LEFT_FOOT=10,
    RIGHT_THIGH=11,
    RIGHT_CALF=12,
    RIGHT_ANKLE=13,
    RIGHT_FOOT=14,
    WAIST=15,
    LOWER_TORSO=16,
    UPPER_TORSO=17
  }
  local HitboxHeads = { }
  HitboxHeads["models/player.mdl"]=0
  HitboxHeads["models/grim.mdl"]=0
  HitboxHeads["models/player/phoenix.mdl"]=0
  HitboxHeads["models/player/mossman.mdl"]=0
  HitboxHeads["models/player/corpse1.mdl"]=0
  HitboxHeads["models/player/arctic.mdl"]=0
  HitboxHeads["models/player/leet.mdl"]=0
  HitboxHeads["models/player/barney.mdl"]=0
  HitboxHeads["models/player/breen.mdl"]=0
  HitboxHeads["models/player/combine_soldier_prisonguard.mdl"]=0
  HitboxHeads["models/player/kleiner.mdl"]=0
  HitboxHeads["models/player/monk.mdl"]=0
  HitboxHeads["models/player/guerilla.mdl"]=0
  HitboxHeads["models/player/gman_high.mdl"]=0
  HitboxHeads["models/player/police.mdl"]=0
  HitboxHeads["models/player/swat.mdl"]=0
  HitboxHeads["models/player/gasmask.mdl"]=0
  HitboxHeads["models/player/combine_super_soldier.mdl"]=0
  HitboxHeads["models/player/group01/female_01.mdl"]=0
  HitboxHeads["models/player/group01/female_02.mdl"]=0
  HitboxHeads["models/player/group01/female_03.mdl"]=0
  HitboxHeads["models/player/group01/female_04.mdl"]=0
  HitboxHeads["models/player/group01/female_05.mdl"]=0
  HitboxHeads["models/player/group01/female_06.mdl"]=0
  HitboxHeads["models/player/group01/female_07.mdl"]=0
  HitboxHeads["models/player/group01/female_08.mdl"]=0
  HitboxHeads["models/player/group01/female_09.mdl"]=0
  HitboxHeads["models/player/group01/male_01.mdl"]=0
  HitboxHeads["models/player/group01/male_02.mdl"]=0
  HitboxHeads["models/player/group01/male_03.mdl"]=0
  HitboxHeads["models/player/group01/male_04.mdl"]=0
  HitboxHeads["models/player/group01/male_05.mdl"]=0
  HitboxHeads["models/player/group01/male_06.mdl"]=0
  HitboxHeads["models/player/group01/male_07.mdl"]=0
  HitboxHeads["models/player/group01/male_08.mdl"]=0
  HitboxHeads["models/player/group01/male_09.mdl"]=0
  HitboxHeads["models/player/group03/male_01.mdl"]=0
  HitboxHeads["models/player/group03/male_02.mdl"]=0
  HitboxHeads["models/player/group03/male_03.mdl"]=0
  HitboxHeads["models/player/group03/male_04.mdl"]=0
  HitboxHeads["models/player/group03/male_05.mdl"]=0
  HitboxHeads["models/player/group03/male_06.mdl"]=0
  HitboxHeads["models/player/group03/male_07.mdl"]=0
  HitboxHeads["models/player/group03/male_08.mdl"]=0
  HitboxHeads["models/player/group03/male_09.mdl"]=0
  HitboxHeads["models/player/group03/female_01.mdl"]=0
  HitboxHeads["models/player/group03/female_02.mdl"]=0
  HitboxHeads["models/player/group03/female_03.mdl"]=0
  HitboxHeads["models/player/group03/female_04.mdl"]=0
  HitboxHeads["models/player/group03/female_05.mdl"]=0
  HitboxHeads["models/player/group03/female_06.mdl"]=0
  HitboxHeads["models/player/group03/female_07.mdl"]=0
  HitboxHeads["models/player/group03/female_08.mdl"]=0
  HitboxHeads["models/headcrab.mdl"]=0
  HitboxHeads["models/headcrabclassic.mdl"]=0
  HitboxHeads["models/antlion.mdl"]=0
  HitboxHeads["models/zombie/fast.mdl"]=10
  HitboxHeads["models/zombie/classic.mdl"]=13

  function CE.FindHead(Entity)
    return HitboxHeads[Entity:GetModel()]
  end
  local hitboxIdTable = {
    Hitboxes.HEAD,
    Hitboxes.UPPER_TORSO,
    Hitboxes.LOWER_TORSO,
    Hitboxes.WAIST,
    Hitboxes.LEFT_ARM,
    Hitboxes.RIGHT_ARM,
    Hitboxes.LEFT_FOREARM,
    Hitboxes.RIGHT_FOREARM,
    Hitboxes.LEFT_THIGH,
    Hitboxes.RIGHT_THIGH,
    Hitboxes.LEFT_CALF,
    Hitboxes.RIGHT_CALF,
    Hitboxes.LEFT_HAND,
    Hitboxes.RIGHT_HAND,
    Hitboxes.LEFT_FOOT,
    Hitboxes.RIGHT_FOOT,
    Hitboxes.LEFT_ANKLE,
    Hitboxes.RIGHT_ANKLE
  }
  local shootPosition
  local function IsGoodPoint(bPos, bAng, ply, x, y, z)
    local pos
    if bAng then
      pos = Vector(x,y,z) -- convert to vector
      pos:Rotate(bAng) -- rotate around box angle
      pos = bPos + pos -- shift it from the origin to the player
    else
      pos = bPos
    end
    local tr = util.TraceLine({start=shootPosition,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
    -- fire a trace from us to it, ignoring us, and masking it as a shot, meaning itll go through glass i think ^
    return tr.HitPos == pos and tr.Entity == ply and pos;
  end

  local function FindHitboxPosition(players, hitboxcount)
    local lp = LocalPlayer()
    shootPosition = lp:GetShootPos()
    for _, ply in pairs( players ) do
      if IsValid(ply) and ply ~= lp and ply:Alive() then
        for hitbox=0,hitboxcount-1 do
          local bpos, bang = ply:GetBonePosition( ply:GetHitBoxBone( hitbox, 0 ) );
          local min, max = ply:GetHitBoxBounds( hitbox, 0 );
          if (min ~= nil and max ~= nil) then
            --[[local DidYZ = false
            local halfX = Lerp(.5,min.x, max.x)
            local halfY = Lerp(.5,min.y, max.y)
            local halfZ = Lerp(.5,min.z, max.z)
            for x=min.x,max.x, 10 do
            if x < halfX then x = halfX - x end
            for y=min.y,max.y, 10 do
            if y < halfY then y = halfY - y end
            if not DidYZ then
            for z=min.z,max.z,10 do
            if z < halfZ then z = halfZ - z end
            local pos = Vector(min.x,y,z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            pos = Vector(max.x,y,z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            end
            end
            local pos = Vector(x,y,min.z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            pos = Vector(x,y,max.z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            end
            DidYZ = true
            for z=min.z,max.z, 10 do
            if z < halfZ then z = halfZ - z end
            local pos = Vector(x,min.y,z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            pos = Vector(x,max.y,z)
            pos:Rotate(bang)
            pos = bpos + pos
            local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
            if tr.HitPos == pos and tr.Entity == ply then
            return pos, ply
            end
            end
            end]]



            if ply.AimbotTarget and IsGoodPoint(ply.AimbotTarget, nil, ply) then
              return ply.AimbotTarget, ply
            end
            for x=min.x, max.x, 1 do
              if x == min.x or x == max.x then
                for y=min.y, max.y, 1 do
                  for z=min.z, max.z, 1 do
                    if IsGoodPoint(bpos, bang, ply, x, y, z) then
                      return Vector(x,y,z):Rotate(bang)+bpos, ply
                    end
                  end
                end
              else
                -- lets just do the outline
                for y=min.y, max.y, 1 do
                  if IsGoodPoint(bpos, bang, ply, x, y, min.z) then
                    return Vector(x,y,z):Rotate(bang)+bpos, ply
                  end
                  if IsGoodPoint(bpos, bang, ply, x, y, max.z) then
                    return Vector(x,y,z):Rotate(bang)+bpos, ply
                  end
                end
                for z=min.z, max.z, 1 do
                  if IsGoodPoint(bpos, bang, ply, x, min.y, z) then
                    return Vector(x,y,z):Rotate(bang)+bpos, ply
                  end
                  if IsGoodPoint(bpos, bang, ply, x, max.y, z) then
                    return Vector(x,y,z):Rotate(bang)+bpos, ply
                  end
                end
              end
            end




          end
        end
      end
    end
    return nil, players[1]
  end
  CE.Hook.Add("Think","CE.AimbotTargetter",function()
    if not CE.GetConVarBool("hacks_aimbot") or not CE.AimbotTarget or not UsingHitboxes then return end
    local hitboxcount = LocalPlayer():GetHitBoxCount(0)
    local lp = LocalPlayer()
    local players = {CE.AimbotTarget}
    local pos, ply = FindHitboxPosition(players, hitboxcount)
    if(pos) then
      ply.AimbotTarget = pos
    else
      ply.AimbotTarget = nil
    end
  end)
  local function DrawHitbox()
    if not CE.GetConVarBool("hacks_aimbot") or not CE.AimbotTarget or true then return end
    local hitboxcount = LocalPlayer():GetHitBoxCount(0)
    local lp = LocalPlayer()
    local players = {CE.AimbotTarget}--player.GetAll()
    for _, ply in pairs( players ) do
      if IsValid(ply) and ply ~=  lp and ply:Alive() then
        local shootpos = lp:GetShootPos()
        local AimbotTarget=nil
        for hitbox=0,hitboxcount-1 do
          local bpos, bang = ply:GetBonePosition( ply:GetHitBoxBone( hitbox, 0 ) );
          local min, max = ply:GetHitBoxBounds( hitbox, 0 );
          if (min ~= nil and max ~= nil) then
            local DidYZ = false
            local halfX = Lerp(.5,min.x, max.x)
            local halfY = Lerp(.5,min.y, max.y)
            local halfZ = Lerp(.5,min.z, max.z)
            for x=min.x,max.x, 10 do
              if x < halfX then x = halfX - x end
              for y=min.y,max.y, 10 do
                if y < halfY then y = halfY - y end
                if not DidYZ then
                  for z=min.z,max.z,10 do
                    if z < halfZ then z = halfZ - z end
                    local pos = Vector(min.x,y,z)
                    pos:Rotate(bang)
                    pos = bpos + pos
                    local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                    if tr.HitPos == pos and tr.Entity == ply then
                      AimbotTarget=pos
                      break
                    end
                    pos = Vector(max.x,y,z)
                    pos:Rotate(bang)
                    pos = bpos + pos
                    local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                    if tr.HitPos == pos and tr.Entity == ply then
                      AimbotTarget=pos
                      break
                    end
                  end
                  if AimbotTarget then break end
                end
                local pos = Vector(x,y,min.z)
                pos:Rotate(bang)
                pos = bpos + pos
                local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                if tr.HitPos == pos and tr.Entity == ply then
                  AimbotTarget=pos
                  break
                end
                pos = Vector(x,y,max.z)
                pos:Rotate(bang)
                pos = bpos + pos
                local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                if tr.HitPos == pos and tr.Entity == ply then
                  AimbotTarget=pos
                  break
                end
              end
              if AimbotTarget then break end
              DidYZ = true
              for z=min.z,max.z, 10 do
                if z < halfZ then z = halfZ - z end
                local pos = Vector(x,min.y,z)
                pos:Rotate(bang)
                pos = bpos + pos
                local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                if tr.HitPos == pos and tr.Entity == ply then
                  AimbotTarget=pos
                  break
                end
                pos = Vector(x,max.y,z)
                pos:Rotate(bang)
                pos = bpos + pos
                local tr = util.TraceLine({start=shootpos,endpos=pos,filter=LocalPlayer(), mask=MASK_SHOT})
                if tr.HitPos == pos and tr.Entity == ply then
                  AimbotTarget=pos
                  break
                end
                draw.DrawRect()
              end
              if AimbotTarget then break end
            end
            if AimbotTarget then break end
          end
          if AimbotTarget then break end
        end
      end
    end
    --[[cam.Start3D( EyePos(), EyeAngles() );
    for i, ent in pairs( player.GetAll() ) do
    if IsValid(ent) and ent ~= LocalPlayer() and ((ent:IsPlayer() and ent:Alive() ) or ( ent:IsNPC() and ent:GetMoveType() ~= 0)) then
    local hitboxcount = ent:GetHitBoxCount(0)
    local hitbox=0
    while hitbox < hitboxcount do
    local bone = ent:GetHitBoxBone( hitbox, 0 );
    local bpos, bang = ent:GetBonePosition( bone );
    local min, max = ent:GetHitBoxBounds( hitbox, 0 );
    --print("min: ", min)
    --print("max: ", max)
    local head = CE.FindHead(ent)
    if not head then head = 0 end
    if (min ~= nil and max ~= nil and not head or ent:EntIndex() == 1 or true) then
    if (not IGNOREZ ) then
    render.SetColorMaterial();
    else
    render.SetColorMaterialIgnoreZ();
    end
    --local color = Color(hitbox*5, 0, 0, 50)
    --render.SetBlend( color.a / 255 );
    --render.DrawBox( bpos, bang, min, max, color, not IGNOREZ );
    --local that_other_color = Colors.WithAlpha(color, 255)
    --render.DrawWireframeBox( bpos, bang, min, max, that_other_color, not IGNOREZ );
    end
    hitbox = hitbox + 1
    end
    end
    end
    cam.End3D();]]
  end

  CE.Hook.Add( "RenderScreenspaceEffects", "Render", DrawHitbox );
  local function DrawHeads()
    if GetConVarNumber("hacks_chams") ~= 3 then return end
    cam.Start3D( EyePos(), EyeAngles() );
    for i, ent in pairs( player.GetAll() ) do
      if IsValid(ent) and ent ~= LocalPlayer() and ((ent:IsPlayer() and ent:Alive() ) or ( ent:IsNPC() and ent:GetMoveType() ~= 0)) then
        local hitboxcount = ent:GetHitBoxCount(0)
        local hitbox= CE.FindHead(ent) or 0
        local bone = ent:GetHitBoxBone( hitbox, 0 );
        local bpos, bang = ent:GetBonePosition( bone );
        local min, max = ent:GetHitBoxBounds( hitbox, 0 );
        if (min ~= nil and max ~= nil) then
          if (IGNOREZ == 0) then
            render.SetColorMaterial();
          else
            render.SetColorMaterialIgnoreZ();
          end
          local color = CE.Colors.WithAlpha(ent:GetRoleColor(), 50)
          render.SetBlend( color.a / 255 );
          render.DrawBox( bpos, bang, min, max, color, IGNOREZ == 0 );
          local that_other_color = CE.Colors.WithAlpha(color, 255)
          render.DrawWireframeBox( bpos, bang, min, max, that_other_color, IGNOREZ == 0 );
        end
      end
    end
    cam.End3D();
  end
  CE.Hook.Add( "RenderScreenspaceEffects", "RenderHeads", DrawHeads);
  local function CalculateAngle(initialPosition, targetPosition)
    -- p = 1500
    local dif = targetPosition - initialPosition
    local ply = LocalPlayer()
    --(x/t)^2 + (y/t)^2 + ((z-.5gt^2)/t)^2 = 2250000
    --0 = (-.25g^2)t^4 + (2250000-gz)t^2 - (x^2+y^2+z^2)
    local g=physenv.GetGravity().z
    local x,y,z = dif.z,dif.y,dif.z
    local t = math.sqrt((-(1500^2-g*z)-math.sqrt((1500^2-g*z)^2-4*(-.25*g^2)*(x^2+y^2+z^2)))/(2*(-.25*g^2)))
    print(t)
    local vox = x/t
    local voy = y/t
    local voz = (z-.5*g*t^2)/t
    print(math.sqrt(vox^2+voz^2+voy^2))
    local pitch = math.deg(math.acos(voz/1500)) or 0
    local yaw = math.deg(math.atan(voy/vox)) or 0
    local roll = 0
    return Angle(pitch, yaw, roll)
  end
  local CreateMoveCMD
  local function aimbot()
    if(not IsValid(CE.AimbotTarget) or (CE.AimbotTarget.Alive and not CE.AimbotTarget:Alive()) or (CE.AimbotTarget:IsPlayer() and CE.AimbotTarget:Health() <= 0)) then
      CE.ReadyAimKill = true
      CE.AimbotTarget = nil
    end
    if CE.GetConVarBool("hacks_aimbotv2") then
      return
    end
    local lp = LocalPlayer()
    if GetConVarNumber("hacks_aimbot") == CE.Constants.AIMBOT_HARD then
      if(CE.AimbotTarget == nil) then
        local trace = util.GetPlayerTrace( lp )
        trace.mask = MASK_SHOT
        local traceRes = util.TraceLine( trace )
        if traceRes.HitNonWorld then
          local target = traceRes.Entity
          if target:IsPlayer() and target:Alive() and target:Health() > 0 and (target:IsPlayer() and not target:IsTraitorBuddy() and not target:IsFriend()) then
            CE.AimbotTarget = target
            CE.PlayBeep()
          end
        end
        return
      end
      local TargetHeadPosition
      if CE.AimbotTarget:IsPlayer() then
        --[[local hitbox = CE.FindHead(CE.AimbotTarget)
        local bone
        if hitbox then
        bone = CE.AimbotTarget:GetHitBoxBone( hitbox, 0 );
        else]]
        --bone = CE.AimbotTarget:LookupBone("ValveBiped.Bip01_Head1") or CE.Constants.BONE_HEAD
        --end
        local bone = CE.GetPriorityBone() or CE.AimbotTarget:LookupBone("ValveBiped.Bip01_Head1")
        TargetHeadPosition = CE.AimbotTarget:GetBonePosition( bone );
      else
        TargetHeadPosition = CE.AimbotTarget:GetPos() + Vector(0,0,50)
      end
      if TargetHeadPosition ~= nil then
        if IsValid(LocalPlayer():GetActiveWeapon()) and (LocalPlayer():GetActiveWeapon():GetClass() == "weapon_throwingaxe" or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_throwingknife") then
          --CreateMoveCMD:SetViewAngles(CalculateAngle(ply:GetShootPos()+absVel,TargetHeadPosition-Vector(0,0,40)))
          print(CalculateAngle(lp:GetShootPos(),TargetHeadPosition-Vector(0,0,40)))
        else
          local angles = lp:GetShootPos():AngleTo(TargetHeadPosition + CE.CalculateLag(CE.AimbotTarget))-LocalPlayer():GetPunchAngle()
          CreateMoveCMD:SetViewAngles(angles)
          --CE.SetEyeAngles(angles)
        end
      end
    elseif GetConVarNumber("hacks_aimbot") == CE.Constants.AIMBOT_SOFT then
      local trace = util.GetPlayerTrace( lp )
      trace.mask = MASK_SHOT
      local traceRes = util.TraceLine( trace )
      if traceRes.HitNonWorld then
        local target = traceRes.Entity
        if target:IsNPC() or (target:IsPlayer() and not target:IsTraitorBuddy() and not target:IsFriend() and not target:IsSpawnProtected()) then

          --[[local hitbox = CE.FindHead(CE.AimbotTarget)
          local bone
          if hitbox then
          bone = CE.AimbotTarget:GetHitBoxBone( hitbox, 0 );
          else]]
          --bone = CE.AimbotTarget:LookupBone("ValveBiped.Bip01_Head1") or CE.Constants.BONE_HEAD
          --end
          local bone = CE.GetPriorityBone() or CE.AimbotTarget:LookupBone("ValveBiped.Bip01_Head1")
          local TargetHeadPosition = target:GetBonePosition( bone ) + CE.CalculateLag(target)

          CreateMoveCMD:SetViewAngles((lp:GetShootPos()):AngleTo(TargetHeadPosition)-LocalPlayer():GetPunchAngle())
        end
      end
    else
      CE.AimbotTarget = nil
    end
  end

  local function tryAimbot(cmd)
    --CreateMoveCMD = cmd
    CreateMoveCMD = { SetViewAngles = function(cmd, angles) CE.SetEyeAngles(angles) end}
    if(GetConVarNumber("hacks_aimbot") == CE.Constants.AIMBOT_ERROR) then
      return
    end
    --LocalPlayer():LagCompensation(false)
    local success, callback = xpcall(aimbot, CE.ErrorHandler)
    --LocalPlayer():LagCompensation(false)
    if(not success) then
      RunConsoleCommand("hacks_aimbot", -1);
    end
  end
  CE.Hook.Add("Think", "CE.Aimbot", tryAimbot)
  CE.Hook.Remove("CreateMove", "CE.Aimbot", tryAimbot)
end