if RequireTool("button") then
	TOOL.Continuum = false
	TOOL.AddToMenu = true
	function TOOL:Reload(trace)
		if trace.Entity and		-- Hit an entity
		trace.Entity:IsValid() and	-- And the entity is valid
		trace.Entity:EntIndex() ~= 0 and -- And isn't worldspawn
		not trace.Entity:GetModel():starts("*") -- And isn't map prop
		then
			RunConsoleCommand("button_model", trace.Entity:GetModel())
			return true
		end
		return false
	end
	function TOOL:CanReload(entity)
		return true
	end
end