TOOL.Category		= "Render"
TOOL.Name			= "#tool.color.name"
TOOL.Command		= nil
TOOL.ConfigName		= nil


TOOL.ClientConVar[ "r" ] = 255
TOOL.ClientConVar[ "g" ] = 0
TOOL.ClientConVar[ "b" ] = 255
TOOL.ClientConVar[ "a" ] = 255
TOOL.ClientConVar[ "mode" ] = 0
TOOL.ClientConVar[ "fx" ] = 0

local function SetColour( Player, Entity, Data )

	--
	-- If we're trying to make them transparent them make the render mode
	-- a transparent type. This used to fix in the engine - but made HL:S props invisible(!)
	--
	if ( Data.Color and Data.Color.a < 255 and Data.RenderMode == 0 ) then
		Data.RenderMode = 1
	end

	if ( Data.Color ) then Entity:SetColor( Color( Data.Color.r, Data.Color.g, Data.Color.b, Data.Color.a ) ) end
	if ( Data.RenderMode ) then Entity:SetRenderMode( Data.RenderMode ) end
	if ( Data.RenderFX ) then Entity:SetKeyValue( "renderfx", Data.RenderFX ) end
end
duplicator.RegisterEntityModifier( "colour", SetColour )

function TOOL:LeftClick( trace )
	return IsValid(trace.Entity)
end

function TOOL:RightClick( trace )

	if trace.Entity and		-- Hit an entity
	trace.Entity:IsValid() and	-- And the entity is valid
	trace.Entity:EntIndex() ~= 0 -- And isn't worldspawn
	then

		SetColour( self:GetOwner(), trace.Entity, { Color = Color( 255, 255, 255, 255 ), RenderMode = 0, RenderFX = 0 } )
		return true

	end

end
function TOOL:Reload(trace)

	if trace.Entity and		-- Hit an entity
	trace.Entity:IsValid() and	-- And the entity is valid
	trace.Entity:EntIndex() ~= 0 -- And isn't worldspawn
	then
		local e = trace.Entity
		local c = e:GetColor()
		local mode = e:GetRenderMode()
		local fx = e:GetRenderFX()
		RunConsoleCommand("colour_r", c.r)
		RunConsoleCommand("colour_g", c.g)
		RunConsoleCommand("colour_b", c.b)
		RunConsoleCommand("colour_a", c.a)
		RunConsoleCommand("colour_mode", mode or 0)
		RunConsoleCommand("colour_fx", fx or 0)
		return true
	end
	return false
end
function TOOL:CanReload(entity)
	return true
end
local function DrawScrollingText( text, y, texwide )
	text = language.GetPhrase(text:sub(2)) -- So we can add more text if we want
	local w, h = surface.GetTextSize( text  )
	w = w + 64
	local x = math.fmod( CurTime() * 400, w ) * -1;
	while ( x < texwide ) do
		surface.SetTextColor( 0, 0, 0, 255 )
		surface.SetTextPos( x + 3, y + 3 )
		surface.DrawText( text )

		surface.SetTextColor( 255, 255, 255, 255 )
		surface.SetTextPos( x, y )
		surface.DrawText( text )
		x = x + w
	end
end
local function DrawAlphaChannel(width, height)
	render.Clear(255,255,255,255)
	local rectSize = width / 8
	local x,y = 0,0
	surface.SetDrawColor(Color(200,200,200))
	while x < width do
		y = 0
		while y < height do
			if (x/rectSize + y/rectSize) % 2 == 0 then
				surface.DrawRect(x,y,rectSize,rectSize)
			end
			y = y + rectSize
		end
		x = x + rectSize
	end
end
---[[
-- Because it's nice to know what material you're using
--]]
function TOOL:DrawToolScreen(width, height)
	DrawAlphaChannel(width,height)
	surface.SetDrawColor(Color(self:GetClientNumber( "r", 0 ), self:GetClientNumber( "g", 0 ), self:GetClientNumber( "b", 0 ), self:GetClientNumber( "a", 0 )))
	surface.DrawRect(0,0,width,height)
	surface.SetFont( "GModToolScreen" )
	DrawScrollingText( "#tool."..self.Mode..".name", 64, width )
end
