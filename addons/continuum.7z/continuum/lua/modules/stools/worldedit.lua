local CE = CE
TOOL.Category		= "Continuum"
TOOL.Name			= "#tool.worldedit.name"
TOOL.Command		= nil
TOOL.ConfigName		= nil

TOOL.ClientConVar[ "nocollide" ]		= "1"
TOOL.ClientConVar[ "gravity" ]			= "0"

language.Add( "tool.worldedit.name", "Worldedit" )
language.Add( "tool.worldedit.desc", "Copy and paste props" )
language.Add( "tool.worldedit.0", "Left click to paste an entity. Right click to copy. Reload to remove" )

language.Add( "tool.worldedit.gravity", "Gravity" )
language.Add( "tool.worldedit.nocollide", "No Collide" )
language.Add( "tool.worldedit.gravity.help", "Gravity state to use for pasted props" )
language.Add( "tool.worldedit.nocollide.help", "No Collides props that are pasted" )
local LastSpawn = 0
function TOOL:LeftClick( trace )
	if CE.Session.WorldEdit and CurTime() > LastSpawn+.6 then
		local model = CE.Session.WorldEdit:GetModel()
		local bodygroups = ""
		for id=0,8 do
			bodygroups = bodygroups .. tostring(CE.Session.WorldEdit:GetBodygroup(id))
		end
		local skin = CE.Session.WorldEdit:GetSkin()
		--
		RunConsoleCommand("gm_spawn", model, skin, bodygroups, true)
		LastSpawn = CurTime()
		return true
	end
	return false
end
function TOOL:CanLeftClick(entity)
	return true
end
function TOOL:CanRightClick(entity)
	return true
end

function TOOL:RightClick( trace )
	if IsValid(trace.Entity) and not trace.Entity:GetModel():starts("*") then
		CE.Session.WorldEdit = trace.Entity
		return true
	else
		CE.Session.WorldEdit = nil
		return false
	end
end

function TOOL:Reload( trace )
	net.Start("properties")
	net.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
	net.WriteEntity( trace.Entity )
	net.SendToServer()
	return IsValid(trace.Entity)
end

function TOOL:UpdateGhostProp( ent, player )

	if ( not IsValid(ent) ) then return end

	local tr 	= util.GetPlayerTrace( player )
	local trace 	= util.TraceLine( tr )
	if (not trace.Hit) then return end

	if ( trace.Entity:IsPlayer() ) then

		ent:SetNoDraw( true )
		return

	end

	local Ang = player:EyeAngles()
	Ang.yaw = Ang.yaw + 180
	Ang.roll = 0
	Ang.pitch = 0
	local CurPos = ent:GetPos()
	local NearestPoint = ent:NearestPoint( CurPos - (trace.HitNormal * 512) )
	local WheelOffset = CurPos - NearestPoint

	local min = ent:OBBMins()
	ent:SetPos( trace.HitPos + trace.HitNormal + WheelOffset )
	ent:SetAngles( Ang )

	ent:SetNoDraw( false )

end
local function GetBodyGroups(ent)
	local bodygroups = ""
	for id=0,8 do
		bodygroups = bodygroups .. tostring(ent:GetBodygroup(id))
	end
	return bodygroups
end
--[[---------------------------------------------------------
Maintains the ghost prop
-----------------------------------------------------------]]
function TOOL:Think()
	if IsValid(CE.Session.WorldEdit) then
		if (not IsValid(self.GhostEntity) or self.GhostEntity:GetModel() ~= CE.Session.WorldEdit:GetModel()
		or self.GhostEntity:GetSkin() ~= CE.Session.WorldEdit:GetSkin() or GetBodyGroups(self.GhostEntity) ~=
		GetBodyGroups(CE.Session.WorldEdit)) then

			self:MakeGhostEntity( CE.Session.WorldEdit:GetModel(), Vector(0,0,0), Angle(0,0,0) )
			if self.GhostEntity then
				self.GhostEntity:SetSkin(CE.Session.WorldEdit:GetSkin())
				self.GhostEntity:SetBodyGroups(GetBodyGroups(CE.Session.WorldEdit))
			end
		end

		self:UpdateGhostProp( self.GhostEntity, self:GetOwner() )
	else
		CE.Session.WorldEdit = nil
		self:ReleaseGhostEntity()
	end
end
function TOOL.BuildCPanel( CPanel )
	test = CPanel
	-- HEADER
	CPanel:AddControl( "Header", { Text = "#tool.worldedit.name", Description	= "#tool.worldedit.desc" }  )

	CPanel:AddControl( "CheckBox",{ Label = "#tool.worldedit.nocollide", Command="worldedit_nocollide", Help=true })
	CPanel:AddControl( "CheckBox",{ Label = "#tool.worldedit.gravity", Command="worldedit_gravity", Help=true })
	CPanel:AddControl( "Label", { Text = "Since collisions and gravity are really the only two forces that exist in garrysmod, we're basically 'freezing' it if you turn off gravity and turn on nocollide. Hopefully garry will answer my feature request for freezing in context menu, this is the only reason I want it :P" } )

end
CE.Hook.Add("WorldeditPropSpawned", "GravitySpawn", function(prop)
	if not CE.GetConVarBool("worldedit_gravity") then
		net.Start( "properties" )
		net.WriteUInt( util.NetworkStringToID( "gravity" ), 32 )
		net.WriteEntity( prop )
		net.SendToServer()
	end
	if CE.GetConVarBool("worldedit_nocollide") then
		net.Start( "properties" )
		net.WriteUInt( util.NetworkStringToID( "collision_off" ), 32 )
		net.WriteEntity( prop )
		net.SendToServer( )
	else
		net.Start( "properties" )
		net.WriteUInt( util.NetworkStringToID( "collision_on" ), 32 )
		net.WriteEntity( prop )
		net.SendToServer( )
	end
end)
