TOOL.Category		= "Render"
TOOL.Name			= "#tool.material.name"
TOOL.Command		= nil
TOOL.ConfigName		= ""
language.Add( "tool.material.0", "Left click to change material. Right click to revert. Reload to copy" )


TOOL.ClientConVar[ "override" ] = "debug/env_cubemap_model"

--
-- Duplicator function
--
local function SetMaterial( Player, Entity, Data )
	return true

end
duplicator.RegisterEntityModifier( "material", SetMaterial )

--
-- Left click applies the current material
--
function TOOL:LeftClick( trace )

	if ( not IsValid( trace.Entity ) ) then return end

	local mat = self:GetClientInfo( "override" )
	SetMaterial( self:GetOwner(), trace.Entity, { MaterialOverride = mat } )
	return true

end

--
-- Right click reverts the material
--
function TOOL:RightClick( trace )

	if ( not IsValid( trace.Entity ) ) then return end

	SetMaterial( self:GetOwner(), trace.Entity, { MaterialOverride = "" } )
	return true

end
function TOOL:CanReload(trace)
	return true
end
function TOOL:Reload( trace )

	if ( not IsValid( trace.Entity ) ) then return end
	RunConsoleCommand("material_override", trace.Entity:GetMaterial())
	return true
end


function TOOL.BuildCPanel( CPanel )

	-- HEADER
	CPanel:SetTooltip( "#tool.material.desc" )

	CPanel:MatSelect( "material_override", list.Get( "OverrideMaterials" ), true, 0.33, 0.33 )

end
local function DrawAlphaChannel(width, height)
	render.Clear(255,255,255,255)
	local rectSize = width / 8
	local x,y = 0,0
	surface.SetDrawColor(Color(200,200,200))
	while x < width do
		y = 0
		while y < height do
			if (x/rectSize + y/rectSize) % 2 == 0 then
				surface.DrawRect(x,y,rectSize,rectSize)
			end
			y = y + rectSize
		end
		x = x + rectSize
	end
end
local function DrawScrollingText( text, y, texwide )
	text = language.GetPhrase(text:sub(2)) -- So we can add more text if we want
	local w, h = surface.GetTextSize( text  )
	w = w + 64
	local x = math.fmod( CurTime() * 400, w ) * -1;
	while ( x < texwide ) do
		surface.SetTextColor( 0, 0, 0, 255 )
		surface.SetTextPos( x + 3, y + 3 )
		surface.DrawText( text )

		surface.SetTextColor( 255, 255, 255, 255 )
		surface.SetTextPos( x, y )
		surface.DrawText( text )
		x = x + w
	end
end
local CachedIds = { }
CachedIds['vgui/black'] = surface.GetTextureID('vgui/black')
---[[
-- Because it's nice to know what material you're using
--]]
function TOOL:DrawToolScreen(width, height)
	local mat = self:GetClientInfo( "override" )
	if not CachedIds[mat] then
		CachedIds[mat] = surface.GetTextureID(mat)
	end
	DrawAlphaChannel(width,height)
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.SetTexture( CachedIds[mat] )
	surface.DrawTexturedRect( 0, 0, width, height )
	surface.SetFont( "GModToolScreen" )
	DrawScrollingText( "#tool."..self.Mode..".name", 64, width )
end