local CE = CE
if RequireTool("fading_door") or RequireTool("fadingdoor") or RequireTool("fd") or RequireTool("fading_doors") or RequireTool("fadingdoors") then
	TOOL.ClientConVar["StoreButton"] = "1"
	function TOOL:LeftClick(Trace)
		local Entity = Trace.Entity
		if not IsValid(Entity) or Entity:IsPlayer() or Trace.HitWorld or Entity:IsNPC() then
			return false
		end
		local Data = {}
		Data.Key = self:GetClientNumber("Key")
		Data.Toggle = self:GetClientNumber("Toggle")
		Data.Inverse = self:GetClientNumber("Inversed")

		Entity.FadingDoor = {}
		Entity.FadingDoor.Active = false
		Entity.FadingDoor.Toggle = (Data.Toggle ~= 0)
		Entity.FadingDoor.Key = Data.Key
		if SetEntityText then
			SetEntityText(Entity, "Use key '"..input.GetKeyName(Data.Key).."'")
		end
		CE.Hook.Add("Think", Entity, function()
			Entity.FadingDoor.Active = Entity:GetMaterial() == "sprites/heatwave"
		end)
		if self:GetClientNumber("StoreButton") >= 1 then
			RunConsoleCommand("button_keygroup", tostring(Data.Key))
		end
		return true
	end
	if not TOOL._BuildCPanel then TOOL._BuildCPanel = TOOL.BuildCPanel end
	local tool = TOOL
	function TOOL.BuildCPanel(Panel)
		tool._BuildCPanel(Panel)
        Panel:AddControl("CheckBox", {Label = "Store key to Button", Command = "fadingdoor_StoreButton"})
	end
end