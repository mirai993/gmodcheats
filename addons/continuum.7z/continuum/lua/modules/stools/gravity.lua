TOOL.Category		= "Continuum"
TOOL.Name			= "#tool.gravity.name"
TOOL.Command		= nil
TOOL.ConfigName		= nil
TOOL.AddToMenu = false

language.Add( "tool.gravity.name", "Gravity" )
language.Add( "tool.gravity.desc", "Change prop gravity" )
language.Add( "tool.gravity.0", "Left click to enable gravity. Right click to disable. Reload to toggle" )
local function IsGravityEnabled(ent)
	return not ent:GetNWBool( "gravity_disabled" )
end
local function ToggleGravity(ent)
	net.Start( "properties" )
	net.WriteUInt( util.NetworkStringToID( "gravity" ), 32 )
	net.WriteEntity( ent )
	net.SendToServer()
end
local lastLeftClick = 0
local lastReload = 0
local lastRightClick = 0
function TOOL:LeftClick( trace )
	if IsValid(trace.Entity) and CurTime() > lastLeftClick + .05 then
		lastLeftClick = CurTime()
		if not IsGravityEnabled(trace.Entity) then
			ToggleGravity(trace.Entity)
			return true
		end
	end
	return false
end

function TOOL:RightClick( trace )
	if IsValid(trace.Entity) and CurTime() > lastRightClick + .05 then
		lastRightClick = CurTime()
		if IsGravityEnabled(trace.Entity) then
			ToggleGravity(trace.Entity)
			return true
		end
	end
	return false
end
function TOOL:Reload( trace )
	if IsValid(trace.Entity) and CurTime() > lastReload + .05 then
		lastReload = CurTime()
		ToggleGravity(trace.Entity)
		return true
	end
	return false
end
