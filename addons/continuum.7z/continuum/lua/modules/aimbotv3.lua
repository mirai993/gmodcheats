MODULE.ID = "com.continuum.aimbotv3"
MODULE.Dependencies = { "com.continuum.aimbot", "com.continuum.buddies" }

MODULE.Name = "Aimbot v3"
MODULE.Info = "Aka aimrape, aimbotv3 targets everything in sight"
MODULE.cvars = { {Nick="Aimbot v3", Name="hacks_aimbotv3", Default="0", HUD={
  Category = "Weaponry", Type="ToggleButton"
}} }

MODULE.Init = function(CE)
  CE.AimbotV3Target = nil
  local function findEntityOnScreen()
    if CE.AimbotV2Target then
      if(not IsValid(CE.AimbotV3Target)) then
        CE.AimbotV2Target = nil
        CE.PlayBeep()
        return nil
      end
      local trace = util.TraceLine({start=LocalPlayer():GetShootPos(), endpos = CE.AimbotV3Target:GetPos()})
      if trace.HitNonWorld and trace.Entity == CE.AimbotV3Target then
        return CE.AimbotV3Target
      end
    end
    local topDamageInfo = CE.LoadTraceData( nil, nil, nil )
    local ents = ents.GetAll()
    table.sort(ents, function(x,y)return x:IsValid() and y:IsValid() and CE.DistanceTo(x:GetPos()) < CE.DistanceTo(y:GetPos())end)
    for k,v in pairs(ents) do
      if IsValid(v) and not v:IsPlayer() then
        local target = v:GetPos()
        local traceRes = util.TraceLine({start=LocalPlayer():GetShootPos(), endpos=target, mask=MASK_SHOT})
        if traceRes.Entity == v then
          return v
        end
      end
    end
    return nil
      --return topDamageInfo.target and topDamageInfo or nil
  end

  CE.findEntityOnScreen = findEntityOnScreen
  local CreateMoveCMD
  local function aimbotv3()
    CE.AimbotV3Target = findEntityOnScreen()
    if(CE.AimbotV3Target == nil) then
      return
    end
    local target = CE.AimbotV3Target
    if(IsValid(target)) then
      local targetpos = target:GetPos()
      if(targetpos == nil) then
        return
      end
      local CurrentAngles = LocalPlayer():EyeAngles()
      local NewAngles = (LocalPlayer():GetShootPos() + CE.CalculateLag(LocalPlayer())):AngleTo(targetpos + CE.CalculateLag(target))
      --local BetweenAngles = LerpAngle(.5, CurrentAngles, NewAngles) -- use this if u want to make it move slowly
      CreateMoveCMD:SetViewAngles(CE.ClampAngle(NewAngles-LocalPlayer():GetPunchAngle()))
    end
  end

  local function tryAimbotv3(cmd)
    if not CE.GetConVarBool("hacks_aimbotv3") then
      return
    end
    --CreateMoveCMD = cmd
    CreateMoveCMD = { SetViewAngles = function(cmd, angles) CE.SetEyeAngles(angles) end}
    local success, callback = xpcall(aimbotv3, CE.ErrorHandler)
    if(not success) then
      RunConsoleCommand("hacks_aimbotv3", -1);
    end
  end
  CE.Hook.Add("Think", "CE.Aimbotv3", tryAimbotv3)
end