MODULE.Name = "Printers"
MODULE.Info = "Printer collector for some servers"
MODULE.ID = "com.continuum.printers"
MODULE.Dependencies = { }
MODULE.cvars = {{Name="hacks_printercollect", Default="0"}}
MODULE.Init = function(CE)
  if util.NetworkStringToID('DataSend') > 0 then
    timer.Create("CE.CollectPrinters", 3, 0, function()
      if CE.GetConVarBool("hacks_printercollect") then
        for _,ent in pairs(ents.FindByClass("adv_moneyprinter")) do
            if ent:GetNWInt("Heat") >= ent:GetNWInt("MaxFSHeat") - 5 and ent:GetNWInt("Toggle") then
              -- Power off
              net.Start("DataSend")
              net.WriteFloat(1)
              net.WriteEntity(ent)
              net.SendToServer()
            end
            if ent:GetNWInt("Power") > 0 and not ent:GetNWInt("Toggle") then
              -- Power on
              net.Start("DataSend")
              net.WriteFloat(1)
              net.WriteEntity(ent)
              net.SendToServer()
            end
            if ent:GetNWInt("PrintA") > 0 then
              -- Collect
              net.Start("DataSend")
              net.WriteFloat(2)
              net.WriteEntity(ent)
              net.WriteEntity(LocalPlayer())
              net.SendToServer()
            end
        end
      end
    end)
  end
end
-- Lets  catch NW Vars!
local EM = FindMetaTable("Entity")
EM._GetNWInt = EM._GetNWInt or EM.GetNWInt
EM._GetNWBool = EM._GetNWBool or EM.GetNWBool
EM._GetNWEntity = EM._GetNWEntity or EM.GetNWEntity
EM._GetNWFloat = EM._GetNWFloat or EM.GetNWFloat
EM._GetNWVector = EM._GetNWVector or EM.GetNWVector
EM._GetNWAngle = EM._GetNWAngle or EM.GetNWAngle
EM._GetNWString = EM._GetNWString or EM.GetNWString
EM.GetNWInt = function(self,name, default)
  local value = self:_GetNWInt(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWBool = function(self,name, default)
  local value = self:_GetNWBool(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWEntity = function(self,name, default)
  local value = self:_GetNWEntity(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWFloat = function(self,name, default)
  local value = self:_GetNWFloat(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWVector = function(self,name, default)
  local value = self:_GetNWVector(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWAngle = function(self,name, default)
  local value = self:_GetNWAngle(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end
EM.GetNWString = function(self,name, default)
  local value = self:_GetNWString(name, default)
  self.NWVars = self.NWVars or { }
  self.NWVars[name] = value
  return value
end