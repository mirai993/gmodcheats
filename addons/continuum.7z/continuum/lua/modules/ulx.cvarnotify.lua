MODULE.ID = "com.continuum.ulx.cvarnotify"
MODULE.Dependencies = { "com.continuum.notify" }

MODULE.Name="ULX CVar Notifier"
MODULE.Info="Notifies you when a ulx server cvar changes"

MODULE.Init = function(CE)
  local Colors = CE.Colors
  CE.Hook.Add("ULibReplicatedCvarChanged", "CE.UlibCvarHackNotify",function(serverCvar, clientCvar, changer, oldValue, newValue)
    if changer == nil then
      CE.Notify.Chat(Colors.WHITE, "Server cvar ", Colors.RED, serverCvar, Colors.WHITE, " (cl ",clientCvar, ") changed to ", newValue)
    else
      CE.Notify.Chat(Colors.WHITE, changer:Nick(), " changed server cvar", Colors.RED, serverCvar, Colors.WHITE, " (cl ",clientCvar,") to ", newValue)
    end
  end)
end