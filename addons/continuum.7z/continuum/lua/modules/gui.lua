MODULE.ID = "com.continuum.gui"
MODULE.Dependencies = { }

MODULE.Name="GUI"
MODULE.Info="Graphic User Interface, simple interface to change status of modules"

MODULE.Init = function(CE)
  local GUIFrame
  local function createGUI()
  	local Frame = vgui.Create( "DFrame" )
  	Frame:SetPos( 50,50 )
  	Frame:SetSize( 450, 500 )
  	Frame:SetTitle( "Continuum GUI" )
  	Frame:SetDraggable( true )
  	Frame:ShowCloseButton( true )
  	Frame:MakePopup()
  	Frame:Hide()
  	Frame:SetVerticalScrollbarEnabled(true)
  
  	local MainPanel = vgui.Create("DPanelList", Frame)
  	MainPanel:SetSize(440, 470)
  	MainPanel:SetPos(10,30)
  	MainPanel:SetSpacing( 10 )
  
  
  	local ConVarScroll = vgui.Create("DScrollPanel", MainPanel)
  	ConVarScroll:SetSize(100, 200)
  	local ConVarLabel = vgui.Create("DLabel", MainPanel)
  	ConVarLabel:SetColor(Color(255,255,255,255))
  	ConVarLabel:SetFont("default")
  	ConVarLabel:SetText("Console Variables")
  	ConVarLabel:SizeToContents()
  	MainPanel:AddItem(ConVarLabel)
  	MainPanel:AddItem(ConVarScroll)
  	local CommandScroll = vgui.Create("DScrollPanel", MainPanel)
  	CommandScroll:SetSize(100, 200)
  	local CommandLabel = vgui.Create("DLabel", MainPanel)
  	CommandLabel:SetColor(Color(255,255,255,255))
  	CommandLabel:SetFont("default")
  	CommandLabel:SetText("Console Commands")
  	CommandLabel:SizeToContents()
  	MainPanel:AddItem(CommandLabel)
  	MainPanel:AddItem(CommandScroll)
  
  
  	local ConVarList = vgui.Create( "DPanelList", ConVarScroll)
  	ConVarList:SetAutoSize( false )
  	ConVarList:SetSpacing( 5 )
  	ConVarList:SetPos(20, 0)
  
  	local CommandList = vgui.Create( "DPanelList", CommandScroll)
  	CommandList:SetAutoSize( false )
  	CommandList:SetSpacing( 5 )
  	CommandList:SetPos(20, 0)
  	local cvarHeight = 0
  	local cmdHeight = 0
  	local cvars = { }
  	local cmds = { }
  	for _,data in pairs(CE.cvars) do
  		if data.cmd and data.noargs then
  			cmds[data.name]=data
  		elseif data.cvar and not data.NoToggle then
  			cvars[data.name]=data
  		end
  	end
  	for _,data in CE.PairsByKeys(cvars) do
  			local CheckBox = vgui.Create( "DCheckBoxLabel" )
  			CheckBox:SetText( data.name )
  			CheckBox:SetConVar( data.cvar )
  			CheckBox:SetValue( GetConVarNumber(data.cvar) )
  			CheckBox:SizeToContents()
  			ConVarList:AddItem( CheckBox )
  			
  			local w,h = CheckBox:GetSize()
  			cvarHeight = cvarHeight + 5 + h
  	end
  	for _,data in CE.PairsByKeys(cmds) do
  			local Button = vgui.Create( "Button", CommandList );
  			Button:SetText( data.name );
  			function Button:DoClick( )
  				RunConsoleCommand(data.cmd)
  			end
  			CommandList:AddItem(Button)
  			cmdHeight = cmdHeight + 27
  	end
  	
  	for _,data in pairs(CE.cvars) do
  		if data.cmd and data.noargs then
  		elseif data.cvar and not data.NoToggle then
  		end
  	end
  	ConVarList:SetSize(400,cvarHeight)
  	CommandList:SetSize(400,cmdHeight)
  	GUIFrame = Frame
  	return Frame
  end
  CE.Hook.Add("ModulesLoaded", "CE.CreateGUI", createGUI)
  MODULE.AddCmd({Nick="GUI", Name="hacks_gui", Function=function()
  	if(GUIFrame:IsVisible()) then
  		GUIFrame:Hide()
  	elseif(not IsValid(GUIFrame)) then
  		createGUI()
  		GUIFrame:Show()
  	else
  		GUIFrame:Show()
  	end
  end, HUD={ Category="Misc", Type="CommandButton"}})
end