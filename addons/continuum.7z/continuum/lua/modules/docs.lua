MODULE.ID = "com.continuum.docs"
MODULE.Dependencies = { }
MODULE.Init = function(CE)
  CE.Documentation = { }
  http.Fetch( "http://samuelmaddock.github.io/glua-docs/data/glua.json", function(body, len, headers, code)
    if code == 200 then
      CE.Documentation = util.JSONToTable(body)
      for k,v in pairs(CE.Documentation) do
        v.code = v.html
        :gsub('&#58;', ':')
        :gsub("<(.-)>", ""):gsub("\n\n", "\n"):gsub("\n\n", "\n"):gsub("\n\n", "\n")
        rawset(CE.Documentation, k, nil)
        rawset(CE.Documentation, v.title, v)
      end
      for k,v in pairs(CE.Documentation) do
        rawset(CE.Documentation, k, nil)
        rawset(CE.Documentation, v.title, v)
      end
    end
  end, function() print("Failed to load documentation") end)
  MODULE.AddCmd({Nick="GLuaDocs", Name="hacks_docs", Function=function(ply, cmd, args)
    local argstr = table.concat(args, ' ')
    local data = CE.Documentation[argstr]
    if not data then print("No docs found for '" .. argstr .. "'") return end
    local MOTDFrame = vgui.Create( "DFrame" )
    MOTDFrame:SetTitle( data.title .. " - " .. data.scope )
    MOTDFrame:SetSize( ScrW()/2, ScrH()/2 )
    MOTDFrame:Center()
    MOTDFrame:SetBackgroundBlur( true )
    MOTDFrame:MakePopup()

    local MOTDHTMLFrame = vgui.Create( "HTML", MOTDFrame )
    MOTDHTMLFrame:SetPos( 25, 50 )
    MOTDHTMLFrame:SetSize( MOTDFrame:GetWide() - 50, MOTDFrame:GetTall() - 150 )
    MOTDHTMLFrame:SetHTML( data.html )
  end, Autocomplete=function(cmd, args)
    local res = { }
    local str = cmd .. args
    for title,data in CE.PairsByKeys(CE.Documentation) do
      local s = cmd.." "..title
      if s:starts(str) then
        table.insert(res, s)
      end
    end
    return res
  end})
end