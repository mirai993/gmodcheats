MODULE.ID = "com.continuum.hud"
MODULE.Dependencies = { "com.continuum.antiban" }

MODULE.Name = "HUD"
MODULE.Info = "Heads Up Display module, shows status of some other modules"
MODULE.cvars = {
  { Name="hacks_compass", Nick="Compass", Info="Draws a compass (axes) on your screen", Default="0", HUD={ Category="Misc", Type="ToggleButton"}},
  { Name="hacks_crosshairs", Nick="Crosshairs", Info="Draws better crosshairs", Default="1", HUD={ Category="Misc", Type="ToggleButton"}}
}
MODULE.Init = function(CE)
  MODULE.AddCmd({ Nick="HUD", Name="hacks_hud_toggle", info="Draws HUD to screen", Function=function()
    CE.Session.HUDFrame:SetVisible(not CE.Session.HUDFrame:IsVisible())
  end, HUD={ Category="Misc", Type="CommandButton", IsOn=function() return CE.Session.HUDFrame:IsVisible() end}})
  local Colors = CE.Colors
  local draw = draw
  local surface = surface
  local GM = GAMEMODE
  local scope = surface.GetTextureID("sprites/scope")
  local crosshairs = Material( "continuum/crosshairs2.png" )
  local wireframeMat = Material( "hlmv/debugmrmwireframe" )
  local explosion = Material( "continuum/explosion.png" )

  local baseX = ScrW() - 225
  local baseY =  ScrH() - 400
  local width = 200
  local height = 30
  local y
  local function Key(binding, default)
    local b = input.LookupBinding(binding)
    if not b then return default end

    return string.upper(b)
  end
  local function DrawInfo(material, info, InfoColor, key, KeyColor)
    if material then
      surface.SetDrawColor( CE.Colors.WHITE );
      surface.SetMaterial( material );
      surface.DrawTexturedRect( baseX+5, y, 20, 20 );
    else
      y = y - 10
    end
    if info then
      draw.DrawText(info, "ChatFont", baseX+40, y+3, InfoColor or Colors.BLACK, TEXT_ALIGN_LEFT )
    end
    if key then
      draw.DrawText(key, "ChatFont", baseX+width-6, y+3, KeyColor or Colors.GREEN, TEXT_ALIGN_RIGHT )
    end
    y = y + 25
    height = y + 10 - baseY
  end
  surface.CreateFont("ContinuumTitle", {
    font="Default",
    size=15
  })
  surface.CreateFont("BigTitle", {
    font="Default",
    size=50,
    weight = 900
  })
  local max = math.max
  local floor = math.floor
  local function drawHackHUD()
    y = baseY

    --Draw background:
    draw.RoundedBoxEx(8, baseX, baseY, width, 27, Color(25,25,25,250), true, true, false, false)
    draw.RoundedBoxEx(8, baseX, baseY+27, width, height-27, Color(25,25,25,215), false, false, true, true)

    surface.SetDrawColor(Color(220,220,220,200))
    surface.DrawLine(baseX, baseY+27, baseX+width, baseY+27)

    --Draw title:
    draw.DrawText("Engine Modules", "ContinuumTitle", baseX+15, baseY+5, Colors.CONTINUUM, TEXT_ALIGN_LEFT )

    --Draw aimbot:
    y = y + 30 -- 30
    local aimbot = GetConVarNumber("hacks_aimbot")
    local aimbotKey = Key("hacks_aimbot_toggle", "")
    DrawInfo(crosshairs, aimbot == CE.Constants.AIMBOT_ERROR and "Error" or aimbot == CE.Constants.AIMBOT_SOFT and "Weak Lock" or aimbot == CE.Constants.AIMBOT_HARD and "Strong Lock" or "Off", Colors.GetTrafficColor(aimbot*50), aimbotKey)

    --Draw aimbotv2:
    local aimbotv2 = GetConVarNumber("hacks_aimbotv2")
    local aimbotv2Key = Key("hacks_aimbotv2_toggle", "")
    DrawInfo(crosshairs, aimbotv2 == CE.Constants.AIMBOT_ERROR and "Error" or aimbotv2 == CE.Constants.AIMBOT_SOFT and "AimRape" or "Off", Colors.GetTrafficColor(aimbotv2*100), aimbotv2Key)
    draw.DrawText(  "v2","TargetIDSmall",baseX+25, y-20,Color(255, 255, 255, 255),1)

    --Draw wireframe:
    local wireframe = GetConVarNumber("hacks_wireframe")
    local wireframeKey = Key("hacks_wireframe_toggle", "")
    DrawInfo(wireframeMat, wireframe == 1 and "Weapons" or wireframe==2 and "Bodies" or wireframe==3 and "Gamemode" or wireframe==4 and "All" or "None", wireframe == 0 and Colors.GetTrafficColor(0) or wireframe == 4 and Colors.GetTrafficColor(100) or Colors.GetTrafficColor(50), wireframeKey)

    --Draw triggerbot
    local triggerbot = GetConVarNumber("hacks_triggerbot")
    local triggerbotKey = Key("hacks_triggerbot_toggle", "")
    DrawInfo(explosion, triggerbot >= 1 and "On" or "Off", Colors.GetTrafficColor(triggerbot*100), triggerbotKey)

    --Draw prop count
    if CE.IsTTT() then
      DrawInfo(nil, "Credits: "..tostring(LocalPlayer():GetCredits()),Colors.GREEN)
    else
      local props = LocalPlayer():GetNetworkedInt("Count.Props")
      local maxprops = GetConVarNumber("sbox_maxprops")
      DrawInfo(nil, "Props: "..tostring(props).."/"..tostring(maxprops),Colors.GetTrafficColor(100-props/maxprops*100 ))
    end
    --Draw position
    local Pos,X,Y,Z = LocalPlayer():GetPos()
    X = math.round(Pos.x,1)
    Y = math.round(Pos.y,1)
    Z = math.round(Pos.z,1)
    draw.DrawText("("..tostring(X)..","..tostring(Y)..","..tostring(Z)..")", "ChatFont", baseX+width/2, baseY+height-20, Colors.WHITE, TEXT_ALIGN_CENTER )
  end
  CE.Hook.Remove("HUDPaint", "CE.HackHUD", drawHackHUD)
  local X,Y
  if CE.Session.HUDFrame then X,Y=CE.Session.HUDFrame:GetPos() CE.Session.HUDFrame:Remove() else
    X,Y=CE.GetPersistant("HUDPosition", {x=20}).x,CE.GetPersistant("HUDPosition", {y=50}).y
  end
  local HUDFrame = vgui.Create('DFrame')
  CE.Session.HUDFrame = HUDFrame
  HUDFrame:SetSize(width, width)
  HUDFrame:SetPos(X,Y)
  HUDFrame:SetTitle('')
  HUDFrame:SetSizable(false)
  HUDFrame:SetVisible(true)
  HUDFrame:SetDraggable(true)
  HUDFrame:SetDeleteOnClose(false)
  HUDFrame.btnMinim:SetVisible(false)
  HUDFrame.btnMaxim:SetDisabled( false )
  HUDFrame.btnMaxim.DoClick = function ( button ) HUDFrame.Minimized = not HUDFrame.Minimized end
  HUDFrame.btnMaxim.Paint = function( panel, w, h )
    if not HUDFrame.Minimized then
      derma.SkinHook( "Paint", "WindowMinimizeButton", panel, w-1, h )
    else
      derma.SkinHook( "Paint", "WindowMaximizeButton", panel, w, h )
    end
  end
  local LastSave=0
  function HUDFrame:Paint()
    baseX=0
    baseY=0
    drawHackHUD()
    if HUDFrame.Minimized then
      HUDFrame:SetSize(width, 25)
    else
      HUDFrame:SetSize(width, height)
    end
    local x,y = HUDFrame:GetPos()
    local pos = {x=x,y=y}
    -- No need to save unless the position has changed and also no need to save more frequqently than 1 hertz
    if (x ~= CE.GetPersistant('HUDPosition', {x=20}).x or y ~= CE.GetPersistant('HUDPosition', {y=50}).y) and CurTime() > LastSave+1 then
      CE.SetPersistant('HUDPosition', pos)
      LastSave=CurTime()
    end
  end
  local DamageInfos = { }
  local pos = nil
  local function drawX()
    local x = ScrW() / 2
    local y = ScrH() / 2
    if pos then x = pos.x; y = pos.y end

    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.DrawLine( x - 8, y - 8, x - 15, y - 15 )
    surface.DrawLine( x + 8, y - 8, x + 15, y - 15 )
    surface.DrawLine( x + 8, y + 8, x + 15, y + 15 )
    surface.DrawLine( x - 8, y + 8, x - 15, y + 15 )
  end
  function GM:PlayerTraceAttack( ply, dmginfo, dir, trace )
    local info = { Damage=dmginfo:GetDamage(), Victim=ply, Position=dmginfo:GetDamagePosition() }
    DamageInfos[info] = CurTime()
    return false
  end
  function GAMEMODE:ScalePlayerDamage(ply,hitgroup,dmginfo)
    if dmginfo:GetAttacker():IsPlayer() and dmginfo:GetAttacker() == LocalPlayer() then
      pos = dmginfo:GetDamagePosition():ToScreen()
      CE.Hook.Add("HUDPaint", "HitMarkers", drawX)
      timer.Simple(0.5, function() CE.Hook.Remove("HUDPaint", "HitMarkers") end)
    end
  end

  local CompassOffset = {x=ScrW()/2-120,y=ScrH()/2-240}
  local RadarOffset = {x=50,y=50}
  local ScreenSize = {x=ScrW(),y=ScrH()}
  local ScreenCenter = {x=ScreenSize.x/2,y=ScreenSize.y/2}
  local DIST = 500
  local function VectorToLPCameraScreen( vDir, iScreenW, iScreenH, angCamRot, fFoV )
    --Same as we did above, we found distance the camera to a rectangular slice of the camera's frustrum, whose width equals the "4:3" width corresponding to the given screen height.
    local d = 4 * iScreenH / ( 6 * math.tan( 0.5 * fFoV ) );
    local fdp = angCamRot:Forward():Dot( vDir );

    --fdp must be nonzero ( in other words, vDir must not be perpendicular to angCamRot:Forward() )
    --or we will get a divide by zero error when calculating vProj below.
    if fdp == 0 then
      return 0, 0, -1
    end

    --Using linear projection, project this vector onto the plane of the slice
    local vProj = ( d / fdp ) * vDir;

    --Dotting the projected vector onto the right and up vectors gives us screen positions relative to the center of the screen.
    --We add half-widths / half-heights to these coordinates to give us screen positions relative to the upper-left corner of the screen.
    --We have to subtract from the "up" instead of adding, since screen coordinates decrease as they go upwards.
    local x = 0.5 * iScreenW + angCamRot:Right():Dot( vProj );
    local y = 0.5 * iScreenH - angCamRot:Up():Dot( vProj );

    --Lastly we have to ensure these screen positions are actually on the screen.
    local iVisibility
    if fdp < 0 then			--Simple check to see if the object is in front of the camera
      iVisibility = -1;
    elseif x < 0 or x > iScreenW or y < 0 or y > iScreenH then	--We've already determined the object is in front of us, but it may be lurking just outside our field of vision.
      iVisibility = 0;
    else
      iVisibility = 1;
    end

    return x, y, iVisibility;
  end
  local function DrawRealHUD()
    if not HUDFrame:IsVisible() then return end
    local players = player.GetAll()
    -- Draw traitors
    if CE.IsTTT() then
      if(CE.IsRoundOver() and (GetGlobalInt("ttt_rounds_left", 6) == 0 or floor(max(0, ((GetGlobalInt("ttt_time_limit_minutes") or 60) * 60) - CurTime())) == 0)) then
        if(floor(CurTime() % 2) == 1) then
          draw.DrawText("MAP CHANGE", "BigTitle", ScrW()/2-50, ScrH()/2, Colors.RED, TEXT_ALIGN_CENTER )
        end
      end
      local traitorsString = "Known traitors: "
      for k,v in pairs(players) do
        if v.HatTraitor or (v.GetTraitor ~= nil and v:GetTraitor()) then
          if traitorsString == "Known traitors: " then
            traitorsString = traitorsString..v:Nick()
          else
            traitorsString = traitorsString.."; "..v:Nick()
          end
        end
      end
      draw.DrawText(traitorsString, "TargetID", ScrW() / 2, ScrH() - 120, Colors.RED, TEXT_ALIGN_CENTER)
    end
    -- Draw spectators
    local spectatorsString = "Spectating you: "
    for k,v in pairs(players) do
      if v:IsSpectatingLocalPlayer() then
        local name = v:Nick() .. v:GetTag()
        if spectatorsString == "Spectating you: " then
          spectatorsString = spectatorsString..name
        else
          spectatorsString = spectatorsString.."; "..name
        end
      end
    end
    draw.DrawText(spectatorsString , "TargetID", ScrW() / 2, ScrH() - 100, Colors.RED, TEXT_ALIGN_CENTER)
    local lookingAtString = "Looking at you: "
    for k,v in pairs (players) do
      if v:IsLookingAt(LocalPlayer()) then
        local name = v:Nick() .. v:GetTag()
        if lookingAtString == "Looking at you: " then
          lookingAtString = lookingAtString..name
        else
          lookingAtString = lookingAtString.."; "..name
        end
      end
    end
    draw.DrawText(lookingAtString , "TargetID", ScrW() / 2, ScrH() - 80, Colors.RED, TEXT_ALIGN_CENTER)
    for dmginfo,time in pairs(DamageInfos) do
      local elapsedRatio = (CurTime()-time) / 2
      if elapsedRatio >= 1 then
        DamageInfos[dmginfo]=nil
      else
        local position = dmginfo.Position
        position = position:ToScreen()
        if position then
          position.y = position.y - elapsedRatio * 20
          local color = Color(255,0,0,255 * (1 - elapsedRatio))
          draw.DrawText("-"..math.round(dmginfo.Damage), "TargetID", position.x, position.y, color, TEXT_ALIGN_CENTER)
        end
      end
    end
    if CE.GetConVarBool("hacks_compass") then
      local Data = hook.Run( "CalcView", LocalPlayer(), EyePos(), EyeAngles(), 75 )
      local Position = Data.origin or EyePos()
      local Angles = Data.angles or EyeAngles()
      local AnglesClone = Angle(Angles.p, Angles.y, Angles.r)
      local FOV = LocalPlayer():GetFOV() == 75 and Data.fov or LocalPlayer():GetFOV()
      local ratio = math.pow(FOV,1.1) / 115
      local Center = Position + Angles:Forward() * 100 / ratio
      local XEnd = Center + Vector(20,0,0)
      local YEnd = Center + Vector(0,20,0)
      local ZEnd = Center + Vector(0,0,20)
      local testEnd = Center + Angles:Up() * 20


      local ScrCenter = Center:ToScreen()
      local ScrXEnd = XEnd:ToScreen()
      local ScrYEnd = YEnd:ToScreen()
      local ScrZEnd = ZEnd:ToScreen()
      local ScrTestEnd = testEnd:ToScreen()

      local SIZE = math.sqrt((ScrCenter.x - ScrTestEnd.x)^2 + (ScrCenter.y - ScrTestEnd.y)^2)

      Angles.y = Angles.y - 50
      Angles.p = 0
      Angles.r = 0
      local FOVLeft = (Center + Angles:Forward() * 10):ToScreen()
      Angles.y = Angles.y + 50 * 2
      local FOVRight = (Center + Angles:Forward() * 10):ToScreen()
      ScrCenter.x = ScrCenter.x + CompassOffset.x
      ScrXEnd.x = ScrXEnd.x + CompassOffset.x
      ScrYEnd.x = ScrYEnd.x + CompassOffset.x
      ScrZEnd.x = ScrZEnd.x + CompassOffset.x
      FOVLeft.x = FOVLeft.x + CompassOffset.x
      FOVRight.x = FOVRight.x + CompassOffset.x
      ScrTestEnd.x = ScrTestEnd.x + CompassOffset.x

      ScrCenter.y = ScrCenter.y + CompassOffset.y
      ScrXEnd.y = ScrXEnd.y + CompassOffset.y
      ScrYEnd.y = ScrYEnd.y + CompassOffset.y
      ScrZEnd.y = ScrZEnd.y + CompassOffset.y
      FOVLeft.y = FOVLeft.y + CompassOffset.y
      FOVRight.y = FOVRight.y + CompassOffset.y
      ScrTestEnd.y = ScrTestEnd.y + CompassOffset.y

      surface.SetDrawColor( 255, 0, 0, 150 )
      surface.DrawLine( ScrCenter.x, ScrCenter.y, ScrXEnd.x, ScrXEnd.y )
      surface.SetDrawColor( 0, 255, 0, 150 )
      surface.DrawLine( ScrCenter.x, ScrCenter.y, ScrYEnd.x, ScrYEnd.y )
      surface.SetDrawColor( 0, 0, 255, 150 )
      surface.DrawLine( ScrCenter.x, ScrCenter.y, ScrZEnd.x, ScrZEnd.y )
      --surface.SetDrawColor( 255, 0, 255, 150 )
      --surface.DrawLine( ScrCenter.x, ScrCenter.y, ScrTestEnd.x, ScrTestEnd.y )


      surface.SetDrawColor( 0, 0, 0, 200 )
      surface.DrawLine( ScrCenter.x, ScrCenter.y, FOVLeft.x, FOVLeft.y )
      surface.DrawLine( ScrCenter.x, ScrCenter.y, FOVRight.x, FOVRight.y )
      for k,v in pairs(players) do
        local Relative = v:EyePos() - Position
        if Relative:Length() < DIST then
          if v == LocalPlayer() then surface.SetDrawColor(Colors.WHITE) else
            surface.SetDrawColor( team.GetColor(v:Team()) )
          end
          Relative.x = Relative.x / 200 * (5000  / DIST)
          Relative.y = Relative.y / 200 * (5000  / DIST)
          Relative.z = Relative.z / 50 * (5000  / DIST)
          Relative = Center + Relative
          local ScrRelative = Relative:ToScreen()
          ScrRelative.x = ScrRelative.x + CompassOffset.x
          ScrRelative.y = ScrRelative.y + CompassOffset.y
          surface.DrawLine( ScrRelative.x -1, ScrRelative.y - 1, ScrRelative.x + 1, ScrRelative.y + 1 )
          surface.DrawLine( ScrRelative.x - 1, ScrRelative.y + 1, ScrRelative.x + 1, ScrRelative.y - 1 )
        end
      end
    end
    --[[if CE.GetConVarBool("hacks_radar") then
    -- local DIST = 550
    local SIZE = 100
    local Data = hook.Run( "CalcView", LocalPlayer(), EyePos(), EyeAngles(), 75 )
    local Position = Data.origin or EyePos()
    local Angles = Data.angles or EyeAngles()
    local FOV = LocalPlayer():GetFOV() == 75 and Data.fov or LocalPlayer():GetFOV()
    local ratio = math.pow(FOV,1.1) / 115
    local CamData = {}
    CamData.origin = Vector(Position.x,Position.y,900)
    CamData.angles = CamData.origin:AngleTo(LocalPlayer():GetPos())
    CamData.angles.y = Angles.y
    CamData.x = RadarOffset.x
    CamData.y = RadarOffset.y
    CamData.w = SIZE * 2
    CamData.h = SIZE * 2
    CamData.fov = 75
    CamData.drawviewmodel = false
    render.DrawLocalPlayer = false
    render.RenderView( CamData )
    render.DrawLocalPlayer = nil
    Angles.p = 0
    Position.z = 0
    Angles.y = Angles.y + 180
    for k,v in pairs(players) do
    local Relative = v:EyePos() - Position
    --Relative.z = 0
    if true then
    if v == LocalPlayer() then
    surface.SetDrawColor(CE.Colors.WHITE)
    else
    surface.SetDrawColor( team.GetColor(v:Team()) )
    end
    --local AnglesClone = Angle(0, Angles.y, 0)
    --Relative:Rotate(AnglesClone)
    local t = v:GetPos()
    t.z = 0
    local a = Angle(CamData.angles.p, CamData.angles.y, CamData.angles.r)
    --a.y = t:AngleTo(CamData.origin).y

    local x,y, vis = VectorToLPCameraScreen(CamData.origin - t, CamData.w, CamData.h, a, math.rad(CamData.fov or 75))
    Relative = {x = x - SIZE,y = y - SIZE}

    Relative.x = Relative.x
    Relative.y = Relative.y


    if vis and math.abs(Relative.x) < SIZE and math.abs(Relative.y) < SIZE then
    -- console.Print(x, " ", y)
    -- Relative:Rotate(Angle(0,Angles.y,0))
    Relative.x = Relative.x + RadarOffset.x + SIZE
    Relative.y = Relative.y + RadarOffset.y + SIZE
    local length = 2
    surface.DrawLine( Relative.x - length, Relative.y - length, Relative.x + length, Relative.y + length )
    surface.DrawLine( Relative.x - length, Relative.y + length, Relative.x + length, Relative.y - length )
    end
    end
    end
    end]]
  end
  CE.Hook.Add("HUDPaint", "CE.DrawHUD", DrawRealHUD)
  CE.Hook.Add("HUDPaint", "DrawCrosshairs", function()
    if CE.GetConVarBool("hacks_crosshairs") then
      local weapon = LocalPlayer():GetActiveWeapon()
      local x,y = ScrW() / 2, ScrH() / 2
      local dx, dy, size = 0,0,0
      if not CE.GetConVarBool("hacks_nospread") and IsValid(weapon) then
        local cone = CE.GetVectorCone(weapon)
        dx = cone.x or 0
        dy = cone.y or 0
        dx,dy = math.abs(dx * 750), math.abs(dy * 750)
      end
      size = 25
      surface.SetDrawColor(Color(255,255,255))
      surface.DrawLine(x - dx - size, y, x - dx, y)
      surface.DrawLine(x + dx, y, x + dx + size, y)
      surface.DrawLine(x, y - dy - size, x, y - dy)
      surface.DrawLine(x, y + dy, x, y + dy + size)
      size = 20
      surface.SetDrawColor(team.GetColor(LocalPlayer():Team()) or Color(255,0,0))
      surface.DrawLine(x - dx - size, y, x - dx, y)
      surface.DrawLine(x + dx, y, x + dx + size, y)
      surface.DrawLine(x, y - dy - size, x, y - dy)
      surface.DrawLine(x, y + dy, x, y + dy + size)
    end
  end)
end