MODULE.ID = "com.continuum.drp.keypadcracker"
MODULE.Dependencies = { "com.continuum.notify" }

MODULE.Name = "DarkRP Keypad Cracker"
MODULE.Info = "Keypad cracker for darkrp by eye positions"

MODULE.Init = function(CE)
  local function crackKeypad(keypad)
  	local vars = keypad:GetNetworkVars()
  	if vars.Status ~= 0 or (keypad.CrackTime and CurTime() < keypad.CrackTime) then return end
  	if not keypad.CrackData or not keypad.CrackData.Pass then
  		CE.Console.Warning("Keypad not yet cracked; wait for a player to enter their password")
  		return
  	end
  	-- Clear old password:
  	if #vars.DisplayText ~= 0 then
  		net.Start("keypad_command")
  		net.WriteEntity(keypad)
  		net.WriteUInt(1, 3)
  		net.SendToServer()
  	end
  	-- Iterate through our pass string, convert each digit to a number, and send it to server
  	for i=1,math.min(#keypad.CrackData.Pass,4) do
  		local digit = tonumber(keypad.CrackData.Pass:sub(i,i)) or 1
  		net.Start("keypad_command")
  		net.WriteEntity(keypad)
  		net.WriteUInt(0, 3)
  		net.WriteUInt(digit, 10)
  		net.SendToServer()
  		i = i + 1
  	end
  
  	--
  	keypad.CrackTime = CurTime()+.5
  	net.Start("keypad_command")
  	net.WriteEntity(keypad)
  	net.WriteUInt(2, 3)
  	net.SendToServer()
  	timer.Simple(1, function()
  		if keypad:GetNetworkVars().Status == 2 then
  			keypad.CrackData.Pass = nil
  			CE.Notify.All("Invalidated keypad, passcode failed")
  		elseif keypad:GetNetworkVars().Status == 1 then
  			CE.Notify.All("Validated keypad, passcode succeeded!")
  			keypad.Valid = true
  		end
  	end)
  end
  
  local SentTime = nil
  
  local X = -50
  local Y = -100
  local W = 100
  local H = 200
  
  local KeyPos =	{	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
  	{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
  	{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
  
  	{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
  	{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
  	{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
  
  	{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
  	{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
  	{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
  
  	{X+5, Y+67.5, 40, 25, -2.2, 4.25, -0.3, 1.6},
  	{X+55, Y+67.5, 40, 25, 0.3, 1.65, -0.3, 1.6}
  }
  
  CE.Hook.Add("Think", "CE.CrackKeypads", function()
  	local keypads = ents.FindByClass("keypad")
  	if #keypads == 0 then return end
  	for _,ply in pairs(player.GetAll()) do
  		local time = CurTime()
  		ply.EyeHistory = ply.EyeHistory or { }
  		local tr = util.TraceLine({start=ply:GetShootPos(), endpos=ply:GetAimVector()*32+ply:GetShootPos(), filter=ply})
  		ply.EyeHistory[time] = tr.HitPos
  		for Time,Hit in CE.PairsByKeys(ply.EyeHistory) do
  			if Time < time - .15 then
  				ply.EyeHistory[Time] = nil
  			end
  		end
  	end
  	for _,keypad in pairs( keypads ) do
  		local vars = keypad:GetNetworkVars()
  		if keypad.CrackData then
  			if vars.Status == 0 then
  				if vars.DisplayText ~= keypad.CrackData.OldDisplayText then
  					if #vars.DisplayText == 0 then
  						keypad.CrackData.Log = ""
  					elseif #keypad.CrackData.OldDisplayText < 4 then
  						local IsEncrypted = vars.DisplayText:sub(1, 1) == "*"
  						--[[if SentTime then
  						local dif = CurTime() - SentTime
  						local ratio = dif / LocalPlayer():Ping()
  						console.AddText("Difference: ", dif, "; ratio: ", ratio, "\n")
  						SentTime = nil
  						end]]
  						if IsEncrypted then
  							local Key = "?"
  							local Multi = false
  							--[[for _,ply in pairs(player.GetAll()) do
  							local tr = util.TraceLine({start=ply:GetShootPos(), endpos=ply:GetAimVector()*32+ply:GetShootPos(), filter=ply})
  
  							local pos = keypad:WorldToLocal(tr.HitPos)
  
  							for k,v in pairs(KeyPos) do
  							local x = (pos.y - v[5]) / (v[5] + v[6])
  							local y = 1 - (pos.z + v[7]) / (v[7] + v[8])
  
  							if (x >= 0) and (y >= 0) and (x <= 1) and (y <= 1) then
  							if Key ~= "?" then Multi = true end
  							Key = tostring(k)
  							end
  							end
  							end]]
  							local time = CurTime()
  							for _,ply in pairs(player.GetAll()) do
  								local target = time - (.1 * LocalPlayer():Ping() / 48)
  								local BestTime,BestHit
  								for Time,Hit in CE.PairsByKeys(ply.EyeHistory) do
  									if BestTime == nil or math.abs(Time-target) < math.abs(BestTime-target) then
  										BestTime,BestHit = Time,Hit
  									end
  								end
  								if BestHit then
  									local pos = keypad:WorldToLocal(BestHit)
  
  									for k,v in pairs(KeyPos) do
  										local x = (pos.y - v[5]) / (v[5] + v[6])
  										local y = 1 - (pos.z + v[7]) / (v[7] + v[8])
  
  										if (x >= 0) and (y >= 0) and (x <= 1) and (y <= 1) then
  											if Key ~= "?" then Multi = true end
  											Key = tostring(k)
  										end
  									end
  								end
  							end
  							if Multi then Key = "?" end
  							keypad.CrackData.Log = keypad.CrackData.Log .. Key
  						else
  							keypad.CrackData.Log=vars.DisplayText
  
  						end
  					end
  				end
  			elseif vars.Status == 1 and keypad.CrackData.OldStatus ~= 1 then
  				if not keypad.Valid and not keypad.CrackData.Log:find("?") and (keypad.CrackTime == nil or CurTime() > keypad.CrackTime+.5) then
  					keypad.CrackData.Pass=keypad.CrackData.Log
  					local owner = keypad:GetRealOwner()
  					if IsValid(owner) then
  						CE.Notify.All("Cracked "..owner:Nick().."'s keypad: "..keypad.CrackData.Pass)
  					else
  						CE.Notify.All("Cracked keypad: "..keypad.CrackData.Pass)
  					end
  				end
  				keypad.CrackData.Log=""
  			elseif vars.Status == 2 and keypad.CrackData.OldStatus ~= 2 then
  				keypad.CrackData.Log=""
  			end
  		else
  			keypad.CrackData = { Log=vars.DisplayText }
  		end
  		keypad.CrackData.OldDisplayText=vars.DisplayText
  		keypad.CrackData.OldStatus=vars.Status
  
  		if(LocalPlayer():EyePos():Distance(keypad:GetPos()) <= 50 and vars.Status == 0 and CE.GetConVarBool("hacks_keypadautocrack")) then
  			crackKeypad(keypad)
  		end
  	end
  end)
  
  CE.Hook.Add( "HUDPaint", "CE.DrawKeypadCrack", function()
  	local e = LocalPlayer():GetEyeTrace().Entity
  	if IsValid(e) and string.find(e:GetClass(), "keypad") and e.CrackData then
  		local text = "Pass: %code; Log: %log; Status: %status;"
  		local code = e.CrackData.Pass or "Not Found"
  		local log = e.CrackData.Log or "nil"
  		local status = e:GetNetworkVars().Status == 2 and "Denied" or e:GetNetworkVars().Status == 1 and "Granted" or "0"
  
  		text = string.Replace( text, "%code", code )
  		text = string.Replace( text, "%log", log )
  		text = string.Replace( text, "%status", status )
  		draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
  	end
  end)
  CE.Hook.Add("NetStart", "CE.KeypadCheck", function(name)
  	if name == "keypad_command" then
  		SentTime = CurTime()
  	end
  end)
  MODULE.AddCVar({
  	Name="hacks_keypadautocrack",
  	Info="Automatically cracks nearby keypads",
  	Default=0,
  	HUD={ Category="Misc", Type="ToggleButton"}
  })
  MODULE.AddCmd({
  	Name="hacks_keypadcrack",
  	Nick="Crack keypad",
  	Info="Cracks a keypad (wait for someone to enter a pass first)",
  	Function=function()
  		local e = LocalPlayer():GetEyeTrace().Entity
  		if(not (e and e:GetClass() == "keypad" and LocalPlayer():EyePos():Distance(e:GetPos()) <= 50)) then
  			local closestKeypad = nil
  			local closestDist = -1
  			for _,keypad in pairs(ents.FindByClass("keypad")) do
  				local dist = LocalPlayer():GetPos():Distance(keypad:GetPos())
  				if(LocalPlayer():EyePos():Distance(keypad:GetPos()) <= 50 and (closestKeypad == nil or dist < closestDist)) then
  					closestDist = dist
  					closestKeypad = keypad
  				end
  			end
  			e = closestKeypad
  		end
  		if e then
  			crackKeypad(e)
  		else
  			CE.Console.Warning("No keypads found near player; move closer to the keypad.")
  			return
  		end
  
  	end,
  	HUD={ Category="Misc", Type="CommandButton"}
  })
end