MODULE.ID = "com.continuum.stool"
MODULE.Dependencies = { }

MODULE.Name="STool"
MODULE.Info="Adds STools for continuum to spawn menu"

MODULE.Init = function(CE)
  local SWEP = weapons.GetStored("gmod_tool")
  if SWEP then
    ToolObj = {}
    --[[---------------------------------------------------------
    Starts up the ghost entity
    The most important part of this is making sure it gets deleted properly
    -----------------------------------------------------------]]
    function ToolObj:MakeGhostEntity( model, pos, angle )

      util.PrecacheModel( model )

      -- We do ghosting serverside in single player
      -- It's done clientside in multiplayer
      if (SERVER and not game.SinglePlayer()) then return end
      if (CLIENT and game.SinglePlayer()) then return end

      -- Release the old ghost entity
      self:ReleaseGhostEntity()

      -- Don't allow ragdolls/effects to be ghosts
      if (not util.IsValidProp( model )) then return end

      if ( CLIENT ) then
        self.GhostEntity = ents.CreateClientProp( model )
      else
        self.GhostEntity = ents.Create( "prop_physics" )
      end

      -- If there's too many entities we might not spawn..
      if (not self.GhostEntity:IsValid()) then
        self.GhostEntity = nil
        return
      end

      self.GhostEntity:SetModel( model )
      self.GhostEntity:SetPos( pos )
      self.GhostEntity:SetAngles( angle )
      self.GhostEntity:Spawn()

      self.GhostEntity:SetSolid( SOLID_VPHYSICS );
      self.GhostEntity:SetMoveType( MOVETYPE_NONE )
      self.GhostEntity:SetNotSolid( true );
      self.GhostEntity:SetRenderMode( RENDERMODE_TRANSALPHA )
      self.GhostEntity:SetColor( Color( 255, 255, 255, 180 ) ) -- fuck using 150, that's too low for the fence thing
      -- Well this didn't fix the stacker tool though, it must have it's own ghoster :/ We'll have to
      -- check that out, maybe copy+paste but modify the color? But we'd need to have different versions :/ mybe just
      -- override one function...

      -- overall, big success today, somewhat fixed this, made TOOL's clear old ghosts, added ghosts for worldedit tool
      -- which is nice bc u can see where gm_spawn places it
      -- added functionality for skin and bodygroups, made it detect when u spawn a prop and calls a hook
      -- I think I should probably read my book now...
    end

    --[[---------------------------------------------------------
    Starts up the ghost entity
    The most important part of this is making sure it gets deleted properly
    -----------------------------------------------------------]]
    function ToolObj:StartGhostEntity( ent )

      -- We can't ghost ragdolls because it looks like ass
      local class = ent:GetClass()

      -- We do ghosting serverside in single player
      -- It's done clientside in multiplayer
      if (SERVER and not game.SinglePlayer()) then return end
      if (CLIENT and game.SinglePlayer()) then return end

      self:MakeGhostEntity( ent:GetModel(), ent:GetPos(), ent:GetAngles() )

    end

    --[[---------------------------------------------------------
    Releases up the ghost entity
    -----------------------------------------------------------]]
    function ToolObj:ReleaseGhostEntity()

      if ( self.GhostEntity ) then
        if (not self.GhostEntity:IsValid()) then self.GhostEntity = nil return end
        self.GhostEntity:Remove()
        self.GhostEntity = nil
      end

      if ( self.GhostEntities ) then

        for k,v in pairs( self.GhostEntities ) do
          if ( v:IsValid() ) then v:Remove() end
          self.GhostEntities[k] = nil
        end

        self.GhostEntities = nil
      end

      if ( self.GhostOffset ) then

        for k,v in pairs( self.GhostOffset ) do
          self.GhostOffset[k] = nil
        end

      end

    end

    --[[---------------------------------------------------------
    Update the ghost entity
    -----------------------------------------------------------]]
    function ToolObj:UpdateGhostEntity()

      if (self.GhostEntity == nil) then return end
      if (not self.GhostEntity:IsValid()) then self.GhostEntity = nil return end

      local tr = util.GetPlayerTrace( self:GetOwner() )
      local trace = util.TraceLine( tr )
      if (not trace.Hit) then return end

      local Ang1, Ang2 = self:GetNormal(1):Angle(), (trace.HitNormal * -1):Angle()
      local TargetAngle = self:GetEnt(1):AlignAngles( Ang1, Ang2 )

      self.GhostEntity:SetPos( self:GetEnt(1):GetPos() )
      self.GhostEntity:SetAngles( TargetAngle )

      local TranslatedPos = self.GhostEntity:LocalToWorld( self:GetLocalPos(1) )
      local TargetPos = trace.HitPos + (self:GetEnt(1):GetPos() - TranslatedPos) + (trace.HitNormal)

      self.GhostEntity:SetPos( TargetPos )

    end



    --[[---------------------------------------------------------
    Sets which stage a tool is at
    -----------------------------------------------------------]]
    function ToolObj:UpdateData()

      self:SetStage( self:NumObjects() )

    end

    --[[---------------------------------------------------------
    Sets which stage a tool is at
    -----------------------------------------------------------]]
    function ToolObj:SetStage( i )

      if ( SERVER ) then
        self:GetWeapon():SetNWInt( "Stage", i, true )
      end

    end

    --[[---------------------------------------------------------
    Gets which stage a tool is at
    -----------------------------------------------------------]]
    function ToolObj:GetStage()
      return self:GetWeapon():GetNWInt( "Stage", 0 )
    end

    --[[---------------------------------------------------------
    -----------------------------------------------------------]]
    function ToolObj:GetOperation()
      return self:GetWeapon():GetNWInt( "Op", 0 )
    end

    --[[---------------------------------------------------------
    -----------------------------------------------------------]]
    function ToolObj:SetOperation( i )
      self:GetWeapon():SetNWInt( "Op", i, true )

    end

    --[[---------------------------------------------------------
    ClearObjects - clear the selected objects
    -----------------------------------------------------------]]
    function ToolObj:ClearObjects()

      self:ReleaseGhostEntity()
      self.Objects = {}
      self:SetStage( 0 )
      self:SetOperation( 0 )

    end


    --[[---------------------------------------------------------
    Since we're going to be expanding this a lot I've tried
    to add accessors for all of this crap to make it harder
    for us to mess everything up.
    -----------------------------------------------------------]]
    function ToolObj:GetEnt( i )

      if (not self.Objects[i]) then return NULL end

      return self.Objects[i].Ent
    end


    --[[---------------------------------------------------------
    Returns the world position of the numbered object hit
    We store it as a local vector then convert it to world
    That way even if the object moves it's still valid
    -----------------------------------------------------------]]
    function ToolObj:GetPos( i )

      if (self.Objects[i].Ent:EntIndex() == 0) then
        return self.Objects[i].Pos
      else
        if (self.Objects[i].Phys ~= nil and self.Objects[i].Phys:IsValid()) then
          return self.Objects[i].Phys:LocalToWorld(self.Objects[i].Pos)
        else
          return self.Objects[i].Ent:LocalToWorld(self.Objects[i].Pos)
        end
      end

    end

    --[[---------------------------------------------------------
    Returns the local position of the numbered hit
    -----------------------------------------------------------]]
    function ToolObj:GetLocalPos( i )
      return self.Objects[i].Pos
    end


    --[[---------------------------------------------------------
    Returns the physics bone number of the hit (ragdolls)
    -----------------------------------------------------------]]
    function ToolObj:GetBone( i )
      return self.Objects[i].Bone
    end

    function ToolObj:GetNormal( i )
      if (self.Objects[i].Ent:EntIndex() == 0) then
        return self.Objects[i].Normal
      else
        local norm
        if (self.Objects[i].Phys ~= nil and self.Objects[i].Phys:IsValid()) then
          norm = self.Objects[i].Phys:LocalToWorld(self.Objects[i].Normal)
        else
          norm = self.Objects[i].Ent:LocalToWorld(self.Objects[i].Normal)
        end

        return norm - self:GetPos(i)
      end
    end


    --[[---------------------------------------------------------
    Returns the physics object for the numbered hit
    -----------------------------------------------------------]]
    function ToolObj:GetPhys( i )

      if (self.Objects[i].Phys == nil) then
        return self:GetEnt(i):GetPhysicsObject()
      end

      return self.Objects[i].Phys
    end


    --[[---------------------------------------------------------
    Sets a selected object
    -----------------------------------------------------------]]
    function ToolObj:SetObject( i, ent, pos, phys, bone, norm )

      self.Objects[i] = {}
      self.Objects[i].Ent = ent
      self.Objects[i].Phys = phys
      self.Objects[i].Bone = bone
      self.Objects[i].Normal = norm

      -- Worldspawn is a special case
      if (ent:EntIndex() == 0) then

        self.Objects[i].Phys = nil
        self.Objects[i].Pos = pos

      else

        norm = norm + pos

        -- Convert the position to a local position - so it's still valid when the object moves
        if (phys ~= nil and phys:IsValid()) then
          self.Objects[i].Normal = self.Objects[i].Phys:WorldToLocal(norm)
          self.Objects[i].Pos = self.Objects[i].Phys:WorldToLocal(pos)
        else
          self.Objects[i].Normal = self.Objects[i].Ent:WorldToLocal(norm)
          self.Objects[i].Pos = self.Objects[i].Ent:WorldToLocal(pos)
        end

      end

      if (SERVER) then
      -- Todo: Make sure the client got the same info
      end

    end


    --[[---------------------------------------------------------
    Returns the number of objects in the list
    -----------------------------------------------------------]]
    function ToolObj:NumObjects()

      if ( CLIENT ) then

        return self:GetStage()

      end

      return #self.Objects

    end


    --[[---------------------------------------------------------
    Returns the number of objects in the list
    -----------------------------------------------------------]]
    function ToolObj:GetHelpText()

      return "#tool."..gmod_toolmode:GetString().."."..self:GetStage()

    end




    function ToolObj:FreezeMovement()
      return false
    end

    function ToolObj:DrawHUD()
    end

    function ToolObj:Create()

      local o = {}

      setmetatable( o, self )
      self.__index = self

      o.Mode				= nil
      o.SWEP				= nil
      o.Owner				= nil
      o.ClientConVar		= {}
      o.ServerConVar		= {}
      o.Objects			= {}
      o.Stage				= 0
      o.Message			= "start"
      o.LastMessage		= 0
      o.AllowedCVar		= 0

      return o

    end

    function ToolObj:CreateConVars()

      local mode = self:GetMode()

      if ( CLIENT ) then

        for cvar, default in pairs( self.ClientConVar ) do

          CreateClientConVar( mode.."_"..cvar, default, true, true )

        end

        return end

      -- Note: I changed this from replicated because replicated convars don't work
      -- when they're created via Lua.

      if ( SERVER ) then

        self.AllowedCVar = CreateConVar( "toolmode_allow_"..mode, 1, FCVAR_NOTIFY )

      end

    end

    function ToolObj:GetServerInfo( property )

      local mode = self:GetMode()

      return GetConVarString( mode.."_"..property )

    end

    function ToolObj:GetClientInfo( property )

      local mode = self:GetMode()
      return self:GetOwner():GetInfo( mode.."_"..property )

    end

    function ToolObj:GetClientNumber( property, default )

      default = default or 0
      local mode = self:GetMode()
      return self:GetOwner():GetInfoNum( mode.."_"..property, default )

    end

    function ToolObj:Allowed()

      if ( CLIENT ) then return true end
      return self.AllowedCVar:GetBool()

    end

    -- Now for all the ToolObj redirects

    function ToolObj:Init()	end

    function ToolObj:GetMode() 			return self.Mode end
    function ToolObj:GetSWEP() 			return self.SWEP end
    function ToolObj:GetOwner() 			return self:GetSWEP().Owner or self.Owner end
    function ToolObj:GetWeapon() 			return self:GetSWEP().Weapon or self.Weapon end

    function ToolObj:LeftClick()			return false end
    function ToolObj:RightClick()			return false end
    function ToolObj:Reload()			self:ClearObjects() end
    function ToolObj:Deploy()			self:ReleaseGhostEntity() return end
    function ToolObj:Holster()			self:ReleaseGhostEntity() return end
    function ToolObj:Think()			self:ReleaseGhostEntity() end

    --[[---------------------------------------------------------
    Checks the objects before any action is taken
    This is to make sure that the entities haven't been removed
    -----------------------------------------------------------]]
    function ToolObj:CheckObjects()

      for k, v in pairs( self.Objects ) do

        if ( not v.Ent:IsWorld() and not v.Ent:IsValid() ) then
          self:ClearObjects()
        end

      end


    end


    if not SWEP.OriginalTool then SWEP.OriginalTool = table.Copy(SWEP.Tool) end
    local matScreen 	= Material( "models/weapons/v_toolgun/screen" )
    local txidScreen	= surface.GetTextureID( "models/weapons/v_toolgun/screen" )
    local txRotating	= surface.GetTextureID( "pp/fb" )

    local txBackground	= surface.GetTextureID( "models/weapons/v_toolgun/screen_bg" )


    -- GetRenderTarget returns the texture if it exists, or creates it if it doesn't
    local RTTexture 	= GetRenderTarget( "GModToolgunScreen", 256, 256 )

    surface.CreateFont( "GModToolScreen",
      {
        font		= "Helvetica",
        size		= 60,
        weight		= 900
      })

    local fmod = math.fmod
    local function DrawScrollingText( text, y, texwide )
      text = language.GetPhrase(text:sub(2)) -- So we can add more text if we want
      local w, h = surface.GetTextSize( text  )
      w = w + 64
      for x = fmod( CurTime() * 400, w ) * -1,texwide, w do
        surface.SetTextColor( 0, 0, 0, 255 )
        surface.SetTextPos( x + 3, y + 3 )
        surface.DrawText( text )

        surface.SetTextColor( 255, 255, 255, 255 )
        surface.SetTextPos( x, y )
        surface.DrawText( text )
      end
    end

    --[[---------------------------------------------------------
    We use this opportunity to draw to the toolmode
    screen's rendertarget texture.
    -----------------------------------------------------------]]
    local function RenderScreen(self)

      local TEX_SIZE = 256
      local mode 	= gmod_toolmode:GetString()
      local NewRT = RTTexture
      local oldW = ScrW()
      local oldH = ScrH()

      -- Set the material of the screen to our render target
      matScreen:SetTexture( "$basetexture", NewRT )

      local OldRT = render.GetRenderTarget();

      -- Set up our view for drawing to the texture
      render.SetRenderTarget( NewRT )
      render.SetViewPort( 0, 0, TEX_SIZE, TEX_SIZE )
      cam.Start2D()

      -- Background
      surface.SetDrawColor( 255, 255, 255, 255 )
      surface.SetTexture( txBackground )
      surface.DrawTexturedRect( 0, 0, TEX_SIZE, TEX_SIZE )

      -- Give our toolmode the opportunity to override the drawing
      if ( self:GetToolObject() and self:GetToolObject().DrawToolScreen ) then

        self:GetToolObject():DrawToolScreen( TEX_SIZE, TEX_SIZE )

      else

        surface.SetFont( "GModToolScreen" )
        DrawScrollingText( "#tool."..mode..".name", 64, TEX_SIZE )

      end

      cam.End2D()
      render.SetRenderTarget( OldRT )
      render.SetViewPort( 0, 0, oldW, oldH )

    end
    local SWEPs = ents.FindByClass('gmod_tool')
    local toolmodes = file.Find( "lua/modules/stools/*.lua", "MOD" )
    for key, val in pairs( toolmodes ) do
      local char1,char2,toolmode = string.find( val, "([%w_]*).lua" )
      TOOL = ToolObj:Create()
      TOOL.Mode = toolmode
      TOOL.Continuum = true
      function LoadTool(name)
        TOOL = SWEP.Tool[name]
      end
      function LoadOriginalTool(name)
        TOOL = SWEP.OriginalTool[name]
      end
      local Cancel = false
      function RequireTool(name)
        TOOL = SWEP.OriginalTool[name]
        if TOOL then
          TOOL._ToolMode=name
          Cancel = false
        else
          Cancel = true
        end
        return not Cancel
      end
      TOOL.AddToMenu=false
      CE.RevealGlobal()
      CE.include( "modules/stools/"..val )
      CE.HideGlobal()
      LoadTool = nil
      LoadOriginalTool = nil
      RequireTool = nil
      if not Cancel then
        toolmode = TOOL._ToolMode or toolmode
        TOOL.Command = "hacks_toolmode "..toolmode
        TOOL:CreateConVars()
        SWEP.Tool[ toolmode ] = TOOL
        SWEP.RenderScreen = RenderScreen
        for _,SWEP in pairs(SWEPs) do
          local tool = table.Copy(TOOL)
          tool.SWEP = SWEP
          SWEP.Tool = SWEP.Tool or { }
          if SWEP.Tool[toolmode] then
            SWEP.Tool[toolmode]:ReleaseGhostEntity()
          end
          SWEP.Tool[ toolmode ] = tool
          SWEP.RenderScreen = RenderScreen
        end
      end
      TOOL = nil
    end
    -- Keep the tool list handy
    local TOOLS_LIST = SWEP.Tool

    -- Add the STOOLS to the tool menu
    local function AddContinuumTools()
      for ToolName, TOOL in pairs( TOOLS_LIST ) do
        if ( TOOL.Continuum) then
          spawnmenu.AddToolMenuOption( TOOL.Tab or "AAAAAAA_Main",
            TOOL.Category or "New Category",
            ToolName,
            TOOL.Name or "#"..ToolName,
            TOOL.Command or "gmod_tool "..ToolName,
            TOOL.ConfigName or ToolName,
            TOOL.BuildCPanel )
        end
      end
    end
    local function AddHiddenTools()
      for ToolName, TOOL in pairs( TOOLS_LIST ) do
        if ( TOOL.AddToMenu == false and not TOOL.Continuum) then
          local Name = TOOL.Name or ToolName
          Name = language.GetPhrase(Name:sub(1)) or Name
          spawnmenu.AddToolMenuOption( TOOL.Tab or "Hidden Tools",
            TOOL.Category or "New Category",
            ToolName,
            Name,
            TOOL.Command or "gmod_tool "..ToolName,
            (TOOL.ConfigName or ToolName),
            TOOL.BuildCPanel )
        end
      end
    end
    CE.Hook.Add("PopulateToolMenu", "ContinuumTools", AddContinuumTools)
    CE.Hook.Add("PopulateToolMenu", "HiddenTools", AddHiddenTools)
    local function CreateSpawnMenu()

      -- If we have an old spawn menu remove it.
      if ( g_SpawnMenu ) then

        g_SpawnMenu:Remove()
        g_SpawnMenu = nil

      end

      -- Start Fresh
      spawnmenu.ClearToolMenus()

      -- Add defaults for the gamemode. In sandbox these defaults
      -- are the Main/Postprocessing/Options tabs.
      -- They're added first in sandbox so they're always first
      hook.Run( "AddGamemodeToolMenuTabs" )

      -- Use this hook to add your custom tools
      -- This ensures that the default tabs are always
      -- first.
      hook.Run( "AddToolMenuTabs" )

      -- Use this hook to add your custom tools
      -- We add the gamemode tool menu categories first
      -- to ensure they're always at the top.
      hook.Run( "AddGamemodeToolMenuCategories" )
      hook.Run( "AddToolMenuCategories" )

      -- Add the tabs to the tool menu before trying
      -- to populate them with tools.
      hook.Run( "PopulateToolMenu" )
      g_SpawnMenu = vgui.Create( "SpawnMenu" )
      g_SpawnMenu:SetVisible( false )

      CreateContextMenu()

      hook.Run( "PostReloadToolsMenu" )

    end
    CreateSpawnMenu()
    menubar.Control:Remove()
    menubar.Init()

    local function CreateAutocomplete(commandName,args)
      local current = string.join("", args):sub(2)
      local options = { }
      for Name,Data in pairs(SWEP.Tool) do
        table.insert(options, #options+1, Name)
      end
      local validOptions = { }
      for key,val in pairs(options) do
        if(val:starts(current)) then
          table.insert(validOptions, commandName.." "..val)
        end
      end
      table.sort(validOptions, function(a, b) return a < b end)
      return validOptions
    end
    local function SetToolmode(ply, name, args)
      RunConsoleCommand("gmod_toolmode", args[1]) -- set our toolmode
      RunConsoleCommand( "use", "gmod_tool" ) -- switch to the toolgun
    end
    concommand.Add("hacks_toolmode", SetToolmode, CreateAutocomplete)


    spawnmenu.AddContentType( "model", function( container, obj )

        local icon = vgui.Create( "SpawnIcon", container )

        if ( obj.body ) then
          obj.body = string.Trim( tostring(obj.body), "B" )
        end

        if ( obj.wide ) then
          icon:SetWide( obj.wide )
        end

        if ( obj.tall ) then
          icon:SetTall( obj.tall )
        end

        icon:InvalidateLayout( true )

        icon:SetModel( obj.model, obj.skin or 0, obj.body )

        icon:SetTooltip( string.Replace( string.GetFileFromFilename(obj.model), ".mdl", "" ) )

        icon.DoClick = function( icon ) surface.PlaySound( "ui/buttonclickrelease.wav") RunConsoleCommand( "gm_spawn", icon:GetModelName(), icon:GetSkinID() or 0, icon:GetBodyGroup() or "" ) end
        icon.OpenMenu = function( icon )
          local ent = ents.CreateClientProp(obj.model)
          local options,skinCount
          if IsValid(ent) then
            options = ent:GetBodyGroups();
            skinCount = ent:SkinCount()
          end
          ent:Remove()
          local menu = DermaMenu()
          menu:AddOption( "Copy to Clipboard", function() SetClipboardText( obj.model ) end )
          menu:AddOption( "Set as button model", function() RunConsoleCommand("button_model", icon:GetModelName()) end )

          menu:AddSpacer()
          if skinCount and skinCount > 0 then
            local submenu = menu:AddSubMenu( "Set Skin" )
            for i=0, skinCount-1 do
              local option = submenu:AddOption( "Skin " .. i, function() icon:SkinChanged( i ); icon:InvalidateLayout( true ) end )
              if ( icon:GetSkinID() == i ) then
                option:SetChecked( true )
              end
            end
          end
          if options and #options >= 2 then
            local submenu = menu:AddSubMenu( "Set Bodygroups" )
            for k, v in pairs( options ) do
              if ( v.num == 2 ) then
                local current = tonumber(icon.m_strBodyGroups:GetChar(v.id+1))
                local opposite = 1
                if ( current == opposite ) then opposite = 0 end
                local option = submenu:AddOption( v.name, function() icon:BodyGroupChanged( v.id, opposite ) end )
                if ( current == 1 ) then
                  option:SetChecked( true )
                end
              elseif v.num > 2 then
                local groups = submenu:AddSubMenu( v.name )
                for i=1, v.num do
                  local modelname = "model #" .. i
                  if ( v.submodels and v.submodels[ i-1 ] ~= "" ) then modelname = v.submodels[ i-1 ] end
                  local option = groups:AddOption( modelname, function() icon:BodyGroupChanged( v.id, i-1 ) end )
                  if ( tonumber(icon.m_strBodyGroups:GetChar(v.id+1)) == i-1 ) then
                    option:SetChecked( true )
                  end
                end
              end
            end
          end
          menu:AddSpacer()
          menu:AddOption( "Delete", function() icon:Remove(); hook.Run( "SpawnlistContentChanged" ) end )
          menu:Open()
        end

        icon:InvalidateLayout( true )

        if ( IsValid( container ) ) then
          container:Add( icon )
        end
        return icon

    end )
  end
end