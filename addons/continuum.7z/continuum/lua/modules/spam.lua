MODULE.ID = "com.continuum.spam"
MODULE.Dependencies = { }

MODULE.name = "Spam"
MODULE.info = "Tool for sending spam messages and spamming props"
MODULE.cvars = { {nick="Prop Spam", name="hacks_propspam", default="0"}, {nick="Prop Spam Model", name="hacks_propspam_model", info="Model to use for prop spam", default="models/props_building_details/Storefront_Template001a_Bars.mdl", NoToggle=true} }

MODULE.Init = function(CE)
  RunConsoleCommand("hacks_propspam_model", "models/props_building_details/Storefront_Template001a_Bars.mdl")
  local spamMessage = nil
  MODULE.AddCmd({ name="hacks_spam",nick="Spam", info = "Spams messages to the server", func = function(ply,name,arguments, args)
    if #arguments == 0 then
      RunConsoleCommand("hacks_help", "spam")
      return
    end
    spamMessage = args
  end, autocomplete = function(commandName,args)
    local argSet = { }
    return { "hacks_spam message" }
  end})
  MODULE.AddCmd({ name="hacks_spamclear",NoArgs=true, nick="Spam Clear",info="Clears out the buffer of spam messages to be sent", func = function(ply,name,args)
    spamMessage = nil
    chat.AddText(CE.Colors.RED, "Stopped spam")
  end})
  timer.Create("CE.ChatSpam", .75, 0, function()
    if spamMessage then
      LocalPlayer():ConCommand(spamMessage)
    end
  end)
  timer.Create("CE.PropSpam", .6, 0, function()
    if CE.GetConVarBool("hacks_propspam") then
      RunConsoleCommand("gm_spawn", GetConVarString("hacks_propspam_model"))
    end
  end)
end