MODULE.ID = "com.continuum.aimbotv2"
MODULE.Dependencies = { "com.continuum.aimbot", "com.continuum.buddies" }

MODULE.Name = "Aimbot v2"
MODULE.Info = "Aka aimrape, aimbotv2 targets everything in sight"
MODULE.cvars = { {Nick="Aimbot v2", Name="hacks_aimbotv2", Default="0", HUD={
    Category = "Weaponry", Type="ToggleButton"
  }} }

MODULE.Init = function(CE)


  CE.AimbotV2Target = nil
  local function findPlayerOnScreen()
    if CE.AimbotV2Target then
      if(CE.AimbotV2Target.target and (CE.AimbotV2Target.target.Alive == nil or not IsValid(CE.AimbotV2Target.target) or not CE.AimbotV2Target.target:Alive())) then
        CE.AimbotV2Target = nil
        CE.PlayBeep()
        return nil
      end
      local trace = util.TraceLine({start=LocalPlayer():GetShootPos(), endpos = CE.AimbotV2Target.target:GetPos()})
      if trace.HitNonWorld and trace.Entity == CE.AimbotV2Target.target then
        return CE.AimbotV2Target
      end
    end
    local topDamageInfo = CE.LoadTraceData( nil, nil, nil )
    local players = player.GetAll()
    table.sort(players, function(x,y)return not y:IsSpawnProtected() and CE.DistanceTo(x:GetPos()) < CE.DistanceTo(y:GetPos())end)
    for k,v in pairs(players) do
      if IsValid(v) and v ~= LocalPlayer() and v:Alive() and ((not v:IsTraitorBuddy() and not v:IsFriend()) or CE.IsRoundOver()) then
        local bones = { CE.GetPriorityBone() or CE.Constants.BONE_HEAD, CE.Constants.BONE_HEAD ,CE.Constants.BONE_TORSO, CE.Constants.BONE_GEAR,CE.Constants.BONE_SPINE,CE.Constants.BONE_LEFT_HAND,CE.Constants.BONE_RIGHT_HAND,CE.Constants.BONE_LEFT_FOOT, CE.Constants.BONE_RIGHT_FOOT, -13 }
        for _,bone in pairs(bones) do
          local target
          if bone == -13 then
            target = v:GetShootPos()
          elseif bone == CE.Constants.BONE_HEAD and v:IsHeadVisible() then
            local targethead = v:LookupBone("ValveBiped.Bip01_Head1") or CE.Constants.BONE_HEAD
            local targetheadpos,targetheadang = v:GetBonePosition(targethead)
            --targetheadpos = targetheadpos + Vector(0,0,0)
            target=targetheadpos
          else
            target = v:GetBonePosition(bone)
          end
          local traceRes = util.TraceLine({start=LocalPlayer():GetShootPos(), endpos=target, mask=MASK_SHOT})
          local boneTraceData = CE.LoadTraceData(traceRes, nil, nil)--LoadTraceData(nil, v, bone)
          if bone == CE.Constants.BONE_HEAD and v:IsHeadVisible() then
            return boneTraceData
          elseif bone ~= CE.Constants.BONE_HEAD and boneTraceData.traceRes ~= nil and boneTraceData.target == v then
            --[[if(boneTraceData.dist < topDamageInfo.dist) then
              topDamageInfo = boneTraceData
              break
            end]]
            return boneTraceData
          end
        end
      end
    end
    return nil
    --return topDamageInfo.target and topDamageInfo or nil
  end
  CE.Hook.Remove("PostDrawTranslucentRenderables", "DrawAimrape")
  CE.Hook.Add("HUDPaint", "DrawAimrape", function()
    local data = CE.AimbotV2Target
    if not data then return end
    local v = data.target
    if not IsValid(v) then return end
    local bones = { CE.GetPriorityBone() or CE.Constants.BONE_HEAD, CE.Constants.BONE_HEAD ,CE.Constants.BONE_TORSO, CE.Constants.BONE_GEAR,CE.Constants.BONE_SPINE,CE.Constants.BONE_LEFT_HAND,CE.Constants.BONE_RIGHT_HAND,CE.Constants.BONE_LEFT_FOOT, CE.Constants.BONE_RIGHT_FOOT, -13 }
    local damageInfos = { }
    local topDamageInfo = nil
    local IsTopFound = false
    for _,bone in pairs(bones) do
      local target
      if bone == -13 then
        target = v.GetShootPos and v:GetShootPos() or v:GetPos() + Vector(0,0,30)
      elseif bone == CE.Constants.BONE_HEAD and v.IsHeadVisible and v:IsHeadVisible() then
        local targethead = v:LookupBone("ValveBiped.Bip01_Head1") or CE.Constants.BONE_HEAD
        local targetheadpos,targetheadang = v:GetBonePosition(targethead)
        targetheadpos = targetheadpos + Vector(0,0,0)
        target=targetheadpos
      else
        target = v:GetBonePosition(bone)
      end
      if target then
        local traceRes = util.TraceLine({start=LocalPlayer():GetShootPos(), endpos=target, mask=MASK_SHOT})
        local boneTraceData = CE.LoadTraceData(traceRes, nil, nil)--LoadTraceData(nil, v, bone)
        boneTraceData.endpos = target
        if bone == CE.Constants.BONE_HEAD and v.IsHeadVisible and v:IsHeadVisible() then
          if not topDamageInfo then
            topDamageInfo = boneTraceData
          else
            boneTraceData.Plausible = true
            table.insert(damageInfos, boneTraceData)
          end
        elseif bone ~= CE.Constants.BONE_HEAD and boneTraceData.traceRes ~= nil and boneTraceData.target == v then
          if not topDamageInfo then
            topDamageInfo = boneTraceData
          else
            boneTraceData.Plausible = true
            table.insert(damageInfos, boneTraceData)
          end
        else
          table.insert(damageInfos, boneTraceData)
        end
      end
    end
    local dist = v.Distance and v:Distance(LocalPlayer():GetPos()) or 100000
    local width, height = 10, 10
    width = math.min(width*500/dist, 5)
    height = math.min(height*500/dist, 5)
    for _,damageInfo in pairs(damageInfos) do
      local color = damageInfo.Plausible and Color(255,215,0) or Color(255,0,0)
      local pt = damageInfo.endpos:ToScreen()
      surface.SetDrawColor(Color(0,0,0))
      surface.DrawRect(pt.x-width/2, pt.y-height/2, width, height)
      surface.SetDrawColor(color)
      surface.DrawRect(pt.x-width/2+1, pt.y-height/2+1, width-2, height-2)
      
      --surface.DrawCircle(pt.x, pt.y, 3, damageInfo.Plausible and Color(255,215,0) or Color(255,0,0))
      --surface.DrawCircle(pt.x, pt.y, 2, damageInfo.Plausible and Color(255,215,0) or Color(255,0,0))
      --surface.DrawCircle(pt.x, pt.y, 1, damageInfo.Plausible and Color(255,215,0) or Color(255,0,0))
      
      --render.SetMaterial(nil)
      --render.DrawSphere(damageInfo.endpos, 5, 50, 50, color)
    end
    if topDamageInfo and topDamageInfo.endpos then
      local damageInfo = topDamageInfo
      local color = Color(0,255,0)
      local pt = damageInfo.endpos:ToScreen()
      surface.SetDrawColor(Color(0,0,0))
      surface.DrawRect(pt.x-width/2, pt.y-height/2, width, height)
      surface.SetDrawColor(color)
      surface.DrawRect(pt.x-width/2+1, pt.y-height/2+1, width-2, height-2)
    end
  end)
  CE.findPlayerOnScreen = findPlayerOnScreen
  local CreateMoveCMD
  local function aimbotv2()
    local weapon = LocalPlayer():GetActiveWeapon()
    if(not IsValid(weapon) or weapon:GetPrintName() == "Holstered") then
      CE.AimbotV2Target = nil
      return
    end
    CE.AimbotV2Target = findPlayerOnScreen()
    if(CE.AimbotV2Target == nil) then
      return
    end
    local target = CE.AimbotV2Target.target
    if(IsValid(target)) then
      local targetpos = CE.AimbotV2Target.traceRes.HitPos
      if(targetpos == nil) then
        return
      end
      local CurrentAngles = LocalPlayer():EyeAngles()
      local NewAngles = (LocalPlayer():GetShootPos() + CE.CalculateLag(LocalPlayer())):AngleTo(targetpos + CE.CalculateLag(CE.AimbotV2Target.target))
      --local BetweenAngles = LerpAngle(.5, CurrentAngles, NewAngles) -- use this if u want to make it move slowly
      CreateMoveCMD:SetViewAngles(CE.ClampAngle(NewAngles-LocalPlayer():GetPunchAngle()))
    end
  end
  
  local function tryAimbotv2(cmd)
    if not CE.GetConVarBool("hacks_aimbotv2") then
      return
    end
    --CreateMoveCMD = cmd
    CreateMoveCMD = { SetViewAngles = function(cmd, angles) CE.SetEyeAngles(angles) end}
    local success, callback = xpcall(aimbotv2, CE.ErrorHandler)
    if(not success) then
      RunConsoleCommand("hacks_aimbotv2", -1);
    end
  end
  CE.Hook.Add("Think", "CE.Aimbotv2", tryAimbotv2)
end