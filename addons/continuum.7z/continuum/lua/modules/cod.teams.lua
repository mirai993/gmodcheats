local CE = CE
MODULE.Name="COD Teams"
MODULE.ID="com.continuum.cod.teams"
MODULE.Dependencies = { }
TEAM_AXIS = 2
TEAM_ALLIES = 3
team.SetUp(TEAM_AXIS, "Axis", CE.Colors.RED, false)
team.SetUp(TEAM_ALLIES, "Allies", CE.Colors.BLUE, false)