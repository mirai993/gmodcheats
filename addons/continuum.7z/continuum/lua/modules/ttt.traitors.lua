MODULE.ID = "com.continuum.ttt.traitors"
MODULE.Dependencies = { "com.continuum.notify" }

MODULE.Name = "Traitor Flagger"
MODULE.Info = "Flags traitors by looking at when a traitor weapon spawns, and flagging whoever carries it as a traitor. Also tracks who has what weapons, but this is not used"

MODULE.Init = function(CE)
  local Colors = CE.Colors
  local DidResetFlags = false;
  CE.Hook.Add("Think", "CE.TraitorWeaponFlagger", function()
    for _,v in pairs(player.GetAll()) do
      v._tmpweapons = { }
    end
    if GAMEMODE.round_state ~= ROUND_ACTIVE then
      if not DidResetFlags then
        for _,v in pairs(player.GetAll()) do
          v.HatTraitor = nil
          v._weapons = { }
          v._tmpweapons = { }
          v.DisguiseActive = false
        end
        for _,v in pairs(ents.GetAll()) do
          v.HatESPTracked = true
        end
      end
      DidResetFlags = true
      return
    end
    DidResetFlags = false
    for _,v in pairs(ents.GetAll() ) do
      local pl = v:GetOwner()
      if not pl:IsPlayer() then pl = nil end
      --[[if v and IsValid(v) then
      if pl and IsValid(pl) and pl.IsTerror ~= nil and pl:IsTerror() then
      if(v.Slot ~= nil) then
      pl._tmpweapons[v.Slot] = v
      end
      end
      end]]
      if not v.HatESPTracked then
        local invalidPly = (pl == nil or not IsValid(pl) or pl.IsTerror == nil or not pl:IsTerror())
        if v:GetClass() == "ttt_c4" then
          v.HatESPTracked = true
          pl.HatTraitor = true
          CE.Notify.All(pl:GetRoleColor(), pl:Nick(), Colors.WHITE," placed a ",Colors.TRAITOR, "C4",Colors.WHITE,"!")
        end
        if v:GetClass() == "ttt_decoy" then
          v.HatESPTracked = true
          pl.HatTraitor = true
          CE.Notify.All(pl:GetRoleColor(), pl:Nick(), Colors.WHITE," placed a ",Colors.TRAITOR, "Decoy",Colors.WHITE,"!")
        end
        if not invalidPly and v and IsValid(v) and CE.IsTraitorous(v,pl) then
          local wname = LANG.TryTranslation(v.PrintName)
          if pl:IsDetective() then
            --if they're a detective, they just happened to buy it from the store
            v.HatESPTracked = true
            CE.Notify.All(pl:GetRoleColor(), pl:Nick(), Colors.WHITE," bought a ",Colors.DETECTIVE, wname,Colors.WHITE,"!")
          else
            v.HatESPTracked = true
            pl.HatTraitor = true
            CE.Notify.All(pl:GetRoleColor(), pl:Nick(), Colors.WHITE," bought a ",Colors.TRAITOR, wname,Colors.WHITE,"!")
          end
        end
      end
    end
    for _,v in pairs(player.GetAll()) do
      v._weapons = v._tmpweapons
      if v:GetNWBool("disguised", false) then
        v.HatTraitor = true
        if not v.DisguiseActive then
          CE.Notify.All(v:GetRoleColor(), v:Nick(), Colors.WHITE," turned on their ",Colors.TRAITOR, "disguiser",Colors.WHITE,"!")
        end
        v.DisguiseActive = true
      else
        if v.DisguiseActive then
          CE.Notify.All(v:GetRoleColor(), v:Nick(), Colors.WHITE," turned off their ",Colors.TRAITOR, "disguiser",Colors.WHITE,"!")
        end
        v.DisguiseActive = false
      end
    end
  end)
end