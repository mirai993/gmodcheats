MODULE.ID = "com.continuum.patrol"
MODULE.Dependencies = { }

MODULE.Name="Patrol"
MODULE.Info="Patrols around"
MODULE.cvar = { Nick="Patrol", Name="hacks_patrol", HUD={ Category="Misc", Type="ToggleButton"}}
MODULE.Init = function(CE)
  local moving = { forward=nil, reverse=nil, left=nil, right=nil}
  CE.Hook.Add("Think", "CE.PatrolThinker", function()
    if CE.GetConVarBool("hacks_patrol") then
      local ET = LocalPlayer():GetEyeTrace()
      local dist = ET.StartPos:Distance(ET.HitPos)
      if dist > 100 and not moving.forward then
        RunConsoleCommand( "+forward" )
        moving.forward = 1
        if moving.reverse then RunConsoleCommand("-forward"); moving.forward=nil end
        if moving.left then RunConsoleCommand("-left"); moving.left=nil end
        if moving.right then RunConsoleCommand("-right"); moving.right=nil end
      elseif dist <= 100 and not moving.left then
        RunConsoleCommand("+left")
        moving.left = 1
        if moving.forward then RunConsoleCommand("-forward"); moving.forward=nil end
        if moving.reverse then RunConsoleCommand("-forward"); moving.reverse=nil end
        if moving.right then RunConsoleCommand("-right"); moving.right=nil end
      end
    else
      if moving.forward then RunConsoleCommand("-forward"); moving.forward=nil end
      if moving.reverse then RunConsoleCommand("-forward"); moving.reverse=nil end
      if moving.left then RunConsoleCommand("-left"); moving.left=nil end
      if moving.right then RunConsoleCommand("-right"); moving.right=nil end
    end
  end)
end