MODULE.ID = "com.continuum.ttt.radio"
MODULE.Dependencies = { }

MODULE.Name = "Radio Hacks"
MODULE.Info = "Makes radio on disguised players still work"
MODULE.cvars = { { name="hacks_radio_showunid",nick="Radio Unidentifieds", info="Makes unidentified bodies be radio'd as if they were alive when you're a traitor", default=1, HUD={ Category="Misc", Type="ToggleButton"}} }

MODULE.Init = function(CE)
  function RADIO:GetTargetType()
  	if not IsValid(LocalPlayer()) then return end
  	local trace = LocalPlayer():GetEyeTrace(MASK_SHOT)
  
  	if not trace or (not trace.Hit) or (not IsValid(trace.Entity)) then return end
  
  	local ent = trace.Entity
  
  	if ent:IsPlayer() then
  		if ent:GetNWBool("disguised", false) then
  			return ent, false
  		else
  			return ent, false
  		end
  	elseif ent:GetClass() == "prop_ragdoll" and CORPSE.GetPlayerNick(ent, "") ~= "" then
  		if DetectiveMode() and not CORPSE.GetFound(ent, false) then
  			local ply = player.GetByName(CORPSE.GetPlayerNick(ent, ""))
  			if CE.GetConVarBool("hacks_radio_showunid") and ply ~= nil and LocalPlayer():GetRole() == ROLE_TRAITOR then
  				return ply,false
  			end
  			return "quick_corpse", true
  		else
  			return ent, false
  		end
  	end
  end
end
--[[local stored_id
local _last_chat = ""
local last_words = nil
function GAMEMODE:ChatTextChanged(text)
	_last_chat = text
end
local function ChatInterrupt(um)
	local client = LocalPlayer()
	stored_id = um:ReadLong()
	print("Caught ID, "..tostring(stored_id))

	last_words = ""
	if _last_chat == "" then
		if RADIO.LastRadio.t > CurTime() - 2 then
			last_words = RADIO.LastRadio.msg
		end
	else
		last_words = _last_chat
	end
	last_words = nil
	if lastLookingAt and (CurTime() - lastLookingTime < 5) then
		last_words = lastLookingAt:Nick().." is a Traitor!"
	end
	local FunLastWords = {
		"Oh fuck. I'm dead. LOL. Well. This is awkward because you're alive.x",
		"Well... I'm dead xD\n\n\n",
		"Sometimes I just like to say SPLUT. It's a fun word. ",
	}
	if LocalPlayer():IsTraitor() then
		table.insert(FunLastWords, 1, "Damn. On my t round, lol.")
	elseif LocalPlayer():IsDetective() then
		table.insert(FunLastWords, 1, "Have fun with no detective!")
	else
		table.insert(FunLastWords, 1, "At least I was innocent!")
	end
	if last_words == nil then last_words = table.Random(FunLastWords) end
	if _last_chat == "" then
		if RADIO.LastRadio.t > CurTime() - 2 then
			last_words = RADIO.LastRadio.msg
		end
	else
		last_words = _last_chat
	end
	-- RunConsoleCommand("_deathrec", tostring(stored_id), tostring(table.Random(player.GetAll())), last_words)
end]]
--usermessage.Hook("interrupt_chat", ChatInterrupt)