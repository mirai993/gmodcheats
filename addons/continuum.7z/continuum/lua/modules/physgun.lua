MODULE.ID = "com.continuum.physgun"
MODULE.Dependencies = { }

MODULE.Name = "Physgun"
MODULE.Info = "Stores some information about physgun and calls CE hooks"

MODULE.Init = function(CE)
  local PhysgunEnt = nil
  local GM = GAMEMODE
  local function PhysgunPickup( ply, ent )
    if not PhysgunEnt then
      CE.Hook.Call("PhysgunGrabbed", nil, ent)
      if ent.Frozen then
        local effectdata = EffectData()
        effectdata:SetOrigin( ent:GetPos() )
        effectdata:SetEntity( ent )
        util.Effect( "phys_unfreeze", effectdata, true, true )
      end
    end
    PhysgunEnt = ent
  end
  local function PhysgunDrop( ply, ent )
    if PhysgunEnt then
      CE.Hook.Call("PhysgunDropped", nil, ent)
    end
    PhysgunEnt = nil
  end
  local function OnPhysgunFreeze( weapon, phys, ent, ply )
    chat.AddText("Froze: "..ent:GetClass())
  end
  CE.Hook.Add("PhysgunPickup", "CE.PhysgunGrabbed", PhysgunPickup)
  CE.Hook.Add("PhysgunDrop", "CE.PhysgunDropped", PhysgunDrop)
  CE.Hook.Add("OnPhysgunFreeze", "CE.PhysgunFreeze", OnPhysgunFreeze)
  function CE.GetPhysgunEntity()
    return PhysgunEnt
  end

  local physgun_halo = CreateConVar( "physgun_halo", "1", { FCVAR_ARCHIVE }, "Draw the physics gun halo?" )
  local PhysgunHalos = {}

  --[[---------------------------------------------------------
  Name: gamemode:DrawPhysgunBeam()
  Desc: Return false to override completely
  -----------------------------------------------------------]]
  function GM:DrawPhysgunBeam( ply, weapon, bOn, target, boneid, pos )

    if ( physgun_halo:GetInt() == 0 ) then return true end

    if ( IsValid( target ) ) then
      PhysgunHalos[ ply ] = target
    end

    return true

  end

  hook.Add( "PreDrawHalos", "AddPhysgunHalos", function()

      if ( not PhysgunHalos or table.Count( PhysgunHalos ) == 0 ) then return end
      for k, v in pairs( PhysgunHalos ) do
        if ( IsValid(k) ) then
          local size = math.random( 1, 2 )
          local colr = k:GetWeaponColor() + VectorRand() * 0.3

          effects.halo.Add( PhysgunHalos, Color( colr.x * 255, colr.y * 255, colr.z * 255 ), size, size, 1, true, false )
        end
      end
      PhysgunHalos = {}
  end )
end