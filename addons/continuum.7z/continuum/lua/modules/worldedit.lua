MODULE.ID = "com.continuum.worldedit"
MODULE.Dependencies = { }

MODULE.Name = "WorldEdit"
MODULE.Info = "Tool for copying and pasting entities"

MODULE.Init = function(CE)
  local Colors = CE.Colors
  local worldeditCmd = { Name="hacks_worldedit",Nick="WorldEdit", Info=MODULE.Info }
  local render = render
  local draw = draw
  local surface = surface
  local function getTarget()
    local trace = util.GetPlayerTrace( LocalPlayer() )
    local tr = util.TraceLine( trace )
    if tr.Entity then return tr.Entity end
    trace.mask = MASK_SHOT
    local tr = util.TraceLine( trace )
    return tr.Entity
  end
  local function select()
    if IsValid(CE.Session.WorldEdit) then
      CE.Session.WorldEdit.selectionSet = nil
    end
    CE.Session.WorldEdit = getTarget()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection found at crosshairs")
      return
    end
    CE.Session.WorldEdit.selectionSet = true
    chat.AddText(Colors.ORANGE, "Selected ", Colors.GREEN, CE.Session.WorldEdit:GetClass(), Colors.ORANGE, " with model ", Colors.GREEN, CE.Session.WorldEdit:GetModel())
  end
  local function unselect()
    CE.Session.WorldEdit = nil
    chat.AddText(Colors.RED, "Unselected selection")
  end
  local function deleteClient()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection is currently set. Use hacks_worldedit select")
      return
    end
    CE.Session.WorldEdit:Remove()
    chat.AddText(Colors.RED, "Deleted selection clientside")
  end
  local function deleteServer()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection is currently set. Use hacks_worldedit select")
      return
    end
    local index = CE.Session.WorldEdit:EntIndex()
    LocalPlayer():ConCommand("ulx luarun Entity("..tostring(index).."):Remove()")
    chat.AddText(Colors.RED, "Deleted selection serverside")
  end
  local TargetModel
  local TargetPos
  local TargetIgnores
  local TargetWorldedit
  local function pasteSpawn()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection is currently set. Use hacks_worldedit select")
      return
    end
    local model = CE.Session.WorldEdit:GetModel()
    local bodygroups = ""
    for id=0,8 do
      bodygroups = bodygroups .. tostring(CE.Session.WorldEdit:GetBodygroup(id))
    end
    local skin = CE.Session.WorldEdit:GetSkin()
    --
    RunConsoleCommand("gm_spawn", model, skin, bodygroups, true) -- bc we're fucking pimps and copy not only the model,
    -- but also the skin and bodygroups.
    chat.AddText(Colors.RED, "Created prop with gm_spawn")
    print("gm_spawn "..model)
  end
  function CE.FindSpawnedProp(model, worldedit)
    local vStart = LocalPlayer():GetShootPos()
    local vForward = LocalPlayer():GetAimVector()

    local trace = {}
    trace.start = vStart
    trace.endpos = vStart + (vForward * 2048)
    trace.filter = LocalPlayer()

    local tr = util.TraceLine( trace )

    local ent = ents.CreateClientProp( model )
    local ang = LocalPlayer():EyeAngles()
    ang.yaw = ang.yaw + 180 -- Rotate it 180 degrees in my favour
    ang.roll = 0
    ang.pitch = 0

    ent:SetModel( model )
    ent:SetAngles( ang )
    ent:SetPos( tr.HitPos )
    ent:Spawn()
    ent:Activate()

    -- Attempt to move the object so it sits flush
    -- We could do a TraceEntity instead of doing all
    -- of this - but it feels off after the old way

    -- However, first we gotta put all the server props in around it
    local ClientProps = { }
    ClientProps[ent] = true
    local nearbyEnts = ents.FindInSphere(ent:GetPos(), 550)
    for _,sv_ent in pairs(nearbyEnts) do
      if IsValid(sv_ent) then
        local sv_model = sv_ent:GetModel()
        local sv_pos = sv_ent:GetPos()
        local sv_angles = sv_ent:GetAngles()
        local sv_movetype = sv_ent:GetMoveType()
        local sv_solid = sv_ent:GetSolid()
        local sv_phys = sv_ent:GetPhysicsObject()
        local sv_motion = IsValid(sv_phys) and sv_phys:IsMotionEnabled()
        local sv_gravity = IsValid(sv_phys) and sv_phys:IsGravityEnabled()
        local sv_collisions = IsValid(sv_phys) and sv_phys:IsCollisionEnabled()

        local cl_ent = ents.CreateClientProp(sv_model)
        cl_ent:SetModel( sv_model )
        cl_ent:SetPos( sv_pos )
        cl_ent:SetAngles( sv_angles)
        cl_ent:Spawn()
        cl_ent:PhysicsInit( sv_solid )
        cl_ent:SetMoveType( sv_movetype )
        cl_ent:SetSolid( sv_solid )
        cl_ent:SetRenderMode( RENDERMODE_TRANSALPHA )
        cl_ent:SetColor( Color( 255, 255, 255, 0 ) )
        ClientProps[cl_ent] = true
      end
    end
    local vFlushPoint = tr.HitPos - ( tr.HitNormal * 512 )	-- Find a point that is definitely out of the object in the direction of the floor
    vFlushPoint = ent:NearestPoint( vFlushPoint )			-- Find the nearest point inside the object to that point
    vFlushPoint = ent:GetPos() - vFlushPoint				-- Get the difference
    vFlushPoint = tr.HitPos + vFlushPoint

    for k,v in pairs(ClientProps) do
      k:Remove()
    end
    TargetIgnores = ents.GetAll()
    TargetPos=vFlushPoint
    TargetWorldedit=worldedit
    TargetModel=model
  end
  CE.Hook.Add("Think", "FindSpawnedProp", function()
    if not TargetModel then return end
    for _,prop in pairs(ents.FindInSphere(TargetPos, 75)) do
      if prop:GetModel():lower() == TargetModel:lower() and not table.containsValue(TargetIgnores, prop) then
        if TargetWorldedit then
          CE.Hook.Call("WorldeditPropSpawned", nil, prop)
        else
          CE.Hook.Call("PropSpawned", nil, prop)
        end
        TargetModel=nil
        break;
      end
    end
  end)
  CE.Hook.Add("PropSpawned", "GravitySpawn", function(prop)
    if CE.GetConVarBool("hacks_gravityspawn") then -- Yes, I know this convar doesn't exist
      net.Start( "properties" )
      net.WriteUInt( util.NetworkStringToID( "gravity" ), 32 )
      net.WriteEntity( prop )
      net.SendToServer()
    end
  end)
  local function pasteClient()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No clipboard is currently set. Use hacks_worldedit copy")
      return
    end
    local newEnt=ents.CreateClientProp(CE.Session.WorldEdit:GetClass())--prop_physics
    newEnt:SetModel(CE.Session.WorldEdit:GetModel())--
    newEnt:PhysicsInit( SOLID_VPHYSICS )      -- Make us work with physics,
    newEnt:SetMoveType( MOVETYPE_VPHYSICS )   -- after all, gmod is a physics
    newEnt:SetSolid( SOLID_VPHYSICS )         -- Toolbox
    local phys = newEnt:GetPhysicsObject()
    if (phys:IsValid()) then
      phys:Wake()
    end
    if not newEnt or not newEnt:IsValid() then
      chat.AddText(Colors.ORANGE, "Unknown entity type (", Colors.RED, CE.Session.WorldEdit:GetClass(), Colors.ORANGE, "), aborting." )
      return
    end

    local trace = LocalPlayer():GetEyeTrace()
    local vector = trace.HitPos
    vector.z = vector.z + 20

    newEnt:SetPos( vector )
    newEnt:Spawn()
    newEnt:Activate()
    chat.AddText(Colors.RED, "Pasted selection clientside")
  end
  local function pasteServer()
    if not IsValid(CE.Session.WorldEdit) then CE.Session.WorldEdit = nil end
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection is currently set. Use hacks_worldedit select")
      return
    end
    LocalPlayer():ConCommand("ulx ent "..CE.Session.WorldEdit:GetClass().." {model:"..CE.Session.WorldEdit:GetModel().."}")
    --RunConsoleCommand("ulx", "ent", clipboard:GetClass(), "{model:"..clipboard:GetModel().."}")
    chat.AddText(Colors.RED, "Pasted selection serverside")
  end
  local function deleteSandbox()
    if CE.Session.WorldEdit == nil then
      chat.AddText(Colors.RED, "No selection is currently set. Use hacks_worldedit select")
      return
    end
    net.Start( "properties" )
    net.WriteUInt( util.NetworkStringToID( "remove" ), 32 )
    net.WriteEntity( CE.Session.WorldEdit )
    net.SendToServer()
  end
  worldeditCmd.func = function(ply,name,args)
    if #args == 0 then
      RunConsoleCommand("hacks_help", "worldedit")
      return
    end
    if args[1] == "unselect" then
      unselect()
    elseif args[1] == "select" then
      select()
    elseif args[1] == "client" and args[2] == "paste" then
      pasteClient()
    elseif args[1] == "server" and args[2] == "paste" then
      pasteServer()
    elseif args[1] == "sandbox" and args[2] == "paste" then
      pasteSpawn()
    elseif args[1] == "sandbox" and (args[2] == "remove" or args[2] == "del" or args[2] == "delete") then
      deleteSandbox()
    elseif args[1] == "client" and (args[2] == "remove" or args[2] == "del" or args[2] == "delete") then
      deleteClient()
    elseif args[1] == "server" and (args[2] == "remove" or args[2] == "del" or args[2] == "delete") then
      deleteServer()
    else
      chat.AddText(Colors.RED, "Unknown worldedit command "..args[1])
    end
  end
  worldeditCmd.autocomplete = function(commandName,args)
    local current = string.join("", args):sub(2)
    local options =  {"sandbox del","sandbox delete","sandbox remove","sandbox paste", "client del","client delete","client remove", "server del","server delete","server remove","server paste","client paste","select", "unselect"}
    local validOptions = { }
    for key,val in pairs(options) do
      if(val:starts(current)) then
        table.insert(validOptions, "hacks_worldedit "..val)
      end
    end
    table.sort(validOptions, function(a, b) return a < b end)
    return validOptions
  end
  local mat = Material("models/props_combine/portalball001_sheet")
  local ARROW_HEAD_LENGTH = 4
  local ARROW_HEAD_WIDTH = 2
  local AXIS_LENGTH = 20
  surface.CreateFont("CompassText", {
    font="Default",
    size=20,
    weight=500,
    antialias=true,
    outline=false
  })
  local function DrawAxes(Position,Angles,Alpha, LabelAlpha)


    local Center = Position
    local XEnd = Center + Vector(AXIS_LENGTH,0,0):Rotate(Angles)
    local XArrow1 = XEnd + Vector(-ARROW_HEAD_LENGTH,ARROW_HEAD_WIDTH,0):Rotate(Angles)
    local XArrow2 = XEnd + Vector(-ARROW_HEAD_LENGTH,-ARROW_HEAD_WIDTH,0):Rotate(Angles)
    local YEnd = Center + Vector(0,AXIS_LENGTH,0):Rotate(Angles)
    local YArrow1 = YEnd + Vector(ARROW_HEAD_WIDTH,-ARROW_HEAD_LENGTH,0):Rotate(Angles)
    local YArrow2 = YEnd + Vector(-ARROW_HEAD_WIDTH,-ARROW_HEAD_LENGTH,0):Rotate(Angles)
    local ZEnd = Center + Vector(0,0,AXIS_LENGTH):Rotate(Angles)
    local ZArrow1 = ZEnd + Vector(0,-ARROW_HEAD_WIDTH,-ARROW_HEAD_LENGTH):Rotate(Angles)
    local ZArrow2 = ZEnd + Vector(0,ARROW_HEAD_WIDTH,-ARROW_HEAD_LENGTH):Rotate(Angles)
    local red = Colors.WithAlpha(Colors.RED, Alpha)
    local green = Colors.WithAlpha(Colors.GREEN, Alpha)
    local blue = Colors.WithAlpha(Colors.BLUE, Alpha)


    render.DrawLine( Center, XEnd, red, false )
    render.DrawLine( XEnd, XArrow1, red, false )
    render.DrawLine( XEnd, XArrow2, red, false )

    render.DrawLine( Center, YEnd, green, false )
    render.DrawLine( YEnd, YArrow1, green, false )
    render.DrawLine( YEnd, YArrow2, green, false )

    render.DrawLine( Center, ZEnd, blue, false )
    render.DrawLine( ZEnd, ZArrow1, blue, false )
    render.DrawLine( ZEnd, ZArrow2, blue, false )

    if LabelAlpha > 0 then
      red = Colors.WithAlpha(Colors.RED, LabelAlpha)
      green = Colors.WithAlpha(Colors.GREEN, LabelAlpha)
      blue = Colors.WithAlpha(Colors.BLUE, LabelAlpha)
      local Data = hook.Run( "CalcView", LocalPlayer(), EyePos(), EyeAngles(), 75 )
      local Position = Data.origin or EyePos()
      local Angles = Data.angles or EyeAngles()
      local angles = (XEnd - Position):Angle()
      angles = Angle(0,angles.y-90,90-angles.p)

      cam.IgnoreZ(true);
      cam.Start3D2D( XEnd, angles, .2 )
      draw.DrawText( "X (Front)", "CompassText", 0,-20, red, TEXT_ALIGN_CENTER )
      cam.End3D2D()

      cam.Start3D2D( YEnd, angles, .2 )
      draw.DrawText( "Y (Left)", "CompassText", 0,-20, green, TEXT_ALIGN_CENTER )
      cam.End3D2D()

      cam.Start3D2D( ZEnd, angles, .2 )
      draw.DrawText( "Z (Up)", "CompassText", 0,-20, blue, TEXT_ALIGN_CENTER )
      cam.End3D2D()
      cam.IgnoreZ(false);
    end
  end
  CE.Hook.Add("PostDrawTranslucentRenderables","CE.DrawSelection", function()
    if IsValid(CE.Session.WorldEdit) then
      cam.Start3D(EyePos(), EyeAngles())
      render.MaterialOverride(mat)
      render.SuppressEngineLighting(true)
      render.SetColorModulation(0, .5, 0)

      CE.Session.WorldEdit:DrawModel()

      render.SetColorModulation(1, 1, 1)
      render.SuppressEngineLighting(false)
      render.MaterialOverride(nil)
      cam.End3D()

      -- Draw origin axes
      DrawAxes(CE.Session.WorldEdit:GetPos(), Angle(0,0,0), 255, 255)

      -- Draw prop axes
      DrawAxes(CE.Session.WorldEdit:GetPos(), CE.Session.WorldEdit:GetAngles(), 50, 0)

    else
      CE.Session.WorldEdit=nil
    end
  end)
  MODULE.AddCmd(worldeditCmd)
end