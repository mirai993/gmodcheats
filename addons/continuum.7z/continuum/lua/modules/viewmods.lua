MODULE.ID = "com.continuum.viewmods"
MODULE.Dependencies = { }

MODULE.Name="View mods"
MODULE.Info="Modifications to view GM core stuff"
MODULE.cvars = {
  {Name="hacks_camera", Nick="RT Camera", Info="Draws a camera onto your screen", Default=0, HUD={ Category="Misc", Type="ToggleButton"}},
  {Name="hacks_rearview", Nick="Rear View", Info="Makes hacks_camera show 'eyes in the back of your head'", Default=0, HUD={ Category="Misc", Type="ToggleButton"}},
  {Name="hacks_usecameraprop", Nick="Use Camera Prop", Info="Use the camera prop from the camera STOOL", Default=1, HUD={ Category="Misc", Type="ToggleButton"}},
  {Name="hacks_camerax", Nick="Camera X", Info="Camera X position", Default=0, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=0, Max=ScrW()}},
  {Name="hacks_cameray", Nick="Camera Y", Info="Camera Y position", Default=0, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=0, Max=ScrH()}},
  {Name="hacks_cameraw", Nick="Camera Width", Info="Camera screen width", Default=ScrW() / 3, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=1, Max=ScrW()}},
  {Name="hacks_camerah", Nick="Camera Height", Info="Camera screen height", Default=ScrH() / 3, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=1, Max=ScrH()}},
  {Name="hacks_zoom", Nick="Zoom", Info="Zoom Level", Default=1, NoToggle=true, Save=false, HUD={ Category="Misc", Type="Slider", Min=.0001, Max=1000}},
  {Name="hacks_seethroughdistance", Nick="See-through", Info="See through walls", Default=.1, NoToggle=true, Save=false, HUD={ Category="Misc", Type="Slider", Min=1, Max=10000}},
}

MODULE.Init = function(CE)
  local Colors = CE.Colors
  ----[[ GAMEMODE stuff ]]----
  local function getThirdPersonPos(ply)
    local aimvector = LocalPlayer():GetAimVector()
    local startPos = ply:GetShootPos()
    local endpos = startPos - aimvector * 100

    local tracer = {
      start = startPos,
      endpos = endpos,
      filter = ply
    }

    local trace = util.TraceLine(tracer)

    return trace.HitPos + trace.HitNormal * 10
  end
  local DrawLocalPlayer = nil
  local RenderingCamera = false
  local RenderingCameraEnt = false
  local thirdpersonMode = false
  local IsDrawingRT = false
  local IsDrawingRTV = false
  surface.CreateFont("TVFontBigAss", {font="ChatFont", size=200, weight=400, antialias=true, additive=false})
  surface.CreateFont("TVFontHuge", {font="ChatFont", size=45, weight=400, antialias=true, additive=false})
  surface.CreateFont("TVFontBig", {font="ChatFont", size=30, weight=400, antialias=true, additive=false})
  surface.CreateFont("TVFontMedium", {font="ChatFont", size=20, weight=400, antialias=true, additive=false})
  surface.CreateFont("TVFontSmall", {font="ChatFont", size=10, weight=400, antialias=true, additive=false})
  local w, h = ScrW(), ScrH()
  local customRT = GetRenderTarget("models/effects/splode1_sheet",w,h);
  local RTTexture = surface.GetTextureID( "models/effects/splode1_sheet" );
  local OldRT = render.GetRenderTarget()
  render.SetRenderTarget( customRT )
  render.SetViewPort( 0, 0, w, h )
  render.Clear( 0, 0, 0, 255 )
  render.SetViewPort( 0, 0, w, h )
  render.SetRenderTarget( OldRT )
  local function UpdateRTCameraMat()
    if IsDrawingRTV then return end
    IsDrawingRTV=true
    local OldRT = render.GetRenderTarget()
    render.SetRenderTarget( customRT )
    cam.Start2D()
    draw.SimpleText( "RT Material", "TVFontBigAss", w/2,h/2, Color(255,0,0,255), TEXT_ALIGN_CENTER )
    cam.End2D()
    render.SetRenderTarget( OldRT )
    IsDrawingRTV=false
  end
  local function UpdateRTCameraView()
    if IsDrawingRTV then return end
    IsDrawingRTV = true
    local OldRT = render.GetRenderTarget()
    render.SetRenderTarget( customRT )
    local time = math.round(CurTime() / 5)
    local _cameras = ents.FindByClass('gmod_cameraprop')
    local cameras = { }
    for _,ent in pairs(_cameras) do
      if ent:GetPlayer() == LocalPlayer() then
        table.insert(cameras, #cameras+1, ent)
      end
    end
    if #cameras > 0 then
      local cameraindex = time % #cameras + 1
      local camera = cameras[cameraindex]
      local CamData = {}
      CamData.angles = camera:GetAngles()
      CamData.origin = camera:GetPos()
      CamData.x = 0
      CamData.y = 0
      CamData.w = ScrW()
      CamData.h = ScrH()


      camera:SetNoDraw(true)
      LocalPlayer():SetNoDraw(false)
      DrawLocalPlayer = true
      render.RenderView( CamData )
      cam.Start2D()
      draw.SimpleText( "Camera "..cameraindex.."/"..#cameras, "TVFontBig", w-35,30, Color(255,0,0,255), TEXT_ALIGN_RIGHT )
      cam.End2D()
      DrawLocalPlayer = nil
      camera:SetNoDraw(false)
    else
      render.Clear( 0, 0, 0, 255, true )
      local players = player.GetAll()
      local index = time % #players + 1
      local ply = players[index]

      local CamData = {}
      CamData.angles = ply:EyeAngles()
      CamData.origin = getThirdPersonPos(ply)
      CamData.x = 0
      CamData.y = 0
      CamData.w = ScrW()
      CamData.h = ScrH()


      ply:SetNoDraw(true)
      DrawLocalPlayer = ply ~= LocalPlayer()
      render.RenderView( CamData )
      DrawLocalPlayer = nil
      ply:SetNoDraw(false)
      cam.Start2D()
      draw.SimpleText( "No camera set", "TVFontHuge", w/2,h - 100, Color(255,0,0,255), TEXT_ALIGN_CENTER )
      draw.SimpleText( "Spectating: "..ply:Nick(), "TVFontBig", w/2,h - 50, Colors.WHITE, TEXT_ALIGN_CENTER )
      cam.End2D()
    end
    render.SetRenderTarget( OldRT )
    IsDrawingRTV = false
  end
  local function UpdateOnscreenCameraView()
    if IsDrawingRT then return end
    local angles = LocalPlayer():EyeAngles()
    local pos = LocalPlayer():EyePos()
    if CE.GetConVarBool("hacks_rearview") then
      angles.pitch = angles.pitch * -1
      angles.yaw = angles.yaw + 180
    end
    local camera = nil
    if CE.GetConVarBool("hacks_usecameraprop") then
      local cameras = ents.FindByClass('gmod_cameraprop')
      for _,ent in pairs(cameras) do
        if ent.GetPlayer and ent:GetPlayer() == LocalPlayer() then
          camera = ent
        end
      end
    end
    if LocalPlayer():GetViewEntity() == camera then camera = nil end
    if camera then
      angles = camera:GetAngles()
      pos = camera:GetPos()
    end

    local CamData = {}
    CamData.angles = angles
    CamData.origin = pos
    CamData.x = GetConVarNumber("hacks_camerax")
    CamData.y = GetConVarNumber("hacks_cameray")
    CamData.w = ScrW() / 3
    CamData.h = ScrH() / 3

    RenderingCamera = true
    if camera then
      camera:SetNoDraw(true)
      RenderingCameraEnt = true
    end
    IsDrawingRT = true
    render.RenderView( CamData )
    IsDrawingRT = false
    if camera then
      camera:SetNoDraw(false)
      RenderingCameraEnt = false
    end
    RenderingCamera = false
    --surface.SetTexture( RTTexture )
    --surface.DrawTexturedRect(0,0,ScrW()/3, ScrH()/3)
  end
  local function OriginCam()
    local ShouldUpdateOnScreenCamera = CE.GetConVarBool("hacks_camera")
    local ShouldUpdateRTCamera = false
    for _,ent in pairs(ents.GetAll()) do
      if ent:GetMaterial() == "models/effects/splode1_sheet" then
        ShouldUpdateRTCamera = true
        break
      end
    end
    if ShouldUpdateRTCamera then UpdateRTCameraView() else UpdateRTCameraMat() end
    if ShouldUpdateOnScreenCamera then UpdateOnscreenCameraView() end
  end
  --CE.Hook.Add("HUDPaint", "CE.OriginCam", OriginCam)
  --CE.Hook.Add("Think", "CE.RTCamera", function()
  --end)
  timer.Destroy("CERTCamera")


  local GM = GAMEMODE
  local function CECalcView( player, origin, angles, fov, znear, zfar)
    local view = { }
    local ViewChanged = false
    local wep = LocalPlayer():GetActiveWeapon()
    if IsValid(wep) and wep.dt and wep.dt.Scope and wep.ZoomLevel and wep.UseZoom then
      view.fov = wep.ZoomLevel
    end
    if thirdpersonMode then
      view.origin = getThirdPersonPos(LocalPlayer())
      view.angles = LocalPlayer():EyeAngles()
    end
    if (GetConVarNumber("hacks_zoom") ~= 1 and GetConVarNumber("hacks_zoom") ~= 0) then
      view.fov = 75 / GetConVarNumber("hacks_zoom")
    end
    if math.abs(GetConVarNumber("hacks_seethroughdistance") - .1) > .5 then
      view.znear = GetConVarNumber("hacks_seethroughdistance")
    end
    if table.Count(view) > 0 then return view end
  end
  CE.Hook.Add( "CalcView", "CE.NoRecoil", CECalcView );
  local thirdperson = true
  local IsNoclipped = false
  local function noclip()
    IsNoclipped = not IsNoclipped
    
  end

  local stopSpectating
  local isSpectating = false
  local roamPos -- the position when roaming free
  local roamVelocity = Vector(0)
  local trueAngles = LocalPlayer():EyeAngles()
  local spectateAngles = LocalPlayer():EyeAngles()
  local oldUse = false
  local view = {
    vm_origin = Vector(0, 0, -13000)
  }

  local function specCalcView(ply, origin, angles, fov)
    view.origin = roamPos
    view.angles = spectateAngles
    return view
  end


  -- Manual keysDown table, so I can return true in plyBindPress and still detect key presses
  local keysDown = {}
  local function specBinds(ply, bind, pressed)
    if LocalPlayer():KeyDown(IN_USE) or bind == "+use" then return end
    local key = string.match(bind, "+([a-z A-Z 0-9]+)")
    if not key or key == "use" or key == "attack" then return end
    keysDown[key:upper()] = pressed
    return true
  end


  local function specThink()
    local ply = LocalPlayer()

    if keysDown["USE"] then return end

    local roamSpeed = 1000
    local aimVec = ply:GetAimVector()
    aimVec = spectateAngles:Forward()
    local direction = Vector(0)
    local frametime = RealFrameTime()

    if keysDown["FORWARD"] then
      direction = aimVec
    elseif keysDown["BACK"] then
      direction = -aimVec
    end

    if keysDown["MOVELEFT"] then
      direction = direction - aimVec:Angle():Right()
    elseif keysDown["MOVERIGHT"] then
      direction = direction + aimVec:Angle():Right()
    elseif keysDown["JUMP"] then
      direction = direction + Vector(0,0,10)
    end

    if keysDown["SPEED"] then
      roamSpeed = 1700
    elseif keysDown["WALK"] then
      roamSpeed = 400
    end

    direction:Normalize()

    roamVelocity = direction * roamSpeed
    roamPos = roamPos + roamVelocity * frametime
  end


  local function drawHelp()
    draw.WordBox(2, 10, ScrH() / 2, "Left mouse: teleport forwards", "Trebuchet18", Color(0,0,0,120), Color(255, 255, 255, 255))
    draw.WordBox(2, 10, ScrH() / 2 + 20, "Right mouse: (Un)select player to spectate", "Trebuchet18", Color(0,0,0,120), Color(255, 255, 255, 255))
    draw.WordBox(2, 10, ScrH() / 2 + 40, "Jump: Stop spectating", "Trebuchet18", Color(0,0,0,120), Color(255, 255, 255, 255))
    draw.WordBox(2, 10, ScrH() / 2 + 60, "Right mouse + Jump: Teleport to spectate pos", "Trebuchet18", Color(0,0,0,120), Color(255, 255, 255, 255))
  end
  local lastAngles = Angle(0,0,0)
  local function CreateSpectateAngles(cmd)
    if not cmd:KeyDown(IN_USE) then
      -- Here's a cool little trick. By storing the old angles, and comparing to the new ones found here
      -- we can tell how much the player tried to move angles. Normally we let them just move. However
      -- since we're faking the ucmd angles, LocalPlayer():EyeAngles() will always return our fake angles.
      -- solution: use the dAngles and add them to our old stored spectating angles. That way we can still
      -- move our mouse around to move like normal, but we can also fake the angles of our player that are sent
      -- to the server :D (in our case, we tell the server our angles are w/e points to what we look at in spectate
      -- mode. This lets us go roam around, and then we can shoot and it will still hit our crosshairs)
      -- A cool fun way to test this is with your physgun; hold it down as u fly around and look at ur player / laser
      local dAngle = cmd:GetViewAngles() - lastAngles
      local hitPoint = util.TraceLine({start=roamPos, endpos=roamPos+spectateAngles:Forward()*100000}).HitPos
      local fakeAngles = spectateAngles -- on the off chance that there's nothing 100k units away from us
      if hitPoint then
        fakeAngles = (hitPoint - LocalPlayer():GetShootPos()):Angle()
      end
      cmd:SetViewAngles(fakeAngles)
      spectateAngles = spectateAngles + dAngle
    end
    lastAngles = cmd:GetViewAngles()
  end
  local function startSpectate()
    roamPos = LocalPlayer():GetShootPos()
    spectateAngles = EyeAngles()
    keysDown = {}
    isSpectating = true
    DrawLocalPlayer = true
    CE.Hook.Add("CalcView", "CE.Spectate", specCalcView)
    CE.Hook.Add("PlayerBindPress", "CE.Spectate", specBinds)
    CE.Hook.Add("Think", "CE.Spectate", specThink)
    CE.Hook.Add("HUDPaint", "CE.Spectate", drawHelp)
    CE.Hook.Add("CreateMove", "CE.Spectate", CreateSpectateAngles)
  end


  function stopSpectating()
    CE.Hook.Remove("CalcView", "CE.Spectate")
    CE.Hook.Remove("PlayerBindPress", "CE.Spectate")
    CE.Hook.Remove("ShouldDrawLocalPlayer", "CE.Spectate")
    CE.Hook.Remove("Think", "CE.Spectate")
    CE.Hook.Remove("HUDPaint", "CE.Spectate")
    CE.Hook.Remove("CreateMove", "CE.Spectate")

    timer.Destroy("CESpectatePosUpdate")

    isSpectating = false
    DrawLocalPlayer = nil
  end
  local function makeThirdperson()
    thirdpersonMode = true
  end
  local function makeFirstperson()
    thirdpersonMode = false
  end
  local function ShouldDrawLocalPlayer()
    local ShouldDraw = nil
    if render.DrawLocalPlayer ~= nil then
      ShouldDraw = render.DrawLocalPlayer
    elseif DrawLocalPlayer ~= nil then
      ShouldDraw = DrawLocalPlayer
    elseif IsDrawingRTV then
      ShouldDraw = true
    elseif RenderingCamera and RenderingCameraEnt then
      ShouldDraw = true
    elseif not RenderingCamera and thirdpersonMode then
      ShouldDraw = true
    else
      ShouldDraw = not LocalPlayer():GetViewEntity() == LocalPlayer()
      -- let's just not have a say in this case, and let other CE.Hooks manage it
      return
    end
    --LocalPlayer():SetNoDraw(not ShouldDraw)
    return ShouldDraw
  end

  CE.Hook.Add( "ShouldDrawLocalPlayer", "CE.LocalDrawing", ShouldDrawLocalPlayer, -10 )

  MODULE.AddCmd({ name="hacks_roamstart", NoArgs=true, nick="Roam Start", info="Roam around as spectator (models far from player don't show well)", func=startSpectate })
  MODULE.AddCmd({ name="hacks_roamstop", NoArgs=true, nick="Roam Stop", info="Stop roaming around as spectator", func=stopSpectating })
  MODULE.AddCmd({ name="hacks_thirdperson", NoArgs=true, nick="Thirdperson", func=makeThirdperson, HUD={ Category="Misc", Type="CommandButton"}})
  MODULE.AddCmd({ name="hacks_firstperson", NoArgs=true, nick="Firstperson", func=makeFirstperson, HUD={ Category="Misc", Type="CommandButton"}})
  MODULE.AddCmd({ name="hacks_noclip", NoArgs=true, nick="Noclip", func=noclip, HUD={ Category="Misc", Type="CommandButton"}})
  stopSpectating()


  local lockpos = nil
  local LockTarget = false
  concommand.Add("+hacks_lockcam", function()
    LockTarget = true
    lockpos = LocalPlayer():EyeAngles()
  end)
  concommand.Add("-hacks_lockcam", function()
    LockTarget = false
  end)
  local lastAdjustment = Angle(0,0,0)
  CE.Hook.Add("CreateMove", "CE.LockCam", function(cmd)
    if LockTarget then
      cmd:SetViewAngles(lockpos)
    end
    local wep = LocalPlayer():GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() == "weapon_357" then
      local ang = -LocalPlayer():GetPunchAngle()
      cmd:SetViewAngles(cmd:GetViewAngles()+ang-lastAdjustment)
      lastAdjustment = ang
    end
  end)
end