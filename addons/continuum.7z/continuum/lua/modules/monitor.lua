local CE = CE
MODULE.ID = "com.continuum.monitor"
MODULE.Dependencies = { }

MODULE.Name="Monitor"
MODULE.Info="Monitor changes to entities, like color, material, amount, fading state, movement etc."

CE.Session.Monitors = CE.Session.Monitors or { }
MODULE.Init = function(CE)
  local function GetEyeEntity()
    return util.TraceLine(util.GetPlayerTrace(LocalPlayer())).Entity
  end
  local function compare(a, b)
    if a.r and a.g and a.b and b.r and b.g and b.b then
      return a.r == a.r and b.g == a.g and b.b == a.b and b.a == a.a
    end
    return a == b
  end
  local function colortostring(col)
    return "(r="..col.r..",g="..col.g..",b="..col.b..",a="..col.a..")"
  end
  local FADING_MAT = "sprites/heatwave"
  timer.Create("MonitorUpdate", .5,0, function()
    for name,data in pairs(CE.Session.Monitors) do
      local ent = data.ent
      if not IsValid(ent) then
        CE.Session.Monitors[name] = nil
      else
        if ent:GetMaterial() == FADING_MAT then
          if not data.FadingDoor or not data.FadingDoor.Active then
            chat.AddText(CE.Colors.GREEN, data.Name.."'s fading door was opened!")
          end
          chat.PlaySound()
          chat.PlaySound()
          chat.PlaySound()
          chat.PlaySound()
          data.FadingDoor = { Active=true }
        elseif data.FadingDoor and data.FadingDoor.Active then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s fading door was closed!")
          data.FadingDoor = { Active=false }
        end
        local IsDoor = ent:GetClass() == "func_door" or ent:GetClass() == "func_door_rotating" or
          ent:GetClass() == "prop_door_rotating" or ent:GetClass() == "prop_dynamic"

        if IsDoor then
          local angles = ent:GetSaveTable().m_angAbsRotation
          local isClosed = math.abs((math.abs(angles.yaw) % 180) - 90) < 2
          local isOpen = not isClosed
          if isOpen ~= data.IsDoorOpen then
            if isOpen then
              chat.AddText(CE.Colors.GREEN, data.Name.." was opened!")
              chat.PlaySound()
              chat.PlaySound()
              chat.PlaySound()
              chat.PlaySound()
            else
              chat.AddText(CE.Colors.GREEN, data.Name.." was closed!")
            end
            data.IsDoorOpen = isOpen
          end
        end
        if data.material ~= ent:GetMaterial() and data.material ~= FADING_MAT and ent:GetMaterial() ~= FADING_MAT then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s material was changed from '", CE.Colors.RED, data.material, CE.Colors.GREEN, " ' to '", CE.Colors.RED, ent:GetMaterial(), CE.Colors.GREEN, " '")
          data.material = ent:GetMaterial()
        end
        if not compare(data.color, ent:GetColor()) then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s color was changed from '", CE.Colors.RED, colortostring(data.color), CE.Colors.GREEN, " ' to '", CE.Colors.RED, colortostring(ent:GetColor()), CE.Colors.GREEN, " '")
          data.color = ent:GetColor()
        end
        if data.model ~= ent:GetModel() then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s model was changed from '", CE.Colors.RED, data.model, CE.Colors.GREEN, " ' to '", CE.Colors.RED, ent:GetModel(), CE.Colors.GREEN, " '")
          data.model = ent:GetModel()
        end
        if ent.dt and data.amount ~= ent.dt.amount then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s amount was changed from '", CE.Colors.RED, tostring(data.amount), CE.Colors.GREEN, " ' to '", CE.Colors.RED, tostring(ent.dt.amount), CE.Colors.GREEN, " '")
          data.amount = ent.dt.amount
        end
        if ent:GetNWInt("PrintA",nil) ~= data.PrintA then
          chat.AddText(CE.Colors.GREEN, data.Name.."'s money was changed from '", CE.Colors.RED, tostring(data.PrintA), CE.Colors.GREEN, " ' to '", CE.Colors.RED, tostring(ent:GetNWInt("PrintA",nil)), CE.Colors.GREEN, " '")
          data.PrintA = ent:GetNWInt("PrintA",nil)
        end
      end
    end
  end)
  function AddMonitor(Name,ent)
    --
    CE.Session.Monitors[Name] = {Name=Name, PrintA=ent:GetNWInt("PrintA",nil),ent=ent, amount=ent.dt and ent.dt.amount, color=ent:GetColor(), material=ent:GetMaterial(), model=ent:GetModel(), pos=ent:GetPos(), lastPosWarn=0}
  end
  local monitoradd = { name="hacks_monitoradd", nick="Monitor Add"}
  monitoradd.func = function(ply, cmd, args)
    if #args ~= 1 then
      Msg("Command expects 1 argument, the name of the monitor to create")
      return
    end
    local ent = GetEyeEntity()
    if not ent then
      Msg("No entity found at crosshairs!")
      return
    end
    AddMonitor(args[1], ent)
  end
  monitoradd.autocomplete = function(cmd, args)
    return { cmd.." [name]" }
  end

  local monitordel = { name="hacks_monitordel", nick="Monitor Delete"}
  monitordel.func = function(ply, cmd, args)
    if #args ~= 1 then
      Msg("Command expects 1 argument, the name of the monitor to delete")
      return
    end
    CE.Session.Monitors[args[1]] = nil
  end
  monitordel.autocomplete = function(cmd, args)
    local res = { }
    for name,ent in pairs(CE.Session.Monitors) do
      table.insert(res, 1, cmd.." \""..name.."\"")
    end
    return res
  end

  MODULE.AddCmd(monitoradd)
  MODULE.AddCmd(monitordel)
end