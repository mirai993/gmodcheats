MODULE.ID = "com.continuum.nohandicap"
MODULE.Dependencies = { }

MODULE.Name = "No Handicap"
MODULE.Info = "Removes recoil of a gun and other handicaps"
MODULE.cvars = {
  { name="hacks_speedhack_ratio", nick="Speedhack Amount", info="Ratio of speed to normal speed (1 is roughly regular, 2 is double speed, .5 is half speed", default=9, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=0, Max=10}},
  { name="hacks_speedhack_caution", nick="Speedhack Caution", info="Automatically disables when you're in the LOS of another player, and reenables after", default=1, HUD={ Category="Misc", Type="ToggleButton"}},
  { name="hacks_nospread", nick="Nospread", info="No spread when shooting", default="1", HUD={ Category="Weaponry", Type="ToggleButton"}}
}

MODULE.Init = function(CE)
  usermessage.Hook("sh_flashed", function( um ) end )
  usermessage.Hook("blackScreen", function( um ) end)
  usermessage.Hook( "ulx_blind", function( um ) end )

  -- todo: maybe make a convar for these
  hook.Remove("HUDPaintBackground", "BlackScreen")
  hook.Remove("RenderScreenspaceEffects", "StunEffect")
  hook.Remove("HUDPaint", "FlashEffect")
  hook.Remove("HUDPaint", "Veins_Effect")
  hook.Remove("RenderScreenspaceEffects", "SW.RenderScreenspaceEffects")
  hook.Remove("RenderScreenspaceEffects", "durgz_alcohol_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_cigarette_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_cocaine_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_heroine_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_lsd_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_mushroom_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_pcp_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_weed_high")
  hook.Remove("RenderScreenspaceEffects", "durgz_cigarette_msg")
  hook.Remove("RenderScreenspaceEffects", "durgz_heroine_notice")
  hook.Remove("RenderScreenspaceEffects", "durgz_mushroom_awesomeface")


  local IsSpeedhackOn = false
  CE.Hook.Remove("PlayerSwitchWeapon", "CE.NoRecoil")
  hook.Remove( "PlayerBindPress", "ULXGagForce" ) -- fuck ulx
  timer.Destroy( "GagLocalPlayer")
  hook.Remove('PlayerBindPress','FAdmin_voicemuted') -- fuck fadmin
  CE.Hook.Add("Think", "CE.SafeSpeedhack", function()
    local ply = LocalPlayer()
    local weapon = ply:GetActiveWeapon()
    if IsValid(weapon) then
      if weapon.Primary and weapon.Primary.Recoil then
        weapon.Primary.Recoil = 0
      end
      if weapon.Recoil then
        weapon.Recoil = 0
      end
      if weapon.Recoil_Orig then
        weapon.Recoil_Orig = 0
      end
      if weapon.SwayScale then
        weapon.SwayScale = 0
      end
      if weapon.BobScale then
        weapon.BobScale = 0
      end
      --if weapon.ViewKick then
      --  weapon.ViewKick = 0
      --end
      if weapon:GetNoDraw() then
        weapon:SetNoDraw(false)
      end
      weapon.DrawCrosshair = true
      hook.Remove("CreateMove", "SniperCreateMove") -- fuck the sniper sway
      --CE.LuaDebugger(weapon.ShootBullet)
    end
    if IsSpeedhackOn then
      local IsLookedAt = false
      for k,v in pairs(player.GetAll()) do
        IsLookedAt = IsLookedAt or (not v.AFK and v:IsLookingAt(LocalPlayer()))
      end
      if IsLookedAt and CE.GetConVarBool("hacks_speedhack_caution") then
        if GetConVarNumber("host_framerate") ~= 0 then
          RunConsoleCommand("host_framerate", 0)
        end
      elseif IsSpeedhackOn ~= GetConVarNumber("host_framerate") then
        RunConsoleCommand("host_framerate", IsSpeedhackOn)
      end
    end
  end)
  local LastViewAng = false

  local function SimilarizeAngles(ang1, ang2)

    ang1.y = math.fmod (ang1.y, 360)
    ang2.y = math.fmod (ang2.y, 360)

    if math.abs (ang1.y - ang2.y) > 180 then
      if ang1.y - ang2.y < 0 then
        ang1.y = ang1.y + 360
      else
        ang1.y = ang1.y - 360
      end
    end
  end
  local function ReduceScopeSensitivity(uCmd)
    if LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() and not CE.AimbotTarget and not CE.AimbotV2Target then
      local newAng = uCmd:GetViewAngles()

      if LastViewAng then
        SimilarizeAngles (LastViewAng, newAng)

        local diff = newAng - LastViewAng

        diff = diff * (LocalPlayer():GetActiveWeapon().MouseSensitivity or 1)
        uCmd:SetViewAngles (LastViewAng + diff)
      end
    end
    LastViewAng = uCmd:GetViewAngles()
  end
  CE.Hook.Add ("CreateMove", "BetterReduceScopeSensitivity", ReduceScopeSensitivity)
  hook.Remove("CreateMove", "ReduceScopeSensitivity")

  local speedhackOn = { name="+hacks_speedhack", NoArgs=true, nick="Speedhack On", info="Uses 'host_framerate' to make your player run fast; dont get seen! [On]", HUD={ Category="Misc", Type="CommandButton"}}
  local speedhackOff = { name="-hacks_speedhack", NoArgs=true, nick="Speedhack Off", info="Uses 'host_framerate' to make your player run fast; dont get seen! [Off]", HUD={ Category="Misc", Type="CommandButton"}}
  speedhackOn.func = function(ply,name,args)
    local speed = args[1]
    if #args <= 1 or not speed or speed == '' then
      speed = GetConVarNumber("hacks_speedhack_ratio")
    else
      speed = tonumber(tostring(speed))
    end
    speed = math.Clamp(speed, 0, 10)
    if speed == 0 then speed = .00000000000000000000000001 end
    speed = (1/speed) * 40
    IsSpeedhackOn = speed
    RunConsoleCommand("host_framerate", IsSpeedhackOn)
  end
  speedhackOff.func = function()
    RunConsoleCommand("host_framerate", "0")
    IsSpeedhackOn = nil
  end
  MODULE.AddCmd(speedhackOn)
  MODULE.AddCmd(speedhackOff)
  local NormalCones                       = {
    [ "weapon_cs_base" ]    = true,
    [ "weapon_zs_base" ]    = true,
  }

  local HL2Cones                          = {
    weapon_357 = -Vector(0,0,0),
    weapon_smg1 = -Vector(0.04362, 0.04362, 0.04362),
    weapon_ar2 = -Vector(0.02618, 0.02618, 0.02618),
    weapon_pistol = -Vector(0.00873, 0.00873, 0.00873),
    weapon_shotgun = -Vector(0.08716, 0.08716, 0.08716),
  }
  local SpreadTable = { }

  local function GetCone( wep )
    if not IsValid( wep ) then return 0 end

    if HL2Cones[ wep:GetClass() ] then return HL2Cones[ wep:GetClass() ] end
    if NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end

    local Cone = wep.Cone

    if not Cone then
      Cone = wep.Primary and wep.Primary.Cone or 0
    end

    return Cone
  end
  local function GetVectorCone( weapon )
    if IsValid(weapon) and SpreadTable[weapon:EntIndex()] then return SpreadTable[weapon:EntIndex()] * -1 end
    if IsValid(weapon) and SpreadTable[weapon:GetClass()] then return SpreadTable[weapon:GetClass()] * -1 end
    local w = weapon
    local vecCone, valCone = Vector( 0, 0, 0 )
    if ( w and w:IsValid() and ( type( w.Initialize ) == "function" ) ) then
      valCone = GetCone( w )
      if ( type( valCone ) == "number" ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
      elseif ( type( valCone ) == "Vector" ) then
        vecCone = valCone * -1
      elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
        vecCone = valCone * 2
      end
    else
      if ( w:IsValid() ) then
        local class = w:GetClass()
        if ( HL2Cones[ class ] ) then
          vecCone = HL2Cones[ class ]
        end
      end
    end
    return vecCone
  end
  CE.GetVectorCone = GetVectorCone
  CE.Session._FireBullets = CE.Session._FireBullets or debug.getregistry().Entity.FireBullets
  debug.getregistry().Entity.FireBullets = function(self, bullets)
    --PrintTable(bullets)
    if self == LocalPlayer() then
      SpreadTable[self:GetActiveWeapon():EntIndex()] = bullets.Spread
      SpreadTable[self:GetActiveWeapon():GetClass()] = bullets.Spread
    end
    bullets.Tracer = 1
    CE.Session._FireBullets(self, bullets)
  end
  function CE.ClampAngle(ang)
    ang.r = (ang.r + 180) % 360 - 180
    ang.p = (ang.p + 180) % 360 - 180
    ang.y = (ang.y + 180) % 360 - 180
    return ang
  end
  local ms = Angle()
  local function mouse(c)
    ms = ms + Angle(c:GetMouseY() * 0.022,-c:GetMouseX() * 0.022,0)
    ms.p = math.Clamp(ms.p,-89,89)
  end
  local function angles(c)
    return ms
  end
  local lastAdjustment = Angle(0,0,0)
  CE.Hook.Add("CreateMove", "CE.NoSpread", function(cmd)
    local self = LocalPlayer():GetActiveWeapon()
    _G.cmd = cmd
    if IsValid(self) and cmd:CommandNumber() ~= 0 and cmd:KeyDown(IN_ATTACK) then
      if CE.GetConVarBool("hacks_nospread") and self:GetClass():find("fas2") and self.CurCone then
        --print("Echo: " .. cmd:CommandNumber())
        math.randomseed(cmd:CommandNumber())
        local Cone = self.CurCone
        Cone = Cone * 25
        local Dir = Angle(math.Rand(-Cone, Cone), math.Rand(-Cone, Cone), 0)

        if self.ClumpSpread and self.ClumpSpread > 0 then
          Dir = (Dir:Forward() + Vector(math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1)) * self.ClumpSpread):Angle()
        end

        --Dir.r = 0
        --Dir.p = math.NormalizeAngle( Dir.p ) + 0.2
        --Dir.y = math.NormalizeAngle( Dir.y ) + 0.2
        cmd:SetViewAngles(cmd:GetViewAngles()-Dir-lastAdjustment)
        lastAdjustment = -Dir
      elseif CE.GetConVarBool("hacks_nospread") and not self:GetClass():find("fas2") then
        local seed = bit.band(bit.band(CE.md5.PseudoRandom(cmd:CommandNumber()),0x7fffffff),255)
        local vecAim = LocalPlayer():GetAimVector()
        local vecSpread = GetVectorCone(self) -- note vecCone = vecSpread
        CE.RandomSeed(seed)
        -- why round you ask? Well thats an excellent question. Rounding seems like such a waste, why spend resources
        -- to intentionally cut off your precision 4 times every loop? Well you see since, behind the scenes,
        -- these things occur as floats, loss of precision is only natural. We simply simulate this loss of precision
        -- because they only go to 4 decimanl places too, even though the algorithm technically goes to a lot more
        local x = math.round(CE.RandomFloat(-0.5, 0.5), 6) + math.round(CE.RandomFloat(-0.5, 0.5), 6);
        local y = math.round(CE.RandomFloat(-0.5, 0.5), 6) + math.round(CE.RandomFloat(-0.5, 0.5), 6);
        local aimAngles = vecAim:Angle()
        local forward = aimAngles:Forward()
        local right = aimAngles:Right()
        local up = aimAngles:Up()
        local vector = forward + (x * vecSpread.x * right) + (y * vecSpread.y * up)
        local angles = vector:Angle()
        local adjust = angles-cmd:GetViewAngles()
        adjust.r = 0
        cmd:SetViewAngles(CE.ClampAngle(cmd:GetViewAngles()+adjust-lastAdjustment))
        lastAdjustment = adjust
      else
        cmd:SetViewAngles(cmd:GetViewAngles()-lastAdjustment)
        lastAdjustment = Angle(0,0,0)
      end
    else
      cmd:SetViewAngles(cmd:GetViewAngles()-lastAdjustment)
      lastAdjustment = Angle(0,0,0)
    end
  end)
end