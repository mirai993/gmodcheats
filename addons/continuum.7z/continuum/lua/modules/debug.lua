local CE = CE

if MODULE then
  MODULE.ID = "com.continuum.debug"
  MODULE.Dependencies = { }

  MODULE.name = "Debug"
  MODULE.info = "Debugger module that allows lua to be run from console"
end
local function GetFullMetaTable(arg)
  local EM = FindMetaTable( "Entity" )

  local MT = getmetatable(arg)
  local metas = { }
  local ExtendsEntity = false
  local tbl = { }
  while MT do
    if MT == EM then ExtendsEntity = true end
    table.insert(metas, MT)
    MT = MT.MetaBaseClass
  end
  if ExtendsEntity then
    if IsValid(arg) then
      tbl.Owner = arg:GetOwner()
    end
  end
  for _,meta in pairs(metas) do
    for k,v in pairs(meta) do
      tbl[k] = v
    end
  end
  if arg.GetTable and arg:GetTable() then
    for k,v in pairs(arg:GetTable()) do
      tbl[k] = v
    end
  end
  return tbl

end
if not MODULE then
  if not CE then
    CE = { }
  end
  CE.Console = { }
  function CE.Console.AddText(...)
    local printResult = ""
    local arg={...}
    for i,v in ipairs(arg) do
      printResult = printResult .. tostring(v)
    end
    Msg(printResult)
  end
  function string.starts(String,Start)
    return string.sub(String,1,string.len(Start))==Start
  end
  function string.ends(String,End)
    return End=='' or string.sub(String,-string.len(End))==End
  end
  function string:split(sep)
    local sep, fields = sep or ":", {}
    local pattern = string.format("([^%s]+)", sep)
    self:gsub(pattern, function(c) fields[#fields+1] = c end)
    return fields
  end
  function string.url_encode(str)
    if (str) then
      str = string.gsub (str, "\n", "\r\n")
      str = string.gsub (str, "([^%w ])",
        function (c) return string.format ("%%%02X", string.byte(c)) end)
      str = string.gsub (str, " ", "+")
    end
    return str
  end
  function string.url_decode(str)
    str = string.gsub (str, "+", " ")
    str = string.gsub (str, "%%(%x%x)",
      function(h) return string.char(tonumber(h,16)) end)
    str = string.gsub (str, "\r\n", "\n")
    return str
  end
  function string.join(delimiter, list)
    local len = #list
    if len == 0 then
      return ""
    end
    local string = list[1]
    for i = 2, len do
      string = string .. delimiter .. list[i]
    end
    return string
  end
  function math.round(x, place)
    if(place == nil) then
      place = 0
    end
    x = x * math.pow(10, place)
    if x%2 ~= 0.5 then
      return math.floor(x+0.5)/math.pow(10,place)
    end
    x = math.floor(x-0.5)
    return x / math.pow(10,place)
  end
  function table.containsKey(tbl, key)
    return tbl[key] ~= nil
  end
  function table.containsValue(tbl, element)
    for _, value in pairs(tbl) do
      if value == element then
        return true
      end
    end
    return false
  end
  function table.contains(tbl, element)
    return table.containsValue(element)
  end
  function table.tostring (...)
    local printResult = ""
    local arg={...}
    for i,v in ipairs(arg) do
      printResult = printResult .. tostring(v) .. ", "
    end
    return printResult
  end
  function table.print(t)
    for key, val in CE.PairsByKeys(t) do
      CE.Console.AddText(key, "\t ", val, "\n")
    end
  end
  function table.clone(t)
    local nt = { }
    for key,val in pairs(t) do
      nt[key] = val
    end
    setmetatable(nt, getmetatable(t))
    return nt
  end

  function CE.PairsByKeys(t, f)
    local a = {}
    for n in pairs(t) do table.insert(a, n) end
    table.sort(a, f)
    local i = 0-- iterator variable
    local iter = function () -- iterator function
      i = i + 1
      if a[i] == nil then return nil
      else return a[i], t[a[i]]
      end
    end
    return iter
  end
end
if CE.Session.DebugHistory == nil then
  CE.Session.DebugHistory = { }
end

local function debugger( calling_ply,command,arguments, args )
  local variable_name = args
  table.insert(CE.Session.DebugHistory, 1, command.." "..variable_name)
  variable_name = variable_name:gsub("|", ";")
  local success, callback
  local p = variable_name:gsub("\".-\"", ""):gsub("'.-'", "")
  local lua = ""
  if(p:find("return") == nil and p:find(";") == nil) then
    lua = "return "..variable_name
  else
    lua = variable_name
  end
  local func, error = CompileString(lua, "user_lua", false)
  if error then
    CE.Console.AddText("Datatype: [error]", "\n")
    CE.Console.AddText("Compilation error: "..callback, "\n")
    return
  end
  CE.RevealGlobal()
  local success, callback = pcall(func)
  CE.HideGlobal()
  if(not success) then
    CE.Console.AddText("Datatype: [error]", "\n")
    CE.Console.AddText("Runtime error: "..callback, "\n")
    return
  end
  local DebugReturnValue = callback
  CE.Console.AddText("Datatype: "..type(DebugReturnValue), "\n")
  if type( DebugReturnValue ) == "nil" then
    CE.Console.AddText("Null value (void)", "\n")
  elseif type( DebugReturnValue ) == "boolean" then
    CE.Console.AddText("Value: "..tostring(DebugReturnValue), "\n")
  elseif type( DebugReturnValue ) == "number" then
    CE.Console.AddText("Value: "..tostring(DebugReturnValue), "\n")
  elseif type( DebugReturnValue ) == "string" then
    CE.Console.AddText("Value: ".."\""..DebugReturnValue.."\"", "\n")
  elseif type( DebugReturnValue ) == "function" then
    local funcinfo = debug.getinfo(DebugReturnValue)
    --linedefined, lastlinedefined, short_src
    if(funcinfo.short_src == '[C]') then
      CE.Console.AddText("C Function\n")
    else
      --local info = jit.util.funcinfo(DebugReturnValue)

      CE.Console.AddText(funcinfo.short_src, ":", funcinfo.linedefined, "(")
      if funcinfo.isvararg then
        CE.Console.AddText("...")
      elseif funcinfo.nparams ~= 0 then
        CE.Console.AddText("arg1")
        for i=2,funcinfo.nparams do
          CE.Console.AddText(", arg", i)
          i = i + 1
        end
      end
      CE.Console.AddText(")\n")
    end
  elseif type( DebugReturnValue ) == "thread" then
    CE.Console.AddText(tostring(DebugReturnValue), "\n")
  else
    local MT
    if type( DebugReturnValue ) == "table" then
      MT = getmetatable(DebugReturnValue)
      table.print(DebugReturnValue)
    else
      MT = GetFullMetaTable(DebugReturnValue)
      table.print(MT)
    end
    if MT and MT.__tostring then
      CE.Console.AddText("tostring: "..tostring(DebugReturnValue), "\n")
    end
  end
end
local function tryDebugger(calling_ply,command,arguments, args)
  local status, err = pcall(debugger, calling_ply,command,arguments, args)
  if(not status) then
    if CE.LogError then
      CE.LogError(err)
    else
      print(err)
    end
  end
end
local addTo
--Put three options in the autocomplete list - Red, green, and blue.
local function getAutoCompleteOptions(commandName,args)
  local current = string.join("", args):sub(2)
  if current == "" then
    return CE.Session.DebugHistory
  else
    local options = { }
    local globals = _G
    local validOptions = { }

    CE.RevealGlobal() -- make CE show in autocomplete
    options = addTo(options, "", _G, -1, current)
    CE.HideGlobal()
    if(options ~= nil) then
      for key,val in pairs(options) do
        if(val:starts(current)) then
          table.insert(validOptions, commandName.." "..val)
        end
      end
    end
    table.sort(validOptions, function(a, b) return a < b end)
    return validOptions
  end
end
function addTo(options, evaluateCode, value, depth, target, parent)
  if(evaluateCode:ends("_M") or #options >= 128 or target == "" or value == nil or depth > 5  or not (evaluateCode:starts(target) or target:starts(evaluateCode))) then
    return
  end
  if type( value ) == "nil" or type( value ) == "boolean" or type( value ) == "number" or type( value ) == "string" or type( value ) == "thread" then
    if evaluateCode:starts(target) then
      table.insert(options, evaluateCode)
    end
  elseif type( value ) == "function" then
    --print("Checking for "..tostring(parent)..":"..evaluateCode.."()")
    --print("Calling "..tostring(parent)..":"..evaluateCode.."()")
    if(target:starts(evaluateCode.."()")) then -- flipped? why?
      local status,val = pcall(value, parent)
      if status then
        addTo(options, evaluateCode.."()", val, depth+1, target)
      end
    else
      if (evaluateCode.."("):starts(target) then
        table.insert(options, (evaluateCode.."("))
      end
    end
  elseif type( value ) == "table" then
    if evaluateCode:starts(target) then
      table.insert(options, evaluateCode)
    end
    if(evaluateCode == "") then
      for tname,tvalue in pairs(value) do
        if not table.containsValue(options, tvalue) then
          addTo(options, tname, tvalue, depth+1, target)
        end
      end
    else
      for tname,tvalue in pairs(value) do
        if not table.containsValue(options, tvalue) and tname ~= "_M" then
          if (type(tname) == "string" and not tname:find("%.") and not tname:find("%[") and not tname:find(" ") and not tname:find("]") and not tname:find("%(") and not tname:find("%)")) then
            --if (evaluateCode.."."..tostring(tname)):starts(target) then
            --table.insert(options, evaluateCode.."."..tostring(tname))
            addTo(options, evaluateCode.."."..tostring(tname), tvalue, depth+1, target)
            --end
            if(type(tvalue) == "function") then
              table.insert(options, evaluateCode.."."..tostring(tname))
              addTo(options, evaluateCode..":"..tostring(tname), tvalue, depth+1, target, value)
            end
          elseif (type(tname) == "string") then
            addTo(options, evaluateCode.."['"..tostring(tname).."']", tvalue, depth+1, target)
          elseif (type(tname) == "number") then
            if (evaluateCode.."["..tostring(tname).."]"):starts(target) then
              addTo(options, evaluateCode.."["..tostring(tname).."]", tvalue, depth+1, target)
              --table.insert(options, evaluateCode.."["..tostring(tname).."]")
            end
          end
        end
      end
    end
  else
    local tbl = GetFullMetaTable(value)
    for tname,tvalue in CE.PairsByKeys(tbl) do
      if(type(tname) == "string") then
        addTo(options, evaluateCode.."."..tostring(tname), tvalue, depth+1, target)
        if(type(tvalue) == "function") then
          addTo(options, evaluateCode..":"..tostring(tname), tvalue, depth+1, target, value)
        end
      elseif(type(tname) == "number") then
        addTo(options, evaluateCode.."["..tostring(tname).."]", tvalue, depth+1, target)
      end
    end
  end
  return options
end
function CE.LuaDebugger(var)
  _G['debugtmp'] = var
  --PrintTable(CE)
  debugger(LocalPlayer and LocalPlayer() or nil, "hacks_lua", { "debugtmp" }, "debugtmp")
  _G['debugtmp'] = nil
end
if MODULE == nil then
  if MENU_DLL then
    concommand.Add("hacks_lua_menu", tryDebugger, getAutoCompleteOptions)
    print("Debug module loaded in menu lua")
  else
    concommand.Add("hacks_luai", tryDebugger, getAutoCompleteOptions)
    print("Debug module loaded in semi-client lua")
  end
else
  MODULE.cmds = { { name="hacks_lua", nick="Debug", func=debugger, autocomplete=getAutoCompleteOptions },
    {name="lua", nick="Lua", func=debugger} }
end