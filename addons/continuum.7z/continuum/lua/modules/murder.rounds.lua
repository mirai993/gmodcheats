MODULE.ID = "com.continuum.murder.rounds"
MODULE.Name = "Murder Rounds"
MODULE.Dependencies = { "com.continuum.modulemods" }
net.Receive("SetRound", function (length)
  local r = net._ReadUInt(8)
  print(r)
  local start = net._ReadDouble()
  print(start)
  GAMEMODE.RoundStage = r
  GAMEMODE.RoundStart = start

  GAMEMODE.RoundSettings = {}
  local settings = net._ReadUInt(8)
  if settings ~= 0 then
    GAMEMODE.RoundSettings.ShowAdminsOnScoreboard = net.ReadUInt(8) ~= 0
    GAMEMODE.RoundSettings.AdminPanelAllowed = true--net.ReadUInt(8) ~= 0
    GAMEMODE.RoundSettings.ShowSpectateInfo = net.ReadUInt(8) ~= 0
  end

  if r == 1 then
    for k,v in pairs(player.GetAll()) do
      v.MurderStatus = 0
    end
    timer.Simple(0.2, function ()
      for k,v in pairs(player.GetAll()) do
        v.MurderStatus = 0
      end
      local pitch = math.random(70, 140)
      if IsValid(LocalPlayer()) then
        LocalPlayer():EmitSound("ambient/creatures/town_child_scream1.wav", 100, pitch)
      end
    end)
    GAMEMODE.LootCollected = 0
  end
end)