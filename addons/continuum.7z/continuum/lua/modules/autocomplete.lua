local CE = CE

MODULE.Enabled = true
MODULE.ID = "com.continuum.modelcomplete"
MODULE.Dependencies = { }

MODULE.Name="Model Autocomplete Spawner"
MODULE.Info="Spawns props by model name on enabled servers and autocompletes paths"
MODULE.Init = function(CE)
  MODULE.AddCmd({
  	name="hacks_spawn",
  	nick="Spawn",
  	func=function(ply, cmd, args)
  		if #args == 0 then print("Command requires one argument") end
  		local path = args[1]
  		path = "models/" .. string.Trim( path )
  		RunConsoleCommand("gm_spawn", path)
  	end,
  	autocomplete = function(cmd, args)
  		local targs = string.Trim( args )
  		local fileList = {}
  		local relpath = targs:GetPathFromFilename()
  		local files, folders = file.Find( "models/"..relpath .. "*", "GAME" )
  		folders = folders or { }
  		files = files or { }
  		for _, File in ipairs( folders ) do
  			if targs:len() == 0 or (relpath .. File):sub( 1, targs:len() ) == targs then
  				table.insert( fileList, cmd.." "..relpath .. File.."/" )
  			end
  		end
  		for _, File in ipairs( files ) do
  			if targs:len() == 0 or (relpath .. File):sub( 1, targs:len() ) == targs and File:ends(".mdl") then
  				table.insert( fileList, cmd.." "..relpath .. File .. "" )
  			end
  		end
  		return fileList
  	end})
  MODULE.AddCmd({
  	name="hacks_material",
  	nick="Material",
  	func=function(ply, cmd, args)
  		if #args == 0 then print("Command requires one argument") end
  		local material = string.Trim(args[1])
  		RunConsoleCommand("material_override", material)
  		RunConsoleCommand("gmod_toolmode", "material")
  	end,
  	autocomplete = function(cmd, args)
  		local targs = string.Trim( args )
  		local materialList = { }
  		local materialArray = { }
  		for _,material in pairs(list.Get("OverrideMaterials")) do
  			local IsRepeat = materialArray[material] ~= nil
  			local IsMatch = targs:len() == 0 or (targs:len() <= material:len() and material:sub(1, targs:len()) == targs)
  			if not IsRepeat and IsMatch then
  				table.insert(materialList, #materialList+1, cmd.." "..material)
  				materialArray[material] = true
  			end
  		end
  		return materialList
  	end
  })
  concommand.Add("+pickup", function()
  	RunConsoleCommand("+walk")
  	RunConsoleCommand("+use")
  end)
  concommand.Add("-pickup", function()
  	RunConsoleCommand("-walk")
  	RunConsoleCommand("-use")
  end)
end