MODULE.ID = "com.continuum.buddies"
MODULE.Dependencies = { }

MODULE.Name = "Buddies"
MODULE.Info = "System for adding buddies to not kill"
MODULE.cvars = { { name="hacks_buddies_minrank",nick="Buddy Min Ranking", info="Sets the minimum buddy rank needed for a player to be ignored by your aimbot", default=1, NoToggle=true, HUD={ Category="Misc", Type="Slider", Min=-25, Max=25}} }
MODULE.Init = function(CE)
MODULE.AddCmd({name="hacks_buddies_set",nick="Buddies Add", info="Sets the buddy ranking of a player (default 0)",
  func = function(ply,name,args)
    if #args ~= 2 and #args ~= 1 then
      print("All buddy ranks reset to -1")
      CE.SetPersistant("buddyRanks", { })
      return
    end
    local plys = CE.AutocompletePlayers(args[1], true)
    local rank = #args >= 2 and tonumber(args[2]) or nil
    if plys then
      local buddyRanks = CE.GetPersistant("buddyRanks", { })
      for _,ply in CE.PairsByKeys(plys) do
        if rank then
          buddyRanks[ply:SteamID()]=rank
          local color = buddyRanks[ply:SteamID()] >= GetConVarNumber("hacks_buddies_minrank") and CE.Colors.GREEN or CE.Colors.RED
          CE.Console.AddText(color, "Set "..ply:Nick().." ["..ply:SteamID().."]'s to Rank "..tostring(rank), "\n")
        else
          local color = buddyRanks[ply:SteamID()] >= GetConVarNumber("hacks_buddies_minrank") and CE.Colors.GREEN or CE.Colors.RED
          CE.Console.AddText(color, ply:Nick(),"'s Rank is ",tostring(buddyRanks[ply:SteamID()] or -1), "\n")
        end
      end
      CE.SetPersistant("buddyRanks", buddyRanks)
    else
      CE.Console.AddText("No players found matching \""..args[1].."\"!\n")
    end
  end,
  autocomplete = function(name,args)
    args = args:sub(2)
    local argstr = args
    if args:ends(" ") then
      args = string.split(args, " ")
      args[#args+1]=""
    else
      args = string.split(args, " ")
    end
    local res = { }
    local str = name.." "
    args[1] = args[1] or ""
    if #args <= 1 then
      local plys = CE.AutocompletePlayers(args[1], true)
      if plys then
        for _,val in CE.PairsByKeys(plys) do
          table.insert(res, str.."\""..val:Nick().."\"")
        end
      end
    else
      str = str.."("..args[1]..") [rank]"
      res = { str }
    end
    return res
  end})
end