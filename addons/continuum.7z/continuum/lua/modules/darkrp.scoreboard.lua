MODULE.ID = "com.continuum.drp.scoreboard"
MODULE.Dependencies = { }

MODULE.Name="Scoreboard"
MODULE.Info="Adds columns to scoreboard"

MODULE.Init = function(CE)
  local Data = { }
  Data.ScoreBoard = {}
  
  local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  
  Data.ScoreBoard.X = ScreenWidth * 0.05
  Data.ScoreBoard.Y = ScreenHeight * 0.025
  Data.ScoreBoard.Width = ScreenWidth * 0.9
  Data.ScoreBoard.Height = ScreenHeight * 0.95
  
  Data.ScoreBoard.Controls = {}
  Data.ScoreBoard.CurrentView = "Main"
  
  Data.ScoreBoard.Main = {}
  Data.ScoreBoard.Main.Controls = {}
  Data.ScoreBoard.Main.Logo = "gui/gmod_logo"
  
  Data.ScoreBoard.Player = {}
  Data.ScoreBoard.Player.Controls = {}
  Data.ScoreBoard.Player.Player = NULL
  Data.ScoreBoard.Player.Logo = "Data/back"
  
  Data.ScoreBoard.Server = {}
  Data.ScoreBoard.Server.Controls = {}
  Data.ScoreBoard.Server.Logo = "Data/back"
  
  local Sorted, SortDown = CreateClientConVar("Data_SortPlayerList", "Team", true), CreateClientConVar("Data_SortPlayerListDown", 1, true)
  local allowedSorts = {
  	["Name"] = true,
  	["Team"] = true,
  	["Ping"] = true,
  	["Group"] = true,
  	["Money"] = true
  }
  
  function Data.ScoreBoard.Main.Show()
  	local Sort = {}
  	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  
  	Data.ScoreBoard.X = ScreenWidth*0.05
  	Data.ScoreBoard.Y = ScreenHeight*0.025
  	Data.ScoreBoard.Width = ScreenWidth*0.9
  	Data.ScoreBoard.Height = ScreenHeight*0.95
  
  	Data.ScoreBoard.ChangeView("Main")
  
  	Data.ScoreBoard.Main.Controls.DataPanelList = Data.ScoreBoard.Main.Controls.DataPanelList or vgui.Create("DPanelList")
  	Data.ScoreBoard.Main.Controls.DataPanelList:SetVisible(true)
  	Data.ScoreBoard.Main.Controls.DataPanelList:Clear(true)
  	Data.ScoreBoard.Main.Controls.DataPanelList.Padding = 3
  	Data.ScoreBoard.Main.Controls.DataPanelList:EnableVerticalScrollbar(true)
  
  
  	Data.ScoreBoard.Main.Controls.DataPanelList:Clear(true)
  
  	Data.ScoreBoard.Main.Controls.DataPanelList:SetPos(Data.ScoreBoard.X + 20, Data.ScoreBoard.Y + 90 + 30 + 20)
  	Data.ScoreBoard.Main.Controls.DataPanelList:SetSize(Data.ScoreBoard.Width - 40, Data.ScoreBoard.Height - 90 - 30 - 20 - 20)
  
  	Sort.Name = Sort.Name or vgui.Create("DLabel")
  	Sort.Name:SetText("Sort by:     Name")
  	Sort.Name:SetPos(Data.ScoreBoard.X + 20, Data.ScoreBoard.Y + 90 + 30)
  	Sort.Name.Type = "Name"
  	Sort.Name:SetVisible(true)
  
  	Sort.Team = Sort.Team or vgui.Create("DLabel")
  	Sort.Team:SetText("Team")
  	Sort.Team:SetPos(ScreenWidth * 0.5 - 30, Data.ScoreBoard.Y + 90 + 30)
  	Sort.Team.Type = "Team"
  	Sort.Team:SetVisible(true)
  
  	Sort.Group = Sort.Group or vgui.Create("DLabel")
  	Sort.Group:SetText("Group")
  	Sort.Group:SetPos(Data.ScoreBoard.X + Data.ScoreBoard.Main.Controls.DataPanelList:GetWide() - 275,  Data.ScoreBoard.Y + 90 + 30)
  	Sort.Group.Type = "Group"
  	Sort.Group:SetVisible(true)
  
  	Sort.Money = Sort.Money or vgui.Create("DLabel")
  	Sort.Money:SetText("Money")
  	Sort.Money:SetPos(Data.ScoreBoard.X + Data.ScoreBoard.Main.Controls.DataPanelList:GetWide() - 140, Data.ScoreBoard.Y + 90 + 30)
  	Sort.Money.Type = "Money"
  	Sort.Money:SetVisible(true)
  
  	Sort.Ping = Sort.Ping or vgui.Create("DLabel")
  	Sort.Ping:SetText("Ping")
  	Sort.Ping:SetPos(Data.ScoreBoard.X + Data.ScoreBoard.Main.Controls.DataPanelList:GetWide() - 50, Data.ScoreBoard.Y + 90 + 30)
  	Sort.Ping.Type = "Ping"
  	Sort.Ping:SetVisible(true)
  
  	local sortBy = Sorted:GetString()
  	sortBy = allowedSorts[sortBy] and sortBy or "Team"
  
  	Data.ScoreBoard.Main.PlayerListView(sortBy, SortDown:GetBool())
  
  	for k,v in pairs(Sort) do
  		v:SetFont("Trebuchet20")
  		v:SizeToContents()
  
  		local X, Y = v:GetPos()
  
  		v.BtnSort = vgui.Create("DButton")
  		v.BtnSort:SetText("")
  		v.BtnSort.Type = "Down"
  		v.BtnSort.Paint = function( panel, w, h ) derma.SkinHook("Paint", "ButtonDown", panel, w, h ) end
  		v.BtnSort:SetSkin(GAMEMODE.Config.DarkRPSkin)
  		if Sorted:GetString() == v.Type then
  			v.BtnSort.Depressed = true
  			v.BtnSort.Type = (SortDown:GetBool() and "Down") or "Up"
  		end
  		v.BtnSort:SetSize(16, 16)
  		v.BtnSort:SetPos(X + v:GetWide() + 5, Y + 4)
  		function v.BtnSort.DoClick()
  			for a,b in pairs(Sort) do
  				b.BtnSort.Depressed = (b.BtnSort == v.BtnSort)
  			end
  			v.BtnSort.Type = (v.BtnSort.Type == "Down" and "Up") or "Down"
  			v.BtnSort.Paint = function( panel, w, h ) derma.SkinHook("Paint", "Button"..v.BtnSort.Type, panel, w, h ) end
  
  			RunConsoleCommand("Data_SortPlayerList", v.Type)
  			RunConsoleCommand("Data_SortPlayerListDown", (v.BtnSort.Type == "Down" and "1") or "0")
  			Data.ScoreBoard.Main.Controls.DataPanelList:Clear(true)
  			Data.ScoreBoard.Main.PlayerListView(v.Type, v.BtnSort.Type == "Down")
  		end
  		table.insert(Data.ScoreBoard.Main.Controls, v) -- Add them to the table so they get removed when you close the scoreboard
  		table.insert(Data.ScoreBoard.Main.Controls, v.BtnSort)
  	end
  end
  
  function Data.ScoreBoard.Main.AddPlayerRightClick(Name, func)
  	Data.PlayerIcon.RightClickOptions[Name] = func
  end
  
  local function ScoreboardAddTeam(Name, color)
  	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  
  	local cat = Data.ScoreBoard.Main.Controls.DataPanelList:Add("DataPlayerCatagory")
  	cat:SetLabel("  "..Name)
  	cat.CatagoryColor = color
  	cat:SetWide((Data.ScoreBoard.Width - 40)/2)
  
  	function cat:Toggle()
  	end
  
  	local pan = vgui.Create("DataPanelList")
  	pan:SizeToContents()
  
  	cat:SetContents(pan)
  
  	return cat, pan
  end
  
  local function SortedPairsByFunction(Table, Sorted, SortDown)
  	local CopyTable = {}
  	for k,v in pairs(Table) do
  		table.insert(CopyTable, {NAME = tostring(v:Nick()), PLY = v})
  	end
  	table.SortByMember(CopyTable, "NAME", SortDown)
  
  	local SortedTable = {}
  	for k,v in ipairs(CopyTable) do
  		if IsValid(v.PLY) and v.PLY[Sorted] then
  			local SortBy = (Sorted ~= "Team" and v.PLY[Sorted](v.PLY)) or team.GetName(v.PLY[Sorted](v.PLY))
  			SortedTable[SortBy] = SortedTable[SortBy] or {}
  			table.insert(SortedTable[SortBy], v.PLY)
  		end
  	end
  
  	local SecondSort = {}
  	for k,v in SortedPairs(SortedTable, SortDown) do
  		table.insert(SecondSort, v)
  	end
  
  	CopyTable = {}
  	for k,v in pairs(SecondSort) do
  		for a,b in pairs(v) do
  			table.insert(CopyTable, b)
  		end
  	end
  
  	return ipairs(CopyTable)
  end
  
  function Data.ScoreBoard.Main.PlayerListView(Sorted, SortDown)
  	Data.ScoreBoard.Main.Controls.DataPanelList:Clear(true)
  	if Sorted == "Group" then Sorted = "GetUserGroup" end
  	if Sorted == "Money" then Sorted = "GetMoney" end
  	for k, ply in SortedPairsByFunction(player.GetAll(), Sorted, SortDown) do
  		local Row = vgui.Create("DataPlayerRow")
  		Row:SetPlayer(ply)
  		Row:Dock(TOP)
  		Row:InvalidateLayout()
  
  		Data.ScoreBoard.Main.Controls.DataPanelList:AddItem(Row)
  	end
  end
  
  
  Data.PlayerIcon = {}
  Data.PlayerIcon.RightClickOptions = {}
  
  function Data.PlayerIcon.AddRightClickOption(name, func)
  	Data.PlayerIcon.RightClickOptions[name] = func
  end
  -- Data player row (from the sandbox player row)
  PANEL = {}
  
  CreateClientConVar("Data_PlayerRowSize", 30, true, false)
  function PANEL:Init()
  	self.Size = GetConVarNumber("Data_PlayerRowSize")
  
  	self.lblName 	= vgui.Create("DLabel", self)
  	self.lblGroup 	= vgui.Create("DLabel", self)
  	self.lblTeam	= vgui.Create("DLabel", self)
  	self.lblMoney 	= vgui.Create("DLabel", self)
  	self.lblPing 	= vgui.Create("DLabel", self)
  
  	-- If you don't do this it'll block your clicks
  	self.lblName:SetMouseInputEnabled(false)
  	self.lblTeam:SetMouseInputEnabled(false)
  	self.lblGroup:SetMouseInputEnabled(false)
  	self.lblMoney:SetMouseInputEnabled(false)
  	self.lblPing:SetMouseInputEnabled(false)
  
  	self.lblName:SetColor(Color(255,255,255,200))
  	self.lblTeam:SetColor(Color(255,255,255,200))
  	self.lblGroup:SetColor(Color(255,255,255,200))
  	self.lblMoney:SetColor(Color(255,255,255,200))
  	self.lblPing:SetColor(Color(255,255,255,200))
  
  	self.imgAvatar = vgui.Create("AvatarImage", self)
  
  	self:SetCursor("hand")
  end
  
  function PANEL:Paint()
  	if not IsValid(self.Player) then return end
  
  	self.Size = GetConVarNumber("Data_PlayerRowSize")
  	self.imgAvatar:SetSize(self.Size - 4, self.Size - 4)
  
  	local color = Color(100, 150, 245, 255)
  
  
  	if GAMEMODE.Name == "Sandbox" then
  		color = Color(100, 150, 245, 255)
  		if self.Player:Team() == TEAM_CONNECTING then
  			color = Color(200, 120, 50, 255)
  		elseif self.Player:IsAdmin() then
  			color = Color(30, 200, 50, 255)
  		end
    self.Player.FriendStatus = self.Player.FriendStatus or self.Player:GetFriendStatus()
  
  		if self.Player.FriendStatus == "friend" then
  			color = Color(236, 181, 113, 255)
  		end
  	else
  		color = team.GetColor(self.Player:Team())
  	end
  
  	local hooks = hook.GetTable().Data_PlayerRowColour
  	if hooks then
  		for k,v in pairs(hooks) do
  			color = (v and v(self.Player, color)) or color
  			break
  		end
  	end
  
  	draw.RoundedBox(4, 0, 0, self:GetWide(), self.Size, color)
  
  	surface.SetTexture(0)
    self.Player.FriendStatus = self.Player.FriendStatus or self.Player:GetFriendStatus()
  	if self.Player == LocalPlayer() or self.Player.FriendStatus == "friend" then
  		surface.SetDrawColor(255, 255, 255, 50 + math.sin(RealTime() * 2) * 50)
  	end
  	surface.DrawTexturedRect(0, 0, self:GetWide(), self.Size)
  	return true
  end
  
  function PANEL:SetPlayer(ply)
  	self.Player = ply
  
  	self.imgAvatar:SetPlayer(ply)
  
  	self:UpdatePlayerData()
  end
  
  function PANEL:UpdatePlayerData()
  	if not self.Player then return end
  	if not self.Player:IsValid() then return end
  
  	self.lblName:SetText(self.Player:Nick())
  	self.lblTeam:SetText((self.Player.getDarkRPVar and self.Player:getDarkRPVar("job")) or team.GetName(self.Player:Team()))
  	self.lblTeam:SizeToContents()
  	self.lblGroup:SetText(self.Player:GetUserGroup())
  	self.lblMoney:SetText(tostring(self.Player:GetMoney()):FormatMoney())
  	self.lblPing:SetText(self.Player:Ping())
  end
  
  function PANEL:ApplySchemeSettings()
  	self.lblName:SetFont("ScoreboardPlayerNameBig")
  	self.lblTeam:SetFont("ScoreboardPlayerNameBig")
  	self.lblGroup:SetFont("ScoreboardPlayerNameBig")
  	self.lblMoney:SetFont("ScoreboardPlayerNameBig")
  	self.lblPing:SetFont("ScoreboardPlayerName")
  
  	self.lblName:SetFGColor(color_white)
  	self.lblTeam:SetFGColor(color_white)
  	self.lblGroup:SetFGColor(color_white)
  	self.lblMoney:SetFGColor(color_white)
  	self.lblPing:SetFGColor(color_white)
  end
  
  function PANEL:DoClick(x, y)
  	if not IsValid(self.Player) then self:Remove() return end
  	Data.ScoreBoard.ChangeView("Player", self.Player)
  end
  
  function PANEL:DoRightClick()
  	if table.Count(Data.PlayerIcon.RightClickOptions) < 1 then return end
  	local menu = DermaMenu()
  
  	menu:SetPos(gui.MouseX(), gui.MouseY())
  
  	for Name, func in pairs(Data.PlayerIcon.RightClickOptions) do
  		menu:AddOption(Name, function() func(self.Player, self) end)
  	end
  
  	menu:Open()
  end
  
  function PANEL:Think()
  	if not self.PlayerUpdate or self.PlayerUpdate < CurTime() then
  		self.PlayerUpdate = CurTime() + 0.5
  		self:UpdatePlayerData()
  	end
  end
  
  function PANEL:PerformLayout()
  	self.imgAvatar:SetPos(2, 2)
  	self.imgAvatar:SetSize(32, 32)
  
  	self:SetSize(self:GetWide(), self.Size)
  
  	self.lblName:SizeToContents()
  	self.lblName:SetPos(24, 2)
  	self.lblName:MoveRightOf(self.imgAvatar, 8)
  
  	local COLUMN_SIZE = 75
  
  	self.lblPing:SetPos(self:GetWide() - COLUMN_SIZE * 0.4, 0)
  	self.lblMoney:SizeToContents()
  	self.lblMoney:SetPos(self:GetWide() - COLUMN_SIZE * 2, 0)
  	self.lblGroup:SizeToContents()
  	self.lblGroup:SetPos(self:GetWide() - COLUMN_SIZE * 3.75, 0)
  
  	self.lblTeam:SetPos(self:GetWide() / 2 - (0.5*self.lblTeam:GetWide()))
  end
  vgui.Register("DataPlayerRow", PANEL, "Button")
  
  CreateClientConVar("Data_IsScoreboard", 1, true, false) -- Set if it's a scoreboard or not
  
  function Data.ScoreBoard.ChangeView(newView, ...)
  	if Data.ScoreBoard.CurrentView == newView then return end
  	for k,v in pairs(Data.ScoreBoard[Data.ScoreBoard.CurrentView].Controls) do
  		v:SetVisible(false)
  	end
  
  	Data.ScoreBoard.CurrentView = newView
  	Data.ScoreBoard[newView].Show(...)
  	Data.ScoreBoard.ChangeGmodLogo(Data.ScoreBoard[newView].Logo)
  
  	Data.ScoreBoard.Controls.BackButton = Data.ScoreBoard.Controls.BackButton or vgui.Create("DButton")
  	Data.ScoreBoard.Controls.BackButton:SetVisible(true)
  	Data.ScoreBoard.Controls.BackButton:SetPos(Data.ScoreBoard.X, Data.ScoreBoard.Y)
  	Data.ScoreBoard.Controls.BackButton:SetText("")
  	Data.ScoreBoard.Controls.BackButton:SetToolTip("Click me to go back!")
  	Data.ScoreBoard.Controls.BackButton:SetCursor("hand")
  	Data.ScoreBoard.Controls.BackButton:SetSize(100,90)
  	Data.ScoreBoard.Controls.BackButton:SetZPos(999)
  
  	function Data.ScoreBoard.Controls.BackButton:DoClick()
  		Data.ScoreBoard.ChangeView("Main")
  	end
  	Data.ScoreBoard.Controls.BackButton.Paint = function()end
  end
  
  local GmodLogo, TempGmodLogo, GmodLogoColor = surface.GetTextureID("gui/gmod_logo"), surface.GetTextureID("gui/gmod_logo"), Color(255,255,255,255)--"Data/back", gui/gmod_tool
  function Data.ScoreBoard.ChangeGmodLogo(new)
  	if surface.GetTextureID(new) == TempGmodLogo then return end
  	TempGmodLogo = surface.GetTextureID(new)
  	for i = 0, 0.5, 0.01 do
  		timer.Simple(i, function() GmodLogoColor = Color(255,255,255,GmodLogoColor.a-5.1) end)
  	end
  	timer.Simple(0.5, function() GmodLogo = surface.GetTextureID(new) end)
  	for i = 0.5, 1, 0.01 do
  		timer.Simple(i, function() GmodLogoColor = Color(255,255,255,GmodLogoColor.a+5.1) end)
  	end
  end
  
  function Data.ScoreBoard.Background()
  	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  
  	surface.SetDrawColor(0,0,0,200)
  	surface.DrawRect(Data.ScoreBoard.X, Data.ScoreBoard.Y, Data.ScoreBoard.Width, Data.ScoreBoard.Height)
  
  	surface.SetTexture(GmodLogo)
  	surface.SetDrawColor(255,255,255,GmodLogoColor.a)
  	surface.DrawTexturedRect(Data.ScoreBoard.X - 20, Data.ScoreBoard.Y, 128, 128)
  end
  
  
  function Data.ScoreBoard.DrawScoreBoard()
  	if (input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)) and not Data.ScoreBoard.DontGoBack then
  		Data.ScoreBoard.ChangeView("Main")
  	elseif Data.ScoreBoard.DontGoBack then
  		Data.ScoreBoard.DontGoBack = input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)
  	end
  	Data.ScoreBoard.Background()
  end
  
  function Data.ScoreBoard.ShowScoreBoard()
  	Data.ScoreBoard.Visible = true
  	Data.ScoreBoard.DontGoBack = input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)
  	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  
  	Data.ScoreBoard.Controls.Hostname = Data.ScoreBoard.Controls.Hostname or vgui.Create("DLabel", self )
  	Data.ScoreBoard.Controls.Hostname:SetText(GetHostName())
  	Data.ScoreBoard.Controls.Hostname:SetFont("ScoreboardHeader")
  	Data.ScoreBoard.Controls.Hostname:SetColor(Color(200,200,200,200))
  	Data.ScoreBoard.Controls.Hostname:SetPos(Data.ScoreBoard.X + 90, Data.ScoreBoard.Y + 20)
  	Data.ScoreBoard.Controls.Hostname:SizeToContents()
  	Data.ScoreBoard.Controls.Hostname:SetVisible(true)
  
  	Data.ScoreBoard.Controls.Description = Data.ScoreBoard.Controls.Description or vgui.Create("DLabel")
  	Data.ScoreBoard.Controls.Description:SetText("Continuum Engine")
  	Data.ScoreBoard.Controls.Description:SetFont("ScoreboardSubtitle")
  	Data.ScoreBoard.Controls.Description:SetColor(CE.Colors.Continuum)
  	Data.ScoreBoard.Controls.Description:SetPos(Data.ScoreBoard.X + 90, Data.ScoreBoard.Y + 50)
  	Data.ScoreBoard.Controls.Description:SizeToContents()
  	if Data.ScoreBoard.X + Data.ScoreBoard.Width / 9.5 + Data.ScoreBoard.Controls.Description:GetWide() > Data.ScoreBoard.Width - 150 then
  		Data.ScoreBoard.Controls.Description:SetFont("Trebuchet18")
  		Data.ScoreBoard.Controls.Description:SetPos(Data.ScoreBoard.X + 90, Data.ScoreBoard.Y + 50)
  	end
  	Data.ScoreBoard.Controls.Description:SetVisible(true)
  
  	if Data.ScoreBoard.Controls.BackButton then Data.ScoreBoard.Controls.BackButton:SetVisible(true) end
  
  	Data.ScoreBoard[Data.ScoreBoard.CurrentView].Show()
  
  	gui.EnableScreenClicker(true)
  	hook.Add("HUDPaint", "Data_ScoreBoard", Data.ScoreBoard.DrawScoreBoard)
  	return true
  end
  concommand.Add("+Data_menu", Data.ScoreBoard.ShowScoreBoard)
  
  hook.Add("ScoreboardShow", "Data_scoreboard", function()
  	return Data.ScoreBoard.ShowScoreBoard()
  end)
  
  function Data.ScoreBoard.HideScoreBoard()
  	Data.ScoreBoard.Visible = false
  	CloseDermaMenus()
  
  	gui.EnableScreenClicker(false)
  	hook.Remove("HUDPaint", "Data_ScoreBoard")
  
  	for k,v in pairs(Data.ScoreBoard[Data.ScoreBoard.CurrentView].Controls) do
  		v:SetVisible(false)
  	end
  
  	for k,v in pairs(Data.ScoreBoard.Controls) do
  		v:SetVisible(false)
  	end
  	return true
  end
  concommand.Add("-Data_menu", Data.ScoreBoard.HideScoreBoard)
  
  hook.Add("ScoreboardHide", "Data_scoreboard", function()
  	return Data.ScoreBoard.HideScoreBoard()
  end)
  
  Data.ScoreBoard.Player.Information = {}
  Data.ScoreBoard.Player.ActionButtons = {}
  
  function Data.ScoreBoard.Player.Show(ply)
  	local OldPly = Data.ScoreBoard.Player.Player
  	ply = ply or Data.ScoreBoard.Player.Player
  	Data.ScoreBoard.Player.Player = ply
  
  	if not IsValid(ply) or not IsValid(Data.ScoreBoard.Player.Player) then Data.ScoreBoard.ChangeView("Main") return end
  
  	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
  	local SteamID = ply:SteamID()
  
  	Data.ScoreBoard.Player.Controls.AvatarBackground = Data.ScoreBoard.Player.Controls.AvatarBackground or vgui.Create("AvatarImage")
  	Data.ScoreBoard.Player.Controls.AvatarBackground:SetPos(Data.ScoreBoard.X + 20, Data.ScoreBoard.Y + 100)
  	Data.ScoreBoard.Player.Controls.AvatarBackground:SetSize(184, 184)
  	Data.ScoreBoard.Player.Controls.AvatarBackground:SetPlayer(ply, 184)
  	Data.ScoreBoard.Player.Controls.AvatarBackground:SetVisible(true)
  
  	if Data.ScoreBoard.Player.Controls.AvatarLarge and Data.ScoreBoard.Player.Controls.AvatarLarge:IsValid() and Data.ScoreBoard.Player.Controls.AvatarLarge.Player == ply then
  		Data.ScoreBoard.Player.Controls.AvatarLarge:SetVisible(true)
  	end
  
  	Data.ScoreBoard.Player.InfoPanels = Data.ScoreBoard.Player.InfoPanels or {}
  	for k,v in pairs(Data.ScoreBoard.Player.InfoPanels) do
  		if ValidPanel(v) then
  			v:Remove()
  			Data.ScoreBoard.Player.InfoPanels[k] = nil
  		end
  	end
  
  	if ValidPanel(Data.ScoreBoard.Player.Controls.InfoPanel1) then
  		Data.ScoreBoard.Player.Controls.InfoPanel1:Remove()
  	end
  
  	Data.ScoreBoard.Player.Controls.InfoPanel1 = vgui.Create("DListLayout")
  	Data.ScoreBoard.Player.Controls.InfoPanel1:SetPos(Data.ScoreBoard.X + 20, Data.ScoreBoard.Y + 100 + 184 + 5 )
  	Data.ScoreBoard.Player.Controls.InfoPanel1:SetSize(184, ScreenHeight*0.1 + 2)
  	Data.ScoreBoard.Player.Controls.InfoPanel1:SetVisible(true)
  	Data.ScoreBoard.Player.Controls.InfoPanel1:Clear(true)
  
  	Data.ScoreBoard.Player.Controls.InfoPanel2 = Data.ScoreBoard.Player.Controls.InfoPanel2 or vgui.Create("DataPanelList")
  	Data.ScoreBoard.Player.Controls.InfoPanel2:SetPos(Data.ScoreBoard.X + 25 + 184, Data.ScoreBoard.Y + 100)
  	Data.ScoreBoard.Player.Controls.InfoPanel2:SetSize(Data.ScoreBoard.Width - 184 - 30 - 10, 184 + 5 + ScreenHeight*0.1 + 2)
  	Data.ScoreBoard.Player.Controls.InfoPanel2:SetVisible(true)
  	Data.ScoreBoard.Player.Controls.InfoPanel2:Clear(true)
  
  	local function AddInfoPanel()
  		local pan = Data.ScoreBoard.Player.Controls.InfoPanel2:Add("DListLayout")
  		pan:SetSize(1, Data.ScoreBoard.Player.Controls.InfoPanel2:GetTall())
  
  		table.insert(Data.ScoreBoard.Player.InfoPanels, pan)
  		return pan
  	end
  
  	local SelectedPanel = AddInfoPanel() -- Make first panel to put the first things in
  
  	for k, v in pairs(Data.ScoreBoard.Player.Information) do
  		SelectedPanel:Dock(LEFT)
  		local Value = v.func(Data.ScoreBoard.Player.Player)
  		--if not Value or Value == "" then return --[[ Value = "N/A" ]] end
  		if Value and Value ~= "" then
  
  			local Text = vgui.Create("DLabel")
  			Text:Dock(LEFT)
  			Text:SetFont("TabLarge")
  			Text:SetText(v.name .. ":  ".. Value)
  			Text:SizeToContents()
  			Text:SetColor(Color(200,200,200,200))
  			Text:SetToolTip("Click to copy "..v.name.." to clipboard")
  			Text:SetMouseInputEnabled(true)
  			function Text:OnMousePressed(mcode)
  				self:SetToolTip(v.name.." copied to clipboard!")
  				ChangeTooltip(self)
  				SetClipboardText(Value)
  				self:SetToolTip("Click to copy "..v.name.." to clipboard")
  			end
  
  			timer.Create("Data_Scoreboard_text_update_"..v.name, 1, 0, function()
  				if not IsValid(ply) or not IsValid(Data.ScoreBoard.Player.Player) or not ValidPanel(Text) then
  					timer.Destroy("Data_Scoreboard_text_update_"..v.name)
  					if Data.ScoreBoard.Visible and (not IsValid(ply) or not IsValid(Data.ScoreBoard.Player.Player)) then Data.ScoreBoard.ChangeView("Main") end
  					return
  				end
  				Value = v.func(Data.ScoreBoard.Player.Player)
  				if not Value or Value == "" then Value = "N/A" end
  				Text:SetText(v.name .. ":  "..Value)
  			end)
  
  			if (#Data.ScoreBoard.Player.Controls.InfoPanel1:GetChildren()*17 + 17) <= Data.ScoreBoard.Player.Controls.InfoPanel1:GetTall() and not v.NewPanel then
  				Data.ScoreBoard.Player.Controls.InfoPanel1:Add(Text)
  			else
  				if #SelectedPanel:GetChildren()*17 + 17 >= SelectedPanel:GetTall() or v.NewPanel then
  					SelectedPanel = AddInfoPanel() -- Add new panel if the last one is full
  				end
  				SelectedPanel:Add(Text)
  				if Text:GetWide() > SelectedPanel:GetWide() then
  					SelectedPanel:SetWide(Text:GetWide() + 40)
  				end
  			end
  		end
  	end
  
  	local CatColor = team.GetColor(ply:Team())
  	if GAMEMODE.Name == "Sandbox" then
  		CatColor = Color(100, 150, 245, 255)
  		if ply:Team() == TEAM_CONNECTING then
  			CatColor = Color(200, 120, 50, 255)
  		elseif ply:IsAdmin() then
  			CatColor = Color(30, 200, 50, 255)
  		end
  
      ply.FriendStatus = ply.FriendStatus or ply:GetFriendStatus()
  		if ply:GetFriendStatus() == "friend" then
  			CatColor = Color(236, 181, 113, 255)
  		end
  	end
  	Data.ScoreBoard.Player.Controls.ButtonCat = Data.ScoreBoard.Player.Controls.ButtonCat or vgui.Create("DataPlayerCatagory")
  	Data.ScoreBoard.Player.Controls.ButtonCat:SetLabel("  Player options!")
  	Data.ScoreBoard.Player.Controls.ButtonCat.CatagoryColor = CatColor
  	Data.ScoreBoard.Player.Controls.ButtonCat:SetSize(Data.ScoreBoard.Width - 40, 100)
  	Data.ScoreBoard.Player.Controls.ButtonCat:SetPos(Data.ScoreBoard.X + 20, Data.ScoreBoard.Y + 100 + Data.ScoreBoard.Player.Controls.InfoPanel2:GetTall() + 5)
  	Data.ScoreBoard.Player.Controls.ButtonCat:SetVisible(true)
  
  	function Data.ScoreBoard.Player.Controls.ButtonCat:Toggle()
  	end
  
  	Data.ScoreBoard.Player.Controls.ButtonPanel = Data.ScoreBoard.Player.Controls.ButtonPanel or vgui.Create("DataPanelList", Data.ScoreBoard.Player.Controls.ButtonCat)
  	Data.ScoreBoard.Player.Controls.ButtonPanel:SetSpacing(5)
  	Data.ScoreBoard.Player.Controls.ButtonPanel:EnableHorizontal(true)
  	Data.ScoreBoard.Player.Controls.ButtonPanel:EnableVerticalScrollbar(true)
  	Data.ScoreBoard.Player.Controls.ButtonPanel:SizeToContents()
  	Data.ScoreBoard.Player.Controls.ButtonPanel:SetVisible(true)
  	Data.ScoreBoard.Player.Controls.ButtonPanel:SetSize(0, (ScreenHeight - Data.ScoreBoard.Y - 40) - (Data.ScoreBoard.Y + 100 + Data.ScoreBoard.Player.Controls.InfoPanel2:GetTall() + 5))
  	Data.ScoreBoard.Player.Controls.ButtonPanel:Clear()
  	Data.ScoreBoard.Player.Controls.ButtonPanel:DockMargin(5, 5, 5, 5)
  
  
  	for k,v in ipairs(Data.ScoreBoard.Player.ActionButtons) do
  		if v.Visible == true or (type(v.Visible) == "function" and v.Visible(Data.ScoreBoard.Player.Player) == true) then
  			local ActionButton = vgui.Create("DataActionButton")
  			if type(v.Image) == "string" then
  				ActionButton:SetImage(v.Image or "icon16/exclamation")
  			elseif type(v.Image) == "table" then
  				ActionButton:SetImage(v.Image[1])
  				if v.Image[2] then ActionButton:SetImage2(v.Image[2]) end
  			elseif type(v.Image) == "function" then
  				local img1, img2 = v.Image(ply)
  				ActionButton:SetImage(img1)
  				if img2 then ActionButton:SetImage2(img2) end
  			else
  				ActionButton:SetImage("icon16/exclamation")
  			end
  			local name = v.Name
  			if type(name) == "function" then name = name(Data.ScoreBoard.Player.Player) end
  			ActionButton:SetText(name)
  			ActionButton:SetBorderColor(v.color)
  
  			function ActionButton:DoClick()
  				return v.Action(Data.ScoreBoard.Player.Player, self)
  			end
  			Data.ScoreBoard.Player.Controls.ButtonPanel:AddItem(ActionButton)
  			if v.OnButtonCreated then
  				v.OnButtonCreated(Data.ScoreBoard.Player.Player, ActionButton)
  			end
  		end
  	end
  	Data.ScoreBoard.Player.Controls.ButtonPanel:Dock(TOP)
  end
  
  function Data.ScoreBoard.Player:AddInformation(name, func, ForceNewPanel) -- ForeNewPanel is to start a new column
  	table.insert(Data.ScoreBoard.Player.Information, {name = name, func = func, NewPanel = ForceNewPanel})
  end
  
  function Data.ScoreBoard.Player:AddActionButton(Name, Image, color, Visible, Action, OnButtonCreated)
  	table.insert(Data.ScoreBoard.Player.ActionButtons, {Name = Name, Image = Image, color = color, Visible = Visible, Action = Action, OnButtonCreated = OnButtonCreated})
  end
  
  Data.ScoreBoard.Player:AddInformation("Name", function(ply) return ply:Nick() end)
  Data.ScoreBoard.Player:AddInformation("SteamID", function(ply) return ply:SteamID() end)
  Data.ScoreBoard.Player:AddInformation("Kills", function(ply) return ply:Frags() end)
  Data.ScoreBoard.Player:AddInformation("Deaths", function(ply) return ply:Deaths() end)
  Data.ScoreBoard.Player:AddInformation("Health", function(ply) return ply:Health() end)
  Data.ScoreBoard.Player:AddInformation("Ping", function(ply) return ply:Ping() end)
end