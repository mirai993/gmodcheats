MODULE.ID = "com.continuum.dlights"
MODULE.Dependencies = { }

MODULE.Name = "Dynamic lights"
MODULE.Info = "Collection of various dynamic light mods"

MODULE.Init = function(CE)
  local WarningSystem = {"ttt_firegrenade_proj","ttt_c4", "npc_tripmine", "npc_grenade_frag", "crossbow_bolt", "rpg_missile", "grenade_ar2", "prop_combine_ball", "hunter_flechette", "ent_flashgrenade", "ent_explosivegrenade", "ent_smokegrenade"}
  local userdlights = { }
  local entsToColor = { }
  timer.Create("CE.RenderLights", .5, 0, function()
  	local _entsToColor = { }
  	for _, ent in pairs(ents.GetAll()) do
  		if (table.HasValue(WarningSystem, ent:GetClass()) or CE.IsTraitorWeapon(ent)) and ent.Owner ~= LocalPlayer() then
  			table.insert(entsToColor, ent)
  		end
  	end
  	entsToColor = _entsToColor
  end)
  CE.Hook.Add("RenderScene", "CE.RenderLights", function()
  	local tr = util.TraceLine( util.GetPlayerTrace( LocalPlayer() ) )
  	for _, ent in pairs(entsToColor) do
       	if IsValid(ent) then
  			local dlight = DynamicLight()
  			dlight.Pos = ent:GetPos()
  			dlight.r = 200
  			dlight.g = 0
  			dlight.b = 0
  			dlight.Brightness = 10
  			dlight.Size = 30
  			if(ent:GetClass() == "ttt_firegrenade_proj") then
  				dlight.Size = 250
  			end
  			dlight.DieTime = CurTime() + 0.2
  			dlight.Style = 0
  		end
  	end
  	for _,light in pairs(userdlights) do
  		local tr = light.tr
  		local ent = tr.Entity
  		if ent ~= nil and ent ~= NULL and IsValid(ent) and ent:GetPos() ~= nil and light.relpos ~= nil then
  			light.pos = ent:GetPos() - light.relpos
  			light.dlight.Pos = light.pos
  			light.dlight.DieTime = CurTime() + 100000
  		end
  	end
  end)
  local function addlight()
  	if #userdlights > 25 then
  		chat.AddText("Maximum number of lights (25) created! Please delete some first.")
  		return
  	end
  	--local uid = math.random(1, 999999)
  	local t = util.GetPlayerTrace(LocalPlayer())
  	local tr = util.TraceLine(t)
  	if tr.HitSky then
  		chat.AddText("Cannot add a light to the sky. Waste of your space and wouldnt show")
  		return
  	end
  	local dlight = DynamicLight()
  	dlight.Pos = tr.HitPos
  	dlight.r = 255
  	dlight.g = 255
  	dlight.b = 255
  	dlight.NoWorld = false
  	dlight.NoModel = false
  	dlight.Brightness = 3
  	dlight.Size = 500
  	dlight.Decay = 0
  	dlight.DieTime = CurTime() + 100000
  	local light = {dlight=dlight,pos=tr.HitPos,tr=tr}
  	if(tr.Entity ~= nil and tr.Entity ~= NULL) then
  		light.relpos = tr.Entity:GetPos() - tr.HitPos
  	end
  
  	table.insert(userdlights, light)
  end
  local function dellight()
  	local close = nil
  	local index = 0
  	for _,light in pairs(userdlights) do
  		if(close == nil or CE.DistanceTo(light.pos) < CE.DistanceTo(close.pos)) then
  			close = light
  			index = _
  		end
  	end
  	if(close ~= nil and CE.DistanceTo(close.pos) < 1000) then
  		close.dlight.DieTime = CurTime()
  		table.remove(userdlights, index)
  	end
  end
  --
  MODULE.AddCmd({
    Name="hacks_light_add",
    Nick="Add Lights",
    Info="Tool for dynamic lights (add)",
    Function=function(ply, command, args)
        addlight()
    end,
    HUD={ Category="Misc", Type="CommandButton"}
  })
  MODULE.AddCmd({
    Name="hacks_light_remove",
    Nick="Lights",
    Info="Tool for dynamic lights (remove)",
    Function=function(ply, command, args)
        dellight()
    end,
    HUD={ Category="Misc", Type="CommandButton"}
  })
end