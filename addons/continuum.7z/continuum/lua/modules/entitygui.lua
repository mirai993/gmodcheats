MODULE.ID = "com.continuum.entgui"
MODULE.Dependencies = { "com.continuum.monitor" }

MODULE.Name = "Entity GUI"
MODULE.Info = "Graphic User Interface for entities, players, and teams"

MODULE.Init = function(CE)
  if CE.SessionEntityFrame then CE.SessionEntityFrame:Remove() end
  local EntityFrame, ArsenalList, WeaponList, ShipmentList, PlayerList, MonitorList, TeamList, UpdateEntities,
    UpdateArsenalList, UpdateWeaponList, UpdateShipmentList, UpdatePlayerList, UpdateMonitorList, UpdateTeamList, Sheet
  local arsenalHook = usermessage.GetTable().arsenal_use

  EntityFrame = vgui.Create('DFrame')
  CE.Session.EntityFrame = EntityFrame
  EntityFrame:SetSize(449, 326)
  EntityFrame:Center()
  EntityFrame:SetTitle('Entity Controls')
  EntityFrame:SetSizable(false)
  EntityFrame:MakePopup()
  EntityFrame:SetVisible(false)
  function EntityFrame:Close()
    EntityFrame:SetVisible(not EntityFrame:IsVisible())
  end

  ArsenalList = vgui.Create("DPanelList")
  ArsenalList:SetSize(439, 296)
  ArsenalList:SetSpacing( 5 )
  ArsenalList:EnableHorizontal( false )
  ArsenalList:EnableVerticalScrollbar( true )

  WeaponList = vgui.Create("DPanelList")
  WeaponList:SetSize(439, 296)
  WeaponList:SetSpacing( 5 )
  WeaponList:EnableHorizontal( false )
  WeaponList:EnableVerticalScrollbar( true )

  ShipmentList = vgui.Create("DPanelList")
  ShipmentList:SetSize(439, 296)
  ShipmentList:SetSpacing( 5 )
  ShipmentList:EnableHorizontal( false )
  ShipmentList:EnableVerticalScrollbar( true )

  PlayerList = vgui.Create("DPanelList")
  PlayerList:SetSize(439, 296)
  PlayerList:SetSpacing( 5 )
  PlayerList:EnableHorizontal( false )
  PlayerList:EnableVerticalScrollbar( true )

  MonitorList = vgui.Create("DPanelList")
  MonitorList:SetSize(439, 296)
  MonitorList:SetSpacing( 5 )
  MonitorList:EnableHorizontal( false )
  MonitorList:EnableVerticalScrollbar( true )

  TeamList = vgui.Create("DPanelList")
  TeamList:SetSize(439, 296)
  TeamList:SetSpacing( 5 )
  TeamList:EnableHorizontal( false )
  TeamList:EnableVerticalScrollbar( true )

  Sheet = vgui.Create("DPropertySheet", EntityFrame)
  Sheet:SetPos(5,25)
  Sheet:SetSize(439, 296)
  if arsenalHook then
    Sheet:AddSheet( "Arsenals", ArsenalList, "gui/silkicons/box", false, false, "Arsenal Crates" )
  else
    ArsenalList = nil
  end
  local FakeArsenal = {
    Getowning_ent = function()
      --DebugStart()
      --Globals.timer.Simple(.5, DebugEnd)
      return { Nick=function() return "Global Crate" end} end,
    GetModel = function() return "models/items/ammocrate_ar2.mdl" end,
    --EntIndex = function() return 50 end,
    IsValid = function() return true end
  }
  Sheet:AddSheet( "Weapons", WeaponList, "materials/icon16/gun.png", false, false, "Guns & Knives" )
  if CustomShipments then
    Sheet:AddSheet( "Shipments", ShipmentList, "materials/icon16/lorry.png", false, false, "Various Packages Of Weapons" )
  else
    ShipmentList = nil
  end
  if RPExtraTeams then
    Sheet:AddSheet("Teams", TeamList, "gui/silkicons/group", false, false, "DarkRP Roles")
  else
    TeamList = nil
  end
  Sheet:AddSheet( "Players", PlayerList, "gui/silkicons/user", false, false, "Online Players" )
  --Sheet:AddSheet( "Monitors", MonitorList, "gui/silkicons/computer", false, false, "Monitors (hacks_monitoradd)" )
  local function capitalize(str)
    if str:lower() == "vip" then return "VIP" end
    if str:lower() == "vip+" then return "VIP+" end
    if str:lower() == "ump" then return "UMP" end
    if str:lower() == "ulx" then return "ULX" end
    return str:sub(1,1):upper()	 .. str:sub(2):lower()
  end
  local PM = FindMetaTable("Player")
  if not PM._IsAdmin then PM._IsAdmin = PM.IsAdmin end
  function PM:IsAdmin()
    if IsValid(self) then
      self.IsCheckingAdmin = true
    end
    return self:_IsAdmin()
  end
  if not PM._IsSuperAdmin then PM._IsSuperAdmin = PM.IsSuperAdmin end
  function PM:IsSuperAdmin()
    if IsValid(self) then
      self.IsCheckingSuperAdmin = true
    end
    return self:_IsSuperAdmin()
  end
  if not PM._IsUserGroup then PM._IsUserGroup = PM.IsUserGroup end
  function PM:IsUserGroup(group)
    if IsValid(self) then
      self.IsCheckingUserGroup = group
    end
    return self:_IsUserGroup(group)
  end
  if not PM._CheckGroup then PM._CheckGroup = PM.CheckGroup end
  function PM:CheckGroup(group)
    if IsValid(self) then
      self.IsCheckingUserGroup = group
    end
    return self:_CheckGroup(group)
  end

  local FakeUserGroup = nil
  if not PM._GetUserGroup then PM._GetUserGroup = PM.GetUserGroup end
  function PM:GetUserGroup()
    if IsValid(self) then
      self.IsCheckingUserGroup = true
    end
    if FakeUserGroup then return FakeUserGroup end
    if(not self._GetUserGroup) then
      return "user"
    end
    return self:_GetUserGroup()
  end
  --[[local MT = getmetatable("")
  local function __eq(o1, o2)
  local meta = getmetatable("")
  print("EQ check")
  meta.__eq = nil
  local eq = o1 == o2
  meta.__eq = __eq
  end
  MT.__eq = __eq
  print("test" == "test")
  --MT.__eq = nil]]


  local Entities = { }
  local Arsenals = { }
  local Weapons = { }
  local Shipments = { }
  local Players = { }
  local Monitors = { }
  local Teams = { }
  if arsenalHook then

    concommand.Add("hacks_maxammo", function()
      local a = LocalPlayer()
      for k,v in pairs(Arsenals) do
        a = v
        if v.Getowning_ent and v:Getowning_ent() == LocalPlayer() then
          break
        end
      end
      print("Buying ammo from " .. a:Getowning_ent():Nick())
      local wep = LocalPlayer():GetActiveWeapon()
      local ammoType = "smg1"
      if IsValid(wep) and wep.Primary then
        ammoType = wep.Primary.Ammo:lower()
      end
      local ammoId = -1
      for id,data in pairs(GM.AmmoTypes) do
        if data.ammoType:lower() == ammoType then ammoId = id end
      end
      for ammoToBuy=1,math.ceil((9999 - LocalPlayer():GetAmmoCount(ammoType)) / GM.AmmoTypes[ammoId].price) do
        CE.SwitchDependency("com.continuum.modulemods", net._Start, net.Start)("ammocrate_buy")
        net.WriteEntity(a)
        net.WriteDouble(ammoId)
        net.SendToServer()
      end
    end)
    concommand.Add("hacks_buyammo", function()
      local a = LocalPlayer()
      for k,v in pairs(Arsenals) do
        a = v
        if v.Getowning_ent and v:Getowning_ent() == LocalPlayer() then
          break
        end
      end
      print("Buying ammo from " .. a:Getowning_ent():Nick())
      local wep = LocalPlayer():GetActiveWeapon()
      local ammoType = "smg1"
      if IsValid(wep) and wep.Primary then
        ammoType = wep.Primary.Ammo
      end
      local ammoId = -1
      for id,data in pairs(GM.AmmoTypes) do
        if data.ammoType == ammoType then ammoId = id end
      end
      net._Start("ammocrate_buy")
      net.WriteEntity(a)
      net.WriteDouble(ammoId)
      net.SendToServer()
    end)
  end
  local function FindWeapon(spawnedWep)
    --if spawnedWep.swep then
    --	return spawnedWep.swep
    --end
    local model = spawnedWep:GetModel()
    local ModelSwepTable = { }
    ModelSwepTable["models/katharsmodels/syringe_out/syringe_out.mdl"] = { PrintName="Syringe" }
    local SpecialModelTable = { }
    SpecialModelTable["models/items/healthkit.mdl"]="models/weapons/w_medkit.mdl"
    SpecialModelTable["models/weapons/w_knife_ct.mdl"]="models/weapons/w_knife_t.mdl"

    if ModelSwepTable[model] then return ModelSwepTable[model] end
    if SpecialModelTable[model] then model = SpecialModelTable[model] end

    for _,swep in pairs(weapons.GetList()) do
      if swep.WorldModel and swep.WorldModel:find("syringe") then
        print(swep.WorldModel)
      end
      if swep.WorldModel == model then
        if model == "models/weapons/w_357.mdl" then swep.PrintName="Magnum" end
        spawnedWep.swep = swep
        return swep
      end
    end
  end
  local function OpenArsenal(Arsenal)
    surface.PlaySound('items/ammocrate_open.wav')
    local PreArgs = arsenalHook.PreArgs
    local Function = arsenalHook.Function
    local FakeUsermessage = { ReadEntity = function() return Arsenal end }
    print("OPENING ARSENAL!")
    PrintTable(debugger.GetUpvalues(Function))
    Function(FakeUsermessage, PreArgs)
  end
  local function RemoveMonitor(Entity)
    CE.Session.Monitors[Entity] = nil
  end
  local function AddMonitor(Entity)
    local name = Entity:GetClass()
    if name == "spawned_weapon" then
      name = FindWeapon(Entity).PrintName or "Weapon"
    elseif name == "props_arsenalcrate" then
      name = Entity:Getowning_ent():Nick().."'s Arsenal"
    elseif name == "player" then
      name = Entity:Nick()
    elseif name == "spawned_shipment" then
      local info = CustomShipments[Entity.dt.contents]
      name = (info.name or "Weapon") .. " Shipment"
    end
    if not name or name == "" then
      if Entity.Nick then
        name = Entity:Nick()
      else
        name = Entity:GetClass()
      end
    end
    CE.Session.Monitors[Entity] = {
      Name=name,
      PrintA=Entity:GetNWInt("PrintA",nil),
      ent=Entity,
      amount=Entity.dt and Entity.dt.amount,
      color=Entity:GetColor(),
      material=Entity:GetMaterial(),
      model=Entity:GetModel(),
      pos=Entity:GetPos(),
      lastPosWarn=0}
  end
  function UpdateEntities()
    Entities = ents.GetAll()
    Arsenals = { }
    Weapons = { }
    Shipments = { }
    Players = { }
    Teams = { }
    for k,v in pairs(Entities) do
      if v:GetClass() == "props_arsenalcrate" then
        table.insert(Arsenals, #Arsenals+1, v)
      elseif v:GetClass() == "spawned_weapon" or v.Primary and not (IsValid(v.Owner) or v:EntIndex() == 0) then
        table.insert(Weapons, #Weapons+1, v)
      elseif v:GetClass() == "spawned_shipment" then
        table.insert(Shipments, #Shipments+1, v)
        --elseif v:GetClass() == "player" then
        --	table.insert(Players, #Players+1, v)
      end
    end
    table.insert(Arsenals, 1, FakeArsenal)
    Teams = RPExtraTeams or { }
    Players = player.GetAll()
    Monitors = CE.Session.Monitors or { }

    table.sort(Players, function(a,b) return (team.GetName(a:Team()) or "") < (team.GetName(b:Team()) or "") end)
    table.sort(Shipments, function(a,b)
      local p = LocalPlayer():GetPos()
      return a:GetPos():Distance(p) < b:GetPos():Distance(p)
    end)
    table.sort(Weapons, function(a,b)
      local p = LocalPlayer():GetPos()
      return a:GetPos():Distance(p) < b:GetPos():Distance(p)
    end)
    table.sort(Arsenals, function(a,b)
      return a:Getowning_ent() == LocalPlayer()
    end)
  end
  function UpdateArsenalList()
    if not ArsenalList then return end
    for _,Panel in pairs(ArsenalList:GetItems()) do
      Panel:Remove()
    end
    for _,Arsenal in pairs(Arsenals) do
      local DPanel1 = vgui.Create('DPanel')
      DPanel1:SetSize(419, 74)

      local icon = vgui.Create("SpawnIcon", DPanel1)
      icon:SetModel(Arsenal:GetModel())
      icon:SetPos(5,5)
      icon:SetMouseInputEnabled(false)

      local name = vgui.Create("DLabel", DPanel1)
      name:SetText(Arsenal:Getowning_ent():Nick().."'s Arsenal")
      name:SizeToContents()
      name:SetTextColor(Color(30,30,30))
      name:SetPos(89, 5)

      local desc = vgui.Create("DLabel", DPanel1)
      desc:SetText("Arsenal Crate containing ammo")
      desc:SizeToContents()
      desc:SetTextColor(Color(90,90,90))
      desc:SetPos(89, 20)

      local open = vgui.Create("DButton", DPanel1)
      open:SetSize(45, 17)
      open:SetPos(290, 54)
      open:SetText("Open")
      open.DoClick = function()
        OpenArsenal(Arsenal)
      end

      if not Arsenal.FakeArsenal then
        local monitor = vgui.Create("DButton", DPanel1)
        monitor:SetSize(65, 17)
        monitor:SetPos(340, 54)
        if Monitors[Arsenal] then
          monitor:SetText("- Monitor")
          monitor.DoClick = function()
            RemoveMonitor(Arsenal)
            UpdateArsenalList()
            UpdateMonitorList()
          end
        else
          monitor:SetText("+ Monitor")
          monitor.DoClick = function()
            AddMonitor(Arsenal)
            UpdateArsenalList()
            UpdateMonitorList()
          end
        end
      end

      ArsenalList:AddItem(DPanel1)
    end
  end
  function UpdateWeaponList()
    if not WeaponList then return end
    for _,Panel in pairs(WeaponList:GetItems()) do
      Panel:Remove()
    end
    for _,Weapon in pairs(Weapons) do
      if not Weapon:GetNoDraw() then
        local swep = FindWeapon(Weapon)
        local wepname = swep and swep.PrintName or "Weapon" -- todo, scan through the weapons to find matching model or w/e
        local count = Weapon.dt and Weapon.dt.amount or 1
        local DPanel1 = vgui.Create('DPanel')
        DPanel1:SetSize(419, 74)

        local icon = vgui.Create("SpawnIcon", DPanel1)
        icon:SetModel(Weapon:GetModel())
        icon:SetPos(5,5)
        icon:SetMouseInputEnabled(false)

        local name = vgui.Create("DLabel", DPanel1)
        name:SetText(wepname)
        name:SizeToContents()
        name:SetTextColor(Color(30,30,30))
        name:SetPos(89, 5)

        local desc = vgui.Create("DLabel", DPanel1)
        if count == 1 then
          desc:SetText("A "..wepname:lower().." lying on the ground")
        else
          desc:SetText(count.." "..wepname:lower().."s lying on the ground")
        end
        desc:SizeToContents()
        desc:SetTextColor(Color(90,90,90))
        desc:SetPos(89, 20)
        if CustomShipments then
          local shipID
          for k,v in pairs(CustomShipments) do
            if v.model == Weapon:GetModel() or Weapon:GetModel() == "models/weapons/w_knife_t.mdl" then
              shipID = k
              break
            end
          end

          if shipID then
            local ship = vgui.Create("DButton", DPanel1)
            ship:SetSize(45, 17)
            ship:SetPos(290, 54)
            ship:SetText("Ship")
            ship.DoClick = function()
              RunConsoleCommand("darkrp", "makeshipment", Weapon:EntIndex())
              --RunConsoleCommand("darkrp", "/makeshipment", Weapon:EntIndex())
              timer.Simple(1, function()
                UpdateEntities()
                UpdateWeaponList()
                UpdateShipmentList()
              end)
            end
          end
        end
        local monitor = vgui.Create("DButton", DPanel1)
        monitor:SetSize(65, 17)
        monitor:SetPos(340, 54)
        if Monitors[Weapon] then
          monitor:SetText("- Monitor")
          monitor.DoClick = function()
            RemoveMonitor(Weapon)
            UpdateWeaponList()
            UpdateMonitorList()
          end
        else
          monitor:SetText("+ Monitor")
          monitor.DoClick = function()
            AddMonitor(Weapon)
            UpdateWeaponList()
            UpdateMonitorList()
          end
        end
        WeaponList:AddItem(DPanel1)
      end
    end
  end
  function UpdateShipmentList()
    if not ShipmentList then return end
    for _,Panel in pairs(ShipmentList:GetItems()) do
      Panel:Remove()
    end
    for k,Shipment in pairs(Shipments) do
      local DPanel1 = vgui.Create('DPanel')
      DPanel1:SetSize(419, 74)

      local info = CustomShipments[Shipment.dt.contents]
      local icon = vgui.Create("SpawnIcon", DPanel1)
      icon:SetModel("models/Items/item_item_crate.mdl")
      icon:SetPos(5,5)
      icon:SetMouseInputEnabled(false)
      local icon2 = vgui.Create("DModelPanel", DPanel1)
      icon2:SetModel(info.model)
      icon2:SetPos(-40,-120)
      icon2:SetSize(150,150)
      icon2:SetMouseInputEnabled(false)

      local name = vgui.Create("DLabel", DPanel1)
      name:SetText(info.name)
      name:SizeToContents()
      name:SetTextColor(Color(30,30,30))
      name:SetPos(89, 5)

      local desc = vgui.Create("DLabel", DPanel1)
      desc:SetText("A shipment with " .. Shipment.dt.count .. " left.")
      desc:SizeToContents()
      desc:SetPos(89, 20)
      desc:SetTextColor(Color(90,90,90))
      if (Shipment.dt.count or 1) >= 2 then
        local drop = vgui.Create("DButton", DPanel1)
        drop:SetSize(45, 17)
        drop:SetPos(290, 54)
        drop:SetText("Split")
        drop.DoClick = function()
          print("Splitting the shipment, /splitshipment "..Shipment:EntIndex())
          RunConsoleCommand("darkrp", "splitshipment", Shipment:EntIndex())
          --RunConsoleCommand("darkrp", "/splitshipment", Shipment:EntIndex())
          timer.Simple(1, function()
            UpdateEntities()
            UpdateShipmentList()
          end)
        end
      end
      local monitor = vgui.Create("DButton", DPanel1)
      monitor:SetSize(60, 15)
      monitor:SetPos(340, 54)
      if Monitors[Shipment] then
        monitor:SetText("- Monitor")
        monitor.DoClick = function()
          RemoveMonitor(Shipment)
          UpdateShipmentList()
          UpdateMonitorList()
        end
      else
        monitor:SetText("+ Monitor")
        monitor.DoClick = function()
          AddMonitor(Shipment)
          UpdateShipmentList()
          UpdateMonitorList()
        end
      end

      ShipmentList:AddItem(DPanel1)
    end
  end
  function UpdatePlayerList()
    if not PlayerList then return end
    for _,Panel in pairs(PlayerList:GetItems()) do
      Panel:Remove()
    end
    for _,ply in pairs(Players) do
      local DPanel1 = vgui.Create('DPanel')
      DPanel1:SetSize(419, 74)
      ply.GUIPanel = DPanel1
      local icon
      if ply.Avatar and IsValid(ply.Avatar) then
        icon = ply.Avatar
        icon:SetParent(DPanel1)
      else
        icon = vgui.Create("AvatarImage", DPanel1)
        icon:SetPlayer(ply)
        icon:SetPos(5,5)
        icon:SetSize(64,64)
        icon:SetMouseInputEnabled(false)
        icon._Remove = icon.Remove
        ply.Avatar = icon
      end

      local name = vgui.Create("DLabel", DPanel1)
      name:SetTextColor(team.GetColor(ply:Team()))
      name:SetText(ply:Nick())
      name:SizeToContents()
      name:SetPos(80, 5)
      local desc = vgui.Create("DLabel", DPanel1)
      desc:SetTextColor(CE.Colors.BLACK)
      ply.SteamName = ply.SteamName or ply.Name
      local descText = "Steam Name: "..ply:SteamName().."\nSteam ID: "..ply:SteamID()
      if ply.isWanted and ply:isWanted() then
        descText = descText .. "\nWanted: "..ply:getWantedReason()
      end
      if ply.isHitman and ply:isHitman() then
        descText = descText .. "\nHit price: "..ply:getHitPrice()
        if IsValid(ply:getHitTarget()) then
          descText = descText .. "     Hit target: " .. ply:getHitTarget():Nick()
        end
      end
      desc:SetText(descText)
      desc:SizeToContents()
      desc:SetPos(80, 20)
      ply.FriendStatus = ply.FriendStatus or ply:GetFriendStatus()
      local status = ply.FriendStatus
      local info = nil
      local infoclr = nil
      if status == "none" then
      elseif status == "friend" then
        info = "Friend"
        infoclr = Color(75,255,75)
      elseif status == "blocked" then
        info = "Blocked"
        infoclr = Color(255,75,75)
      elseif status == "requested" then
        info = "Request Pending"
        infoclr = Color(255,255,0)
      end
      if info then
        local InfoLabel = vgui.Create("DLabel", DPanel1)
        InfoLabel:SetFont("ChatFont")
        InfoLabel:SetTextColor(infoclr)
        InfoLabel:SetText(info)
        InfoLabel:SizeToContents()
        InfoLabel:SetPos(340, 5)
      end
      PlayerList:AddItem(DPanel1)
    end
  end
  function UpdateMonitorList()
  end
  local LastTeamChange = 0
  local ScaleBrightness, ScaleDarkness
  function ScaleBrightness(col, brightness)
    if brightness == 0 then brightness = .00000001 end
    brightness = 1/brightness
    if brightness >= 1 then return ScaleDarkness(col,brightness) end
    return Color(255-((255-col.r)*brightness), 255-((255-col.g)*brightness), 255-((255-col.b)*brightness), col.a)
  end
  function ScaleDarkness(col, brightness)
    if brightness == 0 then brightness = .00000001 end
    brightness = 1/brightness
    if brightness >= 1 then return ScaleBrightness(col,brightness) end
    return Color(col.r*brightness, col.g*brightness, col.b*brightness, col.a)
  end
  function UpdateTeamList()
    if not TeamList then return end
    for _,Panel in pairs(TeamList:GetItems()) do
      Panel:Remove()
    end
    for TeamKey,Team in pairs(Teams) do
      if type(Team.model) == "table" then
        Team.models = Team.model
      else
        Team.models = { Team.model }
      end
      Team.count = #team.GetPlayers(TeamKey)
      local DPanel1 = vgui.Create('DPanel')
      DPanel1:SetSize(419, 74)
      local icon = vgui.Create("SpawnIcon", DPanel1)
      icon:SetModel(Team.models[1])
      icon:SetPos(0,0)
      icon:SetSize(80,80)
      icon:SetMouseInputEnabled(false)

      local name = vgui.Create("DLabel", DPanel1)
      name:SetTextColor(team.GetColor(TeamKey))
      name:SetText(Team.name)
      name:SizeToContents()
      name:SetPos(80, 5)

      local salary = vgui.Create("DLabel", DPanel1)
      salary:SetTextColor(team.GetColor(TeamKey))
      salary:SetText("Salary: " .. GAMEMODE.Config.currency .. tostring(Team.salary))
      salary:SizeToContents()
      salary:SetPos(math.min((surface.GetTextSize(Team.name) or 0)+90, 340), 5)

      local count = vgui.Create("DLabel", DPanel1)
      count:SetTextColor(team.GetColor(TeamKey))
      count:SetFont("ChatFont")
      local str = tostring(Team.count) .. "/"
      if Team.max == 0 or Team.max == game.MaxPlayers() then
        str = str .. "MAX"
      else
        str = str .. tostring(Team.max)
      end
      count:SetText(str)
      count:SizeToContents()
      count:SetPos(350, 5)

      local desc = vgui.Create("DLabel", DPanel1)
      desc:SetTextColor(CE.Colors.BLACK)
      desc:SetText(Team.description)
      desc:SizeToContents()
      desc:SetPos(80, 20)

      local IsCurrentJob = TeamKey == LocalPlayer():Team()
      local MaxPass = Team.max == 0 or (Team.count or 0) <  (Team.max or 999)
      local AdminPass = Team.admin ~= 1 or LocalPlayer():IsAdmin()
      local SAdminPass = (Team.admin or 0) < 2 or LocalPlayer():IsSuperAdmin()
      local CustomPass = not Team.customCheck or pcall(Team.customCheck, LocalPlayer())
      local TeamPass = not Team.NeedToChangeFrom or (type(Team.NeedToChangeFrom) == "table" and table.HasValue(Team.NeedToChangeFrom, LocalPlayer:Team()) or type(Team.NeedToChangeFrom) == "number" and Team.NeedToChangeFrom == LocalPlayer():Team())
      local CanBe = MaxPass and AdminPass and CustomPass and TeamPass
      if (not IsCurrentJob) then
        local join = vgui.Create("DButton", DPanel1)
        join:SetSize(60,17)
        join:SetPos(330, 54)
        if Team.vote then
          join:SetText("Vote")
        else
          join:SetText("Join")
        end
        join.DoClick = function()
          if Team.vote then
            --RunConsoleCommand("darkrp", "/vote"..Team.command)
            RunConsoleCommand("darkrp", "vote"..Team.command)
          else
            --RunConsoleCommand("darkrp", "/"..Team.command)
            RunConsoleCommand("darkrp", ""..Team.command)
          end
          join:SetText("Joining")
        end
        if not LocalPlayer():Alive() then
          join:SetDisabled(true)
          join:SetText("Dead")
        end
        if LocalPlayer().isArrested and LocalPlayer():isArrested() then
          join:SetDisabled(true)
          join:SetText("Arrested")
        end
        if 10 - (CurTime() - LastTeamChange) > 0 then
          join:SetDisabled(true)
          local ToWait = math.round(10 - (CurTime() - LastTeamChange))
          join:SetText("Wait "..ToWait)
        end
        if not MaxPass then
          join:SetText("Full")
          join:SetDisabled(true)
        end
        if not TeamPass then
          join:SetText(team.GetName(Team.NeedToChangeFrom))
          join:SetDisabled(true)
        end
        if not AdminPass then
          join:SetText("Admin")
          join:SetDisabled(true)
        end
        if not SAdminPass then
          join:SetText("SAdmin")
          join:SetDisabled(true)
        end
        if not CustomPass then
          -- start attempting to catch calls
          LocalPlayer().IsCheckingAdmin = false
          LocalPlayer().IsCheckingSuperAdmin = false
          LocalPlayer().IsCheckingUserGroup = false
          pcall(Team.customCheck, LocalPlayer())
          if LocalPlayer().IsCheckingUserGroup then
            if LocalPlayer().IsCheckingUserGroup == true and ULib then
              local tree = ULib.ucl.getInheritanceTree()
              local minRank = nil
              for name,children in pairs(tree) do
                FakeUserGroup = name
                if minRank then break end
                if Team.customCheck(LocalPlayer()) then
                  minRank = name
                  break
                end
                for name,children in pairs(children) do
                  FakeUserGroup = name
                  if minRank then break end
                  if Team.customCheck(LocalPlayer()) then
                    minRank = name
                    break
                  end
                  for name,children in pairs(children) do
                    FakeUserGroup = name
                    if minRank then break end
                    if Team.customCheck(LocalPlayer()) then
                      minRank = name
                      break
                    end
                    for name,children in pairs(children) do
                      FakeUserGroup = name
                      if minRank then break end
                      if Team.customCheck(LocalPlayer()) then
                        minRank = name
                        break
                      end
                      for name,children in pairs(children) do
                        FakeUserGroup = name
                        if minRank then break end
                        if Team.customCheck(LocalPlayer()) then
                          minRank = name
                          break
                        end
                        for name,children in pairs(children) do
                          FakeUserGroup = name
                          if minRank then break end
                          if Team.customCheck(LocalPlayer()) then
                            minRank = name
                            break
                          end
                        end
                      end
                    end
                  end
                end
              end
              join:SetText(capitalize(minRank or "ulx"))
            else
              join:SetText(capitalize(LocalPlayer().IsCheckingUserGroup))
            end
            --print(Team.name .. " checks for usergroup "..LocalPlayer().IsCheckingUserGroup)
          elseif LocalPlayer().IsCheckingAdmin then
            join:SetText("Admin")
            --print(Team.name .. " checks for admin")
          elseif LocalPlayer().IsCheckingSuperAdmin then
            join:SetText("SAdmin")
            --print(Team.name .. " checks for super admin")
          else
            join:SetText("Custom")
            --print(Team.name .. " checks for some other thing, proly VIP")
          end


          join:SetDisabled(true)
        end
        surface.SetFont(join.GetFont and join:GetFont() or "DermaDefault")
        join:SetSize(math.Clamp(surface.GetTextSize(join:GetText())+10, 60, 70), 17)

        if join:GetDisabled() then
          desc:SetTextColor(ScaleBrightness(desc:GetTextColor(), 3))
          name:SetTextColor(ScaleBrightness(name:GetTextColor(), 3))
          salary:SetTextColor(ScaleBrightness(salary:GetTextColor(), 3))
          count:SetTextColor(ScaleBrightness(count:GetTextColor(), 3))
          count:SetFont("DermaDefault")
        end
      end
      FakeUserGroup = nil
      local color = team.GetColor(TeamKey)
      if IsCurrentJob then
        color = ScaleBrightness(color, 1.4)
      elseif not CanBe then
        --color =  Color( 200, 200, 200,255)
        color = ScaleBrightness(color, 7)
      else
        color = ScaleBrightness(color, 1.8)
      end
      function icon:PaintOver() -- The paint function
        if not IsCurrentJob and not CanBe then
          surface.SetDrawColor( color.r, color.g, color.b, 100 ) -- What color do You want to paint the button (R, B, G, A)
          surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() ) -- Paint what coords
      end
      end
      function DPanel1:Paint()
        surface.SetDrawColor(color)
        surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
      end
      function DPanel1:PaintOver()
        if IsCurrentJob then
          surface.SetDrawColor(ScaleBrightness(team.GetColor(TeamKey), .8))
          local wide = self:GetWide()
          local tall = self:GetTall()
          for width=1,3 do
            surface.DrawOutlinedRect(width-1,width-1, wide-(width-1)*2, tall-(width-1)*2)
          end
        end
      end
      TeamList:AddItem(DPanel1)
    end
  end
  CE.Hook.Add("TeamChanged", "CE.TeamChangedHook", function(before, after)
    LastTeamChange = CurTime()
  end)
  local function UpdateAll()
    UpdateEntities()

    UpdateArsenalList()
    UpdateWeaponList()
    UpdateShipmentList()
    UpdatePlayerList()
    UpdateTeamList()
  end
  local function UpdateFrequent()
    if EntityFrame:IsVisible() then UpdateAll() end
  end
  local function UpdateInfrequent()
    for k,ply in pairs(Players) do
      if IsValid(ply) then
        local icon = vgui.Create("AvatarImage", ply.GUIPanel)
        icon:SetSize(64,64)
        icon:SetPlayer(ply)
        icon:SetPos(5,5)
        icon:SetMouseInputEnabled(false)
        ply.Avatar = icon
        ply.FriendStatus = ply:GetFriendStatus()
      end
    end
  end
  UpdateAll()
  timer.Create( "hacks_ents_update", 1, 0, UpdateFrequent)
  timer.Create( "HacksUpdate60", 60, 0, UpdateInfrequent)

  local function showmenu()
    UpdateAll()
    EntityFrame:SetVisible(true)
  end
  MODULE.AddCmd({Name="hacks_ents", Nick="Entity GUI", Function=showmenu, HUD={ Category="Misc", Type="CommandButton"}})


  if CE.IsDarkRP() and DarkRP then -- lets mess with some hitman stuff
    local activeHitmen = {}
    local PM = FindMetaTable("Player")
    local textCol1, textCol2 = Color(0, 0, 0, 200), Color(128, 30, 30, 255)
    local function postPlayerDraw(ply) -- add to the hitman screen the target / customer
      if not activeHitmen[ply] and false then return end
      local pos, ang = ply:GetShootPos(), ply:EyeAngles()
      ang.p = 0
      ang:RotateAroundAxis(ang:Up(), 90)
      ang:RotateAroundAxis(ang:Forward(), 90)

      cam.Start3D2D(pos, ang, 0.3)
      draw.DrawText(GAMEMODE.Config.hitmanText, "TargetID", 1, -100, textCol1, 1)
      draw.DrawText(GAMEMODE.Config.hitmanText, "TargetID", 0, -101, textCol2, 1)

      --draw.DrawText(GAMEMODE.Config.hitmanText, "TargetID", 1, -100, textCol1, 1)
      --draw.DrawText(GAMEMODE.Config.hitmanText, "TargetID", 0, -101, textCol2, 1)
      cam.End3D2D()
    end
    function PM:drawHitInfo()
      activeHitmen[self] = true
      hook.Add("PostPlayerDraw", "drawHitInfo", postPlayerDraw)
    end
    function PM:stopHitInfo()
      activeHitmen[self] = nil
      if table.Count(activeHitmen) == 0 then
        hook.Remove("PostPlayerDraw", "drawHitInfo")
      end
    end

    -- Lets overwrite theyre hooks and save the target and customer
    function DarkRP.hooks:onHitAccepted(hitman, target, customer)
      if not IsValid(hitman) then return end
      hitman:drawHitInfo()
      hitman.HitCustomer = customer
      hitman.HitTarget = target
    end

    function DarkRP.hooks:onHitCompleted(hitman, target, customer)
      if not IsValid(hitman) then return end
      hitman:stopHitInfo()
      hitman.HitCustomer = nil
      hitman.HitTarget = nil
    end

    function DarkRP.hooks:onHitFailed(hitman, target, reason)
      if not IsValid(hitman) then return end
      hitman:stopHitInfo()
      hitman.HitCustomer = nil
      hitman.HitTarget = nil
    end

    -- We're just gonna shift the hitman option down a little to make room for our player info
    local localplayer , hudText
    hook.Add("HUDPaint", "DrawHitOption", function()
      localplayer = localplayer or LocalPlayer()
      hudText = hudText or GAMEMODE.Config.hudText
      local x, y
      local ply = localplayer:GetEyeTrace().Entity

      if IsValid(ply) and ply:IsPlayer() and ply.IsHitman and ply:isHitman() and not ply:hasHit() and localplayer:GetPos():Distance(ply:GetPos()) < GAMEMODE.Config.minHitDistance then
        x, y = ScrW() / 2, ScrH() / 2 + 60

        draw.DrawText(hudText, "TargetID", x + 1, y + 1, textCol1, 1)
        draw.DrawText(hudText, "TargetID", x, y, textCol2, 1)
      end

      if localplayer.isHitman and localplayer:isHitman() and localplayer:hasHit() and IsValid(localplayer:getHitTarget()) then
        x, y = chat.GetChatBoxPos()
        local text = "Hit: " .. localplayer:getHitTarget():Nick()
        draw.DrawText(text, "HUDNumber5", x + 1, y + 1, textCol1, 0)
        draw.DrawText(text, "HUDNumber5", x, y, textCol2, 0)
      end
    end)
  end
end