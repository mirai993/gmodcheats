MODULE.Name = "Chat Bubbles"
MODULE.ID = "com.continuum.chatbubbles"
MODULE.Dependencies = { }
MODULE.cvars = {{Nick="Chat Bubbles", Name="hacks_chatbubbles", Default="1", HUD={ Category="Misc", Type="ToggleButton"}}}
MODULE.Init = function(CE)
  surface.CreateFont( "BigChatFont", {
    font = "Arial",
    size = 80,
    weight = 1000,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = true,
    additive = false,
    outline = true
  } )

  surface.CreateFont( "HugeChatFont____", {
    font = "derma_font_default",
    size = 160,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = true
  })
  surface.CreateFont( "HugeChatFont_____", {
    font = "derma_font_default",
    size = 164,
    weight = 500,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = true
  })
  local msgs = CE.Session.msgs or { }
  CE.Session.msgs = msgs
  CE.Hook.Add("OnPlayerChat", "CE.ChatBubbles", function( ply, strText, bTeamOnly, bPlayerIsDead )
    msgs[ply] = { time=CurTime(), text=strText, teamOnly=bTeamOnly, dead=bPlayerIsDead, player=ply }
  end)
  local function WrapText(text, font, width)
    surface.SetFont(font)

    -- Any wrapping required?
    local w, _ = surface.GetTextSize(text)
    if w <= width then
      return {text} -- Nope, but wrap in table for uniformity
    end

    local words = string.Explode(" ", text) -- No spaces means you're screwed

    local lines = {""}
    for i, wrd in pairs(words) do
      local l = #lines
      local added = lines[l] .. " " .. wrd
      w, _ = surface.GetTextSize(added)

      if w > width then
        -- New line needed
        table.insert(lines, wrd)
      else
        -- Safe to tack it on
        lines[l] = added
      end
    end

    return lines
  end
  CE.Hook.Add("PostDrawTranslucentRenderables", "CE.ChatBubbles", function()
    for _,msg in pairs(msgs) do
      local scale = 6 - (CurTime() - msg.time)
      local ply = msg.player
      if scale > 1 then scale = 1 end
      if scale <= 0 or not IsValid(ply) then
        msgs[_] = nil
      else
        if ply:Alive() and ply ~= LocalPlayer() then
          local Data = hook.Run( "CalcView", LocalPlayer(), EyePos(), EyeAngles(), 75 )
          local Position = Data.origin or EyePos()
          local Angles = Data.angles or EyeAngles()
          Angles = (ply:GetPos() - Position):Angle()
          Angles = Angle(0,Angles.y-90+10,--[[90-Angles.p]]90)
  
          cam.IgnoreZ(false);
          cam.Start3D2D( ply:GetPos()+Vector(0,0,85+math.sin(CurTime()*1.7)*3), Angles, .1 )
          local lines = WrapText(msg.text, "BigChatFont", 900)
          surface.SetDrawColor( 20, 20, 20, 180*scale)
          surface.DrawRect(-500, -300, 1000, 200+100*#lines )
  
          local nick = ply:Nick()
          local team = team.GetColor(ply:Team())
          draw.DrawText( nick, "HugeChatFont_____", 0,-300, Color(255,255,255*scale), TEXT_ALIGN_CENTER )
          draw.DrawText( nick, "HugeChatFont____", 0,-300, Color(team.r,team.g,team.b,255*scale), TEXT_ALIGN_CENTER )
          for _,line in pairs(lines) do
            draw.DrawText(line, "BigChatFont", -450, -250 + _ * 100, Color(200,200,200,255*scale))
          end
          cam.End3D2D()
          cam.IgnoreZ(false);
        end
      end
    end
  end)
end