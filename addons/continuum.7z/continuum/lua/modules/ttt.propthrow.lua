MODULE.ID = "com.continuum.propthrow"
MODULE.Dependencies = { }

MODULE.Name = "Propthrow"
MODULE.Info = "Throws props"

local function findSolutions(ply, prop)
  if not IsValid(ply) or not IsValid(prop) then return end
  local absVel = ply:GetAbsVelocity() * .122
  local pos = ply:GetPos() + Vector(0,0,25) + absVel
  local lpos = LocalPlayer():EyePos()
  local v = prop:GetPos() - ply:GetPos()
  local a = pos.x
  local b = pos.y
  local c = pos.z

  local d = lpos.x
  local e = lpos.y
  local f = lpos.z

  local x = v.x
  local y = v.y
  local z = v.z

  local r = baseclass.BaseClassTable.weapon_zm_carry:GetRange(prop)

  local ta = (-1/2 * math.sqrt((2*a*x + 2*b*y + 2*c*z - 2*d*x - 2*e*y - 2*f*z)^2 - 4*(x^2+y^2+z^2)*(a^2 - 2*a*d + b^2 - 2*b*e + c^2 - 2*c*f + d^2 + e^2 + f^2 - r^2)) - a*x - b*y - c*z + d*x + e*y+f*z)/(x^2+y^2+z^2)
  local tb = (1/2 * math.sqrt((2*a*x + 2*b*y + 2*c*z - 2*d*x - 2*e*y - 2*f*z)^2 - 4*(x^2+y^2+z^2)*(a^2 - 2*a*d + b^2 - 2*b*e + c^2 - 2*c*f + d^2 + e^2 + f^2 - r^2)) - a*x - b*y - c*z + d*x + e*y+f*z)/(x^2+y^2+z^2)
  local solutionA = pos + ta*v
  local solutionB = pos + tb*v
  return solutionA, solutionB, pos
end

MODULE.AddCmd({
  Name="hacks_propthrow",
  Func=function()
    --local angles = LocalPlayer():EyeAngles()
    --angles.y = angles.y + 80

    --CE.SetEyeAngles(angles)

    -- Try to guess what prop we're holding:
    local prop
    for _,ent in pairs(ents.GetAll()) do
      if ent:GetOwner() == LocalPlayer() and not ent:IsPlayer() and not ent:IsWorld() and ent:GetClass() ~= "viewmodel" and ent:GetClass() ~= "gmod_hands" and (not ent.IsCarriedByLocalPlayer or not ent:IsCarriedByLocalPlayer()) then
        prop = ent
        break
      end
    end
    if not prop then return end
    print("Prop: ", tostring(prop))
    local ply = CE.findPlayerOnScreen(true)
    if not ply or ply then
      local angles = LocalPlayer():EyeAngles()
      --angles.y = angles.y + 180
      --CE.SetEyeAngles(angles)
      timer.Create("TurnAround", .3, 1, function()
        angles.y = angles.y - 150
        angles.p = angles.p - 2
        CE.SetEyeAngles(angles)
        RunConsoleCommand("+attack2")
        timer.Create("ReleaseAttack", .2, 1, function() RunConsoleCommand("-attack2") end)
      end)
      return
    end
    ply = ply.target

    -- r = vo + tv
    -- x = pos.x + t * v.x
    -- y = pos.y + t * v.y
    -- y = pos.z + t * v.z

    -- (x-lpos.x)^2 + (y-lpos.y)^2 + (z-lpos.z)^2 = carryRange^2

    -- (pos.x + t * v.x - lpos.x)^2 +
    local absVel = ply:GetAbsVelocity() * .122
    local pos = ply:GetPos() + Vector(0,0,25) + absVel
    local lpos = LocalPlayer():EyePos()
    print("LP is at: ", tostring(lpos))
    print("Target is at: ", tostring(pos))
    print("Prop is at: ", tostring(prop:GetPos()))
    local solutionA, solutionB = findSolutions(ply, prop)
    print("Solutions are: ", solutionA, " and ", solutionB)
    --local angles = (LocalPlayer():EyePos()):AngleTo(solutionB)
    local angles = (LocalPlayer():EyePos()):AngleTo(pos)
    local t = (LocalPlayer():EyeAngles().r - angles.r) ^ 2 +
      (LocalPlayer():EyeAngles().p- angles.p) ^ 2 +
      (LocalPlayer():EyeAngles().y - angles.y) ^ 2
    t = t / 12137.169336567

    --print(t)
    angles = LerpAngle(.47 * t, LocalPlayer():EyeAngles(), angles)
    --print(angles)
    angles.r = 0
    print(tostring(angles))
    CE.SetEyeAngles(angles)
    RunConsoleCommand("+attack2")
    timer.Create("ReleaseAttack", .2, 1, function() RunConsoleCommand("-attack2") end)
  end})