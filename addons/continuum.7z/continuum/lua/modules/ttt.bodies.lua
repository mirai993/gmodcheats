MODULE.ID = "com.continuum.ttt.bodies"
MODULE.Dependencies = { "com.continuum.notify" }

MODULE.Name = "Body Flagger"
MODULE.Info = "Notifies user about body info changes in TTT"

MODULE.Init = function(CE)
  local Colors = CE.Colors
  local clearedForPrep = false
  local lastRound = nil
  local IsFirstScan = true
  CE.Hook.Add("Think","CE.Notifier", function()
    if CORPSE ~= nil then
      -- If the round changed, and it didn't change from active to post (the only time bodies persist), clear deaths
      if GAMEMODE.round_state ~= ROUND_POST and GAMEMODE.round_state ~= lastRound  then
        if not clearedForPrep then
          for _,v in pairs(player.GetAll()) do
            v._deathKnown = nil
          end
          clearedForPrep = true
        end
      else
        clearedForPrep = false
      end
      lastRound = GAMEMODE.round_state
      for k,ply in pairs(player.GetAll()) do
        if not ply:Alive() and not ply._deathKnown then
          if not IsFirstScan then
            CE.Notify.Stack(ply:GetRoleColor(), ply:GetName(), Colors.WHITE, " was killed, and is now MIA.")
          end
          ply._deathKnown = true
        end
      end
      for k,ent in pairs(ents.FindByClass('prop_ragdoll')) do
        if ent:IsValid() and ent:IsRagdoll() then
          local PT = LANG.GetParamTranslation
          local rag = ent
          local nick  = CORPSE.GetPlayerNick(rag)
          local ply = player.GetByName(nick)
          local found = CORPSE.GetFound(rag, false)
          if nick ~= nil and nick ~= "" then
            if not found then
              if rag._deathKnown ~= true then
                rag._deathKnown = true
              end
            else
              if rag._idKnown ~= true then
                rag._idKnown = true
                if not IsFirstScan then
                --CE.Notify.Chat(ply and ply:GetRoleColor() or Colors.BLACK, nick, Colors.WHITE,"'s body was identified.")
                end
              end
            end
            if(ply ~= nil and ply.search_result ~= nil and rag._searchReported ~= true) then
              rag._searchReported = true
              local s = ply.search_result
              local wepinfo = ""
              local lastsaw = ""
              if s.wep ~= "" then
                local wep = util.WeaponForClass(s.wep)
                local wname = wep and LANG.TryTranslation(wep.PrintName)
                wepinfo = " He was "
                if s.head then
                  wepinfo = wepinfo.."headshotted"
                else
                  wepinfo = wepinfo.."killed"
                end
                wepinfo = wepinfo.." with a "..wname.."."
              end
              if s.lastid ~= nil then
                local ent = Entity(s.lastid.idx)
                if IsValid(ent) and ent:IsPlayer() then
                  lastsaw = " "..PT("search_eyes", {player = ent:Nick()})
                end
              end
              if not IsFirstScan then
                CE.Notify.Stack(CE.Colors.GetRoleColor(s.role), nick, Colors.WHITE,"'s body's search was recieved. "..wepinfo..lastsaw)
              end
            end
          end
        end
      end
    end
    IsFirstScan = false
  end)
end