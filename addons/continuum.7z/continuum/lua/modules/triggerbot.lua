MODULE.ID = "com.continuum.triggerbot"
MODULE.Dependencies = { }

MODULE.Name = "Autobot"
MODULE.Info = "Collection of bot-like things; triggerbot autoshoots when someone is in your sights, and usebot spams +use then -use"
MODULE.cvars = {
  { nick = "Triggerbot", name="hacks_triggerbot", default=0, info="Automatically shoots for you when you over a player", HUD={ Category="Weaponry", Type="ToggleButton"}},
  { nick="Usebot", name="hacks_usebot", description="Spams +use then -use for you", default=0 },
  { nick="Spacespam", name="hacks_spacespam", description="Spams space key for you", default=0 },
  {name="hacks_rapidfire", nick="Rapid Fire", info="Rapid fire for guns", default=1, HUD={ Category="Weaponry", Type="ToggleButton"}},
  {name="hacks_bunnyhop", nick="Bunnyhop", info="Repeatedly jumps if you hold space", default=1, HUD={ Category="Misc", Type="ToggleButton"}},
{name="hacks_autoreload", nick="Auto reload", info="Automatically reloads when out of ammo", default=1, HUD={ Category="Weaponry", Type="ToggleButton"}},
  {name="hacks_nofall", nick="Nofall", info="Tries to prevent you from falling off cliffs [beta]", default=0},
  {name="hacks_nofallv2", nick="Nofall V2", info="Legit. You freeze midair while falling. [beta]", default=0},
  {name="hacks_nostop", nick="No Stop", info="Makes you slideeee", default=0}
}
MODULE.Init = function(CE)
  local Using = false
  local Spacing = false
  local AttackReleased = false
  local DidToolUse = false
  local ToolUsePos = 0

  local JumpReleased = false
  local function CheckValid(pos)
    local trace = {start=LocalPlayer():GetPos(), endpos=pos}
    return not trace.Hit
  end
  local oldForward = 0
  local oldSide = 0
  local SENSITIVITY = GetConVarNumber("sensitivity")
  local OldAngles = LocalPlayer():GetAngles()
  local IsSlowing = false
  CE.Hook.Add("Think", "CE.NoFall", function()
    if CE.GetConVarBool("hacks_nofallv2") then
      local aim = LocalPlayer():GetAimVector()
      aim.z = 0
      aim = aim * 75
      local Pos = LocalPlayer():GetPos()
      local Trace = {start=Pos, endpos=Pos-Vector(0,0,1000)}
      local TR = util.TraceLine(Trace)
      local Down = TR.Fraction * 1000
      if Down > 150 and not IsSlowing and not LocalPlayer():IsOnGround() then
        RunConsoleCommand("host_framerate", 250);
        IsSlowing = true
      elseif LocalPlayer():IsOnGround() and IsSlowing then
        RunConsoleCommand("host_framerate", 0);
        IsSlowing = false
      end
    end
  end)
  CE.Hook.Add("CreateMove", "CE.Triggerbot", function(cmd)
    local forward = cmd:GetForwardMove()
    local side = cmd:GetSideMove()
    if forward > 300 then forward = 300 end
    if side > 300 then side = 300 end
    oldForward=oldForward+forward/10
    oldSide=oldSide+side/10
    --cmd:SetForwardMove(oldForward)
    --cmd:SetSideMove(oldSide)
    -- Automatic reload
    local wep = LocalPlayer():GetActiveWeapon()
    if CE.GetConVarBool("hacks_autoreload") then
      if IsValid(wep) and wep.Clip1 and wep.GetPrimaryAmmoType then
        local mag_left = wep:Clip1()
        local mag_extra = LocalPlayer():GetAmmoCount(wep:GetPrimaryAmmoType())
        if mag_left == 0 and mag_extra > 0 then
          cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))
        end
      end
    end
    -- Triggerbot
    if CE.GetConVarBool("hacks_triggerbot") then
      local trace = util.GetPlayerTrace( LocalPlayer() )
      trace.mask = MASK_SHOT
      local traceRes = util.TraceLine( trace )
      local Target = traceRes.Entity
      if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() and (CE.IsRoundOver() or (not Target:IsTraitorBuddy() and not Target:IsFriend() and not Target:IsSpawnProtected() and not LocalPlayer():IsSpawnProtected()))) then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
      end
    end
    -- Usebot, spams the use button
    if CE.GetConVarBool("hacks_usebot") then
      if not Using then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_USE))
      end
      Using = not Using
    end
    if CE.GetConVarBool("hacks_spacespam") then
      if not Spacing then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
      end
      Spacing = not Spacing
    end
    -- Rapidfire, toggles the attack if we're firing
    if CE.GetConVarBool("hacks_rapidfire") then
      if (IsValid(wep) --[[and not wep.current_mode and wep:GetClass() ~= "weapon_physgun" and not (wep.Primary and wep.Primary.Automatic) ]]and cmd:KeyDown( IN_ATTACK )) then
        if not AttackReleased then
          cmd:RemoveKey(IN_ATTACK)
        end
        AttackReleased = not AttackReleased
        IsShooting = true
      elseif not AttackReleased then
        AttackReleased = true;
        IsShooting = cmd:KeyDown(IN_ATTACK)
      else
        IsShooting = cmd:KeyDown(IN_ATTACK)
      end
    else
      IsShooting = cmd:KeyDown(IN_ATTACK)
      AttackReleased = true;
    end
    --Bunnyhop
    if bit.band(LocalPlayer():GetMoveType(), MOVETYPE_WALK) ~= 0 then
      if (cmd:KeyDown( IN_JUMP ) and CE.GetConVarBool("hacks_bunnyhop")) then --Credits to gir489 original code for TF2
        if (not JumpReleased) then
          if (not LocalPlayer():OnGround() --[[or LocalPlayer():WaterLevel() <= 0]]) then
            cmd:RemoveKey( IN_JUMP );
          end
      else
        JumpReleased = false
      end
      elseif not JumpReleased then
        JumpReleased = true;
      end
    end
    --luaDebugger(cmd)
    if cmd:GetImpulse() > 0 then
      print("Impulse ",cmd:GetImpulse())
    end
    --Tool Cycler
    if IsValid(wep) and wep:GetClass() == "gmod_tool" then
      if GetConVarString("gmod_toolmode") == "stacker" and cmd:KeyDown(IN_USE) then
        local input = {IsKeyDown=CE.Session._IsKeyDown}
        local rate = cmd:KeyDown(IN_SPEED) and 5 or .05
        if input.IsKeyDown(KEY_UP) then
          RunConsoleCommand("stacker_offsety", GetConVarNumber("stacker_offsety")+rate)
        elseif input.IsKeyDown(KEY_DOWN) then
          RunConsoleCommand("stacker_offsety", GetConVarNumber("stacker_offsety")-rate)
        elseif input.IsKeyDown(KEY_LEFT) then
          RunConsoleCommand("stacker_offsetx", GetConVarNumber("stacker_offsetx")-rate)
        elseif input.IsKeyDown(KEY_RIGHT) then
          RunConsoleCommand("stacker_offsetx", GetConVarNumber("stacker_offsetx")+rate)
        elseif cmd:KeyDown(IN_FORWARD) then
          RunConsoleCommand("stacker_offsetz", GetConVarNumber("stacker_offsetz")+rate)
        elseif cmd:KeyDown(IN_BACK) then
          RunConsoleCommand("stacker_offsetz", GetConVarNumber("stacker_offsetz")-rate)
        elseif cmd:KeyDown(IN_JUMP) then
          RunConsoleCommand("stacker_offsetx", 0)
          RunConsoleCommand("stacker_offsety", 0)
          RunConsoleCommand("stacker_offsetz", 0)
        end
        cmd:RemoveKey(IN_JUMP)
        cmd:SetForwardMove(0)
      end


      if cmd:KeyDown(IN_USE) then
        local IsLeft = cmd:GetSideMove() < 0
        local IsRight = cmd:GetSideMove() > 0
        if IsRight then
          if ToolUsePos <= 0 then
            ToolUsePos = 10
            local NewTool
            local IsToolNext = false
            for idx,Tool in CE.PairsByKeys(wep.Tool) do
              if Tool:Allowed() then
                print(idx)
                if IsToolNext then NewTool = idx; break; end
                if idx == wep.Mode then
                  IsToolNext = true
                end
              end
            end
            NewTool = NewTool or CE.PairsByKeys(wep.Tool)()
            RunConsoleCommand("gmod_toolmode", NewTool)
          end
        elseif IsLeft then
          if ToolUsePos <= 0 then
            ToolUsePos = 10
            local NewTool
            local LastTool = nil
            for idx,Tool in CE.PairsByKeys(wep.Tool) do
              if Tool:Allowed() then
                if idx == wep.Mode then
                  NewTool = LastTool
                  if NewTool then break end
                end
                LastTool = idx
              end
            end
            NewTool = NewTool or LastTool
            RunConsoleCommand("gmod_toolmode", NewTool)
          end
        else
          ToolUsePos = 0
        end
        cmd:SetSideMove(0) -- Dont want to actually move when they use arrows
      else
        ToolUsePos = 0
      end
      ToolUsePos = math.Clamp(ToolUsePos-1, 0, 30)
    end
    if CE.GetConVarBool("hacks_nofall") then
      local aim = LocalPlayer():GetAimVector()
      aim.z = 0
      aim = aim * 75
      local Pos = LocalPlayer():GetPos()
      local ForwardPos = Pos+aim
      aim:Rotate(Angle(0,90,0))
      local RightPos = Pos+aim
      aim:Rotate(Angle(0,90,0))
      local BackPos = Pos+aim
      aim:Rotate(Angle(0,90,0))
      local LeftPos = Pos+aim
      local Trace = {start=Pos, endpos=Pos-Vector(0,0,1000)}
      local ForwardTrace = {start=ForwardPos, endpos=ForwardPos-Vector(0,0,1000)}
      local RightTrace = {start=RightPos, endpos=RightPos-Vector(0,0,1000)}
      local BackTrace = {start=BackPos, endpos=BackPos-Vector(0,0,1000)}
      local LeftTrace = {start=LeftPos, endpos=LeftPos-Vector(0,0,1000)}
      local TR = util.TraceLine(Trace)
      local ForwardTR = util.TraceLine(ForwardTrace)
      local RightTR = util.TraceLine(RightTrace)
      local BackTR = util.TraceLine(BackTrace)
      local LeftTR = util.TraceLine(LeftTrace)
      local Down = TR.Fraction * 1000
      local Forward = ForwardTR.Fraction * 1000
      local Right = RightTR.Fraction * 1000
      local Back = BackTR.Fraction * 1000
      local Left = LeftTR.Fraction * 1000
      if Down < 100 then
        if Forward > 100 and CheckValid(ForwardPos) then cmd:SetForwardMove(math.min(0,cmd:GetForwardMove())) end
        if Back > 100 and CheckValid(BackPos) then cmd:SetForwardMove(math.max(0,cmd:GetForwardMove())) end
        if Right > 100 and CheckValid(RightPos) then cmd:SetSideMove(math.max(0,cmd:GetSideMove())) end
        if Left > 100 and CheckValid(LeftPos) then cmd:SetSideMove(math.min(0,cmd:GetSideMove())) end
      end
    end

  end)
end