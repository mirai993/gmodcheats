MODULE.ID = "com.continuum.binds"
MODULE.Dependencies = { }

MODULE.Name = "Bind+"
MODULE.Info = "Improves the bind command in a new command, bind+. Allows you to bind a combination of keys, and also allows for different slots"

MODULE.Init = function(CE)
  local BIND_FILE = "multibinds.txt";
  local IsChatOpen = false
  local reserved = { }
  local PM = FindMetaTable("Player")
  if not CE.Session._IsKeyDown then
  	CE.Session._IsKeyDown = input.IsKeyDown
  end
  function input.IsKeyDown(key)
  	--print("INPUT CALL for "..key)
  	if reserved[key] then
  		return false
  	end
  	return CE.Session._IsKeyDown(key)
  end
  if not PM._KeyDown then
  	PM._KeyDown = PM.KeyDown
  end
  function PM:KeyDown(key)
  	--print("PM CALL")
  	if reserved[key] then
  		return false
  	end
  	return self:_KeyDown(key)
  end
  local MultiBinds = CE.Save["Bind+"] or { }
  MultiBinds["key_f10"] = { none={} }
  MultiBinds["key_f10"]["none"][1] = function(pressed)
  	if pressed then
  		CE.Session.ConsoleFrame:SetVisible(not CE.Session.ConsoleFrame:IsVisible())
  	end
  end
  local function save()
  	CE.Save["Bind+"] = MultiBinds
  end
  --MultiBinds = { }
  local keys = { none=0, player_death=0 }
  for _,v in pairs(_G) do
  	_ = _:lower();
  	if _:starts("key_") and _ ~= "key_none" or _:starts("mouse_") and _ ~= "mouse_none" then
  		keys[_]=v
  	end
  end
  local oldTestResults = { }
  local function RunTest(test)
  	local ply = LocalPlayer()
  	local ret = false
  	if test:lower():starts("key_") and keys[test:lower()] then
  		ret = not input.IsKeyTrapping() and CE.Session._IsKeyDown(keys[test:lower()])
  	elseif test:lower():starts("mouse_") and keys[test:lower()] then
  		ret = input.IsButtonDown(keys[test:lower()])
  	elseif test:lower() == "player_death" then
  		ret = not ply:Alive()
  	elseif test:lower() == "player_spawn" then
  		ret = ply:Alive()
  	elseif test:lower() == "none" or test:lower() == "key_none" then
  		ret = true
  	else
  		ret = false
  	end
  	return ret
  end
  
  concommand.Add("bind+", function(ply,name,args)
  	if #args == 0 then
  		print("Bind table:")
  		PrintTable(MultiBinds)
  		return
  	end
  	if #args < 2 then
  		print("At least 2 arguments or none required; "..#args.." found")
  		return
  	end
  	local key1 = args[1]
  	local key2 = args[2]
  	local slot = #args>=3 and (tonumber(args[3]) or 1) or nil
  	local cmd = ""
  	local vargs = { }
  	for _,val in pairs(args) do
  		if _ > 3 then
  			vargs[_-3]=val
  		end
  	end
  	if not slot then
  		MultiBinds[key1] = MultiBinds[key1] or { }
  		MultiBinds[key1][key2]=MultiBinds[key1][key2] or { }
  		print("Bind table for "..key1.." and "..key2..":")
  		if #MultiBinds[key1][key2] == 0 then
  			print("[empty]")
  		else
  		PrintTable(MultiBinds[key1][key2])
  		end
  	elseif #vargs < 1 then
  		MultiBinds[key1] = MultiBinds[key1] or { }
  		MultiBinds[key1][key2]=MultiBinds[key1][key2] or { }
  		print("Bind for "..key1.." and "..key2.." slot #"..slot..":")
  		print(string.join(" ", MultiBinds[key1][key2][slot] or ""))
  		
  	elseif #vargs == 1 and vargs[1]=="" then
  		MultiBinds[key1] = MultiBinds[key1] or { }
  		MultiBinds[key1][key2]=MultiBinds[key1][key2] or { }
  		MultiBinds[key1][key2][slot]=nil
  	else
  		MultiBinds[key1] = MultiBinds[key1] or { }
  		MultiBinds[key1][key2]=MultiBinds[key1][key2] or { }
  		MultiBinds[key1][key2][slot]=vargs
  	end
  	save();
  	
  end, function(name, args)
  	args = args:sub(2)
  	if args:ends(" ") then
  	args = string.split(args, " ")
  	args[#args+1]=""
  	else
  	args = string.split(args, " ")
  	end
  	local res = { }
  	local str = name.." "
  	args[1] = args[1] or ""
  	if #args <= 1 then
  		for _,val in CE.PairsByKeys(keys) do
  			if _:starts(args[1]) then
  				table.insert(res, str.._)
  			end
  		end
  	else
  		str = str..args[1].." "
  		if #args <= 2 then
  			for _,val in CE.PairsByKeys(keys) do
  				if _:starts(args[2]) then
  					table.insert(res, str.._)
  				end
  			end
  		elseif #args == 3 then
  			res = { str..args[2].." [slot#]" }
  		else
  			res = { str..args[2].." "..args[3].." [bind]" }
  		end
  	end
  	return res
  end)
  local function BindThink()
  	--if IsChatOpen then return end
  	if vgui.GetKeyboardFocus() ~= nil then return end
  	if gui.IsGameUIVisible() then return end
  	--Multibinds = { [key1]={[key2]={5,[key2]=6,[key2]=7 }   }
  	local _reserved = { }
  	for test1,test2s in pairs(MultiBinds) do
  		for test2,cmds in pairs(test2s) do
  				local testsPass = true
  				local tests = {test1, test2}
  				for _,test in pairs(tests) do
  					if testsPass then
  						testsPass = RunTest(test)
  					end
  				end
  				oldTestResults[test1] = oldTestResults[test1] or { }
  				if testsPass and not oldTestResults[test1][test2] then
  					for _,cmd in pairs(cmds) do
  						if type(cmd) == "table" then
  							RunConsoleCommand(unpack(cmd))
  						elseif type(cmd) == "function" then
  							cmd(true)
  						end 
  					end
  				elseif not testsPass and oldTestResults[test1][test2] then
  					for _,cmd in pairs(cmds) do
  						if type(cmd) == "table" then
  							local cmda = table.clone(cmd)
  							if #cmda > 0 and cmda[1]:starts("+") then
  								cmda[1]="-"..cmda[1]:sub(2)
  								--print("Running: "..string.join(" ", cmda))
  								RunConsoleCommand(unpack(cmda)) 
  							end
  						elseif type(cmd) == "function" then
  							cmd(false)
  						end
  					end
  				end
  				oldTestResults[test1] = oldTestResults[test1] or { }
  				oldTestResults[test1][test2] = testsPass
  				if testsPass then
  					if test1:lower():starts("key_") and keys[test1:lower()] then
  						_reserved[keys[test1:lower()]] = true
  					end
  					if test2:lower():starts("key_") and keys[test2:lower()] then
  						_reserved[keys[test2:lower()]] = true
  					end
  				end
  		end
  	end
  	if reserved ~= _reserved then
  		reserved = _reserved
  	end
  end
  local function StartChatHook( teamsay )
  	IsChatOpen = true
  end
  
  --[[---------------------------------------------------------
     Name: gamemode:FinishChat()
  -----------------------------------------------------------]]
  local function FinishChatHook()
  	IsChatOpen = false
  end
  CE.Hook.Add("Think","CE.HacksKeyBinds",BindThink)
  CE.Hook.Add("StartChat","CE.Bind+StartChat",StartChatHook)
  CE.Hook.Add("FinishChat","CE.Bind+FinishChat",FinishChatHook)
end