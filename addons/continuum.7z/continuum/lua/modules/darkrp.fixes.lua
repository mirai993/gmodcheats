local CE = CE

MODULE.Enabled = true
MODULE.ID = "com.continuum.drp.fixes"
MODULE.Dependencies = { }

MODULE.Name = "DarkRP Fixes"
MODULE.Info = "Fixes up some things in DarkRP (i.e. adds chat receivers and entcontrol cmds)"

MODULE.Init = function(CE)
  local GM = GAMEMODE
  local PM = FindMetaTable("Player")
  if FPP then
    local function UpdateMenus()
      if IsValid(AdminPanel) then
        FPP.AdminMenu(AdminPanel)
      end
      if IsValid(BuddiesPanel) then
        FPP.BuddiesMenu(BuddiesPanel)
      end
    end
    CE.Hook.Add("SpawnMenuOpen", "FPPMenus", UpdateMenus)
  end
  -- bc some idiot servers dont even use this
  function PM:getDarkRPVar(name, default)
    if not self.DarkRPVars then return default end
    local val = self.DarkRPVars[name]
    if val == nil then val = default end
    return val
  end
  ---[[
  -- Let's add in the english language which doesn't exist for some reason
  -- ]]
  local rp_languages = DarkRP.addLanguage and CE.Debugger.GetUpvalue(DarkRP.addLanguage, 'rp_languages') or { }
  local selectedLanguage = GetConVarString("gmod_language") -- Switch language by setting gmod_language to another language

  function DarkRP.addLanguage(name, tbl)
    local old = rp_languages[name] or {}
    rp_languages[name] = tbl

    -- Merge the language with the translations added by DarkRP.addPhrase
    for k,v in pairs(old) do
      rp_languages[name][k] = v
    end
    LANGUAGE = rp_languages[name] -- backwards compatibility
  end

  function DarkRP.addPhrase(lang, name, phrase)
    print(name)
    rp_languages[lang] = rp_languages[lang]  or {}
    rp_languages[lang][name] = phrase
  end

  function DarkRP.getPhrase(name, ...)
    local langTable = rp_languages[selectedLanguage] or rp_languages.en
    local text = langTable[name] or rp_languages.en[name]
    if text == nil then
      text = "??" .. name .. "??"
      print("MISSING '" .. name .. "'")
    end
    return string.format(text, ...)
  end
  local english = {
    -- Other
    contents = "Contents",
    amount = "Amount",
    -- Admin things
    need_admin = "You need admin privileges in order to be able to %s",
    need_sadmin = "You need super admin privileges in order to be able to %s",
    no_jail_pos = "No jail position",
    invalid_x = "Invalid %s! %s",
    laws_of_the_land = "Laws of the Land",
    -- F1 menu
    mouse_wheel_to_scroll = "Use mousewheel to scroll",

    -- Money things:
    customer_price = "Customer price: ",
    reset_money = "%s has reset all player's money!",
    has_given = "%s has given you %s",
    you_gave = "You gave %s %s",
    npc_killpay = "%s for killing an NPC!",

    money_printer = "Money Printer",

    payday_message = "Payday! You received %s!",
    payday_unemployed = "You received no salary because you are unemployed!",
    payday_missed = "Pay day missed! (You're in jail!)",

    property_tax = "Property tax! %s",
    property_tax_cant_afford = "You couldn't pay the taxes! Your property has been taken away from you!",

    -- Players
    wanted = "Wanted by Police!\nReason: %s",
    youre_arrested = "You have been arrested for %d seconds!",
    hes_arrested = "%s has been arrested for %d seconds!",
    hes_unarrested = "%s has been released from jail!",
    health = "Health: %s",
    job = "Job: %s",
    salary = "Salary: %s%s",
    wallet = "Wallet: %s%s",
    warrant_request = "%s requests a search warrant for %s\nReason: %s",
    warrant_request2 = "Search warrant request sent to Mayor %s!",
    warrant_approved = "Search warrant approved for %s!",
    warrant_approved2 = "You are now able to search his house.",
    warrant_denied = "Mayor %s has denied your search warrant request.",
    warrant_expired = "The search warrant for %s has expired!",
    wanted_by_police = "%s is wanted by the police!\nReason: %s\nOrdered by: %s",
    wanted_by_police_print = "%s has made %s wanted, reason: %s",
    wanted_expired = "%s is no longer wanted by the Police.",
    wanted_revoked = "%s is no longer wanted by the Police.\nRevoked by: %s",
    rpname_changed = "%s changed their RPName to: %s",

    -- Teams
    need_to_be_before = "You need to be %s first in order to be able to become %s",
    need_to_make_vote = "You need to make a vote to become a %s!",
    team_limit_reached = "Can not become %s as the limit is reached",
    wants_to_be = "%s\nwants to be\n%s",
    has_not_been_made_team = "%s has not been made %s!",
    job_has_become = "%s has been made a %s!",

    -- Disasters
    meteor_approaching = "WARNING: Meteor storm approaching!",
    meteor_passing = "Meteor storm passing.",
    meteor_enabled = "Meteor Storms are now enabled.",
    meteor_disabled = "Meteor Storms are now disabled.",
    earthquake_report = "Earthquake reported of magnitude %sMw",
    earthtremor_report = "Earth tremor reported of magnitude %sMw",

    -- Keys, vehicles and doors
    keys_allowed_to_coown = "You are allowed to co-own this\n(Press Reload with keys or press F2 to co-own)\n",
    keys_other_allowed = "Allowed to co-own:\n%s\n",
    keys_allow_ownership = "(Press Reload with keys or press F2 to allow ownership)",
    keys_disallow_ownership = "(Press Reload with keys or press F2 to disallow ownership)",
    keys_owned_by = "Owned by: ",
    keys_cops_and_mayor = "All cops and the mayor",
    keys_unowned = "Unowned\n(Press Reload with keys or press F2 to own)",
    keys_everyone = "(Press Reload with keys or press F2 to enable for everyone)",
    keys_cops = "(Press Reload with keys or press F2 to set to cops and mayor only)",
    door_unown_arrested = "You can not own or unown things while arrested!",
    door_unownable = "This door cannot be owned or unowned!",
    door_sold = "You have sold this for %s",
    door_already_owned = "This door is already owned by someone!",
    door_cannot_afford = "You can not afford this door!",
    door_hobo_unable = "You can not buy a door if you are a hobo!",
    vehicle_cannot_afford = "You can not afford this vehicle!",
    door_bought = "You've bought this door for %s%s",
    vehicle_bought = "You've bought this vehicle for %s%s",
    door_need_to_own = "You need to own this door in order to be able to %s",
    door_rem_owners_unownable = "You can not remove owners if a door is non-ownable!",
    door_add_owners_unownable = "You can not add owners if a door is non-ownable!",
    rp_addowner_already_owns_door = "%s already owns (or is already allowed to own) this door!",

    -- Talking
    hear_noone = "No-one can hear you %s!",
    hear_everyone = "Everyone can hear you!",
    hear_certain_persons = "Players who can hear you %s: ",

    whisper = "whisper",
    yell = "yell",
    advert = "[Advert]",
    radio = "radio",
    request = "(REQUEST!)",
    group = "(group)",

    -- Notifies
    disabled = "%s is disabled! %s",
    limit = "You have reached the %s limit!",
    have_to_wait = "You need to wait another %d seconds before using %s!",
    must_be_looking_at = "You need to be looking at a %s!",
    incorrect_job = "You do not have the right job to %s",
    unavailable = "This %s is unavailable",
    unable = "You are unable to %s. %s",
    cant_afford = "You can not afford this %s",
    created_x = "%s created a %s",
    cleaned_up = "Your %s were cleaned up.",
    you_bought_x = "You have bought a %s for %s",

    created_first_jailpos = "You have created the first jail position!",
    added_jailpos = "You have added one extra jail position!",
    reset_add_jailpos = "You have removed all jail positions and you have added a new one here.",
    created_spawnpos = "%s's spawn position created.",
    updated_spawnpos = "%s's spawn position updated.",
    do_not_own_ent = "You do not own this entity!",
    cannot_drop_weapon = "Can't drop this weapon!",
    team_switch = "Jobs switched successfully!",

    -- Misc
    could_not_find = "Could not find %s",
    f3tovote = "Hit F3 to vote",
    listen_up = "Listen up:", -- In rp_tell or rp_tellall
    nlr = "New Life Rule: Do Not Revenge Arrest/Kill.",
    reset_settings = "You have reset all settings!",
    must_be_x = "You must be a %s in order to be able to %s.",
    agenda_updated = "The agenda has been updated",
    job_set = "%s has set his/her job to '%s'",
    demoted = "%s has been demoted",
    demoted_not = "%s has not been demoted",
    demote_vote_started = "%s has started a vote for the demotion of %s",
    demote_vote_text = "Demotion nominee:\n%s", -- '%s' is the reason here
    lockdown_started = "The mayor has initiated a Lockdown, please return to your homes!",
    lockdown_ended = "The lockdown has ended",
    gunlicense_requested = "%s has requested %s a gun license",
    gunlicense_granted = "%s has granted %s a gun license",
    gunlicense_denied = "%s has denied %s a gun license",
    gunlicense_question_text = "Grant %s a gun license?",
    gunlicense_remove_vote_text = "%s has started a vote for the gun license removal of %s",
    gunlicense_remove_vote_text2 = "Revoke gunlicense:\n%s", -- Where %s is the reason
    gunlicense_removed = "%s's license has been removed!",
    gunlicense_not_removed = "%s's license has not been removed!",
    vote_specify_reason = "You need to specify a reason!",
    vote_started = "The vote is created",
    vote_alone = "You have won the vote since you are alone in the server.",
    jail_punishment = "Punishment for disconnecting! Jailed for: %d seconds.",
    admin_only = "Admin only!", -- When doing /addjailpos
    chief_or = "Chief or",-- When doing /addjailpos

    dead_in_jail = "You now are dead until your jail time is up!",
    died_in_jail = "%s has died in jail!",

    -- The lottery
    lottery_started = "There is a lottery! Participate for %s",
    lottery_entered = "You entered the lottery for %s",
    lottery_not_entered = "%s did not enter the lottery",
    lottery_noone_entered = "No-one has entered the lottery",
    lottery_won = "%s has won the lottery! He has won %s",

    -- Hungermod
    starving = "Starving!",

    -- F4menu
    -- Tab 1
    give_money = "Give money to the player you're looking at",
    drop_money = "Drop money",
    change_name = "Change your DarkRP name",
    go_to_sleep = "Go to sleep/wake up",
    drop_weapon = "Drop current weapon",
    buy_health = "Buy health(%s)",
    request_gunlicense = "Request gunlicense",
    demote_player_menu = "Demote a player",


    searchwarrantbutton = "Make a player wanted",
    unwarrantbutton = "Remove the wanted status from a player",
    noone_available = "No-one available",
    request_warrant = "Request a search warrant for a player",
    make_wanted = "Make someone wanted",
    make_unwanted = "Make someone unwanted",
    set_jailpos = "Set the jail position",
    add_jailpos = "Add a jail position",

    set_custom_job = "Set a custom job (press enter to activate)",

    set_agenda = "Set the agenda (press enter to activate)",

    initiate_lockdown = "Initiate a lockdown",
    stop_lockdown = "Stop the lockdown",
    start_lottery = "Start a lottery",
    give_license_lookingat = "Give <lookingat> a gun license",

    -- Second tab
    job_name = "Name: ",
    job_description = "Description: " ,
    job_weapons = "Weapons: ",

    -- Entities tab
    buy_a = "Buy %s: %s",

    -- Licenseweaponstab
    license_tab = [[License weapons
  
  	Tick the weapons people should be able to get WITHOUT a license!
  	]],
    license_tab_other_weapons = "Other weapons:",
  }
  if not rp_languages["en"] then
    DarkRP.addLanguage("en", english)
  end


  local prefix = "/"
  local IsTeamChat = false

  local receivers
  local currentChatText = {}
  local receiverConfigs = {
    [""] = { -- The default config decides who can hear you when you speak normally
      text = "talk",
      hearFunc = function(ply)
        if GAMEMODE.Config.alltalk then return nil end

        return LocalPlayer():GetPos():Distance(ply:GetPos()) < 250
      end
    }
  }

  local currentConfig = receiverConfigs[""] -- Default config is normal talk

  function GM:AddChatReceiver(prefix, text, hearFunc)
    receiverConfigs[prefix] = {
      text = text,
      hearFunc = hearFunc
    }
  end

  function GM:removeChatReceiver(prefix)
    receiverConfigs[prefix] = nil
  end

  local PM = FindMetaTable("Player")
  function PM:IsSpec()
    return self ~= LocalPlayer() and not self:Alive()
  end

  local function drawChatReceivers()
    if not receivers then return end

    local x, y = chat.GetChatBoxPos()
    y = y - 21

    -- No one hears you
    if #receivers == 0 then
      draw.WordBox(2, x, y, "No-one can hear you "..currentConfig.text.."!", "DarkRPHUD1", Color(0,0,0,160), Color(255,0,0,255))
      return
      -- Everyone hears you
    elseif #receivers == #player.GetAll() - 1 then
      draw.WordBox(2, x, y, "Everyone can hear you "..currentConfig.text, "DarkRPHUD1", Color(0,0,0,160), Color(0,255,0,255))
      return
    end

    draw.WordBox(2, x, y - (#receivers * 21), "Players who can hear you "..currentConfig.text..':', "DarkRPHUD1", Color(0,0,0,160), Color(0,255,0,255))
    for i = 1, #receivers, 1 do
      if not IsValid(receivers[i]) then
        receivers[i] = receivers[#receivers]
        receivers[#receivers] = nil
      else
        draw.WordBox(2, x, y - (i - 1)*21, receivers[i]:Nick(), "DarkRPHUD1", Color(0,0,0,160), Color(255,255,255,255))
      end
    end
  end


  local function chatGetRecipients()
    if not currentConfig then return end
    if IsTeamChat then
      currentConfig = receiverConfigs["/g"]
    end
    receivers = {}
    for _, ply in pairs(player.GetAll()) do
      if IsValid(ply) and ply ~= LocalPlayer() then
        local val = currentConfig.hearFunc(ply, currentChatText)

        -- Return nil to disable the chat recipients temporarily.
        if val == nil then
          receivers = nil
          return
        elseif val == true then
          table.insert(receivers, ply)
        end
      end
    end
  end


  local function startFind(group)
    currentConfig = receiverConfigs[""]
    IsTeamChat = group
    CE.Hook.Add("Think", "DarkRP_chatRecipients", chatGetRecipients)
    CE.Hook.Add("HUDPaint", "DarkRP_DrawChatReceivers", drawChatReceivers)
  end
  CE.Hook.Add("StartChat", "DarkRP_StartFindChatReceivers", startFind)


  local function stopFind()
    IsTeamChat = false
    CE.Hook.Remove("Think", "DarkRP_chatRecipients")
    CE.Hook.Remove("HUDPaint", "DarkRP_DrawChatReceivers")
  end
  CE.Hook.Add("FinishChat", "DarkRP_StopFindChatReceivers", stopFind)


  local function findConfig(text)
    if IsTeamChat then return end
    local split = string.Explode(' ', text)
    local prefix = string.lower(split[1])

    currentChatText = split

    currentConfig = receiverConfigs[prefix] or receiverConfigs[""]
  end
  CE.Hook.Add("ChatTextChanged", "DarkRP_FindChatRecipients", findConfig)



  GM:AddChatReceiver("/ooc", "speak in OOC", function(ply) return true end)
  GM:AddChatReceiver("//", "speak in OOC", function(ply) return true end)
  GM:AddChatReceiver("/a", "speak in OOC", function(ply) return true end)
  GM:AddChatReceiver("/w", "whisper", function(ply) return LocalPlayer():GetPos():Distance(ply:GetPos()) < 90 end)
  GM:AddChatReceiver("/y", "yell", function(ply) return LocalPlayer():GetPos():Distance(ply:GetPos()) < 550 end)
  GM:AddChatReceiver("/me", "perform your action", function(ply) return LocalPlayer():GetPos():Distance(ply:GetPos()) < 250 end)
  GM:AddChatReceiver("/g", "talk to your group", function(ply)
    for _, func in pairs(GAMEMODE.DarkRPGroupChats) do
      if func(LocalPlayer()) and func(ply) then
        return true
      end
    end
    return false
  end)

  GM:AddChatReceiver("/pm", "PM", function(ply, text)
    if not isstring(text[2]) then return false end
    text[2] = string.lower(tostring(text[2]))

    return string.find(string.lower(ply:Nick()), text[2], 1, true) ~= nil or
      string.find(string.lower(ply:SteamName()), text[2], 1, true) ~= nil or
      string.lower(ply:SteamID()) == text[2]
  end)


  GM:AddChatReceiver("speak", "speak", function(ply)
    if not LocalPlayer().DRPIsTalking then return nil end
    if LocalPlayer():GetPos():Distance(ply:GetPos()) > 550 then return false end

    return not GAMEMODE.Config.dynamicvoice or ply:IsInRoom()
  end)

  function PM:IsSpeaking()
    return self._IsSpeaking
  end
  local function startFindVoice(ply)
    ply._IsSpeaking = true
    if ply ~= LocalPlayer() then return end

    currentConfig = receiverConfigs["speak"]
    CE.Hook.Add("Think", "DarkRP_chatRecipients", chatGetRecipients)
    CE.Hook.Add("HUDPaint", "DarkRP_DrawChatReceivers", drawChatReceivers)
  end
  CE.Hook.Add("PlayerStartVoice", "DarkRP_VoiceChatReceiverFinder", startFindVoice)


  local function stopFindVoice(ply)
    ply._IsSpeaking = false
    if ply ~= LocalPlayer() then return end

    stopFind()
  end
  CE.Hook.Add("PlayerEndVoice", "DarkRP_VoiceChatReceiverFinder", stopFindVoice)

  -- THE FOLLOWING FUNCTION IS REMOVED IN REFACTOR BRANCH
  local meta = FindMetaTable("Player")
  function meta:IsInRoom()
    local tracedata = {}
    tracedata.start = LocalPlayer():GetShootPos()
    tracedata.endpos = self:GetShootPos()
    local trace = util.TraceLine(tracedata)

    return not trace.HitWorld
  end




  local DarkRPCommands = { }
  function AddCEDarkRPCommand(CommandName, Arguments)
    if not Arguments then Arguments = { } end
    if not Arguments.ExtraArgs then Arguments.ExtraArgs = { } end
    DarkRPCommands[CommandName]=Arguments
  end
  AddCEDarkRPCommand("pm", {ExtraArgs={"<Player>", "<text>"}})
  AddCEDarkRPCommand("ooc", {ExtraArgs={"<text>"}})
  AddCEDarkRPCommand("/", {ExtraArgs={"<text>"}})
  AddCEDarkRPCommand("splitshipment", {ExtraArgs={"[id]"}})
  AddCEDarkRPCommand("makeshipment", {ExtraArgs={"[id]"}})
  AddCEDarkRPCommand("drop")
  AddCEDarkRPCommand("dropmoney", {ExtraArgs={"<amount>"}})
  AddCEDarkRPCommand("wanted", {ExtraArgs={"<Player>", "<reason>"}})
  AddCEDarkRPCommand("warrant", {ExtraArgs={"<Player>", "<reason>"}})
  for k,v in pairs(DarkRPEntities) do
    if v.cmd then
      AddCEDarkRPCommand(v.cmd:sub(2), {ExtraArgs={}, Condition=function()
        return not v.allowed or table.containsValue(v.allowed, LocalPlayer():Team())
      end})
    end
  end
  local function PlayerConnect( name, address )
    chat.AddText( "Player " .. name .. " has joined from ip " .. address )
  end
  local function userAuthed( ply, stid, unid )
    print("Player "..ply:Name().." ("..stid.." - "..unid..") is authed")
  end
  CE.Hook.Add( "PlayerAuthed", "CE.Auth", userAuthed )
  CE.Hook.Add( "PlayerConnect", "CE.Connect", PlayerConnect )
  function GM:PlayerConnect( name, address )
    print( "GM: Player " .. name .. " has joined from ip " .. address )
  end
  GM:AddChatReceiver("@", "admin talk", function(ply) return ply:IsAdmin() end)
  GM:AddChatReceiver("/advert", "advertise", function(ply) return true end)


  local Options = {}
  local targets
  surface.CreateFont("UiBold", {
    size = 16,
    weight = 800,
    antialias = true,
    shadow = false,
    font = "Default"})
  CE.Hook.Add("ChatTextChanged", "FAdmin_Chat_autocomplete", function(text)
    if string.sub(text, 1, 1) ~= prefix then targets = nil return end
    Options = {}

    local TExplode = string.Explode(" ", string.sub(text, 2))
    if not TExplode[1] then return end
    local Command = string.lower(TExplode[1])
    local Args = table.Copy(TExplode)
    Args[1] = nil
    Args = table.ClearKeys(Args)


    local optionsCount = 0
    local MergedCommands = { }
    if FAdmin and FAdmin.GlobalSetting.FAdmin then
      for k,v in pairs(FAdmin.Commands.List) do
        MergedCommands[k]=v
      end
    end
    for k,v in pairs(DarkRPCommands) do
      MergedCommands[k]=v
    end
    for k,v in CE.PairsByKeys(MergedCommands) do
      if ((#TExplode > 1 and k:lower() == Command) or (#TExplode == 1 and k:lower():starts(Command))) and (not v.Condition or v.Condition()) then
        Options["/" .. k] = table.Copy(v.ExtraArgs)
        optionsCount = optionsCount + 1
      end
    end

    local ChatBoxPosX, ChatBoxPosY = chat.GetChatBoxPos()
    local DidMakeShorter = false
    table.sort(Options)
    local i = 1
    for k,v in pairs(Options) do
      local Pos = ChatBoxPosY + i*24
      if Pos + 24 > ScrH() then
        Options[k] = nil
        DidMakeShorter = true
        optionsCount = optionsCount - 1
      end
      i = i + 1
    end

    -- Player arguments
    local firstVal = table.GetFirstValue(Options)
    if optionsCount == 1 and firstVal[#Args] and string.match(firstVal[#Args], ".Player.") then
      local players = {}

      for k,v in pairs(FAdmin.FindPlayer(Args[#Args]) or {}) do
        if IsValid(v) then
          table.insert(players, v:Nick())
        end
      end

      targets = table.concat(players, ", ")
    end

    local xPos = (ChatBoxPosX == 12 and 412) or (ChatBoxPosX == 22 and 745) or (ChatBoxPosX == 21 and 741) or 526
    CE.Hook.Add("HUDPaint", "FAdmin_Chat_autocomplete", function()
      local i = 0
      for option, args in pairs(Options) do
        draw.WordBox(4, xPos, ChatBoxPosY + i*24, option, "UiBold", Color(0,0,0,200), Color(255,255,255,255))
        for k, arg in pairs(args) do
          draw.WordBox(4, xPos + k * 130, ChatBoxPosY + i*24, arg, "UiBold", Color(0,0,0,200), Color(255,255,255,255))
        end
        i = i + 1
      end

      if targets then
        draw.WordBox(4, xPos, ChatBoxPosY + i*24, "Targets: " .. targets, "UiBold", Color(255,125,0,200), Color(255,255,255,255))
      end
      if DidMakeShorter then
        draw.WordBox(4, xPos, ChatBoxPosY + i*24, "...", "UiBold", Color(0,0,0,200), Color(255,255,255,255))
      end
    end)
  end)

  CE.Hook.Add("FinishChat", "FAdmin_Chat_autocomplete", function() CE.Hook.Remove("HUDPaint", "FAdmin_Chat_autocomplete") end)
  local i = 1
  CE.Hook.Add("OnChatTab", "FAdmin_Chat_autocomplete", function(text)
    if #Options > 0 and not string.find(text, " ") then
      chat.AddText("Message: "..string.sub(Options[1], 1, string.find(Options[1], " ")))
      return string.sub(Options[1], 1, string.find(Options[1], " "))
    elseif #Options > 0 and string.find(text, " ") then
      chat.AddText("Message2: "..string.sub(Options[1], 1, string.find(Options[1], " ")))
      i = i + 1
      if i > #player.GetAll() then i = 1 end

      return string.sub(Options[1], 1, string.find(Options[1], " "))..string.sub(player.GetAll()[i]:Nick(), 1, string.find(player.GetAll()[i]:Nick(), " "))
    end
  end)

  local meta = FindMetaTable("Entity")
  local plyMeta = FindMetaTable("Player")

  function meta:isKeysOwnable()
    if not IsValid(self) then return false end
    local class = self:GetClass()

    if ((class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating") or
      (GAMEMODE.Config.allowvehicleowning and self:IsVehicle() and (not IsValid(self:GetParent()) or not self:GetParent():IsVehicle()))) then
      return true
    end
    return false
  end

  function meta:isDoor()
    if not IsValid(self) then return false end
    local class = self:GetClass()

    if class == "func_door" or
      class == "func_door_rotating" or
      class == "prop_door_rotating" or
      class == "prop_dynamic" then
      return true
    end
    return false
  end

  function meta:doorIndex()
    return self:CreatedByMap() and self:MapCreationID() or nil
  end

  function DarkRP.doorToEntIndex(num)
    local ent = ents.GetMapCreatedEntity(num)

    return IsValid(ent) and ent:EntIndex() or nil
  end

  function DarkRP.doorIndexToEnt(num)
    return ents.GetMapCreatedEntity(num) or NULL
  end

  function meta:getDoorData()
    local doorData
    if DarkRP.doorData then
      doorData = DarkRP.doorData[self:EntIndex()] or {}
      self.DoorData = doorData -- Backwards compatibility
    else
      doorData=self.DoorData
    end
    return doorData
  end
  function meta:isKeysOwned()
    if IsValid(self:getDoorOwner()) then return true end

    return false
  end

  function meta:getDoorOwner()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.Owner or doorData.owner
  end

  function meta:isMasterOwner(ply)
    return ply == self:getDoorOwner()
  end

  function meta:isKeysOwnedBy(ply)
    if self:isMasterOwner(ply) then return true end

    local coOwners = self:getKeysCoOwners()
    return coOwners and coOwners[ply:UserID()] or false
  end

  function meta:isKeysAllowedToOwn(ply)
    local doorData = self:getDoorData()
    if not doorData then return false end

    return doorData.allowedToOwn and doorData.allowedToOwn[ply:UserID()] or false
  end

  function meta:getKeysNonOwnable()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.nonOwnable
  end

  function meta:getKeysTitle()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.title
  end

  function meta:getKeysDoorGroup()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.groupOwn
  end

  function meta:getKeysDoorTeams()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.teamOwn
  end

  function meta:getKeysAllowedToOwn()
    local doorData = self:getDoorData()
    if not doorData then return nil end

    return doorData.allowedToOwn
  end
  function meta:getKeysCoOwners()
    local doorData = self:getDoorData()
    if not doorData then return nil end
    if doorData.AllowedToOwn then
      local plys
      if type(doorData.AllowedToOwn) == "string" then
        plys = doorData.AllowedToOwn:split(";")
      else
        plys =  { tostring(doorData.AllowedToOwn) }
      end 
      for _,uid in pairs(plys) do
        plys[_] = player.GetAll()[uid]
      end
      return plys
    end
    return doorData.extraOwners
  end

  local function canLockUnlock(ply, ent)
    local Team = ply:Team()
    local group = ent:getKeysDoorGroup()
    local teamOwn = ent:getKeysDoorTeams()

    return ent:isKeysOwnedBy(ply)                       or
      (group   and table.HasValue(RPExtraTeamDoors[group] or {}, Team)) or
      (teamOwn and teamOwn[Team])
  end

  function plyMeta:canKeysLock(ent)
    local canLock = hook.Run("canKeysLock", self, ent)

    if canLock ~= nil then return canLock end
    return canLockUnlock(self, ent)
  end

  function plyMeta:canKeysUnlock(ent)
    local canUnlock = hook.Run("canKeysUnlock", self, ent)

    if canUnlock ~= nil then return canUnlock end
    return canLockUnlock(self, ent)
  end


  MODULE.AddCmd({
    Name = "hacks_entcontrol",
    Nick = "Ent control",
    Function = function()
      local ent = worldedit_selection
      local window = vgui.Create("DFrame")
      window:SetSize( 320, 400 )
      window:SetTitle( tostring( ent ) )
      window:Center()
      window:SetSizable( true )

      local control = window:Add( "DEntityProperties" )
      control:SetEntity( ent )
      control:Dock( FILL )
      control.OnEntityLost = function()
        window:Remove()
      end
      window:MakePopup()
    end
  })
  MODULE.AddCmd({
    Name = "hacks_gravity",
    Nick = "Gravity",
    Info = "Toggles an entity's gravity",
    Function = function()
      local trace = util.GetPlayerTrace( LocalPlayer() )
      local tr = util.TraceLine( trace )
      if not tr.Entity then console.Warning("No entity found at crosshairs!") return end
      net.Start( "properties" )
      net.WriteUInt( util.NetworkStringToID( "gravity" ), 32 )
      net.WriteEntity( tr.Entity )
      net.SendToServer()
    end
  })
end
