MODULE.ID = "com.continuum.ttt.stats"
MODULE.Dependencies = { }

MODULE.Name = "TTT Stats"
MODULE.Info = "Gives info about your TTT rounds"

MODULE.Init = function(CE)
  local ServerIP = GetHostName()
  local ServersData = CE.GetPersistant("ServersData",{})
  local ServerData = ServersData[ServerIP] or { }

  --GUI:
  local IsReload = CE.Session.StatsFrame and true or false
  if IsReload then CE.Session.StatsFrame:Remove(); end
  local StatsFrame = vgui.Create("DFrame")
  CE.Session.StatsFrame = StatsFrame
  StatsFrame:SetSize(400, 640)
  StatsFrame:SetTitle( "TTT Statistics" )
  StatsFrame:SetDraggable( true )
  StatsFrame:ShowCloseButton( true )
  StatsFrame:MakePopup()
  StatsFrame:Center()
  StatsFrame:SetSizable(false)
  StatsFrame:SetVisible(false)
  local Avatar = vgui.Create( "AvatarImage", StatsFrame )
  Avatar:SetPos(10, 35)
  Avatar:SetSize(65,65)
  Avatar:SetPlayer(LocalPlayer())
  function StatsFrame:Paint()
    surface.SetDrawColor(Color(0,0,0,225))
    surface.DrawRect(0,0,400,23)
    surface.DrawRect(0,28,400,80)
    surface.DrawRect(0,115,400,160)
    surface.DrawRect(0,280,400,360)

    -- top right
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.DETECTIVE))
    surface.DrawRect(177,155, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.TRAITOR))
    surface.DrawRect(177+75,155, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.INNOCENT))
    surface.DrawRect(177+75+75,155, 65, 65)

    -- middle left
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.TRAITOR))
    surface.DrawRect(70,318, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.INNOCENT))
    surface.DrawRect(31,410, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.DETECTIVE))
    surface.DrawRect(31+75,410, 65, 65)

    -- middle right

    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.TRAITOR))
    surface.DrawRect(270,410, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.INNOCENT))
    surface.DrawRect(230,318, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.DETECTIVE))
    surface.DrawRect(230+75,318, 65, 65)

    -- bottom left
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.TRAITOR))
    surface.DrawRect(70,537, 65, 65)

    -- bottom right
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.INNOCENT))
    surface.DrawRect(230,537, 65, 65)
    surface.SetDrawColor(CE.Colors.Darker(CE.Colors.DETECTIVE))
    surface.DrawRect(230+75,537, 65, 65)


    -- TODO: Add text


    --surface.SetTextPos( self:GetWide() / 2 - 10, self:GetTall() / 2 - 8)
    --surface.SetFont("DermaDefault")
    --surface.DrawText(BatteryText)
  end
  function StatsFrame:Close()
    self:SetVisible(false)
  end

  -- Actual code:
  function ScoreInit()
    return {
      deaths=0,
      suicides=0,
      innos=0,
      traitors=0,
      detectives=0,
      was_traitor=false,
      bodies=0,
      bonus=0 -- non-kill points to add
    };
  end
  function ScoreEvent(e, scores)
    if e.id == EVENT_KILL then
      local aid = e.att.uid
      local vid = e.vic.uid

      -- make sure a score table exists for this person
      -- he might have disconnected by now
      if scores[vid] == nil then
        scores[vid] = ScoreInit()

        -- normally we have the ply:GetTraitor stuff to base this on, but that
        -- won't do for disconnected players
        scores[vid].was_traitor = e.vic.tr
      end
      if scores[aid] == nil then
        scores[aid] = ScoreInit()
        scores[aid].was_traitor = e.att.tr
      end

      scores[vid].deaths = scores[vid].deaths + 1

      if aid == vid then
        scores[vid].suicides = scores[vid].suicides + 1
      elseif aid ~= -1 then
        if e.vic.tr then
          scores[aid].traitors = scores[aid].traitors + 1
        elseif scores[vid].was_detective then
          scores[aid].innos = scores[aid].innos + 1
          scores[aid].detectives = scores[aid].detectives + 1
        elseif not e.vic.tr then
          scores[aid].innos = scores[aid].innos + 1
        end
      end
    elseif e.id == EVENT_BODYFOUND then
      local uid = e.uid
      if scores[uid] == nil or scores[uid].was_traitor then return end

      local find_bonus = scores[uid].was_detective and 3 or 1
      scores[uid].bonus = scores[uid].bonus + find_bonus
      scores[uid].bodies = scores[uid].bodies + 1
    end
  end

  if not CE.Session.CLSCORE_Init then CE.Session.CLSCORE_Init = CLSCORE.Init end
  function CLSCORE:Init(events)
    CE.Session.CLSCORE_Init(CLSCORE, events)
    local scores = CLSCORE.Scores
    local score = scores[LocalPlayer():UniqueID()]
    if score == nil then return end
    --PrintTable(score)
    -- {was_traitor, deaths, suicides, traitors, innos, was_detective, bonus}
    -- {were they a t, deathcount, suicide count, traitors killed count, innos killed count, was a d, bonus pts}
    local killsOnTAsInnoD = 0
    local killsOnInnoAsT = 0
    local killsOnDAsT = 0
    local killsAsT = 0
    local kills = 0
    local deaths = 0
    local traitorRounds = 0
    local detectiveRounds = 0
    local innocentRounds = 0
    local rdm = 0
    if score.was_traitor then
      traitorRounds = 1

      killsAsT = score.innos or 0
      killsOnDAsT = score.detectives or 0
      killsOnInnoAsT = killsAsT - killsOnDAsT
      rdm = rdm + score.traitors
    elseif score.was_detective then
      detectiveRounds = 1

      killsOnTAsInnoD = score.traitors or 0
      rdm = score.innos
    else -- innocent
      innocentRounds = 1

      killsOnTAsInnoD = score.traitors or 0
      rdm = score.innos
    end
    deaths = score.deaths or 0
    kills = (score.innos + score.traitors) or 0
    ServerData["k"] = (ServerData["k"] or 0) + kills -- Kills
    ServerData["d"] = (ServerData["d"] or 0) + deaths -- Deaths
    ServerData["tki"] = (ServerData["tki"] or 0) + killsOnInnoAsT -- Traitor --kill--> Inno
    ServerData["tkd"] = (ServerData["tkd"] or 0) + killsOnDAsT -- Traitor --kill--> Detective
    ServerData["idkt"] = (ServerData["idkt"] or 0) + killsOnTAsInnoD -- Inno/Detective --kill--> Traitor
    ServerData["tk"] = math.max(ServerData["tk"] or 0, killsAsT) -- Traitor --kill--> *
    ServerData["tr"] = (ServerData["tr"] or 0) + traitorRounds -- Traitor Rounds
    ServerData["dr"] = (ServerData["dr"] or 0) + detectiveRounds -- Detective Rounds
    ServerData["ir"] = (ServerData["ir"] or 0) + innocentRounds -- Innocent Rounds
    ServerData["rdm"] = (ServerData["rdm"] or 0) + rdm -- Innocent Rounds
    ServerData["r"] = (ServerData["r"] or 0) + 1 -- Total Rounds
    PrintTable(ServerData)
    ServersData[ServerIP] = ServerData
    CE.SetPersistant("ServersData", ServersData)
  end


  local function ProcessMatch(WinType)
  -- maybe ill use this in the future
  end
  hook.Add("TTTEndRound", "TTTStats", ProcessMatch)



  MODULE.AddCmd({
    Function = function()
      StatsFrame:SetVisible(not StatsFrame:IsVisible())
    end,
    Name="hacks_tttstats",
    Nick="TTT Stats",
    HUD={ Category="Misc", Type="CommandButton", IsOn=function() return StatsFrame:IsVisible() end}
  })
end