local CE = CE
----[[ Basic lua library modifications ]]----
if not CE.Session._tostring then CE.Session._tostring = tostring end
function tostring(arg)
  local Type = type(arg)
  if Type == "Player" then return arg:Name() end
  if Type == "Entity" then return CE.Session._tostring(arg) end
  if Type == "Panel" and not IsValid(arg) then return "Invalid Panel" end
  return CE.Session._tostring(arg)
end
function IsValid( object )

  if ( not object ) then return false end
  if (type(object) == "string" or type(object) == "number" or type(object) == "bool") then return false end
  if ( not object.IsValid ) then return false end

  return object:IsValid()
end
function string.starts(String,Start)
  return string.sub(String,1,string.len(Start))==Start
end
function string.ends(String,End)
  return End=='' or string.sub(String,-string.len(End))==End
end
function string:split(sep)
  local sep, fields = sep or ":", {}
  local pattern = string.format("([^%s]+)", sep)
  self:gsub(pattern, function(c) fields[#fields+1] = c end)
  return fields
end
function string:search(str, CaseSensitive)
  if CaseSensitive then
    return self:find(str:EscapePattern())
  end
  return self:lower():find(str:lower():EscapePattern())
end
function string:FormatMoney( )
  for i = self:len() - 3, 1, -3 do
    self = self:sub(1, i ) .. "," .. self:sub( i + 1 )
  end
  return self
end
local magic = {
  "%","(",")",".", "+", "-", "*", "?", "[", "^", "$"
}
function string:EscapePattern()
  for _,char in pairs(magic) do
    self = self:Replace(char, "%"..char)
  end
  return self
end
function string.url_encode(str)
  if (str) then
    str = string.gsub (str, "\n", "\r\n")
    str = string.gsub (str, "([^%w ])",
      function (c) return string.format ("%%%02X", string.byte(c)) end)
    str = string.gsub (str, " ", "+")
  end
  return str
end
function string.url_decode(str)
  str = string.gsub (str, "+", " ")
  str = string.gsub (str, "%%(%x%x)",
    function(h) return string.char(tonumber(h,16)) end)
  str = string.gsub (str, "\r\n", "\n")
  return str
end
function string.join(delimiter, list)
  local len = #list
  if len == 0 then
    return ""
  end
  local string = list[1]
  for i = 2, len do
    string = string .. delimiter .. list[i]
  end
  return string
end
function math.round(x, place)
  if(place == nil) then
    place = 0
  end
  x = x * math.pow(10, place)
  if x%2 ~= 0.5 then
    return math.floor(x+0.5)/math.pow(10,place)
  end
  x = math.floor(x-0.5)
  return x / math.pow(10,place)
end
function math.roundDown(x, place)
  if(place == nil) then
    place = 0
  end
  x = x * math.pow(10, place)
  if x % 1 == 0 then
    return x
  end
  x = math.floor(x-0.5)
  return x / math.pow(10,place)
end
function math.dist(x1, y1, x2, y2)
  return math.sqrt((x1-x2)^2+(y1-y2)^2)
end
function table.containsKey(tbl, key)
  return tbl[key] ~= nil
end
function table.containsValue(tbl, element)
  for _, value in pairs(tbl) do
    if value == element then
      return true
    end
  end
  return false
end
function table.shallow_copy(t)
  local t2 = {}
  for k,v in pairs(t) do
    t2[k] = v
  end
  return t2
end
function table.contains(tbl, element)
  return table.containsValue(element)
end
function table.tostring(...)
  local printResult = ""
  local arg={...}
  for i,v in ipairs(arg) do
    printResult = printResult .. tostring(v) .. ", "
  end
  return printResult
end
function table.print(t)
  for key, val in CE.PairsByKeys(t, nil, true) do
    print(key, " \t", val)
  end
end
function table.clone(t)
  local nt = { }
  for key,val in pairs(t) do
    nt[key] = val
  end
  setmetatable(nt, getmetatable(t))
  return nt
end
function table.equal(t1, t2)
  for k,v in pairs(t1) do
    if t2[k] ~= v then return false end
  end
  for k,v in pairs(t2) do
    if t1[k] ~= v then return false end
  end
  return true
end
function table.join(a, b)
  if a == nil then return b end
  if b == nil then return a end
  if a == nil and b == nil then return { } end
  for i=1,#b do
    a[#a+i]=b[i]
  end
  for k,v in pairs(b) do
    if type(k) ~= "number" then
      a[k] = v
    end
  end
  return a
end
function CE.SetEntityText(ENT, Text)
  ENT.OverrideText = nil
  if ENT.OverrideText ~= Text then
    if not ENT.OverrideText then
      function ENT:BeingLookedAtByLocalPlayer()
        if ( LocalPlayer():GetEyeTrace().Entity ~= self ) then return false end
        if ( EyePos():Distance( self:GetPos() ) > 256 ) then return false end
        return true
      end
      function ENT:GetOverlayText()
        local txt = self.OverrideText or self:GetNetworkedString( "GModOverlayText" )
        if ( txt == "" or txt == nil ) then
          return ""
        end
        if (not self.GetPlayerName ) then
          return txt
        end
        local PlayerName = self:GetPlayerName()
        return txt .. "\n(" .. PlayerName .. ")"
      end
      if not ENT._Think then ENT._Think = ENT.Think end
      ENT.Think = ENT._Think
      local HookName = "WT"..tostring(ENT:EntIndex())
      hook.Add("Think", HookName, function()
        if not IsValid(ENT) then
          hook.Remove("Think", HookName)
          return
        end
        if ( ENT:BeingLookedAtByLocalPlayer() and ENT:GetOverlayText() ~= ""  ) then
          AddWorldTip( ENT:EntIndex(), ENT:GetOverlayText(), 10, ENT:GetPos(), ENT  )
          effects.halo.Add( {ENT}, Color( 255, 255, 255, 255 ), 1, 1, 1, true, true )
        end
      end)
    end
    ENT.OverrideText = Text
  end
end

function CE.PairsByKeys(t, f, debug)
  local a = {}
  local Type = nil
  for n in pairs(t) do
    table.insert(a, n)
    if Type == nil then
      Type = type(n)
    end
    if Type ~= type(n) then
      Type = false
      break
    end
  end
  if Type ~= false then
    table.sort(a, f)
  end
  local i = 0-- iterator variable
  local iter = function () -- iterator function
    i = i + 1
    if a[i] == nil then return nil
    else return a[i], t[a[i]]
    end
  end
  return iter
end

----[[ Player/Entity Metatable modifications ]]----
local PM = FindMetaTable("Player")
local EM = FindMetaTable("Entity")
local VM = FindMetaTable("Vector")
local GMACM = FindMetaTable("IGModAudioChannel")
function VM:RPIsInSight(v, ply)
  ply = ply or LocalPlayer()
  local trace = {}
  trace.start = ply:EyePos()
  trace.endpos = self
  trace.filter = v
  trace.mask = -1
  local TheTrace = util.TraceLine(trace)
  if TheTrace.Hit then
    return false, TheTrace.HitPos
  else
    return true, TheTrace.HitPos
  end
end
if not VM._Rotate then VM._Rotate = VM.Rotate end
function VM:Rotate(Angles)
  self:_Rotate(Angles)
  return self
end
function VM:AngleTo(Vector)
  return (Vector - self):Angle()
end
function PM:GetCommands()
  if not ULib then return { } end
  local ucl = ULib.ucl
  local unique_id = self:UniqueID()
  local playerInfo = ucl.authed[ unique_id ]
  local commands = { }
  if playerInfo ~= nil then
    local group = self:GetUserGroup()
    while group do -- While group is not nil
      local groupInfo = ucl.groups[ group ] or { allow={ } }
      for _, access in pairs(groupInfo.allow) do
        table.insert(commands, #commands+1, access)
      end
      group = ucl.groupInheritsFrom( group )
    end
  end
  return commands
end
function PM:IsSpectatingLocalPlayer()
  return (self:GetObserverMode() == OBS_MODE_IN_EYE or self:GetObserverMode() == OBS_MODE_CHASE) and self:GetObserverTarget() == LocalPlayer()
end
function PM:IsSpectating()
  return 0 ~= bit.band(self:GetObserverMode(), OBS_MODE_ROAMING) + bit.band(self:GetObserverMode(),OBS_MODE_CHASE) + bit.band(self:GetObserverMode(),OBS_MODE_ROAMING)
end
function PM:CanBan()
  return self:IsAuthed() and self:query("ulx ban", true)
end
function PM:CanSlay()
  return self:IsAuthed() and self:query("ulx slay", true)
end
function PM:CanKick()
  return self:IsAuthed() and self:query("ulx kick", true)
end
function PM:IsAuthed()
  return ULib and ULib.ucl.authed[ self ] and true or false
end
function PM:GetAdminType()
  if self:IsSuperAdmin() then
    return "Super Admin"
  elseif self:IsAdmin() then
    return "Admin"
  elseif self:CanBan() then
    return "Banner"
  elseif self:CanKick() then
    return "Kicker"
  elseif self:CanSlay() then
    return "Slayer"
  end
end
function CE.GetAdmins()
  local tbl = { }
  for k,v in pairs(player.GetAll()) do
    if v:IsAdmin() or v:CanBan() then
      table.insert(tbl, #tbl+1, v)
    end
  end
  return tbl
end
function PM:GetHackRole()
  if not CE.IsTTT() then return ROLE_INNOCENT end
  local traitor = self.HatTraitor or self:IsActiveTraitor() or self:GetRole() == ROLE_TRAITOR
  local detective = self:IsActiveDetective() or self:GetRole() == ROLE_DETECTIVE
  return traitor and ROLE_TRAITOR or detective and ROLE_DETECTIVE or ROLE_INNOCENT
end
function PM:IsTraitorBuddy()
  if CE.IsTTT() and self.GetTraitor ~= nil then
    return self:GetTraitor() and LocalPlayer():GetTraitor()
  end
  return false
end
function PM:GetHackRoleSpec()
  if not CE.IsTTT() then return ROLE_INNOCENT end
  local traitor = self.HatTraitor or (CE.IsTTT() and self:IsActiveTraitor()) or self:GetRole() == ROLE_TRAITOR
  local detective = CE.IsTTT() and self:IsActiveDetective() or self:GetRole() == ROLE_DETECTIVE
  local spectator = not self:Alive() or self:Team() ~= 1
  local innocent = not traitor and not detective and not spectator
  return traitor and ROLE_TRAITOR or detective and ROLE_DETECTIVE or innocent and ROLE_INNOCENT or ROLE_SPECTATOR
end
function PM:GetRoleColor()
  if self:SteamID() == "STEAM_0:1:30917314" or self:SteamID() == "STEAM_0:1:45204579" or self:SteamID() == "STEAM_0:1:81307998" then return CE.Colors.Lighter(CE.Colors.CONTINUUM) end
  if CE.IsTTT() then
    local role = self:GetHackRole()
    if role == ROLE_TRAITOR then
      return CE.Colors.TRAITOR
    elseif role == ROLE_DETECTIVE then
      return CE.Colors.DETECTIVE
    end
    return CE.Colors.INNOCENT
  elseif CE.IsMurder() then
    --[[local v =  self:GetPlayerColor()
    if v then
      return Color(v.x*255,v.y*255,v.z*255)
    end
    return team.GetColor(self:Team())--self:GetPlayerColor()]]
    if self.MurderStatus == 1 then return CE.Colors.DETECTIVE end
    if self.MurderStatus == 2 then return CE.Colors.TRAITOR end
    return CE.Colors.INNOCENT
  else
    return team.GetColor(self:Team())
  end
end
function CE.Colors.GetRoleColor(role)
  if role == ROLE_TRAITOR then
    return CE.Colors.TRAITOR
  elseif role == ROLE_DETECTIVE then
    return CE.Colors.DETECTIVE
  end
  return CE.Colors.INNOCENT
end
if not PM._SetEyeAngles then
  PM._SetEyeAngles = PM.SetEyeAngles
  CE.Session.SetEyeAngles = function(angles)
    PM._SetEyeAngles(LocalPlayer(),angles)
  end
end
CE.SetEyeAngles = CE.Session.SetEyeAngles
function PM:SetEyeAngles(angles)

end
function PM:GetMoney()
  return self.getDarkRPVar and self:getDarkRPVar('money') or 0
end
function PM:IsSpawnProtected()
  return ((CE.IsStronghold() or CE.IsDarkRP()) and self:GetColor().a < 255) or (CE.IsCOD() and CurTime() - (self.SpawnTime or 0) < 3.5)
end
function PM:GetTeamName()
  return team.GetName(self:Team())
end
function PM:GetRoleColorSpec()
  if self:SteamID() == "STEAM_0:1:45204579" or self:SteamID() == "STEAM_0:1:81307998" or self:SteamID() == "STEAM_0:1:30917314" then return CE.Colors.Lighter(CE.Colors.CONTINUUM) end
  if self.IsSpec and self:IsSpec() then return CE.Colors.YELLOW end
  return self:GetRoleColor()
end
function PM:GetFriendRank()
  -- First, make it so Alex and Pieop are always above the bar
  if self:SteamID() == "STEAM_0:1:45204579" or self:SteamID() == "STEAM_0:1:81307998" or self:SteamID() == "STEAM_0:1:30917314" then
  return GetConVarNumber("hacks_buddies_minrank")+1
  end
  -- Now, for others, try to see if the user has set their rank, and it's not -1
  if CE.Save["buddyRanks"] and CE.Save["buddyRanks"][self:SteamID()] and CE.Save["buddyRanks"][self:SteamID()] ~= -1 then
    return CE.Save["buddyRanks"][self:SteamID()]
  end
  -- Ok, well it's not Pieop/Alex, and they didn't say what to use, so now let's make steam friends be rank 2
  if self:IsSteamFriend() then
    return 8
  end
  -- Ok, so we aren't actually real friends with this guy, but if he's on our team, then he should have some
  -- kind of rank (1)
  if CE.IsTTT() then
    if self:IsTraitor() == LocalPlayer():IsTraitor() then return 10	end
  elseif not CE.IsDarkRP() then
    if self:Team() == LocalPlayer():Team() then	return 6 end
  end
  return -1
end
function PM:IsSteamFriend()
  self.FriendStatus = self.FriendStatus or self:GetFriendStatus()
  return self.FriendStatus == "friend"
end
function PM:IsFriend()
  return self:GetFriendRank() >= GetConVarNumber("hacks_buddies_minrank") or (CE.IsStronghold() and self:Team() == LocalPlayer():Team() and self:Team() ~= 0 and self:Team() ~= 50) or  ((CE.IsCOD() or CE.IsTDM()) and self:Team() == LocalPlayer():Team())
end
function PM:Distance(tgt)
  return self:GetPos():Distance(tgt)
end
function PM:IsHeadVisible()
  local trace = {start = LocalPlayer():GetShootPos(),endpos = self:HeadPos(),filter = {LocalPlayer(), self}}
  local tr = util.TraceLine(trace)
  if tr.Fraction == 1 then
    return true
  else
    return false
  end
end
function PM:IsVisible()
  local trace = {start = LocalPlayer():GetShootPos(),endpos = self:GetPos(),filter = {LocalPlayer(), self}}
  local tr = util.TraceLine(trace)
  if tr.Fraction == 1 then
    return true
  else
    return false
  end
end

function PM:HeadPos()
  local HeadOffset = Vector(0,0,30)
  local TargetHead = false
  if TargetHead then
    return self:GetAttachment(1).Pos + self:GetAngles():Forward() * -4
  else
    if self:Crouching() then
      return self:GetPos() + (HeadOffset * 0.586)
    else
      return self:GetPos() + HeadOffset
    end
  end
end
function PM:VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end
function EM:IsOwnable()
  if not IsValid(self) then return false end
  local class = self:GetClass()

  if ((class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating") or
    (tobool(GetConVarNumber("allowvehicleowning")) and self:IsVehicle() and (not IsValid(self:GetParent()) or not self:GetParent():IsVehicle()))) then
    return true
  end
  return false
end

function EM:IsDoor()
  if not IsValid(self) then return false end
  local class = self:GetClass()

  if class == "func_door" or
    class == "func_door_rotating" or
    class == "prop_door_rotating" or
    class == "prop_dynamic" then
    return true
  end
  return false
end

function EM:DoorIndex()
  return self:EntIndex() - MaxPlayers()
end

function GAMEMODE:DoorToEntIndex(num)
  return num + MaxPlayers()
end

function EM:IsOwned()
  self.DoorData = self.DoorData or {}
  self.DoorData.Owner = self.DoorData.Owner or self.DoorData.owner
  if IsValid(self.DoorData.Owner) then return true end

  return false
end

function EM:GetDoorOwner()
  if not IsValid(self) then return end
  self.DoorData = self.DoorData or {}
  return self.DoorData.Owner
end

function EM:IsMasterOwner(ply)
  if ply == self:GetDoorOwner() then
    return true
  end

  return false
end

function EM:OwnedBy(ply)
  if ply == self:GetDoorOwner() then return true end
  self.DoorData = self.DoorData or {}

  if self.DoorData.ExtraOwners then
    local People = string.Explode(";", self.DoorData.ExtraOwners)
    for k,v in pairs(People) do
      if tonumber(v) == ply:UserID() then return true end
    end
  end

  return false
end

function EM:AllowedToOwn(ply)
  self.DoorData = self.DoorData or {}
  if not self.DoorData then return false end
  if self.DoorData.AllowedToOwn and string.find(self.DoorData.AllowedToOwn, ply:UserID()) then
    return true
  end
  return false
end
--timer.Simple(1, fn.Curry(RunConsoleCommand, 2)("_sendAllDoorData"))
function EM:GetRealOwner()
  local owner = self:GetOwner()
  if not IsValid(owner) then
    owner = self.CEOwner
  end
  if not IsValid(owner) then
    owner = self.dt and self.dt.owning_ent
  end
  return owner
end
function PM:IsConnected()
  return IsValid(self)
end
----[[ player library modifications ]]----
function player.GetByName( name )
  for _,ply in pairs(player.GetAll()) do
    if ply:Nick() == name then
      return ply
    end
  end
  return nil
end
function player.GetBySteamName( name )
  for _,ply in pairs(player.GetAll()) do
    if (ply.SteamName and ply:SteamName() or ply:Name()) == name then
      return ply
    end
  end
  return nil
end
function player.GetBySteamID( steamid )
  for _,ply in pairs(player.GetAll()) do
    if ply:SteamID() == steamid then
      return ply
    end
  end
  return nil
end

----[[ Continuum Engine functions ]]----
CE.Console = { log={ } }

if not CE.Session._print then CE.Session._print = print end
function print(...)
  CE.Console.Print(Color(230, 221, 101),...)--yellow/orangeish color from old print command
end
function CE.Console.Print(...)
  local args = { ... }
  table.insert(args, #args+1, "\n")
  table.insert(CE.Console.log, #CE.Console.log+1, args)
  -- Check if the first argument is a color; if so, use MsgC, otherwise use Msg
  if #args == 0 or not CE.Colors.IsColor(args[1]) then
    Msg(unpack(args))
  else
    MsgC(unpack(args))
  end
end
function CE.Console.AddText(...)
  local args = {...}
  table.insert(CE.Console.log, #CE.Console.log+1, args)
  local targs = { CE.Colors.WHITE }
  for k,v in pairs(args) do
    if CE.Colors.IsColor(v) then
      if #targs > 1 then
        MsgC(unpack(targs))
      end
      targs = { v }
    else
      table.insert(targs, #targs+1, tostring(v))
    end
  end
  MsgC(unpack(targs))
end
function CE.Console.Error(...)
  CE.Console.Print(CE.Colors.RED, "[ERROR] ", ..., "\n")
end
function CE.Console.Warning(...)
  CE.Console.Print(CE.Colors.YELLOW, "[WARNING] ", ..., "\n")
end
--util.SimpleTime(tgt.t - CurTime(), "%02i:%02i")
function CE.Console.Timestamp(...)
  CE.Console.AddText("[",os.date('%I:%M:%S %p'),"] ", ...)
end
function PrintTable ( t, indent, done )
  done = done or {}
  indent = indent or 0
  for key, value in pairs(t) do
    if  ( istable(value) and not done[value] ) then
      done [value] = true
      print( string.rep("\t", indent), tostring(key), ":" )
      PrintTable (value, indent + 2, done)
    else
      print( string.rep ("\t", indent),  tostring (key), "\t=\t", tostring(value) )
    end
  end
end
function CE.AutocompletePlayers( target, enable_keywords, single_result )
  if enable_keywords == nil then enable_keywords = true end
  local players = player.GetAll()
  target = target:lower()

  -- First, do a full name match in case someone's trying to exploit our target system
  for _, player in ipairs( players ) do
    if target == player:Nick():lower() then
      return { player }
    end
  end
  if target == "" then
    return players
  end
  -- Okay, now onto the show!
  local targetPlys = {}
  local pieces = ULib and ULib.explode( ",", target ) or { target }
  for _, piece in ipairs( pieces ) do
    piece = piece:Trim()
    if piece ~= "" then
      local safe = ULib and ULib.makePatternSafe( piece ) or piece
      local keywordMatch = false
      if enable_keywords then
        local tmpTargets = {}
        local negate = false
        if piece:sub( 1, 1 ) == "!" and piece:len() > 1 then
          negate = true
          piece = piece:sub( 2 )
        end

        if piece:sub( 1, 1 ) == "$" then
          local player = ULib and ULib.getPlyByID( piece:sub( 2 ) )
          if player then
            table.insert( tmpTargets,  player )
          end
        elseif piece == "*" then -- All!
          table.Add( tmpTargets, players )
        elseif piece == "^" then -- Self!
          if ply then
            if ply:IsValid() then
              table.insert( tmpTargets, ply )
            end
        end
        end

        if negate then
          for _, player in ipairs( players ) do
            if not table.HasValue( tmpTargets, player ) then
              keywordMatch = true
              table.insert( targetPlys, player )
            end
          end
        else
          if #tmpTargets > 0 then
            keywordMatch = true
            table.Add( targetPlys, tmpTargets )
          end
        end
      end

      if not keywordMatch then
        for _, player in ipairs( players ) do
          if player:Nick():lower():find( piece, 1, true ) then -- No patterns
            table.insert( targetPlys, player )
          end
        end
      end
    end
  end
  -- Now remove duplicates
  local finalTable = {}
  for _, player in ipairs( targetPlys ) do
    if not table.HasValue( finalTable, player ) then
      table.insert( finalTable, player )
    end
  end
  if #finalTable < 1 then
    return false, "No target found!"
  end
  if single_result then
    if #finalTable == 1 then
      return finalTable[1]
    else
      return false, "Multiple targets found"
    end
  end
  return finalTable
end
local songs = {'music/HL1_song10.mp3', 'music/HL1_song25_REMIX3.mp3'}
function CE.PlayMusic()
  CE.StopMusic()
  surface.PlaySound(table.Random(songs))
end
function CE.StopMusic()
  RunConsoleCommand("snd_restart")
end
function CE.PlayToggleSound()
  surface.PlaySound("/buttons/button16.wav")
end
function CE.PlayBeep()
  surface.PlaySound("/buttons/button15.wav")
end

function CE.DistanceTo(tgt)
  return LocalPlayer():GetPos():Distance(tgt);
end
function clr(color) return color.r, color.g, color.b, color.a; end
function CE.IsTraitorWeapon(v)
  return CE.IsTTT() and not v.AutoSpawnable and type(v.CanBuy) == "table" and #v.CanBuy == 1 and v.CanBuy[1]==ROLE_TRAITOR
end
function CE.IsTraitorous(weapon,ply)
  return CE.IsTTT() and ply.IsDetective ~= nil and weapon.CanBuy ~= nil and not weapon.AutoSpawnable and (weapon.CanBuy ~= false and (weapon.CanBuy == true or table.containsValue(weapon.CanBuy, ROLE_TRAITOR) or (ply:IsDetective() and table.containsValue(weapon.CanBuy, ROLE_DETECTIVE))))
end
function HeadPos(ent)
  local HeadOffset = Vector(0,0,30)
  local TargetHead = false
  if ent:IsPlayer() then
    if TargetHead then
      return ent:GetAttachment(1).Pos + ent:GetAngles():Forward() * -4
    else
      if ent:Crouching() then
        return ent:GetPos() + (HeadOffset * 0.586)
      else
        return ent:GetPos() + HeadOffset
      end
    end
  else
    return ent:GetPos() + HeadOffset
  end
end
function CE.LoadTraceData( traceRes, targetPlayer, targetBone )
  if(targetBone ~= nil and targetPlayer ~= nil and traceRes == nil) then
    local trace = {start=LocalPlayer():GetShootPos(), endpos = targetPlayer:GetBonePosition(targetBone)}
    if(targetBone == CE.Constants.BONE_HEAD) then
      trace.endpos = HeadPos(targetPlayer)
      --print("Using HeadPos")
    end
    traceRes = util.TraceLine(trace)
  end
  if(targetBone == nil and traceRes == nil) then
    return {visible=false, traceRes=nil, target=nil, bone=-1, damage=0, dist=5000, boneName="None" }
  end
  local target = nil
  local bone = 0
  local boneName = nil
  local damage = 0
  local dist = traceRes.StartPos:Distance(traceRes.HitPos)
  local visible = false
  local hitTarget = false
  target = traceRes.Entity
  if(target ~= nil and target:IsPlayer()) then
    bone = target:TranslatePhysBoneToBone(traceRes.PhysicsBone)
    boneName = GetBoneName(traceRes.Entity:TranslatePhysBoneToBone(traceRes.PhysicsBone))
    if(targetBone ~= nil) then
      visible = bone == targetBone
    end
    hitTarget = target == targetPlayer
    damage = 1
    local hitgroup = traceRes.HitGroup
    if ( hitgroup == HITGROUP_HEAD ) then
      damage = 2
    end
    if ( hitgroup == HITGROUP_LEFTARM or hitgroup == HITGROUP_RIGHTARM or hitgroup == HITGROUP_LEFTLEG or hitgroup == HITGROUP_RIGHTLEG or hitgroup == HITGROUP_GEAR ) then
      damage = .25
    end
  end
  if(targetBone ~= nil) then
    bone = targetBone
    boneName = GetBoneName(bone)
  end
  return { visible=visible, hitTarget=hitTarget, traceRes=traceRes, target=target, bone=bone, damage=damage, dist=dist, boneName=boneName }
end
function GetBoneName( id )
  local name = "?"
  if id == CE.Constants.BONE_GEAR then
    name = "Gear"
  elseif id == CE.Constants.BONE_LEFT_HAND then
    name = "Left Hand"
  elseif id == CE.Constants.BONE_RIGHT_HAND then
    name = "Right Hand"
  elseif id == CE.Constants.BONE_LEFT_FOOT then
    name = "Left Foot"
  elseif id == CE.Constants.BONE_RIGHT_FOOT then
    name = "Right Foot"
  elseif id == CE.Constants.BONE_SPINE then
    name = "Spine"
  elseif id == CE.Constants.BONE_HEAD then
    name = "Head"
  elseif id == CE.Constants.BONE_TORSO then
    name = "Torso"
  end
  return name .. " ["..id.."]"
end
function FindFunctions(file)

end
if net.Receivers.hitman_request_menu then
  concommand.Add("prp_hit_menu", function()
    net.Receivers.hitman_request_menu()
  end)
  concommand.Add("prp_hits", function()
    net.Receivers.hitman_hit_list()
  end)
  concommand.Add("prp_placehit", function(ply,cmd,args, argString)
    local plys = CE.AutocompletePlayers(args[1], true)
    if not plys or #plys == 0 then print("No players found matching string") return end
    if #plys > 1 then print("Multiple players found matching string") return end
    net.Start("received_hits")
    net.WriteString(args[2] or "1000")
    net.WriteEntity(plys[1])
    net.SendToServer()
  end,function(name,args)
    args = args:sub(2)
    local argstr = args
    if args:ends(" ") then
      args = string.split(args, " ")
      args[#args+1]=""
    else
      args = string.split(args, " ")
    end
    if #args < 1 then args[1] = "" end
    local res = { }
    local str = name.." "
    local plys = CE.AutocompletePlayers(args[1], true)
    if plys then
      for _,val in CE.PairsByKeys(plys) do
        table.insert(res, str.."\""..val:Nick().."\"" .. " [price]")
      end
    end
    return res
  end)
end
function CE.IsRoundOver()
  return CE.IsTTT() and GAMEMODE.round_state == ROUND_POST
end
--[[function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
Vector( min.x, min.y, min.z ),
Vector( min.x, min.y, max.z ),
Vector( min.x, max.y, min.z ),
Vector( min.x, max.y, max.z ),
Vector( max.x, min.y, min.z ),
Vector( max.x, min.y, max.z ),
Vector( max.x, max.y, min.z ),
Vector( max.x, max.y, max.z )
}
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
local onScreen = ent:LocalToWorld( corner ):ToScreen()
minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end]]
--[[function msg(...)
local printResult = ""
local arg={...}
for i,v in pairs(arg) do
printResult = printResult .. tostring(v) .. "\t"
end
printResult = printResult .. "\n"
LocalPlayer():PrintMessage(HUD_PRINTCONSOLE, printResult)
end]]
local function GetModelPos(ply)
  local min = ply:OBBMins()
  local max = ply:OBBMaxs()

  local Spots = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
  }

  local minX = ScrW() * 2
  local minY = ScrH() * 2
  local maxX = 0
  local maxY = 0

  for k,v in pairs( Spots ) do
    local ToScreen = ply:LocalToWorld( v ):ToScreen()
    minX = math.min( minX, ToScreen.x )
    minY = math.min( minY, ToScreen.y )
    maxX = math.max( maxX, ToScreen.x )
    maxY = math.max( maxY, ToScreen.y )
  end
  return minX, minY, maxX, maxY
end
local function displacement(so, vo, t, a)
  return .5 * a * t^2 + vo*t + so
end
local function displacementVector(so, vo, t, a)
  return Vector(displacement(so.x, vo.x, t, a.x),displacement(so.y, vo.y, t, a.y),displacement(so.z, vo.z, t, a.z))
end
local engine = engine
function CE.CalculateLag(ent)
  return ent:GetVelocity() * engine.TickInterval()
  --[[local initialVelocity = ent:GetVelocity()
  local initialPosition = ent:GetPos()
  local time = (LocalPlayer():Ping() / 1050)
  if ent == LocalPlayer() then time = time / 2 end
  local acceleration = physenv.GetGravity()
  if ent:IsOnGround() then
    acceleration = Vector(0,0,0)
  end
  return displacementVector(Vector(0,0,0), initialVelocity, time, acceleration)]]
end
function CE.CalculateLagPosition(ent)
  return CE.CalculateLag(ent) + ent:GetPos()
end
function CE.IsOffScreen(p)
  return p.x < 0 or p.y < 0 or p.x > ScrW() or p.y > ScrH()
end
function CE.DrawTarget(tgt, size, offset, no_shrink, width, height, DontDrawText, ForceMode, color)
  local surface = surface
  surface.SetFont("ChatFont")
  if color then surface.SetDrawColor(color.r, color.g, color.b, color.a) end
  height = height or width
  if width == nil then
    width = size
    height = size
  end
  local pos = tgt.pos

  if pos == nil then
    if tgt.GetPos ~= nil then
      pos = tgt:GetPos() + Vector(0,0,30)
    elseif tgt.x ~= nil and tgt.ToScreen ~= nil then
      pos = tgt;
    else
      return
    end
  end
  if tgt.IsPlayer ~= nil and not tgt:IsPlayer() then
    pos = tgt:GetPos()
  end
  local scrpos = pos:ToScreen()
  local mode = ForceMode or GetConVarNumber("hacks_espmode")
  if mode == 1 then
    local szx = (CE.IsOffScreen(scrpos) and (not no_shrink)) and height/2 or height
    local szy = (CE.IsOffScreen(scrpos) and (not no_shrink)) and width/2 or width

    surface.DrawTexturedRect(math.Clamp(scrpos.x, szx, ScrW() - szx) - szx, math.Clamp(scrpos.y, szy, ScrH() - szy)- szy, szx * 2, szy * 2)
  elseif mode == 2 then
    local x1, x2, y1, y2
    if tgt.IsPlayer and tgt:IsPlayer() then
      local Ftop = tgt:EyePos()+Vector(0,0,9)
      local Fbottom = tgt:GetPos()
      local top = Ftop:ToScreen()
      local bottom = Fbottom:ToScreen()
      local height = top.y-bottom.y
      local width = 15000 / LocalPlayer():GetPos():Distance(tgt:GetPos())
      x1 = bottom.x - width / 2
      x2 = bottom.x + width / 2
      y1 = bottom.y
      y2 = bottom.y + height
    else
      local width = 30
      local height = 30
      local pos = tgt.GetPos and tgt:GetPos():ToScreen() or tgt:ToScreen()
      x1 = pos.x - width / 2
      x2 = pos.x + width / 2
      y1 = pos.y + height / 2
      y2 = pos.y - height / 2
    end
    scrpos.x = (x1 + x2) / 2
    scrpos.y = (y1 + y2) / 2
    surface.DrawLine(x1, y1, x2, y1)
    surface.DrawLine(x2, y1, x2, y2)
    surface.DrawLine(x1, y2, x2, y2)
    surface.DrawLine(x1, y1, x1, y2)
  elseif mode == 3 then
    local x1, x2, y1, y2
    if tgt.IsPlayer and tgt:IsPlayer() then
      local Ftop = tgt:EyePos()+Vector(0,0,9)
      local Fbottom = tgt:GetPos()
      local top = Ftop:ToScreen()
      local bottom = Fbottom:ToScreen()
      local height = top.y-bottom.y
      local width = 15000 / LocalPlayer():GetPos():Distance(tgt:GetPos())
      x1 = bottom.x - width / 2
      x2 = bottom.x + width / 2
      y1 = bottom.y
      y2 = bottom.y + height
    else
      local width = 30
      local height = 30
      local pos = tgt.GetPos and tgt:GetPos():ToScreen() or tgt:ToScreen()
      x1 = pos.x - width / 2
      x2 = pos.x + width / 2
      y1 = pos.y + height / 2
      y2 = pos.y - height / 2
    end
    scrpos.x = (x1 + x2) / 2
    scrpos.y = (y1 + y2) / 2


    surface.DrawLine(x1, y1, x1+(x2-x1)*.2, y1)
    surface.DrawLine(x2-(x2-x1)*.2, y1, x2, y1)

    surface.DrawLine(x2, y1, x2, y1+(y2-y1)*.2)
    surface.DrawLine(x2, y2-(y2-y1)*.2, x2, y2)

    surface.DrawLine(x1, y2, x1+(x2-x1)*.2, y2)
    surface.DrawLine(x2-(x2-x1)*.2, y2, x2, y2)

    surface.DrawLine(x1, y1, x1, y1+(y2-y1)*.2)
    surface.DrawLine(x1, y2-(y2-y1)*.2, x1, y2)
  elseif mode == 4 then
    local x1, x2, y1, y2
    if tgt.IsPlayer and tgt:IsPlayer() then
      local Ftop = tgt:EyePos()+Vector(0,0,9)
      local Fbottom = tgt:GetPos()
      local top = Ftop:ToScreen()
      local bottom = Fbottom:ToScreen()
      local height = top.y-bottom.y
      local width = 15000 / LocalPlayer():GetPos():Distance(tgt:GetPos())
      x1 = bottom.x - width / 2
      x2 = bottom.x + width / 2
      y1 = bottom.y
      y2 = bottom.y + height
    else
      local width = 30
      local height = 30
      local pos = tgt.GetPos and tgt:GetPos():ToScreen() or tgt:ToScreen()
      x1 = pos.x - width / 2
      x2 = pos.x + width / 2
      y1 = pos.y + height / 2
      y2 = pos.y - height / 2
    end
    scrpos.x = (x1 + x2) / 2
    scrpos.y = (y1 + y2) / 2


    surface.DrawLine(x1, y1, x1+(x2-x1)*.2, y1)
    surface.DrawLine(x2-(x2-x1)*.2, y1, x2, y1)

    surface.DrawLine(x2, y1, x2, y1+(y2-y1)*.2)
    surface.DrawLine(x2, y2-(y2-y1)*.2, x2, y2)

    surface.DrawLine(x1, y2, x1+(x2-x1)*.2, y2)
    surface.DrawLine(x2-(x2-x1)*.2, y2, x2, y2)

    surface.DrawLine(x1, y1, x1, y1+(y2-y1)*.2)
    surface.DrawLine(x1, y2-(y2-y1)*.2, x1, y2)
    if color then
      surface.SetDrawColor(color.r, color.g, color.b, 25)
      surface.DrawRect(x1+1, y1+1, x2-x1-2, y2-y1-2)
    end
  else
    return
  end
  local offscreen = CE.IsOffScreen(scrpos)
  local szx = (offscreen and (not no_shrink)) and height/2 or height
  local szy = (offscreen and (not no_shrink)) and width/2 or width

  scrpos.x = math.Clamp(scrpos.x, szx, ScrW() - szx)
  scrpos.y = math.Clamp(scrpos.y, szy, ScrH() - szy)
  -- Drawing full size?
  if not offscreen and not DontDrawText then
    local text = math.ceil(LocalPlayer():GetPos():Distance(pos))
    local w, h = surface.GetTextSize(text)
    if mode == 1 then
      -- Show range to target
      surface.SetTextPos(scrpos.x - w/2, scrpos.y + (offset * szy) - h/2)
      surface.DrawText(text)
    end
    text = nil
    if tgt.t then
      if tgt.t >= 0 then
        text = util.SimpleTime(tgt.t - CurTime(), "%02i:%02i")
      else
        text = "--:--"
      end
    elseif tgt.nick then
      text = tgt.nick
    elseif CORPSE ~= nil and CORPSE.GetPlayerNick(tgt, nil) ~= "" then
      text = CORPSE.GetPlayerNick(tgt, nil)
    end
    if text ~= nil then
      surface.SetFont( "TargetIDSmall" )
      w, h = surface.GetTextSize(text)
      surface.SetTextPos(scrpos.x - w / 2, scrpos.y + szy / 2)
      surface.DrawText(text)
    end
  end
end
local surface = surface
function CE.DrawRadar(ent, color, mode)
  if not IsValid(ent) then
    return
  end
  if color then
    surface.SetDrawColor(color.r, color.g, color.b, color.a)
    surface.SetTextColor(color.r, color.g, color.b, color.a)
  end
  if GetConVarNumber("hacks_espmode") == 1 then
    surface.SetTexture(surface.GetTextureID("effects/select_ring"))
  end
  CE.DrawTarget(ent, 24, 0, false, 24, 24, false, mode, color)
  surface.SetDrawColor(255, 255, 255, 255)
  surface.SetTextColor(255, 255, 255, 255)
end

----[[ Module handling functions ]]----
CE.cvars = { }

function CE.AddCommandToggle(cvar, name, description, maxValue, printTables, ref)
  if maxValue == nil then
    maxValue = 1
  end
  table.insert(CE.cvars, {cvar=cvar, name=name, description=description, maxValue=maxValue, printTables=printTables, NoToggle=maxValue ~= 1, ref=ref})
  concommand.Add(cvar.."_toggle", function()
    CE.PlayToggleSound()
    local val = (GetConVarNumber(cvar) + 1) % (maxValue+1)
    RunConsoleCommand(cvar,val)
    if(printTables ~= nil and printTables[val+1] ~= nil) then
      if(cvar == "hacks_notifications") then
        chat.AddText(CE.Colors.WHITE, "[",CE.Colors.CONTINUUM,"NOTIFY",CE.Colors.WHITE,"] ", CE.Colors.WHITE, unpack(printTables[val+1]))
      elseif CE.Notify then
        CE.Notify.All(unpack(printTables[val+1]))
      end
    end
  end)
end
function CE.GetConVarBool(name)
  local cvar = GetConVar(name)
  if cvar then return cvar:GetBool() end
  return false
end

function CE.NonHacksErrorHandler(error)
  return CE.ErrorHandler(error, true)
end
function CE.ErrorHandler(error, nonhacks)
  local msg = "[CAUGHT ERROR] " .. error
  local stack = CE.Debugger.GetStack(2)
  for level,info in pairs(stack) do
    msg = msg .. "\n" .. string.rep(" ", level) .. (level-1) .. ". " .. (info.name or "unknown") .. " - "
    if(info.short_src ~= "[C]") then
      msg = msg .. info.short_src .. ":" .. info.currentline
    else
      msg = msg .. "[C]"
    end
  end
  --print(msg)
  if nonhacks then
    RunConsoleCommand("__cl_error", error)
  else
    RunConsoleCommand("__cl_herror", error)
  end
  return-- msg
end
CE.Modules = { }
function CE.AddCmd(cmd, MODULE)
  MODULE = MODULE or _G.MODULE or { }
  MODULE.cmds = MODULE.cmds or { }
  MODULE.cmds[cmd.Name or cmd.name] = cmd
  cmd.Name = cmd.Name or cmd.name
  cmd.Nick = cmd.Nick or cmd.nick or MODULE.name
  cmd.Info = cmd.Info or cmd.info or MODULE.info or ""
  cmd.Func = cmd.Func or cmd.Function or cmd.func or function() print(cmd.name.." not overridden!") end
  cmd.Autocomplete = cmd.Autocomplete or cmd.autocomplete
  if(cmd.Name == nil) then
    CE.ErrorHandler(MODULE.Name.." has malformed cmd data")
  else
    table.insert(CE.cvars, {cmd=cmd.Name, name=cmd.Nick, description=cmd.Info, noargs=cmd.NoArgs, ref=cmd})
    return concommand.Add(cmd.Name, cmd.Func, cmd.Autocomplete, cmd.Info)
  end
end
function CE.AddCVar(cvar, MODULE)
  MODULE = MODULE or _G.MODULE or { }
  cvar.Name = cvar.Name or cvar.name
  cvar.Saves = cvar.Saves or cvar.saves or cvar.Save or cvar.save
  cvar.Default = cvar.Default or cvar.default

  cvar.Flags = cvar.Flags or cvar.flags
  cvar.Nick = cvar.Nick or cvar.nick or MODULE.Name
  cvar.Info = cvar.Info or cvar.info or MODULE.info or ""
  MODULE.cvars = MODULE.cvars or { }
  MODULE.cvars[cvar.Name or cvar.name] = cvar
  if(cvar.Name == nil or not cvar.Nick) then
    print((MODULE.Name or cvar.Name or cvar.Nick) .." has malformed cvar data")
  else
    cvar.Options = cvar.Options or cvar.options or { { cvar.Nick.." set to ", Color(255, 30, 30), "off" },{ cvar.Nick.." set to ", Color(30, 255, 30), "on" } }
    cvar.OptionsCount = cvar.OptionsCount or cvar.optionsCount or #cvar.Options
    if not cvar.NoToggle then
      if cvar.OptionsCount == 2 then
        concommand.Add("-"..cvar.Name, function() RunConsoleCommand(cvar.Name, "0") end, nil, "Toggles "..cvar.Name)
        concommand.Add("+"..cvar.Name, function() RunConsoleCommand(cvar.Name, "1") end, nil, "Toggles "..cvar.Name)
      end
      CE.AddCommandToggle(cvar.Name, cvar.Nick, cvar.Info, cvar.OptionsCount-1, cvar.Options, cvar)
    else
      concommand.Remove(cvar.Name.."_toggle")
    end
    -- CreateClientConVar(cvar.name, cvar.default or 0, cvar.saves, false)
    local name = cvar.Name
    local default = cvar.Default
    local flags = cvar.Flags
    local help = cvar.Info
    if default == nil then default = 0 end
    if flags == nil then flags = { FCVAR_PROTECTED } end
    if cvar.Saves == nil or cvar.Saves == true then table.insert(flags, FCVAR_ARCHIVE) end
    return CreateConVar( name, tostring(default), flags, help )
  end
end
local AttemptedModules = { }
function CE.LoadModules()
  local ok = true
  local modules = file.Find( "lua/modules/*", "MOD" )
  for _,name in pairs(modules) do
    local pass, MODULE = CE.ParseModule(name)
    if not pass then
      print("Module " .. name .. (MODULE and MODULE.ID and (" [" .. MODULE.ID .. "]") or "") .. " experienced errors while parsing...")
      --chat.AddText(CE.Colors.CONTINUUM,"Continuum Engine ", CE.Colors.CONTINUUM, ""..CE.Version, CE.Colors.WHITE, " failed to load!" )
    elseif MODULE then
      CE.Modules[MODULE.ID] = MODULE
    end
  end
  for id,MODULE in pairs(CE.Modules) do
    ok = ok and CE.LoadModule(MODULE)
  end
  CE.Hook.Run("ModulesLoaded", modules)
  return ok
end
function CE.CheckDependency(id)
  return CE.Modules[id] and CE.Modules[id].Loaded
end
function CE.SwitchDependency(id, ifDependencyFunction, elseFunction)
  return CE.CheckDependency(id) and ifDependencyFunction or elseFunction
end
function CE.ParseModule(name)
  if(name:starts("ulx.") and not ulx) then
    return true
  end
  if(name:starts("ttt.") and not CE.IsTTT()) then
    return true
  end
  if(name:starts("hg.") and not CE.IsTTT()) then
    return true
  end
  if(name:starts("darkrp.") and not CE.IsDarkRP()) then
    return true
  end
  if(name:starts("stronghold.") and not CE.IsStronghold()) then
    return true
  end
  if(name:starts("cod.") and not CE.IsCOD()) then
    return true
  end
  if(name:starts("murder.") and not CE.IsMurder()) then
    return true
  end
  if name:starts("dev.") then
    return true
  end
  MODULE = { FileName=name, Name=name, Version=1.0, cvars={ }, cmds={ }, Options={}, Enabled=true }

  local MODULE = MODULE
  MODULE.AddCVar = function(cvar)
    MODULE.cvars = MODULE.cvars or { }
    MODULE.cvars[cvar.Name or cvar.name] = cvar
  end
  MODULE.AddOption = function(name, data)
    MODULE.options = MODULE.options or { }
    MODULE.options[name] = data
  end
  MODULE.AddCmd = function(cmd)
    MODULE.cmds = MODULE.cmds or { }
    MODULE.cmds[cmd.Name or cmd.name] = cmd
  end
  MODULE.AddCVars = function(cvars)
    for _,cvar in pairs(cvars) do
      MODULE.AddCVar(cvar)
    end
  end
  MODULE.AddCmds = function(cmds)
    for _,cmd in pairs(cmds) do
      MODULE.AddCmd(cmd)
    end
  end
  MODULE.AddOptions = function(options)
    for _,option in pairs(options) do
      MODULE.AddOption(_, option)
    end
  end
  MODULE.GetOption = function(name)
    --local moduleName = MODULE.FileName:gsub(".lua", ""):gsub(".", "_")
    local option = MODULE.Options[name]
    if not option then return nil end
    local typeof = type(option.Default)
    return typeof == "number" and option.ConVar:GetFloat() or typeof == "bool" and option.ConVar:GetBool() or option.ConVar:GetString()
  end
  MODULE.SetOption = function(name, value)
    local option = MODULE.Options[name]
    if not option then return nil end
    RunConsoleCommand(option.ConVar:GetName(), tostring(value))
    return option.ConVar
  end
  CE.RevealGlobal()
  local success, callback = xpcall(function() CE.include("modules/"..name) end, function(error)
    chat.AddText(CE.Colors.RED, "An error occurred while processing ", CE.Colors.WHITE, name, CE.Colors.RED, " module's base, check console for more info")
    return CE.ErrorHandler(error)
  end)
  CE.HideGlobal()
  if(not success) then
    _G.MODULE = nil
    return false, MODULE
  end

  MODULE.AddCVar = CE.AddCVar
  MODULE.AddCmd = CE.AddCmd
  MODULE.AddOption = function(name, data)
    local cvarName = "hacks_" .. (MODULE.Prefix or MODULE.prefix or MODULE.FileName:gsub("%.lua", "")):gsub(" ", "_"):gsub("%.", "_")
    if name ~= "" then
      cvarName = cvarName .. "_" .. name
    end
    -- Also, finish converting AddCVar to AddOption, and then make a GUI with reload button
    -- and put it in ulx tab. note that if xgui doesnt exist maybe include our own? bc
    -- xgui is sounding nice for a GUI

    -- maybe do something like SWEP's or STOOL's createpanel or w/e to let modules make their own settings
    -- and lastly, go through modules and update them to use Options instead of cvars if possible
    -- *******************************************************************
    -- also!!!!
    -- steal ulx's shit for making cmd's proly
    -- they have a nice argument gui too at ulx/lua/ulx/xgui/commands.lua
    --






    local cvar = MODULE.AddCVar({Nick=data.Nick or data.nick or MODULE.Name, Name=cvarName, Saves=data.Saves, Default=data.Default, Info=data.Info, Options=data.Options, HUD=data.HUD})

    data.ConVar = cvar
    MODULE.Options = MODULE.Options or MODULE.options or { }
    MODULE.Options[name] = data
    data.Name = data.Name or data.name
    data.Saves = data.Saves or data.saves or data.Save or data.save
    if data.Default == nil then data.Default = data.default end

    data.Nick = data.Nick or data.nick or name
    data.Info = data.Info or data.Info or MODULE.info or ""
  end

  MODULE.Name = MODULE.Name or MODULE.name or MODULE.FileName
  MODULE.Info = MODULE.Info or MODULE.info or MODULE.Description or MODULE.description
  MODULE.Version = MODULE.version or MODULE.Version
  if MODULE.Info == nil then
    MODULE.Info = MODULE.Name.." module version "..tostring(MODULE.Version)
  end
  MODULE.Initialize = MODULE.Initialize or MODULE.Init
  MODULE.cvars = MODULE.cvars or { }
  if MODULE.cvar ~= nil then
    table.insert(MODULE.cvars, MODULE.cvar)
  end
  MODULE.cmds = MODULE.cmds or { }
  if MODULE.cmd ~= nil then
    table.insert(MODULE.cmds, MODULE.cmd)
  end
  MODULE.Options = MODULE.Options or { }
  if MODULE.Option ~= nil then
    table.insert(MODULE.Options, MODULE.Option)
  end
  _G.MODULE = nil
  return true, MODULE
end
function CE.LoadModule(MODULE)
  if AttemptedModules[MODULE.ID] then return CE.Modules[MODULE.ID].Loaded end
  AttemptedModules[MODULE.ID] = true
  local name = MODULE.FileName

  for _,id in pairs(MODULE.Dependencies) do
    if not CE.Modules[id] then
      print(name .. " failed to load, missing dependency \"" .. id .. "\"")
      MODULE.Loaded = false
      return false
    end
    if not CE.LoadModule(CE.Modules[id], CE.Modules[id].FileName) then
      print(name .. " failed to load, dependency \"" .. id .. "\" had errors")
      MODULE.Loaded = false
      return false
    end
  end

  local cvars = MODULE.cvars
  MODULE.cvars = { }
  MODULE.AddCVars(cvars)
  local cmds = MODULE.cmds
  MODULE.cmds = { }
  MODULE.AddCmds(cmds)
  local opts = MODULE.Options
  MODULE.Options = { }
  MODULE.AddOptions(opts)

  if MODULE.Initialize and MODULE.Enabled then
    _G.MODULE = MODULE
    local success, callback = xpcall(function() MODULE.Initialize(CE) end, function(error)
      chat.AddText(CE.Colors.RED, "An error occurred while initializing ", CE.Colors.WHITE, name, CE.Colors.RED, " module, check console for more info")
      return CE.ErrorHandler(error)
    end)
    _G.MODULE = nil
    if(not success) then
      MODULE.Loaded = false
      return false
    end
  end
  MODULE.Loaded = true
  _G.MODULE = nil
  return true
end
function CE.CheckForUpdates()
  CE.Constants.NewVersion = nil
  CE.Constants.VersionLoaded = false
  http.Post( "http://pastebin.com/raw.php?i=11LW9hYu", { },
    function( versionStr )
      CE.Constants.NewVersion = tonumber(versionStr) or 1.0
      if(CE.Constants.NewVersion > CE.Version) then
        chat.AddText(CE.Colors.WHITE,"A new version of ", CE.Colors.CONTINUUM, "Continuum Engine", CE.Colors.WHITE, " (v"..CE.Constants.NewVersion..") is available! Opening update page...")
        gui.OpenURL("https://github.com/alexrcoleman/Continuum")
      elseif CE.Constants.NewVersion < CE.Version then
        chat.AddText(CE.Colors.WHITE,"You are currently running on a development build ["..CE.Version..">"..CE.Constants.NewVersion.."]! Don't forget to push your updates!" )
      end
      CE.Constants.VersionLoaded = true
    end,
    function()
      print("Error occurred while trying to fetch latest version number")
      CE.Constants.NewVersion = -1
      CE.Constants.VersionLoaded = true
    end
  );
end
function CE.ReadURL(url, protocol, callback, err)
  if protocol ~= nil then
    url = protocol.."://"..url
  end
  print("Reading "..url)
  http.Post( url, { },
    callback or function( callback )
      print("Callback: "..callback)
    end,
    err or function(err)
      print("Error: "..err)
    end
  );
end
----[[ Help command ]]----
concommand.Add("hacks_help",function( calling_ply,command,args )
  local validcmds = { }
  for _,cmd in pairs(CE.cvars) do
    local name = cmd.cmd or cmd.cvar
    if(#args < 1 or name:starts("hacks_"..args[1]) or name:starts(args[1])) then
      validcmds[name] = cmd
    end
  end
  for _,cmd in CE.PairsByKeys(validcmds) do
    CE.Console.AddText(cmd.cmd and Color(150,0,0) or Color(0,0,150), cmd.cmd or cmd.cvar, " [", cmd.cmd and "cmd" or "cvar", "]: ", CE.Colors.WHITE, cmd.description, "\n")
  end
  if #args == 0 then
    CE.Console.AddText("-------------------------------------------------------------------------------\n")
    CE.Console.AddText("Listed above are the possible commands to run and cvars to modify for Continuum\n")
  end
end)
local modes = { }
concommand.Add("hacks_toggle", function(ply, _, arguments, args)
  CE.PlayToggleSound()
  local cmd = arguments[1]
  if not cmd then return end
  local convar = GetConVar(cmd)
  if convar then
    if #arguments > 1 then
      local mode = 1
      --
      for k=2,#arguments do
        local num1 = tonumber(arguments[k])
        local num2 = tonumber(convar:GetString())

        if arguments[k] == convar:GetString()
          or num1 == num2 then -- allow for 1.00 and 1 to count as equal
          mode = k
          break
        end
      end
      if mode+1 > #arguments then mode = 1 end
      print("Mode: "..mode)

      local currentValue = arguments[mode+1]
      print(currentValue)
      RunConsoleCommand(cmd, currentValue)
    else
      if convar:GetBool() then
        RunConsoleCommand(cmd, "0")
      else
        RunConsoleCommand(cmd, "1")
      end
    end
  else
    if modes[cmd] then
      RunConsoleCommand("-"..cmd)
      modes[cmd] = nil
    else
      RunConsoleCommand("+"..cmd)
      modes[cmd] = true
    end
  end
end)
local function FindInTable( tab, find, parents, depth )

  depth = depth or 0
  parents = parents or ""

  if ( not istable( tab ) ) then return end
  if ( depth > 3 ) then return end
  depth = depth + 1

  for k, v in pairs ( tab ) do

    if ( type(k) == "string" ) then

      if ( k and k:lower():find( find:lower() ) ) then

        Msg("\t", parents, k, " - (", type(v), " - ", v, ")\n")

      end

      -- Recurse
      if ( istable(v) and
        k ~= "_R" and
        k ~= "_E" and
        k ~= "_G" and
        k ~= "_M" and
        k ~= "_LOADED" and
        k ~= "__index" ) then

        local NewParents = parents .. k .. ".";
        FindInTable( v, find, NewParents, depth )

      end

    end

  end

end


--[[---------------------------------------------------------
Name:	Find
-----------------------------------------------------------]]
local function Find( ply, command, arguments )
  if ( not arguments[1] ) then print("Requires one argument!") return end
  Msg("Finding '", arguments[1], "' CLIENTSIDE:\n\n")

  FindInTable( _G, arguments[1] )
  FindInTable( debug.getregistry(), arguments[1] )

  Msg("\n\n")

end
concommand.Add( "lua_find_cl", Find, nil, "", { FCVAR_DONTRECORD } )

local debugger = CE.Debugger
function CE.MeasureSpeed(func, ...)
  local args = {...}
  local t = SysTime()
  local result = {func(unpack(args))}
  table.insert(result, SysTime()-t)
  return unpack(result)
end
function CE.TestFunc(a,b,c)
  return a,b,c
end

effects.EffectList = debugger.GetUpvalue(effects.Create, "EffectList")
list.g_Lists = debugger.GetUpvalue(list.Get, "g_Lists")
baseclass.BaseClassTable = debugger.GetUpvalue(baseclass.Get, "BaseClassTable")
notification.Notices = debugger.GetUpvalue(notification.AddLegacy, "Notices")