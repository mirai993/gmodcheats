local CE = CE

CE.Hook = { }
CE.Hook.CEHooks = { }
local CEFunctions = { }
local debugger = CE.Debugger
local Hook = CE.Hook
local gmod          = gmod
local pairs         = pairs
local isfunction    = isfunction
local isstring      = isstring
local IsValid       = IsValid

-- Needed due to our modifications
local table         = table
local ipairs        = ipairs
local tostring      = tostring

-- Grab all previous hooks from the pre-existing hook module.
local BackwardsHooks = debugger.GetUpvalue(hook.Add, "BackwardsHooks") or debugger.GetUpvalue(hook.Add, "Hooks")
if not BackwardsHooks then
  BackwardsHooks = { }
end
local IsULX = debugger.GetUpvalue(hook.Add, "BackwardsHooks") and true or false
local NewHooks
if IsULX then
	NewHooks = debugger.GetUpvalue(hook.Add, "Hooks")
end
function hook.GetTable()
	local FakeTable = { }
	for HookType,HookTable in pairs(BackwardsHooks) do
		for HookName,HookFunction in pairs(HookTable) do
			if(not Hook.IsCEHook(HookFunction)) then
				FakeTable[HookType] = FakeTable[HookType] or { }
				FakeTable[HookType][HookName] = HookFunction
			end
		end
	end
	local MetaTable = { __metatable=false }
	function MetaTable.__index(tbl,key)
		return nil
	end
	function MetaTable.__newindex(tbl, key, value)
		BackwardsHooks[key] = value
		rawset(tbl, key, value)
	end
	return setmetatable(FakeTable, MetaTable)
end
function Hook.GetTable()
	return BackwardsHooks
end
function Hook.Add( event_name, name, func, priority )
  local wrapper = function(...)
    local args = {...}
    local ok, result = xpcall(function() return func(unpack(args)) end, CE.ErrorHandler)
    if ok then return result end
  end
	CEFunctions[func] = true
	Hook.CEHooks[event_name] = Hook.CEHooks[event_name] or { }
	Hook.CEHooks[event_name][name] = func
	hook.Add(event_name, name, func, priority)
end

function Hook.Remove( event_name, name )
	if BackwardsHooks[ event_name ] and BackwardsHooks[ event_name ][ name ] then
		CEFunctions[BackwardsHooks[ event_name ][ name ]] = false
		if Hook.CEHooks[event_name] then
			Hook.CEHooks[event_name][name] = nil
		end
	end
	if not isstring( event_name ) then return end

	if not BackwardsHooks[ event_name ] then return end

	if NewHooks then
		for index, value in ipairs( NewHooks[ event_name ] ) do
			if value.name == name then
				table.remove( NewHooks[ event_name ], index )
				break
			end
		end
	end
	
	BackwardsHooks[ event_name ][ name ] = nil
end
function Hook.Run( name, ... )
        return Hook.Call( name, nil, ... )
end
function Hook.Call( name, gm, ... )

        local ret

        --
        -- If called from hook.Run then gm will be nil.
        --
        if ( gm == nil and gmod ~= nil ) then
                gm = gmod.GetGamemode()
        end

        --
        -- Run hooks
        --
        local HookTable = Hook.CEHooks[ name ]
        if ( HookTable ~= nil ) then
        
                local a, b, c, d, e, f;

                for k, v in pairs( HookTable ) do 
                        
                        if ( isstring( k ) ) then
                                
                                --
                                -- If it's a string, it's cool
                                --
                                a, b, c, d, e, f = v( ... )

                        else

                                --
                                -- If the key isn't a string - we assume it to be an entity
                                -- Or panel, or something else that IsValid works on.
                                --
                                if ( IsValid( k ) ) then
                                        --
                                        -- If the object is valid - pass it as the first argument (self)
                                        --
                                        a, b, c, d, e, f = v( k, ... )
                                else
                                        --
                                        -- If the object has become invalid - remove it
                                        --
                                        HookTable[ k ] = nil
                                end
                        end

                        --
                        -- Hook returned a value - it overrides the gamemode function
                        --
                        if ( a ~= nil ) then
                                return a, b, c, d, e, f
                        end
                        
                end
        end
        
        --
        -- Call the gamemode function
        --
        if ( not gm ) then return end
        
        local GamemodeFunction = gm[ name ]
        if ( GamemodeFunction == nil ) then return end
                
        return GamemodeFunction( gm, ... )        
        
end
function Hook.IsCEHook(func)
	return CEFunctions[func] == true
end

