TEXT_ALIGN_LEFT = 0
TEXT_ALIGN_CENTER = 1
TEXT_ALIGN_RIGHT = 2
TEXT_ALIGN_TOP = 3
TEXT_ALIGN_BOTTOM = 4
local CE = { }
if _include then
  CE.include = _include
else
  CE.include = function(path)
    local str = file.Read(path, "LUA") or file.Read("lua/" .. path, "GAME")
    if not str then
      print("Did not find " .. path .. ", using include")
      return include(path)
    end
    local func = CompileString(str, path, false)
    if(type(func) ~= "function") then
      CE.ErrorHandler(func)
      return false
    else
      return func()
    end
  end
  CE.fileinclude = function(path)
    local str = file.Read(path, "LUA")
    local func = CompileString(str, path, false)
    if(type(func) ~= "function") then
      CE.ErrorHandler(func)
      return false
    else
      return func()
    end
  end
end
function CE.RevealGlobal()
  _G.CE = CE
end
function CE.HideGlobal()
  _G.CE = nil
end

CE.RevealGlobal()
CE.include("glon.lua")
CE.HideGlobal()
CE.md5 = CE.include("md5.lua")
local IA = 16807
local IM = 2147483647
local IQ = 127773
local IR = 2836
local NTAB = 32
local NDIV = (1+(IM-1)/NTAB)
local MAX_RANDOM_RANGE = 0x7FFFFFFF

local AM = (1.0/IM)
local EPS = 1.2e-7
local RNMX = (1.0-EPS)

local m_idum = 0;
local m_iy = 0;
local m_iv = { }; -- size: NTAB
function CE.RandomSeed(iSeed)
  m_idum = ((iSeed < 0) and iSeed or -iSeed);
  m_iy = 0;
--print("Seed=" .. m_idum)
end

function CE.GenerateRandomNumber()
  local j;
  local k;
  --print("pre-m_idum=" .. m_idum)
  if (m_idum <= 0 or not m_iy) then
    if (-(m_idum) < 1) then
      m_idum = 1;
    else
      m_idum = -(m_idum);
    end

    for j = NTAB + 7,0,-1 do
      k = math.floor((m_idum) / IQ);
      m_idum = IA*(m_idum - k*IQ) - IR*k;
      if (m_idum < 0) then
        m_idum = m_idum + IM;
      end
      if (j < NTAB) then
        m_iv[j] = m_idum;
      end
    end
    m_iy = m_iv[0];
  end
  k = math.floor((m_idum) / IQ); -- k is an int
  m_idum = IA*(m_idum - k*IQ) - IR*k;
  if (m_idum < 0) then
    m_idum = m_idum + IM;
  end
  j = math.floor(m_iy / NDIV); -- j is an int
  m_iy = m_iv[j];
  m_iv[j] = m_idum;
  return m_iy;
end

function CE.RandomFloat(flLow, flHigh)
  -- float in [0,1)
  local fl = AM * CE.GenerateRandomNumber();
  if (fl > RNMX) then
    fl = RNMX;
  end

  return (fl * (flHigh - flLow)) + flLow; -- float in [low,high)
end

function CE.RandomInt(iLow, iHigh)
  --ASSERT(lLow <= lHigh);
  -- uints:
  local maxAcceptable;
  local x = iHigh - iLow + 1;
  local n;
  if (x <= 1 or MAX_RANDOM_RANGE < x - 1) then
    return iLow;
  end

  -- The following maps a uniform distribution on the interval [0,MAX_RANDOM_RANGE]
  -- to a smaller, client-specified range of [0,x-1] in a way that doesn't bias
  -- the uniform distribution unfavorably. Even for a worst case x, the loop is
  -- guaranteed to be taken no more than half the time, so for that worst case x,
  -- the average number of times through the loop is 2. For cases where x is
  -- much smaller than MAX_RANDOM_RANGE, the average number of times through the
  -- loop is very close to 1.
  --
  maxAcceptable = MAX_RANDOM_RANGE - ((MAX_RANDOM_RANGE + 1) % x);
  repeat
    n = CE.GenerateRandomNumber();
  until (n <= maxAcceptable);

  return iLow + (n % x);
end
local bit = bit
function CE.PredictSpread(ucmdNumber)
  local seed = CE.md5.PseudoRandom(ucmdNumber)
  print(seed)
  seed = bit.band(seed,0x7fffffff)
  print(seed)
  seed = bit.band(seed,255)
  print(seed)
  CE.RandomSeed(seed);

  local x = math.round(CE.RandomFloat(-0.5, 0.5), 6) + math.round(CE.RandomFloat(-0.5, 0.5), 6);
  local y = math.round(CE.RandomFloat(-0.5, 0.5), 6) + math.round(CE.RandomFloat(-0.5, 0.5), 6);
  return x,y
end

if not GetGlobalVar then
  GlobalVariables = { }
  function GetGlobalVar(key, default)
    if GlobalVariables[key] then
      return GlobalVariables[key]
    end
    return default
  end
  function SetGlobalVar(key, value)
    GlobalVariables[key] = value
  end
end
local SessionTable = GetGlobalVar and GetGlobalVar("7089412", { }) or { }
CE.Session = setmetatable({}, {
  __index = function (t,k)
    return CE.GetSession(k)
  end,
  __newindex = function (t,k,v)
    CE.SetSession(k,v)
  end,
  __pairs = SessionTable
})
function CE.SetSession(key, value)
  SessionTable[key] = value
  SetGlobalVar("7089412", SessionTable)
end
function CE.GetSession(key, default)
  local Value = SessionTable[key]
  if Value == nil then
    Value = default
    CE.SetSession(key, default)
  end
  return Value
end

local SaveTable = CE.glon.decode(file.Read("continuum.txt")) or { }
CE.Save = setmetatable({ },{
  __index = function (t,k)
    return CE.GetPersistant(k)
  end,
  __newindex = function (t,k,v)
    CE.SetPersistant(k,v)
  end,
  __pairs = SaveTable
})
function CE.SetPersistant(Key,Value)
  if Key == SaveTable or Key == CE.Save or Value == SaveTable or Value == CE.Save then
    print("Attempt to reference persistant table in itself blocked")
    return
  end
  SaveTable[Key] = Value
  file.Write("continuum.txt", CE.glon.encode(SaveTable))
  chat.AddText("Stored ", tostring(Key))
end
function CE.GetPersistant(Key,DefaultValue)
  local Value = SaveTable[Key]
  if Value == nil then Value = DefaultValue end
  return Value
end

if not CE.Session._pairs then CE.Session._pairs = pairs end
function string.starts(String,Start)
  return string.sub(String,1,string.len(Start))==Start
end
function string.ends(String,End)
  return End=='' or string.sub(String,-string.len(End))==End
end
function string:split(sep)
  local sep, fields = sep or ":", {}
  local pattern = string.format("([^%s]+)", sep)
  self:gsub(pattern, function(c) fields[#fields+1] = c end)
  return fields
end
local LocalTable = { }
local UpvalueTable = { }
local DebugFunctionCalls = false
local function GetLuaCode(o)
  local Type = type(o)
  if Type == "string" then return "\"" .. o .. "\"" end
  if Type == "Entity" or Type == "NPC" or Type == "Player" then return "Entity(" .. tostring(o:EntIndex()) .. ")" end
  if CE.Colors.IsColor(o) then return "Color( " .. tostring(o.r) .. ", " .. tostring(o.g) .. ", " .. tostring(o.b) .. (o.a == 255 and "" or (", " .. tostring(o.a))) .. " )" end
  return tostring(o)
end
local function GetFullLuaCode(o, depth)
  if not depth then depth = 1 end
  if depth > 5 then return GetLuaCode(o) end
  local Type = type(o)
  if Type == "string" then return "\"" .. o .. "\"" end
  if o == LocalPlayer() then return "LocalPlayer()" end
  if Type == "Entity" or Type == "NPC" or Type == "Player" then return "Entity(" .. tostring(o:EntIndex()) .. ")" end
  if CE.Colors.IsColor(o) then return "Color( " .. tostring(o.r) .. ", " .. tostring(o.g) .. ", " .. tostring(o.b) .. (o.a == 255 and "" or (", " .. tostring(o.a))) .. " )" end
  if Type == "table" then
    local code = "{ "
    for k,v in pairs(o) do
      if code ~= "{ " then
        code = code .. ", "
      end
      code = code .. "[" .. GetFullLuaCode(k, depth+1) .. "] = " .. GetFullLuaCode(v, depth+1)
    end
    code = code .. " }"
    return code
  end
  return tostring(o)
end
local IsShuttingDown = false
local OldHook = nil
local ScopeIgnore = nil

local maxDepth = nil
local function DefaultHook(EventName, NewLineNumber)
  local FunctionInfo = debug.getinfo(2)
  local IgnoreLocals = {
    GMACM,
    EM,
    VM,
    PM,
    __SAVE
  }
  if not IsShuttingDown and FunctionInfo.func ~= DebugStart and FunctionInfo.func ~= DebugEnd and FunctionInfo.func ~= ScopeIgnore then
    local CallerInfo = debug.getinfo(3)
    local depth = debugger.GetDepth()
    if maxDepth and depth > maxDepth then
      return
    end
    depth = depth - 6
    if EventName == "call" and FunctionInfo.name then
      local PrintingTable = { string.rep("\t", depth) }
      local FunctionType = FunctionInfo.namewhat
      if FunctionType == "field" then FunctionType = "table" end
      if FunctionInfo.linedefined == -1 then FunctionType = "internal " .. FunctionType end
      FunctionType = FunctionType:sub(1,1):upper() .. FunctionType:sub(2)
      if not maxDepth then
        table.insert(PrintingTable, FunctionType)
        table.insert(PrintingTable, " function called ")
      end
      local CallerSource
      if CallerInfo.short_src == '[C]' then
        CallerSource = "in C code"
      else
        CallerSource = "at '" .. CallerInfo.short_src .. ":" .. tostring(CallerInfo.currentline) .. "'"
      end
      if not maxDepth then
        table.insert(PrintingTable, CallerSource)
        table.insert(PrintingTable, " ")
      end
      table.insert(PrintingTable, FunctionInfo.name)
      table.insert(PrintingTable, "( ")

      local LocalVariables = {}
      local lk, lv
      local first = true
      local function AddParameter(val)
        if not first then
          table.insert(PrintingTable, ", ")
        end
        table.insert(PrintingTable, GetLuaCode(val))
        first = false
      end
      for idx=1,50 do -- if your function takes more than 50 arguments, fuck you.
        lk,lv = debug.getlocal(2, idx)
        if not lk or lk == "" then break end
        if lk == "arg" then
          for k,v in pairs(lv) do
            AddParameter(v)
          end
        else
          AddParameter(lv)
        end
      end

      table.insert(PrintingTable, " )")
      print(unpack(PrintingTable))
    elseif EventName == "return" then
      for idx=1,100 do -- if you use over 100 local variables at once, fuck you
        local lk,lv = debug.getlocal(2, idx)
        if not lk or lk == "" then break end
        if not lk:starts("(") then
          LocalTable[lk] = lv
        end
      end
      for idx=1,100 do -- if you use over 100 upvalues at once, fuck you
        local uk,uv = debug.getupvalue(FunctionInfo.func, idx)
        if not uk or uk == "" then break end
        if not uk:starts("(") then
          UpvalueTable[uk] = uv
        end
      end
    elseif EventName == "line" then
      for idx=1,100 do -- if you use over 100 local variables at once, fuck you
        local lk,lv = debug.getlocal(2, idx)
        if not lk or lk == "" then break end
        if not lk:starts("(") and not table.containsValue(IgnoreLocals, lv) then
          LocalTable[lk] = lv
        end
      end
      for idx=1,100 do -- if you use over 100 upvalues at once, fuck you
        local uk,uv = debug.getupvalue(FunctionInfo.func, idx)
        if not uk or uk == "" then break end
        if not uk:starts("(") and not table.containsValue(IgnoreLocals, uv) then
          UpvalueTable[uk] = uv
        end
      end
    end
  end
end
local debugger = { }
function debugger.GetStack(level)
  local info = debug.getinfo(level+1)
  local stack = { }
  while info do
    --table.insert(stack, info)
    stack[level] = info
    level = level + 1
    info = debug.getinfo(level+1)
  end
  return stack
end
function debugger.GetDepth()
  local depth = 1
  local _
  while depth == 1 or (_ and depth < 20) do
    depth = depth+1
    _ = debug.getinfo(depth)
  end
  return depth - 2
end
function debugger.DebugFunctionCalls(basic)
  OldHook = {debug.gethook()}
  LocalTable = nil
  UpvalueTable = nil
  ScopeIgnore = debug.getinfo(2).func
  IsShuttingDown = false
  maxDepth = basic and debugger.GetDepth()+4
  debug.sethook( DefaultHook, "c", 0 )
end
function debugger.DebugVariables()
  OldHook = {debug.gethook()}
  LocalTable = { }
  UpvalueTable = { }
  ScopeIgnore = debug.getinfo(2).func
  debug.sethook( DefaultHook, "rtl", 0 )
  IsShuttingDown = false
end
function debugger.FinishDebug(PrintVariables, HideValues)
  IsShuttingDown = true
  debug.sethook()
  print("MAX: ", maxDepth)
  if LocalTable and UpvalueTable then
    if PrintVariables then
      if HideValues then
        print("Locals: ")
        for k,_ in pairs(LocalTable) do
          print("\t", k)
        end
        print("Upvalues: ")
        for k,_ in pairs(UpvalueTable) do
          print("\t", k)
        end
      else
        print("Locals: ")
        PrintTable(LocalTable, 1)
        print("Upvalues: ")
        PrintTable(UpvalueTable, 1)
      end
    end
    return LocalTable, UpvalueTable
  end
end
function debugger.GetUpvalues(func)
  local UpvalueTable = { }
  for idx=1,100 do -- if you use over 100 upvalues at once, fuck you
    local uk,uv = debug.getupvalue(func, idx)
    if not uk or uk == "" then break end
    if not uk:starts("(") then
      UpvalueTable[uk] = uv
    end
  end
  return UpvalueTable
end
function debugger.GetLocals(level)
  level = level + 1 -- ignore this level
  local LocalsTable = { }
  for idx=1,100 do -- if you use over 100 locals at once, fuck you
    local lk,lv = debug.getlocal(level, idx)
    if not lk or lk == "" then break end
    if not lk:starts("(") then
      LocalsTable[lk] = lv
    end
  end
  return LocalsTable
end
function debugger.GetUpvalue(func, name)
  local tbl = debugger.GetUpvalues(func)
  for k,v in pairs(tbl) do
    if k == name then return v end
  end
  return nil
end
function debugger.GetLocal(level, name)
  local tbl = debugger.GetLocals(level + 1) -- ignore this level
  for k,v in pairs(tbl) do
    if k == name then return v end
  end
  return nil
end
function debugger.SetUpvalue(func, name, value)
  local index = -1
  for idx=1,100 do -- if you use over 100 upvalues at once, fuck you
    local uk,uv = debug.getupvalue(func, idx)
    if not uk or uk == "" then break end
    if uk == name then
      index = idx
      break
    end
  end
  if index ~= -1 then
    debug.setupvalue(func, index, value)
    return true
  end
  return false
end
function debugger.SetLocal(level, name, value)
  level = level + 1 -- ignore this level
  local index = -1
  for idx=1,100 do
    local uk,uv = debug.getlocal(level, idx)
    if not uk or uk == "" then break end
    if uk == name then
      index = idx
      break
    end
  end
  if index ~= -1 then
    debug.setlocal(level, index, value)
    return true
  end
  return false
end
--[[
Still in beta testing. It lags the fuck out of you to get all the upvalues :/
]]
function debugger.EnableAntiAntiHacks()
  debug.sethook(function(EventName)
    local Upvalues-- = debugger.GetUpvalues(debug.getinfo(2).func)
    if Upvalues and Upvalues.TEST_R then
      print("They used TEST_R!")
    end
  end, "c", 0)
  debug.sethook()
end
local SourceCode = ""
local FakeTable = {
  _SourceCode=""
}
local MT = {
  __index = function(t,k)
    local t = table.clone(FakeTable)
    t._SourceCode = t._SourceCode .. "[" .. GetFullLuaCode(k) .. "]"
    return t
  end,
  __call = function(tbl, ...)
    local _t = tbl
    local s = CurTime()
    while _t.Parent and _t ~= _t.Parent and CurTime() - s < 2 do -- maybe put a timeout here? its crashing
      _t = _t.Parent
    end

    local t = table.clone(FakeTable)
    t.Parent = tbl
    _t._SourceCode = _t._SourceCode .. "("
    return t
  end
}
setmetatable(FakeTable, MT)
function debugger.RunInSandbox(func, ...)
  local g = {}        -- create new environment
  setmetatable(g, {__G = getfenv(),
    __index = function(t,k)
      local t = table.clone(FakeTable)
      return t
    end,
    __newindex = function()
    end})
  setfenv(func, g)    -- set it
  func(...)
  local g = getmetatable(getfenv()) and getmetatable(getfenv()).__G
  setfenv(func, g)
end
function debugger.GetCallerString()
  local level = 3
  local info = 1
  local text = ""
  while(level < 20 and (info == 1 or info ~= nil)) do
    info = debug.getinfo(level)
    level = level + 1
  end
  level = level - 2
  while(level > 2) do
    info = debug.getinfo(level)
    text = text .. level .. "@" ..  (info.short_src or "?") .. " -> "
    level = level - 1
  end
  text = text .. "(this)"
  return text
end
function debugger.FindSource(func, ...)
  local __G = getfenv(func)
  local g = {}        -- create new environment
  g.print = print
  setmetatable(g, {__G = getfenv(func),
    __index = function(t,k)
      local t = table.clone(FakeTable)
      t._SourceCode = k
      if not SourceCode then SourceCode = t end
      return t
    end,
    __newindex = function(t,k,v)
      SourceCode = k .. " = " .. v._SourceCode
    end})
  setfenv(func, g)    -- set it
  debug.sethook( function()
    if SourceCode then
      if type(SourceCode) == "string" then
        print(SourceCode)
      else
        print(SourceCode._SourceCode)
      end
    end
    SourceCode = nil
  end, "l", 0 )
  func(...)
  debug.sethook()
  local g = getmetatable(getfenv()) and getmetatable(getfenv()).__G
  setfenv(func, __G or g)
end
function debugger.SaveFunction(func)
  local dump = string.dump(func)
  local code = "MyFunction = loadstring(\"" .. dump .. "\");"
  -- SetClipboardText(code)

  CE.Console.Print("Use the following code to load the function:\n", code, "\n")
end
debugger.GetFullLuaCode = GetFullLuaCode
CE.Debugger = debugger
function pairs(tbl)
  local m = getmetatable(tbl)
  if m and type(m.__pairs) == "function" then tbl = m.__pairs() end
  if m and type(m.__pairs) == "table" then tbl = m.__pairs end
  if type(m) == "function" then return m end -- in case they try to call pairs() in their MT
  return CE.Session._pairs(tbl)
end
_include = _include or include
function include(...)
  local args = {...}
  table.insert(args,1,"include(")
  table.insert(args,")")
  print(unpack(args))
  _include(...)
end
local function InstallHooks()
  if vgui and vgui.GetControlTable then
    vgui.PanelFactory = CE.Debugger.GetUpvalue(vgui.GetControlTable, "PanelFactory")
    if not vgui._Register then vgui._Register = vgui.Register end
    function vgui.Register( name, mtable, base )
      -- Fix mac scrolling when possible
      if system.IsOSX() then
        if not mtable.__OnMouseWheeled and mtable.OnMouseWheeled then
          mtable.__OnMouseWheeled = mtable.__OnMouseWheeled or mtable.OnMouseWheeled
        end
        function mtable:OnMouseWheeled(delta)
          if delta == 0 then return self:__OnMouseWheeled(0) end
          return self:__OnMouseWheeled(delta/math.abs(delta))
        end
      end
      vgui._Register(name,mtable,base)
    end
  end

  --[[for k,PANEL in pairs(vgui.PanelFactory) do
  if not PANEL.___OnMouseWheeled and PANEL.OnMouseWheeled then
  PANEL.___OnMouseWheeled = PANEL.___OnMouseWheeled or PANEL.OnMouseWheeled
  print(PANEL.ThisClass .. ": " .. tostring(PANEL.___OnMouseWheeled))
  end
  function PANEL:OnMouseWheeled(delta)
  print("HOOK " .. delta)
  --if delta == 0 then return self:___OnMouseWheeled(0) end
  --return self:___OnMouseWheeled(delta/math.abs(delta))
  end
  baseclass.Set(k, PANEL)
  end]]
end
InstallHooks()
hook.Add("Think", "Install_Hooks", InstallHooks)
-- Spoof convars
--[[if not CE.Session._GetConVar then CE.Session._GetConVar = GetConVar end
function GetConVar(name, ...)
if name == "sv_cheats" or name == "sv_allowcslua" or name == "host_framerate" then
return {
GetBool = function() return false end,
GetInt = function() return 0 end,
GetFloat = function() return 0.0 end,
GetString = function() return "0" end,
MetaID=27,
MetaName="ConVar"
};
end
return CE.Session._GetConVar(name, ...);
end]]



CE.RevealGlobal()