print("Initializing gmod clientside scripting")
include("hacks_menu+.lua")