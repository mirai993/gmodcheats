print("Menu hacks initializing...")
local CommandList = concommand.GetTable()
function concommand.Run( player, command, arguments, args )
  local LowerCommand = string.lower( command )

  if ( CommandList[ LowerCommand ] ~= nil ) then
    CommandList[ LowerCommand ]( player, command, arguments, args )
    return true
  end

  return false;
end
function InjectConsoleCommand( player, command, arguments, args )
  return concommand.Run( player, command, arguments, args )
end
vgui._CreateX = vgui._CreateX or vgui.CreateX
vgui.Elements = vgui.Elements or { }
local counter = 1
function vgui.CreateX( classname, parent, name )
  local title = name
  if not title then
    title = "#Element" .. counter
    counter = counter + 1
  end
  local t = vgui._CreateX(classname, parent, name)
  vgui.Elements[title] = t
  return t
end


RunConsoleCommand("sv_cheats", "13371221")
_JoinServer = _JoinServer or JoinServer
local ServerIP = ""
function JoinServer(serverip)
  ServerIP = serverip
  print("Connecting to " .. ServerIP)
  _JoinServer(ServerIP)
end
function GetLastServerIP()
  return ServerIP
end
function GetServerIP()
  return IsInGame() and GetLastServerIP() or ""
end
concommand.Add("hacks_reload_menu", function()
  include('continuum/hacks_menu+.lua')
end)
concommand.Add("__cl_error", function(ply, cmd, args)
  hook.Run("OnLuaError", args[1], "client")
end)
concommand.Add("__cl_herror", function(ply, cmd, args)
  hook.Run("OnLuaError", args[1], "hacks")
end)
local Errors = {}
hook.Add( "OnLuaError", "MenuLuaErrorHandler", function( str, realm, addontitle, addonid )
  local text
  if realm == "hacks" then
    text = "Hacks are creating caught script errors: " .. str
  elseif realm == "notify" then
    text = "Note: " .. str
  else
    text = "Something is creating script errors: " .. str
  end
  if ( isstring( addonid ) ) then
    text = "The addon \""..addontitle.."\" is creating errors, check the console for details";
  end
  if  ( addonid == nil ) then addonid = str .. "/" .. realm; end
  if ( Errors[ addonid ] ) then
    Errors[ addonid ].times   = Errors[ addonid ].times + 1
    Errors[ addonid ].last    = SysTime()
    return;
  end
  local error =
    {
      first = SysTime(),
      last  = SysTime(),
      times = 1,
      title = addontitle,
      x   = 32,
      text  = text,
    }
  Errors[ addonid ] = error;
end )

local matAlert = Material( "icon16/error.png" );

hook.Add( "DrawOverlay", "MenuDrawLuaErrors", function()

    if ( table.Count( Errors ) == 0 ) then return end

    local idealy = 32;
    local height = 30;
    local EndTime = SysTime() - 30;
    local Recent = SysTime() - 0.5;

    for k, v in SortedPairsByMemberValue( Errors, "last" ) do

      local text = v.text .. " (x" .. v.times .. ")"
      surface.SetFont( "DermaDefaultBold" )
      if ( v.y == nil ) then v.y = idealy end
      --[[if ( v.w == nil ) then ]]v.w = surface.GetTextSize( text ); v.w = v.w + 48-- end


      draw.RoundedBox( 2, v.x+2, v.y+2, v.w, height, Color( 40, 40, 40, 255 ) )
      draw.RoundedBox( 2, v.x, v.y, v.w, height, Color( 240, 240, 240, 255 ) )

      if ( v.last > Recent ) then

        draw.RoundedBox( 2, v.x, v.y, v.w, height, Color( 255, 200, 0, (v.last - Recent) * 255 * 2 ) )

      end

      surface.SetTextColor( 90, 90, 90, 255 )
      surface.SetTextPos( v.x + 34, v.y + 8 )
      surface.DrawText( text );

      surface.SetDrawColor( 255, 255, 255, 150 + math.sin( v.y + SysTime() * 30 ) * 100 )
      surface.SetMaterial( matAlert )
      surface.DrawTexturedRect( v.x + 6, v.y + 6, 16, 16 )

      v.y = idealy;

      idealy = idealy + 32 + 8

      if ( v.last < EndTime ) then
        Errors[k] = nil
      end

    end

end )




local last = false
local continuum_icon = Material( "continuum/continuum.png" )
local checkmark_icon = Material( "continuum/checkmark.png" )
local redx_icon = Material( "continuum/redx.png" )
surface.CreateFont("ContinuumLoading", {
  font="DermaDefault",
  size=75,
  weight=600,
  antialias=true,
  shadow=true
})
surface.CreateFont("ContinuumLoadingSmall", {
  font="DermaDefault",
  size=20,
  weight=600,
  antialias=true,
  shadow=true
})
local state = 0
local timestamp = 0
local ok = true
local function CurTime()
  return os.clock() * 1000/3 -- 3 times slow
end
hook.Add("DrawOverlay", "DrawLoadingHUD", function()
  if state == 1 then
    draw.RoundedBox(16, ScrW()/2-250, ScrH()/2-50, 500, 100, Color(25,25,25,235))
    draw.DrawText("Loading...", "ContinuumLoading", ScrW()/2-215, ScrH()/2-35, Color(255,255,255), TEXT_ALIGN_CENTER )
    surface.SetDrawColor( Color(255,255,255,250) );
    surface.SetMaterial( continuum_icon );
    surface.DrawTexturedRectRotated( ScrW()/2+175, ScrH()/2, 64, 64, CurTime()/3);
  elseif state == 2 then
    local scale = 2 - (127/127500) * (CurTime() - timestamp)
    if scale > 1 then scale = 1 end
    if scale < 1/300 then
      state = 0
      return
    end
    draw.RoundedBox(16, ScrW()/2-250, ScrH()/2-50, 500, 100, Color(25,25,25,235*scale))
    draw.DrawText(ok and "Complete!" or "CE Error!", "ContinuumLoading", ScrW()/2-215, ok and ScrH()/2-35 or ScrH()/2-39, Color(255,255,255,scale*255), TEXT_ALIGN_CENTER )
    draw.DrawText(ok and "" or "Modules semi-loaded, partial functionality", "ContinuumLoadingSmall", ScrW()/2-215, ScrH()/2+22, Color(255,255,255,scale*255), TEXT_ALIGN_CENTER )
    surface.SetDrawColor( Color(255,255,255,250*scale) );
    surface.SetMaterial( ok and checkmark_icon or redx_icon );
    surface.DrawTexturedRect( ScrW()/2+160, ScrH()/2-29, 64, 64);
  end
end)
concommand.Add("__cl_loading", function()
  print("Menu lua confirms loading 1 tick late")
  timestamp = CurTime()
  state = 1
end)
concommand.Add("__cl_loaded", function(ply, cmd, args)
  print("Menu lua confirms loaded 1 tick late")
  timestamp = CurTime()
  ok = tobool(args[1])
  state = 2
end)
concommand.Add("serverscan", function(ply,cmd,args)
  local data =
    {
      Finished = function()
        print("FINISHED")
      end,

      Callback = function( ping , name, desc, map, players, maxplayers, botplayers, pass, lastplayed, address, gamemode, workshopid )
        print("Callback")
        name  = string.JavascriptSafe( name );
        desc  = string.JavascriptSafe( desc );
        map   = string.JavascriptSafe( map );
        address = string.JavascriptSafe( address );
        gamemode = string.JavascriptSafe( gamemode );
        workshopid = string.JavascriptSafe( workshopid );

        if ( pass ) then pass = "true" else pass = "false" end
        print(name)
        --pnlMainMenu:Call( "AddServer( '"..type.."', '"..id.."', "..ping..", \""..name.."\", \""..desc.."\", \""..map.."\", "..players..", "..maxplayers..", "..botplayers..", "..pass..", "..lastplayed..", \""..address.."\", \""..gamemode.."\", \""..workshopid.."\" )" );

      end,

      Type = 'internet',
      GameDir = 'garrysmod',
      AppID = 4000,
    }

  serverlist.Query( data )
end)


hook.Add("Think", "CLInitStuff", function()
  if not last then
    local res = RunOnClient([[
    SetGlobalVar('ServerIP', ']] .. GetLastServerIP() .. [[')
    local function ErrorHandler(error)
          local msg = "[CAUGHT ERROR] " .. error    
          local level = 2
          local info = debug.getinfo(level)
          local stack = { }
          while info do
              --table.insert(stack, info)
              stack[level] = info
              level = level + 1
              info = debug.getinfo(level)
          end
          for level,info in pairs(stack) do
            msg = msg .. "\n" .. string.rep(" ", level) .. (level-1) .. ". " .. (info.name or "unknown") .. " - "
            if(info.short_src ~= "[C]") then
              msg = msg .. (info.short_src == "" and "anonymous" or info.short_src) .. ":" .. info.currentline
            else
              msg = msg .. "[C]"
            end
          end
          print(msg)
          RunConsoleCommand("__cl_error", error)
          return msg
      end
      local function clinit()
        RunConsoleCommand('__cl_loading')
        print('------ Launching cl_init.lua ------')
        print("Compiling cl_init.lua");
        local result = CompileString(file.Read("continuum/cl_init.lua", "LUA") or "print('[No continuum/cl_init.lua file found]')", "continuum/cl_init.lua", false)
        if type(result) ~= "function" then
          ErrorHandler(result or "")
          RunConsoleCommand('__cl_loaded', false)
        else
          print("Executing cl_init.lua")
          success, callback = xpcall(result, ErrorHandler)
          if success then
            print("Complete!")
          else
            RunConsoleCommand('__cl_loaded', false)
          end
        end
      end
      concommand.Add("clinit_reload", clinit)
    if not CL_LOADED then
      CL_LOADED = true
      clinit()
    end
    ]], "clinit")
  end
  last = IsInGame()
end)




include("util_basic.lua")
local CE = CE
local ServerTable = CE.glon.decode(file.Read("continuum_servers.txt", "DATA") or "") or { }
if ServerLoadingComplete == nil then
  ServerLoadingComplete = true
end
local TotalServers = 3700 -- roughly right
local CurrentCount = 0
local pnlServer = vgui.RegisterFile( "server.lua" )
local vgui_server = nil

local GetServers = function( type, id )
  --[[if ServerLoadingComplete == false then
    local msg = "Last server loading not yet complete. Please wait for it to finish."
    MsgC(Color(255,100,100), msg, '\n')
    hook.Run("OnLuaError", msg, "notify")
    return
  end]]

  if ( IsValid( vgui_server ) ) then vgui_server:Remove() end

  vgui_server = GetOverlayPanel():Add( pnlServer )
  CurrentCount = 0
  --hacks_lua_menu Material('../gamemodes/terrortown/icon24.png')
  local data =
    {
      Finished = function()
        print("Finished. Total servers: " .. CurrentCount)
        file.Write("continuum_servers.txt", CE.glon.encode(ServerTable))
        if IsValid(vgui_server) then vgui_server:Remove() end
      end,

      Callback = function( ping , name, desc, map, players, maxplayers, botplayers, pass, lastplayed, address, gamemode, workshopid )
        ServerTable[address]={ping,name,desc,map,players,maxplayers,botplayers,pass,lastplayed,address,gamemode,workshopid}
        CurrentCount = CurrentCount + 1

        if ( not IsValid( vgui_server ) ) then
          vgui_server = GetOverlayPanel():Add( pnlServer )
        end

        vgui_server:UpdateDownloading(unpack(ServerTable[address]))
        vgui_server:UpdateProgress( CurrentCount, TotalServers )

        name  = string.JavascriptSafe( name );
        desc  = string.JavascriptSafe( desc );
        map   = string.JavascriptSafe( map );
        address = string.JavascriptSafe( address );
        gamemode = string.JavascriptSafe( gamemode );
        workshopid = string.JavascriptSafe( workshopid );

        if ( pass ) then pass = "true" else pass = "false" end

        pnlMainMenu:Call( "AddServer( '"..type.."', '"..id.."', "..ping..", \""..name.."\", \""..desc.."\", \""..map.."\", "..players..", "..maxplayers..", "..botplayers..", "..pass..", "..lastplayed..", \""..address.."\", \""..gamemode.."\", \""..workshopid.."\" )" );
      end,

      Type = type,
      GameDir = 'garrysmod',
      AppID = 4000,
    }
  ServerLoadingComplete = false
  serverlist.Query( data )

end
_G.GetServers = GetServers
hook.Add("Think", "EnsureBypassed", function()
  _G.GetServers = GetServers
  hook.Remove( "OnLuaError", "MenuErrorHandler" )
end)


CE.Client = { }
local Client = CE.Client
function Client._WriteUInt(value, size)
  Client.msg = Client.msg .. value
end
function Client._WriteString(value)
  Client.msg = Client.msg .. string.gsub(value, "|", "||") .. "|"
end
function Client._WriteFloat(value)
  Client.msg = Client.msg .. tostring(value) .. "|"
end
function Client._WriteBit(value)
  Client.msg = Client.msg .. tostring(value) .. "|"
end
function Client._WriteEntity(value)
  Client.msg = Client.msg .. tostring(IsValid(value) and value:EntIndex() or 0) .. "|"
end
function Client._WriteVector(value)
  Client.msg = Client.msg .. value.x .. "," .. value.y .. "," .. value.z .. "|"
end
function Client._WriteAngle(value)
  Client.msg = Client.msg .. value.p .. "," .. value.y .. "," .. value.r .. "|"
end
Client.WriteVars =
  {
    [TYPE_NIL]      = function ( t, v ) Client._WriteUInt( t, 8 )               end,
    [TYPE_STRING]   = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteString( v )    end,
    [TYPE_NUMBER]   = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteFloat( v )     end,
    [TYPE_TABLE]    = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteTable( v )     end,
    [TYPE_BOOL]     = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteBit( v )     end,
    [TYPE_ENTITY]   = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteEntity( v )    end,
    [TYPE_VECTOR]   = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteVector( v )    end,
    [TYPE_ANGLE]    = function ( t, v ) Client._WriteUInt( t, 8 ) Client._WriteAngle( v )     end,
  }
function Client._WriteType( v )
  local typeid = TypeID( v )
  local wv = net.WriteVars[ typeid ]
  if ( wv ) then return wv( typeid, v ) end
  print( "Couldn't write type " .. typeid )
end
function Client.CallHook(name, ...)
  local args = {...}
  Client.msg = ""
  Client._WriteType(name)
  for k,v in pairs(args) do
    Client._WriteType(v)
  end
  Client._WriteUInt(TYPE_FUNCTION)
  RunOnClient([[CE.Client.ReceiveHook("]] .. string.gsub(Client.msg, '"', '\\"') .. [[")]])
end

include("../modules/debug.lua")
MODULE = { }
include("luapad_editor.lua")
MODULE = { }
include("luapad.lua")
MODULE = nil
CE.HideGlobal()