
PANEL.Base = "DPanel"

surface.CreateFont( "WorkshopLarge",
{
  font    = "Helvetica",
  size    = 19,
  antialias = true,
  weight    = 800
})

local pnlRocket     = vgui.RegisterFile( "server_rocket.lua" )
local matProgressCog  = Material( "gui/progress_cog.png", "nocull smooth mips" )
local matHeader     = Material( "gui/steamworks_header.png" )

AccessorFunc( PANEL, "m_bDrawProgress",       "DrawProgress",       FORCE_BOOL )

function PANEL:Init()

  self.Label = self:Add( "DLabel" )
  self.Label:SetText( "Updating Servers..." )
  self.Label:SetFont( "WorkshopLarge" )
  self.Label:SetTextColor( Color( 255, 255, 255, 200 ) )
  self.Label:Dock( TOP )
  self.Label:DockMargin( 16, 10, 16, 8 )
  self.Label:SetContentAlignment( 5 )

  self.ProgressLabel = self:Add( "DLabel" )
  self.ProgressLabel:SetText( "-" )
  self.ProgressLabel:SetContentAlignment( 7 )
  self.ProgressLabel:SetVisible( false )
  self.ProgressLabel:SetTextColor( Color( 255, 255, 255, 50 ) )

  self.TotalsLabel = self:Add( "DLabel" )
  self.TotalsLabel:SetText( "Processing" )
  self.TotalsLabel:SetContentAlignment( 7 )
  self.TotalsLabel:SetVisible( false )
  self.TotalsLabel:SetTextColor( Color( 255, 255, 255, 50 ) )
  
  self:SetDrawProgress( false )

  self.Progress = 0
  self.TotalProgress = 0;
    
end

function PANEL:PerformLayout()

  self:SetSize( 500, 80 )
  self:Center()
  self:AlignBottom( 16 )

  self.ProgressLabel:SetSize( 100, 20 )
  self.ProgressLabel:SetPos( self:GetWide() - 100, 40 )

  self.TotalsLabel:SetSize( 100, 20 )
  self.TotalsLabel:SetPos( self:GetWide() - 100, 60 )
  
end

function PANEL:Spawn()

  self:PerformLayout()

end
function PANEL:UpdateDownloading( ping , name, desc, map, players, maxplayers, botplayers, pass, lastplayed, address, gamemode, workshopid )
  

  if ( not self.Rocket) then
    self.Rocket = self:Add( pnlRocket );
    self.Rocket:Dock( LEFT )
    self.Rocket:MoveToBack();
    self.Rocket:DockMargin( 8, 0, 8, 0 )
  end
  self.Label:SetText( "Retrieving \"" .. name .. "\"" );
  local iconpath = 'gamemodes/' .. gamemode .. '/icon24.png'
  if not file.Exists(iconpath, 'GAME') then
    iconpath = 'gamemodes/base/icon24.png'
  end
  self.Rocket:Charging( iconpath )
  self:SetDrawProgress( true )
  self.ProgressLabel:Show()
  self.ProgressLabel:SetText( "Progress" )

  self.TotalsLabel:Show()
  self.TotalsLabel:SetText( address )

  self:UpdateProgress( 0, 0 )
  
end

function PANEL:FinishedDownloading( id, title )
  
  self.Progress = 0
  --self:SetDrawProgress( false )
  --self.ProgressLabel:Hide()
  --self.TotalsLabel:Hide()
  --self.Rocket:Blast()
  
end
surface.CreateFont( "ContinuumServerOverlayTitle", {
  font = "Arial",
  size = 32,
  weight = 500,
  blursize = 0,
  scanlines = 0,
  antialias = true,
  underline = false,
  italic = false,
  strikeout = false,
  symbol = false,
  rotary = false,
  shadow = false,
  additive = false,
  outline = true,
} )
function PANEL:Paint()

  DisableClipping( true )
    draw.RoundedBox( 4, -1, -1, self:GetWide()+2, self:GetTall()+2, Color( 0, 0, 0, 255 ) )
  DisableClipping( false )

  draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 50, 50, 50, 255 ) )
  
  surface.SetDrawColor( 0, 0, 0, 100 )
  surface.SetMaterial( matProgressCog );
  surface.DrawTexturedRectRotated( 0, 32, 64 * 4, 64 * 4, SysTime() * -20 )
  
  if ( self:GetDrawProgress() ) then
  
    -- Overall progress
    local off = 0;
    local w = (self:GetWide() - 64 - 64 - 100)
    local x = 80
    
    draw.RoundedBox( 4, x+32 + off, 44 + 18, w, 10, Color( 0, 0, 0, 150 ) )
    draw.RoundedBox( 4, x+33 + off, 45 + 18, w * math.Clamp( self.TotalProgress, 0.05, 1 )-2, 8, Color( 255, 255, 255, 200 ) )

    -- Current file Progress
    draw.RoundedBox( 4, x+32, 40, w, 15, Color( 0, 0, 0, 150 ) )
    draw.RoundedBox( 4, x+33, 41, w * math.Clamp( self.Progress, 0.05, 1 )-2, 15-2, Color( 255, 255, 255, 200 ) )
    
  end
  
  -- Workshop LOGO
  DisableClipping( true )

    local x = -8;

    --[[surface.SetDrawColor( 255, 255, 255, 255 )
    surface.SetMaterial( matHeader );
    surface.DrawTexturedRect( x, -22, 128, 32 )
    
    surface.SetDrawColor( 255, 255, 255, math.random( 0, 255 ) )
    surface.DrawTexturedRect( x, -22, 128, 32 )]]
    -- height = 32
    surface.SetTextPos(x, -22)
    surface.SetFont("ContinuumServerOverlayTitle")
    surface.SetTextColor( 255, 255, 255, 255 )
    surface.DrawText("Server Listing Info")

  DisableClipping( false )
  
end

function PANEL:UpdateProgress( downloaded, expected )

  self.Progress = downloaded / expected

  if ( self.Progress > 0 ) then
    self.ProgressLabel:SetText( Format( "%.0f%%", math.min((self.Progress) * 100, 100) ) .. " of " .. expected )
  else
    self.ProgressLabel:SetText( expected )
  end

end

function PANEL:UpdateTotalProgress( completed, iTotal )

  self.TotalsLabel:SetText( "Addon "..completed.." of "..iTotal );
  self.TotalProgress = completed / iTotal;

end
