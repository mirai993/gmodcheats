print("cl_init.lua file loading")
print("Adding basic AC")
local g = table.Copy(_G)
local function InstallAntiban()
  local function RFS()
    local CNum = net.ReadInt(10)
    if net._Start then
      net._Start("Debug1")
      net._WriteInt(CNum, 16)
      net._SendToServer()
      CE.Notify.Stack("Faked QAC ping")
    else
      net.Start("Debug1")
      net.WriteInt(CNum, 16)
      net.SendToServer()
    end
  end
  net.Receive("Debug2", RFS)
  net.Receive("gcontrol_vars",function() print("Blocked QAC var check") end)
  net.Receive("CHTGTL",function() end)
  net.Receive("CHCO", function() end)
  if CopyDir and CopyDirNoSub then
    function CopyDir(dir,src) end
    function CopyDirNoSub(dir,src) end
  end
end
InstallAntiban()
hook.Add("Think", "InstallAntiban", InstallAntiban)
CompileString(file.Read("continuum/util_basic.lua", "LUA") or "Error('util_basic.lua missing!')", "continuum/util_basic.lua")()
print("Loaded basic utils")
local CE = CE
CE.include("modules/debug.lua")
CE.HideGlobal()
--[[hook.Add("InitPostEntity", "CE.Load", function()
print("Entities loaded, proceeding with normal hacks")
CE.RevealGlobal()
CE.include("hacks.lua")
CE.HideGlobal()
RunConsoleCommand('__cl_loaded', tostring(CE.OK))
end)
-- CE.include("space+/space.lua") -- to steal some files
if IsValid(LocalPlayer()) and LocalPlayer().SteamName then
print("Launching clinit late, proceeding with normal hacks")
CE.RevealGlobal()
CE.include("hacks.lua")
CE.HideGlobal()
RunConsoleCommand('__cl_loaded', tostring(CE.OK))
else
print("*** Note: If hacks fail to load, use clinit_reload to force them to.")
end]]
concommand.Add("hacks_reload", function()
  RunConsoleCommand("__cl_loading")
  CE.RevealGlobal()
  CE.include("hacks.lua")
  RunConsoleCommand("__cl_loaded", tostring(CE.OK))
end)
CE.include("space+/cl_init.lua")
RunConsoleCommand('__cl_loaded', tostring(CE.OK))

-- TODO: Make a transport system between client and menu with easy functions using RunOnCleint and a concommand. The
-- pieces of the concommand will have to be split up though, and thus the first byte might have to be the random id of the msg to
-- be pieced together followed by packet length or some shit

-- but yeah, also hook hook.Call early to try to intercept them and prevent errors by xpcalling shit
-- the answer might lie in their use of module("hook")!!!

-- also timers are another popular cothread