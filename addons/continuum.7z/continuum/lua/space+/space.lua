local Source = Source or { }
local S = Source
Source.LP = LocalPlayer()
Source._G = table.Copy(_G)
local G = Source._G
Source._R = debug.getregistry()
local R = Source._R
Source.Filters = {
  NoSelf = function(ply) return ply ~= S.LP end,
  
}
Source.Sorts = {
  ClosestFirst = function(a, b) return S.LP:GetPos():Distance(a:GetPos()) < S.LP:GetPos():Distance(b:GetPos()) end,
  FarthestFirst = function(a, b) return S.LP:GetPos():Distance(a:GetPos()) > S.LP:GetPos():Distance(b:GetPos()) end,
}
function Source.GetPlayers(filter, sort)
  if not G.player or not G.player.GetAll then return nil end
  local tbl = { }
  for n,ply in G.pairs(G.player.GetAll()) do
    ply = Source.Entity(ply)
    if not filter or filter(ply) then
      G.table.insert(ply, tbl)
    end
  end
  G.table.sort(tbl, sort)
  return tbl
end
function Source.GetEnts(filter, sort)
  if not G.ents or not G.ents.GetAll then return nil end
  local tbl = { }
  for n,ent in G.pairs(G.ents.GetAll()) do
    ent = Source.Entity(ent)
    if not filter or filter(ent) then
      G.table.insert(ent, tbl)
    end
  end
  G.table.sort(tbl, sort)
  return tbl
end
Source.Entity = function(id)
  if G.type(id) == "number" then id = G.Entity(id) end
  return id
end
function Source.CopyDir(path, type)
  local file = G.file
  local dataFolder = "source/"
  path = path or ""
  file.CreateDir(dataFolder .. (type == "LUA" and "lua/" or "") .. path, "DATA")
  local files, directories = file.Find(path .. "*", type)
  for _,v in pairs(files) do
    --print("OLD " .. type .. ": " .. path .. v)
    local old = path .. v
    -- can't write to files unless they end in .txt, so throw that on there too
    local new = dataFolder .. (type == "LUA" and "lua/" or "") .. path .. v .. ".txt"
    --print("NEW " .. type .. ": " .. new)
    if file.Exists(new, "DATA") then file.Delete(new, "DATA") end
    local contents = file.Read(old, type)
    if not contents then contents = "--[[ Unable to be read ]]" end
    file.Write(new, contents, "DATA")
  end
  for _,v in pairs(directories) do
    Source.CopyDir(path .. v .. "/", type)
  end
end
--[[copyDir("", "LUA") -- copy all lua
copyDir("gamemodes/", "GAME") -- copy  gamemodes folder
copyDir("addons/", "GAME") -- copy addons?
copyDir("cfg/", "GAME") -- copy cfg folder]]

-- NOTE: You will see some files that are just from your folders, but any new ones are from server
-- Files copied to garrysmod/data/source/