if MENU_DLL then
  GlobalVariables = GlobalVariables or { }
  function GetGlobalVar(key, default)
    if GlobalVariables[key] then
      return GlobalVariables[key]
    end
    return default
  end
  function SetGlobalVar(key, value)
    GlobalVariables[key] = value
  end
end

local Source = Source or { }
Source.Session = system.Session or { }
system.Session = Source.Session
Source.Debug = Source.Session.Debug
if not Source.Debug then
  local dbg = { }
  for k,v in pairs(debug) do
    if k ~= "Trace" then -- Trace is a lua function, so we can emulate it ourselves and not worry
      local info = jit.util.funcinfo(v)
      if not info.addr then
        print("ERROR: Found infected debug entry for [debug." .. k .. "], source: " .. info.source)
        return
      end
      dbg[k] = v
    end
  end
  dbg.Trace = function()
    local level = 1
    Msg( "\nTrace: \n" )
    while true do
      local info = dbg.getinfo(level, "Sln")
      if (not info) then break end
      if (info.what) == "C" then
        Msg(level, "\tC function\n")
      else
        Msg( string.format( "\t%i: Line %d\t\"%s\"\t%s\n", level, info.currentline, info.name, info.short_src ) )
      end
      level = level + 1
    end
    Msg( "\n\n" )
  end
  Source.Debug = dbg
  Source.Session.Debug = dbg
end
local Debugger = { }
Source.Debugger = Debugger
function Debugger.GetUpvalues(func)
  local UpvalueTable = { }
  for idx=1, Source.Debug.getinfo(func).nups do
    local uk,uv = Source.Debug.getupvalue(func, idx)
    if not uk or uk == "" then break end
    if not uk:starts("(") then UpvalueTable[uk] = uv end
  end
  return UpvalueTable
end
function Debugger.GetLocals(level)
  level = level + 1 -- ignore this level
  local LocalsTable = { }
  for idx=1,100 do -- if you use over 100 locals at once, fuck you
    local lk,lv = Source.Debug.getlocal(level, idx)
    if not lk or lk == "" then break end
    if not lk:starts("(") then
      LocalsTable[lk] = lv
    end
  end
  return LocalsTable
end
function Debugger.GetUpvalue(func, name)
  local tbl = Debugger.GetUpvalues(func)
  for k,v in g.pairs(tbl) do
    if k == name then return v end
  end
  return nil
end
function Debugger.GetLocal(level, name)
  local tbl = Debugger.GetLocals(level + 1) -- ignore this level
  for k,v in G.pairs(tbl) do
    if k == name then return v end
  end
  return nil
end
function Debugger.SetUpvalue(func, name, value)
  local index = -1
  for idx=1,Source.Debug.getinfo(func).nups do -- if you use over 100 upvalues at once, fuck you
    local uk,uv = Source.Debug.getupvalue(func, idx)
    if not uk or uk == "" then break end
    if uk == name then
      index = idx
      break
    end
  end
  if index ~= -1 then
    Source.Debug.setupvalue(func, index, value)
    return true
  end
  return false
end
function Debugger.SetLocal(level, name, value)
  level = level + 1 -- ignore this level
  local index = -1
  for idx=1,100 do
    local uk,uv = Source.Debug.getlocal(level, idx)
    if not uk or uk == "" then break end
    if uk == name then
      index = idx
      break
    end
  end
  if index ~= -1 then
    Source.Debug.setlocal(level, index, value)
    return true
  end
  return false
end
function Debugger.GetStack(level)
  local info = Source.Debug.getinfo(level+1)
  local stack = { }
  while info do
    stack[level] = info
    level = level + 1
    info = Source.Debug.getinfo(level+1)
  end
  return stack
end
local function CreateSandboxTable()
  local tbl = { unpack=unpack }
  local MT = { __index = function() return tbl end, __newindex = function() end, __call = function() return tbl end }
  setmetatable(tbl, MT)
  return tbl
end
function Source.AntiDetour(func, data, level)
  local info = jit.util.funcinfo(func)
  local pass = true
  for k,v in pairs(data) do
    pass = pass and info[k] == v
  end
  if pass then return func end
  local Match = nil
  local t = { }
  for i=1,20 do
    table.insert(t, CreateSandboxTable())
  end
  local function RunSandbox()
    func(unpack(t))
  end
  Source.Debug.setfenv(RunSandbox, CreateSandboxTable())
  Source.Debug.sethook(function(type)
    local func = Source.Debug.getinfo(2).func
    local info = jit.util.funcinfo(func)
    local pass = true
    for k,v in pairs(data) do
      pass = pass and info[k] == v
    end
    if pass then Match = func end
  end, "c")
  RunSandbox()
  Source.Debug.sethook()
  Source.Debug.setfenv(RunSandbox, _G)
  return Match
end
function debug.getinfo(func, a, b, c)
  local requested = Source.Debug.getinfo(func, a, b, c)
  local caller = Source.Debug.getinfo(2)
  local caller_caller = Source.Debug.getinfo(3)
  if caller.short_src:starts("space+/") or caller.short_src:starts("modules/")
    or caller_caller.short_src:starts("space+/") or caller_caller.short_src:starts("modules/")
    or caller.short_src == "util.lua" or caller.short_src == "hacks.lua" or caller.short_src == "developer.lua"
    or a == 'CE'
    or Source.Debugging then
    Source.Debugging = false
    return requested
  end
  print("Blocked " .. caller.short_src .. "/" .. caller_caller.short_src)
  if requested and requested.short_src:starts("space+/") then
    -- these locations should be whitelisted:
    requested.short_src = "[C]"--"lua/includes/extensions/debug.lua"
    requested.source = "[C]"--"@lua/includes/extensions/debug.lua"
  end
  return requested
end
--[[ ulx hook.Add
bytecodes  46
children   false
currentline  89
gcconsts   6
isvararg   false
lastlinedefined  106
linedefined  89
loc  hook.lua:89
nconsts  0
params   4
source   @addons/ulib/lua/ulib/shared/hook.lua
stackslots   7
upvalues   6
]]
--[[ vanilla hook.Add
bytecodes  24
children   false
currentline  23
gcconsts   0
isvararg   false
lastlinedefined  34
linedefined  23
loc  hook.lua:23
nconsts  0
params   3
source   @lua/includes/modules/hook.lua
stackslots   5
upvalues   3
]]
--[[ vanilla hook.GetTable
bytecodes 3
gcconsts  0
upvalues  1
source  @lua/includes/modules/hook.lua

]]


--local VanillaHookTable = Source.AntiDetour(hook.GetTable, )
_G.Source = Source