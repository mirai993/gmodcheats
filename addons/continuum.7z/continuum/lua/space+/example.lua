print("EXAMPLE LOADED")
local lastAdjustment = Angle(0,0,0)
hook.Add("CreateMove", "CE.NoSpread", function(cmd)
  if cmd:CommandNumber() ~= 0 then
    print("Delta: " .. cmd:CommandNumber())
  else
    print("Delta: FAILURE")
  end
end)