chat.AddText("Loading client testing stuff...");
local ent = nil
surface.CreateFont( "HoverInfo", {
 font = "Arial",
 size = 18,
 weight = 1000,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = true,
 additive = false,
 outline = false
} )
hook.Add("PreDrawHalos", "HoverInfo", function()
  ent = properties.GetHovered( LocalPlayer():EyePos(), LocalPlayer():GetAimVector() )
  if ( not IsValid( ent ) or LocalPlayer():GetPos():Distance(ent:GetPos()) > 1000 ) then return end
  local c = Color( 0, 0, 255, 255 )
  if ( ent:IsPlayer() ) then
	if ( ent:GetRole() == ROLE_TRAITOR ) then
		c = Color( 255, 0, 0 );
	elseif ( ent:GetRole() == ROLE_DETECTIVE ) then
		c = Color( 0, 0, 255 );
	else
		c = Color( 0, 255, 0 );
	end
  elseif ( ent:IsWeapon() ) then
	
  else
	return;
  end
  halo.Add( {ent}, c, 2, 2, 7, true, false );
end)
hook.Add("HUDPaint", "HoverInfo", function()
	if IsValid(ent) then
	  if ( ent:IsWeapon() ) then
		surface.SetDrawColor( Color( 0,0,0,200) )
		surface.SetFont("HoverInfo");
		local text = "Weapon: " .. ent.PrintName
		local position = ent:GetPos():ToScreen();
		local width, height = surface.GetTextSize(text)
		surface.DrawRect( position.x + 5, position.y - 2, width + 10, height + 4)
		draw.DrawText(text, "HoverInfo", position.x + 7, position.y, Color(255, 255, 255, 255),TEXT_ALIGN_LEFT)
	  end
	end
end)