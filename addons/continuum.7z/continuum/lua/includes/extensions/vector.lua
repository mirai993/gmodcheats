local meta = FindMetaTable( "Vector" )

-- Nothing in here, still leaving this file here just in case
