local meta = FindMetaTable( "Angle" )

-- Nothing in here, still leaving this file here just in case
