local CE = CE

function surface.FontExists(FontName)
	local success, callback = pcall(surface.SetFont, FontName)
	return success
end

-- Fuck you derma, trying to give OSX some shitty default font...
-- Helvetica SUCKS
local DermaDefaultFont = CreateConVar( "derma_font_default", "Tahoma", { FCVAR_PROTECTED, FCVAR_ARCHIVE }, "Font to use for default Derma elements. Default is Tahoma" )
local DermaChatFont = CreateConVar( "derma_font_chat", "Verdana", { FCVAR_PROTECTED, FCVAR_ARCHIVE }, "Font to use for chat. Default is Verdana" )
if not surface.FontExists("_ChatFont") then
	surface.CreateFont("_ChatFont", {font="ChatFont"})
end
local function UpdateFont()
  local DermaDefaultFont = DermaDefaultFont and DermaDefaultFont:GetString() or "Tahoma"
  DermaDefaultFont = "Helvetica neue"
	surface.CreateFont( "DermaDefault",
	{
		font		= DermaDefaultFont,
		size		= 14,
		antialias	= true,
		weight		= 500
	})
	surface.CreateFont( "DermaDefaultBold",
	{
		font		= DermaDefaultFont,
		size		= 13,
		antialias	= false,
		weight		= 800
	})
end
cvars.AddChangeCallback("derma_font_default", UpdateFont)
function cvars.OnConVarChanged( name, oldvalue, newvalue )
	local Callbacks = cvars.GetConVarCallbacks( name, false )
	CE.Hook.Call("OnConVarChanged", nil, name, oldvalue, newvalue)
	if (not Callbacks) then return end
	for k, v in pairs( Callbacks ) do
		v( name, oldvalue, newvalue )
	end
end
UpdateFont() -- when the convar is first loaded, a change callback wont be called, so we'll manually call it

local CachedLocals = { CE=CE }
local function get_locals()
	local variables = {}
	local idx = 1
	while true do
		local ln, lv = debug.getlocal(2, idx)
		if ln ~= nil and #ln > 0 and ln:sub(1,1) ~= "(" then
			variables[ln] = lv
		else
			break
		end
		idx = 1 + idx
	end
	for name,val in pairs(variables) do
		CachedLocals[name] = val
	end
	return variables
end
local Leaders = {
	["Hangmen Leader"]={"Hangmen Gangster"},
	["Firebirds Leader"]={"Firebirds Gangster"}
}
local Groups = {
	{"Hangmen Leader", "Hangmen Gangster"},
	{"Firebirds Leader", "Firebirds Gangster"}
}
if not chat._AddText then chat._AddText = chat.AddText end
function chat.AddText(...)
	local args = {...}
	if #args == 4 and CE.Colors.IsColor(args[1]) and CE.Colors.IsColor(args[3]) and CE.Colors.Equal(args[1], CE.Colors.WHITE) and CE.Colors.Equal(args[3], CE.Colors.RED) and args[4] == "Raid!" then
		local name = args[2]
		name = name:sub(1, #name-2)
		local raider = player.GetByName(name)
		local Team = team.GetName(raider:Team())
		local children = Leaders[Team]
		CE.Console.AdminLog(CE.Colors.WHITE, Team, " ", raider:Nick(), ": ", CE.Colors.RED, "Raid!")
		if children then
			for k,v in pairs(player.GetAll()) do
				Team = team.GetName(v:Team())
				if table.containsValue(children, Team) and v:GetPos():Distance(raider:GetPos()) < 1500 then
					CE.Console.AdminLog("\t",CE.Colors.WHITE, Team, " ", v:Nick(), ": ", CE.Colors.RED, "Raid!")
				end
			end
		end
	end
	chat._AddText(...)
end
function CE.Console.RunLua(lua)
	CE.Console.LuaLog("> ", lua)
	lua = lua:Trim()

	local DoLog = false
	if lua:starts("=") then
		DoLog = true
		lua = lua:sub(2)
	elseif lua:starts("return ") then
		DoLog = true
		lua = lua:sub(8)
	end
	if DoLog then
		lua = "local _retval = " .. lua
	end
	for name,v in pairs(CachedLocals) do
		print(name)
		lua = "local "..name.." = CachedLocals['"..name.."']\n"..lua -- preload all their previous locals
	end
	if DoLog then
		lua = lua .. "\nprint( _retval )\n_retval = nil"
	end
	lua = lua .. "\nlocalization()"
	local tmpprint = print
	local tmperror = error
	function print(...)
		local log = {...}
		table.insert(log, 1, "\t")
		CE.Console.LuaLog(unpack(log))
	end
	local func, error = CompileString(lua, "DeveloperLua", false)
	if error then
		print(CE.Colors.RED, "[COMPILE ERROR] ", error)
		print(error)
		print(func)
	else
		_G["localization"] = get_locals
		_G["CachedLocals"] = CachedLocals
		local success, callback = pcall(func)
		_G["CachedLocals"] = nil
		_G["localization"] = nil
		if not success then
			print(CE.Colors.RED, "[RUNTIME ERROR] ", callback)
		elseif callback ~= nil then
			print(tostring(callback))
		end
	end
	print = tmpprint

end
function CE.Console.RunCommand(cmd)
-- todo: parse quotes and stuff I guess
end
local ColorLevel = 1

local IsReload = CE.Session.ConsoleFrame and true or false
if IsReload then CE.Session.ConsoleFrame:Remove(); end
local ConsoleFrame = vgui.Create("DFrame")
CE.Session.ConsoleFrame = ConsoleFrame
ConsoleFrame:SetSize(500, 500)
ConsoleFrame:SetTitle( "Continuum Console" )
ConsoleFrame:SetDraggable( true )
ConsoleFrame:ShowCloseButton( true )
ConsoleFrame:SetPos(100, 100)
ConsoleFrame:MakePopup()
ConsoleFrame:SetSizable(true)
ConsoleFrame:SetVisible(false)
if not ConsoleFrame._PerformLayout then ConsoleFrame._PerformLayout = ConsoleFrame.PerformLayout end
local Sheet = vgui.Create("DPropertySheet", ConsoleFrame)
Sheet:SetPos(5,25)
local DeveloperTab = vgui.Create("DPanel")
local AdminTab = vgui.Create("DPanel")
local LuaTab = vgui.Create("DPanel")
Sheet:AddSheet( "Lua Console", LuaTab, "gui/silkicons/box", false, false, "Lua Console" )
Sheet:AddSheet( "Developer logs", DeveloperTab, "gui/silkicons/box", false, false, "Developer information" )
Sheet:AddSheet( "Admin logs", AdminTab, "gui/silkicons/box", false, false, "Administrative logs" )

local DeveloperOutput = vgui.Create("RichText", DeveloperTab)
local AdminLogsOutput = vgui.Create("RichText", AdminTab)
local LuaOutput = vgui.Create("RichText", LuaTab)
function DeveloperTab:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function LuaTab:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function AdminTab:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function DeveloperOutput:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function AdminLogsOutput:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function LuaOutput:Paint()
	surface.SetDrawColor( Color( 0, 0, 0,150 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end
function ConsoleFrame:Paint()
	surface.SetDrawColor( Color( 100, 100, 100,200 ) )
	surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
end

local DeveloperInputArea = vgui.Create("DTextEntry", DeveloperTab)
DeveloperInputArea:SetBGColor(CE.Colors.WHITE)
local DoCommand = function()
	CE.Console.RunCommand(DeveloperInputArea:GetText())
	DeveloperInputArea:SetText("")
	DeveloperInputArea:RequestFocus()
end
DeveloperInputArea.OnEnter = DoCommand

local DeveloperSubmitButton = vgui.Create("Button", DeveloperTab)
DeveloperSubmitButton:SetText("Submit")
DeveloperSubmitButton.DoClick = DoCommand


local LuaInputArea = vgui.Create("DTextEntry", LuaTab)
LuaInputArea:SetBGColor(CE.Colors.WHITE)
LuaInputArea:SetFont("default")
--local LuaAutocompleteArea = vgui.Create("DLabel", LuaInputArea)
--LuaAutocompleteArea:SetBGColor(CE.Colors.WHITE)
--LuaAutocompleteArea:SetText("Test text goes here so its cool")
--LuaAutocompleteArea:SetFont("default")
--LuaAutocompleteArea:SetFGColor(Color(130, 130, 130, 150))
local DoCommand = function()
	CE.Console.RunLua(LuaInputArea:GetText())
	LuaInputArea:SetText("")
	LuaInputArea:RequestFocus()
end
LuaInputArea.OnEnter = DoCommand
CE.Console.Print(LuaInputArea:GetFont())
--CE.Console.Print(LuaAutocompleteArea:GetFont())
CE.Console.Print(LuaInputArea:GetTextSize())
--CE.Console.Print(LuaAutocompleteArea:GetTextSize())
local LuaSubmitButton = vgui.Create("Button", LuaTab)
LuaSubmitButton:SetText("Run")
LuaSubmitButton.DoClick = DoCommand


function CE.Console.AdminLog(...)
	local args = {...}
	table.insert(args, #args+1, "\n")
	return CE.Console.AdminLogNLn(unpack(args))
end
function CE.Console.AdminLogNLn(...)
	local args = {...}
	AdminLogsOutput:InsertColorChange(255,255,255,255)
	for k,v in pairs(args) do
		if CE.Colors.IsColor(v) then
			AdminLogsOutput:InsertColorChange(v.r,v.g,v.b,v.a)
		else
			AdminLogsOutput:AppendText(tostring(v))
		end
	end
	AdminLogsOutput:InsertColorChange(255,255,255,255)
end
function CE.Console.LuaLog(...)
	local args = {...}
	table.insert(args, #args+1, "\n")
	return CE.Console.LuaLogNLn(unpack(args))
end
function CE.Console.LuaLogNLn(...)
	local args = {...}
	LuaOutput:InsertColorChange(255,255,255,255)
	for k,v in pairs(args) do
		if CE.Colors.IsColor(v) then
			LuaOutput:InsertColorChange(v.r,v.g,v.b,v.a)
		else
			LuaOutput:AppendText(tostring(v))
		end
	end
	LuaOutput:InsertColorChange(255,255,255,255)
end
CE.Hook.Add("OnPlayerChat", "CE.ChatCommands", function( ply, strText, bTeamOnly, bPlayerIsDead )
	if not CE.IsDarkRP() then
		local tab = {}
		if ( bPlayerIsDead ) then
			table.insert( tab, Color( 255, 30, 40 ) )
			table.insert( tab, "*DEAD* " )
		end
		if ( bTeamOnly ) then
			table.insert( tab, Color( 30, 160, 40 ) )
			table.insert( tab, "(TEAM) " )
		end
		if ( IsValid( ply ) ) then
			table.insert( tab, ply:GetName() )
		else
			table.insert( tab, "Console" )
		end
		table.insert( tab, Color( 255, 255, 255 ) )
		table.insert( tab, ": "..strText )
		CE.Console.AdminLogNLn("PChat: { ")
		CE.Console.AdminLogNLn(unpack(tab))
		CE.Console.AdminLog(" }")
	end

end)

-- Darkrp chat:
local function AddToChat(msg)
	local col1 = Color(msg:ReadShort(), msg:ReadShort(), msg:ReadShort())
	local prefixText = msg:ReadString()
	local ply = msg:ReadEntity()
	ply = IsValid(ply) and ply or LocalPlayer()
	if prefixText == "" or not prefixText then
		prefixText = ply:Nick()
		prefixText = prefixText ~= "" and prefixText or ply:SteamName()
	end

	local col2 = Color(msg:ReadShort(), msg:ReadShort(), msg:ReadShort())

	local text = msg:ReadString()
	if prefixText:sub(0,8) == "[Advert]" and text:lower():find("mug") then
		
		
		local Group
		for _,group in pairs(Groups) do
			for __,teamName in pairs(group) do
				if teamName == team.GetName(ply:Team()) then
					Group = group
					break
				end
			end
		end
		
		
		local pos = ply:GetPos()
		local ang = ply:GetAimVector()
		 
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos + ( ang * 300 )
		tracedata.filter = ply
		tracedata.mins = ply:OBBMins()
		tracedata.maxs = ply:OBBMaxs()
		 
		local tr = util.TraceHull( tracedata )
		local target = nil
		if IsValid(tr.Entity) and tr.Entity:IsPlayer() then
			target = tr.Entity
		else
			local players = player.GetAll()
			table.sort(players, function(x,y)return CE.DistanceTo(x:GetPos())>CE.DistanceTo(y:GetPos())end)
			for k,v in pairs(players) do
				if v ~= ply and (Group == nil or not table.containsValue(Group, team.GetName(v:Team()))) and v:GetPos():Distance(ply:GetPos()) < 300 then
					target = v
					break
				end
			end
		end
		
		CE.Console.AdminLog(CE.Colors.WHITE,team.GetName(ply:Team())," ",ply:Nick(),": ",CE.Colors.RED,"Mug on " .. (IsValid(target) and target:Nick() or "someone") .. "!")
		local plys = { ply }
		if Group then
			for k,v in pairs(player.GetAll()) do
				if table.containsValue(Group, team.GetName(v:Team())) and v:GetPos():Distance(ply:GetPos()) < 300 then
					table.insert(plys, v)
					CE.Console.AdminLog("\t",CE.Colors.WHITE, team.GetName(v:Team()), " ", v:Nick(), ": ", CE.Colors.RED, "Mug!")
				end
			end
		end
		if target == LocalPlayer() then
			CE.Muggers = plys
		end
	end
	local shouldShow
	if text and text ~= "" then
		if IsValid(ply) then
			shouldShow = hook.Call("OnPlayerChat", nil, ply, text, false, not ply:Alive(), prefixText, col1, col2)
		end

		if shouldShow ~= true then
			chat.AddText(col1, prefixText, col2, ": "..text)
		end
		CE.Console.AdminLog(col1, prefixText, col2, ": "..text)
	else
		shouldShow = hook.Call("ChatText", nil, "0", prefixText, prefixText, "none")
		if shouldShow ~= true then
			chat.AddText(col1, prefixText)
		end
	end
	chat.PlaySound()
end
usermessage.Hook("DarkRP_Chat", AddToChat)
local doors = { }
for k,door in pairs(ents.GetAll()) do
	if door.IsDoor and door:IsDoor() then
		table.insert(doors, door)
	end
end
-- I think it's safe to say we can just store doors once, right? PVS won't fuck that up?
local LastDoorIndex = 0
local LastDoorTime = 0
local function PlayerColor(ply)
	return IsValid(ply) and team.GetColor(ply:Team()) or CE.Colors.RED
end
local function PlayerName(ply, UseSteamName)
	if IsValid(ply) then
		return (UseSteamName and ply:SteamName() or ply:Name()) .. " (" .. ply:SteamID() .. ")"
	end
	return "(Disconnected)"
end
CE.Hook.Add("Think", "CE.AdminLog", function()
	if CE.IsTTT() then return end
	local players = player.GetAll()
	local hitman = team.GetPlayers(TEAM_HIT)[1]
	for _,fragger in pairs(players) do
		if fragger:Frags() ~= fragger.OldFrags and fragger.OldFrags ~= nil then
			for _,deather in pairs(player.GetAll()) do
				if deather:Deaths() ~= deather.OldDeaths and deather.OldDeaths ~= nil then
					if fragger == deather then
						hook.Run("PlayerKilledSelf", deather)
					else
						hook.Run("PlayerKilledPlayer", fragger, deather, fragger:GetActiveWeapon())
					end
				end
				deather.OldDeaths = deather:Deaths()
			end
		end
		fragger.OldFrags = fragger:Frags()
	end
	for _,ply in pairs(players) do
		if ply:Deaths() ~= ply.OldDeaths and ply.OldDeaths ~= nil then
			hook.Run("PlayerKilledSelf", ply)
		end
		if net.Receivers.hitman_request_menu then
			local hitted = ply:GetNWBool('hitted')
			local old = ply.OldHitted
			if old ~= nil and hitted ~= old then
				if hitted then
					local price = tonumber(ply:GetNWString('hit_reward'))
					ply.hitCustomer = CE.Session.RecentMoneyChanges[-price]
					ply.hitCustomer = ply.hitCustomer and ply.hitCustomer.player
					hook.Run("onHitAccepted", hitman, ply, ply.hitCustomer, price)
				else
					hook.Run("onHitCompleted", hitman, ply, ply.hitCustomer)
				end
			end
			ply.OldHitted = hitted
		end
		ply.OldDeaths = ply:Deaths()
	end

end)
CE.Hook.Add("Think", "SpawnCaller", function()
  for _,ply in pairs(player.GetAll()) do
    if ply:Alive() and not ply._OldAlive then
      CE.Hook.Run("PlayerSpawn", ply)
    end
    ply._OldAlive = ply:Alive()
  end
end)
CE.Hook.Add("PlayerSpawn", "SpawnKillTimer", function(ply)
  ply.SpawnTime = CurTime()
end)
CE.Hook.Add( "PlayerKilledPlayer", "CE.AdminLog", function(killer, victim, inflictor)
	CE.Console.AdminLog(PlayerColor(killer), PlayerName(killer), CE.Colors.WHITE, " killed ",
	PlayerColor(victim), PlayerName(victim), CE.Colors.WHITE, " with their ", inflictor.PrintName)
	if CE.IsDarkRP() and not GAMEMODE.Config.showdeaths then
		if IsValid(killer) and IsValid(victim) then
			GAMEMODE:AddDeathNotice( killer:Nick(), killer:Team(), IsValid(inflictor) and inflictor:GetClass() or "?", victim:Nick(), victim:Team(), false )
		end
	end
end)
CE.Hook.Add( "PlayerKilledSelf", "CE.AdminLog", function(victim)
	CE.Console.AdminLog(PlayerColor(victim), PlayerName(victim), CE.Colors.WHITE, " took his own life!")
	if CE.IsDarkRP() and not GAMEMODE.Config.showdeaths then
		GAMEMODE:AddDeathNotice( nil, 0, "suicide", victim:Nick(), victim:Team() )
	end
end)
CE.Hook.Add( "PlayerSoldDoor", "CE.AdminLog", function(ply,door,cost)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " sold a door for $", cost)
end)
CE.Hook.Add( "PlayerBoughtDoor", "CE.AdminLog", function(ply,door,cost)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " bought a door for $", cost)
end)
local function ConsoleMessage(um)
	local msg = um:ReadString()
	MsgC(Color(255,0,0,255), "(FAdmin) ")
	MsgC(Color(200,0,200,255), msg, "\n")
	CE.Console.AdminLog(Color(255,0,0,255), "(FAdmin) ", Color(200,0,200,255), msg) -- todo: manual?)
end
usermessage.Hook("FAdmin_ConsoleMessage", ConsoleMessage)
CE.Hook.Add( "DarkRPVarChanged", "CE.AdminLog", function(ply, var, o, n)
	if var == "money" then
		hook.Run("PlayerMoneyChanged", ply, o, n)
	elseif var == "rpname" and o ~= "" then
		hook.Run("PlayerChangedRPName", ply, o, n)
	elseif var == "wantedReason" then
		if n then
			hook.Run("PlayerWanted", ply, n)
			print(ply.DarkRPVars.wantedReason)
		end
	elseif var == "wanted" then
		if not n then
			hook.Run("PlayerUnwanted", ply)
		end
	elseif var == "Arrested" then
		if n then
			hook.Run("playerArrested", ply, GAMEMODE.Config.jailtimer or 120)
		else
			hook.Run("playerUnArrested", ply)
		end
	elseif var == "job" then
		if o then
			hook.Run("PlayerChangedJob", ply, o, n)
		end
	end
end)
local demoter = nil
if not CE.Session._DoVoteHook then CE.Session._DoVoteHook = usermessage.GetTable().DoVote end
local VoteIntercept = function(msg)
	local question = msg:ReadString()
	local voteid = msg:ReadShort()
	local timeleft = msg:ReadFloat()
	local msg = {
		ReadString=function()
			return question
		end,
		ReadShort=function()
			return voteid
		end,
		ReadFloat=function()
			return timeleft
		end
	}
	CE.Session._DoVoteHook.Function(msg) -- lil bit hacky
	local Identifier = ":\nDemotion nominee:\n"
	local idx = question:find(Identifier)
	if idx then
		local demotee = question:sub(1,idx-1)
		local reason = question:sub(idx+#Identifier)
		demotee = player.GetByName(demotee)
		CE.Console.AdminLog(PlayerColor(demoter), PlayerName(demoter), CE.Colors.WHITE, " started a vote for the demotion of ", PlayerColor(demotee),
		demotee, CE.Colors.WHITE, " for: ", reason)
	end

end
usermessage.Hook("DoVote", VoteIntercept)
local function DisplayNotify(msg)
	local txt = msg:ReadString()
	GAMEMODE:AddNotify(txt, msg:ReadShort(), msg:ReadLong())
	surface.PlaySound("buttons/lightswitch2.wav")
	print(txt)
	local Identifier = " has started a vote for the demotion of "
	local idx = txt:find(Identifier)
	if idx then
		demoter = txt:sub(1,idx-1)
		local demotee = txt:sub(idx+#Identifier)
		demoter = player.GetByName(demoter)
		demotee = player.GetByName(demotee)
		if demoter == LocalPlayer() or demotee == LocalPlayer() then
			CE.Console.AdminLog(PlayerColor(demoter), PlayerName(demoter), CE.Colors.WHITE, " started a vote for the demotion of ", PlayerColor(demotee), demotee)
			demoter = nil
		end
	end
end
usermessage.Hook("_Notify", DisplayNotify)


CE.Session.RecentMoneyChanges = CE.Session.RecentMoneyChanges or { }
local LastHitmanMoneyChange = nil
CE.Hook.Add( "PlayerChangedJob", "CE.AdminLog", function(ply, OldJobName, NewJobName)
	local OldJobId, NewJobId = ply:Team(), ply:Team()
	for k,v in pairs(team.GetAllTeams()) do
		if v.Name == NewJobName then NewJobId = k break end
	end
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " changed jobs from ", team.GetColor(OldJobId), OldJobName, CE.Colors.WHITE, " to ", team.GetColor(NewJobId), NewJobName)
end)
CE.Hook.Add( "PlayerKilledPlayer", "CE.HitmanAdminLog", function(killer, victim, inflictor)
	
end)
if net.Receivers.hitman_request_menu then
	timer.Create("CE.ClearOldMoney", 10, 0, function()
		for price,data in pairs(CE.Session.RecentMoneyChanges) do
			if not data.time or CurTime() > data.time + 10 then
				CE.Session.RecentMoneyChanges[price] = nil
				CE.SetSession("RecentMoneyChanges", CE.Session.RecentMoneyChanges)
			end
		end
	end)
end
CE.Hook.Add("PlayerMoneyChanged", "CE.AdminLog", function(ply, oldmoney, newmoney)
	if oldmoney and net.Receivers.hitman_request_menu then
		if type(oldmoney) == "number" and newmoney < oldmoney then
			if newmoney - oldmoney < 0 then
				CE.Session.RecentMoneyChanges[newmoney - oldmoney] = {player=ply, time=CurTime()}
				CE.SetSession("RecentMoneyChanges", CE.Session.RecentMoneyChanges)
			end
		end
	end
end)
CE.Hook.Add("PlayerChangedRPName", "CE.AdminLog", function(ply, oldname, newname)
	if oldname then
		CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply, true), CE.Colors.WHITE, " changed their rpname from ", CE.Colors.RED, oldname,
		CE.Colors.WHITE, " to ", CE.Colors.RED, newname)
	end
end)
CE.Hook.Add("playerArrested", "CE.AdminLog", function(ply, time)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " was arrested for ", time, " seconds")
end)
CE.Hook.Add("playerUnarrested", "CE.AdminLog", function(ply)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " was released from jail.")
end)
CE.Hook.Add("PlayerWanted", "CE.AdminLog", function(ply, reason)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " was made wanted for: ", reason)
end)
CE.Hook.Add("PlayerUnwanted", "CE.AdminLog", function(ply)
	CE.Console.AdminLog(PlayerColor(ply), PlayerName(ply), CE.Colors.WHITE, " is no longer wanted by the Police.")
end)
CE.Hook.Add("onHitAccepted", "CE.AdminLog", function(hitman, target, customer, price)
	local priceStr = price and (" for $" .. price) or ""
	CE.Console.AdminLog(PlayerColor(hitman), PlayerName(hitman), CE.Colors.WHITE, " accepted a hit on ", PlayerColor(target),
	target, CE.Colors.WHITE, " from ", CE.Colors.RED, customer, CE.Colors.WHITE, priceStr)
end)
CE.Hook.Add("onHitCompleted", "CE.AdminLog", function(hitman, target, customer)
	CE.Console.AdminLog(PlayerColor(hitman), PlayerName(hitman), CE.Colors.WHITE, " completed their hit on ", PlayerColor(target),
	PlayerName(target), CE.Colors.WHITE, " from ", PlayerColor(customer), PlayerName(customer))
end)
CE.Hook.Add("onHitFailed", "CE.AdminLog", function(hitman, target, reason)
	CE.Console.AdminLog(PlayerColor(hitman), PlayerName(hitman), CE.Colors.WHITE, " failed their hit on ", PlayerColor(target),
	target, CE.Colors.WHITE, " because ", reason)
end)



function CE.Console.Developer(...)
	local args = {...}
	table.insert(args, #args+1, "\n")
	return CE.Console.DeveloperNLn(unpack(args))
end
function CE.Console.DeveloperNLn(...)
  if not IsValid(DeveloperOutput) then return end
	local args = {...}
	DeveloperOutput:InsertColorChange(255,255,255,255)
	for k,v in pairs(args) do
		if CE.Colors.IsColor(v) then
			DeveloperOutput:InsertColorChange(v.r,v.g,v.b,v.a)
		else
			DeveloperOutput:AppendText(tostring(v))
		end
	end
	DeveloperOutput:InsertColorChange(255,255,255,255)
end
function ConsoleFrame:Close()
	self:SetVisible(false)
end
function ConsoleFrame:PerformLayout()
	local ow,oh = self:GetSize()
	local w = math.Clamp(ow, 200, 1200)
	local h = math.Clamp(oh, 200, 1200)
	if ow ~= w or oh ~= h then
		self:SetSize(w,h)
	else
		ConsoleFrame:_PerformLayout()
		Sheet:SetSize(w-10,h-30)
		DeveloperOutput:SetPos(5,5)
		DeveloperOutput:SetSize(w-40,h-100)
		LuaOutput:SetPos(5,5)
		LuaOutput:SetSize(w-40,h-100)
		AdminLogsOutput:SetPos(5,5)
		AdminLogsOutput:SetSize(w-40,h-100)
		DeveloperSubmitButton:SetPos(w-90, h-92)
		DeveloperSubmitButton:SetSize(50,22)
		LuaSubmitButton:SetPos(w-90, h-92)
		LuaSubmitButton:SetSize(50,22)
		DeveloperInputArea:SetPos(10, h-92)
		DeveloperInputArea:SetSize(w-110, 22)
		LuaInputArea:SetPos(10,h-92)
		LuaInputArea:SetSize(w-110, 22)
		--LuaAutocompleteArea:SetPos(3, 1)
		--LuaAutocompleteArea:SetSize(LuaInputArea:GetSize())
	end
end
CE.AddCmd({Nick="CE Console", Name="hacks_console", Function=function()
	ConsoleFrame:SetVisible(not ConsoleFrame:IsVisible())
end, HUD={Category="Utility", Type="CommandButton", IsOn=function() return ConsoleFrame:IsVisible() end}})
if IsReload then
	CE.Console.Developer(Color(50,225,50), "Reloaded Continuum Console...")
else
	CE.Console.Developer(Color(50,225,50), "Loaded Continuum Console...")
end
local function sign(var)
	if var == 0 then
		return 0
	else
		return var / math.abs(var)
	end
end
local dColor = .05
local function RenderDarkScreen()
	local target = ConsoleFrame:IsVisible() and .5 or 1
	if math.abs(ColorLevel - target) <= dColor then
		ColorLevel = target
	else
		ColorLevel = ColorLevel + sign(target - ColorLevel) * dColor
	end
	local tab = {}
	tab[ "$pp_colour_addr" ] = (1 - ColorLevel) * -.01--DarkBoost
	tab[ "$pp_colour_addg" ] = (1 - ColorLevel) * -.01--DarkBoost
	tab[ "$pp_colour_addb" ] = (1 - ColorLevel) * -.01--DarkBoost
	tab[ "$pp_colour_brightness" ] = 0
	tab[ "$pp_colour_contrast" ] = 1
	tab[ "$pp_colour_colour" ] = ColorLevel
	tab[ "$pp_colour_mulr" ] = 0
	tab[ "$pp_colour_mulg" ] = 0
	tab[ "$pp_colour_mulb" ] = 0

	DrawColorModify( tab )
end
CE.Hook.Add( "RenderScreenspaceEffects", "RenderDarkScreen", RenderDarkScreen )
local X,Y
if IsValid(CE.Session.BatteryFrame) then
	X,Y=CE.Session.BatteryFrame:GetPos() CE.Session.BatteryFrame:Remove()
else
	X,Y=CE.GetPersistant("BatteryPosition", {x=100}).x,CE.GetPersistant("BatteryPosition", {y=100}).y
end
CE.AddCVar({Nick="Battery", Name="hacks_battery", Info="Show battery on HUD if not on charger", Default="1", HUD={Category="Misc", Type="ToggleButton"}})
local BatteryFrame = vgui.Create("DFrame")
local LastSave = 0
CE.Session.BatteryFrame = BatteryFrame

BatteryFrame:SetSize(100,40)
BatteryFrame:SetTitle( "" )
BatteryFrame:SetDraggable( true ) -- not being draggable?
BatteryFrame:ShowCloseButton( false )
BatteryFrame:SetPos(X, Y)
BatteryFrame:SetVisible(true)

function BatteryFrame:Paint()
	local BatteryPower = system.BatteryPower()
	if BatteryPower ~= 255 then
		local BatteryAlpha = 150
		local BatteryColor = CE.Colors.GetTrafficColor(BatteryPower)
		local BatteryText = BatteryPower.."%"
		surface.SetDrawColor( CE.Colors.WithAlpha(CE.Colors.BLACK, BatteryAlpha) )
		surface.DrawRect( 0,0,self:GetWide(), self:GetTall() )
		surface.SetDrawColor( CE.Colors.WithAlpha(BatteryColor, BatteryAlpha) )
		surface.DrawRect( 0,0,self:GetWide() * BatteryPower / 100.0, self:GetTall() )
		surface.SetTextColor( CE.Colors.WithAlpha(CE.Colors.WHITE, BatteryAlpha) )
		surface.SetTextPos( self:GetWide() / 2 - 10, self:GetTall() / 2 - 8)
		surface.SetFont("DermaDefault")
		surface.DrawText(BatteryText)
	end
	local x,y = BatteryFrame:GetPos()
	local pos = {x=x,y=y}
	-- No need to save unless the position has changed and also no need to save more frequqently than 1 hertz
	if (x ~= CE.GetPersistant('BatteryPosition', {x=20}).x or y ~= CE.GetPersistant('BatteryPosition', {y=50}).y) and CurTime() > LastSave+1 then
		CE.SetPersistant('BatteryPosition', pos)
		LastSave=CurTime()
	end
end
function BatteryFrame:Close()
  self:SetVisible(false)
end
local function UpdateBattery()
  BatteryFrame:SetVisible(CE.GetConVarBool("hacks_battery"))
end
cvars.AddChangeCallback("hacks_battery", UpdateBattery)
UpdateBattery()