local CE = CE
CE.Version = 4.1

--game-mode
function CE.IsTTT()
	return GAMEMODE.Name == "Trouble in Terrorist Town"
end
function CE.IsDarkRP()
	return GAMEMODE.Name == "DarkRP"
end
function CE.IsStronghold()
	return GAMEMODE.Name == "F2S: Stronghold"
end
function CE.IsCOD()
	return GAMEMODE.Name == "COD:MOD" or GAMEMODE.FolderName == "codmod"
end
function CE.IsHungerGames()
  return GAMEMODE.Name == "Hunger Games"
end
function CE.IsMurder()
  return GAMEMODE.Name == "Murder"
end
function CE.IsTDM()
  return GAMEMODE.Name == "Vietnam War TDM"
end


CE.Constants = { }
--aim-bot
CE.Constants.AIMBOT_ERROR = -1
CE.Constants.AIMBOT_OFF = 0
CE.Constants.AIMBOT_SOFT = 1
CE.Constants.AIMBOT_HARD = 2

--bones
CE.Constants.BONE_GEAR = 0
CE.Constants.BONE_SPINE = 1
CE.Constants.BONE_TORSO = 3
CE.Constants.BONE_HEAD = 6
CE.Constants.BONE_RIGHT_HAND = 11
CE.Constants.BONE_LEFT_HAND = 16
CE.Constants.BONE_RIGHT_FOOT = 20
CE.Constants.BONE_LEFT_FOOT = 24

--colors
local Colors = {}
Colors.WHITE = Color(255,255,255)
Colors.BLACK = Color(0,0,0)
Colors.PURPLE = Color(230,230,250)
Colors.RED = Color(255,0,0)
Colors.GREEN = Color(0,255,0)
Colors.BLUE = Color(0,0,255)
Colors.YELLOW = Color(255,255,0)
Colors.ORANGE = Color(255, 127, 0)
Colors.CONTINUUM = Color(85, 25, 176)
Colors.GMOD = Color(0,170,255)
Colors.LGRAY = Color(175,175,175)
Colors.DGRAY = Color(75,75,75)
Colors.GRAY = Color(125,125,125)

Colors.TRAITOR = Color(220, 50, 40, 255)
Colors.INNOCENT = Color(0, 200, 0, 255)
Colors.SPECTATOR = Color(255,255,0)
Colors.DETECTIVE = Color(50, 60, 180, 255)
function Colors.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function Colors.WithAlpha(c,a)
	return Color(c.r,c.g,c.b,a)
end
function Colors.Inverse(color)
	return Color(Colors.AddToColor( color.r, 150 ), Colors.AddToColor( color.g, 150 ), Colors.AddToColor( color.b, 150 ), color.a)
end
function Colors.Equal(color1, color2)
	return color1.r == color2.r and color1.g == color2.g and color1.b == color2.b and color1.a == color2.a
end
function Colors.Lighter(color)
	return Color(math.Clamp(color.r + 30, 0, 255),math.Clamp(color.g + 30, 0, 255),math.Clamp(color.b + 30, 0, 255))
end
function Colors.Darker(color)
	return Color(math.Clamp(color.r - 30, 0, 255),math.Clamp(color.g - 30, 0, 255),math.Clamp(color.b - 30, 0, 255))
end
function Colors.IsColor(arg)
	return type(arg)=="table" and arg.a and arg.r and arg.g and arg.b
end
function Colors.Clone(color)
  return Color(color.r, color.g, color.b, color.a)
end
function Colors.Random()
	return Color(math.random(0,255), math.random(0,255), math.random(0,255))
end
function Colors.AddColorFunctions(color)
  color.Lighter = Colors.Lighter
  color.Darker = Colors.Darker
  color.Equals = Colors.Equal
  color.Inverse = Colors.Inverse
  color.Clone = Colors.Clone
  color.AddToColor = Colors.AddToColor
  color.WithAlpha = Colors.WithAlpha
end

function Colors.GetTrafficColor(percentage)
	if util ~= nil and util.HealthToString ~= nil then
		local _, color = util.HealthToString(percentage)
		return color;
	else
		local x = (100.0-percentage) / 100.0
		return Color(math.Clamp(2.0 * x * 255, 0, 255), math.Clamp(2.0 * (1 - x) * 255, 0, 255), 0);
	end
end
CE.Colors = { }
local CMT = { }
CMT.__newindex = function(t, k, v) 
  Colors[k] = v
end
CMT.__index = function(t, k)
  local v = Colors[k]
  if(Colors.IsColor(v)) then
    return Colors.Clone(Colors[k])
  end
  return v
end
CMT.__call = function(r, g, b, a)
  return Colors.AddColorFunctions(Color(r,g,b,a))
end
CMT.__pairs = Colors
setmetatable(CE.Colors, CMT)

ROLE_SPECTATOR = -1