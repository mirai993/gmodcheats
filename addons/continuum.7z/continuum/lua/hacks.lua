--[[hook._OldCall = hook._OldCall or hook.Call

function hook.Call(...)
local args = {...}
if args[1] ~= "DrawOverlay" and args[1] ~= "PreDrawHalos" then
print(args[1])
end
return hook._OldCall(...)
end]]

if CE then
  CE.include("continuum/util_basic.lua")
else
  include("continuum/util_basic.lua")
end
local CE = CE
concommand.Add("hacks_reload", function()
  RunConsoleCommand("__cl_loading")
  CE.RevealGlobal()
  CE.include("hacks.lua")
  timer.Simple(1.2, function() --[[PrintTable(CE.Session)]] RunConsoleCommand("__cl_loaded", tostring(CE.OK)) end)
end)
-- Include basic utilities
CE.include( "constants.lua" ) -- constants such as colors
CE.include( "util.lua" ) -- utility functions that are used in modules / hooks / developer
CE.include( "hooks.lua" ) -- Fuck with the hook table to prevent anticheats from seeing it
CE.include( "developer.lua" ) -- developer shit
CE.HideGlobal()

-- Check for a new version
CE.CheckForUpdates()

-- Load modules
CE.OK = CE.LoadModules()
if not CE.OK then
  chat.AddText(CE.Colors.RED, "*** Continuum had errors in some modules while loading. Most functionality will remain where possible, but some may be missing. Please check console for more info")
end


if CE.Notify then
  CE.Notify.Stack(CE.Colors.CONTINUUM,"Continuum Engine ", CE.Colors.CONTINUUM, ""..CE.Version, CE.Colors.WHITE, " loaded!")
end
-- Printing out admins after 2 seconds (so anything modules print will be before it)
timer.Simple(2, function()
  chat.AddText("Admin count: ", CE.Colors.RED, tostring(#CE.GetAdmins()))
end)

--hacks_lua_menu RunGameUICommand('quit')