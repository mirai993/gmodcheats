--Build 73

--[[Tips:

Want to change colors for the crosshair? Find the MB.ch.ch1 variables, then change the numbers.

Want to disable it completely? Change MB.ch.bool = true to MB.ch.bool = false

r = red (0-255)
g = green (0-255)
b = blue (0-255)
a = alpha [transparency] (0-255) 255 = not transparent
]]

--require("spreadthebutter")

-------------------------LOCALIZATION
local math = math -------------------
local table = table -----------------
local player = player ---------------
local string = string ---------------
local tostring = tostring -----------
local pairs = pairs -----------------
local ipairs = ipairs ---------------
local util = util -------------------
local surface = surface -------------
local draw = draw -------------------
local cam = cam ---------------------
local render = render ---------------
local vgui = vgui -------------------
local timer = timer -----------------
local hook = hook -------------------
local concommand = concommand -------
local _G = _G -----------------------
---------------------LOCALIZATION END

local MB = {}

if string.find(string.lower(GAMEMODE.Name),"terror") then MB.TTT = true else MB.TTT = false end
if string.find(string.lower(GAMEMODE.Name),"darkrp") then MB.DRP = true else MB.DRP = false end

MB.lp = LocalPlayer
MB.chars = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "_"}

MB.ch = {}
MB.ch.bool = true

MB.ch.ch1 = {}
MB.ch.ch1.r = 213
MB.ch.ch1.g = 91
MB.ch.ch1.b = 201
MB.ch.ch1.a = 200

MB.settings = {}
MB.hooks = {}
MB.commands = {}
MB.convars = {}
MB.timers = {}

MB.aim = false
MB.aimnotify = true
MB.meep = true
MB.shootwhileaim = false
MB.meepbot = false
MB.targ = nil
MB.shooteveryone = false


MB.settings.ESPColor = "health"
MB.settings.WallhackColor = "team"

MB.allwep = {}
MB.traitorz = {}
MB.witnesses = {}
MB.deadpplz = {}

MB.mat = CreateMaterial(math.random(1337,13370), "VertexLitGeneric", {["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1})
MB.donottrack = {"viewmodel", "weapon_ttt_wtester", "weapon_zm_improvised", "weapon_zm_magnetstick", "weapon_zm_carry", "weapon_ttt_unarmed", "env_fire", "ttt_flame", "ttt_knife_proj", "prop_ragdoll", "trace1", "rope", "func_physbox", "ttt_firegrenade_proj", "ttt_smokegrenade_proj", "ttt_confgrenade_proj"}
surface.CreateFont("Font111", {font = "BudgetLabel", size = 23, weight = 500, antialias = false, underline = false, shadow = true, outline = true})

for k, v in pairs(ents.GetAll()) do
    v.isPartOfMap = true
    if not table.HasValue(MB.allwep,v:GetClass()) and v:IsWeapon() and not table.HasValue(MB.donottrack,v:GetClass()) then
        table.insert(MB.allwep,v:GetClass())
    end
end

function MB.rs(minl,maxl)
    local result = ""
    for i = 1, math.random(minl,maxl) do
        result = result..MB.chars[math.random(1,#MB.chars)]
    end
    return result
end

function MB.AddHook(Type,Function)
    local Name = MB.rs(5,25)
    MB.hooks[Name] = {}
    MB.hooks[Name].name = Name
    MB.hooks[Name].type = Type
    hook.Add(Type,Name,Function)
end

function MB.AddConVar(val, desc)
    local aval = MB.rs(5,10)
    MB.convars[desc] = {}
    MB.convars[desc].name = aval
    MB.convars[desc].desc = desc
    CreateConVar(aval,val)
end

function MB.AddTimer(timerdesc,timeamt,times,functiontimer)
    local timername = MB.rs(6,14)
    timer.Create(timername,timeamt,times,functiontimer)
    MB.timers[timername] = {}
    MB.timers[timername].name = timername
    MB.timers[timername].desc = timerdesc
end

function MB.ToConsole(text,nextline)
    if nextline then
        MsgN("[MeepBot] "..text)
    else
        Msg("[MeepBot] "..text)
    end
end

function MB.ToChat(...)
    chat.AddText(Color(225,215,0),"[MeepBot] ",Color(210,180,0), ...)
end

function MB.AddCommand(Name, bool, Function)
    local number = ""
    if bool then 
        number = tostring(bool)
    else
        number = MB.rs(4,15)
    end
    MB.commands[Name] = {}
    MB.commands[Name].number = number
    MB.commands[Name].name = Name
    concommand.Add(number,Function)
end

MB.AddCommand("MB.Aimbot.Toggle", "meepbot", function()
    MB.aim = not MB.aim
end)
MB.AddCommand("MB.DropWeaponTTT", "ttt_drophax", function()
    local wep = MB.lp():GetActiveWeapon()
    WEPS.DropNotifiedWeapon(MB.lp(), wep)
end)

function MB.MESPCheck(v)
    if MB.TTT then
        if IsValid(v) and v:IsPlayer() and not v:IsNPC() and v:IsTerror() ~= nil and v:IsTerror() and not table.HasValue(MB.deadpplz,v) and v ~= MB.lp() then
            return true
        else
            return false
        end
    else
        if IsValid(v) and v:IsPlayer() and not v:IsNPC() and not table.HasValue(MB.deadpplz,v) and v ~= MB.lp() then
            return true
        else
            return false
        end
    end
end

function MB.coordinates(ent)
    local min, max = ent:OBBMins(), ent:OBBMaxs()
    local corners = {
        Vector(min.x, min.y, min.z),
        Vector(min.x, min.y, max.z),
        Vector(min.x, max.y, min.z),
        Vector(min.x, max.y, max.z),
        Vector(max.x, min.y, min.z),
        Vector(max.x, min.y, max.z),
        Vector(max.x, max.y, min.z),
        Vector(max.x, max.y, max.z)
    }
     
    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
    for _, corner in pairs(corners) do    
        local onScreen = ent:LocalToWorld(corner):ToScreen()
        minX, minY = math.min(minX, onScreen.x), math.min(minY, onScreen.y)
        maxX, maxY = math.max(maxX, onScreen.x), math.max(maxY, onScreen.y)
    end
     
    return minX, minY, maxX, maxY
end



MB.AddHook("Think",function()
	for _,v in pairs(player.GetAll()) do
        if not v:Alive() and v:Health() < 1 and not v:IsNPC() and v:IsPlayer() then
            if not table.HasValue(MB.deadpplz,v) then
                table.insert(MB.deadpplz,v)
                MB.ToChat(v:Name().." died somehow!")
            end
        else
            for k,v2 in pairs (MB.deadpplz) do
                if v2 == v then
                    table.remove(MB.deadpplz,k)
                end
            end
        end
    end
end)

MB.AddHook("CreateMove",function(cmd) --Thanks Tyler Wearing!
	--print(cmd.command_number)
    local lp = MB.lp()
    if not MB.shooteveryone then
        local trace = util.GetPlayerTrace(lp)
        local traceRes = util.TraceLine(trace)
        if traceRes.HitNonWorld then
            local target = traceRes.Entity
            if target:Health() > 0 and IsValid(target) and v ~= lp then
                MB.temptarg = target
            end
        end
        if MB.aim and IsValid(MB.targ) and MB.targ:Health() > 0 and table.HasValue(player.GetAll(), MB.targ) then
            
            local absVel = MB.targ:GetAbsVelocity() * 0.012
            local targpos2, _ = MB.targ:GetBonePosition(MB.targ:LookupBone("ValveBiped.Bip01_Head1"))
            local targpos = targpos2 - absVel + absVel
            local angle = Angle(0,0,0)
            
            
            if MB.TTT and IsValid(lp:GetActiveWeapon()) and lp:GetActiveWeapon().Primary then
                local Cone = MB.lp():GetActiveWeapon().Primary.Cone
                local vecCone = Vector(-1 * Cone, -1 * Cone, 0)
                angle = (targpos - lp:EyePos()):Angle()--DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), targpos - lp:EyePos(), vecCone):Angle()
            else
                angle = (targpos - lp:EyePos()):Angle()
            end
            
            cmd:SetViewAngles(angle) --Thanks Tyler Wearing!
            local tracedata = {}
            tracedata.start = lp:EyePos()
            tracedata.endpos = MB.targ:EyePos()
            tracedata.filter = lp
            local traceRes = util.TraceLine(tracedata)
            if traceRes.HitNonWorld and traceRes.Entity and IsValid(traceRes.Entity) and MB.shootwhileaim then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK)) --Thanks Tyler Wearing!
            end
        else
            MB.aim = false
            MB.targ = MB.temptarg
        end
    elseif MB.aim then
        for k, v in pairs(player.GetAll()) do
            if MB.MESPCheck(v) then
                local tracedata = {}
                tracedata.start = lp:EyePos()
                tracedata.endpos = v:EyePos()
                tracedata.filter = lp
                local trace = util.TraceLine(tracedata)
                if trace.HitNonWorld and trace.Entity == v then
                    local targpos2, _ = v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
                    local absVel = v:GetAbsVelocity() * 0.012
                    local angle = Angle(0,0,0)
            
                    if MB.TTT and IsValid(lp:GetActiveWeapon()) and lp:GetActiveWeapon().Primary then
                        local Cone = MB.lp():GetActiveWeapon().Primary.Cone
                        local vecCone = Vector(-1 * Cone, -1 * Cone, 0)
                        angle = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), (targpos2 - absVel + absVel) - lp:EyePos(), vecCone):Angle()
                    else
                        angle = ((targpos2 - absVel + absVel) - lp:EyePos()):Angle()
                    end
                    
                    cmd:SetViewAngles(angle)
                    if trace.HitNonWorld and trace.Entity and IsValid(trace.Entity) and MB.shootwhileaim then
                        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK)) --Thanks Tyler Wearing!
                    end
                    return
                end
            end
        end
    end
end)


MB.AddHook("HUDPaint", function()
    local lp = MB.lp()
    local trace = util.GetPlayerTrace(lp)
    local traceRes = util.TraceLine(trace)
    if traceRes.HitNonWorld then
        local target = traceRes.Entity
        draw.DrawText(target:GetClass(),"BudgetLabel", 30, ScrH() / 2 + 15,Color(255,255,255,255))
    end
    
    local numspec = 0
    for k,v in pairs(player.GetAll()) do
        if v:GetObserverTarget() == lp then
            numspec = numspec + 1
        end
    end
    draw.DrawText(numspec.." Spectating You","Font111", 30, ScrH() / 2 + 30,Color(255,0,255,255))
    
    if MB.aim and MB.aimnotify then
        if IsValid(MB.targ) and MB.targ then
            draw.DrawText(MB.targ:Nick(), "BudgetLabel", 30, ScrH() / 2, Color(255, 255, 255, 255))
        end
    end
    if MB.ch["bool"] then
        
        surface.SetDrawColor(Color(MB.ch.ch1.r, MB.ch.ch1.g, MB.ch.ch1.b, MB.ch.ch1.a))
        
        local x, y = ScrW() / 2, ScrH() / 2
        local gap = 0
        local length = 15
        local exgap = 5
        
        if lp and lp:GetActiveWeapon() and MB.TTT and MB.MESPCheck(lp) then
            --stole code below
            local scale = math.max(0.2,  10 * lp:GetActiveWeapon().Primary.Cone)
            local sights = lp:GetActiveWeapon():GetIronsights()
            exgap = 20 * scale * (sights and 0.8 or 1)
        end
        
        surface.DrawLine( x - length, y, x - gap, y )
        surface.DrawLine( x + length, y, x + gap, y )
        surface.DrawLine( x, y - length, x, y - gap )
        surface.DrawLine( x, y + length, x, y + gap )
        if MB.TTT then
            surface.DrawLine(x - exgap,y + length / exgap, x - exgap, y - length / exgap)
            surface.DrawLine(x + exgap,y + length / exgap, x + exgap, y - length / exgap)
            surface.DrawLine(x - length / exgap,y + exgap, x + length / exgap, y + exgap)
            surface.DrawLine(x - length / exgap,y - exgap, x + length / exgap, y - exgap)
        end
    end
    if MB.meep then
        cam.Start2D()
        for k,v in pairs (ents.GetAll()) do
            if string.find(string.lower(v:GetClass()),"money") and MB.DRP then
                local pos = v:GetPos():ToScreen()
                local x, y = pos.x, pos.y
                draw.DrawText(tostring(v:GetClass()),"BudgetLabel",x,y,Color(100,150,125,255),TEXT_ALIGN_CENTER)
            elseif string.find(string.lower(tostring(v:GetClass())),"shipment") and MB.DRP then
                local pos = v:GetPos():ToScreen()
                local x, y = pos.x, pos.y
                local ct = v:Getcontents() or ""
                local cts = CustomShipments[ct] or ""
                local ctsn = cts.name
                draw.DrawText(tostring(v:GetClass()..(": "..ctsn.."; Amount: "..v:Getcount() or "")),"BudgetLabel",x,y,Color(100,150,125,255),TEXT_ALIGN_CENTER)
            end
        end
        for k,v in pairs (player.GetAll()) do
            if MB.MESPCheck(v) then
            --Name Draw start
                local Position = v:GetPos():ToScreen()
                local name = v:Name()
                local isadmin = v:IsAdmin() or false
                local issuperadmin = v:IsSuperAdmin() or false
                local text = ""
                if issuperadmin then text = "[SuperAdmin]\n"..name.."\n" elseif isadmin then text = "[Admin]\n"..name.."\n" else text = "\n"..name.."\n" end
                local extra = ""
                local color = Color(0,0,0,255)
                if MB.TTT then
                    if v:IsDetective() then 
                        extra = "Detective"
                    elseif table.HasValue(MB.traitorz,v) then
                        extra = "Traitor"
                    else
                        extra = "Innocent"
                    end
                elseif MB.DRP then
                    extra = tostring(team.GetName(v:Team()))
                end
                
                --color
                if MB.settings.WallhackColor == "team" then
                    if MB.TTT then
                        if v:IsDetective() then 
                            color = Color(0,0,255,255)
                        elseif table.HasValue(MB.traitorz,v) then
                            color = Color(255,0,0,255)
                        else
                            color = Color(0,255,0,255)
                        end
                    else
                        color = team.GetColor(v:Team())
                    end
                elseif MB.settings.WallhackColor == "health" then
                    color = Color(math.min(255,v:Health()*2.55-255),math.min(255,v:Health()*2.55),0,255)
                elseif MB.settings.WallhackColor == "red" then
                    color = Color(255,0,0,255)
                elseif MB.settings.WallhackColor == "green" then
                    color = Color(0,255,0,255)
                elseif MB.settings.WallhackColor == "blue" then
                    color = Color(0,0,255,255)
                elseif MB.settings.WallhackColor == "white" then
                    color = Color(255,255,255,255)
                else 
                    color = Color(0,0,0,255)
                end
                
                
                draw.DrawText(text..extra, "BudgetLabel", Position.x, Position.y, color, 1)
            --Name Draw finish
            end
        end
        cam.End2D()
    end
end)

MB.AddHook("RenderScreenspaceEffects", function()
    if MB.meep then
        local lp = MB.lp()
        cam.Start3D(lp:EyePos(), lp:EyeAngles())
        
        render.SuppressEngineLighting(true)
        render.MaterialOverride(MB.mat)
        
        
        for k,v in pairs(player.GetAll()) do
            if MB.MESPCheck(v) then
            --draw people start
                --part 1
                local green = 0
                local red = 0
                local blue = 0
                local alpha = 1
                if MB.settings.ESPColor == "health" then
                    h = v:Health()
                    green = (2.55 * h) / 255
                    red = (255 - 2.00 * h) / 255
                elseif MB.settings.ESPColor == "team" then
                    local color = team.GetColor(v:Team())
                    red = color.r / 255
                    green = color.g / 255
                    blue = color.b / 255
                    alpha = color.a / 255
                elseif MB.settings.ESPColor == "white" then
                    red = 1
                    blue = 1
                    green = 1
                elseif MB.settings.ESPColor == "red" then
                    red = 1
                elseif MB.settings.ESPColor == "blue" then
                    blue = 1
                elseif MB.settings.ESPColor == "green" then
                    green = 1
                end 
                    
                render.SetColorModulation(red, green, blue, alpha)
                render.MaterialOverride(MB.mat)
                v:DrawModel()
                
                --part 2
                render.MaterialOverride()
                render.SetModelLighting(4, 0.78, 0.19, 0.19)
                v:DrawModel()
            --draw people finish
            
            --draw guns start
                if IsValid(v:GetActiveWeapon()) then
                    render.SetColorModulation(0, 0, 0, 1)
                    render.MaterialOverride(MB.mat)
                    v:GetActiveWeapon():DrawModel()
                    
                    render.SetColorModulation(0, 0, 0, 1)
                    render.MaterialOverride()
                    v:GetActiveWeapon():DrawModel() 
                end
            --draw guns finish
            end
        end
        render.SuppressEngineLighting(false)
        cam.End3D()
    end
end)



if MB.TTT then
    MB.AddHook("TTTPrepareRound",function()
        traitorfinder = false
        for k, v in pairs(MB.allwep) do
            table.remove(MB.allwep, k)
            MB.allwep = {}
        end
        MB.targ = nil
        MB.temptarg = nil
        for _,v in pairs(ents.GetAll()) do
            v.isPartOfMap = true
        end
    end)

    MB.AddHook("TTTBeginRound",function()
        traitorfinder = true
        for k, v in pairs(ents.GetAll()) do
            v.isPartOfMap = true
            if not table.HasValue(MB.allwep,v:GetClass()) and v:IsWeapon() and not table.HasValue(MB.donottrack,v:GetClass()) then
                table.insert(MB.allwep,v:GetClass())
            end
        end
        MB.traitorz = {}
        MB.deadpplz = {}
    end)
end

MB.AddHook("PostDrawOpaqueRenderables", function()
    if MB.TTT then
        for k, v in pairs(ents.GetAll()) do
            if v and MB.meep and traitorfinder and IsValid(v) then
                if not table.HasValue(MB.allwep,v:GetClass()) and v.CanBuy and not v.isPartOfMap and not v.wasESPTracked and not table.HasValue(MB.donottrack,v:GetClass()) then
                    pl = v.Owner
                    if MB.MESPCheck(pl) and IsValid(pl) and pl and not pl:IsDetective() then
                        v.wasESPTracked = true
                        table.insert(MB.traitorz,pl)
                        MB.ToChat(pl, Color(205,160,0), " has a ",Color(255,0,0), tostring(v:GetPrintName()), Color(205,160,0), "!")
                    end
                end
            end
        end
    end
end)

MB.AddCommand("ShowWindow", false, function()
    -- the width in along the sides should be 5
    local frame = vgui.Create("DFrame")
    frame:SetTitle("MeepBot")
    frame:SetSize(400, 300) -- 398, 278 = the size of the actual window
    frame:SetPos(25, 25)
    frame:SetSizable(false)
    frame:MakePopup()
    
    local btnsd = vgui.Create("DButton", frame)
    btnsd:SetText("Self Destruct")
    btnsd:SetPos(6,27)
    btnsd:SetWide(388)
    btnsd:SetHeight(20)
    btnsd:SetTextColor(Color(255,0,0,255))
    function btnsd:DoClick()
        for _,v in pairs(MB.hooks) do
            hook.Remove(v.type,v.name)
            MB.ToConsole(v.name.." was removed! ("..v.type..")",true)
        end
        for _,v in pairs (MB.timers) do
            timer.Remove(v.name)
            MB.ToConsole(v.desc.." was removed! ("..v.name..")",true)
        end
        for _,v in pairs (MB.commands) do
            concommand.Remove(v.number)
            MB.ToConsole(v.name.." was removed! ("..v.number..")",true)
        end
        frame:Close()
    end
    
    local btnbind = vgui.Create("DButton", frame)
    btnbind:SetPos(6, 53)
    btnbind:SetHeight(20)
    btnbind:SetWide(96)
    btnbind:SetText("List binds in ~")
    function btnbind:DoClick()
        for _,v in pairs(MB.commands) do
            MB.ToConsole(v.number.." = "..v.name,true)
        end
    end
    
    local btnshoot = vgui.Create("DButton", frame)
    btnshoot:SetPos(103, 53)
    btnshoot:SetWide(194)
    btnshoot:SetHeight(20)
    if MB.shootwhileaim then btnshoot:SetText("Shooting while aiming!") else btnshoot:SetText("Not shooting while aiming!") end
    function btnshoot:DoClick()
        MB.shootwhileaim = not MB.shootwhileaim
        if MB.shootwhileaim then self:SetText("Shooting while aiming!") else self:SetText("Not shooting while aiming!") end
    end
    
    local btnwht = vgui.Create("DButton", frame)
    if MB.meep then btnwht:SetText("Wallhack on") else btnwht:SetText("Wallhack off") end
    btnwht:SetPos(298, 53)
    btnwht:SetWide(96)
    btnwht:SetHeight(20)
    function btnwht:DoClick()
        MB.meep = not MB.meep
        if MB.meep then self:SetText("Wallhack on") else self:SetText("Wallhack off") end
    end
    
    local btnaimtype = vgui.Create("DButton", frame)
    btnaimtype:SetPos(103, 79)
    btnaimtype:SetWide(194)
    btnaimtype:SetHeight(20)
    if MB.shooteveryone then btnaimtype:SetText("Shooting at everyone!") else btnaimtype:SetText("Not shooting everyone!") end
    function btnaimtype:DoClick()
        MB.shooteveryone = not MB.shooteveryone
        if MB.shooteveryone then self:SetText("Shooting at everyone!") else self:SetText("Not shooting everyone!") end
    end
    
    local cbespppl = vgui.Create("DComboBox", frame)
    cbespppl:SetPos(6,79)
    cbespppl:SetHeight(20)
    cbespppl:SetWide(96)
    cbespppl:SetValue("Color of people")
    cbespppl:AddChoice("health")
    cbespppl:AddChoice("team")
    cbespppl:AddChoice("white")
    cbespppl:AddChoice("black")
    cbespppl:AddChoice("red")
    cbespppl:AddChoice("green")
    cbespppl:AddChoice("blue")
    function cbespppl:OnSelect(k,v,d)
        MB.settings.ESPColor = v
    end
    
    local cbesptxt = vgui.Create("DComboBox", frame)
    cbesptxt:SetPos(298,79)
    cbesptxt:SetHeight(20)
    cbesptxt:SetWide(96)
    cbesptxt:SetValue("Color of text")
    cbesptxt:AddChoice("health")
    cbesptxt:AddChoice("team")
    cbesptxt:AddChoice("white")
    cbesptxt:AddChoice("black")
    cbesptxt:AddChoice("red")
    cbesptxt:AddChoice("green")
    cbesptxt:AddChoice("blue")
    function cbesptxt:OnSelect(k,v,d)
        MB.settings.WallhackColor = v
        MB.ToConsole("Sorry, this function is partially broken right now. Health doesn't work.",true)
    end
    
end)

MB.ToChat("Bind a key to: ",Color(255,0,0),MB.commands["ShowWindow"].number)
