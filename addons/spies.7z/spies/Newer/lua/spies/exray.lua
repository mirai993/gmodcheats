--[[
	MOD/addons/spies/lua/spies/exray.lua
	Cazed | STEAM_0:1:78044580 <86.180.82.205:27006> | [04-02-14 09:26:29PM]
	===BadFile===
]]


MsgC(Color(255,0,0),"\n Spies EXRAY Initialized\n")


//////////////////////
///// WallHack //////
////////////////////


// Config \\

spies.xray = {}
spies.xray.playercolour = {}
spies.xray.propphyscolour = {}

spies.xray.toggle = true
spies.xray.material = Material("/models/wireframe")

spies.xray.playercolour.r = 0
spies.xray.playercolour.g = 255
spies.xray.playercolour.b = 0

spies.xray.propphyscolour.r = 0
spies.xray.propphyscolour.g = 0
spies.xray.propphyscolour.b = 255


//       \\

function WallHack()
surface.PlaySound("garrysmod/ui_click.wav")
print(spies.xray.toggle)
	if spies.xray.toggle == false then
		print("off")
		spies.xray.toggle = true
		hook.Remove("HUDPaint","wallhack")

		for k,v in pairs(ents.FindByClass("prop_physics")) do
			v:SetNoDraw(false)
		end
	elseif spies.xray.toggle == true then
		spies.xray.toggle = false
		function WallHacks()

		render.MaterialOverride(spies.xray.material)
		cam.Start3D()
		cam.IgnoreZ(true)
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() and v:Alive() then
				render.SetColorModulation(spies.xray.playercolour.r, spies.xray.playercolour.g, spies.xray.playercolour.b)
				render.SetBlend(0.5)
				v:DrawModel()
				v:SetNoDraw(false)
			else
				v:SetNoDraw(true)
			end
		end
		for k,v in pairs(ents.FindByClass("prop_physics")) do
			if v:IsValid() then
				render.SetColorModulation(spies.xray.propphyscolour.r, spies.xray.propphyscolour.g, spies.xray.propphyscolour.b)
				render.SetBlend(0.5)
				v:DrawModel()
				v:SetNoDraw(true)
			end
		end
		cam.End3D()
		cam.IgnoreZ(false)
		end
		hook.Add("HUDPaint","wallhack",WallHacks)
	end
end
concommand.Add("spies_xray",WallHack)




//////////////////////
//////// ESP ////////
////////////////////

// Config \\

spies.esp = {}
spies.esp.adminscolour = {}
spies.esp.usercolour = {}

spies.esp.toggle = true

spies.esp.adminscolour.r = 255
spies.esp.adminscolour.g = 0
spies.esp.adminscolour.b = 0

spies.esp.usercolour.r = 255
spies.esp.usercolour.g = 255
spies.esp.usercolour.b = 255


//        \\


function ESP()
surface.PlaySound("garrysmod/ui_click.wav")
	if spies.esp.toggle == false then
		spies.esp.toggle = true
		hook.Remove("HUDPaint","esp")
	elseif spies.esp.toggle == true then
		spies.esp.toggle = false
		local function SESP()
			for k,v in pairs(player.GetAll()) do
				local pos = (v:GetPos() +Vector(0,0,100)):ToScreen()
				if (v!=LocalPlayer()) then
					if v:IsAdmin() or v:IsSuperAdmin() then
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.adminscolour.r , spies.esp.adminscolour.b, spies.esp.adminscolour.g ), 1 )
					else
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.usercolour.r , spies.esp.usercolour.b, spies.esp.usercolour.g ), 1 )
					end
						draw.DrawText( team.GetName(v:Team()), "TargetID", pos.x,pos.y+20, Color(spies.esp.usercolour.r , spies.esp.usercolour.b, spies.esp.usercolour.g ), 1 )
				end
			end
		end
		hook.Add("HUDPaint","esp",SESP)
	end
end
concommand.Add("spies_esp",ESP)

//////////////////////
//// Info Panel /////
////////////////////

spies.infopanel = {}
spies.infopanel.dims = {}
spies.infopanel.cfg = {}
spies.infopanel.cfg.boxcolour = {}

spies.infopanel.toggle = true

spies.infopanel.dims.w = (ScrW()*0.15)
spies.infopanel.dims.h = (ScrH()*0.12)
spies.infopanel.dims.x =  0 or (Menu:GetWide())
spies.infopanel.dims.y = ScrH()*0.3

spies.infopanel.dims.columnW = ScrW()*0.02
spies.infopanel.dims.columnH = ScrH()*0.3

spies.infopanel.cfg.boxcolour.r = 0
spies.infopanel.cfg.boxcolour.g = 0
spies.infopanel.cfg.boxcolour.b = 0
spies.infopanel.cfg.boxcolour.a = 180 

function InfoPanel()

	if spies.infopanel.toggle == false then
		spies.infopanel.toggle = true
		hook.Remove("HUDPaint","InfoPanel")
	elseif spies.infopanel.toggle == true then
		spies.infopanel.toggle = false

		local function Info()

		surface.SetDrawColor(spies.infopanel.cfg.boxcolour.r, spies.infopanel.cfg.boxcolour.g, spies.infopanel.cfg.boxcolour.b, spies.infopanel.cfg.boxcolour.a)

		local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer(),LocalPlayer():GetAimVector()))
			if tr.Entity:IsPlayer() then
				surface.DrawRect(spies.infopanel.dims.x, spies.infopanel.dims.y, spies.infopanel.dims.w, spies.infopanel.dims.h)
				surface.SetTextColor(255,255,255)
					surface.SetFont("Trebuchet24")
					surface.SetTextPos( spies.infopanel.dims.columnW+10, spies.infopanel.dims.columnH)

					surface.DrawText("Name : "..tr.Entity:Name())

					surface.SetFont("Trebuchet18")

					surface.SetTextPos( spies.infopanel.dims.columnW, spies.infopanel.dims.columnH+30)
					surface.DrawText("SteamID : "..tr.Entity:SteamID())

					surface.SetTextPos( spies.infopanel.dims.columnW, spies.infopanel.dims.columnH+50)
					surface.DrawText("Rank : "..tr.Entity:GetUserGroup())

					surface.SetTextPos( spies.infopanel.dims.columnW, spies.infopanel.dims.columnH+70)
					surface.DrawText("Money : "..tr.Entity.DarkRPVars.money)

					surface.SetTextPos( spies.infopanel.dims.columnW, spies.infopanel.dims.columnH+90)
					surface.DrawText("Weapon : "..tr.Entity:GetActiveWeapon():GetClass())
			end
		end
		hook.Add("HUDPaint","InfoPanel",Info)
	end
end
concommand.Add("spies_infopanel",InfoPanel)



//////////////////////
//// Head Trace /////
////////////////////

spies.headtrace = {}

spies.headtrace.toggle = true

function HeadTrace()
	if spies.headtrace.toggle == false then
		spies.headtrace.toggle = true
		hook.Remove("PostDrawOpaqueRenderables","HeadTrace")
	elseif spies.headtrace.toggle == true then
	spies.headtrace.toggle = false
		local function HeadTraceDraw()
			for k,v in pairs(player.GetAll()) do
				if v:IsValid() and v != LocalPlayer() then
					local pos = v:EyePos()
					render.DrawLine(pos,Vector(pos.x,pos.y,4000),Color(255,255,255),true)
				end
			end
		end
		hook.Add("PostDrawOpaqueRenderables","HeadTrace",HeadTraceDraw)
	end
end
concommand.Add("spies_headtrace",HeadTrace)



-- OLD ESP pretty dam bad
--[[
ESP = true

function ToggleESP()

print("Toggle")


	if ESP == false then
		ESP = true
		hook.Remove("HUDPaint","ESP")
		hook.Remove("PostDrawOpaqueRenderables","PlyXray")
		cam.IgnoreZ(false)
			surface.PlaySound("garrysmod/ui_click.wav")


	elseif ESP == true then
	surface.PlaySound("garrysmod/ui_click.wav")

		function ESP() -- Player ESP
			for k,v in pairs(player.GetAll()) do
				local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
				if !(v == LocalPlayer()) or !(v:IsAdmin()) or !(v:IsSuperAdmin()) then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
				end
				if v:IsAdmin() or v:IsSuperAdmin() then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color(255,25,25,255), 1)
				end
			end
		end
		hook.Add("HUDPaint","ESP",ESP)

		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)


	function PlyXray() -- Player XRAY

		cam.IgnoreZ(true)
			render.SuppressEngineLighting( true )


			for k,v in pairs(player.GetAll()) do
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:SetMaterial("models/shiny")
			render.SetBlend(0.5)
			--render.MaterialOverride(Material("models/wireframe"))
			--render.SetMaterial(Material("models/shiny"))
				render.SetColorModulation( 0, 1, 0 )
				v:DrawModel()
			end

			for k,v in pairs(ents.FindByClass("prop_physics")) do
			--v:SetRenderMode(RENDERMODE_TRANSALPHA)
				v:SetMaterial("models/wireframe")
				render.SetBlend(0.2)
				--render.SetMaterial(Material("models/shiny"))
					render.SetColorModulation(0,0,1)
					v:DrawModel()
			end

		cam.IgnoreZ(false)
		render.SuppressEngineLighting(false)
	end
	hook.Add("PostDrawOpaqueRenderables","PlyXray",PlyXray)
	ESP = false

	end

end
concommand.Add("spies_esp",ToggleESP)

--]]
