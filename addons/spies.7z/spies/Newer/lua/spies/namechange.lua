--[[
	MOD/addons/spies/lua/spies/namechange.lua
	Cazed | STEAM_0:1:78044580 <86.180.82.205:27006> | [04-02-14 09:26:29PM]
	===BadFile===
]]


MsgC(Color(255,0,0),"\n Spies Name Change Initialized\n")

playernames = {}
 function PlayerNames()
 playernames = {}
	print("UPDATING PLAYER NAMES!")
	for k,v in pairs(player.GetAll()) do
		if v == LocalPlayer() or v:IsAdmin() or v:IsSuperAdmin() then
		else
			table.insert(playernames,0,v:Name())
		end
	end
end
timer.Create("PlayerNameUpdate",30,0,PlayerNames)
concommand.Add("spies_ForcePlayerUpdate",PlayerNames)

function NameChange(ply,cmd,args)
local plyN = table.Random(playernames)
print(plyN)
	RunConsoleCommand("say", "/rpname "..plyN.."  " )
end
concommand.Add("spies_NameChange",NameChange)
