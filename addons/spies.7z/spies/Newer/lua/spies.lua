--[[
	MOD/addons/spies/lua/spies.lua
	Cazed | STEAM_0:1:78044580 <86.180.82.205:27006> | [04-02-14 09:26:28PM]
	===BadFile===
]]


spies = {}


-- Include Files Below

include("spies/exray.lua")
include("spies/namechange.lua")
include("spies/pkcmds.lua")
include("spies/utilcmds.lua")

--
--[[
function AutoHealth()

local ply = LocalPlayer()
print("Hit")
	if ply:Health() <= 100 then
		RunConsoleCommand("say", "/buyhealth")
	end
end
hook.Add("PlayerTraceAttack","AutoHealth",AutoHealth)
--]]