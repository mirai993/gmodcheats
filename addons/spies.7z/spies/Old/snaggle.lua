--[[
	MOD/lua/Old/snaggle.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:20AM]
	===BadFile===
]]


MsgC(Color(127,0,255),"\n Spy's EXRAY Initialized\n")


//////////////////////
///// WallHack //////
////////////////////

xray = true

function WallHack()

	if xray == false then
		xray = true
		hook.Remove("HUDPaint","wallhack")
	elseif xray == true then

	function WallHacks()

	cam.Start3D()
	for k,v in pairs(player.GetAll()) do
		if v:IsValid() then
			if
				v:IsUserGroup("superadmin") or v:IsUserGroup("owner")
					then
				v:SetMaterial("models/wireframe")
				render.SetColorModulation(255,191,0)
				render.SetBlend(0.75)
				v:DrawModel()
			elseif 
				v:IsUserGroup("admin") or v:IsUserGroup("mod") or v:IsUserGroup("moderator")
					then
				v:SetMaterial("models/wireframe")
				render.SetColorModulation(255,0,0)
				render.SetBlend(1)
				v:DrawModel()
			elseif
				v:IsUserGroup("user")
					then
				v:SetMaterial("models/wireframe")
				render.SetColorModulation(255,255,255)
				render.SetBlend(0.5)
				v:DrawModel()
			else
				v:SetMaterial("models/wireframe")
				render.SetColorModulation(0,255,0)
				render.SetBlend(0.75)
				v:DrawModel()
			end
		end
	end
	


	
	cam.End3D()
	end
	hook.Add("HUDPaint","wallhack",WallHacks)
end
end
concommand.Add("spys_xray",WallHack)



//////////////////////
//////// ESP ////////
////////////////////

esp = true

function ESP()
surface.PlaySound("garrysmod/ui_click.wav")
	if esp == false then
		esp = true
		hook.Remove("HUDPaint","esp")
	elseif esp == true then
		local function SESP()
			for k,v in pairs(player.GetAll()) do
				local pos = (v:GetPos() +Vector(0,0,80)):ToScreen()
				if (v==LocalPlayer()) then end
					if v:IsUserGroup("user") 
							then
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color( 255, 255, 255 ), 1 )
					else
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color( 255, 0, 0 ), 1 )
					end
			end
		end
		hook.Add("HUDPaint","esp",SESP)
	end
end
concommand.Add("spys_esp",ESP)

//////////////////////
//// Head Trace /////
////////////////////

Headtrace = true

function HeadTrace()
	if Headtrace == false then
		Headtrace = true
		hook.Remove("RenderScreenspaceEffects","HeadTrace")
	elseif Headtrace == true then
		local function HeadTraceDraw()
			for k,v in pairs(player.GetAll()) do
				if v:IsValid() then
					local pos = v:EyePos()+Vector(0,0,10)
					render.DrawLine(pos,Vector(pos.x,pos.y,4000),Color(255,255,255),true)
				end
			end
		end
		hook.Add("PostDrawOpaqueRenderables","HeadTrace",HeadTraceDraw)
	end
end
concommand.Add("spys_headtrace",HeadTrace)



-- OLD ESP pretty dam bad
--[[
ESP = true

function ToggleESP()

print("Toggle")


	if ESP == false then
		ESP = true
		hook.Remove("HUDPaint","ESP")
		hook.Remove("PostDrawOpaqueRenderables","PlyXray")
		cam.IgnoreZ(false)
			surface.PlaySound("garrysmod/ui_click.wav")


	elseif ESP == true then
	surface.PlaySound("garrysmod/ui_click.wav")

		function ESP() -- Player ESP
			for k,v in pairs(player.GetAll()) do
				local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
				if !(v == LocalPlayer()) or !(v:IsAdmin()) or !(v:IsSuperAdmin()) then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
				end
				if v:IsAdmin() or v:IsSuperAdmin() then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color(255,25,25,255), 1)
				end
			end
		end
		hook.Add("HUDPaint","ESP",ESP)

		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)


	function PlyXray() -- Player XRAY

		cam.IgnoreZ(true)
			render.SuppressEngineLighting( true )


			for k,v in pairs(player.GetAll()) do
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:SetMaterial("models/shiny")
			render.SetBlend(0.5)
			--render.MaterialOverride(Material("models/wireframe"))
			--render.SetMaterial(Material("models/shiny"))
				render.SetColorModulation( 0, 1, 0 )
				v:DrawModel()
			end

			for k,v in pairs(ents.FindByClass("prop_physics")) do
			--v:SetRenderMode(RENDERMODE_TRANSALPHA)
				v:SetMaterial("models/wireframe")
				render.SetBlend(0.2)
				--render.SetMaterial(Material("models/shiny"))
					render.SetColorModulation(0,0,1)
					v:DrawModel()
			end

		cam.IgnoreZ(false)
		render.SuppressEngineLighting(false)
	end
	hook.Add("PostDrawOpaqueRenderables","PlyXray",PlyXray)
	ESP = false

	end

end
concommand.Add("spies_esp",ToggleESP)

--]]
