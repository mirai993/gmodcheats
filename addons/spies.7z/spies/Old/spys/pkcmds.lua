--[[
	MOD/lua/Old/spys/pkcmds.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:23AM]
	===BadFile===
]]


MsgC(Color(127,0,255),"\n Spy's Propkill Commands Initialized\n")

function Boost360()

local b = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(b.p,b.y-180,b.r))
	local function boost()
		local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
		RunConsoleCommand("+jump")
		timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
	end
	local function propSpawn()
		RunConsoleCommand("gm_spawn","models/props_c17/lampShade001a.mdl")
	end
timer.Simple(0.15,propSpawn)
timer.Simple(0.3,boost)
end
concommand.Add("spys_360Boost",Boost360)

function boost()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
timer.Simple(0.1, function() RunConsoleCommand("-jump") end)
end
concommand.Add("spys_180up",boost)


function BreakFallDamage()

RunConsoleCommand("+Back")
	local function SetEye()
		local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(89, a.y, a.r))
	end
	local function propSpawn()
		RunConsoleCommand("gm_spawn","models/props_docks/dock02_pole02a.mdl")
	end
timer.Simple(0.1,SetEye)
timer.Simple(0.2,propSpawn)
timer.Simple(0.25,function() RunConsoleCommand("-back") end)
end
concommand.Add("spys_AutoBreakFallDamage",BreakFallDamage)
