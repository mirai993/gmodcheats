--[[
	MOD/lua/Old/spys/jobs.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:22AM]
	===BadFile===
]]

/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
DarkRP custom jobs
---------------------------------------------------------------------------

This file contains your custom jobs.
This file should also contain jobs from DarkRP that you edited.

Note: If you want to edit a default DarkRP job, first disable it in darkrp_config/disabled_defaults.lua
	Once you've done that, copy and paste the job to this file and edit it.

The default jobs can be found here:
<TODO: INSERT URL HERE>

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomJobFields


Add jobs under the following line:
---------------------------------------------------------------------------*/
TEAM_BUILDER = DarkRP.createJob("Builder", {
    color = Color(81, 0, 44, 255),
    model = {"models/player/alyx.mdl"},
    description = [[People hire you to build things for them.
    The builder has access to various special tools to help them.]],
    weapons = {},
    command = "builder",
    max = 2,
    salary = 45,
    admin = 0,
    vote = false,
    hasLicense = false
})

TEAM_POLICE = DarkRP.createJob("Police Officer", {
	color = Color(25, 25, 170, 255),
	model = {"models/player/elispolice/police.mdl"},
	description = [[The protector of every citizen that lives in the city.
		You have the power to arrest criminals and protect innocents.
		Hit a player with your arrest baton to put them in jail.
		Bash a player with a stunstick and they may learn to obey the law.
		The Battering Ram can break down the door of a criminal, with a warrant for their arrest.
		The Battering Ram can also unfreeze frozen props (if enabled).
		Type /wanted <name> to alert the public to the presence of a criminal.]],
	weapons = {"arrest_stick", "unarrest_stick", "bb_glock_alt", "stunstick", "door_ram", "weaponchecker"},
	command = "police",
	max = 4,
	salary = 65,
	admin = 0,
	vote = true,
	hasLicense = true,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	}
})

TEAM_BG = DarkRP.createJob("Bodyguard", {
    color = Color(65, 65, 65, 255),
    model = "models/player/odessa.mdl",
    description = [[Your job is to protect whoever hires you.
    You start with a pistol and a stunstick to make your job easier.]],
    weapons = {"stunstick", "bb_usp_alt"},
    command = "bodyguard",
    max = 2,
    salary = 50,
    admin = 0,
    vote = false,
    hasLicense = true
})

TEAM_CHIEF = DarkRP.createJob("Police Chief", {
	color = Color(20, 20, 255, 255),
	model = "models/player/combine_soldier_prisonguard.mdl",
	description = [[The Chief is the leader of the Police Officers.
		Coordinate the police force to enforce law in the city.
		Hit a player with arrest baton to put them in jail.
		Bash a player with a stunstick and they may learn to obey the law.
		The Battering Ram can break down the door of a criminal, with a warrant for his/her arrest.
		Type /wanted <name> to alert the public to the presence of a criminal.
		Type /jailpos to set the Jail Position]],
	weapons = {"arrest_stick", "unarrest_stick", "bb_deagle_alt", "stunstick", "door_ram", "weaponchecker"},
	command = "chief",
	max = 1,
	salary = 75,
	admin = 0,
	vote = false,
	hasLicense = true,
	chief = true,
	NeedToChangeFrom = TEAM_POLICE,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	}
})

TEAM_THIEF = DarkRP.createJob("Thief", {
	color = Color(75, 75, 75, 255),
	model = {"models/player/pd2_dallas_p.mdl", "models/player/pd2_chains_p.mdl", "models/player/pd2_wolf_p.mdl", "models/player/pd2_hoxton_p.mdl"},
	description = [[]],
	weapons = {"keypad_cracker", "lockpick"},
	command = "thief",
	max = 4,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = false,
	help = {}
})

TEAM_HITMAN = DarkRP.createJob("Hitman", {
	color = Color(25, 25, 25, 255),
	model = "models/player/gman_high.mdl",
	description = [[You are the man who kills people.. for cash!
	This job is not an excuse to go around RDM'ing everyone.]],
	weapons = {"bb_awp_alt"},
	command = "hitman",
	max = 1,
	salary = 60,
	admin = 0,
	vote = false,
	hasLicense = true,
	help = {}
})

TEAM_HUNTER = DarkRP.createJob("Hobo Hunter", {
	color = Color(125, 95, 0, 255),
	model = "models/player/gman_high.mdl",
	description = [[You are a hobo hunter, feel free
	to kill the hobos! Limited time only! ]],
	weapons = {"bb_awp_alt"},
	command = "hunter",
	max = 2,
	salary = 60,
	admin = 0,
	vote = false,
	hasLicense = true,
	help = {}
})

TEAM_BANKER = DarkRP.createJob("Banker", {
	color = Color(25, 25, 170, 255),
	model = {"models/player/magnusson.mdl"},
	description = [[]],
	weapons = {},
	command = "banker",
	max = 1,
	salary = 80,
	admin = 0,
	vote = false,
	hasLicense = false,
	help = {}
})

TEAM_LGUN = DarkRP.createJob("Light Arms Dealer", {
	color = Color(255, 140, 0, 255),
	model = "models/player/monk.mdl",
	description = [[A Gun Dealer is the only person who can sell guns to other people.
		Make sure you aren't caught selling illegal firearms to the public! You might get arrested!]],
	weapons = {},
	command = "lgundealer",
	max = 2,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = true
})

TEAM_HGUN = DarkRP.createJob("Heavy Arms Dealer", {
	color = Color(255, 140, 0, 255),
	model = "models/player/monk.mdl",
	description = [[A Gun Dealer is the only person who can sell guns to other people.
		Make sure you aren't caught selling illegal firearms to the public! You might get arrested!]],
	weapons = {},
	command = "hgundealer",
	max = 2,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = true
})

TEAM_SWAT = DarkRP.createJob("Swat", {
	color = Color(25, 25, 170, 255),
	model = {"models/jessev92/player/misc/edfsoldier.mdl"},
	description = [[The protector of every citizen that lives in the city.
		You have the power to arrest criminals and protect innocents.
		Hit a player with your arrest baton to put them in jail.
		Bash a player with a stunstick and they may learn to obey the law.
		The Battering Ram can break down the door of a criminal, with a warrant for their arrest.
		The Battering Ram can also unfreeze frozen props (if enabled).
		Type /wanted <name> to alert the public to the presence of a criminal.]],
	weapons = {"arrest_stick", "unarrest_stick", "bb_usp_alt", "bb_m4a1_alt", "stunstick", "door_ram", "weaponchecker"},
	command = "swat",
	max = 4,
	salary = 65,
	admin = 0,
	vote = true,
	hasLicense = true,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	},
    customCheck = function(ply) return ply:CheckGroup("vip") end,
    CustomCheckFailMsg = "You need to be a VIP to use this Job."
})

TEAM_SWATS = DarkRP.createJob("Swat Sniper", {
	color = Color(25, 25, 170, 255),
	model = {"models/jessev92/player/misc/edfsoldier.mdl"},
	description = [[The protector of every citizen that lives in the city.
		You have the power to arrest criminals and protect innocents.
		Hit a player with your arrest baton to put them in jail.
		Bash a player with a stunstick and they may learn to obey the law.
		The Battering Ram can break down the door of a criminal, with a warrant for their arrest.
		The Battering Ram can also unfreeze frozen props (if enabled).
		Type /wanted <name> to alert the public to the presence of a criminal.]],
	weapons = {"arrest_stick", "unarrest_stick", "bb_usp_alt", "bb_awp_alt", "stunstick", "door_ram", "weaponchecker"},
	command = "swats",
	max = 4,
	salary = 65,
	admin = 0,
	vote = true,
	hasLicense = true,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	},
    customCheck = function(ply) return ply:CheckGroup("vip") end,
    CustomCheckFailMsg = "You need to be a VIP to use this Job."
})

TEAM_ADMIN = DarkRP.createJob("Staff on Duty", {
	color = Color(255, 0, 0, 255),
	model = {"models/player/combine_super_soldier.mdl"},
	description = [[Staff on Duty...
        what more do you need to know ;_;]],
	weapons = {},
	command = "admin",
	max = 0,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = true
	customCheck = function(ply) return ply:CheckGroup("mod") end,
    CustomCheckFailMsg = "You need to be Staff to use this Job."
})





/*---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------*/
GAMEMODE.DefaultTeam = TEAM_CITIZEN


/*---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------*/
GAMEMODE.CivilProtection = {
	[TEAM_POLICE] = true,
	[TEAM_CHIEF] = true,
	[TEAM_MAYOR] = true,
    [TEAM_SWAT] = true,
    [TEAM_SWATS] = true,
}

/*---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------*/
DarkRP.addHitmanTeam(TEAM_HITMAN)































/*--------------------------------------------------------
Default teams. If you make a team above the citizen team, people will spawn with that team!
--------------------------------------------------------*/
TEAM_CITIZEN = AddExtraTeam("Citizen", {
	color = Color(20, 150, 20, 255),
	model = {
		"models/player/Group01/Female_01.mdl",
		"models/player/Group01/Female_02.mdl",
		"models/player/Group01/Female_03.mdl",
		"models/player/Group01/Female_04.mdl",
		"models/player/Group01/Female_06.mdl",
		"models/player/group01/male_01.mdl",
		"models/player/Group01/Male_02.mdl",
		"models/player/Group01/male_03.mdl",
		"models/player/Group01/Male_04.mdl",
		"models/player/Group01/Male_05.mdl",
		"models/player/Group01/Male_06.mdl",
		"models/player/Group01/Male_07.mdl",
		"models/player/Group01/Male_08.mdl",
		"models/player/Group01/Male_09.mdl"
	},
	description = [[The Citizen is the most basic level of society you can hold
		besides being a hobo.
		You have no specific role in city life.]],
	weapons = {},
	command = "citizen",
	max = 0,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = false
})

TEAM_POLICE = AddExtraTeam("Civil Protection", {
	color = Color(25, 25, 170, 255),
	model = {"models/player/police.mdl", "models/player/police_fem.mdl"},
	description = [[The protector of every citizen that lives in the city .
		You have the power to arrest criminals and protect innocents.
		Hit them with your arrest baton to put them in jail
		Bash them with a stunstick and they might learn better than to disobey
		the law.
		The Battering Ram can break down the door of a criminal with a warrant
		for his/her arrest.
		The Battering Ram can also unfreeze frozen props(if enabled).
		Type /wanted <name> to alert the public to this criminal
		OR go to tab and warrant someone by clicking the warrant button]],
	weapons = {"arrest_stick", "unarrest_stick", "weapon_mad_glock", "stunstick", "door_ram", "weaponchecker"},
	command = "cp",
	max = 4,
	salary = 65,
	admin = 0,
	vote = true,
	hasLicense = true,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	}
})

TEAM_GANG = AddExtraTeam("Gangster", {
	color = Color(75, 75, 75, 255),
	model = {
		"models/player/Group03/Female_01.mdl",
		"models/player/Group03/Female_02.mdl",
		"models/player/Group03/Female_03.mdl",
		"models/player/Group03/Female_04.mdl",
		"models/player/Group03/Female_06.mdl",
		"models/player/group03/male_01.mdl",
		"models/player/Group03/Male_02.mdl",
		"models/player/Group03/male_03.mdl",
		"models/player/Group03/Male_04.mdl",
		"models/player/Group03/Male_05.mdl",
		"models/player/Group03/Male_06.mdl",
		"models/player/Group03/Male_07.mdl",
		"models/player/Group03/Male_08.mdl",
		"models/player/Group03/Male_09.mdl"},
	description = [[The lowest person of crime.
		A gangster generally works for the Mobboss who runs the crime family.
		The Mobboss sets your agenda and you follow it or you might be punished.]],
	weapons = {},
	command = "gangster",
	max = 3,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = false
})

TEAM_MOB = AddExtraTeam("Mob boss", {
	color = Color(25, 25, 25, 255),
	model = "models/player/gman_high.mdl",
	description = [[The Mobboss is the boss of the criminals in the city.
		With his power he coordinates the gangsters and forms an efficent crime
		organization.
		He has the ability to break into houses by using a lockpick.
		The Mobboss also can unarrest you.]],
	weapons = {"lockpick", "unarrest_stick"},
	command = "mobboss",
	max = 1,
	salary = 60,
	admin = 0,
	vote = false,
	hasLicense = false,
	help = {
		"As the mob boss, you decide what you want the other Gangsters to do.",
		"You get an Unarrest Stick which you can use to break people out of jail.",
		"/agenda <Message> Sets the Gangsters' agenda. Use // to go to the next line."
	}
})

TEAM_GUN = AddExtraTeam("Gun Dealer", {
	color = Color(255, 140, 0, 255),
	model = "models/player/monk.mdl",
	description = [[A gun dealer is the only person who can sell guns to other
		people.
		However, make sure you aren't caught selling guns that are illegal to
		the public.
		/Buyshipment <name> to Buy a  weapon shipment
		/Buygunlab to Buy a gunlab that spawns P228 pistols]],
	weapons = {},
	command = "gundealer",
	max = 2,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = false
})

TEAM_MEDIC = AddExtraTeam("Medic", {
	color = Color(47, 79, 79, 255),
	model = "models/player/kleiner.mdl",
	description = [[With your medical knowledge,
		you heal players to proper
		health.
		Without a medic, people can not be healed.
		Left click with the Medical Kit to heal other players.
		Right click with the Medical Kit to heal yourself.]],
	weapons = {"weapon_mad_medic"},
	command = "medic",
	max = 3,
	salary = 45,
	admin = 0,
	vote = false,
	hasLicense = false
})

TEAM_CHIEF = AddExtraTeam("Civil Protection Chief", {
	color = Color(20, 20, 255, 255),
	model = "models/player/combine_soldier_prisonguard.mdl",
	description = [[The Chief is the leader of the Civil Protection unit.
		Coordinate the police forces to bring law to the city
		Hit them with arrest baton to put them in jail
		Bash them with a stunstick and they might learn better than to
		disobey the law.
		The Battering Ram can break down the door of a criminal with a
		warrant for his/her arrest.
		Type /wanted <name> to alert the public to this criminal
		Type /jailpos to set the Jail Position]],
	weapons = {"arrest_stick", "unarrest_stick", "weapon_mad_deagle", "stunstick", "door_ram", "weaponchecker"},
	command = "chief",
	max = 1,
	salary = 75,
	admin = 0,
	vote = false,
	hasLicense = true,
	NeedToChangeFrom = TEAM_POLICE,
	help = {
		"Please don't abuse your job",
		"When you arrest someone they are auto transported to jail.",
		"They are auto let out of jail after some time",
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect",
		"Type /jailpos to set the jail position"
	}
})

TEAM_MAYOR = AddExtraTeam("Mayor", {
	color = Color(150, 20, 20, 255),
	model = "models/player/breen.mdl",
	description = [[The Mayor of the city creates laws to serve the greater good
	of the people.
	If you are the mayor you may create and accept warrants.
	Type /wanted <name>  to warrant a player
	Type /jailpos to set the Jail Position
	Type /lockdown initiate a lockdown of the city.
	Everyone must be inside during a lockdown.
	The cops patrol the area
	/unlockdown to end a lockdown]],
	weapons = {},
	command = "mayor",
	max = 1,
	salary = 85,
	admin = 0,
	vote = true,
	hasLicense = false,
	help = {
		"Type /warrant [Nick|SteamID|Status ID] to set a search warrant for a player.",
		"Type /wanted [Nick|SteamID|Status ID] to alert everyone to a wanted suspect.",
		"Type /unwanted [Nick|SteamID|Status ID] to clear the suspect.",
		"Type /lockdown to initiate a lockdown",
		"Type /unlockdown to end a lockdown",
		"Type /placelaws to place a screen containing the laws.",
		"Type /addlaw and /removelaw to edit the laws."
	}
})

TEAM_HOBO = AddExtraTeam("Hobo", {
	color = Color(80, 45, 0, 255),
	model = "models/player/corpse1.mdl",
	description = [[The lowest member of society. All people see you laugh.
		You have no home.
		Beg for your food and money
		Sing for everyone who passes to get money
		Make your own wooden home somewhere in a corner or
		outside someone else's door]],
	weapons = {"weapon_bugbait"},
	command = "hobo",
	max = 5,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = false
})

//ADD CUSTOM TEAMS UNDER THIS LINE:

TEAM_HITMAN = AddExtraTeam("Hitman", Color(158, 39, 39, 255), "models/player/leet.mdl", [[You're a hired assassin.
People can pay you to kill people.
You may choose your own prices for your hits.
Although your job is to kill people, you can't
kill people without being paid first. Remember to use /advert Hit accepted and /advert Hit complete/failed.]], {"weapon_mad_knife","weapon_mad_usp"}, "hitman", 1, 80, 0, true, true, false)

TEAM_THIEF = AddExtraTeam("Thief", Color(79, 79, 79, 255), "models/player/Phoenix.mdl", [[You can use your lockpick to break into peoples
houses, but don't get caught! People can also pay
you to unlock doors.]], {"lockpick", "keypad_cracker"}, "thief", 4, 80, 0, false, false, true)

TEAM_GUARD = AddExtraTeam("Bodyguard", Color(128, 0, 255, 255), "models/player/barney.mdl", [[You must protect whoever hires you from threats such as
thieves and gangsters.]], {"weapon_mad_usp","stunstick"}, "guard", 2, 80, 0, true, true, false)

TEAM_SWAT = AddExtraTeam("SWAT", Color(10, 34, 252, 255), "models/player/swat.mdl", [[Work along side the Civil Protection to crack down
on crime in the city.Hit players with your arrest
baton to put them in jail. Bash them with a
stunstick and they might learn better than to
disobey the law. The Battering Ram can break down
the door of a suspect with a warrant for his/her
arrest.
The Battering Ram can also unfreeze frozen props.
Type /wanted <name> to alert the public to this
criminal
OR go to tab and warrant someone by clicking the
warrant button]], {"arrest_stick","unarrest_stick","weapon_mad_usp","stunstick","door_ram","weaponchecker","weapon_mad_m4"}, "swat", 2, 80, 0, true, true, {TEAM_POLICE})

TEAM_SWATCHIEF = AddExtraTeam("SWAT Chief", Color(10, 34, 252, 255), "models/player/gasmask.mdl", [[Leader of the SWAT unit.
 Coordinate the SWAT to bring law to the city. 
Work along side the Civil Protection to crack down
on crime in the city. Hit players with your arrest
baton to put them in jail. Bash them with a
stunstick and they might learn better than to
disobey the law. The Battering Ram can break down
the door of a suspect with a warrant for his/her
arrest.	The Battering Ram can also unfreeze frozen
props. Type /wanted <name> to alert the public to
this criminal OR go to tab and warrant someone by
clicking the warrant button]], {"arrest_stick","unarrest_stick","arrest_stick","weapon_mad_deagle","stunstick","weaponchecker","weapon_mad_m4", "door_ram"}, "swatchief", 1, 100, 0, true, true, {TEAM_SWAT})

TEAM_BLACK = AddExtraTeam("Black Market Dealer", Color(102, 102, 51, 255), "models/player/eli.mdl", [[You sell items which are illegal. Try not to get
caught by the police!]], {}, "rp_blackmarket", 2, 50, 0, true, false, false)

TEAM_MTHIEF = AddExtraTeam("Master Thief", {
    color = Color(90, 90, 90, 255),
    model = "models/player/arctic.mdl",
    description = [[ *This is a special donator job* 
	You can use your lockpick to break into peoples
	houses, but don't get caught! People can also pay
	you to unlock doors.]],
    weapons = {"keypad_cracker","pro_lockpick","weapon_mad_dual"},
    command = "mthief",
    max = 3,
    salary = 100,
	admin = 0,
    vote = false,
    hasLicense = false,
		customCheck = function(ply) 
			return CLIENT or (ply:GetUserGroup() == "tier 1 donator" or  ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin()) 
    	end,
		customCheckFailMsg = "You need to be a Tier 1 donator or above to become a Master Thief."
})

TEAM_SNIPER = AddExtraTeam("SWAT Sniper", {
    color = Color(10, 34, 252, 255),
    model = "models/player/urban.mdl",
    description = [[*This is a special donator job* 
Work along side the Civil Protection to crack down
on crime in the city.Hit players with your arrest
baton to put them in jail. Bash them with a
stunstick and they might learn better than to
disobey the law. The Battering Ram can break down
the door of a suspect with a warrant for his/her
arrest.
The Battering Ram can also unfreeze frozen props.
Type /wanted <name> to alert the public to this
criminal
OR go to tab and warrant someone by clicking the
warrant button]],
    weapons = {"arrest_stick", "unarrest_stick", "weapon_mad_deagle", "stunstick", "door_ram", "weaponchecker", "weapon_mad_g3"},
    command = "sniper",
    max = 1,
    salary = 100,
	admin = 0,
    vote = true,
    hasLicense = true,
		customCheck = function(ply) 
			return CLIENT or (ply:GetUserGroup() == "tier 1 donator" or  ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin()) 
    	 end,
		customCheckFailMsg = "You need to be a Tier 1 donator or above to become the SWAT Sniper."
})

TEAM_NINJA = AddExtraTeam("Old Man Ninja", {
    color = Color(255, 174, 201, 255),
    model = "models/player/hostage/hostage_04.mdl",
    description = [[*This is a special donator job* 
	Fly around using the Spiderman gun! 
	Laugh at people who can't fly around using the spiderman gun! 
	-Don't use this job to RDM then quickly escape.]],
    weapons = {"spider_gun"},
    command = "ninja",
    max = 1,
    salary = 0,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 1 donator" or  ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin()) 
    	 end,
		customCheckFailMsg = "You need to be a Tier 1 donator or above to become the Old Man Ninja."
})

TEAM_KING = AddExtraTeam("King Hobo", {
    color = Color(90, 55, 0, 255),
    model = "models/player/corpse1.mdl",
	description = [[ *This is a special donator job* 
		The highest member of the lowest members of society.
		You have no home.
		Lead all of the other hobos.
		Make your own palace somewhere in a corner or
		outside someone else's door]],
    weapons = {"weapon_bugbait"},
    command = "kinghobo",
    max = 1,
    salary = 0,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 1 donator" or  ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin()) 
    	 end,
		customCheckFailMsg = "You need to be a Tier 1 donator or above to become the King Hobo"
})

TEAM_TERROR = AddExtraTeam("Terrorist", {
    color = Color(185, 122, 87, 255),
    model = "models/player/guerilla.mdl",
	description = [[*This is a special donator job*
	A terrorists job is to cause as much trouble for the Civil Protection as possible.
	This can be done through raids, illegal activities, taking the mayor hostage and so on.
	*DO NOT USE THIS JOB AS AN EXCUSE TO RDM CIVIL PROTECTION*]],
    weapons = {"weapon_mad_ak47", "weapon_mad_deagle", "lockpick"},
    command = "terrorist",
    max = 1,
    salary = 0,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 1 donator" or  ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin())
    	 else
		customCheckFailMsg = "You need to be a Tier 1 donator or above to become a Terrorist."
		end
})

TEAM_ULTIMATE = AddExtraTeam("Ultimate Dealer", {
    color = Color(233, 233, 233, 255),
    model = "models/player/magnusson.mdl",
	description = [[*This is a special donator job*
	The ultimate dealer sells virtually everything available. 
	But remember, you are still not above the law and must follow RP rules regardless.]],
    weapons = {},
    command = "ultimate",
    max = 1,
    salary = 200,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin())
    	 end,
		customCheckFailMsg = "You need to be a Tier 3 donator to become the Ultimate Dealer."
})

TEAM_CAR = AddExtraTeam("Car Dealer", {
    color = Color(34, 177, 76, 255),
    model = "models/player/odessa.mdl",
	description = [[*This is a special donator job*
	The car dealer sells cars to people with enough money.
	The car dealer must instruct people about rules on the road.]],
    weapons = {},
    command = "cardealer",
    max = 1,
    salary = 150,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin())
    	 end,
		customCheckFailMsg = "You need to be a Tier 2 donator or above to become a Car Dealer."
})

TEAM_BUILDER = AddExtraTeam("Builder", {
    color = Color(128, 255, 255, 255),
    model = "models/player/alyx.mdl",
	description = [[*This is a special donator job*
	This job allows players to build for people using their unlocked tools.
	Players using this job are allowed to build in the street, as long as it is deemed withing reason.]],
    weapons = {},
    command = "builder",
    max = 2,
    salary = 100,
	admin = 0,
    vote = false,
    hasLicense = true,
		customCheck = function(ply)
			return CLIENT or (ply:GetUserGroup() == "tier 2 donator" or  ply:GetUserGroup() == "tier 3 donator" or ply:IsSuperAdmin())
    	 end,
		customCheckFailMsg = "You need to be a Tier 2 donator or above to become a Builder."
})

TEAM_ADMIN = AddExtraTeam("Admin on duty", {
	color = Color(255, 0, 0, 255),
	model = "models/player/combine_super_soldier.mdl",
	description = [[ Makes you an admin on duty.
Do not overuse or RP while in this job.]],
	weapons = {},
	command = "admin",
	max = 3,
	salary = 420,
	admin = 1,
	vote = false,
	hasLicense = false,
	candemote = false
})

TEAM_OWNER = AddExtraTeam("Admin on duty", {
     color = Color(255,0,0,255),
     model = "models/player/Combine_Super_Soldier.mdl",
     description = [[ Admin on duty's abusive older brother.]],
     weapons = {"stunstick", "arrest_stick", "unarrest_stick", "weapon_mad_gnome", "weapon_mad_admin", "keypad_cracker"},
     command = "superadmin",
     max = 3,
     salary = 69,
     admin = 2,
     vote = false,
     hasLicense = true,
	 function(ply) return ply:IsSuperAdmin()end 
})


/*
--------------------------------------------------------
HOW TO MAKE A DOOR GROUP
--------------------------------------------------------
AddDoorGroup("NAME OF THE GROUP HERE, you see this when looking at a door", Team1, Team2, team3, team4, etc.)

WARNING: THE DOOR GROUPS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!


The default door groups, can also be used as examples:
*/
AddDoorGroup("Cops and Mayor only", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR, TEAM_SWAT, TEAM_SWATCHIEF, TEAM_SNIPER)
AddDoorGroup("Gundealer only", TEAM_GUN)


/*
--------------------------------------------------------
HOW TO MAKE AN AGENDA
--------------------------------------------------------
AddAgenda(Title of the agenda, Manager (who edits it), Listeners (the ones who just see and follow the agenda))

WARNING: THE AGENDAS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!

The default agenda's, can also be used as examples:
*/
AddAgenda("Gangster's agenda", TEAM_MOB, {TEAM_GANG, TEAM_THIEF})
AddAgenda("Police agenda", TEAM_MAYOR, {TEAM_CHIEF, TEAM_POLICE, TEAM_SWAT, TEAM_SWATCHIEF, TEAM_SNIPER})


/*
---------------------------------------------------------------------------
HOW TO MAKE A GROUP CHAT
---------------------------------------------------------------------------
Pick one!
GAMEMODE:AddGroupChat(List of team variables separated by comma)

or

GAMEMODE:AddGroupChat(a function with ply as argument that returns whether a random player is in one chat group)
This one is for people who know how to script Lua.

*/
GM:AddGroupChat(function(ply) return ply:IsCP() end)
GM:AddGroupChat(TEAM_MOB, TEAM_GANG)

/*---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------*/
GM.CivilProtection = {
	[TEAM_POLICE] = true,
	[TEAM_CHIEF] = true,
	[TEAM_MAYOR] = true,
	[TEAM_SWAT] = true,
	[TEAM_SWATCHIEF] = true,
	[TEAM_SNIPER] = true,
}

/*---------------------------------------------------------------------------
Enable hitman goodies on this team
---------------------------------------------------------------------------*/
DarkRP.addHitmanTeam(TEAM_HITMAN)

