--[[
	MOD/lua/Old/spys/utilcmds.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:24AM]
	===BadFile===
]]


MsgC(Color(127,0,255),"\n Spy's UtilCMDS Initialized\n")


////////////////////
////// BHOP ///////
//////////////////

JumpHELD = false

function BHOPScript()
	if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+jump")
			timer.Create("JumpOFF",0.01,0,function()
				RunConsoleCommand("-jump")
			end)
		end
	end
end
hook.Add("Think","BHOP",BHOPScript)


////////////////////
/// ATM Crack /////
//////////////////

pins = {}

	function ATMPinPrep()

		for i=0,9 do
			table.insert(pins, "000"..i)
		end

		for i=10,99 do
			table.insert(pins, "00"..i)
		end

		for i= 100,999 do
			table.insert(pins, "0"..i)
		end

		for i=1000,9999 do
			table.insert(pins, i)
		end

	end
	timer.Create("ATMPinPrep",2,1,ATMPinPrep)


function ATMCrack(ply,cmd,args)
print("Initialized")
	for k,v in pairs(player.GetAll()) do
		if args[1] == v:Nick() then
			print("We got this far")
			for k,p in pairs(pins) do
				timer.Simple(tonumber(p)*.015,function()
				RunConsoleCommand("rp_atm_login",util.CRC(p),v:UniqueID(),v:Nick())
				end)
			end
		end
	end
end
concommand.Add("spys_atmcrack",ATMCrack)