--[[
	MOD/lua/Old/spys/namechange.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:23AM]
	===BadFile===
]]


MsgC(Color(127,0,255),"\n Spy's Name Change Initialized\n")

playernames = {}
 function PlayerNames()
 playernames = {}
	print(Color(127,0,255), "UPDATING PLAYER NAMES!")
	for k,v in pairs(player.GetAll()) do
		if v == LocalPlayer() or v:IsAdmin() or v:IsSuperAdmin() then
		else
			table.insert(playernames,0,v:Name())
		end
	end
end
timer.Create("PlayerNameUpdate",30,0,PlayerNames)
concommand.Add("spys_ForcePlayerUpdate",PlayerNames)

function NameChange(ply,cmd,args)
local plyN = table.Random(playernames)
print(plyN)
	RunConsoleCommand("say", "/rpname "..plyN.."  " )
end
concommand.Add("spys_NameChange",NameChange)
