--[[
	MOD/lua/spies/namechange.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:49AM]
	===BadFile===
]]


MsgC(Color(255,0,0),"\n Spies Name Change Initialized\n")

playernames = {}
 function PlayerNames()
 playernames = {}
	print("UPDATING PLAYER NAMES!")
	for k,v in pairs(player.GetAll()) do
		if v == LocalPlayer() or v:IsAdmin() or v:IsSuperAdmin() or v:GetFriendStatus() == "friend" then
		else
			table.insert(playernames,0,v:Name())
		end
	end
end
timer.Create("PlayerNameUpdate",30,0,PlayerNames)
concommand.Add("spies_ForcePlayerUpdate",PlayerNames)

function NameChange(ply,cmd,args)
local plyN = table.Random(playernames)
print(plyN)
	RunConsoleCommand("say", "/rpname "..plyN.."  " )
end
concommand.Add("spies_NameChange",NameChange)
