--[[
	MOD/lua/spies/exray.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:49AM]
	===BadFile===
]]


MsgC(Color(255,0,0),"\n Spies EXRAY Initialized\n")


//////////////////////
///// WallHack //////
////////////////////


// Config \\

spies.xray = {}
spies.xray.playercolour = {}
spies.xray.propphyscolour = {}
spies.xray.superadminscolour = {}
spies.xray.adminscolour = {}
spies.xray.otherscolour = {}

spies.xray.toggle = true
spies.xray.materialplayer = Material("/models/shiny")
spies.xray.materialprop = Material("/models/wireframe")

spies.xray.playercolour.r = 255
spies.xray.playercolour.g = 255
spies.xray.playercolour.b = 255

spies.xray.propphyscolour.r = 0
spies.xray.propphyscolour.g = 0
spies.xray.propphyscolour.b = 255

spies.xray.adminscolour.r = 255
spies.xray.adminscolour.g = 0
spies.xray.adminscolour.b = 0

spies.xray.superadminscolour.r = 255
spies.xray.superadminscolour.g = 255
spies.xray.superadminscolour.b = 0

spies.xray.otherscolour.r = 0
spies.xray.otherscolour.g = 255
spies.xray.otherscolour.b = 0


//       \\

function WallHack()
surface.PlaySound("garrysmod/ui_click.wav")
print(spies.xray.toggle)
	if spies.xray.toggle == false then
		print("off")
		spies.xray.toggle = true
		hook.Remove("HUDPaint","wallhack")

		for k,v in pairs(ents.FindByClass("prop_physics")) do
			v:SetNoDraw(false)
		end
		
	elseif spies.xray.toggle == true then
		spies.xray.toggle = false

		function WallHacks()
		render.MaterialOverride(spies.xray.materialplayer)
		cam.Start3D()
		cam.IgnoreZ(true)
		for k,v in pairs(player.GetAll()) do
			if v:IsValid() then		
				if v:GetFriendStatus() == "friend" then
					render.SetColorModulation(127,0,255)
				elseif v:IsUserGroup("user") or v:IsUserGroup("guest") or v:IsUserGroup("member") then
					render.SetColorModulation(spies.xray.playercolour.r, spies.xray.playercolour.b, spies.xray.playercolour.g)
				elseif v:IsSuperAdmin() then
					render.SetColorModulation(255,255,0)			
				elseif v:IsAdmin() or v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
					render.SetColorModulation(spies.xray.adminscolour.r, spies.xray.adminscolour.g, spies.xray.adminscolour.b)
				else
					render.SetColorModulation(spies.xray.otherscolour.r, spies.xray.otherscolour.g, spies.xray.otherscolour.b )
				end
				render.SetBlend(0.5)			
				v:DrawModel()				
			end
		end
		
		render.MaterialOverride(spies.xray.materialprop)
		for k,v in pairs(ents.FindByClass("prop_physics")) do
			if v:IsValid() then
				render.SetColorModulation(spies.xray.propphyscolour.r, spies.xray.propphyscolour.g, spies.xray.propphyscolour.b)
				render.SetBlend(0.5)
				v:DrawModel()
				v:SetNoDraw(true)
			end
		end
		
		for k,v in pairs(ents.FindByClass("gmod_button")) do
			if v:IsValid() then
				render.SetColorModulation(127,255,0)
				render.SetBlend(0.5)				
				v:DrawModel()
				v:SetNoDraw(true)
			end
		end
		
		cam.End3D()
		cam.IgnoreZ(false)
		end
		hook.Add("HUDPaint","wallhack",WallHacks)
	end
end
concommand.Add("spies_xray",WallHack)




//////////////////////
//////// ESP ////////
////////////////////

// Config \\

spies.esp = {}
spies.esp.adminscolour = {}
spies.esp.usercolour = {}
spies.esp.healthcolour = {}
spies.esp.healthcolourgreen = {}
spies.esp.healthcolourorange = {}
spies.esp.healthcolourred = {}

spies.esp.toggle = true

spies.esp.adminscolour.r = 255
spies.esp.adminscolour.g = 0
spies.esp.adminscolour.b = 0

spies.esp.usercolour.r = 255
spies.esp.usercolour.g = 255
spies.esp.usercolour.b = 255

spies.esp.healthcolourgreen.r = 0
spies.esp.healthcolourgreen.g = 255
spies.esp.healthcolourgreen.b = 0

spies.esp.healthcolourorange.r = 255
spies.esp.healthcolourorange.g = 73
spies.esp.healthcolourorange.b = 0

spies.esp.healthcolourred.r = 255
spies.esp.healthcolourred.g = 0
spies.esp.healthcolourred.b = 0

spies.esp.healthcolourred.r = 255
spies.esp.healthcolourred.g = 255
spies.esp.healthcolourred.b = 255

function ESP()
surface.PlaySound("garrysmod/ui_click.wav")
	if spies.esp.toggle == false then
		spies.esp.toggle = true
		hook.Remove("HUDPaint","esp")
	elseif spies.esp.toggle == true then
		spies.esp.toggle = false
		local function SESP()
			for k,v in pairs(player.GetAll()) do
				local pos = (v:GetPos() +Vector(0,0,100)):ToScreen()
				local pos2 = (v:GetPos() +Vector(0,0,120)):ToScreen()
				if (v!=LocalPlayer()) then
				if v:IsValid() and v:Alive() then
					if v:IsUserGroup("user") and v:Health() <= 100 and v:Health() > 64 then
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.usercolour.r , spies.esp.usercolour.b, spies.esp.usercolour.g ), 1 )
						draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(0,255,0), 1 )
					elseif v:IsUserGroup("user") and v:Health() < 65 and v:Health() >30 then
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.usercolour.r , spies.esp.usercolour.b, spies.esp.usercolour.g ), 1 )
						draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(255,80,0), 1 )	
					elseif v:IsUserGroup("user") and v:Health() < 31 and v:Health() >-1 then
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.usercolour.r , spies.esp.usercolour.b, spies.esp.usercolour.g ), 1 )
						draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(255,0,0 ), 1 )
					elseif v:GetFriendStatus() == "friend" then
					draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(127,255,0), 1 )
					else
						draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(spies.esp.adminscolour.r , spies.esp.adminscolour.b, spies.esp.adminscolour.g ), 1 )
							if v:Health() <= 100 and v:Health() > 64 then
							draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(0,255,0), 1 )	
							elseif v:Health() < 65 and v:Health() > 31 then
							draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(255,80,0 ), 1 )
							elseif v:Health() < 30 and v:Health() > -1 then
							draw.DrawText( v:Health(), "Trebuchet24", pos2.x,pos2.y, Color(255,0,0 ), 1 )
							else
							draw.DrawText( "N/A", "Trebuchet22", pos2.x,pos2.y, Color(255,0,0 ), 1 )	
							end					
					end
					if v:GetFriendStatus() == "friend" then
					draw.DrawText( v:Name(), "Trebuchet18", pos.x,pos.y, Color(127,255,0 ), 1 )
					end
					
					end
				end
			end
		end
		hook.Add("HUDPaint","esp",SESP)
	end
end
concommand.Add("spies_esp",ESP)

//////////////////////
//// Info Panel /////
////////////////////

spies.infopanel = {}
spies.infopanel.dims = {}
spies.infopanel.cfg = {}
spies.infopanel.cfg.boxcolour = {}

spies.infopanel.toggle = true

spies.infopanel.dims.w = (ScrW()*0.15)
spies.infopanel.dims.h = (ScrH()*0.1)
spies.infopanel.dims.x =  0 or (Menu:GetWide())
spies.infopanel.dims.y = ScrH()*0.3

spies.infopanel.dims.columnW = ScrW()*0.03
spies.infopanel.dims.columnH = ScrH()*0.3

spies.infopanel.cfg.boxcolour.r = 0
spies.infopanel.cfg.boxcolour.g = 0
spies.infopanel.cfg.boxcolour.b = 0
spies.infopanel.cfg.boxcolour.a = 180 

function InfoPanel()

	if spies.infopanel.toggle == false then
		spies.infopanel.toggle = true
		hook.Remove("HUDPaint","InfoPanel")
	elseif spies.infopanel.toggle == true then
		spies.infopanel.toggle = false

		local function Info()

		surface.SetDrawColor(spies.infopanel.cfg.boxcolour.r, spies.infopanel.cfg.boxcolour.g, spies.infopanel.cfg.boxcolour.b, spies.infopanel.cfg.boxcolour.a)

		local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer(),LocalPlayer():GetAimVector()))
			if tr.Entity:IsPlayer() then
				surface.DrawRect(spies.infopanel.dims.x, spies.infopanel.dims.y, spies.infopanel.dims.w, spies.infopanel.dims.h)

					draw.DrawText(" Name : "..tr.Entity:Name(), "Trebuchet24", spies.infopanel.dims.columnW+50, spies.infopanel.dims.columnH,Color(255,255,255),1)

					draw.DrawText(" SteamID : "..tr.Entity:SteamID(),"Trebuchet18",spies.infopanel.dims.columnW+35,spies.infopanel.dims.columnH+30,Color(255,255,255),1)

					draw.DrawText(" Rank : "..tr.Entity:GetUserGroup(),"Trebuchet18",spies.infopanel.dims.columnW,spies.infopanel.dims.columnH+50,Color(255,255,255),1)

					draw.DrawText("Money : "..tr.Entity.DarkRPVars.money,"Trebuchet18",spies.infopanel.dims.columnW,spies.infopanel.dims.columnH+70,Color(255,255,255),1)
					
					draw.DrawText("	Current Weapon : "..tr.Entity:GetActiveWeapon():GetClass(),"Trebuchet18",spies.infopanel.dims.columnW+35,spies.infopanel.dims.columnH+90,Color(255,255,255),1)
			end
		end
		hook.Add("HUDPaint","InfoPanel",Info)
	end
end
concommand.Add("spies_infopanel",InfoPanel)



//////////////////////
//// Head Trace /////
////////////////////

spies.headtrace = {}

spies.headtrace.toggle = true

function HeadTrace()
	if spies.headtrace.toggle == false then
		spies.headtrace.toggle = true
		hook.Remove("RenderScreenspaceEffects","HeadTrace")
	elseif spies.headtrace.toggle == true then
	spies.headtrace.toggle = false
		local function HeadTraceDraw()
			for k,v in pairs(player.GetAll()) do
				if v:IsValid() and v != LocalPlayer() then
					local pos = v:EyePos()
					render.DrawLine(pos,Vector(pos.x,pos.y,4000),Color(255,255,255),true)
				end
			end
		end
		hook.Add("PostDrawOpaqueRenderables","HeadTrace",HeadTraceDraw)
	end
end
concommand.Add("spies_headtrace",HeadTrace)



-- OLD ESP pretty dam bad
--[[
ESP = true

function ToggleESP()

print("Toggle")


	if ESP == false then
		ESP = true
		hook.Remove("HUDPaint","ESP")
		hook.Remove("PostDrawOpaqueRenderables","PlyXray")
		cam.IgnoreZ(false)
			surface.PlaySound("garrysmod/ui_click.wav")


	elseif ESP == true then
	surface.PlaySound("garrysmod/ui_click.wav")

		function ESP() -- Player ESP
			for k,v in pairs(player.GetAll()) do
				local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
				if !(v == LocalPlayer()) or !(v:IsAdmin()) or !(v:IsSuperAdmin()) then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
				end
				if v:IsAdmin() or v:IsSuperAdmin() then
					draw.DrawText( v:Name(), "Trebuchet18", Position.x, Position.y, Color(255,25,25,255), 1)
				end
			end
		end
		hook.Add("HUDPaint","ESP",ESP)

		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)


	function PlyXray() -- Player XRAY

		cam.IgnoreZ(true)
			render.SuppressEngineLighting( true )


			for k,v in pairs(player.GetAll()) do
			v:SetRenderMode(RENDERMODE_TRANSALPHA)
			v:SetMaterial("models/shiny")
			render.SetBlend(0.5)
			--render.MaterialOverride(Material("models/wireframe"))
			--render.SetMaterial(Material("models/shiny"))
				render.SetColorModulation( 0, 1, 0 )
				v:DrawModel()
			end

			for k,v in pairs(ents.FindByClass("prop_physics")) do
			--v:SetRenderMode(RENDERMODE_TRANSALPHA)
				v:SetMaterial("models/wireframe")
				render.SetBlend(0.2)
				--render.SetMaterial(Material("models/shiny"))
					render.SetColorModulation(0,0,1)
					v:DrawModel()
			end

		cam.IgnoreZ(false)
		render.SuppressEngineLighting(false)
	end
	hook.Add("PostDrawOpaqueRenderables","PlyXray",PlyXray)
	ESP = false

	end

end
concommand.Add("spies_esp",ToggleESP)

--]]
