--[[
	MOD/lua/spies.lua
	Snaggle | STEAM_0:0:22593800 <86.133.25.71:27005> | [06-01-14 01:08:18AM]
	===BadFile===
]]


spies = {}


-- Include Files Below

include("spies/exray.lua")
include("spies/namechange.lua")
include("spies/pkcmds.lua")
include("spies/utilcmds.lua")