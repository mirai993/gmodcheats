--[[
	lua/ThatHack/Config/ConCommands.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( ' ConCommands Loaded ' )

-- Aimbot
CreateClientConVar("ThatHack_AIM_Friendly",					0, true, false)
CreateClientConVar("ThatHack_AIM_Steam",					0, true, false)
CreateClientConVar("ThatHack_AIM_Admins",					0, true, false)
CreateClientConVar("ThatHack_AIM_Auto",						0, true, false)
CreateClientConVar("ThatHack_AIM_NoRecoil",					0, true, false)
CreateClientConVar("ThatHack_AIM_Offset",					0, true, false)
CreateClientConVar("ThatHack_AIM_AimSpot",					"Head", true, false)
CreateClientConVar("ThatHack_AIM_Trigger",					0, true, false)
CreateClientConVar("ThatHack_AIM_SH",						0, true, false)
CreateClientConVar("ThatHack_AIM_Anti",						0, true, false)
CreateClientConVar("ThatHack_AIM_Anti_Type",				"Invert", true, false)
CreateClientConVar("ThatHack_AIM_Anti_Angle_X",				"-181", true, false)
CreateClientConVar("ThatHack_AIM_Anti_Angle_Z",				"180", true, false)
CreateClientConVar("ThatHack_AIM_AntiSnap",					0, true, false)
CreateClientConVar("ThatHack_AIM_AntiSnap_Speed",			5, true, false)
CreateClientConVar("ThatHack_AIM_Fov",						180, true, false)
CreateClientConVar("ThatHack_AIM_Reload",					0, true, false)
CreateClientConVar("ThatHack_AIM_TargetBones",				0, true, false)
CreateClientConVar("ThatHack_AIM_CheckLos",					0, true, false)
CreateClientConVar("ThatHack_AIM_IgnoreNoWep",				0, true, false)
CreateClientConVar("ThatHack_AIM_Prediction",				0, true, false)
CreateClientConVar("ThatHack_AIM_SpawnProtection",			0, true, false)
CreateClientConVar("ThatHack_AIM_RapidFire",				0, true, false)
CreateClientConVar("ThatHack_AIM_Method",					"Distance", true, false)
CreateClientConVar("ThatHack_AIM_Silent",					0, true, false)
CreateClientConVar("ThatHack_AIM_AAA",						0, true, false)


-- ESP
CreateClientConVar('ThatHack_ESP_Info', 1, true, false )
CreateClientConVar('ThatHack_ESP_Box', 1, true, false )
CreateClientConVar('ThatHack_ESP_Skeleton', 1, true, false )
CreateClientConVar('ThatHack_ESP_Crosshair', 1, true, false )

-- Misc
CreateClientConVar('ThatHack_Misc_NoRecoil', 1, true, false )
CreateClientConVar('ThatHack_Misc_Bhop', 1, true, false )
CreateClientConVar('ThatHack_Misc_RPGod', 0, true, false )
CreateClientConVar('ThatHack_Misc_FlashLightSpamming', 0, true, false )
CreateClientConVar('ThatHack_Misc_PotatoHack', 1, true, false )
