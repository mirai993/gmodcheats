--[[
	lua/ThatHack/Config/RunConsoleCommand.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( ' Run ConsoleCommand Loaded ' )
local TH = {}