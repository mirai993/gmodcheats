--[[
	lua/ThatHack/ThatHack/modules/Misc_Bhop.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( ' BHOP Loaded ' )

function BHOP()
	if GetConVarNumber("ThatHack_Misc_Bhop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
				RunConsoleCommand("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
			end
		end
	end
end
hook.Add('Think', 'BHOP', BHOP )