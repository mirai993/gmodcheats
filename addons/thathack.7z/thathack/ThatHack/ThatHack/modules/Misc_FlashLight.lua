--[[
	lua/ThatHack/ThatHack/modules/Misc_FlashLight.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( ' FlashLight Spammer Loaded ' )      
	
function FlashLight()	
	if GetConVarNumber("ThatHack_Misc_FlashLightSpamming") == 1 then
		RunConsoleCommand("impulse","100")
	end
end
hook.Add('Think', 'FlashLight', FlashLight)