--[[
	lua/ThatHack/ThatHack/modules/AIM_AntiAim.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

/**************************
Name: Anti-Aim
Purpose: HVH feature
**************************/
/**************************
Name: Anti-Aim
Purpose: HVH feature
**************************/
TH:RegisterHook("CreateMove",function(cmd, u)
local caim
local getangs = cmd:GetViewAngles()
	if GetConVarNumber("ThatHack_AIM_Anti") == 1 then
		if GetConVarString("ThatHack_AIM_Anti_Type") == "Invert" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(181, getangs.y, 180))
			end
		elseif GetConVarString("ThatHack_AIM_Anti_Type") == "Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = Angle(0,math.random(-89,89),0) 
				cmd:SetViewAngles(NormalizeAng(caim))
			end
		elseif GetConVarString("ThatHack_AIM_Anti_Type") == "Random Pitch" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(math.random(181,180), getangs.y, 180))
			end	
		elseif GetConVarString("ThatHack_AIM_Anti_Type") == "Invert/Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = math.random(-89,89)
				cmd:SetViewAngles(Angle(181, NormalizeAng(caim), 180))
			end
		elseif GetConVarString("ThatHack_AIM_Anti_Type") == "Var" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				cmd:SetViewAngles(Angle(GetConVarNumber("ThatHack_AIM_Anti_Angle_X"),getangs.y,GetConVarNumber("ThatHack_AIM_Anti_Angle_Z")))
			end
		end
	end
end)