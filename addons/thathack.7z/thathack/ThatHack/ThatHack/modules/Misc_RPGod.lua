--[[
	lua/ThatHack/ThatHack/modules/Misc_RPGod.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( ' RPGod Loaded ' )

function RPGod()
	if( GetConVarNumber('ThatHack_Misc_RPGod') == 1 ) then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
		end
	end
end