--[[
	lua/ThatHack/ThatHack/modules/Esp_Info.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

print( 'ESP Info Loaded' )

local function ESPInfo()
if( GetConVarNumber( 'ThatHack_ESP_Info' ) != 0 ) then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() ) then
local Pos = ( v:GetPos() + Vector( 0, 0, 75 ) ):ToScreen();
surface.SetDrawColor( team.GetColor( v:Team() ) )
draw.SimpleText( "N: " ..v:Name(), 'TabLarge', Pos.x, Pos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "H: " ..v:Health(), 'TabLarge', Pos.x, Pos.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
draw.SimpleText( "A: " ..v:Armor(), 'TabLarge', Pos.x, Pos.y + 20, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER );
end
end
end
end
hook.Add( 'HUDPaint', 'ESP', ESPInfo )