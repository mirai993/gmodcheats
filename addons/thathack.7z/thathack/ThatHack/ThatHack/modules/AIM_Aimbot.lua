--[[
	lua/ThatHack/ThatHack/modules/AIM_Aimbot.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
Credits: Isis, Hera
*******************************************/


local shouldFire = 0
// So ugly, ugh.
// There's better ways of doing this, but making a "toggle" function seemed best.
function RapidFire()
	if GetConVarNumber("ThatHack_AIM_RapidFire") == 1 and input.IsMouseDown(MOUSE_LEFT) then
		if shouldFire == 0 then
			shouldFire = 1
		else 
			shouldFire = 0
		end
		if shouldFire == 0 then
			RunConsoleCommand("+attack")
		else
			RunConsoleCommand("-attack")
		end
		elseif shouldFire == 0 then
			RunConsoleCommand("-attack")
		if shouldFire == 0 then
			shouldFire = 1
		else
			shouldFire = 0

		end
	end
end


/****************************************
Aimbot functions
****************************************/

/********
bonescan
hermes v1
*******/

-- get owned
function IsSpawnProtected(ent)
	if ((GAMEMODE.Name):lower()):find("stronghold") then
		local entcol = ent:GetColor(r, g, b, a)
		if entcol.a < 255 then
			return true
		else
			return false
		end
	end
end

function AimSpot(ent)
	if GetConVarNumber("ThatHack_AIM_TargetBones") == 0 then
		local eyes = ent:LookupAttachment("eyes")
		if GetConVarNumber("ThatHack_AIM_AAA") == 1 and (ent:EyeAngles().p < -89) then
			return ent:LocalToWorld( ent:OBBCenter())
		elseif(eyes ~= 0) then
			eyes = ent:GetAttachment(eyes)
			if(eyes and eyes.Pos) then
				return eyes.Pos, eyes.Ang
			end
		end
	end

local bonename = ThatHack.aimmodels[ent:GetModel()]
	if(not bonename) then
		for k, v in pairs(ThatHack.bones) do
			if(v[1] == GetConVarString("ThatHack_AIM_AimSpot")) then
				bonename = v[2]
			end
		end
		bonename = bonename or "ValveBiped.Bip01_Head1"
	end
	local aimbone = ent:LookupBone(bonename);
	if(aimbone) then
		local pos, ang = ent:GetBonePosition(aimbone)
		return pos, ang;
	end
return ent:LookupBone("ValveBiped.Bip01_Head1")
--return ent:LocalToWorld(ent:OBBCenter())
end

function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("ThatHack_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end 
	if (ent:IsPlayer() and (ent:IsAdmin() or ent:IsSuperAdmin()) and GetConVarNumber("ThatHack_AIM_Admins") == 0) then return false end	
	if (GetConVarNumber("ThatHack_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
	if (GetConVarNumber("ThatHack_AIM_SH") == 1 && IsSpawnProtected(ent)) then return false end
	if (ent:IsPlayer() and GetConVarNumber("ThatHack_AIM_IgnoreNoWep") == 1 and not IsValid(ent:GetActiveWeapon())) then return false end
	if (GetConVarNumber("ThatHack_AIM_SpawnProtection") == 1 and ent:GetColor(r, g, b, a).a < 255) then return false end
return true
end

function HasLOS(ent)
	if(GetConVarNumber("ThatHack_AIM_CheckLOS") == 0) then return true end
	local trace = util.TraceLine( {
		start = LocalPlayer():GetShootPos(),
		endpos = AimSpot(ent),
		filter = { LocalPlayer(), e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if (( trace.Fraction >= 0.99 )) then return true end
	return false
end

function InFov( ent )
	local fov = GetConVarNumber("ThatHack_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

/*
 local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
if ( distance < 4000 && speed > 0 ) then p = self():GetVelocity() * distance / (speed * distance * 0.125) end
if ( weapon:IsWeapon() && prediction[weapon:GetClass()] != 0 ) then t = target:GetVelocity() * distance / (prediction[weapon:GetClass()] || 150000) end

vector = vector - p + t
end
*/

function AimPrediction( pos , pl )
	if IsValid( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon and ( IsValid( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )	
		if weapon and ThatHack.prediction[ weapon ] then
			local time = distance / ThatHack.prediction[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

function NormalizeAng(angle)
	if type(angle) == "Angle" then
		return Angle(math.NormalizeAngle(angle.p) , math.NormalizeAngle(angle.y) , math.NormalizeAngle(angle.r))
	end
	return angle
end

function GetTargets()
local target;
if target == nil then target = LocalPlayer() else target = target end
local ply = LocalPlayer()
local angA, angB = 0
local x, y = ScrW(), ScrH()
local distance = math.huge;
	for k, v in pairs(player.GetAll()) do
		if (v != LocalPlayer() and v:Alive() and HasLOS(v) and Exception(v) and InFov(v)) then
			local ePos, oldPos, myAngV = v:EyePos():ToScreen(), target:EyePos():ToScreen(), ply:GetAngles()
			local thedist = v:GetPos():DistToSqr(LocalPlayer():GetPos());
			angA = math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
			angB = math.Dist( x / 2, y / 2, ePos.x, ePos.y )
			if GetConVarString("ThatHack_AIM_Method") == "Closest To Crosshair" then
				if ( angB <= angA ) then
					target = v;
				elseif target == ply then
					target = v;
				end
			elseif GetConVarString("ThatHack_AIM_Method") == "Distance" then
				if (thedist < distance) then
					distance = thedist;
					target = v;
				end					
			end
		end
	end
return target
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("ThatHack_AIM_AntiSnap_Speed") / 10
local aimang = Angle(0,0,0)
	if Aimon == 1 then		
		local target = GetTargets()
		if target != nil and target != LocalPlayer() then
	
		-- Offset
		local Aimspot;
		if GetConVarNumber("ThatHack_AIM_Prediction") == 1 then
			Aimspot = AimPrediction(AimSpot(target)) - Vector(0,0,GetConVarNumber("ThatHack_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() * ( 1 / 66 ) - LocalPlayer():GetVelocity() * ( 1 / 66 )
		else
			Aimspot = (AimSpot(target)) - Vector(0,0,GetConVarNumber("ThatHack_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
		end
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		-- Anti snap
		if GetConVarNumber("ThatHack_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			aimang = Angle (Smooth1, Smooth2, 0)
		else
			-- Normal
			aimang = Angle( Angel.p, Angel.y, 0 )
		end
		-- faggot
			_G.debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, aimang)
			if GetConVarNumber("ThatHack_AIM_Auto") == 1 then
               ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("ThatHack_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

TH:AddCMD("+ThatHack_Aim",function()
Aimon = 1
end)

TH:AddCMD("-ThatHack_Aim",function()
Aimon = 0
end)