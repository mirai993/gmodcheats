--[[
	lua/ThatHack/ThatHack/modules/AIM_Reload.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun", "weapon_keys", "weapon_pocket", "pocket", "rp_pocket", "rp_keys", "keys"}
function AutoReload()
    if (GetConVarNumber("ThatHack_AIM_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			RunConsoleCommand( "+reload" )
			LastReload = CurTime()
			Hera:AddTimer( .2, 1, function()
				RunConsoleCommand( "-reload" )
			end )
		end
    end
end

local function StartFire()
	RunConsoleCommand("+attack")
end

local function StopFire()
	RunConsoleCommand("-attack")
end