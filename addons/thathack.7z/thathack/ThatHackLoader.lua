--[[
	lua/ThatHackLoader.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

local TH = {}

-- Module Loader
Msg("\n==================================\n")
Msg("ThatHack Module Loader: \n")
for k, v in pairs( file.Find("lua/ThatHack/ThatHack/modules/*.lua", "GAME")) do
include("ThatHack/ThatHack/modules/"..v)
include("ThatHack/config/ConCommands.lua" )
include("ThatHack/config/RunConsoleCommand.lua" )
end
Msg("\n==================================\n")

-- Config Loader
Msg("\n==================================\n")
Msg("ThatHack Config Loader: \n")
for k, v in pairs( file.Find("lua/ThatHack/ThatHack/Config/*.lua", "GAME")) do
include("ThatHack/ThatHack/modules/"..v)
end
Msg("\n==================================\n")
