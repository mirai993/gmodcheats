--[[
	lua/Tnac_Remake/tnac_core.lua
	DJ Simple | (STEAM_0:1:60333045)
	===DStream===
]]

-- Tnac remake
-- round fucking 2 here we go

-- ClientSide
if ( CLIENT ) then
	LocalPlayer():ChatPrint('Running Client-Side')
else
	LocalPlayer():ChatPrint('Running Server-Side')
end

-- Locals
local tnac = {}
local client 		= LocalPlayer();
local CCCV			= CreateClientConVar; 
local GCVN			= GetConVarNumber; 

local Colors 	= {}
Red				= Color(255, 0, 0, 255);
Green			= Color(0, 255, 0, 255);
Blue			= Color(0, 0, 255, 255);
White			= Color(255, 255, 255, 255 );
Black			= Color( 0, 0, 0, 255 );

-- Requirments
require('cvar3')
--include('tnac_remake/tnac_include')

-- 