--[[
	lua/TNAC/TnacCore.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Name: TotalNotACheat
Purpose: Not A Hack
]]

timer.Simple(1, function()

	Msg("/////////////////////////////////// \n")
	Msg("///////////TotalNotACheat ///////// \n")
	Msg("////////// Core Loaded...////////// \n")
	Msg("/////////////////////////////////// \n")
end )

-- Client Side Stuff
if ( SERVER ) then return end

-- Require
require('cvar3')
include('TNAC/TnacRP')
include('TNAC/TnacTTT')
include('TNAC/TnacSBOX')

-- Colors
local Colors				= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
Orange						= Color(255,100,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);

-- Loading Up --
chat.AddText(
Red, "[TNAC] ",
Blue, "Hack ",
Blue, "Loaded ",
Green, "Successfully.....")

-- ConVars
CCCV('tnac_esp_info', 				0, true, false)
CCCV('tnac_esp_healthbar', 			0, true, false)
CCCV('tnac_esp_dead', 				0, true, false)
CCCV('tnac_esp_ESPNPC', 			0, true, false)
CCCV('tnac_esp_playerbox', 			0, true, false)
CCCV('tnac_esp_crosshair', 			0, true, false)
CCCV('tnac_Crosshair_Red', 			0, true, false)
CCCV('tnac_Crosshair_Green', 		255, true, false)
CCCV('tnac_Crosshair_Blue', 		0, true, false)

-- Shorten shit
local TNAC	= {}
local TAC 	= TEXT_ALIGN_CENTER;
local CCCCV	= CreateClientConVar;


-- Core Code
function ESP()
	if( GetConVarNumber('tnac_esp_info') == 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
					local Pos = ( v:EyePos() ):ToScreen()
						if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
						draw.SimpleText( "N: "	..v:Nick(), "TabLarge", Pos.x, Pos.y, White, TAC, TAC )
						draw.SimpleText( "H: "	..v:Health(), "TabLarge", Pos.x, Pos.y + 10, White, TAC, TAC)
						if v:IsAdmin() then
						draw.SimpleText( "-[Admin]-", "TabLarge", Pos.x, Pos.y - 10, Red, TAC, TAC )
					end
						if v:GetFriendStatus() == "friend" then
						draw.SimpleText( "-[Friend]-", "TabLarge", Pos.x, Pos.y - 20, Blue, TAC, TAC )
					end
				end
			end
		end
	end
end
if( GetConVarNumber('tnac_esp_healthbar') >= 1 ) then
				if v:Health() >= 75 then
				HPColor = Green
				elseif v:Health() >= 35 and v:Health() < 75 then
				HPColor = Gold
				elseif v:Health() < 35 then
				HPColor = Red
			end
				draw.RoundedBox( 0, pos.x-17, pos.y+4, 42, 6,Color(0,0,0,255))
				draw.RoundedBox( 0, pos.x-16, pos.y+5, 0.4 * math.Clamp( v:Health(), 1, 100 ), 4,HPColor)
			end
if( GetConVarNumber('tnac_esp_dead') >= 1 ) then
				local Pos = ( v:EyePos() ):ToScreen()
					if v:Health() < 1 then
					draw.SimpleText( "-[Dead]- ( " .. v:Nick() .. " )", "TargetID", Pos.x, Pos.y - 10, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end

if GetConVarNumber( "tnac_esp_NPCESP" ) >= 1 then
	for k, v in pairs( ents.GetAll() ) do
		if ValidEntity( v ) then
			if v:IsNPC() then
				local NpcESPPos = ( v:EyePos() ):ToScreen()
					draw.SimpleText( v:GetClass(), "TabLarge", NpcESPPos.x, NpcESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
hook.Add('HUDPaint', 'ESP', ESP)






















