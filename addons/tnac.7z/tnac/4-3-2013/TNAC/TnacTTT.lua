--[[
	lua/TNAC/TnacTTT.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

timer.Simple(1, function()
	Msg("///////////TotalNotACheat ///////// \n")
	Msg("////////// TTT Loaded...////////// \n")
end )