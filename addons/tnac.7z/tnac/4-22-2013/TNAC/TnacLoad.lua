--[[
	lua/TNAC/TnacLoad.lua
	DJ Simple | (STEAM_0:1:60333045)
	===DStream===
]]

timer.Simple(1, function()

	Msg("/////////////////////////////////// \n")
	Msg("///////////TotalNotACheat ///////// \n")
	Msg("////////// Information Loaded.../// \n")
	Msg("/////////////////////////////////// \n")
	
end )