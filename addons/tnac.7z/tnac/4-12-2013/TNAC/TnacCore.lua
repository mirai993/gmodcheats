--[[
	lua/TNAC/TnacCore.lua
	SimpleIsTheBest | (STEAM_0:1:60333045)
	===DStream===
]]

--[[
Name: TotalNotACheat
PurPose: Not A Hack
]]

timer.Simple(1, function()

	Msg("/////////////////////////////////// \n")
	Msg("///////////TotalNotACheat ///////// \n")
	Msg("////////// Core Loaded...////////// \n")
	Msg("/////////////////////////////////// \n")
	
end )

-- Client Side Stuff
if ( SERVER ) then return end

-- Require
require('cvar3')
include('TNAC/TnacRP.lua')
include('TNAC/TnacTTT.lua')
include('TNAC/TnacLoad.lua')

-- Loading
local Colors				= {}
Red							= Color(255,0,0,255);
Black						= Color(0,0,0,255);
Green						= Color(0,255,0,255);
Orange						= Color(255,100,0,255);
White						= Color(255,255,255,255);
Blue						= Color(0,0,255,255);
Cyan						= Color(0,255,255,255);
Pink 						= Color(255,0,255,255);
Blue						= Color(0,0,255,255);
Grey						= Color(100,100,100,255);
Gold						= Color(255,228,0,255);

-- Shorten shit
local TNAC	= {}
local TAC 	= TEXT_ALIGN_CENTER;
local CCCV	= CreateClientConVar;

-- Loading Up --
chat.AddText(
Red, "[TNAC] ",
Blue, "Hack ",
Blue, "Loaded ",
Green, "Successfully.....")

-- ConVars
CCCV('tnac_esp_info', 				0, true, false)
CCCV('tnac_esp_healthbar', 			0, true, false)
CCCV('tnac_esp_dead', 				0, true, false)
CCCV('tnac_esp_ESPNPC', 			0, true, false)
CCCV('tnac_esp_playerbox', 			0, true, false)
CCCV('tnac_esp_crosshair', 			0, true, false)
CCCV('tnac_Crosshair_Red', 			0, true, false)
CCCV('tnac_Crosshair_Green', 		255, true, false)
CCCV('tnac_Crosshair_Blue', 		0, true, false)

CCCV( "vh_silentaim", 0, true, false )
CCCV( "vh_trigger", 0, true, false )
CCCV( "vh_nospread", 0, true, false )


-- Core Code
function ESP()
	if( GetConVarNumber('tnac_esp_info') == 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
					local Pos = ( v:EyePos() ):ToScreen()
						if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
						draw.SimpleText( "N: "	..v:Nick(), "TabLarge", Pos.x, Pos.y, Green, TAC, TAC )
						draw.SimpleText( "H: "	..v:Health(), "TabLarge", Pos.x, Pos.y + 10, Green, TAC, TAC)
						if v:IsAdmin() then
						draw.SimpleText( "-[Admin]-", "TabLarge", Pos.x, Pos.y - 40, Red, TAC, TAC )
					end
						if v:GetFriendStatus() == "friend" then
						draw.SimpleText( "-[Friend]-", "TabLarge", Pos.x, Pos.y - 50, Blue, TAC, TAC )
					end
				end
			end
		end
	end
end
if( GetConVarNumber('tnac_esp_healthbar') >= 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
				local Pos = ( v:EyePos() ):ToScreen()
				if v:Health() >= 75 then
				HPColor = Green
				elseif v:Health() >= 35 and v:Health() < 75 then
				HPColor = Gold
				elseif v:Health() < 35 then
				HPColor = Red
			end
				draw.RoundedBox( 0, Pos.x-17, Pos.y-15, 42, 6,Color(0,0,0,255))
				draw.RoundedBox( 0, Pos.x-16, Pos.y-15, 0.4 * math.Clamp( v:Health(), 1, 100 ), 4,HPColor)
			end
if( GetConVarNumber('tnac_esp_dead') >= 1 ) then
		for k, v in pairs( player.GetAll() ) do
			if IsValid( v ) then
				if v ~= LocalPlayer() then
				local Pos = ( v:EyePos() ):ToScreen()
					if v:Health() < 1 then
					draw.SimpleText( "-[Dead]- ( " .. v:Nick() .. " )", "TargetID", Pos.x, Pos.y - 10, Red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end

if GetConVarNumber( "tnac_esp_NPCESP" ) >= 1 then
	for k, v in pairs( ents.GetAll() ) do
		if IsValid( v ) then
			if v:IsNPC() then
				local NpcESPPos = ( v:EyePos() ):ToScreen()
					draw.SimpleText( v:GetClass(), "TabLarge", NpcESPPos.x, NpcESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
end
end
end
end
end

if GetConVarNumber("tnac_esp_playerbox") == 1 then
	cam.Start3D(EyePos(), EyeAngles());
		for k, ply in pairs(player.GetAll()) do
			if( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
				local pos = ply:GetPos();
				local width = 32;
				local height = 80;
				local scale = 1;
				local BoxColor = Red
				local ang = EyeAngles();
				ang.p = ang.p - 90;
					pos = pos - (ang:Right() * (width / 2))
					cam.Start3D2D(pos, ang, (1 / scale));
						surface.SetDrawColor(BoxColor)
						surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
					cam.End3D2D();
				end
			end
		cam.End3D();
	end
end
hook.Add("HUDPaint","ESP",ESP)

/////////////////
// **Aimbot** //
///////////////
--No Recoil--
hook.Add( "Think", "No Recoil", function()
if GetConVarNumber( "vh_norecoil" ) >= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                end
        end
end )
 
--Aimbot--
// ### TEMPORARY AIMBOT CODE ### //
// Yes I know this aimbot is shit,//
//I will replace it when I get the//
//coding skills to do so.//
 
local Aiming = false;
local Target = nil;
 
local function IsVisible( e )
        local Trace = {};
        Trace.start = LocalPlayer():GetShootPos();
        Trace.endpos = e:GetBonePosition( e:LookupBone( 'ValveBiped.Bip01_Head1' ) );
        Trace.mask = MASK_SHOT
        Trace.filter = { LocalPlayer(), e };
        local tr = util.TraceLine( Trace );
        if( !tr.Hit ) then return true; end
end
 
local function Valid( e )
        if( !IsValid( e ) || !IsValid( e ) ) then return false; end
        if( !e:Alive() || !e:IsPlayer() ) then return false; end
        if( e == LocalPlayer() || e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then return false; end
        return true;
end
 
local function Aimbot( u )
        if( !Aiming ) then return; end
        for k, v in pairs( player.GetAll() ) do
                if( IsVisible( v ) && Valid( v ) ) then
                        Target = v;
                        if( !Target ) then return; end
                        local Bone = Target:GetBonePosition( Target:LookupBone( 'ValveBiped.Bip01_Head1' ) );
                        Bone = Bone + Target:GetVelocity() / 50 + LocalPlayer():GetVelocity() / 50
                        local Angl = ( Bone - LocalPlayer():GetShootPos() ):Angle();
                        Angl.p = math.NormalizeAngle( Angl.p );
                        Angl.y = math.NormalizeAngle( Angl.y );
                        Angl.r = 0
                        u:SetViewAngles( Angl );
                        local w = LocalPlayer():GetActiveWeapon()
                        if( w.Primary ) then w.Primary.Recoil = 0 end;
                        if( w.Secondary ) then w.Secondary.Recoil = 0 end;
                end
        end
end
hook.Add( 'CreateMove', '\2\3', Aimbot );
concommand.Add( '+tnac_aim', function() Aiming = true end );
concommand.Add( '-tnac_aim', function() Aiming = false end );
 
--NoSpread--
 
function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end
 
local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons[ "weapon_pistol" ]          = WeaponVector( 0.0100, true )  // HL2 Pistol
CustomCones.Weapons[ "weapon_smg1" ]            = WeaponVector( 0.04362, true ) // HL2 SMG1
CustomCones.Weapons[ "weapon_ar2" ]                     = WeaponVector( 0.02618, true ) // HL2 AR2
CustomCones.Weapons[ "weapon_shotgun" ]         = WeaponVector( 0.08716, true ) // HL2 SHOTGUN
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end
           
function DoVHNospread( ucmd, angle )
if GetConVarNumber( "vh_nospread" ) >= 1 then
        local ply = LocalPlayer()
               
        cmd2, seed = abc_ucmd_getperdicston( ucmd )
        if ( cmd2 != 0 ) then currentseed = seed end
       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )
                       
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )
                       
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1
                               
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle()
  end
end

--TriggerBot--
function TriggerBot()
local Eye = LocalPlayer():GetEyeTrace().Entity
if GetConVarNumber( "vh_trigger" ) >= 1 then
if (Eye:IsNPC() or Eye:IsPlayer()) then
RunConsoleCommand("+attack")
else
timer.Simple(0.50, function()
RunConsoleCommand("-attack")
                        end)
                end
        end
                end
 
hook.Add("Think", "Test", TriggerBot)






















