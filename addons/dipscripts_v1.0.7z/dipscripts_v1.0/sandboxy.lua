--[[
	EXECUTABLE_PATH/scripts/l/sandboxy.lua [#483 (#492), 3871946763, UID:1406500439]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:18AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

-- This is the file where I try stuff out. (Such as badly documented functions, etc...)


MsgC(Color(0,255,0), "\ndips Sandbox initialized!\n")