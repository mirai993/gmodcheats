--[[
	EXECUTABLE_PATH/scripts/l/fovchanger.lua [#1023 (#1062), 428938388, UID:1210597734]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 05:11:27AM]
	===BadFile===
]]

--[[
Script by dip. (STEAM_0:0:30422103)
Modified and improved by Ott (STEAM_0:0:36527860)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]
CreateClientConVar("dip_fov", 0)

local newfov =  GetConVarNumber("dip_fov")

local function fov(ply, ori, ang, fov, nz, fz)
	local view = {}

	view.origin = ori
	view.angles = ang
	view.fov = newfov

	return view
end


-- preperation
hook.Remove("CalcView", "fov")
timer.Simple(1, function()
if GetConVarNumber("dip_fov") != 0 then
	hook.Add("CalcView", "fov", fov)
end
end)
-- end of prep

cvars.AddChangeCallback("dip_fov", function() 
	newfov = GetConVarNumber("dip_fov")
	if newfov != 0 then
		hook.Add("CalcView", "fov", fov)
	else
		hook.Remove("CalcView", "fov")
	end
end)

MsgC(Color(0,255,0), "\ndip's FOV changer initialized!\n")