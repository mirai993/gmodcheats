--[[
	EXECUTABLE_PATH/scripts/l/anti-falldamage.lua [#1473 (#1520), 2315062272, UID:1310693835]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 05:11:23AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_stopfalldmg_prop",  "models/props_trainstation/trainstation_post001.mdl")

local toggler = 0
local ang
local view = {}
local function falldamage()
	hook.Add("CreateMove", "anti-falldmg", function(cmd)

		ang = cmd:GetViewAngles()
		if toggler == 0 then
			oriang = ang
			toggler = 1
			hook.Add("CalcView", "FlyCam", function(ply, ori, ang, fov, nz, fz)
				view.origin = ori
				view.angles = Angle(30, ang.yaw,0)
				view.fov = fov

 				return view	
			end)
		end
		cmd:SetViewAngles(Angle(90, ang.yaw, 0))

		local trace = LocalPlayer():GetEyeTrace()
		if trace.HitWorld then
			if LocalPlayer():GetPos():Distance(trace.HitPos) < 25 then
				hook.Remove("CreateMove", "anti-falldmg")
				RunConsoleCommand("gm_spawn", GetConVarString("dip_stopfalldmg_prop"))
				view.angles = view.angles or Angle(30, ang.yaw, 0)
				cmd:SetViewAngles(view.angles)
				hook.Remove("CalcView", "FlyCam")
				toggler = 0
				timer.Simple(.1, function()
					RunConsoleCommand("undo")
				end)
			end
		end
	end)
end

concommand.Add("dip_stopfalldmg", falldamage)

MsgC(Color(0,255,0), "\ndips Anti-Falldmg initialized!\n")