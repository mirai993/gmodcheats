--[[
	EXECUTABLE_PATH/scripts/l/flashlightspam.lua [#944 (#976), 2426215842, UID:1844173418]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 05:11:27AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_flashlightspam", 0)


local function flashspammer(cmd)
	if  input.IsKeyDown(KEY_F) then
		cmd:SetImpulse(100)
	end
 end

-- preperation
hook.Remove("CreateMove", "flashspam")

if GetConVarNumber("dip_flashlightspam") == 1 then
	hook.Add("CreateMove", "flashspam", flashspammer)
end
-- end of prep


cvars.AddChangeCallback("dip_flashlightspam", function() 
	if GetConVarNumber("dip_flashlightspam") == 1 then
		hook.Add("CreateMove", "flashspam", flashspammer)
	else
		hook.Remove("CreateMove", "flashspam")
	end
end)

MsgC(Color(0,255,0), "\ndips Flashlight spam initialized!\n")