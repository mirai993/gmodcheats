--[[
	EXECUTABLE_PATH/scripts/l/hud.lua [#949 (#983), 2944553198, UID:1342388419]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:13AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]

CreateClientConVar("dip_hud", 1)

local w, h = ScrW(), ScrH()

local function hud()
	draw.SimpleText("Speed: "..math.Round(LocalPlayer():GetVelocity():Length()), "Default", w*.5, 0, Color(0,0,0), 1)
end


--prepping
hook.Remove("HUDPaint", "diphud")
timer.Simple(1, function()
if GetConVarNumber("dip_hud") == 1 then
	hook.Add("HUDPaint", "diphud", hud)
end
end)
-- end of prep


cvars.AddChangeCallback("dip_hud", function() 
	if GetConVarNumber("dip_hud") == 1 then
		hook.Add("HUDPaint", "diphud", hud)
	else
		hook.Remove("HUDPaint", "diphud")
	end
end)


MsgC(Color(0,255,0), "\ndips HUD initialized!\n")