--[[
	EXECUTABLE_PATH/scripts/l/b.lua [#743 (#772), 1365095363, UID:3585503937]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:09AM]
	===BadFile===
]]

CreateClientConVar("dip_bhop", 0)

local function bhopper( cmd )
	if cmd:KeyDown(IN_JUMP) and LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP and LocalPlayer():WaterLevel() < 2 then
		local buttonsetter = cmd:GetButtons()
		if !LocalPlayer():IsOnGround() then
			buttonsetter = bit.band(buttonsetter, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttonsetter)
	end
end


hook.Remove("CreateMove", "b")
timer.Simple(1, function()
if GetConVarNumber("dip_bhop") == 1 then
	hook.Add("CreateMove", "b", bhopper)
end
end)


cvars.AddChangeCallback("dip_bhop", function() 
	if GetConVarNumber("dip_bhop") == 1 then
		hook.Add("CreateMove", "b", bhopper)
	else
		hook.Remove("CreateMove", "b")
	end
end)

MsgC(Color(0,255,0), "\ndip Bhop initialized!\n")