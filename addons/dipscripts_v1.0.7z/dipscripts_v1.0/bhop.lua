--[[
	EXECUTABLE_PATH/scripts/l/bhop.lua [#1160 (#1200), 2133055937, UID:737664774]
	Lando Calrissian | STEAM_0:0:13347490 <75.82.0.132:27005> | [27.05.14 04:19:10AM]
	===BadFile===
]]

--[[
dips Scripts by dip. (STEAM_0:0:30422103)
This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/.
Credit to the author must be given when using/sharing this work or derivative work from it.
]]
-- thanks to vexx21322 for help with the bitwise arithmetics

CreateClientConVar("dip_bh", 0)


local function bhper( cmd )
	if cmd:KeyDown(IN_JUMP) and LocalPlayer():GetMoveType() != MOVETYPE_NOCLIP and LocalPlayer():WaterLevel() < 2 then
		local buttonsetter = cmd:GetButtons()
		if !LocalPlayer():IsOnGround() then
			buttonsetter = bit.band(buttonsetter, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttonsetter)
	end
end


-- preperation
hook.Remove("CreateMove", "b")
timer.Simple(1, function()
if GetConVarNumber("dip_bh") == 1 then
	hook.Add("CreateMove", "b", bhper)
end
end)
-- end of prep


cvars.AddChangeCallback("dip_bh", function() 
	if GetConVarNumber("dip_bh") == 1 then
		hook.Add("CreateMove", "b", bhper)
	else
		hook.Remove("CreateMove", "b")
	end
end)

MsgC(Color(0,255,0), "\ndip bh initialized!\n")
