-- Made by rose (duh)
-- MainMenu:SetVisible( false ) 

local scrw = ScrW()
local scrh = ScrH()
local ply = LocalPlayer()
local date = os.date( "%m/%d/%Y" )
local User = nil

local DefTextColor = Color(255, 255, 255)
local WatermarkText = "very epic"
local Verison = "3.0"

-- box color
local Background1 = Color(33, 33, 38)
local TopBar1 = Color(247, 164, 23)

-- pos for watermark
local XPos = 5
local YPos = 5
local XSize = 200
local YSize = 30

-- debug
local DXPos = 10
local DYPos = 60
local DXSize = 200
local DYSize = 200

-- menu
local function rosemenu()

    local MainMenu = vgui.Create( "DFrame" )
    MainMenu:SetSize( 400, 400 ) 
    MainMenu:SetTitle( "RoseHook" ) 
    MainMenu:Center()
    MainMenu:SetDraggable( true ) 
    MainMenu:ShowCloseButton( true ) 
    MainMenu:MakePopup()

    local sheet = vgui.Create( "DPropertySheet", MainMenu )
        sheet:Dock( FILL )

    --aim
        local aim = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Aim", aim, "icon16/mouse.png" )

    --Visuals
        local visuals = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Visuals", visuals, "icon16/color_wheel.png" )

        local bpCheckbox = vgui.Create( "DCheckBoxLabel", visuals )
        bpCheckbox:SetPos( 5, 5 )
        bpCheckbox:SetText("gay esp")
        bpCheckbox:SetValue( false )
        function bpCheckbox:OnChange(ESPChecked)
            if ESPChecked then
                hook.Add("HUDPaint", "ESP", function ()
    
                    for k, v in pairs(player.GetAll()) do
                    
                        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
                        if (v:Alive()) then -- finds out if the player is Alive
            
                            local plypos = v:GetPos() -- gets player position
                            plypos = plypos:ToScreen() -- puts the text in the 3d world
            
                            surface.SetTextColor( 7, 243, 26, 232) -- Set text color. you can make this any color you want.     
                            surface.SetTextPos( plypos.x, plypos.y ) -- Set text position to the player
                            surface.SetFont( "Default" ) -- Set the font
                            surface.DrawText( v:Name() ) -- Gets the name of the player and puts it as the text
            
                        end 
                    end
                end)
            else
                hook.Remove("HUDPaint", "ESP")
            end
        end

    --Misc
        local misc = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Misc", misc, "icon16/cog.png" )

        local bpCheckbox = vgui.Create( "DCheckBoxLabel", misc )
        bpCheckbox:SetPos( 5, 5 )
        bpCheckbox:SetText("bhop")
        bpCheckbox:SetValue( false )
        function bpCheckbox:OnChange(bpChecked)
            if bpChecked then
                hook.Add("CreateMove","omgrealbhopy", function(cmd)
                    if LocalPlayer():KeyDown(IN_JUMP) then
                            cmd:RemoveKey(IN_JUMP)
                    end
                end)
            else
                hook.Remove("CreateMove", "omgrealbhopy")
            end
        end

    --settings

        local settings = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Settings", settings, "icon16/cog.png" )

end

concommand.Add("rosehook_menu", rosemenu)