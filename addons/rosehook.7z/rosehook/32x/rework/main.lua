MsgC(Color(0, 0, 0), [[     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣤⣴⡶⠶⠶⠶⠶⠶⠶⠶⠶⠤⠤⢤⣤⣤⣤⣤⣤⣄⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⠋⠀⠀⠀⠀⢀⣀⠤⠖⠚⢉⣉⣉⣉⣉⣀⠀⠀⠀⠀⠀⠀⠈⠉⠩⠛⠛⠛⠻⠷⣦⣄⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⡿⠋⠀⠀⠀⣀⠤⠒⣉⠤⢒⣊⡉⠠⠤⠤⢤⡄⠈⠉⠉⠀⠂⠀⠀⠐⠂⠀⠉⠉⠉⠉⠂⠀⠙⠻⣶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣰⡿⠁⠀⠀⡠⠊⢀⠔⣫⠔⠊⠁⠀⠀⠀⠀⠀⠀⠙⡄⠀⠀⠀⠀⠀⠘⣩⠋⠀⠀⠀⠉⠳⣄⠀⠀⠀⠈⢻⡇⠀⠀⠀                 _       __            __                  ___ __  __  __        __    _ __ 
⠀⠀⠀⠀⠀⣰⡿⠁⠀⠀⠀⠀⠀⠁⠜⠁⣀⣤⣴⣶⣶⣶⣤⣤⣀⠀⠃⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠈⠆⠀⠀⠀⠸⣧⡀⠀⠀                | |     / /__     ____/ /___     ____ _   / (_) /_/ /_/ /__     / /_  (_) /_
⠀⠀⠀⣠⣾⣿⣥⠤⢄⡀⠀⢠⣤⠔⢠⣾⣿⣿⣿⣿⣿⣯⣄⡈⠙⢿⣦⠀⠀⠀⠀⡀⢀⣤⣶⣿⣿⣿⣿⣿⣦⠀⣀⣀⣀⣀⡙⢿⣦⡀             | | /| / / _ \   / __  / __ \   / __ `/  / / / __/ __/ / _ \   / __ \/ / __/
⠀⣠⡾⣻⠋⢀⣠⣴⠶⠾⢶⣤⣄⡚⠉⠉⠉⠁⣠⣼⠏⠉⠙⠛⠷⡾⠛⠀⠀⠀⠘⠛⢿⡟⠛⠋⠉⠉⠉⠁⠀⠀⠀⠀⠀⠦⣝⠦⡙⣿             | |/ |/ /  __/  / /_/ / /_/ /  / /_/ /  / / / /_/ /_/ /  __/  / /_/ / / /_  
⢰⡟⠁⡇⢠⣾⠋⠀⠀⣼⣄⠉⠙⠛⠷⠶⠶⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣇⠀⠀⠀⠠⣦⣄⣴⡾⢛⡛⠻⠷⠘⡄⢸⣿              |__/|__/\___/   \__,_/\____/   \__,_/  /_/_/\__/\__/_/\___/  /_.___/_/\__/  
⢸⡇⠀⡇⢸⣇⢀⣤⣴⣿⠻⠷⣦⣄⣀⠀⠀⠀⢀⡀⠀⣀⠰⣤⡶⠶⠆⠀⠀⠀⠀⠀⠈⠛⢿⣦⣄⠀⠈⠉⠉⠁⢸⣇⠀⠀⣠⠃⢸⣿
⠸⣿⡀⢇⠘⣿⡌⠁⠈⣿⣆⠀⠀⠉⢻⣿⣶⣦⣤⣀⡀⠀⠀⢻⣦⠰⡶⠿⠶⠄⠀⠀⠀⣠⣾⠿⠟⠓⠦⡄⠀⢀⣾⣿⡇⢈⠡⠔⣿⡟
⠀⠙⢿⣌⡑⠲⠄⠀⠀⠙⢿⣿⣶⣦⣼⣿⣄⠀⠈⠉⠛⠻⣿⣶⣯⣤⣀⣀⡀⠀⠘⠿⠾⠟⠁⠀⠀⢀⣀⣤⣾⣿⢿⣿⣇⠀⠀⣼⡟⠀                                       ____   __             _____            
⠀⠀⠀⠹⣿⣇⠀⠀⠀⠀⠈⢻⣦⠈⠙⣿⣿⣷⣶⣤⣄⣠⣿⠁⠀⠈⠉⠙⢻⡟⠛⠻⠿⣿⠿⠛⠛⢻⣿⠁⢈⣿⣨⣿⣿⠀⢰⡿                                  ____  / __/  / /__________  / / (_)___  ____ _
⠀⠀⠀⠀⠈⢻⣇⠀⠀⠀⠀⠀⠙⢷⣶⡿⠀⠈⠙⠛⠿⣿⣿⣶⣶⣦⣤⣤⣼⣧⣤⣤⣤⣿⣦⣤⣤⣶⣿⣷⣾⣿⣿⣿⡟⠀⢸⡇⠀⠀                               / __ \/ /_   / __/ ___/ __ \/ / / / __ \/ __ `/
⠀⠀⠀⠀⠀⠈⢿⣦⠀⠀⠀⠀⠀⠀⠙⢷⣦⡀⠀⠀⢀⣿⠁⠉⠙⠛⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢸⣷⠀⠀                              / /_/ / __/  / /_/ /  / /_/ / / / / / / / /_/ / 
⠀⠀⠀⠀⠀⠀⠀⠙⢷⣄⠀⢀⡀⠀⣀⡀⠈⠻⢷⣦⣾⡃⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⢹⡟⠉⠉⣿⠏⢡⣿⠃⣾⣷⡿⠁⠀⠘⣿⠀⠀                              \____/_/     \__/_/   \____/_/_/_/_/ /_/\__, /  
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣤⣉⠒⠤⣉⠓⠦⣀⡈⠉⠛⠿⠶⢶⣤⣤⣾⣧⣀⣀⣀⣿⣄⣠⣼⣿⣤⣿⠷⠾⠟⠋⠀⠀⠀⠀⣿⠀⠀                                                                     /____/   
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣶⣄⡉⠒⠤⢌⣑⠲⠤⣀⡀⠀⠀⠀⠈⠍⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⣠⠏⠀⢰⠀⠀⣿⡄⠀                     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠿⢷⣦⣄⡉⠑⠒⠪⠭⢄⣀⣀⠀⠐⠒⠒⠒⠒⠀⠀⠐⠒⠊⠉⠀⢀⡠⠚⠀⠀⢸⡇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⢷⣦⣀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠉⠓⠒⠒⠒⠊⠁⠀⠀⠀⢠⣿⠃⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠛⠛⠷⠶⣶⣦⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣴⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠙⠛⠛⠷⠶⠶⠶⠶⠶⠾⠛⠛⠉⠀⠀⠀⠀⠀

    for the list of all concommands type rose_help
]])

--anti screengrab for lbg and libbys
if _G.dontloadthisshitagain then MsgC("script already running\n") end
local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
-- encoding
function enc(data)
    return ((data:gsub('.', function(x) 
        local r,b='',x:byte()
        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
        return r;
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

local originalbase64encode = util.Base64Encode
util.Base64Encode = function() 
notification.AddLegacy( "ScreenGrab Spoofed", NOTIFY_GENERIC, 2 )
local filegrab = file.Read( "egirls.jpg", "DATA" ) 
local convert = originalbase64encode(filegrab)
print(convert)
return convert
end
_G.dontloadthisshitagain = true
--done with that shit
--Config time
local Cache = {
	ScrW = ScrW(),
	ScrH = ScrH(),
	
	Menu = nil,
	
	LocalPlayer = LocalPlayer(),
	
	_R = debug.getregistry(),
	
	Players = {},
	Entities = {},
	
	EntityClasses = { "prop_physics" },
	
	Colors = {
		Black = Color(0, 0, 0),
	    Red = Color(255, 0, 0),
	    Blue = Color(0, 0, 255),
	    Green = Color(0, 255, 0),
	    Aqua = Color(0, 255, 255),	
	    Pink = Color(255, 0, 200),
	    Crimson = Color(175, 0, 42),
	    Greener = Color(132, 222, 2),
	    Gray = Color(155, 155, 155),
	    Orange = Color(255, 126, 0),
	    Violet = Color(178, 132, 190),
	    RedA = Color(255, 0, 0, 100),		
	    Purple = Color(160, 32, 240),
	    Seafoam = Color(201, 255, 229),
	    White = Color(255, 255, 255),
	    Yellow = Color(255, 255, 0),
	},
	
	NetVars = {
		BuildMode = { "BuildMode","buildmode", "_Kyle_Buildmode", "BuildMode" },
		GodMode = { "has_god" },
		Protected = { "LibbyProtectedSpawn", "SH_SZ.Safe", "spawn_protect", "InSpawnZone" }
	},

	ConVars = {
		cl_sidespeed = GetConVar("cl_sidespeed"),
		cl_forwardspeed = GetConVar("cl_forwardspeed")
	},

    Hooks = {}
}

local Vars = {
	ESP = {
		Player = {
			Enabled = true,
			Name = true,
			Weapon = false,
			Skeleton = false,
			HealthInfo = {
				Enabled = true,
				Amount = true,
				Bar = false
			},
			Flags = false,
		},
	},

    Movement = {
        Bhop = true,    
        AutoStrafe = true,
    },

	CustomFOV = {
        Enabled = true,
        FOV = 116
    },
		
	Crosshair = {
        Enabled = true,
	    Length = 2,
	    Width = 1,
	    Color = Cache.Colors.Red,
    },
}

do -- metatable functions are swag
    local meta_en_g = Cache._R.Entity
    local meta_pl_g = Cache._R.Player
    local meta_wn_g = Cache._R.Weapon

    meta_pl_g.IsInBuildMode = function(self)
        for i = 1, #Cache.NetVars.BuildMode do
            if self:GetNWBool(Cache.NetVars.BuildMode[i], false) then
                return true
            end
        end

        return false
    end

    meta_pl_g.IsInGodMode = function(self)
        if self:HasGodMode() then return true end

        for i = 1, #Cache.NetVars.GodMode do
            if self:GetNWBool(Cache.NetVars.GodMode[i], false) then
                return true
            end
        end

        return false
    end

    meta_pl_g.IsProtected = function(self)
        for i = 1, #Cache.NetVars.Protected do
            if self:GetNWBool(Cache.NetVars.Protected[i], false) then
                return true
            end
        end
        
        return false
    end

    meta_pl_g.IsTargetable = function(self)
        return self ~= Cache.LocalPlayer and self:Alive() and self:Team() ~= TEAM_SPECTATOR and self:GetObserverMode() == 0
    end

    meta_en_g.GetHealthColor = function(self)
        local Max = self:GetMaxHealth()
        local Health = math.Clamp(self:Health(), 0, Max)
        local Percent = Health * (Health / Max)

        if self._LastHealth ~= Health or not self._LastHealthColor then
            self._LastHealth = Health
            self._LastHealthColor = Color(255 - (Percent * 2.55), Percent * 2.55, 0)
        end
            
        return self._LastHealthColor, Percent / Health
    end

    meta_en_g.GetScreenCorners = function(self)
        if not IsValid(self) then
            return 0, 0, 0, 0
        end

        local Mins, Maxs = self:OBBMins(), self:OBBMaxs()

        local Coords = {
            self:LocalToWorld(Mins):ToScreen(),
            self:LocalToWorld(Vector(Mins.x, Maxs.y, Mins.z)):ToScreen(),
            self:LocalToWorld(Vector(Maxs.x, Maxs.y, Mins.z)):ToScreen(),
            self:LocalToWorld(Vector(Maxs.x, Mins.y, Mins.z)):ToScreen(),

            self:LocalToWorld(Maxs):ToScreen(),
            self:LocalToWorld(Vector(Mins.x, Maxs.y, Maxs.z)):ToScreen(),
            self:LocalToWorld(Vector(Mins.x, Mins.y, Maxs.z)):ToScreen(),
            self:LocalToWorld(Vector(Maxs.x, Mins.y, Maxs.z)):ToScreen()
        }

        local Left, Right, Top, Bottom = Coords[1].x, Coords[1].x, Coords[1].y, Coords[1].y

        for _, v in ipairs(Coords) do
            if Left > v.x then Left = v.x end
            if Top > v.y then Top = v.y end
            if Right < v.x then Right = v.x end
            if Bottom < v.y then Bottom = v.y end
        end

        return math.Round(Left), math.Round(Right), math.Round(Top), math.Round(Bottom)
    end

    meta_pl_g.HasValidMoveType = function(self)
        return self:GetMoveType() == MOVETYPE_WALK and not IsValid(self:GetVehicle()) and self:WaterLevel() < 2
    end

    meta_pl_g.IsFriend = function(self)
        if not IsValid(self) then return false end

        return self:GetFriendStatus() == "friend"
    end

    meta_wn_g.GetBase = function(self)
        if not self.Base then return nil end

        return self.Base:lower():Split("_")[1]
    end

    meta_wn_g.IsBasedOnShort = function(self, Base)
        return self:GetBase() == Base
    end

    meta_wn_g.GetWeaponName = function(self)
        local Name = self:GetClass()
        
        if self.GetPrintName then
            local PrintName = self:GetPrintName()

            if PrintName == "<MISSING SWEP PRINT NAME>" then
                return Name
            end

            return language.GetPhrase(PrintName)
        end

        return Name
    end
end