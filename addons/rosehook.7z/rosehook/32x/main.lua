-- Made by rose (duh)
-- MainMenu:SetVisible( false ) 

MsgC(Color(0, 0, 0), [[     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⣤⣤⣤⣴⡶⠶⠶⠶⠶⠶⠶⠶⠶⠤⠤⢤⣤⣤⣤⣤⣤⣄⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⠋⠀⠀⠀⠀⢀⣀⠤⠖⠚⢉⣉⣉⣉⣉⣀⠀⠀⠀⠀⠀⠀⠈⠉⠩⠛⠛⠛⠻⠷⣦⣄⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣠⡿⠋⠀⠀⠀⣀⠤⠒⣉⠤⢒⣊⡉⠠⠤⠤⢤⡄⠈⠉⠉⠀⠂⠀⠀⠐⠂⠀⠉⠉⠉⠉⠂⠀⠙⠻⣶⣄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣰⡿⠁⠀⠀⡠⠊⢀⠔⣫⠔⠊⠁⠀⠀⠀⠀⠀⠀⠙⡄⠀⠀⠀⠀⠀⠘⣩⠋⠀⠀⠀⠉⠳⣄⠀⠀⠀⠈⢻⡇⠀⠀⠀                 _       __            __                  ___ __  __  __        __    _ __ 
⠀⠀⠀⠀⠀⣰⡿⠁⠀⠀⠀⠀⠀⠁⠜⠁⣀⣤⣴⣶⣶⣶⣤⣤⣀⠀⠃⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠈⠆⠀⠀⠀⠸⣧⡀⠀⠀                | |     / /__     ____/ /___     ____ _   / (_) /_/ /_/ /__     / /_  (_) /_
⠀⠀⠀⣠⣾⣿⣥⠤⢄⡀⠀⢠⣤⠔⢠⣾⣿⣿⣿⣿⣿⣯⣄⡈⠙⢿⣦⠀⠀⠀⠀⡀⢀⣤⣶⣿⣿⣿⣿⣿⣦⠀⣀⣀⣀⣀⡙⢿⣦⡀             | | /| / / _ \   / __  / __ \   / __ `/  / / / __/ __/ / _ \   / __ \/ / __/
⠀⣠⡾⣻⠋⢀⣠⣴⠶⠾⢶⣤⣄⡚⠉⠉⠉⠁⣠⣼⠏⠉⠙⠛⠷⡾⠛⠀⠀⠀⠘⠛⢿⡟⠛⠋⠉⠉⠉⠁⠀⠀⠀⠀⠀⠦⣝⠦⡙⣿             | |/ |/ /  __/  / /_/ / /_/ /  / /_/ /  / / / /_/ /_/ /  __/  / /_/ / / /_  
⢰⡟⠁⡇⢠⣾⠋⠀⠀⣼⣄⠉⠙⠛⠷⠶⠶⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣇⠀⠀⠀⠠⣦⣄⣴⡾⢛⡛⠻⠷⠘⡄⢸⣿              |__/|__/\___/   \__,_/\____/   \__,_/  /_/_/\__/\__/_/\___/  /_.___/_/\__/  
⢸⡇⠀⡇⢸⣇⢀⣤⣴⣿⠻⠷⣦⣄⣀⠀⠀⠀⢀⡀⠀⣀⠰⣤⡶⠶⠆⠀⠀⠀⠀⠀⠈⠛⢿⣦⣄⠀⠈⠉⠉⠁⢸⣇⠀⠀⣠⠃⢸⣿
⠸⣿⡀⢇⠘⣿⡌⠁⠈⣿⣆⠀⠀⠉⢻⣿⣶⣦⣤⣀⡀⠀⠀⢻⣦⠰⡶⠿⠶⠄⠀⠀⠀⣠⣾⠿⠟⠓⠦⡄⠀⢀⣾⣿⡇⢈⠡⠔⣿⡟
⠀⠙⢿⣌⡑⠲⠄⠀⠀⠙⢿⣿⣶⣦⣼⣿⣄⠀⠈⠉⠛⠻⣿⣶⣯⣤⣀⣀⡀⠀⠘⠿⠾⠟⠁⠀⠀⢀⣀⣤⣾⣿⢿⣿⣇⠀⠀⣼⡟⠀                                       ____   __             _____            
⠀⠀⠀⠹⣿⣇⠀⠀⠀⠀⠈⢻⣦⠈⠙⣿⣿⣷⣶⣤⣄⣠⣿⠁⠀⠈⠉⠙⢻⡟⠛⠻⠿⣿⠿⠛⠛⢻⣿⠁⢈⣿⣨⣿⣿⠀⢰⡿                                  ____  / __/  / /__________  / / (_)___  ____ _
⠀⠀⠀⠀⠈⢻⣇⠀⠀⠀⠀⠀⠙⢷⣶⡿⠀⠈⠙⠛⠿⣿⣿⣶⣶⣦⣤⣤⣼⣧⣤⣤⣤⣿⣦⣤⣤⣶⣿⣷⣾⣿⣿⣿⡟⠀⢸⡇⠀⠀                               / __ \/ /_   / __/ ___/ __ \/ / / / __ \/ __ `/
⠀⠀⠀⠀⠀⠈⢿⣦⠀⠀⠀⠀⠀⠀⠙⢷⣦⡀⠀⠀⢀⣿⠁⠉⠙⠛⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢸⣷⠀⠀                              / /_/ / __/  / /_/ /  / /_/ / / / / / / / /_/ / 
⠀⠀⠀⠀⠀⠀⠀⠙⢷⣄⠀⢀⡀⠀⣀⡀⠈⠻⢷⣦⣾⡃⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⢹⡟⠉⠉⣿⠏⢡⣿⠃⣾⣷⡿⠁⠀⠘⣿⠀⠀                              \____/_/     \__/_/   \____/_/_/_/_/ /_/\__, /  
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⣤⣉⠒⠤⣉⠓⠦⣀⡈⠉⠛⠿⠶⢶⣤⣤⣾⣧⣀⣀⣀⣿⣄⣠⣼⣿⣤⣿⠷⠾⠟⠋⠀⠀⠀⠀⣿⠀⠀                                                                     /____/   
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠿⣶⣄⡉⠒⠤⢌⣑⠲⠤⣀⡀⠀⠀⠀⠈⠍⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⣠⠏⠀⢰⠀⠀⣿⡄⠀                     
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠿⢷⣦⣄⡉⠑⠒⠪⠭⢄⣀⣀⠀⠐⠒⠒⠒⠒⠀⠀⠐⠒⠊⠉⠀⢀⡠⠚⠀⠀⢸⡇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⢷⣦⣀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠉⠉⠓⠒⠒⠒⠊⠁⠀⠀⠀⢠⣿⠃⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠛⠛⠷⠶⣶⣦⣄⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣴⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠙⠛⠛⠷⠶⠶⠶⠶⠶⠾⠛⠛⠉⠀⠀⠀⠀⠀

    for the list of all concommands type rose_help
]])

--anti screengrab for lbg and libbys
if _G.dontloadthisshitagain then MsgC("script already running\n") end
local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' -- You will need this for encoding/decoding
-- encoding
function enc(data)
    return ((data:gsub('.', function(x) 
        local r,b='',x:byte()
        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
        return r;
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

local originalbase64encode = util.Base64Encode
util.Base64Encode = function() 
notification.AddLegacy( "ScreenGrab Spoofed", NOTIFY_GENERIC, 2 )
local filegrab = file.Read( "egirls.jpg", "DATA" ) 
local convert = originalbase64encode(filegrab)
print(convert)
return convert
end
_G.dontloadthisshitagain = true
--done with that shit

local scrw = ScrW()
local scrh = ScrH()
local ply = LocalPlayer()
local date = os.date( "%m/%d/%Y" )
local ACS = false
local ACS2 = false

local inang = 25
local length = 15
local color = Color(255, 255, 0, 75)

Colors = {
    Black = Color(0, 0, 0),
    Red = Color(255, 0, 0),
    Blue = Color(0, 0, 255),
    Green = Color(0, 255, 0),
    Aqua = Color(0, 255, 255),	
    Pink = Color(255, 0, 200),
    Crimson = Color(175, 0, 42),
    Greener = Color(132, 222, 2),
    Gray = Color(155, 155, 155),
    Orange = Color(255, 126, 0),
    Violet = Color(178, 132, 190),
    RedA = Color(255, 0, 0, 100),		
    Purple = Color(160, 32, 240),
    Seafoam = Color(201, 255, 229),
    White = Color(255, 255, 255),
    Yellow = Color(255, 255, 0),
}

local DefTextColor = Color(255, 255, 255)
local WatermarkText = "RoseHook"
local Verison = "3.5"
local Pubic = false

-- box color
local Background1 = Color(33, 33, 38)
local TopBar1 = Color(247, 164, 23)

-- pos for watermark
local XPos = 5
local YPos = 5
local XSize = 200
local YSize = 30

--other shit
local function getHeadPos(ent)
	if not ent:IsValid() then
		return Vector(0, 0, 0)
	end
	
	local entpos = ent:GetPos()
	local headpos = ent:EyePos()
	
	for i = 0, ent:GetBoneCount() - 1 do
		if string.find(string.lower(ent:GetBoneName(i)), "head") then
			headpos = ent:GetBonePosition(i)
			
			if headpos == entpos then
				headpos = ent:GetBoneMatrix(i):GetTranslation()
			end

			break
		end
	end
	
	return headpos
end

local function drawHat()
	if LocalPlayer():ShouldDrawLocalPlayer() then
		local base = getHeadPos(LocalPlayer()) + Vector(0, 0, 10)
		local ang = Angle(inang, 0, 0)
		
		cam.Start3D()
			for i = 1, 360 do
				if panic then
					cam.End3D()
				end
			
				render.DrawLine(base, base + (ang:Forward() * length), color, false)
				ang.y = ang.y + 1
			end
		cam.End3D()
	end
end

-- menu
local function rosemenu()

    local MainMenu = vgui.Create( "DFrame" )
    MainMenu:SetSize( 400, 400 ) 
    MainMenu:SetTitle( "RoseHook" ) 
    MainMenu:Center()
    MainMenu:SetDraggable( true ) 
    MainMenu:ShowCloseButton( true ) 
    MainMenu:MakePopup()

    local sheet = vgui.Create( "DPropertySheet", MainMenu )
        sheet:Dock( FILL )

    --aim
        local aim = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Aim", aim, "icon16/mouse.png" )

    --Visuals
        local visuals = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Visuals", visuals, "icon16/color_wheel.png" )

        local EsCheckbox = vgui.Create( "DCheckBoxLabel", visuals )
        EsCheckbox:SetPos( 5, 5 )
        EsCheckbox:SetText("name esp")
        EsCheckbox:SetValue( false )
        function EsCheckbox:OnChange(ESPChecked)
            if ESPChecked then
                hook.Add("HUDPaint", "ESP", function ()
    
                    for k, v in pairs(player.GetAll()) do
                    
                        if v == LocalPlayer() then continue end -- if the loop finds the localplayer which is you then it will not set a text for you
                        if (v:Alive()) then -- finds out if the player is Alive
            
                            local plypos = v:GetPos() -- gets player position
                            plypos = plypos:ToScreen() -- puts the text in the 3d world
            
                            surface.SetTextColor( 7, 243, 26, 232) -- Set text color. you can make this any color you want.     
                            surface.SetTextPos( plypos.x, plypos.y ) -- Set text position to the player
                            surface.SetFont( "Default" ) -- Set the font
                            surface.DrawText( v:Name() ) -- Gets the name of the player and puts it as the text
            
                        end 
                    end
                end)
            else
                hook.Remove("HUDPaint", "ESP")
            end
        end
        local CHCheckbox = vgui.Create( "DCheckBoxLabel", visuals )
        CHCheckbox:SetPos( 5, 25 )
        CHCheckbox:SetText("china hat")
        CHCheckbox:SetValue( false )
        function CHCheckbox:OnChange(CHIChecked)
            if CHIChecked then
                hook.Add("HUDPaint", "CHINA", function()
                    drawHat()
                end)
            else
                hook.Remove("HUDPaint", "CHINA")
            end
        end
    --Misc
        local misc = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Misc", misc, "icon16/cog.png" )

        local bpCheckbox = vgui.Create( "DCheckBoxLabel", misc )
        bpCheckbox:SetPos( 5, 5 )
        bpCheckbox:SetText("bhop")
        bpCheckbox:SetValue( false )
        function bpCheckbox:OnChange(bpChecked)
            if bpChecked then
                hook.Add("CreateMove","omgrealbhopy", function(cmd)
                    if LocalPlayer():KeyDown(IN_JUMP) then
                            cmd:RemoveKey(IN_JUMP)
                    end
                end)
            else
                hook.Remove("CreateMove", "omgrealbhopy")
            end
        end

    --settings

        local settings = vgui.Create( "DPanel", sheet )
        sheet:AddSheet( "Settings", settings, "icon16/cog.png" )

end

--autoclicker
concommand.Add("ac_t", function() 
	ACS = not ACS
	print("ACS: " .. tostring(ACS))
end)

hook.Add("CreateMove", "ac", function(cmd)
	if ACS then
		local ply = LocalPlayer()

		if ply:KeyDown(IN_ATTACK) then
			cmd:RemoveKey(IN_ATTACK)
		end
	end
end)

concommand.Add("ac_t2", function() 
	ACS2 = not ACS2
	print("ACS2: " .. tostring(ACS2))
end)

hook.Add("CreateMove", "ac2", function(cmd)
	if ACS2 then
		local ply = LocalPlayer()

		if ply:KeyDown(IN_ATTACK2) then
			cmd:RemoveKey(IN_ATTACK2)
		end
	end
end)

concommand.Add("rice_ang", function(p, c, args)
	args[1] = args[1] or 25
	
	inang = tonumber(args[1])
end)

concommand.Add("rice_len", function(p, c, args)
	args[1] = args[1] or 15
	
	length = tonumber(args[1])
end)

concommand.Add("rice_col", function(p, c, args, argstr)
	argstr = argstr or "255 255 255 75"
	
	color = Color(unpack(string.Split(argstr, " ")))
end)

concommand.Add("rose_help", function()
    MsgC(Colors.Pink, "╔═══════════════════════════════╗\n")
    MsgC(Colors.Pink, "║            RoseHook           ║\n")
    MsgC(Colors.Pink, "╚═══════════════════════════════╝\n")
    MsgC(Colors.Red, "│ rosehook_menu - main menu     │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "│ ac_t - autoclicker (left)     │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "│ ac_t2 - autoclicker (right)   │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "│ rice_ang - angle of the hat   │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "│ rice_len - length of the hat  │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "│ rice_color - color of the hat │\n")
    MsgC(Colors.Red, "│                               │\n")
    MsgC(Colors.Red, "╚───────────────────────────────╝\n")
end)

concommand.Add("rosehook_menu", rosemenu)