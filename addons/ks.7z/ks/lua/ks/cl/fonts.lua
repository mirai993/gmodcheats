--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddFont( Name, Font, Extended, Size, Weight, Blursize, Scanlines, Antialias, Underline, Italic, Strikeout, Symbol, Rotary, Shadow, Additive, Outline )
	
	surface.CreateFont( Name, {
		
		font = Font,
		extended = Extended,
		size = Size,
		weight = Weight,
		blursize = Blursize,
		scanlines = Scanlines,
		antialias = Antialias,
		underline = Underline,
		italic = Italic,
		strikeout = Strikeout,
		symbol = Symbol,
		rotary = Rotary,
		shadow = Shadow,
		additive = Additive,
		outline = Outline
		
	} )
	
end