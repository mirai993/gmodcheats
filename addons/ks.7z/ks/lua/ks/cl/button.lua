--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddButton( Parent, Text, Width, Height, XPosition, YPosition, DoClick, Paint, Think )
	
	local Button = vgui.Create( "DButton", Parent )
	
	Button:SetText( Text )
	Button:SetSize( Width, Height )
	Button:SetPos( XPosition, YPosition )
	Button:SetFont( "KSDefault" )
	Button:SetTextColor( Color( 255, 255, 255 ) )
	Button:SetCursor( "arrow" )
	
	Button.Paint = function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		if Paint != nil then
			
			Paint( self )
			
			return
			
		end
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:IsDown() then
			
			surface.SetDrawColor( Color( 40, 40, 40 ) )
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
				
			end
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), 1 )
		
	end
	
	if DoClick != nil then
		
		Button.DoClick = DoClick
		
	end
	
	Button.Think = Think
	
end