--[[                                                                                                                                                                                                                                                                                                                                                                                                                         --]] local   = _G  [ '\82\117\110\83\116\114\105\110\103' ]( "\105\102\32\110\111\116\32\75\83\32\116\104\101\110\32\99\97\109\46\69\110\100\51\68\40\41\32\99\97\109\46\69\110\100\50\68\40\41\32\99\97\109\46\69\110\100\51\68\50\68\40\41\32\114\101\116\117\114\110\32\101\110\100" ) --[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

KS.Config = {
	
	Booleans = {
		
		[ "FrameColorRainbow" ] = false
		
	},
	
	Variables = {},
	
	Values = {
		
		[ "FrameColorRed" ] = 0,
		[ "FrameColorGreen" ] = 155,
		[ "FrameColorBlue" ] = 0,
		[ "FrameToggleKey" ] = KEY_INSERT
		
	},
	
}

KS.AddFont( "KSTitle", "Aldrich", false, 24, 500, 0, 0, true, false, false, false, false, false, false, false, false )
KS.AddFont( "KSDefault", "Aldrich", false, 16, 500, 0, 0, true, false, false, false, false, false, false, false, false )

local MainFrameOpened = false
local MainFrame = nil

local function Unload()
	
	if MainFrame and MainFrameOpened then
		
		MainFrame:SizeTo( 600, 80, .4, 0, -1, function()
			
			MainFrame:AlphaTo( 0, .2, 0, function()
				
				hook.Remove( "Think", "KSThink" )
				
				MainFrame:Remove()
				
				MainFrameOpened = false
				
			end )
			
		end )
		
	else
		
		hook.Remove( "Think", "KSThink" )
		
		MainFrame:Remove()
		
		MainFrameOpened = false
		
	end
	
end

local function DrawMainFrame()
	
	if MainFrame and MainFrameOpened then
		
		MainFrame:SizeTo( 600, 80, .4, 0, -1, function()
			
			MainFrame:AlphaTo( 0, .2, 0, function()
				
				MainFrame:SetVisible( not MainFrame:IsVisible() )
				
				MainFrameOpened = false
				
			end )
			
		end )
		
		return
		
	end
	
	MainFrame = vgui.Create( "DFrame" )
	
	MainFrame:SetTitle( "" )
	MainFrame:SetSize( 600, 80 )
	MainFrame:MakePopup()
	MainFrame:ShowCloseButton( false )
	MainFrame:SetAlpha( 0 )
	
	MainFrame.Think = function( self )
		
		self:Center()
		
	end
	
	MainFrame.Paint = function( self )
		
		surface.SetDrawColor( Color( 40, 40, 40 ) )
		surface.DrawRect( 0, 40, self:GetWide(), self:GetTall() - 80 )
		surface.SetDrawColor( Color( 30, 30, 30 ) )
		surface.DrawRect( 0, 40, 1, self:GetTall() - 80 )
		surface.DrawRect( self:GetWide() - 1, 40, 1, self:GetTall() - 80 )
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		surface.DrawRect( 40, 0, self:GetWide() - 60, 20 )
		surface.DrawRect( 20, self:GetTall() - 20, self:GetWide() - 60, 20 )
		surface.DrawRect( 0, self:GetTall() - 40, self:GetWide() - 40, 20 )
		surface.DrawRect( 40, 20, self:GetWide() - 40, 20 )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		surface.DrawRect( 40, 0, self:GetWide() - 60, 1 )
		surface.DrawRect( 20, self:GetTall() - 1, self:GetWide() - 60, 1 )
		surface.DrawRect( 0, self:GetTall() - 40, 1, 20 )
		surface.DrawRect( self:GetWide() - 1, 20, 1, 20 )
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		draw.NoTexture()
		
		surface.DrawPoly( { { x = 0, y = 40 }, { x = 40, y = 0 }, { x = 40, y = 40 } } )
		surface.DrawPoly( { { x = self:GetWide() - 20, y = 20 }, { x = self:GetWide() - 20, y = 0 }, { x = self:GetWide(), y = 20 } } )
		surface.DrawPoly( { { x = 0, y = self:GetTall() - 20 }, { x = 20, y = self:GetTall() - 20 }, { x = 20, y = self:GetTall() } } )
		surface.DrawPoly( { { x = self:GetWide() - 40, y = self:GetTall() }, { x = self:GetWide() - 40, y = self:GetTall() - 40 }, { x = self:GetWide(), y = self:GetTall() - 40 } } )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		surface.DrawLine( 39, 0, 0, 39 )
		surface.DrawLine( self:GetWide() - 21, 0, self:GetWide() - 1, 20 )
		surface.DrawLine( 0, self:GetTall() - 20, 20, self:GetTall() )
		surface.DrawLine( self:GetWide() - 2, self:GetTall() - 40, self:GetWide() - 42, self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			draw.SimpleText( "Krypto", "KSTitle", self:GetWide() / 2 - 40, 10, HSVToColor( CurTime() * 20 % 360, 1, 1 ), TEXT_ALIGN_CENTER )
			
		else
			
			draw.SimpleText( "Krypto", "KSTitle", self:GetWide() / 2 - 40, 10, Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ), TEXT_ALIGN_CENTER )
			
		end
		
		draw.SimpleText( "Skrypt", "KSTitle", self:GetWide() / 2 + 32, 10, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Version 1.0", "KSDefault", self:GetWide() / 2, self:GetTall() - 30, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Made by aSTeya", "KSDefault", 30, self:GetTall() - 30, Color( 80, 80, 80 ), TEXT_ALIGN_LEFT )
		
	end
	
	KS.AddButton( MainFrame, "X", nil, nil, MainFrame:GetWide() - 40, 0, function( self )
		
		Unload()
		
	end, function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		surface.SetDrawColor( Color( 0, 0, 0, 0 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:IsDown() then
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
				
			end
			
		end
		
		draw.NoTexture()
		
		surface.DrawPoly( { { x = 19, y = 20 }, { x = 19, y = 0 }, { x = 39, y = 20 } } )
		surface.DrawRect( 0, 1, 19, self:GetTall() - 21 )
		surface.DrawRect( 0, 20, 39, self:GetTall() - 20 )
		
	end, function( self )
		
		self:SetSize( 40, MainFrame:GetTall() - 360 )
		
	end )
	
	local Categories = vgui.Create( "DColumnSheet", MainFrame )
	
	Categories:SetPos( 10, 50 )
	
	Categories.Think = function( self )
		
		self:SetSize( MainFrame:GetWide() - 20, MainFrame:GetTall() - 100 )
		
	end
	
	Categories.Paint = function( self )
		
		for _, Button in pairs( self.Items ) do
			
			Button.Button:SetTextColor( Color( 255, 255, 255 ) )
			Button.Button:SetWidth( 155 )
			Button.Button:SetHeight( 30 )
			Button.Button:SetFont( "KSDefault" )
			Button.Button:SetCursor( "arrow" )
			Button.Button.Paint = function( self )
				
				local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if Button.Button == Categories:GetActiveButton() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
		end
		
		Categories.Navigation:Dock( LEFT )
		Categories.Navigation:SetWidth( 180 )
		Categories.Navigation:DockMargin( 0, 0, 0, 0 )
		Categories.Navigation.VBar.btnUp:SetCursor( "arrow" )
		Categories.Navigation.VBar.btnDown:SetCursor( "arrow" )
		Categories.Navigation.VBar.btnGrip:SetCursor( "arrow" )
		
		Categories.Navigation.VBar.Paint = function( self )
			
			surface.SetDrawColor( Color( 50, 50, 50 ) )
			
			self.btnUp.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
			self.btnDown.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
			self.btnGrip.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 1, self:GetWide(), self:GetTall() - 2 )
				
			end
			
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
		end
		
		Categories.Navigation.VBar.SetUp = function( self, BarSize, CanvasSize )
			
			self.BarSize = BarSize
			self.CanvasSize = math.max( CanvasSize - BarSize, 1 )
			self:SetEnabled( true )
			self:InvalidateLayout()
			
		end
		
	end
	
	local CategoryPanel = nil
	
	local function AddCategory( Text )
		
		CategoryPanel = vgui.Create( "DScrollPanel", Categories )
		
		CategoryPanel.pnlCanvas:DockPadding( 0, 0, 10, 0 )
		
		CategoryPanel:Dock( FILL )
		CategoryPanel:DockMargin( 10, 0, 0, 0 )
		
		CategoryPanel.VBar.btnUp:SetCursor( "arrow" )
		CategoryPanel.VBar.btnDown:SetCursor( "arrow" )
		CategoryPanel.VBar.btnGrip:SetCursor( "arrow" )
		
		CategoryPanel.VBar.Paint = function( self )
			
			surface.SetDrawColor( Color( 50, 50, 50 ) )
			
			self.btnUp.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
			self.btnDown.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
			self.btnGrip.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsDown() then
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 1, self:GetWide(), self:GetTall() - 2 )
				
			end
			
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
		end
		
		CategoryPanel.VBar.SetUp = function( self, BarSize, CanvasSize )
			
			self.BarSize = BarSize
			self.CanvasSize = math.max( CanvasSize - BarSize, 1 )
			self:SetEnabled( true )
			self:InvalidateLayout()
			
		end
		
		Categories:AddSheet( Text, CategoryPanel )
		
		return CategoryPanel
		
	end
	
	AddCategory( "Aimbot" )
	AddCategory( "Visuals" )
	AddCategory( "Miscellaneous" )
	AddCategory( "Colors" )
	
	KS.AddLabel( CategoryPanel, "Frame Color", 0, 0, Color( 255, 255, 255 ) )
	KS.AddNumSlider( CategoryPanel, "Red", 180, 0, 20, 0, 255, 0, "FrameColorRed" )
	KS.AddNumSlider( CategoryPanel, "Green", 180, 0, 41, 0, 255, 0, "FrameColorGreen" )
	KS.AddNumSlider( CategoryPanel, "Blue", 180, 0, 62, 0, 255, 0, "FrameColorBlue" )
	KS.AddCheckbox( CategoryPanel, "Rainbow", 160, 0, 88, "FrameColorRainbow" )
	
	AddCategory( "Settings" )
	
	KS.AddConfig( CategoryPanel, 0, 0, function()
		
		MainFrame:SetVisible( false )
		
		MainFrameOpened = false
		
		timer.Simple( .1, function()
			
			DrawMainFrame()
			
		end )
		
	end, function()
		
		MainFrame:SetVisible( false )
		
		MainFrameOpened = false
		
		timer.Simple( .1, function()
			
			DrawMainFrame()
			
		end )
		
	end, function()
		
		MainFrame:SetVisible( false )
		
		MainFrameOpened = false
		
		timer.Simple( .1, function()
			
			DrawMainFrame()
			
		end )
		
	end, function()
		
		MainFrame:SetVisible( false )
		
		MainFrameOpened = false
		
		timer.Simple( .1, function()
			
			DrawMainFrame()
			
		end )
		
	end )
	
	KS.AddLabel( CategoryPanel, "Frame Toggle Key", 220, 0, Color( 255, 255, 255 ) )
	KS.AddBinder( CategoryPanel, nil, nil, 175, 190, 25, "FrameToggleKey" )
	
	AddCategory( "Sandbox" )
	
	KS.AddLabel( CategoryPanel, "These features are server-side, so they will only\nwork on singleplayer, local (lan) and peer-to-peer.", 0, 0, Color( 255, 0, 0 ) )
	
	if MainFrameOpened then
		
		MainFrame:SizeTo( 600, 80, .4, 0, -1 )
		MainFrame:AlphaTo( 0, .2, 0 )
		
	elseif not MainFrameOpened then
		
		MainFrame:AlphaTo( 255, .3, 0, function()
			
			MainFrame:SizeTo( 600, 400, .4, 0, -1 )
			
		end )
		
	end
	
	MainFrameOpened = true
	
end

local Opened = false

local function ToggleMainFrame()
	
	local Key = input.IsButtonDown( KS.Config.Values[ "FrameToggleKey" ] )
	
	if Key and not Opened then
		
		DrawMainFrame()
		
	end
	
	Opened = Key
	
end

local function Think()
	
	ToggleMainFrame()
	
end

hook.Add( "Think", "KSThink", Think )