--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddTextEntry( Parent, Text, Width, XPosition, YPosition, Numeric, Variable )
	
	local TextEntry = vgui.Create( "DTextEntry", Parent )
	
	TextEntry:SetSize( Width, 20 )
	TextEntry:SetPos( XPosition, YPosition )
	TextEntry:SetTextColor( Color( 255, 255, 255 ) )
	TextEntry:SetFont( "KSDefault" )
	TextEntry:SetNumeric( Numeric )
	TextEntry:SetCursor( "arrow" )
	
	if KS.Config.Variables[ Variable ] != nil then
		
		TextEntry:SetText( KS.Config.Variables[ Variable ] )
		
	else
		
		TextEntry:SetText( Text )
		
	end
	
	TextEntry.OnGetFocus = function( self )
		
		hook.Run( "OnTextEntryGetFocus", self )
		
		if self:GetText() == Text then
			
			self:SetText( "" )
			
		end
		
	end
	
	TextEntry.OnLoseFocus = function( self )
		
		self:UpdateConvarValue()
		
		hook.Call( "OnTextEntryLoseFocus", nil, self )
		
		if self:GetText() == "" then
			
			self:SetText( Text )
			
			KS.Config.Variables[ Variable ] = nil
			
		else
			
			KS.Config.Variables[ Variable ] = self:GetText()
			
		end
		
	end
	
	TextEntry.Paint = function( self )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:IsEditing() then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			self:DrawTextEntryText( Color( 255, 255, 255 ), HSVToColor( CurTime() * 20 % 360, 1, 1 ), Color( 255, 255, 255 ) )
			
		else
			
			self:DrawTextEntryText( Color( 255, 255, 255 ), Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ), Color( 255, 255, 255 ) )
			
		end
		
	end
	
end