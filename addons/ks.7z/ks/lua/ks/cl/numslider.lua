--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddNumSlider( Parent, Text, Width, XPosition, YPosition, Min, Max, Decimals, Value )
	
	local NumSlider = vgui.Create( "DNumSlider", Parent )
	
	NumSlider:SetText( "" )
	NumSlider:SetSize( Width, 20 )
	NumSlider:SetPos( XPosition, YPosition )
	NumSlider:SetMin( Min )
	NumSlider:SetMax( Max )
	NumSlider:SetDecimals( Decimals )
	NumSlider:SetValue( KS.Config.Values[ Value ] )
	
	NumSlider.Slider.Knob:SetCursor( "arrow" )
	NumSlider.TextArea:SetVisible( false )
	NumSlider.Label:SetVisible( false )
	NumSlider.Scratch:SetVisible( false )
	
	NumSlider.OnValueChanged = function( self, Val )
		
		KS.Config.Values[ Value ] = math.Round( Val, Decimals )
		
	end
	
	NumSlider.Paint = function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered or self.Slider.Hovered or self.Slider.Knob.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		self.Slider.Paint = function( self )
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
				
			end
			
			surface.DrawRect( 0, 0, math.ceil( NumSlider:GetValue() * self:GetWide() / Max ), self:GetTall() )
			
			draw.SimpleText( NumSlider.TextArea:GetText(), "KSDefault", self:GetWide() - 5, 4, Color( 255, 255, 255 ), TEXT_ALIGN_RIGHT )
			
		end
		
		self.Slider.Knob.Paint = function( self )
		end
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		surface.DrawOutlinedRect( 0, 0, self:GetWide(), 1 )
		
	end
	
	KS.AddLabel( Parent, Text, XPosition + 5, YPosition + 4, Color( 255, 255, 255 ) )
	
end