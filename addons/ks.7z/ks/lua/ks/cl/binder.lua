--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddBinder( Parent, Text, TextWidth, Width, XPosition, YPosition, Value )
	
	local Binder = vgui.Create( "DBinder", Parent )
	
	Binder:SetSize( Width, 20 )
	Binder:SetValue( KS.Config.Values[ Value ] or KEY_NONE )
	Binder:SetTextColor( Color( 255, 255, 255 ) )
	Binder:SetFont( "KSDefault" )
	
	Binder.Paint = function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:GetText() == "Press any key..." then
			
			surface.SetDrawColor( Color( 40, 40, 40 ) )
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
				
			end
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), 1 )
		
	end
	
	Binder.OnChange = function( self, Val )
		
		KS.Config.Values[ Value ] = self:GetValue()
		
	end
	
	if Text != nil and TextWidth != nil then
		
		Binder:SetPos( XPosition + TextWidth, YPosition	)
		
		KS.AddLabel( Parent, Text, XPosition, YPosition + 2, Color( 255, 255, 255 ) )
		
	else
		
		Binder:SetPos( XPosition, YPosition	)
		
	end
	
end