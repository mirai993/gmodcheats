--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddConfig( Parent, XPosition, YPosition, Create, Save, Load, Delete )
	
	local ListView = vgui.Create( "DListView", Parent )
	
	ListView:SetSize( 181, 140 )
	ListView:SetPos( XPosition, YPosition )
	ListView:AddColumn( "Configs" )
	ListView:SetMultiSelect( false )
	
	ListView.Paint = function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		surface.SetDrawColor( Color( 50, 50, 50 ) )
		surface.DrawRect( 0, 0, self:GetWide() - 17, self:GetTall() )
		
		for _, Line in pairs( self:GetLines() ) do 
			
			Line.Paint = function( self )
			end
			
			for _, Column in pairs( Line[ "Columns" ] ) do
				
				Column:SetFont( "KSDefault" )
				Column:SetTextColor( Color( 255, 255, 255 ) )
				
			end
			
		end
		
		for _, Column in pairs( self.Columns ) do 
			
			Column:SetWidth( 164 )
			Column.Header:SetCursor( "arrow" )
			Column.Header:SetFont( "KSDefault" )
			Column.Header:SetTextColor( Color( 255, 255, 255 ) )
			Column.Header.Paint = function( self )
			end
			
			Column.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
		end
		
		for _, Sort in pairs( self.Sorted ) do 
			
			Sort.Paint = function( self )
				
				surface.SetDrawColor( Color( 60, 60, 60 ) )
				
				if self.Hovered then
					
					surface.SetDrawColor( Color( 80, 80, 80 ) )
					
				end
				
				if self:IsSelected() then
					
					surface.SetDrawColor( Color( 40, 40, 40 ) )
					surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
					
					if KS.Config.Booleans[ "FrameColorRainbow" ] then
						
						surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
						
					else
						
						surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
						
					end
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() - 1 )
				
			end
			
		end
		
	end
	
	ListView.DataLayout = function( self )
		
		local XPosition = 1
		local Height = self.m_iDataHeight
		
		for _, Line in ipairs( self.Sorted ) do
			
			Line:SetPos( 0, XPosition )
			Line:SetSize( self:GetWide() - 17, Height )
			Line:DataLayout( self )
			Line:SetAltLine( _ % 2 == 1 )
			
			XPosition = XPosition + Line:GetTall()
			
		end
		
		return XPosition
		
	end
	
	ListView.VBar.btnUp:SetCursor( "arrow" )
	ListView.VBar.btnDown:SetCursor( "arrow" )
	ListView.VBar.btnGrip:SetCursor( "arrow" )
	
	ListView.VBar.Paint = function( self )
		
		surface.SetDrawColor( Color( 50, 50, 50 ) )
		
		self.btnUp.Paint = function( self )
			
			surface.SetDrawColor( Color( 60, 60, 60 ) )
			
			if self.Hovered then
				
				surface.SetDrawColor( Color( 80, 80, 80 ) )
				
			end
			
			if self:IsDown() then
				
				if KS.Config.Booleans[ "FrameColorRainbow" ] then
					
					surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
					
				else
					
					surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
					
				end
				
			end
			
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
		end
		
		self.btnDown.Paint = function( self )
			
			surface.SetDrawColor( Color( 60, 60, 60 ) )
			
			if self.Hovered then
				
				surface.SetDrawColor( Color( 80, 80, 80 ) )
				
			end
			
			if self:IsDown() then
				
				if KS.Config.Booleans[ "FrameColorRainbow" ] then
					
					surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
					
				else
					
					surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
					
				end
				
			end
			
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
		end
		
		self.btnGrip.Paint = function( self )
			
			surface.SetDrawColor( Color( 60, 60, 60 ) )
			
			if self.Hovered then
				
				surface.SetDrawColor( Color( 80, 80, 80 ) )
				
			end
			
			if self:IsDown() then
				
				if KS.Config.Booleans[ "FrameColorRainbow" ] then
					
					surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
					
				else
					
					surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
					
				end
				
			end
			
			surface.DrawRect( 0, 1, self:GetWide(), self:GetTall() - 2 )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	
	ListView.VBar.SetUp = function( self, BarSize, CanvasSize )
		
		self.BarSize = BarSize
		self.CanvasSize = math.max( CanvasSize - BarSize, 1 )
		self:SetEnabled( true )
		self:InvalidateLayout()
		
	end
	
	local Path = "ks/"
	local Files = file.Find( Path .. "*.txt", "DATA" )
	
	if #Files > 0 then
		
		for _, File in pairs( Files ) do
			
			ListView:AddLine( File )
			
		end
		
	end
	
	local TextEntry = vgui.Create( "DTextEntry", Parent )
	
	TextEntry:SetText( "my_config" )
	TextEntry:SetSize( 90, 20 )
	TextEntry:SetPos( XPosition, YPosition + 141 )
	TextEntry:SetTextColor( Color( 255, 255, 255 ) )
	TextEntry:SetFont( "KSDefault" )
	TextEntry:SetCursor( "arrow" )
	
	TextEntry.OnGetFocus = function( self )
		
		if self:GetText() == "my_config" then
			
			self:SetText( "" )
			
		end
		
	end
	
	TextEntry.OnLoseFocus = function( self )
		
		if self:GetText() == "" then
			
			self:SetText( "my_config" )
			
		else
			
			self:GetText()
			
		end
		
	end
	
	TextEntry.Paint = function( self )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:IsEditing() then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			self:DrawTextEntryText( Color( 255, 255, 255 ), HSVToColor( CurTime() * 20 % 360, 1, 1 ), Color( 255, 255, 255 ) )
			
		else
			
			self:DrawTextEntryText( Color( 255, 255, 255 ), Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ), Color( 255, 255, 255 ) )
			
		end
		
	end
	
	KS.AddButton( Parent, "Create", 90, 20, XPosition + 91, YPosition + 141, function( self )
		
		if not file.Exists( "ks", "DATA" ) then
			
			file.CreateDir( "ks" )
			
		end
		
		if TextEntry:GetValue() == "" or TextEntry:GetValue() == "my_config" then
			
			return
			
		end
		
		file.Write( Path .. TextEntry:GetValue() .. ".txt", util.TableToJSON( KS.Config ) )
		
		if Create != nil then
			
			Create()
			
		end
		
	end, Paint, Think )
	
	KS.AddButton( Parent, "Save", 90, 20, XPosition, YPosition + 162, function( self )
		
		if not file.Exists( "ks", "DATA" ) then
			
			file.CreateDir( "ks" )
			
		end
		
		if not ListView:GetSelectedLine() then
			
			return
			
		end
		
		file.Write( Path .. ListView:GetLine( ListView:GetSelectedLine() ):GetColumnText( 1 ), util.TableToJSON( KS.Config ) )
		
		if Save != nil then
			
			Save()
			
		end
		
	end, Paint, Think )
	
	KS.AddButton( Parent, "Load", 90, 20, XPosition + 91, YPosition + 162, function( self )
		
		if not file.Exists( "ks", "DATA" ) then
			
			return
			
		end
		
		if not ListView:GetSelectedLine() then
			
			return
			
		end
		
		KS.Config = util.JSONToTable( file.Read( Path .. ListView:GetLine( ListView:GetSelectedLine() ):GetColumnText( 1 ), "DATA" ) )
		
		if Load != nil then
			
			Load()
			
		end
		
	end, Paint, Think )
	
	KS.AddButton( Parent, "Delete", 181, 20, XPosition, YPosition + 183, function( self )
		
		if not file.Exists( "ks", "DATA" ) then
			
			return
			
		end
		
		if not ListView:GetSelectedLine() then
			
			return
			
		end
		
		file.Delete( Path .. ListView:GetLine( ListView:GetSelectedLine() ):GetColumnText( 1 ) )
		
		if Delete != nil then
			
			Delete()
			
		end
		
	end, Paint, Think )
	
end