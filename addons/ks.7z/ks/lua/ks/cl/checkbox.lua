--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddCheckbox( Parent, Text, Width, XPosition, YPosition, Boolean )
	
	local CheckBox = vgui.Create( "DCheckBox", Parent )
	
	CheckBox:SetPos( XPosition + Width, YPosition )
	CheckBox:SetChecked( KS.Config.Booleans[ Boolean ] )
	CheckBox:SetCursor( "arrow" )
	CheckBox:SetSize( 20, 20 )
	
	CheckBox.OnChange = function( self )
		
		KS.Config.Booleans[ Boolean ] = self:GetChecked()
		
	end
	
	CheckBox.Paint = function( self )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:GetChecked() then
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
				
			end
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
	end
	
	KS.AddLabel( Parent, Text, XPosition, YPosition + 2, Color( 255, 255, 255 ) )
	
end