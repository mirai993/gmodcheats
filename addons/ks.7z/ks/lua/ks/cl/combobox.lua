--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

function KS.AddComboBox( Parent, Text, TextWidth, Width, XPosition, YPosition, Variable, Variables )
	
	local ComboBox = vgui.Create( "DComboBox", Parent )
	
	ComboBox:SetSize( Width, 20 )
	
	if KS.Config.Variables[ Variable ] != nil then
		
		ComboBox:SetValue( KS.Config.Variables[ Variable ] )
		
	else
		
		ComboBox:SetValue( Variables[ 1 ] )
		
	end
	
	ComboBox:SetTextColor( Color( 255, 255, 255 ) )
	ComboBox:SetFont( "KSDefault" )
	
	ComboBox.DropButton:SetVisible( false )
	
	for k, v in pairs( Variables ) do
		
		ComboBox:AddChoice( v )
		
	end
	
	ComboBox.Paint = function( self )
		
		local ColorRainbow = HSVToColor( CurTime() * 20 % 360, 1, 1 )
		
		surface.SetDrawColor( Color( 60, 60, 60 ) )
		
		if self.Hovered then
			
			surface.SetDrawColor( Color( 80, 80, 80 ) )
			
		end
		
		if self:IsMenuOpen() then
			
			surface.SetDrawColor( Color( 40, 40, 40 ) )
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
			
			if KS.Config.Booleans[ "FrameColorRainbow" ] then
				
				surface.SetDrawColor( Color( ColorRainbow.r, ColorRainbow.g, ColorRainbow.b, 55 ) )
				
			else
				
				surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ], 55 ) )
				
			end
			
		end
		
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		if KS.Config.Booleans[ "FrameColorRainbow" ] then
			
			surface.SetDrawColor( HSVToColor( CurTime() * 20 % 360, 1, 1 ) )
			
		else
			
			surface.SetDrawColor( Color( KS.Config.Values[ "FrameColorRed" ], KS.Config.Values[ "FrameColorGreen" ], KS.Config.Values[ "FrameColorBlue" ] ) )
			
		end
		
		draw.NoTexture()
		
		surface.DrawPoly( { { x = self:GetWide() - 15, y = 5 }, { x = self:GetWide() - 5, y = 5 }, { x = self:GetWide() - 10, y = 15 } } )
		
	end
	
	ComboBox.DoClick = function( self )
		
		if self:IsMenuOpen() then
			
			return self:CloseMenu()
			
		end
		
		self:OpenMenu()
		
		for _, Choice in pairs( self.Menu:GetCanvas():GetChildren() ) do
			
			Choice:SetTextColor( Color( 255, 255, 255 ) )
			Choice:SetFont( "KSDefault" )
			
			Choice.Paint = function( self )
				
				surface.SetDrawColor( 60, 60, 60 )
				
				if self.Hovered then
					
					surface.SetDrawColor( 80, 80, 80 )
					
				end
				
				surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
				
			end
			
		end
		
	end
	
	ComboBox.OnSelect = function( self, Value, Data )
		
		KS.Config.Variables[ Variable ] = self:GetSelected()
		
	end
	
	if Text != nil and TextWidth != nil then
		
		ComboBox:SetPos( XPosition + TextWidth, YPosition )
		
		KS.AddLabel( Parent, Text, XPosition, YPosition + 2, Color( 255, 255, 255 ) )
		
	else
		
		ComboBox:SetPos( XPosition, YPosition )
		
	end
	
end