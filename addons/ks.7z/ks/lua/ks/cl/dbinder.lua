--[[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
--]]

local Parent = Parent or {}

AccessorFunc( Parent, "m_iSelectedNumber", "SelectedNumber" )

Derma_Install_Convar_Functions( Parent )

function Parent:Init()
	
	self:SetSelectedNumber( 0 )
	self:SetSize( 60, 30 )
	
end

function Parent:UpdateText()
	
	local String = input.GetKeyName( self:GetSelectedNumber() )
	
	if not String then String = "None" end
	
	String = language.GetPhrase( String )
	
	self:SetText( String )
	
end

function Parent:DoClick()
	
	self:SetText( "Press any key..." )
	
	input.StartKeyTrapping()
	
	self.Trapping = true
	
end

function Parent:DoRightClick()
	
	self:SetText( "None" )
	self:SetValue( 0 )
	
end

function Parent:SetSelectedNumber( iNum )
	
	self.m_iSelectedNumber = iNum
	self:ConVarChanged( iNum )
	self:UpdateText()
	self:OnChange( iNum )
	
end

function Parent:Think()
	
	if input.IsKeyTrapping() and self.Trapping then
		
		local Code = input.CheckKeyTrapping()
		
		if Code then
			
			if Code == KEY_ESCAPE then
				
				self:SetValue( self:GetSelectedNumber() )
				
			else
				
				self:SetValue( Code )
				
			end
			
			self.Trapping = false
			
		end
		
	end
	
	self:ConVarNumberThink()
	
end

function Parent:SetValue( iNumValue )
	
	self:SetSelectedNumber( iNumValue )
	
end

function Parent:GetValue()
	
	return self:GetSelectedNumber()
	
end

function Parent:OnChange()
end

derma.DefineControl( "DBinder", "A Binder", Parent, "DButton" )