MsgC( Color( 0, 155, 0 ), [[
	
	██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗     ███████╗██╗  ██╗██████╗ ██╗   ██╗██████╗ ████████╗
	██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗    ██╔════╝██║ ██╔╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝
	█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║    ███████╗█████╔╝ ██████╔╝ ╚████╔╝ ██████╔╝   ██║   
	██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║    ╚════██║██╔═██╗ ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   
	██║  ██╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝    ███████║██║  ██╗██║  ██║   ██║   ██║        ██║   
	╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝   
	
]] )

if CLIENT then
	
	KS = KS or {}
	
	local Path1, Path2 = "lua/ks/cl/", "ks/cl/"
	local Files = file.Find( Path1 .. "*.lua", "GAME" )
	
	if #Files > 0 then
		
		for _, File in pairs( Files ) do
			
			include( Path2 .. File )
			
			MsgC( Color( 0, 155, 0 ), "KS", Color( 255, 255, 255 ), ": Included client-side file: ", Color( 0, 155, 0 ), File .. "\n" )
			
		end
		
	end
	
elseif SERVER then
	
	if not KS then
		
		KS = {}
		
		local Path1, Path2 = "lua/ks/cl/", "ks/cl/"
		local Files = file.Find( Path1 .. "*.lua", "GAME" )
		
		if #Files > 0 then
			
			for _, File in pairs( Files ) do
				
				AddCSLuaFile( Path2 .. File )
				
				MsgC( Color( 0, 155, 0 ), "KS", Color( 255, 255, 255 ), ": Included client-side file: ", Color( 0, 155, 0 ), File .. "\n" )
				
			end
			
		end
		
		Path1, Path2 = "lua/ks/sv/", "ks/sv/"
		Files = file.Find( Path1 .. "*.lua", "GAME" )
		
		if #Files > 0 then
			
			for _, File in pairs( Files ) do
				
				include( Path2 .. File )
				
				MsgC( Color( 0, 155, 0 ), "KS", Color( 255, 255, 255 ), ": Included server-side file: ", Color( 0, 155, 0 ), File .. "\n" )
				
			end
			
		end
		
	end
	
end