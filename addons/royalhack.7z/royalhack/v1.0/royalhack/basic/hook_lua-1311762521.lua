--[[
	royalhack/basic/hook.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

function RoyalHack.KillPlayer()

local frags = LocalPlayer():Frags()
	if( Kills < frags ) then
		return true
	else
		return false
	end

end

hook.Add("Think","KillPlayer",RoyalHack.KillPlayer)