--[[
	vgui/HackMenu.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

PANEL = {}
/*

Author: ALL YOU CAN EAT
Version: 1.0 Beta
Build: 24.04.2011 20:16
Info: Erstellt ein Menu das mit der Tastatur bedient werden kann.
*/

AccessorFunc( PANEL, "m_bDeleteOnClose", 	"DeleteOnClose", 	FORCE_BOOL )
AccessorFunc( PANEL, "m_pSelected", 			"Selected", 		FORCE_BOOL ) 		
AccessorFunc( PANEL, "SelectedItems", 			"SelectedItems" ) 	

/*---------------------------------------------------------
   Name: Init
   Info: Dinge die ich f�r das erstellen des Panels und den zusammenhalt
   ben�tige.
---------------------------------------------------------*/

function PANEL:Init()
Keynumber = 2
self.Id = -5 -- -5 ja schei�e wars aus unbekannten Gr�nden f�ngt er nicht bei 0 an sondern bei 5 ):|
self.Items = {}
self.SelectedItems = {}
self.Count = {}
self.spaceing = false
self:SetPaintBackgroundEnabled( false )
self:SetPaintBorderEnabled( false )
label = vgui.Create("DLabel",self)

end

/*---------------------------------------------------------
   Name: Think
   Info: Diese Funktion wird bis ins Unendliche wiederholt.
---------------------------------------------------------*/

function PANEL:Think()

if( input.IsKeyDown(KEY_INSERT) ) then
	self:Close()
	
end

	self:KeyBoardControl() -- abfrage meiner Tastatur Funktion
end

/*---------------------------------------------------------
   Name: Paint
   Info: Hiermit bestimme ich das aussehen meines HackMen�s
---------------------------------------------------------*/

function PANEL:Paint()

draw.RoundedBox(10,0,0,self:GetWide()+5,self:GetTall()+5,Color(173,173,173,100))--out
draw.RoundedBox(3,2,2,self:GetWide()-4,self:GetTall()-4,Color(0,0,0,255))--in
surface.SetDrawColor(255,255,255,100)
surface.DrawRect(5,25,self:GetWide()-10,self:GetTall()-30)
end

/*---------------------------------------------------------
   Name: PaintOver
   Info: Mit dieser Funktion kann ich etwas �ber die Paint-Ebene
	Zeichnen.
---------------------------------------------------------*/

function PANEL:PaintOver()

end

/*---------------------------------------------------------
   Name: PerformLayout
   Info: Mit dieser Funktion kann ich mein Panel in einer bestimmten weise
		 anordnen.(SetPos,SetSize)
---------------------------------------------------------*/

function PANEL:PerformLayout( )



end 

/*---------------------------------------------------------
   Name: SetTitle
   Info: Eine selbst erstellte Funktion in der ich den Namen meines Panels
		 bestimme.
---------------------------------------------------------*/

function PANEL:SetTitle( name )

label:SetText( name )
label:SetPos( 5, 5 )


end


/*---------------------------------------------------------
   Name: SetSpaceing
   Info: Eine selbst erstellte Funktion mit der ich den freigehaltenen Platz 
		 zwischen meinen Objekten An und Aus schalten kann.
---------------------------------------------------------*/

function PANEL:SetSpaceing( bool )

if( bool ) then
	self.spaceing = true
elseif( !bool ) then
	self.spaceing = false
end


end

/*---------------------------------------------------------
   Name: AddPanel
---------------------------------------------------------*/

function PANEL:AddPanel( pnl , id )

pnl:SetParent( self )
table.insert( self.Items, pnl )


end

/*---------------------------------------------------------
   Name: AddItem
   Info: In dieser �u�erst WICHTIGEN Funktion baue ich mein Menu auf
		 und f�ge die Objekte hinzu.
---------------------------------------------------------*/

function PANEL:AddItem( name , cvar)

	local pnl = vgui.Create( "HackOption", self ) -- Objekt //sp�ter erstelle ich noch Kontainer Elemente
	pnl:Name( name )
	pnl:SetConVar( cvar )
	pnl:SetMax(5)
	pnl:SetMin(0)

	
	
--	if ( ffunction ) then pnl.DoClick = funcFunction end 
 
	

	
	local space = 5 

if( self.spaceing == true ) then
	local x, y = 10, 30
	for k, panel in pairs ( self.Items ) do
	
				
			local w = panel:GetWide()
			local h = panel:GetTall()
			 
			y = y + h + space
								pnl:SetPos(x,(y+pnl:GetTall()+space))
								panel:SetPos(x,y)
		--	
		self.Id = self.Id + 1
		Msg("\n"..self.Id.."\n") -- Kontrolle 
		panel:SetId(self.Id)
		Msg("\n"..panel:GetId().."\n") -- Kontrolle 
		end		
	end

		self:AddPanel( pnl , Id )
		self:OnItemAdd( pnl )
	return true	
end

/*---------------------------------------------------------
   Name: Close
   Info: Mit dieser Funktion schlie�e ich das Men� ebenfalls eine selbst
		 erstellte Funktion.(nach Beispiel)
---------------------------------------------------------*/

function PANEL:Close()

	self:SetVisible( false )

	if ( self:GetDeleteOnClose() ) then
		self:Remove()
	end

end

/*---------------------------------------------------------
   Name: SelectItem
   Info: Mit dieser Funktion selektiere ich NUR EIN bestimmtes
		 Objekt.
---------------------------------------------------------*/

function PANEL:SelectItem( item, onlyme )

--	if ( !onlyme && item:GetSelected() ) then return end
	
	// soll eigentlich nicht selectierte Objekte l�schen... ? ka ob das so klappt
	if ( onlyme  ) then
	
		for k, v in pairs( self.SelectedItems ) do
			v:SetSelected( false )
		end
		
		self.SelectedItems = {}
		self.m_pSelected = nil
		
	end
	
	
	self.m_pSelected = item
	item:SetSelected( true )
	table.insert( self.SelectedItems, self.m_pSelected )
	

end

/*---------------------------------------------------------
   Name: KeyBoardControl
   Info: �u�erst h�sslich aber es funktioniert(teilweise)
---------------------------------------------------------*/

function PANEL:KeyBoardControl(pl)
// begrenzer Funktion muss noch geschrieben werden
	if(pl:KeyPressed(KEY_UP)) then
		Keynumber = Keynumber - 1
		self:SelectByID(math.Clamp(Keynumber,0,100)) // /10 da es sonst zu schnell ist also etwas sehr h�ssliches
		Msg(Keynumber.."\n")
	if( pl:KeyPressed(KEY_DOWN)) then
		Keynumber = Keynumber + 1
		self:SelectByID(math.Clamp(Keynumber,0,100))
		Msg(Keynumber.."\n")
	end
	end

end

/*---------------------------------------------------------
   Name: SelectByID
   Info: Hiermit w�hle ich ein Objekt nach der dazu geh�rigen ID aus.
---------------------------------------------------------*/

function PANEL:SelectByID( id )
	for k, panel in pairs( self.Items ) do
		if ( id == panel:GetId()  ) then
			self:SelectItem( panel, true )
		end
	
	end

end

/*---------------------------------------------------------
   Name: OnItemAdd
   Info: Kontroll Funktion
---------------------------------------------------------*/

function PANEL:OnItemAdd( item )

// zum �berschreiben

end



derma.DefineControl( "HackMenu", "A HAX Panel", PANEL, "EditablePanel" )