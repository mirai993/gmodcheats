--[[
	vgui/RAimNode.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

/*

AimNode

*/

local PANEL = {}


AccessorFunc( PANEL, "bSelected", 		"Selected" )


/*---------------------------------------------------------
   Name: Init
---------------------------------------------------------*/
function PANEL:Init()

	self:SetMouseInputEnabled( true )
	self:SetKeyboardInputEnabled( false )
	
	self:SetSize(10,10)


end

/*---------------------------------------------------------
   Name: OnMousePressed
---------------------------------------------------------*/
function PANEL:OnMousePressed()

end

/*---------------------------------------------------------
   Name: DoRightClick
---------------------------------------------------------*/
function PANEL:DoRightClick()

//Overwrite function

end

/*---------------------------------------------------------
   Name: DoLeftClick
---------------------------------------------------------*/
function PANEL:DoLeftClick()

//Overwrite function

end

/*---------------------------------------------------------
   Name: Paint
---------------------------------------------------------*/
function PANEL:Paint()

surface.SetDrawColor(0,0,0,255)
surface.DrawLine(self.GetPos().x,self.GetPos().y,self.GetWide(),self.GetPos().y)
surface.DrawLine(self.GetWide()/2,self.GetPos().y/2,self.GetWide()/2,self.GetPos().y*2)
	
end



/*---------------------------------------------------------
   Name: GenerateExample
---------------------------------------------------------*/
function PANEL:GenerateExample( ClassName, PropertySheet, Width, Height )

end

derma.DefineControl( "RAimNode", "A moveable node", PANEL, "DButton" )