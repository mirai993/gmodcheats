--[[
	vgui/SPanel.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

/*   _                                
    ( )                               
   _| |   __   _ __   ___ ___     _ _ 
 /'_` | /'__`\( '__)/' _ ` _ `\ /'_` )
( (_| |(  ___/| |   | ( ) ( ) |( (_| |
`\__,_)`\____)(_)   (_) (_) (_)`\__,_) 

	DSlider

*/
local PANEL = {}
	AccessorFunc( PANEL, "m_bPaintBackground", 		"PaintBackground" )
AccessorFunc( PANEL, "m_bSizable", 			"Sizable", 			FORCE_BOOL )
AccessorFunc( PANEL, "m_bDeleteOnClose", 	"DeleteOnClose", 	FORCE_BOOL )

/*---------------------------------------------------------
	AccessorFunc( PANEL, "m_bPaintBackground", 		"PaintBackground" )
AccessorFunc( PANEL, "m_bDisabled", 			"Disabled" )
AccessorFunc( PANEL, "m_bgColor", 		"BackgroundColor" )

Derma_Hook( PANEL, "Paint", "Paint", "Panel" )
Derma_Hook( PANEL, "ApplySchemeSettings", "Scheme", "Panel" )
Derma_Hook( PANEL, "PerformLayout", "Layout", "Panel" )
---------------------------------------------------------*/
function PANEL:Init()

	self:SetPaintBackground( true )
	
	// This turns off the engine drawing
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )

end
/*---------------------------------------------------------
	
---------------------------------------------------------*/
function PANEL:Paint()

	
end
/*---------------------------------------------------------
	
---------------------------------------------------------*/
function PANEL:Close()

	self:SetVisible( false )

	if ( self:GetDeleteOnClose() ) then
		self:Remove()
	end

end

/*---------------------------------------------------------
	
---------------------------------------------------------*/
function PANEL:SetMoveText(text)
if text == "" then return end
if text ~= "" then
half = (self:GetTall() / 2)
self.Slidetext = vgui.Create( "DLabel", self )
self.Slidetext:SetPos(0,half)
self.Slidetext:SetText(text)
self.Slidetext:MoveTo(self:GetWide(),half,3,1)
if self.Slidetext:GetPos(self:GetWide(),half) then
self.Slidetext:SetPos(0,half)
self.Slidetext:MoveTo(self:GetWide(),half,3,1)

end
end
end

derma.DefineControl( "SPanel", "", PANEL, "Panel" )