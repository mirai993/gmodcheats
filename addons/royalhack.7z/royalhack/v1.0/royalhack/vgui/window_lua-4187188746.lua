--[[
	vgui/window.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

PANEL = {}

function DrawOutlinedWindow(bordersize,x,y,w,h,color,colorin)

surface.SetDrawColor(0,0,0,70)
surface.DrawRect(x+10,y+10,w,h)
draw.RoundedBox(3,x,y,w+bordersize,h+bordersize,Color(173,173,173,180))--out
draw.RoundedBox(3,x+(bordersize/2),y+(bordersize/2),w,h,Color(color.r,color.g,color.b,color.a))--in
surface.SetDrawColor(colorin.r,colorin.g,colorin.b,colorin.a)
surface.DrawRect(x+8,y+20,w-10,h-20)

end

function PANEL:Int()

self.lbl= vgui.Create("Label",self)
self.lbl:SetPos(1,3)
self.lbl:SetTextColor(Color(255,95,55,255)


end

function PANEL:Think()



end

function PANEL:Paint()

DrawOutlinedWindow(6,self.x,self.y,self:GetWide(),self:GetTall(),Color(0,0,0,255),Color(255,0,0,255))

end

//extern

function PANEL:SetText(strtext)

self.lbl:SetText(strtext)

end
vgui.Register("window",PANEL)