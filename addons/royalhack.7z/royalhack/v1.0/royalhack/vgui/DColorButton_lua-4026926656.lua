--[[
	vgui/DColorButton.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

PANEL = {}


function PANEL:Init()

self.Color = Color(0,0,0,0)

end




function PANEL:Think()



end

function PANEL:SetColor(color)

self.Color = color

end

function  PANEL:GetColor()

return self.Color

end

function PANEL:DoClick()
// Overwrite
end


function PANEL:OnMousePressed( mcode )

if(mcode == MOUSE_LEFT ) then
	self.DoClick()
end

end


function PANEL:Paint( )

surface.SetDrawColor(self.Color.r,self.Color.g,self.Color.b,255)
surface.DrawRect(1,1,self:GetWide()-1,self:GetTall()-1)
surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())


end


function PANEL:ApplySchemeSettings( )

end

function PANEL:PerformLayout( )

		
end

derma.DefineControl( "DColorButton", "Colormenu", PANEL, "EditablePanel" )