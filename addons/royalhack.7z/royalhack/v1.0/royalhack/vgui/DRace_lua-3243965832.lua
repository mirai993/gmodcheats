--[[
	vgui/DRace.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]


PANEL = {}
AccessorFunc( PANEL, "m_bStretchToFit", 			"StretchToFit" )
AccessorFunc( PANEL, "m_bDeleteOnClose", 	"DeleteOnClose", 	FORCE_BOOL )
AccessorFunc( PANEL, "a", 	"Value" )

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Init()

	self:SetDrawBackground( true )
	self:SetDrawBorder( true )
	self:SetStretchToFit( true )
	self:SetDeleteOnClose( true )
	self:SetCursor( "hand" )
	self.m_Image = vgui.Create( "DImage", self )
	self.m_Label = vgui.Create( "DLabel", self )
	--self.m_Pbar = vgui.Create( "DProgressBar", self )

end

/*---------------------------------------------------------
	SetImage
---------------------------------------------------------*/
function PANEL:SetImage( strImage, strBackup )

	self.m_Image:SetImage( strImage, strBackup )

end

/*---------------------------------------------------------
	SetTitle
-----------------------------------------------------------*/
function PANEL:SetTitle(title)

	self.m_Label:SetText(title)
	
end

/*---------------------------------------------------------
DoRightClick
---------------------------------------------------------*/
function PANEL:DoRightClick()

end

/*---------------------------------------------------------
	SetKeepAspect
---------------------------------------------------------*/
function PANEL:SetKeepAspect( bKeep )

	self.m_Image:SetKeepAspect( bKeep )

end

// This makes it compatible with the older ImageButton
PANEL.SetMaterial = PANEL.SetImage

/*---------------------------------------------------------
   Name: OnMouseReleased
---------------------------------------------------------*/
function PANEL:OnCursorEntered()

self.PaintOverOld = self.PaintOver
self.PaintOver = self.PaintOverHovered
self.MouseinRange = true
end

/*---------------------------------------------------------
   Name: OnMouseReleased
---------------------------------------------------------*/
function PANEL:OnCursorExited()
self.MouseinRange = false
	if ( self.PaintOver == self.PaintOverHovered ) then
		self.PaintOver = self.PaintOverOld
	end

end

/*---------------------------------------------------------
	GetCourserStat
---------------------------------------------------------*/
function PANEL:GetCourserStat( )

if self.MouseinRange == true then
	return true
elseif self.MouseinRange == false then
	return false
end

end
/*---------------------------------------------------------
	OnMousePressed
---------------------------------------------------------*/
function PANEL:OnMousePressed( mousecode )

	DButton.OnMousePressed( self, mousecode )
    surface.DrawRect( 0, 0, self:GetWide()-20, self:GetTall()-20 )
	

end

/*---------------------------------------------------------
	OnMouseReleased
---------------------------------------------------------*/
function PANEL:OnMouseReleased( mousecode )

	DButton.OnMouseReleased( self, mousecode )
surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Paint()
if self.MouseinRange == true then
	draw.RoundedBox( 6, 1, 1, self:GetWide(), self:GetTall()-1, Color( 0, 0, 255, 50 ) )
else
    draw.RoundedBox( 6, 1, 1, self:GetWide(), self:GetTall()-1, Color( 100, 100, 100, 150 ) )
	end
	surface.SetDrawColor( 0, 0, 0, 255 )
	surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	return true

end
/*---------------------------------------------------------
Close
---------------------------------------------------------*/
function PANEL:Close()

	self:SetVisible( false )

	if ( self:GetDeleteOnClose() ) then
		self:Remove()
	end

end

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:PaintOver()


	return true

end


/*---------------------------------------------------------
SetTextColor( Color(255, 0, 0, 255) )
---------------------------------------------------------*/
function PANEL:PerformLayout()

self.m_Image:SetPos(2,2)
self.m_Image:SetSize(self:GetWide()-((self:GetWide()/4)*3),self:GetTall()-3)
self.m_Label:SetPos((self:GetWide()/4)+5,self:GetTall()/4)
self.m_Label:SetSize(self:GetWide(),10)
self.m_Label:SetTextColor( Color(255, 0, 0, 255) )


end

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:SetDisabled( bDisabled )

	DButton.SetDisabled( self, bDisabled )

	if ( bDisabled ) then
		self.m_Image:SetImageColor( Color( 200, 200, 200, 150 ) ) 
	else
		self.m_Image:SetImageColor( Color( 255, 255, 255, 255 ) ) 
	end

end

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:SetOnViewMaterial( MatName, Backup )

	self.m_Image:SetOnViewMaterial( MatName, Backup )

end
/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:IsActive()

	if ( self:HasFocus() ) then return true end
	if ( vgui.FocusedHasParent( self ) ) then return true end
	
	return false

end

/*---------------------------------------------------------
   Name: GenerateExample
---------------------------------------------------------*/
function PANEL:GenerateExample( ClassName, PropertySheet, Width, Height )

	local ctrl = vgui.Create( ClassName )
		ctrl:SetImage( "brick/brick_model" )
		ctrl:SetSize( 300, 50 )
		ctrl:SetTitle("Example")
		--ctr1:Value( 10 )
	PropertySheet:AddSheet( ClassName, ctrl, nil, true, true )

end

derma.DefineControl( "DRace", "Raceb", PANEL, "DButton" )