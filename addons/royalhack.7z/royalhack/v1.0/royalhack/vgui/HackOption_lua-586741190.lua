--[[
	vgui/HackOption.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]


PANEL = {}

/*
Author: ALL YOU CAN EAT
Version: 1.0 Beta
Build: 24.04.2011 20:16
Info: Erstellt ein Menu das mit der Tastatur bedient werden kann.
*/

AccessorFunc( PANEL, "m_Min", 			"Min" ) 
AccessorFunc( PANEL, "m_Max", 			"Max" )
AccessorFunc( PANEL, "m_Cvar", 			"Cvar" )
AccessorFunc( PANEL, "m_Value",			"Value" )
function PANEL:Init()
	self.Id = 0
	self:SetContentAlignment( 4 )
	self:SetTextInset( 20 )		
	self.selected = false
	self.lblTitle = vgui.Create( "DLabel", self )
	self.lblTitle:SetPos(10,2)
	self.lblTitle:SetTextColor(Color(255,0,0,255))
	self.TextEntry = vgui.Create( "DTextEntry", self )
	self.TextEntry:SetUpdateOnType( true )
	self.TextEntry:SetNumeric( true )
	self.TextEntry.SetValue = function ( entry, value ) self:SetValue( value ) end
	self.TextEntry.Paint = function()
	draw.SimpleText(""..self:GetValue().."","DefaultSmall",0,0,Color(0,0,0,255))--GetValue()
	end	
	
	
end


function PANEL:Name( name )


self.lblTitle:SetText( name )

end

function PANEL:SetConVar( str )
 
self.m_Cvar = str

end

function PANEL:SetMin( value )

self.m_Min = tonumber( value )
self.m_Value = self.m_Min
end

function PANEL:SetMax( value )

self.m_Max = tonumber( value )

end

function PANEL:SetId(id)

self.Id = id

end

function PANEL:GetId()

return self.Id

end


function PANEL:GetValue()


	return tonumber( self.TextEntry:GetValue() ) or 0


end

function PANEL:Think()



end

function PANEL:SetValue( val )

cvar = self.m_Cvar

math.Round( val )


RunConsoleCommand( cvar, val )
self.m_Value = val

		self.TextEntry:SetText( val )
		self.TextEntry:ConVarChanged( val )

end



function PANEL:SetSelected( bool )


	if ( bool == true ) then
	 self.selected = true
	 self:OnSelect()
	elseif( bool == false ) then
	self.selected = false
	self:OnDeSelect()
	
	end

end

function PANEL:GetSelected()

if(self.selected == true) then
return true
elseif(self.selected == false) then
return false
end

end


--self.m_Min
function PANEL:OnMousePressed( mcode )
	local val = self.m_Value
	if ( mcode == MOUSE_LEFT and val <= self.m_Max ) then
		val = val + 1 
		self.lblTitle:SetTextColor(Color(0,255,0,255))
		--self.lblValue:SetTextColor(Color(0,255,0,255))
		self:SetValue( val )
		
	elseif( mcode == MOUSE_RIGHT and val >= self.m_Min ) then
		local xval = val - 1
		self:SetValue( xval )
		if(xval <=0) then
		self.lblTitle:SetTextColor(Color(255,0,0,255))
	--	self.lblValue:SetTextColor(Color(255,0,0,255))
	
			end
		end
end


function PANEL:OnSelect()

	self.PaintOverOld = self.PaintOver
	self.PaintOver = self.PaintOverHovered

end

function PANEL:OnDeSelect()

	if ( self.PaintOver == self.PaintOverHovered ) then
		self.PaintOver = self.PaintOverOld
	end

end

function PANEL:PaintOverHovered()

	surface.SetDrawColor( 0, 0, 0, 100 )
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())

end

function PANEL:Paint()



end


function PANEL:ApplySchemeSettings()

end

function PANEL:PerformLayout()

self.TextEntry:SetPos(self:GetWide()-3,7)
self.TextEntry:SetSize(20,20)
		
end

derma.DefineControl( "HackOption", "A HAX Panel", PANEL, "EditablePanel" )