--[[
	vgui/HRadar.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

/*   _                                
    ( )                               
   _| |   __   _ __   ___ ___     _ _ 
 /'_` | /'__`\( '__)/' _ ` _ `\ /'_` )
( (_| |(  ___/| |   | ( ) ( ) |( (_| |
`\__,_)`\____)(_)   (_) (_) (_)`\__,_) 

	DFrame
	
	A window.

*/

PANEL = {}


AccessorFunc( PANEL, "m_bDraggable", 		"Draggable", 		FORCE_BOOL )
AccessorFunc( PANEL, "m_bSizable", 			"Sizable", 			FORCE_BOOL )
AccessorFunc( PANEL, "m_bScreenLock", 		"ScreenLock", 		FORCE_BOOL )
AccessorFunc( PANEL, "m_bDeleteOnClose", 	"DeleteOnClose", 	FORCE_BOOL )

AccessorFunc( PANEL, "m_bBackgroundBlur", 	"BackgroundBlur", 	FORCE_BOOL )


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Init()

	self:SetFocusTopLevel( true )

//	self:SetCursor( "sizeall" )
	
	self.btnClose = vgui.Create( "DSysButton", self )
	self.btnClose:SetType( "close" )
	self.btnClose.DoClick = function ( button ) self:Close() end
	self.btnClose:SetDrawBorder( false )
	self.btnClose:SetDrawBackground( false )
	
	self.lblTitle = vgui.Create( "DLabel", self )
	
	self:SetDraggable( true )
	self:SetSizable( false )
	self:SetScreenLock( true )
	self:SetDeleteOnClose( true )
	self:SetTitle( "#Untitled DFrame" )
	
	// This turns off the engine drawing
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )
	
	self.m_fCreateTime = SysTime()

end

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:ShowCloseButton( bShow )

	self.btnClose:SetVisible( bShow )

end

/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:SetTitle( strTitle )

	self.lblTitle:SetText( strTitle )

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Close()

	self:SetVisible( false )

	if ( self:GetDeleteOnClose() ) then
		self:Remove()
	end

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Center()

	self:InvalidateLayout( true )
	self:SetPos( ScrW()/2 - self:GetWide()/2, ScrH()/2 - self:GetTall()/2 )

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Think()

	if (self.Dragging) then
	
		local x = gui.MouseX() - self.Dragging[1]
		local y = gui.MouseY() - self.Dragging[2]

		// Lock to screen bounds if screenlock is enabled
		if ( self:GetScreenLock() ) then
		
			x = math.Clamp( x, 0, ScrW() - self:GetWide() )
			y = math.Clamp( y, 0, ScrH() - self:GetTall() )
		
		end
		
		self:SetPos( x, y )
	
	end
	
	
	if ( self.Sizing ) then
	
		local x = gui.MouseX() - self.Sizing[1]
		local y = gui.MouseY() - self.Sizing[2]	
	
		self:SetSize( x, y )
		self:SetCursor( "sizenwse" )
		return
	
	end
	
	if ( self.Hovered &&
         self.m_bSizable &&
	     gui.MouseX() > (self.x + self:GetWide() - 20) &&
	     gui.MouseY() > (self.y + self:GetTall() - 20) ) then	

		self:SetCursor( "sizenwse" )
		return
		
	end
	
	if ( self.Hovered && self:GetDraggable() ) then
		self:SetCursor( "sizeall" )
	end
	
end


/*---------------------------------------------------------
local x,y = self:GetPos()
w = self:GetWide()
h = self:GetTall()
		local COL_GOOD = Color(0,255,0,255)
		local COL_BAD = Color(255,0,0,255)
radius = 2056  -- distance scaleable later
for _, ply in ipairs(player.GetAll()) do
			local cx = x+w/2
			local cy = y+h/2
			local vdiff = ply:GetPos()-LocalPlayer():GetPos()
			if ( ply:Alive() and LocalPlayer()!=ply and vdiff:Length()<=radius ) then
				local px = (vdiff.x/500)
				local py = (vdiff.y/250)
				local z = math.sqrt( px*px + py*py )
				local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( LocalPlayer():GetAimVector().x, LocalPlayer():GetAimVector().y ) ) - 90 )
				px = math.cos(phi)*z
				py = math.sin(phi)*z
	draw.RoundedBox( 4, cx+px*w/2-4, cy+py*h/2-4, 8, 8,COL_GOOD )
	if ( self.m_bBackgroundBlur ) then
		Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
	end
---------------------------------------------------------*/

				
function PANEL:Paint()
radius = 2056
w = self:GetWide()
h = self:GetTall()
x = ScrW()-self:GetWide()-16
y = ScrW()-self:GetTall()-16
lpl = LocalPlayer()
		local players = player.GetAll()
		for i, pl in ipairs(players) do
			local cx = x+w/2
			local cy = y+h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			if ( pl:Alive() and lpl!=pl and vdiff:Length()<=radius ) then
				local px = (x/radius)
				local py = (y/radius)
				local z = math.sqrt( px*px + py*py )
				local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
				px = math.cos(phi)*z
				py = math.sin(phi)*z
				draw.RoundedBox( 4, cx+px*w/2-4, cy+py*h/2-4, 8, 8,Color(0,255,0,255))
		local COL_GREY = Color(50,50,50,255)
		local COL_LGREY = Color(100,100,100,255)
		local COL_BLACK = Color(0,0,0,255)
		local COL_GOOD = Color(0,255,0,255)
	surface.SetDrawColor(COL_GREY)
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	surface.SetDrawColor(COL_BLACK)
	surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
	surface.SetDrawColor(COL_LGREY)
	surface.DrawRect(0,0,self:GetWide(),21)
	surface.SetDrawColor(COL_BLACK)
	surface.DrawOutlinedRect(0,0,self:GetWide(),21)
	surface.DrawLine( 0, self:GetTall() / 2, self:GetWide(), self:GetTall() / 2 )
	surface.DrawLine( self:GetWide() / 2, 0, self:GetWide() / 2, self:GetTall() )

	

	return true

end
end
end
/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:OnMousePressed()

	if ( self.m_bSizable ) then
	
		if ( gui.MouseX() > (self.x + self:GetWide() - 20) &&
			gui.MouseY() > (self.y + self:GetTall() - 20) ) then			
	
			self.Sizing = { gui.MouseX() - self:GetWide(), gui.MouseY() - self:GetTall() }
			self:MouseCapture( true )
			return
		end
		
	end
	
	if ( self:GetDraggable() ) then
		self.Dragging = { gui.MouseX() - self.x, gui.MouseY() - self.y }
		self:MouseCapture( true )
		return
	end
	


end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:OnMouseReleased()

	self.Dragging = nil
	self.Sizing = nil
	self:MouseCapture( false )

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:PerformLayout()

	derma.SkinHook( "Layout", "Frame", self )

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:IsActive()

	if ( self:HasFocus() ) then return true end
	if ( vgui.FocusedHasParent( self ) ) then return true end
	
	return false

end


derma.DefineControl( "HRadar", "Hax radar panel", PANEL, "EditablePanel" )