--[[
	vgui/CSlideBar.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]


PANEL = {}

/*
Author: ALL YOU CAN EAT
Version: 1.0 Beta
Build: 24.04.2011 20:16
Info: CSlideBar
*/

AccessorFunc( PANEL, "m_bDeleteOnClose", 	"DeleteOnClose", 	FORCE_BOOL )

function PANEL:Init()

self.ContentImage = vgui.Create( "DImage", self)
self.Left = vgui.Create( "DImage", self)
self.Right = vgui.Create( "DImage", self)
self.Disc = vgui.Create( "DLabel", self)

self.Content ={}

end

function PANEL:AddContent( part )

table.insert(self.Content.name,part)

end

function PANEL:MoveRight()


end

function PANEL:MoveLeft()


end

function PANEL:SetStart( index )


end

function PANEL:GetDiscription (  )


end



/*---------------------------------------------------------
	GetCourserStat
---------------------------------------------------------*/
function PANEL:GetCourserStat( )

if self.MouseinRange == true then
	return true
elseif self.MouseinRange == false then
	return false
end

end

function PANEL:Think()



end



function PANEL:SetSelected( bool )


end

function PANEL:GetSelected()


end

function PANEL:DoClick()

end

--self.m_Min
function PANEL:OnMousePressed( mcode )

if(mcode == MOUSE_LEFT ) then
	self.DoClick()
	self.SetSelected(true)
end

end


function PANEL:OnCursorEntered( )
self.MouseinRange = true
	self.PaintOverOld = self.PaintOver
	self.PaintOver = self.PaintOverHovered

end

function PANEL:OnCursorExited( )
self.MouseinRange = false
	if ( self.PaintOver == self.PaintOverHovered ) then
		self.PaintOver = self.PaintOverOld
	end

end

function PANEL:PaintOverHovered( )

	surface.SetDrawColor( 0, 0, 0, 100 )
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())

end

function PANEL:Paint( )
if self.MouseinRange == true then
	surface.SetDrawColor(255,255,255,150)
	surface.DrawRect(1,1,self:GetWide()-1,self:GetTall()-1)
else
surface.SetDrawColor(41,41,41,255)
surface.DrawRect(1,1,self:GetWide()-1,self:GetTall()-1)
	end
surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())


end


function PANEL:ApplySchemeSettings( )

end

function PANEL:PerformLayout( )
		
end

derma.DefineControl( "CSlideBar", "silde your content", PANEL, "EditablePanel" )