--[[
	vgui/HButton.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

/*   _                                
    ( )                               
   _| |   __   _ __   ___ ___     _ _ 
 /'_` | /'__`\( '__)/' _ ` _ `\ /'_` )
( (_| |(  ___/| |   | ( ) ( ) |( (_| |
`\__,_)`\____)(_)   (_) (_) (_)`\__,_) 

	DButton
	
	Default Button

*/

PANEL = {}

AccessorFunc( PANEL, "m_bBorder", 			"DrawBorder", 		FORCE_BOOL )
AccessorFunc( PANEL, "m_bBackground", 		"DrawBackground", 	FORCE_BOOL )
AccessorFunc( PANEL, "m_bDisabled", 		"Disabled", 		FORCE_BOOL )
AccessorFunc( PANEL, "m_bSelected", 		"Selected", 		FORCE_BOOL )


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Init()

	self:SetContentAlignment( 5 )
	
	//
	// These are Lua side commands
	// Defined above using AccessorFunc
	//
	self:SetDrawBorder( true )
	self:SetDrawBackground( true )
	
	//
	self:SetTall( 22 )
	self:SetMouseInputEnabled( true )
	self:SetKeyboardInputEnabled( true )

end

/*---------------------------------------------------------
	IsDown
---------------------------------------------------------*/
function PANEL:IsDown()

	return self.Depressed

end

/*---------------------------------------------------------
	OnMousePressed
---------------------------------------------------------*/
function PANEL:OnMousePressed( mousecode )

	if ( self.m_bDisabled ) then return end

	self:MouseCapture( true )
	self.Depressed = true

end

/*---------------------------------------------------------
	OnMouseReleased
---------------------------------------------------------*/
function PANEL:OnMouseReleased( mousecode )

	self:MouseCapture( false )
	
	if ( !self.Depressed ) then return end
	
	self.Depressed = nil
	
	if ( !self.Hovered ) then return end
	

	if ( mousecode == MOUSE_RIGHT ) then
		PCallError( self.DoRightClick, self )
	end
	
	if ( mousecode == MOUSE_LEFT ) then
		PCallError( self.DoClick, self )
	end

end


/*---------------------------------------------------------
	DoRightClick
---------------------------------------------------------*/
function PANEL:DoRightClick()

end

/*---------------------------------------------------------
	DoClick
---------------------------------------------------------*/
function PANEL:DoClick()

end


/*---------------------------------------------------------

---------------------------------------------------------*/
function PANEL:Paint()

local COL_GREY = Color(50,50,50,255)
local COL_LGREY = Color(0,0,0,100)
local COL_Blue = Color(0,147,234,255)
	surface.SetDrawColor(COL_LGREY)
	surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	surface.SetDrawColor(COL_Blue)
	surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
	surface.SetDrawColor(COL_LGREY)
	surface.DrawRect(0,0,self:GetWide(),21)
	surface.SetDrawColor(COL_Blue)
	surface.DrawOutlinedRect(0,0,self:GetWide(),21)
	
	// No need to draw the border in another function when 
	// we can draw it here just fine..
	derma.SkinHook( "PaintOver", "Button", self )
	
	//
	// Draw the button text
	//
	return false

end

/*---------------------------------------------------------
   Name: PerformLayout
---------------------------------------------------------*/
function PANEL:ApplySchemeSettings()

	derma.SkinHook( "Scheme", "Button", self )

end

/*---------------------------------------------------------
	DoClick
---------------------------------------------------------*/
function PANEL:SetDisabled( bDisabled )

	self.m_bDisabled = bDisabled	
	self:InvalidateLayout()

end

/*---------------------------------------------------------
   Name: SetConsoleCommand
---------------------------------------------------------*/
function PANEL:SetConsoleCommand( strName, strArgs )

	self.DoClick = function( self, val ) 
						RunConsoleCommand( strName, strArgs ) 
				   end

end

/*---------------------------------------------------------
   Name: GenerateExample
---------------------------------------------------------*/
function PANEL:GenerateExample( ClassName, PropertySheet, Width, Height )

	local ctrl = vgui.Create( ClassName )
		ctrl:SetText( "Example Button" )
		ctrl:SetWide( 200 )
	
	PropertySheet:AddSheet( ClassName, ctrl, nil, true, true )

end


local PANEL = derma.DefineControl( "HButton", "A standard Button", PANEL, "DLabel" )

PANEL = table.Copy( PANEL )

// No example here!
PANEL.GenerateExample = nil

/*---------------------------------------------------------
   Name: PerformLayout
---------------------------------------------------------*/
function PANEL:PerformLayout()

	self:SetTextInset( 4 )

end

/*---------------------------------------------------------
   Name: SetActionFunction
---------------------------------------------------------*/
function PANEL:SetActionFunction( func )

	self.DoClick = function( self, val ) func( self, "Command", 0, 0 ) end

end

derma.DefineControl( "HButton", "Backwards Compatibility", PANEL, "DLabel" )