--[[
	royalhack/module/DangerEsp.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

function RoyalHack.DangerPlayer(target)

end


function RoyalHack.DangerEsp()

end