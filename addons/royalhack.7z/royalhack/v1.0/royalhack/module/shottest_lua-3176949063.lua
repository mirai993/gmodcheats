--[[
	royalhack/module/shottest.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

function ShowShot()

local player = LocalPlayer()

tables = {}

table.insert(tables,LocalPlayer():GetAimVector())
PrintTable(tables)

end

concommand.Add("cl_shotpos",ShowShot)