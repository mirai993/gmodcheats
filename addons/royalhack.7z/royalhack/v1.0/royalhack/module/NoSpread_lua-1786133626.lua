--[[
	royalhack/module/NoSpread.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

// NoSpread
