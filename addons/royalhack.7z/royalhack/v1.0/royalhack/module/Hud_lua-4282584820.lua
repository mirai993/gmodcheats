--[[
	royalhack/module/Hud.lua
	Royal | (STEAM_0:1:14585758)
	===DStream===
]]

// Hud
/*
RoyalKills = {}

function HideBasicHud(name)	

	if name == "CHudHealth" || name == "CHudBattery" || name == "CHudAmmo" then return false end
	return true
	end


hook.Add("HUDShouldDraw", "RoyalHud", HideBasicHud)
*/

function AddVgui()
/*
		local MainFrame = vgui.Create( "RoyalFrame" )
		  MainFrame:SetPos( ScrW()-500,ScrH()-500)
		  MainFrame:SetSize( 500, 500 )
		  MainFrame:SetTitle( "Royal Killbook" )
		  MainFrame:SetVisible( true )
		  MainFrame:SetDraggable( true )
		  */
end


