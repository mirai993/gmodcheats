--[[ Leaked By Tyler Wearing, The Creator Of Hera V4, Enjoy This Amazing Garry's Mod Cheat Made By The Original Blue Kirby. Good Job At Circumventing Anti-Cheats By "Loading Lua Files Before Your Autorun/Client Files" You Sure Did A Swell Job At Defeating Anti-Cheats, Now Go On And Proceed Shoving A Cactus Up In Your Ass. I Love You Blue Kirby, Marry Me.

The Original Blue Kirby:
STEAM: STEAM_0:0:49821628
IP: 72.95.14.178 Thanks To The Revolutionary Verizion Internet You Have A Static Ip, Yay.
Game Deception Profile: http://www.gamedeception.net/members/59482-smith
Aliases: VACUBANU, Blue Kirby
Thanks To The Revolutionary Anti-Cheat Made By Me And Only Tyler Wearing This Was Possible To Be Done, If You See This, Contact Me At Steam Right Here: https://steamcommunity.com/profiles/76561198040553376
Because Of Garry, I'm Not Able To Include Any Modules. ]]

--[[ Folder Structure:
lua/blue_bot.lua
lua/bubber_ducky.lua
lua/bvip_cl_init.lua
lua/cl_init.lua
lua/cl_init_post.lua
lua/cvar_spoofer.lua
lua/html.lua
lua/lel.lua
lua/menu_plugin.lua
lua/name.lua
lua/printtrace.lua
lua/printts.lua
lua/rake.lua
lua/ulx_psay_spammer.lua
Let's Not Forget The Amazing Autorun Folder Containing This Amazing File Named Ugh.lua:
lua/autorun/client/ugh.lua ]]

// lua/blue_bot.lua

local BB = { };
local LocalPlayer = LocalPlayer;
BB.DeadPlayers = { };
BB.ply = LocalPlayer;
BB.players = player.GetAll;
BB.Target = nil;
BB.ShouldReturn = false;
BB.AimbotEnabled = CreateClientConVar( "blue_bot_aimbot_enabled", "0", true, false );
BB.MaxAngle = CreateClientConVar( "blue_bot_aimbot_max_angle", "30", true, false );
BB.FriendlyFire = CreateClientConVar( "blue_bot_aimbot_friendly_fire", "1", true, false );
BB.ESPEnabled = CreateClientConVar( "blue_bot_esp_enabled", "1", true, false );
BB.ChamsEnabled = CreateClientConVar( "blue_bot_chams_enabled", "1", true, false );
BB.CrosshairEnabled = CreateClientConVar( "blue_bot_crosshair_enabled", "1", true, false );
BB.HeadPos = nil;
BB.TraceRes = nil;
BB.IsTTT = false;

function BB.Init( )
	surface.CreateFont( "BBFont", { font = "Arial", size = 14, weight = 750, antialias = false, outline = true } );
	BB.IsTTT = string.find( GAMEMODE.Name , "Terror" );
	return 0;
end

function BB.Print( color, message )
	MsgC( Color( 50, 100, 255 ), "[Blue Bot] " );
	MsgC( color, message.."\n" );
	
	return 0;
end

function BB.PrintChat( color, message )
	chat.AddText( Color( 50, 100, 255 ), "[Blue Bot] ", color, message );
	
	return 0;
end

function BB.Error( error )
	MsgC( Color( 255, 50, 50 ), "[Blue Bot] ERROR: " );
	MsgC( Color( 255, 255, 255 ), error.."\n" );
	
	return 0;
end

function BB.IsOnTeam( ply )
	if ( BB.IsTTT ) then
		return ply:IsTraitor() == BB.ply():IsTraitor();
	else
		return ply:Team() == BB.ply():Team();
	end
end

function BB.GetValidPlayers( )
	local players = { };
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply && IsValid( ply ) && 
		ply:IsPlayer() && 
		ply:Alive() && 
		ply:Health() >= 1 &&
		( !BB.IsOnTeam( ply ) || BB.FriendlyFire:GetBool() ) ) then
			table.insert( players, ply );
		end
	end
	
	return players
end

function BB.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = BB.ply():EyePos(), endpos = vecPos, filter = BB.ply(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
	
	BB.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function BB.ClosestAngle( players )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = BB.ply():EyeAngles();
	
	for _, ply in pairs( players ) do
		local vecPos, ang = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
		local oldpos = vecPos;
		vecPos = vecPos - BB.VelocityPrediction( BB.ply() ) + BB.VelocityPrediction( ply )
		local angAngle = ( vecPos - BB.ply():EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (!BB.MaxAngle:GetFloat() || flDif < BB.MaxAngle:GetFloat())) then
			BB.HeadPos = oldpos:ToScreen();
			BB.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle;
end

function BB.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function BB.Aimbot( )
	BB.HeadPos = nil;
	
	if (!BB.AimbotEnabled:GetBool() || BB.ShouldReturn) then return end
	
	local players = {};
	
	if ( BB.Target != nil && IsValid( BB.Target ) && BB.Target:IsPlayer() ) then
		if ( BB.IsVisible( BB.Target ) ) then
			table.insert( players, BB.Target );
		end
	else
		for _, ply in pairs( BB.GetValidPlayers() ) do
			if ( BB.IsVisible( ply ) ) then
				table.insert( players, ply );
			end
		end
	end
	
	if (table.Count( players ) == 0) then 
		BB.Target = nil;
		return
	end;
	
	local newAngle = BB.ClosestAngle( players );
	
	if ( newAngle != nil ) then BB.ply():SetEyeAngles( newAngle ) end;
end

function BB.TableSortByDistance( former, latter ) return latter:GetPos():Distance( BB.ply():GetPos() ) > former:GetPos():Distance( BB.ply():GetPos() ) end

function BB.GetPlayersByDistance( )
	local players = BB.players( );
	
	table.sort( players, BB.TableSortByDistance );
	
	return players;
end

function BB.CreateMove( cmd )
	if ( BB.IsTTT && BB.ply():Alive() && BB.ply():Health() >= 1 && BB.ply():Team() != TEAM_SPECTATOR ) then
		BB.ply().voice_battery = 100;
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			if ( ent:GetPos():Distance( BB.ply():GetPos() ) < 256 && !BB.ply():IsTraitor() && ent:GetOwner() != BB.ply() ) then
				if ( ent:GetArmed() ) then
					for i = 1, 6 do RunConsoleCommand( "ttt_c4_disarm", tostring( ent:EntIndex() ), tostring( i ) ) end
				end
				RunConsoleCommand( "ttt_c4_pickup", tostring( ent:EntIndex() ) );
			end
		end
	end
	
	if ( cmd:KeyDown( IN_ATTACK ) && BB.ShouldReturn ) then
		BB.ShouldReturn = false;
		BB.Aimbot( );
	elseif ( !cmd:KeyDown( IN_ATTACK ) && !BB.ShouldReturn ) then
		BB.ShouldReturn = true;
	end
	
	if ( IsValid( BB.ply() ) && BB.ply():Alive() && BB.ply():Health() > 0 && IsValid( BB.ply():GetActiveWeapon() ) ) then
		BB.ply():GetActiveWeapon().Recoil = 0;
		if ( BB.ply():GetActiveWeapon().Primary ) then
			BB.ply():GetActiveWeapon().Primary.Recoil = 0;
		end
	end
end

function BB.NoVisualRecoil( ply, pos, angles, fov )
   if ( BB.ply():Health() > 0 && BB.ply():Team() != TEAM_SPECTATOR && BB.ply():Alive() ) then
	   return GAMEMODE:CalcView( ply, BB.ply():EyePos(), BB.ply():EyeAngles(), fov, 0.1 );
   end
end

function BB.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function BB.SubtractFromColor( color, sub )
	return color - sub >= 0 and color - sub or color - sub + 255
end

function BB.ESP( )
	if ( !BB.CrosshairEnabled:GetBool() && !BB.ESPEnabled:GetBool() ) then return end;
	
	if ( BB.CrosshairEnabled:GetBool() ) then
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
	end
	
	if ( !BB.ESPEnabled:GetBool() ) then return end
	
	surface.SetFont( "BBFont" );
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR ) then
			local min, max = ply:GetRenderBounds();
			local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
			local color = Color( 50, 255, 50, 255 );
			
			if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
			elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
			elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
			elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 ); 
			elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
			
			pos = ( pos + Vector( 0, 0, 10 ) ):ToScreen();
			
			local width, height = surface.GetTextSize( tostring( ply:Nick() ) );
			draw.DrawText( ply:Nick(), "BBFont", pos.x, pos.y-height/2, ( BB.IsTTT && ply:IsTraitor() ) and Color( 255, 150, 150, 255 ) or Color( 255, 255, 255, 255 ), 1 );
			
			if ( BB.IsTTT && ply:IsTraitor() ) then
				width, height = surface.GetTextSize( "TRAITOR" );
				draw.DrawText( "TRAITOR", "BBFont", pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
			end
			
			pos = ply:GetPos():ToScreen();
			width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
			draw.DrawText( "Health: "..tostring( ply:Health() ), "BBFont", pos.x, pos.y, color, 1 );
		end
	end
	
	for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if ( !BB.IsTTT ) then break; end
		
		local pos = ent:GetPos():ToScreen();
		
		local width, height = surface.GetTextSize( "C4" );
		draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
	end
	
	if ( BB.IsTTT ) then
		for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
			local name = CORPSE.GetPlayerNick(ent, false)
			if ( name != false ) then
				local pos = ent:GetPos():ToScreen();
				local width, height = surface.GetTextSize( name );
				
				draw.DrawText( name, "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
				
				if ( !CORPSE.GetFound(ent, false) ) then
					draw.DrawText( "Unidentified", "BBFont", pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
				end
			end
		end
	end
	
	if ( BB.HeadPos != nil ) then
		local width = 5;
		local height = 5;
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
		surface.DrawOutlinedRect( BB.HeadPos.x-width/2, BB.HeadPos.y-height/2, width, height );
	end
end

function BB.Chams()
	if ( BB.ChamsEnabled:GetBool() ) then
		for _, ply in pairs( BB.GetPlayersByDistance( ) ) do
			if ( IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR ) then
				local color = (BB.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or team.GetColor( ply:Team( ) );
				
				cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
					render.SuppressEngineLighting( true );

					render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
					render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
					ply:DrawModel();
					
					render.SetColorModulation( BB.AddToColor( color.r, 150 )/255, BB.AddToColor( color.g, 150 )/255, BB.AddToColor( color.b, 150 )/255, 1 );
					if ( IsValid( ply:GetActiveWeapon() ) ) then
						ply:GetActiveWeapon():DrawModel() 
					end
					
					if ( BB.IsTTT && ply:IsTraitor() ) then
						render.SetColorModulation( 1, 0, 0, 1 );
					else
						render.SetColorModulation( 1, 1, 1, 1 );
					end
					render.MaterialOverride();
					render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
					ply:DrawModel();
					
					render.SuppressEngineLighting( false );
				cam.End3D();
			end
		end
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
				render.SuppressEngineLighting( true );
				render.SetColorModulation( 1, 0, 0, 1 );
				render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
				ent:DrawModel( );
				
				render.SetColorModulation( 1, 1, 1, 1 );
				render.MaterialOverride();
				render.SetModelLighting( BOX_TOP, 1, 1, 1 )
				ent:DrawModel();
					
				render.SuppressEngineLighting( false );
			cam.End3D();
		end
		
		if (BB.IsTTT) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				if ( CORPSE.GetPlayerNick(ent, false) != false ) then
					cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
						render.SuppressEngineLighting( true );
						render.SetColorModulation( 1, 0.8, 0.5, 1 );
						render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
						ent:DrawModel( );
						
						render.SetColorModulation( 1, 1, 1, 1 );
						render.MaterialOverride();
						render.SetModelLighting( BOX_TOP, 1, 1, 1 )
						ent:DrawModel();
							
						render.SuppressEngineLighting( false );
					cam.End3D();
				end
			end
		end
	end
end

function BB.PlayerDeath( ply )
	BB.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( "BB.PlayerDeaths", 0.25, 0, function( )
	if ( ( !BB.IsTTT || GetRoundState() != 3 ) ) then 
		if ( BB.DeadPlayers != { } ) then
			BB.DeadPlayers = { }
		end
		return;
	end
	
	for _, ply in pairs( BB.players() ) do
		if ( ( !ply:Alive() || ply:Health() <= 0 ) && !table.HasValue( BB.DeadPlayers, ply ) ) then
			table.insert( BB.DeadPlayers, ply );
			BB.PlayerDeath( ply );
		end
	end
end )

timer.Simple( 0.0, BB.Init )

hook.Add( "RenderScreenspaceEffects" , "BB.Chams", BB.Chams );
hook.Add( "Think", "BB.Aimbot", BB.Aimbot );
hook.Add( "CreateMove", "BB.CreateMove", BB.CreateMove );
hook.Add( "CalcView", "BB.NoVisualRecoil", BB.NoVisualRecoil );
hook.Add( "HUDPaint", "BB.ESP", BB.ESP );










// lua/bubber_ducky.lua









local BB = { };
local LocalPlayer = LocalPlayer;
BB.DeadPlayers = { };
BB.ply = LocalPlayer;
BB.players = player.GetAll;
BB.Target = nil;
BB.ShouldReturn = false;
BB.AimbotEnabled = CreateClientConVar( "blue_bot_aimbot_enabled", "0", true, false );
BB.MaxAngle = CreateClientConVar( "blue_bot_aimbot_max_angle", "30", true, false );
BB.FriendlyFire = CreateClientConVar( "blue_bot_aimbot_friendly_fire", "1", true, false );
BB.ESPEnabled = CreateClientConVar( "blue_bot_esp_enabled", "1", true, false );
BB.ChamsEnabled = CreateClientConVar( "blue_bot_chams_enabled", "1", true, false );
BB.CrosshairEnabled = CreateClientConVar( "blue_bot_crosshair_enabled", "1", true, false );
BB.HeadPos = nil;
BB.TraceRes = nil;
BB.IsTTT = false;

function BB.Init( )
	surface.CreateFont( "BBFont", { font = "Arial", size = 14, weight = 750, antialias = false, outline = true } );
	BB.IsTTT = string.find( GAMEMODE.Name , "Terror" );
	return 0;
end

function BB.Print( color, message )
	MsgC( Color( 50, 100, 255 ), "[Blue Bot] " );
	MsgC( color, message.."\n" );
	
	return 0;
end

function BB.PrintChat( color, message )
	chat.AddText( Color( 50, 100, 255 ), "[Blue Bot] ", color, message );
	
	return 0;
end

function BB.Error( error )
	MsgC( Color( 255, 50, 50 ), "[Blue Bot] ERROR: " );
	MsgC( Color( 255, 255, 255 ), error.."\n" );
	
	return 0;
end

function BB.IsOnTeam( ply )
	if ( BB.IsTTT ) then
		return ply:IsTraitor() == BB.ply():IsTraitor();
	else
		return ply:Team() == BB.ply():Team();
	end
end

function BB.GetValidPlayers( )
	local players = { };
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply && IsValid( ply ) && 
		ply:IsPlayer() && 
		ply:Alive() && 
		ply:Health() >= 1 &&
		( !BB.IsOnTeam( ply ) || BB.FriendlyFire:GetBool() ) ) then
			table.insert( players, ply );
		end
	end
	
	return players
end

function BB.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = BB.ply():EyePos(), endpos = vecPos, filter = BB.ply(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
	
	BB.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function BB.ClosestAngle( players )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = BB.ply():EyeAngles();
	
	for _, ply in pairs( players ) do
		local vecPos, ang = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
		local oldpos = vecPos;
		vecPos = vecPos - BB.VelocityPrediction( BB.ply() ) + BB.VelocityPrediction( ply )
		local angAngle = ( vecPos - BB.ply():EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (!BB.MaxAngle:GetFloat() || flDif < BB.MaxAngle:GetFloat())) then
			BB.HeadPos = oldpos:ToScreen();
			BB.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle;
end

function BB.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function BB.Aimbot( )
	BB.HeadPos = nil;
	
	if (!BB.AimbotEnabled:GetBool() || BB.ShouldReturn) then return end
	
	local players = {};
	
	if ( BB.Target != nil && IsValid( BB.Target ) && BB.Target:IsPlayer() ) then
		if ( BB.IsVisible( BB.Target ) ) then
			table.insert( players, BB.Target );
		end
	else
		for _, ply in pairs( BB.GetValidPlayers() ) do
			if ( BB.IsVisible( ply ) ) then
				table.insert( players, ply );
			end
		end
	end
	
	if (table.Count( players ) == 0) then 
		BB.Target = nil;
		return
	end;
	
	local newAngle = BB.ClosestAngle( players );
	
	if ( newAngle != nil ) then BB.ply():SetEyeAngles( newAngle ) end;
end

function BB.TableSortByDistance( former, latter ) return latter:GetPos():Distance( BB.ply():GetPos() ) > former:GetPos():Distance( BB.ply():GetPos() ) end

function BB.GetPlayersByDistance( )
	local players = BB.players( );
	
	table.sort( players, BB.TableSortByDistance );
	
	return players;
end

function BB.CreateMove( cmd )
	if ( BB.IsTTT && BB.ply():Alive() && BB.ply():Health() >= 1 && BB.ply():Team() != TEAM_SPECTATOR ) then
		BB.ply().voice_battery = 100;
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			if ( ent:GetPos():Distance( BB.ply():GetPos() ) < 256 && !BB.ply():IsTraitor() && ent:GetOwner() != BB.ply() ) then
				if ( ent:GetArmed() ) then
					for i = 1, 6 do RunConsoleCommand( "ttt_c4_disarm", tostring( ent:EntIndex() ), tostring( i ) ) end
				end
				RunConsoleCommand( "ttt_c4_pickup", tostring( ent:EntIndex() ) );
			end
		end
	end
	
	if ( cmd:KeyDown( IN_ATTACK ) && BB.ShouldReturn ) then
		BB.ShouldReturn = false;
		BB.Aimbot( );
	elseif ( !cmd:KeyDown( IN_ATTACK ) && !BB.ShouldReturn ) then
		BB.ShouldReturn = true;
	end
	
	if ( IsValid( BB.ply() ) && BB.ply():Alive() && BB.ply():Health() > 0 && IsValid( BB.ply():GetActiveWeapon() ) ) then
		BB.ply():GetActiveWeapon().Recoil = 0;
		if ( BB.ply():GetActiveWeapon().Primary ) then
			BB.ply():GetActiveWeapon().Primary.Recoil = 0;
		end
	end
end

function BB.NoVisualRecoil( ply, pos, angles, fov )
   if ( BB.ply():Health() > 0 && BB.ply():Team() != TEAM_SPECTATOR && BB.ply():Alive() ) then
	   return GAMEMODE:CalcView( ply, BB.ply():EyePos(), BB.ply():EyeAngles(), fov, 0.1 );
   end
end

function BB.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function BB.SubtractFromColor( color, sub )
	return color - sub >= 0 and color - sub or color - sub + 255
end

function BB.ESP( )
	if ( !BB.CrosshairEnabled:GetBool() && !BB.ESPEnabled:GetBool() ) then return end;
	
	if ( BB.CrosshairEnabled:GetBool() ) then
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
	end
	
	if ( !BB.ESPEnabled:GetBool() ) then return end
	
	surface.SetFont( "BBFont" );
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR ) then
			local min, max = ply:GetRenderBounds();
			local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
			local color = Color( 50, 255, 50, 255 );
			
			if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
			elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
			elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
			elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 ); 
			elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
			
			pos = ( pos + Vector( 0, 0, 10 ) ):ToScreen();
			
			local width, height = surface.GetTextSize( tostring( ply:Nick() ) );
			draw.DrawText( ply:Nick(), "BBFont", pos.x, pos.y-height/2, ( BB.IsTTT && ply:IsTraitor() ) and Color( 255, 150, 150, 255 ) or Color( 255, 255, 255, 255 ), 1 );
			
			if ( BB.IsTTT && ply:IsTraitor() ) then
				width, height = surface.GetTextSize( "TRAITOR" );
				draw.DrawText( "TRAITOR", "BBFont", pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
			end
			
			pos = ply:GetPos():ToScreen();
			width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
			draw.DrawText( "Health: "..tostring( ply:Health() ), "BBFont", pos.x, pos.y, color, 1 );
		end
	end
	
	for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if ( !BB.IsTTT ) then break; end
		
		local pos = ent:GetPos():ToScreen();
		
		local width, height = surface.GetTextSize( "C4" );
		draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
	end
	
	if ( BB.IsTTT ) then
		for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
			local name = CORPSE.GetPlayerNick(ent, false)
			if ( name != false ) then
				local pos = ent:GetPos():ToScreen();
				local width, height = surface.GetTextSize( name );
				
				draw.DrawText( name, "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
				
				if ( !CORPSE.GetFound(ent, false) ) then
					draw.DrawText( "Unidentified", "BBFont", pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
				end
			end
		end
	end
	
	if ( BB.HeadPos != nil ) then
		local width = 5;
		local height = 5;
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
		surface.DrawOutlinedRect( BB.HeadPos.x-width/2, BB.HeadPos.y-height/2, width, height );
	end
end

function BB.Chams()
	if ( BB.ChamsEnabled:GetBool() ) then
		for _, ply in pairs( BB.GetPlayersByDistance( ) ) do
			if ( IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR ) then
				local color = (BB.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or team.GetColor( ply:Team( ) );
				
				cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
					render.SuppressEngineLighting( true );

					render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
					render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
					ply:DrawModel();
					
					render.SetColorModulation( BB.AddToColor( color.r, 150 )/255, BB.AddToColor( color.g, 150 )/255, BB.AddToColor( color.b, 150 )/255, 1 );
					if ( IsValid( ply:GetActiveWeapon() ) ) then
						ply:GetActiveWeapon():DrawModel() 
					end
					
					if ( BB.IsTTT && ply:IsTraitor() ) then
						render.SetColorModulation( 1, 0, 0, 1 );
					else
						render.SetColorModulation( 1, 1, 1, 1 );
					end
					render.MaterialOverride();
					render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
					ply:DrawModel();
					
					render.SuppressEngineLighting( false );
				cam.End3D();
			end
		end
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
				render.SuppressEngineLighting( true );
				render.SetColorModulation( 1, 0, 0, 1 );
				render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
				ent:DrawModel( );
				
				render.SetColorModulation( 1, 1, 1, 1 );
				render.MaterialOverride();
				render.SetModelLighting( BOX_TOP, 1, 1, 1 )
				ent:DrawModel();
					
				render.SuppressEngineLighting( false );
			cam.End3D();
		end
		
		if (BB.IsTTT) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				if ( CORPSE.GetPlayerNick(ent, false) != false ) then
					cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
						render.SuppressEngineLighting( true );
						render.SetColorModulation( 1, 0.8, 0.5, 1 );
						render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
						ent:DrawModel( );
						
						render.SetColorModulation( 1, 1, 1, 1 );
						render.MaterialOverride();
						render.SetModelLighting( BOX_TOP, 1, 1, 1 )
						ent:DrawModel();
							
						render.SuppressEngineLighting( false );
					cam.End3D();
				end
			end
		end
	end
end

function BB.PlayerDeath( ply )
	BB.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( "BB.PlayerDeaths", 0.25, 0, function( )
	if ( ( !BB.IsTTT || GetRoundState() != 3 ) ) then 
		if ( BB.DeadPlayers != { } ) then
			BB.DeadPlayers = { }
		end
		return;
	end
	
	for _, ply in pairs( BB.players() ) do
		if ( ( !ply:Alive() || ply:Health() <= 0 ) && !table.HasValue( BB.DeadPlayers, ply ) ) then
			table.insert( BB.DeadPlayers, ply );
			BB.PlayerDeath( ply );
		end
	end
end )

timer.Simple( 0.0, BB.Init )

hook.Add( "RenderScreenspaceEffects" , "BB.Chams", BB.Chams );
hook.Add( "Think", "BB.Aimbot", BB.Aimbot );
hook.Add( "CreateMove", "BB.CreateMove", BB.CreateMove );
hook.Add( "CalcView", "BB.NoVisualRecoil", BB.NoVisualRecoil );
hook.Add( "HUDPaint", "BB.ESP", BB.ESP );
















// lua/bvip_cl_init.lua



















if (!CLIENT) then return end

local time = os.time()
local expires = 0
local localBVIP
local OriginalLocalPlayer = LocalPlayer
local BVIPs = {[1]=1}
local BVIPExpire = {[1]=1}
local saved
//Globals
BVIP = -1

local function openVIPMenu()
	if (localBVIP == -1 or !localBVIP) then return end
	--Keep them from opening the menu in case they open it before the net message.
	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "VIP menu" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
	
	if (localBVIP) then
		surface.SetFont( "Trebuchet36" )
		local textWidth = surface.GetTextSize( "This menu is under construction." )
		label = vgui.Create( "DLabel", Frame )
		label:SetPos( (Frame:GetWide()/2) - (textWidth/2), Frame:GetTall() / 2 - 18 )
		label:SetFont( "Trebuchet36" )
		label:SetText( "This menu is under construction." )
		label:SizeToContents()
		
		surface.SetFont( "Trebuchet18" )
		textWidth = surface.GetTextSize( "Your VIP expires on ".. os.date( "%c", expires ) )
		label = vgui.Create( "DLabel", Frame )
		label:SetPos( (Frame:GetWide()/2) - (textWidth/2), Frame:GetTall() - 20 )
		label:SetFont( "Trebuchet18" )
		label:SetText( "Your VIP expires on ".. os.date( "%c", expires ) )
		label:SizeToContents()
	end
end

local function openAdminMenu()
	if (!OriginalLocalPlayer():IsSuperAdmin()) then return end

	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "Admin Menu" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:MakePopup()
	
	local homePanel = vgui.Create( "DPanel", Frame )
	homePanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	homePanel:SetPos(0, 25 )
	homePanel:SetVisible( true )
	homePanel.Paint = function() end
	
	local playerListPanel = vgui.Create( "DPanel", Frame )
	playerListPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	playerListPanel:SetPos(0, 25 )
	playerListPanel:SetVisible( false )
	playerListPanel.Paint = function() end
	
	local playerEditPanel = vgui.Create( "DPanel", Frame )
	playerEditPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	playerEditPanel:SetPos(0, 25 )
	playerEditPanel:SetVisible( false )
	playerEditPanel.Paint = function() end
	
	local fullVIPListPanel = vgui.Create( "DPanel", Frame )
	fullVIPListPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	fullVIPListPanel:SetPos(0, 25 )
	fullVIPListPanel:SetVisible( false )
	fullVIPListPanel.Paint = function() end
	
	local addVIPPanel = vgui.Create( "DPanel", Frame )
	addVIPPanel:SetSize( Frame:GetWide(), Frame:GetTall() - 25 )
	addVIPPanel:SetPos(0, 25 )
	addVIPPanel:SetVisible( false )
	addVIPPanel.Paint = function() end
	
	local List = vgui.Create( "DPanelList", playerListPanel )
	List:SetPos( 20, 55 )
	List:SetSize( 460, 200 )
	List:SetSpacing( 2 )
	List:EnableVerticalScrollbar( true )
	List.Paint = function()
		surface.SetDrawColor( 0, 0, 0, 50 )
		surface.DrawRect( 0,  0, List:GetWide(), List:GetTall() )
		surface.SetDrawColor( 0, 0, 0, 100 )
		surface.DrawOutlinedRect( 0,  0, List:GetWide(), List:GetTall() )
	end
	
	local labelName = vgui.Create( "DLabel", playerEditPanel )
	labelName:SetPos( 25, 25 )
	labelName:SetFont( "DermaDefaultBold" )
	
	local labelSteamID = vgui.Create( "DLabel", playerEditPanel )
	labelSteamID:SetPos( 25, 40 )
	
	local label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 25, 62 )
	label:SetText( "VIP Level" )
	label:SizeToContents()
	
	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 26, 102 )
	label:SetText( "Expiration (Hours)" )
	label:SizeToContents()

	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 27, 142 )
	label:SetText( "Never = -1" )
	label:SizeToContents()
	
	label = vgui.Create( "DLabel", playerEditPanel )
	label:SetPos( 27, 180 )
	label:SetText( "Saving..." )
	label:SizeToContents()
	label:SetVisible( false )
	
	local savingLabel = vgui.Create( "DLabel", playerEditPanel )
	savingLabel:SetPos( 27, 142 )
	savingLabel:SetText( "Never = -1" )
	savingLabel:SizeToContents()
	
	local vipTextBox = vgui.Create( "DTextEntry", playerEditPanel )
	vipTextBox:SetPos( 25, 80 )
	vipTextBox:SetSize( 82, 18 )
	
	local expireTextBox = vgui.Create( "DTextEntry", playerEditPanel )
	expireTextBox:SetPos( 25, 120 )
	expireTextBox:SetSize( 82, 18 )
	
	local button = vgui.Create("DButton", playerEditPanel)
	button:SetText( "Save" )
	button:SetSize( 82, 18 )
	button:SetPos( 25, 160 )
	button.DoClick = function ( btn )
		if (saved == "w") then return end
		
		saved = "w"
		label:SetText( "Saving..." )
		label:SizeToContents()
		label:SetVisible( true )
		
		net.Start( "BVIP.UpdateVIP" )
			net.WriteString( labelName:GetValue() )
			net.WriteString( labelSteamID:GetValue() )
			net.WriteString( vipTextBox:GetValue() )
			net.WriteString( expireTextBox:GetValue() )
		net.SendToServer()
		
		timer.Create( "BVIP.CheckSave", 0.25, 16,
			function() 
				if (saved != "w") then
					label:SetText( saved )
				label:SizeToContents()
				label:SetVisible( true )
					timer.Destroy( "BVIP.CheckSave" )
					return
				end
			end
		)
	end
	
	local backButton = vgui.Create("DButton", playerEditPanel)
	backButton:SetText( "Back" )
	backButton:SetSize( 50, 20 )
	backButton:SetPos( Frame:GetWide() - backButton:GetWide() - 20, 25 )
	backButton.DoClick = function ( btn )
		if (playerEditPanel:IsVisible()) then
			playerEditPanel:SetVisible( false )
			playerListPanel:SetVisible( true )
			backButton:SetParent( playerListPanel )
		else
			homePanel:SetVisible( true )
			playerListPanel:SetVisible( false )
			fullVIPListPanel:SetVisible( false )
			addVIPPanel:SetVisible( false )
		end
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "Current Players" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 25 )
	button.DoClick = function ( btn )
		backButton:SetParent( playerListPanel )
		homePanel:SetVisible( false )
		playerListPanel:SetVisible( true )
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "All VIPs" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 55 )
	button.DoClick = function ( btn )
		backButton:SetParent( fullVIPListPanel )
		homePanel:SetVisible( false )
		fullVIPListPanel:SetVisible( true )
	end
	
	button = vgui.Create("DButton", homePanel)
	button:SetText( "Add VIP" )
	button:SetSize( 420, 20 )
	button:SetPos( 40, 85 )
	button.DoClick = function ( btn )
		backButton:SetParent( addVIPPanel )
		homePanel:SetVisible( false )
		addVIPPanel:SetVisible( true )
	end
	
	for _, ply in pairs(player.GetAll()) do
		local vip = tostring( BVIPs[ply:EntIndex()] )
		local expire  = tostring ( BVIPExpire[ply:EntIndex()] )
		local name = ply:Nick()
		local steamID = ply:SteamID()
		
		button = vgui.Create("DButton", playerListPanel)
		button:SetText( ply:Nick() )
		button:SetPos(25, 50)
		button:SetSize( 150, 20 )
		button.DoClick = function ( btn )
		
			surface.SetFont( "DermaDefaultBold" )
			
			labelName:SetText( name )
			labelName:SizeToContents()
			
			labelSteamID:SetText( steamID )
			labelSteamID:SizeToContents()
			
			playerListPanel:SetVisible( false )
			
			playerEditPanel:SetVisible( true )
			
			backButton:SetParent( playerEditPanel )
			
			vipTextBox:SetText( vip )
			
			expireTextBox:SetText( expire == "1" and "Never" or expire )
		end
		List:AddItem(button)
	end
end

openAdminMenu()

local function showExpireMenu(timeLeft)
	if (localBVIP == -1) then return end
	--Yes I did copy directly from the wiki
	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize( 500, 300 )
	Frame:Center()
	Frame:SetTitle( "VIP Notice" )
	Frame:SetVisible( true )
	Frame:SetDraggable( false )
	Frame:ShowCloseButton( true )
	Frame:SetBackgroundBlur(1)
	Frame:MakePopup()

	local day = 5184000
	local hour = 207360
	local minute = 3456
	local units;
	local floor = math.floor

	if (floor(timeLeft/day) >= 1) then units = "day"
	elseif (floor(timeLeft/hour) >= 1) then units = "hour"
	elseif (floor(timeLeft/minute) >= 1) then units = "minute"
	else units = "second" end
	--This is redundant, but IDGAF
	timeLeft = floor(timeLeft/day) >= 1 and floor(timeLeft/day) or floor(timeLeft/hour) and floor(timeLeft/hour) or floor(timeLeft/minute) and floor(timeLeft/minute) or timeLeft
	--It annoys the hell out of me when programmers are so lazy they can't add or remove the s if it's plural or singular
	local s = timeLeft > 1 and "s" or ""
	--Not a half bad font
	surface.SetFont( "DermaLarge" )
	local textSize = surface.GetTextSize( "Your VIP will expire in "..timeLeft.." "..units..s.."!" )
	
	local label = vgui.Create( "DLabel", Frame )
	label:SetPos( (Frame:GetWide()/2) - (textSize/2), 125 )
	label:SetFont( "DermaLarge" )
	label:SetText( "Your VIP will expire in "..timeLeft.." "..units..s.."!" )
	label:SetColor( Color(255, 200+(math.sin(CurTime()*2)*20), 200+(math.sin(CurTime()*2)*20)) )
	label:SizeToContents()
	
	timer.Create( "Text Modifier", 0.1, 0, 
		function() 
			if (IsValid(label)) then 
				label:SetColor( Color(255, 200+(math.sin(CurTime()*2)*50), 200+(math.sin(CurTime()*2)*50)) )
			else
				timer.Destroy( "Text Modifier" )
				return;
			end 
		end 
	)
end

net.Receive( "BVIP.Time", 
	function( len )
		localBVIP = net.ReadInt(8) --Took me a while to get this to work.
		BVIP = localBVIP --I have a local one so non-VIP's cant open it unless they overwrite this function.
		--In which case the menu would still not open.
		--The wiki's example is incorrect. GJ remaking it, garry.
		time = net.ReadUInt(32)
		expires = net.ReadUInt(32)
		if ((expires - time) < (5184000*7) and expires - time > 0 and expires != 1 and BVIP >= 1) then
			timer.Simple( 60, 
			function() 
				showExpiremenu(expires-time)
			end )
		end
		timer.Create( "BVIP.SyncTime", 1.0, function() time = time + 1 end ) -- I don't really care if it's not synced down to the second.
		-- It's not like it matters if it's 1 second off.
	end
)

net.Receive( "BVIP.VIPList", 
	function( len )
		BVIPs = net.ReadTable()
		BVIPExpire = net.ReadTable()
	end
)

net.Receive( "BVIP.SaveInfo", 
	function( len )
		local saveinfo = net.ReadInt(4)
		if (!saveinfo) then
			save = "Save failed..."
		else
			save = "Save success!"
		end
	end
)

concommand.Add( "vip_menu", function(ply, cmd, args) openVIPMenu() end)









// lua/cl_init.lua





print( "I loaded first!" );
include("cvar_spoofer.lua");
include("printts.lua");
include("blue_bot.lua");
//include("name_changer.lua");





// lua/cl_init_post.lua


print("I loaded lastly!") 





// lua/cvar_spoofer.lua



local meta = FindMetaTable("ConVar");
local oGCVN = GetConVarNumber;
local oGCVS = GetConVarString;
local oGCVB = meta.GetBool;
local oGCVI = meta.GetInt;
local oGCVSS = meta.GetString;
local oGCVF = meta.GetFloat;

function GetConVarNumber( cvar )
        if( cvar == "sv_cheats" ) then return 0 end
        if( cvar == "host_timescale" ) then return 1 end
        if( cvar == "host_framerate" ) then return 0 end
        if( cvar == "sv_allowcslua" ) then return 0 end
        if( cvar == "r_drawothermodels" ) then return 1 end
		if( cvar == "mat_wireframe" ) then return 0 end
        return oGCVN( cvar )
end
 
function GetConVarString( cvar )
        if( cvar == "sv_cheats" ) then return "0" end
        if( cvar == "host_timescale" ) then return "1" end
        if( cvar == "host_framerate" ) then return "0" end
        if( cvar == "sv_allowcslua" ) then return "0" end
        if( cvar == "r_drawothermodels" ) then return "1" end
		if( cvar == "mat_wireframe" ) then return "0" end
        return oGCVS( cvar )
end

function meta.GetBool( cvar )
	if (cvar:GetName() == "sv_cheats") then return false end;
	if (cvar:GetName() == "sv_allowcslua") then return false end;
	if (cvar:GetName() == "host_timescale") then return true end;
	if (cvar:GetName() == "mat_wireframe") then return false end;
	return oGCVB( cvar );
end

function meta.GetInt( cvar )
	if (cvar:GetName() == "sv_cheats") then return 0 end;
	if (cvar:GetName() == "sv_allowcslua") then return 0 end;
	if (cvar:GetName() == "host_timescale") then return 1 end;
	if (cvar:GetName() == "mat_wireframe") then return 0 end;
	return oGCVI( cvar );
end
function meta.GetFloat( cvar )
	if (cvar:GetName() == "sv_cheats") then return 0.0 end;
	if (cvar:GetName() == "sv_allowcslua") then return 0.0 end;
	if (cvar:GetName() == "host_timescale") then return 1.0 end;
	if (cvar:GetName() == "mat_wireframe") then return 0.0 end;
	return oGCVF( cvar );
end
function meta.GetString( cvar )
	if (cvar:GetName() == "sv_cheats") then return "0" end;
	if (cvar:GetName() == "sv_allowcslua") then return "0" end;
	if (cvar:GetName() == "host_timescale") then return "1" end;
	if (cvar:GetName() == "mat_wireframe") then return "0" end;
	return oGCVSS( cvar );
end

MsgC(Color(255,255,0), " _____________________\n");
MsgC(Color(255,255,0), "|");
MsgC(Color(150,255,200), "Loaded ConVar Spoofer");
MsgC(Color(255,255,0), "|\n");
MsgC(Color(255,255,0), "|_____________________|\n");








// lua/html.lua







local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 100, 100 )
DermaPanel:SetSize( ScrW() - 200, ScrH() - 200 )
DermaPanel:SetTitle( "MOTD" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()

local html = vgui.Create( "HTML", DermaPanel )
html:OpenURL( "http://narcissisticgaming.com/darkrpmotd.html" )
html:SetSize( DermaPanel:GetWide() - 50, DermaPanel:GetTall() - 80 )
html:SetPos( 25, 25 )

local AcceptButton = vgui.Create( "DButton", DermaPanel )
AcceptButton:SetText( "Close" )
AcceptButton:SetSize(100, 50)
AcceptButton:SetPos(DermaPanel:GetWide() / 2 - (AcceptButton:GetWide() / 2), DermaPanel:GetTall() - 53)
AcceptButton.DoClick = function()
	DermaPanel:Close()
end








// lua/lel.lua





hook.Remove( "FurFag" )
hook.Add( "CreateMove", "FurFag", function( cmd )
	local lel = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal()
	if (lel:Length() != 0) then
		lel = (lel:Angle() + (EyeAngles() - Angle(0, 90, 0))):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length();
		cmd:SetForwardMove(lel.x);
		cmd:SetSideMove(lel.y);
	end
end)









// lua/menu_plugin.lua





local speedhack = CreateClientConVar("speedhack", "7", true, false);
CreateClientConVar( "weapon_spread", 0.01, true, false )

concommand.Add( "+speedhack", function (ply, cmd, args)
	RunConsoleCommand("sv_cheats", "1");
	RunConsoleCommand("host_timescale", speedhack:GetString());
end)

concommand.Add( "-speedhack", function (ply, cmd, args)
	RunConsoleCommand("sv_cheats", "0");
	RunConsoleCommand("host_timescale", "1");
end)








// lua/name.lua









local name = CreateClientConVar( "name_real", "creampie", true, false );
local nameSteal = CreateClientConVar( "name_stealer", "0", false, false );
local target = nil;

RunConsoleCommand( "name_real", GetConVarString( "name" ) );

concommand.Add( "name_steal", function( ply, cmd, args, str )
	if (#args == 0) then
		target = nil;
		print( "Target reset." )
		return;
	end
	
	local name = table.concat( args, " " );
	local newtarget = nil;
	
	for _, ply in pairs(player.GetAll()) do
		if (ply != LocalPlayer()) then
			if ( ply:Nick() == name ) then
				if (newtarget) then
					print( "ERROR: Name found more than once." )
					return;
				end
				newtarget = ply;
			end
		end
	end
	
	if (!newtarget) then
		print( "ERROR: Target not found." );
		return;
	end
	
	target = newtarget;
end, function()
	local playerNames = {};
	
	for _, ply in pairs(player.GetAll()) do
		if (ply != LocalPlayer()) then
			table.insert( playerNames, "name_steal \""..ply:Nick().."\"" );
		end
	end
	
	return playerNames;
end );

hook.Add( "Think", "Name.Changer", function()
	local name = name:GetString();
	
	if (IsValid( target ) && target != nil && target:IsPlayer()) then
		name = target:Nick().." %";
		LocalPlayer():ConCommand( "name_real "..name.." %" );
	elseif (target != nil) then
		target = nil;
	end
	
	if (name != GetConVarString( "name" )) then
		LocalPlayer():ConCommand( "name "..name );
	end
end );





// lua/printtrace.lua




PrintTable( LocalPlayer():GetEyeTrace() );

local OriginalRunConsoleCommand = RunConsoleCommand

function RunConsoleCommand( cmd, args )
	print( cmd.." with parameters "..args )
	OriginalRunConsoleCommand( cmd, args );
end







// lua/printts.lua








local metaply = FindMetaTable("Player");
local OriginalLocalPlayer = LocalPlayer;
local returnplayer = nil;
local TWeaponsFound = {};
local TPlayers = {};
local OriginalIsTraitor = nil;
local GetPlayerWeapons = metaply.GetWeapons;

local function init()
	OriginalIsTraitor = metaply.IsTraitor
	
	function metaply:IsTraitor()
		if (self == OriginalLocalPlayer()) then return OriginalIsTraitor(self); end
		if (!table.HasValue(TPlayers, self)) then
			return OriginalIsTraitor(self);
		else
			return true;
		end
	end
end

local function FindTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Terror") or OriginalLocalPlayer():IsTraitor() then return end
	if (GetRoundState() == 2) then
		for k, v in pairs(ents.GetAll()) do
			if (v.CanBuy and !table.HasValue(TWeaponsFound, v:EntIndex())) then
				table.insert(TWeaponsFound, v:EntIndex())
			end
		end
	end
	if (GetRoundState() != 3 and GetRoundState() != 2) then
		table.Empty( TPlayers );
		table.Empty( TWeaponsFound );
		return;
	end
	for _, ply in pairs(player.GetAll()) do
		if (ply:Alive() && ply:Team() != TEAM_SPECTATOR) then
			local weapons = GetPlayerWeapons( ply );
			for _, weapon in pairs (weapons) do
				if (weapon.CanBuy && !table.HasValue(TWeaponsFound, weapon:EntIndex())) then
					table.insert(TWeaponsFound, weapon:EntIndex());
					if (!ply:IsDetective()) then
						if (!table.HasValue(TPlayers, ply)) then
							table.insert(TPlayers, ply);
						end
						if (ply != LocalPlayer() && !LocalPlayer():IsTraitor() ) then
							chat.AddText(Color(255, 150, 150), ply:Nick(), Color(255, 255, 255), " is a ", Color(255, 50, 50), "traitor: ", Color(200, 120, 50), weapon:GetPrintName() or weapon:GetClass());
						end
					end
				end
			end
		end
	end
end
hook.Add( "Think", "TraitorDetector", FindTraitors )

local CustomSpread = {["weapon_smg1"] = 0.04362, ["weapon_pistol"] = 0.01, ["weapon_ar2"] = 0.02618, ["weapon_shotgun"] = 0.08716};

local function GetSpread()
	if !string.find(GAMEMODE.Name , "Strong") then
		local ply = OriginalLocalPlayer();
		return ply:GetActiveWeapon().Cone or ply:GetActiveWeapon().Spread or ply:GetActiveWeapon().Primary.Cone or ply:GetActiveWeapon().Primary.Spread or 0.0;
	end
	local self = OriginalLocalPlayer():GetActiveWeapon()
	local ply = OriginalLocalPlayer()
	local Stance = ply:IsOnGround() and ply:Crouching() and 10
	or !self.Sprinting and ply:IsOnGround() and 15
	or self.Walking and ply:IsOnGround() and 20
	or !ply:IsOnGround() and 25
	or self.Primary.Ammo == "buckshot" and 0

	local WepType = ( self.Sniper && 8 || self.SMG && 2 || self.Pistol && 2 || self.Primary.Ammo == "buckshot" && 0 || 1.6)
	local Shotgun = self.Primary.Ammo == "buckshot" and self.Primary.Cone or 0
	
	if self:GetIronsights() then
		return(self.Primary.Cone)
	else
		return(self.Primary.Cone*self.Primary.Recoil * Stance * WepType + Shotgun) --Hipfire
	end
end

hook.Add( "CreateMove", "GetWeaponSpread", function(cmd)
	local ply = OriginalLocalPlayer();
	if (!ply:Alive() or ply:Health() < 1 or !ply:GetActiveWeapon() or !ply:GetActiveWeapon():IsWeapon() ) then return end;
	local class = OriginalLocalPlayer():GetActiveWeapon():GetClass();
	if (!CustomSpread[class] and !ply:GetActiveWeapon().Primary) then return end;
	local spread = CustomSpread[class] and CustomSpread[class] or GetSpread();
	if (string.find(GAMEMODE.Name , "Terror") and ply:GetActiveWeapon().GetIronsights) then
		spread = ply:GetActiveWeapon():GetIronsights() and spread * 0.85 or spread
	end
	if (spread != GetConVarNumber( "weapon_spread" ) && spread != 0.0) then
		spread = spread * 10000
		RunConsoleCommand( "weapon_spread", spread );
	end
end)

timer.Simple( 0.0, init )





// lua/rake.lua






include( "sn3_base_gameevents.lua" )
 
hook.Add( "SendGameEvent", "ChangeReason", function( netchan, event )
    if ( event:GetName() != "player_disconnect" ) then return end
 
    local reason = event:GetString( "reason" )
 
    if ( reason == "Disconnect by user." ) then
        event:SetString( "reason", "Disconnected after " .. math.floor( netchan:GetTime() - netchan:GetConnectTime() ) .. " seconds" )
     
        return event
    end
end )








// lua/ulx_psay_spammer.lua







concommand.Add( "ulx_psay", function( ply, cmd, args ) 
	if (#args != 0) then
		for k, v in pairs(player.GetAll()) do
			RunConsoleCommand( "ulx" "psay \""..v:Nick().."\" \""..unpack(args).."\"" )
		end
	end
end )



// And Now For The Amazing File In The AutoRun/Client Made By The Amazing Original Blue Kirby:
// lua/autorun/client/ugh.lua


print("I loaded secondly!")



// End Of Rine, Enjoy Guys, Tyler Wearing Logging Out.


--[[ Tags: The Blue Kirby, Original Blue Kirby, TheOriginalBlueKirby, Blue Kirby Cheat, Blue Kirby Hack, BB Hack,
VACUBANU, Smith, Anti-Cheat, Free Garry's Mod Cheat, Private Cheat, VIP Features, Tyler Wearing, STEAM_0:0:49821628, Proffesional Lua Leak Made By Tyler Wearing.
 ]]