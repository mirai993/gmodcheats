--[[
	lua/bubber_ducky.lua
	the creampie kid | (STEAM_0:0:49821628)
	===DStream===
]]

local BB = { };
local LocalPlayer = LocalPlayer;
BB.DeadPlayers = { };
BB.ply = LocalPlayer;
BB.players = player.GetAll;
BB.Target = nil;
BB.ShouldReturn = false;
BB.AimbotEnabled = CreateClientConVar( "blue_bot_aimbot_enabled", "0", true, false );
BB.MaxAngle = CreateClientConVar( "blue_bot_aimbot_max_angle", "30", true, false );
BB.FriendlyFire = CreateClientConVar( "blue_bot_aimbot_friendly_fire", "1", true, false );
BB.ESPEnabled = CreateClientConVar( "blue_bot_esp_enabled", "1", true, false );
BB.ChamsEnabled = CreateClientConVar( "blue_bot_chams_enabled", "1", true, false );
BB.CrosshairEnabled = CreateClientConVar( "blue_bot_crosshair_enabled", "1", true, false );
BB.HeadPos = nil;
BB.TraceRes = nil;
BB.IsTTT = false;

function BB.Init( )
	surface.CreateFont( "BBFont", { font = "Arial", size = 14, weight = 750, antialias = false, outline = true } );
	BB.IsTTT = string.find( GAMEMODE.Name , "Terror" );
	return 0;
end

function BB.Print( color, message )
	MsgC( Color( 50, 100, 255 ), "[Blue Bot] " );
	MsgC( color, message.."\n" );
	
	return 0;
end

function BB.PrintChat( color, message )
	chat.AddText( Color( 50, 100, 255 ), "[Blue Bot] ", color, message );
	
	return 0;
end

function BB.Error( error )
	MsgC( Color( 255, 50, 50 ), "[Blue Bot] ERROR: " );
	MsgC( Color( 255, 255, 255 ), error.."\n" );
	
	return 0;
end

function BB.IsOnTeam( ply )
	if ( BB.IsTTT ) then
		return ply:IsTraitor() == BB.ply():IsTraitor();
	else
		return ply:Team() == BB.ply():Team();
	end
end

function BB.GetValidPlayers( )
	local players = { };
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply && IsValid( ply ) && 
		ply:IsPlayer() && 
		ply:Alive() && 
		ply:Health() >= 1 &&
		( !BB.IsOnTeam( ply ) || BB.FriendlyFire:GetBool() ) ) then
			table.insert( players, ply );
		end
	end
	
	return players
end

function BB.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = BB.ply():EyePos(), endpos = vecPos, filter = BB.ply(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
	
	BB.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function BB.ClosestAngle( players )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = BB.ply():EyeAngles();
	
	for _, ply in pairs( players ) do
		local vecPos, ang = ply:GetBonePosition( 14 or ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
		local oldpos = vecPos;
		vecPos = vecPos - BB.VelocityPrediction( BB.ply() ) + BB.VelocityPrediction( ply )
		local angAngle = ( vecPos - BB.ply():EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (!BB.MaxAngle:GetFloat() || flDif < BB.MaxAngle:GetFloat())) then
			BB.HeadPos = oldpos:ToScreen();
			BB.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle;
end

function BB.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function BB.Aimbot( )
	BB.HeadPos = nil;
	
	if (!BB.AimbotEnabled:GetBool() || BB.ShouldReturn) then return end
	
	local players = {};
	
	if ( BB.Target != nil && IsValid( BB.Target ) && BB.Target:IsPlayer() ) then
		if ( BB.IsVisible( BB.Target ) ) then
			table.insert( players, BB.Target );
		end
	else
		for _, ply in pairs( BB.GetValidPlayers() ) do
			if ( BB.IsVisible( ply ) ) then
				table.insert( players, ply );
			end
		end
	end
	
	if (table.Count( players ) == 0) then 
		BB.Target = nil;
		return
	end;
	
	local newAngle = BB.ClosestAngle( players );
	
	if ( newAngle != nil ) then BB.ply():SetEyeAngles( newAngle ) end;
end

function BB.TableSortByDistance( former, latter ) return latter:GetPos():Distance( BB.ply():GetPos() ) > former:GetPos():Distance( BB.ply():GetPos() ) end

function BB.GetPlayersByDistance( )
	local players = BB.players( );
	
	table.sort( players, BB.TableSortByDistance );
	
	return players;
end

function BB.CreateMove( cmd )
	if ( BB.IsTTT && BB.ply():Alive() && BB.ply():Health() >= 1 && BB.ply():Team() != TEAM_SPECTATOR ) then
		BB.ply().voice_battery = 100;
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			if ( ent:GetPos():Distance( BB.ply():GetPos() ) < 256 && !BB.ply():IsTraitor() && ent:GetOwner() != BB.ply() ) then
				if ( ent:GetArmed() ) then
					for i = 1, 6 do RunConsoleCommand( "ttt_c4_disarm", tostring( ent:EntIndex() ), tostring( i ) ) end
				end
				RunConsoleCommand( "ttt_c4_pickup", tostring( ent:EntIndex() ) );
			end
		end
	end
	
	if ( cmd:KeyDown( IN_ATTACK ) && BB.ShouldReturn ) then
		BB.ShouldReturn = false;
		BB.Aimbot( );
	elseif ( !cmd:KeyDown( IN_ATTACK ) && !BB.ShouldReturn ) then
		BB.ShouldReturn = true;
	end
	
	if ( IsValid( BB.ply() ) && BB.ply():Alive() && BB.ply():Health() > 0 && IsValid( BB.ply():GetActiveWeapon() ) ) then
		BB.ply():GetActiveWeapon().Recoil = 0;
		if ( BB.ply():GetActiveWeapon().Primary ) then
			BB.ply():GetActiveWeapon().Primary.Recoil = 0;
		end
	end
end

function BB.NoVisualRecoil( ply, pos, angles, fov )
   if ( BB.ply():Health() > 0 && BB.ply():Team() != TEAM_SPECTATOR && BB.ply():Alive() ) then
	   return GAMEMODE:CalcView( ply, BB.ply():EyePos(), BB.ply():EyeAngles(), fov, 0.1 );
   end
end

function BB.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function BB.SubtractFromColor( color, sub )
	return color - sub >= 0 and color - sub or color - sub + 255
end

function BB.ESP( )
	if ( !BB.CrosshairEnabled:GetBool() && !BB.ESPEnabled:GetBool() ) then return end;
	
	if ( BB.CrosshairEnabled:GetBool() ) then
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
	end
	
	if ( !BB.ESPEnabled:GetBool() ) then return end
	
	surface.SetFont( "BBFont" );
	
	for _, ply in pairs( BB.players() ) do
		if ( ply != BB.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR ) then
			local min, max = ply:GetRenderBounds();
			local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
			local color = Color( 50, 255, 50, 255 );
			
			if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
			elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
			elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
			elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 ); 
			elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
			
			pos = ( pos + Vector( 0, 0, 10 ) ):ToScreen();
			
			local width, height = surface.GetTextSize( tostring( ply:Nick() ) );
			draw.DrawText( ply:Nick(), "BBFont", pos.x, pos.y-height/2, ( BB.IsTTT && ply:IsTraitor() ) and Color( 255, 150, 150, 255 ) or Color( 255, 255, 255, 255 ), 1 );
			
			if ( BB.IsTTT && ply:IsTraitor() ) then
				width, height = surface.GetTextSize( "TRAITOR" );
				draw.DrawText( "TRAITOR", "BBFont", pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
			end
			
			pos = ply:GetPos():ToScreen();
			width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
			draw.DrawText( "Health: "..tostring( ply:Health() ), "BBFont", pos.x, pos.y, color, 1 );
		end
	end
	
	for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if ( !BB.IsTTT ) then break; end
		
		local pos = ent:GetPos():ToScreen();
		
		local width, height = surface.GetTextSize( "C4" );
		draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
	end
	
	if ( BB.IsTTT ) then
		for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
			local name = CORPSE.GetPlayerNick(ent, false)
			if ( name != false ) then
				local pos = ent:GetPos():ToScreen();
				local width, height = surface.GetTextSize( name );
				
				draw.DrawText( name, "BBFont", pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
				
				if ( !CORPSE.GetFound(ent, false) ) then
					draw.DrawText( "Unidentified", "BBFont", pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
				end
			end
		end
	end
	
	if ( BB.HeadPos != nil ) then
		local width = 5;
		local height = 5;
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
		surface.DrawOutlinedRect( BB.HeadPos.x-width/2, BB.HeadPos.y-height/2, width, height );
	end
end

function BB.Chams()
	if ( BB.ChamsEnabled:GetBool() ) then
		for _, ply in pairs( BB.GetPlayersByDistance( ) ) do
			if ( IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR ) then
				local color = (BB.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or team.GetColor( ply:Team( ) );
				
				cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
					render.SuppressEngineLighting( true );

					render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
					render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
					ply:DrawModel();
					
					render.SetColorModulation( BB.AddToColor( color.r, 150 )/255, BB.AddToColor( color.g, 150 )/255, BB.AddToColor( color.b, 150 )/255, 1 );
					if ( IsValid( ply:GetActiveWeapon() ) ) then
						ply:GetActiveWeapon():DrawModel() 
					end
					
					if ( BB.IsTTT && ply:IsTraitor() ) then
						render.SetColorModulation( 1, 0, 0, 1 );
					else
						render.SetColorModulation( 1, 1, 1, 1 );
					end
					render.MaterialOverride();
					render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
					ply:DrawModel();
					
					render.SuppressEngineLighting( false );
				cam.End3D();
			end
		end
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
				render.SuppressEngineLighting( true );
				render.SetColorModulation( 1, 0, 0, 1 );
				render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
				ent:DrawModel( );
				
				render.SetColorModulation( 1, 1, 1, 1 );
				render.MaterialOverride();
				render.SetModelLighting( BOX_TOP, 1, 1, 1 )
				ent:DrawModel();
					
				render.SuppressEngineLighting( false );
			cam.End3D();
		end
		
		if (BB.IsTTT) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				if ( CORPSE.GetPlayerNick(ent, false) != false ) then
					cam.Start3D( BB.ply():EyePos(), BB.ply():EyeAngles() );
						render.SuppressEngineLighting( true );
						render.SetColorModulation( 1, 0.8, 0.5, 1 );
						render.MaterialOverride( CreateMaterial( "bb_mat", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ) );
						ent:DrawModel( );
						
						render.SetColorModulation( 1, 1, 1, 1 );
						render.MaterialOverride();
						render.SetModelLighting( BOX_TOP, 1, 1, 1 )
						ent:DrawModel();
							
						render.SuppressEngineLighting( false );
					cam.End3D();
				end
			end
		end
	end
end

function BB.PlayerDeath( ply )
	BB.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( "BB.PlayerDeaths", 0.25, 0, function( )
	if ( ( !BB.IsTTT || GetRoundState() != 3 ) ) then 
		if ( BB.DeadPlayers != { } ) then
			BB.DeadPlayers = { }
		end
		return;
	end
	
	for _, ply in pairs( BB.players() ) do
		if ( ( !ply:Alive() || ply:Health() <= 0 ) && !table.HasValue( BB.DeadPlayers, ply ) ) then
			table.insert( BB.DeadPlayers, ply );
			BB.PlayerDeath( ply );
		end
	end
end )

timer.Simple( 0.0, BB.Init )

hook.Add( "RenderScreenspaceEffects" , "BB.Chams", BB.Chams );
hook.Add( "Think", "BB.Aimbot", BB.Aimbot );
hook.Add( "CreateMove", "BB.CreateMove", BB.CreateMove );
hook.Add( "CalcView", "BB.NoVisualRecoil", BB.NoVisualRecoil );
hook.Add( "HUDPaint", "BB.ESP", BB.ESP );