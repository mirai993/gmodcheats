--[[
	lua/printts.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

local metaply = FindMetaTable("Player");
local OriginalLocalPlayer = LocalPlayer;
local returnplayer = nil;
local TWeaponsFound = {};
local TPlayers = {};
local OriginalIsTraitor = nil;
local GetPlayerWeapons = metaply.GetWeapons;

local function init()
	OriginalIsTraitor = metaply.IsTraitor
	
	function metaply:IsTraitor()
		if (self == OriginalLocalPlayer()) then return OriginalIsTraitor(self); end
		if (!table.HasValue(TPlayers, self)) then
			return OriginalIsTraitor(self);
		else
			return true;
		end
	end
end

local function FindTraitors()
	if not GAMEMODE or not GAMEMODE.Name or not string.find(GAMEMODE.Name , "Terror") or OriginalLocalPlayer():IsTraitor() then return end
	if (GetRoundState() == 2) then
		for k, v in pairs(ents.GetAll()) do
			if (v.CanBuy and !table.HasValue(TWeaponsFound, v:EntIndex())) then
				table.insert(TWeaponsFound, v:EntIndex())
			end
		end
	end
	if (GetRoundState() != 3 and GetRoundState() != 2) then
		table.Empty( TPlayers );
		table.Empty( TWeaponsFound );
		return;
	end
	for _, ply in pairs(player.GetAll()) do
		if (ply:Alive() && ply:Team() != TEAM_SPECTATOR) then
			local weapons = GetPlayerWeapons( ply );
			for _, weapon in pairs (weapons) do
				if (weapon.CanBuy && !table.HasValue(TWeaponsFound, weapon:EntIndex())) then
					table.insert(TWeaponsFound, weapon:EntIndex());
					if (!ply:IsDetective()) then
						if (!table.HasValue(TPlayers, ply)) then
							table.insert(TPlayers, ply);
						end
						if (ply != LocalPlayer() && !LocalPlayer():IsTraitor() ) then
							chat.AddText(Color(255, 150, 150), ply:Nick(), Color(255, 255, 255), " is a ", Color(255, 50, 50), "traitor: ", Color(200, 120, 50), weapon:GetPrintName() or weapon:GetClass());
						end
					end
				end
			end
		end
	end
end
hook.Add( "Think", "TraitorDetector", FindTraitors )

local CustomSpread = {["weapon_smg1"] = 0.04362, ["weapon_pistol"] = 0.01, ["weapon_ar2"] = 0.02618, ["weapon_shotgun"] = 0.08716};

local function GetSpread()
	if !string.find(GAMEMODE.Name , "Strong") then
		local ply = OriginalLocalPlayer();
		return ply:GetActiveWeapon().Cone or ply:GetActiveWeapon().Spread or ply:GetActiveWeapon().Primary.Cone or ply:GetActiveWeapon().Primary.Spread or 0.0;
	end
	local self = OriginalLocalPlayer():GetActiveWeapon()
	local ply = OriginalLocalPlayer()
	local Stance = ply:IsOnGround() and ply:Crouching() and 10
	or !self.Sprinting and ply:IsOnGround() and 15
	or self.Walking and ply:IsOnGround() and 20
	or !ply:IsOnGround() and 25
	or self.Primary.Ammo == "buckshot" and 0

	local WepType = ( self.Sniper && 8 || self.SMG && 2 || self.Pistol && 2 || self.Primary.Ammo == "buckshot" && 0 || 1.6)
	local Shotgun = self.Primary.Ammo == "buckshot" and self.Primary.Cone or 0
	
	if self:GetIronsights() then
		return(self.Primary.Cone)
	else
		return(self.Primary.Cone*self.Primary.Recoil * Stance * WepType + Shotgun) --Hipfire
	end
end

hook.Add( "CreateMove", "GetWeaponSpread", function(cmd)
	local ply = OriginalLocalPlayer();
	if (!ply:Alive() or ply:Health() < 1 or !ply:GetActiveWeapon() or !ply:GetActiveWeapon():IsWeapon() ) then return end;
	local class = OriginalLocalPlayer():GetActiveWeapon():GetClass();
	if (!CustomSpread[class] and !ply:GetActiveWeapon().Primary) then return end;
	local spread = CustomSpread[class] and CustomSpread[class] or GetSpread();
	if (string.find(GAMEMODE.Name , "Terror") and ply:GetActiveWeapon().GetIronsights) then
		spread = ply:GetActiveWeapon():GetIronsights() and spread * 0.85 or spread
	end
	if (spread != GetConVarNumber( "weapon_spread" ) && spread != 0.0) then
		spread = spread * 10000
		RunConsoleCommand( "weapon_spread", spread );
	end
end)

timer.Simple( 0.0, init )