--[[
	lua/lel.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

hook.Remove( "FurFag" )
hook.Add( "CreateMove", "FurFag", function( cmd )
	local lel = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal()
	if (lel:Length() != 0) then
		lel = (lel:Angle() + (EyeAngles() - Angle(0, 90, 0))):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length();
		cmd:SetForwardMove(lel.x);
		cmd:SetSideMove(lel.y);
	end
end)