--[[
	lua/name_.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

local name = CreateClientConVar( "name_real", "creampie", true, false );
local nameSteal = CreateClientConVar( "name_stealer", "0", false, false );
local target = nil;

RunConsoleCommand( "name_real", GetConVarString( "name" ) );

concommand.Add( "name_steal", function( ply, cmd, args, str )
	if (#args == 0) then
		target = nil;
		print( "Target reset." )
		return;
	end
	
	local name = table.concat( args, " " );
	local newtarget = nil;
	
	for _, ply in pairs(player.GetAll()) do
		if (ply != LocalPlayer()) then
			if ( ply:Nick() == name ) then
				if (newtarget) then
					print( "ERROR: Name found more than once." )
					return;
				end
				newtarget = ply;
			end
		end
	end
	
	if (!newtarget) then
		print( "ERROR: Target not found." );
		return;
	end
	
	target = newtarget;
end, function()
	local playerNames = {};
	
	for _, ply in pairs(player.GetAll()) do
		if (ply != LocalPlayer()) then
			table.insert( playerNames, "name_steal \""..ply:Nick().."\"" );
		end
	end
	
	return playerNames;
end );

hook.Add( "Think", "Name.Changer", function()
	local name = name:GetString();
	
	if (IsValid( target ) && target != nil && target:IsPlayer()) then
		name = target:Nick().." %";
		LocalPlayer():ConCommand( "name_real "..name.." %" );
	elseif (target != nil) then
		target = nil;
	end
	
	if (name != GetConVarString( "name" )) then
		LocalPlayer():ConCommand( "name "..name );
	end
end );