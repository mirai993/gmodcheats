--[[
	lua/cl_init_post.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

print("I loaded lastly!") 