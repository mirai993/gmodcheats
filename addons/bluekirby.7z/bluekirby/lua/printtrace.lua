--[[
	lua/printtrace.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

PrintTable( LocalPlayer():GetEyeTrace() );

local OriginalRunConsoleCommand = RunConsoleCommand

function RunConsoleCommand( cmd, args )
	print( cmd.." with parameters "..args )
	OriginalRunConsoleCommand( cmd, args );
end