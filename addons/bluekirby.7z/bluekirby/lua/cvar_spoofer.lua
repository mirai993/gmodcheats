--[[
	lua/cvar_spoofer.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

local meta = FindMetaTable("ConVar");
local oGCVN = GetConVarNumber;
local oGCVS = GetConVarString;
local oGCVB = meta.GetBool;
local oGCVI = meta.GetInt;
local oGCVSS = meta.GetString;
local oGCVF = meta.GetFloat;

function GetConVarNumber( cvar )
        if( cvar == "sv_cheats" ) then return 0 end
        if( cvar == "host_timescale" ) then return 1 end
        if( cvar == "host_framerate" ) then return 0 end
        if( cvar == "sv_allowcslua" ) then return 0 end
        if( cvar == "r_drawothermodels" ) then return 1 end
		if( cvar == "mat_wireframe" ) then return 0 end
        return oGCVN( cvar )
end
 
function GetConVarString( cvar )
        if( cvar == "sv_cheats" ) then return "0" end
        if( cvar == "host_timescale" ) then return "1" end
        if( cvar == "host_framerate" ) then return "0" end
        if( cvar == "sv_allowcslua" ) then return "0" end
        if( cvar == "r_drawothermodels" ) then return "1" end
		if( cvar == "mat_wireframe" ) then return "0" end
        return oGCVS( cvar )
end

function meta.GetBool( cvar )
	if (cvar:GetName() == "sv_cheats") then return false end;
	if (cvar:GetName() == "sv_allowcslua") then return false end;
	if (cvar:GetName() == "host_timescale") then return true end;
	if (cvar:GetName() == "mat_wireframe") then return false end;
	return oGCVB( cvar );
end

function meta.GetInt( cvar )
	if (cvar:GetName() == "sv_cheats") then return 0 end;
	if (cvar:GetName() == "sv_allowcslua") then return 0 end;
	if (cvar:GetName() == "host_timescale") then return 1 end;
	if (cvar:GetName() == "mat_wireframe") then return 0 end;
	return oGCVI( cvar );
end
function meta.GetFloat( cvar )
	if (cvar:GetName() == "sv_cheats") then return 0.0 end;
	if (cvar:GetName() == "sv_allowcslua") then return 0.0 end;
	if (cvar:GetName() == "host_timescale") then return 1.0 end;
	if (cvar:GetName() == "mat_wireframe") then return 0.0 end;
	return oGCVF( cvar );
end
function meta.GetString( cvar )
	if (cvar:GetName() == "sv_cheats") then return "0" end;
	if (cvar:GetName() == "sv_allowcslua") then return "0" end;
	if (cvar:GetName() == "host_timescale") then return "1" end;
	if (cvar:GetName() == "mat_wireframe") then return "0" end;
	return oGCVSS( cvar );
end

MsgC(Color(255,255,0), " _____________________\n");
MsgC(Color(255,255,0), "|");
MsgC(Color(150,255,200), "Loaded ConVar Spoofer");
MsgC(Color(255,255,0), "|\n");
MsgC(Color(255,255,0), "|_____________________|\n");