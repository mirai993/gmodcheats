--[[
	lua/cl_init.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

print( "I loaded first!" );
include("cvar_spoofer.lua");
include("printts.lua");
include("blue_bot.lua");
//include("name_changer.lua");