--[[
	lua/menu_plugin.lua
	VACUBANU | (STEAM_0:0:49821628)
	===DStream===
]]

local speedhack = CreateClientConVar("speedhack", "7", true, false);
CreateClientConVar( "weapon_spread", 0.01, true, false )

concommand.Add( "+speedhack", function (ply, cmd, args)
	RunConsoleCommand("sv_cheats", "1");
	RunConsoleCommand("host_timescale", speedhack:GetString());
end)

concommand.Add( "-speedhack", function (ply, cmd, args)
	RunConsoleCommand("sv_cheats", "0");
	RunConsoleCommand("host_timescale", "1");
end)