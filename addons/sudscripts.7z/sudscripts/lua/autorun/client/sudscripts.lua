--[[
	MOD/addons/SudScripts/lua/autorun/client/SudScripts.lua [#3748 (#3881), 1835270660]
	Sudoxe | STEAM_0:0:73762976 <81.129.65.23:27005> | [23.01.14 04:17:21PM]
	===BadFile===
]]

--
-- The whole purpose of this script is to not bypass Anti-Cheats and be the best out there
-- but to provide me with an ESP and XRay for DarkRP for 'trolling' with. Also propkilling.

--
-- Fonts
--
surface.CreateFont("ESPFont", {
	font    = "Arial",
	size    = 16,
	weight  = 1000,
	antialias = false,
	shadow = true
})

local DrawProps = CreateClientConVar("Sud_DrawProps", "0", false, false);
local DrawPlayers = CreateClientConVar("Sud_DrawPlayers", "0", false, false);
local DrawESP = CreateClientConVar("Sud_DrawESP", "0", false, false);

local Sud = {
	Ents = { Props = {} }
};

--
-- Having our functions local makes faster access.
--
local draw = draw;
local hook = hook;
local math = math;
local render = render;
local cam = cam;
local timer = timer;

--
-- ESP
--
hook.Add("HUDPaint", "ESP", function()
	surface.SetFont("ESPFont");
	if (DrawESP:GetBool()) then
		for i, player in pairs(player.GetAll()) do
			if (player == LocalPlayer()) then continue; end

			-- Stop moving cunt.
			local pos = player:EyePos():ToScreen();
			pos.x = math.Clamp(pos.x, 0, ScrW());
			pos.y = math.Clamp(pos.y, 45, ScrH());

			draw.SimpleTextOutlined(player:Nick(), "ESPFont", pos.x, pos.y - 15, Color(255, 0, 0), 1, 1, 1, Color(0, 0, 0, 255));
			draw.SimpleTextOutlined(player:GetNWString("usergroup"), "ESPFont", pos.x, pos.y, Color(255, 255, 255), 1, 1, 1, Color(0, 0, 0, 255));
		end
	end
end)

function Sud:SetupXrayEnt(ent)
	ent:DrawModel();
end;

function Sud:XrayEnt(ent, player)
	cam.IgnoreZ(true);
	render.MaterialOverride(Material("models/shiny"));
	render.SetBlend(0.4);
	if (player) then
		render.SetColorModulation(1, 0, 0);
	else
		render.SetColorModulation(0, 1, 0);
	end
	render.SuppressEngineLighting(true);
		self:SetupXrayEnt(ent);
	render.SuppressEngineLighting(false);
	render.SetBlend(1);
	render.SetColorModulation(1, 1, 1);
	render.MaterialOverride(nil);
	cam.IgnoreZ(false);
end;

hook.Add("RenderScreenspaceEffects", "Beams", function()
	if (DrawPlayers:GetBool()) then
		for i, player in pairs(player.GetAll()) do
			if (player == LocalPlayer()) then continue; end

			local PlayerTraceUp = util.TraceLine(util.GetPlayerTrace(player, player:GetUp()));
			local PlayerTrace = util.TraceLine(util.GetPlayerTrace(player));
			cam.Start3D(EyePos(), EyeAngles());
				render.SetMaterial(Material("tripmine_laser"));
				render.DrawBeam(player:EyePos(), PlayerTraceUp.HitPos, 3, 1, 1, Color(255, 0, 0, 255));
				render.DrawBeam(player:GetShootPos(), PlayerTrace.HitPos, 1, 1, 1, Color(255, 0, 0, 255));
			cam.End3D();
		end;
	end

	if (DrawProps:GetBool()) then
		cam.Start3D(EyePos(), EyeAngles());
			for k, v in pairs(Sud.Ents.Props) do
				if not (v:IsValid()) then table.remove(Sud.Ents.Props, k) continue end
				Sud:XrayEnt(v);
			end;

			for k, v in pairs(player.GetAll()) do
				Sud:XrayEnt(v, true);
			end
		cam.End3D();
	end
end);

--
-- Basically store ents in a local table for the xray, less resources needed.
--
hook.Add("OnEntityCreated", "Sud", function(ent)
	if IsValid(ent) then
		if ent:GetClass() == "prop_physics" then
			table.insert(Sud.Ents.Props, ent);
		end;
	end;
end);

--
-- 180q turn, downtown too cramped!
--
concommand.Add("sud_rotate", function()
   	RunConsoleCommand("+juqmp");
   	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() + Angle(-2 * LocalPlayer():EyeAngles().p, 180, 0));
    timer.Simple(0.2, function()
    	RunConsoleCommand("-jump");
    end);
end)

concommand.Add("sud_rotate2", function()
	LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() + Angle(-2 * LocalPlayer():EyeAngles().p, 180, 0));
end)

--
-- Anti-File Stealer (Detour) :), if they scan files before this is loaded then we're fucked.
-- I guess I should be saying hi to that person then, hi faggot?
--