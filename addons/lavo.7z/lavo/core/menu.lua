Lavo.core.menu = {}

local firstcall = true
function Lavo.core.menu.load( )
	
	if ( firstcall ) then
	
		firstcall = false
		
		timer.Simple(0.1, Lavo.core.menu.load) -- Hacky, oh well
		return
	end
	
	local fullw = ScrW() * 0.7
	local fullh = ScrH() * 0.7

	Lavo.core.menu.mainframe = vgui.Create("DFrame")
	Lavo.core.menu.mainframe:SetSize( fullw, fullh )
	Lavo.core.menu.mainframe:Center()
	Lavo.core.menu.mainframe:SetTitle( "Lavo Menu" )
	Lavo.core.menu.mainframe:SetVisible(true)
	Lavo.core.menu.mainframe:MakePopup()

	Lavo.core.menu.mainframe.Paint = function()
		draw.RoundedBox( 0, 0, 0, Lavo.core.menu.mainframe:GetWide(), Lavo.core.menu.mainframe:GetTall(), Color( 0, 0, 0, 150 ) )
	end
	
	Lavo.core.menu.property_sheet = vgui.Create( "DPropertySheet", Lavo.core.menu.mainframe )
	Lavo.core.menu.property_sheet:SetPos( 5, 30 )
	Lavo.core.menu.property_sheet:SetSize( fullw*0.99, fullh*0.93 )

	Lavo.core.menu.property_sheet_browser = vgui.Create( "DFrame" )
	Lavo.core.menu.property_sheet_browser:SetPos(1,1)
	Lavo.core.menu.property_sheet_browser:SetSize( fullw*0.99, fullh*0.93 )

	Lavo.core.menu.property_sheet:AddSheet( "Browser", Lavo.core.menu.property_sheet_browser, "icon16/user.png", 
	false, false, "Oh no charlez, it's alive !" )

	Lavo.core.menu.property_sheet_browser_input = vgui.Create( "DTextEntry", Lavo.core.menu.property_sheet_browser )
	Lavo.core.menu.property_sheet_browser_input:SetPos(3,fullh*0.04)
	Lavo.core.menu.property_sheet_browser_input:SetSize( fullw*0.85, fullh*0.03 )
	Lavo.core.menu.property_sheet_browser_input:OpenURL("http://www.google.com/")
	Lavo.core.menu.property_sheet_browser_input.OnEnter = function(self)
		Lavo.core.menu.property_sheet_browser_html:OpenURL( self:GetValue() )
	end
	
	Lavo.core.menu.property_sheet_browser_html = vgui.Create( "HTML", Lavo.core.menu.property_sheet_browser )
	Lavo.core.menu.property_sheet_browser_html:SetPos(3,fullh*0.1)
	Lavo.core.menu.property_sheet_browser_html:SetSize( fullw*0.99, fullh*0.85 )
	Lavo.core.menu.property_sheet_browser_html:OpenURL("http://www.google.com/")

	local nextopen = CurTime() + 0.3

	hook.Add( "Think", "Lavo.Core.Menu.Toggler", function()
		
		if ( nextopen < CurTime() ) then
			nextopen = CurTime() + 0.3
		else
			return
		end

		hook.Call( "Lavo.Core.Menu.Toggles", nil )

	end )

	hook.Add( "Lavo.Core.Menu.Toggles", "Lavo.Core.Menu.Main", function()
	
		if ( input.IsKeyDown( KEY_HOME ) ) then
			
			if ( not Lavo.core.menu.mainframe ) then
				Lavo.print( "Menu was closed improperly, can't toggle menu :(" )
				return
			end

			Lavo.core.menu.mainframe:SetVisible( not Lavo.core.menu.mainframe:IsVisible() )

			Lavo.print( "Menu toggle was pressed !" )
		
		end

	end)

end