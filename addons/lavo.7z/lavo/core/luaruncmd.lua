Lavo.core.luaruncmd = {}

function Lavo.core.luaruncmd.runlua( str )

	RunString( str )

end

function Lavo.core.luaruncmd.load( )

	concommand.Add( "lavo_luarun", function( p,c,a )

		local str = table.concat(a, " ")

		Lavo.core.luaruncmd.runlua(str)

	end)

end