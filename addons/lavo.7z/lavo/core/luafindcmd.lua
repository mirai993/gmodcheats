Lavo.core.luafindcmd = {}

local pairs = pairs
local isstring = isstring

function Lavo.core.luafindcmd.runlua( str )
	
	local ret = {}

	for k,v in pairs(_G) do
		if ( k and isstring(k) and k:find( str ) ) then
			table.insert(ret, k)
		end
	end
	
	return ret

end

function Lavo.core.luafindcmd.load( )

	concommand.Add( "lavo_luafind", function( p,c,a )
		
		local tbl = Lavo.core.luafindcmd.runlua( a[1] )

		for k,v in pairs( tbl ) do
			Lavo.print( v )
		end
	
	end)

end