
Lavo = {}
Lavo.core = {}
Lavo.plugins = {}

function Lavo.print( str )

	MsgC( Color(255,255,255), "[" )
	MsgC( Color(160, 215, 50), "Lavo" )
	MsgC( Color(255,255,255), "] " )
	MsgC( Color(128,128,128), str .. "\n" )

end

Lavo.print( "Initializing..." )

local files = file.Find("addons/lavo_menu/core/*.lua", "GAME")

for k,v in ipairs(files) do

	Lavo.print( "CORE[] Loading: " .. v )

	local runfile = CompileString( file.Read( "addons/lavo_menu/core/" .. v, "GAME" ), v, false )
	
	v = v:gsub( ".lua", "" )

	if ( isstring(runfile) ) then
		Lavo.print( "CORE[] Failed Loading: " .. v .. " because: " .. runfile .. " !")
		continue
	end

	runfile()

	if ( not Lavo.core[v] ) then
		Lavo.print( "CORE[] Failed Loading: " .. v .. " missing register !")
		PrintTable(Lavo.core)
		continue
	end
	
	if ( not Lavo.core[v].load ) then
		Lavo.print( "CORE[] Failed Loading: " .. v .. " missing load func !" )
		continue
	end

	Lavo.core[v].load( )

end

files  = file.Find("addons/lavo_menu/plugins/*.lua", "GAME")

for k,v in ipairs(files) do

	Lavo.print( "PLUGINS[] Loading: " .. v )

	local runfile = CompileString( file.Read( "addons/lavo_menu/plugins/" .. v, "GAME" ), v, false )
	
	v = v:gsub( ".lua", "" )

	if ( isstring(runfile) ) then
		Lavo.print( "PLUGINS[] Failed Loading: " .. v .. " because: " .. runfile .. " !")
		continue
	end

	runfile()

	if ( not Lavo.plugins[v] ) then
		Lavo.print( "PLUGINS[] Failed Loading: " .. v .. " missing register !")
		continue
	end
	
	if ( not Lavo.plugins[v].load ) then
		Lavo.print( "PLUGINS[] Failed Loading: " .. v .. " missing load func !" )
		continue
	end

	Lavo.plugins[v].load( )

end