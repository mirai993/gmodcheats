require "p_base"
require "p_cvar"
require "p_forcevar"
require "funcsolver"

Msg ( [[		   
 _   _      _ _        ____            _       _          ____ _                
| | | | ___| (_)_  __ / ___|  ___ _ __(_)_ __ | |_ ___   |  __(_)__  __
| |_| |/ _ \ | \ \/ / \___ \ / __| '__| | '_ \| __/ __|  | |_ | |\ \/ /
|  _  |  __/ | |>  <   ___) | (__| |  | | |_) | |_\__ \  |  _|| | >  < 
|_| |_|\___|_|_/_/\_\ |____/ \___|_|  |_| .__/ \__|___/  |_|  |_|/_/\_\
                                        |_|                                    
]] )
Msg( "HelixScripts Injected\n" )
Helix = {}
Helix.Safe = {}
Helix.Cryptosystem = {}
Helix.FileMenu = {}
Helix.FileMenu.CurFile = {}
Helix.SoundMenu = {}
Helix.SoundMenu.SoundPlaying = {}
Helix.Aim = {}
Helix.Hooks = {}
Helix.Color = {}
Helix.Material = {}
Helix.Words = { "am", "are", "green", "small", "stunstick", "grow", "useless", "boat", "truck", "pro", "stealin", "steal", "mah", "cheese", "out", "in", "hour", "minute", "second", "sassilization", "the", "garry", "eat", "I", "an", "am", "not", "money", "explode", "said", "liquid", "bye", "helix", "you", "mom", "your", "cake", "flat", "throw", "could", "cat", "hollow", "his", "mine", "her", "nigger" }
Helix.Punct = { ".", "!", "?" }
Helix.Punct = { ".", "!", "?" }
Helix.RenderTargets = {}
Helix.MessageList = {}
Helix.Bones = {
	"ValveBiped.Bip01_Neck1",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Pelvis"
}
Helix.Colors = {
	Name = Color( 255, 255, 255, 200 ),
	Outline = Color( 0, 0, 0, 235 ),
	Wireframe = Color( 255, 255, 255, 255),
	Crosshair = Color( 0, 255, 10, 230 ),
}
Helix.PassiveWeapons = {
	"weapon_phycannon",
	"weapon_physgun",
	"weapon_crowbar",
	"weapon_frag",
	"gmod_tool",
	nil
}
Helix.BlockFiles = {
	"cfg",
	"settings",
--	"helix",
	"gmcl_deco",
--	"sv_cheats",
--	"host_timescale",
}
Helix.Target = nil
Helix.Next = CurTime()
Helix.Reloading = false
Helix.Overlay = Material( "HelixScripts/Wall" )
Helix.ViewAngle = Vector( 0, 0, 0 )

Helix.ChatSpamming = false
Helix.Bhoping = false
Helix.PropSpamming = false
Helix.PropSpamming2 = false
Helix.RPNameSpamming = false
Helix.NameSpamming = false
Helix.NameForcing = false
Helix.Dir = "HelixScripts/"
Helix.SoundMenu.SoundPath = "../sound"
Helix.SoundMenu.SoundFile = ""
Helix.SoundMenu.PageNum = 0

local SpeedHax= CreateClientConVar( "helix_speed", 3.5, true )
local BlockLua = CreateClientConVar( "helix_blocklua", 0, true )
local ThirdPerson = CreateClientConVar("helix_thirdperson", 0, true )
local ThirdPersonDist = CreateClientConVar("helix_thirdpersondist", 100, true )
local Power_Amount = CreateClientConVar( "helix_power_amt", 2500, true )
local Health_Toggle = CreateClientConVar( "helix_health_enabled", "1", true )
local Health_Val = CreateClientConVar( "helix_health", "50", true )
local Health_Time = CreateClientConVar( "helix_health_time", "1", true )
local DarkRP = CreateClientConVar( "helix_ooc", "0", true )
local PropSpamMdl = CreateClientConVar( "helix_propspam_mdl", "models/props_c17/oildrum001_explosive.mdl", true )
local Reticle = CreateClientConVar( "helix_reticle", "1", true )
local ReticleMat = CreateClientConVar( "helix_reticle_mat", "reticle1", true )

local Bone = CreateClientConVar( "helix_aim_bone", 1, true )
local Crosshair = CreateClientConVar( "helix_aim_crosshair", 0, true, false )
local Esp = CreateClientConVar( "helix_esp", 1, true, false )
local NPCEsp = CreateClientConVar( "helix_esp_old_npc", 1, true, false )
local Fov = CreateClientConVar( "helix_aim_fov", 5, true, false )
local Los = CreateClientConVar( "helix_aim_los", 1, true, false )
local Recoil = CreateClientConVar( "helix_aim_norecoil", 0, true, false )
local Players = CreateClientConVar( "helix_aim_players", 1, true, false )
local Shoot = CreateClientConVar( "helix_aim_shoot", 1, true, false )
local Team = CreateClientConVar( "helix_aim_team", 1, true, false )
local Trigger = CreateClientConVar( "helix_aim_trigger", 0, true, false )
local Wireframe = CreateClientConVar( "helix_aim_wireframe", 0, true, false )
local WallMaterial = CreateClientConVar( "helix_wall_mat", "Team", true, false )

/*
	END OF CONVARS & BOOLS
*/


function _R.Player:GetRank()
	if self:IsSuperAdmin() then
		return "Superadmin"
	elseif self:IsAdmin() then
		return "Admin"
	else
		return "Guest"
	end
end

function Helix.GenerateStringRandom()
	local j, r = 0, ""
		
	for i = 1, math.random(3, 19) do
		j = math.random(65, 116)
		if ( j > 90 && j < 97 ) then j = j + 6 end
		r = r .. string.char(j)
	end
	return r
end

function Helix.Prime( min, max )
	return 1 <= max <= min <= 1000000000, min - max <= 100000
end

function _R.Player:GetRankEvolve()
	if self:EV_IsOwner() then
		return "Owner"	
	elseif self:EV_IsSuperAdmin() then
		return "Superadmin"
	elseif self:EV_IsAdmin() then
		return "Admin"	
	elseif self:EV_IsRespected() then
		return "Respected"
	else
		return "Guest"
	end
end

function _R.Player:GetCash()
	return self.DarkRPVars.money
	end


function Helix.NumToBin( num )
	local ret = ""
	while( num > 0 ) do
		ret = tostring( num % 2 ) .. ret
		num = math.floor( num / 2 )
	end
	return ret
end

function Helix.StrToBin( str )
	local ret = ""
	for b in str:gmatch( "%S+" ) do
		for c in b:gmatch( "." ) do
			ret = ret .. "0" .. Helix.NumToBin( c:byte() )
			ret = ret .. " "
		end
	end
	return ret
end

function Helix.GetAdminMod()
	local ULXF = file.Find( "../lua_temp/ulx/*.lua" )
	local ASSF = file.Find( "../lua_temp/*.lua" )
	local EVOLVEF = file.Find( "../lua_temp/*.lua" )
	
	if table.HasValue( ULXF, "cl_init.lua" ) then
		return tostring( "============ULX============" )
	elseif table.HasValue( ASSF, "ass_client.lua" ) then
		return tostring( "============ASSMod============" )
	elseif table.HasValue( EVOLVEF, "ev_framework.lua" ) then
		return tostring( "============Evolvemod============" )
	else
		return tostring( "============OTHER ADMIN MOD============" )
	end
end

function Helix.Log( msg )
	filex.Append( "HelixScripts/logs.txt", ">>> " .. msg .. "\n" )
	print( ">>> " .. msg )
end

function Helix.GetBone( e )
	local b = e:GetBonePosition( e:LookupBone( Helix.Bones[ math.Clamp( Bone:GetInt(), 1, 4 ) ] ) )
	if ( !b || !Bone:GetBool() ) then b = e:LocalToWorld( e:OBBCenter() ) end
	
	return b
end

function Helix.SimulateShot()
	local w = LocalPlayer():GetActiveWeapon()
	if ( CurTime() < Helix.Next || Helix.Reloading || w:IsWeapon() && table.HasValue( Helix.PassiveWeapons, w:GetClass() ) ) then return end

	LocalPlayer():ConCommand( "+attack" ); timer.Simple( 0.1, function() LocalPlayer():ConCommand( "-attack" ); end )
	Helix.Next = CurTime() + 0.125
end

function Helix.ShootTrace()
	local s, e = LocalPlayer():GetShootPos(), LocalPlayer():GetAimVector()
	local t = { }
	t.start = s
	t.endpos = s + ( e * 65535 )
	t.filter = { LocalPlayer() }
	
	return util.TraceLine( t )
end
	
function Helix.Visible( e )
	if ( !ValidEntity( e ) ) then return false end
	local t = {}
	t.start = LocalPlayer():GetShootPos()
	t.endpos = Helix.GetBone(e)
	t.filter = { LocalPlayer() }
	
	return ( util.TraceLine(t).Entity == e )
end
	
function Helix.ValidTarget( e )	
	if ( !ValidEntity( e ) ) || ( e == LocalPlayer() ) || ( Players:GetBool() && !e:IsPlayer() ) || ( !e:IsNPC() && !e:IsPlayer() ) then return false end
		
	local m = e:GetMoveType()	
	if ( m == MOVETYPE_NONE ) then return false end
	if ( e:IsPlayer() ) then
		if ( !e:Alive() ) || ( m == MOVETYPE_OBSERVER ) || ( e:Team() == LocalPlayer():Team() && Team:GetBool() or Helix.Teams ) then return false end
	end
		
	return true
end
function Helix.InRange( j, min, max )
	return ( j >= min && j <= max )
end

function Helix.toint( v )
	return v && 1 || 0
end

function Helix.AddHook( h, f )
	local n = Helix.GenerateStringRandom()
	Helix.Hooks[ n ] = h
	hook.Add( h, n, f )
	Msg( "Added hook >> " .. h .."[" .. n .. "]\n" )
end

function Helix.Unload()
	for n, h in pairs( Helix.Hooks ) do
		Msg( "Removed hook >> " .. h .."[" .. n .. "]\n" )
		hook.Remove( h, n )
	end
	Helix.Hooks = {}
	Msg( "Unloaded Hooks\n" )
end
concommand.Add( "helix_unload", Helix.Unload )

function Helix.Reload()
	Helix.Unload()
	include( "autorun/client/helix.lua" )
	Msg( "Reloaded Scripts\n" )
end	
concommand.Add( "helix_reload", Helix.Reload )

/*
	END OF METATABLES
*/

Helix.AddHook( "PostDrawOpaqueRenderables", function()
--[[
	for _, ent in pairs( ents.GetAll() ) do  
		if ( ent:GetClass() == "crossbow_bolt" ) then  
					//Written by Night-Eagle  
					surface.SetDrawColor(0,0,255,255)  
              
					local trace = {  
						ang = ent:GetForward()  
					}  
					local tracer = {  
						HitPos = ent:GetPos() + ent:GetForward() * 2  
					}  
					local i = 0  
					repeat  
						i = i + 1  
						trace.start = tracer.HitPos  
						trace.endpos = trace.start + trace.ang * 32  
						trace.ang = trace.ang:Angle()  
						trace.ang.p = trace.ang.p + .004  
						trace.ang = trace.ang:Forward()  
						tracer = util.TraceLine(trace)  
					until i > 3000 or tracer.Hit  
					local boltpos = ent:GetPos():ToScreen()  
					local d = tracer.HitPos:ToScreen()  
  
			surface.DrawLine( boltpos.x, boltpos.y, d.x, d.y )  
			surface.DrawRect(d.x,d.y,4,4)  
		end   
	end 
	--]]
	if not Reticle:GetBool() then return end
	local tr = LocalPlayer():GetEyeTrace()
	local Pos,Normal = tr.HitPos, tr.HitNormal
	
	Pos = Pos + Normal
	
	cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( Material( "sprites/" .. ReticleMat:GetString() ) )
		render.DrawQuadEasy( Pos, Normal, 64, 64, Color( 255, 255, 255, 255 ) )
	cam.End3D()
end )
function Helix.Chams()
	for k, v in pairs( ents.GetAll() ) do
		if v:IsNPC() then
			local npcmat = v:GetMaterial()
			local R, G, B, A = v:GetColor()
			if v:GetColor() ~= Color( 255, 255, 255, 255 ) then
				Helix.Color[ v:GetClass() ] = Color( R, G, B, A )
				v:SetColor( Color( 255, 255, 255, 255 ) )
			else
				v:SetColor( Helix.Color[ v:GetClass() ] )
			end
			if npcmat ~= Helix.Dir .. WallMaterial:GetString() then
				Helix.Material[ v:GetClass() ] = npcmat
				v:SetMaterial( Helix.Dir .. WallMaterial:GetString() )
			else
				v:SetMaterial( Helix.Material[ v:GetClass() ] )
			end
		elseif v:IsPlayer() then
			local plymat = v:GetMaterial()
			local R, G, B, A = v:GetColor()
			if v:GetColor() ~= Color( 255, 255, 255, 255 ) then
				Helix.Color[ v:UniqueID() ] = Color( R, G, B, A )
				v:SetColor( team.GetColor( v:Team() ) )
			else
				v:SetColor( Helix.Color[ v:UniqueID() ] )
			end
			if npcmat ~= Helix.Dir .. WallMaterial:GetString() then
				Helix.Material[ v:UniqueID() ] = npcmat
				v:SetMaterial( Helix.Dir .. WallMaterial:GetString() )
			else
				v:SetMaterial( Helix.Material[ v:UniqueID() ] )
			end
		end
	end
end
concommand.Add( "helix_chams", Helix.Chams )

function Helix.AutoHealth()
	if not Health_Toggle:GetBool() then return end
	
	if LocalPlayer():Health() < Health_Val:GetInt() then
		if CurTime() >= Health_Time:GetInt() then
			if LocalPlayer():Health() ~=0 and LocalPlayer():Health() > 0 then
				LocalPlayer():ConCommand( "say /buyhealth" )
			end
		end
	end
end
Helix.AddHook( "Think", Helix.AutoHealth )

function Helix.PropSpammer2()
	if !Helix.PropSpamming2 then
		timer.Create( "PropSpammer2", 0.1, 0, function()
			LocalPlayer():ConCommand( "gm_spawn models/props_junk/pushcart01a.mdl" )
		end )
	else
		timer.Destroy( "PropSpammer2" )
	end
	Helix.PropSpamming2 = !Helix.PropSpamming2
end
concommand.Add( "helix_propspammer2", Helix.PropSpammer2 )

function Helix.BarrelBomb()
	for i = 1, 50 do
		RunConsoleCommand( "gm_spawn", "models/props_c17/oildrum001_explosive.mdl" )
	end
	timer.Simple( 5, function()
		for i = 1, 50 do
			RunConsoleCommand( "undo" )
		end
	end )
end
concommand.Add( "helix_barrelbomb", Helix.BarrelBomb )

function Helix.Bhop()
	if not Helix.Bhoping then
		timer.Create( "BhopTimer", 0.01, 0, function()
			if LocalPlayer():OnGround() then
				RunConsoleCommand( "+jump" )
				timer.Simple( 0.01, function()
					RunConsoleCommand( "-jump" )
				end)
			end
		end )
	else
		timer.Destroy( "BhopTimer" )
	end
	Helix.Bhoping = !Helix.Bhoping
end
concommand.Add( "helix_bhop", Helix.Bhop )

function Helix.ChatSpam()
	if not Helix.ChatSpamming then
		timer.Create( "ChatSpammer", 1, 0, function()
			if DarkRP:GetBool() then
				LocalPlayer():ConCommand( "say /ooc" .. Helix.GenerateStringRandom() )
			else
				LocalPlayer():ConCommand( "say " .. Helix.GenerateStringRandom() )
			end
		end )
	else
		timer.Destroy( "ChatSpammer" )
	end
	Helix.ChatSpamming = !Helix.ChatSpamming
end
concommand.Add( "helix_chatspammer", Helix.ChatSpam )

function Helix.Undo()
	for i = 1, 500 do
		LocalPlayer():ConCommand("undo")
	end
end
concommand.Add( "helix_undo", Helix.Undo )

function Helix.PropSpam()
	if not Helix.PropSpamming then
		timer.Create( "PropSpammer", 0.1, 0, function()
			RunConsoleCommand( "gm_spawn", PropSpamMdl )
		end )
	else
		timer.Destroy( "PropSpammer" )
	end
	Helix.PropSpamming = !Helix.PropSpamming
end
concommand.Add( "helix_propspam", PropBomb )

function Helix.Money()
	local pls = table.Copy( player.GetAll() )
	table.sort( pls, function(a, b) return a:GetCash() > b:GetCash() end )
	for k, v in pairs( pls ) do
		print( tostring( k ) .. ": " .. v:Nick() .. " has $" .. v:GetCash() .. " in their wallet" )
	end
end
concommand.Add( "helix_money", Helix.Money )

function Helix.Admins()
	local pls = table.Copy( player.GetAll() )
	print( Helix.GetAdminMod() )
	for k,v in pairs( pls ) do
		if table.HasValue( file.Find( "../lua_temp/*.lua" ), "ev_framework.lua" ) then
			print( v:Nick() .. " - " .. v:GetRankEvolve() )
		else
			print( v:Nick() .. " - " .. v:GetRank() )
		end
	end
end
concommand.Add( "helix_admins",Helix.Admins )

function Helix.RPNameSpammer()
	if not Helix.RPNameSpamming then
		timer.Create( "DarkRPNameSpammer", 1, 0, function()
			LocalPlayer():ConCommand( "say /rpname " .. Helix.GenerateStringRandom() )
		end )
	else
		timer.Destroy( "DarkRPNameSpammer" )
	end
	Helix.RPNameSpamming = !Helix.RPNameSpamming
end
concommand.Add( "helix_rpnamespammer", Helix.RPNameSpammer )


function Helix.Speed( ply, cmd, args )
	local speed = GetConVarNumber("helix_speed")
	_P.ForceVar( "host_framerate", tostring( speed ) )
	_P.ForceVar( "sv_cheats", "1" )
end
concommand.Add( "+helix_speed", Helix.Speed )
concommand.Add( "-helix_speed", function() _P.ForceVar( "host_framerate", "0" ) end )

function Helix.ToBinCmd( ply, cmd, args )
	local plaintext = string.Implode( " ", args ) or ""
	Msg( Helix.StrToBin( plaintext ) .. "\n" )
end
concommand.Add( "helix_crypto_binary", Helix.ToBinCmd )

function Helix.SavePower( ply, cmd, args )
	local p = args or "N/A"
	local a = tonumber( string.Implode( " ", p ) )
	
	if not file.Exists( "HelixScripts/powers/power_" .. a .. ".txt" ) then
		file.Write( dir .. "power_" .. a .. ".txt", "" )
	end
	for i = 1, PowerAmount:GetInt() do
		local n = a^i
		if n ~= math.huge then
			filex.Append( dir .. "power_" .. a .. ".txt", a .. "^" .. i .. " >>> " .. n .. "\n" )
		end
	end
	Msg( ">>> File " .. dir .. "power_" .. a .. " wrote to successfuly with power " .. a .. "\n" )
end
concommand.Add( "helix_power", Helix.SavePower )

concommand.Add( "helix_power_prune", function()
										for _, f in pairs( file.Find( "HelixScripts/powers/*.txt" ) ) do
											file.Write( dir .. f, "" )
										end
end )

function Helix.Prime( ply, cmd, args )
	local a = tonumber( string.Implode( " ", args ) )
	
	for i = 1, 5 do
		Msg( Helix.Prime( 1, 100 ) .. "\n" )
	end
end
concommand.Add( "helix_prime", Helix.Prime)

---------------------------------------------------------------------

timer.Create("RandomName", 0.01, 0, function() 
RunConsoleCommand( "setinfo", "name", table.Random( player.GetAll() ):Nick() .. " ") end)
timer.Stop("RandomName")

function Helix.ForceRandomName()
timer.Start("RandomName")
end

concommand.Add("helix_forcerandomname_on", Helix.ForceRandomName)

function Helix.ForceRandomNameOff()
timer.Stop("RandomName")
end

concommand.Add("helix_forcerandomname_off", Helix.ForceRandomNameOff)

---------------------------------------------------------------------

Helix.AddHook("CalcView", function( ply, pos, ang, fov )
		
	if ThirdPerson:GetBool() then
		local dist = math.Clamp( ThirdPersonDist:GetInt(), 10, 150 )
		local center = ply:GetPos() + Vector(0, 0, 75)
		local trace = util.TraceLine({start = center, endpos = center + ang:Forward() * -dist, mask = MASK_OPAQUE})
		if trace.Fraction < 1 then
			dist = dist * trace.Fraction
		end
			
		return {
			["origin"] = center + (ang:Forward() * -dist * 0.95),
			["angles"] = Angle(ang.p + 10, ang.y, ang.r)
		}
	end
		
end)

Helix.AddHook( "ShouldDrawLocalPlayer", function()
	if ThirdPerson:GetBool() then
		return true
	end
end )


function Helix.Troll()
	local _w = table.Random( Helix.Words )
	local _w1 = table.Random( Helix.Words )
	local _w2 = table.Random( Helix.Words )
	local _w3 = table.Random( Helix.Words )
	local _w4 = table.Random( Helix.Words )
	local _w5 = table.Random( Helix.Words )
	local _y = table.Random( Helix.Punct )
	local _c = math.random( 1, 3 )
	if _c == 1 then
		LocalPlayer():ConCommand( "say " .. _w .. " " .. _w1 .. " " .. _w2 .. " " .. _w3 .. _y )
	elseif _c == 2 then
		LocalPlayer():ConCommand( "say " .. _w .. " " .. _w1 .. " " .. _w2 .. " " .. _w3 .. " " .. _w4 .. " " .. _w5 .. _y )
	elseif _c == 3 then
		LocalPlayer():ConCommand( "say " .. _w .. " " .. _w1 .. " " .. _w2 .. _y )
	end
end
concommand.Add( "helix_troll", Helix.Troll )


function Helix.SetBool( ply, cmd, args )
	ply:SetNWBool( args[ 1 ], args[ 2 ] )
end
concommand.Add( "helix_bool", Helix.SetBool )

function Helix.SetInt( ply, cmd, args )
	ply:SetNWInt( args[ 1 ], args[ 2 ] )
end
concommand.Add( "helix_int", Helix.SetInt )

function Helix.SetString( ply, cmd, args )
	ply:SetNWString( args[ 1 ], args[ 2 ] )
end
concommand.Add( "helix_string", Helix.SetString )

/*
	END OF FUNCTIONS/HOOKS
*/

local pent = FindMetaTable( "Entity" )

function pent:AddNWHook( id, call )
	self.hooked = self.hooked or {}
	self.hooked[id] = { call = call, val = "" }
end

Helix.AddHook( "Think", function()
	for i,ent in ipairs( ents.GetAll() ) do
		if ent.hooked then
			local nw
			for k,v in pairs( ent.hooked ) do
				nw = ent:GetNWString( k )
				v.val = (v.val != nil) and v.val or nw
				
				if nw != "" and v.val != nw and not ent.Once then
					ent.Once = true
					v.call( ent, k, v.val, nw )
					v.val = nw
				elseif v.val == nw then
					ent.Once = false
				end
			end
		end
	end
end )

local X = -50
local Y = -100

local KeyPos = {
	{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
	{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
	{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},

	{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
	{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
	{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},

	{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
	{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
	{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},

	{X+5, Y+67.5, 40, 25, -2.2, 4.25, -0.3, 1.6},
	{X+55, Y+67.5, 40, 25, 0.3, 1.65, -0.3, 1.6}
}

local function test( ent, id, old, new )
	--print( ent:GetNWBool( "keypad_access" ) )
	ent.Pass = ent.Pass or ""
	if new == 0 and not ent.SavedPass then ent.Pass = "" return end
	
	for k,v in ipairs( player.GetAll() ) do
		local tr = v:GetEyeTrace()
		if tr.Hit and tr.Entity and tr.Entity == ent then
			local pos = ent:WorldToLocal(tr.HitPos)
			
			for i,p in ipairs( KeyPos ) do
				local x = (pos.y - p[5]) / (p[5] + p[6])
				local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
				--print(i, x, y)
				if (x >= 0) and (x <= 1) and (y >= 0) and (y <= 1) then
					--We have our key!
					ent.Pass = ent.Pass .. tostring(i)
				end
			end
		end
	end
end

local function save( ent, id, old, new )
	--print( "Testing", ent.Pass, old, new )
	if new == true and ent.Pass and tonumber( ent.Pass ) and tonumber( ent.Pass ) > 0 and tonumber( ent.Pass ) < 10000 then
		--print( "Setting", ent.Pass )
		ent.SavedPass = ent.Pass
	end
	if new == false and ent.Pass and tonumber( ent.Pass ) and tonumber( ent.Pass ) > 0 and tonumber( ent.Pass ) < 10000 and ent.Pass == ent.SavedPass then
		ent.SavedPass = nil --Something went wrong
	end
end

for k,v in ipairs( ents.GetAll() ) do
	if v:GetClass():match( "sent_keypad" ) then
		v:AddNWHook( "keypad_num", test )
		v:AddNWHook( "keypad_access", save )
	end
end

Helix.AddHook( "OnEntityCreated", function( ent )
	if not ent or not ValidEntity( ent ) then return end
	if ent:GetClass():match( "sent_keypad" ) then
		ent:AddNWHook( "keypad_num", test )
		ent:AddNWHook( "keypad_access", save )
	end
end )

Helix.AddHook( "HUDPaint", function()
	for i,ent in ipairs( ents.GetAll() ) do
		if ent:GetClass():match( "sent_keypad" ) and (ent.Pass or ent.SavedPass) then
			local pass = ent.SavedPass or ent.Pass
			draw.SimpleText( "Pass: " .. pass, "TargetID", ent:GetPos():ToScreen().x, (ent:GetPos() + Vector(0,0,5)):ToScreen().y, Color(255,0,0), 1, 1 )
		end
	end
end )

/*
	END OF KEYPAD 1.4 CRACKER
*/

function Helix.Aim.DrawBox( ply )
	local center = ply:LocalToWorld( ply:OBBCenter() )
	local min,max = ply:WorldSpaceAABB()
	local dim = max - min
			
	local front = ply:GetForward()*(dim.y/2)
	local right = ply:GetRight()*(dim.x/2)
	local top = ply:GetUp()*(dim.z/2)
	local back = (ply:GetForward()*-1)*(dim.y/2)
	local left = (ply:GetRight()*-1)*(dim.x/2)
	local bottom = (ply:GetUp()*-1)*(dim.z/2)
	local FRT = center+front+right+top
	local BLB = center+back+left+bottom
	local FLT = center+front+left+top
	local BRT = center+back+right+top
	local BLT = center+back+left+top
	local FRB = center+front+right+bottom
	local FLB = center+front+left+bottom
	local BRB = center+back+right+bottom
			
	FRT = FRT:ToScreen()
	BLB = BLB:ToScreen()
	FLT = FLT:ToScreen()
	BRT = BRT:ToScreen()
	BLT = BLT:ToScreen()
	FRB = FRB:ToScreen()
	FLB = FLB:ToScreen()
	BRB = BRB:ToScreen()
	
	local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
	local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	
	surface.SetDrawColor( 255, 0, 0, 255 )
	
	surface.DrawLine( xmax, ymax, xmax, ymin )
	surface.DrawLine( xmax, ymin, xmin, ymin )
	surface.DrawLine( xmin, ymin, xmin, ymax )
	surface.DrawLine( xmin, ymax, xmax, ymax )
end

	function Helix.Aim.DrawESP()
		local j, s
		
		if ( Esp:GetBool() ) then
			for k, e in pairs( Helix.RenderTargets ) do		
				if ( ValidEntity(e) && e:IsPlayer() ) then
					j = (Helix.GetBone(e) + Vector(0, 0, 15)):ToScreen()
					s = string.format("%s - [%i]", e:Nick(), e:Health())
					
					draw.SimpleText(s, "DefaultSmall", j.x, j.y+2, Helix.Colors.Outline, 1, 1)
					draw.SimpleText(s, "DefaultSmall", j.x, j.y, Helix.Colors.Name, 1, 1)
				end
			end
		end
		Helix.RenderTargets = {}
		
		if ( Helix.Aiming ) then
			if ValidEntity( Helix.Target ) then
				Helix.Aim.DrawBox( Helix.Target )
			end
		end
		
			if ( Helix.Crosshair or Crosshair:GetBool() ) then

				local w, h = ScrW() / 2 - 16, ScrH() / 2 - 16
			
				surface.SetTexture( surface.GetTextureID( "sprites/hud/v_crosshair2" ) )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawTexturedRect( w, h, 32, 32 )
			
			end
	end
	
	function Helix.Aim.Render()
		local r = (1/255)
		
			render.SuppressEngineLighting(true)
			SetMaterialOverride(Helix.Overlay)
		for k, e in pairs( ents.GetAll() ) do
			if ( Helix.ValidTarget(e) ) then
				j = ( Helix.GetBone(e) + Vector(0, 0, 10)):ToScreen()
				
				if ( Helix.InRange(j.x, 0, ScrW()) && Helix.InRange(j.y, 0, ScrH()) ) then
					table.insert(Helix.RenderTargets, e)
					if ( Wireframe:GetBool() ) then 
						cam.Start3D( EyePos(), EyeAngles() ) 
							//>> Set the color {
								local c = Helix.Colors.Wireframe
								if ( e:IsPlayer() ) then c = team.GetColor(e:Team()) end
							//<< }
							//>> Render the Wireframe {
								render.SetColorModulation((r*c.r), (r*c.g), (r*c.b))
								e:DrawModel()
							//<< } 
						cam.End3D()
					end
				end
			end
		end
			render.SuppressEngineLighting(false)
			render.SetColorModulation(1, 1, 1) 
			SetMaterialOverride()

		for k, e in pairs( Helix.RenderTargets ) do if ( ValidEntity(e) ) then cam.Start3D( EyePos(), EyeAngles() ); e:DrawModel(); cam.End3D() end end
	end
	
function Helix.Aim.Bot( u )
	Helix.ViewAngle = u:GetViewAngles()

		local w = LocalPlayer():GetActiveWeapon()
		if ( w:IsWeapon() && w:Clip1() <= 0 && w:DefaultReload() ) then LocalPlayer():ConCommand("+reload"); Helix.Reloading = true else LocalPlayer():ConCommand("-reload"); Helix.Reloading = false end
		
	local trace = Helix.ShootTrace()
		
	if ( !Helix.Aiming && Trigger:GetBool() ) then
		if ( Helix.ValidTarget(trace.Entity) && Helix.InRange(trace.HitGroup, 0, 3) ) then 
			Helix.SimulateShot() 
		end
	end
		
	if ( !Helix.Aiming ) then return end
		
	if ( !Helix.ValidTarget( Helix.Target ) || Los:GetBool() && ( trace.HitWorld || util.IsValidProp( trace.Entity:GetModel() ) ) ) then
		Helix.Target = nil
		local f, o, a, t, b = Fov:GetInt(), { p, y }
		for k, e in pairs( ents.GetAll() ) do
			if ( Helix.ValidTarget(e) && Helix.Visible(e) ) then
				b = Helix.GetBone(e)
				if ( !b || !Bone:GetBool() ) then b = e:LocalToWorld(e:OBBCenter()) end
				
				a, t = LocalPlayer():GetAimVector():Angle(), (b - LocalPlayer():GetShootPos()):Angle()
				o.p, o.y = math.abs(math.NormalizeAngle(a.p - t.p)), math.abs(math.NormalizeAngle(a.y - t.y))
				
				if ( !Helix.Target || e:Health() > Helix.Target:Health() ) && ( o.p <= f && o.y <= f ) then Helix.Target = e end
			end
		end
	end
		
	if ( !ValidEntity(Helix.Target) || !Helix.Aiming ) then return end
	Helix.ViewAngle = (Helix.GetBone(Helix.Target) - LocalPlayer():GetShootPos()):Angle()
	u:SetViewAngles(Helix.ViewAngle)
	
	if ( !Shoot:GetBool() ) then return end
	trace = Helix.ShootTrace()
	if ( Helix.ValidTarget(trace.Entity) && Helix.InRange(trace.HitGroup, 0, 3) ) then Helix.SimulateShot() end
end
	
function Helix.Aim.Recoil( u, o )
	if ( Recoil:GetBool() ) then
		local w = LocalPlayer():GetActiveWeapon()
			
		if ( w.Primary ) then w.Primary.Recoil = 0.0 end
		if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
	return { origin = o, angles = Helix.ViewAngle }
	end
end
	
function Helix.Aim.Enable()
	Helix.Aiming = true
	print( ">>> Aim Enabled" )
end
	
function Helix.Aim.Disable()
	Helix.Aiming = false
	Helix.Target = nil
	print( ">>> Aim Disabled" )
end

concommand.Add( "+helix_aim", Helix.Aim.Enable )
concommand.Add( "-helix_aim", Helix.Aim.Disable )
Helix.AddHook( "InitPostEntity", Helix.Aim.Initialize )
Helix.AddHook( "CreateMove", Helix.Aim.Bot )
Helix.AddHook( "HUDPaint", Helix.Aim.DrawESP )
Helix.AddHook( "RenderScreenspaceEffects", Helix.Aim.Render )
Helix.AddHook( "CalcView", Helix.Aim.Recoil )

/*
	END OF AIMBOT
*/

local SKIN = {}

// These are used in the settings panel

SKIN.PrintName 		= "Helix Skin"
SKIN.Author 		= "Garry Newman / Helix Nebula"
SKIN.DermaVersion	= 1

SKIN.colOutline	= Color( 0, 0, 0, 250 )

// You can change the colours from the Default skin

SKIN.colPropertySheet 			= Color(56, 142, 203)
SKIN.colTab			 			= SKIN.colPropertySheet
SKIN.colTabText		 			= Color( 0, 0, 0, 200 )
SKIN.fontButton					= "TargetID"
SKIN.fontTab					= "TargetID"
SKIN.fontFrame					= "Trebuchet17"

SKIN.colButtonText				= Color( 255, 255, 255, 255 )
SKIN.colButtonTextDisabled		= Color( 255, 255, 255, 55 )
SKIN.colButtonBorder			= Color( 20, 20, 20, 255 )
SKIN.colButtonBorderHighlight	= Color( 255, 255, 255, 50 )
SKIN.colButtonBorderShadow		= Color( 0, 0, 0, 100 )
SKIN.fontButton					= "Default"

local darker_blue = Color(38, 109, 175)
local glossy_black = Color(60, 60, 60)
local moredark_blue = Color(56, 142, 203)
local lighter_blue = Color(65, 148, 207)
local separator_blue = Color(49, 126, 179)

local text_white = Color(255, 255, 255)
local text_red = Color(200, 25, 25)

local inactive_blue = Color(42, 114, 169)
local rowa_blue = Color(85, 167, 221)
local rowb_blue = Color(52, 137, 195)
local header_blue = Color(25, 89, 147)

local trans_blue = Color(85, 167, 221, 50)
local dark_trans_blue = Color(38, 109, 175, 150)



// Or any of the functions

function SKIN:DrawSquaredBox( x, y, w, h, color )

	surface.SetDrawColor( color )
	surface.DrawRect( x, y, w, h )
	
	surface.SetDrawColor( self.colOutline )
	surface.DrawOutlinedRect( x, y, w, h )

end

function SKIN:PaintFrame( panel )

	local color = self.bg_color

	self:DrawSquaredBox( 0, 0, panel:GetWide(), panel:GetTall(), color )
	
	surface.SetDrawColor( 0, 0, 0, 75 )
	surface.DrawRect( 0, 0, panel:GetWide(), 21 )
	
	surface.SetDrawColor( self.colOutline )
	surface.DrawRect( 0, 21, panel:GetWide(), 1 )

end

function SKIN:DrawButtonBorder( x, y, w, h, depressed )

	surface.SetDrawColor( self.colButtonBorder )
	surface.DrawOutlinedRect( x, y, w, h )

end

function SKIN:PaintButton( panel )
	local w, h = panel:GetSize()
	if ( panel.m_bBackground ) then
		if ( panel:GetDisabled() ) then
			draw.RoundedBox( 8, 0, 0, w, h, self.control_color_dark )
		elseif ( panel.Depressed || panel:GetSelected() ) then
			draw.RoundedBox( 8, 0, 0, w, h, self.control_color_dark )
		elseif ( panel.Hovered ) then
			draw.RoundedBox( 8, 0, 0, w, h, Color( 90, 170, 225 ) )
		else
			draw.RoundedBox( 8, 0, 0, w, h, self.control_color )
		end
	end
end

derma.DefineSkin( "HelixSkin", "HelixSkin", SKIN )

function ForceVarMenu()

    local DFrame2 = vgui.Create( "DFrame"); 
    DFrame2:SetSize( 265, 75 ); 
    DFrame2:SetPos( ScrW()/2,ScrH()/2 );
    DFrame2:SetVisible( true );  
    DFrame2:MakePopup( );
	DFrame2:SetSkin( "HelixSkin" )
    DFrame2:SetTitle("ConVar Forcing")

	local TextBox_B = vgui.Create( "DTextEntry", DFrame2 )
	TextBox_B:SetPos( 5,25 )
	TextBox_B:SetTall(20)
	TextBox_B:SetWide(255)
	TextBox_B:SetEnterAllowed( true )

	local MenuButton = vgui.Create("DButton",DFrame2)
	MenuButton:SetText( "Force" )
	MenuButton:SetPos(5, 50)
	MenuButton:SetSize( 255, 20 )
	MenuButton.DoClick = function ( btn )
		_P.ForceVar( TextBox_B:GetValue(), "1" )
		surface.PlaySound("buttons/button24.wav")
	end
	
end
concommand.Add( "helix_cvarmenu", ForceVarMenu )

function HelixMenu()
	local MouseX=ScrW()/2
	local MouseY=ScrH()/2
	gui.SetMousePos(MouseX,MouseY)

	_Pan = vgui.Create( "DPropertySheet" )
	_Pan:SetPos( ScrW() / 2 - 285, ScrH() / 2 - 133 )
	_Pan:SetSize( 570, 267 )
	_Pan:MakePopup()
	
	local TabA = vgui.Create( "DLabel", _Pan )
	TabA:SetPos(0,0)
	TabA:SetSkin( "HelixSkin" )
	TabA:SetText("")
	
	local HelixTex = vgui.Create("DImage", TabA)
	HelixTex:SetMaterial(Material("HelixScripts/Background.vtf"))
	HelixTex:SetPos(0,0)
	HelixTex:SetSize(580,237)	
	

	local TabB = vgui.Create( "DFrame", _Pan )
	TabB:SetPos(0,0)
	TabB:SetSkin( "HelixSkin" )
	TabB:SetText("")
	TabB:SetDraggable(false)
	TabB:SetTitle( "General Hacks" )
	
	local HelixTex2 = vgui.Create("DImage", TabB)
	HelixTex2:SetMaterial(Material("HelixScripts/Background.vtf"))
	HelixTex2:SetPos(0,0)
	HelixTex2:SetSize(580,237)
		
	ButtonA = vgui.Create("DButton", TabB )
	ButtonA:SetText( "Barrel Bomb" )
	ButtonA:SetPos( 5, 210 )
	ButtonA:SetSize( 90, 20 )
	ButtonA.DoClick = function ( btn )
		RunConsoleCommand("helix_barrelbomb")
		surface.PlaySound("buttons/button24.wav")
	end
	
	ButtonB = vgui.Create("DButton", TabB )
	ButtonB:SetText( "Show Admins" )
	ButtonB:SetPos( 5, 185 )
	ButtonB:SetSize( 90, 20 )
	ButtonB.DoClick = function ( btn )
		LocalPlayer():PrintMessage( HUD_PRINTTALK, "The list of admins on this server has been printed to your console!" )
		RunConsoleCommand("helix_admins")
		surface.PlaySound("buttons/button24.wav")
	end
	
	ButtonC = vgui.Create("DButton", TabB )
	ButtonC:SetText( "Show Money" )
	ButtonC:SetPos( 5, 160 )
	ButtonC:SetSize( 90, 20 )
	ButtonC.DoClick = function ( btn )
		LocalPlayer():PrintMessage( HUD_PRINTTALK, "Everyone on the servers money has been printed to your console!" )
		RunConsoleCommand("helix_money")
		surface.PlaySound("buttons/button24.wav")
	end
	
	ButtonD = vgui.Create("DButton", TabB )
	ButtonD:SetText( "Cheats" )
	ButtonD:SetPos( 5, 135 )
	ButtonD:SetSize( 90, 20 )
	ButtonD.DoClick = function ( btn )
		cheats = !cheats
		if !cheats then
			_P.ForceVar( "sv_cheats", "0" )
		else
			_P.ForceVar( "sv_cheats", "1" )
		end
		surface.PlaySound("buttons/button24.wav")
	end
	
	ButtonE = vgui.Create("DButton", TabB )
	ButtonE:SetText( "Wallhack" )
	ButtonE:SetPos( 5, 110 )
	ButtonE:SetSize( 90, 20 )
	ButtonE.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand("helix_chams")
	end
	
	ButtonE = vgui.Create("DButton", TabB )
	ButtonE:SetText( "Mass Undo" )
	ButtonE:SetPos( 5, 85 )
	ButtonE:SetSize( 90, 20 )
	ButtonE.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		for i=1,500 do
			RunConsoleCommand("undo")
		end
	end
	
	ButtonF = vgui.Create("DButton", TabB )
	ButtonF:SetText( "Fullbright" )
	ButtonF:SetPos( 5, 60 )
	ButtonF:SetSize( 90, 20 )
	ButtonF.DoClick = function ( btn )
		fullbright = !fullbright
		surface.PlaySound("buttons/button24.wav")
		if !fullbright then
			_P.ForceVar( "mat_fullbright", "0" )
		else
			_P.ForceVar( "mat_fullbright", "1" )
		end
	end
	
	ButtonG = vgui.Create("DButton", TabB )
	ButtonG:SetText( "Wireframe" )
	ButtonG:SetPos( 5, 35 )
	ButtonG:SetSize( 90, 20 )
	ButtonG.DoClick = function ( btn )
		wireframe = !wireframe
		surface.PlaySound("buttons/button24.wav")
		if !wireframe then
			_P.ForceVar( "mat_wireframe", "0" )
		else
			_P.ForceVar( "mat_wireframe", "1" )
		end
	end
		
	ButtonH = vgui.Create("DButton", TabB )
	ButtonH:SetText( "Gray" )
	ButtonH:SetPos( 5, 10 )
	ButtonH:SetSize( 90, 20 )
	ButtonH.DoClick = function ( btn )
		gray = !gray
		surface.PlaySound("buttons/button24.wav")
		if !gray then
			_P.ForceVar( "mat_fullbright", "0" )
		else
			_P.ForceVar( "mat_fullbright", "2" )
		end
	end
	
	ButtonI = vgui.Create("DButton", TabB )
	ButtonI:SetText( "Prop Wireframe" )
	ButtonI:SetPos( 100, 10 )
	ButtonI:SetSize( 90, 20 )
	ButtonI.DoClick = function ( btn )
		propwire = !propwire
		surface.PlaySound("buttons/button24.wav")
		if !propwire then
			_P.ForceVar( "vcollide_wireframe", "0" )
		else
			_P.ForceVar( "vcollide_wireframe", "1" )
		end
	end
	
	ButtonJ = vgui.Create("DButton", TabB )
	ButtonJ:SetText( "Speed" )
	ButtonJ:SetPos( 100, 35 )
	ButtonJ:SetSize( 90, 20 )
	ButtonJ.DoClick = function ( btn )
		speed = !speed
		surface.PlaySound("buttons/button24.wav")
		if !speed then
			RunConsoleCommand( "-helix_speed" )
			_P.ForceVar( "host_framerate", "0" )
		else
			RunConsoleCommand( "+helix_speed" )
		end
	end	
	
	ButtonK = vgui.Create("DButton", TabB )
	ButtonK:SetText( "Grid" )
	ButtonK:SetPos( 100, 60 )
	ButtonK:SetSize( 90, 20 )
	ButtonK.DoClick = function ( btn )
		grid = !grid
		surface.PlaySound("buttons/button24.wav")
		if !grid then
			_P.ForceVar( "mat_luxels", "0" )
		else
			_P.ForceVar( "mat_luxels", "1" )
		end
	end
	
	ButtonL = vgui.Create("DButton", TabB )
	ButtonL:SetText( "Fake Ping" )
	ButtonL:SetPos( 100, 85 )
	ButtonL:SetSize( 90, 20 )
	ButtonL.DoClick = function ( btn )
		fping = !fping
		surface.PlaySound("buttons/button24.wav")
		if !fping then
			_P.ForceVar( "cl_cmdrate", "0" )
		else
			_P.ForceVar( "cl_cmdrate", "+100" )
		end
	end

	ButtonM = vgui.Create("DButton", TabB )
	ButtonM:SetText( "Troll" )
	ButtonM:SetPos( 100, 110 )
	ButtonM:SetSize( 90, 20 )
	ButtonM.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand( "helix_troll" )
	end
	
	ButtonN = vgui.Create("DButton", TabB )
	ButtonN:SetText( "Bhop" )
	ButtonN:SetPos( 100, 135 )
	ButtonN:SetSize( 90, 20 )
	ButtonN.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand( "helix_bhop" )
	end
	
	ButtonO = vgui.Create("DButton", TabB )
	ButtonO:SetText( "Prop Spammer" )
	ButtonO:SetPos( 100, 185 )
	ButtonO:SetSize( 90, 20 )
	ButtonO.DoClick = function ( btn )
		propspammer = !propspammer
		surface.PlaySound("buttons/button24.wav")
		if !propspammer then
			RunConsoleCommand( "helix_propspammer2" )
		else
			RunConsoleCommand( "helix_propspammer2" )
		end
	end
	
	ButtonP = vgui.Create("DButton", TabB )
	ButtonP:SetText( "Thirdperson" )
	ButtonP:SetPos( 100, 160 )
	ButtonP:SetSize( 90, 20 )
	ButtonP.DoClick = function ( btn )
		thirdp = !thirdp
		surface.PlaySound("buttons/button24.wav")
		if !thirdp then
			RunConsoleCommand( "helix_thirdpersondist", "100" )
			RunConsoleCommand( "helix_thirdperson", "0" )

		else
		RunConsoleCommand( "helix_thirdperson", "1" )
		end
	end
	
	ButtonQ = vgui.Create("DButton", TabB )
	ButtonQ:SetText( "Sound Browser" )
	ButtonQ:SetPos( 100, 210 )
	ButtonQ:SetSize( 90, 20 )
	ButtonQ.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
			RunConsoleCommand( "helix_soundbrowser" )
	end
	
	ButtonR = vgui.Create("DButton", TabB )
	ButtonR:SetText( "Chat Spammer" )
	ButtonR:SetPos( 195, 10 )
	ButtonR:SetSize( 90, 20 )
	ButtonR.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
			RunConsoleCommand( "helix_chatspammer" )
	end
	
	ButtonS = vgui.Create("DButton", TabB )
	ButtonS:SetText( "Name Stealer" )
	ButtonS:SetPos( 195, 35 )
	ButtonS:SetSize( 90, 20 )
	ButtonS.DoClick = function ( btn )
	surface.PlaySound("buttons/button24.wav")
	rname = !rname
	if !rname then
	RunConsoleCommand( "helix_forcerandomname_off" )
	else 
	RunConsoleCommand( "helix_forcerandomname_on" )
	end
end

	ButtonT = vgui.Create("DButton", TabB )
	ButtonT:SetText( "Random RPName" )
	ButtonT:SetPos( 195, 60 )
	ButtonT:SetSize( 90, 20 )
	ButtonT.DoClick = function ( btn )
	surface.PlaySound("buttons/button24.wav")
	rname = !rname
	if !rname then
	
	RunConsoleCommand( "helix_rpnamespammer" )
	else 
	RunConsoleCommand( "helix_rpnamespammer" )
	end
end

	
	local TabC = vgui.Create( "DLabel", _Pan )
	TabC:SetPos(0,0)
	TabC:SetSkin( "HelixSkin" )
	TabC:SetText("")
		
	local HelixTex3 = vgui.Create("DImage", TabC)
	HelixTex3:SetMaterial(Material("HelixScripts/Background.vtf"))
	HelixTex3:SetPos(0,0)
	HelixTex3:SetSize(580,237)
	
	local Button_G = vgui.Create( "DButton", TabC )
	Button_G:SetText( "ConVar Force" )
	Button_G:SetPos( 5, 40 )
	Button_G:SetSize( 90, 20 )
	Button_G.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand( "helix_cvarmenu" )
	end
	
	local Button_H = vgui.Create( "DButton", TabC )
	Button_H:SetText( "Crash" )
	Button_H:SetPos( 5, 65 )
	Button_H:SetSize( 90, 20 )
	Button_H.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand( "formatlaser" )
	end
	
	local Button_I = vgui.Create( "DButton", TabC )
	Button_I:SetText( "Toolgun Crash" )
	Button_I:SetPos( 5, 90 )
	Button_I:SetSize( 90, 20 )
	Button_I.DoClick = function ( btn )
		surface.PlaySound("buttons/button24.wav")
		RunConsoleCommand( "tool_trails" )
		RunConsoleCommand( "trails_material", "*" )
		RunConsoleCommand( "+attack" )
		timer.Simple( 0.1, function()
			RunConsoleCommand( "-attack" )
		end )
	end
	
	local TabD = vgui.Create( "DFrame", _Pan )
	TabD:SetPos(0,0)
	TabD:SetSkin( "HelixSkin" )
	TabD:SetText("")
	TabD:SetTitle("Aimbot Settings")
	TabD:SetDraggable(False)
		
	local HelixTex4 = vgui.Create("DImage", TabD)
	HelixTex4:SetMaterial(Material("HelixScripts/Background.vtf"))
	HelixTex4:SetPos(0,0)
	HelixTex4:SetSize(580,237)
	
	CheckboxE = vgui.Create("DCheckBox", TabD)
	CheckboxE:SetPos(10,13)
	CheckboxE:SetConVar( "helix_aim_trigger" )
	local CheckboxLabelE = vgui.Create( "DLabel", TabD)
	CheckboxLabelE:SetPos(25,14)
	CheckboxLabelE:SetText("Trigger")
	CheckboxLabelE:SizeToContents()
	CheckboxLabelE:SetTextColor(Color(225,225,225,225))
	
	CheckboxF = vgui.Create("DCheckBox", TabD)
	CheckboxF:SetPos(10,30)
	CheckboxF:SetConVar( "helix_aim_crosshair" )
	local CheckboxLabelF = vgui.Create( "DLabel", TabD)
	CheckboxLabelF:SetPos(25,31)
	CheckboxLabelF:SetText("Crosshair")
	CheckboxLabelF:SizeToContents()
	CheckboxLabelF:SetTextColor(Color(225,225,225,225))
	
	CheckboxG = vgui.Create("DCheckBox", TabD)
	CheckboxG:SetPos(10,48)
	CheckboxG:SetConVar( "helix_aim_team" )
	local CheckboxLabelG = vgui.Create( "DLabel", TabD)
	CheckboxLabelG:SetPos(25,49)
	CheckboxLabelG:SetText("Other teams than you")
	CheckboxLabelG:SizeToContents()
	CheckboxLabelG:SetTextColor(Color(225,225,225,225))
	
	CheckboxH = vgui.Create("DCheckBox", TabD)
	CheckboxH:SetPos(10,68)
	CheckboxH:SetConVar( "helix_aim_norecoil" )
	local CheckboxLabelH = vgui.Create( "DLabel", TabD )
	CheckboxLabelH:SetPos(25,69)
	CheckboxLabelH:SetText("No Recoil")
	CheckboxLabelH:SizeToContents()
	CheckboxLabelH:SetTextColor(Color(225,225,225,225))
	
	CheckboxI = vgui.Create("DCheckBox", TabD)
	CheckboxI:SetPos(10,88)
	CheckboxI:SetConVar( "helix_esp" )
	local CheckboxLabelI = vgui.Create( "DLabel", TabD )
	CheckboxLabelI:SetPos(25,89)
	CheckboxLabelI:SetText("Esp")
	CheckboxLabelI:SizeToContents()
	CheckboxLabelI:SetTextColor(Color(225,225,225,225))

	CheckboxJ = vgui.Create("DCheckBox", TabD)
	CheckboxJ:SetPos(10,108)
	CheckboxJ:SetConVar( "helix_aim_players" )
	local CheckboxLabelJ = vgui.Create( "DLabel", TabD )
	CheckboxLabelJ:SetPos(25,109)
	CheckboxLabelJ:SetText("Players Only")
	CheckboxLabelJ:SizeToContents()
	CheckboxLabelJ:SetTextColor(Color(225,225,225,225))
	CheckboxJ = vgui.Create("DCheckBox", TabD)
	CheckboxJ:SetPos(10,128)
	CheckboxJ:SetConVar( "helix_reticle" )
	local CheckboxLabelJ = vgui.Create( "DLabel", TabD )
	CheckboxLabelJ:SetPos(25,129)
	CheckboxLabelJ:SetText("Draw Reticle")
	CheckboxLabelJ:SizeToContents()
	CheckboxLabelJ:SetTextColor(Color(225,225,225,225))
	
	local NumSlider = vgui.Create( "DNumSlider", TabD )
	NumSlider:SetPos( 25,148 )
	NumSlider:SetWide( 150 )
	NumSlider:SetText( "Aim Bone" ) 
	NumSlider:SetMin( 0 )
	NumSlider:SetMax( 4 ) 
	NumSlider:SetDecimals( 0 )
	NumSlider:SetConVar( "helix_aim_bone" )
	
	local HealthLevel = LocalPlayer():Health()

	local NumSlider2 = vgui.Create( "DNumSlider", TabB )
	NumSlider2:SetPos( 197,125 )
	NumSlider2:SetWide( 150 )
	NumSlider2:SetText( "AutoHealth Health" ) 
	NumSlider2:SetMin( 1 )
	NumSlider2:SetMax( HealthLevel ) 
	NumSlider2:SetDecimals( 0 )
	NumSlider2:SetConVar( "helix_health" )
	
	local NumSlider3 = vgui.Create( "DNumSlider", TabB )
	NumSlider3:SetPos( 197,165 )
	NumSlider3:SetWide( 150 )
	NumSlider3:SetText( "Speed" ) 
	NumSlider3:SetMin( 8 )
	NumSlider3:SetMax( 2 ) 
	NumSlider3:SetDecimals( 0 )
	NumSlider3:SetConVar( "helix_speed" )
	
	local CheckboxLabelJ = vgui.Create( "DLabel", TabB)
	CheckboxLabelJ:SetPos(215,85)
	CheckboxLabelJ:SetText( "AutoHealth Enabled" )
	CheckboxLabelJ:SizeToContents()
	CheckboxLabelJ:SetTextColor(Color(225,225,225,225))
	
	CheckboxJ = vgui.Create("DCheckBox", TabB)
	CheckboxJ:SetPos(197,85)
	CheckboxJ:SetValue( Health_Toggle:GetBool() )
	CheckboxJ.DoClick=function()
		CheckboxJ:SetValue( !Health_Toggle:GetBool() )
		if Health_Toggle:GetBool() then
			RunConsoleCommand("helix_health_enabled", 0 )
		else
			RunConsoleCommand("helix_health_enabled", 1 )
		end
	end
	
	local CheckboxLabelK = vgui.Create( "DLabel", TabB)
	CheckboxLabelK:SetPos(215,105)
	CheckboxLabelK:SetText("AutoHealth Time")
	CheckboxLabelK:SizeToContents()
	CheckboxLabelK:SetTextColor(Color(225,225,225,225))
	
	CheckboxK = vgui.Create("DCheckBox", TabB)
	CheckboxK:SetPos(197,105)
	CheckboxK:SetConVar( "helix_health_time" )

		
	--[[
	local TabE = vgui.Create( "DLabel", _Pan )
	TabE:SetPos(0,0)
	TabE:SetSkin( "HelixSkin" )
	TabE:SetText("")
	
	local HelixTex5 = vgui.Create("DImage", TabE)
	HelixTex5:SetMaterial(Material("HelixScripts/Background.vtf"))
	HelixTex5:SetPos(0,0)
	HelixTex5:SetSize(580,237)
	
	local CryptoInput = vgui.Create( "DTextEntry", TabE )
	CryptoInput:SetSize( ( _Pan:GetWide()* .5 ) - 35, _Pan:GetTall() - 60 )
	CryptoInput:SetPos( 10, 10 )
	CryptoInput:AllowInput( true )
	CryptoInput.OnEnter = function()
							Msg( CryptoInput:GetValue() )
							end
	--]]
	_Pan:AddSheet( "Settings", TabA, "gui/silkicons/world", false, false, "Settings panel" )
	_Pan:AddSheet( "Aimbot", TabD, "gui/silkicons/heart", false, false, "Aimbot" )
	_Pan:AddSheet( "General Hacks", TabB, "gui/silkicons/user", false, false, "General Hacks" )
	_Pan:AddSheet( "Engine Hacks", TabC, "gui/silkicons/delete", false, false, "Engine Hacks" )
	--_Pan:AddSheet( "Cryptosystem", TabE, "gui/silkicons/lock", false, false, "Cryptosystem" )
end
concommand.Add( "+Helix_Menu", HelixMenu )
concommand.Add( "-Helix_Menu", function() MouseX,MouseY=gui.MousePos() _Pan:Remove() end )

function Helix.SoundMenu:ShowList()



	if self.browser then self:Clear() end

	

	self.browser = {}

	self.browser.Panel = vgui.Create("DFrame")

	self.browser.Panel:SetPos(930,125)

	self.browser.Panel:SetSize(350, 400)

	self.browser.Panel:SetTitle("Sound Browser")

	self.browser.Panel:SetVisible(true)

	self.browser.Panel:SetDraggable(true)

	self.browser.Panel:ShowCloseButton(true)

	self.browser.Panel:SetDeleteOnClose(true)

	self.browser.Panel:MakePopup()
	
	self.browser.Panel:SetSkin( "HelixSkin" )

	

	self.browser.Text = vgui.Create("DTextEntry", self.browser.Panel)

	self.browser.Text:SetPos(50, 30)

	self.browser.Text:SetSize(225, 20)

	self.browser.Text:SetEditable(false)

	

	self.browser.BackButton = vgui.Create("DSysButton", self.browser.Panel)

	self.browser.BackButton:SetPos(20, 25)

	self.browser.BackButton:SetSize(25, 25)

	self.browser.BackButton:SetType("left")

	self.browser.BackButton.DoClick = function()

		local backDir = string.Explode("/", self.SoundPath)

		if #backDir <= 2 then return end

		

		table.remove(backDir, #backDir)

		self.SoundPath = string.Implode("/", backDir)

		

		self:UpdateList(self.SoundPath) --Goes back a folder

	end

	

	self.browser.BackButton = vgui.Create("DSysButton", self.browser.Panel)

	self.browser.BackButton:SetPos(self.browser.Text:GetWide() + 60, 25)

	self.browser.BackButton:SetSize(25, 25)

	self.browser.BackButton:SetType("left")

	self.browser.BackButton.DoClick = function()

		if self.PageNum <= 0 then return end 

		self.PageNum = self.PageNum - 1

		self:UpdateList(self.SoundPath)

	end

	

	self.browser.BackButton = vgui.Create("DSysButton", self.browser.Panel)

	self.browser.BackButton:SetPos(self.browser.Text:GetWide() + 85, 25)

	self.browser.BackButton:SetSize(25, 25)

	self.browser.BackButton:SetType("right")

	self.browser.BackButton.DoClick = function()

		if self.PageNum >= self:PageNums() - 1 then return end

		self.PageNum = self.PageNum + 1

		self:UpdateList(self.SoundPath)

	end



	self.browser.PlayButton = vgui.Create("DButton", self.browser.Panel)

	self.browser.PlayButton:SetText("Play")

	self.browser.PlayButton:SetPos(20, self.browser.Panel:GetTall() - 35)

	self.browser.PlayButton:SetSize(50, 25)

	self.browser.PlayButton.DoClick = function ()

		self:Play(self.SoundFile, tonumber(self.browser.Pitch:GetValue()))

	end
	
	self.browser.PlayButton = vgui.Create("DButton", self.browser.Panel)

	self.browser.PlayButton:SetText("Stop")

	self.browser.PlayButton:SetPos(80, self.browser.Panel:GetTall() - 35)

	self.browser.PlayButton:SetSize(50, 25)

	self.browser.PlayButton.DoClick = function ()

		RunConsoleCommand( "stopsounds" )

	end


	self.browser.Volume = vgui.Create("DTextEntry", self.browser.Panel)

	self.browser.Volume:SetPos(140, self.browser.Panel:GetTall() - 35)

	self.browser.Volume:SetSize(25, 25)

	self.browser.Volume:SetValue(100)

	self.browser.Volume:SetEnterAllowed(true)

	self.browser.Volume:SetEditable(true)

	

	self.browser.VolumeL = vgui.Create("Label", self.browser.Panel)

	self.browser.VolumeL:SetPos(140, self.browser.Panel:GetTall() - 55)

	self.browser.VolumeL:SetText("Volume")

	

	self.browser.Pitch = vgui.Create("DTextEntry", self.browser.Panel)

	self.browser.Pitch:SetPos(180, self.browser.Panel:GetTall() - 35)

	self.browser.Pitch:SetSize(25, 25)

	self.browser.Pitch:SetValue(100)

	self.browser.Pitch:SetEnterAllowed(true)

	self.browser.Pitch:SetEditable(true)

	

	self.browser.PitchL = vgui.Create("Label", self.browser.Panel)

	self.browser.PitchL:SetPos(180, self.browser.Panel:GetTall() - 55)

	self.browser.PitchL:SetText("Pitch")

	

	self.browser.CopyButton = vgui.Create("DButton", self.browser.Panel)

	self.browser.CopyButton:SetText("Set to Clipboard")

	self.browser.CopyButton:SetPos(240, self.browser.Panel:GetTall() - 35)

	self.browser.CopyButton:SetSize(100, 25)

	self.browser.CopyButton.DoClick = function ()

		SetClipboardText( self.SoundFile .. self.browser.Volume:GetValue() .. " " .. self.browser.Pitch:GetValue() )

	end

	

	self.browser.ListView = vgui.Create("DListView", self.browser.Panel)

	self.browser.ListView:SetPos(25, 50)

	self.browser.ListView:SetSize(self.browser.Panel:GetWide() - 50, self.browser.Panel:GetTall() - 100)

	self.browser.ListView:SetMultiSelect(false)

	self.browser.ListView:AddColumn("Sound")

	self.browser.ListView.OnClickLine = function(parent, line, isselected)

		local soundFile = line:GetValue(1)

		if self:IsFile( soundFile) then 

			if self.SoundFile !=  soundFile then self.SoundFile = string.gsub(self.SoundPath, "../sound/", "") .. "/" .. soundFile print(self.SoundFile) end

			return 

		end

		

		self.SoundPath = self.SoundPath .. "/" .. line:GetValue(1)

		self:UpdateList(self.SoundPath)

	end



	self:UpdateList(self.SoundPath)

	

end



concommand.Add( "helix_soundbrowser", function(ply, cmd, args) 

		Helix.SoundMenu:ShowList()

	end)



function Helix.SoundMenu:IsFile(fileName)

	return table.HasValue( { "wav", "mp3" }, string.GetExtensionFromFilename( fileName ) )

end



function Helix.SoundMenu:Play(soundPath, pitch)



	if !soundPath or !pitch then return end



	LocalPlayer():EmitSound(Sound(soundPath), 100, math.Clamp(pitch, 50, 255)) 



end



function Helix.SoundMenu:Stop()

	--if timer.IsTimer("SoundBrowser") then timer.Remove("SoundBrowser") end

	RunConsoleCommand("stopsounds")

end



function Helix.SoundMenu:UpdateList(dir)

	self.FileList = self:CreateList(dir)

	self.browser.ListView:Clear()

	

	if self.browser.Text then self.browser.Text:SetValue(dir) end

	

	if self.browser.ListView then

		local tbl = self:SetPage(self.PageNum)

		

		for _, v in pairs(tbl) do

			self.browser.ListView:AddLine(v)

		end

	end

end



function Helix.SoundMenu:Clear()

	self.SoundPath = "../sound"

	self.SoundFile = ""

	self.PageNum = 0

	if self.brower then self.browser.Panel:Close() end

	self.browser = nil

	self.FileList = nil

end

concommand.Add( "helix_clearsoundbrowser", function(ply, cmd, args)

		Helix.SoundMenu:Clear()

	end)

	

function Helix.SoundMenu:CreateList(dir)

	local fileList = file.FindDir(dir .. "/*")

	

	for _, v in ipairs(file.Find(dir .. "/*")) do

		if self:IsFile(v) then table.insert(fileList, v) end

	end

	

	return fileList

end



function Helix.SoundMenu:SetPage(num)

	local tbl = {}

	

	for i = 0, 1000 do

		tbl[i] = self.FileList[i + (1000 * num)]

	end

	

	return tbl

end



function Helix.SoundMenu:PageNums()

	return math.ceil(#self.FileList / 1000)

end

function ClearSoundList()

	table.Empty(Helix.SoundMenu.SoundPlaying)

end

/*
	END OF DERMA
*/