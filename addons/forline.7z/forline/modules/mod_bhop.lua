--[[
	autorun/client/modules/mod_bhop.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

local function BunnyHop()
	if LocalPlayer():IsOnGround() then
		LocalPlayer():ConCommand("+jump")
	else
		LocalPlayer():ConCommand("-jump")
	end
end

concommand.Add("+fls_bhop", function()
	hook.Add("Think", "FLS.BunnyHop", BunnyHop)
end)

concommand.Add("-fls_bhop", function()
	hook.Remove("Think", "FLS.BunnyHop")
	LocalPlayer():ConCommand("-jump")
end)