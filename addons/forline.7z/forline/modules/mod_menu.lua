--[[
	autorun/client/modules/mod_menu.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

function MENU_CREATE()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(ScrW() / 1.5, ScrH() / 1.5)
		Frame:Center()
		Frame:SetTitle("Player Info Menu")
		Frame:ShowCloseButton(true)
		Frame:SetDraggable(false)
		Frame:SetSizable(false)
		Frame:MakePopup()
	local Sheet = vgui.Create("DPropertySheet", Frame)
		Sheet:SetPos(10, 30)
		Sheet:SetSize(Frame:GetWide() - 20, Frame:GetTall() - 40)
	local INDEX_PANEL = vgui.Create("DPanel", Sheet)
		INDEX_PANEL:SetSize(INDEX_PANEL:GetParent():GetWide(), INDEX_PANEL:GetParent():GetTall())
		local INDEX_DRAW_PANEL = vgui.Create("DPanel", INDEX_PANEL)
			INDEX_DRAW_PANEL:SetSize(INDEX_DRAW_PANEL:GetParent():GetWide(), INDEX_DRAW_PANEL:GetParent():GetTall())
			INDEX_DRAW_PANEL.Paint = function(self)
				surface.SetDrawColor(Color(210, 210, 210, 255))
				surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
				surface.SetDrawColor(Color(0, 128, 255, 128))
				surface.DrawRect(10, 10, self:GetWide() - 30, 70)
				surface.SetFont("HUDNumber5")
				surface.SetTextColor(Color(255, 255, 255, 255))
				local textw, texth = surface.GetTextSize("FLS Config Menu")
				surface.SetTextPos((self:GetWide() / 2) - (textw / 2) - 15, 45 - (texth / 2))
				surface.DrawText("FLS Config Menu")
				surface.SetDrawColor(Color(128, 128, 128, 128))
				surface.DrawOutlinedRect(10, 90, 200, 90)
			end
	local UTIL_PANEL = vgui.Create("DPanel", Sheet)
		UTIL_PANEL:SetSize(INDEX_PANEL:GetParent():GetWide(), UTIL_PANEL:GetParent():GetTall())
		local UTIL_DRAW_PANEL = vgui.Create("DPanel", UTIL_PANEL)
			UTIL_DRAW_PANEL:SetSize(INDEX_DRAW_PANEL:GetParent():GetWide(), UTIL_DRAW_PANEL:GetParent():GetTall())
			UTIL_DRAW_PANEL.Paint = function(self)
				surface.SetDrawColor(Color(210, 210, 210, 255))
				surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			end
		local ESPDraw = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			ESPDraw:SetPos(20, 100)
			ESPDraw:SetConVar("fls_esp_enabled")
			ESPDraw:SetText("Enable ESP (Wallhack, X-Ray)")
			ESPDraw:SetTextColor(Color(0, 0, 0, 255))
			ESPDraw:SizeToContents()
		local XrayCheckbox = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			XrayCheckbox:SetPos(40, 120)
			XrayCheckbox:SetConVar("fls_esp_xray")
			XrayCheckbox:SetText("Enable X-Ray Vision")
			XrayCheckbox:SetTextColor(Color(0, 0, 0, 255))
			XrayCheckbox:SizeToContents()
		local PlayerDraw = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			PlayerDraw:SetPos(40, 140)
			PlayerDraw:SetConVar("fls_esp_drawplayers")
			PlayerDraw:SetText("Enable Player Wallhack")
			PlayerDraw:SetTextColor(Color(0, 0, 0, 255))
			PlayerDraw:SizeToContents()
		local NPCDraw = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			NPCDraw:SetPos(40, 160)
			NPCDraw:SetConVar("fls_esp_drawnpcs")
			NPCDraw:SetText("Draw NPCs (X-Ray)")
			NPCDraw:SetTextColor(Color(0, 0, 0, 255))
			NPCDraw:SizeToContents()
		local AntiMute = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			AntiMute:SetPos(20, 190)
			AntiMute:SetConVar("fls_antimute")
			AntiMute:SetText("Enable Anti-Mute/Anti-Gag")
			AntiMute:SetTextColor(Color(0, 0, 0, 255))
			AntiMute:SizeToContents()
		local AntiBlind = vgui.Create("DCheckBoxLabel", INDEX_DRAW_PANEL)
			AntiBlind:SetPos(20, 210)
			AntiBlind:SetConVar("fls_antiblind")
			AntiBlind:SetText("Enable Anti-Blind")
			AntiBlind:SetTextColor(Color(0, 0, 0, 255))
			AntiBlind:SizeToContents()
	local TEXT_SPEC = vgui.Create("DTextEntry", UTIL_DRAW_PANEL)
		TEXT_SPEC:SetSize(100, 20)
		TEXT_SPEC:SetPos(20, 70)
		TEXT_SPEC:SetText("Player Name")
	local DO_SPEC = vgui.Create("DButton", UTIL_DRAW_PANEL)
		DO_SPEC:SetSize(100, 20)
		DO_SPEC:SetPos(130, 70)
		DO_SPEC:SetText("Spectate Player")
		DO_SPEC.DoClick = function()
			RunConsoleCommand("fls_specplayer", TEXT_SPEC:GetValue())
		end
	local STOP_SPEC = vgui.Create("DButton", UTIL_DRAW_PANEL)
		STOP_SPEC:SetSize(100, 20)
		STOP_SPEC:SetPos(20, 100)
		STOP_SPEC:SetText("Stop Spectating")
		STOP_SPEC.DoClick = function()
			RunConsoleCommand("fls_stopspec")
		end
	local DOCRASH = vgui.Create("DButton", UTIL_DRAW_PANEL)
		DOCRASH:SetSize(570, 30)
		DOCRASH:SetPos(20, 130)
		DOCRASH:SetText("Try crash (Better to use fls_weightcrash in console) requires you have Weight Tool then walk on/move the props")
		DOCRASH.DoClick = function()
			RunConsoleCommand("fls_weightcrash")
		end
	local BUTTON_ADVUPLOAD = vgui.Create("DButton", UTIL_DRAW_PANEL)
		BUTTON_ADVUPLOAD:SetSize(150, 40)
		BUTTON_ADVUPLOAD:SetPos(20, 20)
		BUTTON_ADVUPLOAD:SetText("Adv Dupe Force Upload")
		BUTTON_ADVUPLOAD.DoClick = function(self)
			local sizew = 300
			local sizeh = 100
			local POPUP_ADVUPLOAD = vgui.Create("DFrame", UTIL_DRAW_PANEL)
				POPUP_ADVUPLOAD:SetSize(sizew, sizeh)
				POPUP_ADVUPLOAD:Center()
				POPUP_ADVUPLOAD:SetTitle("Forced Adv Dupe Upload")
				POPUP_ADVUPLOAD:ShowCloseButton(true)
				POPUP_ADVUPLOAD:SetDraggable(false)
				POPUP_ADVUPLOAD:SetSizable(false)
				POPUP_ADVUPLOAD:SetBackgroundBlur(true)
				POPUP_ADVUPLOAD:MakePopup()
			local INPUT_DUPEFILE = vgui.Create("DTextEntry", POPUP_ADVUPLOAD)
				INPUT_DUPEFILE:SetSize(sizew - 40, 20)
				INPUT_DUPEFILE:SetPos(20, 30)
				INPUT_DUPEFILE:SetText("Filename relevant to data/adv_duplicator")
				INPUT_DUPEFILE.OnTextChanged = function()
					local files = file.Find("adv_duplicator/*.txt")
					if #files != 1 then
						local Menu = DermaMenu()
						for k, v in pairs(files) do
							if string.match(string.lower(v), string.lower(INPUT_DUPEFILE:GetValue())) then
								Menu:AddOption(v, function()
									INPUT_DUPEFILE:SetText(v)
								end)
							end
						end
						Menu:Open()
					end
				end
			local BUTTON_DOADVUPLOAD = vgui.Create("DButton", POPUP_ADVUPLOAD)
				BUTTON_DOADVUPLOAD:SetSize(80, 30)
				BUTTON_DOADVUPLOAD:SetPos((sizew / 2) - 40, 60)
				BUTTON_DOADVUPLOAD:SetText("Force Upload")
				BUTTON_DOADVUPLOAD.DoClick = function(self)
					AdvDupeClient.UpLoadFile(LocalPlayer(), "adv_duplicator/" .. INPUT_DUPEFILE:GetValue())
					POPUP_ADVUPLOAD:Close()
				end
		end
	local PLAYER_PANEL = vgui.Create("DPanel", Sheet)
		PLAYER_PANEL:SetSize(PLAYER_PANEL:GetParent():GetWide(), PLAYER_PANEL:GetParent():GetTall())
	local List = vgui.Create("DListView", PLAYER_PANEL)
		List:SetPos(0, 40)
		List:SetSize(List:GetParent():GetWide(), List:GetParent():GetTall() - 40)
		List:SetMultiSelect(false)
		List:AddColumn("Player Name")
		List:AddColumn("Rank")
		List:AddColumn("SteamID")
		List:AddColumn("Location")
		List:AddColumn("Money")
		for k, v in pairs(player.GetAll()) do
			local rank = "Guest"
			local money = "???"
			if v.DarkRPVars and v.DarkRPVars.money and v.DarkRPVars.money != nil then
				money = v.DarkRPVars.money
			end
			if v:IsAdmin() and not v:IsSuperAdmin() then
				rank = "Admin"
			elseif v:IsSuperAdmin() then
				rank = "Superadmin"
			end
			List:AddLine(v:Nick(), rank, v:SteamID(), v:GetLocation(), "$" .. money)
		end
		List.OnRowRightClick = function(panel, line)
			local ListMenu = DermaMenu()
				ListMenu:AddOption("Copy Name", function()
					SetClipboardText(panel:GetLine(line):GetValue(1))
				end)
				ListMenu:AddOption("Copy SteamID", function()
					SetClipboardText(panel:GetLine(line):GetValue(3))
				end)
				ListMenu:AddOption("Copy Money", function()
					SetClipboardText(panel:GetLine(line):GetValue(5))
				end)
				ListMenu:AddOption("Show Weapons", function()
					local Weapons = {}
					table.Empty(Weapons)
					for k, v in pairs(player.GetAll()) do
						if v:SteamID() == panel:GetLine(line):GetValue(3) then
							for _, weap in pairs(v:GetWeapons()) do
								if weap and weap:IsValid() and weap:IsWeapon() then
									table.insert(Weapons, weap:GetPrintName() or weap:GetClass())
								end
							end
						end
					end
					local Popup = vgui.Create("DFrame")
						Popup:SetSize(300, 200)
						Popup:Center()
						Popup:SetTitle("Weapons")
						Popup:SetDraggable(false)
						Popup:SetSizable(false)
						Popup:ShowCloseButton(true)
						Popup:SetBackgroundBlur(true)
						Popup:MakePopup()
					local WeaponList = vgui.Create("DListView", Popup)
						WeaponList:SetPos(10, 30)
						WeaponList:SetSize(WeaponList:GetParent():GetWide() - 20, WeaponList:GetParent():GetTall() - 40)
						WeaponList:AddColumn("Weapon name")
						for k, v in pairs(Weapons) do
							WeaponList:AddLine(v)
						end
				end)
				ListMenu:Open()
		end
	local TypeSelect = vgui.Create("DMultiChoice", PLAYER_PANEL)
		TypeSelect:SetPos(10, 10)
		TypeSelect:SetSize(120, 20)
		TypeSelect:SetText("No Mod")
		TypeSelect:AddChoice("No Mod")
		TypeSelect:AddChoice("Evolve")
		TypeSelect:AddChoice("ULX")
		TypeSelect.OnSelect = function(index, value)
			if value == 1 then
				List:Clear()
				for k, v in pairs(player.GetAll()) do
					local rank = "Guest"
					local money = "???"
					if v.DarkRPVars then
						money = v.DarkRPVars.money
					end
					if v:IsAdmin() and not v:IsSuperAdmin() then
						rank = "Admin"
					elseif v:IsSuperAdmin() then
						rank = "Superadmin"
					end
					List:AddLine(v:Nick(), rank, v:SteamID(), "", "$" .. money)
				end
			elseif value == 2 then
				List:Clear()
				for k, v in pairs(player.GetAll()) do
					local rank = "Guest"
					local money = "???"
					if v.DarkRPVars then
						money = v.DarkRPVars.money
					end
					rank = v:GetNWString("UserGroup")
					if ply:EV_HasPrivilege("Ban") then
						rank = rank .. " [CAN BAN]"
					end
					List:AddLine(v:Nick(), rank, v:SteamID(), "", "$" .. money)
				end
			elseif value == 3 then
				List:Clear()
				for k, v in pairs(player.GetAll()) do
					local rank = "Guest"
					local money = "???"
					if v.DarkRPVars then
						money = v.DarkRPVars.money
					end
					rank = v:GetUserGroup()
					List:AddLine(v:Nick(), rank, v:SteamID(), "", "$" .. money)
				end
			end
		end
	Sheet:AddSheet("Main", INDEX_PANEL, "gui/silkicons/page", false, false, "Main Settings/Info")
	Sheet:AddSheet("Players", PLAYER_PANEL, "gui/silkicons/user", false, false, "Player Info")
	Sheet:AddSheet("Utilities", UTIL_PANEL, "gui/silkicons/wrench", false, false, "Utilities/Tools")
end

concommand.Add("fls_menu", MENU_CREATE)

function SPEC_PLAYER(plyname)
	local ply = LocalPlayer()
	for k, v in pairs(player.GetAll()) do
		if string.match(string.lower(v:Nick()), string.lower(plyname)) then
			ply = v
		end
	end
	hook.Add("HUDPaint", "SpectatePlayer", function()
	if ply and ply:IsValid() then
		local CamData = {}
			local hpos, hang = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
			CamData.angles = ply:EyeAngles()
			CamData.origin = hpos + ((hpos - ply:GetShootPos()) / 2) - Vector(-5, 0, 4)
			CamData.x = 0
			CamData.y = 0
			CamData.w = ScrW()
			CamData.h = ScrH()
			render.RenderView(CamData)
	end
	end)
end

concommand.Add("fls_specplayer", function(ply, command, args)
	local name = args[1]
	SPEC_PLAYER(name)
end)
concommand.Add("fls_stopspec", function()
	hook.Remove("HUDPaint", "SpectatePlayer")
	LocalPlayer():SetViewOffset(Vector(0, 0, 64))
end)