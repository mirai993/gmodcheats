--[[
	autorun/client/modules/mod_lua.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

function LOAD_LUA(luafile)
	local f = file.Read("../garrysmod/lua/" .. luafile)
	RunString(f)
end

function EXEC_LUA(lua)
	RunString(lua)
end

concommand.Add("fls_execlua", function(ply, command, args)
	if not args or #args == 0 then
		print("No lua to be exectuted.")
	else
		EXEC_LUA(unpack(args))
	end
end)

concommand.Add("fls_loadlua", function(ply, command, args)
	if #args or #args == 0 then
		print("No lua to be exectuted.")
	else
		LOAD_LUA(args[1])
	end
end)