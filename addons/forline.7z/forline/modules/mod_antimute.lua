--[[
	autorun/client/modules/mod_antimute.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

function ANTI_MUTE()
	if GetConVar("fls_antimute"):GetInt() == 1 then
		/* Evolve */
		if LocalPlayer():GetNWBool("Muted") then
			LocalPlayer():SetNWBool("Muted", false)
		end
		/* ULX */
		hook.Remove("PlayerBindPress", "ULXGagForce")
		timer.Destroy("GagLocalPlayer")
	end
end

CreateClientConVar("fls_antimute", "1", false, true)

hook.Add("Tick", "AntiMute", ANTI_MUTE)