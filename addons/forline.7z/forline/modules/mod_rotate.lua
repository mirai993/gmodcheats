--[[
	autorun/client/modules/mod_rotate.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

local function Rotate()
	local ang = LocalPlayer():EyeAngles()

	LocalPlayer():SetEyeAngles(ang - Angle(0, 180, 0))
end

concommand.Add("fls_rotate", Rotate)