--[[
	autorun/client/fls_init.lua
	/FL-L\ Lethal (Dexter) | (STEAM_0:1:9463261)
	===DStream===
]]

/* Initializes the modules and command */

FLS = {}
FLS.colors = {}
FLS.data = {}

include("modules/mod_esp.lua")
include("modules/mod_menu.lua")
include("modules/mod_lua.lua")
include("modules/mod_bhop.lua")
include("modules/mod_antimute.lua")
include("modules/mod_antiblind.lua")
include("modules/mod_antieffects.lua")
include("modules/mod_crash.lua")
include("modules/mod_rotate.lua")

local function Initialize()
	print("** Starting Forline Scripts v1.0")
end

Initialize()