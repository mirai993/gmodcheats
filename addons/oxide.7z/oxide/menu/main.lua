/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox
*/

//-/~ Main Table
local Main = { }

//-/~ Setup Enviroment
local G = table.Copy( _G )

local Enviroment = setmetatable( {
    Main = Main,

    G = G,
    _G = _G
}, {
    __index = G,
} )

//-/~ Load Essentials
Main.Local = LocalPlayer( )

Main.Colors = { 
    White       = color_white,
    Black       = color_black,
    Transparent = color_transparent,

    Red   = Color( 255,0,0 ),
    Green = Color( 0,255,0 ),
    Blue  = Color( 0,0,255 ),

    Yellow = Color( 255,255,0 ),
    Orange = Color( 255,165,0 ),
    Orchid = Color( 86,85,211 ),
    Cyan   = Color( 0,255,255 ),
    Gray   = Color( 128,128,128 )
}

Main.Files = {
    Base    = file.Find( 'lua/oxide/code/base/*.lua', 'GAME' ),
    Modules = file.Find( 'lua/oxide/code/*.lua', 'GAME' )
}

function Main:Print( Text )
    G.MsgC( color_white, '[ ', self.Colors.Orange, 'oxide', color_white, ' ] ' .. Text .. '\n' )
end

function Main:ExecuteLua( Code, Insecure )
    local Compiled = G.CompileString( Code, 'oxide', true )

    if not Compiled then 
        self:Print( 'Failed to execute Lua file!\n' )

        G.debug.Trace( )

        return false
    end

    if Insecure then
        Compiled( )

        return true 
    end

    setfenv( Compiled, Enviroment )( )

    return true 
end

//-/~ Load Base Library
for i = 1, #Main.Files.Base do 
    Main:ExecuteLua( file.Read( 'lua/oxide/code/base/' .. Main.Files.Base[ i ], 'GAME' ) )
end

//-/~ Load Modules
for i = 1, #Main.Files.Modules do 
    Main:ExecuteLua( file.Read( 'lua/oxide/code/' .. Main.Files.Modules[ i ], 'GAME' ) )
end