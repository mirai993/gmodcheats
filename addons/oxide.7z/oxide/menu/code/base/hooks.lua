/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Cache
local Cache = { }

//-/~ Hook
function Main:Hook( Event, Callback )
    if not Cache[ Event ] then 
        Cache[ Event ] = { }

        gameevent.Listen( Event )

        hook.Add( Event, 'oxide_' .. Event, function( ... ) 
            for i = 1, #Cache[ Event ] do 
                Cache[ Event ][ i ] ( ... )
            end
        end )

        self:Print( 'Hooked New Callback: "' .. Event .. '"' )
    end

    table.insert( Cache[ Event ], Callback )

    return Callback
end

//-/~ Unhook
function Main:Unhook( Event, CallbackOrIndex )
    if not Cache[ Event ] then return end
    
    if isfunction( CallbackOrIndex ) then 
        for i = 1, #Cache[ Event ] do 
           if Cache[ Event ][ i ] == CallbackOrIndex then 
                table.remove( Cache[ Event ], i )
           end
        end
    elseif isnumber( CallbackOrIndex ) then
        table.remove( Cache[ Event ], CallbackOrIndex )
    end
end