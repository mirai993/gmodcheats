/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Materials
Materials = { 
    Disired = { 
        [ 'Textured' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/debug/debugwhite',
                [ '$nocull' ] = 1, -- Optimization, doesn't cause any issues
            },
        },

        [ 'Flat' ] = {
            'UnLitGeneric', -- This material shader is what gives it the `flat` look.
            {
                [ '$basetexture' ] = 'models/debug/debugwhite',
                [ '$nocull' ] = 1,
            },
        },

        [ 'Wireframe' ] = {
            'UnLitGeneric',
            {
                [ '$wireframe' ] = 1, -- We just use a set wireframe here instead of a material.
                [ '$nocull' ] = 1,  
            }
        },

        [ 'Glass' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/shadertest/shader5',
                [ '$nocull' ] = 1,
            }
        },

        [ 'Metal' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'vgui/white_additive',
                [ '$envmap' ] = 'effects/cubemapper',
                [ '$nocull' ] = 1,
            },
        },

        [ 'Globe' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/props_combine/tprings_globe',
                [ '$nocull' ] = 1,
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 0.9,
                        [ 'texturescrollangle' ] = 50,
                    }
                },
            }
        },

        [ 'Comball' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/effects/comball_sphere',
                [ '$nocull' ] = 1,
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 1.5,
                        [ 'texturescrollangle' ] = 50,
                    }
                },
            }
        },

        [ 'Liquid' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/shadertest/shader4',
                [ '$nocull' ] = 1,
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = .5,
                        [ 'texturescrollangle' ] = 20,
                    }
                },
            }
        },

        [ 'Hoverball' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'models/props_combine/portalball001_sheet',
                [ '$nocull' ] = 1,
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = .8,
                        [ 'texturescrollangle' ] = 50,
                    }
                },
            }
        },

        [ 'Scan' ] = { -- This one only likes to work on specific colors.
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = "models/dav0r/hoverball",
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ '$nocull' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 0.45,
                        [ 'texturescrollangle' ] = 90,
                    }
                },
            }
        },

        [ 'Star' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = "models/props_combine/stasisfield_beam",
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ '$nocull' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 0.65,
                        [ 'texturescrollangle' ] = 90,
                    }
                },
            }
        },

        [ 'Lines' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = "models/effects/portalrift_sheet",
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ '$nocull' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 0.5,
                        [ 'texturescrollangle' ] = 60,
                    }
                },
            }
        },

        [ 'Net' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = "models/shadertest/vertexlitalphatestedtexture",
                [ '$nodecal' ] = 1,
                [ '$model' ] = 1,
                [ '$additive' ] = 1,
                [ '$nocull' ] = 1,
                [ 'Proxies' ] = {
                    [ 'TextureScroll' ] = {
                        [ 'texturescrollvar' ] = '$basetexturetransform',
                        [ 'texturescrollrate' ] = 0.5,
                        [ 'texturescrollangle' ] = 90,
                    }
                },
            }
        },

        [ 'Glow' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'vgui/white_additive',
                [ '$bumpmap' ] = 'vgui/white_additive',
                [ '$model' ] = 1,
                [ '$nocull' ] = 0,
                [ '$selfillum' ] = 1,
                [ '$selfIllumFresnel' ] = 1,
                [ '$selfIllumFresnelMinMaxExp' ] = '[0.0 0.3 0.6]',
                [ '$selfillumtint' ] = '[0 0 0]',
            }
        },

        [ 'Glow Outlined' ] = {
            'VertexLitGeneric',
            {
                [ '$basetexture' ] = 'vgui/white_additive',
                [ '$bumpmap' ] = 'vgui/white_additive',
                [ '$model' ] = 1,
                [ '$nocull' ] = 1,
                [ '$nodecal' ] = 1,
                [ '$additive' ] = 1,
                [ '$selfillum' ] = 1,
                [ '$selfIllumFresnel' ] = 1,
                [ '$selfIllumFresnelMinMaxExp' ] = '[0.0 0.3 0.6]',
                [ '$selfillumtint' ] = '[0 0 0]',
            }
        },

        [ 'Arrow' ]   = 'gui/arrow',
        [ 'Laser' ]   = 'trails/laser',
        [ 'Smoke' ]   = 'trails/smoke',
        [ 'Beam' ]    = 'sprites/tp_beam001',
        [ 'Spark' ]   = 'effects/tool_tracer',
        [ 'Plasma' ]  = 'decals/plasmaglowfade',
        [ 'Generic' ] = 'effects/beam_generic01',
        [ 'Blur' ]    = 'effects/beam001_white',
        [ 'Hearts' ]  = 'trails/love'
    },
    Cache = { }
}

//-/~ Create Material
function Materials:CreateMaterial( Name, Shader, Data )
    if not Data then 
        self.Cache[ Name ] = Material( Shader )

        return true 
    end 

    self.Cache[ Name ] = CreateMaterial( Name, Shader, Data )

    if not self.Cache[ Name ] then return false end 

    return self.Cache[ Name ]
end

//-/~ Call Cached
function Materials:CallCached( Name )
    return self.Cache[ Name ]
end

//-/~ Populate Disired
function Materials:PopulateDisired( Name, Shader, Data )
    -- This function isn't actually used right now, possibly a future feature but mainly here for API purposes.
    self.Disired[ Name ] = {
        Shader,
        Data
    }
end

//-/~ Create Cached
function Materials:CreateCached( )
    for k,v in pairs( self.Disired ) do -- Used `pairs` here because we're planning on using k for index to access cached later through menu. 
        if isstring( v ) then -- Basic material support. 
            self:CreateMaterial( k, v ) 
            continue
        end 

        self:CreateMaterial( k, v[ 1 ], v[ 2 ] )

        v[ 2 ][ '$ignorez' ] = 1

        self:CreateMaterial( k .. 'IgnoreZ', v[ 1 ], v[ 2 ] )

        if Main.ConsoleInsert then 
            Main:ConsoleInsert( 'SYSTEM', 'Cached new material "' .. k .. '"', Color( 255, 87, 51 ) )
        end
    end

    -- Empty this, if we need it again we can refill it using `PopulateDisired`.
    table.Empty( self.Disired )
end

Materials:CreateCached( ) -- Run this here, no reason to not run it here.