/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Cache
local Cache = { }

//-/~ Hook
function Main:Hook( Event, Callback )
    if not Cache[ Event ] then 
        Cache[ Event ] = { }

        gameevent.Listen( Event )

        hook.Add( Event, 'oxide_' .. Event, function( ... ) 
            for i = 1, #Cache[ Event ] do 
                local Data = { Cache[ Event ][ i ] ( ... ) }

                if Data[ 1 ] then 
                    return unpack( Data, 2 )
                end
            end
        end )
    end

    table.insert( Cache[ Event ], Callback )

    return Callback
end