/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Playerlist = { 
    Chat = { },
    Blacklist = { },
    Players = { }
}

//-/~ Pass Object
function Playerlist:PassObject( Obj )
    self.DTree = Obj
end

//-/~ Is Blacklisted
function Playerlist:IsBlacklisted( ENT )
    local hasBlacklist = false
    
    for k,v in pairs( self.Blacklist ) do 
        if v then 
            hasBlacklist = true
            break
        end
    end

    if hasBlacklist then
        return self.Blacklist[ ENT ] == true
    else
        return true
    end
end

//-/~ Node
function Playerlist:Node( ENT )
    local New = self.DTree:AddNode( ENT:Nick( ), 'icon16/user_green.png' )

    self.Blacklist[ ENT ] = self.Blacklist[ ENT ] or false
    self.Chat[ ENT ] = self.Chat[ ENT ] or false

    New.DoRightClick = function( s )
        local Dropdown = DermaMenu( )
        
        if self.Blacklist[ ENT ] then 
            Dropdown:AddOption( 'Unblacklist', function( ) 
                self.Blacklist[ ENT ] = false
            end ):SetIcon( 'icon16/bullet_green.png' )
        else
            Dropdown:AddOption( 'Blacklist', function( ) 
                self.Blacklist[ ENT ] = true
            end ):SetIcon( 'icon16/bullet_red.png' )
        end

        if self.Chat[ ENT ] then 
            Dropdown:AddOption( 'Chat Block', function( ) 
                self.Chat[ ENT ] = false
            end ):SetIcon( 'icon16/add.png' )
        else
            Dropdown:AddOption( 'Chat Block', function( ) 
                self.Chat[ ENT ] = true
            end ):SetIcon( 'icon16/cancel.png' )
        end

        Dropdown:AddOption( 'Steal Name', function( ) 
            Name:Set( '\xe2\x80\x8b' .. ENT:Nick( ) )
        end ):SetIcon( 'flags16/rs.png' )

        Dropdown:AddOption( 'Copy SteamID', function( ) 
            SetClipboardText( ENT:SteamID( ) )
        end ):SetIcon( 'icon16/paste_plain.png' )

        Dropdown:AddOption( 'Copy SteamID64', function( ) 
            SetClipboardText( ENT:SteamID64( ) )
        end ):SetIcon( 'icon16/paste_word.png' )

        Dropdown:Open( )
    end

    New.DoClick = function( self ) end

    self.Players[ ENT ] = New
end

//-/~ Update
function Playerlist:Update( )
    local Targets, Found = player.GetAll( ), { }

    -- Add new ones.
    for i = 1, #Targets do 
        local Index = Targets[ i ]

        if not Index or Index:Nick( ) == 'unconnected' then 
            continue
        end

        if not self.Players[ Index ] then 
            self:Node( Index )
        end

        Found[ Index ] = true
    end

    -- Remove old ones.
    for k,v in pairs( self.Players ) do 
        if not Found[ k ] then 
            if self.Blacklist[ k ] then 
                self.Blacklist[ k ] = nil
            end

            self.Players[ k ]:Remove( ) -- Mark node for deletion.

            self.Players[ k ] = nil
        end
    end
end
