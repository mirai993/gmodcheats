/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Frame Stage Constants
FRAME_UNDEFINED                       = -1
FRAME_START                           = 1
FRAME_NET_UPDATE_START                = 2
FRAME_NET_UPDATE_POSTDATAUPDATE_START = 3
FRAME_NET_UPDATE_POSTDATAUPDATE_END   = 4
FRAME_NET_UPDATE_END                  = 5
FRAME_RENDER_START                    = 6
FRAME_RENDER_END                      = 7

//-/~ Interval
function Interval( )
    return Main.Interval
end

//-/~ Lerp Amount 
function Lerp( )
    if not Optimization then 
        return 
    end

    -- https://github.com/lua9520/source-engine-2018-hl2_src/blob/3bf9df6b2785fa6d951086978a3e66f49427166a/engine/client.cpp#L624

    return math.max( Optimization:ConVar( 'cl_interp_ratio' ):GetFloat( ) / Optimization:ConVar( 'cl_updaterate' ):GetFloat( ), Optimization:ConVar( 'cl_interp' ):GetFloat( ) )
end

//-/~ Server Time
function Servertime( )
    return TICK_TO_TIME( Main.Local:GetInternalVariable( 'm_nTickBase' ) )
end

//-/~ Time To Tick
function TIME_TO_TICK( Time )
    return math.floor( 0.5 + Time / Interval( ) )
end

//-/~ Tick To Time
function TICK_TO_TIME( Tick )
    return Interval( ) * Tick
end

//-/~ Round To Closest
function math.RoundToClosest( Value, Options )
    local Closest = Options[ 1 ]
    local Best = math.abs( Value - Closest )
    
    for i = 2, #Options do
        local Value = math.abs( Value - Options[ i ] )

        if Value < Best then
            Closest = Options[ i ]
            Best = Value
        end
    end
    
    return Closest
end

//-/~ Remove All
function table.RemoveByValueAll( Table, Value )
    for k,v in pairs( Table ) do 
        if v == Value then
            Table[ k ] = nil
        end
    end

    return Table
end

//-/~ Text
function AddText( Text )
    chat.AddText( color_white, '[ ', Main.Colors.Orange, 'oxide', color_white, ' ] ' .. Text )
end

//-/~ Limit
function math.Limit( Number, Min )
    if Number < Min then 
        return Min
    end

    return Number
end