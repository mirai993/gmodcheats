/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Binds Library
-- =============================================================================

-- Main Table
local Binds = { }

-- =============================================================================
-- Internal function used to handle when the player releases a button.
-- @param Ent (player): The current player pressing the button.
-- @param Key (number): The current key being released.
-- =============================================================================
function Main:PlayerButtonUp( Ent, Key )
    if Ent != Main.Local then return end 
    
    Binds[ Key ] = Binds[ Key ] or false 

    if Binds[ Key ] then 
        Binds[ Key ] = false 
    else 
        Binds[ Key ] = true 
    end 
end

-- =============================================================================
-- Function used to calculate if the player has a keybind down.
-- @param Key (number): The current key being released.
-- @param Toggle (boolean): Weather or not the keybind should be toggled.
-- @return boolean: Weather or not the keybind is pressed.
-- =============================================================================
function Main:InputDown( Key, Toggle )
    if Key == 0 then return true end 

    if Toggle then 
        return ( Binds[ Key ] or false )
    end 

    return input.IsButtonDown( Key )
end