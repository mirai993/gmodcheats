/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Dragable = {
    Cache = { }
}

//-/~ Gradients
local Gradient = Material( 'vgui/gradient-l' )

//-/~ New Dragable
function Dragable:NewDragable( Title, Y )
    local DFrame = vgui.Create( 'DFrame' )
    DFrame:SetPos( 0, Y or 0 )
    DFrame:SetSize( 90, 60 )
    DFrame:SetTitle( '' )
    DFrame:ShowCloseButton( false )
    DFrame.Paint = function( ) end

    local DPanelMain = vgui.Create( 'DPanel', DFrame )
    DPanelMain:Dock( FILL )
    DPanelMain.Paint = function( s, w, h )
        -- draw.RoundedBox(0, 0, 0, w, h, Color( 32, 32, 32 ) )
        -- surface.SetDrawColor( 42, 42, 42 )
        -- surface.DrawOutlinedRect(0, 0, w, h, 1 )
        -- surface.SetDrawColor( 0, 0, 0 )
        -- surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
    end

    local DPanel = vgui.Create( 'DPanel', DPanelMain )
    DPanel:Dock( TOP )
    DPanel:DockMargin(3, 3, 3, 0 )
    DPanel:SetTall( 18 )
    DPanel.Paint = function( s, w, h )
        surface.SetDrawColor( Main.Elements and Main.GetColor( Main.Elements[ 'Miscellaneous' ][ 'Settings' ], 'Menu Section Color' ) or Main.UIColors[ 'Purple04' ] )
        surface.SetMaterial( Gradient )
        surface.DrawTexturedRect( 0, 0, w, h )
        surface.SetDrawColor( Main.Elements and Main.GetColor( Main.Elements[ 'Miscellaneous' ][ 'Settings' ], 'Menu Accent Color' ) or Main.UIColors[ 'Purple03' ] )
        surface.DrawRect( 0, h-2, w, 2 )
        draw.SimpleText( Title, 'oxide.16', 3, h/2, color_white, 0, 1 )
    end

    self.Cache[ Title ] = { DFrame = DFrame, DPanelMain = DPanelMain, Labels = { } }

    return DFrame, DPanelMain
end

//-/~ Grab Cache
function Dragable:GrabCache( Title )
    return self.Cache[ Title ]
end

//-/~ Calculate Size
function Dragable:CalculateSize( Data )
    -- Calculate the largest text.
    local Largest, Count = 0, 0

    for k,v in pairs( Data.Labels ) do 
        local LabelText = v:GetText( )

        if #LabelText > Largest then 
            Largest = #LabelText
        end

        Count = Count + 1
    end

    -- Calculate X and Y for the main frame.
    local X, Y = 90, 60 + ( Count * 20 )

    if Largest > 10 then 
        X = X + ( Largest * 2.5 )
    end

    Data.DFrame:SetSize( X, Y )
end

//-/~ Add Index
function Dragable:AddIndex( Title, Text )
    if not Text or not Title then return end 

    local Data = self.Cache[ Title ]

    local DLabel = vgui.Create( 'DLabel', Data.DPanelMain )
    DLabel:Dock( TOP )
    DLabel:DockMargin( 5, 0, 0, 0 )
    DLabel:SetText( Text )
    DLabel:SetFont( 'oxide.13' )
    DLabel:SetTextColor( Color( 255, 255, 255 ) )

    self.Cache[ Title ].Labels[ Text ] = DLabel

    Dragable:CalculateSize( Data )
end

//-/~ Clear Labels
function Dragable:ClearLabels( Title )
    if not Title then return end 

    local Data = self.Cache[ Title ]

    for k,v in pairs( self.Cache[ Title ].Labels ) do 
        v:Remove( )

        self.Cache[ Title ].Labels[ k ] = nil
    end
    
    Data.DFrame:SetSize( 90, 60 )
end

//-/~ Remove Label
function Dragable:RemoveLabel( Title, Text )
    if not Title then return end 

    self.Cache[ Title ].Labels[ Text ]:Remove( )

    self.Cache[ Title ].Labels[ Text ] = nil

    Dragable:CalculateSize( self.Cache[ Title ] )
end

//-/~ Set Visible
function Dragable:SetVisible( Title, Visible )
    self.Cache[ Title ].DFrame:SetVisible( Visible )
end