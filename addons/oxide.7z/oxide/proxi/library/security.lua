/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

proxi = table.Copy( proxi )

_G.proxi = nil

if _M then 
    _M:PatchMetaTables( {
        [ 'Entity' ] = {
            [ 'SetDTNetVar' ] = true,
            [ 'GetDTNetVar' ] = true,
            [ 'SetInterpolationEnabled' ] = true
        },

        [ 'CUserCmd' ] = {
            [ 'GetInWorldClicker' ] = true,
            [ 'SetInWorldClicker' ] = true,
            [ 'GetWorldClickerAngles' ] = true,
            [ 'SetWorldClickerAngles' ] = true,
            [ 'SetCommandNumber' ] = true,
            [ 'SetTickCount' ] = true,
            [ 'HasBeenPredicted' ] = true,
            [ 'GetIsTyping' ] = true,
            [ 'SetIsTyping' ] = true,
            [ 'GetButtonDown' ] = true,
            [ 'SetButtonDown' ] = true,
            [ 'GetRandomSeed' ] = true,
            [ 'SetRandomSeed' ] = true
        },

        [ 'ConVar' ] = {
            [ 'ForceFloat' ] = true,
            [ 'ForceBool' ] = true,
            [ 'ForceInt' ] = true,
            [ 'ForceString' ] = true,
            [ 'ForceMax' ] = true,
            [ 'ForceMin' ] = true,
            [ 'ForceHasMax' ] = true,
            [ 'ForceHasMin' ] = true,
            [ 'SetFlags' ] = true,
            [ 'SendValue' ] = true
        }
    } )
end
