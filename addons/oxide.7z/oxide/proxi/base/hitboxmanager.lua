/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Hitbox Manager Library
-- =============================================================================

-- Main Table
Hitboxes = { 
    Cache = { }
}

function Hitboxes:HandleMultipoint( Ent, Internal, Matrix, Ang, Info )
    if not Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Multipoint' ] then return Internal end

    -- Get the scale.
    local Scale = Info.Group == HITGROUP_HEAD and Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Head Scale' ] or Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Body Scale' ]

    Scale = Scale / 200

    -- Visualization.
    local Visualize = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Visualize Multipoints' ]

    -- Calculate Mins/Maxs.
    local Mins, Maxs = Ent:GetHitBoxBounds( Info.Hitbox, Info.Set )

    -- Calculate points.
    local Points = {
        ( ( Mins + Maxs ) * 0.5 ),
        Vector( Mins.x, Mins.y, Mins.z ),
        Vector( Mins.x, Maxs.y, Mins.z ),
        Vector( Maxs.x, Maxs.y, Mins.z ),
        Vector( Maxs.x, Mins.y, Mins.z )
    }

    for i = 1, #Points do
        Points[ i ]:Rotate( Ang )
        Points[ i ] = Points[ i ] + Matrix

        if i == 1 then 
            table.insert( Internal, Points[ i ] )
            -- debugoverlay.Cross( Points[ i ], 2, 1, Color( 255,0,0 ) )
            continue 
        end
        
        Points[ i ] = ( ( Points[ i ] - Points[ 1 ] ) * Scale ) + Points[ 1 ]
        
        table.insert( Internal, Points[ i ] )

        if Visualize and Ent != Main.Local then 
            Overlay:Box( Points[ i ], Vector( 0, 0, 0 ), Vector( .5, .5, .5 ), .1, Main.GetColor( Main.Elements[ 'Aimbot' ][ 'Target Selection' ], 'Visualize Multipoints' ), false )
        end
    end

    return Internal
end

-- =============================================================================
-- Function to parse the bone matrix of an entity.
-- @param Ent (entity): The entity to parse the bone matrix for.
-- @return Temp (table): A table containing the parsed bone matrices (positional vectors).
-- =============================================================================
function Hitboxes:ParseInformation( Ent )
    -- Get our model and start our cache.
    local Model = Ent:GetModel( )

    self.Cache[ Model ] = { }

    -- Get our sets.
    local Temp, Sets = { }, Ent:GetHitboxSetCount( )

    if Sets == 0 then return Temp end 
    
    -- Loop through sets and count to get bone information.
    for i = 0, Sets - 1 do
        local Count = Ent:GetHitBoxCount( i )

        for c = 0, Count do 
            local Group, Bone = Ent:GetHitBoxHitGroup( c, i ), Ent:GetHitBoxBone( c, i )

            if not Group or not Bone then continue end 

            local Name = Ent:GetBoneName( Bone )

            if not Name then continue end 

            if Name == '__INVALIDBONE__' then
                self.Cache[ Model ] = '__INVALIDBONE__'
                return { }
            end 

            Temp[ Group ] = Temp[ Group ] or { }

            table.insert( Temp[ Group ],  { Name = Name, Hitbox = c, Set = i, Group = Group } )
        end
    end

    self.Cache[ Model ] = Temp
    
    return Temp
end

-- =============================================================================
-- Function to get the bone matrix information for an entity.
-- @param Ent (entity): The entity to get the matrix information for.
-- @return Temp (table): A table containing the matrix information. Will be empty if none is found.
-- =============================================================================
function Hitboxes:GetMatrixInformation( Ent )
    local Temp, Data = { }, self.Cache[ Ent:GetModel( ) ]

    if Data == '__INVALIDBONE__' then 
        self:ParseInformation( Ent )
        return
    elseif not Data then 
        Data = self:ParseInformation( Ent )
    end

    for k,v in pairs( Data ) do 
        local Internal = { }

        for i = 1, #v do 
            local Info = v[ i ]

            local Bone = Ent:LookupBone( Info.Name )

            if not Bone then 
                return self:ParseInformation( Ent )
            end

            local Matrix, Ang = Ent:GetBonePosition( Bone )

            if not Matrix or not Ang then 
                continue
            end 
            
            table.insert( Internal, Matrix )

            Internal = Hitboxes:HandleMultipoint( Ent, Internal, Matrix, Ang, Info )
        end

        Temp[ k ] = Internal
    end

    return Temp
end

concommand.Add('sexing', function()
    PrintTable( Hitboxes.Cache )
end)