/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Rebuilt `debugoverlay` Library
-- =============================================================================

-- Main Table
Overlay = { 
    Cache = { }
}

-- =============================================================================
-- Function to draw a overlay line at the next avaliable frame.
-- @param Position (vector): The first positional vector to start the line from.
-- @param NewPosition (vector): The goal positional vector of the line.
-- @param Lifetime (number): The lifetime of the line. Optional.
-- @param Color (color): The color of the line. Optional.
-- @param IgnoreZ (boolean): Weather or not the line should ignore the depth buffer. Optional.
-- =============================================================================
function Overlay:Line( Position, NewPosition, Lifetime, Color, IgnoreZ )
    -- Load in the same defaults as `debugoverlay.Line`
    Lifetime = Lifetime or 1
    Color = Color or color_white
    IgnoreZ = IgnoreZ or false 

    -- Insert our stuff into cache
    table.insert( Overlay.Cache, { Type = 'Line', Time = CurTime( ), Position = Position, NewPosition = NewPosition, Lifetime = Lifetime, Color = Color, IgnoreZ = IgnoreZ } )
end

-- =============================================================================
-- Function to draw an angle orientated overlay box at the next avaliable frame.
-- @param Position (vector): The first positional vector to start the line from.
-- @param Mins (vector): The minimum bounds of the box.
-- @param Maxs (vector): The maximum bounds of the box.
-- @param Angle (angle): The angle of the box.
-- @param Lifetime (number): The lifetime of the box. Optional.
-- @param Color (color): The color of the box. Optional.
-- @param IgnoreZ (boolean): Weather or not the box should ignore the depth buffer. Optional.
-- =============================================================================
function Overlay:BoxAngles( Position, Mins, Maxs, Angles, Lifetime, Color, IgnoreZ )
    -- Load in the same defaults as `debugoverlay.BoxAngles`
    Lifetime = Lifetime or 1
    Color = Color or color_white
    IgnoreZ = IgnoreZ or false 

    -- Insert our stuff into cache
    table.insert( Overlay.Cache, { Type = 'Box', Time = CurTime( ), Position = Position, Mins = Mins, Maxs = Maxs, Angles = Angles, Lifetime = Lifetime, Color = Color, IgnoreZ = IgnoreZ } )
end

-- =============================================================================
-- Function to draw a overlay beam at the next avaliable frame.
-- @param Position (vector): The first positional vector to start the beam from.
-- @param NewPosition (vector): The goal positional vector of the beam.
-- @param Width (number): The width of the beam.
-- @param textureStart (number): The starting coordinate of the beam texture.
-- @param textureEnd (number): The ending coordinate of the beam texture.
-- @param Lifetime (number): The lifetime of the beam.
-- @param Color (color): The color of the beam.
-- @param Material (material): The material of the beam.
-- @param IgnoreZ (boolean): Weather or not the beam should ignore the depth buffer. Optional.
-- =============================================================================
function Overlay:Beam( Position, NewPosition, Width, textureStart, textureEnd, Lifetime, Color, Material, IgnoreZ )
    -- Load in the same defaults as `render.DrawBeam`
    Lifetime = Lifetime or 1
    Color = Color or color_white
    IgnoreZ = IgnoreZ or false 

    -- Insert our stuff into cache
    table.insert( Overlay.Cache, { Type = 'Beam', Time = CurTime( ), Position = Position, NewPosition = NewPosition, Width = Width, textureStart = textureStart, textureEnd = textureEnd, Lifetime = Lifetime, Color = Color, Material = Material, IgnoreZ = IgnoreZ } )
end

-- =============================================================================
-- Function to draw a overlay sprite at the next avaliable frame.
-- @param Position (vector): The positional vector to spawn the sprite.
-- @param Width (number): The width of the sprite.
-- @param Height (number): The height of the sprite.
-- @param Material (material): The material of the sprite.
-- @param Lifetime (number): The lifetime of the sprite.
-- @param Color (color): The color of the sprite.
-- @param IgnoreZ (boolean): Weather or not the sprite should ignore the depth buffer. Optional.
-- =============================================================================
function Overlay:Sprite( Position, Width, Height, Material, Lifetime, Color, IgnoreZ )
    -- Load in the same defaults as `render.DrawSprite`
    Lifetime = Lifetime or 1
    Color = Color or color_white
    IgnoreZ = IgnoreZ or false 

    -- Insert our stuff into cache
    table.insert( Overlay.Cache, { Type = 'Sprite', Time = CurTime( ), Position = Position, Width = Width, Height = Height, Material = Material, Lifetime = Lifetime, Color = Color, IgnoreZ = IgnoreZ } )
end

-- =============================================================================
-- Function to draw a overlay box at the next avaliable frame.
-- @param Position (vector): The first positional vector to put the box.
-- @param Mins (vector): The minimum bounds of the box.
-- @param Maxs (vector): The maximum bounds of the box.
-- @param Lifetime (number): The lifetime of the box. Optional.
-- @param Color (color): The color of the box. Optional.
-- @param IgnoreZ (boolean): Weather or not the box should ignore the depth buffer. Optional.
-- =============================================================================
function Overlay:Box( Position, Mins, Maxs, Lifetime, Color, IgnoreZ )
    return self:BoxAngles( Position, Mins, Maxs, Angle( 0, 0, 0 ), Lifetime, Color, IgnoreZ )
end

-- =============================================================================
-- Internal function used to draw all the rendering. Detour if you'd like.
-- =============================================================================
function Overlay:Hook( )
    local Time = CurTime( )

    for k,v in ipairs( self.Cache ) do 
        if v.Time+v.Lifetime < Time then 
            table.remove( self.Cache, k )
            continue 
        end

        cam.IgnoreZ( v.IgnoreZ )
    
        render.SetColorMaterial( )

        if v.Type == 'Box' then 
            render.DrawBox( v.Position, v.Angles, v.Mins, v.Maxs, v.Color )
        elseif v.Type == 'Line' then
            render.DrawLine( v.Position, v.NewPosition, v.Color, v.IgnoreZ )
        elseif v.Type == 'Beam' then 
            render.SetMaterial( v.Material )

            render.DrawBeam( v.Position, v.NewPosition, v.Width, v.textureStart, v.textureEnd, v.Color )           
        elseif v.Type == 'Sprite' then 
            render.SetMaterial( v.Material )

            render.DrawSprite( v.Position, v.Width, v.Height, v.Color )
        end
    end

    cam.IgnoreZ( false )
end