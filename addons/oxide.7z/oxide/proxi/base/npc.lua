/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- NPC Library
-- =============================================================================

-- Main Table
NPCs = {
    Cache = { }
}

-- =============================================================================
-- Function to add a callback for the Entity provided. Use with CallCallback.
-- @param Class (string): The entities class name.
-- @param Func (function): The function to call when validating the Entity.
-- =============================================================================
function NPCs:AddCallback( Class, Func )
    table.insert( self.Cache, { Class, Func } )
end

-- =============================================================================
-- Function to call a callback relating to an Entity to make sure it's valid.
-- @param Ent (entity): The entity you wish to validate.
-- @return boolean: Whether the Entity is valid or not.
-- =============================================================================
function NPCs:CallCallback( Ent )
    if not Ent then 
        return false
    end 

    local Class = Ent:GetClass( )
    if not Class then 
        return false
    end

    for i = 1, #self.Cache do 
        local Data = self.Cache[ i ]

        if string.StartsWith( Class, Data[ 1 ] ) then 
            return Data[ 2 ]( Ent )
        end 
    end

    return false
end

-- =============================================================================
-- Function to support the avoid methods on NZombies.
-- @param Ent (entity): The entity to validate. Unused currently.
-- @return boolean: Whether the Entity is valid or not.
-- =============================================================================
function NPCs:NZombies( Ent )
    if not Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'NZombies Support' ] and Main.Gamemode == 'nzombies' then 
        return true 
    end

    if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid When Down' ] then 
        -- NZombies Unlimited
        if Main.Local.GetIsDowned and Main.Local:GetIsDowned( ) then 
            return true 
        end 
    
        -- NZombies Rezzurrection / NZombies Chronicles
        if Main.Local.GetNotDowned and not Main.Local:GetNotDowned( ) then 
            return true 
        end 
    end 

    return false 
end

-- =============================================================================
-- Add built-in NPC callbacks.
-- =============================================================================

NPCs:AddCallback( 'drg_moo_codz', NPCs.NZombies )
NPCs:AddCallback( 'nz_zombie', NPCs.NZombies )