/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Progress Bar Library
-- =============================================================================

-- Main Table
Progress = { }

-- =============================================================================
-- Function to initialize a new progress bar.
-- @param Identity (string): Identity of the newly made progress bar. Used to grab the panel info.
-- @param VScale (number): Vertical scaling of the panel.
-- @param HScale (number): Horizontal scaling of the panel.
-- @param SizeX (number): Vertical size of the panel.
-- @param SizeY (number): Horizontal size of the panel.
-- @param Paint (function): Function to override the default paint with. Optional.
-- @return panel: The newly made DProgress bar reference panel.
-- =============================================================================
function Progress:New( Identity, VScale, HScale, SizeX, SizeY, Paint, Text )
    local DFrame = vgui.Create( 'DFrame' )
    DFrame:SetSize( SizeX, SizeY + 36 )
    DFrame:CenterVertical( VScale )
    DFrame:CenterHorizontal( HScale )
    DFrame:SetDraggable( true )
    DFrame:SetVisible( false )
    DFrame:ShowCloseButton( false )
    DFrame:SetTitle( '' )
    
    DFrame.Paint = function( ) end
    
    local DProgress = vgui.Create( 'DProgress', DFrame )
    DProgress:Dock( FILL )    

    if Paint then 
        DProgress.Paint = Paint
    end

    local DLabel;

    if Text then 
        local DLabel = vgui.Create( 'DLabel' )
        DLabel:SetColor( color_black )
        DLabel:SetText( Text )
        DLabel:SetFont( 'oxide.16' )

        DLabel.Think = function( )
            local X, Y, W, H = DFrame:GetBounds( )

            DLabel:SetPos( X + W, Y + ( H / 2 ) + 4 )    
            DLabel:SetColor( DFrame:IsVisible( ) and color_black or color_transparent )
        end
    end

    Progress[ Identity ] = { DProgress = DProgress, DFrame = DFrame, DLabel = DLabel }

    return DProgress, DFrame
end


-- =============================================================================
-- Function to grab the panel reference.
-- @param Identity (string): Identity to grab the panel of.
-- @return panel: The DProgress bar reference panel.
-- =============================================================================
function Progress:GetPanel( Identity )
    return Progress[ Identity ]
end

-- =============================================================================
-- Function to initialize a new progress bar.
-- @param Identity (string): Identity of the progress bar to update.
-- @param Fractio (number): The progress of the progress bar (0-1).
-- @param VScale (number): Vertical scaling of the panel.
-- @param HScale (number): Horizontal scaling of the panel.
-- @return boolean: If the update was successful or not.
-- =============================================================================
function Progress:Update( Identity, Fraction, Text )
    local DProgress = self:GetPanel( Identity )
    
    if not DProgress then 
        return false 
    end 

    DProgress.DProgress:SetFraction( Fraction or 0 )

    if DProgress.DLabel and Text then 
        DProgress.DLabel:SetText( Text )
    end

    return true 
end

-- =============================================================================
-- Function to grab the progress bars fraction.
-- @param Identity (string): Identity to grab the panel of.
-- @return number: The progress fraction (0-1). Will be nil if the panel was invalid.
-- =============================================================================
function Progress:Get( Identity )
    local DProgress = self:GetPanel( Identity )

    if not DProgress then 
        return 
    end 

    return DProgress:GetFraction( )
end

-- =============================================================================
-- Function to set the visibility of a progress bar.
-- @param Identity (string): Identity to set the visibility of.
-- @param Visible (boolean): If the panel should be visible or not.
-- @return boolean: If the update was successful or not.
-- =============================================================================
function Progress:SetVisible( Identity, Visible )
    local DProgress = self:GetPanel( Identity ).DFrame

    if not DProgress then 
        return false
    end 

    DProgress:SetVisible( Visible )

    return true
end