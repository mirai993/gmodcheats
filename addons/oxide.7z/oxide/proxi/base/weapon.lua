/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Weapon Library
-- =============================================================================

-- Main Table
Weapon = { }

-- =============================================================================
-- Function to handle calculating the fire delay between shots.
-- @param Delay (number): The delay amount (in ms). Optional.
-- @param SWEP (weapon): The desired weapon to calculate delay for.
-- @return boolean: If you can currently fire the provided SWEP. 
-- =============================================================================
function Weapon:CanAttack( Delay, SWEP )
    Delay = Delay or 0  

    return SWEP:GetNextPrimaryFire( ) + math.Remap( Delay, 0, 1000, 0, 1 ) <= Main.BulletTime
end

function Weapon:CanAttackSimple( )
    local SWEP = Main.Local:GetActiveWeapon()
    
    if not SWEP:IsValid() then return false end

    return self:CanAttack( 0, SWEP )
end

-- =============================================================================
-- Function to handle calculating the base of the provided SWEP.
-- @param SWEP (weapon): The desired weapon to calculate base of.
-- @return string: The base of the SWEP or `None` if we couldn't find one.
-- =============================================================================
function Weapon:GetBase( SWEP )
    local Base, Class = SWEP.Base, ( SWEP.ClassName or SWEP:GetPrintName( ) )
    
    if Base == 'bobs_gun_base' or Base == 'bobs_shotty_base' or Base == 'bobs_scoped_base' or Base == 'bobs_nade_base' then 
        return 'M9K'
    elseif Base == 'tfa_gun_base' or Base == 'tfa_bash_base' or Base == 'tfa_3dscoped_base' or Base == 'tfa_cso_crow_base' then 
        return 'TFA' 
    elseif  Base == 'tfa_rust_recoilbase' then 
        return 'TFA:RUST'
    elseif Base == 'fas2_base' then 
        return 'FA:S'
    elseif Base == 'cw_base' or Base == 'cw_melee_base' or Base == 'cw_kk_dods_base' then 
        return 'CW 2.0'
    elseif Base == 'weapon_swcs_base_grenade' or Base == 'weapon_swcs_base_item' or Base == 'weapon_swcs_knife' or Base == 'weapon_swcs_base' then
        return 'SWCS'
    elseif Base == 'arccw_base_melee' or Base == 'arccw_base' or Base =='arccw_mw2_abase' then
        return 'ARCCW'
    elseif Base == 'tacrp_base' then 
        return 'TACRP' 
    elseif Base == 'swb_base' then 
        return 'SWB'
    elseif Base == 'weapon_rtbr_base' then 
        return 'RTB'
    end

    -- If we haven't found a base, we can try using the class setup we defined pre-boot.
    if Class then 
        for k,v in pairs( Main.SWEPs ) do 
            if string.StartsWith( Class, k ) then 
                return v
            end
        end
    end 

    return 'None'
end