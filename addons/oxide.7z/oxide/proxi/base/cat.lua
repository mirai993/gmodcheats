/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & scott
*/

-- =============================================================================
-- Cat Library
-- =============================================================================

-- Main Table
Cat = { 
    Extensions = {
        '.png',
        '.jpeg',
        '.jpg' 
    },

    Cache = { }
}

-- =============================================================================
-- Function to verify if a path picture is valid or not.
-- @param Name (string): The path to the cat.
-- @return boolean: If the picture was valid.
-- =============================================================================
function Cat:Valid( Name )
    for k,v in ipairs( self.Extensions ) do 
        if string.EndsWith( Name, v ) then 
            return true 
        end
    end

    return false
end

-- =============================================================================
-- Function to grab a random cat from the disk.
-- @param Seed (number): The seed of the random generation. Optional.
-- @return string: The random cat data or nil if the data wasn't found.
-- =============================================================================
function Cat:GrabDisk( Seed )
    local Files, Directories = file.Find( 'cat/*', 'DATA' )
    local Cache = { }

    for k,v in ipairs( Files ) do 
        if not self:Valid( v ) then continue end -- Invalid picture.

        table.insert( Cache, v )
    end

    if Seed then 
        math.randomseed( Seed )
    end

    local Directory = 'cat/' .. Cache[ math.random( 1, #Cache ) ]

    if not Directory or not file.Exists( Directory, 'DATA' ) then return end 

    local Data = file.Open( Directory, 'rb', 'DATA' )

    if not Data then return end 

    return Data:Read( )
end

-- =============================================================================
-- Helper function to append data to the end of a URL.
-- @param URL (string): The current URL.
-- @param Text (string): The identifier of the appended text.
-- @param Data (string): The setting the user wants applied.
-- @return string: The URL with the appended format.
-- =============================================================================
function Cat:AppendWeb( URL, Text, Data )
    if not Text or not Data then 
        return URL 
    end 

    return string.format( '%s%s=%s&', URL, Text, Data )
end 

-- =============================================================================
-- Function to dump all active cache information to disk.
-- =============================================================================
function Cat:Dump( )
    for k,v in ipairs( self.Cache ) do 
        file.Write( string.format( 'cat/%s.png', k ), v )
    end
end

-- =============================================================================
-- Function to clear all active cache information.
-- @param Index (number): The index of the cache that needs to be cleared. Optional
-- =============================================================================
function Cat:Clear( Index )
    if Index then 
        return table.remove( self.Cache, Index )
    end

    self.Cache = { }
end

-- =============================================================================
-- Function to pop the top of the cache.
-- @param Index (number): The index of the cache to be grabbed. Optional
-- @return string: The data of the image. Will return nil if none found.
-- =============================================================================
function Cat:Pop( Index )
    return table.remove( self.Cache, Index )
end

-- =============================================================================
-- Function to grab the index of the cache.
-- @param Index (number): The index of the cache to be grabbed.
-- @return string: The data of the image. Will return nil if none found.
-- =============================================================================
function Cat:Grab( Index )
    return self.Cache[ Index ]
end

-- =============================================================================
-- Function to grab a random cat from `cataas`. See the refrence page for API documentation on `cataas`.
-- @param Func (function): A function to be called when the HTTP fetch is completed. Will not be called for errors.
-- @param Type (string): The type of image..
-- @param Filter (string): Filters the server to find images.
-- @param Says (string): Adds a word to the bottom of the image.
-- @param Width (string): The width of the image.
-- @param Height (string): The height of the image.
-- @param Brightness (string): The brightness of the supplied image.
-- @param Lightness (string): The lightness of the supplied image.
-- @param Saturation (string): The saturation of the supplied image.
-- @param Hue (string): The hue of the supplied image.
-- @param Color (color): The color tint of the supplied image.
-- =============================================================================
function Cat:GrabWeb( Func, Type, Filter, Says, Width, Height, Brightness, Lightness, Saturation, Hue, Color )
    local URL = 'https://cataas.com/cat'

    -- Calculate Says.
    if Says then 
        URL = URL .. '/says/' .. Says .. '?'
    else 
        URL = URL .. '?'
    end 

    -- Append all of these to the end of the generated URL.
    URL = self:AppendWeb( URL, 'type', Type )
    URL = self:AppendWeb( URL, 'filter', Filter ) -- Use custom for custom colors.
    URL = self:AppendWeb( URL, 'width', Width )
    URL = self:AppendWeb( URL, 'height', Height )
    URL = self:AppendWeb( URL, 'brightness', Brightness )
    URL = self:AppendWeb( URL, 'lightness', Lightness )
    URL = self:AppendWeb( URL, 'saturation', Saturation )
    URL = self:AppendWeb( URL, 'hue', Hue )

    if Color then
        URL = self:AppendWeb( URL, 'r', Color.r )
        URL = self:AppendWeb( URL, 'g', Color.g )
        URL = self:AppendWeb( URL, 'b', Color.b )
    
        if Filter != 'custom' then 
            Main:Print( 'Warning! Must use custom filter to effect color.' )
        end
    end
 
    -- Strip the `&` from the end of the URL.
    URL = string.sub( URL, 1, #URL-1 )

    http.Fetch( URL, function( Body, Size, Headers, Code )
        local Index = table.insert( self.Cache, Body )

        if Func then 
            Func( Body, Size, Index )
        end 
    end, function( Code )
        Main:Print( 'Failed to grab URL. Code: ' .. ( Code or 'unknown' ) )
    end )
end