/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Command Helper Library
-- =============================================================================

-- Main Table
Command = { 
    Cache = { } 
}

-- =============================================================================
-- Function to print all the command information to console.
-- @param Table (table): The table containing command information.
-- =============================================================================
function Command:PrintInfo( Table )
    local Description = Table.Description and ' - '.. Table.Description or ''

    Main:ConsoleInsert( 'SYSTEM', 'Command `' .. Table.Name .. '`' .. Description, Color( 255, 87, 51 ) )
end

-- =============================================================================
-- Function to dynamically register a command within the in-game console.
-- @param Name (string): The name of the command.
-- @param Func (function): The function to execute when this command is ran.
-- @param Description (string): A description of the command.
-- @return Data (table): The table containing command information. This can be printed with PrintInfo.
-- =============================================================================
function Command:AddCommand( Name, Func, Description )
    local Data = { Name = Name, Func = Func, Description = Description }

    -- Insert data.
    table.insert( self.Cache, Data )

    return Data
end

-- =============================================================================
-- Internal function used to handle when the user presses enter in console.
-- @param Panel (panel): The panel where the text is entered.
-- @param Text (string): The text entered by the user.
-- @return boolean: Whether the command was found and executed.
-- =============================================================================
function Command:OnEnter( Panel, Text )
    Panel:SetText( '' ) -- Make the text entry blank.

    -- This allows it to sorta support dynamic console commands with custom values.
    local Text = string.Split( Text, ' ' )

    local First = Text[ 1 ]

    table.remove( Text, 1 )

    for _, v in pairs( self.Cache ) do 
        if v.Name == First then 
            return v.Func( table.concat( Text, ' ' ), Panel )
        end
    end

    Main:ConsoleInsert( 'SYSTEM', 'Unable to find command `' .. First .. '` (`' .. ( First or '' ) .. '`)', Color( 255, 87, 51 ) )

    return false 
end

-- =============================================================================
-- Add a default `help` command to list all loaded commands.
-- =============================================================================

Command:AddCommand( 'help', function( )
    for _, v in pairs( Command.Cache ) do 
        Command:PrintInfo( v )
    end
end, 'Lists all the commands currently loaded.' )

-- =============================================================================
-- Add a few default commands.
-- =============================================================================

Command:AddCommand( 'echo', function( Text )
    Main:ConsoleInsert( 'SYSTEM', Text, Color( 255, 87, 51 ) )
end, 'Echos whatever you type in.' )

Command:AddCommand( 'load', function( Text )
    local File = file.Open( 'oxide/configs/' .. Text .. '.json', 'rb', 'DATA' )

    Config:Parse( util.JSONToTable( File:Read( File:Size( ) ) ) )

    File:Close( )
end, 'Loads whatever config you put in.' )

Command:AddCommand( 'save', function( Text )
    local File = file.Open( 'oxide/configs/' .. Text .. '.json', 'wb', 'DATA' )

    File:Write( util.TableToJSON( Config:Generate( ), true ) )

    File:Close( )
end, 'Loads whatever config you put in.' )

Command:AddCommand( 'god_word', function( Text )
    local File = file.Open( 'oxide/God.txt', 'rb', 'DATA' )

    if not File then 
        Main:ConsoleInsert( 'SYSTEM', 'Failed to open a passage to God. Did you forget to download the Bible?', Color( 255, 87, 51 ) )
        return
    end

    local Text = string.Split( File:Read( File:Size( ) ), '\n' )

    Main:ConsoleInsert( 'SYSTEM', 'God Says: `' .. Text[ math.random( 1, #Text ) ] .. '`', Color( 255, 87, 51 ) )
end, 'Generates a god word.' )

Command:AddCommand( 'god_passage', function( Text )
    local Length = tonumber( Text ) or 10
    local File   = file.Open( 'oxide/Vocab.txt', 'rb', 'DATA' )

    if not File then 
        Main:ConsoleInsert( 'SYSTEM', 'Failed to open a passage to God. Did you forget to download the Bible Verses?', Color( 255, 87, 51 ) )
        return
    end

    local Text  = string.Split( File:Read( File:Size( ) ), '\n' )
    local Final = '' 

    for i = 1, Length do 
        Final = Final .. Text[ math.random( 1, #Text ) ] .. ' '
    end

    Main:ConsoleInsert( 'SYSTEM', 'God Says: `' .. Final .. '`', Color( 255, 87, 51 ) )
end, 'Generates a god passage.' )

Command:AddCommand( 'open_lua', function( Text )
    Text = string.Split( Text, ' ' )

    local File = file.Open( 'lua/' .. Text[ 1 ], 'rb', 'GAME' )

    if not File then 
        return Main:ConsoleInsert( 'SYSTEM', 'Invalid file.', Color( 255, 87, 51 ) )
    end

    if Text[ 2 ] == '-m' then 
        proxi.RunOnMenu( File:Read( File:Size( ) ) )
    else
        proxi.RunOnClient( File:Read( File:Size( ) ) )
    end

    File:Close( )
end, 'Executes a Lua file relative to the Lua folder. Use -m as the second argument for a menustate execution.' )

Command:AddCommand( 'run_lua', function( Text )
    proxi.RunOnClient( Text )
end, 'Runs direct Lua code.' )

Command:AddCommand( 'run_lua_menu', function( Text )
    proxi.RunOnMenu( Text )
end, 'Runs direct Lua code on menustate.' )

Command:AddCommand( 'run', function( Text )
    Main.Local:ConCommand( Text )
end, 'Runs a console command.' )

Command:AddCommand( 'reload', function( Text )
    Main:LoadFile( 'lua/' .. Text )
end, 'Reloads a specific cheat module.' )