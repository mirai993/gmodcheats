- Override prop spawn effect w/ effect.Register ("propspawn")
- 180 keybind
    controlable pitch angle
- speedhack
    SetSequenceNumber( GetSequenceNumber + 1 )
    sv_cheats 1 and host_timescale whatever
- armor esp
- Set the stars and skybox with the "$TOPCOLOR" flags
    tools/cac bypass/lua/matproxy/sky_paint.lua
- DebugInfo print info as optional change instead of left hand skeet like logs
- hitboxes
    if we want dynamic hitboxes (closet to xhair, dynamic body aim, etc) on hitscan then we could just cache the VALID and VISIBLE hitboxes into
    a table and loop through them a second time and sort them dynamically, this shit aint gonna be optimized though.
- smart anti-idle
- reveal team chat
- print server information
- print server grab information 
    console commands
    known anti-cheat information
    addons
- known cheaters list
- aim target information panel
    similar to chudvision or aimware spectator menu
    would have info about weapon, ammo, health, rank, etc
- spectator panel
    similar to aimware spectator menu
    play vo/canals/boxcar_becareful_b.wav
    play bot/clear3.wav
- triggerbot
- hitsound
    npc/barnacle/neck_snap2.wav
    player/geiger1.wav
    physics/cardboard/cardboard_box_impact_bullet4.wav
    physics/cardboard/cardboard_box_impact_bullet1.wav
- disconnect w/ message
    ded.NetDisconnect
- host_framerate 
    slowmo
    server lagger at lower values (speedhack w/ packets)
        host_ShowIPCCallCount -1
- entity list
- typing spoofer
- hide lua errors
- break lc prediction
- knife bot
- prop spammer
- optimizations button
    render.SetShadowDistance
- properties exploits
    - see lolxd.lua
    - also add normal remove
    - FPP.Settings.FPP_TOOLGUN1.worldprops == 1
    - eprotect
- exclude world model from prop esp
- chams
    viewmodel
    hand
    fake angle
    local player
    
    see todo markdown in menu.lua
- dupe stealer
- bunch of pack support
    fas
    swcs (csgo weapons)
    cw
    tfa
    arcw
    tf2
    cof
- Gamemode Support
    nzombies
    darkrp
    ttt
    etc
- Molotov Range
- Grenade Prediction
    This isn't a high prority feature
- Bomb Range (csgo)
- Crossbow Prediction
- TFA Equipment Prediction
    Grenade Launcher
- TF2 Weapon Support
- Landing Position 
    colors and other misc
- NZombies Money Support
- Prop Beams
- Presistant Player List
    Leave notes, mark them as cheater, prority, etc
    Captures information from steam API?

    Marked Cheater ESP color options (like highlighted targets execpt with name and weapon)
    
    Use Steam API to fetch family shared SteamID 
    Avatars and other information

    Name
    SteamID (64/Full)
    Suspected Cheater
    Family Shared (SteamID 64/Full)
    Note
    Save Record
- Killsay
- Majestic File Viewer 
    show hooks
- Disable Rendering of 3D2D textscreens
- Disable aimbot when spectated
- Move menu accent colors to misc tab so they always update when the menu is open
    turn on rainbow and switch to world tab
- Write an alt account checker into the cheat
- Removals
    emmiters
    ropes
    lights
- Kill Effects
- Rope Material Menu
- Randomize Pitch Keybind
    For use with standalone autoclicker to make rope spammer
- Damage Logs
- Ammo Bar
- Emmiter using partical/snow (thanks ovah)
- Uncapped scroll speed
    CUSERCMD
- Sitting Addon Fuckery
- ULX Fuckery
    Ragdoll
    Slap 
    Admin Chat
- Party / Buildmode
- Net Removals:
    net.Receive("WireHoloEmitterData", function() end) -- wire holo emitter gayness prevention tactic
    net.Receive("ulib_sound", function() end) -- Fuck you
    net.Receive("wire_netmsg_registered", function() end) -- text screen slideshow fps rape

    ALSO FUCKING PAC3
    ALSO FUCKING OUTFITTER
- Cleanup Healthkits on Spawn
- Cleanup Armor on Spawn
- Remove 3D & 2D Skybox
- Spam whole server ULX psay
- Name Spoofer
    Stealer
    Newlines (*\n)
    Static

- DrawTexturedRectRotated for trails
- Draw Graphs?

- Shitty URL spammers:
    gmod_modding
    gmod_privacy 

- Dynamite Bot
- CSS and CSGO flashbang removal
- Sine Wave healthbar?

- Grenade Trails like Crossbow
- Leanbot

- Add to the auto weedfarm stuff
    Auto soil
    Auto fertilizer

- ULX and SAM autoheal/autoarmor while on ground too
- Notifications
    Damage
    Spawns
    Joins
- Bouncy Ball Infinite HP

- Blasts M9K Sweps Support
    Misses when not ADS

- package.loaded._G.debug.getregistry()._VMEVENTS

- Add RCC to console

- Hitchams
    Hitboxes
    Skeletons

- Backtrack chams
    Hitboxes
    Skeletons

- Remove loud ass wire emitters

- Local Ammo Bar

- Climb SWEP Utilities

- Box Fill Materials