/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- Lord, forgive me for what I am about to code...

//-/~ Config
Config = { }

//-/~ Setup
file.CreateDir( 'oxide/configs' )

//-/~ Set
function Config:Set( Element, Index, Value )
    local Name, New = Value[ 2 ], Value[ 1 ]
    
    if Name == 'checkbox' then
        Element[ Index .. ' Pointer' ]:SetValue( tobool( New ) )
    elseif Name == 'colormixer' then 
        Element[ Index ] = Color( New.r, New.g, New.b, New.a )
    elseif Name == 'dropdown' then
        Element[ Index .. ' Pointer' ]:SetValue( tostring( New ) )
    elseif Name == 'slider' then
        Element[ Index .. ' Pointer' ]:SetValue( tonumber( New ) )
    elseif Name == 'binder' then 
        Element[ Index .. ' Pointer' ]:SetValue( tonumber( New ) )
    elseif Name == 'textbox' then
        Element[ Index .. ' Pointer' ]:SetValue( tostring( New ) )
    elseif Name == 'checkbox-r' then 
        Element[ Index ] = New
    end
end

//-/~ Process
function Config:Process(UI, Page, Title, SubTableName, Data)
    for key, value in pairs( Data ) do
        if istable( value ) and not value[ 2 ] then
            self:Process( UI, Page, key, key, value )
        else
            self:Set( SubTableName and Main.Elements[ UI ][ Page ][ SubTableName ] or Main.Elements[ UI ][ Page ], key, value )
        end
    end
end

//-/~ Parse Config
function Config:Parse( Data )
    for UI, Pages in pairs(Data) do
        for Page, Titles in pairs(Pages) do
            self:Process(UI, Page, Page, nil, Titles)
        end
    end
end

//-/~ Generate Config
function Config:Generate( )
    local Data = { }

    local Set = function( ui, page, title, name, type )   
        Data[ ui ] = Data[ ui ] or { }
        
        if page then 
            Data[ ui ][ page ] = Data[ ui ][ page ] or { }
            Data[ ui ][ page ][ title ] = Data[ ui ][ page ][ title ] or { }
            
            Data[ ui ][ page ][ title ][ name ] = { Main.Elements[ ui ][ page ][ title ][ name ], type }
        else 
            Data[ ui ][ title ] = Data[ ui ][ title ] or { } 

            Data[ ui ][ title ][ name ] = { Main.Elements[ ui ][ title ][ name ], type }
        end
    end

    for k, v in ipairs( Options ) do
        local Name = v[ 1 ]:lower( )

        if Name == 'checkbox' then
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ], Name )
        elseif Name == 'colormixer' then
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ] .. ' Color', Name )

            if not v[ 7 ] then 
                Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ], 'checkbox' )
            end

            if not v[ 8 ] then 
                Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ] .. ' Rainbow', 'checkbox-r' )
            end
        elseif Name == 'dropdown' then
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ], Name )
        elseif Name == 'slider' then
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 9 ], Name )
        elseif Name == 'binder' then 
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ] .. ' Bind', Name )

            if not v[ 6 ] then
                Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ] .. ' Bind Style', 'dropdown' )
            end

            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ], 'checkbox' )
        elseif Name == 'textbox' then
            Set( v[ 2 ], v[ 3 ], v[ 4 ], v[ 5 ], Name )
        end
    end

    return Data
end

//-/~ Save Config
concommand.Add( 'oxide_save', function( ENT, Command, Table, String )
    local File = file.Open( 'oxide/configs/' .. String .. '.json', 'wb', 'DATA' )

    File:Write( util.TableToJSON( Config:Generate( ), true ) )

    File:Close( )
end )

//-/~ Load Config
concommand.Add( 'oxide_load', function( ENT, Command, Table, String )
    local File = file.Open( 'oxide/configs/' .. String .. '.json', 'rb', 'DATA' )

    Config:Parse( util.JSONToTable( File:Read( File:Size( ) ) ) )

    File:Close( )
end )