/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Aimbot
Aimbot = { 
    [ 'Sandbox SWEPs' ] = {
        [ 'gmod_camera' ] = true,
        [ 'weapon_medkit' ] = true,
        [ 'gmod_tool' ] = true,
        [ 'weapon_physcannon' ] = true,
        [ 'weapon_physgun' ] = true
    }
}

//-/~ Exclude Target
function Aimbot:ExcludeTarget( Ent )
    if not Ent or Ent:IsDormant( ) or Ent == Main.Local then return true end 

    if Ent:IsPlayer( ) then 
        if not Ent:Alive( ) or  Ent:Health( ) <= 0 then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Players' ] then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Steam Friends' ] and Ent:GetFriendStatus( ) == 'friend' then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Invisible' ] and Ent:GetColor( ).a <= 200  then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Staff' ] and Ent:IsAdmin( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Noclip' ] and Ent:GetMoveType( ) == MOVETYPE_NOCLIP then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Vehicles' ] and Ent:InVehicle( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Bot' ] and Ent:IsBot( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Teammates' ] then
            if Ent:Team( ) == Main.Local:Team( ) then return true end 

            -- TTT, this only gets networked if we're teammates.
            if Ent.IsTraitor and Ent:IsTraitor( ) then return true end 
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Roles' ] then
            -- Military RP and other similar gamemodes.
            if Ent:GetNWString( 'Role', 'unknown' ) == Main.Local:GetNWString( 'Role', 'localrole' ) then return true end
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Buildmode' ] then
            if Ent.buildmode then return true end

            if Ent:GetNWBool( 'BuildMode' ) then return true end
        end

        if not Playerlist:IsBlacklisted( Ent ) then
            return true
        end
    else 
        if Ent:Health( ) <= 0 then return true end

        if not Ent:IsNPC( ) and not Ent:IsNextBot( ) then return true end 
            
        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid NPC' ] then return true end 

        if NPCs:CallCallback( Ent ) then return true end 
    end

    return false
end

//-/~ Force View Affinity
function Aimbot:ForceViewAffinity( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Force View Affinity' ] or self.aimTarget != NULL then return end  
 
    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP or not SWEP:IsValid( ) then return end 

    if Weapon:GetBase( SWEP ) != 'CW 2.0' then return end 

    local Reverse = CUserCMD:GetViewAngles( )

    proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )
    proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, Angle( Reverse.x, Reverse.y - 180, Reverse.z ):Forward( ) )
end

//-/~ Select Target
function Aimbot:SelectTarget( Record, Best, Hitbox, CUserCMD )
    -- Limit Distance
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit Distance' ] then 
        local dist = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Distance Units' ]

        if Record.Pos:Distance( Main.Local:GetPos( ) ) > ( dist * 5 ) then 
            return
        end
    end

    -- Calculate View FOV
    local localAngle, posAng = Main.Local:GetAngles( ), ( Hitbox - Main.Local:GetPos( ) ):Angle( )
    local FOV = math.Clamp( Vector( math.NormalizeAngle( posAng.x - localAngle.x ), math.NormalizeAngle( posAng.y - localAngle.y ), 0 ):Length2D( ), 0, 180 )
    
    Record.FOV = FOV
    Record.Distance = ( Record.Pos ):Distance( Main.Local:GetPos( ) )

    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit FOV' ] then 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'FOV' ] < ( FOV ) then 
            return 
        end
    end

    -- Safety check.
    if not Best then return Record end 

    local Sort = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Priority' ] 

    -- Sort our stuff.
    if Sort == 'Crosshair' and Record.FOV then 
       if Record.FOV < Best.FOV then 
            return Record
        end 
    elseif Sort == 'Distance' and Record.Distance then 
        if  Record.Distance < Best.Distance then 
            return Record
        end
    else -- Do the else here just in case the above ones failed.
        if Record.Health < Best.Health then 
            return Record
        end
    end
end

//-/~ Adjust Angle
function Aimbot:AdjustAngle( CUserCMD, AimAngle, Best, SWEP )
    AimAngle = AimAngle:Angle( )

    -- Compensate our recoil/spread.
    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Compensate Accuracy' ] then 
        AimAngle = Prediction:Calculate( CUserCMD, AimAngle, SWEP )
    end

    -- Set autostop.
    Main.Autostop = true

    -- Calculate our final angle.
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Silent' ] then 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Silent Mode' ] == 'Serverside' then 
            if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Force Facestab' ] then 
                CUserCMD:SetViewAngles( Best.Ent:EyeAngles( ) )
            end 

            proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

            proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, AimAngle:Forward( ) )
        else 
            CUserCMD:SetViewAngles( AimAngle )
        end
    else 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Smoothing' ] then 
            AimAngle = LerpAngle( ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Smoothing Amount' ] / ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Ratio' ] * 100 ) ), CUserCMD:GetViewAngles( ), AimAngle )
        end 

        proxi.SetViewAngles( AimAngle )
    end
end

//-/~ Loop Hitbox
function Aimbot:LoopHitbox( Data, Record )
    if not Data then return end 

    for i = 1, #Data do 
        local Matrix = Data[ i ]

        if not Matrix then continue end 

        local Trace = util.TraceLine( { start = Main.Local:EyePos( ), endpos = Matrix, filter = { Main.Local, Record.Ent }, mask = MASK_SHOT } )

        if Trace.Fraction == 1 then 
            return Matrix
        end
    end
end

//-/~ Find Hitbox
function Aimbot:FindHitbox( Record )
    if not Record.Bones then return end 

    local Mode = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Hitbox Selection' ]

    if Mode == 'Head' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_HEAD	 ], Record )
    elseif Mode == 'Pelvis' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_STOMACH ], Record )
    elseif Mode == 'Body' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_CHEST ], Record )
    elseif Mode == 'Feet' then
        return self:LoopHitbox( Record.Bones[ HITGROUP_LEFTLEG ], Record ) or self:LoopHitbox( Record.Bones[ HITGROUP_RIGHTLEG ], Record )
    end 

    for k, Bone in pairs( Record.Bones ) do 
        local Data = self:LoopHitbox( Bone, Record )
        
        if Data then 
            return Data
        end 
    end
end

//-/~ Main Function
function Aimbot:Aimbot( CUserCMD )
    -- Enabled or dead.
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled' ] or not Main.Local:Alive( ) then 
        self.aimTarget = NULL -- Just in case.
        return 
    end 

    -- Can shoot weapon.
    local SWEP = Main.Local:GetActiveWeapon()
    
    if not SWEP:IsValid() then return end

    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Ignore Sandbox SWEPs' ] and self[ 'Sandbox SWEPs' ][ SWEP:GetClass( ) ] then return end

    -- Delay.
    if not Weapon:CanAttack( Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Delay' ] and Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Delay Amount' ] or 0, SWEP ) then 
        CUserCMD:RemoveKey( IN_ATTACK )         
        return
    end 

    -- Reset our aim target.
    self.aimTarget = NULL

    -- Menu opened.
    if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid When Menu Opened' ] and Main.Elements[ 'Menu Reference' ]:IsVisible( ) then 
        return 
    end

    local EnginePrediction = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

    if EnginePrediction then 
        proxi.StartPrediction( CUserCMD )
    end 

    -- Keybind
    if not Main:InputDown( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled Bind' ], Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled Bind Style' ] == 'Toggle' ) then return end 

    -- Avoid sticky.    
    if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Sticky' ] then 
        local Stuck = Main.Local:GetEyeTrace( ).Entity

        if Stuck and Stuck:IsPlayer( ) then 
            return 
        end
    end 

    -- Find our target.
    local Best;

    local Limit   = { 
        Enabled = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit Targets' ], 
        Targets = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Max Targets' ],
        Counter = 0
    }

    local Targets = Main.Entities

    for i = 1, #Targets do 
        local Ent = Targets[ i ]

        if self:ExcludeTarget( Ent ) then continue end 

        local Record = Records:Construct( Ent )

        if Record then 
            local Hitbox = self:FindHitbox( Record )

            -- if istable( Hitbox ) then --Debugging
                -- PrintTable( Hitbox )
                -- PrintTable( Record.Bones )

                -- for i = 1, 30 do 
                --     chat.AddText('check console')
                -- end
            -- end

            if Hitbox and self:SelectTarget( Record, Best, Hitbox, CUserCMD ) then 
                Best = Record

                Best.Aim = Hitbox

                if Limit.Enabled then 
                    Limit.Counter = Limit.Counter + 1

                    if Limit.Counter >= Limit.Targets then 
                        break
                    end
                end
            end
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Prediction' ] != 'Backtrack' or not Ent:IsPlayer( ) then continue end 

        local Record = Records:FindLastRecord( Ent )

        if Record then 
            if not Records:ValidateRecord( Record ) then continue end

            local Hitbox = self:FindHitbox( Record )
    
            if Hitbox and self:SelectTarget( Record, Best, Hitbox, CUserCMD ) then 
                Best = Record

                Best.Aim = Hitbox

                if Limit.Enabled then 
                    Limit.Counter = Limit.Counter + 1

                    if Limit.Counter >= Limit.Targets then 
                        break
                    end
                end
            end
        end
    end

    if not Best or not Best.Aim then return end

    -- Crossbow Prediction
    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Predict Bow' ] and SWEP:GetClass( ) == 'weapon_crossbow' then 
        Best.Aim = Prediction.HL2:Crossbow( CUserCMD, Best.Aim, Best.Ent, TICK_TO_TIME( 100 ) )
    end  

    -- Adjust for tick and calculate angle.
    local AimAngle = ( Best.Aim - Main.Local:EyePos( ) )

    if Best.Tick then 
        local Pred = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Prediction' ]

        if Pred == 'Leading' then 
            local predAmount = TIME_TO_TICK( proxi.GetFlowIncoming( ) + proxi.GetFlowOutgoing( ) )

            AimAngle = AimAngle + ( Best.Ent:GetVelocity( ) * ( Interval( ) * predAmount ) )

            proxi._R.CUserCmd.SetTickCount( CUserCMD, ( TIME_TO_TICK( Best.Tick ) + predAmount ) - 1 )
        elseif Pred == 'Lock' then
            proxi._R.CUserCmd.SetTickCount( CUserCMD, TIME_TO_TICK( Best.Tick + LerpAmount( ) ) )
        else 
            proxi._R.CUserCmd.SetTickCount( CUserCMD, TIME_TO_TICK( Best.Tick ) + TIME_TO_TICK( proxi.GetFlowIncoming( ) + proxi.GetFlowOutgoing( ) ) )
        end
    end 

    -- Set our angle.
    self:AdjustAngle( CUserCMD, AimAngle, Best, SWEP )

    -- Autoshoot.
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Auto Shoot' ] then 
        CUserCMD:AddKey( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Auto Shoot Mode' ] == 'Left' and IN_ATTACK or IN_ATTACK2 )
    end

    self.aimTarget = Best

    if EnginePrediction then 
        proxi.EndPrediction( )
    end 
end