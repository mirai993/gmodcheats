/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Records
Records = { 
    Records = { },
    Models  = { },

    sv_maxunlag = GetConVar( 'sv_maxunlag' )
}

//-/~ Validate Record
function Records:ValidateRecord( Record )
    if not Record.Tick then return true end 

    local Delta = Servertime( ) + proxi.GetFlowOutgoing( ) + proxi.GetFlowIncoming( ) - Record.Tick

    if Delta < self.sv_maxunlag:GetFloat( ) then 
        return true
    end

    return false
end

//-/~ Find Last Record
function Records:FindLastRecord( Ent )
    return self.Records[ Ent ][ #self.Records[ Ent ] ] 
end

//-/~ Construct Record
function Records:Construct( Ent )
    local Tick;

    if Ent:IsPlayer( ) then 
        Tick = proxi._R.Entity.GetDTNetVar( Ent, 'DT_BaseEntity->m_flSimulationTime', 1 )
    end

    local Animations = { }
    if Ent:IsPlayer( ) then 
        -- This is for backtrack chams and things like that.
        Animations.Sequence = Ent:GetSequence( )
        Animations.Cycle    = Ent:GetCycle( )
        Animations.Angles   = Ent:EyeAngles( )
        
        Animations.Layers = { }

        for i = 0, 13 do 
            if Ent:IsValidLayer( i ) then 
                Animations.Layers[ i ] = {
                    Weight   = Ent:GetLayerWeight( i ),
                    Cycle    = Ent:GetLayerCycle( i ),
                    Duration = Ent:GetLayerDuration( i ),
                    Playback = Ent:GetLayerPlaybackRate( i )
                }
            end
        end 

        Animations.Poses = { 
            MoveX = Ent:GetPoseParameter( 'move_x' ),
            MoveY = Ent:GetPoseParameter( 'move_y' )
        }

        Animations.Color = Ent:GetColor( )
    end

    return {
        Ent    = Ent,
        Health = Ent:Health( ),
        Pos    = Ent:GetPos( ),
        Origin = Ent:GetNetworkOrigin( ),
        Health = Ent:Health( ),
        Bones  = Hitboxes:GetMatrixInformation( Ent ),
        Model  = Ent:GetModel( ),
        Tick   = Tick,
        Aim    = NULL, -- This will get filled in by our Aimbot selection to be the hitbox. 

        -- Sorting Stuff
        FOV      = 0,
        Distance = 0,

        -- Animation Stuff
        Animations = Animations
    }
end

//-/~ Emplace Records
function Records:EmplaceRecords( stage )
    if stage != proxi.FRAME_NET_UPDATE_POSTDATAUPDATE_END then return end -- FRAME_NET_UPDATE_POSTDATAUPDATE_END

    local STime = Servertime( )
    local Targets, Delta = player.GetAll( ), STime - ( Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Record Time' ] / 1000 )

    for i = 1, #Targets do 
        local Ent = Targets[ i ]
        
        if not IsValid( Ent ) or Ent:IsDormant( ) then 
            self.Records[ Ent ] = { }
            continue 
        end 

        self.Records[ Ent ] = self.Records[ Ent ] or { }

        -- Clean old records.
        for i = 1, #self.Records[ Ent ] do 
            local Index = self.Records[ Ent ][ i ]

            if not Index or Index.Tick < Delta or Index.Tick > STime then 
                table.remove( self.Records[ Ent ], i )
            end
        end

        -- Insert new record.
        table.insert( self.Records[ Ent ], 1, self:Construct( Ent ) )
    end
end

//-/~ Chams
function Records:Chams( )
    local Enabled = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Backtrack' ]

    -- Collect garbage on models.
    for k,v in pairs( self.Models ) do 
        if not Enabled or k == NULL then 
            v:Remove( )
        end
    end

    if not Enabled then return end

    local Config = {
        Main = {
            Enabled = true,
            Material = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Backtrack Material' ], 
            Color = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Backtrack' )
        },

        Overlay = {
            Enabled = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Backtrack Overlay' ],
            Material = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Backtrack Overlay Material' ], 
            Color = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Backtrack Overlay' )
        }
    }

    local Targets = player.GetAll( )

    -- Loop stuff.
    for i = 1, #Targets do 
        local Index = Targets[ i ]

        if not Wallhack:Exclude( Index ) or Index == Main.Local then continue end 

        local Record = Records:FindLastRecord( Index )

        -- Setup model stuff.
        local Model = self.Models[ Index ]
    
        if not Model or not IsValid( Model ) then 
            self.Models[ Index ] = ClientsideModel( Record.Model )
            continue
        end

        -- Record handler.
        if not Record or not self:ValidateRecord( Record ) then
            if Model then 
                Model:Remove( )
            end

            continue
        end

        -- Setup animation stuff.
        Model:SetPos( Record.Origin )
        Model:SetModel( Record.Model )

        Model:SetSequence( Record.Animations.Sequence )
        Model:SetCycle( Record.Animations.Cycle )
        Model:SetAngles( Angle( 0, Record.Animations.Angles.y, 0 ) )

        for i = 0, 13 do 
            if Record.Animations.Layers[ i ] then
                local Index = Record.Animations.Layers[ i ]

                Model:SetLayerWeight( i, Index.Weight )
                Model:SetLayerCycle( i, Index.Cycle )
                Model:SetLayerDuration( i, Index.Duration )
                Model:SetLayerPlaybackRate( i, Index.Playback )
            end
        end

        Model:SetPoseParameter( 'move_x', Record.Animations.Poses.MoveX )
        Model:SetPoseParameter( 'move_y', Record.Animations.Poses.MoveY )

        Model:SetPoseParameter( 'aim_pitch', Record.Animations.Angles.x )
        Model:SetPoseParameter( 'head_pitch', 0 )
        Model:SetPoseParameter( 'body_yaw', Record.Animations.Angles.y )
        Model:SetPoseParameter( 'aim_yaw', 0 )
    
        Model:SetColor( Record.Animations.Color )
        Model:SetRenderMode( RENDERMODE_TRANSCOLOR )

        Model:SetNoDraw( true )

        -- Rendering stuff.
        cam.Start3D( )

        cam.IgnoreZ( true )

        render.SetBlend( Config.Main.Color.a / 255 )

        if Config.Main.Material == 'None' then 
            Model:DrawModel( )
        else
            render.MaterialOverride( Materials:CallCached( Config.Main.Material ) ) -- Use our cached material.
            render.SetColorModulation( Config.Main.Color.r / 255, Config.Main.Color.g / 255, Config.Main.Color.b / 255 ) 

            Model:DrawModel( )
        end

        if Config.Overlay.Enabled then 
            render.MaterialOverride( Materials:CallCached( Config.Overlay.Material ) ) -- Use our cached material.
            render.SetColorModulation( Config.Overlay.Color.r / 255, Config.Overlay.Color.g / 255, Config.Overlay.Color.b / 255 ) 
            render.SetBlend( Config.Overlay.Color.a / 255 )

            Model:DrawModel( )
        end

        cam.IgnoreZ( false )

        cam.End3D( )
    end
end