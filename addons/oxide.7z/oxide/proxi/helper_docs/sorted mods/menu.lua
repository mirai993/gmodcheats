
/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

Main.Element = { }

//-/~ Colors
Main.UIColors = { 
    White       = color_white,
    Black       = color_black,

    White02     = Color( 200, 200, 200 ),
    White03     = Color( 194, 190, 190 ),
    White04     = Color( 255, 255, 255, 155 ),

    Black02     = Color( 0, 0, 0, 66 ),
    Black03     = Color( 26, 26, 26 ),
    Black04     = Color( 42, 42, 42 ),
    Black05     = Color( 32, 32, 32 ),
    Black06     = Color( 30, 30, 30 ),
    Black07     = Color( 36, 36, 36 ),
    Black08     = Color( 55, 55, 55 ),

    Grey        = Color( 194, 190, 190, 44 ),

    Purple01    = Color( 210, 121, 69, 100 ),
    Purple02    = Color( 210, 121, 69, 166 ),
    Purple03    = Color( 210, 121, 69 ),
    Purple04    = Color( 253, 182, 11, 99 ),
}

//-/~ Main Table
Options = {
    { 'menu', 'Aimbot' },
    { "menu", "Visuals", { "Players", "World", "Items" } },
    { "menu", "Miscellaneous" },
    { "menu", "Other", { 'Console', 'Player List' }, 600, 350 },
    
    // General Aimbot
    { 'section', 'Aimbot', nil, 'General' },
    { 'binder', "Aimbot", nil, "General", "Enabled" },
    -- { "dropdown", "Aimbot", nil, 'General', 'Bind Style', false, 'Hold', { 'Hold', 'Toggle' }, 0, 0, 65, 0 },
    
    { 'checkbox', 'Aimbot', nil, "General", "Auto Shoot" },
    { "dropdown", "Aimbot", nil, "General", 'Auto Shoot Mode', false, 'Left', { 'Left', 'Right' } },

    { 'checkbox', 'Aimbot', nil, "General", "Silent" },
    { "dropdown", "Aimbot", nil, "General", 'Silent Mode', false, 'Clientside', { 'Clientside', 'Serverside' } },

    { 'checkbox', 'Aimbot', nil, "General", "Limit FOV" },
    { "slider", "Aimbot", nil, "General", "°", 1, 180, false, 'FOV' },

    { 'colormixer', 'Aimbot', nil, "General", "Highlight Targets" },

    { 'checkbox', 'Aimbot', nil, "General", "Smoothing" },
    { "slider", "Aimbot", nil, "General", "%", 1, 100, false, 'Smoothing Amount' },
    { "slider", "Aimbot", nil, "General", "%", 1, 100, false, 'Ratio' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Limit Distance' },
    { "slider", "Aimbot", nil, "General", "un", 1, 15000, false, 'Distance Units' },
    
    { 'checkbox', 'Aimbot', nil, 'General', 'Limit Targets' },
    { "slider", "Aimbot", nil, "General", '', 1, 10, false, 'Max Targets' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Force Facestab' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Autoheal' },
    { "dropdown", "Aimbot", nil, "General", 'Autoheal Method', true, 'SENT', { 'SENT', 'ULX', 'SAM' } },
    { "dropdown", "Aimbot", nil, "General", 'Autoheal Mode', false, 'Regular', { 'Regular', 'Small' } },
    { "slider", "Aimbot", nil, "General", 'hp', 1, 100, false, 'Autoheal Minimum' },
    { "slider", "Aimbot", nil, "General", 'ms', 1, 500, false, 'Autoheal Delay' },
    { 'checkbox', 'Aimbot', nil, 'General', 'Ignore Maximum Health Sents' },
    { "dropdown", "Aimbot", nil, "General", 'Autoheal Snap', true, 'Perfect', { 'Perfect', 'Regular' } },

    { 'checkbox', 'Aimbot', nil, 'General', 'Autoarmor' },
    { "dropdown", "Aimbot", nil, "General", 'Autoarmor Method', true, 'SENT', { 'SENT', 'ULX', 'SAM' } },
    { "slider", "Aimbot", nil, "General", 'ar', 1, 100, false, 'Autoarmor Minimum' },
    { "slider", "Aimbot", nil, "General", 'ms', 1, 500, false, 'Autoarmor Delay' },
    { 'checkbox', 'Aimbot', nil, 'General', 'Ignore Maximum Armor Sents' },
    { "dropdown", "Aimbot", nil, "General", 'Autoarmor Snap', true, 'Perfect', { 'Perfect', 'Regular' } },

    { 'checkbox', 'Aimbot', nil, 'General', 'Standalone Autoclicker' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Force View Affinity' },

    // Accuracy Aimbot
    { 'section', 'Aimbot', nil, 'Accuracy' },
    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Compensate Accuracy' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Autostop' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Resolver' },
    { "dropdown", "Aimbot", nil, "Accuracy", 'Resolver Mode', false, 'Off', { 'Off', 'Default', 'Basic' } },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Delay' },
    { "slider", "Aimbot", nil, "Accuracy", 'ms', 1, 1000, false, 'Delay Amount' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Predict Bow' },
    { 'colormixer', 'Aimbot', nil, 'Accuracy', 'Visualize Prediction' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Engine Prediction (!)' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Ignore Sandbox SWEPs' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Auto Revolver' },

    { 'checkbox', "Aimbot", nil, "Accuracy", "Doubletap" },
    
    { 'binder', "Aimbot", nil, "Accuracy", "Tickwarp", true },
    { "slider", "Aimbot", nil, "Accuracy", '%', 1, 100, true, 'Warp Amount' },
    { "slider", "Aimbot", nil, "Accuracy", '%', 1, 100, true, 'Warp Attack' },


    // Target Selection Aimbot
    { 'section', 'Aimbot', nil, 'Target Selection' },
    { "dropdown", "Aimbot", nil, "Target Selection", 'Priority', true, 'Crosshair', { 'Crosshair', 'Distance', 'Health' } },
    { "dropdown", "Aimbot", nil, "Target Selection", 'Hitbox Selection', true, 'Hitscan', { 'Hitscan', 'Head', 'Body', 'Pelvis', 'Feet' } },

    { 'checkbox', 'Aimbot', nil, 'Target Selection', 'Multipoint' },
    { "slider", "Aimbot", nil, "Target Selection", "%", 1, 100, true, 'Head Scale' },
    { "slider", "Aimbot", nil, "Target Selection", "%", 1, 100, true, 'Body Scale' },
    { 'colormixer', 'Aimbot', nil, 'Target Selection', 'Visualize Multipoints' },

    { "dropdown", "Aimbot", nil, "Target Selection", 'Prediction', true, 'Off', { 'Off', 'Leading', 'Backtrack', 'Lock' } },
    { "slider", "Aimbot", nil, "Target Selection", "ms", 2, 200, false, 'Record Time' },

    { 'checkbox', 'Aimbot', nil, 'Target Selection', "Avoid Sticky" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Teammates" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Roles" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Buildmode" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Steam Friends" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Invisible" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Staff" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Noclip" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Vehicles" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Bots" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid NPC" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Players" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid When Menu Opened" },

    { 'checkbox', 'Aimbot', nil, "Target Selection", "NZombies Support" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid When Down" },

    // Anti-Aim
    { 'section', 'Aimbot', nil, 'Anti-Aim' },
    { "checkbox", "Aimbot", nil, "Anti-Aim", "Enable" },
    { "dropdown", "Aimbot", nil, "Anti-Aim", "Pitch", true, 'Down', { 'Up', 'Down', 'Fake-Up', 'Fake-Down', 'Mixed' } },
    { "dropdown", "Aimbot", nil, "Anti-Aim" ,"Yaw Base", true, 'Away Crosshair', { 'Static', 'Away Crosshair', 'Away Distance' } },
    { "slider", "Aimbot", nil, "Anti-Aim", "°", 1, 360, true, 'Yaw Add' },
    { "dropdown", "Aimbot", nil, "Anti-Aim" ,"Fake Yaw", true, 'Static', { 'Off', 'Static' } },
    { "slider", "Aimbot", nil, "Anti-Aim", "°", 1, 360, false, 'Fake Add' },

    // ESP
    { "section", "Visuals", "Players", "ESP" },
    
    { "checkbox", "Visuals", "Players", "ESP", "Enabled" },
    { "colormixer", "Visuals", "Players", "ESP", "Box" },
    { "dropdown", "Visuals", "Players", "ESP", "Box Style", false, '2D', { '2D', '2D Outlined', '3D' } },
    { "colormixer", "Visuals", "Players", "ESP", "Fill Box" },
    { "colormixer", "Visuals", "Players", "ESP", "Name" },
    { "colormixer", "Visuals", "Players", "ESP", "Weapon" },
    { "dropdown", "Visuals", "Players", "ESP", "Weapon Style", false, 'Basic', { 'Basic', 'Smart' } },
    { "checkbox", "Visuals", "Players", "ESP", "Force Uppercase" },
    { "checkbox", "Visuals", "Players", "ESP", "Health Bar" },
    { "dropdown", "Visuals", "Players", "ESP", "Health Bar Style", false, 'Regular', { 'Regular', 'Gradient Down', 'Gradient Up' } },
    { "colormixer", "Visuals", "Players", "ESP", "Override Health Bar" },
    { "colormixer", "Visuals", "Players", "ESP", "Armor Bar" },
    { "dropdown", "Visuals", "Players", "ESP", "Armor Bar Style", false, 'Regular', { 'Regular', 'Gradient Down', 'Gradient Up' } },
    { "colormixer", "Visuals", "Players", "ESP", "Skeleton" },
    { "colormixer", "Visuals", "Players", "ESP", "Tracers" },
    { "colormixer", "Visuals", "Players", "ESP", "Hitboxes" },
    { "colormixer", "Visuals", "Players", "ESP", "Glow (!)" },
    { "slider", "Visuals", "Players", "ESP", 'x', 1, 5, true, 'Passes' },
    { "checkbox", "Visuals", "Players", "ESP", "Include Weapon" },
    { "checkbox", "Visuals", "Players", "ESP", "Force Bloom" },
    { "checkbox", "Visuals", "Players", "ESP", "Only Visible" },
    { "colormixer", "Visuals", "Players", "ESP", "Head Tracers" },
    { "dropdown", "Visuals", "Players", "ESP", "Head Tracer Material", false, 'Arrow', { 'Arrow', 'Laser', 'Smoke', 'Beam', 'Spark', 'Plasma' } },
    { "slider", "Visuals", "Players", "ESP", 'z', -15, 15, true, 'Head Tracer Offset' },
    { "colormixer", "Visuals", "Players", "ESP", "Overhead Prop" },
    { "colormixer", "Visuals", "Players", "ESP", "Light" },
    { "dropdown", "Visuals", "Players", "ESP", "Light Mode", false, 'DLight', { 'DLight', 'ELight' } },
    { "slider", "Visuals", "Players", "ESP", '%', 1, 100, false, 'DLight Size' },
    { "colormixer", "Visuals", "Players", "ESP", "Ring" },
    { "slider", "Visuals", "Players", "ESP", '%', 1, 100, true, 'Ring Noise' },
    { "slider", "Visuals", "Players", "ESP", 'un', 1, 100, true, 'Ring Start Radius' },
    { "slider", "Visuals", "Players", "ESP", 'un', 1, 100, true, 'Ring End Radius' },
    { "colormixer", "Visuals", "Players", "ESP", "Visualize Footsteps" },
    { "colormixer", "Visuals", "Players", "ESP", "Barrel Laser" },
    { "colormixer", "Visuals", "Players", "ESP", "Barrel Hit Position" },
    { "dropdown", "Visuals", "Players", "ESP", "Barrel Mode", false, 'Wireframe', { 'Wireframe', 'Solid' } },
    { "colormixer", "Visuals", "Players", "ESP", "Trail" },
    { "dropdown", "Visuals", "Players", "ESP", "Trail Material", false, 'Laser', { 'Laser', 'Generic', 'Blur', 'Smoke', 'Hearts' } },
    { "slider", "Visuals", "Players", "ESP", 'ms', 1, 1000, false, 'Trail Time' },
    { "slider", "Visuals", "Players", "ESP", 'un', 1, 15, false, 'Trail Height' },
    { "colormixer", "Visuals", "Players", "ESP", "Ball Halo" },
    { "slider", "Visuals", "Players", "ESP", '%', 1, 100, false, 'Ball Rotation Speed' },
    { "colormixer", "Visuals", "Players", "ESP", "Head Dot" },
    { "dropdown", "Visuals", "Players", "ESP", "Head Dot Mode", false, 'Wireframe', { 'Wireframe', 'Solid' } },

    { "checkbox", "Visuals", "Players", "ESP", "Override LOD" },
    { "slider", "Visuals", "Players", "ESP", '', 1, 8, false, 'LOD' },

    { "colormixer", "Visuals", "Players", "ESP", "Blacklist Flag" },
    { "colormixer", "Visuals", "Players", "ESP", "Reloading Flag" },
    { "colormixer", "Visuals", "Players", "ESP", "Health Flag" },
    { "colormixer", "Visuals", "Players", "ESP", "Armor Flag" },

    // Chams
    { "section", "Visuals", "Players", "Chams" },

    { "colormixer", "Visuals", "Players", "Chams", "Visible" },
    { "dropdown", "Visuals", "Players", "Chams", "Visible Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal', 'Glow', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Visible Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Visible Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Invisible" },
    { "dropdown", "Visuals", "Players", "Chams", "Invisible Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal', 'Glow' } },

    { "colormixer", "Visuals", "Players", "Chams", "Invisible Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Invisible Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net', 'Glow Outlined' } },

    { "checkbox", "Visuals", "Players", "Chams", "Disable Player Model (!)" },

    { "colormixer", "Visuals", "Players", "Chams", "Attachments" },
    { "dropdown", "Visuals", "Players", "Chams", "Attachments Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal', 'Glow', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Attachments Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Attachments Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net', 'Glow Outlined' } },
   
    { "colormixer", "Visuals", "Players", "Chams", "Viewmodel" },
    { "dropdown", "Visuals", "Players", "Chams", "Viewmodel Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal', 'Glow', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Viewmodel Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Viewmodel Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Backtrack" },
    { "dropdown", "Visuals", "Players", "Chams", "Backtrack Material", false, 'None', { 'None', 'Textured', 'Flat', 'Glass', 'Metal', 'Glow', 'Glow Outlined' } },

    { "colormixer", "Visuals", "Players", "Chams", "Backtrack Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Backtrack Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net', 'Glow Outlined' } },

    -- TODO 
    -- Local Chams in here
    -- Fake Chams in here
    
    // Other
    { "section", "Visuals", "Players", "Other", nil, 450 },

    { "checkbox", "Visuals", "Players", "Other", "Spectator List" },
    { "checkbox", "Visuals", "Players", "Other", "Admin List" },
    { "checkbox", "Visuals", "Players", "Other", "Aimbot Information" },
    { "checkbox", "Visuals", "Players", "Other", "Notifications" },

    { "checkbox", "Visuals", "Players", "Other", "Footstep Manipulation" },
    { "checkbox", "Visuals", "Players", "Other", "Supress Local" },
    { "slider", "Visuals", "Players", "Other", '%', 1, 100, true, 'Local Volume' },
    { "slider", "Visuals", "Players", "Other", '%', 1, 100, true, 'Enemy Volume' },
    { "checkbox", "Visuals", "Players", "Other", "Spoof Sound" },
    { "dropdown", "Visuals", "Players", "Other", "Footstep Sound", false, 'Light', { 'Light', 'Screenshot', 'Notification', 'Blip', 'Bell', 'Stomp' } },
    { "checkbox", "Visuals", "Players", "Other", "Spoof DSP" },
    { "dropdown", "Visuals", "Players", "Other", "Footstep DSP", false, 'Reverb', { 'Reverb', 'Depth', 'Echo', 'Tunnel', 'Distorted', 'Water' } },
    { "checkbox", "Visuals", "Players", "Other", "Extend Range" },
    { "colormixer", "Visuals", "Players", "Other", "Vape Timer" },
    { "colormixer", "Visuals", "Players", "Other", "Shot Timer" },
    { "colormixer", "Visuals", "Players", "Other", "Ammo Bar" },
    { "colormixer", "Visuals", "Players", "Other", "Projectile Trail" },
    { "checkbox", "Visuals", "Players", "Other", "Trail Through Walls" },
    { "checkbox", "Visuals", "Players", "Other", "Trail Only Local" },

    { "checkbox", "Visuals", "Players", "Other", "Crosshair" },
    { "slider", "Visuals", "Players", "Other", 'un', 1000, 5000, true, 'Trace Distance' },
    { "colormixer", "Visuals", "Players", "Other", "Dot" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Dot Size' },
    { "colormixer", "Visuals", "Players", "Other", "Recoil" },
    { "dropdown", "Visuals", "Players", "Other", "Recoil Direct", false, 'Down', { 'Down', 'Up' } },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Recoil Multiplication' },
    { "colormixer", "Visuals", "Players", "Other", "Recoil Dot" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Recoil Dot Size' },
    { "slider", "Visuals", "Players", "Other", '', 1, 5, true, 'Recoil Dot Delta' },
    { "colormixer", "Visuals", "Players", "Other", "Left" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Left Size' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 45, true, 'Left Length' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 100, true, 'Left Distance' },
    { "colormixer", "Visuals", "Players", "Other", "Right" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Right Size' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 45, true, 'Right Length' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 100, true, 'Right Distance' },
    { "colormixer", "Visuals", "Players", "Other", "Bottom" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Bottom Size' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 45, true, 'Bottom Length' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 100, true, 'Bottom Distance' },
    { "colormixer", "Visuals", "Players", "Other", "Top" },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 5, true, 'Top Size' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 45, true, 'Top Length' },
    { "slider", "Visuals", "Players", "Other", 'x', 1, 100, true, 'Top Distance' },

    { "colormixer", "Visuals", "Players", "Other", "Bullet Tracers" },
    { "dropdown", "Visuals", "Players", "Other", "Tracer Style", false, 'Traced', { 'Traced', 'Bullet' } },
    { "slider", "Visuals", "Players", "Other", 'ms', 1, 2500, false, 'Tracer Time' },
    { "colormixer", "Visuals", "Players", "Other", "Override Hurt Color" },

    { "checkbox", "Visuals", "Players", "Other", "Hit Sounds" },
    { "dropdown", "Visuals", "Players", "Other", "Hit Sound", false, 'Pop', { 'Pop', 'Snap', 'Crunch', 'Click', 'Blip', 'Stab', 'Custom' } },
    { "textbox", "Visuals", "Players", "Other", "Custom Hit Sound", '' },
    { "checkbox", "Visuals", "Players", "Other", "Kill Sounds" },
    { "dropdown", "Visuals", "Players", "Other", "Kill Sound", false, 'Blip', { 'Pop', 'Snap', 'Crunch', 'Click', 'Blip', 'Stab', 'Custom' } },
    { "textbox", "Visuals", "Players", "Other", "Custom Kill Sound", '' },

    { "checkbox", "Visuals", "Players", "Other", "Hit Effects" },
    { "dropdown", "Visuals", "Players", "Other", "Hit Effect", false, 'Tesla', { 'Tesla', 'Gibs', 'Sparks', 'Heavy Sparks', 'Explosion' } },
    { "checkbox", "Visuals", "Players", "Other", "Kill Effects" },
    { "dropdown", "Visuals", "Players", "Other", "Kill Effect", false, 'Explosion', { 'Tesla', 'Gibs', 'Sparks', 'Heavy Sparks', 'Explosion' } },

    { "checkbox", "Visuals", "Players", "Other", "Notify Damage Dealt" },
    { "checkbox", "Visuals", "Players", "Other", "Notify Damage Taken" },
    { "checkbox", "Visuals", "Players", "Other", "Notify Player Connect" },
    { "checkbox", "Visuals", "Players", "Other", "Notify Player Disconnect" },
    { "checkbox", "Visuals", "Players", "Other", "Notify Spectator" },

    { "checkbox", "Visuals", "Players", "Other", "Use Hint Popup" },
    { "checkbox", "Visuals", "Players", "Other", "Use Console Messages" },

    { "checkbox", "Visuals", "Players", "Other", "Skin Changer" },
    { "slider", "Visuals", "Players", "Other", '', 1, 12, false, 'Skin ID' },
    { "checkbox", "Visuals", "Players", "Other", "Randomize Skin" },

    // Filters
    { "section", "Visuals", "Players", "Filters", nil, 450 },

    { "checkbox", "Visuals", "Players", "Filters", "Avoid Teammates" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Roles" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Builders" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Friendly" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Staff" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Invisible" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid NPC" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid While Flashed" },
    { "checkbox", "Visuals", "Players", "Filters", "Only Visible" },

    // World
    { "section", "Visuals", "World", "World", nil, 960 },

    { 'binder', "Visuals", 'World', 'World', "Thirdperson", true },
    { "slider", "Visuals", "World", "World", '°', 75, 250, true, 'Max Distance' },
    { "slider", "Visuals", "World", "World", '°', -64, 64, true, 'Up Distance' },
    { 'checkbox', "Visuals", 'World', 'World', "Collision" },
    { 'checkbox', "Visuals", 'World', 'World', "Right Offset" },
    { "slider", "Visuals", "World", "World", '°', -64, 64, false, 'Right Offset Distance' },
    { 'binder', "Visuals", 'World', 'World', "Freecam", true },
    { "slider", "Visuals", "World", "World", '°', 5, 15, true, 'Speed' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Sensitivity' },
    { 'checkbox', "Visuals", 'World', 'World', "Unclamp Pitch" },
    { 'binder', "Visuals", 'World', 'World', "Freelook", true },
    { 'checkbox', "Visuals", 'World', 'World', "Viewmodel Adjustments" },
    { 'checkbox', "Visuals", 'World', 'World', "No Sway" },
    { 'checkbox', "Visuals", 'World', 'World', "No Bob" },
    { 'checkbox', "Visuals", 'World', 'World', "Enforce Gamemode View" },
    { 'checkbox', "Visuals", 'World', 'World', "Adjust Offsets" },
    { "slider", "Visuals", "World", "World", '°', -30, 30, true, 'Offset X' },
    { "slider", "Visuals", "World", "World", '°', -30, 30, true, 'Offset Y' },
    { "slider", "Visuals", "World", "World", '°', -30, 30, true, 'Offset Z' },
    { "slider", "Visuals", "World", "World", '°', 0, 360, true, 'Roll' },
    { "slider", "Visuals", "World", "World", '°', 0, 360, true, 'Yaw' },
    { "slider", "Visuals", "World", "World", '°', 60, 140, true, 'FOV' },
    { 'colormixer', "Visuals", 'World', 'World', "World Modulation", nil, false, true },
    { 'checkbox', "Visuals", 'World', 'World', "Skybox Modulation" },
    { 'colormixer', "Visuals", 'World', 'World', "Skybox Top", nil, true },
    { 'colormixer', "Visuals", 'World', 'World', "Skybox Bottom", nil, true },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Fade Bias' },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'HDR Scale' },
    { 'colormixer', "Visuals", 'World', 'World', "Dusk" },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Dusk Scale' },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Dusk Intensity' },
    { 'checkbox', "Visuals", 'World', 'World', "Star Modulation" },
    { 'checkbox', "Visuals", 'World', 'World', "Draw Stars" },
    { "dropdown", "Visuals", "World", "World", "Star Texture", true, 'Cloud', { 'Cloud', 'Stars', 'Warp', 'Bars', 'Liquid' } },
    { "slider", "Visuals", "World", "World", '', 1, 3, true, 'Star Layers' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Speed' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Scale' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Fade' },
    { 'colormixer', "Visuals", 'World', 'World', "Sun Modulation" },
    { "slider", "Visuals", "World", "World", '%', 1, 250, false, 'Sun Scale' },
    { 'colormixer', "Visuals", 'World', 'World', "Fog Modulation" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Fog Distance' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Fog Density' },
    { 'colormixer', "Visuals", 'World', 'World', "Sky Fog Modulation" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Sky Fog Distance' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Sky Fog Density' },

    { 'checkbox', "Visuals", 'World', 'World', "Aspect Ratio" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, false, 'Aspect Ratio Scale' },

    { 'checkbox', "Visuals", 'World', 'World', "Bloom Modification" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Bloom Strength' },
    { "slider", "Visuals", "World", "World", 'x', 1, 3, true, 'Strength Multiplier' },
    { "slider", "Visuals", "World", "World", 'x', 1, 3, true, 'Color Multiplier' },
    { "slider", "Visuals", "World", "World", 'x', 1, 5, true, 'Passes' },

    { 'checkbox', "Visuals", 'World', 'World', "Toy Town Modification" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, false, 'Toy Town Strength' },

    { 'checkbox', "Visuals", 'World', 'World', "Sobel Modification" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, false, 'Sobel Strength' },

    { 'checkbox', "Visuals", 'World', 'World', "DOF Modification" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'DOF Strength' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'DOF Distance' },
    { "slider", "Visuals", "World", "World", '', 1, 12, true, 'DOF Focus' },

    { 'checkbox', "Visuals", 'World', 'World', "Color Modification" },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Brightness' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Contrast' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Saturation' },
    { 'checkbox', "Visuals", 'World', 'World', "Invert Colors" },

    { 'checkbox', "Visuals", 'World', 'World', "Remove Emitters" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Flashbangs" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Admin Popup" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Vape Talking" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Discord Relay" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Visual Recoil" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Drugz Effects" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Direct Messages" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Artificial Lights" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Mushroom Factory Effects" },
    { 'checkbox', "Visuals", 'World', 'World', "Remove Vape Hallucinogenic Effects" },

    { 'button', "Visuals", 'World', 'World', "Remove SWCS Prediction Errors" },

    { 'checkbox', "Visuals", 'World', 'World', "Fade Props" },
    { "slider", "Visuals", "World", "World", 'un', 1, 1000, false, 'Fade Start' },


    // Props
    { "section", "Visuals", "World", "Props", nil, 960 },


    // Miscellaneous
    { "section", "Miscellaneous", nil, "Main" },

    { "checkbox", "Miscellaneous", nil, "Main", "Bunnyhop", false },

    { "binder", "Miscellaneous", nil, "Main", "Flashlight Spam", true },

    { "binder", "Miscellaneous", nil, "Main", "Auto Inventory", true },

    { "binder", "Miscellaneous", nil, "Main", "Auto Seed", true },
    { "checkbox", "Miscellaneous", nil, "Main", "Silent", true },
    { "dropdown", "Miscellaneous", nil, "Main", "Silent Mode", false, 'Clientside', { 'Clientside', 'Serverside' } },
    { "slider", "Miscellaneous", nil, "Main", 'ms', 1, 1000, true, 'Hold Time' },

    { "button", "Miscellaneous", nil, "Main", "Delete All Seeds" },

    { "checkbox", "Miscellaneous", nil, "Main", "Cleanup Death", true },
    { "dropdown", "Miscellaneous", nil, "Main", "Cleanup Death Mode", false, 'All', { 'All', 'Props', 'Entities' } },

    { "checkbox", "Miscellaneous", nil, "Main", "Cleanup Spawn", true },
    { "dropdown", "Miscellaneous", nil, "Main", "Cleanup Spawn Mode", false, 'All', { 'All', 'Props', 'Entities' } },

    { "checkbox", "Miscellaneous", nil, "Main", "ULX Ragdoll Crasher", true },
    { "checkbox", "Miscellaneous", nil, "Main", "ULX Asay Clear", true },

    { "button", "Miscellaneous", nil, "Main", "Force Escape" },
    { "dropdown", "Miscellaneous", nil, "Main", "Force Escape Mode", false, 'Game UI', { 'Game UI', 'Console', 'Premission' } },

    { "binder", "Miscellaneous", nil, "Main", "Name Spoofer", true },
    { "dropdown", "Miscellaneous", nil, "Main", "Name Spoofer Mode", false, 'Steal', { 'Steal', 'Static', 'Clear', 'Bypass', 'Fake Name' } },
    { "textbox", "Miscellaneous", nil, "Main", 'Name Spoofer Text', Main.Local:Name( ) },
    { "checkbox", "Miscellaneous", nil, "Main", "Use RP Name", true },

    { "button", "Miscellaneous", nil, "Main", "Reset Name" },
    { "dropdown", "Miscellaneous", nil, "Main", "Reset Mode", true, 'Steam', { 'Steam', 'Initial' } },

    { "binder", "Miscellaneous", nil, "Main", "Slowmo", true },
    { "slider", "Miscellaneous", nil, "Main", '%', 1, 100, false, 'Slowmo Strength' },

    { "binder", "Miscellaneous", nil, "Main", "Airstuck", true },
    { "slider", "Miscellaneous", nil, "Main", '%', 1, 100, false, 'Airstuck Strength' },

    { "checkbox", "Miscellaneous", nil, "Main", "Vape Fire Aura", true },
    { "slider", "Miscellaneous", nil, "Main", 'un', 1, 1000, false, 'Vape Fire Distance' },

    { "checkbox", "Miscellaneous", nil, "Main", "Auto Lean", true },

    -- { "checkbox", "Miscellaneous", nil, "Main", "Tipjar Aura", true },
    -- { "slider", "Miscellaneous", nil, "Main", 'un', 1, 1000, false, 'Tipjar Distance' },

    { "checkbox", "Miscellaneous", nil, "Main", "Console Breaker", true },

    { "checkbox", "Miscellaneous", nil, "Main", "Auto Meth", true },

    { "checkbox", "Miscellaneous", nil, "Main", "Vape Spam", false },
    { "slider", "Miscellaneous", nil, "Main", 'ms', 3, 48, false, 'Vape Amount' },

    { "checkbox", "Miscellaneous", nil, "Main", "Auto Reload", false },
    { "slider", "Miscellaneous", nil, "Main", '%', 1, 100, false, 'Reload Percentage' },
    { "checkbox", "Miscellaneous", nil, "Main", "Use Secondary Clip", true },
    { "checkbox", "Miscellaneous", nil, "Main", "Avoid While Aimbotting", false },

    { 'button', "Miscellaneous", nil, "Main", "Ping DDOSer" },
    { "slider", "Miscellaneous", nil, "Main", 'x', 1, 2500, false, 'Pings' },
    { "textbox", "Miscellaneous", nil, "Main", 'Ping DDOSer IP', '127.0.0.1:27015' },
    
    // Settings
    { "section", "Miscellaneous", nil, "Settings" },

    { "colormixer", "Miscellaneous", nil, "Settings", "Menu Navigation Bar", Main.UIColors[ 'Purple01' ], true, nil, function( panel, color, name )
        Main.UIColors[ 'Purple01' ] = color
    end },
    { "colormixer", "Miscellaneous", nil, "Settings", "Menu Top Bar", Main.UIColors[ 'Purple02' ], true, nil, function( panel, color, name )
        Main.UIColors[ 'Purple02' ] = color
    end },
    { "colormixer", "Miscellaneous", nil, "Settings", "Menu Accent Color", Main.UIColors[ 'Purple03' ], true, nil, function( panel, color, name )
        Main.UIColors[ 'Purple03' ] = color
    end },
    { "colormixer", "Miscellaneous", nil, "Settings", "Menu Section Color", Main.UIColors[ 'Purple04' ], true, nil, function( panel, color, name )
        Main.UIColors[ 'Purple04' ] = color
    end },

    { "checkbox", "Miscellaneous", nil, "Settings", "Menu Theme Song", true },
    { "slider", "Miscellaneous", nil, "Settings", '%', 1, 100, false, 'Volume' },

    { "checkbox", "Miscellaneous", nil, "Settings", "Menu Flag", true },
    { "dropdown", "Miscellaneous", nil, "Settings", "Menu Flag Icon", false, 'Serbia', { 'Serbia', 'United States', 'Germany', 'Ireland' } },

    // Chat
    { "section", "Miscellaneous", nil, "Chat" },
    
    { "checkbox", "Miscellaneous", nil, "Chat", "Console Spam", true },
    { "dropdown", "Miscellaneous", nil, "Chat", "Console Spam Mode", false, 'RCC', { 'RCC', 'Console Command', 'Send Command' } },
    { "textbox", "Miscellaneous", nil, "Chat", 'Console Spam Text', 'ulx asay \\n\\n' },

    { "checkbox", "Miscellaneous", nil, "Chat", "Direct Message Spammer", true },
    { "dropdown", "Miscellaneous", nil, "Chat", "Direct Message Mode", false, 'ULX', { 'ULX', 'SAM', 'DarkRP' } },
    { "textbox", "Miscellaneous", nil, "Chat", 'Direct Message Text', '' },

    { "checkbox", "Miscellaneous", nil, "Chat", "Auto Clear Chat" },
    { "dropdown", "Miscellaneous", nil, "Chat", "Clear Chat Mode", false, 'Carriage Return', { 'Carriage Return', 'Newline', 'Vertical Tab' } },
    { "checkbox", "Miscellaneous", nil, "Chat", "Use OOC" },

    // Prop Utilities
    { "section", "Miscellaneous", nil, "Prop Utilities" },

    { "binder", "Miscellaneous", nil, "Prop Utilities", "Properties Aura", true },
    { "dropdown", "Miscellaneous", nil, "Prop Utilities", "Properties Mode", false, 'Removal', { 'Removal', 'Disintegrate', 'Ignite' } },
    { "slider", "Miscellaneous", nil, "Prop Utilities", 'un', 1, 1000, false, 'Properties Distance' },
    
    { "binder", "Miscellaneous", nil, "Prop Utilities", "Properties Beam", true },

    { 'checkbox', "Miscellaneous", nil, 'Prop Utilities', "Auto Toolgun" },
    { "dropdown", "Miscellaneous", nil, "Prop Utilities", "Toolgun Mode", false, 'Remover', { 'Remover', 'Weld', 'Hydraulic', 'Motor', 'Muscle', 'Trails' } },
    { "slider", "Miscellaneous", nil, "Prop Utilities", 'un', 1, 1000, false, 'Toolgun Distance' },
    { "checkbox", "Miscellaneous", nil, "Prop Utilities", "Auto Equip", false },
    { "checkbox", "Miscellaneous", nil, "Prop Utilities", "Toolgun Silent", false },
    { "dropdown", "Miscellaneous", nil, "Prop Utilities", "Toolgun Silent Mode", false, 'Clientside', { 'Clientside', 'Serverside' } },
    { "checkbox", "Miscellaneous", nil, "Prop Utilities", "Wait For Invalidation", false },
    { "slider", "Miscellaneous", nil, "Prop Utilities", 's', 1, 5, false, 'Invalidation Time' },

    { 'button', "Miscellaneous", nil, 'Prop Utilities', "Spawn Bypass" },
    { "textbox", "Miscellaneous", nil, "Prop Utilities", 'Spawn Bypass Prop', 'models/props_phx/torpedo.mdl' },

    { 'button', "Miscellaneous", nil, 'Prop Utilities', "Spawn Props" },
    { "textbox", "Miscellaneous", nil, "Prop Utilities", 'Spawn Props Prop', 'models/props_c17/gate_door02a.mdl' },
    { "slider", "Miscellaneous", nil, "Prop Utilities", '', 1, 250, true, 'Quantity' },
    { 'checkbox', "Miscellaneous", nil, 'Prop Utilities', "Use Bypass", false },
    { 'checkbox', "Miscellaneous", nil, 'Prop Utilities', "Use Random Props", false },


    // Console
    { "section", 'Other', 'Console', "Output", function( DScrollPanel, DPanelSection )
        DScrollPanel:Remove( )

        local DRichText = vgui.Create( "RichText", DPanelSection )
        DRichText:Dock( FILL )

        function Main:ConsoleInsert( Prefix, Text, PrefixColor )
            DRichText:InsertColorChange( PrefixColor.r, PrefixColor.g, PrefixColor.b, 255 )
            DRichText:AppendText( '[' .. Prefix .. '] ' )
            DRichText:InsertColorChange( 192, 192, 192, 255 )
            DRichText:AppendText( ' ' .. Text .. '\n' )
        end

        local CommandEntry = vgui.Create( 'DTextEntry', DPanelSection )
        CommandEntry:Dock( BOTTOM ) 

        CommandEntry.OnEnter = function( self, value )
            Command:OnEnter( CommandEntry, value )
        end

        CommandEntry.Paint = function( self, w, h )
            draw.RoundedBox( 0, 0, 0, w, h, Color( 30, 30, 30 ) )

            surface.SetDrawColor( 42, 42, 42 )
            surface.DrawOutlinedRect( 0, 0, w, h, 1 )

            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )

            if self:HasFocus( ) then 
                draw.SimpleText( self:GetValue( ), 'Trebuchet18', 5, 0 )
            else
                draw.SimpleText( 'Type a command or type `help` to get a list of commands...', 'Trebuchet18', 5, 0 )
            end
        end
    end },

    // Player List
    { "section", 'Other', 'Player List', "List", function( DScrollPanel, DPanelSection )
        DScrollPanel:Remove( ) -- DTree comes with it.

        local DTree = vgui.Create( 'DTree', DPanelSection )
        DTree:Dock( FILL )
        DTree.Paint = function( self, w, h )
            draw.RoundedBox( 0, 0, 0, w, h, Color( 30, 30, 30 ) )

            surface.SetDrawColor( 42, 42, 42 )
            surface.DrawOutlinedRect( 0, 0, w, h, 1 )

            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
        end

        DTree.OnNodeSelected = function( Node ) end

        local VBar = DTree:GetVBar(  )
        VBar:SetWide( Main.Scale(4) )
        VBar:SetHideButtons( true )
        VBar.Paint = function( s, w, h )
            surface.SetDrawColor( Main.UIColors['Black03'] )
            surface.DrawRect( 0, 0, w, h )
        end

        VBar.btnGrip.Paint = function( s, w, h )
            surface.SetDrawColor( Main.UIColors['Black04'] )
            surface.DrawRect( 0, 0, w, h )
        end

        Playerlist:PassObject( DTree )
    end },
}

//-/~ Setup
Main.Elements = { }
local gradient = Material( 'vgui/gradient-l' )
local gradient_down = Material( 'gui/gradient_down' )

function Main.Scale( size )
    return math.max( size * (ScrH() / 1440), 1 )
end

for i = 5, 40 do
    surface.CreateFont( 'oxide.' .. i, { font = 'Roboto Bold', size = Main.Scale( i ), weight = 550 } )
end

local bg = vgui.Create( 'DPanel' )
bg:Dock( FILL )
bg:SetKeyboardInputEnabled( true )
bg:Center( )
bg.Paint = function( s,w,h )
    surface.SetDrawColor( Main.UIColors['Black02'] )
    surface.DrawRect( 0, 0, w, h )
end
bg.Think = function( s )
    if s:HasFocus( ) then
        s:KillFocus( )
    end
end

Main.Elements[ 'Menu Reference' ] = bg

local offset = Main.Scale( 20 )
local handle = vgui.Create( 'DIconLayout', bg )
handle:Dock( FILL )
handle:DockMargin( offset, offset, offset, offset )
handle:SetSpaceX( Main.Scale( 8 ) )
handle:SetSpaceY( Main.Scale( 8 ) )
handle.OnMousePressed = function( ) Main.Element:CloseMixer( ) end

//-/~ Find UI Indexes
function Main.Element:FindIndex( ui, page, title )
    if !IsValid(Main.Elements[ui or '']) then return end
    local elem = Main.Elements[ui]

    if page then
        return IsValid(elem[page]) and ( title and IsValid(elem[page][title]) and elem[page][title] ) or elem[page]
    end

    return IsValid(elem[title]) and elem[title] or elem
end

//-/~ DScrollPanel
function Main.Element:DScrollPanel( parent )
    if !IsValid( parent ) then return end

    local DScrollPanel = vgui.Create( 'DScrollPanel', parent )

    local VBar = DScrollPanel:GetVBar(  )
    VBar:SetWide( Main.Scale(4) )
    VBar:SetHideButtons( true )
    VBar.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black03'] )
        surface.DrawRect( 0, 0, w, h )
    end
    VBar.btnGrip.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black04'] )
        surface.DrawRect( 0, 0, w, h )
    end

    DScrollPanel.OnMousePressed = function( )
        Main.Element:CloseMixer( )
    end

    return DScrollPanel
end

//-/~ DFrame
function Main.Element:CreateDFrame( title, tabs, w, h )
    w, h = w and Main.Scale(w) or Main.Scale( 600 ), h and Main.Scale(h) or Main.Scale( 700 )

    local Menu = vgui.Create( 'DFrame', handle )
    Menu:DockPadding( 0,0,0,0 )
    Menu:SetTitle( '' )
    Menu:SetDraggable( false )
    Menu:MakePopup( )
    Menu:SetSize( w, h )
    Menu.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black'] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end
    Main.Elements[ title ] = Menu

    local i = Main.Scale( 1 )
    Menu.Title = vgui.Create( 'DPanel', Menu )
    Menu.Title:Dock( TOP )
    Menu.Title:DockMargin( i, i, i, 0 )
    Menu.Title:SetTall( Main.Scale( 25 ) )
    Menu.Title.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Purple02' ] )
        surface.DrawRect( 0, 0, w, h )

        draw.SimpleText( title or '', 'oxide.16', 4, h/2.1, Main.UIColors[ 'White' ], 0, 1 )
        surface.SetDrawColor( Main.UIColors[ 'Purple01' ] )
        surface.DrawRect( 0, h-2, w, 2 )
    end
    
    Menu.Title.OnMousePressed = function( ) 
        Main.Element:CloseMixer( )
    end 

    Menu.filler = vgui.Create( 'DPanel', Menu )
    Menu.filler:Dock( FILL )
    Menu.filler:DockMargin( i, 0, i, i )
    Menu.filler.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black03' ] )
        surface.DrawRect( 0, 0, w, h )
    end

    Menu.filler.OnMousePressed = function( ) 
        Main.Element:CloseMixer( )
    end 
            
    Menu.populate = vgui.Create( 'Panel', Menu.filler )
    Menu.populate:Dock( FILL )
    Menu.populate:DockMargin( Main.Scale(12), Main.Scale(8), Main.Scale(12), Main.Scale(8) )


    Menu.layout = {}
    Menu.layout[ title ] = {}

    if tabs then
        local nav = vgui.Create( 'DPanel', Menu )
        nav:Dock( TOP )
        nav:DockMargin( i, 0, i, 0 )
        nav:SetTall( Main.Scale(32) )
        nav.Paint = function( s, w, h )
            surface.SetDrawColor( Main.UIColors[ 'Black07' ] )
            surface.DrawRect( 0, 0, w, h )

            surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
            surface.DrawRect( 0, h-2, w, 2 )
        end

        local selected;

        for i, v in ipairs( tabs ) do
            Menu.layout[ title ][ v ] = Menu.layout[ title ][ v ] or { }

            local layout = vgui.Create( 'DIconLayout', Menu.populate )
            table.insert( Menu.layout[ title ][ v ], layout )

            Main.Elements[ title ][ v ] = layout

            layout:Dock( FILL )
            layout:SetSpaceX( Main.Scale(6) )
            layout:SetSpaceY( Main.Scale(6) )
            layout.OnMousePressed = function( ) 
                Main.Element:CloseMixer( )
            end 
            
            if i != 1 then 
                layout:SetVisible( false ) 
            else 
                selected = v
            end

            local DButton = vgui.Create( 'DButton', nav )
            DButton:Dock( LEFT )
            DButton:DockMargin( 0, 0, Main.Scale(3), Main.Scale(5) )
            DButton:SetText( '' )
            DButton.Think = function( s )
                if s.THINKED then return end
                s.THINKED = true
                s:SetWide( (nav:GetWide( ) / #tabs) - Main.Scale(3) )
            end

            DButton.Paint = function( s, w, h )
                local hover = s:IsHovered(  )
                local me = ( selected == v )

                surface.SetDrawColor( hover and Main.UIColors[ 'Black08' ] or Main.UIColors[ 'Black04' ] )
                surface.DrawRect( 0, 0, w, h )

                draw.SimpleText( v, 'oxide.16', w / 2, h / 2, ( me and Main.UIColors[ 'Purple03' ] ) or ( hover and Main.UIColors[ 'White' ] or Main.UIColors[ 'White04' ] ), 1, 1 )
            end

            DButton.DoClick = function(  )
                if selected == v then return end
                Main.Elements[ title ][ selected ]:SetVisible( false )
                Main.Elements[ title ][ v ]:SetVisible( true )
                selected = v

                Main.Element:CloseMixer( )
            end
        end
    else
        Menu.layout = vgui.Create( 'DIconLayout', Menu.populate )
        Menu.layout:Dock( FILL )
        Menu.layout:SetSpaceX( Main.Scale(6) )
        Menu.layout:SetSpaceY( Main.Scale(6) )
        Menu.layout.OnMousePressed = function( ) 
            Main.Element:CloseMixer( )
        end 
    end

    Menu:ShowCloseButton( false )
end

//-/~ Section
function Main.Element:CreateSection( ui, page, title, func )
    local parent = self:FindIndex( ui, page, title )

    if !parent then return end

    local section = parent:GetName( ) == 'DIconLayout' and parent:Add( 'DPanel' ) or parent.layout:Add( 'DPanel' )
    
    section.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black05'] )
        surface.DrawRect( 0, 0, w, h )
        surface.SetDrawColor( Main.UIColors['Black04'] )
        surface.DrawOutlinedRect(0, 0, w, h, 1 )
        surface.SetDrawColor( Main.UIColors['Black'] )
        surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
    end

    section.OnMousePressed = function( )
        Main.Element:CloseMixer( )
    end

    local navbar = vgui.Create( 'DPanel', section )
    navbar:Dock( TOP )
    navbar:DockMargin( Main.Scale(3), Main.Scale(3), Main.Scale(3), Main.Scale(5) )
    navbar:SetTall( Main.Scale(22) )
    navbar.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Purple04'] )
        surface.SetMaterial( gradient )
        surface.DrawTexturedRect( 0, 0, w, h )
        surface.SetDrawColor( Main.UIColors['Purple03'] )
        surface.DrawRect( 0, h-2, w, 2 )
        draw.SimpleText( title, 'oxide.16', 3, h*.45, Main.UIColors['White'], 0, 1 )
    end

    navbar.OnMousePressed = function( )
        Main.Element:CloseMixer( )
    end

    local panel = vgui.Create( 'Panel', section )
    panel:Dock( FILL )
    panel:DockMargin( Main.Scale(10), Main.Scale(6), Main.Scale(10), Main.Scale(6) )

    local scroll = self:DScrollPanel( panel )
    scroll:Dock( FILL )
    scroll.OnMousePressed = function( )
        Main.Element:CloseMixer( )
    end

    if func then
        func( scroll, section )
    end

    parent[ title ] = scroll

    return scroll
end

//-/~ Checkbox
function Main.Element:CreateCheckBox( ui, page, section, name, overwrite, docklow )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    if overwrite and IsValid(overwrite) then
        -- overwrite.Paint = function(s,w,h)
        --     draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,100))
        -- end

        overwrite:DockMargin( 0, 0, 0, Main.Scale(5) )
    end

    local DCheckBoxLabel = vgui.Create( 'DCheckBoxLabel', ( overwrite or parent ) )
    DCheckBoxLabel:Dock( docklow and BOTTOM or TOP )
    DCheckBoxLabel:DockMargin( docklow and Main.Scale(8) or 0, 0, 0, parent and Main.Scale(5) or 0 )
    DCheckBoxLabel:SetTextColor( Main.UIColors[ 'White' ] )
    DCheckBoxLabel:SetFont( 'oxide.16' )
    DCheckBoxLabel:SetText( name )
    DCheckBoxLabel:SizeToContents( )
    DCheckBoxLabel.Button.Paint = function( s, w, h )
        parent[ name ] = s:GetChecked( )

        if parent[ name ] then
            surface.SetDrawColor( Main.UIColors[ 'Purple03' ] )
            surface.DrawRect( 0, 0, w, h )
            draw.SimpleText( '✔', 'oxide.16', w/2, h/2, Main.UIColors[ 'White' ], 1, 1 )
        else
            surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
            surface.DrawRect( 0, 0, w, h )
        end
        
        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end 
    
    if parent[ name ] then 
        DCheckBoxLabel:SetValue( parent[ name ] )
    end

    DCheckBoxLabel.OnMousePressed = function( )
        Main.Element:CloseMixer( )
    end

    DCheckBoxLabel.OnChange = function( self, val )
        parent[ name ] = val

        hook.Run( 'ovc', name, self, val )
    
        Main.Element:CloseMixer( )
    end

    parent[ name .. ' Pointer' ] = DCheckBoxLabel

    return DCheckBoxLabel
end

//-/~ Color Mixer
function Main.Element:CloseMixer( )
    if !IsValid( Main.Elements.Mixer ) then return end
    Main.Elements.Mixer:Remove( )
end

function Main.Element:DColorMixer( ui, page, section, name, color, norainbow, func )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    self:CloseMixer( )

    local x, y = input.GetCursorPos( )

    local DPanel = vgui.Create( 'DPanel' )
    DPanel:SetPos( x, y )
    DPanel:SetSize( Main.Scale(180), Main.Scale(175) )
    DPanel:MoveToFront( )
    DPanel:MakePopup( )
    DPanel.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black06' ] )
        surface.DrawRect( 0, 0, w, h )

        surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
    end

    Main.Elements.Mixer = DPanel

    local DColorMixer = vgui.Create( 'DColorMixer', Main.Elements.Mixer )
    DColorMixer:Dock( FILL )
    DColorMixer:DockMargin( Main.Scale(9), Main.Scale(9), Main.Scale(9), Main.Scale(9) )
    DColorMixer:SetPalette( false )
    DColorMixer:SetWangs( false )
    DColorMixer:SetAlphaBar( true )

    if color then 
        DColorMixer:SetColor( color ) 
    else 
        DColorMixer:SetColor( Main.UIColors[ 'White02' ] ) 
    end

    local Children = DColorMixer:GetChildren()

    Children[ 5 ]:Dock( RIGHT )
    Children[ 5 ]:SetWide( Main.Scale(22) )

    Children[ 6 ]:Dock( RIGHT )
    Children[ 6 ]:SetWide( Main.Scale(22) )

    if not norainbow then 
        self:CreateCheckBox( ui, page, section, name .. ' Rainbow', DPanel, true )
    end

    DColorMixer.Think = function( s )
        if parent[ name..' Rainbow' ] then 
            parent[ name..' Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )

            DColorMixer:SetColor( parent[ name..' Color' ] )
        else 
            parent[ name..' Color' ] = s:GetColor( )
        end
    end

    DColorMixer.ValueChanged = function( self, col )
        if parent[ name..' Rainbow' ] then 
            parent[ name..' Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
        else 
            parent[ name..' Color' ] = col
        end

        if func then 
            func( self, parent[ name..' Color' ], name )
        end

        -- TODO: Dynamic hooking via a hook callback, we'd just grab it from the hook library in here and call them.
    end

    return DPanel
end

function Main.Element:CreateColorMixer( ui, page, section, name, color, text, norainbow, func )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    local default_color = Main.UIColors[ 'White02' ]:ToVector()
    default_color = default_color:ToColor()

    if not parent[ name .. ' Color' ] then 
        parent[ name .. ' Color' ] = color or default_color
    end

    local DPanel = vgui.Create( 'Panel', parent )
    DPanel:Dock( TOP )
    DPanel:SetTall( Main.Scale(20) )

    local DButton = vgui.Create( 'DButton', DPanel )
    DButton:Dock( RIGHT )
    DButton:DockMargin( 0, 0, Main.Scale(12), 0 )
    DButton:SetWide( Main.Scale(45) )
    DButton:SetText( '' )
    DButton.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        if parent[ name .. ' Rainbow' ] then
            s.col = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
        end
        
        if func then 
            func( self, s.col, name )
        end

        surface.SetDrawColor( s.col )
        surface.SetMaterial( gradient_down )
        surface.DrawTexturedRect( 1, 1, w-2, h-2 )
    end

    DButton.Think = function( s )
        if s.col != ( parent[ name .. ' Color' ] or color or default_color ) then 
            s.col = parent[ name .. ' Color' ] or color or default_color
            
            hook.Run( 'ovc', name, s, s.col )
        end
    end

    DButton.DoClick = function( s )
        self:DColorMixer( ui, page, section, name, s.col, norainbow, func )
    end

    if not text then 
        self:CreateCheckBox( ui, page, section, name, DPanel )
    else 
        local DLabel = vgui.Create( 'DLabel', DPanel )
        DLabel:Dock( TOP )
        DLabel:DockMargin( 0, 0, 0, Main.Scale( 10 ) )
        DLabel:SetTextColor( Main.UIColors[ 'White' ] )
        DLabel:SetFont( 'oxide.16' )
        DLabel:SetText( name )
        DLabel:SizeToContents( )
    end

    self:DColorMixer( ui, page, section, name, DButton.col, norainbow, func )

    parent[ name .. ' Color Pointer' ] = DButton

    self:CloseMixer( )

    return DPanel
end

//-/~ DropDown
function Main.Element:CreateDropDown( ui, page, section, name, useName, dropdown, tbl, override, dockright )
    if !dropdown then return end

    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    tbl = tbl or {}

    parent[ name ] = parent[ name ] or dropdown


    if useName then
        local DLabel = vgui.Create( 'DLabel', parent )
        DLabel:Dock( TOP )
        -- DLabel:DockMargin( 0, 0, 0, 0 )
        DLabel:SetTextColor( Main.UIColors[ 'White' ] )
        DLabel:SetFont( 'oxide.16' )
        DLabel:SetText( name )
        DLabel:SizeToContents( )
    end

    local DComboBox = vgui.Create( 'DComboBox', ( override or parent ) )

    if dockright then
        DComboBox:Dock( RIGHT )
        DComboBox:DockMargin( 0, 0, Main.Scale(3), 0 )
        DComboBox:SetWide( Main.Scale(70) )
    else -- For some reason if you dock above and then SetPos it just refuses to listen to you.
        DComboBox:Dock( TOP )
        DComboBox:DockMargin( 0, 0, Main.Scale(10), Main.Scale(10) )
    end

    DComboBox:SetTextColor( Main.UIColors[ 'White' ] )
    DComboBox:SetFont( 'oxide.15' )
    DComboBox:SetValue( dropdown )
    DComboBox:SetSortItems( false )

    for k, v in pairs( tbl ) do DComboBox:AddChoice( v ) end
    
    DComboBox:GetChildren( )[ 1 ].Paint = function( s, w, h )
        draw.SimpleText( '▼', 'oxide.13', w/2, h/2, Main.UIColors[ 'Grey' ], 1, 1 )
    end

    DComboBox.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
        surface.DrawRect( 1, 1, w-2, h-2 )
    end

    DComboBox.OnMenuOpened = function( panel )
        Main.Element:CloseMixer( )

        local childMenu = panel:GetChildren( )[ 2 ]

        childMenu.Paint = function( s, w, h )
            surface.SetDrawColor( Main.UIColors[ 'Black' ] )
            surface.DrawOutlinedRect( 0, 0, w, h, 1 )

            surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
            surface.DrawRect( 1, 1, w-2, h-2 )
        end
    
        for i = 1, #tbl do 
            childMenu:GetChild( i ):SetColor( Main.UIColors[ 'White' ] ) 
        end

        panel:GetChildren( )[ 2 ].OpenSubMenu = function( sub, menu )
            local subSub = sub:GetChildren( )[ 1 ]
            for i = 1, #tbl do 
                local subSubSub = subSub:GetChildren( )[ i ]

                subSubSub.Paint = function( self, w, h )
                    if !self:IsHovered( ) then return end 
                    surface.SetDrawColor( Main.UIColors[ 'Black02' ] )
                    surface.DrawRect( 0, 0, w, h )
                end
            end
        end
    end

    DComboBox.OnSelect = function( _, _, d )
        parent[ name ] = d
    end

    parent[ name .. ' Pointer' ] = DComboBox

    return DComboBox
end

//-/~ Button
function Main.Element:CreateTextbox( ui, page, section, identity, default )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    parent[ identity ] = default or ''

	local DTextEntry = vgui.Create( 'DTextEntry', parent ) -- create the form as a child of frame
	DTextEntry:Dock( TOP )
    DTextEntry:DockMargin( 0, 0, Main.Scale(10), Main.Scale(6) )
    DTextEntry:SetValue( parent[ identity ] )
    DTextEntry:SetTextColor( Main.UIColors[ 'White' ] )
    DTextEntry:SetFont( 'oxide.17' )
    DTextEntry.OnEnter = function( self )
        parent[ identity ] = self:GetValue( )

        self:KillFocus( )

        parent:RequestFocus( )
    end
    DTextEntry.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
        surface.DrawRect( 1, 1, w-2, h-2 )
        
        s:DrawTextEntryText( Color( 255, 255, 255 ), Color( 255, 255, 255 ), Color( 255, 255, 255 ) )
    end

    DTextEntry.OnMousePressed = function( self, code )
        if code == MOUSE_RIGHT then 
            DTextEntry:SetValue( default )
            return true
        end
    end

    parent[ identity .. ' Pointer' ] = DTextEntry
end

//-/~ Button
function Main.Element:CreateButton( ui, page, section, name )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    parent[ name ] = false

    local DButton = vgui.Create( "DButton", parent ) 
    DButton:SetText( name )					
    DButton:Dock( TOP )
    DButton:DockMargin( 0, 0, Main.Scale(10), Main.Scale(10) )
    DButton:SetTextColor( Main.UIColors[ 'White' ] )
    DButton:SetFont( 'oxide.15' )
    
    DButton.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
        surface.DrawRect( 1, 1, w-2, h-2 )
    end

    DButton.DoClick = function()				
        parent[ name ] = true

        timer.Simple( 0, function( )
            parent[ name ] = false
        end )	
    end

    return DButton
end

//-/~ Slider
function Main.Element:CreateSlider( ui, page, section, prefix, min, max, useName, name )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end

    parent[ name ] = math.ceil( max / 2 )

    if useName then
        local DLabel = vgui.Create( 'DLabel', parent )
        DLabel:Dock( TOP )
        -- DLabel:DockMargin( 0, Main.Scale(10), 0, 0 )
        DLabel:SetTextColor( Main.UIColors[ 'White' ] )
        DLabel:SetFont( 'oxide.16' )
        DLabel:SetText( name )
        DLabel:SizeToContents( )
    end

    local DNumSlider = vgui.Create( 'DNumSlider', parent )
    DNumSlider:Dock( TOP )
    DNumSlider:DockMargin( -Main.Scale(260), 0, -Main.Scale(45), Main.Scale(14) )
    DNumSlider:SetTall( Main.Scale(6) )
    DNumSlider:SetText( '' )
    DNumSlider:SetMin( min )
    DNumSlider:SetMax( max )
    DNumSlider:SetValue( math.ceil( max / 2 ) )
    DNumSlider.Slider.Paint = function( s, w, h )
        local value   = tonumber( DNumSlider:GetValue() )
        local clamped = w*math.Clamp( (value - min) / (max - min), 0, 1 )
        local textw   = w / 2.2

        if value > 100 then 
            textw = w / 2.3
        elseif value < 10 then 
            textw = w / 2.1
        end

        surface.SetDrawColor( Main.UIColors[ 'Black08' ] )
        surface.DrawRect( 0, 0, w, h )

        surface.SetDrawColor( Main.UIColors[ 'Purple03' ] )
        surface.DrawRect( 0, 1, clamped, h-2 )

        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        DisableClipping( true )
            draw.SimpleText( math.ceil( value ) .. prefix, 'oxide.16', textw, h * 2, Main.UIColors[ 'White04' ], 0, 1 )
        DisableClipping( false )
    end

    DNumSlider.OnValueChanged = function( _, i )
        parent[ name ] = math.ceil( i )

        hook.Run( 'ovc', name, self, i )
    end

    DNumSlider.Slider:GetChildren( )[ 1 ].Paint = nil
    DNumSlider:GetChildren( )[ 1 ].Paint = nil 

    parent[ name .. ' Pointer' ] = DNumSlider

    return DNumSlider
end

//-/~ Binder
function Main.Element:CreateBinder( ui, page, section, name, avoidMode )
    local parent = self:FindIndex( ui, page, section )

    if !parent then return end
    
    parent[ name .. ' Bind' ] = KEY_NONE

    local DPanel = vgui.Create( 'Panel', parent )
    DPanel:Dock( TOP )
    DPanel:DockMargin( 0, 0, 0, Main.Scale(10) )
    DPanel:SetTall( Main.Scale(20) )

    local DBinder = vgui.Create( 'DBinder', DPanel )
    DBinder:Dock( RIGHT )
    DBinder:DockMargin( 0, 0, Main.Scale(12), 0 )
    DBinder:SetWide( Main.Scale(70) )
    DBinder:SetTextColor( Main.UIColors[ 'White' ] )
    DBinder:SetFont( "oxide.12" )
    DBinder.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors[ 'Black04' ] )
        surface.DrawRect( 0, 0, w, h )

        surface.SetDrawColor( Main.UIColors[ 'Black' ] )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    DBinder.OnChange = function( bind )
        parent[ name .. ' Bind' ] = bind:GetValue( )
    end

    if not avoidMode then 
        self:CreateDropDown( ui, page, section, name .. ' Bind Style', false, 'Hold', { 'Hold', 'Toggle' }, DPanel, true )
    end 

    self:CreateCheckBox( ui, page, section, name, DPanel )

    parent[ name .. ' Bind Pointer' ] = DBinder

    return DBinder
end

//-/~ Grab Color
function Main.GetColor( Tbl, Index, Convert ) -- Actual record for the ugliest code I've ever written.
    if Tbl[ Index..' Rainbow' ] then -- Pretty sure I've written ASM prettier than this.
        Tbl[ Index..' Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
    end

    local Col = Tbl[ Index..' Color' ]

    if Convert then 
        Col = Vector( Col.r / 255, Col.g / 255, Col.b / 255 )
    end

    return Col
end

//-/~ Fill our menu
for _, t in ipairs( Options ) do
    local e = t[ 1 ]:lower( )

    if e == 'menu' then
        Main.Element:CreateDFrame( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'section' then
        Main.Element:CreateSection( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'checkbox' then
        Main.Element:CreateCheckBox( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'colormixer' then
        Main.Element:CreateColorMixer( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ], t[ 9 ] )
    elseif e == 'dropdown' then
        Main.Element:CreateDropDown( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ], t[ 9 ], t[ 10 ] )
    elseif e == 'slider' then
        Main.Element:CreateSlider( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ], t[ 9 ] )
    elseif e == 'binder' then 
        Main.Element:CreateBinder( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ] )
    elseif e == 'button' then
        Main.Element:CreateButton( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'textbox' then
        Main.Element:CreateTextbox( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ] )
    end
end

for k, pnl in pairs( Main.Elements ) do
    if !IsValid(pnl.populate) then continue end

    function pnl.populate:PerformLayout( w, h )
        local cols = 2
        local layout = pnl.layout

        if istable(layout) then
            for _, t in pairs( layout ) do
                for kk, pnl in pairs( table.Copy(t) ) do
                    local _layout = pnl[ 1 ]
                    local children = _layout:GetChildren( )
                    local ww, hh = 0, 0

                    if #children > 1 then
                        ww = w - math.ceil( (cols - 1) * _layout:GetSpaceX( ) )
                        ww = ww/cols
                    else
                        ww = w
                    end

                    if #children > 2 then
                        hh = h - ( (cols - 1) * _layout:GetSpaceY( ) )
                        hh = hh/cols
                    else
                        hh = h
                    end

                    for i = 1, #children do
                        _layout:GetChildren( )[ i ]:SetSize( ww, hh )
                    end
                end
            end
        else
            local children = layout:GetChildren( )
            local ww, hh = 0, 0

            if #children > 1 then
                ww = w - math.ceil( (cols - 1) * layout:GetSpaceX( ) )
                ww = ww/cols
            else
                ww = w
            end
    
            if #children > 2 then
                hh = h - ( (cols - 1) * layout:GetSpaceY( ) )
                hh = hh/cols
            else
                hh = h
            end
    
            for i = 1, #children do
                layout:GetChildren( )[ i ]:SetSize( ww, hh )
            end
        end
    end
end

//-/~ Hook
local menuToggle = false

Main:Hook( 'Think', function( )
    local k, b = input.IsKeyDown( KEY_INSERT ), bg:IsVisible( )
    
    if k and not menuToggle then 
        menuToggle = true

        Main.Element:CloseMixer( )

        bg:SetVisible( !b )
        bg:RequestFocus( ) 

        gui.EnableScreenClicker( !b )
    elseif !k then 
        menuToggle = false
    end
end )

Main:ConsoleInsert( 'SYSTEM', 'Cheat loaded successfully, welcome user', Color( 255, 87, 51 ) )

if _M then 
    Main:ConsoleInsert( 'MAJESTIC', 'Majestic loaded with cheat successfully', Color( 221, 160, 221 ) )
end

if proxi then 
    Main:ConsoleInsert( 'PROXI', 'Proxi detected, more features enabled', Color( 0, 160, 221 ) )
end

Main:ConsoleInsert( 'SYSTEM', 'Detected gamemode : ' .. Main.Gamemode, Color( 255, 87, 51 ) )


local function Recursive( Children, Indent )
    if not Children or #Children == 0 then return end

    Indent = Indent or 0

    for k,v in pairs( Children ) do 
        if v:HasFocus( ) then 
            MsgN( string.rep( ' ', Indent ), tostring( v ), ' -> ', tostring( v:HasFocus( ) ) )
        end

        Recursive( v:GetChildren( ), Indent + 1 )

        v:KillFocus( )
    end
end

concommand.Add('fuckoff', function( )
    local Children = bg:GetChildren( )

    Recursive( Children )

    bg:RequestFocus( )
end)