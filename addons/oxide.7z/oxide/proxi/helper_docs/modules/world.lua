/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

World = { 
    Skybox = ents.FindByClass( 'env_skypaint' )[ 1 ],
    World  = game.GetWorld( ),

    r_aspectratio = GetConVar( 'r_aspectratio' ),

    Texture = { 
        [ 'Cloud' ]  = 'skybox/clouds',
        [ 'Stars' ]  = 'skybox/starfield',
        [ 'Warp' ]   = 'models/props_lab/warp_sheet',
        [ 'Bars' ]   = 'phoenix_storms/heli',
        [ 'Liquid' ] = 'models/shadertest/shader4'
    },

    Effect = {
        [ 'Tesla' ]        = 'TeslaHitboxes',
        [ 'Gibs' ]         = 'AntlionGib',
        [ 'Sparks' ]       = 'cball_explode',
        [ 'Heavy Sparks' ] = 'Sparks',
        [ 'Explosion' ]    = 'Explosion'
    },

    Sound = {
        [ 'Pop' ]    = 'garrysmod/balloon_pop_cute.wav',
        [ 'Snap' ]   = 'npc/barnacle/neck_snap2.wav',
        [ 'Crunch' ] = 'physics/cardboard/cardboard_box_impact_bullet4.wav',
        [ 'Click' ]  = 'UI/buttonclick.wav',
        [ 'Blip' ]   = 'buttons/blip1.wav',
        [ 'Stab' ]   = 'phx/eggcrack.wav'
    }
}

if not World.Skybox then 
    -- Fallback skyboxes cannot be edited.
    Main:ConsoleInsert( 'WORLD', 'Map has an invalid skybox! Modulation will not work correctly.', Color( 127, 255, 212 ) )
end

World.Ratio = World.r_aspectratio:GetFloat( )

//-/~ World Modulation
function World:WorldModulation( Name, Panel, Value )
    if not Name:StartsWith( 'World Modulation' ) or not World.World then return end 

    -- Check our config.
    local Col = color_white

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'World Modulation' ] then 
        Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'World Modulation' ) 
    end

    -- Actually set the materials.
    local Materials = World.World:GetMaterials( )

    if not Materials or not Col then return end 

    for i = 1, #Materials do 
        local Mat = Material( Materials[ i ] )

        -- These should never be error materials but if they are this should stop it from spamming console.
        if not Mat or Mat:IsError( ) then continue end 
        
        Mat:SetVector( '$color', Vector( Col.r / 255, Col.g / 255, Col.b / 255 ) )
        Mat:SetFloat( '$alpha', Col.a / 255 )
    end
end

//-/~ Set Default Skybox Color
function World:SetDefaultSkyboxColor( )
    if not self.Skybox then return end 

    self.Defaults = { }

    self.Defaults.Top    = self.Skybox:GetTopColor( )
    self.Defaults.Bottom = self.Skybox:GetBottomColor( )
    self.Defaults.Dusk   = self.Skybox:GetDuskColor( )

    self.Defaults.Bias = self.Skybox:GetFadeBias( )
    self.Defaults.HDR  = self.Skybox:GetHDRScale( )
    
    self.Defaults.DuskScale     = self.Skybox:GetDuskScale( )
    self.Defaults.DuskIntensity = self.Skybox:GetDuskIntensity( )

    self.Defaults.Stars = self.Skybox:GetDrawStars( )
    self.Defaults.StarTexture = self.Skybox:GetStarTexture( )
    self.Defaults.StarLayers = self.Skybox:GetStarLayers( )
    self.Defaults.StarSpeed = self.Skybox:GetStarSpeed( )
    self.Defaults.StarFade = self.Skybox:GetStarFade( )
    self.Defaults.StarScale = self.Skybox:GetStarScale( )

    -- The entity code on github is lying to you, the sun isn't a seperate entity.
    self.Defaults.SunSize = self.Skybox:GetSunSize( )
    self.Defaults.SunColor = self.Skybox:GetSunColor( )
end

//-/~ Skybox Modulation
function World:SkyboxModulation( )
    -- These network variables are only networked when the player spawns in and never again, hence, why we have a hard coded revert.
    -- Also the default env_skybox entity in the sandbox gamemode uses a think hook and I ran the set network variables in a for loop (400)
    -- with basically no effect on my FPS.
    if not self.Skybox then return end 

    if not self.Defaults then 
        self:SetDefaultSkyboxColor( )
    end

    self:StarModulation( )
    self:SunModulation( )

    -- Fetch colors.
    local Settings = {
        Top    = self.Defaults.Top,
        Bottom = self.Defaults.Bottom,

        Bias = self.Defaults.Bias, 
        HDR  = self.Defaults.HDR,

        Dusk      = self.Defaults.Dusk,
        DuskScale = self.Defaults.DuskScale,
        DuskIntensity = self.Defaults.DuskIntensity 
    }

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Skybox Modulation' ] then         
        Settings.Top    = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Skybox Top', true )
        Settings.Bottom = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Skybox Bottom', true ) 
        
        Settings.Bias = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fade Bias' ] / 100
        Settings.HDR  = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'HDR Scale' ] / 100

        if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Dusk' ] then 
            Settings.Dusk = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Dusk', true )

            Settings.DuskScale     = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Dusk Scale' ] / 100
            Settings.DuskIntensity = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Dusk Intensity' ] / 100
        end
    end

    -- Vectors.
    self.Skybox:SetTopColor( Settings.Top )
    self.Skybox:SetBottomColor( Settings.Bottom )
    self.Skybox:SetDuskColor( Settings.Dusk )

    -- Floats
    self.Skybox:SetFadeBias( Settings.Bias )
    self.Skybox:SetHDRScale( Settings.HDR )
    self.Skybox:SetDuskScale( Settings.DuskScale )
    self.Skybox:SetDuskIntensity( Settings.DuskIntensity )
end

//-/~ Star Modulation
function World:StarModulation( )
    local Settings = {
        Stars = self.Defaults.Stars,
        StarTexture = self.Defaults.StarTexture,
        StarLayers = self.Defaults.StarLayers,

        StarSpeed = self.Defaults.StarSpeed,
        StarFade = self.Defaults.StarFade,
        StarScale = self.Defaults.StarScale
    }

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Modulation' ] then         
        Settings.Stars       = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Draw Stars' ]
        Settings.StarLayers  = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Layers' ]

        Settings.StarTexture = self.Texture[ Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Texture' ] ]
 
        Settings.StarSpeed  = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Speed' ] / 100
        Settings.StarScale  = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Scale' ] / 100
        Settings.StarFade   = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Star Fade' ] / 100
    end

    -- Bools
    self.Skybox:SetDrawStars( Settings.Stars )

    -- Textures
    self.Skybox:SetStarTexture( Settings.StarTexture )

    -- Floats
    self.Skybox:SetStarLayers( Settings.StarLayers )
    self.Skybox:SetStarSpeed( Settings.StarSpeed )
    self.Skybox:SetStarScale( Settings.StarScale )
    self.Skybox:SetStarFade( Settings.StarFade )
end

//-/~ Sun Modulation
function World:SunModulation( )
    local Settings = {
        SunSize = self.Defaults.SunSize,
        SunColor = self.Defaults.SunColor
    }

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sun Modulation' ] then      
        Settings.SunSize  = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sun Scale' ] / 100
        Settings.SunColor = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Sun Modulation', true )
    end

    -- Vectors
	self.Skybox:SetSunColor( Settings.SunColor )

    -- Floats
    self.Skybox:SetSunSize( Settings.SunSize )
end

//-/~ Setup Fog
function World:SetupFog( )
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fog Modulation' ] then 
        return 
    end 

    -- Calculate distance and density.
    local Distance, Density = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fog Distance' ] * 250, Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fog Density' ] / 100

    -- Calculate main fog.
	render.FogMode( MATERIAL_FOG_LINEAR )
	render.FogStart( 0 )
	render.FogEnd( Distance )
	render.FogMaxDensity( Density )

    -- Calculate color.
    local Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Fog Modulation', false )

    render.FogColor( Col.r, Col.g, Col.b )

    return true 
end

//-/~ Setup Sky Fog
function World:SetupSkyFog( Scale )
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sky Fog Modulation' ] then 
        return 
    end 

    -- Calculate distance and density.
    local Distance, Density = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sky Fog Distance' ] * 250, Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sky Fog Density' ] / 100

    -- Calculate main fog.
	render.FogMode( MATERIAL_FOG_LINEAR )
	render.FogStart( 0 )
	render.FogEnd( Distance )
	render.FogMaxDensity( Density )

    -- Calculate color.
    local Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ], 'Sky Fog Modulation', false )

    render.FogColor( Col.r, Col.g, Col.b )

    return true 
end

//-/~ Hit Sounds
function World:HitSounds( Attacker, Victim, Health )
    -- Kill Sound
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Kill Sounds' ] and Health == 0 then 
        local Sound = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Kill Sound' ]

        if Sound == 'Custom' then 
            Sound = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Custom Kill Sound' ]
        else
            Sound = self.Sound[ Sound ] 
        end

        return surface.PlaySound( Sound )
    end

    -- Hit Sound
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Hit Sounds' ] then 
        local Sound = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Hit Sound' ]

        if Sound == 'Custom' then 
            Sound = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Custom Hit Sound' ]
        else
            Sound = self.Sound[ Sound ] 
        end

        return surface.PlaySound( Sound )
    end
end

//-/~ Hit Effects
function World:HitEffects( Attacker, Victim, Health )
    self:HitSounds( Attacker, Victim, Health )

    local Effect = EffectData( )

    -- Set our settings.
    Effect:SetOrigin( Victim:GetPos( ) + Victim:OBBCenter( ) )
    Effect:SetEntity( Victim )
    
    Effect:SetMagnitude( 14 )
    Effect:SetRadius( 1 )
    Effect:SetScale( 6 )

    Effect:SetFlags( 0x84 ) -- https://github.com/ValveSoftware/source-sdk-2013/blob/master/mp/src/game/shared/tempentity.h

    -- Kill Effect
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Kill Effects' ] and Health == 0 then 
        util.Effect( self.Effect[ Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Kill Effect' ] ], Effect )
        return
    end

    -- Hit Effect
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Hit Effects' ] then 
        util.Effect( self.Effect[ Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Hit Effect' ] ], Effect )
    end
end

//-/~ Adjust Aspect Ratio
function World:AspectRatio( )
    proxi._R.ConVar.SetFlags( self.r_aspectratio, FCVAR_NONE ) -- Zero this shit.
    
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Aspect Ratio' ] then 
        proxi._R.ConVar.ForceFloat( self.r_aspectratio, self.Ratio )
        return 
    end  

   proxi._R.ConVar.ForceFloat( self.r_aspectratio, Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Aspect Ratio Scale' ] / 100 )
end

//-/~ Screenspace Effects
function World:ScreenspaceEffects( )
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Color Modification' ] then     
        local Modification = {
            [ '$pp_colour_addr' ] = 0,
            [ '$pp_colour_addg' ] = 0,
            [ '$pp_colour_addb' ] = 0,

            [ '$pp_colour_mulr' ] = 0,
            [ '$pp_colour_mulg' ] = 0,
            [ '$pp_colour_mulb' ] = 0,

            [ '$pp_colour_brightness' ] = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Brightness' ] / 100,
            [ '$pp_colour_contrast' ] = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Contrast' ] / 10,
            [ '$pp_colour_colour' ] = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Saturation' ] / 10,

            [ '$pp_colour_inv' ] = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Invert Colors' ] and 1 or 0
        }

        DrawColorModify( Modification )
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Bloom Modification' ] then     
        DrawBloom( 1 - ( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Bloom Strength' ] / 100 ), Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Strength Multiplier' ], 9, 9, Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Passes' ], Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Color Multiplier' ], 1, 1, 1 )
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Toy Town Modification' ] then     
        DrawToyTown( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Toy Town Strength' ], ScrW( ) / 2 )
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sobel Modification' ] then     
        DrawSobel( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sobel Strength' ] / 100 )
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'DOF Modification' ] then     
        DrawBokehDOF( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'DOF Strength' ], Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'DOF Distance' ] / 100, Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'DOF Focus' ] )
    end
end