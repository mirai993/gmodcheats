/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Name
Name = { 
    ConVar = GetConVar( 'name' )
}

Name.Old = Name.ConVar:GetString( )

//-/~ Fetch Names
Name.Names = {
    First = {
        'John',
        'Emma',
        'Liam',
        'Olivia',
        'Noah',
        'Ava',
        'Elijah',
        'Sophia',
        'James',
        'Isabella',
        'William',
        'Mia',
        'Benjamin',
        'Amelia',
        'Lucas',
        'Harper',
        'Henry',
        'Evelyn',
        'Alexander',
        'Abigail'
    },
    Last = {
        'Smith',
        'Johnson',
        'Williams',
        'Brown',
        'Jones',
        'Garcia',
        'Miller',
        'Davis',
        'Rodriguez',
        'Martinez',
        'Hernandez',
        'Lopez',
        'Gonzalez',
        'Wilson',
        'Anderson',
        'Thomas',
        'Taylor',
        'Moore',
        'Jackson',
        'Martin'
    }
}

//-/~ Get Steam Name
steamworks.RequestPlayerInfo( Main.Local:SteamID64( ), function( Steam )
    Name.Steam = Steam
end )

//-/~ Set
function Name:Set( Name )
    if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Use RP Name' ] then 
        Main.Local:ConCommand( 'say /rpname ' .. Name )
    else
        proxi._R.ConVar.SendValue( self.ConVar, Name )
    end
end

//-/~ Spoof
function Name:Spoof( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Name Spoofer' ] then 
        if self.ConVar:GetString( ) != self.Old then 
            return self:Reset( )
        end
        
        return
    end

    local Mode = Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Name Spoofer Mode' ]

    if Mode == 'Steal' then 
        local Targets = player.GetAll( )

        table.RemoveByValue( Targets, Main.Local )

        self:Set( '\xe2\x80\x8b' .. Targets[ math.random( #Targets ) ]:Nick( ) )
    elseif Mode == 'Static' then 
        self:Set( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Name Spoofer Text' ] )
    elseif Mode == 'Clear' then 
        self:Set( '.' .. string.rep( '\v', 2500 ) )
    elseif Mode == 'Bypass' then
        self:Set( '\xe2\x80\x8b' .. Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Name Spoofer Text' ] )
    elseif Mode == 'Fake Name' then
        self:Set( self.Names.First[ math.random( #self.Names.First ) ] .. ' ' .. self.Names.Last[ math.random( #self.Names.Last ) ] )
    end
end

//-/~ Reset
function Name:Reset( )
    self:Set( ( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Reset Mode' ] == 'Steam' and self.Steam ) or self.Old )
end

//-/~ Force Reset
function Name:ForceReset( )
    if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Reset Name' ] then 
        return self:Reset( )
    end
end