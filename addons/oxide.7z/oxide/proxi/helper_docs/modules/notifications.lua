/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Notifications
Notifications = { 
    [ 'Hitgroups' ] = {
        [ HITGROUP_GENERIC ] = 'body',
        [ HITGROUP_HEAD	] = 'head',
        [ HITGROUP_CHEST ] = 'chest',
        [ HITGROUP_STOMACH ] = 'stomach',
        [ HITGROUP_LEFTARM ] = 'left arm',
        [ HITGROUP_RIGHTARM ] = 'right arm',
        [ HITGROUP_LEFTLEG ] = 'left leg',
        [ HITGROUP_RIGHTLEG ] = 'right leg',
        [ HITGROUP_GEAR ] = 'pelvis'
    }
}

//-/~ Initialize
function Notifications:Initialize( Object )
    local DRichText = vgui.Create( 'RichText', Object )
    DRichText:Dock( FILL )
    DRichText:DockMargin( Main.Scale( 8 ), Main.Scale( 30 ), 0, 0 )
    DRichText:SetVerticalScrollbarEnabled( false )
    DRichText:SetFontInternal( 'TargetID' )

    self.Object = DRichText
end

//-/~ Update
function Notifications:Update( )
    local Object = Dragable:GrabCache( 'Notifications' )

    Object.DFrame:SetSize( 350, 150 )

    if not self.Object then
        Notifications:Initialize( Object.DFrame )
    else
        self.Object:GotoTextEnd( )
    end
end

//-/~ Notify
function Notifications:Notify( ... )
    if self.Object then 
        for k,v in ipairs( { ... } ) do
            if IsColor( v ) or ( istable( v ) and v.r and v.g and v.b ) then 
                self.Object:InsertColorChange( v.r, v.g, v.b, v.a )
            else
                self.Object:AppendText( tostring( v ) )
            end
        end
    end

    -- Just repurposed code from above.
    local Text = ''

    for k,v in ipairs( { ... } ) do
        if IsColor( v ) or ( istable( v ) and v.r and v.g and v.b ) then
            -- Nope
        else 
            Text = Text .. tostring( v )
        end 
    end

    Text = string.Replace( Text, '\n', '' )

    -- Console
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Use Console Messages' ] then 
        Main:Print( Text )
    end

    -- Hints
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Use Hint Popup' ] then 
        notification.AddLegacy( Text, NOTIFY_GENERIC, 4 )
    end
end