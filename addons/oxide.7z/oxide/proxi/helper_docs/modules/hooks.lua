/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ StartCommand
Main:Hook( 'StartCommand', function( Ent, ... )
    Auto:Autoclicker( ... )
end )

//-/~ CreateMove
Main:Hook( 'CreateMove', function( ... )
    Main.Players  = player.GetAll( )
    Main.Entities = ents.GetAll( )

    table.RemoveByValue( Main.Players, Main.Local )

    Freecam:Main( ... )
    Freelook:Main( ... )

    Movement:Bunnyhop( ... )

    Playerlist:Update( )
end )

//-/~ CreateMoveEx (proxi)
Main:Hook( 'CreateMoveEx', function( ... )
    Aimbot:Aimbot( ... )
    
    Auto:Automations( ... )
    
    Props:Toolgun( ... )

    Aimbot:ForceViewAffinity( ... )
    
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Silent Mode' ] == 'Clientside' then 
       Movement:FixMovement( ... ) 
    end

    Movement:Quickstop( ... )

    Chat:DirectMessage( )

    Misc:AutoReload( ... )
    Misc:AutoRevolver( ... )
    Misc:FlashlightSpammer( ... )
    Misc:AutoInventory( ... )
    Misc:SeedDelete( ... )
    Misc:AutoSeed( ... )
    Misc:OverrideRelay( )

    Misc:ServerErrors( )
    Misc:DragonFire( )

    Misc:Slowmo( )
    Misc:Airstuck( )

    Misc:ForceEscape( ... )

    Name:Spoof( )
    Name:ForceReset( )

    Vape:Timer( ... )
    Vape:Spam( ... )

    Props:Spawn(  )
    Props:Bypass( )
    Props:Properties( ... )

    Lists:CalculateLists( ... )
    
    Wallhack:ShotTimer( ... )
    Wallhack:VapeTimer( ... )
    Wallhack:AmmoBar( ... )
        
    Ticks:Doubletap( ... )
    Ticks:Warp( ... )

    DDOS:Check( )

    if not Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ] then 
        return true, true, true
    end 
end )

//-/~ Move
Main:Hook( 'Move', function( ... ) 
    if IsFirstTimePredicted( ) then -- https://wiki.facepunch.com/gmod/Prediction
        Main.BulletTime = CurTime( ) + Interval( )
    end
end )

//-/~ PreFrameStageNotify (proxi)
Main:Hook( 'PreFrameStageNotify', function( ... )
    -- This is correct in my CSGO cheat so I assume it's correct here.
    Records:EmplaceRecords( ... )
end )

//-/~ Think
Main:Hook( 'Think', function( ... )
    Misc:ConsoleSpam( )
    Misc:RagdollCrasher( )
    Misc:Asay( )

    Theme:Think( )
    Theme:Icon( )
end )

//-/~ On Player Chat
Main:Hook( 'OnPlayerChat', function( ... ) 
    Misc:ClearChat( ... )
end )

//-/~ PreDrawViewModel
Main:Hook( 'PreDrawViewModel', function( ... )
    Viewmodel:HandleDrawing( )
end )

//-/~ PostDrawViewModel
Main:Hook( 'PostDrawViewModel', function( ... )
    Viewmodel:HandleLogic( )
end )

//-/~ HUDPaint
Main:Hook( 'HUDPaint', function( ... )
    Wallhack:Wallhack( ... )
    Wallhack:SkinChanger( ... )
    Wallhack:Removals( ... )

    Misc:SWCSFix( )

    Wallhack:Crosshair( ... )
end )

//-/~ RenderScreenspaceEffects
Main:Hook( 'RenderScreenspaceEffects', function( ... )
    Wallhack:Render3D( )
    Wallhack:ProjectileTrail( )

    Records:Chams( )
end )

//-/~ PostDraw2DSkyBox
Main:Hook( 'PostDraw2DSkyBox', function( ... )
    World:SkyboxModulation( )
end )

//-/~ PostDrawTranslucentRenderables
Main:Hook( 'PostDrawTranslucentRenderables', function( ... )
    Overlay:Hook( )
end )

//-/~ Player Footstep
Main:Hook( 'PlayerFootstep', function( ... )
    return true, Wallhack.FootstepManipulation( ... )
end )

//-/~ Player Footstep
Main:Hook( 'RenderScreenspaceEffects', function( ... )
    World:ScreenspaceEffects( )
end )

//-/~ EntityFireBullets
Main:Hook( 'EntityFireBullets', function( Ent, Bullet )
    if Ent != Main.Local then return end 

    local SWEP = Ent:GetActiveWeapon()

    if not SWEP or not SWEP:IsValid( ) then return end 

    local Class = SWEP:GetClass( )

    if not Main.Cones[ Class ] or ( Ent:IsScripted( ) and Main.Cones[ Class ] != Bullet.Spread ) then 
        Main.Cones[ Class ] = Bullet.Spread
    end
end )

//-/~ PostEntityFireBullets
Main:Hook( 'PostEntityFireBullets', function( Ent, Bullet )
    Wallhack:BulletTracers( Ent, Bullet )
end )

//-/~ CalcView
Main:Hook( 'CalcView', function( ... )
    return true, Wallhack.CalculateView( ... )
end )

//-/~ CalcViewModelView
Main:Hook( 'CalcViewModelView', function( ... )
    local Pos, Ang = Wallhack.CalculateViewmodel( ... )
    
    if Pos and Ang then 
        return true, Pos, Ang
    end 
end )

//-/~ PlayerButtonUp
Main:Hook( 'PlayerButtonUp', function( ... )
    Main:PlayerButtonUp( ... )
end )

//-/~ On Value Changed
Main:Hook( 'ovc', function( ... )
    World:WorldModulation( ... )

    World:AspectRatio( ... )
end )

//-/~ SetupWorldFog
Main:Hook( 'SetupWorldFog', function( ... )
    return World:SetupFog( ... ), true
end )

//-/~ SetupSkyboxFog
Main:Hook( 'SetupSkyboxFog', function( ... )
    return World:SetupSkyFog( ... ), true
end )

//-/~ Player Hurt
Main:Hook( 'player_hurt', function( Data )
    local Health, Attacker, Victim = Data.health, Player( Data.attacker ), Player( Data.userid ) 

    if Attacker == Main.Local then 
        World:HitEffects( Attacker, Victim, Health )
    end
end )

//-/~ Scale Player Damage
Main:Hook( 'ScalePlayerDamage', function( ENT, Hitgroup, DamageInfo )
    -- We use this because player_hurt doesn't give a good way to tell how much damage was taken.

    local Damage, Health = math.ceil( DamageInfo:GetDamage( ) ), ENT:Health( )

    if ENT != Main.Local and DamageInfo:GetAttacker( ) == Main.Local then 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Damage Dealt' ] then 
            Notifications:Notify( color_white, string.format( 'Hit %s in the %s for %s damage (%s health remaining; %s overflow)!\n', ENT:Nick( ), Notifications[ 'Hitgroups' ][ Hitgroup ], Damage, math.Limit( Health - Damage, 0 ), ( Damage > Health and Health - Damage or 'no' ) ) )
        end
    elseif ENT == Main.Local then 
        local Attacker = DamageInfo:GetAttacker( )

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Damage Taken' ] then 
            Notifications:Notify( color_white, string.format( 'Hit by %s in the %s for %s damage (%s health remaining; %s overflow)!\n', ( Attacker:IsPlayer( ) and Attacker:Nick( ) or Attacker:GetClass( ) ), Notifications[ 'Hitgroups' ][ Hitgroup ], Damage, math.Limit( Health - Damage, 0 ), ( Damage > Health and Health - Damage or 'no' ) ) )
        end
    end
end )

//-/~ Entity Killed
Main:Hook( 'entity_killed', function( Data )
    local SWEP, Attacker, DMG, Killed = Data.entindex_inflictor, Data.entindex_attacker, Data.damagebits, Data.entindex_killed

    if Entity( Killed ) == Main.Local then
        Misc:CleanupDeath( )
    end
end )

//-/~ Player Spawn
local First = { }

Main:Hook( 'player_spawn', function( Data )
    local User = Data.userid

    -- Cleanup Spawn
    local ENT = Player( User )

    if ENT == Main.Local then
        Misc:CleanupSpawn( )
    end

    -- Admin Popup
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Admin Popup' ] and IsValid( ENT ) and ENT:IsPlayer( ) and First[ User ] then
        if ENT:IsAdmin( ) or ENT:IsSuperAdmin( ) then
            surface.PlaySound( 'vo/npc/Alyx/watchout01.wav' )

            AddText( 'Staff member "' .. ENT:Nick( ) .. '" has joined the server!' )
        end

        First[ User ] = false
    end
end )

//-/~ Player Disconnect
Main:Hook( 'player_disconnect', function( Data )
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Player Disconnect' ] then 
        Notifications:Notify( color_white, Data.name, ' (', Data.networkid, ') has left the server!\n' )
    end
end )

//-/~ Player Connect
Main:Hook( 'player_connect_client', function( Data )
    First[ Data.userid ] = true

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Player Connect' ] then 
        Notifications:Notify( color_white, Data.name, ' (', Data.networkid, ') has left the server!\n' )
    end
end )