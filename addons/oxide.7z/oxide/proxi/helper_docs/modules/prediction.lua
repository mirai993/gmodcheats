/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Prediction Library
-- =============================================================================

-- Main Table
Prediction = { }

-- Cones
Main.Cones = {
    [ 'weapon_smg1' ] = { 0.04362, 0.04362 },
    [ 'weapon_ar2' ] = { 0.02618, 0.02618 },
    [ 'weapon_shotgun' ] = { 0.08716, 0.08716 },
    [ 'weapon_pistol' ] = { 0.00873, 0.00873 }
}

-- =============================================================================
-- Function to handle calling all of our predictions based on SWEP.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Angle (angle): The desired angle to calculate prediction for.
-- @param SWEP (weapon): The weapon to calculate prediction for.
-- =============================================================================
function Prediction:Calculate( CUserCMD, Angle, SWEP )
    local Base = Weapon:GetBase( SWEP )

    if Base == 'None' or Base == 'M9K' then 
        return Prediction.HL2:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'TFA' or Base == 'TFA:RUST' then 
        return Prediction.TFA:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'CW 2.0' then 
        return Prediction.CW:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'FA:S' then 
        return Prediction.FAS:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'TF2' then 
        return Prediction.TF2:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'Cry Of Fear' then 
        return Prediction.COF:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'SWCS' then 
        return Prediction.SWCS:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'ARCCW' then
        return Prediction.ARCCW:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'TACRP' then 
        return Prediction.TACRP:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'SWB' then 
        return Prediction.SWB:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'Half-Life: Source' then 
        return Prediction.HLS:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    elseif Base == 'RTB' then
        return Prediction.RTB:CalculateSpread( CUserCMD, Angle, SWEP, Base )
    end 

    return Angle
end

-- =============================================================================
-- HL2/Engine Prediction
-- =============================================================================

Prediction.HL2 = {
    UniformRandomStream = UniformRandomStream( ),
    Time                = 3500,
    
    -- Convars
    ai_shot_bias_min = GetConVar( 'ai_shot_bias_min' ),
    ai_shot_bias_max = GetConVar( 'ai_shot_bias_max' ),
    ai_shot_bias     = GetConVar( 'ai_shot_bias' ),

    sv_gravity       = GetConVar( 'sv_gravity' ),
    sv_maxvelocity   = GetConVar( 'sv_maxvelocity' )
}

-- =============================================================================
-- Function to handle calculating the crossbow bolt's drop over time.
-- @param Pred (vector): The current prediction vector as calculated by Crossbow.
-- @param ShootPosition (vector): The current shoot position of the player. 
-- @param Max (number): The velocity of the crossbow bolt (always 3500; only changed by addons).
-- @param Gravity (number): The gravity pull of the crossbow bolt.
-- @return number: The amount of drop that will be applied the the bolt.
-- =============================================================================
function Prediction.HL2:CrossbowDrop( Pred, ShootPosition, Max, Gravity )
    -- https://en.wikipedia.org/wiki/Inverse_trigonometric_functions

    local Dist = ( Pred - ShootPosition ):Length2D( )

    local Drop = ( Max ^ 4 ) - Gravity * ( Gravity * ( Dist ^ 2 ) + 2.0 * ( Pred.z - ShootPosition.z ) * ( Max ^ 2 ) )

    return math.atan( ( ( Max ^ 2 ) - ( Drop ^ 0.5 ) ) / ( Gravity * Dist ) )
end

-- =============================================================================
-- Function to handle the crossbow and it's special prediction. 
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Vec (vector): The end position vector (goal) of the bolt.
-- @param Target (player): The associated player that the bolt needs to hit.
-- @param Ticks (number): The amount of ticks allowed before the prediction is aborted. Optimization.
-- @return vector: The predicted vector.
-- =============================================================================
function Prediction.HL2:Crossbow( CUserCMD, Vec, Target, Ticks )
    -- https://raw.githubusercontent.com/ValveSoftware/source-sdk-2013/master/sp/src/game/server/hl2/weapon_crossbow.cpp
    -- https://github.com/ValveSoftware/source-sdk-2013/blob/0d8dceea4310fde5706b3ce1c70609d72a38efdf/mp/src/game/client/c_stickybolt.cpp#L129
    
    local Mins, Maxs    = Target:GetCollisionBounds( )
    local Origin        = Target:GetNetworkOrigin( ) 
    local ShootPosition = Main.Local:GetShootPos( )
    local Velocity      = Target:GetAbsVelocity( )
    local MaxVelocity   = self.sv_maxvelocity:GetFloat( )
    local Gravity       = self.sv_gravity:GetFloat( )

    local Interval      = Interval( )
    local Compensation  = TICK_TO_TIME( proxi.GetFlowOutgoing( ) ) -- Requires proxi.

    -- Calculate the uninterpolated position of the player.
    local Predicted = Origin + ( Vec - Target:GetPos( ) )
    local POffset   = ( Predicted - Origin )

    -- Get the visualization settings.
    local Visualize, VisualizeColor = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Visualize Prediction' ], Main.GetColor( Main.Elements[ 'Aimbot' ][ 'Accuracy' ], 'Visualize Prediction' )

    -- Calculate costly variables.
    local onGround, isNoclip = Target:IsOnGround( ), ( Target:GetMoveType( ) == MOVETYPE_NOCLIP )
    local gravityInterval    = Gravity * Interval

    -- Initialize variables.
    local Time, Trace, Drop = 0, { }, 0
    local Final;

    local traceData = {
        output = Trace,
        mask = MASK_SHOT,
        filter = { Target },
        mins = Mins,
        maxs = Maxs
    }

    while Time < Ticks do  
        if not isNoclip then 
            if not onGround then 
                -- If they're in noclip then gravity doesn't get applied to them.
                -- https://github.com/ValveSoftware/source-sdk-2013/blob/master/sp/src/game/shared/gamemovement.cpp#L1248
                Velocity.z = Velocity.z - gravityInterval
            end

            -- Clamp this so it doesn't break at high speeds.
            -- You don't need to clamp when we're noclipping since it doesn't apply max velocity anyway.
            Velocity.z = math.Clamp( Velocity.z, -MaxVelocity, MaxVelocity )
        end
        
        local Next = Predicted + ( Velocity * Interval )  

        traceData.start = Predicted
        traceData.endpos = Next - POffset

        util.TraceHull( traceData )

        if math.abs( Trace.HitNormal:Dot( Vector( 0, 0, 1 ) ) ) >= 0.65 then 
            Next = Trace.HitPos + POffset
        end

        if Trace.HitSky then break end

        if Visualize then 
            Overlay:Line( Next, Predicted, 5, VisualizeColor )
        end

        Predicted = Next

        -- Calculate the drop on this.
        Drop = self:CrossbowDrop( Predicted, ShootPosition, self.Time, Gravity * 0.05 ) 
        
        local sTime =  ( Predicted - ShootPosition ):Length2D( ) / ( math.cos( Drop ) * MaxVelocity )

        if sTime + Compensation < Time then 
            Final = Predicted
            break 
        end

        Time = Time + Interval
    end

    if not Final then return Vec end

    return ShootPosition + Angle( -math.deg(Drop), (Final - ShootPosition):Angle( ).y, 0 ):Forward() * ( Final - ShootPosition ):Length2D( )
end

-- =============================================================================
-- Function to fetch the bias of a specific seed pattern.
-- @param Seed (number): The current seed we need to predict for.
-- @return x (number): The X bias of the current seed.
-- @return y (number): The Y bias of the current seed.
-- @return z (number): The Z bias of the current seed.
-- =============================================================================
function Prediction.HL2:FetchBias( Seed )
    -- https://github.com/ValveSoftware/source-sdk-2013/blob/0d8dceea4310fde5706b3ce1c70609d72a38efdf/mp/src/game/shared/shot_manipulator.h#L59

    -- For some reason this doesn't properly support ai_shot_bias_min/ai_shot_bias_max. Probably a serverside issue rather than an issue with this code.
    self.UniformRandomStream:SetSeed( Seed )

    local x, y, z = 0, 0, 0
    local bias = self.ai_shot_bias:GetFloat( ) -- Custom for Garry's Mod.

    local shotBiasMin = self.ai_shot_bias_min:GetFloat()
    local shotBiasMax = self.ai_shot_bias_max:GetFloat()

    local shotBias = ( ( shotBiasMax - shotBiasMin ) * bias ) + shotBiasMin
    local flatness = math.abs(shotBias) * 0.5

    repeat
        x = self.UniformRandomStream:RandomFloat(-1, 1) * flatness + self.UniformRandomStream:RandomFloat(-1, 1) * (1 - flatness)
        y = self.UniformRandomStream:RandomFloat(-1, 1) * flatness + self.UniformRandomStream:RandomFloat(-1, 1) * (1 - flatness)

        if shotBias < 0 then
            x = (x >= 0) and 1.0 - x or -1.0 - x
            y = (y >= 0) and 1.0 - y or -1.0 - y
        end

        z = (x * x) + (y * y)
    until z <= 1
    
    return x, y, z
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @param Base (string): The base of the SWEP.
-- @param Cone (vector): The cone of the SWEP. Optional.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.HL2:CalculateSpread( CUserCMD, Ang, SWEP, Base, Cone )
    if not SWEP or not CUserCMD then return Ang end 

    Cone = Cone or Main.Cones[ SWEP:GetClass( ) ]

    if not Cone then return Ang end -- We can't help you here.

    -- Get bias calculation.
    local x, y, z = self:FetchBias( proxi._R.CUserCmd.GetRandomSeed( CUserCMD ) )

    -- Calculate the spread.
    local RetVec = ( Ang:Forward( ) + ( x * Cone[ 1 ] * Ang:Right( ) * -1 ) + ( y * Cone[ 2 ] * Ang:Up( ) * -1 ) ):Angle( )

    RetVec:Normalize( )

    return RetVec
end

-- =============================================================================
-- TFA Prediction
-- =============================================================================

Prediction.TFA = {
    -- Convars
    sv_tfa_spread_multiplier    = GetConVar( 'sv_tfa_spread_multiplier' ),
    sv_tfa_recoil_legacy        = GetConVar( 'sv_tfa_recoil_legacy' ),
    sv_tfa_recoil_mul_p         = GetConVar( 'sv_tfa_recoil_mul_p' ),
    sv_tfa_recoil_mul_y         = GetConVar( 'sv_tfa_recoil_mul_y' )
}

-- =============================================================================
-- Function to calculate the recoil associated with the TFA SWEP.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the recoil of.
-- @param SWEP (weapon): The current SWEP.
-- @param Base (string): The base of the SWEP. Used for `TFA:Rust`. 
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.TFA:CalculateRecoil( CUserCMD, Ang, SWEP, Base )
    if Base == 'TFA:RUST' then return SWEP.RecoilAng end -- This one doesn't care about recoil manipulation commands.

    local Rec = Main.Local:GetViewPunchAngles( )

    if not self.sv_tfa_recoil_legacy:GetBool( ) then 
        Rec.x = SWEP:GetViewPunchP( )
        Rec.y = SWEP:GetViewPunchY( )
        Rec.z = 0
    end 

    Rec.x = Rec.x * self.sv_tfa_recoil_mul_p:GetFloat( )
    Rec.y = Rec.y * self.sv_tfa_recoil_mul_y:GetFloat( )

    return Rec
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @param Base (string): The base of the SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.TFA:CalculateSpread( CUserCMD, Ang, SWEP, Base )
    if not SWEP or not CUserCMD then return Ang end 
    
    SWEP:CalculateRatios( )

    local Cone = SWEP:CalculateConeRecoil( )
	local dYaw, dPitch = SWEP:ComputeBulletDeviation( 1, 1, Cone )
	
    local aimDir = Ang:Forward()

	local a = aimDir.x;
	local b = aimDir.y;
	local c = math.cos( math.rad( 90 - math.abs( dYaw ) ) )
	local s = ( dYaw < 0 ) && -1 || 1
			
	local d = a*a + b*b - c*c
	local e = a + c

	if ( d >= 0 && e != 0 ) then
	    local x = 2*math.atan( ( b + s*math.sqrt( d ) ) / e )
		local right = Vector( -1*s*math.cos( x ), -1*s*math.sin( x ), 0 )
				
		Ang:RotateAroundAxis( right, -dPitch )
				
		local up = right:Cross( Ang:Forward() )
				
		Ang:RotateAroundAxis( up, -dYaw )

        return Ang - self:CalculateRecoil( CUserCMD, Ang, SWEP ) 
	end

    -- This probably shouldn't happen but if the server disables spread or calculates it weird then this could happen.
    return Ang
end

-- =============================================================================
-- CW 2.0 Prediction
-- =============================================================================

Prediction.CW = {  }

-- =============================================================================
-- Function to calculate the cone of the CW 2.0 SWEP. Taken heavily from the offical CW 2.0 base. 
-- @param Ang (angle): The current angle to predict the cone of.
-- @param SWEP (weapon): The current SWEP.
-- =============================================================================
function Prediction.CW:CalculateCurrentCone( Ang, SWEP )
	if not SWEP.AccuracyEnabled then
		return
	end
	
	local aim, CT = Ang:Forward( ), CurTime( )

    -- TODO: Find a way to perfectly sync this between client & server.
        -- SUB-TODO: Clamp this based on the maximum for each weapon, it's unclamped currently.
	if not Main.Local.LastView then
		Main.Local.LastView = aim
		Main.Local.ViewAff = 0
	else
		Main.Local.ViewAff = LerpCW20( Interval( ) * 10, Main.Local.ViewAff, ( aim - Main.Local.LastView ):Length( ) * 0.5 )
		Main.Local.LastView = aim
	end
		
	local baseCone, maxSpreadMod = SWEP:getBaseCone( )
	SWEP.BaseCone = baseCone
	
	if Main.Local:Crouching( ) then
		SWEP.BaseCone = SWEP.BaseCone * SWEP:getCrouchSpreadModifier( )
	end
	
	SWEP.CurCone = SWEP:getFinalSpread( Main.Local:GetVelocity( ):Length2D( ), maxSpreadMod )
	
	if CT > SWEP.SpreadWait then
		SWEP.AddSpread = math.Clamp( SWEP.AddSpread - 0.5 * SWEP.AddSpreadSpeed * Interval( ), 0, SWEP:getMaxSpreadIncrease( maxSpreadMod ) )
		SWEP.AddSpreadSpeed = math.Clamp( SWEP.AddSpreadSpeed + 5 * Interval( ), 0, 1 )
	end
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.CW:CalculateSpread( CUserCMD, Ang, SWEP )
    if not SWEP or not CUserCMD then return Ang end 

    self:CalculateCurrentCone( Ang, SWEP )

    local Spread        = SWEP.CurCone

    -- Adjust based on movement.
    if not Spread then return Ang end 

    if Main.Local:Crouching( ) then 
        Spread = Spread * 0.85
    end
    
    math.randomseed( CUserCMD:CommandNumber( ) )

    return ( Ang - Main.Local:GetViewPunchAngles( ) ) - Angle( math.Rand( -Spread, Spread ), math.Rand( -Spread, Spread ), 0 ) * 25
end


-- =============================================================================
-- F:AS 2.0 Alpha Prediction
-- =============================================================================

Prediction.FAS = { }

-- =============================================================================
-- Function to calculate the cone of the F:AS SWEP. 
-- @param Ang (angle): The current angle to predict the cone of.
-- @param SWEP (weapon): The current SWEP.
-- =============================================================================
function Prediction.FAS:CalculateCurrentCone( Ang, SWEP )
    -- Slightly modified version of the SWEP:CalculateSpread already located in `fas2_base/shared.lua`.
	local aim = Ang:Forward( )

    -- TODO: Find a way to perfectly sync this between client & server.
        -- SUB-TODO: Clamp this based on the maximum for each weapon, it's unclamped currently.	
	if not Main.Local.LastView then
		Main.Local.LastView = aim
		Main.Local.ViewAff = 0
	else
		Main.Local.ViewAff = Lerp( 0.25, Main.Local.ViewAff, ( aim - Main.Local.LastView ):Length( ) * 0.5 )
		Main.Local.LastView = aim
	end
	
	local cone = SWEP.HipCone * ( Main.Local:Crouching( ) and 0.75 or 1 ) * ( SWEP.dt.Bipod and 0.3 or 1 )
		
	if SWEP.dt.Status == FAS_STAT_ADS then
        local td = { }

		td.start = Main.Local:GetShootPos( )
		td.endpos = td.start + aim * 30
		td.filter = Main.Local
		
		local tr = util.TraceLine( td )
		
		if not tr.Hit then
			cone = SWEP.AimCone
		end
	end
	
	SWEP.CurCone = math.Clamp( cone + SWEP.AddSpread * ( SWEP.dt.Bipod and 0.5 or 1 ) + ( Main.Local:GetVelocity( ):Length( ) / 10000 * SWEP.VelocitySensitivity ) * ( SWEP.dt.Status == FAS_STAT_ADS and 0.25 or 1 ) + Main.Local.ViewAff, 0, 0.09 + SWEP.MaxSpreadInc )

    -- Doesn't seem like modifying the things I modified impacted accuracy (specifically on shotguns).
    -- These modifications were done to save a few cpu cycles and ( hopefully ) improve accuracy.
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.FAS:CalculateSpread( CUserCMD, Ang, SWEP )
    -- This function is practically identical to the CW prediction.
    if not SWEP or not CUserCMD then return Ang end 

    self:CalculateCurrentCone( Ang, SWEP )

    local Spread        = SWEP.CurCone

    if not Spread then return Ang end 

    math.randomseed( CurTime( ) ) 

    return ( Ang - Main.Local:GetViewPunchAngles( ) ) - Angle( math.Rand( -Spread, Spread ), math.Rand( -Spread, Spread ), 0 ) * 25
end

-- =============================================================================
-- SWB Prediction
-- =============================================================================

Prediction.SWB = { }

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.SWB:CalculateSpread( CUserCMD, Ang, SWEP )
    if not SWEP or not CUserCMD then return Ang end 

    local Spread        = SWEP:GetCurrentCone( ) 

    -- Adjust based on movement.
    if not Spread then return Ang end 

    if Main.Local:Crouching( ) then 
        Spread = Spread * 0.85
    end
    
    math.randomseed( CUserCMD:CommandNumber( ) )

    return ( Ang - Main.Local:GetViewPunchAngles( ) ) - Angle( math.Rand( -Spread, Spread ), math.Rand( -Spread, Spread ), 0 ) * 25
end


-- =============================================================================
-- SWCS (CS:GO) Prediction
-- =============================================================================

Prediction.SWCS = { 
    UniformRandomStream = UniformRandomStream( ),

    -- Convars
    swcs_weapon_sync_seed           = GetConVar( 'swcs_weapon_sync_seed' ),
    weapon_accuracy_nospread        = GetConVar( 'weapon_accuracy_nospread' ),
    weapon_debug_max_inaccuracy     = GetConVar( 'weapon_debug_max_inaccuracy' ),
    weapon_debug_inaccuracy_only_up = GetConVar( 'weapon_debug_inaccuracy_only_up' )
}

-- =============================================================================
-- Function to calculate the cone of the SWCS SWEP.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return x (number): The predicted X of the cone.
-- @return y (number): The predicted Y of the cone.
-- =============================================================================
function Prediction.SWCS:CalculateCurrentCone( CUserCMD, Ang, SWEP )
    -- For some reason this function has slight inaccuracy issues, I assume do to compression or normalization. Not sure.
    self.UniformRandomStream:SetSeed( SWEP:GetRandomSeed( ) + 1 )

    local flRadiusCurveDensity = self.UniformRandomStream:RandomFloat( )
    if self.weapon_debug_max_inaccuracy:GetBool( ) then 
        flRadiusCurveDensity = 1 -- Maximum spread.
    end 

	local fTheta0 = self.UniformRandomStream:RandomFloat( 0, 2 * math.pi )
    if self.weapon_debug_inaccuracy_only_up:GetBool( ) then
		fTheta0 = math.pi * 0.5
	end
    
    local fRadius0 = flRadiusCurveDensity * SWEP:GetInaccuracy( false )

    local fTheta1, fRadius1 = self.UniformRandomStream:RandomFloat( 0, 2 * math.pi ), self.UniformRandomStream:RandomFloat( ) * SWEP:GetSpread( )

    return fRadius0 * math.cos( fTheta0 ) + fRadius1 * math.cos( fTheta1 ), fRadius0 * math.sin( fTheta0 ) + fRadius1 * math.sin( fTheta1 )
end 

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.SWCS:CalculateSpread( CUserCMD, Ang, SWEP )
    if not self.swcs_weapon_sync_seed:GetBool( ) or self.weapon_accuracy_nospread:GetBool( ) then return Ang - SWEP:GetUninterpolatedAimPunchAngle( ) end 

    local x, y = self:CalculateCurrentCone( CUserCMD, Ang, SWEP )

    if not x or not y then return Ang end 

    local RetVec = ( Ang:Forward( ) + ( x * Ang:Right( ) * -1 ) + ( y * Ang:Up( ) * -1 ) ):Angle( )

    RetVec:Normalize( )

    return RetVec - SWEP:GetUninterpolatedAimPunchAngle( )
end

-- =============================================================================
-- ARCCW Prediction
-- =============================================================================

Prediction.ARCCW = { }

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.ARCCW:CalculateSpread( CUserCMD, Ang, SWEP )
    return Ang
end

-- =============================================================================
-- TF2 Prediction
-- =============================================================================

Prediction.TF2 = { }

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.TF2:CalculateSpread( CUserCMD, Ang, SWEP )
    /*
        Until a working prediction for Entity:Think is found I can't fix this
        Entity:Think is ran weird serverside so I need to figure out what thats ran by before this is can even be done.
    */

    return Ang -- For now we're doing this to prevent weird legacy bugs with base prediction
end

-- =============================================================================
-- Cry Of Fear Prediction
-- =============================================================================

Prediction.COF = { }

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.COF:CalculateSpread( CUserCMD, Ang, SWEP, Base )
    return Prediction.HL2:CalculateSpread( CUserCMD, ( Ang - ( Main.Local:GetViewPunchAngles( )  ) ), SWEP, Base )
end

-- =============================================================================
-- TACRP Prediction
-- =============================================================================

Prediction.TACRP = { }

-- =============================================================================
-- An almost directly ported version of the TACRP recoil system.
-- @param SWEP (weapon): The current TACRP SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.TACRP:CalculateRecoil( SWEP )
    local rec = SWEP:GetRecoilAmount( )

    local rps = SWEP:GetValue( 'RecoilPerShot' )

    if rec == 0 then
        rps = rps * SWEP:GetValue( 'RecoilFirstShotMult' )
    end

    if Main.Local:Crouching( ) and Main.Local:OnGround( ) then
        rps = rps * SWEP:GetValue( 'RecoilCrouchMult' )
    end

    if SWEP:GetInBipod( ) then
        rps = rps * math.min( 1, self:GetValue( 'BipodRecoil' ) )
    end

    rec = rec + rps

    rec = math.Clamp( rec, 0, SWEP:GetValue( 'RecoilMaximum' ) )

    if SWEP:UseRecoilPatterns( ) then
        SWEP:SetRecoilDirection( SWEP:GetRecoilPatternDirection( SWEP:GetPatternCount( ) ) )
    else
        local stab = math.Clamp( SWEP:GetValue( 'RecoilStability' ), 0, 0.9 )
        SWEP:SetRecoilDirection( util.SharedRandom( 'tacrp_recoildir', -180 + stab * 90, -stab * 90 ) )
    end

    SWEP:SetRecoilAmount( rec )
    SWEP:SetLastRecoilTime( CurTime( ) )

    local vis_kick = SWEP:GetValue( 'RecoilVisualKick' )
    local vis_shake = 0

    vis_kick = vis_kick * TacRP.ConVars[ 'mult_recoil_vis' ]:GetFloat( )
    vis_shake = 0

    if SWEP:GetInBipod( ) then
        vis_kick = vis_kick * math.min( 1, SWEP:GetValue( 'BipodKick' ) )
        vis_shake = math.max( 0, 1 - SWEP:GetValue( 'BipodKick' ) )
    end

    local vis_kick_v = vis_kick * 1
    local vis_kick_h = vis_kick * util.SharedRandom( 'tacrp_vis_kick_h', -1, 1)

    return Angle( vis_kick_v, vis_kick_h, vis_shake )
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.TACRP:CalculateSpread( CUserCMD, Ang, SWEP, Base )
    if SWEP:IsShotgun( ) then return Ang end 

    local Spread = SWEP.GetSpread and SWEP:GetSpread( )

    if not Spread then return Ang end 

    return Prediction.HL2:CalculateSpread( CUserCMD, Ang, SWEP, Base, Vector( Spread, Spread, 0 ) )
end

-- =============================================================================
-- Half-Life: Source Prediction
-- =============================================================================

Prediction.HLS = { }

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.HLS:CalculateSpread( CUserCMD, Ang, SWEP, Base )
    if not SWEP or not CUserCMD then return Ang end 

    if SWEP:GetClass( ) == 'weapon_shotgun_hl1' then return Ang end 
    
    Cone = Cone or Main.Cones[ SWEP:GetClass( ) ]

    if not Cone then return Ang end -- We can't help you here.

    local RetVec = ( Ang:Forward( ) + ( Cone.x * Ang:Right( ) ) + Cone.y * Ang:Up( ) ):Angle( )

    RetVec:Normalize( )
    
    return RetVec
end

-- =============================================================================
-- Raising The Bar: Redux Prediction
-- =============================================================================

Prediction.RTB = { }

function Prediction.RTB:CalculateSpreadedVector( Vector, Spread )
	local x, y;
	local i = 0
	while i < 10 do 
		x, y = util.SharedRandom( 'x', -1.0, 1.0, i ), util.SharedRandom( 'y', -1.0, 1.0, i )
        
		if x*x + y*y < 1 then
			break
		end

		i = i + 1
	end
	
	return Vector:Forward( ) + x * Vector:Right( ) * Spread + y * Vector:Up( ) * Spread
end

-- =============================================================================
-- Function to calculate the spread of the associated weapon pack.
-- @param CUserCMD (cusercmd): The current CUserCMD of the CreateMove (or CreateMoveEx).
-- @param Ang (angle): The current angle to predict the spread of.
-- @param SWEP (weapon): The current SWEP.
-- @return angle: The predicted angle.
-- =============================================================================
function Prediction.RTB:CalculateSpread( CUserCMD, Ang, SWEP, Base )
    if not SWEP or not CUserCMD then return Ang end 

    return ( self:CalculateSpreadedVector( Ang, SWEP:GetBulletSpread() ) ):Angle( )
end