/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Auto = { 
    sbox_maxsents = GetConVar( 'sbox_maxsents' ),

    Active = true,

    Heal  = 0,
    Armor = 0,

    Clicked = false
}

//-/~ Start Automations
function Auto:Automations( CUserCMD )
    if not Main.Local:Alive( ) or Main.Local:Health( ) <= 0 or Aimbot.aimTarget != NULL then return end 

    if self.Active then self.Active = false return end

    -- Maximum Entities.  
    local Count, Max = 0, 0
    
    if Main.Local.GetCount then   
        Count, Max = Main.Local:GetCount( 'sents' ), self.sbox_maxsents:GetFloat( )
    end 

    -- Load our autoheal.
    self:AutoHeal( CUserCMD, Count, Max )
    self:AutoArmor( CUserCMD, Count, Max )

    self.Active = true
end

//-/~ Set Angles
function Auto:SetAngles( CUserCMD, Mode )
    local Ang = CUserCMD:GetViewAngles( )

    local EnginePrediction = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

    if EnginePrediction then 
        proxi.StartPrediction( CUserCMD )
    end 

    if Mode == 'Perfect' then 
        proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )
        proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, Angle( 89, Ang.y, Ang.z ):Forward( ) )
    else
        CUserCMD:SetViewAngles( Angle( 89, Ang.y, Ang.z ) )
    end

    if EnginePrediction then 
        proxi.EndPrediction( )
    end 
end

//-/~ Auto Heal
function Auto:AutoHeal( CUserCMD, Count, Max )
    if self.Heal >= CurTime( ) then return end

    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal' ] then 
        return 
    end

    local Difference =  Main.Local:GetMaxHealth( ) - Main.Local:Health( )

    if Difference < Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal Minimum' ] then 
        return 
    end 

    -- Command Methods.
    local Method = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal Method' ] 

    if Method != 'SENT' then 
        local Amount = Main.Local:GetMaxHealth( )

        if Method == 'ULX' and ULib then 
            RunConsoleCommand( 'ulx', 'hp', '^', Amount )
            return
        elseif sam then
            RunConsoleCommand( 'sam', 'hp', '^', Amount )
            return
        end
    end 

    if not Main.Local:OnGround( ) then return end

    -- Calculate our amount and our pack type.
    local Amount, Pack = math.ceil( Difference / 25 ), 'item_healthkit'

    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal Mode' ] == 'Small' then 
        Amount, Pack = math.ceil( Difference / 10 ), 'item_healthvial'
    end 

    -- Check our limit. 
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Ignore Maximum Health Sents' ] and Main.Local.GetCount then 
        if Count >= Max then 
            return
        end

        Amount = math.Clamp( Max - Count, 0, Amount )
    end

    -- Run our autoheal and set our view angles.
    self:SetAngles( CUserCMD, Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal Snap' ] )
    
    for i = 1, Amount do
        RunConsoleCommand( 'gm_spawnsent', Pack ) 
    end

    self.Heal = CurTime( ) + ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoheal Delay' ] / 1000 ) 
end

//-/~ Auto Armor
function Auto:AutoArmor( CUserCMD, Count, Max )
    if self.Armor >= CurTime( ) then return end

    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoarmor' ] then 
        return 
    end

    local Difference =  Main.Local:GetMaxArmor( ) - Main.Local:Armor( )

    if Difference < Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoarmor Minimum' ] then 
        return 
    end 

    -- Command Methods.
    local Method = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoarmor Method' ] 

    if Method != 'SENT' then 
        local Amount = Main.Local:GetMaxArmor( )

        if Method == 'ULX' and ULib then 
            RunConsoleCommand( 'ulx', 'armor', '^', Amount )
            return
        elseif sam then
            RunConsoleCommand( 'sam', 'armor', '^', Amount )
            return
        end
    end 

    if not Main.Local:OnGround( ) then return end

    -- Calculate amount.
    local Amount = math.ceil( Difference / 15 )

    -- Check our limit. 
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Ignore Maximum Armor Sents' ] and Main.Local.GetCount then 
        if Count >= Max then 
            return
        end

        Amount = math.Clamp( Max - Count, 0, Amount )
    end

    -- Run our autoheal and set our view angles.
    self:SetAngles( CUserCMD, Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoarmor Snap' ] )
    
    for i = 1, Amount do
        RunConsoleCommand( 'gm_spawnsent', 'item_battery' ) 
    end

    self.Armor = CurTime( ) + ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Autoarmor Delay' ] / 1000 )
end

//-/~ Autoclicker
function Auto:Autoclicker( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Standalone Autoclicker' ] then return end 

    local Down = CUserCMD:KeyDown( IN_ATTACK )

    if Down and self.Clicked then 
        CUserCMD:RemoveKey( IN_ATTACK )
        self.Clicked = false 
    elseif Down then 
        self.Clicked = true 
    end
end