/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Wallhack
Wallhack = {
    Gradients = { -- Before you shout that this is pasted, it was suggested by Scott that I should take it from his cheat.
        [ 'Gradient Down' ] = Material( 'gui/gradient_down' ),
        [ 'Gradient Up' ] = Material( 'gui/gradient_up' )
    },

    Footstep = {
        [ 'Light' ] = 'buttons/lightswitch2.wav',
        [ 'Screenshot' ] = 'common/bugreporter_succeeded.wav',
        [ 'Notification' ] = 'friends/message.wav',
        [ 'Blip' ] = 'HL1/fvox/blip.wav',
        [ 'Bell' ] = 'HL1/fvox/bell.wav',
        [ 'Stomp' ] = 'npc/antlion/foot3.wav'
    },

    DSP = {
        [ 'Reverb' ] = 2,
        [ 'Depth' ] = 6,
        [ 'Tunnel' ] = 7,
        [ 'Echo' ] = 10,
        [ 'Distorted' ] = 11,
        [ 'Water' ] = 15 
    },

    Projectiles = {
        'm9k_nervegasnade',
        'm9k_thrown_m61',
        'm9k_thrown_nitrox',
        'm9k_thrown_sticky_grenade',
        'm9k_proxy',
        'rpg_missile',
        'npc_grenade_frag',
        'npc_grenade_bugbait',
        'bb_throwncssfrag',
        'bb_throwncsssmoke',
        'cw_grenade_thrown',
        'cw_flash_thrown',
        'hunter_flechette',
        'ghor_shuriken',
        'env_rockettrail',
        'grenade_hand',
        'cbow_rocket',
        'toybox_629_valkyrie_cr'
    },

    Drugs = { 
        [ 'durgz_cocaine_high' ] = true,
        [ 'durgz_cigarette_high' ] = true,
        [ 'durgz_alcohol_high' ] = true,
        [ 'durgz_heroine_high' ] = true,
        [ 'durgz_lsd_high' ] = true,
        [ 'durgz_weed_high' ] = true,
        [ 'durgz_meth_high' ] = true,
        [ 'durgz_pcp_high' ] = true,
        [ 'durgz_mushroom_high' ] = true
    },

    Ball = Material( 'sprites/sent_ball' )
}

//-/~ Exclude
function Wallhack:Exclude( Ent )
    if not Ent or Ent:IsDormant( ) then return false end 

    if _M and _M.Screenshot then return false end 

    if Ent:IsPlayer( ) then 
        if not Ent:Alive( ) then return false end 

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Staff' ] and Ent:IsAdmin( ) then return false end

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Invisible' ] and Ent:GetColor( ).a <= 200 then return false end

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Teammates' ] then 
            if Ent:Team( ) == Main.Local:Team( ) then return false end 

            -- TTT, this only gets networked if we're teammates.
            if Ent.IsTraitor and Ent:IsTraitor( ) then return false end 
        end

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Roles' ] then
            -- Military RP and other similar gamemodes.
            if Ent:GetNWString( 'Role', 'unknown' ) == Main.Local:GetNWString( 'Role', 'localrole' ) then return false end
        end 

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Buildmode' ] then
            if Ent.buildmode then return false end
            
            if Ent:GetNWBool( 'BuildMode' ) then return false end
        end
    else
        if not Ent:IsNextBot( ) and Ent:Health( ) <= 0 then return false end
        
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid NPC' ] then return false end 

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid Friendly' ] and not IsEnemyEntityName( Ent:GetClass( ) ) then return false end  
    end

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Only Visible' ] then 
        local Trace = util.TraceLine( { start = Main.Local:EyePos( ), endpos = Ent:LocalToWorld( Ent:OBBCenter( ) ), filter = { Main.Local, Ent }, mask = MASK_SHOT } )
        
        if Trace.Fraction != 1 then 
            return false 
        end
    end 

    return true
end

-- =============================================================================
-- Create Our Font
-- =============================================================================

surface.CreateFont('oxide_main', {
    font = 'Calibri',
    size = 16,
    outline = true
})

-- =============================================================================
-- 3D Rendering
-- =============================================================================

-- =============================================================================
-- Function to call all 3D rendering functions.
-- =============================================================================
function Wallhack:Render3D( )
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid While Flashed' ] and CurTime( ) < Main.Local:GetNWFloat( 'BlindUntilTime', 0 ) then 
        return
    end

    -- Load settings.
    local Offset = Vector( 0, 0, Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Head Tracer Offset' ] )

    -- Start a 3D rendering call.
    cam.Start3D( )

    -- Set IgnoreZ.
    cam.IgnoreZ( true )

    -- Call our functions.
    local Targets = Main.Entities

    for i = 1, #Targets do 
        local Ent = Targets[ i ]

        if not Ent:IsPlayer( ) and not Ent:IsNPC( ) and not Ent:IsNextBot( ) then continue end

        Ent:SetRenderMode( RENDERMODE_NORMAL )

        if not self:Exclude( Ent ) or Ent == Main.Local then continue end 
    
        self:Chams( Ent )
        
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Head Tracers' ] then 
            self:HeadTracers( Ent, Offset )
        end

        self:Barrel( Ent )
        self:SpriteBall( Ent )
        self:HeadDot( Ent )
    end 
    
    -- End a 3D rendering call.
    cam.End3D( )
end

-- =============================================================================
-- Function to draw a head beam over a player.
-- @param Ent (entity): The entity we're drawing over.
-- @param Offset (number): The offset of the beam.
-- =============================================================================
function Wallhack:HeadTracers( Ent, Offset )
    cam.IgnoreZ( true )

    local Origin = Ent:GetNetworkOrigin( )
    local Trace  = util.TraceLine( { start = Origin, endpos = Origin + Main.MaxHeight, filter = { Ent }, mask = MASK_SHOT } )
    local Dist   = math.Clamp( Ent:EyePos( ):Distance( Main.Local:EyePos( ) ), 100, 2500 )

    -- Calculate the color.
    local Color;

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Overhead Prop' ] and Trace.Entity != NULL and Trace.Entity:GetClass( ) == 'prop_physics' then 
        Color = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Overhead Prop' )
    else 
        Color = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Head Tracers' )
    end 

    render.SetMaterial( Materials:CallCached( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Head Tracer Material' ] ) )
	render.DrawBeam( Ent:EyePos( ) + Offset, Trace.HitPos, Dist/80, 15, 10, Color )
end

-- =============================================================================
-- Function to render a cham over a player.
-- @param Ent (entity): The entity we're rendering over.
-- @param Name (string): The material to render.
-- @param Color (color): The color to render.
-- @param IgnoreZ (boolean): Weather or not to ignore the depth buffer.
-- =============================================================================
function Wallhack:RenderCham( Ent, Name, Color, IgnoreZ )
    if IgnoreZ then Name = Name .. 'IgnoreZ' end 
    
    cam.IgnoreZ( IgnoreZ )

    render.MaterialOverride( Materials:CallCached( Name ) ) -- Use our cached material.
    render.SetColorModulation( Color.r / 255, Color.g / 255, Color.b / 255 ) -- TODO: Make a library for this so I don't have to use these ugly ass /255
    render.SetBlend( Color.a / 255 )
	
    Ent:DrawModel( )

    cam.IgnoreZ( false )
end

-- =============================================================================
-- Function to call the rendering of chams.
-- @param Ent (entity): The entity we're rendering over.
-- @param Prop (boolean): If the entity we're rendering is a prop.
-- =============================================================================
function Wallhack:Chams( Ent, Prop )
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Visible' ] and not Prop then 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Invisible' ] then 
            self:RenderCham( Ent, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Invisible Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Invisible' ), true )

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Invisible Overlay' ] then 
                self:RenderCham( Ent, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Invisible Overlay Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Invisible Overlay' ), true )
            end 
        end

        -- This will not draw your model if you get screengrabbed, meaning, players will be invisible. Render mode takes one tick to disable/enable so you get a slight delay. 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Disable Player Model (!)' ] then 
            Ent:SetRenderMode( RENDERMODE_NONE ) -- We don't use EF_NODRAW because we still want the entity networked and predicted, just not drawn to render target.
        end 

        self:RenderCham( Ent, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Visible Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Visible' ), false )
            
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Visible Overlay' ] then 
            self:RenderCham( Ent, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Visible Overlay Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Visible Overlay' ), false )
        end

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Attachments' ] then 
            local SWEP = Ent:GetActiveWeapon( )

            if not SWEP or not SWEP:IsValid( ) then return end 

            self:RenderCham( SWEP, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Attachments Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Attachments' ), false )
                
           if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Attachments Overlay' ] then 
                self:RenderCham( SWEP, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Attachments Overlay Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Attachments Overlay' ), false )
            end
        end
    end
    
	render.MaterialOverride( nil )
    render.SetColorModulation( 1, 1, 1 )
	render.SetBlend( 1 )
end

-- =============================================================================
-- Function to handle rendering of sprite ESP.
-- @param Ent (entity): The entity we're rendering the sprite ESP for.
-- =============================================================================
function Wallhack:SpriteBall( Ent )
    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ball Halo' ] then
        return
    end 

    render.SetMaterial( self.Ball )

	render.DrawQuadEasy( Ent:GetPos( ) + Vector( 0, 0, 1 ), Vector( 0, 0, 1 ), 48, 48, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Ball Halo' ), ( CurTime( ) * ( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ball Rotation Speed' ] * 2 ) ) % 360 )
end

function Wallhack:HeadDot( Ent )
    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Head Dot' ] then
        return
    end 

    local Head = Hitboxes.Cache[ Ent:GetModel( ) ]

    if not istable( Head ) then 
        Records:Construct( Ent )
        return
    end

    Head = Head[ 1 ]

    if not Head then 
        return
    end

    Head = Head[ 1 ]

    if not Head then 
        return
    end

    Head = Ent:LookupBone( Head.Name )

    if not Head then 
        return
    end

    local Pos = Ent:GetBonePosition( Head )

    if not Pos then 
        return
    end

    render.SetColorMaterial( )

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Head Dot Mode' ] == 'Wireframe' then 
        render.DrawWireframeSphere( Pos, 2, 5, 5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Head Dot' ) )
    else
        render.DrawSphere( Pos, 2, 5, 5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Head Dot' ) )
    end
end

-- =============================================================================
-- Function to handle rendering of barrel ESP.
-- @param Ent (entity): The entity we're rendering the barrel ESP for.
-- =============================================================================
function Wallhack:Barrel( Ent )
    -- Same as GetEyeTrace but works for entities.
    local Hit = util.TraceLine( { 
        start = Ent:EyePos( ),
        endpos = Ent:EyePos( ) + ( Ent:EyeAngles( ):Forward( ) * 32768 ),
        filter = { Ent }
    } )

    if not Hit or not Hit.Hit then return end 


    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Barrel Laser' ] then 
        render.SetMaterial( Materials:CallCached( 'Laser' ) )
        render.DrawBeam( Hit.StartPos, Hit.HitPos, 5, 0, 0, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Barrel Laser' ) )            
    end

    render.SetColorMaterial( )

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Barrel Hit Position' ] then 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Barrel Mode' ] == 'Wireframe' then 
            render.DrawWireframeSphere( Hit.HitPos, 3, 5, 5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Barrel Hit Position' ) )
        else
            render.DrawSphere( Hit.HitPos, 3, 5, 5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Barrel Hit Position' ) )
        end
    end
end




//-/~ Main Function
function Wallhack:Wallhack( )
    -- TODO: Since cam.Start3D and cam.End3D are so unbeleviably unoptimized we should take this loop
    -- and forward it to a `master` 3D function that will have another loop with cam.Start3D and cam.End3D
    -- called outside the loop so we can have more optimized code. Look at how I use Start3D and End3D in Chams.

    -- TODO: Package all bools and colors into a single master table that is generated by a helper function (or library)
    -- which would allow it to be hella optimized even with several dozen targets on screen at once.

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Filters' ][ 'Avoid While Flashed' ] and CurTime( ) < Main.Local:GetNWFloat( 'BlindUntilTime', 0 ) then 
        return
    end

    local Targets = Main.Entities

    for i = 1, #Targets do
        local Ent = Targets[ i ] 

        if not Ent:IsPlayer( ) and not Ent:IsNPC( ) and not Ent:IsNextBot( ) then continue end

        if not self:Exclude( Ent ) or Main.Local == Ent then continue end 

        -- Positioning Information
        local EntPos = Ent:GetPos( )
        local EntAng = Ent:GetAngles( )

        local Pos = EntPos
        local Min, Max = Ent:GetCollisionBounds( )

        local PosZ = Pos + Vector( 0, 0, Max.z )

        Pos, PosZ = Pos:ToScreen( ), PosZ:ToScreen( )

        local H = Pos.y - PosZ.y
        local W = H / 2

        -- LOD
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Override LOD' ] then 
            Ent:SetLOD( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'LOD' ] )
        else
            Ent:SetLOD( -1 )
        end

        -- Box ESP
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Box' ] then 
            local Style, BoxColor = Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Box Style' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Box' )

            if Style == '3D' then 
                cam.Start3D( )
                    render.DrawWireframeBox( EntPos, EntAng, Ent:OBBMins( ), Ent:OBBMaxs( ), BoxColor, true )
                cam.End3D( )
            else 
                if Style == '2D Outlined' then     
                    surface.SetDrawColor( 0, 0, 0, 200 )
                    surface.DrawOutlinedRect( Pos.x - W / 2 - 1, Pos.y - H - 1 + 4, W + 2, H - 2 )
                end
    
                surface.SetDrawColor( BoxColor )
                surface.DrawOutlinedRect( Pos.x - W / 2, Pos.y - H + 2, W, H )

                if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Fill Box' ] then 
                    surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Fill Box' ) )
                    surface.DrawRect( ( Pos.x - W / 2 ) + 2, Pos.y - H + 4, W - 4, H - 4 )
                end
            end
        end

        -- Name ESP
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Name' ] then 
            local Name = Ent:IsPlayer( ) and Ent:Nick( ) or Ent:GetClass( )
            
            draw.SimpleText( Name, 'DebugOverlay', Pos.x, Pos.y - H - 5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Name' ), 1, 1 )
        end    

        -- Weapon ESP
        local SWEP = Ent:GetActiveWeapon( )

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Weapon' ] and not Ent:IsNextBot( ) then    
            local Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Weapon' )            
            local Text;

            if SWEP:IsValid( ) then 
                if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Weapon Style' ] == 'Smart' then 
                    Text = language.GetPhrase( SWEP:GetPrintName( ) )
                else 
                    Text = SWEP:GetClass( )
                end 
            else 
                Text = 'unarmed'
            end
            
            draw.SimpleText( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Force Uppercase' ] and string.upper( Text ) or string.lower( Text ), 'oxide_main', Pos.x, Pos.y + 8, Col, 1, 1 )
        end

        -- Health Bar ESP
        local Health, maxHealth = math.min( 100, Ent:Health( ) ), Ent:GetMaxHealth( )

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Health Bar' ] and Health != 0 then 
            local hpPos = math.min( H * Health / maxHealth, H )

            -- Get our color.
            local HealthColor;

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Override Health Bar' ] then 
                HealthColor = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Override Health Bar' )
            else 
                HealthColor = HSVToColor( math.Clamp( Health / maxHealth, 0, 1 ) * 110, 1, 1 )
            end

            -- Set our gradient if we have any.
            local Gradient = Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Health Bar Style' ]

            if Gradient != 'Regular' then 
                surface.SetMaterial( self.Gradients[ Gradient ] )
            else
                draw.NoTexture( )
            end

            surface.SetDrawColor( HealthColor )
            surface.DrawTexturedRect( Pos.x - W / 2 - 6, Pos.y - H + 2 + ( H - hpPos ), 2, hpPos )

            if Gradient != 'Regular' then 
                draw.NoTexture( ) -- Reset texture so we can draw everything else normally.
            end
        end

        -- Armor Bar ESP
        if Ent:IsPlayer( ) then 
            local Armor, maxArmor = math.min( 100, Ent:Armor( ) ), Ent:GetMaxArmor( )

            local Offset = Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Health Bar' ] and 12 or 6

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Armor Bar' ] and Armor != 0 then 
                local armorPos = math.min( H * Armor / maxArmor, H )

                -- Set our gradient if we have any.
                local Gradient = Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Armor Bar Style' ]

                if Gradient != 'Regular' then 
                    surface.SetMaterial( self.Gradients[ Gradient ] )
                else
                    draw.NoTexture( )
                end

                surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Armor Bar' ) )
                surface.DrawTexturedRect( Pos.x - W / 2 - Offset, Pos.y - H + 2 + ( H - armorPos ), 2, armorPos )

                if Gradient != 'Regular' then 
                    draw.NoTexture( ) -- Reset texture so we can draw everything else normally.
                end
            end
        end
        
        -- Tracer
        local Screen, ScreenLocal = EntPos:ToScreen( ), Main.Local:GetPos( ):ToScreen( ) 

        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Highlight Targets' ] and Ent == Aimbot.aimTarget.Ent then 
            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Aimbot' ][ 'General' ], 'Highlight Targets' ) )
            surface.DrawLine( ScreenLocal.x, ScreenLocal.y, Screen.x, Screen.y )
        elseif Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Tracers' ] then 
            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Tracers' ) )
            surface.DrawLine( ScreenLocal.x, ScreenLocal.y, Screen.x, Screen.y )
        end

        -- Hitbox 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Hitboxes' ] then 
            local Bone, BonePos, BoneAng;
            local Mins, Maxs;

            local HitboxColor = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Hitboxes' )

            cam.Start3D( )
                for k = 0, Ent:GetHitBoxGroupCount( ) - 1 do
                    for i = 0, Ent:GetHitBoxCount( k ) - 1 do
                        Bone = Ent:GetHitBoxBone( i, k )

                        if not Bone then continue end			

                        BonePos, BoneAng = Ent:GetBonePosition( Bone )

                        if not BonePos or not BoneAng then continue end 

                        Mins, Maxs = Ent:GetHitBoxBounds( i, k ) 
                        
                        render.DrawWireframeBox( BonePos, BoneAng, Mins, Maxs, HitboxColor, true )
                    end
                end
            cam.End3D( )
        end

        -- Skeleton
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Skeleton' ] then 
            -- Unfortunately cam.Start3D & End3D are super expensive and we can't render surface in those.
            
            -- The only way to combine hitboxes and skeleton would be ugly if statements and it would be much more unoptimized
            -- than doing it this way.
            
            local Parent, ParentPos, BonePos;
            local ScreenParent, ScreenBone;

            local SkeletonColor = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Skeleton' ) 

            for i = 0, Ent:GetBoneCount( ) do
                Parent  = Ent:GetBoneParent( i )

                if not Parent then continue end 

                BonePos   = Ent:GetBonePosition( i )
                ParentPos = Ent:GetBonePosition( Parent )

                if not BonePos or not ParentPos then continue end 

                if BonePos == EntPos then continue end 

                ScreenParent, ScreenBone = ParentPos:ToScreen( ), BonePos:ToScreen( )

                surface.SetDrawColor( SkeletonColor )
                surface.DrawLine( ScreenParent.x, ScreenParent.y, ScreenBone.x, ScreenBone.y )
            end
        end

        -- Glow 
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Glow (!)' ] then 
            local Ents = { Ent }
            local GlowColor =  Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Glow (!)' ) 
            
            if not Ent:IsNextBot( ) and Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Include Weapon' ] then
                Ents = { Ent, Ent:GetActiveWeapon( ) }
            end 
            
            halo.Add( Ents, GlowColor, 1, 1, Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Passes' ], not (  Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Force Bloom' ] ), not ( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Only Visible' ] ) )
        end

        -- DLight
        local DLight = DynamicLight( Ent:EntIndex( ), Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Light Mode' ] == 'ELight' )
        DLight.pos = EntPos
		DLight.brightness = 2
		DLight.decay = 1000

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Light' ] then 
            local DLightColor = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Light' ) 

        	DLight.size = ( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'DLight Size' ] / 100 ) * 1024
		    DLight.dietime = CurTime( ) + 1
    		DLight.r = DLightColor.r
            DLight.g = DLightColor.g
            DLight.b = DLightColor.b
        else
            DLight.dietime = 0
            DLight.size = 0
        end

        -- Ring
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ring' ] then 
            effects.BeamRingPoint( EntPos, .1, Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ring Start Radius' ], Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ring End Radius' ], 1, Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Ring Noise' ] / 100, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Ring' ) )
        end

        -- Trail
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Trail' ] then 
            Overlay:Sprite( EntPos, 12, Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Trail Height' ], Materials:CallCached( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Trail Material' ] ), Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Trail Time' ] / 1000, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Trail' ) )
        end 

        -- Flags
        if Ent:IsPlayer( ) then 
            local Flags, Text = 10, ''
            local TW, TH = 0, 0

            surface.SetFont( 'DebugOverlay' )

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Blacklist Flag' ] and Playerlist:IsBlacklisted( Ent ) then 
                Text = 'blacklist'

                TW, TH = surface.GetTextSize( Text )

                draw.SimpleText( Text, 'DebugOverlay', Pos.x + ( W / 2 ) + ( TW / 2 ), Pos.y - H + Flags, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Blacklist Flag' ), 1, 1 )

                Flags = Flags + 10 
            end


            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Reloading Flag' ] and SWEP:IsValid( ) and SWEP:GetActivity( ) == ACT_RELOAD then 
                Text = 'reload'

                TW, TH = surface.GetTextSize( Text )

                draw.SimpleText( Text, 'DebugOverlay', Pos.x + ( W / 2 ) + ( TW / 2 ), Pos.y - H + Flags, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Reloading Flag' ), 1, 1 )

                Flags = Flags + 10 
            end

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Health Flag' ] then 
                Text = Ent:Health( ) .. 'hp'

                TW, TH = surface.GetTextSize( Text )

                draw.SimpleText( Text, 'DebugOverlay', Pos.x + ( W / 2 ) + ( TW / 2 ), Pos.y - H + Flags, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Health Flag' ), 1, 1 )

                Flags = Flags + 10 
            end

            if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Armor Flag' ] then 
                Text = Ent:Armor( ) .. 'ar'

                TW, TH = surface.GetTextSize( Text )

                draw.SimpleText( Text, 'DebugOverlay', Pos.x + ( W / 2 ) + ( TW / 2 ), Pos.y - H + Flags, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Armor Flag' ), 1, 1 )

                Flags = Flags + 10 
            end
        end
    end
end

//-/~ Footstep Manipulation
function Wallhack.FootstepManipulation( Ent, Pos, Foot, Sound, Volume )
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ][ 'Visualize Footsteps' ] and Ent != Main.Local then
        effects.BeamRingPoint( Pos, 1, 70, 200, 2, .5, Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'ESP' ], 'Visualize Footsteps' ) )
    end 

    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Footstep Manipulation' ] then return false end 

    -- Supress local footsteps.
    if Ent == Main.Local and Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Supress Local' ] then 
        return true
    end 

    -- Volume mixer.
    local Volume;

    if Ent == Main.Local then 
        Volume = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Local Volume' ]
    else 
        Volume = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Enemy Volume' ]
    end

    -- Spoof sound.
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Spoof Sound' ] then 
        Sound = Wallhack.Footstep[ Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Footstep Sound' ] ]
    end

    -- Spoof DSP.
    local DSP = 0

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Spoof DSP' ] then 
        DSP = Wallhack.DSP[ Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Footstep DSP' ] ]
    end

    -- Spoof Distance
    local Dist = 75

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Extend Range' ] then 
        Dist = 511
    end 

    -- Emit our remade sound.
    Ent:EmitSound( Sound, Dist, 100, Volume / 100, CHAN_AUTO, SND_NOFLAGS, DSP )

    return true 
end

//-/~ Calculate View
function Wallhack.CalculateView( Ent, Origin, Angles, FOV, ZNear, ZFar )
    if _M and _M.Screenshot then return end 
    
    local View = {
        angles = Angles,
		fov = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Viewmodel Adjustments' ] and Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'FOV' ] or FOV,
        origin = Origin
	}

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Visual Recoil' ] then 
        View.angles = View.angles - Main.Local:GetViewPunchAngles( )
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Thirdperson' ] and Main:InputDown( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Thirdperson Bind' ], true ) then 
        View.drawviewer = true 

        -- Get EyePos.
        local Eye = Ent:EyePos( )

        -- Calculate base offset.
        local Pos = Eye + ( Angles:Forward( ) * -( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Max Distance' ] ) )
		Pos = Pos + ( Angles:Up( ) * Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Up Distance' ] )

        -- Calculate right offset.
        if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Right Offset' ] then 
            Pos = Pos + ( Angles:Right( ) * Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Right Offset Distance' ] )
        end
		
        if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Collision' ] then 
            local Trace = util.TraceLine( {
                start  = Eye,
                endpos = Pos,
                filter = Ent
            } )
                    
            Pos = Trace.HitPos
                    
            if Trace.Fraction < 1.0 then
                Pos = Pos + Trace.HitNormal * 5
            end
        end
			
        View.origin = Pos
    elseif Freecam.Active then 
        View.drawviewer = true 

        -- Set our cam data to the things calculated in Freecam.
        View.angles = Freecam.Angle
        View.origin = Freecam.Camera
    elseif Freelook.Active then 
        View.angles = Freelook.Angle
    end

    return View
end

//-/~ Calculate Viewmodel
function Wallhack.CalculateViewmodel( SWEP, Viewmodel, OPos, OAng, Pos, Ang )
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Viewmodel Adjustments' ] then return end

    if Weapon:GetBase( SWEP ) == 'CW 2.0' then return end  

    -- Calculate No Sway/Bob.
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'No Sway' ] then 
        Pos = OPos
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'No Bob' ] then 
        Ang = OAng
    end

    -- Enforce Gamemode View.
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Enforce Gamemode View' ] then
        -- Very useful for third party weapon packs.
        Pos, Ang = GAMEMODE:CalcViewModelView( SWEP, Viewmodel, OPos, OAng, Pos, Ang )
    end

    if not Pos or not Ang then return false end 

    -- Viewmodel offsets
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Adjust Offsets' ] then 
        Ang:RotateAroundAxis( Ang:Forward( ), Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Roll' ] )
        Ang:RotateAroundAxis( Ang:Up( ), Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Yaw' ] )

        Pos = Pos + Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Offset X' ] * Ang:Right( ) * 1
        Pos = Pos + Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Offset Y' ] * Ang:Forward( ) * 1
        Pos = Pos + Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Offset Z' ] * Ang:Up( ) * 1
    end

    return Pos, Ang  
end

//-/~ Vape Timer
function Wallhack:VapeTimer( )
    if not Progress:GetPanel( 'Vape Timer' ) then 
        Progress:New( 'Vape Timer', .34, .5, 200, 5, function( self, W, H )
            -- The outline.
            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 0, 0, W, H, 1 )

            -- The bar.
            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Vape Timer' ) )
            surface.DrawRect( 1, 1, (W-2)*self:GetFraction( ), H-2 )
        end )
    end

    Progress:SetVisible( 'Vape Timer', false )

    if not Vape:Check( ) then return end 

    Progress:SetVisible( 'Vape Timer', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Vape Timer' ] )

    Progress:Update( 'Vape Timer', ( 50 - ( 50 - Vape:GetCount( ) ) ) / 50 )

end

//-/~ Shot Timer
function Wallhack:ShotTimer( )
	local SWEP = Main.Local:GetActiveWeapon( )

    if not Progress:GetPanel( 'Shot Timer' ) then 
        Progress:New( 'Shot Timer', .35, .5, 200, 5, function( self, W, H )
            -- The outline.
            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 0, 0, W, H, 1 )

            -- The bar.
            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Shot Timer' ) )
            surface.DrawRect( 1, 1, (W-2)*self:GetFraction( ), H-2 )
        end )
    end

    Progress:SetVisible( 'Shot Timer', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Shot Timer' ] )

    if not SWEP or not SWEP:IsValid( ) then return end 

    Progress:Update( 'Shot Timer', 1 - math.Clamp( SWEP:GetNextPrimaryFire( ) - Main.BulletTime, 0, 1 ) )
end

//-/~ Ammo Bar
function Wallhack:AmmoBar( )
	local SWEP = Main.Local:GetActiveWeapon( )

    if not Progress:GetPanel( 'Ammo Bar' ) then 
        Progress:New( 'Ammo Bar', .36, .5, 200, 5, function( self, W, H )
            -- The outline.
            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 0, 0, W, H, 1 )

            -- The bar.
            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Ammo Bar' ) )
            surface.DrawRect( 1, 1, (W-2)*self:GetFraction( ), H-2 )
        end )
    end

    Progress:SetVisible( 'Ammo Bar', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Ammo Bar' ] )

    if not SWEP or not SWEP:IsValid( ) then return end 

    local Clip, Max = SWEP:Clip1( ), SWEP:GetMaxClip1( )

    Progress:Update( 'Ammo Bar', Clip / Max )
end

//-/~ Projectile Trail
function Wallhack:ProjectileTrail( )
    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Projectile Trail' ] then return end
    
    local Projectiles, IgnoreZ, Col, Local = ents.FindByClass( 'crossbow_bolt' ), Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Trail Through Walls' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Projectile Trail' ), Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Trail Only Local' ]

    for i = 1, #self.Projectiles do 
        table.Merge( Projectiles, ents.FindByClass( self.Projectiles[ i ] ) )
    end

    for i = 1, #Projectiles do 
        local Proj = Projectiles[ i ]

        if Local and Proj:GetOwner( ) != Main.Local then continue end  
 
        Overlay:Box( Proj:GetPos( ), Proj:OBBMins( ), Proj:OBBMaxs( ), 3, Col, IgnoreZ  )
    end
end

//-/~ Bullet Tracers
function Wallhack:BulletTracers( Ent, Bullet )
    if Ent != Main.Local or not Bullet.Trace.Hit or not Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Bullet Tracers' ] then return end
    
    -- Trace Style.
    local Trace = Bullet.Trace

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Tracer Style' ] == 'Traced' then 
        Trace = Ent:GetEyeTrace( )
    end

    -- Color.
    local Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Bullet Tracers' )

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Override Hurt Color' ] and ( Trace.Entity:IsPlayer( ) or Trace.Entity:IsNPC( ) or Trace.Entity:IsNextBot( ) ) then 
        Col = Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Override Hurt Color' )
    end

    Overlay:Beam( Trace.StartPos, Trace.HitPos, 5, 0, 0, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Tracer Time' ] / 1000, Col, Materials:CallCached( 'Laser' ), false )
end

//-/~ Skin Changer
function Wallhack:SkinChanger( )
    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Skin Changer' ] then return end 

    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP or not SWEP:IsValid( ) then return end 

    if SWEP.SkinIndex and SWEP.Base == 'csgo_baseknife' then 
        SWEP.SkinIndex = ( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Randomize Skin' ] and math.random( 1, 12 ) or Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Skin ID' ] ) - 1
    end
end

//-/~ Flashbang Removal
function Wallhack:Flashbang( )
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Flashbangs' ] or not swcs then return end 

    local hFlashBangPlayer = NULL
    if Main.Local:GetObserverMode( ) == OBS_MODE_IN_EYE then
        local target = Main.Local:GetObserverTarget( )

        if target:IsPlayer( ) then
            hFlashBangPlayer = target
        end
    else
        hFlashBangPlayer = Main.Local
    end

    if not hFlashBangPlayer:IsValid( ) then
        return
    end

    hFlashBangPlayer:UpdateFlashBangEffect( )
    local flFlashOverlayAlpha = hFlashBangPlayer:GetNWFloat( 'FlashOverlayAlpha', 0.0 )

    if flFlashOverlayAlpha <= 0.0 then
        return
    end

    local flAlphaScale = 1.0

    local overlaycolor = Color( 255, 255, 255 )

    -- draw the screenshot overlay portion of the flashbang effect
    local pMaterial = Material( 'effects/flashbang' )
    if pMaterial then
        -- This is for handling split screen where we could potentially enter this function more than once a frame.
        -- Since this bit of code grabs both the left and right viewports of the buffer, it only needs to be done once per frame per flash.
        if ( CurTime( ) == lastTimeGrabbed ) then
            hFlashBangPlayer.m_bFlashScreenshotHasBeenGrabbed = true
        end

        if ( not hFlashBangPlayer.m_bFlashScreenshotHasBeenGrabbed ) then
            local nScreenWidth, nScreenHeight = ScrW( ), ScrH( )

            -- update m_pFlashTexture
            lastTimeGrabbed = CurTime( )

            m_pFlashTexture = GetRenderTarget( '_rt_FullFrameFB0', nScreenWidth, nScreenHeight )
            render.CopyRenderTargetToTexture( m_pFlashTexture )

            pMaterial:SetTexture( '$basetexture', m_pFlashTexture )

            hFlashBangPlayer.m_bFlashScreenshotHasBeenGrabbed = true
        end

        if m_pFlashTexture then
            overlaycolor:SetUnpacked(
                flFlashOverlayAlpha * flAlphaScale,
                flFlashOverlayAlpha * flAlphaScale,
                flFlashOverlayAlpha * flAlphaScale
            )

            pMaterial:SetFloat( '$alpha', overlaycolor.r / 255 )

            render.SetMaterial( pMaterial )
            for pass = 1, 4 do
                render.DrawScreenQuadEx( 0, 0, ScrW( ), ScrH( ) )
            end
        end
    end

    -- draw pure white overlay part of the flashbang effect.
    pMaterial = Material( 'vgui/white' )
    if pMaterial then
        overlaycolor:SetUnpacked(
            flFlashOverlayAlpha * flAlphaScale,
            flFlashOverlayAlpha * flAlphaScale,
            flFlashOverlayAlpha * flAlphaScale
        )

        pMaterial:SetFloat( '$alpha', overlaycolor.r / 255 )
        render.SetMaterial( pMaterial )
        render.DrawScreenQuadEx( 0, 0, ScrW( ), ScrH( ) )
        pMaterial:SetFloat( '$alpha', 1 )
    end
end
hook.Add( 'RenderScreenspaceEffects', 'swcs.flashbang', Wallhack.Flashbang )

//-/~ Removals
function Wallhack:Removals( )
    local Targets = ents.GetAll( )

    for i = 1, #Targets do 
        local ENT = Targets[ i ]

        if not ENT then 
            continue
        end    

        if ENT.PrintName == 'Emitter' and Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Emitters' ] then 
            ENT:SetOn( false )
            ENT:SetScale( 0 )
            ENT:SetDelay( math.huge )
        end
    
        if ENT.PrintName == 'Light' and Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Artificial Lights' ] then 
            ENT:SetOn( false )
            ENT:SetLightSize( 0 )

            -- This is a backup and will completely brick any light.
            ENT:SetLightWorld( false )
            ENT:SetLightModels( false )
        end
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Mushroom Factory Effects' ] then
        local Table = hook.GetTable( )[ 'RenderScreenspaceEffects' ]

        for k,v in pairs( Table ) do 
            if string.StartWith( k, 'MMF_GetHigh_') then 
                hook.Remove( 'RenderScreenspaceEffects', k )
            end
        end
    end

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Vape Hallucinogenic Effects' ] and _G.vapeHallucinogen and _G.vapeHallucinogen > 0 then
        _G.vapeHallucinogen = 0 -- Adjust the variable in global state.
    end 

    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Drugz Effects' ] then 
        DURGZ_LOST_VIRGINITY = false -- Don't force this to true, it lowers FPS.
        
        -- For some reason the above one is too slow.
        local Hooks = hook.GetTable( )[ 'RenderScreenspaceEffects' ]

        for k,v in pairs( Hooks ) do 
            if self.Drugs[ k ] then 
                hook.Remove( 'RenderScreenspaceEffects', k )
            end
        end
    end

    -- I couldn't get this to scale to 255 perfectly when you come in view...
    if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fade Props' ] then
        local Targets = ents.FindByClass( 'prop_*' )
        local Position = Main.Local:GetPos( )
        local FadeStart = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Fade Start' ]

        local FadeDistanceSqr = FadeStart * FadeStart

        for i = 1, #Targets do
            local Index = Targets[ i ]
            local TotalSqr = Position:DistToSqr( Index:GetPos( ) )

            if TotalSqr > FadeDistanceSqr then
                local FadeFactor = math.Clamp( 1 - ( TotalSqr - FadeDistanceSqr ) / ( 1000000 - FadeDistanceSqr ), 0, 1 )
                
                local Alpha = 255 * FadeFactor

                Index:SetColor( Color( 255, 255, 255, Alpha + 1 ) )
                Index:SetRenderMode( RENDERMODE_TRANSCOLOR )
            end
        end
    end
end

//-/~ Crosshair
function Wallhack:Crosshair( )
    if not Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Crosshair' ] then return end

    local Angles, Shoot = Main.Local:EyeAngles( ), Main.Local:GetShootPos( )

    -- Get our constant distance
    local Distance = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Trace Distance' ]

    -- Calculate Traces
    local Trace  = util.QuickTrace( Shoot, Angles:Forward( ) * Distance, Main.Local )
    local Screen = Trace.HitPos:ToScreen( )

    -- Constants
    local Size;

    -- Recoil
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil' ] then 
        local Recoil;
        
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Direct' ] == 'Up' then
            Recoil = util.QuickTrace( Shoot, ( Angles + ( Main.Local:GetViewPunchAngles( ) * Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Multiplication' ] ) ):Forward( ) * Distance, Main.Local ).HitPos:ToScreen( )
        else
            Recoil = util.QuickTrace( Shoot, ( Angles - ( Main.Local:GetViewPunchAngles( ) * Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Multiplication' ] ) ):Forward( ) * Distance, Main.Local ).HitPos:ToScreen( )
        end 

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Recoil' ) )
        surface.DrawLine( Screen.x + 1, Screen.y + 1, Recoil.x, Recoil.y )
  
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Dot' ] and Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Dot Delta' ] < math.floor( Screen.x - Recoil.x ) then 
            Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Recoil Dot Size' ]

            surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Recoil Dot' ) )
            surface.DrawRect( Recoil.x, Recoil.y, Size, Size )
        end
    end

    -- Dot
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Dot' ] then 
        Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Dot Size' ]

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Dot' ) )
        surface.DrawRect( Screen.x, Screen.y, Size, Size )
    end
    
    -- Left
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Left' ] then 
        Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Left Size' ]

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Left' ) )
        surface.DrawRect( Screen.x - Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Left Distance' ], Screen.y, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Left Length' ], Size )
    end

    -- Right
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Right' ] then 
        Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Right Size' ]

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Right' ) )
        surface.DrawRect( Screen.x + Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Right Distance' ], Screen.y, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Right Length' ], Size )
    end

    -- Bottom
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Bottom' ] then 
        Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Bottom Size' ]

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Bottom' ) )
        surface.DrawRect( Screen.x, Screen.y + Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Bottom Distance' ], Size, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Bottom Length' ] )
    end

    -- Top
    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Top' ] then 
        Size = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Top Size' ]

        surface.SetDrawColor( Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ], 'Top' ) )
        surface.DrawRect( Screen.x, Screen.y - Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Top Distance' ], Size, Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Top Length' ] )
    end
end