/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Meth
Meth = { }

if zmlab2 then 
    //-/~ Filter
    net.Receive( 'zmlab2_Filter_MiniGame', function( Length )
        zclib.Debug_Net( 'zmlab2_Filter_MiniGame', Length )

        Main.Local.zmlab2_Filter = net.ReadEntity( )

        if IsValid( zmlab2_Filter_MiniGame_panel ) then
            zmlab2_Filter_MiniGame_panel:Remove( )
        end

        if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Meth' ] then 
            timer.Simple( 0.5, function( )
                net.Start( 'zmlab2_Filter_MiniGame' )
                    net.WriteEntity( Main.Local.zmlab2_Filter )
                    net.WriteBool( true )
                net.SendToServer( )
            end )
            
            return 
        end

        if vgui.Exists( 'methgametest' ) then -- Low Sodium
            zmlab2_Filter_MiniGame_panel = vgui.Create( 'methgametest' )
            zmlab2_Filter_MiniGame_panel.End = function( this, result )
                net.Start( 'zmlab2_Filter_MiniGame' )
                    net.WriteEntity( Main.Local.zmlab2_Filter )
                    net.WriteBool( result )
                net.SendToServer( )
            end

            return
        end

        zmlab2_Filter_MiniGame_panel = vgui.Create( 'zmlab2_vgui_Filter_MiniGame' )
    end )

    //-/~ Main
    net.Receive( 'zmlab2_MiniGame', function( Length )
        zclib.Debug_Net( 'zmlab2_MiniGame', Length )

        Main.Local.zmlab2_MiniGame_Ent = net.ReadEntity( )
        Main.Local.zmlab2_MiniGame_Time = net.ReadUInt( 16 )

        if IsValid( zmlab2_MiniGame_main_panel ) then
            zmlab2_MiniGame_main_panel:Remove( )
        end

        if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Meth' ] then 
            timer.Simple( 0.5, function( )
                net.Start( 'zmlab2_MiniGame' )
                    net.WriteEntity( Main.Local.zmlab2_MiniGame_Ent )
                    net.WriteBool( true )
                net.SendToServer( )
            end )
            
            return 
        end

        if vgui.Exists( 'methgametest' ) then -- Low Sodium
            zmlab2_MiniGame_main_panel = vgui.Create( 'methgametest' )
            zmlab2_MiniGame_main_panel.End = function( this, result )
                net.Start( 'zmlab2_MiniGame' )
                    net.WriteEntity( Main.Local.zmlab2_MiniGame_Ent )
                    net.WriteBool( result )
                net.SendToServer( )
            end

            return
        end

        zmlab2_MiniGame_main_panel = vgui.Create( 'zmlab2_vgui_MiniGame' )
    end )

    //-/~ Mixer
    net.Receive( 'zmlab2_Mixer_MiniGame', function( Length )
        zclib.Debug_Net( 'zmlab2_Mixer_MiniGame', Length )

        Main.Local.zmlab2_Mixer = net.ReadEntity( )

        if IsValid( zmlab2_Mixer_MiniGame_panel ) then
            zmlab2_Mixer_MiniGame_panel:Remove( )
        end

        if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Meth' ] then 
            timer.Simple( 0.5, function( )
                net.Start( 'zmlab2_Mixer_MiniGame' )
                    net.WriteEntity( Main.Local.zmlab2_Mixer )
                    net.WriteBool( true )
                net.SendToServer()
            end )
            
            return 
        end

        zmlab2_Mixer_MiniGame_panel = vgui.Create( 'zmlab2_vgui_Mixer_MiniGame' )
    end )
end