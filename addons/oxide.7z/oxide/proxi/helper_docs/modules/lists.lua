/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Lists = { 
    Base = { },
    Target = NULL,
    Last = 0
}

//-/~ Generate Base
function Lists:GenerateBase( Panel )
    -- Add AvatarImage
    local Avatar = vgui.Create( 'AvatarImage', Panel )
	Avatar:SetSize( 16, 16 )
	Avatar:SetPlayer( NULL, 16 )
    Avatar:DockMargin( Main.Scale( 8 ), Main.Scale( 2 ), 0, 0 )
    Avatar:Dock( LEFT )

    -- Add DLabel
    local DLabel = vgui.Create( 'DLabel', Panel )
    DLabel:DockMargin( 0, 0, Main.Scale( 8 ), 0 )
    DLabel:Dock( LEFT )
    DLabel:SetFont( 'oxide.16' )
    DLabel:SetText( 'Unknown' )

    -- Set
    Lists.Base.Avatar = Avatar
    Lists.Base.Label  = DLabel
end

//-/~ Notifications
function Lists:Notifications( )
    return Notifications:Update( )
end

//-/~ Calculate Lists
function Lists:CalculateLists( )
    -- This calculates stuff for spectator list, aimbot information, admin list, etc.
    local Targets, Count = Main.Players, 0

    Dragable:ClearLabels( 'Spectators' )
    Dragable:ClearLabels( 'Admins' )

    for i = 1, #Targets do 
        local Ent = Targets[ i ]

        if not Ent then continue end
    
        -- Emplace spectators.
        if Ent:GetObserverTarget( ) == Main.Local then 
            local Mode = Ent:GetObserverMode( )

            if Mode == OBS_MODE_NONE then 
                Mode = 'UN' -- Unknown
            elseif Mode == OBS_MODE_IN_EYE then 
                Mode = 'FP' -- First Person
            elseif Mode == OBS_MODE_CHASE then
                Mode = 'TP' -- Third Person
            elseif Mode == OBS_MODE_ROAMING	 then 
                Mode = 'FR' -- Free Roam
            end

            Dragable:AddIndex( 'Spectators', Ent:Nick( ) .. ' [' .. Mode .. ']' )

            Count = Count + 1
        end

        -- Emplace Admins
        if Ent:IsAdmin( ) then 
            local Type = Ent:IsSuperAdmin( ) and 'SA' or 'A' 

            Dragable:AddIndex( 'Admins',  Ent:Nick( ) .. ' [' .. Type .. ']' )
        end
    end
    
    -- Setup Aimbot Objects
    local Object = Dragable:GrabCache( 'Aimbot' )

    Object.DFrame:SetSize( 120, 75 )
    
    if not self.Base.Avatar or not self.Base.Label then 
        Lists:GenerateBase( Object.DPanelMain )
    end

    -- Aimbot Stuff.
    local Target, Name = Aimbot.aimTarget, ''

    if Target != self.Target then
        if Target != NULL then
            Target = Target.Ent

            if Target:IsPlayer( ) then 
                Name = Target:Nick( )
            else
                Name = language.GetPhrase( Target:GetClass( ) )
            end
        end

        self.Base.Avatar:SetPlayer( Target, 16 )
        self.Base.Label:SetText( Target == NULL and 'Unknown' or Name )
    end 

    -- Handle Notifications
    Lists:Notifications( )

    -- Visibility
    Dragable:SetVisible( 'Spectators', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Spectator List' ] )
    Dragable:SetVisible( 'Admins', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Admin List' ]  )
    Dragable:SetVisible( 'Aimbot', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Aimbot Information' ]  )
    Dragable:SetVisible( 'Notifications', Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notifications' ]  )

    if self.Last < Count then 
        surface.PlaySound( 'vo/canals/boxcar_becareful_b.wav' )
        
        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Spectator' ] then 
            Notifications:Notify( color_white, 'An admin has started spectating you!\n' )
        end
    elseif self.Last != 0 and Count == 0 then 
        surface.PlaySound( 'bot/clear3.wav' )

        if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Other' ][ 'Notify Spectator' ] then 
            Notifications:Notify( color_white, 'An admin has stopped spectating you!\n' )
        end
    end

    self.Last  = Count
    self.Target = Target
end

//-/~ Add Dragables
function Lists:AddDragables( )
    Dragable:NewDragable( 'Spectators' )
    Dragable:NewDragable( 'Admins', 30 )
    Dragable:NewDragable( 'Aimbot', 60 )

    Dragable:NewDragable( 'Notifications', 120 )
end

Lists:AddDragables( )