/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Viewmodel
Viewmodel = { 
    Bottom = false,
    Overlay = false
}

//-/~ Handle Logic
function Viewmodel:HandleLogic( )
    if self.Bottom and Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel' ] then
        local Name, Color = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Viewmodel' )

        render.MaterialOverride( Materials:CallCached( Name ) ) -- Use our cached material.
        render.SetColorModulation( Color.r / 255, Color.g / 255, Color.b / 255 )
        render.SetBlend( Color.a / 255 )
    elseif self.Overlay and Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel Overlay' ] then 
        local Name, Color = Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel Overlay Material' ], Main.GetColor( Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ], 'Viewmodel Overlay' )

        render.MaterialOverride( Materials:CallCached( Name ) ) -- Use our cached material.
        render.SetColorModulation( Color.r / 255, Color.g / 255, Color.b / 255 ) -- TODO: Make a library for this so I don't have to use these ugly ass /255
        render.SetBlend( Color.a / 255 )
    end
end

//-/~ Handle Drawing
function Viewmodel:HandleDrawing( )
    render.SetColorModulation( 1, 1, 1 )
	render.MaterialOverride( nil ) 
	render.SetBlend( 1 )

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel' ] and not self.Bottom then 
        self.Bottom = true
            Main.Local:GetViewModel( ):DrawModel( )
        self.Bottom = false
    end

    if Main.Elements[ 'Visuals' ][ 'Players' ][ 'Chams' ][ 'Viewmodel Overlay' ] and not self.Overlay then 
        self.Overlay = true
            Main.Local:GetViewModel( ):DrawModel( )
        self.Overlay = false
    end
    
    Main.Local:GetHands( ):DrawModel( ) -- Draw this shit on top so it doesn't get vaporized.
end