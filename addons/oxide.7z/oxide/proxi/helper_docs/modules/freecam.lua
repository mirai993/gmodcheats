/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Freecam = {
    Active = false
}

//-/~ Main
function Freecam:Main( CUserCMD )
    -- This really wouldn't fit in the Wallhack file so I put it in it's own file.
    Freecam.Active = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Freecam' ] and Main:InputDown( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Freecam Bind' ], false )

    if not Freecam.Active or not Freecam.Previous then 
        Freecam.Previous = CUserCMD:GetViewAngles( )
        Freecam.Camera   = Main.Local:EyePos( ) 
        Freecam.Angle    = Freecam.Previous

        return 
    end 

    -- Get our sensitivity.
    local Sensitivity = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Sensitivity' ] / 500 -- Odd number but 100 is super fast.

    -- Calculate our angle.
    Freecam.Angle  = Freecam.Angle + Angle( CUserCMD:GetMouseY( ) * Sensitivity, CUserCMD:GetMouseX( ) * -Sensitivity, 0 ) 
    Freecam.Camera = Freecam.Camera or Main.Local:EyePos( ) 

    CUserCMD:SetViewAngles( Freecam.Previous )

    -- Clamp our angles.
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Unclamp Pitch' ] then 
        Freecam.Angle.x = math.Clamp( Freecam.Angle.x, -89, 89)
    end

    -- Calculate our speed.
    local Speed = Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Speed' ] / 2

    if CUserCMD:KeyDown( IN_SPEED ) then -- Sprinting takes prority.
        Speed = Speed * 1.5
    elseif CUserCMD:KeyDown( IN_WALK ) then  
        Speed = Speed / 3
    end

    -- Calculate our z axis.
    if CUserCMD:KeyDown( IN_JUMP ) then 
        Freecam.Camera = Freecam.Camera + Vector( 0, 0, Speed ) 
    elseif CUserCMD:KeyDown( IN_DUCK ) then 
        Freecam.Camera = Freecam.Camera - Vector( 0, 0, Speed ) 
    end

    -- Calculate our relative position.
    if CUserCMD:KeyDown( IN_FORWARD ) then 
		Freecam.Camera = Freecam.Camera + ( Freecam.Angle:Forward() * Speed )
    elseif CUserCMD:KeyDown( IN_BACK ) then 
		Freecam.Camera = Freecam.Camera - ( Freecam.Angle:Forward() * Speed )
    end

    if CUserCMD:KeyDown( IN_MOVERIGHT ) then 
		Freecam.Camera = Freecam.Camera + ( Freecam.Angle:Right() * Speed )
    elseif CUserCMD:KeyDown( IN_MOVELEFT ) then 
		Freecam.Camera = Freecam.Camera - ( Freecam.Angle:Right() * Speed )
    end

    -- Strip our movement variables
    CUserCMD:RemoveKey(IN_FORWARD)
	CUserCMD:RemoveKey(IN_BACK)
	CUserCMD:RemoveKey(IN_MOVELEFT)
	CUserCMD:RemoveKey(IN_MOVERIGHT)
				
	CUserCMD:RemoveKey(IN_JUMP)
	CUserCMD:RemoveKey(IN_DUCK)

    CUserCMD:ClearMovement( )

    -- Strip these as well, maybe we'll make a flag system to add to the Entity list later.
	CUserCMD:RemoveKey(IN_ATTACK)
	CUserCMD:RemoveKey(IN_ATTACK2)
end

//-/~ Table
Freelook = { -- Better structure if we do it this way.
    Active = false
}

//-/~ Main
function Freelook:Main( CUserCMD )
    Freelook.Active =  Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Freelook' ] and Main:InputDown( Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Freelook Bind' ], false )

    if not Freelook.Active then 
        Freelook.Angle    = CUserCMD:GetViewAngles( )
        Freelook.Previous = CUserCMD:GetViewAngles( )
        return
    end

    Freelook.Angle = Freelook.Angle + Angle( CUserCMD:GetMouseY( ) * 0.02, CUserCMD:GetMouseX( ) * -0.02, 0 ) 
    
    CUserCMD:SetViewAngles( Freelook.Previous )
        
    Freelook.Angle.x = math.Clamp( Freelook.Angle.x, -89, 89)
end