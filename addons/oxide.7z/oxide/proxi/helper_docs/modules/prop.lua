/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Props
Props = { 
    [ 'List' ] = { },
    [ 'Random Props' ] = {
        'models/props_c17/gate_door02a.mdl',
        'models/props_c17/door01_left.mdl',
        'models/props_junk/PropaneCanister001a.mdl',
        'models/props_phx/empty_barrel.mdl',
        'models/props_phx/ball.mdl',
        'models/props_phx/huge/evildisc_corp.mdl',
        'models/props_phx/huge/tower.mdl',
        'models/props_phx/wheels/wooden_wheel1.mdl'
    }
}

//-/~ Bypass Button
function Props:Bypass( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Spawn Bypass' ] then
        return
    end
    
    proxi.SendConsoleCommand( 'gm_spawn ' .. string.Replace( Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Spawn Bypass Prop' ], '/', '\\' ) )
end

//-/~ Auto Toolgun
function Props:Toolgun( CUserCMD )
    if not Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Auto Toolgun' ] then
        return
    end
    
    if Aimbot.aimTarget != NULL or not Main.Local:HasWeapon( 'gmod_tool' ) then
        return
    end

    -- Weapon Check.
    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP:IsValid( ) then return end 

    if SWEP:GetClass( ) != 'gmod_tool' then
        if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Auto Equip' ] then
            CUserCMD:SelectWeapon( Main.Local:GetWeapon( 'gmod_tool' ) )
        end

        return
    end

    local Targets, Mode = ents.FindInSphere( Main.Local:GetPos( ), Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Toolgun Distance' ] ), Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Toolgun Mode' ]
    
    -- Rapidfire.
    if Main.Local:KeyDown( IN_ATTACK ) and #Targets > 0 then
        CUserCMD:RemoveKey( IN_ATTACK )
        return
    end

    -- Loop targets.
    for i = 1, #Targets do
        local Index = Targets[ i ]

        if not string.StartWith( Index:GetClass( ), 'prop_' ) then
            continue
        end

        if self.List[ Index ] and Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Wait For Invalidation' ] then
            continue
        end

        local Calculated = ( Index:LocalToWorld( Index:OBBCenter() ) - Main.Local:EyePos( ) ):Angle( )
        local EnginePrediction = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

        if EnginePrediction then 
            proxi.StartPrediction( CUserCMD )
        end 

        if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Toolgun Silent' ] then 
            if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Toolgun Silent Mode' ] == 'Serverside' then 
                proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

                proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, Calculated:Forward( ) )
            else 
                CUserCMD:SetViewAngles( Calculated )
            end
        else 
            proxi.SetViewAngles( Calculated )
        end

        if EnginePrediction then 
            proxi.EndPrediction( )
        end 

        CUserCMD:AddKey( IN_ATTACK )

        self.List[ Index ] = Index
        
        timer.Simple( Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Invalidation Time' ], function( )
            if self.List[ Index ] != NULL then
                self.List[ Index ] = nil -- Invalidation, try again.
            end
        end )

        break
    end

    -- Clean List
    self.List = table.RemoveByValueAll( self.List, NULL )

    -- Select mode.
    RunConsoleCommand( 'gmod_toolmode', string.lower( Mode ) )
end

//-/~ Properties Aura
function Props:Properties( CUserCMD )
    local Mode = Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Mode' ]

    if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Beam' ] then 
        if Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Beam Bind' ], false ) then 
            local Index = Main.Local:GetEyeTrace( ).Entity

            if Mode == 'Removal' then
                net.Start( 'properties' )
                    net.WriteString( 'remove' )
                    net.WriteEntity( Index )
                net.SendToServer( )
            elseif Mode == 'Disintegrate' then
                net.Start( 'properties' )
                    net.WriteString( 'rb655_dissolve' )
                    net.WriteEntity( Index )
                net.SendToServer( )
            elseif Mode == 'Ignite' then
                net.Start( 'properties' )
                    net.WriteString( 'ignite' )
                    net.WriteEntity( Index )
                net.SendToServer( )
            end
        end
    end

    if not Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Aura' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Aura Bind' ], true ) then return end 

    local Targets = ents.FindInSphere( Main.Local:GetPos( ), Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Properties Distance' ] )

    for i = 1, #Targets do
        local Index = Targets[ i ]

        if not string.StartWith( Index:GetClass( ), 'prop_' ) then
            continue
        end

        if Mode == 'Removal' then
            net.Start( 'properties' )
                net.WriteString( 'remove' )
                net.WriteEntity( Index )
            net.SendToServer( )
        elseif Mode == 'Disintegrate' then
            net.Start( 'properties' )
                net.WriteString( 'rb655_dissolve' )
                net.WriteEntity( Index )
            net.SendToServer( )
        elseif Mode == 'Ignite' then
            net.Start( 'properties' )
                net.WriteString( 'ignite' )
                net.WriteEntity( Index )
            net.SendToServer( )
        end
    end
end

//-/~ Prop Spawner
function Props:Spawn(  )
    if not Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Spawn Props' ] then return end

    local Random, Bypass = Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Use Random Props' ], Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Use Bypass' ] 

    for i = 1, Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Quantity' ] do
        local Prop = Random and self[ 'Random Props' ][ math.random( #self[ 'Random Props' ] ) ] or Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Spawn Props Prop' ]

        timer.Simple( ( .05 + i ) / 1000, function( )
            proxi.SendConsoleCommand( 'gm_spawn ' .. ( Bypass and string.Replace( Prop, '/', '\\' ) or Prop ) )
        end )
    end
end