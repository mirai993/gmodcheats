/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Chat
Chat = { }

//-/~ Direct Messages
function Chat:DirectMessage( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Direct Message Spammer' ] then return end

    local Mode, Text = Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Direct Message Mode' ], Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Direct Message Text' ]

    -- Get Target.
    local Target = player.GetAll( )

    table.RemoveByValue( Target, Main.Local )

    Target = Target[ math.random( #Target ) ]

    -- Run Command.
    if Mode == 'ULX' and ULib then
        RunConsoleCommand( 'ulx', 'psay', Target:Nick( ), Text )
    elseif Mode == 'SAM' and sam then
        RunConsoleCommand( 'sam', 'pm', Target:Nick( ), Text )
    else
        Main.Local:ConCommand( 'say /pm ' .. Target:Nick( ) .. ' ' .. Text )
    end
end