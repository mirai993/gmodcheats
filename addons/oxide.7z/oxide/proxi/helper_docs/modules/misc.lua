/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Misc
Misc = { 
    ConVar = GetConVar( 'host_framerate' ),

    Flip = false,
    Seed = 0
}

//-/~ Server Error Spammer
function Misc:ServerErrors( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Console Breaker' ] then return end

    proxi.SendLuaError( string.rep( '\n', 110 ) )
end

//-/~ Dragon Fire
function Misc:DragonFire( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Vape Fire Aura' ] then return end

    -- Check SWEP.
    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP:IsValid( ) or SWEP:GetClass( ) != 'weapon_vape_dragon' then return end

    -- Check net message.
    if util.NetworkStringToID( 'DragonVapeIgnite' ) == 0 then return end

    -- Loop targets.
    local Targets = ents.FindInSphere( Main.Local:GetPos( ), Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Vape Fire Distance' ] )

    for i = 1, #Targets do
        local Index = Targets[ i ]

        if not Index or Index == Main.Local then 
            continue
        end

        net.Start( 'DragonVapeIgnite' )
            net.WriteEntity( Index )
        net.SendToServer( )
    end
end

//-/~ Airstuck
function Misc:Airstuck( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Airstuck' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Airstuck Bind' ], true ) then return end 

    proxi.SetSequenceNumber( proxi.GetSequenceNumber( ) + ( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Airstuck Strength' ] * 10 ) )
end

//-/~ Slowmo
function Misc:Slowmo( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Slowmo' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Slowmo Bind' ], true ) then return end 

    proxi._R.ConVar.SetFlags( self.ConVar, FCVAR_NONE )

    proxi._R.ConVar.ForceFloat( self.ConVar, Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Slowmo Strength' ] / 10000 )
end

//-/~ Asay
function Misc:Asay( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'ULX Asay Clear' ] or not ULib then return end

    RunConsoleCommand( 'ulx', 'asay', '/me', string.rep( '\n', 350 ) )
end

//-/~ Force Escape
function Misc:ForceEscape( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Force Escape' ] then return end
 
    local Mode = Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Force Escape Mode' ]

    if Mode == 'Game UI' then
        gui.ActivateGameUI( )
    elseif Mode == 'Console' then
        proxi.RunOnMenu( 'gui.ShowConsole( )' )
    elseif Mode == 'Premissions' and not permissions.IsGranted( 'voicerecord' ) then
        permissions.EnableVoiceChat( true )
    end
end

//-/~ Cleanup Death
function Misc:CleanupDeath( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Cleanup Death' ] then return end

    local Prefix = Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Cleanup Death Mode' ]

    if Prefix == 'Props' then
        Prefix = 'props'
    elseif Prefix == 'Entities' then
        Prefix = 'sents'
    else
        Prefix = ''
    end

    Main.Local:ConCommand( 'gmod_cleanup ' .. Prefix )
end

//-/~ Cleanup Spawn
function Misc:CleanupSpawn( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Cleanup Spawn' ] then return end

    local Prefix = Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Cleanup Spawn Mode' ]

    if Prefix == 'Props' then
        Prefix = 'props'
    elseif Prefix == 'Entities' then
        Prefix = 'sents'
    else
        Prefix = ''
    end

    Main.Local:ConCommand( 'gmod_cleanup ' .. Prefix )
end

//-/~ Ragdoll Crasher
function Misc:RagdollCrasher( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'ULX Ragdoll Crasher' ] or not ULib then 
        hook.Remove( 'HUDShouldDraw', 'Lag' )
        return 
    end

    if self.Flip then 
        RunConsoleCommand("ulx", "ragdoll", "^" ) 
    else 
        RunConsoleCommand("ulx", "unragdoll", "^" ) 
    end 
    
    self.Flip = not self.Flip 

    hook.Add( 'HUDShouldDraw', 'Lag', function( ... ) return false end )
end

//-/~ Console Spam
function Misc:ConsoleSpam( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Console Spam' ] then return end

    local Text, Mode = Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Console Spam Text' ], Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Console Spam Mode' ]

    Text = string.Replace( Text, '\\n', '\n' )
    Text = string.Replace( Text, '\\r', '\r' )
    Text = string.Replace( Text, '\\v', '\v' )

    if Mode == 'Console Command' then 
        Main.Local:ConCommand( Text ) -- So we don't have to pack it into a vararg.
    elseif Mode == 'Send Command' then 
        proxi.SendConsoleCommand( Text )
    else
        local Pack = string.Split( Text, ' ' )

        if #Pack == 0 then 
            return
        end

        RunConsoleCommand( Pack[ 1 ], unpack( Pack, 2 ) )
    end
end

//-/~ Flashlight Spammer
function Misc:FlashlightSpammer( CUserCMD )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Flashlight Spam' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Flashlight Spam Bind' ], true ) then return end 

    CUserCMD:SetImpulse( 100 )
end

//-/~ Delete all seeds
function Misc:SeedDelete( )
    if not zwf then return end

    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Delete All Seeds' ] then return end
    
    for i = 1, zwf.config.SeedBank.Limit do
        timer.Simple( i * .5, function( )
            net.Start("zwf_DeleteSeed")
                net.WriteEntity( Main.Local.zwf_SeedBank )
                net.WriteInt( 1, 16 ) -- Delete one so it doesn't desync
            net.SendToServer()
        end )
	end
end

//-/~ Auto Inventory
function Misc:AutoInventory( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Inventory' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Inventory Bind' ], false ) then return end 

    RunConsoleCommand( 'say', '/invholster' )
end

//-/~ Auto Seed
function Misc:AutoSeed( CUserCMD )
    if not zwf then return end

    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Seed' ] then return end

    if not Main:InputDown( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Seed Bind' ], true ) then return end 

    if self.Seed >= CurTime( ) or Aimbot.aimTarget != NULL then return end

    if CUserCMD:KeyDown( IN_USE ) then 
        CUserCMD:RemoveKey( IN_USE )
        return
    end

    local Targets = ents.FindByClass( 'zwf_pot_hydro' )

    for i = 1, #Targets do 
        local Index = Targets[ i ]

        if not Index.HasPlagueEffect and not Index:GetHarvestReady( ) then
            continue
        end

        -- Valid context.
        local Calculated = ( Index:LocalToWorld( Index:OBBCenter() ) - Main.Local:EyePos( ) ):Angle( )
        local EnginePrediction = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

        if EnginePrediction then 
            proxi.StartPrediction( CUserCMD )
        end 

        if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Silent' ] then 
            if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Silent Mode' ] == 'Serverside' then 
                proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

                proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, Calculated:Forward( ) )
            else 
                CUserCMD:SetViewAngles( Calculated )
            end
        else 
            proxi.SetViewAngles( Calculated )
        end

        if EnginePrediction then 
            proxi.EndPrediction( )
        end 

        -- Force use.
        CUserCMD:AddKey( IN_USE )

        self.Seed = self.Seed + ( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Hold Time' ] / 1000 )
    end
end

//-/~ Direct Messages
local Text = { }

net.Receive( 'tsayc', function( )
    -- https://github.com/TeamUlysses/ulib/blob/6b26feb0e22eeddb1d7530c4a3e6e864da4dab04/lua/ulib/shared/messages.lua#L131
    local Last, Size = net.ReadBool( ), net.ReadInt( 8 )
    
    for i = 1, Size do
        if net.ReadBool( ) then
            table.insert( Text, net.ReadString( ) )
        else
            table.insert( Text, net.ReadColor( ) )
        end
    end

    if Last then
        if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Direct Messages' ] then
            chat.AddText( unpack( Text ) )
            Text = { }
            return
        end

        if Text[ 2 ] and Text[ 4 ] and Text[ 8 ] then
            if Text[ 2 ] != 'You' and Text[ 4 ] == ' to ' then 
                Text = { }
                return
            end
        end

        chat.AddText( unpack( Text ) )
		Text = { }
	end
end )

//-/~ Vape Removal
net.Receive( 'VapeTalking', function( )
	if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Vape Talking' ] then 
        return
    end

    local ENT = net.ReadEntity( )

	if IsValid( ENT ) then 
        ENT.vapeTalkingEndtime = net.ReadFloat( ) 
    end
end )

//-/~ Discord Relay
function Misc:OverrideRelay( )
    if Discord and Discord.Chat then 
        function Discord:Chat(...)
            if Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove Discord Relay' ] then
                return
            end

            chat.AddText( Color( 114, 137, 255 ), '[Discord] ', Color( 255, 255, 255 ), ... )
        end
    end
end

//-/~ Clear Chat
function Misc:ClearChat( ENT )
    if Playerlist.Chat[ ENT ] then return end 
    
    if not Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Auto Clear Chat' ] then return end

    local Text = Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Clear Chat Mode' ]

    if Text == 'Carriage Return' then
        Text = '\r'
    elseif Text == 'Newline' then
        Text = '\n'
    elseif Text == 'Vertical Tab' then
        Text = '\v'
    end

    local Prefix = Main.Elements[ 'Miscellaneous' ][ 'Chat' ][ 'Use OOC' ] and '// .' or '.'

    proxi.SendConsoleCommand('say ' .. Prefix .. string.rep( Text, 400 ) )
end

//-/~ Remove SWCS Prediction Errors
function Misc:SWCSFix( )
    if not Main.Elements[ 'Visuals' ][ 'World' ][ 'World' ][ 'Remove SWCS Prediction Errors' ] then return end

    hook.Remove( 'PlayerTick', 'swcs.ProcessActivities' )
end

//-/~ Auto Revolver
function Misc:AutoRevolver( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Auto Revolver' ] or Aimbot.aimTarget != NULL or input.IsMouseDown( MOUSE_LEFT ) then return end
    
    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP or not SWEP:IsValid( ) or SWEP:GetClass( ) != 'weapon_swcs_revolver' then return end 

    -- Calculate
    local Time = SWEP:GetPostponeFireReadyTime( )
    if Time != math.huge and Time + 8.5 >= CurTime( ) then 
        CUserCMD:RemoveKey( IN_ATTACK )
        CUserCMD:AddKey( IN_ATTACK2 )
    else
        CUserCMD:AddKey( IN_ATTACK )
        CUserCMD:RemoveKey( IN_ATTACK2 )
    end 
end

//-/~ Auto Reload
function Misc:AutoReload( CUserCMD )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Auto Reload' ] then return end
    
    if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Avoid While Aimbotting' ] and Aimbot.aimTarget != NULL then 
        return
    end

    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP or not SWEP:IsValid( ) then return end 

    local Clip, Max;

    if Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Use Secondary Clip' ] then 
        Clip = SWEP:Clip2( )
        Max  = SWEP:GetMaxClip2( )
    else
        Clip = SWEP:Clip1( )
        Max  = SWEP:GetMaxClip1( )  
    end

    if math.Limit( ( Clip * 100 ) / ( Max - 1 ), 1 ) < Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Reload Percentage' ] then 
        CUserCMD:AddKey( IN_RELOAD )
    end
end