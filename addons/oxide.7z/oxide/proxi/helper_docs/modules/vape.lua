/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Vape
Vape = { 
    Count = 0,
    Release = false
}

//-/~ Get Count
function Vape:GetCount( )
    return self.Count
end

//-/~ Check
function Vape:Check( SWEP )
    SWEP = SWEP or Main.Local:GetActiveWeapon( )

    if not SWEP or not SWEP:IsValid( ) then return false end

    if not Main.Vapes[ SWEP:GetClass( ) ] then 
        self.Count = 0
        return false
    end

    return true
end

//-/~ Timer
function Vape:Timer( )
    if not Vape:Check( ) then return end

    -- Completely rebuilt from the serverside. Should be one to one.

    self.Count = self.Count or 0

    local Key = Main.Local:KeyDown( IN_ATTACK ) 

    if Key and not self.Release then 
        if Weapon:CanAttackSimple( ) then 
            self.Count = self.Count + 1

            if self.Count >= 50 then 
                self.Count = 0

                self.Release = true
            end
        end
    else
        self.Count = 0

        self.Release = Key
    end
end

//-/~ Spam
function Vape:Spam( CUserCMD )
    if not Vape:Check( ) then return end 

    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Vape Spam' ] then return end 

    if self.Count > Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Vape Amount' ] then 
        CUserCMD:RemoveKey( IN_ATTACK )
    else
        CUserCMD:AddKey( IN_ATTACK )
    end
end