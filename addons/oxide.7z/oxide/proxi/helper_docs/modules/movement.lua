/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Movement
Movement = { }

//-/~ Bunnyhop
function Movement:Bunnyhop( CUserCMD )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Bunnyhop' ] then return end

    if CUserCMD:KeyDown( IN_JUMP ) and not Main.Local:IsOnGround( ) then
        CUserCMD:RemoveKey( IN_JUMP )
    end
end

//-/~ Fix Movement
function Movement:FixMovement( CUserCMD )
    local flYaw, flSpeed;
    local Move = Vector( CUserCMD:GetForwardMove(), CUserCMD:GetSideMove(), 0 )

    flSpeed = Move:Length2D()

    local View = CUserCMD:GetViewAngles()
    View:Normalize()
    
    flYaw = math.deg( math.atan2( Move.y, Move.x ) )
    flYaw = math.rad( View.y - Main.Local:EyeAngles().y + flYaw )

    CUserCMD:SetForwardMove( math.cos( flYaw ) * flSpeed )
    CUserCMD:SetSideMove( math.sin( flYaw ) * flSpeed )

    if View.x < -90 or View.x > 90 then
        CUserCMD:SetForwardMove( -CUserCMD:GetForwardMove( ) )
        CUserCMD:SetSideMove( -CUserCMD:GetSideMove( ) )
    end

    local Valid = { 0, 2500, 5000, 7500, 10000, -2500, -5000, -7500, -10000 }    

    CUserCMD:SetForwardMove( math.RoundToClosest( CUserCMD:GetForwardMove( ), Valid ) )
    CUserCMD:SetSideMove( math.RoundToClosest( CUserCMD:GetSideMove( ), Valid ) )
end

//-/~ Autostop
function Movement:Quickstop( CUserCMD )
    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Autostop' ] and Main.Autostop then 
        local velAngle = Main.Local:GetVelocity( )

        local speed = velAngle:Length2D( )

        velAngle = velAngle:Angle( )

        velAngle.y = CUserCMD:GetViewAngles( ).y - velAngle.y

        local stop = velAngle:Forward( ) * -speed
        
        if speed > 5 then 
            CUserCMD:SetForwardMove( stop.x )
            CUserCMD:SetSideMove( stop.y )
        else 
            CUserCMD:SetForwardMove( 0 )
            CUserCMD:SetSideMove( 0 )

            Main.Autostop = false
        end
    end
end