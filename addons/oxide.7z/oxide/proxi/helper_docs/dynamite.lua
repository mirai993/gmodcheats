--- tools use internally input library
--- i dunno how to force them to press.

//-/~ Dynamite
function Misc:Dynamite( CUserCMD )
    if not Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Auto Dynamite' ] then return end

    if Aimbot.aimTarget != NULL or not Main.Local:HasWeapon( 'gmod_tool' ) then
        return
    end

    -- Weapon Check.
    local SWEP = Main.Local:GetActiveWeapon( )

    if not SWEP:IsValid( ) then return end 

    if SWEP:GetClass( ) != 'gmod_tool' then
        return CUserCMD:SelectWeapon( Main.Local:GetWeapon( 'gmod_tool' ) )
    end

    local Targets, Mode = ents.FindInSphere( Main.Local:GetPos( ), Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Dynamite Distance' ] ), Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Removal Mode' ]
    
    -- Removals
    if Main.Local:GetCount( 'dynamite' ) > 0 then 
        RunConsoleCommand( 'gmod_cleanup', 'dynamite' )

        return 
    end

    -- Rapidfire.
    if Main.Local:KeyDown( IN_ATTACK ) and #Targets > 0 then
        CUserCMD:RemoveKey( IN_ATTACK )
        
        return
    end

    -- Loop targets.
    for i = 1, #Targets do
        local Index = Targets[ i ]
        
        if not Index:IsPlayer( ) or Index == Main.Local then
            continue
        end

        local Calculated = ( Index:GetPos( ) - Main.Local:EyePos( ) ):Angle( )
        local EnginePrediction = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

        if EnginePrediction then 
            proxi.StartPrediction( CUserCMD )
        end 

        if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Dynamite Silent' ] then 
            if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Dynamite Silent Mode' ] == 'Serverside' then 
                proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

                proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, Calculated:Forward( ) )
            else 
                CUserCMD:SetViewAngles( Calculated )
            end
        else 
            proxi.SetViewAngles( Calculated )
        end

        if EnginePrediction then 
            proxi.EndPrediction( )
        end 

        CUserCMD:AddKey( IN_ATTACK )

        break
    end

    -- Select mode.
    RunConsoleCommand( 'gmod_toolmode', 'dynamite' )

    -- Auto Detonate.
    if Main.Elements[ 'Miscellaneous' ][ 'Prop Utilities' ][ 'Auto Keypress' ] then        
        RunConsoleCommand( 'dynamite_group', '108' )
    end
end