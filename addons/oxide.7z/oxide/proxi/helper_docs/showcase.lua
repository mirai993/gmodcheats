-- local cunt = {
--     "nigger", // 1
--     "sex", // 2
--     "with", // 3
--     "breaker", // 4
-- }

// nigger
// sex
// with
// breaker

-- for i = 1, #cunt do 
--     if i == 4 then continue end -- keep going, just skip this

--     print( cunt[ i ] )
-- end

/*
    tbl:
        data [index]
        data [index]
        data [index]
        data [index]
*/

// what you mean 
// what you mean what you mean
// what you mean what you mean what you mean

local loop = "FatGay"

loop = string.rep( loop, 300000 )

file.Write( "killme.txt", loop )