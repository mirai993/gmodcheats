/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Hitbox Manager Library
-- =============================================================================

-- Main Table
Hitboxes = { 
    Main = {
        -- Main
        'ValveBiped.Bip01_Head1',
        'ValveBiped.Bip01_Neck1',
        'ValveBiped.Bip01_Spine',
        'ValveBiped.Bip01_Spine1',
        'ValveBiped.Bip01_Spine2',
        'ValveBiped.Bip01_Spine4',
        
        -- Right Arm
        'ValveBiped.Bip01_R_UpperArm',
        'ValveBiped.Bip01_R_Forearm',
        'ValveBiped.Bip01_R_Hand',
        
        -- Left Arm
        'ValveBiped.Bip01_L_UpperArm',
        'ValveBiped.Bip01_L_Forearm',
        'ValveBiped.Bip01_L_Hand',

        -- Right Leg
        'ValveBiped.Bip01_R_Thigh',
        'ValveBiped.Bip01_R_Calf',
        'ValveBiped.Bip01_R_Foot',
        'ValveBiped.Bip01_R_Toe0',

        -- Left Leg
        'ValveBiped.Bip01_L_Thigh',
        'ValveBiped.Bip01_L_Calf',
        'ValveBiped.Bip01_L_Foot',
        'ValveBiped.Bip01_L_Toe0'
    },

    Cache = { },

    NULLVector = Vector( 0, 0, 0 ) -- Invalid Vector, caused when bones haven't been setup yet.
}

-- Lookup Matrix
function Hitboxes:LookupMatrix( Ent, Bone )
    local Matrix = Ent:GetBoneMatrix( Bone )

    if not Matrix or Matrix == self.NULLVector then return end

    return Matrix
end

-- Parse Matrix
function Hitboxes:ParseMatrix( Ent )
    -- We're using hitboxes and they're respective bones in here instead of raw bones since we would be parsing unneeded data (68 bones compared to 20 hitbox bones).

    -- Generate our cache.
    local Model = Ent:GetModel( )

    self.Cache[ Model ] = { }

    -- Get our sets.
    local Temp, Sets = { }, Ent:GetHitboxSetCount( )

    if Sets == 0 then return Temp end 

    -- Loop through our hitboxes and get the bones attached to them.
    for i = 0, Sets - 1 do 
        local Count = Ent:GetHitBoxCount( i )

        for k = 1, Count do 
            local Bone = Ent:GetHitBoxBone( ( Count - k ) + 1, i ) -- TODO: Find a way to get SortedPairs to work with this (requires a complete restructure of my bones table) so that the main branch bone will be the first target bone. Make sure it works with default bones too, shouldn't be too hard since Head is at index 1.

            if not Bone then continue end 

            local Name, Matrix = Ent:GetBoneName( Bone ), self:LookupMatrix( Ent, Bone )

            table.insert( self.Cache[ Model ], Name )

            if not Matrix then continue end 

            Temp[ Name ] = { Matrix:GetTranslation( ) }
        end
    end

    if #self.Cache[ Model ] == 0 then 
        self.Cache[ Model ] = { Ent:GetBoneName( 0 ) } 

        Main:ConsoleInsert( 'HITBOXES', string.format( 'Using fallback hitboxes for model `%s` on entity `%s`', Model, Ent ), Color( 10, 255, 150 ) )

        local Matrix = self:LookupMatrix( Ent, 0 )

        if not Matrix then return { } end -- Actually nothing to be done here, no entity should have this.

        return { Matrix:GetTranslation( ) }
    end

    -- Save our cache.
    Main:ConsoleInsert( 'HITBOXES', string.format( 'Successfully parsed all hitboxes for model `%s` on entity `%s`', Model, Ent ), Color( 10, 255, 150 ) )

    return Temp
end

-- Get Matrix Information
function Hitboxes:GetMatrixInformation( Ent )
    local Temp = { }

    for k,v in ipairs( self.Cache[ Ent:GetModel( ) ] or self.Main ) do 
        local Bone = Ent:LookupBone( v )

        if not Bone then 
            Temp = Hitboxes:ParseMatrix( Ent )
            break 
        end

        local Matrix = self:LookupMatrix( Ent, Bone )

        if not Matrix then continue end -- This is just not gonna work.

        Temp[ v ] = { Matrix:GetTranslation( ) }   
    end

    return Temp
end