/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

//-/~ Table
Playerlist = { 
    Players = { }
}

//-/~ Initial
function Playerlist:Initial( DScrollPanel, DPanelSection )
    DScrollPanel:Remove( )

    -- Setup Layout
    local List = vgui.Create( 'DIconLayout', DPanelSection )
    List:Dock( FILL )
        
    local Left = List:Add( 'DPanel' ) 
    Left:SetSize( 215, 206 )
    Left.Paint = function( self, w, h ) end
    
    local Right = List:Add( 'DPanel' ) 
    Right:SetSize( 215, 206 )
    Right.Paint = function( self, w, h ) end

    -- Setup Left Scrollbar
    local Scrollbar = vgui.Create( 'DScrollPanel', Left )
    Scrollbar:Dock( FILL )

    local VBar = Scrollbar:GetVBar(  )
    VBar:SetWide( Main.Scale(4) )
    VBar:SetHideButtons( true )
    VBar.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black03'] )
        surface.DrawRect( 0, 0, w, h )
    end
    VBar.btnGrip.Paint = function( s, w, h )
        surface.SetDrawColor( Main.UIColors['Black04'] )
        surface.DrawRect( 0, 0, w, h )
    end

    -- Setup Playerlist
    local layout = vgui.Create( 'DListLayout', Scrollbar )
    layout:Dock( FILL )

    layout:SetPaintBackground( true )
    layout:SetBackgroundColor( Color( 30, 30, 30 ) )

    layout:MakeDroppable( 'Oxide-DListLayout' ) 

    self.List = layout
end

//-/~ Update
function Playerlist:Update( Players )

end

//-/~ Check
function Playerlist:Check( )
    local Targets = player.GetAll( )

    for i = 1, #Targets do 
        local Index = Targets[ i ]

        if not Index then 
            continue 
        end

        if not self.Players[ Index ] then 
            Playerlist:Update( Players )
        end
    end
end