/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

local Element = {}

//-/~ Main Table
local Options = {
    { 'menu', 'Aimbot' },
    { "menu", "Visuals", { "Players", "World", "Items" } },
    { "menu", "Console", nil, 600, 350 },
    
    // General Aimbot
    { 'section', 'Aimbot', nil, 'General' },
    { 'binder', "Aimbot", nil, "General", "Enabled" },
    -- { "dropdown", "Aimbot", nil, 'General', 'Bind Style', false, 'Hold', { 'Hold', 'Toggle' }, 0, 0, 65, 0 },
    
    { 'checkbox', 'Aimbot', nil, "General", "Auto Shoot" },
    { "dropdown", "Aimbot", nil, "General", 'Auto Shoot Mode', false, 'Left', { 'Left', 'Right' } },

    { 'checkbox', 'Aimbot', nil, "General", "Silent" },
    { "dropdown", "Aimbot", nil, "General", 'Silent Mode', false, 'Clientside', { 'Clientside', 'Serverside' } },

    { 'checkbox', 'Aimbot', nil, "General", "Limit FOV" },
    { "slider", "Aimbot", nil, "General", "°", 1, 180, false, 'FOV' },

    { 'colormixer', 'Aimbot', nil, "General", "Highlight Targets" },

    { 'checkbox', 'Aimbot', nil, "General", "Smoothing" },
    { "slider", "Aimbot", nil, "General", "%", 1, 100, false, 'Smoothing Amount' },
    { "slider", "Aimbot", nil, "General", "%", 1, 100, true, 'Ratio' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Limit Distance' },
    { "slider", "Aimbot", nil, "General", "un", 1, 15000, false, 'Distance Units' },
    
    { 'checkbox', 'Aimbot', nil, 'General', 'Limit Targets' },
    { "slider", "Aimbot", nil, "General", '', 1, 10, false, 'Max Targets' },

    { 'checkbox', 'Aimbot', nil, 'General', 'Force Facestab' },

    // Accuracy Aimbot
    { 'section', 'Aimbot', nil, 'Accuracy' },
    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Compensate Accuracy' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Autostop' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Resolver' },
    { "dropdown", "Aimbot", nil, "Accuracy", 'Resolver Mode', false, 'Off', { 'Off', 'Default', 'Basic' } },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Delay' },
    { "slider", "Aimbot", nil, "Accuracy", 'ms', 1, 1000, false, 'Delay Amount' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Predict Bow' },

    { 'checkbox', 'Aimbot', nil, 'Accuracy', 'Engine Prediction (!)' },

    // Target Selection Aimbot
    { 'section', 'Aimbot', nil, 'Target Selection' },
    { "dropdown", "Aimbot", nil, "Target Selection", 'Priority', true, 'Crosshair', { 'Crosshair', 'Distance', 'Health' } },
    { "dropdown", "Aimbot", nil, "Target Selection", 'Hitbox Selection', true, 'Hitscan', { 'Hitscan', 'Head', 'Body', 'Pelvis', 'Feet' } },

    { 'checkbox', 'Aimbot', nil, 'Target Selection', 'Multipoint' },
    { "dropdown", "Aimbot", nil, "Target Selection", 'Mode', false, 'Normal', { 'Normal', 'Rough', 'Very Rough' } },
    { "slider", "Aimbot", nil, "Target Selection", "%", 1, 100, false, 'Multipoint Amount' },

    { "dropdown", "Aimbot", nil, "Target Selection", 'Prediction', true, 'Off', { 'Off', 'Leading', 'Backtrack' } },
    { "slider", "Aimbot", nil, "Target Selection", "t", 2, 8, false, 'Record Ticks' },

    { 'checkbox', 'Aimbot', nil, 'Target Selection', "Avoid Sticky" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Teammates" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Steam Friends" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Invisible" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Staff" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Noclip" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Bots" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid NPC" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid Players" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid When Menu Opened" },

    { 'checkbox', 'Aimbot', nil, "Target Selection", "NZombies Support" },
    { 'checkbox', 'Aimbot', nil, "Target Selection", "Avoid When Down" },

    // Anti-Aim
    { 'section', 'Aimbot', nil, 'Anti-Aim' },
    { "checkbox", "Aimbot", nil, "Anti-Aim", "Enable" },
    { "dropdown", "Aimbot", nil, "Anti-Aim", "Pitch", true, 'Down', { 'Up', 'Down', 'Fake-Up', 'Fake-Down', 'Mixed' } },
    { "dropdown", "Aimbot", nil, "Anti-Aim" ,"Yaw Base", true, 'Away Crosshair', { 'Static', 'Away Crosshair', 'Away Distance' } },
    { "slider", "Aimbot", nil, "Anti-Aim", "°", 1, 360, true, 'Yaw Add' },
    { "dropdown", "Aimbot", nil, "Anti-Aim" ,"Fake Yaw", true, 'Static', { 'Off', 'Static' } },
    { "slider", "Aimbot", nil, "Anti-Aim", "°", 1, 360, false, 'Fake Add' },

    // ESP
    { "section", "Visuals", "Players", "ESP" },
    
    { "checkbox", "Visuals", "Players", "ESP", "Enabled" },
    { "colormixer", "Visuals", "Players", "ESP", "Box" },
    { "dropdown", "Visuals", "Players", "ESP", "Box Style", false, '2D', { '2D', '2D Outlined', '3D' } },
    { "colormixer", "Visuals", "Players", "ESP", "Name" },
    { "colormixer", "Visuals", "Players", "ESP", "Weapon" },
    { "checkbox", "Visuals", "Players", "ESP", "Health Bar" },
    { "dropdown", "Visuals", "Players", "ESP", "Health Bar Style", false, 'Regular', { 'Regular', 'Gradient Down', 'Gradient Up' } },
    { "colormixer", "Visuals", "Players", "ESP", "Override Health Bar" },
    { "colormixer", "Visuals", "Players", "ESP", "Skeleton" },
    { "colormixer", "Visuals", "Players", "ESP", "Tracers" },
    { "colormixer", "Visuals", "Players", "ESP", "Hitboxes" },
    { "colormixer", "Visuals", "Players", "ESP", "Glow (!)" },
    { "slider", "Visuals", "Players", "ESP", 'x', 1, 5, true, 'Passes' },
    { "checkbox", "Visuals", "Players", "ESP", "Include Weapon" },
    { "checkbox", "Visuals", "Players", "ESP", "Force Bloom" },
    { "checkbox", "Visuals", "Players", "ESP", "Only Visible" },
    { "colormixer", "Visuals", "Players", "ESP", "Head Tracers" },
    { "dropdown", "Visuals", "Players", "ESP", "Head Tracer Material", false, 'Arrow', { 'Arrow', 'Laser', 'Smoke', 'Beam', 'Spark', 'Plasma' } },
    { "slider", "Visuals", "Players", "ESP", 'z', -15, 15, true, 'Head Tracer Offset' },
    { "colormixer", "Visuals", "Players", "ESP", "Overhead Prop" },

    // Chams
    { "section", "Visuals", "Players", "Chams" },

    { "colormixer", "Visuals", "Players", "Chams", "Visible" },
    { "dropdown", "Visuals", "Players", "Chams", "Visible Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal' } },

    { "colormixer", "Visuals", "Players", "Chams", "Visible Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Visible Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net' } },
   
    { "colormixer", "Visuals", "Players", "Chams", "Invisible" },
    { "dropdown", "Visuals", "Players", "Chams", "Invisible Material", false, 'Textured', { 'Textured', 'Flat', 'Glass', 'Metal' } },

    { "colormixer", "Visuals", "Players", "Chams", "Invisible Overlay" },
    { "dropdown", "Visuals", "Players", "Chams", "Invisible Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball', 'Scan', 'Star', 'Lines', 'Net' } },

    { "checkbox", "Visuals", "Players", "Chams", "Disable Model (!)" },

    -- TODO
    -- This
    -- { "colormixer", "Visuals", "Players", "Chams", "Backtrack" },
    -- { "dropdown", "Visuals", "Players", "Chams", "Backtrack Material", false, 'Textured', { 'Textured', 'Flat', 'Wireframe', 'Glass', 'Globe', 'Comball', 'Liquid', 'Hoverball' } },

    -- { "colormixer", "Visuals", "Players", "Chams", "Backtrack Overlay" },
    -- { "dropdown", "Visuals", "Players", "Chams", "Backtrack Overlay Material", false, 'Wireframe', { 'Wireframe', 'Globe', 'Comball', 'Liquid', 'Hoverball' } },

    -- TODO 
    -- Local Chams in here
    -- Fake Chams in here

    // Other
    { "section", "Visuals", "Players", "Other", nil, 450 },

    { "checkbox", "Visuals", "Players", "Other", "Spectator List" },
    { "checkbox", "Visuals", "Players", "Other", "Admin List" },
    { "checkbox", "Visuals", "Players", "Other", "Aimbot Information" },

    { "checkbox", "Visuals", "Players", "Other", "Footstep Manipulation" },
    { "checkbox", "Visuals", "Players", "Other", "Supress Local" },
    { "slider", "Visuals", "Players", "Other", '%', 1, 100, true, 'Local Volume' },
    { "slider", "Visuals", "Players", "Other", '%', 1, 100, true, 'Enemy Volume' },
    { "checkbox", "Visuals", "Players", "Other", "Spoof Sound" },
    { "dropdown", "Visuals", "Players", "Other", "Footstep Sound", false, 'Light', { 'Light', 'Screenshot', 'Notification', 'Blip', 'Bell', 'Stomp' } },
    { "checkbox", "Visuals", "Players", "Other", "Spoof DSP" },
    { "dropdown", "Visuals", "Players", "Other", "Footstep DSP", false, 'Reverb', { 'Reverb', 'Depth', 'Echo', 'Tunnel', 'Distorted', 'Water' } },
    { "checkbox", "Visuals", "Players", "Other", "Extend Range" },
    { "colormixer", "Visuals", "Players", "Other", "Shot Timer" },
    { "colormixer", "Visuals", "Players", "Other", "Projectile Trail" },
    { "checkbox", "Visuals", "Players", "Other", "Trail Through Walls" },

    -- TODO:
    -- Hand Chams in here
    -- Viewmodel Chams in here

    // Filters
    { "section", "Visuals", "Players", "Filters", nil, 450 },

    { "checkbox", "Visuals", "Players", "Filters", "Avoid Teammates" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Friendly" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Staff" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid Invisible" },
    { "checkbox", "Visuals", "Players", "Filters", "Avoid NPC" },

    // World
    { "section", "Visuals", "World", "World", nil, 960 },

    { 'binder', "Visuals", 'World', 'World', "Thirdperson", true },
    { "slider", "Visuals", "World", "World", '°', 75, 250, true, 'Max Distance' },
    { "slider", "Visuals", "World", "World", '°', -64, 64, true, 'Up Distance' },
    { 'checkbox', "Visuals", 'World', 'World', "Collision" },
    { 'checkbox', "Visuals", 'World', 'World', "Right Offset" },
    { "slider", "Visuals", "World", "World", '°', -64, 64, false, 'Right Offset Distance' },
    { 'binder', "Visuals", 'World', 'World', "Freecam", true },
    { "slider", "Visuals", "World", "World", '°', 5, 15, true, 'Speed' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Sensitivity' },
    { 'checkbox', "Visuals", 'World', 'World', "Unclamp Pitch" },
    { 'binder', "Visuals", 'World', 'World', "Freelook", true },
    { 'checkbox', "Visuals", 'World', 'World', "Viewmodel Adjustments" },
    { 'checkbox', "Visuals", 'World', 'World', "No Sway" },
    { 'checkbox', "Visuals", 'World', 'World', "No Bob" },
    { 'checkbox', "Visuals", 'World', 'World', "Enforce Gamemode View" },
    { 'checkbox', "Visuals", 'World', 'World', "Adjust Offsets" },
    { "slider", "Visuals", "World", "World", '°', -15, 15, true, 'Offset X' },
    { "slider", "Visuals", "World", "World", '°', -15, 15, true, 'Offset Y' },
    { "slider", "Visuals", "World", "World", '°', -15, 15, true, 'Offset Z' },
    { "slider", "Visuals", "World", "World", '°', 0, 360, true, 'Roll' },
    { "slider", "Visuals", "World", "World", '°', 0, 360, true, 'Yaw' },
    { "slider", "Visuals", "World", "World", '°', 60, 140, true, 'FOV' },
    { 'colormixer', "Visuals", 'World', 'World', "World Modulation", nil, false, true },
    { 'checkbox', "Visuals", 'World', 'World', "Skybox Modulation" },
    { 'colormixer', "Visuals", 'World', 'World', "Skybox Top", nil, true },
    { 'colormixer', "Visuals", 'World', 'World', "Skybox Bottom", nil, true },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Fade Bias' },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'HDR Scale' },
    { 'colormixer', "Visuals", 'World', 'World', "Dusk" },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Dusk Scale' },
    { "slider", "Visuals", "World", "World", '%', 0, 100, true, 'Dusk Intensity' },
    { 'checkbox', "Visuals", 'World', 'World', "Star Modulation" },
    { 'checkbox', "Visuals", 'World', 'World', "Draw Stars" },
    { "dropdown", "Visuals", "World", "World", "Star Texture", true, 'Cloud', { 'Cloud', 'Stars', 'Warp', 'Bars', 'Liquid' } },
    { "slider", "Visuals", "World", "World", '', 1, 3, true, 'Star Layers' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Speed' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Scale' },
    { "slider", "Visuals", "World", "World", '%', 1, 100, true, 'Star Fade' },
    { 'colormixer', "Visuals", 'World', 'World', "Sun Modulation" },
    { "slider", "Visuals", "World", "World", '%', 1, 250, false, 'Sun Scale' },


    // Props
    { "section", "Visuals", "World", "Props", nil, 960 },

    // Console
    { "section", "Console", nil, "Output", 1090, 560, function( DScrollPanel, DPanelSection )
        DScrollPanel:Remove( )

        local DRichText = vgui.Create( "RichText", DPanelSection )
        DRichText:Dock( FILL )

        function Main:ConsoleInsert( Prefix, Text, PrefixColor )
            DRichText:InsertColorChange( PrefixColor.r, PrefixColor.g, PrefixColor.b, 255 )
            DRichText:AppendText( '[' .. Prefix .. '] ' )
            DRichText:InsertColorChange( 192, 192, 192, 255 )
            DRichText:AppendText( ' ' .. Text .. '\n' )
        end

        local CommandEntry = vgui.Create( 'DTextEntry', DPanelSection )
        CommandEntry:Dock( BOTTOM ) 

        CommandEntry.OnEnter = function( self, value )
            Command:OnEnter( CommandEntry, value )
        end
        CommandEntry.OnMousePressed = function( )
            Element.CloseMixer( )
        end

        CommandEntry.Paint = function( self, w, h )
            draw.RoundedBox( 0, 0, 0, w, h, Color( 30, 30, 30 ) )

            surface.SetDrawColor( 42, 42, 42 )
            surface.DrawOutlinedRect( 0, 0, w, h, 1 )

            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )

            if self:HasFocus( ) then 
                draw.SimpleText( self:GetValue( ), 'Trebuchet18', 5, 0 )
            else
                draw.SimpleText( 'Type a command or type `help` to get a list of commands...', 'Trebuchet18', 5, 0 )
            end
        end
    end },
}

//-/~ Setup
local gradient = Material( 'vgui/gradient-l' )
local gradient_down = Material( 'gui/gradient_down' )
local w, h = ScrW(  ), ScrH(  )

//-/~ Table
Main.Elements = { }

//-/~ Fonts
for i=5, 30 do
    surface.CreateFont( 'oxide.' .. i, { font='Roboto Bold', size=i, weight=550 } )
end

//-/~ Background
local background = vgui.Create(  'DFrame' )
background:DockPadding( 0,0,0,0 )
background:Dock( FILL )
background:DockMargin( 0,0,0,0 )
background:SetTitle( '' )
background:MakePopup(  )
background:SetDraggable( false )
background:SetKeyboardInputEnabled( true )
background:ShowCloseButton( false )
background:Center(  )
background.Paint = function( s,w,h )
    draw.RoundedBox( 0,0,0,w,h,Color( 0,0,0,150 ) )
end

Main[ 'Menu Reference' ] = background

local MenuHandler = vgui.Create( 'DIconLayout', background )
MenuHandler:Dock( FILL )
MenuHandler:DockMargin( 16,16,16,16 )
MenuHandler:SetSpaceX( 8 )
MenuHandler:SetSpaceY( 4 )

//-/~ Main VGUI
function Element.FindIndex( ui, page, title )
    if !IsValid(Main.Elements[ui or ""]) then return end
    if page then
        return Main.Elements[ui] and IsValid(Main.Elements[ui][page]) and ( title and IsValid(Main.Elements[ui][page][title]) and Main.Elements[ui][page][title] ) or Main.Elements[ui][page]
    end
    return Main.Elements[ui] and ( IsValid(Main.Elements[ui][title]) and Main.Elements[ui][title] ) or Main.Elements[ui]
end

function Element.DScrollPanel( parent )
    if !IsValid( parent ) then return end

    local DScrollPanel = vgui.Create( 'DScrollPanel', parent )
    
    local VBar = DScrollPanel:GetVBar(  )
    VBar:SetWide( 4 )
    VBar:SetHideButtons( true )
    VBar.Paint = function( s,w,h )
        draw.RoundedBox( 0,0,0,w,h,Color( 26,26,26 ) )
    end
    VBar.btnGrip.Paint = function( s,h,h )
        draw.RoundedBox( 0,0,0,w,h,Color( 42,42,42 ) )
    end

    return DScrollPanel
end

function Element.CreateDFrame( title, tabs, W, H )
    W, H = W or w/3.75, H or h/1.8

    local DFrame = vgui.Create( 'DFrame', MenuHandler )
    DFrame:DockPadding( 0,0,0,0 )
    DFrame:SetTitle( '' )
    DFrame:SetDraggable( false )
    DFrame:SetSize( W, H )
    DFrame.Paint = function( s, w, h )
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    local DPanel = vgui.Create( 'DPanel', DFrame )
    DPanel:Dock( TOP )
    DPanel:DockMargin( 1,1,1,0 )
    DPanel:SetTall( 25 )
    DPanel.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 210, 121, 69, 166 ) )
        draw.SimpleText( title or '', 'oxide.14', 4, h/2.1, Color( 255, 255, 255 ), 0, 1 )
        
        surface.SetDrawColor( 210, 121, 69, 200 )
        surface.DrawRect( 0, h-2, w, 2 )
    end

    local panel = vgui.Create( 'DPanel', DFrame )
    Main.Elements[ title ] = panel
    panel:Dock( FILL )
    panel:DockMargin( 1, 0, 1, 1 )
    panel.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 28, 28, 28 ) )
    end

    if tabs then
        local nav = vgui.Create( 'DPanel', panel )
        nav:Dock( TOP )
        nav:DockMargin( 4, 0, 4, 0 )
        nav:SetTall( 30 )
        nav.Paint = function( s, w, h )
            draw.RoundedBox( 0, 0, 0, w, h, Color( 36,36,36 ) )
            surface.SetDrawColor( 42, 42, 42 )
            surface.DrawRect( 0, h-2, w, 2 )
        end

        local Populate = vgui.Create( 'DPanel', panel )
        Populate:Dock( FILL )
        Populate:DockMargin( 8, 8, 8, 8 )
        Populate.Paint = nil

        local selected = ''
        for i, v in ipairs( tabs ) do
            if !IsValid( nav ) then break end
            
            local DIconLayout = vgui.Create( 'DIconLayout', Populate )
            Main.Elements[ title ][ v ] = DIconLayout
            DIconLayout:Dock( FILL )
            DIconLayout:DockMargin( 5, 0, 0, 0 )
            DIconLayout:SetSpaceX( 6 )
            DIconLayout:SetSpaceY( 4 )
            DIconLayout.OnMousePressed = function(  )
                Element.CloseMixer(  )
            end

            if i != 1 then DIconLayout:SetVisible( false ) else selected = v end
            
            local DButton = vgui.Create( 'DButton', nav )
            DButton:Dock( LEFT )
            DButton:SetText( '' )
            DButton.Think = function( s )
                s:DockMargin( 0, 0, 2, 3 )
                s:SetWide( nav:GetWide(  ) / #tabs )
            end

            DButton.Paint = function( s, w, h )
                local hover = s:IsHovered(  )
                local me = ( selected == v )
                draw.RoundedBox( 0, 0, 0, w, h, hover and Color( 55,55,55 ) or Color( 44,44,44 ) )
                draw.SimpleText( v, 'oxide.15', w / 2, h / 2, ( me and color_white ) or ( hover and Color( 255,255,255 ) or Color( 255,255,255,155 ) ), 1, 1 )
            end

            DButton.DoClick = function(  )
                if selected == v then return end

                Main.Elements[ title ][ selected ]:SetVisible( false )
                Main.Elements[ title ][ v ]:SetVisible( true )

                selected = v
            end
        end

    else
        local Populate = vgui.Create( 'DPanel', panel )
        Populate:Dock( FILL )
        Populate:DockMargin( 8,8,8,8 )
        Populate.Paint = nil

        local DIconLayout = vgui.Create( 'DIconLayout', Populate )
        Main.Elements[ title ]  = DIconLayout
        DIconLayout:Dock( FILL )
        DIconLayout:DockMargin( 5, 0, 0, 0 )
        DIconLayout:SetSpaceX( 6 )
        DIconLayout:SetSpaceY( 4 )
        DIconLayout.OnMousePressed = function(  )
            Element.CloseMixer(  )
        end
    end

    DFrame:ShowCloseButton( false )
end

//-/~ Features & Other Elements
function Element.CreateSection( ui, page, title, W, H, func )
    local parent = Element.FindIndex( ui, page, title )

    if !parent then return end
    
    local W, H = W or 445, H or 505
    
    local DPanelSection = vgui.Create( 'DPanel', parent )
    DPanelSection:SetSize( W*.53, H*.55 )
    DPanelSection.Paint = function( s, w, h )
        draw.RoundedBox(0, 0, 0, w, h, Color( 32, 32, 32 ) )
        surface.SetDrawColor( 42, 42, 42 )
        surface.DrawOutlinedRect(0, 0, w, h, 1 )
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
    end

    local DPanel = vgui.Create( 'DPanel', DPanelSection )
    DPanel:Dock( TOP )
    DPanel:DockMargin(3, 3, 3, 5 )
    DPanel:SetTall( 18 )
    DPanel.Paint = function( s, w, h )
        surface.SetDrawColor( 253, 182, 11, 99 )
        surface.SetMaterial( gradient )
        surface.DrawTexturedRect( 0, 0, w, h )
        surface.SetDrawColor( 210, 121, 69 )
        surface.DrawRect( 0, h-2, w, 2 )
        draw.SimpleText( title, 'oxide.13', 3, h/2, color_white, 0, 1 )
    end

    local DScrollPanel = Element.DScrollPanel( DPanelSection )
    DScrollPanel:Dock( FILL )
    DScrollPanel:DockMargin( 10, 8, 2, 2 )
    DScrollPanel.OnMousePressed = function( )
        Element.CloseMixer( )
    end
    parent[ title ] = DScrollPanel

    local VBar = DScrollPanel:GetVBar( )
    VBar:SetWide( 5 )
    VBar:SetHideButtons( true )
    VBar.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 26, 26, 26 ) )
    end

    VBar.btnGrip.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 42, 42, 42 ) )
    end

    if func then 
        func( DScrollPanel, DPanelSection )
    end

    return DScrollPanel
end

function Element.CreateCheckBox( ui, page, section, name, overwrite, docklow )
    local parent = Element.FindIndex( ui, page, section )

    if !parent then return end

    local DCheckBoxLabel = vgui.Create( 'DCheckBoxLabel', ( overwrite or parent ) )
    DCheckBoxLabel:Dock( docklow and BOTTOM or TOP )
    DCheckBoxLabel:DockMargin( docklow and 10 or 0, 0, 0, 8 )
    DCheckBoxLabel:SetTextColor( color_white )
    DCheckBoxLabel:SetFont( 'oxide.12' )
    DCheckBoxLabel:SetText( name )
    DCheckBoxLabel:SizeToContents( )
    DCheckBoxLabel.Button.Paint = function( s, w, h )
        parent[ name ] = s:GetChecked( )

        draw.RoundedBox( 0, 0, 0, w, h, Color( 44, 44, 44 ) )
        
        if parent[ name ] then
            draw.RoundedBox( 0, 0, 0, w, h, Color( 210, 121, 69 ) )
            draw.SimpleText( '✔', 'oxide.15', w/2, h/2, color_white, 1, 1 )
        end
        
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end 

    if parent[ name ] then 
        DCheckBoxLabel:SetValue( parent[ name ] )
    end

    DCheckBoxLabel.OnMousePressed = function( )
        Element.CloseMixer( )
    end

    DCheckBoxLabel.OnChange = function( self, val )
        parent[ name ] = val

        hook.Run( 'ovc', name, self, val )
    end

    return DCheckBoxLabel
end

function Element.CloseMixer()
    if !IsValid( Element.Mixer ) then return end

    Element.Mixer:Remove( )
end

function Element.DColorMixer( ui, page, section, name, color, norainbow )
    local parent =  Element.FindIndex( ui, page, section )

    if !parent then return end

    Element.CloseMixer( )

    local x, y = input.GetCursorPos( )

    local DPanel = vgui.Create( 'DPanel' )
    DPanel:SetPos( x, y )
    DPanel:SetSize( 180, 160 )
    DPanel:MoveToFront( )
    DPanel:MakePopup( )
    DPanel.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 30, 30, 30 ) )

        surface.SetDrawColor( 42, 42, 42 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 1, 1, w-2, h-2, 1 )
    end

    Element.Mixer = DPanel

    local DColorMixer = vgui.Create( 'DColorMixer', Element.Mixer )
    DColorMixer:Dock( FILL )
    DColorMixer:DockMargin( 6, 6, 6, 6 )
    DColorMixer:SetPalette( false )
    DColorMixer:SetWangs( false )
    DColorMixer:SetAlphaBar( true )

    if color then DColorMixer:SetColor( color ) else DColorMixer:SetColor( Color( 200, 200, 200 ) ) end

    -- Adjust children to fit box.
    local Children = DColorMixer:GetChildren()

    -- Children[ 5 ]:Dock( RIGHT )
    Children[ 5 ]:SetWide( 20 )
    -- Children[ 5 ]:DockMargin( 0, 0, 3, 0 )

    -- Children[ 6 ]:Dock( RIGHT )
    Children[ 6 ]:SetWide( 20 )
    -- Children[ 6 ]:DockMargin( 0, 3, 0, 0 )

    if not norainbow then 
        Element.CreateCheckBox( ui, page, section, name .. ' Rainbow', DPanel, true )
    end 

    DColorMixer.Think = function( s )
        if parent[ name..' Rainbow' ] then 
            parent[ name..'Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )

            DColorMixer:SetColor( parent[ name..'Color' ] )
        else 
            parent[ name..'Color' ] = s:GetColor( )
        end
    end

    DColorMixer.ValueChanged = function( self, col )
        if parent[ name..' Rainbow' ] then 
            parent[ name..'Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
        else 
            parent[ name..'Color' ] = col
        end

        hook.Run( 'ovc', name, self, col ) -- TODO: Dynamic hooking via a hook callback, we'd just grab it from the hook library in here and call them.
    end

    return DPanel
end

function Element.CreateColorMixer( ui, page, section, name, color, text, norainbow )
    local parent = Element.FindIndex( ui, page, section )

    if !parent then return end

    if not parent[ name..'Color' ] then 
        parent[ name..'Color' ] = Color( 200, 200, 200 )
    end

    local DPanel = vgui.Create( 'DPanel', parent )
    DPanel:Dock( TOP )
    DPanel:DockMargin( 0, 0, 0, 8 )
    DPanel:SetTall( 15 )
    DPanel.Paint = nil

    local DButton = vgui.Create( 'DButton', DPanel )
    DButton:Dock( RIGHT )
    DButton:DockMargin( 0, 0, 10, 0 )
    DButton:SetWide( 45 )
    DButton:SetText( '' )
    DButton.Paint = function( s, w, h )
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )

        s.col = parent[ name..'Color' ] or color or Color( 200, 200, 200 )

        if parent[ name..' Rainbow' ] then
            s.col = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
        end

        surface.SetDrawColor( s.col )
        surface.SetMaterial( gradient_down )
        surface.DrawTexturedRect( 1, 1, w-2, h-2 )
    end
    
    DButton.DoClick = function( s )
        Element.DColorMixer( ui, page, section, name, s.col or color or Color( 200, 200, 200 ), norainbow )
    end
    
    if not text then 
        Element.CreateCheckBox( ui, page, section, name, DPanel )
    else 
        local DLabel = vgui.Create( "DLabel", DPanel )
        DLabel:Dock( TOP )
        DLabel:DockMargin( 0, 1, 0, 8 )
        DLabel:SetTextColor( Color( 200, 200, 200 ) )
        DLabel:SetFont( 'oxide.12' )
        DLabel:SetText( name )
        DLabel:SizeToContents( )
    end

    return DPanel
end

function Element.CreateDropDown( ui, page, section, name, useName, dropdown, tbl, x, y, override, dockright )
    if !dropdown then return end

    local parent = Element.FindIndex( ui, page, section )

    if !parent then return end

    tbl = tbl or {}

    parent[ name ] = parent[ name ] or dropdown

    local DComboBox = vgui.Create( 'DComboBox', ( override or parent ) )
    
    if x and y then 
        DComboBox:SetPos( x, y ) 
    elseif dockright then
        DComboBox:Dock( RIGHT )
        DComboBox:DockMargin( 0, 0, 3, 0 )
    else -- For some reason if you dock above and then SetPos it just refuses to listen to you.
        DComboBox:Dock( TOP )
        DComboBox:DockMargin( 0, useName and 10 or -4, 10, 8 )
    end
    
    DComboBox:SetTextColor( color_white )
    DComboBox:SetFont( 'oxide.13' )
    DComboBox:SetValue( dropdown )
    DComboBox:SetSortItems( false )

    for k, v in pairs( tbl ) do DComboBox:AddChoice( v ) end
    
    DComboBox:GetChildren( )[ 1 ].Paint = function( s, w, h )
        draw.SimpleText( '▼', 'oxide.12', w/2, h/2, Color( 194, 190, 190, 44 ), 1, 1 )
    end

    DComboBox.Paint = function( s, w, h )
        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
        draw.RoundedBox( 0, 1, 1, w-2, h-2, Color( 44, 44, 44 ) )

        if( useName ) then 
            DisableClipping( true )
            draw.SimpleText( name, 'oxide.12', 2, -h*.32, Color( 255, 255, 255, 220 ), 0, 1 )
            DisableClipping( false )
        end
    end
    
    DComboBox.OnMenuOpened = function( panel )
        local childMenu = panel:GetChildren( )[ 2 ]

        childMenu.Paint = function( s, w, h )
            surface.SetDrawColor( 0, 0, 0 )
            surface.DrawOutlinedRect( 0, 0, w, h, 1 )
            draw.RoundedBox( 0, 1, 1, w-2, h-2, Color( 44, 44, 44 ) )
        end
    
        for i = 1, #tbl do 
            childMenu:GetChild( i ):SetColor( color_white ) 
        end

        panel:GetChildren( )[ 2 ].OpenSubMenu = function( sub, menu )
            local subSub = sub:GetChildren( )[ 1 ]
            for i = 1, #tbl do 
                local subSubSub = subSub:GetChildren( )[ i ]

                subSubSub.Paint = function( self, w, h )
                    if not self:IsHovered( ) then return end 
                    
                    surface.SetDrawColor( 194, 190, 190 )
                    surface.DrawOutlinedRect( 0, 0, w, h, 1 )
                end
            end
        end
    end
    
    DComboBox.OnSelect = function( _, _, d )
        parent[ name ] = d
    end

    return DComboBox
end

function Element.CreateSlider( ui, page, section, prefix, min, max, useName, name )
    local parent = Element.FindIndex( ui, page, section )

    if !parent then return end
    
    parent[ name ] = math.ceil( max / 2 )
    
    local DNumSlider = vgui.Create( 'DNumSlider', parent )
    DNumSlider:Dock( TOP )
    DNumSlider:DockMargin( -200, useName and 8 or 0, -40, 12 )
    DNumSlider:SetTall( 6 )
    DNumSlider:SetText( '' )
    DNumSlider:SetMin( min )
    DNumSlider:SetMax( max )
    DNumSlider:SetValue( parent[ name ] )
    DNumSlider.Slider.Paint = function( s, w, h )
        local value   = tonumber( DNumSlider:GetValue() )
        local clamped = w*math.Clamp( (value - min) / (max - min), 0, 1 )
        local textw   = w / 2.2

        if value > 100 then 
            textw = w / 2.3
        elseif value < 10 then 
            textw = w / 2.1
        end

        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
        draw.RoundedBox( 0, 1, 1, w-2, h-2, Color( 55, 55, 55 ) )
    
        surface.SetDrawColor( 233, 156, 123 )
        surface.DrawRect( 1, 1, clamped-2, h-2 )
        DisableClipping( true )
        
        if useName then 
            draw.SimpleText( name, 'oxide.12', 8, -h*1.3, Color( 255, 255, 255, 155 ), 0, 1 )
        end 

        draw.SimpleText( math.floor( value ) .. prefix, 'oxide.12', textw, h * 2, Color( 255, 255, 255, 155 ), 0, 1 )

        DisableClipping( false )
    end

    DNumSlider.OnValueChanged = function( self, i )
        parent[ name ] = math.ceil( i )

        hook.Run( 'ovc', name, self, col )
    end

    DNumSlider.Slider:GetChildren( )[ 1 ].Paint = nil

    DNumSlider:GetChildren( )[ 1 ].Paint = nil 

    return DNumSlider
end

function Element.CreateBinder( ui, page, section, name, avoidMode )
    local parent = Element.FindIndex( ui, page, section )

    if !parent then return end
    
    parent[ name .. ' Bind' ] = KEY_NONE

    local DPanel = vgui.Create( 'DPanel', parent )
    DPanel:Dock( TOP )
    DPanel:DockMargin( 0, 0, 0, 8 )
    DPanel:SetTall( 15 )
    DPanel.Paint = nil

    local DBinder = vgui.Create( 'DBinder', DPanel )
    DBinder:Dock( RIGHT )
    DBinder:DockMargin( 0, 0, 10, 0 )
    DBinder:SetWide( 75 )
    DBinder:SetTextColor( color_white )
    DBinder.Paint = function( s, w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 44, 44, 44 ) )

        surface.SetDrawColor( 0, 0, 0 )
        surface.DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    DBinder.OnChange = function( bind )
        parent[ name .. ' Bind' ] = bind:GetValue( )
    end

    if not avoidMode then 
        Element.CreateDropDown( ui, page, section, name .. ' Bind Style', false, 'Hold', { 'Hold', 'Toggle' }, nil, nil, DPanel, true )
    end 

    Element.CreateCheckBox( ui, page, section, name, DPanel )
end

// Grab Color
function Main.GetColor( Tbl, Index, Convert ) -- Actual record for the ugliest code I've ever written.
    if Tbl[ Index..' Rainbow' ] then -- Pretty sure I've written ASM prettier than this.
        Tbl[ Index..'Color' ] = HSVToColor( ( CurTime() * 40 ) % 360, 1, 1 )
    end

    local Col = Tbl[ Index..'Color' ]

    if Convert then 
        Col = Vector( Col.r / 255, Col.g / 255, Col.b / 255 )
    end

    return Col
end

// Fill our menu
for _, t in ipairs( Options ) do
    -- TODO: unpack varargs and pass them to functions instead of all the t[1], t[2] bullshit
    local e = t[ 1 ]:lower( )

    if e == 'menu' then
        Element.CreateDFrame( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'section' then
        Element.CreateSection( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ] )
    elseif e == 'checkbox' then
        Element.CreateCheckBox( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ] )
    elseif e == 'colormixer' then
        Element.CreateColorMixer( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ] )
    elseif e == 'dropdown' then
        Element.CreateDropDown( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ], t[ 9 ], t[ 10 ] )
    elseif e == 'slider' then
        Element.CreateSlider( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ], t[ 7 ], t[ 8 ], t[ 9 ] )
    elseif e == "binder" then 
        Element.CreateBinder( t[ 2 ], t[ 3 ], t[ 4 ], t[ 5 ], t[ 6 ] )
    end
end

//-/~ Hook
local menuToggle = false

Main:Hook( 'Think', function( )
    local k, b = input.IsKeyDown( KEY_INSERT ), background:IsVisible( )
    
    if k and not menuToggle then 
        menuToggle = true

        Element.CloseMixer( )

        background:SetVisible( !b )
        gui.EnableScreenClicker( !b )
    elseif !k then 
        menuToggle = false
    end
end )

Main:ConsoleInsert( 'SYSTEM', 'Cheat loaded successfully, welcome user', Color( 255, 87, 51 ) )

if _M then 
    Main:ConsoleInsert( 'MAJESTIC', 'Majestic loaded with cheat successfully', Color( 221, 160, 221 ) )
end

if proxi then 
    Main:ConsoleInsert( 'PROXI', 'Proxi detected, more features enabled', Color( 0, 160, 221 ) )
end

Main:ConsoleInsert( 'SYSTEM', 'Detected gamemode : ' .. Main.Gamemode, Color( 255, 87, 51 ) )