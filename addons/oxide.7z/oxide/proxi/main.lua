/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Main Initialization
-- =============================================================================

-- Main Table
local Main = { }

-- Load Requires
require( 'proxi' )

-- Setup Environment
local G = table.Copy( _G )

local Environment = setmetatable( {
    Main = Main,
    _M    = _M,
    
    G  = G,
    _G = _G
}, {
    __index = G,
} )

if _M then 
    // Spawn prohibited instance and call AddEnvironment to secure our environment.
    local Prohibited = _M:Prohibited(  )

    Prohibited:AddEnvironment( Environment ) 

    // Load our files
    G.file = __G.file
end

-- Load Essentials
Main.Local = G.LocalPlayer( )

Main.Gamemode = G.engine.ActiveGamemode( )

Main.Interval = G.engine.TickInterval( )

Main.MaxHeight = G.Vector( 0, 0, 16384 ) // Max height of a Source Engine map.

Main.Colors = { 
    White       = color_white,
    Black       = color_black,
    Transparent = color_transparent,

    Red   = G.Color( 255,0,0 ),
    Green = G.Color( 0,255,0 ),
    Blue  = G.Color( 0,0,255 ),

    Yellow = G.Color( 255,255,0 ),
    Orange = G.Color( 255,165,0 ),
    Orchid = G.Color( 86,85,211 ),
    Cyan   = G.Color( 0,255,255 ),
    Gray   = G.Color( 128,128,128 )
}

Main.Files = {
    Library = G.file.Find( 'lua/oxide/library/*.lua', 'GAME' ),
    Base    = G.file.Find( 'lua/oxide/base/*.lua', 'GAME' )
}

Main.SWEPs = {
    [ '#HL1_' ] = 'Half-Life: Source',
    [ 'tf_' ] = 'TF2',
    [ 'weapon_cof_' ] = 'Cry Of Fear'
}

Main.Vapes = { -- This just does include on a shared file and then detours shit for new vapes. No base.
    [ 'weapon_vape_american' ] = true,
    [ 'weapon_vape_butterfly' ] = true,
    [ 'weapon_vape_custom' ] = true,
    [ 'weapon_vape_dragon' ] = true,
    [ 'weapon_vape_golden' ] = true,
    [ 'weapon_vape_hallucinogenic' ] = true,
    [ 'weapon_vape_helium' ] = true,
    [ 'weapon_vape_juicy' ] = true,
    [ 'weapon_vape_medicinal' ] = true,
    [ 'weapon_vape_mega' ] = true,
    [ 'weapon_vape' ] = true
}

Main.Players  = { }
Main.Entities = { }

Main.BulletTime = 0

-- =============================================================================
-- Booter & Utility Functions 
-- =============================================================================

function Main:Print( Text )
    G.MsgC( color_white, '[ ', self.Colors.Orange, 'oxide', color_white, ' ] ' .. Text .. '\n' )
end

function Main:ExecuteLua( Code, Insecure )
    local Compiled = G.CompileString( Code, 'oxide', true )

    if not Compiled then 
        self:Print( 'Failed to execute Lua file!\n' )

        G.debug.Trace( )

        return false
    end

    if Insecure then
        Compiled( )

        return true 
    end

    G.setfenv( Compiled, Environment )( )

    return true 
end

function Main:LoadFiles( Directory, Table )
    for i = 1, #Table do 
        local Code = G.file.Open( Directory .. Table[ i ], 'rb', 'GAME' )

        if not Code then 
            self:Print( 'Failed to read Lua file!\n' )
            continue
        end

        self:ExecuteLua( Code:Read( Code:Size( ) ) )
    end
end

function Main:LoadFile( Directory )
    local Code = G.file.Open( Directory, 'rb', 'GAME' )

    if not Code then 
        self:Print( 'Failed to read Lua file!\n' )
        return
    end

    self:ExecuteLua( Code:Read( Code:Size( ) ) )

    Code:Close( )
end

function Main:Load( )
    self:LoadFiles( 'lua/oxide/library/', self.Files.Library )
    self:LoadFiles( 'lua/oxide/base/', self.Files.Base )

    self:LoadFile( 'lua/oxide/modules/ui/main.lua' )
    self:LoadFile( 'lua/oxide/modules/optimization/main.lua' )

    self:LoadFile( 'lua/oxide/modules/aimbot/main.lua' )
    -- self:LoadFile( 'lua/oxide/modules/visual/main.lua' )

    self:LoadFile( 'lua/oxide/modules/misc/main.lua' )

    if G.game.SinglePlayer( ) then 
        self:Print( 'Cannot boot properly in singleplayer mode.' )
    end

    G.gui.HideGameUI( )

    G.surface.PlaySound( 'hl1/fvox/targetting_system.wav' )

    G.timer.Simple( 3.32, function( ) // 3.32 is how long the `targetting_system.wav` sound is. 
        G.surface.PlaySound("hl1/fvox/activated.wav") 
    end)

    G.notification.AddLegacy( 'Loaded Successfully!', NOTIFY_GENERIC, 2 )
end

Main:Load( )