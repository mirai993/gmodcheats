/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Hooks Module
-- =============================================================================

/*
    I can't run them in seperate files because I don't want to run the prediction more than once. I also need
    to really control what order things load in since the Aimbot needs to load before all automations. Similar
    issue with spammers and stuff.
*/

Main:Hook( 'CreateMoveEx', function( CUserCMD )
    Main.Entities = ents.GetAll( )

    local Engine = Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

    if Engine then 
        proxi.StartPrediction( CUserCMD )
    end

    Optimization:Localizers( CUserCMD )

    Aimbot:Aimbot( CUserCMD )

    Movement:FixMove( CUserCMD )

    if Engine then 
        proxi.EndPrediction( )
    end

    Tick:Doubletap( CUserCMD )
    Tick:Warp( CUserCMD )

    return true, true, false
end )

Main:Hook( 'PreFrameStageNotify', function( Stage )
    Records:Generate( Stage )
end )

Main:Hook( 'Move', function( ENT, CMoveData ) 
    if IsFirstTimePredicted( ) then -- https://wiki.facepunch.com/gmod/Prediction
        Main.BulletTime = CurTime( ) + Interval( )
    end
end )

Main:Hook( 'PostDrawTranslucentRenderables', function( ... )
    Overlay:Hook( )
end )