/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Movement Module
-- =============================================================================

-- Main Table
Movement = { }

-- =============================================================================
-- Function to fix movement when altering angles.
-- @param CUserCMD (cusercmd): CUserCMD provided by CreateMove.
-- =============================================================================
function Movement:FixMove( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Movement Fix' ] then 
        return 
    end

    -- Setup.
    local Yaw, Speed;
    local Move = Vector( CUserCMD:GetForwardMove(), CUserCMD:GetSideMove(), 0 )

    Speed = Move:Length2D()

    local View = CUserCMD:GetViewAngles()
    View:Normalize()
    
    Yaw = math.deg( math.atan2( Move.y, Move.x ) )
    Yaw = math.rad( View.y - Main.Local:EyeAngles().y + Yaw )

    -- Set movement.
    CUserCMD:SetForwardMove( math.cos( Yaw ) * Speed )
    CUserCMD:SetSideMove( math.sin( Yaw ) * Speed )

    -- Fix movement clamping.
    if math.abs( View.x ) > 90 then
        CUserCMD:SetForwardMove( -CUserCMD:GetForwardMove( ) )
        CUserCMD:SetSideMove( -CUserCMD:GetSideMove( ) )
    end

    local Valid = { 0, 2500, 5000, 7500, 10000, -2500, -5000, -7500, -10000 }    

    CUserCMD:SetForwardMove( math.RoundToClosest( CUserCMD:GetForwardMove( ), Valid ) )
    CUserCMD:SetSideMove( math.RoundToClosest( CUserCMD:GetSideMove( ), Valid ) )
end