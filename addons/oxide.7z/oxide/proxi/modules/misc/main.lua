/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Miscellaneous Booter Module
-- =============================================================================

-- Booters
Main:LoadFile( 'lua/oxide/modules/misc/hooks/hooks.lua' )

Main:LoadFile( 'lua/oxide/modules/misc/config/config.lua' )

Main:LoadFile( 'lua/oxide/modules/misc/movement/movement.lua' )