
/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- UI Addons Module
-- =============================================================================

-- Main Table
Extra = { 
    Flags = {
        [ 'Serbia' ] = 'flags16/rs.png',
        [ 'United States' ] = 'flags16/us.png',
        [ 'Germany' ] = 'flags16/de.png',
        [ 'Ireland' ] = 'flags16/ie.png'
    }
}

-- =============================================================================
-- Internal function used to handle menu themes.
-- =============================================================================
function Extra:Theme( )
    if not self.Sound then 
        self.Sound = CreateSound( game.GetWorld( ), 'theme/theme.wav' )
    end

    if not Main.Elements[ 'Miscellaneous' ][ 'Settings' ][ 'Menu Theme Song' ] then 
        self.Sound:Stop( )
        return
    end

    if Main.Elements[ 'Menu Reference' ]:IsVisible( ) then 
        if not self.Sound:IsPlaying( ) then
            self.Sound:Play( )
        end

        self.Sound:ChangeVolume( Main.Elements[ 'Miscellaneous' ][ 'Settings' ][ 'Volume' ] )
    else
        self.Sound:ChangeVolume( 0, 0.25 ) -- Could also use FadeTime.
    end
end

-- =============================================================================
-- Internal function used to handle overlay flag icons.
-- =============================================================================
function Extra:Icon( )
    if not self.IconButton then 
        local Icon = vgui.Create( 'DImageButton', Main.Elements[ 'Menu Reference' ] )
        Icon:Dock( FILL )
        Icon:SetImage( 'flags16/rs.png' )
        Icon:SetDepressImage( false )
        Icon:SetVisible( false )
        Icon:SetColor( Color( 255, 255, 255, 35 ) )
        Icon.DoClick = function( ) end

        self.IconButton = Icon
    end

    if Main.Elements[ 'Miscellaneous' ][ 'Settings' ][ 'Menu Flag' ] then 
        self.IconButton:SetVisible( true )

        self.IconButton:SetImage( self.Flags[ Main.Elements[ 'Miscellaneous' ][ 'Settings' ][ 'Menu Flag Icon' ] ] )
    else 
        self.IconButton:SetVisible( false )
    end
end