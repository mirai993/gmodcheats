/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Record Module
-- =============================================================================

-- Main Table
Records = { 
    Cache = { }
}

-- =============================================================================
-- Function used to validate a record object.
-- @param Object (table): The record table.
-- @return boolean: Is the record valid or not.
-- =============================================================================
function Records:Validate( Object )
    if not Object.Tick then 
        return true
    end

    -- Limit based on unlag.
    local Unlag = Optimization:ConVar( 'sv_maxunlag' )

    if Object.Tick <= Servertime( ) - math.Clamp( Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Record Time' ] / 1000, 0, Unlag and Unlag:GetFloat( ) or 1 ) then 
        return false
    end

    -- Do the correction based math.
    local Correction = Optimization:Fetch( 'LocalPlayer', 'Ping' )

    Correction = Correction + TICK_TO_TIME( Lerp( ) )
    Correction = math.Clamp( Correction, 0, 1 ) 

    return math.abs( Correction - TICK_TO_TIME( Main.Local:GetInternalVariable( 'm_nTickBase' ) - TIME_TO_TICK( Object.Tick ) ) ) < 0.2
end

-- =============================================================================
-- Function used to construct records for a specific entity.
-- @param ENT (entity): The player or entity to construct the record for.
-- @return table: The newly constructed lag record.
-- =============================================================================
function Records:Construct( ENT )
    local Tick;

    if ENT:IsPlayer( ) then 
        Tick = proxi._R.Entity.GetDTNetVar( ENT, 'DT_BaseEntity->m_flSimulationTime', 1 )
    end

    local Animations = { }
    if ENT:IsPlayer( ) then 
        ENT:InvalidateBoneCache( )
        ENT:SetupBones( ) 

        Animations.Sequence = ENT:GetSequence( )
        Animations.Cycle    = ENT:GetCycle( )
        Animations.Angles   = ENT:EyeAngles( )
        Animations.Time     = ENT:GetAnimTime( )

        Animations.Layers = { }

        for i = 0, 13 do 
            if ENT:IsValidLayer( i ) then 
                Animations.Layers[ i ] = {
                    Weight   = ENT:GetLayerWeight( i ),
                    Cycle    = ENT:GetLayerCycle( i ),
                    Duration = ENT:GetLayerDuration( i ),
                    Playback = ENT:GetLayerPlaybackRate( i )
                }
            end
        end 

        Animations.Poses = { 
            MoveX = ENT:GetPoseParameter( 'move_x' ),
            MoveY = ENT:GetPoseParameter( 'move_y' )
        }

        Animations.Color = ENT:GetColor( )
    end

    return {
        ENT    = ENT,
        Health = ENT:Health( ),
        Pos    = ENT:GetPos( ),
        Origin = ENT:GetNetworkOrigin( ),
        Health = ENT:Health( ),
        Bones  = Hitboxes:GetMatrixInformation( ENT ),
        Model  = ENT:GetModel( ),
        Tick   = Tick,
        Aim    = NULL, -- This will get filled in by our Aimbot selection to be the hitbox. 

        -- Sorting stuff.
        FOV      = 0,
        Distance = 0,

        -- Animation stuff.
        Animations = Animations
    }
end

-- =============================================================================
-- Internal function used to generate our lag records and put them in the cache.
-- @param Stage (number): The framestage we're in.
-- =============================================================================
function Records:Generate( Stage )
    if Stage != FRAME_NET_UPDATE_END then 
        return 
    end 

    -- Clean records from players who have left.
    for k,v in pairs( self.Cache ) do
        if not IsValid( k ) then
            self.Cache[ k ] = nil 
        end
    end

    -- Insert new records.
    local Targets, Server = player.GetAll( )

    for i = 1, #Targets do 
        local ENT = Targets[ i ]

        if not IsValid( ENT ) or ENT:IsDormant( ) then 
            self.Cache[ ENT ] = { }
            continue 
        end 

        self.Cache[ ENT ] = self.Cache[ ENT ] or { }

        -- Clean old records.
        for i = 1, #self.Cache[ ENT ] do 
            local Index = self.Cache[ ENT ][ i ]

            if not Index or not self:Validate( Index ) then 
                table.remove( self.Cache[ ENT ], i )
            end
        end

        -- Insert new record.
        table.insert( self.Cache[ ENT ], 1, self:Construct( ENT ) )
    end
end


-- =============================================================================
-- Function used to grab last record from a cached entity.
-- @param ENT (entity): The entity to grab.
-- @return table: The lag record.
-- =============================================================================
function Records:FindLastRecord( ENT )
    if not self.Cache[ ENT ] then 
        return 
    end
    
    local Reverse = table.Reverse( self.Cache[ ENT ] )

    for i = 1, #Reverse do 
        local Index = Reverse[ i ]

        if self:Validate( Index ) then 
            return Index
        end
    end
end
