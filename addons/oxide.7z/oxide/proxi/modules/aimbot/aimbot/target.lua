/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Targeting Module
-- =============================================================================

-- =============================================================================
-- Function used to exclude targets from the Aimbot based on configuration settings.
-- @param ENT (entity): The entity you want to validate.
-- @return boolean: Weather or not the entity passed should be excluded.
-- =============================================================================
function Aimbot:Exclude( ENT )
    if not ENT or ENT:IsDormant( ) or ENT == Main.Local then return true end 

    if ENT:IsPlayer( ) then 
        if not ENT:Alive( ) or  ENT:Health( ) <= 0 then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Players' ] then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Steam Friends' ] and ENT:GetFriendStatus( ) == 'friend' then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Invisible' ] and ENT:GetColor( ).a <= 200  then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Staff' ] and ENT:IsAdmin( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Noclip' ] and ENT:GetMoveType( ) == MOVETYPE_NOCLIP then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Vehicles' ] and ENT:InVehicle( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Bot' ] and ENT:IsBot( ) then return true end 

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Teammates' ] then
            if ENT:Team( ) == Main.Local:Team( ) then return true end 

            -- TTT, this only gets networked if we're teammates.
            if ENT.IsTraitor and ENT:IsTraitor( ) then return true end 
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Roles' ] then
            -- Military RP and other similar gamemodes.
            if ENT:GetNWString( 'Role', 'unknown' ) == Main.Local:GetNWString( 'Role', 'localrole' ) then return true end
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Buildmode' ] then
            if ENT.buildmode then return true end

            if ENT:GetNWBool( 'BuildMode' ) then return true end
        end

        if not Playerlist:IsBlacklisted( ENT ) then
            return true
        end
    else 
        if ENT:Health( ) <= 0 then return true end

        if not ENT:IsNPC( ) and not ENT:IsNextBot( ) then return true end 
            
        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid NPC' ] then return true end 

        if NPCs:CallCallback( ENT ) then return true end 
    end

    return false
end


-- =============================================================================
-- Internal function used to select the best target when the targeting system loops.
-- =============================================================================
function Aimbot:SelectTarget( Record, Best, Hitbox, CUserCMD )
    -- Limit Distance
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit Distance' ] then 
        local dist = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Distance Units' ]

        if Record.Pos:Distance( Main.Local:GetPos( ) ) > ( dist * 5 ) then 
            return
        end
    end

    -- Calculate View FOV
    local localAngle, posAng = Main.Local:GetAngles( ), ( Hitbox - Main.Local:GetPos( ) ):Angle( )
    local FOV = math.Clamp( Vector( math.NormalizeAngle( posAng.x - localAngle.x ), math.NormalizeAngle( posAng.y - localAngle.y ), 0 ):Length2D( ), 0, 180 )
    
    Record.FOV = FOV
    Record.Distance = ( Record.Pos ):Distance( Main.Local:GetPos( ) )

    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit FOV' ] then 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'FOV' ] < ( FOV ) then 
            return 
        end
    end

    -- Safety check.
    if not Best then return Record end 

    local Sort = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Priority' ] 

    -- Sort our stuff.
    if Sort == 'Crosshair' and Record.FOV then 
       if Record.FOV < Best.FOV then 
            return Record
        end 
    elseif Sort == 'Distance' and Record.Distance then 
        if  Record.Distance < Best.Distance then 
            return Record
        end
    else -- Do the else here just in case the above ones failed.
        if Record.Health < Best.Health then 
            return Record
        end
    end
end
