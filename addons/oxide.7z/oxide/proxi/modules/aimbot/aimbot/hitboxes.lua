/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Hitboxes Module
-- =============================================================================

-- =============================================================================
-- Function used to check the visibility of a hitbox matrix.
-- @param Data (table): The matrix information table from the record that we're looping.
-- @param Record (table): The record that we're looping.
-- @return vector: The matrix information (or nil if the target wasn't valid).
-- =============================================================================
function Aimbot:LoopHitbox( Data, Record )
    if not Data then return end 

    for i = 1, #Data do 
        local Matrix = Data[ i ]

        if not Matrix then continue end 

        local Trace = util.TraceLine( { start = Main.Local:EyePos( ), endpos = Matrix, filter = { Main.Local, Record.ENT }, mask = MASK_SHOT } )

        if Trace.Fraction == 1 then 
            return Matrix
        end
    end
end

-- =============================================================================
-- Function used to loop all hitboxes in a record.
-- @param Record (table): The record that we're looping.
-- @return vector: The matrix information (or nil if the target wasn't valid).
-- =============================================================================
function Aimbot:FindHitbox( Record )
    if not Record.Bones then return end 

    local Mode = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Hitbox Selection' ]

    if Mode == 'Head' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_HEAD	 ], Record )
    elseif Mode == 'Pelvis' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_STOMACH ], Record )
    elseif Mode == 'Body' then 
        return self:LoopHitbox( Record.Bones[ HITGROUP_CHEST ], Record )
    elseif Mode == 'Feet' then
        return self:LoopHitbox( Record.Bones[ HITGROUP_LEFTLEG ], Record ) or self:LoopHitbox( Record.Bones[ HITGROUP_RIGHTLEG ], Record )
    end 

    for k, Bone in pairs( Record.Bones ) do 
        local Data = self:LoopHitbox( Bone, Record )
        
        if Data then 
            return Data
        end 
    end
end
