/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Aimbot Angle Module
-- =============================================================================

-- =============================================================================
-- Function used to adjust angle with the aimbot.
-- =============================================================================
function Aimbot:AdjustAngle( CUserCMD, AimAngle, Best, SWEP )
    AimAngle = AimAngle:Angle( )

    -- Compensate our recoil/spread.
    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Compensate Accuracy' ] then 
        AimAngle = Prediction:Calculate( CUserCMD, AimAngle, SWEP )
    end

    -- Set autostop.
    Main.Autostop = true

    -- Calculate our final angle.
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Silent' ] then 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Silent Mode' ] == 'Serverside' then 
            if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Force Facestab' ] then 
                CUserCMD:SetViewAngles( Best.ENT:EyeAngles( ) )
            end 

            proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

            proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, AimAngle:Forward( ) )
        else 
            CUserCMD:SetViewAngles( AimAngle )
        end
    else 
        if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Smoothing' ] then 
            AimAngle = LerpAngle( ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Smoothing Amount' ] / ( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Ratio' ] * 100 ) ), CUserCMD:GetViewAngles( ), AimAngle )
        end 

        proxi.SetViewAngles( AimAngle )
        CUserCMD:SetViewAngles( AimAngle )
    end
end