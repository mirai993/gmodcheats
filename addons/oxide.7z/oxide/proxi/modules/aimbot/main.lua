/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Aimbot Booter Module
-- =============================================================================

Aimbot = { }

-- Constants
Aimbot[ 'Sandbox SWEPs' ] = {
    [ 'gmod_camera' ] = true,
    [ 'weapon_medkit' ] = true,
    [ 'gmod_tool' ] = true,
    [ 'weapon_physcannon' ] = true,
    [ 'weapon_physgun' ] = true
}

-- Booters
Main:LoadFile( 'lua/oxide/modules/aimbot/prediction/weapon.lua' )
Main:LoadFile( 'lua/oxide/modules/aimbot/prediction/record.lua' )

Main:LoadFile( 'lua/oxide/modules/aimbot/aimbot/hitboxes.lua' )
Main:LoadFile( 'lua/oxide/modules/aimbot/aimbot/target.lua' )

Main:LoadFile( 'lua/oxide/modules/aimbot/aimbot/angle.lua' )

Main:LoadFile( 'lua/oxide/modules/aimbot/tick/tick.lua' )

-- =============================================================================
-- Main Aimbot handler function.
-- @param CUserCMD (cusercmd): CUserCMD provided by CreateMove.
-- =============================================================================
function Aimbot:Aimbot( CUserCMD )
    proxi._R.ConVar.ForceBool( Optimization:ConVar( 'cl_interpolate' ), true ) 
    proxi._R.ConVar.ForceFloat( Optimization:ConVar( 'cl_interp' ), 0.1 )

    if CUserCMD:CommandNumber( ) == 0 then 
        return
    end

    -- Enabled or dead.
    if not Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled' ] or not Optimization:Fetch( 'LocalPlayer', 'Alive' ) then 
        self.aimTarget = NULL -- Just in case.
        return 
    end 

    -- Can shoot weapon.
    local SWEP = Optimization:Fetch( 'LocalPlayer', 'SWEP' )
    
    if not SWEP:IsValid() then 
        return 
    end

    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Ignore Sandbox SWEPs' ] and self[ 'Sandbox SWEPs' ][ SWEP:GetClass( ) ] then 
        return 
    end

    -- Delay.
    if not Weapon:CanAttack( Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Delay' ] and Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Delay Amount' ] or 0, SWEP ) then 
        CUserCMD:RemoveKey( IN_ATTACK )         
        return
    end 

    -- Reset our aim target.
    self.aimTarget = NULL

    -- Menu opened.
    if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid When Menu Opened' ] and Main.Elements[ 'Menu Reference' ]:IsVisible( ) then 
        return 
    end

    -- Keybind
    if not Main:InputDown( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled Bind' ], Main.Elements[ 'Aimbot' ][ 'General' ][ 'Enabled Bind Style' ] == 'Toggle' ) then return end 

    -- Avoid sticky.    
    if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Avoid Sticky' ] then 
        local Stuck = Optimization:Fetch( 'LocalPlayer', 'Eye Trace' ).Entity

        if Stuck and Stuck:IsPlayer( ) then 
            return 
        end
    end 

    -- Find our target.
    local Best;

    local Limit   = { 
        Enabled = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Limit Targets' ], 
        Targets = Main.Elements[ 'Aimbot' ][ 'General' ][ 'Max Targets' ],
        Counter = 0
    }

    local Targets = Main.Entities

    for i = 1, #Targets do 
        local ENT = Targets[ i ]

        if self:Exclude( ENT ) then continue end 

        local Record = Records:Construct( ENT )

        if Record then 
            local Hitbox = self:FindHitbox( Record )

            if Hitbox and self:SelectTarget( Record, Best, Hitbox, CUserCMD ) then 
                Best = Record

                Best.Aim = Hitbox

                if Limit.Enabled then 
                    Limit.Counter = Limit.Counter + 1

                    if Limit.Counter >= Limit.Targets then 
                        break
                    end
                end
            end
        end

        if Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Prediction' ] != 'Backtrack' or not ENT:IsPlayer( ) then continue end 

        Record = Records:FindLastRecord( ENT )

        if Record then 
            if not Records:Validate( Record ) then continue end

            local Hitbox = self:FindHitbox( Record )
    
            if Hitbox and self:SelectTarget( Record, Best, Hitbox, CUserCMD ) then 
                Best = Record

                Best.Aim = Hitbox

                if Limit.Enabled then 
                    Limit.Counter = Limit.Counter + 1

                    if Limit.Counter >= Limit.Targets then 
                        break
                    end
                end
            end
        end
    end

    if not Best or not Best.Aim then return end
    
    -- Crossbow Prediction
    if Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Predict Bow' ] and SWEP:GetClass( ) == 'weapon_crossbow' then 
        Best.Aim = Prediction.HL2:Crossbow( CUserCMD, Best.Aim, Best.ENT, TICK_TO_TIME( 100 ) )
    end  

    -- Adjust for tick and calculate angle.
    local AimAngle = ( Best.Aim - Optimization:Fetch( 'LocalPlayer', 'Eye' ) )
    
    if Best.Tick then 
        local Pred = Main.Elements[ 'Aimbot' ][ 'Target Selection' ][ 'Prediction' ]

        if Pred == 'Leading' then 
            local predAmount = TIME_TO_TICK( proxi.GetFlowIncoming( ) + proxi.GetFlowOutgoing( ) )

            AimAngle = AimAngle + ( Best.ENT:GetVelocity( ) * ( Interval( ) * predAmount ) )

            proxi._R.CUserCmd.SetTickCount( CUserCMD, ( TIME_TO_TICK( Best.Tick ) + predAmount ) - 1 )
        elseif Pred == 'Lock' then
            proxi._R.CUserCmd.SetTickCount( CUserCMD, TIME_TO_TICK( Best.Tick + LerpAmount( ) ) )
        elseif Pred == 'Backtrack' then 
            proxi._R.CUserCmd.SetTickCount( CUserCMD, TIME_TO_TICK( Best.Tick ) )

            proxi._R.ConVar.ForceBool( Optimization:ConVar( 'cl_interpolate' ), false ) 
            proxi._R.ConVar.ForceFloat( Optimization:ConVar( 'cl_interp' ), 0 )
        end

        -- Don't set this shit otherwise because desynculator will break ticks.
    end 

    -- Set our angle.
    self:AdjustAngle( CUserCMD, AimAngle, Best, SWEP )

    -- Autoshoot.
    if Main.Elements[ 'Aimbot' ][ 'General' ][ 'Auto Shoot' ] then 
        CUserCMD:AddKey( Main.Elements[ 'Aimbot' ][ 'General' ][ 'Auto Shoot Mode' ] == 'Left' and IN_ATTACK or IN_ATTACK2 )
    end

    self.aimTarget = Best
end