/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Record Module
-- =============================================================================

-- Main Table
Tick = { 
    Previous = false,

    Times = {
        Warp = 0,
        Charge = 0,
        ChargeSeq = proxi.GetSequenceNumber( )
    }
}

-- =============================================================================
-- Function used to force two (or more) shots at once using sequences.
-- @param CUserCMD (cusercmd): CUserCMD provided by StartCommand.
-- =============================================================================
function Tick:Doubletap( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Doubletap' ] then return end

    local SWEP = Optimization:Fetch( 'LocalPlayer', 'SWEP' )

    if not SWEP or not SWEP:IsValid( ) then return end 

    local Current = Optimization:KeyPressed( IN_ATTACK )

    if Current and Weapon:CanAttack( 0, SWEP ) then 
        if self.Previous then 
            proxi.SetSequenceNumber( proxi.GetSequenceNumber() + math.floor( 1 / Main.Interval ) - 1 )
        end

        self.Previous = not self.Previous 
    end
end

-- =============================================================================
-- Function used to warp quickly using sequences.
-- @param CUserCMD (cusercmd): CUserCMD provided by StartCommand.
-- =============================================================================
function Tick:Warp( CUserCMD )
    if not Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Tickwarp' ] then return end 

    local CurTime = CurTime( )

    if Main:InputDown( Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Tickwarp Bind' ], false ) then 
    	if CurTime >= self.Times.Warp then
            proxi.SetSequenceNumber( proxi.GetSequenceNumber() + ( ( Optimization:ConVar( 'sv_maxusrcmdprocessticks' ):GetInt( ) * ( Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Warp Amount' ] / 100 ) ) - 2 ) )

            self.Times.Warp = CurTime + ( Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Warp Attack' ] / 100 )
        end
    else 
		if CurTime < self.Times.Warp then
            if CurTime - self.Times.Charge >= 0.02 then
				self.Times.ChargeSeq = proxi.GetSequenceNumber( )
				self.Times.Charge = CurTime
            else
                proxi.SetSequenceNumber( self.Times.ChargeSeq )
            end 
        end
    end
end