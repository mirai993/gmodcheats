/*
              _     __   
  ____  _  __(_)___/ /__ 
 / __ \| |/_/ / __  / _ \
/ /_/ />  </ / /_/ /  __/
\____/_/|_/_/\__,_/\___/ 
    by paradox & rari
*/

-- =============================================================================
-- Optimization Module
-- =============================================================================

-- Main Table
Optimization = { 
    ConVars = { },
    Localizer = { }
}

-- =============================================================================
-- Menu Helper Sub-Module
-- =============================================================================

-- =============================================================================
-- Function used to see if a key is pressed and checkbox is checked.
-- @param Element (table): The table of elements relative to the menu.
-- @param Lookup (name): The key value to look in the table for.
-- @param Bind (bool): Should the keybind be toggle.
-- @return bool: Should the menu element in question be active.
-- =============================================================================
function Optimization:IsActive( Element, Lookup, Bind )
    local Valid = Element[ Lookup ]

    -- Check for internal bind.
    if Bind != nil and not Main:InputDown( Element[ Lookup ], Bind ) then
        return false
    end

    return Valid
end

-- =============================================================================
-- Key Sub-Module
-- =============================================================================

-- =============================================================================
-- Function used to see if a key is pressed.
-- @param IN (number): The IN enum of the key.
-- @return bool: Was the key down, will be false if not found or if not held.
-- =============================================================================
function Optimization:KeyPressed( IN )
    -- Won't be used for internal menu keybinds but will be used for any hardcoded CUserCMD keybinds.

    local bitFlag = Optimization:Fetch( 'LocalPlayer', 'Buttons' )

    if not bitFlag then 
        return false
    end

    return bit.band( bitFlag, IN ) != 0
end

-- =============================================================================
-- Angle Sub-Module
-- =============================================================================

-- =============================================================================
-- Function used to set the view angles of ourself with specific settings.
-- @param New (angle): The angle to set.
-- @param CUserCMD (cusercmd): The CUserCMD of the call.
-- @param Silent (bool): The silent setting.
-- @param Mode (number): The silent mode setting.
-- @param Engine (number): The engine prediction setting. Optional
-- =============================================================================
function Optimization:Angle( New, CUserCMD, Silent, Mode, Engine )
    Engine = Engine or Main.Elements[ 'Aimbot' ][ 'Accuracy' ][ 'Engine Prediction (!)' ]

    if Engine then 
        proxi.StartPrediction( CUserCMD )
    end 

    if Silent then 
        if Mode == 'Serverside' then 
            proxi._R.CUserCmd.SetInWorldClicker( CUserCMD, true )

            proxi._R.CUserCmd.SetWorldClickerAngles( CUserCMD, New:Forward( ) )
        else 
            CUserCMD:SetViewAngles( New )
        end
    else 
        proxi.SetViewAngles( New )
    end

    if Engine then 
        proxi.EndPrediction( )
    end 
end

-- =============================================================================
-- ConVar Sub-Module
-- =============================================================================

-- =============================================================================
-- Function used to grab a ConVar object.
-- @param Name (string): The ConVars name.
-- =============================================================================
function Optimization:ConVar( Name )
    if not self.ConVars[ Name ] then 
        self.ConVars[ Name ] = proxi.GetConVar( Name )
    end

    return self.ConVars[ Name ]
end

-- =============================================================================
-- Localizer Sub-Module
-- =============================================================================

-- =============================================================================
-- Function used to grab a localization from the localizer.
-- @param Key (string): The localizer cache key.
-- @param Sub-Key (string): The localizer cache sub value to look for (health for example).
-- @return any: Whatever value the localizer stored. Will be nil if not found.
-- =============================================================================
function Optimization:Fetch( Key, Sub )
    local Cache = self.Localizer[ Key ]

    if not Cache then 
        return -- Couldn't find the cache entry.
    end

    return Cache[ Sub ]
end

-- =============================================================================
-- Internal function used to grab a localization from the localizer.
-- @param Key (string): The localizer cache key.
-- @param Subs (table): The list of things to set in the cache. Will dynamic loop
-- so you don't need to actually have EVERYTHING just the stuff to override.
-- =============================================================================
function Optimization:Set( Key, Subs )
    self.Localizer[ Key ] = self.Localizer[ Key ] or { }

    for k,v in pairs( Subs ) do
        self.Localizer[ Key ][ k ] = v
    end
end

-- =============================================================================
-- Internal function used to handle the localizers localizations.
-- @param CUserCMD (cusercmd): The CUserCMD from CreateMove.
-- =============================================================================
function Optimization:Localizers( CUserCMD )
    -- Cleanup old player cache.
    for k,v in pairs( self.Localizer ) do
        if not IsValid( k ) then
            self.Localizer[ k ] = nil 
        end
    end

    -- LocalPlayer caches.
    Optimization:Set( 'LocalPlayer', {
        -- Health stuff.
        [ 'Health' ] = Main.Local:Health( ),
        [ 'Max Health' ] = Main.Local:GetMaxHealth( ),

        [ 'Alive' ] = Main.Local:Alive( ),

        [ 'Armor' ] = Main.Local:Armor( ),
        [ 'Max Armor' ] = Main.Local:GetMaxArmor( ),

        -- Eye stuff.
        [ 'Eye' ] = Main.Local:EyePos( ),

        [ 'Eye Trace' ] = Main.Local:GetEyeTrace( ),

        -- CUserCMD stuff.
        [ 'Tick' ] = CUserCMD:TickCount( ),
        [ 'Buttons' ] = CUserCMD:GetButtons( ),

        [ 'Side Move' ] = CUserCMD:GetSideMove( ),
        [ 'Forward Move' ] = CUserCMD:GetForwardMove( ),

        [ 'Angles' ] = CUserCMD:GetViewAngles( ),

        -- SWEP stuff.
        [ 'SWEP' ] = Main.Local:GetActiveWeapon( ),

        -- Internal stuff.
        [ 'Ping' ] = proxi.GetFlowIncoming( ) + proxi.GetFlowOutgoing( ),

        [ 'Tickbase' ] = Main.Local:GetInternalVariable( 'm_nTickBase' )
    } )

    -- Other player caches.
    local Players = player.GetAll( )

    for i = 1, #Players do
        local ENT = Players[ i ]

        if not ENT or ENT == Main.Local then 
            continue 
        end

        if ENT:IsDormant( ) then 
            continue
        end

        Optimization:Set( ENT, {
            -- Health stuff.
            [ 'Health' ] = ENT:Health( ),
            [ 'Max Health' ] = ENT:GetMaxHealth( ),

            [ 'Alive' ] = ENT:Alive( ),

            [ 'Armor' ] = ENT:Armor( ),
            [ 'Max Armor' ] = ENT:GetMaxArmor( ),

            -- SWEP stuff.
            [ 'SWEP' ] = ENT:GetActiveWeapon( )
        } )
    end
end