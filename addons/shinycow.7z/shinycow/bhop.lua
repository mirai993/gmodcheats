--[[
	MOD/lua/shinycow/bhop.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:28PM]
	===BadFile===
]]

---------------------- shittily made, made just for bored nights since my fps.
---- oh, and i made it at 1 am. so there's that too.

local SCE = {}

local hook = hook
local RunConsoleCommand = RunConsoleCommand
local timer = timer
local AddConsoleCommand = AddConsoleCommand

local function sce_AddCommand( cmd, func, help )
	SCE[ "sc_" .. cmd:lower() ] = {Function = func, Help = help}
	AddConsoleCommand( "sc_" .. cmd:lower(), help )
end

local oldICC = InjectConsoleCommand
function InjectConsoleCommand( player, command, arguments, args )
	if SCE[ command:lower() ] then
		SCE[ command:lower() ].Function( player, command, arguments, args )
		return true
	end
	
	oldICC( player, command, arguments, args )
end

--concommand.Add("sc_togglethisshit", function()
sce_AddCommand( "togglethisshit", function()
	if LocalPlayer().IsHopping == nil then
		LocalPlayer().IsHopping = true
	else
		LocalPlayer().IsHopping = not LocalPlayer().IsHopping
	end
end, "Toggle bhop." )

hook.Add("Think", "bunnyhop", function()
--hook.Add("CreateMove", "sc_hawhop", function( pl, cmd )
	if LocalPlayer():IsOnGround() and LocalPlayer().IsHopping then
		RunConsoleCommand("+jump")
		--cmd:SetButtons( IN_JUMP )
		timer.Simple(0.2, function()
			RunConsoleCommand("-jump")
		end)
	end
end)