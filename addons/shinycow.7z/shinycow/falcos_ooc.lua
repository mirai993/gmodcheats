--[[
	MOD/lua/shinycow/falcos_ooc.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:29PM]
	===BadFile===
]]

----- THIS IS NOT FALCO's OOC.
----- IT'S CODE TO EXPLOIT PEOPLE USING IT. And it's hilarious.

for i=1,3 do
	timer.Simple( i - (i-1), function()
		RunConsoleCommand("say", "of course")
	end )
end