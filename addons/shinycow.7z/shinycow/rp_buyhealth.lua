--[[
	MOD/lua/shinycow/rp_buyhealth.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:32PM]
	===BadFile===
]]

if not string.find(string.lower(gmod.GetGamemode().Name:lower()), "darkrp") then print("not darkrp. stopping script.") return end
if not GAMEMODE.Config["enablebuyhealth"] then print("Buying health is disabled!") return end

hook.Add("Think", "buymyhealth", function()
	if LocalPlayer():Health() <= 69 and LocalPlayer():Alive() and team.NumPlayers(TEAM_MEDIC) < 1 and (LocalPlayer().DarkRPVars.money > 4000) then
		RunConsoleCommand("say", "/buyhealth")
	end
end)