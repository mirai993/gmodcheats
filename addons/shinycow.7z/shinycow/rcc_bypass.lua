--[[
	MOD/lua/shinycow/rcc_bypass.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:31PM]
	===BadFile===
]]

local _R = debug.getregistry()
local oRCC = RunConsoleCommand
local oPCC = _R.Player.ConCommand
local oIM = IncomingMessage

CreateClientConVar("shinycow_logcommands", 0, true, false)
CreateClientConVar("shinycow_commandblacklist", 0, true, false)

local cmdblacklist = {}
if file.Exists("shinycow/cmds.txt", "DATA") then
	local data = util.JSONToTable( file.Read("shinycow/cmds.txt", "DATA") )
	
	for k,v in pairs(data) do
		cmdblacklist[ k ] = true
	end
end


function RunConsoleCommand( ... )
	local args = {...}
	if GetConVarNumber("shinycow_logcommands") >= 1 then
		if args[1] then
			LocalPlayer():ChatPrint("Running " .. args[1])
		end
		for i=2,#args do
			LocalPlayer():ChatPrint("With args: " .. args[i])
		end
	end
		
	if args[1] != "precision_nudge" then
		oRCC( ... )
	end
end

function _R.Player:ConCommand( str_command )
	if GetConVarNumber("shinycow_logcommands") >= 1 then
		LocalPlayer():ChatPrint("Forced console command: " .. tostring(str_command))
	end
	
	oPCC( self, str_command )
end

function IncomingMessage( MessageName, msg )
	if GetConVarNumber("shinycow_logcommands") >= 1 then
		LocalPlayer():ChatPrint("Usermessage hook: " .. MessageName)
	end
	
	oIM( MessageName, msg )

	--[[if ( Hooks[ MessageName ] ) then
	
		Hooks[ MessageName ].Function( msg, unpack(Hooks[ MessageName ].PreArgs) )
		return
	
	end
	
	Msg("Warning: Unhandled usermessage '"..MessageName.."'\n")]]

end


concommand.Add("sc_rcc", function()
	local mainmenu = vgui.Create("DFrame")
	mainmenu:SetSize( ScrW() / 2, ScrH() / 2 )
	mainmenu:Center()
	mainmenu:SetTitle( "Add / Remove blacklisted commands." )
	mainmenu:SetDraggable( true )
	mainmenu:SetVisible( true )
	mainmenu:MakePopup()
	
	--local 
end)