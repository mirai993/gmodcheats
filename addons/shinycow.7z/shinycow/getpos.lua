--[[
	MOD/lua/shinycow/getpos.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:29PM]
	===BadFile===
]]

concommand.Add("getpos2", function( pl )
	local pos = pl:GetPos()
	
	SetClipboardText( pos.x .. ", " .. pos.y .. ", " .. pos.z )
end)