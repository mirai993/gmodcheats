--[[
	MOD/lua/shinycow/esp.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:28PM]
	===BadFile===
]]

local SCE = {}
local sc_materialon = false

local debug = debug
local CreateClientConVar = CreateClientConVar
local gameevent = gameevent

local _R = debug.getregistry()
local scSetMat = _R.Entity.SetMaterial

local AddConsoleCommand = AddConsoleCommand

gameevent.Listen("player_spawn")

local function sce_AddCommand( cmd, func, help )
	SCE[ "sc_" .. cmd:lower() ] = {Function = func, Help = help}
	AddConsoleCommand( "sc_" .. cmd:lower(), help )
end

local oldICC = InjectConsoleCommand
function InjectConsoleCommand( player, command, arguments, args )
	if SCE[ command:lower() ] then
		SCE[ command:lower() ].Function( player, command, arguments, args )
		return true
	end
	
	oldICC( player, command, arguments, args )
end

local function SC_SetMaterial( ent )
	if sc_materialon then
	
		scSetMat( ent, "mat1" )
	
	else
	
		scSetMat( ent, "" )
		
	end
end

hook.Add("HUDPaint", "idksomeesp", function()
	for i=1,#player.GetAll() do
		local v = player.GetAll()[ i ]
		
		if v == LocalPlayer() then continue end
		
		surface.SetDrawColor( team.GetColor(v:Team()) )
				--gets the center of the screen
		--local x = v:GetPos():ToScreen().x
		--local y = v:GetPos():ToScreen().y
		local x = v:GetPos():ToScreen().x
		local y = v:GetPos():ToScreen().y
		
		print("y" .. y)
		 
		local gap = 5
		local getpos = LocalPlayer():GetPos():Distance( v:GetPos() )
		local distance = getpos / (getpos * 10)
		--local length = gap + (distance - 800)
		local eyepos = LocalPlayer():EyePos().x
		--print("eyeeeeeee " .. eyepos)
		if eyepos < 1000 then eyepos = 1000 end
		local length = gap + (distance - 800) + eyepos
		--if length < 225 then length = 225 end
		--print(length)
		if length > 1200 then length = 1200 end
		if y > 345 then y = 345 end
		print("x " ..x)		
		
		--print(y - length)
		--print(y - gap)
		--[[if (y - length) < -850 then
			print("YEEEEEEEEEEEEEEEEEEE")
			surface.DrawLine( x, -850, x, y - gap )
		else]]
			print( y - length )
			surface.DrawLine( x, y - length, x, y - gap )
		--end
	 
		--surface.DrawLine( v:GetPos():ToScreen().x, v:GetPos():ToScreen().y , v:GetPos():ToScreen().x, v:GetPos():ToScreen().y - 50 )
		--surface.DrawLine( v:GetPos():ToScreen().x + 5, v:EyePos():ToScreen().y, v:GetPos():ToScreen().x, v:EyePos():ToScreen().x)
	end
end)

hook.Add("PreDrawHalos", "sc_halos", function()
	halo.Add( ents.FindByClass( "Player" ), Color( 255, 0, 0 ), 1, 1, 1 )
end )

hook.Add("player_spawn", "idklisten", function( data )
	SC_SetMaterial( Player( data.userid ) )
end)

--sce_AddCommand( "esp_toggle", function() sc_materialon = not sc_materialon end )
local function espnow()
	for k,v in pairs(player.GetAll()) do
		
		if v:Alive() then
		
			SC_SetMaterial( v )
			
		end
	end
end
timer.Create("refresh", 3, 0, espnow)

sce_AddCommand( "esp_toggle", function()
	sc_materialon = not sc_materialon
	
	espnow()
end )