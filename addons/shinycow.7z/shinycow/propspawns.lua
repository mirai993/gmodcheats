--[[
	MOD/lua/shinycow/propspawns.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:30PM]
	===BadFile===
]]

CreateClientConVar("shinycow_propspawns", "0", true, false)

	-- propspawns
	--		name
	--			1: model
	--			2: model
local propspawns = {}

gameevent.Listen("player_connect")

for i=1,#player.GetAll() do
	propspawns[ player.GetAll()[ i ] ] = {}
end
hook.Add("player_connect", "shinyshinyshinycow", function( data )
	timer.Simple(0.5, function()
		propspawns[ Player(data.userid) ] = {}
	end)
end)

hook.Add("OnEntityCreated", "shinycow_logpropspawns", function( ent )
	if GetConVarString("shinycow_propspawns") != "1" then return end
	
	local found = false
	
	if not IsValid(ent) then return end
	if ent:GetModel() == nil then return end
	
	for i=1,#player.GetAll() do
		player.GetAll()[ i ].PropLookingAt = ent
	end
	
	for i=1,#player.GetAll() do
		local v = player.GetAll()[ i ]
		
		if v:GetEyeTrace().Entity == ent then
			print(v:Nick() .. " " .. ent:GetModel())
			propspawns[ v ][ #propspawns[ v ] + 1 ] = ent:GetModel()
			found = true
		end
	end
	
	if not found then print("NULL ENTITY FDSFDASF - " .. ent:GetModel()) end
end)

concommand.Add("sc_printprops", function()
	PrintTable(propspawns)
end)