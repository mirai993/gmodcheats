--[[
	MOD/lua/shinycow/propinfo.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:30PM]
	===BadFile===
]]

local CreateClientConVar = CreateClientConVar

-- Should print the info of all new props spawned. Includes radius. Set to 0 to disable.
CreateClientConVar( "shinycow_propinfo_radius", 0, true, false)

local function printInfo( args )
	if IsValid( args ) then
		print("\nPrinting " .. args:GetClass())
		print("Model: " .. args:GetModel())
		print("Pos: " .. tostring(args:GetPos()))
		print("Angles: " .. tostring(args:GetAngles()))
		print("Skin: " .. args:GetSkin())
		if IsValid(args:GetPhysicsObject()) then
			print("Mass: " .. args:GetPhysicsObject():GetMass())
			print("Volume: " .. args:GetPhysicsObject():GetVolume())
		end
		print("\n")
	end
end

concommand.Add("sc_propinfo", function( pl, cmd, args )
	if not IsValid( pl ) then return end
	if not IsValid( pl:GetEyeTrace().Entity ) then return end
	
	printInfo( pl:GetEyeTrace().Entity )
	
		-- we're assuming they want to copy the position
	if args[1] and args[1] == "copy" then
		SetClipboardText( pl:GetEyeTrace().Entity:GetPos().x .. ", " .. pl:GetEyeTrace().Entity:GetPos().y .. ", " .. pl:GetEyeTrace().Entity:GetPos().z)
	end
end)

hook.Add("OnEntityCreated", "shinycow_propinfo", function( ent )
	if GetConVarNumber("shinycow_propinfo_radius") < 1 then return end
	
	for k,v in pairs(ents.FindInSphere( LocalPlayer():GetPos(), GetConVarNumber("shinycow_propinfo_radius") )) do
		if ent == v then
			printInfo( v )
		end
	end
end)
