--[[
	MOD/lua/shinycow/admencheck.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:27PM]
	===BadFile===
]]

if not ULib then return end

for k,v in pairs(ULib.ucl.authed) do
	if not v.guest then
		LocalPlayer():ChatPrint(v.name)
		for a,b in pairs(v.allow) do
			print(tostring(k), tostring(v))
		end
	end
end