--[[
	MOD/lua/shinycow/spamips.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:34PM]
	===BadFile===
]]

--[[
	Hi from Shinycow!
]]--

local random_ips =
{
"12.23.242.160",
"210.197.53.37",
"77.163.158.97",
"24.246.243.138",
"175.213.67.97",
"96.34.16.96",
"100.221.2.24",
"111.184.225.122",
"207.213.28.162",
"156.80.198.232",
"242.101.74.11",
"93.62.148.13",
"21.215.110.117",
"248.126.212.93",
"92.214.117.203",
"143.88.70.95",
"46.97.2.202",
"176.200.179.164",
"47.253.175.139",
"61.69.152.81",
"29.8.198.23",
"133.155.116.225",
"115.233.173.3",
"67.242.98.113",
"85.100.60.7",
"45.238.170.91",
"237.90.230.44",
"158.128.124.187",
"135.68.210.13",
"223.72.237.83"
}

local say_what = "I hab IPS - "

	-- Type in console "shinycow_spamips <0/1>" to enable/disable.
CreateClientConVar("shinycow_spamips", 0, true, false)

hook.Add("CreateMove", "shinycow_rafdsf", function()
	if not tobool(GetConVar("shinycow_spamips"):GetInt()) then return end
	
	RunConsoleCommand("say", say_what .. random_ips[ math.random(1, #random_ips) ])
end)
