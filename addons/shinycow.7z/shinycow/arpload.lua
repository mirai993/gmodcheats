--[[
	MOD/lua/shinycow/arpload.lua
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:27PM]
	===BadFile===
]]

if string.find(string.lower(gmod.GetGamemode().Name), "darkrp") then 
	timer.Create("fds", 1.3, 0, function() RunConsoleCommand("_DarkRP_DoAnimation", "1616") end)
end
--timer.Create("hah", 1.1, 0, function() RunConsoleCommand("say", "/advert Removing all autists.") end)

local haha =
{
"gmod_tool",
"weapon_physgun",
"weapon_physcannon"
}

timer.Create("haha", 3, 0, function()
	if LocalPlayer():Alive() and IsValid(LocalPlayer():GetActiveWeapon()) then
		if not table.HasValue(haha, LocalPlayer():GetActiveWeapon():GetClass()) then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
			LocalPlayer():GetActiveWeapon().Primary.Cone = 0
		end
	end
end)

timer.Create("nodurgz", 3, 0, function()
	for k,v in pairs(hook.GetTable()["RenderScreenspaceEffects"]) do
		if string.find(string.lower(tostring(k)), "durgz_") then
			hook.Remove("RenderScreenspaceEffects", k)
		end
	end
	--hook.Remove("RenderScreenspaceEffects", "durgz_weed_high")
	--hook.Remove("RenderScreenspaceEffects", "durgz_
end)

include("trackplayers.lua")
include("rp_buyhealth.lua")
include("rp_police.lua")
include("bhop.lua")