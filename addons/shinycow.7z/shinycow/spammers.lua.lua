--[[
	MOD/lua/shinycow/spammers.txt
	Shinycow ت | (STEAM_0:0:29257121) | [06-08-13 07:36:34PM]
	===BadFile===
]]


#     89 "coolgamer48"       STEAM_0:0:65985952   1:32:06    96    0 active

#    155 "Fox McCloud"       STEAM_0:0:60799558  05:43       75    0 active

STEAM_0:1:52737786 - Reflex. Mass propkilling / propspamming almost crashed serber.

STEAM_0:1:62797365 - http://steamcommunity.com/profiles/76561198085860459 - "GamingFuck" - "theimortalfire"
	Propspammed massively almost crahsed server.
	
STEAM_0:0:47797683 - Venom - massive propspam

	-- watchlist
STEAM_0:0:36279058 - Fax160 - http://steamcommunity.com/profiles/76561198032823844 - massive propspam
	-- watchlist

STEAM_0:0:40789323 - Almighty Loaf - http://steamcommunity.com/profiles/76561198041844374 - masisve propspam

STEAM_0:1:59780351 - Nate0323 - http://steamcommunity.com/profiles/76561198079826431 - massive propspam