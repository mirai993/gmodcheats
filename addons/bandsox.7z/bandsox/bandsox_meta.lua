--[[
	bandsox/meta.lua
	Stoned
	===DStream===
]]

	print("[BandSox] Meta Backups!")
	
	dgi = debug.getinfo
	dgu = debug.getupvalue

	angMeta = table.Copy(_R["Angle"])
	cmdMeta = table.Copy(_R["CUserCmd"])
	entMeta = table.Copy(_R["Entity"])
	plyMeta = table.Copy(_R["Player"])
	vecMeta = table.Copy(_R["Vector"])
	
	old_gin = plyMeta.GetInfo
	old_pcc = plyMeta.ConCommand
	old_rcc = _G.RunConsoleCommand
	old_had = _G.hook.Add
	old_hrm = _G.hook.Remove
	old_hgt = _G.hook.GetTable
	old_gcv = _G.GetConVar
	old_gcn = _G.GetConVarNumber
	old_inc = _G.include
	old_htg = _G.http.Get
	old_smt = entMeta.SetMaterial
	old_scl = entMeta.SetColor
	old_tsc = vecMeta.ToScreen
	old_ffi = _G.file.Find
	old_frd = _G.file.Read
	old_fwr = _G.file.Write
	old_req = _G.require
	old_vgr = vgui.Register
	old_tic = timer.Create
	old_umh = usermessage.Hook
	old_umi = usermessage.IncomingMessage
	--old_sts = _G.datastream.StreamToServer
	drv_tbl = {}
	old_drv = _G.DeriveGamemode

	file.Write("bandsox/loaded.txt","0",true)
	bs = true
	
	function file.Read(str,skip)
		print("Detour (read): "..str)
		if skip then return old_frd(str) end
		return ""--old_frd(str)	
	end
	
	function file.Find(str,skip)
		print("Detour (find): "..str)
		if skip then return old_ffi(str) end
		return {}--old_ffi(str)	
	end
	
	function debug.getinfo(...)
		local p,a,b,c = dgi(...)
		if p and p.short_src == "bandsox/bandsox.lua" then
			p.short_src = "=[C]"
		end
		if p and p.source == "@bandsox/bandsox.lua" then
		    p.source = "=[C]"
		end
		return p,a,b,c
	end
	
	function debug.getupvalue(...)
		local name,tbl = dgu(...)
		if name == "Hooks" then
			tbl = {}	
		end
		return name,tbl
	end
	
	function debug.getlocalvar(func,str)
		local tbl = dgi(func)
		for i=1,tbl.nups do
			local vali,val = dgu(func,i)
			if str == vali then return val end                                                          
		end
	end
	
	function debug.getparams(f)
		local co = coroutine.create(f)
		local params = {}
		debug.sethook(co, function(event, line)
			local i, k, v = 1, debug.getlocal(co, 2, 1)
			while k do
				if k ~= "(*temporary)" then
					table.insert(params, k)
				end
				i = i+1
				k, v = debug.getlocal(co, 2, i)
			end
			error("~~end~~")
		end, "c")
		local res = {coroutine.resume(co)}
		if res[1] then
			error("The function provided defys the laws of the universe.", 2)
		elseif string.sub(tostring(res[2]), -7) ~= "~~end~~" then
			error("The function failed with the error: "..tostring(res[2]), 2)
		end
		return params
	end
	
	function _G.GetConVar(arg)
		local res = old_gcv(arg)
		if arg == "voice_inputfromfile" or arg == "sv_cheats" then
			CreateConVar("allways_0",0)
			return old_gcv("allways_0")
		end
		return res
	end
	
	function _R.Player:GetInfo(arg)
		local res = old_gin(self,arg)
  		if arg == "voice_inputfromfile" or arg == "sv_cheats" then
			return "0"
		end
		return res	
	end
	
	function _G.require(arg)
	    print("[BandSox] Debug: Required > "..arg)	
		return old_req(arg)
	end

	function _G.hook.GetTable()
		return {}
	end
	
	function _G.hook.Remove(name,unique)
		if table.HasValue(BandSox.Hooked,unique) then 
			print("[BandSox] Blocked Hook remove: ["..name.."] - "..unique)
			return 
		end
		print("[BandSox] Hook removed: ["..name.."] - "..unique)
		old_hrm(name,unique)	
	end