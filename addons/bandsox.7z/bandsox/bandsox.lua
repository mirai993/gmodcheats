--[[
	bandsox/bandsox.lua
	Stoned
	===DStream===
]]

BandSox = {
	Settings = {
		Filter = {
			["Human"] = false,
			["Team"] = false,
			["NPC"] = false,
			["Prop"] = false,
			["Bottle"] = false,		
		},
		Target = "screenpos",
		NoRecoil = true,
		BHop = true,
	},
	Hooks = {},
	Hooked = {},
	Commands = {},
	Lasthop = 0,
	Aimat = 0,
	Hl2Cones = {
		weapon_pistol = 0.00873,
		weapon_smg1 = 0.04362,
		weapon_smg2 = 0.08716, -- What weapon is that?
		weapon_shotgun = 0.08716,
		weapon_alyxgun = 0.01745,
		weapon_ar1 = 0.08716,  -- What weapon is that?
		weapon_ar2 = 0.02618,
		weapon_rpg = 0.02618,
	},

	MrGreenCones = {
		["pistol"] = { Cone = 0.1, Length = 14 },
		["smg"] = { Cone = 0.13, Length = 17 },
		["rifle"] = { Cone = 0.14, Length = 18 },
		["shotgun"] = { Cone = 0.26, Length = 22 },
		["admin"] = { Cone = 0.30, Length = 27 }
	},

}

if !hack then
	require("syshack")
end
require("dispatchum")

--RunString(file.Read("../lua/bandsox/recordmove.lua"))

hook.Add("DispatchUserMessage","BandSox - SendLua Block",function(typ,msg)
	if typ == 29 then -- SendLua
		ErrorNoHalt("[BandSox] SendLua: "..msg:ReadString().."\n")
	end
end)

function BandSox:Reload()
	self:Unload()
	RunString(file.Read("../lua/bandsox/bandsox.lua", "BandSox"))
	print("[BandSox] RunString'd self.")
end
concommand.Add("bs_reload",function() BandSox:Reload() end)

function BandSox:Unload()
	for name,tbl in pairs(self.Hooks) do
	    for unique,_ in pairs(tbl) do
			print("[BandSox] Unhooking ["..name.."] - "..unique)
			old_hrm(name,unique)
		end
	end
end
concommand.Add("bs_unload",function() BandSox:Unload() end)

function BandSox:Inject()
	-- ulib bro
	local ulib_tbl = select(2,dgu(hook.Call,3))
	for name,tbl in pairs(self.Hooks) do
	    for unique,func in pairs(tbl) do
			print("[BandSox] Injecting ["..name.."] - "..unique)
			if !ulib_tbl[name] then ulib_tbl[name] = {} end
			table.insert(ulib_tbl[name],{fn = func,name = unique,priority = 0})
		end
	end
	self.ULib = ulib_tbl	
end
concommand.Add("bs_inject",function() BandSox:Inject() end)

if (not bs) then
	RunString(file.Read("../lua/bandsox/meta.lua"))
end

RunString(file.Read("../lua/bandsox/hookmanager.lua", "BandSox"))

function LuaQuickRun()
	local qrpanel = vgui.Create("DFrame")
	qrpanel:SetPos(827,768)
	qrpanel:SetSize(963,44)
	qrpanel:SetTitle("")
	qrpanel:SetVisible(true)
	qrpanel:SetDraggable(false)
	qrpanel:SetScreenLock(false)
	qrpanel:ShowCloseButton(false)
	qrpanel.Paint = function()
	    surface.SetDrawColor(0,0,0,50)
	end
	qrpanel:MakePopup()

    local qrtext = vgui.Create("DTextEntry")
	qrtext:SetParent(qrpanel)
	qrtext:SetText("")
	qrtext:SetPos(5,22)
	qrtext:SetTall(25)
	qrtext:SetWide(qrpanel:GetWide()-10)
	qrtext:RequestFocus()
	qrtext.OnEnter = function()
		RunString(qrtext:GetValue())
		qrtext:SetText("")
		qrpanel:Close()
		--print(qrpanel:GetPos())
	end
end
concommand.Add("lua_run_quick",LuaQuickRun)

function BandSox:Hook(hookname,name,func)
	self.Hooks[hookname] = self.Hooks[hookname] or {}
	self.Hooks[hookname][name] = func
	table.insert(self.Hooked,name)
	hook.Add(hookname,name,func)
end

function BandSox:CallBack(cmd,arg)
	local tbl = {}
	local arg = arg:Trim()
	for k,v in pairs(self.Commands) do
		if v.c:find(arg) then
			table.insert(tbl,cmd.." "..v.c)
		end
	end
	return tbl
end

function BandSox:ConCommand(ply,cmd,arg)
	if #arg < 1 then
		table.sort(self.Commands,function(a,b) return a.c > b.c end)
		for k,v in pairs(self.Commands) do
			print("> "..k)
		end
	end
	for k,v in pairs(self.Commands) do
		if v.c == table.concat(arg," ") then
			print("> "..v.c)
			PrintTable(arg)
			local ok,err = pcall(v.f,arg)
			if !ok then print(err) end
		end
	end
end
concommand.Add("bs",function(p,c,a) BandSox:ConCommand(p,c,a) end,function(c,a) return BandSox:CallBack(c,a) end)

BandSox.BHClear = 0xFFFF - IN_JUMP
function BandSox:BunnyHop(ucmd)
	if self.Settings.BHop == true and (cmdMeta.GetButtons(ucmd) & IN_JUMP) > 0 then
		if entMeta.IsOnGround(LocalPlayer()) then
			cmdMeta.SetButtons(ucmd,cmdMeta.GetButtons(ucmd) | IN_JUMP)
		else
			cmdMeta.SetButtons(ucmd,cmdMeta.GetButtons(ucmd) & self.BHClear)
		end
		/*if (!LocalPlayer():IsOnGround()) then
			cmdMeta.SetButtons(ucmd, cmdMeta.GetButtons(ucmd) - IN_JUMP)
		end*/
	end
end
BandSox:Hook("CreateMove","BandSox - BunnyHop",function(ucmd) BandSox:BunnyHop(ucmd) end)

function BandSox:GetActiveWeapon(ply)
	ply = ply or LocalPlayer()
	local weapon, name = nil,"..."
	if IsValid(ply:GetActiveWeapon()) then
	    weapon = ply:GetActiveWeapon()
	    name = ply:GetActiveWeapon():GetPrintName()
	end
	return weapon,name
end

function BandSox:IsGamemode(name)
	local gm = GAMEMODE or gmod.GetGamemode()
	if (string.find(gm.Name,name)) then
		return true
	end
	return false
end

function BandSox:KeyDown(...)
	for k,key in pairs({...}) do
		if !input.IsKeyDown(key) then
			return false
		end
	end
	return true
end

local x,y = ScrW(),ScrH()
function BandSox:ForceLoad()
	hack.cvar.SetValue("sv_cheats",1)

	local forceenabled = false
	local forceindex = 7
	local forces = {
		"0",
		"0.1",
		"0.2",
		"0.3",
		"0.5",
		"0.75",
		"1",
		"1.2",
		"1.5",
		"2",
		"3",
		"5",
	}					

	local function ControlForce(ply,bind,pressed)
		if pressed and self:KeyDown(KEY_E) == true then
			if string.find(bind, "invprev") then
				forceindex = forceindex + 1
				if forceindex > #forces then
					forceindex = #forces
				end
				--chat.AddText(Color(0,0,255),"[Force]",Color(255,255,255)," Speed is now: "..forces[forceindex])
				hack.cvar.SetValue("host_timescale",forces[forceindex])
				return true
			elseif string.find(bind, "invnext") then
				forceindex = forceindex - 1
				if forceindex < 1 then
					forceindex = 1
				end
				--chat.AddText(Color(0,0,255),"[Force]",Color(255,255,255)," Speed is now: "..forces[forceindex])
				hack.cvar.SetValue("host_timescale",forces[forceindex])
				return true
			elseif string.find(bind, "reload") then
				forceindex = 7
				--chat.AddText(Color(0,0,255),"[Force]",Color(255,255,255)," Speed is has been reset.")
				hack.cvar.SetValue("host_timescale",forces[forceindex])
				return true
			end
		end
	end
	self:Hook("PlayerBindPress","BandSox - ForceCheck",ControlForce)
	self:Hook("HUDPaint","BandSox - Debug",function()
		draw.SimpleText("Speed: "..forces[forceindex],"BudgetLabel",x/2,y - 31,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM)	
	end)
end
concommand.Add("bs_force_load",function(p,c,a) BandSox:ForceLoad() end)

local TraitorGuns = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol"}

function BandSox:TraitorScan()
	if !self.Traitors then self.Traitors = {} end
	if !self:IsGamemode("Trouble in Terror") then return end
	
	for k,ply in pairs(player.GetAll()) do
		if ply ~= LocalPlayer() then
			for i,wep in pairs(ply:GetWeapons()) do
				if table.HasValue(TraitorGuns,wep:GetClass()) and !table.HasValue(self.Traitors,ply) then
					table.insert(self.Traitors,ply)
					chat.AddText(Color(255,255,255),ply:Name().." has collected a traitor weapon: "..wep:GetClass())
				end
			end
		end
		if table.HasValue(self.Traitors,ply) and (ply:Health() <= 0 or ply:GetMoveType() == MOVETYPE_OBSERVER) then
			for i,tra in pairs(self.Traitors) do
				if tra == ply then
					self.Traitors[i] = nil
				end
			end
		end
	end
end
BandSox:Hook("Think","BandSox - TraiorScan",function() BandSox:TraitorScan() end)

local m = FindMetaTable("Player")
function m:IsTraitor(ply)
	return table.HasValue(BandSox.Traitors,ply)
end

local umsg_inc = usermessage.IncomingMessage
function usermessage.IncomingMessage(name,um,...)
	if name == "ttt_role" then
		print("[BandSox] Clearing traitors - round end.")
		for k,ply in pairs(BandSox.Traitors) do
			print("[BandSox] Removing traitor "..ply:Name().." - the round has ended.")
			BandSox.Traitors[k] = nil
		end
	end	
	return umsg_inc(name,um,...)
end

function BandSox:Rates()
	old_rcc("cl_cmdrate","100")
	old_rcc("cl_updaterate","100")
	old_rcc("rate","50000")
end
timer.Create("BandSox - Rates Checker",5,0,function() BandSox:Rates() end)

function BandSox:Hud()
	local ply = LocalPlayer()
	local ent = ply:GetEyeTraceNoCursor().Entity
	local mdl,ang,pos,class,wep
	
	if IsValid(ent) then
		class = ent:GetClass()
		if class ~= "player" then
			local tbl = string.Explode("/",ent:GetModel())
			mdl = tbl[#tbl]
			ang = tostring(ent:GetAngles())
			pos = tostring(ent:GetPos())
		end
		if class == "class C_World" then
			class = "..."
		elseif class == "class C_BaseEntity" then
			class = "func_button"
		end
	else
		class = "..."
	end

	if IsValid(ply) then
		wep = IsValid(ply:GetActiveWeapon()) and ply:GetActiveWeapon():GetClass() or "..."
	end

	draw.SimpleText("Ent: "..class,"BudgetLabel",x/2,y/2 + 70,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	draw.SimpleText("Weapon: "..wep,"BudgetLabel",x/2,y - 16,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM)
	if class ~= "player" and class ~= "..." then
		draw.DrawText("Model: "..mdl.."\nPos: "..pos.."\nAngle: "..ang, "BudgetLabel", x - 293, 16, Color(0,255,0,255),TEXT_ALIGN_LEFT)
	end

	surface.SetDrawColor(color_black)
	surface.DrawRect(x/2 - 1,y/2 - 3,3,7)
	surface.DrawRect(x/2 - 3,y/2 - 1,7,3)

	surface.SetDrawColor(Color(0,255,10,230))
	surface.DrawLine(x/2,y/2 - 2,x/2,y/2 + 3)
	surface.DrawLine(x/2 - 2,y/2,x/2 + 3,y/2)
end
BandSox:Hook("HUDPaint","BandSox - HUDPaint",function() BandSox:Hud() end)

color_red = Color(255,0,0)
color_yellow = Color(255,255,0)
color_blue = Color(0,0,255)
color_green = Color(0,255,0)
local size = y * 0.01
local laser = Material("trails/laser")

function BandSox:UpdateEnt()
	if !self.Ent then self.Ent = {} end
	table.Empty(self.Ent)
	for k,ent in pairs(ents.GetAll()) do
		local name = ent:GetClass()
		local model = ent:GetModel()
	end
end
--timer.Create("BandSox - UpdateEnt",1,0,function() BandSox:UpdateEnt() end)

function BandSox:Esp()
	self.AdminCount = self.AdminCount or 0
	for k,ply in pairs(player.GetAll()) do
		if ply ~= LocalPlayer() then
			local myteam = LocalPlayer():Team()
		
			local ply_team = ply:Team()
			local pos = self:GetPos(ply)
			local trace = ply:GetEyeTraceNoCursor().HitPos
			--local admin = ply:IsAdmin()
			--local super_admin = ply:IsSuperAdmin()
			--if admin ~= false or super_admin ~= false then
				--local str = super_admin ~= false and "SuperAdmin: "..ply:Name() "Admin: "..ply:Name()
				--draw.SimpleText(str,"BudgetLabel",10,y/2,color_red,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
			--end
			local color = (myteam == ply_team) and (self:Visible(ply) and color_green or color_blue) or (self:Visible(ply) and color_red or color_yellow)
			-- eyeline
			--surface.DrawLine(pos.x,pos.y,trace.x,trace.y)
			--if ply_team ~= myteam then
				/*cam.Start3D(EyePos(),EyeAngles())
					render.SetMaterial(laser)
					cam.IgnoreZ(false)
						render.DrawBeam(pos,trace,8,2,0,color_white)
					cam.IgnoreZ(true)
				cam.End3D()*/
			
				pos,trace = pos:ToScreen(),trace:ToScreen()
				surface.SetDrawColor(color)
				surface.DrawLine(pos.x + size,pos.y,pos.x - size,pos.y)
				surface.DrawLine(pos.x,pos.y + size,pos.x,pos.y - size)
			
				-- esp
				draw.SimpleText(ply:Name(),"BudgetLabel",pos.x - size * 0.25,pos.y - size * 0.75,color_white,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
				draw.SimpleText("("..ply:Health().."|"..ply:Armor()..")","BudgetLabel",pos.x,pos.y + size * 0.75,color_white,TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
				draw.SimpleText(select(2,self:GetActiveWeapon(ply)),"BudgetLabel",pos.x + size * 0.25,pos.y + size * 0.75,color_white,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
			--end
		end
	end
	local ent = LocalPlayer():GetEyeTraceNoCursor().Entity
	if ValidEntity(ent) then
		if ent:GetClass() == "prop" then
			local pos = ent:GetPos():ToScreen()
			local str = math.floor(ent:GetNWInt("Health") / ent:GetNWInt("MaxHP") * 10000) / 100 .."%"
			draw.SimpleText(str,"BudgetLabel",pos.x,pos.y,color_red,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
		end
	end
end
BandSox:Hook("HUDPaint","BandSox - ESP",function() BandSox:Esp() end)

function BandSox:GetPos(ent)
	local model = string.lower(ent:GetModel()) or ""
	if string.find(model, "fast") then
		return ent:GetAttachment(3).Pos
	elseif string.find(model, "zombie") then
		return ent:GetAttachment(2).Pos
	elseif string.find(model, "headcrab") then
		return ent:GetPos() + Vector(0,0,10)
	elseif string.find(model, "antlion") then
		return ent:LocalToWorld( ent:OBBCenter() )
	elseif string.find(model, "hunter") then
		local pos = ent:GetPos()
		local vup = ent:GetUp()
		local endpos = pos + (vup * 75)
		return endpos
	end
	if ent:GetAttachment(ent:LookupAttachment("eyes")) ~= nil then
		return ent:GetAttachment(ent:LookupAttachment("eyes")).Pos
	else
		return ent:LocalToWorld(ent:OBBCenter())
	end
end

function BandSox:Visible(ent)
	local trace = {}
	trace.start = LocalPlayer():GetShootPos()
	trace.endpos = self:GetPos(ent)
	trace.filter = {LocalPlayer(),ent}
	trace.mask = MASK_SHOT
	local tr = util.TraceLine(trace)
	if (tr.Fraction >= 0.99) then -- if ( !tr ) then
		return true
	else
		return false
	end
end

function BandSox:Alive(ent)
	if ValidEntity(ent) and ((ent:IsPlayer() and ent:Alive()) or (ent:IsNPC() and ent:GetMoveType() ~= MOVETYPE_NONE)) then return true end
	return false
end

function BandSox:FilterTarget(ent)
	if (!ent:IsValid() or (!ent:IsNPC() and !ent:IsPlayer() and 
		!(ent:GetClass() == "prop_physics") and 
		!(ent:GetClass() == "ware_bullseye") and 
		!(ent:GetClass() == "ware_catchball") and 
		!(ent:GetClass() == "melon") and 
		!(ent:GetClass() == "gmod_balloon")) or LocalPlayer() == ent) then return false end
	if (ent:IsPlayer()) then
		if (ent:GetMoveType() == MOVETYPE_NONE or ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	    if (self.Settings.Filter.NPC == true) then return false end
	    if (self.Settings.Filter.Prop == true) then return false end
	    if (ent:Team() == 1001 or ent:Team() == 1002) and !self:IsGamemode("Plane Crazy") and !self:IsGamemode("Instagib") and !self:IsGamemode("Sandbox") and !self:IsGamemode("Garry's Mod Deathmatch") then return false end
	    if (self.Settings.Filter.Bottle == true) then return false end
		if (!ent:Alive()) then return false end
		if (ent:Health() < 1) then return false end
		if (ent:GetMaterial() == "models/shiny") then return false end
		if (ent:Team() ~= LocalPlayer():Team() and self:IsGamemode("Bomb Tag")) then return false end
		if (ent:IsFrozen() and self:IsGamemode("Freeze Tag")) then return false end
		if (ent:Team() == 1001 and self:IsGamemode("Garry Theft Auto")) then return false end
		if (self.Settings.Filter.Team == false) and (ent:Team() == LocalPlayer():Team()) then return false end
	end
	if (ent:IsNPC()) then
		if (ent:GetMoveType() == MOVETYPE_NONE or ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
		if (self.Settings.Filter.Human == true) then return false end
	    if (self.Settings.Filter.Bottle == true) then return false end
		if (ent:GetMoveType() == 0) then return false end
		local model = string.lower(ent:GetModel() or "")
		if (ent:GetClass() == "npc_turret_floor") then return false end
		if (ent:GetClass() == "zw_trader") then return false end
		--if (table.HasValue(deathSequences[model] or {}, ent:GetSequence())) then return false end
	end
	if (ent:GetClass() == "prop_physics" or ent:GetClass() == "melon" or ent:GetClass() == "gmod_balloon") then
	    if ent:GetNWEntity("Owner") == LocalPlayer() then return false end
	    if (self.Settings.Filter.Prop == true) then return true end
		if (self.Settings.Filter.Bottle == false) then return false end
        local model = string.lower(ent:GetModel() or "")
		if (model ~= "models/props_junk/glassbottle01a.mdl")
		and (model ~= "models/props_junk/wood_crate001a.mdl")
		and (model ~= "models/props_c17/oildrum001_explosive.mdl")
		and (model ~= "models/props_junk/watermelon01.mdl")
		and (model ~= "models/props_junk/watermelon01_chunk01a.mdl")
		and (model ~= "models/props_junk/watermelon01_chunk01b.mdl")
		and (model ~= "models/props_junk/watermelon01_chunk01c.mdl")
		and (model ~= "models/dav0r/balloon/balloon.mdl") then return false end
	end
	return true
end

function BandSox:GetPlayer()
	local pos = LocalPlayer():GetPos()
	local ang = LocalPlayer():GetAimVector()
	local entlist = {0,0}
	for _,ent in pairs(ents.GetAll()) do
		if (self:FilterTarget(ent) == true) and self:Visible(ent) then
		    if (self.Settings.Target == "screenpos") then
				local targetpos = ent:EyePos() -- ent:GetPos()
				local diff = (targetpos-pos):Normalize()
				diff = diff - ang
				diff = diff:Length()
				diff = math.abs(diff)
				if (diff < entlist[2]) or (entlist[1] == 0) then
					entlist = {ent, diff}
				end
			 elseif (self.Settings.Target == "health") then
                local hp = ent:Health()
    			if (hp < entlist[2]) or (entlist[1] == 0) then
     				entlist = {ent,hp}
				end
			 else
			    local targetpos = ent:EyePos()
				local diff = targetpos:Distance(pos)
				if (diff < entlist[2]) or (entlist[1] == 0) then
     				entlist = {ent,diff}
				end
			 end
		end
	end
	return entlist[1]
end

function BandSox:GetWepVal(t,v,i)
	if not t then return "NULL" end
	if t[v] then return t[v] end
	if t.Primary and t.Primary[v] then return t.Primary[v] end
	if t["Primary"..v] then return t["Primary"..v] end
	if t["data"] then
		for _,d in pairs(t["data"]) do
			if type(d) == "table" and d[v] then return d[v] end
		end
	end
	if t.BaseClass and (i or 0) < 10 then
		return self:GetWepVal(t.BaseClass,v,(i or 0)+1)
	end
	return nil
end

function BandSox:Cone()
	local cone = 0
	local ok,err = pcall(function()
	    local weapon,name = self:GetActiveWeapon()
		if !weapon then return end
		local tbl = weapon:GetTable()
		if !ValidEntity(weapon) then return 5 end
		if weapon == nil or weapon == NULL then return 6 end
		if GetHostName():find("LEFT4GREEN") ~= nil then
			if (LocalPlayer():IsHuman()) then
				local weptype = weapon:GetType()
				local wepcone = 0
				if (self.MrGreenCones[weptype]) then
					wepcone = self.MrGreenCones[weptype].Cone or 0
				end
				local runcone, crouchcone, basecone = 1.7, 0.8, 1.3
				local iIronsightMul = 2
				if weapon:GetIronsights() then iIronsightMul = weapon.IronSightMultiplier end
				
				if LocalPlayer():GetVelocity():Length() > 25 then
					cone = tonumber( wepcone * runcone * 0.25 * iIronsightMul )
				else
					if LocalPlayer():Crouching() then
						cone = tonumber( wepcone * crouchcone * 0.25 * iIronsightMul )
					else
						cone = tonumber( wepcone * basecone * 0.25 * iIronsightMul )
					end
				end
			end
	    elseif weapon:GetClass() == "weapon_planegun" then
			cone = 0.04
		elseif self.Hl2Cones[weapon:GetClass()] then
			cone = (self.Hl2Cones[weapon:GetClass()] or 0)
		else
		    if self.Moving and self.Moving ~= 0 then
				cone = (tonumber(self:GetWepVal(tbl,"ConeMoving")) or tonumber(self:GetWepVal(tbl,"Cone")) or 0)
			elseif self.Crouching and self.Crouching ~= false then
			    cone = (tonumber(self:GetWepVal(tbl,"ConeCrouching")) or tonumber(self:GetWepVal(tbl,"Cone")) or 0)
			else
			    cone = (tonumber(self:GetWepVal(tbl,"Cone")) or 0)
			end
		end
	end)
	if !ok then print(err) end
	return Vector(-cone,-cone,-cone)
end

--[[local CalcTable = {}; -- Grabage collector optimization
function BandSox:CalcView(ply,origin,angles,fov)
	local self = BandSox;
	
	local w = p:GetActiveWeapon();
	
	if(ValidEntity(w)) then
		if(w.Primary) then w.Primary.Recoil = 0 end;
		if(w.Secondary) then w.Secondary.Recoil = 0 end;
	end
	
	CalcTable.origin = origin;
	CalcTable.angles = self.ViewAngles;
	return CalcTable;
end]]

concommand.Add("+bs_getview",function(ply,cmd,arg)
	-- This shouldn't overwrite the convar since it already exists.
	-- sens = CreateClientConVar("sensitivity","10",false, false ):GetFloat()
	BandSox.Zoom = 90
	local new_sens = 2
	ply:ConCommand("sensitivity "..new_sens.."\n")
end)

concommand.Add("-bs_getview",function(ply,cmd,arg)
	BandSox.Zoom = nil
	local old_sens = 10
	ply:ConCommand("sensitivity "..old_sens.."\n")
end)

--BandSox.Settings.NoRecoil = false

function BandSox:CalcView(ply,origin,angles,fov)
	if !self.CalcTable then
		self.CalcTable = {}
	end
	self.CalcTable.origin = origin
	self.CalcTable.angles = angles
	self.CalcTable.fov = fov
	
	if self.Zoom then
		self.Zoom = self.Zoom + (10-self.Zoom)*0.5
		self.CalcTable.fov = self.Zoom	
	end
	
	if self.Settings.NoRecoil == true then
		self.CalcTable.angles = self.ViewAngles
		return self.CalcTable--{angles = self.ViewAngles}
	end
end
BandSox:Hook("CalcView","BandSox - CalcView",function(p,o,a,f) return BandSox:CalcView(p,o,a,f) end)

local m_pitch = CreateClientConVar("m_pitch","")
local m_yaw = CreateClientConVar("m_yaw","")
function BandSox:NoRecoil(cmd)
	if self.Settings.NoRecoil ~= true then return end
	if !self.ViewAngles then
		self.ViewAngles = cmd:GetViewAngles()
		self.AimAngles = self.ViewAngles
	end
	local x,y = cmd:GetMouseX(),cmd:GetMouseY() -- Mouse difference in x/y difference. X is responsible for yaw, Y for pitch
	local m_pitch,m_yaw = m_pitch:GetFloat(),m_yaw:GetFloat() -- Scalare values, defined by the engine
	self.ViewAngles.p = math.Clamp(self.ViewAngles.p + m_pitch*y,-89.9,89.9) -- Disables the ability for you to "flip" the view
	self.ViewAngles.y = self.ViewAngles.y - m_yaw*x	
	
	local move = Vector(cmd:GetForwardMove(),cmd:GetSideMove(),0)
	local set = (move:Angle() + (self.AimAngles - self.ViewAngles)):Forward() * move:Length()
	cmd:SetForwardMove(set.x)
	cmd:SetSideMove(set.y)
	
	if self.Aimat == 0 and !input.IsMouseDown(MOUSE_LEFT) then
		cmd:SetViewAngles(self.ViewAngles)
		--cmdMeta.SetViewAngles(cmd,self.ViewAngles)
	end
end
BandSox:Hook("CreateMove","BandSox - NoRecoil",function(ucmd) BandSox:NoRecoil(ucmd) end)

AutoShoot = false
function BandSox:Ai(cmd)
	if !self.AimAngles then
		self.AimAngles = cmd:GetViewAngles()
	end
	if self.Aim == true then
		--self.Aimat = self:GetPlayer()
	end
	if self.Aimat ~= 0 and IsValid(self.Aimat) then		
		self.AimAngles = (self:GetPos(self.Aimat) - LocalPlayer():GetShootPos()):Angle() // + (self.Aimat:GetVelocity() * 0.6/10000 * LocalPlayer():Ping())
		if (AutoShoot) then
			cmdMeta.SetButtons(cmd, cmdMeta.GetButtons(cmd) | IN_ATTACK)
		else
			cmdMeta.SetButtons(cmd, cmdMeta.GetButtons(cmd) & IN_ATTACK)	
		end
		AutoShoot = !AutoShoot
		--old_rcc("+attack")
		--timer.Simple(0.1,old_rcc,"-attack")
	end
	
	if input.IsMouseDown(MOUSE_LEFT) or (self.Aimat ~= 0) then
		if !select(1,self:GetActiveWeapon()) then return end
		local dir = self.AimAngles:Forward()
		LocalPlayer():LagCompensation(true)
		local ang = hack.CompensateWeaponSpread(cmd,self:Cone(),dir):Angle()
		if (ang.p > 90) then ang.p = ang.p - 360 end -- Fixes a bug
		cmd:SetViewAngles(ang)
		--cmdMeta.SetViewAngles(cmd,hack.CompensateWeaponSpread(cmd,self:Cone(),dir):Angle())
		LocalPlayer():LagCompensation(false)
	end
end

function BandSox:Hai()
	if !self.AimAngles then
		self.AimAngles = Angle()
	end
	if self.Aimat ~= 0 and IsValid(self.Aimat) then		
		self.AimAngles = (self:GetPos(self.Aimat) - LocalPlayer():GetShootPos()):Angle() // + (self.Aimat:GetVelocity() * 0.6/10000 * LocalPlayer():Ping())
		LocalPlayer():SetEyeAngles(self.AimAngles)
		old_rcc("+attack")
		timer.Simple(0.1,old_rcc,"-attack")	
	end
end
BandSox:Hook("CreateMove","BandSox - MouseMove",function(ucmd) BandSox:Ai(ucmd) end)
--BandSox:Hook("HUDPaint","BandSox - MouseMove",function() BandSox:Hai() end)

function BandSox:NewTarget()
	if self.Aim == true then
		if self.Aimat == 0 then
			self.AimAngles = self.ViewAngles
			self.Aimat = self:GetPlayer()
			return
		end
		if !IsValid(self.Aimat) then
			self.Aimat = self:GetPlayer()
			return
		end
		if self:Visible(self.Aimat) ~= true then
			self.Aimat = self:GetPlayer()
			return
		end
		if self:Alive(self.Aimat) ~= true then
			self.Aimat = self:GetPlayer()
			return
		end
	end
end
BandSox:Hook("HUDPaint","BandSox - NewTarget",function() BandSox:NewTarget() end)

function BandSox:Aimplus(ply,cmd,arg)
	self.Aimat = self:GetPlayer()
	self.Aim = true
end

function BandSox:Aiminus(ply,cmd,arg)
	self.Aimat = 0
	self.Aim = false
	self.AimAngles = self.ViewAngles
end
concommand.Add("+bs_getpos",function(p,c,a) BandSox:Aimplus(p,c,a) end)
concommand.Add("-bs_getpos",function(p,c,a) BandSox:Aiminus(p,c,a) end)