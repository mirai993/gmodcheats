--[[
	menu_plugins/bandsox.lua
	Stoned
	===DStream===
]]

-- BandSox Menu State

--require("sourcenet")

Signatures = {}

function AddSignature(name,mod,sig)
	local mask = sig:gsub("[0-9A-F]+%s*","x"):gsub("%?%s*","?")
	sig = sig:gsub("%?","00"):gsub("(%S+)%s*",function(byte)
		return string.char(tonumber(byte,16))
	end)

	Signatures[name] = {
		Signature = sig,
		Mask = mask,
		Module = mod,
		Length = sig:len(),
	}
	/*print("[BandSox] Signature added: "..name)
	print("[BandSox] Signature: "..sig)
	print("[BandSox] Mask: "..mask)
	print("[BandSox] Module: "..mod)
	print("[BandSox] Length: "..sig:len())*/
end

AddSignature(
	"CUserMessages::DispatchUserMessage",
	"client",
	"8B 44 24 04 83 EC 24 85 C0"
)

local BandSoxLoaded = false
function RunScriptsInFolder(dir)
	if BandSoxLoaded == false then
		BandSoxLoaded = true
		print("[BandSox] (Injecting) ...")
		--RunStringClient(file.Read("../lua/bandsox/bandsox.lua"))
	end
	print("(RunScriptsInFolder): "..dir)
end
hook.Add("RunScriptsInFolder","BandSox - RunScriptsInFolder",RunScriptsInFolder)

function CanRunScript(dir,str,online)
	local state = (online == true) and "Online" or "Local"
	print("(CanRunScript) "..state..": "..dir)
end
hook.Add("CanRunScript","BandSox - CanRunScript",CanRunScript)

function BlockCommand(msg)
	local cmd = msg:GetCommand()
	if cmd:find("setinfo name") then
		ErrorNoHalt("[BandSox] 'setinfo name' blocked.\n")
		return false  
	end
	if cmd:find("-speed") then
		return false
	end
	ErrorNoHalt("[BandSox] Incoming cmd: "..tostring(msg:GetCommand()).."\n")
end
hook.Add("ProcessStringCmd","BlockCommand",BlockCommand)

function BlockUserMessage(msg)
	local typ = msg:GetType()
	if typ == 23 or typ == 43 then
		-- return false
	end
end
hook.Add("ProcessUserMessage","BlockUserMessage",BlockUserMessage)

local block_cvar = CreateClientConVar("net_block",0,true,false)
local voice_cvar = CreateClientConVar("net_voice",0,true,false)
local voice_loop = CreateClientConVar("net_voice_loop",100,true,false)

function SendNetMsg(msg,reliable,voice) 
	--if (msg:GetName() == "svc_VoiceData") then  
	--	return false  
	--end
	local name = msg:GetName()
	if name ~= "net_Tick" and name ~= "clc_Move" and name ~= "clc_BaselineAck" then
		if name == "net_StringCmd" then
			ErrorNoHalt("[NetMessage] StringCmd: "..msg:To(FindMetaTable("NET_StringCmd")):GetCommand().."\n")
		else			
			--ErrorNoHalt("[NetMessage] "..name.."\n")
		end
	end
	if block_cvar:GetBool() == true and name == "clc_Move" then
		--local net = GetNetChannel()
		--net:SendNetMsg(msg,true,true)
		--net:SendNetMsg(msg,true,true)
		--return false
		--local base = msg:ToBase()
		/*INetMessage:To([table] typeMetaTable)
		INetMessage:SetReliable([boolean] reliable)
		INetMessage:Process()
		INetMessage:IsReliable()
		INetMessage:GetType()
		INetMessage:GetGroup()
		INetMessage:GetName()
		INetMessage:GetNetChannel()
		INetMessage:ToString()*/

		--print(msg)
		--print(msg:To(FindMetaTable("CLC_Move")))
		--print(msg:ToString())
		
		
		--INetMessage: 405A3A78
		--CLC_Move: 405993C0
		--clc_Move: backup 3, new 2, bytes 36660000
		return false
	end
	if msg:GetName() == "clc_VoiceData" and voice_cvar:GetBool() == true then
		local net = GetNetChannel()
		for i=1,voice_loop:GetInt() do
			net:SendNetMsg(msg,true,true)
		end
	end
end
hook.Add("SendNetMsg","NetMsgCheck",SendNetMsg)

function ProcessVoice(msg)
	--if VoiceReady then return end
	--if msg:ToBase():GetName() == "svc_VoiceData" and !VoiceReady then
	--	VoiceReady = true
	--	VoiceChannel = msg:ToBase():GetNetChannel()
	--end
end
hook.Add("ProcessVoiceData","ProcessVoice",ProcessVoice)
--hook.Add("ProcessVoiceData","ProcessVoice",function(msg) if msg:ToBase():GetName() == "svc_VoiceData" and !VoiceReady then VoiceReady = true VoiceChannel = msg:ToBase():GetNetChannel() end end)
--hook.Add("SendNetMsg","NetMsgCheck",function(msg,reliable,voice) if VoiceReady and DOSPAM then VoiceChannel:SendNetMessage(msg,true,true) end end)