--[[
	MOD/addons/infinity/lua/autorun/client/infinity_hud.lua [#25622 (#26200), 1581670758, UID:2259809146]
	.ABH. Kingofultima | STEAM_0:0:75566661 <50.173.14.252:27005> | [10.06.14 11:34:35PM]
	===BadFile===
]]

if infinity_menu then
        infinity_menu:Remove( );
        infinity_menu = nil;
end;
 
-- mouse in box function
function util.InBox( x, y, w, h )
    local mx, my = gui.MouseX( ), gui.MouseY( );
   
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        return true;
    end;
   
    return false;
end;
 
-- infinity hud script
local arrow_down = Material( "vgui/hack/arrow_down.png", nocull ); -- materials
local arrow_up = Material( "vgui/hack/arrow_up.png", nocull );
local grad = Material( "vgui/hack/gradient.png", nocull );
local infinity = Material( "vgui/hack/infinity.png", nocull );
local off = Material( "vgui/hack/off.png", nocull );
local on = Material( "vgui/hack/on.png", nocull );
local seperator_bottom = Material( "vgui/hack/seperator_bottom.png", nocull );
local seperator_side = Material( "vgui/hack/seperator_side.png", nocull );
 
--HERP font
local tblFonts = { }
tblFonts["Derp"] = {
    font = "Tahoma",
    size = 18,
    weight = 0,
    shadow = true,
}
 
tblFonts["HerpSmall"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
 
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end
 
 
-- fake vars, change to yours
var1 = false;
_wallon = true;
_espon = true; -- for example purposes
_enton = false
_crosson = true
_dancin = false
local t_trigger = false
local showgui = false;
local homedown = false;
_optionsvar = "Arm";
_slidervar = 0;
 
--[[
There has to be one table per tab
There has to be one var per table option
Add more tabs by looking at the very last 5 or so lines of the code
Remember to replace var table names when adding tabs
]]
 
local NUMBER_OF_TABS = 5; -- don't forget to change this
 
-- tab 1
local tab1_options = { };
tab1_options.num = 1;
tab1_options.toggle = false;
 
        tab1_options.name = "Aimbot"; -- edit name
       
        -- edit options
        tab1_options[ 1 ] = { };
        tab1_options[ 1 ].name = "Aimbot";
        tab1_options[ 1 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim" ) ); end;
        tab1_options[ 1 ].off = function( ) RunConsoleCommand( "infinity_aim", "0" ); end;
        tab1_options[ 1 ].seton = function( ) RunConsoleCommand( "infinity_aim", "1" ); end;

       
        tab1_options[ 2 ] = { };
        tab1_options[ 2 ].name = "Autoshoot";
        tab1_options[ 2 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_autoshoot" ) ); end;
        tab1_options[ 2 ].off = function( ) RunConsoleCommand( "infinity_aim_autoshoot", "0" ); end;
        tab1_options[ 2 ].seton = function( ) RunConsoleCommand( "infinity_aim_autoshoot", "1" ); end;
		
		
		tab1_options[ 3 ] = { };
        tab1_options[ 3 ].name = "AntiSnap";
        tab1_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_smooth" ) ); end;
        tab1_options[ 3 ].off = function( ) RunConsoleCommand( "infinity_aim_smooth", "0" ); end;
        tab1_options[ 3 ].seton = function( ) RunConsoleCommand( "infinity_aim_smooth", "1" ); end;
       
	   
	   	tab1_options[ 4 ] = { };
        tab1_options[ 4 ].name = "AntiSnap Speed";
        tab1_options[ 4 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", infinity_menu );
                    scratch:SetMin( 4 );
                    scratch:SetMax( 12 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( GetConVarNumber( "infinity_aim_smooth_val" ) );
                                        function scratch:OnValueChanged( val )
                                                RunConsoleCommand( "infinity_aim_smooth_val", val )
                                        end;
                    return scratch;
            end;
       tab1_options[ 4 ].slider = true;
	   
	   
	   	tab1_options[ 5 ] = { };
        tab1_options[ 5 ].name = "FOV";
        tab1_options[ 5 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", infinity_menu );
                    scratch:SetMin( 1 );
                    scratch:SetMax( 180 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( GetConVarNumber( "infinity_aim_fov" ) );
                                        function scratch:OnValueChanged( val )
                                                RunConsoleCommand( "infinity_aim_fov", val )
                                        end;
                    return scratch;
            end;
       tab1_options[ 5 ].slider = true;
	   
	   
	   	tab1_options[ 6 ] = { };
        tab1_options[ 6 ].name = "Aim Offset";
        tab1_options[ 6 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", infinity_menu );
                    scratch:SetMin( -10 );
                    scratch:SetMax( 10 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( GetConVarNumber( "infinity_aim_offset" ) );
                                        function scratch:OnValueChanged( val )
                                                RunConsoleCommand( "infinity_aim_offset", val )
                                        end;
                    return scratch;
            end;
       tab1_options[ 6 ].slider = true;
	   
	   
	   
		tab1_options[ 7 ] = { };
        tab1_options[ 7 ].name = "Snap On Fire";
        tab1_options[ 7 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_snaponfire" ) ); end;
        tab1_options[ 7 ].off = function( ) RunConsoleCommand( "infinity_aim_snaponfire", "0" ); end;
        tab1_options[ 7 ].seton = function( ) RunConsoleCommand( "infinity_aim_snaponfire", "1" ); end;
		
		
		tab1_options[ 8 ] = { };
        tab1_options[ 8 ].name = "Friendly Fire";
        tab1_options[ 8 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_friendlyfire" ) ); end;
        tab1_options[ 8 ].off = function( ) RunConsoleCommand( "infinity_aim_friendlyfire", "0" ); end;
        tab1_options[ 8 ].seton = function( ) RunConsoleCommand( "infinity_aim_friendlyfire", "1" ); end;

		tab1_options[ 9 ] = { };
        tab1_options[ 9 ].name = "Ignore Admins";
        tab1_options[ 9 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_ignoreadmins" ) ); end;
        tab1_options[ 9 ].off = function( ) RunConsoleCommand( "infinity_aim_ignoreadmins", "0" ); end;
        tab1_options[ 9 ].seton = function( ) RunConsoleCommand( "infinity_aim_ignoreadmins", "1" ); end;
		
		tab1_options[ 10 ] = { };
        tab1_options[ 10 ].name = "Ignore Traitor Buddies";
        tab1_options[ 10 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_ignoretraitors" ) ); end;
        tab1_options[ 10 ].off = function( ) RunConsoleCommand( "infinity_aim_ignoretraitors", "0" ); end;
        tab1_options[ 10 ].seton = function( ) RunConsoleCommand( "infinity_aim_ignoretraitors", "1" ); end;
		
		tab1_options[ 11 ] = { };
        tab1_options[ 11 ].name = "Ignore Friends";
        tab1_options[ 11 ].on = function( ) return tobool( GetConVarNumber( "infinity_aim_ignorefriends" ) ); end;
        tab1_options[ 11 ].off = function( ) RunConsoleCommand( "infinity_aim_ignorefriends", "0" ); end;
        tab1_options[ 11 ].seton = function( ) RunConsoleCommand( "infinity_aim_ignorefriends", "1" ); end;
	   
	   
 
-- tab 2
local tab2_options = { };
tab2_options.num = 2;
tab2_options.toggle = false;
 
        tab2_options.name = "Wallhack"; -- edit name
       
        -- edit options
        tab2_options[ 1 ] = { };
 
        tab2_options[ 1 ].name = "Wallhack";
        tab2_options[ 1 ].on = function( ) return _wallon; end;
        tab2_options[ 1 ].off = function( ) _wallon = false; end;
        tab2_options[ 1 ].seton = function( ) _wallon = true; end;
       
        tab2_options[ 2 ] = { };
        tab2_options[ 2 ].name = "PERP";
        tab2_options[ 2 ].on = function( ) return _enton; end;
        tab2_options[ 2 ].off = function( ) _enton = false; end;
        tab2_options[ 2 ].seton = function( ) _enton = true; end;
		
        tab2_options[ 3 ] = { };
        tab2_options[ 3 ].name = "DarkRP";
        tab2_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "infinity_printer" ) ); end;
        tab2_options[ 3 ].off = function( ) RunConsoleCommand( "infinity_printer", "0" ); end;
        tab2_options[ 3 ].seton = function( ) RunConsoleCommand( "infinity_printer", "1" ); end;
       
	   
	 
       
-- tab 3
local tab3_options = { };
tab3_options.num = 3;
tab3_options.toggle = false;
 
        tab3_options.name = "ESP"; -- edit name
       
        -- edit options;
        tab3_options[ 1 ] = { };
        tab3_options[ 1 ].name = "ESP";
        tab3_options[ 1 ].on = function( ) return _espon; end;
        tab3_options[ 1 ].off = function( ) _espon = false; end;
        tab3_options[ 1 ].seton = function( ) _espon = true; end;
		
		
		tab3_options[ 2 ] = { };
        tab3_options[ 2 ].name = "Box ESP";
        tab3_options[ 2 ].on = function( ) return tobool( GetConVarNumber( "infinity_box" ) ); end;
        tab3_options[ 2 ].off = function( ) RunConsoleCommand( "infinity_box", "0" ); end;
        tab3_options[ 2 ].seton = function( ) RunConsoleCommand( "infinity_box", "1" ); end;
		
       
                -- edit options;
        tab3_options[ 3 ] = { };
        tab3_options[ 3 ].name = "Crosshair";
        tab3_options[ 3 ].on = function( ) return _crosson; end;
        tab3_options[ 3 ].off = function( ) _crosson = false; end;
        tab3_options[ 3 ].seton = function( ) _crosson = true; end;
		
		
        tab3_options[ 4 ] = { };
        tab3_options[ 4 ].name = "Admin List";
        tab3_options[ 4 ].on = function( ) return tobool( GetConVarNumber( "infinity_showadmins" ) ); end;
        tab3_options[ 4 ].off = function( ) RunConsoleCommand( "infinity_showadmins", "0" ); end;
        tab3_options[ 4 ].seton = function( ) RunConsoleCommand( "infinity_showadmins", "1" ); end;
		
        tab3_options[ 5 ] = { };
        tab3_options[ 5 ].name = "Spectator Box";
        tab3_options[ 5 ].on = function( ) return tobool( GetConVarNumber( "infinity_showspecs" ) ); end;
        tab3_options[ 5 ].off = function( ) RunConsoleCommand( "infinity_showspecs", "0" ); end;
        tab3_options[ 5 ].seton = function( ) RunConsoleCommand( "infinity_showspecs", "1" ); end;
		
		
		tab3_options[ 6 ] = { };
        tab3_options[ 6 ].name = "PERP Player Info";
        tab3_options[ 6 ].on = function( ) return tobool( GetConVarNumber( "infinity_perp_playerinfo" ) ); end;
        tab3_options[ 6 ].off = function( ) RunConsoleCommand( "infinity_perp_playerinfo", "0" ); end;
        tab3_options[ 6 ].seton = function( ) RunConsoleCommand( "infinity_perp_playerinfo", "1" ); end;

		
        local tab4_options = { };
        tab4_options.num = 4;
        tab4_options.toggle = false;
 
        tab4_options.name = "Misc"; -- edit name
       
        -- edit options
        tab4_options[ 1 ] = { };
		tab4_options[ 1 ].name = "Thirdperson";
		tab4_options[ 1 ].on = function( ) return var2; end;
		tab4_options[ 1 ].off = function( ) RunConsoleCommand( "firstperson" ); var2 = false; end;
		tab4_options[ 1 ].seton = function( ) RunConsoleCommand( "thirdperson" ); var2 = true; end;
       
        tab4_options[ 2 ] = { };
		tab4_options[ 2 ].name = "Fullbright";
		tab4_options[ 2 ].on = function( ) return var3; end;
		tab4_options[ 2 ].off = function( ) RunConsoleCommand( "mat_fullbright", "0" ); var3 = false; end;
		tab4_options[ 2 ].seton = function( ) RunConsoleCommand( "mat_fullbright", "1" ); var3 = true; end;
       
        tab4_options[ 3 ] = { };
        tab4_options[ 3 ].name = "Traitor Detector";
        tab4_options[ 3 ].on = function( ) return tobool( GetConVarNumber( "infinity_traitor" ) ); end;
        tab4_options[ 3 ].off = function( ) RunConsoleCommand( "infinity_traitor", "0" ); end;
        tab4_options[ 3 ].seton = function( ) RunConsoleCommand( "infinity_traitor", "1" ); end;
       
        tab4_options[ 4 ] = { };
        tab4_options[ 4 ].name = "Drug Dealer";
        tab4_options[ 4 ].on = function( ) return tobool( GetConVarNumber( "infinity_dd" ) ); end;
        tab4_options[ 4 ].off = function( ) RunConsoleCommand( "infinity_dd", "0" ); end;
        tab4_options[ 4 ].seton = function( ) RunConsoleCommand( "infinity_dd", "1" ); end;
       
        tab4_options[ 5 ] = { };
        tab4_options[ 5 ].name = "Tiny Dancin Man";
        tab4_options[ 5 ].on = function( ) return _dancin; end;
        tab4_options[ 5 ].off = function( ) _dancin = false; end;
        tab4_options[ 5 ].seton = function( ) _dancin = true; end;
		
		tab4_options[ 6 ] = { };
        tab4_options[ 6 ].name = "AntiAFK";
        tab4_options[ 6 ].on = function( ) return tobool( GetConVarNumber( "infinity_antiafk" ) ); end;
        tab4_options[ 6 ].off = function( ) RunConsoleCommand( "infinity_antiafk", "0" ); end;
        tab4_options[ 6 ].seton = function( ) RunConsoleCommand( "infinity_antiafk", "1" ); end;
		
		tab4_options[ 7 ] = { };
        tab4_options[ 7 ].name = "No Recoil";
        tab4_options[ 7 ].on = function( ) return tobool( GetConVarNumber( "infinity_norecoil" ) ); end;
        tab4_options[ 7 ].off = function( ) RunConsoleCommand( "infinity_norecoil", "0" ); end;
        tab4_options[ 7 ].seton = function( ) RunConsoleCommand( "infinity_norecoil", "1" ); end;
		
		tab4_options[ 8 ] = { };
        tab4_options[ 8 ].name = "Bunnyhop";
        tab4_options[ 8 ].on = function( ) return tobool( GetConVarNumber( "infinity_misc_bunnyhop" ) ); end;
        tab4_options[ 8 ].off = function( ) RunConsoleCommand( "infinity_misc_bunnyhop", "0" ); end;
        tab4_options[ 8 ].seton = function( ) RunConsoleCommand( "infinity_misc_bunnyhop", "1" ); end;


 
        local tab5_options = { };
        tab5_options.num = 5;
        tab5_options.toggle = false;
 
        tab5_options.name = "Config"; -- edit name
		
		tab5_options[ 1 ] = { };
        tab5_options[ 1 ].name = "Speedhack Speed";
        tab5_options[ 1 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", infinity_menu );
                    scratch:SetMin( 2 );
                    scratch:SetMax( 10 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( GetConVarNumber( "infinity_speedhack_speed" ) );
                                        function scratch:OnValueChanged( val )
                                                RunConsoleCommand( "infinity_speedhack_speed", val )
                                        end;
                    return scratch;
            end;
       tab5_options[ 1 ].slider = true;
		
	   
	   
-- table
local tables = { tab1_options, tab2_options, tab3_options, tab4_options };
       
-- mouse think
local mouse_down = false;
local pressed = false;
local released = false;
local press_elem = nil;
 
hook.Add( "Think", "infinityGuiThink", function( )
    -- press
    if not pressed and input.IsMouseDown( MOUSE_LEFT ) then
        pressed = true;
                if IsValid( opt_menu ) then menuopen = true; end;
    end;
   
    -- release
    if pressed and not input.IsMouseDown( MOUSE_LEFT ) then
        pressed = false;
        released = true;
    end;
   
    if released then
        if press_elem then
                        if press_elem.toggle != nil then
                                press_elem.toggle = !press_elem.toggle;
                               
                                if press_elem.toggle then
                                        for k, v in pairs( press_elem ) do
                                                if type( v ) == "table" and v.slider then
                                                        v.scratcher = v.scratch( );
                                                        v.scratcher:SetPos( tab_x + ( tabwidth - 2 ) * press_elem.num - 1 - 16 - 5, 37 + k * 37 - 27 );
                                                end;
                                        end;
                                end;
                        elseif press_elem.options then
                                if not IsValid( opt_menu ) and menuopen then
                                        menuopen = false;
                                else
                                        press_elem.menu( );
                                end;
                        else
                                if press_elem.on( ) then
                                        press_elem.off( );
                                else
                                        press_elem.seton( );
                                end;
                        end;
                       
                        press_elem = nil;
        end;
       
        released = false;
    end;
end );
 
-- draw tab function
local function drawtab( x, first, vartab, tw )
        -- first seperator
        if first then
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x, 0, 2, 36 );
        end;
   
        -- check for hover, with options for hovering with it being on or off
    local opt_on = vartab.toggle;
    local col = Color( 11, 156, 28, 255 );
    local col2 = Color( 51, 51, 51, 255 );
    if not opt_on then col = Color( 0, 123, 184, 255 ); col2 = Color( 61, 61, 61, 255 ); end;
   
    if util.InBox( x + 2, 0, tw - 4, 35 ) then
        if not opt_on then
            col2 = Color( 71, 71, 71, 255 );
            if pressed then col2 = Color( 81, 81, 81, 255 ); press_elem = vartab; end;
        else
            col2 = Color( 61, 61, 61, 255 );
            if pressed then col2 = Color( 71, 71, 71, 255 ); press_elem = vartab; end;
        end;
    end;
       
        -- box
    draw.RoundedBoxEx( 0, x + 2, 0, tw - 4, 35, col2 );
   
        -- sperator
    surface.SetMaterial( seperator_side );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( x + tw - 2, 0, 2, 36 );
   
        -- name
    draw.SimpleText( vartab.name, "Derp", x + tw / 2, 35 / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
   
    -- items
        if vartab.toggle then
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x, 37, 2, 37 * #vartab );
               
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + tw - 2, 37, 2, 37 * #vartab );
               
                local yadd = 37;
               
                for i = 1, #vartab do
                        -- toggle stuff
                        local mat;
                        local opt_on;
                       
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                opt_on = vartab[ i ].on( );
                                mat = on;
                        end;
                       
                        local col = Color( 11, 156, 28, 255 );
                        local col2 = Color( 51, 51, 51, 255 );
                       
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                if not opt_on then
                                        mat = off;
                                        col = Color( 0, 123, 184, 255 );
                                end;
                        end;
                       
                        if util.InBox( x + 2, yadd, tw - 4, 35 ) and not vartab[ i ].slider then
                                if pressed then col2 = Color( 61, 61, 61, 255 ); press_elem = vartab[ i ]; end;
                        end;
                       
                        -- box
                        draw.RoundedBoxEx( 0, x + 2, yadd, tw - 4, 35, col2 );
                       
                        surface.SetMaterial( seperator_bottom );
                        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                        surface.DrawTexturedRect( x + 1, yadd + 35, tw - 3, 2 );
                       
                        -- on off material
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                surface.SetMaterial( mat );
                                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                                surface.DrawTexturedRect( x + tw - 4 - 5 - 14, yadd + 36 / 2 - 7, 14, 14 );
                        end;
                       
                        -- text
                        if vartab[ i ].options then
                                draw.SimpleText( vartab[ i ].name .. " (PICK)", "HerpSmall", x + 10, yadd + 37 / 2, Color( 255, 120, 120, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                        else
                                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                        end;
                       
                        -- add y
                        yadd = yadd + 37;
                end;
               
                -- arrow
                surface.SetMaterial( arrow_down );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 37, 9, 6 );
        else
                -- arrow
                surface.SetMaterial( arrow_up );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 29, 9, 6 );
        end;
end;
 
-- infinity_paint function
infinity_paint = function( )
        -- bar
        surface.SetMaterial( grad );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 0, 0, ScrW( ), 35 );
       
        surface.SetMaterial( seperator_bottom );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 0, 35, ScrW( ), 2 );
       
        -- logo
        surface.SetMaterial( infinity );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 8, -1, 91, 36 );
       
        -- tabs
        local after_logo_add = 25;
        tabwidth = math.ceil( ( ScrW( ) - 91 - ScrW( ) * 0.20 - after_logo_add ) / NUMBER_OF_TABS );
        tab_x = 91 + after_logo_add;
       
        -- add tabs here
        drawtab( tab_x, true, tab1_options, tabwidth );
        drawtab( tab_x + tabwidth - 2, false, tab2_options, tabwidth );
        drawtab( tab_x + ( tabwidth - 2 ) * 2, false, tab3_options, tabwidth );
        drawtab( tab_x + ( tabwidth - 2 ) * 3, false, tab4_options, tabwidth );
		drawtab( tab_x + ( tabwidth - 2 ) * 4, false, tab5_options, tabwidth );
end;
 
-- showgui
hook.Add( "Think", "Show_infinity", function( )
                        for k, v in pairs( tables ) do
                                for k2, v2 in pairs( v ) do
                                        if type( v2 ) == "table" and IsValid( v2.scratcher ) then
                                                if not v.toggle then
                                                        v2.scratcher:SetVisible( false );
                                                else
                                                        v2.scratcher:SetVisible( true );
                                                end;
                                        end;
                                end;
                        end;
               
                                if showgui then
                                        if not infinity_menu then
                                                        infinity_menu = vgui.Create( "DFrame" );
                                                        infinity_menu:ShowCloseButton( false );
                                                        infinity_menu:SetDraggable( false );
                                                        infinity_menu.lblTitle:SetVisible( false );
                                        else
                                                        if not infinity_menu.setpaint then
                                                                        infinity_menu.Paint = infinity_paint;
                                                                        infinity_menu.setpaint = true;
                                                        end;
                                               
                                                        infinity_menu:SetSize( ScrW( ), ScrH( ) );
                                        end;
                                else
                                        if infinity_menu then
                                                infinity_menu:Remove( );
                                                infinity_menu = nil;
                                        end;
                                end;
               
        if input.IsKeyDown( KEY_INSERT ) then
                homedown = true;
        elseif not input.IsKeyDown( KEY_INSERT ) and homedown then
                showgui = !showgui;
                gui.EnableScreenClicker( showgui );
                homedown = false;
        end;
end );