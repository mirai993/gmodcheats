--[[
	MOD/addons/infinity/lua/autorun/client/infinity.lua [#51641 (#52995), 3114804911, UID:337737778]
	.ABH. Kingofultima | STEAM_0:0:75566661 <50.173.14.252:27005> | [10.06.14 11:34:34PM]
	===BadFile===
]]

-- Made by Kevin G aka Kingofultima
--local _espon = false -- handled using gui, but you can still check for _espon in this script because _espon is global in the gui script
--local _wallon = false -- do the same for this and replace my example, you can put the right tab names and delete items or add new ones
--local _enton = false
--local _crosson = false

if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

orange = Color(255,106,0)
lightblue = Color(0,150,255)
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
white = Color(255,255,255)
yellow = Color(0,255,255)
local infinity = {}

function infinity.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(lightblue, "[Infinity v2 by Kevin G] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end
 
 
infinity.Notify(true,green,"has sucessfully loaded!")
 
local weed = Material( "vgui/hack/weed.png", nocull );
local shield = Material( "icon16/shield.png", nocull );
local shieldadd = Material( "icon16/shield_add.png", nocull );
local user = Material( "icon16/user.png", nocull );
local heart = Material( "icon16/heart.png", nocull );
local money = Material( "icon16/money.png", nocull );

function CreateTimer( sec, rep, func )
        local index = RandomString( 10 )       
        infinity.timers[ index ] = sec     
        timer.Create( index, sec, rep, func )
end
function RandomString( len )
        local ret = ""
                for i = 1 , len do
                        ret = ret .. string.char( math.random( 65 , 116 ) )
       end
        return ret
end
infinity.timers = {}
CreateClientConVar( "infinity_showadmins", 1, true, false )
CreateClientConVar( "infinity_rpgod", 1, true, false )
CreateClientConVar( "infinity_showspecs", 1, true, false )
CreateClientConVar( "infinity_sniper", 1, true, false )
CreateClientConVar( "infinity_weed", 1, true, false )
CreateClientConVar( "infinity_coke", 1, true, false )
CreateClientConVar( "infinity_printer", 1, true, false )
CreateClientConVar( "infinity_gmodz", 1, true, false )
CreateClientConVar( "infinity_norecoil", 1, true, false )
CreateClientConVar( "infinity_lazer", 1, true, false )
CreateClientConVar( "infinity_dd", 1, true, false )
CreateClientConVar( "infinity_box", 0, true, false )
CreateClientConVar( "infinity_c4", 1, true, false )
CreateClientConVar( "infinity_nospread", 1, true, false )
CreateClientConVar( "infinity_showspec", 1, true, false )
CreateClientConVar( "infinity_antiafk", 0, true, false )
CreateClientConVar( "infinity_autoreload", 1, true, false )
CreateClientConVar( "infinity_perp_playerinfo", 1, true, false )
CreateClientConVar( "infinity_ulxgag", 1, true, false )
speedhack_speed = CreateClientConVar( "infinity_speedhack_speed", 1, true, false )
infinity_speed = 1

--Check if player is alive or dead
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

concommand.Add("infinity_dancin", function() _dancin = !_dancin  end)
concommand.Add("infinity_esp", function() _espon = !_espon  end)
concommand.Add("infinity_xray", function() _xray = !_xray surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("infinity_allents", function() _allents = !_allents  end)
concommand.Add("infinity_crosshair", function() _crosson = !_crosson  end)
concommand.Add("infinity_wall", function() _wallon = !_wallon surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("infinity_ent", function() _enton = !_enton surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("infinity_printents", function() _printent = !_printent end)

local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end


infinity.spectators = {}
infinity.admins = {}
infinity.superadmins = {}


 function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(infinity.spectators, v)) then
                                table.insert(infinity.spectators, v);
                                        infinity.Notify(true,orange,""..v:Name().. " has begun to spectate you.")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
				
        for k, v in pairs(infinity.spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(infinity.spectators, k);
                                infinity.Notify(true,green,""..v:Name().." has stopped spectating you.")
                        end
                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(infinity.superadmins, v)) then
                                table.insert(infinity.superadmins, v);
                                infinity.Notify(true,white,"Super Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(infinity.admins, v) and not v:IsSuperAdmin()) then
                                table.insert(infinity.admins, v);
                                infinity.Notify(true,white,"Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)


--Aimbot


if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.
local _R = debug.getregistry();

local infinity    = {}
infinity.Commands = {}
infinity.ConVars  = {}
infinity.Hooks    = {}
infinity.MenuInfo = {}
infinity.Meta	   = { _G, hook, concommand, debug, file }
infinity.Settings = {}
infinity.World	   = { players = {} }

--[ RESET METATABLES ]--

function infinity:UnlockMeta()
	for i = 1, table.Count( infinity.Meta ) do
		rawset( infinity.Meta[i], "__metatable", false )
	end
end
infinity:UnlockMeta()

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand


infinity.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

infinity.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "infinity_"
}

function infinity:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

function infinity:AddCommand( name, func )
	return concommand.Add(name,func);
end


infinity.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 1, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 1, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 12, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_bunnyhop", Value = 1, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },

	}

function infinity:CreateConVars()
	local tbl = infinity.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = infinity.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		infinity.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		infinity.MenuInfo[pvar] = cvarinfo
		infinity.MenuInfo[#infinity.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			infinity.Settings[v.Table] = new
		end )
	
		infinity.ConVars[pvar] = convar
	end
end
infinity:CreateConVars()

MsgC( Color( 255, 255, 255 ),":: " )
MsgC(  Color( 255, 0, 0 ),"Convars created.\n" )


function infinity:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

function infinity:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function infinity:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function infinity:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function infinity:IsTraitor( e )
	local ply = LocalPlayer()
	if not infinity:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function infinity:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( infinity.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if infinity:IsAdmin( e ) and infinity:G( infinity.Settings['ignoreadmins'], 1 ) then return false end
		if infinity:IsTraitor( e ) and infinity:G( infinity.Settings['ignoretraitors'], 1 ) then return false end
		if infinity:IsFriend( e ) and infinity:G( infinity.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and infinity:G( infinity.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not infinity:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if infinity:IsAdmin( e ) and infinity:G( infinity.Settings['ignoreadmins'], 1 ) then return false end
		if infinity:IsTraitor( e ) and infinity:G( infinity.Settings['ignoretraitors'], 1 ) then return false end
		if infinity:IsFriend( e ) and infinity:G( infinity.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and infinity:G( infinity.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

infinity.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function infinity:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function infinity:GetTargetLocation( e )
	for i = 1, table.Count( infinity.ZombieModels ) do
		if ( e:GetModel() == infinity.ZombieModels[i][1] ) then return infinity:GetPosition( e, infinity.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = infinity:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = infinity:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return infinity:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

--[ PREDICTION ]--

function infinity:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

--[ AUTOWALL ]--

function infinity:IsPenetrable( tr ) -- Thanks noPE.
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function infinity:TargetVisible( e )
	local ply = LocalPlayer()
	if infinity:G( infinity.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = infinity:GetTargetLocation( e ) + infinity:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( infinity:G( infinity.Settings['autowall'], 1 ) and infinity:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function infinity:GetAimTarget()
	if infinity:IsTargetValid( infinity.Vars.target, "aim" ) and infinity:TargetVisible( infinity.Vars.target ) then return infinity.Vars.target else infinity.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if infinity:G( infinity.Settings['aim'], 1 ) then
		for i = 1, table.Count( infinity.World.players ) do
			local e = infinity.World.players[i]
			if infinity:IsTargetValid( e, "aim" ) and infinity:TargetVisible( e ) then
				local pos = infinity:GetTargetLocation( e ) + infinity:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function infinity:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if infinity:G( infinity.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( infinity.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function infinity.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	infinity.Vars.aacorrectang = ply:GetAimVector():Angle()
	infinity.Vars.fakeang = ply:GetAimVector():Angle()
end
infinity:AddHook( "OnToggled", infinity.OnToggled )

--[ AIMBOT ]--

function infinity.Aimbot( cmd )
	local ply, tar = LocalPlayer(), infinity:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	infinity.Vars.fakeang.p = math.Clamp( infinity.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	infinity.Vars.fakeang.y = math.NormalizeAngle( infinity.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if infinity:G( infinity.Settings['aimsilent'], 1 ) and infinity:G( infinity.Settings['antiaim'], 0 ) then
		infinity.Copy.SetViewAngles( cmd, infinity.Vars.fakeang )
	end
	if infinity:G( infinity.Settings['aim'], 1 ) and ply:Alive() and tar then
		infinity.Vars.target = tar
		infinity.Vars.found = true
		local pos = infinity:GetTargetLocation( tar ) + infinity:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( infinity.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		infinity.Vars.aimingang = ang
		ang = infinity:GetSmoothAngle( ang )
		if infinity:G( infinity.Settings['nospread'], 1 ) and infinity:G( infinity.Settings['aimsmooth'], 0 ) then
			ang = infinity:PredictSpread( cmd, ang )
		end
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		if infinity:G( infinity.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				infinity.Copy.SetViewAngles( cmd, ang )
				infinity.Vars.aimlocked = true
			else
				infinity.Vars.aimlocked = false
			end
		else
			infinity.Copy.SetViewAngles( cmd, ang )
			infinity.Vars.aimlocked = true
		end
		if infinity:G( infinity.Settings['autoshoot'], 1 ) and not infinity.Vars.firing then
			RunConsoleCommand( "+attack" )
			infinity.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				infinity.Vars.firing = false
			end )
		end
	else
		infinity.Vars.target = nil
		infinity.Vars.aimlocked = false
		infinity.Vars.found = false
	end
	if infinity:G( infinity.Settings['aimsilent'], 1 ) and infinity.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( infinity.Vars.aimingang - infinity.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end
concommand.Add("+co_derp", infinity.Aimbot)

--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function infinity.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {}
	if infinity:G( infinity.Settings['calcview'], 1 ) then
		if infinity.Vars.pkfake and infinity:IsTTT() then
			view.angles = infinity.Vars.pkfakeang
		elseif infinity.Vars.aimlocked and infinity:G( infinity.Settings['aimsmooth'], 1 ) and infinity:G( infinity.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		elseif infinity.Vars.aimlocked and infinity:G( infinity.Settings['aimsilent'], 0 ) then
			view.angles = infinity.Vars.aimingang
		elseif infinity:G( infinity.Settings['aimsilent'], 1 ) or infinity:G( infinity.Settings['antiaim'], 1 ) then
			view.angles = infinity.Vars.fakeang
		elseif infinity:G( infinity.Settings['aimsilent'], 1 ) and infinity:G( infinity.Settings['novisrecoil'], 1 ) then
			view.angles = infinity.Vars.fakeang
		elseif infinity:G( infinity.Settings['novisrecoil'], 1 ) and infinity:G( infinity.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		else
			view = GAMEMODE:CalcView( e, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
infinity:AddHook( "CalcView", infinity.CalcView )


--[[--------------------------------------------
	PLAYERS AND ENTITIES
--]]--------------------------------------------

function infinity.GetAllPlayers()
	infinity.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( infinity.World.players, e ) end
	end
end


--[[--------------------------------------------
	BUNNYHOP
--]]--------------------------------------------


function infinity.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if infinity:G( infinity.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end


--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function infinity.CreateMove( cmd )
	infinity.Aimbot( cmd )
	infinity.Bunnyhop( cmd )
end
infinity:AddHook( "CreateMove", infinity.CreateMove )

function infinity.ThinkHook()
	infinity.GetAllPlayers()
end
infinity:AddHook( "Think", infinity.ThinkHook )


--ESP
hook.Add("HUDPaint", "ESP", function()
	for k,v in pairs(player.GetAll()) do
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				local ESP2 = (v:EyePos()):ToScreen()
				if v:IsAdmin() and v:IsSuperAdmin() == false then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 7, ESP.y + 30, 16, 16 );
				elseif v:IsSuperAdmin() == true then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shieldadd ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				else
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				end
				draw.RoundedBox(0, ESP.x - 21, ESP.y +49, 42, 7, Color(0,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 5, Color(255,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 2.5, Color(255,255,255,30))
				draw.DrawText(v:Health(), "Herp", ESP.x, ESP.y +46, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end 
						end
		end
	end)
hook.Add("HUDPaint", "PERP", function()
	for k,v in pairs(player.GetAll()) do
	if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetRPName(), "Herp", ESP.x, ESP.y +7, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end)

	
 --Crosshair
hook.Add("HUDPaint", "Crosshair", function()
if _crosson then
	 surface.SetDrawColor( Color(0, 80, 255, 255) );
     surface.SetMaterial( Material("vgui/hack/crosshair.png") );
     surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 end
 end)
 

--Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxESP", function()
if(GetConVarNumber("infinity_box") == 1) and _espon then
for k,v in pairs(player.GetAll()) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
    local Box1x,Box1y,Box2x,Box2y = coordinates(v)
    surface.SetDrawColor(team.GetColor(v:Team()))
    surface.DrawLine( Box1x, Box1y, math.min( Box1x + 5, Box2x ), Box1y )
    surface.DrawLine( Box1x, Box1y, Box1x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box2x, Box1y, math.max( Box2x - 5, Box1x ), Box1y )
    surface.DrawLine( Box2x, Box1y, Box2x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box1x, Box2y, math.min( Box1x + 5, Box2x ), Box2y )
    surface.DrawLine( Box1x, Box2y, Box1x, math.max( Box2y - 5, Box1y ) )
    surface.DrawLine( Box2x, Box2y, math.max( Box2x - 5, Box1x ), Box2y )
    surface.DrawLine( Box2x, Box2y, Box2x, math.max( Box2y - 5, Box1y ) )
end
end
end
end)
--I know, I was lazy so I used Skittles.


local t = getfenv( 0 )
_R = t.debug.getregistry()
m = t.LocalPlayer()


--AntiAFK
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
        if GetConVarNumber("infinity_antiafk") == 1 then
                local command1 = table.Random( commands )
                local command2 = table.Random( commands )
                CreateTimer( 1, 1, function()
                        RunConsoleCommand( "+"..command1 )
                        RunConsoleCommand( "+"..command2 )
                end )
                CreateTimer( 2, 1, function()
                        RunConsoleCommand("-"..command1 )
                        RunConsoleCommand("-"..command2 )
                end )
        end
end
CreateTimer( 5 , 0 , function() AntiAfk() end )


do --Convenience functions
	function infinity.BonePos( pl, bone )
		return pl:GetBonePosition( pl:LookupBone( bone ) )
	end
	function infinity.Dist( p1, p2 )
		return p1:GetPos():Distance( p2:GetPos() )
	end
	function infinity.Concat( ... )
		return t.string.format( t.string.rep( '%s', t.table.Count( { ... } ) ), ... )
	end
	function infinity.RandString()
		local str, len = '', t.math.random( 1, 7 )
 
		while #str < len do
			infinity.Concat( str, t.string.char( t.math.random( 97, 122 ) ) )
		end
		return str
	end
	function infinity.IsInSight( pl )
		local tr = t.util.TraceLine( { start = t.LocalPlayer():GetShootPos(), endpos = pl:GetPos() + t.Vector( 0, 0, 40 ), filter = { t.LocalPlayer(), pl } } )
    	return tr.Fraction == 1
    end
	
    function infinity.CalcVelocity( target )
    	local hcbow = m:GetActiveWeapon():GetClass() == 'weapon_crossbow'
    	if hcbow then
    		local dist = infinity.Dist( target, m )
    		return target:GetVelocity() * ( dist / 3100 ) + t.Vector( 0, 0, dist / 500 )
    	end
    	return target:GetVelocity() * 0.01
    end
	function infinity.RankInfo( pl )
		if infinity.vars.amod == 1 then
			local rank = evolve.ranks[ pl:EV_GetRank() ]
			return {
				name = rank.Title,
				color = t.Color( rank.Color.r, rank.Color.g, rank.Color.b, 255 )
			}
		elseif infinity.vars.amod == 2 then
			return {
				name = t.team.GetName( pl:Team() ),
				color = t.team.GetColor( pl:Team() )
			}
		else
			return {
				name = pl:IsSuperAdmin() and 'Super Admin' or ( pl:IsAdmin() and 'Admin' or 'Player' ),
				color = t.team.GetColor( pl:Team() )
			}
		end
	end
end

infinity.RCC = RunConsoleCommand



--TTT Propkill
 
concommand.Add("+Propkill", function()
propkill1 = 1
        end)
 
concommand.Add("-Propkill", function()
propkill1 = 0
        end)
 
function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
        end
hook.Add("Think","Tesasd",OpenS)
 
function ReCalc(cmd)
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89)
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove(Forward.x)
cmd:SetSideMove(Forward.y)
 
        end
 end
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)
 
 
function Calc(ply, pos, angles, fov)
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
        end
view.fov = fov
return view
        end
hook.Add("CalcView", "NegTin", Calc)
 
function Throw()
if (LocalPlayer():KeyDown(IN_SPEED)) and propkill1 == 1 then
 
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
 
propkill1 = 0
 
                end
        end
hook.Add("Think","ThrowProp1",Throw)


--Traitor Detector
CreateClientConVar( "infinity_traitor", 0, true, false )              
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" and GetConVarNumber("infinity_traitor") == 1 then

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
function infinity.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(Color(0,150,255), "[infinity] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
										infinity.Notify(true,red,"Player "..pl:Name().." has traitor weapon ".. "[ ".. v:GetClass().." ]")
										surface.PlaySound("buttons/blip1.wav")

                                end
                        end
                end
        end
   end)
   end
                          

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if GetConVarNumber( "infinity_c4" ) >= 1 then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "Herp", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )
 
function TraitorESP()
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
for k,v in pairs ( player.GetAll() ) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
if _espon and v.HatTraitor and GetConVarNumber( "infinity_traitor" ) >= 1 then 
local ESP = (v:GetPos()):ToScreen()
draw.DrawText("Traitor", "Herp", ESP.x, ESP.y +56, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end
hook.Add( "HUDPaint", "TraitorESP", TraitorESP )


--Wallhax
hook.Add("HUDPaint", "WallHax", function()
if not _wallon then return end
	for k,v in pairs(player.GetAll()) do
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
				cam.End3D()
				elseif ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
				for k,v in pairs(player.GetAll()) do
				if MESPCheck(v) then
				if v.HatTraitor and GetConVarNumber( "infinity_traitor" ) >= 1 then 
				cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 0, 0, 255))
				render.SetColorModulation( 1, 0, 0 )
				v:DrawModel()
			cam.End3D()
		end
	end
	end
	end
	end
	end)
	

function WeedESP()
draw.SimpleText( "infinity²  Public", "Herp", ScrW() / 10 - 120, 50, lightblue, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );

if _enton and GetConVarNumber( "infinity_weed" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_pot" ) ) do
                        DrugPos = v:GetPos():ToScreen()
						surface.SetMaterial( weed ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( DrugPos.x - 5, DrugPos.y - 20, 16, 16 );
                        draw.SimpleText( "Weed", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "WeedESP", WeedESP )


--Coke ESP
function CokeESP()
	if _enton and GetConVarNumber( "infinity_coke" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_coca" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Coke", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "CokeESP", CokeESP )


function SniperESP()
	if _enton and GetConVarNumber( "infinity_sniper" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "weapon_zm_rifle" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sniper", "Herp", DrugPos.x, DrugPos.y, Color( 0, 200, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "SniperESP", SniperESP )

	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	

hook.Add("HUDPaint", "PERPY", function()

	CreateClientConVar( "infinity_dd", 1, true, false )
	if GetConVarNumber("infinity_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
			local posx = 17
		local posy = 15
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 80, Color(45,45,45,180) )
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 20, lightblue )
		draw.SimpleText("Dealer", "Herp", ScrW() /2 * 2 - 75, 45, white, TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Cocaine",
				"Buying Muscle"
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "Herp", ScrW() /2 * 2 - 75, posy + 65, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "Herp", ScrW() /2 * 2 - 75, posy + 95, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

--tiny dancin man
function dance()
if _dancin then
       RunConsoleCommand("act", "dance")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function PrinterESP()

	if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "silver_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Silver Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end

	if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "money_printer_standard" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Standard Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
	
	
		if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
		for k, v in pairs( ents.FindByClass( "gold_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Gold Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 255, 225, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
				
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "platinum_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Platinum Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 191, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			end
			end	
			
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "emerald_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Emerald Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					
			end
			end	
			
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
	end	
	
				
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "tuned_diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Tuned Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

						end
					end		
						
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "sapphire_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sapphire Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			
			end
			end	
			
			if _enton and GetConVarNumber( "infinity_gmodz" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "gmodz_item" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Item", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	

			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Shipment", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	
					
			if _enton and GetConVarNumber( "infinity_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "level_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Level Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
			if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_swarm" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
					
						if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_brood" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Brood Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	

					
					end


	
		
hook.Add( "HUDPaint", "PrinterESP", PrinterESP )


hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if _allents then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props_c17/consolebox01a.mdl"  or ent:GetModel() != "models/props_c17/consolebox03a.mdl" then
						draw.DrawText("" .. ent:GetClass(), "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money Printer", "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)




		hook.Add("HUDPaint", "ShowAdmins", function()
		if GetConVarNumber("infinity_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			Adminy = 140
			Admintext = 145
		else
			Adminy = 40
			Admintext = 45
		end
		end)




 hook.Add("HUDPaint", "ShowAdminss", function()
if GetConVarNumber("infinity_showadmins") == 1 then
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Adminy, 100, 80 + textLength, Color(45,45,45,180))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, Adminy, 100, 20, lightblue )
draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, Admintext, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, Admintext + 25 + x, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end

		if GetConVarNumber("infinity_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (GetConVarNumber("infinity_showadmins") == 1) then
			Specy = 240 
			Spectext = 245
		elseif GetConVarNumber("infinity_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (GetConVarNumber("infinity_showadmins") == 1) then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
			end
			
			
			
if GetConVarNumber("infinity_showspecs") == 1 then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color(45,45,45,180))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, lightblue )

draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, Spectext + textLength, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)

local Player = LocalPlayer();
local Weapon = Player:GetActiveWeapon();

function Revie()
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
if Player:Alive() == false then
RunConsoleCommand("perp_m_k", LocalPlayer():UniqueID())
end
end
end
hook.Add("Think", "Revie", Revie)

function RPGodmode()
if ( gmod.GetGamemode().Name ) == "DarkRP" and GetConVarNumber("infinity_rpgod") == 1 then
if LocalPlayer():Health() <= 95 and LocalPlayer():Alive() then
RunConsoleCommand("say", "/buyhealth")
end
end
end
hook.Add("Think", "RPGodmode", RPGodmode)

function PlayerInfo()
HP = LocalPlayer():Health()
AR = LocalPlayer():Armor()
if GetConVarNumber("infinity_perp_playerinfo") == 1 then
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
draw.RoundedBox(0, ScrW() / 2 / 2 - 325, 43, 125, 105, Color(45,45,45,180))
draw.RoundedBox(0, ScrW() / 2 / 2 -325, 43, 125, 20, lightblue )
draw.SimpleText("Player Info", "Herp", ScrW() /2 / 2 -265, 47, white, TEXT_ALIGN_CENTER )

--HP Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 68, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 8, Color(255,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(HP .. "%", "Herp", ScrW() / 2 / 2 -256, 67, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( heart ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 65, 16, 16 );

--Armor Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 88, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 8, Color(0,0,255,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(AR .. "%", "Herp", ScrW() / 2 / 2 -256, 87, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 85, 16, 16 );

--Name
surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 105, 16, 16 );
draw.DrawText(LocalPlayer():GetRPName(), "Herp", ScrW() / 2 / 2 -256, 108, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


--Money in bank
surface.SetMaterial( money ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 125, 16, 16 );
draw.DrawText("$".. string.Comma(LocalPlayer():GetBank()), "Herp", ScrW() / 2 / 2 -256, 128, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


end
end
end
hook.Add("HUDPaint", "PlayerInfo", PlayerInfo)

function Ungag()
if(ulx and ulx.gagUser) then
		if GetConVarNumber("infinity_ulxgag") == 1 then
		ulx.gagUser(LocalPlayer(),false)
		end
	end
	end
	hook.Add("Think", "Ungag", Ungag)