function FindDarkRPEnts()
	SystemOnline = true
	
hook.Add("HUDPaint", "FindDarkRPEnts", function()
	for _, ent in pairs(ents.GetAll()) do
		if IsValid(ent) and (ent:GetClass() == "cash_printer" or ent:GetClass() == "ent_item" or ent:GetClass() == "ent_pot" or ent:GetClass() == "shroom" or ent:GetClass() == "spawned_money"
		or ent:GetClass() == "spawned_shipment") then
			ent:SetMaterial("itemesp/dev")
		else
			end
		end
	end)
end

FindDarkRPEnts()

concommand.Add("ent_esp_perp", function()

		if SystemOnline then
			hook.Remove("HUDPaint", "FindDarkRPEnts")
			
	for _, ent in pairs(ents.GetAll()) do
		if IsValid(ent) and (ent:GetClass() == "cash_printer" or ent:GetClass() == "ent_item" or ent:GetClass() == "ent_pot" or ent:GetClass() == "shroom" or ent:GetClass() == "spawned_money"
		or ent:GetClass() == "spawned_shipment") then
			ent:SetMaterial("")
	end
end

	LocalPlayer():ChatPrint("[PERP Item ESP] - Item ESP is Unactive.")
		SystemOnline = false

			elseif !SystemOnline then
				FindDarkRPEnts()
				LocalPlayer():ChatPrint("[PERP Item ESP] - Item ESP is active.")
		SystemOnline = true
	end
end)