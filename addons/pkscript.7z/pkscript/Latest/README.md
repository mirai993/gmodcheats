# PK Script
Garry's Mod propkill script

# Installation

1. [Download zip](https://github.com/github-is-garbage/pkscript/archive/refs/heads/main.zip)
2. Open zip
3. Open pkscript-main
4. Drag pkscript folder into `garrysmod/lua` (`garrysmod/lua/pkscript`)
5. `lua_openscript_cl pkscript/pkscript.lua`
6. `pkscript_menu` to open/close menu (it's best to bind it)
