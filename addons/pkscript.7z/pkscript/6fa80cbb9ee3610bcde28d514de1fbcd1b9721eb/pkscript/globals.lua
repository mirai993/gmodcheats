pkscript.LocalPlayer = LocalPlayer()

pkscript.Colors = pkscript.Colors or {}
pkscript.Colors.Red = Color(255, 0, 0, 255)
pkscript.Colors.Green = Color(0, 255, 0, 255)

pkscript.ConVars = pkscript.ConVars or {}
pkscript.ConVars.cl_sidespeed = GetConVar("cl_sidespeed")
pkscript.ConVars.cl_forwardspeed = GetConVar("cl_forwardspeed")
