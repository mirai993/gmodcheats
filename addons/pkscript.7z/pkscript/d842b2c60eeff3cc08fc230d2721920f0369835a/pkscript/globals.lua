pkscript.LocalPlayer = LocalPlayer()

pkscript.ConVars = pkscript.ConVars or {}
pkscript.ConVars.cl_sidespeed = GetConVar("cl_sidespeed")
pkscript.ConVars.cl_forwardspeed = GetConVar("cl_forwardspeed")
