cl_interpolate = GetConVar("cl_interpolate")

cl_interp = GetConVar("cl_interp")
cl_interp_ratio = GetConVar("cl_interp_ratio")

sv_minupdaterate = GetConVar("sv_minupdaterate")
sv_maxupdaterate = GetConVar("sv_maxupdaterate")

cl_updaterate = GetConVar("cl_updaterate")

sv_client_min_interp_ratio = GetConVar("sv_client_min_interp_ratio")
sv_client_max_interp_ratio = GetConVar("sv_client_max_interp_ratio")

m_pitch = GetConVar("m_pitch")
m_yaw = GetConVar("m_yaw")

cam_size = Vector(8,8,8)

function GenerateModelData(Model) -- 0572 :)
	Model = Model or "models/error.mdl"

	if Cache.ModelData[Model] then
		return Cache.ModelData[Model]
	end

	local FileStream = file.Open(Model, "rb", "GAME")
	if not FileStream then return Cache.ModelData[Model] end

	local ID = FileStream:Read(4)
	if ID ~= "IDST" then return Cache.ModelData[Model] end
	
	Log("Parsing model '%s'", Model)

	local Data = {}
	Data.Version = FileStream:ReadLong()
	Data.Checksum = FileStream:ReadLong()

	FileStream:Read(64) -- Name

	Data.DataLength = FileStream:ReadLong()

	FileStream:Read(12) -- eyeposition
	FileStream:Read(12) -- illumposition

	FileStream:Read(12) -- hull_min
	FileStream:Read(12) -- hull_max

	FileStream:Read(12) -- view_bbmin
	FileStream:Read(12) -- view_bbmax

	Data.Flags = FileStream:ReadLong()

	-- mstudiobone_t
	Data.BoneCount = FileStream:ReadLong()
	Data.BoneOffset = FileStream:ReadLong()

	-- mstudiobonecontroller_t
	Data.BoneControllerCount = FileStream:ReadLong()
	Data.BoneControllerOffset = FileStream:ReadLong()

	-- mstudiobonecontroller_t
	Data.HitboxCount = FileStream:ReadLong()
	Data.HitboxOffset = FileStream:ReadLong()

	FileStream:Seek(Data.HitboxOffset)

	Data.szNameIndex = FileStream:ReadLong()
	Data.HitboxOffsetCount = FileStream:ReadLong()
	Data.HitboxIndex = FileStream:ReadLong()

	FileStream:Seek(Data.HitboxOffset + Data.HitboxIndex)

	Data.m_tHitboxes = {}

	for i = 1, Data.HitboxOffsetCount do
		local Temp = {}

		Temp.m_iBone = FileStream:ReadLong()
		Temp.m_iHitGroup = FileStream:ReadLong()

		Temp.m_vMins = Vector(FileStream:ReadFloat(), FileStream:ReadFloat(), FileStream:ReadFloat())
		Temp.m_vMaxs = Vector(FileStream:ReadFloat(), FileStream:ReadFloat(), FileStream:ReadFloat())
		Temp.m_vCenter = (Temp.m_vMins + Temp.m_vMaxs) / 2

		Temp.m_tCorners = {
            Vector(Temp.m_vMins.x, Temp.m_vMins.y, Temp.m_vMins.z),
            Vector(Temp.m_vMins.x, Temp.m_vMins.y, Temp.m_vMaxs.z),
            Vector(Temp.m_vMins.x, Temp.m_vMaxs.y, Temp.m_vMins.z),
            Vector(Temp.m_vMins.x, Temp.m_vMaxs.y, Temp.m_vMaxs.z),
            Vector(Temp.m_vMaxs.x, Temp.m_vMins.y, Temp.m_vMins.z),
            Vector(Temp.m_vMaxs.x, Temp.m_vMins.y, Temp.m_vMaxs.z),
            Vector(Temp.m_vMaxs.x, Temp.m_vMaxs.y, Temp.m_vMaxs.z),
            Vector(Temp.m_vMaxs.x, Temp.m_vMaxs.y, Temp.m_vMaxs.z)
        }

		Temp.szHitBoxNameIndex = FileStream:ReadLong()

		FileStream:Read(32) -- Unused

		Data.m_tHitboxes[#Data.m_tHitboxes + 1] = Temp
	end

	FileStream:Close()

	Cache.ModelData[Model] = Data
	return Data
end

function GetFOVRadius(Radius)
    if not Cache.CalcViewData.Origin then
        return 0
    end

    Radius = Radius or Vars.Aimbot.AimCone.FOV

    local Ratio = Cache.ScreenData.ScrW / Cache.ScreenData.ScrH
    local AimFOV = Radius * (math.pi / 180)
    local GameFOV = Cache.CalcViewData.FOV * (math.pi / 180)
    local ViewFOV = 2 * math.atan(Ratio * (Cache.CalcViewData.ZNear / 2) * math.tan(GameFOV / 2))

    return (math.tan(AimFOV) / math.tan(ViewFOV / 2)) * Cache.ScreenData.ScrW
end

function DistanceFromCrosshair(vPosition)
    if not vPosition then return 360 end

    local Direction = vPosition - g_pLocalPlayer:GetShootPos()
    Direction:Normalize()

    local DotProduct = g_pLocalPlayer:EyeAngles():Forward():Dot(Direction)
    local Degrees = math.deg(math.acos(DotProduct))

    return math.abs(Degrees)
end

function InFOV(vPosition)
    local Distance = DistanceFromCrosshair(vPosition)

	return Vars.Aimbot.AimCone.Enabled and Distance <= Vars.Aimbot.AimCone.FOV or true, Distance
end

function TimeToTick(flTime)
    return math.floor(flTime / TICK_INTERVAL)
end

function TickToTime(iTick)
    return iTick * TICK_INTERVAL
end

function RoundToTicks(flTime)
    return TickToTime(TimeToTick(flTime))
end

function GetServerTime()
    return TickToTime(g_pLocalPlayer:GetInternalVariable("m_nTickBase"))
end

function CanShoot()
    local Weapon = g_pLocalPlayer:GetActiveWeapon()
    if not Weapon:IsValid() then return false end
    if Weapon:GetMaxClip1() > 0 and Weapon:Clip1() <= 0 then return false end

    local CurTime = GetServerTime()
    local weptime = Weapon:GetNextPrimaryFire()

    if not Weapon:IsScripted() then
        if Weapon:GetClass() == "weapon_pistol" then
            weptime = Weapon:GetInternalVariable"m_flSoonestPrimaryAttack"
        end
    elseif Weapon.IsSWCSWeapon then
        if Weapon:GetHasBurstMode() and Weapon:GetBurstShotsRemaining() > 0 then
            weptime = Weapon:GetNextBurstShot()
        else
            local flCycleTime = Weapon:GetCycleTime()
            weptime = Weapon:GetNextPrimaryFire(flCycleTime)
        end

        if Weapon:GetIsRevolver() then
            local flFireReadyTime = Weapon:GetPostponeFireReadyTime()
            if flFireReadyTime == math.huge then return false end

            weptime = math.max(flFireReadyTime, weptime)
        end
    elseif Weapon.CSSWeapon then
        weptime = Weapon:GetNextPrimaryAttack()
    end

    return weptime < CurTime
end

function FixAngle(Angle)
    Angle.pitch = math.Clamp(math.NormalizeAngle(Angle.pitch), -89, 89)
	Angle.yaw = math.NormalizeAngle(Angle.yaw)
	Angle.roll = math.NormalizeAngle(Angle.roll)
end

function GetWeaponBase(hWeapon)
    if not hWeapon.Base then return "" end
    return hWeapon.Base:lower():Split("_")[1]
end

function GetHealthColor(pEntity)
	local DataTable = Cache.EntityData[pEntity]

	local Health = pEntity:Health()
	local ClampedHealth = math.Clamp(Health, 0, DataTable.MaxHealth)
	local Percent = ClampedHealth * (ClampedHealth / DataTable.MaxHealth)

	if Health ~= DataTable.Health or not DataTable.HealthColor then
		DataTable.Health = Health
		DataTable.HealthColor = Color(255 - (Percent * 2.55), Percent * 2.55, 0)
	end

	return DataTable.HealthColor, Percent / ClampedHealth
end

function GetWeaponPrintName(Weapon)
	if not Weapon:IsValid() then return "" end

	local Class = Weapon:GetClass()
	if Cache.WeaponNames[Class] then return Cache.WeaponNames[Class] end

	if Weapon.PrintName then
		Cache.WeaponNames[Class] = language.GetPhrase(Weapon.PrintName)
	else
		Cache.WeaponNames[Class] = Weapon.GetPrintName and language.GetPhrase(Weapon:GetPrintName()) or Class
	end

	return Cache.WeaponNames[Class]
end

function IsProtected(pEntity)	
	for i = 1, #Cache.NetMessages.Protected do
		if pEntity:GetNWBool(Cache.NetMessages.Protected[i]) then
			return true
		end
	end
		
	return false
end

function IsInGodMode(pEntity)
	if pEntity:HasGodMode() then return true end

	for i = 1, #Cache.NetMessages.God do
		if pEntity:GetNWBool(Cache.NetMessages.God[i]) then
			return true
		end
	end

	return false
end

function IsInBuildMode(pEntity)
	for i = 1, #Cache.NetMessages.Buildmode do
		if pEntity:GetNWBool(Cache.NetMessages.Buildmode[i]) then
			return true
		end
	end

	return false
end

function GetScreenCorners(pEntity)
	local Mins = Cache.EntityData[pEntity].Mins
	local Maxs = Cache.EntityData[pEntity].Maxs

	local Coords = { -- I'm sorry garbage collection :(
		pEntity:LocalToWorld(Mins):ToScreen(),
		pEntity:LocalToWorld(Vector(Mins.x, Maxs.y, Mins.z)):ToScreen(),
		pEntity:LocalToWorld(Vector(Maxs.x, Maxs.y, Mins.z)):ToScreen(),
		pEntity:LocalToWorld(Vector(Maxs.x, Mins.y, Mins.z)):ToScreen(),
		pEntity:LocalToWorld(Maxs):ToScreen(),
		pEntity:LocalToWorld(Vector(Mins.x, Maxs.y, Maxs.z)):ToScreen(),
		pEntity:LocalToWorld(Vector(Mins.x, Mins.y, Maxs.z)):ToScreen(),
		pEntity:LocalToWorld(Vector(Maxs.x, Mins.y, Maxs.z)):ToScreen()
	}

	local Left, Right, Top, Bottom = Coords[1].x, Coords[1].x, Coords[1].y, Coords[1].y

	for i = 1, #Coords do
		local v = Coords[i]
		if Left > v.x then Left = v.x end
		if Top > v.y then Top = v.y end
		if Right < v.x then Right = v.x end
		if Bottom < v.y then Bottom = v.y end
	end

	return math.Round(Left), math.Round(Right), math.Round(Top), math.Round(Bottom)
end

-- Updates the entity data for this entity
function UpdateEntityInfo(pEntity)
	Cache.EntityData[pEntity] = Cache.EntityData[pEntity] or {}
	local EntityTable = Cache.EntityData[pEntity]
    
	local IsPlayer = pEntity:IsPlayer()

	EntityTable.Dormant = pEntity:IsDormant()
	EntityTable.Name = IsPlayer and pEntity:GetName() or (pEntity.PrintName or pEntity.ClassName or pEntity:GetClass())
	if not IsPlayer and EntityTable.Name:len() < 1 then EntityTable.Name = pEntity:GetClass() end

	EntityTable.MaxHealth = pEntity:GetMaxHealth()
	EntityTable.HealthColor = GetHealthColor(pEntity)
	EntityTable.Health = pEntity:Health()

	if IsPlayer then
		EntityTable.Alive = pEntity:Alive()
	else
		if pEntity:IsNPC() or pEntity:IsNextBot() then
			EntityTable.Alive = EntityTable.Health >= 1
		else
			EntityTable.Alive = true
		end
	end

    EntityTable.Weapon = pEntity.GetActiveWeapon and GetWeaponPrintName(pEntity:GetActiveWeapon()) or ""
	EntityTable.Invisible = pEntity:IsEffectActive(EF_NODRAW) or pEntity:GetColor().a < 1
	EntityTable.Mins, EntityTable.Maxs = pEntity:GetCollisionBounds()
	EntityTable.BoundingRadius = pEntity:BoundingRadius()

	EntityTable.ShouldRender = EntityTable.Alive and not EntityTable.Dormant and not EntityTable.Invisible

	return EntityTable
end

function UpdatePlayerInfo(hPlayer)
    UpdateEntityInfo(hPlayer)

    Cache.EntityData[hPlayer] = Cache.EntityData[hPlayer] or {}
	local PlayerTable = Cache.EntityData[hPlayer]

	PlayerTable.UserGroup = hPlayer:GetUserGroup()
	PlayerTable.ObserverMode = hPlayer:GetObserverMode()
	PlayerTable.Team = hPlayer:Team()
	PlayerTable.Protected = IsProtected(hPlayer)
    PlayerTable.BuildMode = IsInBuildMode(hPlayer)
    PlayerTable.GodMode = IsInGodMode(hPlayer)

    if not IsValid(PlayerTable.AvatarImage) then
		local AvatarImage = vgui.Create("AvatarImage")

		AvatarImage:SetSize(16, 16)
		AvatarImage:SetVisible(false)
		AvatarImage:SetPaintedManually(true)
		AvatarImage:SetPlayer(hPlayer, 16)

		PlayerTable.AvatarImage = AvatarImage
	end

	PlayerTable.ShouldRender = PlayerTable.Alive and not PlayerTable.Dormant and not PlayerTable.Observing and PlayerTable.Team ~= TEAM_SPECTATOR and not PlayerTable.Invisible and hPlayer ~= g_pLocalPlayer

	if hPlayer == g_pLocalPlayer then
		g_pLocalPlayer = LocalPlayer()
		g_pActiveWeapon = hPlayer:GetActiveWeapon()
	end

	return PlayerTable
end

function GetLerpTime()
    if not cl_interpolate:GetBool() then
        return 0
    end

    if sv_minupdaterate and sv_maxupdaterate then
        cl_updaterate = sv_maxupdaterate:GetInt()
    end

    local ratio = cl_interp_ratio:GetFloat()
    if ratio == 0 then
        ratio = 1
    end

    local lerp = cl_interp:GetFloat()
    if sv_client_max_interp_ratio and sv_client_max_interp_ratio and sv_client_min_interp_ratio:GetFloat() ~= 1 then
        ratio = math.Clamp(ratio, sv_client_min_interp_ratio:GetFloat(), sv_client_max_interp_ratio:GetFloat())
    end

    return math.max(lerp, ratio / cl_updaterate)
end

function IsTickValid(flTime)
    local correct = 0
    local lerpticks = TimeToTick(GetLerpTime())

    correct = correct + (g_pLocalPlayer:Ping() / 1000) --proxi.GetFlowIncoming() + proxi.GetFlowOutgoing()
    correct = correct + TickToTime(lerpticks)
    correct = math.Clamp(correct, 0, 1)

    local targettick = TimeToTick(flTime) -- lerpticks
    local servertick = g_pLocalPlayer:GetInternalVariable("m_nTickBase")
    local deltatime = correct - TickToTime(servertick - targettick)

    return math.abs(deltatime) < 0.2, deltatime
end

RunConsoleCommand("cl_updaterate", 1 / TICK_INTERVAL)
RunConsoleCommand("cl_cmdrate", 1 / TICK_INTERVAL)
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("cl_interp_ratio", 0)