local MainFrame = fgui.Create("FHFrame")
MainFrame:SetVisible(false)
MainFrame:SetTitle("Kitty Ware :3")
MainFrame:SetSize(600, 350)
MainFrame:SetDeleteOnClose(false)
MainFrame:CenterVertical()

local FrameW, FrameH = MainFrame:GetSize()
MainFrame:SetPos(Cache.ScreenData.Center.X - FrameW/2, Cache.ScreenData.Center.Y - FrameH/2)

Cache.Menu = MainFrame

MainFrame._OldPerformLayout = MainFrame.PerformLayout

MainFrame.PerformLayout = RegisterFunction(function(self, w, h)
	MainFrame._OldPerformLayout(self, w, h)

	local MainFrameTabs = fgui.Create("FHTabbedMenu", self)
	MainFrameTabs:Dock(FILL)
	MainFrameTabs:SetTabBackground(true)
	local MainTabs = MainFrameTabs:AddTabs("Aimbot", "HvH", "Visuals", "Miscellaneous", "Players List", "Config")

	local AimbotPanel = MainTabs[1]

    local AimbotSection = fgui.Create("FHSection", AimbotPanel)
	AimbotSection:SetSize(270, 165)
	AimbotSection:SetPos(5, 5)
	AimbotSection:SetTitle("Aimbot")

	local AimbotEnabled = fgui.Create("FHCheckBox", AimbotSection)
	AimbotEnabled:SetPos(20, 20)
	AimbotEnabled:SetText("Enabled")
	AimbotEnabled:SetVarTable(Vars.Aimbot, "Enabled")

    local AimbotKeyEnabled = fgui.Create("FHCheckBox", AimbotSection)
	AimbotKeyEnabled:SetPos(40, 40)
	AimbotKeyEnabled:SetText("On Key")
	AimbotKeyEnabled:SetVarTable(Vars.Aimbot.Key, "Enabled")

	local AimbotSilent = fgui.Create("FHCheckBox", AimbotSection)
	AimbotSilent:SetPos(40, 60)
	AimbotSilent:SetText("Silent Aim")
	AimbotSilent:SetVarTable(Vars.Aimbot, "Silent")

	local AimbotNoSpread = fgui.Create("FHCheckBox", AimbotSection)
    AimbotNoSpread:SetPos(40, 80)
	AimbotNoSpread:SetText("No-Spread")
	AimbotNoSpread:SetVarTable(Vars.Aimbot, "Nospread")

    local AimbotNoRecoil = fgui.Create("FHCheckBox", AimbotSection)
    AimbotNoRecoil:SetPos(40, 100)
	AimbotNoRecoil:SetText("No-Recoil")
	AimbotNoRecoil:SetVarTable(Vars.Aimbot, "Norecoil")

    local AimbotMultiPoint = fgui.Create("FHCheckBox", AimbotSection)
	AimbotMultiPoint:SetPos(40, 120)
	AimbotMultiPoint:SetText("Multi-Point")
	AimbotMultiPoint:SetVarTable(Vars.Aimbot, "MultiPoint")

	local AimbotpSilent = fgui.Create("FHCheckBox", AimbotSection)
	AimbotpSilent:SetPos(40, 140)
	AimbotpSilent:SetText("pSilent")
	AimbotpSilent:SetVarTable(Vars.Aimbot, "pSilent")

	local AimbotKeyBinder = fgui.Create("FHBinder", AimbotSection)
	AimbotKeyBinder:SetSize(80, 20)
	AimbotKeyBinder:SetPos(130, 30)
	AimbotKeyBinder:SetLabel("Key Code")
	AimbotKeyBinder:SetVarTable(Vars.Aimbot.Key, "Code")

	local AimbotAimAtHitbox = fgui.Create("FHDropDown", AimbotSection)
	AimbotAimAtHitbox:SetSize(80, 18)
	AimbotAimAtHitbox:SetPos(130, 55)
	AimbotAimAtHitbox:AddChoice("Head", HITGROUP_HEAD)
	AimbotAimAtHitbox:AddChoice("Chest", HITGROUP_CHEST)
	AimbotAimAtHitbox:AddChoice("Stomach", HITGROUP_STOMACH)
	AimbotAimAtHitbox:ChooseOption("Head", HITGROUP_HEAD)
	AimbotAimAtHitbox.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.Aimbot.AimAtHitbox = data
	end)

	local AimbotSilent = fgui.Create("FHCheckBox", AimbotSection)
	AimbotSilent:SetPos(130, 80) 
	AimbotSilent:SetText("Resolver")
	AimbotSilent:SetVarTable(Vars.Aimbot, "Resolver")

    local TriggerbotSection = fgui.Create("FHSection", AimbotPanel)
	TriggerbotSection:SetSize(280, 165)
	TriggerbotSection:SetPos(285, 5)
	TriggerbotSection:SetTitle("Triggerbot")

    local TriggerbotEnabled = fgui.Create("FHCheckBox", TriggerbotSection)
	TriggerbotEnabled:SetPos(20, 20)
	TriggerbotEnabled:SetText("Enabled")
	TriggerbotEnabled:SetVarTable(Vars.Aimbot.Triggerbot, "Enabled")

    local TriggerbotOnCrosshair = fgui.Create("FHCheckBox", TriggerbotSection)
	TriggerbotOnCrosshair:SetPos(40, 40)
	TriggerbotOnCrosshair:SetText("On Crosshair")
	TriggerbotOnCrosshair:SetVarTable(Vars.Aimbot.Triggerbot, "OnCrosshair")

    local TriggerbotAutoWall = fgui.Create("FHCheckBox", TriggerbotSection)
	TriggerbotAutoWall:SetPos(40, 60)
	TriggerbotAutoWall:SetText("Auto Wall")
	TriggerbotAutoWall:SetVarTable(Vars.Aimbot.Triggerbot, "AutoWall")

	local TriggerAutoShoot = fgui.Create("FHCheckBox", TriggerbotSection)
	TriggerAutoShoot:SetPos(40, 80)
	TriggerAutoShoot:SetText("Auto Shoot")
	TriggerAutoShoot:SetVarTable(Vars.Aimbot.Triggerbot.AutoShoot, "Enabled")

    local TriggerAutoShoot = fgui.Create("FHCheckBox", TriggerbotSection)
	TriggerAutoShoot:SetPos(60, 100)
	TriggerAutoShoot:SetText("Slow Fire")
	TriggerAutoShoot:SetVarTable(Vars.Aimbot.Triggerbot.AutoShoot.Slow, "Enabled")

    local TriggerWaitTime = fgui.Create("FHSlider", TriggerbotSection)
	TriggerWaitTime:SetText("Wait Time")
	TriggerWaitTime:SetPos(60, 116)
	TriggerWaitTime:SetWide(200)
	TriggerWaitTime:SetMinMax(0, 3)
	TriggerWaitTime:SetDecimals(1)
	TriggerWaitTime:SetVarTable(Vars.Aimbot.Triggerbot.AutoShoot.Slow, "Amount")

	local TargetAdjustmentsSection = fgui.Create("FHSection", AimbotPanel)
	TargetAdjustmentsSection:SetSize(560, 110)
	TargetAdjustmentsSection:SetPos(5, 175)
	TargetAdjustmentsSection:SetTitle("Adjust Targeting")

	local IgnoreProtected = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreProtected:SetPos(20, 20)
	IgnoreProtected:SetText("Ignore Protected")
	IgnoreProtected:SetVarTable(Vars.Aimbot.IgnoreFlags, "Protected")

	local IgnoreFriends = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreFriends:SetPos(20, 40)
	IgnoreFriends:SetText("Ignore Friends")
	IgnoreFriends:SetVarTable(Vars.Aimbot.IgnoreFlags, "Friends")

	local IgnoreBuildMode = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreBuildMode:SetPos(20, 60)
	IgnoreBuildMode:SetText("Ignore BuildMode")
	IgnoreBuildMode:SetVarTable(Vars.Aimbot.IgnoreFlags, "Buildmode")

	local IgnoreGodmode = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreGodmode:SetPos(20, 80)
	IgnoreGodmode:SetText("Ignore Godmode")
	IgnoreGodmode:SetVarTable(Vars.Aimbot.IgnoreFlags, "Godmode")

	local IgnorePlayers = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnorePlayers:SetPos(150, 20)
	IgnorePlayers:SetText("Ignore Players")
	IgnorePlayers:SetVarTable(Vars.Aimbot.IgnoreFlags, "Players")

	local IgnoreNPCs = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreNPCs:SetPos(150, 40)
	IgnoreNPCs:SetText("Ignore NPCS")
	IgnoreNPCs:SetVarTable(Vars.Aimbot.IgnoreFlags, "NPCs")

	local IgnoreNextBots = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	IgnoreNextBots:SetPos(150, 60)
	IgnoreNextBots:SetText("Ignore NextBots")
	IgnoreNextBots:SetVarTable(Vars.Aimbot.IgnoreFlags, "NextBots")
    
	local ToggleAimCone = fgui.Create("FHCheckBox", TargetAdjustmentsSection)
	ToggleAimCone:SetPos(295, 20)
	ToggleAimCone:SetText("Aim Cone")
	ToggleAimCone:SetVarTable(Vars.Aimbot.AimCone, "Enabled")

	local AimbotAdjustAimConeFov = fgui.Create("FHSlider", TargetAdjustmentsSection)
	AimbotAdjustAimConeFov:SetText("Cone Fov")
	AimbotAdjustAimConeFov:SetPos(295, 33)
	AimbotAdjustAimConeFov:SetWide(250)
	AimbotAdjustAimConeFov:SetMinMax(0, 60)
	AimbotAdjustAimConeFov:SetDecimals(0)
	AimbotAdjustAimConeFov:SetVarTable(Vars.Aimbot.AimCone, "FOV")

	local AimbotAdjustAimConeColor = fgui.Create("FHColorButton", TargetAdjustmentsSection)
	AimbotAdjustAimConeColor:SetSize(80, 19)	
	AimbotAdjustAimConeColor:SetPos(295, 60)
	AimbotAdjustAimConeColor:SetText("Cone Color")
	AimbotAdjustAimConeColor:SetVarTable(Vars.Aimbot.AimCone, "Color")

	local HvHPanel = MainTabs[2]

	local AntiAimSection = fgui.Create("FHSection", HvHPanel)
	AntiAimSection:SetSize(560, 175)
	AntiAimSection:SetPos(5, 5)
	AntiAimSection:SetTitle("Anti Aim")

	local AntiAimEnabled = fgui.Create("FHCheckBox", AntiAimSection)
	AntiAimEnabled:SetPos(20, 20)
	AntiAimEnabled:SetText("Enabled")
	AntiAimEnabled:SetVarTable(Vars.AntiAim, "Enabled")

	local AntiAimPitchMethod = fgui.Create("FHDropDown", AntiAimSection)
	AntiAimPitchMethod:SetSize(80, 18)
	AntiAimPitchMethod:SetPos(40, 40)
	AntiAimPitchMethod:AddChoice("None", 1)
	AntiAimPitchMethod:AddChoice("Up", 2)
	AntiAimPitchMethod:AddChoice("Down", 3)
	AntiAimPitchMethod:AddChoice("Jitter", 4)
	AntiAimPitchMethod:AddChoice("Front", 5)
	AntiAimPitchMethod:AddChoice("Custom", 6)		
	AntiAimPitchMethod:AddChoice("Fake Up", 7)
	AntiAimPitchMethod:AddChoice("Fake Down", 8) 
	AntiAimPitchMethod:AddChoice("Fake Zero Down", 9)
	AntiAimPitchMethod:ChooseOption("Pitch", 1)

	AntiAimPitchMethod.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.AntiAim.PitchMethod = data
	end)
			
	local AntiAimYawMethod = fgui.Create("FHDropDown", AntiAimSection)
	AntiAimYawMethod:SetSize(80, 18)
	AntiAimYawMethod:SetPos(125, 40)
	AntiAimYawMethod:AddChoice("None", 1)
	AntiAimYawMethod:AddChoice("Spinbot", 2)
	AntiAimYawMethod:AddChoice("Jitter", 3)
	AntiAimYawMethod:AddChoice("Jitter Backwards", 4)
	AntiAimYawMethod:AddChoice("Fake Forwards", 5)
	AntiAimYawMethod:AddChoice("Fake Sideways", 6)
	AntiAimYawMethod:AddChoice("Fake Spinbot", 7)
	AntiAimYawMethod:AddChoice("Fake Custom", 8)
	AntiAimYawMethod:ChooseOption("Yaw", 1)
	AntiAimYawMethod.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.AntiAim.YawMethod = data
	end)
	
	local AntiAimPitch = fgui.Create("FHSlider", AntiAimSection)
	AntiAimPitch:SetText("Pitch")
	AntiAimPitch:SetPos(40, 56)
	AntiAimPitch:SetWide(300)
	AntiAimPitch:SetMinMax(-89, 89)
	AntiAimPitch:SetDecimals(0)
	AntiAimPitch:SetVarTable(Vars.AntiAim.CustomAngles, "Pitch")

	local AntiAimYawReal = fgui.Create("FHSlider", AntiAimSection)
	AntiAimYawReal:SetText("Real Yaw")
	AntiAimYawReal:SetPos(40, 76)
	AntiAimYawReal:SetWide(300)
	AntiAimYawReal:SetMinMax(-180, 180)
	AntiAimYawReal:SetDecimals(0)
	AntiAimYawReal:SetVarTable(Vars.AntiAim.CustomAngles, "RealYaw")

	local AntiAimYawFake = fgui.Create("FHSlider", AntiAimSection)
	AntiAimYawFake:SetText("Fake Yaw")
	AntiAimYawFake:SetPos(40, 96)
	AntiAimYawFake:SetWide(300)
	AntiAimYawFake:SetMinMax(-180, 180)
	AntiAimYawFake:SetDecimals(0)
	AntiAimYawFake:SetVarTable(Vars.AntiAim.CustomAngles, "FakeYaw")

	local AntiAimBreakerEnabled = fgui.Create("FHCheckBox", AntiAimSection)
	AntiAimBreakerEnabled:SetPos(40, 125)
	AntiAimBreakerEnabled:SetText("Lby Breaker")
	AntiAimBreakerEnabled:SetVarTable(Vars.AntiAim.LbyBreaker, "Enabled")

	local AntiAimBreakerDelta = fgui.Create("FHSlider", AntiAimSection)
	AntiAimBreakerDelta:SetText("Breaker Delta")
	AntiAimBreakerDelta:SetPos(40, 140)
	AntiAimBreakerDelta:SetWide(300)
	AntiAimBreakerDelta:SetMinMax(-90, 90)
	AntiAimBreakerDelta:SetDecimals(0)
	AntiAimBreakerDelta:SetVarTable(Vars.AntiAim.LbyBreaker, "Delta")

	local FakeLagSection = fgui.Create("FHSection", HvHPanel)
	FakeLagSection:SetSize(560, 100)
	FakeLagSection:SetPos(5, 185)
	FakeLagSection:SetTitle("Fake Lag")

	local FakeLagEnabled = fgui.Create("FHCheckBox", FakeLagSection)
	FakeLagEnabled:SetPos(20, 20)
	FakeLagEnabled:SetText("Enabled")
	FakeLagEnabled:SetVarTable(Vars.FakeLag, "Enabled")

	local FakeLagChoke = fgui.Create("FHSlider", FakeLagSection)
	FakeLagChoke:SetText("Choke")
	FakeLagChoke:SetPos(20, 36)
	FakeLagChoke:SetWide(300)
	FakeLagChoke:SetMinMax(0, 14)
	FakeLagChoke:SetDecimals(0)
	FakeLagChoke:SetVarTable(Vars.FakeLag, "Choke")

	local FakeLagMethod = fgui.Create("FHDropDown", FakeLagSection)
	FakeLagMethod:SetSize(80, 18)
	FakeLagMethod:SetPos(20, 64)
	FakeLagMethod:AddChoice("Static", 1)
	FakeLagMethod:AddChoice("Adaptive", 2)
	FakeLagMethod:AddChoice("Random", 3)
	FakeLagMethod:ChooseOption("Static", 1)
	FakeLagMethod.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.FakeLag.Method = data
	end)

	local VisualPanel = MainTabs[3]

	local VisualESPSection = fgui.Create("FHSection", VisualPanel)
	VisualESPSection:SetSize(170, 280)
	VisualESPSection:SetPos(5, 5)
	VisualESPSection:SetTitle("2D-ESP")

	local VisualsESPEnabled = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPEnabled:SetPos(20, 20)
	VisualsESPEnabled:SetText("Enabled")
	VisualsESPEnabled:SetVarTable(Vars.Visuals.ESP2D, "Enabled")
	
	local Visuals2DESPColor = fgui.Create("FHColorButton", VisualESPSection)	 
	Visuals2DESPColor:SetSize(60, 19)	
	Visuals2DESPColor:SetPos(100, 18)
	Visuals2DESPColor:SetText("ESP Color")
	Visuals2DESPColor:SetVarTable(Vars.Visuals.ESP2D, "Color")

	local VisualsESPName = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPName:SetPos(40, 40)
	VisualsESPName:SetText("Name")
	VisualsESPName:SetVarTable(Vars.Visuals.ESP2D, "Name")

	local VisualsESPBox = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPBox:SetPos(40, 60)
	VisualsESPBox:SetText("2D-Box")
	VisualsESPBox:SetVarTable(Vars.Visuals.ESP2D, "Box")

	local VisualsESPBox = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPBox:SetPos(40, 80)
	VisualsESPBox:SetText("Box Fill")
	VisualsESPBox:SetVarTable(Vars.Visuals.ESP2D, "BoxFill")

	local VisualsESPWeapon = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPWeapon:SetPos(40, 100)
	VisualsESPWeapon:SetText("Weapon")
	VisualsESPWeapon:SetVarTable(Vars.Visuals.ESP2D, "Weapon")

	local VisualsESPHealthEnabled = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPHealthEnabled:SetPos(40, 120)
	VisualsESPHealthEnabled:SetText("Health Information")
	VisualsESPHealthEnabled:SetVarTable(Vars.Visuals.ESP2D.Health, "Enabled")

	local VisualsESPHealthBar = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPHealthBar:SetPos(60, 140)
	VisualsESPHealthBar:SetText("Health Bar")
	VisualsESPHealthBar:SetVarTable(Vars.Visuals.ESP2D.Health, "Bar")

	local VisualsESPHealthAmount = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPHealthAmount:SetPos(60, 160)
	VisualsESPHealthAmount:SetText("Health Amount")
	VisualsESPHealthAmount:SetVarTable(Vars.Visuals.ESP2D.Health, "Amount")

	local VisualsESPSkeleton = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPSkeleton:SetPos(40, 180)
	VisualsESPSkeleton:SetText("Skeleton")
	VisualsESPSkeleton:SetVarTable(Vars.Visuals.ESP2D.Bones, "Enabled")

	local VisualsESPSkeletonLines = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPSkeletonLines:SetPos(60, 200)
	VisualsESPSkeletonLines:SetText("Lines")
	VisualsESPSkeletonLines:SetVarTable(Vars.Visuals.ESP2D.Bones, "Lines")

	local VisualsESPSkeletonPoints = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPSkeletonPoints:SetPos(60, 220)
	VisualsESPSkeletonPoints:SetText("Points")
	VisualsESPSkeletonPoints:SetVarTable(Vars.Visuals.ESP2D.Bones, "Points")

	local VisualsESPFlags = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPFlags:SetPos(40, 240)
	VisualsESPFlags:SetText("Player Flags")
	VisualsESPFlags:SetVarTable(Vars.Visuals.ESP2D, "Flags")

	local VisualsESPAvatar = fgui.Create("FHCheckBox", VisualESPSection)
	VisualsESPAvatar:SetPos(40, 260)
	VisualsESPAvatar:SetText("Avatar")
	VisualsESPAvatar:SetVarTable(Vars.Visuals.ESP2D, "Avatar")

	local Visual3DESPSection = fgui.Create("FHSection", VisualPanel)
	Visual3DESPSection:SetSize(180, 280)
	Visual3DESPSection:SetPos(185, 5)
	Visual3DESPSection:SetTitle("3D-ESP")

	local Visuals3DESPEnabled = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPEnabled:SetPos(20, 20)
	Visuals3DESPEnabled:SetText("Enabled")
	Visuals3DESPEnabled:SetVarTable(Vars.Visuals.ESP3D, "Enabled")

	local Visuals3DESPHitboxes = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPHitboxes:SetPos(40, 40)
	Visuals3DESPHitboxes:SetText("Hitboxes")
	Visuals3DESPHitboxes:SetVarTable(Vars.Visuals.ESP3D.Hitboxes, "Enabled")

	local Visuals3DESPBoundingBox = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPBoundingBox:SetPos(60, 60)
	Visuals3DESPBoundingBox:SetText("Bounding Box")
	Visuals3DESPBoundingBox:SetVarTable(Vars.Visuals.ESP3D.Hitboxes, "BoundingBox")

	local Visuals3DESPChams = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPChams:SetPos(40, 80)
	Visuals3DESPChams:SetText("Chams")
	Visuals3DESPChams:SetVarTable(Vars.Visuals.ESP3D.Chams, "Enabled")

	local Visuals3DESPVisible = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPVisible:SetPos(60, 100)
	Visuals3DESPVisible:SetText("Visible")
	Visuals3DESPVisible:SetVarTable(Vars.Visuals.ESP3D.Chams.Visible, "Enabled")

	local Visuals3DESPVisibleColor = fgui.Create("FHColorButton", Visual3DESPSection)	 
	Visuals3DESPVisibleColor:SetSize(80, 19)	
	Visuals3DESPVisibleColor:SetPos(80, 120)
	Visuals3DESPVisibleColor:SetText("Visible Color")
	Visuals3DESPVisibleColor:SetVarTable(Vars.Visuals.ESP3D.Chams.Visible, "Color")

	local Visuals3DESPVisibleMaterial = fgui.Create("FHDropDown", Visual3DESPSection)
	Visuals3DESPVisibleMaterial:SetSize(80, 18)
	Visuals3DESPVisibleMaterial:SetPos(80, 144)
	Visuals3DESPVisibleMaterial:AddChoice("Off", "off")
	Visuals3DESPVisibleMaterial:AddChoice("Flat", "flat")
	Visuals3DESPVisibleMaterial:AddChoice("Metallic", "metallic")
	Visuals3DESPVisibleMaterial:AddChoice("Cherry", "cherry")
	Visuals3DESPVisibleMaterial:AddChoice("Goo", "goo")
	Visuals3DESPVisibleMaterial:AddChoice("Glow", "glow")
	Visuals3DESPVisibleMaterial:AddChoice("Wireframe", "wireframe")
	Visuals3DESPVisibleMaterial:AddChoice("Water", "water")
	Visuals3DESPVisibleMaterial:AddChoice("Islandwater", "islandwater")
	Visuals3DESPVisibleMaterial:AddChoice("Islandframe", "islandframe")
	Visuals3DESPVisibleMaterial:ChooseOption(tostring(Vars.Visuals.ESP3D.Chams.Visible.Material), tostring(Vars.Visuals.ESP3D.Chams.Visible.Material))
	Visuals3DESPVisibleMaterial.FHOnSelect = RegisterFunction(function(self, _, _, data)
		Vars.Visuals.ESP3D.Chams.Visible.Material = data
	end)

	local Visuals3DESPOccluded = fgui.Create("FHCheckBox", Visual3DESPSection)
	Visuals3DESPOccluded:SetPos(60, 164)
	Visuals3DESPOccluded:SetText("Occluded")
	Visuals3DESPOccluded:SetVarTable(Vars.Visuals.ESP3D.Chams.Occluded, "Enabled")

	local Visuals3DESPOccludedColor = fgui.Create("FHColorButton", Visual3DESPSection)	 
	Visuals3DESPOccludedColor:SetSize(80, 19)	
	Visuals3DESPOccludedColor:SetPos(80, 184)
	Visuals3DESPOccludedColor:SetText("Occluded Color")
	Visuals3DESPOccludedColor:SetVarTable(Vars.Visuals.ESP3D.Chams.Occluded, "Color")

	local Visuals3DESPOccludedMaterial = fgui.Create("FHDropDown", Visual3DESPSection)
	Visuals3DESPOccludedMaterial:SetSize(80, 18)
	Visuals3DESPOccludedMaterial:SetPos(80, 208)
	Visuals3DESPOccludedMaterial:AddChoice("Off", "off")
	Visuals3DESPOccludedMaterial:AddChoice("Flat", "flat")
	Visuals3DESPOccludedMaterial:AddChoice("Metallic", "metallic")
	Visuals3DESPOccludedMaterial:AddChoice("Cherry", "cherry")
	Visuals3DESPOccludedMaterial:AddChoice("Goo", "goo")
	Visuals3DESPOccludedMaterial:AddChoice("Glow", "glow")
	Visuals3DESPOccludedMaterial:AddChoice("Wireframe", "wireframe")
	Visuals3DESPOccludedMaterial:AddChoice("Water", "water")
	Visuals3DESPOccludedMaterial:AddChoice("Islandwater", "islandwater")
	Visuals3DESPOccludedMaterial:AddChoice("Islandframe", "islandframe")
	Visuals3DESPOccludedMaterial:ChooseOption(tostring(Vars.Visuals.ESP3D.Chams.Occluded.Material), tostring(Vars.Visuals.ESP3D.Chams.Occluded.Material))
	Visuals3DESPOccludedMaterial.FHOnSelect = RegisterFunction(function(self, _, _, data)
		Vars.Visuals.ESP3D.Chams.Occluded.Material = data
	end)

	local VisualAAChamsSection = fgui.Create("FHSection", VisualPanel)
	VisualAAChamsSection:SetSize(160, 140)
	VisualAAChamsSection:SetPos(375, 5)
	VisualAAChamsSection:SetTitle("Anti-Aim Chams")

	local VisualAAChams = fgui.Create("FHCheckBox", VisualAAChamsSection)
	VisualAAChams:SetPos(20, 20)
	VisualAAChams:SetText("Enabled")
	VisualAAChams:SetVarTable(Vars.Visuals.AntiAimChams, "Enabled")

	local VisualAAChamFakeColor = fgui.Create("FHColorButton", VisualAAChamsSection)	 
	VisualAAChamFakeColor:SetSize(80, 19)	
	VisualAAChamFakeColor:SetPos(40, 40)
	VisualAAChamFakeColor:SetText("Fake Color")
	VisualAAChamFakeColor:SetVarTable(Vars.Visuals.AntiAimChams.Fake, "Color")

	local VisualAAChamFakeMaterial = fgui.Create("FHDropDown", VisualAAChamsSection)
	VisualAAChamFakeMaterial:SetPos(60, 64)
	VisualAAChamFakeMaterial:SetSize(90, 19)
	VisualAAChamFakeMaterial:AddChoice("Off", "off")
	VisualAAChamFakeMaterial:AddChoice("Flat", "flat")
	VisualAAChamFakeMaterial:AddChoice("Metallic", "metallic")
	VisualAAChamFakeMaterial:AddChoice("Cherry", "cherry")
	VisualAAChamFakeMaterial:AddChoice("Goo", "goo")
	VisualAAChamFakeMaterial:AddChoice("Glow", "glow")
	VisualAAChamFakeMaterial:AddChoice("Wireframe", "wireframe")
	VisualAAChamFakeMaterial:AddChoice("Water", "water")
	VisualAAChamFakeMaterial:AddChoice("Islandwater", "islandwater")
	VisualAAChamFakeMaterial:AddChoice("Islandframe", "islandframe")
	VisualAAChamFakeMaterial:ChooseOption("Fake Material", "glow")
	VisualAAChamFakeMaterial.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.Visuals.AntiAimChams.Fake.Material = data
	end)

	local VisualAAChamRealColor = fgui.Create("FHColorButton", VisualAAChamsSection)		
	VisualAAChamRealColor:SetSize(80, 19)
	VisualAAChamRealColor:SetPos(40, 88)
	VisualAAChamRealColor:SetText("Real Color")
	VisualAAChamRealColor:SetVarTable(Vars.Visuals.AntiAimChams.Real, "Color")

	local VisualAAChamRealMaterial = fgui.Create("FHDropDown", VisualAAChamsSection)
	VisualAAChamRealMaterial:SetSize(90, 19)
	VisualAAChamRealMaterial:SetPos(60, 112)
	VisualAAChamRealMaterial:AddChoice("Off", "off")
	VisualAAChamRealMaterial:AddChoice("Flat", "flat")
	VisualAAChamRealMaterial:AddChoice("Metallic", "metallic")
	VisualAAChamRealMaterial:AddChoice("Cherry", "cherry")
	VisualAAChamRealMaterial:AddChoice("Goo", "goo")
	VisualAAChamRealMaterial:AddChoice("Glow", "glow")
	VisualAAChamRealMaterial:AddChoice("Wireframe", "wireframe")
	VisualAAChamRealMaterial:AddChoice("Water", "water")
	VisualAAChamRealMaterial:AddChoice("Islandwater", "islandwater")
	VisualAAChamRealMaterial:AddChoice("Islandframe", "islandframe")
	VisualAAChamRealMaterial:ChooseOption("Real Material", "glow")
	VisualAAChamRealMaterial.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.Visuals.AntiAimChams.Real.Material = data
	end)

	local MiscellaneousPanel = MainTabs[4]

	local MiscellaneousMovementSection = fgui.Create("FHSection", MiscellaneousPanel)
	MiscellaneousMovementSection:SetSize(160, 95)
	MiscellaneousMovementSection:SetPos(5, 5)
	MiscellaneousMovementSection:SetTitle("Movement")

	local MiscellaneousMovementBhop = fgui.Create("FHCheckBox", MiscellaneousMovementSection)
	MiscellaneousMovementBhop:SetPos(20, 20)
	MiscellaneousMovementBhop:SetText("Bunny Hop")
	MiscellaneousMovementBhop:SetVarTable(Vars.Misc.Movement, "BunnyHop")

	local MiscellaneousMovementAutoStrafeEnabled = fgui.Create("FHCheckBox", MiscellaneousMovementSection)
	MiscellaneousMovementAutoStrafeEnabled:SetPos(20, 40)
	MiscellaneousMovementAutoStrafeEnabled:SetText("Auto Strafe")
	MiscellaneousMovementAutoStrafeEnabled:SetVarTable(Vars.Misc.Movement.AutoStrafe, "Enabled")

	local MiscellaneousMovementAutoStrafeMode = fgui.Create("FHDropDown", MiscellaneousMovementSection)
	MiscellaneousMovementAutoStrafeMode:SetSize(100, 20)
	MiscellaneousMovementAutoStrafeMode:SetPos(40, 60)
	MiscellaneousMovementAutoStrafeMode:AddChoice("Legit", 1)
	MiscellaneousMovementAutoStrafeMode:AddChoice("Rage", 2)
	MiscellaneousMovementAutoStrafeMode:ChooseOption("Legit", 1)
	MiscellaneousMovementAutoStrafeMode.FHOnSelect = RegisterFunction(function(self, index, value, data)
		Vars.Misc.Movement.AutoStrafe.Method = data
	end)

	local MiscThirdpersonSection = fgui.Create("FHSection", MiscellaneousPanel)
	MiscThirdpersonSection:SetSize(260, 95)
	MiscThirdpersonSection:SetPos(175, 5)
	MiscThirdpersonSection:SetTitle("Thirdperson")

	local MiscThirdpersonEnabled = fgui.Create("FHCheckBox", MiscThirdpersonSection)
	MiscThirdpersonEnabled:SetPos(20, 20)
	MiscThirdpersonEnabled:SetText("Enabled")
	MiscThirdpersonEnabled:SetVarTable(Vars.Misc.Thirdperson, "Enabled")

	local MiscThirdpersonDistance = fgui.Create("FHSlider", MiscThirdpersonSection)
	MiscThirdpersonDistance:SetText("Distance")
	MiscThirdpersonDistance:SetPos(20, 36)
	MiscThirdpersonDistance:SetWide(230)
	MiscThirdpersonDistance:SetMinMax(0, 400)
	MiscThirdpersonDistance:SetDecimals(0)
	MiscThirdpersonDistance:SetVarTable(Vars.Misc.Thirdperson, "Distance")

	local MiscChatSpamSection = fgui.Create("FHSection", MiscellaneousPanel)
	MiscChatSpamSection:SetSize(175, 95)
	MiscChatSpamSection:SetPos(5, 105)
	MiscChatSpamSection:SetTitle("Chat Spam")

	local MiscChatSpamEnabled = fgui.Create("FHCheckBox", MiscChatSpamSection)
	MiscChatSpamEnabled:SetPos(20, 20)
	MiscChatSpamEnabled:SetText("Enabled")
	MiscChatSpamEnabled:SetVarTable(Vars.Misc.ChatSpam, "Enabled")

	local MiscChatSpamDisableWhenTyping = fgui.Create("FHCheckBox", MiscChatSpamSection)
	MiscChatSpamDisableWhenTyping:SetPos(40, 40)
	MiscChatSpamDisableWhenTyping:SetText("Disable When Typing")
	MiscChatSpamDisableWhenTyping:SetVarTable(Vars.Misc.ChatSpam, "DisableWhenTyping")

	local PlayerListPanel = MainTabs[5]

	local PlayerList = fgui.Create("FHList", PlayerListPanel)
	PlayerList:Dock(FILL)
	PlayerList:SetMultiSelect(false)
	PlayerList:SetSortable(false)
	Cache.Panels.PlayerList = PlayerList

	local PlayerListIndex = PlayerList:AddColumn("Index")
	PlayerListIndex:SetFixedWidth(60)

	local PlayerListUsername = PlayerList:AddColumn("Player Name")

	local PlayerListWhitelist = PlayerList:AddColumn("Whitelisted")
	PlayerListWhitelist:SetFixedWidth(80)

	PlayerList.CacheUpdate = RegisterFunction(function(self)
		self:Clear()

		local Added = {}

		for k, v in next, Cache.Players do
			if not IsValid(v) then continue end

			if not Added[v] then
				self:AddLine(k, v:GetName(), Vars.Aimbot.Friends[v] and "True" or "False")
				Added[v] = true
			end
		end
	end)

	PlayerList.FHOnRowSelected = RegisterFunction(function(self, index, row)
		local Ply = Cache.Players[index]
		if not IsValid(Ply) then return end

		Vars.Aimbot.Friends[Ply] = not Vars.Aimbot.Friends[Ply]
		self:CacheUpdate()
	end)

	PlayerList:CacheUpdate()

	local ConfigPanel = MainTabs[6]

	local ConfigList = fgui.Create("FHList", ConfigPanel)
	ConfigList:Dock(FILL)
	ConfigList:SetMultiSelect(false)
	ConfigList:SetSortable(true)

	local ConfigListAutoLoad = ConfigList:AddColumn("Auto Load")
	ConfigListAutoLoad:SetFixedWidth(100)

	local ConfigListName = ConfigList:AddColumn("Name")
	ConfigListName:SetFixedWidth(290)

	local ConfigListDateMod = ConfigList:AddColumn("Date Modified")
	ConfigListDateMod:SetFixedWidth(180)

	Cache.Panels.ConfigList = ConfigList

	-- functions 

	ConfigList._OnMouseReleased = ConfigList.OnMouseReleased
	ConfigList.OnMouseReleased = RegisterFunction(function(self, MouseCode)
		self:_OnMouseReleased(MouseCode)

		if MouseCode == MOUSE_RIGHT then
			local Options = DermaMenu()

			Options:AddOption("Clear autoload", function()
				file.Delete(string.format("%s/autoload.txt", CONFIG_DIR))

				for k, Line in next, self:GetLines() do
					if Line:GetColumnText(1) == "Yes" then
						Line:SetColumnText(1, "")
					end
				end
			end)
					
			Options:AddOption("Save current config", function()
				Derma_StringRequest("save config", "name of config to save\nfiles stored in data/jackson/config", "", function(text)
					KConfigManager:SaveConfig(text, KConfigManager.CurrConfig, true)
					RefreshConfigList()
				end, nil, "Save")
			end)

			Options:Open()
		end
	end)

	ConfigList.DoDoubleClick = RegisterFunction(function(self, LineID, Line)
		KConfigManager:LoadConfig(Line.m_strConfigName)
		RefreshConfigList()
	end)

	ConfigList.OnRowRightClick = RegisterFunction(function(self, lineID, line)
		local Options = DermaMenu()

		Options:AddOption("Clear autoload", function()
			file.Delete(string.format("%s/autoload.txt", CONFIG_DIR))

			for k, Line in next, ConfigList:GetLines() do
				if Line:GetColumnText(1) == "Yes" then
					Line:SetColumnText(1, "")
				end
			end
		end)

		Options:AddOption("Save current config", function()
			Derma_StringRequest("save config", "name of config to save\nfiles stored in data/jackson/config", "", function(text)
				KConfigManager:SaveConfig(text, KConfigManager.CurrConfig, true)
				RefreshConfigList()
			end, nil, "Save")
		end)
		
		Options:AddSpacer()
		Options:AddOption("Load", function()
			KConfigManager:LoadConfig(line.m_strConfigName)
		end)

		Options:AddOption("Mark as autoload", function()
			KConfigManager:MarkAsAutoload(line.m_strConfigName)
			line:SetColumnText(1, "Yes")

			for k, Line in next, ConfigList:GetLines() do
				if Line ~= line and Line:GetColumnText(1) == "Yes" then
					Line:SetColumnText(1, "")
				end
			end
		end)

		Options:AddSpacer()
		Options:AddOption("Delete", function()
			KConfigManager:DeleteConfig(line.m_strConfigName)
			ConfigList:RemoveLine(lineID)
		end)

		Options:Open()
	end)

	RefreshConfigList()
end)

timer.Simple(0, RegisterFunction(function()
	MainFrame:InvalidateLayout(true)
end))

function ToggleMenu()
    local Status = not Cache.Menu:IsVisible()
    
    Cache.Menu:SetVisible(Status)

	if IsValid(Cache.Panels.PlayerList) then
		Cache.Panels.PlayerList:CacheUpdate()
	end

    if Status then
        Cache.Menu:MakePopup()
    else
        Cache.Menu:Close()
    end

    gui.EnableScreenClicker(not Status)
end