KMovement = {
    m_flCircleYaw = 0,
    m_flPrevYaw = 0,
    CurrCmd = nil
}

cl_forwardspeed = GetConVar("cl_forwardspeed")
cl_sidespeed = GetConVar("cl_sidespeed")

function FixMovement(pUserCmd)
    local qOrientation = pUserCmd:GetViewAngles()

	local MoveVector = Vector(pUserCmd:GetForwardMove(), pUserCmd:GetSideMove(), 0)
	local Yaw = math.rad(qOrientation.y - Cache.FacingAngle.y + MoveVector:Angle().y)
	local Speed = MoveVector:Length2D()

    pUserCmd:SetForwardMove(math.cos(Yaw) * Speed)
	pUserCmd:SetSideMove(math.sin(Yaw) * Speed)
end

function RotateMovement(pUserCmd, flYawRotation)
    local yaw, flSpeed
    local vMove = Vector(pUserCmd:GetForwardMove(), pUserCmd:GetSideMove(), 0)

    flSpeed = vMove:Length2D()

    local ViewAngles = pUserCmd:GetViewAngles()
    ViewAngles:Normalize()

    local ViewYaw = g_pLocalPlayer:EyeAngles().y
    if type(flYawRotation) == "number" then
        ViewYaw = ViewYaw - flYawRotation
    end
    
    yaw = math.deg(math.atan2(vMove.y, vMove.x))
    yaw = math.rad(ViewAngles.y - ViewYaw + yaw)

    pUserCmd:SetForwardMove(math.cos(yaw) * flSpeed)
    pUserCmd:SetSideMove(math.sin(yaw) * flSpeed)

    if ViewAngles.x < -90 or ViewAngles.x > 90 then
        pUserCmd:SetForwardMove(-pUserCmd:GetForwardMove())
        pUserCmd:SetSideMove(-pUserCmd:GetSideMove())
    end
end

function KMovement:ValidMovementType()
	return g_pLocalPlayer:GetMoveType() == MOVETYPE_WALK and not IsValid(g_pLocalPlayer:GetVehicle()) and g_pLocalPlayer:WaterLevel() < 2
end

local CircleFactor = 0
function KMovement:AutoStrafe(pUserCmd)
    if not Vars.Misc.Movement.AutoStrafe.Enabled then return end

    local MouseX = pUserCmd:GetMouseX()
    local Velocity = g_pLocalPlayer:GetVelocity()
    Velocity.z = 0

    local Velocity2D = Velocity:Length2D()
    
    local MaxSideMove = cl_sidespeed:GetFloat()
    local MaxForwardMove = cl_forwardspeed:GetFloat()

    if Vars.Misc.Movement.AutoStrafe.Method == 1 then
        if MouseX > 0 then
            pUserCmd:SetSideMove(MaxSideMove)
        elseif MouseX < 0 then
            pUserCmd:SetSideMove(MaxSideMove * -1)
        end
        
        if pUserCmd:KeyDown(IN_JUMP) then
            pUserCmd:SetForwardMove((MaxForwardMove * 0.5) / Velocity2D)
            pUserCmd:SetSideMove(pUserCmd:CommandNumber() % 2 == 0 and (MaxSideMove * -1) or MaxSideMove)
        end
    elseif Vars.Misc.Movement.AutoStrafe.Method == 2 then
        if input.IsButtonDown(KEY_R) then
            CircleFactor = CircleFactor + 1

            local flFactor = 5

            local turnAngle = flFactor * CircleFactor - TICK_INTERVAL
            if turnAngle >= 360 then
                CircleFactor = 0
            end
            
            local velocityYaw = math.NormalizeAngle(math.deg(math.atan2(Velocity.x, Velocity.y)))
            local yawDifference = math.NormalizeAngle(pUserCmd:GetViewAngles().y - velocityYaw)

            pUserCmd:SetForwardMove(10000)
            pUserCmd:SetSideMove(0)

            RotateMovement(pUserCmd, math.NormalizeAngle((turnAngle >= 0 and -90 or 90) - turnAngle + yawDifference))

            debugoverlay.Box(g_pLocalPlayer:GetPos(), Vector(-1, -1, -1), Vector(1, 1, 1), 10, Color(255, 0, 0))
        end
    end
    
    pUserCmd:SetSideMove(math.Clamp(pUserCmd:GetSideMove(), MaxSideMove * -1, MaxSideMove))
    pUserCmd:SetForwardMove(math.Clamp(pUserCmd:GetForwardMove(), MaxForwardMove * -1, MaxForwardMove))
end

local GroundTick = 0
function KMovement:Bhop(pUserCmd)
    if not Vars.Misc.Movement.BunnyHop then return false end
	if not pUserCmd:KeyDown(IN_JUMP) then return end

	if LocalPlayer():IsOnGround() then
		GroundTick = GroundTick + 1

		if GroundTick > 4 then
			pUserCmd:RemoveKey(IN_JUMP)
			GroundTick = 0
		end
	else
		pUserCmd:RemoveKey(IN_JUMP)
		GroundTick = 0
	end
end

function KMovement:Run(pUserCmd)
    if not self:ValidMovementType() then return end

    self:Bhop(pUserCmd)

    if not g_pLocalPlayer:IsOnGround() and g_pLocalPlayer:GetMoveType() == MOVETYPE_WALK then
        self:AutoStrafe(pUserCmd)
    end
end