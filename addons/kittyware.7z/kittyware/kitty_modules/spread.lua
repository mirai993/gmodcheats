local ai_shot_bias_min = GetConVar("ai_shot_bias_min")
local ai_shot_bias_max = GetConVar("ai_shot_bias_max")

do 
    local CUniformRandomStream = {
       Meta = {}
    }

    CUniformRandomStream.Meta.__index = CUniformRandomStream.Meta

    local NTAB = 32

    local IA = 16807
    local IM = 2147483647
    local IQ = 127773
    local IR = 2836
    local NDIV = 1 + (IM - 1) / NTAB
    local MAX_RANDOM_RANGE = 0x7FFFFFFF

    local AM = 1 / IM
    local EPS = 1.2e-7
    local RNMX = 1 - EPS

    function CUniformRandomStream.Meta:SetSeed(Seed)
        self.m_idum = Seed < 0 and Seed or -Seed
        self.m_iy = 0
    end

    function CUniformRandomStream.Meta:GenerateRandomNumber()
        local math_floor = math.floor
        local j, k = 0, 0

        if self.m_idum <= 0 or not self.m_iy then
            self.m_idum = -self.m_idum

            if self.m_idum < 1 then
                self.m_idum = 1
            end

            j = NTAB + 8
            while j > 0 do
                j = j - 1

                k = math_floor(self.m_idum / IQ)
                self.m_idum = math_floor(IA * (self.m_idum - k * IQ) - IR * k)

                if self.m_idum < 0 then
                    self.m_idum = math_floor(self.m_idum + IM)
                end

                if j < NTAB then
                    self.m_iv[j] = math_floor(self.m_idum)
                end
            end

            self.m_iy = self.m_iv[0]
        end

        k = math_floor(self.m_idum / IQ)
        self.m_idum = math_floor(IA * (self.m_idum - k * IQ) - IR * k)

        if self.m_idum < 0 then
            self.m_idum = math_floor(self.m_idum + IM)
        end

        j = math_floor(self.m_iy / NDIV)

        if j >= NTAB or j < 0 then
            ErrorNoHalt(string.format("CUniformRandomStream array overrun; Tried to write %d", j))
            j = math_floor(bit.band(j % NTAB, MAX_RANDOM_RANGE))
        end

        self.m_iy = math_floor(self.m_iv[j])
        self.m_iv[j] = math_floor(self.m_idum)

        return self.m_iy
    end

    function CUniformRandomStream.Meta:RandomFloat(Min, Max)
        Min = Min or 0
        Max = Max or 1

        local Float = AM * self:GenerateRandomNumber()

        if Float > RNMX then
            Float = RNMX
        end

        return (Float * (Max - Min)) + Min
    end

    function CUniformRandomStream.New()
        local RandomStream = setmetatable({}, CUniformRandomStream.Meta)
        RandomStream.m_iv = {}

        RandomStream:SetSeed(0)

        return RandomStream
    end

    local RandomStream = CUniformRandomStream.New()

    local ShotBiasMin = ai_shot_bias_min:GetFloat()
    local ShotBiasMax = ai_shot_bias_max:GetFloat()
    local ShotBiasDif = (ShotBiasMax - ShotBiasMin) + ShotBiasMin
    local Flatness = math.abs(ShotBiasDif) / 2
    local iFlatness = 1 - Flatness

    for Seed = 0, 255 do
        RandomStream:SetSeed(Seed)

        local FirstRan = false
        local X, Y, Z = 0, 0, 0

        while true do
            if Z <= 1 and FirstRan then break end

            X = (RandomStream:RandomFloat(-1, 1) * Flatness) + (RandomStream:RandomFloat(-1, 1) * iFlatness)
            Y = (RandomStream:RandomFloat(-1, 1) * Flatness) + (RandomStream:RandomFloat(-1, 1) * iFlatness)

            if ShotBiasDif < 0 then
                X = X >= 0 and 1 - X or -1 - X
                Y = Y >= 0 and 1 - Y or -1 - Y
            end

            Z = (X * X) + (Y * Y)
            FirstRan = true
        end

        KNoSpread.m_tEngineSeeds[Seed] = {
            X = X,
            Y = Y,
            Z = Z
        }
    end

    local function fsel(c, x, y)
        return c >= 0 and x or y
    end

    local function RemapValClamped(val, a, b, c, d)
        if a == b then
            return fsel(val - b, d, c)
        end
        
        local cVal = (val - a) / (b - a)
        cVal = math.Clamp(cVal, 0, 1)

        return c + (d - c) * cVal
    end

    local SMGVector = Vector(0.04362, 0.04362, 0.04362)
    local PulseRifleVector = Vector(0.02618, 0.02618, 0.02618)
    local FirstPistolVector = Vector(0.00873, 0.00873, 0.00873)
    local SecondPistolVector = Vector(0.05234, 0.05234, 0.05234)
    local ShotgunVector = Vector(0.08716, 0.08716, 0.08716)

    KNoSpread.m_tEngineSpread = {
        weapon_smg1 = SMGVector,
        weapon_ar2 = PulseRifleVector,
        weapon_357 = vector_origin,
        weapon_pistol = function(Weapon)
            local nv = Weapon:GetInternalVariable("m_flAccuracyPenalty")
            local ramp = RemapValClamped(nv, 0, 1.5, 0, 1)
            local cone = LerpVector(ramp, FirstPistolVector, SecondPistolVector)
        
            return cone
        end,
        weapon_shotgun = ShotgunVector
    }
end

do
    local Const = {
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
        0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
        0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,

        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
        0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
        0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,

        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
        0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
        0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,

        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
        0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
        0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,

        0x67452301, -0x10325477, -0x67452302, 0x10325476
    }

    local f = function(x, y, z)
        return bit.bor(bit.band(x, y), bit.band(-x - 1, z))
    end

    local g = function(x, y, z)
        return bit.bor(bit.band(x, z), bit.band(y, -z - 1))
    end

    local h = function(x, y, z)
        return bit.bxor(x, bit.bxor(y, z))
    end

    local i = function(x, y, z)
        return bit.bxor(y, bit.bor(x, -z - 1))
    end

    local z = function(f, a, b, c, d, x, s, ac)
        a = bit.band(a + f(b, c, d) + x + ac, 0xffffffff)
        return bit.bor(bit.lshift(bit.band(a, bit.rshift(0xffffffff, s)), s), bit.rshift(a, 32 - s)) + b
    end

    local MAX = 2 ^ 31
    local SUB = 2 ^ 32

    local function Fix(a)
        if a > MAX then
            return a - SUB
        end

        return a
    end

    local function Transform(A, B, C, D, X)
        local a, b, c, d = A, B, C, D

        a=z(f,a,b,c,d,X[ 0], 7,Const[ 1]) -- im not even gonna try with this cluster fuck
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(f,d,a,b,c,X[ 1],12,Const[ 2])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(f,c,d,a,b,X[ 2],17,Const[ 3])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(f,b,c,d,a,X[ 3],22,Const[ 4])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(f,a,b,c,d,X[ 4], 7,Const[ 5])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(f,d,a,b,c,X[ 5],12,Const[ 6])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(f,c,d,a,b,X[ 6],17,Const[ 7])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(f,b,c,d,a,X[ 7],22,Const[ 8])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(f,a,b,c,d,X[ 8], 7,Const[ 9])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(f,d,a,b,c,X[ 9],12,Const[10])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(f,c,d,a,b,X[10],17,Const[11])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(f,b,c,d,a,X[11],22,Const[12])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(f,a,b,c,d,X[12], 7,Const[13])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(f,d,a,b,c,X[13],12,Const[14])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(f,c,d,a,b,X[14],17,Const[15])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(f,b,c,d,a,X[15],22,Const[16])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

        a=z(g,a,b,c,d,X[ 1], 5,Const[17])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(g,d,a,b,c,X[ 6], 9,Const[18])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(g,c,d,a,b,X[11],14,Const[19])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(g,b,c,d,a,X[ 0],20,Const[20])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(g,a,b,c,d,X[ 5], 5,Const[21])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(g,d,a,b,c,X[10], 9,Const[22])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(g,c,d,a,b,X[15],14,Const[23])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(g,b,c,d,a,X[ 4],20,Const[24])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(g,a,b,c,d,X[ 9], 5,Const[25])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(g,d,a,b,c,X[14], 9,Const[26])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(g,c,d,a,b,X[ 3],14,Const[27])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(g,b,c,d,a,X[ 8],20,Const[28])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(g,a,b,c,d,X[13], 5,Const[29])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(g,d,a,b,c,X[ 2], 9,Const[30])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(g,c,d,a,b,X[ 7],14,Const[31])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(g,b,c,d,a,X[12],20,Const[32])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

        a=z(h,a,b,c,d,X[ 5], 4,Const[33])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(h,d,a,b,c,X[ 8],11,Const[34])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(h,c,d,a,b,X[11],16,Const[35])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(h,b,c,d,a,X[14],23,Const[36])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(h,a,b,c,d,X[ 1], 4,Const[37])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(h,d,a,b,c,X[ 4],11,Const[38])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(h,c,d,a,b,X[ 7],16,Const[39])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(h,b,c,d,a,X[10],23,Const[40])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(h,a,b,c,d,X[13], 4,Const[41])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(h,d,a,b,c,X[ 0],11,Const[42])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(h,c,d,a,b,X[ 3],16,Const[43])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(h,b,c,d,a,X[ 6],23,Const[44])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(h,a,b,c,d,X[ 9], 4,Const[45])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(h,d,a,b,c,X[12],11,Const[46])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(h,c,d,a,b,X[15],16,Const[47])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(h,b,c,d,a,X[ 2],23,Const[48])
        a=Fix(a) b=Fix(b) c = Fix(c) d=Fix(d)

        a=z(i,a,b,c,d,X[ 0], 6,Const[49])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(i,d,a,b,c,X[ 7],10,Const[50])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(i,c,d,a,b,X[14],15,Const[51])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(i,b,c,d,a,X[ 5],21,Const[52])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(i,a,b,c,d,X[12], 6,Const[53])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(i,d,a,b,c,X[ 3],10,Const[54])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(i,c,d,a,b,X[10],15,Const[55])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(i,b,c,d,a,X[ 1],21,Const[56])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(i,a,b,c,d,X[ 8], 6,Const[57])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(i,d,a,b,c,X[15],10,Const[58])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(i,c,d,a,b,X[ 6],15,Const[59])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(i,b,c,d,a,X[13],21,Const[60])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        a=z(i,a,b,c,d,X[ 4], 6,Const[61])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        d=z(i,d,a,b,c,X[11],10,Const[62])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        c=z(i,c,d,a,b,X[ 2],15,Const[63])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
        b=z(i,b,c,d,a,X[ 9],21,Const[64])
        a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

        return A + a, B + b, C + c, D + d
    end

    function KNoSpread:PseudoRandom(number)
        local a, b, c, d = Fix(Const[65]), Fix(Const[66]), Fix(Const[67]), Fix(Const[68])

        local m = {}

        for i= 0, 15 do
            m[i] = 0
        end

        m[0] = number
        m[1] = 128
        m[14] = 32

        local a,b,c,d = Transform(a,b,c,d,m)

        return bit.rshift(Fix(b), 16) % 256
    end
end