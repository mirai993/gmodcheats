KTriggerBot = {}

function KTriggerBot:ShouldRun()
    if not Vars.Aimbot.Triggerbot.Enabled then return false end

    return true
end

function KTriggerBot:Run(pUserCmd)
    if not self:ShouldRun() then return false end

    if not IsValid(g_pActiveWeapon) then return false end

    local bWantsToShoot = false

    if not bWantsToShoot then
        if Vars.Aimbot.Triggerbot.OnCrosshair and self:CanHit() then
            bWantsToShoot = true
        end

        if pUserCmd:KeyDown(IN_ATTACK) then
            bWantsToShoot = true
        end
    end

    local iWeaponBase = GetWeaponBase(g_pActiveWeapon)
    if bWantsToShoot and iWeaponBase == "bobs" and pUserCmd:KeyDown(IN_SPEED) then
        pUserCmd:RemoveKey(IN_SPEED)
    end

    if bWantsToShoot and CanShoot() then
        if pUserCmd:KeyDown(IN_ZOOM) then
            pUserCmd:RemoveKey(IN_ZOOM) 
        end

        if (iWeaponBase == "bobs" or iWeaponBase == "cw") and pUserCmd:KeyDown(IN_SPEED) then
            pUserCmd:RemoveKey(IN_SPEED) 
        end
        
        pUserCmd:AddKey(IN_ATTACK)

        if Vars.Aimbot.pSilent then g_bSendPacket = false end
    end

    if IsValid(g_pActiveWeapon) and g_pActiveWeapon:Clip1() ~= -1 and g_pActiveWeapon:Clip1() <= 0 and g_pActiveWeapon:GetNextPrimaryFire() < GetServerTime() and g_pActiveWeapon:GetClass() ~= "weapon_physgun" then
        pUserCmd:RemoveKey(bit.bor(IN_ATTACK, IN_ATTACK2))
        pUserCmd:AddKey(IN_RELOAD)
    end
end

function KTriggerBot:CanHit()
    local vDir = g_pLocalPlayer:EyeAngles():Forward()
    vDir:Mul(0x7FFF)

    local trResult = {}
    local trData = {
        start = g_pLocalPlayer:GetShootPos(),
        endpos = g_pLocalPlayer:GetShootPos() + vDir,
        mask = MASK_SHOT,
        filter = g_pLocalPlayer,

        output = trResult,
    }

    util.TraceLine(trData)

    return IsValid(trResult.Entity)
end