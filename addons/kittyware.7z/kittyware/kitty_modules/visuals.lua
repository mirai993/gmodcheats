KVisuals = {}

function OnScreen(pEntity)
	local vDirection = pEntity:GetPos() - g_pLocalPlayer:GetShootPos()
	local flLength = vDirection:Length()
	local vRadius = pEntity:BoundingRadius()

	local flMax = math.abs(math.cos(math.acos(flLength / math.sqrt((flLength * flLength) + (vRadius * vRadius))) + 60 * (math.pi / 180)))

	vDirection:Normalize()

	return vDirection:Dot(EyeVector()) > flMax
end

function KVisuals:Run2D(Entity, OptionsTable)
	local EntityTable = Cache.EntityData[Entity]
    local EntColor = Vars.Visuals.ESP2D.Color
	
	if OptionsTable.Bones.Enabled then
		Entity:SetupBones()
	
		if OptionsTable.Bones.Lines then
			surface.SetDrawColor(color_blue) -- Don't call SetDrawColor a bunch of times
		end

		for Bone = 0, Entity:GetBoneCount() - 1 do
			if not Entity:BoneHasFlag(Bone, BONE_USED_BY_HITBOX) then continue end
	
			local pMatrix = Entity:GetBoneMatrix(Bone)
			if not pMatrix then continue end
			pMatrix = pMatrix:GetTranslation():ToScreen()
	
			if OptionsTable.Bones.Points then
				surface.DrawCircle(pMatrix.x, pMatrix.y, 2, color_green)
			end
	
			if OptionsTable.Bones.Lines then
				local Parent = Entity:GetBoneParent(Bone)
				if Parent == -1 or not Entity:BoneHasFlag(Parent, BONE_USED_BY_HITBOX) then continue end
	
				local ParentMatrix = Entity:GetBoneMatrix(Parent)
				if not ParentMatrix then continue end
				ParentMatrix = ParentMatrix:GetTranslation():ToScreen()
	
				surface.DrawLine(pMatrix.x, pMatrix.y, ParentMatrix.x, ParentMatrix.y)
			end
		end
	end
	
	local Left, Right, Top, Bottom = GetScreenCorners(Entity)
	local Width = Right - Left
	local Height = Bottom - Top
	
	if OptionsTable.Box then 
		surface.SetDrawColor(EntColor)
		surface.DrawOutlinedRect(Left, Top, Width - 1, Height - 1)

		surface.SetDrawColor(color_black)
		surface.DrawOutlinedRect(Left - 1, Top - 1, Width + 1, Height + 1)
		surface.DrawOutlinedRect(Left + 1, Top + 1, Width - 3, Height - 3)
	end

	if OptionsTable.BoxFill then
		surface.SetAlphaMultiplier(.08)

		surface.SetDrawColor(EntColor)
		surface.DrawRect(Left, Top, Width - 1, Height - 1)
		surface.SetAlphaMultiplier(1)
	end

	surface.SetFont(fgui.FontName)
	local tw, th = 0, 0
	
	if OptionsTable.Health.Enabled then
		local Barwidth, Spacer = 4, 2
		local HealthColor, HealthPercent = GetHealthColor(Entity)
		local HealthScreen = math.Round((Height * HealthPercent) - 1)
		local HealthPos = (Bottom - HealthScreen) - 1
	
		if OptionsTable.Health.Bar then
			surface.SetDrawColor(color_black)
			surface.DrawRect(Left - Spacer - Barwidth, Top - 1, Barwidth, Height + 1)
	
			surface.SetDrawColor(HealthColor)
			surface.DrawRect((Left - Spacer - Barwidth) + 1, HealthPos, Barwidth - Spacer, HealthScreen)
		end
	
		if OptionsTable.Health.Amount and EntityTable.Health ~= (EntityTable.MaxHealth) then
			tw, th = surface.GetTextSize(EntityTable.Health)
	
			local tx = Left - tw - Spacer
			if OptionsTable.Health.Bar then tx = tx - Spacer - Barwidth end
	
			local ty = math.Clamp(OptionsTable.Health.Bar and HealthPos or Top, Top, Bottom - th)
	
			surface.SetTextColor(HealthColor)
			surface.SetTextPos(tx, ty)
			surface.DrawText(EntityTable.Health)
		end
	end
	
	if OptionsTable.UserGroup then
		_, th = surface.GetTextSize(EntityTable.UserGroup)
	
		surface.SetTextColor(color_white)
		surface.SetTextPos(Right + 2, math.Clamp(Top, Top, Bottom - th))
		surface.DrawText(EntityTable.UserGroup)
	end
	
	if OptionsTable.Name then
		tw, th = surface.GetTextSize(EntityTable.Name)
	
		surface.SetTextColor(color_white)
		surface.SetTextPos(Left + (Width / 2) - (tw / 2), Top - th - 3)
		surface.DrawText(EntityTable.Name)
	end
	
	if OptionsTable.Weapon then
		local Weapon = Entity.GetActiveWeapon and Entity:GetActiveWeapon() or NULL
		if Weapon:IsValid() then
			tw = surface.GetTextSize(EntityTable.Weapon)
	
			surface.SetTextColor(color_white)
			surface.SetTextPos(Left + (Width / 2) - (tw / 2), Bottom)
			surface.DrawText(EntityTable.Weapon)
		end
	end
	
	if OptionsTable.Avatar then -- Having this above other things break the surface library
		if IsValid(EntityTable.AvatarImage) then
			local y = Top - 24
			if OptionsTable.Name then
				y = y - th
			end
	
			EntityTable.AvatarImage:PaintAt(Left + ((Width / 2) - 8), y)
		end
	end

	if OptionsTable.Flags and Entity:IsPlayer() then
        surface.SetTextColor(color_seafoam)

        local pFlags = {}

        if EntityTable.GodMode then
            pFlags[#pFlags + 1] = "*God-Mode*"
        end

        if EntityTable.BuildMode then
            pFlags[#pFlags + 1] = "*Build-Mode*"
        end

        if EntityTable.Protected then
            pFlags[#pFlags + 1] = "*Protected*"
        end

		if Vars.Aimbot.Friends[Entity] then
            pFlags[#pFlags + 1] = "*Whitelisted*"
        end

        if #pFlags > 0 then
            local ypos = Top
            local _, th = surface.GetTextSize(pFlags[1])

            for _, v in next, pFlags do
                surface.SetTextPos(Right, ypos)
                surface.DrawText(v)

                _, th = surface.GetTextSize(v)
                ypos = ypos + th
            end
        end
    end
end

local fn = FrameNumber()
KVisuals.m_tChamMaterials = {
	["off"] = CreateMaterial(fn .. tostring(SysTime() * 1), "VertexLitGeneric", {}),
	["flat"] = CreateMaterial(fn .. tostring(SysTime() * 2), "UnlitGeneric", {
		["$basetexture"] =  "vgui/white_additive",
		["$envmap"] = "",
		["$nofog"] = 1,
		["$model"] = 1,
		["$nocull"] = 0,
		["$selfillum"] = 1,
		["$halflambert"] = 1,
		["$znearer"] = 0,
		["$flat"] = 1,
		["$ignorez"] = 1,
	}),
	["metallic"] = CreateMaterial(fn .. tostring(SysTime() * 3), "VertexLitGeneric", {
		["$basetexture"] = "vgui/white_additive",
		["$envmap"] = "env_cubemap",
		["$normalmapalphaenvmapmask"] = 1,
		["$envmapcontrast"] = 1,
		["$nofog"] = 1,
		["$model"] = 1,
		["$nocull"] = 0,
		["$selfillum"] = 1,
		["$halflambert"] = 1,
		["$znearer"] = 0,
		["$flat"] = 1,
		["$ignorez"] = 1,
	}),
	["goo"] = CreateMaterial(fn .. tostring(SysTime() * 4), "VertexLitGeneric",{
		["$basetexture"] = "color/white",
		["$nocull"] = 1,
		["$model"] = 1,
		["$cloakpassenabled"] = 1,
		["$cloakcolortint"] = "[0 1 0]",
		["$cloakfactor"] = .8,
		["$selfillum"] = 1,
		["$ignorez"] = 0,
		["$phong"] = 1,
		["$phongexponent"] = 200,
		["$phongboost"] = 100,
		["$phongfresnelranges"] = "[0 .5 1]",
		["$alpha"] = 1,
	}),
	["glow"] = CreateMaterial(fn .. tostring(SysTime() * 5), "VertexLitGeneric", {
		["$additive"] = "1",
		["$basetexture"] = "vgui/white_additive",
		["$bumpmap"] = "vgui/white_additive",
		["$selfillum"] = "1",
		["$selfIllumFresnel"] = "1",
		["$selfIllumFresnelMinMaxExp"] = "[0 0.18 0.1]",
		["$selfillumtint"] = "[0 0 0]",
			
		["$ignorez"] = 1,
	}),
	["cherry"] = CreateMaterial(fn .. tostring(SysTime() * 6), "VertexLitGeneric", {
		["$basetexture"] = "vgui/white_additive",
		["$additive"] = 1,
		["$envmap"] = "",
		["$nofog"] = 1,
		["$model"] = 1,
		["$nocull"] = 1,
		["$selfillum"] = 1,
		["$halflambert"] = 1,
		["$znearer"] = 0,
		["$flat"] = 1,
		["$reflectivity"] = "[1 1 1]",
		["$ignorez"] = 1,
	}),
	["wireframe"] = CreateMaterial(fn .. tostring(SysTime() * 7), "", {
		["$basetexture"] = "models/wireframe",
		["$ignorez"] = 1
		
	}),
	["pulseframe"] = CreateMaterial(fn .. tostring(SysTime() * 11), "VertexLitGeneric",{
		["$basetexture"] = "models/effects/comball_tape",
		["$nocull"] = 1,
		["$wireframe"] = 1,
		["$additive"] = 1,
		["$envmap"] = "vgui/white_additive",
		["$envmaptint"] = "[1 1 1]",
		["$envmapfresnel"] = 1,
		["$phong"] = 1,
		["$envmapfresnelminmaxexp"] = "[0 2 4]",
		["$envmapanisotropy"] = 1,
		["$envmapanisotropyscale"] = 5,
		["$alpha"] = 1,
		["Proxies"] = {
			["TextureScroll"] = {
				["texturescrollvar"] = "$basetexturetransform",
				["texturescrollrate"] = 0.5,
				["texturescrollangle"] = math.abs(math.sin(CurTime()) * 360),
			},
		},
	}),
	["water"] = CreateMaterial(fn .. tostring(SysTime() * 12), "VertexLitGeneric", {
		["$basetexture"] = "color/white",
		["$nocull"] = 1,
		["$model"] = 1,
		["$cloakpassenabled"] = 1,
		["$cloakcolortint"] = "[1 1 1]",
		["$cloakfactor"] = 0.9,
		["$bumpmap"] = "models/shadertest/shieldnoise0_normal",
		["$detail"] = "water/tfwater001_normal",
		["$flashlighttint"] = "[1 1 1]",
		["$fogenable"] = 1,
		["$forceexpensive"] = 1,
		["$reflectentities"] = 1,
		["$refract"] = 1,
		["$refractamount"] = 0.9,
		["$alpha"] = 1,
		["Proxies"] = {
			["AnimatedTexture"] = {
				["animatedtexturevar"] = "$bumpmap",
				["animatedtextureframenumvar"] = "$bumpframe",
				["animatedtextureframerate"] = 60,
			},

			["AnimatedOffsetTexture"] = {
				["animatedtexturevar"] = "$detail",
				["animatedtextureframenumvar"] = "$detailframe",
				["animatedtextureframerate"] = 60,
			},
		},
	}),
	["islandwater"] = CreateMaterial(fn .. tostring(SysTime() * 13), "VertexLitGeneric", {
		["$basetexture"] = "water/island_water01_normal",
		["$model"] = 1,
		["$additive"] = 1,
		["$nocull"] = 1,
		["$alpha"] = 1,
		["Proxies"] = {
			["TextureScroll"] = {
				["texturescrollvar"] = "$basetexturetransform",
				["texturescrollrate"] = 1,
				["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
			},
		},
	}),
	["islandframe"] = CreateMaterial("24 " .. tostring(SysTime() * 14), "VertexLitGeneric", {
		["$wireframe"] = 1,
		["$basetexture"] = "water/island_water01_normal",
		["$model"] = 1,
		["$additive"] = 1,
		["$nocull"] = 1,
		["$alpha"] = 1,
		["Proxies"] = {
			["TextureScroll"] = {
				["texturescrollvar"] = "$basetexturetransform",
				["texturescrollrate"] = 1,
				["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
			},
		},
	})
}

function KVisuals:Run3D(Entity, OptionsTable)
	local EntityTable = Cache.EntityData[Entity]

	if OptionsTable.Hitboxes.Enabled then
		local ModelData = GenerateModelData(Entity:GetModel())

		Entity:SetupBones()

		for iHitbox, pHitbox in pairs(ModelData.m_tHitboxes) do
			local pMatrix = Entity:GetBoneMatrix(pHitbox.m_iBone)
			if not pMatrix then continue end

			local vTranslation, vAngle = pMatrix:GetTranslation(), pMatrix:GetAngles()

			render.DrawWireframeBox(vTranslation, vAngle, pHitbox.m_vMins, pHitbox.m_vMaxs, color_white, true)
		end

		if OptionsTable.Hitboxes.BoundingBox then
			render.DrawWireframeBox(Entity:GetPos(), angle_zero, Cache.EntityData[Entity].Mins, Cache.EntityData[Entity].Maxs, OptionsTable.Hitboxes.BoundingColor, true)
		end
	end

	if OptionsTable.Chams.Enabled then
		if OptionsTable.Chams.Occluded.Enabled then
			local OccludedColor = OptionsTable.Chams.Occluded.Color
			local OccludedMaterial = OptionsTable.Chams.Occluded.Material

			render.MaterialOverride(self.m_tChamMaterials[OccludedMaterial])
			render.SetColorModulation(OccludedColor.r / 255, OccludedColor.g / 255, OccludedColor.b / 255)
			render.SetBlend(OccludedColor.a / 255)

			Entity:DrawModel()
		end

		if OptionsTable.Chams.Visible.Enabled then
			local VisibleColor = OptionsTable.Chams.Visible.Color
			local VisibleMaterial = OptionsTable.Chams.Visible.Material

			render.SetColorModulation(VisibleColor.r / 255, VisibleColor.g / 255, VisibleColor.b / 255)
			render.SetBlend(VisibleColor.a / 255)
			render.MaterialOverride(self.m_tChamMaterials[VisibleMaterial])

			Entity:DrawModel()
		end
	end
end


function KVisuals:DrawAntiAimChams()
	if not Vars.Visuals.AntiAimChams.Enabled then return end
	if not g_pLocalPlayer:Alive() then return end
	
	local LocalFakeColor = Vars.Visuals.AntiAimChams.Fake.Color
	local LocalFakeMaterial = Vars.Visuals.AntiAimChams.Fake.Material
	
	local LocalRealColor = Vars.Visuals.AntiAimChams.Real.Color
	local LocalRealMaterial = Vars.Visuals.AntiAimChams.Real.Material

	cam.Start3D()
		render.SuppressEngineLighting(true)
		
		do
			render.MaterialOverride(self.m_tChamMaterials[LocalFakeMaterial])
			g_pLocalPlayer:SetRenderMode(RENDERMODE_TRANSALPHA)

			render.SetColorModulation(LocalFakeColor.r / 255, LocalFakeColor.g / 255, LocalFakeColor.b / 255)
			render.SetBlend(255)

			g_pLocalPlayer:SetRenderAngles(Angle(Cache.FakeAngle.r, Cache.FakeAngle.y, 0))
				
			g_pLocalPlayer:InvalidateBoneCache()
			g_pLocalPlayer:SetupBones()
			
			g_pLocalPlayer:DrawModel()
			render.MaterialOverride(nil)
		end
		
		do
			render.MaterialOverride(self.m_tChamMaterials[LocalRealMaterial])
			g_pLocalPlayer:SetRenderMode(RENDERMODE_TRANSALPHA)

			render.SetColorModulation(LocalRealColor.r / 255, LocalRealColor.g / 255, LocalRealColor.b / 255)
			render.SetBlend(255)
			
			g_pLocalPlayer:SetRenderAngles(Angle(Cache.RealAngle.r, Cache.RealAngle.y, 0))

			g_pLocalPlayer:InvalidateBoneCache()
			g_pLocalPlayer:SetupBones()

			g_pLocalPlayer:DrawModel()
			render.MaterialOverride(nil)
		end
		
		render.MaterialOverride()
		render.SetColorModulation(1, 1, 1)
		render.SuppressEngineLighting(false)
	cam.End3D()
end