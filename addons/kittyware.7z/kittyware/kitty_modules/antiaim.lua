--[[
    not giving p aa
    so you get shit aa
    OWNED
]]

KAntiAim = {}

local Choke = 0
function KAntiAim:FakeLag(pUserCmd)
    if pUserCmd:CommandNumber() == 0 or pUserCmd:TickCount() == 0 then return end

    if Vars.FakeLag.Enabled then
        if Choke >= Vars.FakeLag.Choke then
            Choke = 0
        else
            Choke = Choke + 1
        end

        if Vars.FakeLag.Method == 1 then
            g_bSendPacket = Choke >= Vars.FakeLag.Choke
        elseif Vars.FakeLag.Method == 2 then
            local Velocity = g_pLocalPlayer:GetVelocity()
            local Speed = Velocity:Length2D()

            local chokes = math.ceil(64 / (Speed * TICK_INTERVAL))
            chokes = math.Clamp(chokes, 1, 14)
        
            g_bSendPacket = Choke >= chokes
        elseif Vars.FakeLag.Method == 3 then
            local chokes = math.random()
            chokes = math.Clamp(chokes, 1, 14)
        
            g_bSendPacket = Choke >= chokes
        end
    else
        Choke = 0
            
        g_bSendPacket = true
    end
end

local pDance = 0
local trigger = 0
local bFlip = false

function KAntiAim:PerformPitch(pAngle)
    if Vars.AntiAim.PitchMethod == 1 then return end
 
    if Vars.AntiAim.PitchMethod == 2 then -- static up
        pAngle.x = -89.9
    elseif Vars.AntiAim.PitchMethod == 3 then -- static down
        pAngle.x = 89.9
    elseif Vars.AntiAim.PitchMethod == 4 then -- jitter
        pDance = pDance + 45
        if pDance > 100 then
            pDance = 0
        elseif pDance > 75 then
            pAngle.x = -89
        elseif pDance < 75 then
            pAngle.x = 89
        end
    elseif Vars.AntiAim.PitchMethod == 5 then -- front
        pAngle.x = 0
    elseif Vars.AntiAim.PitchMethod == 6 then
        pAngle.x = Vars.AntiAim.CustomAngles.Pitch
    elseif Vars.AntiAim.PitchMethod == 7 then
        pAngle.x = g_bSendPacket and 89 or -89
    elseif Vars.AntiAim.PitchMethod == 8 then
        pAngle.x = g_bSendPacket and -89 or 89
    elseif Vars.AntiAim.PitchMethod == 9 then -- fake zero down
        pAngle.x = 1080
    end

    return true
end

function KAntiAim:PerformYaw(pAngle)
    if Vars.AntiAim.YawMethod == 1 then return end
    
    bFlip = not bFlip

    if Vars.AntiAim.YawMethod == 2 then -- spinbot
        local SpinSpeed = Vars.AntiAim.SpinSpeed
        pAngle.y = math.fmod(GetServerTime() * SpinSpeed, 360)
    elseif Vars.AntiAim.YawMethod == 3 then -- jitter
        pAngle.y = pAngle.y - (bFlip and 30 or -30)
    elseif Vars.AntiAim.YawMethod == 4 then -- jitter backwards
        pAngle.y = pAngle.y - 180
        pAngle.y = pAngle.y - (bFlip and 30 or -30)
    elseif Vars.AntiAim.YawMethod == 5 then -- fake forwards
        pAngle.y = g_bSendPacket and pAngle.y or pAngle.y + (bFlip and 180 or -180)
    elseif Vars.AntiAim.YawMethod == 6 then -- fake sideways
        pAngle.y = g_bSendPacket and pAngle.y + (bFlip and 30 or -30) or pAngle.y + (bFlip and 180 or -180)
    elseif Vars.AntiAim.YawMethod == 7 then -- fake custom spin
        local factor = Vars.AntiAim.SpinSpeed
        pAngle.y = g_bSendPacket and math.fmod(GetServerTime() * factor, 360) or pAngle.y + (bFlip and 180 or -180)
    elseif Vars.AntiAim.YawMethod == 8 then
        pAngle.y = pAngle.y + (g_bSendPacket and Vars.AntiAim.CustomAngles.FakeYaw or Vars.AntiAim.CustomAngles.RealYaw + (bFlip and 180 or -180))
    end

    return true
end

function KAntiAim:ShouldRun(pUserCmd)
    if not Vars.AntiAim.Enabled then return false end
    if pUserCmd:CommandNumber() == 0 then return false end
    if pUserCmd:KeyDown(IN_USE) or g_pLocalPlayer:GetMoveType() == MOVETYPE_LADDER then return false end
    if pUserCmd:KeyDown(IN_ATTACK) then return false end
    if pUserCmd:TickCount() == 0 then return false end
    
    return true
end
    
local LastBreak = 0
function KAntiAim:Run(pUserCmd)
    if not self:ShouldRun(pUserCmd) then return false end
    local pViewAngles = pUserCmd:GetViewAngles()
    
    self:PerformPitch(pViewAngles)
    self:PerformYaw(pViewAngles)

    local flTime = GetServerTime()
    if Vars.AntiAim.LbyBreaker.Enabled and g_bSendPacket then
        if flTime - LastBreak >= 1.1 then
            pViewAngles.y = pViewAngles.y + Vars.AntiAim.LbyBreaker.Delta

            LastBreak = flTime
        end
    end
    
    pUserCmd:SetViewAngles(pViewAngles)
end