local M9KDisablePenetration = GetConVar("M9KDisablePenetration")
local sv_tfa_bullet_penetration = GetConVar("sv_tfa_bullet_penetration")
local sv_tfa_bullet_penetration_power_mul = GetConVar("sv_tfa_bullet_penetration_power_mul")
local sv_tfa_penetration_hardlimit = GetConVar("sv_tfa_penetration_hardlimit")
local arccw_enable_penetration = GetConVar("arccw_enable_penetration")

local AutowallFunction = {
    ["bobs"] = function(self, TraceData)
		if M9KDisablePenetration:GetBool() then
			return nil
		end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		return DataTable[1], DataTable[2]
	end,
	["tfa"] = function(self, TraceData)
		if not sv_tfa_bullet_penetration:GetBool() then
			return nil
		end

		local ForceMultiplier = self:GetAmmoForceMultiplier()
		local PenetrationMultiplier = self:GetPenetrationMultiplier(TraceData.MatType)
		local ConVarMultiplier = sv_tfa_bullet_penetration_power_mul:GetFloat()

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		local MaxPen = math.Clamp(DataTable and DataTable[2] or 1, 0, sv_tfa_penetration_hardlimit:GetInt())

		return math.Truncate(((ForceMultiplier / PenetrationMultiplier) * ConVarMultiplier) * 0.9, 5), MaxPen
	end,
	["arccw"] = function(self, TraceData)
		if not arccw_enable_penetration:GetBool() then
			return nil
		end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		return math.pow(self.Penetration, 2), DataTable and DataTable[2] or 1
	end,
	["cw"] = function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = self.PenetrationMaterialInteraction and self.PenetrationMaterialInteraction[TraceData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end,
	["fas2"] = function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = Cache.WeaponData.AutoWall.Multipliers[TraceData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end,
	["swb"] = function(self, TraceData)
		if not CWCanPenetrate(self, TraceData) then return nil end

		local DataTable = Cache.WeaponData.AutoWall.Limits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		local Multiplier = Cache.WeaponData.AutoWall.Multipliers[TraceData.MatType] or 1
		return DataTable[1] * Multiplier * self.PenMod, 1
	end
}

function GetWeaponAmmoName(Weapon)
    if Weapon.Primary and Weapon.Primary.Ammo then
        return string.lower(Weapon.Primary.Ammo)
    else
        return string.lower(tostring(game.GetAmmoName(Weapon:GetPrimaryAmmoType())))
    end
end

function CWCanPenetrate(Weapon, TraceData)
    if Cache.WeaponData.AutoWall.Cancellers[TraceData.MatType] or (Weapon.CanPenetrate ~= nil and not Weapon.CanPenetrate) then
        return false
    end

    local Entity = TraceData.Entity
    if IsValid(Entity) and (Entity:IsPlayer() or Entity:IsNPC()) then
        return false
    end

    return -TraceData.Normal:Dot(TraceData.HitNormal) > 0.26
end

function GetWeaponPenetrationDistance(Weapon, TraceData)
    local Base = GetWeaponBase(Weapon)

    if AutowallFunction[Base] then
        return AutowallFunction[Base](Weapon, TraceData)
    end

    return nil
end

function WeaponCanPenetrate(Weapon, TraceData, Target, TargetPos)
    local MaxDistance, MaxTimes = GetWeaponPenetrationDistance(Weapon, TraceData)
    if not MaxDistance then return false end

    if not Weapon:IsScripted() then
        return TraceData.Entity == Target
    end

    local TraceOutput = {} -- Create our own here to avoid interference
    local Trace = {
        start = TargetPos,
        endpos = TraceData.HitPos,
        filter = {Target},
        mask = MASK_SHOT,
        output = TraceOutput
    }

    util.TraceLine(Trace)

    local CurTimes = 1
    local LastPos = TraceOutput.HitPos

    local World = game.GetWorld()
    local IsTFA = GetWeaponBase(Weapon) == "tfa"
    if IsTFA then MaxDistance = MaxDistance / 2 end

    while CurTimes <= MaxTimes do
        if TraceOutput.Entity == World then
            local OriginalEndPos = Trace.endpos

            for i = 1, 75 do
                Trace.start = TraceOutput.HitPos - (TraceData.Normal * 10)
                Trace.endpos = Trace.start

                util.TraceLine(Trace)

                if not TraceOutput.HitWorld then break end
            end

            Trace.endpos = OriginalEndPos
        else
            if TraceOutput.Entity == Target then break end

            local Entity = TraceOutput.Entity
            Trace.start = LastPos

            util.TraceLine(Trace)

            Trace.start = TraceOutput.HitPos - TraceData.Normal
            Trace.endpos = LastPos
            Trace.filter[2] = Entity

            util.TraceLine(Trace)
        end

        local CurDistance
        if IsTFA then
            CurDistance = TraceOutput.HitPos:Distance(LastPos) / 88.88
        else
            CurDistance = math.floor(TraceOutput.HitPos:DistToSqr(LastPos))
        end

        if CurDistance > MaxDistance then return false end

        if TraceOutput.Hit then
            LastPos = TraceOutput.HitPos
        else
            local OriginalEndPos = TraceData.HitPos

            Trace.endpos = TraceData.HitPos

            util.TraceLine(Trace)

            Trace.endpos = OriginalEndPos

            if TraceOutput.Hit then
                LastPos = TraceOutput.HitPos
            else
                if IsTFA then
                    CurDistance = TraceOutput.HitPos:Distance(LastPos) / 88.88
                else
                    CurDistance = math.floor(TraceOutput.HitPos:DistToSqr(LastPos))
                end

                if CurDistance <= MaxDistance then
                    break
                end
            end
        end

        CurTimes = CurTimes + 1
    end

    return CurTimes <= MaxTimes, CurTimes
end