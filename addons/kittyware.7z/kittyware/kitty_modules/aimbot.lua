--[[
    rip heads with ease!
]]

KRagebot = {}

KRagebot.m_flShootTicks = 0

function KRagebot:IsViableTarget(pEntity)
    if not IsValid(pEntity) or pEntity == g_pLocalPlayer then return false end

    local DataTable = Cache.EntityData[pEntity] or UpdateEntityInfo(pEntity)
    if not DataTable then return false end

    if DataTable.Dormant or not DataTable.Alive then return false end

    if pEntity:IsPlayer() then
        if Vars.Aimbot.IgnoreFlags.Players then return false end
        if Vars.Aimbot.Friends[pEntity] then return false end
        if Vars.Aimbot.IgnoreFlags.Friends and pEntity:GetFriendStatus() == "friend" then return false end
        
        -- Net stuff
        if Vars.Aimbot.IgnoreFlags.Buildmode and IsInBuildMode(pEntity) then return false end
        if Vars.Aimbot.IgnoreFlags.Protected and IsProtected(pEntity) then return false end
        if Vars.Aimbot.IgnoreFlags.Godmode and IsInGodMode(pEntity) then return false end

        if pEntity:InVehicle() then return false end    
    elseif pEntity:IsNPC() then
        if Vars.Aimbot.IgnoreFlags.NPCs then return false end

        if pEntity:GetClass() == "npc_turret_floor" then return false end
        if pEntity:GetClass() == "npc_furniture" then return false end
    elseif pEntity:IsNextBot() then
        if Vars.Aimbot.IgnoreFlags.NextBots then return false end
    end
    
	return true
end

function KRagebot:IsVisible(vPosition, pEntity)
    local trResult = {}
    local trData = {
        start = g_pLocalPlayer:GetShootPos(),
        endpos = vPosition,
        filter = g_pLocalPLayer,
        mask = MASK_SHOT,

        output = trResult
    }

	util.TraceLine(trData)

	if trResult.Entity == pEntity then
		return true, 0, trResult.Fraction
	elseif Vars.Aimbot.Triggerbot.AutoWall then
		if not IsValid(g_pActiveWeapon) then
			return false, 0, trResult.Fraction
		end

		local Hit, Penetrations = WeaponCanPenetrate(g_pActiveWeapon, trResult, pEntity, vPosition)
		Hit = Hit or false

		return Hit, Penetrations, trResult.Fraction
	else
		return false, 0, trResult.Fraction
	end
end

function KRagebot:GetAimTargets()
    local pTargets = {}

    for _, pEntity in pairs(ents.GetAll()) do
        if not (pEntity:IsPlayer() or pEntity:IsNextBot() or pEntity:IsNPC()) then continue end
        if not self:IsViableTarget(pEntity) then continue end

        pTargets[#pTargets + 1] = pEntity
    end

    table.sort(pTargets, function(a, b)
        return DistanceFromCrosshair(a:WorldSpaceCenter()) > DistanceFromCrosshair(b:WorldSpaceCenter())
    end)    

    return pTargets
end

function KRagebot:GetEntityHitboxes(pEntity)
	local pModelData = GenerateModelData(pEntity:GetModel())
	if not pModelData then 
        return nil
    end

    pEntity:SetAnimTime(GetServerTime())
	pEntity:InvalidateBoneCache()
    pEntity:SetupBones()

    local pHitboxes = {}

    for iHitbox, pHitbox in pairs(pModelData.m_tHitboxes) do 
		if pHitbox.m_iHitGroup ~= Vars.Aimbot.AimAtHitbox then 
            continue 
        end

		local pMatrix = pEntity:GetBoneMatrix(pHitbox.m_iBone)
		if not pMatrix then continue end

		local vTranslation, vAngle = pMatrix:GetTranslation(), pMatrix:GetAngles()

		local vCenter = Vector(pHitbox.m_vCenter)
		vCenter:Rotate(vAngle)

		pHitboxes[#pHitboxes + 1] = vTranslation + vCenter

		if Vars.Aimbot.MultiPoint then 
            for _, vCorner in ipairs(pHitbox.m_tCorners) do
                local vCornerPosition = Vector(vCorner)
                vCornerPosition:Rotate(vAngle)
                vCornerPosition:Add(vTranslation)
                        
                pHitboxes[#pHitboxes + 1] = vCornerPosition
            end
        end
	end

	return pHitboxes
end

local sv_gravity = GetConVar("sv_gravity")
function KRagebot:GetEntityAimPos(pEntity)
    if IsValid(g_pActiveWeapon) and g_pActiveWeapon:GetClass() == "weapon_crossbow" then
        local hitpos = pEntity:WorldSpaceCenter()
        local flTime = g_pLocalPlayer:GetShootPos():Distance(hitpos) / 3500

        flTime = flTime + GetLerpTime()
        flTime = flTime + TickToTime(1)

        flTime = flTime + (g_pLocalPlayer:Ping() / 1000)

        local vel = pEntity:GetAbsVelocity()

        hitpos:Add(vel * flTime)
        hitpos.z = hitpos.z + (sv_gravity:GetFloat() * 0.05 * flTime)

        return hitpos
    end
        
    local tHitboxes = self:GetEntityHitboxes(pEntity)
    if not tHitboxes then return pEntity:WorldSpaceCenter() end -- how the fuck

    for _, vPosition in pairs(tHitboxes) do
        if not vPosition then continue end

        if not InFOV(Position) then continue end
        if not self:IsVisible(vPosition, pEntity) then continue end

        return vPosition
    end

    return nil
end

function KRagebot:PredictPosition(vPosition, pEntity) -- SHIT prediction 
    if not cl_interpolate:GetBool() then return end

	local flVelocity = pEntity:GetAbsVelocity()
	if flVelocity:IsZero() then return end

	local Ping = (g_pLocalPlayer:Ping() / 1000)

	flVelocity:Mul(TICK_INTERVAL * Ping)
	vPosition:Add(flVelocity)
end

function KRagebot:Run(pUserCmd)
    if not Vars.Aimbot.Enabled then 
        return false 
    end

    if not IsValid(g_pActiveWeapon) or not CanShoot() then 
        return false 
    end

    local KeyDown = Vars.Aimbot.Key.Enabled and input.IsButtonDown(Vars.Aimbot.Key.Code) or not Vars.Aimbot.Key.Enabled
    if not KeyDown then
        self.m_flShootTicks = math.huge

        return false 
    end

    for idx, pEntity in pairs(self:GetAimTargets()) do
        if not IsValid(pEntity) then continue end
        
        local vPosition = self:GetEntityAimPos(pEntity)
        if not vPosition then continue end

        self:PredictPosition(vPosition, pEntity)

        local vDirection = (vPosition - g_pLocalPlayer:GetShootPos()):Angle()
        vDirection:Normalize()

        if Vars.Aimbot.Triggerbot.AutoShoot.Enabled then
            if Vars.Aimbot.Triggerbot.AutoShoot.Slow.Enabled then
                if self.m_flShootTicks >= TimeToTick(Vars.Aimbot.Triggerbot.AutoShoot.Slow.Amount) then
                    pUserCmd:AddKey(IN_ATTACK)
                else
                    self.m_flShootTicks = self.m_flShootTicks + 1
                end
            else
                pUserCmd:AddKey(IN_ATTACK)
            end
        end

        if not Vars.Aimbot.Silent then 
            Cache.FacingAngle = Angle(vDirection) 
        end

        pUserCmd:SetViewAngles(vDirection) 
    end
end