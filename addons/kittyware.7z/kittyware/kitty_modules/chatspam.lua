KChatSpam = {}
KChatSpam.m_aChatQueue = {}

KChatSpam.m_szLastMessage = ""
KChatSpam.m_flLastTimeChatted = 0

local spam_list = {
    "meow",
    "nyaaa",
    ":3",
    "do u guys like cookies i luv cookies",
    "cats r like da best",
    "hey guyz how i play game",
    "whas the shoot button",
    "wha wuh",
    "u stupid nigger",
    "son of a bitch i hate niggers", 
    "and u r a nigger",
    "every single jackass i play wit is a stupid nigger",
    "holy fuck lois",
    "what is a word u use for people that annoy u",
    "naggers",
    "black african nigger",
    "literal monkey",
    "take any sharp ass utencil and fukcing kill urself",
    "faggggyyyyyyyy",
    "i dont like niggers",
    "who here is black",
    "porch monkeyyyyyy",
    "kind of a nigger tyke",
    "if u die ur a faggot"
}

function KChatSpam:Say(msg, bTeam)
    if not isstring(msg) then return end
    if #msg == 0 then return end

    if bTeam then
        RunConsoleCommand("say_team", msg)
    else
        RunConsoleCommand("say", msg)
    end

    if self.m_flLastTimeChatted + 0.66 > GetServerTime() then
        self.m_szLastMessage = msg
    end
end

-- supplement queue, de queue, & chat after cool down passes
function KChatSpam:Run()
    if not Vars.Misc.ChatSpam.Enabled then return false end
    if self.m_flLastTimeChatted + 0.66 > GetServerTime() then return false end

    if Vars.Misc.ChatSpam.DisableWhenTyping and self.m_bPlayerTyping then
        self.m_flLastTimeChatted = GetServerTime() + 0.1
        return false
    end

    if #self.m_aChatQueue < 3 then
        repeat
            local v
            repeat v = table.Random(spam_list) until v ~= self.m_aChatQueue[1] and v ~= self.m_szLastMessage
            self:EnqueueMessage(v)
        until #self.m_aChatQueue == 3
    end

    if #self.m_aChatQueue > 0 then
        local strMsg = table.remove(self.m_aChatQueue, math.min(#self.m_aChatQueue, 3))
        self:Say(strMsg)
    end
end

function KChatSpam:EnqueueMessage(strMsg)
    table.insert(self.m_aChatQueue, 1, strMsg)
end

function KChatSpam:StartChat()
    self.m_bPlayerTyping = true
end
function KChatSpam:FinishChat()
    self.m_bPlayerTyping = false
end

function KChatSpam:UpdateCooldown(Data)
    if tonumber(Data.userid) == g_pLocalPlayer:UserID() then
        self.m_flLastTimeChatted = GetServerTime()
    end
end