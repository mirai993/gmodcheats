--[[
    im not over engineering this fuck you, you get shitty nospread
]]

KNoSpread = {}
KNoSpread.m_tEngineSeeds = {}
KNoSpread.m_tEngineSpread = {}

local sv_tfa_recoil_legacy = GetConVar("sv_tfa_recoil_legacy")

KNoSpread.m_tWeaponBaseFunction = {
    ["tfa"] = function(hWeapon, _, WeaponCone, ViewAngle)
        local Cone, Recoil = hWeapon:CalculateConeRecoil()

        local Yaw, Pitch = hWeapon:ComputeBulletDeviation(1, 1, Cone)

        local WeaponAngle = Angle(ViewAngle)
        local BulletAngle = Angle(WeaponAngle)

        if sv_tfa_recoil_legacy:GetBool() then
            WeaponAngle:Add(g_pLocalPlayer:GetViewPunchAngles())
        elseif hWeapon:HasRecoilLUT() then
            WeaponAngle:Add(hWeapon:GetRecoilLUTAngle())
        else
            local PitchPunch = hWeapon:GetViewPunchP()
            local YawPunch = hWeapon:GetViewPunchY()

            PitchPunch = PitchPunch - PitchPunch * TICK_INTERVAL
            YawPunch = YawPunch - YawPunch * TICK_INTERVAL

            WeaponAngle.pitch = WeaponAngle.pitch + PitchPunch
            WeaponAngle.yaw = WeaponAngle.yaw + YawPunch
        end

        WeaponAngle:Normalize()

        local Up = BulletAngle:Up()
        local Right = BulletAngle:Right()

        BulletAngle:RotateAroundAxis(Up, Yaw)
        BulletAngle:RotateAroundAxis(Right, Pitch)

        local Difference = WeaponAngle - BulletAngle

        ViewAngle:Sub(Difference)

        return true
    end,
    ["cw"] = function(hWeapon, pUserCmd, _, ViewAngle)
        local Cone = hWeapon.CurCone

        math.randomseed(pUserCmd:CommandNumber())
        ViewAngle:Add(Angle(-math.Rand(-Cone, Cone), -math.Rand(-Cone, Cone), 0) * 25)

        return true
    end,
    ["bobs"] = function(hWeapon, pUserCmd, WeaponCone)
		if hWeapon:GetNWBool("M9K_Ironsights") or pUserCmd:KeyDown(IN_ATTACK2) then
			WeaponCone.x = hWeapon.Primary.IronAccuracy
			WeaponCone.y = hWeapon.Primary.IronAccuracy
		else
			WeaponCone.x = hWeapon.Primary.Spread
			WeaponCone.y = hWeapon.Primary.Spread
		end

		return false
	end
}

function KNoSpread:CalculateNospread(pUserCmd, hWeapon, ViewAngle)
    local WeaponCone = self.m_tEngineSpread[hWeapon:GetClass()]
    if not WeaponCone then return end

    if type(WeaponCone) == "function" then
        WeaponCone = WeaponCone(hWeapon, pUserCmd)
    end

    local strBase = strBase
    if self.m_tWeaponBaseFunction[strBase] then
        self.m_tWeaponBaseFunction[strBase](hWeapon, pUserCmd, WeaponCone, ViewAngle) 
        if strBase ~= "bobs" then -- p
            return
        end
    end
    
    local Seed = self:PseudoRandom(pUserCmd:CommandNumber())
    
    local X = self.m_tEngineSeeds[Seed].X
    local Y = self.m_tEngineSeeds[Seed].Y
    
    local Forward = ViewAngle:Forward()
    local Right = ViewAngle:Right()
    local Up = ViewAngle:Up()
    
    local CalculatedSpread = Forward + (X * WeaponCone.x * Right * -1) + (Y * WeaponCone.y * Up * -1)
    ViewAngle:Set(CalculatedSpread:Angle())
end

function KNoSpread:CalculateViewPunch(hWeapon)
    if hWeapon:GetClass() == "weapon_pistol" then
        return angle_zero
    end

    if hWeapon:IsScripted() then
        if GetWeaponBase(hWeapon) ~= "cw" and GetWeaponBase(hWeapon) ~= "fas2" then
            return angle_zero
        end
    end

    return g_pLocalPlayer:GetViewPunchAngles()
end
    

function KNoSpread:Run(pUserCmd)
    if not Vars.Aimbot.Nospread then return false end

    if not IsValid(g_pActiveWeapon) then return false end

	if pUserCmd:KeyDown(IN_ATTACK) and CanShoot() then
        local ViewAngles = pUserCmd:GetViewAngles()

        self:CalculateNospread(pUserCmd, g_pActiveWeapon, ViewAngles)
        if Vars.Aimbot.Norecoil then ViewAngles:Sub(self:CalculateViewPunch(g_pActiveWeapon)) end
        
        pUserCmd:SetViewAngles(ViewAngles)
    end
end