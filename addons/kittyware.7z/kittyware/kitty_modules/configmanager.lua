KConfigManager = {}
KConfigManager.CurrConfigName = ""
KConfigManager.CurrConfig = Vars

BASE_DIR = "kittyware"
CONFIG_DIR = BASE_DIR .. "/config"
CONFIG_EXTENSION = ".json"

function KConfigManager:Init()
    if not (file.Exists(BASE_DIR, "DATA") and file.IsDir(BASE_DIR, "DATA")) then
        file.CreateDir(BASE_DIR) 
    end

    if not (file.Exists(CONFIG_DIR, "DATA") and file.IsDir(CONFIG_DIR, "DATA")) then
        file.CreateDir(CONFIG_DIR) 
    end
end

function KConfigManager:Serialize(data)
    return util.TableToJSON(data)
end

function KConfigManager:Deserialize(rawdata)
    local data = util.JSONToTable(rawdata, false)

    return data
end

function KConfigManager:DeleteConfig(name)
    file.Delete(string.format("%s/%s%s", CONFIG_DIR, name, CONFIG_EXTENSION))
end

function KConfigManager:LoadConfig(name)
    if not (isstring(name) and string.Trim(name) ~= "") then return false end

    if not file.Exists(string.format("%s/%s%s", CONFIG_DIR, name, CONFIG_EXTENSION), "DATA") then
        return false 
    end

    local data = self:Deserialize(file.Read(string.format("%s/%s%s", CONFIG_DIR, name, CONFIG_EXTENSION)), "DATA")
    if not data then return false end

    self.CurrConfigName = name
    table.Merge(self.CurrConfig, data)

    return true
end

function KConfigManager:SaveConfig(name, data, bSavingCurrent)
    local rawdata = self:Serialize(data)
    if not rawdata then return false end

    file.Write(string.format("%s/%s%s", CONFIG_DIR, name, CONFIG_EXTENSION), rawdata)

    if not file.Exists(string.format("%s/%s%s", CONFIG_DIR, name, CONFIG_EXTENSION), "DATA") then return false end

    return true
end

function KConfigManager:GetDiskConfigs()
    local tFiles, _ = file.Find(string.format("%s/*%s", CONFIG_DIR, CONFIG_EXTENSION), "DATA")

    return tFiles
end

function KConfigManager:GetAutoloadName()
    local strAutoloadFileName = string.format("%s/autoload.txt", CONFIG_DIR)

    if file.Exists(strAutoloadFileName, "DATA") and not file.IsDir(strAutoloadFileName, "DATA") then
        return file.Read(strAutoloadFileName, "DATA")
    end
end

function RefreshConfigList()
	Cache.Panels.ConfigList:Clear()

	local cfgs = KConfigManager:GetDiskConfigs()
	local strAutoLoadName = KConfigManager:GetAutoloadName()

	for _, strConfigFilename in ipairs(cfgs) do
		local strConfigName = string.StripExtension(strConfigFilename)
		local iFileTime = file.Time(string.format("%s/%s", CONFIG_DIR, strConfigFilename), "DATA")
		local bIsAutoload = strAutoLoadName == strConfigName

		local line = Cache.Panels.ConfigList:AddLine(bIsAutoload and "Yes" or "", strConfigName, os.date("%m/%d/%Y %H:%M %p", iFileTime))
		line.m_strConfigName = strConfigName
		line.m_bIsAutoload = bIsAutoload
		line.m_bIsLoaded = strConfigName == KConfigManager.CurrConfigName
	end
end

function KConfigManager:MarkAsAutoload(name)
    if not (isstring(name) and string.Trim(name) ~= "") then return false end

    file.Write(string.format("%s/autoload.txt", CONFIG_DIR), string.Trim(name))

    return true
end

function KConfigManager:LoadAutoload()
    self:LoadConfig(self:GetAutoloadName())
end

KConfigManager:Init()

timer.Simple(0, function()
    KConfigManager:LoadAutoload()
end)