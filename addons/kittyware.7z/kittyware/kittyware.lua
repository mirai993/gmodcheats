/*
    kitty ware
*/

pcall(require, "frozen2")

local Data = {
	Environment = {
		_G = _G or getfenv(1),
		_R = debug.getregistry(),

		net = net,

		Vars = {
            Aimbot = {
                Enabled = false,
                Silent = false,

                Key = {
                    Enabled = false,
                    Code = KEY_NONE
                },

                AimCone = {
                    Enabled = false,
                    FOV = 0,
					Color = nil
                },
                
				AimAtHitbox = HITGROUP_HEAD,

                Nospread = false,
                Norecoil = false,

                Resolver = false,

                MultiPoint = false,
				pSilent = false,

                Triggerbot = {
                    Enabled = false,
                    OnCrosshair = false,
                    AutoWall = false,

                    AutoShoot = {
                        Enabled = false,
        
                        Slow = {
                            Enabled = false,
                            Amount = 0
                        }
                    }
                },

                IgnoreFlags = {
					Players = false,
					NextBots = false,
					NPCs = false,
                    Friends = false,
                    Buildmode = false,
                    Godmode = false,
                    Protected = false
                },

                Friends = {}
            },

            AntiAim = {
                Enabled = false,

                PitchMethod = 1,
                YawMethod = 1,

                CustomAngles = {
                    Pitch = 0,
                    
                    RealYaw = 0,
                    FakeYaw = 0
                },

                FollowTarget = false,

                SpinSpeed = 0,

                LbyBreaker = {
                    Enabled = false,
                    Delta = 0
                }
            },

            FakeLag = {
                Enabled = false,
                Choke = 0,
                Method = 1
            },

            Visuals = {
                ESP2D = {
                    Enabled = false,

					Color = nil,

                    Box = false,
					BoxFill = false,
                    Name = false,
                    Weapon = false,
                    Skeleton = false,
                    Flags = false,
                    UserGroup = false,
                    Avatar = false,
                    
                    Bones = {
                        Enabled = false,
                        Lines = false,
                        Points = false
                    },
                    
                    Health = {
                        Enabled = false,
                            
                        Bar = false,
                        Amount = false
                    },
                },

				ESP3D = {
					Enabled = false, 

					Hitboxes = {
						Enabled = false,
						BoundingBox = false,
	
						Color = nil,
						BoundingColor = nil
					},
	
					Chams = {
						Enabled = false,
	
						Visible = {
							Enabled = false,
							Color = nil,
							Material = "Off"
						},
	
						Occluded = {
							Enabled = false,
							Color = nil,
							Material = "Off"
						}
					}
				},

				AntiAimChams = {
					Enabled = false,
					
					Fake = {
						Color = nil,
						Material = "glow"
					},

					Real = {
						Color = nil,
						Material = "glow"
					}
				}
            },

            Misc = {
                Movement = {
                    BunnyHop = false,
                    AutoStrafe = {
                        Enabled = false,
                        Method = 1  
                    }
                },

				Thirdperson = {
					Enabled = false,
					Distance = 0
				},

				ChatSpam = {
					Enabled = false,
					DisableWhenTyping = false
				}
            }
		},

		Cache = {
			FacingAngle = nil,

			FakeAngle = nil,
			RealAngle = nil,

            Menu = nil,
            Panels = {},

            AimbotData = {
				SlowShootTicks = 0
			},

            Players = {},

            EntityData = {},
			ModelData = {},
            CalcViewData = {},

            WeaponNames = {},

			LastCacheUpdate = 0,
			PlayerList = {},

			HitgroupLookups = {
				[HITGROUP_GENERIC] = "Generic",
				[HITGROUP_HEAD] = "Head",
				[HITGROUP_CHEST] = "Chest",
				[HITGROUP_STOMACH] = "Stomach",
				[HITGROUP_LEFTARM] = "Left Arm",
				[HITGROUP_RIGHTARM] = "Right Arm",
				[HITGROUP_LEFTLEG] = "Left Leg",
				[HITGROUP_RIGHTLEG] = "Right Leg"
			},

			ScreenData = {
				Width = 0,
				Height = 0,

				Center = {
					X = 0,
					Y = 0
				}
			},

			NetMessages = {
				Buildmode = { "BuildMode", "buildmode", "_Kyle_Buildmode" },
				God = { "has_god", "god_mode", "ugod" },
				HVH = { "HVHER" },
				Protected = { "LibbyProtectedSpawn", "SH_SZ.Safe", "spawn_protect", "InSpawnZone" }
			},

			WeaponData = {
				AutoWall = {
					Limits = {
						["357"] = {144, 4},
						ar2 = {256, 8},
						buckshot = {25, 1},
						pistol = {81, 2},
						smg1 = {196, 5},
						sniperpenetratedround = {400, 12},
						sniperround = {400, 12} -- SWB
					},

					Multipliers = {
						[MAT_SAND] = 0.5,
						[MAT_DIRT] = 0.8,
						[MAT_METAL] = 1.1,
						[MAT_TILE] = 0.9,
						[MAT_WOOD] = 1.2
					},

					Cancellers = {
						[MAT_SLOSH] = true
					}
				}
			},
		},

		g_pLocalPlayer = NULL,
		g_pActiveWeapon = nil,
		g_bSendPacket = true,

		g_tLocalHooks = {},

		TICK_INTERVAL = 0,

		color_white = nil,
		color_black = nil,
		color_red = nil,
		color_blue = nil,
		color_green = nil,
		color_orange = nil,
		color_gray = nil,
		color_pink = nil,
		color_crimson = nil,
		color_lavender = nil,
		color_purple = nil,
		color_teal = nil,
		color_seafoam = nil,

        StartPrediction = StartPrediction,
        EndPrediction = EndPrediction,

        GetSendPacket = GetSendPacket
	}
}

do
	local ENV = Data.Environment

	ENV.rawget = rawget(ENV._G, "rawget")
	ENV.getfenv = ENV.rawget(ENV._G, "getfenv")
	ENV.setfenv = ENV.rawget(ENV._G, "setfenv")
	ENV.type = ENV.rawget(ENV._G, "type")

	ENV.table = {
		Copy = ENV.rawget(ENV._G.table, "Copy")
	}

	function ENV.RegisterFunction(Function)
		return ENV.setfenv(Function, ENV)
	end

	function ENV.CreateFunction(Name, Function)
		ENV[Name] = ENV.RegisterFunction(Function)
	end

	ENV.CreateFunction("Localize", function(...)
		local Parameters = {...}
		local Found = false
		local Last = "_"
		local Cur = _G
		local LastTable = ENV
		local CurTable = ENV

		for i = 1, #Parameters do
			local v = Parameters[i]

			Last = Cur
			Cur = Cur[v]

			if type(Cur) == "table" then
				CurTable[v] = rawget(CurTable, v) or {}

				LastTable = CurTable
				CurTable = CurTable[v]
				Last = v
			else
				CurTable[v] = Cur
				Found = true

				break
			end
		end

		if not Found then
			LastTable[Last] = table.Copy(Cur)
		end
	end)

	--------------------------- Localization ---------------------------

	-- Enums
	ENV.Localize("FILL")
	ENV.Localize("NODOCK")
	ENV.Localize("MOUSE_RIGHT")
	ENV.Localize("HITGROUP_CHEST")
	ENV.Localize("HITGROUP_HEAD")
	ENV.Localize("HITGROUP_STOMACH")
	ENV.Localize("BONE_USED_BY_HITBOX")
	ENV.Localize("MOVETYPE_WALK")
	ENV.Localize("MOVETYPE_NOCLIP")
	ENV.Localize("FL_ONGROUND")
	ENV.Localize("IN_ATTACK")
	ENV.Localize("IN_ATTACK2")
	ENV.Localize("IN_RELOAD")
	ENV.Localize("IN_SPEED")
	ENV.Localize("IN_ZOOM")
	ENV.Localize("IN_JUMP")
	ENV.Localize("IN_DUCK")
    ENV.Localize("IN_USE")
	ENV.Localize("MASK_SHOT")
	ENV.Localize("EF_NODRAW")
	ENV.Localize("OBS_MODE_NONE")
	ENV.Localize("TEAM_SPECTATOR")
	ENV.Localize("RENDERMODE_TRANSALPHA")
	ENV.Localize("RENDERMODE_NORMAL")
	ENV.Localize("GESTURE_SLOT_VCD")
	ENV.Localize("GESTURE_SLOT_CUSTOM")
	ENV.Localize("KEY_R")

	ENV.Localize("angle_zero")
	ENV.Localize("vector_origin")

	-- Functions
	ENV.Localize("setmetatable")
	ENV.Localize("assert")
	ENV.Localize("pairs")
	ENV.Localize("DermaMenu")
	ENV.Localize("Derma_StringRequest")
	ENV.Localize("ipairs")
	ENV.Localize("SortedPairs")
	ENV.Localize("print")
	ENV.Localize("PrintTable")
	ENV.Localize("error")
	ENV.Localize("rawset")
	ENV.Localize("CompileString")
	ENV.Localize("Entity")
	ENV.Localize("Angle")
	ENV.Localize("Color")
	ENV.Localize("ColorAlpha")
	ENV.Localize("HSVToColor")
	ENV.Localize("CurTime")
	ENV.Localize("IsFirstTimePredicted")
	ENV.Localize("IsValid")
	ENV.Localize("LocalPlayer")
	ENV.Localize("EyeVector")
	ENV.Localize("MsgC")
	ENV.Localize("MsgN")
	ENV.Localize("Player")
	ENV.Localize("RealFrameTime")
	ENV.Localize("RunConsoleCommand")
	ENV.Localize("ScrH")
	ENV.Localize("ScrW")
	ENV.Localize("SysTime")
	ENV.Localize("Vector")
	ENV.Localize("collectgarbage")
	ENV.Localize("next")
	ENV.Localize("tobool")
	ENV.Localize("istable")
	ENV.Localize("tonumber")
	ENV.Localize("tostring")
	ENV.Localize("isvector")
	ENV.Localize("isnumber")
	ENV.Localize("isentity")
	ENV.Localize("isfunction")
	ENV.Localize("isbool")
	ENV.Localize("isstring")
	ENV.Localize("type")
	ENV.Localize("unpack")
	ENV.Localize("FrameNumber")
	ENV.Localize("Material")
	ENV.Localize("CreateMaterial")
	ENV.Localize("getinfo")
	ENV.Localize("getupvalue")
	ENV.Localize("getupvalues")
	ENV.Localize("GetConVar")
    ENV.Localize("LerpVector")

	-- Libraries
    ENV.Localize("bit", "band")
	ENV.Localize("bit", "bor")
	ENV.Localize("bit", "bxor")
	ENV.Localize("bit", "lshift")
	ENV.Localize("bit", "rshift")
    ENV.Localize("cam", "Start2D")
    ENV.Localize("cam", "End2D")
	ENV.Localize("cam", "Start3D")
    ENV.Localize("cam", "End3D")
	ENV.Localize("concommand", "Add")
    ENV.Localize("concommand", "Remove")
	ENV.Localize("debug", "setmetatable")
	ENV.Localize("debugoverlay", "Box")
	ENV.Localize("draw", "NoTexture")
	ENV.Localize("ents", "GetAll")
	ENV.Localize("engine", "TickInterval")
	ENV.Localize("file", "Open")
	ENV.Localize("file", "Delete")
	ENV.Localize("file", "Write")
	ENV.Localize("file", "Find")
	ENV.Localize("file", "Time")
    ENV.Localize("file", "Exists")
    ENV.Localize("file", "IsDir")
    ENV.Localize("file", "Read")
	ENV.Localize("file", "CreateDir")
	ENV.Localize("game", "GetAmmoName")
	ENV.Localize("game", "GetWorld")
	ENV.Localize("gameevent", "Listen")
    ENV.Localize("halo", "Add")
	ENV.Localize("hook", "Add")
	ENV.Localize("hook", "Run")
    ENV.Localize("hook", "Remove")
	ENV.Localize("hook", "GetTable")
	ENV.Localize("input", "IsButtonDown")
    ENV.Localize("language", "GetPhrase")
    ENV.Localize("math", "ceil")
	ENV.Localize("math", "Clamp")
	ENV.Localize("math", "Distance")
	ENV.Localize("math", "NormalizeAngle")
	ENV.Localize("math", "Rand")
	ENV.Localize("math", "Round")
	ENV.Localize("math", "Truncate")
	ENV.Localize("math", "abs")
	ENV.Localize("math", "acos")
	ENV.Localize("math", "atan")
    ENV.Localize("math", "atan2")
	ENV.Localize("math", "cos")
	ENV.Localize("math", "deg")
	ENV.Localize("math", "floor")
    ENV.Localize("math", "fmod")
	ENV.Localize("math", "huge")
	ENV.Localize("math", "max")
	ENV.Localize("math", "min")
	ENV.Localize("math", "pi")
	ENV.Localize("math", "pow")
	ENV.Localize("math", "rad")
    ENV.Localize("math", "random")
	ENV.Localize("math", "randomseed")
	ENV.Localize("math", "sin")
	ENV.Localize("math", "sqrt")
	ENV.Localize("math", "tan")
    ENV.Localize("math", "AngleDifference")
	ENV.Localize("net", "Start")
	ENV.Localize("net", "WriteEntity")
	ENV.Localize("net", "WriteUInt")
	ENV.Localize("net", "WriteFloat")
	ENV.Localize("net", "WriteString")
	ENV.Localize("net", "ReadString")
	ENV.Localize("net", "WriteBit")
	ENV.Localize("net", "Receive")
	ENV.Localize("net", "SendToServer")
	ENV.Localize("os", "date")
	ENV.Localize("player", "GetAll")
	ENV.Localize("render", "GetBlend")
	ENV.Localize("render", "GetViewSetup")
	ENV.Localize("render", "SetMaterial")
	ENV.Localize("render", "DrawBeam")
	ENV.Localize("render", "SetColorModulation")
	ENV.Localize("render", "MaterialOverride")
	ENV.Localize("render", "SetBlend")
	ENV.Localize("render", "SuppressEngineLighting")
	ENV.Localize("render", "DrawWireframeBox")
	ENV.Localize("render", "SetMaterial")
    ENV.Localize("string", "char")
	ENV.Localize("string", "Split")
	ENV.Localize("string", "ToColor")
	ENV.Localize("string", "Trim")
	ENV.Localize("string", "find")
	ENV.Localize("string", "format")
	ENV.Localize("string", "lower")
	ENV.Localize("string", "sub")
	ENV.Localize("string", "StripExtension")
    ENV.Localize("surface", "CreateFont")
	ENV.Localize("surface", "DrawCircle")
	ENV.Localize("surface", "DrawLine")
	ENV.Localize("surface", "DrawOutlinedRect")
	ENV.Localize("surface", "DrawPoly")
	ENV.Localize("surface", "DrawRect")
	ENV.Localize("surface", "GetTextSize")
	ENV.Localize("surface", "GetTextureID")
	ENV.Localize("surface", "SetAlphaMultiplier")
	ENV.Localize("surface", "SetDrawColor")
	ENV.Localize("surface", "SetTexture")
    ENV.Localize("surface", "SetFont")
    ENV.Localize("surface", "SetTextColor")
    ENV.Localize("surface", "SetTextPos")
    ENV.Localize("surface", "DrawText")
	ENV.Localize("table", "Empty")
	ENV.Localize("table", "IsEmpty")
	ENV.Localize("table", "insert")
	ENV.Localize("table", "remove")
	ENV.Localize("table", "Random")
    ENV.Localize("table", "sort")
	ENV.Localize("table", "Merge")
    ENV.Localize("timer", "Create")
	ENV.Localize("timer", "Simple")
    ENV.Localize("timer", "Remove")
	ENV.Localize("util", "Base64Encode")
	ENV.Localize("util", "Compress")
	ENV.Localize("util", "TraceLine")
	ENV.Localize("util", "TraceHull")
	ENV.Localize("util", "JSONToTable")
	ENV.Localize("util", "TableToJSON")
    ENV.Localize("gui", "EnableScreenClicker")
	ENV.Localize("vgui", "Create")
    ENV.Localize("vgui", "GetWorldPanel")
    ENV.Localize("vgui", "Register")

	-- Stupid shit
	ENV.NULL = ENV.rawget(_G, "NULL")
	ENV.angle_zero = ENV.Angle(0, 0, 0)

	ENV.CustomizableWeaponry = ENV.rawget(ENV._G, "CustomizableWeaponry")
	ENV.CW_AIMING = ENV.rawget(ENV._G, "CW_AIMING")
	ENV.FAS_STAT_CUSTOMIZE = ENV.rawget(ENV._G, "FAS_STAT_CUSTOMIZE")
	ENV.FAS_STAT_SPRINT = ENV.rawget(ENV._G, "FAS_STAT_SPRINT")
	ENV.FAS_STAT_QUICKGRENADE = ENV.rawget(ENV._G, "FAS_STAT_QUICKGRENADE")
	ENV.TFA = ENV.rawget(ENV._G, "TFA")
	ENV.ArcCW = ENV.rawget(ENV._G, "ArcCW")
	
    ENV.g_pLocalPlayer = ENV.LocalPlayer()
    ENV.g_bSendPacket = true
	ENV.TICK_INTERVAL = ENV.engine.TickInterval()

	local Cache = ENV.Cache
	local Vars = ENV.Vars

    -- Screen
	Cache.ScreenData.ScrW = ENV.ScrW()
	Cache.ScreenData.ScrH = ENV.ScrH()

	Cache.ScreenData.Center.X = ENV.math.floor(Cache.ScreenData.ScrW / 2)
	Cache.ScreenData.Center.Y = ENV.math.floor(Cache.ScreenData.ScrH / 2)

    -- Colors
	ENV.color_white = ENV.Color(255, 255, 255)
	ENV.color_black = ENV.Color(0, 0, 0)
	ENV.color_red = ENV.Color(255, 0, 0)
	ENV.color_blue = ENV.Color(0, 0, 255)
	ENV.color_green = ENV.Color(0, 255, 0)
	ENV.color_orange = ENV.Color(255, 150, 0)
	ENV.color_gray = ENV.Color(175, 175, 175)
	ENV.color_pink = ENV.Color(255, 0, 200)
	ENV.color_crimson = ENV.Color(175, 0, 42)
	ENV.color_lavender = ENV.Color(165, 125, 255)
	ENV.color_purple = ENV.Color(125, 0, 255)
	ENV.color_teal = ENV.Color(0, 180, 180)
	ENV.color_seafoam = ENV.Color(201, 255, 229)

	Vars.Aimbot.AimCone.Color = ENV.Color(255, 255, 255, 255)
	Vars.Visuals.ESP2D.Color = ENV.Color(255, 0, 0, 255)
	Vars.Visuals.ESP3D.Hitboxes.Color = ENV.Color(255, 255, 255, 255)
	Vars.Visuals.ESP3D.Hitboxes.BoundingColor = ENV.Color(255, 255, 255, 255)
	Vars.Visuals.ESP3D.Chams.Visible.Color = ENV.Color(255, 0, 0, 255)
	Vars.Visuals.ESP3D.Chams.Occluded.Color = ENV.Color(0, 255, 255, 255)
	Vars.Visuals.AntiAimChams.Fake.Color = ENV.Color(255, 0, 0, 255)
	Vars.Visuals.AntiAimChams.Real.Color = ENV.Color(255, 255, 255, 255)
	
	Cache.FacingAngle = ENV.g_pLocalPlayer:EyeAngles()
	Cache.FakeAngle = ENV.g_pLocalPlayer:EyeAngles()
	Cache.RealAngle = ENV.g_pLocalPlayer:EyeAngles()

	Cache.CalcViewData.Origin = ENV.g_pLocalPlayer:EyePos()
	Cache.CalcViewData.Angles = ENV.g_pLocalPlayer:EyeAngles()
	Cache.CalcViewData.FOV = ENV.g_pLocalPlayer:GetFOV()
	Cache.CalcViewData.ZNear = 3

    ENV.CreateFunction("Log", function(strMessage, ...)
		MsgC(color_gray, "[", color_lavender, "KittyWare", color_gray, "] ", color_seafoam, string.format(strMessage, ...))
		MsgN()
	end)

    ENV.CreateFunction("LoadModules", function(Directory)
		if not file.Exists(Directory, "MOD") and not file.IsDir(Directory, "MOD") then return end
		
		local files = file.Find(string.format("%s/*", Directory), "MOD")
		
		for _, v in next, files do
			local code = file.Read(string.format("%s/%s", Directory, v), "MOD")	

			local ModulesCode = CompileString(code)
			ENV.setfenv(ModulesCode, ENV)
			ModulesCode()
			
			Log("Loaded '%s'", v)
		end
	end)

    ENV.CreateFunction("AddHook", function(Event, Function)
		local Name = tostring({})

		g_tLocalHooks[#g_tLocalHooks + 1] = {Event, Name}

		hook.Add(Event, Name, ENV.RegisterFunction(Function))

		Log("Hooking [{%s} {%s}]", Event, Name)
	end)

    ENV.CreateFunction("AddConCommand", function(Name, Function)
		Log("Adding Command '%s'", Name)
        
		concommand.Add(Name, ENV.RegisterFunction(Function))
	end)

    ENV.LoadModules("lua/kitty_modules")
end

do
	local AddHook = Data.Environment.AddHook
    local AddConCommand = Data.Environment.AddConCommand

    Data.Environment.gameevent.Listen("player_connect_client")
	AddHook("player_connect_client", function()
		if IsValid(Cache.Panels.PlayerList) then
            Cache.Panels.PlayerList:CacheUpdate()
        end
	end)

	Data.Environment.gameevent.Listen("player_disconnect")
	AddHook("player_disconnect", function()
		if IsValid(Cache.Panels.PlayerList) then
            Cache.Panels.PlayerList:CacheUpdate()
        end
	end)

	Data.Environment.gameevent.Listen("player_say")
	AddHook("player_say", function(pData)
		KChatSpam:UpdateCooldown(pData)
	end)

    AddHook("Tick", function()
        local CurTime = SysTime()
        if CurTime - Cache.LastCacheUpdate >= 0.3 then
            table.Empty(Cache.Players)

			for idx, pPlayer in pairs(ents.GetAll()) do
				if not pPlayer:IsPlayer() then continue end

				Cache.Players[#Cache.Players + 1] = pPlayer
			end

            -- clear invalid data
            local InValid = {}
			for k, _ in pairs(Cache.EntityData) do
				if not k:IsValid() then
					InValid[#InValid + 1] = k
				end
			end

			for i = #InValid, 1, -1 do
				Cache.EntityData[InValid[i]] = nil
			end
			
			InValid = nil

            Cache.LastCacheUpdate = CurTime
        end

		for idx, pPlayer in pairs(Cache.Players) do
			if not pPlayer:IsValid() then continue end
			UpdatePlayerInfo(pPlayer)
		end

		KChatSpam:Run()
    end)

    AddHook("EntityFireBullets", function(pEntity, pData)
        if pEntity ~= g_pLocalPlayer then return end
		if not IsFirstTimePredicted() then return end
        if not IsValid(g_pActiveWeapon) then return end

		KRagebot.m_flShootTicks = 0
    
        if isvector(pData.Spread) and not pData.Spread:IsZero() then
            KNoSpread.m_tEngineSpread[g_pActiveWeapon:GetClass()] = pData.Spread
        end
    end)

	AddHook("ShouldDrawLocalPlayer", function(Player)
		if Vars.Misc.Thirdperson.Enabled and Vars.Misc.Thirdperson.Distance > 0 then
			return true
		end
	
		return g_pLocalPlayer:ShouldDrawLocalPlayer()
	end)

    AddHook("CalcView", function(Player, Origin, Angles, FOV, ZNear, ZFar)
		if Vars.Misc.Thirdperson.Enabled then
			local trResult = {}
			util.TraceHull({
                start = Origin,
                endpos = Origin - Cache.FacingAngle:Forward() * Vars.Misc.Thirdperson.Distance,
                mask = MASK_SOLID,
                mins = -cam_size,
                maxs = cam_size,
                filter = {g_pLocalPlayer},
                output = trResult,
            })

            Origin:Set(trResult.HitPos)
		end

		Angles:Set(Cache.FacingAngle)

		if not Vars.Aimbot.Enabled or not Vars.Aimbot.Norecoil then
			Angles:Add(Player:GetViewPunchAngles())
		end

		if not Cache.CalcViewData.Origin then
			Cache.CalcViewData.Origin = Vector(Origin)
		else
			Cache.CalcViewData.Origin:Set(Origin)
		end

		if not Cache.CalcViewData.Angles then
			Cache.CalcViewData.Angles = Angle(Angles)
		else
			Cache.CalcViewData.Angles:Set(Angles)
		end

		Cache.CalcViewData.FOV = FOV
		Cache.CalcViewData.ZNear = ZNear
		Cache.CalcViewData.ZFar = ZFar
	end)

    AddHook("InputMouseApply", function(pUserCmd, MouseX, MouseY)
		if not Vars.Aimbot.Enabled or g_pLocalPlayer:IsFrozen() then return end
		
		local Weapon = g_pLocalPlayer:GetActiveWeapon()

		if IsValid(Weapon) then
			if Weapon.FreezeMovement and Weapon:FreezeMovement() then return end
			if Weapon:GetClass() == "weapon_physgun" and IsValid(Weapon:GetInternalVariable("m_hGrabbedEntity")) and (pUserCmd:KeyDown(IN_USE) or g_pLocalPlayer:KeyDown(IN_USE)) then return end -- Physgun rotating (CUserCmd:KeyDown is jank in this hook)
		end

		Cache.FacingAngle.pitch = Cache.FacingAngle.pitch + (MouseY * m_pitch:GetFloat())
		Cache.FacingAngle.yaw = Cache.FacingAngle.yaw - (MouseX * m_yaw:GetFloat())

		FixAngle(Cache.FacingAngle)
	end)

    AddHook("CreateMove", function(pUserCmd)
		g_bSendPacket = true
		
		if not Vars.Aimbot.Enabled then
			Cache.FacingAngle = pUserCmd:GetViewAngles()
		end

		if Vars.Aimbot.Silent then pUserCmd:SetViewAngles(Cache.FacingAngle) end

        if not g_pLocalPlayer:Alive() or pUserCmd:CommandNumber() == 0 then return end -- idiot
		
        if pUserCmd:TickCount() ~= 0 then
            KAntiAim:FakeLag(pUserCmd)
        end

		KMovement:Run(pUserCmd)

        StartPrediction(pUserCmd)
            KRagebot:Run(pUserCmd)
            KNoSpread:Run(pUserCmd)
			KTriggerBot:Run(pUserCmd)
            KAntiAim:Run(pUserCmd)
        EndPrediction()

		FixMovement(pUserCmd)

		if g_bSendPacket then
			Cache.FakeAngle.p = math.NormalizeAngle(pUserCmd:GetViewAngles().p)
			Cache.FakeAngle.y = math.NormalizeAngle(pUserCmd:GetViewAngles().y)
		end

		Cache.RealAngle.p = math.NormalizeAngle(pUserCmd:GetViewAngles().p)
		Cache.RealAngle.y = math.NormalizeAngle(pUserCmd:GetViewAngles().y)

        --GetSendPacket(g_bSendPacket)
    end)
	
    AddHook("PostDrawHUD", function()
		cam.Start2D()
			local EntitiesThisFrame = {} 

			if Vars.Visuals.ESP2D.Enabled then
				for _, v in ipairs(Cache.Players) do
					if not IsValid(v) then continue end

					local PlayerTable = Cache.EntityData[v] or UpdatePlayerInfo(v)
					if not PlayerTable or not PlayerTable.ShouldRender then continue end
					if not OnScreen(v) then continue end

					EntitiesThisFrame[#EntitiesThisFrame + 1] = { 
						v, 
						Vars.Visuals.ESP2D 
					}
				end
			end

			table.sort(EntitiesThisFrame, function(A, B)
				return A[1]:GetPos():DistToSqr(g_pLocalPlayer:EyePos()) > B[1]:GetPos():DistToSqr(g_pLocalPlayer:EyePos())
			end)
			
			for i = 1, #EntitiesThisFrame do
                KVisuals:Run2D(EntitiesThisFrame[i][1], EntitiesThisFrame[i][2])
			end
		cam.End2D()

        if Vars.Aimbot.AimCone.Enabled then
            surface.DrawCircle(Cache.ScreenData.Center.X, Cache.ScreenData.Center.Y,  GetFOVRadius(), Vars.Aimbot.AimCone.Color) 
        end
    end)

	AddHook("PreDrawEffects", function()
		local Blend = render.GetBlend()

		if Vars.Visuals.ESP3D.Enabled then
			for _, v in ipairs(Cache.Players) do
				if not IsValid(v) then continue end

				local PlayerTable = Cache.EntityData[v] or UpdatePlayerInfo(v)
				if not PlayerTable or not PlayerTable.ShouldRender then continue end
				if not OnScreen(v) then continue end

				KVisuals:Run3D(v, Vars.Visuals.ESP3D)
			end
		end

		KVisuals:DrawAntiAimChams()

		render.SetBlend(Blend)
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(nil)
	end)

    AddHook("PrePlayerDraw", function(Player)
        if not Vars.Aimbot.Resolver then return end 
        if Player == g_pLocalPlayer then return end

        local resolvedpitch = 0
        local resolvedyaw = 0
            
        resolvedyaw = resolvedyaw or 0
        resolvedyaw = resolvedyaw + 1
            
        resolvedyaw = math.NormalizeAngle(CurTime() * 1500)
            
        if 45 >= resolvedyaw then
            resolvedpitch = 89
        elseif resolvedyaw > 45 and 90 > resolvedyaw then
            resolvedpitch = -89
        end
        
        Player:SetPoseParameter("aim_pitch", resolvedpitch)
        Player:SetPoseParameter("head_pitch", resolvedpitch)

        Player:SetPoseParameter("body_yaw", 0)
        Player:SetPoseParameter("aim_yaw", 0)
            
        Player:InvalidateBoneCache()
        Player:SetRenderAngles(Angle(0, resolvedyaw, 0))
        Player:SetupBones()
    end)

	AddHook("StartChat", function()
		KChatSpam:StartChat()
	end)

	AddHook("FinishChat", function()
		KChatSpam:FinishChat()
	end)

    AddHook("OnScreenSizeChanged", function()
        Cache.ScreenData.Width = ScrW()
        Cache.ScreenData.Height = ScrH()
    
        Cache.ScreenData.Center.X = math.floor(Cache.ScreenData.Width / 2)
        Cache.ScreenData.Center.Y = math.floor(Cache.ScreenData.Height / 2)
    end)

	--[[
		commands
	]]

    AddConCommand("kw_menu", function()
        ToggleMenu()
    end)

    AddConCommand("kw_unload", function()
		for _, pHook in pairs(g_tLocalHooks) do
			local strEvent = pHook[1]
			local strName = pHook[2]

			hook.Remove(strEvent, strName)

			if not hook.GetTable()[strEvent][strName] then
				Log("Unhooking [{%s} {%s}]", strEvent, strName)
			end
		end

        timer.Remove(fgui.TimerName)
		
		Cache.Menu:Remove()

		concommand.Remove("kw_menu")
		concommand.Remove("kw_unload")

		local CollectGarbage = collectgarbage
		table.Empty(Data.Environment)
		Data.Environment = nil
		CollectGarbage("collect")
	end)

    Data.Environment.ToggleMenu()
end