function Playermenu()

DermaPanel1 = vgui.Create( "DFrame" )
DermaPanel1:SetPos( 50,25 )
DermaPanel1:SetSize( 300, 450 )
DermaPanel1:SetTitle( "GMOD MP3 Player" )
DermaPanel1:SetVisible( true )
DermaPanel1:SetDraggable( true )
DermaPanel1:ShowCloseButton( true )
DermaPanel1:MakePopup()

local DermaListView = vgui.Create("DListView")  
DermaListView:SetParent(DermaPanel1)  
DermaListView:SetPos(12.5, 37.5)  
DermaListView:SetSize(275, 362.5)  
DermaListView:SetMultiSelect(false)  
DermaListView:AddColumn("Name") // Add column     

local list = file.Find("../sound/songs/*.mp3")  
for k,v in pairs(list) do
DermaListView:AddLine(v)
end

local name
function DermaListView:OnRowSelected( LineID, Line )  
   name = Line:GetColumnText( 1 )
end

local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
DermaButton:SetText( ">play>" )  
DermaButton:SetPos( 12.5, 412.5 )  
DermaButton:SetSize( 100, 25 )  
DermaButton.DoClick = function()
surface.PlaySound( "ui/buttonclick.wav" )
RunConsoleCommand( "play", "songs/"..name )
end

local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
DermaButton:SetText( "Stop" )  
DermaButton:SetPos( 187.5, 412.5 )  
DermaButton:SetSize( 100, 25 )  
DermaButton.DoClick = function()
surface.PlaySound( "ui/buttonclick.wav" )
RunConsoleCommand( "stopsounds" )
end

end

function Hidemenu()

if DermaPanel1:IsVisible() == true then
DermaPanel1:SetVisible(false)
end

end

concommand.Add("mp3", Playermenu)
concommand.Add("+mp3", Playermenu)
concommand.Add("-mp3", Hidemenu)