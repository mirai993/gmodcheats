/*
VGUI/minixhair
PrintTable(ents.GetAll())
*/
if not CLIENT then return end

local centerdist = 16
local decimals = 2

local function drawents()
	local entstable = entstable or ents.GetAll()
	local drawinginfo = 0 
	for num, ent in pairs(entstable) do
		local poss = ent:GetPos()
		if ( (LocalPlayer():GetPos()+Vector(0,0,64)):Distance(poss) > 32 ) and
		poss:ToScreen().x > 0 and  -- Don't waste processor power on drawing things we can't see.
		poss:ToScreen().y > 0 and
		poss:ToScreen().x < ScrW() and
		poss:ToScreen().y < ScrH() then
			local pos = {}
			pos.s, pos.e = (ent:LocalToWorld( Vector(20,0,0)) ):ToScreen(), (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
			surface.SetDrawColor( 255, 0, 0, 255 ); surface.DrawLine( pos.s.x, pos.s.y, pos.e.x, pos.e.y )
			pos.s, pos.e = (ent:LocalToWorld( Vector(0,20,0)) ):ToScreen(), (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
			surface.SetDrawColor( 0, 255, 0, 255 ); surface.DrawLine( pos.s.x, pos.s.y, pos.e.x, pos.e.y )
			pos.s, pos.e = (ent:LocalToWorld( Vector(0,0,20)) ):ToScreen(), (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
			surface.SetDrawColor( 0, 0, 255, 255 ); surface.DrawLine( pos.s.x, pos.s.y, pos.e.x, pos.e.y )
			
			if poss:ToScreen().x > (ScrW()/2)-centerdist and  -- Don't waste processor power on drawing things we can't see.
			poss:ToScreen().y > (ScrH()/2)-centerdist and
			poss:ToScreen().x < (ScrW()/2)+centerdist and
			poss:ToScreen().y < (ScrH()/2)+centerdist then
				
				local angle = ent:GetAngles()
				local exp = 10^decimals
				local texts = {}
				local colr, colg, colb, cola = ent:GetColor()
				local name = ""
				if ent:IsPlayer() then name = ent:GetName() end
				table.insert( texts, "Entity: ("..ent:EntIndex() ..") ".. ent:GetClass() .." " .. name )
				
				if not (poss.x == 0 and poss.y == 0 and poss.z == 0) then
					table.insert( texts, "Position: ".. math.Round(poss.x*exp)/exp ..", ".. math.Round(poss.y*exp)/exp ..", ".. math.Round(poss.z*exp)/exp )
				end
				if not (angle.p == 0 and angle.y == 0 and angle.r == 0) then
					table.insert( texts, "Angles: ".. math.Round(angle.p*exp)/exp ..", ".. math.Round(angle.y*exp)/exp ..", ".. math.Round(angle.r*exp)/exp )
				end
				if (ent:GetModel() != "" and ent:GetModel() != nil) then
					table.insert( texts, "Model: ".. ent:GetModel() )
				end
				if (ent:GetMaterial() != "" and ent:GetMaterial() != nil ) then
					table.insert( texts, "Material: ".. ent:GetMaterial() )
				end
				if not (colr == 255 and colg == 255 and colb == 255) then
					table.insert( texts, "Color: ".. colr ..", ".. colg ..", ".. colb ..", ".. cola )
				end
				if ent:IsPlayer() then
					table.insert(texts, "Health: ".. ent:Health() .." Armor: ".. ent:Armor())
				end
				
				local text = ""
				for num,str in pairs(texts) do
					text = text .. str .. "\n"
				end
				draw.DrawText(text, "BudgetLabel", poss:ToScreen().x, poss:ToScreen().y + drawinginfo*16, Color(255,255,255,255),0)
				drawinginfo = drawinginfo + #texts + 1
			end
		end
	end
end

local pron = nil
local function togglepicker()
	if pron != nil then 
		hook.Remove("HUDPaint", "picker2")
		pron = nil
		print("Off")
	elseif pron == nil then
		pron = "yay"
		hook.Add("HUDPaint", "picker2", drawents)
		print("On")
	end
end
concommand.Add( "picker2", togglepicker )
