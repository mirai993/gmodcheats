local function rs_clipboard() // Create the function
	local savestuff = {}
	
	if(file.Exists("rs_clipboard.txt")) then
		savestuff = util.KeyValuesToTable(file.Read("rs_clipboard.txt"))
	end
	
	if (savestuff.x == nil || savestuff.y == nil || savestuff.text == nil || savestuff.text == "") then // set default stuff
		savestuff.x = 200
		savestuff.y = 100
		savestuff.text = "ReaperSWE's lua Clipboard\n\nType whatever you want in here.\nCopy and Paste etc..\n\nWhatever you want to do."
	end
	
	local Panel = vgui.Create("DFrame") // Create the frame
	Panel:SetPos(savestuff.x,savestuff.y) // set the frame's position on the screen
	Panel:SetSize(300, 300) // set the frame size
	Panel:SetTitle( "RS: Clipboard (Version 1.0)" ) // set the frame title
	Panel:ShowCloseButton( false ) // We have our own close button.
	Panel:SetVisible( true ) // Make the frame visible
	Panel:MakePopup() // make the frame popup
	
	local myText = vgui.Create("DTextEntry", Panel)
		local indent = 8
		myText:SetMultiline( 1 )
		myText:SetText(tostring(savestuff.text))
		myText:SetPos(8,22 +indent)
		myText:SetTall(-22 -indent +Panel:GetTall() - indent)
		myText:SetWide(-indent +Panel:GetWide() -indent)
	
	local function changesmade()
		if tostring(myText:GetValue()) == tostring(savestuff.text) then
			return false
		else
			return true
		end
	end
	local Menu = vgui.Create("DButton", Panel)
		Menu:SetText( "" )
		Menu:SetWide( Menu:GetTall())
		Menu:SetPos( Panel:GetWide() -Menu:GetWide())
		Menu.DoClick = function()
			local menu123 = DermaMenu() // create a derma menu
				if changesmade() then
				menu123:AddOption("Save Changes", function()
					savestuff.text = myText:GetValue()
					file.Write("rs_clipboard.txt", util.TableToKeyValues(savestuff))
				end )
				menu123:AddOption("Undo Changes", function()
					myText:SetText(tostring(savestuff.text))
				end )
				menu123:AddOption("Exit without Saving", function()
					rs_clipboardexit()
				end )
			else
				menu123:AddOption("Exit", function()
					savestuff.x,savestuff.y = Panel:GetPos()
					file.Write("rs_clipboard.txt", util.TableToKeyValues(savestuff))
					Panel:Close()
				end )
			end

			menu123:Open() 
		end
	
	function rs_clipboardexit() // Create the function	
		local Panel2 = vgui.Create("DFrame") // Create the frame
		local x,y = Panel:GetPos()
		Panel2:SetPos(x-100 +(Panel:GetWide()/2) ,y-25 +(Panel:GetTall()/2) ) // set the frame's position on the screen
		Panel2:SetSize(200, 50) // set the frame size
		Panel2:SetTitle( "Exit and Discard all changes?" ) // set the frame title
		Panel2:SetDraggable( false )
		Panel2:SetKeyboardInputEnabled( false )
		Panel2:ShowCloseButton( false )
		Panel2:SetVisible( true ) // Make the frame visible
		Panel2:MakePopup() // make the frame popup
		
		Panel:SetMouseInputEnabled( false )
		Panel:SetKeyboardInputEnabled( false )
		
		local btnYes = vgui.Create("DButton", Panel2)
			btnYes:SetText( "Yes" )
			btnYes:SetWide( 60 )
			btnYes:SetPos( 20, Panel2:GetTall()/2)
			btnYes.DoClick = function()
				savestuff.x,savestuff.y = Panel:GetPos()
				file.Write("rs_clipboard.txt", util.TableToKeyValues(savestuff))
				Panel:SetKeyboardInputEnabled( true )
				Panel:SetMouseInputEnabled( true )
				Panel:Close()
				Panel2:Close()
			end
		local btnNo = vgui.Create("DButton", Panel2)
			btnNo:SetText( "No" )
			btnNo:SetWide( 60 )
			btnNo:SetPos( Panel2:GetWide() - 60 -20, Panel2:GetTall()/2)
			btnNo.DoClick = function()
				Panel:SetKeyboardInputEnabled( true )
				Panel:SetMouseInputEnabled( true )
				Panel2:Close()
			end
		
	end // ending the function
end // ending the function
concommand.Add("rs_clipboard", rs_clipboard) // adding the console command 
