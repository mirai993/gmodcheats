--Splambob's quick clientside distance script.
--Bind a key to "distance_press" to use.
--Press key twice to define two points, press again to remove results.
--Outputs results to console for copy/pasta.

--Thanks to the Lua scripting section for being better at all this than me.


if not CLIENT then return end


local distance = {}
distance.vec1 = 0
distance.vec2 = 0
distance.dist = 0
distance.display = false





function DistThink()
	if distance.display then
		draw.WordBox( 8, ScrW() / 2, ScrH() / 2, "Distance: "..tostring(distance.dist), "Default", Color(50,50,75,100), Color(255,255,255,255) )
		draw.WordBox( 8, ScrW() / 2, ScrH() / 2 + 30, "Vec1: "..tostring(distance.vec1).."  Vec2: "..tostring(distance.vec2), "Default", Color(50,50,75,100), Color(255,255,255,255) )
		

	end
end
hook.Add("HUDPaint", "DistThink", DistThink)





function DistIn(player,command,arguments)

	if distance.vec1 == 0 then
		local vec1trace = LocalPlayer():GetEyeTrace()
		distance.vec1 = vec1trace.HitPos
	elseif distance.vec2 == 0 then
		local vec2trace = LocalPlayer():GetEyeTrace()
		distance.vec2 = vec2trace.HitPos
	end

	if distance.display then
		distance.display = false
		distance.vec1 = 0
		distance.vec2 = 0
		distance.dist = 0
	end
	
	if (distance.vec1 ~= 0) and (distance.vec2 ~= 0) then

		distance.dist = distance.vec1:Distance(distance.vec2)
		distance.display = true
		
		Msg("\n==== Distance Measure Script Output: ====\n\n      Distance: "..tostring(distance.dist).."\n    Vec1 (XYZ): "..tostring(distance.vec1).."\n    Vec2 (XYZ): "..tostring(distance.vec2).."\n\n")
	end

end


concommand.Add( "distance_press", DistIn )