--[[
	MOD/lua/client/detours/FragHack_Detours.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:35PM]
	===BadFile===
]]

/******************************
Name: FragHack
Credit: LordOfGears
*******************************/

local old_print 	= print
local old_msgn		= MsgN
local old_fileread 	= file.Read

MsgN("Detouring file.Read")
// file.Read
function file.Read( f, base )
	if f != nil and type(f) == "string" then
		if string.match(f, "addons/") or string.match(f, "lua/") or string.match(f, ".lua") or string.match(f, "data/") then
			chat.AddText( Color(255, 100, 100, 255), "[FragHack]", Color(100, 255, 100, 255), "Blocked attempt to view ".. f)
			surface.PlaySound("buttons/button6.wav")
			return "LOL NOPE"
		else
			return old_fileread(f, false)
		end
	end
end

MsgN("Detouring print")
// print
function print( Msg )
	MsgN(string.format("[FragHack] - ", Msg ))
	return old_print( Msg )
end
