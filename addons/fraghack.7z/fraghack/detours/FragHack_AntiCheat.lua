--[[
	MOD/lua/client/detours/FragHack_AntiCheat.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:35PM]
	===BadFile===
]]

/******************************
Name: FragHack
Credit: LordOfGears
*******************************/



function BlockRCC( cmd, ... )
	local old_rcc = RunConsoleCommand
	if ( FH.Bools["Frag_MISC_BRCC"] ) then
		if ( table.HasValue(FH.Log, cmd) ) then
			print("Blocked RCC: "..cmd)
			return old_rcc(cmd, ...)
		end
	end
end

MsgN("[FragHack] Base64Encode Bypassed!")
function util.Base64Encode()
	local Picture	= file.Read("error.txt", "DATA" )
	chat.AddText("Someone is taking a screenshot of your screen! Sending a ERROR picture!")
	return( Picture )
end

MsgN("[FragHack] DAC Bypassed!")
// Bypass DAC
for i = 100, 10000 do
	hook.Remove( "Think", tostring( i ) );
end

for i = 1, 10 do
	hook.Remove( "Think", tostring( i ) );
end

MsgN("[FragHack] Other Timers Bypassed!")
timer.Destroy( "AntiCheatTimer" )
timer.Destroy( "testing123" )

hook.Remove( "Think", "PlayerInfoThing" )

hook.Add( "Think", "sh_menu", function()
	return true
end )
hook.Remove( "Think", "sh_menu" )