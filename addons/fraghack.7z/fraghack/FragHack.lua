--[[
	MOD/lua/client/FragHack.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:34PM]
	===BadFile===
]]

/******************************
Name: FragHack
Credit: LordOfGears ( Luv u :3 )
*******************************/

include("detours/FragHack_Detours.lua")
include("detours/FragHack_AntiCheat.lua")
include("libs/FragHack_ESP.lua")
include("libs/FragHack_Chams.lua")
include("libs/FragHack_Bhops.lua")

FH 		= {};
FH.Log  = { "dac_pleasebanme", "dac_imacheater", "Give_LightSuit", "Give_DarkSuit", "blade_client_check", "quit", "disconnect", "retry", "exit" };
FH.Dev  = { "STEAM_0:0:53429341" };

FH.Bools = {
	[ "Frag_ESP_Active" ] 			= true,
	[ "Frag_ESP_MoneyPrinter" ] 	= true,
	[ "Frag_ESP_Weapons"] 			= true,
	[ "Frag_ESP_Name" ] 			= true,
	[ "Frag_ESP_Health" ] 			= true,
	[ "Frag_ESP_Status" ] 			= false,
	[ "Frag_ESP_Tracer" ]			= true,
	[ "Frag_ESP_Chams" ] 			= true,

	[ "Frag_MISC_BRCC" ] 			= true,
	[ "Frag_MISC_Bhop"]				= true,
	[ "Frag_MISC_BStraff" ]			= false,
	
};

FH.Vars	= {
	[ "Frag_ESP_Chams" ] = "Solid"
};

FH.Binds	= {
	["+menu"] = KEY_P
};

FH.Keys	= {
	[1] = { Name = "A", Key = KEY_A },
	[2] = { Name = "B", Key = KEY_B },
	[3] = { Name = "C", Key = KEY_C },
	[4] = { Name = "D", Key = KEY_D },
	[5] = { Name = "E", Key = KEY_E },
	[6] = { Name = "F", Key = KEY_F },
	[7] = { Name = "G", Key = KEY_G },		
	[8] = { Name = "H", Key = KEY_H },
	[9] = { Name = "I", Key = KEY_I },
	[10] = { Name = "J", Key = KEY_J },
	[11] = { Name = "K", Key = KEY_K },
	[12] = { Name = "L", Key = KEY_L },
	[13] = { Name = "M", Key = KEY_M },
	[14] = { Name = "N", Key = KEY_N },
	[15] = { Name = "O", Key = KEY_O },
	[16] = { Name = "P", Key = KEY_P },
	[17] = { Name = "Q", Key = KEY_Q },
	[18] = { Name = "R", Key = KEY_R },
	[19] = { Name = "S", Key = KEY_S },
	[20] = { Name = "T", Key = KEY_T },
	[21] = { Name = "U", Key = KEY_U },
	[22] = { Name = "V", Key = KEY_V },
	[23] = { Name = "W", Key = KEY_W },
	[24] = { Name = "X", Key = KEY_X },
	[25] = { Name = "Y", Key = KEY_Y },
	[26] = { Name = "Z", Key = KEY_Z },
	[27] = { Name = "SPACE", Key = KEY_SPACE },
	[28] = { Name = "TAB", Key = KEY_TAB },
	[29] = { Name = "Left Shift", Key = KEY_LSHIFT },
	[30] = { Name = "Right Shift", Key = KEY_RSHIFT },
	[31] = { Name = "Left Alt", Key = KEY_LALT },
	[32] = { Name = "Right Alt", Key = KEY_RALT },
	[33] = { Name = "Delete", Key = KEY_DELETE },
	[34] = { Name = ".", Key = KEY_PERIOD },
	[35] = { Name = "/", Key = KEY_SLASH },
	[36] = { Name = "[", Key = KEY_LBRACKET },
	[37] = { Name = ";", Key = KEY_SEMICOLON },
	[38] = { Name = "'", Key = KEY_APOSTROPHE },
	[39] = { Name = ",", Key = KEY_COMMA },	
};

/*
function IsDown( Bind )
	return input.IsKeyDown( FH.Binds[ Bind ] )
else
	return false
end
*/

function GetAdmin(v)
	if v:GetNetworkedString("UserGroup") != "user" then
		return v:GetNetworkedString( "UserGroup" )
	end
end

function IsWorking(v)
	if ( v:Alive() && v:Health() ~= 0 && v != LocalPlayer() ) then
		return true
	else
		return false
	end
end

function IsFriend(v)
	if ( v:GetFriendStatus() == "friend" ) then
		return "Friend"
	else
		return "Random"
	end
end

function FH:IsDev(ply)
	if ( table.HasValue(FH.Dev, ply:SteamID() ) ) then
		return true
	else
		return false
	end
end

timer.Create(tostring(math.random(100, 100000) ), 30, 0, function()
	for k, v in pairs( player.GetAll() ) do
		if ( FH:IsDev( LocalPlayer() ) ) then
			chat.AddText(Color(100, 255, 100), "[FragHack]", Color(100, 100, 255), "Wecome"..LocalPlayer().." ! We hope you enjoy SegaHack V3L by OverDoen and LordOfGears!")
		elseif( !v:IsDev() ) then
			chat.AddText(Color(100, 255, 100), "[FragHack]", Color(100, 100, 255), "Jack off and quit stealling hacks why don't you?")
			return
		end
	end
end )



function Welcome()
	MsgN("\n");
	MsgN("\n");
	MsgN("-----------------------------------------------------\n");
	MsgN("==================== Information ====================\n");
	MsgN("Welcome player: "..LocalPlayer().."! Have fun!	   \n");
	MsgN("==================== End of Info ====================\n");
	MsgN("\n");
	Msgn("\n");
end