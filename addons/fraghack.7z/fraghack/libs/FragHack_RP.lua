--[[
	MOD/lua/client/libs/FragHack_RP.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:37PM]
	===BadFile===
]]

/******************************
Name: FragHack
Credit: LordOfGears
*******************************/

local ESPPrinter	= {
"money_printer",
"topaz_money_printer",
"amethyst_money_printer",
"emerald_money_printer",
"ruby_money_printer",
"sapphire_money_printer"
};

local ESPWeapons	= {
"arrest_stick",
"door_ram",
"keys",
"lockpick"
"ls_sniper",
"med_kit",
"stunstick",
"unarrest_stick"
"weapon_ak472"
"weapon_deagle2",
}

function SimpleRPESP()
	for k, v in pairs( player.GetAll() ) do
		if ( FH.Bools["Frag_ESP_Active"] ) then
		local Pos = v:GetPos():ToScreen();

				if ( FH.Bools["Frag_ESP_MoneyPrinter"] ) then
					if ( table.HasValue(ESPPrinter) ) then
						draw.SimpleText("Money Printer", "DefaultFixed", Pos.x, Pos.y - 20, Color(100, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

				if ( FH.Bools["Frag_ESP_Weapons"] ) then
					if( table.HasValue(ESPWeapons) ) then
						draw.SimpleText("Weapon", "DefaultFixed", Pos.x, Pos.y - 20, Color(255, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				end

			end
		end
	end
end

