--[[
	MOD/lua/client/libs/FragHack_Chams.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:36PM]
	===BadFile===
]]

local function CreateMat()
	local BaseInfo	= {
		[ "$basetexture" ] = "models/debug/debugwhite",
		[ "$model" ] = 1,
		[ "$translucent" ] = 1,
		[ "$alpha" ] = 1,
		[ "$nocull" ] = 1,
		[ "$ignorez" ] = 1  
};
local Material
	if ( FH.Vars["Frag_ESP_Chams" ] == "Solid" ) then
		Material = CreateMaterial("Frag_Solid", "VertexLitGeneric", BaseInfo)
	elseif ( FH.Vars["Frag_ESP_Chams"] == "Wireframe" ) then
		Material = CreateMaterial( "Frag_Wire", "Wireframe", BaseInfo)
	end
	return Material
end

function Chams()
	for k, v in pairs( player.GetAll() ) do
		if ( FH.Bools["Frag_ESP_Active"] ) then
			if ( IsWorking(v) ) then
				if ( FH.Bools["Frag_ESP_Chams"] ) then
				local color = team.GetColor( v:Team() );
					cam.Start3D( EyePos(), EyeAngles() )
						render.SuppressEngineLighting( true )
                        render.SetColorModulation( ( color.r * ( 1 / 255 ) ), ( color.g * ( 1 / 255 ) ), ( color.b * ( 1 / 255 ) ) )
                        render.MaterialOverride( Material )
                        v:DrawModel()
                        render.SuppressEngineLighting( false )
                        render.SetColorModulation(1,1,1)
                        render.MaterialOverride( )
                        v:DrawModel()
					cam.End3D()
				end
			end
		end
	end
end
hook.Add("HUDPaint", tostring( math.random(1, 10000) ), Chams )