--[[
	MOD/lua/client/libs/FragHack_ESP.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:37PM]
	===BadFile===
]]

function SimpleESP()
	for k, v in pairs( player.GetAll() ) do
		if ( FH.Bools["Frag_ESP_Active"] ) then
			if ( IsWorking(v) ) then

				local Pos	= v:GetPos():ToScreen();
				local x = ScrW() / 2;
				local y = ScrH() / 2;
				local Name = v:Name();
				local Health = v:Health();

				if ( FH.Bools["Frag_ESP_Name"] ) then
					draw.SimpleText("N: "..v:Name(), "DefaultFixed", Pos.x, Pos.y, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end

				if ( FH.Bools["Frag_ESP_Health"] ) then
					draw.SimpleText("H: "..v:Health(), "DefaultFixed", Pos.x, Pos.y + 10, Color(255 - Health * 2.55, Health * 2.55, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER ) 
				end

				if ( FH.Bools["Frag_ESP_Status"] ) then
					draw.SimpleText( GetAdmin(v), "DefaultFixed", Pos.x, Pos.y + 20, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER ) 
				end

				if ( FH.Bools["Frag_ESP_Tracer"] ) then
					surface.SetDrawColor( 100, 100, 255, 255)
					surface.DrawLine(x, y, Pos.x, Pos.y)
				end
			end
		end
	end
end
hook.Add("HUDPaint", tostring( math.random(1, 10000) ), SimpleESP )