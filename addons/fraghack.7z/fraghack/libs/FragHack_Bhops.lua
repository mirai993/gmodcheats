--[[
	MOD/lua/client/libs/FragHack_Bhops.lua
	gяєу нєℓℓισѕ | STEAM_0:0:53429341 <66.168.88.138:27006> | [27-10-13 11:39:36PM]
	===BadFile===
]]

local bhop = {}
local bhopHooks = { hook = {}, name = {} };

function bhop.AddHook(hookname, name, func)
	table.insert( bhopHooks.hook, hookname);
	table.insert( bhopHooks.name, name );
	hook.Add( hookname, name, func );
end

local OldEyePos = LocalPlayer():EyeAngles()
function bhop.CreateMove( cmd )
local JumpReleased = false;	
	if ( cmd:KeyDown( IN_JUMP ) ) then
		if ( !JumpReleased ) then
			if ( FH.Bools["Frag_MISC_Bhop"] && !LocalPlayer():OnGround() ) then
				cmd:RemoveKey( IN_JUMP );
			end
		else
			JumpReleased = false;
		end

	if ( FH.Bools["Frag_MISC_BStraff"] ) then
		local traceRes = LocalPlayer():EyeAngles()
			while( traceRes.y > OldEyePos.y ) do
				OldEyePos = traceRes;
				RunConsoleCommand("+moveleft")
					timer.Simple( .25, function()
						RunConsoleCommand("-moveleft")
					end )
				end

			while( OldEyePos.y > traceRes.y ) do
				OldEyePos = traceRes;
				RunConsoleCommand("+moveright")
					timer.Simple(.25, function() 
						RunConsoleCommand("-moveright")
					end )
				end
			end
		elseif( !JumpReleased) then
				JumpReleased = true;
			end
		end
	bhop.AddHook( "CreateMove", tostring( math.random( 0, 24692469246924692469) ), bhop.CreateMove )
	print("Bhop Loaded!")