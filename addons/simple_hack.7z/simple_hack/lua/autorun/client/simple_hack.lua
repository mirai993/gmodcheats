colors = {} -- small color table, add yours!
colors[ "red" ] = Color( 255, 0, 0, 255 )
colors[ "green" ] = Color( 0, 255, 0, 255 )
colors[ "blue" ] = Color( 0, 0, 255, 255 )

function simple_hack() -- core code

	ply = LocalPlayer() -- making things faster
	
	for k, v in pairs( player.GetAll() ) do -- getting everyone in the server
	
		if v == ply then -- if the target is ourselves
		
			-- do nothing
		
		else -- else
		
			if v:Alive() then -- check if the target is alive
			
				local vhead = v:LookupBone("ValveBiped.Bip01_Head1") -- getting the head of the player
				
				local vheadpos, vheadang = v:GetBonePosition( vhead ) -- getting its position
				
				local vscreenpos = vheadpos:ToScreen() -- converting it into vector
				
				if v:Team() == ply:Team() then -- If ally
				
					surface.SetTextColor( colors[ "red" ] ) -- write some info
					surface.SetTextPos( vscreenpos.x, vscreenpos.y ) 
					surface.DrawText( v:Nick() ) -- name of player
					
					surface.SetTextColor( colors[ "red" ] )
					surface.SetTextPos( vscreenpos.x, vscreenpos.y + 15 ) 
					surface.DrawText( v:Health() .. " HP" ) -- his hp
					
					v:SetColor( 0, 255, 0, 255 ) -- the player is an ally, so make it green
					v:SetMaterial( "simple_hack/esp" ) -- esp material
					
				else -- If enemy
				
					surface.SetTextColor( colors[ "green" ] ) -- write some info
					surface.SetTextPos( vscreenpos.x, vscreenpos.y ) 
					surface.DrawText( v:Nick() ) -- name of the enemy
					
					surface.SetTextColor( colors[ "green" ] )
					surface.SetTextPos( vscreenpos.x, vscreenpos.y + 15 ) 
					surface.DrawText( v:Health() .. " HP" ) -- hp of the enemy
					
					v:SetColor( 255, 0, 0, 255 ) -- enemy so, red
					v:SetMaterial( "simple_hack/esp" ) -- esp material
					
				end
				
			end
		
		end
		
	end
	
end
hook.Add( "HUDPaint", "simple_hack", simple_hack ) -- activates the esp