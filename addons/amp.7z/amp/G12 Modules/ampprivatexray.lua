--[[
	amp/ampprivatexray.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local FGetMat = _R.Entity.GetMaterial
local repmat = CreateClientConVar("amp_ampmaterial", "RayMat", true, false)
local AmpLightBrightness = CreateClientConVar("amp_light_brightness", 10, true, false)
local AmpLightSize = CreateClientConVar("amp_lightsize", 700, true, false)
local playercolors = CreateClientConVar( "amp_teamcolors", "0", true, false )

local function ToggleampnodeRay()
   if RayOn then
      surface.PlaySound("off.wav") 
      for k,v in pairs(ents.GetAll()) do
         FSetMat(v, AllMats[v])
         local z = allcolors[v]
         if z and type(z) == "table" then
            FSetColor(v, z.r, z.g, z.b, z.a)
         else 
            FSetColor(v, 255,255,255,255)
         end
      end
      allcolors = {}
   else
      for k,v in pairs(ents.GetAll()) do
         ExecFRayOnce(v)
      end
      surface.PlaySound("on.wav") 
   end
   RayOn = not RayOn
end
concommand.Add("amp_xray_private", ToggleampnodeRay)

function ExecFRayOnce(v)
   local r,g,b,a = v:GetColor()
   local class = v:GetClass()
   local low = string.lower(class)
   if v:IsPlayer() and (r ~= 255 or g ~= 0 or b ~= 0 or a ~= 255) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v,255, 0, 0, 255)
         elseif v:IsNPC() and (r ~= 0 or g ~= 255 or b ~= 0 or a ~= 255) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 0, 255, 0, 255)
         elseif (class == "prop_physics" or class == "prop") and (r ~= 0 or g ~= 0 or b ~= 255 or a > 40) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 0, 0, 255, math.Clamp(a, 0, 40))
         elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 140, 0, 255, 255)
         elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 0, 0, 0, 30)
         elseif v:GetClass() == "env_spritetrail" and (r ~= 255 or g ~= 255 or b ~= 255 or a ~= 255) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 255, 255, 255, 255)
         elseif not v:IsPlayer() and not v:IsNPC() and v:GetClass() ~= "prop_physics" and v:GetClass() ~= "prop" and v:GetClass() ~= "env_spritetrail" and not v:IsWeapon() and v:GetClass() ~= "viewmodel" and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 255, 0, 0, 130)
         elseif string.find(class, "ghost") and a ~= 100 then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 255, 255, 255, 100)
         elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
            allcolors[v] = Color(r,g,b,a)
            FSetColor(v, 255, 0, 0, 60)
            
   if class ~= "viewmodel" and FGetMat(v) ~= repmat:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
      AllMats[v] = FGetMat(v)
      FSetMat(v, repmat:GetString())
   end
end

function DoPoKiRay()
   if not RayOn then return end
   for k,v in pairs(ents.FindByClass("prop_physics")) do
      if ValidEntity(v) then
         local trace = { }
         trace.start = LocalPlayer():GetShootPos()
         trace.endpos = v:GetPos()
         trace.filter = LocalPlayer()
         local CanSee = util.TraceLine( trace )
         local entsinradius = ents.FindInSphere( CanSee.HitPos, 10 )
         local secondtrace = { }
         secondtrace.start = LocalPlayer():GetShootPos()
         secondtrace.endpos = v:GetPos() + Vector( 0, 0, 65 )
         secondtrace.filter = LocalPlayer()
         local CanSeeSecond = util.TraceLine( secondtrace )
         local secondentsinradius = ents.FindInSphere( CanSeeSecond.HitPos, 10 )
         if v:GetVelocity():Length() > 1 then
            if table.HasValue( entsinradius, v ) or table.HasValue( secondentsinradius, v ) then
               if CanSee.HitWorld and CanSeeSecond.HitWorld then
                  FSetColor( v, 232, 225, 21, 100 )
                  FSetMat(v, repmat:GetString())
               else
                  FSetColor( v, 0, 200, 0, 100 )
                  FSetMat(v, repmat:GetString())               
               end
            else
               FSetColor( v, 232, 225, 21, 100 )
               FSetMat(v, repmat:GetString())
            end
         elseif table.HasValue( entsinradius, v ) or table.HasValue( secondentsinradius, v ) then 
            if CanSee.HitWorld and CanSeeSecond.HitWorld then
               FSetColor( v, 130, 0, 255, 100 )
               FSetMat(v, repmat:GetString())               
            else
               FSetColor(v,255, 0, 0, 100)
               FSetMat(v, repmat:GetString())
            end
         else
            FSetColor(v,130, 0, 255, 100)
            FSetMat(v, repmat:GetString())
         end
      end
   end
   
   for k,v in pairs(ents.FindByClass("prop")) do
      if ValidEntity(v) then
         FSetColor(v,255 , 0, 0, 100)
         FSetMat(v, repmat:GetString())
      end
   end
   
   for k,v in pairs(player.GetAll()) do
      if ValidEntity(v) then
         local playertrace = { }
         playertrace.start = LocalPlayer():GetShootPos()
         playertrace.endpos = v:GetPos() + Vector( 0, 0, 30 )
         playertrace.filter = LocalPlayer()
         local PlayerCanSee = util.TraceLine( playertrace )
         local PlayerRadius = ents.FindInSphere( PlayerCanSee.HitPos, 15 )
         if playercolors:GetBool() then
            local playercolor = team.GetColor( v:Team() )
            FSetColor(v,playercolor.r,playercolor.g,playercolor.b,120)
            FSetMat(v, repmat:GetString())
         else
            if table.HasValue( PlayerRadius, v ) then
               FSetColor(v,0,0,255,120)
               FSetMat(v, repmat:GetString())
            else
               FSetColor(v,179,107,12,120)
               FSetMat(v, repmat:GetString())
            end
         end
      end
   end
end
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)

local function FDynamicLight()
   local dlight = DynamicLight( LocalPlayer():UserID() + 2 ) 
   if ( dlight ) then 
      dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
      dlight.r = ampLightR:GetInt()
      dlight.g = ampLightG:GetInt()
      dlight.b = ampLightB:GetInt()
      dlight.Brightness = ampLightBrightness:GetInt()
      dlight.Size = ampLightSize:GetInt()
      dlight.Decay = 0 
      dlight.DieTime = CurTime() + 0.2
   end 
end  
 
local togglelight = true
concommand.Add("amp_light", function()
   togglelight = not togglelight
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglelight then
      hook.Remove("Think", "amp_Light")
   else
      hook.Add("Think", "amp_Light", FDynamicLight)
   end
end)

local function Surrounding_Light()
   local surr_light_brightness = CreateClientConVar( "surr_light_brightness", 8, true, false )
   local surr_light_size = CreateClientConVar( "surr_light_size", 700, true, false )
   local dlight = DynamicLight( LocalPlayer():UserID() ) 
   if ( dlight ) then 
      dlight.Pos = LocalPlayer():GetShootPos()
      dlight.r = 255
      dlight.g = 255
      dlight.b = 255
      dlight.Brightness = surr_light_brightness:GetInt()
      dlight.Size = surr_light_size:GetInt()
      dlight.Decay = 0 
      dlight.DieTime = CurTime() + 0.2
   end 
end  
 
local togglesurrlight = true
concommand.Add("surr_light", function()
   togglesurrlight = not togglesurrlight
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglesurrlight then
      hook.Remove("Think", "Surrounding_Light")
   else
      hook.Add("Think", "Surrounding_Light", Surrounding_Light)
   end
end)

local function FullBrightPlayer()
   for k,v in pairs( player.GetAll() ) do
      if v != LocalPlayer() then
         local dlight = DynamicLight( v:UserID() + 1 ) 
         if ( dlight ) then 
            dlight.Pos = v:GetShootPos()
            dlight.r = 255
            dlight.g = 255
            dlight.b = 255
            dlight.Brightness = 10
            dlight.Size = 100
            dlight.Decay = 0 
            dlight.DieTime = CurTime() + 0.2
         end
      end 
   end
end

local togglefullbrightplayers = true
concommand.Add("fullbrightplayers", function()
   togglefullbrightplayers = not togglefullbrightplayers
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglefullbrightplayers then
      hook.Remove("Think", "fullbright")
   else
      hook.Add("Think", "fullbright", FullBrightPlayer)
   end
end)

local PropPathOn = CreateClientConVar( "amp_proppath", "1", true, false )
local SkyboxPosOn = CreateClientConVar( "amp_skyboxtrace", "0", true, false )
local SpeedOn = CreateClientConVar( "amp_speedometer", "0", true, false )

local function PaintThings()
   if not RayOn then return end
   for k,v in pairs( ents.GetAll() ) do
      if v:IsValid() and v:GetVelocity():Length() > 60 and v:GetClass() == "prop_physics" and PropPathOn:GetBool() then
         local PropCenter = v:OBBCenter()
         local propTrace = {}
         propTrace.start = v:LocalToWorld( v:OBBCenter() )
         propTrace.endpos = v:LocalToWorld( v:OBBCenter() ) + v:GetVelocity() * Vector( 10000, 10000, 10000 )
         propTrace.filter = v
         local DoPropLine = util.TraceLine( propTrace )
         cam.Start3D( EyePos() , EyeAngles() )
            render.SetMaterial( Material( "cable/xbeam" ) )
            render.DrawBeam( DoPropLine.StartPos, DoPropLine.HitPos, 15, 0, 0, Color( 255, 255, 0, 255 ) )
         cam.End3D()
      end
      if v:IsValid() and v:GetClass() == "prop_physics" then
         local propradius = ents.FindInSphere( v:LocalToWorld( v:OBBCenter() ), 60 )
         for a,b in pairs( propradius ) do
            if b:IsPlayer() and b:Alive() then
            end
         end
      end
   end
   for k,v in pairs( player.GetAll() ) do
      if v:IsValid() and v:IsPlayer() and v:Alive() and SkyboxPosOn:GetBool() and v != LocalPlayer() then
         local skytrace = {}
         skytrace.start = v:GetShootPos()
         skytrace.endpos = v:GetShootPos() + Vector( 0, 0, 10000 )
         skytrace.filter = v
         local doskytrace = util.TraceLine( skytrace )
         cam.Start3D( EyePos() , EyeAngles() )
            render.SetMaterial( Material( "effects/laser1" ) )
            render.DrawBeam( v:GetShootPos(), doskytrace.HitPos, 25, 0, 0, Color( 56, 186, 255, 255 ) )
         cam.End3D()
      end
   end
   if SpeedOn:GetBool() then
      local speedy = LocalPlayer():GetVelocity():Length()
      draw.SimpleTextOutlined( "Speed: " .. tostring( math.Round( speedy * 3600 / 63360 * 0.75 ) ) .. "mph", "Trebuchet24", ScrW()/2, 25, Color( 0, 0, 0, 255 ), 1, 1, 1, Color( 255, 255, 255, 150 ) )
   end
end
hook.Add( "HUDPaint", "paintthings", PaintThings )



local PropSoundsOn = CreateClientConVar( "amp_propsounds", "0", true, false )
local PropSoundsPitch = CreateClientConVar( "amp_propsounds_pitchdivisor", "10", true, false )

local function GetSound()
   if PropSoundsOn:GetInt() < 10 and PropSoundsOn:GetInt() > 0 then
      return PropSoundsOn:GetInt()
   else
      return 1
   end
end
	  
local function PropSound()
   if not RayOn then return end
   if not PropSoundsOn:GetBool() then return end
   for k,v in pairs( ents.GetAll() ) do
      if v == NULL then return end
      if v:GetClass() == "prop_physics" then
         if v:IsValid() then
            if v:GetVelocity():Length() > 60 then
               local vol = 800
               local pitch = math.Clamp( v:GetVelocity():Length() / PropSoundsPitch:GetInt(), 0, 255 )
               local propSound = CreateSound( v, "movement" .. GetSound() .. ".wav" )
               if not propSound:IsPlaying() then propSound:Play() end
               propSound:ChangePitch( pitch )
               propSound:ChangeVolume( vol )
            end
         end
      end
   end
end
hook.Add( "Think", "propnoises", PropSound )

local PropSpawnSound = CreateClientConVar( "amp_propspawnsound", "0", true, false )

local function SpawnedPropSound( ent )
   if not RayOn then return end
   if not PropSpawnSound:GetBool() then return end
   if ent == NULL then return end
   if ent:GetClass() == "prop_physics" then
      local SpawnSound = CreateSound( ent, "movement6.wav" )
      if not SpawnSound:IsPlaying() then SpawnSound:Play() end
   end
end
hook.Add( "OnEntityCreated", "propspawnnoise", SpawnedPropSound )
end