--[[
	amp/darkrpmenu.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

local ddm
local choice
local conv = CreateClientConVar("amp_printtoconsole","0")
local convchief = CreateClientConVar("amp_ischiefserver","0")

local function getplayers()
for k,v in pairs(player.GetAll()) do
   ddm:AddChoice(v:Nick())
   end
end
local function dispbox()
   inf = vgui.Create("DFrame")
   inf:SetSize(400,400)
   inf:Center()
   inf:MakePopup()
   inf:SetTitle("Ampbot Beta V2 Player Info")
   inf:SetSkin("DarkRP")
   inf:SetBackgroundBlur(false)
	inf.Paint = function()
		surface.SetDrawColor( 100, 100, 100, 210 )    
		surface.DrawRect( 0, 0, inf:GetWide(), inf:GetTall() )    
		surface.SetDrawColor( 70, 70, 70, 210 )    
		surface.DrawOutlinedRect( 0, 0, inf:GetWide(), inf:GetTall() )
	end
   ddm = vgui.Create("DMultiChoice",inf)
   ddm:SetSize(200,20)
   ddm:SetPos(5,35)
   
   getplayers()
   function ddm:OnSelect(index,value,data)
      choice = value

      for k,v in pairs(player.GetAll()) do
         if choice == v:Nick() then
            local mdl = vgui.Create( "DModelPanel", inf )
            mdl:SetModel( v:GetModel() )
            mdl:SetPos(150,25)
            mdl:SetSize( 300,300 )
            mdl:SetCamPos(Vector( 50, 90, 120 ))
            mdl:SetLookAt(Vector( 0, 0, 0 ))
      end
   end
end


   local cbpc = vgui.Create("DCheckBoxLabel",inf)
   cbpc:SetPos(5,65)
   cbpc:SetText("Print to Console")
   cbpc:SetConVar("amp_printtoconsole")
   cbpc:SetValue(0)
   cbpc:SizeToContents()

   local bdm = vgui.Create("DButton",inf)
   bdm:SetSize(100,20)
   bdm:SetPos(5,380)
   bdm:SetText("Get Info")

   bdm.DoClick = function()
   
      if conv:GetInt() == 1 then
         printconsole()   
      else
         dispinfobox()
      end
      inf:Close()
   end

   local dpb = vgui.Create("DButton",inf)

   dpb:SetSize(100,20)
   dpb:SetPos(115,380)
   dpb:SetText("Display Table")
   dpb.DoClick = function()
   disptabledtv()
   end   
end
function disptabledtv()
local dtv = vgui.Create("DListView")
   dtv:SetParent(inf)
   dtv:SetPos(5, 100)
   dtv:SetSize(250, 170)
   dtv:SetMultiSelect(false)
   dtv:AddColumn("Statistics")
   dtv:AddColumn("Values")

   dtv.OnRowSelected = function( panel, line )
      LocalPlayer():ChatPrint("Copied to Clipboard:  "..dtv:GetLine(line):GetValue(1))
      SetClipboardText( dtv:GetLine(line):GetValue(2) ) 
      
   end
   for k,v in pairs(player.GetAll()) do
      if choice == v:Nick() then
         if v:IsSuperAdmin()  then
            Rank = "Super Admin"
         elseif v:IsAdmin() and !v:IsSuperAdmin() then
            Rank = "Admin"
         elseif !v:IsAdmin() and !v:IsSuperAdmin() then
            Rank = "Guest"
         
         end

         
         local money = v.DarkRPVars.money or 0
         local job = v.DarkRPVars.job or "Citizen"
         local salary = v.DarkRPVars.salary or 0
         

         dtv:AddLine("Steam Name",v:SteamName())
         dtv:AddLine("Nick Name",v:Nick())
         dtv:AddLine("Health",v:Health())
         dtv:AddLine("Armor",v:Armor())
         dtv:AddLine("Money",money)
         dtv:AddLine("Job Name",job)
         dtv:AddLine("Rank",Rank)
         dtv:AddLine("SteamID",v:SteamID())
         dtv:AddLine("Entity Number",v:EntIndex())
         dtv:AddLine("Alive?",v:Alive())
         
      end
   end
end
 function dispinfobox()

   local ibox = vgui.Create("DFrame")
   ibox:SetSize(765,75)
   ibox:Center()
   ibox:MakePopup()
   ibox:SetTitle(choice.."'s Info")
   ibox:SetSkin("DarkRP")
   ibox:SetBackgroundBlur(false)
   ibox:SetDraggable(true)
   ibox:ShowCloseButton(true)

   local infolist = vgui.Create("DListView", ibox)
   infolist:SetPos(5, 25)
   infolist:SetSize(750, 35)
   infolist:AddColumn("Steam Name")
   infolist:AddColumn("Nick Name")
   infolist:AddColumn("Health")
   infolist:AddColumn("Armor")
   infolist:AddColumn("Money")
   infolist:AddColumn("Salary")
   infolist:AddColumn("Job name")
   infolist:AddColumn("Rank")
   infolist:AddColumn("SteamID")
   infolist:AddColumn("Entity")
   infolist:AddColumn("Alive")


   for k,v in pairs(player.GetAll()) do
      if choice == v:Nick() then
      local rank = "Guest"
      local job,salary,money
         if v:IsSuperAdmin()  then
            Rank = "Super Admin"
               elseif v:IsAdmin() and !v:IsSuperAdmin() then
                  Rank = "Admin"
               elseif !v:IsAdmin() and !v:IsSuperAdmin() then
                  Rank = "Guest"
         end
         
         money = v.DarkRPVars.money or 0
         job = v.DarkRPVars.job or "Citizen"
         salary = v.DarkRPVars.salary or 0
         
         
            infolist:AddLine(
            v:SteamName(),
            v:Nick(),
            v:Health(),
            v:Armor(),
            "$"..money,
            "$"..salary,
            job,
            Rank,
            v:SteamID(),
            v:EntIndex(),
            v:Alive())
      end
         
      end
   end
function printconsole()
local rank = "Guest"
local Money,Job,Salary
for k,v in pairs(player.GetAll()) do
   if v:Nick() == choice then
         if v:IsSuperAdmin()  then
         Rank = "Super Admin"
      elseif v:IsAdmin() and !v:IsSuperAdmin() then
         Rank = "Admin"
         elseif !v:IsAdmin() and !v:IsSuperAdmin() then
         Rank = "Guest"
      end
      
      local Money = v.DarkRPVars.money or 0
      local Job = v.DarkRPVars.job or "Citizen"
      local Salary = v.DarkRPVars.salary or 0
      
         money = 0
            job = 0
            salary = 0
      
      print("SteamName: "..v:SteamName())
      print("Nickname:  "..v:Nick())
      print("Health:  "..v:Health())
      print("Armor:  "..v:Armor())
      print("Cash:  $"..Money)
      print("Salary:  $"..Salary)
      print("Job:  "..Job)
      print("Rank:  "..Rank)
      print("SteamID:  "..v:SteamID())
      print("Entity:  "..v:EntIndex())
      
      print("----")
   end
      end

end
concommand.Add("+ampinfo",dispbox)