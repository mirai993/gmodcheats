--[[
	amp/infomod.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

function EntityInformation()
   local trace = LocalPlayer():GetEyeTrace()
   print(trace.Entity:GetClass())
   print(trace.Entity:GetModel())
   if trace.Hit and trace.Entity:IsValid() and string.find(string.lower(trace.Entity:GetClass()), "prop") then
      surface.PlaySound("modelfound.wav")
      print(trace.Entity:GetModel())
      print(trace.Entity:GetOwner())
      print(trace.Entity:Health())
      PrintTable(trace.Entity:GetTable())
   elseif trace.Hit and trace.Entity:IsValid() and trace.Entity:GetClass() == "player" then
      print(trace.Entity:Nick())
      print(trace.Entity:Health())
      print(trace.Entity:GetActiveWeapon():GetPrintName())
      print("This player is an admin:", trace.Entity:IsAdmin())
   end
end
concommand.Add("amp_GetModel", EntityInformation)