--[[
	amp/ampxray.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

local RayOn2 = false
local AllMats2 = {}
local allcolors2 = {}
local FSetColor2 = _R.Entity.SetColor
local FSetRayMat2 = _R.Entity.SetMaterial
local FGetRayMat2 = _R.Entity.GetMaterial
local repmat2 = CreateClientConVar("amp_xraymaterial", "RayMat", true, false)

local function TogglePoKiRay2()
	if RayOn2 then
		surface.PlaySound("off.wav") 
		for k,v in pairs(ents.GetAll()) do
			FSetRayMat2(v, AllMats2[v])
			local z = allcolors2[v]
			if z and type(z) == "table" then
				FSetColor2(v, z.r, z.g, z.b, z.a)
			else 
				FSetColor2(v, 255,255,255,255)
			end
		end
		allcolors2 = {}
	else
		for k,v in pairs(ents.GetAll()) do
			ExecFRayOnce2(v)
		end
		surface.PlaySound("on.wav") 
	end
	RayOn2 = not RayOn2
end
concommand.Add("amp_xray", TogglePoKiRay2)

function ExecFRayOnce2(v)
   local r,g,b,a = v:GetColor()
   local class = v:GetClass()
   local low = string.lower(class)
   if v:IsPlayer() and (r ~= 255 or g ~= 0 or b ~= 0 or a ~= 255) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v,255, 0, 0, 255)
         elseif v:IsNPC() and (r ~= 0 or g ~= 255 or b ~= 0 or a ~= 255) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 0, 255, 0, 255)
         elseif (class == "prop_physics" or class == "prop") and (r ~= 0 or g ~= 0 or b ~= 255 or a > 40) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 0, 0, 255, math.Clamp(a, 0, 40))
         elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 140, 0, 255, 255)
         elseif v:GetClass() == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 0, 0, 0, 30)
         elseif v:GetClass() == "env_spritetrail" and (r ~= 255 or g ~= 255 or b ~= 255 or a ~= 255) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 255, 255, 255, 255)
         elseif not v:IsPlayer() and not v:IsNPC() and v:GetClass() ~= "prop_physics" and v:GetClass() ~= "prop" and v:GetClass() ~= "env_spritetrail" and not v:IsWeapon() and v:GetClass() ~= "viewmodel" and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 255, 0, 0, 130)
         elseif string.find(class, "ghost") and a ~= 100 then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 255, 255, 255, 100)
         elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
            allcolors2[v] = Color(r,g,b,a)
            FSetColor2(v, 255, 0, 0, 60)
		end
	if class ~= "viewmodel" and FGetRayMat2(v) ~= repmat2:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
		AllMats2[v] = FGetRayMat2(v)
		FSetRayMat2(v, repmat2:GetString())
	end
end

function DoPoKiRay2()
	if not RayOn2 then return end
	for k,v in pairs(ents.FindByClass("prop_physics")) do
		if ValidEntity(v) then
			FSetColor2(v,50, 186, 255, 90)
			FSetRayMat2(v, repmat2:GetString())
		end
	end
	
	for k,v in pairs(ents.FindByClass("prop")) do
		if ValidEntity(v) then
			FSetColor2(v,50, 255, 50, 40)
			FSetRayMat2(v, repmat2:GetString())
		end
	end
	
	for k,v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			FSetColor2(v,255,0,0,255)
			FSetRayMat2(v, repmat2:GetString())
		end
	end
end 
hook.Add( "RenderScene", "PoKiRay2", DoPoKiRay2)

local function FDynamicLight()
   local dlight = DynamicLight( LocalPlayer():UserID() + 2 ) 
   if ( dlight ) then 
      dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
      dlight.r = ampLightR:GetInt()
      dlight.g = ampLightG:GetInt()
      dlight.b = ampLightB:GetInt()
      dlight.Brightness = ampLightBrightness:GetInt()
      dlight.Size = ampLightSize:GetInt()
      dlight.Decay = 0 
      dlight.DieTime = CurTime() + 0.2
   end 
end  
 
local togglelight = true
concommand.Add("amp_light", function()
   togglelight = not togglelight
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglelight then
      hook.Remove("Think", "amp_Light")
   else
      hook.Add("Think", "amp_Light", FDynamicLight)
   end
end)

local function Surrounding_Light()
   local surr_light_brightness = CreateClientConVar( "surr_light_brightness", 8, true, false )
   local surr_light_size = CreateClientConVar( "surr_light_size", 700, true, false )
   local dlight = DynamicLight( LocalPlayer():UserID() ) 
   if ( dlight ) then 
      dlight.Pos = LocalPlayer():GetShootPos()
      dlight.r = 255
      dlight.g = 255
      dlight.b = 255
      dlight.Brightness = surr_light_brightness:GetInt()
      dlight.Size = surr_light_size:GetInt()
      dlight.Decay = 0 
      dlight.DieTime = CurTime() + 0.2
   end 
end  
 
local togglesurrlight = true
concommand.Add("surr_light", function()
   togglesurrlight = not togglesurrlight
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglesurrlight then
      hook.Remove("Think", "Surrounding_Light")
   else
      hook.Add("Think", "Surrounding_Light", Surrounding_Light)
   end
end)

local function FullBrightPlayer()
   for k,v in pairs( player.GetAll() ) do
      if v != LocalPlayer() then
         local dlight = DynamicLight( v:UserID() + 1 ) 
         if ( dlight ) then 
            dlight.Pos = v:GetShootPos()
            dlight.r = 255
            dlight.g = 255
            dlight.b = 255
            dlight.Brightness = 10
            dlight.Size = 100
            dlight.Decay = 0 
            dlight.DieTime = CurTime() + 0.2
         end
      end 
   end
end

local togglefullbrightplayers = true
concommand.Add("fullbrightplayers", function()
   togglefullbrightplayers = not togglefullbrightplayers
   LocalPlayer():EmitSound("flashlight.wav",100,100)
   if togglefullbrightplayers then
      hook.Remove("Think", "fullbright")
   else
      hook.Add("Think", "fullbright", FullBrightPlayer)
   end
end)