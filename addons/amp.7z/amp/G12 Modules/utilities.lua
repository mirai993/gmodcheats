--[[
	autorun/client/amputilities.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

print("Opening Private Scripts...")
local cansay = true
amp_CHATTIME = 1.6
local OOC = CreateClientConVar("amp_ooc", 1, true, false)
local amp_ReloadScripts = surface.PlaySound("loadedcorrect.wav")

function amp_DelayedSay(text)
   if cansay then
      local add = ""
      if OOC:GetInt() == 1 and GetGlobalInt("alltalk") == 0 then add = "/ooc " end
      local endresult = add.. tostring(text)
      if string.len(endresult) >= 126 then
         timer.Simple(1.62, amp_DelayedSay, string.sub(endresult, 127))
      end
      LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
      cansay = false
      timer.Simple(amp_CHATTIME, function() cansay = true end)
   else
      timer.Simple(amp_CHATTIME, amp_DelayedSay, text)
   end
end
--Example:
concommand.Add("amp_hiall", function()
   local hiall = ""
   for k,v in pairs(player.GetAll()) do 
      if v ~= LocalPlayer() then
         hiall = hiall ..", Hi " .. v:Nick()
      end
   end
   hiall = string.sub(hiall, 3)
   amp_DelayedSay(hiall)
end)

amp_CHATCOMMANDS = {}

function amp_addchatcmd(text, func)
   amp_CHATCOMMANDS[text] = func
end

function amp_CHAT(ply, text, teamonly, dead)
   if ply == LocalPlayer() then
      cansay = false
      timer.Simple(2.1, function() cansay = true end)
      for k,v in pairs(amp_CHATCOMMANDS) do
         if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then 
            v(string.sub(text, string.len(k) + 2)) 
            break
         elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
            v(string.sub(text, string.len(k) + 8)) 
         end
      end
   end   
end
hook.Add( "OnPlayerChat", "amp_chat", amp_CHAT)
amp_addchatcmd("amp_ReloadScripts", function() include("autorun/client/amputilities.lua") end)
amp_addchatcmd("FReloadScripts", function() include("autorun/client/amputilities.lua") end)
concommand.Add("amp_ReloadScripts", function() include("autorun/client/amputilities.lua")
   if amp_ReloadScripts then
      surface.PlaySound("loadedcorrect.wav")
      end
   end)
concommand.Add("FReloadScripts", function() include("autorun/client/amputilities.lua") end)

function fnotify(text, a, b)
   local Type, Length = a, b
   if not a and not b then
      Type, Length = 1, 5
   end
   if GAMEMODE.IsSandboxDerived then // in some gamemodes GAMEMODE:AddNotify() doesn't exist
      GAMEMODE:AddNotify(tostring(text), Type, Length)
      surface.PlaySound( "ambient/water/drip2.wav")
   end
end

for k,v in pairs(file.FindInLua("amp/*.lua")) do include("amp/"..v) end



