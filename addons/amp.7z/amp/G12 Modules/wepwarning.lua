--[[
	amp/wepwarning.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

local enabled = CreateClientConVar("amp_ArrestBatonWarning", 0, true, false)

local waits = {}

local function getAllWeapons()
	for k,v in pairs(player.GetAll()) do
		if ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() == "arrest_stick" and not waits[v] then
			player.GetByID( 1 ):ChatPrint("Arrest Baton.")
			player.GetByID( 1 ):ChatPrint(v:Nick() .. " pulled out their arrest baton.")
                        surface.PlaySound("detected.wav")
			waits[v] = true
		elseif ValidEntity(v:GetActiveWeapon()) and v:GetActiveWeapon():GetClass() ~= "arrest_stick" and waits[v] then
			player.GetByID( 1 ):ChatPrint("Not arrest baton.")
			waits[v] = false
		end
	end
end

if enabled:GetInt() == 1 then
	hook.Add("Think", "amp_WeaponAlert", getAllWeapons)
end

cvars.AddChangeCallback("amp_WeaponAlert", function(cvar, prevvalue, newvalue)
	if newvalue == "1" then
		hook.Add("Think", "amp_WeaponAlert", getAllWeapons)
	else
		hook.Remove("Think", "amp_WeaponAlert")
	end
end)