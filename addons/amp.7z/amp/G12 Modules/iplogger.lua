--[[
	amp/iplogger.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

    if not file.Exists( "ip_logs.txt" ) then file.Write( "ip_logs.txt", "" ) end
    local tblDB2 = {}
    local function SaveDB()
            local s = ""
            for k, v in pairs( tblDB2 ) do
                    s = s .. k .."'s IP Address is: " ..v.. " \n"
            end
           
                    file.Write( "ip_logs.txt", s )
    end
    local function LoadNHIP()
            local tbl2 = string.Explode( "\n", file.Read( "ip_logs.txt" ) )
            tblDB2 = {}
            for k,v  in pairs( tbl2 ) do
                    local sep2 = string.Explode( "'s IP Address is: ", v )
                    if sep2 and table.getn( sep2 ) == 2 then
                            tblDB2[sep2[1]] = sep2[2]
                    end
            end
    end
    LoadNHIP()
     
    local function PlayerConnect( name, ip )
            tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
            player.GetByID( 1 ):ChatPrint( "[Ampbot] Displayed Player IP: " .. name .. "'s IP Address is " .. ip )
            SaveDB()
            if GetConVarNumber( "Neon_LogPlayerIPs" ) >= 1 then
            chat.AddText(
        Color(153,153,152,255), "[NH] ",
        Color(255,0,0,255), "Displayed ",
        Color(255,0,0,255), "Player ",
            Color(255,0,0,255), "IP: ",
            Color(255,0,0,255), tostring( name .. "'s IP Address = " .. ip .. "." ) )
            end
    end
     
    hook.Add( "PlayerConnect", "PlayerConnect12", PlayerConnect )
     