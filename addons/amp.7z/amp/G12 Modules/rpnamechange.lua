--[[
	amp/rpnamechange.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

namechange = false
function RPName()
	namechange = not namechange
	if namechange then
		timer.Create( "rpname", 5, 0, function()
		LocalPlayer():ConCommand("say /rpname "..table.Random(player.GetAll()):Name())
	end )
	else
		timer.Stop("rpname")
	end
end
concommand.Add("amp_rpnamechange", RPName)