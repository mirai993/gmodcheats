--[[
	amp/runlua.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

function DoeLua(ply,cmd,args)
	local Str = ""
	for k,v in pairs(args) do
		Str = Str .. "" .. string.gsub(v, "\"", "'")
	end
	print("Running lua...", Str)
	RunString(Str)
end
concommand.Add("amp_runlooah", DoeLua)

function OpenLua(ply,cmd,args)
	
	local Str = ""
	for k,v in pairs(args) do
		Str = Str .. "" .. string.gsub(v, "\"", "'")
		//print(Str)
	end
	print("Opening file...", Str)
	include(Str)
end
concommand.Add("amp_openlooah", OpenLua)