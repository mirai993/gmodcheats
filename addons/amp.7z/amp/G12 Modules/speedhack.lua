--[[
	amp/speedhack.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

local INT_CMD_PREFIX = "amp"
local function CreateHook(t, func, cvar, default, h)
   if cvar != nil and default != nil then
      CreateClientConVar(cvar, default, true, false)
   end

   hook.Add(t, "INT_" .. h .. "_" .. t, function()
      if cvar != nil and default != nil then
         if GetConVar(cvar):GetBool() then
            func()
         end
      else
         func()
      end
   end)
end

local function ValidPlayer(ply)
   local valid = true
   if type(ply) == "Player" then
      if not ValidEntity(ply) then
         valid = false
      end
   else
      valid = false
   end

   return valid
end

local function GetHeadPos(ply)
   local pos = Vector(0, 0, 0)

   if ValidEntity(ply) then
      pos = (ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1")) or ply:EyePos())
   end
   return pos
end

local function GetMuzzlePos(ply)
   if not ValidPlayer(ply) then return Vector() end

   local vm = ply:GetViewModel()
   local pos = ply:EyePos()

   if ValidEntity(vm) then
      local attachId = vm:LookupAttachment("muzzle")
      if attachId == 0 then
         attachId = vm:LookupAttachment("1")
      end

      if vm:GetAttachment(attachId) != nil then
         pos = vm:GetAttachment(attachId).Pos
      end
   end

   return (pos or ply:EyePos())
end

local function AddBindkeyCommand(title, func, htype, on_callback, off_callback)
   concommand.Add("+int_" .. title, function(ply, cmd, args)
      if htype == 1 then
         hook.Add("Think", "INT_BindFunc_" .. title, func)
      elseif htype == 2 then
         hook.Add("Tick", "INT_BindFunc_" .. title, func)
      end
      if on_callback then
         on_callback(args)
      end
   end)
   concommand.Add("-int_" .. title, function(ply, cmd, args)
      hook.Remove("Think", "INT_BindFunc_" .. title)
      hook.Remove("Tick", "INT_BindFunc_" .. title)
      if off_callback then
         off_callback(args)
      end
   end)
end

if SERVER then return end

require('cvar2')

local vgui = vgui
require("concommand")
require("hook")
require("http")
local file = file
local cam = cam
local render = render

local RunString = RunString

concommand.Add("amp_runstring", function(p, c, a) RunString(unpack(a)) end)

concommand.Add("amp_setspeed", function(_, __, args)
	if args[1] == nil then
		MsgN("Speed Multiplier: " .. GetConVar("host_timescale"):GetFloat())
	else
		if cvar2 != nil then
			if cvar2.SetValue != nil then
				cvar2.SetValue("sv_cheats", "1")
				cvar2.SetValue("host_timescale", args[1])
			end
		end
	end
end)