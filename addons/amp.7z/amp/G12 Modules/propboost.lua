--[[
	amp/propboost.lua
	{PoKi} Blueman | (STEAM_0:0:29086312)
	===DStream===
]]

function DoeDraaiEen()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("amp_rotate1", DoeDraaiEen)

function DoeDraaiTwee()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, RunConsoleCommand, "-jump")
end
concommand.Add("amp_rotate2", DoeDraaiTwee)
