--[[
	MOD/addons/Ampbot/lua/scripts/getinfo.lua
	FaZe Temperrr | STEAM_0:0:68368709 <146.135.46.64:27005> | [24-10-13 12:58:04PM]
	===BadFile===
]]

local function EntityInformation()
	local trace = LocalPlayer():GetEyeTrace()
	chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ),trace.Entity:GetClass())
	chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ),trace.Entity:GetModel())
	if trace.Hit and trace.Entity:IsValid() and string.find(string.lower(trace.Entity:GetClass()), "prop") then
		surface.PlaySound("modelfound.wav")
		chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ),trace.Entity:GetModel())
		chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ),trace.Entity:GetOwner())
		PrintTable(trace.Entity:GetTable())
	elseif trace.Hit and trace.Entity:IsValid() and trace.Entity:GetClass() == "player" then
		chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ), trace.Entity:Nick())
		chat.AddText(Color( 0,201,0,255 ), "[Ampbot] ", Color( 100, 100, 100 ), trace.Entity:GetActiveWeapon():GetPrintName())
		print("Admin?: ", trace.Entity:IsAdmin())
	end
end
concommand.Add("Ampbot_GetModel", EntityInformation)
