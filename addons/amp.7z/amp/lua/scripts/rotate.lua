--[[
	MOD/addons/Ampbot/lua/scripts/rotate.lua
	FaZe Temperrr | STEAM_0:0:68368709 <146.135.46.64:27005> | [24-10-13 12:58:05PM]
	===BadFile===
]]

local function Rotate180()
	Ampbot_NOAUTOPICKUP = true
	timer.Simple(0.5, function() Ampbot_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("Ampbot_180", Rotate180)

local function Rotate180Up()
	Ampbot_NOAUTOPICKUP = true
	timer.Simple(0.5, function() Ampbot_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
			RunConsoleCommand("+jump")
			timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p-a.p-a.p, a.y-180, a.r))
	RunConsoleCommand("+jump")
	timer.Simple(0.2, function() RunConsoleCommand("-jump") end)
end
concommand.Add("Ampbot_180up", Rotate180Up)

concommand.Add("Ampbot_180shot", function()
	local IsHook = hook.GetTable().CalcView and hook.GetTable().CalcView["180shot"]
	if IsHook then
		Rotate180()
		hook.Remove("CalcView", "180shot")
		timer.Destroy("180shot")
		return
	end

	hook.Add("CalcView", "180shot", function(ply, origin, angle, fov)
		local view = {}
		view.origin = origin
		view.angles = angle - Angle(0,180,0)
		view.fov = fov

		if not LocalPlayer():KeyDown(IN_ATTACK) then
			hook.Remove("CalcView", "180shot")
			Rotate180()
			timer.Destroy("180shot")
		end

		return view
	end)
	Rotate180()
	timer.Create("180shot", 5, 1, function()
		hook.Remove("CalcView", "180shot")
		Rotate180()
	end)
end)

local backwards = CreateClientConVar("Ampbot_backwards", 0, false, false)
local sensitivity
local FSetEyeAngles = debug.getregistry().Player.SetEyeAngles
local FGetEyeAngles = debug.getregistry().Player.EyeAngles
local eyeAng

local function overrideSetEyeAngle(ply, angle, ...)
	if (angle.p % 360) > 270 or (angle.p % 360) < 90 then
		angle.p = 180 - angle.p
		angle.y = 180 + angle.y
	end
	eyeAng = angle

	return FSetEyeAngles(ply, angle, ...)
end

local function overrideGetEyeAngles(ply, ...)
	if ply == LocalPlayer() then
		return Angle(180 - eyeAng.p, 180 + eyeAng.y, eyeAng.r)
	end

	return FGetEyeAngles(ply, ...)
end

local function mouseMovement(umc)
	local ang = Angle((eyeAng.p - umc:GetMouseY() / sensitivity) % 360, (eyeAng.y - umc:GetMouseX() / sensitivity) % 360, eyeAng.r)

	if ang.p > 270 or ang.p < 90 then
		umc:SetViewAngles(eyeAng)
		return
	end

	local weapon = LocalPlayer():GetActiveWeapon()

	if not IsValid(weapon) or weapon:GetClass() ~= "weapon_physgun" or not LocalPlayer():KeyDown(IN_USE) then
		eyeAng = ang
	end

	umc:SetViewAngles(eyeAng)
end

local function TurnVision(ply, origin, angles, fov)
	local view = {}

	view.origin = origin
	view.angles = angles

	if eyeAng.p < 270 or ang.p > 90 then
		view.angles.r = 180
	end

	return view
end

local function fixMovementKeys(ply, bind, pressed)
	if bind == "+moveright" and pressed then
		RunConsoleCommand("+moveleft")
		return true
	elseif bind == "+moveright" and not pressed then
		RunConsoleCommand("-moveleft")
		return true
	elseif bind == "+moveleft" and pressed then
		RunConsoleCommand("+moveright")
		return true
	elseif bind == "+moveleft" and not pressed then
		RunConsoleCommand("-moveright")
		return true
	end
end

local function doBackwards()
	eyeAng = LocalPlayer():EyeAngles()

	debug.getregistry().Player.SetEyeAngles = overrideSetEyeAngle
	debug.getregistry().Player.EyeAngles = overrideGetEyeAngles

	eyeAng.p = 180 - eyeAng.p
	eyeAng.y = 180 + eyeAng.y

	hook.Add("CreateMove", "Ampbot_backwards", mouseMovement)
	hook.Add("CalcView", "Ampbot_backwards", TurnVision)
	hook.Add("PlayerBindPress", "Ampbot_backwards", fixMovementKeys)
end

if tobool(backwards:GetInt()) then
	doBackwards()
end

cvars.AddChangeCallback("Ampbot_backwards", function(cvar, prevvalue, newvalue)
	sensitivity = GetConVarNumber("sensitivity") * 10

	if tobool(newvalue) then
		doBackwards()
	else
		hook.Remove("CreateMove", "Ampbot_backwards")
		hook.Remove("CalcView", "Ampbot_backwards")
		hook.Remove("PlayerBindPress", "Ampbot_backwards")

		debug.getregistry().Player.SetEyeAngles = FSetEyeAngles
		debug.getregistry().Player.EyeAngles = FGetEyeAngles

		local ang = eyeAng
		ang.p = 180 - ang.p
		ang.y = 180 + ang.y
		LocalPlayer():SetEyeAngles(ang)
	end
end)