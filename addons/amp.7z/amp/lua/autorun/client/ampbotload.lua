--[[
	MOD/addons/Ampbot/lua/autorun/client/ampbotload.lua
	FaZe Temperrr | STEAM_0:0:68368709 <146.135.46.64:27005> | [24-10-13 12:58:03PM]
	===BadFile===
]]

include( "ampbot/ampbot.lua" )
local cansay = true
Ampbot_CHATTIME = 1.6
local _R = debug.getregistry()

function Ampbot_DelayedSay(text)
	if cansay then
		local add = ""
		if OOC:GetInt() == 1 and GetGlobalInt("alltalk") == 0 then add = "/ooc " end
		local endresult = add.. tostring(text)
		if string.len(endresult) >= 126 then
			timer.Simple(1.62, function() Ampbot_DelayedSay(string.sub(endresult, 127)) end)
		end
		LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
		cansay = false
		timer.Simple(Ampbot_CHATTIME, function() cansay = true end)
	else
		timer.Simple(Ampbot_CHATTIME, function() Ampbot_DelayedSay(text) end)
	end
end
concommand.Add("_Ampbot_delayedsay", function(_,_,args) Ampbot_DelayedSay(table.concat(args, " ")) end)

local Ampbot_CHATCOMMANDS = {}

function Ampbot_addchatcmd(text, func)
	Ampbot_CHATCOMMANDS[text] = func
end

local function Ampbot_CHAT2(ply, text, teamonly, dead)
	if ply ~= LocalPlayer() then return end
	cansay = false
	timer.Simple(2.1, function() cansay = true end)
	for k,v in pairs(Ampbot_CHATCOMMANDS) do
		if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then
			v(string.sub(text, string.len(k) + 2))
			break
		elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
			v(string.sub(text, string.len(k) + 8))
		end
	end
end
hook.Add( "OnPlayerChat", "Ampbot_chatter", Ampbot_CHAT2)

local function ReloadScripts()
	include("autorun/client/Ampbotload.lua")
	hook.Call("InitPostEntity")
end
Ampbot_addchatcmd("Ampbot_ReloadScripts", ReloadScripts)
concommand.Add("Ampbot_ReloadScripts", ReloadScripts)

function fnotify(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if FPP then FPP.AddNotify(text, true) return end
	if GAMEMODE.IsSandboxDerived then 
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound("ambient/water/drip2.wav") 
	end
end

function Ampbot_FindPlayer(info)
	local pls = player.GetAll()

	for k, v in pairs(pls) do
		if tonumber(info) == v:UserID() then
			return v
		end
	end

	for k, v in pairs(pls) do
		if v.DarkRPVars and string.find(string.lower(v.DarkRPVars.rpname or ""), string.lower(tostring(info))) ~= nil then
			return v
		end
	end

	for k, v in pairs(pls) do
		if string.find(string.lower(v:Name()), string.lower(tostring(info))) ~= nil then
			return v
		end
	end
	return nil
end


hook.Add("OnPlayerChat", "Ampbot_chat", function(ply, text, teamonly, dead)
	if ply == LocalPlayer() and string.sub(text, 1,1) == ";" then
		RunString(string.sub(text, 2))
	end
end)

local files, folders = file.Find("lua/scripts/*.lua", "GAME")
for k, v in pairs(files) do
	include("scripts/" .. v)
end

local ENTITY = FindMetaTable("Entity")
ENTITY.oldgetattachment = ENTITY.oldgetattachment or ENTITY.GetAttachment
function ENTITY:GetAttachment(...)
	if not self.oldgetattachment then return {Pos = Vector(0,0,0)} end
	if self:GetClass() == "grapplehook" and not self:oldgetattachment(...) then return {Pos = Vector(0,0,0)} end
	return self:oldgetattachment(...)
end

hook.Add("InitPostEntity", "FixShit", function()
	if hook.GetTable().HUDPaint then hook.Remove("HUDPaint", "FlashEffect") end
	if hook.GetTable().RenderScreenspaceEffects then hook.Remove("RenderScreenspaceEffects", "StunEffect") end
end)


concommand.Add("wire_keyboard_press", function() end)


function debug.getupvalues(f)
	local t, i, k, v = {}, 1, debug.getupvalue(f, 1)
	while k do
		t[k] = v
		i = i+1
		k,v = debug.getupvalue(f, i)
	end
	return t
end


hook.Add("InitPostEntity", "PhysgunPickup", function()
	hook.Add("PhysgunPickup", "FPP_CL_PhysgunPickup", function(ply, ent)
		if not ent.IsMine then return false end
	end)

	usermessage.Hook("EV_Notification", function() end) -- Fucking adverts
	hook.Remove("HUDPaint", "UpdateTimeHUD") -- Fucking rank mod
end)

timer.Simple(10, function() concommand.Remove("DrawDeathMsg") end)


local oldChatAddText = chat.AddText
local oldChatPlaySound = chat.PlaySound

function chat.AddText(color, text, ...)
	if LANGUAGE and LANGUAGE.hints and table.HasValue(LANGUAGE.hints, text) then
		chat.PlaySound = function() end
		print("Blocked: ", text)
		return
	end
	chat.PlaySound = oldChatPlaySound
	oldChatAddText(color, text, ...)
end

timer.Simple(1, function() hook.Call("InitPostEntity") end)
