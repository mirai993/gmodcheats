--[[
	MOD/addons/Ampbot/lua/ampbot/ampbot.lua
	FaZe Temperrr | STEAM_0:0:68368709 <146.135.46.64:27005> | [24-10-13 12:58:03PM]
	===BadFile===
]]

CreateClientConVar("Ampbot_misc_logips",1,true,false)
CreateClientConVar("Ampbot_esp_2dbox",0,true,false)
CreateClientConVar("Ampbot_esp_3dbox",0,true,false)
CreateClientConVar("Ampbot_esp_2dbox_color_r",0,true,false)
CreateClientConVar("Ampbot_esp_2dbox_color_g",0,true,false)
CreateClientConVar("Ampbot_esp_2dbox_color_b",0,true,false)
CreateClientConVar("Ampbot_esp_3dbox_color_r",0,true,false)
CreateClientConVar("Ampbot_esp_3dbox_color_g",0,true,false)
CreateClientConVar("Ampbot_esp_3dbox_color_b",0,true,false)
CreateClientConVar("Ampbot_esp_crosshair_color_r",0,true,false)
CreateClientConVar("Ampbot_esp_crosshair_color_g",0,true,false)
CreateClientConVar("Ampbot_esp_crosshair_color_b",0,true,false)

local function IsisCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end

function TwoDBox()
if GetConVarNumber("Ampbot_esp_2dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local pos = ply:GetPos();
local width = 32;
local height = 80;
local scale = 1;
local BoxColor = Color(GetConVarNumber("Ampbot_esp_2dbox_color_r"),GetConVarNumber("Ampbot_esp_2dbox_color_g"),GetConVarNumber("Ampbot_esp_2dbox_color_b"),255)
local ang = EyeAngles();
ang.p = ang.p - 90;
pos = pos - (ang:Right() * (width / 2))
cam.Start3D2D(pos, ang, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("HUDPaint", TwoDBox)


local function DrawBoundingBox()
if GetConVarNumber("Ampbot_esp_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(GetConVarNumber("Ampbot_esp_3dbox_color_r"),GetConVarNumber("Ampbot_esp_3dbox_color_g"),GetConVarNumber("Ampbot_esp_3dbox_color_b"),255)

local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();

local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();


local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("RenderScreenspaceEffects", DrawBoundingBox)

 
    local Ampbot                                 = {}
    Ampbot.settings                              = {}
    Ampbot.hooks                                 = {} 
    Ampbot.concommands                   = {} 
    Ampbot.convars                               = {}
    Ampbot.timers                                        = {} 
    Ampbot.cones                                 = { normal = {}, hl2 = {}, custom = {}} 
    Ampbot.meta                                  = {} 
    Ampbot.files                                 = {"Ampbot.lua","Log.txt"}
    Ampbot.version                               = " " 
    Ampbot.ents                                  = {"money_printer", "vip_trigger_money_printer", "trigger_money_printer", "vip_nuclear_money_printer", "nuclear_money_printer", "sapphire_money_printer", "robin_money_printer", "vip_robin_money_printer", "ent_mad_grenade", "nuke_equipment", "ent_mad_c4", "ph_prop", "drug_plant","ent_pot","npc_vendor","weapon_perp_glock","ent_item","ent_prop_item","sent_spawnpoint","spawned_weapon","spawned_shipment","weed_plant","gift","spawned_money","base_item","weapon_ak47_dayz","weapon_mp5_dayz","weapon_deagle_dayz","sapphire_money_printer","amethyst_money_printer","topaz_money_printer","emerald_money_printer"}
    Ampbot.invalidents                   = {"player","prop_physics","viewmodel",} 
    Ampbot.weapons                               = {["weapon_crossbow"] = 3110,}
    Ampbot.spectators                            = {} 
    Ampbot.admins                                        = {} 
     
    local colors                            = {}
    red                                                     = Color(255,0,0,255);
    black                                           = Color(0,0,0,255);
    green                                           = Color(0,201,0,255);
    white                                           = Color(255,255,255,255);
    blue                                            = Color(0,0,255,255);
    cyan                                            = Color(0,255,255,255);
    pink                                            = Color(255,0,255,255);
    blue                                            = Color(0,0,255,255);
    grey                                            = Color(100,100,100,255);
    gold                                            = Color(255,228,0,255);
    lblue                                           = Color(155,205,248);
    lgreen                                          = Color(174,255,0);
    iceblue                                         = Color(116,187,251,255);
     
    local _G                                        = table.Copy(_G)
     
    local math                                      = _G.math
    local string                            = _G.string
    local hook                                      = _G.hook
    local table                             = _G.table
    local timer                             = _G.timer
    local surface                           = _G.surface
    local concommand                        = _G.concommand
    local cvars                             = _G.cvars
    local ents                                      = _G.ents
    local player                            = _G.player
    local team                                      = _G.team
    local util                                      = _G.util
    local draw                                      = _G.draw
    local usermessage                       = _G.usermessage
    local vgui                                      = _G.vgui
    local http                                      = _G.http
    local cam                                       = _G.cam
    local render                            = _G.render
     
    local MsgN                                      = _G.MsgN
    local Msg                                       = _G.Msg
    local Vector                            = _G.Vector
    local Angle                             = _G.Angle
    local pairs                             = _G.pairs
    local ipairs                            = _G.ipairs
    local CreateSound                       = _G.CreateSound
    local setmetatable                      = _G.setmetatable
    local Sound                             = _G.Sound
    local print                             = _G.print
    local pcall                             = _G.pcall
    local type                                      = _G.type
    local LocalPlayer                       = _G.LocalPlayer
    local KeyValuesToTable          = _G.KeyValuesToTable
    local TableToKeyValues          = _G.TableToKeyValues
    local Color                             = _G.Color
    local CreateClientConVar        = _G.CreateClientConVar
    local ErrorNoHalt                       = _G.ErrorNoHalt
    local IsValid                           = _G.IsValid
    local CreateMaterial            = _G.CreateMaterial
    local tonumber                          = _G.tonumber
    local tostring                          = _G.tostring
    local CurTime                           = _G.CurTime
    local FrameTime                         = _G.FrameTime
    local ScrW                                      = _G.ScrW
    local ScrH                                      = _G.ScrH
    local SetClipboardText          = _G.SetClipboardText
    local GetHostName                       = _G.GetHostName
    local unpack                            = _G.unpack
    local AddConsoleCommand         = _G.AddConsoleCommand
    local require                           = _G.require
    local include                           = _G.include
     
    local MOVETYPE_OBSERVER         = _G.MOVETYPE_OBSERVER
    local MOVETYPE_NONE             = _G.MOVETYPE_NONE
    local TEXT_ALIGN_LEFT           = _G.TEXT_ALIGN_LEFT
    local TEXT_ALIGN_TOP            = _G.TEXT_ALIGN_TOP
    local TEXT_ALIGN_RIGHT          = _G.TEXT_ALIGN_RIGHT
    local TEXT_ALIGN_BOTTOM         = _G.TEXT_ALIGN_BOTTOM
    local IN_JUMP                           = _G.IN_JUMP
    local IN_FORWARD                        = _G.IN_FORWARD
    local IN_BACK                           = _G.IN_BACK
    local IN_MOVERIGHT                      = _G.IN_MOVERIGHT
    local IN_MOVELEFT                       = _G.IN_MOVELEFT
    local IN_SPEED                          = _G.IN_SPEED
    local IN_DUCK                           = _G.IN_DUCK
    local TEAM_SPECTATOR            = 1002
     
    -- old [detour]
    local old_filecdir                      = file.CreateDir;
    local old_filedel                       = file.Delete;
    local old_fileexist             = file.Exists;
    local old_fileexistex           = file.ExistsEx;
    local old_filefind                      = file.Find;
    local old_filefinddir           = file.FindDir;
    local old_filefindil            = file.FindInLua;
    local old_fileisdir                     = file.IsDir;
    local old_fileread                      = file.Read;
    local old_filerename            = file.Rename;
    local old_filesize                      = file.Size;
    local old_filetfind                     = file.TFind;
    local old_filetime                      = file.Time;
    local old_filewrite             = file.Write;
    local old_dbginfo                       = debug.getinfo;
    local old_dbginfo                       = debug.getupvalue;
    local old_cve                           = ConVarExists;
    local old_gcv                           = GetConVar;
    local old_gcvn                          = GetConVarNumber;
    local old_gcvs                          = GetConVarString;
    local old_rcc                           = RunConsoleCommand;
    local old_hookadd                       = hook.Add;
    local old_hookrem                       = hook.Remove;
    local old_ccadd                         = concommand.Add;
    local old_ccrem                         = concommand.Remove;
    local old_cvaracc                       = cvars.AddChangeCallback;
    local old_cvargcvc                      = cvars.GetConVarCallbacks;
    local old_cvarchange            = cvars.OnConVarChanged;
    local old_require                       = require;
    local old_eccommand             = engineConsoleCommand;
     
Ampbot.bones					= {
{"Head", "ValveBiped.Bip01_Head1"},
{"Neck", "ValveBiped.Bip01_Neck1"},
{"Spine", "ValveBiped.Bip01_Spine"},
{"Spine1", "ValveBiped.Bip01_Spine1"},
{"Spine2", "ValveBiped.Bip01_Spine2"},
{"Spine4", "ValveBiped.Bip01_Spine4"},
{"Pelvis", "ValveBiped.Bip01_Pelvis"},
{"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
{"R Forearm", "ValveBiped.Bip01_R_Forearm"},
{"R Hand", "ValveBiped.Bip01_R_Hand"},
{"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
{"L Forearm", "ValveBiped.Bip01_L_Forearm"},
{"L Hand", "ValveBiped.Bip01_L_Hand"},
{"R Thigh", "ValveBiped.Bip01_R_Thigh"},
{"R Calf", "ValveBiped.Bip01_R_Calf"},
{"R Foot", "ValveBiped.Bip01_R_Foot"},
{"R Toes", "ValveBiped.Bip01_R_Toe0"},
{"L Calf", "ValveBiped.Bip01_L_Calf"},
{"L Foot", "ValveBiped.Bip01_L_Foot"},
{"L Toes", "ValveBiped.Bip01_L_Toe0"},
}

Ampbot.aimmodels = {
["models/combine_scanner.mdl"] = "Scanner.Body",
["models/hunter.mdl"] = "MiniStrider.body_joint",
["models/combine_turrets/floor_turret.mdl"] = "Barrel",
["models/dog.mdl"] = "Dog_Model.Eye",
["models/antlion.mdl"] = "Antlion.Body_Bone",
["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrabblack.mdl"] = "HCBlack.body",
["models/headcrab.mdl"] = "HCFast.body",
["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
}
Ampbot.prediction				= {
["weapon_crossbow"] = 3485,
["weapon_pistol"] = 40000,
["weapon_357"] = 20500,
["weapon_smg"] = 39000,
["weapon_ar2"] = 39000,
["weapon_shotgun"] = 35000,
["weapon_rpg"] = 0,	
}
	 
    surface.CreateFont("ESPFont",{font = "Default", size = 17, weight = 500, antialias = 0})
    surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 500, antialias = 0})
    surface.CreateFont("Logo",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
    surface.CreateFont("Ampbot_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
    surface.CreateFont("Ampbot_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
    surface.CreateFont("Ampbot_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
     
    function Ampbot:CreateMaterial()
    local BaseInfo = {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"]       = 1,
    ["$translucent"] = 1,
    ["$alpha"]       = 1,
    ["$nocull"]      = 1,
    ["$ignorez"]     = 1
    }      
    local mat      
    if GetConVarString("Ampbot_esp_Chams_Material") == "Solid" then
            mat = CreateMaterial( "Ampbot_solid", "VertexLitGeneric", BaseInfo )
    elseif GetConVarString("Ampbot_esp_Chams_Material") == "Wireframe" then
            mat = CreateMaterial( "Ampbot_wire", "Wireframe", BaseInfo )
    end
       return mat 
    end
     
    function Log(msg)
    file.Append("Ampbot/log.txt","["..os.date().."]: "..msg.."\n")
    end
    Log("Loading....")
     
function Ampbot:AddCMD(Name,Function)
	return old_ccadd(Name,Function)
end

function Ampbot:RemoveCMD(Name)
	table.Empty(Ampbot.concommands)
	return old_ccrem(Name)
end

function Ampbot:RegisterHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	table.insert(Ampbot.hooks,Name)
	return old_hookadd(Type,Name,Function)
end

function Ampbot:RemoveHook(Type,Function)
	return old_hookrem(Type,Function)
end

    function Ampbot.Print(msg)
            print("[Ampbot] "..msg)
    end
     
    function Ampbot.Notify(dosound,col,msg)
            if col then
                    col = col
            end
    chat.AddText(
    green, "[Ampbot] ",
    col, msg)
            if dosound == sound then
                    local beep = Sound( "/buttons/button17.wav" )
                    local beepsound = CreateSound( LocalPlayer(), beep )
                    beepsound:Play()
            end
    end
     
     
    local function AddHook(Type,Function)
            Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
            return old_hookadd(Type,Name,Function)
    end
     
    local function RemoveHook(Type,Function)
            return old_hookadd(Type,Function)
    end

    function AddFile(Name,Data)
            Ampbot.Print("[WROTE] File: "..Name.."")
            return old_filewrite(Name,Data)
    end
     

    function RandomString( len )
            local ret = ""
                    for i = 1 , len do
                            ret = ret .. string.char( math.random( 65 , 116 ) )
            end
            return ret
    end
     
    function AddTimer( sec, rep, func )
            local index = RandomString( 10 )       
            Ampbot.timers[ index ] = sec
            timer.Create( index, sec, rep, func )
    end
     
     
    function AddCMD(Name,Function)
            return old_ccadd(Name,Function)
    end
     
    function RemoveCMD(Name)
            return old_ccrem(Name)
    end
     
     
    function AddConVar(convar,str,save,data)
            return CreateClientConVar("Ampbot_"..convar,str,true,false)
    end
     
    function AddEnt(entclass)
            if(!table.HasValue(Ampbot.ents,entclass)) then
                    table.insert(Ampbot.ents,entclass)
                    Ampbot.Print("[ADDED] Ent: "..entclass.." to ESP")
                    file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
            end
    end

    function RemoveEnt(entclass)
            for k, v in pairs(Ampbot.ents) do
                    if(string.Trim(v) == entclass) then
                            Ampbot.ents[k] = nil
                            Ampbot.Print("[REMOVED] Ent: "..entclass.." from the ESP")
                    end
            end
            file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
    end

    function ClearEnts()
            Ampbot.ents = {}
            file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
    end

    function IsCustomEnt( entclass )
            return table.HasValue( Ampbot.ents, entclass )
    end
     
    function AddCheckBox( text, cvar, parent, x, y, tt )
    local checkbox = vgui.Create( "DCheckBoxLabel", parent )
    checkbox:SetPos( x, y )
    checkbox:SetText( text )
    checkbox:SetConVar( cvar )
    checkbox:SetTextColor(white)
    checkbox:SetTooltip( tt or "No Tool Tip" )
    checkbox:SizeToContents()      
    end
     
    function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
    local slider = vgui.Create( "DNumSlider" )
    slider:SetParent( parent )
    slider:SetPos( x, y )
    slider:SetWide( wide )
    slider:SetText( text )

    slider:SetMin( min )
    slider:SetMax( max )
    slider:SetDecimals( decimals )
    slider:SetConVar( cvar )
    slider:SetTooltip( tt or "No Tool Tip" )
    end
     
    Gradient = surface.GetTextureID( "gui/gradient" )
    function DrawBox( x, y, wide, tall, dropsize )
            draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
            draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
    end
     
    function CreatePos(v)
    local ply = LocalPlayer()
    local center = v:LocalToWorld( v:OBBCenter() )
    local min, max = v:OBBMins(), v:OBBMaxs()
    local dim = max - min   local z = max + min    
    local frt       = ( v:GetForward() ) * ( dim.y / 2 )
    local rgt       = ( v:GetRight() ) * ( dim.x / 2 )
    local top       = ( v:GetUp() ) * ( dim.z / 2 )
    local bak       = ( v:GetForward() * -1 ) * ( dim.y / 2 )
    local lft       = ( v:GetRight() * -1 ) * ( dim.x / 2 )
    local btm       = ( v:GetUp() * -1 ) * ( dim.z / 2 )
    local s = 1
    local FRT       = center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
    local BLB       = center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
    local FLT       = center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
    local BRT       = center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
    local BLT       = center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
    local FRB       = center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
    local FLB       = center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
    local BRB       = center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()   
    local z = 100
    if ( v:Health() <= 50 ) then z = 100 end
    local x, y = ( ( v:Health() / 100 ) ), 1
    if ( v:Health() <= 0 ) then x = 1 end
    local FRT3      = center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
    local BLB3      = center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
    local FLT3      = center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
    local BRT3      = center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
    local BLT3      = center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
    local FRB3      = center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
    local FLB3      = center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
    local BRB3      = center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()    
    local x, y, z = 1.1, 0.9, 1
    local FRT2      = center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
    local BLB2      = center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
    local FLT2      = center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
    local BRT2      = center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
    local BLT2      = center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
    local FRB2      = center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
    local FLB2      = center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
    local BRB2      = center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen() 
    local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
    local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )     
    local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
    end

    local function CanSee(ply)
        local trace = {start = LocalPlayer():GetShootPos(),endpos = {}}
        local tr = util.TraceLine(trace)
        if tr.Fraction == 1 then
            return true
        else
            return false
        end    
    end
     

    local function GetColorCrosshair()
            if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
                    return 0,255,0,255
            end
            if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
                    return 0,0,255,255
            end
            return Color(GetConVarNumber("Ampbot_esp_crosshair_color_r"),GetConVarNumber("Ampbot_esp_crosshair_color_g"),GetConVarNumber("Ampbot_esp_crosshair_color_b"),255)
    end
     
    local function GetColorVisible(e)
            if CanSee(e) then
                    return 0,255,0,255
            end
            if !CanSee(e) then
                    return 255,0,0,255
            end
    end
     
    function CommaValue(amount)
            local formatted = amount
            while true do  
                    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
                    if (k==0) then
                            break
                    end
            end
            return formatted
    end
     
    function RoundNum(val, decimal)
            if (decimal) then
                    return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
            else
                    return math.floor(val+0.5)
            end
    end
     
    function FormatNum(amount, decimal, prefix, neg_prefix)
            local str_amount,  formatted, famount, remain
            decimal = decimal or 2
            neg_prefix = neg_prefix or "-"
            famount = math.abs(RoundNum(amount,decimal))
            famount = math.floor(famount)
            remain = RoundNum(math.abs(amount) - famount, decimal)
            formatted = CommaValue(famount)
            if (decimal > 0) then
                    remain = string.sub(tostring(remain),3)
                    formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
            end
            formatted = (prefix or "") .. formatted
            if (amount<0) then
                    if (neg_prefix=="()") then
                            formatted = "("..formatted ..")"
                    else
                            formatted = neg_prefix .. formatted
                    end
            end
            return formatted
    end
     
    function ConvertTime(sSeconds)
            local nSeconds = tonumber(sSeconds)
            if nSeconds <= 0 then
                            return 0;
                    else
                            local nHours = string.format("%02.f", math.floor(nSeconds/3600));
                            local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
                            local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
                    if tonumber( nHours ) > 0 then
                            return nHours..":"..nMins..":"..nSecs
                    elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
                            return nMins..":"..nSecs
                    elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
                            return nMins..":"..nSecs
                    end
            end
    end

    function Ampbot.DrawText( text, font, x, y, colour, xalign, yalign )
            if (font == nil) then font = "Default" end
            if (x == nil) then x = 0 end
            if (y == nil) then y = 0 end   
            local curX = x
            local curY = y
            local curString = ""   
            surface.SetFont(font)
            local sizeX, lineHeight = surface.GetTextSize("\n")    
            for i=1, string.len(text) do
                    local ch = string.sub(text,i,i)
                    if (ch == "\n") then
                            if (string.len(curString) > 0) then
                                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
                            end                    
                            curY = curY + (lineHeight/2)
                            curX = x
                            curString = ""
                    elseif (ch == "\t") then
                            if (string.len(curString) > 0) then
                                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
                            end
                            local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
                            curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
                            curString = ""
                    else
                            curString = curString .. ch
                    end
            end    
            if (string.len(curString) > 0) then
                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
            end
    end
     
    local function FillRGBA(x,y,w,h,col)
        surface.SetDrawColor( col.r, col.g, col.b, col.a );
        surface.DrawRect( x, y, w, h );
    end
     
    local function OutlineRGBA(x,y,w,h,col)
        surface.SetDrawColor( col.r, col.g, col.b, col.a );
        surface.DrawOutlinedRect( x, y, w, h );
    end

    function Ampbot.IsVehicle( e )      
            local ply = LocalPlayer()      
            if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
                    return true
            end
            return false
    end

    function SetColors(e)
            local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
            local col      
            if ( e:IsPlayer() ) then
                    col = Color(0,255,0,255)
            elseif ( e:IsNPC() ) then
                    col = Color( 255, 0, 0, 20 )           
            elseif IsCustomEnt( e:GetClass() ) then
                    col = Color( 0, 200, 255, 50 )         
            else
                    col = Color( 255, 255, 255, 255 )              
            end    
            return col
    end

    AddConVar("esp_info",0)
    AddConVar("esp_skeleton",0)
    AddConVar("esp_tracer",0)
    AddConVar("esp_crosshair",0)
    AddConVar("esp_chams",0)
    AddConVar("esp_chams_material","Solid")
    AddConVar("esp_ents",0)
    AddConVar("esp_distance",1000)
    AddConVar("esp_info_type","info")
	 
    AddConVar("misc_bunnyhop",0)
    AddConVar("misc_ttt",0)
    AddConVar("misc_chatspam",0)
    AddConVar("misc_chatSpam_msg"," ")
    AddConVar("misc_cmdspam",0)
    AddConVar("misc_cmdspam_Msg"," ")
    AddConVar("misc_antiafk",0)
    AddConVar("misc_rpgod",0)
    AddConVar("misc_showspec",0)
    AddConVar("misc_showadmins",0)
          
	AddConVar("aim_friendly",0)
	AddConVar("aim_steam",0)
	AddConVar("aim_admins",0)
	AddConVar("aim_auto",0)
	AddConVar("aim_noRecoil",0)
	AddConVar("aim_offset",0)
	AddConVar("aim_aimSpot","Head")
	AddConVar("aim_trigger",0)
	AddConVar("aim_sh",0)
	AddConVar("aim_anti",0)
	AddConVar("aim_anti_type","Invert")
	AddConVar("aim_anti_angle_x","-181")
	AddConVar("aim_anti_angle_z","180")
	AddConVar("aim_antisnap",0)
	AddConVar("aim_antiSnap_speed",5)
	AddConVar("aim_fov",180)
	AddConVar("aim_reload",0)
	AddConVar("aim_targetbones",0)
	AddConVar("aim_checklos",0)
	AddConVar("aim_ignorenowep",0)
	AddConVar("aim_prediction",0)
	AddConVar("aim_spawnsrotection",0)
	AddConVar("misc_rapidfire",0)
	AddConVar("aim_method","Distance")
	AddConVar("aim_silent",0)
	AddConVar("aim_aaa",0)
     
    
     
    AddCMD("_ents",function()
    PrintTable(ents.GetAll())
    end)
     
    AddCMD("_players",function()
    PrintTable(player.GetAll())
    end)

function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Ampbot_esp_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
local mat = Ampbot:CreateMaterial()
	if GetConVarNumber("Ampbot_esp_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = team.GetColor(v:Team())
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then

			cam.Start3D(EyePos(),EyeAngles())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end


local IsLock = false;

function DoChecksRadar( e )
	local ply, val = LocalPlayer(), 0	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end	
	return true	
end

local RRadar

function Radar()	
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 250, 250 )	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 0.1, sH - rH - ( sH - rH ) + 30 )
	Radar:SetTitle( " " )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 2, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		local ply = LocalPlayer()		
		local radar = {}
		radar.h		= 250
		radar.w		= 250
		radar.org	= 1000		
		local x, y = ScrW() / 2, ScrH() / 2		
		local half = rH / 2
		local xm = half
		local ym = half		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 100 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )								
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )			
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )				
				local text = e:GetClass()				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				elseif ( e:IsNPC() ) then
					text = ""
				elseif (IsCustomEnt(e:GetClass())) then
					text = "Logo"
				end					
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then				
					draw.RoundedBox( s, posX, posY, s, s, color )
					Ampbot.DrawText(
						text,
						"Logo",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )	
	RRadar = Radar
concommand.Add("Ampbot_misc_radar_on",function() Radar:SetVisible(true) end)
concommand.Add("Ampbot_misc_radar_off",function() Radar:SetVisible(false) end)
end
Radar()

function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "None/Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local hvhpos = ( e:GetPos() + Vector( 0, 0, 130 ) ):ToScreen();
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
					end
				end
			end
		end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )

if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined(" ","Logo",1285,15,Color(2,0,0,255),4,1,1,red)
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:Alive() != nil then
								if (GetConVarNumber("Ampbot_esp_Info") == 1 && GetConVarString("Ampbot_esp_Info_Type") == "info") then
									draw.SimpleTextOutlined( Name, "Ampbot_coolvetica", maxX2, minY2 - 30, TeamColor, 4, 0, 1,Color(0,0,0))
									draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 - 15, HPColor, 0, 1, 0.7, black )
									draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 - 5, gold, 0, 1, 0.7, black )
									draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 5, iceblue, 0, 1, 0.7, black)
									if e:GetFriendStatus() == "friend" then
										draw.SimpleTextOutlined( "[FRIEND]", "ESPFont_Small", maxX2 - 45, minY2 - 30, iceblue, 0, 0, 0, black)
									end
										if e:IsSuperAdmin() then
											draw.SimpleText("[SUPERADMIN]","ESPFont_Small",maxX2,minY2 -40,iceblue,0, 0, 0.7, black)
										elseif e:IsAdmin() then
											draw.SimpleText("[ADMIN]","ESPFont_Small",maxX2,minY2 -40,iceblue,0, 0, 0.7, black)
										end
								elseif GetConVarString("Ampbot_esp_Info_Type") == "hvh" then
									draw.SimpleTextOutlined(e:Nick().." ["..e:Health().."]","Default",hvhpos.x,hvhpos.y,TeamColor,4,.5,.5,black,TEXT_ALIGN_CENTER)
								end

							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Ampbot_esp_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							if GetConVarNumber("Ampbot_esp_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							if GetConVarNumber("Ampbot_esp_Crosshair") == 1 then
								local x, y = ScrW() / 2, ScrH() / 2	
								local Speed = 0
								surface.SetDrawColor(GetColorCrosshair()) 
								CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
								CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
								mathsin = math.sin(CurTime()*Speed)*2
								mathcos = math.cos(CurTime()*Speed)*2
								mathsin2 = math.sin(CurTime()*Speed+0.1)*2
								mathcos2 = math.cos(CurTime()*Speed+0.1)*2
								mathsin3 = math.sin(CurTime()*Speed-0.1)*2
								mathcos3 = math.cos(CurTime()*Speed-0.1)*2
								surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*12,CHPosy+mathsin*12 );
								surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*12,CHPosy-mathsin*12 );
								surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*12,CHPosy-mathcos*12 );
								surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*12,CHPosy+mathcos*12 );
							end
						end
					end
				end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Ampbot_esp_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(""..wname.."", "Logo", entpos.x + 50, entpos.y - 25, color_red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
				surface.SetDrawColor(0,204,0,255)
				surface.DrawLine(entpos.x,entpos.y,entpos.x,entpos.y-10)
				surface.DrawLine(entpos.x,entpos.y,entpos.x+10,entpos.y)
			end
		end                    
	end
end 
     
    local Tb  = table.Copy( file )
    local Tbs = table.Copy( string )
    local Uw = {}
    local Mw = {}
    local function PlyPos( ply )
    local min = ply:OBBMins()
    local max = ply:OBBMaxs()
           
    local Spots = {
            Vector( min.x, min.y, min.z ),
            Vector( min.x, min.y, max.z ),
            Vector( min.x, max.y, min.z ),
            Vector( min.x, max.y, max.z ),
            Vector( max.x, min.y, min.z ),
            Vector( max.x, min.y, max.z ),
            Vector( max.x, max.y, min.z ),
            Vector( max.x, max.y, max.z )
    }      
    local minX = ScrW() * 2
    local minY = ScrH() * 2
    local maxX = 0
    local maxY = 0
     
            for k,v in pairs( Spots ) do
            local ToScreen = ply:LocalToWorld( v ):ToScreen()
            minX = math.min( minX, ToScreen.x )
            minY = math.min( minY, ToScreen.y )
            maxX = math.max( maxX, ToScreen.x )
            maxY = math.max( maxY, ToScreen.y )
            end
            return minX, minY, maxX, maxY
    end


local shouldFire = 0
function RapidFire()
	if GetConVarNumber("Ampbot_misc_RapidFire") == 1 and input.IsMouseDown(MOUSE_LEFT) then
		if shouldFire == 0 then
			shouldFire = 1
		else 
			shouldFire = 0
		end
		if shouldFire == 0 then
			old_rcc("+attack")
		else
			old_rcc("-attack")
		end
		elseif shouldFire == 0 then
			old_rcc("-attack")
		if shouldFire == 0 then
			shouldFire = 1
		else
			shouldFire = 0

		end
	end
end

function IsSpawnProtected(ent)
	if ((GAMEMODE.Name):lower()):find("stronghold") then
		local entcol = ent:GetColor(r, g, b, a)
		if entcol.a < 255 then
			return true
		else
			return false
		end
	end
end

function AimSpot(ent)
	if GetConVarNumber("Ampbot_aim_TargetBones") == 0 then
		local eyes = ent:LookupAttachment("eyes")
		if GetConVarNumber("Ampbot_aim_AAA") == 1 and (ent:EyeAngles().p < -89) then
			return ent:LocalToWorld( ent:OBBCenter())
		elseif(eyes ~= 0) then
			eyes = ent:GetAttachment(eyes)
			if(eyes and eyes.Pos) then
				return eyes.Pos, eyes.Ang
			end
		end
	end

local bonename = Ampbot.aimmodels[ent:GetModel()]
	if(not bonename) then
		for k, v in pairs(Ampbot.bones) do
			if(v[1] == GetConVarString("Ampbot_aim_AimSpot")) then
				bonename = v[2]
			end
		end
		bonename = bonename or "ValveBiped.Bip01_Head1"
	end
	local aimbone = ent:LookupBone(bonename);
	if(aimbone) then
		local pos, ang = ent:GetBonePosition(aimbone)
		return pos, ang;
	end
return ent:LookupBone("ValveBiped.Bip01_Head1")
end

function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("Ampbot_aim_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end 
	if (ent:IsPlayer() and (ent:IsAdmin() or ent:IsSuperAdmin()) and GetConVarNumber("Ampbot_aim_Admins") == 0) then return false end	
	if (GetConVarNumber("Ampbot_aim_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
	if (GetConVarNumber("Ampbot_aim_SH") == 1 && IsSpawnProtected(ent)) then return false end
	if (ent:IsPlayer() and GetConVarNumber("Ampbot_aim_IgnoreNoWep") == 1 and not IsValid(ent:GetActiveWeapon())) then return false end
	if (GetConVarNumber("Ampbot_aim_SpawnProtection") == 1 and ent:GetColor(r, g, b, a).a < 255) then return false end
return true
end

function HasLOS(ent)
	if(GetConVarNumber("Ampbot_aim_CheckLOS") == 0) then return true end
	local trace = util.TraceLine( {
		start = LocalPlayer():GetShootPos(),
		endpos = AimSpot(ent),
		filter = { LocalPlayer(), e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if (( trace.Fraction >= 0.99 )) then return true end
	return false
end

function InFov( ent )
	local fov = GetConVarNumber("Ampbot_aim_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

function AimPrediction( pos , pl )
	if IsValid( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon and ( IsValid( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )	
		if weapon and Ampbot.prediction[ weapon ] then
			local time = distance / Ampbot.prediction[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

function NormalizeAng(angle)
	if type(angle) == "Angle" then
		return Angle(math.NormalizeAngle(angle.p) , math.NormalizeAngle(angle.y) , math.NormalizeAngle(angle.r))
	end
	return angle
end

function GetTargets()
local target;
if target == nil then target = LocalPlayer() else target = target end
local ply = LocalPlayer()
local angA, angB = 0
local x, y = ScrW(), ScrH()
local distance = math.huge;
	for k, v in pairs(player.GetAll()) do
		if (v != LocalPlayer() and v:Alive() and HasLOS(v) and Exception(v) and InFov(v)) then
			local ePos, oldPos, myAngV = v:EyePos():ToScreen(), target:EyePos():ToScreen(), ply:GetAngles()
			local thedist = v:GetPos():DistToSqr(LocalPlayer():GetPos());
			angA = math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
			angB = math.Dist( x / 2, y / 2, ePos.x, ePos.y )
			if GetConVarString("Ampbot_aim_method") == "Closest To Crosshair" then
				if ( angB <= angA ) then
					target = v;
				elseif target == ply then
					target = v;
				end
			elseif GetConVarString("Ampbot_aim_method") == "Distance" then
				if (thedist < distance) then
					distance = thedist;
					target = v;
				end					
			end
		end
	end
return target
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("Ampbot_aim_AntiSnap_Speed") / 10
local aimang = Angle(0,0,0)
	if Aimon == 1 then		
		local target = GetTargets()
		if target != nil and target != LocalPlayer() then
	
		local Aimspot;
		if GetConVarNumber("Ampbot_aim_Prediction") == 1 then
			Aimspot = AimPrediction(AimSpot(target)) - Vector(0,0,GetConVarNumber("Ampbot_aim_Offset"))
			Aimspot = Aimspot + target:GetVelocity() * ( 1 / 66 ) - LocalPlayer():GetVelocity() * ( 1 / 66 )
		else
			Aimspot = (AimSpot(target)) - Vector(0,0,GetConVarNumber("Ampbot_aim_Offset"))
			Aimspot = Aimspot + target:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
		end
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		if GetConVarNumber("Ampbot_aim_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			aimang = Angle (Smooth1, Smooth2, 0)
		else
			aimang = Angle( Angel.p, Angel.y, 0 )
		end
			_G.debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, aimang)
			if GetConVarNumber("Ampbot_aim_Auto") == 1 then
               ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("Ampbot_aim_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

Ampbot:AddCMD("+Ampbot_Aim",function()
Aimon = 1
end)

Ampbot:AddCMD("-Ampbot_Aim",function()
Aimon = 0
end)

Ampbot:RegisterHook("CreateMove",function(cmd, u)
local caim
local getangs = cmd:GetViewAngles()
	if GetConVarNumber("Ampbot_aim_Anti") == 1 then
		if GetConVarString("Ampbot_aim_Anti_Type") == "Invert" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(181, getangs.y, 180))
			end
		elseif GetConVarString("Ampbot_aim_Anti_Type") == "Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = Angle(0,math.random(-89,89),0) 
				cmd:SetViewAngles(NormalizeAng(caim))
			end
		elseif GetConVarString("Ampbot_aim_Anti_Type") == "Random Pitch" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(math.random(181,180), getangs.y, 180))
			end	
		elseif GetConVarString("Ampbot_aim_Anti_Type") == "Invert/Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = math.random(-89,89)
				cmd:SetViewAngles(Angle(181, NormalizeAng(caim), 180))
			end
		elseif GetConVarString("Ampbot_aim_Anti_Type") == "Var" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				cmd:SetViewAngles(Angle(GetConVarNumber("Ampbot_aim_Anti_Angle_X"),getangs.y,GetConVarNumber("Ampbot_aim_Anti_Angle_Z")))
			end
		end
	end
end)

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun", "weapon_keys", "weapon_pocket", "pocket", "rp_pocket", "rp_keys", "keys"}
function AutoReload()
    if (GetConVarNumber("Ampbot_aim_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			old_rcc( "+reload" )
			LastReload = CurTime()
			Ampbot:AddTimer( .2, 1, function()
				old_rcc( "-reload" )
			end )
		end
    end
end

local function StartFire()
	old_rcc("+attack")
end

local function StopFire()
	old_rcc("-attack")
end
function TriggerBot()
	if(GetConVarNumber("Ampbot_aim_Trigger") == 1) then
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {};
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
			target = trace.Entity
			if(target:IsPlayer()) then
				StartFire()
				timer.Simple(0.1, StopFire)
			end
		end
	end
end

    function Misc()
            if GetConVarNumber("Ampbot_misc_BunnyHop") == 1 then
                    if input.IsKeyDown(KEY_SPACE) then
                            if LocalPlayer():IsOnGround() then
                                    old_rcc("+Jump")
                                    timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
                            end
                    end
            end
            if GetConVarNumber("Ampbot_aim_NoRecoil") == 1 then
                    if LocalPlayer():GetActiveWeapon().Primary then
                            LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                    end
            end
            if GetConVarNumber("Ampbot_misc_ChatSpam") == 1 then
                    LocalPlayer():ConCommand("say "..GetConVarString("Ampbot_misc_ChatSpam_Msg"))
            end
            if GetConVarNumber("Ampbot_misc_CMDSpam") == 1 then
                    LocalPlayer():ConCommand(GetConVarString("Ampbot_misc_CMDSpam_Msg"))
            end
            if GetConVarNumber("Ampbot_misc_RPGod") == 1 then
                    if LocalPlayer():Health() < 100 then
                            LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
                    end
            end
    end
     
    function ShowNotifi()

            for k, v in pairs(player.GetAll()) do
                    if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                            if(not table.HasValue(Ampbot.spectators, v)) then
                                    table.insert(Ampbot.spectators, v);
                                    if GetConVarNumber("Ampbot_misc_ShowSpec") == 1 then
                                            Ampbot.Notify(true,red,""..v:Nick().." is now spectating you!")
                                            surface.PlaySound("ambient/alarms/klaxon1.wav")
                                    end
                            end
                    end
            end

            for k, v in pairs(Ampbot.spectators) do
                    if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                            table.remove(Ampbot.spectators, k);
                            if GetConVarNumber("Ampbot_misc_ShowSpec") == 1 then
                                    Ampbot.Notify(true,green,""..v:Nick().." is no longer spectating you!")
									surface.PlaySound("buttons/blip1.wav")
                            end
                    end
            end

            if GetConVarNumber("Ampbot_misc_ShowAdmins") == 1 then
                    for k, v in pairs(player.GetAll()) do
                            if (v:IsAdmin() and not table.HasValue(Ampbot.admins, v)) then
                                    table.insert(Ampbot.admins, v);
                                    Ampbot.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
                                    surface.PlaySound("npc/attack_helicopter/aheli_damaged_alarm1.wav");
                            end
                    end
            end
    end
     
     
    local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
    function AntiAfk()
            if GetConVarNumber("Ampbot_misc_AntiAFK") == 1 then
                    local command1 = table.Random( commands )
                    local command2 = table.Random( commands )
                    AddTimer( 1, 1, function()
                            old_rcc( "+"..command1 )
                            old_rcc( "+"..command2 )
                    end )
                    AddTimer( 2, 1, function()
                            old_rcc("-"..command1 )
                            old_rcc("-"..command2 )
                    end )
            end
    end
    AddTimer( 5 , 0 , function() AntiAfk() end )
     
local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
        if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
                local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
                local UsedWeapons = {}
                local MapWeapons = {}
function IsATraitor( ply )
        for k, v in pairs( Traitors ) do
                if v == ply then
                        return true
                else
                        return false
                end
        end
end
 
timer.Create("TTT", 0.8, 0, function()
        if GetConVarNumber("Ampbot_misc_TTT") == 1 then
                if !IsATraitor( ply ) then
                        for k, v in pairs( ents.FindByClass( "player" ) ) do
                                if IsValid( v ) then
                                        if (!v:IsDetective()) then
                                                if v:Team() ~= TEAM_SPECTATOR then
                                                        for wepk, wepv in pairs( TWeapons ) do
                                                                for entk, entv in pairs( ents.FindByClass( wepv ) ) do
                                                                        if IsValid( entv ) then
                                                                                cookie.Set( entv, 100 - wepk )
                                                                                if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                local EntPos = ( entv:GetPos() - Vector(0,0,35) )
                                                                                                        if entv:GetClass() == wepv then
                                                                                                                if v:GetPos():Distance( EntPos ) <= 1 then
                                                                                                                        table.insert( Traitors, v )
                                                                                                                        Ampbot.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
                                                                                                                        if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( UsedWeapons, cookie.GetNumber( entv ) )
                                                                                                                        else
                                                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( MapWeapons, cookie.GetNumber( entv ) )
                                                                                                                        end
                                                                                                                end
                                                                                                        end
                                                                                                end
                                                                                        end
                                                                                end
                                                                        end
                                                                end
                                                        end
                                                end
                                        end
                                end
                        end
                end
        end
end )
 
AddHook("HUDPaint",function()
        if GetConVarNumber("Ampbot_misc_TTT") == 1 then
                for k, e in pairs( Traitors ) do
                        local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
                        if IsValid( e ) then
                                if e:Team() ~= TEAM_SPECTATOR then
                                        if ( !e:IsDetective() ) then
                                                PlayerIsTraitor = true
                                                draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
                                        end
                                end
                        end
                end
        end
end )
 
AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
        for k, v in pairs( Traitors ) do
                table.remove( Traitors, k )
                Traitors = {}
        end
                for k, v in pairs( UsedWeapons ) do
                        table.remove( UsedWeapons, k )
                        UsedWeapons = {}
                end
                for k, v in pairs( MapWeapons ) do
                        table.remove( MapWeapons, k )
                        MapWeapons = {}
                end
        end )
end )
        end
end )
     
local function PlayerConnect( name, ip )
	if GetConVarNumber("Ampbot_misc_logips") == 1 then
	surface.PlaySound("ambient/levels/canals/drip4.wav")
	chat.AddText(
	Color(116,187,251,255), "[Ampbot] ",
	Color(150,150,150,255), tostring( name .. "'s IP: " .. ip ) )
	end
end
IsisCreateHook("PlayerConnect", PlayerConnect)


if CLIENT then

    surface.CreateFont( "NameDefault",
    {
        font        = "Helvetica",
        size        = 20,
        weight      = 800
    })

	concommand.Add("ampbotm_menu", function()	

	local plyrs = player.GetAll()
	local FrameWidth = 500
	local FrameHeight = 350
	local windowTitle = ""
	local muteAdmins = 0

	if (GetConVarString("ampbotm_mute_admins") == "0") then
		windowTitle = " "
		muteAdmins = 0
	else
		windowTitle = " "
		muteAdmins = 1

	end

	DermaFrame = vgui.Create( "DFrame" )
	DermaFrame:SetPos( (ScrW()/2)-100,(ScrH()/2)-100 )
	DermaFrame:SetWidth(FrameWidth)
	DermaFrame:SetHeight(FrameHeight)
	DermaFrame:SetTitle( windowTitle )
	DermaFrame:SetVisible( true )
	DermaFrame:SetDraggable( true )
	DermaFrame:ShowCloseButton( true )
	DermaFrame:Center()
	DermaFrame:SetDeleteOnClose(true)
	DermaFrame:MakePopup()
	function DermaFrame:Paint()
    surface.SetDrawColor( 0, 0, 0, 150 )
    surface.DrawRect( 0, 0, DermaFrame:GetWide(), DermaFrame:GetTall() )
	end
	

	DermaScrollPanel = vgui.Create("DPanelList", DermaFrame)
	DermaScrollPanel:SetPos(6, 25)
	DermaScrollPanel:SetSize(FrameWidth-12, FrameHeight-50-12)
	DermaScrollPanel:SetSpacing(2)
	DermaScrollPanel:SetPadding(2)
	DermaScrollPanel:SetVisible(true)
	DermaScrollPanel:EnableHorizontal(false)
	DermaScrollPanel:EnableVerticalScrollbar(true)

	local scrollWide = DermaScrollPanel:GetWide()

	function CreatePlayerPanels()

	for id, pl in pairs( plyrs ) do

			pl.PlayerPanel = vgui.Create("DPanel")
			pl.PlayerPanel:SetWide(scrollWide)
			pl.PlayerPanel:SetVisible(true)

			pl.PlayerPanelWide = pl.PlayerPanel:GetWide()

			pl.NameLabel = vgui.Create( "DLabel", pl.PlayerPanel )
			pl.NameLabel:SetFont("NameDefault")
			pl.NameLabel:SetText(pl:Nick())
			pl.NameLabel:SetWide(pl.PlayerPanelWide - 50)
			pl.NameLabel:SetPos(3,3)
			pl.NameLabel:SetColor(Color(0,0,0,255))

			pl.Mute = vgui.Create( "DImageButton", pl.PlayerPanel )
			pl.Mute:SetSize( 20, 20 )

			pl.Muted = pl:IsMuted()

			if ( pl.Muted ) then
				pl.Mute:SetImage( "icon32/muted.png" )
			else
				pl.Mute:SetImage( "icon32/unmuted.png" )
			end

			pl.Mute.DoClick = function()

			pl:SetMuted( !pl.Muted )

			DermaScrollPanel:Clear()

			CreatePlayerPanels()

			if ( pl.Muted ) then
				pl.Mute:SetImage( "icon32/muted.png")

			else
				pl.Mute:SetImage( "icon32/unmuted.png" )
			end
			end

			DermaScrollPanel:AddItem(pl.PlayerPanel)

			pl.PlayerPanel:InvalidateLayout(true)
			pl.PlayerPanel.PerformLayout = function()
			pl.PlayerPanelWide = pl.PlayerPanel:GetWide()
			pl.NameLabel:SetWide(pl.PlayerPanelWide - 50)
			pl.Mute:SetPos(pl.PlayerPanelWide - 20 - 3,3)
			pl.NameLabel:SetPos(3,3)
			end

			if (pl:IsAdmin() and muteAdmins == 0) then
				pl.Mute:SetDisabled(true)
			else
				pl.Mute:SetDisabled(false)
			end
	end
	end

	CreatePlayerPanels()

	muteAllPanel = vgui.Create("DPanel", DermaFrame)
	muteAllPanel:SetWide(scrollWide)
	muteAllPanel:SetVisible(true)
	muteAllPanel:SetBackgroundColor(Color(0,201,0,255))

	muteAllPanelWide = muteAllPanel:GetWide()

	muteAllLabel = vgui.Create( "DLabel", muteAllPanel )
	muteAllLabel:SetFont("NameDefault")
	muteAllLabel:SetText("Mute All")
	muteAllLabel:SetWide(muteAllPanelWide - 50)
	muteAllLabel:SetPos(3,3)
	muteAllLabel:SetColor(Color(0,0,0,255))

	muteAllMuteButton = vgui.Create( "DImageButton", muteAllPanel )
	muteAllMuteButton:SetSize( 20, 20 )
	muteAllMuteButton:SetImage( "icon32/muted.png" )
	muteAllMuteButton.DoClick = function()

		for id2, pl2 in pairs( plyrs ) do
			if (pl2:IsAdmin() and muteAdmins == 0) then
				if (pl2:IsMuted() == true) then
					pl2:SetMuted(false)
				end
			else
				if (pl2:IsMuted() == false) then
					pl2:SetMuted(true)
				end
			end

		end

		DermaScrollPanel:Clear()

		CreatePlayerPanels()
	end

	muteAllUnMuteButton = vgui.Create( "DImageButton", muteAllPanel )
	muteAllUnMuteButton:SetSize( 20, 20 )

	muteAllUnMuteButton:SetImage( "icon32/unmuted.png" )

	muteAllUnMuteButton.DoClick = function()

		for id2, pl2 in pairs( plyrs ) do
			if (pl2:IsMuted() == true) then
				pl2:SetMuted(false)
			end
		end

		DermaScrollPanel:Clear()

		CreatePlayerPanels()
	end

	muteAllPanel:SetPos(6,FrameHeight-25-6)

	muteAllPanel:InvalidateLayout(true)
	muteAllPanel.PerformLayout = function()
	muteAllPanelWide = muteAllPanel:GetWide()
	muteAllLabel:SetWide(muteAllPanelWide - 50)
	muteAllMuteButton:SetPos(muteAllPanelWide - 26 - 20,3)
	muteAllUnMuteButton:SetPos(muteAllPanelWide - 20 - 3,3)
	muteAllLabel:SetPos(3,3)
	end

end)
end

CreateConVar("ampbotm_text_command", "mute", {FCVAR_REPLICATED})


if SERVER then
    hook.Add("PlayerSay", "ampbotmMutePlayers", function(Player, Text, Public)

		local textCommand = "!" .. GetConVar("ampbotm_text_command"):GetString()

        if Text[1] == "!" then

            Text = Text:lower()

            if Text == textCommand then
			Player:ConCommand("ampbotmMute")
                return ""
            end
        end
    end)
end

for k,v in pairs(_G) do
	local k = v
	
end

function Color(r, g, b, a)
	return {r = r or 0, g = g or 0, b = b or 0, a = a or 0}
end

local function DrawGradientRectH(x, y, w, h, col1, col2)
	local segments = 1 / h

	for i = 0, h do
		local col = Color((col1.r - (col1.r - col2.r) * segments * i), (col1.g - (col1.g - col2.g) * segments * i), (col1.b - (col1.b - col2.b) * segments * i), (col1.a - (col1.a - col2.a) * segments * i))
		surface.SetDrawColor(col)
		surface.DrawLine(x, y + i, x + w, y + i)
	end
end

local pairs = pairs
local require = require
local unpack = unpack

local Msg = Msg
local MsgN = MsgN
local print = print

local CreateClientConVar = CreateClientConVar
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand
local SetMaterialOverride = SetMaterialOverride

local draw = require("draw")
local hook = require("hook")

local cam = cam
local draw = draw
local hook = hook
local render = render
local surface = surface
local table = table

local AmpC = {}
	AmpC.CMDPrefix = "ampbot"
	AmpC.ConVars = {}
	AmpC.GM = {}
	AmpC.OnInit = {}
	AmpC.ValidEntities = {}
	AmpC.ValidPlayers = {}
	AmpC.IsActive = CreateClientConVar(AmpC.CMDPrefix .. "_" .. "enabled", 0, true, false)

function AmpC:AppendToGM(hType, func, ret)
	if self.GM[hType] != nil then

		self.GM["TEMP_" .. hType] = self.GM[hType]
		local t_Index = self.GM["TEMP_" .. hType]

		self.GM[hType] = function(...)
			local value = t_Index(...)
			if ret then
				local value2 = func(...)
				if value2 != nil then
					value = value2
				end
			else
				func(...)
			end
			self.GM["TEMP_" .. hType] = nil
			return value
		end
	end
end

function AmpC:DoOnInit(func)
	table.insert(self.OnInit, func)
end

function AmpC:AddCommand(cmd, func)
	concommand.Add(self.CMDPrefix .. "_" .. cmd, function(p, c, a) func(a) end)
end

function AmpC:Hook(type, func, convar, default, ret)
	local function Do()
		if convar != nil then
			AmpC:CreateConVar(convar, default)
		end

		AmpC:AppendToGM(type, function(...)
			local args = {...}

			if args[1] != nil then
				table.remove(args, 1)
			end
		end, ret)
	end

	AmpC:DoOnInit(Do)
end

local function RemoveBindHooks()
	local t = hGetTable()

	for k, v in pairs(t) do
		if string.match(string.lower(k), "playerbindpress") then
			for _k, _v in pairs(v) do
				hRemove(k, _k)
			end
		end
	end
end
AmpC:AddCommand("removebindhooks", RemoveBindHooks)

function AmpC:AddBindCommand(cmd, func, htype, on_callback, off_callback)
	local on = false
	AmpC:Hook(htype, function()
		if on then
			func()
		end
	end)
	concommand.Add("+" .. AmpC.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = true
		if on_callback != nil then
			on_callback(a)
		end
	end)
	concommand.Add("-" .. AmpC.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = false
		if off_callback != nil then
			off_callback(a)
		end
	end)
end

AmpC:Hook("Think", function()
	AmpC.ValidEntities = {}
	AmpC.ValidPlayers = {}

	for k, v in pairs(ents.GetAll()) do
		if ValidEntity(v) then
			AmpC.ValidEntities[k] = v
		end
	end

	for k, v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			AmpC.ValidPlayers[k] = v
		end
	end
end)

function AmpC:CreateConVar(cmd, default)
	table.insert(AmpC.ConVars, {cmd = cmd, value = CreateClientConVar(AmpC.CMDPrefix .. "_" .. cmd, default, true, false)})
end
AmpC:CreateConVar("enabled", 1)

function AmpC:GetConVar(cmd)
	for k, v in pairs(AmpC.ConVars) do
		if v.cmd == cmd then
			return v.value
		end
	end
end

local function DrawGradientRectH(x, y, w, h, col1, col2)
	local segments = 1 / h

	for i = 0, h do
		local col = Color((col1.r - (col1.r - col2.r) * segments * i), (col1.g - (col1.g - col2.g) * segments * i), (col1.b - (col1.b - col2.b) * segments * i), (col1.a - (col1.a - col2.a) * segments * i))
		surface.SetDrawColor(col)
		surface.DrawLine(x, y + i, x + w, y + i)
	end
end

function ConVarExists(cvar)
	if !table.HasValue(Ampbot.convars,cvar) then
		Ampbot.Print("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		Ampbot:Log("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return old_cve(cvar)
	else
		Ampbot.Print("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		Ampbot:Log("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

local MENU_TABS = {}
	MENU_TABS[1] = "Aimbot"
	MENU_TABS[2] = "ESP"
	MENU_TABS[3] = "Misc"
	MENU_TABS[4] = "Design"

local MENU_ITEMS = {}
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_auto", text = "Autofire", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_admins", text = "Target Admins", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_steam", text = "Target STEAM friends", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_friendly", text = "Target Team-mates", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_autosight", text = "Auto Iron-Sight", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_antisnap", text = "Anti-Snap", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_aeload", text = "Auto Reload", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_targetbones", text = "Target Specific Bones", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_prediction", text = "Movement Prediction", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_spawnprotection", text = "Stronghold SpawnProtection", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "misc_rapidfire", text = "Rapid Fire", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_offset", text = "Bone Offset", t = "float", min = 0, max = 100})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_antiSnap_speed", text = "Anti-Snap Speed", t = "float", min = 0, max = 200})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aim_fov", text = "Field of View", t = "float", min = 0, max = 360})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_info", text = "Enable ESP", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_chams", text = "Enable Chams", t = "boolean"})	
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_skeleton", text = "Enable Skeleton", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_2dbox", text = "Enable 2DBox", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_3dbox", text = "Enable 3DBox", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Misc", convar = "esp_crosshair", text = "Enable Crosshair", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Misc", convar = "misc_bunnyhop", text = "Enable Bunnyhop", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showspec", text = "Show Spectators", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Misc", convar = "misc_showadmins", text = "Show Admins", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Misc", convar = "misc_ttt", text = "TTT Mode", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_2dbox_color_r", text = "2D Box [RED]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_2dbox_color_g", text = "2D Box [GREEN]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_2dbox_color_b", text = "2D Box [BLUE]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_3dbox_color_r", text = "3D Box [RED]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_3dbox_color_g", text = "3D Box [GREEN]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_3dbox_color_b", text = "3D Box [BLUE]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_crosshair_color_r", text = "Crosshair [RED]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_crosshair_color_g", text = "Crosshair [GREEN]", t = "float", min = 0, max = 255})
	table.insert(MENU_ITEMS, {tab = "Design", convar = "esp_crosshair_color_b", text = "Crosshair [BLUE]", t = "float", min = 0, max = 255})
	
local function ShowAmpMenu()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(600, 400)
		Frame:Center()
		Frame:SetTitle("                                                                                            AMPBOT V3")
		Frame:SetSizable(false)
		Frame:SetDraggable(false)
		Frame:MakePopup()
		function Frame:Paint()
			Derma_DrawBackgroundBlur(self, self.fCreateTime)
			surface.SetDrawColor(Color(0, 0, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(0, 102, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), 22)
		end

	local TabList = vgui.Create("DColumnSheet", Frame)
		TabList:SetSize(Frame:GetWide() - 40, Frame:GetTall() - 40)
		TabList:SetPos(10, 30)
		TabList.ButtonOnly = true

		function TabList.Content:Paint()
		end

		for k, v in pairs(MENU_TABS) do
			local panel = vgui.Create("DPanelList", TabList)
			local p_Item = TabList:AddSheet(v, panel , "models/effects/vol_light001")
				panel:SetSize(TabList:GetWide() - 200, TabList:GetTall() - 10)
				panel:SetSpacing(5)
				panel:SetPadding(5)

				function panel:Paint()
					surface.SetDrawColor(Color(0, 0, 0, 102))
					surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
				end
			for _k, _v in pairs(MENU_ITEMS) do
				if _v.tab == v then
					if _v.t == "boolean" then
						local Item = vgui.Create("DCheckBoxLabel")
							Item:SetText(_v.text)
							Item:SetConVar()

							function Item:OnChange(value)
								local num = 0
								if value then num = 1 end
								RunConsoleCommand(AmpC.CMDPrefix .. "_" .. _v.convar, num)
							end

							Item:SizeToContents()
						panel:AddItem(Item)
					elseif _v.t == "ampbot" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(AmpC:GetConVar(_v.convar):GetBool())
							Item:SetDecimals(0)

							function Item:OnValueChanged(value)
								RunConsoleCommand(AmpC.CMDPrefix .. "_" .. _v.convar, value)
							end

						panel:AddItem(Item)
					elseif _v.t == "float" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(AmpC:GetConVar(_v.convar))
							if _v.convar == "speedamount" then
								Item:SetDecimals(0)
							else
								Item:SetDecimals(0)
							end

							function Item:OnValueChanged(value)
								RunConsoleCommand(AmpC.CMDPrefix .. "_" .. _v.convar, value)
							end
							
	local Xrabu= vgui.Create("DButton")
	Xrabu:SetPos( 10, 250 )
	Xrabu:SetParent( Frame )
	Xrabu:SetSize( 200, 25 )
	Xrabu:SetText( "Enable/Disable Xray" )
	Xrabu.OnCursorEntered = function()
		surface.PlaySound("hover.wav")
		return false
	end
	Xrabu.Paint = function()
		surface.SetDrawColor( 0, 160, 0, 255 )
		surface.DrawRect( 0, 0, Xrabu:GetWide(), Xrabu:GetTall() )
	Xrabu.DoClick = function()
	RunConsoleCommand( "ampbotp_xray" )
	end
end
							
	local Mutep1= vgui.Create("DButton")
	Mutep1:SetPos( 10, 290 )
	Mutep1:SetParent( Frame )
	Mutep1:SetSize( 200, 25 )
	Mutep1:SetText( "Mute Players" )
	Mutep1.OnCursorEntered = function()
		surface.PlaySound("hover.wav")
		return false
	end
	Mutep1.Paint = function()
		surface.SetDrawColor( 0, 160, 0, 255 )
		surface.DrawRect( 0, 0, Mutep1:GetWide(), Mutep1:GetTall() )
	Mutep1.DoClick = function()
	RunConsoleCommand( "ampbotm_menu" )
	end
end
	
	local PrintAs= vgui.Create("DButton")
	PrintAs:SetPos( 10, 330 )
	PrintAs:SetParent( Frame )
	PrintAs:SetSize( 200, 25 )
	PrintAs:SetText( "Print Ranks" )
	PrintAs.OnCursorEntered = function()
		surface.PlaySound("hover.wav")
		return false
	end
	PrintAs.Paint = function()
		surface.SetDrawColor( 0, 160, 0, 255 )
		surface.DrawRect( 0, 0, PrintAs:GetWide(), PrintAs:GetTall() )
	PrintAs.DoClick = function()
	RunConsoleCommand( "ampbot_printadmins" )
	end
end
	
	local RelHo= vgui.Create("DButton")
	RelHo:SetPos( 10, 370 )
	RelHo:SetParent( Frame )
	RelHo:SetSize( 200, 25 )
	RelHo:SetText( "Reload Hooks" )
	RelHo.OnCursorEntered = function()
		surface.PlaySound("hover.wav")
		return false
	end
	RelHo.Paint = function()
		surface.SetDrawColor( 0, 160, 0, 255 )
		surface.DrawRect( 0, 0, RelHo:GetWide(), RelHo:GetTall() )
	RelHo.DoClick = function()
	Ampbot.hooks:reload()
	Ampbot.Notify(green,"Reloaded hooks.")
	end
end

	local Misc7Text = vgui.Create("DLabel")
	Misc7Text:SetText( "CMD Spam" )
	Misc7Text:SetParent( Frame )
	Misc7Text:SetWide(200)
	Misc7Text:SetPos(60,203)
	Misc7Text:SetTextColor(Color(70,70,70,100))

	local Miscs7 = vgui.Create( "DTextEntry", Frame )
	Miscs7:SetPos( 10, 220 )
	Miscs7:SetTall(15)
	Miscs7:SetWide(200)
	Miscs7:SetConVar("Ampbot_misc_CMDspam_msg")
	Miscs7:SetValue(GetConVarNumber("Ampbot_misc_CMDspam_msg"))
	Miscs7:SetEnterAllowed( true )
	
	local Misc9Text = vgui.Create("DLabel")
	Misc9Text:SetText( "Chat Spam" )
	Misc9Text:SetParent( Frame )
	Misc9Text:SetWide(200)
	Misc9Text:SetPos(60,173)
	Misc9Text:SetTextColor(Color(70,70,70,100))
	
	local Miscs7 = vgui.Create( "DTextEntry", Frame )
	Miscs7:SetPos( 10, 190 )
	Miscs7:SetTall(15)
	Miscs7:SetWide(200)
	Miscs7:SetConVar("Ampbot_misc_Chatspam_msg")
	Miscs7:SetValue(GetConVarNumber("Ampbot_misc_chatspam"))
	Miscs7:SetEnterAllowed( true )
							
	local Misc6 = vgui.Create( "DCheckBoxLabel", Frame )
	Misc6:SetPos( 140, 205 )
	Misc6:SetText( " " )
	Misc6:SetConVar("Ampbot_misc_CMDspam")
	Misc6:SetValue(GetConVarNumber("Ampbot_misc_CMDspam"))
	Misc6:SizeToContents()
	
	local Miscf6 = vgui.Create( "DCheckBoxLabel", Frame )
	Miscf6:SetPos( 140, 175 )
	Miscf6:SetText( " " )
	Miscf6:SetConVar("Ampbot_misc_Chatspam")
	Miscf6:SetValue(GetConVarNumber("Ampbot_misc_Chatspam"))
	Miscf6:SizeToContents()
	
						panel:AddItem(Item)
					elseif _v.t == "func" then
						local Item = vgui.Create("DButton")
							Item:SetText(_v.text)
							Item.DoClick = function() 
								_v.func()
								if _v.close then
									Frame:Close()
								end
							end
						panel:AddItem(Item)
					end
				end
			end
		end
		TabList.Navigation:SetWidth(180)
		for k, v in pairs(TabList.Items) do
			v.Button:SetHeight(30)
			v.Button:DockMargin(0, 0, 0, 0)
			v.Button.OnCursorEntered = function()
				surface.PlaySound("hover.wav")
				return false
			end
			
			if v.Button.Image then
				v.Button.Image.SetImage = function() end
				v.Button.Image.Paint = function() end
			end

			function v.Button:Paint()
				local color = Color(0, 102, 0, 255)

				if TabList:GetActiveButton() == v.Button then
					color = Color(0, 204, 0, 255)
				end
				
				if self.Depressed then
					color = Color(color.r - (color.r / 6), color.g - (color.g / 6), color.b - (color.b / 6), 255)
				elseif self.Hovered and TabList:GetActiveButton() != v.Button then
					color = Color(color.r + (color.r / 6), color.g + (color.g / 6), color.b + (color.b / 6), 255)
				end

				color.a = 255
				DrawGradientRectH(0, 0, self:GetWide(), self:GetTall(), color, Color(color.r + (color.r / 4), color.g + (color.g / 4), color.b + (color.b / 4), 255))
			end
		end
end
concommand.Add("ampbot_menu", ShowAmpMenu)
     
function hooks_hudpaint()
ESP()
end

function hooks_postdraw()
Chams()
end

function hooks_think()
Misc();
ShowNotifi();
end

function hooks_renderscreenspaceeffects()
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd)
end

function Ampbot.hooks:load()
Log("Loaded hooks")
AddHook("HUDPaint",hooks_hudpaint)
AddHook("PostDrawEffects",hooks_postdraw)
AddHook("Think",hooks_think)
AddHook("CalcView",hooks_calcview)
AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
AddHook("CreateMove",hooks_createmove)
end
Ampbot.hooks:load(); 

function Ampbot.hooks:unload()
RemoveHook("HUDPaint",hooks_hudpaint)
RemoveHook("CalcView",hooks_calcview)
RemoveHook("PostDrawEffects",hooks_postdraw)
RemoveHook("Think",hooks_think)
RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
RemoveHook("CreateMove",hooks_createmove)
end

function Ampbot.hooks:reload()
Log("Reloaded hooks")
Ampbot.hooks:unload()
Ampbot.hooks:load()
end

function unload()
Log("Unloaded.")
Ampbot.hooks:unload()
old_rcc("-Ampbot_Menu")
RemoveCMD("+Ampbot_Menu")
RemoveCMD("-Ampbot_Menu")
RemoveCMD("+Ampbot_Aim")
RemoveCMD("-Ampbot_Aim")
RemoveCMD("+Ampbot_Speed")
RemoveCMD("-Ampbot_Speed")
RemoveCMD("Ampbot_Menu_Toggle")
timer.Destroy("TTT")
end
     

     
    Ampbot.Notify(dosound,white,"loaded successfully.")
    Log("Loaded!")
