Trooper Hack v1.3, created by Assault_Trooper

The console command has been changed, edit it!

Usage:

Bind a key in console for the aimbot menu, in console type:

bind KEYHERE +trooperhack_menu

SVN:

https://trooperhack.svn.sourceforge.net/svnroot/trooperhack/

Homepage:

http://troopersbuild.info/

Here you can find the latest version and any other future projects.

Disclaimer:

You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work). You may not use this work for commercial purposes. You may not alter, transform, or build upon this work. 

http://creativecommons.org/licenses/by-nc-nd/3.0/