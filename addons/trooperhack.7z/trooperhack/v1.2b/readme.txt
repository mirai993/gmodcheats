Trooper Hack v1.2b, created by Assault_Trooper

Usage:

Bind a key in console for the aimbot menu, in console type:

bind KEYHERE +trooper_menu

SVN:

https://trooperhack.svn.sourceforge.net/svnroot/trooperhack/

Disclaimer:

You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work). You may not use this work for commercial purposes. You may not alter, transform, or build upon this work. 

http://creativecommons.org/licenses/by-nc-nd/3.0/