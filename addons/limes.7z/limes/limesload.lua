--[[
	limesload.lua
	Discord
	===DStream===
]]

require( "hook" )

require( "preproc" )

MsgN( "<-- Lua Here" )

file.Write( "limes_runstring.txt", "" )
file.Write( "limes_luacmd.txt", "" )

hook.Add( "Lua_Preprocess", "LuaHook", function(fi, path, lua)
	if ( fi == "LuaCmd" ) then
		file.Append( "limes_luacmd.txt", "LuaCmd-(" .. lua .. ")\n" )
	else
		file.Append( "limes_runstring.txt", fi .. "\n" )
	end
end )