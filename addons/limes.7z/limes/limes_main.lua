--[[
	arc.lua
	Discord
	===DStream===
]]

MsgN("~~~~~Lymes~~~~~")

local Lymes = {}
Lymes.Hooks = {}
Lymes.IsHooking = 0
Lymes.ScrHW	 = ScrW()/2
Lymes.ScrHH	 = ScrH()/2
Lymes.Weapon = NULL
Lymes.Target = NULL
Lymes.Me = LocalPlayer()
Lymes.Aiming = false
Lymes.Cone = Vector(0, 0, 0)
Lymes.Deco = require("jell")

Lymes.HideFiles = { "jell.dll", "cvar2.dll", "preproc.dll" }
Lymes.HideHooks = { "Lymes_HUDPaint", "Lymes_Think", "Lymes_CreateMove", "Lymes_IPE", "Lymes_CalcView" }

/*Stored funcs before they can be altered*/

Lymes.Old = {}
Lymes.Old.GVA	= _R["CUserCmd"].GetViewAngles
Lymes.Old.SVA 	= _R["CUserCmd"].SetViewAngles
Lymes.Old.GMX 	= _R["CUserCmd"].GetMouseX
Lymes.Old.GMY 	= _R["CUserCmd"].GetMouseY
Lymes.Old.GB	= _R["CUserCmd"].GetButtons
Lymes.Old.GSP	= _R["Player"].GetShootPos

Lymes.Old.FE	= file.Exists
Lymes.Old.FEE	= file.ExistsEx
Lymes.Old.FF	= file.Find
Lymes.Old.FFIL 	= file.FindInLua
Lymes.Old.FID	= file.IsDir
Lymes.Old.FR	= file.Read
Lymes.Old.FS	= file.Size
Lymes.Old.FTF	= file.TFind
Lymes.Old.FT	= file.Time

Lymes.Old.PGA	= player.GetAll
Lymes.Old.GCV	= GetConVar
Lymes.Old.GCVS	= GetConVarString
Lymes.Old.GCVN	= GetConVarNumber
Lymes.Old.ECC	= engineConsoleCommand
Lymes.Old.RS	= RunString
Lymes.Old.PC	= pcall

Lymes.Old.Math	= table.Copy(math)
Lymes.Old.Timer = table.Copy(timer)
Lymes.Old.Util	= table.Copy(util)
Lymes.Old.RCC	= RunConsoleCommand
Lymes.Old.RQ	= require

Lymes.Old.DGUV	= debug.getupvalue
Lymes.Old.DGI	= debug.getinfo

Lymes.Old.HA	= function() return end
Lymes.Old.HC	= function() return end
Lymes.Old.HGT	= function() return end
Lymes.Old.HR	= function() return end

if (Lymes.Deco) then
	Lymes.Old.DGP	= hl2_ucmd_getpr3diction
	Lymes.Old.DMS	= hl2_man1pshot
	//hl2_ucmd_getpr3diction = nil
	//hl2_man1pshot = nil
end

/*Variable system*/

local LyVars = {
	["aim_enabled"] = 1,	//0 = Off, 1 = Always, 2 = Mouse1
	["aim_viewfix"] = true,
	["aim_antiaim"] = true,
	["aim_friends"] = true,
	["esp_crosshair"] = 2,
	["esp_healthbars"] = true
}

/*HUDPaint-ESP-Radar*/
function Lymes.DrawEsp()
	for k, ply in pairs(player.GetAll()) do
	
		local ply_h = ply:Health()
		local col_n
		
		local center = ply:LocalToWorld(ply:OBBCenter())	
		local pos_n = (center-Vector(0, 0, 25)):ToScreen()
		
		if (LyVars.esp_healthbars) then
			local col_hg = ply_h*2.55
			local col_h = Color(255-col_hg, col_hg, 0)
			surface.SetDrawColor(30, 30, 30, 230)
			surface.DrawRect(pos_n.x-17, pos_n.y+14, 35, 6)
			surface.SetDrawColor(col_h)
			if (ply_h <= 100) then
				surface.DrawRect(pos_n.x-16, pos_n.y+15, (ply_h/3), 4)
			else
				surface.DrawRect(pos_n.x-16, pos_n.y+15, 33, 4)
			end
		end

		if (ply_h > 0) then 
			col_n = Color(25, 200, 25, 230) 
		else
			col_n = Color(75, 75, 75, 230)
		end
		
		
		draw.DrawText(ply:Nick(), "BudgetLabel", pos_n.x, pos_n.y, col_n, TEXT_ALIGN_CENTER)
		
	end
end

function Lymes.DrawCrosshair()
	if (LyVars.esp_crosshair == 1) then
		surface.SetDrawColor(255, 0, 0)
		surface.DrawLine(Lymes.ScrHW, Lymes.ScrHH-6, Lymes.ScrHW, Lymes.ScrHH+6)
		surface.DrawLine(Lymes.ScrHW-6, Lymes.ScrHH, Lymes.ScrHW+6, Lymes.ScrHH)
	elseif (LyVars.esp_crosshair == 2) then
		surface.SetDrawColor(255, 0, 0)
		surface.DrawRect(Lymes.ScrHW, Lymes.ScrHH-7, 1, 6)
		surface.DrawRect(Lymes.ScrHW-7, Lymes.ScrHH, 6, 1)
		surface.DrawRect(Lymes.ScrHW, Lymes.ScrHH+2, 1, 6)
		surface.DrawRect(Lymes.ScrHW+2, Lymes.ScrHH, 6, 1)
	end
end

function Lymes.Hooks.HUDPaint()
	surface.SetTextColor(255,255,255)
	surface.SetFont("BudgetLabel")
	surface.SetTextPos(10,5)
	surface.DrawText("Cone: " .. Lymes.Cone[1])
	surface.SetTextPos(10,15)
	if (Lymes.Target ~= NULL and ValidEntity(Lymes.Target)) then
		surface.DrawText("Targ: " .. Lymes.Target:Nick())
	end
	Lymes.DrawEsp()
	Lymes.DrawCrosshair()
end

/*CreateMove-CalcView*/

local LyAngs = {}
LyAngs.Real = Angle(0,0,0)	//Normal view w/ recoil
LyAngs.Aim	= Angle(0,0,0)	//Normal view wo/ recoil
LyAngs.AA	= Angle(0,89,0)	//Anti-Aim angles
LyAngs.CV	= Angle(0,0,0)	//Fake view angles
LyAngs.CVP 	= GetConVarNumber("m_pitch")
LyAngs.CVY 	= -GetConVarNumber("m_yaw")

function Lymes.Hooks.CreateMove(ucmd)
	local mfix = Angle(Lymes.Old.GMY(ucmd)*LyAngs.CVP, Lymes.Old.GMX(ucmd)*LyAngs.CVY)	
	
	LyAngs.Real = Lymes.Old.GVA(ucmd)
	LyAngs.Aim 	= LyAngs.Aim + mfix
	
	if (Lymes.Target ~= NULL) then
		local TPos = Lymes.GetTargetPos(Lymes.Target)
		if (TPos) then
			Lymes.IsAiming = true
			LyAngs.Aim = (TPos-Lymes.Old.GSP(Lymes.Me)):Angle()
			Lymes.Old.RCC("+attack")
			timer.Simple(0.01, function() Lymes.Old.RCC("-attack") end)
		end
	else
		Lymes.IsAiming = false
	end
	
	LyAngs.Aim.p = Lymes.Old.Math.NormalizeAngle(LyAngs.Aim.p)
	LyAngs.Aim.y = Lymes.Old.Math.NormalizeAngle(LyAngs.Aim.y)
	
	if (LyVars.aim_viewfix) then
	
		if (Lymes.IsAiming) then
			LyAngs.CV.p = Lymes.Old.Math.ApproachAngle(LyAngs.CV.p, LyAngs.Aim.p, 5)
			LyAngs.CV.y = Lymes.Old.Math.ApproachAngle(LyAngs.CV.y, LyAngs.Aim.y, 5)
		else
			LyAngs.CV = LyAngs.Aim
		end
		
		if (Lymes.Old.GB(ucmd) & IN_ATTACK > 0) then
			local cmd2, seed = Lymes.Old.DGP(ucmd)
			local currentseed = 0
			if (cmd2 ~= 0) then currentseed = seed end
			local newAng = Lymes.Old.DMS(currentseed, LyAngs.Aim:Forward(), -Lymes.Cone):Angle()
				
			newAng.p = Lymes.Old.Math.NormalizeAngle(newAng.p)
			newAng.y = Lymes.Old.Math.NormalizeAngle(newAng.y)

			Lymes.Old.SVA(ucmd, newAng)
		end
		
	else
		LyAngs.CV = LyAngs.Real
		Lymes.Old.SVA(ucmd, LyAngs.Real)	
	end
	
end

function Lymes.Hooks.CalcView(ply,o,a,f)
	return GAMEMODE:CalcView(ply,o,LyAngs.CV,f)
end

/*Targeting-ThinkHooks*/

function Lymes.ValidTarget(ent)
	if (!ValidEntity(ent)) then return false end
	if (ent == LocalPlayer()) then return false end
	if (type(ent) ~= "Player") then return false end
	if (!ent:Alive()) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (ent:GetMoveType() == MOVETYPE_NONE) then return false end
	if (LyVars.aim_friends and ent:GetFriendStatus() == "friend") then return false end
	return true
end

function Lymes.IsTargetVisible(ent)
	if (!ValidEntity(ent)) then return false end
	
	local visTraceData = {}
	visTraceData.start = Lymes.Old.GSP(Lymes.Me)
	visTraceData.endpos = ent:LocalToWorld(ent:OBBCenter())
	visTraceData.filter = {Lymes.Me, MASK_SHOT, MASK_SHOT_HULL}
	
	local visTrace = util.TraceLine(visTraceData)
	
	if (visTrace.Entity == ent) then return true end
	
	return false
end

function Lymes.GetTargetPos(ent)
	if (!ValidEntity(ent)) then return false end
	
	local mdl = ent:GetModel()
	local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
	
	if (bone) then return ent:GetBonePosition(bone) else
		return false
	end
	
end

function Lymes.ThinkTarget()
	local targs = player.GetAll()
	
	for k, v in pairs(targs) do
		if (!Lymes.ValidTarget(v)) then
			targs[k] = nil
		end
		if (!Lymes.IsTargetVisible(v)) then
			targs[k] = nil
		end
	end
	
	local BestTarget
	for _, ent in pairs(targs) do
		local dist = ent:GetPos():Distance(Lymes.Me:GetPos())
		if (!BestTarget) then BestTarget = ent end
		if (dist < BestTarget:GetPos():Distance(Lymes.Me:GetPos())) then
			BestTarget = ent
		end
	end
	
	if (BestTarget == Lymes.Target) then return end
	
	Lymes.Target = BestTarget
end


Lymes.Cones = {
	["weapon_pistol"]	=	0.0100,
	["weapon_smg1"]		=	0.04362,
	["weapon_ar2"]		=	0.02618,
	["weapon_shotgun"]	=	0.08716
}

function Lymes.ThinkCone()
	if (Lymes.Me:GetActiveWeapon() ~= Lymes.Weapon) then
		Lymes.Weapon = Lymes.Me:GetActiveWeapon()

		if (Lymes.Weapon) then
		
			if (Lymes.Weapon:GetClass()) then
				if (Lymes.Cones[Lymes.Weapon:GetClass()]) then
					local NewCone = Lymes.Cones[Lymes.Weapon:GetClass()]
					Lymes.Cone = Vector(NewCone, NewCone, NewCone)
					return
				end
			end
		
			if (Lymes.Weapon.Primary) then
				if (Lymes.Weapon.Primary.Cone) then
					local NewCone = Lymes.Weapon.Primary.Cone
					Lymes.Cone = Vector(NewCone, NewCone, NewCone)
					return
				end
			end
						
		end
		
		Lymes.Cone = Vector(0, 0, 0)
		
	end
end

function Lymes.ThinkKeys()

end

function Lymes.Hooks.Think()
	Lymes.Old.PC(function()
		Lymes.ThinkTarget()
		Lymes.ThinkCone()
		Lymes.ThinkKeys()
	end)
end

function Lymes.Hooks.IPE()
	Lymes.Me = LocalPlayer()
	print( "[Lymes] SelfEntity: " .. Lymes.Me:Nick() )
end

/*AntiDetection-Convienience*/

function Lymes.Old.THV(t, val)
	for k, v in pairs(t) do
		if (v == val ) then return true end
	end
	return false
end

function Lymes.CleanGetTable()
	local hooktable = {}
	
	for ktype, vtype in pairs( Lymes.Old.HGT() ) do
		hooktable[ktype] = {}
		for k, v in pairs( vtype ) do
			if !Lymes.Old.THV(Lymes.HideHooks, k) then
				hooktable[ktype][k] = v
			else
				print( "[Lymes] Excluded: \"" .. k .. "\" from hook check." )
			end
		end
	end
	
	return hooktable
end

function Lymes.IsHidden(filepath)
	if type(filepath) == "table" then
		print( "[Lymes](dbg) IsHidden got table." )
		return false
	end
	if type(filepath) ~= "string" then return false end
	for k, v in pairs( Lymes.HideFiles ) do
		if ( string.find( filepath, v ) ) then
			return true
		end
	end
	return false
end

function Lymes.StripFiles(tbl)
	for k, v in pairs(tbl) do
		if Lymes.IsHidden(v) then
			table.remove(tbl, k)
			print("[Lymes] file \"" .. v .. "\" stripped from file query.")
		end
	end
	return tbl
end

/*Detours*/

function debug.getupvalue(...) //Anti-Detour Detection
	local args = {...}
	if (args[1]) then
		
		if ( Lymes.THV( Lymes, Lymes.Old.DGUV(...) ) ) then
			MsgN( "[Lymes](DGUV) Returned in Lymes, faking nil." )
		end
		
		if ( Lymes.Old.DGUV(...) == Lymes ) then
			MsgN( "[Lymes](DGUV) Returned = Lymes, faking nil." )
		end
		
		if ( Lymes.Old.DGUV(...) == debug.getupvalue ) then
			MsgN( "[Lymes](DGUV) Returned self, faking nil." )
		end
		
		if ( Lymes.Old.DGUV(...) == Lymes.Old.DGUV ) then
			MsgN( "[Lymes](DGUV) Returned self(stored), faking nil." )
		end
	
	end
	print( "[Lymes](DGUV) Returning Old, ret="..Lymes.Old.DGUV(...) )
	return Lymes.Old.DGUV(...)
end

function require(...) //Safe hook loading ( hook funcs will never exist until theyre supposed to )
	local args = {...}
	if (args[1]) then
		if (args[1] == "hook") then
			Lymes.Old.RQ(...)
			Lymes.IsHooking = Lymes.IsHooking + 1
			if (Lymes.IsHooking == 1) then
				Lymes.Old.HA  = hook.Add
				Lymes.Old.HC  = hook.Call
				Lymes.Old.HGT = hook.GetTable
				Lymes.Old.HR  = hook.Remove
				hook.GetTable = Lymes.CleanGetTable
				print( "[Limes] Ready to hook!" )
				Lymes.Old.HA("InitPostEntity", "Lymes_IPE", Lymes.Hooks.IPE)
				Lymes.Old.HA("HUDPaint", "Lymes_HUDPaint", Lymes.Hooks.HUDPaint)
				Lymes.Old.HA("CreateMove", "Lymes_CreateMove", Lymes.Hooks.CreateMove)
				Lymes.Old.HA("CalcView", "Lymes_CalcView", Lymes.Hooks.CalcView)
				Lymes.Old.HA("Think", "Lymes_Think", Lymes.Hooks.Think)
				return true
			end
			return false
		end
	end
	return Lymes.Old.RQ(...)
end

//if hook then hook = nil end
//if concommand then concommand = nil end