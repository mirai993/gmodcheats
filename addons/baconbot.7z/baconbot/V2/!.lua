_G.SafeViewAngles = _R["CUserCmd"].SetViewAngles
_G.LoadedMe=true

concommand.Add("Bacon_Reload_Script", function() include("stuff/Clock.lua") print("**Loaded BaconBot and BaconESP**") if LoadedMe then print("**Post-Loading for BaconBot**") InitShit() LoadedMe = false end end)