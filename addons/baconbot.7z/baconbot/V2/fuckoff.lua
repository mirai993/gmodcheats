local oldRead = file.Read

local fuckoff = [[]]

function file.Read(path)
if string.find(path , "../") then
ErrorNoHalt("file.Read: Attempted to read file outside of the data folder. \""..path.."\"\n")
return fuckoff
else
oldRead(path)
end
end