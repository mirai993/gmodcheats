Hello i upload dis file and it will help ju succeed to be the top person k
put baconbot in garrysmod>garrysmod>materials
put dah other .laughs files in the garrysmod>lau>autorun>client
add me if u knead more  help http://steamcommunity.com/id/3094/