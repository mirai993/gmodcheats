if MaxPlayers ~= nil then return end
require("baconbot")
LoadBaconBot(file.Read("../lua/baconbot.lua"))