--[[
	lua/menu_plugins/bbot.lua
	MutantCode | (STEAM_0:0:49151823)
	===DStream===
]]

if MaxPlayers then return end
require("bbot_crack_u2")

function HandleChangelog(user, pass)
end

function Loader()

	local LoginPanel = vgui.Create("DFrame")
	LoginPanel:SetSize(195,215)
	LoginPanel:SetPos(ScrW()/2-100,ScrH()/2-100)
	LoginPanel:SetTitle("BaconBot_v4 Crack Update 2")
	
	local Logo = vgui.Create("DImage", LoginPanel)
	Logo:SetMaterial(Material("BaconBot/Logo"))
	Logo:SetPos(0,37)
	Logo:SetSize(200,50)
	
	local UserLabel = vgui.Create("DLabel", LoginPanel)
	UserLabel:SetText("Username")
	UserLabel:SetPos(15,120)
	UserLabel:SizeToContents()
	
	local UserBox = vgui.Create("DTextEntry", LoginPanel)
	UserBox:SetSize(120,20)
	UserBox:SetPos(65,118)
	UserBox.OnEnter=function() end
	
	local PassLabel = vgui.Create("DLabel", LoginPanel)
	PassLabel:SetText("Password")
	PassLabel:SetPos(15,145)
	PassLabel:SizeToContents()
	
	local PassBox = vgui.Create("DTextEntry", LoginPanel)
	PassBox:SetSize(120,20)
	PassBox:SetPos(65,143)
	PassBox.OnEnter=function() Login() end
	
	local AccessButton = vgui.Create("DButton", LoginPanel)
	AccessButton:SetText("Request Access")
	AccessButton:SetSize(100,25)
	AccessButton:SetPos(50,175)
	AccessButton.DoClick=function() Login() end
	
	function Login()
		AccessButton:SetDisabled(true)
		PassBox:SetEditable(false)
		AccessButton:SetText("Loading")
		local Dot=""
		timer.Create("LoadingDot",0.5,0,function()
			if !AccessButton:IsValid() then
				timer.Destroy("LoadingDot")
				return
			end 
			if Dot=="...." then
				Dot=""
			end
			Dot=Dot.."." AccessButton:SetText("Loading"..Dot)
			surface.PlaySound("weapons/grenade/tick1.wav")
		end)

		if !AttemptLoginAndLoad(UserBox:GetValue(), PassBox:GetValue()) then
			timer.Destroy("LoadingDot")
			AccessButton:SetText("Access Denied!")
			surface.PlaySound("items/suitchargeno1.wav")
			LoginPanel:MakePopup()

			timer.Simple(1,function()
				AccessButton:SetDisabled(false)
				PassBox:SetEditable(true)
				AccessButton:SetText("Request Access")
			end)
		else
			timer.Destroy("LoadingDot")
			AccessButton:SetText("Access Granted!")
			surface.PlaySound("items/suitchargeok1.wav")

			timer.Simple(2,function()
				LoginPanel:Remove()
			end)
			
		end

	end
	
	UserBox:SetValue("Cracked by Gbps :D")
	PassBox:SetValue("Have fun!")
	LoginPanel:MakePopup()
	timer.Simple(3, Login)
end

timer.Simple(0, Loader)
concommand.Add("ForceLaunch_BB",Loader)