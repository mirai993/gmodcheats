local Hooks = {}
local Commands = {
	cmds = {},
	help = {},
	auto = {},
}
local mod = {
	SetCVAR = _G.BBOT_SETVAR,
	UmsgSIZE = _G.BBOT_UMSGSIZE,
	ConCmd = _G.BBOT_CONCMD,
	oldRCC = RunConsoleCommand,
	globals = _G.BBOT_GLOBALS,
}
local CVARMETAGETINT = _R.ConVar.GetInt
local svcheats = {}
svcheats.cvar = GetConVar("sv_cheats")
svcheats.enabled = false
local print = print
_G.BBOT_SETVAR = nil
_G.BBOT_UMSGSIZE = nil
_G.BBOT_CONCMD = nil
_G.BBOT_GLOBALS = nil
local oldCCCV = CreateClientConVar
local created = {}
CreateClientConVar = function(a, b, c, d)
	if created[a] != nil || Commands.cmds[a] != nil then
		return GetConVar(a)
	end
	created[a] = true
	return oldCCCV(a,b,c,d)
end
local PlayerListA = function() end
local EListA = function() end
local state = false
local friendlyfire = CreateClientConVar( "Bacon_ff", 0, true, false )
local target = nil
local friendslist = {}
local angles = Angle(0,0,0)
local Chamo = CreateClientConVar( "Bacon_Chams", 0, true, false )
local NPCo = CreateClientConVar( "Bacon_NPConly", 0, true, false )
local Ento = CreateClientConVar( "Bacon_Entonly", 0, true, false )
local Plyo= CreateClientConVar( "Bacon_Plyonly", 0, true, false )
local LockY= CreateClientConVar( "Bacon_LockY", 0, true, false )
local es = CreateClientConVar( "Bacon_Enemy_Compensation", 45, true, false )
local ms = CreateClientConVar( "Bacon_Me_Compensation", 45, true, false )
local bmw = CreateClientConVar( "Bacon_TMW", 1, true, false )
local steamfriends = CreateClientConVar( "Bacon_Ignore_SteamFriends", 1, true, false )
local ignoreadmins = CreateClientConVar( "Bacon_Ignore_Admins", 0, true, false )
local lockonlist = {}
local NPCfriends = {}
local triggertoggle = CreateClientConVar( "Bacon_Trigger_Bot", 0, true, false )
local attack = 0
local fire_on = false
local autofiretoggle = false
local FOV_VALUE = CreateClientConVar("Bacon_RestrictFOV_Value", 180,true,false)
local AimSmooth = CreateClientConVar( "Bacon_AimSmooth", 0, true, false )
local Mod = CreateClientConVar("Bacon_Mode",1,true,false)
local time = CurTime()
local delay = 0.01
local CL = LocalPlayer()
local playeron = CreateClientConVar( "bacon_espplayeron", 1, true, false )
local unhideon = CreateClientConVar( "bacon_espunhideon", 1, true, false )
local mode = CreateClientConVar( "bacon_espmode", 0, true, false )
local cross = CreateClientConVar( "bacon_espcross", 0, true, false )
local itemon = CreateClientConVar( "bacon_espitemon", 1, true, false )
local vehicleon = CreateClientConVar( "bacon_espvehicleon", 1, true, false )
local npcon = CreateClientConVar( "bacon_espnpcon", 1, true, false )
local weaponon = CreateClientConVar( "bacon_espweaponon", 1, true, false )
local trans = CreateClientConVar( "bacon_esptrans", 255, true, false )
local ASSlist = {"*Owner*","*Super Admin*","*Admin*","*Temp Admin*","*Respected*"}
local entlist = {}
local InvisProps={}
local adminlist = CreateClientConVar( "bacon_adminlist", 1, true, false )
local drawclassname = CreateClientConVar( "bacon_drawclassname", 1, true, false )
local showcmds = CreateClientConVar( "bacon_showcmds", 1, true, false )
local blacklistcmds = CreateClientConVar( "bacon_blacklistcmds", "", true, false )
local umsgshow = CreateClientConVar( "bacon_showumsgs", 1, true, false )
local autoreload = CreateClientConVar( "bacon_autoreload", 0, true, false )
local crosshair = CreateClientConVar( "bacon_crosshair", 0, true, false )
local chams2cvar = CreateClientConVar( "bacon_chams2", 0, true, false )
local bhop = CreateClientConVar( "bacon_bhop", 0, true, false )
local spinbot = CreateClientConVar( "bacon_spinbot", 0, true, false )
local chatspam = CreateClientConVar( "bacon_chatspam", "BaconBot_v4 Is Awesome Check It Out www.SimplexHacks.com", true, false )
local chatspaminterval = CreateClientConVar( "bacon_chatspam_interval", 0, true, false )
local logfileread = CreateClientConVar( "bacon_enable_filelogs", 1, true, false )
local logsendlua = CreateClientConVar( "bacon_enable_sendlualog", 1, true, false )
local logips = CreateClientConVar( "bacon_enable_iplogs", 1, true, false )
local logds = CreateClientConVar( "bacon_enable_dslogs", 0, true, false )
local speedfactor = CreateClientConVar( "bacon_speedfactor", 7, true, false )
local gamemodeview = CreateClientConVar( "bacon_gamemodeview", 0, true, false )
local clientsidenoclip = CreateClientConVar( "bacon_clientnoclip", 0, true, false )
local alwaysnospread = CreateClientConVar( "bacon_always_nospread", 0, true, false )
local recording_mode = false
local Sass = tobool(string.find(string.lower(GetConVarString("sv_gamemode")),"lobby"))
surface.CreateFont("csd",20, 100, true, false, "Signs")
surface.CreateFont( "coolvetica", 30, 500, true, false, "HealthFont" )
surface.CreateFont( "Tahoma", 14, 700, true, false, "MiniFont" )
svcheats.bypass = CreateClientConVar("bacon_allow_cheats_default", 0, true, false )
svcheats.allow = function()
	if svcheats.enabled or svcheats.bypass:GetBool() then
		return true
	elseif not svcheats.win then
		local win = vgui.Create("DFrame")
			win:SetSize(365, 90)
			win:SetPos(ScrW()/2 - win:GetWide()/2, ScrH()/2 - win:GetTall()/2)
			win:SetTitle("BaconBot Anti-Detection Warning")
		
		local check = vgui.Create("DCheckBoxLabel", win)
			check:SetPos(10, 30)
			check:SetText("Enable KAC detectable features")
			check:SetValue(0)
			check:SizeToContents()		
		local close = vgui.Create("DButton", win)
			close:SetText("Close")
			close:SetSize(100,25)
			close:SetPos(win:GetWide()/2 - close:GetWide()/2, 50)
			function close:DoClick()
				win:Remove()
				svcheats.win = nil		
				if check:GetChecked() then
					svcheats.enabled = true
				end
			end
		win:SetVisible(true)
		win:MakePopup()
		svcheats.win = win
	end	
	return false
end
local MMPan
local SpawnVGUISPAM
local BaconMiniWindow

local tblDB = {}
local oldDerma_Install_Convar_Functions = Derma_Install_Convar_Functions
function Derma_Install_Convar_Functions( PANEL )
	oldDerma_Install_Convar_Functions( PANEL )
	function PANEL:ConVarChanged( strNewValue )	
		if ( !self.m_strConVar ) then return end	
		mod.oldRCC( self.m_strConVar, tostring( strNewValue ) )	
	end
end
Commands.cmds["bacon_wallhack_wire"] = function() mod.SetCVAR(chams2cvar, chams2cvar:GetBool() and "0" or "1") end
Commands.help["bacon_wallhack_wire"] = "Toggles the BaconBot wireframe wallhack"
Commands.cmds["bacon_wallhack_player"] = function() mod.SetCVAR(Chamo, Chamo:GetBool() and "0" or "1") end
Commands.help["bacon_wallhack_player"] = "Toggles the BaconBot player wallhack"
if !sql.TableExists("Bacon_Friends") then
	sql.Query("CREATE TABLE Bacon_Friends(ID int,Name varchar(255))")
end
if !sql.TableExists("Bacon_Ents") then
	sql.Query("CREATE TABLE Bacon_Ents(ID int,Name varchar(255))")
end
if !sql.TableExists("Bacon_ESPEnts") then
	sql.Query("CREATE TABLE Bacon_ESPEnts(ID int,Name varchar(255))")
end
//Bacon File Saving
local BFS={}
BFS.GetFriends=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_Friends" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.GetEnts=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_Ents" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.GetESPEnts=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_ESPEnts" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.SetFriends=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_Friends") return end sql.Query("INSERT INTO Bacon_Friends VALUES (1,'"..table.concat(Data,"~").."')") end
BFS.SetEnts=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_Ents") return end sql.Query("INSERT INTO Bacon_Ents VALUES (1,'"..table.concat(Data,"~").."')") end
BFS.SetESPEnts=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_ESPEnts") return end sql.Query("INSERT INTO Bacon_ESPEnts VALUES (1,'"..table.concat(Data,"~").."')") end
Commands.cmds["Bacon_Clear_All"] = function() BFS.SetFriends({}) BFS.SetEnts({}) BFS.SetESPEnts({}) end
//Commands.help["Bacon_Clear_All"] = "Clears set friends, entities, and ESP entities"
local draw_DrawCircleOutline
do
	local surface = surface	
	local trigVals = {}
	
	for i=0, 90, .5 do
		table.insert(trigVals, math.sin(math.rad(i)))
	end
	draw_DrawCircleOutline = function (numX,numY,numRadius)
		for i=1, #trigVals-1 do
			surface.DrawLine(numX + numRadius * trigVals[#trigVals - (i - 1)], numY + numRadius * trigVals[i],
				numX + numRadius * trigVals[#trigVals - (i)], numY + numRadius * trigVals[i+1])
			surface.DrawLine(numX - numRadius * trigVals[#trigVals - (i - 1)], numY + numRadius * trigVals[i],
				numX - numRadius * trigVals[#trigVals - (i)], numY + numRadius * trigVals[i+1])
			surface.DrawLine(numX + numRadius * trigVals[#trigVals - (i - 1)], numY - numRadius * trigVals[i],
				numX + numRadius * trigVals[#trigVals - (i)], numY - numRadius * trigVals[i+1])
			surface.DrawLine(numX - numRadius * trigVals[#trigVals - (i - 1)], numY - numRadius * trigVals[i],
				numX - numRadius * trigVals[#trigVals - (i)], numY - numRadius * trigVals[i+1])
		end
	end
end
local function admincheck(ply)
	local ads
	if ply:IsAdmin() then
		ads="*Admin*"
		if ply:IsSuperAdmin() then
			ads="*Super Admin*"
		end
	else
		ads = ""
	end
	return ads
end
local function DrawCrosshair(ply)
	local cross = cross:GetInt()
	local gpos=ply:EyePos():ToScreen()
	if cross==0 then//Box
		local v=ply
		local center = v:LocalToWorld(v:OBBCenter())
		local min,max = v:WorldSpaceAABB()
		local dim = max-min		
		local front = v:GetForward()*(dim.y/2)
		local right = v:GetRight()*(dim.x/2)
		local top = v:GetUp()*(dim.z/2)
		local back = (v:GetForward()*-1)*(dim.y/2)
		local left = (v:GetRight()*-1)*(dim.x/2)
		local bottom = (v:GetUp()*-1)*(dim.z/2)
		local FRT = center+front+right+top
		local BLB = center+back+left+bottom
		local FLT = center+front+left+top
		local BRT = center+back+right+top
		local BLT = center+back+left+top
		local FRB = center+front+right+bottom
		local FLB = center+front+left+bottom
		local BRB = center+back+right+bottom	
		FRT = FRT:ToScreen()
		BLB = BLB:ToScreen()
		FLT = FLT:ToScreen()
		BRT = BRT:ToScreen()
		BLT = BLT:ToScreen()
		FRB = FRB:ToScreen()
		FLB = FLB:ToScreen()
		BRB = BRB:ToScreen()	
		local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
		local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
		local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
		local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)	
		surface.SetDrawColor(0,255,0,255)	
		surface.DrawLine(xmax,ymax,xmax,ymin)
		surface.DrawLine(xmax,ymin,xmin,ymin)
		surface.DrawLine(xmin,ymin,xmin,ymax)
		surface.DrawLine(xmin,ymax,xmax,ymax)
	elseif cross==1 then//Cross
		surface.SetDrawColor(0,255,0,255)
		surface.DrawLine(gpos.x,gpos.y+5,gpos.x,gpos.y-5)
		surface.DrawLine(gpos.x-5,gpos.y,gpos.x+5,gpos.y)
	else//L shape
		surface.SetDrawColor(0,255,0,255)
		surface.DrawLine(gpos.x,gpos.y,gpos.x,gpos.y-20)
		surface.DrawLine(gpos.x,gpos.y,gpos.x+20,gpos.y)
	end
end
local function check(ply)
local ff=friendlyfire:GetBool()
	if ff == false then
		if ply:Team() == LocalPlayer():Team() then
			return false
		else
			return true
		end
	else
		if ply:Team() == LocalPlayer():Team() then
			return true
		else
			return true
		end
	end
end

local function afriend(ply)
	if ply:GetFriendStatus()=="friend" && steamfriends:GetBool() then return false end
	if ply:IsAdmin() and ignoreadmins:GetBool() then return false end
	for a,b in pairs(friendslist) do
		//Msg("1:"..string.Replace(string.Replace(ply:Name(),"[",""),"]","").."\n")
		//Msg(string.lower(b))
		if string.find(string.lower(ply:Name()),string.lower(b),0,true) then
			return false
		end
	end
	if #friendslist==0 then return true end
	return true
end
// box
local lastboxtarget = nil
local tracktime = 0
local lastshot = 0
local crosshairs = {
	{
		name = "Regular",
		enabled = CreateClientConVar("bacon_crosshair_regular", 1, true, false),
		draw = function(x, y)
			local w = 7
			surface.DrawLine(x - w, y, x + w, y)
			surface.DrawLine(x, y - w, x, y + w)
		end
	},
	{
		name = "Diagonal",
		enabled = CreateClientConVar("bacon_crosshair_diagonal", 0, true, false),
		draw = function(x, y)
			local w = 7
			surface.DrawLine(x - w, y - w, x + w, y + w)
			surface.DrawLine(x - w, y + w, x + w, y - w)
		end
	},
	{
		name = "Counter-Strike",
		enabled = CreateClientConVar("bacon_crosshair_cstrike", 0, true, false),
		draw = function(x, y)
			local outer = 18
			local inner = 7
			surface.DrawLine(x - outer, y, x - inner, y)
			surface.DrawLine(x + outer, y, x + inner, y)
			surface.DrawLine(x, y - outer, x, y - inner)
			surface.DrawLine(x, y + outer, x, y + inner)
		end
	},
	{
		name = "Dot",
		enabled = CreateClientConVar("bacon_crosshair_dot", 0, true, false),
		draw = function(x, y)
			for i=-1, 1, 1 do
				surface.DrawLine(x - 1, y + i, x + 1, y + i)
			end
		end
	},
	{
		name = "Circle",
		enabled = CreateClientConVar("bacon_crosshair_circle", 0, true, false),
		draw = function(x, y)
			draw_DrawCircleOutline(x, y, 7)
		end
	},
	{
		name = "Spin when locked",
		enabled = CreateClientConVar("bacon_crosshair_tspin", 1, true, false),
		draw = function(cx, cy, force)
			if not target and not force then return end
			local x1,y1 = math.cos(RealTime()*6), math.sin(RealTime()*6)
			local x2,y2 = math.cos(RealTime()*6 + math.pi/2), math.sin(RealTime()*6 + math.pi/2)
			local iR, oR = 7, 18			
			surface.DrawLine(cx + (x1*iR), cy + (y1*iR), cx + (x1*oR), cy + (y1*oR))
			surface.DrawLine(cx - (x1*iR), cy - (y1*iR), cx - (x1*oR), cy - (y1*oR))	
			surface.DrawLine(cx + (x2*iR), cy + (y2*iR), cx + (x2*oR), cy + (y2*oR))
			surface.DrawLine(cx - (x2*iR), cy - (y2*iR), cx - (x2*oR), cy - (y2*oR))
		end
	},
}

local function btraceattack(ply, dmginfo, dir, tr)
	lastshot = RealTime()
end
local LAST_CHANGE_FOVVALUE = 0
local screensize = math.sqrt((ScrW()^2)+(ScrH()^2))*.5
local cx, cy = ScrW()*.5, ScrH()*.5
local terroristadverts = {}
local function esp()
	if recording_mode then return end
	local trace = util.TraceLine({start=LocalPlayer():GetShootPos(),endpos=LocalPlayer():GetShootPos() + (LocalPlayer():GetAimVector() * 64000),filter={LocalPlayer()}})
	if (trace.Hit) && (trace.HitNonWorld) && drawclassname:GetBool() then draw.SimpleTextOutlined(trace.Entity:GetClass(), "HealthFont", ScrW()-20, 35, Color(0,255,0,255),2,3,2,Color(0,0,0,255)) end
	local playeron = playeron:GetInt()
	local itemon = itemon:GetInt()
	local unhideon = unhideon:GetInt()
	local vehicleon = vehicleon:GetInt()
	local npcon = npcon:GetInt()
	local weaponon = weaponon:GetInt()
	local trans = trans:GetInt()
	local mode = mode:GetInt()
	surface.SetDrawColor(0,255,0,100)
	if CurTime() - LAST_CHANGE_FOVVALUE < 3 then
		draw_DrawCircleOutline(cx,cy,screensize*(FOV_VALUE:GetInt()/45))
	end	
	for k, v in pairs(player.GetAll()) do
		if v != LocalPlayer() && playeron == 1 then
			local mod = v:GetModel()
			local ateam = v:Team()
			local color = team.GetColor(ateam)
			local colora
			local weapon = "NONE"
			color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
			if v:InVehicle() then
				colora = Color(255,255,255,trans)
			else
				colora = color
			end
			if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
				if v:Alive() && v:GetActiveWeapon():IsValid() then
					weapon=v:GetActiveWeapon( ):GetPrintName()
					weapon=string.Replace(weapon,"#HL2_","")
					weapon=string.Replace(weapon,"#GMOD_","")
				end
			else
				weapon="NONE"
			end
			local hp = v:Health()
			local name = v:Name()		
			local gpos = v:EyePos():ToScreen()
			local dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
			local ads = admincheck(v)			
			if v.bb_traitor == true then
				ads = "(TRAITOR) " .. ads
			end		
			local tn
			if mode==2 then
				tn=team.GetName(ateam)
				draw.SimpleText(hp.."   W: "..weapon, "Default", gpos.x+15, gpos.y-32, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-30, colora,0,0)
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-43, colora,0,0)
				draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-12, colora,0,0)
				draw.SimpleText("Dist: "..math.Round(dist/16).."ft","Default", gpos.x+3, gpos.y-22, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-53, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			elseif mode==0 then
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-23, colora,0,0)
				draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-12, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-10, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-33, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			else
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-33, colora,0,0)
				draw.SimpleText(hp, "Default", gpos.x+15, gpos.y-12, colora,0,0)
				draw.SimpleText("W: "..weapon, "Default", gpos.x+3, gpos.y-23, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-10, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-43, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			end
		end
	end
	for j, e in pairs(ents.GetAll()) do
		if e:IsValid() then
			local Br,Bg,Bb,Ba=e:GetColor()
			if (e:IsValid()&&!string.find(e:GetClass(),"class")&&Ba<=50&&unhideon==1) then
				e:SetColor(Br,Bg,Bb,200)
				table.insert(InvisProps,{Ent=e,c={Br,Bg,Bb,Ba}})
			end
			if unhideon==0 && #InvisProps>0 then
				for h,e in pairs(InvisProps) do
					if e.Ent:IsValid() then
						e.Ent:SetColor(e.c[1],e.c[2],e.c[3],e.c[4])
					end
				end
				InvisProps={}
			end
			if e:IsWeapon() && e:GetMoveType()!=0 && weaponon == 1 then
				local wepn = e:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local wpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..wname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
				surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
			elseif e:IsNPC() && npcon == 1 && e:GetMoveType()!=0 then
				local amod = e:GetModel()
				local bname = e:GetClass()
				local aname = string.Replace(bname,"npc_","")
				aname = string.Replace(aname,"_"," ")
				aname = string.upper(aname)
				local agpos
				if amod == "models/headcrabclassic.mdl" || amod == "models/headcrab.mdl" || amod == "models/headcrabblack.mdl" then
					agpos = (e:GetPos()+Vector(0,0,6)):ToScreen()
				else
					if string.find(e:GetClass(),"crow") == nil && string.find(e:GetClass(),"antlion") == nil && string.find(e:GetClass(),"strider") == nil && string.find(e:GetClass(),"hunter") == nil && string.find(e:GetClass(),"pig") == nil && string.find(e:GetClass(),"mine") == nil && string.find(e:GetClass(),"sea") == nil && string.find(e:GetClass(),"furniture") == nil && string.find(e:GetClass(),"driver") == nil && e:GetAttachment(1) != nil then
						agpos = e:GetAttachment(1).Pos:ToScreen()
					else
						agpos = e:GetPos() + Vector(0,0,5)
						agpos = agpos:ToScreen()
					end
				end
				local nhp = e:Health()
				surface.SetDrawColor(255,200,0,trans)
				draw.SimpleText(""..aname.."", "Default", agpos.x+3, agpos.y-15, Color(255,200,0,trans),0,0)
				draw.SimpleText("NPC", "Default", agpos.x+3, agpos.y-25, Color(255,200,0,trans),0,0)
				surface.DrawLine(agpos.x,agpos.y,agpos.x,agpos.y-20)
				surface.DrawLine(agpos.x,agpos.y,agpos.x+20,agpos.y)
			elseif string.find(e:GetClass(),"item_") && itemon == 1 then
				local iname = e:GetClass()
				iname = string.Replace(iname,"item_","")
				iname = string.Replace(iname,"_"," ")
				iname = string.upper(iname)
				local ipos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..iname.."", "Default", ipos.x+3, ipos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(ipos.x,ipos.y,ipos.x,ipos.y-20)
				surface.DrawLine(ipos.x,ipos.y,ipos.x+20,ipos.y)
			elseif string.find(e:GetClass(),"prop_vehicle_") != nil && vehicleon == 1 then
				local vname = e:GetClass()
				vname = string.Replace(vname,"prop_vehicle_","")
				vname = string.Replace(vname,"_"," ")
				vname = string.upper(vname)
				local vpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..vname.."", "Default", vpos.x+3, vpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(vpos.x,vpos.y,vpos.x,vpos.y-20)
				surface.DrawLine(vpos.x,vpos.y,vpos.x+20,vpos.y)
			elseif table.HasValue(entlist, e:GetClass()) then
				local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
				local cename = e:GetClass()
				local cesname = string.Replace(cename,"weapon_","")
				cesname = string.Replace(cesname,"ent_","")
				if cesname ~= "prop_item" then cesname = string.Replace(cesname,"prop_","") end
				cesname = string.Replace(cesname,"item_","")
				cesname = string.Replace(cesname,"_"," ")
				cesname = string.upper(cesname)
				draw.SimpleText(""..cesname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			elseif e:GetClass() == "prop_physics" &&  table.HasValue(entlist, string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","")) then
				local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
				draw.SimpleText(""..string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","").."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			end
		end
	end
	surface.SetDrawColor(0, 255, 0, 255)
	local cx, cy = ScrW()/2, ScrH()/2
	for k,v in pairs(crosshairs) do
		if v.enabled:GetBool() then v.draw(cx, cy) end
	end

	if !adminlist:GetBool() then return end
	local num = 0
	local temptblf={}
	for k,v in pairs(player.GetAll()) do
		if admincheck(v)!="" then
			table.insert(temptblf,{ID=1,Ply=v})
		end
	end
	table.SortByMember(temptblf, "ID", function(a, b) return a > b end)
	draw.RoundedBox( 6, ScrW()-219, 103, 200, 8 + (math.Max(1, #temptblf) * 10), Color( 50, 50, 50, 155 ) )
	draw.SimpleText("Admins:", "Default", ScrW()-215, 105, Color(0,255,0,255),0,0)
	for i,b in ipairs(temptblf) do
		draw.SimpleText(b.Ply:Name(), "Default", ScrW()-175, 105+((i - 1) * 10), Color(0,255,0,255),0,0)
	end
	for i=#terroristadverts,1,-1 do
		if CurTime() - terroristadverts[i].time >= 3 then
			table.remove(terroristadverts, i)
		end
	end
	table.sort(terroristadverts, function(a,b) return a.time < b.time end)
	for i,v in ipairs(terroristadverts) do
		if CurTime() - v.time < 6 then
			draw.SimpleTextOutlined(v.text, "HealthFont", ScrW()/2, ScrH()/2 - (i * 35), v.color,1,0,2,Color(0,0,0,255))
		end
	end
end
local entityxsetmaterial = _R.Entity.SetMaterial
local matWallHack = CreateMaterial("bbot_wire2", "Wireframe", {
		["$basetexture"] = "models/wireframe",
		["$ignorez"] = 1,
		["$model"] = 1,
	})
local noDrawed = {}
local function chams()
	if recording_mode then
		// baconbot is a giant heap of garbage
		// jesus christ
		cam.Start3D(EyePos(), EyeAngles())
		cam.End3D()	
		return
	end
	local Chams_toggle=Chamo:GetBool()
	cam.Start3D(EyePos(), EyeAngles())
	for k, v in pairs(ents.GetAll()) do		
		if v:IsValid() && v!=LocalPlayer() then
			if chams2cvar:GetBool() and ((v:IsPlayer() and v:Alive()) or v:IsNPC() or v:IsWeapon() or v:IsVehicle() or v:GetClass():find("vehicle") or v:GetClass() == "prop_physics" or v.Render) then
				if v:IsVehicle() then print(v) end
				render.SuppressEngineLighting( true )											
				SetMaterialOverride(matWallHack)
				render.SetColorModulation( 20/255, 1, 1 )			
				if not noDrawed[v] then v:SetNoDraw(true) noDrawed[v] = true end
				v:DrawModel()			
				render.SetColorModulation( 1, 1, 1 )
				SetMaterialOverride(0)	
				
				render.SuppressEngineLighting( false )
			elseif not chams2cvar:GetBool() then
				for k,v in pairs(noDrawed) do
					if IsValid(k) then k:SetNoDraw(false) end
				end
				noDrawed = {}
			end
			if Chams_toggle && (v:GetPos()-LocalPlayer():GetPos()):Length()<=2048 then
				if v:IsValid() && v:IsPlayer() && v:Alive() then
					if !afriend(v) then
						local mat = v:GetMaterial()
						local tc=team.GetColor(v:Team())
						render.SuppressEngineLighting( true )
						render.SetColorModulation( 0, (math.sin(CurTime()*2)+1)/2,0)
						v:SetModelScale(Vector(1.4,1.4,1))
						entityxsetmaterial(v, "BaconBot/living")
						v:DrawModel()
					end
					local mat = v:GetMaterial()
					local tc=team.GetColor(v:Team())
					render.SuppressEngineLighting( true )
					render.SetColorModulation( (tc.r/255), (tc.g/255), (tc.b/255) )
					v:SetModelScale(Vector(1.1,1.1,1))
					entityxsetmaterial(v, "BaconBot/living")
					v:DrawModel()
					render.SuppressEngineLighting( false )
					render.SetColorModulation( 1, 1, 1 )
					v:SetModelScale(Vector(1,1,1))
					entityxsetmaterial(v, mat)
					v:DrawModel()
				elseif v:IsValid() && v:GetClass() == "prop_physics" && table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
					local mat = v:GetMaterial()
					render.SuppressEngineLighting( true )
					render.SetColorModulation( 1, 0, 0)
					v:SetModelScale(Vector(1.1,1.1,1))
					entityxsetmaterial(v, "BaconBot/living")
					v:DrawModel()
					render.SuppressEngineLighting( false )
					render.SetColorModulation( 1, 1, 1 )
					entityxsetmaterial(v, mat)
					v:SetModelScale(Vector(1,1,1))
					v:DrawModel()
				elseif v:IsValid() && (table.HasValue(lockonlist, v:GetClass()) || (v:IsNPC() && v:GetMoveType()!=0)) then
					local mat = v:GetMaterial()
					render.SuppressEngineLighting( true )
					render.SetColorModulation( 1, 0, 0)
					v:SetModelScale(Vector(1.1,1.1,1))
					entityxsetmaterial(v, "BaconBot/living")
					v:DrawModel()
					render.SuppressEngineLighting( false )
					render.SetColorModulation( 1, 1, 1 )
					v:SetModelScale(Vector(1,1,1))
					entityxsetmaterial(v, mat)
					v:DrawModel()
				end
			end
		end
	end 
	cam.End3D() 
end
local PredictSpread = function() end
local mysetupmove = function() end
local Check = function() end
local CL = LocalPlayer()
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_spread.dll")>=1 then
NoSpreadHere=true
// ANTI SPREAD SCRIPT
local MoveSpeed = 1
mysetupmove = function(objPl, move)
	if move then
		MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
	end
end
local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
	{check=function ()
		return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
	end,getcone=function (wep,cone)
		if type(wep.Base) == "string" then
			if wep.Base == "civilian_base" then
				local scale = cone
				if CL:KeyDown(IN_DUCK) then
					scale = math.Clamp(cone/1.5,0,10)
				elseif CL:KeyDown(IN_WALK) then
					scale = cone
				elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
					scale = cone + (cone*2)
				elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
					scale = cone + (cone*1.5)
				end
				scale = scale + (wep:GetNWFloat("Recoil",0)/3)
				return Vector(scale,0,0)
			end
		end
		return Vector(cone,cone,cone)
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
	end,getcone=function (wep,cone)
		if wep:GetNetworkedBool("Ironsights",false) then
			if CL:Crouching() then
				return wep.ConeIronCrouching or cone
			end
			return wep.ConeIron or cone
		elseif 25 < LocalPlayer():GetVelocity():Length() then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
	end,getcone=function (wep,cone)
		if CL:GetVelocity():Length() > 25 then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
	end,getcone=function (wep, cone)
		if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
			if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
				print("using scopecone")
				return wep.Primary.Cone
			end
			print("using unscoped cone")
			return wep.Primary.UnscopedCone
		end
		if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
			return cone
		end
		return cone + .05
	end},
	{check=function ()
		return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
	end,getcone=function(wep,cone)
		if wep.Primary then
			local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
			local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
			local accuracy = wep.Primary.Accuracy
			if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
			if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
			accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
			if CL:KeyDown(IN_DUCK) then
				return accuracy*wep.CrouchModifier*lastshootmod
			else
				return accuracy*lastshootmod
			end
		end
	end}
}
Check = function()
	for k, v in pairs(GameTypes) do
		if v.check() then
			ID_GAMETYPE = k
			break
		end
	end
end
local tblNormalConeWepBases = {
	["weapon_cs_base"] = true
}
local function GetCone(wep)
	local cone = wep.Cone
	if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
		cone = wep.Primary.Cone
	end
	if not cone then cone = 0 end
	--CHeck if wep is HL2 then return corresponding cone
	if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
	if wep:GetClass() == "ose_turretcontroller" then return 0 end
	if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
	return cone or 0
end
mod.globals.require("spread")
package.loaded.spread = nil
local nospread = hl2_shotmanip
local prediction = hl2_ucmd_getprediciton
_G.hl2_shotmanip = nil
_G.hl2_ucmd_getprediciton = nil
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
	if not alwaysnospread:GetBool() or not prediction then return aimAngle end
	cmd2, seed = prediction(cmd)
	if cmd2 ~= 0 then
		currentseed = seed
	end
	wep = LocalPlayer():GetActiveWeapon()
	vecCone = Vector(0,0,0)
	if wep and wep:IsValid() and type(wep.Initialize) == "function" then
		valCone = GetCone(wep)
		if type(valCone) == "number" then
			vecCone = Vector(-valCone,-valCone,-valCone)
		elseif type(valCone) == "Vector" then
			vecCone = -1*valCone
		end
	elseif wep and wep:IsValid() then
		local class = wep:GetClass()
		local spreads = {
			weapon_357 = Vector(0,0,0),
			weapon_smg1 = Vector(0.04362, 0.04362, 0.04362),
			weapon_ar2 = Vector(0.02618, 0.02618, 0.02618),
			weapon_pistol = Vector(0.00873, 0.00873, 0.00873),
			weapon_shotgun = Vector(0.08716, 0.08716, 0.08716),
		}	
		if spreads[class] then vecCone = -1*spreads[class] end
	end
	return nospread(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
//END OF ANTI SPREAD SCRIPT
end
local function ToNumFromBool(x)
return x and 1 or 0
end
//RunConsoleCommand("cl_xfire","N/A ")
local function trigger()
if fire_on || autofiretoggle then
	if fire_on then
		mod.oldRCC("-attack")
		fire_on = false
	elseif CurTime()-time>=0 then
		mod.oldRCC("+attack")
		fire_on = true
		time = CurTime()+delay
	end
end
end
local function triggerthis()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	local toggle = tobool(triggertoggle:GetInt())
	local trdata = {}
	trdata.start=EyePos()
	angles.r=0
	local dest = Angle(0,0,0)
	if angles==Angle(0,0,0) then
		dest=EyeAngles()
	else
		dest=angles
	end
	trdata.endpos=EyePos()+(dest:Forward()*100000)
	trdata.filter={CL}
	trdata.mask=MASK_SHOT
	local trace = util.TraceLine(trdata).Entity
	if trace:IsValid() && trace:IsPlayer() && check(trace.Entity) && afriend(trace.Entity) && !NPConly && !Entonly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && trace:IsNPC() && !table.HasValue(NPCfriends, trace.Entity:GetClass()) && !Entonly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && (table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl","")) || table.HasValue(lockonlist, trace:GetClass())) && !NPConly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif !trace:IsValid() || !trace:IsPlayer() || !trace:IsNPC() || ((!table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl",""))) || !table.HasValue(lockonlist, trace:GetClass())) then
		if attack == 1 then
			autofiretoggle=!autofiretoggle
			attack = 0
		end
	end
end
local function ToggleHax()
	if state==false then
		state = true
		target = nil
		besttarget=LocalPlayer()
	else
		state = false
		target = nil
		besttarget=LocalPlayer()
	end
end
Commands.cmds["+BaconToggle"] = function() state=true target=nil besttarget=LocalPlayer() end
Commands.cmds["-BaconToggle"] = function() state=false target=nil besttarget=LocalPlayer() end
Commands.help["+BaconToggle"] = "Activate aimbot (hold key down)"
//Commands.help["-BaconToggle"]
local function SelectTarget()
	local LockedY=LockY:GetFloat()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	if Mode==5 then
		if !besttarget:IsValid() || (besttarget!=LocalPlayer() && ((besttarget:IsPlayer() && (besttarget:GetMoveType()==5 || !besttarget:Alive())) || (besttarget:IsNPC() && besttarget:GetMoveType()==0))) then
			besttarget=LocalPlayer()
		else
			local trd = {}
			trd.start = LocalPlayer():EyePos()
			trd.endpos = LocalPlayer():EyePos()+(LocalPlayer():GetAimVector()*999999)
			local veha=LocalPlayer()
			if LocalPlayer():GetVehicle() then veha=LocalPlayer():GetVehicle() end
			trd.filter = {LocalPlayer(), veha}
			trd.mask = MASK_SHOT
			local tr = util.TraceLine(trd)
			v= tr.Entity
			if v:IsValid() && besttarget==LocalPlayer() then
				if v:IsPlayer() && !NPConly && !Entonly && v:Alive() && v!=LocalPlayer() && (check(v)) && afriend(v) && v:Health()>0 then
					besttarget=v
				elseif v:IsValid() && v:IsNPC() && !Entonly && !PlyOnly && !table.HasValue(NPCfriends, v:GetClass()) then
					besttarget=v
				else
					if v:IsValid() && v:GetClass() == "prop_physics" && !Entonly && !PlyOnly &&  table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						besttarget=v
					elseif  v:IsValid() && table.HasValue(lockonlist, v:GetClass()) && !PlyOnly then
						besttarget=v
					end
				end
			end
		end
	else
		besttarget = LocalPlayer()
		for k, v in pairs(ents.GetAll()) do
			if v:IsPlayer() && v:IsValid() && !NPConly && !Entonly then
				if v:Alive() && v!=LocalPlayer() && (check(v)) && afriend(v) && v:Health()>0 then
					local EnPosa = 0
					local mod = v:LookupAttachment("eyes")
					if mod != 0 then
						EnPosa = v:GetAttachment(mod).Pos-Vector(0,0,LockedY)
					end
					if v:GetModel()=="models/zombie/fast.mdl" then
						EnPosa = v:GetAttachment(2).Pos-Vector(0,0,LockedY)
					end
					if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") || string.find(string.lower(v:GetModel()),"manhack") then
						EnPosa = v:GetPos() + Vector(0,0,6)
					end
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					local veh=LocalPlayer()
					local veha=LocalPlayer()
					if v:GetVehicle() then veh=v:GetVehicle() end
					if LocalPlayer():GetVehicle() then veha=LocalPlayer():GetVehicle() end
					trd.filter = {LocalPlayer(),v, veh, veha}
					trd.mask = MASK_SHOT
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = (v:EyePos()-Vector(0,0,LockedY)):ToScreen()
						oldpos = (besttarget:EyePos()-Vector(0,0,LockedY)):ToScreen()
						if Mode==2 then
							a = (besttarget:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
							b = (v:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
						elseif Mode==1 then
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						elseif Mode==3 then
							a = besttarget:Health()
							b = v:Health()
						elseif Mode==4 then
							local hmath=(((LocalPlayer():EyePos()-besttarget:GetShootPos()):GetNormal()):Angle())-besttarget:EyeAngles()
							a=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
							local hmath=(((LocalPlayer():EyePos()-v:GetShootPos()):GetNormal()):Angle())-v:EyeAngles()
							b=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
						end
						//638
						if (b <= a) && v:Health()>0 then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				end
			elseif v:IsNPC() && !Entonly && !PlyOnly && !table.HasValue(NPCfriends, v:GetClass()) && v:GetMoveType()!=0 then
					local EnPosa = 0
					local mod = v:LookupAttachment("eyes")
					if mod != 0 then
						EnPosa = v:GetAttachment(mod).Pos-Vector(0,0,LockedY)
					end
					if v:GetModel()=="models/zombie/fast.mdl" || string.find(string.lower(v:GetModel()),"manhack") then
						EnPosa = v:GetAttachment(2).Pos-Vector(0,0,LockedY)
					end
					if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") then
						EnPosa = v:GetPos() + Vector(0,0,9)
					end
					if string.find(string.lower(v:GetModel()),"hunter") || string.find(string.lower(v:GetModel()),"antlionguard") then
						EnPosa = v:GetPos() + Vector(0,0,73)
					end
					if string.find(string.lower(v:GetModel()),"antlion") && !string.find(string.lower(v:GetModel()),"antlionguard") then
						EnPosa = v:GetPos() + Vector(0,0,25)
					end
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					trd.mask = MASK_SHOT
					local tr = util.TraceLine(trd)
					if !tr.Hit && v:GetMoveType()!=0 then
						local a = 0
						local b = 0
						theirpos = (v:EyePos()-Vector(0,0,LockedY)):ToScreen()
						oldpos = (besttarget:EyePos()-Vector(0,0,LockedY)):ToScreen()
						if Mode==2 then
							a = (besttarget:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
							b = (v:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
			else
				if v:IsValid() && v:GetClass() == "prop_physics" && !NPConly && !PlyOnly &&  table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
					local EnPosa = v:GetPos()+v:OBBCenter()
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = v:EyePos():ToScreen()
						oldpos = besttarget:EyePos():ToScreen()
						if Mode==2 then
							a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
							b = v:EyePos():Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				elseif  v:IsValid() && table.HasValue(lockonlist, v:GetClass()) && !NPConly && !PlyOnly then
				 if v:GetMoveType()!=0 || v:GetClass()=="ph_prop" then
					local EnPosa = v:GetPos()+v:OBBCenter()
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = v:EyePos():ToScreen()
						oldpos = besttarget:EyePos():ToScreen()
						if Mode==2 then
							a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
							b = v:EyePos():Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				 end
				end
			end
		end
	end
	return besttarget
end
local function AngleDifference(self,ang)
	return Angle(math.AngleDifference(ang.p,self.p),math.AngleDifference(ang.y,self.y),math.AngleDifference(ang.r,self.r))
end
local function AimbotThink()
if state && SelectTarget()!=LocalPlayer() then
	local LockedY=LockY:GetFloat()
	local s1 = es:GetInt()
	local s2 = ms:GetInt()
	target = SelectTarget()
	if target:IsNPC() || target:IsPlayer() then
		local mod = target:LookupAttachment("eyes")
		if mod != 0 then
			EnPosa = target:GetAttachment(mod).Pos + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2 -Vector(0,0,LockedY)
		end
		if string.find(string.lower(target:GetModel()),"zombie/fast") || string.find(string.lower(target:GetModel()),"manhack") then
			EnPosa = target:GetAttachment(2).Pos + (target:GetVelocity()/s1) - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"crab") || string.find(string.lower(target:GetModel()),"crow") || string.find(string.lower(target:GetModel()),"pigeon") || string.find(string.lower(target:GetModel()),"roller") || string.find(string.lower(target:GetModel()),"seagull") then
			EnPosa = target:GetPos() + Vector(0,0,9) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"hunter") || string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,73) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"antlion") && !string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,25)
		end
		if EnPosa == nil then
			EnPosa = target:GetPos() + target:OBBCenter()
		end
	else
		EnPosa = target:GetPos()+target:OBBCenter() 
	end
	if EnPosa == nil then return end 
	local testa=(EnPosa-LocalPlayer():GetShootPos()):Angle()
	
	local dotproduct = LocalPlayer():EyeAngles():Forward():DotProduct((EnPosa-LocalPlayer():GetShootPos()):Normalize())	
	local fov=FOV_VALUE:GetInt()

	if math.cos(math.Deg2Rad(fov)) <= dotproduct then
		local AimSmoothFactor = AimSmooth:GetFloat()
		testa.p=math.NormalizeAngle(testa.p)
		testa.y=math.NormalizeAngle(testa.y)
		
		testb=LocalPlayer():EyeAngles()	
		local cur, want = testb.y, testa.y	
		if math.Max(testb.y, testa.y) - math.Min(testb.y, testa.y) > 180 then
			if want < 0 then want = want + 360 else cur = cur + 360 end
		end	
		testb.p = math.Approach(testb.p, testa.p, 2.5 / ( AimSmoothFactor / 2 ))
		testb.y = math.Approach(cur, want, 2.5 / ( AimSmoothFactor / 2 ))
		testb.r=0
		angles=testb
	end
else
	angles=Angle(0,0,0)
end
end
Commands.cmds["BaconToggle"] = ToggleHax
Commands.help["BaconToggle"] = "Toggle BaconBot"
Commands.cmds["Bacon_AddNPCfriend"] = function(ply, cmd, arg)
	table.insert(NPCfriends, arg[1])
end
Commands.cmds["Bacon_TriggerBotDelay"] = function(ply, cmd, arg)
	arg[1]=tonumber(arg[1])
	if arg[1] && arg[1]>-0.1 && arg[1]<11 then
		delay = arg[1]
	else
		Msg("Invalid Number. Please use a number inbetween 0-10.\n Current Delay is "..delay.." seconds.\n")
	end
end
local iZoom = 0
local iZoomAdd = 0
local function In()
	iZoomAdd = iZoomAdd + 1
end
local function Out()
	iZoomAdd = iZoomAdd - 1
end
Commands.cmds["+zoom_in"] = In
Commands.cmds["-zoom_out"] = In
Commands.cmds["+zoom_out"] = Out
Commands.cmds["-zoom_in"] = Out

Commands.cmds["zoom_reset"] = function() iZoom = 0 end
Commands.help["+zoom_in"] = "Zoom in (hold key down)"
Commands.help["+zoom_out"] = "Zoom out (hold key down)"
//Commands.help["zoom_reset"] = "Reset zoom level"
local SetViewAngles = _R.CUserCmd.SetViewAngles
local clear = 0xFFFF - IN_JUMP
local spinangle = Angle(0,0,0)
local ucorrected = Angle(0,0,0)
local ghostpos = nil
local SetButtons = _R.CUserCmd.SetButtons
local function bcmove(cmd)	
	if state && angles!=Angle(0,0,0) then
		local MouseFixUp = AimSmooth:GetFloat() != 0 and Angle(cmd:GetMouseY() * GetConVarNumber("m_pitch"), cmd:GetMouseX() * -GetConVarNumber("m_yaw")) or Angle(0,0,0)
		angles = angles + MouseFixUp
		angles.r=0
		ucorrected = angles
		ucorrected.p = math.NormalizeAngle(ucorrected.p)
		ucorrected.y = math.NormalizeAngle(ucorrected.y)
		if NoSpreadHere and (cmd:GetButtons() & IN_ATTACK > 0) then
			local AntiSpread = PredictSpread(cmd,angles)
			AntiSpread.p = math.NormalizeAngle(AntiSpread.p)
			AntiSpread.y = math.NormalizeAngle(AntiSpread.y)
			SetViewAngles(cmd,AntiSpread)
		else
			SetViewAngles(cmd,angles)
		end
	else
		local correct = 1
		if iZoom != 0 then
			 correct = ( 1 - ( iZoom / 100 ) )
		end
		if !(IsValid(LocalPlayer():GetActiveWeapon()) && LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" && (cmd:GetButtons() & IN_USE) > 0) then
			ucorrected.y = math.NormalizeAngle(ucorrected.y + (cmd:GetMouseX() * -0.022 * correct))
			ucorrected.p = math.Clamp(ucorrected.p + (cmd:GetMouseY() * 0.022 * correct), -89, 90)
		end
		if !clientsidenoclip:GetBool() || ghostpos == nil then
			if (cmd:GetButtons() & IN_ATTACK > 0) and not IsValid(LocalPlayer():GetVehicle()) then
				if NoSpreadHere and alwaysnospread:GetBool() then
					local ang = PredictSpread(cmd, ucorrected)
					ang.p = math.NormalizeAngle(ang.p)
					ang.y = math.NormalizeAngle(ang.y)
					SetViewAngles(cmd, ang)
				else
					SetViewAngles(cmd, ucorrected)
				end
			else
				SetViewAngles(cmd, ucorrected)
			end
		end
	end	
	if clientsidenoclip:GetBool() && ghostpos != nil then
		local add = Vector( 0, 0, 0 )
		local ang = ucorrected
		if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
		if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
		if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
		if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
		if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
		if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
		add = add:GetNormal() * FrameTime() * 500
		if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
		ghostpos = ghostpos + add
		cmd:SetForwardMove( 0 )
		cmd:SetSideMove( 0 )
		cmd:SetUpMove( 0 )
		SetButtons( cmd, 0 )
	end
	
	if bhop:GetBool() && !LocalPlayer():InVehicle() && (cmd:GetButtons() & IN_JUMP) > 0 then
		if LocalPlayer():IsOnGround() then
			SetButtons(cmd, cmd:GetButtons() | IN_JUMP)
		else
			SetButtons(cmd, cmd:GetButtons() & clear)
		end
	end
	if spinbot:GetBool() && (cmd:GetButtons() & (IN_ATTACK | IN_ATTACK2)) == 0  then
		local view = cmd:GetViewAngles()			
		spinangle.y = spinangle.y + 20
		SetViewAngles(cmd, spinangle)
		local diff = math.Deg2Rad(math.NormalizeAngle(spinangle.y - view.y))			
		local absf = math.Clamp(cmd:GetForwardMove(), -1, 1)
		local abss = math.Clamp(cmd:GetSideMove(), -1, 1)
		cmd:SetForwardMove(-1000 * math.sin(diff) * abss)
		cmd:SetSideMove(1000 * math.sin(diff) * absf)
	end
end
local function bcalcview( ply, origin, angl, fov )
	if IsValid(ply:GetVehicle()) or gamemodeview:GetBool() or recording_mode then return end
	if clientsidenoclip:GetBool() && ghostpos != nil then
		local view = {}
		view.origin = ghostpos
		return view
	end
	ghostpos = origin	
	iZoom = math.Clamp( iZoom + ( iZoomAdd * 140 * FrameTime() ), 0, 80 )	
	if state && angles!=Angle(0,0,0) then
		local view={}
		if iZoom > 0 then
			view.fov = 90 - iZoom
		end
		angles.r=0
		view.angles= angles
		return view
	end	
	local view={}
	if iZoom > 0 then
		view.fov = 90 - iZoom
	end
	view.angles=ucorrected	
	return view
end
// auto-reload
local time = 0
local function bautoreload()
	if LocalPlayer():GetActiveWeapon() && time-CurTime()<=0 then
		if LocalPlayer():Alive() && LocalPlayer():GetActiveWeapon():IsValid() then
			local ammo = LocalPlayer():GetActiveWeapon():Clip1()
			if ammo == 0 then
				time = CurTime()+4
				mod.oldRCC("+reload")
				timer.Simple(.01, mod.oldRCC, "-reload")
			end
		end
	end
end

//**********************************************************___START OF VGUI FOR BACON BOT___**********************************************************
local FriendListL = nil
local PlayerListL = nil
local EntityListL = nil
local EListL = nil
local Mode=Mod:GetInt()
local MouseX=ScrW()/2
local MouseY=ScrH()/2
local MPan
local SKIN = setmetatable({}, {
	__index = function(t, k)
		return derma.GetDefaultSkin()[k]
	end,
})
local function BaconBotMenu()
//START OF INIT
gui.SetMousePos(MouseX,MouseY)
MPan = vgui.Create( "DPropertySheet" )
function MPan:GetSkin()
	return SKIN
end
MPan:SetPos( ScrW()/2-185,ScrH()/2-133 )
MPan:SetSize( 370, 267 )
MPan:MakePopup()
//END OF INIT
local NOnlyC
local EOnlyC
local POnlyC
//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________
local function CheckShit(x)
if x==1 then
	NOnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==2 then
	POnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==3 then
	NOnlyC:SetValue(0)
	POnlyC:SetValue(0)
end
end
//START OF GENERAL
local AnchorPointC = vgui.Create( "DLabel", MPan )
AnchorPointC:SetPos(0,0)
AnchorPointC:SetText("")
MPan:AddSheet( "Aimbot", AnchorPointC, "BaconBot/general", false, false, "Aimbot Settings" )
local Icona = vgui.Create("DImage", AnchorPointC)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(370,267)
local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(4,0)
TListT:SetText("-Target Selection-")
TListT:SetTextColor(Color(0,70,225,255))
TListT:SizeToContents()

POnlyC = vgui.Create("DCheckBox", AnchorPointC)
POnlyC:SetPos(10,14)
POnlyC:SetValue(ToNumFromBool(Plyo:GetBool()))
POnlyC.DoClick=function()
	POnlyC:SetValue(ToNumFromBool(!Plyo:GetBool()))
	CheckShit(1)
	mod.oldRCC("Bacon_Plyonly",ToNumFromBool(!Plyo:GetBool()))
	mod.oldRCC("Bacon_Entonly",0)
	mod.oldRCC("Bacon_NPConly",0)
end
local POnlyT = vgui.Create( "DLabel", AnchorPointC)
POnlyT:SetPos(26,10)
POnlyT:SetText("Player Only")
POnlyT:SetTextColor(Color(225,225,225,225))
NOnlyC = vgui.Create("DCheckBox", AnchorPointC)
NOnlyC:SetPos(10,28)
NOnlyC:SetValue(ToNumFromBool(NPCo:GetBool()))
NOnlyC.DoClick=function()
	NOnlyC:SetValue(ToNumFromBool(!NPCo:GetBool()))
	CheckShit(2)
	mod.oldRCC("Bacon_NPConly",ToNumFromBool(!NPCo:GetBool()))
	mod.oldRCC("Bacon_Entonly",0)
	mod.oldRCC("Bacon_Plyonly",0)
end
local NOnlyT = vgui.Create( "DLabel", AnchorPointC)
NOnlyT:SetPos(26,24)
NOnlyT:SetText("NPC Only")
NOnlyT:SetTextColor(Color(225,225,225,225))
EOnlyC = vgui.Create("DCheckBox", AnchorPointC)
EOnlyC:SetPos(10,42)
EOnlyC:SetValue(ToNumFromBool(Ento:GetBool()))
EOnlyC.DoClick=function()
	CheckShit(3)
	EOnlyC:SetValue(ToNumFromBool(!Ento:GetBool()))
	mod.oldRCC("Bacon_Entonly",ToNumFromBool(!Ento:GetBool()))
	mod.oldRCC("Bacon_NPConly",0)
	mod.oldRCC("Bacon_Plyonly",0)
end
local EOnlyT = vgui.Create( "DLabel", AnchorPointC)
EOnlyT:SetPos(26,38)
EOnlyT:SetText("Entity Only")
EOnlyT:SetTextColor(Color(225,225,225,225))
local FFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
FFC:SetPos(10,56)
FFC:SetConVar( "Bacon_ff" )
FFC:SetValue(friendlyfire:GetInt())
local FFT = vgui.Create( "DLabel", AnchorPointC)
FFT:SetPos(26,52)
FFT:SetText("Friendly Fire")
FFT:SetTextColor(Color(225,225,225,225))
local SFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
SFC:SetPos(10,71)
SFC:SetConVar( "Bacon_ignore_steamfriends" )
local SFT = vgui.Create( "DLabel", AnchorPointC)
SFT:SetPos(26,70)
SFT:SetText("Ignore Steam Friends")
SFT:SizeToContents()
SFT:SetTextColor(Color(225,225,225,225))
local ADC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ADC:SetPos(10,86)
ADC:SetConVar( "Bacon_ignore_admins" )
local ADT = vgui.Create( "DLabel", AnchorPointC)
ADT:SetPos(26,85)
ADT:SetText("Ignore Admins")
ADT:SizeToContents()
ADT:SetTextColor(Color(225,225,225,225))
-- anti detect
local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(260,78)
TListT:SetText("-Anti-Detection-")
TListT:SetTextColor(Color(0,200,40,255))
TListT:SizeToContents()
--Pcwizdan copyright USA 2010-2999 (C) DERP-DERP-DURP inc
do
	local AntiFOV_SLIDER = vgui.Create('DNumSlider',AnchorPointC)
	AntiFOV_SLIDER:SetText('Field of View')
	AntiFOV_SLIDER:SetPos(238,93)
	AntiFOV_SLIDER:SetMinMax(1,180)
	AntiFOV_SLIDER:SetWide(120)
	AntiFOV_SLIDER:SetMouseInputEnabled(true)
	AntiFOV_SLIDER:SetValue(math.Round(FOV_VALUE:GetInt()))
	AntiFOV_SLIDER:SetConVar("Bacon_RestrictFOV_Value")
	AntiFOV_SLIDER.ValueChanged = function (pnl,val)
		LAST_CHANGE_FOVVALUE = CurTime()
	end	
	local AimSmooth_Slider = vgui.Create('DNumSlider',AnchorPointC)
	AimSmooth_Slider:SetText('Smoothing')
	AimSmooth_Slider:SetPos(238,130)
	AimSmooth_Slider:SetMinMax(0,10)
	AimSmooth_Slider:SetWide(120)
	AimSmooth_Slider:SetMouseInputEnabled(true)
	AimSmooth_Slider:SetValue(AimSmooth:GetFloat())
	AimSmooth_Slider:SetConVar("Bacon_AimSmooth")
end
-- Misc Checkboxes --
local MiscT = vgui.Create( "DLabel", AnchorPointC)
MiscT:SetPos(4,100)
MiscT:SetText("-Miscellaneous Scripts-")
MiscT:SetTextColor(Color(255,10,10,255))
MiscT:SizeToContents()
local TBC = vgui.Create("DCheckBoxLabel", AnchorPointC)
TBC:SetPos(4,115)
TBC:SetConVar( "Bacon_Trigger_Bot" )
TBC:SetValue(triggertoggle:GetInt())
local TBT = vgui.Create( "DLabel", AnchorPointC)
TBT:SetPos(20,111)
TBT:SetText("Trigger-Bot")
TBT:SetTextColor(Color(225,225,225,225))
local TAR = vgui.Create("DCheckBoxLabel", AnchorPointC)
TAR:SetPos(4,130)
TAR:SetConVar( "bacon_autoreload" )
TAR:SetValue(autoreload:GetInt())
local TART = vgui.Create( "DLabel", AnchorPointC)
TART:SetPos(20,126)
TART:SetText("Auto Reload")
TART:SetTextColor(Color(225,225,225,225))
local SPINBOTGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
SPINBOTGUI:SetPos(4,145)
SPINBOTGUI:SetConVar( "Bacon_spinbot" )
local SPINBOTGUIL = vgui.Create( "DLabel", AnchorPointC)
SPINBOTGUIL:SetPos(20,144)
SPINBOTGUIL:SetText("Spinbot")
SPINBOTGUIL:SizeToContents()
SPINBOTGUIL:SetTextColor(Color(225,225,225,225))
local ThirdPerson = vgui.Create("DCheckBoxLabel", AnchorPointC)
ThirdPerson:SetPos(4,160)
ThirdPerson:SetValue(IsValid(LocalPlayer()) and LocalPlayer():EyePos() != EyePos())
function ThirdPerson:OnChange()
	if not svcheats.allow() then return false end
	if self:GetChecked() then mod.SetCVAR(svcheats.cvar, "1") end
	mod.oldRCC((self:GetChecked() and "third" or "first").."person")
end
local ThirdPersonL = vgui.Create( "DLabel", AnchorPointC)
ThirdPersonL:SetPos(20,159)
ThirdPersonL:SetText("Third Person")
ThirdPersonL:SizeToContents()
ThirdPersonL:SetTextColor(Color(225,225,225,225))
local nospread = vgui.Create("DCheckBoxLabel", AnchorPointC)
nospread:SetPos(94,115)
nospread:SetConVar( "bacon_always_nospread" )
local nospread = vgui.Create( "DLabel", AnchorPointC)
nospread:SetPos(110,114)
nospread:SetText("Nospread")
nospread:SizeToContents()
nospread:SetTextColor(Color(225,225,225,225))
local BHOPGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
BHOPGUI:SetPos(94,130)
BHOPGUI:SetConVar( "Bacon_bhop" )
local BHOPL = vgui.Create( "DLabel", AnchorPointC)
BHOPL:SetPos(110,126)
BHOPL:SetText("Bunny Hop")
BHOPL:SetTextColor(Color(225,225,225,225))
local CLIENTNOCLIPGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
CLIENTNOCLIPGUI:SetPos(94,145)
CLIENTNOCLIPGUI:SetConVar( "bacon_clientnoclip" )
CLIENTNOCLIPGUI:SetValue(clientsidenoclip:GetInt())
local CLIENTNOCLIPGUIL = vgui.Create( "DLabel", AnchorPointC)
CLIENTNOCLIPGUIL:SetPos(110,144)
CLIENTNOCLIPGUIL:SetText("Client Spectate")
CLIENTNOCLIPGUIL:SizeToContents()
CLIENTNOCLIPGUIL:SetTextColor(Color(225,225,225,225))
local BypassCheck = vgui.Create("DCheckBoxLabel", AnchorPointC)
BypassCheck:SetPos(94,160)
BypassCheck:SetConVar( "bacon_allow_cheats_default" )
BypassCheck:SetValue(svcheats.bypass:GetInt())
local BypassCheckLabel = vgui.Create( "DLabel", AnchorPointC)
BypassCheckLabel:SetPos(110,159)
BypassCheckLabel:SetText("Disable sv_cheats warning")
BypassCheckLabel:SizeToContents()
BypassCheckLabel:SetTextColor(Color(225,225,225,225))
local BMWGUI = vgui.Create("DCheckBox", AnchorPointC)
BMWGUI:SetPos(270,170)
BMWGUI:SetConVar( "Bacon_TMW" )
BMWGUI:SetValue(bmw:GetInt())
local BMWGUIL = vgui.Create( "DLabel", AnchorPointC)
BMWGUIL:SetPos(286,169)
BMWGUIL:SetText("Mini Window")
BMWGUIL:SizeToContents()
BMWGUIL:SetTextColor(Color(225,225,225,225))
BMWGUI.DoClick=function(pnl)
	pnl:Toggle()	
	if pnl:GetChecked() then
		BaconMiniWindow()
	else
		MMPan:Remove()
	end
end
local LOCKL = vgui.Create( "DLabel", AnchorPointC )
LOCKL:SetPos( 5, 195 )
LOCKL:SetText("-Targeting Priority-")
LOCKL:SizeToContents()
LOCKL:SetTextColor(Color(255,204,80,225))
local LockOnL
local function LockOnListA()
	local types = {"Crosshair", "Distance", "Lowest HP", "Deadliest", "Aim Assistance"}
	LockOnL = vgui.Create("DButton", AnchorPointC )
	LockOnL:SetText( types[Mod:GetInt()] )
	LockOnL:SetPos( 5, 210 )
	LockOnL:SetSize( 90, 20 )
	LockOnL.DoClick = function ( btn )
		local MenuButtonOptions = DermaMenu() 
		MenuButtonOptions:AddOption("Crosshair", function() mod.oldRCC("Bacon_Mode",1) LockOnL:SetText( types[1] ) end ) 
		MenuButtonOptions:AddOption("Distance", function() mod.oldRCC("Bacon_Mode",2) LockOnL:SetText( types[2] )  end )
		MenuButtonOptions:AddOption("Lowest HP", function() mod.oldRCC("Bacon_Mode",3) LockOnL:SetText( types[3] ) end )
		MenuButtonOptions:AddOption("Deadliest", function() mod.oldRCC("Bacon_Mode",4) LockOnL:SetText( types[4] ) end )
		MenuButtonOptions:AddOption("Aim Assistance", function() mod.oldRCC("Bacon_Mode",5) LockOnL:SetText( types[5] ) end )
		MenuButtonOptions:Open() 
	end
end
LockOnListA()

local Icon = vgui.Create("DImage", AnchorPointC)
Icon:SetMaterial(Material("BaconBot/Logo"))
Icon:SetPos(147,15)
Icon:SetSize(211,53)
local HEIGHTL = vgui.Create( "DLabel", AnchorPointC )
HEIGHTL:SetPos( 116,175 )
HEIGHTL:SetText("-Aimbot Targeting Area-")
HEIGHTL:SizeToContents()
HEIGHTL:SetTextColor(Color(225,100,20,225))
local SetHeight = vgui.Create( "DNumSlider", AnchorPointC )
SetHeight:SetPos( 100,190 )
SetHeight:SetSize( 150, 100 ) -- Keep the second number at 100
SetHeight:SetText( "     <Head - Nuts>" )
SetHeight:SetMin( 0 ) -- Minimum number of the slider
SetHeight:SetMax( 33 ) -- Maximum number of the slider
SetHeight:SetDecimals( 1 ) -- Sets a decimal. Zero means its a whole number
SetHeight:SetConVar( "bacon_lockY" ) -- Set the convar
local cheatsbutton = vgui.Create( "DButton", AnchorPointC )
cheatsbutton:SetPos(255,210)
cheatsbutton:SetText("Toggle sv_cheats")
cheatsbutton:SetSize(100,20)
cheatsbutton.DoClick = function()
	if not svcheats.allow() then return end
	if CVARMETAGETINT(svcheats.cvar) != 0 then
		mod.SetCVAR(svcheats.cvar, "0")
		print("sv_cheats turned off")
	else
		mod.SetCVAR(svcheats.cvar, "1")
		print("sv_cheats turned on")
	end
end
local spambutton = vgui.Create( "DButton", AnchorPointC )
spambutton:SetPos(255,190)
spambutton:SetText("BB Spammer")
spambutton:SetSize(100,20)
spambutton.DoClick = function()
	SpawnVGUISPAM()
end
local Title = vgui.Create("DLabel",AnchorPointC)
Title:SetPos(165,220)
Title:SetText("")
Title:SizeToContents()
//END OF GENERAL
//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________

//START OF FRIENDS LIST!!!!!!
local AnchorPointA = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")
MPan:AddSheet( "Friends", AnchorPointA, "BaconBot/friends", false, false, "Aimbot Friends" )
local Icona = vgui.Create("DImage", AnchorPointA)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(370,267)
local FriendListT = vgui.Create( "DLabel", AnchorPointA )
FriendListT:SetPos(40,5)
FriendListT:SetText("Friends - Current")
FriendListT:SizeToContents()
FriendListT:SetTextColor(Color(255,255,255,255))
local FriendListL
local function FriendsListA()
	FriendListL = vgui.Create( "DComboBox", AnchorPointA )
	FriendListL:SetPos( 10, 25 )
	FriendListL:SetSize( 150, 190 )
	FriendListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetFriends() then friendslist=BFS.GetFriends() else friendslist={} end
	for k,v in pairs(friendslist) do
		FriendListL:AddItem(v) -- Add our options
	end
end
FriendsListA()
local FriendListB = vgui.Create( "DButton", AnchorPointA )
FriendListB:SetPos(20,215)
FriendListB:SetText("Remove from friends")
FriendListB:SetSize(120,20)
FriendListB.DoClick = function()
	local temptable = {}
	if #FriendListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(FriendListL:GetSelectedItems()) do
		for c,d in pairs(friendslist) do
			if b:GetValue()==d then
				if #friendslist==0 then friendslist={} end
				table.remove(friendslist,c)
				table.insert(temptable,b:GetValue())
			end
		end
	end
	BFS.SetFriends(friendslist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	PlayerListA()
	FriendsListA()
end

local PlayerListT = vgui.Create( "DLabel", AnchorPointA )
PlayerListT:SetPos(250,5)
PlayerListT:SetText("Players List")
PlayerListT:SizeToContents()
PlayerListT:SetTextColor(Color(255,255,255,255))
local PlayerListL
PlayerListA = function()
	PlayerListL = vgui.Create( "DComboBox", AnchorPointA )
	PlayerListL:SetPos( 200, 25 )
	PlayerListL:SetSize( 150, 190 )
	PlayerListL:SetMultiple(true)
	for k,v in pairs(player.GetAll()) do
		if !table.HasValue(friendslist,v:Name()) && v!=LocalPlayer() then
			PlayerListL:AddItem(v:Name()) -- Add our options
		end
	end
end
PlayerListA()
local PlayerListB = vgui.Create( "DButton", AnchorPointA )
PlayerListB:SetPos(240,215)
PlayerListB:SetSize(80,20)
PlayerListB:SetText("Add to friends")
PlayerListB.DoClick = function()
	local temptable = {}
	if #PlayerListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(PlayerListL:GetSelectedItems()) do
		table.insert(friendslist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetFriends(friendslist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	PlayerListA()
	FriendsListA()
end
//END OF FRIENDS LIST!!!!!!
//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________

//START OF ENTITIES LIST!!!!!!
local AnchorPointB = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")
MPan:AddSheet( "Aim Ents", AnchorPointB, "BaconBot/ent_add", false, false, "Aimbot Entities" )
local Icona = vgui.Create("DImage", AnchorPointB)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(370,267)
local EntityListT = vgui.Create( "DLabel", AnchorPointB )
EntityListT:SetPos(40,5)
EntityListT:SetText("Entities - Current")
EntityListT:SizeToContents()
EntityListT:SetTextColor(Color(255,255,255,255))
local EntityListL
local function EntityListA()
	EntityListL = vgui.Create( "DComboBox", AnchorPointB )
	EntityListL:SetPos( 10, 25 )
	EntityListL:SetSize( 150, 190 )
	EntityListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetEnts() then lockonlist=BFS.GetEnts() else lockonlist={} end
	for k,v in pairs(lockonlist) do
		EntityListL:AddItem(v) -- Add our options
	end
end
EntityListA()
local EntityListB = vgui.Create( "DButton", AnchorPointB )
EntityListB:SetPos(20,215)
EntityListB:SetText("Remove from entities")
EntityListB:SetSize(120,20)
EntityListB.DoClick = function()
	local temptable = {}
	if #EntityListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EntityListL:GetSelectedItems()) do
		for c,d in pairs(lockonlist) do
			if string.lower(b:GetValue())==string.lower(d) then
				local lost=table.remove(lockonlist,c)
				table.insert(temptable,lost)
			end
		end
	end
	BFS.SetEnts(lockonlist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	EntityListA()
	EListA()
end
local EListT = vgui.Create( "DLabel", AnchorPointB )
EListT:SetPos(235,5)
EListT:SetText("Active Entities List")
EListT:SizeToContents()
EListT:SetTextColor(Color(255,255,255,255))
local EListL
EListA = function()
	EListL = vgui.Create( "DComboBox", AnchorPointB )
	EListL:SetPos( 200, 25 )
	EListL:SetSize( 150, 190 )
	EListL:SetMultiple(true)
	local tempents = {}
	for k,v in pairs(ents.GetAll()) do
		if IsValid(v) && !table.HasValue(tempents,v:GetClass()) && !table.HasValue(lockonlist,v:GetClass()) then
			table.insert(tempents,v:GetClass())
		end
	end
	for g,h in pairs(tempents) do
		if h=="prop_physics" then
			ThePropList=EListL:AddItem(h)
			ThePropList.OnMousePressed=function(a,b)
			if b==108 then
				local MenuButtonOptions = DermaMenu()
				local temptablec = {}
				local temptabled = {}
				for k,v in pairs(ents.FindByClass("prop_physics")) do
					if !table.HasValue(temptablec,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) && !table.HasValue(lockonlist,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						table.insert(temptablec, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl",""))
						table.insert(temptabled,v:GetModel())
					end
				end
				for i,c in pairs(temptablec) do
					local mover = vgui.Create( "DMenuOption", MenuButtonOptions)
					mover:SetText(c)
					local icon
					mover.OnCursorEntered=function() icon=vgui.Create("SpawnIcon") icon:SetModel(temptabled[i]) icon.DoClick=function() icon:Remove() end local c,d = mover:GetPos() local a,b = MenuButtonOptions:GetPos() icon:SetPos(a+mover:GetWide(),b+d) end
					mover.OnCursorExited=function() icon:Remove() end
					mover.DoRightClick=function() icon:Remove() end
					mover.DoClick=function()
					table.insert(lockonlist,c)
					BFS.SetEnts(lockonlist)
					EListA()
					EntityListA()
					LocalPlayer():ChatPrint("Added: "..c)
					icon:Remove()
					end
					MenuButtonOptions:AddPanel(mover)
				end
				MenuButtonOptions:Open()
			else
				EListL:SelectByName( "prop_physics" )
			end
			end
		else
			EListL:AddItem(h) -- Add our options
		end
	end
end
EListA()
local EListB = vgui.Create( "DButton", AnchorPointB )
EListB:SetPos(240,215)
EListB:SetSize(80,20)
EListB:SetText("Add to entities")
EListB.DoClick = function()
	local temptable = {}
	if #EListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EListL:GetSelectedItems()) do
		table.insert(lockonlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetEnts(lockonlist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	EListA()
	EntityListA()
end
//END OF ENTITIES LIST!!!!!!
//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________
//START OF ESP TAB!!!!!!
local AnchorPointD = vgui.Create( "DLabel", MPan )
AnchorPointD:SetPos(0,0)
AnchorPointD:SetText("")
MPan:AddSheet( "ESP", AnchorPointD, "BaconBot/radar", false, false, "ESP Menu" )
local Icona = vgui.Create("DImage", AnchorPointD)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(370,267)
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10, 30 )
CheckBoxThing:SetConVar( "bacon_espplayeron" )
CheckBoxThing:SetValue( playeron:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26, 29 )
CheckBoxThing2:SetText( "Players" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local MenuButton = vgui.Create("DButton", AnchorPointD)
MenuButton:SetText( "Mode >" )
MenuButton:SetPos(10, 10)
MenuButton:SetSize(50, 15)
MenuButton.DoClick = function ( btn )
 local MenuButtonOptions = DermaMenu() // Creates the menu
 MenuButtonOptions:AddOption("Simple", function() mod.oldRCC("bacon_espmode","0") end ) // Add options to the menu
 MenuButtonOptions:AddOption("Normal", function() mod.oldRCC("bacon_espmode","1") end )
 MenuButtonOptions:AddOption("Advanced", function() mod.oldRCC("bacon_espmode","2") end )
 MenuButtonOptions:Open() // Open the menu AFTER adding your options
end 
local MenuButton = vgui.Create("DButton", AnchorPointD)
MenuButton:SetText( "ESP Crosshair >" )
MenuButton:SetPos(10, 170)
MenuButton:SetSize(100, 15)
MenuButton.DoClick = function ( btn )
 local MenuButtonOptions = DermaMenu() // Creates the menu
 MenuButtonOptions:AddOption("Box", function() mod.oldRCC("bacon_espcross","0") end ) // Add options to the menu
 MenuButtonOptions:AddOption("Cross", function() mod.oldRCC("bacon_espcross","1") end )
 MenuButtonOptions:AddOption("|_", function() mod.oldRCC("bacon_espcross","2") end )
 MenuButtonOptions:Open() // Open the menu AFTER adding your options
end 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos(10, 50)
CheckBoxThing:SetConVar("bacon_espitemon")
CheckBoxThing:SetValue(itemon:GetInt())
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos(26, 49)
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SetText("Items")
CheckBoxThing2:SizeToContents()
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,70 )
CheckBoxThing:SetConVar( "bacon_espvehicleon" )
CheckBoxThing:SetValue( vehicleon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,69 )
CheckBoxThing2:SetText( "Vehicles" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,90 )
CheckBoxThing:SetConVar( "bacon_espnpcon" )
CheckBoxThing:SetValue( npcon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,89 )
CheckBoxThing2:SetText( "NPCs" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,110 )
CheckBoxThing:SetConVar( "bacon_espweaponon" )
CheckBoxThing:SetValue( weaponon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,109 )
CheckBoxThing2:SetText( "Weapons" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,130 )
CheckBoxThing:SetConVar( "bacon_espunhideon" )
CheckBoxThing:SetValue( unhideon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,129 )
CheckBoxThing2:SetText( "Show Invisble Props" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,150 )
CheckBoxThing:SetConVar( "bacon_drawclassname" )
CheckBoxThing:SetValue( drawclassname:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,149 )
CheckBoxThing2:SetText( "Item Type Display" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()
local Icon = vgui.Create("DModelPanel", AnchorPointD)
Icon:SetModel(LocalPlayer():GetModel())
Icon:SetAnimated(true)
Icon:SetPos(157,36)
Icon:SetSize(175,175)
Icon.Entity:SetPos(Icon.Entity:GetPos()+Vector(-10,0,0))
local Painted = vgui.Create("DLabel", AnchorPointD)
Painted:SetPos(115,0)
Painted:SetSize(250,250)
Painted:SetText("")
Painted.Paint=function()
local x=140
local y=55
local MMode=cross:GetInt()
local playeron = playeron:GetInt()
local itemon = itemon:GetInt()
local vehicleon = vehicleon:GetInt()
local npcon = npcon:GetInt()
local weaponon = weaponon:GetInt()
local trans = trans:GetInt()
local mode = mode:GetInt()
surface.SetDrawColor(0,255,0,255)
if (MMode==0) then
	surface.DrawLine(x-40,y-15,x+40,y-15)
	surface.DrawLine(x-40,y-15,x-40,y+150)
	surface.DrawLine(x-40,y+150,x+40,y+150)
	surface.DrawLine(x+40,y-15,x+40,y+150)
elseif (MMode==1) then
	surface.DrawLine(x,y-5,x,y+5)
	surface.DrawLine(x-5,y,x+5,y)
else
	surface.DrawLine(x,y,x,y-20)
	surface.DrawLine(x,y,x+20,y)
end
v=LocalPlayer()
local mod = v:GetModel()
ateam = v:Team()
color = team.GetColor(ateam)
color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
if v:InVehicle() then
	colora = Color(255,255,255,trans)
else
	colora = color
end
local weapon="NONE"
if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
	if v:Alive() && v:GetActiveWeapon():IsValid() then
		weapon=v:GetActiveWeapon( ):GetPrintName()
		weapon=string.Replace(weapon,"#HL2_","")
		weapon=string.Replace(weapon,"#GMOD_","")
	end
else
	weapon="NONE"
end
hp = v:Health()
name = v:Name()
gpos = v:EyePos():ToScreen()
dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
local ads = admincheck(v)
if mode==2 then
	tn=team.GetName(ateam)
	draw.SimpleText(hp.."   W: "..weapon, "Default", x+15, y-32, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-30, colora,0,0)
	draw.SimpleText(""..name.."", "Default", x+3, y-43, colora,0,0)
	draw.SimpleText(""..tn.."","Default", x+3, y-12, colora,0,0)
	draw.SimpleText("Dist: 1337","Default", x+3, y-22, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-53, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
elseif mode==0 then
	draw.SimpleText(""..name.."", "Default", x+3, y-23, colora,0,0)
	draw.SimpleText(hp,"Default", x+15, y-12, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-10, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-33, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
else
	draw.SimpleText(""..name.."", "Default", x+3, y-33, colora,0,0)
	draw.SimpleText(hp, "Default", x+15, y-12, colora,0,0)
	draw.SimpleText("W: "..weapon, "Default", x+3, y-23, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-10, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-43, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
end
end
local NumSliderThingy = vgui.Create( "DNumSlider", AnchorPointD )
NumSliderThingy:SetPos( 10,190 )
NumSliderThingy:SetSize( 150, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "ESP Transparency" )
NumSliderThingy:SetMin( 100 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 255 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means its a whole number
NumSliderThingy:SetConVar( "bacon_esptrans" )
local TBC = vgui.Create("DCheckBoxLabel", AnchorPointD)
TBC:SetPos(90,30)
TBC:SetConVar( "Bacon_Chams" )
local TBT = vgui.Create( "DLabel", AnchorPointD)
TBT:SetPos(106,29)
TBT:SetText("Player Wallhack")
TBT:SizeToContents()
TBT:SetTextColor(Color(225,225,225,225))
local CHAMS2C = vgui.Create("DCheckBoxLabel", AnchorPointD)
CHAMS2C:SetPos(90, 50)
CHAMS2C:SetConVar( "bacon_chams2" )
local CHAMS2L = vgui.Create( "DLabel", AnchorPointD)
CHAMS2L:SetPos(106, 49)
CHAMS2L:SetWide(CHAMS2L:GetWide() + 20)
CHAMS2L:SetText("Wireframe Wallhack")
CHAMS2L:SizeToContents()
CHAMS2L:SetTextColor(Color(225,225,225,225))
local ALC = vgui.Create("DCheckBoxLabel", AnchorPointD)
ALC:SetPos(90,70)
ALC:SetConVar( "Bacon_adminlist" )
local ALT = vgui.Create( "DLabel", AnchorPointD)
ALT:SetPos(106,66)
ALT:SetText("Admin List")
ALT:SetTextColor(Color(225,225,225,225))
local FB = vgui.Create("DCheckBoxLabel", AnchorPointD)
FB:SetPos(90,90)
FB:SetValue(GetConVar("mat_fullbright"):GetBool())
function FB:OnChange()
	mod.SetCVAR(GetConVar("mat_fullbright"), self:GetChecked() and "1" or "0")
end
local FBL = vgui.Create( "DLabel", AnchorPointD)
FBL:SetPos(106,86)
FBL:SetWide(FBL:GetWide() + 5)
FBL:SetText("Fullbright")
FBL:SetTextColor(Color(225,225,225,225))
//END OF ESP TAB!!!!!!!
//START OF ESP ENTITIES LIST!!!!!!!!
local AnchorPointE = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")
MPan:AddSheet( "ESP Ents", AnchorPointE, "BaconBot/esp_list", false, false, "ESP Entities" )
local Icona = vgui.Create("DImage", AnchorPointE)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(370,267)
Icona.Think = function (self)
end
local ESPEntityListT = vgui.Create( "DLabel", AnchorPointE )
ESPEntityListT:SetPos(40,5)
ESPEntityListT:SetText("Entities - Current")
ESPEntityListT:SizeToContents()
ESPEntityListT:SetTextColor(Color(255,255,255,255))
local ESPEntityListL
local function ESPEntityListA()
	ESPEntityListL = vgui.Create( "DComboBox", AnchorPointE )
	ESPEntityListL:SetPos( 10, 25 )
	ESPEntityListL:SetSize( 150, 190 )
	ESPEntityListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetESPEnts() then entlist=BFS.GetESPEnts() else entlist={} end
	for k,v in pairs(entlist) do
		ESPEntityListL:AddItem(v) -- Add our options
	end
end
ESPEntityListA()
local ESPEntityListB = vgui.Create( "DButton", AnchorPointE )
ESPEntityListB:SetPos(20,215)
ESPEntityListB:SetText("Remove from entities")
ESPEntityListB:SetSize(120,20)
ESPEntityListB.DoClick = function()
	local temptable = {}
	if #ESPEntityListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(ESPEntityListL:GetSelectedItems()) do
		for c,d in pairs(entlist) do
			if string.lower(b:GetValue())==string.lower(d) then
				local lost=table.remove(entlist,c)
				table.insert(temptable,lost)
			end
		end
	end
	BFS.SetESPEnts(entlist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	ESPEntityListA()
	EListA()
end
local EListT = vgui.Create( "DLabel", AnchorPointE )
EListT:SetPos(235,5)
EListT:SetText("Active Entities List")
EListT:SizeToContents()
EListT:SetTextColor(Color(255,255,255,255))
local EESPListL
local function EESPListA()
	EESPListL = vgui.Create( "DComboBox", AnchorPointE )
	EESPListL:SetPos( 200, 25 )
	EESPListL:SetSize( 150, 190 )
	EESPListL:SetMultiple(true)
	local tempents = {}
	for k,v in pairs(ents.GetAll()) do
		if IsValid(v) && !table.HasValue(tempents,v:GetClass()) && !table.HasValue(entlist,v:GetClass()) then
			table.insert(tempents,v:GetClass())
		end
	end
	for g,h in pairs(tempents) do
		if h=="prop_physics" then
			ThePropList=EESPListL:AddItem(h)
			ThePropList.OnMousePressed=function(a,b)
			if b==108 then
				local MenuButtonOptions = DermaMenu()
				local temptablec = {}
				local temptabled = {}
				for k,v in pairs(ents.FindByClass("prop_physics")) do
					if !table.HasValue(temptablec,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) && !table.HasValue(entlist,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						table.insert(temptablec, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl",""))
						table.insert(temptabled,v:GetModel())
					end
				end
				for i,c in pairs(temptablec) do
					local mover = vgui.Create( "DMenuOption", MenuButtonOptions)
					mover:SetText(c)
					local icon
					mover.OnCursorEntered=function() icon=vgui.Create("SpawnIcon") icon:SetModel(temptabled[i]) icon.DoClick=function() icon:Remove() end local c,d = mover:GetPos() local a,b = MenuButtonOptions:GetPos() icon:SetPos(a+mover:GetWide(),b+d) end
					mover.OnCursorExited=function() icon:Remove() end
					mover.DoRightClick=function() icon:Remove() end
					mover.DoClick=function()
					table.insert(entlist,c)
					BFS.SetESPEnts(entlist)
					EESPListA()
					ESPEntityListA()
					LocalPlayer():ChatPrint("Added: "..c)
					icon:Remove()
					end
					MenuButtonOptions:AddPanel(mover)
				end
				MenuButtonOptions:Open()
			else
				EESPListL:SelectByName( "prop_physics" )
			end
			end
		else
			EESPListL:AddItem(h) -- Add our options
		end
	end
end
EESPListA()
local EListB = vgui.Create( "DButton", AnchorPointE )
EListB:SetPos(240,215)
EListB:SetSize(80,20)
EListB:SetText("Add to entities")
EListB.DoClick = function()
	local temptable = {}
	if #EESPListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EESPListL:GetSelectedItems()) do
		table.insert(entlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetESPEnts(entlist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	EESPListA()
	ESPEntityListA()
end
//END OF ESP ENTITIES LIST!!!!!!
//START OF MISC
local MiscAnchor = vgui.Create( "DLabel", MPan )
MiscAnchor:SetPos(0,0)
MiscAnchor:SetText("")
local background = vgui.Create("DImage", MiscAnchor)
background:SetMaterial(Material("BaconBot/BBBackground.vtf"))
background:SetPos(0,0)
background:SetSize(370,267)
MPan:AddSheet( "Misc.", MiscAnchor, "BaconBot/misc", false, false, "Everything else" )
local label = vgui.Create( "DLabel", MiscAnchor)
	label:SetPos(12,5)
	label:SetText("-Crosshairs-")
	label:SetTextColor(Color(225,0,70,255))
	label:SizeToContents()

for i,v in ipairs(crosshairs) do
	local check = vgui.Create( "DCheckBoxLabel", MiscAnchor)
		check:SetPos(10, 20 + (i-1)*18)
		check:SetConVar(v.enabled:GetName())
		check:SetValue(v.enabled:GetInt())
		check:SetText(v.name)
		check:SizeToContents()
end
local label = vgui.Create( "DLabel", MiscAnchor)
	label:SetPos(118,5)
	label:SetText("-Preview-")
	label:SetTextColor(Color(225,0,70,255))
	label:SizeToContents()
local preview = vgui.Create("Panel", MiscAnchor)
	preview:SetPos(120, 20)
	preview:SetSize(40, 40)
	function preview:Paint()
		local cx, cy = self:GetWide()/2, self:GetTall()/2
		surface.SetDrawColor(0, 255, 0, 255)	
		surface.DrawLine(0, 0, self:GetWide(), 0)
		surface.DrawLine(0, 0, 0, self:GetTall())
		surface.DrawLine(0, self:GetTall()-1, self:GetWide(), self:GetTall()-1)
		surface.DrawLine(self:GetWide()-1, 0, self:GetWide()-1, self:GetTall())	
		for k,v in pairs(crosshairs) do
			if v.enabled:GetBool() then
				v.draw(cx, cy, true)
			end
		end
	end
local label = vgui.Create( "DLabel", MiscAnchor)
	label:SetPos(118, 64)
	label:SetText("-Camera-")
	label:SetTextColor(Color(225,0,70,255))
	label:SizeToContents()	
local check = vgui.Create( "DCheckBoxLabel", MiscAnchor)
	check:SetPos(118, 79)
	check:SetConVar(gamemodeview:GetName())
	check:SetValue(gamemodeview:GetInt())
	check:SetText("Thirdperson GM Fix" )
	check:SizeToContents()
local check = vgui.Create( "DCheckBoxLabel", MiscAnchor)
	check:SetPos(118, 94)
	check:SetValue(recording_mode)
	check:SetText("Panic Mode (Hides HUD/ESP/Chams)")
	check:SizeToContents()
	function check.Button:DoClick()
		self:Toggle()
		recording_mode = not recording_mode		
		if self:GetChecked() then					if MMPan then
				MMPan:Remove()			end
		else
			if bmw:GetBool() then
				BaconMiniWindow()
			end
		end
	end
local label = vgui.Create( "DLabel", MiscAnchor)
	label:SetPos(12,175)
	label:SetText("-IP Logging-")
	label:SetTextColor(Color(225,0,70,255))
	label:SizeToContents()
local check = vgui.Create( "DCheckBoxLabel", MiscAnchor)
	check:SetPos(10, 190)
	check:SetConVar(logips:GetName())
	check:SetValue(logips:GetInt())
	check:SetText("Enable IP Logging")
	check:SizeToContents()
local ipbutton = vgui.Create( "DButton", MiscAnchor)
	ipbutton:SetPos(10, 208)
	ipbutton:SetText("IP Log Viewer")
	ipbutton:SetSize(109,20)
	ipbutton.DoClick = function()
		local win = vgui.Create("DFrame")
			function win:GetSkin()
				return SKIN
			end
			win:SetSize(300, 365)
			win:SetPos(ScrW()/2 + 300, ScrH()/2 - 180)
			win:SetVisible(true)
			win:MakePopup()
			win:SetTitle("BaconBot IP Viewer")	
		local bg = vgui.Create("DImage", win)
			bg:SetMaterial(Material("BaconBot/BBBackground.vtf"))
			bg:SetPos(0, 22)
			bg:SetSize(450, 300)
		local searchName = vgui.Create("DTextEntry", win)
			searchName:SetPos(3, 25)
			searchName:SetSize(125, 20)	
		local bindButton = vgui.Create("DButton", win)
			bindButton:SetPos(133, 25)
			bindButton:SetSize(40, 20)
			bindButton:SetText("Search")		
		local clearButton = vgui.Create("DButton", win)
			clearButton:SetSize(50, 20)
			clearButton:SetPos(win:GetWide() - clearButton:GetWide() - 3,25)
			clearButton:SetText("Clear DB")
		local ipList = vgui.Create("DListView", win)
			ipList:SetPos(0, 47)
			ipList:SetSize(300, 318)
			ipList:SetMultiSelect(false)
		local col1 = ipList:AddColumn( "Name" )
			col1:SetMinWidth(150)
			col1:SetMaxWidth(150)
		local col2 = ipList:AddColumn( "IP Address" )
		for k,v in pairs(tblDB) do
			ipList:AddLine(k, v)
		end
		ipList:SortByColumn(1, false)
		function bindButton:DoClick()
			ipList:Clear()
			for k,v in pairs(tblDB) do
				if k:lower():find(searchName:GetValue():gsub("%[", "%%%["):gsub("%]", "%%%]"):gsub("%%", "%%%%"):lower()) then
					ipList:AddLine(k, v)
				end
			end
		end	
		function clearButton:DoClick()
			ipList:Clear()
			mod.ConCmd("log_clear")
		end
		function ipList:OnRowRightClick(line)
			local menu = DermaMenu()
				menu:AddOption("Copy", function()
					SetClipboardText(self:GetLine(line):GetValue(2))
				end)
			menu:Open()
		end
	end
local label = vgui.Create( "DLabel", MiscAnchor)
	label:SetPos(130,175)
	label:SetText("-Speedhack-")
	label:SetTextColor(Color(225,0,70,255))
	label:SizeToContents()
local AimSmooth_Slider = vgui.Create('DNumSlider',MiscAnchor)	
	AimSmooth_Slider:SetText('Speed Factor')
	AimSmooth_Slider:SetPos(130, 190)
	AimSmooth_Slider:SetMinMax(1,10)
	AimSmooth_Slider:SetWide(120)
	AimSmooth_Slider:SetMouseInputEnabled(true)
	AimSmooth_Slider:SetValue(speedfactor:GetFloat())
	AimSmooth_Slider:SetConVar(speedfactor:GetName())
//END OF MISC
//START OF BIND MENU LIST
// 370, 267
local BindAnchor = vgui.Create( "DLabel", MPan )
BindAnchor:SetPos(0,0)
BindAnchor:SetText("")
local background = vgui.Create("DImage", BindAnchor)
background:SetMaterial(Material("BaconBot/BBBackground.vtf"))
background:SetPos(0,0)
background:SetSize(370,267)
MPan:AddSheet( "Binds", BindAnchor, "BaconBot/bind", false, false, "Bind Menu" )
local keyChoice = ""
local keys = {
	{
		name = "Letters/Num",
		keys = { 
			"A",	"B",	"C",	"D",
			"E",	"F",	"G",	"H",
			"I",	"J",	"K",	"L",
			"M",	"N",	"O",	"P",
			"Q",	"R",	"S",	"T",
			"U",	"V",	"W",	"X",
			"Y",	"Z",	"1",	"2",
			"3",	"4",	"5",	"6",
			"7",	"8",	"9",	"0",
		},
	},
	{
		name = "Other",
		keys = {
			"ALT",	"SHIFT","CAPSLOCK","-",
			"=",	"[",	"]",	"\\",
			";",	"'",	",",	".",
			"/",	"F5", 	"F6", 	"F7", 
			"F8",	"F9",	"F10", 	"F11",
			"F12",	"INS", 	"DEL",	"HOME",
			"END",	"PGUP",	"PGDN",
		},
	},
	{
		name = "Mouse",
		keys = {
			"MOUSE3",
			"MOUSE4",
			"MOUSE5",
			"MWHEELUP",
			"MWHEELDOWN",
		},
	},
}
local keyList = vgui.Create("DTextEntry", BindAnchor)
	keyList:SetPos(3, 3)
	keyList:SetWidth(45)
	function keyList:OnMousePressed(code)
		if code ~= MOUSE_LEFT then return true end	
		if self.Menu then self.Menu:Remove() end
		self.Menu = DermaMenu()
		for _,v in ipairs(keys) do
			local sub = self.Menu:AddSubMenu(v.name)		
			for _, iv in ipairs(v.keys) do
				sub:AddOption(iv, function()
					if not IsValid(self) then return end				
					keyChoice = iv
					self:SetText(iv)
				end)
			end
		end	
		self.Menu:Open()
	end
local commandName = vgui.Create("DTextEntry", BindAnchor)
	commandName:SetPos(53, 3)
	commandName:SetSize(125, 20)
	commandName:SetEditable(false)
local errorLabel = vgui.Create("DLabel", BindAnchor)
	errorLabel:SetPos(228, 3)
	errorLabel:SetSize(150, 20)
	errorLabel:SetText("")
	errorLabel:SetColor(Color(255, 0, 0))
local bindButton = vgui.Create("DButton", BindAnchor)
	bindButton:SetPos(183, 3)
	bindButton:SetSize(40, 20)
	bindButton:SetText("Bind!")
	function bindButton:DoClick()
		if keyChoice == "" or commandName:GetValue() == "" then
			errorLabel:SetText("Specify key and command!")
			timer.Simple(3, function() if IsValid(errorLabel) then errorLabel:SetText("") end end)
		else
			local cmd = "bind \""..tostring(keyChoice).."\" \""..tostring(commandName:GetValue()).."\""
			mod.ConCmd(cmd)
			print(cmd)
			errorLabel:SetText("")
		end
	end
local cmdList = vgui.Create("DListView", BindAnchor)
	cmdList:SetPos(0, 25)
	cmdList:SetSize(360, 232)
	cmdList:SetMultiSelect(false)
function cmdList:OnRowSelected(LineID, Line)
	commandName:SetValue(Line:GetColumnText(1))
end
local col1 = cmdList:AddColumn( "Command" )
	col1:SetMinWidth(125)
	col1:SetMaxWidth(125)
local col2 = cmdList:AddColumn( "Description" )
for k,v in pairs(Commands.help) do
	cmdList:AddLine(k:lower(), v)
end
table.Copy( cmdList.Sorted, cmdList.Lines )	
table.sort( cmdList.Sorted, function( a, b ) 			
	if (!IsValid( a )) then return true end
	if (!IsValid( b )) then return false end
	local cmd1 = a:GetColumnText(1):lower()
	local cmd2 = b:GetColumnText(1):lower()	
	if ( cmd1 != cmd2 ) then
		if cmd1:gsub("+", ""):sub(1,1) == cmd2:gsub("+", ""):sub(1,1) then
			return cmd1 < cmd2
		else
			return cmd1:gsub("+", "") < cmd2:gsub("+", "")
		end
	end
	return true							
end )
cmdList:SetDirty( true )
cmdList:InvalidateLayout()
end

local spamchat = false
-- Coded by seth, if you take this line out you're a fucking nigger
local propamount = CreateClientConVar( "bacon_data_prop", 0, true, false )
local swepamount = CreateClientConVar( "bacon_data_swep", 0, true, false )
local sentamount = CreateClientConVar( "bacon_data_sent", 0, true, false )
local propmodel = "Prop Model"
local swepmodel = "SWEP Name"
local vehiclemodel = "Vehicle Name"
local npcmodel = "NPC Name"
local sentmodel = "SENT Name"
local function sentspam()
	local sents = sentamount:GetInt() -1
	for i=0,sents do
		mod.oldRCC("gm_spawnsent",sentmodel)
	end
end
local function propspam()
	local props = propamount:GetInt() -1
	for i=0,props do
		mod.oldRCC("gm_spawn",propmodel)
	end
end
local function swepspam()
	local sweps = swepamount:GetInt() -1
	for i=0,sweps do
		mod.oldRCC("gm_spawnswep",swepmodel)
	end
end
SpawnVGUISPAM = function( )
    local DFrame = vgui.Create( "DFrame"); 
	function DFrame:GetSkin()
		return SKIN
	end
    DFrame:SetSize( 265, 375 ); 
    DFrame:SetPos( ScrW()/2,ScrH()/2 );
    DFrame:SetVisible( true );  
    DFrame:MakePopup( );
    DFrame:SetTitle("Spam Here :D")
local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15,45 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(propmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    propmodel=DermaText:GetValue()
end
local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,65 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "Prop Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "bacon_data_prop" )
 NumSliderThingy:SetValue( 0 )
local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15,120 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(swepmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    swepmodel=DermaText:GetValue()
end
local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,140 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "SWEP Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "bacon_data_swep" )
NumSliderThingy:SetValue( 0 )
local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15, 195 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(sentmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    sentmodel=DermaText:GetValue()
end
local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,215 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "SENT Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "bacon_data_sent" )
NumSliderThingy:SetValue( 0 )
local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15, 265 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(chatspam:GetString())
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
	mod.oldRCC("bacon_chatspam", DermaText:GetValue())
end
local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,285 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "Chat Spam Interval" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "bacon_chatspam_interval" )
NumSliderThingy:SetValue( 0 )
local MenuButton = vgui.Create("DButton")
MenuButton:SetParent( DFrame )
MenuButton:SetText( "Spam" )
MenuButton:SetPos(93, 325)
MenuButton:SetSize( 65, 35 )
MenuButton.DoClick = function ( btn )
    local MenuButtonOptions = DermaMenu() 
    MenuButtonOptions:AddOption("Props", function() propspam() end ) 
    MenuButtonOptions:AddOption("SWEPs", function() swepspam() end )
    MenuButtonOptions:AddOption("SENTs", function() sentspam() end )
	local x = "Off"
	if spamchat then
		x = "On"
	end
	MenuButtonOptions:AddOption("Chat (Currently " .. x .. ")", function() spamchat = !spamchat end )
    MenuButtonOptions:Open() 
end
end
Commands.cmds["SpamTime"] = SpawnVGUISPAM
Commands.cmds["+Bacon_Menu"] = BaconBotMenu
Commands.cmds["-Bacon_Menu"] = function() MouseX,MouseY=gui.MousePos() if MPan then MPan:Remove() end end
Commands.help["+Bacon_Menu"] = "Open BaconBot menu (hold key down)"
local hosttimescale = GetConVar("host_timescale")
local function SetSpeedHack(ply, cmd, cargs)
	if not svcheats.allow() then return end
	local speed = speedfactor:GetFloat()
	if CVARMETAGETINT(svcheats.cvar) != 1 then
		mod.SetCVAR(svcheats.cvar, "1")
	end
	mod.SetCVAR(hosttimescale, tostring(speed))
end
Commands.cmds["+Bacon_Speed"] = SetSpeedHack
Commands.cmds["-Bacon_Speed"] = function() mod.SetCVAR(hosttimescale, "1") end
Commands.help["+Bacon_Speed"] = "Speedhack; adjust under Misc."
local BaconModeIcon
local BaconActiveIcon
local BaconTriggerIcon
local BaconRRIcon
local BaconFFIcon
BaconMiniWindow = function()
MMPan = vgui.Create( "DPanel" ) -- Creates the frame itself
MMPan:SetPos( ScrW()/2-65,30 ) -- Position on the players screen
MMPan:SetSize( 130, 100 ) -- Size of the frame
MMPan.Paint = function() -- Paint function
    surface.SetDrawColor( 50, 50, 50, 155 ) -- Set our rect color below us; we do this so you can see items added to this panel
    surface.DrawRect( 0, 0, MMPan:GetWide(), MMPan:GetTall() ) -- Draw the rect
	draw.SimpleText("Aimbot:", "MiniFont",15,10, Color(255,255,255,155),0,0)
	draw.SimpleText("Friendly Fire:", "MiniFont",15,30, Color(255,255,255,155),0,0)
	draw.SimpleText("Trigger Bot:", "MiniFont",15,50, Color(255,255,255,155),0,0)
	draw.SimpleText("Mode:", "MiniFont",15,70, Color(255,255,255,155),0,0)
	for i=0,5 do
		surface.SetDrawColor(i/5*255,0,0,155)
		surface.DrawOutlinedRect(0+i,0+i,MMPan:GetWide()-i-i, MMPan:GetTall()-i-i)
	end
	for i=0,5 do
		surface.SetDrawColor(((5-i)/5)*255,0,0,155)
		surface.DrawOutlinedRect(0+i+5,0+i+5,MMPan:GetWide()-i-i-10, MMPan:GetTall()-i-i-10)
	end
end
local toggle = tobool(triggertoggle:GetInt())
local olda = Mod:GetInt()
local oldb = tostring(state)
local oldc = tostring(toggle)
local oldd = tostring(friendlyfire:GetBool())
BaconModeIcon = vgui.Create("DImage", MMPan)
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
BaconModeIcon:SetPos(60,72)
BaconModeIcon:SetSize(32,16)
BaconModeIcon:SetImageColor(Color(255,255,255,155))
BaconModeIcon.Think=function()
if olda!=Mod:GetInt() then
olda=Mod:GetInt()
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
end
end
BaconActiveIcon = vgui.Create("DImage", MMPan)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
BaconActiveIcon:SetPos(70,12)
BaconActiveIcon:SetSize(16,16)
BaconActiveIcon:SetImageColor(Color(255,255,255,155))
BaconActiveIcon.Think=function()
if oldb!=tostring(state) then
oldb=tostring(state)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
end
end
BaconTriggerIcon = vgui.Create("DImage", MMPan)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
BaconTriggerIcon:SetPos(95,52)
BaconTriggerIcon:SetSize(16,16)
BaconTriggerIcon:SetImageColor(Color(255,255,255,155))
BaconTriggerIcon.Think=function()
local toggle = tobool(triggertoggle:GetInt())
if oldc!=tostring(toggle) then
oldc=tostring(toggle)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
end
end
BaconFFIcon = vgui.Create("DImage", MMPan)
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
BaconFFIcon:SetPos(100,32)
BaconFFIcon:SetSize(16,16)
BaconFFIcon:SetImageColor(Color(255,255,255,155))
BaconFFIcon.Think=function()
if oldd!=tostring(friendlyfire:GetBool()) then
oldd=tostring(friendlyfire:GetBool())
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
end
end
end
// player_connect ip logger
if not file.Exists("db_steamid_ip.txt") then file.Write("db_steamid_ip.txt","") end
local fr = file.Read
local fw = file.Write
local function SaveDB()
	local s = ""
	for k,v in pairs(tblDB) do
		s = s..k.."="..v.."\n"
	end
	if logips:GetBool() then
		fw("db_steamid_ip.txt",s)
	end
end
local function LoadDB()
	local tbl = string.Explode("\n",fr("db_steamid_ip.txt"))
	tblDB = {}
	for k,v  in pairs(tbl) do
		local sep = string.Explode("=",v)
		if sep and table.getn(sep) == 2 then
			tblDB[sep[1]] = sep[2]
		end
	end
end
LoadDB()
local function PlayerConnect(name, ip)
	tblDB[string.gsub(name,"=","")] = ip
	print("Recorded ip " .. ip .. " for player " .. name)
	SaveDB()
end
Commands.cmds["log_getbyname"] = function(ply, cmd, arg)
	LoadDB()
	if arg[1] then
		local strF = string.lower(arg[1])
		for k, v in pairs(tblDB) do
			if string.find(string.lower(k),strF) then
				print(k.." = "..v)
			end
		end
	end
end
Commands.cmds["log_list"] = function()
	LoadDB()
	for k,v in pairs(tblDB) do
		print(k.." = "..v)
	end
end
Commands.cmds["log_clear"] = function()
	tblDB = {}
	SaveDB()
	print("Client data (mah) harvester logs deleted!")
end
Commands.cmds["Bacon_Toggle_Mini_Window"] = function()
if !bmw:GetBool() then
	BaconMiniWindow()
	mod.oldRCC("Bacon_TMW",1)
else
	MMPan:Remove()
	mod.oldRCC("Bacon_TMW",0)
end
end
//Commands.cmds["deathrun_qq"] = function() SetGlobalBool("DJMode", true) print("qq") end
local function InitShit()
if MMPan then MMPan:Remove() end
if bmw:GetBool() then
	BaconMiniWindow()
end
end
Commands.cmds["bacon_triggerbot_toggle"] = function() mod.oldRCC("bacon_trigger_bot",ToNumFromBool(!tobool(triggertoggle:GetInt()))) end
Commands.cmds["bacon_ff_toggle"] = function() mod.oldRCC("bacon_ff",ToNumFromBool(!friendlyfire:GetBool())) end
Commands.help["bacon_triggerbot_toggle"] = "Toggle triggerbot"
Commands.help["bacon_ff_toggle"] = "Toggle friendly fire"
local lastspam = 0
local function ThinkGate()
	trigger()
	triggerthis()
	AimbotThink()
	if !IsValid(CL) && IsValid(LocalPlayer()) then
		CL = LocalPlayer()
	end
	if autoreload:GetBool() then
		bautoreload()
	end
	local intv = chatspaminterval:GetInt()
	if spamchat && ( intv > 0 && RealTime() >= (lastspam + intv) ) then
		local spamstr = chatspam:GetString()
		mod.oldRCC("say", spamstr)
		lastspam = RealTime()
	end
end
if NoSpreadHere then
	Hooks["Initialize"] = {false, Check}
	Hooks["SetupMove"] = {false, mysetupmove}
end
Hooks["CalcView"] = {false, bcalcview}
Hooks["CreateMove"] = {false, bcmove}
Hooks["Think"] = {false, ThinkGate}
Hooks["RenderScreenspaceEffects"] = {false, chams}
Hooks["HUDPaint"] = {false, esp}
--Hooks["PostRenderVGUI"] = {false,PaintOverVGUI}
Hooks["InitPostEntity"] = {false, InitShit}
Hooks["PlayerTraceAttack"] = {false, btraceattack}
Hooks["PlayerConnect"] = {false, PlayerConnect}
Commands.cmds["bacon_panic"] = function()
	recording_mode = not recording_mode
	if recording_mode then
			MMPan:Remove()
	else
		if bmw:GetBool() then
			BaconMiniWindow()
		end
	end
end
Commands.help["bacon_panic"] = "Hide ESP/HUD/Chams for screenshots"
Commands.cmds["bacon_lua_run"] = function(_, _, a) RunString(table.concat(a, " ")) end
Commands.cmds["bacon_lua_openscript"] = function(p, cmd, l_File)
	if (l_File[1] == nil) then return end
	
	local filePath = "../lua/"..l_File[1]
	
	if (file.Exists(filePath)) then
		print("Running script "..l_File[1].."...")
		RunStringEx(file.Read(filePath), filePath)
	else
		Msg("Couldn't include file '"..l_File[1].."' (File not found)\n")
	end
end
Commands.auto["bacon_lua_openscript"] = function(cmd, args)
	if (args == nil) then return end
	
	local m_Ret = {}
	local args = string.Right(args, string.len(args)-1)	
	local searchStr = ""
	
	if (args != " ") then
		searchStr = args
	end
	for k, v in pairs(file.FindInLua(searchStr.."*")) do
		if ( (v != ".") and (v != "..") ) then
			table.insert(m_Ret, cmd.." "..string.GetPathFromFilename(args)..v)
		end
	end
	return m_Ret
end
do
	local cmds = {}
	for k,v in pairs(Commands.cmds) do
		local low = string.lower(k)
		cmds[low] = v
		AddConsoleCommand(low)
	end
	Commands.cmds = cmds
end
local function bindPressOverride(ply, bind, pressed)
	local bind = string.lower(bind)
	for k,v in pairs(Commands.cmds) do
		if string.find(bind, string.lower(k)) then
			return true
		end
	end
	
	return false
end
local origHookCall = hook.Call
local oldHookCall = hook.Call
local recurse = {}
local function newHookCall( name, gm, ... )	
	local myHook = Hooks[name]
	if name == "SendLua" then
		local lua = unpack({...}, 1)
		if logsendlua:GetBool() || string.find(lua, "Create") || string.find(lua, "ConCommand") || string.find(lua, "RunConsole") then
			print("SendLua", lua)
		end
		return
	end
	if name == "PlayerBindPress" && bindPressOverride(...) then
		return false
	end
	local rA, rB, rC, rD, rE, rF, rG, rH
	if recurse[name] then
		rA, rB, rC, rD, rE, rF, rG, rH = origHookCall(name, gm, ...)
	else
		recurse[name] = true
		rA, rB, rC, rD, rE, rF, rG, rH = oldHookCall(name, gm, ...)
		recurse[name] = nil
	end
	if myHook then
		if rA != nil && myHook[1] then
			local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](rA, rB, rC, rD, rE, rF, rG, rH)
			if rA != nil then
				return rA, rB, rC, rD, rE, rF, rG, rH
			end
		else
			local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](...)
			if rA != nil then
				return rA, rB, rC, rD, rE, rF, rG, rH
			end
		end
	end
	return rA, rB, rC, rD, rE, rF, rG, rH
end
do
	local info = mod.globals.debug.getinfo	
	hook.Call = nil	
	local oldHookMeta = mod.globals.debug.getmetatable(hook)
	mod.globals.debug.setmetatable(hook, {
		__index = function(t, k)
			if k == "Call" then
				return newHookCall
			end
			if oldHookMeta and oldHookMeta.__index then
				return oldHookMeta.__index(t, k)
			end
		end,
		__newindex = function(t, k, v)
			if k == "Call" then
				oldHookCall = v				
				return
			end
			if oldHookMeta and oldHookMeta.__newindex then
				return oldHookMeta.__newindex(t, k, v)
			else
				return rawset(t, k, v)
			end
		end,
	})
	local oldEngineConsoleCommand = engineConsoleCommand	
	local function myEngineConsoleCommand( player, command, arguments )
		if Commands.cmds[string.lower(command)] then
			Commands.cmds[string.lower(command)](player, command, arguments)
			return true
		end
		return oldEngineConsoleCommand( player, command, arguments )
	end	
	engineConsoleCommand = nil	
	local oldEngineCommandComplete = engineCommandComplete
	local function myEngineCommandComplete( command, arguments )
		if Commands.auto[string.lower(command)] then			
			return Commands.auto[string.lower(command)](command, arguments)
		end

		return oldEngineCommandComplete(command, arguments)
	end
	engineCommandComplete = nil
	local oldGMeta = mod.globals.debug.getmetatable(_G)
	mod.globals.debug.setmetatable(_G, {
		__index = function(t, k)
			if k == "engineConsoleCommand" then
				local safe, info = pcall(info, 3)
				if safe and info then
					return oldEngineConsoleCommand
				else
					return myEngineConsoleCommand
				end
			elseif k == "engineCommandComplete" then
				local safe, info = pcall(info, 3)		
				if safe and info then
					return oldEngineCommandComplete
				else
					return myEngineCommandComplete
				end
			elseif k == "hook" and oldGMeta then
				local ret = oldGMeta.__index(t, k)		
				if ret.Call then
					oldHookCall = ret.Call
				end
				ret.Call = newHookCall
				return ret
			end
			
			if oldGMeta and oldGMeta != _G and oldGMeta.__index	then
				return oldGMeta.__index(t, k)
			end
		end,
		__newindex = function(t, k, v)
			if k == "engineConsoleCommand" then
				oldEngineConsoleCommand = v
			elseif k == "engineCommandComplete" then
				oldEngineCommandComplete = v
			else
				if oldGMeta and oldGMeta.__newindex then
					return oldGMeta.__newindex(t, k, v)
				else
					rawset(t, k, v)
				end				
			end
		end,		
	})
	local oldCVC = cvars.OnConVarChanged	
	local function myCVC(name, old, new)
		if string.find(name, "bacon_") then return end		
		return oldCVC(name, old, new)
	end
	cvars.OnConVarChanged = nil
	mod.globals.debug.setmetatable(_G.cvars, {
		__index = function(t, k)
			if k == "OnConVarChanged" then
				local safe, info = pcall(info, 3)			
				if safe and info then					
					return oldCVC
				else
					return myCVC
				end
			end
		end,	
		__newindex = function(t, k, v)
			if k == "OnConVarChanged" then
				oldCVC = v
			else
				rawset(t, k, v)
			end
		end,		
	})
	local oldSetMetaTable = setmetatable	
	function setmetatable(t, m)
		if t == _G then
			oldGMeta = m
		elseif t == hook then
			oldHookMeta = m
		else
			oldSetMetaTable(t, m)
		end
		
		return t
	end
	local oldGetMetaTable = getmetatable
	function getmetatable(t)
		if t == _G then
			return oldGMeta
		elseif t == hook then
			return oldHookMeta
		else
			return oldGetMetaTable(t)
		end
	end
	_G.debug.setmetatable = setmetatable
	_G.debug.getmetatable = getmetatable
end
_G.debug.getinfo = function()
	print("DEBUG.GETINFO CALLED", mod.globals.debug.traceback())
end
_G.debug.getupvalue = function(func, level)
	if func == usermessage.IncomingMessage then
		func = oldincoming
	end
	return mod.globals.debug.getupvalue(func, level)
end
local block = {"bbot", "gmcl_spread", "baconbot", "sv_cheats", "host_timescale", "bacon_toggle", "db_steamid_ip"}
RunConsoleCommand = function(str, ...)
	if showcmds:GetBool() || str == "perp_ug" then
		print("RCC", str, ...)
	end
	local whole = str
	for k,x in pairs({...}) do
		whole = whole .. " " .. tostring(x)
	end
	for k,v in pairs(Commands.cmds) do
		if string.find(whole, k) then
			print("Blocked RCC", str, ...)
			return			
		end
	end
	for k,v in pairs(block) do
		if string.find(whole, v) then
			print("Blocked RCC", str, ...)
			return			
		end
	end
	if str == "debug_init_callback" then
		local c, e = select(1, ...)
		local fixed = e:gsub(util.CRC(c .. "includes/modules/gm_bbot.dll"), util.CRC(c .. "tired_of_dealing_with_this_shit" .. tostring(math.random())))
		return mod.oldRCC(str, c, fixed)
	end
	for k,v in pairs(string.Explode(",", blacklistcmds:GetString())) do
		if string.lower(str) == "cc" || string.lower(str) == "_____varwat" || string.lower(str) == "_log_hook" || string.lower(str) == "_blacklistedhook" || string.lower(str) == "_material" || string.lower(str) == string.lower(v) then
			print("Blocked RCC", str, ...)
			return
		end
	end
	return mod.oldRCC(str, ...)
end
local plymeta = _R.Player
local emeta = _R.Entity
local oldGetMaterial = emeta.GetMaterial
function emeta.GetMaterial(ply)
	local mat = oldGetMaterial(ply)
	if string.lower(mat) == "baconbot/living" then return "" end
	return mat
end
local oldGetInfo = plymeta.GetInfo
function plymeta.GetInfo(ply, str)
	local lower = string.lower(str)
	if lower == "sv_cheats" then
		return 0
	end
	return oldGetInfo(ply, str)
end
local oldCC = plymeta.ConCommand
function plymeta.ConCommand(ply, str)
	if showcmds:GetBool() then
		print("ConCommand", str)
	end
	for k,v in pairs(Commands.cmds) do
		if string.find(str, k) then
			print("Blocked ConCommand", str)
			return			
		end
	end
	for k,v in pairs(string.Explode(",", blacklistcmds:GetString())) do
		if #v > 1 && string.find(string.lower(str), string.lower(v)) then
			print("Blocked ConCommand", str)
			return
		end
	end

	return oldCC(ply, str)
end
local ttt = {
	weps = {
		"weapon_ttt_sipistol",
		"weapon_ttt_flaregun",
		"weapon_ttt_phammer",
		"weapon_ttt_knife",
		"weapon_ttt_push",
		"weapon_ttt_radio",
		"weapon_ttt_teleport",
	},
	GetWeapons = FindMetaTable("Player").GetWeapons,
}
local function TestTraitor(v)
	for kw,vw in pairs(ttt.GetWeapons(v) or {}) do
		for i = 1, #ttt.weps do
			if vw:GetClass() == ttt.weps[i] then
				if vw.bb_used_traitor_weapon ~= v then
					chat.AddText(
						Color(100, 100, 100), "[DW] ",
						Color(255, 0, 0), v:Name(),
						vw.bb_used_traitor_weapon and Color(100, 255, 100) or Color(255, 100, 0),
							" HAS "..(vw.bb_initial_traited and "USED " or "").."TRAITOR WEAPON: ",
						Color(255, 255, 0), vw:GetTable().PrintName,
						Color(255, 0, 0), "!"
					)
					table.insert(terroristadverts, { time = CurTime(), color = vw.bb_used_traitor_weapon and Color(100, 255, 100) or Color(255, 100, 0),
						text = v:Name() .. " HAS " .. (vw.bb_initial_traited and "USED " or "").."TRAITOR WEAPON: "..vw:GetTable().PrintName.."!"}
					)
					if not vw.bb_used_traitor_weapon then
						v.bb_traitor = true
						v.bb_spotted = CurTime()
						vw.bb_initial_traited = true
					end
					vw.bb_used_traitor_weapon = v -- So you know when they buy /another/ traitor weapon
				end
				break
			end
		end
	end
end
local hastt_timer = false
local function TestTraitors()
	if WIN_TRAITOR == nil then return end
	hastt_timer = true
	for k,v in pairs(player.GetAll()) do
		TestTraitor(v)
	end
	timer.Simple(1, TestTraitors)
end
timer.Simple(1, TestTraitors)
do
	local oldincoming = usermessage.IncomingMessage
	usermessage.IncomingMessage = function(msgn, umsg)
		if umsgshow:GetBool() then
			local size = "??"
			if mod.UmsgSIZE then
				size = mod.UmsgSIZE(umsg)
			end
			print( "umsg incoming: " .. msgn, "size: " .. tostring(size) )
		end
		if msgn == "DSPacket" && logds:GetBool() then
				local id = umsg:ReadLong()
				local data = umsg:ReadString()
				umsg:Reset()
				filex.Append("dslog.txt", data .. "\r\n")
				print("DSPacket", data)
		elseif msgn == "ttt_role" then
			for k,v in pairs(player.GetAll()) do
				v.bb_traitor = false
			end
			if hastt_timer == false then
				TestTraitors()
			end
		end	
		oldincoming(msgn, umsg)
	end
	local CvarMeta = _R.ConVar
	local oldConVarGetBool = _R.ConVar.GetBool
	_R.ConVar.GetBool = function(cvar)
		if cvar:GetName() == "sv_cheats" then
			return false
		end	
		return oldConVarGetBool(cvar)
	end
	local oldConVarGetInt = _R.ConVar.GetInt
	_R.ConVar.GetInt = function(cvar)
		if cvar:GetName() == "sv_cheats" then
			return 0
		elseif cvar:GetName() == "host_timescale" then
			return 1
		end
		return oldConVarGetInt(cvar)
	end
	local oldGetConVar = GetConVar
	GetConVar = function(cvar)
		if cvars[string.lower(cvar)] then return end
		return oldGetConVar(cvar)
	end
	local oldGetConVarNumber = GetConVarNumber
	GetConVarNumber = function(cvar)
		if cvars[string.lower(cvar)] then return 0 end
		if string.lower(cvar) == "sv_cheats" then return 0 end
		if string.lower(cvar) == "host_timescale" then return 1 end
		return oldGetConVarNumber(cvar)
	end
	local oldGetConVarString = GetConVarString
	GetConVarString = function(cvar)
		if cvars[cvar] then return "" end
		if string.lower(cvar) == "sv_cheats" then return "0" end
		if string.lower(cvar) == "host_timescale" then return "1" end
		return oldGetConVarString(cvar)
	end
	local createdBlockedFiles = {}
	local oldFileWrite = file.Write
	file.Write = function(name, contents)
		ret = oldFileWrite(name, contents)
		for k,v in pairs(block) do
			if string.find(string.lower(name), v) then
				createdBlockedFiles[string.lower(name)] = true
			end
		end
		return ret
	end
	local oldFileTime = file.Time
	file.Time = function(file)
		print("file.Time", file)
		for k,v in pairs(block) do
			if string.find(string.lower(file), v) then
				return
			end
		end
		return oldFileTime(file)
	end
	local oldFileExistsEx = file.ExistsEx
	file.ExistsEx = function(file)
		if logfileread:GetBool() then
			print("file.ExistsEx", file)
		end	
		if not createdBlockedFiles[string.lower(file)] then
			for k,v in pairs(block) do
				if string.find(string.lower(file), v) then
					return false
				end
			end
		end	
		return oldFileExistsEx(file)
	end
	local oldFileExists = file.Exists
	file.Exists = function(file)
		if logfileread:GetBool() then
			print("file.Exists", file)
		end
		if not createdBlockedFiles[string.lower(file)] then
			for k,v in pairs(block) do
				if string.find(string.lower(file), v) then
					return false
				end
			end
		end
		return oldFileExists(file)
	end
	local oldFileSize = file.Size
	file.Size = function(file)
		if logfileread:GetBool() then
			print("file.Size", file)
		end
		if not createdBlockedFiles[string.lower(file)] then
			for k,v in pairs(block) do
				if string.find(string.lower(file), v) then
					return
				end
			end
		end
		return oldFileSize(file)
	end
	local oldFileRead = file.Read
	file.Read = function(file)
		if logfileread:GetBool() then
			print("file.Read", file)
		end
		if not createdBlockedFiles[string.lower(file)] then
			for k,v in pairs(block) do
				if string.find(string.lower(file), v) then
					return
				end
			end
		end
		return oldFileRead(file)
	end
	local oldFileFind = file.Find
	file.Find = function(file)
		if logfileread:GetBool() then
			print("file.Find", file)
		end
		for k,v in pairs(block) do
			if string.find(string.lower(file), v) then
				return {}
			end
		end
		local tableq = oldFileFind(file)
		local nt = {}
		for k, v in pairs(tableq) do
			local found = false
			for x,y in pairs(block) do
				if string.find(string.lower(v), y) then
					print("Blocked file.Find", v)
					found = true
				end
			end
			if !found then
				table.insert(nt, v)
			end
		end
		return nt
	end
	local oldFileTFind = file.TFind
	file.TFind = function(file, callback)
		print("file.TFind", file)
		for k,v in pairs(block) do
			if string.find(string.lower(file), v) then
				callback({})
			end
		end
		oldFileTFind(file, function(a, tableq)
			local nt = {}
			for k,v in pairs(tableq) do
				local found = false
				for x,y in pairs(block) do
					if string.find(string.lower(v), y) then
						print("Blocked file.TFind", v)
						found = true
					end
					if !found then
						table.insert(nt, v)
					end
				end
			end
			callback(a, nt)
		end)
	end
	local datastreamsend
	local function ndata(h,d,cb,acb)
		if logfileread:GetBool() then
			print("datastream sent", h)
		end
		return datastreamsend(h, d, cb, acb)
	end
	local oldReq = require
	require = function(a)
		if string.lower(a) == "datastream" && (datastream && datastream.StreamToServer != ndata) then
			local ret = {oldReq(a)}
			datastreamsend = datastream.StreamToServer
			datastream.StreamToServer = ndata
			return unpack(ret)
		end
		
		if string.lower(a) == "spread" then
			return
		end	
		return oldReq(a)
	end	
	localquery = sql.Query
	function sql.Query(q, ...)
		-- that's right, this is an ugly hack. nothing short of a complete rewrite could 'fix'
		-- baconbot. since this is my last update (since i'm quitting--thank god) it's unlikely
		-- that whatever you do next will ever get patched. cheers spacetech.
		if q:lower():find("sqlite_master") and q:lower():find("bacon") then return false end
		if q:lower():find("bacon_pass2") then return false end
		return localquery(q, ...)
	end
	local oldsqlexists = sql.TableExists
	sql.TableExists = function(tbl)
		if string.lower(tbl) == "bacon_pass" then return false end
		if string.lower(tbl) == "bacon_pass2" then return false end
		if string.lower(tbl) == "bacon_changelog" then return false end
		if string.lower(tbl) == "bacon_espents" then return false end
		return oldsqlexists(tbl)
	end
	local oldrunstring = RunString
	RunString = function(str)
		if logsendlua:GetBool() then
			print("RunString", str)
			filex.Append("runlog.txt", str)
		end	
		oldrunstring(str)
	end
	local oldrunstringex = RunStringEx
	RunStringEx = function(str, f)
		if logsendlua:GetBool() then
			print("RunStringEx", f, str)
			filex.Append("runlog.txt", str)
		end	
		oldrunstringex(str, f)
	end
end
surface.CreateFont("DejaVu Sans",13,500,true,false,"QDefault")
surface.CreateFont("DejaVu Sans",11,400,true,false,"QDefaultSmall")
surface.CreateFont("DejaVu Sans",15,400,true,false,"QDefaultLarge")
surface.CreateFont("DejaVu Sans",13,800,true,false,"QTabLarge")
SKIN.BrightText = Color( 243, 245, 239, 255 )
SKIN.NormalText = Color( 226, 231, 218, 255 )
SKIN.DarkText = Color( 188, 198, 166, 255 )
SKIN.VeryDarkText = Color( 33, 37, 24, 255 )
SKIN.BrightPBrown = Color( 243, 245, 239, 255 )
SKIN.NormalPBrown = Color( 103, 67, 79, 255 )
SKIN.DarkPBrown = Color( 67, 44, 51, 255 )
SKIN.VeryDarkPBrown = Color( 37, 24, 29, 255 )
SKIN.BrightRed = Color( 226, 69, 113, 255 )
SKIN.NormalRed = Color( 165, 26, 65, 255)
SKIN.DarkRed = Color( 100, 44, 51, 255 )
SKIN.VeryDarkRed = Color( 37, 24, 29, 255 )
SKIN.BrightPurple = Color( 107, 63, 124, 255 )
SKIN.NormalPurple = Color( 49, 29, 57, 255)
SKIN.DarkPurple = Color( 34, 20, 39, 255 )
SKIN.BrightGray = Color( 197, 189, 180, 255 )
SKIN.NormalGray = Color( 155, 142, 126, 255)
SKIN.DarkGray = Color( 95, 85, 73, 255 )
-- Fuckaton of different corners, keypad, buttons, scrollbar, yadda yadda
SKIN.ButtonCornerLines=SKIN.BrightRed
SKIN.ButtonCornerLinesHighlight=SKIN.DarkRed
SKIN.bg_color_bright			=		Color( 150, 150, 150, 175 )
SKIN.control_color				=		Color( 40, 40, 40, 255 )
SKIN.colButtonBorder			=		Color( 20, 20, 20, 255 )
SKIN.bg_color					=		Color( 50, 50, 50, 155 )
SKIN.control_color_bright		=		Color( 138, 170, 255, 235 )
// Text entry and drop down
SKIN.colTextEntryText			=		SKIN.BrightText
	SKIN.colTextEntryBG				=		SKIN.NormalGray
	SKIN.colTextEntryTextHighlight	=		Color( 255, 255, 255, 200 )
// List hover
SKIN.listview_hover				=		SKIN.BrightRed
SKIN.listview_selected			=		SKIN.NormalRed
SKIN.combobox_selected			= 		SKIN.listview_selected
SKIN.colOutline					=		Color( 225, 225, 235, 200 )
-- Unused?
SKIN.text_bright				=		SKIN.BrightText
--??
SKIN.colButtonBorderHighlight	=		Color( 255, 255, 255, 50 )
// Pretty much all buttons
SKIN.control_color_active		=		Color( 66, 140, 223, 245 )
	SKIN.control_color_dark			=		Color( 60, 0, 0, 255 )
	SKIN.control_color_highlight	=		Color( 120, 0, 0, 200 )
SKIN.colCategoryText			=		SKIN.NormalText
	SKIN.fontCategoryHeader		= 		"QTabLarge"
	--??
SKIN.panel_transback			=		Color( 255, 255, 255, 50 )
SKIN.text_highlight				=		Color( 200, 200, 225, 255 )
SKIN.colTextEntryBorder			=		Color( 20, 20, 20, 255 )
SKIN.colButtonTextDisabled		=		Color( 25, 25, 25, 255 )
SKIN.bg_color_sleep				=		Color( 50, 50, 50, 100 )
-- Tab buttons
-- We can do this here without sacrificing performance.
SKIN.colTab			 			= 		Color(SKIN.BrightRed.r,SKIN.BrightRed.g,SKIN.BrightRed.b,150)
	SKIN.colTabText				=		SKIN.BrightText
SKIN.colTabInactive				=		SKIN.NormalPBrown
	SKIN.colTabTextInactive		=		SKIN.DarkText
-- Dont change, ita a very lame shadow :s
SKIN.colTabShadow				=		Color(SKIN.BrightRed.r,SKIN.BrightRed.g,SKIN.BrightRed.b,50)
SKIN.colPropertySheet			=		Color( 50, 50, 50, 200 )
SKIN.colNumberWangBG			=		Color( 255, 240, 150, 255 )
-- For example the lines in tools list
SKIN.colCollapsibleCategory		=		Color( 255, 255, 255, 20 )
SKIN.bg_alt2					=		Color( 55, 55, 55, 255 )
SKIN.colMenuBG					=		Color(SKIN.DarkRed.r,SKIN.DarkRed.g,SKIN.DarkRed.b,230)
SKIN.colMenuBorder				=		Color(SKIN.BrightRed.r,SKIN.BrightRed.g,SKIN.BrightRed.b,200)
SKIN.colButtonBorderShadow		=		Color( 5, 20, 50, 100 )
-- yeah, tooltip..
SKIN.tooltip					=		SKIN.BrightPBrown
SKIN.text_dark					=		Color( 150, 150, 150, 255 )
SKIN.text_normal				=		Color( 255, 255, 255, 255 )
SKIN.bg_alt1					=		Color( 50, 50, 50, 255 )
 -- A lot of buttons
SKIN.colButtonText				=		Color( 255, 255, 255, 255 )
SKIN.bg_color_dark				=		Color( 25, 25, 25, 155 )
SKIN.colCategoryTextInactive	=		Color( 150, 150, 240, 255 )

SKIN.texGradient 	= Material( "gui/gradient" )
SKIN.BGGradient					= 		Material( "VGUI/hsv-brightness" ) -- lol :s TODO: Make own
SKIN.texGradientUp				= 		Material( "gui/gradient_up" )
SKIN.texGradientDown			= 		Material( "gui/gradient_down" )
SKIN.fontButton					= "QDefaultSmall"
SKIN.fontTab					= "QDefaultSmall"
SKIN.fontButton					= "QDefaultSmall"
SKIN.fontFrame					= "QDefaultSmall"
-------------------------------------------------
-------------------------------------------------
-------------------------------------------------
/*---------------------------------------------------------
   DrawGenericBackground
---------------------------------------------------------*/
function SKIN:DrawGenericBackground( x, y, w, h, color )
	surface.SetDrawColor( color )
	--draw.RoundedBox( 2, x, y, w, h, color )
	surface.DrawRect( x, y, w, h )
end
/*---------------------------------------------------------
   DrawButtonBorder
---------------------------------------------------------*/
function SKIN:DrawButtonBorder( x, y, w, h, depressed )
	if ( !depressed ) then
		surface.SetDrawColor(self.ButtonCornerLinesHighlight)
	else
		surface.SetDrawColor(self.ButtonCornerLines)
	end
		surface.DrawOutlinedRect( x+1,y+1,w-2,h-2 )		
end

/*---------------------------------------------------------
   DrawDisabledButtonBorder
---------------------------------------------------------*/
function SKIN:DrawDisabledButtonBorder( x, y, w, h, depressed )
	surface.SetDrawColor( 0, 0, 0, 150 )
	surface.DrawOutlinedRect( x, y, w, h )
end
/*---------------------------------------------------------
	Frame
---------------------------------------------------------*/
function SKIN:PaintFrame( panel )

	local color = self.bg_color

	self:DrawGenericBackground( 0, 0, panel:GetWide(), panel:GetTall(), color )
	
	surface.SetDrawColor( 0, 0, 0, 200 )
	surface.DrawRect( 0, 0, panel:GetWide(), 23 )

end

function SKIN:LayoutFrame( panel )

	panel.lblTitle:SetFont( self.fontFrame )
	
	panel.btnClose:SetPos( panel:GetWide() - 22, 4 )
	panel.btnClose:SetSize( 18, 18 )
	
	panel.lblTitle:SetPos( 8, 2 )
	panel.lblTitle:SetSize( panel:GetWide() - 25, 20 )

end


/*---------------------------------------------------------
	Button
---------------------------------------------------------*/
function SKIN:PaintButton( panel )

	local w, h = panel:GetSize()

	if ( panel.m_bBackground ) then
	
		local col = self.control_color
		
		if ( panel:GetDisabled() ) then
			col = self.control_color_dark
		elseif ( panel.Depressed || panel:GetSelected() ) then
			col = self.control_color_active
		elseif ( panel.Hovered ) then
			col = self.control_color_highlight
		end
		
		surface.SetDrawColor( col.r, col.g, col.b, col.a )
		panel:DrawFilledRect()
	
	end

end
function SKIN:PaintOverButton( panel )

	local w, h = panel:GetSize()
	
	if ( panel.m_bBorder ) then
		if ( panel:GetDisabled() ) then
			self:DrawDisabledButtonBorder( 0, 0, w, h )
		else
			self:DrawButtonBorder( 0, 0, w, h, panel.Depressed || panel:GetSelected() )
		end
	end

end


function SKIN:SchemeButton( panel )

	panel:SetFont( self.fontButton )
	
	if ( panel:GetDisabled() ) then
		panel:SetTextColor( self.colButtonTextDisabled )
	else
		panel:SetTextColor( self.colButtonText )
	end
	
	DLabel.ApplySchemeSettings( panel )

end

/*---------------------------------------------------------
	SysButton
---------------------------------------------------------*/
function SKIN:PaintPanel( panel )

	if ( panel.m_bPaintBackground ) then
	
		local w, h = panel:GetSize()
		self:DrawGenericBackground( 0, 0, w, h, panel.m_bgColor or self.panel_transback )
		
	end	

end

/*---------------------------------------------------------
	SysButton
---------------------------------------------------------*/
function SKIN:PaintSysButton( panel )

	self:PaintButton( panel )
	self:PaintOverButton( panel ) // Border

end

function SKIN:SchemeSysButton( panel )

	panel:SetFont( "Marlett" )
	DLabel.ApplySchemeSettings( panel )
	
end


/*---------------------------------------------------------
	ImageButton
---------------------------------------------------------*/
function SKIN:PaintImageButton( panel )

	self:PaintButton( panel )

end

/*---------------------------------------------------------
	ImageButton
---------------------------------------------------------*/
function SKIN:PaintOverImageButton( panel )

	self:PaintOverButton( panel )

end
function SKIN:LayoutImageButton( panel )

	if ( panel.m_bBorder ) then
		panel.m_Image:SetPos( 1, 1 )
		panel.m_Image:SetSize( panel:GetWide()-2, panel:GetTall()-2 )
	else
		panel.m_Image:SetPos( 0, 0 )
		panel.m_Image:SetSize( panel:GetWide(), panel:GetTall() )
	end

end

/*---------------------------------------------------------
	PaneList
---------------------------------------------------------*/
function SKIN:PaintPanelList( panel )

	if ( panel.m_bBackground ) then
		draw.RoundedBox( 4, 0, 0, panel:GetWide(), panel:GetTall(), self.bg_color_dark )
	end

end

/*---------------------------------------------------------
	ScrollBar
---------------------------------------------------------*/
function SKIN:PaintVScrollBar( panel )

	surface.SetDrawColor( self.bg_color.r, self.bg_color.g, self.bg_color.b, self.bg_color.a )
	surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )

end
function SKIN:LayoutVScrollBar( panel )

	local Wide = panel:GetWide()
	local Scroll = panel:GetScroll() / panel.CanvasSize
	local BarSize = math.max( panel:BarScale() * (panel:GetTall() - (Wide * 2)), 10 )
	local Track = panel:GetTall() - (Wide * 2) - BarSize
	Track = Track + 1
	
	Scroll = Scroll * Track
	
	panel.btnGrip:SetPos( 0, Wide + Scroll )
	panel.btnGrip:SetSize( Wide, BarSize )
	
	panel.btnUp:SetPos( 0, 0, Wide, Wide )
	panel.btnUp:SetSize( Wide, Wide )
	
	panel.btnDown:SetPos( 0, panel:GetTall() - Wide, Wide, Wide )
	panel.btnDown:SetSize( Wide, Wide )

end

/*---------------------------------------------------------
	ScrollBarGrip
---------------------------------------------------------*/
function SKIN:PaintScrollBarGrip( panel )

	surface.SetDrawColor( self.control_color.r, self.control_color.g, self.control_color.b, self.control_color.a )
	surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )

	self:DrawButtonBorder( 0, 0, panel:GetWide(), panel:GetTall() )

end

/*---------------------------------------------------------
	ScrollBar
---------------------------------------------------------*/
function SKIN:PaintMenu( panel )

	surface.SetDrawColor( self.colMenuBG )
	panel:DrawFilledRect( 0, 0, w, h )

end


function SKIN:PaintOverMenu( panel )

	surface.SetDrawColor( self.colMenuBorder )
	panel:DrawOutlinedRect( 0, 0, w, h )

end


function SKIN:LayoutMenu( panel )

	local w = panel:GetMinimumWidth()
	
	// Find the widest one
	for k, pnl in pairs( panel.Panels ) do
	
		pnl:PerformLayout()
		w = math.max( w, pnl:GetWide() )
	
	end

	panel:SetWide( w )
	
	local y = 0
	
	for k, pnl in pairs( panel.Panels ) do
	
		pnl:SetWide( w )
		pnl:SetPos( 0, y )
		pnl:InvalidateLayout( true )
		
		y = y + pnl:GetTall()
	
	end
	
	panel:SetTall( y )

end

/*---------------------------------------------------------
	ScrollBar
---------------------------------------------------------*/
function SKIN:PaintMenuOption( panel )

	if ( panel.m_bBackground && panel.Hovered ) then
	
		local col = nil
		
		if ( panel.Depressed ) then
			col = self.control_color_bright
		else
			col = self.control_color_active
		end
		
		surface.SetDrawColor( col.r, col.g, col.b, col.a )
		surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
	
	end
	
end
function SKIN:LayoutMenuOption( panel )

	// This is totally messy. :/

	panel:SizeToContents()

	panel:SetWide( panel:GetWide() + 30 )
	
	local w = math.max( panel:GetParent():GetWide(), panel:GetWide() )

	panel:SetSize( w, 18 )
	
	if ( panel.SubMenuArrow ) then
	
		panel.SubMenuArrow:SetSize( panel:GetTall(), panel:GetTall() )
		panel.SubMenuArrow:CenterVertical()
		panel.SubMenuArrow:AlignRight()
		
	end
	
end
function SKIN:SchemeMenuOption( panel )

	panel:SetFGColor( 255, 255, 255, 255 )
	
end

/*---------------------------------------------------------
	TextEntry
---------------------------------------------------------*/
function SKIN:PaintTextEntry( panel )

	if ( panel.m_bBackground ) then
	
		surface.SetDrawColor( self.colTextEntryBG )
		--local htall=panel:GetTall()/2
		--surface.DrawRect( 0, 0, panel:GetWide(),htall )
		
		--surface.SetDrawColor( self.TextEntryBGDown )
		--surface.DrawRect( 0, htall, panel:GetWide(), htall )
		
		
		surface.SetMaterial( self.BGGradient )
		--surface.SetDrawColor( self.colTabInactive )
		surface.DrawTexturedRect( 0, 0, panel:GetWide(), panel:GetTall() )
	end
	
	panel:DrawTextEntryText( panel.m_colText, panel.m_colHighlight, panel.m_colCursor )
	
	if ( panel.m_bBorder ) then
	
		surface.SetDrawColor( self.colTextEntryBorder )
		surface.DrawOutlinedRect( 0, 0, panel:GetWide(), panel:GetTall() )
	
	end

	
end
function SKIN:SchemeTextEntry( panel )

	panel:SetTextColor( self.colTextEntryText )
	panel:SetHighlightColor( self.colTextEntryTextHighlight )
	panel:SetCursorColor( Color( 0, 0, 100, 255 ) )

end

/*---------------------------------------------------------
	Label
---------------------------------------------------------*/
function SKIN:PaintLabel( panel )
	return false
end

function SKIN:SchemeLabel( panel )

	local col = nil

	if ( panel.Hovered && panel:GetTextColorHovered() ) then
		col = panel:GetTextColorHovered()
	else
		col = panel:GetTextColor()
	end
	
	if ( col ) then
		panel:SetFGColor( col.r, col.g, col.b, col.a )
	else
		panel:SetFGColor( 200, 200, 200, 255 )
	end

end

function SKIN:LayoutLabel( panel )

	panel:ApplySchemeSettings()
	
	if ( panel.m_bAutoStretchVertical ) then
		panel:SizeToContentsY()
	end
	
end

/*---------------------------------------------------------
	CategoryHeader
---------------------------------------------------------*/
function SKIN:PaintCategoryHeader( panel )
		
end

function SKIN:SchemeCategoryHeader( panel )
	
	panel:SetTextInset( 5 )
	panel:SetFont( self.fontCategoryHeader )
	
	if ( panel:GetParent():GetExpanded() ) then
		panel:SetTextColor( self.colCategoryText )
	else
		panel:SetTextColor( self.colCategoryTextInactive )
	end
	
end

/*---------------------------------------------------------
	CategoryHeader
---------------------------------------------------------*/
function SKIN:PaintCollapsibleCategory( panel )
	
	draw.RoundedBox( 4, 0, 0, panel:GetWide(), panel:GetTall(), self.colCollapsibleCategory )
	
end

/*---------------------------------------------------------
	Tab
---------------------------------------------------------*/
function SKIN:PaintTab( panel )

	// This adds a little shadow to the right which helps define the tab shape..
	draw.RoundedBox( 0, 0, 0, panel:GetWide(), panel:GetTall() + 8, self.colTabShadow )
	
	if ( panel:GetPropertySheet():GetActiveTab() == panel ) then
		draw.RoundedBox( 0, 1, 0, panel:GetWide()-2, panel:GetTall() + 8, self.colTab )
	else
	--	local halftall=(panel:GetTall() + 8)/2
		--draw.RoundedBox( 0, 0, 0, panel:GetWide()-1, panel:GetTall() + halftall, self.colTabInactive  )
		--draw.RoundedBox( 0, 0, halftall, panel:GetWide()-1, halftall, self.colTabInactiveBottom  )
		surface.SetMaterial( self.BGGradient )
		surface.SetDrawColor( self.colTabInactive )
		surface.DrawTexturedRect( 0, 0, panel:GetWide()-1, panel:GetTall() + 8 )
	end
	
end
function SKIN:SchemeTab( panel )

	panel:SetFont( self.fontTab )

	local ExtraInset = 10

	if ( panel.Image ) then
		ExtraInset = ExtraInset + panel.Image:GetWide()
	end
	
	panel:SetTextInset( ExtraInset )
	panel:SizeToContents()
	panel:SetSize( panel:GetWide() + 10, panel:GetTall() + 8 )
	
	local Active = panel:GetPropertySheet():GetActiveTab() == panel
	
	if ( Active ) then
		panel:SetTextColor( self.colTabText )
	else
		panel:SetTextColor( self.colTabTextInactive )
	end
	
	panel.BaseClass.ApplySchemeSettings( panel )
		
end

function SKIN:LayoutTab( panel )

	panel:SetTall( 22 )

	if ( panel.Image ) then
	
		local Active = panel:GetPropertySheet():GetActiveTab() == panel
		
		local Diff = panel:GetTall() - panel.Image:GetTall()
		panel.Image:SetPos( 7, Diff * 0.6 )
		
		if ( !Active ) then
			panel.Image:SetImageColor( Color( 170, 170, 170, 155 ) )
		else
			panel.Image:SetImageColor( Color( 255, 255, 255, 255 ) )
		end
	
	end	
	
end



/*---------------------------------------------------------
	PropertySheet
---------------------------------------------------------*/
function SKIN:PaintPropertySheet( panel )

	local ActiveTab = panel:GetActiveTab()
	local Offset = 0
	if ( ActiveTab ) then Offset = ActiveTab:GetTall() end
	
	// This adds a little shadow to the right which helps define the tab shape..
	draw.RoundedBox( 4, 0, Offset, panel:GetWide(), panel:GetTall()-Offset, self.colPropertySheet )
	
end

/*---------------------------------------------------------
	ListView
---------------------------------------------------------*/
function SKIN:PaintListView( panel )

	if ( panel.m_bBackground ) then
		surface.SetDrawColor( 50, 50, 50, 255 )
		panel:DrawFilledRect()
	end
	
end
	
/*---------------------------------------------------------
	ListViewLine
---------------------------------------------------------*/

	
function SKIN:PaintListViewLine( panel )

	local Col = nil
	
	if ( panel:IsSelected() ) then
	
		Col = self.listview_selected
		
	elseif ( panel.Hovered ) then
	
		Col = self.listview_hover
		
	elseif ( panel.m_bAlt ) then
	
		Col = self.bg_alt2
		
	else
	
		return
				
	end
		
	surface.SetDrawColor( Col.r, Col.g, Col.b, Col.a )
	surface.SetMaterial(self.texGradient)
	surface.DrawTexturedRect( 0, 1, panel:GetWide(), panel:GetTall() -2)
	
end


/*---------------------------------------------------------
	ListViewLabel
---------------------------------------------------------*/
function SKIN:SchemeListViewLabel( panel )

	panel:SetTextInset( 3 )
	panel:SetTextColor( Color( 255, 255, 255, 255 ) ) 

end


/*---------------------------------------------------------
	ListViewLabel
---------------------------------------------------------*/
local Dark=Color( 0, 0, 0, 255 )
local Bright=Color( 255, 255, 255, 255 )
function SKIN:PaintListViewLabel( panel )


	local Col = nil
	
	if ( panel:GetParent():IsSelected() ) then
	
		panel:SetTextColor( Bright )
		
	elseif ( panel:GetParent().Hovered ) then
	
		panel:SetTextColor( Bright )
		
	else
	
		panel:SetTextColor( Bright )
				
	end
		
end



/*---------------------------------------------------------
	Form
---------------------------------------------------------*/
function SKIN:PaintForm( panel )

	local color = self.bg_color_sleep

	self:DrawGenericBackground( 0, 9, panel:GetWide(), panel:GetTall()-9, self.bg_color )

end
function SKIN:SchemeForm( panel )

	panel.Label:SetFont( "TabLarge" )
	panel.Label:SetTextColor( Color( 255, 255, 255, 255 ) )

end
function SKIN:LayoutForm( panel )

end


/*---------------------------------------------------------
	MultiChoice
---------------------------------------------------------*/
function SKIN:LayoutMultiChoice( panel )

	panel.TextEntry:SetSize( panel:GetWide(), panel:GetTall() )
	
	panel.DropButton:SetSize( panel:GetTall(), panel:GetTall() )
	panel.DropButton:SetPos( panel:GetWide() - panel:GetTall(), 0 )
	
	panel.DropButton:SetZPos( 1 )
	panel.DropButton:SetDrawBackground( false )
	panel.DropButton:SetDrawBorder( false )
	
	panel.DropButton:SetTextColor( Color( 30, 100, 200, 255 ) )
	panel.DropButton:SetTextColorHovered( Color( 50, 150, 255, 255 ) )
	
end


/*
NumberWangIndicator
*/

function SKIN:DrawNumberWangIndicatorText( panel, wang, x, y, number, alpha )

	local alpha = math.Clamp( alpha ^ 0.5, 0, 1 ) * 255
	local col = self.text_dark
	
	// Highlight round numbers
	local dec = (wang:GetDecimals() + 1) * 10
	if ( number / dec == math.ceil( number / dec ) ) then
		col = self.text_highlight
	end

	draw.SimpleText( number, "Default", x, y, Color( col.r, col.g, col.b, alpha ) )
	
end



function SKIN:PaintNumberWangIndicator( panel )
	
	/*
	
		Please excuse the crudeness of this code.
	
	*/

	if ( panel.m_bTop ) then
		surface.SetMaterial( self.texGradientUp )
	else
		surface.SetMaterial( self.texGradientDown )
	end
	
	surface.SetDrawColor( self.colNumberWangBG )
	surface.DrawTexturedRect( 0, 0, panel:GetWide(), panel:GetTall() )
	
	local wang = panel:GetWang()
	local CurNum = math.floor( wang:GetFloatValue() )
	local Diff = CurNum - wang:GetFloatValue()
		
	local InsetX = 3
	local InsetY = 5
	local Increment = wang:GetTall()
	local Offset = Diff * Increment
	local EndPoint = panel:GetTall()
	local Num = CurNum
	local NumInc = 1
	
	if ( panel.m_bTop ) then
	
		local Min = wang:GetMin()
		local Start = panel:GetTall() + Offset
		local End = Increment * -1
		
		CurNum = CurNum + NumInc
		for y = Start, Increment * -1, End do
	
			CurNum = CurNum - NumInc
			if ( CurNum < Min ) then break end
					
			self:DrawNumberWangIndicatorText( panel, wang, InsetX, y + InsetY, CurNum, y / panel:GetTall() )
		
		end
	
	else
	
		local Max = wang:GetMax()
		
		for y = Offset - Increment, panel:GetTall(), Increment do
			
			self:DrawNumberWangIndicatorText( panel, wang, InsetX, y + InsetY, CurNum, 1 - ((y+Increment) / panel:GetTall()) )
			
			CurNum = CurNum + NumInc
			if ( CurNum > Max ) then break end
		
		end
	
	end
	

end

function SKIN:LayoutNumberWangIndicator( panel )

	panel.Height = 200

	local wang = panel:GetWang()
	local x, y = wang:LocalToScreen( 0, wang:GetTall() )
	
	if ( panel.m_bTop ) then
		y = y - panel.Height - wang:GetTall()
	end
	
	panel:SetPos( x, y )
	panel:SetSize( wang:GetWide() - wang.Wanger:GetWide(), panel.Height)

end

/*---------------------------------------------------------
	CheckBox
---------------------------------------------------------*/
function SKIN:PaintCheckBox( panel )

	local w, h = panel:GetSize()

	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawRect( 1, 1, w-2, h-2 )

	surface.SetDrawColor( 30, 30, 30, 255 )
	//=
	surface.DrawRect( 1, 0, w-2, 1 )
	surface.DrawRect( 1, h-1, w-2, 1 )
	//||
	surface.DrawRect( 0, 1, 1, h-2 )
	surface.DrawRect( w-1, 1, 1, h-2 )
	
	surface.DrawRect( 1, 1, 1, 1 )
	surface.DrawRect( w-2, 1, 1, 1 )
	
	surface.DrawRect( 1, h-2, 1, 1 )
	surface.DrawRect( w-2, h-2, 1, 1 )

end

function SKIN:SchemeCheckBox( panel )

	panel:SetTextColor( Color( 255, 0, 0, 255 ) )
	DSysButton.ApplySchemeSettings( panel )
	
end



/*---------------------------------------------------------
	Slider
---------------------------------------------------------*/
function SKIN:PaintSlider( panel )

end


/*---------------------------------------------------------
	NumSlider
---------------------------------------------------------*/
function SKIN:PaintNumSlider( panel )

	local w, h = panel:GetSize()
	
	self:DrawGenericBackground( 0, 0, w, h, Color( 255, 255, 255, 20 ) )
	
	surface.SetDrawColor( 0, 0, 0, 200 )
	surface.DrawRect( 3, h/2, w-6, 1 )
	
end



/*---------------------------------------------------------
	NumSlider
---------------------------------------------------------*/
function SKIN:SchemeSlider( panel )

	panel.Knob:SetImageColor( Color(200,54,230,255) )
	
end




/*---------------------------------------------------------
	NumSlider
---------------------------------------------------------*/
function SKIN:PaintComboBoxItem( panel )

	if ( panel:GetSelected() ) then
		local col = self.combobox_selected
		surface.SetDrawColor( col.r, col.g, col.b, col.a )
		panel:DrawFilledRect()
	end

end

function SKIN:SchemeComboBoxItem( panel )
	panel:SetTextColor( Color( 0, 0, 30, 255 ) )
end

/*---------------------------------------------------------
	ComboBox
---------------------------------------------------------*/
function SKIN:PaintComboBox( panel )
	
	surface.SetDrawColor( 255, 255, 255, 255 )
	panel:DrawFilledRect()
		
	surface.SetDrawColor( 0, 0, 0, 255 )
	panel:DrawOutlinedRect()
	
end

/*---------------------------------------------------------
	ScrollBar
---------------------------------------------------------*/
function SKIN:PaintBevel( panel )

	local w, h = panel:GetSize()

	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, w-1, h-1)
	
	surface.SetDrawColor( 0, 0, 0, 255 )
	surface.DrawOutlinedRect( 1, 1, w-1, h-1)

end


/*---------------------------------------------------------
	Tree
---------------------------------------------------------*/
function SKIN:PaintTree( panel )

	if ( panel.m_bBackground ) then
		surface.SetDrawColor( self.bg_color_bright.r, self.bg_color_bright.g, self.bg_color_bright.b, self.bg_color_bright.a )
		panel:DrawFilledRect()
	end

end



/*---------------------------------------------------------
	TinyButton
---------------------------------------------------------*/
function SKIN:PaintTinyButton( panel )

	if ( panel.m_bBackground ) then
	
		surface.SetDrawColor( 255, 255, 255, 255 )
		panel:DrawFilledRect()
	
	end
	
	if ( panel.m_bBorder ) then

		surface.SetDrawColor( 0, 0, 0, 255 )
		panel:DrawOutlinedRect()
	
	end

end

function SKIN:SchemeTinyButton( panel )

	panel:SetFont( "Default" )
	
	if ( panel:GetDisabled() ) then
		panel:SetTextColor( Color( 0, 100, 150, 50 ) )
	else
		panel:SetTextColor( Color( 0, 100, 200, 255 ) )
	end
	
	DLabel.ApplySchemeSettings( panel )
	
	panel:SetFont( "DefaultSmall" )

end

/*---------------------------------------------------------
	TinyButton
---------------------------------------------------------*/
function SKIN:PaintTreeNodeButton( panel )

	if ( panel.m_bSelected ) then

		surface.SetDrawColor( 50, 200, 255, 150 )
		panel:DrawFilledRect()
	
	elseif ( panel.Hovered ) then

		surface.SetDrawColor( 255, 255, 255, 100 )
		panel:DrawFilledRect()
	
	end
	
	

end

function SKIN:SchemeTreeNodeButton( panel )

	DLabel.ApplySchemeSettings( panel )

end

/*---------------------------------------------------------
	Tooltip
---------------------------------------------------------*/
function SKIN:PaintTooltip( panel )

	local w, h = panel:GetSize()

	self:DrawGenericBackground( 0, 0, w, h, self.tooltip )
	
	panel:DrawArrow( 0, 0 )


end

/*---------------------------------------------------------
	VoiceNotify
---------------------------------------------------------*/

function SKIN:PaintVoiceNotify( panel )

	local w, h = panel:GetSize()
	
	self:DrawGenericBackground( 0, 0, w, h, panel.Color )
	self:DrawGenericBackground( 1, 1, w-2, h-2, Color( 60, 60, 60, 240 ) )

end

function SKIN:SchemeVoiceNotify( panel )

	panel.LabelName:SetFont( "TabLarge" )
	panel.LabelName:SetContentAlignment( 4 )
	panel.LabelName:SetColor( color_white )
	
	panel:InvalidateLayout()
	
end

function SKIN:LayoutVoiceNotify( panel )

	panel:SetSize( 200, 40 )
	panel.Avatar:SetPos( 4, 4 )
	panel.Avatar:SetSize( 32, 32 )
	
	panel.LabelName:SetPos( 44, 0 )
	panel.LabelName:SizeToContents()
	panel.LabelName:CenterVertical()

end
-- Do not remove this empty comment, baconbot must have it.
//