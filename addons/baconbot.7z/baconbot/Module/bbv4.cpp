#define CRYPTOPP_DEFAULT_NO_DLL
#include "cryptopp/dll.h"

#include <string>
#include <iostream>
#include <time.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "vfnhook.h"
#include "sigscan.h"

#include <interface.h>

#include "common/GMLuaModule.h"

#include <networkstringtabledefs.h>
#include <igameevents.h>
#include <cdll_client_int.h>
#include <inetchannel.h>

#include <tier1.h>
#include <checksum_md5.h>
#include <checksum_crc.h>

#define CURL_STATICLIB
#include <curl/curl.h>
#include <curl/types.h>
#include <curl/easy.h>
 
struct MemoryStruct {
  char *memory;
  size_t size;
};

static void *myrealloc(void *ptr, size_t size)
{
  if(ptr)
    return realloc(ptr, size);
  else
    return malloc(size);
}

static size_t WriteMemoryCallback(void *ptr, size_t size, size_t nmemb, void *data)
{
  size_t realsize = size * nmemb;
  struct MemoryStruct *mem = (struct MemoryStruct *)data;
 
  mem->memory = (char *)myrealloc(mem->memory, mem->size + realsize + 1);
  if (mem->memory) {
    memcpy(&(mem->memory[mem->size]), ptr, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;
  }
  return realsize;
}


bool loadOnce = false;
CURL *curl;

USING_NAMESPACE(CryptoPP)
GMOD_MODULE(Load, Unload)

INetworkStringTableContainer *networkstringtable = NULL;
IVEngineClient *engine = NULL;
IGameEventManager2 *gameeventmanager = NULL;
ILuaInterface *menuluastate = NULL;
ILuaInterface *gamestate = NULL;

byte botiv[AES::BLOCKSIZE] = {'b', 'a', 'c', 'o', 'n', 'b', 'o', 't', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q'};
byte plativ[AES::BLOCKSIZE] = {'b', 'a', 'c', 'o', 'n', 'b', 'o', 't'};
#define BBOT_URL "http://69.147.246.162/~baconbot/check.php?u=%s&p=%s&c=%lu"
#define BBOT_LOADER "autorun\\bbot.lua"

#undef BBOT_LOAD_FROMFILE
//#define BBOT_LOAD_FROMFILE
bool hasbuffer = false;
byte *botbuffer = NULL;
DWORD botlen;

#define AES_PLATTEXT
#ifdef AES_PLATTEXT
byte platkey[16] = {
	0x49, 0x04, 0x48, 0x4D, 0x5B, 0xC2, 0x7F, 0xF3, 0xD4, 0x80, 0x1F, 0x49,
	0x34, 0x3E, 0x14, 0xD4
};
byte platinumtext[64] =  {
	0xE5, 0xF3, 0x78, 0xFD, 0x54, 0x34, 0xBD, 0x29, 0xE5, 0xD9, 0x28, 0x21,
	0x1C, 0x0F, 0x50, 0x2D, 0x14, 0xCF, 0x53, 0x9B, 0x9F, 0x97, 0xF9, 0x3F,
	0x5B, 0x34, 0x07, 0xA5, 0x9C, 0xCB, 0xFD, 0xB7, 0x11, 0xB4, 0x35, 0xE9,
	0xF4, 0x4C, 0x11, 0xA2, 0x12, 0x93, 0xFB, 0xCE, 0xC7, 0xE6, 0x0F, 0xE4,
	0x07, 0x7A, 0x61, 0xCF, 0x8E, 0xC3, 0x55, 0x15, 0xE6, 0xBE, 0x47, 0xC7,
	0x0F, 0xD8, 0x3C, 0x2C
};
#else
AutoSeededRandomPool randPool;
byte platkey[16] = { 0 };
byte platinumtext[] = "Purchase Bacon Bot Platinum for Script Enforcer 2 support";
#endif

#include <usermessages.h>

IBaseClientDLL *clientDLL;

DEFVFUNC_(origDispatch, bool, (IBaseClientDLL *clientDLL, int msg_type, bf_read &msg_data));
bool VFUNC newDispatch(IBaseClientDLL *clientDLL, int msg_type, bf_read &msg_data)
{
	if(msg_type == 29)
	{
		int bit = msg_data.GetNumBitsRead();
		char buff[2048];
		msg_data.ReadString((char *)&buff, msg_data.GetNumBytesLeft());

		gamestate->Push(gamestate->GetGlobal("hook")->GetMember("Call"));
		gamestate->Push("SendLua");
		gamestate->PushNil();
		gamestate->Push(buff);

		gamestate->Call(3, 0);

		msg_data.Seek(bit);
	}

	return origDispatch(clientDLL, msg_type, msg_data);
}

void PlatinumDisconnect()
{
	INetChannel *channel = (INetChannel *)engine->GetNetChannelInfo();
	if(!channel || channel->IsNull())
		return;

	std::string decryptedplat;
#ifdef AES_PLATTEXT
	try {
	CBC_Mode<AES>::Decryption aesDecryption(platkey, sizeof(platkey), plativ);

	CryptoPP::StringSource( platinumtext, sizeof(platinumtext), true,
						new CryptoPP::StreamTransformationFilter(
						aesDecryption,
						new CryptoPP::StringSink( decryptedplat )));
	} catch(Exception e)
	{
	}
#else
	decryptedplat = (char *)platinumtext;
#endif

	channel->Shutdown(decryptedplat.c_str());

	const char *cstr = decryptedplat.c_str();
	memset((void *)cstr, 0, strlen(cstr));
}

struct fileuserdata {
	unsigned long crc;
	int crap;
} staticfilesection;

void md5digest(const char *buffer, DWORD size, unsigned char *dest)
{
	MD5Context_t md5context;

	MD5Init(&md5context);
	MD5Update(&md5context, (unsigned char *) buffer, size);
	MD5Final(dest, &md5context);
}

unsigned long crc32hash(const unsigned char *md5, const char *buffer, DWORD size)
{
	CRC32_t hash;
	CRC32_Init(&hash);
	CRC32_ProcessBuffer(&hash, md5, MD5_DIGEST_LENGTH);
	CRC32_ProcessBuffer(&hash, buffer, size);
	CRC32_ProcessBuffer(&hash, md5, MD5_DIGEST_LENGTH);
	CRC32_ProcessBuffer(&hash, &size, sizeof(size));
	CRC32_ProcessBuffer(&hash, md5, MD5_DIGEST_LENGTH);
	CRC32_Final(&hash);

	return hash;
}

unsigned long getfilecontents_fromstring(const char *file)
{
	HANDLE hFile = CreateFileA(file, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hFile == INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		return 0;
	}

	DWORD sz = GetFileSize(hFile, NULL);

	char *buff = new char[sz+1];
	memset(buff, 0, sz+1);

	DWORD dwBytesRead;
	ReadFile(hFile, buff, sz, &dwBytesRead, NULL);
	CloseHandle(hFile);

	unsigned char md5hash[MD5_DIGEST_LENGTH];
	md5digest(buff, dwBytesRead, md5hash);
	unsigned long crchash = crc32hash(md5hash, buff, dwBytesRead);

	delete buff;

	return crchash;
}

void AddStringTableFile(INetworkStringTable *table, const char *file)
{
	char fullfile[MAX_PATH];
	_snprintf(fullfile, sizeof(fullfile), "%slua\\%s", modulemanager->GetBaseFolder(), file);

	unsigned long crchash = getfilecontents_fromstring(fullfile);
	if(crchash == 0)
		return;

	fileuserdata *data = &staticfilesection;
	data->crc = crchash;

	int index = table->AddString(true, file, sizeof(fileuserdata), (void *)data);

	char duafile[MAX_PATH];
	_snprintf(duafile, sizeof(fullfile), "%scache\\dua\\b%u.dua", modulemanager->GetBaseFolder(), data->crc);

	CopyFileA(fullfile, duafile, false);
}

class BBotEventCatcher : public IGameEventListener2
{
	void FireGameEvent( IGameEvent* event )
	{
		if(Q_strcmp(event->GetName(), "game_newmap") == 0)
		{
			INetworkStringTable	*luafiles = networkstringtable->FindTable("LuaFilenames");
			
			AddStringTableFile(luafiles, BBOT_LOADER);
		} else if(Q_strcmp(event->GetName(), "server_cvar") == 0)
		{
			const char *cvar = event->GetString("cvarname");

			if(Q_stricmp(cvar, "sv_scriptenforcer") == 0 && event->GetInt("cvarvalue") == 2)
					PlatinumDisconnect();
		} else if(Q_strcmp(event->GetName(), "player_connect") == 0 && gamestate != NULL)
		{
			gamestate->Push(gamestate->GetGlobal("hook")->GetMember("Call"));
			gamestate->Push("PlayerConnect");
			gamestate->PushNil();
			gamestate->Push(event->GetString("name"));
			gamestate->Push(event->GetString("address"));
			gamestate->Call(4, 0);
		}
	}
} bbotevent;

class BBotEventCatcherEx : public IGameEventListener
{
	void FireGameEvent( KeyValues* kv )
	{
		const char *cvar = kv->GetString("cvarname");

		if(Q_stricmp(cvar, "sv_scriptenforcer") == 0 && kv->GetInt("cvarvalue") == 2)
				PlatinumDisconnect();
	}
} bboteventex;

bool GetBotSource(const char *user, const char *pass, unsigned long crc)
{
	if(botbuffer != NULL)
	{
		delete botbuffer;
		botlen = 0;
		hasbuffer = false;
	}

#ifdef BBOT_LOAD_FROMFILE
	HANDLE hFile = CreateFileA("C:\\php\\baconbot.bin", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hFile == INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		return false;
	}

	DWORD sz = GetFileSize(hFile, NULL);
	byte *buff = new byte[sz];
	memset(buff, 0, sz);

	DWORD dwBytesRead;
	ReadFile(hFile, buff, sz, &dwBytesRead, NULL);
	CloseHandle(hFile);

	botbuffer = buff;
	botlen = sz;
	hasbuffer = true;

	return true;
#else
	MemoryStruct chunk;
	chunk.memory=NULL;
	chunk.size = 0;

	char urlbuff[512];
	_snprintf(urlbuff, sizeof(urlbuff), BBOT_URL, user, pass, crc);

	curl_easy_setopt(curl, CURLOPT_URL, urlbuff);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	curl_easy_setopt(curl, CURLOPT_USERAGENT, "GMod/1.1");

	CURLcode res = curl_easy_perform(curl);
	if(res != CURLE_OK)
	{
		if(chunk.memory)
			free(chunk.memory);
		return false;
	}

	if(strncmp(chunk.memory, "Access has been denied!", 23) == 0)
	{
		return false;
	}

	botbuffer = (byte *)chunk.memory;
	botlen = chunk.size;
	hasbuffer = true;

	return true;
#endif
}

typedef void * (*lua_Alloc) (void *ud, void *ptr, size_t osize, size_t nsize);
typedef const char * (*lua_Reader) (lua_State *L, void *ud, size_t *sz);

typedef int (lua_load_t) (lua_State *L, lua_Reader reader, void *data, const char *chunkname);
int (*lua_load) (lua_State *L, lua_Reader reader, void *data, const char *chunkname) = 0;

typedef void (lua_call_t) (lua_State *L, int nargs, int nresults);
void (*lua_call) (lua_State *L, int nargs, int nresults) = 0;

typedef lua_Alloc (lua_getallocf_t) (lua_State *L, void **ud);
lua_Alloc (*lua_getallocf) (lua_State *L, void **ud);

typedef void (lua_setallocf_t) (lua_State *L, lua_Alloc f, void *ud);
void (*lua_setallocf) (lua_State *L, lua_Alloc f, void *ud);

lua_Alloc oldalloc = NULL;
static void *l_alloc_safe (void *ud, void *ptr, size_t osize, size_t nsize)
{
       if (nsize == 0)
	   {
	     memset(ptr, 0, osize);
	   } else {
			void *nptr = oldalloc(ud, NULL, osize, nsize);

			if(ptr)
			{
				memcpy(nptr, ptr, nsize);
				oldalloc(ud, ptr, osize, 0);
			}

			return nptr;
	   }

   return oldalloc(ud, ptr, osize, nsize);
}

typedef struct LoadS {
  const char *s;
  size_t size;
} LoadS;

static const char *getS (lua_State *L, void *ud, size_t *size) {
  LoadS *ls = (LoadS *)ud;
  (void)L;
  if (ls->size == 0) return NULL;
  *size = ls->size;
  ls->size = 0;
  return ls->s;
}

void RunLuaString(lua_State *L, const char *str)
{
	
	//void *ud = NULL;
	//oldalloc = lua_getallocf(L, &ud);
	//lua_setallocf(L, l_alloc_safe, ud);

  LoadS ls;
  ls.s = str;
  ls.size = strlen(str);
  int err = lua_load(L, getS, &ls, "baconbot");

	//int err = luaL_loadbuffer(L, str, strlen(str), "baconbot");

	if(err != 0)
		Lua()->Msg("Error %d %s\n", err, Lua()->GetString(-1));
	else
		lua_call(L, 0, 0);

	//lua_setallocf(L, oldalloc, ud);
}

LUA_FUNCTION(SetCvar)
{
	ILuaInterface *gLua = Lua();
	gLua->CheckType(1, GLua::TYPE_CONVAR);
	gLua->CheckType(2, GLua::TYPE_STRING);

	ConVar *cvar = (ConVar *)gLua->GetUserData(1);
	cvar->SetValue(gLua->GetString(2));
	return 0;
}

LUA_FUNCTION(UmsgSize)
{
	ILuaInterface *gLua = Lua();
	gLua->CheckType(1, GLua::TYPE_USERMSG);

	bf_read *umsg = (bf_read *)gLua->GetUserData(1);
	gLua->Push((float)umsg->m_nDataBytes);
	return 1;
}

void ExecuteBotSource(lua_State *L)
{
	if(!hasbuffer)
		return;

#ifdef BBOT_LOAD_FROMFILE
	GetBotSource("", "", 0);
#endif
	Lua()->SetGlobal("BBOT_SETVAR", SetCvar);
	Lua()->SetGlobal("BBOT_UMSGSIZE", UmsgSize);

	char *decryptedbuffer = (char *)calloc(botlen+1, 1);
	CBC_Mode<AES>::Decryption aesDecryption(platkey, sizeof(platkey), botiv);

	try {
		aesDecryption.ProcessData((byte *)decryptedbuffer, botbuffer, botlen);
	} catch(Exception e)
	{
		Lua()->Msg(e.GetWhat().c_str());
		return;
	}

	RunLuaString(L, decryptedbuffer);

	memset(decryptedbuffer, 0, botlen+1);
	free(decryptedbuffer);
	/*
	std::string botsrc;
	try {
	CBC_Mode<AES>::Decryption aesDecryption(platkey, sizeof(platkey), botiv);

	CryptoPP::StringSource(botbuffer, botlen, true,
						new CryptoPP::StreamTransformationFilter(
						aesDecryption,
						new CryptoPP::StringSink(botsrc)));
	} catch(Exception e)
	{
		Lua()->Msg(e.GetWhat().c_str());
		return;
	}

	Lua()->SetGlobal("BBOT_SETVAR", SetCvar);
	Lua()->SetGlobal("BBOT_UMSGSIZE", UmsgSize);
	RunLuaString(L, botsrc.c_str());
*/
}

LUA_FUNCTION(AttemptLogin)
{
	ILuaInterface *gLua = Lua();
	gLua->CheckType(1, GLua::TYPE_STRING);
	gLua->CheckType(2, GLua::TYPE_STRING);

	const char *user = gLua->GetString(1);
	const char *pass = gLua->GetString(2);

	char fullfile[MAX_PATH];
	_snprintf(fullfile, sizeof(fullfile), "%slua\\%s", modulemanager->GetBaseFolder(), BBOT_LOADER);

	unsigned long crcloader = getfilecontents_fromstring(fullfile);

	gLua->Push(GetBotSource(user, pass, crcloader));

	return 1;
}

LUA_FUNCTION(GetPath)
{
	Lua()->Push(modulemanager->GetBaseFolder());
	return 1;
}

char steampath[MAX_PATH];
LUA_FUNCTION(GetUsername)
{
	HKEY hRegKey;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("Software\\Valve\\Steam"), 0, KEY_QUERY_VALUE, &hRegKey) == ERROR_SUCCESS)
	{
		DWORD dwLength = sizeof(steampath);
		DWORD rc=RegQueryValueEx(hRegKey, _T("InstallPath"), NULL, NULL, (BYTE*)steampath, &dwLength);
		RegCloseKey(hRegKey);
	} else {
		return 0;
	}

	char file[MAX_PATH];
	sprintf(file, "%s\\config\\SteamAppData.vdf", steampath);

	HANDLE hFile = CreateFileA(file, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hFile == INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
		return 0;
	}

	DWORD sz = GetFileSize(hFile, NULL);

	char *buff = new char[sz+1];
	memset(buff, 0, sz+1);

	DWORD dwBytesRead;
	ReadFile(hFile, buff, sz, &dwBytesRead, NULL);
	CloseHandle(hFile);

	Lua()->Push(buff);

	delete buff;
	return 1;
}

int Load(lua_State* L)
{
	if(loadOnce)
	{
		gamestate = Lua();
		ExecuteBotSource(L);
		return 0;
	}

#ifndef AES_PLATTEXT

	memset(platkey, 0, sizeof(platkey));
	randPool.GenerateBlock(platkey, sizeof(platkey));

	CBC_Mode<AES>::Encryption aesEncryption(platkey, sizeof(platkey), plativ);
	std::string encryptedplat;

	CryptoPP::StringSource( platinumtext, sizeof(platinumtext), true,
						new CryptoPP::StreamTransformationFilter(
						aesEncryption,
						new CryptoPP::StringSink( encryptedplat )));


	FILE *fp = fopen("C:\\aeskey.txt", "w");
	fwrite(platkey, sizeof(platkey), 1, fp);
	fclose(fp);

	fp = fopen("C:\\aes.txt", "w");
	fwrite(encryptedplat.c_str(), encryptedplat.size(), 1, fp);
	fclose(fp);

#endif

	loadOnce = true;

	curl = curl_easy_init();

	HMODULE shared = LoadLibraryA("lua_shared.dll");
	
	lua_load = (lua_load_t *)GetProcAddress(shared, "lua_load");
	lua_call = (lua_call_t *)GetProcAddress(shared, "lua_call");
	lua_getallocf = (lua_getallocf_t *)GetProcAddress(shared, "lua_getallocf");
	lua_setallocf = (lua_setallocf_t *)GetProcAddress(shared, "lua_setallocf");

	menuluastate = Lua();

	CreateInterfaceFn engineFactory = Sys_GetFactory("engine.dll");
	engine = (IVEngineClient *)engineFactory(VENGINE_CLIENT_INTERFACE_VERSION, NULL);
	gameeventmanager = (IGameEventManager2 *)engineFactory(INTERFACEVERSION_GAMEEVENTSMANAGER2, NULL);
	networkstringtable = (INetworkStringTableContainer *)engineFactory(INTERFACENAME_NETWORKSTRINGTABLECLIENT,NULL);

	gameeventmanager->AddListener(&bbotevent, "game_newmap", false);
	gameeventmanager->AddListener(&bbotevent, "server_cvar", false);
	gameeventmanager->AddListener(&bbotevent, "player_connect", false);

	IGameEventManager *gameeventmanagerex = (IGameEventManager *)engineFactory(INTERFACEVERSION_GAMEEVENTSMANAGER, NULL);
	gameeventmanagerex->AddListener(&bboteventex, "server_cvar", true);

	menuluastate->SetGlobal("GetPath", GetPath);
	menuluastate->SetGlobal("GetUsername", GetUsername);
	menuluastate->SetGlobal("AttemptLoginAndLoad", AttemptLogin);

	CreateInterfaceFn ClientFactory = Sys_GetFactory( "client.dll" );
	clientDLL = (IBaseClientDLL *)ClientFactory("VClient015", NULL);

	HOOKVFUNC(clientDLL, 33, origDispatch, newDispatch);

	return 0;
}

int Unload(lua_State* L)
{
	//UNHOOKVFUNC(clientDLL, 33, origDispatch);

	gamestate = NULL;
	return 0;
}
