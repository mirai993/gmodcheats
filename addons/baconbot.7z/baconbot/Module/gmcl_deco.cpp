LUA_FUNCTION(manipulate_shot) {
    ILuaInterface *gLua = Lua();
    gLua->CheckType(1, GLua::TYPE_NUMBER);
    gLua->CheckType(2, GLua::TYPE_VECTOR);
    gLua->CheckType(3, GLua::TYPE_VECTOR);

    RandomSeed(gLua->GetInteger(1));

    Vector *vecAim = GetVector(gLua, 2);

    CShotManipulator shot(*vecAim);

    Vector *vecSpread = GetVector(gLua, 3);

    Vector vecResult = shot.ApplySpread(*vecSpread);

    Vector *result = new Vector(vecResult);

    PushVector(gLua, *result);

    return 1;
}

LUA_FUNCTION(L_MD5_PseudoRandom) {
    gLua = Lua();
    gLua->CheckType(1, GLua::TYPE_NUMBER);
    unsigned int seed = MD5_PseudoRandom( gLua->GetInteger(1) ) & 0x7fffffff;

    gLua->Push((float)(seed & 255));
    return 1;
}

LUA_FUNCTION(cusercmd_getcommandnumber) {
    gLua = Lua();
    gLua->CheckType(1, GLua::TYPE_USERCMD);
    CUserCmd *cmd = (CUserCmd*)gLua->GetUserData(1);

    gLua->Push((float)cmd->command_number);
    return 1;
}