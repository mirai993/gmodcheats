include ( "includes/compat.lua" )
include ( "includes/util.lua" )
include ( "includes/util/sql.lua" )
require ( "concommand" )
require ( "saverestore" )
require ( "gamemode" )
require ( "weapons" )
require ( "hook" )
require ( "timer" )
require ( "schedule" )
require ( "scripted_ents" )
require ( "player_manager" )
require ( "numpad" )
require ( "team" )
require ( "undo" )
require ( "cleanup" )
require ( "duplicator" )
require ( "constraint" )
require ( "construct" )	
require ( "filex" )
require ( "vehicles" )
require ( "usermessage" )
require ( "list" )
require ( "cvars" )
require ( "http" )
require ( "datastream" )
require ( "draw" )
require ( "markup" )
require ( "effects" )
require ( "killicon" )
require ( "spawnmenu" )
require ( "controlpanel" )
require ( "presets" )
require ( "cookie" )

include( "includes/util/model_database.lua" )
include( "includes/util/vgui_showlayout.lua" )
include( "includes/util/tooltips.lua" )	
include( "includes/util/client.lua" )

--[[
-- Setting your own lua Enviroment.
local bbe = {
	print = print,
	error = error,
	math = math,
	__index = __index,
	_G = _G,
	_R = _R,
}

local bb = {}

function bb.RCC( ... )
	_G.RunConsoleCommand( ... )
end
for k, v in pairs(bb) do
	local f = bb[k]
	setfenv( f, bbe )
end

bb.RCC( 1, 2, 3 )
--]]

CreateConVar("ac_dev" , 0 , true , true)

if !BAdmin then BAdmin = {} end
BAdmin.TableExists = function() return false end -- BlackOps AC

local function DevMsg(msg)
	if not ValidEntity(LocalPlayer()) then
		Msg(msg)
		return
	end
	
	if GetConVar("ac_dev"):GetInt() >= 1 then
		Msg(msg)
		return
	end
end

local BlacklistHooks = {
	{Name = 'DerptyDerp' , Type = 'Initialize'} -- BlackOps AC	
}

local hookadd = hook.Add
hook.Add = function(typ , name , func)
	local found = false
	for k , v in pairs(BlacklistHooks) do
		if (v.Name == name) and (v.Type == typ) then
			found = true
			break
		end
	end
	
	if found then
		DevMsg("[DEV] Hook add blocked: ".. typ .. " , ".. name.."\n")
		return
	end
	
	return hookadd(typ , name , func )
end

local BlacklistQuerys = {
	{Query = "select name FROM sqlite_master WHERE name="..SQLStr("Bacon_Friends").." AND type='table'"}, -- BlackOps AC
	{Query = "select name FROM sqlite_master WHERE name="..SQLStr("Bacon_Ents").." AND type='table'"}, -- BlackOps AC
	{Query = "select name FROM sqlite_master WHERE name="..SQLStr("Bacon_ESPEnts").." AND type='table'"}, -- BlackOps AC
	{Query = "SELECT User, Pass FROM Bacon_Pass2"},
	{Query = "SELECT User FROM Bacon_Pass2"},
	{Query = "SELECT Pass FROM Bacon_Pass2"}
}

local sqlquery = sql.Query
sql.Query = function(query)
	local found = false
	for k , v in pairs(BlacklistQuerys) do
		if (v.Query == query) then
			found = true
			break
		end
	end
	
	if found then
		DevMsg("[DEV] Query blocked: ('".. query .."')\n")
		return false
	end
	
	return sqlquery(query)
end