local state = false
local friendlyfire = CreateClientConVar( "Bacon_ff", 0, true, false )
local target = nil
local dir = "bacon_botlist.txt"
local dire = "bacon_entlist.txt"
local direc = "bacon_esp_entlist.txt"
local ran = false
local angles = Angle(0,0,0)
local NPCo = CreateClientConVar( "Bacon_NPConly", 0, true, false )
local Ento = CreateClientConVar( "Bacon_Entonly", 0, true, false )
local Plyo= CreateClientConVar( "Bacon_Plyonly", 0, true, false )
local es = CreateClientConVar( "Bacon_Enemy_Compensation", 45, true, false )
local ms = CreateClientConVar( "Bacon_Me_Compensation", 45, true, false )
local sf = CreateClientConVar( "Bacon_Sound_Effects", 1, true, false )
local bmw = CreateClientConVar( "Bacon_TMW", 1, true, false )
local playeron = CreateClientConVar( "Bacon_ESP_Players", 1, true, false )
local mode = CreateClientConVar( "Bacon_ESP_Mode", 0, true, false )
local cross = CreateClientConVar( "Bacon_ESP_Cross", 0, true, false )
local itemon = CreateClientConVar( "Bacon_ESP_Items", 1, true, false )
local vehicleon = CreateClientConVar( "Bacon_ESP_Vehicles", 1, true, false )
local npcon = CreateClientConVar( "Bacon_ESP_NPCs", 1, true, false )
local weaponon = CreateClientConVar( "Bacon_ESP_Weapons", 1, true, false )
local trans = CreateClientConVar( "Bacon_ESP_Transperency", 255, true, false )
local darkrp = CreateClientConVar( "Bacon_ESP_DarkRP", 1, true, false )
local steamfriends = CreateClientConVar( "Bacon_Ignore_SteamFriends", 1, true, false )
local ASSlist = {"*Owner*","*Super Admin*","*Admin*","*Temp Admin*","*Respected*"}
local friendslist = {}
local entlist = {}
local lockonlist = {}
local NPCfriends = {}
local triggertoggle = CreateClientConVar( "Bacon_Trigger_Bot", 0, true, false )
local attack = 0
local TextOn = true
local fire_on = false
local autofiretoggle = false
local FOV = CreateClientConVar( "Bacon_RestrictFOV", 0, true, false )
local Anti = CreateClientConVar( "Bacon_AntiSnap", 0, true, false )
local Mod = CreateClientConVar("Bacon_Mode",1,true,false)
local time = CurTime()
local timea = CurTime()
local timeb = CurTime()
local delay = 0.01
local oldn = NPCo:GetBool()
local oldp = Plyo:GetBool()
local olde = Ento:GetBool()

// ANTI SPREAD SCRIPT
local NAME = "PredictStuff"
local MoveSpeed = 1

hook.Add("SetupMove",NAME,function (objPl, move)
	if move then
		MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
	end
end)

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
	{check=function ()
		return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
	end,getcone=function (wep,cone)
		if type(wep.Base) == "string" then
			if wep.Base == "civilian_base" then
				local scale = cone
				if CL:KeyDown(IN_DUCK) then
					scale = math.Clamp(cone/1.5,0,10)
				elseif CL:KeyDown(IN_WALK) then
					scale = cone
				elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
					scale = cone + (cone*2)
				elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
					scale = cone + (cone*1.5)
				end
				scale = scale + (wep:GetNWFloat("Recoil",0)/3)
				return Vector(scale,0,0)
			end
		end
		return Vector(cone,cone,cone)
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
	end,getcone=function (wep,cone)
		if wep:GetNetworkedBool("Ironsights",false) then
			if CL:Crouching() then
				return wep.ConeIronCrouching or cone
			end
			return wep.ConeIron or cone
		elseif 25 < CL:GetVelocity():Length() then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
	end,getcone=function (wep,cone)
		if CL:GetVelocity():Length() > 25 then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
	end,getcone=function (wep, cone)
		if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
			if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
				print("using scopecone")
				return wep.Primary.Cone
			end
			print("using unscoped cone")
			return wep.Primary.UnscopedCone
		end
		if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
			return cone
		end
		return cone + .05
	end},
	{check=function ()
		return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
	end,getcone=function(wep,cone)
		if wep.Primary then
			local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
			local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
			local accuracy = wep.Primary.Accuracy
			if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
			if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
			accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
			if CL:KeyDown(IN_DUCK) then
				return accuracy*wep.CrouchModifier*lastshootmod
			else
				return accuracy*lastshootmod
			end
		end
	end}
}
local function Check()
	for k, v in pairs(GameTypes) do
		if v.check() then
			ID_GAMETYPE = k
			break
		end
	end
end
concommand.Add("raidbot_predictcheck",function () Check() print("GameType = ["..ID_GAMETYPE.."]")end)
hook.Add("Initialize",NAME,Check)

local tblNormalConeWepBases = {
	["weapon_cs_base"] = true
}
function GetCone(wep)
	local cone = wep.Cone
	if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
		cone = wep.Primary.Cone
	end
	--CHeck if wep is HL2 then return corresponding cone
	if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
	if wep:GetClass() == "ose_turretcontroller" then return 0 end
	if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
	return cone or 0
end

require("deco")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
function PredictSpread(cmd,aimAngle)
	cmd2, seed = hl2_ucmd_getprediciton(cmd)
	if cmd2 ~= 0 then
		currentseed = seed
	end
	wep = LocalPlayer():GetActiveWeapon()
	vecCone = Vector(0,0,0)
	if wep and wep:IsValid() and type(wep.Initialize) == "function" then
		valCone = GetCone(wep)
		if type(valCone) == "number" then
			vecCone = Vector(-valCone,-valCone,-valCone)
		elseif type(valCone) == "Vector" then
			vecCone = -1*valCone
		end
	end
	return hl2_shotmanip(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
//END OF ANTI SPREAD SCRIPT
surface.CreateFont( "csd", 20, 100, true, true, "BacSigns" )
surface.CreateFont( "coolvetica", 30, 500, true, false, "HealthFont" )

function ASScheck()
local apps=file.Find("../lua_temp/*.lua")
return table.HasValue(apps,"ass_client.lua")
end
local AssMod = ASScheck()
function ULXcheck()
local apps=file.Find("../lua_temp/ulx/*.lua")
return table.HasValue(apps,"cl_init.lua")
end

function FileWrite()
	file.Write(dir,util.TableToKeyValues(friendslist))
	print("Wrote Friends List\n")
	file.Write(dire,util.TableToKeyValues(lockonlist))
	print("Wrote Entities List\n")
	file.Write(direc,util.TableToKeyValues(entlist))
	print("Wrote ESP Entities List\n")
end

function ToNumFromBool(x)
if x then return 1 else return 0 end
end
hook.Add("Think","AutoFire_Bitch", function ()
if fire_on || autofiretoggle then
	if fire_on then
		RunConsoleCommand("-attack")
		fire_on = false
	elseif CurTime()-time>=0 then
		RunConsoleCommand("+attack")
		fire_on = true
		time = CurTime()+delay
	end
end
end)


function triggerthis()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	local toggle = tobool(triggertoggle:GetInt())
	trace = util.TraceLine({start=LocalPlayer():GetShootPos(),endpos=LocalPlayer():GetShootPos() + (LocalPlayer():GetAimVector() * 64000),filter={LocalPlayer()},mask=1174421507}).Entity
	if trace:IsValid() && trace:IsPlayer() && check(trace.Entity) && afriend(trace.Entity) && !NPConly && !Entonly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && trace:IsPlayer() && check(trace.Entity) && afriend(trace.Entity) && !NPConly && !Entonly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && trace:IsNPC() && !table.HasValue(NPCfriends, trace.Entity:GetClass()) && !Entonly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && (table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl","")) || table.HasValue(lockonlist, trace:GetClass())) && !NPConly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif !trace:IsValid() || !trace:IsPlayer() || !trace:IsNPC() || ((!table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl",""))) || !table.HasValue(lockonlist, trace:GetClass())) then
		if attack == 1 then
			autofiretoggle=!autofiretoggle
			attack = 0
		end
	end
end
hook.Add("Think", "TriggerThinky", triggerthis)


function ToggleHax()
	if state==false then

		state = true
		target = nil

	else
		state = false
		target = nil
	end
end


function check(ply)
local ff=friendlyfire:GetBool()
	if ff == false then
		if ply:Team() == LocalPlayer():Team() then
			return false
		else
			return true
		end
	else
		if ply:Team() == LocalPlayer():Team() then
			return true
		else
			return true
		end
	end
end


function afriend(ply)
	if ply:GetFriendStatus()=="friend" && steamfriends:GetBool() then return false end
	for a,b in pairs(friendslist) do
		//Msg("1:"..string.Replace(string.Replace(ply:Name(),"[",""),"]","").."\n")
		//Msg(string.lower(b))
		if string.find(string.lower(ply:Name()),string.lower(b),0,true) then
			return false
		end
	end
	if #friendslist==0 then return true end
	return true
end


function SelectTarget()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	besttarget = LocalPlayer()
	for k, v in pairs(ents.GetAll()) do
		if v:IsPlayer() && v:IsValid() && !NPConly && !Entonly then
			if v:Alive() && v!=LocalPlayer() && (check(v)) && afriend(v) && v:Health()>0 then
				local EnPosa = 0
				local mod = v:LookupAttachment("eyes")
				if mod != 0 then
					EnPosa = v:GetAttachment(mod).Pos
				end
				if v:GetModel()=="models/zombie/fast.mdl" then
					EnPosa = v:GetAttachment(2).Pos
				end
				if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") || string.find(string.lower(v:GetModel()),"manhack") then
					EnPosa = v:GetPos() + Vector(0,0,6)
				end
				local trd = {}
				trd.start = LocalPlayer():EyePos()
				trd.endpos = EnPosa
				local veh=LocalPlayer()
				local veha=LocalPlayer()
				if v:GetVehicle() then veh=v:GetVehicle() end
				if LocalPlayer():GetVehicle() then veha=LocalPlayer():GetVehicle() end
				trd.filter = {LocalPlayer(),v, veh, veha}
				trd.mask = 1174421507
				local tr = util.TraceLine(trd)
				if !tr.Hit then
					local a = 0
					local b = 0
					theirpos = v:EyePos():ToScreen()
					oldpos = besttarget:EyePos():ToScreen()
					if Mode==2 then
						a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
						b = v:EyePos():Distance(LocalPlayer():EyePos())
					elseif Mode==1 then
						a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
						b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
					elseif Mode==3 then
						a = besttarget:Health()
						b = v:Health()
					elseif Mode==4 then
						local hmath=(((LocalPlayer():EyePos()-besttarget:GetShootPos()):GetNormal()):Angle())-besttarget:EyeAngles()
						a=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
						local hmath=(((LocalPlayer():EyePos()-v:GetShootPos()):GetNormal()):Angle())-v:EyeAngles()
						b=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
					end
					//638
					if (b <= a) && v:Health()>0 then
						besttarget = v
					elseif besttarget == LocalPlayer() then
						besttarget = v
					end
				end
			end
		elseif v:IsNPC() && !Entonly && !PlyOnly && !table.HasValue(NPCfriends, v:GetClass()) then
				local EnPosa = 0
				local mod = v:LookupAttachment("eyes")
				if mod != 0 then
					EnPosa = v:GetAttachment(mod).Pos
				end
				if v:GetModel()=="models/zombie/fast.mdl" || string.find(string.lower(v:GetModel()),"manhack") then
					EnPosa = v:GetAttachment(2).Pos
				end
				if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") then
					EnPosa = v:GetPos() + Vector(0,0,9)
				end
				if string.find(string.lower(v:GetModel()),"hunter") || string.find(string.lower(v:GetModel()),"antlionguard") then
					EnPosa = v:GetPos() + Vector(0,0,73)
				end
				if string.find(string.lower(v:GetModel()),"antlion") && !string.find(string.lower(v:GetModel()),"antlionguard") then
					EnPosa = v:GetPos() + Vector(0,0,25)
				end
				local trd = {}
				trd.start = LocalPlayer():EyePos()
				trd.endpos = EnPosa
				trd.filter = {LocalPlayer(),v}
				trd.mask = 1174421507
				local tr = util.TraceLine(trd)
				if !tr.Hit && v:GetMoveType()!=0 then
					local a = 0
					local b = 0
					theirpos = v:EyePos():ToScreen()
					oldpos = besttarget:EyePos():ToScreen()
					if Mode==2 then
						a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
						b = v:EyePos():Distance(LocalPlayer():EyePos())
					else
						a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
						b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
					end
					if (b <= a) then
						besttarget = v
					elseif besttarget == LocalPlayer() then
						besttarget = v
					end
				end
		else
			if v:IsValid() && v:GetClass() == "prop_physics" && !PlyOnly &&  table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
				local EnPosa = v:GetPos()+v:OBBCenter()
				local trd = {}
				trd.start = LocalPlayer():EyePos()
				trd.endpos = EnPosa
				trd.filter = {LocalPlayer(),v}
				local tr = util.TraceLine(trd)
				if !tr.Hit then
					local a = 0
					local b = 0
					theirpos = v:EyePos():ToScreen()
					oldpos = besttarget:EyePos():ToScreen()
					if Mode==2 then
						a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
						b = v:EyePos():Distance(LocalPlayer():EyePos())
					else
						a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
						b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
					end
					if (b <= a) then
						besttarget = v
					elseif besttarget == LocalPlayer() then
						besttarget = v
					end
				end
			elseif  v:IsValid() && table.HasValue(lockonlist, v:GetClass()) && !PlyOnly then
			 if v:GetMoveType()!=0 || v:GetClass()=="ph_prop" then
				local EnPosa = v:GetPos()+v:OBBCenter()
				local trd = {}
				trd.start = LocalPlayer():EyePos()
				trd.endpos = EnPosa
				trd.filter = {LocalPlayer(),v}
				local tr = util.TraceLine(trd)
				if !tr.Hit then
					local a = 0
					local b = 0
					theirpos = v:EyePos():ToScreen()
					oldpos = besttarget:EyePos():ToScreen()
					if Mode==2 then
						a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
						b = v:EyePos():Distance(LocalPlayer():EyePos())
					else
						a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
						b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
					end
					if (b <= a) then
						besttarget = v
					elseif besttarget == LocalPlayer() then
						besttarget = v
					end
				end
			 end
			end
		end
	end
	return besttarget
end


function AimbotThink()
local FOVlock=FOV:GetBool()
local AntiSnap=Anti:GetBool()
if state && SelectTarget()!=LocalPlayer() then
	local s1 = es:GetInt()
	local s2 = ms:GetInt()
	target = SelectTarget()
	if target:IsNPC() || target:IsPlayer() then
		local mod = target:LookupAttachment("eyes")
		if mod != 0 then
			EnPosa = target:GetAttachment(mod).Pos + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"zombie/fast") || string.find(string.lower(target:GetModel()),"manhack") then
			EnPosa = target:GetAttachment(2).Pos + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"crab") || string.find(string.lower(target:GetModel()),"crow") || string.find(string.lower(target:GetModel()),"pigeon") || string.find(string.lower(target:GetModel()),"roller") || string.find(string.lower(target:GetModel()),"seagull") then
			EnPosa = target:GetPos() + Vector(0,0,9) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"hunter") || string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,73) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"antlion") && !string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,25)
		end
	else
		EnPosa = target:GetPos()+target:OBBCenter() 
	end
	local testa=((EnPosa-LocalPlayer():GetShootPos()):GetNormal()):Angle()
	local lol = testa-LocalPlayer():EyeAngles()
	lol.p = math.abs(lol.p)
	lol.y = math.NormalizeAngle(360-math.abs(lol.y))
	lol.r = math.abs(lol.r)
	local fov=30
	if FOVlock then
		if lol.p<fov && (lol.y<fov && lol.y>-30) then
			if AntiSnap then
				testa.p=math.NormalizeAngle(testa.p)
				testa.y=math.NormalizeAngle(testa.y)
				testb=LocalPlayer():EyeAngles()
				testb.p = math.Approach(testb.p, testa.p, 5)
				testb.y = math.Approach(testb.y, testa.y, 5)
				testb.r=0
				angles=testb
			else
				angles=testa
			end
		end
	else
		if AntiSnap then
			testa.p=math.NormalizeAngle(testa.p)
			testa.y=math.NormalizeAngle(testa.y)
			testb=LocalPlayer():EyeAngles()
			testb.p = math.Approach(testb.p, testa.p, 5)
			testb.y = math.Approach(testb.y, testa.y, 5)
			testb.r=0
			angles=testb
		else
			angles=testa
		end
	end
else
	angles=Angle(0,0,0)
end
end


hook.Add("HUDPaint","BaconBotHud",function()
local EnP = Vector(0,0,0)
local Text=""
local Colora = Color(0,0,0,0)
if state && SelectTarget()!=LocalPlayer() then
	Text = "Target Acquired"
	Colora = Color(0,255,0,255)
	target = SelectTarget()
	if target:IsNPC() || target:IsPlayer() then
		local mod = target:LookupAttachment("eyes")
		if mod != 0 then
			EnP = target:GetAttachment(mod).Pos
		end
		if string.find(string.lower(target:GetModel()),"zombie/fast") || string.find(string.lower(target:GetModel()),"manhack") then
			EnP = target:GetAttachment(2).Pos
		end
		if string.find(string.lower(target:GetModel()),"crab") || string.find(string.lower(target:GetModel()),"crow") || string.find(string.lower(target:GetModel()),"pigeon") || string.find(string.lower(target:GetModel()),"roller") || string.find(string.lower(target:GetModel()),"seagull") then
			EnP = target:GetPos() + Vector(0,0,9)
		end
		if string.find(string.lower(target:GetModel()),"hunter") || string.find(string.lower(target:GetModel()),"antlionguard") then
			EnP = target:GetPos() + Vector(0,0,73)
		end
		if string.find(string.lower(target:GetModel()),"antlion") && !string.find(string.lower(target:GetModel()),"antlionguard") then
			EnP = target:GetPos() + Vector(0,0,25)
		end
	else
		EnP = target:GetPos()+target:OBBCenter() 
	end
elseif state then
	Text = "Acquiring"
	Colora = Color(255,0,0,255)
end
if state then
	local sound = sf:GetInt()
	draw.DrawText(Text, "ScoreboardText", ScrW() / 2, ScrH()/2+50, Colora,1)
	if Text == "Acquiring" then
		surface.SetDrawColor( 255, 0, 0, 255 )
		surface.DrawLine( (ScrW()/2-10)+math.sin(CurTime()*5)*20, ScrH()/2+67,(ScrW()/2+10)+math.sin(CurTime()*5)*20,ScrH()/2+67)
		surface.SetDrawColor( 255, 255, 255, 255 )
		local pos = EnP:ToScreen()
		surface.DrawOutlinedRect(pos.x-5,pos.y-5,10,10)
		surface.SetDrawColor( 0, 255, 0, 122 )
		surface.DrawRect(pos.x-4, pos.y-4, 9,9)
	end
end
end)

concommand.Add("BaconToggle", ToggleHax )

hook.Add("Think", "AimbotThinkingHere", AimbotThink)

concommand.Add("Bacon_AddNPCfriend", function(ply, cmd, arg)
	table.insert(NPCfriends, arg[1])
end)


concommand.Add("Bacon_ToggleText", function(ply, cmd, arg)
	TextOn=!TextOn
end)


concommand.Add("Bacon_EntTriggerBot", function(ply, cmd, arg)
	EntBot=!EntBot
end)


concommand.Add("Bacon_TriggerBotDelay", function(ply, cmd, arg)
	arg[1]=tonumber(arg[1])
	if arg[1] && arg[1]>-0.1 && arg[1]<11 then
		delay = arg[1]
	else
		Msg("Invalid Number. Please use a number inbetween 0-10.\n Current Delay is "..delay.." seconds.\n")
	end
end)

hook.Add("CreateMove","this",function(cmd)
	if state && angles!=Angle(0,0,0) then
		angles.r=0
		SafeViewAngles(cmd,angles)
	end
end)

//**********************************************************___START OF VGUI FOR BACON BOT___**********************************************************
local FriendListL = nil
local PlayerListL = nil
local EntityListL = nil
local ESPEntListL = nil
local AddedESPEntList = nil
local EListL = nil
local Mode=Mod:GetInt()
local MouseX=ScrW()/2
local MouseY=ScrH()/2
function BaconBotMenu()
//START OF INIT
gui.SetMousePos(MouseX,MouseY)
_G.MPan = vgui.Create( "DFrame" )
MPan:SetPos( ScrW()/2-200,ScrH()/2-150 )
MPan:SetSize( 400, 300 )
MPan:SetTitle( "Bacon Bot Menu" )
MPan:SetVisible( true )
MPan:SetDraggable( true )
MPan:ShowCloseButton( true )
MPan:MakePopup()


local BaconBotSheet = vgui.Create( "DPropertySheet" )
BaconBotSheet:SetParent( MPan )
BaconBotSheet:SetPos( 5, 25 )
BaconBotSheet:SetSize( 390, 270 )
//END OF INIT



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF GENERAL
local AnchorPointC = vgui.Create( "DLabel", MPan )
AnchorPointC:SetPos(0,0)
AnchorPointC:SetText("")


BaconBotSheet:AddSheet( "General", AnchorPointC, "gui/silkicons/wrench", false, false, "General Configs" )

local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(4,0)
TListT:SetText("- Lock-On Selection")
TListT:SetTextColor(Color(255,255,255,255))
TListT:SizeToContents()


local POnlyC = vgui.Create("DCheckBox", AnchorPointC)
POnlyC:SetPos(10,14)
POnlyC:SetValue(ToNumFromBool(Plyo:GetBool()))
POnlyC.DoClick=function()
	POnlyC:SetValue(ToNumFromBool(!Plyo:GetBool()))
	CheckShit(1)
	RunConsoleCommand("Bacon_Plyonly",ToNumFromBool(!Plyo:GetBool()))
	RunConsoleCommand("Bacon_Entonly",0)
	RunConsoleCommand("Bacon_NPConly",0)
end
local POnlyT = vgui.Create( "DLabel", AnchorPointC)
POnlyT:SetPos(26,10)
POnlyT:SetText("Player Only")
POnlyT:SetTextColor(Color(225,225,225,225))


local NOnlyC = vgui.Create("DCheckBox", AnchorPointC)
NOnlyC:SetPos(10,28)
NOnlyC:SetValue(ToNumFromBool(NPCo:GetBool()))
NOnlyC.DoClick=function()
	NOnlyC:SetValue(ToNumFromBool(!NPCo:GetBool()))
	CheckShit(2)
	RunConsoleCommand("Bacon_NPConly",ToNumFromBool(!NPCo:GetBool()))
	RunConsoleCommand("Bacon_Entonly",0)
	RunConsoleCommand("Bacon_Plyonly",0)
end
local NOnlyT = vgui.Create( "DLabel", AnchorPointC)
NOnlyT:SetPos(26,24)
NOnlyT:SetText("NPC Only")
NOnlyT:SetTextColor(Color(225,225,225,225))


local EOnlyC = vgui.Create("DCheckBox", AnchorPointC)
EOnlyC:SetPos(10,42)
EOnlyC:SetValue(ToNumFromBool(Ento:GetBool()))
EOnlyC.DoClick=function()
	CheckShit(3)
	EOnlyC:SetValue(ToNumFromBool(!Ento:GetBool()))
	RunConsoleCommand("Bacon_Entonly",ToNumFromBool(!Ento:GetBool()))
	RunConsoleCommand("Bacon_NPConly",0)
	RunConsoleCommand("Bacon_Plyonly",0)
end

function CheckShit(x)
if x==1 then
	NOnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==2 then
	POnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==3 then
	NOnlyC:SetValue(0)
	POnlyC:SetValue(0)
end
end

local EOnlyT = vgui.Create( "DLabel", AnchorPointC)
EOnlyT:SetPos(26,38)
EOnlyT:SetText("Entity Only")
EOnlyT:SetTextColor(Color(225,225,225,225))

local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(4,58)
TListT:SetText("- Anti-Detection Settings")
TListT:SetTextColor(Color(255,255,255,255))
TListT:SizeToContents()


local AntiSC = vgui.Create("DCheckBoxLabel", AnchorPointC)
AntiSC:SetPos(10,71)
AntiSC:SetConVar( "Bacon_AntiSnap" )
local AntiST = vgui.Create( "DLabel", AnchorPointC)
AntiST:SetPos(26,67)
AntiST:SetText("Anti-Snap")
AntiST:SetTextColor(Color(225,225,225,225))


local AntiFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
AntiFC:SetPos(10,85)
AntiFC:SetConVar( "Bacon_RestrictFOV" )
local AntiFT = vgui.Create( "DLabel", AnchorPointC)
AntiFT:SetPos(26,81)
AntiFT:SetText("Restrict FOV")
AntiFT:SetTextColor(Color(225,225,225,225))


local MiscT = vgui.Create( "DLabel", AnchorPointC)
MiscT:SetPos(4,102)
MiscT:SetText("- Miscellaneous")
MiscT:SetTextColor(Color(255,255,255,255))
MiscT:SizeToContents()

local FFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
FFC:SetPos(10,116)
FFC:SetValue(ToNumFromBool(friendlyfire:GetBool()))
FFC:SetConVar( "Bacon_ff" )
local FFT = vgui.Create( "DLabel", AnchorPointC)
FFT:SetPos(26,112)
FFT:SetText("Friendly-Fire")
FFT:SetTextColor(Color(225,225,225,225))

local SFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
SFC:SetPos(90,116)
SFC:SetValue(ToNumFromBool(steamfriends:GetBool()))
SFC:SetConVar( "Bacon_Ignore_SteamFriends" )
local SFT = vgui.Create( "DLabel", AnchorPointC)
SFT:SetPos(106,115)
SFT:SetText("Ignore Steam Friends")
SFT:SizeToContents()
SFT:SetTextColor(Color(225,225,225,225))

local TBC = vgui.Create("DCheckBoxLabel", AnchorPointC)
TBC:SetPos(10,130)
TBC:SetValue(ToNumFromBool(triggertoggle:GetBool()))
TBC:SetConVar( "Bacon_Trigger_Bot" )
local TBT = vgui.Create( "DLabel", AnchorPointC)
TBT:SetPos(26,126)
TBT:SetText("Trigger-Bot")
TBT:SetTextColor(Color(225,225,225,225))


local TT = vgui.Create( "DLabel", AnchorPointC)
TT:SetPos(4,145)
TT:SetText("- Targeting Option")
TT:SetTextColor(Color(255,255,255,255))
TT:SizeToContents()

function LockOnListA()
	LockOnL = vgui.Create( "DComboBox", AnchorPointC )
	LockOnL:SetPos( 10, 160 )
	LockOnL:SetSize( 60, 100 )
	LockOnL:SetMultiple(false)
	local a= LockOnL:AddItem("Crosshair")
	local b= LockOnL:AddItem("Distance")
	local c= LockOnL:AddItem("Lowest HP")
	local d= LockOnL:AddItem("Deadliest")
	if Mod:GetInt()==1 then
		LockOnL:SelectItem(a)
	elseif Mod:GetInt()==2 then
		LockOnL:SelectItem(b)
	elseif Mod:GetInt()==3 then
		LockOnL:SelectItem(c)
	elseif Mod:GetInt()==4 then
		LockOnL:SelectItem(d)
	end
	a.DoClick=function() RunConsoleCommand("Bacon_Mode",1) LockOnL:SelectItem(a) end
	b.DoClick=function() RunConsoleCommand("Bacon_Mode",2) LockOnL:SelectItem(b) end
	c.DoClick=function() RunConsoleCommand("Bacon_Mode",3) LockOnL:SelectItem(c) end
	d.DoClick=function() RunConsoleCommand("Bacon_Mode",4) LockOnL:SelectItem(d) end

end
LockOnListA()



//END OF GENERAL



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________


//START OF ESP
local AnchorPointC = vgui.Create( "DLabel", MPan )
AnchorPointC:SetPos(0,0)
AnchorPointC:SetText("")


BaconBotSheet:AddSheet( "ESP", AnchorPointC, "gui/silkicons/world", false, false, "ESP Configuration" )

local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(4,0)
TListT:SetText("- Item Selection")
TListT:SetTextColor(Color(255,255,255,255))
TListT:SizeToContents()

local ESPPlyC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPPlyC:SetPos(10,14)
ESPPlyC:SetConVar( "Bacon_ESP_Players" )
local ESPPlyT = vgui.Create( "DLabel", AnchorPointC)
ESPPlyT:SetPos(26,10)
ESPPlyT:SetText("Players")
ESPPlyT:SetTextColor(Color(225,225,225,225))


local ESPItemC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPItemC:SetPos(10,29)
ESPItemC:SetConVar( "Bacon_ESP_Items" )
local ESPItemT = vgui.Create( "DLabel", AnchorPointC)
ESPItemT:SetPos(26,25)
ESPItemT:SetText("Items")
ESPItemT:SetTextColor(Color(225,225,225,225))

local ESPRPC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPRPC:SetPos(110,29)
ESPRPC:SetConVar( "Bacon_ESP_DarkRP" )
local ESPRPT = vgui.Create( "DLabel", AnchorPointC)
ESPRPT:SetPos(126,25)
ESPRPT:SetText("DarkRP")
ESPRPT:SetTextColor(Color(225,225,225,225))

local ESPVehC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPVehC:SetPos(10,44)
ESPVehC:SetConVar( "Bacon_ESP_Vehicles" )
local ESPVehT = vgui.Create( "DLabel", AnchorPointC)
ESPVehT:SetPos(26,40)
ESPVehT:SetText("Vehicles")
ESPVehT:SetTextColor(Color(225,225,225,225))

local ESPNPCC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPNPCC:SetPos(10,59)
ESPNPCC:SetConVar( "Bacon_ESP_NPCs" )
local ESPNPCT = vgui.Create( "DLabel", AnchorPointC)
ESPNPCT:SetPos(26,55)
ESPNPCT:SetText("NPCs")
ESPNPCT:SetTextColor(Color(225,225,225,225))

local ESPWepC = vgui.Create("DCheckBoxLabel", AnchorPointC)
ESPWepC:SetPos(10,74)
ESPWepC:SetConVar( "Bacon_ESP_Weapons" )
local ESPWepT = vgui.Create( "DLabel", AnchorPointC)
ESPWepT:SetPos(26,70)
ESPWepT:SetText("Weapons")
ESPWepT:SetTextColor(Color(225,225,225,225))

local OptionsT = vgui.Create( "DLabel", AnchorPointC)
OptionsT:SetPos(5,90)
OptionsT:SetText("- ESP Display Options")
OptionsT:SetTextColor(Color(255,255,255,255))
OptionsT:SizeToContents()

local CrosshairT = vgui.Create( "DLabel", AnchorPointC)
CrosshairT:SetPos(1,110)
CrosshairT:SetText("Crosshair Options")
CrosshairT:SetTextColor(Color(255,255,255,255))
CrosshairT:SizeToContents()

function CrosshairTypeA()
	CrosshairA = vgui.Create( "DComboBox", AnchorPointC )
	CrosshairA:SetPos( 13, 124 )
	CrosshairA:SetSize( 60, 80 )
	CrosshairA:SetMultiple(false)
	local a= CrosshairA:AddItem("Box")
	local b= CrosshairA:AddItem("Half Box")
	local c= CrosshairA:AddItem("Cross")
	if Mod:GetInt()==1 then
		CrosshairA:SelectItem(a)
	elseif Mod:GetInt()==2 then
		CrosshairA:SelectItem(b)
	elseif Mod:GetInt()==3 then
		CrosshairA:SelectItem(c)
	end
	a.DoClick=function() RunConsoleCommand("Bacon_ESP_Cross","0") CrosshairA:SelectItem(a) end
	b.DoClick=function() RunConsoleCommand("Bacon_ESP_Cross","2") CrosshairA:SelectItem(b) end
	c.DoClick=function() RunConsoleCommand("Bacon_ESP_Cross","1") CrosshairA:SelectItem(c) end

end
CrosshairTypeA()

local ESPModeT = vgui.Create( "DLabel", AnchorPointC)
ESPModeT:SetPos(94,110)
ESPModeT:SetText("Information Options")
ESPModeT:SetTextColor(Color(255,255,255,255))
ESPModeT:SizeToContents()

function ESPModeV()
	ESPMode = vgui.Create( "DComboBox", AnchorPointC )
	ESPMode:SetPos( 110, 124 )
	ESPMode:SetSize( 60, 80 )
	ESPMode:SetMultiple(false)
	local a= ESPMode:AddItem("Simple")
	local b= ESPMode:AddItem("Normal")
	local c= ESPMode:AddItem("Advanced")
	if Mod:GetInt()==1 then
		ESPMode:SelectItem(a)
	elseif Mod:GetInt()==2 then
		ESPMode:SelectItem(b)
	elseif Mod:GetInt()==3 then
		ESPMode:SelectItem(c)
	end
	a.DoClick=function() RunConsoleCommand("Bacon_ESP_Mode","0") ESPMode:SelectItem(a) end
	b.DoClick=function() RunConsoleCommand("Bacon_ESP_Mode","1") ESPMode:SelectItem(b) end
	c.DoClick=function() RunConsoleCommand("Bacon_ESP_Mode","2") ESPMode:SelectItem(c) end

end
ESPModeV()



//END OF ESP



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF FRIENDS LIST!!!!!!
local AnchorPointA = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

BaconBotSheet:AddSheet( "Friends List", AnchorPointA, "gui/silkicons/user", false, false, "Edit your friends." )


local FriendListT = vgui.Create( "DLabel", AnchorPointA )
FriendListT:SetPos(40,5)
FriendListT:SetText("Friends - Current")
FriendListT:SizeToContents()
FriendListT:SetTextColor(Color(255,255,255,255))


function FriendsListA()
	FriendListL = vgui.Create( "DComboBox", AnchorPointA )
	FriendListL:SetPos( 10, 25 )
	FriendListL:SetSize( 150, 190 )
	FriendListL:SetMultiple(true)
	for k,v in pairs(friendslist) do
		FriendListL:AddItem(v)
	end
end
FriendsListA()


local FriendListB = vgui.Create( "DButton", AnchorPointA )
FriendListB:SetPos(20,215)
FriendListB:SetText("Remove from friends")
FriendListB:SetSize(120,20)
FriendListB.DoClick = function()
	local temptable = {}
	if #FriendListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(FriendListL:GetSelectedItems()) do
		for c,d in pairs(friendslist) do
			if b:GetValue()==d then
				if #friendslist==0 then friendslist={} end
				table.remove(friendslist,c)
				table.insert(temptable,b:GetValue())
			end
		end
	end
	PlayerListA()
	FriendsListA()
	FileWrite()
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
end


local PlayerListT = vgui.Create( "DLabel", AnchorPointA )
PlayerListT:SetPos(250,5)
PlayerListT:SetText("Players List")
PlayerListT:SizeToContents()
PlayerListT:SetTextColor(Color(255,255,255,255))


function PlayerListA()
	PlayerListL = vgui.Create( "DComboBox", AnchorPointA )
	PlayerListL:SetPos( 210, 25 )
	PlayerListL:SetSize( 150, 190 )
	PlayerListL:SetMultiple(true)
	for k,v in pairs(player.GetAll()) do
		if !table.HasValue(friendslist,v:Name()) && v!=LocalPlayer() then
			PlayerListL:AddItem(v:Name())
		end
	end
end
PlayerListA()

local PlayerListB = vgui.Create( "DButton", AnchorPointA )
PlayerListB:SetPos(240,215)
PlayerListB:SetSize(80,20)
PlayerListB:SetText("Add to friends")
PlayerListB.DoClick = function()
	local temptable = {}
	if #PlayerListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(PlayerListL:GetSelectedItems()) do
		table.insert(friendslist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	PlayerListA()
	FriendsListA()
	FileWrite()
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
end
//END OF FRIENDS LIST!!!!!!



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF ENTITIES LIST!!!!!!
local AnchorPointB = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

BaconBotSheet:AddSheet( "Entities List", AnchorPointB, "gui/silkicons/bomb", false, false, "Edit lock-on entities." )


local EntityListT = vgui.Create( "DLabel", AnchorPointB )
EntityListT:SetPos(40,5)
EntityListT:SetText("Entities - Current")
EntityListT:SizeToContents()
EntityListT:SetTextColor(Color(255,255,255,255))


function EntityListA()
	EntityListL = vgui.Create( "DComboBox", AnchorPointB )
	EntityListL:SetPos( 10, 25 )
	EntityListL:SetSize( 150, 190 )
	EntityListL:SetMultiple(true)
	for k,v in pairs(lockonlist) do
		EntityListL:AddItem(v)
	end
end
EntityListA()


local EntityListB = vgui.Create( "DButton", AnchorPointB )
EntityListB:SetPos(20,215)
EntityListB:SetText("Remove from entities")
EntityListB:SetSize(120,20)
EntityListB.DoClick = function()
	local temptable = {}
	if #EntityListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EntityListL:GetSelectedItems()) do
		for c,d in pairs(lockonlist) do
			if b:GetValue()==d then
				local lost=table.remove(lockonlist,c)
				table.insert(temptable,lost)
			end
		end
	end
	EntityListA()
	EListA()
	FileWrite()
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
end


local EListT = vgui.Create( "DLabel", AnchorPointB )
EListT:SetPos(235,5)
EListT:SetText("Active Entities List")
EListT:SizeToContents()
EListT:SetTextColor(Color(255,255,255,255))


function EListA()
	EListL = vgui.Create( "DComboBox", AnchorPointB )
	EListL:SetPos( 210, 25 )
	EListL:SetSize( 150, 190 )
	EListL:SetMultiple(true)
	serverents = {}
	for k,v in pairs(ents.GetAll()) do
		if !table.HasValue(serverents,v:GetClass()) && !table.HasValue(lockonlist,v:GetClass()) then
			table.insert(serverents,v:GetClass())
		end
	end
	for g,h in pairs(serverents) do
		if h=="prop_physics" then
			ThePropList=EListL:AddItem(h)
			ThePropList.OnMousePressed=function(a,b)
			if b==108 then
				local MenuButtonOptions = DermaMenu()
				local temptablec = {}
				local temptabled = {}
				for k,v in pairs(ents.FindByClass("prop_physics")) do
					if !table.HasValue(temptablec,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) && !table.HasValue(lockonlist,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						table.insert(temptablec, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl",""))
						table.insert(temptabled,v:GetModel())
					end
				end
				for i,c in pairs(temptablec) do
					local mover = vgui.Create( "DMenuOption", MenuButtonOptions)
					mover:SetText(c)
					local icon
					mover.OnCursorEntered=function() icon=vgui.Create("SpawnIcon") icon:SetModel(temptabled[i]) icon.DoClick=function() icon:Remove() end local c,d = mover:GetPos() local a,b = MenuButtonOptions:GetPos() icon:SetPos(a+mover:GetWide(),b+d) end
					mover.OnCursorExited=function() icon:Remove() end
					mover.DoRightClick=function() icon:Remove() end
					mover.DoClick=function()
					table.insert(lockonlist,c)
					EListA()
					EntityListA()
					FileWrite()
					LocalPlayer():ChatPrint("Added: "..c)
					icon:Remove()
					end
					MenuButtonOptions:AddPanel(mover)
				end
				MenuButtonOptions:Open()
			end
			end
		else
			EListL:AddItem(h)
		end
	end
end
EListA()
local EListB = vgui.Create( "DButton", AnchorPointB )
EListB:SetPos(240,215)
EListB:SetSize(80,20)
EListB:SetText("Add to entities")
EListB.DoClick = function()
	local temptable = {}
	if #EListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EListL:GetSelectedItems()) do
		table.insert(lockonlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	EListA()
	EntityListA()
	FileWrite()
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
end



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF ESP ENTITIES LIST!!!!!!
local AnchorPointA = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

BaconBotSheet:AddSheet( "ESP Entities", AnchorPointA, "gui/silkicons/information", false, false, "Display more Entities." )


local AddedESPEntListT = vgui.Create( "DLabel", AnchorPointA )
AddedESPEntListT:SetPos(40,5)
AddedESPEntListT:SetText("ESP Entities - Current")
AddedESPEntListT:SizeToContents()
AddedESPEntListT:SetTextColor(Color(255,255,255,255))


function AddedESPEntListA()
	AddedESPEntListL = vgui.Create( "DComboBox", AnchorPointA )
	AddedESPEntListL:SetPos( 10, 25 )
	AddedESPEntListL:SetSize( 150, 190 )
	AddedESPEntListL:SetMultiple(true)
	for k,v in pairs(entlist) do
		AddedESPEntListL:AddItem(v)
	end
end
AddedESPEntListA()


local AddedESPEntListB = vgui.Create( "DButton", AnchorPointA )
AddedESPEntListB:SetPos(20,215)
AddedESPEntListB:SetText("Remove from ESP")
AddedESPEntListB:SetSize(120,20)
AddedESPEntListB.DoClick = function()
	local temptable = {}
	if #AddedESPEntListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(AddedESPEntListL:GetSelectedItems()) do
		for c,d in pairs(entlist) do
			if b:GetValue()==d then
				if #entlist==0 then entlist={} end
				table.remove(entlist,c)
				table.insert(temptable,b:GetValue())
			end
		end
	end
	AddedESPEntListA()
	EspEntListA()
	FileWrite()
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
end


local EspEntListT = vgui.Create( "DLabel", AnchorPointA )
EspEntListT:SetPos(250,5)
EspEntListT:SetText("Entities List")
EspEntListT:SizeToContents()
EspEntListT:SetTextColor(Color(255,255,255,255))


function EspEntListA()
	EspEntListL = vgui.Create( "DComboBox", AnchorPointA )
	EspEntListL:SetPos( 210, 25 )
	EspEntListL:SetSize( 150, 190 )
	EspEntListL:SetMultiple(true)
	for k,v in pairs(serverents) do
		if !table.HasValue(entlist,v) then
			EspEntListL:AddItem(v)
		end
	end
end
EspEntListA()

local EspEntListB = vgui.Create( "DButton", AnchorPointA )
EspEntListB:SetPos(240,215)
EspEntListB:SetSize(80,20)
EspEntListB:SetText("Add to ESP")
EspEntListB.DoClick = function()
	local temptable = {}
	if #EspEntListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EspEntListL:GetSelectedItems()) do
		table.insert(entlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	AddedESPEntListA()
	EspEntListA()
	FileWrite()
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
end
end
concommand.Add("+Bacon_Menu",BaconBotMenu)
concommand.Add("-Bacon_Menu",function() MouseX,MouseY=gui.MousePos() _G.MPan:Remove() end)
//END OF VGUI FOR BACON BOT

function BaconMiniWindow()
_G.MMPan = vgui.Create( "DPanel" )
MMPan:SetPos( ScrW()/2-65,10 )
MMPan:SetSize( 130, 100 )
MMPan.Paint = function()
    surface.SetDrawColor( 50, 50, 50, 155 )
    surface.DrawRect( 0, 0, MMPan:GetWide(), MMPan:GetTall() )
	draw.SimpleText("Aimbot:", "ScoreboardText",15,10, Color(255,255,255,155),0,0)
	draw.SimpleText("Friendly Fire:", "ScoreboardText",15,30, Color(255,255,255,155),0,0)
	draw.SimpleText("Trigger Bot:", "ScoreboardText",15,50, Color(255,255,255,155),0,0)
	draw.SimpleText("Mode:", "ScoreboardText",15,70, Color(255,255,255,155),0,0)
	for i=0,5 do
		surface.SetDrawColor(i/5*255,0,0,155)
		surface.DrawOutlinedRect(0+i,0+i,MMPan:GetWide()-i-i, MMPan:GetTall()-i-i)
	end
	for i=0,5 do
		surface.SetDrawColor(((5-i)/5)*255,0,0,155)
		surface.DrawOutlinedRect(0+i+5,0+i+5,MMPan:GetWide()-i-i-10, MMPan:GetTall()-i-i-10)
	end
end

local toggle = tobool(triggertoggle:GetInt())
local olda = Mod:GetInt()
local oldb = tostring(state)
local oldc = tostring(toggle)
local oldd = tostring(friendlyfire:GetBool())


_G.BaconModeIcon = vgui.Create("DImage", MMPan)
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
BaconModeIcon:SetPos(60,72)
BaconModeIcon:SetSize(32,16)
BaconModeIcon:SetImageColor(Color(255,255,255,155))
BaconModeIcon.Think=function()
if olda!=Mod:GetInt() then
olda=Mod:GetInt()
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
end
end

_G.BaconActiveIcon = vgui.Create("DImage", MMPan)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
BaconActiveIcon:SetPos(70,12)
BaconActiveIcon:SetSize(16,16)
BaconActiveIcon:SetImageColor(Color(255,255,255,155))
BaconActiveIcon.Think=function()
if oldb!=tostring(state) then
oldb=tostring(state)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
end
end

_G.BaconTriggerIcon = vgui.Create("DImage", MMPan)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
BaconTriggerIcon:SetPos(95,52)
BaconTriggerIcon:SetSize(16,16)
BaconTriggerIcon:SetImageColor(Color(255,255,255,155))
BaconTriggerIcon.Think=function()
local toggle = tobool(triggertoggle:GetInt())
if oldc!=tostring(toggle) then
oldc=tostring(toggle)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
end
end

_G.BaconRRIcon = vgui.Create("DImageButton", MMPan)
BaconRRIcon:SetImage("BaconBot/reload")
BaconRRIcon:SetPos(114,84)
BaconRRIcon:SetSize(16,16)
BaconRRIcon.OnMouseReleased=function()
include("stuff/BaconBot.lua")
end

_G.BaconFFIcon = vgui.Create("DImage", MMPan)
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
BaconFFIcon:SetPos(100,32)
BaconFFIcon:SetSize(16,16)
BaconFFIcon:SetImageColor(Color(255,255,255,155))
BaconFFIcon.Think=function()
if oldd!=tostring(friendlyfire:GetBool()) then
oldd=tostring(friendlyfire:GetBool())
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
end
end

end
concommand.Add("Bacon_Toggle_Mini_Window", function()
if !bmw:GetBool() then
	BaconMiniWindow()
	RunConsoleCommand("Bacon_TMW",1)
else
	_G.MMPan:Remove()
	RunConsoleCommand("Bacon_TMW",0)
end
end)

function esp()
local trace = util.TraceLine({start=LocalPlayer():GetShootPos(),endpos=LocalPlayer():GetShootPos() + (LocalPlayer():GetAimVector() * 64000),filter={LocalPlayer()}})
if (trace.Hit) && (trace.HitNonWorld) then draw.SimpleText(trace.Entity:GetClass(), "HealthFont", ScrW()/2, ScrH()-35, Color(0,255,0,255),1,0) end
local playeron = playeron:GetInt()
local itemon = itemon:GetInt()
local vehicleon = vehicleon:GetInt()
local npcon = npcon:GetInt()
local weaponon = weaponon:GetInt()
local trans = trans:GetInt()
local darkrp = darkrp:GetInt()
local mode = mode:GetInt()
	for k, v in pairs(player.GetAll()) do
		if v != LocalPlayer() && playeron == 1 then
			local mod = v:GetModel()
			ateam = v:Team()
			color = team.GetColor(ateam)
			color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
			if v:InVehicle() then
				colora = Color(255,255,255,trans)
			else
				colora = color
			end
			if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
				if v:Alive() && v:GetActiveWeapon():IsValid() then
					weapon=v:GetActiveWeapon( ):GetPrintName()
					weapon=string.Replace(weapon,"#HL2_","")
					weapon=string.Replace(weapon,"#GMOD_","")
				end
			else
				weapon="Unknown Wep"
			end
			hp = v:Health()
			name = v:Name()
			gpos = v:EyePos():ToScreen()
			dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
			local ads = admincheck(v)
			if mode==2 then
				tn=team.GetName(ateam)
				draw.SimpleText(hp.."   W: "..weapon, "Default", gpos.x+15, gpos.y-35, colora,0,0)
				draw.SimpleText("F","BacSigns", gpos.x+1, gpos.y-33, colora,0,0)
				draw.SimpleText(""..name.."", "Default", gpos.x+1, gpos.y-45, colora,0,0)
				draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-15, colora,0,0)
				draw.SimpleText("Dist:"..dist,"Default", gpos.x+3, gpos.y-25, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-55, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			elseif mode==0 then
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-25, colora,0,0)
				draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-12, colora,0,0)
				draw.SimpleText("F","BacSigns", gpos.x+1, gpos.y-10, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-35, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			else
				tn=team.GetName(ateam)
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-35, colora,0,0)
				draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-25, colora,0,0)
				draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-15, colora,0,0)
				draw.SimpleText("F","BacSigns", gpos.x+1, gpos.y-23, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-45, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			end
		end
	end
	for j, e in pairs(ents.GetAll()) do
		if e:IsValid() then
			if e:IsWeapon() && e:GetMoveType()!=0 && weaponon == 1 then
				wepn = e:GetClass()
				wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				wpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..wname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
				surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
			elseif e:IsNPC() && npcon == 1 then
				local amod = e:GetModel()
				local bname = e:GetClass()
				aname = string.Replace(bname,"npc_","")
				aname = string.Replace(aname,"_"," ")
				aname = string.upper(aname)
				if amod == "models/headcrabclassic.mdl" || amod == "models/headcrab.mdl" || amod == "models/headcrabblack.mdl" then
					agpos = (e:GetPos()+Vector(0,0,6)):ToScreen()
				else
					if string.find(e:GetClass(),"crow") == nil && string.find(e:GetClass(),"antlion") == nil && string.find(e:GetClass(),"strider") == nil && string.find(e:GetClass(),"hunter") == nil && string.find(e:GetClass(),"pig") == nil && string.find(e:GetClass(),"mine") == nil && string.find(e:GetClass(),"sea") == nil && string.find(e:GetClass(),"furniture") == nil && string.find(e:GetClass(),"driver") == nil then
						agpos = e:GetAttachment(1).Pos:ToScreen()
					else
						agpos = e:GetPos() + Vector(0,0,5)
						agpos = agpos:ToScreen()
					end
				end
				nhp = e:Health()
				surface.SetDrawColor(255,200,0,trans)
				draw.SimpleText(""..aname.."", "Default", agpos.x+3, agpos.y-15, Color(255,200,0,trans),0,0)
				draw.SimpleText("NPC", "Default", agpos.x+3, agpos.y-25, Color(255,200,0,trans),0,0)
				surface.DrawLine(agpos.x,agpos.y,agpos.x,agpos.y-20)
				surface.DrawLine(agpos.x,agpos.y,agpos.x+20,agpos.y)
			elseif string.find(e:GetClass(),"item_") && itemon == 1 then
				iname = e:GetClass()
				iname = string.Replace(iname,"item_","")
				iname = string.Replace(iname,"_"," ")
				iname = string.upper(iname)
				ipos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..iname.."", "Default", ipos.x+3, ipos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(ipos.x,ipos.y,ipos.x,ipos.y-20)
				surface.DrawLine(ipos.x,ipos.y,ipos.x+20,ipos.y)
			elseif string.find(e:GetClass(),"prop_vehicle_") != nil && vehicleon == 1 then
				vname = e:GetClass()
				vname = string.Replace(vname,"prop_vehicle_","")
				vname = string.Replace(vname,"_"," ")
				vname = string.upper(vname)
				vpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..vname.."", "Default", vpos.x+3, vpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(vpos.x,vpos.y,vpos.x,vpos.y-20)
				surface.DrawLine(vpos.x,vpos.y,vpos.x+20,vpos.y)
			elseif (string.find(e:GetClass(),"spawned_shipment") || string.find(e:GetClass(),"spawned_weapon") || string.find(e:GetClass(),"money_printer") || string.find(e:GetClass(),"gunlab") || string.find(e:GetClass(),"drug_lab") || (e:GetClass()=="prop_physics" && e:GetModel()=="models/props/cs_assault/money.mdl")) && darkrp == 1 then
				if string.find(e:GetClass(),"spawned_shipment") then
					dname = e:GetNWString("contents").." x "..e:GetNWInt("count")
					dname = string.upper(dname)
					dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText(""..dname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
					surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
				elseif string.find(e:GetClass(),"spawned_weapon") then
					daname = e:GetModel()
					daname = string.Replace(daname,"models/weapons/w_","")
					daname = string.Replace(daname,".mdl","")
					daname = string.Replace(daname,"shot_","")
					daname = string.Replace(daname,"pist_","")
					daname = string.Replace(daname,"smg_","")
					daname = string.Replace(daname,"m3super90","Pump Shotgun")
					daname = string.Replace(daname,"rif_","")
					daname = string.Replace(daname,"snip_g3sg1","Sniper")
					daname = string.upper(daname)
					dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText(""..daname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
					surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
				elseif string.find(e:GetClass(),"money_printer") then
					mpname = e:GetClass()
					mpname = string.Replace(mpname,"_"," ")
					mpname = string.upper(mpname)
					wpos = e:GetPos():ToScreen()
					draw.SimpleText(mpname, "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
					surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
				elseif string.find(e:GetClass(),"gunlab") then
					glname = e:GetClass().." - "..e:GetNWInt("price")
					glname = string.Replace(glname,"_"," ")
					glname = string.upper(glname)
					wpos = e:GetPos():ToScreen()
					draw.SimpleText(""..glname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
					surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
				elseif string.find(e:GetClass(),"drug_lab") then
					dlname = e:GetClass()
					dlname = string.Replace(dlname,"_"," ")
					dlname = string.upper(dlname)
					wpos = e:GetPos():ToScreen()
					draw.SimpleText(""..dlname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
					surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
				elseif e:GetClass()=="prop_physics" && e:GetModel()=="models/props/cs_assault/money.mdl" then
					dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText("$", "Default", dpos.x, dpos.y, Color(255,0,0,trans),0,0)
				end
			elseif table.HasValue(entlist, e:GetClass()) then
				cname = e:GetClass()
				cname = string.Replace(cname,"weapon_","")
				cname = string.Replace(cname,"sent_","")
				cname = string.Replace(cname,"rp_","")
				cname = string.Replace(cname,"swep_","")
				cname = string.Replace(cname,"swep_","")
				cname = string.Replace(cname,"class","")
				cname = string.Replace(cname," ","")
				cname = string.Replace(cname,"_"," ")
				cname = string.upper(cname)
				dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
				draw.SimpleText(""..cname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			end
		end
	end
end
hook.Add("HUDPaint", "EspHUD", esp)
function adminfind()
	local num = 0
	draw.SimpleText("Admins:", "Default", ScrW()-200, 100, Color(255,0,0,255),0,0)
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			num=1+num
			draw.SimpleText(v:Name(), "Default", ScrW()-200, 100+(num*10), Color(255,0,0,255),0,0)
		end
	end
end
hook.Add("HUDPaint","adminfind",adminfind)

function DrawCrosshair(ply)
local cross = cross:GetInt()
local gpos=ply:EyePos():ToScreen()
if cross==0 then
	local v=ply
			local center = v:LocalToWorld(v:OBBCenter())
			local min,max = v:WorldSpaceAABB()
			local dim = max-min
			
			local front = v:GetForward()*(dim.y/2)
			local right = v:GetRight()*(dim.x/2)
			local top = v:GetUp()*(dim.z/2)
			local back = (v:GetForward()*-1)*(dim.y/2)
			local left = (v:GetRight()*-1)*(dim.x/2)
			local bottom = (v:GetUp()*-1)*(dim.z/2)
			local FRT = center+front+right+top
			local BLB = center+back+left+bottom
			local FLT = center+front+left+top
			local BRT = center+back+right+top
			local BLT = center+back+left+top
			local FRB = center+front+right+bottom
			local FLB = center+front+left+bottom
			local BRB = center+back+right+bottom
			
			FRT = FRT:ToScreen()
			BLB = BLB:ToScreen()
			FLT = FLT:ToScreen()
			BRT = BRT:ToScreen()
			BLT = BLT:ToScreen()
			FRB = FRB:ToScreen()
			FLB = FLB:ToScreen()
			BRB = BRB:ToScreen()
			
			local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
			local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
			local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
			local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
			
			surface.SetDrawColor(0,255,0,255)
			
			surface.DrawLine(xmax,ymax,xmax,ymin)
			surface.DrawLine(xmax,ymin,xmin,ymin)
			surface.DrawLine(xmin,ymin,xmin,ymax)
			surface.DrawLine(xmin,ymax,xmax,ymax)
elseif cross==1 then
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(gpos.x,gpos.y+5,gpos.x,gpos.y-5)
	surface.DrawLine(gpos.x-5,gpos.y,gpos.x+5,gpos.y)
else
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(gpos.x,gpos.y,gpos.x,gpos.y-20)
	surface.DrawLine(gpos.x,gpos.y,gpos.x+20,gpos.y)
end
end

function admincheck(ply)
			if AssMod && ply:GetLevel()<5 then
				ads=ASSlist[ply:GetLevel()+1]
			elseif ply:IsAdmin() then
				ads="*Admin*"
				if ply:IsSuperAdmin() then
					ads="*Super Admin*"
				end
			else
				ads = ""
			end
			return ads
end

function InitShit()
if file.Exists(dir) then
	friendslist = util.KeyValuesToTable(file.Read(dir))
else
	file.Write(dir,util.TableToKeyValues(friendslist))
end
if file.Exists(dire) then
	lockonlist = util.KeyValuesToTable(file.Read(dire))
else
	file.Write(dire,util.TableToKeyValues(lockonlist))
end
if file.Exists(direc) then
	entlist = util.KeyValuesToTable(file.Read(direc))
else
	file.Write(direc,util.TableToKeyValues(entslist))
end
if _G.MMPan then _G.MMPan:Remove() end
if bmw:GetBool() then
	BaconMiniWindow()
end
end

concommand.Add("Bacon_Reload_Script", function() include("stuff/BaconBot.lua") print("**Reloaded BaconBot and BaconESP**") _G.MMPan:Remove() BaconMiniWindow() InitShit() end)