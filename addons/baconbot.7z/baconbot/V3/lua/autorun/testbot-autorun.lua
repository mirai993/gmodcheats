if !CLIENT then return end
require("testbot")