if MaxPlayers then return end
require("testbot")