******************
******************
BaconBot_v3 ReadMe
******************
******************

!!!!!!!!!!!!!DISCLAIMER!!!!!!!!!!!!!!!!! YOU BETTER READ THIS!!!!!!!!!!

FIRST THING IS FIRST YOU MUST NOT HAVE ANY CUSTOM ADDED .LUA SCRIPTS RUNNING IN YOUR 

LUA/AUTORUN 

OR 

LUA/AUTORUN/CLIENT

IF YOU DO YOU RUN THE RISK OF GETTING BANNED FROM RANDOM SERVERS!!!!!!


ALSO FOR PERP2 PEOPLE IF YOU RUN GMOD ONE DAY AND DECIDE FOR SOME ODD REASON "HEY I DONT WANT TO CHEAT ON PERP2 TODAY ;)" AND CLICK THE LITTLE "X" BUTTION ON THE BB LOGIN PANNLE, THEN DECIDE TO JOIN PERP2 "YOU WILL BE BANNED!!!!!!!!!!!!!!" PERP2 LOOKS FOR BBOT.LUA AND IF YOU DONT RUN THE SCRIPT TO BYPASS THE SERVERS ANTICHEAT IT WILL GET YOU BANNED CAUSE BBOT.LUA IS NOT DOING ANYTHING!!!!!! 

ALSO IN PERP2 IF YOU DECIDE TO BIND BACONBOT KEYS WHILE IN THE PERP2 SERVER AND YOU ACCIDENTLY MAKE A TYPO LIKE "+bocon_speed 1" YOU WILL BE BANNED!!!  YOU MUST TYPE THE CORRECT COMMANDS/BINDS IN CONSOLE CAUSE THE SERVER SENDS ALL THE "+" COMMANDS TO THE ADMINS TELLING THEM A CLIENT IS TRYING TO RUN A HACK!!!!!



Install instructions:
_________________________________________
Put the lua and materials folders in your garrysmod/garrysmod folder
and boot up gmod to see if it works.
_________________________________________

Console Commands: (bind <KEY> <COMMAND>)
_________________________________________
+Bacon_Menu
	Bind this to a key and hold down that key to see the menu.

+BaconToggle
	Bind and hold down key to activate Bacon Bot and let go of key to deactivate.

BaconToggle
	Bind and tap key once to activate and then tap key again to deactivate.

Bacon_triggerbot_toggle 
	Bind and tap to toggle the trigger bot on and off.

Bacon_FF_Toggle
	Bind and tap to toggle the friendly fire.


Features:
_________________________________________
*Auto-Update
	If there is a update to the Bacon Bots main code then you will automatically receive it on the next loading of the Bacon Bot.
	You may not notice updates at all. If there is a update to the Bacon Bot launcher coding then there will be a little window at the top
	right of your screen notifying you of what to do to get this update. A update to the Bacon bot launcher is code will be rare.
	
*Login System
	At first launch of the Bacon Bot there will be a panel appearing that asks you for your password (this is the password you
	suppied to us). Just enter your password and press enter or click the 'Request Access' button. Once you have enter the correct password
	and after loading, a sound will emit and there after Bacon Bot will be loaded instantly. The password will be saved to your
	Garry's Mod and will not be needed unless you ask for a password change or your password become invalid. There aftert his box will appear everytime you
	load/reload Bacon Bot, but thanks to the auto-saved password the box should only be up for a second or two.

*Aimbot
 
+Selection
   -Player Only
		This feature allows you to lock only onto player targets.
   -NPC Only
		This feature allows you to lock only onto NPC (AI) targets.
   -Entities Only
		This feature allows you to lock only onto targets listed in your entity list.
   -Friends List
		This feature allows you to add friends, so we don't accidentally shoot a fellow hacker or admin.
   -Entity Lock-On List
		This feature allows you to add entities in which you wish to target.
   -Friendly Fire
		Allows locking onto players of the same team as you.
 

+Anti-Detection
   -Anti-Snap
		This allows you to slowly turn towards a target, instead of instantly snapping to them.
   -Restrict FOV
		This allows you to only lock onto targets in your field of view.

 
+Target Selecting Modes (FYI: For all modes target must be visible.)
   -Crosshair
		With this mode you lock onto targets closest to your crosshair.
   -Distance
		Locks onto the closest target to you.
   -Lowest HP (Does not work for: NPCs, Entities)
		Locks onto the target with the lowest health.
   -Deadliest (Does not work for: NPCs, Entities)
		Locks onto the target that is looking most at you.
   -Aim Assist
		Locks onto a target when your crosshair rolls over them. Will stay locked on until bacon bot is disabled or target dies/deleted/destroyed.

 
+Misc
   
    
    -Clientside Spectate
           This allows you to spectate "clientside" freely and see only what is networked to your player."THIS IS NOT NO-CLIP"
    
    -Name Changer
           Once this box has been checked your players name will repedily change through every other players name on the current server without showing your name.
     
    -Auto Reload 
          This allows your gun to auto reload itself after it has run the clip dry.

    -Third Person
          Once this box is checked it allows your player to be in 3rd person.


     -Spin Bot
           This allows your player to spin rapidly in a 360 motion, But still allows your player to appear to you as if he is stairing striaght. 
           "Not Reccomended unless your raging"

     -Bunny Hop
            Check this box and hold down spacebar for constant jumping.

     -Ignore Steam Friends
		With this checked you will not lock onto anyone that is on your Steam Friends' list.
   
     -Trigger-Bot
		This is a main feature of the Bacon Bot. This feature will make you automatically shoot when you crosshair is on a target.
   
     *BaconBot Mini Window
	A little window at the top of the screen that shows the status of the Bacon Bot and is toggable in the Aimbot menu.



*ESP ('Extra Sensory Perspective' AKA 3D Radar)
 +Modes
   -Simple
		Name, HP
   -Normal
		Name, HP, Weapon
   -Advanced
		Name, HP, Team, Weapon, Distance
 



+Crosshair Type
   -Box
		Places a box around players.
   -Cross
		Places a cross above players heads.
   -|_
		Places a L shaped figure above players heads.
 


+Targets
   -Players
		Places information over players heads.
   -Items
		Places name of item over items such as health and ammo.
   -Vehicles
		Places name of vehicle over vehicles.
   -NPCs
		Places name of NPC over their heads(or body if they are headless man eating zombies and such).
   -Weapons
		Places name of weapon over weapons.
   

-Entity Chams and Entity Chams 2
		This is a main feature of the Bacon Bot. This feature allows you to see targets and objects through walls.


+Show Invisible Props
		Invisible entities will become halfway translucent.
 
+ESP Transparency
		Change the transparency of the ESP HUD.
 
+Entity List
	Add custom entities to the ESP to be shown on the HUD.





