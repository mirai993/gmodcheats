require( "forceconvar" )

local Hooks = {}
local Commands = {}

local UmsgSIZE = function() end
local oldRCC = RunConsoleCommand

local CVARMETAGETINT = _R.ConVar.GetInt
local svcheats = GetConVar("sv_cheats")

local realhook = hook

local PlayerListA = function() end
local EListA = function() end
local state = false
local friendlyfire = CreateClientConVar( "Bacon_ff", 0, true, false )
local target = nil
local friendslist = {}
local ScanningText = "Scanning"
local ScanningFoundText = "Target Locked"
local timea = CurTime()
local timeb = CurTime()
local angles = Angle(0,0,0)
local Chamo = CreateClientConVar( "Bacon_Chams", 0, true, false )
local NPCo = CreateClientConVar( "Bacon_NPConly", 0, true, false )
local Ento = CreateClientConVar( "Bacon_Entonly", 0, true, false )
local Plyo= CreateClientConVar( "Bacon_Plyonly", 0, true, false )
local LockY= CreateClientConVar( "Bacon_LockY", 0, true, false )
local es = CreateClientConVar( "Bacon_Enemy_Compensation", 45, true, false )
local ms = CreateClientConVar( "Bacon_Me_Compensation", 45, true, false )
local bmw = CreateClientConVar( "Bacon_TMW", 1, true, false )
local steamfriends = CreateClientConVar( "Bacon_Ignore_SteamFriends", 1, true, false )
local sf = CreateClientConVar( "Bacon_Sound_Effects", 1, true, false )
local lockonlist = {}
local NPCfriends = {}
local triggertoggle = CreateClientConVar( "Bacon_Trigger_Bot", 0, true, false )
local attack = 0
local fire_on = false
local autofiretoggle = false
local FOV = CreateClientConVar( "Bacon_RestrictFOV", 0, true, false )
local Anti = CreateClientConVar( "Bacon_AntiSnap", 0, true, false )
local Mod = CreateClientConVar("Bacon_Mode",1,true,false)
local time = CurTime()
local delay = 0.01
local CL = LocalPlayer()
local playeron = CreateClientConVar( "espplayeron", 1, true, false )
local unhideon = CreateClientConVar( "espunhideon", 1, true, false )
local mode = CreateClientConVar( "espmode", 0, true, false )
local cross = CreateClientConVar( "espcross", 0, true, false )
local itemon = CreateClientConVar( "espitemon", 1, true, false )
local vehicleon = CreateClientConVar( "espvehicleon", 1, true, false )
local npcon = CreateClientConVar( "espnpcon", 1, true, false )
local weaponon = CreateClientConVar( "espweaponon", 1, true, false )
local trans = CreateClientConVar( "esptrans", 255, true, false )
local darkrp = CreateClientConVar( "darkrp", 1, true, false )
local ASSlist = {"*Owner*","*Super Admin*","*Admin*","*Temp Admin*","*Respected*"}
local entlist = {}
local InvisProps={}
local adminlist = CreateClientConVar( "bacon_adminlist", 1, true, false )

local showcmds = CreateClientConVar( "bacon_showcmds", 0, true, false )
local blacklistcmds = CreateClientConVar( "bacon_blacklistcmds", "", true, false )
local umsgshow = CreateClientConVar( "bacon_showumsgs", 0, true, false )

local autoreload = CreateClientConVar( "bacon_autoreload", 0, true, false )
local crosshud = CreateClientConVar( "bacon_crosshud", 0, true, false )

local chams2cvar = CreateClientConVar( "bacon_chams2", 0, true, false )

local bhop = CreateClientConVar( "bacon_bhop", 0, true, false )
local spinbot = CreateClientConVar( "bacon_spinbot", 0, true, false )
local namechange = CreateClientConVar( "bacon_namechange", 0, true, false )
local chatspam = CreateClientConVar( "bacon_chatspam", "", true, false )
local chatspaminterval = CreateClientConVar( "bacon_chatspam_interval", 0, true, false )

local logfileread = CreateClientConVar( "bacon_enable_filelogs", 1, true, false )
local logsendlua = CreateClientConVar( "bacon_enable_sendlualog", 1, true, false )
local logips = CreateClientConVar( "bacon_enable_iplogs", 1, true, false )

local clientsidenoclip = CreateClientConVar( "bacon_clientnoclip", 0, true, false )

timer.Simple(1, function()
ScanSound = CreateSound(LocalPlayer(),"BaconBot/scan.wav")
LockSound = CreateSound(LocalPlayer(),"BaconBot/lock.wav") 
end )

local Sass = tobool(string.find(string.lower(GetConVarString("sv_gamemode")),"lobby"))
surface.CreateFont("csd",20, 100, true, false, "Signs")
surface.CreateFont( "coolvetica", 30, 500, true, false, "HealthFont" )
surface.CreateFont( "Tahoma", 14, 700, true, false, "MiniFont" )

local MMPan
local SpawnVGUISPAM
local BaconMiniWindow

local oldDerma_Install_Convar_Functions = Derma_Install_Convar_Functions
function Derma_Install_Convar_Functions( PANEL )
	oldDerma_Install_Convar_Functions( PANEL )
	
	function PANEL:ConVarChanged( strNewValue )
	
		if ( !self.m_strConVar ) then return end	
		oldRCC( self.m_strConVar, tostring( strNewValue ) )
		
	end
end

local cvarrother = GetConVar("r_drawothermodels")

local function SetChams2(value)
	if value then
		if CVARMETAGETINT(svcheats) != 1 then
			ForceConVar(CreateConVar("sv_cheats", ""), "1")
		end
	
		ForceConVar(CreateConVar("r_drawothermodels", ""), "2")
	elseif CVARMETAGETINT(cvarrother) != 0 then
		ForceConVar(CreateConVar("r_drawothermodels", ""), "1")
	end
end

SetChams2(CVARMETAGETINT(chams2cvar) != 0)

local function ASScheck()
	local apps=file.Find("../lua_temp/*.lua")
	return table.HasValue(apps,"ass_client.lua")
end

local AssMod = ASScheck()

local function ULXcheck()
	local apps=file.Find("../lua_temp/ulx/*.lua")
	return table.HasValue(apps,"cl_init.lua")
end

if !sql.TableExists("Bacon_Friends") then
	sql.Query("CREATE TABLE Bacon_Friends(ID int,Name varchar(255))")
end
if !sql.TableExists("Bacon_Ents") then
	sql.Query("CREATE TABLE Bacon_Ents(ID int,Name varchar(255))")
end
if !sql.TableExists("Bacon_ESPEnts") then
	sql.Query("CREATE TABLE Bacon_ESPEnts(ID int,Name varchar(255))")
end

//Bacon File Saving
local BFS={}
BFS.GetFriends=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_Friends" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.GetEnts=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_Ents" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.GetESPEnts=function() local Tbl={} local T=sql.Query( "SELECT Name FROM Bacon_ESPEnts" ) if T && #T!=0 then Tbl=string.Explode("~",T[#T].Name or "") end return Tbl end
BFS.SetFriends=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_Friends") return end sql.Query("INSERT INTO Bacon_Friends VALUES (1,'"..table.concat(Data,"~").."')") end
BFS.SetEnts=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_Ents") return end sql.Query("INSERT INTO Bacon_Ents VALUES (1,'"..table.concat(Data,"~").."')") end
BFS.SetESPEnts=function(Data) if !Data || #Data==0 then sql.Query("DELETE FROM Bacon_ESPEnts") return end sql.Query("INSERT INTO Bacon_ESPEnts VALUES (1,'"..table.concat(Data,"~").."')") end


Commands["Bacon_Clear_All"] = function() BFS.SetFriends({}) BFS.SetEnts({}) BFS.SetESPEnts({}) end

local function admincheck(ply)
			local ads
			if AssMod && ply.GetLevel && ply:GetLevel()<4 then
				ads=ASSlist[ply:GetLevel()+1]
			elseif ply:IsAdmin() then
				ads="*Admin*"
				if ply:IsSuperAdmin() then
					ads="*Super Admin*"
				end
			else
				ads = ""
			end
			return ads
end

local function DrawCrosshair(ply)
local cross = cross:GetInt()
local gpos=ply:EyePos():ToScreen()
if cross==0 then//Box
	local v=ply
			local center = v:LocalToWorld(v:OBBCenter())
			local min,max = v:WorldSpaceAABB()
			local dim = max-min
			
			local front = v:GetForward()*(dim.y/2)
			local right = v:GetRight()*(dim.x/2)
			local top = v:GetUp()*(dim.z/2)
			local back = (v:GetForward()*-1)*(dim.y/2)
			local left = (v:GetRight()*-1)*(dim.x/2)
			local bottom = (v:GetUp()*-1)*(dim.z/2)
			local FRT = center+front+right+top
			local BLB = center+back+left+bottom
			local FLT = center+front+left+top
			local BRT = center+back+right+top
			local BLT = center+back+left+top
			local FRB = center+front+right+bottom
			local FLB = center+front+left+bottom
			local BRB = center+back+right+bottom
			
			FRT = FRT:ToScreen()
			BLB = BLB:ToScreen()
			FLT = FLT:ToScreen()
			BRT = BRT:ToScreen()
			BLT = BLT:ToScreen()
			FRB = FRB:ToScreen()
			FLB = FLB:ToScreen()
			BRB = BRB:ToScreen()
			
			local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
			local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
			local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
			local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
			
			surface.SetDrawColor(0,255,0,255)
			
			surface.DrawLine(xmax,ymax,xmax,ymin)
			surface.DrawLine(xmax,ymin,xmin,ymin)
			surface.DrawLine(xmin,ymin,xmin,ymax)
			surface.DrawLine(xmin,ymax,xmax,ymax)
elseif cross==1 then//Cross
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(gpos.x,gpos.y+5,gpos.x,gpos.y-5)
	surface.DrawLine(gpos.x-5,gpos.y,gpos.x+5,gpos.y)
else//L shape
	surface.SetDrawColor(0,255,0,255)
	surface.DrawLine(gpos.x,gpos.y,gpos.x,gpos.y-20)
	surface.DrawLine(gpos.x,gpos.y,gpos.x+20,gpos.y)
end
end

local function check(ply)
local ff=friendlyfire:GetBool()
	if ff == false then
		if ply:Team() == LocalPlayer():Team() then
			return false
		else
			return true
		end
	else
		if ply:Team() == LocalPlayer():Team() then
			return true
		else
			return true
		end
	end
end

local function afriend(ply)
	if ply:GetFriendStatus()=="friend" && steamfriends:GetBool() then return false end
	for a,b in pairs(friendslist) do
		//Msg("1:"..string.Replace(string.Replace(ply:Name(),"[",""),"]","").."\n")
		//Msg(string.lower(b))
		if string.find(string.lower(ply:Name()),string.lower(b),0,true) then
			return false
		end
	end
	if #friendslist==0 then return true end
	return true
end


// box
local lastboxtarget = nil
local tracktime = 0
local lastshot = 0

local function bcrossbox()
	local wh, hh = ScrW()/2, ScrH()/2
	surface.SetDrawColor(0, 255, 0, 255)
	surface.DrawOutlinedRect(wh - 8, hh - 8, 16, 16)

	local w = 5
	if state && angles!=Angle(0,0,0) then
		if target != lastboxtarget then
			lastboxtarget = target
			tracktime = RealTime()
		end
		local lock = math.Clamp((RealTime() - tracktime) * 2.5, 0, 1)
		w = 60 - (lock * 55)

		if lock == 1 then
			w = w + (1 - math.Clamp((RealTime() - lastshot) * 3, 0, 1)) * 15
		end
	else
		w = w + (1 - math.Clamp((RealTime() - lastshot) * 3, 0, 1)) * 15
		lastboxtarget = nil
	end

	surface.DrawLine(wh - w, hh, wh + w, hh)
	surface.DrawLine(wh, hh - w, wh, hh + w)
end

local function btraceattack(ply, dmginfo, dir, tr)
	lastshot = RealTime()
end

local function esp()
local trace = util.TraceLine({start=LocalPlayer():GetShootPos(),endpos=LocalPlayer():GetShootPos() + (LocalPlayer():GetAimVector() * 64000),filter={LocalPlayer()}})
if (trace.Hit) && (trace.HitNonWorld) then draw.SimpleText(trace.Entity:GetClass(), "HealthFont", ScrW()/2, ScrH()-35, Color(0,255,0,255),1,0) end
local playeron = playeron:GetInt()
local itemon = itemon:GetInt()
local unhideon = unhideon:GetInt()
local vehicleon = vehicleon:GetInt()
local npcon = npcon:GetInt()
local weaponon = weaponon:GetInt()
local trans = trans:GetInt()
local darkrp = darkrp:GetInt()
local mode = mode:GetInt()
	for k, v in pairs(player.GetAll()) do
		if v != LocalPlayer() && playeron == 1 then
			local mod = v:GetModel()
			local ateam = v:Team()
			local color = team.GetColor(ateam)
			local colora
			local weapon = "NONE"
			color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
			if v:InVehicle() then
				colora = Color(255,255,255,trans)
			else
				colora = color
			end
			if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
				if v:Alive() && v:GetActiveWeapon():IsValid() then
					weapon=v:GetActiveWeapon( ):GetPrintName()
					weapon=string.Replace(weapon,"#HL2_","")
					weapon=string.Replace(weapon,"#GMOD_","")
				end
			else
				weapon="NONE"
			end
			local hp = v:Health()
			local name = v:Name()
			local gpos = v:EyePos():ToScreen()
			local dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
			local ads = admincheck(v)
			local tn
			if mode==2 then
				tn=team.GetName(ateam)
				draw.SimpleText(hp.."   W: "..weapon, "Default", gpos.x+15, gpos.y-35, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-33, colora,0,0)
				draw.SimpleText(""..name.."", "Default", gpos.x+1, gpos.y-45, colora,0,0)
				draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-15, colora,0,0)
				draw.SimpleText("Dist:"..dist,"Default", gpos.x+3, gpos.y-25, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-55, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			elseif mode==0 then
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-25, colora,0,0)
				draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-12, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-10, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-35, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			else
				tn=team.GetName(ateam)
				draw.SimpleText(""..name.."", "Default", gpos.x+3, gpos.y-35, colora,0,0)
				draw.SimpleText(hp,"Default", gpos.x+15, gpos.y-25, colora,0,0)
				draw.SimpleText(""..tn.."","Default", gpos.x+3, gpos.y-15, colora,0,0)
				draw.SimpleText("F","Signs", gpos.x+1, gpos.y-23, colora,0,0)
				draw.SimpleText(""..ads.."","Default", gpos.x+3, gpos.y-45, Color(255,0,0,trans),0,0)
				DrawCrosshair(v)
			end
		end
	end
	for j, e in pairs(ents.GetAll()) do
		if e:IsValid() then
			local Br,Bg,Bb,Ba=e:GetColor()
			if (e:IsValid()&&!string.find(e:GetClass(),"class")&&Ba<=50&&unhideon==1) then
				e:SetColor(Br,Bg,Bb,200)
				table.insert(InvisProps,{Ent=e,c={Br,Bg,Bb,Ba}})
			end
			if unhideon==0 && #InvisProps>0 then
				for h,e in pairs(InvisProps) do
					if e.Ent:IsValid() then
						e.Ent:SetColor(e.c[1],e.c[2],e.c[3],e.c[4])
					end
				end
				InvisProps={}
			end
			if e:IsWeapon() && e:GetMoveType()!=0 && weaponon == 1 then
				local wepn = e:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local wpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..wname.."", "Default", wpos.x+3, wpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(wpos.x,wpos.y,wpos.x,wpos.y-20)
				surface.DrawLine(wpos.x,wpos.y,wpos.x+20,wpos.y)
			elseif e:IsNPC() && npcon == 1 && e:GetMoveType()!=0 then
				local amod = e:GetModel()
				local bname = e:GetClass()
				local aname = string.Replace(bname,"npc_","")
				aname = string.Replace(aname,"_"," ")
				aname = string.upper(aname)
				local agpos
				if amod == "models/headcrabclassic.mdl" || amod == "models/headcrab.mdl" || amod == "models/headcrabblack.mdl" then
					agpos = (e:GetPos()+Vector(0,0,6)):ToScreen()
				else
					if string.find(e:GetClass(),"crow") == nil && string.find(e:GetClass(),"antlion") == nil && string.find(e:GetClass(),"strider") == nil && string.find(e:GetClass(),"hunter") == nil && string.find(e:GetClass(),"pig") == nil && string.find(e:GetClass(),"mine") == nil && string.find(e:GetClass(),"sea") == nil && string.find(e:GetClass(),"furniture") == nil && string.find(e:GetClass(),"driver") == nil && e:GetAttachment(1) != nil then
						agpos = e:GetAttachment(1).Pos:ToScreen()
					else
						agpos = e:GetPos() + Vector(0,0,5)
						agpos = agpos:ToScreen()
					end
				end
				local nhp = e:Health()
				surface.SetDrawColor(255,200,0,trans)
				draw.SimpleText(""..aname.."", "Default", agpos.x+3, agpos.y-15, Color(255,200,0,trans),0,0)
				draw.SimpleText("NPC", "Default", agpos.x+3, agpos.y-25, Color(255,200,0,trans),0,0)
				surface.DrawLine(agpos.x,agpos.y,agpos.x,agpos.y-20)
				surface.DrawLine(agpos.x,agpos.y,agpos.x+20,agpos.y)
			elseif string.find(e:GetClass(),"item_") && itemon == 1 then
				local iname = e:GetClass()
				iname = string.Replace(iname,"item_","")
				iname = string.Replace(iname,"_"," ")
				iname = string.upper(iname)
				local ipos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..iname.."", "Default", ipos.x+3, ipos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(ipos.x,ipos.y,ipos.x,ipos.y-20)
				surface.DrawLine(ipos.x,ipos.y,ipos.x+20,ipos.y)
			elseif string.find(e:GetClass(),"prop_vehicle_") != nil && vehicleon == 1 then
				local vname = e:GetClass()
				vname = string.Replace(vname,"prop_vehicle_","")
				vname = string.Replace(vname,"_"," ")
				vname = string.upper(vname)
				local vpos = e:GetPos():ToScreen()
				surface.SetDrawColor(255,0,0,trans)
				draw.SimpleText(""..vname.."", "Default", vpos.x+3, vpos.y-15, Color(255,0,0,trans),0,0)
				surface.DrawLine(vpos.x,vpos.y,vpos.x,vpos.y-20)
				surface.DrawLine(vpos.x,vpos.y,vpos.x+20,vpos.y)
			elseif (string.find(e:GetClass(),"spawned_shipment") || string.find(e:GetClass(),"spawned_weapon") || (e:GetClass()=="prop_physics" && e:GetModel()=="models/props/cs_assault/Money.mdl")) && darkrp == 1 then
				if string.find(e:GetClass(),"spawned_shipment") then
					local dname = e:GetNWString("contents").." x "..e:GetNWInt("count")
					dname = string.upper(dname)
					local dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText(""..dname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
					surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
				elseif string.find(e:GetClass(),"spawned_weapon") then
					local daname = e:GetModel()
					daname = string.Replace(daname,"models/weapons/w_","")
					daname = string.Replace(daname,".mdl","")
					daname = string.Replace(daname,"shot_","")
					daname = string.Replace(daname,"pist_","")
					daname = string.Replace(daname,"smg_","")
					daname = string.Replace(daname,"m3super90","Pump Shotgun")
					daname = string.Replace(daname,"rif_","")
					daname = string.Replace(daname,"snip_g3sg1","Sniper")
					daname = string.upper(daname)
					local dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText(""..daname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
					surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
					surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
				elseif e:GetClass()=="prop_physics" && e:GetModel()=="models/props/cs_assault/Money.mdl" then
					local dpos = e:GetPos():ToScreen()
					surface.SetDrawColor(255,0,0,trans)
					draw.SimpleText("$", "Default", dpos.x, dpos.y, Color(255,0,0,trans),0,0)
				end
			elseif string.find(e:GetClass(),"keypad") then
				if ( e:GetNWBool( "keypad_access" ) && e:GetNWBool( "keypad_showaccess" ) ) then
					e.Password=e:GetNWInt( "keypad_num" )
				end
				if e:GetNetworkedBool("keypad_secure") then
					e.Password="SECURE MODE"
				end
				local dpos = e:GetPos():ToScreen()
				draw.SimpleText(e.Password or "NONE", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			elseif table.HasValue(entlist, e:GetClass()) then
				local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
				local cename = e:GetClass()
				local cesname = string.Replace(cename,"weapon_","")
				cesname = string.Replace(cesname,"ent_","")
				cesname = string.Replace(cesname,"prop_","")
				cesname = string.Replace(cesname,"item_","")
				cesname = string.Replace(cesname,"_"," ")
				cesname = string.upper(cesname)
				draw.SimpleText(""..cesname.."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			elseif e:GetClass() == "prop_physics" &&  table.HasValue(entlist, string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","")) then
				local dpos = (e:GetPos()+e:OBBCenter()):ToScreen()
				draw.SimpleText(""..string.Replace(string.Replace(string.GetFileFromFilename(e:GetModel()),"/",""),".mdl","").."", "Default", dpos.x+3, dpos.y-15, Color(255,0,0,trans),0,0)
				surface.SetDrawColor(255,0,0,trans)
				surface.DrawLine(dpos.x,dpos.y,dpos.x,dpos.y-20)
				surface.DrawLine(dpos.x,dpos.y,dpos.x+20,dpos.y)
			end
		end
	end

	if crosshud:GetBool() then
		bcrossbox()
	end

	if !adminlist:GetBool() then return end
	local num = 0
	draw.SimpleText("Admins:", "Default", ScrW()-200, 100, Color(0,255,0,255),0,0)
	local temptblf={}
	for k,v in pairs(player.GetAll()) do
		if AssMod && v.GetLevel && admincheck(v)!="" then
			table.insert(temptblf,{ID=v:GetLevel(),Ply=v})
		elseif admincheck(v)!="" then
			table.insert(temptblf,{ID=1,Ply=v})
		end
	end
	table.SortByMember(temptblf, "ID", function(a, b) return a > b end)
	for i,b in ipairs(temptblf) do
		draw.SimpleText(b.Ply:Name(), "Default", ScrW()-200, 100+(i*10), Color(0,255,0,255),0,0)
	end
end

local entityxmeta = _R.Entity
local entityxsetmaterial = entityxmeta.SetMaterial

local function chams()
local Chams_toggle=Chamo:GetBool()
cam.Start3D(EyePos(), EyeAngles())
for k, v in pairs(ents.GetAll()) do
	if v:IsValid() && v!=LocalPlayer() && Chams_toggle && (v:GetPos()-LocalPlayer():GetPos()):Length()<=2048 then
		if v:IsValid() && v:IsPlayer() && v:Alive() then
			if !afriend(v) then
				local mat = v:GetMaterial()
				local tc=team.GetColor(v:Team())
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 0, (math.sin(CurTime()*2)+1)/2,0)
				v:SetModelScale(Vector(1.4,1.4,1))
				entityxsetmaterial(v, "BaconBot/living")
				v:DrawModel()
			end
			local mat = v:GetMaterial()
			local tc=team.GetColor(v:Team())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( (tc.r/255), (tc.g/255), (tc.b/255) )
			v:SetModelScale(Vector(1.1,1.1,1))
			entityxsetmaterial(v, "BaconBot/living")
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			v:SetModelScale(Vector(1,1,1))
			entityxsetmaterial(v, mat)
			v:DrawModel()
		elseif v:IsValid() && v:GetClass() == "prop_physics" && table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
			local mat = v:GetMaterial()
			render.SuppressEngineLighting( true )
			render.SetColorModulation( 1, 0, 0)
			v:SetModelScale(Vector(1.1,1.1,1))
			entityxsetmaterial(v, "BaconBot/living")
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			entityxsetmaterial(v, mat)
			v:SetModelScale(Vector(1,1,1))
			v:DrawModel()
		elseif v:IsValid() && (table.HasValue(lockonlist, v:GetClass()) || (v:IsNPC() && v:GetMoveType()!=0)) then
			local mat = v:GetMaterial()
			render.SuppressEngineLighting( true )
			render.SetColorModulation( 1, 0, 0)
			v:SetModelScale(Vector(1.1,1.1,1))
			entityxsetmaterial(v, "BaconBot/living")
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			v:SetModelScale(Vector(1,1,1))
			entityxsetmaterial(v, mat)
			v:DrawModel()
		end
    end
end 
cam.End3D()
 
end

local PredictSpread = function() end
local mysetupmove = function() end
local Check = function() end

local CL = LocalPlayer()

local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_deco.dll")>=1 then
NoSpreadHere=true
// ANTI SPREAD SCRIPT

local MoveSpeed = 1

mysetupmove = function(objPl, move)
	if move then
		MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
	end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
	{check=function ()
		return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
	end,getcone=function (wep,cone)
		if type(wep.Base) == "string" then
			if wep.Base == "civilian_base" then
				local scale = cone
				if CL:KeyDown(IN_DUCK) then
					scale = math.Clamp(cone/1.5,0,10)
				elseif CL:KeyDown(IN_WALK) then
					scale = cone
				elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
					scale = cone + (cone*2)
				elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
					scale = cone + (cone*1.5)
				end
				scale = scale + (wep:GetNWFloat("Recoil",0)/3)
				return Vector(scale,0,0)
			end
		end
		return Vector(cone,cone,cone)
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
	end,getcone=function (wep,cone)
		if wep:GetNetworkedBool("Ironsights",false) then
			if CL:Crouching() then
				return wep.ConeIronCrouching or cone
			end
			return wep.ConeIron or cone
		elseif 25 < LocalPlayer():GetVelocity():Length() then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
	end,getcone=function (wep,cone)
		if CL:GetVelocity():Length() > 25 then
			return wep.ConeMoving or cone
		elseif CL:Crouching() then
			return wep.ConeCrouching or cone
		end
		return cone
	end},
	{check=function ()
		return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
	end,getcone=function (wep, cone)
		if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
			if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
				print("using scopecone")
				return wep.Primary.Cone
			end
			print("using unscoped cone")
			return wep.Primary.UnscopedCone
		end
		if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
			return cone
		end
		return cone + .05
	end},
	{check=function ()
		return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
	end,getcone=function(wep,cone)
		if wep.Primary then
			local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
			local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
			local accuracy = wep.Primary.Accuracy
			if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
			if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
			accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
			if CL:KeyDown(IN_DUCK) then
				return accuracy*wep.CrouchModifier*lastshootmod
			else
				return accuracy*lastshootmod
			end
		end
	end}
}
Check = function()
	for k, v in pairs(GameTypes) do
		if v.check() then
			ID_GAMETYPE = k
			break
		end
	end
end

Commands["raidbot_predictcheck"] = function () Check() print("GameType = ["..ID_GAMETYPE.."]") end

local tblNormalConeWepBases = {
	["weapon_cs_base"] = true
}
local function GetCone(wep)
	local cone = wep.Cone
	if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
		cone = wep.Primary.Cone
	end
	if not cone then cone = 0 end
	--CHeck if wep is HL2 then return corresponding cone
	if type(wep.Base) == "string" and tblNormalConeWepBases[wep.Base] then return cone end
	if wep:GetClass() == "ose_turretcontroller" then return 0 end
	if ID_GAMETYPE ~= -1 then return GameTypes[ID_GAMETYPE].getcone(wep,cone) end
	return cone or 0
end

require("deco")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
	cmd2, seed = hl2_ucmd_getprediciton(cmd)
	if cmd2 ~= 0 then
		currentseed = seed
	end
	wep = LocalPlayer():GetActiveWeapon()
	vecCone = Vector(0,0,0)
	if wep and wep:IsValid() and type(wep.Initialize) == "function" then
		valCone = GetCone(wep)
		if type(valCone) == "number" then
			vecCone = Vector(-valCone,-valCone,-valCone)
		elseif type(valCone) == "Vector" then
			vecCone = -1*valCone
		end
	end
	return hl2_shotmanip(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
//END OF ANTI SPREAD SCRIPT
end

local function ToNumFromBool(x)
if x then return 1 else return 0 end
end

//RunConsoleCommand("cl_xfire","N/A ")

local function trigger()
if fire_on || autofiretoggle then
	if fire_on then
		oldRCC("-attack")
		fire_on = false
	elseif CurTime()-time>=0 then
		oldRCC("+attack")
		fire_on = true
		time = CurTime()+delay
	end
end
end

local function triggerthis()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	local toggle = tobool(triggertoggle:GetInt())
	local trdata = {}
	trdata.start=EyePos()
	angles.r=0
	local dest = Angle(0,0,0)
	if angles==Angle(0,0,0) then
		dest=EyeAngles()
	else
		dest=angles
	end
	trdata.endpos=EyePos()+(dest:Forward()*100000)
	trdata.filter={CL}
	trdata.mask=1174421507
	local trace = util.TraceLine(trdata).Entity
	if trace:IsValid() && trace:IsPlayer() && check(trace.Entity) && afriend(trace.Entity) && !NPConly && !Entonly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && trace:IsNPC() && !table.HasValue(NPCfriends, trace.Entity:GetClass()) && !Entonly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif trace:IsValid() && (table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl","")) || table.HasValue(lockonlist, trace:GetClass())) && !NPConly && !PlyOnly then
		if toggle then
			if attack == 0 then
				autofiretoggle=!autofiretoggle
				attack = 1
			end
		end
	elseif !trace:IsValid() || !trace:IsPlayer() || !trace:IsNPC() || ((!table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(trace:GetModel()),"/",""),".mdl",""))) || !table.HasValue(lockonlist, trace:GetClass())) then
		if attack == 1 then
			autofiretoggle=!autofiretoggle
			attack = 0
		end
	end
end

local function ToggleHax()
	if state==false then

		state = true
		target = nil
		besttarget=LocalPlayer()
	else
		state = false
		target = nil
		besttarget=LocalPlayer()
	end
end

Commands["+BaconToggle"] = function()  state=true target=nil besttarget=LocalPlayer() end
Commands["-BaconToggle"] = function() state=false target=nil besttarget=LocalPlayer() end

local function SelectTarget()
	local LockedY=LockY:GetFloat()
	local NPConly=NPCo:GetBool()
	local Entonly=Ento:GetBool()
	local PlyOnly=Plyo:GetBool()
	local Mode=Mod:GetInt()
	if Mode==5 then
		if !besttarget:IsValid() || (besttarget!=LocalPlayer() && ((besttarget:IsPlayer() && (besttarget:GetMoveType()==5 || !besttarget:Alive())) || (besttarget:IsNPC() && besttarget:GetMoveType()==0))) then
			besttarget=LocalPlayer()
			Msg(1)
		else
			local trd = {}
			trd.start = LocalPlayer():EyePos()
			trd.endpos = LocalPlayer():EyePos()+(LocalPlayer():GetAimVector()*999999)
			local veha=LocalPlayer()
			if LocalPlayer():GetVehicle() then veha=LocalPlayer():GetVehicle() end
			trd.filter = {LocalPlayer(), veha}
			trd.mask = 1174421507
			local tr = util.TraceLine(trd)
			v= tr.Entity
			if v:IsValid() && besttarget==LocalPlayer() then
				if v:IsPlayer() && !NPConly && !Entonly && v:Alive() && v!=LocalPlayer() && (check(v)) && afriend(v) && v:Health()>0 then
					besttarget=v
				elseif v:IsValid() && v:IsNPC() && !Entonly && !PlyOnly && !table.HasValue(NPCfriends, v:GetClass()) then
					besttarget=v
				else
					if v:IsValid() && v:GetClass() == "prop_physics" && !Entonly && !PlyOnly &&  table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						besttarget=v
					elseif  v:IsValid() && table.HasValue(lockonlist, v:GetClass()) && !PlyOnly then
						besttarget=v
					end
				end
			end
		end
	else
		besttarget = LocalPlayer()
		for k, v in pairs(ents.GetAll()) do
			if v:IsPlayer() && v:IsValid() && !NPConly && !Entonly then
				if v:Alive() && v!=LocalPlayer() && (check(v)) && afriend(v) && v:Health()>0 then
					local EnPosa = 0
					local mod = v:LookupAttachment("eyes")
					if mod != 0 then
						EnPosa = v:GetAttachment(mod).Pos-Vector(0,0,LockedY)
					end
					if v:GetModel()=="models/zombie/fast.mdl" then
						EnPosa = v:GetAttachment(2).Pos-Vector(0,0,LockedY)
					end
					if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") || string.find(string.lower(v:GetModel()),"manhack") then
						EnPosa = v:GetPos() + Vector(0,0,6)
					end
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					local veh=LocalPlayer()
					local veha=LocalPlayer()
					if v:GetVehicle() then veh=v:GetVehicle() end
					if LocalPlayer():GetVehicle() then veha=LocalPlayer():GetVehicle() end
					trd.filter = {LocalPlayer(),v, veh, veha}
					trd.mask = 1174421507
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = (v:EyePos()-Vector(0,0,LockedY)):ToScreen()
						oldpos = (besttarget:EyePos()-Vector(0,0,LockedY)):ToScreen()
						if Mode==2 then
							a = (besttarget:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
							b = (v:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
						elseif Mode==1 then
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						elseif Mode==3 then
							a = besttarget:Health()
							b = v:Health()
						elseif Mode==4 then
							local hmath=(((LocalPlayer():EyePos()-besttarget:GetShootPos()):GetNormal()):Angle())-besttarget:EyeAngles()
							a=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
							local hmath=(((LocalPlayer():EyePos()-v:GetShootPos()):GetNormal()):Angle())-v:EyeAngles()
							b=((math.abs(hmath.p/2)+math.abs(hmath.y))-540*-1)
						end
						//638
						if (b <= a) && v:Health()>0 then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				end
			elseif v:IsNPC() && !Entonly && !PlyOnly && !table.HasValue(NPCfriends, v:GetClass()) && v:GetMoveType()!=0 then
					local EnPosa = 0
					local mod = v:LookupAttachment("eyes")
					if mod != 0 then
						EnPosa = v:GetAttachment(mod).Pos-Vector(0,0,LockedY)
					end
					if v:GetModel()=="models/zombie/fast.mdl" || string.find(string.lower(v:GetModel()),"manhack") then
						EnPosa = v:GetAttachment(2).Pos-Vector(0,0,LockedY)
					end
					if string.find(string.lower(v:GetModel()),"crab") || string.find(string.lower(v:GetModel()),"crow") || string.find(string.lower(v:GetModel()),"pigeon") || string.find(string.lower(v:GetModel()),"roller") || string.find(string.lower(v:GetModel()),"seagull") then
						EnPosa = v:GetPos() + Vector(0,0,9)
					end
					if string.find(string.lower(v:GetModel()),"hunter") || string.find(string.lower(v:GetModel()),"antlionguard") then
						EnPosa = v:GetPos() + Vector(0,0,73)
					end
					if string.find(string.lower(v:GetModel()),"antlion") && !string.find(string.lower(v:GetModel()),"antlionguard") then
						EnPosa = v:GetPos() + Vector(0,0,25)
					end
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					trd.mask = 1174421507
					local tr = util.TraceLine(trd)
					if !tr.Hit && v:GetMoveType()!=0 then
						local a = 0
						local b = 0
						theirpos = (v:EyePos()-Vector(0,0,LockedY)):ToScreen()
						oldpos = (besttarget:EyePos()-Vector(0,0,LockedY)):ToScreen()
						if Mode==2 then
							a = (besttarget:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
							b = (v:EyePos()-Vector(0,0,LockedY)):Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
			else
				if v:IsValid() && v:GetClass() == "prop_physics" && !NPConly && !PlyOnly &&  table.HasValue(lockonlist, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
					local EnPosa = v:GetPos()+v:OBBCenter()
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = v:EyePos():ToScreen()
						oldpos = besttarget:EyePos():ToScreen()
						if Mode==2 then
							a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
							b = v:EyePos():Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				elseif  v:IsValid() && table.HasValue(lockonlist, v:GetClass()) && !NPConly && !PlyOnly then
				 if v:GetMoveType()!=0 || v:GetClass()=="ph_prop" then
					local EnPosa = v:GetPos()+v:OBBCenter()
					local trd = {}
					trd.start = LocalPlayer():EyePos()
					trd.endpos = EnPosa
					trd.filter = {LocalPlayer(),v}
					local tr = util.TraceLine(trd)
					if !tr.Hit then
						local a = 0
						local b = 0
						theirpos = v:EyePos():ToScreen()
						oldpos = besttarget:EyePos():ToScreen()
						if Mode==2 then
							a = besttarget:EyePos():Distance(LocalPlayer():EyePos())
							b = v:EyePos():Distance(LocalPlayer():EyePos())
						else
							a = math.Dist(ScrW()/2,ScrH()/2,oldpos.x,oldpos.y)
							b = math.Dist(ScrW()/2,ScrH()/2,theirpos.x,theirpos.y)
						end
						if (b <= a) then
							besttarget = v
						elseif besttarget == LocalPlayer() then
							besttarget = v
						end
					end
				 end
				end
			end
		end
	end
	return besttarget
end
SelectTarget()
local function AimbotThink()
if state && SelectTarget()!=LocalPlayer() then
	local FOVlock=FOV:GetBool()
	local AntiSnap=Anti:GetBool()
	local LockedY=LockY:GetFloat()
	local s1 = es:GetInt()
	local s2 = ms:GetInt()
	target = SelectTarget()
	if target:IsNPC() || target:IsPlayer() then
		local mod = target:LookupAttachment("eyes")
		if mod != 0 then
			EnPosa = target:GetAttachment(mod).Pos + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2 -Vector(0,0,LockedY)
		end
		if string.find(string.lower(target:GetModel()),"zombie/fast") || string.find(string.lower(target:GetModel()),"manhack") then
			EnPosa = target:GetAttachment(2).Pos + (target:GetVelocity()/s1) - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"crab") || string.find(string.lower(target:GetModel()),"crow") || string.find(string.lower(target:GetModel()),"pigeon") || string.find(string.lower(target:GetModel()),"roller") || string.find(string.lower(target:GetModel()),"seagull") then
			EnPosa = target:GetPos() + Vector(0,0,9) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"hunter") || string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,73) + target:GetVelocity()/s1 - LocalPlayer():GetVelocity()/s2
		end
		if string.find(string.lower(target:GetModel()),"antlion") && !string.find(string.lower(target:GetModel()),"antlionguard") then
			EnPosa = target:GetPos() + Vector(0,0,25)
		end
		if EnPosa == nil then
			EnPosa = target:GetPos() + target:OBBCenter()
		end
	else
		EnPosa = target:GetPos()+target:OBBCenter() 
	end
	if EnPosa == nil then return end 
	local testa=((EnPosa-LocalPlayer():GetShootPos()):GetNormal()):Angle()
	local lol = testa-LocalPlayer():EyeAngles()
	lol.p = math.abs(lol.p)
	lol.y = math.NormalizeAngle(360-math.abs(lol.y))
	lol.r = math.abs(lol.r)
	local fov=30
	if FOVlock then
		if lol.p<fov && (lol.y<fov && lol.y>-30) then
			if AntiSnap then
				testa.p=math.NormalizeAngle(testa.p)
				testa.y=math.NormalizeAngle(testa.y)
				testb=LocalPlayer():EyeAngles()
				testb.p = math.Approach(testb.p, testa.p, 5)
				testb.y = math.Approach(testb.y, testa.y, 5)
				testb.r=0
				angles=testb
			else
				angles=testa
			end
		end
	else
		if AntiSnap then
			testa.p=math.NormalizeAngle(testa.p)
			testa.y=math.NormalizeAngle(testa.y)
			testb=LocalPlayer():EyeAngles()
			testb.p = math.Approach(testb.p, testa.p, 5)
			testb.y = math.Approach(testb.y, testa.y, 5)
			testb.r=0
			angles=testb
		else
			angles=testa
		end
	end
else
	angles=Angle(0,0,0)
end
end

Commands["BaconToggle"] = ToggleHax

Commands["Bacon_AddNPCfriend"] = function(ply, cmd, arg)
	table.insert(NPCfriends, arg[1])
end

Commands["Bacon_TriggerBotDelay"] = function(ply, cmd, arg)
	arg[1]=tonumber(arg[1])
	if arg[1] && arg[1]>-0.1 && arg[1]<11 then
		delay = arg[1]
	else
		Msg("Invalid Number. Please use a number inbetween 0-10.\n Current Delay is "..delay.." seconds.\n")
	end
end

local iZoom = 0
local iZoomAdd = 0

local function In()
	iZoomAdd = iZoomAdd + 1
end

local function Out()
	iZoomAdd = iZoomAdd - 1
end

Commands["+zoom_in"] = In
Commands["-zoom_out"] = In
Commands["+zoom_out"] = Out
Commands["-zoom_in"] = Out

Commands["zoom_reset"] = function() iZoom = 0 end


local SetViewAngles = _R.CUserCmd.SetViewAngles
local clear = 0xFFFF - IN_JUMP

local spinangle = Angle(0,0,0)
local ucorrected = Angle(0,0,0)

local ghostpos = nil

local function bcmove(cmd)
	if state && angles!=Angle(0,0,0) then
		angles.r=0
		ucorrected = angles
		ucorrected.p = math.NormalizeAngle(ucorrected.p)
		ucorrected.y = math.NormalizeAngle(ucorrected.y)
		
		if NoSpreadHere then
			local AntiSpread = PredictSpread(cmd,angles)
			SetViewAngles(cmd,AntiSpread)
		else
			SetViewAngles(cmd,angles)
		end
	else
		local correct = 1
		if iZoom != 0 then
			 correct = ( 1 - ( iZoom / 100 ) )
		end
		
		if !(IsValid(LocalPlayer():GetActiveWeapon()) && LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" && (cmd:GetButtons() & IN_USE) > 0) then
			ucorrected.y = math.NormalizeAngle(ucorrected.y + (cmd:GetMouseX() * -0.022 * correct))
			ucorrected.p = math.Clamp(ucorrected.p + (cmd:GetMouseY() * 0.022 * correct), -89, 90)
		end

		
		if !clientsidenoclip:GetBool() || ghostpos == nil then
			SetViewAngles(cmd, ucorrected)
		end
	end
	
	if clientsidenoclip:GetBool() && ghostpos != nil then
		local add = Vector( 0, 0, 0 )
		local ang = ucorrected
		if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
		if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
		if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
		if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
		if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
		if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
		add = add:GetNormal() * FrameTime() * 500
		if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end

		ghostpos = ghostpos + add
		
		cmd:SetForwardMove( 0 )
		cmd:SetSideMove( 0 )
		cmd:SetUpMove( 0 )
		cmd:SetButtons( 0 )
	end
	
	if bhop:GetBool() && !LocalPlayer():InVehicle() && (cmd:GetButtons() & IN_JUMP) > 0 then
		if LocalPlayer():IsOnGround() then
			cmd:SetButtons(cmd:GetButtons() | IN_JUMP)
		else
			cmd:SetButtons(cmd:GetButtons() & clear)
		end
	end
	

	
	if spinbot:GetBool() && (cmd:GetButtons() & (IN_ATTACK | IN_ATTACK2)) == 0  then
		local view = cmd:GetViewAngles()
				
		spinangle.y = spinangle.y + 20
		SetViewAngles(cmd, spinangle)

		local diff = math.Deg2Rad(math.NormalizeAngle(spinangle.y - view.y))
				
		local absf = math.Clamp(cmd:GetForwardMove(), -1, 1)
		local abss = math.Clamp(cmd:GetSideMove(), -1, 1)
		
		cmd:SetForwardMove(-1000 * math.sin(diff) * abss)
		cmd:SetSideMove(1000 * math.sin(diff) * absf)
	end
end

local function bcalcview( ply, origin, angl, fov )
	if clientsidenoclip:GetBool() && ghostpos != nil then
		local view = {}
		view.origin = ghostpos
		return view
	end
	
	ghostpos = origin
	
	iZoom = math.Clamp( iZoom + ( iZoomAdd * 140 * FrameTime() ), 0, 80 )
	
	if state && angles!=Angle(0,0,0) then
		local view={}
		if iZoom > 0 then
			view.fov = 90 - iZoom
		end
		
		angles.r=0
		view.angles= angles
		return view
	end
	
	local view={}
	if iZoom > 0 then
		view.fov = 90 - iZoom
	end
		
	view.angles=ucorrected
	
	if !(GetConVarNumber("gmod_vehicle_viewmode") == 1 && IsValid(LocalPlayer():GetVehicle())) then
		return view
	end
end

// auto-reload
local time = 0

local function bautoreload()

	if LocalPlayer():GetActiveWeapon() && time-CurTime()<=0 then

		if LocalPlayer():Alive() && LocalPlayer():GetActiveWeapon():IsValid() then
			local ammo = LocalPlayer():GetActiveWeapon():Clip1()
			if ammo == 0 then
				time = CurTime()+4
				oldRCC("+reload")
				timer.Simple(.01, oldRCC, "-reload")
			end
		end

	end

end
/*
hook.Add("HUDPaint","BaconBotHud",function()
	local EnP = Vector(0,0,0)
	local Text=""
	local Colora = Color(0,0,0,0)
	if state && SelectTarget()!=LocalPlayer() then
		Text = ScanningFoundText
		Colora = Color(0,255,0,255)
		target = SelectTarget()
	if target:IsNPC() || target:IsPlayer() then
		local mod = target:LookupAttachment("eyes")
		if mod != 0 then
			EnP = target:GetAttachment(mod).Pos
		end
		if string.find(string.lower(target:GetModel()),"zombie/fast") || string.find(string.lower(target:GetModel()),"manhack") then
			EnP = target:GetAttachment(2).Pos
		end
		if string.find(string.lower(target:GetModel()),"crab") || string.find(string.lower(target:GetModel()),"crow") || string.find(string.lower(target:GetModel()),"pigeon") || string.find(string.lower(target:GetModel()),"roller") || string.find(string.lower(target:GetModel()),"seagull") then
			EnP = target:GetPos() + Vector(0,0,9)
		end
		if string.find(string.lower(target:GetModel()),"hunter") || string.find(string.lower(target:GetModel()),"antlionguard") then
			EnP = target:GetPos() + Vector(0,0,73)
		end
		if string.find(string.lower(target:GetModel()),"antlion") && !string.find(string.lower(target:GetModel()),"antlionguard") then
			EnP = target:GetPos() + Vector(0,0,25)
		end
	else
		EnP = target:GetPos()+target:OBBCenter()
	end
elseif state then
	Text = ScanningText
	Colora = Color(255,0,0,255)
end
if state then
	local sound = sf:GetInt()
	draw.DrawText(Text, "ScoreboardText", ScrW() / 2, ScrH()/2+50, Colora,1)
	if Text == ScanningText then
		surface.SetDrawColor( 255, 0, 0, 255 )
		surface.DrawLine( (ScrW()/2-10)+math.sin(CurTime()*5)*20, ScrH()/2+67,(ScrW()/2+10)+math.sin(CurTime()*5)*20,ScrH()/2+67)
		if timea<=CurTime() && sound==1 then
			ScanSound:Play()
			timea=CurTime()+1
			timer.Simple(0.9,function() ScanSound:Stop() end)
		end
	else
			ScanSound:Stop()
			if timeb<=CurTime() && sound==1 then
				LockSound:Play()
				timeb=CurTime()+0.3
				timer.Simple(0.25,function() LockSound:Stop() end)
			end
			surface.SetDrawColor( 255, 255, 255, 255 )
			local pos = EnP:ToScreen()
			--surface.DrawOutlinedRect(pos.x-5,pos.y-5,10,10)
			surface.SetDrawColor( 0, 255, 0, 122 )
			--surface.DrawRect(pos.x-4, pos.y-4, 9,9)
		end
	end
end)
*/
//**********************************************************___START OF VGUI FOR BACON BOT___**********************************************************
local FriendListL = nil
local PlayerListL = nil
local EntityListL = nil
local EListL = nil
local Mode=Mod:GetInt()
local MouseX=ScrW()/2
local MouseY=ScrH()/2
local MPan
local function BaconBotMenu()
//START OF INIT
gui.SetMousePos(MouseX,MouseY)

MPan = vgui.Create( "DPropertySheet" )
MPan:SetPos( ScrW()/2-185,ScrH()/2-133 )
MPan:SetSize( 370, 267 )
MPan:MakePopup()

//END OF INIT

local NOnlyC
local EOnlyC
local POnlyC

//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________

local function CheckShit(x)
if x==1 then
	NOnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==2 then
	POnlyC:SetValue(0)
	EOnlyC:SetValue(0)
elseif x==3 then
	NOnlyC:SetValue(0)
	POnlyC:SetValue(0)
end
end

//START OF GENERAL
local AnchorPointC = vgui.Create( "DLabel", MPan )
AnchorPointC:SetPos(0,0)
AnchorPointC:SetText("")


MPan:AddSheet( "Aimbot", AnchorPointC, "BaconBot/general", false, false, "Aimbot Settings" )

local Icona = vgui.Create("DImage", AnchorPointC)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(380,237)


local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(4,0)
TListT:SetText("-Target Selection-")
TListT:SetTextColor(Color(0,70,225,255))
TListT:SizeToContents()


POnlyC = vgui.Create("DCheckBox", AnchorPointC)
POnlyC:SetPos(10,14)
POnlyC:SetValue(ToNumFromBool(Plyo:GetBool()))
POnlyC.DoClick=function()
	POnlyC:SetValue(ToNumFromBool(!Plyo:GetBool()))
	CheckShit(1)
	oldRCC("Bacon_Plyonly",ToNumFromBool(!Plyo:GetBool()))
	oldRCC("Bacon_Entonly",0)
	oldRCC("Bacon_NPConly",0)
end
local POnlyT = vgui.Create( "DLabel", AnchorPointC)
POnlyT:SetPos(26,10)
POnlyT:SetText("Player Only")
POnlyT:SetTextColor(Color(225,225,225,225))


NOnlyC = vgui.Create("DCheckBox", AnchorPointC)
NOnlyC:SetPos(10,28)
NOnlyC:SetValue(ToNumFromBool(NPCo:GetBool()))
NOnlyC.DoClick=function()
	NOnlyC:SetValue(ToNumFromBool(!NPCo:GetBool()))
	CheckShit(2)
	oldRCC("Bacon_NPConly",ToNumFromBool(!NPCo:GetBool()))
	oldRCC("Bacon_Entonly",0)
	oldRCC("Bacon_Plyonly",0)
end
local NOnlyT = vgui.Create( "DLabel", AnchorPointC)
NOnlyT:SetPos(26,24)
NOnlyT:SetText("NPC Only")
NOnlyT:SetTextColor(Color(225,225,225,225))


EOnlyC = vgui.Create("DCheckBox", AnchorPointC)
EOnlyC:SetPos(10,42)
EOnlyC:SetValue(ToNumFromBool(Ento:GetBool()))
EOnlyC.DoClick=function()
	CheckShit(3)
	EOnlyC:SetValue(ToNumFromBool(!Ento:GetBool()))
	oldRCC("Bacon_Entonly",ToNumFromBool(!Ento:GetBool()))
	oldRCC("Bacon_NPConly",0)
	oldRCC("Bacon_Plyonly",0)
end


local EOnlyT = vgui.Create( "DLabel", AnchorPointC)
EOnlyT:SetPos(26,38)
EOnlyT:SetText("Entity Only")
EOnlyT:SetTextColor(Color(225,225,225,225))

local TListT = vgui.Create( "DLabel", AnchorPointC)
TListT:SetPos(100,0)
TListT:SetText("-Anti-Detection-")
TListT:SetTextColor(Color(0,200,40,255))
TListT:SizeToContents()


local AntiSC = vgui.Create("DCheckBoxLabel", AnchorPointC)
AntiSC:SetPos(105,14)
AntiSC:SetConVar( "Bacon_AntiSnap" )
local AntiST = vgui.Create( "DLabel", AnchorPointC)
AntiST:SetPos(120,10)
AntiST:SetText("Anti-Snap")
AntiST:SetTextColor(Color(225,225,225,225))


local AntiFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
AntiFC:SetPos(105,29)
AntiFC:SetConVar( "Bacon_RestrictFOV" )
local AntiFT = vgui.Create( "DLabel", AnchorPointC)
AntiFT:SetPos(120,25)
AntiFT:SetText("Restrict FOV")
AntiFT:SetTextColor(Color(225,225,225,225))


local FFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
FFC:SetPos(10,56)
FFC:SetConVar( "Bacon_ff" )
FFC:SetValue(friendlyfire:GetInt())
local FFT = vgui.Create( "DLabel", AnchorPointC)
FFT:SetPos(26,52)
FFT:SetText("Friendly Fire")
FFT:SetTextColor(Color(225,225,225,225))

local SFC = vgui.Create("DCheckBoxLabel", AnchorPointC)
SFC:SetPos(10,71)
SFC:SetConVar( "Bacon_ignore_steamfriends" )
local SFT = vgui.Create( "DLabel", AnchorPointC)
SFT:SetPos(26,70)
SFT:SetText("Ignore Steam Friends")
SFT:SizeToContents()
SFT:SetTextColor(Color(225,225,225,225))

-- Misc Checkboxes --

local MiscT = vgui.Create( "DLabel", AnchorPointC)
MiscT:SetPos(114,95)
MiscT:SetText("-Miscellaneous Scripts-")
MiscT:SetTextColor(Color(255,10,10,255))
MiscT:SizeToContents()

local TBC = vgui.Create("DCheckBoxLabel", AnchorPointC)
TBC:SetPos(90,110)
TBC:SetConVar( "Bacon_Trigger_Bot" )
TBC:SetValue(triggertoggle:GetInt())
local TBT = vgui.Create( "DLabel", AnchorPointC)
TBT:SetPos(106,106)
TBT:SetText("Trigger-Bot")
TBT:SetTextColor(Color(225,225,225,225))

local TAR = vgui.Create("DCheckBoxLabel", AnchorPointC)
TAR:SetPos(90,125)
TAR:SetConVar( "bacon_autoreload" )
TAR:SetValue(autoreload:GetInt())
local TART = vgui.Create( "DLabel", AnchorPointC)
TART:SetPos(106,121)
TART:SetText("Auto Reload")
TART:SetTextColor(Color(225,225,225,225))

local SPINBOTGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
SPINBOTGUI:SetPos(90,140)
SPINBOTGUI:SetConVar( "Bacon_spinbot" )
local SPINBOTGUIL = vgui.Create( "DLabel", AnchorPointC)
SPINBOTGUIL:SetPos(106,139)
SPINBOTGUIL:SetText("Spinbot")
SPINBOTGUIL:SizeToContents()
SPINBOTGUIL:SetTextColor(Color(225,225,225,225))

local BHOPGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
BHOPGUI:SetPos(180,110)
BHOPGUI:SetConVar( "Bacon_bhop" )
local BHOPL = vgui.Create( "DLabel", AnchorPointC)
BHOPL:SetPos(196,106)
BHOPL:SetText("Bunny Hop")
BHOPL:SetTextColor(Color(225,225,225,225))

local NCGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
NCGUI:SetPos(180,125)
NCGUI:SetConVar( "bacon_namechange" )
NCGUI:SetValue(namechange:GetInt())
local NCGUIL = vgui.Create( "DLabel", AnchorPointC)
NCGUIL:SetPos(196,124)
NCGUIL:SetText("Name Changer")
NCGUIL:SizeToContents()
NCGUIL:SetTextColor(Color(225,225,225,225))

local CLIENTNOCLIPGUI = vgui.Create("DCheckBoxLabel", AnchorPointC)
CLIENTNOCLIPGUI:SetPos(180,140)
CLIENTNOCLIPGUI:SetConVar( "bacon_clientnoclip" )
CLIENTNOCLIPGUI:SetValue(clientsidenoclip:GetInt())
local CLIENTNOCLIPGUIL = vgui.Create( "DLabel", AnchorPointC)
CLIENTNOCLIPGUIL:SetPos(196,140)
CLIENTNOCLIPGUIL:SetText("Client Spectate")
CLIENTNOCLIPGUIL:SizeToContents()
CLIENTNOCLIPGUIL:SetTextColor(Color(225,225,225,225))

local BMWGUI = vgui.Create("DCheckBox", AnchorPointC)
BMWGUI:SetPos(270,170)
BMWGUI:SetConVar( "Bacon_TMW" )
BMWGUI:SetValue(bmw:GetInt())
local BMWGUIL = vgui.Create( "DLabel", AnchorPointC)
BMWGUIL:SetPos(286,169)
BMWGUIL:SetText("Mini Window")
BMWGUIL:SizeToContents()
BMWGUIL:SetTextColor(Color(225,225,225,225))

BMWGUI.DoClick=function(pnl)
	pnl:Toggle()
	
	if pnl:GetChecked() then
		BaconMiniWindow()
	else
		MMPan:Remove()
	end
end

local LOCKL = vgui.Create( "DLabel", AnchorPointC )
LOCKL:SetPos( 5, 195 )
LOCKL:SetText("-Targeting Priority-")
LOCKL:SizeToContents()
LOCKL:SetTextColor(Color(255,204,80,225))

local LockOnL
local function LockOnListA()
	local types = {"Crosshair", "Distance", "Lowest HP", "Deadliest", "Aim Assistance"}
	
	LockOnL = vgui.Create("DButton", AnchorPointC )
	LockOnL:SetText( types[Mod:GetInt()] )
	LockOnL:SetPos( 5, 210 )
	LockOnL:SetSize( 90, 20 )
	LockOnL.DoClick = function ( btn )
		local MenuButtonOptions = DermaMenu() 
		MenuButtonOptions:AddOption("Crosshair", function() oldRCC("Bacon_Mode",1) LockOnL:SetText( types[1] ) end ) 
		MenuButtonOptions:AddOption("Distance", function() oldRCC("Bacon_Mode",2) LockOnL:SetText( types[2] )  end )
		MenuButtonOptions:AddOption("Lowest HP", function() oldRCC("Bacon_Mode",3) LockOnL:SetText( types[3] ) end )
		MenuButtonOptions:AddOption("Deadliest", function() oldRCC("Bacon_Mode",4) LockOnL:SetText( types[4] ) end )
		MenuButtonOptions:AddOption("Aim Assistance", function() oldRCC("Bacon_Mode",5) LockOnL:SetText( types[5] ) end )
		MenuButtonOptions:Open() 
	end

end
LockOnListA()



local Icon = vgui.Create("DImage", AnchorPointC)
Icon:SetMaterial(Material("BaconBot/Logo"))
Icon:SetPos(167,-63)
Icon:SetSize(200,200)

local HEIGHTL = vgui.Create( "DLabel", AnchorPointC )
HEIGHTL:SetPos( 116,175 )
HEIGHTL:SetText("-Aimbot Targeting Area-")
HEIGHTL:SizeToContents()
HEIGHTL:SetTextColor(Color(225,100,20,225))


local SetHeight = vgui.Create( "DNumSlider", AnchorPointC )
SetHeight:SetPos( 100,190 )
SetHeight:SetSize( 150, 100 ) -- Keep the second number at 100
SetHeight:SetText( "     <Head - Nuts>" )
SetHeight:SetMin( 0 ) -- Minimum number of the slider
SetHeight:SetMax( 33 ) -- Maximum number of the slider
SetHeight:SetDecimals( 1 ) -- Sets a decimal. Zero means its a whole number
SetHeight:SetConVar( "bacon_lockY" ) -- Set the convar


local cheatsbutton = vgui.Create( "DButton", AnchorPointC )
cheatsbutton:SetPos(255,210)
cheatsbutton:SetText("Toggle sv_cheats")
cheatsbutton:SetSize(100,20)
cheatsbutton.DoClick = function()
	if CVARMETAGETINT(svcheats) != 0 then
		ForceConVar(CreateConVar("sv_cheats", ""), "0")
		print("sv_cheats turned off")
	else
		ForceConVar(CreateConVar("sv_cheats", ""), "1")
		print("sv_cheats turned on")
	end
end

local spambutton = vgui.Create( "DButton", AnchorPointC )
spambutton:SetPos(255,190)
spambutton:SetText("BB Spammer")
spambutton:SetSize(100,20)
spambutton.DoClick = function()
	SpawnVGUISPAM()
end

local Title = vgui.Create("DLabel",AnchorPointC)
Title:SetPos(165,220)
Title:SetText("")
Title:SizeToContents()

//END OF GENERAL



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF FRIENDS LIST!!!!!!
local AnchorPointA = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

MPan:AddSheet( "Friends", AnchorPointA, "BaconBot/friends", false, false, "Aimbot Friends" )

local Icona = vgui.Create("DImage", AnchorPointA)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(380,237)

local FriendListT = vgui.Create( "DLabel", AnchorPointA )
FriendListT:SetPos(40,5)
FriendListT:SetText("Friends - Current")
FriendListT:SizeToContents()
FriendListT:SetTextColor(Color(255,255,255,255))

local FriendListL
local function FriendsListA()
	FriendListL = vgui.Create( "DComboBox", AnchorPointA )
	FriendListL:SetPos( 10, 25 )
	FriendListL:SetSize( 150, 190 )
	FriendListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetFriends() then friendslist=BFS.GetFriends() else friendslist={} end
	for k,v in pairs(friendslist) do
		FriendListL:AddItem(v) -- Add our options
	end
end
FriendsListA()


local FriendListB = vgui.Create( "DButton", AnchorPointA )
FriendListB:SetPos(20,215)
FriendListB:SetText("Remove from friends")
FriendListB:SetSize(120,20)
FriendListB.DoClick = function()
	local temptable = {}
	if #FriendListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(FriendListL:GetSelectedItems()) do
		for c,d in pairs(friendslist) do
			if b:GetValue()==d then
				if #friendslist==0 then friendslist={} end
				table.remove(friendslist,c)
				table.insert(temptable,b:GetValue())
			end
		end
	end
	BFS.SetFriends(friendslist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	PlayerListA()
	FriendsListA()
end


local PlayerListT = vgui.Create( "DLabel", AnchorPointA )
PlayerListT:SetPos(250,5)
PlayerListT:SetText("Players List")
PlayerListT:SizeToContents()
PlayerListT:SetTextColor(Color(255,255,255,255))

local PlayerListL
PlayerListA = function()
	PlayerListL = vgui.Create( "DComboBox", AnchorPointA )
	PlayerListL:SetPos( 200, 25 )
	PlayerListL:SetSize( 150, 190 )
	PlayerListL:SetMultiple(true)
	for k,v in pairs(player.GetAll()) do
		if !table.HasValue(friendslist,v:Name()) && v!=LocalPlayer() then
			PlayerListL:AddItem(v:Name()) -- Add our options
		end
	end
end
PlayerListA()


local PlayerListB = vgui.Create( "DButton", AnchorPointA )
PlayerListB:SetPos(240,215)
PlayerListB:SetSize(80,20)
PlayerListB:SetText("Add to friends")
PlayerListB.DoClick = function()
	local temptable = {}
	if #PlayerListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(PlayerListL:GetSelectedItems()) do
		table.insert(friendslist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetFriends(friendslist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	PlayerListA()
	FriendsListA()
end
//END OF FRIENDS LIST!!!!!!



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________



//START OF ENTITIES LIST!!!!!!
local AnchorPointB = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

MPan:AddSheet( "Aim Ents", AnchorPointB, "BaconBot/ent_add", false, false, "Aimbot Entities" )

local Icona = vgui.Create("DImage", AnchorPointB)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(380,237)

local EntityListT = vgui.Create( "DLabel", AnchorPointB )
EntityListT:SetPos(40,5)
EntityListT:SetText("Entities - Current")
EntityListT:SizeToContents()
EntityListT:SetTextColor(Color(255,255,255,255))


local EntityListL
local function EntityListA()
	EntityListL = vgui.Create( "DComboBox", AnchorPointB )
	EntityListL:SetPos( 10, 25 )
	EntityListL:SetSize( 150, 190 )
	EntityListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetEnts() then lockonlist=BFS.GetEnts() else lockonlist={} end
	for k,v in pairs(lockonlist) do
		EntityListL:AddItem(v) -- Add our options
	end
end
EntityListA()


local EntityListB = vgui.Create( "DButton", AnchorPointB )
EntityListB:SetPos(20,215)
EntityListB:SetText("Remove from entities")
EntityListB:SetSize(120,20)
EntityListB.DoClick = function()
	local temptable = {}
	if #EntityListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EntityListL:GetSelectedItems()) do
		for c,d in pairs(lockonlist) do
			if string.lower(b:GetValue())==string.lower(d) then
				local lost=table.remove(lockonlist,c)
				table.insert(temptable,lost)
			end
		end
	end
	BFS.SetEnts(lockonlist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	EntityListA()
	EListA()
end


local EListT = vgui.Create( "DLabel", AnchorPointB )
EListT:SetPos(235,5)
EListT:SetText("Active Entities List")
EListT:SizeToContents()
EListT:SetTextColor(Color(255,255,255,255))

local EListL
EListA = function()
	EListL = vgui.Create( "DComboBox", AnchorPointB )
	EListL:SetPos( 200, 25 )
	EListL:SetSize( 150, 190 )
	EListL:SetMultiple(true)
	local tempents = {}
	for k,v in pairs(ents.GetAll()) do
		if IsValid(v) && !table.HasValue(tempents,v:GetClass()) && !table.HasValue(lockonlist,v:GetClass()) then
			table.insert(tempents,v:GetClass())
		end
	end
	for g,h in pairs(tempents) do
		if h=="prop_physics" then
			ThePropList=EListL:AddItem(h)
			ThePropList.OnMousePressed=function(a,b)
			if b==108 then
				local MenuButtonOptions = DermaMenu()
				local temptablec = {}
				local temptabled = {}
				for k,v in pairs(ents.FindByClass("prop_physics")) do
					if !table.HasValue(temptablec,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) && !table.HasValue(lockonlist,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						table.insert(temptablec, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl",""))
						table.insert(temptabled,v:GetModel())
					end
				end
				for i,c in pairs(temptablec) do
					local mover = vgui.Create( "DMenuOption", MenuButtonOptions)
					mover:SetText(c)
					local icon
					mover.OnCursorEntered=function() icon=vgui.Create("SpawnIcon") icon:SetModel(temptabled[i]) icon.DoClick=function() icon:Remove() end local c,d = mover:GetPos() local a,b = MenuButtonOptions:GetPos() icon:SetPos(a+mover:GetWide(),b+d) end
					mover.OnCursorExited=function() icon:Remove() end
					mover.DoRightClick=function() icon:Remove() end
					mover.DoClick=function()
					table.insert(lockonlist,c)
					BFS.SetEnts(lockonlist)
					EListA()
					EntityListA()
					LocalPlayer():ChatPrint("Added: "..c)
					icon:Remove()
					end
					MenuButtonOptions:AddPanel(mover)
				end
				MenuButtonOptions:Open()
			else
				EListL:SelectByName( "prop_physics" )
			end
			end
		else
			EListL:AddItem(h) -- Add our options
		end
	end
end
EListA()
local EListB = vgui.Create( "DButton", AnchorPointB )
EListB:SetPos(240,215)
EListB:SetSize(80,20)
EListB:SetText("Add to entities")
EListB.DoClick = function()
	local temptable = {}
	if #EListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EListL:GetSelectedItems()) do
		table.insert(lockonlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetEnts(lockonlist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	EListA()
	EntityListA()
end
//END OF ENTITIES LIST!!!!!!



//SPACE DIVIDER!!!!!!!!__________________________________________________________________________________________________________________________________


//START OF ESP TAB!!!!!!
local AnchorPointD = vgui.Create( "DLabel", MPan )
AnchorPointD:SetPos(0,0)
AnchorPointD:SetText("")

MPan:AddSheet( "ESP", AnchorPointD, "BaconBot/radar", false, false, "ESP Menu" )

local Icona = vgui.Create("DImage", AnchorPointD)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(380,237)

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10, 30 )
CheckBoxThing:SetConVar( "espplayeron" )
CheckBoxThing:SetValue( playeron:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26, 29 )
CheckBoxThing2:SetText( "Players" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local MenuButton = vgui.Create("DButton", AnchorPointD)
MenuButton:SetText( "Mode >" )
MenuButton:SetPos(10, 10)
MenuButton:SetSize(50, 15)
MenuButton.DoClick = function ( btn )
 local MenuButtonOptions = DermaMenu() // Creates the menu
 MenuButtonOptions:AddOption("Simple", function() oldRCC("espmode","0") end ) // Add options to the menu
 MenuButtonOptions:AddOption("Normal", function() oldRCC("espmode","1") end )
 MenuButtonOptions:AddOption("Advanced", function() oldRCC("espmode","2") end )
 MenuButtonOptions:Open() // Open the menu AFTER adding your options
end 

local MenuButton = vgui.Create("DButton", AnchorPointD)
MenuButton:SetText( "ESP Crosshair >" )
MenuButton:SetPos(10, 170)
MenuButton:SetSize(100, 15)
MenuButton.DoClick = function ( btn )
 local MenuButtonOptions = DermaMenu() // Creates the menu
 MenuButtonOptions:AddOption("Box", function() oldRCC("espcross","0") end ) // Add options to the menu
 MenuButtonOptions:AddOption("Cross", function() oldRCC("espcross","1") end )
 MenuButtonOptions:AddOption("|_", function() oldRCC("espcross","2") end )
 MenuButtonOptions:Open() // Open the menu AFTER adding your options
end 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos(10, 50)
CheckBoxThing:SetConVar("espitemon")
CheckBoxThing:SetValue(itemon:GetInt())
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos(26, 49)
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SetText("Items")
CheckBoxThing2:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,70 )
CheckBoxThing:SetConVar( "espvehicleon" )
CheckBoxThing:SetValue( vehicleon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,69 )
CheckBoxThing2:SetText( "Vehicles" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,90 )
CheckBoxThing:SetConVar( "espnpcon" )
CheckBoxThing:SetValue( npcon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,89 )
CheckBoxThing2:SetText( "NPCs" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,110 )
CheckBoxThing:SetConVar( "espweaponon" )
CheckBoxThing:SetValue( weaponon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,109 )
CheckBoxThing2:SetText( "Weapons" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,130 )
CheckBoxThing:SetConVar( "darkrp" )
CheckBoxThing:SetValue( darkrp:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,129 )
CheckBoxThing2:SetText( "DarkRP" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", AnchorPointD)
CheckBoxThing:SetPos( 10,150 )
CheckBoxThing:SetConVar( "espunhideon" )
CheckBoxThing:SetValue( unhideon:GetInt() )
local CheckBoxThing2 = vgui.Create( "DLabel", AnchorPointD)
CheckBoxThing2:SetPos( 26,149 )
CheckBoxThing2:SetText( "Show Invisble Props" )
CheckBoxThing2:SetTextColor(Color(225,225,225,225))
CheckBoxThing2:SizeToContents()

local Icon = vgui.Create("DModelPanel", AnchorPointD)
Icon:SetModel(LocalPlayer():GetModel())
Icon:SetAnimated(true)
Icon:SetPos(157,36)
Icon:SetSize(175,175)
Icon.Entity:SetPos(Icon.Entity:GetPos()+Vector(-10,0,0))

local Painted = vgui.Create("DLabel", AnchorPointD)
Painted:SetPos(115,0)
Painted:SetSize(250,250)
Painted:SetText("")
Painted.Paint=function()
local x=140
local y=55
local MMode=cross:GetInt()
local playeron = playeron:GetInt()
local itemon = itemon:GetInt()
local vehicleon = vehicleon:GetInt()
local npcon = npcon:GetInt()
local weaponon = weaponon:GetInt()
local trans = trans:GetInt()
local darkrp = darkrp:GetInt()
local mode = mode:GetInt()
surface.SetDrawColor(0,255,0,255)
if (MMode==0) then
	surface.DrawLine(x-40,y-15,x+40,y-15)
	surface.DrawLine(x-40,y-15,x-40,y+150)
	surface.DrawLine(x-40,y+150,x+40,y+150)
	surface.DrawLine(x+40,y-15,x+40,y+150)
elseif (MMode==1) then
	surface.DrawLine(x,y-5,x,y+5)
	surface.DrawLine(x-5,y,x+5,y)
else
	surface.DrawLine(x,y,x,y-20)
	surface.DrawLine(x,y,x+20,y)
end
v=LocalPlayer()
local mod = v:GetModel()
ateam = v:Team()
color = team.GetColor(ateam)
color.r, color.g, color.b, color.a = color.r, color.g, color.b, trans
if v:InVehicle() then
	colora = Color(255,255,255,trans)
else
	colora = color
end
local weapon="NONE"
if v:Alive() && !v:InVehicle() && v:GetActiveWeapon( ) && (!string.find(v:GetModel(),"Antlion") && !string.find(v:GetModel(),"player.mdl")) && !Sass then
	if v:Alive() && v:GetActiveWeapon():IsValid() then
		weapon=v:GetActiveWeapon( ):GetPrintName()
		weapon=string.Replace(weapon,"#HL2_","")
		weapon=string.Replace(weapon,"#GMOD_","")
	end
else
	weapon="NONE"
end
hp = v:Health()
name = v:Name()
gpos = v:EyePos():ToScreen()
dist = math.Round(v:EyePos():Distance(LocalPlayer():EyePos()))
local ads = admincheck(v)
if mode==2 then
	tn=team.GetName(ateam)
	draw.SimpleText(hp.."   W: "..weapon, "Default", x+15, y-35, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-33, colora,0,0)
	draw.SimpleText(""..name.."", "Default", x+1, y-45, colora,0,0)
	draw.SimpleText(""..tn.."","Default", x+3, y-15, colora,0,0)
	draw.SimpleText("Dist:1337","Default", x+3, y-25, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-55, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
elseif mode==0 then
	draw.SimpleText(""..name.."", "Default", x+3, y-25, colora,0,0)
	draw.SimpleText(hp,"Default", x+15, y-12, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-10, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-35, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
else
	tn=team.GetName(ateam)
	draw.SimpleText(""..name.."", "Default", x+3, y-35, colora,0,0)
	draw.SimpleText(hp,"Default", x+15, y-25, colora,0,0)
	draw.SimpleText(""..tn.."","Default", x+3, y-15, colora,0,0)
	draw.SimpleText("F","Signs", x+1, y-23, colora,0,0)
	draw.SimpleText(""..ads.."","Default", x+3, y-45, Color(255,0,0,trans),0,0)
	DrawCrosshair(v)
end
end


local NumSliderThingy = vgui.Create( "DNumSlider", AnchorPointD )
NumSliderThingy:SetPos( 10,190 )
NumSliderThingy:SetSize( 150, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "ESP Transparency" )
NumSliderThingy:SetMin( 100 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 255 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means its a whole number
NumSliderThingy:SetConVar( "esptrans" )

local TBC = vgui.Create("DCheckBoxLabel", AnchorPointD)
TBC:SetPos(90,30)
TBC:SetConVar( "Bacon_Chams" )
local TBT = vgui.Create( "DLabel", AnchorPointD)
TBT:SetPos(106,26)
TBT:SetText("Entity Chams")
TBT:SetTextColor(Color(225,225,225,225))

local CHAMS2C = vgui.Create("DCheckBoxLabel", AnchorPointD)
CHAMS2C:SetPos(90, 50)
CHAMS2C:SetConVar( "bacon_chams2" )

function CHAMS2C:OnChange(value)
	SetChams2(value)
end

local CHAMS2L = vgui.Create( "DLabel", AnchorPointD)
CHAMS2L:SetPos(106, 46)
CHAMS2L:SetWide(CHAMS2L:GetWide() + 20)
CHAMS2L:SetText("Entity Chams 2")
CHAMS2L:SetTextColor(Color(255,255,255,255))


local ALC = vgui.Create("DCheckBoxLabel", AnchorPointD)
ALC:SetPos(90,70)
ALC:SetConVar( "Bacon_adminlist" )
local ALT = vgui.Create( "DLabel", AnchorPointD)
ALT:SetPos(106,66)
ALT:SetText("Admin List")
ALT:SetTextColor(Color(225,225,225,225))

local BCCC = vgui.Create("DCheckBoxLabel", AnchorPointD)
BCCC:SetPos(90,90)
BCCC:SetConVar( "bacon_crosshud" )
local BCCCL = vgui.Create( "DLabel", AnchorPointD)
BCCCL:SetPos(106,86)
BCCCL:SetWide(BCCCL:GetWide() + 5)
BCCCL:SetText("Box Crosshair")
BCCCL:SetTextColor(Color(225,225,225,225))

//END OF ESP TAB!!!!!!!






//START OF ESP ENTITIES LIST!!!!!!!!

local AnchorPointE = vgui.Create( "DLabel", MPan )
AnchorPointA:SetPos(0,0)
AnchorPointA:SetText("")

MPan:AddSheet( "ESP Ents", AnchorPointE, "BaconBot/esp_list", false, false, "ESP Entities" )

local Icona = vgui.Create("DImage", AnchorPointE)
Icona:SetMaterial(Material("BaconBot/BBBackground.vtf"))
Icona:SetPos(0,0)
Icona:SetSize(380,237)


local ESPEntityListT = vgui.Create( "DLabel", AnchorPointE )
ESPEntityListT:SetPos(40,5)
ESPEntityListT:SetText("Entities - Current")
ESPEntityListT:SizeToContents()
ESPEntityListT:SetTextColor(Color(255,255,255,255))

local ESPEntityListL
local function ESPEntityListA()
	ESPEntityListL = vgui.Create( "DComboBox", AnchorPointE )
	ESPEntityListL:SetPos( 10, 25 )
	ESPEntityListL:SetSize( 150, 190 )
	ESPEntityListL:SetMultiple(true) -- Dont use this unless you know extensive knowledge about tables
	if BFS.GetESPEnts() then entlist=BFS.GetESPEnts() else entlist={} end
	for k,v in pairs(entlist) do
		ESPEntityListL:AddItem(v) -- Add our options
	end
end
ESPEntityListA()


local ESPEntityListB = vgui.Create( "DButton", AnchorPointE )
ESPEntityListB:SetPos(20,215)
ESPEntityListB:SetText("Remove from entities")
ESPEntityListB:SetSize(120,20)
ESPEntityListB.DoClick = function()
	local temptable = {}
	if #ESPEntityListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(ESPEntityListL:GetSelectedItems()) do
		for c,d in pairs(entlist) do
			if string.lower(b:GetValue())==string.lower(d) then
				local lost=table.remove(entlist,c)
				table.insert(temptable,lost)
			end
		end
	end
	BFS.SetESPEnts(entlist)
	LocalPlayer():ChatPrint("Removed: "..table.concat(temptable,", "))
	ESPEntityListA()
	EListA()
end


local EListT = vgui.Create( "DLabel", AnchorPointE )
EListT:SetPos(235,5)
EListT:SetText("Active Entities List")
EListT:SizeToContents()
EListT:SetTextColor(Color(255,255,255,255))

local EESPListL
local function EESPListA()
	EESPListL = vgui.Create( "DComboBox", AnchorPointE )
	EESPListL:SetPos( 200, 25 )
	EESPListL:SetSize( 150, 190 )
	EESPListL:SetMultiple(true)
	local tempents = {}
	for k,v in pairs(ents.GetAll()) do
		if IsValid(v) && !table.HasValue(tempents,v:GetClass()) && !table.HasValue(entlist,v:GetClass()) then
			table.insert(tempents,v:GetClass())
		end
	end
	for g,h in pairs(tempents) do
		if h=="prop_physics" then
			ThePropList=EESPListL:AddItem(h)
			ThePropList.OnMousePressed=function(a,b)
			if b==108 then
				local MenuButtonOptions = DermaMenu()
				local temptablec = {}
				local temptabled = {}
				for k,v in pairs(ents.FindByClass("prop_physics")) do
					if !table.HasValue(temptablec,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) && !table.HasValue(entlist,string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl","")) then
						table.insert(temptablec, string.Replace(string.Replace(string.GetFileFromFilename(v:GetModel()),"/",""),".mdl",""))
						table.insert(temptabled,v:GetModel())
					end
				end
				for i,c in pairs(temptablec) do
					local mover = vgui.Create( "DMenuOption", MenuButtonOptions)
					mover:SetText(c)
					local icon
					mover.OnCursorEntered=function() icon=vgui.Create("SpawnIcon") icon:SetModel(temptabled[i]) icon.DoClick=function() icon:Remove() end local c,d = mover:GetPos() local a,b = MenuButtonOptions:GetPos() icon:SetPos(a+mover:GetWide(),b+d) end
					mover.OnCursorExited=function() icon:Remove() end
					mover.DoRightClick=function() icon:Remove() end
					mover.DoClick=function()
					table.insert(entlist,c)
					BFS.SetESPEnts(entlist)
					EESPListA()
					ESPEntityListA()
					LocalPlayer():ChatPrint("Added: "..c)
					icon:Remove()
					end
					MenuButtonOptions:AddPanel(mover)
				end
				MenuButtonOptions:Open()
			else
				EESPListL:SelectByName( "prop_physics" )
			end
			end
		else
			EESPListL:AddItem(h) -- Add our options
		end
	end
end
EESPListA()
local EListB = vgui.Create( "DButton", AnchorPointE )
EListB:SetPos(240,215)
EListB:SetSize(80,20)
EListB:SetText("Add to entities")
EListB.DoClick = function()
	local temptable = {}
	if #EESPListL:GetSelectedItems()==0 then LocalPlayer():ChatPrint("Please select one or more items please.") return end
	for a,b in pairs(EESPListL:GetSelectedItems()) do
		table.insert(entlist,b:GetValue())
		table.insert(temptable,b:GetValue())
	end
	BFS.SetESPEnts(entlist)
	LocalPlayer():ChatPrint("Added: "..table.concat(temptable,", "))
	EESPListA()
	ESPEntityListA()
end
//END OF ESP ENTITIES LIST!!!!!!



end



local spamchat = false


local propamount = CreateClientConVar( "data_prop", 0, true, false )
local swepamount = CreateClientConVar( "data_swep", 0, true, false )
local sentamount = CreateClientConVar( "data_sent", 0, true, false )
local propmodel = "Prop Model"
local swepmodel = "SWEP Name"
local vehiclemodel = "Vehicle Name"
local npcmodel = "NPC Name"
local sentmodel = "SENT Name"


local function sentspam()
	local sents = sentamount:GetInt() -1
	for i=0,sents do
		oldRCC("gm_spawnsent",sentmodel)
	end
end

local function propspam()
	local props = propamount:GetInt() -1
	for i=0,props do
		oldRCC("gm_spawn",propmodel)
	end
end

local function swepspam()
	local sweps = swepamount:GetInt() -1
	for i=0,sweps do
		oldRCC("gm_spawnswep",swepmodel)
	end
end

SpawnVGUISPAM = function( )

    local DFrame = vgui.Create( "DFrame"); 
    DFrame:SetSize( 265, 375 ); 
    DFrame:SetPos( ScrW()/2,ScrH()/2 );
    DFrame:SetVisible( true );  
    DFrame:MakePopup( );
    DFrame:SetTitle("Spam Here :D")

local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15,45 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(propmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    propmodel=DermaText:GetValue()
end

local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,65 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "Prop Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "data_prop" )
 NumSliderThingy:SetValue( 0 )
   
   
local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15,120 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(swepmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    swepmodel=DermaText:GetValue()
end

local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,140 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "SWEP Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "data_swep" )
NumSliderThingy:SetValue( 0 )



local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15, 195 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(sentmodel)
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
    sentmodel=DermaText:GetValue()
end

local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,215 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "SENT Amount" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "data_sent" )
NumSliderThingy:SetValue( 0 )


local DermaText = vgui.Create( "DTextEntry", DFrame )
DermaText:SetPos( 15, 265 )
DermaText:SetTall(15)
DermaText:SetWide(225)
DermaText:SetValue(chatspam:GetString())
DermaText:SetEnterAllowed( true )
DermaText.OnTextChanged = function()
	oldRCC("bacon_chatspam", DermaText:GetValue())
end

local NumSliderThingy = vgui.Create( "DNumSlider", DFrame )
NumSliderThingy:SetPos( 15,285 )
NumSliderThingy:SetSize( 225, 100 ) -- Keep the second number at 100
NumSliderThingy:SetText( "Chat Spam Interval" )
NumSliderThingy:SetMin( 0 ) -- Minimum number of the slider
NumSliderThingy:SetMax( 100 ) -- Maximum number of the slider
NumSliderThingy:SetDecimals( 0 ) -- Sets a decimal. Zero means it's a whole number
NumSliderThingy:SetConVar( "bacon_chatspam_interval" )
NumSliderThingy:SetValue( 0 )

local MenuButton = vgui.Create("DButton")
MenuButton:SetParent( DFrame )
MenuButton:SetText( "Spam" )
MenuButton:SetPos(93, 325)
MenuButton:SetSize( 65, 35 )
MenuButton.DoClick = function ( btn )
    local MenuButtonOptions = DermaMenu() 
    MenuButtonOptions:AddOption("Props", function() propspam() end ) 
    MenuButtonOptions:AddOption("SWEPs", function() swepspam() end )
    MenuButtonOptions:AddOption("SENTs", function() sentspam() end )
	local x = "Off"
	if spamchat then
		x = "On"
	end
	MenuButtonOptions:AddOption("Chat (Currently " .. x .. ")", function() spamchat = !spamchat end )
    MenuButtonOptions:Open() 
end

end

Commands["SpamTime"] = SpawnVGUISPAM

Commands["+Bacon_Menu"] = BaconBotMenu
Commands["-Bacon_Menu"] = function() MouseX,MouseY=gui.MousePos() MPan:Remove() end

local hosttimescale = GetConVar("host_timescale")

local function SetSpeedHack(ply, cmd, cargs)
	local speed = math.Clamp(tonumber(cargs[1] or 7), 0, 7)

	if CVARMETAGETINT(svcheats) != 1 then
		ForceConVar(CreateConVar("sv_cheats", ""), "1")
	end

	ForceConVar(CreateConVar("host_timescale", ""), tostring(math.Clamp(tonumber(cargs[1] or 7), 0, 7)))
end

Commands["+Bacon_Speed"] = SetSpeedHack
Commands["-Bacon_Speed"] = function() ForceConVar(CreateConVar("host_timescale", ""), "1") end

local BaconModeIcon
local BaconActiveIcon
local BaconTriggerIcon
local BaconRRIcon
local BaconFFIcon

BaconMiniWindow = function()
MMPan = vgui.Create( "DPanel" ) -- Creates the frame itself
MMPan:SetPos( ScrW()/2-65,10 ) -- Position on the players screen
MMPan:SetSize( 130, 100 ) -- Size of the frame
MMPan.Paint = function() -- Paint function
    surface.SetDrawColor( 50, 50, 50, 155 ) -- Set our rect color below us; we do this so you can see items added to this panel
    surface.DrawRect( 0, 0, MMPan:GetWide(), MMPan:GetTall() ) -- Draw the rect
	draw.SimpleText("Aimbot:", "MiniFont",15,10, Color(255,255,255,155),0,0)
	draw.SimpleText("Friendly Fire:", "MiniFont",15,30, Color(255,255,255,155),0,0)
	draw.SimpleText("Trigger Bot:", "MiniFont",15,50, Color(255,255,255,155),0,0)
	draw.SimpleText("Mode:", "MiniFont",15,70, Color(255,255,255,155),0,0)
	for i=0,5 do
		surface.SetDrawColor(i/5*255,0,0,155)
		surface.DrawOutlinedRect(0+i,0+i,MMPan:GetWide()-i-i, MMPan:GetTall()-i-i)
	end
	for i=0,5 do
		surface.SetDrawColor(((5-i)/5)*255,0,0,155)
		surface.DrawOutlinedRect(0+i+5,0+i+5,MMPan:GetWide()-i-i-10, MMPan:GetTall()-i-i-10)
	end
end
local toggle = tobool(triggertoggle:GetInt())
local olda = Mod:GetInt()
local oldb = tostring(state)
local oldc = tostring(toggle)
local oldd = tostring(friendlyfire:GetBool())


BaconModeIcon = vgui.Create("DImage", MMPan)
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
BaconModeIcon:SetPos(60,72)
BaconModeIcon:SetSize(32,16)
BaconModeIcon:SetImageColor(Color(255,255,255,155))
BaconModeIcon.Think=function()
if olda!=Mod:GetInt() then
olda=Mod:GetInt()
BaconModeIcon:SetMaterial(Material("BaconBot/mode_"..Mod:GetInt()))
end
end

BaconActiveIcon = vgui.Create("DImage", MMPan)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
BaconActiveIcon:SetPos(70,12)
BaconActiveIcon:SetSize(16,16)
BaconActiveIcon:SetImageColor(Color(255,255,255,155))
BaconActiveIcon.Think=function()
if oldb!=tostring(state) then
oldb=tostring(state)
BaconActiveIcon:SetMaterial(Material("BaconBot/"..tostring(state)))
end
end

BaconTriggerIcon = vgui.Create("DImage", MMPan)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
BaconTriggerIcon:SetPos(95,52)
BaconTriggerIcon:SetSize(16,16)
BaconTriggerIcon:SetImageColor(Color(255,255,255,155))
BaconTriggerIcon.Think=function()
local toggle = tobool(triggertoggle:GetInt())
if oldc!=tostring(toggle) then
oldc=tostring(toggle)
BaconTriggerIcon:SetMaterial(Material("BaconBot/"..tostring(toggle)))
end
end

BaconFFIcon = vgui.Create("DImage", MMPan)
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
BaconFFIcon:SetPos(100,32)
BaconFFIcon:SetSize(16,16)
BaconFFIcon:SetImageColor(Color(255,255,255,155))
BaconFFIcon.Think=function()
if oldd!=tostring(friendlyfire:GetBool()) then
oldd=tostring(friendlyfire:GetBool())
BaconFFIcon:SetMaterial(Material("BaconBot/"..tostring(friendlyfire:GetBool())))
end
end

end

// player_connect ip logger
if not file.Exists("db_steamid_ip.txt") then file.Write("db_steamid_ip.txt","") end
local tblDB = {}
local function SaveDB()
	local s = ""
	for k,v in pairs(tblDB) do
		s = s..k.."="..v.."\n"
	end
	
	if logips:GetBool() then
		file.Write("db_steamid_ip.txt",s)
	end
end
local function LoadDB()
	local tbl = string.Explode("\n",file.Read("db_steamid_ip.txt"))
	tblDB = {}
	for k,v  in pairs(tbl) do
		local sep = string.Explode("=",v)
		if sep and table.getn(sep) == 2 then
			tblDB[sep[1]] = sep[2]
		end
	end
end
LoadDB()

local function PlayerConnect(name, ip)
	tblDB[string.gsub(name,"=","")] = ip
	print("Recorded ip " .. ip .. " for player " .. name)
	SaveDB()
end

Commands["log_getbyname"] = function(ply, cmd, arg)
	LoadDB()
	if arg[1] then
		local strF = string.lower(arg[1])
		for k, v in pairs(tblDB) do
			if string.find(string.lower(k),strF) then
				print(k.." = "..v)
			end
		end
	end
end

Commands["log_list"] = function()
	LoadDB()
	for k,v in pairs(tblDB) do
		print(k.." = "..v)
	end
end

Commands["log_clear"] = function()
	tblDB = {}
	SaveDB()
	print("Client data (mah) harvester logs deleted!")
end

Commands["bacon_commands"] = function()
	for k, v in pairs(Commands) do
		print(k)
	end
end

Commands["Bacon_Toggle_Mini_Window"] = function()
if !bmw:GetBool() then
	BaconMiniWindow()
	oldRCC("Bacon_TMW",1)
else
	MMPan:Remove()
	oldRCC("Bacon_TMW",0)
end
end

local function InitShit()
if MMPan then MMPan:Remove() end
if bmw:GetBool() then
	BaconMiniWindow()
end
end

Commands["bacon_triggerbot_toggle"] = function() oldRCC("bacon_trigger_bot",ToNumFromBool(!tobool(triggertoggle:GetInt()))) end
Commands["bacon_ff_toggle"] = function() oldRCC("bacon_ff",ToNumFromBool(!friendlyfire:GetBool())) end

local myconcmd = nil
local lastspam = 0

local function ThinkGate()
	trigger()
	triggerthis()
	AimbotThink()

	if !IsValid(CL) && IsValid(LocalPlayer()) then
		CL = LocalPlayer()
	end

	if autoreload:GetBool() then
		bautoreload()
	end

	if myconcmd && engineConsoleCommand != myconcmd then
		engineConsoleCommand = myconcmd
	end
	
	if namechange:GetInt() == 1 then
		oldRCC("setinfo", "name", player.GetAll()[math.random(1, #player.GetAll())]:Nick().." ")
	end
	
	local intv = chatspaminterval:GetInt()
	
	if spamchat && ( intv > 0 && RealTime() >= (lastspam + intv) ) then
		local spamstr = chatspam:GetString()
		oldRCC("say", spamstr)
		lastspam = RealTime()
	end
end

if NoSpreadHere then
	Hooks["Initialize"] = {true, Check}
	Hooks["SetupMove"] = {true, mysetupmove}
end
Hooks["CalcView"] = {true, bcalcview}
Hooks["CreateMove"] = {true, bcmove}
Hooks["Think"] = {true, ThinkGate}
Hooks["RenderScreenspaceEffects"] = {true, chams}
Hooks["HUDPaint"] = {true, esp}
Hooks["InitPostEntity"] = {true, InitShit}
Hooks["PlayerTraceAttack"] = {true, btraceattack}
Hooks["PlayerConnect"] = {true, PlayerConnect}

local cmds = {}
for k,v in pairs(Commands) do
	local low = string.lower(k)
	cmds[low] = v
	AddConsoleCommand(low)
end
Commands = cmds

local function bindPressOverride(ply, bind, pressed)
	local bind = string.lower(bind)
	for k,v in pairs(Commands) do
		if string.find(bind, string.lower(k)) then
			return true
		end
	end
	
	return false
end

local origHookCall = hook.Call
local oldHookCall = hook.Call
local recurse = nil
local function newHookCall( name, gm, ... )	
	local myHook = Hooks[name]

	if name == "SendLua" then
		local lua = unpack({...}, 1)
		if logsendlua:GetBool() then
			print("SendLua", lua)
		end
		return
	end
	
	if name == "PlayerBindPress" && bindPressOverride(...) then
		return false
	end

	local rA, rB, rC, rD, rE, rF, rG, rH
	if recurse == name then
		rA, rB, rC, rD, rE, rF, rG, rH = origHookCall(name, gm, ...)
	else
		recurse = name
		rA, rB, rC, rD, rE, rF, rG, rH = oldHookCall(name, gm, ...)
		recurse = nil
	end
	
	if myHook then
		if rA != nil && myHook[1] then
			local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](rA, rB, rC, rD, rE, rF, rG, rH)
			if rA != nil then
				return rA, rB, rC, rD, rE, rF, rG, rH
			end
		else
			local rA, rB, rC, rD, rE, rF, rG, rH = myHook[2](...)
			if rA != nil then
				return rA, rB, rC, rD, rE, rF, rG, rH
			end
		end
	end
	
	return rA, rB, rC, rD, rE, rF, rG, rH
end
local hooktable = table.Copy(hook)
hook = {}
setmetatable(hook, {__index=function(t, k) if k=="Call" then return newHookCall end return hooktable[k] end, __newindex = function(t, k, v) if k=="Call" then print("INFO: gamemode set its own hook.Call") if v != newHookCall then oldHookCall = v end return end hooktable[k] = v end})

local oldEngineConsoleCommand = engineConsoleCommand
function engineConsoleCommand( player, command, arguments )
	if Commands[string.lower(command)] then
		Commands[string.lower(command)](player, command, arguments)
		return true
	end

	return oldEngineConsoleCommand( player, command, arguments )
end
myconcmd = engineConsoleCommand

package.loaded.bbot = nil

debug.getinfo = function()
	print("DEBUG.GETINFO CALLED", debug.traceback())
end

local block = {"bbot", "gmcl_deco", "baconbot", "sv_cheats", "host_timescale", "bacon_toggle"}

RunConsoleCommand = function(str, ...)
	if showcmds:GetBool() || str == "perp_ug" then
		print("RCC", str, ...)
	end

	local whole = str
	for k,x in pairs({...}) do
		whole = whole .. " " .. tostring(x)
	end
	
	for k,v in pairs(Commands) do
		if string.find(whole, k) then
			print("Blocked RCC", str, ...)
			return			
		end
	end
	for k,v in pairs(block) do
		if string.find(whole, v) then
			print("Blocked RCC", str, ...)
			return			
		end
	end

	for k,v in pairs(string.Explode(",", blacklistcmds:GetString())) do
		if string.lower(str) == "cc" || string.lower(str) == "kcheatfound" || string.lower(str) == "_command" || string.lower(str) == "_____varwat" || string.lower(str) == "_log_hook" || string.lower(str) == "_blacklistedhook" || string.lower(str) == "_material" || string.lower(str) == string.lower(v) then
			print("Blocked RCC", str, ...)
			return
		end
	end

	return oldRCC(str, ...)
end

local plymeta = _R.Player
local emeta = _R.Entity
local oldGetMaterial = emeta.GetMaterial
function emeta.GetMaterial(ply)
	local mat = oldGetMaterial(ply)
	if string.lower(mat) == "baconbot/living" then return "" end
	return mat
end

local oldCC = plymeta.ConCommand
function plymeta.ConCommand(ply, str)
	if showcmds:GetBool() then
		print("ConCommand", str)
	end

	for k,v in pairs(Commands) do
		if string.find(str, k) then
			print("Blocked ConCommand", str)
			return			
		end
	end

	for k,v in pairs(string.Explode(",", blacklistcmds:GetString())) do
		if #v > 1 && string.find(string.lower(str), string.lower(v)) then
			print("Blocked ConCommand", str)
			return
		end
	end

	return oldCC(ply, str)
end

local oldincoming = usermessage.IncomingMessage
usermessage.IncomingMessage = function(msgn, umsg)
	if umsgshow:GetBool() then

		local size = "??"
		if UmsgSIZE then
			size = UmsgSIZE(umsg)
		end
		print( "umsg incoming: " .. msgn, "size: " .. tostring(size) )
	end

	oldincoming(msgn, umsg)
end


local CvarMeta = _R.ConVar
local oldConVarGetBool = _R.ConVar.GetBool
_R.ConVar.GetBool = function(cvar)
	if cvar:GetName() == "sv_cheats" then
		return false
	elseif cvar:GetName() == "sv_scriptenforcer" then
		return true
	end
	
	return oldConVarGetBool(cvar)
end

local oldConVarGetInt = _R.ConVar.GetInt
_R.ConVar.GetInt = function(cvar)
	if cvar:GetName() == "sv_cheats" then
		return 0
	elseif cvar:GetName() == "sv_scriptenforcer" then
		return 1
	elseif cvar:GetName() == "host_timescale" then
		return 1
	end
	
	return oldConVarGetInt(cvar)
end

local oldGetConVar = GetConVar
GetConVar = function(cvar)
	if cvars[string.lower(cvar)] then return end
	return oldGetConVar(cvar)
end

local oldGetConVarNumber = GetConVarNumber
GetConVarNumber = function(cvar)
	if cvars[string.lower(cvar)] then return 0 end
	if string.lower(cvar) == "sv_cheats" then return 0 end
	if string.lower(cvar) == "host_timescale" then return 1 end
	
	return oldGetConVarNumber(cvar)
end

local oldGetConVarString = GetConVarString
GetConVarString = function(cvar)
	if cvars[cvar] then return "" end
	if string.lower(cvar) == "sv_cheats" then return "0" end
	if string.lower(cvar) == "host_timescale" then return "1" end
	
	return oldGetConVarString(cvar)
end

local oldFileTime = file.Time
file.Time = function(file)
	print("file.Time", file)
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return
		end
	end
	return oldFileTime(file)
end

local oldFileExistsEx = file.ExistsEx
file.ExistsEx = function(file)
	if logfileread:GetBool() then
		print("file.ExistsEx", file)
	end
	
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return false
		end
	end
	return oldFileExistsEx(file)
end

local oldFileExists = file.Exists
file.Exists = function(file)
	if logfileread:GetBool() then
		print("file.Exists", file)
	end
	
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return false
		end
	end
	return oldFileExists(file)
end

local oldFileSize = file.Size
file.Size = function(file)
	if logfileread:GetBool() then
		print("file.Size", file)
	end
	
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return
		end
	end
	return oldFileSize(file)
end

local oldFileRead = file.Read
file.Read = function(file)
	if logfileread:GetBool() then
		print("file.Read", file)
	end
	
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return
		end
	end
	return oldFileRead(file)
end
local oldFileFind = file.Find
file.Find = function(file)
	if logfileread:GetBool() then
		print("file.Find", file)
	end
	
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			return {}
		end
	end
	local tableq = oldFileFind(file)
	local nt = {}
	for k, v in pairs(tableq) do
		local found = false
		for x,y in pairs(block) do
			if string.find(string.lower(v), y) then
				print("Blocked file.Find", v)
				found = true
			end
		end

		if !found then
			table.insert(nt, v)
		end
	end
	return nt
end
local oldFileTFind = file.TFind
file.TFind = function(file, callback)
	print("file.TFind", file)
	for k,v in pairs(block) do
		if string.find(string.lower(file), v) then
			callback({})
		end
	end
	oldFileTFind(file, function(a, tableq)
		local nt = {}
		for k,v in pairs(tableq) do
			local found = false
			for x,y in pairs(block) do
				if string.find(string.lower(v), y) then
					print("Blocked file.TFind", v)
					found = true
				end

				if !found then
					table.insert(nt, v)
				end
			end
		end
		callback(a, nt)
	end)
end

local datastreamsend
local function ndata(h,d,cb,acb)
	if logfileread:GetBool() then
		print("datastream sent", h)
	end
	
	return datastreamsend(h, d, cb, acb)
end

local oldReq = require
require = function(a)
	if string.lower(a) == "datastream" && (datastream && datastream.StreamToServer != ndata) then
		oldReq(a)
		datastreamsend = datastream.StreamToServer
		datastream.StreamToServer = ndata
		return
	end
	
	oldReq(a)
end

local oldsqlexists = sql.TableExists
sql.TableExists = function(tbl)
	if string.lower(tbl) == "bacon_pass" then return false end
	return oldsqlexists(tbl)
end

local oldrunstring = RunString
RunString = function(str)
	if logsendlua:GetBool() then
		print("RunString", str)
		filex.Append("runlog.txt", str)
	end
	
	oldrunstring(str)
end

-- Do not remove this empty comment, baconbot must have it.
//
