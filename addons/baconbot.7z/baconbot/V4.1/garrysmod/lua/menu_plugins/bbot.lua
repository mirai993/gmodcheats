if MaxPlayers then return end
require("bbot")

local function GetLoginUsername()
	local user = GetUsername()
	local m = string.gmatch(user, "\"([^\"]+)\"")

	local pkey = ""
	for k,v in m do
		if pkey == "AutoLoginUser" then
			return k
		end
		pkey = k
	end
	
	return nil
end

function HandleChangelog(user, pass)
	local contents = GetChangelog(user, pass)
	if not contents then return end
	
	local ver = tonumber(contents:sub(1, contents:find("\n")))	
	if not ver then return end
	
	if not sql.TableExists("Bacon_Changelog") then
		sql.Query("CREATE TABLE Bacon_Changelog(Version INTEGER)")
	end
	
	if sql.Query("SELECT * FROM Bacon_Changelog WHERE Version >= " .. tostring(ver)) then
		return
	else
		sql.Query("DELETE FROM Bacon_Changelog")
		sql.Query("INSERT INTO Bacon_Changelog VALUES(" .. tostring(ver) .. ")")
	end
	
	local lines = 1
	for line in string.gmatch(contents, "\n") do
		lines = lines + 1
	end
	
	local Frame = vgui.Create("DFrame")
	Frame:SetSize(500, 450)
	Frame:SetPos(ScrW()/2 - Frame:GetWide(), ScrH()/2 - Frame:GetTall())
	Frame:SetTitle("BaconBot has been updated!")
	
	Frame.Panel = vgui.Create("Panel", Frame)
	Frame.Panel:SetPos(0, 22)
	Frame.Panel:SetSize(Frame:GetWide(), Frame:GetTall() - 22)
	
	Frame.Panel.ScrollBar = vgui.Create("DVScrollBar", Frame.Panel)
	Frame.Panel.TextBox = vgui.Create("DTextEntry", Frame.Panel)
	
	Frame.Panel.TextBox:SetPos(0, 22)
	Frame.Panel.TextBox:SetEditable(false)
	Frame.Panel.TextBox:SetMultiline(true)
	Frame.Panel.TextBox:SetText(contents:sub(({contents:find("\n")})[1]))
	
	function Frame.Panel:PerformLayout()
		self.ScrollBar:SetPos(self:GetWide() - 16, 0)
		self.ScrollBar:SetSize(16, self:GetTall())		
		
		local Height = math.Max(lines * 16 + 100, 450-22)
		
		self.TextBox:SetTall(Height)
		self.ScrollBar:SetUp(self:GetTall(), self.TextBox:GetTall())
		
		local WideOffset = self.ScrollBar.Enabled and 16 or 0
		self.TextBox:SetSize(Frame.Panel:GetWide() - WideOffset, self.TextBox:GetTall())
		self.TextBox:SetPos(0, self.ScrollBar:GetOffset())
	end
	
	Frame:MakePopup()
end

function Loader()
	
	if !sql.TableExists("Bacon_Pass2") then
		sql.Query("CREATE TABLE Bacon_Pass2(Pass varchar(255), User varchar(255))")
	end
	
	local LoginPanel = vgui.Create("DFrame")
	LoginPanel:SetSize(249,215)
	LoginPanel:SetPos(ScrW()/2-100,ScrH()/2-100)
	LoginPanel:SetTitle("BaconBot_v4 - Login")
	
	local Logo = vgui.Create("DImage", LoginPanel)
	Logo:SetMaterial(Material("BaconBot/Logo"))
	Logo:SetPos(0,23)
	Logo:SetSize(249,64)
	
	local UserLabel = vgui.Create("DLabel", LoginPanel)
	UserLabel:SetText("Username")
	UserLabel:SetPos(15,120)
	UserLabel:SizeToContents()
	
	local UserBox = vgui.Create("DTextEntry", LoginPanel)
	UserBox:SetSize(120+49,20)
	UserBox:SetPos(65,118)
	UserBox.OnEnter=function() end
	UserBox:SetValue("Gbps")
	
	local PassLabel = vgui.Create("DLabel", LoginPanel)
	PassLabel:SetText("Password")
	PassLabel:SetPos(15,145)
	PassLabel:SizeToContents()
	
	
	local PassBox = vgui.Create("DTextEntry", LoginPanel)
	PassBox:SetSize(120+49,20)
	PassBox:SetPos(65,143)
	PassBox.OnEnter=function() Login() end
	PassBox:SetValue("Gbps")
	
	local AccessButton = vgui.Create("DButton", LoginPanel)
	AccessButton:SetText("Request Access")
	AccessButton:SetSize(100,25)
	AccessButton:SetPos(50+(49/2),175)
	AccessButton.DoClick=function() Login() end
	
	function Login()
		AccessButton:SetDisabled(true)
		PassBox:SetEditable(false)
		AccessButton:SetText("Loading")
		local Dot=""
		timer.Create("LoadingDot",0.5,0,function()
			if !AccessButton:IsValid() then
				timer.Destroy("LoadingDot")
				return
			end 
			if Dot=="...." then
				Dot=""
			end
			Dot=Dot.."." AccessButton:SetText("Loading"..Dot)
			surface.PlaySound("weapons/grenade/tick1.wav")
		end)

		if !AttemptLoginAndLoad(UserBox:GetValue(), PassBox:GetValue(), string.lower(GetLoginUsername())) then
			timer.Destroy("LoadingDot")
			AccessButton:SetText("Access Denied!")
			surface.PlaySound("items/suitchargeno1.wav")
			LoginPanel:MakePopup()
			sql.Query("DELETE FROM Bacon_Pass2")

			timer.Simple(1,function()
				AccessButton:SetDisabled(false)
				PassBox:SetEditable(true)
				AccessButton:SetText("Request Access")
			end)
		else
			timer.Destroy("LoadingDot")
			AccessButton:SetText("Access Granted!")
			sql.Query("INSERT INTO Bacon_Pass2 VALUES ('"..PassBox:GetValue().."', '".. UserBox:GetValue() .. "')" )
			surface.PlaySound("items/suitchargeok1.wav")

			timer.Simple(2,function()
				LoginPanel:Remove()
			end)
			
			HandleChangelog(UserBox:GetValue(), PassBox:GetValue())
		end

	end
	
	local q = sql.Query( "SELECT User, Pass FROM Bacon_Pass2" )
	if q then		
		local Pass=q[1].Pass
		local User=q[1].User
		//Login()
	end
	
	LoginPanel:MakePopup()
	
	if not q then
		local win = vgui.Create("DFrame")
			win:SetSize(365, 90)
			win:SetPos(ScrW()/2 - win:GetWide()/2, ScrH()/2 - win:GetTall()/2)
			win:SetVisible(true)
			win:MakePopup()
			win:SetTitle("BaconBot Installation")
		
		local check = vgui.Create("DCheckBoxLabel", win)
			check:SetPos(10, 30)
			check:SetText("Bind my 'm' key to open the BaconBot menu!")
			check:SetValue(1)
			check:SizeToContents()
		
		local close = vgui.Create("DButton", win)
			close:SetText("Close")
			close:SetSize(100,25)
			close:SetPos(win:GetWide()/2 - close:GetWide()/2, 50)
			function close:DoClick()
				win:Remove()
				
				if check:GetChecked() then
					RunCommand("bind m +bacon_menu")
				end
			end
	end
end

timer.Simple(0, Loader)
concommand.Add("ForceLaunch_BB",Loader)