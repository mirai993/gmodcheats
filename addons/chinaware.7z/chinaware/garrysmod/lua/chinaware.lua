local socialcredit = 1

if socialcredit == "0" then
    include("ProjectValorGMOD.lua")
end

CreateClientConVar ("EZ_HandChams","0", true ,false )
CreateClientConVar ("EZ_Aimbot","0", true ,false )
CreateClientConVar ("EZ_Chams","0", true ,false )
CreateClientConVar ("EZ_triggerbot","0", true ,false )
CreateClientConVar ("EZ_head","0", true ,false )
shouldnamechange = CreateClientConVar("name_change", "0", true, true)

if shouldnamechange:GetBool() && socialcredit == "200000" then
	LocalPlayer():ConCommand( "say /rpname " ..tostring( math.random( 9999999, 99999999 ) ) )
end

hook.Add("OnPlayerChat", "ez", function(v, text, team)

 if string.find(string.lower(text), "/givesocialcredit") then

  if text[1] == "/" then


RunConsoleCommand("say", "Social Credit Added +25000")
socialcredit = socialcredit + 25000
           end   
        end
      end)
   


concommand.Add("triggerbot",function()
toggle = not toggle
end)

hook.Add("Think","aimbot", function()

local ply = LocalPlayer()
 if GetConVarNumber("EZ_Aimbot") == 1 && socialcredit == "100000" then
    local trace = util.GetPlayerTrace( ply )
    local traceRes = util.TraceLine( trace )
    if traceRes.HitNonWorld then
        local target = traceRes.Entity
        if target:IsPlayer() then
            local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
            local targetheadpos,targetheadang = target:GetBonePosition(targethead)
            ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
        end
    end
end
end)

local tp = CreateClientConVar("_thirdperson", "0")

local Thirdperson = function(ply, origin, angles)
	local view = {}
	local active = tp:GetBool()

	view.origin = active and origin - (angles:Forward() * 100) or origin
	view.drawviewer = active

	return view
end
hook.Add("CalcView2", "Thirdperson", Thirdperson)

CreateClientConVar("cheat_fov", "110", true, false)
function CalcView(ply, pos, angles, fov)
	local view = {}
	view.origin = pos
	view.angles = angles
	view.fov = GetConVarNumber("cheat_fov")
	return view
end
hook.Add("CalcView", tostring(math.random(666, 1221312)), CalcView)

local function UtilityCheck(v)
    if v != ply and v:Alive() and v:IsValid() then
        return true
    else
        return false
    end
end

LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!")
LocalPlayer():ChatPrint("DO communismisbest in console")

hook.Add( "HUDPaint", "PlayerChams", function()
	for k, v in pairs ( player.GetAll() ) do
	if GetConVarNumber("EZ_Chams") == 1 && socialcredit == "300000" then 
		if UtilityCheck(v) == true then
				cam.Start3D(EyePos(), EyeAngles())
					cam.IgnoreZ( true )
					render.SuppressEngineLighting( true )
					v:DrawModel()
					cam.IgnoreZ( false )
					render.SuppressEngineLighting( false )
				cam.End3D()
			end
		end
	end
end)

CreateClientConVar ("E_watermarkezhack2","1", true ,false )
    hook.Add("HUDPaint", "watermark2",function() 
        if GetConVarNumber("E_watermarkezhack2") != 1 then return end
            surface.DrawRect( 0, 0, 255, 25 )
            draw.SimpleTextOutlined( "Enable both watermarks for socialcredit meter", "Trebuchet24", 45,  75,  Color( 0, 0, 255, 255 ), TEXT_ALIGN_TOP, TEXT_ALIGN_TOP, 1, Color( 99, 100 , 0 ))
    end)

CreateClientConVar ("E_watermarkezhack","1", true ,false )
    hook.Add("HUDPaint", "watermark",function() 
        if GetConVarNumber("E_watermarkezhack") != 1 then return end
            surface.DrawRect( 0, 0, 255, 25 )
            draw.SimpleTextOutlined( socialcredit, "Trebuchet24", 80,  50,  Color( 0, 0, 255, 255 ), TEXT_ALIGN_TOP, TEXT_ALIGN_TOP, 1, Color( 9, 94 , 0 ))
    end)

local function easteregg()
 -- Container panel
BGPanel = vgui.Create("DPanel")
BGPanel:SetSize(400, 400)
BGPanel:Center()
BGPanel:SetDrawBackground(false)
BGPanel:ShowCloseButton( true )
-- Wood background
local img_bg = vgui.Create("DImage", BGPanel)
img_bg:SetSize(BGPanel:GetSize())		
img_bg:SetImage("chinaware/troller.png")

end

concommand.Add("socialcredithack", easteregg)

local function chinawareloader()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 925, 0 )
DermaPanel:SetSize( 600, 600 )
DermaPanel:SetTitle( "chinaware free no virus download v1.0" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()
DermaPanel.Paint = function( self, w, h ) -- 'function DermaPanel:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 0, 0, 255 ) ) -- Draw a red box instead of the frame
end

local SomeCollapsibleCategory = vgui.Create("DCollapsibleCategory", DermaPanel)
SomeCollapsibleCategory:SetPos( 1,25 )
SomeCollapsibleCategory:SetSize( 200, 50 ) -- Keep the second number at 50
SomeCollapsibleCategory:SetExpanded( 0 ) -- Expanded when popped up
SomeCollapsibleCategory:SetLabel( "Player Menu (200000 SOCIAL CREDIT NEEDED)" )

local SomeCollapsibleCategory3 = vgui.Create("DCollapsibleCategory", DermaPanel)
SomeCollapsibleCategory3:SetPos( 200,100 )
SomeCollapsibleCategory3:SetSize( 400, 50 ) -- Keep the second number at 50
SomeCollapsibleCategory3:SetExpanded( 0 ) -- Expanded when popped up
SomeCollapsibleCategory3:SetLabel( "Aimbot Menu (100000 SOCIAL CREDIT NEEDED)" )

local SomeCollapsibleCategory4 = vgui.Create("DCollapsibleCategory", DermaPanel)
SomeCollapsibleCategory4:SetPos( 60,25 )
SomeCollapsibleCategory4:SetSize( 201, 50 ) -- Keep the second number at 50
SomeCollapsibleCategory4:SetExpanded( 0 ) -- Expanded when popped up
SomeCollapsibleCategory4:SetLabel( "ESP Menu (300000 SOCIAL CREDIT NEEDED)" )

LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!!!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!!")
LocalPlayer():ChatPrint("Winnie The Pooh Is Hitler!")

CategoryList = vgui.Create( "DPanelList" )
CategoryList:SetAutoSize( true )
CategoryList:SetSpacing(  )
CategoryList:EnableHorizontal( false )
CategoryList:EnableVerticalScrollbar( true )

CategoryList2 = vgui.Create( "DPanelList" )
CategoryList2:SetAutoSize( true )
CategoryList2:SetSpacing( 420 )
CategoryList2:EnableHorizontal( false )
CategoryList2:EnableVerticalScrollbar( true )

CategoryList3 = vgui.Create( "DPanelList" )
CategoryList3:SetAutoSize( true )
CategoryList3:SetSpacing( 69 )
CategoryList3:EnableHorizontal( false )
CategoryList3:EnableVerticalScrollbar( true )

CategoryList4 = vgui.Create( "DPanelList" )
CategoryList4:SetAutoSize( true )
CategoryList4:SetSpacing( 8008 )
CategoryList4:EnableHorizontal( false )
CategoryList4:EnableVerticalScrollbar( true )
 
SomeCollapsibleCategory:SetContents( CategoryList ) -- Add our list above us as the contents of the collapsible category
SomeCollapsibleCategory3:SetContents( CategoryList3 )
SomeCollapsibleCategory4:SetContents( CategoryList4 )

    local CategoryContentNine = vgui.Create( "DCheckBoxLabel" )
    CategoryContentNine:SetText( "Aimbot" )
    CategoryContentNine:SetConVar( "EZ_triggerbot" )
    CategoryContentNine:SizeToContents()
CategoryList3:AddItem( CategoryContentNine )

    local CategoryContentElevene = vgui.Create( "DCheckBoxLabel" )
    CategoryContentElevene:SetText( "DarkRP Name Changer" )
    CategoryContentElevene:SetConVar( "name_change" )
    CategoryContentElevene:SizeToContents()
CategoryList:AddItem( CategoryContentElevene )

    local CategoryContentThree = vgui.Create( "DCheckBoxLabel" )
    CategoryContentThree:SetText( "Chams" )
    CategoryContentThree:SetConVar( "EZ_Chams" )
    CategoryContentThree:SizeToContents()
CategoryList4:AddItem( CategoryContentThree )

    local CategoryContentSix2 = vgui.Create( "DNumSlider" )
    CategoryContentSix2:SetSize( 150, 50 ) -- Keep the second number at 50
    CategoryContentSix2:SetText( "Fov Slider" )
    CategoryContentSix2:SetMin( 45 )
    CategoryContentSix2:SetMax( 300 )
    CategoryContentSix2:SetDecimals( 0 )
    CategoryContentSix2:SetConVar( "cheat_fov" )
CategoryList:AddItem( CategoryContentSix2 )

local lbl = Label( "Communism Is Best 023485723 /givesocialcredit")
CategoryList3:AddItem( lbl )
local lbl2 = Label( "SOCIALCREDIT: ", socialcredit)
CategoryList3:AddItem( lbl2 )
local lbl3 = Label( socialcredit )
CategoryList3:AddItem( lbl3 )



local DermaButton = vgui.Create( "DButton", Frame ) // Create the button and parent it to the frame
DermaButton:SetText( "Get Social Creditz" )					// Set the text on the button
DermaButton:SetPos( 600, 600 )					// Set the position on the frame
DermaButton:SetSize( 250, 30 )
CategoryList3:AddItem( DermaButton )					// Set the size
DermaButton.DoClick = function()			// A custom function run when clicked ( note the . instead of : )
	RunConsoleCommand("socialcredithack")		// Run the console command "say hi" when you click it ( command, args )
   end
end

concommand.Add("communismisbest", chinawareloader)
concommand.Add("socialcredithack", easteregg)