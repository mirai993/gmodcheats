timer.Create("cs_spam_dance", 0.1, 0, function()

if CS_DANCE_COMMAND != nil then
RunConsoleCommand('act', CS_DANCE_COMMAND)
end

end)

function CS_SET_EMOTE(ply, cmd, args)

if not tostring(args[1]) then 
cs_msg("Invalid emote!")
return end


CS_DANCE_COMMAND = tostring(args[1])


end

concommand.Add('cs_spam_emote', CS_SET_EMOTE)