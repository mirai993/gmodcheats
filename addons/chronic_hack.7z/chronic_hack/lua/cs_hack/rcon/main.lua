--[[
This is our RCON hack :3
]]--

function scanfiles(ply, command, args)

if not tostring(args[1]) then 
cs_msg("Invalid usage! cs_scan <file dir>")
return end


local txt = file.Read(args[1], true)
print(txt)


end
concommand.Add('cs_scan', scanfiles)