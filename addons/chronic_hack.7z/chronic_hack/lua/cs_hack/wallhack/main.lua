--[[
This LUA file will contain all the differant wallhacks included in the script.
]]--


-- Staff wallhack
local staff_wallhack = false

concommand.Add('cs_wallhack_staff', function()

staff_wallhack = !staff_wallhack
cs_msg('Staff wallhack set to: ' .. tostring(staff_wallhack))

end)


hook.Add( "HUDPaint", "Staff wallhack", function()
 
if !(staff_wallhack == true) then return end
 
for k,v in pairs ( player.GetAll() ) do
 

if v:GetUserGroup() == 'user' then 
-- Do nothing
else
   
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
 
if v == LocalPlayer() then
 
else
draw.DrawText( v:Nick(), "ChatFont", Position.x, Position.y, team.GetColor(v:Team()), 1 )
draw.DrawText( v:GetUserGroup(), "ChatFont", Position.x, Position.y+20, team.GetColor(v:Team()), 1 )
draw.DrawText( "Distance: " ..  math.floor(LocalPlayer():GetPos():Distance( v:GetPos())/17.6 / 3) .. 'M', "ChatFont", Position.x, Position.y-20, team.GetColor(v:Team()), 1 )

end

end
    
end
 
end)





-- Money printer wallhack
local printer_wallhack = false

concommand.Add('cs_wallhack_printers', function()

printer_wallhack = !printer_wallhack
cs_msg('Printer wallhack set to: ' .. tostring(printer_wallhack))

end)


hook.Add( "HUDPaint", "Printer wallhack", function()
 
if !(printer_wallhack == true) then return end
 
for k,v in pairs ( ents.GetAll() ) do
 
if IsPrinter(v) then   
local Position = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()

draw.RoundedBox( 4, Position.x-1, Position.y-1, 10+2, 10+2, Color( 0, 0, 0, 255 ) )
draw.RoundedBox( 4, Position.x, Position.y, 10, 10, Color( 255, 255, 255, 200 ) )
draw.DrawText( v:GetClass(), "ChatFont", Position.x, Position.y-40, Color( 255, 255, 255, 255 ), 1 )
draw.DrawText( "Distance: " ..  math.floor(LocalPlayer():GetPos():Distance( v:GetPos())/17.6 / 3) .. 'M', "ChatFont", Position.x, Position.y-20, Color( 255, 255, 255, 255 ), 1 )
 
 end
 
end
 
end)