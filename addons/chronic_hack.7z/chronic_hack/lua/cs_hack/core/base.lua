--[[
This is just the base code of the script, a lot of the core functions will be found here.
]]--



-- Allows the script to message the player
function cs_msg(text)
chat.AddText(Color(255,0,0), "[CS] ", Color(255,255,100), tostring(text))
RunConsoleCommand('play', 'HL1/fvox/blip.wav')
end
--


-- Tell the client that the script has loaded
cs_msg("Chronic's script BETA has succesfully loaded!")
--


-- Advanced method of detecting if an entity is a money printer or not (WIP)
function IsPrinter(ent)

if not IsValid(ent) then return false end
local class = ent:GetClass()

if class == 'money_printer' then return true end
if class == 'money_printer_*' then return true end
if ( string.match(class, "printer") ) then return true end

return false

end
--



-- Detect whether a player is in your friends list or not.
function IsFriend(ply)
return ply:GetFriendStatus() == 'friend' 
end
--