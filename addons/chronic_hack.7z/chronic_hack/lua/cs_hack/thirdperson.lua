--[[

Thirdperson view :3

]]--

function SetView(ply, pos, angles, fov)

    local view = {}
    view.origin = pos-(angles:Forward()*100)
    view.angles = angles
    view.fov = fov
 
 if CS_TPS == true then
    return view
end
    
end
 
hook.Add("CalcView", "MyCalcView", SetView)
 
hook.Add("ShouldDrawLocalPlayer", "Thirdperson view", function(ply)
        return CS_TPS
end)
 
 
 
concommand.Add('cs_thirdperson', function()

if CS_TPS == nil then CS_TPS = false end

CS_TPS = !CS_TPS

end)