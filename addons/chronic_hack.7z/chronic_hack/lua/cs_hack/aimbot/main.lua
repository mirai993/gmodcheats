--[[
This LUA file contains the differant aimbots
]]--

cs_target = nil

function SetPlayer (ply, key)

-- When we press L ALT
if key == IN_WALK then

local ent = LocalPlayer():GetEyeTrace().Entity

if IsValid(ent) and ent:IsPlayer() then
if cs_target == ent then return end
cs_target = ent
cs_msg('Target set: ' .. ent:Nick())
target = cs_target:LookupBone("ValveBiped.Bip01_Spine")
end

end

end
hook.Add( "KeyPress", "CS Aimbot Set Player", SetPlayer )


local function DoAttack()

if input.IsKeyDown(KEY_LALT) then

if IsValid(cs_target) then
LocalPlayer():SetEyeAngles((cs_target:GetBonePosition(target) - LocalPlayer():GetShootPos()):Angle())
end

end


end
 
hook.Add("Think","CS Aimbot find player", DoAttack)
