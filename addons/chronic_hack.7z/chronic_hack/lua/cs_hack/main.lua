include('core/base.lua')
include('wallhack/main.lua')
include('aimbot/main.lua')
include('rcon/main.lua')
include('spam/main.lua')
include('thirdperson.lua')

