Error("LOADER DISABLED")

if (SERVER) then Error("[GABV9K] SERVER USE NOT AUTHORIZED\n") end

--[[ GABV9K ]]--
local GABV9K_MENU = {}

print([[    __  ____    _    ___   __
   /  |/  (_)__| |  / / | / / ____/_  __/
  / /|_/ / // ___/ ___/ __ \ | / /  |/ / __/   / /  
/ /  / / // /__/ /  / /_/ / |/ / /|  / /___  / /    
/_/  /_/_/ \___/_/   \____/|___/_/ |_/__/ /_/  ]])
print("==GABV9K v0.0==")

--[[ GABV9K Setup ]]--
GABV9K_MENU['url'] = ""

GABV9K_MENU.tosig = function(str)
    local out = ""
    str = string.gsub(str, "?", "\x3F")
    local i = string.find(str, "x")
    while (i ~= nil) do
        out = out .. string.char('0' .. string.sub(str, i, i+2))
        i = string.find(str, "x", i+2)
    end
    return out
end

--[[ GABV9K Hook Provider ]]--
GABV9K_MENU.Hooks = {}
GABV9K_MENU.AddHook = function(name, unique, func)
    if (GABV9K_MENU.Hooks[name] == nil) then
        GABV9K_MENU.Hooks[name] = {}
    end
    GABV9K_MENU.Hooks[name][unique] = func
end
GABV9K_MENU.RemoveHook = function(name, unique)
    GABV9K_MENU.Hooks[name][unique] = nil
end
GABV9K_MENU.CallHook = function(name, ...)
    --print("[CallHook]", name, unpack({...}))
    if (GABV9K_MENU.Hooks[name] ~= nil) then
        local ret
        local args = {...}
        for k,v in pairs(GABV9K_MENU.Hooks[name]) do
            if (v ~= nil) then
                ret = {pcall(v, unpack({...}))}
                if (ret[1] == false) then
        ErrorNoHalt("[GABV9k] Hook '"..tostring(k).."' failed! ["..tostring(ret[2]).."]\n")
        GABV9K_MENU.Hooks[name][k] = nil
                else
        if (ret[2] ~= nil) then
        return unpack(ret, 2)
        end
                end
            else
                ErrorNoHalt("[GABV9K] '"..tostring(k).."' not valid!\n")
                GABV9K_MENU.Hooks[name][k] = nil
            end
        end
    end
end
_G["GABV9K_CallHook"] = GABV9K_MENU.CallHook

--[[ GABV9K Load Module
STATES | NAME
G + M  | bool IsInGame()
G + M  | bool IsTakingScreenshot()
G + M  | bool IsPaused()
G + M  | RunConCmd(string)
G + M  | ForceCvar(name, value)
G  | SetViewAngles(angle, OPTIONAL usercmd)
G  | angle GetViewAngles(OPTIONAL usercmd)
M  | float LUD2INT(lud)
M  | lud SigScan(table) [see GABV9K_MENU['ExecuteCmdString'] for table format]
M  | HookExecuteCmdString(lud)
M  | UnHookExecuteCmdString() ]]--
require("gabv9k")
GABV9K_MENU.MODULE = {}
GABV9K_MenuLoadInto(GABV9K_MENU.MODULE)

--[[ GABV9K ExecuteCmdString Hook ]]--
GABV9K_MENU.AddHook("LoadInto", "EcsHook", function()
    print("[GABV9K] Adding ExecuteCmdString hook")
    ecs_ptr = GABV9K_MENU.MODULE.SigScan({
        ['dll'] = "engine.dll",
        ['dfn'] = "CreateInterface", --Function exported from the dll
        ['sig'] = GABV9K_MENU.tosig("?\x8B\x6C\x24?\x8B??\x85?\x75??\xC3\x85??\xBE"),
        ['len'] = 18,
    })
    if (ecs_ptr ~= nil) then GABV9K_MENU.MODULE.HookExecuteCmdString(ecs_ptr)
    else print("[GABV9K] Failed to hook ExecuteCmdString") end
end)
GABV9K_MENU.AddHook("ModuleUnload", "EcsUnHook", function()
    print("[GABV9K] Removing ExecuteCmdString hook")
    GABV9K_MENU.MODULE.UnHookExecuteCmdString()
end)

--[[ GABV9K Force Cvar ]]--
GABV9K_MENU.AddHook("ExecuteCmdString", "ForceCvar", function(cmd)
    if (string.sub(cmd, 0, 16) == "GABV9K_FORCECVAR") then
        local explode = string.Explode(" ", cmd)
        GABV9K_MENU.MODULE.ForceCvar(explode[2], tonumber(explode[3]), FCVAR_CHEAT | FCVAR_REPLICATED)
        return false
    end
end)

--[[ GABV9K ConCommand Firewall ]]--
GABV9K_MENU.CmdFirewall = {}
GABV9K_MENU.CmdFirewall.Enabled = false
GABV9K_MENU.CmdFirewall.BlockedCmds = { --Checked before whitelist
    --cvars
    "mat_fullbright", "mat_drawwater", "mat_fastno",
    "mat_wireframe", "r_drawropes", "r_drawrain",
    "r_drawdecals", "r_drawtranslucentrenderables",
    "r_farz", "r_drawskybox", "fog_enable_water_fog",
    "cl_phys_timescale", "host_timescale",
    "net_fakelag", "net_fakeloss", "net_fakejitter",
    --general AntiCheat
    "say I'm ", "say_team I'm ", "team_say I'm ",
    "lua_run_cl",
    --Blade AntiCheat
    "say [BLADE] ", "say_team [BLADE] ", "team_say [BLADE] ",
    "blade_client_check",
    "blade_client_message",
    "blade_client_detected_message",
    --Flapdar AntiCheat
    "_zs_class", "_zs_setclass", "_zs_spread",
    "_cmd", "_ac_log", "_ac_devpass",
}
GABV9K_MENU.CmdFirewall.Hook = function(cmd)
    if (string.sub(cmd, 0, 25) == "GABV9K_CMDFIREWALL") then
        GABV9K_MENU.CmdFirewall.Enabled = not GABV9K_MENU.CmdFirewall.Enabled
        print("[GABV9K] [CmdFirewall] " ..
            (GABV9K_MENU.CmdFirewall.Enabled and "Enabled" or "Disabled"))
        return false
    end
    if (GABV9K_MENU.CmdFirewall.Enabled) then
        for _,v in pairs(GABV9K_MENU.CmdFirewall.BlockedCmds) do
            if (string.sub(cmd, 0, string.len(v)) == v) then
                print("[GABV9K] [CmdFirewall] Blocked command '"..cmd.."'")
                return false
            end
        end
    end
end
GABV9K_MENU.AddHook("ExecuteCmdString", "CmdFirewall", GABV9K_MENU.CmdFirewall.Check)