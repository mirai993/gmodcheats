--[[
	microbotold.lua
	Ollie | (STEAM_0:0:30709335)
	===DStream===
]]

Micro = {} 
Micro.Info = "A hack for garry's mod!"  
Micro.Version = "0.3"
Micro.Friends = {}
Micro.TTTWeps = {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio","weapon_ttt_radar"}
Micro.Bones = {}
Micro.Functions = {}
Micro.Spectators = {}  
Micro.Hacks = {}
Micro.CanClick = true 
Micro.Menu = {}
Micro.Menu.Enabled = false
Micro.Menu.Items = {}
Micro.Draw = false

Micro.InfoMenu = {}
Micro.InfoMenu.Enabled = false

Micro.Aimbot = {}
Micro.Aimbot.Enabled = false
Micro.Aimbot.FakeFov = 180
Micro.Aimbot.NoSnap = true
Micro.Aimbot.Scroll = false
Micro.Aimbot.x = 0


Micro.Radar = {}
Micro.Radar.x = ScrW()-200
Micro.Radar.y = ScrH()-200

Micro.Dragging = false

local menuy = 0

function Micro.Functions.Initialize() // All of initializing code here! :3

print("Microbot "..Micro.Version.." Loaded!" )

local pairs = pairs
local hook = hook
local LocalPlayer = LocalPlayer
local CreateClientConVar = CreateClientConVar
local RunConsoleCommand = RunConsoleCommand
local table = table
local surface = surface
local cam = cam
local render = render 
local util = util   
local math = math
local Entity = Entity
local team = team
local string = string
local ents = ents
local vgui = vgui
local concommand = concommand
local me = LocalPlayer() 

Micro.Enabled = 1

Micro.Bones.Crow = "models/crow.mdl"
Micro.Bones.Pigeon = "models/pigeon.mdl"
Micro.Bones.Seagull = "models/seagull.mdl"
Micro.Bones.Combine_Scanner = "models/combine_scanner.mdl"
Micro.Bones.Hunter = "models/hunter.mdl"
Micro.Bones.Combine_Turret = "models/combine_turrets/floor_turret.mdl"
Micro.Bones.Dog = "models/dog.mdl"
Micro.Bones.Vortigaunt = "models/vortigaunt.mdl"
Micro.Bones.Antlion = "models/antlion.mdl"
Micro.Bones.Antlion_Guard = "models/antlion_guard.mdl"
Micro.Bones.Worker = "models/antlion_worker.mdl"
Micro.Bones.Fast_Torso = "models/zombie/fast_torso.mdl"
Micro.Bones.Fast = "models/zombie/fast.mdl"
Micro.Bones.Headcrab_Classic = "models/headcrabclassic.mdl"
Micro.Bones.Headcrab_Black = "models/headcrabblack.mdl"
Micro.Bones.Headcrab = "models/headcrab.mdl"
Micro.Bones.Poison = "models/zombie/poison.mdl"
Micro.Bones.Zombie = "models/zombie/classic.mdl"
Micro.Bones.Torso = "models/zombie/classic_torso.mdl"
Micro.Bones.Zombie_Soldier = "models/zombie/zombie_soldier.mdl"
Micro.Bones.Combine_Strider = "models/combine_strider.mdl"
Micro.Bones.Drop = "models/combine_dropship.mdl"
Micro.Bones.Heli = "models/combine_helicopter.mdl"
Micro.Bones.Gunship = "models/gunship.mdl"
Micro.Bones.Lamarr = "models/lamarr.mdl" 
Micro.Bones.Mortar = "models/mortarsynth.mdl" 
Micro.Bones.Synch = "models/synth.mdl"
Micro.Bones.Vor_Slave = "models/vortigaunt_slave.mdl"  

Micro.Skeleton = { 


{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },


{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },


{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },


{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },


{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

local temptable = {}
temptable.Name = "Skeleton"
temptable.Enabled = 0
temptable.y = 0
Micro.Hacks.Skeleton = temptable

local temptable = {}
temptable.Name = "ESP"
temptable.Enabled = 0
temptable.y = 0
Micro.Hacks.ESP = temptable

local temptable = {}
temptable.Name = "Wallhack"
temptable.Enabled = 0
temptable.y = 0
Micro.Hacks.Wallhack = temptable

local temptable = {}
temptable.Name = "BoundingBoxes"
temptable.Enabled = 0
temptable.y = 0
Micro.Hacks.BoundingBoxes = temptable

local temptable = {} // <- 
temptable.Name = "Spec"
temptable.Enabled = 0 
temptable.y = 0
Micro.Hacks.Spectators = temptable 

local temptable = {}
temptable.Name = "Crossbow Trace"
temptable.Enabled = 0 
temptable.y = 0
Micro.Hacks.Traces = temptable 

local temptable = {}
temptable.Name = "Barrel"
temptable.Enabled = 0
temptable.y = 0

Micro.Hacks.Barrel = temptable

local temptable = {}
temptable.Name = "PlayerTracer"
temptable.Enabled = 0
temptable.y = 0

Micro.Hacks.PlyTracer = temptable

local temptable = {}
temptable.Name = "Radar"
temptable.Enabled = 0
temptable.y = 0

Micro.Hacks.Radar = temptable

local temptable = {}
temptable.Name = "Laser"
temptable.Enabled = 0
temptable.y = 0

Micro.Hacks.Laser = temptable


end

Micro.Functions.Initialize() // <- Initialize the system


function IsEnabled(hackname) 

if hackname == nil then return end

return Micro.Hacks[hackname].Enabled 

end
function CheckHit(mx,my,x,y,w,h) 
if x == nil or y == nil or w == nil or h == nil then return end
if mx > x and mx < x + w and my > y and my < y + h then
return true
else
return false
end
end

function Micro.Functions.DrawSkeleton()

	if Micro.Hacks.Skeleton.Enabled == 1 then

		for _,ply in pairs(player.GetAll()) do

			if ply:IsPlayer() and ply:Alive() and ply != LocalPlayer() then 

				for _,bone in pairs( Micro.Skeleton ) do

				local sPos, ePos = ply:GetBonePosition( ply:LookupBone( bone.S ) ):ToScreen(), ply:GetBonePosition( ply:LookupBone( bone.E ) ):ToScreen()

				if ply:IsPlayer() and !ply:IsNPC() and ply != LocalPlayer() then
					surface.SetDrawColor(team.GetColor(ply:Team()))
				end

				surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)

			end

		end

		end

	end

end


function Micro.Functions.DrawActive() 


if CheckHit(gui.MouseX(),gui.MouseY(),5,5,140,18) == true then
	
	MenuColor = Color(110,190,220,155) 
	
	
	if input.IsMouseDown(MOUSE_LEFT) and Micro.CanClick == true then
	Micro.CanClick = false
	
	timer.Simple(0.4,function() Micro.CanClick = true end)
	
	if Micro.Menu.Enabled == true then
	Micro.Menu.Enabled = false
	else
	Micro.Menu.Enabled = true
	end
	
	end
	
	else
	
	MenuColor = Color(135,206,250,155) 
	
end

draw.RoundedBox(1,5,5,145,18,MenuColor) //<- 
draw.SimpleText("Microbot Version "..Micro.Version,"ScoreboardText",10,5,Color(255,255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)  

if Micro.Menu.Enabled == true then

	Micro.Draw = true
	
	menuy = math.Approach(menuy,250,FrameTime()*380)

else

menuy = math.Approach(menuy,0,FrameTime()*380)

if menuy == 0 then

Micro.Draw = false

end

end

if Micro.Draw == true then

	local itemnum = 0

		for k,v in pairs(Micro.Hacks) do

			if v.Enabled == 1 then

			DrawCol = Color(0,155,0,155) 

				else

			DrawCol = Color(155,0,0,155) 

			end

		local boxx = 5 + menuy
		local boxy = 25 + 33*itemnum 
		local boxw = 140 
		local boxh = 30

				if gui.MouseX() > 5 + boxx -250 and gui.MouseX() < boxx + boxw - 250 and gui.MouseY() > boxy and gui.MouseY() < boxy + boxh then

				DrawCol = Color(0,0,155,155)


				if input.IsMouseDown(MOUSE_LEFT) and Micro.CanClick == true then
				Micro.CanClick = false

				timer.Simple(0.3,function() Micro.CanClick = true end)

					if v.Enabled == 1 then
						v.Enabled = 0 
							else
						v.Enabled = 1 
					end

				LocalPlayer():EmitSound("buttons/blip1.wav")

			end 

	end

		draw.RoundedBox(1,boxx - 250 ,boxy,boxw,boxh,DrawCol)
		draw.SimpleText(v.Name,"TargetID",boxx + 10 - 250,boxy + 5,Color(255,255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)  

		itemnum = itemnum + 1 

	end
	
	end


end

local sliderx = ScrW()/2 - 5
local slidery = ScrH()/2 - 10
local dragging = false

//Info Menu

function Micro.InfoMenu.Draw()

local InfoMenuCol = Color(135,206,250,155) 

if Micro.InfoMenu.Enabled == true then
InfoMenuCol = Color(235,206,250,155) 
end

if CheckHit(gui.MouseX(),gui.MouseY(),ScrW()/2.08,5,50,18) then

InfoMenuCol = Color(110,190,220,155) 
	
	if input.IsMouseDown(MOUSE_LEFT) and Micro.CanClick == true then
	Micro.CanClick = false
	
	timer.Simple(0.4,function() Micro.CanClick = true end)
	
	if Micro.InfoMenu.Enabled == true then
	Micro.InfoMenu.Enabled = false
	else
	Micro.InfoMenu.Enabled = true
	end
	
	end

end


draw.RoundedBox(1,ScrW()/2.08,5,50,18,InfoMenuCol)
draw.SimpleText("Info","ScoreboardText",ScrW()/2.02,5,Color(255,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)

if Micro.InfoMenu.Enabled then

// All of info shit drawing here!





end

end
hook.Add("HUDPaint","DerpInfoMenu",Micro.InfoMenu.Draw)


function Micro.Functions.Friends()




end

function Micro.Functions.MainDraw()

// Main hudpaint function

Micro.Functions.DrawSkeleton()
Micro.Functions.DrawActive()
Micro.Functions.Friends()
//Micro.Functions.DrawSliders()
//Micro.Functions.DrawPlyTracer()
Micro.Functions.DrawAimbotMenu()

end

hook.Add("HUDPaint","MainDraw",Micro.Functions.MainDraw)



//Spectators

function MicroSpec()

if !Specs then return end 

local x = 0

for k,v in pairs(player.GetAll()) do

if v:GetObserverTarget() == LocalPlayer() then
table.insert(Micro.Spectators, v:Name()) 
end

local Textlength = surface.GetTextSize(table.concat(Micro.Spectators))
draw.RoundedBox(1,0,0,100,30 + Textlength,Color(0,0,0))
draw.SimpleText("Spectators","ScoreboardText",0,0,Color(255,255,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)

for k,v in pairs(Micro.Spectators) do 

draw.SimpleText(v,"ScoreboardText",ScrW(),ScrH() ,Color(255,255,256))

end
end

end
//Micro.Hacks.Spectators.Enabled = !Micro.Hacks.Spectators.Enabled

concommand.Add("Specs", function(ply, command, args) 

if Micro.Hacks.Spectators.Enabled == 1 then
Micro.Hacks.Spectators.Enabled = 0
else
Micro.Hacks.Spectators.Enabled = 1
end


end) 

//EPS Core
 
function Micro.Hacks.ESP.Function()
for k,v in pairs(player.GetAll()) do 
if IsEnabled("ESP") == 1 then
if v!=LocalPlayer() then
if v:IsPlayer() and v:Alive() then 

local center = v:LocalToWorld( v:OBBCenter() )
local min,max = v:WorldSpaceAABB()
local dim = max - min

local front = v:GetForward()*(dim.y/2)
local right = v:GetRight()*(dim.x/2)
local top = v:GetUp()*(dim.z/2)
local back = (v:GetForward()*-1)*(dim.y/2)
local left = (v:GetRight()*-1)*(dim.x/2)
local bottom = (v:GetUp()*-1)*(dim.z/2)

local FRT = center+front+right+top
local BLB = center+back+left+bottom
local FLT = center+front+left+top
local BRT = center+back+right+top
local BLT = center+back+left+top
local FRB = center+front+right+bottom
local FLB = center+front+left+bottom
local BRB = center+back+right+bottom


FRT = FRT:ToScreen()
BLB = BLB:ToScreen()
FLT = FLT:ToScreen()
BRT = BRT:ToScreen()
BLT = BLT:ToScreen()
FRB = FRB:ToScreen()
FLB = FLB:ToScreen()
BRB = BRB:ToScreen()

local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)

if IsEnabled("BoundingBoxes") == 1 then

surface.SetDrawColor(team.GetColor(v:Team()))

surface.DrawLine( xmax, ymax, xmax, ymin )
surface.DrawLine( xmax, ymin, xmin, ymin )
surface.DrawLine( xmin, ymin, xmin, ymax )
surface.DrawLine( xmin, ymax, xmax, ymax )

end

end
end


if v!=LocalPlayer() then
if v:IsPlayer() and v:Alive() and !v:IsNPC() then

local Pos = v:EyePos():ToScreen()
local Col = team.GetColor(v:Team())
local Dist = v:GetPos():Distance(LocalPlayer():GetPos())
local Rank = ""
local Wep = ""
if v:IsAdmin() then 
Rank = " (A)" 
end
if v:IsSuperAdmin() then 
Rank = " (SA)"  
end

if ValidEntity(v:GetActiveWeapon()) then
Wep = v:GetActiveWeapon():GetPrintName()
Wep = string.gsub(Wep,"#HL2_","")
Wep = string.gsub(Wep,"#GMOD_","") 
Wep = string.upper(Wep)
end

draw.SimpleTextOutlined(v:Nick() .." - "..v:Health().."H"..Rank,"DefaultSmall",Pos.x - 30,Pos.y - 20,Col,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,.6,Color(30,30,30,165))
draw.SimpleTextOutlined(Wep.." - "..math.Round(Dist).."D","DefaultSmall",Pos.x - 30, Pos.y - 8, Col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, .6, Color( 30, 30, 30, 165 ) )

elseif v:IsNPC() then
local NPC = v:GetClass()
NPC = string.Replace(NPC,"npc_","")
NPC = string.Replace(NPC,"_","")
NPC = string.upper(NPC) 
local Pos = v:EyePos():ToScreen()
draw.SimpleTextOutlined(NPC,"DefaultSmall",Pos.x ,Pos.y - 20,Col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,.6,Color(30,30,30,165))


end
end
end
end
end
hook.Add("HUDPaint","ESPCore",Micro.Hacks.ESP.Function)
 

//BowStuff
function Shitbow() 

if IsEnabled("Traces") == 1 then

for k,v in pairs(ents.GetAll()) do 

if v:GetModel() == "models/crossbow_bolt.mdl" then

if(ValidEntity(v)) then 

cam.Start3D(EyePos(),EyeAngles())
render.SetMaterial(Material("cable/blue_elec")) //sprites/bluelaser1 cable/physbeam   

local mepos = LocalPlayer():GetPos()
local pos = v:GetPos() 
local lpos = (v:GetPos() + v:GetForward()*-200)


render.DrawBeam(lpos,pos,15,0,0,Color(255,0,255,255))
cam.End3D() 
//surface.SetDrawColor(255,255,255,255)
//surface.DrawLine(lpos.x,lpos.y,pos.x,pos.y)  

end
end
end
end
end
hook.Add("HUDPaint","crosbows",Shitbow)  

//Player Tracers

function Micro.Functions.DrawPlyTracer()

if Micro.Hacks.PlyTracer.Enabled == 1 then

for k,v in pairs(player.GetAll()) do
if v!=LocalPlayer() and v:IsPlayer() and v:Alive() then
if ValidEntity(v) then
PlyPos = v:GetPos()


cam.Start3D(EyePos(), EyeAngles())
render.SetMaterial(Material("cable/physbeam"))

render.DrawBeam(LocalPlayer():GetPos(),PlyPos,5,0,0,Color(255,255,255,255))
cam.End3D()

end
end
end
end
end
hook.Add("HUDPaint","PlayerTracers",Micro.Functions.DrawPlyTracer) 

//Barrel 
function DrawBarrel() 

if IsEnabled("Barrel") == 1 then // <- IsEnabled 

for k,v in pairs(player.GetAll()) do
if v!= LocalPlayer() and v:IsPlayer() and v:Alive() then
if ValidEntity(v) then

cam.Start3D(EyePos(),EyeAngles())
render.SetMaterial(Material("cable/physbeam"))
render.DrawBeam(v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1")),v:GetEyeTraceNoCursor().HitPos,5,0,0,Color(255,255,255,255))
cam.End3D()

end
end
end
end
end
hook.Add("HUDPaint","Barrelshits",DrawBarrel)


//Radar shits

function MicroRadars()

if IsEnabled("Radar") == 1 then




local Showname = true

local sin,cos,rad = math.sin,math.cos,math.rad;  
function GeneratePoly(x,y,radius,quality) 
    local circle = {};
    local tmp = 0;
    for i=1,quality do
        tmp = rad(i*360)/quality
        circle[i] = {x = x + cos(tmp)*radius,y = y + sin(tmp)*radius};
    end
    return circle;
end

surface.SetDrawColor(Color(255,255,255,55))
surface.SetTexture(surface.GetTextureID("gui/gradient"))
surface.DrawPoly(GeneratePoly(Micro.Radar.x,Micro.Radar.y,100,36))


local center = Vector(Micro.Radar.x,Micro.Radar.y, 0 )
local scale = Vector( 100, 100, 0 )
local segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
surface.SetDrawColor( 0, 0, 0, 155 )
 
for a = 0, 360 - segmentdist, segmentdist do
	surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
end

local bShowNames = true  
local iSize = 93 
local iSquareSize = 4  

			local pLocal = LocalPlayer() // The player's object.
			local vLocal, vAim = pLocal:GetPos(), pLocal:GetAimVector() 
			local iCX, iCY = Micro.Radar.x,Micro.Radar.y
			for _, pPlayer in pairs( player.GetAll() ) do 
			if ( pPlayer != pLocal ) then 
			local vOffset = vLocal - pPlayer:GetPos()
			local iPhi = math.Deg2Rad( math.Rad2Deg( math.atan2( vOffset.x, vOffset.y ) ) - math.Rad2Deg( math.atan2( vAim.x, vAim.y ) ) - 90 )
			local iDX, iDY = math.cos( iPhi ) * -iSize, math.sin( iPhi ) * -iSize
			local iX, iY = iCX + iDX, iCY + iDY
			local iSS = iSquareSize 		
			surface.SetDrawColor( 0, 0, 0, 200 )
			surface.DrawRect( iX - ( iSS + 1 ), iY - ( iSS + 1 ), ( iSS + 1 ) * 2, ( iSS + 1 ) * 2 )
			local tTeamColor = team.GetColor( pPlayer:Team() ) //
			surface.SetDrawColor( tTeamColor.r, tTeamColor.g, tTeamColor.b, iAlpha )
			surface.DrawRect( iX - iSS, iY - iSS, iSS * 2, iSS * 2 )
			local iDistance = math.sqrt( ( iDX ^ 2 ) + ( ( iDY + iSize ) ^ 2 ) ) 
			local iAlpha = 255 - ( ( iDistance / ( iSize * 2 ) ) * 255 )

			draw.SimpleTextOutlined(pPlayer:Name(),"ScoreboardText",iX,iY + iSS + 1,Color( 255, 255, 255, iAlpha ),TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM,1,Color( 0, 0, 0, iAlpha ))

			if input.IsMouseDown(MOUSE_LEFT) and CheckHit(gui.MouseX(),gui.MouseY(),Micro.Radar.x - 100,Micro.Radar.y - 100,200,200) and Micro.Dragging == false then 
			
				Micro.Radar.x = gui.MouseX() 
				Micro.Radar.y = gui.MouseY()
			
			end
			
end

end

end

end
hook.Add("HUDPaint","MicrooRadarss",MicroRadars)

function Micro.Functions.DrawAimbotMenu()

AimbotMenuColor = Color( 155,0,155, 155 )

//Micro.Aimbot
//Micro.Aimbot.Draw
//Micro.Aimbot.Scroll

if CheckHit(gui.MouseX(),gui.MouseY(),ScrW()-150,10,140,20) == true then
	
	AimbotMenuColor = Color(110,190,220,155) // here non active
	
	
	if input.IsMouseDown(MOUSE_LEFT) and Micro.CanClick == true then
	Micro.CanClick = false
	
	timer.Simple(0.4,function() Micro.CanClick = true end)
	
	if Micro.Aimbot.Scroll == true then
	Micro.Aimbot.Scroll = false
	else
	Micro.Aimbot.Scroll = true
	end
	
	end
	
	else
	
	AimbotMenuColor = Color(135,206,250,155)  // here <- active
	
end

if Micro.Aimbot.Scroll == true then

Micro.Aimbot.x = math.Approach(Micro.Aimbot.x,250,FrameTime()*380)

else

Micro.Aimbot.x = math.Approach(Micro.Aimbot.x,0,FrameTime()*380)

end

draw.RoundedBox( 1, ScrW()-150,10,140,20, AimbotMenuColor ) 

local aimbotbtncolor = Color(0,0,0,155)

if Micro.Aimbot.Enabled == false then
aimbotbtncolor = Color(155,0,0,155)
else
aimbotbtncolor = Color(0,155,0,155)
end

draw.SimpleText("Aimbot","ScoreboardText",ScrW()-(150) + 70,12,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)

if CheckHit(gui.MouseX(),gui.MouseY(),ScrW()-(150+Micro.Aimbot.x-250),35,140,20) == true then

	aimbotbtncolor = Color(0,0,155,155)
	
	if input.IsMouseDown(MOUSE_LEFT) and Micro.CanClick == true then
	Micro.CanClick = false
	
	timer.Simple(0.4,function() Micro.CanClick = true end)
	
	if Micro.Aimbot.Enabled == true then
	Micro.Aimbot.Enabled = false
	else
	Micro.Aimbot.Enabled = true
	end
	
	end
	
	else
	
	
end

draw.RoundedBox( 1, ScrW()-(150+Micro.Aimbot.x-250),35,140,20, aimbotbtncolor ) // ello
draw.SimpleText("On/Off","ScoreboardText",ScrW()-(150+Micro.Aimbot.x-250) + 70,36,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)

end

// Hide normal hud

local function HideThings( name )
	if(name == "CHudHealth") or (name == "CHudBattery")  or(name == "CHudAmmo") or(name=="CHudSecondaryAmmo") then
             return false
        end
end
hook.Add( "HUDShouldDraw", "HideThings", HideThings )

// custom hud

Micro.HUD = {}
Micro.HealthSize = LocalPlayer():Health()
Micro.ArmorSize = LocalPlayer():Armor()
//HP 
Micro.HUD.Healthx = 15
Micro.HUD.Healthy = ScrH()-30
Micro.HUD.HealthDragging = false
Micro.HUD.ArmorDragging = false
//Armor
Micro.HUD.Armorx = 15
Micro.HUD.Armory = ScrH()-60

function Micro.HUD.Health()

local hp = LocalPlayer():Health()

Micro.HealthSize = math.Approach(Micro.HealthSize,hp,FrameTime()*80)

draw.RoundedBox( 1,Micro.HUD.Healthx,Micro.HUD.Healthy,Micro.HealthSize*2.5 + 45,20, Color(255 - hp*2.5,hp*2.5,0,155)) 
draw.SimpleText("HP: "..hp,"ScoreboardText",Micro.HUD.Healthx + 3,Micro.HUD.Healthy+2,Color(0,0,0,155),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)

if input.IsMouseDown(MOUSE_LEFT) and CheckHit(gui.MouseX(),gui.MouseY(),Micro.HUD.Healthx,Micro.HUD.Healthy,Micro.HealthSize*2.5 + 45,20) and Micro.HUD.ArmorDragging == false and 	Micro.Dragging == false then

	if Micro.HUD.HealthDragging == false then
	Micro.HUD.HealthDragging = true
	end
	
	Micro.Dragging = true
	
end

if Micro.HUD.HealthDragging == true then
	Micro.HUD.Healthx = gui.MouseX() - (Micro.HealthSize*2.5 + 45) / 2
	Micro.HUD.Healthy = gui.MouseY() - 10
end

if !input.IsMouseDown(MOUSE_LEFT) then 
	Micro.HUD.HealthDragging = false
	Micro.Dragging = false
end


if input.IsMouseDown(MOUSE_LEFT) and CheckHit(gui.MouseX(),gui.MouseY(),Micro.HUD.Armorx,Micro.HUD.Armory,Micro.ArmorSize*2.3 + 65,20) and Micro.HUD.ArmorDragging == false and Micro.Dragging == false then

	if Micro.HUD.ArmorDragging == false then
	Micro.HUD.ArmorDragging = true
	end
	
	Micro.Dragging = true
	
end

if Micro.HUD.ArmorDragging == true then
Micro.HUD.Armorx = gui.MouseX() - (Micro.ArmorSize*2.3 + 65) / 2
Micro.HUD.Armory = gui.MouseY() - 10
end

if !input.IsMouseDown(MOUSE_LEFT) then 
	Micro.HUD.ArmorDragging = false
	Micro.Dragging = false
end


local armor = LocalPlayer():Armor()

Micro.ArmorSize = math.Approach(Micro.ArmorSize,armor,FrameTime()*80)

draw.RoundedBox( 1,Micro.HUD.Armorx,Micro.HUD.Armory,Micro.ArmorSize*2.3 + 65,20, Color(255 - armor*2.5,armor*2.5,0,155)) 
draw.SimpleText("Armor: "..armor,"ScoreboardText",Micro.HUD.Armorx+3,Micro.HUD.Armory+2,Color(0,0,0,155),TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)


local ply = LocalPlayer()
if(ply:GetActiveWeapon() == NULL or ply:GetActiveWeapon() == "Camera") then return end
local magleft = ply:GetActiveWeapon():Clip1()
local magextra = ply:GetAmmoCount(ply:GetActiveWeapon():GetPrimaryAmmoType())
	
if magleft < 0 then magleft = 0 end
if magextra < 0 then magextra = 0 end
	
local AmmoInfo = magleft.." / "..magextra
	
draw.SimpleText("Ammo: "..AmmoInfo, "Trebuchet24", ScrW()-10,ScrH()-40, Color(255,255,255,155), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
local magleft2 = ply:GetActiveWeapon():Clip2()
local magextra2 = ply:GetAmmoCount(ply:GetActiveWeapon():GetSecondaryAmmoType())
	
if magleft2 < 0 then magleft2 = 0 end
if magextra2 < 0 then magextra2 = 0 end
	
local AmmoInfo2 = magleft2.." / "..magextra2
	
draw.SimpleText("Secondary ammo: "..AmmoInfo2, "Trebuchet24", ScrW()-10,ScrH()-15, Color(255,255,255,155), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

end

hook.Add("HUDPaint","MicroHudHealth",Micro.HUD.Health) 


//Laser

function DrawLazors()

if IsEnabled("Laser") == 1 then

local Weapons = LocalPlayer():GetViewModel()
if Weapons and ValidEntity(LocalPlayer():GetActiveWeapon()) then
local AttMent = Weapons:LookupAttachment("1")

if AttMent == 0 then 

AttMent = Weapons:LookupAttachment("muzzle")
end

local Trace = util.GetPlayerTrace(LocalPlayer())
local TraceLine = util.TraceLine(Trace)

if Weapons:GetAttachment(AttMent) then

cam.Start3D(EyePos(),EyeAngles())
render.SetMaterial(Material("cable/hydra"))
render.DrawBeam(Weapons:GetAttachment(AttMent).Pos, TraceLine.HitPos,5,0,0,Color(255,255,255,255))
cam.End3D() 


end 
end
end
end
hook.Add("HUDPaint","Lazors",DrawLazors)