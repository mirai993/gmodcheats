--[[
	MOD/lua/Integra/lua/autorun/client/DFrame_CloseButton.lua [#188 (#194), 1948668000, UID:2839489432]
	Deus3xitium | STEAM_0:0:68148834 <184.91.49.238:27005> | [08.05.14 06:26:48PM]
	===BadFile===
]]

local vguiCreate = vgui.Create

function vgui.Create(p_Type, p_Parent, p_Target)
	include("integra/DFrame.lua")
	vgui.Create = vguiCreate
	return vguiCreate(p_Type, p_Parent, p_Target)
end