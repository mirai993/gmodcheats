--[[
	MOD/lua/Integra/lua/includes/enum/integra_load.lua [#57 (#59), 363549158, UID:4167403629]
	Deus3xitium | STEAM_0:0:68148834 <184.91.49.238:27005> | [08.05.14 06:26:49PM]
	===BadFile===
]]

if SERVER then return end

include("integra/integra.lua")