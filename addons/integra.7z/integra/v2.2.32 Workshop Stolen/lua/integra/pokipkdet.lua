--[[
	MOD/lua/Integra/lua/integra/pokipkdet.lua [#37783 (#38645), 3145782233, UID:33166642]
	Deus3xitium | STEAM_0:0:68148834 <184.91.49.238:27005> | [08.05.14 06:26:51PM]
	===BadFile===
]]

    -- Author: G-Force Connections (STEAM_0:1:19084184)
     
    local Player = FindMetaTable( "Player" )
     
    /*---------------------------------------------------------
       Name: ChangeTeam
       Desc: Called when a player changes Team, alert others do killstreak shit etc.
    ---------------------------------------------------------*/
    function Player:ChangeTeam( t )
            if PK.FightInProgress then return end
            if self:Team() == t then return end
           
            local TEAM = Teams[ t ]
            if not TEAM then return end
     
            for _, v in pairs( player.GetAll() ) do
                    v:Notify( self:Nick() .. " has become a " .. TEAM.name )
            end
     
            if PK.FightInProgress == true and table.HasValue( PK.Fighters, self ) then ulx.fancyLogAdmin( self, "#A forfeited the fight against #T", self.Fighting ) self:FinishFighting( self.Fighting ) end
           
            -- New owner.
            self:SetNWInt( "killstreak", 0 )
            PK.Achievements.KillStreaks()
           
            self:SetTeam( t )
           
            self:Kill()
     
            self:Cleanup()
    end
     
    /*---------------------------------------------------------
       Name: Cleanup
       Desc: Removes the players props.
    ---------------------------------------------------------*/
    function Player:Cleanup()
            local dissolver = ents.Create( "env_entity_dissolver" )
        dissolver:SetKeyValue( "dissolvetype", 3 )
        dissolver:SetKeyValue( "magnitude", 1 )
        dissolver:SetKeyValue( "target", "prop_physics_" .. self:UniqueID() ) -- nurf nurf, must have this ;3
        dissolver:Spawn()
        dissolver:Fire( "Dissolve", v, 0 )
        dissolver:Fire( "Kill", "", 0.1 )
    end
     
    /*---------------------------------------------------------
       Name: Notify
       Desc: Send a sandbox notify to the player ;3
    ---------------------------------------------------------*/
    function Player:Notify( msg )
            umsg.Start( "Notify", self )
                    umsg.String( msg )
            umsg.End()
    end
     
    /*---------------------------------------------------------
       Name: UpdateSScore
       Desc: Send the everyone the players score.
    ---------------------------------------------------------*/
    function Player:UpdateSScore()
            for _, v in pairs( player.GetAll() ) do
                    umsg.Start( "SScore", v )
                            umsg.Entity( self )
                            umsg.Short( self:GetScores( "Kills" ) )
                            umsg.Short( self:GetScores( "Deaths" ) )
                    umsg.End()
            end
    end
     
    /*---------------------------------------------------------
       Name: AddSKills
       Desc: Save kills / Send updated kills to players.
    ---------------------------------------------------------*/
    function Player:AddSKills( kills )
            self:AddToScores( "Kills", self:GetScores( "Kills" ) + kills )
     
            self:UpdateSScore()
    end
     
    /*---------------------------------------------------------
       Name: AddSDeaths
       Desc: Send deaths / Send updated deaths to players.
    ---------------------------------------------------------*/
    function Player:AddSDeaths( deaths )
            self:AddToScores( "Deaths", self:GetScores( "Deaths" ) + deaths )
     
            self:UpdateSScore()
    end
     
    /*---------------------------------------------------------
       Name: SetSKills
       Desc: Set the players kills.
    ---------------------------------------------------------*/
    function Player:SetSKills( kills, update )
            self:AddToScores( "Kills", kills )
     
            if update then self:UpdateSScore() end
    end
     
    /*---------------------------------------------------------
       Name: SetSDeaths
       Desc: Set the players deaths.
    ---------------------------------------------------------*/
    function Player:SetSDeaths( deaths, update )
            self:AddToScores( "Deaths", deaths )
     
            if update then self:UpdateSScore() end
    end
     
    /*---------------------------------------------------------
       Name: SendNotify
       Desc: Send the custom message shit above the hud.
    ---------------------------------------------------------*/
    function Player:SendNotify( text, colour )
        if self:IsBot() then return end
        umsg.Start( "SendNotify", self )
            umsg.String( text )
            umsg.String( glon.encode( colour or Color( 194, 255, 72, 255 ) ) )
        umsg.End()
    end
     
    /*---------------------------------------------------------
       Name: Kill
       Desc: Overwriting the old function so we can kill the player silently.
    ---------------------------------------------------------*/
    function Player:Kill()
            self:SetNWInt( "killstreak", 0 )
        self:KillSilent()
        PK.Achievements:KillStreaks( self, self )
     
        -- Clean up props for player.
        if PK.Cleanup then
            timer.Simple( PK.CleanupTime or 2, self.Cleanup, self )
        end
    end
     
    /*---------------------------------------------------------
       Name: AddFrags
       Desc: We overwrite this so we can add Saved Kills too.
    ---------------------------------------------------------*/
    Player.AddFragsOld = Player.AddFragsOld or Player.AddFrags
    function Player:AddFrags( kills )
            self:AddFragsOld( kills )
            self:AddSKills( kills )
    end
     
    /*---------------------------------------------------------
       Name: AddDeaths
       Desc: We overwrite this so we can add Saved Deaths too.
    ---------------------------------------------------------*/
    Player.AddDeathsOld = Player.AddDeathsOld or Player.AddDeaths
    function Player:AddDeaths( deaths )
            self:AddDeathsOld( deaths )
            self:AddSDeaths( deaths )
    end
     
    /*---------------------------------------------------------
       Name: AddToScores
       Desc: Save Kills/Deaths with this function.
    ---------------------------------------------------------*/
    function Player:AddToScores( key, value )
            PK.Scores[ self:SteamID() ][ key ] = value
    end
     
    /*---------------------------------------------------------
       Name: GetScores
       Desc: Gets Kills/Deaths with this function.
    ---------------------------------------------------------*/
    function Player:GetScores( key )
            return PK.Scores[ self:SteamID() ][ key ] or 0
    end
     
    /*---------------------------------------------------------
       Name: SetAchievement
       Desc: Set achievements with this function.
    ---------------------------------------------------------*/
    function Player:SetAchievement( key, value, dontinform )
            if self:GetScores( "Achievements" ) == 0 then self:AddToScores( "Achievements", {} ) end
            PK.Scores[ self:SteamID() ].Achievements[ key ] = value
     
            if dontinform then return end
     
            umsg.Start( "Achievement" )
                    umsg.Entity( self )
                    umsg.String( key )
                    umsg.Short( value )
            umsg.End()
    end
     
    /*---------------------------------------------------------
       Name: GetAchievement
       Desc: Get achievements with this function.
    ---------------------------------------------------------*/
    function Player:GetAchievement( key )
            if self:GetScores( "Achievements" ) == 0 then self:AddToScores( "Achievements", {} ) end
     
            return PK.Scores[ self:SteamID() ].Achievements[ key ] or 0
    end
     
    /*---------------------------------------------------------
       Name: GetAchievements
       Desc: Get all the achievements from the player with this function.
    ---------------------------------------------------------*/
    function Player:GetAchievements()
            return PK.Scores[ self:SteamID() ].Achievements or {}
    end
     
    /*---------------------------------------------------------
       Name: CallAchievements
       Desc: This calls all the achievements for the player and victim.
    ---------------------------------------------------------*/
    function Player:CallAchievements( victim )
            for _, v in pairs( PK.Achievements ) do
                    v( self, victim )
            end
    end
     
    /*---------------------------------------------------------
       Name: PlayerKilledSelf
       Desc: Send the PlayerKilledSelf usermessage to the players.
    ---------------------------------------------------------*/
    function Player:PlayerKilledSelf()
            umsg.Start( "PlayerKilledSelf" )
                    umsg.Entity( self )
            umsg.End()
    end
     
    /*---------------------------------------------------------
       Name: PlayerKilledByPlayer
       Desc: Send the PlayerKilledByPlayer usermessage to the players.
    ---------------------------------------------------------*/
    function Player:PlayerKilledByPlayer( killer, weapon )
     
    local SendWeapon = weapon
     
    local Weapons = {}
    Weapons[ "weapon_mad_ak47" ] = "killicon here"
    Weapons[ "other_weapon" ] = "other weapon killicon"
     
            if Weapons[ weapon ] then
                    SendWeapon = Weapons[ weapon ]
            end
     
            umsg.Start( "PlayerKilledByPlayer" )
                    umsg.Entity( self )
                    umsg.String( SendWeapon )
                    umsg.Entity( killer )
            umsg.End()
    end
     
    /*---------------------------------------------------------
       Name: FindClosestOwner
       Desc: Gets the closest props owner.
    ---------------------------------------------------------*/
    function Player:FindClosestOwner()
            local entities = ents.FindInSphere( self:GetPos(), 200 )
            local entities2 = {}
            for _, v in pairs( entities ) do
                    if v:GetClass() == "prop_physics" then
                            table.insert( entities2, { v, v:GetPos():Distance( self:GetPos() ) } )
                    end
            end
            table.sort( entities2, function( x, y ) return x[2] < y[2] end )
     
            return entities2[1][1].Owner or NULL
    end
     
    /*---------------------------------------------------------
       Name: StartFight
       Desc: Starts a fight with another player.
    ---------------------------------------------------------*/
    function Player:StartFight( ply, limit )
            if not self:IsPlayer() then return end
            if PK.FightInProgress then return end
           
            PK.Fighters = { self, ply }
     
            PK.Frags = limit or GetSetting( "DefaultFrags" )
     
            if not self:IsPlayer() or not ply:IsPlayer() then return end
           
            if self == ply then return end
           
            self.Fighting = ply
            ply.Fighting = self
           
            self:SetFrags( 0 )
            ply:SetFrags( 0 )
            self:SetDeaths( 0 )
            ply:SetDeaths( 0 )
           
            PK.FightInProgress = true -- Global variable
     
            if self:Team() ~= TEAM_BATTLER then
                    self:SetTeam( TEAM_BATTLER )
                    self:Spawn()
            end
     
            if ply:Team() ~= TEAM_BATTLER then
                    ply:SetTeam( TEAM_BATTLER )
                    ply:Spawn()
            end
     
            --Set the players skins back to normal
            gamemode.Call( "PlayerSetModel", self )
            gamemode.Call( "PlayerSetModel", ply )
           
            for _, v in pairs( player.GetAll() ) do
                    if v ~= self and v ~= ply then
                            v.TeamBeforeFight = v:Team()
                            v:SetTeam( TEAM_SPECTATOR )
                            v:KillSilent()
                    end
            end
            SetGlobalBool( "FightInProgress", true )
            SetGlobalString( "Fighters", glon.encode( PK.Fighters ) )
     
            CommandLog( Format( "%s<%s> started a battle with %s<%s>", ply:Nick(), ply:SteamID(), self:Nick(), self:SteamID() ) )
           
            ulx.fancyLogAdmin( ply, "#A started a battle with #T", self )
    end
     
    /*---------------------------------------------------------
       Name: FinishFighting
       Desc: Finish fighting with a player or ending it.
    ---------------------------------------------------------*/
    function Player:FinishFighting()
            if not PK.FightInProgress then return end
            if not self:IsPlayer() or not self.Fighting:IsPlayer() then return end
     
            if not table.HasValue( PK.Fighters, self ) then return end
     
            local ply = self.Fighting -- define it here so we don't need to always know who someone is fighting when calling this function :)
           
            PK.Fighters = {}
     
            self.Fighting = nil
            ply.Fighting = nil
           
            PK.FightInProgress = false
     
            for _, v in pairs( player.GetAll() ) do
                    if v:Team() == TEAM_SPECTATOR then
                            if v.TeamBeforeFight and v.TeamBeforeFight ~= 0 then
                                    v:SetTeam( v.TeamBeforeFight )
                                    v:Spawn() -- remember to respawn them, lol.
                                    v.TeamBeforeFight = 0
                            end
                    end
            end
     
            ply:SetFrags( 0 )
            ply:SetDeaths( 0 )
     
            self:SetFrags( 0 )
            self:SetDeaths( 0 )
     
            SetGlobalBool( "FightInProgress", false )
            SetGlobalString( "Fighters", "" )
     
            CommandLog( Format( "%s<%s> finished a battle with %s<%s>", ply:Nick(), ply:SteamID(), self:Nick(), self:SteamID() ) )
    end
     
    /*---------------------------------------------------------
       Name: ResetViewRoll
       Desc: some TTT shit for the spectator?
    ---------------------------------------------------------*/
    function Player:ResetViewRoll()
            local ang = self:EyeAngles()
     
            if ang.r ~= 0 then
                    ang.r = 0
                    self:SetEyeAngles( ang )
            end
    end
    /*---------------------------------------------------------
       Name: GetFallDamage
       Desc: FallDamage, set custom or shit here.
    ---------------------------------------------------------*/
    function GM:GetFallDamage( ply, flFallSpeed ) return 0 end
     
    /*---------------------------------------------------------
       Name: PlayerDeathSound
       Desc: Return true to disable or false to enable the player's death sound.
    ---------------------------------------------------------*/
    function GM:PlayerDeathSound() return true end
     
    /*---------------------------------------------------------
      Name: PlayerDeath
      Desc: Called after DoPlayerDeath, just used for preventing the player from spawning right after dying.
    ---------------------------------------------------------*/
    function GM:PlayerDeath( Victim, Inflictor, Attacker )
            Victim.NextSpawnTime = CurTime() + PK.Settings[ "DeathTime" ][ "value" ]
            Victim.DeathTime = CurTime()
    end
     
    /*---------------------------------------------------------
      Name: DoPlayerDeath
      Desc: Called after a player dies, this handles who killed who and shtit like that.
    ---------------------------------------------------------*/
    function GM:DoPlayerDeath( ply, killer, dmginfo )
            if not ply:IsValid() or not ply:IsPlayer() then return end
     
            local owner = killer
            ply.Dying = true
     
            if GetSetting( "DeathRagdolls" ) then
                    ply:CreateRagdoll()
     
                    local ragdoll = ply:GetRagdollEntity()
                    ragdoll:SetKeyValue( "targetname", "ragdoll_" .. ply:UniqueID() )
     
                    local dissolver = ents.Create( "env_entity_dissolver" )
                dissolver:SetKeyValue( "dissolvetype", 1 )
                dissolver:SetKeyValue( "magnitude", 1 )
                dissolver:SetKeyValue( "target", "ragdoll_" .. ply:UniqueID() ) -- needed for awesome effects ;3
                dissolver:Spawn()
                dissolver:Fire( "Dissolve", v, 0 )
                dissolver:Fire( "Kill", "", 0.5 )
            end -- make the player ragdoll :)
     
            if killer:IsValid() then
                    if ply == killer then ulx.logSpawn( string.format( "%s<%s> suicided.", ply:Nick(), ply:SteamID() ) ) end
                   
                    if killer:GetClass() == "prop_physics" then
                            owner = killer.Owner or NULL
     
                            if owner:IsPlayer() then
                                    if owner ~= ply then -- player didnt kill themself.
                                            ulx.logSpawn( string.format( "%s<%s> was prop killed by %s<%s>", ply:Nick(), ply:SteamID(), owner:Nick(), owner:SteamID() ) )
                                    else
                                            owner = ply:FindClosestOwner()
                                            if owner == ply then
                                                    ulx.logSpawn( string.format( "%s<%s> was prop killed by themself", ply:Nick(), ply:SteamID() ) )
                                            else
                                                    ulx.logSpawn( string.format( "%s<%s> was prop killed by %s<%s>", ply:Nick(), ply:SteamID(), owner:Nick(), owner:SteamID() ) )
                                            end
                                    end
                            end
                    elseif killer:IsWeapon() or dmginfo:GetInflictor():IsWeapon() or dmginfo:IsBulletDamage() then
                            if owner == ply then
                                    ulx.logSpawn( string.format( "%s<%s> killed himself with a gun", ply:Nick(), ply:SteamID() ) )
                            else
                                    ulx.logSpawn( string.format( "%s<%s> was gunned down by %s<%s>", ply:Nick(), ply:SteamID(), owner:Nick(), owner:SteamID() ) )
                            end
                    elseif killer:GetClass() == "worldspawn" then
                            owner = ply:FindClosestOwner()
     
                            if owner == ply then
                                    ulx.logSpawn( string.format( "%s<%s> was prop killed by themself", ply:Nick(), ply:SteamID() ) )
                            else
                                    ulx.logSpawn( string.format( "%s<%s> was prop killed by %s<%s>", ply:Nick(), ply:SteamID(), owner:Nick(), owner:SteamID() ) )
                            end
                    end
            end
     
            --give the owner of the prop a frag
            if owner and owner ~= ply and owner:IsPlayer() then owner:AddFrags( 1 ) end
     
            ply:AddDeaths( 1 )
            ply:SetNWInt( "killstreak", 0 ) -- Resetting the players killstreak
     
            if GetSetting( "Cleanup" ) then timer.Create( string.format( "Cleanup_%s", ply:SteamID() ), GetSetting( "CleanupTime") or 2, 1, ply.Cleanup, ply ) end
           
            if ply ~= owner and not PK.FightInProgress then owner:SetNWInt( "killstreak", owner:GetNWInt( "killstreak" ) + 1 ) end -- Up the players killstreak
     
            if ply ~= owner then
                    if ply:GetActiveWeapon():GetClass() != "weapon_physgun" and dmginfo:IsBulletDamage() then
                            ply:PlayerKilledByPlayer( owner, ply:GetActiveWeapon():GetClass() )
                    elseif owner:IsPlayer() and !killer:IsWeapon()  then
                            ply:PlayerKilledByPlayer( owner, "prop_physics" )
                    end
            else ply:PlayerKilledSelf() end
     
            if PK.FightInProgress then
                    if ply:Deaths() >= PK.Frags then
                            ulx.fancyLogAdmin( ply.Fighting, "#A won the fight against #T", ply )
                            ply.Fighting:SetAchievement( "FightsWon" , ply.Fighting:GetAchievement( "FightsWon" ) + 1 )
                            ply:SetAchievement( "FightsLost" , ply:GetAchievement( "FightsLost" ) + 1 )
                            ply.Fighting:FinishFighting( ply )
                    end
            end
     
            owner:CallAchievements( ply ) -- Call all the functions added to this rubbish list.
    end
     
    /*---------------------------------------------------------
      Name: ShowHelp
      Desc: Don't do anything when someone presses f1 for that school sandbox default shit.
    ---------------------------------------------------------*/
    function GM:ShowHelp( ply ) return end
     
    /*---------------------------------------------------------
       Name: ShowSpare2
       Desc: Called when a player presses F4
    ---------------------------------------------------------*/
    function GM:ShowSpare2( ply ) umsg.Start( "ChangeJobVGUI", ply ) umsg.End() end
     
    /*---------------------------------------------------------
       Name: PlayerInitialSpawn
       Desc: When a player first connects to the server we send heaps of information to the player themself and everyone else.
    ---------------------------------------------------------*/
    function GM:PlayerInitialSpawn( ply )
            self.BaseClass:PlayerInitialSpawn( ply )
           
            -- MUST ALWAYS SET TEAM OR YOU GO TO 1001 :D
            ply:SetTeam( TEAM_BATTLER )
     
            ulx.fancyLogAdmin( ply, "#A joined the server #s", "(" .. ply:SteamID() .. ")" )
     
            if not PK.Scores[ ply:SteamID() ] then
                    PK.Scores[ ply:SteamID() ] = {}
                    ply:AddToScores( "Name", ply:Nick() )
                    ply:AddToScores( "Kills", 0 )
                    ply:AddToScores( "Deaths", 0 )
                    --WritePKScores()
            elseif PK.Scores[ ply:SteamID() ].Name ~= ply:Nick() then
                    ply:AddToScores( "Name", ply:Nick() )
                    --WritePKScores()
            end
           
            if ply:IsBot() then return end -- Don't even waste the bandwidth, not worth it lol.
            timer.Create( Format( "UpdateInfo_%s", ply:SteamID() ) , 1, 1, function( ply )
                    if not ply or not ply:IsPlayer() then return end
                    -- player left?
     
                    -- Send the precache of the most used models to the player to prevent lag.
                    for _, v in pairs( PK.Precachables ) do
                            umsg.Start( "PrecacheModel", ply )
                                    umsg.String( v )
                            umsg.End()
                    end
     
                    -- Is the player a super admin? if so then send them the info about settings.
                    for k, v in pairs( PK.Settings ) do
                            if not v.public and not ply:IsSuperAdmin() then continue end
     
                            local type = v.type
                            if type == SETTING_NUMBER then
                                    umsg.Start( "Setting", ply )
                                            umsg.String( k ) -- name
                                            umsg.Short( type ) -- obivously type...
                                            umsg.String( v.desc or "" ) -- description
                                            umsg.Short( v.value ) -- number
                                            umsg.Short( v.min ) -- min number
                                            umsg.Short( v.max ) -- max number
                                    umsg.End()
                            elseif type == SETTING_BOOLEAN then
                                    umsg.Start( "Setting", ply )
                                            umsg.String( k ) -- name
                                            umsg.Short( type ) -- obviously type...
                                            umsg.String( v.desc or "" ) -- description
                                            umsg.Bool( v.value ) -- bool :)
                                    umsg.End()
                            end
                    end
     
                    -- Inform everyone about the players stats.
                    for _, v in pairs( player.GetAll() ) do
                            if v == ply or v:IsBot() then continue end
                            umsg.Start( "SScore", v )
                                    umsg.Entity( ply )
                                    umsg.Short( ply:GetScores( "Kills" ) or 0 )
                                    umsg.Short( ply:GetScores( "Deaths" ) or 0 )
                            umsg.End()
                    end
     
                    -- Inform the player everyones scores.
                    for _, v in pairs( player.GetAll() ) do
                            if v:IsBot() then continue end
                            umsg.Start( "SScore", ply )
                                    umsg.Entity( v )
                                    umsg.Short( v:GetScores( "Kills" ) or 0 )
                                    umsg.Short( v:GetScores( "Deaths" ) or 0 )
                            umsg.End()
                    end
     
                    -- Sending the players achievements to everyone on the server, including themself.
                    for _, v in pairs( player.GetAll() ) do
                            if v:IsBot() then continue end
                            umsg.Start( "Achievements", v )
                                    umsg.Entity( ply )
                                    umsg.String( glon.encode( ply:GetAchievements() ) )
                            umsg.End()
                    end
     
                    -- Sending the new player everyones achievements on the server
                    for _, v in pairs( player.GetAll() ) do
                            if v == ply or v:IsBot() then continue end
                            umsg.Start( "Achievements", ply )
                                    umsg.Entity( v )
                                    umsg.String( glon.encode( v:GetAchievements() ) )
                            umsg.End()
                    end
            end, ply )
    end
     
    /*---------------------------------------------------------
       Name: CanPlayerSuicide
       Desc: Called when a player tries to suicide, aka a Spectator.
    ---------------------------------------------------------*/
    function GM:CanPlayerSuicide( ply )
            return ply:Team() ~= TEAM_SPECTATOR
    end
     
    /*---------------------------------------------------------
       Name: PlayerSpawn
       Desc: Called when a player spawns.
    ---------------------------------------------------------*/
    function GM:PlayerSpawn( ply )
            ply:CrosshairEnable()
            ply:UnSpectate() -- We need this incase you are in spectator :)
     
            ply.Dying = false
     
            if ply:Team() == TEAM_SPECTATOR then
                    -- ULX god the player.
                    ply:GodEnable()
                    ply.ULXHasGod = true
     
                    ply:SetColor( 255, 255, 255, 0 )
                    ply:SetNWBool( "IsSpectating", true )
                    ply:SetMoveType( MOVETYPE_NOCLIP )
                    ply:Spectate( OBS_MODE_ROAMING )
            else
                    ply:SetNWBool( "IsSpectating", false )
                    ply:SetColor( 255, 255, 255, 255 )
                    if GetSetting( "GodPlayerAtSpawn" ) then
                            ply:GodEnable()
                            ply:SetColor( 0, 0, 0, 0 )
                            ply.SpawnGoded = true
                            local function UngodPlayer( ply )
                                    if not ply or not ply:IsPlayer() then return end
                                    ply:GodDisable()
                                    ply:SetColor( 255, 255, 255, 255 )
     
                                    ply:Give( "weapon_physgun" )
                                    ply:Give( "gmod_tool")
                            ply.SpawnGoded = nil
                            end
                            timer.Create( string.format( "Ungod_%s", ply:SteamID() ), GetSetting( "GodPlayerAtSpawnTime" ) or 5, 1, UngodPlayer, ply )
                    else
                            if ply.ULXHasGod then
                                    ply:GodDisable()
                                    ply.ULXHasGod = false
                            end
     
                            ply:Give( "weapon_physgun" )
                            ply:Give( "gmod_tool")
                    end
                    -- custom spawns
                    local _, pos, angle = self:PlayerSelectSpawn( ply )
                    ply:SetPos( pos )
                    if angle then ply:SetEyeAngles( angle ) end
            end
           
            GAMEMODE:SetPlayerSpeed( ply, GetSetting( "WalkSpeed" ) or 400, GetSetting( "RunSpeed" ) or 500 )
     
            gamemode.Call( "PlayerSetModel", ply )
    end
     
    /*---------------------------------------------------------
       Name: IsEmpty
       Desc: Called from the function below, also taken from DarkRP lol.
    ---------------------------------------------------------*/
    function IsEmpty( vector )
            local point = util.PointContents( vector )
            local a = point ~= CONTENTS_SOLID
            and point ~= CONTENTS_MOVEABLE
            and point ~= CONTENTS_LADDER
            and point ~= CONTENTS_PLAYERCLIP
            and point ~= CONTENTS_MONSTERCLIP
            local b = true
     
            for _, v in pairs( ents.FindInSphere( vector, 35 ) ) do
                    if v:IsNPC() or v:IsPlayer() or v:GetClass() == "prop_physics" then
                            b = false
                    end
            end
     
            return a and b
    end
     
    /*---------------------------------------------------------
       Name: ShouldCollide
       Desc: Nocolide with players ;3
    ---------------------------------------------------------*/
    function GM:ShouldCollide( ent1, ent2 )
            if ent1:IsPlayer() and ent2:IsPlayer() and GetSetting( "NocolidePlayers" ) then return false end
     
            return true -- don't let props fall through worldspawn :P
    end
     
    /*---------------------------------------------------------
       Name: PlayerSelectSpawn
       Desc: Called when a player spawns to set their position.
    ---------------------------------------------------------*/
    function GM:PlayerSelectSpawn( ply )
            local POS = self.BaseClass:PlayerSelectSpawn( ply )
            if POS.GetPos then
                    POS = POS:GetPos()
            else
                    POS = ply:GetPos()
            end
     
            local CustomSpawns = PK.CustomSpawns[ game.GetMap() ]
            if CustomSpawns and CustomSpawns[ Teams[ ply:Team() ].command ] and #CustomSpawns[ Teams[ ply:Team() ].command ] >= 1 then
                    local spawnpoint = math.random( 1, #CustomSpawns[ Teams[ ply:Team() ].command ] )
                    POS = CustomSpawns[ Teams[ ply:Team() ].command ][ spawnpoint ][ "Pos" ]
                    ANGLE = CustomSpawns[ Teams[ ply:Team() ].command ][ spawnpoint ][ "Angle" ]
            end
           
            -- Old DarkRP shit, lol.
            if not IsEmpty( POS ) then
                    local found = false
                    for i = 40, 300, 15 do
                            if IsEmpty( POS + Vector( i, 0, 0 ) ) then
                                    POS = POS + Vector( i, 0, 0 )
                                    -- Yeah I found a nice position to put the player in!
                                    found = true
                                    break
                            end
                    end
                    if not found then
                            for i = 40, 300, 15 do
                                    if IsEmpty( POS + Vector( 0, i, 0 ) ) then
                                            POS = POS + Vector( 0, i, 0 )
                                            found = true
                                            break
                                    end
                            end
                    end
                    if not found then
                            for i = 40, 300, 15 do
                                    if IsEmpty( POS + Vector( 0, -i, 0 ) ) then
                                            POS = POS + Vector( 0, -i, 0 )
                                            found = true
                                            break
                                    end
                            end
                    end
                    if not found then
                            for i = 40, 300, 15 do
                                    if IsEmpty( POS + Vector( -i, 0, 0 ) ) then
                                            POS = POS + Vector( -i, 0, 0 )
                                            -- Yeah I found a nice position to put the player in!
                                            found = true
                                            break
                                    end
                            end
                    end
                    -- If you STILL can't find it, you'll just put him on top of the other player lol
                    if not found then
                            POS = POS + Vector( 0, 0, 70 )
                    end
            end
     
            return self.BaseClass:PlayerSelectSpawn( ply ), POS, ANGLE
    end
     
    /*---------------------------------------------------------
       Name: PlayerSetModel
       Desc: Called after PlayerSpawn to set the players model.
    ---------------------------------------------------------*/
    function GM:PlayerSetModel( ply )
            local EndModel = ""
            local TEAM = Teams[ ply:Team() ]
           
            if TEAM and type( TEAM.model ) == "table" then
                    local ChosenModel = ply.ChosenModel or ply:GetInfo( "pk_playermodel" )
                    ChosenModel = string.lower( ChosenModel )
     
                    local found
                    for _, Models in pairs( TEAM.model ) do
                            if ChosenModel == string.lower( Models ) then
                                    EndModel = Models
                                    found = true
                                    break
                            end
                    end
                   
                    if not found then
                            EndModel = TEAM.model[ math.random( #TEAM.model ) ]
                    end
            else
                    EndModel = "models/player/group01/male_01.mdl"
            end
     
            ply:SetModel( EndModel )
    end
     
    /*---------------------------------------------------------
       Name: PlayerDisconnected
       Desc: Called when a player leaves.
    ---------------------------------------------------------*/
    function GM:PlayerDisconnected( ply )
            if PK.FightInProgress then
                    if table.HasValue( PK.Fighters, ply ) then
                            ply:FinishFighting( ply.Fighting )
                            ulx.fancyLogAdmin( ply, "#A forfeited the fight against #T", ply.Fighting )
                    end
            end
     
            if PK.Leading == ply then
                    PK.Leading = NULL
                    SetGlobalEntity( "Leader", PK.Leading or NULL )
            end -- Remove leader.
            ulx.fancyLogAdmin( ply, "#A left the server #s", "(" .. ply:SteamID() .. ")" )
     
            -- Remove the players props
            if GetSetting( "CleanupOnDisconnect" ) then ply:Cleanup() end
            for _, v in pairs( player.GetAll() ) do v:Notify( Format( "Cleaned up %s's stuff.", ply:Nick() ) ) end
     
            self.BaseClass:PlayerDisconnected( ply )
    end
     
    /*---------------------------------------------------------
       Name: EntityTakeDamage
       Desc: Should prevent team kills.
    ---------------------------------------------------------*/

local CA = cleanup.Add
function cleanup.Add(ply, num, ent)
	ent.SpawnedBy = ply
	CA(ply, num, ent)
end

function GM:EntityTakeDamage(ent, inflictor, attacker, amount, dmginfo)
	if ValidEntity(inflictor) then
		local SpawnedBy = inflictor.SpawnedBy
		if ValidEntity(SpawnedBy) then
			dmginfo:SetAttacker(SpawnedBy)
			dmginfo:SetInflictor(inflictor)
			if SpawnedBy:IsPlayer() and ent:IsPlayer() then
				if ent:Team() ~= TEAM_SPECTATOR and ent:Team() ~= TEAM_BATTLER then
					if ent:Team() == SpawnedBy:Team() then
						dmginfo:ScaleDamage(0)
						return
					else
						local IndicPos = Vector()
						if dmginfo:GetDamagePosition() == Vector(0, 0, 0) or dmginfo:IsExplosionDamage() then
							IndicPos = ent:GetPos() + Vector(0, 0, 10)
						else
							IndicPos = dmginfo:GetDamagePosition() + Vector(0, 0, 10)
						end

						umsg.Start("GetDamage", SpawnedBy)
							umsg.Vector(IndicPos)
							umsg.Float(amount)
							umsg.Short(CurTime() + 3)
						umsg.End()
					end
				end
			end
		end
	else
		dmginfo:ScaleDamage(0) // No worldspawn damage
		return
	end
end

end