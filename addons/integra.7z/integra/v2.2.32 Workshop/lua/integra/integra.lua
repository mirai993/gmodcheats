if SERVER then return end

/*
	Integra v2.232
	- Improved XRay
	- Added spectate
	- Rotate 2
*/

function Color(r, g, b, a)
	return {r = r or 0, g = g or 0, b = b or 0, a = a or 0}
end

local function DrawGradientRectH(x, y, w, h, col1, col2)
	local segments = 1 / h

	for i = 0, h do
		local col = Color((col1.r - (col1.r - col2.r) * segments * i), (col1.g - (col1.g - col2.g) * segments * i), (col1.b - (col1.b - col2.b) * segments * i), (col1.a - (col1.a - col2.a) * segments * i))
		surface.SetDrawColor(col)
		surface.DrawLine(x, y + i, x + w, y + i)
	end
end

local pairs = pairs
local require = require
local unpack = unpack

local Msg = Msg
local MsgN = MsgN
local print = print

local CreateClientConVar = CreateClientConVar
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand
local SetMaterialOverride = SetMaterialOverride

local draw = require("draw")
local hook = require("hook")
local concommand = require("concommand")

require("cvar2")

local GBP = _R.Entity.GetBonePosition
local SEA = _R.Player.SetEyeAngles

local cam = cam
local concommand = concommand
local draw = draw
local hook = hook
local render = render
local surface = surface
local table = table

local dST = draw.SimpleText
local dSTO = draw.SimpleTextOutlined

function draw.SimpleText(text, font, x, y, col, xalign, yalign)
	if (x > -20 and x < ScrW() + 20) and (y > -20 and y < ScrH() + 20) then
		dST(text, font, x, y, col, xalign, yalign)
	end
end

function draw.SimpleTextOutlined(text, font, x, y, col, xalign, yalign, olsize, olcolor)
	if (x > -20 and x < ScrW() + 20) and (y > -20 and y < ScrH() + 20) then
		dSTO(text, font, x, y, col, xalign, yalign, olsize, olcolor)
	end
end

local _T = {}
	_T.CMDPrefix = "int"
	_T.ConVars = {}
	_T.GM = {}
	_T.OnInit = {}
	_T.ValidEntities = {}
	_T.ValidPlayers = {}
	_T.IsActive = CreateClientConVar(_T.CMDPrefix .. "_" .. "enabled", 1, true, false)

// Gamemode Injection

function _T:AppendToGM(hType, func, ret)
	if self.GM[hType] != nil then

		self.GM["TEMP_" .. hType] = self.GM[hType]
		local t_Index = self.GM["TEMP_" .. hType]

		self.GM[hType] = function(...)
			local value = t_Index(...)
			if ret then
				local value2 = func(...)
				if value2 != nil then
					value = value2
				end
			else
				func(...)
			end
			self.GM["TEMP_" .. hType] = nil
			return value
		end
	end
end

local hAdd = hook.Add
local hRemove = hook.Remove

local Chars = {}
	table.insert(Chars, "A")
	table.insert(Chars, "a")
	table.insert(Chars, "B")
	table.insert(Chars, "b")
	table.insert(Chars, "C")
	table.insert(Chars, "c")
	table.insert(Chars, "D")
	table.insert(Chars, "d")
	table.insert(Chars, "E")
	table.insert(Chars, "e")
	table.insert(Chars, "F")
	table.insert(Chars, "f")
	table.insert(Chars, "G")
	table.insert(Chars, "g")
	table.insert(Chars, "H")
	table.insert(Chars, "h")
	table.insert(Chars, "I")
	table.insert(Chars, "i")
	table.insert(Chars, "J")
	table.insert(Chars, "j")
	table.insert(Chars, "K")
	table.insert(Chars, "k")
	table.insert(Chars, "L")
	table.insert(Chars, "l")
	table.insert(Chars, "M")
	table.insert(Chars, "m")
	table.insert(Chars, "N")
	table.insert(Chars, "n")
	table.insert(Chars, "O")
	table.insert(Chars, "o")
	table.insert(Chars, "P")
	table.insert(Chars, "p")
	table.insert(Chars, "Q")
	table.insert(Chars, "q")
	table.insert(Chars, "R")
	table.insert(Chars, "r")
	table.insert(Chars, "S")
	table.insert(Chars, "s")
	table.insert(Chars, "T")
	table.insert(Chars, "t")
	table.insert(Chars, "U")
	table.insert(Chars, "u")
	table.insert(Chars, "V")
	table.insert(Chars, "v")
	table.insert(Chars, "W")
	table.insert(Chars, "w")
	table.insert(Chars, "X")
	table.insert(Chars, "x")
	table.insert(Chars, "Y")
	table.insert(Chars, "y")
	table.insert(Chars, "Z")
	table.insert(Chars, "z")
	table.insert(Chars, "1")
	table.insert(Chars, "2")
	table.insert(Chars, "3")
	table.insert(Chars, "4")
	table.insert(Chars, "5")
	table.insert(Chars, "6")
	table.insert(Chars, "7")
	table.insert(Chars, "8")
	table.insert(Chars, "9")
	table.insert(Chars, "0")

function _T:RandStr(len)
	local str = ""
	for i = 1, len do
		str = str .. Chars[math.random(1, #Chars)]
	end

	return str
end

local rndstr = _T:RandStr(math.random(8, 24))

hAdd("InitPostEntity", rndstr, function()
	_T.GM = GAMEMODE
	for k, v in pairs(_T.OnInit) do
		v()
	end
	_T.OnInit = {}
	hRemove("InitPostEntity", rndstr)
end)

function _T:DoOnInit(func)
	table.insert(self.OnInit, func)
end

function _T:AddCommand(cmd, func)
	concommand.Add(self.CMDPrefix .. "_" .. cmd, function(p, c, a) func(a) end)
end

local m_RunString = RunString
_T:AddCommand("runlua", function(a) m_RunString(unpack(a)) end)

function _T:Hook(type, func, convar, default, ret)
	local function Do()
		if convar != nil then
			_T:CreateConVar(convar, default)
		end

		_T:AppendToGM(type, function(...)
			local args = {...}

			if args[1] != nil then
				table.remove(args, 1)
			end

			if self.IsActive:GetBool() then
				if convar != nil then
					if _T:GetConVar(convar):GetBool() then
						return func(unpack(args))
					end
				else
					return func(unpack(args))
				end
			end
		end, ret)
	end

	_T:DoOnInit(Do)
end

function _T:AddBindCommand(cmd, func, htype, on_callback, off_callback)
	local on = false
	_T:Hook(htype, function()
		if on then
			func()
		end
	end)
	concommand.Add("+" .. _T.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = true
		if on_callback != nil then
			on_callback(a)
		end
	end)
	concommand.Add("-" .. _T.CMDPrefix .. "_" .. cmd, function(p, c, a)
		on = false
		if off_callback != nil then
			off_callback(a)
		end
	end)
end

_T:Hook("Think", function()
	_T.ValidEntities = {}
	_T.ValidPlayers = {}

	for k, v in pairs(ents.GetAll()) do
		if ValidEntity(v) then
			_T.ValidEntities[k] = v
		end
	end

	for k, v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			_T.ValidPlayers[k] = v
		end
	end
end)

function _T:CreateConVar(cmd, default)
	table.insert(_T.ConVars, {cmd = cmd, value = CreateClientConVar(_T.CMDPrefix .. "_" .. cmd, default, true, false)})
end
_T:CreateConVar("enabled", 1)

function _T:GetConVar(cmd)
	for k, v in pairs(_T.ConVars) do
		if v.cmd == cmd then
			return v.value
		end
	end
end

function _T:GetHeadPos(ply)
	if ValidEntity(ply) then
		local hp = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
		if hp != nil then
			return hp
		else
			hp = ply:EyePos()
			if hp != nil then
				return hp
			else
				return ply:GetPos() + Vector(0, 64, 0)
			end
		end
	end
	return Vector(0, 0, 0)
end

function _T:IsVisible(ent)
	if ValidEntity(ent) then
		local tr = {}
			tr.start = EyePos()
			tr.endpos = ent:GetPos()
			if ent:IsPlayer() or ent:IsNPC() then
				tr.endpos = _T:GetHeadPos(ent)
			end
			tr.mask = MASK_SHOT
			tr.filter = LocalPlayer()
		local trace = util.TraceLine(tr)

		if trace.Entity == ent then
			return true
		else
			return false
		end
	else
		return false
	end
end

// X-Ray Vision

local XRAY_SOLID_MAT = Material("models/debug/debugwhite")
local XRAY_WIREFRAME_MAT = Material("models/wireframe")

local XRayValidEnts = {}
	XRayValidEnts["prop_door_rotating"] = {col = {r = 1, g = 1, b = 1}, blend = 0.5, ignorez = false}
	XRayValidEnts["prop_dynamic"] = {col = {r = 0.5, g = 0.5, b = 1}, mat = XRAY_SOLID_MAT, blend = 0.5, ignorez = true}
	XRayValidEnts["prop_static"] = {col = {r = 0.5, g = 0.5, b = 1}, mat = XRAY_SOLID_MAT, blend = 0.5, ignorez = true}
	XRayValidEnts["prop_physics"] = {col = {r = 0.5, g = 1, b = 0}, mat = XRAY_SOLID_MAT, blend = 0.5, ignorez = true}
	XRayValidEnts["prop_vehicle"] = {col = {r = 0, g = 1, b = 0.5}, mat = XRAY_SOLID_MAT, blend = 0.5, ignorez = true}

local XRayEnts = {}

local function AddXRayEnt(ent)
	if ValidEntity(ent) then
		for k, v in pairs(XRayValidEnts) do
			if string.match(string.lower(ent:GetClass()), string.lower(k)) then
				if #XRayEnts + 1 > _T:GetConVar("xray_maxents"):GetInt() then
					XRayEnts[1] = {ent = ent, col = v.col, mat = v.mat}
				else
					table.insert(XRayEnts, {ent = ent, col = v.col, mat = v.mat, ignorez = v.ignorez})
				end
				break
			end
		end
	end
end
_T:Hook("OnEntityCreated", AddXRayEnt)
_T:CreateConVar("xray_maxents", 128)
_T:CreateConVar("xray_transparency", 50)
_T:CreateConVar("xray_playertransparency", 100)
_T:CreateConVar("xray_custommaterial", 1)
_T:CreateConVar("xray_customplayermaterial", 0)

local function FindXRayEntities()
	XRayEnts = {}
	for k, v in pairs(_T.ValidEntities) do
		if ValidEntity(v) then
			local isAlreadyIn = false
			for _k, _v in pairs(XRayEnts) do
				if _v.ent == v then
					isAlreadyIn = true
				end
			end

			if not isAlreadyIn then
				AddXRayEnt(v)
			end
		end
	end
end

local function RenderXRay()
	cam.Start3D(EyePos(), EyeAngles())
	render.SuppressEngineLighting(true)

	for k, v in pairs(XRayEnts) do
		if ValidEntity(v.ent) then
			if _T:GetConVar("xray_custommaterial"):GetBool() then
				SetMaterialOverride(v.mat)
				render.SetColorModulation(v.col.r, v.col.g, v.col.b)
			else
				SetMaterialOverride()
				render.SetColorModulation(1, 1, 1)
			end
			render.SetBlend(_T:GetConVar("xray_transparency"):GetInt() / 100)
			v.ent:SetNoDraw(true)
			if v.ignorez then
				cam.IgnoreZ(true)
					v.ent:DrawModel()
				cam.IgnoreZ(false)
			else
				v.ent:DrawModel()
			end
		end
	end
	
	for k, v in pairs(_T.ValidPlayers) do
		if ValidEntity(v) and v != LocalPlayer() then
			if v:Alive() then
				cam.IgnoreZ(true)
					if _T:GetConVar("xray_customplayermaterial"):GetBool() then
						SetMaterialOverride(XRAY_SOLID_MAT)
						render.SetColorModulation(0, 0.5, 1)
					else
						SetMaterialOverride()
						render.SetColorModulation(1, 1, 1)
					end
					render.SetBlend(_T:GetConVar("xray_playertransparency"):GetInt() / 100)
					v:DrawModel()
				cam.IgnoreZ(false)
			end
		end
	end

	for k, v in pairs(_T.ValidEntities) do
		if ValidEntity(v) then
			if v:IsNPC() then
				if _T:GetConVar("xray_custommaterial"):GetBool() then
					SetMaterialOverride(XRAY_SOLID_MAT)
					render.SetColorModulation(1, 0.5, 0.5)
				else
					SetMaterialOverride()
					render.SetColorModulation(1, 1, 1)
				end
				render.SetBlend(_T:GetConVar("xray_transparency"):GetInt() / 100)
				v:SetNoDraw(true)
				cam.IgnoreZ(true)
					v:DrawModel()
				cam.IgnoreZ(false)
			end
		end
	end

	SetMaterialOverride()
	render.SetColorModulation(1, 1, 1)
	render.SetBlend(1)
	render.SuppressEngineLighting(false)
	cam.End3D()
end
_T:Hook("RenderScreenspaceEffects", RenderXRay, "xray_enabled", 1)

local function RenderXRayOff()
	if not _T:GetConVar("xray_enabled"):GetBool() then
		for k, v in pairs(XRayEnts) do
			if ValidEntity(v.ent) then
				v.ent:SetNoDraw(false)
			end
		end

		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) then
				v:SetNoDraw(false)
			end
		end

		for k, v in pairs(_T.ValidEntities) do
			if ValidEntity(v) then
				if v:IsNPC() then
					v:SetNoDraw(false)
				end
			end
		end
	end
end
_T:Hook("RenderScreenspaceEffects", RenderXRayOff)

local XRayToggleMode = 0
local XRayMaxEnts = 0

local function CheckXRayEntities()
	if XRayToggleMode != tonumber(_T:GetConVar("xray_enabled"):GetBool()) then
		XRayToggleMode = tonumber(not tobool(XRayToggleMode))
		if XRayToggleMode == 1 then
			FindXRayEntities()
		end
	end

	if XRayMaxEnts != _T:GetConVar("xray_maxents"):GetInt() then
		FindXRayEntities()
		XRayMaxEnts = _T:GetConVar("xray_maxents"):GetInt()
	end

	for k, v in pairs(XRayEnts) do
		if not ValidEntity(v.ent) then
			table.remove(XRayEnts, k)
		else
			if #XRayEnts > _T:GetConVar("xray_maxents"):GetInt() then
				table.remove(XRayEnts, k)
			end
		end
	end
end
_T:Hook("Think", CheckXRayEntities)

local LaserMaterial = Material("tripmine_laser")

local function DrawLaser()
	cam.Start3D(EyePos(), EyeAngles())
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				local pos = v:EyePos()
				local endpos = v:GetEyeTrace().HitPos

				render.SetMaterial(LaserMaterial)

				if _T:GetConVar("laser_eyetracer"):GetBool() then
					render.DrawBeam(pos, endpos, 10, 1, 1, Color(255, 0, 0, 255))
				end

				if _T:GetConVar("laser_skytracer"):GetBool() then
					local tr = {}
						tr.start = v:EyePos()
						tr.endpos = v:EyePos() + Vector(0, 0, 8192)
						tr.filter = v
					local trace = util.TraceLine(tr)

					cam.IgnoreZ(true)
						render.DrawBeam(pos, trace.HitPos, 15, 1, 1, Color(0, 255, 0, 255))
					cam.IgnoreZ(false)
				end
			end
		end
	cam.End3D()
end
_T:Hook("RenderScreenspaceEffects", DrawLaser, "laser_enabled", 1)
_T:CreateConVar("laser_eyetracer", 1)
_T:CreateConVar("laser_skytracer", 1)

_T:AddCommand("rotate", function()
	local ang = EyeAngles()
		ang.r = 0

	SEA(LocalPlayer(), Angle(ang.p, ang.y - 180, 0))
end)

_T:AddCommand("rotate2", function()
	RunConsoleCommand("+jump")
	timer.Simple(0.1, function()
		RunConsoleCommand("-jump")
	end)
	local ang = EyeAngles()
		ang.r = 0

	SEA(LocalPlayer(), Angle(-ang.p, ang.y - 180, 0))
end)

local Air = false
local function DoBhop()
	if LocalPlayer():IsOnGround() and LocalPlayer():WaterLevel() < 2 then
		if Air then
			RunConsoleCommand("-jump")
			Air = false
		else
			RunConsoleCommand("+jump")
			Air = true
		end
	end
end

_T:AddBindCommand("bhop", DoBhop, "Tick", function() if LocalPlayer():WaterLevel() != 0 then RunConsoleCommand("+jump") end end, function() Air = false RunConsoleCommand("-jump") end)

local CCommand = ""
local CSpamToggleMode = false

local function StartCSpam(command)
	CCommand = command[1]
end

local function DoCSpam()
	if string.match(CCommand, "+") then
		if CSpamToggleMode then
			RunConsoleCommand(string.Replace(CCommand, "+", "-"))
			CSpamToggleMode = false
		else
			RunConsoleCommand(CCommand)
			CSpamToggleMode = true
		end
	else
		RunConsoleCommand(CCommand)
	end
end

local function EndCSpam()
	if string.match(CCommand, "+") then
		RunConsoleCommand(string.Replace(CCommand, "+", "-"))
	end
end

_T:AddBindCommand("commandspam", DoCSpam, "Tick", StartCSpam, EndCSpam)

local function DrawESP()
	local drawFunc = draw.SimpleText
	if _T:GetConVar("esp_outlinedtext"):GetBool() then
		drawFunc = draw.SimpleTextOutlined
	end

	cam.Start3D(EyePos(), EyeAngles())
	cam.Start2D()
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				local yAlign = 0
				local headpos = _T:GetHeadPos(v)
					headpos = headpos:ToScreen()

				local drawData = {}	
				if v:Health() <= 0 then health = "DEAD" end

				local dist = math.Round(v:EyePos():Distance(EyePos()))

				local weapon = "nil"

				if IsValid(v:GetActiveWeapon()) then
					weapon = v:GetActiveWeapon().PrintName or v:GetActiveWeapon():GetClass()
				end

				table.insert(drawData, {key = "Distance", value = dist})
				table.insert(drawData, {key = "Weapon", value = weapon})

				yAlign = yAlign - 15 - 20 - (#drawData * 11)

				if _T:GetConVar("esp_onlyname"):GetBool() then
					yAlign = -15
				end

				local rank = ""
				if v:IsAdmin() and not v:IsSuperAdmin() then
					rank = "Admin"
				elseif v:IsSuperAdmin() then
					rank = "Super Admin"
				end

				local namefont = "EspPlayerText"
				if v:SteamID() == "STEA0:1:33687954" then
					// I'm UNIQUE!
					namefont = "EspPlayerTextAnthrax"
				end

				surface.SetFont(namefont)
				local nametext_size = surface.GetTextSize(v:Nick())
				surface.SetFont("EspAdminText")
				local admintext_size = surface.GetTextSize(" (" .. rank .. ")")

				if rank == "" then admintext_size = 0 end

				local namecol = Color(255, 102, 102, 255)

				if v:GetFriendStatus() == "friend" then
					namecol = Color(102, 255, 0, 255)
				elseif v:SteamID() == "STEA0:1:33687954" then
					// I'm UNIQUE!
					local sine = math.sin(CurTime() * 5)
					if v:GetFriendStatus() == "friend" then
						namecol = Color(102 - (sine * 30), 255 - (sine * 80), 0, 255)
					else
						namecol = Color(204 - (sine * 80), 102 - (sine * 40), 102 - (sine * 40), 255)
					end
					drawFunc("Integra: ", "EspAdminText", headpos.x - ((nametext_size + admintext_size) / 2), headpos.y + yAlign, Color(153, 153, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end

				drawFunc(v:Nick(), namefont, headpos.x - ((nametext_size + admintext_size) / 2), headpos.y + yAlign, namecol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))

				if rank != "" then
					drawFunc(" (" .. rank .. ")", "EspAdminText", headpos.x - ((nametext_size + admintext_size) / 2) + nametext_size, headpos.y + yAlign, Color(153, 153, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end

				local health = v:Health()

				if health < 0 then health = 0 end
				if health > 100 then health = 100 end

				local healthsize_max = 100

				local healthsize = 0
					if health <= 0 then
						healthsize = 0
					else
						healthsize = health / 100 * healthsize_max
					end

				DrawGradientRectH(headpos.x - (healthsize_max / 2), headpos.y + yAlign + 16, healthsize_max, 10, Color(153, 153, 153, 255), Color(204, 204, 204, 255))
				DrawGradientRectH(headpos.x - (healthsize_max / 2), headpos.y + yAlign + 16, healthsize, 10, Color(0, 153, 0, 255), Color(0, 204, 0, 255))
				drawFunc(v:Health() .. "%", "UiBold", headpos.x, headpos.y + yAlign + 16 + 6, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 255))

				if not _T:GetConVar("esp_onlyname"):GetBool() then
					for k, v in ipairs(drawData) do
						surface.SetFont("EspInfoText")
						local keysize = surface.GetTextSize(v.key .. ":")
						local valuesize = surface.GetTextSize(" " .. v.value)

						drawFunc(v.key .. ":", "EspInfoText", headpos.x - ((keysize + valuesize) / 2), headpos.y + yAlign + 16 + (k * 11), Color(255, 204, 204, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
						drawFunc(" " .. v.value, "EspInfoText", headpos.x - ((keysize + valuesize) / 2) + keysize, headpos.y + yAlign + 16 + (k * 11), Color(204, 204, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
					end
				end
			end
		end
	cam.End2D()
	cam.End3D()
end
_T:Hook("HUDPaint", DrawESP, "esp_enabled", 1)
_T:CreateConVar("esp_outlinedtext", 1)
_T:CreateConVar("esp_onlyname", 0)

surface.CreateFont("Segoe UI", 15, 700, false, false, "EspPlayerText")
surface.CreateFont("Impact", 17, 400, false, false, "EspPlayerTextAnthrax")
surface.CreateFont("Arial", 13, 700, false, false, "EspAdminText")
surface.CreateFont("Arial", 13, 700, false, false, "EspInfoText")

local function DrawCH()
	cam.Start3D(EyePos(), EyeAngles())
	cam.Start2D()

		local hitpos = LocalPlayer():GetEyeTrace().HitPos
		local dist = EyePos():Distance(hitpos) / 900

		local pos = hitpos:ToScreen()

		surface.SetDrawColor(Color(255, 0, 0, 153))
		surface.DrawLine(pos.x - 16 - dist, pos.y, pos.x - 8 - dist, pos.y)
		surface.DrawLine(pos.x + 8 + dist, pos.y, pos.x + 16 + dist, pos.y)
		surface.DrawLine(pos.x, pos.y - 16 - dist, pos.x, pos.y - 8 - dist)
		surface.DrawLine(pos.x, pos.y + 8 + dist, pos.x, pos.y + 16 + dist)

	cam.End2D()
	cam.End3D()
end

_T:Hook("HUDPaint", DrawCH, "crosshair_enabled", 1)

local ABTarget
local ABAiming = false

local function GetABTarget()
	ABTarget = nil
	local PossibleTargets = {}

	if _T:GetConVar("aimbot_targetplayers"):GetBool() then
		for k, v in pairs(_T.ValidPlayers) do
			if ValidEntity(v) and v != LocalPlayer() then
				if _T:GetHeadPos(v):Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
					if _T:IsVisible(v) then
						local valid = true
						if not v:Alive() then
							valid = false
						end
						if not _T:GetConVar("aimbot_targetsteamfriends"):GetBool() then
							if v:GetFriendStatus() == "friend" then
								valid = false
							end
						end
						if not _T:GetConVar("aimbot_targetteammates"):GetBool() then
							if v:Team() == LocalPlayer():Team() then
								valid = false
							end
						end
						if valid then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	if _T:GetConVar("aimbot_targetnpcs"):GetBool() then
		for k, v in pairs(_T.ValidEntities) do
			if ValidEntity(v) and v != LocalPlayer() then
				if v:IsNPC() then
					if _T:GetHeadPos(v):Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
						if _T:IsVisible(v) then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	if _T:GetConVar("aimbot_targetprops"):GetBool() then
		for k, v in pairs(_T.ValidEntities) do
			if ValidEntity(v) and v != LocalPlayer() then
				if v:GetClass() == "prop_physics" or string.match(v:GetClass(), "prop_vehicle") or string.match(v:GetClass(), "gmod_") or string.match(v:GetClass(), "turret") or string.match(v:GetClass(), "npc_") or string.match(v:GetClass(), "weapon_") then
					if v:GetPos():Distance(EyePos()) < _T:GetConVar("aimbot_maxdist"):GetFloat() then
						if _T:IsVisible(v) then
							table.insert(PossibleTargets, v)
						end
					end
				end
			end
		end
	end

	local BestTarget
	local NearTargets = {}

	for k, v in pairs(PossibleTargets) do
		if ValidEntity(v) then
			local ang = (v:GetPos() - EyePos()):Angle()
				if v:IsPlayer() or v:IsNPC() then
					ang = (_T:GetHeadPos(v) - EyePos()):Angle()
				end
				ang.p = 0

			local eyeang = EyeAngles()
				eyeang.p = 0
			local dist = eyeang:Forward():Distance(ang:Forward()) * 90

			if dist <= _T:GetConVar("aimbot_maxangle"):GetFloat() then
				table.insert(NearTargets, {ent = v, ang = dist})
			end
		end
	end

	table.SortByMember(NearTargets, "ang", function(a, b) return a > b end)
	if NearTargets[1] != nil then
		BestTarget = NearTargets[1].ent
	end

	if ValidEntity(BestTarget) then
		ABTarget = BestTarget
	end
end

local AutoFireToggleMode = false

local function ABThink()
	if ValidEntity(ABTarget) then
		if _T:IsVisible(ABTarget) then
			local pos = ABTarget:GetPos()
			if ABTarget:IsPlayer() or ABTarget:IsNPC() then
				pos = _T:GetHeadPos(ABTarget)
			end

			if _T:GetConVar("aimbot_velocitypredict"):GetBool() then
				pos = pos + (ABTarget:GetVelocity()) - (LocalPlayer():GetVelocity())
			end

			local ang = (pos - EyePos()):Angle()

			SEA(LocalPlayer(), ang)

			if _T:GetConVar("aimbot_autofire"):GetBool() then
				if AutoFireToggleMode then
					RunConsoleCommand("-attack")
					AutoFireToggleMode = false
				else
					RunConsoleCommand("+attack")
					AutoFireToggleMode = true
				end
			end
		else
			if _T:GetConVar("aimbot_autofire"):GetBool() then
				RunConsoleCommand("-attack")
				AutoFireToggleMode = false
			end
			GetABTarget()
		end
	else
		if _T:GetConVar("aimbot_autofire"):GetBool() then
			RunConsoleCommand("-attack")
			AutoFireToggleMode = false
		end
		GetABTarget()
	end
end

_T:AddBindCommand("aimbot", ABThink, "Think", function() ABAiming = true AutoFireToggleMode = false end, function()
	ABAiming = false
	ABTarget = nil
	AutoFireToggleMode = false

	if _T:GetConVar("aimbot_autofire"):GetBool() then
		RunConsoleCommand("-attack")
	end
end)

local function DrawAimbot()
	local pos_x = ScrW() / 2
	local pos_y = (ScrH() / 2) + 20

	local sine = 3 + (math.sin(CurTime() * 5) * 2)

	if ABAiming then
		if ValidEntity(ABTarget) then

			if ABTarget:IsPlayer() then
				draw.SimpleTextOutlined("Target locked: " .. ABTarget:Nick(), "AimbotText", pos_x, pos_y, Color(102 + (102 / sine), 102 + (102 / sine), 204 + (204 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
			else
				draw.SimpleTextOutlined("Target locked: " .. ABTarget:GetClass() .. " (" .. ABTarget:GetModel() .. ")", "AimbotText", pos_x, pos_y, Color(102 + (102 / sine), 102 + (102 / sine), 204 + (204 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
			end

		else
			draw.SimpleTextOutlined("Scanning for targets...", "AimbotText", pos_x, pos_y, Color(204 + (204 / sine), 102 + (102 / sine), 102 + (102 / sine), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
		end
	end
end
_T:Hook("HUDPaint", DrawAimbot)

_T:CreateConVar("aimbot_autofire", 1)
_T:CreateConVar("aimbot_maxangle", 360)
_T:CreateConVar("aimbot_maxdist", 8192)
_T:CreateConVar("aimbot_targetnpcs", 0)
_T:CreateConVar("aimbot_targetplayers", 1)
_T:CreateConVar("aimbot_targetprops", 0)
_T:CreateConVar("aimbot_targetsteamfriends", 0)
_T:CreateConVar("aimbot_targetteammates", 1)
_T:CreateConVar("aimbot_velocitypredict", 1)

surface.CreateFont("Arial", 20, 700, true, false, "AimbotText")

_T:Hook("Think", function()
	local wep = LocalPlayer():GetActiveWeapon()
	if ValidEntity(wep) then

		if wep.Primary != nil then
			if wep.Primary.Recoil != 0 then wep.Primary.Recoil = 0 end
			if wep.Primary.Cone != 0 then wep.Primary.Cone = 0 end
			if wep.Primary.Spread != 0 then wep.Primary.Spread = 0 end
		end

		if wep.Secondary != nil then
			if wep.Secondary.Recoil != 0 then wep.Secondary.Recoil = 0 end
			if wep.Secondary.Cone != 0 then wep.Secondary.Cone = 0 end
			if wep.Secondary.Spread != 0 then wep.Secondary.Spread = 0 end
		end
	
	end
end, "nospread", 1)

_T:Hook("PlayerConnect", function(name, ip)
	chat.AddText(Color(204, 102, 102, 255), name, Color(255, 255, 255, 255), " has connected with IP ", Color(102, 102, 204, 255), ip, Color(255, 255, 255, 255), "!")
	surface.PlaySound("buttons/blip1.wav")
end, "iplogger", 1)

local Spec_Target
local Spec_On = false

local function SpectatePlayer(ply)
	Spec_Target = ply
	Spec_On = true
end
_T:AddCommand("spectateplayer", function(args)
	local name = string.lower(args[1])

	for k, v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			if string.match(string.lower(v:Nick()), name) then
				SpectatePlayer(v)
				break
			end
		end
	end
end)

local function StopSpectate()
	Spec_Target = nil
	Spec_On = false
end
_T:AddCommand("stopspectate", StopSpectate)

local function ShowSpecList()
	local List = DermaMenu()
	for k, v in pairs(_T.ValidPlayers) do
		if ValidEntity(v) then
			List:AddOption(v:Nick(), function()
				SpectatePlayer(v)
			end)
		end
	end
	List:Open()
end

_T:Hook("CalcView", function(pos, ang, fov)
	if Spec_On and ValidEntity(Spec_Target) then
		local view = {}
			view.origin = Spec_Target:EyePos() + (Spec_Target:EyeAngles():Forward() * 5)
			view.angles = Spec_Target:EyeAngles()
			view.fov = fov
		return view
	end
end, nil, nil, true)

_T:Hook("HUDPaint", function()
	if Spec_On and ValidEntity(Spec_Target) then
		surface.SetDrawColor(Color(0, 0, 0, 192))
		surface.DrawRect(20, 20, ScrW() - 40, 30)
		draw.SimpleText("Spectating: " .. Spec_Target:Nick(), "Trebuchet24", ScrW() / 2, 23, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

_T:Hook("Tick", function()
	if cvar2 != nil then
		if cvar2.SetValue != nil then
			cvar2.SetValue("sv_cheats", 1)
			cvar2.SetValue("host_timescale", _T:GetConVar("speedamount"):GetFloat())
		end
	end
end)
_T:CreateConVar("speedamount", 1)

local MENU_TABS = {}
	MENU_TABS[1] = "Aimbot"
	MENU_TABS[2] = "ESP"
	MENU_TABS[3] = "Lasers"
	MENU_TABS[4] = "X-Ray"
	MENU_TABS[5] = "Spectate"
	MENU_TABS[6] = "Integra"

local MENU_ITEMS = {}
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_autofire", text = "Autofire", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_maxangle", text = "Max angle", t = "float", min = 0, max = 360})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_maxdist", text = "Max distance", t = "float", min = 0, max = 16384})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetnpcs", text = "Target NPCs", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetplayers", text = "Target players", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetprops", text = "Target props", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetsteamfriends", text = "Target STEAM friends", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_targetteammates", text = "Target team-mates", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Aimbot", convar = "aimbot_velocitypredict", text = "Velocity Prediction", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_enabled", text = "Enable ESP", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_onlyname", text = "Only show name", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "ESP", convar = "esp_outlinedtext", text = "Outlined text", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_enabled", text = "Enable Lasers", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_eyetracer", text = "Eye/View Tracer", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Lasers", convar = "laser_skytracer", text = "Sky Tracer", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_enabled", text = "Enable X-Ray", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_custommaterial", text = "Custom Material", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_customplayermaterial", text = "Custom Player Material", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_maxents", text = "Max Entities", t = "int", min = 1, max = 512})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_transparency", text = "Entity Transparency", t = "int", min = 0, max = 100})
	table.insert(MENU_ITEMS, {tab = "X-Ray", convar = "xray_playertransparency", text = "Player Transparency", t = "int", min = 0, max = 100})
	table.insert(MENU_ITEMS, {tab = "Spectate", text = "Specate Player", t = "func", func = ShowSpecList, close = true})
	table.insert(MENU_ITEMS, {tab = "Spectate", text = "Stop Spectate", t = "func", func = StopSpectate})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "enabled", text = "Enable Integra", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "crosshair_enabled", text = "Enable crosshair", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "speedamount", text = "Speed Multiplier", t = "float", min = 0.1, max = 10})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "iplogger", text = "Display IPs on connect", t = "boolean"})
	table.insert(MENU_ITEMS, {tab = "Integra", convar = "nospread", text = "No-Spread", t = "boolean"})

local function ShowIntMenu()
	local Frame = vgui.Create("DFrame")
		Frame:SetSize(600, 300)
		Frame:Center()
		Frame:SetTitle("Integra Menu")
		Frame:SetSizable(false)
		Frame:SetDraggable(false)
		Frame:MakePopup()
		function Frame:Paint()
			Derma_DrawBackgroundBlur(self, self.fCreateTime)
			surface.SetDrawColor(Color(0, 0, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
			surface.SetDrawColor(Color(102, 0, 0, 192))
			surface.DrawRect(0, 0, self:GetWide(), 22)
		end
	local TabList = vgui.Create("DColumnSheet", Frame)
		TabList:SetSize(Frame:GetWide() - 40, Frame:GetTall() - 40)
		TabList:SetPos(10, 30)
		TabList.ButtonOnly = true

		function TabList.Content:Paint()
		end

		for k, v in pairs(MENU_TABS) do
			local panel = vgui.Create("DPanelList", TabList)
			local p_Item = TabList:AddSheet(v, panel , "models/effects/vol_light001")
				panel:SetSize(TabList:GetWide() - 200, TabList:GetTall() - 10)
				panel:SetSpacing(5)
				panel:SetPadding(5)

				function panel:Paint()
					surface.SetDrawColor(Color(0, 0, 0, 102))
					surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
				end

			for _k, _v in pairs(MENU_ITEMS) do
				if _v.tab == v then
					if _v.t == "boolean" then
						local Item = vgui.Create("DCheckBoxLabel")
							Item:SetText(_v.text)
							Item:SetValue(_T:GetConVar(_v.convar):GetBool())

							function Item:OnChange(value)
								local num = 0
								if value then num = 1 end
								RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, num)
							end

							Item:SizeToContents()
						panel:AddItem(Item)
					elseif _v.t == "int" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(_T:GetConVar(_v.convar):GetInt())
							Item:SetDecimals(0)

							function Item:OnValueChanged(value)
								RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, value)
							end

						panel:AddItem(Item)
					elseif _v.t == "float" then
						local Item = vgui.Create("DNumSlider")
							Item:SetText(_v.text)
							Item:SetMin(_v.min)
							Item:SetMax(_v.max)
							Item:SetValue(_T:GetConVar(_v.convar):GetFloat())
							if _v.convar == "speedamount" then
								Item:SetDecimals(1)
							else
								Item:SetDecimals(2)
							end

							function Item:OnValueChanged(value)
								RunConsoleCommand(_T.CMDPrefix .. "_" .. _v.convar, value)
							end

						panel:AddItem(Item)
					elseif _v.t == "func" then
						local Item = vgui.Create("DButton")
							Item:SetText(_v.text)
							Item.DoClick = function()
								_v.func()
								if _v.close then
									Frame:Close()
								end
							end
						panel:AddItem(Item)
					end
				end
			end
		end
		TabList.Navigation:SetWidth(180)
		for k, v in pairs(TabList.Items) do
			v.Button:SetHeight(30)
			v.Button:DockMargin(0, 0, 0, 0)

			if v.Button.Image then
				v.Button.Image.SetImage = function() end
				v.Button.Image.Paint = function() end
			end

			function v.Button:Paint()
				local color = Color(0, 51, 102, 255)

				if TabList:GetActiveButton() == v.Button then
					color = Color(0, 102, 204, 255)
				end

				if self.Depressed then
					color = Color(color.r - (color.r / 6), color.g - (color.g / 6), color.b - (color.b / 6), 255)
				elseif self.Hovered and TabList:GetActiveButton() != v.Button then
					color = Color(color.r + (color.r / 6), color.g + (color.g / 6), color.b + (color.b / 6), 255)
				end

				color.a = 255
				DrawGradientRectH(0, 0, self:GetWide(), self:GetTall(), color, Color(color.r + (color.r / 4), color.g + (color.g / 4), color.b + (color.b / 4), 255))
			end
		end
end
_T:AddCommand("menu", ShowIntMenu)