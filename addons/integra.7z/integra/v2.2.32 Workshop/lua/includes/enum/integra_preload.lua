local m_GetConVar = GetConVar
local m_GetConVarNumber = GetConVarNumber

function GetConVar(convar)
	if type(convar) == "string" then
		if string.match(string.lower(convar), "int_") or string.match(string.lower(convar), "host_timescale") or string.match(string.lower(convar), "sv_cheats") then
			return nil
		else
			return m_GetConVar(convar)
		end
	else
		return nil
	end
end

function GetConVarNumber(convar)
	if type(convar) == "string" then
		if string.match(string.lower(convar), "int_") or string.match(string.lower(convar), "host_timescale") or string.match(string.lower(convar), "sv_cheats") then
			return nil
		else
			return m_GetConVarNumber(convar)
		end
	else
		return nil
	end
end

local SLASH = "[\\/]+"

local m_file = {}
	m_file.Read = file.Read
	m_file.Find = file.Find
	m_file.FindDir = file.FindDir
	m_file.FindInLua = file.FindInLua
	m_file.Exists = file.Exists
	m_file.Delete = file.Delete

function file.Read(f, base)
	if string.match(string.lower(f), "integra") then
		return nil
	else
		return m_file.Read(f, base)
	end
end

function file.Find(f, base)
	if string.match(string.lower(f), "integra") then
		return {}
	else
		local l = m_file.Find(f, base)
		local _l = {}
		for k, v in pairs(l) do
			if not string.match(string.lower(v), "integra") then
				table.insert(_l, v)
			end
		end
		return _l
	end
end

function file.FindDir(f, base)
	if string.match(string.lower(f), "integra") then
		return {}
	else
		local l = m_file.FindDir(f, base)
		local _l = {}
		for k, v in pairs(l) do
			if not string.match(string.lower(v), "integra") then
				table.insert(_l, v)
			end
		end
		return _l
	end
end

function file.FindInLua(f)
	local l = m_file.FindInLua(f)
	local _l = {}
	for k, v in pairs(l) do
		if not string.match(string.lower(v), "integra") then
			table.insert(_l, v)
		end
	end
	return _l
end

function file.Exists(f, base)
	if string.match(string.lower(f), "integra") then
		return false
	else
		return m_file.Exists(f, base)
	end
end

function file.Delete(f)
	MsgN("Something tried to remove the file: '" .. f .. "', but got blocked!")
end