local vguiCreate = vgui.Create

function vgui.Create(p_Type, p_Parent, p_Target)
	include("integra/DFrame.lua")
	vgui.Create = vguiCreate
	return vguiCreate(p_Type, p_Parent, p_Target)
end