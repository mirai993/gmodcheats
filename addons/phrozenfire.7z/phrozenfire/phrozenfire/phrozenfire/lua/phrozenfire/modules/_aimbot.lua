--[[
	MOD/lua/PhrozenFire/PhrozenFire/lua/PhrozenFire/Modules/_aimbot.lua [#9830 (#9830), 2514127430, UID:3828245966]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:43PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "PhrozenAimbot" )

MODULE.Author = "Firehawk"
MODULE.Version = 0.1

MODULE.cVars = {

	["aimbot_enabled"]			= { "aimbotenabled"		, 1, 0, 1 },
	["aimbot_norecoil"] 		= { "norecoil"			, 1, 0, 1 },
	["aimbot_fov"] 				= { "aimbotfov"			, 20,0, 360 },
	["aimbot_players"]			= { "playersincluded"	, 1, 0, 1 },
	["aimbot_teamcheck"] 		= { "teamcheck"			, 1, 0, 1 },
	["aimbot_autoshoot"]		= { "autoshoot"			, 1, 0, 1 },
	["aimbot_nospread"] 		= { "nospread"			, 1, 0, 1 },
	["aimbot_alwayspread"]		= { "alwaysspread"		, 1, 0, 1 },
	["aimbot_autoreload"]		= { "autoreload"		, 0, 0, 1 },
	["aimbot_dangerousonly"]	= { "dangerousonly"		, 0, 0, 1 },
	["aimbot_compensation"]		= { "compensation"		, 50, 1, 100 }
	
}

MODULE.notAuto = { "weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow" }

MODULE.weaponCones = {
	
	weapon_zs_base = function( wep )
	
		local cone = wep.Cone

		if wep:GetNWBool( "Ironsights", false ) then

			if LocalPlayer():Crouching() then

				cone = wep.ConeIronCrouching

			else

				cone = wep.ConeIron

			end

		elseif LocalPlayer():GetVelocity():Length() > 25 then
		
			cone = wep.ConeMoving
			
		elseif LocalPlayer():Crouching() then
		
			cone = wep.ConeCrouching
			
		end
		
		return cone
		
	end,
	
	weapon_sniper_rifle = function( wep )
	
		return (1.0 - wep.zoom) * 0.25
		
	end
	
}

function MODULE:Init()

	self.Enabled = false

	self.Target = nil
	self.Shooting = false

	self.LastReloadGCD = 0
	self.LastReload = 0
	
	self.AttackDown = false
	self.NextShot = 0
	
	self.angDiff = Angle( 0, 0, 0 )
	self.angFire = Angle( 0, 0, 0 )
	
	self.correctView = Angle()
	
	concommand.Add( "+scan", function() self.Enabled = true end )
	concommand.Add( "-scan", function() self.Enabled = false end )

end

function MODULE:IsSemiAuto( Weapon )

	if not ValidEntity( Weapon ) then return end
	
	return ( Weapon.Primary && not Weapon.Primary.Automatic ) || table.HasValue( self.notAuto, LocalPlayer():GetActiveWeapon():GetClass() )
	
end

function MODULE:SetShooting( bool )

	bool = bool or false

	if self.AttackDown == bool then return end
	
	self.AttackDown = bool

	local pre = { [true] = "+", [false] = "-" }
	
	RunConsoleCommand( pre[bool] .. "attack" )
	
end

function MODULE:Shoot()

	if CurTime() < self.NextShot then return end

	local Weapon = LocalPlayer():GetActiveWeapon()
	if not ValidEntity( Weapon ) then return end
	
	local Delay = 0.07
	
	if Weapon.Primary && Weapon.Primary.Delay then Delay = Weapon.Primary.Delay end

	self:SetShooting( true )
	
	if self:IsSemiAuto( Weapon ) then
	
		timer.Simple( Delay / 2, function() self:SetShooting( false ) end )
		
	end
	
	self.NextShot = CurTime() + Delay
	
end

function MODULE:IsFOV ( ent )
	
	local fov = self.base:GetValue( "AimbotFov" )
	
	if ( fov ~= 180 ) then
	
		local PlayerAngle = LocalPlayer():GetAngles()
		
		local ang = ( ent:GetPos() - LocalPlayer():GetPos() ):Angle()
		
		local ady = math.abs( math.NormalizeAngle( PlayerAngle.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( PlayerAngle.p - ang.p ) )
		
		if( ady > fov or adp > fov ) then 
		
			return false
			
		end
		
	end
	
	return true
	
end

function MODULE:PredictPos ( ent, pos )
	
	/*
	local v = pos
	local p = LocalPlayer():GetPos()
	local s, d = p:Distance( p + LocalPlayer():GetVelocity() ), LocalPlayer():GetPos():Distance( pos )
	
	local po = Vector( 0, 0, 0 )
	
	if ( d < 4000 && s > 0 ) then po = LocalPlayer():GetVelocity() * d / ( s * d * 0.135 ) end
	
	v = v - po

	return v

	*/
	local comp = self.base:GetValue( "Compensation" )

	return pos + ( ( ent:GetVelocity() / comp ) - ( LocalPlayer():GetVelocity() / comp ) )
end

function MODULE:PredictSpread( cmd, aimAngle )

	local Seed = self.base.GetSeed( cmd ) or 0
	
	Weapon = LocalPlayer():GetActiveWeapon()
	vecCone = Vector( 0, 0, 0 )

	if ( Weapon && ValidEntity( Weapon ) && type( Weapon.Initialize ) == "function" ) then
	
		local valCone = Weapon.Primary.Cone
		
		if self.weaponCones[ Weapon.Base ] then
			
			valCone = self.weaponCones[ Weapon.Base ]( Weapon )
			
		end
		
		if type( valCone ) == "number" then
		
			vecCone = Vector( -valCone, -valCone, -valCone )
			
		elseif type( valCone ) == "Vector" then
		
			vecCone = -1 * valCone
				
		end
		
	elseif ( Weapon and Weapon:IsValid() ) then
	
		local class = Weapon:GetClass()
		
		local HL2_SPREAD = {
			weapon_357 = Vector( 0, 0, 0 ),
			weapon_smg1 = Vector(0.04362, 0.04362, 0.04362),
			weapon_ar2 = Vector(0.02618, 0.02618, 0.02618),
			weapon_pistol = Vector(0.00873, 0.00873, 0.00873),
			weapon_shotgun = Vector(0.08716, 0.08716, 0.08716),
		}
		
		if HL2_SPREAD[ class ] then vecCone = -1 * HL2_SPREAD[ class ] end
		
	end
	
	return self.base.ShotManipulate( Seed or 0, ( aimAngle or LocalPlayer():GetAimVector():Angle() ):Forward(), self.FireCone or vecCone or Vector( 0, 0, 0 ) ):Angle()
	
end

function MODULE:GetAimAngle ( ent, cmd )

	local ang = self.util:GetHeadPosition( ent )
	
	ang = self:PredictPos ( ent, ang )
	ang = ( ang - LocalPlayer():GetShootPos()):Angle()
	
	ang = self:PredictSpread( cmd, ang )
	
	ang.p = self.util:NormaliseAngle(ang.p)
	ang.y = self.util:NormaliseAngle(ang.y)
	ang.r = 0
	
	return ang
	
end

function MODULE:CheckTeam( ent )

	if ( ent:IsPlayer() ) then

		if ( self.base:GetBool( "TeamCheck" ) && ent:Team() == LocalPlayer():Team() ) then

			return false
			
		end
		
		return true
	
	end
	
	return true
	
end

function MODULE:GetValid( ent )

	if ValidEntity( ent ) then

		if ( not ( ent == LocalPlayer() ) ) && self.util:GetAlive( ent ) then
		
			if ( ent:IsPlayer() || ent:IsNPC() ) then
		
				if ( ent:IsPlayer() && not self.base:GetBool( "PlayersIncluded" ) ) then return false end
				if ( ent:IsNPC() && self.util:FriendlyNPC( ent ) ) then return false end

				if ( self.base:GetBool( "DangerousOnly") ) then

					local Weapon = self.util:GetActiveWeapon( ent )

					if not ( self.util:MarkDangerousWeapon( Weapon ) ) then

						return false

					end

				end
			
				if self:IsFOV( ent ) then
				
					if self:CheckTeam( ent ) then

						return true
					
					end
					
				end
			
			end
		
		end
	
	end
	
	return false

end

function MODULE:Holstered()

	if type( ClientVars ) == "table" then
	
		return ClientVars["Holstered"] 
		
	else
	
		return false
		
	end
	
end

function MODULE:ViewCorrection( c )
	
	local curView = c:GetViewAngles()
	
	self.angFire = curView - self.angDiff
	
	local angSpread = self.angFire
	
	if self.base:GetBool( "AlwaysSpread" ) then
		
		if ( c:GetButtons() & IN_ATTACK > 0 ) then
			angSpread = self:PredictSpread( c, self.angFire )
		end
		
		self.angDiff = Angle( math.AngleDifference( angSpread.p, self.angFire.p ), math.AngleDifference( angSpread.y, self.angFire.y ), 0 )
	else
		self.angDiff = Angle( 0, 0, 0 )
	end
	
	angSpread.p = self.util:NormaliseAngle( angSpread.p )
	angSpread.y = self.util:NormaliseAngle( angSpread.y )
	angSpread.r = 0
	
	self.correctView = curView - self.angDiff
	
	if ( self.base:GetBool( "NoRecoil" ) && not self.Target ) then 
	
		c:SetViewAngles( angSpread )
	
	end
	
end

function MODULE:NoRecoil( o, fov )
		
	local Weapon = LocalPlayer():GetActiveWeapon()
	
	if LocalPlayer():Alive() && ValidEntity( Weapon ) then
		
		if ( Weapon.Primary ) then Weapon.Primary.Recoil = 0.0 end
		if ( Weapon.Secondary ) then Weapon.Secondary.Recoil = 0.0 end
				
		if ( self:Holstered() == false ) then
		
			return { origin = o, angles = self.correctView, fov = fov }
			
		end
		
	end

end

function MODULE:GetTarget( )

    local closest = { self.Target or nil ,0 }
	
	for k, v in pairs ( self.util:GetEntityTable() ) do

		if self:GetValid( v ) && self.util:IsVisible( v ) then
		
			local diff = ( v:GetPos() - LocalPlayer():GetPos() ):Normalize()
			
			diff = diff - LocalPlayer():GetAimVector()
			diff = diff:Length()
			diff = math.abs( diff )
			
			if ( diff < closest[2] ) or ( closest[1] == nil ) then
			
				closest = { v, diff }
				
			end	
		
		end
		
	end
	
	self.Target = closest[1]

end

function MODULE:Aimbot( cmd )

	if ( self.Enabled ) then
		
		self:GetTarget()
		
		if self:GetValid ( self.Target ) then

			local ang = self:GetAimAngle( self.Target, cmd )
			self.correctView = ang
			
			cmd:SetViewAngles( ang )
			
		else
			self.Target = nil		
		end
		
	else
		self.Target = nil	
	end
	
end

function MODULE:AutoReload( cmd )

	local Weapon = LocalPlayer():GetActiveWeapon()

	if ( LocalPlayer():Alive() && ValidEntity( Weapon ) ) then

		if ( Weapon:Clip1() <= 0 ) then

			if ( self.LastReload < CurTime() ) then

				RunConsoleCommand("+reload")

				self.LastReload = CurTime() + self.util:GetReloadTime() 
			
				timer.Simple( .2, function()
					
					RunConsoleCommand("-reload")

				end)

			end

		end

	end

end


function MODULE:Autoshoot( )

	if ( self.Target && self.Enabled ) then
	
		self:Shoot()
		self.Shooting = true

	elseif ( not self.Target && self.Shooting ) then
	
		self:StopShooting( )

	end

	if ( self.Shooting && ( not self.Target ) ) then
		self:StopShooting ( )
		self.Shooting = false
	end

end

function MODULE.CreateMove( cmd )

	local self = MODULE
	
	if self.base:GetBool("Enabled") then
	
		if self.base:GetBool( "AimbotEnabled" ) then self:Aimbot( cmd ) end
		if self.base:GetBool( "AutoShoot" ) then self:Autoshoot( ) end
		if self.base:GetBool( "NoRecoil" ) then self:ViewCorrection( cmd ) end
		if self.base:GetBool( "AutoReload" ) then self:AutoReload( cmd ) end
	
	end

end

function MODULE.CalcView( ply, pos, angles, fov )

	local self = MODULE
		
	if ( ( not (self.Enabled ) ) && self.base:GetBool( "NoRecoil" ) ) then
	
		return self:NoRecoil( pos )
		
	end
	
end

function MODULE:StopShooting()

	self:SetShooting( false )

end

MODULE.Hooks = {

	["CalcView"] = { MODULE.CalcView },
	["CreateMove"] = { MODULE.CreateMove }
	
}

PhrozenFire:RegisterModule( MODULE )