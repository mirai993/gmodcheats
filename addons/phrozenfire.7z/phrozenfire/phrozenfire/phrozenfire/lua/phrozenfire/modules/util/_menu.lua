--[[
	MOD/lua/PhrozenFire/PhrozenFire/lua/PhrozenFire/Modules/Util/_menu.lua [#660 (#660), 221450486, UID:1413633811]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:43PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "_Menu" )

MODULE.Name = "#Bobby's favorite PhrozenFire Menu#"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

//Since we get access to the PhrozenFire table from the module, lets not even register the plugin.
//By the time these functions get added in, we should be good.

MODULE.base.Menu = {}

concommand.Add( MODULE.base.prefix .. "core_menu", function()

	if MODULE.base.Menu then
	
		MODULE.base.Menu:Open()
	
	end

end)

function MODULE.base.Menu:Open()

	self.panel = vgui.Create( "DFrame" )
	self.panel:SetSize( 640, 400 )
	self.panel:Center()
	self.panel:MakePopup()
end

//PhrozenFire:RegisterModule( MODULE )