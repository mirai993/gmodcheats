--[[
	MOD/lua/PhrozenFire/PhrozenFire/lua/PhrozenFire/Modules/_esp.lua [#10041 (#10041), 1872335764, UID:1434668670]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:43PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "PhrozenEsp" )

MODULE.Author = "Firehawk"
MODULE.Version = 0.1

MODULE.cVars = {
	
	["esp_enabled"]				= { "espenabled"		, 1, 0, 1 },
	["esp_players"] 			= { "playeresp"			, 1, 0, 1 },
	["esp_bbox"] 				= { "box"				, 1, 0, 1 },
	["esp_entities"] 			= { "entityesp"			, 1, 0, 1 },
	["esp_showweaponclasses"]	= { "weaponclasses"		, 1, 0, 1 },
	["esp_developer"] 			= { "developer"			, 1, 0, 1 },
	["hud_crosshair"] 			= { "crosshair"			, 1, 0, 1 },
	["esp_gamemodenames"]		= { "gamemodespecific"	, 1, 0, 1 }
	
}

function MODULE:Init()

	self.ents, self.names = {}, {}
	self.data = {}
	
	self.Color1 = Color( 150, 150, 255 )
	self.Color2 = Color( 255, 150, 50 )
	
	self.c = {}
	self.c.Black = Color( 0, 0, 0, 255 )

	self:LoadEspEntities()
	self:LoadNameData()
	
end

function MODULE:AddEntity( class, name, callback, color )

	if ( self.ents && not ( self.ents[ class ] ) ) then
	
		local obj = {}
		
		obj.name 		= name or ""
		obj.callback	= callback or nil
		obj.color		= color or Color( 255, 255, 255 )
		
		self.ents[ class ] = obj
		
		return
	
	end

end

function MODULE:AddPlayerName( GM, func )

	if ( self.names && not ( self.names[ GM ] ) ) then
	
		local obj = {}
		
		obj.callback = func
		
		self.names[ GM ] = obj
	
	end

end

function MODULE:GetColor( v )

	if v then return self.Color1 end

	return self.Color2

end

function MODULE:DrawBox( ent, color )

	local x1, y1, x2, y2 = self.util:GetCoordiantes( ent )
	
	if self.base:GetBool( "Box" ) then
		surface.SetDrawColor( color )
		surface.DrawOutlinedRect( x1, y1, x2 - x1, y2 - y1)
	end
	
	return x1, y1, x2, y2
	
end


function MODULE:DrawCrosshair( )

	local midx = ScrW() / 2
	local midy = ScrH() / 2
	
	surface.SetDrawColor( Color( 0, 0, 0 ) )

	surface.DrawRect( midx - 2, midy - 4, 3, 9 )
	surface.DrawRect( midx - 5, midy - 1, 9, 3 )

	surface.SetDrawColor( self.Color1 )

	surface.DrawLine( midx - 1, midy - 3, midx - 1, midy + 4)
	surface.DrawLine( midx - 4, midy, midx + 3, midy)

end

function MODULE:DrawHealthbar( x, y, value, ply )

	value = math.Clamp( value / 100, 0, 1 )

	self.util:FillRGBA( x + 2, y - 1, 24, 6, Color( 0, 0, 0, 255 ) )
	self.util:FillRGBA( x + 3, y, 22 * value, 4, Color( 0, 255, 0, 255) )
	
	if self.util:IsAdmin( ply ) then
	
		self.util:FillRGBA( x + 2, y + 4, 6, 6, Color( 0, 0, 0, 255 ) )
		self.util:FillRGBA( x + 3, y + 5, 4, 4, Color( 150, 150, 255 ) )
		
		return true
	
	end
		
	return false
		
end

function MODULE:DrawWeapons( ent )

	local Weapons = self.util:GetWeapons( ent ) or {}
	
	local x1, y1, x2, y2 = self.util:GetCoordiantes( ent )
		
	if table.Count( Weapons ) == 0 then
	
		self.util:DrawText( "No Weapons", x2, y1, Color( 50, 255, 50, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
		
	else
	
		for i = 1,table.Count( Weapons ) do
			
			if Weapons[i] != nil then
				
				if self.base:GetBool( "WeaponClasses" ) then
					self.util:DrawText( Weapons[i]:GetClass(), x2, y1 + ( self.util.th * i ) + 10, Color(50,255,50,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				else
					self.util:DrawText( Weapons[i]:GetPrintName(), x2, y1 + ( self.util.th * i ) + 10, Color(50,255,50,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
				end	
			
			end
			
		end
	
	end
	
	table.Empty( Weapons )
		
end

function MODULE:DoWeaponTrace()

	local Target = self.util:DoTrace()
	
	if ValidEntity( Target ) then 
	
		if Target:IsPlayer() then
		
			self:DrawWeapons( Target )
			
		else
	
			if self.base:GetBool( "Developer" ) then
			
				local Pos = self.util:GetHeadPosition( Target ):ToScreen()
				
				self.util:DrawText( Target:GetClass(), Pos.x, Pos.y, Color( 255, 0, 0 ) )
				
			end
			
		end
		
	end

end

function MODULE:CorrectName( ent )

	local NewName = ""

	if self.base:GetBool( "GamemodeSpecific" ) then
		
		local obj = self.names[ self.base.CurrentGamemode ]
		
		if obj then	
		
			NewName = obj.callback( ent )
			
			if NewName:len() > 0 then
			
				return NewName
			
			end
		
		end
	
	end
	
	//What the fuck are you?
	if not ( ent:IsNPC() || ent:IsPlayer() ) then return ent:GetClass() end
	
	if ent:IsNPC() then return ent:GetClass() end
	
	return ent:Nick()

end

function MODULE:PlayerESP( )

	for k, ply in pairs ( self.util:GetEntityTable() ) do
	
		if ( ValidEntity( ply ) && ( not ( ply == LocalPlayer() ) ) && self.util:GetAlive( ply )  ) then
	
			local DrawColor = self:GetColor( self.util:IsVisible( ply ) )
			
			local TeamColor, TeamName = nil, nil
			
			if ply:IsPlayer() then
				TeamColor, TeamName = team.GetColor( ply:Team() ), team.GetName( ply:Team() )
			end
			
			if ( self.util:ScreenVisible( ply:LocalToWorld(ply:OBBCenter()) ) then
			
				local x1, y1, x2, y2 = self:DrawBox( ply, DrawColor )
				local Name = self:CorrectName( ply )

				local center_x = x1 + ((x2 - x1) / 2)
				
				if TeamName then
					self.util:DrawText( Name, center_x, y1 - (self.util.th * 2), DrawColor )
					self.util:DrawText( TeamName, center_x, y1 - self.util.th, TeamColor )
				else
					self.util:DrawText( Name, center_x, y1 - self.util.th, DrawColor )
				end
				
				if ply:IsPlayer() then
				
					local Admin = self:DrawHealthbar( center_x - 15, y2 + 5, ( ply:Health() or 0 ), ply )
					
					local Weapon = self.util:GetActiveWeapon( ply )

					if self.util:MarkDangerousWeapon( Weapon ) then
					
						DrawColor = Color( 255, 0, 0 )

					end

					if ( ValidEntity( Weapon ) ) then
					
						Weapon = Weapon:GetPrintName() or ""
						
						if Admin then
							self.util:DrawText( Weapon, center_x, y2 + self.util.th + 8, DrawColor )
						else
							self.util:DrawText( Weapon, center_x, y2 + self.util.th + 4, DrawColor )
						end
					
					end
				
				end
			
			end
			
		end
	
	end
	
end

function MODULE:EntityESP( )

	for class, obj in pairs ( self.ents ) do
	
		local entities = ents.FindByClass( class )
		local name = obj.name
	
		for _, ent in pairs ( entities ) do
		
			if ( ValidEntity( ent ) ) then
			
				if not ( ent:GetParent():IsValid() && ent:GetParent():IsPlayer() ) then 
			
					if obj.callback then
						name = obj.callback( ent, name )
					end
					
					if self.base:GetBool( "WeaponClasses" ) then name = ent:GetClass() end
					
					local DrawColor = self:GetColor( self.util:IsVisible( ent ) )
					
					local x1, y1, x2, y2 = self:DrawBox( ent, DrawColor )
								
					self.util:DrawText( name, x1 - ( ( x1 - x2 ) / 2 ), y1 - 12, DrawColor )	
				
				end
			
			end
		
		end
	
	end

end

function MODULE.HUDPaint( )
	if MODULE.base:GetBool( "EspEnabled" ) && MODULE.base:GetBool( "Enabled" ) then
		if MODULE.base:GetBool( "EntityEsp" ) then MODULE:EntityESP() end
		if MODULE.base:GetBool( "PlayerEsp" ) then MODULE:PlayerESP() end
		if MODULE.base:GetBool( "Crosshair" ) then MODULE:DrawCrosshair() end
		
		MODULE:DoWeaponTrace()
		if LocalPlayer():GetNWBool("wanted") then
		
			MODULE.util:DrawText( "Wanted: "..tostring( LocalPlayer():GetNWString("wantedReason") ), 5, 40, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT )	
		end
	end
end

MODULE.RenderPanel = vgui.Create( "DForm" )
MODULE.RenderPanel:ParentToHUD()
MODULE.RenderPanel:SetPos(0, 0)
MODULE.RenderPanel:SetSize(1, 1)
MODULE.RenderPanel:NoClipping( true )
MODULE.RenderPanel.IsDrawing = false

function MODULE.RenderPanel:Paint( w, h )
	MODULE.RenderPanel.IsDrawing = true
	MODULE:HUDPaint()
end

render.oRenderCapture = render.oRenderCapture or render.Capture
render.oRenderClear = render.oRenderClear or render.Clear

function render.Clear( ... )
	MODULE.RenderPanel.IsDrawing = false

	render.oRenderClear( ... )
end

function render.Capture( data )
	if MODULE.RenderPanel.IsDrawing then
		MODULE.RenderPanel:SetVisible( false )
		
		print("[Screengrab Attempt Detected]")

		render.Clear( 0, 0, 0, 255, true, true )
		render.RenderView( { origin = EyePos(), angles = EyeAngles(), x = 0, y = 0, w = ScrW(), h = ScrH(), dopostprocess = true, drawhud = true, drawmonitors = true, drawviewmodel = true } )
		render.RenderHUD( 0, 0, ScrW(), ScrH() )
		
		local WorldPanel = vgui.GetWorldPanel()
		
		if IsValid( WorldPanel ) then WorldPanel:PaintManual() end

		MODULE.RenderPanel:SetVisible( true )
	end
	
	local pixels = render.oRenderCapture( data )

	return pixels
end

function MODULE:LoadEspEntities( )
	self:AddEntity( "weapon_mor_*", "", function( ent, name ) return ent:GetPrintName() end, nil )
	self:AddEntity( "weapon_mad_*", "", function( ent, name ) return ent:GetPrintName() end, nil )
	self:AddEntity( "weapon_*", "", function( ent, name ) return ent:GetPrintName() end, nil )
	self:AddEntity( "dz_item", "", function( ent, name ) return ent:GetPrintName() end, nil )

	self:AddEntity( "rp_money_printer", "Money Printer" )
	self:AddEntity( "info_player_*", "Swag" )
	self:AddEntity( "rp_spawned_money", "Dollars", function( ent, name ) return "$" .. ( ent.dt.amount or 0 ) .. " " .. name end, nil )
	self:AddEntity( "rp_spawned_shipment", "Shipment", function( ent, name ) 
	
		if ent && ent.dt then
	
			local contents = ent.dt.contents or ""
			contents = CustomShipments[contents]
			
			if not contents then 
				return name 
			end
			
			return contents.name .. " " .. name

		end
		
		return name
		
	end, nil )
	
	self:AddEntity( "ts2_item", "", function( ent, name )
	
		if ent:GetTable().ItemName then
			return ent:GetTable().ItemName
		else
			TS.HUDItemInfo[ ent:EntIndex() ] = nil
			RunConsoleCommand( "eng_reciteminfo", ent:EntIndex() )
			
			return ""
		end
	
	end )
	
	self:AddEntity( "ttt_c4", "", function( ent, name )
	
		if math.max( 0, ent:GetExplodeTime() - CurTime() ) == "00:00" then
			return "*C4*"
		elseif math.max( 0, ent:GetExplodeTime() - CurTime() ) ~= "00:00" then
			return "**C4 (" .. string.FormattedTime( math.max( 0, ent:GetExplodeTime() - CurTime() ), "%02i:%02i" ) .. ")**"
		end
	
	end )
	
	self:AddEntity( "aura_item", "", function( ent, name ) return openAura.item:Get( ent:GetDTInt( "index" ) ).name end )
	
end

function MODULE:LoadNameData( )

	self:AddPlayerName( "TacoScript2", function( ent ) return ent:GetRPName() end )

end

PhrozenFire:RegisterModule( MODULE )