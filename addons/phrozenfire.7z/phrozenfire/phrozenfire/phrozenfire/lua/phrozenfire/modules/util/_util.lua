--[[
	MOD/lua/PhrozenFire/PhrozenFire/lua/PhrozenFire/Modules/Util/_util.lua [#6878 (#6878), 3842908125, UID:3354588140]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:44PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "_Util" )

//We won't register this module, so yeah.

MODULE.Name = "#Bobby's favorite _Util#"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

MODULE.util.Font = "DefaultSmall"

MODULE.util.FriendNPCS = {
	"npc_alyx",
	"npc_vortigaunt",
	"npc_turret_floor",
	"npc_citizen",
	"npc_monk",
	"npc_pigeon",
	"npc_seagull",
	"npc_rollermine",
	"npc_dog",
	"npc_breen",
	"npc_gman",
	"npc_magnusson",
	"npc_kleiner",
	"npc_barney",
	"npc_mossman",
	"npc_grenade_bugbait"
}

MODULE.util.npcs = {
	"npc_*",
	"monster_*",
	"zw_zombie_*"
}

MODULE.util.ModelCorrections = {
	["models/combine_scanner.mdl"] = "Scanner.Body",
	["models/hunter.mdl"] = "MiniStrider.body_joint",
	["models/combine_turrets/floor_turret.mdl"] = "Barrel",
	["models/dog.mdl"] = "Dog_Model.Eye",
	["models/antlion.mdl"] = "Antlion.Body_Bone",
	["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
	["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
	["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
	["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body",
	["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
	["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
	["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
};

MODULE.util._GetWeapons = _R.Player.GetWeapons
MODULE.util._GetActiveWeapon = _R.Player.GetActiveWeapon

function MODULE.util:FriendlyNPC( ent )

	if ValidEntity( ent ) then 

		if ent:IsNPC() && table.HasValue( self.FriendNPCS, ent:GetClass() ) then
		
			return true
			
		end
		
	end
	
	return false

end

function MODULE.util:GetHeadPosition( ent )

    local model = ent:GetModel() or ""

	local bone = self.ModelCorrections[ model ]

	if bone then
		bone = ent:LookupBone( bone )

		return ent:GetBonePosition( bone )
 
	end
	
    if model:find("crow") or model:find("seagull") or model:find("pigeon") then
        return ent:LocalToWorld(ent:OBBCenter() + Vector(0,0,-5))
		
    elseif ent:GetAttachment(ent:LookupAttachment("eyes")) ~= nil then
        return ent:GetAttachment(ent:LookupAttachment("eyes")).Pos
		
    else
	
        return ent:LocalToWorld(ent:OBBCenter())
		
    end
	
end

function MODULE.util:GetWeapons( ent )

	if ( ent:IsPlayer() ) then

		return self._GetWeapons( ent )

	end

end

function MODULE.util:GetActiveWeapon( ent )
	
	if ( ent:IsPlayer() ) then

		return self._GetActiveWeapon( ent )

	end

end

function MODULE.util:MarkDangerousWeapon( ent )

	if ent && ValidEntity( ent ) then

		if ent:IsWeapon() then

			if ent && ent.Primary && ( ent.Primary.damage || ent.Primary.Damage ) then

				return true		
			
			end

		end

	end

	return false

end


function MODULE.util:IsVisible( ent )

	if ent:IsValid() then

		local trace = {
		
			start = LocalPlayer():GetShootPos(), 
			endpos = self:GetHeadPosition( ent ), 
			filter = { LocalPlayer(), ent },
			mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
		}
					
		local tr = util.TraceLine(trace)
		
		if tr.Fraction == 1 then
		
			return true
			
		else
		
			return false
			
		end 
	
	end

end

function MODULE.util:GetAlive( ent )
	
	local movetype = ent:GetMoveType()	
				
	if ( movetype == MOVETYPE_NONE ) then return false end
	
	if ( ent:IsPlayer() ) then
	
		if not ( ent:Alive() ) then return false end
	
	end
	
	return true

end

function MODULE.util:GetCoordiantes( ent )

	local min, max = ent:OBBMins(), ent:OBBMaxs()
	
	local corners = {
	
		Vector(min.x,min.y,min.z),
		Vector(min.x,min.y,max.z),
		Vector(min.x,max.y,min.z),
		Vector(min.x,max.y,max.z),
		Vector(max.x,min.y,min.z),
		Vector(max.x,min.y,max.z),
		Vector(max.x,max.y,min.z),
		Vector(max.x,max.y,max.z)
		
	}

	local minx, miny, maxx, maxy = ScrW() * 2, ScrH() * 2, 0, 0
	
	for _, corner in pairs( corners ) do
	
		local screen = ent:LocalToWorld( corner ):ToScreen()
		
		minx, miny = math.min( minx, screen.x ), math.min( miny, screen.y )
		maxx, maxy = math.max( maxx, screen.x ), math.max( maxy, screen.y )
		
	end
	
	return minx, miny, maxx, maxy
	
end

function MODULE.util:GetNPCTable( )
	local output = {}

	for i = 1, #self.npcs do
		local npcs = ents.FindByClass( self.npcs[i] )

		for _, ent in pairs ( npcs ) do
			table.insert( output, ent )
		end
	end
	return output

end

function MODULE.util:GetEntityTable( )
	local output = self:GetNPCTable( )

	for _, ply in pairs ( player.GetAll() ) do
		table.insert( output, ply )
	end

	return output
end

function MODULE.util:GetReloadTime( )

	if ( ValidEntity( LocalPlayer():GetViewModel() ) ) then

		return LocalPlayer():GetViewModel():SequenceDuration()

	end

	return 0

end

function MODULE.util:IsAdmin( ply )
	
	if not ply:IsPlayer() then return false end
	
	if ( ply:IsAdmin() ||
		 ply:IsSuperAdmin() ||
		 ply:IsUserGroup( "Admin" ) || 
		 ply:IsUserGroup( "admin" ) ) then 
		return true
	end
	
	return false
	
end

function MODULE.util:FillRGBA( x, y, w, h, col )

    surface.SetDrawColor( col.r, col.g, col.b, col.a )
    surface.DrawRect( x, y, w, h )
	
end

function MODULE.util:OutlineRGBA( x, y, w, h, col )

    surface.SetDrawColor( col.r, col.g, col.b, col.a )
    surface.DrawOutlinedRect( x, y, w, h )
	
end

function MODULE.util:DrawText( text, x, y, color, xalign, yalign )

	xalign = xalign or TEXT_ALIGN_CENTER
	yalign = yalign or TEXT_ALIGN_CENTER
	
	if MODULE.base:GetBool( "SimpleText" ) then
		draw.SimpleText( text, "DefaultSmall", x, y, color, xalign, yalign )
	else
		draw.SimpleTextOutlined( text, self.font, x, y, color, xalign, yalign, 1, Color( 0, 0, 0, 255 ) )
	end
	
end

function MODULE.util:ScreenVisible( screen )

	if (screen.x > 0 && screen.x < ScrW() &&
		screen.y > 0 && screen.y < ScrH()) then
		
		return true
		
	else
	
		return false
		
	end
	
end

function MODULE.util:NormaliseAngle( ang )

	if ang < 180 then
	
		return ang
		
	end
	
	return ( ang % 180 ) - 180
	
end

function MODULE.util:DoTrace()

	local pos = LocalPlayer():GetShootPos()
	local ang = LocalPlayer():GetAimVector()
	
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos + (ang * 10000000)
	tracedata.filter = LocalPlayer()
	
	local trace = util.TraceLine( tracedata )

	if trace.HitNonWorld then
	   
	   return trace.Entity
	
	end
	
	return nil
	
end

function MODULE.util:SetFont( str )

	self.font = str or "DefaultSmall"
	
	surface.SetFont( self.font )
	self.tw, self.th = surface.GetTextSize( " " )

end

//Why would we register this module? We get a handle to util, and we use it.
//PhrozenFire:RegisterModule( MODULE )