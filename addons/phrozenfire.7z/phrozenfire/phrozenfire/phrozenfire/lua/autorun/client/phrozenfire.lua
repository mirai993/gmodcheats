--[[
	MOD/lua/PhrozenFire/PhrozenFire/lua/autorun/client/PhrozenFire.lua [#6131 (#6131), 3140517794, UID:2932231190]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:44PM]
	===BadFile===
]]

require( "fbse" ) //This will create our table.

//ConVar, { ScriptText, Default Value, Min, Max }
PhrozenFire.cVars = {

	["core_enabled"] 		= { "enabled", 1, 0, 1 },
	["core_simpletext"]		= { "simpletext", 0, 0, 1 }
	
}

function PhrozenFire:Init()

	self.prefix = "ph_"
	
	//For plugins with gamemode specific features.
	self.CurrentGamemode = ""
	
	self.Modules = {}
	self.data = {}
	self.util = {}
	self.Hooks = {}
	self.Detours = {}
	
	//Lets init the defaults.
	self:CreateClientVars(  )
	
	//We load all of our modules. They should register in the table.
	//If not, free lua autorun!
	self:LoadModules()
	
	self.util:SetFont( "DefaultSmall" )
	
	//I suppose we should take care of convars.
	for k, Module in pairs ( self.Modules ) do

		if not ( Module.Special ) then
		
			local cVars = Module.cVars or {}
			self:CreateClientVars( cVars ) //We load our convars for that module first.
			
			//And the hooking.
			for hk, ht in pairs ( Module.Hooks ) do // for hookname, hooktable
			
				for _, t in pairs ( ht ) do // for index, 
				
					self:AddHook( hk, t ) // second index is our function.
			
				end
				
			end
			
			if ( Module.Init ) then Module:Init() end

		end
	
	end

	concommand.Add( self.prefix .. "core_reload", function() PhrozenFire:Reload() end )

end

//Swag...
function PhrozenFire:LoadModules( )

	local Modules 	= file.FindInLua("PhrozenFire/Modules/*.lua")
	local Util 		= file.FindInLua("PhrozenFire/Modules/Util/*.lua")

	for _, Module in pairs( Util ) do
	
		include( "PhrozenFire/Modules/Util/" .. Module )
		
	end
	
	for _, Module in pairs( Modules ) do
	
		include( "PhrozenFire/Modules/" .. Module )
		
	end

end

//Registers every variable in our cVarList.
function PhrozenFire:CreateClientVars( cVarList )

	local tab = cVarList or self.cVars
	
	if ( cVarList ) then
	
		table.Merge( self.cVars, cVarList )
	
	end

	for k, v in pairs ( tab ) do
		
		self:RegisterClientVar( k, v )
		
	end

end

function PhrozenFire:RegisterClientVar( name, varData )
	
	//Append our prefix to our index, creating our cvar.
	local NewCVar = string.lower( self.prefix .. name )
	
	//This is just making sure we don't overwrite our old value.
	local oldValue = GetConVarNumber( NewCVar )
	
	//Create our cvar with our listed default value.
	CreateClientConVar( NewCVar, varData[2], true, false )

	//Add a callback for our variable.
	cvars.AddChangeCallback( NewCVar, function( a, b, c )
	
		self:SetValue( a, b, c ) 
		
	end )
	
	//Set the value in our script.
	local value = GetConVarNumber( NewCVar )

	self:SetValue( NewCVar, oldValue, value )		

end

//Generates a random string.
function PhrozenFire:GenerateRandomString( chars, seed )

	local str = ""
	
	math.randomseed( seed or os.time() )
	
	for i = 1, chars do
	
		str = str .. ( string.char( math.Rand( 65, 90 ) ) )
		
	end
	
	return str
	
end

function PhrozenFire:SetValue( var, oldvalue, value )
	
	//Remove our prefix
	local tvar = var:sub( self.prefix:len() + 1 )
	
	local varData = self.cVars[tvar]
	
	//Get our code's variable name from our cvar table.
	tvar = varData[1]
	
	//Now we set our value.
	self.data[ tvar ] = tonumber( value )

end

function PhrozenFire:GetValue( var )
	
	//Return our value.
	return tonumber( self.data[ var:lower() ] ) or 0

end

function PhrozenFire:GetBool( var )
	
	//Get our value.
	local val = self:GetValue( var )
	
	//Return if our value is equal to 1
	return ( val == 1 ) 

end

//Removes all of the hooks inside of our hook table, and then clears the table.
function PhrozenFire:ClearHooks()

	//Interate through every entry.
	for k, v in pairs( self.Hooks ) do
		
		//Our value is also a table, let's go through that.
		for _, t in pairs ( v ) do
			
			//Nodify us of the removed hook, and then remove it.
			chat.AddText( Color( 255, 255, 255 ), "[PhrozenFire]: ", Color(255,60,60), "Hook " .. k .. " removed.(" .. t[1] .. ")" )
			hook.Remove( k, t[1] )
		
		end
	
	end
	
	//None of the hooks exist anymore. Remove them.
	table.Empty( self.Hooks )

end

//Adds a hook to our hook table under a unique, randomly generated name.
function PhrozenFire:AddHook( h, f )
	
	//This is what we identify our hook as uniquely.
	local Name = self:GenerateRandomString( 12 )
	local Function = f
	
	//If we haven't added this hook already, add a new entry as a table.
	if not self.Hooks[h] then self.Hooks[h] = {} end
	
	//Inside of this, we add our HookIndetifyer. and our functions.
	table.insert( self.Hooks[h], { Name, Function } )
	
	//Now, actually add the hook.
	hook.Add( h, Name, Function )
	
	chat.AddText( Color( 255, 255, 255 ), "[PhrozenFire]: ", Color( 60, 255, 60 ), "Hook " .. h .. " added.(" .. Name .. ")" )

end

function PhrozenFire:AddManagedDetour( detoured, original )

	self.Detours[original] = detoured

end

function PhrozenFire:Reload()
	
	local str = self:GenerateRandomString( 12 )

	self:ClearHooks()

	for original, detour in pairs ( self.Detours ) do

		detour = original

	end
	
	for _, Module in pairs ( self.Modules ) do
	
		for _, v in pairs ( Module ) do

			if type( v ):lower() == "panel" then
				v:Remove()
			end
		
			v = nil
		
		end
	
	end
	
	timer.Create( str, 0.5, 1, function()
	
		include("autorun/client/PhrozenFire.lua")

		PhrozenFire:Init()
		
	end)

end

//This just takes a few things from the object, and makes a entry in our table.
function PhrozenFire:RegisterModule( object )

	self.Modules[ object.handle ] = object

end

//Initialize a new table for our modules. This function just exists so we can set default values.
function PhrozenFire:NewModule( Name )

	local object = {}

	object.Name 	= Name or "#Bobby's favorite PhrozenFire module#"
	object.Author	= "Bobby"
	object.Version 	= 0
	object.handle 	= self:GenerateRandomString( 5 )
	object.base 	= self //Lets give our modules a reference to PhrozenFire ;).
	object.util		= self.util
	object.Hooks	= {}
	
	return object
	
end

PhrozenFire:Init()

hook.Add("Think", "Phrozenfire.wtfload", function()

	for k, Module in pairs ( PhrozenFire.Modules ) do
	
		if ( Module.Init && Module.Special && vgui ) then 
			Module:Init()
			hook.Remove("Think", "Phrozenfire.wtfload" )
		end
	
	end

end)