--[[
	MOD/lua/PhrozenFire/Modules/_protection.lua [#2766 (#2766), 1436367594, UID:1178890608]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:39PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "PhrozenProtection" )

MODULE.id = "protection"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

function MODULE:Print( msg )
	local Console = PhrozenFire:GetModuleByID("console")
	Console:AddText( Color(255, 0, 0), "[Protection] ", Color(255, 255, 255),  msg .. ".")
end

function MODULE:Init()
	local detours = PhrozenFire:GetModuleByID( "detours" )

	PhrozenFire.NoDraw = false

	detours:func( "debug", "getinfo", function( old, func )
		if TypeID(func) == TYPE_FUNCTION then
			local original = detours.patches[func]

			if original then
				return old(original)
			end
		else
			local info = old(func)

			local original = detours.patches[info.func]

			if original then
				return old(original)
			end
		end

		return old(func)
	end )

	detours.hook:Add( "HUDPaint", "ScreenshotProtection", function()
		PhrozenFire.IsDrawing = true
	end )

	detours:func( "render", "Clear", function( old, ... )
		PhrozenFire.IsDrawing = false

		return old( ... )
	end )

	detours:func( "render", "Capture", function( old, data )
		if PhrozenFire.IsDrawing then
			self:SetAllPanels( PhrozenFire.BaseModules, false )
			self:SetAllPanels( PhrozenFire.Modules, false )
			
			self:Print("The Server is attempting to screenshot your client. Cleaning screenshot...")

			PhrozenFire.NoDraw = true

			render.Clear( 0, 0, 0, 255, true, true )
			render.RenderView( {
				origin = LocalPlayer():EyePos(),
				angles = LocalPlayer():EyeAngles(),
				x = 0,
				y = 0,
				w = ScrW(),
				h = ScrH(),
				dopostprocess = true,
				drawhud = true,
				drawmonitors = true,
				drawviewmodel = true
			} )
			
			local WorldPanel = vgui.GetWorldPanel()
			
			if IsValid( WorldPanel ) then WorldPanel:PaintManual() end

			PhrozenFire.NoDraw = false

			self:RestorePanels( PhrozenFire.BaseModules )
			self:RestorePanels( PhrozenFire.Modules )
		end

		return old(data)
	end )

	detours.hook:FlagProtected( "HUDPaint" )
	detours.hook:FlagProtected( "RenderScreenspaceEffects" )
end

function MODULE:OnRemove()
	local detours = PhrozenFire:GetModuleByID( "detours" )

	detours.hook:Remove( "HUDPaint", "ScreenshotProtection" )
end

function MODULE:SetAllPanels( Modules, bool )
	for k, obj in pairs( Modules ) do
		local Module = obj.Module

		for index, data in pairs( Module ) do
			if TypeID(data) == TYPE_PANEL then
				data.oldVisible = data:IsVisible()
				data:SetVisible( bool )
			end
		end
	end
end

function MODULE:RestorePanels( Modules )
	for k, obj in pairs( Modules ) do
		local Module = obj.Module

		for index, data in pairs( Module ) do
			if TypeID(data) == TYPE_PANEL then
				if data.oldVisible == true then
					data:SetVisible( data.oldVisible or true )
				end
			end
		end
	end
end

PhrozenFire:RegisterModule( MODULE )
