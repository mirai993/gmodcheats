--[[
	MOD/lua/PhrozenFire/Modules/_esp.lua [#17735 (#17735), 331299556, UID:2111466715]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:39PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "PhrozenEsp" )

MODULE.id = "esp"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

MODULE.cVars = {
	["esp_enabled"]				= { "espenabled"		, 1, 0, 1, "Enabled" },
	["esp_players"] 			= { "playeresp"			, 1, 0, 1, "Player Esp" },
	["esp_bbox"] 				= { "box"				, 1, 0, 1, "Box Esp" },
	["esp_3dbbox"] 				= { "3dbox"				, 1, 0, 1, "Use 3D Bounding Box" },
	["esp_modelfullbright"] 	= { "modelfullbright"	, 1, 0, 1, "Model Fullbright" },
	["esp_entities"] 			= { "entityesp"			, 1, 0, 1, "Entity Esp" },
	["esp_laseresp"] 			= { "laseresp"			, 1, 0, 1, "Laser Eyetrace Esp" },
	["esp_chamsesp"] 			= { "chamsesp"			, 1, 0, 1, "Chams Esp" },
	["esp_showweaponclasses"]	= { "weaponclasses"		, 1, 0, 1, "Use Weapon Classes" },
	["esp_developer"] 			= { "developer"			, 1, 0, 1, "Developer Mode" },
	["hud_crosshair"] 			= { "crosshair"			, 1, 0, 1, "Draw Crosshair" },
	["esp_gamemodenames"]		= { "gamemodespecific"	, 1, 0, 1, "Use Gamemode-Specific Names" },
	["esp_distanced"]			= { "distancebased"		, 1, 0, 1, "Check Distance" },
	["esp_distance"]			= { "maxdistance"		, 2000, 0, 99999, "Maximum Distance" }
}

--Initialize function for the current module.
function MODULE:Init()
	self.ents, self.names, self.Observers = {}, {}, {}
	
	self.Color1 = Color( 250, 250, 0 )
	self.Color2 = Color( 100, 100, 255 )

	self:LoadEspEntities()
	self:LoadNameData()

	local Texture = {
        ["$basetexture"] = "models/debug/debugwhite",
        ["$model"]       = 1,
        ["$translucent"] = 1,
        ["$alpha"]       = 1,
        ["$nocull"]      = 1,
        ["$ignorez"]     = 1
    }

   	self.ChamTexture = CreateMaterial( "PHRCHM", "VertexLitGeneric", Texture )
end

--Adds an entity class to be parsed in the entity esp system.
function MODULE:AddEntity( gamemode, class, name, callback, color )
	local loaded_ents = scripted_ents.GetList()

	if self.ents and loaded_ents[class] then
		local obj = {
			class 		= class,
			name 		= name or "",
			callback	= callback or nil,
			color		= color or Color( 255, 255, 255 )	
		}
		
		self.ents[ #self.ents + 1 ] = obj
	end
end

--Adds a custom callback per gamemode to obtain a player's name.
function MODULE:AddPlayerName( GM, func )
	if self.names && not self.names[ GM ] then
		local obj = {
			callback = func
		}
		
		self.names[ GM ] = obj
	end
end

--Gets the visibility color for the esp.
function MODULE:GetColor( bIsVisible )
	if bIsVisible then 
		return self.Color1 
	end

	return self.Color2
end

function MODULE:DrawBoundingBox( ent, min, max, is3d, color )
	local Corners = {}

	local Box = {
		{ 1, 2, 4, 6 },
		{ 2, 7, 3, 0 },
		{ 4, 5, 3, 0 },
		{ 6, 5, 7, 0 },	
		{ 8, 5, 7, 3 }
	}

	Corners[#Corners + 1] = Vector( min.x, min.y, min.z ) //Corner 1
	Corners[#Corners + 1] = Vector( max.x, min.y, min.z ) //Corner 2
	Corners[#Corners + 1] = Vector( max.x, min.y, max.z ) //Corner 3
	Corners[#Corners + 1] = Vector( min.x, min.y, max.z ) //Corner 4
	Corners[#Corners + 1] = Vector( min.x, max.y, max.z ) //Corner 5
	Corners[#Corners + 1] = Vector( min.x, max.y, min.z ) //Corner 6
	Corners[#Corners + 1] = Vector( max.x, max.y, min.z ) //Corner 7
	Corners[#Corners + 1] = Vector( max.x, max.y, max.z ) //Corner 8
	
	for a = 1, #Box do
		local Start = Corners[Box[a][1]]

		if not is3d then
			Start = Start:ToScreen()
		end
		
		for b = 1, #Box[a] do
			if Box[a][b] == 0 then
				continue
			end

			local End = Corners[Box[a][b]]

			if not is3d then
				End = End:ToScreen()
			end

			surface.SetDrawColor( color )
			surface.DrawLine( Start.x, Start.y, End.x, End.y )
		end
	end
end

--Draws a box around the given entity.
function MODULE:DrawBox( EntObj, DrawColor )
	local x1, y1, x2, y2 = self.util:GetCoordiantes(EntObj)
	
	if self.base:GetBool( "Box" ) then
		--Draw 3d bounding box
		if self.base:GetBool( "3DBox" ) then
			local min, max = EntObj:WorldSpaceAABB()

			self:DrawBoundingBox( EntObj, min, max, false, DrawColor )
		else
			--Colored box
			surface.SetDrawColor( DrawColor )
			surface.DrawOutlinedRect(x1, y1, x2 - x1, y2 - y1)
			
			--Black border
			surface.SetDrawColor(Color(0, 0, 0, 255))
			surface.DrawOutlinedRect(x1-1, y1-1, x2 - x1 + 2, y2 - y1 + 2)
			surface.DrawOutlinedRect(x1+1, y1+1, x2 - x1 - 2, y2 - y1 - 2)
		end
	end
	local box = {x = x1, y = y1, w = x2 - x1, h = y2 - y1}
	box.middle_x = box.x + box.w/2
	box.middle_y = box.y + box.h/2

	return box
end

--Draws a crosshair in the center of our screen.
function MODULE:DrawCrosshair( )
	local midx = ScrW() / 2
	local midy = ScrH() / 2
	
	local size = 30

	surface.SetDrawColor( Color( 0, 0, 0 ) )

	surface.DrawRect( midx - 2, midy - (size/2), 3, size+1 )
	surface.DrawRect( midx - (size/2) - 1, midy - 1, size+1, 3 )

	surface.SetDrawColor( self.Color1 )

	surface.DrawLine( midx - 1, midy - size/2 + 1, midx - 1, midy + size/2)
	surface.DrawLine( midx - size/2 , midy, midx + size/2 - 1, midy)
end

--Draws a healthbar at the given coordinates, as well as an admin indicator.
--Returns whether or not the admin indicator is being drawn.
function MODULE:DrawHealthbar(x, y, w, h, Value, PlayerObj)
	Value = math.Clamp( Value / 100, 0, 1 )

	--Black Border
	self.util:FillRGBA( x, y-1, w, h, Color(0, 0, 0, 255) )
	--Green Bar
	self.util:FillRGBA( x+1, y, (w-2)*Value, h-2, Color(0, 255, 0, 255) )
	
	--Admin indicator
	if self.util:IsAdmin( PlayerObj ) then
		self.util:FillRGBA( x + 2, y + 4, 6, 6, Color( 0, 0, 0, 255 ) )
		self.util:FillRGBA( x + 3, y + 5, 4, 4, Color( 150, 150, 255 ) )
		
		return true
	end
		
	return false
end

--Draws a player's weapons on the outside of their bounding box.
function MODULE:DrawWeapons( EntityObj, Box )
	local Weapons = self.util:GetWeapons( EntityObj ) or {}
	
	--If there's no weapons, draw that and return.	
	if #Weapons == 0 then
		self.util:DrawText( "No Weapons", Box.x + Box.w, Box.y, Color(50, 255, 50, 255) )
		return
	end

	for i = 1, #Weapons do
		--Skip if there's no weapon
		if Weapons[i] == nil then
			continue
		end

		local Name = Weapons[i]:GetPrintName()

		if self.base:GetBool( "WeaponClasses" ) then
			Name = Weapons[i]:GetClass()
		end

		self.util:DrawText( Name, Box.x + Box.w, Box.y + (self.util.th * i) + 10, Color(50, 255, 50, 255), 0, 0 )
	end
end

--Traces a line from your view to find the player who's weapons will be drawn.
function MODULE:DoWeaponTrace()
	local Target = self.util:DoTrace()
	
	if not IsValid( Target ) then
		self.MouseTarget = nil
		return
	end
	
	--Draw their weapons.
	if Target:IsPlayer() then
		self.MouseTarget = Target
		return
	end
	
	--Draw the classname of the currently viewed target if we're set to developer mode.
	if self.base:GetBool( "Developer" ) then
		local Pos = self.util:GetHeadPosition( Target ):ToScreen()
		
		self.util:DrawText( Target:GetClass(), Pos.x, Pos.y, Color( 255, 0, 0 ) )
	end
end

--Gets a clean name for the object based on the gamemode.
function MODULE:CorrectName( EntObj )
	local Name = ""

	if self.base:GetBool( "GamemodeSpecific" ) then
		local obj = self.names[ self.base.CurrentGamemode ]

		if obj then	
			Name = obj.callback( EntObj )
			
			if Name:len() > 0 then
				return Name
			end
		end
	end
	
	--Return the class name if it's not a player.
	if !EntObj:IsPlayer() then 
		return EntObj:GetClass() 
	end
	
	--Return the player's nickname.
	return EntObj:Nick()
end

--Iterates through every entity - this also draws npcs.
function MODULE:EntityIterator( )
	local EntityList = ents.GetAll()

	--Lets not retrieve these every iteration if we don't need to
	local MaxDistance, bDistanceCheck, EntsEnabled = self.base:GetValue( "MaxDistance" ), self.base:GetBool("DistanceBased"), self.base:GetBool( "EntityEsp" )

	if not EntsEnabled then
		EntityList = player.GetAll()
	end	

	for i = 1, #EntityList do
		local EntityObj = EntityList[i]
		
		--Check if it's a valid object and it's not our player.
		if not IsValid( EntityObj ) or EntityObj == LocalPlayer() then
			continue
		end

		--This is for our spectate hack - while, in our entity iterator, 
		if EntityObj:IsPlayer() and EntityObj.GetObserverTarget then
			if EntityObj:GetObserverTarget() == LocalPlayer() and not self.Observers[PlayerObj] then
				self.Observers[PlayerObj] = true
			end
		end

		--Check if the entity is alive
		if not self.util:GetAlive(EntityObj) then
			continue
		end

		--Check if the given position is visible on our screen.
		if not self.util:ScreenVisible(EntityObj:GetPos():ToScreen()) then
			continue
		end

		--This is a less expensive way of comparing distance.
		local Distance = EntityObj:GetPos():DistToSqr(LocalPlayer():GetPos())

		if bDistanceCheck and Distance > MaxDistance then
			continue
		end

		--If we're not dealing with an NPC or player, pass it to our EntityESP
		if not EntityObj:IsPlayer() and not EntityObj:IsNPC() then
			if EntsEnabled then
				self:EntityESP( EntityObj )
			end

			continue
		end

		--Get our draw color and draw our box. This returns our box coordinates.
		local DrawColor = self:GetColor(self.util:IsVisible(EntityObj)) 
		local Box = self:DrawBox( EntityObj, DrawColor )

		if IsValid( self.MouseTarget ) and self.MouseTarget == EntityObj then
			self:DrawWeapons( self.MouseTarget, Box )
		end

		--Get our object's name. Define teamname incase it's a player.
		local Name, TeamName, TeamColor = self:CorrectName(EntityObj), nil, nil
			
		--Grab our team name.
		if EntityObj:IsPlayer() then 
			TeamName = team.GetName(EntityObj:Team())
			TeamColor = team.GetColor(EntityObj:Team())
		end
		
		--If the player has a team name, draw it.
		if TeamName then
			self.util:DrawText( Name, Box.middle_x, Box.y - (self.util.th * 2), DrawColor )
			self.util:DrawText( TeamName, Box.middle_x, Box.y - self.util.th - 2, TeamColor )
		else
			self.util:DrawText( Name, Box.middle_x, Box.y - self.util.th, DrawColor)
		end
		
		--Player only code past this point	
		if not EntityObj:IsPlayer() then
			continue
		end

		local IsAdmin = self:DrawHealthbar( Box.x, Box.y + Box.h + 2, Box.w, 4, EntityObj:Health() or 0, EntityObj )
		local Weapon = self.util:GetActiveWeapon( EntityObj )

		--Todo: Make this function more extensive.
		if self.util:MarkDangerousWeapon( Weapon ) then
			DrawColor = Color( 255, 0, 0 )
		end

		--If the weapon is valid, draw it
		if IsValid( Weapon ) then
			Weapon = Weapon:GetPrintName() or ""
			
			if IsAdmin then
				self.util:DrawText(Weapon, Box.middle_x, Box.y + Box.h + 8, DrawColor)
			else
				self.util:DrawText(Weapon, Box.middle_x, Box.y + Box.h + 4, DrawColor)
			end
		end
	end
end

--Passes our entity through our ents table.
function MODULE:EntityESP( EntityObj )
	for i = 1, #self.ents do
		local Object = self.ents[i]
		local Name = Object.Name

		if not string.match(string.lower(EntityObj:GetClass()), Object.Class) then
			continue
		end
		
		if not IsValid(EntityObj) or (IsValid(EntityObj:GetParent()) and EntityObj:GetParent():IsPlayer()) then
			continue
		end

		if Object.Callback then
			Name = Object.Callback( EntityObj, Name )
		end
		
		if self.base:GetBool( "WeaponClasses" ) then 
			Name = EntityObj:GetClass() 
		end
		
		local DrawColor = self:GetColor(self.util:IsVisible(EntityObj))
		local Box = self:DrawBox(EntityObj, DrawColor)
					
		self.util:DrawText( Name, Box.middle_x, Box.y - self.util.th, DrawColor )
	end
end

function MODULE:DrawSpectators()
	self.util:DrawText( "Spectators:", 40, 200 - self.util.th, Color( 255, 150, 0, 255), 0)

	local i = 0
	for Player, _ in pairs( self.Observers ) do

		if not IsValid( Player ) or Player:GetObserverTarget() ~= LocalPlayer() then
			self.Observers[Player] = nil
			continue
		end

		self.util:DrawText(self:CorrectName(Player), 40, 200 + (i * self.util.th), Color(255, 180, 0, 255), 0)
		i = i + 1
	end
end

function MODULE:HUDPaint( )
	if not self.base:GetBool( "Enabled" ) or not self.base:GetBool( "EspEnabled" ) then
		return
	end

	self:DrawSpectators()

	if self.base:GetBool( "PlayerEsp" ) or self.base:GetBool( "EntityEsp" ) then self:EntityIterator() end
	if self.base:GetBool( "Crosshair" ) then self:DrawCrosshair() end
	
	self:DoWeaponTrace()
end

function MODULE:Chams( )
	local Conversion = (1 / 255)

	local MaxDistance, bDistanceCheck, bLaser = self.base:GetValue( "MaxDistance" ), self.base:GetBool( "DistanceBased" ), self.base:GetBool( "LaserEsp" )
	local bChams, bModelFullbright = self.base:GetBool( "ChamsEsp" ), self.base:GetBool( "ModelFullbright" )

    if not bChams then
    	return
    end

	local EntityList = player.GetAll()
	
	cam.Start3D( EyePos(), EyeAngles() )
	
	for i = 1, #EntityList do
		local PlayerObj = EntityList[i]

		if not IsValid( PlayerObj ) or not PlayerObj:IsPlayer() or PlayerObj == LocalPlayer() or not self.util:GetAlive(PlayerObj) then
			continue
		end

		local Distance = LocalPlayer():GetPos():DistToSqr(PlayerObj:GetPos())

		if bDistanceCheck and Distance > MaxDistance then
			continue
		end

    	local Weapon = PlayerObj:GetActiveWeapon()

    	local TeamColor = Color( 255, 255, 255 )

    	if PlayerObj:IsPlayer() then
    		TeamColor = team.GetColor( PlayerObj:Team() )
    	end

    	local tr, Length, Attachment

    	if bLaser then
    		tr = util.TraceLine(util.GetPlayerTrace( PlayerObj ) )
        	Length = (tr.StartPos - tr.HitPos):Length()

        	local id = PlayerObj:LookupAttachment("eyes")

			if id == 0 then 
				return 
			end

			Attachment = PlayerObj:GetAttachment(id)

			render.SetMaterial( Material( "trails/laser" ) )
			render.DrawBeam(Attachment.Pos, tr.HitPos, 10, 1, Length / 128, TeamColor)	

			render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
			render.DrawQuadEasy(tr.HitPos, tr.HitNormal, 10, 10, TeamColor, 0 )
    	end
        
        --Set up for our first pass - drawing the cham player.
       	render.SuppressEngineLighting( true )
        render.MaterialOverride( self.ChamTexture )
        render.SetColorModulation( TeamColor.r * Conversion, TeamColor.g * Conversion, TeamColor.b * Conversion )

        PlayerObj:DrawModel()

        if IsValid( Weapon ) then
        	--If our player has a weapon, draw it as well.
        	render.SetColorModulation( 1, 1, 1 )
        	Weapon:DrawModel()
        end

        --If we don't want the original model drawn with full bright, disable it here.
        if not bModelFullbright then
        	render.SuppressEngineLighting( false )
        end

        render.MaterialOverride()
      	render.SetColorModulation( 1, 1, 1 ) 

        PlayerObj:DrawModel()

        --If instead, we have ModelFullbright, disable it after we draw our original.
        if bModelFullbright then
       		render.SuppressEngineLighting( false )
       	end
       	
       	--Do the same for our weapon.
        if IsValid( Weapon ) then
        	Weapon:DrawModel()
        end

        --If we have laser esp enabled, draw it after we draw everything else.
        if bLaser then
    		tr = util.TraceLine(util.GetPlayerTrace( PlayerObj ) )
        	Length = (tr.StartPos - tr.HitPos):Length()

        	local id = PlayerObj:LookupAttachment("eyes")

			if id == 0 then 
				return 
			end

			Attachment = PlayerObj:GetAttachment(id)

			render.SetMaterial( Material( "trails/laser" ) )
			render.DrawBeam(Attachment.Pos, tr.HitPos, 10, 1, Length / 128, TeamColor)	

			render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
			render.DrawQuadEasy(tr.HitPos, tr.HitNormal, 10, 10, TeamColor, 0 )
    	end
    end
    
    cam.End3D()
end

function MODULE:LoadEspEntities( )
	self:AddEntity( "obj_item", "", function( ent, name ) return GAMEMODE:GetName( ent ) end, nil )
	self:AddEntity( "money_printer", "Money Printer" )
	self:AddEntity( "spawned_money", "", function( ent, name ) 
		return "Money " .. "[" .. ent:Getamount() .. "]"
	end )
	self:AddEntity( "obj_workbench", "", function( ent, name ) return GAMEMODE:GetName( ent ) end, nil )
	self:AddEntity( "obj_container", "", function( ent, name ) 
		local IsEmpty = ent:IsEmpty()

		if ( IsEmpty ) then
			return ""
		end

		IsEmpty = ""

		return GAMEMODE:GetName( ent ) .. IsEmpty
	end, nil )

	self:AddEntity( "rp_money_printer", "Money Printer" )
	self:AddEntity( "rp_spawned_money", "Dollars", function( ent, name ) return "$" .. ( ent.dt.amount or 0 ) .. " " .. name end, nil )
	self:AddEntity( "rp_spawned_shipment", "Shipment", function( ent, name ) 
		if ent && ent.dt then
			local contents = ent.dt.contents or ""
			contents = CustomShipments[contents]
			
			if not contents then 
				return name 
			end
			
			return contents.name .. " " .. name
		end
		
		return name
	end, nil )
	
	self:AddEntity( "ts2_item", "", function( ent, name )
		if ent:GetTable().ItemName then
			return ent:GetTable().ItemName
		else
			TS.HUDItemInfo[ ent:EntIndex() ] = nil
			RunConsoleCommand( "eng_reciteminfo", ent:EntIndex() )
			
			return ""
		end
	end )
	
	self:AddEntity( "ttt_c4", "", function( ent, name )
		if math.max( 0, ent:GetExplodeTime() - CurTime() ) == "00:00" then
			return "*C4*"
		elseif math.max( 0, ent:GetExplodeTime() - CurTime() ) ~= "00:00" then
			return "**C4 (" .. string.FormattedTime( math.max( 0, ent:GetExplodeTime() - CurTime() ), "%02i:%02i" ) .. ")**"
		end
	end )
	
	self:AddEntity( "aura_item", "", function( ent, name ) return openAura.item:Get( ent:GetDTInt( "index" ) ).name end )

	self:AddEntity( "bp_item", "", function( ent, name ) 
		local itemData = blueprint.item.Get( ent:GetSharedVar("sh_Index") ) 

		if ( itemData ) then
			return itemData.name
		end
		
		return ""
	end )
end

function MODULE:LoadNameData( )
	self:AddPlayerName( "TacoScript2", function( ent ) return ent:GetRPName() end )
end

MODULE.Hooks = {
	["RenderScreenspaceEffects"] = { function() MODULE:Chams() end },
	["HUDPaint"] = { function() MODULE:HUDPaint() end }
}

PhrozenFire:RegisterModule( MODULE )