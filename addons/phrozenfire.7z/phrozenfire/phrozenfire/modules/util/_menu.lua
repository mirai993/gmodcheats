--[[
	MOD/lua/PhrozenFire/Modules/Util/_menu.lua [#2795 (#2795), 1806170513, UID:364312089]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:42PM]
	===BadFile===
]]


local MODULE = PhrozenFire:NewModule( "_Menu" )

MODULE.Name = "#Bobby's favorite PhrozenFire Menu#"
MODULE.id = "menu"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

//Since we get access to the PhrozenFire table from the module, lets not even register the plugin.
//By the time these functions get added in, we should be good.

MODULE.base.Menu = {
	DisplayInfo = {
		"Author",
		"Version"
	}
}

local Menu = MODULE.base.Menu

concommand.Add( PhrozenFire.prefix .. "core_menu", function()
	if Menu then
		Menu:Open()
	end
end)

function Menu:Open()
	self.Panel = vgui.Create( "DFrame" )
	self.Panel:SetSize( 640, 400 )
	self.Panel:Center()
	self.Panel:MakePopup()
	self.Panel:SetTitle( "PhrozenFire::Menu")

	self.PanelBack = vgui.Create( "DForm", self.Panel )
	self.PanelBack:SetPos( 204, 26 )
	self.PanelBack:SetSize( 430, 369 )
	self.PanelBack:SetName( "")

	function self.PanelBack:Paint(w, h)
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 155, 115, 100 ) )
		surface.SetDrawColor(Color(0,0,0,255))
		surface.DrawOutlinedRect( 0, 0, w, h )
	end

	self.PanelList = vgui.Create( "DPanelList", self.PanelBack )
	self.PanelList:SetPos( 5, 5 )
	self.PanelList:SetSize( 320, 359 )
	self.PanelList:EnableHorizontal()
	self.PanelList:SetSpacing( 10 )

	self.List = vgui.Create( "DListView", self.Panel )
	self.List:SetPos(2, 26)
	self.List:SetSize(200, 370 )
	self.List:AddColumn( "Plugin" )
	self.List:SetMultiSelect(false)

	local oClickLine = self.List.OnClickLine

	function self.List.OnClickLine( parent, line, isSelected )
		self.PanelList:Clear()

		Object = vgui.Create( "DButton" )
		Object:SetText( "Reload Plugin" )
		Object:SetSize( 100, 15 )
		Object.Handle = line.Handle

		self.PanelList:AddItem( Object )

		function Object.DoClick()
			PhrozenFire.Modules[line.Handle].Module:ReloadPlugin()
			self:PopulatePluginList()
		end

		for cVar, data in pairs(PhrozenFire.Modules[line.Handle].Module.cVars) do
			local Object

			if data[2] > 1 then
				Object = vgui.Create( "DNumSlider" )
			    Object:SetText( data[5] or data[1] )
			    Object:SetConVar( PhrozenFire.prefix .. cVar )
			    Object:SetMinMax( data[3], data[4])
			    Object:SizeToContents()
			else
				Object = vgui.Create( "DCheckBoxLabel" )
			    Object:SetText( data[5] or data[1] )
			    Object:SetConVar( PhrozenFire.prefix .. cVar )
			    Object:SizeToContents()
			end
		
			self.PanelList:AddItem( Object )
		end

		oClickLine( parent, line, isSelected )
	end

	self:PopulatePluginList()
end

function Menu:PopulatePluginList()
	self.PanelList:Clear()
	self.List:Clear()

	for index, Obj in pairs ( MODULE.base.Modules ) do
		local Plugin = Obj.Module

		if Plugin.cVars then
			local Line = self.List:AddLine( Plugin.Name )
			Line.Handle = index
		end
	end
end

--PhrozenFire:RegisterModule( MODULE )