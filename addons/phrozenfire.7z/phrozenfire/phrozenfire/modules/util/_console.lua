--[[
	MOD/lua/PhrozenFire/Modules/Util/_console.lua [#9368 (#9368), 3275416663, UID:881309702]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:40PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "PhrozenConsole" )

MODULE.id = "console"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1
MODULE.TextLineLength = 8

MODULE.cVars = {
	["menu_x"]				= { "menu_x"		, 20, 0, 1, "Menu X" },
	["menu_y"] 				= { "menu_y"		, 20, 0, 1, "Menu Y" }
}

function MODULE:Init()
	self.Width, self.Height, self.Title = 550, 200, "PhrozenFire :: Console"

	self.Console = vgui.Create( "DFrame" )
	local Console = self.Console

	Console:SetSize( self.Width, self.Height )
	Console:SetPos( self.base:GetValue("menu_x"), self.base:GetValue("menu_y") )
	Console:SetSizable(true)
	Console.base = self

	--For use with the console.
	Console.TextLines, Console.Size = {}, 0
	Console.y_offset, Console.CurrentLine, Console.SelectedLine = 0, 1, -1

	--Keep the old think, but we need to do our own thinking, sir!
	self.Console.oThink = self.Console.Think
	
	function self.Console:Think()
		--Set the title with our timestamp.
		self:SetTitle(self.base.Title .. " - " .. os.date("[%I:%M:%S %p]"))
		self:oThink()
	end

	--Create our scrollbar
	self.Console.Scrollbar = vgui.Create( "DVScrollBar", self.Console )
	local Scrollbar = self.Console.Scrollbar

	--Create our text field. This is where the magic happens.
	self.Console.ChatField = vgui.Create( "Panel", self.Console )
	local ChatField = self.Console.ChatField

	ChatField.Scrollbar = Scrollbar

	function ChatField:Paint( w, h )
		--Draw our black background.
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 220))

		--Draw our console text over that background. This is where the magic takes place.
		MODULE:DrawConsole(2, self.Scrollbar:GetOffset())

		--Draw our white border.
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, w , h )
	end
	
	--This is for copying our text.
	function ChatField:OnMousePressed( mc )
		if mc == MOUSE_RIGHT then
			local Parent = self:GetParent()

			--For when we don't have an item selected, this will be -1.
			if Parent.SelectedLine ~= -1 then
				local Line = Parent.TextLines[Parent.SelectedLine]

				local Option = DermaMenu()

				--Add option for copying the line.
				Option:AddOption("Copy", function() 
					SetClipboardText( Line.Stamp .. Line.Clean )
				end)

				Option:Open()
			end
		end
	end
	
	--To stop our scrollbar from invalidating our parent, create an empty function.
	function Console:OnVScroll( offset )
	end

	function Console:OnResize( width, height )
		self.Scrollbar:SetScroll( self.base:GetCanvasSize() )
	end

	--We want to keep the old layout function for our console to make sure the buttons don't get fucked up.
	self.Console.oPerformLayout = self.Console.PerformLayout

	function self.Console:PerformLayout( width, height )
		if self.base.Width ~= width or self.base.Height ~= height then
			self.base.Width, self.base.Height = width, height

			if self.OnResize then
				self:OnResize( width, height )
			end	
		end

		local width_offset = 0

		--If our scrollbar is enabled, modify the width.
		if self.Scrollbar.Enabled then 
			width_offset = 20
		end

		--Reposition our text field and scrollbar.
		self.ChatField:SetPos(5, 25)
		self.Scrollbar:SetPos((width - width_offset) , 25)
		self.ChatField:SetSize((width - width_offset) - 10, height - 30 )
		self.Scrollbar:SetTall(height - 30)

		local y_offset = 0

		--Get the size of the canvas to let the scrollbar know how big it needs to scale to.
	    self.Scrollbar:SetUp( self.ChatField:GetTall(), self.base:GetCanvasSize() )
	    self.Scrollbar:SetScroll( self.base:GetCanvasSize() )

	    --Call our original layout.
	    self:oPerformLayout()
	end
	
	self.Console:SetVisible(true)

	--Temporary - for testing purposes.
	concommand.Add( self.base.prefix .. "mouse", function()
		self.mouse = !self.mouse or false
		gui.EnableScreenClicker(self.mouse)
	end )

	--Toggles the console.
	concommand.Add( self.base.prefix .. "console", function()
		if Console:IsVisible() then
			local x, y = Console:GetPos()

			self.base:SetValue( self.base.prefix .. "menu_x", x, true)
			self.base:SetValue( self.base.prefix .. "menu_y", y, true)
		else
			self.Console:SetPos( self.base:GetValue("menu_x"), self.base:GetValue("menu_y") )
		end
		self.Console:SetVisible(!self.Console:IsVisible()) 
	end )

	concommand.Add( self.base.prefix .. "addtestline", function() 
		self:AddText( color_red, "Test!" )
	end )
end

--When we unload our module, get rid of the console object. Simple.
function MODULE:OnRemove()
	self.Console:Remove()
end

function MODULE:GetCanvasSize()
	local Lines = self.Console.TextLines
	--Return the full size of the chat lines.
	return (#Lines * self.util.th) + 4
end

function MODULE:GetMaxLines()
	--Divide the size of our text field by the height of our font.
	return self.Console.ChatField:GetTall() / self.util.th
end

function MODULE:GenerateMarkup( font, max, ... )
	local str, clean, args = "", "", {...}
	local color_open = false

	--Loop through our argument table.
	for i = 1, #args do
		local data = args[i]

		--If we're dealing with a string, ideally, we should be also applying closing color tags.
		if TypeID(data) == TYPE_STRING then
			str = str .. data
			clean = clean .. data
			
			--Close the previous color tag.
			if color_open then
				str = str .. "</color>"
				color_open = false
			end
		--If we're dealing with a table, hopefully it's a color.
		elseif TypeID(data) == TYPE_TABLE then
			--Set the color tag to open and apply our color tag.
			str = str .. "<color=" .. data.r .. " " .. data.g .. " " .. data.b .. ">"
			color_open = true
		end
	end

	str = "<font=" .. font .. ">" .. str .. "</font>"

	--Parse our object and return it. We're going to save this for later. Generating these objects is very expensive.
	return str, clean
end

function MODULE:AddText( ... )
	local ChatLine, Console = {}, self.Console

	--Get our timestamp for this moment.
	local TimeStamp = os.date("[%I:%M:%S %p] ")
	
	--Get the size of our timestamp. Instead of being a part of the markup, this is drawn separately.
	surface.SetFont( self.util.Font )
	local StampWidth = surface.GetTextSize( TimeStamp )

	--Get the maximum width of our ChatField/Canvas.
	local Max = Console.ChatField:GetWide()

	local y_offset, Scroll = Console.CurrentLine * self.util.th, Console.Scrollbar:GetScroll()

	local obj, dirty, clean = nil, self:GenerateMarkup( self.util.Font, nil, ... )

	obj = markup.Parse( dirty )

	function obj:DrawOutlined(xOffset, yOffset, halign, valign, alphaoverride)
		for i,blk in pairs(self.blocks) do
			local y = yOffset + (blk.height - blk.thisY) + blk.offset.y
			local x = xOffset

			if (halign == TEXT_ALIGN_CENTER) then		x = x - (self.totalWidth / 2) 
			elseif (halign == TEXT_ALIGN_RIGHT) then	x = x - (self.totalWidth)
			end

			x = x + blk.offset.x

			if (valign == TEXT_ALIGN_CENTER) then		y = y - (self.totalHeight / 2)
			elseif (valign == TEXT_ALIGN_BOTTOM) then	y = y - (self.totalHeight)
			end
			
			local alpha = blk.colour.a
			if (alphaoverride) then 
				alpha = alphaoverride 
			end

			local lineColor = Color(blk.colour.r, blk.colour.g, blk.colour.b, alpha)
			draw.SimpleTextOutlined( blk.text, blk.font, x, y, lineColor, 0, 0, 1, Color(0,0,0,alpha) )
		end
	end

	--Store our markup object, as well as the time stamp and its width.
	Console.TextLines[Console.CurrentLine] = { obj = obj, Clean = clean, Dirty = dirty, Stamp = TimeStamp, StampWidth = StampWidth, Timing = CurTime() + self.TextLineLength }
	Console.CurrentLine = Console.CurrentLine + 1

	Console.VisibleTimer = CurTime() + self.TextLineLength

	Console:InvalidateLayout(true)
end

function MODULE:MouseInLine( mouse_x, mouse_y, x, y, w, h )
	if mouse_x > x and mouse_x < w and mouse_y > y and mouse_y < y + h then
		return true
	end
end

function MODULE:DrawConsole(x, y)
	local Console = self.Console
	local TextLines, Scrollbar, ChatField = Console.TextLines, Console.Scrollbar, Console.ChatField
	
	--Height variable for convenience. y_offset is used to offset for wordwrapping.
	local Height, y_offset = self.util.th, 0
	local Minimum = (-self.util.th + Scrollbar:GetScroll() + y)

	--Loop through all of our textlines.
	for i=1, #TextLines do
		local Line = TextLines[i]

		--Get the y_pos before we increase our offset.
		local y_pos = y + y_offset

		if Console:IsVisible() == false and Line.Timing - CurTime() > 0 or Console:IsVisible() then
			--To prevent us from drawing more than we can see, check if the drawing position of the
			--console text is greater than the canvas height or less than the size of our current line.
			if y_pos > Minimum and y_pos < Minimum + self.Height then
				local mouse_x, mouse_y = ChatField:CursorPos()

				if self:MouseInLine( mouse_x, mouse_y, x, y_pos, ChatField:GetWide(), Line.obj:GetHeight() ) then
					draw.RoundedBox( 0, x, y_pos, ChatField:GetWide(), Line.obj:GetHeight(), Color( 190, 190, 190, 150 ) )
					Console.SelectedLine = i
				end

				local Alpha = 255

				if not Console:IsVisible() then
					Alpha = 255 * (Line.Timing - CurTime()) / 1
				end
				
				local StampColor = Color(255, 255, 255, Alpha)

				draw.SimpleText( Line.Stamp, self.util.Font, x, y_pos, StampColor, 0, 0 )
				Line.obj:Draw( x + Line.StampWidth, y_pos, 0, 0, Alpha )
			end
		end

		--Increase the offset for the next line to draw at to compensate for word wrapping.
		y_offset = y_offset + self.util.th
	end
end

PhrozenFire:RegisterBaseModule( MODULE )