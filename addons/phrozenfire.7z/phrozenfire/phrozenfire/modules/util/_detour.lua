--[[
	MOD/lua/PhrozenFire/Modules/Util/_detour.lua [#3713 (#3713), 2057797161, UID:3722407640]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:40PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "Detours" )

MODULE.Name = "Detours"
MODULE.id = "detours"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1
MODULE.patches = {}
MODULE.hook = {
	Protected = {},
	hooks = {}
}

MODULE.DebugMode = true

local detours = MODULE

function detours:DebugPrint( ... )
	if self.DebugMode == true then
		local Console = PhrozenFire:GetModuleByID("console")
		if Console then
			Console:AddText( Color(255, 200, 0), "[Detours] ", ...)
		end
	end
end

function detours:func( Library, index, new, meta )
	--If our library is passed as a string, we have to look it up.
	local str = Library

	if TypeID( Library ) == TYPE_STRING then
		if str == "_G" then
			Library = _G
		else
			if str == "GAMEMODE" or str == "GM" then
				Library = self.hook:GetNamespace()
			elseif meta == true then
				str = "_R." .. Library
				Library = debug.getregistry()[Library]
			else
				Library = _G[str]
			end
		end
	end

	--If this function is already detoured, restore it
	if Library["o" .. index] then
		if self.patches[Library[index]] then
			self.patches[Library[index]] = nil
		end
		
		Library[index] = Library["o" .. index]
		Library["o" .. index] = nil

		self:DebugPrint( color_white, "[", color_blue, str .. "." .. index, color_white, "]", color_purple, " Retoured!" )
	end

	local old = Library[index]

	--Store the original function pointer and replace it.
	Library["o" .. index] = Library[index]

	local NewFunction = function(...)
		return new(old, ...)
	end

	Library[index] = NewFunction

	self:DebugPrint( color_white, "[", color_blue, str .. "." .. index, color_white, "]", color_green, " Detoured!" )

	self.patches[NewFunction] = old
end

function detours.hook:GetNamespace()
	local Namespace = GAMEMODE
    if not Namespace then
        Namespace = GM

        if not Namespace then
        	return nil
		end
    end

    return Namespace
end

function detours.hook:Add( hook, name, new )
   	local Namespace = self:GetNamespace()	

   	if not Namespace then
   		hook.Add( hook, name, func )
   		return
   	end

    self.hooks = self.hooks or {}

    if not self.hooks[hook] then
   		self.hooks[hook] = {}
  		
   		detours:DebugPrint( color_white, "Creating hook for [", color_blue, "GAMEMODE." .. hook, color_white, "]." )

	    detours:func( "GAMEMODE", hook, function(old, s, ...)
	    	local ret_old = nil

	        if old then
	        	ret_old = old(s, ...)
	        end

	        if PhrozenFire.NoDraw == true and self.Protected[hook] then
	        	return ret_old
	        end
        	
	        for i = 1, #self.hooks[hook] do
	        	local obj = self.hooks[hook][i]

	        	local status, ret = pcall( obj.new, ... )
	        	
	        	if status == true and ret then
	        		return ret
	        	elseif status == false then
	        		detours:DebugPrint( color_red, ret )
	        	end
	        end
		    
	        return ret_old
	    end )
 	end

 	detours:DebugPrint( color_teal, "Adding hook for GAMEMODE." .. hook .. " (", color_white, "Name: " .. name, color_teal, ")")

    self.hooks[hook][#self.hooks[hook] + 1] = { name = name, new = new }
end

function detours.hook:FlagProtected( hook )
	if not self.Protected[hook] then
		self.Protected[hook] = true
	end
end

function detours.hook:FindHookIndex( hook, name )
	for i = 1, #self.hooks[hook] do
		local obj = self.hooks[hook][i]

		if obj.name == name then
			return i
		end
	end

	return nil
end

function detours.hook:Remove( hook, name )
	local Namespace = self:GetNamespace()

	if not Namespace then
		hook.Remove( hook, name )
		return
	end

	local index = self:FindHookIndex(hook, name)

	if index then
		table.remove(self.hooks[hook], index)
	end
end

PhrozenFire:RegisterBaseModule( MODULE )