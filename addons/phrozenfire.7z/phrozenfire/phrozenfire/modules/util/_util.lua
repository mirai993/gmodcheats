--[[
	MOD/lua/PhrozenFire/Modules/Util/_@util.lua [#7067 (#7067), 2757786186, UID:3239520608]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:39PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "_Util" )

MODULE.Name = "PhrozenFire Utilies"
MODULE.id = "util"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

MODULE.util.Font = "DefaultSmall"

color_green = Color(0, 255, 0)
color_red = Color(255, 0, 0)
color_blue = Color(0, 125, 255)
color_teal = Color(0, 255, 255)
color_purple = Color(200, 0, 255)
color_orange = Color(200, 255, 0)

MODULE.util.FriendNPCS = {
	"npc_alyx",
	"npc_vortigaunt",
	"npc_turret_floor",
	"npc_citizen",
	"npc_monk",
	"npc_pigeon",
	"npc_seagull",
	"npc_rollermine",
	"npc_dog",
	"npc_breen",
	"npc_gman",
	"npc_magnusson",
	"npc_kleiner",
	"npc_barney",
	"npc_mossman",
	"npc_grenade_bugbait"
}

MODULE.util.npcs = {
	"npc_*",
	"monster_*",
	"zw_zombie_*"
}

MODULE.util.ModelCorrections = {
	["models/combine_scanner.mdl"] = "Scanner.Body",
	["models/hunter.mdl"] = "MiniStrider.body_joint",
	["models/combine_turrets/floor_turret.mdl"] = "Barrel",
	["models/dog.mdl"] = "Dog_Model.Eye",
	["models/antlion.mdl"] = "Antlion.Body_Bone",
	["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
	["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
	["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
	["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body",
	["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
	["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
	["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
	["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
};

local meta = FindMetaTable( "Player" )

MODULE.util._GetWeapons = meta.GetWeapons
MODULE.util._GetActiveWeapon = meta.GetActiveWeapon

function MODULE.util:FriendlyNPC( ent )
	if IsValid( ent ) then 
		if ent:IsNPC() && table.HasValue( self.FriendNPCS, ent:GetClass() ) then
			return true
		end
	end
	
	return false
end

function MODULE.util:GetHeadPosition( ent )
    local model = ent:GetModel() or ""

	local bone = self.ModelCorrections[ model ]

	if bone then
		return ent:GetBonePosition( ent:LookupBone( bone ) )
	end
	
    if model:find("crow") or model:find("seagull") or model:find("pigeon") then
        return ent:LocalToWorld(ent:OBBCenter() + Vector(0,0,-5))
    elseif ent:GetAttachment(ent:LookupAttachment("eyes")) ~= nil then
        return ent:GetAttachment(ent:LookupAttachment("eyes")).Pos
    else
        return ent:LocalToWorld(ent:OBBCenter())
    end
end

function MODULE.util:GetWeapons( ent )
	if ( ent:IsPlayer() ) then
		return self._GetWeapons( ent )
	end
end

function MODULE.util:GetActiveWeapon( ent )
	if ( ent:IsPlayer() ) then
		return self._GetActiveWeapon( ent )
	end
end

function MODULE.util:MarkDangerousWeapon( ent )
	if ent && IsValid( ent ) then
		if ent:IsWeapon() then
			if ent && ent.Primary && ( ent.Primary.damage || ent.Primary.Damage ) then
				return true		
			end
		end
	end

	return false
end

function MODULE.util:IsVisible( ent )
	if ent:IsValid() then
		local trace = {
			start = LocalPlayer():GetShootPos(), 
			endpos = self:GetHeadPosition( ent ), 
			filter = { LocalPlayer(), ent },
			mask = CONTENTS_SOLID + CONTENTS_MOVEABLE + CONTENTS_OPAQUE + CONTENTS_DEBRIS + CONTENTS_HITBOX + CONTENTS_MONSTER
		}
					
		local tr = util.TraceLine(trace)
		
		if tr.Fraction == 1 then
			return true
		end
	end
	
	return false
end

function MODULE.util:GetAlive( ent )
	local movetype = ent:GetMoveType()	
				
	if ( movetype == MOVETYPE_NONE ) then return false end
	
	if ( ent:IsPlayer() ) then
		if not ( ent:Alive() ) then return false end
	end
	
	return true
end

function MODULE.util:IsNPC( EntityObj )
	return EntityObj:IsNPC() or EntityObj:GetClass():find("npc_")
end

function MODULE.util:GetCoordiantes( ent )
	local min, max = ent:WorldSpaceAABB()
	
	local corners = {
		Vector(min.x,min.y,min.z),
		Vector(min.x,min.y,max.z),
		Vector(min.x,max.y,min.z),
		Vector(min.x,max.y,max.z),
		Vector(max.x,min.y,min.z),
		Vector(max.x,min.y,max.z),
		Vector(max.x,max.y,min.z),
		Vector(max.x,max.y,max.z)
	}

	local minx, miny, maxx, maxy = ScrW() * 2, ScrH() * 2, 0, 0
	
	for i = 1, #corners do
		local screen = corners[i]:ToScreen()
		
		minx, miny = math.min( minx, screen.x ), math.min( miny, screen.y )
		maxx, maxy = math.max( maxx, screen.x ), math.max( maxy, screen.y )	
	end
	
	return minx, miny, maxx, maxy
end

function MODULE.util:GetNPCTable( )
	local output = {}
	
	if ( MODULE.base:GetBool("NpcsEnabled") ) then
		for a = 1, #self.npcs do
			local npcs = ents.FindByClass( self.npcs[a] )
			
			for i = 1, #npcs do
				local ent = npcs[i]

				output[ #output + 1 ] = ent
			end
		end
	end

	return output
end

function MODULE.util:GetEntityTable( )
	local output = self:GetNPCTable( )
	local ptable = player.GetAll()

	for i = 1, #ptable do
		local ply = ptable[i]

		output[ #output + 1 ] = ply
	end

	return output
end

function MODULE.util:GetReloadTime( )
	if ( IsValid( LocalPlayer():GetViewModel() ) ) then
		return LocalPlayer():GetViewModel():SequenceDuration()
	end

	return 0
end

function MODULE.util:IsAdmin( ply )
	if not ply:IsPlayer() then return false end
	
	if ( ply:IsAdmin() ||
		 ply:IsSuperAdmin() ||
		 ply:IsUserGroup( "Admin" ) || 
		 ply:IsUserGroup( "admin" ) ) then 
		return true
	end
	
	return false
end

function MODULE.util:FillRGBA( x, y, w, h, col )
    surface.SetDrawColor( col.r, col.g, col.b, col.a )
    surface.DrawRect( x, y, w, h )
end

function MODULE.util:OutlineRGBA( x, y, w, h, col )
    surface.SetDrawColor( col.r, col.g, col.b, col.a )
    surface.DrawOutlinedRect( x, y, w, h )
end

function MODULE.util:DrawText( text, x, y, color, xalign, yalign )
	xalign = xalign or TEXT_ALIGN_CENTER
	yalign = yalign or TEXT_ALIGN_BOTTOM
	
	if MODULE.base:GetBool( "SimpleText" ) then
		return draw.SimpleText( text, self.Font, x, y, color, xalign, yalign )
	else
		return draw.SimpleTextOutlined( text, self.Font, x, y, color, xalign, yalign, 1, Color( 0, 0, 0, 255 ) )
	end
end

function MODULE.util:ScreenVisible( screen )
	if (screen.x > 0 && screen.x < ScrW() &&
		screen.y > 0 && screen.y < ScrH()) then
		return true
	end
	
	return false
end

function MODULE.util:NormaliseAngle( ang )
	if ang < 180 then
		return ang
	end
	
	return ( ang % 180 ) - 180
end

function MODULE.util:DoTrace()
	local pos = LocalPlayer():GetShootPos()
	local ang = LocalPlayer():GetAimVector()
	
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos + (ang * 10000000)
	tracedata.filter = LocalPlayer()
	
	local trace = util.TraceLine( tracedata )

	if trace.HitNonWorld then
	   return trace.Entity
	end
	
	return nil
end

function MODULE.util:SetFont( str )
	self.Font = str or "DermaDefault"

	surface.SetFont( self.Font )
	self.tw, self.th = surface.GetTextSize( "W" )
end

function MODULE:Init()
	self.util:SetFont("PhrozenText2")
end

PhrozenFire:RegisterBaseModule( MODULE )