--[[
	MOD/lua/PhrozenFire/Modules/_aimbot.lua [#12607 (#12607), 2217045392, UID:4275191618]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:37PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "PhrozenAimbot" )

MODULE.id = "aimbot"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

local isBhopping = false
local FloorVelocity, FloorVelocity_Cooldown, FloorVelocity_Color = 0, CurTime(), color_white

local p = LocalPlayer()

MODULE.cVars = {
	["aimbot_enabled"]			= { "aimbotenabled"		, 1, 0, 1, "Enabled" },
	["aimbot_viewcorrection"]	= { "viewcorrection"	, 1, 0, 1, "View Correction" },
	["aimbot_norecoil"] 		= { "norecoil"			, 1, 0, 1, "No Recoil" },
	["aimbot_nospread"] 		= { "nospread"			, 1, 0, 1, "No Spread" },
	["aimbot_players"]			= { "playersincluded"	, 1, 0, 1, "Check Players" },
	["aimbot_teamcheck"] 		= { "teamcheck"			, 1, 0, 1, "Check Teams" },
	["aimbot_autoshoot"]		= { "autoshoot"			, 1, 0, 1, "Auto Shoot" },
	["aimbot_autoreload"]		= { "autoreload"		, 0, 0, 1, "Auto Reload" },
	["aimbot_alwayspread"]		= { "alwaysspread"		, 1, 0, 1, "Always No Spread" },
	["aimbot_dangerousonly"]	= { "dangerousonly"		, 0, 0, 1, "Target Dangerous Only" },
	["aimbot_fov"] 				= { "aimbotfov"			, 20,0, 360, "Field of View" },
	["aimbot_compensation"]		= { "compensation"		, 50, 1, 100, "Aim Compensation" }
}

MODULE.notAuto = { "weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow" }

function MODULE:Init()
	self.Enabled = false
	self.ShootEnabled = false

	self.Target = nil
	self.Shooting = false

	self.LastReloadGCD = 0
	self.LastReload = 0
	
	self.AttackDown = false
	self.NextShot = 0
	
	self.angDiff = Angle( 0, 0, 0 )
	self.angFire = Angle( 0, 0, 0 )
	
	self.CorrectView = Angle()
	self.CurrentView = Angle()
	
	concommand.Add( "+scan", function() 
		self.Enabled = true
	end )
	concommand.Add( "-scan", function() 
		self.Enabled = false
	end )

	concommand.Add("+bjump",function()
		isBhopping = true
	end)

	concommand.Add("-bjump",function()
		isBhopping = false
		RunConsoleCommand("-jump")
	end)

	surface.CreateFont( "Bunnyhop_hud", {
		font = "Tahoma",
		size = 60,
		bold =false,
		weight = 500
	} )
end

--Checks if the given weapon is semi automatic.
function MODULE:IsSemiAuto( Weapon )
	if not IsValid( Weapon ) then 
		return false
	end
	
	return (Weapon.Primary and not Weapon.Primary.Automatic) or table.HasValue( self.notAuto, LocalPlayer():GetActiveWeapon():GetClass() )
end

function MODULE:Shoot()
	RunConsoleCommand( "+attack" )

	timer.Simple(0.0001,function()
		RunConsoleCommand( "-attack" )
	end)
end

function MODULE:IsFOV ( ent )
	local fov = self.base:GetValue( "AimbotFov" )
	
	if ( fov ~= 180 ) then
		local PlayerAngle = LocalPlayer():GetAngles()
		
		local ang = ( ent:GetPos() - LocalPlayer():GetPos() ):Angle()
		
		local ady = math.abs( math.NormalizeAngle( PlayerAngle.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( PlayerAngle.p - ang.p ) )
		
		if( ady > fov or adp > fov ) then 
			return false
		end
	end
	return true
end

function MODULE:PredictSpread( cmd, aimAngle )
	return aimAngle
	/*
	local Seed = self.base.GetSeed( cmd ) or 0
	
	Weapon = LocalPlayer():GetActiveWeapon()
	vecCone = Vector( 0, 0, 0 )

	if ( Weapon && IsValid( Weapon ) && type( Weapon.Initialize ) == "function" ) then
		local valCone = Weapon.Primary.Cone
		
		if self.weaponCones[ Weapon.Base ] then
			valCone = self.weaponCones[ Weapon.Base ]( Weapon )
		end
		
		if type( valCone ) == "number" then
			vecCone = Vector( -valCone, -valCone, -valCone )
		elseif type( valCone ) == "Vector" then
			vecCone = -1 * valCone
		end
	elseif ( Weapon and Weapon:IsValid() ) then
		local class = Weapon:GetClass()
		
		local HL2_SPREAD = {
			weapon_357 = Vector( 0, 0, 0 ),
			weapon_smg1 = Vector(0.04362, 0.04362, 0.04362),
			weapon_ar2 = Vector(0.02618, 0.02618, 0.02618),
			weapon_pistol = Vector(0.00873, 0.00873, 0.00873),
			weapon_shotgun = Vector(0.08716, 0.08716, 0.08716),
		}
	
		if HL2_SPREAD[ class ] then vecCone = -1 * HL2_SPREAD[ class ] end
	end
	return self.base.ShotManipulate( Seed or 0, ( aimAngle or LocalPlayer():GetAimVector():Angle() ):Forward(), self.FireCone or vecCone or Vector( 0, 0, 0 ) ):Angle()
	*/
end

function MODULE:Prediction( tar, compensate )
	local ply = LocalPlayer()

	local tarFrames, plyFrames = ( RealFrameTime() / 25 ), ( RealFrameTime() / 66 )
	return compensate + ( ( tar:GetVelocity() * ( tarFrames ) ) - ( ply:GetVelocity() * ( plyFrames ) ) )
end

function MODULE:GetAimAngle ( ent, cmd )
	local ang = self.util:GetHeadPosition( ent )
	
	ang = self:Prediction( ent, ang )
	ang = (ang - LocalPlayer():GetShootPos()):Angle()
	
	ang.p = self.util:NormaliseAngle(ang.p)
	ang.y = self.util:NormaliseAngle(ang.y)
	ang.r = 0
	
	return ang
end

function MODULE:CheckTeam( ent )
	if not self.base:GetBool( "TeamCheck" ) then
		return true
	end
	
	if ent:IsPlayer() then
		local Cops, Team1, Team2 = GAMEMODE.CivilProtection, ent:Team(), LocalPlayer():Team()

		if Team1 == Team2 or (Cops and Cops[Team1] and Cops[Team2]) then
			return false
		end
	end

	return true
end

function MODULE:Spinbot( c )
	local new_angles = Angle( 0, 0, 0 )
	local view_angles = c:GetViewAngles()
	
	new_angles.p = -view_angles.p
	new_angles.y = math.fmod( CurTime() / 0.001 * 360, 360 )
	new_angles.r = math.random( -360, 360 )
	
	local Forward, Right, Up = c:GetForwardMove(), c:GetSideMove(), c:GetUpMove()
	
	c:SetViewAngles( new_angles )
	
	local vForward, vRight, vUp = view_angles:Forward(), view_angles:Right(), view_angles:Up()
	
	vForward:Normalize()
	vRight:Normalize()
	vUp:Normalize()
	
	local fw = vForward * Vector( Forward, Forward, Forward )
	local ri = vRight * Vector( Right, Right, Right )
	local uu = vUp * Vector( Up, Up, Up )
	
	c:SetForwardMove( fw:DotProduct( vForward ) +  ri:DotProduct( vForward ) + uu:DotProduct( vForward ) )
	c:SetSideMove( fw:DotProduct( vRight ) +  ri:DotProduct( vRight ) + uu:DotProduct( vRight ) )
	c:SetUpMove( fw:DotProduct( vUp ) +  ri:DotProduct( vUp ) + uu:DotProduct( vUp ) )
end

function MODULE:ViewCorrection( c )
	local mouse = Angle(c:GetMouseY() * 0.022, c:GetMouseX() * -0.022, 0) or Angle(0,0,0)

	self.CurrentView   = self.CurrentView + mouse
	self.CurrentView.p = math.Clamp( math.NormalizeAngle( self.CurrentView.p ), -90, 90 )
	self.CurrentView.y = math.NormalizeAngle( self.CurrentView.y )
	
	self.angFire = self.CurrentView - self.angDiff
	
	local angSpread = self.angFire
	
	if self.base:GetBool( "AlwaysSpread" ) then
		if ( bit.band( c:GetButtons(), IN_ATTACK ) > 0 ) then
			angSpread = self:PredictSpread( c, self.angFire )
		end
		
		self.angDiff = Angle( math.AngleDifference( angSpread.p, self.angFire.p ), math.AngleDifference( angSpread.y, self.angFire.y ), 0 )
	else
		self.angDiff = Angle( 0, 0, 0 )
	end
	
	angSpread.p = self.util:NormaliseAngle( angSpread.p )
	angSpread.y = self.util:NormaliseAngle( angSpread.y )
	angSpread.r = 0
	
	self.CorrectView = self.CurrentView - self.angDiff
	
	local Weapon = LocalPlayer():GetActiveWeapon()
	
	if ( IsValid( Weapon ) && self.base:GetBool( "NoRecoil" ) && !string.find( Weapon:GetClass(), "physgun" ) ) then 
		c:SetViewAngles( angSpread - LocalPlayer():GetPunchAngle() )
	end
end

function MODULE:NoRecoil( o, angles, fov )
	local Weapon = LocalPlayer():GetActiveWeapon()
	local ModifiedView = { origin = o, angles = angles, fov = fov }
	
	if LocalPlayer():Alive() && IsValid( Weapon ) then
		if ( Weapon.Primary ) then Weapon.Primary.Recoil = 0.0 end
		if ( Weapon.Secondary ) then Weapon.Secondary.Recoil = 0.0 end
		
		if self.base:GetBool( "ViewCorrection" ) and ( self:Holstered() == false && !string.find( Weapon:GetClass(), "physgun" ) ) then
			ModifiedView.angles = self.CurrentView
		end
	end
	
	return ModifiedView
end

function MODULE:GetValid( EntityObj )
	--We can't aim at ourself or dead people.
	if not IsValid( EntityObj ) or EntityObj == LocalPlayer() or not self.util:GetAlive( EntityObj ) then
		return false
	end

	--If we're neither a player or an npc
	if not EntityObj:IsPlayer() and not self.util:IsNPC(EntityObj) then 
		return false 
	end

	--If we're an npc, we can't be a friendly one.
	if self.util:IsNPC( EntityObj ) and self.util:FriendlyNPC( EntityObj ) then 
		return false 
	end

	--If we're a player, we need to be allowed to aim at them.
	if EntityObj:IsPlayer() and not self.base:GetBool( "PlayersIncluded" ) then 
		return false
	end

	--If they fail either the team check, the FOV check, or the visibility check in that order..
	if not self:CheckTeam( EntityObj ) or not self:IsFOV( EntityObj ) or not self.util:IsVisible( EntityObj ) then 
		return false
	end

	--If we're only supposed to aim at hostile targets, check their weapon.
	if self.base:GetBool( "DangerousOnly") and EntityObj:IsPlayer() then
		local Weapon = self.util:GetActiveWeapon( EntityObj )

		if not self.util:MarkDangerousWeapon( Weapon ) then
			return false
		end
	end

	return true
end

function MODULE:Holstered()
	if type( ClientVars ) == "table" then
		return ClientVars["Holstered"] 
	end
	return false
end

function MODULE:GetTarget( )
    local closest = { self.Target or nil , 0 }
	
	for _, EntObj in pairs (ents.GetAll()) do
		if self:GetValid(EntObj) then
			local diff = EntObj:GetPos() - LocalPlayer():GetPos()
			diff:Normalize()
			
			diff = diff - LocalPlayer():GetAimVector()
			diff = diff:Length()
			diff = math.abs( diff )
			
			if ( diff < closest[2] ) or ( closest[1] == nil ) then
				closest = { EntObj, diff }
			end	
		end
	end
	self.Target = closest[1]
end

function MODULE:Aimbot( cmd )
	if self.Enabled  then
		self:GetTarget()

		if self:GetValid(self.Target) then
			local ang = self:GetAimAngle(self.Target, cmd)
			
			self.CorrectView = ang
			self.CurrentView = ang
			
			cmd:SetViewAngles(ang)
			self.ShootEnabled = true
		else
			if self.Target then
				self.Target = nil
				self.ShootEnabled = false
			end
		end
	else
		if self.Target then
			self.Target = nil
			self.ShootEnabled = false
		end
	end
end

function MODULE:AutoReload( cmd )
	local Weapon = LocalPlayer():GetActiveWeapon()

	if LocalPlayer():Alive() and IsValid( Weapon ) and Weapon:Clip1() <= 0 then
		if self.LastReload < CurTime() then

			RunConsoleCommand("+reload")

			self.LastReload = CurTime() + self.util:GetReloadTime() 
		
			timer.Simple( .2, function()
				RunConsoleCommand("-reload")
			end)
		end
	end
end

function MODULE:Autoshoot( )
	if not self.Shooting && self.ShootEnabled then
		self:Shoot()
		self.Shooting = true
	elseif self.Shooting then
		self.Shooting = false
	end
end

function MODULE:BunnyHop( c )
	if isBhopping then
		if p:IsOnGround() or p:WaterLevel() > 0 then
			c:SetButtons( bit.bor(c:GetButtons(), IN_JUMP) )
		end
			
		if p:IsOnGround() and FloorVelocity_Cooldown - CurTime() < 0 then
			local PreviousVelocity = FloorVelocity
			FloorVelocity = math.floor(LocalPlayer():GetVelocity():Length())
			FloorVelocity_Color = (FloorVelocity > PreviousVelocity and Color( 0, 255, 0 ) ) or ( FloorVelocity < PreviousVelocity and Color( 255, 0, 0 ) ) or color_white 
			FloorVelocity_Cooldown = CurTime() + 0.5
		end

		local Horizontal_Delta = c:GetMouseX()
		local Forward_Delta = p:GetVelocity():Dot( p:GetForward() )
		
		local left_force = (Forward_Delta > 0 and 10000) or (Forward_Delta < 0 and -10000) or 0
		local right_force = (Forward_Delta > 0 and -10000) or (Forward_Delta < 0 and 10000) or 0
		
		if Horizontal_Delta != 0 then
			c:SetSideMove( ( Horizontal_Delta > 0 and left_force ) or ( Horizontal_Delta < 0 and right_force ) )
		end
	end
end 

function MODULE:CreateMove( cmd )
	local self = MODULE
	
	self:BunnyHop(cmd)

	if self.base:GetBool("Enabled") then
		if self.base:GetBool( "AimbotEnabled" ) then self:Aimbot( cmd ) end
		if self.base:GetBool( "AutoShoot" ) then self:Autoshoot( ) end
		if self.base:GetBool( "NoRecoil" ) then self:ViewCorrection( cmd ) end
		if self.base:GetBool( "AutoReload" ) then self:AutoReload( cmd ) end
	end
end

function MODULE:HUDPaint( )
	local self = MODULE
	
	if isBhopping then
		draw.SimpleText( math.floor(p:GetVelocity():Length()), "Bunnyhop_hud", ScrW() / 2, ScrH() - 150, color_white, TEXT_ALIGN_CENTER )
		draw.SimpleText( math.floor(FloorVelocity), "Bunnyhop_hud", ScrW() / 2, ScrH() - 150 + 60, FloorVelocity_Color, TEXT_ALIGN_CENTER )
	end

	if self.Enabled && self.Target then
		--
	end
end

function MODULE:CalcView( ply, pos, angles, fov )
	local self = MODULE
		
	if ( self.base:GetBool( "NoRecoil" ) ) then
		return self:NoRecoil( pos, angles, fov )
	end
end

MODULE.Hooks = {
	["CalcView"] = { function(a, b, c, d) return MODULE:CalcView(a, b, c, d) end },
	["CreateMove"] = { function( cmd ) return MODULE:CreateMove(cmd) end },
	["HUDPaint"] = { function() MODULE:HUDPaint() end }
}

PhrozenFire:RegisterModule( MODULE )