--[[
	MOD/lua/PhrozenFire/_admin.lua [#5704 (#5704), 2229013171, UID:3087985537]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:36PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "PhrozenImpAdminConsole" )

MODULE.Author = "Firehawk"
MODULE.Version = 0.1
MODULE.Special = true //This is fucking stupid.

function MODULE:Init()

	self.TextLines = {}
	self.CurrentLine = 0
	self.width = 470
	self.YOffset = 0

	self.Console = vgui.Create( "DFrame" )
	self.Console:SetSize( self.width + 30, 211 )
	self.Console:SetDeleteOnClose( false )

	self.Console:SetTitle("PhrozenFire :: Impacted Admin")

	self.Console:SetPos( 10, 100 )
	
	function self.Console:Paint()

		local w, h = self:GetWide(), self:GetTall()
		
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 100 ) )
	
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, w , h )
		
	end

	self.Console.verBar = vgui.Create( "DVScrollBar", self.Console )
	self.Console.verBar:SetPos( self.width + 5, 25 )
	self.Console.verBar:SetSize( 16, 180)

	self.Console.ChatField = vgui.Create( "Panel", self.Console )
	self.Console.ChatField:SetSize( self.width, 180 )
	self.Console.ChatField:SetPos( 5, 25 )

	function self.Console.ChatField:Paint()

		MODULE.YOffset = MODULE.Console.verBar:GetOffset()

		local w, h = self:GetWide(), self:GetTall()
		
		draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 150 ) )
	
		MODULE:DrawConsole( 2, 1 + MODULE.YOffset )

		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, w , h )

	end

	self:VBarLayout()

	self.Console:SetVisible( true )

end

concommand.Add( MODULE.base.prefix .. "adminconsole_toggle", function()

	MODULE.Console:SetVisible( !MODULE.Console:IsVisible() )

end)


concommand.Add( MODULE.base.prefix .. "adminconsole_test", function()

	for i = 1, 20 do

		MODULE:ConsoleAddText( Color( 0, 255, 0 ), "Testing testing we are testing." )

	end

end)

function MODULE:VBarLayout()

    local YPos = 0
   	
    // Make sure the scrollbar knows how big our canvas is
    self.Console.verBar:SetUp( 175, self:GetCanvasSize() )

	local wide = 0

	if not ( self.Console.verBar.Enabled ) then wide = 20 end

	self.Console.ChatField:SetSize( self.width + wide, 180 )

	self.Console.verBar:SetScroll( self:GetCanvasSize() )
   
end


function MODULE:GetCanvasSize( )

	return ( #self.TextLines + 1 ) * self.util.th

end

function MODULE:ConsoleAddText( ... )

	local chatline = {}
	local chatdata = {}

	if not ( self.TextLines ) then self.TextLines = {} end
	if not ( self.CurrentLine ) then self.CurrentLine = 0 end

	for _, v in pairs( arg ) do

		if ( type( v ) == "string" ) then
			
			chatdata[2] = v
			chatline[ #chatline + 1 ] = table.Copy( chatdata )

		end

		if ( type ( v )  == "table" ) then

			chatdata[1] = v
			
		end

	end

	self.TextLines[self.CurrentLine] = chatline

	self.CurrentLine = self.CurrentLine + 1

	self:VBarLayout()
	
end

function MODULE:DrawConsole( x, y )

	for k, v in pairs ( self.TextLines ) do

		local w = 0

		for _, chatline in pairs ( v ) do

			local ypos = y + ( ( k * self.util.th ) )

			if ypos > -self.util.th && ypos < 180 then

				self.util:DrawText( chatline[2], x + w , ypos , chatline[1], TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )

				surface.SetFont( self.util.font )
				local tw = surface.GetTextSize( chatline[2] )

			 	w = w + tw

			end

		end
	
	end

end

MODULE.FlaggedimpAdmin = {
	["ghosted"] = 1
}


MODULE.Hooked = {
["logAdmen"] = {false, function( msg ) MODULE:ProcessAdminText( msg ) end},

["impbroadcast"] = {false, function( msg ) 

	local str = msg:ReadString()

	chat.AddText( Color(234, 102, 0, 255), "[impAdmin]: ", Color(234, 102, 0, 255), str )
	MODULE:WriteLog( str )
	MODULE:ConsoleAddText( Color(234, 102, 0, 255), "[impAdmin]: ", Color(234, 102, 0, 255), str  )

end},

["impAChat"] = {false, function( msg ) 

	local str = msg:ReadString()
	
	chat.AddText( Color( 234, 102, 0, 255 ), "[impAdmin]: ", str )

	for k, v in pairs ( MODULE.FlaggedimpAdmin ) do

		if string.find( str, k ) then return end

	end

	MODULE:WriteLog( str )
	MODULE:ConsoleAddText( Color( 234, 102, 0, 255 ), "[impAdmin]: ", str) 

end}

}

MODULE.Colors = {
	["pmed"] = Color( 200, 255, 200 ),
	["disconnected"] = Color( 255, 150, 150 ),
	["changed to"] = Color( 255, 200, 255 ),
	["arrested"] = Color( 255, 165, 0 ),
	["joined the game"] = Color( 180, 255, 180 ),
	["has given"] = Color( 140, 255, 140 ),
	["has dropped"] = Color( 140, 255, 140 ),
	["pickpocketed"] = Color( 255, 165, 80 ),
	["damaged"] = Color( 150, 150, 255 )
}

function MODULE:ProcessAdminText( msg )

	local str = msg:ReadString()

	print( str )

	if ( string.sub( str, 1, 7 ) == "[DEATH]" ) then

		self:WriteLog( str )
		self:ConsoleAddText( Color( 255, 200, 200 ), str )
	
	else
		
		for k, v in pairs ( self.Colors ) do

			if string.find( str, k ) then
			
				self:WriteLog( str )
				self:ConsoleAddText( v, str )
				return

			end

		end
		
		self:WriteLog( str )
		self:ConsoleAddText( Color( 255, 255, 255 ), str )

	end

end


MODULE.IncomingMessage = usermessage.IncomingMessage
 
function usermessage.IncomingMessage( name , um , ... )

	local HookData = MODULE.Hooked[name]

	if HookData && not HookData[1] then

		usermessage.Hook( name, HookData[2] )
		HookData[1] = true

	end

    return MODULE.IncomingMessage( name , um , ... )

end

usermessage.Hook("impAChat", function(um)
	chat.AddText(Color(234, 102, 0, 255), "[impAdmin]: ", um:ReadString())
end)

usermessage.Hook("impbroadcast", function(um)
	
end)

function MODULE:GetLogFilename( )

	local filename = "Impacted/logs/";

	filename = filename .. "/" .. os.date( "%Y-%m-%d" )

	return string.gsub( filename, "[.]", "_" ) .. ".txt"

end

function MODULE:WriteLog( text )
	
	filex.Append( self:GetLogFilename(), os.date("[%I:%M:%S %p] ") .. text .. "\n" )

end

PhrozenFire:RegisterModule( MODULE )