--[[
	MOD/lua/PhrozenFire/_console_back_stable.lua [#8049 (#8049), 1568936841, UID:2345277879]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:37PM]
	===BadFile===
]]

local MODULE = PhrozenFire:NewModule( "PhrozenConsole" )

MODULE.id = "console"
MODULE.Author = "Firehawk"
MODULE.Version = 0.1

function MODULE:Init()
	self.Width, self.Height, self.Title = 600, 500, "PhrozenFire :: Console"

	self.Console = vgui.Create( "DFrame" )
	local Console = self.Console

	Console:SetSize( self.Width, self.Height )
	Console:SetPos( 0, ScrH() / 2 - Console:GetTall() - 30 )
	Console:SetSizable(true)
	Console.base = self

	--For use with the console.
	Console.TextLines, Console.Size = {}, 0
	Console.y_offset, Console.CurrentLine, Console.SelectedLine = 0, 1, -1

	--Keep the old think, but we need to do our own thinking, sir!
	self.Console.oThink = self.Console.Think
	
	function self.Console:Think()
		--Set the title with our timestamp.
		self:SetTitle(self.base.Title .. os.date("[%I:%M:%S %p]"))
		self:oThink()
	end

	--Create our scrollbar
	self.Console.Scrollbar = vgui.Create( "DVScrollBar", self.Console )
	local Scrollbar = self.Console.Scrollbar

	--Create our text field. This is where the magic happens.
	self.Console.ChatField = vgui.Create( "Panel", self.Console )
	local ChatField = self.Console.ChatField

	ChatField.Scrollbar = Scrollbar

	function ChatField:Paint( w, h )
		--Draw our black background.
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 220))

		--Draw our console text over that background. This is where the magic takes place.
		MODULE:DrawConsole(2, 1 +  self.Scrollbar:GetOffset())

		--Draw our white border.
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawOutlinedRect( 0, 0, w , h )
	end
	
	--This is for copying our text.
	function ChatField:OnMousePressed( mc )
		if mc == MOUSE_RIGHT then
			local Parent = self:GetParent()

			--For when we don't have an item selected, this will be -1.
			if Parent.SelectedLine ~= -1 then
				local Line = Parent.TextLines[Parent.SelectedLine]

				local Option = DermaMenu()

				--Add option for copying the line.
				Option:AddOption("Copy", function() 
					SetClipboardText( Line.Stamp .. Line.Clean )
				end)

				Option:Open()
			end
		end
	end
	
	--To stop our scrollbar from invalidating our parent, create an empty function.
	function Console:OnVScroll( offset )
	end

	--We want to keep the old layout function for our console to make sure the buttons don't get fucked up.
	self.Console.oPerformLayout = self.Console.PerformLayout

	function self.Console:PerformLayout( width, height )
		self.base.Width, self.base.Height = width, height

		local width_offset = 0

		--If our scrollbar is enabled, modify the width.
		if not self.Scrollbar.Enabled then 
			width_offset = 20
		end

		--Reposition our text field and scrollbar.
		self.ChatField:SetPos(5, 25)
		self.Scrollbar:SetPos(width - width_offset - 20, 25)
		self.ChatField:SetSize(width - width_offset - 25, height - 30)
		self.Scrollbar:SetTall(height - 30)
		
		local y_offset = 0

		--Since we're modifying the size of our canvas, we need to recalculate our markup objects.
		--This can become very costly. In the future, non-visible elements may be marked as invalidated,
		--and reparsed the next time they attempt to draw them.
		for i = 1, #self.TextLines do
			local Line, Scroll = self.TextLines[i], self.Scrollbar:GetScroll()

			y_offset = y_offset + Line.obj:GetHeight()

			Line.obj = markup.Parse( Line.Dirty, self.ChatField:GetWide() - 65 )
		end

		--Get the size of the canvas to let the scrollbar know how big it needs to scale to.
	    self.Scrollbar:SetUp( self.ChatField:GetTall(), self.base:GetCanvasSize() )
	    self.Scrollbar:SetScroll( self.base.CanvasSize )

	    --Call our original layout.
	    self:oPerformLayout()
	end
	
	self.Console:SetVisible(true)

	--Temporary - for testing purposes.
	concommand.Add( self.base.prefix .. "mouse", function()
		self.mouse = !self.mouse or false
		gui.EnableScreenClicker(self.mouse)
	end )

	--Toggles the console.
	concommand.Add( self.base.prefix .. "console", function() 
		self.Console:SetVisible(!self.Console:IsVisible()) 
	end )

	--Temporary.
	for i = 1, 1000 do
		self:AddText( color_blue, "testing! ", color_red, tostring(i) )
	end
end

--When we unload our module, get rid of the console object. Simple.
function MODULE:OnRemove()
	self.Console:Remove()
end

function MODULE:GetCanvasSize()
	self.CanvasSize = 0

	local Lines, Height = self.Console.TextLines, 4

	for i = 1, #Lines do
		--Get the current markup object for that line.
		local Line = Lines[i].obj

		--Add the overall height of the markup object.
		Height = Height + Line:GetHeight()
	end

	self.CanvasSize = Height

	--Return the full size of the chat lines.
	return Height
end

function MODULE:GetMaxLines()
	--Divide the size of our text field by the height of our font.
	return self.Console.ChatField:GetTall() / self.util.th
end

function MODULE:GenerateMarkup( font, max, ... )
	local str, clean, args = "", "", {...}
	local color_open = false

	--Loop through our argument table.
	for i = 1, #args do
		local data = args[i]

		--If we're dealing with a string, ideally, we should be also applying closing color tags.
		if TypeID(data) == TYPE_STRING then
			str = str .. data
			clean = clean .. data
			
			--Close the previous color tag.
			if color_open then
				str = str .. "</color>"
				color_open = false
			end
		--If we're dealing with a table, hopefully it's a color.
		elseif TypeID(data) == TYPE_TABLE then
			--Set the color tag to open and apply our color tag.
			str = str .. "<color=" .. data.r .. " " .. data.g .. " " .. data.b .. ">"
			color_open = true
		end
	end

	str = "<font=" .. font .. ">" .. str .. "</font>"

	--Parse our object and return it. We're going to save this for later. Generating these objects is very expensive.
	return markup.Parse( str, max ), str, clean
end

function MODULE:AddText( ... )
	local ChatLine, Console = {}, self.Console

	--Get our timestamp for this moment.
	local TimeStamp = os.date("[%I:%M:%S %p] ")
	
	--Get the size of our timestamp. Instead of being a part of the markup, this is drawn separately.
	surface.SetFont( self.util.Font )
	local StampWidth = surface.GetTextSize( TimeStamp )

	--Get the maximum width of our ChatField/Canvas.
	local Max = Console.ChatField:GetWide()
	local obj, dirty, clean = self:GenerateMarkup( self.util.Font, Max - StampWidth, ... )

	--Store our markup object, as well as the time stamp and its width.
	Console.TextLines[Console.CurrentLine] = { obj = obj, Clean = clean, Dirty = dirty, Stamp = TimeStamp, StampWidth = StampWidth }
	Console.CurrentLine = Console.CurrentLine + 1

	Console:InvalidateLayout()
end

function MODULE:MouseInLine( mouse_x, mouse_y, x, y, w, h )
	if mouse_x > x and mouse_x < w and mouse_y > y and mouse_y < y + h then
		return true
	end
end

function MODULE:DrawConsole(x, y)
	local Console = self.Console
	local TextLines, Scrollbar, ChatField = Console.TextLines, Console.Scrollbar, Console.ChatField
	
	--Height variable for convenience. y_offset is used to offset for wordwrapping.
	local Height, y_offset = self.util.th, 0

	--Loop through all of our textlines.
	for i=1, #TextLines do
		local Line = TextLines[i]

		if not Line then
			break
		end

		--Get the y_pos before we increase our offset.
		local y_pos = y + y_offset

		--To prevent us from drawing more than we can see, check if the drawing position of the
		--console text is greater than the canvas height or less than the size of our current line.
		if y_pos > -Line.obj:GetHeight() and y_pos < self.Height then
			local mouse_x, mouse_y = ChatField:CursorPos()

			if self:MouseInLine( mouse_x, mouse_y, x, y_pos, ChatField:GetWide(), Line.obj:GetHeight() ) then
				draw.RoundedBox( 0, x, y_pos, ChatField:GetWide(), Line.obj:GetHeight(), Color( 190, 190, 190, 150 ) )
				Console.SelectedLine = i
			end
			
			self.util:DrawText( Line.Stamp, x, y_pos, color_white, 0, 0 )
			Line.obj:Draw( x + Line.StampWidth, y_pos )
		end

		--Increase the offset for the next line to draw at to compensate for word wrapping.
		y_offset = y_offset + Line.obj:GetHeight()
	end
end

PhrozenFire:RegisterBaseModule( MODULE )