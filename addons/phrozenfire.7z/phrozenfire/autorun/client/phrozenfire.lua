--[[
	MOD/lua/autorun/client/PhrozenFire.lua [#6443 (#6443), 2134921086, UID:1176108743]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:45PM]
	===BadFile===
]]


//require( "fbse" ) //This will create our table.

PhrozenFire = {}

//ConVar, { ScriptText, Default Value, Min, Max }
PhrozenFire.cVars = {
	["core_enabled"] 		= { "enabled", 1, 0, 1 },
	["core_simpletext"]		= { "simpletext", 0, 0, 1 },
	["core_npcs"]			= { "npcsenabled", 1, 0, 1 }
}

function PhrozenFire:Init()
	self.prefix = "ph_"

	//For plugins with gamemode specific features.
	self.CurrentGamemode = GAMEMODE.FolderName
	
	self.Modules, self.BaseModules = {}, {}
	self.data = {}
	self.util = {}
	self.Hooks = {}
	
	surface.CreateFont( "PhrozenText2", { font = "Tahoma", size = 13, weight = 500, outline = false, antialias = true } )

	--We load all of our modules. They should register in the table.
	--If not, free lua autorun!
	self:LoadModules()
	--Lets init the defaults.
	self:CreateClientVars()

	self:InitializeModules( self.BaseModules )
	self:InitializeModules( self.Modules )

	concommand.Add( self.prefix .. "core_reload", function() 
		PhrozenFire:Reload() 
	end )

	self.Console = self:GetModuleByID( "console" )

	self:Print( color_white, "Loaded Successfully!" )
end

function PhrozenFire:Print( ... )
	if self.Console then
		self.Console:AddText( color_blue, "[PhrozenFire] ", ... )
	end
end

function PhrozenFire:InitializeModules( Modules )
	for k, obj in pairs ( Modules ) do
		local Module = obj.Module

		local cVars = Module.cVars or {}
		
		self:CreateClientVars( cVars ) //We load our convars for that module first.
		
		//And the hooking.
		for hk, ht in pairs ( Module.Hooks ) do // for hookname, hooktable
			for _, t in pairs ( ht ) do // for index, 
				self:AddHook( hk, t ) // second index is our function.
			end
		end

		if ( Module.Init ) then 
			Module:Init() 
		end
	end
end

function PhrozenFire:LoadModules( )
	local Modules, dir 	= file.Find("lua/PhrozenFire/Modules/*", "GAME", "namedesc")
	local Util 		= file.Find("lua/PhrozenFire/Modules/Util/*.lua", "GAME", "namedesc")

	for _, Module in pairs( Util ) do
		include( "PhrozenFire/Modules/Util/" .. Module )
	end
	
	for _, Module in pairs( Modules ) do
		include( "PhrozenFire/Modules/" .. Module )
	end
end

//Registers every variable in our cVarList.
function PhrozenFire:CreateClientVars( cVarList )
	local tab = cVarList or self.cVars
	
	if ( cVarList ) then
		table.Merge( self.cVars, cVarList )
	end

	for k, v in pairs ( tab ) do
		self:RegisterClientVar( k, v )
	end
end

function PhrozenFire:RegisterClientVar( name, varData )
	//Append our prefix to our index, creating our cvar.
	local NewCVar = string.lower( self.prefix .. name )
	
	//This is just making sure we don't overwrite our old value.
	local oldValue = GetConVarNumber( NewCVar )
	
	//Create our cvar with our listed default value.
	CreateClientConVar( NewCVar, varData[2], true, false )

	//Add a callback for our variable.
	cvars.AddChangeCallback( NewCVar, function( a, b, c )	
		self:SetValue( a, b, c ) 
	end )
	
	//Set the value in our script.
	local value = GetConVarNumber( NewCVar )

	self:SetValue( NewCVar, oldValue, value )		
end

//Generates a random string.
function PhrozenFire:GenerateRandomString( chars, seed )
	local str = ""
	
	for i = 1, chars do
		str = str .. ( string.char( math.Rand( 65, 75 ) ) )
	end
	
	return str
end

function PhrozenFire:SetValue( var, oldvalue, value )	
	//Remove our prefix
	local tvar = var:sub( self.prefix:len() + 1 )
	
	local varData = self.cVars[tvar]
	
	//Get our code's variable name from our cvar table.
	tvar = varData[1]
	
	//Now we set our value.
	self.data[ tvar ] = tonumber( value )
end

function PhrozenFire:GetValue( var )
	//Return our value.
	return tonumber( self.data[ var:lower() ] ) or 0
end

function PhrozenFire:GetBool( var )
	//Get our value.
	local val = self:GetValue( var )
	
	//Return if our value is equal to 1
	return ( val == 1 ) 
end

//Removes all of the hooks inside of our hook table, and then clears the table.
function PhrozenFire:ClearHooks()
	local detours = self:GetModuleByID( "detours" )
	
	//Interate through every entry.
	for k, v in pairs( self.Hooks ) do
		
		//Our value is also a table, let's go through that.
		for _, t in pairs ( v ) do
			
			//Nodify us of the removed hook, and then remove it.
			detours.hook:Remove( k, t[1] )
		
		end
	
	end
	//None of the hooks exist anymore. Remove them.
	table.Empty( self.Hooks )
end

//Adds a hook to our hook table under a unique, randomly generated name.
function PhrozenFire:AddHook( h, f )
	local detours = self:GetModuleByID( "detours" )

	//This is what we identify our hook as uniquely.
	local Name = self:GenerateRandomString( 12 )
	local Function = f
	
	//If we haven't added this hook already, add a new entry as a table.
	if not self.Hooks[h] then self.Hooks[h] = {} end
	
	//Inside of this, we add our HookIndetifyer. and our functions.
	table.insert( self.Hooks[h], { Name, Function } )
	
	//Now, actually add the hook.
	detours.hook:Add( h, Name, Function )
end

function PhrozenFire:ClearModules( Modules )
	for _, obj in pairs ( Modules ) do
		local Module = obj.Module
		
		if Module.OnRemove then
			Module:OnRemove()
		end

		for _, v in pairs ( Module ) do
			if type( v ):lower() == "panel" then
				v:Remove()
			end
		
			v = nil
		end	
	end
end

function PhrozenFire:Reload()
	self:ClearHooks()
	
	self:ClearModules( self.Modules )
	self:ClearModules( self.BaseModules )
	
	include("PhrozenFire.lua")
end

//This just takes a few things from the object, and makes a entry in our table.
function PhrozenFire:RegisterModule( object )
	self.Modules[ #self.Modules + 1 ] = { id = object.id, Module = object }
end

function PhrozenFire:RegisterBaseModule( object )
	self.BaseModules[ #self.BaseModules + 1 ] = { id = object.id , Module = object }
end

function PhrozenFire:FindByID( tab, id )
	for i = 1, #tab do
		local data = tab[i]

		if data.id == id then
			return data.Module
		end
	end

	return nil
end

function PhrozenFire:GetModuleByID( id )
	return self:FindByID( self.Modules, id ) or self:FindByID( self.BaseModules, id )
end

//Initialize a new table for our modules. This function just exists so we can set default values.
function PhrozenFire:NewModule( Name )
	local object = {}

	object.Name 	= Name or "#Bobby's favorite PhrozenFire module#"
	object.Author	= "Bobby"
	object.Version 	= 0
	object.handle 	= #self.Modules + 1
	object.base 	= self //Lets give our modules a reference to PhrozenFire ;).
	object.util		= self.util
	object.Hooks	= {}
	
	return object
end

PhrozenFire:Init()