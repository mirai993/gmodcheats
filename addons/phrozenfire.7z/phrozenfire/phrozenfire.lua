--[[
	MOD/lua/PhrozenFire.lua [#7883 (#7883), 2202540240, UID:201480494]
	Firehawk | STEAM_0:1:12116637 <98.249.188.196:27006> | [28.07.14 07:54:30PM]
	===BadFile===
]]


//require( "fbse" ) //This will create our table.

PhrozenFire = {
	prefix = "ph_",
	Modules = {},
	BaseModules = {},
	data = {},
	util = {},
	LastPlugin = nil
}

//ConVar, { ScriptText, Default Value, Min, Max }
PhrozenFire.cVars = {
	["core_enabled"] 		= { "enabled", 1, 0, 1 },
	["core_simpletext"]		= { "simpletext", 0, 0, 1 },
	["core_npcs"]			= { "npcsenabled", 1, 0, 1 }
}

function PhrozenFire:Init()
	--For plugins with gamemode specific features.
	self.CurrentGamemode = string.lower(GAMEMODE.FolderName)
	
	--Our font~
	surface.CreateFont( "PhrozenText2", { 
		font = "Tahoma", 
		size = 16, 
		weight = 500, 
		outline = false, 
		antialias = true,
		shadow = true
	} )

	--We load all of our modules. They should register in the table.
	self:LoadModules()

	--Initialize the default control variables.
	self:CreateClientVars()

	concommand.Add( self.prefix .. "core_reload", function() 
		PhrozenFire:Reload() 
	end )

	self.Console, self.Detours = self:GetModuleByID( "console" ), self:GetModuleByID( "detours" )

	--I hate that it has to come to this...
	self.Detours.hook:Add( "HUDPaint", "ConsoleHUD", function()
		local Console = self.Console.Console
		
		if Console.VisibleTimer - CurTime() > 0 and Console:IsVisible() == false then
			local x, y = Console:GetPos()
			local x2, y2 = Console.ChatField:GetPos()

			x = x + x2
			y = y + y2

			self.Console:DrawConsole( x + 2, y + Console.Scrollbar:GetOffset() )
		end
	end )

	self:Print( color_white, "Loaded Successfully!" )
end

function PhrozenFire:Print( ... )
	if self.Console then
		self.Console:AddText( color_blue, "[PhrozenFire] ", ... )
	end
end

--Include all of our modules. They each deal with initialization on their own.
function PhrozenFire:LoadModules( )
	local Modules	= file.Find("lua/PhrozenFire/Modules/*", "GAME", "namedesc")
	local Util 		= file.Find("lua/PhrozenFire/Modules/Util/*.lua", "GAME", "namedesc")

	for _, Module in SortedPairs( Util ) do
		self.CurrentPath = "PhrozenFire/Modules/Util/" .. Module 
		include( self.CurrentPath )
	end
	for _, Module in SortedPairs( Modules ) do
		self.CurrentPath = "PhrozenFire/Modules/" .. Module 
		include( self.CurrentPath )
	end
end

--Registers every variable in our cVarList.
function PhrozenFire:CreateClientVars( cVarList )
	local tab = cVarList or self.cVars

	if cVarList then
		table.Merge( self.cVars, cVarList )
	end

	for Name, Data in pairs ( tab ) do
		self:RegisterClientVar( Name, Data )
	end
end

--Registers a new cvar to be used with PhrozenFire.
function PhrozenFire:RegisterClientVar( Name, Data )
	Name = string.lower( self.prefix .. Name )
	
	CreateClientConVar( Name, Data[2], true, false )

	local originalValue = GetConVarNumber( Name )

	cvars.AddChangeCallback( Name, function( a, b, c )	
		self:SetValue( a, c, false ) 
	end )

	self:SetValue( Name, originalValue, false )		
end

--Generates a random string.
function PhrozenFire:GenerateRandomString( chars, seed )
	local str = ""
	
	for i = 1, chars do
		str = str .. ( string.char( math.Rand( 65, 75 ) ) )
	end
	
	return str
end

function PhrozenFire:SetValue( Variable, Value, WriteConsole )
	if WriteConsole then
		RunConsoleCommand( Variable, Value )
	end

	--Removes the prefix from our variable.
	local Name = Variable:sub( self.prefix:len() + 1 )
	
	Name = self.cVars[Name][1]
	
	--Set the value in our table.
	self.data[Name] = tonumber( Value )
end

--Returns the given variable as its numerical value.
function PhrozenFire:GetValue( Variable )
	return tonumber( self.data[Variable:lower()] ) or 0
end

--Returns the given variable as a boolean.
function PhrozenFire:GetBool( var )
	return self:GetValue( var ) == 1
end

--Adds a hook to our hook table under a unique, randomly generated name.
function PhrozenFire:AddHook( Module, Hook, Func )
	--If we're going to do this safe, we need the detours library.
	local detours = self:GetModuleByID( "detours" )

	--This is what we identify our hook as uniquely.
	local Name = self:GenerateRandomString( 12 )

	--If we haven't added this hook already, add a new entry as a table.
	if not Module.HookTable[Hook] then 
		Module.HookTable[Hook] = {} 
	end
	
	--Inside of this, we add our HookIndetifyer. and our functions.
	table.insert( Module.HookTable[Hook], { Name = Name, Func = Func } )
	
	--Now, actually add the hook.
	detours.hook:Add( Hook, Name, Func )
end

--Iterates the given modules table, cleaning each of them up.
function PhrozenFire:ClearModules( Modules )
	for _, obj in pairs ( Modules ) do
		local Module = obj.Module
		
		--Incase the module needs some special cleanup done:
		if Module.OnRemove then
			Module:OnRemove()
		end
		
		--Clear our module's hooks.
		Module:ClearHooks()

		--Delete all of our panels.
		for index, ptr in pairs ( Module ) do
			if type(ptr):lower() == "panel" then
				ptr:Remove()
			end
		
			ptr = nil
		end	
	end
end

--Clears all of the modules, as well as hooks, and reloads the base file.
function PhrozenFire:Reload()
	self:ClearModules( self.Modules )
	self:ClearModules( self.BaseModules )
	
	include("PhrozenFire.lua")
end

--Sets up the object's handles, loads it, and adds it to the given table.
function PhrozenFire:Register( ModuleContainer, Object )
	local Container, Handle = ModuleContainer, #ModuleContainer+1

	--Incase the last plugin in our stream is being reloaded
	if self.LastPlugin then
		Handle = self.LastPlugin.Handle
		Container = self.LastPlugin.Container
		self.LastPlugin = nil
	end

	Object.Handle = table.insert( Container, Handle, { id = Object.id, Module = Object } )
	Object.Container = Container

	Object:Load()
end

--Wrapper for Register function.
function PhrozenFire:RegisterModule( Object )
	self:Register( self.Modules, Object )
end

--Wrapper for Register function.
function PhrozenFire:RegisterBaseModule( Object )
	self:Register( self.BaseModules, Object )
end

--Searches the given table for the correct object id reference.
function PhrozenFire:FindByID( Table, id )
	for i=1, #Table do
		local Object = Table[i]

		if Object.id == id then
			return Object.Module
		end
	end

	return nil
end

--Searches both the Modules and BaseModules table for the given id.
function PhrozenFire:GetModuleByID( id )
	return self:FindByID( self.Modules, id ) or self:FindByID( self.BaseModules, id )
end

local plugin_meta = {}

function plugin_meta:ReloadPlugin()
	table.remove( self.Container, self.Handle )

	self:ClearHooks()

	self.base:Print( color_white, "Reloading plugin [", color_blue, self.Name, color_white, "]." )
	self.base.CurrentPath = self.Path
	self.base.LastPlugin = self

	include( self.Path )

	self = nil
end

function plugin_meta:ClearHooks()
	local detours = self.base:GetModuleByID( "detours" )

	--Our value is also a table, let's go through that.
	for Hook, HookTable in pairs ( self.HookTable ) do
		--Nodify us of the removed hook, and then remove it.
		for _, HookData in pairs( HookTable ) do
			detours.hook:Remove( Hook, HookData.Name )
		end
	end

	table.Empty( self.Hooks )
end

function plugin_meta:Load()
	local cVars = self.cVars or {}

	--Register our module's command variables.
	self.base:CreateClientVars( cVars )

	--Apply our module's hooks.
	for HookName, HookTable in pairs ( self.Hooks ) do 
		for _, Func in pairs ( HookTable ) do 
			self.base:AddHook( self, HookName, Func ) 
		end
	end

	if self.Init then self:Init() end
end

--Initialize a new table for our modules. This function just exists so we can set default values.
function PhrozenFire:NewModule( Name )
	local Object = {}

	Object.Name 		= Name or "#Bobby's favorite PhrozenFire module#"
	Object.Author		= "Bobby"
	Object.Version 		= 0
	Object.base 		= self --Lets give our modules a reference to PhrozenFire ;).
	Object.util			= self.util
	Object.Path 		= self.CurrentPath
	Object.Hooks		= {}
	Object.HookTable 	= {}

	setmetatable( Object, {__index = plugin_meta} )

	return Object
end

PhrozenFire:Init()