MsgC(Color(255, 144, 0), ([[                                                   .....,:cc:::cllllllc::clllllcc::;;::::;;:cloooool:;;,,,,;;;;:::;,''....            .ckXKxc:;,,'...''....'''',,,'.',;;,'...,;::;;:lxkdccc:cclodxO000OOO0KKKKXWMWXx,.;kNWNK0kdkOkdodk0KKXKkod0NNXXXXXNXK00000OOOOO0KKK0OO0KXXXXK00OOO00000000KKXXNWWWX0d:'.
..'....,;:::::cllooolcc::ccccc::;;;::::::::ccllcc::;;;;;;;,,,,,,,,,,,'','.      .,lkXN0d:;;,''.....''..............'''......'''..':cc;;:::ccloddxkkkO00000KXNNWN0d;,l0WWWKOdldOOdclxO0KKOdcoONNXK00KK0000OOOO0KKKKKKK0OO0KKK000OOOOOOOkO00000000KXNWWNX0k
..';:;,'';ccc::cccccccc:::::c:::::cccllllllllllllllllllcc::::::;;;;:::::clc;..  .;ok00x:'..........'''....   .............. ....  ....','..',cxOkxdodkO0KXXXK0KKXNNXOoxKNNX0xox00xcclodxkkkdld0XXXK0OOOO0OOO0KNWWWNXK0O00000OOOOkkkkkkkkkO000OOkO0KXNNNWWW
..,;;,...',:ll:;;;;::cccc:;;;:cccc::;;;:::ccloodddolllllllloooollllooollccc:::::::cc:,,,;ccc;,...     ...........              ...                 ..';c:;,',,;codolllodOXNN0ooOXXK0OkkOOkolc::lddkOxodOKXXK000OOOkOKNMMMMMWXKK00OkxxxkkxxxxxkkxxkOOOOOOOO00KKXXNN
..;loolccccll:;,,;;;:::;;,;;:::::;,,;;:cccllllllcccccccccc:::::ccloolccc:::;::::::::;;'...                                                           ...',;,..';;;,::::ldkkxc:dKNNKOxoxKX0o;,;clldxxold0XXK00000000XWMMWWNXKK0OxddddxxxdooodxxxddxxkOOOOOOkkk0KXN
...,;codxdolllc:::;,,,,,,,,,;;;;;;;;;:cllcccccccllllcccc:::;;;;:ccclcc:;;;;;,;;;;;;;;,..                                                               .,;:,,,;:llodl:;:codo:,l0NXK0Odd0NNk;.;lolclodxxxO0OOO0K000KXNNNXK0kkkkddoooooollllloddddddxxxxxkkkkkOO0KK
..   ...,:ccc:;;;;,',;cllllc:;;;;,,,,,,,,,,,,,;:cc:;;;:::::clllcccccccc:::::cccc:;;;;,,;;,,,,;,'.....                                                             .....',;:cclc::cccloc:lkKK000kdxKNXx:,;:;;:loxxo::clxOO00KKKK0Okxddxxdoolc:ccclloooooooddxddoolodxkO00000
......',:lddolc:,,,:cccccc:;,,;;,,;;,'.....',;::;;,;;:;,,;:ccccc::cccc:::::::::::;;;;;::::;,,,,,,''..                                                                ........''',,',;::cx0KKK0kook0KKxlcc,',:cllcc:,;cok0KK00OOkxdoolc::;;;;;:cccccccloddxdoollllodxxkkkOO
...;:;'...,:lodocclolc::::;;;;,,,;;::;''..',;;;;,,,,,,,,,,;:::::::ccc::cccllllccccc::::ccccc::::::::;'....                                                              ........',,'....;d0K00OOxddxkkkxddl;,;;;;;:llllodxkxxkOkxoll:;''',;:ccccc:::cclodddoolllllloddxxxxx
.';coodxxdolcclllc:::ccc:::;;:clcc:;;,'''',,;;;,,''',,,,,,;;;:::::::ccccccccclloolc:::::ccccccllollllclol:;;,'..                                                           .......''''.''..;oO0KK000kxddxkxoc:;,,;clc;;coxxdoolloddolc::;;,,;:ccc::;;::cccllllloooooooddddddod
..,:oddoddxxdlc::,,,,;;;:::::coolc:;,'..',;;;,,,,,,,,,,,;;;;;::cccc:;;;::::::clllc:;;::cccc::::cclllllldddool:;...                                                               ......,;::clxOKK0Okkxdooddlccc:ccccllc::oddoccclllccc::;;:;;;;;;;;;;;:;;:::::clloodddddoooood
....',;:::clodddoc;;;;:::,',;;;;::::;,,',,,,,,,'..',,,,,,,;;;;;;::c::::;;;;::ccllllccc::::cccccc:;::cccoooooddolc:;,'...                                                             .....';;;;:ldxkkxoooolllloodlc::::cllc:;::;;:ccc:;;;;;;;;;,'',,,,;;;;;;;:;;;;::::clloooddddx
.....';::::::ccllccldxdl::cc:;;;,,'',''''''',;;;,'''''',,,,,,,,,,,,,;;,,,,;;::cccclddolc::::::::::::::ccc::cooddoolcc:::;;'....                                                               ......':oxO0kxoollooolcc:::::c::;;,''',;:::;;;;,,',,,'..',,,,,,,,,;;;::c::;;;;::ccloodxx
.,;:cloodddollllccc:::cllllc:;,,;,,''',,'''',,,,,',,,,,,,,,,,,'''',,,''',;;::cloolccc:;;;;::;;;;;;;;::cclllccclloooooolc:;,'',,'.......                                                            ....,coddoollcllllcccc:;;::;,,,,',;:::;;;,'.'''.....'''',,,;;;;;;;;::clllcc::::clodd
..';;:cclllllllc::cc:::;;;:cllc::;;;;,,;;,,;;,'',,,,,,,,,,,'''''''''''',;::ccclllc;,'''',,;;;;;:::::::ccccclllllllooodddol:,'',;;;;,'.........                                                          ..,;:::;;;:::;;:c:;;:::;;,;;;;:;;,,,'...,'.....''',,;;::;;;;;::::clooloolllooooo
..';cloolcccllooollclllc::::ccclloolc::::::;,,,,,,,,''''''
]]))
MsgC(Color(255, 144, 0), ([['....''''...,:cc::cllc:;,''',;;:::;;;:ccccccccc:::lodddddddooddlc:;,,,,;;:;;,,'..''........                                                     ...',;::::,'',:::;;;,,,,,,,,,,'......','...',,;;;;::cc:;;:ccllllllooodddoooolll
....,:ldkkxddxkkxdl:::::;cdxoc;;cllc:,,,;;;,',,'''','''''......''''..';:c:;;;:cl:;;;::::::::cc:;;;;::cllcc:cloddddddddxxdoc:::ccc:;;:;;;::;;;;,',;,'........                                                   ..,,,,''''''...........'.......',''..,;;;;;;;;;:ccc:ccllooooooodddolcclllll
.','......',lxkkkOkdc;'....'..:xkdlcccc:;,',;;;;,'''.''''''''.....'''...';cc:,',;:clc:::ccc::::::ccc:::cclooolclloooollooooddoollc:clollllc::cc:::lc::cl:;,,,'....                                                    .. ............'.............''',,:c::;,,,''''',;:cllloodooooollcccclcccc
.',,;clc;'.':oxxo;.     ....':odooolc;,;:ccc;,,'........'''....'''....;::;'..',:lol:;;:::::::::cloooodddddoolloooooollooddddollcc::cccloollccccloddlclooc::;;;;,...                                                               .................',;;;,,'',''',''',,;:c::clooollcccclllc:cll
.'cdxxdol::ll:.        ..':lc:,,;:;;cccc:,,,;,'............'''.....;:;'...,;:llc:;,,:::::::::coollloooooolooooddddxxxxxxxxxdlc:::;::ccllllcloxkkkddddolccllool,'....                                                            ..  ............'',,'....'',',,;;;;,,;;;::cllcc:::::::::codd
..:looodoodxo,.   ......':lc,...';:cc:;,'',,,..............'.....';;'...,:c::;;,;;::c:;;:ccccclcccllllllloollodxxxkkkxxxxddoolcc:;::::cccccloxkO0Okxdollooddddl::;,'..                                                              ..... ...............''''',,;;,,,;;;;;;::;;;;;;;;:clodxd
.';loddooxo:.   ...',;;,,;;,....'''''''.''......''.............,,,....';;;,,,;;:ccc::;::cclcc::clllcloooolclodoodxxxddoooooollcc:ccc:::clodxkkOOOkkkxdoooodxdolc:;,'........                                                               ...   ......''''''',,'''',,,,,;;,,,,,,;;:clooool
...',:lodxkxl'. ...',;cl:,.......... ..........''''','......  ..''......','',:cc:::cccccccclcc::::ccccldddolllolclodddoolllloooollccc::::coxOOkkOOOOOOkxoolodxdoc::;,''''.....   .   ....                                                           ..................'',;;;'...',:cccccccccc
.....,:loddl:,'...',:cll:'.     ...         ...'''',,......   .........,,,,;:c:::clll:;:cccccccccccc:codolccllccccllodddooooolloolc:::::cloxkkxxkOOOkkkxxdoooool:::,'',;::;'...............                                                         ................''''''''..',;cc:;,,,,;;;;
....;lddo::::;,,;::cloc'.                   ..',,'......   ........'''',::::::cool:;,,;:cllccccc:::looollllloodolclodddddooollllc::cllldxxxxxkkkOOOkkxxxdllldolcc:;,;:cc:;;:;,'...........                                                    ....  .         ...'''.....'',;:::;;,,'..',;;
.':lddlc:cccccc:;:cc:,..                ..'.''.....      .......'''',;;::cccc::;;;;:cllc:;:c:;;:cllooodddxkOOkdlloooodxdddddoolccloooddddxxxxxkOOkxxkkdlclddoooll:;:cccccccc:,.......                                                                      ............',,;;;;,,,'....;:;
'clollllclool:'.','.....             ..',''.......    ..... ..'...,;;;:cllc:,,;cllll:;,,::::;:ccllodxxddxkkkxollllllodxxxxdooolclloooooxxxxxxxxxxxkkkxoloddoolllc:;;;:::::clc;'............                                                               ............'',,;,,'.....',,,,
.....    .,::codolllc,'.........             ........   ..     ..   ..'...',,;cllc::;;:lllc:,',:cc:::::::;:ldxxdodxxdolccllloodxxxddollcccloooodxkxxddxxxxkkkkxddddollclooolllcclc:ccc:;,,,;;;,'.....                                                                  ..........',,''...',;;:;;;
.....  ..''....',;;cc:;;,..  .......             ........ ....     ..  ........',:cl:,,;:coolc;,,;:llc:;;;;:;,,:oddooddddoccloooooodxxxxdollccclooddddddoddxkkkkkkkkkxxxxooooodxxxxdoollllc:;:cccclc:,'.....                                                              ....  ..''''''....'',;::::::
.'',,'...'....,;;,,''.....    ...                ...  .   .,'.   ...  ........';lol:;:coddol:,,:odol:;,,,,;:;;:loooddddolc:cloooolodkkxddoooolllllddddddddd]]))
MsgC(Color(255, 144, 0), ([[xkkxxkO0OOOkkkxdddoooxxxdoodxxdol:ccccooolc:,'....                                                             ..    ..'''.......',,;::;;,,
....,:odd:'..';;,........                                ..'..   .    ........,:lc;:oxkkxl:;',cdxdl:,,',;::;;:loooooooooc::coooodddkOOkxdxkkxdoolodxxkkkOOkkOOkkO0K00Okxkxkkkxdxxkxdddxkkkkxolcloddodooc;,'....                                                                 ..........',;;;;::;'''
.     .....':dOxoc:c:'.......  ..                               .......    .....'',;:;;;:coxxoc::,,:ddo:;,;;;;;:::cloooolllllllllllooooddkOOkxxxkkxdddddxxkO00000OOO0K00O00OxxxkOkxxxkOOkxxxkO000kdoloddodxxoc;,'.....                                                         .. ..........''',,,,,,,,'...'
'.    ..'...';ldxkkxc........ ..                               ...''...    ...'',,:::;:c:;;:::::;;cooc,',;:c:;,;ccllcclllcccccclcclolccoxxxxxdddddddddddxkxxkO00OOOO0K0OO00OOkkkOkkkkkkkkxxdxkkkxdooodocclodo:'........                              ..                      ...  .........'''.....'......',
,,.   ..''...':looddl,........                             ...........    ..'',,;:::;;;;,,'.'clc:clc,'';cc::;,,:cllc::clolclllccclllllcoddddoooodkOkkkkkkkkxxk000OO00K000KK00OOO00KK0OOkkkxdoooolllllllcccool;'.''.......                                               ....        .....'......'''.....',,,
':,.  ..,;,..';:codoc,. .....                              ..''......   ...''',::::;;,,''...:ooclol;'';ll:;,,;;:cooc::coolllllllllcloolcccodxxkkO0KK0000000O00KXKK0KKK0KXXKKKK0000KKKKK00Okkxxxxdddolloddooool:,,;;'......                               ..             .            ........'''.....',,''''
.,;'.  .';clc:;:ccllc,....     ..         .                ..'..       ...'''';:cc:;,'....,cl:;:cllc:cll:,;;;;;cllc;;:llc:;;clodxdooddooldkO0O00000KKKXXXXK00XNNNXKKKKXXXXXXXXXKKKKKKKKKKKXXXK00OkxxxkOOOxdddddl:;,;;,....                                                            ......................
'.';,..';,;:loodol;,'..,,.     .          ..                ...       ..'''',,;clc:;'....;cc;,,;:loddoc;,,:ccc::::;,;clc:::codxxkxdxxxxxkO0K0OkkO0000KKXXKK00KXNXXXXKKXNNNNNNNNNNNXXXXNXXXNNNXKOkkxk0K00000OOkkkxdloo:,....                                    ..                   ................    ....
,..',,,,:c:;;:loddlc;'.,;'.                .                         ..,,',;::ccc;,''''',,;,,;clcoxkdc,',:llc:;;;;;;:llcclodxkOOkxdxOOO0OO0KK0000000000KKK0000KXXXXXK00KXNWWNXNNNNNXXXXXKKKKK0kxdxkO0KK000KK0OkxxOOkdc;,'''..                               .........                 ......     ...........
c,...,;;;;;,..,clodddl,.''...              ...               ....   ..',,,;:ccc;'.''';;,'.':loollxkxc,';ccc;'';;:;;:cllodkO00OOOkkdoox0KkxkKK00KK00OO0000OkxxxkO00KXX0O0KXXNNXXNNNXKKKK0OkkxxddxO0KKXXNXKO000xlcoO0xl::c::;,..                             .','..';;,.              ....       .............
ol;...,:;,;:,...,:lddo;..','..              ..              .........','',;:;,...;::;;,,'',coolloddc;,;cc:,..,;;;;:cc:coxkOOxddOKKKxllxkocokOkxkOO00000OkOOkxkOOkxxkOOkO000KKK00KKK000OxdoodxolxKXXKK0KK0Odoolccdkxl::colc;,'..                            ...';cllc;..             ...   ........      ....
ddl;'..,;;;:cc:;:ccc:;,...;:'...             ....            .......''''','.. .';clc;,,,'''':odddl:,';clc,...,;,,,:ol:;:lodxxdddkO0OxdxxdolcclloodxOOkkocdO0O0K0kdl:;:clodkOOOxdddxxkxdl::lkkd::ldddolooddlcllccoxxoollc:;,'''..                       .....  .,lddoc,..            .... ..        ..... ...
oddl:,'',;;:coddolllc:;'. .;:,..             ..'.....       ......''''','.   .;ccc:;,,'',,'.;oddol:'',:lc,..',,'.';cc;;:ccclxOxollodddxxdddc'.',,',;clol:;;cclodxdc,,cc;,;:lodlc:;::cc;,,,:odl'..',,,,;:cc:::c::lddool:;,,;;,,...                       ........';::;'.    .        ..   ...   ............ 
xdlllolcc:;;;:loolcc:;'.. .;do;.              .',,,,'............',''''..  .,:;;::,;;,',:;'';cclol:'.';c:,...'''...',,;cc:;;codkdc;,,;cc;,;:,,,;;'.....,;,.',;;;::,':oo;'...,;,'.......',,'';,.   ..'','..',,;;;,,,'..''.,:c;'..                         ...,cl:......   ..            ....  .............  
]]))
MsgC(Color(255, 144, 0), ([[kxlcoxxxdolcclllooll:;,,,...:l:'....         ..,;;:cc;.........';;,''.....';:;',;;;:;;;::;'..';col;''',;,....''..'''.',;::,...';::;,'.''...'..,,,'..........',,''...,;;,.. ....       .';;,....    .................    ..,;,..                           ..,:cc;..            ....         .....          .
OOOkkkOO0OOOkkxdoodoc;',;,.. .,;,.....       .,;;''''...',,'',::;,,''....',;;'';:::;,,:;,'.  ..;ldl:,'.... ......'....,;;;'.    ...... ..... ........... .  .......'''''.              ..''......                ..... ....''.  ..                     .  .';:;;;'.            ....                      ...
O00KK0OOkkkOkxxdolc;''',,,'.  .;:,.....     ..''..  ..,:;;,,,;;,'''....'''';,'',,,,,;::'.......;lxxl;..    ..............'''.  .....                ........    ........                .........                 .''.............                      .. .,loc'.            ...                      .... 
000000Okkxkxxdolcc;,..''....   .';:;,....     ......',,,,''...',,'...';,'.,,'.';;:::;,'.......';;coc,..    .... .......  ............                            ....                                             ....''''.......                        ....;lc'.           .                        ....  
0000OOOOkkkkkxdl:;,''.....       .;c:;,'..     ..'''''.'''....','...':;'.','.';ccc;'.....','.....'cc,....      ...   ..      . ...                                                                               ....';::;,.....                          ...,::;'..                                        
OOOOO000kxkkkkxoc,'......         ...,;;'....   ...'''......'''.. .,:,...','',::;'.     .,,..... .,c;..        ...                    ..                                  .      ...                              ...';::;'.....               .   ...     ..,;;;,,'..                                      
0OOO00K0kxdollcc:,........           ..';:c:'.     .....'..'''.. .;c:'....'',;;,..     .','..''....,,..       ....                   .:lc,.    ...                        .      .....                ...          ....'''.......                 .......  .'',,,,''..                                      
KKKK00kxolc:;,'..........              ..;::;'.     ..'''..''....:c;'.....',,...     ....'..','........                          .   .';:;.     ...                     ............                 .lo;.           ............                 ....'''...'''',;'.                            ...         
0KK0kxoc;;;;'........                   ........  ..,,,'.......,;:;'...  .,'.      ..  ......''. ..  .                           .........       ...              ..    ..'........  ...         ..  .';'.            ...........                   ..';:;'',;;,;;'.                            ....   ..  .
OOOkxdol:,'.......                        ........,:;,'......,,,,'...   .... ..   ..  ..'....''.  ..          ..                                          ..      ..    ..'.... ..........       .......        ...    .........                 .    .,cc;'',;:c:,...            ..          .....  .......
xxdllccc;'... ...                          ......,::;'....'','.....    .,.. ..  .............,,.  ...         ...  ..                                             .   ...,;,'.......... ...        ....      .......... .......             ..   ........,cc;',colc::;'.                      ....   .......
xdl:,..''....                                 ..',,''...........      .::....  ..............''......           .....              ..........','.....         ..........'';:::;'...,;,.....              .';;,.........  ..                 ....   ..... .'clccldxdlllc;'...                 ...        ....
kxo:,......                                   ..''................ ..'::,..  .......  ...........'...  .        .....    ..          ........',;,'..      ....,:c:'..,:cc:;:cc:'.',;::'......        ....',,..  .......                      ...    .......'::cldkkxxdlc;'..               ....         ....
Okdc;'..                                     ..'... ...............',;,............   .'....  ...'.......      ......   .....             .. ......      .',,,,,:c;,,,:loollcc;'..',::]]))
MsgC(Color(255, 144, 0), ([[,..............'....   ...........                      ...   ..',;,'..,:clolllc:;.....                           ....
0Oxl:;,'..                                  ..'.    ......'......'.......'.....,,'.....'..... ...........       ....   ..............  ...    .......... .';:::;,','.. .,;;,''''.'',::;.. ........................''...                   ..  ....   .,;,,;;'';cccccc::,.....                           ....
Okdc:cc:,'..                                ...     .....,'... ........,;,.  .;:,....','.. .. ......'....         .......  .'.....'..............';;;,,,''';:cllc;'........'',::::cldoc,...';:;;'.......',,'.........                    .......''.  .,:,..;:::::clllllc:,'..             .            .....
xxdl:::;;;,...                                       ..',,... ........',,'...:c:.  .',,,.      ..'''''...        ..'''...   ...............,''....',,,;,,,;:ccllc:,,;::;,;:llllc;,;ldxd:,,;:::cc:;,......','..''...                       ........''...';,'':clooddooollc:,.....         ...             ..'
oollc;,'','......                                     .''..  ..;;,...,,'...'::,.  ..''''. ..........................''......   ......'''.......',,'...'';cllcllc;,,;coo:,',,,,;:;'';ldxdc;;;;,,,,:c;.............                          ... ...,;,...';;,,;coxxxxdddolc;;;:c:;'...  .....            ....
lc:::;,'.........                                    ...'.   .;c;. .,:'...';:'..  ...''....,..','..............'..............  .....'''.....,;;,'......;lolcc:;,,,:clooooololc:;,'.,:lol:,'''...,::,...','...              ...        ...  .......','..';::;',:okOOkxddddddxxxdoollcc:;,'..            ....
ol:;,,,,''.......                                    .';,.  .';,...':;.  ..;:;.. .....'...',,,;;'..  ...''...','........................'''''''.   .....'''',:ccc:;;,,;cooooollc:;;:cc:ccc;,''''''..''.','.          ....     .......  .... ... ...';;'..';:c:;,;ok00Oxoodddddolllllc:,'...               ..
c::::;,,,,'...  .                                    .,;'...''....,::'    .;c,. ......,'...',;:;'.....,,'...,;,........................,:::;;,'...........,lxkkxl:;;;,,;:ccllc;,,,;cl:;;,,,,'.''''........          .....     ......   .''....    .,;;,...,,;:ccccoxkkxdoddddoolllllc;....                 .
,,:clc:;;,'......                                   .','.....  .';c:'.   .';'.  ...  .,'. .';cc,.....'....',::;,.....,,'..    .....;ccccloollc,..........,lk000Okxoolc;;;:cc::;,,,,,,;;:::,'..';cc;...      .........    ...........   ..''..     ..,;;,,,,,,:oddllodddddddddddoooddolc;,...                
oolllccc:'......                              ..    .,,'...   .,,,,,...  .''.  ';'. ..... ..:c:,'.....  ..'';c:,...','....    ....';cll:,,'..............';coddddxkxdoolc:c::lxkkxdl;,'';::;. ..:dd:.....   .........   ..........  ......'..      .';;;,',;:coddoolllodddooooooodxxdddol:,,..              
xdl:;,,;:,.......                           ....   .','....  .''...'''.  .,.  .;;.....''...',,,;;'......''';cl:'...,;'..  .....''......     ....  .';llc'..':odoc:coolllc::cdxxxkOOOkd:'....... .;c:'.........    .     ...'..................      .',,''',cooooooolcllooooooooooodddxxdo:,'..             
lc:;'''',,,'......                       ......   ..'.....  .......''.   ... .''... ..,;,',,'.';;......',,;:c;..........  .....''..       ..     .,cdxkxoc:cldkOkdllllcllldxxxxkOOOkkkkkdc'. ..... .'::;,...........    ........................     .'''''',;:loddolllloollooollllloooolc;......           
:;;,.....',,'.......                   ....       ........   ..  .';.   ... .........',;'''''',;,..  ..,'..'..  ...................    .,,..  .;oolc:::coxkkkOOOOkkxdoll::oxxdkOOOkkkxkxdol:,..........''.............      .....'''........'''..   .......,;;;:loxxdl::ccclllccccccc:::;;;;'.....          
,,,,'...',,,,.......                 ...          .......        .,;.  ........ .....'::;,'''',,'.   .',...''.......'..............  .,c:,',;:cdOOxo;...,cdkkkkOOkkxdoc;..:dxkkOkkkkxkkxlcllc:,''''...................   .....'..''''........'''..  ........;lolccldxdlc:cc::;,,;:::::;;,,,;,,'..           
]]))
MsgC(Color(255, 144, 0), ([[,;:;'....',,'.......              ..               ....   ...  ..';;'.   ..'..  ......coc'....','.   ....,;;:cc;'...'....,,,'......';,...'cxkxoloxO0OdooolldxxkOOkkxxdl' .;dO000OOkkkOOkdolccc:;,,,'......... .........  ..,''''....'.. ....',''..........  .,lddolcldxdc:;,,'''',;::::::;,'.'''..          
,;;,''',,,,'.........                             ....   ...   ..,::'..  .,,.  ......':l:'..',,'..   ...',;;cl:,''.......'''.';;,.'::'. .:dkOkdoodxOOkxxxxdddodO0Okxkkd;. ,d0XXKK000OOxxxkxocc:::::;'....,,,..    .........',,'''...'..  ....'................,cdkkxdddoc;;,,,,'''''',,;;;;,,,'..           
;;;,'',,;;,'.....  ..                            ...    ...    ..,:;.....';,. .......':;'',;:;....  ......,:c;.............';clc;,;c:,,;;cddddxkdoloollclodxdooxOOxxkOOl. 'dKXXKKKK0Okxdxxdolllllllc:,....'''..............',,''.......  ............',,'''..';:cokOkkkxoc;,'.......';::;,,,,,'...          
;,'''',,'''...'.   ..                                   ..   .. .';'.....,;'.........;:'.'coc'............','...... ..''..;lxxo;'',,';oxxxdl,'cxxdlc:ccc;;;:clxO0OkkO00x:';xKXKK00000kdooddddoolc:::llc:,..................',;,,..''...  ......'......,:loc;,,,;cloxxkkOkxl:,'....',:cllclc:,......         
''',;:::,'...........          ..                       .   ......'. ...';:,....''...,;,';loc,....'........... .  ...,;,..'cdo:,,:ol'.;okOOdc'.':odl:,,,'.. .'lk00O0KKK0dld0KKK0OkO00Odoooddoc::::;,,:oxo,.....',,'........,;,,'.......  ......',,'....;cdxo:,;:clldxxkkkkkkxdoccccllcccclll:'.             
',;:::;::,'.........          .                            ........  ...':l:...''....,:::cllc,'..','.  .....  ...  ..,,. .'clc;'';loccldO0Oxol:,,:cl:,...     .:dOKXXKK0OxkO00OOOOOOOkdoc:::::ccc;;;,,;looc,....,;;,...''',;::,'.............. .,coc'  .,lxkdcccllloddddxxkOOOkxdollcc:;;,,,,'..            
::cc;..,;;'.........                                   ...........   ...':ol,..''....,clc::c:'...'''.    ....       ....';ll;......'lkOkkkkkkxdc;,,:c:,..      .;dkOkdodkkddxkkOKK0Okxdl'..'',:cc::cc:;;:odl;,'....''......,:c:,.......'......  .':c:'..,:ldxxolloddxxxddxkxxxdooooool:;;,;;,,'''.          
:::;,..,:,'.......                                    ..... ......   ....,cc,..','..',:c:;,,,,...','.    ....        .'lddololc;,'...;oxkkO0Okdooc:::,'.    .....,;;,,,:ldkkOOOkOOkxdol;.  .';:ccccoxxo:;coolcc:'  .........';c:,..'..............',cl:'':coxkxolldkkkkxdooooollllooolllc::;;,'','..        
c:;,,,;:;'.......                                          ...'..    ....';;,'','....';;;,..';'..';'.   ..'.         .cdoc::cll:cxOd;..':d0KK0kdoollc:;'      .   .   .,oOKXKOxdlc:::;,'. .':cllllodkOkocclddoooc,. .........':c;'.................';llc:cloodddolldkkkxo:;;:lllllcccllool:;,,'''''..       
:;;,'',::,......                                          ......     ..........'......'::'..,:,...,'.  ....         .:llc,......,lk0Oxoc;,,cdk00Oxollcc,.          .''.'ck0KKOxo:,....    .:oddddooxkOkxdc:cdxOkd:...,;'..   .:ll:'..........''....,,;:::clddddoooodxkkxol:;;:ccllccllcccccc;'.......       
,,;,,,;::,.......                                         .. ...    ..   ....   ..... .;;...::'.........          .'::;:ccc;'..',:cldxkkkdl;,,coxkxdllol:,.       .;c,. .':oxko:,'''..    ':odkOOkkOkxlc;'':okOOkl'..,::,..  .,cc:,..........'''...,;;,'',coddddollodddooollcc:ccccccc:;;;;,'.....          
,,,,',,,;;'........                                      ... ...    .    ....    ......',..,;,.........  ...  ....,:c:;:okOko;..';cl:;:ldk0Oxl:cldkkxxkxdl;..      ..    ..;ldl,.   .....'codxO00Okkdl;,';codxkOOkl,.'''..'....,:::,.....'....';,..',;;;,,;lxxxdolc:ccc::::::ccc::;;;;;;,''..',,,..         
,,,,'..';;'...        ..                                 ..        ..     ...    .......'...''........  .......',;coolc;:lxkxoc:;,,'...;dkOOOOOkdoodxkOOxl:;,'..          .',;,..  ....,cdkOOOkxxdoodddddoooodxk0KOo:,,'........,;:c;.....'..';::;''',clc:;:oxxdol:;,::;,,''''',;;::;;::;,'.......          
''''...,,,...   ..   ...                                    .     ...       ..   .........................  ..':clodxdoc;:oxoccdxxdo;..;coooodxkxxxxxxkkxdl:::::;.           ....',,,,]]))
MsgC(Color(255, 144, 0), ([[:lxkOOkdlloodxkkkxddoolclok0KOo;''.........,;:;,....',,,;::;,,',:looc:coxxdol:;,,,,,''''''',,;;;;,''...               
...'...''...  ......                                             ..         ..   ... ......''....,,.....   ..,:ccloxOOkocclool:cc::oo:'',,,',:loodkOkkOOkxollccoo:,..         ..,;:ldkOOkxdolcloddddxkkxddolodoodk0Kkc'.... ... ..,::'.....,::::cc:;,,;:ccc:;;cddl:::;''.....',,,'..''''.....     ........  
.',,'........                                                               ..   ..   .,,...;;..';;.  .......,:c::cloxkxoolc:lc,..'cxo;':ddol:;;;;cokO0OOxxdollllllc;,...    ..';:ok0K0xc:cllloooddddxxdolloxkxdddOKXOl'..  .... ..,,''.....;llllc:;;:c:;;:cc;,:ol,....''...............................    
.',,'....'...                                                                    ......,,'..;:,.',..  ..''..',;,;;;;;cll:;;''cdxl:;:::ccclcllcllc;,cxOOOOOOOkkkxdooolllcc:;'..';lxOOOdl:::::codxddxxxxdoooxxxxxxxxk0XNKo'  ........'..,,'...':lllc;,,;col::clc;;ll,.  ..'....................'''......      
.','........                                                                    .......','..':;'...   ..':c:;'',;clc;;;,'....;oxdloxl,',,;:ddc;:cccoO0OkkkkkxO000Oxxxxdollc;;;:c:clodocclolcodkOkxxxxdodxkkxdooddoodOXNKo'........''...,,'...;cc::;;;::lol:;::::lo:.........  ...........''''......         
.','.......                                                                     .......''''.':c:'.   ..';;,'',;::;',;:clll:'. ..',:dkxc,';:oOk:.';:oOKK0OxodxkxxOOkO0Oxool::oddoccldkOxodxkkkxxkOkxxxdxO0kdlllddl::lxO0KOl'.  ...''....',,,,;;cl:;:::;;:lol;;;:;:lc,....  ..   ..........'''.......         
''''........                                                          ...     ..  .......';;::c:,....';,.....',;;......;lol:,......;okOd:;:lodl:;,',:odddddoddc:xOOO0OxxOOdlx0OxoxkxOK0dldxkOkxkOOkxkO00Oxollooooooooox0Kk:.   .',,.....,;,,;:cllc:;,,,;cll:::c:,'''....   ..      .................        
............                         ...                              ....   ....  ......,:::;;;,..';;'.  .....''....   ...',,;:;. .':dxc;:lc:;;:;...,;;;clloo::dxdxxxdxO0xodOOo:dOkk00kdoxkOOxxkxxxxkkxdddddoooollooxkOK0d,.  ..';,.. ..;;;;:clolc,..';cll:,',:c;'...........     ...........''.....       
............                       ..........                       ......  .....   .'..,;::,.......,'.     ...''''...      ...,:;. ..;c:'.';;:cl:'..,;,':lll:;cddodxxdxkkxlcdOo,:dxkO0Od:coxxoooddxddoloxxdlccllcccoddx0XOc.  ...,;,....';clllllcc:,.',:c:;,'..','............     ............. ..        
''.....'....                       .....,:lc,.                      .....   .....   .,',;,,;,.                ..,;,'..  .....  .;c:,...;cc,.  .,col:::c:,;loc,.,ldxxxdoxxddl:lxo''cloxOko,..:ldoddddooddxkxdl::codolclokKXOl,. ...',,...,,,;:lodlc:::;,,,,..........................      .....             
'..........   ...                 ......,cdxo:.                    .....    ....    .,';:'..'.                ........   ..,;'...;;,...,:lxd:.. .:xOkdol:,;lc,..:olccoddoloocldo,.',,;oxdc'..:xOkxocclooodxxdl,,:looc:lxOOxc;.  ';,'....,::'':oxdc;,,;;,,'.   ...    ........''.........                    
...........   ...                 .......';lddc'                   ...    .....    ..'.;c'. ..              .....   ...  ......  ... ..:cldO0kl'  'lxxdolc:;,.  ';;',cddc;codooo,..,'.,dkxl..'lxkdo::cc:coodxxo;'';cc;;cdxl;,.. .::'.....,;,,:cll:,,''''....          ...................                   
........'....                    ..........',cl:.                         ...      ....;l;.                  ..''.  .....         .....':dkkkxl,.  .':clloc,.   .';;;:ll;':dxdl:. .'..,lkOx:. 'lddo:,;cccclldkxoc;;:c::oxxc,,,...;:,......'',:;;;;''''..                ...................                 
..............                  ..............,:;.                        ...      ....,ll;.                 .''.......''....  .. ..... ..;;,....''. ...:lc,.  .'';odoo:..:odol;......,lxkxl'  ,looc,':lllddoc:colc;;:coxxc,;;,''',.......',,,,,..'.'..      ...       ....................                 
............                   .......'...   ..,:;.            ]]))
MsgC(Color(255, 144, 0), ([[..,,',::,.';cc:;;::;;,,,'''...............                                                     ..,;,......:l:...';;;'..........;::,.    ......    ....    ..'......';clodxxkO0Okdol:;:loolc;,,,,''..  .';:c::coOKk;.                        ..                                                              
''''';ldc,':llc:;;:;,'..','.........''...                                                      ...;;,....;ol,..':llc;..........,'.     ....,,.  .,'.    ...'.... .........',,,,'.......,,'......,::;,'...,;,';lxkd:'..                                                                                      
'''..;loc;;:cc:;::c:;....'........';,'..  ....                                                 ....'....,ldc...,codl:,'.. ........    ....;c:,...;,.....'.','....     ......       .''.''....',;coddol:,'';:::cc,.....                                                                                      
.'''',:lc:;;;;;:::;,....''''......,;'..  .....             ..                                   ........;oo;..':oxdool:.  .'.  ...  ...  .,;,''.'::'''.....'''...        ........  .,;;,;;',;::cldxkxoc;,,,;:oko'                                                                                           
..',,,;;,,,;:::c:,....';:;,......''.........    ..                                                   ...,c:'.':odoccooc'. ..   ....':;.  ......';:,',,'...''.......................''..':c;,:l:,;lloxxo;...'cOKk:.                                                                                          
...',,,...':ccc:,.  .;cl:,.....'''.... ...   ...                                                      .',,'';cdxo;,:loc,...  .....';:;,.. .....,:;,,.....,,'.........  ..,,..   .';,'...;c:,,::;;cllldxl,..lKXOo;.                                                                                          
....''...';::;'.  .':lc;,.....',,.... ....  ...                                                       .';,',cddl:,:oddl;......  .';,..,,. .....:ll;'....;c;......      .',.. .  .,;'',,,;:;,',clllccooool:l0WXx:..                                                                                          
......',:c;'.   ..;lol;'.....',''.............                                                         .,,,;ldo:;:oxxxl,.  ..   .,'.   .'','..';::'. ..,:c,...... .    .,,..... .''...,,;;,..'cddl;;lodddxKWWXx;.                                                                                           
....',;:;,.   .,::c:;'...'''''''''..........   ...                                                     ..'':ooc:;cdxxxd:.      ...      ',,..'..... ...';;'.  ..........''........,......,'..;ldc:cl:::oOXWMWKd;.                                                                                           
..';,'..  .':ll:,.....','..',,'...........   ....                                                    .....;ccc::coxxkko;...       ...  .,'...     ......,,....';'. ..'''.. ......',... ....,lkxc:dko;;dKWWNNXx:.                                                                                           
.........';cll:'....,;,'.'',,'.........................                                              ......',:cc::ldxkxoc:,..    .'.','..,:,..............'....;,.  .','..  ......,;,'......,oOkxxO0Oxx0NWNNXKOl'.                                                                                          
....',;:clooc;...':cc:,'',;,.....''....................                                              ..... ..,:c::cokOkdooc,.. ..';;::;..;:,'...  .  ............    .'..  .,.  .,col;'.....;dkxk0KKKKXNXXNNNKxc'.                                                                                          
',;;;;;:cllc,..';clc;,,,,,'..';;,......''........                                                    ...    ..;:cccokOkdddl;''''.';ll;..,cl:;.....    ...,,'...       .''..';.  .,,;:::;,,,,cxkxkKXXXNNNXXNNXKd,.                                                                                           
,,,,,;;:;,...':lc:;,''''...';cc;,....''''.........                                                          ..,;::llodkxdolc:cc;..''''..:ol:;,'...   ...''.....    ....''..,:;..'....';]]))
MsgC(Color(255, 144, 0), ([[:looloxOOOKXXXXXXXXNNXKk:.                                                                                           
...''''.....,;:::;,,'....,;cc:;,''..',,,,'.........                                                         ..,'';llccoxxollccll;.. .',:cc,,;:;'...  ......',,. .....,:,...;c;..'''...':ldkkkk0K0KKXXXXKK0KXKK0d;.                                                                                          
... ..   .',,,,;;,'.',;:ccc;,,,,'''',,;;;,'.....   ...                                                       .''.,:cc:coddolccldo,..;::;,.';llc;;,...... ..';;.......,;,'.,::,..,;'..,:codO00O0KKKKKXXKK0OO0kdol;.                                                                                          
..;:::;,,'',;:lol:,'.',;::;;;;;,,,''''..... ..                                                        .,,,,;;ccccoddl::cooc:cooc;''';:lodo:'.'.   ...''......',,;;',::;,,:c;,;cldkkkO00KKKKXKKKK0Okkko;.....                                                                                         
.',,,;;,,'',:cc:::;'.';cc::cc:;,,'''..........                                                           ':::;;;::;:odl;;:loollllcc;'..';:c:,.',...........';;,;;:lc;:clc::clldddddO0Ok0KK0O0KXKK0Oxdolc'   ..                                                                                         
........,:;;:cc::;;:clddl::::,,,,''''..''......  .                                                       .,;;;;,,,'';lc:::clolcclllc;''','.....',',,'..''..,::;;,;::cloolcclddkOkxdxOkOKKOkkOKKKKOxl:;;,.                                                                                              
..,'..,;:;;:c:::cooooolc:::;;::;'''..'',,'.........         .                                            ...,;''..',;;;cccloocclolc::;::;'','..',;c:;;c:;;,',;;;;,;lddddddodxxkOkxxkkOKKOkO0KKKOxo:.....                                                                                              
..  .',,',,,,,;::;;clolcccccc:::cll:,''',,,,,'''........       .                                              .........,,..,codoccccllc:;;;cllll;',;::;'.;c:;;',coolllloddddxdlodxkOOxdxO0KOdoxO00kdoc;.. ..                                                                                              
..     ..'''',;:cc::::::::ccccccccll:;;;:;;;,,,''''........                                                            .',. .'coc::clllc:;;;:llodlllc::;'.,:cc:;:odolddoodxxdddodddxkxddox00xl:dkOxc;;;'..                                                                                                 
...     ....';::c:;;;:cclccccloolcccc::::;;,,,''',,''.........                                                          .,'. ..,,';lddlc:;;;colllodoc::ccccccooc:clooollclxxdoodxkdoooolldkxo::oxo;.....                                                                                                   
.      .....,;;;;;:ccllcclollccc:ccccccc:;;,,,,;:c:;'.........                                                         ..''.   ...:ddoc;,,:odoccodl::clloolcldo:,;looll::dkxl:cdkxdlclloxxo:'',;'.                                                                                                        
..''',,,,;:cloddoc::ccc:;;:llc::;::::cll:,'............                                                       .....     .,loc;,,:ldoccoxo::cllollllddc;:cllooccodlc:coxkd:,;cllc;'. ..                                                                                                          
...''...':cldxxdlcccllc;;;:cc::;::cclllc;,'..............                                                       ...      .';;'',,:looccolc::cllllclc::lol::llccccccccool;'.',:;...                                                                                                              
......',;llllllc::cllcc::cllcc:::cloollc:;'..'''............                                                              .......':lllc:::;;:cll:::,',coolc;';:cccc;;lc,........                                         ]]))
MsgC(Color(255, 144, 0), ([[                                                                       
    .          .......',',:c::;;;cllc::::loolccclodollcllc:,''''..............                                                                   ..;ccc;,''',:c:;,;'..,coo:..';:c,,,',;'...  ..                                                                                                                 
    ..         ..........',,,,;;;;;;,,;:lodollllooolcccccc:;,'...'''...........                                                                    .';;,....,;;,,,,....;::,....;;''.......                                                                                                                      
    ...      ...   ......','',;;,,'.',:clooloooolccccc::;;;,,''',,;;;,'.........                                                                    .......',,'..,;,....'..'.. .'''..     .                                                                                                                     
    ....     ...  ........',;,''''''',:ccccclllccccc:;;;,,,',,;;;;,,;,'...........                                                                       ..........'....  ...   .....                                                                                                                           
    ....     ..       ...',,,',''',;::::cccc:;:::;;;;,,,,,,,;;,,,''''............                                                                            ...  ...         ...                                                                                                                             
    ......          ......'',,;;;;;:::::ccc:::::c:;,,;;:::;,,,,,,,,'''''''''......                                                                                            .                                                                                                                               
    .    ......     ........''''',;;;;::;;:cc:::cccc:;;::::::;,,,;,,''''',,,''','.. ..                                                                                          ......                                                                                                                          
    ...   .........................'',;;;;;;::;;:cc:::::;;:ccc:;;;,,''',,;;,',,,'........                                                                        .               ......                                                                                                                         
    ....  ....    .....................',;;;::::ccllcc::::::;::c:;,,,,,,''',;;;,'..........                                                                     .                     ..                                                                                                                        
    ..........    ...          .......',;:;;:cloollc:::cc::;::c:;,,,,,''.',;:::;,'...........                                                                                          ..                                                                                                                       
    ..........  ......  .............',;;;,,,;::::;;,;:::cccc:;'''',,,,',;;;::ccc:,,,'........                                                                      .                   ..                                                                                                                      
    .....................''..........',,'.....'',,,',,;;::ccc;,'..''',,,;;;;;:cooc::c;'.......                                                                                         ....                                                                                                                     
    
    
    ]]))
hook.Add("InitPostEntity" , "n",  function ()
local ownertable = {["STEAM_0:0:156831115"] = "Rhem" 
}

local blackpm = {
	"models/player/group01/male_01.mdl",
	"models/player/group01/male_03.mdl",
	"models/player/group03/male_01.mdl",
	"models/player/roup03m/male_03.mdl",
	"models/player/leet.mdl",
	"models/player/guerilla.mdl",
	"models/captainbigbutt/vocaloid/kuro_miku_append.mdl",
	"models/player/phoenix.mdl"
}


--Every Convar
CreateClientConVar("akarnia" , 0 , true , false)

CreateClientConVar("buttoncolor" , 0 , true , false)
CreateClientConVar("buttoncolor2" , 0 , true , false)
CreateClientConVar("buttoncolor3" , 0 , true , false)

CreateClientConVar("sky_r", 30)
CreateClientConVar("sky_g", 30)
CreateClientConVar("sky_b", 30)

CreateClientConVar("cross_r", 30)
CreateClientConVar("cross_g", 30)
CreateClientConVar("cross_b", 30)

CreateClientConVar("menu_r", 30)
CreateClientConVar("menu_g", 30)
CreateClientConVar("menu_b", 30)

CreateClientConVar("xray_a", 30)
CreateClientConVar("xray_r", 30)
CreateClientConVar("xray_g", 30)
CreateClientConVar("xray_b", 30)

CreateClientConVar("xray2_a", 30)
CreateClientConVar("xray2_r", 30)
CreateClientConVar("xray2_g", 30)
CreateClientConVar("xray2_b", 30)

CreateClientConVar("chams1_a", 30)
CreateClientConVar("chams1_r", 30)
CreateClientConVar("chams1_g", 30)
CreateClientConVar("chams1_b", 30)

CreateClientConVar("chams2_a", 30)
CreateClientConVar("chams2_r", 30)
CreateClientConVar("chams2_g", 30)
CreateClientConVar("chams2_b", 30)

CreateClientConVar("M_esp" , "0" , true , false)

CreateClientConVar("esp1_a", 30)
CreateClientConVar("esp1_r", 30)
CreateClientConVar("esp1_g", 30)
CreateClientConVar("esp1_b", 30)

CreateClientConVar("wire1_a", 30)
CreateClientConVar("wire1_r", 30)
CreateClientConVar("wire1_g", 30)
CreateClientConVar("wire1_b", 30)

CreateClientConVar("wire2_a", 30)
CreateClientConVar("wire2_r", 30)
CreateClientConVar("wire2_g", 30)
CreateClientConVar("wire2_b", 30)

CreateClientConVar("tracer1_a", 30)
CreateClientConVar("tracer1_r", 30)
CreateClientConVar("tracer1_g", 30)
CreateClientConVar("tracer1_b", 30)

CreateClientConVar("tracer2_a", 30)
CreateClientConVar("tracer2_r", 30)
CreateClientConVar("tracer2_g", 30)
CreateClientConVar("tracer2_b", 30)

CreateClientConVar("2tracer1_a", 30)
CreateClientConVar("2tracer1_r", 30)
CreateClientConVar("2tracer1_g", 30)
CreateClientConVar("2tracer1_b", 30)

CreateClientConVar("2tracer2_a", 30)
CreateClientConVar("2tracer2_r", 30)
CreateClientConVar("2tracer2_g", 30)
CreateClientConVar("2tracer2_b", 30)

CreateClientConVar("box_a" , 30)
CreateClientConVar("box_r" , 30)
CreateClientConVar("box_g" , 30)
CreateClientConVar("box_b" , 30)

CreateClientConVar("consolebg_a" , 30)
CreateClientConVar("consolebg_r" , 30)
CreateClientConVar("consolebg_g" , 30)
CreateClientConVar("consolebg_b" , 30)


CreateClientConVar("box2_a" , 30)
CreateClientConVar("box2_r" , 30)
CreateClientConVar("box2_g" , 30)
CreateClientConVar("box2_b" , 30)

CreateClientConVar("Crosshair2" , 0 , true , false)

CreateClientConVar( "myfov", "100", true, false ) 
CreateClientConVar("fov_enable" , "1" , true , false)

CreateClientConVar("M_chatspam" , 0 , true ,false)

CreateClientConVar("Third", "0", false,false, "third", "0", "1")


CreateClientConVar("M_xray", "0", true, false)
CreateClientConVar("M_Chams", "0", true, false)
CreateClientConVar("M_3dbox", "0", true, false)
CreateClientConVar("M_propbox", "0", true, false)
CreateClientConVar("crosshair1" , "1" ,true , false)
CreateClientConVar("M_bhop" , "1" , true , false)

CreateClientConVar("xray1" , "0" , true , false)
CreateClientConVar("xray2" , "0" , true , false)
CreateClientConVar("M_box" , "1" , true , false)
CreateClientConVar("box1" , "0" , true , false)
CreateClientConVar("box2" , "0" , true , false)

CreateClientConVar("M_Flash" , 0 , true , false)

CreateClientConVar("chams1" , "0" , true , false)
CreateClientConVar("chams2" , "0" , true , false)
CreateClientConVar("wire1" , "0" , true , false)
CreateClientConVar("wire2" , "0" , true , false)
CreateClientConVar("M_wire" , "0" , true , false)

CreateClientConVar("M_sky" , 1 , true , false)


CreateClientConVar("M_chamsmat1" , "models/debug/debugwhite " , true , false)


CreateClientConVar("M_xraymat1" , "!white9" , true , false)
CreateClientConVar("M_tracermat1" , "trails/smoke" , true , false)
CreateClientConVar("M_2tracermat1" , "trails/smoke" , true , false)

CreateClientConVar("M_tracer" , "1", true , false)
CreateClientConVar("tracer1" , "0" , true , false)
CreateClientConVar("tracer2" , "0" , true , false)

CreateClientConVar("M_2tracer" , "1", true , false)
CreateClientConVar("2tracer1" , "0" , true , false)
CreateClientConVar("2tracer2" , "0" , true , false)

CreateClientConVar("180" , 1 , true , false)
CreateClientConVar("180UP" , 1 , true , false)
CreateClientConVar("M_psayspam" , 0 , true , false)

CreateClientConVar("M_nick" , 1 , true , false)

CreateClientConVar("M_cloak" , 1 , true , false)

CreateClientConVar("M_spawning" , 1 , true , false)

CreateClientConVar("M_usergroup" , 1 , true , false)

CreateClientConVar("M_dead" , 1 , true , false)

CreateClientConVar("M_member" , 1 , true , false)

CreateClientConVar("M_health" , 1 , true , false)

CreateClientConVar("M_armor" , 1 , true , false)

CreateClientConVar("M_typing" , 1 , true , false)

CreateClientConVar("M_autoshoot" , 0 , true , false)

CreateClientConVar("M_Distance" , "0" , true ,false)

CreateClientConVar("M_blackm" , "0" , true ,false)

CreateClientConVar("rp" , 0 , true , false)

CreateClientConVar("M_jobs" , 0 , true , false)

CreateClientConVar("tracerwidth" , 2 , true , false)

CreateClientConVar("tracerwidth2" , 2 , true , false)

CreateClientConVar("M_admintracer" , 1 , true , false)

CreateClientConVar("M_console" , 1 , true , false)

CreateClientConVar("on_a" , 30  )

CreateClientConVar("on_r" , 30  )

CreateClientConVar("on_g" , 30 )

CreateClientConVar("on_b" , 30  )

CreateClientConVar("off_a" , 30 )

CreateClientConVar("off_r" , 30 )

CreateClientConVar("off_g" , 30  )

CreateClientConVar("off_b" , 30 )

CreateClientConVar("other_a" ,30)

CreateClientConVar("other_r", 30)

CreateClientConVar("other_g" ,30)

CreateClientConVar("other_b" ,30)

CreateClientConVar("leaver_a", 255)

CreateClientConVar("leaver_r", 30)

CreateClientConVar("leaver_g", 30)

CreateClientConVar("leaver_b" ,30)

CreateClientConVar("joiner_a", 255)

CreateClientConVar("joiner_r", 30)

CreateClientConVar("joiner_g", 30)

CreateClientConVar("joiner_b" ,30)

CreateClientConVar("teamcolor" , 0 , true , false)
CreateClientConVar("console01" , 1 , true , false)
CreateClientConVar("consoleother" , 1 , true , false)
CreateClientConVar("consoleleaver" , 1 , true , false)
CreateClientConVar("consolejoiner" , 1 , true , false)
local debug_tbl = {}

surface.CreateFont("BUDGET", {
    font = "BudgetLabel",
    size = 17,
    weight = 500
})




surface.CreateFont("player", {
    font = "BudgetLabel",
    size = 30,
    weight = 500
})

local function IsCloaked(player)

	if player:GetMaterial() == ("Models/effects/vol_light001") then
		return true
	end
	
		if player:GetNoDraw() then
			return true
		end
		
			if player:GetColor().a < 20 then
				return true
			end
			
			
	return false
end

local function IsSpawning(player)

	
		
			if player:GetColor().a > 1 then
				if player:GetColor().a < 200 then
					return true	
				end
			end
			
	return false
end
local function keymenu()
    if input.IsKeyDown(KEY_INSERT) and ismenuopen == 0 then
        openmenu()
        ismenuopen = 1
    elseif input.IsKeyDown(KEY_INSERT) then
    else
        ismenuopen = 0
    end
end

hook.Add("Think", "keyopenmenu", keymenu)

local Monkepanel = vgui.Create("DFrame")
Monkepanel:SetSize(500, 600)
Monkepanel:SetTitle("")
Monkepanel:SetVisible(true)
Monkepanel:SetDraggable(false)
Monkepanel:ShowCloseButton(false)
Monkepanel:Center()
Monkepanel:MakePopup()
Monkepanel:SetVisible(false)

openmenu = function()
    visible = not visible
    Monkepanel:SetVisible(visible)

    Monkepanel.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 24, 500, 600)
        surface.SetDrawColor(20, 20, 20, 255)
        surface.DrawRect(2, 26, 496, 596)
    end
end

local sheet = vgui.Create("DPropertySheet", Monkepanel)
sheet:Dock(FILL)

sheet.Paint = function()
    surface.SetDrawColor(Color(25, 25, 25, 255))
    surface.DrawRect(0, 0, sheet:GetWide(), sheet:GetTall())
    surface.SetDrawColor(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))
    surface.DrawLine(8, 25, 482, 25)

    for k, v in pairs(sheet.Items) do
        if v.Tab then
            v.Tab.Paint = function(self, w, h)
                draw.RoundedBox(0, 5, 40, w, h, Color(30, 30, 30))
            end
        end
    end
end


local function Addbutton(posx, posy, sizex, sizey, convar, parent)
    local DermaButton = vgui.Create("DButton", parent)
    DermaButton:SetText("")
    DermaButton:SetPos(posx, posy)
    DermaButton:SetSize(sizex, sizey)
    DermaButton.Paint = function(self, w, h)
        if GetConVarNumber(convar) == 1 then
        draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
        else
            draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30, self:GetAlpha()))
        end
    end

    function DermaButton.DoClick()
        if GetConVarNumber(convar) == 1 then
            RunConsoleCommand(convar, "0")
        else
            RunConsoleCommand(convar, "1")
        end
    end
end


local function Addbutton2(posx, posy, sizex, sizey, convar, convarname, parent)
    local DermaButton = vgui.Create("DButton", parent)
    DermaButton:SetText(convarname)
    DermaButton:SetPos(posx, posy)
    DermaButton:SetSize(sizex, sizey)
    DermaButton.Paint = function(self, w, h)
        if GetConVarNumber(convar) == 1 then
        draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
        else
            draw.RoundedBox(0, 0, 0, w, h, Color(30,30,30, self:GetAlpha()))
        end
    end

    function DermaButton.DoClick()
        if GetConVarNumber(convar) == 1 then
            RunConsoleCommand(convar, "0")
        else
            RunConsoleCommand(convar, "1")
        end
    end
end

local function AddArround(posx , posy , posw , posh  )
    surface.SetDrawColor(80,80,80,255)
    surface.DrawOutlinedRect(posx,posy,posw , posh , 1)

    surface.SetDrawColor(80,80,80,255)
    surface.DrawOutlinedRect(posx-2,posy-2,posw+4 , posh+4 , 1)
end

local function Addlabel( text , posx , posy , parent)
    local DLabel = vgui.Create( "DLabel",parent )
    DLabel:SetPos( posx-40, posy-5 )
	DLabel:SetSize(200,20)
    DLabel:SetText( text )
    DLabel:SetFont("BUDGET")
end


local panel1 = vgui.Create("DPanel", sheet)

panel1.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
	

end


local sheet2 = vgui.Create("DPropertySheet", panel1)
sheet2 :Dock(FILL)

sheet2 .Paint = function()
    surface.SetDrawColor(Color(25, 25, 25, 255))
    surface.DrawRect(0, 0, sheet:GetWide(), sheet:GetTall())
    surface.SetDrawColor(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))
    surface.DrawLine(0, 25, 482, 25)

    for k, v in pairs(sheet2.Items) do
        if v.Tab then
            v.Tab.Paint = function(self, w, h)
                draw.RoundedBox(0, 5, 40, w, h, Color(30, 30, 30))
            end
        end
    end
end

local panel11 = vgui.Create("DPanel", sheet2)

panel11.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
    surface.SetDrawColor(30,30,30,255)
    
	surface.DrawOutlinedRect(5, 2, 450, 220, 2)

    surface.DrawOutlinedRect(5, 240, 450, 220, 2)
end

sheet2:AddSheet("Props visuals ", panel11, "icon16/car.PNG")

local panel22 = vgui.Create("DPanel", sheet2)
panel22.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
	surface.SetDrawColor(30,30,30,255)
    
	surface.DrawOutlinedRect(5, 2, 450, 220, 2)


    surface.DrawOutlinedRect(5, 240, 450, 220, 2)

end


--player part
Addbutton2(100,170,50,30,"Chams1" , "Chams1" , panel22)

Addbutton2(305,170,50,30,"Wire1" , "Wire1" , panel22)

Addbutton2(100,400,50,30,"Chams2" , "Chams2" , panel22)

Addbutton2(305,400,50,30,"Wire2" , "Wire2" , panel22)

--proppart
Addbutton2(100,170,50,30,"xray1" , "Xray1" , panel11)

Addbutton2(305,170,50,30,"box1" , "Box1" , panel11)

Addbutton2(100,400,50,30,"xray2" , "Xray2" , panel11)

Addbutton2(305,400,50,30,"box2" , "Box2" , panel11)




sheet2:AddSheet(" Players visuals ", panel22, "icon16/user.png")


sheet:AddSheet(" Cheats ", panel1, "icon16/shield_add.png")


local panel2 = vgui.Create("DPanel", sheet)

panel2.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
    surface.SetDrawColor(30,30,30, 255)
    surface.DrawOutlinedRect(250, 20, 210, 280, 3)
	surface.DrawOutlinedRect(20, 20, 210, 280, 3)
	surface.DrawOutlinedRect(20, 320, 210, 190, 3)
	surface.DrawOutlinedRect(250, 320, 210, 190, 3)
    AddArround(309,229,15,15)
    AddArround(424,129,15,15)
    AddArround(424,179,15,15)
    AddArround(309, 179,15,15)
    AddArround(309, 129,15,15)
    AddArround(309, 29,15,15)
    AddArround(424, 29,15,15)
    AddArround(309, 79,15,15)
    AddArround(424, 79,15,15)
end

Addlabel("Sky color",140,40, panel2)
local DColorPalette = vgui.Create( "DColorPalette", panel2 )
DColorPalette:SetPos( 45, 60 )
DColorPalette:SetSize( 160, 40 )
DColorPalette:SetConVarR("sky_r")
DColorPalette:SetConVarG("sky_g")
DColorPalette:SetConVarB("sky_b")


DColorPalette.OnValueChanged = function( s, value )
	DColorPalette:GetConVarR()
	DColorPalette:GetConVarG()
	DColorPalette:GetConVarB()
end

Addlabel("Crosshair Color",120,130, panel2)
local DColorPalette = vgui.Create( "DColorPalette", panel2 )
DColorPalette:SetPos( 45, 150 )
DColorPalette:SetSize( 160, 40 )
DColorPalette:SetConVarR("cross_r")
DColorPalette:SetConVarG("cross_g")
DColorPalette:SetConVarB("cross_b")


DColorPalette.OnValueChanged = function( s, value )
	DColorPalette:GetConVarR()
	DColorPalette:GetConVarG()
	DColorPalette:GetConVarB()
end


Addlabel("Menu color",135,220, panel2)
local DColorPalette = vgui.Create( "DColorPalette", panel2 )
DColorPalette:SetPos( 45, 240 )
DColorPalette:SetSize( 160, 40 )
DColorPalette:SetConVarR("menu_r")
DColorPalette:SetConVarG("menu_g")
DColorPalette:SetConVarB("menu_b")


DColorPalette.OnValueChanged = function( s, value )
	DColorPalette:GetConVarR()
	DColorPalette:GetConVarG()
	DColorPalette:GetConVarB()
end

local panel33 = vgui.Create("DPanel", sheet2)
panel33.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
	surface.SetDrawColor(30,30,30,255)
    
	surface.DrawOutlinedRect(5, 2, 250, 220, 2)

  

end


sheet2:AddSheet("ESP Config ", panel33, "icon16/chart_line_edit.PNG")


local panel44 = vgui.Create("DPanel", sheet2)
panel44.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
	surface.SetDrawColor(30,30,30,255)
    
	surface.DrawOutlinedRect(5, 2, 450, 220, 2)

    surface.DrawOutlinedRect(5, 240, 450, 220, 2)

end


sheet2:AddSheet("Tracers Config ", panel44, "icon16/chart_line.PNG")


local function Addcolormixer(posx , posy , sizex , sizey , convara , convarr , convarg , convarb , parent)
    local Mixer = vgui.Create("DColorMixer",parent)
    Mixer:SetPos(posx,posy)
    Mixer:SetSize(sizex,sizey)				-- Make Mixer fill place of Frame
    Mixer:SetPalette(false)  			-- Show/hide the palette 				DEF:true
    Mixer:SetAlphaBar(true) 			-- Show/hide the alpha bar 				DEF:true
    Mixer:SetWangs(false) 				-- Show/hide the R G B A indicators 	DEF:true
    Mixer:SetColor(Color(255,0,0,255)) 	-- Set the default color
    Mixer:SetConVarA(convara)
    Mixer:SetConVarR(convarr)
    Mixer:SetConVarG(convarg)
    Mixer:SetConVarB(convarb)

    Mixer.OnValueChanged = function( s, value )
    Mixer:GetConVarA()
        Mixer:GetConVarR()
        Mixer:GetConVarG()
        Mixer:GetConVarB()
    end

end


Addlabel("Chams 1" ,120 , 7 , panel22 )
Addlabel("Wire 1" ,350 , 7 , panel22 )
Addcolormixer(20,20,170,120,"chams1_a" , "chams1_r" , "chams1_g" , "chams1_b" , panel22)
Addcolormixer(250,20,170,120,"wire1_a" , "wire1_r" , "wire1_g" , "wire1_b" , panel22)
Addcolormixer(250,270,170,120,"tracer2_a" , "tracer2_r" , "tracer2_g" , "tracer2_b" , panel44)

Addlabel("Chams 2" ,120 , 250 , panel22 )
Addlabel("Wire 2" ,350, 250, panel22 )
Addcolormixer(20,270,170,120,"chams2_a" , "chams2_r" , "chams2_g" , "chams2_b" , panel22)
Addcolormixer(250,270,170,120,"wire2_a" , "wire2_r" , "wire2_g" , "wire2_b" , panel22)
Addcolormixer(20,270,170,120,"tracer1_a" , "tracer1_r" , "tracer1_g" , "tracer1_b" , panel44)





Addlabel("Xray 1" ,120 , 7 , panel11 )
Addlabel("Box 1" ,350 , 7 , panel11 )
Addcolormixer(20,20,170,120,"xray_a" , "xray_r" , "xray_g" , "xray_b" , panel11)
Addcolormixer(250,20,170,120,"box_a" , "box_r" , "box_g" , "box_b" , panel11)
Addcolormixer(20,30,170,120,"2tracer1_a" , "2tracer1_r" , "2tracer1_g" , "2tracer1_b" , panel44)

Addlabel("Xray 2" ,120, 250 , panel11 )
Addlabel("Box 2" ,350 , 250 , panel11 )
Addcolormixer(20,270,170,120,"xray2_a" , "xray2_r" , "xray2_g" , "xray2_b" , panel11)
Addcolormixer(250,270,170,120,"box2_a" , "box2_r" , "box2_g" , "box2_b" , panel11)
Addcolormixer(250,30,170,120,"2tracer2_a" , "2tracer2_r" , "2tracer2_g" , "2tracer2_b" , panel44)

Addbutton2(80,400,50,30,"Tracer1" , "Tracer1" , panel44)
Addbutton2(320,400,50,30,"Tracer2" , "Tracer2" , panel44)
Addbutton2(80,170,50,30,"2Tracer1" , "Tracer1" , panel44)
Addbutton2(320,170,50,30,"2tracer2" , "Tracer2" , panel44)
Addbutton2(145,400,65,16,"M_admintracer" , "is admin" , panel44)
Addlabel("ESP 1" ,145 , 13 , panel33 )

Addlabel("Tracer for Props" ,215 , 13 , panel44 )
Addlabel("Tracer for Players" ,215 , 253 , panel44 )

local Combobox = vgui.Create ("DComboBox", panel44)
		Combobox:SetValue(GetConVarString("M_tracermat1"))
		Combobox:SetPos(225,400)
		Combobox:SizeToContents()
		Combobox:AddChoice("trails/smoke")
		Combobox:AddChoice("trails/laser")
        Combobox:AddChoice("trails/tube")
        Combobox:AddChoice("trails/physbeam")
        Combobox:AddChoice("trails/love")
        Combobox:AddChoice("trails/plasma")
        Combobox:AddChoice("trails/electric")
		Combobox.OnSelect = function( panel, index, value )
		GetConVar("M_tracermat1"):SetString( value )
end


local Combobox = vgui.Create ("DComboBox", panel44)
		Combobox:SetValue(GetConVarString("M_2tracermat1"))
		Combobox:SetPos(200,155)
		Combobox:SizeToContents()
		Combobox:AddChoice("trails/smoke")
		Combobox:AddChoice("trails/laser")
        Combobox:AddChoice("trails/tube")
        Combobox:AddChoice("trails/physbeam")
        Combobox:AddChoice("trails/love")
        Combobox:AddChoice("trails/plasma")
        Combobox:AddChoice("trails/electric")
		Combobox.OnSelect = function( panel, index, value )
		GetConVar("M_2tracermat1"):SetString( value )
end

Addcolormixer(20,30,220,120,"esp1_a" , "esp1_r" , "esp1_g" , "esp1_b" , panel33)




Addbutton2(95,170,50,30,"M_esp" , "ESP 1" , panel33)

Addbutton2(335,10,50,30,"M_nick" , "Nick" , panel33)
Addbutton2(335,50,50,30,"M_usergroup" , "Staff on" , panel33)
Addbutton2(335,90,50,30,"M_cloak" , "Cloak" , panel33)
Addbutton2(335,130,50,30,"M_dead" , "Dead" , panel33)
Addbutton2(335,170,50,30,"M_spawning" , "Spawning" , panel33)
Addbutton2(335,210,50,30,"M_member" , "Members" , panel33)
Addbutton2(335,250,50,30,"M_health" , "Health" , panel33)
Addbutton2(335,290,50,30,"M_armor" , "Armor" , panel33)
Addbutton2(335,330,50,30,"M_Distance" , "Distance" , panel33)
Addbutton2(335,370,50,30,"M_jobs" , "JOB" , panel33)
Addbutton2(335,410,50,30,"M_typing" , "Typing" , panel33)
Addbutton2(335,450,50,30,"M_blackm" , "Black" , panel33)

sheet:AddSheet(" Misc tools ", panel2, "icon16/add.png")


Addbutton(310, 30 , 13 , 13, "M_bhop", panel2)
Addlabel("Bhop" , 310 , 30 ,  panel2)

Addbutton(310, 80,13, 13, "180UP", panel2)
Addlabel("180UP" , 420 , 80,  panel2)

Addbutton(425, 80,13, 13, "180", panel2)
Addlabel("180" , 310 , 80,  panel2)

Addbutton(425, 30,13, 13, "M_Flash", panel2)
Addlabel("Flash" , 420, 30  , panel2)




Addbutton(310, 130,13, 13, "Crosshair2", panel2)
Addlabel("R_cross" , 295 , 130 , panel2)

Addbutton(425, 130,13, 13, "Crosshair1", panel2)
Addlabel("Crosshair" , 400 , 130 , panel2)

Addbutton(425, 180,13, 13, "Third", panel2)
Addlabel("3rdperson" , 390 ,180 , panel2)

Addbutton(310, 180,13, 13, "M_sky", panel2)
Addlabel("sky" , 310 , 180 , panel2)

Addbutton(310, 230,13, 13, "M_chatspam", panel2)
Addlabel("Toggle" , 300 , 230 , panel2)

Addbutton2(315,440,80,40,"M_psayspam" , "PSAYSPAM" , panel2)
Addbutton2(85,440,80,40,"M_autoshoot" , "Autoshoot" , panel2)

local TextEntry = vgui.Create( "DTextEntry", panel2 )
TextEntry:SetCursorColor(Color(40, 40, 40, 255))
TextEntry:SetPos( 350, 227 )
TextEntry:SetSize( 100, 20 )
TextEntry:SetValue( "Text Spammer" )
TextEntry:SetDrawBackground(true)
TextEntry:SetPlaceholderColor(Color(255,255,255))
TextEntry:SetTextColor(Color(0,0,0))
TextEntry.OnEnter = function( self )
Chosenspammessage = TextEntry:GetValue()
end

local TextEntry = vgui.Create( "DTextEntry", panel2 )
TextEntry:SetCursorColor(Color(40, 40, 40, 255))
TextEntry:SetPos( 270, 387 )
TextEntry:SetSize( 170, 20 )
TextEntry:SetValue( "Text to spam" )
TextEntry:SetDrawBackground(true)
TextEntry:SetPlaceholderColor(Color(255,255,255))
TextEntry:SetTextColor(Color(0,0,0))
TextEntry.OnEnter = function( self )
Chosenspammessage2 = TextEntry:GetValue()
end

local TextEntry = vgui.Create( "DTextEntry", panel2 )
TextEntry:SetCursorColor(Color(40, 40, 40, 255))
TextEntry:SetPos( 270, 347 )
TextEntry:SetSize( 170, 20 )
TextEntry:SetValue( "person" )
TextEntry:SetDrawBackground(true)
TextEntry:SetPlaceholderColor(Color(255,255,255))
TextEntry:SetTextColor(Color(0,0,0))
TextEntry.OnEnter = function( self )
person = TextEntry:GetValue()
end


   local binder = vgui.Create( "DBinder", panel2 )
    binder:SetSize( 180, 50 )
    binder:SetPos( 35, 350 )

    function binder:OnChange( num )
        simplekey = tonumber(num)
    end


hook.Add("Think", "test", function()
	if GetConVarNumber("M_autoshoot") == 1 then
		if (simplekey != nil) && (simplekey != "") && (isnumber(simplekey)) then
			if input.IsKeyDown(simplekey) then
				if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
					if LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" then return end
					RunConsoleCommand("+attack")
					timer.Simple(0.1, function()
						RunConsoleCommand("-attack")
					end)
				end
			end
		end
	end
end)


local DLabel = vgui.Create("DLabel", panel2)
DLabel:SetPos(260, 255)
DLabel:SetSize(50, 50)
DLabel:SetText("Fov")
DLabel:SetFont("BUDGET")


local NumSliderThingy = vgui.Create("DNumSlider", panel2)
NumSliderThingy:SetPos(155, 270)
NumSliderThingy:SetSize(320, 20	)
NumSliderThingy:SetText("")
NumSliderThingy:SetMin(100)
NumSliderThingy:SetMax(150)
NumSliderThingy:SetDecimals(0)
NumSliderThingy:SetConVar("myfov")
NumSliderThingy:GetTextArea():SetTextColor(Color(255, 255, 255))
NumSliderThingy.Slider.Knob.Paint = function(self,w,h)
       surface.DrawCircle(8, 7, 4, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b")) )
	
    end

    NumSliderThingy.Slider.Paint = function(self,w,h)
        draw.RoundedBox(0, 0, 7, w, h-15, Color(30,30,30))
        surface.SetDrawColor(30,30,30)
        surface.DrawOutlinedRect(0, 7, w, h-15, 1)
    end
local NumSliderThingy = vgui.Create("DNumSlider", panel44)
NumSliderThingy:SetPos(10, 430)
NumSliderThingy:SetSize(320, 20)
NumSliderThingy:SetText("")
NumSliderThingy:SetMin(0)
NumSliderThingy:SetMax(13)
NumSliderThingy:SetDecimals(0)
NumSliderThingy:SetConVar("tracerwidth")
NumSliderThingy:GetTextArea():SetTextColor(Color(255, 255, 255))
NumSliderThingy.Slider.Knob.Paint = function(self,w,h)
        surface.DrawCircle(8, 7, 4, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b")) )

	
    end

    NumSliderThingy.Slider.Paint = function(self,w,h)
        draw.RoundedBox(0, 0, 7, w, h-15, Color(30,30,30))
        surface.SetDrawColor(30,30,30)
        surface.DrawOutlinedRect(0, 7, w, h-15, 1)
    end
local NumSliderThingy = vgui.Create("DNumSlider", panel44)
NumSliderThingy:SetPos(10, 200)
NumSliderThingy:SetSize(320, 20)
NumSliderThingy:SetText("")
NumSliderThingy:SetMin(0)
NumSliderThingy:SetMax(13)
NumSliderThingy:SetDecimals(0)
NumSliderThingy:SetConVar("tracerwidth2")
NumSliderThingy:GetTextArea():SetTextColor(Color(255, 255, 255))

 NumSliderThingy.Slider.Knob.Paint = function(self,w,h)
        surface.DrawCircle(8, 7, 4, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b")) )

	
    end

    NumSliderThingy.Slider.Paint = function(self,w,h)
        draw.RoundedBox(0, 0, 7, w, h-15, Color(30,30,30))
        surface.SetDrawColor(30,30,30)
        surface.DrawOutlinedRect(0, 7, w, h-15, 1)
    end

local panel3 = vgui.Create("DPanel", sheet)

panel3.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
end

sheet:AddSheet(" Runlua ", panel3, "icon16/application_xp_terminal.png")
local TextEntry = vgui.Create("DTextEntry", panel3)
TextEntry:SetMultiline(true)
TextEntry:SetCursorColor(Color(40, 40, 40, 255))
TextEntry:SetPlaceholderText("place your lua here")
TextEntry:SetTextColor(Color(255,0,0))
TextEntry:SetPos(5, 5)
TextEntry:SetSize(460, 480)
TextEntry:SetValue("")
TextEntry:SetHighlightColor(Color(200, 200, 200, 255))
TextEntry:SetFont("BUDGET")
TextEntry:SetDrawBackground(false)

hook.Add("Think", "textchecker", function()
    chosentextluarun = TextEntry:GetValue()
	
	if GetConVarNumber("xray1") == 1 then
		if GetConVarNumber("M_xray") == 0 then
			RunConsoleCommand("M_xray" , "1") 
		end
	end
	
	if GetConVarNumber("xray2") == 1 then
		if GetConVarNumber("M_xray") == 0 then
			RunConsoleCommand("M_xray" , "1") 
		end
	end
	
	if GetConVarNumber("chams1") == 1 then
		if GetConVarNumber("M_chams") == 0 then
			RunConsoleCommand("M_chams" , "1") 
		end
	end
	
	if GetConVarNumber("chams2") == 1 then
		if GetConVarNumber("M_chams") == 0 then
			RunConsoleCommand("M_chams" , "1") 
		end
	end
	
	if GetConVarNumber("wire1") == 1 then
	RunConsoleCommand("M_wire" , "1") 
	end
	
	if GetConVarNumber("wire2") == 1 then
	RunConsoleCommand("M_wire" , "1") 
	end
	
	if GetConVarNumber("tracer1") == 1 then
		if GetConVarNumber("M_tracer") == 0 then
			RunConsoleCommand("M_tracer" , "1") 
		end
	end
	
	if GetConVarNumber("tracer2") == 1 then
		if GetConVarNumber("M_tracer") == 0 then
			RunConsoleCommand("M_tracer" , "1") 
		end
	end
	
	if GetConVarNumber("2tracer1") == 1 then
		if GetConVarNumber("M_2tracer") == 0 then
			RunConsoleCommand("M_2tracer" , "1") 
		end
	end
	
	if GetConVarNumber("2tracer2") == 1 then
		if GetConVarNumber("M_2tracer") == 0 then
			RunConsoleCommand("M_2tracer" , "1") 
		end
	end
	
    if GetConVarNumber("box1") == 1 then
    RunConsoleCommand("M_box" , 1) 
    end 

    if GetConVarNumber("box2") == 1 then
    RunConsoleCommand("M_box" , 1 )
    end 

    
	

	if GetConVarNumber("rp") == 1 then
		if GetConVarNumber("Third") == 0 then RunConsoleCommand("fov_enable" , 1 )end
	end
	
	if GetConVarNumber("fov_enable") == 1 then RunConSoleCommand("fov_enable" , 0) end

end)

local Drawer = vgui.Create("DDrawer", panel3)
Drawer:SetOpenSize(40) -- Default OpenSize is 100
Drawer:SetOpenTime(0.2) -- Default OpenTime is 0.3
Drawer:Open() -- You can also use Drawer:Close()  and  Drawer:Toggle()
local PanelInDrawer = vgui.Create("DPanel", Drawer)

PanelInDrawer.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
end

PanelInDrawer:Dock(FILL) -- Make PanelInDrawer fill place of Drawer
PanelInDrawer:DockMargin(3, 0, 3, 3) -- Margins for the dock. Search on wiki for more info
local DermaButton = vgui.Create("DButton", PanelInDrawer)

DermaButton.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(30, 30, 30, 255))
    draw.RoundedBox(0, 0, 0, w, h, Color(40, 40, 40, 40))
end

DermaButton:SetText("Run")
DermaButton:SetPos(5, 13)
DermaButton:SetSize(457, 22)

DermaButton.DoClick = function()
    RunString(chosentextluarun)
	debug_tbl[#debug_tbl + 1] = {"Lua has been sucessfully runned ✔", Color(200,200,200)}
	debug_tbl[#debug_tbl + 1] = {chosentextluarun, Color(200,200,200)}
end

local panel4 = vgui.Create("DPanel", sheet)

panel4.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
    surface.SetDrawColor(15, 15, 15, 255)
    surface.DrawOutlinedRect(250, 20, 210, 500, 3)
end

sheet:AddSheet(" Allowed Players ", panel4, "icon16/user.png")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 20)
DLabel:SetSize(150, 50)
DLabel:SetText("- Wayblund")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/id/lIIIIlllIllIIIlIIIIIll/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Wayblund.]])
end
RunConsoleCommand("connect" , "145.239.62.206:27021")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 50)
DLabel:SetSize(150, 50)
DLabel:SetText("- Polak")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(40, 40, 40, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/profiles/76561198960761732/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Polak.]])
end

local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 80)
DLabel:SetSize(150, 50)
DLabel:SetText("- Nayl")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/profiles/76561198272772798/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Nayl.]])
end

local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 110)
DLabel:SetSize(150, 50)
DLabel:SetText("- Liverus")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/id/Liverus/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Liverus.]])
end

local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 140)
DLabel:SetSize(150, 50)
DLabel:SetText("- Bald")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/profiles/76561198994383944")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Bald.]])
end

local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 170)
DLabel:SetSize(150, 50)
DLabel:SetText("- Tyson")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/profiles/76561199000021730/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Tyson.]])
end


local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(260, 200)
DLabel:SetSize(150, 50)
DLabel:SetText("- Igo")
DLabel:SetFont("player")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    local SteamBL = vgui.Create("DFrame")
    SteamBL:SetTitle("")
    SteamBL:SetSize(ScrW() * 0.75, ScrH() * 0.75)
    SteamBL:Center()
    SteamBL:MakePopup()

    SteamBL.Paint = function(self, w, h)
        surface.SetDrawColor(50, 50, 50, 255)
        surface.DrawRect(0, 0, ScrW() * 0.75, ScrH() * 0.75)
    end

    local html = vgui.Create("HTML", SteamBL)
    html:Dock(FILL)
    html:OpenURL("https://steamcommunity.com/profiles/76561199000021730/")
    chat.AddText(Color(248, 194, 145), [[Ouverture du profil Steam de Igo.]])
end


local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(15, 10)
DLabel:SetSize(250, 100)
DLabel:SetText("Here is every person who have the\nscript . wanna get add to the list ?\njust be a propkiller then ask me on\n ")
DLabel:SetFont("BUDGET")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(15, 36)
DLabel:SetSize(250, 100)
DLabel:SetTextColor(Color(114, 137, 218))
DLabel:SetText("Discord --->")
DLabel:SetFont("BUDGET")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(90, 36)
DLabel:SetSize(250, 100)
DLabel:SetTextColor(Color(255, 0, 0))
DLabel:SetText("Rhem#3060")
DLabel:SetFont("BUDGET")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(15, 100)
DLabel:SetSize(250, 100)
DLabel:SetText("You can also join the propkill Discord\nwhich regroup a lot of Propkillers :")
DLabel:SetFont("BUDGET")
local DLabel = vgui.Create("DLabel", panel4)
DLabel:SetPos(15, 135)
DLabel:SetSize(250, 100)
DLabel:SetTextColor(Color(114, 137, 218))
DLabel:SetText("https://discord.gg/w4RbEftrv8\nClick to copy")
DLabel:SetFont("BUDGET")
DLabel:SetMouseInputEnabled(true)

function DLabel:DoClick()
    SetClipboardText("https://discord.gg/w4RbEftrv8")
end



local panel5 = vgui.Create("DPanel", sheet)

panel5.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
end


sheet:AddSheet(" Console ", panel5, "icon16/application_xp_terminal.png")


Addcolormixer(10,30,220,110,"consolebg_a" , "consolebg_r" , "consolebg_g" , "consolebg_b" , panel5)
Addcolormixer(10,200,220,110,"on_a" , "on_r" , "on_g" , "on_b" , panel5)
Addcolormixer(10,375,220,110,"joiner_a" , "joiner_r" , "joiner_g" , "joiner_b" , panel5)
Addcolormixer(240,375,220,110,"leaver_a" , "leaver_r" , "leaver_g" , "leaver_b" , panel5)
Addcolormixer(240,200,220,110,"off_a" , "off_r" , "off_g" , "off_b" , panel5)
Addcolormixer(240,30,220,110,"other_a" , "other_r" , "other_g" , "other_b" , panel5)
Addlabel("Background colors" ,105 , 13 , panel5 )

Addlabel("Leavers colors" ,345 , 355 , panel5 )

Addlabel("Joiners colors" ,105, 355 , panel5 )

Addlabel("Convar to 1 color" ,100 ,185 , panel5 )

Addlabel("Convar to 0 color" ,340 , 185 , panel5 )

Addlabel("Others colors" ,340 , 13 , panel5 )

Addbutton2(60,495,50,30,"consolejoiner" , "Enable" , panel5)

Addbutton2(60,145,50,30,"M_console" , "Console" , panel5)
Addbutton2(280,315,50,30,"console01" , "Enable" , panel5)
Addbutton2(280,145,50,30,"consoleother" , "Enable" , panel5)
Addbutton2(280,495,50,30,"consoleleaver" , "Enable" , panel5)

local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Exemple")
DermaButton:SetPos(340, 495)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()
	debug_tbl[#debug_tbl + 1] = {"Rhem has left the server.", Color(GetConVarNumber("leaver_r"),GetConVarNumber("leaver_g"),GetConVarNumber("leaver_b"),GetConVarNumber("leaver_a"))}
end

local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Exemple")
DermaButton:SetPos(340, 315)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()
	debug_tbl[#debug_tbl + 1] = {"Convar has changed to 0.", Color(GetConVarNumber("off_r"),GetConVarNumber("off_g"),GetConVarNumber("off_b"),GetConVarNumber("off_a"))}
end

local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Exemple")
DermaButton:SetPos(340, 145)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()
	debug_tbl[#debug_tbl + 1] = {"Blund has mutated to models/debug/cum .", Color(GetConVarNumber("other_r"),GetConVarNumber("other_g"),GetConVarNumber("other_b"),GetConVarNumber("other_a"))}
end

local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Exemple")
DermaButton:SetPos(90, 315)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()
	debug_tbl[#debug_tbl + 1] = {"Convar has changed to 1.", Color(GetConVarNumber("on_r"),GetConVarNumber("on_g"),GetConVarNumber("on_b"),GetConVarNumber("on_a"))}
end


local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Test all")
DermaButton:SetPos(120, 145)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()

debug_tbl[#debug_tbl + 1] = {"Convar has changed to 1.", Color(GetConVarNumber("on_r"),GetConVarNumber("on_g"),GetConVarNumber("on_b"),GetConVarNumber("on_a"))}
debug_tbl[#debug_tbl + 1] = {"Rhem has joined.", Color(GetConVarNumber("joiner_r"),GetConVarNumber("joiner_g"),GetConVarNumber("joiner_b"),GetConVarNumber("joiner_a"))}
debug_tbl[#debug_tbl + 1] = {"Blund has mutated to models/debug/cum .", Color(GetConVarNumber("other_r"),GetConVarNumber("other_g"),GetConVarNumber("other_b"),GetConVarNumber("other_a"))}
debug_tbl[#debug_tbl + 1] = {"Convar has changed to 0.", Color(GetConVarNumber("off_r"),GetConVarNumber("off_g"),GetConVarNumber("off_b"),GetConVarNumber("off_a"))}
debug_tbl[#debug_tbl + 1] = {"Rhem has left the server.", Color(GetConVarNumber("leaver_r"),GetConVarNumber("leaver_g"),GetConVarNumber("leaver_b"),GetConVarNumber("leaver_a"))}

end


local DermaButton = vgui.Create("DButton", panel5)
DermaButton:SetText("Exemple")
DermaButton:SetPos(120, 495)
DermaButton:SetSize(50, 30)
DermaButton.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"), self:GetAlpha()))
end

function DermaButton.DoClick()
	debug_tbl[#debug_tbl + 1] = {"Rhem has joined.", Color(GetConVarNumber("joiner_r"),GetConVarNumber("joiner_g"),GetConVarNumber("joiner_b"),GetConVarNumber("joiner_a"))}
end



local panel6 = vgui.Create("DPanel", sheet)

panel6.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, self:GetAlpha()))
end
sheet:AddSheet(" Info ", panel6, "icon16/information.png")

--Surface part

hook.Add("HUDPaint", "Everythings", function()
   GetHostName()
	if GetConVarNumber("M_console") == 0 then
		spacex = 0
		spacey = 0
	else
		spacex = 370
		spacey = 0
	end
	
	draw.SimpleTextOutlined("FPS  : ", "BUDGET", 8+spacex, 5+spacey, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined(math.Round(1 / FrameTime()), "BUDGET", 49+spacex, 5+spacey, Color(GetConVarNumber("menu_r"), GetConVarNumber("menu_g"), GetConVarNumber("menu_b")), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined("ServerName  : ", "BUDGET", 8+spacex, 25+spacey, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined(GetHostName(), "BUDGET", 99+spacex, 25+spacey, Color(GetConVarNumber("menu_r"), GetConVarNumber("menu_g"), GetConVarNumber("menu_b")), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined("Tickrate : ", "BUDGET", 8+spacex, 45+spacey, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined(math.Round(1 / engine.TickInterval()), "BUDGET", 70+spacex, 45+spacey, Color(GetConVarNumber("menu_r"), GetConVarNumber("menu_g"), GetConVarNumber("menu_b")), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
	draw.SimpleTextOutlined( math.Round(LocalPlayer():GetVelocity():Length(), 0), "BUDGET", ScrW() /2, ScrH() /9+spacey, Color(255,255,255,255), 1, 1, 2, Color(50,50,50,255) )

	if GetConVarNumber("Crosshair1") == 1 then
        if GetConVarNumber("Crosshair2") == 1 then 
            surface.SetDrawColor(HSVToColor(CurTime() * 100 % 360, 1, 1))
            surface.DrawRect(ScrW() / 2 - 18, ScrH() / 2 - 1, 14, 3)
			surface.DrawRect(ScrW() / 2 + 3, ScrH() / 2 - 1, 14, 3)
            surface.DrawRect(ScrW() / 2 - 2, ScrH() / 2 + 5, 3, 9)
        else
			surface.SetDrawColor(GetConVarNumber("cross_r"), GetConVarNumber("cross_g"), GetConVarNumber("cross_b"))
			surface.DrawRect(ScrW() / 2 - 18, ScrH() / 2 - 1, 14, 3)
			surface.DrawRect(ScrW() / 2 + 3, ScrH() / 2 - 1, 14, 3)
			surface.DrawRect(ScrW() / 2 - 2, ScrH() / 2 + 5, 3, 9)
        end
	end
    
	for k,v in pairs(player.GetAll()) do
		if v ~= LocalPlayer() then
			if v:GetPos():Distance(LocalPlayer():GetPos()) < 1000 then
				if v:GetUserGroup() != "user" then
					if v:GetUserGroup() != "vip" then
						draw.SimpleTextOutlined("An admin is Nearby !", "BUDGET", ScrW()/2-80, 15, Color(255, 0,0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
					end
				end
			end
		end
	end
end)

--Surface part end
--Whole Script is here
--chat message part
server = game.GetIPAddress()


    chat.AddText(Color(248, 194, 145), [[Monke Script enabled]])
	debug_tbl[#debug_tbl + 1] = {"Logged as : God of Monke", Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))}
	debug_tbl[#debug_tbl + 1] = {"Logged on : ".. server, Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))}
	debug_tbl[#debug_tbl + 1] = {"Monke Script is Enabled ", Color(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))}
    RunConsoleCommand("r_3dsky", 0)
    RunConsoleCommand("r_waterforcereflectentities", 0)
    RunConsoleCommand("r_teeth", 0)
    RunConsoleCommand("r_shadows", 0)
    RunConsoleCommand("r_ropetranslucent", 0)
    RunConsoleCommand("r_maxmodeldecal", 0)
    RunConsoleCommand("r_maxdlights", 0)
    RunConsoleCommand("r_decals", 0)
    RunConsoleCommand("r_drawmodeldecals", 0)
    RunConsoleCommand("r_drawdetailprops", 0)
    RunConsoleCommand("r_worldlights", 0)
    RunConsoleCommand("r_flashlightrender", 1)
    RunConsoleCommand("cl_forcepreload", 1)
    RunConsoleCommand("r_threaded_renderables", 1)
    RunConsoleCommand("r_threaded_client_shadow_manager", 1)
    RunConsoleCommand("snd_mix_async", 1)
    RunConsoleCommand("cl_ejectbrass", 0)
    RunConsoleCommand("cl_detaildist", 0)
    RunConsoleCommand("cl_show_splashes", 0)
    RunConsoleCommand("gmod_mcore_test", 1)
    RunConsoleCommand("mat_filterlightmaps", 0)
    RunConsoleCommand("mat_queue_mode", -1)
    RunConsoleCommand("r_drawflecks", 0)
    RunConsoleCommand("r_dynamic", 0)
    RunConsoleCommand("cl_threaded_bone_setup", 1)
    RunConsoleCommand("r_WaterDrawReflection", 0)
    RunConsoleCommand("r_WaterDrawRefraction", 0)
    RunConsoleCommand("cl_drawspawneffect", 0)
    RunConsoleCommand("r_eyemove", 0)
    RunConsoleCommand("r_eyes", 0)
    chat.AddText(Color(248, 194, 145), [[Logged as : Allowed player]])
    chat.AddText(Color(248, 194, 145), [[Script loaded !]])
    chat.AddText(Color(248, 194, 145), [[Have fun]])
    chat.AddText(Color(248, 194, 145), [[Logged on :]] .. server)


sound.PlayURL("https://cdn.discordapp.com/attachments/827960891966357556/829679617245052948/monkey-sound-effect.mp3", "noblock", function(s) end)

local friends = {
    ["STEAM_0:0:500248002"] = "Lounis"
}

--Spec menu part by NAYYYYYYYYYYYYYL

//fov
local function ffov( ply, pos, ang, fov )
local view = {}
	if GetConVarNumber("fov_enable") == 1 then
		if (!IsValid( ply ) ) then return end
		view.fov = GetConVar( "myfov" ):GetInt()
		view.fov =  math.Clamp(GetConVar( "myfov" ):GetInt(), GetConVar( "myfov" ):GetInt(), 200 )
		return view
	end
end
hook.Add("CalcView", "fov", ffov )

--end of the NAYYYYYYYYYYYL'part

hook.Add("Think", "ChatSpam", function()
    if GetConVarNumber("M_chatspam") == 1 then
        RunConsoleCommand("say", Chosenspammessage)
    end

    if GetConVarNumber("M_psayspam") == 1 then
        RunConsoleCommand("ulx" , "psay" , person , Chosenspammessage2)
    end
end)




hook.Add( "CalcView", "MyCalcView", function( ply, pos, angles, fov )
    if GetConVarNumber("Third") == 1 then
	RunConsoleCommand("fov_enable" , 0 )
        local view = {
            origin = pos - ( angles:Forward() * 100 ),
            angles = angles,
            fov = fov,
            drawviewer = true
        }
        return view
		
    else
        /*local view = {
            origin = pos,
            drawviewer = false
        }*/
        return nil
		
    end
end )


MsgC(Color(248, 194, 145), ([[
        
    
    
    
    
    
    
    
    Monke Script]]))
MsgC(Color(255, 255, 255), ([[(]]))
MsgC(Color(255, 0, 0), ([[Sucessfully Loaded]]))
MsgC(Color(255, 255, 255), ([[)
    ]]))
-- Convar



--optimisation part
RunConsoleCommand("cl_updaterate", 200)
RunConsoleCommand("cl_cmdrate", 0)
RunConsoleCommand("cl_interp", 0)
RunConsoleCommand("cl_interp_ratio", 1)
RunConsoleCommand("rate", 1048576)

--end of the optimisation part
local mat = CreateMaterial("White9", "UnlitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$nocull"] = 1,
    ["$model"] = 1
})


--Flash Light Spamming
hook.Add("Think", "flash", function()
        if GetConVarNumber("M_Flash") == 1 then
            RunConsoleCommand("impulse", "100")
        end
end)



local function xray()
    if GetConVarNumber("M_xray") == 1 then
        for k, v in pairs(ents.FindByClass("prop_physics")) do
            if IsValid(v) then
                cam.Start3D()
                v:SetColor(Color(0, 0, 0, 0))
                cam.IgnoreZ(true)
                render.SuppressEngineLighting(true)
				
				if GetConVarNumber("xray1") == 1 and GetConVarNumber("xray2") == 1 then
				RunConsoleCommand("M_xray" , 1 )
					if v:GetPos():Distance(LocalPlayer():GetPos()) < 2000 then
						render.SetColorModulation(GetConVarNumber("xray_r")/255,GetConVarNumber("xray_g")/255,GetConVarNumber("xray_b")/255 , GetConVarNumber("xray_a")/255)
					else
						render.SetColorModulation(GetConVarNumber("xray2_r")/255,GetConVarNumber("xray2_g")/255,GetConVarNumber("xray2_b")/255 , GetConVarNumber("xray2_b")/255 )
					end
				end
				
				if GetConVarNumber("xray1") == 0 and GetConVarNumber("xray2") == 0 then
					RunConsoleCommand("M_xray" , "0")
				end
				
				if GetConVarNumber("xray1") == 1 and GetConVarNumber("xray2") == 0 then
				RunConsoleCommand("M_xray" , 1 )
						render.SetColorModulation(GetConVarNumber("xray_r")/255,GetConVarNumber("xray_g")/255,GetConVarNumber("xray_b")/255 )
				end
				
				if GetConVarNumber("xray1") == 0 and GetConVarNumber("xray2") == 1 then
						RunConsoleCommand("M_xray" , 1 )
						render.SetColorModulation(GetConVarNumber("xray2_r")/255,GetConVarNumber("xray2_g")/255,GetConVarNumber("xray2_b")/255 )
				end
				
                render.MaterialOverride(Material(GetConVarString("M_xraymat1")))
                v:SetRenderMode(RENDERMODE_TRANSALPHA)
                render.SetBlend(0.4)
                render.SuppressEngineLighting(false)

                if GetConVarNumber("M_box") == 1 then
                        if GetConVarNumber("box1") == 1 then
                            propboxcolor = Color(GetConVarNumber("box_r"), GetConVarNumber("box_g"), GetConVarNumber("box_b") , GetConVarNumber("box_a"))
                        else
                            propboxcolor = Color(0,0,0,0)
                        end

                        if GetConVarNumber("box2") == 1 then
                            propboxcolor2 = Color(GetConVarNumber("box2_r"), GetConVarNumber("box2_g"), GetConVarNumber("box2_b") , GetConVarNumber("box2_a"))
                        else
                            propboxcolor2 = Color(0,0,0,0)
                        end
                end

                if GetConVarNumber("M_box") == 1 then
                    render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.10, -0.10, -0.10), v:OBBMins() + Vector(-0.10, -0.10, -0.10), propboxcolor)
                    render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.65, -0.65, -0.65), v:OBBMins() + Vector(-0.65, -0.65, -0.65), propboxcolor2)
                end
				
                v:DrawModel()
				
				if GetConVarNumber("M_2tracer") == 1 then
						if GetConVarNumber("2tracer1") == 1 and GetConVarNumber("2tracer2") == 1 then
							RunConsoleCommand("M_2tracer" , 1 )
						if v:GetPos():Distance(LocalPlayer():GetPos()) < 2000 then
							tracercolor2 = Color(GetConVarNumber("2tracer1_r"),GetConVarNumber("2tracer1_g"),GetConVarNumber("2tracer1_b"))
						else
							tracercolor2 = Color(GetConVarNumber("2tracer2_r"),GetConVarNumber("2tracer2_g"),GetConVarNumber("2tracer2_b"))
						end
						end
					
							if GetConVarNumber("2tracer1") == 0 and GetConVarNumber("2tracer2") == 0 then
								RunConsoleCommand("M_2tracer" , "0")
							end
							
							if GetConVarNumber("2tracer1") == 1 and GetConVarNumber("2tracer2") == 0 then
							RunConsoleCommand("M_2tracer" , 1 )
									tracercolor2 = Color(GetConVarNumber("2tracer1_r"),GetConVarNumber("2tracer1_g"),GetConVarNumber("2tracer1_b") )
							end
							
						if GetConVarNumber("2tracer1") == 0 and GetConVarNumber("2tracer2") == 1 then
								RunConsoleCommand("M_2tracer" , 1 )
								tracercolor2 = Color(GetConVarNumber("2tracer2_r"),GetConVarNumber("2tracer2_g"),GetConVarNumber("2tracer2_b"))
						end
                    
						
                    render.SetMaterial(Material(GetConVarString("M_2tracermat1")))
                        cam.IgnoreZ(true)
                        render.DrawBeam(v:GetPos() + Angle():Up() * 0, LocalPlayer():GetPos() + EyeAngles():Up() * 0 + EyeAngles():Forward() * 60, GetConVarNumber("tracerwidth2"), 1, 1, tracercolor2)
                end
						
					
                if GetConVarNumber("M_xray") == 0 then
                    cam.IgnoreZ(false)
                    render.MaterialOverride(nil)
                    v:DrawModel()
                end

                cam.End3D()
            end
        end
    end
end






if GetConVarNumber("M_xray") == 0 then
    render.MaterialOverride(nil)
end

hook.Add("PreDrawEffects", "xray", xray)
hook.Add("PostDraw2DSkyBox", "removeSkybox1", function()
    if GetConVarNumber("M_sky") == 1 then
    render.Clear(GetConVarNumber("sky_r"), GetConVarNumber("sky_g"), GetConVarNumber("sky_b") , 255)
    end
    return true
end)

local function chams()
    if GetConVarNumber("M_chams") == 1 then
        for k, v in pairs(player.GetAll()) do
            if v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR then
                if v:Health() > 0 then
					if GetConVarNumber("akarnia") == 1 then
						cam.IgnoreZ(false)
					else
						cam.IgnoreZ(true)
					end
                    render.SuppressEngineLighting(true)
                    v:SetRenderMode(RENDERMODE_TRANSALPHA)
                    render.SetBlend(1)
                    render.MaterialOverride(Material(GetConVarString("M_chamsmat1")))
                    render.SuppressEngineLighting(false)
					if GetConVarNumber("teamcolor") == 1 then
						render.SetColorModulation(team.GetColor(v:Team()).r/255,team.GetColor(v:Team()).g/255,team.GetColor(v:Team()).b/255 )
					else
                    if GetConVarNumber("chams1") == 1 and GetConVarNumber("chams2") == 1 then
				RunConsoleCommand("M_chams" , 1 )
					if v:GetPos():Distance(LocalPlayer():GetPos()) < 2000 then
						render.SetColorModulation(GetConVarNumber("chams1_r")/255,GetConVarNumber("chams1_g")/255,GetConVarNumber("chams1_b")/255 )
					else
						render.SetColorModulation(GetConVarNumber("chams2_r")/255,GetConVarNumber("chams2_g")/255,GetConVarNumber("chams2_b")/255 )
					end
				end
				
				if GetConVarNumber("chams1") == 0 and GetConVarNumber("chams2") == 0 then
					RunConsoleCommand("M_chams" , "0")
				end
				
				if GetConVarNumber("chams1") == 1 and GetConVarNumber("chams2") == 0 then
				RunConsoleCommand("M_chams" , 1 )
						render.SetColorModulation(GetConVarNumber("chams1_r")/255,GetConVarNumber("chams1_g")/255,GetConVarNumber("chams1_b")/255 )
				end
				
				if GetConVarNumber("chams1") == 0 and GetConVarNumber("chams2") == 1 then
						RunConsoleCommand("M_chams" , 1 )
						render.SetColorModulation(GetConVarNumber("chams2_r")/255,GetConVarNumber("chams2_g")/255,GetConVarNumber("chams2_b")/255 )
				end
				end
				cam.IgnoreZ(false)
					if GetConVarNumber("teamcolor") == 1 then
						if GetConVarNumber("M_3dbox") == 1 then
								render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25), v:OBBMins() + Vector(-0.25, -0.25, -0.25), Color(255,255,255))
								render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-1, -1, -1), v:OBBMins() + Vector(-1, -1, -1), team.GetColor(v:Team()))
						end
					else
						if GetConVarNumber("M_3dbox") == 1 then
								render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-0.25, -0.25, -0.25), v:OBBMins() + Vector(-0.25, -0.25, -0.25), Color(30,30,30))
								render.DrawWireframeBox(v:GetPos(), v:GetAngles(), v:OBBMaxs() - Vector(-1, -1, -1), v:OBBMins() + Vector(-1, -1, -1), Color(255,255,255))
						end
					end
				
				if IsSpawning(v) then
					render.SetColorModulation(1 , 0.4,0)
				end
				
				if IsCloaked(v) then
					render.SetColorModulation(0,0,1)
				end
                    v:DrawModel()
                    render.MaterialOverride(Material("models/wireframe"))
					if GetConVarNumber("M_wire") == 1 then
						if GetConVarNumber("wire1") == 1 and GetConVarNumber("wire2") == 1 then
							RunConsoleCommand("M_wire" , 1 )
						if v:GetPos():Distance(LocalPlayer():GetPos()) < 2000 then
							render.SetColorModulation(GetConVarNumber("wire1_r")/255,GetConVarNumber("wire1_g")/255,GetConVarNumber("wire1_b")/255 )
						else
							render.SetColorModulation(GetConVarNumber("wire2_r")/255,GetConVarNumber("wire2_g")/255,GetConVarNumber("wire2_b")/255 )
						end
					end
					
					if GetConVarNumber("wire1") == 0 and GetConVarNumber("wire2") == 0 then
						RunConsoleCommand("M_wire" , "0")
					end
					
					if GetConVarNumber("wire1") == 1 and GetConVarNumber("wire2") == 0 then
					RunConsoleCommand("M_wire" , 1 )
							render.SetColorModulation(GetConVarNumber("wire1_r")/255,GetConVarNumber("wire1_g")/255,GetConVarNumber("wire1_b")/255 )
					end
					
					if GetConVarNumber("wire1") == 0 and GetConVarNumber("wire2") == 1 then
							RunConsoleCommand("M_wire" , 1 )
							render.SetColorModulation(GetConVarNumber("wire2_r")/255,GetConVarNumber("wire2_g")/255,GetConVarNumber("wire2_b")/255 )
					end
                    if IsSpawning(v) then
					render.SetColorModulation(1 , 0.4,0)
				end
                    v:DrawModel()
					end
                end
            end
        end
    end
end
hook.Add("PreDrawEffects", "RChams", chams)

--Chams
local function rchams()

		if GetConVarNumber("akarnia") == 1 then
			for k, v in pairs(player.GetAll()) do
				if v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR then
					if v:Health() > 0 then
						if v:Alive() then   
							cam.IgnoreZ(true)
							render.SuppressEngineLighting(true)
							v:SetRenderMode(RENDERMODE_TRANSALPHA)
							render.SetBlend(0.9)
							render.MaterialOverride(Material("models/debug/debugwhite"))
							render.SuppressEngineLighting(false)
							render.SetColorModulation(0,1,0)
							v:DrawModel()
							
						end 
					end
				end
			end
		end

end

hook.Add("PreDrawEffects", "Chams", rchams)

local Combobox = vgui.Create ("DComboBox", panel22)
		Combobox:SetValue(GetConVarString("M_chamsmat1"))
		Combobox:SetPos(10,145)
        Combobox:SetSize(50 ,15)
		Combobox:SizeToContents()
		Combobox:AddChoice("models/debug/debugwhite")
		Combobox:AddChoice("!White9")
		
		Combobox.OnSelect = function( panel, index, value )
		GetConVar("M_chamsmat1"):SetString( value )
end

local Combobox = vgui.Create ("DComboBox", panel11)
		Combobox:SetValue(GetConVarString("M_xraymat1"))
		Combobox:SetPos(40,145)
        Combobox:SetSize(50 ,15)
		Combobox:SizeToContents()
		Combobox:AddChoice("models/debug/debugwhite")
		Combobox:AddChoice("!White9")
		Combobox.OnSelect = function( panel, index, value )
		GetConVar("M_xraymat1"):SetString( value )
end






local function mtracer()
    if GetConVarNumber("M_tracer") == 1 then
	for k,v in next, player.GetAll() do
        if v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR and LocalPlayer():Health() > 0 and v:Health() > 0 then

			    cam.Start3D()
                    cam.IgnoreZ(true)


					if GetConVarNumber("M_tracer") == 1 then
						if GetConVarNumber("tracer1") == 1 and GetConVarNumber("tracer2") == 1 then
							RunConsoleCommand("M_tracer" , 1 )
						if v:GetPos():Distance(LocalPlayer():GetPos()) < 2000 then
							tracercolor = Color(GetConVarNumber("tracer1_r"),GetConVarNumber("tracer1_g"),GetConVarNumber("tracer1_b"))
						else
							tracercolor = Color(GetConVarNumber("tracer2_r"),GetConVarNumber("tracer2_g"),GetConVarNumber("tracer2_b"))
						end
						end
					
							if GetConVarNumber("tracer1") == 0 and GetConVarNumber("tracer2") == 0 then
								RunConsoleCommand("M_tracer" , "0")
							end
							
							if GetConVarNumber("tracer1") == 1 and GetConVarNumber("tracer2") == 0 then
							RunConsoleCommand("M_tracer" , 1 )
									tracercolor = Color(GetConVarNumber("tracer1_r"),GetConVarNumber("tracer1_g"),GetConVarNumber("tracer1_b") )
							end
							
						if GetConVarNumber("tracer1") == 0 and GetConVarNumber("tracer2") == 1 then
								RunConsoleCommand("M_tracer" , 1 )
								tracercolor = Color(GetConVarNumber("tracer2_r"),GetConVarNumber("tracer2_g"),GetConVarNumber("tracer2_b"))
						end
                    end
					if GetConVarNumber("M_admintracer") == 1 then
						if v:GetUserGroup() != "user" then
								if v:GetUserGroup() != "vip" then
									tracercolor = Color(0,255,144,255)
								end
						end
					end
				render.SetMaterial(Material(GetConVarString("M_tracermat1")))
                render.DrawBeam(LocalPlayer():GetPos() + EyeAngles():Forward() *60, v:GetPos(), GetConVarNumber("tracerwidth"), 1, 1, tracercolor)
				
			
				
						end
            cam.End3D()
                    end
            
	end
end	
hook.Add("RenderScreenspaceEffects", "Tracers", mtracer)


hook.Add("Think", "BHOP", function()

        if GetConVarNumber("M_bhop") == 1 then
            if ismenuopen == 0 then
                if Monkepanel:IsActive() then return end
                if gui.IsConsoleVisible() or LocalPlayer():IsTyping() or gui.IsGameUIVisible() then return end
                
                if input.IsKeyDown(KEY_SPACE) then
                    if LocalPlayer():IsOnGround() then
                        RunConsoleCommand("+jump")
                        jump = 1
                    else
                        RunConsoleCommand("-jump")
                        jump = 0
                    end
                elseif LocalPlayer():IsOnGround() then
                    if jump == 1 then
                        RunConsoleCommand("-jump")
                        jump = 0
                    end
                end
            end
        end
end)

local function Cheats()
    RunConsoleCommand("M_Chams", "1")
    RunConsoleCommand("M_3dbox", "1")
    RunConsoleCommand("M_propbox", "1")
    RunConsoleCommand("M_xray", "1")
end

concommand.Add("CH_enable", Cheats)
hook.Add("PreDrawEffects", "RChams", chams)

local function dCheats()
    RunConsoleCommand("M_Chams", "0")
    RunConsoleCommand("M_3dbox", "0")
    RunConsoleCommand("M_propbox", "0")
    RunConsoleCommand("M_xray", "0")
end

concommand.Add("CH_disable", dCheats)
--rotate
local function rotate()
    if GetConVarNumber("180") == 1 then
    LocalPlayer():SetEyeAngles(Angle(LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().r))
    end
end

concommand.Add("Monke_backflip", rotate)

local function rotateup()
    if GetConVarNumber("180") == 1 then
        LocalPlayer():SetEyeAngles(Angle(-LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y - 180, LocalPlayer():EyeAngles().r))
        RunConsoleCommand("+jump")

        timer.Simple(0.1, function()
            RunConsoleCommand("-jump")
        end)
    end     
end

concommand.Add("Monke_backflipUP", rotateup)

-- esp

local function eesp()
    for k, v in pairs(player.GetAll()) do
        local pos = v:EyePos():ToScreen()
        mattt = v:GetMaterial()
            if v ~= LocalPlayer() and v:Team() ~= TEAM_SPECTATOR then
			if v:GetPos():Distance(LocalPlayer():GetPos()) < 6000 then
            start = v:GetPos():ToScreen();
            endme = v:LocalToWorld(Vector(0, 0, v:OBBMaxs().z)):ToScreen();
            height = start.y - endme.y;
            width = height / 2;
spacerpos1 = 20
-- this time i just put the first esp because it don't need a second and even , it will be useless .
            if GetConVarNumber("M_esp") == 1 then 
				bxcolor = Color(GetConVarNumber("esp1_r"),GetConVarNumber("esp1_g"),GetConVarNumber("esp1_b") , GetConVarNumber("esp1_a"))
			
					if GetConVarNumber("M_dead") == 1 then
						if v:Health() <= 0 then 
							draw.SimpleText("Dead", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(255,0,0,255))
						end
					end
					
					if GetConVarNumber("M_spawning") == 1 then
						if IsSpawning(v) then
							spacerpos1 = spacerpos1+10
							draw.SimpleText("Spawning", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(255,93,0))
						end
					end
					--may not work on server with custom chatbox
					if GetConVarNumber("M_blackm") == 1 then
						if table.HasValue(blackpm,v:GetModel()) then
						spacerpos1 = spacerpos1+10	
							draw.SimpleText("Black guy", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(0,0,0,255))
						end
					end
					
					if GetConVarNumber("M_typing") == 1 then
						if v:IsTyping() then
							spacerpos1 = spacerpos1+10
							draw.SimpleText("Typing", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(127,63,111))
						end
					end
					
					if GetConVarNumber("M_member") == 1 then
					
							if ownertable[v:SteamID()] then
							spacerpos1 = spacerpos1+10
								draw.SimpleText("Owner", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,HSVToColor(CurTime() * 100 % 360, 1, 1))
							
							else 
							spacerpos1 = spacerpos1+10
								draw.SimpleText("Script member", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(255,255,0,255))
							end
					
					end
					
						
					if GetConVarNumber("M_cloak") == 1 then
						if IsCloaked(v) then
						spacerpos1 = spacerpos1+10
							draw.SimpleText("Cloak", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(0,0,255,255))
						end
					end
					
					
					
					if GetConVarNumber("M_usergroup") == 1 then
						if v:GetUserGroup() != "user" then
							if v:GetUserGroup() != "vip" then
								if v:GetUserGroup() != "premium" then
									if v:GetUserGroup() != "Habitue" then
							spacerpos1 = spacerpos1+10
								draw.SimpleText((v:GetUserGroup()), "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,bxcolor)
									end
								end
							end
						end
					end
					
						if GetConVarNumber("M_Distance") == 1 then
					spacerpos1 = spacerpos1+10
                        draw.SimpleText((math.Round(v:GetPos():Distance(LocalPlayer():GetPos()))), "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,bxcolor)
                    end
					
						
					if GetConVarNumber("M_jobs") == 1 then
					spacerpos1 = spacerpos1+10
					job_color = team.GetColor(v:Team())
                        draw.SimpleText((team.GetName(v:Team())), "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,job_color)
                    end
					
					if GetConVarNumber("M_armor") == 1 then
						if v:Armor() != 0 then
						spacerpos1 = spacerpos1+10
						draw.SimpleText(v:Armor().. " Armor", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,Color(0,0,255))
						end
					end
					
					if GetConVarNumber("M_health") == 1 then
						spacerpos1 = spacerpos1+10
						if v:Health() < 50 then 
						hlthcolor = Color(255,93,0)
						else
						hlthcolor = Color(0,255,0)
						end
						draw.SimpleText(v:Health().. " HP", "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,hlthcolor)
					end
					
					if GetConVarNumber("M_nick") == 1 then
						spacerpos1 = spacerpos1+10
						draw.SimpleText(v:Nick(), "BudgetLabel", pos.x-20, pos.y-spacerpos1+10,bxcolor)
					end
				end
			end
        end
    end
end

hook.Add("RenderScreenspaceEffects", "esp", eesp)


	

 


-- brain thanks you nigger .
local function Addcb1(convar)
	cvars.AddChangeCallback(convar, function(convar_name, value_old, value_new)
		if GetConVarNumber("console01") == 1 then
			if tonumber(value_new) == 1 then
				debug_tbl[#debug_tbl + 1] = {convar.. " has changed to 1", Color(GetConVarNumber("on_r"),GetConVarNumber("on_g"),GetConVarNumber("on_b"), GetConVarNumber("on_a"))}
			else
				debug_tbl[#debug_tbl + 1] = {convar.. " has changed to 0", Color(GetConVarNumber("off_r"),GetConVarNumber("off_g"),GetConVarNumber("off_b"), GetConVarNumber("off_a"))}
			end
		end
	end)
end

Addcb1("M_xray")
Addcb1("M_nick")
Addcb1("M_cloak")
Addcb1("M_spawning")
Addcb1("M_usergroup")
Addcb1("M_dead")
Addcb1("M_member")
Addcb1("M_health")
Addcb1("M_armor")
Addcb1("M_typing")
Addcb1("M_autoshoot")
Addcb1("M_Distance")
Addcb1("M_blackm")
Addcb1("rp")
Addcb1("M_jobs")
Addcb1("M_admintracer")
Addcb1("xray1")
Addcb1("xray2")
Addcb1("M_box")
Addcb1("box1")
Addcb1("box2")
Addcb1("M_Flash")
Addcb1("M_bhop")
Addcb1("crosshair1")
Addcb1("M_propbox")
Addcb1("M_3dbox")
Addcb1("Third")
Addcb1("M_Chams")
Addcb1("fov_enable")
Addcb1("Crosshair2")
Addcb1("M_esp")
Addcb1("akarnia")
Addcb1("chams1")
Addcb1("chams2")
Addcb1("wire1")
Addcb1("wire2")
Addcb1("tracer1")
Addcb1("tracer2")
Addcb1("2tracer1")
Addcb1("2tracer2")
Addcb1("M_console")

cvars.AddChangeCallback("M_psayspam", function(convar_name, value_old, value_new)
	if GetConVarNumber("consoleother") == 1 then
		if tonumber(value_new) == 1 then
			debug_tbl[#debug_tbl + 1] = {"Psay spam enabled :", Color(0,255,0)}
			debug_tbl[#debug_tbl + 1] = {Chosenspammessage2.. " to ".. person, Color(255,255,255)}
		else
		debug_tbl[#debug_tbl + 1] = {"Psay spam disabled :", Color(255,0,0)}
		end
	end
end)
	
cvars.AddChangeCallback("M_chatspam", function(convar_name, value_old, value_new)
	if GetConVarNumber("consoleother") == 1 then
		if tonumber(value_new) == 1 then
			debug_tbl[#debug_tbl + 1] = {"Chat spam enabled :", Color(0,255,0)}
			debug_tbl[#debug_tbl + 1] = {Chosenspammessage, Color(255,255,255)}
		else
		debug_tbl[#debug_tbl + 1] = {"Psay spam disabled", Color(255,0,0)}
		end
	end
end)

local function Addcb2(convar)
	cvars.AddChangeCallback(convar, function(convar_name, value_old, value_new)
		if GetConVarNumber("consoleother") == 1 then
			debug_tbl[#debug_tbl + 1] = {convar.. " has changed to ".. GetConVarString(convar), Color(GetConVarNumber("other_r"),GetConVarNumber("other_g"),GetConVarNumber("other_b") ,GetConVarNumber("other_a"))}
		end
	end)
end

Addcb2("sky_r")
Addcb2("sky_g")
Addcb2("sky_b")
Addcb2("cross_r")
Addcb2("cross_g")
Addcb2("cross_b")
Addcb2("menu_r")
Addcb2("menu_g")
Addcb2("menu_b")
Addcb2("xray_a")
Addcb2("xray_r")
Addcb2("xray_g")
Addcb2("xray_b")
Addcb2("xray2_a")
Addcb2("xray2_r")
Addcb2("xray2_g")
Addcb2("xray2_b")
Addcb2("chams1_a")
Addcb2("chams1_r")
Addcb2("chams1_g")
Addcb2("chams1_b")
Addcb2("chams2_a")
Addcb2("chams2_r")
Addcb2("chams2_g")
Addcb2("chams2_b")
Addcb2("esp1_a")
Addcb2("esp1_r")
Addcb2("esp1_g")
Addcb2("esp1_b")
Addcb2("wire1_a")
Addcb2("wire1_r")
Addcb2("wire1_g")
Addcb2("wire1_b")
Addcb2("wire2_a")
Addcb2("wire2_r")
Addcb2("wire2_g")
Addcb2("wire2_b")
Addcb2("tracer1_a")
Addcb2("tracer1_r")
Addcb2("tracer1_g")
Addcb2("tracer1_b")
Addcb2("tracer2_a")
Addcb2("tracer2_r")
Addcb2("tracer2_g")
Addcb2("tracer2_b")
Addcb2("2tracer1_a")
Addcb2("2tracer1_r")
Addcb2("2tracer1_g")
Addcb2("2tracer1_b")
Addcb2("2tracer2_a")
Addcb2("2tracer2_r")
Addcb2("2tracer2_g")
Addcb2("2tracer2_b")
Addcb2("consolebg_a")
Addcb2("consolebg_r")
Addcb2("consolebg_g")
Addcb2("consolebg_b")
Addcb2("box_a")
Addcb2("box_r")
Addcb2("box_g")
Addcb2("box_b")
Addcb2("box2_a")
Addcb2("box2_r")
Addcb2("box2_g")
Addcb2("box2_b")
Addcb2("myfov")
Addcb2("M_chamsmat1")
Addcb2("M_xraymat1")
Addcb2("M_tracermat1")
Addcb2("M_2tracermat1")
Addcb2("tracerwidth")
Addcb2("tracerwidth2")


debug_tbl[#debug_tbl + 1] = {"Welcome on :", Color(200,200,200)}
debug_tbl[#debug_tbl + 1] = {"Monkey_script.lua", HSVToColor(CurTime() * 100 % 360, 1, 1)}
debug_tbl[#debug_tbl + 1] = {"", Color(200,200,200)}
debug_tbl[#debug_tbl + 1] = {"", Color(200,200,200)}
debug_tbl[#debug_tbl + 1] = {"", Color(200,200,200)}
debug_tbl[#debug_tbl + 1] = {"", Color(200,200,200)}


local function drawconsole()
if GetConVarNumber("M_console") == 1 then
	local grogdsgoh = 0
	surface.SetDrawColor(GetConVarNumber("menu_r"),GetConVarNumber("menu_g"),GetConVarNumber("menu_b"))
		surface.DrawOutlinedRect(ScrW()/300 , ScrH()/270 , ScrW()/5.25,((ScrH()/18)/3)*9.1 , 3)
				draw.RoundedBox(2 , ScrW()/250, ScrH()/200, ScrW()/5.32, ((ScrH()/18)/3)*9, Color(GetConVarNumber("consolebg_r"),GetConVarNumber("consolebg_g"),GetConVarNumber("consolebg_b"),GetConVarNumber("consolebg_a") ))

        for k,v in pairs(table.Reverse(debug_tbl)) do
            grogdsgoh = grogdsgoh + 1
            if grogdsgoh < 10 then
				draw.SimpleText( v[1]	, "DermaDefault" , ScrW()/170, ScrH()/16  - ScrH()/18*(k)/3 + ScrH()/9, v[2], TEXT_ALIGN_LEFT )
            else
                break
            end
        end
    end
end



hook.Add("HUDPaint", "chui_lmeilleur", drawconsole) 


--config propkill / freekill
local function propkillconfig()
RunConsoleCommand("xray1" , "1")
RunConsoleCommand("xray2" , "1")
RunConsoleCommand("xray_r" , "255")
RunConsoleCommand("xray_g" , "0")
RunConsoleCommand("xray_b" , "0")
RunConsoleCommand("xray2_r" , "0")
RunConsoleCommand("xray2_g" , "255")
RunConsoleCommand("xray2_b" , "0")
RunConsoleCommand("chams1" , "1")
RunConsoleCommand("chams2" , "1")
RunConsoleCommand("chams1_r" , "255")
RunConsoleCommand("chams1_g" , "0")
RunConsoleCommand("chams1_b" , "0")
RunConsoleCommand("chams2_r" , "0")
RunConsoleCommand("chams2_g" , "255")
RunConsoleCommand("chams2_b" , "0")
RunConsoleCommand("M_bhop" , 1)
RunConsoleCommand("180" , 1)
RunConsoleCommand("180UP" , 1)
RunConsoleCommand("fov_enable" , 1)
end


concommand.Add("propkill_config" , propkillconfig) 



gameevent.Listen( "entity_killed" )
hook.Add( "entity_killed", "entity_killed_example", function( data ) 
	local inflictor_index = data.entindex_inflictor		// Same as Weapon:EntIndex() / weapon used to kill victim
	local attacker_index = data.entindex_attacker		// Same as Player/Entity:EntIndex() / person or entity who did the damage
	local damagebits = data.damagebits			// DAMAGE_TYPE - use BIT operations to decipher damage types...
	local victim_index = data.entindex_killed		// Same as Victim:EntIndex() / the entity / player victim
	if GetConVarNumber("consoleother") == 1 then
	debug_tbl[#debug_tbl + 1] = {Entity(victim_index):Nick().. " is Dead.", Color(255,0,0)}
	end
end )

gameevent.Listen( "player_connect_client" )
hook.Add( "player_connect_client", "player_connect_example", function( data )
	local name = data.name			// Same as Player:Nick()
	local steamid = data.networkid	// Same as Player:SteamID()
	local ip = data.address			// Same as Player:IPAddress()
	local id = data.userid			// Same as Player:UserID()
	local bot = data.bot			// Same as Player:IsBot()
	local index = data.index		// Same as Player:EntIndex()
	if GetConVarNumber("consolejoiner") == 1 then
		debug_tbl[#debug_tbl + 1] = {name.. " has joined.", Color(GetConVarNumber("joiner_r"),GetConVarNumber("joiner_g"),GetConVarNumber("joiner_b"),GetConVarNumber("joiner_a"))}
	end
end )

gameevent.Listen( "player_disconnect" )
hook.Add( "player_disconnect", "player_disconnect_example", function( data )
	local name = data.name			// Same as Player:Nick()
	local steamid = data.networkid		// Same as Player:SteamID()
	local id = data.userid			// Same as Player:UserID()
	local bot = data.bot			// Same as Player:IsBot()
	local reason = data.reason		// Text reason for disconnected such as "Kicked by console!", "Timed out!", etc...
	if GetConVarNumber("consoleleaver") == 1 then
		debug_tbl[#debug_tbl + 1] = {name.." has left the server(".. reason.. ")", Color(GetConVarNumber("leaver_r"),GetConVarNumber("leaver_g"),GetConVarNumber("leaver_b"),GetConVarNumber("leaver_a"))}
	end
end )

end)