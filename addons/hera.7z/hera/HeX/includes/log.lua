HERA_ERROR = Color( 255, 80, 80 )
HERA_WARNING = Color( 255, 255, 80 )
HERA_DEBUG = Color( 80, 255, 80 )
HERA_INFO = Color( 0, 184, 245 )

local function GetSev( sev )
	if sev > 4 or sev < 1 then hera.Notify( HERA_ERROR, "Attempted to authenticate erroneous severity" ) end
	if sev == 1 then
		return "Info"
	elseif sev == 2 then
		return "Debug"
	elseif sev == 3 then
		return "Warning"
	else
		return "Error"
	end
end

function hera.Log( typ, sev, str, ... )
	if sev > 4 or sev < 1 or not sev then
		hera.Notify( HERA_ERROR, "Attempted to log erroneous severity" )
	end
	if not str then
		hera.Notify( HERA_ERROR, "Attempted to log erroneous string" )
	end	
	if not typ then
		hera.Notify( HERA_ERROR, "Attempted to log erroneous type" )
	end
	if sev == 1 then
		hera.Notify( HERA_INFO, string.format( str, ... ) )
	elseif sev == 2 then
		hera.Notify( HERA_DEBUG, string.format( str, ... ) )
	elseif sev == 3 then
		hera.Notify( HERA_WARNING, string.format( str, ... ) )
	else
		hera.Notify( HERA_ERROR, string.format( str, ... ) )
	end
	hera.WriteLog( typ, Format( "[%s:%s:%s] [%s] %s\n", os.date( "%I" ), os.date( "%M" ), os.date( "%S" ), GetSev( sev ), string.format( str, ... ) ) )
end

hera.Log( "Initialization", 1, "Loaded Console interface" )