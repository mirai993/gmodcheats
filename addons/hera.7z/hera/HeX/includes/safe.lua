local _safeTables = {}
hera.Safe = {}
hera.Safe.Rawset = rawset
hera.Safe.Rawget = rawget
hera.Safe.SetMetaTable = setmetatable
hera.Safe.GetConVar = GetConVar
hera.Safe.File = {}
hera.Safe.File.Write = file.Write
hera.Safe.File.Read = file.Read
hera.Safe.File.Exists = file.Exists
hera.Safe.File.ExistsEx = file.ExistsEx
hera.Safe.File.IsDir = file.IsDir
hera.Safe.File.Size = file.Size
hera.Safe.File.Find = file.Find
hera.Safe.File.FindDir = file.FindDir
hera.MT = {}
local __safeTables = {
	"hera",
	"luamd5"
}
local _SafeVars = {
	{ V = "sv_cheats", v = "0" },
	{ V = "host_timescale", v = "1"},
	{ V = "host_framerate", v = "0"},
	{ V = "sv_scriptenforcer", v = "1"},
	{ V = "lua_md5", v = "Unknown" }
}
local _SafeMeta = {
	"[GS]etViewAngles",
	"[GS]etButtons",
	"GetAimVector",
	"EyeAngles",
	"GetPos",
	"GetShootPos"
}

local function Safetize( tbl, name )
	tbl.__Name = name
	_safeTables[ name ] = table.Copy( tbl )
	
	for k, v in pairs( tbl ) do
		print( k )
		
		tbl[k] = nil
	end
	
	hera.Safe.SetMetaTable( tbl, {
		__index = function( t, k )
			return _safeTables[ name ][ k ]
		end,
		__newindex = function( t, k, v )
			print( t, k, v, _safeTables[ t.__Name ][ k ] )
			if _safeTables[ t.__Name ][ k ] ~= nil then
				hera.Log( 3, Format( "Blocked attempt to overwrite %s in %s!", k, t.__Name ) )
				return false
			end
			_safeTables[ t.__Name ][ k ] = v
		end,
		__metatable = true
	} )
end

-- Safetize( hera, "hera" ) -- Seems to block access to the table

local function IsSafe( f )
	for k, v in pairs( _safeTables ) do
		if f:lower():find( v ) then
			hera.Log( 3, Format( "Blocked file access attempt: %s", f ) )
			return false
		end
	end
	return true
end

local function IsMetaSafe( var )
	for k,v in pairs( _SafeMeta ) do
		if var:find( v ) then
			return true
		end
	end
	return false
end

local function CopyMeta( var )
	local tbl = _R[var]
	local _mt = {}
	for k,v in pairs( tbl ) do
		_mt[ k ] = v
	end
	_mt.__index = _mt
	hera.MT[ var ] = _mt
	for k,v in pairs( _R[var] ) do
		if IsSafe( k ) then
			_R[var][k] = nil
		end
	end
	setmetatable( _R[var], {
		__index = function( t, k )
			return hera.MT[ var ][ k ]
		end,
		__newindex = function( t, k, v )
			if IsSafe( k ) then
				print( k )
				return
			end
			return rawset( t, k, v )
		end,
		__metatable = {}
	} )
end

/*
	CopyMeta( "CUserCmd" )
	CopyMeta( "Entity" )
	CopyMeta( "Player" )
	CopyMeta( "Weapon" )
	CopyMeta( "NPC" )
*/

function GetConVar( var )
	for k, v in pairs( _SafeVars ) do
		if var:lower() == v.V then
			hera.Log( 3, Format( "Blocked attempt to get ConVar %s returned value %s", var, v.v ) )
			return v.v
		end
	end
	return hera.Safe.GetConVar( var )
end

function rawget( t, k )
	return hera.Safe.rawget( t, k )
end

function rawset( t, k, v )
	if IsSafe( t ) then
		hera.Log( 3, Format( "Blocked attempt to overwrite %s in table %s!", k, t.__Name ) )
		return false
	end
	return hera.Safe.Rawset( t, k, v )
end

function file.Exists( f )
	return IsSafe( f ) and hera.Safe.File.Exists( f ) or false
end

function file.ExistsEx( f, a )
	return IsSafe( f ) and hera.Safe.File.ExistsEx( f, a ) or false
end

function file.IsDir( f )
	return IsSafe( f ) and hera.Safe.File.IsDir( f ) or false
end

function file.Find( f )
	if f:lower():find( "hera" ) or f:lower():find( "luamd5" ) then return {} end
	local l = hera.Safe.File.Find( f )
	for k, v in pairs( l ) do
		if v:lower():find( "hera" ) then
			hera.Log( 3, Format( "Blocked file.Find attempt: %s[%s]", l, k ) )
			table.remove( l, k )
		end
	end
	return l
end

function file.FindDir( f )
	if f:lower():find( "hera" ) or f:lower():find( "luamd5" ) then return {} end
	local l = hera.Safe.File.FindDir( f )
	for k, v in pairs( l ) do
		if v:lower():find( "hera" ) then
			hera.Log( 3, Format( "Blocked file.FindDir attempt: %s[%s]", l, k ) )
			table.remove( l, k )
		end
	end
	return l
end

function file.Read( f )
	if not IsSafe( f ) then
		return ""
	end
	return hera.Safe.File.Read( f )
end

function file.Write( f, w )
	if not IsSafe( f ) then return end
	return hera.Safe.File.Write( f, w )
end
--[[
function setmetatable( obj, tab )
	if unpack( tab ):lower():find( "hera" ) then
		return
	end
	return hera.SetMetaTable
end
--]]
hera.Log( "Initialization", 1, "Loaded Safe interface" )