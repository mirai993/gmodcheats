require "luamd5"

if not ConVarExists( "hera_md5" ) then
	CreateConVar( "hera_md5", "Undefined" )

	hera.Hook.Add( "UpdateLuaMD5", "[Hera]LuaMD5", function()
		local new = GetConVar( "hera_md5" ):GetString()
			
		return ( ( new != "" ) && new || nil )
	end )
	hera.Log( 1, "Safe", "Set Lua MD5 to %s", GetConVar( "hera_md5" ):GetString() )
end