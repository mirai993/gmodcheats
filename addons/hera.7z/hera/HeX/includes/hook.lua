hera.Hook = {}
hera.Hook.Call = hook.Call

require "hook"

local oldCall = hook.Call
function hook.Call( name, gm, ... )
	local newRet = { hera.Hook.Call( name, gm, ... ) }
	if newRet[1] ~= nil then
		return unpack( newRet )
	end
	return oldCall( name, gm, ... )
end

local _hooks = {}

function hera.Hook.Add( id, name, func )
	_hooks[id] = _hooks[id] or {}
	_hooks[id][name] = func
end

function hera.Hook.Remove( id, name )
	(_hooks[id] or {})[name] = nil
end

function hera.Hook.Call( id, gm, ... )
	local b, ret
	local HookTable = _hooks[id]
	
	if ( HookTable != nil ) then
		for k, v in pairs( HookTable ) do
			if ( v == nil ) then
				ErrorNoHalt("Hook '"..tostring(k).."' tried to call a nil function!\n")
				HookTable[ k ] = nil // remove this hook
				break;
			else
				// Call hook function
				ret = { pcall( v, gm, ... ) }
				b = ret[1]
				table.remove( ret, 1 )

				if (!b) then
					ErrorNoHalt( "Hook '" .. tostring(k) .. "' Failed: " .. tostring(ret[1]) .. "\n" )
					HookTable[ k ] = nil // remove this hook
				else
					// Allow hooks to override return values
					if (ret[1] != nil) then
						return unpack( ret )
					end
				end
			end
		end
	end

	return unpack( ret or {} )
end
hera.Log( "Initialization", 1, "Loaded Hook interface" )