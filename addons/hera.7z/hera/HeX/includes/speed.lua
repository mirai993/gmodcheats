concommand.Add( "+hera_speed", function( p, c, a )
	hera.SetConVar( "sv_cheats", "1" )
	hera.SetConVar( "host_timescale", "7" )
end )

concommand.Add( "-hera_speed", function( p, c, a )
	hera.SetConVar( "sv_cheats", "0" )
	hera.SetConVar( "host_timescale", "1" )
end )

hera.Log( "Initialization", 1, "Loaded Speed hack interface" )