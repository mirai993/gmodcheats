--[[

-================================-


Hera v4 - A Garry's Mod aimbot [Multi-Hack]


-================================-

]]--


/************************************
Name: Localizing
Purpose: Make the cheat run faster
************************************/

local g 					= table.Copy(_G)

local Hera					= {} -- Nothing!
Hera.settings				= {} -- Not started yet.
Hera.hooks					= {} -- Store hooks in a table
Hera.concommands			= {} -- Store concommands in a table
Hera.convars				= {} -- Store the ConVars in a table
Hera.timers					= {} -- Store Timers in a table
Hera.cones					= { normal = {}, hl2 = {}, custom = {}} -- I probably won't even need this, I won't have NoSpread for a long time. Anyways, store cones here.
Hera.files					= {"Hera.lua","Log.txt"} -- Files to hide and protect
Hera.version				= "4.1" -- Version of the cheat.
Hera.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
}
Hera.dontlog				= { -- commands to be ignored by the runconsolecommand logger
"+jump",
"-jump", 
"+attack", 
"-attack", 
"impulse"
} 
Hera.badcmds				= { -- commands to be blocked
"__ac",
"__imacheater",
"gm_possess",
"achievementRefresh", -- fuck u lifepunch
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil",
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"-voicerecord",
"+voicerecord",
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
}
Hera.invalidents			= {"player","prop_physics","viewmodel",} -- Ents to not show on the ESP
Hera.weapons				= {["weapon_crossbow"] = 3110,}
Hera.spectators				= {} -- Store spectators here.
Hera.admins					= {} -- store admins here
Hera.config					= {} -- user config

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);

local _G					= table.Copy(_G)

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [detour]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;

--Fonts--
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Hera_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("Hera_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("Hera_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})


g.rawset(_G, "RunConsoleCommand", oRunConsoleCommand) 

--Materials--
function Hera:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("Hera_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "hera_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("Hera_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "hera_wire", "Wireframe", BaseInfo )
end
   return mat
end

/**************************************
Name: Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("Hera_StartLog",function()
file.Write("Hera/log.txt","Log created: ("..os.date()..") \n")
end)

function Log(msg)
file.Append("Hera/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function Hera.Print(msg)
	print("[Hera] "..msg)
end

function Hera.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
iceblue, "[Hera] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Addhook
local function AddHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	Hera.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	return old_hookadd(Type,Name,Function)
end

-- RemoveHook
local function RemoveHook(Type,Function)
	Hera.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

/**********************************
Name: File Shit
Purpose: Anything relating to file.
***********************************/
-- Write file
function AddFile(Name,Data)
	Hera.Print("[WROTE] File: "..Name.."")
	return old_filewrite(Name,Data)
end

/**************
Random String
**************/
function RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function AddTimer( sec, rep, func )
	local index = RandomString( 10 )	
	Hera.timers[ index ] = sec	
	timer.Create( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function AddCMD(Name,Function)
	Hera.Print("[ADDED] ConCommand: "..Name.."")
	return old_ccadd(Name,Function)
end

function RemoveCMD(Name)
	Hera.Print("[REMOVED] ConCommand: "..Name.."")
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

-- AddConVar
function AddConVar(convar,str,save,data)
	return CreateClientConVar("Hera_"..convar,str,true,false), Hera.Print("[ADDED] ConVar: Hera_"..convar.." ["..str.."]")
end

/***************************************
Name: RunConsoleCommand shit
Purpose: Detours, Loggers, blockers
****************************************/

function RunConsoleCommand(cmd,...)
	if !table.HasValue(Hera.dontlog, cmd) then
		Hera.Print("RunConsoleCommand: "..cmd)
		Log("RunConsoleCommand: "..cmd)
	end
	if !table.HasValue(Hera.badcmds,cmd) then 
		return old_rcc(cmd,...)
	else
		Hera.Notify(sound,red,"Blocked command: "..cmd)
		Log("BLOCKED COMMAND: "..cmd)
		return
	end
end

/**************************************
Name: Entity Shit
Purpose: Anything to do with entities
***************************************/
-- entity finder [addent]
function AddEnt(entclass)
	if(!table.HasValue(Hera.ents,entclass)) then
		table.insert(Hera.ents,entclass)
		Hera.Print("[ADDED] Ent: "..entclass.." to ESP")
		file.Write("Hera/ents.txt", glon.encode( Hera.ents ))
	end
end

-- entity finder [removeent]
function RemoveEnt(entclass)
	for k, v in pairs(Hera.ents) do
		if(string.Trim(v) == entclass) then
			Hera.ents[k] = nil
			Hera.Print("[REMOVED] Ent: "..entclass.." from the ESP")
		end
	end
	file.Write("Hera/ents.txt", glon.encode( Hera.ents ))
end

-- entity finder [clear ents]
function ClearEnts()
	Hera.ents = {}
	file.Write("Hera/ents.txt", glon.encode( Hera.ents ))
end

-- entity finder [IsCustomEnt()]
function IsCustomEnt( entclass )
	return table.HasValue( Hera.ents, entclass )
end


/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) Hera.Notify(red,"Error in the Lua script!") end
function Error(...) Hera.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) Hera.Notify(red,"Error in the Lua script!") end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end


/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = {}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
        return true
    else
        return false
    end    
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end


/**************************************
Name: Number shit
Purpose: Format number, round number, etc
**************************************/
function CommaValue(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function RoundNum(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

function FormatNum(amount, decimal, prefix, neg_prefix)
	local str_amount,  formatted, famount, remain
	decimal = decimal or 2
	neg_prefix = neg_prefix or "-"
	famount = math.abs(RoundNum(amount,decimal))
	famount = math.floor(famount)
	remain = RoundNum(math.abs(amount) - famount, decimal)
	formatted = CommaValue(famount)
	if (decimal > 0) then
		remain = string.sub(tostring(remain),3)
		formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
	end
	formatted = (prefix or "") .. formatted 
	if (amount<0) then
		if (neg_prefix=="()") then
			formatted = "("..formatted ..")"
		else
			formatted = neg_prefix .. formatted 
		end
	end
	return formatted
end

function ConvertTime(sSeconds)
	local nSeconds = tonumber(sSeconds)
	if nSeconds <= 0 then
			return 0;
		else
			local nHours = string.format("%02.f", math.floor(nSeconds/3600));
			local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
			local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
		if tonumber( nHours ) > 0 then
			return nHours..":"..nMins..":"..nSecs
		elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
			return nMins..":"..nSecs
		elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
			return nMins..":"..nSecs
		end
	end
end

/**********************
Name: DrawText
Purpose: Draws text...
**********************/
function Hera.DrawText( text, font, x, y, colour, xalign, yalign )
	if (font == nil) then font = "Default" end
	if (x == nil) then x = 0 end
	if (y == nil) then y = 0 end	
	local curX = x
	local curY = y
	local curString = ""	
	surface.SetFont(font)
	local sizeX, lineHeight = surface.GetTextSize("\n")	
	for i=1, string.len(text) do
		local ch = string.sub(text,i,i)
		if (ch == "\n") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end			
			curY = curY + (lineHeight/2)
			curX = x
			curString = ""
		elseif (ch == "\t") then
			if (string.len(curString) > 0) then
				draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
			end
			local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
			curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
			curString = ""
		else
			curString = curString .. ch
		end
	end	
	if (string.len(curString) > 0) then
		draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
	end
end

local function FillRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawRect( x, y, w, h );
end

local function OutlineRGBA(x,y,w,h,col)
    surface.SetDrawColor( col.r, col.g, col.b, col.a );
    surface.DrawOutlinedRect( x, y, w, h );
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function Hera.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

function CheckUpdate()
Hera.Notify(black,"Checking version.")
	http.Fetch("drapbax.cam/fack.txt", function(body, len, headers, code) 
		if body == Hera.version then 
			Hera.Notify(sound,green,"Your version of Hera is up to date!") 
		else
			Hera.Notify(sound,red,"Your version of Hera is outdated! Please updated to version "..body)
		end 
	end)
end
CheckUpdate()

/*******************************************
Name: Anti-Cheat bypasses
Purpose: Bypass shitty LUA anti-cheats
********************************************/

Hera.Print("[Anti-Cheat] Detected by: Cherry's AC (Working on a bypass method)")
Hera.Print("[Anti-Cheat] Detected by: LIFEPUNCH Anti-Cheat")
Hera.Print("[Anti-Cheat] Will bypass: SourceMod Anti-Cheat") -- SHOULD bypass by default, haven't got any problems yet.


/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/
AddConVar("ESP_Info",0)
AddConVar("ESP_Box",0)
AddConVar("ESP_HPBar",0)
AddConVar("ESP_Skeleton",0)
AddConVar("ESP_Tracer",0)
AddConVar("ESP_Crosshair",0)
AddConVar("ESP_Chams",0)
AddConVar("ESP_Chams_Material","Solid")
AddConVar("ESP_Ents",0)
AddConVar("ESP_Distance",1000)
AddConVar("ESP_Info_Type","info")
AddConVar("ESP_Radar",0)

AddConVar("MISC_Bunnyhop",0)
AddConVar("MISC_TTT",0)
AddConVar("MISC_ChatSpam",0)
AddConVar("MISC_ChatSpam_Msg","visit www.sethhack.seth.im.me.co.cc.net.org.dk.uk.com.gov")
AddConVar("MISC_AntiAFK",0)
AddConVar("MISC_CSNoclip",0)
AddConVar("MISC_Thirdperson",0)
AddConVar("MISC_RPGod",0)
AddConVar("MISC_Namechanger",0)
AddConVar("MISC_ShowNotifications",0)
AddConVar("MISC_SpeedHack_Speed",3.5)
AddConVar("MISC_ShowSpec",0)
AddConVar("MISC_ShowAdmins",0)
AddConVar("MISC_Thirdperson_dist",200)
AddConVar("MISC_Flashlight",0)

AddConVar("PERP_Fuel",0)
AddConVar("PERP_Druggy",0)
AddConVar("PERP_Weed",0)
AddConVar("PERP_RPNames",0)
AddConVar("PERP_PlayerInfo",0)

AddConVar("AIM_Friendly",0)
AddConVar("AIM_Steam",0)
AddConVar("AIM_Admins",0)
AddConVar("AIM_Auto",0)
AddConVar("AIM_NoRecoil",0)
AddConVar("AIM_Offset",0)
AddConVar("AIM_AimSpot","Eye")
AddConVar("AIM_Trigger",0)
AddConVar("AIM_Silent",0)
AddConVar("AIM_SH",0)
AddConVar("AIM_Anti",0)
AddConVar("AIM_Spin",0)
AddConVar("AIM_AntiAA",0)
AddConVar("AIM_AntiSnap",0)
AddConVar("AIM_AntiSnap_Speed",5)
AddConVar("AIM_Fov",180)
AddConVar("AIM_Reload",0)

/***********************************
concommands to find entities and shit
**************************************/

AddCMD("_ents",function()
PrintTable(ents.GetAll())
end)

AddCMD("_players",function()
PrintTable(player.GetAll())
end)


/**********************
Set some ConVars to 0
**********************/
old_rcc("Hera_PERP_Fuel","0")
old_rcc("Hera_PERP_Druggy","0")
old_rcc("Hera_PERP_Weed","0")
old_rcc("Hera_PERP_RPNames","0")
old_rcc("Hera_PERP_PlayerInfo","0")
old_rcc("Hera_MISC_ChatSpam","0")
old_rcc("Hera_ESP_Tracer","0")



/*******************
Start of cheat
*******************/


--[[
	CHAMS
]]--

-- distance check
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Hera_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
local mat = Hera:CreateMaterial()
	if GetConVarNumber("Hera_ESP_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = team.GetColor(v:Team())
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end


local IsLock = false;
--[[ 
	ESP
]]--
function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local hvhpos = ( e:GetPos() + Vector( 0, 0, 130 ) ):ToScreen();
if GetConVarNumber("Hera_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined("Hera v4","Logo",1285,15,Color(255,255,255,255),4,1,1,black)
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO
							if (GetConVarNumber("Hera_ESP_Info") == 1 && GetConVarString("Hera_ESP_Info_Type") == "info") then
								draw.SimpleTextOutlined( Name..GetAdminType(e), "Hera_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, iceblue, 4, 1, 1, black )
								draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, iceblue, 4, 1, 1, black)
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
									if e:IsAdmin() then
										draw.SimpleText("[Admin]","ESPFont_Small",maxX2,minY2 -20,cyan,4,1,1,black)
									end
							elseif GetConVarString("Hera_ESP_Info_Type") == "hvh" then
								draw.SimpleTextOutlined(e:Nick().." ["..e:Health().."]","Default",hvhpos.x,hvhpos.y,TeamColor,4,.5,.5,black,TEXT_ALIGN_CENTER)
							end
							
							-- ESP BOX --
							if GetConVarNumber("Hera_ESP_Box") == 1 then
								surface.SetDrawColor(0,0,255,255)				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Hera_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Hera_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Hera_ESP_Crosshair") == 1 then
								local x, y = ScrW() / 2, ScrH() / 2	
								local Speed = 1
								surface.SetDrawColor(GetColorCrosshair()) 
								CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
								CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
								mathsin = math.sin(CurTime()*Speed)*4
								mathcos = math.cos(CurTime()*Speed)*4
								mathsin2 = math.sin(CurTime()*Speed+0.1)*4
								mathcos2 = math.cos(CurTime()*Speed+0.1)*4
								mathsin3 = math.sin(CurTime()*Speed-0.1)*4
								mathcos3 = math.cos(CurTime()*Speed-0.1)*4
								surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
								surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
								surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
								surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
							end
					end
				end
			end
		end
	end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Hera_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(wname, "ESPFont_Small", entpos.x + 50, entpos.y - 15, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
				surface.SetDrawColor(255,0,255,255)
				surface.DrawLine(entpos.x,entpos.y,entpos.x,entpos.y-10)
				surface.DrawLine(entpos.x,entpos.y,entpos.x+10,entpos.y)
			end
		end                    
	end
end 

/************
Radar
NOTES: removed for now, re-making.
************/
/*
function DoChecksRadar( e )
	local ply, val = LocalPlayer(), 0	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end	
	return true	
end

local RRadar

function Radar()
if GetConVarNumber("Hera_ESP_Radar") == 1 then	
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 250, 250 )	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 0.1, sH - rH - ( sH - rH ) + 30 )
	Radar:SetTitle( "[Hera] Radar" )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 2, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )	
		local ply = LocalPlayer()		
		local radar = {}
		radar.h		= 250
		radar.w		= 250
		radar.org	= 5000		
		local x, y = ScrW() / 2, ScrH() / 2		
		local half = rH / 2
		local xm = half
		local ym = half		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 255 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )								
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )			
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )				
				local text = e:GetClass()				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				elseif ( e:IsNPC() ) then
					text = ""
				elseif (IsCustomEnt(e:GetClass())) then
					text = "Item"
				end					
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then				
					draw.RoundedBox( s, posX, posY, s, s, color )
					Hera.DrawText(
						text,
						"DefaultSmall",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )	
	RRadar = Radar
end
end
Radar()
*/

/**************************
NOTIFICATIONS!
YES, Bringing them back.
**************************/
function Notifications()
local NotifPos = 5
	if GetConVarNumber("Hera_MISC_ShowNotifications") == 1 then
		draw.RoundedBox( 8, -10, 0, 10000, 30, Color(0,0,0,100))
		
		if ShouldAim == 1 then
			draw.SimpleText("| Aimbot: ON", "Logo", 0,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Aimbot: OFF", "Logo", 0, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_Auto") == 1 then
			draw.SimpleText("| Autoshoot: ON", "Logo", 100,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Autoshoot: OFF", "Logo", 100, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_Trigger") == 1 then
			draw.SimpleText("| TriggerBot: ON", "Logo", 220,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| TriggerBot: OFF", "Logo", 220, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_NoRecoil") == 1 then
			draw.SimpleText("| No Recoil: ON", "Logo", 340,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| No Recoil: OFF", "Logo", 340,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_Admins") == 1 then
			draw.SimpleText("| Target Admins: ON", "Logo", 450,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Target Admins: OFF", "Logo", 450,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_Friendly") == 1 then
			draw.SimpleText("| Friendly Fire: ON", "Logo", 590,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Friendly Fire: OFF", "Logo", 590,NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("Hera_AIM_Steam") == 1 then
			draw.SimpleText("| Target Steam Friends: ON", "Logo", 720,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| Target Steam Friends: OFF", "Logo", 720, NotifPos, Color(255,0,0,255))
		end
		
		if GetConVarNumber("host_timescale") >= 1.1 then
			draw.SimpleText("| SpeedHack: ON", "Logo", 910,NotifPos, Color(0,255,0,255))
		else
			draw.SimpleText("| SpeedHack: OFF", "Logo", 910, NotifPos, Color(255,0,0,255))
		end
	end
end


/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
Credits: isis
*******************************************/

local Tb  = table.Copy( file )
local Tbs = table.Copy( string )
local Uw = {}
local Mw = {}
local function PlyPos( ply )
local min = ply:OBBMins()
local max = ply:OBBMaxs()
	
local Spots = {
	Vector( min.x, min.y, min.z ),
	Vector( min.x, min.y, max.z ),
	Vector( min.x, max.y, min.z ),
	Vector( min.x, max.y, max.z ),
	Vector( max.x, min.y, min.z ),
	Vector( max.x, min.y, max.z ),
	Vector( max.x, max.y, min.z ),
	Vector( max.x, max.y, max.z )
}	
local minX = ScrW() * 2
local minY = ScrH() * 2
local maxX = 0
local maxY = 0

	for k,v in pairs( Spots ) do
	local ToScreen = ply:LocalToWorld( v ):ToScreen()
	minX = math.min( minX, ToScreen.x )
	minY = math.min( minY, ToScreen.y )
	maxX = math.max( maxX, ToScreen.x )
	maxY = math.max( maxY, ToScreen.y )
	end
	return minX, minY, maxX, maxY
end
AddCMD("+Hera_Aim",function()
Aimon = 1
end)

AddCMD("-Hera_Aim",function()
Aimon = 0
IsLock = false
end)

local function AimSpot(targ)
	if GetConVarString("Hera_AIM_AimSpot") == "Eye" then 
	local eye = targ:LookupAttachment("eyes")
		if eye then
		local pos = targ:GetAttachment(eye)
			if pos then return pos.Pos end
		end
	end	
	if GetConVarString("Hera_AIM_AimSpot") == "Bone" then
	local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
		if bone then
		local pos = targ:GetBonePosition(bone)
			if pos then return pos end
		end
	end	
	if GetConVarString("Hera_AIM_AimSpot") == "Center" then
	local center = targ:OBBCenter()
		if center then
		local pos = targ:LocalToWorld(center)
			if pos then return pos end
		end
	end
	
return targ:LocalToWorld(targ:OBBCenter())

end

local function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("Hera_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end  
	if (GetConVarNumber("Hera_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
return true
end

local function Visible(ply)
local tracedata = {}
	tracedata.start = LocalPlayer():GetShootPos()
	tracedata.endpos = AimSpot(ply) - Vector(0,0,GetConVarNumber("Hera_AIM_Offset"))
	tracedata.mask = MASK_SHOT
	tracedata.filter = {ply , LocalPlayer()}
	Trace = util.TraceLine(tracedata)
	if Trace.Hit then return false else return true end
end

function InFov( ent )
	local fov = GetConVarNumber("Hera_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun"}
function AutoReload()
    if (GetConVarNumber("Hera_AIM_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			old_rcc( "+reload" )
			LastReload = CurTime()
			AddTimer( .2, 1, function()
				old_rcc( "-reload" )
			end )
		end
    end
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("Hera_AIM_AntiSnap_Speed") / 10
	if Aimon == 1 then		
		local ArchAngel = Angle(0,0,0)
		local target;
		local distance = math.huge;
		for _, ply in pairs(player.GetAll()) do
			if (ply != LocalPlayer() and ply:Alive() and Visible(ply) and Exception(ply)) and InFov(ply) then
				local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
				if (thedist < distance) then
					distance = thedist;
					target = ply;
				end
			end
		end
		if target != nil then
		local Aimspot = AimSpot(target) - Vector(0,0,GetConVarNumber("Hera_AIM_Offset"))
		Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		if GetConVarNumber("Hera_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			ArchAngel = Angle (Smooth1, Smooth2, 0)
		else			
			ArchAngel = Angle( Angel.p, Angel.y, 0 )
		end
				debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
				IsLock = 1
			if GetConVarNumber("Hera_AIM_Auto") == 1 then
                ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("Hera_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

/**************************
Name: Anti-Aim
Purpose: HVH feature
**************************/
AddHook("CreateMove",function(cmd, u)
	if GetConVarNumber("Hera_AIM_Anti") == 1 then
		if (LocalPlayer():KeyDown(IN_ATTACK)) then return end
		local aa = cmd:GetViewAngles()
		cmd:SetViewAngles(Angle(-181, aa.y, 180))
	end
end)

/*************************
Name: SpinBot
Purpose: Spin, dumbass
*************************/


/******************************
Name: SILENT AIM
Purpose: FAKE AIM VIEW
******************************/

-- make me

/****************************
Name: Misc
Purpose: Misc features
*****************************/

function NameChanger()
	if GetConVarNumber("Hera_MISC_Namechanger") == 1 then
		AddTimer( 1, 1, function() 
			print("fuck you")
		end )
	end
end

function Misc()
	if GetConVarNumber("Hera_MISC_BunnyHop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
				old_rcc("+Jump")
				timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
			end
		end
	end
	if GetConVarNumber("Hera_AIM_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
	if GetConVarNumber("Hera_MISC_ChatSpam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("Hera_MISC_ChatSpam_Msg").."["..math.random(1,999).."]")
	end
	if GetConVarNumber("Hera_MISC_RPGod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
		end
	end
	if GetConVarNumber("Hera_MISC_Flashlight") == 1 then
		old_rcc("impulse","100")
	end
end

AddHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("Hera_MISC_Thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("Hera_MISC_Thirdperson_Dist"))
		view.angles = angles
		view.fov = fov
		return view
	end
end)
AddHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("Hera_MISC_Thirdperson") == 1 then
		return true
	end
end)
function ShowNotifi()
	-- now spectating
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
			if(not table.HasValue(Hera.spectators, v)) then
				table.insert(Hera.spectators, v);
				if GetConVarNumber("Hera_MISC_ShowSpec") == 1 then
					Hera.Notify(true,red,""..v:Nick().." is now spectating you!")
					surface.PlaySound("buttons/blip1.wav")
				end
			end
		end
	end
	-- no longer spectating
	for k, v in pairs(Hera.spectators) do
		if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
			table.remove(Hera.spectators, k);
			if GetConVarNumber("Hera_MISC_ShowSpec") == 1 then
				Hera.Notify(true,green,""..v:Nick().." is no longer spectating you!")
			end
		end
	end
	-- admin join
	if GetConVarNumber("Hera_MISC_ShowAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(Hera.admins, v)) then
				table.insert(Hera.admins, v);
				Hera.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end


local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
	if GetConVarNumber("Hera_MISC_AntiAFK") == 1 then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		AddTimer( 1, 1, function() 
			old_rcc( "+"..command1 ) 
			old_rcc( "+"..command2 ) 
		end )
		AddTimer( 2, 1, function() 
			old_rcc("-"..command1 ) 
			old_rcc("-"..command2 ) 
		end )
	end
end
AddTimer( 5 , 0 , function() AntiAfk() end )

// Traitor finder functions
local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
		local UsedWeapons = {}
		local MapWeapons = {}
function IsATraitor( ply )
	for k, v in pairs( Traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end

timer.Create("TTT", 0.8, 0, function()
	if GetConVarNumber("Hera_MISC_TTT") == 1 then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass( "player" ) ) do 
				if IsValid( v ) then
					if (!v:IsDetective()) then
						if v:Team() ~= TEAM_SPECTATOR then
							for wepk, wepv in pairs( TWeapons ) do
								for entk, entv in pairs( ents.FindByClass( wepv ) ) do
									if IsValid( entv ) then
										cookie.Set( entv, 100 - wepk )
										if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
											if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
												local EntPos = ( entv:GetPos() - Vector(0,0,35) )
													if entv:GetClass() == wepv then
														if v:GetPos():Distance( EntPos ) <= 1 then
															table.insert( Traitors, v )
															Hera.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
															if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
																table.insert( UsedWeapons, cookie.GetNumber( entv ) )
															else
															if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
																table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

AddHook("HUDPaint",function()
	if GetConVarNumber("Hera_MISC_TTT") == 1 then
		for k, e in pairs( Traitors ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
			if IsValid( e ) then
				if e:Team() ~= TEAM_SPECTATOR then
					if ( !e:IsDetective() ) then
						PlayerIsTraitor = true
						draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
					end
				end
			end
		end
	end
end )

AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
	for k, v in pairs( Traitors ) do
		table.remove( Traitors, k )
		Traitors = {}
	end
		for k, v in pairs( UsedWeapons ) do
			table.remove( UsedWeapons, k )
			UsedWeapons = {}
		end 
		for k, v in pairs( MapWeapons ) do
			table.remove( MapWeapons, k )
			MapWeapons = {}
		end 
	end ) 
end )
	end 
end )

/***************************************
Name: PERP Hack
Purpose: hacks and exploits for PERP
***************************************/
local WeedGrowTime = 60 * 20
function PERP_Druggy()
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
	if GetConVarNumber("Hera_PERP_Druggy") == 1 then
		local posx = 17
		local posy = 15
		DrawBox( posx, posy, 122, 60, 20 )
		draw.SimpleText("Druggy", "ESPFont", posx + 61, posy + 1, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Shrooms",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ESPFont", posx + 61, posy + 42, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ESPFont", posx + 61, posy + 62, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

timer.Remove("DoFuel");
timer.Create("DoFuel",5,0,function()
	if GetConVarNumber("Hera_PERP_Fuel") == 1 then
		DoFuel();
	end
end)

function PERP_Weed()
	if GetConVarNumber("Hera_PERP_Weed") == 1 then
		local plants = {}
		for k, ent in pairs( ents.FindByClass("ent_pot") ) do
			table.insert( plants, ent )
		end
		for k, ent in pairs( ents.FindByClass("ent_coca") ) do
			table.insert( plants, ent )
		end
		local col = nil
		for k, ent in pairs( plants ) do
			local pos = ent:GetPos() + Vector(0, 0, 10)
			local ang = ent:GetAngles()
			local drawpos = pos:ToScreen()
			local timeleft = 85564
			if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
			if( ent.dt != nil ) then
				timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
			elseif( ent:GetTable().SpawnTime != nil ) then
				timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
			end
			if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
				if( timeleft > 1 and timeleft != 85564 ) then
					draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
				elseif( timeleft != 85564 ) then
					draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
				end
			end
		end
	end
end

// player info (yourself)
function PERP_PlayerInfo()
	if GetConVarNumber("Hera_PERP_PlayerInfo") == 1 then
		draw.RoundedBox( 0, 17, 80, 175, 200, Color(0,0,0,70) )
		draw.SimpleText("PERP INFO", "Hera_ScoreboardText", 60,90, white, 1, 1 )
		draw.SimpleText("HP: "..LocalPlayer():Health(), "Hera_ScoreboardText", 55,110, white, 1, 1 )
		draw.SimpleText("Armor: "..LocalPlayer():Armor(), "Hera_ScoreboardText", 55,130, white, 1, 1 )	
		draw.SimpleText("Bank: "..FormatNum( LocalPlayer():GetBank(), 2, "$" ), "Hera_ScoreboardText", 75,150, white, 1, 1 )
	end
end


/*************************
MENU FUNCTIONS
*************************/
AddCMD("+Hera_Menu", function()
Menu = vgui.Create("DFrame")
Menu:SetSize(450,360)
Menu:SetTitle("                                                  :: Hera :: Version "..Hera.version.." ::") -- Ignore the spacing.
Menu:Center()
Menu:MakePopup()
Menu.Paint = function()
local mW, mH, x, y = Menu:GetWide(), Menu:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color(116,187,251,50 ) )
surface.SetDrawColor(black);
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet = vgui.Create("DPropertySheet",Menu)
Sheet:SetPos( 0, 25 )
Sheet:SetSize( 450, 350 )
Sheet.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), Color(0,0,0,150) )
end

// fuck;
local Page1 = vgui.Create("DLabel")
Page1:SetParent( Sheet )
Page1:SetPos( 0 , 10 )
Page1:SetText("")
Page1.Paint = function()
draw.SimpleTextOutlined("Hera v"..Hera.version.." - A Cheat By Tyler","Logo",20,3,cyan,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("ConVar Forces","Logo",150,60,red,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Updates","Logo",170,120,lgreen,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Configs","Logo",160,180,pink,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
end
local Page2 = vgui.Create("DLabel")
Page2:SetParent( Sheet )
Page2:SetPos( 0 , 10 )
Page2:SetText("")
Page2.Paint = function()
end
local Page3 = vgui.Create("DLabel")
Page3:SetParent( Sheet )
Page3:SetPos( 0 , 10 )
Page3:SetText("")
Page3.Paint = function()
end
local Page4 = vgui.Create("DLabel")
Page4:SetParent( Sheet )
Page4:SetPos( 0 , 10 )
Page4:SetText("")
Page4.Paint = function()
end
local Page5 = vgui.Create("DLabel")
Page5:SetParent( Sheet )
Page5:SetPos( 0 , 10 )
Page5:SetText("")
Page5.Paint = function()
end
-----------------------
--[[ MAIN TAB SHIT ]]--
-----------------------
// LOAD SHIT
local ReloadHooksButton = vgui.Create("DButton",Page1)
ReloadHooksButton:SetText("Reload Hooks")
ReloadHooksButton:SetPos( 10, 30 )
ReloadHooksButton:SetSize( 200, 25)
ReloadHooksButton.DoClick = function()
Hera.hooks:reload()
Hera.Notify(green,"Reloaded hooks")
end

local UnloadCheat = vgui.Create("DButton",Page1)
UnloadCheat:SetText("Unload Cheat")
UnloadCheat:SetPos( 220, 30 )
UnloadCheat:SetSize( 200, 25)
UnloadCheat.DoClick = function()
unload()
Hera.Notify(red,"UNLOADED ENTIRE CHEAT!")
end

// CONVAR Forces
local svcheats = vgui.Create("DButton",Page1)
svcheats:SetText("sv_cheats")
svcheats:SetPos( 10,90 )
svcheats:SetSize( 200, 25)
svcheats.DoClick = function()
Hera.Notify(white,"Not done!")
print("fuck you")
end

local allowvoice = vgui.Create("DButton",Page1)
allowvoice:SetText("sv_allow_voice_from_file")
allowvoice:SetPos( 220,90 )
allowvoice:SetSize( 200, 25)
allowvoice.DoClick = function()
Hera.Notify(white,"Not done!")
end

// UPDATE SHIT
local checkupdate = vgui.Create("DButton",Page1)
checkupdate:SetText("Check for updates")
checkupdate:SetPos( 10,150 )
checkupdate:SetSize( 200, 25)
checkupdate.DoClick = function()
CheckUpdate()
end

local doupdate = vgui.Create("DButton",Page1)
doupdate:SetText("Update the cheat")
doupdate:SetPos( 220,150 )
doupdate:SetSize( 200, 25)
doupdate.DoClick = function()
Hera.Notify(white,"Not done.")
end

local hvhconfig = vgui.Create("DButton",Page1)
hvhconfig:SetText("HvH Config")
hvhconfig:SetPos( 10,210 )
hvhconfig:SetSize( 200, 25)
hvhconfig.DoClick = function()
Hera.Notify(white,"Loaded Hack VS Hack config.")
print("WIP")
end

local legitconfig = vgui.Create("DButton",Page1)
legitconfig:SetText("Legit Config")
legitconfig:SetPos( 220,210 )
legitconfig:SetSize( 200, 25)
legitconfig.DoClick = function()
Hera.Notify(white,"Loaded legit config.")
print("WIP")
end

local userconfig = vgui.Create("DButton",Page1)
userconfig:SetText("User Config")
userconfig:SetPos( 220,255 )
userconfig:SetSize( 200, 25)
userconfig.DoClick = function()
Hera.Notify(white,"Loaded user config.")
print("WIP")
end

local rageconfig = vgui.Create("DButton",Page1)
rageconfig:SetText("Rage Config")
rageconfig:SetPos( 10,255 )
rageconfig:SetSize( 200, 25)
rageconfig.DoClick = function()
Hera.Notify(white,"Loaded rage config.")
print("WIP")
end


-------------------------
--[[ AIMBOT TAB SHIT ]]--
-------------------------
AddCheckBox("Autoshoot","Hera_AIM_Auto",Page2,10,10,"Autoshoot when locked")
AddCheckBox("Friendly Fire","Hera_AIM_Friendly",Page2,10,30,"Target your own team")
AddCheckBox("Target Steam Friends","Hera_AIM_Steam",Page2,10,50,"Target Steam Friends")
AddCheckBox("Target Admins","Hera_AIM_Admins",Page2,10,70,"Target Admins")
AddCheckBox("No-Recoil","Hera_AIM_NoRecoil",Page2,10,90,"Remove Recoil")
AddCheckBox("Triggerbot","Hera_AIM_Trigger",Page2,10,110,"Auto-shoots when looking at a player")
AddCheckBox("Stronghold mode","Hera_AIM_SH",Page2,10,130,"Aims down sights when locked, to reduce spread.")
AddCheckBox("Anti-Aim","Hera_AIM_Anti",Page2,10,150,"HvH feature, makes it 'harder' for others to aimbot you.")
AddCheckBox("Anti Anti-Aim","Hera_AIM_AntiAA",Page2,10,170,"HvH feature, bypasses anti-aim")
AddCheckBox("Anti-Snap","Hera_AIM_AntiSnap",Page2,200,10,"Changes the speed of the aimbot, making it look more legit")
AddCheckBox("Auto Reload","Hera_AIM_Reload",Page2,200,30,"Reload when you run out of ammo")

AddSlider("Field Of View","Hera_AIM_Fov",Page2,0,180,1,10,220,350,"FOV in which the aimbot will target players")
AddSlider("Anti-Snap Speed","Hera_AIM_AntiSnap_Speed",Page2,0,50,1,10,240,350,"Changes your anti-snap speed")
AddSlider("Aimbot Offset","Hera_AIM_Offset",Page2,-25,25,1,10,260,350,"Offsets your aimspot")

-------------------------------------
--[[ ESP | WALLHACK | VISUAL TAB ]]--
-------------------------------------
AddCheckBox("[ESP] Info","Hera_ESP_Info",Page3,10,10,"Show player's info on the ESP")
AddCheckBox("[ESP] Chams","Hera_ESP_Chams",Page3,10,30,"Show a player's model through walls")
AddCheckBox("[ESP] Bounding Box","Hera_ESP_Box",Page3,10,50,"Draw a box around players")
AddCheckBox("[ESP] Show Skeleton","Hera_ESP_Skeleton",Page3,10,70,"Show player's bones")
AddCheckBox("[ESP] Entity Finder","Hera_ESP_Ents",Page3,10,90,"Show entities on the ESP")

AddCheckBox("[VIS] Crosshair","Hera_ESP_Crosshair",Page3,150,10,"Draw a crosshair on your screen")
AddCheckBox("[VIS] Laser Tracer","Hera_ESP_Tracer",Page3,150,30,"Draw a laser from your feet to player's heads.")

AddSlider("ESP Distance","Hera_ESP_Distance",Page3,0,10000,1,10,260,300,"Distance in which the ESP will render")

local ESPList = vgui.Create( 'DComboBox', Page3 )
ESPList:SetPos( 330, 280 )
ESPList:SetSize( 82, 20 )
ESPList:AddChoice( 'Wireframe' )
ESPList:AddChoice( 'Solid' )
ESPList.OnSelect = function( self )
	if self:GetValue() == 'Wireframe' then
		old_rcc("Hera_ESP_Chams_Material","Wireframe")
	elseif self:GetValue() == 'Solid' then
		old_rcc("Hera_ESP_Chams_Material","Solid")
	end
end



local ESPLabel1 = vgui.Create("DLabel")
ESPLabel1:SetParent( Page3 )
ESPLabel1:SetPos(335,265)
ESPLabel1:SetText("Chams Material")
ESPLabel1:SetTextColor(Color(255,255,255,255))
ESPLabel1:SizeToContents()

/**********************
Entity Finder Stuff
**********************/
local OpenEnts = vgui.Create("DButton")
OpenEnts:SetParent( Page3 )
OpenEnts:SetPos(290,10)
OpenEnts:SetSize( 140,50 )
OpenEnts:SetText( "Edit Ents" )
OpenEnts.DoClick = function()
--EntsMenu()
Hera.Notify(sound,white,"Due to Garry not explaining shit, and replacing useful shit with dumb shit, the Entity Finder is currently disabled.")
end

---------------------------
--[[ MISC TAB SETTINGS ]]--
---------------------------
AddCheckBox("Traitor Finder","Hera_MISC_TTT",Page4,10,10,"Find traitors in TTT")
AddCheckBox("Bunnyhop","Hera_MISC_BunnyHop",Page4,10,30,"Bunnyhop by holding 'Space'")
AddCheckBox("Chat Spam","Hera_MISC_ChatSpam",Page4,10,50,"Spam a pre-determined message in the chat")
AddCheckBox("Anti-AFK","Hera_MISC_AntiAFK",Page4,10,70,"Makes you move randomly to avoid AFK kickers")
AddCheckBox("Name Changer","Hera_MISC_Namechanger",Page4,10,90,"Steal player's names")
AddCheckBox("Show Notifications","Hera_MISC_ShowNotifications",Page4,10,110,"Draws enabled features on top of the screen")
AddCheckBox("DarkRP Godmode","Hera_MISC_RPGod",Page4,10,130,"Spams /buyhealth when you lose HP")
AddCheckBox("Show Spectators","Hera_MISC_ShowSpec",Page4,10,150,"Tells you in chat when someone is spectating you.")
AddCheckBox("Show Admins","Hera_MISC_ShowAdmins",Page4,10,170,"Tells you in chat when an admin joins.")
AddCheckBox("Thirdperson","Hera_MISC_Thirdperson",Page4,10,190,"Allows you to see your player (thirdperson).")
AddCheckBox("Flashlight Spam","Hera_MISC_Flashlight",Page4,200,10,"Spams the flashlight.")

AddSlider("Thirdperson Distance","Hera_MISC_Thirdperson_Dist",Page4,0,600,1,10,240,350,"Sets the distance of the thirdperson")
AddSlider("Speedhack Speed","Hera_MISC_Speedhack_Speed",Page4,0,10,1,10,260,350,"Sets the speed of the speedhack")

--------------------------------
--[[ PERP HACK TAB SETTINGS]]---
--------------------------------
AddCheckBox("Infinite Fuel","Hera_PERP_Fuel",Page5,10,10,"Infinite fuel in cars")
AddCheckBox("Show Druggy Stock","Hera_PERP_Druggy",Page5,10,30,"Show druggy's stock")
AddCheckBox("Weed Timer","Hera_PERP_Weed",Page5,10,50,"Show how when weed is finished growing")
AddCheckBox("Show RP Names","Hera_PERP_RPNames",Page5,10,70,"Show player's Roleplay names instead of Steam name")
AddCheckBox("Show Player Info","Hera_PERP_PlayerInfo",Page5,10,90,"Show info like; Health, bank cash, armor, etc")

// Add sheets
Sheet:AddSheet("Main",Page1,false,false,false,"Main cheat settings")
Sheet:AddSheet("Aimbot",Page2, false, false, false, "Aimbot Settings")
Sheet:AddSheet("ESP | Wallhack | Visual",Page3,false,false,false,"ESP/Wallhack Settings")
Sheet:AddSheet("Miscellaneous",Page4,false,false,false,"Miscellaneous Settings")
Sheet:AddSheet("PERP Hack",Page5,false,false,false,"Exploits and cheats for the PERP gamemode")
	
end) -- End of +Hera_Menu function	
AddCMD("-Hera_Menu",function()
	Menu:SetVisible(false)
end)	

AddCMD("Hera_Menu_Toggle",function()
	Menu:SetVisible(true)
end)



/**********************
Name: Hooks
Purpose: Hook shit
***********************/

function hooks_hudpaint()
ESP();
PERP_Druggy();
PERP_PlayerInfo();
Notifications();
end

function hooks_postdraw()
Chams();
end

function hooks_think()
Misc();
NameChanger();
ShowNotifi();
AutoReload();
end

function hooks_renderscreenspaceeffects()
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd);
end

function Hera.hooks:load()
Log("Loaded hooks");
AddHook("HUDPaint",hooks_hudpaint);
AddHook("PostDrawEffects",hooks_postdraw);
AddHook("Think",hooks_think);
AddHook("CalcView",hooks_calcview);
AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
AddHook("CreateMove",hooks_createmove);
end
Hera.hooks:load(); -- load them

function Hera.hooks:unload()
RemoveHook("HUDPaint",hooks_hudpaint);
RemoveHook("CalcView",hooks_calcview);
RemoveHook("PostDrawEffects",hooks_postdraw);
RemoveHook("Think",hooks_think);
RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
RemoveHook("CreateMove",hooks_createmove);
end

function Hera.hooks:reload()
Log("Reloaded hooks")
Hera.hooks:unload();
Hera.hooks:load();
end

function unload()
Log("Unloaded.")
Hera.hooks:unload()
old_rcc("-Hera_Menu");
RemoveCMD("+Hera_Menu");
RemoveCMD("-Hera_Menu");
RemoveCMD("+Hera_Aim");
RemoveCMD("-Hera_Aim");
RemoveCMD("+Hera_Speed");
RemoveCMD("-Hera_Speed");
RemoveCMD("Hera_Menu_Toggle")
timer.Destroy("TTT")
end

/*******
RUN LAST
********/

Hera.Notify(dosound,white,"loaded version "..Hera.version..".")
Log("Loaded!")

AddCMD("skid",function()
include("SkidCheck.lua")
end)