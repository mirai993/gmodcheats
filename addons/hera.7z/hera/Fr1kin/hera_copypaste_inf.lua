--[[
Copyright :: All Rights Reserved
Registered :: 2013-03-01 21:30:12
Title :: Hera.lua
Category :: Lua file
Fingerprint :: 1e26103c9e432855c65de4fb7b5455a6e369b88d790c436686f38267c7f44517
MCN :: CY4Z8-E8CTL-8HNB5        
]]

--[[

-================================-


Hera v4 - A Garry's Mod aimbot [Multi-Hack]


-================================-

]]--


/************************************
Name: Localizing
Purpose: Make the cheat run faster
************************************/

//if ( Hera ) then _G.Hera = nil end -- noob !!

local g 					= table.Copy(_G)
local Hera					= {}
Hera.hooks					= {}
Hera.concommands			= {}
Hera.convars				= {} 
Hera.timers					= {}
Hera.spectators				= {}
Hera.admins					= {} 
Hera.version				= "4.2.7"
Hera.log					= {}
Hera.files					= {"Hera.lua","log.txt","gmcl_cvar3_win32.dll","gmcl_hera_win32.dll"}
Hera.traitors				= {}

Hera.bones					= {
{"Head", "ValveBiped.Bip01_Head1"},
{"Neck", "ValveBiped.Bip01_Neck1"},
{"Spine", "ValveBiped.Bip01_Spine"},
{"Spine1", "ValveBiped.Bip01_Spine1"},
{"Spine2", "ValveBiped.Bip01_Spine2"},
{"Spine4", "ValveBiped.Bip01_Spine4"},
{"Pelvis", "ValveBiped.Bip01_Pelvis"},
{"R Upperarm", "ValveBiped.Bip01_R_UpperArm"},
{"R Forearm", "ValveBiped.Bip01_R_Forearm"},
{"R Hand", "ValveBiped.Bip01_R_Hand"},
{"L Upperarm", "ValveBiped.Bip01_L_UpperArm"},
{"L Forearm", "ValveBiped.Bip01_L_Forearm"},
{"L Hand", "ValveBiped.Bip01_L_Hand"},
{"R Thigh", "ValveBiped.Bip01_R_Thigh"},
{"R Calf", "ValveBiped.Bip01_R_Calf"},
{"R Foot", "ValveBiped.Bip01_R_Foot"},
{"R Toes", "ValveBiped.Bip01_R_Toe0"},
{"L Thigh", "ValveBiped.Bip01_L_Thigh"},
{"L Calf", "ValveBiped.Bip01_L_Calf"},
{"L Foot", "ValveBiped.Bip01_L_Foot"},
{"L Toes", "ValveBiped.Bip01_L_Toe0"},
}

Hera.espbones = {
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

Hera.aimmodels = {
["models/combine_scanner.mdl"] = "Scanner.Body",
["models/hunter.mdl"] = "MiniStrider.body_joint",
["models/combine_turrets/floor_turret.mdl"] = "Barrel",
["models/dog.mdl"] = "Dog_Model.Eye",
["models/antlion.mdl"] = "Antlion.Body_Bone",
["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
["models/headcrabblack.mdl"] = "HCBlack.body",
["models/headcrab.mdl"] = "HCFast.body",
["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl",
}
Hera.prediction				= {
["weapon_crossbow"] = 3485,
["weapon_pistol"] = 40000,
["weapon_357"] = 20500,
["weapon_smg"] = 39000,
["weapon_ar2"] = 39000,
["weapon_shotgun"] = 35000,
["weapon_rpg"] = 0,	
}

Hera.props					= {
"models/props/de_tides/gate_large.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
"models/props_c17/furnitureStove001a.mdl",
"models/props_junk/sawblade001a.mdl",
"models/props_junk/TrashDumpster01a.mdl",
"models/props_combine/breendesk.mdl",
"models/props_c17/Lockers001a.mdl",
"models/props/de_train/lockers001a.mdl",
"models/props/de_train/lockers_long.mdl",
"models/props_canal/canal_bars004.mdl",
"models/props_c17/FurnitureCouch001a.mdl",
};

Hera.laser					= {
"weapon_pocket",
"weapon_crowbar",
"keys",
"pocket",
"weapon_toolgun",
"weapon_physgun",
"weapon_camera",
"camera",
}

Hera.dev					= { -- for module shit
"STEAM_0:0:40143824",
"STEAM_0:1:58058392",
}

local colors				= {}
red							= Color(255,0,0,255);
black						= Color(0,0,0,255);
green						= Color(0,255,0,255);
white						= Color(255,255,255,255);
blue						= Color(0,0,255,255);
cyan						= Color(0,255,255,255);
pink 						= Color(255,0,255,255);
blue						= Color(0,0,255,255);
grey						= Color(100,100,100,255);
gold						= Color(255,228,0,255);
lblue						= Color(155,205,248);
lgreen						= Color(174,255,0);
iceblue						= Color(116,187,251,255);
local COLOR_VISIBLE			= Color(0,255,0,150)
local COLOR_NONVISIBLE  	= Color(255,0,0,150)
local COLOR_FROZEN			= Color(0,0,255,150)
local COLOR_FROZEN_NV		= Color(255,255,0,150)

local _G					= table.Copy( _G )
local _R					= _G.debug.getregistry()

local math 					= _G.math
local string 				= _G.string
local hook 					= _G.hook
local table 				= _G.table
local timer 				= _G.timer
local surface 				= _G.surface
local concommand 			= _G.concommand
local cvars 				= _G.cvars
local ents 					= _G.ents
local player 				= _G.player
local team 					= _G.team
local util 					= _G.util
local draw 					= _G.draw
local usermessage 			= _G.usermessage
local vgui 					= _G.vgui
local http 					= _G.http
local cam 					= _G.cam
local render 				= _G.render

local MsgN 					= _G.MsgN
local Msg 					= _G.Msg
local Vector 				= _G.Vector
local Angle 				= _G.Angle
local pairs 				= _G.pairs
local ipairs 				= _G.ipairs
local CreateSound 			= _G.CreateSound
local setmetatable 			= _G.setmetatable
local Sound 				= _G.Sound
local print 				= _G.print
local pcall 				= _G.pcall
local type 					= _G.type
local LocalPlayer 			= _G.LocalPlayer
local KeyValuesToTable 		= _G.KeyValuesToTable
local TableToKeyValues 		= _G.TableToKeyValues
local Color 				= _G.Color
local CreateClientConVar 	= _G.CreateClientConVar
local ErrorNoHalt 			= _G.ErrorNoHalt
local IsValid 				= _G.IsValid
local CreateMaterial 		= _G.CreateMaterial
local tonumber 				= _G.tonumber
local tostring 				= _G.tostring
local CurTime			 	= _G.CurTime
local FrameTime 			= _G.FrameTime
local ScrW 					= _G.ScrW
local ScrH 					= _G.ScrH
local SetClipboardText 		= _G.SetClipboardText
local GetHostName 			= _G.GetHostName
local unpack 				= _G.unpack
local AddConsoleCommand 	= _G.AddConsoleCommand 
local require				= _G.require
local include				= _G.include

local MOVETYPE_OBSERVER 	= _G.MOVETYPE_OBSERVER
local MOVETYPE_NONE 		= _G.MOVETYPE_NONE
local TEXT_ALIGN_LEFT 		= _G.TEXT_ALIGN_LEFT
local TEXT_ALIGN_TOP 		= _G.TEXT_ALIGN_TOP
local TEXT_ALIGN_RIGHT 		= _G.TEXT_ALIGN_RIGHT
local TEXT_ALIGN_BOTTOM		= _G.TEXT_ALIGN_BOTTOM
local IN_JUMP 				= _G.IN_JUMP
local IN_FORWARD 			= _G.IN_FORWARD
local IN_BACK 				= _G.IN_BACK
local IN_MOVERIGHT 			= _G.IN_MOVERIGHT
local IN_MOVELEFT 			= _G.IN_MOVELEFT
local IN_SPEED 				= _G.IN_SPEED
local IN_DUCK 				= _G.IN_DUCK
local TEAM_SPECTATOR 		= 1002

-- old [copy]
local old_filecdir 			= file.CreateDir;
local old_filedel 			= file.Delete;
local old_fileexist 		= file.Exists;
local old_fileexistex 		= file.ExistsEx;
local old_filefind 			= file.Find;
local old_filefinddir 		= file.FindDir;
local old_filefindil 		= file.FindInLua;
local old_fileisdir			= file.IsDir;
local old_fileread 			= file.Read;
local old_filerename 		= file.Rename;
local old_filesize 			= file.Size;
local old_filetfind			= file.TFind;
local old_filetime 			= file.Time;
local old_filewrite 		= file.Write;
local old_dbginfo 			= debug.getinfo;
local old_dbginfo 			= debug.getupvalue;
local old_timerc			= timer.Create;
local old_cve 				= ConVarExists;
local old_gcv 				= GetConVar;
local old_gcvn 				= GetConVarNumber;
local old_gcvs 				= GetConVarString;
local old_rcc 				= RunConsoleCommand;
local old_hookadd			= hook.Add;
local old_hookrem 			= hook.Remove;
local old_ccadd				= concommand.Add;
local old_ccrem 			= concommand.Remove;
local old_cvaracc 			= cvars.AddChangeCallback;
local old_cvargcvc 			= cvars.GetConVarCallbacks;
local old_cvarchange 		= cvars.OnConVarChanged;
local old_require			= require;
local old_eccommand 		= engineConsoleCommand;
local old_rs				= RunString;
local old_ccmd				= _R.Player.ConCommand;
local old_include			= include;
local old_usermsginc		= usermessage.IncomingMessage;

--Fonts--
surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
surface.CreateFont("Hera_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
surface.CreateFont("Hera_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
surface.CreateFont("Hera_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
surface.CreateFont("Hera_coolvetica2",{font = "coolvetica", size = 20, weight = 500, antialias = 1})


----------------
require('cvar3')
----------------



--Materials--
function Hera:CreateMaterial()
local BaseInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$translucent"] = 1,
["$alpha"]       = 1,
["$nocull"]      = 1,
["$ignorez"]	 = 1
}	
local mat	
if GetConVarString("Hera_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "hera_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("Hera_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "hera_wire", "Wireframe", BaseInfo )
end
   return mat
end

/*****
Hera:IsDev
*****/
function Hera:IsDev(ply)
	if table.HasValue(Hera.dev,ply:SteamID()) then
		return true
	else
		return false
	end
end

/*******************************************
Name: Print/Chat functions
Purpose: Notify the user of what's going on
********************************************/
function Hera.Print(msg)
	print("[Hera] "..msg)
end

function Hera.Notify(dosound,col,msg)
	if col then
		col = col
	end
chat.AddText(
iceblue, "[Hera] ",
col, msg)
	if dosound == sound then
		local beep = Sound( "/buttons/button17.wav" )
		local beepsound = CreateSound( LocalPlayer(), beep )
		beepsound:Play()
	end
end

/**************************************
Name: Logger
Purpose: Logs functions and shit
**************************************/ -- ..string.char(92).."Hera"
if !old_fileexist("Hera","DATA") then
	old_filecdir("Hera");
	Hera.Notify(false,lgreen,"Created directory data/Hera/")
end
function Hera:Log(msg)
	if !old_fileexist("Hera/log.txt","DATA") then
		Hera.Notify(false,lblue,"Started log in data/Hera/log.txt")
		old_filewrite("Hera/log.txt","Log started "..os.date().." \n")
	end
	table.insert(Hera.log,"["..os.date("%H:%M:%S").."]: "..msg)
	file.Append("Hera/log.txt","["..os.date().."]: "..msg.."\n")
end

/***********************************************
Name: Hook functions
Purpose: Add hooks and protect from anticheats
************************************************/

-- Hera:RegisterHook
function Hera:RegisterHook(Type,Function)
	Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
	Hera.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
	table.insert(Hera.hooks,Name)
	return old_hookadd(Type,Name,Function)
end

-- Hera:RemoveHook
function Hera:RemoveHook(Type,Function)
	Hera.Print("[REMOVED] Hook: ["..Type.."]")
	return old_hookrem(Type,Function)
end

/**************
Random String
**************/
function Hera:RandomString( len )
	local ret = ""
		for i = 1 , len do
			ret = ret .. string.char( math.random( 65 , 116 ) )
        end
	return ret
end

/**********************
Name: Timer shit
Purpose: Anything timer
***********************/
function Hera:AddTimer( sec, rep, func )
	local index = Hera:RandomString( 10 )	
	Hera.timers[ index ] = sec	
	old_timerc( index, sec, rep, func )
end

/******************************************
Name: ConCommand Shit
Purpose: Anything related to concommands
********************************************/

function Hera:AddCMD(Name,Function)
	table.insert(Hera.concommands,Name)
	Hera.Print("[ADDED] ConCommand: "..Name)
	return old_ccadd(Name,Function)
end

function Hera:RemoveCMD(Name)
	table.Empty(Hera.concommands)
	Hera.Print("[REMOVED] ConCommand: "..Name)
	return old_ccrem(Name)
end

/*******************************************
Name: ConVars
Purpose: Anything with ConVars
********************************************/

function Hera:CreateConVar(convar,str,save,data)
	table.insert(Hera.convars,"Hera_"..convar)
	return CreateClientConVar("Hera_"..convar,str,true,false), Hera.Print("[ADDED] ConVar: Hera_"..convar.." ["..str.."]")
end

/***************************************
Name: RunConsoleCommand shit
Purpose: Detours, Loggers, blockers
****************************************/
Hera.dontlog				= {
"+jump",
"-jump", 
"+attack", 
"-attack", 
"impulse"
} 
Hera.badcmds				= {
"__ac",
"__imacheater",
"gm_possess",
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot",
"birdcage_browse",
"reportmod",
"_fuckme",
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil", -- Fake cmd, but fuck you RIOT servers
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
"excl_banme", -- fuck u bitch
}

/*========================================

Detours, logggers, and other shit

==========================================*/

-- RunConsoleCommand log
function RunConsoleCommand(cmd,...)
	if !table.HasValue(Hera.dontlog, cmd) and !table.HasValue(Hera.convars,cmd) then
		Hera.Print("RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		--Hera:Log("RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		table.insert(Hera.log,"["..os.date("%H:%M:%S").."]: RunConsoleCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
	if !table.HasValue(Hera.badcmds,cmd) then 
		return old_rcc(cmd,...)
	else
		Hera.Notify(sound,red,"Blocked command: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED COMMAND: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return
	end
end

// ConCommand log
function _R.Player.ConCommand(pl,cmd)
	if !table.HasValue(Hera.dontlog, cmd) and !table.HasValue(Hera.concommands,cmd) and !table.HasValue(Hera.badcmds, cmd) then
		Hera.Print("ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return old_ccmd(pl, cmd)
	else
		Hera.Notify(sound, red, "Blocked ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED ConCommand: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		return
	end
end

// concommand.Add log
function concommand.Add(cmd)
	if !table.HasValue(Hera.concommands, cmd) then
		Hera.Print("concommand.Add: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("concommand.Add: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
return old_ccadd(cmd)
end

// concommand.Remove log
function concommand.Remove(cmd)
	if !table.HasValue(Hera.concommands, cmd) then
		Hera.Print("concommand.Remove: "..cmd.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("concommand.Remove: "..cmd.." ["..debug.getinfo(2).short_src.."]")
	end
return old_ccrem(cmd)
end

// RunString log
function RunString(s)
	Hera.Print("RunString: "..tostring(s).." ["..debug.getinfo(2).short_src.."]")
	Hera:Log("RunString: "..tostring(s).." ["..debug.getinfo(2).short_src.."]")
	return old_rs(s)
end

// include log
/*
function include(fn)
	if !table.HasValue(Hera.files, fn) then
		Hera.Print("Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return old_include(fn)
	else
		Hera.Print("BLOCKED Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED Include: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end
*/

// file.Delete log
function file.Delete(fn)
	if !table.HasValue(Hera.files, fn) then
		Hera.Print("file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return old_filedel(fn)
	else
		Hera.Print("BLOCKED file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED file.Delete: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Exists log
function file.Exists(fn, ad)
	if !table.HasValue(Hera.files, fn) then
		Hera.Print("file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return old_fileexist(fn, ad)
	else
		Hera.Print("BLOCKED file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED file.Exists: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Find log
function file.Find(fn)
	if !table.HasValue(Hera.files, fn) then
		Hera.Print("file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return old_filefind(fn)
	else
		Hera.Print("BLOCKED file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED file.Find: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Read log
function file.Read(fn, ad)
	if !table.HasValue(Hera.files, fn) then
		Hera.Print("file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return old_fileread(fn, ad)
	else
		Hera.Print("BLOCKED file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED file.Read: "..fn.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end

// file.Write log
function file.Write(fn, data)
	Hera.Print("file.Write: "..fn.." ["..debug.getinfo(2).short_src.."]")
	Hera:Log("file.Write: "..fn.." ["..debug.getinfo(2).short_src.."]")
	return old_filewrite(fn, data)
end

// timer.Create log (useless)
function timer.Create( index, sec, rep, func)
	Hera.Print("timer.Create: "..index.." ["..debug.getinfo(2).short_src.."]")
	Hera:Log("timer.Create: "..index.." ["..debug.getinfo(2).short_src.."]")
	return old_timerc( index, sec, rep, func )
end

// usermessage.IncomingMessage log
/*
function usermessage.IncomingMessage(name, um, ...)
	if ( name == "ttt_role" ) then
		for k , v in pairs( Hera.traitors ) do
			Hera.traitors = {}
		end
	end
	Hera.Print("usermessage.IncomingMessage: "..name.." ["..debug.getinfo(2).short_src.."]")
	Hera:Log("usermessage.IncomingMessage: "..name.." ["..debug.getinfo(2).short_src.."]")
	return old_usermsginc(name, um, ...);
end
*/

// ConVarExists log
function ConVarExists(cvar)
	if !table.HasValue(Hera.convars,cvar) then
		Hera.Print("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return old_cve(cvar)
	else
		Hera.Print("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		Hera:Log("BLOCKED ConVarExists: "..cvar.." ["..debug.getinfo(2).short_src.."]")
		return;
	end
end


/**************************
Name: Derma shit
Purpose: Anything Derma
***************************/
function Hera:AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(white)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// Hera:AddSlider for the derma
function Hera:AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

Gradient = surface.GetTextureID( "gui/gradient" )
function Hera:DrawBox( x, y, wide, tall, dropsize )
	draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
	draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
end

/*************************
Name: CreatePos
Purpose: Create a position
Credits: BaconBot
***************************/
function Hera:CreatePos(v)
local ply = LocalPlayer()
local ang = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
local nom = v:GetPos()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( v:GetForward() ) * ( dim.y / 2 )
local rgt	= ( v:GetRight() ) * ( dim.x / 2 )
local top	= ( v:GetUp() ) * ( dim.z / 2 )
local bak	= ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local mon = nom + Vector( 0, 0, LocalPlayer():OBBMaxs()[3] )			
local BOXPOS1 = Vector( 16, 16, 0 )
BOXPOS1:Rotate( ang )
BOXPOS1 = ( nom + BOXPOS1 ):ToScreen()
local BOXPOS2 = Vector( 16, -16, 0 )
BOXPOS2:Rotate( ang )
BOXPOS2 = ( nom + BOXPOS2 ):ToScreen()
local BOXPOS3 = Vector( -16, -16, 0 )
BOXPOS3:Rotate( ang )
BOXPOS3 = ( nom + BOXPOS3 ):ToScreen()
local BOXPOS4 = Vector( -16, 16, 0 )
BOXPOS4:Rotate( ang )
BOXPOS4 = ( nom + BOXPOS4 ):ToScreen()
local BOXPOS5 = Vector( 16, 16, 0 )
BOXPOS5:Rotate( ang )
BOXPOS5 = ( mon + BOXPOS5 ):ToScreen()
local BOXPOS6 = Vector( 16, -16, 0 )
BOXPOS6:Rotate( ang )
BOXPOS6 = ( mon + BOXPOS6 ):ToScreen()
local BOXPOS7 = Vector( -16, -16, 0 )
BOXPOS7:Rotate( ang )
BOXPOS7 = ( mon + BOXPOS7 ):ToScreen()
local BOXPOS8 = Vector( -16, 16, 0 )
BOXPOS8:Rotate( ang )
BOXPOS8 = ( mon + BOXPOS8 ):ToScreen()
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8
end


/**************************
Name: GetServerGM
Purpose: Check server's GM
***************************/

function GetServerGM( notify,name )
	if notify == true then
		Hera.Print("This server is using the gamemode '"..GAMEMODE.Name.."'.")
	end
	if ( string.find( string.lower( GAMEMODE.Name ), name ) ) then
		return true
	end
	return false
end

/*************************************
Name: PlayerVisible
Purpose: Check if a player is visible
*************************************/
local function CanSee(ent)    
	local tr = {};	
	tr.start = LocalPlayer():GetShootPos();
	tr.endpos = ent:GetPos() + Vector(0, 0, 5)
	tr.filter = {LocalPlayer(), ent};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end     
end

/**********************************
Name: GetColors
Purpose: Make a cool color!
***********************************/
local function GetColorCrosshair()
	if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
		return 0,255,0,255
	end
	if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
		return 0,0,255,255
	end
	return team.GetColor(LocalPlayer():Team())
end

local function GetColorVisible(e)
	if CanSee(e) then
		return 0,255,0,255
	end
	if !CanSee(e) then
		return 255,0,0,255
	end
end

/*********************
Name: IsVehicle
Purpose: Find vehicles
*********************/
function Hera.IsVehicle( e )	
	local ply = LocalPlayer()	
	if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
		return true
	end
	return false
end

/***************************
Name: SetColors
Purpose: Set Colors
****************************/
function Hera:IsCustomEnt( entclass )
	return table.HasValue( Hera.ents, entclass )
end

function SetColors(e)
	local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
	local col	
	if ( e:IsPlayer() ) then
		col = Color(0,255,0,255)
	elseif ( e:IsNPC() ) then 
		col = Color( 255, 0, 0, 20 )		
	elseif Hera:IsCustomEnt( e:GetClass() ) then
		col = Color( 0, 200, 255, 50 )		
	else
		col = Color( 255, 255, 255, 255 )		
	end	
	return col
end

/******************************
Name: Get Admin Type
Purpose: Get Admin Type..
*******************************/
local function GetAdminType(e)
	if e:IsAdmin() && !e:IsSuperAdmin() then
		return " [A] "
	elseif( e:IsSuperAdmin() ) then
		return " [SA] "
	end
	return " "
end

function Hera:CheckUpdate()
Hera.Print("Checking cheat version...")
	http.Fetch("https://dl.dropbox.com/u/150309237/Hera/version.txt", function(body, len, headers, code) 
		if body == Hera.version then 
			Hera.Notify(sound,green,"Your version of Hera is up to date! You are currently running veresion "..Hera.version) 
		else
			Hera.Notify(sound,red,"Your version of Hera is outdated! Please update to version "..body)
		end 
	end)
end
Hera:CheckUpdate()

function Hera:DoUpdate()
	Hera.Notify(false,green, "Please visit https://dl.dropbox.com/u/150309237/Hera/Hera.lua for the latest update of the cheat.")
end

/****************************
Name: Create ConVars
Purpose: Create ConVars..
*****************************/

Hera:CreateConVar("ESP_Info",0)
Hera:CreateConVar("ESP_Box",0)
Hera:CreateConVar("ESP_Box_Type","3d")
Hera:CreateConVar("ESP_Skeleton",0)
Hera:CreateConVar("ESP_Laser",0)
Hera:CreateConVar("ESP_Crosshair",0)
Hera:CreateConVar("ESP_Crosshair_Type","Swastika")
Hera:CreateConVar("ESP_Chams",0)
Hera:CreateConVar("ESP_Chams_Material","Solid")
Hera:CreateConVar("ESP_Ents",0)
Hera:CreateConVar("ESP_Distance",1000)
Hera:CreateConVar("ESP_Info_Type","info")
Hera:CreateConVar("ESP_Text","outlined")
Hera:CreateConVar("ESP_XRay",0)
Hera:CreateConVar("ESP_PropTrace",0)
Hera:CreateConVar("ESP_HealthBar",0)

Hera:CreateConVar("MISC_Bunnyhop",0)
Hera:CreateConVar("MISC_TTT",0)
Hera:CreateConVar("MISC_ChatSpam",0)
Hera:CreateConVar("MISC_ChatSpam_Msg","visit www.sethhack.seth.im.me.co.cc.net.org.dk.uk.com.gov")
Hera:CreateConVar("MISC_AntiAFK",0)
Hera:CreateConVar("MISC_CSNoclip",0)
Hera:CreateConVar("MISC_CSNoclip_Speed",10)
Hera:CreateConVar("MISC_Thirdperson",0)
Hera:CreateConVar("MISC_RPGod",0)
Hera:CreateConVar("MISC_Namechanger",0)
Hera:CreateConVar("MISC_ShowNotifications",0)
Hera:CreateConVar("MISC_SpeedHack_Speed",3.5)
Hera:CreateConVar("MISC_ShowSpec",0)
Hera:CreateConVar("MISC_ShowAdmins",0)
Hera:CreateConVar("MISC_Thirdperson_dist",200)
Hera:CreateConVar("MISC_Flashlight",0)
Hera:CreateConVar("MISC_Fullbright",0)
Hera:CreateConVar("MISC_RemoveSkybox",0)
Hera:CreateConVar("MISC_NoHands",0)

Hera:CreateConVar("AIM_Friendly",0)
Hera:CreateConVar("AIM_Steam",0)
Hera:CreateConVar("AIM_Admins",0)
Hera:CreateConVar("AIM_Auto",0)
Hera:CreateConVar("AIM_NoRecoil",0)
Hera:CreateConVar("AIM_Offset",0)
Hera:CreateConVar("AIM_AimSpot","Head")
Hera:CreateConVar("AIM_Trigger",0)
Hera:CreateConVar("AIM_SH",0)
Hera:CreateConVar("AIM_Anti",0)
Hera:CreateConVar("AIM_Anti_Type","Invert")
Hera:CreateConVar("AIM_Anti_Angle_X","-181")
Hera:CreateConVar("AIM_Anti_Angle_Z","180")
Hera:CreateConVar("AIM_AntiSnap",0)
Hera:CreateConVar("AIM_AntiSnap_Speed",5)
Hera:CreateConVar("AIM_Fov",180)
Hera:CreateConVar("AIM_Reload",0)
Hera:CreateConVar("AIM_TargetBones",0)
Hera:CreateConVar("AIM_CheckLos",0)
Hera:CreateConVar("AIM_IgnoreNoWep",0)
Hera:CreateConVar("AIM_Prediction",0)
Hera:CreateConVar("AIM_SpawnProtection",0)
//Hera:CreateConVar("AIM_AutoWall",0)
Hera:CreateConVar("MISC_RapidFire",0)
Hera:CreateConVar("AIM_Method","Distance")
Hera:CreateConVar("AIM_Silent",0)
Hera:CreateConVar("AIM_AAA",0)

/***********************************
concommands to find entities and shit
**************************************/

Hera:AddCMD("_ents",function()
	PrintTable(ents.GetAll())
end)

/**********************
Set some ConVars to 0
**********************/
old_rcc("Hera_MISC_ChatSpam","0")
old_rcc("Hera_MISC_CSNoclip","0")
old_rcc("Hera_MISC_NameChanger","0")


--[[
	CHAMS
]]--

-- OnScreen and IsCloseEnough check
function OnScreen(ent)
	local a, f = debug.getregistry().Player["GetAimVector"](LocalPlayer()):Angle() - (ent:GetPos() - LocalPlayer():GetShootPos()):Angle(), debug.getregistry().Player["GetFOV"](LocalPlayer())	
	return (math.NormalizeAngle(a.y) < f + 2 && math.NormalizeAngle(a.p) < f + 2)
end
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Hera_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()			
local mat = Hera:CreateMaterial()
	if GetConVarNumber("Hera_ESP_Chams") == 1 then
		for k,v in pairs(ents.GetAll()) do
			local col;
			if IsValid(v) and (IsCloseEnough(v) and v:IsPlayer() and v:Alive() and v:Health() > 0)  or (IsCloseEnough(v) and v:IsWeapon()) or (IsCloseEnough(v) and v:IsNPC()) then
				if (v:IsPlayer()) then
					col = team.GetColor(v:Team())
				elseif (v:IsWeapon()) then
					col = Color(255,0,0,255)
				elseif (v:IsNPC()) then
					col = Color(0,255,0,255)
				else
					col = Color(255,255,255,255)
				end
				cam.Start3D(EyePos(),EyeAngles())
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255);
					render.SetBlend(col.a / 255);
					render.MaterialOverride( mat )
					v:DrawModel()		
					render.SuppressEngineLighting( false )
					render.SetColorModulation(1,1,1)
					render.MaterialOverride( )
					v:DrawModel()
				cam.End3D()
			end
		end
	end
end

--[[ 
	ESP
]]--

Hera.ents					= { -- ents to be picked up by entity esp, add more if you want.
"ent_pot",
"npc_vendor",
"weapon_perp_glock",
"ent_item",
"ent_prop_item",
"sent_spawnpoint",
"spawned_weapon",
"spawned_shipment",
"weed_plant",
"gift",
"spawned_money",
"base_item",
"weapon_ak47_dayz",
"weapon_mp5_dayz",
"weapon_deagle_dayz",
"sapphire_money_printer",
"amethyst_money_printer",
"topaz_money_printer",
"emerald_money_printer",
"msc_scrapnug",
"food_rawant",
"ent_resource",
"food_rawhead",
"gmodz_item", -- TPS DayZ
"drug_plant",
}

local function GetBoxColor(e)
local LockedTarg = GetTargets();
	if Aimon == 1 and LockedTarg != nil and LockedTarg == e then
		return Color(0,255,255)
	elseif CanSee(e) then
		return Color(0,255,0)
	elseif !CanSee(e) then
		return Color(255,0,0)
	else
		return Color(255,255,255)
	end
end

function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor;
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local InfoCol = white
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp, BOXPOS1, BOXPOS2, BOXPOS3, BOXPOS4, BOXPOS5, BOXPOS6, BOXPOS7, BOXPOS8 = Hera:CreatePos( e )
if( e:Health() <= 100 ) then
	HPColor = Color( 255, e:Health() * 2.55, e:Health() * 2.55, 255 );  // thanks fr1kin/stgn
else
	HPColor = white
end

-- AIMBOT SHIT --
local LockedTarg = GetTargets();
if ( Aimon == 1 and LockedTarg == nil ) or ( Aimon == 1 and LockedTarg == LocalPlayer() ) then
	draw.SimpleTextOutlined("Scanning...","Logo",ScrW() / 2 - 25, ScrH() / 2 + 15, Color(255,0,0,255),4,1,1,black)
elseif Aimon == 1 and LockedTarg != nil then
	draw.SimpleTextOutlined("Locked ("..LockedTarg:Nick()..")","Logo",ScrW() / 2 - 25, ScrH() / 2 + 15, Color(0,255,0,255),4,1,1,black)
end
	
-- WATERMARK --
function Hera:PulsateColor(col)
	return (math.cos(CurTime()*col)+1)/2
end
--draw.SimpleTextOutlined("Hera v"..Hera.version,"Logo",1285,15,Color( 0, 255, Hera:PulsateColor(3)*255, 255 ),4,1,1,black)

		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO --
							if GetConVarNumber("Hera_ESP_Info") == 1 && IsCloseEnough(e) then
								if GetConVarString("Hera_ESP_Text") == "outlined" then
									draw.SimpleTextOutlined( Name..GetAdminType(e), "Hera_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
									draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
									draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, InfoCol, 4, 1, 1, black )
									draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, InfoCol, 4, 1, 1, black)
								elseif GetConVarString("Hera_ESP_Text") == "normal" then		
									draw.SimpleTextOutlined( Name..GetAdminType(e), "Hera_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
									draw.SimpleText( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4, 1 )
									draw.SimpleText( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, InfoCol, 4, 1 )
									draw.SimpleText( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, InfoCol, 4, 1 )
								end								
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
							end
							
							-- ESP BOX --
							if GetConVarNumber("Hera_ESP_Box") == 1 && IsCloseEnough(e) then
								if GetConVarString("Hera_ESP_Box_Type") == "2d" then
									surface.SetDrawColor(GetBoxColor(e))				
									surface.DrawLine( maxX, maxY, maxX, minY )
									surface.DrawLine( maxX, minY, minX, minY )					
									surface.DrawLine( minX, minY, minX, maxY )
									surface.DrawLine( minX, maxY, maxX, maxY )
								elseif GetConVarString("Hera_ESP_Box_Type") == "3d" then	
									surface.SetDrawColor(GetBoxColor(e))
									-- thanks nano
									surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS2.x, BOXPOS2.y )
									surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS3.x, BOXPOS3.y )
									surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS4.x, BOXPOS4.y )
									surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS1.x, BOXPOS1.y )
			
									surface.DrawLine( BOXPOS5.x, BOXPOS5.y, BOXPOS6.x, BOXPOS6.y )
									surface.DrawLine( BOXPOS6.x, BOXPOS6.y, BOXPOS7.x, BOXPOS7.y )
									surface.DrawLine( BOXPOS7.x, BOXPOS7.y, BOXPOS8.x, BOXPOS8.y )
									surface.DrawLine( BOXPOS8.x, BOXPOS8.y, BOXPOS5.x, BOXPOS5.y )
			
									surface.DrawLine( BOXPOS1.x, BOXPOS1.y, BOXPOS5.x, BOXPOS5.y )
									surface.DrawLine( BOXPOS2.x, BOXPOS2.y, BOXPOS6.x, BOXPOS6.y )
									surface.DrawLine( BOXPOS3.x, BOXPOS3.y, BOXPOS7.x, BOXPOS7.y )
									surface.DrawLine( BOXPOS4.x, BOXPOS4.y, BOXPOS8.x, BOXPOS8.y )
								end
							end
							-- ESP SKELETON --
							if GetConVarNumber("Hera_ESP_Skeleton") == 1 && IsCloseEnough(e) then
								for k, v in pairs( Hera.espbones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
									if e:IsPlayer() and !e:IsNPC() then
										surface.SetDrawColor(team.GetColor(e:Team()))
									end
									surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Hera_ESP_Laser") == 1 and LocalPlayer():Alive() then
								local LaserColor = Color(255,0,0,255)
								if Aimon == 1 and LockedTarg != nil and LockedTarg != LocalPlayer() then
									LaserColor = Color(0,255,0,255)
								else
									LaserColor = LaserColor
								end
								local ViewModel = LocalPlayer():GetViewModel()
								local Attach = ViewModel:LookupAttachment("1")
								if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment("muzzle") end
								if !LocalPlayer():Alive() then return end;
								if( LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then
									if( !table.HasValue( Hera.laser, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
										local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()));
										cam.Start3D( EyePos() , EyeAngles())								
											-- Laser
											StartPos = ViewModel:GetAttachment( Attach ).Pos
											EndPos = LocalPlayer():GetEyeTrace().HitPos
											render.SetMaterial( Material( "trails/laser" ) )
											render.DrawBeam(StartPos, EndPos , 3, 0, 0, LaserColor)								
											-- End
											render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
											render.DrawQuadEasy(tr.HitPos, (EyePos() - tr.HitPos), 10, 10, LaserColor, 0 )
										cam.End3D()
									end
								end
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Hera_ESP_Crosshair") == 1 and GetConVarNumber("Hera_MISC_Thirdperson") == 0 then
								if GetConVarString("Hera_ESP_Crosshair_Type") == "Spinning" then
									local x, y = ScrW() / 2, ScrH() / 2	
									local Speed
									if Aimon == 1 and AimbotTarget != nil and AimbotTarget != LocalPlayer() then
										Speed = 5
									else
										Speed = 1
									end
									surface.SetDrawColor(GetColorCrosshair()) 
									CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
									CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
									mathsin = math.sin(CurTime()*Speed)*4
									mathcos = math.cos(CurTime()*Speed)*4
									mathsin2 = math.sin(CurTime()*Speed+0.1)*4
									mathcos2 = math.cos(CurTime()*Speed+0.1)*4
									mathsin3 = math.sin(CurTime()*Speed-0.1)*4
									mathcos3 = math.cos(CurTime()*Speed-0.1)*4
									surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
									surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
									surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
									surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
								elseif GetConVarString("Hera_ESP_Crosshair_Type") == "Swastika" then
									surface.SetDrawColor(red)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
									surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)
									surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
									surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
								elseif GetConVarString("Hera_ESP_Crosshair_Type") == "Basic" then
									local x, y, s = ScrW() / 2, ScrH() / 2, 10
									surface.SetDrawColor(GetColorCrosshair()) 
									surface.DrawLine( x, y - s, x, y + s )
									surface.DrawLine( x - s, y, x + s, y )
								elseif GetConVarString("Hera_ESP_Crosshair_Type") == "Diagonal" then
									local x, y, w = ScrW() / 2, ScrH() / 2, 7
									surface.SetDrawColor(GetColorCrosshair()) 
									surface.DrawLine(x - w, y - w, x + w, y + w)
									surface.DrawLine(x - w, y + w, x + w, y - w)									
								end
							end
							
							-- NOCLIP MARKER --
							if GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
								local me_pos = LocalPlayer():EyePos():ToScreen()
								draw.SimpleText("YOU ARE HERE", "ESPFont_Small", me_pos.x,me_pos.y +10, red, 4, 1 ) // skiddie shit
							end
					end
				end
			end
		end
	end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and Hera:IsCustomEnt( v:GetClass() ) ) then
			if GetConVarNumber("Hera_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleText(wname, "ESPFont_Small", entpos.x,entpos.y +10, red, 4, 1 )
				surface.SetDrawColor(255,0,255,255)
			end
		end                    
	end
end 

function XRay()
local mat = Hera:CreateMaterial()
cam.Start3D(EyePos(), EyeAngles())
	for k,v in pairs(ents.FindByClass("prop_*")) do
	if (!CanSee(v)) then
		PropColor = COLOR_NONVISIBLE
	else
		PropColor = COLOR_VISIBLE
	end	
	if v:GetVelocity():Length() == 0 then
		PropColor = COLOR_FROZEN
	end
	if v:GetVelocity():Length() == 0 and (!CanSee(v)) then
		PropColor = COLOR_FROZEN_NV
	end
		if GetConVarNumber("Hera_ESP_XRay") == 1 then
			if IsValid(v) and table.HasValue(Hera.props,v:GetModel()) and IsCloseEnough(v) then
				render.SuppressEngineLighting( true )
				render.SetColorModulation(PropColor.r / 255, PropColor.g / 255, PropColor.b / 255)
				render.SetBlend(PropColor.a / 255);
				render.MaterialOverride( mat )
				v:DrawModel()		
				render.SuppressEngineLighting( false )
				render.SetColorModulation(1,1,1)
				render.MaterialOverride()
				v:DrawModel()
				v:SetRenderMode(RENDERMODE_TRANSALPHA)
			else
				v:SetColor(Color(255, 255, 255, 255))
			end
		end
	end
cam.End3D()
end



/*****************************************
Name: Aimbot/Aim functions
Purpose: Aim for you, because you suck
Credits: isis
*******************************************/


local shouldFire = 0
// So ugly, ugh.
// There's better ways of doing this, but making a "toggle" function seemed best.
function RapidFire()
	if GetConVarNumber("Hera_MISC_RapidFire") == 1 and input.IsMouseDown(MOUSE_LEFT) then
		if shouldFire == 0 then
			shouldFire = 1
		else 
			shouldFire = 0
		end
		if shouldFire == 0 then
			old_rcc("+attack")
		else
			old_rcc("-attack")
		end
		elseif shouldFire == 0 then
			old_rcc("-attack")
		if shouldFire == 0 then
			shouldFire = 1
		else
			shouldFire = 0

		end
	end
end


/****************************************
Aimbot functions
****************************************/

/********
bonescan
hermes v1
*******/

-- get owned
function IsSpawnProtected(ent)
	if ((GAMEMODE.Name):lower()):find("stronghold") then
		local entcol = ent:GetColor(r, g, b, a)
		if entcol.a < 255 then
			return true
		else
			return false
		end
	end
end

function AimSpot(ent)
	if GetConVarNumber("Hera_AIM_TargetBones") == 0 then
		local eyes = ent:LookupAttachment("eyes")
		if GetConVarNumber("Hera_AIM_AAA") == 1 and (ent:EyeAngles().p < -89) then
			return ent:LocalToWorld( ent:OBBCenter())
		elseif(eyes ~= 0) then
			eyes = ent:GetAttachment(eyes)
			if(eyes and eyes.Pos) then
				return eyes.Pos, eyes.Ang
			end
		end
	end

local bonename = Hera.aimmodels[ent:GetModel()]
	if(not bonename) then
		for k, v in pairs(Hera.bones) do
			if(v[1] == GetConVarString("Hera_AIM_AimSpot")) then
				bonename = v[2]
			end
		end
		bonename = bonename or "ValveBiped.Bip01_Head1"
	end
	local aimbone = ent:LookupBone(bonename);
	if(aimbone) then
		local pos, ang = ent:GetBonePosition(aimbone)
		return pos, ang;
	end
return ent:LookupBone("ValveBiped.Bip01_Head1")
--return ent:LocalToWorld(ent:OBBCenter())
end

function Exception(ent)
	if (ent == LocalPlayer()) then return false end
	if (ent:Team() == TEAM_SPECTATOR) then return false end
	if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
	if (!ent:Alive() ) then return false end
	if (ent:InVehicle()) then return false end 
	if (GetConVarNumber("Hera_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end 
	if (ent:IsPlayer() and (ent:IsAdmin() or ent:IsSuperAdmin()) and GetConVarNumber("Hera_AIM_Admins") == 0) then return false end	
	if (GetConVarNumber("Hera_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
	if (GetConVarNumber("Hera_AIM_SH") == 1 && IsSpawnProtected(ent)) then return false end
	if (ent:IsPlayer() and GetConVarNumber("Hera_AIM_IgnoreNoWep") == 1 and not IsValid(ent:GetActiveWeapon())) then return false end
	if (GetConVarNumber("Hera_AIM_SpawnProtection") == 1 and ent:GetColor(r, g, b, a).a < 255) then return false end
return true
end

function HasLOS(ent)
	if(GetConVarNumber("Hera_AIM_CheckLOS") == 0) then return true end
	local trace = util.TraceLine( {
		start = LocalPlayer():GetShootPos(),
		endpos = AimSpot(ent),
		filter = { LocalPlayer(), e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if (( trace.Fraction >= 0.99 )) then return true end
	return false
end

function InFov( ent )
	local fov = GetConVarNumber("Hera_AIM_Fov")
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetBonePosition( ent:LookupBone("ValveBiped.Bip01_Head1") ) - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

/*
 local p, t = Vector(0, 0, 0), Vector(0, 0, 0)
if ( distance < 4000 && speed > 0 ) then p = self():GetVelocity() * distance / (speed * distance * 0.125) end
if ( weapon:IsWeapon() && prediction[weapon:GetClass()] != 0 ) then t = target:GetVelocity() * distance / (prediction[weapon:GetClass()] || 150000) end

vector = vector - p + t
end
*/

function AimPrediction( pos , pl )
	if IsValid( pl ) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local weapon = ( LocalPlayer().GetActiveWeapon and ( IsValid( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )	
		if weapon and Hera.prediction[ weapon ] then
			local time = distance / Hera.prediction[ weapon ]
			return pos + pl:GetVelocity() * time
		end
	end
	return pos
end

function NormalizeAng(angle)
	if type(angle) == "Angle" then
		return Angle(math.NormalizeAngle(angle.p) , math.NormalizeAngle(angle.y) , math.NormalizeAngle(angle.r))
	end
	return angle
end

function GetTargets()
local target;
if target == nil then target = LocalPlayer() else target = target end
local ply = LocalPlayer()
local angA, angB = 0
local x, y = ScrW(), ScrH()
local distance = math.huge;
	for k, v in pairs(player.GetAll()) do
		if (v != LocalPlayer() and v:Alive() and HasLOS(v) and Exception(v) and InFov(v)) then
			local ePos, oldPos, myAngV = v:EyePos():ToScreen(), target:EyePos():ToScreen(), ply:GetAngles()
			local thedist = v:GetPos():DistToSqr(LocalPlayer():GetPos());
			angA = math.Dist( x / 2, y / 2, oldPos.x, oldPos.y )
			angB = math.Dist( x / 2, y / 2, ePos.x, ePos.y )
			if GetConVarString("Hera_AIM_Method") == "Closest To Crosshair" then
				if ( angB <= angA ) then
					target = v;
				elseif target == ply then
					target = v;
				end
			elseif GetConVarString("Hera_AIM_Method") == "Distance" then
				if (thedist < distance) then
					distance = thedist;
					target = v;
				end					
			end
		end
	end
return target
end

local function Aimbot(ucmd)
local asspeed = GetConVarNumber("Hera_AIM_AntiSnap_Speed") / 10
local aimang = Angle(0,0,0)
	if Aimon == 1 then		
		local target = GetTargets()
		if target != nil and target != LocalPlayer() then
	
		-- Offset
		local Aimspot;
		if GetConVarNumber("Hera_AIM_Prediction") == 1 then
			Aimspot = AimPrediction(AimSpot(target)) - Vector(0,0,GetConVarNumber("Hera_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() * ( 1 / 66 ) - LocalPlayer():GetVelocity() * ( 1 / 66 )
		else
			Aimspot = (AimSpot(target)) - Vector(0,0,GetConVarNumber("Hera_AIM_Offset"))
			Aimspot = Aimspot + target:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
		end
		Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angel.p = math.NormalizeAngle( Angel.p )
		Angel.y = math.NormalizeAngle( Angel.y )
		
		-- Anti snap
		if GetConVarNumber("Hera_AIM_AntiSnap") == 1 then 
			Angle1 = LocalPlayer():EyeAngles()
			local Smooth1 = math.Approach(Angle1.p, Angel.p, asspeed)
			local Smooth2 = math.Approach(Angle1.y , Angel.y, asspeed)       
			aimang = Angle (Smooth1, Smooth2, 0)
		else
			-- Normal
			aimang = Angle( Angel.p, Angel.y, 0 )
		end
		-- faggot
			_G.debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, aimang)
			if GetConVarNumber("Hera_AIM_Auto") == 1 then
               ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK)) 
			end
			if GetConVarNumber("Hera_AIM_SH") == 1 then
				ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
			end
		end
	end
end

Hera:AddCMD("+Hera_Aim",function()
Aimon = 1
end)

Hera:AddCMD("-Hera_Aim",function()
Aimon = 0
end)

/**************************
Name: Anti-Aim
Purpose: HVH feature
**************************/
Hera:RegisterHook("CreateMove",function(cmd, u)
local caim
local getangs = cmd:GetViewAngles()
	if GetConVarNumber("Hera_AIM_Anti") == 1 then
		if GetConVarString("Hera_AIM_Anti_Type") == "Invert" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(181, getangs.y, 180))
			end
		elseif GetConVarString("Hera_AIM_Anti_Type") == "Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = Angle(0,math.random(-89,89),0) 
				cmd:SetViewAngles(NormalizeAng(caim))
			end
		elseif GetConVarString("Hera_AIM_Anti_Type") == "Random Pitch" then
			if (!LocalPlayer():KeyDown(IN_ATTACK)) then
				cmd:SetViewAngles(Angle(math.random(181,180), getangs.y, 180))
			end	
		elseif GetConVarString("Hera_AIM_Anti_Type") == "Invert/Spin" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				caim = math.random(-89,89)
				cmd:SetViewAngles(Angle(181, NormalizeAng(caim), 180))
			end
		elseif GetConVarString("Hera_AIM_Anti_Type") == "Var" then
			if (!LocalPlayer():KeyDown(IN_ATTACK) and !LocalPlayer():KeyDown(IN_ATTACK2)) then
				cmd:SetViewAngles(Angle(GetConVarNumber("Hera_AIM_Anti_Angle_X"),getangs.y,GetConVarNumber("Hera_AIM_Anti_Angle_Z")))
			end
		end
	end
end)

local LastReload = 0
local dontreload = {"weapon_physgun" , "gmod_tool" , "weapon_gravgun", "weapon_keys", "weapon_pocket", "pocket", "rp_pocket", "rp_keys", "keys"}
function AutoReload()
    if (GetConVarNumber("Hera_AIM_Reload") == 1 and LocalPlayer():Alive() and IsValid( LocalPlayer():GetActiveWeapon() ) and !table.HasValue( dontreload, LocalPlayer():GetActiveWeapon():GetClass() ) ) then
		if( LocalPlayer():GetActiveWeapon():Clip1() <= 0 and CurTime() > ( LastReload + 5 ) ) then
			old_rcc( "+reload" )
			LastReload = CurTime()
			Hera:AddTimer( .2, 1, function()
				old_rcc( "-reload" )
			end )
		end
    end
end

local function StartFire()
	old_rcc("+attack")
end

local function StopFire()
	old_rcc("-attack")
end
-- thx hyperion
function TriggerBot()
	if(GetConVarNumber("Hera_AIM_Trigger") == 1) then
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {};
		tracedata.start = pos
		tracedata.endpos = pos+(ang*9999999999999)
		local trace = util.TraceLine(tracedata)
		if(trace.HitNonWorld) then
			target = trace.Entity
			if(target:IsPlayer()) then
				StartFire()
				timer.Simple(0.1, StopFire)
			end
		end
	end
end

/****************************
Name: Misc
Purpose: Misc features
*****************************/
local Speedhacking = false
-- i use a private module for my convar forcing, so anyone else will use cvar3
Hera:AddCMD("+Hera_Speed",function()
Speedhacking = true
	if Hera:IsDev(LocalPlayer()) then
	--	hera.ForceCVar(GetConVar("sv_cheats"):SetValue(1))
	--	hera.ForceCVar(GetConVar("host_timescale"):SetValue(GetConVarNumber("Hera_MISC_SpeedHack_Speed")))
		old_rcc("sp00f_bs_host_timescale",GetConVarNumber("Hera_MISC_SpeedHack_Speed"));
	else
		GetConVar("sv_cheats"):SetValue(1)
		GetConVar("host_timescale"):SetValue(GetConVarNumber("Hera_MISC_SpeedHack_Speed"))
	end
end)

Hera:AddCMD("-Hera_Speed",function()
Speedhacking = false
	if Hera:IsDev(LocalPlayer()) then
		--hera.ForceCVar(GetConVar("sv_cheats"):SetValue(0))
		--hera.ForceCVar(GetConVar("host_timescale"):SetValue(1))
		old_rcc("sp00f_bs_host_timescale",1)
	else
		GetConVar("sv_cheats"):SetValue(0)
		GetConVar("host_timescale"):SetValue(1)
	end
end)

/*
local next_change = GetConVarNumber("sv_namechange_cooldown_seconds") + 0.5
function NameChanger()
local ply = LocalPlayer()
local e = player.GetAll()[ math.random( 1, #player.GetAll() ) ]
local curtime = CurTime()
	if GetConVarNumber("Hera_MISC_Namechanger") == 1 and Hera:IsDev(LocalPlayer()) then
		if next_change < curtime then
			if ( !e:IsAdmin() && e != ply ) then
				Hera:AddTimer( 1, 1 , function()
					if ((GAMEMODE.Name):lower()):find("darkrp") then
						LocalPlayer():ConCommand("say /rpname ".. e:Nick() .. " %" ) // 'can't rp name ~'
					else
						LocalPlayer():ConCommand( "bs_namechange " .. e:Nick() .. " ~" )
						Hera.Notify(false,Color(255,255,255),"Changed your name to "..e:Nick().." ~")
					end
				end)
			end
		end
	end
end
Hera:AddTimer( next_change , 0 , function() NameChanger() end )
*/

Hera:RegisterHook("CreateMove",function(cmd)
	if GetConVarNumber("Hera_MISC_BunnyHop") == 1 and bit.band( cmd:GetButtons(), IN_JUMP ) ~= 0 then
		if !LocalPlayer():IsOnGround() then
			cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		end
	end
end)

function Misc()
	if GetConVarNumber("Hera_AIM_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
	if GetConVarNumber("Hera_MISC_ChatSpam") == 1 then
		LocalPlayer():ConCommand("say "..GetConVarString("Hera_MISC_ChatSpam_Msg").."["..math.random(1,999).."]")
	end
	if GetConVarNumber("Hera_MISC_RPGod") == 1 then
		if LocalPlayer():Health() < 100 then
			LocalPlayer():ConCommand("say /buyhealth") -- spam buyhealth
		end
	end
	if GetConVarNumber("Hera_MISC_Flashlight") == 1 then
		old_rcc("impulse","100")
	end
	if GetConVarNumber("Hera_MISC_Fullbright") == 1 then
		GetConVar("mat_fullbright"):SetValue(1)
	else
		GetConVar("mat_fullbright"):SetValue(0)
	end
	if GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
		CS_NC = LocalPlayer():EyePos();
	end
	if GetConVarNumber("Hera_MISC_RemoveSkybox") == 1 then
		GetConVar("gl_clear"):SetValue(1)
		GetConVar("r_drawskybox"):SetValue(0)
		GetConVar("r_3dsky"):SetValue(0)
	else
		GetConVar("gl_clear"):SetValue(0)
		GetConVar("r_drawskybox"):SetValue(1)
		GetConVar("r_3dsky"):SetValue(1)
	end
end

Hera:RegisterHook("CalcView",function(ply, pos, angles, fov)
	if GetConVarNumber("Hera_MISC_Thirdperson") == 1 and LocalPlayer():Alive() then
		local view = {}
		view.origin = pos-(angles:Forward()*GetConVarNumber("Hera_MISC_Thirdperson_Dist"))
		view.angles = angles
		view.fov = fov
		return view
	elseif(GetConVarNumber("Hera_MISC_CSNoclip") == 1 and CS_NC) then
		local ang = angles:Forward()
		if LocalPlayer():KeyDown( IN_FORWARD ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
		CS_NC = CS_NC + LocalPlayer():GetAimVector() * speed
		end
		if LocalPlayer():KeyDown( IN_BACK ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC - LocalPlayer():GetAimVector() * speed
		end
		if LocalPlayer():KeyDown( IN_MOVERIGHT ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC + ang:Angle():Right() * speed
		end
		if LocalPlayer():KeyDown( IN_MOVELEFT ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC - ang:Angle():Right() * speed
		end
		if LocalPlayer():KeyDown( IN_JUMP ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			CS_NC = CS_NC + Vector( 0, 0, speed )
		end
		if LocalPlayer():KeyDown( IN_SPEED ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			speed = ( GetConVarNumber("Hera_MISC_CSNoclip_Speed") * 3 * ( FrameTime() / 2 ) ) * 100
		elseif LocalPlayer():KeyDown( IN_DUCK ) and GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
			speed = ( GetConVarNumber("Hera_MISC_CSNoclip_Speed") / 3 * ( FrameTime() / 2 ) ) * 100
		else
			speed = ( GetConVarNumber("Hera_MISC_CSNoclip_Speed") * ( FrameTime() / 2 ) ) * 100
		end
		local view = {}
		view.origin = CS_NC
		view.angles = angles
		view.fov = fov
		return view
	else
		CS_NC = LocalPlayer():EyePos()
	end
	return GAMEMODE:CalcView(ply, pos, angles, fov)
end)
Hera:RegisterHook("ShouldDrawLocalPlayer",function()
	if GetConVarNumber("Hera_MISC_Thirdperson") == 1 then
		return true -- pro
	end
end)
function CSNoclip(ucmd)
	if GetConVarNumber("Hera_MISC_CSNoclip") == 1 then
		ucmd:SetForwardMove(0);
		ucmd:SetSideMove(0);
		ucmd:SetUpMove(0);
	end
end


function ShowNotifi()
	-- now spectating
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
			if(not table.HasValue(Hera.spectators, v)) then
				table.insert(Hera.spectators, v);
				if GetConVarNumber("Hera_MISC_ShowSpec") == 1 then
					Hera.Notify(true,red,""..v:Nick().." is now spectating you!")
					surface.PlaySound("buttons/blip1.wav")
				end
			end
		end
	end
	-- no longer spectating
	for k, v in pairs(Hera.spectators) do
		if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
			table.remove(Hera.spectators, k);
			if GetConVarNumber("Hera_MISC_ShowSpec") == 1 then
				Hera.Notify(true,green,""..v:Nick().." is no longer spectating you!")
			end
		end
	end
	-- admin join
	if GetConVarNumber("Hera_MISC_ShowAdmins") == 1 then
		for k, v in pairs(player.GetAll()) do
			if (v:IsAdmin() and not table.HasValue(Hera.admins, v)) then
				table.insert(Hera.admins, v);
				Hera.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
				surface.PlaySound("buttons/blip1.wav");
			end
		end
	end
end


local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
	if GetConVarNumber("Hera_MISC_AntiAFK") == 1 then
		local command1 = table.Random( commands )
		local command2 = table.Random( commands )
		Hera:AddTimer( 1, 1, function() 
			old_rcc( "+"..command1 ) 
			old_rcc( "+"..command2 ) 
		end )
		Hera:AddTimer( 2, 1, function() 
			old_rcc("-"..command1 ) 
			old_rcc("-"..command2 ) 
		end )
	end
end
Hera:AddTimer( 5 , 0 , function() AntiAfk() end )

// Traitor finder functions
local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local UsedWeapons = {}
		local MapWeapons = {}
function IsATraitor( ply )
	for k, v in pairs( Hera.traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end
Hera.tweps					= {
"weapon_ttt_c4",
"weapon_ttt_knife", 
"weapon_ttt_phammer", 
"weapon_ttt_sipistol", 
"weapon_ttt_flaregun", 
"weapon_ttt_push", 
"weapon_ttt_radio", 
"weapon_ttt_teleport", 
"(Disguise)", 
}
timer.Create("TTT", 0.8, 0, function()
	if GetConVarNumber("Hera_MISC_TTT") == 1 then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass( "player" ) ) do 
				if IsValid( v ) then
					if (!v:IsDetective()) then
						if v:Team() ~= TEAM_SPECTATOR then
							for wepk, wepv in pairs( Hera.tweps ) do
								for entk, entv in pairs( ents.FindByClass( wepv ) ) do
									if IsValid( entv ) then
										cookie.Set( entv, 100 - wepk )
										if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
											if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
												local EntPos = ( entv:GetPos() - Vector(0,0,35) )
													if entv:GetClass() == wepv then
														if v:GetPos():Distance( EntPos ) <= 1 then
															table.insert( Hera.traitors, v )
															Hera.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
															old_rcc("say",v:Nick() .. " is a traitor and I can prove it!")
															if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
																table.insert( UsedWeapons, cookie.GetNumber( entv ) )
															else
															if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
																table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end )

Hera:RegisterHook("HUDPaint",function()
	if GetConVarNumber("Hera_MISC_TTT") == 1 then
		for k, e in pairs( Hera.traitors ) do
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = Hera:CreatePos( e )
			if IsValid( e ) then
				if e:Team() ~= TEAM_SPECTATOR then
					if ( !e:IsDetective() ) then
						PlayerIsTraitor = true
						draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
					end
				end
			end
		end
	end
end)

Hera:RegisterHook("TTTPrepareRound",function()
timer.Simple( 2, function()
	for k, v in pairs( Hera.traitors ) do
		table.remove( Hera.traitors, k )
		Hera.traitors = {}
	end
		for k, v in pairs( UsedWeapons ) do
			table.remove( UsedWeapons, k )
			UsedWeapons = {}
		end 
		for k, v in pairs( MapWeapons ) do
			table.remove( MapWeapons, k )
			MapWeapons = {}
		end 
	end ) 
end )
	end 
end )

/*************************
MENU FUNCTIONS
*************************/
Hera:AddCMD("+Hera_Menu", function()
Menu = vgui.Create("DFrame")
Menu:SetSize(450,360)
Menu:SetTitle("                                                  :: Hera :: Version "..Hera.version.." ::") -- Ignore the spacing.
Menu:Center()
Menu:MakePopup()
Menu.Paint = function()
local mW, mH, x, y = Menu:GetWide(), Menu:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color(100,100,255,50 ) ) -- old color: 116,187,251,50
surface.SetDrawColor(black);
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet = vgui.Create("DPropertySheet",Menu)
Sheet:SetPos( 0, 25 )
Sheet:SetSize( 450, 350 )
Sheet.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), Color(0,0,0,150) )
end

// fuck;
local Page1 = vgui.Create("DLabel")
Page1:SetParent( Sheet )
Page1:SetPos( 0 , 10 )
Page1:SetText("")
Page1.Paint = function()
draw.SimpleTextOutlined("Hera v"..Hera.version.." - A Cheat By Tyler","Logo",100,3,cyan,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
draw.SimpleTextOutlined("Updates","Logo",190,60,lgreen,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,black)
end
local Page2 = vgui.Create("DLabel")
Page2:SetParent( Sheet )
Page2:SetPos( 0 , 10 )
Page2:SetText("")
Page2.Paint = function()
end
local Page3 = vgui.Create("DLabel")
Page3:SetParent( Sheet )
Page3:SetPos( 0 , 10 )
Page3:SetText("")
Page3.Paint = function()
end
local Page4 = vgui.Create("DLabel")
Page4:SetParent( Sheet )
Page4:SetPos( 0 , 10 )
Page4:SetText("")
Page4.Paint = function()
end
local Page5 = vgui.Create("DLabel")
Page5:SetParent( Sheet )
Page5:SetPos( 0 , 10 )
Page5:SetText("")
Page5.Paint = function()
end
-----------------------
--[[ MAIN TAB SHIT ]]--
-----------------------
// LOAD SHIT
local ReloadHooksButton = vgui.Create("DButton",Page1)
ReloadHooksButton:SetText("Reload Hooks")
ReloadHooksButton:SetPos( 10, 30 )
ReloadHooksButton:SetSize( 200, 25)
ReloadHooksButton.DoClick = function()
Hera.hooks:reload()
Hera.Notify(green,"Reloaded hooks")
end

local UnloadCheat = vgui.Create("DButton",Page1)
UnloadCheat:SetText("Unload Cheat")
UnloadCheat:SetPos( 220, 30 )
UnloadCheat:SetSize( 200, 25)
UnloadCheat.DoClick = function()
Hera:unload()
Hera.Notify(red,"UNLOADED ENTIRE CHEAT!")
end

// UPDATE SHIT
local CheckUpdate = vgui.Create("DButton",Page1)
CheckUpdate:SetText("Check for updates")
CheckUpdate:SetPos( 10,90 )
CheckUpdate:SetSize( 200, 25)
CheckUpdate.DoClick = function()
Hera:CheckUpdate()
end

local DoUpdate = vgui.Create("DButton",Page1)
DoUpdate:SetText("Update the cheat")
DoUpdate:SetPos( 220,90 )
DoUpdate:SetSize( 200, 25)
DoUpdate.DoClick = function()
Hera:DoUpdate()
end

// Log viewer
local LogPanel = vgui.Create("DPanelList",Page1)
	LogPanel:SetPos( 10,100 ) 
	LogPanel:SetSize( Sheet:GetWide()-22, 195) 
	LogPanel:SetSpacing( 5 ) 
	LogPanel:EnableHorizontal( false ) 
	LogPanel:EnableVerticalScrollbar( false ) 
local DLog = vgui.Create("DListView", LogPanel) 
	DLog:SetPos(2,24) DLog:SetMultiSelect(false) 
	DLog:SetSize(LogPanel:GetWide()-19,LogPanel:GetTall()-28) 
	DLog:AddColumn("Log")
	DLog:SetMultiline( true )
for i=#Hera.log,1,-1 do 
	DLog:AddLine(Hera.log[i]) 
end 

local ClearLogs = vgui.Create("DButton",Page1)
ClearLogs:SetText("Clear log")
ClearLogs:SetPos( 120, 290 )
ClearLogs:SetSize( 200, 20)
ClearLogs.DoClick = function()
Hera.log = {};
Hera.Notify(false,Color(255,255,255),"Cleared log.")
end

-------------------------
--[[ AIMBOT TAB SHIT ]]--
-------------------------
Hera:AddCheckBox("Autoshoot","Hera_AIM_Auto",Page2,10,10,"Autoshoot when locked")
Hera:AddCheckBox("Friendly Fire","Hera_AIM_Friendly",Page2,10,30,"Target your own team")
Hera:AddCheckBox("Target Steam Friends","Hera_AIM_Steam",Page2,10,50,"Target Steam Friends")
Hera:AddCheckBox("Target Admins","Hera_AIM_Admins",Page2,10,70,"Target Admins")
Hera:AddCheckBox("No-Recoil","Hera_AIM_NoRecoil",Page2,10,90,"Remove Recoil")
Hera:AddCheckBox("Triggerbot","Hera_AIM_Trigger",Page2,10,110,"Auto-shoots when looking at a player")
Hera:AddCheckBox("Stronghold mode","Hera_AIM_SH",Page2,10,130,"Aims down sights when locked, to reduce spread.")
Hera:AddCheckBox("Anti-Aim","Hera_AIM_Anti",Page2,10,150,"HvH feature, makes it 'harder' for others to aimbot you.")
Hera:AddCheckBox("Anti Anti-Aim","Hera_AIM_AAA",Page2,10,170,"HvH feature, target center if target has anti-aim [Must have 'Target Bone' on]")
Hera:AddCheckBox("Anti-Snap","Hera_AIM_AntiSnap",Page2,200,10,"Changes the speed of the aimbot, making it look more legit")
Hera:AddCheckBox("Auto Reload","Hera_AIM_Reload",Page2,200,30,"Reload when you run out of ammo")
Hera:AddCheckBox("Target Bones","Hera_AIM_TargetBones",Page2,200,50,"Target custom bone instead of eye position")
Hera:AddCheckBox("Ignore Weaponless Players","Hera_AIM_IgnoreNoWep",Page2,200,70,"Ignore players that don't have a weapon")
Hera:AddCheckBox("Check LOS","Hera_AIM_CheckLos",Page2,200,90,"Check line-of-sight")
Hera:AddCheckBox("Prediction","Hera_AIM_Prediction",Page2,200,110,"Predict time/distance making the aimbot more accurate")
Hera:AddCheckBox("Anti Spawn Protection","Hera_AIM_SpawnProtection",Page2,200,130,"Ignore spawn protected players.")
--Hera:AddCheckBox("Auto Wall","Hera_AIM_AutoWall",Page2,200,150,"Shoot through penetrable surfaces, works best with Mad Cow's weapons")

Hera:AddSlider("Anti-Aim Angle X","Hera_AIM_Anti_Angle_X",Page2,-181,180,1,10,190,350,"Anti-Aim Angle X (For advanced users only)")
Hera:AddSlider("Anti-Aim Angle Z","Hera_AIM_Anti_Angle_Z",Page2,-181,180,1,10,210,350,"Anti-Aim Angle Z (For advanced users only)")
Hera:AddSlider("Field Of View","Hera_AIM_Fov",Page2,0,180,1,10,230,350,"FOV in which the aimbot will target players")
Hera:AddSlider("Anti-Snap Speed","Hera_AIM_AntiSnap_Speed",Page2,0,50,1,10,250,350,"Changes your anti-snap speed")
Hera:AddSlider("Aimbot Offset","Hera_AIM_Offset",Page2,-25,25,1,10,270,350,"Offsets your aimspot")

local AimLabel1 = vgui.Create("DLabel")
AimLabel1:SetParent( Page2 )
AimLabel1:SetPos(350,265)
AimLabel1:SetText("Aimspot")
AimLabel1:SetTextColor(Color(255,255,255,255))
AimLabel1:SizeToContents()

local AimList = vgui.Create( "DComboBox", Page2)
AimList:SetPos(350,280)
AimList:SetSize( 82, 20 )
for k, v in pairs(Hera.bones) do
	AimList:AddChoice(v[1]);
end
AimList.OnSelect = function(self)
	Hera.Notify(false,lblue,"Set aimspot to bone "..self:GetValue()..".")
	old_rcc("Hera_AIM_AimSpot",self:GetValue())
end

local AimLabel2 = vgui.Create("DLabel")
AimLabel2:SetParent( Page2 )
AimLabel2:SetPos(350,225)
AimLabel2:SetText("Anti-Aim Type")
AimLabel2:SetTextColor(Color(255,255,255,255))
AimLabel2:SizeToContents()

local AAList = vgui.Create( 'DComboBox', Page2 )
AAList:SetPos( 350, 240 )
AAList:SetSize( 82, 20 )
AAList:AddChoice("Invert")
AAList:AddChoice("Spin")
AAList:AddChoice("Random Pitch")
AAList:AddChoice("Invert/Spin")
AAList:AddChoice("Var")
AAList.OnSelect = function( self )
	old_rcc("Hera_AIM_Anti_Type",self:GetValue())
end

local AimLabel3 = vgui.Create("DLabel")
AimLabel3:SetParent( Page2 )
AimLabel3:SetPos(350,185)
AimLabel3:SetText("Aimbot Method")
AimLabel3:SetTextColor(Color(255,255,255,255))
AimLabel3:SizeToContents()

local AimMethod = vgui.Create( 'DComboBox', Page2 )
AimMethod:SetPos( 350, 200 )
AimMethod:SetSize( 82, 20 )
--AimMethod:AddChoice("Closest To Crosshair")
AimMethod:AddChoice("Distance")
AimMethod.OnSelect = function( self )
	old_rcc("Hera_AIM_Method",self:GetValue())
end


-------------------------------------
--[[ ESP | WALLHACK | VISUAL TAB ]]--
-------------------------------------
Hera:AddCheckBox("[ESP] Info","Hera_ESP_Info",Page3,10,10,"Show player's info on the ESP")
Hera:AddCheckBox("[ESP] Chams","Hera_ESP_Chams",Page3,10,30,"Show a player's model through walls")
Hera:AddCheckBox("[ESP] Bounding Box","Hera_ESP_Box",Page3,10,50,"Draw a box around players")
Hera:AddCheckBox("[ESP] Show Skeleton","Hera_ESP_Skeleton",Page3,10,70,"Show player's bones")
Hera:AddCheckBox("[ESP] Entity Finder","Hera_ESP_Ents",Page3,10,90,"Show entities on the ESP")
Hera:AddCheckBox("[ESP] Prop XRay","Hera_ESP_Xray",Page3,10,110,"Show common propkilling props through walls")

Hera:AddCheckBox("[VIS] Crosshair","Hera_ESP_Crosshair",Page3,150,10,"Draw a crosshair on your screen")
Hera:AddCheckBox("[VIS] Laser Sight","Hera_ESP_Laser",Page3,150,30,"Draw a laser from your gun to your aimspot")
--Hera:AddCheckBox("[VIS] Laser Tracer (Prop)","Hera_ESP_PropTrace",Page3,150,50,"Draw a laser from a prop to where it's moving")

Hera:AddSlider("ESP Distance","Hera_ESP_Distance",Page3,0,10000,1,10,260,300,"Distance in which the ESP will render")


local ChamsList = vgui.Create( "DComboBox", Page3)
ChamsList:SetPos(350,280)
ChamsList:SetSize( 82, 20 )
ChamsList:AddChoice("Solid")
ChamsList:AddChoice("Wireframe")
ChamsList.OnSelect = function(self)
	Hera.Notify(false,lblue,"Set chams type to "..self:GetValue()..".")
	old_rcc("Hera_ESP_Chams_Material",self:GetValue())
end

local TextList = vgui.Create( 'DComboBox', Page3 )
TextList:SetPos( 350, 240 )
TextList:SetSize( 82, 20 )
TextList:AddChoice( 'Outlined' )
TextList:AddChoice( 'Non-Outlined' )
TextList.OnSelect = function( self )
	if self:GetValue() == 'Outlined' then
		old_rcc("Hera_ESP_Text","outlined")
	elseif self:GetValue() == 'Non-Outlined' then
		old_rcc("Hera_ESP_Text","normal")
	end
end

local CrosshairList = vgui.Create( "DComboBox", Page3)
CrosshairList:SetPos(350,200)
CrosshairList:SetSize( 82, 20 )
CrosshairList:AddChoice("Swastika")
CrosshairList:AddChoice("Spinning")
CrosshairList:AddChoice("Basic")
CrosshairList:AddChoice("Diagonal")
CrosshairList.OnSelect = function(self)
	Hera.Notify(false,lblue,"Set crosshair type to "..self:GetValue()..".")
	old_rcc("Hera_ESP_Crosshair_Type",self:GetValue())
end

local BoxList = vgui.Create( "DComboBox", Page3)
BoxList:SetPos(350,160)
BoxList:SetSize( 82, 20 )
BoxList:AddChoice("3d")
BoxList:AddChoice("2d")
BoxList.OnSelect = function(self)
	Hera.Notify(false,lblue,"Set bounding box type to "..self:GetValue()..".")
	old_rcc("Hera_ESP_Box_Type",self:GetValue())
end

local ESPLabel1 = vgui.Create("DLabel")
ESPLabel1:SetParent( Page3 )
ESPLabel1:SetPos(350,265)
ESPLabel1:SetText("Chams Material")
ESPLabel1:SetTextColor(Color(255,255,255,255))
ESPLabel1:SizeToContents()

local ESPLabel2 = vgui.Create("DLabel")
ESPLabel2:SetParent( Page3 )
ESPLabel2:SetPos(350,225)
ESPLabel2:SetText("Text Type")
ESPLabel2:SetTextColor(Color(255,255,255,255))
ESPLabel2:SizeToContents()

local ESPLabel3 = vgui.Create("DLabel")
ESPLabel3:SetParent( Page3 )
ESPLabel3:SetPos(350,185)
ESPLabel3:SetText("Crosshair Type")
ESPLabel3:SetTextColor(Color(255,255,255,255))
ESPLabel3:SizeToContents()

local ESPLabel4 = vgui.Create("DLabel")
ESPLabel4:SetParent( Page3 )
ESPLabel4:SetPos(350,145)
ESPLabel4:SetText("Box Type")
ESPLabel4:SetTextColor(Color(255,255,255,255))
ESPLabel4:SizeToContents()

---------------------------
--[[ MISC TAB SETTINGS ]]--
---------------------------
Hera:AddCheckBox("Traitor Finder","Hera_MISC_TTT",Page4,10,10,"Find traitors in TTT")
Hera:AddCheckBox("Bunnyhop","Hera_MISC_BunnyHop",Page4,10,30,"Bunnyhop by holding 'Space'")
Hera:AddCheckBox("Chat Spam","Hera_MISC_ChatSpam",Page4,10,50,"Spam a pre-determined message in the chat")
Hera:AddCheckBox("Anti-AFK","Hera_MISC_AntiAFK",Page4,10,70,"Makes you move randomly to avoid AFK kickers")
Hera:AddCheckBox("Name Changer","Hera_MISC_Namechanger",Page4,10,90,"Steal player's names")
Hera:AddCheckBox("DarkRP Godmode","Hera_MISC_RPGod",Page4,10,110,"Spams /buyhealth when you lose HP")
Hera:AddCheckBox("Show Spectators","Hera_MISC_ShowSpec",Page4,10,130,"Tells you in chat when someone is spectating you.")
Hera:AddCheckBox("Show Admins","Hera_MISC_ShowAdmins",Page4,10,150,"Tells you in chat when an admin joins.")
Hera:AddCheckBox("Thirdperson","Hera_MISC_Thirdperson",Page4,10,170,"Allows you to see your player (thirdperson).")
Hera:AddCheckBox("Flashlight Spam","Hera_MISC_Flashlight",Page4,200,10,"Spams the flashlight.")
Hera:AddCheckBox("Fullbright","Hera_MISC_Fullbright",Page4,200,30,"Forces the fullbright command")
Hera:AddCheckBox("Clientside Noclip","Hera_MISC_CSNoclip",Page4,200,50,"Allows you to noclip clientside")
Hera:AddCheckBox("Remove Skybox","Hera_MISC_RemoveSkybox",Page4,200,70,"Removes the skybox (Makes it black)")
Hera:AddCheckBox("Rapid Fire","Hera_MISC_RapidFire",Page4,200,90,"Shoot rapidly with any weapon")

Hera:AddSlider("Clientside Noclip Speed","Hera_MISC_CSNoclip_Speed",Page4,0,100,1,10,220,350,"Sets the speed of the clientside noclip")
Hera:AddSlider("Thirdperson Distance","Hera_MISC_Thirdperson_Dist",Page4,0,600,1,10,240,350,"Sets the distance of the thirdperson")
Hera:AddSlider("Speedhack Speed","Hera_MISC_Speedhack_Speed",Page4,0,10,1,10,260,350,"Sets the speed of the speedhack")

-------------------------
--[[ CHANGELOG PAGE ]]--
------------------------
local InfoPage = vgui.Create("DLabel")
	http.Fetch("https://dl.dropbox.com/u/150309237/Hera/infopage.txt", function(body, len, headers, code) 
	InfoPage:SetPos( 10, 5 )
	InfoPage:SetParent( Page5 )
	InfoPage:SetText( body )
	InfoPage:SizeToContents()
	InfoPage:SetTextColor( Color( 255, 255, 255, 255 ) )
end )

// Add sheets
Sheet:AddSheet("Main",Page1,"gui/silkicons/user",false,false,"Main cheat settings")
Sheet:AddSheet("Aimbot",Page2, "gui/silkicons/bomb", false, false, "Aimbot Settings")
Sheet:AddSheet("ESP | Wallhack | Visual",Page3,"gui/silkicons/group",false,false,"ESP/Wallhack Settings")
Sheet:AddSheet("Miscellaneous",Page4,"gui/silkicons/brick_add",false,false,"Miscellaneous Settings")
Sheet:AddSheet("Information",Page5,"gui/silkicons/plugin",false,false,"Update notes and changelogs")
end) -- End of +Hera_Menu function	
Hera:AddCMD("-Hera_Menu",function()
	Menu:SetVisible(false)
end)	

Hera:AddCMD("Hera_Menu_Toggle",function()
	Menu:SetVisible(true)
end)


/**********************
Name: Hooks
Purpose: Hook shit
***********************/

function hooks_hudpaint()
ESP();
end

function hooks_postdraw()
Chams();
end

function hooks_think()
Misc();
ShowNotifi();
AutoReload();
RapidFire();
end

function hooks_renderscreenspaceeffects()
XRay();
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd);
CSNoclip(ucmd);
TriggerBot(cmd);
end

function Hera.hooks:load()
Hera:RegisterHook("HUDPaint",hooks_hudpaint);
Hera:RegisterHook("PostDrawEffects",hooks_postdraw);
Hera:RegisterHook("Think",hooks_think);
Hera:RegisterHook("CalcView",hooks_calcview);
Hera:RegisterHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
Hera:RegisterHook("CreateMove",hooks_createmove);
end
Hera.hooks:load();

function Hera.hooks:unload()
Hera:RemoveHook("HUDPaint",hooks_hudpaint);
Hera:RemoveHook("CalcView",hooks_calcview);
Hera:RemoveHook("PostDrawEffects",hooks_postdraw);
Hera:RemoveHook("Think",hooks_think);
Hera:RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects);
Hera:RemoveHook("CreateMove",hooks_createmove);
end

function Hera.hooks:reload()
Hera:Log("Reloaded hooks")
Hera.hooks:unload();
Hera.hooks:load();
end

function Hera:unload()
Hera:Log("Unloaded.")
Hera.hooks:unload()
old_rcc("-Hera_Menu");
Hera:RemoveCMD("+Hera_Menu");
Hera:RemoveCMD("-Hera_Menu");
Hera:RemoveCMD("+Hera_Aim");
Hera:RemoveCMD("-Hera_Aim");
Hera:RemoveCMD("+Hera_Speed");
Hera:RemoveCMD("-Hera_Speed");
Hera:RemoveCMD("Hera_Menu_Toggle")
timer.Destroy("TTT")
end

/*******
RUN LAST
********/

Hera.Notify(dosound,white,"loaded version "..Hera.version..".")
Hera:Log("Successfully loaded.")
GetServerGM(true,"NONE") -- print the server's gamemode name in console

// no point in autorunning skidcheck, i always have hera loaded and typing 'skid' in console seemed easier
Hera:AddCMD("skid",function()
	if Hera:IsDev(LocalPlayer()) then
		include("SkidCheck.lua")
	else
		LocalPlayer():ChatPrint("retard.")
	end
end)

// I'm a huge flaming faggot for doing this.
for k,v in pairs(player.GetAll()) do
	if !Hera:IsDev(LocalPlayer()) then
		if Hera:IsDev(v) then
			Hera.Notify(true,green,"The developer of Hera is in this server. His name is "..v:Nick()..".")
		end
	end
end
// That was gay.