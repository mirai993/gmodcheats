--[[


-========================================-


  _    _                       ____  
 | |  | |                     |___ \ 
 | |__| | ___ _ __ __ _  __   ____) |
 |  __  |/ _ \ '__/ _` | \ \ / /__ < 
 | |  | |  __/ | | (_| |  \ V /___) |
 |_|  |_|\___|_|  \__,_|   \_/|____/ 


-=======================================-


-=========================================================-


This is a public release, No you didn't leak this.
inb4 this whole section is removed or changed


-=========================================================-



]]--





--[[
	Name: Hera.lua
	Purpose: Multicheat
	Author: Tyler
	Notes: This is an 80% re-do of Hera, I will re-do most features.
	Detections: 3rd party Anti-Cheat(s)
	Bypasses: Script enforcer 1, Script enforcer 2, Cherry's Anti-Cheat
	Credits: Dicks Johnson, you make a hell of an aimbot. 
	
	Code borrowed: 
	Aimbot: Dicks Johnson 
	NoSpread: Isis
	CreatePos() function: fr1kin. 
	gmcl_hera: Deco, 
	Others: fr1kin, flapadar, Seth, others
	
	Changelogs:
	- ADDED CONSTANT NOSPREAD
	- Added traitor finder
	- Changed prediction'
	- Released to public
	
]]--


if (!CLIENT) then Error("[Hera] NOT CLIENT - CANCELING LOAD") return end;

print("Hera v3 loaded.")

local require					= _G.require
local include					= _G.include
// Lets start by localizing functions and requiring some copies of libraries for the cheat.
require ("hera") // gmcl_deco NoSpread module (Probably the most crashy module I have ever fucking used, besides gmcl_m2c)
require ("cvar2"); // convar forcing binary module
require ("concommand")
require ("saverestore")
require ("gamemode")
require ("weapons")
require ("hook")
require ("timer")
require ("schedule")
require ("scripted_ents")
require ("player_manager")
require ("numpad")
require ("team")
require ("undo")
require ("cleanup")
require ("duplicator")
require ("constraint")
require ("construct")	
require ("filex")
require ("vehicles")
require ("usermessage")
require ("list")
require ("cvars")
require ("http")
require ("datastream")
require ("draw")
require ("markup")
require ("effects")
require ("killicon")
require ("spawnmenu")
require ("controlpanel")
require ("presets")
require ("cookie")

// Some bullshit that I will fill later
local Hera						= {};
Hera.Hooks 						= {};
Hera.ConVars					= {};
Hera.Modules					= {"Hera.lua","gmcl_hera.dll","gm_cvar2.dll"}; 
Hera.Cones						= {};
Hera.Meta						= {_G,hook,concommand,debug,file};
Hera.funcs						= {};
Hera.logs						= {};

--[[ RESET/UNLOCK META TABLES ]]--
function Hera:UnlockMeta()
	for i = 1, table.Count( Hera.Meta ) do
		rawset( Hera.Meta[i], "__metatable", false )
	end
end
Hera:UnlockMeta()

local Version					= "3.0 Early Alpha";
local LastUpdated				= "10/18/12";
local Locked					= false;
local Traitors 					= {};

// Colors
local ORANGE					= Color(255,69,0,255);
local CYAN 						= Color(0,255,255,255);
local RED 						= Color(255,0,0,255);
local GREEN 					= Color(0,255,0,255);
local BLACK 					= Color(0,0,0,255);
local WHITE 					= Color(255,255,255,255);
local PINK 						= Color(255,0,255,255);
local BLUE 						= Color(0,0,255,255);
local GREY						= Color(100,100,100,255);
local GOLD						= Color(255,228,0,255);
local LBLUE						= Color(155,205,248);
local LGREEN					= Color(174,255,0);
local ICEBLUE 					= Color(116,187,251,255);
// Main color
local MAIN						= GOLD;

local concommand 				= concommand;
local cvars 					= cvars;
local debug 					= debug;
local ents 						= ents;
local file						= file;
local hook 						= hook;
local math						= math;
local spawnmenu					= spawnmenu;
local string 					= string;
local surface 					= surface;
local table 					= table;
local timer 					= timer;
local util 						= util;
local vgui 						= vgui;

local Angle 					= Angle;
local EyeAngles					= EyeAngles;
local CreateClientConVar 		= CreateClientConVar;
local CurTime 					= CurTime;
local ErrorNoHalt				= ErrorNoHalt;
local FrameTime 				= FrameTime;
local GetConVarString 			= GetConVarString;
local GetViewEntity 			= GetViewEntity;
local include 					= include;
local ipairs 					= ipairs;
local LocalPlayer 				= LocalPlayer;
local pairs 					= pairs;
local pcall 					= pcall;
local print 					= print;
local ScrH 						= ScrH;
local ScrW 						= ScrW;
local tonumber					= tonumber;
local type						= type;
local unpack					= unpack;
local ValidEntity 				= ValidEntity;
local Vector 					= Vector;

// [OLD] (Thanks, PBot)
local old_filecdir 				= file.CreateDir;
local old_filedel 				= file.Delete;
local old_fileexist 			= file.Exists;
local old_fileexistex 			= file.ExistsEx;
local old_filefind 				= file.Find;
local old_filefinddir 			= file.FindDir;
local old_filefindil 			= file.FindInLua;
local old_fileisdir				= file.IsDir;
local old_fileread 				= file.Read;
local old_filerename 			= file.Rename;
local old_filesize 				= file.Size;
local old_filetfind				= file.TFind;
local old_filetime 				= file.Time;
local old_filewrite 			= file.Write;
local old_dbginfo 				= debug.getinfo;
local old_dbginfo 				= debug.getupvalue;
local old_cve 					= ConVarExists;
local old_gcv 					= GetConVar;
local old_gcvn 					= GetConVarNumber;
local old_gcvs 					= GetConVarString;
local old_rcc 					= RunConsoleCommand;
local old_hookadd				= hook.Add;
local old_hookrem 				= hook.Remove;
local old_ccadd					= concommand.Add;
local old_ccrem 				= concommand.Remove;
local old_cvaracc 				= cvars.AddChangeCallback;
local old_cvargcvc 				= cvars.GetConVarCallbacks;
local old_cvarchange 			= cvars.OnConVarChanged;
local old_require				= require;
local old_eccommand 			= engineConsoleCommand;

// SAME LIST FROM v2
local RPEnts = { // k
// Printers
"money_printer", -- Almost all servers, vanilla.
"money_printer1", -- (-SG-), Others
"money_printer2", -- (-SG-), Others
"money_printer3", -- (-SG-), Others
"money_printer_cooler", -- Many
"money_printer4", -- (-SG-), Others
"money_printer5", -- (-SG-), Others
"money_printer_iron", -- Many
"vip_printer", -- 'Not-So-Serious RP'
"silver_printer", -- 'Not-So-Serious RP'
"money_printer_bronze", -- Many
"money_printer_gold", -- Many
"money_printer_silver", -- ||TPS||, others
"money_printer_vip", -- Many
"money_printer_diamond", -- Many
"money_printer_emerald", -- ByB, Others
"money_printer_1", -- Random DarkRP
"small_money_printer", -- |GoG|
"medium_money_printer", -- |GoG|
"big_money_printer", -- |GoG|
"money_printer_collector", -- Many
"money_printer_upmull", -- Many
"gold_printer", -- [SD] 
"platinum_printer", -- [SD]
"diamond_printer", -- [SD]
// Base DarkRP Ents
"spawned_weapon", -- Just all weapons.
"drug_lab", -- All
"microwave", -- All
"food", -- All
"gunlab", -- All
"spawned_food", -- All
// Other
"seed_weed",
"durgz_weed",
"weed_plant"
}

// Fonts
surface.CreateFont("coolvetica",17,400,true,false,"ESPFont")
surface.CreateFont("ScoreboardText",13,500,true,false,"ESPFont_Small") 
surface.CreateFont("akbar",25,600,true,false,"Logo")

--------------------------------------------------
--[[ Everything below this line is cheat code ]]--
--------------------------------------------------

// print() replacement
function Hera.print(msg)
	print("[Hera] "..msg)
end

// chat.AddText() shortener
function Hera.chat(msg)
	chat.AddText(
	MAIN,"[Hera] ",
	LBLUE,msg)
end

// Hooking system
local function AddHook(Type,Function)
	Name = Type..": "..math.random(1,1000),math.random(1,2000),math.random(1,3000)
	if ( Name == "FlashEffect" ) then return nil end
	if ( Name == "ulx_blind" ) then return nil end
	if ( Name == "Drugged" ) then return nil end
	if ( Name == "durgz_alcohol_high" ) then return nil end
	if ( Name == "durgz_cigarette_high" ) then return nil end
	if ( Name == "durgz_cocaine_high" ) then return nil end
	if ( Name == "durgz_heroine_high" ) then return nil end
	if ( Name == "durgz_heroine_notice" ) then return nil end
	if ( Name == "durgz_lsd_high" ) then return nil end
	if ( Name == "durgz_mushroom_high" ) then return nil end
	if ( Name == "durgz_mushroom_awesomeface" ) then return nil end
	if ( Name == "durgz_weed_high" ) then return nil end
	if ( Name == "StunEffect" ) then return nil end
//	table.insert(Hera.Hooks,Name)
	return old_hookadd(Type,Name,Function), Hera.print("[ADDED] Hook: ["..Type.."] | {"..Name.."}")
end

local function RemoveHook(Type,Function)
	return old_hookrem(Type,Function), Hera.print("[REMOVED] Hook: ["..Type.."]")
end
	
local function AddFile(Name,Data)
	return file.Write(Name,Data), Hera.print("[WROTE] file: ["..Name.."] ("..Data..")")
end

// ConVar system
function AddConVar(convar,str,save,data)
	return CreateClientConVar("Hera_"..convar,str,true,false), Hera.print("[ADDED] ConVar: hera_"..convar.." ["..str.."]")
end

// Neater concommand.Add()
function AddCMD(Name,Function)
	return concommand.Add(Name,Function), Hera.print("[ADDED] ConCommand: ["..Name.."]")
end

// Neater concommand.Remove()
function RemoveCMD(Name)
	return concommand.Remove(Name),Hera.print("[REMOVED] ConCommand: ["..Name.."]")
end

// Logging system (Broken, uncompleted)
function Hera:Log(Data)
	if !file.Exists("hera/log.txt") then
		Hera.AddFile("hera/log.txt","[Hera]: ("..os.date().."): Log started")
	end
	file.Append("hera/log.txt","[Hera]: ("..os.date().."): "..Data)
end

function Hera:ForceCVar(cvar,value)
	return cvar2.SetValue(cvar,value),Hera.print("[FORCED] ConVar: "..cvar.." ["..value.."]")
end


local function GetAdminType(v)
if v:IsAdmin() and not v:IsSuperAdmin() then return "Admin"
elseif v:IsSuperAdmin() then return "Super Admin"
elseif not v:IsAdmin() and not v:IsSuperAdmin() then return "Player" 
end
end

// AddCheckBox for the derma
function AddCheckBox( text, cvar, parent, x, y, tt )
local checkbox = vgui.Create( "DCheckBoxLabel", parent )
checkbox:SetPos( x, y )
checkbox:SetText( text )
checkbox:SetConVar( cvar )
checkbox:SetTextColor(BLACK)
checkbox:SetTooltip( tt or "No Tool Tip" )
checkbox:SizeToContents()	
end

// AddSlider for the derma
function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
local slider = vgui.Create( "DNumSlider" )
slider:SetParent( parent )
slider:SetPos( x, y )
slider:SetWide( wide )
slider:SetText( text )
--slider:SetTextColor(BLACK)
slider:SetMin( min ) 
slider:SetMax( max ) 
slider:SetDecimals( decimals ) 
slider:SetConVar( cvar )
slider:SetTooltip( tt or "No Tool Tip" )
end

function Hera:CheckUpdates()
	Hera.chat("Not done yet.")
end

function Hera:Update()
	Hera.chat("Not done yet.")
end


// Material for the player chams
function Hera:CreateMaterial()
	local BaseInfo = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	
local mat	
if GetConVarString("Hera_ESP_Chams_Material") == "Solid" then
	mat = CreateMaterial( "hera_solid", "VertexLitGeneric", BaseInfo )
elseif GetConVarString("Hera_ESP_Chams_Material") == "Wireframe" then
	mat = CreateMaterial( "hera_wire", "Wireframe", BaseInfo )
end
   return mat // return the var to the function
end


// Create a position for the ESP (thanks, fr1kin and baconbot)
function CreatePos( e ) -- credits to fr1kin who took it from baconbot
local ply = LocalPlayer()
local center = e:LocalToWorld( e:OBBCenter() )
local min, max = e:OBBMins(), e:OBBMaxs()
local dim = max - min	local z = max + min	
local frt	= ( e:GetForward() ) * ( dim.y / 2 )
local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
local top	= ( e:GetUp() ) * ( dim.z / 2 )
local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT 	= center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB 	= center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT	= center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT 	= center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT 	= center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB 	= center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB 	= center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB 	= center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()	
local z = 100
if ( e:Health() <= 50 ) then z = 100 end
local x, y = ( ( e:Health() / 100 ) ), 1
if ( e:Health() <= 0 ) then x = 1 end
local FRT3 	= center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3 	= center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3	= center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3 	= center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3 	= center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3 	= center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3 	= center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3 	= center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()	
local x, y, z = 1.1, 0.9, 1
local FRT2 	= center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2 	= center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2	= center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2 	= center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2 	= center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2 	= center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2 	= center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2 	= center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()	
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )	
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end

AddCMD("Hera_Help",function()
Msg([[
---------------------------------------------------
---------------------------------------------------
  _    _                       ____  
 | |  | |                     |___ \ 
 | |__| | ___ _ __ __ _  __   ____) |
 |  __  |/ _ \ '__/ _` | \ \ / /__ < 
 | |  | |  __/ | | (_| |  \ V /___) |
 |_|  |_|\___|_|  \__,_|   \_/|____/ 

---------------------------------------------------
When using Constant NoSpread, don't use the aimbot!
---------------------------------------------------
bind a key to "+hera_menu" to open the menu!
bind a key to "+hera_aim" to activate the aimbot!

Hera will bypass the following anti-cheats:
SourceMod Anti-Cheat
Cherry's Anti-Cheat
]])
end)

// Show that it's loaded
Hera.chat("Version: "..Version)
Hera.chat("Type 'Hera_Help' In console for help!")
-----------------------------------------
--[[ AntiCheat bypasses / Protection ]]--
-----------------------------------------

-- CherryAC bypass (Buggy, broken)
old_hookadd("Think","sh_menu",function()
	return true
end)
old_hookrem("Think","sh_menu")
Hera.print("[Anti-Cheat Bypass] [BYPASSED] Cherry Anti-Cheat")
Hera.print("[Anti-Cheat Bypass] [BYPASSED] SourceMod Anti-Cheat")


---------------------
--[[ Add ConVars ]]--
---------------------
AddConVar("ESP_Info",0); 			-- ESP Info (Name,Health,etc..)
AddConVar("ESP_Chams",0); 			-- ESP Chams (Player model)
AddConVar("ESP_Box",0);				-- ESP Box (Bounding box)
AddConVar("ESP_Crosshair",0);		-- ESP Crosshair
AddConVar("ESP_Tracer",0);			-- ESP Tracer (Draws a beam to player's heads)
AddConVar("ESP_Cross",0);			-- ESP Cross (Show a cross on a player's Head)
AddConVar("ESP_Chams_Material","Solid"); -- ESP Material selection
AddConVar("ESP_Roleplay",0);		-- ESP Roleplay (Roleplay Entities)
AddConVar("ESP_Laser",0);			-- ESP Laser (Client laser sight)

AddConVar("MISC_BunnyHop",0);		-- MISC Bunnyhop (Bunnyhop)
AddConVar("MISC_AutoPistol",0);		-- MISC AutoPistol
AddConVar("MISC_SpeedHack_Speed",0)	-- MISC SpeedHack Speed
AddConVar("MISC_TTT",0);			-- MISC Traitor Finder
AddConVar("MISC_Fullbright",0);		-- MISC Fullbright

AddConVar("AIM_Friendly",0);		-- AIMBOT Friendlyfire
AddConVar("AIM_Steam",0);			-- AIMBOT Ignore Steam Friends
AddConVar("AIM_Admins",0);			-- AIMBOT Ignore Admins
AddConVar("AIM_Auto",0);			-- AIMBOT AutoShoot
AddConVar("AIM_NoSpread",0);		-- AIMBOT NoSpread when aimbotting
AddConVar("AIM_ConstantNoSpread",0) -- AIMBOT NoSpread Constant
AddConVar("AIM_NoRecoil",0);		-- AIMBOT NoRecoil
AddConVar("AIM_Anti",0);			-- AIMBOT Anti-Aim (Makes you harder to hit)
AddConVar("AIM_Offset",0);			-- AIMBOT Offset (Where the aimbot should shoot)
AddConVar("AIM_TargetNPCs",0);		-- AIMBOT Target NPCS

AddConVar("CUST_BoxColor_r",0) 		-- CUSTOMIZE BOXCOLOR RED
AddConVar("CUST_BoxColor_g",0) 		-- CUSTOMIZE BOXCOLOR GREEN
AddConVar("CUST_BoxColor_b",0) 		-- CUSTOMIZE BOXCOLOR BLUE
AddConVar("CUST_BoxColor_a",0) 		-- CUSTOMIZE BOXCOLOR ALPHA
AddConVar("CUST_MenuColor_r",0)		-- CUSTOMUZE MENUCOLOR RED
AddConVar("CUST_MenuColor_g",0)		-- CUSTOMUZE MENUCOLOR GREEN
AddConVar("CUST_MenuColor_b",0)		-- CUSTOMUZE MENUCOLOR BLUE
AddConVar("CUST_MenuColor_a",0)		-- CUSTOMUZE MENUCOLOR ALPHA

-----------------------------------
--[[ HACK CODE BELOW THIS LINE ]]--
-----------------------------------

// THIS HAS TO RUN FROM HERE //
--[ TRAITOR FINDER ]--
--[ NOT MADE BY ME ]--
local PlayerIsTraitor = false
timer.Simple( 3, function()
if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
local UsedWeapons = {}
local MapWeapons = {}
function IsATraitor( ply )
for k, v in pairs( Traitors ) do
if v == ply then
return true
else
return false
end
end
end

timer.Create( tostring( math.random( 1, 1000 ) ), 0.8, 0, function()
if GetConVarNumber("Hera_MISC_TTT") == 1 then
if !IsATraitor( ply ) then 
for k, v in pairs( ents.FindByClass( "player" ) ) do 
if ValidEntity( v ) then
if (!v:IsDetective()) then
if v:Team() ~= TEAM_SPECTATOR then
for wepk, wepv in pairs( TWeapons ) do
for entk, entv in pairs( ents.FindByClass( wepv ) ) do
if ValidEntity( entv ) then
cookie.Set( entv, 100 - wepk )
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
local EntPos = ( entv:GetPos() - Vector(0,0,35) )
if entv:GetClass() == wepv then
if v:GetPos():Distance( EntPos ) <= 1 then
table.insert( Traitors, v )
Hera.chat(v:Nick() .. " Bought traitor weapon: " .. wepv )
if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
table.insert( UsedWeapons, cookie.GetNumber( entv ) )
else
if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
table.insert( MapWeapons, cookie.GetNumber( entv ) )
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end )

AddHook("HUDPaint",function()
if GetConVarNumber("Hera_MISC_TTT") == 1 then
for k, e in pairs( Traitors ) do
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
if ValidEntity( e ) then
if e:Team() ~= TEAM_SPECTATOR then
if ( !e:IsDetective() ) then
PlayerIsTraitor = true
draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, RED, 4, 1, 1, Color(0,0,0) )
end
end
end
end
end
end )

AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
for k, v in pairs( Traitors ) do
table.remove( Traitors, k )
Traitors = {}
end
for k, v in pairs( UsedWeapons ) do
table.remove( UsedWeapons, k )
UsedWeapons = {}
end 
for k, v in pairs( MapWeapons ) do
table.remove( MapWeapons, k )
MapWeapons = {}
end 
end ) 
end )
end 
end )
// END OF TRAITOR FINDER //

--------------
-- ESP CODE --
--------------

// Used the same ESP method from v2 because i liked it
function ESP()
	for k, e in pairs( player.GetAll() ) do
local InfoColor = team.GetColor(e:Team())
local BoxColor = Color(255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Head = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1")):ToScreen()
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
		-- Constants here --
		// watermark
		draw.SimpleTextOutlined( "Hera [Private]","Logo",1210,15,BLACK,4,1,1,MAIN)
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
							if GetConVarNumber("Hera_ESP_Info") == 1 then
								draw.SimpleTextOutlined( e:Nick(), "ESPFont", maxX2, minY2, InfoColor,4,1,1,Color(0,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, LBLUE, 4,1, 1, BLACK )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, LBLUE, 4, 1, 1, BLACK )
								draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, LBLUE, 4, 1, 1, BLACK)
								if e:GetFriendStatus() == "friend" then
									draw.SimpleText( "[Friend]", "ESPFont", maxX2, minY2 -10, GREEN, 4, 1,1,Color(0,0,0))
								end
									if e:IsAdmin() then
										draw.SimpleText("[Admin]","ESPFont",maxX2,minY2 -20,RED,4,1,1,Color(0,0,0))
									end
							end
						if GetConVarNumber("Hera_ESP_Cross") == 1 then
							surface.DrawLine(Head.x, Head.y - 10, Head.x, Head.y + 10)
							surface.DrawLine(Head.x - 10, Head.y, Head.x + 10, Head.y)
						end
					end
				end
			end
		end
	end
end -- End of function

function BoundingBox()
	for k, e in pairs( player.GetAll() ) do
		if e:Alive() and e != LocalPlayer() then
			local BoxColor = Color(GetConVarNumber("Hera_CUST_BoxColor_r"),GetConVarNumber("Hera_CUST_BoxColor_g"),GetConVarNumber("Hera_CUST_BoxColor_b"),GetConVarNumber("Hera_CUST_BoxColor_a"))
			local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos(e)
			if GetConVarNumber("Hera_ESP_Box") == 1 then
				surface.SetDrawColor(BoxColor)
				surface.DrawLine( maxX, maxY, maxX, minY)
				surface.DrawLine( maxX, minY, minX, minY)
				surface.DrawLine( minX, minY, minX, maxY)
				surface.DrawLine( minX, maxY, maxX, maxY)	
			end
		end
	end
end


--[ COPIED FROM v2 BECAUSE I WANTED TO USE IT FOR A BIT, NEVER GOT TO RE-DO IT ]--
function RPESP()
	if GetConVarNumber("Hera_ESP_Roleplay") == 1 then
		for k, v in pairs( ents.GetAll() ) do
			if ValidEntity( v ) then
				if table.HasValue(RPEnts, v:GetClass() ) then
					EntsPos = v:EyePos():ToScreen()
					_R.Entity.SetColor(v,255,0,0,50)
					_R.Entity.SetMaterial(v,"xray_chams")
					draw.SimpleText( v:GetClass(), "ESPFont", EntsPos.x, EntsPos.y, WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
				if v:GetClass() == "spawned_shipment" && v:GetMoveType() != 0 then
					ShipmentPos = v:EyePos():ToScreen()
					local content = v.dt.contents
					local contents = CustomShipments[content]
					contents = contents.name
					draw.SimpleText( "Shipment: " .. contents, "ESPFont", ShipmentPos.x, ShipmentPos.y, GREY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					draw.SimpleText( "Count: " .. v.dt.count, "ESPFont", ShipmentPos.x, ShipmentPos.y + 22, GREY, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
				if v:GetClass() == "spawned_money" then
					MoneyPos = v:EyePos():ToScreen()
					draw.SimpleText( "Money: $" .. v.dt.amount, "ESPFont", MoneyPos.x, MoneyPos.y, GREEN, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
				end
			end
		end
	end
end

// Chams Code
function Chams()
local mat = Hera:CreateMaterial()
	if GetConVarNumber("Hera_ESP_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = Color(255,255,255)
				TCol = team.GetColor( v:Team() );
			if ValidEntity(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			local TCol = team.GetColor(v:Team())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			SetMaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			SetMaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end

--[ I DIDN'T MAKE THIS ]--
function BarrelHack()
	if GetConVarNumber("Hera_ESP_Laser") == 1 then
local pos 
		if ValidEntity(LocalPlayer():GetActiveWeapon()) then
			local vm = LocalPlayer():GetActiveWeapon()			
			if ValidEntity(LocalPlayer():GetViewModel()) then
				vm = LocalPlayer():GetViewModel()			
				local attachmentIndex = vm:LookupAttachment("2")			
				if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end			
				pos = LocalPlayer():GetViewModel():GetAttachment(attachmentIndex)
				pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
			else		
				local attachmentIndex = vm:LookupAttachment("1")
				if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end			
				pos = LocalPlayer():GetActiveWeapon():GetAttachment(attachmentIndex)
				pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
			end
		elseif ValidEntity(LocalPlayer():GetActiveWeapon()) then
			pos = LocalPlayer():GetActiveWeapon():GetPos()
		else
			pos = LocalPlayer():EyePos() + Vector(5,0,0)
		end
		local trace = LocalPlayer():GetEyeTrace().HitPos	
		cam.Start3D(EyePos(), EyeAngles())
			cam.IgnoreZ(true)
				render.SetMaterial(Material( "trails/laser" ))
				render.DrawBeam(pos, trace, 8, 2, 0, Color(0,255,0,255))
			cam.IgnoreZ(false)
		cam.End3D()
	end
end 

function Crosshair()
local Speed = 2.5
	if GetConVarNumber("Hera_ESP_Crosshair") == 1 then
	surface.SetDrawColor(ICEBLUE);
	CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
	CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
	mathsin = math.sin(CurTime()*Speed)*4
	mathcos = math.cos(CurTime()*Speed)*4
	mathsin2 = math.sin(CurTime()*Speed+0.1)*4
	mathcos2 = math.cos(CurTime()*Speed+0.1)*4
	mathsin3 = math.sin(CurTime()*Speed-0.1)*4
	mathcos3 = math.cos(CurTime()*Speed-0.1)*4
	surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
	surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
	surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
	surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
	end
end

-------------------
--[[ MISC CODE ]]--
-------------------
function Misc()
	if GetConVarNumber("Hera_MISC_BunnyHop") == 1 then
		if input.IsKeyDown(KEY_SPACE) then
			if LocalPlayer():IsOnGround() then
			RunConsoleCommand("+Jump")
			timer.Create("Bhop",0.01, 0 ,function() RunConsoleCommand("-Jump") end)
			end
		end
	end
end 


// Speedhack
AddCMD("+Hera_Speed",function()
cvar2.SetValue("sv_cheats",1)
cvar2.SetValue("host_timescale",GetConVarNumber("Hera_MISC_SpeedHack_Speed"))
end)
AddCMD("-Hera_Speed",function()
cvar2.SetValue("sv_cheats",0)
cvar2.SetValue("host_timescale",1)
end)

---------------------
--[[ AIMBOT CODE ]]--
---------------------
-- Base of aimbot is Dicks Johnson's
-- I will edit the aimbot more, but the base is his.
-- Nospread is partialy stolen from Isis until I decide to make my own

// Bones
function RemoveRecoil()
	if GetConVarNumber("Hera_AIM_NoRecoil") == 1 then
		if LocalPlayer():GetActiveWeapon():IsValid() then
			LocalPlayer():GetActiveWeapon()Recoil = 0
		end
	end
end

function WeaponVector( value, typ )
        local s = ( -value )
       
        if ( typ == true ) then
                s = ( -value )
        elseif ( typ == false ) then
                s = ( value )
        else
                s = ( value )
        end
        return Vector( s, s, s )
end

local currentseed, cmd2, seed = currentseed || 0, 0, 0
local w, vecCone, valCone = "", Vector( 0, 0, 0 ), Vector( 0, 0, 0 )
 
local CustomCones       = {}
CustomCones.Weapons = {}
CustomCones.Weapons["weapon_pistol"]			= WeaponVector( 0.0100, true, true )		// HL2 Pistol
CustomCones.Weapons["weapon_smg1"]				= WeaponVector( 0.04362, true, true )		// HL2 SMG1
CustomCones.Weapons["weapon_ar2"]				= WeaponVector( 0.02618, true, true )		// HL2 AR2
CustomCones.Weapons["weapon_shotgun"]			= WeaponVector( 0.08716, true, true )		// HL2 SHOTGUN
CustomCones.Weapons["weapon_zs_zombie"]			= WeaponVector( 0.0, true, true )			// REGULAR ZOMBIE HAND
CustomCones.Weapons["weapon_zs_fastzombie"]		= WeaponVector( 0.0, true, true )			// FAST ZOMBIE HAND
 
local NormalCones = { [ "weapon_cs_base" ] = true }
 
function GetCone( wep )
        local c = wep.Cone
       
        if ( !c && ( type( wep.Primary ) == "table" ) && ( type( wep.Primary.Cone ) == "number" ) ) then c = 

wep.Primary.Cone end
        if ( !c ) then c = 0 end
        if ( type( wep.Base ) == "string" && NormalCones[ wep.Base ] ) then return c end
        if ( ( wep:GetClass() == "ose_turretcontroller" ) ) then return 0 end
        return c || 0
end

function HeraNoSpread( ucmd, angle )
        local ply = LocalPlayer()		
        cmd2, seed = abc_ucmd_getperdicston( ucmd ) // wtf nomical
        if ( cmd2 != 0 ) then currentseed = seed end       
        local w = ply:GetActiveWeapon(); vecCone = Vector( 0, 0, 0 )
        if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
                valCone = GetCone( w )                    
                if ( type( valCone ) == "number" ) then
                        vecCone = Vector( -valCone, -valCone, -valCone )                      
                elseif ( type( valCone ) == "Vector" ) then
                        vecCone = valCone * -1     
				elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
						vecCone = valCone + (cone*2)                        
                end
    else
                if ( w:IsValid() ) then
                        local class = w:GetClass()
                                if ( CustomCones.Weapons[ class ] ) then
                                        vecCone = CustomCones.Weapons[ class ]
                                end
                        end
                end
        return abc_donospred( currentseed || 0, ( angle || ply:GetAimVector():Angle() ):Forward(), vecCone ):Angle() // "spred"
end

local Aimspots = {
	"head",
	"forward",
	"eyes"
};

// credits to dicks johnson
local function Aimspot( e )
	local Pos; // empty the var
	for k, v in pairs( Aimspots ) do
		if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
			Pos = e:GetAttachment( e:LookupAttachment( v ) )["Pos"];
		end
	end
	return Pos;
end

// credits to dicks niggerson
local function bIsVisible( e )
	local Trace = {};
	Trace.start = LocalPlayer():GetShootPos();
	Trace.endpos = Aimspot( e );
	Trace.mask = MASK_SHOT|CONTENTS_HITBOX;
	Trace.filter = e, LocalPlayer();
	local tr = util.TraceLine( Trace );
	if( tr.Fraction == 1.0 ) then
		return true;
	end
end

// 80% credits to dicks johnson
local function bIsValid( e )
	if( !ValidEntity( e ) or !( e:IsPlayer() or e:IsNPC() ) ) then return false; end
	if( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then return false; end
	if( e:IsNPC() ) then return true; end
	if( GetConVarNumber( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then return false; end
	if( GetConVarNumber("Hera_AIM_Friendly") == 0 && e:Team() == LocalPlayer():Team() ) then return false; end
	if( GetConVarNumber("Hera_AIM_Steam") == 0 && e:GetFriendStatus() == "friend" ) then return false; end
	if( GetConVarNumber("Hera_AIM_Admins") == 0 && e:IsAdmin() ) then return false; end
	if( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then return false; end
	return true;
end

// 80% credits to dicks johnson
local function GetTargets()
	local Targets = {0,0};
	for k, v in pairs(player.GetAll()) do
		if( bIsVisible( v ) && bIsValid( v ) ) then
			local Diff = ( v:EyePos() - LocalPlayer():EyePos() ):Normalize();
			Diff = Diff - LocalPlayer():GetAimVector();
			Diff = Diff:Length();
			Diff = math.abs( Diff );
			if( Diff < Targets[2] || Targets[1] == 0 ) then
				Targets = { v, Diff };
			end
		end	
	end
	return( Targets[1] != 0 && Targets[1] != LocalPlayer() ) && Targets[1] || nil;
end

local weapons = {
	[ "weapon_crossbow" ] = 3110, // #HL2 CROSSBOW
}

// 100% credits to me
function Prediction(Pos,pl)
	if ValidEntity(pl) and type( pl:GetVelocity() ) == "Vector" and pl.GetPos and type( pl:GetPos() ) == "Vector" then
		local Distance = LocalPlayer():GetPos():Distance( pl:GetPos() )
		local Weapon = ( LocalPlayer().GetActiveWeapon and ( ValidEntity( LocalPlayer():GetActiveWeapon() ) and LocalPlayer():GetActiveWeapon():GetClass() ) )		
		if Weapon and weapons[ Weapon ] then
			local Time = Distance / weapons[ Weapon ]
			return Pos + pl:GetVelocity() * time
		end
	end
	return Pos
end

// 90% credits to dicks johnson
function Aimbot(ucmd)
	if ShouldAim == 1 then
		local Target = GetTargets();
		if( !Target ) then return; end
		Locked = true;
		local Aimspot = Aimspot( Target );
		Prediction( Target, Aimspot );
		Aimspot = Aimspot + Vector( 0, 0, GetConVarNumber("Hera_AIM_Offset") );
		local Angl = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
		Angl.p = math.NormalizeAngle( Angl.p )
		Angl.y = math.NormalizeAngle( Angl.y )
		if GetConVarNumber("Hera_AIM_NoSpread") == 1 or GetConVarNumber("Hera_AIM_ConstantNoSpread") == 1 then
			Spread = HeraNoSpread( ucmd, Angle( Angl.p, Angl.y, 0 ) )
		else
			Spread = Angle( Angl.p, Angl.y, 0 )
		end
		if GetConVarNumber("Hera_AIM_Auto") == 1 then
			ucmd:SetButtons( ucmd:GetButtons() | IN_ATTACK );
		end
	_R["CUserCmd"].SetViewAngles(ucmd,Spread)
	end
	if(!ShouldAim) then
		Locked = false;
	end
end


// wut
AddCMD("+Hera_Aim",function()
ShouldAim = 1
end)
AddCMD("-Hera_Aim",function()
ShouldAim = 0
end)

// Constant NoSpread
local angles = Angle( 0, 0, 0 )

function GetView()
	local ply = LocalPlayer()
	if ( !ValidEntity( ply ) ) then return end
	angles = ply:EyeAngles()
end

function CreateMove( ucmd )
if GetConVarNumber("Hera_AIM_ConstantNoSpread") == 1 and ShouldAim == 0 then
	angles.p = math.NormalizeAngle( angles.p )
	angles.y = math.NormalizeAngle( angles.y )
	
	local correct = 1
	angles.y = math.NormalizeAngle( angles.y + ( ucmd:GetMouseX() * -0.022 * correct ) )
	angles.p = math.Clamp( angles.p + ( ucmd:GetMouseY() * 0.022 * correct ), -89, 90 )
	ucmd:SetViewAngles( angles )
	
		if ( ucmd:GetButtons() & IN_ATTACK > 0 ) then
		local fakeang = HeraNoSpread( ucmd, angles )
		fakeang.p = math.NormalizeAngle( fakeang.p )
		fakeang.y = math.NormalizeAngle( fakeang.y )
		ucmd:SetViewAngles( fakeang )
		end
	end
end

function CalcView( ply, origin, angles, FOV )
	local ply = LocalPlayer()
	local w = ply:GetActiveWeapon()
	
	local wep = PlyM.GetActiveWeapon( ply )
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( ply, origin, angles, zoomFOV ) || {}
	view.angles = angles
	view.angles.r = 0
	view.fov = zoomFOV
	return view
end

local function PlayerConnect( name, ip )
	surface.PlaySound("ambient/levels/canals/drip4.wav")
	Hera.chat(tostring( name .. "'s IP: " .. ip ) )
end

---------------
--[[ HOOKS ]]--
---------------

--[ I LIED, I'M NOT CLEANING THIS UP AT ALL ]--


// I will clean this up later
// I will make each hook type load from a function later, I want to finish up the loading system first
function LoadHooks()
AddHook("HUDPaint",ESP);
AddHook("HUDPaint",RPESP)
AddHook("PlayerConnect",PlayerConnect);
AddHook("HUDPaint",Crosshair);
AddHook("HUDPaint",BoundingBox);
AddHook("PostDrawEffects",Chams);
AddHook("RenderScreenspaceEffects",BarrelHack);
AddHook("Think",Misc);
AddHook("CreateMove",Aimbot);
AddHook("CreateMove",CreateMove);
AddHook("OnToggled",GetView);
AddHook("Think",RemoveRecoil);
end

// Shitty Stronghold Vector() error fix
AddCMD("abr",function()
RemoveHook("CreateMove",Aimbot);
RemoveHook("CreateMove",CreateMove);
AddHook("CreateMove",Aimbot);
AddHook("CreateMove",CreateMove);
Hera.chat("Reloaded aimbot")
end)

 -- LOAD -- 
LoadHooks()
 -- LOAD -- 

// Unload function
function UnloadHooks()
Hera.print("Unloading hooks.");
RemoveHook("HUDPaint",ESP);
RemoveHook("HUDPaint",RPESP);
RemoveHook("HUDPaint",BoundingBox);
RemoveHook("HUDPaint",Crosshair);
RemoveHook("PostDrawEffects",Chams);
RemoveHook("RenderScreenspaceEffects",BarrelHack);
RemoveHook("Think",Misc);
RemoveHook("CreateMove",Aimbot);
RemoveHook("CreateMove",CreateMove);
RemoveHook("OnToggled",GetView);
end

// Unload ALL
function UnloadAll()
Hera.print("Unloading Hera");
UnloadHooks()
RemoveCMD("+Hera_Aim")
RemoveCMD("-Hera_Aim")
RemoveCMD("+Hera_Menu")
RemoveCMD("-Hera_Menu")
RemoveCMD("Hera_Menu")
timer.Destroy("bhop");
Hera.print("Unloaded Hera.")
end

// Reload cheat
function ReloadHooks()
UnloadHooks()
LoadHooks()
Hera.print("Reloaded.")
end

-------------------------------------
--[[ I MAY CHANGE THIS UP LATER! ]]--
--[[   PAINT IDEA FROM PBOT v3   ]]--
-------------------------------------


// CUSTOMIZATION MENU
AddCMD("Hera_Customize_Menu", function()
CustMenu = vgui.Create("DFrame")
CustMenu:SetSize(550,420)
CustMenu:SetTitle("Hera v3 :: Customization Menu :: Customize Features of the Cheat")
CustMenu:Center()
CustMenu:MakePopup()
CustMenu.Paint = function()
local mW, mH, x, y = CustMenu:GetWide(), CustMenu:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color( 0, 0, 0, 100 ) )
surface.SetDrawColor(BLACK)
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet2 = vgui.Create("DPropertySheet",CustMenu)
Sheet2:SetPos( 0, 25 )
Sheet2:SetSize( 550, 410 )
Sheet2.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet2:GetWide(), Sheet2:GetTall(), Color(GetConVarNumber("Hera_CUST_MenuColor_r"),GetConVarNumber("Hera_CUST_MenuColor_g"),GetConVarNumber("Hera_CUST_MenuColor_b"),GetConVarNumber("Hera_CUST_MenuColor_a")))
end

local Cust1 = vgui.Create("DLabel")
Cust1:SetParent( Sheet2 )
Cust1:SetPos( 0 , 10 )
Cust1:SetText("")

local Cust2 = vgui.Create("DLabel")
Cust2:SetParent( Sheet2 )
Cust2:SetPos( 0 , 10 )
Cust2:SetText("")


// START OF SLIDERS FOR CUSTOMIZE MENU
// Main 
AddSlider("Main Menu Color [Red]","Hera_CUST_MenuColor_r",Cust1,0,255,0,10,10,255,"Changes color of main menu")
AddSlider("Main Menu Color [Green]","Hera_CUST_MenuColor_g",Cust1,0,255,0,10,50,255,"Changes color of main menu")
AddSlider("Main Menu Color [Blue]","Hera_CUST_MenuColor_b",Cust1,0,255,0,10,90,255,"Changes color of main menu")
AddSlider("Main Menu Color [Alpha]","Hera_CUST_MenuColor_a",Cust1,0,255,0,10,130,255,"Changes color of main menu")

// ESP
AddSlider("Box Color [Red]","Hera_CUST_BoxColor_r",Cust2,0,255,0,10,10,255,"Changes the color of the bounding box")
AddSlider("Box Color [Green]","Hera_CUST_BoxColor_g",Cust2,0,255,0,10,50,255,"Changes the color of the bounding box")
AddSlider("Box Color [Blue]","Hera_CUST_BoxColor_b",Cust2,0,255,0,10,90,255,"Changes the color of the bounding box")
AddSlider("Box Color [Alpha]","Hera_CUST_BoxColor_a",Cust2,0,255,0,10,130,255,"Changes the color of the bounding box")


// Add Sheets for custom menu
Sheet2:AddSheet("Main Customization",Cust1,false,false,false,"Main Customization Settings")
Sheet2:AddSheet("ESP Customization",Cust2,false,false,false,"ESP / Wallhack Customization Settings")

end) -- End of customize menu function




// MAIN MENU
AddCMD("+Hera_Menu", function()
Menu = vgui.Create("DFrame")
Menu:SetSize(450,360)
Menu:SetTitle("                                                  :: Hera :: Version "..Version.." ::") -- Ignore the spacing.
Menu:Center()
Menu:MakePopup()
Menu.Paint = function()
local mW, mH, x, y = Menu:GetWide(), Menu:GetTall(), ScrW() / 2, ScrH() / 2
draw.RoundedBox( 0, 0, 0, mW, mH, Color( 0, 0, 0, 100 ) )
surface.SetDrawColor(BLACK)
surface.DrawOutlinedRect( 0, 0, mW , mH )
surface.DrawOutlinedRect( 0, 25, mW, mH )
end

local Sheet = vgui.Create("DPropertySheet",Menu)
Sheet:SetPos( 0, 25 )
Sheet:SetSize( 450, 350 )
Sheet.Paint = function()
draw.RoundedBox( 0, 0, 0, Sheet:GetWide(), Sheet:GetTall(), Color(GetConVarNumber("Hera_CUST_MenuColor_r"),GetConVarNumber("Hera_CUST_MenuColor_g"),GetConVarNumber("Hera_CUST_MenuColor_b"),GetConVarNumber("Hera_CUST_MenuColor_a")))
end

// fuck;
local Page1 = vgui.Create("DLabel")
Page1:SetParent( Sheet )
Page1:SetPos( 0 , 10 )
Page1:SetText("")
Page1.Paint = function()
draw.SimpleTextOutlined("Hera v"..Version.." - A Cheat By Tyler","Logo",20,3,CYAN,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,BLACK)
draw.SimpleTextOutlined("ConVar Forces","Logo",150,60,RED,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,BLACK)
draw.SimpleTextOutlined("Updates","Logo",170,120,LGREEN,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,BLACK)
draw.SimpleTextOutlined("Changelogs","Logo",160,180,PINK,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,BLACK)
draw.SimpleTextOutlined("Customize The Cheat","Logo",120,240,LBLUE,TEXT_ALIGN_LEFT,TEXT_ALIGN_LEFT,2,BLACK)
end
local Page2 = vgui.Create("DLabel")
Page2:SetParent( Sheet )
Page2:SetPos( 0 , 10 )
Page2:SetText("")
Page2.Paint = function()
end
local Page3 = vgui.Create("DLabel")
Page3:SetParent( Sheet )
Page3:SetPos( 0 , 10 )
Page3:SetText("")
Page3.Paint = function()
end
local Page4 = vgui.Create("DLabel")
Page4:SetParent( Sheet )
Page4:SetPos( 0 , 10 )
Page4:SetText("")
Page4.Paint = function()
end

-----------------------
--[[ MAIN TAB SHIT ]]--
-----------------------
// LOAD SHIT
local ReloadHooksButton = vgui.Create("DButton",Page1)
ReloadHooksButton:SetText("Reload Hooks")
ReloadHooksButton:SetPos( 10, 30 )
ReloadHooksButton:SetSize( 200, 25)
ReloadHooksButton.DoClick = function()
ReloadHooks()
Hera.chat("Reloaded hooks.")
end

local UnloadCheat = vgui.Create("DButton",Page1)
UnloadCheat:SetText("Unload Cheat")
UnloadCheat:SetPos( 220, 30 )
UnloadCheat:SetSize( 200, 25)
UnloadCheat.DoClick = function()
Hera.chat("Unloaded! Removed: Hooks/ConCommands/Timers")
UnloadAll()
end

// CONVAR Forces
local svcheats = vgui.Create("DButton",Page1)
svcheats:SetText("sv_cheats")
svcheats:SetPos( 10,90 )
svcheats:SetSize( 200, 25)
svcheats.DoClick = function()
Hera:ForceCVar("sv_cheats",1)
end

local allowvoice = vgui.Create("DButton",Page1)
allowvoice:SetText("sv_allow_voice_from_file")
allowvoice:SetPos( 220,90 )
allowvoice:SetSize( 200, 25)
allowvoice.DoClick = function()
Hera:ForceCVar("sv_allow_voice_from_file",1)
end

// UPDATE SHIT
local checkupdate = vgui.Create("DButton",Page1)
checkupdate:SetText("Check for updates")
checkupdate:SetPos( 10,150 )
checkupdate:SetSize( 200, 25)
checkupdate.DoClick = function()
Hera:CheckUpdates()
end

local doupdate = vgui.Create("DButton",Page1)
doupdate:SetText("Update the cheat")
doupdate:SetPos( 220,150 )
doupdate:SetSize( 200, 25)
doupdate.DoClick = function()
Hera:Update()
end

// CHANGELOG SHIT
local openchangelog = vgui.Create("DButton",Page1)
openchangelog:SetText("Open changelogs")
openchangelog:SetPos( 10, 210 )
openchangelog:SetSize( 410,25)
openchangelog.DoClick = function()
Hera.chat("Changelogs removed.")
end

// CUSTOMIZE SHIT
local custombutton = vgui.Create("DButton",Page1)
custombutton:SetText("Open Customization Menu")
custombutton:SetPos( 10, 270 )
custombutton:SetSize( 410,25)
custombutton.DoClick = function()
RunConsoleCommand("Hera_Customize_Menu");
end

-------------------------
--[[ AIMBOT TAB SHIT ]]--
-------------------------
AddCheckBox("Autoshoot","Hera_AIM_Auto",Page2,10,10,"Autoshoot when locked")
AddCheckBox("Friendly Fire","Hera_AIM_Friendly",Page2,10,30,"Target your own team")
AddCheckBox("Target Steam Friends","Hera_AIM_Steam",Page2,10,50,"Target Steam Friends")
AddCheckBox("Target Admins","Hera_AIM_Admins",Page2,10,70,"Target Admins")
AddCheckBox("No-Recoil","Hera_AIM_NoRecoil",Page2,10,90,"Remove Recoil")
AddCheckBox("No-Spread","Hera_AIM_NoSpread",Page2,10,110,"Remove Spread while aimbotting")
AddCheckBox("Constant No-Spread","Hera_AIM_ConstantNoSpread",Page2,10,130,"Constant No-Spread")

AddSlider("Aimbot Offset","Hera_AIM_Offset",Page2,-25,25,1,10,260,200,"Offsets your aimspot")

-------------------------------------
--[[ ESP | WALLHACK | VISUAL TAB ]]--
-------------------------------------
AddCheckBox("[ESP] Info","Hera_ESP_Info",Page3,10,10,"Show player's info on the ESP")
AddCheckBox("[ESP] Chams","Hera_ESP_Chams",Page3,10,30,"Show a player's model through walls")
AddCheckBox("[ESP] Head Marker","Hera_ESP_Cross",Page3,10,50,"Show a cross on a player's headspot")
AddCheckBox("[ESP] Bounding Box","Hera_ESP_Box",Page3,10,70,"Draw a box around players")

AddCheckBox("[VIS] Crosshair","Hera_ESP_Crosshair",Page3,150,10,"Draw a crosshair on your screen")
AddCheckBox("[VIS] Client Laser Sight","Hera_ESP_Laser",Page3,150,30,"Draw a laser from your screan to your aimpos")

local ListESP1 = vgui.Create( "DMultiChoice" )
ListESP1:SetPos( 330, 280 )
ListESP1:SetParent( Page3 )
ListESP1:SetSize( 100, 20 )
ListESP1:AddChoice( "Wireframe" )
ListESP1:AddChoice( "Solid" )
ListESP1:SetConVar( "Hera_ESP_Chams_Material" )

local ESPLabel1 = vgui.Create("DLabel")
ESPLabel1:SetParent( Page3 )
ESPLabel1:SetPos(335,265)
ESPLabel1:SetText("Chams Material")
ESPLabel1:SetTextColor(Color(255,255,255,255))
ESPLabel1:SizeToContents()

---------------------------
--[[ MISC TAB SETTINGS ]]--
---------------------------
AddCheckBox("Traitor Finder","Hera_MISC_TTT",Page4,10,10,"Find traitors in TTT")
AddCheckBox("Bunnyhop","Hera_MISC_BunnyHop",Page4,10,30,"Bunnyhop by holding 'Space'")

AddSlider("Speedhack Speed","Hera_MISC_Speedhack_Speed",Page4,0,10,1,10,260,200,"Sets the speed of the speedhack")

// Add sheets
Sheet:AddSheet("Main",Page1,false,false,false,"Main cheat settings")
Sheet:AddSheet("Aimbot",Page2, false, false, false, "Aimbot Settings")
Sheet:AddSheet("ESP | Wallhack | Visual",Page3,false,false,false,"ESP/Wallhack Settings")
Sheet:AddSheet("Miscellaneous",Page4,false,false,false,"Miscellaneous Settings")
	
end) -- End of +Hera_Menu function	
AddCMD("-Hera_Menu",function()
	Menu:SetVisible(false)
end)	

AddCMD("Hera_Menu",function()
	Menu:SetVisible(true)
end)


--[[
==========================

End of Hera v3

==========================
]]--

--[[
================================

Yeah, it's not very good.
I only spent a day or 2 on this.

================================
]]--