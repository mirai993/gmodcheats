--[[
	lua/autorun/client/hugoaim.lua
	[Asm]ϟ MasterX ϟ | (STEAM_0:1:54787435)
	===DStream===
]]

local TriggerBot = CreateClientConVar( "aimbot_enabled", 0, true, false )
 
hook.Add( "Think", "Aimbot", function()
 
local Target = LocalPlayer():GetEyeTrace().Entity
 
if TriggerBot:GetInt() == 1 and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() or Target:IsNPC() ) then
 

end
 
end )