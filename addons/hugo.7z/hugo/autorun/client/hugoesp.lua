--[[
	lua/autorun/client/hugoesp.lua
	[Asm]ϟ MasterX ϟ | (STEAM_0:1:54787435)
	===DStream===
]]

CreateClientConVar( "wallhack_enabled", 0, true, false )

hook.Add( "HUDPaint", "Wallhack", function()
 
if ConVarExists( "wallhack_enabled" ) and GetConVar("wallhack_enabled"):GetInt() == 1 then
 
for k,v in pairs ( player.GetAll() ) do
 
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
draw.DrawText( v:Name(), "MenuLarge", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
end
 
end
 
end )