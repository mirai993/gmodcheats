--[[
	MOD/lua/T7/T7AIM.lua
	special hed :: The Odyssey | STEAM_0:1:59601079 <184.15.7.53:27005> | [26-11-13 04:05:57AM]
	===BadFile===
]]

local T7Aim = 0 
    CreateClientConVar( "T7_Aimbot_IgnoreSteamFriends", 1, true, false )
    CreateClientConVar( "T7_Aimbot_AimMode", 2, true, false )
    CreateClientConVar( "T7_Aimbot_AimBone", 1, true, false )
    CreateClientConVar( "T7_Aimbot_AimOffset", 0, true, false )
    CreateClientConVar( "T7_Aimbot_NoRecoil", 1, true, false )
    CreateClientConVar( "T7_Aimbot_Friendlyfire", 1, true, false )
    CreateClientConVar( "T7_Aimbot_IgnoreAdmins", 1, true, false )
    CreateClientConVar( "T7_Aimbot_IgnoreFriends", 0, true, false )
    CreateClientConVar( "T7_Aimbot_SmoothAimSpeed", 2, true, false )
    CreateClientConVar( "T7_Aimbot_SmoothAimEnabled", 0, true, false )
    CreateClientConVar( "T7_Aimbot_TriggerBot", 0, true, false )
     
    RunConsoleCommand( "T7_Aimbot_AimMode", tonumber( GetConVarNumber( "T7_Aimbot_AimMode" ) ) )
     
    concommand.Add( "+T7_Aim", function()
    T7Aim = 1
    end )
     
    concommand.Add( "-T7_Aim", function()
    T7Aim = 0
    end )
     
    function IsVisible( ent )
    local tracer = {}
    tracer.start = LocalPlayer():GetShootPos()
    tracer.endpos = ent:GetShootPos()
    tracer.filter = { LocalPlayer(), ent }
    tracer.mask = MASK_SHOT
    local trace = util.TraceLine( tracer )
    if trace.Fraction >= 1 then return true else return false end
    end
     
    function Exceptions( ent124 )
    if GetConVarNumber( "T7_Aimbot_IgnoreSteamFriends" ) == 1 then
    if ent124:GetFriendStatus() != "friend" then return true end
    else return true
            end
    end
     
    function Exceptions2( entt124 )
    if GetConVarNumber( "T7_Aimbot_Friendlyfire" ) == 0 then
    if entt124:Team() != LocalPlayer():Team() then return true end
    else return true
            end
    end
     
    function Exceptions3( enta124 )
    if GetConVarNumber( "T7_Aimbot_IgnoreAdmins" ) == 1 then
    if enta124:IsAdmin() or enta124:IsSuperAdmin() then return false else return true end
    else
    return true
            end
    end
     
    function Exceptions4( v12 )
    if GetConVarNumber( "T7_Aimbot_IgnoreFriends" ) < 1 then return true end
    if #friendslist < 1 then return true end
    for k1, v1 in pairs( friendslist ) do
    if v12:Nick() ~= v1 then
    return true
    else
    return false
                    end
            end
    end
     
    function ClosestTarget()
    local target = { NULL, 0 }
    for k, v in ipairs( player.GetAll() ) do
    if IsValid( v ) then
     
    if v ~= LocalPlayer() then
     
    if IsVisible( v ) then
     
    if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= "1001" and v:Team() ~= "1002" then
    if v:Health() > 0 and v:Alive() then
    if !v:InVehicle() then
    if IsVisible( v ) then
    if Exceptions( v ) then
    if Exceptions2( v ) then
    if Exceptions3( v ) then
    if Exceptions4( v ) then
    local distance = v:GetPos() - LocalPlayer():GetPos()
    distance = distance:Length()
    distance = math.abs( distance )
    if ( distance < target[2] or target[1] == NULL ) then
    target = { v, distance }
                                                                                                    end
                                                                                            end
                                                                                    end
                                                                            end
                                                                    end
                                                            end
                                                    end
                                            end    
                                    end
                            end
                    end
            end
    end
    if IsValid( target[1] ) then
    if target[1] != LocalPlayer() then
    return target[1]
    else
    return LocalPlayer()
                    end
            end
    end
     
    function ClosestTarget2()
    local pos = LocalPlayer():GetPos()
    local ang = LocalPlayer():GetAimVector()
    local target2 = { NULL, 0 }
    for k, v in ipairs( player.GetAll() ) do
    if IsValid( v ) then
    if v ~= LocalPlayer() then
     
    if IsVisible( v ) then
     
    if v:Team() ~= TEAM_SPECTATOR and v:Team() ~= TEAM_UNASSIGNED and v:Team() ~= TEAM_CONNECTING then
    if v:Health() > 0 and v:Alive() then
    if !v:InVehicle() then
    if Exceptions( v ) then
    if Exceptions2( v ) then
    if Exceptions3( v ) then
    if Exceptions4( v ) then
    local crosshair =  v:GetPos() - pos
    if crosshair == nil then
        print("RIP")
    end
    crosshair = crosshair - ang
    crosshair = crosshair:Length()
    crosshair = math.abs( crosshair )
    if ( crosshair < target2[2] ) or ( target2[1] == NULL ) then
    target2 = { v, crosshair }
                                                                                            end
                                                                                    end
                                                                            end
                                                                    end
                                                            end    
                                                    end
                                            end
                                    end
                            end
                    end
            end
    end
     
    if IsValid( target2[1] ) then
    if target2[1] != LocalPlayer() then
    return target2[1]
    else
    return LocalPlayer()
                    end
            end
    end
     
    hook.Add( "Think", "T7NoRecoil", function()
    if GetConVarNumber( "T7_Aimbot_NoRecoil" ) >= 1 then
    if LocalPlayer():GetActiveWeapon().Primary then
    LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                    end
            end
    end )
                                   
    function Target()
    if GetConVarNumber( "T7_Aimbot_AimMode" ) >= 2 then
    return ClosestTarget2()
    elseif GetConVarNumber( "T7_Aimbot_AimMode" ) <= 1 then
    return ClosestTarget()
            end
    end
     
    hook.Add( "Think", "TriggerBot1", function()
    if GetConVarNumber( "T7_Aimbot_TriggerBot" ) == 1 then
    if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
    RunConsoleCommand( "+attack" )
    else
    RunConsoleCommand( "-attack" )
            end
        end
end )
     
    --------------------------------------------------------------
    local w = ScrW() / 2 - 28
    local h = ScrH() / 2 - 55
     
    CreateClientConVar( "T7_Aimbot_ShowAimStatus", 1, true, false )
     
    function AimBoat()
     
    if T7Aim == 1 then
     
    if !Target() then
    if GetConVarNumber( "T7_Aimbot_ShowAimStatus" ) >= 1 then
    draw.SimpleText( "[Finding...]", "Default", w, h, Color( 0, 150, 50, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
            end
    end
     
    if Target() and IsValid( Target() ) then
     
    local BonePos
    local TarAng
     
    if GetConVarNumber( "T7_Aimbot_AimBone" ) <= 0 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 1 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Head1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 2 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Neck1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 3 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine4" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 4 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine2" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 5 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine1" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) == 4 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    elseif GetConVarNumber( "T7_Aimbot_AimBone" ) >= 5 then
    BonePos = Target():GetBonePosition( Target():LookupBone( "ValveBiped.Bip01_Spine" ) ) + Vector( 0, 0, tonumber( GetConVarNumber( "T7_Aimbot_AimOffset" ) ) )
    end
     
    BonePos = BonePos + Target():GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50
     
    TarAng = ( BonePos - LocalPlayer():GetShootPos() ):Angle()
     
    TarAng.p = math.NormalizeAngle( TarAng.p )
    TarAng.y = math.NormalizeAngle( TarAng.y )
    TarAng.r = 0
     
    if GetConVarNumber( "T7_Aimbot_SmoothAimEnabled" ) >= 1 then
     
    local Angle1 = LocalPlayer():EyeAngles()
    local Smooth1 = math.Approach( LocalPlayer():EyeAngles().p, TarAng.p, GetConVarNumber( "T7_Aimbot_SmoothAimSpeed" ) )
    local Smooth2 = math.Approach( LocalPlayer():EyeAngles().y, TarAng.y, GetConVarNumber( "T7_Aimbot_SmoothAimSpeed" ) )
     
    LocalPlayer():SetEyeAngles( Angle( Smooth1, Smooth2, 0 ) )
     
    if GetConVarNumber( "T7_Aimbot_ShowAimStatus" ) >= 1 then
    draw.SimpleText( "OK - ", "Default", w, h, Color( 0, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
    draw.SimpleText( "TARGET: " .. Target():Nick(), "Default", w, h + 15, Color( 0, 255, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
    end
     
    else
     
    LocalPlayer():SetEyeAngles( Angle( TarAng.p, TarAng.y, 0 ) )
     
    if GetConVarNumber( "T7_Aimbot_ShowAimStatus" ) >= 1 then
    draw.SimpleText( "LOCKED:", "Default", w, h, Color( 150, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
    draw.SimpleText( "AIMING AT: " .. Target():Nick(), "Default", w, h + 15, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT )
    end
     
    if !LocalPlayer():GetEyeTrace().Entity:IsPlayer() then return end
     
                            end
                    end
            end
    end
    hook.Add( "HUDPaint", "T7HacT7Boat", AimBoat )
     
     
     
     
    function EntMaterial()
     
        local DermaPanel = vgui.Create( "DFrame" )
        DermaPanel:SetPos( 50,50 )
        DermaPanel:SetSize( 600, 700 )
        DermaPanel:SetTitle( "Material finder" )
        DermaPanel:SetVisible( true )
        DermaPanel:SetDraggable( true )
        DermaPanel:ShowCloseButton( true )
        DermaPanel:MakePopup()
         
        local DermaListView = vgui.Create("DListView")
        DermaListView:SetParent(DermaPanel)
        DermaListView:SetPos(25, 50)
        DermaListView:SetSize(565, 625)
        DermaListView:SetMultiSelect(false)
        DermaListView:AddColumn("Owner") -- Add column
        DermaListView:AddColumn("Class") -- Add column
        DermaListView:AddColumn("Prop") -- Add column
        DermaListView:AddColumn("Material")
        DermaListView.OnRowRightClick = function(panel, line)
            local entowner = panel:GetLine(line):GetValue(1)
            local entclass = panel:GetLine(line):GetValue(2)
            local entmpath = panel:GetLine(line):GetValue(3)
            local entmater = panel:GetLine(line):GetValue(4)
            local Menu = DermaMenu()
            Menu:AddOption("Spawn Prop", function() me:ConCommand("gm_spawn ".. entmpath) end)        
            Menu:AddOption("Set Material Tool", function() me:ConCommand("material_override ".. entmater) end)
            local SubMenu1 = Menu:AddSubMenu("Copy")
            SubMenu1:AddOption("Owner", function() SetClipboardText(entowner) end)
            SubMenu1:AddOption("Class", function() SetClipboardText(entclass) end)
            SubMenu1:AddOption("Prop", function() SetClipboardText(entmpath) end)
            SubMenu1:AddOption("Material", function() SetClipboardText(entmater) end)
            SubMenu1:AddOption("All", function() SetClipboardText(entowner .. "  |  " .. entclass .. "  |  " .. entmpath .. " |  " .. entmater) end)
                //SubMenu1:AddOption
            Menu:Open()
        end
         
        for k,v in pairs(ents.GetAll()) do
            DermaListView:AddLine(v:GetOwner(),v:GetClass(),v:GetModel(),v:GetMaterial()) -- Add lines
        end
    end
    concommand.Add("entlist", EntMaterial)
     
    concommand.Add("+ssspeed", function() RunConsoleCommand("host_timescale", 30.0) end)
    concommand.Add("-ssspeed", function() RunConsoleCommand("host_timescale", 1.0) end)