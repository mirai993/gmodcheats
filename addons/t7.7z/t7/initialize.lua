--[[
	MOD/lua/T7/Initialize.lua
	special hed :: The Odyssey | STEAM_0:1:59601079 <184.15.7.53:27005> | [26-11-13 04:05:56AM]
	===BadFile===
]]

include("T7.lua")
include("Alternative.lua")
include("T7AIM.lua")
include("Utilities.lua")
include("T7Force.lua")