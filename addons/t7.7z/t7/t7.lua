--[[
	MOD/lua/T7/T7.lua
	special hed :: The Odyssey | STEAM_0:1:59601079 <184.15.7.53:27005> | [26-11-13 04:02:35AM]
	===BadFile===
]]

--[[
 _______ ______   ____         __          __        
|__   __|____  | |  _ \        \ \        / /        
   | |      / /  | |_) |_   _   \ \  /\  / /_ _ _ __ 
   | |     / /   |  _ <| | | |   \ \/  \/ / _` | '__|
   | |    / /    | |_) | |_| |    \  /\  / (_| | |   
   |_|   /_/     |____/ \__, |     \/  \/ \__,_|_|   
                         __/ |                       
                        |___/                        
]]--

--[[              Color Shortcuts                          ]]--

local Red 						= Color(255,0,0,255);
local Black 					= Color(0,0,0,255);
local Green 					= Color(0,255,0,255);
local White 					= Color(255,255,255,255);
local Blue 						= Color(0,0,255,255);
local Cyan 						= Color(0,255,255,255);
local Pink 						= Color(255,0,255,255);
local Blue 						= Color(0,0,255,255);
local Grey 						= Color(100,100,100,255);
local Gold 						= Color(255,228,0,255);
local LightBlue					= Color(155,205,248);
local LightGreen			    = Color(174,255,0);
local IceBlue 					= Color(116,187,251,255);
local Purple 					= Color(255,0,255,255);

-------------------------------------------------------------------

--[[                      Utility                         ]]--

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util  = util
local IsValid = IsValid
local T7Backup = debug.getregistry()
local T7Objects = {}
local T7GetString = T7Backup.Entity.GetNWString
local T7GetInt = T7Backup.Entity.GetNWInt
local RayOn = false
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {
    ["cluaeffect"] = true,
    ["fog"] = true,
    ["waterlodcontrol"] = true,
    ["clientragdoll"] = true,
    ["envtonemapcontroller"] = true,
    ["entityflame"] = true,
    ["func_tracktrain"] = true,
    ["env_sprite"] = true,
    ["env_spritetrail"] = true,
    ["prop_effect"] = true,
    ["class c_sun"] = true,
    ["class C_ClientRagdoll"] = true,
    ["class C_BaseAnimating"] = true,
    ["clientside"] = true,
    ["illusionary"] = true,
    ["shadowcontrol"] = true,
    ["keyframe"] = true,
    ["wind"] = true,
    ["gmod_wire_hologram"] = true,
    ["effect"] = true,
    ["stasisshield"] = true,
    ["shadertest"] = true,
    ["portalball"] = true,
    ["portalskydome"] = true,
    ["cattails"] = true
}

 
function T7Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText( Blue, "[T7] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

-------------------------------------------------------------------

local function T7GetOffset( ply )
    if !IsValid( ply ) then return Vector( 0, 0, 0 ) end
    if !ply:GetAttachment( ply:LookupAttachment( "eyes" ) ) then
        return ply:GetShootPos():ToScreen()
    else
        return ply:GetAttachment( ply:LookupAttachment( "eyes" ) ).Pos:ToScreen()
    end
end

-------------------------------------------------------------------

concommand.Add("T7_ToggleLasersOFF", function()
	RunConsoleCommand("T7_HeadLasers", "0")
	RunConsoleCommand("T7_EyeLasers", "0")
	RunConsoleCommand("T7_GroundLasers", "0")
end )

concommand.Add("T7_ToggleLasersON", function()
	RunConsoleCommand("T7_HeadLasers", "1")
	RunConsoleCommand("T7_EyeLasers", "1")
	RunConsoleCommand("T7_GroundLasers", "1")
end )

-------------------------------------------------------------------

--[[              Console Commands | ConVars               ]]--

local Crosshair = CreateClientConVar( "T7_Crosshair", "1", true, false )
local espOn = CreateClientConVar("T7_ESP", "1", true, false )
local espName = CreateClientConVar("T7_ESPNames", "1", true, false )
local espHealth = CreateClientConVar("T7_ESPHealth", "1", true, false )
local espDistance = CreateClientConVar("T7_ESPDistance", "1", true, false )
local espWeapon = CreateClientConVar("T7_ESPWeapon", "1", true, false )
local espMoney = CreateClientConVar("T7_ESPMoney", "1", true, false )
local espGroup = CreateClientConVar("T7_ESPGroup", "1", true, false )
local groundLasers = CreateClientConVar("T7_GroundLasers", "1", true, false )
local headLasers = CreateClientConVar("T7_HeadLasers", "1", true, false )
local eyeLasers = CreateClientConVar("T7_EyeLasers", "1", true, false )
local repmat = CreateClientConVar( "T7_XrayMaterial", "mat1", true, false )
local PROPColor = CreateClientConVar( "T7_XrayPropColor", "33,33,33,60", true, false )
local PROPBGColor = CreateClientConVar( "T7_XrayPropBGColor", "33,33,33,39", true, false )
local MINEColor = CreateClientConVar( "T7_XrayMineColor", "33,33,33,60", true, false )
local HOLDINGColor= CreateClientConVar( "T7_XrayHoldingColor", "33,33,33,40", true, false )
local T7TTT = CreateClientConVar( "T7_TTT", 0, true, false )
local MINEBGColor = CreateClientConVar( "T7_XrayPropMineBGColor", "33,33,33,39", true, false )
local PLYColor = CreateClientConVar( "T7_XrayPlayerColor", "33,33,33,100", true, false )
local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local T7RayMat = repmat:GetString()

-------------------------------------------------------------------

--[[                   Crosshair                          ]]--

function DrawRCH(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end

function DrawCH()
    if Crosshair:GetInt() > 0 then
        local x,y = ScrW(),ScrH()
        local w,h = x/2,y/2
    
        surface.SetDrawColor(Color(0,0,0,235))
        surface.DrawRect(w - 1, h - 3, 3, 7)
        surface.DrawRect(w - 3, h - 1, 7, 3)

        surface.SetDrawColor(Color(0,255,10,230))
        surface.DrawLine(w, h - 2, w, h + 3)
        surface.DrawLine(w - 2, h, w + 3, h)

        local time = CurTime() * -180        
        local scale = 10 * 0.02 -- Cone
        local gap = 40 * scale
        local length = gap + 20 * scale

        surface.SetDrawColor(255,0,0,255)

        DrawRCH(w,h,time,      length,gap)
        DrawRCH(w,h,time + 90, length,gap)
        DrawRCH(w,h,time + 180,length,gap)
        DrawRCH(w,h,time + 270,length,gap)
    end
end

-------------------------------------------------------------------

--[[                    180 Script                         ]]--

concommand.Add("T7_180", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, 180, 0 ) )
end )

-------------------------------------------------------------------

concommand.Add("T7_180up", function()
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p, 180, 0 ) )
	RunConsoleCommand("+jump")
	timer.Simple( 0.1, function() RunConsoleCommand( "-jump" )
	end)
end )

-------------------------------------------------------------------

--[[                   ESP \ Xray                          ]]--

local function T7Draw()
		if espOn:GetInt() > 0 then
                    for _, v in pairs( T7Objects ) do
                            if v ~= "" then
                                    for k, b in pairs( ents.GetAll() ) do
                                            if string.find( string.lower( b:GetClass() ), string.lower( v ) ) then
                                                    local o = b:GetPos():ToScreen()
                                                    surface.SetDrawColor( 0, 0, 0, 255 )
                                                    surface.DrawRect( o.x - 6, o.y - 6, 12, 12 )
                                                    surface.SetDrawColor( 255, 255, 255, 255 )
                                                    surface.DrawRect( o.x - 5, o.y - 5, 10, 10 )
                                                   
                                                    surface.SetFont( "Default" )
                                                   
                                                    surface.SetDrawColor( 0, 0, 0, 100)
                                                    surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( b:GetClass() ) + 1, 12 )
                                                    surface.SetTextColor( 255, 255, 255, 255 )
                                                    surface.SetTextPos( o.x + 13, o.y - 7 )
                                                    surface.DrawText( b:GetClass() )
                                                   
                                                    surface.SetDrawColor( 0, 0, 0, 100)
                                                    surface.SetFont( "Default" )
                                                    surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 1, 12 )
                                                    surface.SetTextColor( 255, 255, 255, 255 )
                                                    surface.SetTextPos( o.x - 5, o.y - 20 )
                                                    surface.DrawText( "D: " .. math.floor( b:GetPos():Distance( LocalPlayer():GetPos() ) ) )
                                            end
                                    end
                            end
                    end
                    for _, v in pairs( player.GetAll() ) do
                            if v:Alive() and v ~= LocalPlayer() then
                                    local o = T7GetOffset( v )
                                   
                                    if v:GetPos():Distance( LocalPlayer():GetPos() ) < 500 then
                                            o.y = o.y - ( 100 - v:GetPos():Distance( LocalPlayer():GetPos() ) / 5 )
                                    end
                                   
                                    local color = team.GetColor( v:Team() )
                                    local money = (v.DarkRPVars and v.DarkRPVars.money) or T7GetInt(v, "money")
                                    surface.SetDrawColor( 0, 0, 0, 255 )
                                    surface.SetDrawColor( color.r, color.g, color.b, 255 )
                                    surface.DrawRect( o.x - 3, o.y - 3, 6, 6 )
                                    surface.SetDrawColor( color.r, color.g, color.b, 255 )
                                   
                                    surface.SetFont( "Default" )
                                   
                                    surface.SetDrawColor( 0, 0, 0, 85 )
                                    surface.DrawRect( o.x + 12, o.y - 6, surface.GetTextSize( v:Nick() ) + 1, 12 )
                                    surface.SetTextColor( 255, 255, 255, 255 )
                                    surface.SetTextPos( o.x + 13, o.y - 7 )
                                    surface.DrawText( v:Nick() )
                                   
                                    if espDistance:GetInt() > 0 then
                                            surface.SetDrawColor( 0, 0, 0, 85)
                                            surface.SetFont( "Default" )
                                            surface.DrawRect( o.x - 6, o.y - 19, surface.GetTextSize( "Distance: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) ) + 1, 12 )
                                            surface.SetTextColor( 255, 255, 255, 255 )
                                            surface.SetTextPos( o.x - 5, o.y - 20 )
                                            surface.DrawText( "Distance: " .. math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ) )
                                    end
                                    if espMoney:GetInt() > 0 then
                                            surface.SetDrawColor( 0, 0, 0, 85)
                                            surface.SetFont( "Default" )
                                            local add = 19
                                            if espDistance:GetInt() > 0 then add = 32 end
                                            surface.DrawRect( o.x - 6, o.y - add, surface.GetTextSize( "Money: " .. money) + 1, 12)
                                            surface.SetTextColor( 255, 255, 255, 255 )
                                            surface.SetTextPos( o.x - 5, o.y - add - 1 )
                                            surface.DrawText( "Money: " .. money)
                                    end     
                                    if espHealth:GetInt() > 0 then
                                            surface.SetDrawColor( 0, 0, 0, 85)
                                            surface.SetFont( "Default" )
                                            surface.DrawRect( o.x - 6, o.y + 7, surface.GetTextSize( "Health: " .. v:Health() ) + 1, 12 )
                                            surface.SetTextColor( 255, 255, 255, 255 )
                                            surface.SetTextPos( o.x - 5, o.y + 6 )
                                            surface.DrawText( "Health: " .. v:Health() )
                                    end
                                   
                                    if espWeapon:GetInt() > 0 and v:GetActiveWeapon():IsValid() then
                                            surface.SetDrawColor( 0, 0, 0, 85)
                                            surface.SetFont( "Default" )
                                            local add = 6
                                            if espHealth:GetInt() > 0 then add = 19 end
                                            surface.DrawRect( o.x - 6, o.y + add + 1, surface.GetTextSize( v:GetActiveWeapon():GetPrintName() ) + 1, 12 )
                                            surface.SetTextColor( 255, 255, 255, 255 )
                                            surface.SetTextPos( o.x - 5, o.y + add )
                                            surface.DrawText( v:GetActiveWeapon():GetPrintName() )
                                    end
                                    if espGroup:GetInt() > 0 then
                                        surface.SetDrawColor( 0, 0, 0, 85)
                                        surface.SetFont("Default")
                                        local add = 35
                                        local add2 = 20
                                        if espWeapon:GetInt() > 0 then add = 31 end
                                        if espHealth:GetInt() == 0 then add = 19 end
                                        if espWeapon:GetInt() == 0 then add = 19 end
                                        if espHealth:GetInt() == 0 && espWeapon:GetInt() == 0 then add = 6 end
                                        if espWeapon:GetInt() > 0 && !v:GetActiveWeapon():IsValid() then  
                                            add = 19
                                            surface.DrawRect( o.x - 5, o.y + add2, surface.GetTextSize( v:GetUserGroup() ) + 1, 12 )
                                        else
                                            add = 33
                                            surface.DrawRect( o.x - 5, o.y + add, surface.GetTextSize( v:GetUserGroup() ) + 1, 12 )
                                     end
                                        surface.SetTextPos( o.x - 5, o.y + add )
                                        surface.DrawText( v:GetUserGroup() )
                                        if v:GetActiveWeapon():IsValid() then
                                        end
                                    end
                                end
                            end
                        end
                    end


                    local ExecuteFray

local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
    if RayOn then
        local returnal = table.Copy(FindMetaTable("CLuaParticle"))
        for k,v in pairs(returnal or {}) do
            if type(v) == "function" then
                returnal[k] = function() end
            end
        end
        return returnal
    end
    return self:OldAdd(...)
end

function render.AddBeam(...)
    if not RayOn then
        return OldEffectFunctions.render_AddBeam(...)
    end
end

function render.DrawSprite(a,b,c,d,e, ...)
    if not RayOn or e then
        OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
    end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
    local Pls = player.GetAll()
    for ply=1, #Pls do
        Health = Pls[ply]:Health()
        if Health < 1 and Pls[ply].Spawned then
            Pls[ply].Spawned = false
            Pls[ply].BabyGod = false
        elseif Health > 0 and not Pls[ply].Spawned then
            Pls[ply].Spawned = true
            Pls[ply].BabyGod = true
            timer.Simple(bgodtime, function()
                if not IsValid(Pls[ply]) then return end
                Pls[ply].BabyGod = false
                if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
            end)
        end
    end
end
hook.Add("InitPostEntity", "a", function()
    babygod = tobool(GetConVarNumber("babygod"))
    bgodtime = tonumber(GetConVarNumber("babygodtime"))
    if babygod then
        hook.Add("Think", "T7DetectSpawn", RegisterSpawn)
    end
end)


local function ToggleFRay(ply, cmd, args)
    T7RayMat = repmat:GetString()
    RunConsoleCommand("r_cleardecals")

    if RayOn then
        surface.PlaySound("buttons/button19.wav")

        local ENTS = ents.GetAll()
        for v = 1, #ENTS do
            if not IsValid(ENTS[v]) then continue end

            SetMat(ENTS[v], entityMaterials[ENTS[v]])
            local z = entityColors[ENTS[v]]
            if z and type(z) == "table" then
                SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
            else
                SetColor(ENTS[v], Color(255,255,255,255))
            end


            local model = ENTS[v]:GetModel() or ""
            local class = GetClass(ENTS[v])
            if NoDraws[class] or NoDraws[model] then 
                SetNoDraw(ENTS[v], false)
            end
        end
        entityColors = {}

        hook.Remove("PostDrawOpaqueRenderables", "T7_Xray")
        hook.Remove("OnEntityCreated", "T7RayEntityInPVS")
        hook.Remove("PreDrawSkyBox", "removeSkybox")

        util.Effect = OLDUtilEffect
    else
        surface.PlaySound("/buttons/button17.wav")

        for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
            SetColor(v, Color(0,0,0,0))
        end

        util.Effect = function() end

        local ENTS = ents.GetAll()
        for v = 1, #ENTS do
            ExecFRayOnce(ENTS[v])
        end

        hook.Add("PreDrawSkyBox", "removeSkybox", function()
            render.Clear(50, 50, 50, 255)

            return true
        end)

        hook.Add("PostDrawOpaqueRenderables", "T7_Xray", ExecuteFray)
        hook.Add("OnEntityCreated", "T7RayEntityInPVS", function(ent)
            ExecFRayOnce(ent)
        end)
    end
    RayOn = not RayOn
end
concommand.Add("T7_Xray", ToggleFRay)

function ExecFRayOnce(v)
    if not IsValid(v) then return end
    local color = GetColor(v)
    local r,g,b,a = color.r, color.g, color.b, color.a
    local class = GetClass(v)
    local low = string.lower(class)
    local model = v:GetModel() or ""

    -- Set some entities to not draw
    if NoDraws[class] or NoDraws[model] then
        SetNoDraw(v, true)
        return
    end

    v:SetRenderMode(RENDERMODE_TRANSALPHA)
    if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
        entityColors[v] = Color(r,g,b,a)
        SetColor(v, Color(0, 0, 255, 30))
    elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
        VIEWMODEL = v
        entityColors[v] = Color(r,g,b,a)
        SetColor(v, Color(0, 0, 0, 30))
        SetMat(v, "mat1")
    elseif string.find(class, "ghost") and a ~= 100 then
        entityColors[v] = Color(r,g,b,a)
        SetColor(v, Color(255,255,255,100))
    elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
        entityColors[v] = Color(r,g,b,a)
        SetColor(v, Color(255, 0, 100, 50))
    elseif class == "prop_physics" or v:IsPlayer() then
        entityColors[v] = Color(r,g,b,a)
    elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXray and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
        entityColors[v] = Color(r,g,b,a)
        --SetColor(v, 255, 200, 0, 100)
        SetColor(v, Color(0, 255, 0, 100))
    end
    if class ~= "viewmodel" and GetMat(v) ~= T7RayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXray and not string.find(class, "ghost") then
        entityMaterials[v] = GetMat(v)
        SetMat(v, T7RayMat)
    end
end

local ScaleNormal = Vector()
local ScaleOutline1 = Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
    --size = size or 1.0
    render.SetBlend(a)
    render.SetColorModulation(r, g, b)

    -- First Outline
    --ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
    --SetMaterialOverride("mat4")
    ent:DrawModel()

    -- Revert everything back to how it should be
    render.MaterialOverride(nil)
    --ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
    if not RayOn then return end

    local PROPS = ents.FindByClass("prop_physics")
    local PLYS = player.GetAll()

    local ang = EyeAngles()
    local eyePos = EyePos()
    cam.Start3D(eyePos, ang)
        for v = 1, #PROPS do
            if IsValid(PROPS[v]) then
                local prop = PROPS[v]

                local IsHolding = LocalPlayer().IsHolding == PROPS[v]

                local r,g,b,a =
                    cPROPColor.r,
                    cPROPColor.g,
                    cPROPColor.b,
                    cPROPColor.a

                if PROPS[v].IsMine then
                    r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
                end
                if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
                    r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
                end

                SetColor(PROPS[v], Color(r, g, b, a))
                SetMat(PROPS[v], "mat4")
                if PROPS[v].IsMine then
                    local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
                    DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
                elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
                    DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
                end
                SetMat(PROPS[v], T7RayMat)
            end
        end

        for v = 1, #PLYS do
            if IsValid(PLYS[v]) then
                if PLYS[v].BabyGod then
                    SetColor(PLYS[v], Color(150,0,255,255))
                    if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
                        SetMat(VIEWMODEL, "mat2")
                        SetColor(VIEWMODEL, 255,0,0,40)
                    end
                else
                    if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
                        SetMat(VIEWMODEL, "mat1")
                        SetColor(VIEWMODEL, Color(0,0,0,30))
                    end
                    SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
                end
                SetMat(PLYS[v], "mat4")
                DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
                SetMat(PLYS[v], T7RayMat)
                if IsValid(PLYS[v]:GetActiveWeapon()) then
                    SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
                    DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
                end
            end
            if GetRagdollEntity(PLYS[v]) then
                SetNoDraw(GetRagdollEntity(PLYS[v]), true)
            end
        end
    cam.End3D()

end

-------------------------------------------------------------------

--[[                   Lasers                         ]]--

local function EyeLasers()
	if eyeLasers:GetInt() > 0 then
		cam.Start3D(EyePos(), EyeAngles())
		for k,ply in pairs(player.GetAll()) do
			if ply != LocalPlayer() && ply:Alive() then
				local shootPos = ply:GetShootPos()
				local eyeAngles = ply:EyeAngles()
				local data = {}
				data.start = shootPos
				data.endpos = shootPos + eyeAngles:Forward() * 10000
				data.filter = ply
				local tr = util.TraceLine(data)
				cam.Start3D2D(shootPos, eyeAngles, 1)
				if IsValid(tr.Entity) then
					surface.SetDrawColor(255, 0, 0, 255)
				else
					surface.SetDrawColor(0, 255, 0, 255)
				end
				surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
				cam.End3D2D()
			end
		end
		cam.End3D()
	end
end

local fuckAngle = Angle(-90,0,0)
local fuckAngle2 = Angle(90,0,0)

local function HeadLasers()
	if headLasers:GetInt() > 0 then
    	cam.Start3D(EyePos(), EyeAngles())
    		for k,ply in pairs(player.GetAll()) do
   	 	if ply != LocalPlayer() && ply:Alive() then
    		local shootPos = ply:GetShootPos()
    		local data = {}
    		data.start = shootPos
    		data.endpos = shootPos + fuckAngle:Forward() * 10000
   			data.filter = ply
    		local tr = util.TraceLine(data)
    		cam.Start3D2D(shootPos, fuckAngle, 1)
   		 if IsValid(tr.Entity) then
    		surface.SetDrawColor(255, 0, 0, 255)
    	else
    		surface.SetDrawColor(0, 255, 0, 255)
    	end
   			 surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
    	cam.End3D2D()
    	end
  	end
    	cam.End3D()
	end
end

local function GroundLasers()
		if groundLasers:GetInt() > 0 then
    	cam.Start3D(EyePos(), EyeAngles())
    		for k,ply in pairs(player.GetAll()) do
    	if ply != LocalPlayer() && ply:Alive() then
    		local shootPos = ply:GetShootPos()
    		local data = {}
    		data.start = shootPos
    		data.endpos = shootPos + fuckAngle2:Forward() * 10000
   			data.filter = ply
    		local tr = util.TraceLine(data)
    		cam.Start3D2D(shootPos, fuckAngle2, 1)
    	if IsValid(tr.Entity) then
    		surface.SetDrawColor(255, 0, 0, 255)
    	else
    		surface.SetDrawColor(0, 255, 0, 255)
    	end
   			 surface.DrawLine(0, 0, tr.HitPos:Distance(shootPos), 0)
    	cam.End3D2D()
    	end
  	end
    	cam.End3D()
	end
end

local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
        if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
                local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
                local UsedWeapons = {}
                local MapWeapons = {}
function IsATraitor( ply )
        for k, v in pairs( Traitors ) do
                if v == ply then
                        return true
                else
                        return false
                end
        end
end
 
timer.Create("TTT", 0.8, 0, function()
        if GetConVarNumber("T7_TTT") == 1 then
                if !IsATraitor( ply ) then
                        for k, v in pairs( ents.FindByClass( "player" ) ) do
                                if IsValid( v ) then
                                        if (!v:IsDetective()) then
                                                if v:Team() ~= TEAM_SPECTATOR then
                                                        for wepk, wepv in pairs( TWeapons ) do
                                                                for entk, entv in pairs( ents.FindByClass( wepv ) ) do
                                                                        if IsValid( entv ) then
                                                                                cookie.Set( entv, 100 - wepk )
                                                                                if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                local EntPos = ( entv:GetPos() - Vector(0,0,35) )
                                                                                                        if entv:GetClass() == wepv then
                                                                                                                if v:GetPos():Distance( EntPos ) <= 1 then
                                                                                                                        table.insert( Traitors, v )
                                                                                                                        T7Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
                                                                                                                        if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( UsedWeapons, cookie.GetNumber( entv ) )
                                                                                                                        else
                                                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( MapWeapons, cookie.GetNumber( entv ) )
                                                                                                                        end
                                                                                                                end
                                                                                                        end
                                                                                                end
                                                                                        end
                                                                                end
                                                                        end
                                                                end
                                                        end
                                                end
                                        end
                                end
                        end
                end
        end
end )
 
hook.Add("HUDPaint",function()
        if GetConVarNumber("T7_TTT") == 1 then
                for k, e in pairs( Traitors ) do
                        local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
                        if IsValid( e ) then
                                if e:Team() ~= TEAM_SPECTATOR then
                                        if ( !e:IsDetective() ) then
                                                PlayerIsTraitor = true
                                                draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
                                        end
                                end
                        end
                end
        end
end )
 
hook.Add("TTTPrepareRound",function()
timer.Simple( 2, function()
        for k, v in pairs( Traitors ) do
                table.remove( Traitors, k )
                Traitors = {}
        end
                for k, v in pairs( UsedWeapons ) do
                        table.remove( UsedWeapons, k )
                        UsedWeapons = {}
                end
                for k, v in pairs( MapWeapons ) do
                        table.remove( MapWeapons, k )
                        MapWeapons = {}
                end
        end )
end )
        end
end )

-------------------------------------------------------------------

--[[                       Hooks                      ]]--

hook.Add("HUDPaint","ESPDraw", T7Draw)
hook.Add("HUDPaint", "CH", DrawCH)
hook.Add("RenderScreenspaceEffects", "EyeLasers", EyeLasers )
hook.Add("RenderScreenspaceEffects", "HeadLasers", HeadLasers )
hook.Add("RenderScreenspaceEffects", "vHeadGround", GroundLasers )

-------------------------------------------------------------------