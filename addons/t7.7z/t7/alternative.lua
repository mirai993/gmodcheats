--[[
	MOD/lua/T7/Alternative.lua
	special hed :: The Odyssey | STEAM_0:1:59601079 <184.15.7.53:27005> | [26-11-13 04:02:26AM]
	===BadFile===
]]

local T7LastSpawned = ""
local BlockedModels = {}
local T7A = {}
T7A["models/props_c17/lockers001a.mdl"] = "models/props/cs_militia/refrigerator01.mdl"
T7A["models/props_junk/gascan001a.mdl"] = "models/props_junk/metal_paintcan001a.mdl"
T7A["models/props_wasteland/laundry_dryer001.mdl"] = "models/props_rooftop/dome_copper.mdl"
T7A["models/props_rooftop/dome_copper.mdl"] = "models/props/cs_militia/crate_stackmill.mdl"
T7A["models/props_combine/combine_fence01a.mdl"] = "models/props_c17/utilitypole01b.mdl"
T7A["models/props_c17/utilitypole01b.mdl"] = "models/xqm/helicopterrotorlarge.mdl"
T7A["models/props_combine/breen_tube.mdl"] = "models/props/de_nuke/coolingtower.mdl"
T7A["models/props/de_tides/gate_large.mdl"] = "models/props/de_train/lockers_long.mdl"
T7A["models/props/cs_militia/skylight_glass_p6.mdl"] = "models/props_debris/concrete_chunk02b.mdl"
T7A["models/props_rooftop/roof_vent002.mdl"] = "models/props/cs_assault/firehydrant.mdl"
T7A["models/props_debris/walldestroyed03a.mdl"] = "models/props_junk/ibeam01a_cluster01.mdl"
T7A["models/props_wasteland/interior_fence002d.mdl"] = "models/props/de_inferno/lattice.mdl"
T7A["models/props_junk/sawblade001a.mdl"] = "models/props/cs_militia/skylight_glass_p6.mdl"
T7A["models/props/cs_militia/refrigerator01.mdl"] = "models/props_c17/furniturestove001a.mdl"
T7A["models/props_vents/vent_large_grill001.mdl"] = "models/cheeze/pcb2/pcb6.mdl"
T7A["models/props/de_train/lockers_long.mdl"] = "models/props_lab/blastdoor001c.mdl"
T7A["models/props_canal/canal_bars004.mdl"] = "models/props/cs_militia/sheetrock_leaning.mdl"
T7A["models/xqm/coastertrack/slope_225_2.mdl"] = "models/xqm/coastertrack/slope_225_1.mdl"
T7A["models/xqm/coastertrack/slope_225_1.mdl"] = "models/hunter/misc/cone4x1.mdl"
T7A["models/xqm/coastertrack/slope_90_1.mdl"] = "models/hunter/misc/cone2x1.mdl"
T7A["models/hunter/tubes/tube1x1x6.mdl"] = "models/props_docks/dock03_pole01a.mdl"
T7A["models/props_docks/dock03_pole01a.mdl"] = "models/XQM/helicopterrotorlarge.mdl"
T7A["models/props_phx/construct/metal_angle360.mdl"] = "models/props_junk/trashdumpster02b.mdl"

function T7SpawnModel(Model, DontSpawn)
	local check = string.lower(Model)
	if not DontSpawn then
		T7LastSpawned = string.lower(Model)
	end
	while(table.HasValue(BlockedModels, check) and T7A[check]) do
		check = string.lower(T7A[check])
	end
	if not DontSpawn then RunConsoleCommand("gm_spawn", check) end
	return check, table.HasValue(BlockedModels, check)
end

hook.Add("PlayerBindPress", "SpawnModel", function(ply, bind, pressed, extraArg)
	local TheBind = string.Explode(' ', bind)
	if not TheBind[1] or string.lower(TheBind[1]) ~= "gm_spawn" or not pressed or extraArg then return end
	local DoSpawn = hook.Call("PlayerBindPress", nil, ply, bind, pressed, true)
	if not DoSpawn then T7SpawnModel(TheBind[2]) end
	return true
end )

concommand.Add("T7_ResetblockedModels", function() BlockedModels = {} end)

hook.Add("Think", "HookIntoFPP", function()
	if not FPP then return end
	local notify = FPP.AddNotify
	function FPP.AddNotify(str, type)
		if T7LastSpawned ~= '' and (str == "The model of this entity is in the black list!" or str == "The model of this entity is not in the white list!") then
			table.insert(BlockedModels, string.lower(T7LastSpawned))
			if T7A[string.lower(T7LastSpawned)] then
				T7SpawnModel(T7A[string.lower(T7LastSpawned)])
			end
		end
		return notify(str, type)
	end
end )