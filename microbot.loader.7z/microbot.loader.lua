local oldPrint = print
local print = function(str)
	oldPrint("MICROBOT.LOADER: " .. tostring(str))
end
local BotDownloadSuccess = function(body, len, headers, httpcode)
	print("Downloaded microbot.main.lua")
	print("Executing from buffer [ident=micrbot.main.lua]...")
    RunStringEx(body, "microbot.main.lua")
end
local BotDownloadFail = function(httpcode)
    print("Failed to fetch microbot.main.lua!")
end
http.Fetch("https://dl.dropbox.com/u/3657276/microbot.main.lua", BotDownloadSuccess, BotDownloadFail)
