--[[
	MOD/lua/bot.lua [#5438 (#5671), 2746318418]
	Ollie | STEAM_0:0:30709335 <85.23.158.207:27006> | [26.01.14 12:35:15PM]
	===BadFile===
]]

/*
	Aimbot & Triggerbot
	Coded by Ollie
	22/12/2013
*/

if SERVER then

	local AB = {}
	AB.Aimbot_Time = 15 // 15 seconds

	local Meta = FindMetaTable("Player")
	
	function Meta:ActivateAimbot() // Call this to activate the aimbot
	
		self:SetNWBool("aimbot_bool",1)
		
		timer.Simple(AB.Aimbot_Time,function()
			self:SetNWBool("aimbot_bool",0)
		end)
	
	end

end

if CLIENT then

	local AB = {}

	AB.CanTrigger = true
	
	// Clientside configuration
	
	AB.AimBot_AimBone = CreateClientConVar("ab_aimbone","ValveBiped.Bip01_Head1",true,false)
	AB.TriggerBot_Active = CreateClientConVar("ab_triggerbot",1,true,false)
	AB.AimBot_Active = CreateClientConVar("ab_aimbot",1,true,false)
	AB.ShowLocked = CreateClientConVar("ab_showlocked",1,true,false)
	AB.AutoReload = CreateClientConVar("ab_autoreload",1,true,false)
	
	AB.LockedEnemy = NULL
	AB.SpecAmt = team.NumPlayers(TEAM_SPECTATOR)
	
	local function GetAimBone()
		return AB.AimBot_AimBone:GetString()
	end
	
	local function GetTriggerBot()
		return AB.TriggerBot_Active:GetBool()
	end
	
	local function GetAimBot()
		return AB.AimBot_Active:GetBool()
	end
	
	local function ShowLocked()
		return AB.ShowLocked:GetBool()
	end
	
	local function AutoReload()
		return AB.AutoReload:GetBool()
	end
	
	// Localizations to speed it up a bit
	local player = player
	local math = math
	local LocalPlayer = LocalPlayer

	function AB.FindTarget() // Sort the available enemies by distance

		local distance
		local entity = NULL
		
		for k,v in pairs(player.GetAll()) do
		
			if v == LocalPlayer() or v:Alive() == false or v:Team() == LocalPlayer():Team() then
				continue
			else
				
				local BoneIndx = v:LookupBone(GetAimBone())
				if BoneIndx == nil then
					return entity
				end
				
				local BonePos , BoneAng = v:GetBonePosition( BoneIndx )
				
				local tracedata = {}
				tracedata.start = LocalPlayer():GetShootPos()
				tracedata.endpos = BonePos
				tracedata.filter = LocalPlayer()
				
				local trace = util.TraceLine(tracedata)
			
				if trace.Entity != v then
					continue
				end
			
				local ldist = LocalPlayer():GetPos():Distance(v:GetPos())
				if (distance == nil or ldist < distance) then
					distance = ldist
					entity = v
				end
				
			end
			
		end
		
		return entity
	end

	function AB.ValidPlayerAmount() 
		return (#player.GetAll()-1) > 0
	end
	
	function AB.HasLineOfSight(ply)
	
		local BoneIndx = ply:LookupBone(GetAimBone())
		if BoneIndx == nil then
			return entity
		end
		
		local BonePos , BoneAng = ply:GetBonePosition( BoneIndx )
	
		local tracedata = {}
		tracedata.start = LocalPlayer():GetShootPos()
		tracedata.endpos = BonePos
		tracedata.filter = LocalPlayer()
		
		local trace = util.TraceLine(tracedata)
	
		if trace.Entity == ply then
			return true
		else
			return false
		end
		
	end
	
	hook.Add("HUDPaint","LockedOnPaint",function()
		if ShowLocked() then
			if AB.LockedEnemy != NULL then
				local ts = AB.LockedEnemy:GetShootPos():ToScreen()
				draw.SimpleTextOutlined("Locked!","Default",ts.x,ts.y,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_BOTTOM,1,Color(0,0,0))
			end
		end
	end)

	function AB.Think()
	
		if AB.SpecAmt != team.NumPlayers(TEAM_SPECTATOR) then
			if (AB.SpecAmt < team.NumPlayers(TEAM_SPECTATOR)) then
				chat.AddText(Color(255,0,0),"Someone has joined the spectator team! Watch out!")
			end
			AB.SpecAmt = team.NumPlayers(TEAM_SPECTATOR)
		end
		
		if AutoReload() then
			local wep = LocalPlayer():GetActiveWeapon()
			if wep:IsValid() then
				if wep:Clip1() == 0 then
					RunConsoleCommand("+reload")
					timer.Simple(0,function() RunConsoleCommand("-reload") end)
				end
			end
		end
	
		if GetAimBot() == true then

			if LocalPlayer():GetNWBool("aimbot_bool",0) == 0 then
				return
			end

			if AB.ValidPlayerAmount() == false then
				return
			end
			
			if AB.LockedEnemy == NULL or AB.LockedEnemy:IsValid() == false or AB.LockedEnemy:Alive() == false or AB.HasLineOfSight(AB.LockedEnemy) == false then
				AB.LockedEnemy = AB.FindTarget()
				if AB.LockedEnemy == NULL or AB.LockedEnemy == nil then
					return
				end
			end
			
			if AB.LockedEnemy:IsPlayer() and AB.LockedEnemy:IsValid() and AB.HasLineOfSight(AB.LockedEnemy) then
			
				local BoneIndx = AB.LockedEnemy:LookupBone(GetAimBone())
				if BoneIndx == nil then
					return entity
				end
					
				local BonePos , BoneAng = AB.LockedEnemy:GetBonePosition( BoneIndx )
			
				local pos = LocalPlayer():GetShootPos()
				
				local tracedata = {}
				tracedata.start = pos
				tracedata.endpos = BonePos
				tracedata.filter = ply
				
				local trace = util.TraceLine(tracedata)
				
				if trace.Entity == AB.LockedEnemy then
					
					local angle = (BonePos-pos):Angle()
					LocalPlayer():SetEyeAngles(angle)
					
					if GetTriggerBot() == true then
					
						if AB.CanTrigger == true then
						
							local weapon = LocalPlayer():GetActiveWeapon()
							if weapon == NULL or weapon:GetClass() == "gmod_camera" or weapon:Clip1() <= 0 or weapon:GetNetworkedBool("reloading") == true or weapon.reloading or weapon.Reloading or weapon.isReloading then return end
						
							RunConsoleCommand("+attack")
							
							timer.Simple(0, function() RunConsoleCommand("-attack") end)
							timer.Simple(0.05, function() AB.CanTrigger = true end)
							
							AB.CanTrigger = false
					 
						end
					 
					end
					 
				end
			
			end
		
		end

	end

	hook.Add("Tick","AB_MainThink",AB.Think)

end