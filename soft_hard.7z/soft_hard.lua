--[[
	lua/aim.lua
	[Asm]Capster | (STEAM_0:0:40196066)
	===DStream===
]]

concommand.Add( "aim_e", function()
function aimbot() 
	local ply = LocalPlayer() 
	local trace = util.GetPlayerTrace( ply ) 
	local traceRes = util.TraceLine( trace ) 
	if traceRes.HitNonWorld then 
		local target = traceRes.Entity 
		if target:IsPlayer() then 
			local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
			local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
			ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
		end
	end
end
hook.Add("Think","aimbot",aimbot)

end )
concommand.Add( "hard_e", function()
	function hard() 
		for k,v in pairs ( player.GetAll() ) do
			local target = v  
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1") 
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
			end
		end
	end	
hook.Add("Think","hard",hard)	
end)
concommand.Add( "wh_e", function()
hook.Add( 'HUDPaint', 'lah', function()
cam.Start3D( EyePos(), EyeAngles() )
for _, pl in pairs( player.GetAll() ) do 
if pl:Health() > 0 then pl:DrawModel()  end

end
cam.End3D()
end )
end )
concommand.Add( "fl_e", function()
function flash()
RunConsoleCommand( "+attack" )
end 
end )

 concommand.Add( "fl_d", function()
	RunConsoleCommand( "-attack" )
end)

concommand.Add( "aim_d", function()
	hook.Remove( "Think", "aimbot" )
end)
concommand.Add( "wh_d", function()
hook.Remove( "HUDPaint", "lah")
end)
concommand.Add( "hard_d", function()
	hook.Remove( "Think", "hard" )
end)