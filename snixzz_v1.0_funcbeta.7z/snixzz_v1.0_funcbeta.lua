/*
	
	snixzz 1.0
	
	A cheat made for griefing and hvh
	Author: Tyler
	
	If u have this, message me on how so I can steal private cheats
	i've tried extremely hard to keep this private, its a lua cheat but its still really fast
	if u have leaked this file without the modules ill trade the how to leak guide and the modules, ty
		
		
gmcl_frozen	
ZeroSpread	=	function: 0x2c62faa0
SetMuted	=	function: 0x462d7858
GetLPIndex	=	function: 0x42304780
SetCvarName	=	function: 0x2defb730
ClientCMD	=	function: 0x35ffc4e8
IsMuted	=	function: 0x462f74f0
NoDraw	=	function: 0x438ab828
RawGet	=	function: 0x43abb758
SetViewAngles	=	function: 0x2a443d50
AsusWalls	=	function: 0x2add58f8
GetCvar	=	function: 0x2a43f850
IsDormant	=	function: 0x46940d28
SetCvarFlags	=	function: 0x428aa000
RawSet	=	function: 0x29c44e88
GetServerIP	=	function: 0x2defb330
Changename	=	function: 0x46321cc0
IsVisible	=	function: 0x46805d70
SetCvarValue	=	function: 0x428909d0
	
*/

/*
	Anti-cheat detection, just informs you if an anti-cheat is present
	Must be loaded before module is loaded and the snixzz table is
	actually created
*/

if _G["_snixzz"] then
	_G["_snixzz"] = nil
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat\n" )
end
if _G["snixzz"] then
	_G["snixzz"] = nil 
	MsgC( Color( 255, 0, 0 ), "[snixzz] Detected an anti-cheat, or snixzz was reloaded\n" )
end

local snixzz = {}
local _R = debug["getregistry"]()
// Yes, I know it doesn't make much of a difference using copied functions, but I chose to do it anyways.
snixzz["Copy"] = {
	["MsgN"] = MsgN,
	["tostring"] = tostring,
	["table"] = table,
	["hook"] = hook,
	["math"] = math,
	["surface"] = surface,
	["draw"] = draw,
	["ScrW"] = ScrW,
	["ScrH"] = ScrH,
	["pairs"] = pairs,
	["util"] = util,
	["http"] = http,
	["player"] = player,
	["input"] = input,
	["timer"] = timer,
	["IsValid"] = IsValid,
	["LocalPlayer"] = LocalPlayer,
	["GetConVarNumber"] = GetConVarNumber,
	["SetMaterialOverride"] = SetMaterialOverride,
	["CreateMaterial"] = CreateMaterial,
	["Vector"] = Vector,
	["render"] = render,
	["Material"] = Material,
	["EyePos"] = EyePos,
	["EyeAngles"] = EyeAngles,
	["cam"] = cam,
	["team"] = team,
	["ents"] = ents,
	["Color"] = Color,
	["concommand"] = concommand,
	["vgui"] = vgui,
	["string"] = string,
	["RealFrameTime"] = RealFrameTime,
	["RunConsoleCommand"] = RunConsoleCommand,
	["require"] = require,
}

snixzz["Hooks"] = {
}
snixzz["Detours"] = {
}
snixzz["Spoof"] = {
	["sv_allowcslua"] = snixzz["Copy"]["GetConVarNumber"]( "sv_allowcslua" ), // some anti-cheats man..
	["sv_cheats"] = 0,
	["host_timescale"] = 1,
}	

// features and vars
snixzz["Features"] = {
	["AntiAim"] = false,
	["Aimbot"] = KEY_F,
	["Speedhack"] = KEY_B,
	["ListToggle"] = KEY_T,
	["Changelog"] = KEY_C,
	["ESPDistance"] = 750, // distance in which the ESP will draw (in units)
}

// Aimbot vars nd shit
snixzz["Target"] = nil
snixzz["Distance"] = 9999999999999 // max aimbot distance
snixzz["Shooting"] = false
snixzz["Typing"] = false
snixzz["Locked"] = false
snixzz["Whitelist"] = {
}
snixzz["Attachments"] = {
	"eyes",
	"forward",
	"head",
}

// nospread shit
snixzz["Cones"] = {
	["HL2"] = {	
		["weapon_pistol"] = snixzz["Copy"]["Vector"]( 0.0100, 0.0100, 0.0100 ),
		["weapon_smg1"] = snixzz["Copy"]["Vector"]( 0.04362, 0.04362, 0.04362 ),
		["weapon_ar2"] = snixzz["Copy"]["Vector"]( 0.02618, 0.02618, 0.02618 ),
		["weapon_shotgun"] = snixzz["Copy"]["Vector"]( 0.08716, 0.08716, 0.08716 ),
	},
}
snixzz["ConeBase"] = {
	["weapon_cs_base"] = true,
	["weapon_zs_base"] = true,
}

snixzz["Colors"] = {
	["Red"] = Color( 255, 0, 0, 255 ),
	["DarkRed"] = Color( 200, 50, 50, 255 ),
}

snixzz["Files"] = {}

snixzz["Copy"]["surface"]["CreateFont"]( "snixzz", { font = "Trebuchet18", size = 12, antialias = false } )

/* General notification/display functions */
function snixzz.Message( col, txt )
	MsgC( snixzz["Colors"]["DarkRed"], "[hack]: " )
	MsgC( col, txt .. "\n" )
end

/* Detour function */
function snixzz.Detour( Old, New )
	snixzz["Detours"][New] = Old
	//snixzz["Message"]( Color( 80, 150, 255 ), "Detouring function " .. snixzz["Copy"]["tostring"]( Old ) .. "." )
	return New
end

local _snixzz = _G["NHTable"]
_G["NHTable"] = nil // hacker.


/* Anti-Cheat bypass functions */
function snixzz.AntiCheats()
	
	if _G["CheckVars"] then
		snixzz["Message"]( Color( 50, 255, 50 ), "function CheckVars exists, detouring the scan." )
		_G["CheckVars"] = snixzz["Detour"]( _G["CheckVars"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "HERP-AC attempted to scan cvars, stopping that..." )
		end )
	end
	
	if _G["RunCheck"] then
		snixzz["Message"]( Color( 0, 255, 50 ), "function RunCheck exists, detouring." )
		_G["RunCheck"] = snixzz["Detour"]( _G["RunCheck"], function()
			snixzz["Message"]( Color( 50, 255, 50 ), "TAC attempted to run a check, returning no information." )
		end )
 	end
	
	if _G["CAC"] then
		snixzz["Message"]( Color( 0, 255, 50 ), "table CAC exists, bypassing anti-cheat." )
		snixzz["Copy"]["timer"]["Destroy"]( "CAC" )
	end
		
	
	snixzz["Copy"]["concommand"]["Remove"]( "0_u_found" )
	snixzz["Copy"]["concommand"]["Add"]( "0_u_found", function()
		snixzz["Message"]( Color( 50, 255, 50 ), "anti-cheat concommand 0_u_found blocked" )
	end )
	snixzz["Copy"]["hook"]["Remove"]( "InitPostEntity", "detrp" )
	
end
snixzz["AntiCheats"]()

/* Hooking functions */

function snixzz.RegisterHook( Type, Function )
	snixzz["Message"]( Color( 255, 255, 255 ), "Hooking function " .. Type .." into " .. snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	snixzz["Copy"]["table"]["insert"]( snixzz["Hooks"], snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ) )
	return snixzz["Copy"]["hook"]["Add"]( Type, snixzz["Copy"]["string"]["Replace"]( snixzz["Copy"]["tostring"]( Function ), "function: ", "" ), Function )
end

/* Aimbot functions */

function snixzz.GetCone( wep )

	if !snixzz["Copy"]["IsValid"]( wep ) then
		return 0 
	end	
	
	if snixzz["Cones"][ wep:GetClass() ] then
		return snixzz["Cones"][ wep:GetClass() ] 
	elseif snixzz["ConeBase"][ wep["Base"] ] then 
		return wep["Cone"] or wep["Primary"]["Cone"] or 0
	elseif snixzz["Cones"]["HL2"][ wep:GetClass() ] then
		return snixzz["Cones"]["HL2"][ wep:GetClass() ]
	else
		local Cone = wep["Cone"]	
		if !Cone then
			Cone = wep["Primary"] && wep["Primary"]["Cone"] or 0
		end	
	end
	return Cone || 0
end

function snixzz.PredictSpread( cmd, ang )
local w = snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()
local vecCone, valCone = snixzz["Copy"]["Vector"]( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w["Initialize"] ) == "function" ) ) then
		valCone = snixzz["GetCone"]( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = snixzz["Copy"]["Vector"]( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1
		end
	else
		if ( w:IsValid() && snixzz["Cones"]["HL2"][ w:GetClass() ] ) then
			vecCone = snixzz["Cones"]["HL2"][ w:GetClass() ]
		end
	end
	return _snixzz["ZeroSpread"]( cmd, ang, vecCone )
end

function snixzz.Aimspot( e )

	for k, v in snixzz["Copy"]["pairs"]( snixzz["Attachments"] ) do
		if e:LookupAttachment( v ) then
			local att = e:GetAttachment( e:LookupAttachment( v ) )
			if( att ) then
				return att["Pos"]
			end
		end
	end
	
	return ( e:LocalToWorld( e:OBBCenter() ) )
end

function snixzz.IsVisible( v )
--	return _snixzz["IsVisible"]( snixzz["Copy"]["LocalPlayer"]():GetShootPos(), snixzz["Aimspot"]( v ), v:EntIndex() )
end

function snixzz.OnScreen( e )
	local a, f = _R["Player"]["GetAimVector"]( snixzz["Copy"]["LocalPlayer"]() ):Angle() - ( e:GetPos() - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):Angle(), _R["Player"]["GetFOV"]( snixzz["Copy"]["LocalPlayer"]() )     
	return ( snixzz["Copy"]["math"]["NormalizeAngle"]( a["y"] ) < f + 2 && snixzz["Copy"]["math"]["NormalizeAngle"]( a["p"] ) < f + 2 )
end

function snixzz.IsValid( e )

	if ( !snixzz["Copy"]["IsValid"]( e ) || e == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end

	
	if snixzz["Copy"]["table"]["HasValue"]( snixzz["Whitelist"], e:SteamID() ) then 
		return false	
	end
	
	if ( !e:Alive() || !e:IsPlayer() || e:InVehicle() ) then 
		return false 
	end
	
	if ( snixzz["Copy"]["GetConVarNumber"]( "sbox_noclip" ) == 0 && e:GetMoveType() == MOVETYPE_NOCLIP ) then 
		return false 
	end

	if e:GetFriendStatus() == "friend" then 
		//return false 
	end
	
	if ( e:Team() == snixzz["Copy"]["LocalPlayer"]():Team() ) then
		//return false
	end
			
	if ( e:GetMoveType() == MOVETYPE_OBSERVER || e:Team() == TEAM_SPECTATOR ) then 
		return false 
	end
	
	// ignore T buddies
	if snixzz["Copy"]["string"]["find"]( GAMEMODE["Name"] , "Trouble in Terror" ) then
		if ( snixzz["Copy"]["LocalPlayer"]():IsTraitor() && e:IsTraitor() ) then
			return false
		end
	end
	
	// spawn protection (multiple server detection methods)
	local col = e:GetColor()
	if col["a"] < 255 then
		return false
	end
	if snixzz["Copy"]["LocalPlayer"]():GetColor()["a"] < 255 then
		return false
	end
	// gun game server
	if e:GetMaterial() == "models/props_combine/stasisshield_sheet" then
		return false
	end

	// visible check
	if !snixzz["IsVisible"]( e ) then
		return false
	end

	return true
end

function snixzz.GetTarget()
	local distance = snixzz["Copy"]["math"]["huge"]
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["player"]["GetAll"]() ) do
		if snixzz["IsValid"]( v ) then
			local distance2 = v:GetPos():DistToSqr( snixzz["Copy"]["LocalPlayer"]():GetPos() )
			if distance2 < distance then
				distance = distance2
				snixzz["Target"] = v
			end
		end
	end
	return snixzz["Target"]
end

function snixzz.NormalizeAngles( Angl )
	Angl["p"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["p"] )
	Angl["y"] = snixzz["Copy"]["math"]["NormalizeAngle"]( Angl["y"] )
	Angl["r"] = 0
end

function snixzz.Prediction( Pos, e )
	if ( snixzz["Copy"]["IsValid"]( e ) && type( e:GetVelocity() ) == "Vector" && e["GetPos"] && type( e:GetPos() ) == "Vector" ) then
		local eSpeed = snixzz["Target"]():GetVelocity() * 0.013
        local plySpeed = snixzz["Copy"]["LocalPlayer"]():GetVelocity() * 0.013	
		return ( Pos - plySpeed + eSpeed )
	end
	return Pos
end


/*
	ESP functions
*/

function snixzz.IsAdmin( v )

	if v:IsAdmin() then
		return true
	end
	
	if v:IsSuperAdmin() then
		return true
	end
	
	if v:IsUserGroup( "admin" ) then
		return true
	end
	
	if v:IsUserGroup( "superadmin" ) then
		return true
	end
		
	if v:IsUserGroup( "moderator" ) or v:IsUserGroup( "mod" ) or v:IsUserGroup( "trialmod" ) then
		return true
	end
	
	if v:IsUserGroup( "owner" ) then
		return true
	end
	
end

function snixzz.ShouldDraw( v )

	// better fps
	local distance = v:GetPos():Distance( snixzz["Copy"]["LocalPlayer"]():GetPos() )
	if distance >= snixzz["Features"]["ESPDistance"] then
		return false
	end
	
	if ( !v:IsPlayer() or !v:Alive() or v == snixzz["Copy"]["LocalPlayer"]() ) then
		return false
	end
	
	if ( v:Team() == TEAM_SPECTATOR or snixzz["Copy"]["string"]["find"]( snixzz["Copy"]["team"]["GetName"]( v:Team() ), "spectator" ) ) then
		return false
	end
	
	if _snixzz["IsDormant"]( v:EntIndex() ) then
		return false
	end
	
	if !snixzz["OnScreen"]( v ) then
		return false
	end
	
	return true	
end

/*=======================


Hooked functions below


=========================*/

function snixzz.CreateMove( ucmd )
	
	// Aimbot vars
	snixzz["Angles"] = ucmd:GetViewAngles()
	snixzz["Target"] = snixzz["GetTarget"]()
	
	// Aimbot core
	if ( snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["Aimbot"] ) && !snixzz["Typing"] ) then
		if( !snixzz["Target"] ) then return end

		if snixzz["IsValid"]( snixzz["Target"] ) then
			
			snixzz["Locked"] = true // hey you have a target!
		
			snixzz["Angles"] = ( snixzz["Prediction"]( snixzz["Aimspot"]( snixzz["Target"] ) ) - snixzz["Copy"]["Vector"]( 0, 0, 0 ) ) // 0 offset
			
			snixzz["Angles"] = ( snixzz["Angles"] - snixzz["Copy"]["LocalPlayer"]():GetShootPos() ):GetNormal():Angle()
			snixzz["SetAngle"] = snixzz["PredictSpread"]( ucmd, Angle( snixzz["Angles"]["p"], snixzz["Angles"]["y"], 0 ) )
			snixzz["ViewAngles"] = ucmd:GetViewAngles()
			
			snixzz["NormalizeAngles"]( snixzz["Angles"] )

			_snixzz["SetViewAngles"]( ucmd, snixzz["SetAngle"] )
			
			ucmd:SetButtons( bit["bor"]( ucmd:GetButtons(), IN_ATTACK ) )		
		end
	end
	
	// Bunnyhop
	if !snixzz["Copy"]["LocalPlayer"]():IsOnGround() then
		ucmd:SetButtons( bit["band"]( ucmd:GetButtons(), bit["bnot"]( IN_JUMP ) ) )
	end

	if snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"] then
		snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon()["Primary"]["Recoil"] = 0
	end
	
	// spoofed cvar speedhack
	if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["Speedhack"] ) then
		//_snixzz["SetCvarValue"]( "snx_sv_cheats", 1 )
		//_snixzz["SetCvarValue"]( "snx_host_timescale", 3.5 )
		snixzz["Copy"]["RunConsoleCommand"]( "sp00f_bs_sv_cheats", 1 )
		snixzz["Copy"]["RunConsoleCommand"]( "sp00f_bs_host_timescale", 3.5 )
	else
		//_snixzz["SetCvarValue"]( "snx_sv_cheats", 0 )
		//_snixzz["SetCvarValue"]( "snx_host_timescale", 1 )
		snixzz["Copy"]["RunConsoleCommand"]( "sp00f_bs_host_timescale", 1 )
		snixzz["Copy"]["RunConsoleCommand"]( "sp00f_bs_sv_cheats", 0 )
	end
	
	// No hands
	// _snixzz["NoDraw"]( Material( "models/weapons/v_models/hands/v_hands" ), true )
	
	/*snixzz["GMTColors"] = {
		"999 0 0", -- RED
		"0 0 999", -- BLUE
		"0 999 0", -- GREEN
		"0 999 999", -- CYAN
		"999 999 0", -- YELLOW
		"999 0 999", -- PURPLE
	}
	if snixzz["Copy"]["string"]["find"]( GetHostName(), "[GMT]" ) then 
		snixzz["Copy"]["RunConsoleCommand"]( "cl_playercolor", snixzz["Copy"]["table"]["Random"]( snixzz["GMTColors"] ) )
		snixzz["Copy"]["RunConsoleCommand"]( "gmt_updateplayercolor" )
	end*/
end

function snixzz.HUDPaint()

	local font = "snixzz"
	local listpos = snixzz["Copy"]["ScrH"]() / 3.5

	for k, v in snixzz["Copy"]["pairs"]( snixzz["Copy"]["ents"]["GetAll"]() ) do		
		
		// Player esp	
		if snixzz["ShouldDraw"]( v ) then
			
			// ESP Positions
			local bottom = ( v:GetPos() - snixzz["Copy"]["Vector"]( 0, 0, 10 ) ):ToScreen()
			local top = ( v:GetPos() + snixzz["Copy"]["Vector"]( 0, 0, 70 ) ):ToScreen()
			local height = ( bottom["y"] - top["y"] )
			local width = ( height / 4 )
			
			local wep
			if snixzz["Copy"]["IsValid"]( v:GetActiveWeapon() ) then
				wep = v:GetActiveWeapon():GetPrintName()
			else
				wep = "Unknown"
			end
			
			// player text color
			local color = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			
			// player box color
			local boxcolor = snixzz["Copy"]["team"]["GetColor"]( v:Team() )
			if v == snixzz["Target"] then
				boxcolor = Color( 200, 100, 255, 255 )
			else
				boxcolor = Color( 0, 255, 0, 255 )
			end
			
			// ESP text
			draw["DrawText"]( v:Nick() .. " [" .. v:Health() .. "]", font, top["x"], top["y"] - 14, color, 1 )
			//draw["DrawText"]( wep, font, bottom["x"], bottom["y"] - 3, color, 1 )
			
			// Box ESP
			surface["SetDrawColor"]( boxcolor )
			surface["DrawOutlinedRect"]( top["x"] - width, top["y"], width * 2, height )
		end	
		
		// spectator/admin list
		if snixzz["Copy"]["input"]["IsKeyDown"]( snixzz["Features"]["ListToggle"] ) then
			if v:IsPlayer() then
				if v:GetObserverTarget() == snixzz["Copy"]["LocalPlayer"]() then
					snixzz["Copy"]["draw"]["SimpleTextOutlined"]( v:Nick(), font, 2, listpos, Color( 255, 0, 0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) )
					listpos = listpos + 12
				end
			end
		else	
			if v:IsPlayer() then
				if snixzz["IsAdmin"]( v ) then
					snixzz["Copy"]["draw"]["SimpleTextOutlined"]( v:Nick(), font, 2, listpos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) )
					listpos = listpos + 12
				end
			end
		end
			
		// crosshair color
		/*local color2 = Color( 255, 0, 0, 255 )
		if snixzz["Copy"]["LocalPlayer"]():GetEyeTrace()["Entity"]:IsPlayer() then
			color2 = Color( 0, 255, 0, 255 )
		else
			color2 = Color( 255, 0, 0, 255 )
		end*/
		
		// crosshair core
		surface["SetDrawColor"]( Color( 255, 0, 255 ) )
		local size = 6 // Swastika size
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 + size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 - size, snixzz["Copy"]["ScrW"]() / 2 + size, snixzz["Copy"]["ScrH"]() / 2 - size )
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2, snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size )		
		surface["DrawLine"]( snixzz["Copy"]["ScrW"]() / 2, snixzz["Copy"]["ScrH"]() / 2 + size, snixzz["Copy"]["ScrW"]() / 2 - size, snixzz["Copy"]["ScrH"]() / 2 + size )

	end
end

function snixzz.CalcView( ply, origin, angles, FOV )
	local ply = snixzz["Copy"]["LocalPlayer"]()
	local wep = ply:GetActiveWeapon()

	// visual no recoil
	if wep["Primary"] then wep["Primary"]["Recoil"] = 0 end
	if wep["Secondary"] then wep["Secondary"]["Recoil"]	= 0 end

	// other view shit, such as nospread view correction
	local view = GAMEMODE:CalcView( ply, origin, angles, FOV ) || {}
	view["angles"] = snixzz["Angles"]
	view["angles"]["r"] = 0
	return view
	
end

/*
	DETOURS
	Adding them as I go, don't bitch that I haven't detoured every function 
*/
_R["Entity"]["FireBullets"] = snixzz["Detour"]( _R["Entity"]["FireBullets"], function( e, bullet )
	//snixzz["Message"]( Color( 0, 255, 150 ), "Found cone " .. snixzz["Copy"]["tostring"]( bullet["Spread"] ) .. " for weapon " .. snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetPrintName() )
	snixzz["Cones"][ snixzz["Copy"]["LocalPlayer"]():GetActiveWeapon():GetClass() ] = bullet["Spread"]
	return snixzz["Detours"][ _R["Entity"]["FireBullets"] ]( e, bullet )
end )

file["Exists"] = snixzz["Detour"]( file["Exists"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then // stay out
		snixzz["Message"]( Color( 255, 0, 0 ), "An anti-cheat attempted to search for snixzz" )
		return false
	else
		return snixzz["Detours"][ file["Exists"] ]( filename, dir )
	end
end )

file["Read"] = snixzz["Detour"]( file["Read"], function( filename, dir )
	if string["find"]( filename, "snixzz" ) then 
		return "No, you can not have my source code."
	else
		return snixzz["Detours"][ file["Read"] ]( filename, dir )
	end
end )

net["Start"] = snixzz["Detour"]( net["Start"], function( name )
	if ( name == "checksaum" || name == "send" || name == "leyac_cmd" ) then
		snixzz["Message"]( Color( 255, 0, 0 ), "Blocked net.Send " .. name )
		return
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.Send( '" .. name .. "' )" )
		return snixzz["Detours"][ net["Start"] ]( name )
	end
end )

net["WriteString"] = snixzz["Detour"]( net["WriteString"], function( str )
	if snixzz["Copy"]["string"]["find"]( str, "snixzz" ) then
		return "fuck that"
	else
		snixzz["Message"]( Color( 255, 255, 255 ), "*DEBUG* net.WriteString( " .. str .. " )" )
		return snixzz["Detours"][ net["WriteString"] ]( str )
	end
end )

GetConVarNumber = snixzz["Detour"]( GetConVarNumber, function( cvar )
	for k, v in snixzz["Copy"]["pairs"]( snixzz["Spoof"] ) do
		if cvar == v then
			snixzz["Message"]( Color( 255, 255, 255 ), "*ANTICHEAT ALERT* Server tried to check convar " .. v .. " returning default value " .. k )
			return k
		else
			return snixzz["Detours"][ GetConVarNumber ]( cvar )
		end
	end
end )

RunConsoleCommand = snixzz["Detour"]( RunConsoleCommand, function( cmd, ... )
	snixzz["Message"]( Color( 255, 255, 255 ), "RunConsoleCommand( '" .. cmd .. "' )" )
	return snixzz["Detours"][ RunConsoleCommand ]( cmd, ... )
end )

snixzz["StartChat"] = GAMEMODE["StartChat"] 
function GAMEMODE:StartChat() 
	snixzz["StartChat"]() 
	snixzz["Typing"] = true 
end 
snixzz["FinishChat"] = GAMEMODE["FinishChat"] 
function GAMEMODE:FinishChat() 
	snixzz["FinishChat"]() 
	snixzz["Typing"] = false 
end 

/*

	Hooks
	
*/

snixzz["Message"]( Color( 255, 180, 180, 255 ), "Loading hooks" )
snixzz["RegisterHook"]( "CreateMove", snixzz["CreateMove"] )
snixzz["RegisterHook"]( "HUDPaint", snixzz["HUDPaint"] )
if !snixzz["Copy"]["string"]["find"]( GetHostName(), "[GMT]" ) then
	snixzz["RegisterHook"]( "CalcView", snixzz["CalcView"] )
end

snixzz["Message"]( Color( 0, 255, 130 ), "snixzz initialized." )