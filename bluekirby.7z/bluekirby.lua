--[[
	menu_plugins/new  2.txt
	[6kx3] Blue Kirby | (STEAM_0:0:25093119)
	===DStream===
]]

--Variables
local realAngles = Angle( 0, 0, 0 )
local savedAngle = Angle( 0, 0, 0 )
local Cam3DAngles = Angle( 0, 0, 0 )
local lastAimAngle = Angle( 0, 0, 0 )
local lastAimPos = Vector( 0, 0, 0 )
local DistVec = 0
local fuck = 0
local EntityList = {}
AlreadyRanAttack = false
local RenderEntities = {}
local angleOffset = 0
local key_w = 0
local key_a = 0
local key_s = 0
local key_d = 0
local MOVE = { [0] = "+forward", [1] = "+moveleft", [2] = "+back", [3] = "+moveright" }
local STOPMOVE = { "-forward", "-moveleft", "-back", "-moveright" }
local _inAttack = false
local shake = {}
local ShouldSeeAngle = false;
shake.p = 0
shake.y = 0
--Convars
local bk_aimbot_autoshoot = CreateClientConVar( "bk_aimbot_autoshoot", 0, true, false )
local bk_aimbot_silent = CreateClientConVar( "bk_aimbot_silent", 0, true, false )
local bk_aimbot_silent_smooth = CreateClientConVar( "bk_aimbot_silent_smooth", 1, true, false )
local bk_crosshair_actual_aim = CreateClientConVar( "bk_crosshair_actual_aim", 1, true, false )
local bk_crosshair = CreateClientConVar( "bk_crosshair", 1, true, false )
local bk_esp = CreateClientConVar( "bk_esp", 0, true, false )
local bk_esp_info = CreateClientConVar( "bk_esp_info", 0, true, false )
local bk_norecoil = CreateClientConVar( "bk_norecoil", 1, true, false )
local bk_nospread = CreateClientConVar( "bk_nospread", 1, true, false )
local bk_smoothlook = CreateClientConVar( "bk_smoothlook", 0, true, false )
local bk_spinbot = CreateClientConVar( "bk_spinbot", 0, true, false )
local bk_spinbot_random = CreateClientConVar( "bk_spinbot_random", 0, true, false )
local bk_wallhack = CreateClientConVar( "bk_wallhack", 0, true, false )
local bk_wallhack_players = CreateClientConVar( "bk_wallhack_players", 0, true, false )
local bk_wallhack_entities = CreateClientConVar( "bk_wallhack_entities", 0, true, false )

local function BKUnload()
	
	hook.Remove( "CreateMove", "BK.hacks" )
	hook.Remove( "HUDPaint", "BK.ESP.Box" )
	hook.Remove( "Think", "BK.Aimbot.Silent" )
	hook.Remove( "Think", "BK.Aimbot" )
	hook.Remove( "HUDPaint", "Blue_Wall_.Hack" )
	hook.Remove( "CalcView", "SmoothLook" )
	
	
end
concommand.Add( "bk_unload", BKUnload )

hook.Add( "CreateMove", "BK.hacks", function() 
	
	local wep = LocalPlayer():GetActiveWeapon()
	
	if bk_nospread:GetBool() and LocalPlayer():Alive() and wep:IsValid() and wep.Primary then
	
		wep.Primary.Spread = 0
		wep.Primary.Cone = 0

	end
	
	if bk_norecoil:GetBool() and LocalPlayer():Alive() and wep:IsValid() and wep.Primary then
		
		wep.Primary.Recoil = 0
		
	end
	
end )

local function getAnglesDifference( angle1, angle2 )
	
	local pitch1 = angle1.p
	local yaw1 = angle1.y
	local roll1 = angle1.r
	local pitch2 = angle2.p
	local yaw2 = angle2.y
	local roll2 = angle2.r
	local TotalDistance = 0
	TotalDistance = math.abs(math.AngleDifference( pitch1, pitch2 ))
	TotalDistance = math.abs(math.AngleDifference( yaw1, yaw2 )) + TotalDistance
	TotalDistance = math.abs(math.AngleDifference( roll1, roll2 )) + TotalDistance
	
	return TotalDistance
	
end

local function GetBestTarget()
	
	local ply = LocalPlayer()
	
end

local function lerpA( angle1, angle2, ammount )
	
	ammount = ammount * 10
	
	angle1.p = math.ApproachAngle( angle1.p, angle2.p, 1 ) 
	angle1.y = math.ApproachAngle( angle1.y, angle2.y, 1 ) 
	angle1.r = 0
	
	return angle1
	
end

local function GetHead( ply )
	
	if !ply:IsPlayer() or !ply:IsValid() then return end
	
	local targethead = ply:LookupBone("ValveBiped.Bip01_Head1")
	local targetheadpos,targetheadang = ply:GetBonePosition(targethead)
	
	return targetheadpos
	
end

local function GetBestPlayer()
	
	if table.Count( player.GetAll() ) == 1 then return LocalPlayer() end
	
	local ply = LocalPlayer()
	local plys = {}
	
	for k, v in pairs( player.GetAll() ) do
		
		if v != ply and v:Alive() and v:Team() != TEAM_SPECTATOR then
			
			local pos = ply:GetShootPos()
			local ang = ply:GetAimVector()
			local tracedata = {}
			tracedata.start = pos
			tracedata.endpos = GetHead(v)
			tracedata.filter = ply
			local trace = util.TraceLine(tracedata)
			
			if trace.HitNonWorld then
			
				if trace.Entity == v then
					plys[table.Count(plys)] = v
				end
				
			end
			
		end
		
	end
	
	for k, v in pairs( plys ) do
		
		local lerpd = (GetHead(v) - ply:EyePos()):Angle()
		local dist = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
		lerpd = (GetHead(plys[0]) - ply:EyePos()):Angle()
		local dist2 = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
		if dist < dist2 then
			plys[0] = v
		end
		
	end
	
	if IsValid(plys[0]) then
		ply = plys[0]
	end
	
	return ply;
end

local function GetHand( ply )
	
	local pos = Vector( 0, 0, 0 )
	
	local targethead = ply:LookupBone("ValveBiped.Bip01_R_Hand")
	local pos,targetheadang = ply:GetBonePosition(targethead)
	
	return pos
	
end

local function GetBonePos( ply, bone )
	
	local pos = Vector( 0, 0, 0 )
	
	local bone = ply:LookupBone( bone )
	local pos, ang = ply:GetBonePosition( bone )
	
	return pos
	
end

local function GetLowestX( ply )
	
	local x = ScrW()
	
	local bones = { 
	"ValveBiped.Bip01_Head1", 
	"ValveBiped.Anim_Attachment_RH", 
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_Hand", 
	"ValveBiped.Bip01_R_Forearm", 
	"ValveBiped.Bip01_R_Foot", 
	"ValveBiped.Bip01_R_Thigh", 
	"ValveBiped.Bip01_R_Calf", 
	"ValveBiped.Bip01_R_Shoulder", 
	"ValveBiped.Bip01_R_Elbow",
	"ValveBiped.Bip01_L_Hand", 
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Foot", 
	"ValveBiped.Bip01_L_Thigh", 
	"ValveBiped.Bip01_L_Calf", 
	"ValveBiped.Bip01_L_Shoulder", 
	"ValveBiped.Bip01_L_Elbow"
	}
	
	for k, v in pairs( bones ) do
		
		local cleanupcode = GetBonePos( ply, v ):ToScreen().x
		
		if cleanupcode < x then
			
			x = cleanupcode
			
		end
		
	end
	
	return x
	
end

local function GetHighestX( ply )
	
	local x = 0
	
	local bones = { 
	"ValveBiped.Bip01_Head1", 
	"ValveBiped.Anim_Attachment_RH", 
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_Hand", 
	"ValveBiped.Bip01_R_Forearm", 
	"ValveBiped.Bip01_R_Foot", 
	"ValveBiped.Bip01_R_Thigh", 
	"ValveBiped.Bip01_R_Calf", 
	"ValveBiped.Bip01_R_Shoulder", 
	"ValveBiped.Bip01_R_Elbow",
	"ValveBiped.Bip01_L_Hand", 
	"ValveBiped.Bip01_L_Forearm", 
	"ValveBiped.Bip01_L_Foot", 
	"ValveBiped.Bip01_L_Thigh", 
	"ValveBiped.Bip01_L_Calf", 
	"ValveBiped.Bip01_L_Shoulder", 
	"ValveBiped.Bip01_L_Elbow"
	}
	
	for k, v in pairs( bones ) do
		
		local cleanupcode = GetBonePos( ply, v ):ToScreen().x
		
		if cleanupcode > x then
			
			x = cleanupcode
			
		end
		
	end
	
	return x
	
end

local function BKESPBox()
	
	local ply = LocalPlayer();
	
	if bk_esp:GetBool() == false then return end
	
	if bk_esp_info:GetBool() then
	for k, v in pairs( ents.GetAll() ) do
		
		if v:GetClass() == "prop_ragdoll" then
			
			local pos = v:GetPos():ToScreen()
			
			draw.SimpleText( "-Dead Body-", "HudHintSmallText", pos.x + 1, pos.y + 1, Color( 0, 0, 0, 255 ) )
			draw.SimpleText( "-Dead Body-", "HudHintSmallText", pos.x, pos.y, Color( 255, 255, 255, 255 ) )
			
		end
		
		local exploded = {}
		exploded = string.Explode("_", v:GetClass())
		
		if table.HasValue( exploded, "revolver" ) and table.HasValue( exploded, "weapon" ) then
			
			local pos = v:GetPos():ToScreen()
			
			draw.SimpleText( v:GetClass(), "HudHintSmallText", pos.x + 1, pos.y + 1, Color( 0, 0, 0, 255 ) )
			draw.SimpleText( v:GetClass(), "HudHintSmallText", pos.x, pos.y, Color( 255, 255, 255, 255 ) )
			
		end
		
	end
	end
	
	for k, v in pairs(player.GetAll()) do
		
		if v != ply and v:Alive() and v:Team() != TEAM_SPECTATOR then
			
			local pos = Vector( 0, 0 )
			
			pos = ( GetHead( v ) + Vector( 0, 0, 7) ):ToScreen()
			pos.x = GetLowestX( v )
			local pos_end = Vector( GetHighestX( v ), v:GetPos():ToScreen().y )
			
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawOutlinedRect( pos.x, pos.y, pos_end.x - pos.x, pos_end.y - pos.y )
			
			if bk_esp_info:GetBool() == true then
			
				local finalx = pos_end.x + 5
				
				pos = (v:GetPos() + Vector( 0, 0, 70) ):ToScreen()
				
				draw.RoundedBox( 2, finalx, pos.y, 33, 5, Color( 255, 255, 255, 150 ) )
				draw.RoundedBox( 2, finalx + 1, pos.y + 1, v:Health() / 3 - 2, 3, Color( 255, 0, 0, 150 ) )
				
				pos.y = pos.y + 7
				
				draw.SimpleText( v:Name(), "HudHintSmallText", finalx, pos.y + 1, Color( 0, 0, 0, 255 ) )
				draw.SimpleText( v:Name(), "HudHintSmallText", finalx + 1, pos.y, Color( 255, 255, 255, 255 ) )
				
				pos.y = pos.y + 12
				
				local weapon = v:GetActiveWeapon()
				
				if IsValid( weapon ) then
				
					draw.SimpleText( weapon:GetClass(), "HudHintSmallText", finalx, pos.y + 1, Color( 0, 0, 0, 255 ) )
					draw.SimpleText( weapon:GetClass(), "HudHintSmallText", finalx + 1, pos.y, Color( 255, 255, 255, 255 ) )
				
				end
			
			end
			
		end
		
	end
	
end
 
hook.Add("HUDPaint", "BK.ESP.Box", BKESPBox)

local function BKAimbotSilent()
	
	if !_inAttack and bk_aimbot_autoshoot:GetBool() == false then return end
	
	local ply = LocalPlayer();
	
	local aiment = ply:GetEyeTrace().Entity
	
	local target = GetBestPlayer();
	
	if /*aiment == target or*/ !target:Alive() or target == ply then if !AlreadyRanAttack then RunConsoleCommand( "-attack" ) AlreadyRanAttack = true end ShouldSeeAngle = false return end
	
	local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
	local targetheadpos,targetheadang = target:GetBonePosition(targethead)
	
	local hitpos = LocalPlayer():GetEyeTrace().HitPos
	
	local lerpd = (targetheadpos - LocalPlayer():EyePos()):Angle()
	
	if bk_aimbot_silent_smooth:GetInt() > 0 then
		lerpd = lerpA( ply:EyeAngles(), (targetheadpos - LocalPlayer():EyePos()):Angle(), bk_aimbot_silent_smooth:GetInt() )
	end
	
	ShouldSeeAngle = lerpd;
	
	DistVec = math.abs(math.AngleDifference( ply:EyeAngles().p, lerpd.p )) * 180 + math.abs(math.AngleDifference( ply:EyeAngles().y, lerpd.y )) * 180
	
	ply:SetEyeAngles( lerpd )
	RunConsoleCommand( "+attack" )
	AlreadyRanAttack = false
	
end
hook.Add( "Think", "BK.Aimbot.Silent", BKAimbotSilent )

local function BKAimbot()

end
hook.Add( "Think", "BK.Aimbot", BKAimbot )

local function MoveCorrectly()
	
	local adjfuck = fuck
	
	for k, v in pairs( STOPMOVE ) do
		
		RunConsoleCommand( v )
		
	end
	
	if key_w then
		
		RunConsoleCommand( MOVE[adjfuck] )
		
	end
	
	adjfuck = adjfuck + 1
	
	if adjfuck == 4 then adjfuck = 1 end
	
	if key_a then
		
		RunConsoleCommand( MOVE[adjfuck] )
		
	end
	
	adjfuck = adjfuck + 1
	
	if adjfuck == 4 then adjfuck = 1 end
	
	if key_s then
		
		RunConsoleCommand( MOVE[adjfuck] )
		
	end
	
	adjfuck = adjfuck + 1
	
	if adjfuck == 4 then adjfuck = 1 end
	
	if key_d then
		
		RunConsoleCommand( MOVE[adjfuck] )
		
	end
	
end

local function BKSpinbot()
	
	if _inAttack or !bk_spinbot:GetBool() then return 0 end
	
	local randint = 90
	
	fuck = fuck + 1
	
	if fuck == 4 then fuck = 0 end
	
	LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( 0, randint, 0 ) )
	
	MoveCorrectly()
	
	return randint * fuck
	
	
end


concommand.Add( "+bk_forward", function() 
	
	key_w = 1
		
end)

concommand.Add( "+bk_back", function() 
		
	key_s = 1
		
end)

concommand.Add( "+bk_left", function() 
	
	key_a = 1
	
end)

concommand.Add( "+bk_right", function() 

	key_d = 1
	
end)

concommand.Add( "-bk_forward", function() 
	
	key_w = 0
	
end)

concommand.Add( "-bk_back", function() 
	
	key_s = 0
	
end)

concommand.Add( "-bk_left", function() 

	key_a = 0

end)
	
concommand.Add( "-bk_right", function() 
	
	key_d = 0
	
end)
	
concommand.Add( "+bk_attack", function() 


	LastAimAngle = LocalPlayer():EyeAngles()
	LastAimPos = LocalPlayer():GetEyeTrace().HitPos
	_inAttack = true
	BKAimbotSilent()
	RunConsoleCommand( "+attack" )
	timer.Simple( 0.01, function() LocalPlayer():SetEyeAngles( LastAimAngle ) end )
	
end)
	
concommand.Add( "-bk_attack", function() 
		
	_inAttack = false
	plyRealAngle = LocalPlayer():EyeAngles().y
	ShouldSeeAngle = false;
	
	RunConsoleCommand( "-attack" )
		
end)

local function SmoothLook(ply, pos, angles, fov)
	
	local view = {}
	
	Cam3DAngles = angles
	
	if bk_norecoil:GetBool() and !bk_smoothlook:GetBool() then
		
		view.origin = pos
		view.angles = LocalPlayer():EyeAngles()
		
		if ShouldSeeAngle != false then
			view.angles = ShouldSeeAngle;
		end
		
		view.fov = fov
		view.znear = 0.1
		Cam3DAngles = view.angles
		
		view.angles.y = view.angles.y - BKSpinbot()
		
		return view
		
	end
	
	//bindshit( false )
	
	if !bk_smoothlook:GetBool() then return end
	
	view.origin = LocalPlayer():EyePos()
	view.angles = LocalPlayer():EyeAngles()
	view.fov = fov
	view.znear = 0.1
	
	if getAnglesDifference( view.angles, realAngles ) > 5 then
		realAngles = LerpAngle( 0.9, view.angles, realAngles )
	end
	view.angles = realAngles
	
	view = GAMEMODE:CalcView(ply, view.origin, view.angles, view.fov, view.znear)
	local poop = ( LocalPlayer():GetEyeTrace().HitPos - view.origin ):Angle()
	view.vm_origin = nil
	savedAngle = LerpAngle( RealFrameTime() / 0.07, savedAngle, poop )
	view.vm_angles = savedAngle //( LocalPlayer():GetEyeTrace().HitPos - view.origin ):Angle()
	
	Cam3DAngles = view.angles
	return view
	
end
hook.Add( "CalcView", "SmoothLook", SmoothLook )

hook.Add( "HUDPaint", "Blue_Wall_.Hack", function()
	
	if bk_wallhack:GetBool() and bk_wallhack_players:GetBool() then
		
		local Pos = LocalPlayer():EyePos()
		local Ang = angles
		
		cam.Start3D( Pos, Cam3DAngles )
		
		for k, v in pairs ( player.GetAll() ) do
			
			if v:Health() > 0 and v != LocalPlayer() and v:Team() != TEAM_SPECTATOR then
				
				render.SuppressEngineLighting( true )
				render.SetColorModulation( 0, 1, 0 )
				render.SetBlend( 1 )
				v:SetMaterial( "models/debug/debugwhite" )
				render.SetColorModulation( 0, 1, 0 )
				v:DrawModel()
					
				if v:GetActiveWeapon():IsValid() then
					v:GetActiveWeapon():DrawModel()
				end
				
				render.SuppressEngineLighting( false )
				
			end
			
		end
		
		cam.End3D()
	
	else
		
		for k, v in pairs ( player.GetAll() ) do
		
			v:SetMaterial( "" )
	
		end
		
	end
	
	if !bk_crosshair:GetBool() then return end
	
	local pos = LocalPlayer():GetEyeTrace().HitPos:ToScreen()
	pos.x = pos.x - 1
	
	if !bk_crosshair_actual_aim:GetBool() then pos = Vector( ScrW() / 2 - 1, ScrH() / 2 ) end
	
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawLine( pos.x + 1, pos.y - 4, pos.x + 1, pos.y + 4 )
	surface.DrawLine( pos.x, pos.y - 4, pos.x, pos.y + 4 )
	surface.DrawLine( pos.x - 1, pos.y - 4, pos.x - 1, pos.y + 4 )
	
	surface.DrawLine( pos.x - 4, pos.y + 1, pos.x + 4, pos.y + 1 )
	surface.DrawLine( pos.x - 4, pos.y, pos.x + 4, pos.y )
	surface.DrawLine( pos.x - 4, pos.y - 1, pos.x + 4, pos.y - 1 )
	
	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawLine( pos.x, pos.y - 3, pos.x, pos.y + 3 )
	surface.DrawLine( pos.x - 3, pos.y, pos.x + 3, pos.y )
	
	draw.SimpleText( tostring(DistVec) )
	
end )