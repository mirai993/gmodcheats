--[[
	MOD/lua_old/shinycow/rp_police.lua [#5013 (#5173), 180139563]
	Shinycow | STEAM_0:0:29257121 <76.100.140.68:27006> | [11.01.14 10:12:46PM]
	===BadFile===
]]

	----------------- update 12/20/13
	----------------------- made it harder to detect this script. Replaced the hook.Add's with something else that is exactly the same.

if gmod.GetGamemode().Name:lower() != "darkrp" then print("not darkrp. stopping script.") return end

surface.CreateFont("ScoreboardText", 
{
	size = 20,
	weight = 100,
	antialias = true,
	shadow = true,
	font = "coolvetica"
})

local PoliceNear = {}
local PoliceBatons = {}

local Paint_Near = {}

--[[concommand.Add("rasda", function()
	PrintTable(PoliceNear)
end)]]

timer.Create("sc_updaterpradius", 1.4, 0, function()
	for i=1,#player.GetAll() do
		local v = player.GetAll()[ i ]
		
		if v == LocalPlayer() then continue end
		
		local dir = ( LocalPlayer():GetPos() - v:GetPos() ):GetNormal(); -- replace with eyepos if you want
					-- 0.8
		local canSee = dir:Dot( v:GetForward() ) < 0.75; -- -1 is directly opposite, 1 is self:GetForward(), 0 is orthogonal
		
		---if canSee and (self:GetPos():Distance( self.Chasing:GetPos()) < 1500) then
		--if canSee and ( ((v:GetPos() - LocalPlayer():GetPos()):LengthSqr()) - ((v:GetPos() - LocalPlayer():GetPos()):LengthSqr() / 1.0018) < 1500 ) then
		if canSee then
				
			local tracedata = {}
			tracedata.start = LocalPlayer():GetShootPos()
			tracedata.endpos = v:GetShootPos()
			local trace = util.TraceLine( tracedata )

			if not trace.HitWorld then
		
				local dist = ((v:GetPos() - LocalPlayer():GetPos()):LengthSqr()) - ((v:GetPos() - LocalPlayer():GetPos()):LengthSqr() / 1.0018)
				if dist < 750 then
					--[[if v:IsCP() then
						--LocalPlayer():ChatPrint(v:Nick() .. " is near you.")
						if not table.HasValue(PoliceNear, v) then
							PoliceNear[ #PoliceNear + 1 ] = v
						end
					else]]
						for a,b in next, v:GetWeapons() do
							--print("\n"..v:Nick(), b)
							--print(b:GetClass())
							--if string.find(string.lower(tostring(b)), "arrest") and not string.find(string.lower(tostring(b)), "unarrest") then
							if string.lower(b:GetClass()) == "arrest_stick" then
								--LocalPlayer():ChatPrint(v:Nick() .. " is near u")
								if not table.HasValue(PoliceNear, v) then
									PoliceNear[ #PoliceNear + 1 ] = v
								end
							end
						end
					--end
				end
			
			else
			
					-- We can no longer see the cop.
				if PoliceNear[ k ] then
					if table.HasValue(PoliceNear, v) then
						PoliceNear[ k ] = nil
					end
				end
				
			end
			
		end
	end
end)

timer.Create("sc_removepolice", 2, 0, function()	
	for k,v in next, PoliceNear do
		--print("ohai thar", v:GetPos():Distance( LocalPlayer():GetPos() ))
		if IsValid(v) then
			if v:GetPos():Distance( LocalPlayer():GetPos() ) > 650 then
				PoliceNear[ k ] = nil
			end
		else
			PoliceNear[ k ] = nil
		end
	end
end)

--hook.Add("Think", "sc_updatebatons", function()
hook.Hooks["Think"] = hook.Hooks["Think"] or {}
hook.Hooks["Think"][ "sc_updatebatons" ] = function()
	if table.Count(PoliceNear) == 0 then return end
	
	for k,v in next, PoliceNear do
		
		if not IsValid(v) then continue end
		
		if v:Alive() and IsValid(v:GetActiveWeapon()) then
			--print(v:GetActiveWeapon():GetClass())
			if string.find(string.lower(v:GetActiveWeapon():GetClass()), "arrest") and not string.find(string.lower(v:GetActiveWeapon():GetClass()), "unarrest") then
				if not table.HasValue(PoliceBatons, v) then
					PoliceBatons[ #PoliceBatons + 1 ] = v
				end
			else
				if table.HasValue(PoliceBatons, v) then
					LocalPlayer():ChatPrint("DEBUG: Cop doesnt have arrest baton out anymore!")
					for a,b in next, PoliceBatons do			
						if v == b then
							PoliceBatons[ a ] = nil
						end
					end
				end
			end
		end
		
	end
end

--hook.Add("HUDPaint", "sc_updatecops", function()
hook.Hooks["HUDPaint"] = hook.Hooks["HUDPaint"] or {}
hook.Hooks["HUDPaint"][ "sc_updatecops" ] = function()
	if table.Count(PoliceNear) == 0 then return end

	for i=1,#PoliceNear do
		local v = PoliceNear[ i ]
		
		if not IsValid(v) then continue end
		if not v:Alive() then continue end
		
		if not Paint_Near[ v ] then
			Paint_Near[ v ] = (ScrW() * 0.5) - (520 - ( (i - (i/2)) * 305 ))
		end
		
		draw.RoundedBox(1, (ScrW() * 0.5) - (520 - ( (i - (i/2)) * 305 )), (ScrH() * 0.5) - ( 70 - (ScrH() * 0.5) ), 150, 35, Color(0, 0, 0, 125))
		draw.SimpleText("CP: " .. v:Nick(), "ScoreboardText", (ScrW() * 0.5) - (520 - ( (i - (i/2)) * 305)), (ScrH() * 0.5) - ( 60 - (ScrH() * 0.5) ), Color(255, 255, 255, 255), 0, 0)
	end
	
	if table.Count(PoliceBatons) > 0 then
		for i=1,#PoliceBatons do
			local v = PoliceBatons[ i ]
			
			if not IsValid(v) then continue end
			if not v:Alive() then continue end
			if not table.HasValue(PoliceNear, v) then
				--LocalPlayer():ChatPrint("He's not cop anymore!")
				for a,b in pairs(PoliceNear) do
					if v == b then PoliceNear[ a ] = nil break end
				end
				PoliceBatons[ i ] = nil
			else
				draw.SimpleText("ARREST BATON!", "ScoreboardText", Paint_Near[ v ] + 5, (ScrH() * 0.5) - ( 38 - (ScrH() * 0.5) ), Color( 255, 0, 0, 255 ), 0, 0)
			end
		end
	end
end