surface.CreateFont("chmsfnt", {
    font = "Arial",
    extended = true,
    size = 20
})

surface.CreateFont("nicknm11", {
    font = "Roboto",
    extended = true,
    size = 20,
    outline = true
})

surface.CreateFont("nicknm12", {font = "Roboto", size = 17, weight = 400, antialias = true})
surface.CreateFont("nicknm13", {font = "Roboto", size = 20, weight = 400, antialias = true})

local backgroundcarpet = "https://cs9.pikabu.ru/post_img/2016/12/11/5/1481436164140328311.jpg"

http.Fetch( backgroundcarpet ,function(draw) 
    file.Write("carpet.jpg",draw) 
end)



local chams_mat = Material("")

local hitsounds = "physics/cardboard/cardboard_box_impact_bullet4.wav"
local hitsoundwh = 1
local hitmarker = 0

local gmppslls = 0
local menuons = true

local ike = "n"
local sd = "ri" 
local gg = "do" 
local q2ssQUICK = "an"
local sisiliski = "ow"
local dog = "_ "
local ed = "ed"


local colorframeon = 0
local settingsframeon = 0

local chamson = 0
local namesson = 0
local hitsoundon = 0
local handchamson = false



local chamses = 0
local faded_black = Color(0, 0, 0, 240) 
local chamspanel = vgui.Create("DFrame", carpetyo)
chamspanel:SetSize(500, 300)
chamspanel:Center()
chamspanel:SetTitle("dorian_ owned")
chamspanel:MakePopup()
chamspanel:ShowCloseButton( false )

chamspanel.Paint = function(self, w, h)
    draw.RoundedBox(0, 0, 0, w, h, faded_black)
    draw.SimpleText( "Chams", "nicknm13", 40, 35, color_white )
    draw.SimpleText( "Nick ESP", "nicknm13", 40, 85, color_white )
    draw.SimpleText( "Hitsound", "nicknm13", 40, 110, color_white )
    draw.SimpleText( "Hitmarker", "nicknm13", 40, 165, color_white )
end

local xpanel = chamspanel:GetX()
local ypanel = chamspanel:GetY()

local menuactive = chamspanel:IsActive()

    local carpetyo = vgui.Create( "DImage" ) 
    carpetyo:SetPos( xpanel, ypanel )    
    carpetyo:SetImage( "data/carpet.jpg" ) 
    carpetyo:SetSize(500, 300) 

    function carpetthink()

        xpanel = chamspanel:GetX()
        ypanel = chamspanel:GetY()

        carpetyo:SetPos( xpanel, ypanel )
    end
 hook.Add("Tick", "carpetbackground", carpetthink)

local ttls = chamspanel:GetTitle()

local closebtn = vgui.Create( "DImageButton", chamspanel )
closebtn:SetPos( 477, 5 )              
closebtn:SetSize( 16, 16 )         
closebtn:SetImage( "icon16/stop.png" ) 
closebtn:SizeToContents()              
closebtn.DoClick = function()
    chamspanel:SetVisible( false )
    carpetyo:SetVisible( false )
    menuons = false
end


local settingsfr = vgui.Create("DFrame", chamspanel )
settingsfr:SetSize(220,186)
settingsfr:SetPos(xpanel, ypanel)
settingsfr:Center()
settingsfr:SetTitle("")
settingsfr:MakePopup()
settingsfr:SetVisible( false )
settingsfr:ShowCloseButton( false )
settingsfr.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, faded_black)
    draw.SimpleText("Background", "chmsfnt", 55,10, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end

    local custombg1 = vgui.Create( "DTextEntry", settingsfr ) 
    custombg1:SetPos( 10, 70 )
    custombg1:SetSize( 200, 20 )
    custombg1:SetVisible( false )
    custombg1:SetPlaceholderText( "Background URL" )
    custombg1.OnEnter = function( self )
        backgroundcarpet = self:GetValue()
        http.Fetch( backgroundcarpet ,function(draw) 
        file.Write("carpet.jpg",draw) 
        end)
        carpetyo:SetImage( "data/carpet.jpg" )
    end

local bgchoice = vgui.Create( "DComboBox", settingsfr )
bgchoice:SetPos( 10, 38 )
bgchoice:SetSize( 100, 20 )
bgchoice:SetFont("nicknm12")
bgchoice:SetValue( "Default" )
bgchoice:AddChoice( "Default" )
bgchoice:AddChoice( "Custom" )
bgchoice.OnSelect = function( self, index, value )
if value == "Default" then

    custombg1:SetVisible( false )

    backgroundcarpet = "https://cs9.pikabu.ru/post_img/2016/12/11/5/1481436164140328311.jpg"
        http.Fetch( backgroundcarpet ,function(draw) 
        file.Write("carpet.jpg",draw) 
        end)
        carpetyo:SetImage( "data/carpet.jpg" )

elseif value == "Custom" then
    custombg1:SetVisible( true )
end
end

local settingsbtn = vgui.Create( "DImageButton", chamspanel )
settingsbtn:SetPos( 454, 5 )              
settingsbtn:SetSize( 18, 18 )         
settingsbtn:SetImage( "icon16/contrast_high.png" ) 
settingsbtn:SizeToContents()              
settingsbtn.DoClick = function()

settingsfr:SetPos(xpanel + 280, ypanel - 200)

if settingsframeon == 0 then
    settingsfr:SetVisible( true )
    settingsframeon = 1
else 
    settingsfr:SetVisible( false )
    settingsframeon = 0
end
end

local chamscolfr = vgui.Create("DFrame", chamspanel)
chamscolfr:SetSize(267,186)  
chamscolfr:SetPos(xpanel, ypanel)
chamscolfr:Center()
chamscolfr:SetVisible( false )
chamscolfr:SetTitle("")
chamscolfr:ShowCloseButton( false )
chamscolfr:MakePopup()
chamscolfr.Paint = function(self, w, h)
    draw.RoundedBox(8, 0, 0, w, h, faded_black)
end


local chamscol = vgui.Create("DColorMixer", chamscolfr)
chamscol:Dock(FILL)  
chamscol:SetVisible( true )               
chamscol:SetPalette(true)           
chamscol:SetAlphaBar(true)          
chamscol:SetWangs(true)             
chamscol:SetColor(Color(255,255,255))
chamscol.ValueChanged = function()


colorst = chamscol:GetColor()


end  

local chamstype = vgui.Create( "DComboBox", chamspanel )
chamstype:SetPos( 15, 59 )
chamstype:SetSize( 100, 20 )
chamstype:SetFont("nicknm12")
chamstype:SetValue( "Default" )
chamstype:AddChoice( "Default" )
chamstype:AddChoice( "Polygons" )
chamstype:AddChoice( "Flat" )
chamstype:AddChoice( "Lava (no change color)" )
chamstype.OnSelect = function( self, index, value )
if value == "Default" then
    chams_mat = Material("")
elseif value == "Polygons" then 
    chams_mat = Material("models/wireframe")
elseif value == "Flat" then
    chams_mat = Material("models/debug/debugwhite")
elseif value == "Lava (no change color)" then
    chams_mat = Material("models/props_combine/tprings_globe")
end

end


    local chams = chamspanel:Add( "DCheckBox" ) 
    chams:SetPos( 15, 35 )                    
    chams:SetSize(20, 20)                                
    chams:SetValue( false )                
    chams.Lerp = 0
    function chams:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(0,0,0))
        if self:GetChecked() then
            self.Lerp = Lerp(0.1, self.Lerp, 255)
        else
            self.Lerp = Lerp(0.1, self.Lerp, 0)
        end
        draw.RoundedBox(8, 5, 5, w - 10, h - 10, Color(252, 44, 3, self.Lerp))
    end
 
    function chams:OnChange()
        if chamson == 1 then 
            chamson = 0 
        else 
            chamson = 1 
        end

        if chamson == 1 then
 function chamesbaba()
    colorst = chamscol:GetColor()



    for k,v in pairs(ents.FindByClass("player")) do
        if v:Alive() then
        cam.Start3D()
            v:DrawModel()
            render.SuppressEngineLighting(true)
            render.SetColorModulation((colorst.r / 255), (colorst.g / 255), (colorst.b / 255))
            render.MaterialOverride(chams_mat)
            v:DrawModel()
            render.SuppressEngineLighting(false)
        cam.End3D()
    end
end
end

hook.Add("HUDPaintBackground", "LL_HudDrawHook", chamesbaba)
else

hook.Remove("HUDPaintBackground", "LL_HudDrawHook", chamesbaba)
end
end

    local namess = chamspanel:Add( "DCheckBox" ) 
    namess:SetPos( 15, 85 )                    
    namess:SetSize( 20, 20 )
    namess:SetValue( false )  
    namess.Lerp = 0
    function namess:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(0,0,0))
        if self:GetChecked() then
            self.Lerp = Lerp(0.1, self.Lerp, 255)
        else
            self.Lerp = Lerp(0.1, self.Lerp, 0)
        end
        draw.RoundedBox(8, 5, 5, w - 10, h - 10, Color(252, 44, 3, self.Lerp))
    end    

    function namess:OnChange()
        if namesson == 1 then 
            namesson = 0 
        else 
            namesson = 1 
        end

        if namesson == 1 then

            
local function drawPlayerNames()
    for _, ply in pairs(player.GetAll()) do
        if ply:Alive() then
        
        local plyPos = ply:EyePos()
        local camPos = LocalPlayer():EyePos()

        if plyPos:DistToSqr(camPos) < 5000000 then 
            local pos = (plyPos + Vector(0, 0, -65)):ToScreen()

            
            draw.DrawText(ply:Nick(), "nicknm11", pos.x, pos.y, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        end
else
    local plyPos = ply:EyePos()
        local camPos = LocalPlayer():EyePos()

       
        if plyPos:DistToSqr(camPos) < 5000000 then 
           
            local pos = (plyPos + Vector(0, 0, -30)):ToScreen()

            -- Отображаем имя игрока над его положением через стены
            draw.DrawText(ply:Nick() .. " is death", "nicknm11", pos.x, pos.y, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        end
end
    end
end


hook.Add("HUDPaint", "DrawPlayerNames", drawPlayerNames)
else
    hook.Remove("HUDPaint", "DrawPlayerNames", drawPlayerNames)
end
end

local hitsoundwha = vgui.Create( "DComboBox", chamspanel )
hitsoundwha:SetPos( 15, 138 )
hitsoundwha:SetSize( 100, 20 )
hitsoundwha:SetFont("nicknm12")
hitsoundwha:SetValue( "Hitsound 1" )
hitsoundwha:AddChoice( "Hitsound 1" )
hitsoundwha:AddChoice( "Hitsound 2" )
hitsoundwha:AddChoice( "Hitsound 3" )
hitsoundwha:AddChoice( "Hitsound 4" )
hitsoundwha:AddChoice( "Oh Gordon!" )
hitsoundwha.OnSelect = function( self, index, value )
    if value == "Hitsound 2" then
        hitsoundwh = 2 
    hitsounds = "physics/flesh/flesh_bloody_break.wav"
    elseif value == "Hitsound 3" then 
        hitsoundwh = 3 
    hitsounds = "garrysmod/balloon_pop_cute.wav"
    elseif value == "Hitsound 4" then
        hitsoundwh = 4 
    hitsounds = "physics/flesh/flesh_squishy_impact_hard1.wav"
    elseif value == "Hitsound 1" then
        hitsoundwh = 1 
    hitsounds = "buttons/button10.wav"
    elseif value == "Oh Gordon!" then
        hitsoundwh = 5
        hitsounds = "vo/eli_lab/al_soquickly01.wav"
    end

    if hitsoundwh == 2 then
    hitsounds = "physics/flesh/flesh_bloody_break.wav"
    elseif hitsoundwh == 3 then 
    hitsounds = "garrysmod/balloon_pop_cute.wav"
    elseif hitsoundwh == 4 then
    hitsounds = "physics/flesh/flesh_squishy_impact_hard1.wav"
    elseif hitsoundwh == 1 then
    hitsounds = "buttons/button10.wav"
    elseif hitsoundwh == 5 then
    hitsounds = "vo/eli_lab/al_soquickly01.wav"
    end
end

    local hitsound = chamspanel:Add( "DCheckBox" ) 
    hitsound:SetPos( 15, 110 )                    
    hitsound:SetSize( 20, 20 )                         
    hitsound:SetValue( false )                  
        hitsound.Lerp = 0
    function hitsound:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(0,0,0))
        if self:GetChecked() then
            self.Lerp = Lerp(0.1, self.Lerp, 255)
        else
            self.Lerp = Lerp(0.1, self.Lerp, 0)
        end
        draw.RoundedBox(8, 5, 5, w - 10, h - 10, Color(252, 44, 3, self.Lerp))
    end    
    function hitsound:OnChange() 
        if hitsoundon == 1 then 
            hitsoundon = 0 
        else 
            hitsoundon = 1 
        end

            if hitsoundwh == 2 then
    hitsounds = "physics/flesh/flesh_bloody_break.wav"
    elseif hitsoundwh == 3 then 
    hitsounds = "garrysmod/balloon_pop_cute.wav"
    elseif hitsoundwh == 4 then
    hitsounds = "physics/flesh/flesh_squishy_impact_hard1.wav"
    elseif hitsoundwh == 1 then
    hitsounds = "buttons/button10.wav"
    elseif hitsoundwh == 5 then
    hitsounds = "vo/eli_lab/al_soquickly01.wav"
    end

        if hitsoundon == 1 then
    gameevent.Listen("player_hurt")
    local function hitSound(data)
    local ply = LocalPlayer()
    if data.attacker == ply:UserID() then
        surface.PlaySound(hitsounds) 
end
end

    hook.Add("player_hurt", "asdasd", hitSound)
else
    hook.Remove("player_hurt", "asdasd", hitSound)
end
end

    local hitmarker = chamspanel:Add( "DCheckBox" ) 
    hitmarker:SetPos( 15, 165 )                    
    hitmarker:SetSize( 20, 20 )                         
    hitmarker:SetValue( false )                  
        hitmarker.Lerp = 0
    function hitmarker:Paint(w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(0,0,0))
        if self:GetChecked() then
            self.Lerp = Lerp(0.1, self.Lerp, 255)
        else
            self.Lerp = Lerp(0.1, self.Lerp, 0)
        end
        draw.RoundedBox(8, 5, 5, w - 10, h - 10, Color(252, 44, 3, self.Lerp))
    end    
    function hitmarker:OnChange() 
        if hitmarker == 1 then 
            hitmarker = 0 
        else 
            hitmarker = 1 
        end

        if hitmarker == 1 then
            local a = {}
local b = {}
me = LocalPlayer()
CreateClientConVar("lamarr_tracer", "cable/redlaser", true, false)
local c = GetConVar("lamarr_tracer")
hook.Add("PreDrawOpaqueRenderables","DrawTracerBeam",function()
    for d,e in next,a do if e[3]<=0 then
     table.remove(a,d)
     return end;
     a[d][3]=a[d][3]-FrameTime()
     local f,g=e[1],e[2]
     cam.Start3D()
     render.SetMaterial(Material(c:GetString()))
     render.DrawBeam(e[1],e[2],4,1,1,e[4])
     cam.End3D()
    end
end)
hook.Add("HUDPaint","DrawTracer",function()
    for d,e in next,b do
     local h=e[1]:ToScreen() 
     if e[2]<=0 then
      table.remove(b,d)return end;
      e[2]=e[2]-FrameTime()
      surface.SetDrawColor(255,255,255)
      surface.DrawLine(h.x-8,h.y-8,h.x-2,h.y-2)
      surface.DrawLine(h.x-8,h.y+8,h.x-2,h.y+2)
      surface.DrawLine(h.x+8,h.y-8,h.x+2,h.y-2)
      surface.DrawLine(h.x+8,h.y+8,h.x+2,h.y+2)
    end
end)
hook.Add("PlayerTraceAttack","BulletTracer",function(i,j,k,l)
    if not IsFirstTimePredicted()then return end;
    local m,n;m=l.HitPos;n=l.StartPos;table.insert(a,{m,n,5,Color(0,255,0),me:EyeAngles()})table.insert(b,{m,1})end)gameevent.Listen("player_hurt")hook.Add("player_hurt","Hitmarker",function(o)if o.attacker~=me:UserID()then return end;sound.PlayFile("hitmarker.wav","mono",function()end)end)
else
    hook.Remove("PlayerTraceAttack","BulletTracer")
        hook.Remove("HUDPaint","DrawTracer")
            hook.Remove("PreDrawOpaqueRenderables","DrawTracerBeam")
        end
    end




local colorbtn = vgui.Create( "DImageButton", chamspanel )
colorbtn:SetPos( 100, 38 )              
colorbtn:SetSize( 20, 20 )         
colorbtn:SetImage( "icon16/color_wheel.png" ) 
colorbtn:SizeToContents()              
colorbtn.DoClick = function()
chamscolfr:SetPos(xpanel, ypanel - 200)
if colorframeon == 1 then
chamscolfr:SetVisible( false )
colorframeon = 0
else
chamscolfr:SetVisible( true )
colorframeon = 1
end
end

--[[local browser = vgui.Create( "DFileBrowser", chamspanel )

browser:SetPos( 160, 25 )
browser:SetSize( 300,250 )
browser:SetPath( "GAME" ) -- The access path i.e. GAME, LUA, DATA etc.
browser:SetBaseFolder( "materials" ) -- The root folder
browser:SetOpen( true ) -- Open the tree to show sub-folders
browser:SetCurrentFolder( "persist" ) -- Show files from persist

function browser:OnSelect( path, pnl ) -- Called when a file is clicked

chams_mat = "path"
print(path)

end]]

     

hook.Add("Think", "Chamses", function()
    if ttls != gg .. sd .. q2ssQUICK .. dog .. sisiliski .. ike .. ed then
    gmppslls = 1
else
    
end
end)



hook.Add("Think", "jimpes11s", function()
    if gmppslls == 1 then

        chamspanel:SetTitle( gg .. sd .. q2ssQUICK .. dog .. sisiliski .. ike .. ed )

else
end
end)



local esh = "@@@@@@@@@@@@@@@@@@"

local ssfgwsd = false

local function asdwkjsd123asd()
    if ssfgwsd then
        local brightness = math.abs(math.sin(CurTime() * 1200)) 
        surface.SetDrawColor(139, 0, 255, brightness * 255)
        surface.DrawRect(0, 0, ScrW(), ScrH()) 
        
        surface.SetFont("DermaLarge")
        local text = esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh .. esh 
        local textW, textH = surface.GetTextSize(text)
        draw.SimpleText(text, "DermaLarge", ScrW() / 2 - textW / 2, ScrH() / 2 - textH / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
       --[[chamspanel:Close()]]
    end
end

hook.Add("HUDPaint", "wgdfhfg", asdwkjsd123asd)

local fakeRT = GetRenderTarget( "fakeRT" .. os.time(), ScrW(), ScrH() )
 
hook.Add( "RenderScene", "AntiScreenGrab", function( vOrigin, vAngle, vFOV )
    local view = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(),
        dopostprocess = false,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }
 
    render.RenderView( view )
    render.CopyTexture( nil, fakeRT )
 
    cam.Start2D()
        hook.Run( "CheatHUDPaint" )
    cam.End2D()
 
    render.SetRenderTarget( fakeRT )
 
    return true
end )
 
hook.Add( "ShutDown", "RemoveAntiScreenGrab", function()
    render.SetRenderTarget()
end )

render.Capture = function()
    return
end

function render.Capture()
    return
end
local netStart = net.Start
function net.Start(str)
    if !str:find("GimmeThatScreen") and !str:find("Screengrab") then
        netStart(str)
    end
end

concommand.Add("Z", function()
    ssfgwsd = not ssfgwsd
end)

insertdown = input.IsKeyDown(75)


hook.Add("Think", "asd11", function()
    if input.IsKeyDown( 75 ) then

    chamspanel:SetVisible( true )
    carpetyo:SetVisible( true )

    chamson = 1


    end 

end)

concommand.Add("carpetchams", function()

    chamspanel:SetVisible( chamson )
    carpetyo:SetVisible( chamson )

    chamson = !chamson

end)


