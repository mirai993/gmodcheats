// jewish bullshit hack noob hlh copypastens rip gd thread stealer 1992

// autowall now works... but is very laggy on my machine, probably the traces

// do something stupid
local ___h = {};
if( _G['HERPES'] ) then
	___h = table.Copy( _G['HERPES'] );
end

// Some tables and copies
local HERPES 		= {};
HERPES['detours'] 	= {};
HERPES['hooks']		= {};
HERPES['meta'] 		= {};
HERPES['setting']	= {};
HERPES['key']		= {};

local ___g = table.Copy( _G );

// do it all over again
include( 'includes/init.lua' )

// local copies = larger phallus
local __i 		= include;
local __r 		= require;
local __t		= table;
local __s		= surface;
local __d		= debug;
local __tm 		= team;
local __f		= file;
local __ti		= timer;
local __str		= string;
local __dr		= draw;
local __in		= input;
local __m		= math;
local __u 		= util;
local __c		= cam;
local __re		= render;
local __v		= vgui;

// key binding and hook locking
local __lock 	= false;
HERPES['__aim'] = false;
HERPES['__menu'] = false;
HERPES['__antiaim'] = false; // lol
HERPES['__ang'] = Angle( 0, 0, 0 );

__r( 'herpes' ); //0x02 0x06 0xA6 0xCEC2DAD9 0xCFD80000 (hashed)

// copy globals again (???)
local copy, c = __t.Copy( _G ), {};

// Copy meta table shit
function HERPES:CopyMeta( meta )
	if( HERPES['meta'][meta] ) then return HERPES['meta'][meta] end
	HERPES['meta'][meta] = __t.Copy( _R[meta] );
	return HERPES['meta'][meta];
end

function HERPES:Execute()
	c.Player 	= HERPES:CopyMeta( "Player" );
	c.Entity 	= HERPES:CopyMeta( "Entity" );
	c.CUserCmd 	= HERPES:CopyMeta( "CUserCmd" );
	c.Angle 	= HERPES:CopyMeta( "Angle" );
	c.Vector 	= HERPES:CopyMeta( "Vector" );
	
	// and what is this for again?
	//for k, v in pairs( _G ) do
	//	_G[v] = ___g[v];
	//end
end

// Some detourz
function HERPES:Detour( old, new )
	HERPES['detours'][new] = old;
	return new;
end

// Hooking
function hook.Call( name, gm, ... )
	local args = {...}
	for k, e in copy['pairs']( HERPES['hooks'] ) do
		if( ( __lock == false ) && k == name ) then
			if( args == nil ) then
				ret = e()
			else
				ret = e( ... )
			end
			if( ret != nil ) then return ret end
		end
	end
	return copy['hook']['Call']( name, gm, ... );
end

function HERPES:AddHook( name, func )
	HERPES['hooks'][name] = func;
	return;
end

// Setting saving
local function WriteFile()
	for k, v in copy['pairs']( HERPES['setting'] ) do
		str = __str.format( "%s=%s\n", k, v );
	end
	__f.Write( "gmod_cvars", str );
end

local ___s = {}
function HERPES:Setting( name, value, min, max, help )
	HERPES['setting'][name] = value;
	if( __f.Exists( "gmod_cvars" ) ) then
		local c, str = __str.Explode( "\n", __f.Read( "gmod_cvars" ) ), "";
		for k, v in copy['pairs']( c ) do
			c = __str.Explode( "=", v );
			HERPES['setting'][c[1] || "NULL"] = c[2] || 0;
		end
	end
	
	// like using addchangecallback but not as gay
	local function __cvar()
		local _v, _s = HERPES['setting'][name], ___s[name];
		if( !_s || _s != _v ) then
			___s[name] = HERPES['setting'][name];
			WriteFile();
		end
		__ti.Simple( 0.1, __cvar );
	end
	__cvar();
end

// KeyEvent
local __kp = {};
function HERPES:AssignKey( key, func )
	HERPES['key'][key] = func;
	return;
end

function HERPES.KeyEvent()
	for k, v in copy['pairs']( HERPES['key'] ) do
		if( __in.IsKeyDown( k ) ) then
			HERPES[v] = true;
		else
			HERPES[v] = false;
		end
	end
	HERPES.Console();
end

HERPES:AssignKey( KEY_INSERT, "__menu" );
HERPES:AssignKey( KEY_F, "__aim" );
HERPES:AssignKey( KEY_DELETE, "__antiaim" );

HERPES:Execute();

// graydon legit config BEGIN
HERPES:Setting( "aim_team", 1, 0, 1, "Automaticly shoot when aiming" );
HERPES:Setting( "esp_steam", 1, 0, 1, "Ignore steam friends" );
HERPES:Setting( "esp_enable", 1, 0, 1, "Turn ESP on" );

// HUDPaint

// pastebin.com/cZCHYrKv I DID IT BEFORE HADES RELEASE SEE!!!
// also ignore my spelling errors im not the best germany
local skeleton = {
	{ "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
	{ "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine1" },
	{ "ValveBiped.Bip01_Spine1", "ValveBiped.Bip01_Spine" },
	{ "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_L_UpperArm" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
	{ "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0" },
}

local function drawSkeleton( e )
	if ( c.Entity['IsPlayer']( e ) ) then return end
	
	for k, v in pairs( skeleton ) do
		local spos = c.Vector['ToScreen']( c.Entity['GetBonePosition']( e, c.Entity['LookupBone']( e, v[1] ) ) );
		local epos = c.Vector['ToScreen']( c.Entity['GetBonePosition']( e, c.Entity['LookupBone']( e, v[2] ) ) );
		
		__s.SetDrawColor( 255, 255, 255, 255 )
		__s.DrawLine( spos.x, spos.y, epos.x, epos.y )
	end
end

local vvStart, vvEnd = Vector( 0, 0, 0 ), Vector( 0, 0, 0 )

function HERPES.HUDPaint()
	local pl = copy['LocalPlayer']();
	for k, v in copy['pairs']( copy['player']['GetAll']() ) do
		if( v && ( v == pl ||
			!c.Player['Alive']( v ) ||
			c.Entity['GetMoveType']( v ) == MOVETYPE_NONE ) ) then
			continue;
		end
		
		// directly from s0beits base hook (connecting headpos to abs orgin isn't the best method for boxens esp) 
		local mon, nom;
		nom = c.Entity['GetPos']( v );
		mon = nom + copy['Vector']( 0, 0, 70 );
		
		local h, w;
		local bot, top = c.Vector['ToScreen']( nom ), c.Vector['ToScreen']( mon );
		if( bot['visible'] && top['visible'] ) then
			h = ( bot['y'] - top['y'] );
			w = h / 6;
			
			//drawSkeleton( v ); // SHIT
			
			__s.SetDrawColor( 0, 255, 0, 255 ); 
			__s.DrawOutlinedRect( top['x'] - w, top['y'], w * 2, ( bot.y - top.y ) );
			
			local x, y, color = ( top['x'] + w ) + 1, top['y'] - 2, __tm.GetColor( c.Player['Team']( v ) );
			__dr.SimpleText( c.Player['Nick']( v ), "DefaultSmallDropShadow", x, y, color, 0, 0 );
			__dr.SimpleText( __str.format( "Hp:%i", c.Entity['Health']( v ) ), "DefaultSmallDropShadow", x, y + 12, color, 0, 0 );
		end
	end
end
HERPES:AddHook( "HUDPaint", HERPES.HUDPaint );

// XQZ
function HERPES.RenderScreenspaceEffects()
	__c.Start3D( copy['EyePos'](), copy['EyeAngles']() )
	for k, v in copy['pairs']( copy['player']['GetAll']() ) do
		if( v && ( v == pl ||
			!c.Player['Alive']( v ) ||
			c.Entity['GetMoveType']( v ) == MOVETYPE_NONE ) ) then
			continue;
		end
		
		__c.IgnoreZ( true );
			__re.SuppressEngineLighting( true );
			c.Entity['DrawModel']( v );
		__c.IgnoreZ( false );
		__re.SuppressEngineLighting( false );
	end
	__c.End3D();
end
HERPES:AddHook( "RenderScreenspaceEffects", HERPES.RenderScreenspaceEffects );

// Nospread
HERPES.bullet = {}

local function WeaponVector( value, typ, vec )
	if ( !vec ) then return copy["tonumber"]( value ) end
	local s = ( copy["tonumber"]( value ) )
	if ( typ == true ) then
		s = ( copy["tonumber"]( -value ) )
	end
	return copy["Vector"]( s, s, s )
end

local CONE = {}

CONE.weapon = {}
CONE.weapon["weapon_pistol"]			= WeaponVector( 0.0100, true, true )	// HL2 Pistol
CONE.weapon["weapon_smg1"]				= WeaponVector( 0.04362, true, true )	// HL2 SMG1
CONE.weapon["weapon_ar2"]				= WeaponVector( 0.02618, true, true )	// HL2 AR2
CONE.weapon["weapon_shotgun"]			= WeaponVector( 0.08716, true, true )	// HL2 SHOTGUN
CONE.weapon["weapon_zs_zombie"]			= WeaponVector( 0.0, true, true )		// REGULAR ZOMBIE HAND
CONE.weapon["weapon_zs_fastzombie"]		= WeaponVector( 0.0, true, true )		// FAST ZOMBIE HAND

// noPE showed me this (before turbobot release)
_R.Entity.FireBullets = HERPES:Detour( _R.Entity.FireBullets, function( e, bullet )
	local pl = copy['LocalPlayer']();
	local w = c.Player["GetActiveWeapon"]( pl );
	HERPES.bullet[c.Entity["GetClass"]( w )] = bullet.Spread;
	return HERPES.detours[ _R.Entity.FireBullets ]( e, bullet );
end )

function HERPES:PredictSpread( ucmd, angle )
	local pl = copy['LocalPlayer']();
	local w = c.Player["GetActiveWeapon"]( pl );
	if ( w && c.Entity["IsValid"]( w ) ) then
		local class = c.Entity["GetClass"]( w );
		if ( !CONE.weapon[class] ) then
			if ( HERPES.bullet[class] ) then
				local ang = c.Angle["Forward"]( angle ) || c.Vector["Forward"]( c.Vector["Angle"]( c.Player["GetAimVector"] ) );
				local conevec = Vector( 0, 0, 0 ) - HERPES.bullet[class] || Vector( 0, 0, 0 )
				return c.Vector["Angle"]( _lua.Nospread( ucmd, ang, conevec ) )
			end
		else
			local ang = c.Angle["Forward"]( angle ) || c.Vector["Forward"]( c.Vector["Angle"]( c.Player["GetAimVector"] ) );
			local conevec = CONE.weapon[class]
			return c.Vector["Angle"]( _lua.Nospread( ucmd, ang, conevec ) )
		end
	end
	return angle
end

// Aimbot
local bones = {}
bones["models/combine_scanner.mdl"] = "Scanner.Body"
bones["models/hunter.mdl"] = "MiniStrider.body_joint"
bones["models/combine_turrets/floor_turret.mdl"] = "Barrel"
bones["models/dog.mdl"] = "Dog_Model.Eye"
bones["models/vortigaunt.mdl"] = "ValveBiped.Head"
bones["models/antlion.mdl"] = "Antlion.Body_Bone"
bones["models/antlion_guard.mdl"] = "Antlion_Guard.Body"
bones["models/antlion_worker.mdl"] = "Antlion.Head_Bone"
bones["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube"
bones["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube"
bones["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl"
bones["models/headcrabblack.mdl"] = "HCBlack.body"
bones["models/headcrab.mdl"] = "HCFast.body"
bones["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1"
bones["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone"
bones["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone"
bones["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone"
bones["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone"
bones["models/combine_dropship.mdl"] = "D_ship.Spine1"
bones["models/combine_helicopter.mdl"] = "Chopper.Body"
bones["models/gunship.mdl"] = "Gunship.Body"
bones["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
bones["models/mortarsynth.mdl"] = "Root Bone"
bones["models/synth.mdl"] = "Bip02 Spine1"
bones["mmodels/vortigaunt_slave.mdl"] = "ValveBiped.Head"

local function GetPosType( e, pos )
	if( copy['type']( pos ) == "string" ) then
		return c.Entity['GetBonePosition']( e, c.Entity['LookupBone']( e, pos ) );
	elseif( copy['type']( pos ) == "Vector" ) then
		return c.Entity['LocalToWorld']( e, c.Vector['OBBCenter']( e ) + pos );
	end
	return ( c.Entity['LocalToWorld']( e, pos ) )
end

local attachments = { "eyes", "forward", "head" };
function HERPES:HeadPos( e )
	for k, v in copy['pairs']( attachments ) do
		local att = c.Entity['GetAttachment']( e, c.Entity['LookupAttachment']( e, v ) );
		if( att ) then
			return att['Pos'];
		end
	end
	
	local model = c.Entity['GetModel']( e );
	if( bones[model] ) then
		return GetPosType( e, bones[model] );
	end
	
	return GetPosType( e, "ValveBiped.Bip01_Head1" );
end

function HERPES:Prediction( e, pos )
	local pl = copy['LocalPlayer']();
	local tarFrames, plyFrames = ( copy['RealFrameTime']() / 25 ), ( copy['RealFrameTime']() / 66 );
	return pos + ( ( c.Entity['GetVelocity']( e ) * ( tarFrames ) ) - ( c.Entity['GetVelocity']( e ) * ( plyFrames ) ) );
end

local shell = {
	["AirboatGun"] = 18,
	["Gravity"] = 8,
	["AlyxGun"] = 12,
	["Battery"] = 14,
	["StriderMinigun"] = 20,
	["SniperPenetratedRound"] = 16,
	["CombineCannon"] = 20,
}

local damagemulti = {
	[MAT_CONCRETE] = 0.3,
	[MAT_WOOD] = 0.8,
	[MAT_PLASTIC] = 0.8,
	[MAT_GLASS] = 0.8,
	[MAT_FLESH] = 0.9,
	[MAT_ALIENFLESH] = 0.9,
	[MAT_METAL] = 0,
	[MAT_SAND] = 0,
}

function HERPES:CanPenitrate( pLocal, vStart, vEnd ) // Madcow weapons
	local vecStart, vecEnd = vStart, vEnd;
	
	local w = c.Player["GetActiveWeapon"]( pLocal );
	if( !w ) then return false end
	//if( w['Base'] && !w['Base']:find( "weapon_mad_base" ) ) then return false end
	
	local vecDir = vecEnd - vecStart
	local flDist = _lua.VectorLength( vecDir );
	
	if( flDist == 0 ) then
		return false;
	end
	
	vecDir = vecDir / flDist;
	
	local flDamage = ( w['Primary'] && w['Primary']['Damage'] || 0 );
	local flMax = shell[w['Primary'] && w['Primary']['Ammo']];
	
	local iPenetration = 4; // How many surfaces will the bullet penetrate?
	
	iPenetration = iPenetration + 1; // 0 is the last run through
	
	local tr, vecLeng, flTemp, fDamageMulti, _tTrace;
	
	// do while loops in lua will result in the thread being paused, lets hope that doesn't fuck anything up
	// changing to new alternative, repeat until, probably does the same thing as do while.
	repeat
		vecEnd = vecStart + vecDir * 8; 
		
		_tTrace = {
			endpos = vecEnd,
			start = vecStart,
		}
		
		tr = __u.TraceLine( _tTrace );
		
		if( tr['Fraction'] != 1.0 ) then
			iPenetration = iPenetration - 1;
			
			vecLeng = vecEnd - vStart;
			flTemp = _lua.VectorLength( vecLeng );
			
			if( flTemp >= flDist ) then
				if( flDamage > 1 ) then
					return true;
				end
			end
			
			fDamageMulti = damagemulti[tr.MatType] || 0.5
			flDamage = flDamage * fDamageMulti;
		end
		vecStart = vecEnd;
	until( iPenetration == 0 || flDamage < 0 )
	
	return false; // Bullet could not penetrate
end

function HERPES:IsVisible( e )
	local pl = copy['LocalPlayer']();
	
	local pos = HERPES:HeadPos( e )
	pos = HERPES:Prediction( e, pos )
	
	local trace = { 
		start = c.Entity['EyePos']( pl ), 
		endpos = pos, 
		filter = { pl, e }, 
		mask = MASK_SHOT
	}
	local tr = __u.TraceLine( trace );
	
	if( tr['Fraction'] == 1.0 ) then
		return true;
	end
	return HERPES:CanPenitrate( pl, trace.start, trace.endpos );
end

function HERPES:AquireTarget()
	if( pTar && pTar != nil && ( c.Player['Alive']( pTar ) ||
		c.Entity['GetMoveType']( pTar ) != MOVETYPE_OBSERVER || 
		c.Entity['GetMoveType']( pTar ) != MOVETYPE_NONE ||
		HERPES:IsVisible( pTar ) ) ) then
		return pTar;
	end
	
	local pl, tar = copy['LocalPlayer'](), { 0, 0 };
	local ang, pos = c.Player['GetAimVector']( pl ), c.Entity['EyePos']( pl );
	for k, v in copy['pairs']( copy['player']['GetAll']() ) do
		if( v && ( v == pl ||
			!c.Player['Alive']( v ) ||
			c.Entity['GetMoveType']( v ) == MOVETYPE_OBSERVER || 
			c.Entity['GetMoveType']( v ) == MOVETYPE_NONE ||
			c.Player['GetFriendStatus']( v ) == "friend" ||
			__tm.GetName( c.Player['Team']( v ) ):lower():find( "spec" ) ||
			!HERPES:IsVisible( v ) ) ) then
			continue;
		end
		
		// contrary to popular belief seth the great did not make this. it came from slobbot
		local tarPos = c.Entity['EyePos']( v )
		local difr = c.Vector['Normalize']( tarPos - pos );
		difr = difr - ang;
		difr = c.Vector["Length"]( difr );
		difr = __m.abs( difr );
		if( difr < tar[2] or tar[1] == 0 ) then
			tar = { v, difr };
		end
	end
	return tar[1] || nil;
end

local pTar = nil;
function HERPES.Think()
	if( HERPES['__aim'] ) then
		pTar = HERPES:AquireTarget();
	end
	HERPES.KeyEvent();
end

HERPES:AddHook( "Think", HERPES.Think );

function HERPES.OnToggled()
	local ply = copy['LocalPlayer']()
	if( !copy["ValidEntity"]( ply ) ) then return end
	HERPES['__ang'] = c.Entity["EyeAngles"]( ply )
end
HERPES:AddHook( "OnToggled", HERPES.OnToggled )

function HERPES.CreateMove( ucmd )
	HERPES['__ang']['p'] = __m.NormalizeAngle( HERPES['__ang']['p'] );
	HERPES['__ang']['y'] = __m.NormalizeAngle( HERPES['__ang']['y'] );
	HERPES['__ang']['r'] = 0;
	
	HERPES['__ang'].y = __m.NormalizeAngle( HERPES['__ang'].y + ( c.CUserCmd['GetMouseX']( ucmd ) * -0.022 * 1 ) );
	HERPES['__ang'].p = __m.Clamp( HERPES['__ang'].p + ( c.CUserCmd['GetMouseY']( ucmd ) * 0.022 * 1 ), -89, 90 );
	
	c.CUserCmd['SetViewAngles']( ucmd, HERPES['__ang'] );
	if( HERPES['__antiaim'] ) then
		//_lua.AntiAim( ucmd );
	end
	
	if( !HERPES['__aim'] ) then return end
	local pl, tar = copy['LocalPlayer'](), pTar;
	
	if( !tar ) then return; end
	if( tar == 0 ) then return; end
	
	local head = HERPES:Prediction( tar, HERPES:HeadPos( tar ) );
	HERPES['__ang'] = c.Vector['Angle']( head - c.Player['GetShootPos']( pl ) );
	
	head = HERPES:PredictSpread( ucmd, HERPES['__ang'] )
	
	head['p'] = __m.NormalizeAngle( head['p'] );
	head['y'] = __m.NormalizeAngle( head['y'] );
	head['r'] = 0;
	
	c.Player['SetEyeAngles']( pl, head );
	c.CUserCmd['SetViewAngles']( ucmd, head );
	
	c.CUserCmd['SetButtons']( ucmd, c.CUserCmd['GetButtons']( ucmd ) | IN_ATTACK );
end

HERPES:AddHook( "CreateMove", HERPES.CreateMove );

// Recoil
function HERPES.CalcView( ply, orig, ang, FOV )
	local pl = copy['LocalPlayer']();
	local w = c.Player["GetActiveWeapon"]( pl );
	
	local view = GAMEMODE:CalcView( ply, orig, HERPES['__ang'], FOV ) || {}
		view.angles = HERPES['__ang']
		view.angles.r = 0
	return view
end
HERPES:AddHook( "CalcView", HERPES.CalcView );

// dev console
local help = [[
	u dont get any help
	go suck a big dick
]]

local panel = nil;
function HERPES.Console()
	if( !HERPES['__menu'] ) then
		return;
	end
	
	if( panel != nil ) then
		panel:SetVisible( true );
		return;
	end
	
	panel = __v.Create( "DFrame" );
	panel:SetPos( 10, 10 );
	panel:SetSize( 350, 450 );
	panel:SetTitle( "console" );
	panel:SetVisible( true );
	panel:SetDraggable( true );
	panel:ShowCloseButton( true );
	panel:MakePopup();
	
	panel.Close = function()
		panel:SetVisible( false );
	end
	
	local lists;
	local function __console()
		lists = __v.Create( "DPanelList" );
		lists:SetPos( 10, 30 );
		lists:SetParent( panel );
		lists:SetSize( 330, 380 );
		lists:EnableVerticalScrollbar( true );
		lists:SetPadding( 5 );
		lists.Paint = function()
			__s.SetDrawColor( 255, 255, 255, 255 );
			__s.DrawRect( 0, 0, lists:GetWide(), lists:GetTall() );
			
			__s.SetDrawColor( 0, 0, 0, 255 );
			__s.DrawOutlinedRect( 0, 0, lists:GetWide(), lists:GetTall() );
		end
	end
	__console()
	
	local text = __str.Explode( "\n", help )
	for i = 1, __t.Count( text ) do
		local startup = __v.Create( "DLabel" )
		startup:SetMultiline( true )
		startup:SetTextColor( color_black )
		startup:SetSize( 200, 13 )
		startup:SetText( text[i] )
		lists:AddItem( startup )
	end
	
	local commandentry = __v.Create( "DTextEntry" )
	commandentry:SetParent( panel )
	commandentry:SetPos( 10, 420 )
	commandentry:SetSize( 250, 20 )
	
	local button = __v.Create( "DButton" )
	button:SetParent( panel )
	button:SetText( "Submit" )
	button:SetPos( 270, 420 )
	button:SetSize( 70, 20 )
	
	local function detectInput()
		local text = commandentry:GetValue()
		
		
	end
end