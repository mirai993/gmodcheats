-- made by spritzerland <3
-- if urbanichka steals this fuck him
-- binds are mouse4 and mouse5
-- if you want this to a key, you'll have to edit the script, blame gLua
local targetAngle = nil
local startAngle = nil
local startTime = nil
local duration = 0.05
local chargeBind = MOUSE_4 
local launchBind = MOUSE_5 
local isRotating = false
local chargeWasPressed = false
local launchWasPressed = false

hook.Add("Think", "HandleMouseInput", function()
    local player = LocalPlayer()
    if not IsValid(player) then return end

    local chargeIsPressed = input.IsMouseDown(chargeBind)
    local launchIsPressed = input.IsMouseDown(launchBind)

    if chargeIsPressed and not chargeWasPressed and not isRotating then
        startAngle = player:EyeAngles()
        targetAngle = startAngle - Angle(0, -90, 0)
        startTime = CurTime()
        isRotating = true

        hook.Add("Think", "SmoothTurn", SmoothTurn)
    end

    if launchIsPressed and not launchWasPressed and not isRotating then
        player:SetEyeAngles(player:EyeAngles() - Angle(0, 90, 0))
        timer.Simple(0.01, function() RunConsoleCommand("+attack2") end)
        timer.Simple(0.03, function() RunConsoleCommand("-attack2") end)
    end

    chargeWasPressed = chargeIsPressed
    launchWasPressed = launchIsPressed
end)

function SmoothTurn()
    local player = LocalPlayer()
    if not IsValid(player) then return end

    local elapsed = CurTime() - startTime
    if elapsed > duration then
        player:SetEyeAngles(targetAngle)
        hook.Remove("Think", "SmoothTurn")
        isRotating = false
        return
    end

    local progress = elapsed / duration
    local currentAngle = LerpAngle(progress, startAngle, targetAngle)
    player:SetEyeAngles(currentAngle)
end
