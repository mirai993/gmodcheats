--[[
	MOD/lua/voltage.lua [#15713 (#16149), 3934119603, UID:713678193]
	[VRS] ɺsć [KDG] MrCraigT | STEAM_0:1:49624713 <86.30.250.6:27005> | [07.07.14 07:43:21PM]
	===BadFile===
]]

--SpeedHack--
    CreateClientConVar("vh_speedhack_speed",3.5)
    local factor = GetConVarNumber("vh_speedhack_speed")
    concommand.Add( "+vh_speed", function( p, c, a )
            cvar2.SetValue( "sv_cheats", "1" )
            cvar2.SetValue( "host_timescale", factor )
    end )
     
    concommand.Add( "-vh_speed", function( p, c, a )
            //cvar2.SetValue( "sv_cheats", "0" ) --Uncomment to turn sv_cheats off after SpeedHack is turned off.
            cvar2.SetValue( "host_timescale", "1.0" )
    end )
     
     
    --Spectators--
    local showSpectators = false
    hook.Add("HUDPaint", "showspectators", function()
            if GetConVarNumber( "vh_spectators" ) >= 1 then return end
            local spectatePlayers = {}
            local x = 0
            for k,v in pairs(player.GetAll()) do
                    if v:GetObserverTarget() == LocalPlayer() then
                            table.insert(spectatePlayers, v:Name())
                    end
            end
            local textLength = surface.GetTextSize(table.concat(spectatePlayers) ) / 3
            draw****undedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 17, Color(0, 0, 0, 150))
            draw.SimpleText("Spectators", "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 16, Color(255, 255, 255, 255))
     
            for k, v in pairs(spectatePlayers) do
            draw.SimpleText(v, "ScoreboardText", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(255, 255, 255, 255))
            x = x + 15
        end
    end)
     
     
    --LaserSight--
    local VH = {};
    local Allowed = { 'weapon_hvh_m4a1', 'weapon_sh_m249', 'weapon_sh_p228', 'weapon_sh_mp5a4', 'weapon_sh_deagle', 'weapon_sh_ak47', 'weapon_sh_m4a2', 'weapon_ar2', 'weapon_smg1', 'weapon_deagle', 'weapon_pistol', 'weapon_mad_deagle', 'weapon_mad_ak47', 'weapon_glock', 'weapon_para', 'weapon_ak47', 'weapon_fiveseven', 'weapon_mac10', 'weapon_tmp', 'weapon_m4', 'weapon_mp5', 'weapon_mad_mp5' }
     
    function VH.Barrel( )
    if GetConVarNumber( "vh_lasersight" ) >= 1 then return end
    local ViewModel = LocalPlayer():GetViewModel()
    local Attach = ViewModel:LookupAttachment( '1' )
    if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
    if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
    if( !table.HasValue( Allowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
    cam.Start3D( EyePos(), EyeAngles() )
    render.SetMaterial( Material( 'sprites/bluelaser1' ) )
    render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, team.GetColor( LocalPlayer():Team() ) )
    cam.End3D()
    end
    hook.Add( 'RenderScreenspaceEffects', '\2\3', VH.Barrel )
     
    --Hitmarker--
    function Hitmarker()
    if GetConVarNumber( "vh_hitmarker" ) >= 1 then
    local EyeEnt = LocalPlayer():GetEyeTrace().Entity
    if EyeEnt:IsPlayer() then
    if LocalPlayer():Health() > 0 then
    if LocalPlayer():GetCurrentCommand():KeyDown(IN_ATTACK) then
    if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
     
    surface.SetDrawColor( 255 , 0 , 0 , 255 )
    surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 - 5 , ScrW() / 2 - 15 , ScrH() / 2 - 15)
    surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 + 5 , ScrW() / 2 + 15, ScrH() / 2 + 15)
    surface.DrawLine(ScrW() / 2 + 5 , ScrH() / 2 - 5 , ScrW() / 2 + 15 , ScrH() / 2 - 15)
    surface.DrawLine(ScrW() / 2 - 5 , ScrH() / 2 + 5 , ScrW() / 2 - 15 , ScrH() / 2 + 15)
                                            end
                                    end
                            end
                                    end
                                            end
                                                    end
                                                   
    hook.Add("HUDPaint","DisplayShittyHitmarker",Hitmarker)
     
     
    --SilentAim--
    local Hooks = {};
     
    function AddHook( t, pac )
            local u = tostring( math.random( 1, 150 ) );
            table.insert( Hooks, u )
            return( hook.Add( t, u, pac ) );
    end
     
     
    local View = Angle( 0, 0, 0 );
     
    local function FakeView(ply, origin, angles, FOV)
            if( GetConVarNumber( 'vh_silentaim' ) >= 1 ) then return; end
            if GetViewEntity() != LocalPlayer() then return end
            local base = GAMEMODE:CalcView(ply, origin, View, FOV) || {}
                            base.angles = base.angles || View
                            base.angles.r = 0
            return base
    end
    AddHook("CalcView", FakeView)
     
     
    --Custom Crosshair--
    function Crosshair()
    if GetConVarNumber( "vh_crosshair" ) >= 1 then
    surface.SetDrawColor(0,0,0,255)
    surface.DrawLine(ScrW() / 2 - 20, ScrH() / 2, ScrW() / 2 + 22 , ScrH() / 2)
    surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 20, ScrW() / 2 - 0 , ScrH() / 2 + 22)
            end
    end
    hook.Add("HUDPaint","CustomCross",Crosshair)
     
    /////////////////////
    // **Derma menu** //
    ///////////////////
     
    /// Derma ///
     
    local function ShowFrame()
     
    Frame = vgui.Create("DFrame")
    Frame:SetSize( 280 , 270 )
    Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
    Frame:SetTitle("VoltageHack [V2]")
    Frame:SetVisible( true )
    Frame:ShowCloseButton( true )
    Frame.Paint = function()
            draw****undedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 255, 110 ) )
    end
    Frame:MakePopup()
     
    local BSheet = vgui.Create("DPropertySheet" , Frame)
    BSheet:SetSize( 270 , 230 )
    BSheet:SetPos( 5 , 25 )
    BSheet.Paint = function()
            draw****undedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 0, 0, 0, 190 ) )
    end
     
    local Tab = vgui.Create("DLabel")
    Tab:SetParent( BSheet )
    Tab:SetPos( 0 , 10 )
    Tab:SetText("")
     
    local Tab2 = vgui.Create("DLabel")
    Tab2:SetParent( BSheet )
    Tab2:SetPos( 0 , 10 )
    Tab2:SetText("")
     
    local Tab3 = vgui.Create("DLabel")
    Tab3:SetParent( BSheet )
    Tab3:SetPos( 0 , 10 )
    Tab3:SetText("")
     
    local Tab4 = vgui.Create("DLabel")
    Tab4:SetParent( BSheet )
    Tab4:SetPos( 0 , 10 )
    Tab4:SetText("")
     
     
    // Options
     
    local AimLabel = vgui.Create("DLabel")
    AimLabel:SetParent( Tab )
    AimLabel:SetPos( 13 , 10 )
    AimLabel:SetText("")
    AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel:SizeToContents()
     
    local AimLabel2 = vgui.Create("DLabel")
    AimLabel2:SetParent( Tab )
    AimLabel2:SetPos( 13 , 70 )
    AimLabel2:SetText("")
    AimLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel2:SizeToContents()
     
    local AimLabel3 = vgui.Create("DLabel")
    AimLabel3:SetParent( Tab )
    AimLabel3:SetPos( 206 , 10 )
    AimLabel3:SetText("")
    AimLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel3:SizeToContents()
     
    local AimLabel4 = vgui.Create("DLabel")
    AimLabel4:SetParent( Tab )
    AimLabel4:SetPos( 13 , 130  )
    AimLabel4:SetText("")
    AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel4:SizeToContents()
     
    local AimLabel5 = vgui.Create("DLabel")
    AimLabel5:SetParent( Tab )
    AimLabel5:SetPos( 118.5 , 235 )
    AimLabel5:SetText("VoltageHack [V2] Beta")
    AimLabel5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel5:SizeToContents()
     
    local Aim3 = vgui.Create( "DCheckBoxLabel")
    Aim3:SetText( "TriggerBot" )
    Aim3:SetConVar( "vh_trigger" )
    Aim3:SetParent( Tab )
    Aim3:SetPos( 10 , 30 )
    Aim3:SetValue( GetConVarNumber("vh_trigger") )
    Aim3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim3:SizeToContents()
     
    local Aim4 = vgui.Create( "DCheckBoxLabel")
    Aim4:SetText( "NoSpread" )
    Aim4:SetConVar( "vh_nospread" )
    Aim4:SetParent( Tab )
    Aim4:SetPos( 10 , 50 )
    Aim4:SetValue( GetConVarNumber("vh_nospread") )
    Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim4:SizeToContents()
     
    local Aim5 = vgui.Create( "DCheckBoxLabel")
    Aim5:SetText( "NoRecoil" )
    Aim5:SetConVar( "vh_norecoil" )
    Aim5:SetParent( Tab )
    Aim5:SetPos( 10 , 70 )
    Aim5:SetValue( GetConVarNumber("vh_norecoil") )
    Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim5:SizeToContents()
     
    local Aim6 = vgui.Create( "DCheckBoxLabel")
    Aim6:SetText( "SilentAim" )
    Aim6:SetConVar( "vh_silentaim" )
    Aim6:SetParent( Tab )
    Aim6:SetPos( 10 , 90 )
    Aim6:SetValue( GetConVarNumber( 'vh_silentaim' ) );
    Aim6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim6:SizeToContents()
     
    local EspLabel = vgui.Create("DLabel")
    EspLabel:SetParent( Tab2 )
    EspLabel:SetPos( 13 , 10 )
    EspLabel:SetText("")
    EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    EspLabel:SizeToContents()
     
    local EspLabel2 = vgui.Create("DLabel")
    EspLabel2:SetParent( Tab2 )
    EspLabel2:SetPos( 13 , 90 )
    EspLabel2:SetText("")
    EspLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    EspLabel2:SizeToContents()
     
    local EspLabel3 = vgui.Create("DLabel")
    EspLabel3:SetParent( Tab2 )
    EspLabel3:SetPos( 200 , 10 )
    EspLabel3:SetText("")
    EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    EspLabel3:SizeToContents()
     
    local Esp = vgui.Create( "DCheckBoxLabel")
    Esp:SetText( "Esp Info" )
    Esp:SetConVar( "vh_esp" )
    Esp:SetParent( Tab2 )
    Esp:SetPos( 10 , 30 )
    Esp:SetValue( GetConVarNumber("vh_esp") )
    Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp:SizeToContents()
     
    local Esp2 = vgui.Create( "DCheckBoxLabel")
    Esp2:SetText( "ESP Player Model" )
    Esp2:SetConVar( "vh_espmodel" )
    Esp2:SetParent( Tab2 )
    Esp2:SetPos( 10 , 110 )
    Esp2:SetValue( GetConVarNumber("vh_espmodel") )
    Esp2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp2:SizeToContents()
     
    local Esp3 = vgui.Create( "DCheckBoxLabel")
    Esp3:SetText( "ESP Box" )
    Esp3:SetConVar( "vh_espbox" )
    Esp3:SetParent( Tab2 )
    Esp3:SetPos( 10 , 130 )
    Esp3:SetValue( GetConVarNumber( 'vh_espbox' ) )
    Esp3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp3:SizeToContents()
     
     
    local Esp6 = vgui.Create( "DCheckBoxLabel")
    Esp6:SetText( "KeyPad Hack" )
    Esp6:SetConVar( "vh_keypdhack" )
    Esp6:SetParent( Tab2 )
    Esp6:SetPos( 10 , 70 )
    Esp6:SetValue( GetConVarNumber("vh_keypadhack") )
    Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp6:SizeToContents()
     
    local Esp4 = vgui.Create( "DCheckBoxLabel")
    Esp4:SetText( "ESP Solid" )
    Esp4:SetConVar( "vh_espsolid" )
    Esp4:SetParent( Tab2 )
    Esp4:SetPos( 10 , 90 )
    Esp4:SetValue( GetConVarNumber("vh_espsolidh") )
    Esp4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp4:SizeToContents()
     
    local Esp5 = vgui.Create( "DCheckBoxLabel")
    Esp5:SetText( "Disable Spectator List" )
    Esp5:SetConVar( "vh_spectators" )
    Esp5:SetParent( Tab2 )
    Esp5:SetPos( 10 , 50 )
    Esp5:SetValue( GetConVarNumber("vh_spectators") )
    Esp5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp5:SizeToContents()
     
     
    local MiscLabel = vgui.Create("DLabel")
    MiscLabel:SetParent( Tab3 )
    MiscLabel:SetPos( 13 , 10 )
    MiscLabel:SetText("Misc Features")
    MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    MiscLabel:SizeToContents()
     
    local MiscLabel2 = vgui.Create("DLabel")
    MiscLabel2:SetParent( Tab3 )
    MiscLabel2:SetPos( 205 , 10 )
    MiscLabel2:SetText("")
    MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    MiscLabel2:SizeToContents()
     
    local Misc = vgui.Create( "DCheckBoxLabel")
    Misc:SetText( "Bunnyhop" )
    Misc:SetConVar( "vh_bhop" )
    Misc:SetParent( Tab3 )
    Misc:SetPos( 10 , 30 )
    Misc:SetValue( GetConVarNumber("vh_bhop") )
    Misc:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Misc:SizeToContents()
     
    local Misc2 = vgui.Create( "DCheckBoxLabel")
    Misc2:SetText( "Disable Laser Sight" )
    Misc2:SetConVar( "vh_lasersight" )
    Misc2:SetParent( Tab3 )
    Misc2:SetPos( 10 , 50 )
    Misc2:SetValue( GetConVarNumber("vh_lasersight") )
    Misc2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Misc2:SizeToContents()
     
    local Misc3 = vgui.Create( "DCheckBoxLabel")
    Misc3:SetText( "Crosshair" )
    Misc3:SetConVar( "vh_crosshair" )
    Misc3:SetParent( Tab3 )
    Misc3:SetPos( 10 , 70 )
    Misc3:SetValue( GetConVarNumber("vh_crosshair") )
    Misc3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Misc3:SizeToContents()
     
    local Misc4 = vgui.Create( "DCheckBoxLabel")
    Misc4:SetText( "HitMarker" )
    Misc4:SetConVar( "vh_hitmarker" )
    Misc4:SetParent( Tab3 )
    Misc4:SetPos( 10 , 90 )
    Misc4:SetValue( GetConVarNumber("vh_hitmarker") )
    Misc4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Misc4:SizeToContents()
     
    local Misc5 = vgui.Create( "DCheckBoxLabel")
    Misc5:SetText( "ULX Anti Gag" )
    Misc5:SetConVar( "vh_antigag" )
    Misc5:SetParent( Tab3 )
    Misc5:SetPos( 10 , 110 )
    Misc5:SetValue( GetConVarNumber("vh_antigag") )
    Misc5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Misc5:SizeToContents()
     
    local Sh = vgui.Create( "DNumSlider")
    Sh:SetWide(100)
    Sh:SetText( "" )
    Sh:SetMin(0)
    Sh:SetMax(10)
    Sh:SetDecimals(1)
    Sh:SetPos( 20 , 30 )
    Sh:SetParent( Tab4 )
    Sh:SetConVar("vh_speedhack_speed")
     
    local ShLabel = vgui.Create("DLabel")
    ShLabel:SetParent( Tab4 )
    ShLabel:SetPos( 20 , 15 )
    ShLabel:SetText( "SpeedHack Speed" )
    ShLabel:SetTextColor(Color (255 , 255 , 255 , 255 ))
    ShLabel:SizeToContents()
           
    local IsisB = vgui.Create( "DButton", Tab3 )
    IsisB:SetSize( 70, 30 )
    IsisB:SetPos( 15, 300 )
    IsisB:SetText( "Website." )
    IsisB.DoClick = function()
           
    local HtmlWin = vgui.Create( "DFrame" )
    HtmlWin:SetPos( 1,1 )
    HtmlWin:SetSize( ScrW() - 25 , ScrH() - 50 )
    HtmlWin:SetTitle( "Updates/Information" )
    HtmlWin:SetVisible( true )  
    HtmlWin:SetDraggable( true )
    HtmlWin:ShowCloseButton( false )
    HtmlWin:MakePopup()
           
    local HTMLWeb = vgui.Create( "HTML", HtmlWin )
    HTMLWeb:SetSize(ScrW(), ScrH())
    HTMLWeb:SetPos( 0, 50 )
    HTMLWeb:OpenURL( "http://www.VoltageHack.*********/" )
     
    local IsisB2 = vgui.Create( "DButton", HtmlWin )
    IsisB2:SetSize( 70, 30 )
    IsisB2:SetPos( 3, 5 )
    IsisB2:SetText( "Minimize" )
    IsisB2.DoClick = function()
    HtmlWin:SetVisible(false)
            end    
    local IsisB3 = vgui.Create( "DButton")
    IsisB3:SetSize( 80,30 )
    IsisB3:SetPos( ScrW() - 85, 35 )
    IsisB3:SetText( "Hack Main Page" )
    IsisB3.DoClick = function()
    HtmlWin:SetVisible(true)
            end    
           
           
    end
     
     
    BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Aimbot" )
    BSheet:AddSheet( "ESP", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/ESP" )
    BSheet:AddSheet( "Misc", Tab3, "gui/silkicons/world", false, false, "Misc" )
    BSheet:AddSheet( "Speedhack", Tab4, "gui/silkicons/wrench", false, false, "Gotta go fast" )
    end
    concommand.Add("+Vh_Menu",ShowFrame)
    concommand.Add("-Vh_Menu",function()
    Frame:SetVisible( false )
    end)
     
    concommand.Add("Vh_Menu_Reload",function()
    ShowFrame()
    end)