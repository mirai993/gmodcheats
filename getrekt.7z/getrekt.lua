local me = LocalPlayer()
local GetRekt = {}
GetRekt.vars = {}
GetRekt.col = {}
GetRekt.key = {}
GetRekt.bind = {}
GetRekt.Players = {}

local tabselect = "Rage"
local tabselect21 = "Aim"
local tabselect22 = "Aim"
local tabselect23 = "ESP"
local tabselect33 = "ESP"
local tabselect24 = "Misc #1"
local tabselect34 = "Movement"

pcall(require, "zxcmodule")
--ded.SetAnimFix(false)

local em = FindMetaTable("Entity")
local vm = FindMetaTable("Vector")
local cm = FindMetaTable("CUserCmd")

-- FIX COLOR PICKER POS NOT ADJUSTING DEPENDING TO TEXT LENGTH
-- Binder. IsTyping(), GR:IsVisable(), ESC MENU.

-- Vars

GetRekt.vars["Aimbot"] = false
GetRekt.key["Aimbot"] = 0
GetRekt.bind["Aimbot"] = "Hold"
GetRekt.vars["Silent"] = false
GetRekt.vars["AutoShoot"] = false
GetRekt.vars["Ignores"] = {
	["friends"] = true,
	["team"] = false,
    ["bots"] = false,
    ["noclip"] = true,
    ["admins"] = false,
    ["driving"] = true,
    ["invisible"] = true,
    ["transparent"] = true
} 
GetRekt.vars["FovSize"] = 0
GetRekt.vars["NoAimRecoil"] = false
GetRekt.vars["NoAimSpread"] = false
GetRekt.vars["NoAimLag"] = false
GetRekt.vars["BulletTime"] = false
GetRekt.vars["RapidFire"] = false
GetRekt.vars["AutoWall"] = false

GetRekt.vars["AA_Pitch"] = "Off"
GetRekt.vars["AA_Yaw"] = "Off"

GetRekt.vars["TriggerBot"] = false
GetRekt.key["TriggerBot"] = 0
GetRekt.bind["TriggerBot"] = "Hold"
GetRekt.vars["TriggerBotHead"] = false
GetRekt.vars["TriggerBotChest"] = false
GetRekt.vars["TriggerBotStomach"] = false
GetRekt.vars["TriggerBotArms"] = false
GetRekt.vars["TriggerBotLegs"] = false
GetRekt.vars["TriggerBotAutoPistol"] = false
GetRekt.vars["TriggerBotIgnoreTeam"] = false
GetRekt.vars["TriggerBotJumpCheck"] = false
GetRekt.vars["NoRecoil"] = false

GetRekt.vars["KnifeBot"] = false
GetRekt.key["KnifeBot"] = 0
GetRekt.bind["KnifeBot"] = "Hold"
GetRekt.vars["KnifeBotRange"] = false

GetRekt.vars["ESP"] = true
GetRekt.key["ESP"] = 0
GetRekt.bind["ESP"] = "Always"
GetRekt.vars["Box"] = true
GetRekt.vars["BoxFill"] = false
GetRekt.vars["Name"] = true
GetRekt.vars["HealthBar"] = true
GetRekt.vars["HealthBarType"] = "Normal"
GetRekt.vars["Team"] = false
GetRekt.vars["Group"] = false
GetRekt.vars["Weapon"] = false

GetRekt.vars["Chams"] = false
GetRekt.vars["ChamsOC"] = false
GetRekt.vars["ChamsVis"] = false

GetRekt.vars["MenuColor"] = false
GetRekt.vars["Dark-Mode"] = false 

GetRekt.vars["KeyBinds"] = false
GetRekt.vars["MovementGraph"] = false
GetRekt.vars["Aspect"] = 0
GetRekt.vars["Skybox"] = "none"
GetRekt.vars["EdgeJump"] = false
GetRekt.key["EdgeJump"] = 0
GetRekt.bind["EdgeJump"] = "Hold"
GetRekt.vars["ThirdPerson"] = false
GetRekt.key["ThirdPerson"] = 0
GetRekt.bind["ThirdPerson"] = "Toggle"
GetRekt.vars["FakeLag"] = false
GetRekt.key["FakeLag"] = 0
GetRekt.bind["FakeLag"] = "Hold"
GetRekt.vars["FakeLagType"] = "Normal"
GetRekt.vars["FakeLagAmount"] = 0
GetRekt.vars["FakeType"] = false
GetRekt.vars["FakeTypeType"] = "Full"
GetRekt.vars["FakeDuck"] = false

GetRekt.vars["MirrorCam"] = false
GetRekt.vars["MirrorCamSize"] = 100
GetRekt.vars["EnemyCam"] = false
GetRekt.vars["EnemyCamSize"] = 100

GetRekt.vars["Bhop"] = false
GetRekt.vars["Strafe"] = false
GetRekt.vars["StrafeType"] = "Normal"
GetRekt.vars["FollowBot"] = false
GetRekt.key["FollowBot"] = 0
GetRekt.bind["FollowBot"] = "Hold"
GetRekt.vars["FlashSpam"] = false
GetRekt.key["FlashSpam"] = 0
GetRekt.bind["FlashSpam"] = "Hold"

GetRekt.vars["Mute"] = false
GetRekt.vars["TargetMode"] = "Neutral"

ded.ConVarSetFlags( "r_aspectratio", 4096 )

ded.SpoofConVar("net_fakelag")
ded.ConVarSetNumber("net_fakelag", "0")

local render = table.Copy(render)
local cam = table.Copy(cam)
local surface = table.Copy(surface)
local vgui = table.Copy(vgui)
local input = table.Copy(input)
local player = table.Copy(player)
local gui = table.Copy(gui)
local game = table.Copy(game)
local file = table.Copy(file)
local util = table.Copy(util)
local table = table.Copy(table)
local math = table.Copy(math)
local tick_int = engine.TickInterval()
local tickrate = tostring(math.Round(1 / tick_int))

RunConsoleCommand("cl_cmdrate", tickrate)
RunConsoleCommand("cl_updaterate", tickrate)
RunConsoleCommand("cl_interp", "0")
RunConsoleCommand("cl_interp_ratio", "0")

ded.SpoofConVar("net_fakelag")
ded.ConVarSetNumber("net_fakelag", "0")
ded.NetSetConVar("cl_interpolate", "0")
ded.NetSetConVar("cl_interp", "0")
ded.SetSequenceInterpolation(false)
ded.SetInterpolation(false)

-- Colors

GetRekt.col["MenuColor"] = "0 125 250 255"

local GrTheme = string.ToColor(GetRekt.col["MenuColor"])
local DarkTheme = string.ToColor("240, 240, 240 255")
local DarkTheme2 = string.ToColor("215 215 215 255")
local DarkTheme3 = string.ToColor("194 194 194 255")
local DarkTheme4 = string.ToColor("115 115 115 255")
local DarkTheme5 = string.ToColor("225 225 225 255")
local DarkTheme6 = string.ToColor("225 225 225 255")
local DarkTheme7 = string.ToColor("120 120 120 255")
local CheckBox = string.ToColor("")
local BlackToWhite = string.ToColor("0 0 0 255")
local WhiteToBlack = string.ToColor("255 255 255 255")

local function Colors()
	if GetRekt.vars["MenuColor"] then
		GrTheme = string.ToColor(GetRekt.col["MenuColor"])
	else
		GrTheme = string.ToColor("0 125 250 255")
	end
	if GetRekt.vars["Dark-Mode"] then
		DarkTheme = string.ToColor("70 70 70 255")
		DarkTheme2 = string.ToColor("65 65 65 255")
		DarkTheme3 = string.ToColor("40 40 40 255")
		DarkTheme4 = string.ToColor("20 20 20 255")
		DarkTheme5 = string.ToColor("70 70 70 255")
		DarkTheme6 = string.ToColor("48 48 48 255")
		DarkTheme7 = string.ToColor("100 100 100 255")
		BlackToWhite = string.ToColor("255 255 255 255")
		WhiteToBlack = string.ToColor("0 0 0 255")
	else
		DarkTheme = string.ToColor("240 240 240 255")
		DarkTheme2 = string.ToColor("215 215 215 255")
		DarkTheme3 = string.ToColor("194 194 194 255")
		DarkTheme4 = string.ToColor("40 40 40 255")
		DarkTheme5 = string.ToColor("225 225 225 255")
		DarkTheme6 = string.ToColor("216 216 216 255")
		DarkTheme7 = string.ToColor("120 120 120 255")
		BlackToWhite = string.ToColor("0 0 0 255")
		WhiteToBlack = string.ToColor("255 255 255 255")
	end
end

-- Fonts

surface.CreateFont("Title", { font = "Tahoma", size = 16, antialias = true, weight = 800})
surface.CreateFont("Text", { font = "Tahoma", size = 16, antialias = true, weight = 300})
surface.CreateFont("Feature", { font = "Tahoma", size = 14, antialias = true, weight = 200})

-- Gradients

local function GradV(x, y, w, h, r1, g1, b1, o1, r2, g2, b2, o2)
	for i = 0, h, 1 do
		surface.SetDrawColor(r1 + i*((r2-r1)/h), g1 + i*((g2-g1)/h), b1 + i*((b2-b1)/h), o1 + i*((o2-o1)/h))
		surface.DrawRect(x, y+i, w, 1)
	end
end

local function Gradient(x, y, w, h, r1, g1, b1, t1, r2, g2, b2, t2)
	for i = 0, w, 1 do
		surface.SetDrawColor(r1 + i*((r2-r1)/w), g1 + i*((g2-g1)/w), b1 + i*((b2-b1)/w), t1 + i*((t2-t1)/w))
		surface.DrawRect(x+i, y, 1, h)
	end
end

-- Menu

local GR = vgui.Create("DFrame")
GR:SetSize(690, 500)
GR:Center()
GR:SetTitle("")
GR:SetDraggable(true)
GR:ShowCloseButton(false)
GR:MakePopup()
GR.Paint = function(self, w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 150))
	GradV(0, 40, w, h-465, 70, 70, 70, 255, 48, 48, 48, 255)
	GradV(0, 75, w, h-75, DarkTheme.r, DarkTheme.g, DarkTheme.b, 255, DarkTheme2.r, DarkTheme2.g, DarkTheme2.b, 255)
	draw.RoundedBox(0, 5, 80, w-10, h-85, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
	surface.SetDrawColor( DarkTheme4.r, DarkTheme4.g, DarkTheme4.b, 255 )
	surface.DrawOutlinedRect( 5, 80, w-10, h-85, 1 )
	if tabselect == "Visuals" then
		GradV(30, 95, 632.5, h-465, DarkTheme5.r, DarkTheme5.g, DarkTheme5.b, 255, DarkTheme6.r, DarkTheme6.g, DarkTheme6.b, 255)
		draw.RoundedBox(0, 30, 145, 300, 325, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		draw.RoundedBox(0, 360, 145, 300, 325, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		if tabselect23 == "ESP" then
			GradV(30, 145, 300, 36, 70, 70, 70, 255, 48, 48, 48, 255)
		end
	elseif tabselect == "Rage" then
		GradV(30, 95, 632.5, h-465, DarkTheme5.r, DarkTheme5.g, DarkTheme5.b, 255, DarkTheme6.r, DarkTheme6.g, DarkTheme6.b, 255)
		draw.RoundedBox(0, 30, 145, 300, 325, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		draw.RoundedBox(0, 360, 145, 300, 325, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))	
	elseif tabselect == "PlayerList" then
		draw.RoundedBox(0, 30, 115, 632.5, 355, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
	else
		draw.RoundedBox(0, 30, 105, 300, 365, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		draw.RoundedBox(0, 360, 105, 300, 365, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		GradV(30, 105, 300, 36, 70, 70, 70, 255, 48, 48, 48, 255)
		GradV(360, 105, 300, 36, 70, 70, 70, 255, 48, 48, 48, 255)
	end
	draw.SimpleText("GetRekt", "Title", w/2, 11, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	draw.SimpleText("Welcome, " .. GetConVar("name"):GetString() .. ".", "Title", 48, 11, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	draw.SimpleText(os.date( "%H:%M:%S" , os.time() ), "Title", w-10, 11, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
end

local function Section(x, y, lbl, par)
	GRLabel = vgui.Create("DPanel", par)
	GRLabel:SetSize(270, 16)
	GRLabel:SetPos(x, y)
	GRLabel:SetVisible(true)
	GRLabel.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, h/2, w, 1, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		draw.RoundedBox(0, 25, 0, language.GetPhrase(surface.GetTextSize(lbl)) + 20, h, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
		draw.DrawText(lbl, "Title", 30, 0, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local ToggleBinds = {}

local function CheckBox(text, parent, x, y, var, col, bind)
	local GRCheckbox = vgui.Create( "DCheckBoxLabel", parent)
	GRCheckbox:SetPos( x, y )
	GRCheckbox:SetFont("Feature")
	GRCheckbox:SetText(text)
	GRCheckbox:SetValue( GetRekt.vars[var] )
	GRCheckbox:SizeToContents()
	function GRCheckbox.Button:Paint(w, h)
		if GetRekt.vars[var] then
			draw.RoundedBox(0, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			if self:IsHovered() then
				GradV(0, -h+2, w, h*2, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
			end
			draw.RoundedBox(0, 2, 2, w-4, h-4, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 1, 1, w-2, h-2, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			if self:IsHovered() then
				GradV(0, -h+2, w, h*2, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
			end
		end
		GRCheckbox:SetTextColor(BlackToWhite)
	end	
	function GRCheckbox:OnChange(GRval)
		GetRekt.vars[var] = GRval
	end
	
	if col then
		local cx, cy = GRCheckbox:GetPos()
		local colorPicker = vgui.Create("DButton", parent)
		colorPicker:SetSize(24, 10)
		colorPicker:SetText("")
		colorPicker:SetPos(cx + GRCheckbox:GetWide() + 165, y + 3)
		function colorPicker:Paint(w, h)
			local VarColor = string.ToColor(GetRekt.col[var])
			draw.RoundedBox(0, 0, 0, w, h, color_black)	
			draw.RoundedBox(0, 1, 1, w-2, h-2, Color(VarColor.r, VarColor.g, VarColor.b, VarColor.a))
		end
		
		function colorPicker:DoClick()
			if IsValid(colorWindow) then
				colorWindow:Remove()
			end
			colorWindow = vgui.Create("DFrame", cmd)
			colorWindow:SetSize(300, 225)
			colorWindow:SetTitle("")
			colorWindow:ShowCloseButton(false)
			colorWindow:RequestFocus()
			function colorWindow:Paint(w, h)
				draw.RoundedBox(0, 0, 0, w, h, color_black)	
				draw.RoundedBox(0, 1, 1, w-2, h-2, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			end	
			local frameX, frameY = colorPicker:GetPos()
			local GRframeX, GRframeY = GR:GetPos()
			if (frameX + GRframeX) + 20 > ScrW() or (frameY + GRframeY) + 70 > ScrH() then
				colorWindow:Center()
			else
				local mousex, mousey = gui.MousePos()
				colorWindow:SetPos(mousex, mousey)
			end
		
			colorWindow:MakePopup()
			
			local colorSelector = vgui.Create("DColorMixer", colorWindow)
			colorSelector:SetPos(5, 5)
			colorSelector:SetSize(290, 215)
			colorSelector:SetPalette(false)
			colorSelector:SetColor(string.ToColor(GetRekt.col[var]))
			function colorSelector:ValueChanged(val)
				local r = tostring(val.r)
				local g = tostring(val.g)
				local b = tostring(val.b)
				local a = tostring(val.a)
				local col = r.." "..g.." "..b.." "..a
				GetRekt.col[var] = col
			end
		end
		timer.Create("CheckFrameFocus", 0.5, 0, function()
			if IsValid(colorWindow) and IsValid(GR) and GR:HasFocus() then
				colorWindow:Remove()
			end
		end)
	end

	if bind then
		local keyBind = vgui.Create("DBinder", parent)
		keyBind:SetValue(GetRekt.key[var])
		keyBind:SetSize(surface.GetTextSize("[key not set]") + 10, 16)
		function keyBind:Paint(w, h)
			local bindText = input.GetKeyName(GetRekt.key[var])
			if GetRekt.bind[var] != "Always" then
				if input.IsKeyTrapping() && self.Trapping then
					bindText = "[...]"
				elseif GetRekt.key[var] ~= 0 then
					bindText = "[" .. language.GetPhrase(input.GetKeyName(GetRekt.key[var])) .. "]"
				else
					bindText = "[key not set]"
				end
			else
				bindText = "[always]"
			end
			draw.SimpleText(bindText, "Feature", w/2, h/2, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			--keyBind:SetPos(language.GetPhrase(surface.GetTextSize(text)) + language.GetPhrase(surface.GetTextSize("[key not set]")) - 10, y)
			if GetRekt.bind[var] != "Always" then
				if input.IsKeyTrapping() && self.Trapping then
					keyBind:SetPos(language.GetPhrase(surface.GetTextSize(text)) + x + language.GetPhrase(surface.GetTextSize("[...]")), y)
					keyBind:SetSize(surface.GetTextSize("[...]") + 20, 16)
				elseif GetRekt.key[var] ~= 0 then
					keyBind:SetPos(language.GetPhrase(surface.GetTextSize(text)) + x + 30, y)
					keyBind:SetSize(language.GetPhrase(surface.GetTextSize("[" .. input.GetKeyName(GetRekt.key[var]) .. "]")) + 5, 16)
				else
					keyBind:SetPos(language.GetPhrase(surface.GetTextSize(text)) + language.GetPhrase(surface.GetTextSize("[key not set]")) - 10, y)
					keyBind:SetSize(language.GetPhrase(surface.GetTextSize("[key not set]")) + 20, 16)
				end
			else
				keyBind:SetPos(language.GetPhrase(surface.GetTextSize(text)) + language.GetPhrase(surface.GetTextSize("[always]")) + 18, y)
				keyBind:SetSize(language.GetPhrase(surface.GetTextSize("[always]")) + 20, 16)
			end
		end
		function keyBind:Think()
			keyBind:SetText("")

			if input.IsKeyTrapping() && self.Trapping then
				local code = input.CheckKeyTrapping()
				if code then
					if code == KEY_ESCAPE then
						self:SetValue(0)
					else
						self:SetValue(code)
					end
					
					self.Trapping = false
				end
			end
		end
		keyBind.OnChange = function()
			GetRekt.key[var] = keyBind:GetValue()
			if GetRekt.bind[var] != "Always" then
				if GetRekt.key[var] != 0 then
					keyBind:SetSize(surface.GetTextSize(input.GetKeyName(GetRekt.key[var])) + 10, 16)
				else
					keyBind:SetSize(75, 16)
				end
			else
				keyBind:SetSize(65, 16)
			end
		end
	
		local toggle = {}
		local key_pressed = {}
		
		for i, _ in pairs(GetRekt.bind) do
			table.insert(ToggleBinds, false)
			table.insert(toggle, false)
			table.insert(key_pressed, false)
		end
		
		--Table
		
		local function toggleValue(index)
			toggle[index] = not toggle[index]
		end
			
		hook.Add("Think", "asdassa", function()
			for i, _ in pairs(GetRekt.bind) do
				if GetRekt.bind[i] == "Always" then
					ToggleBinds[i] = true
				elseif GetRekt.bind[i] == "Toggle" then
					if (GetRekt.key[i] != 0 && ((GetRekt.key[i] >= 107 && GetRekt.key[i] <= 113) && input.IsMouseDown(GetRekt.key[i])) || input.IsKeyDown(GetRekt.key[i])) then
						if not key_pressed[i] then
							key_pressed[i] = true
							toggleValue(i)
						end
					else
						key_pressed[i] = false
					end
					if toggle[i] then
						ToggleBinds[i] = true
					else
						ToggleBinds[i] = false
					end
				elseif GetRekt.bind[i] == "Hold" then
					if ( GetRekt.key[i] != 0 && ( ( GetRekt.key[i] >= 107 && GetRekt.key[i] <= 113 ) && input.IsMouseDown(GetRekt.key[i]) ) || input.IsKeyDown(GetRekt.key[i]) ) then
						ToggleBinds[i] = true
					else
						ToggleBinds[i] = false
					end
				end
			end
		end)

		keyBind.DoRightClick = function()
			if IsValid(bindWindow) then
				bindWindow:Remove()
			end
			bindWindow = vgui.Create("DFrame", cmd)
			bindWindow:SetSize(60, 60)
			bindWindow:SetTitle("")
			bindWindow:ShowCloseButton(false)
			bindWindow:RequestFocus()
			function bindWindow:Paint(w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b))	
				draw.RoundedBox(0, 1, 1, w-2, h-2, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			end
			local function CreatebindButton(x, y, text)
				local bindButton = vgui.Create("DButton", bindWindow)
				bindButton:SetSize(60, 20)
				bindButton:SetPos(x, y)
				bindButton:SetText(text)
				function bindButton:DoClick()
					GetRekt.bind[var] = bindButton:GetText(text)
					bindWindow:Remove()
				end
				function bindButton:Paint(w, h)
					bindButton:SetTextColor(BlackToWhite)
					draw.RoundedBox(0, 0, 0, w, h, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b))	
					draw.RoundedBox(0, 1, 1, w-2, h-2, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
					if bindButton:IsHovered() then
						draw.RoundedBox(0, 1, 1, 58, 18, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
					end
					if text == "Hold" and GetRekt.bind[var] == "Hold" then
						draw.RoundedBox(0, 1, 1, 58, 18, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
					end
					if text == "Toggle" and GetRekt.bind[var] == "Toggle" then
						draw.RoundedBox(0, 1, 1, 58, 18, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
					end
					if text == "Always" and GetRekt.bind[var] == "Always" then
						draw.RoundedBox(0, 1, 1, 58, 18, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
					end
				end
			end
			CreatebindButton(0, 0, "Hold")
			CreatebindButton(0, 20, "Toggle")
			CreatebindButton(0, 40, "Always")
			local frameX, frameY = keyBind:GetPos()
			local GRframeX, GRframeY = GR:GetPos()
			if (frameX + GRframeX) + 20 > ScrW() or (frameY + GRframeY) + 70 > ScrH() then
				bindWindow:Center()
			else
				local mousex, mousey = gui.MousePos()
				bindWindow:SetPos(mousex, mousey)
			end
			bindWindow:MakePopup()
			timer.Create("CheckBindFrameFocus", 0.5, 0, function()
				if IsValid(bindWindow) and IsValid(GR) and GR:HasFocus() then
					bindWindow:Remove()
				end
			end)
		end
	end
end

local function CreateButton(lbl, w, h, x, y, fnc, par)
    local button = vgui.Create("DButton", par)
    button:SetSize(w, h)
    button:SetPos(x, y)
    button:SetText(lbl)
    button:SetTextColor(BlackToWhite)
    function button:DoClick()
        fnc()
    end
	function button:Paint(w, h)
		draw.RoundedBox(4, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
		button:SetTextColor(BlackToWhite)
	end
end

local function CheckBoxButton(text, parent, x, y, var)
	local GRCheckboxButton = vgui.Create("DButton", parent)
	GRCheckboxButton:SetPos(x, y)
	GRCheckboxButton:SetFont("Feature")
	GRCheckboxButton:SetText(text)
	GRCheckboxButton:SetSize(120, 22)
	GRCheckboxButton:SetTextColor(Color(255, 255, 255))
	GRCheckboxButton:SetTextInset(25, 0)
	function GRCheckboxButton:Paint(w, h)
		if GetRekt.vars[var] then
			if self:IsHovered() then
				GradV(0, -h+2, w, h*2, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
			end
			GradV(0, -h+2, w, h*2, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
		else
			draw.RoundedBox(0, 1, 1, w-2, h-2, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			if self:IsHovered() then
				GradV(0, -h+2, w, h*2, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
			end
		end
		GRCheckboxButton:SetTextColor(BlackToWhite)
	end
	function GRCheckboxButton:DoClick()
		GetRekt.vars[var] = not GetRekt.vars[var]
	end
end

local function CreateSlider(lbl, x, y, var, min, max, dec, par)
	
	local sliderLabel = vgui.Create("DLabel", par)
	sliderLabel:SetText(lbl)
	sliderLabel:SetColor(color_black)
	local w, h = sliderLabel:GetTextSize()
	sliderLabel:SetWide(w)
	sliderLabel:SetPos(x+170, y - h / 2 + 12.5)
	function sliderLabel:Paint(w, h)
		sliderLabel:SetTextColor(BlackToWhite)
	end
	
	local slider = vgui.Create("DNumSlider", par)
	slider:SetWide(280)
	slider:SetPos(x - 115, y)
	slider:SetMin(min)
	slider:SetMax(max)
	slider:SetDefaultValue(GetRekt.vars[var])
	slider:ResetToDefaultValue()
	slider.Scratch:Hide()
	slider.TextArea:Hide()
	slider.Slider:SetNotches(0)
	slider.Slider:SetNotchColor(Color(0,0,0,0))
	function slider:OnValueChanged(val)
		slider:SetValue(math.Round(val, dec))
		GetRekt.vars[var] = slider:GetValue()
	end
	function slider:Paint(w, h)
		draw.RoundedBox(2, 115, 6, w-110, h-12, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
		if self:IsHovered() or slider.Slider.Knob:IsHovered() then
			GradV(115, 6, w-110, h-12, WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255, GrTheme.r, GrTheme.g, GrTheme.b, 255)
		end
		draw.SimpleText(slider:GetValue(), "Feature", w-85, h/2, BlackToWhite, TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
	end
	slider.Slider.Paint = function(self,w,h)
	end
	slider.Slider.Knob:SetSize(12,15)	
	slider.Slider.Knob.Paint = function(self,w,h)
		draw.RoundedBox(5, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	end
end

local function ComboBox( Parent, PosX, PosY, Width, Height, Choices, var)
	local GRdropdown = vgui.Create("DComboBox", Parent)
	GRdropdown:SetText("")
	GRdropdown:SetSize(Width, Height)
	GRdropdown:SetPos(PosX, PosY)
	GRdropdown:SetValue(GetRekt.vars[var])
	local selected_index = 1
	for k, v in ipairs(Choices) do
		GRdropdown:AddChoice(v)
	end
	GRdropdown:SetSortItems(false)
	function GRdropdown:OnSelect(index, value, data)
		GetRekt.vars[var] = value
		selected_index = index
	end
	GRdropdown.Paint = function(self,w,h)
		draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
		draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
		draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		if self:IsHovered() then
			draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
			draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
			draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		end
	end
	DMenuOption.Paint = function(self, w, h, index, value, data)
		draw.RoundedBox(2, 0, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
		self:SetTextColor(BlackToWhite)
		if self:IsHovered() then
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		end
		if self:IsSelected() == GetRekt.vars[var] then
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))	
		end
	end
	GRdropdown.DropButton.Paint = function() end
	GRdropdown.PerformLayout = function(self)
		self:SetTextColor(BlackToWhite)
		self:SetFont("Feature")
	end
end

local function MultiComboBox(text, parent, x, y, opts, var)
	local panel = vgui.Create("DPanel", parent)
	panel:SetSize(165, 20)
	panel:SetPos(x, y)
	function panel:Paint(w, h) end

	local button = vgui.Create("DButton", panel)
	button:SetSize(165, 20)
	button:SetText("")
	function button:Paint(w, h)
		local selected = ""
		for i, option in ipairs(opts) do
			if GetRekt.vars[var][option] then
				selected = selected .. option .. ", "
			end
		end
		if selected == "" then
			selected = "none"
		else
			selected = selected:sub(1, -3)
		end
		
		draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
		draw.SimpleText(selected, "Feature", selected == "none" && w / 2 or 4, h / 2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255), selected == "none" && TEXT_ALIGN_CENTER or TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
		draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		if self:IsHovered() then
			draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
			draw.SimpleText(selected, "Feature", selected == "none" && w / 2 or 4, h / 2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255), selected == "none" && TEXT_ALIGN_CENTER or TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
			draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		end
	end

	local holder = vgui.Create("DPanel", panel)
	holder:SetSize(165, #opts * 20)
	holder:SetPos(0, 20)
	holder:SetVisible(false)
	for i, option in ipairs(opts) do
		local opt = vgui.Create("DButton", holder)
		opt:SetSize(165, 20)
		opt:SetPos(0, (i - 1) * 20)
		opt:SetText("")
		function opt:Paint(w, h)
			draw.RoundedBox(2, 0, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.g, WhiteToBlack.b, 255))
			draw.SimpleText(option, "Feature", w / 2, h / 2, GetRekt.vars[var][option] && Color(GrTheme.r, GrTheme.g, GrTheme.b, 255) or Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
			if self:IsHovered() then
				draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
				draw.SimpleText(option, "Feature", w / 2, h / 2, GetRekt.vars[var][option] && Color(GrTheme.r, GrTheme.g, GrTheme.b, 255) or Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		function opt:DoClick()
			GetRekt.vars[var][option] = !GetRekt.vars[var][option]
		end
	end

	function button:DoClick()
		if holder:IsVisible() then
			holder:SetVisible(false)
			panel:SetTall(20)
		else
			holder:SetVisible(true)
			panel:SetTall(#opts * 20 + 20)
		end
	end

	local label = vgui.Create("DLabel", parent)
	label:SetPos(x + 170, y)
	label:SetText("  " .. text .. "  ")
	label:SetFont("Feature")
	label:SetTextColor(Color(0, 0, 0, 0))
	label:SizeToContents()
	function label:Paint(w, h)
		draw.SimpleText(" ".. text, "Feature", 0, h / 2 + 1, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local html = vgui.Create("DHTML")
html:SetPos(ScrW() - 45, 15)
html:SetSize(30, 30)
html:SetHTML([[
	<html>
		<head>
			<style>
				body {
					background-image: url("https://getrekt.io/img/logo.png");
					background-size: contain;
					background-repeat: no-repeat;
				}
			</style>
		</head>
		<body>
		</body>
	</html>
]])


local Avatar = vgui.Create( "AvatarImage", GR )
Avatar:SetSize( 32, 32 )
Avatar:SetPos( 6, 4 )
Avatar:SetPlayer( LocalPlayer(), 64 )

local alerts = {}

function ShowPopAlert(Title, message)
	local nextY = ScrH() - 75
	
	local frame = vgui.Create("DFrame")
	frame:SetPos(ScrW() - 400, ScrH() + 75) -- Start off-screen
	frame:SetSize(400, 50)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:SetSizable(false)
	frame:NoClipping(true)
	function frame:Paint(w, h)
		draw.RoundedBox(3, 0, 0, w, h, Color(33, 33, 33, 220))
	end
	
	local html = vgui.Create("DHTML", frame)
	html:SetPos(5, 5)
	html:SetSize(40, 40)
	html:SetHTML([[
		<html>
			<head>
				<style>
					body {
						background-image: url("https://images.emojiterra.com/twitter/v13.1/512px/26a0.png");
						background-size: contain;
						background-repeat: no-repeat;
					}
				</style>
			</head>
			<body>
			</body>
		</html>
	]])
	
	local label = vgui.Create("DLabel", frame)
	label:SetPos(60, 0)
	label:SetSize(340, 25)
	label:SetWrap(true)
	label:SetText(Title)
	label:SetFont("Title")
	
	local label2 = vgui.Create("DLabel", frame)
	label2:SetPos(60, 0)
	label2:SetSize(340, 65)
	label2:SetWrap(true)
	label2:SetText(message)
	label2:SetFont("Text")
	
	local bottom_line = vgui.Create("DPanel", frame)
	bottom_line:SetPos(0, 49)
	bottom_line:SetSize(0, 1)
	bottom_line:SetBackgroundColor(Color(255, 205, 80))

	for i, alert in ipairs(alerts) do
		if IsValid(alert) then
			nextY = math.min(nextY, alert:GetPos()) - 60
		end
	end
	
	frame:MoveTo(ScrW() - 400, nextY, 0.3, 0, -1, function() end) -- Animate the alert sliding in
	
	bottom_line:SizeTo(400, 1, 5, 0, -1, function()
		frame:MoveTo(ScrW() + 400, nextY, 0.3, 0, -1, function()
			frame:Close()
			for i, alert in ipairs(alerts) do
				if alert == frame then
					table.remove(alerts, i)
				break
				end
			end
		end) -- Animate the alert sliding out
	end)
	table.insert(alerts, frame)
end

local panel1 = vgui.Create("DPanel", GR)
panel1:Dock(FILL)
panel1.Paint = function() end
panel1:SetVisible(tabselect == "Rage")
local panel2 = vgui.Create("DPanel", GR)
panel2:Dock(FILL)
panel2.Paint = function() end
panel2:SetVisible(tabselect == "Legit")
local panel3 = vgui.Create("DPanel", GR)
panel3:Dock(FILL)
panel3.Paint = function() end
panel3:SetVisible(tabselect == "Visuals")
local panel4 = vgui.Create("DPanel", GR)
panel4:Dock(FILL)
panel4.Paint = function() end
panel4:SetVisible(tabselect == "Misc")
local panel5 = vgui.Create("DPanel", GR)
panel5:Dock(FILL)
panel5.Paint = function() end
panel5:SetVisible(tabselect == "PlayerList")
local panel6 = vgui.Create("DPanel", GR)
panel6:Dock(FILL)
panel6.Paint = function() end
panel6:SetVisible(tabselect == "Config")

local RageTab = vgui.Create("DButton", GR)
RageTab:SetFont("Text")
RageTab:SetText("RAGE")
RageTab:SetTextColor(Color(180,180,180))
RageTab:SetSize(115, 35)
RageTab:SetPos(0, 40)
function RageTab:DoClick()
	tabselect = "Rage"
	panel1:SetVisible(true)
	panel2:SetVisible(false)
	panel3:SetVisible(false)
	panel4:SetVisible(false)
	panel5:SetVisible(false)
	panel6:SetVisible(false)
end

function RageTab:Paint(w, h)
	if tabselect == "Rage" then
		RageTab:SetTextColor(GrTheme)
	else
		RageTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local LegTab = vgui.Create("DButton", GR)
LegTab:SetFont("Text")
LegTab:SetText("LEGIT")
LegTab:SetTextColor(Color(255,255,255))
LegTab:SetSize(115, 35)
LegTab:SetPos(115, 40)
function LegTab:DoClick()
	tabselect = "Legit"
	panel1:SetVisible(false)
	panel2:SetVisible(true)
	panel3:SetVisible(false)
	panel4:SetVisible(false)
	panel5:SetVisible(false)
	panel6:SetVisible(false)
end

function LegTab:Paint(w, h)
	if tabselect == "Legit" then
		LegTab:SetTextColor(GrTheme)
	else
		LegTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local VisTab = vgui.Create("DButton", GR)
VisTab:SetFont("Text")
VisTab:SetText("VISUALS")
VisTab:SetTextColor(Color(180,180,180))
VisTab:SetSize(115, 35)
VisTab:SetPos(230, 40)
function VisTab:DoClick()
	tabselect = "Visuals" 
	panel1:SetVisible(false)
	panel2:SetVisible(false)
	panel3:SetVisible(true)
	panel4:SetVisible(false)
	panel5:SetVisible(false)
	panel6:SetVisible(false)
end

function VisTab:Paint(w, h)
	if tabselect == "Visuals" then
		VisTab:SetTextColor(GrTheme)
	else
		VisTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local MiscTab = vgui.Create("DButton", GR)
MiscTab:SetFont("Text")
MiscTab:SetText("MISC")
MiscTab:SetTextColor(Color(180,180,180))
MiscTab:SetSize(115, 35)
MiscTab:SetPos(345, 40)
function MiscTab:DoClick()
	tabselect = "Misc"
	panel1:SetVisible(false)
	panel2:SetVisible(false)
	panel3:SetVisible(false)
	panel4:SetVisible(true)
	panel5:SetVisible(false)
	panel6:SetVisible(false)
end

function MiscTab:Paint(w, h)
	if tabselect == "Misc" then
		MiscTab:SetTextColor(GrTheme)
	else
		MiscTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local PlayerTab = vgui.Create("DButton", GR)
PlayerTab:SetFont("Text")
PlayerTab:SetText("PLAYER LIST")
PlayerTab:SetTextColor(Color(180,180,180))
PlayerTab:SetSize(115, 35)
PlayerTab:SetPos(460, 40)
function PlayerTab:DoClick()
	tabselect = "PlayerList"
	panel1:SetVisible(false)
	panel2:SetVisible(false)
	panel3:SetVisible(false)
	panel4:SetVisible(false)
	panel5:SetVisible(true)
	panel6:SetVisible(false)
	UpdatePlayerList()
end

function PlayerTab:Paint(w, h)
	if tabselect == "PlayerList" then
		PlayerTab:SetTextColor(GrTheme)
	else
		PlayerTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local CfgTab = vgui.Create("DButton", GR)
CfgTab:SetFont("Text")
CfgTab:SetText("CONFIG")
CfgTab:SetTextColor(Color(180,180,180))
CfgTab:SetSize(115, 35)
CfgTab:SetPos(575, 40)
function CfgTab:DoClick()
	tabselect = "Config"
	panel1:SetVisible(false)
	panel2:SetVisible(false)
	panel3:SetVisible(false)
	panel4:SetVisible(false)
	panel5:SetVisible(false)
	panel6:SetVisible(true)
end

function CfgTab:Paint(w, h)
	if tabselect == "Config" then
		CfgTab:SetTextColor(GrTheme)
	else
		CfgTab:SetTextColor(Color(255, 255, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
	end
end

local RageTab2 = vgui.Create("DButton", GR)
RageTab2:SetFont("Text")
RageTab2:SetText("AIM")
RageTab2:SetTextColor(Color(180,180,180))
RageTab2:SetSize(316.25, 36)
RageTab2:SetPos(30, 95)
function RageTab2:DoClick()
	tabselect21 = "Aim"
	panel11:SetVisible(true)
	panel12:SetVisible(false)
end
function RageTab2:Paint(w, h)
	if tabselect21 == "Aim" then
		RageTab2:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		if GetRekt.vars["Dark-Mode"] then
			RageTab2:SetTextColor(Color(150, 150, 150, 255))
		else
			RageTab2:SetTextColor(Color(170, 170, 170, 255))
		end
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		if GetRekt.vars["Dark-Mode"] then
			GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		else
			GradV(0, 0, w, h, 248, 248, 248, 255, 240, 240, 240, 255)
		end
		if tabselect21 == "Aim" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local RageTab3 = vgui.Create("DButton", GR)
RageTab3:SetFont("Text")
RageTab3:SetText("ANTI-AIM")
RageTab3:SetTextColor(Color(180,180,180))
RageTab3:SetSize(316.25, 36)
RageTab3:SetPos(346.25, 95)
function RageTab3:DoClick()
	tabselect21 = "Anti-Aim"
	panel11:SetVisible(false)
	panel12:SetVisible(true)
end
function RageTab3:Paint(w, h)
	if tabselect21 == "Anti-Aim" then
		RageTab3:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		if GetRekt.vars["Dark-Mode"] then
			RageTab3:SetTextColor(Color(150, 150, 150, 255))
		else
			RageTab3:SetTextColor(Color(170, 170, 170, 255))
		end
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		if GetRekt.vars["Dark-Mode"] then
			GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		else
			GradV(0, 0, w, h, 248, 248, 248, 255, 240, 240, 240, 255)
		end
		if tabselect21 == "Anti-Aim" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local LegTab2 = vgui.Create("DButton", GR)
LegTab2:SetFont("Text")
LegTab2:SetText("Aim")
LegTab2:SetTextColor(Color(180,180,180))
LegTab2:SetSize(100, 37)
LegTab2:SetPos(30, 105)
function LegTab2:DoClick()
	tabselect22 = "Aim"
	panel21:SetVisible(true)
	panel22:SetVisible(false)
	panel23:SetVisible(false)
end
function LegTab2:Paint(w, h)
	if tabselect22 == "Aim" then
		LegTab2:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		LegTab2:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect22 == "Aim" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local LegTab3 = vgui.Create("DButton", GR)
LegTab3:SetFont("Text")
LegTab3:SetText("Triggerbot")
LegTab3:SetTextColor(Color(180,180,180))
LegTab3:SetSize(100, 37)
LegTab3:SetPos(130, 105)
function LegTab3:DoClick()
	tabselect22 = "Triggerbot"
	panel21:SetVisible(false)
	panel22:SetVisible(true)
	panel23:SetVisible(false)
end
function LegTab3:Paint(w, h)
	if tabselect22 == "Triggerbot" then
		LegTab3:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		LegTab3:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect22 == "Triggerbot" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local LegTab4 = vgui.Create("DButton", GR)
LegTab4:SetFont("Text")
LegTab4:SetText("KnifeBot")
LegTab4:SetTextColor(Color(180,180,180))
LegTab4:SetSize(100, 37)
LegTab4:SetPos(230, 105)
function LegTab4:DoClick()
	tabselect22 = "KnifeBot"
	panel21:SetVisible(false)
	panel22:SetVisible(false)
	panel23:SetVisible(true)
end
function LegTab4:Paint(w, h)
	if tabselect22 == "KnifeBot" then
		LegTab4:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		LegTab4:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect22 == "KnifeBot" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local VisTab2 = vgui.Create("DButton", GR)
VisTab2:SetFont("Text")
VisTab2:SetText("ESP")
VisTab2:SetTextColor(Color(180,180,180))
VisTab2:SetSize(316.25, 36)
VisTab2:SetPos(30, 95)
function VisTab2:DoClick()
	tabselect23 = "ESP"
	panel31:SetVisible(true)
	panel32:SetVisible(false)
end

function VisTab2:Paint(w, h)
	if tabselect23 == "ESP" then
		VisTab2:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		if GetRekt.vars["Dark-Mode"] then
			VisTab2:SetTextColor(Color(150, 150, 150, 255))
		else
			VisTab2:SetTextColor(Color(170, 170, 170, 255))
		end
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		if GetRekt.vars["Dark-Mode"] then
			GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		else
			GradV(0, 0, w, h, 248, 248, 248, 255, 240, 240, 240, 255)
		end
		if tabselect23 == "ESP" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local VisTab3 = vgui.Create("DButton", GR)
VisTab3:SetFont("Text")
VisTab3:SetText("Other")
VisTab3:SetTextColor(Color(180,180,180))
VisTab3:SetSize(316.25, 36)
VisTab3:SetPos(346.25, 95)
function VisTab3:DoClick()
	tabselect23 = "Other"
	panel31:SetVisible(false)
	panel32:SetVisible(true)
end

function VisTab3:Paint(w, h)
	if tabselect23 == "Other" then
		VisTab3:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		if GetRekt.vars["Dark-Mode"] then
			VisTab3:SetTextColor(Color(150, 150, 150, 255))
		else
			VisTab3:SetTextColor(Color(170, 170, 170, 255))
		end
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		if GetRekt.vars["Dark-Mode"] then
			GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		else
			GradV(0, 0, w, h, 248, 248, 248, 255, 240, 240, 240, 255)
		end
		if tabselect23 == "Other" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local VisTab4 = vgui.Create("DButton", GR)
VisTab4:SetFont("Text")
VisTab4:SetText("ESP")
VisTab4:SetTextColor(Color(180,180,180))
VisTab4:SetSize(100, 37)
VisTab4:SetPos(30, 145)
function VisTab4:DoClick()
	tabselect33 = "ESP"
	panel33:SetVisible(true)
	panel34:SetVisible(false)
	panel35:SetVisible(false)
end

function VisTab4:Paint(w, h)
	if tabselect33 == "ESP" then
		VisTab4:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		VisTab4:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect33 == "ESP" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local VisTab5 = vgui.Create("DButton", GR)
VisTab5:SetFont("Text")
VisTab5:SetText("Glow")
VisTab5:SetTextColor(Color(180,180,180))
VisTab5:SetSize(100, 37)
VisTab5:SetPos(230, 145)
function VisTab5:DoClick()
	tabselect33 = "Glow"
	panel33:SetVisible(false)
	panel34:SetVisible(true)
	panel35:SetVisible(false)
end

function VisTab5:Paint(w, h)
	if tabselect33 == "Glow" then
		VisTab5:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		VisTab5:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect33 == "Glow" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local VisTab6 = vgui.Create("DButton", GR)
VisTab6:SetFont("Text")
VisTab6:SetText("Chams")
VisTab6:SetTextColor(Color(180,180,180))
VisTab6:SetSize(100, 37)
VisTab6:SetPos(130, 145)
function VisTab6:DoClick()
	tabselect33 = "Chams"
	panel33:SetVisible(false)
	panel34:SetVisible(false)
	panel35:SetVisible(true)
end

function VisTab6:Paint(w, h)
	if tabselect33 == "Chams" then
		VisTab6:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		VisTab6:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect33 == "Chams" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab2 = vgui.Create("DButton", GR)
MiscTab2:SetFont("Text")
MiscTab2:SetText("Misc #1")
MiscTab2:SetTextColor(Color(180,180,180))
MiscTab2:SetSize(100, 37)
MiscTab2:SetPos(30, 105)
function MiscTab2:DoClick()
	tabselect24 = "Misc #1"
	panel41:SetVisible(true)
	panel42:SetVisible(false)
	panel43:SetVisible(false)
end

function MiscTab2:Paint(w, h)
	if tabselect24 == "Misc #1" then
		MiscTab2:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab2:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect24 == "Misc #1" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab3 = vgui.Create("DButton", GR)
MiscTab3:SetFont("Text")
MiscTab3:SetText("Misc #2")
MiscTab3:SetTextColor(Color(180,180,180))
MiscTab3:SetSize(100, 37)
MiscTab3:SetPos(130, 105)
function MiscTab3:DoClick()
	tabselect24 = "Misc #2"
	panel41:SetVisible(false)
	panel42:SetVisible(true)
	panel43:SetVisible(false)
end

function MiscTab3:Paint(w, h)
	if tabselect24 == "Misc #2" then
		MiscTab3:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab3:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect24 == "Misc #2" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab4 = vgui.Create("DButton", GR)
MiscTab4:SetFont("Text")
MiscTab4:SetText("MoveRecorder")
MiscTab4:SetTextColor(Color(180,180,180))
MiscTab4:SetSize(100, 37)
MiscTab4:SetPos(230, 105)
function MiscTab4:DoClick()
	tabselect24 = "MoveRecorder"
	panel41:SetVisible(false)
	panel42:SetVisible(false)
	panel43:SetVisible(true)
end

function MiscTab4:Paint(w, h)
	if tabselect24 == "MoveRecorder" then
		MiscTab4:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab4:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect24 == "MoveRecorder" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab5 = vgui.Create("DButton", GR)
MiscTab5:SetFont("Text")
MiscTab5:SetText("Movement")
MiscTab5:SetTextColor(Color(180,180,180))
MiscTab5:SetSize(100, 37)
MiscTab5:SetPos(360, 105)
function MiscTab5:DoClick()
	tabselect34 = "Movement"
	panel44:SetVisible(true)
	panel45:SetVisible(false)
	panel46:SetVisible(false)
end

function MiscTab5:Paint(w, h)
	if tabselect34 == "Movement" then
		MiscTab5:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab5:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect34 == "Movement" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab6 = vgui.Create("DButton", GR)
MiscTab6:SetFont("Text")
MiscTab6:SetText("Cams")
MiscTab6:SetTextColor(Color(180,180,180))
MiscTab6:SetSize(100, 37)
MiscTab6:SetPos(460, 105)
function MiscTab6:DoClick()
	tabselect34 = "Cams"
	panel44:SetVisible(false)
	panel45:SetVisible(true)
	panel46:SetVisible(false)
end

function MiscTab6:Paint(w, h)
	if tabselect34 == "Cams" then
		MiscTab6:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab6:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect34 == "Cams" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local MiscTab7 = vgui.Create("DButton", GR)
MiscTab7:SetFont("Text")
MiscTab7:SetText("Translator")
MiscTab7:SetTextColor(Color(180,180,180))
MiscTab7:SetSize(100, 37)
MiscTab7:SetPos(560, 105)
function MiscTab7:DoClick()
	tabselect34 = "Translator"
	panel44:SetVisible(false)
	panel45:SetVisible(false)
	panel46:SetVisible(true)
end

function MiscTab7:Paint(w, h)
	if tabselect34 == "Translator" then
		MiscTab7:SetTextColor(GrTheme)
		draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
	else
		MiscTab7:SetTextColor(Color(200, 200, 200))
		draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
	end
	if self:IsHovered() then
		GradV(0, 0, w, h, 80, 80, 80, 255, 55, 55, 55, 255)
		if tabselect34 == "Translator" then
			draw.RoundedBox(0, 0, h-2, w, 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		else
			draw.RoundedBox(0, 0, h-2, w, 2, Color(DarkTheme7.r, DarkTheme7.g, DarkTheme7.b, 255))
		end
	end
end

local playerList = vgui.Create("DListView", panel5)
playerList:SetPos(30, 90)
playerList:SetSize(622.5, 170)
playerList:AddColumn("Name")
playerList:AddColumn("Steam ID")
playerList:AddColumn("Options")

local players = {}

local plyAvatar = vgui.Create( "AvatarImage", panel5)
plyAvatar:SetSize( 64, 64 )
plyAvatar:SetPos( 255, 328 )

local function CreateLabel1(x, y, text)
	local nameLabel = vgui.Create("DLabel", panel5)
	nameLabel:SetPos(x, y)
	nameLabel:SetText(text)
	nameLabel:SetSize(200, 20)
	nameLabel.Paint = function(self, w, h)
		self:SetTextColor(BlackToWhite)
	end
end

local timerObject = nil

local cooldown = GetConVarNumber("sv_namechange_cooldown_seconds")

CreateLabel1(35, 270, "Name:")
CreateLabel1(35, 290, "Health:")
CreateLabel1(35, 310, "Armor:")
CreateLabel1(35, 330, "Pos:")
CreateLabel1(35, 350, "Speed:")
CreateLabel1(252, 415, "Name delay:")

local nameValue = vgui.Create("DLabel", panel5)
nameValue:SetPos(70, 270)
nameValue:SetSize(200, 20)
nameValue:SetText("")
nameValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local healthValue = vgui.Create("DLabel", panel5)
healthValue:SetPos(75, 290)
healthValue:SetSize(200, 20)
healthValue:SetText("")
healthValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local armorValue = vgui.Create("DLabel", panel5)
armorValue:SetPos(75, 310)
armorValue:SetSize(200, 20)
armorValue:SetText("")
armorValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local posValue = vgui.Create("DLabel", panel5)
posValue:SetPos(60, 330)
posValue:SetSize(200, 20)
posValue:SetText("")
posValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local speedValue = vgui.Create("DLabel", panel5)
speedValue:SetPos(75, 350)
speedValue:SetSize(200, 20)
speedValue:SetText("")
speedValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local resetValue = vgui.Create("DLabel", panel5)
resetValue:SetPos(315, 415)
resetValue:SetSize(200, 20)
resetValue:SetText("")
resetValue.Paint = function(self, w, h)
	self:SetTextColor(BlackToWhite)
end

local ChangedTime = GetConVarNumber("sv_namechange_cooldown_seconds") - os.time()

local TargetMode = {}

local function ComboBox2( Parent, PosX, PosY, Width, Height, Choices, var)
	local GRdropdown = vgui.Create("DComboBox", Parent)
	GRdropdown:SetText("")
	GRdropdown:SetSize(Width, Height)
	GRdropdown:SetPos(PosX, PosY)
	GRdropdown:SetValue(TargetMode[var])
	local selected_index = 1
	for k, v in ipairs(Choices) do
		GRdropdown:AddChoice(v)
	end
	GRdropdown:SetSortItems(false)
	function GRdropdown:OnSelect(index, value, data)
		TargetMode[var] = value
		selected_index = index
	end
	GRdropdown.Paint = function(self,w,h)
		draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
		draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
		draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		if self:IsHovered() then
			draw.RoundedBox(2, 0, 0, w, h, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
			draw.RoundedBox(2, w/1.15, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
			draw.SimpleText("▼", "Feature", w-5 ,h/2, Color(BlackToWhite.r, BlackToWhite.b, BlackToWhite.g, 255),TEXT_ALIGN_RIGHT,TEXT_ALIGN_CENTER)
		end
	end
	DMenuOption.Paint = function(self, w, h, index, value, data)
		draw.RoundedBox(2, 0, 0, w, h, Color(WhiteToBlack.r, WhiteToBlack.b, WhiteToBlack.g, 255))
		self:SetTextColor(BlackToWhite)
		if self:IsHovered() then
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		end
		if self:IsSelected() == GetRekt.vars[var] then
			draw.RoundedBox(2, 0, 0, w, h, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))	
		end
	end
	GRdropdown.DropButton.Paint = function() end
	GRdropdown.PerformLayout = function(self)
		self:SetTextColor(BlackToWhite)
		self:SetFont("Feature")
	end
end

function UpdatePlayerList()
	players = {}
		
	playerList:Clear()
	
	for _, ply in pairs(player.GetAll()) do
		if ply:IsBot() and ply:SteamID() == "NULL" then
			players[ply:Nick()] = ply
		else
			players[ply:SteamID()] = ply
		end
		
		TargetMode[ply] = TargetMode[ply] or "Neutral"
			
		line = playerList:AddLine(ply:Nick(), (ply:IsBot() and ply:SteamID() == "NULL" and "BOT") or (ply:SteamID() == me:SteamID() and "YOU") or (ply:GetFriendStatus() == "friend" and ply:SteamID().." (friend)") or (ply:SteamID()))
		line.OnMousePressed = function()
			if tabselect == "PlayerList" and GR:IsVisible() then
				hook.Add("Think", "UpdateSelectedPlayerInfo", function()
					if IsValid(ply) then
						ChosenPly = ply
						nameValue:SetText(ply:Nick())
						healthValue:SetText(ply:Health())
						armorValue:SetText(ply:Armor())
						posValue:SetText("(" .. string.format("%.2f", ply:GetPos().x) .. ", " .. string.format("%.2f", ply:GetPos().y) .. ", " .. string.format("%.2f", ply:GetPos().z) .. ")")
						speedValue:SetText(string.format("%.2f", ply:GetVelocity():Length()))
						plyAvatar:SetPlayer( ply, 64 )
					end
					resetValue:SetText(math.Clamp((ChangedTime + GetConVarNumber("sv_namechange_cooldown_seconds") - os.time()), 0, 20))
				end)
			end
		end
		ComboBox2( line, 400, 0, 165, 20, {"Neutral", "Rage", "Friendly"}, ply)
	end
end


local myName = GetConVar("name"):GetString()
local myNick = me:Nick()
local ChangedName = false

function test3()
	if ChangedName then
		ded.NetSetConVar("name", myName)
		ChangedName = false
	end
	if me:Nick() != myNick and (engine.ActiveGamemode() == "darkrp") then
		RunConsoleCommand("say", "/name " .. myNick)
	end
	timer.Simple(0.5, function()
		local success = pcall(UpdatePlayerList)
	end)
end

local function test()
	ded.NetSetConVar("name", " ".. nameValue:GetText())
	ChangedName = true
	ChangedTime = os.time()
	timer.Simple(0.5, function()
		local success = pcall(UpdatePlayerList)
	end)
end

local function test4()
	if (engine.ActiveGamemode() == "darkrp") then
		RunConsoleCommand("say", "/name  " .. nameValue:GetText())
		timer.Simple(0.5, function()
			local success = pcall(UpdatePlayerList)
		end)
	end
end

function test2()
	if IsValid(ChosenPly) and ChosenPly:SteamID() == "NULL" then return end
	ChosenPly:ShowProfile()
end

function test5()
	if IsValid(ChosenPly) and ChosenPly:SteamID() == "NULL" then return end
	ChosenPly:SetMuted(true)
end

local function PlayerListUpdater()
	timer.Simple(0.1, function()
		local success = pcall(UpdatePlayerList)
	end)
end

function CheckDisconnectedPlayers()
	if #player.GetAll() < table.Count(players) then
		UpdatePlayerList()
	end
end
UpdatePlayerList()

panel11 = vgui.Create("DPanel", panel1)
panel11:SetSize(GR:GetWide(), GR:GetTall())
panel11:SetPos(0, 0)
panel11:SetVisible(tabselect21 == "Aim")
panel11.Paint = function(self, w, h)
end

panel12 = vgui.Create("DPanel", panel1)
panel12:SetSize(GR:GetWide(), GR:GetTall())
panel12:SetPos(0, 0)
panel12:SetVisible(tabselect21 == "Anti-Aim")
panel12.Paint = function(self, w, h)
end

panel21 = vgui.Create("DPanel", panel2)
panel21:SetSize(GR:GetWide(), GR:GetTall())
panel21:SetPos(0, 0)
panel21:SetVisible(tabselect22 == "Aim")
panel21.Paint = function(self, w, h)
end

panel22 = vgui.Create("DPanel", panel2)
panel22:SetSize(GR:GetWide(), GR:GetTall())
panel22:SetPos(0, 0)
panel22:SetVisible(tabselect22 == "Triggerbot")
panel22.Paint = function(self, w, h)
end

panel23 = vgui.Create("DPanel", panel2)
panel23:SetSize(GR:GetWide(), GR:GetTall())
panel23:SetPos(0, 0)
panel23:SetVisible(tabselect22 == "KnifeBot")
panel23.Paint = function(self, w, h)
end

panel31 = vgui.Create("DPanel", panel3)
panel31:SetSize(GR:GetWide(), GR:GetTall()) -- 30, 95, 632.5, h-465
panel31:SetPos(0, 0)
panel31:SetVisible(tabselect23 == "ESP")
panel31.Paint = function(self, w, h)
end
	
panel32 = vgui.Create("DPanel", panel3)
panel32:SetSize(GR:GetWide(), GR:GetTall())
panel32:SetPos(0, 0)
panel32:SetVisible(tabselect23 == "Other")
panel32.Paint = function(self, w, h)
end

panel33 = vgui.Create("DPanel", panel3)
panel33:SetSize(GR:GetWide(), GR:GetTall())
panel33:SetPos(0, 0)
panel33:SetVisible(tabselect33 == "ESP")
panel33.Paint = function(self, w, h)
end

panel34 = vgui.Create("DPanel", panel3)
panel34:SetSize(GR:GetWide(), GR:GetTall())
panel34:SetPos(0, 0)
panel34:SetVisible(tabselect33 == "Glow")
panel34.Paint = function(self, w, h)
end

panel35 = vgui.Create("DPanel", panel3)
panel35:SetSize(GR:GetWide(), GR:GetTall())
panel35:SetPos(0, 0)
panel35:SetVisible(tabselect33 == "Chams")
panel35.Paint = function(self, w, h)
end

panel41 = vgui.Create("DPanel", panel4)
panel41:SetSize(GR:GetWide()/2, GR:GetTall())
panel41:SetPos(0, 0)
panel41:SetVisible(tabselect24 == "Misc #1")
panel41.Paint = function(self, w, h)
end
	
panel42 = vgui.Create("DPanel", panel4)
panel42:SetSize(GR:GetWide()/2, GR:GetTall())
panel42:SetPos(0, 0)
panel42:SetVisible(tabselect24 == "Misc #2")
panel42.Paint = function(self, w, h)
end

panel43 = vgui.Create("DPanel", panel4)
panel43:SetSize(GR:GetWide()/2, GR:GetTall())
panel43:SetPos(0, 0)
panel43:SetVisible(tabselect24 == "Other")
panel43.Paint = function(self, w, h)
end

panel43 = vgui.Create("DPanel", panel4)
panel43:SetSize(GR:GetWide()/2, GR:GetTall())
panel43:SetPos(0, 0)
panel43:SetVisible(tabselect24 == "Other")
panel43.Paint = function(self, w, h)
end

panel44 = vgui.Create("DPanel", panel4)
panel44:SetSize(GR:GetWide()/2, GR:GetTall())
panel44:SetPos(GR:GetWide()/2, 0)
panel44:SetVisible(tabselect34 == "Movement")
panel44.Paint = function(self, w, h)
end

panel45 = vgui.Create("DPanel", panel4)
panel45:SetSize(GR:GetWide()/2, GR:GetTall())
panel45:SetPos(GR:GetWide()/2, 0)
panel45:SetVisible(tabselect34 == "Cams")
panel45.Paint = function(self, w, h)
end

panel46 = vgui.Create("DPanel", panel4)
panel46:SetSize(GR:GetWide()/2, GR:GetTall())
panel46:SetPos(GR:GetWide()/2, 0)
panel46:SetVisible(tabselect34 == "Translater")
panel46.Paint = function(self, w, h)
end

local uikey = false
local function Openui()
	if input.IsKeyDown(KEY_INSERT) && !GR:IsVisible() && !uikey then
		uikey = true
		GR:Show()
		if tabselect == "PlayerList" then
			UpdatePlayerList()
		end
	elseif input.IsKeyDown(KEY_INSERT) && GR:IsVisible() && !uikey then
		uikey = true
		GR:Hide()
		if IsValid(bindWindow) then
			bindWindow:Remove()
		end
		if IsValid(colorWindow) then
			colorWindow:Remove()
		end
	elseif !input.IsKeyDown(KEY_INSERT) then
		uikey = false
	end

	if tabselect == "Rage" then
		RageTab2:Show()
		RageTab3:Show()
	else
		RageTab2:Hide()
		RageTab3:Hide()
	end
	if tabselect == "Legit" then
		LegTab2:Show()
		LegTab3:Show()
		LegTab4:Show()
	else
		LegTab2:Hide()
		LegTab3:Hide()
		LegTab4:Hide()
	end	
	if tabselect == "Visuals" then
		VisTab2:Show()
		VisTab3:Show()
		if tabselect23 == "ESP" then
			VisTab4:Show()
			VisTab5:Show()
			VisTab6:Show()
		else
			panel33:SetVisible(false)
			VisTab4:Hide()
			VisTab5:Hide()
			VisTab6:Hide()
		end
		if tabselect23 != "Other" and tabselect33 == "ESP" then
			panel33:SetVisible(true)	
		end
	else
		VisTab2:Hide()
		VisTab3:Hide()
		VisTab4:Hide()
		VisTab5:Hide()
		VisTab6:Hide()
	end
	if tabselect == "Misc" then
		MiscTab2:Show()
		MiscTab3:Show()
		MiscTab4:Show()
		MiscTab5:Show()
		MiscTab6:Show()
		MiscTab7:Show()
	else
		MiscTab2:Hide()
		MiscTab3:Hide()
		MiscTab4:Hide()
		MiscTab5:Hide()
		MiscTab6:Hide()
		MiscTab7:Hide()
	end
	if tabselect == "PlayerList" then
	end
end

-- Aimbot

local function valid_player(v)
	return v && IsValid(v) && v != me && v:Alive() && v:Health() > 0  and !v:IsDormant() && v:GetObserverMode() == OBS_MODE_NONE && v:Team() != 1002
end

do
	for _, v in ipairs(player.GetAll()) do
		if valid_player(v) then
			GetRekt.Players[#GetRekt.Players + 1] = v
		end
	end
end
   
function get_players()
	if #GetRekt.Players > 0 then
		GetRekt.Players = {}
	end
	for _, v in ipairs(player.GetAll()) do
		if valid_player(v) then
			GetRekt.Players[#GetRekt.Players + 1] = v
		end
	end
	get_target()
end
   
local awall = {
	funcs = {},
	tracedata = {},
	traceout = {},
	pen = {
		["357"] = {144, 4},
		ar2 = {256, 5},
		buckshot = {25, 1},
		pistol = {81, 2},
		smg1 = {196, 4},
		sniperpenetratedround = {400, 12},
		sniperround = {400, 12}
	},
	multi = {
		[MAT_SAND] = 0.5,
		[MAT_DIRT] = 0.8,
		[MAT_METAL] = 1.1,
		[MAT_TILE] = 0.9,
		[MAT_WOOD] = 1.2
	},
	disable = {
	    [MAT_SLOSH] = true
	},
}

function wep_base(w)
    if !w.Base then return "" end
    return string.Split(string.lower(w.Base), "_")[1]
end

function ammo_name(w)
    if w.Primary and w.Primary.Ammo then
        return string.lower(w.Primary.Ammo)
    else
        return string.lower(tostring(game.GetAmmoName(w:GetPrimaryAmmoType())))
    end
end

function cw_penetration(w, data)
	if awall.disable[data.MatType] or (w.CanPenetrate ~= nil and !w.CanPenetrate) then return false end
	local ent = data.Entity
	if IsValid(ent) and (ent:IsPlayer() or ent:IsNPC()) then return false end
	return -data.Normal:Dot(data.HitNormal) > 0.26
end

function awall.funcs.bobs(w, data)
    if GetConVar("M9KDisablePenetration"):GetBool() then return nil end
    local dtbl = awall.pen[ammo_name(w)]
    if !dtbl then return nil end
    return dtbl[1], dtbl[2]
end

function awall.funcs.tfa(w, data)
	if !GetConVar("sv_tfa_bullet_penetration"):GetBool() then return nil end
	local force = w:GetAmmoForceMultiplier()
	local pen = w:GetPenetrationMultiplier(data.MatType)
	local cvar = GetConVar("sv_tfa_bullet_penetration_power_mul"):GetFloat()
	local dtbl = awall.pen[ammo_name(w)]
	local max = math.Clamp(dtbl and dtbl[2] or 1, 0, GetConVar("sv_tfa_penetration_hardlimit"):GetInt())
	return math.Truncate(((force / pen) * cvar) * 0.9, 5), max
end

function awall.funcs.cw(w, data)
	if !cw_penetration(w, data) then return nil end
	local str = w.PenStr * w.PenMod
	local multi = w.PenetrationMaterialInteraction and w.PenetrationMaterialInteraction[data.MatType] or 1
	return math.pow(str, 2) + (str * multi), 1
end

function awall.funcs.fas2(w, data)
	if !cw_penetration(w, data) then return nil end
	local str = w.PenStr * w.PenMod
	local multi = awall.multi[data.MatType] or 1
	return math.pow(str, 2) + (str * multi), 1
end

function pen_dist(w, data)
    local base = wep_base(w)
    if awall.funcs[base] then
        return awall.funcs[base](w, data)
    end
    return nil
end

function can_penetrate(w, data, v, pos)
    local maxdist, maxtimes = pen_dist(w, data)
    if !maxdist then return false end
    if !w:IsScripted() then return data.Entity == v end
    local opdata = {}
    local tr = {start = pos, endpos = data.HitPos, filter = {v}, mask = MASK_SHOT, output = opdata}
    util.TraceLine(tr)
    local curtimes = 1
    local lastpos = opdata.HitPos
    local world = game.GetWorld()
    local tfa = wep_base(w) == "tfa"
    if tfa then maxdist = maxdist / 2 end
    while curtimes <= maxtimes do
        if opdata.Entity == world then
            local start = tr.endpos
            for i = 1, 75 do
                tr.start = opdata.HitPos - (data.Normal * 10)
                tr.endpos = tr.start
                util.TraceLine(tr)
                if !opdata.HitWorld then break end
            end
            tr.endpos = start
        else
            if opdata.Entity == v then break end
            local ent = opdata.Entity
            tr.start = lastpos
            util.TraceLine(tr)
            tr.start = opdata.HitPos - data.Normal
            tr.endpos = lastpos
            tr.filter[2] = ent
            util.TraceLine(tr)
        end
        local curdist
        if tfa then
            curdist = opdata.HitPos:Distance(lastpos) / 88.88
        else
            curdist = math.floor(opdata.HitPos:DistToSqr(lastpos))
        end
        if curdist > maxdist then return false end
        if opdata.Hit then
            lastpos = opdata.HitPos
        else
            local start = data.HitPos
            tr.endpos = data.HitPos
            util.TraceLine(tr)
            tr.endpos = start
            if opdata.Hit then
                lastpos = opdata.HitPos
            else
                if tfa then
                    curdist = opdata.HitPos:Distance(lastpos) / 88.88
                else
                    curdist = math.floor(opdata.HitPos:DistToSqr(lastpos))
                end
                if curdist <= maxdist then
                    break
                end
            end
        end
        curtimes = curtimes + 1
    end
    return curtimes <= maxtimes, curtimes
end

function is_hittable(pos, v)
    awall.tracedata.start = me:EyePos()
    awall.tracedata.endpos = pos
    awall.tracedata.filter = me
    awall.tracedata.mask = MASK_SHOT
    local opdata = util.TraceLine(awall.tracedata)
    awall.traceout = opdata
    if opdata.Entity == v then
        return true, 0, opdata.Fraction
    elseif GetRekt.vars["AutoWall"] then
        local w = me:GetActiveWeapon()
        if !IsValid(w) then
            return false, 0, opdata.Fraction
        end
        local hit, pen = can_penetrate(w, opdata, v, pos)
        hit = hit or false
        pen = pen or 0
        return hit, pen, opdata.Fraction
    else
        return false, 0, opdata.Fraction
    end
end

function aim_pos(v)
	local set = v:GetHitboxSet()
	local pos = v:LocalToWorld(v:OBBCenter())
	local bone = 0
	local hitboxbone = v:GetHitBoxBone(bone, set)
	if hitboxbone == nil then return pos end
	local mins, maxs = v:GetHitBoxBounds(bone, set)
	local bpos, ang = v:GetBonePosition(hitboxbone)
	mins:Rotate(ang)
	maxs:Rotate(ang)
	pos = bpos + ((mins + maxs) * 0.5)
	return pos
end

function aim_filter(v)
	if TargetMode[v] == "Rage" then return true end
    if GetRekt.vars["Ignores"]["friends"] && v:GetFriendStatus() == "friend" then return false end
    if GetRekt.vars["Ignores"]["team"] && v:Team() == me:Team() then return false end
    if GetRekt.vars["Ignores"]["bots"] && v:IsBot() then return false end
    if GetRekt.vars["Ignores"]["noclip"] && v:GetMoveType() == MOVETYPE_NOCLIP then return false end
    if GetRekt.vars["Ignores"]["admins"] && (v:IsAdmin() or v:IsSuperAdmin()) then return false end
    if GetRekt.vars["Ignores"]["driving"] && v:InVehicle() then return false end
    if GetRekt.vars["Ignores"]["invisible"] && (v:GetNoDraw() or v:GetColor().a <= 0) then return false end
    if GetRekt.vars["Ignores"]["transparent"] && v:GetColor().a < 255 then return false end
    if TargetMode[v] == "Friendly" then return false end
    return true
end

GetRekt.Target = nil

function get_target()
	local sorted = {}
    for _, v in pairs(GetRekt.Players) do
        if aim_filter(v) then
            local visible = is_hittable(aim_pos(v), v)
            if visible then
			    sorted[#sorted + 1] = v
    		end
		end
    end
	table.sort(sorted, function(a, b)
        local a_is_rage = (TargetMode[a] == "Rage")
        local b_is_rage = (TargetMode[b] == "Rage")

        if a_is_rage or b_is_rage then
            return a_is_rage
        end
        
        local ats, bts = a:GetPos():ToScreen(), b:GetPos():ToScreen()
        return Vector(ScrW() / 2 - ats.x, ScrH() / 2 - ats.y, 0):LengthSqr() < Vector(ScrW() / 2 - bts.x, ScrH() / 2 - bts.y, 0):LengthSqr()
    end)
	
	GetRekt.Target = sorted[1]
end

GetRekt.Cones = {}

GAMEMODE["EntityFireBullets"] = function(self, p, data) 
    local w = me:GetActiveWeapon()
    local spread = data.Spread
    if !w or !IsValid(w) then return end
	if GetRekt.Cones[w:GetClass()] == spread or spread == Vector() then return end
    GetRekt.Cones[w:GetClass()] = Vector(spread.x, spread.y, 0)
end

function no_recoil(ang)
	local w = me:GetActiveWeapon()
	if !w or !w:IsValid() then return ang end
	local c = w:GetClass()
	if string.StartWith(c, "m9k_") or string.StartWith(c, "bb_") or string.StartWith(c, "unclen8_") then
		return ang
	else
	    return ang - me:GetViewPunchAngles()
    end
end

--[[function no_spread(cmd, ang)
	local w = me:GetActiveWeapon()
	if !w or !w:IsValid() then return ang end
	local class = w:GetClass()
	local spread = GetRekt.Cones[class]
	local cone = w.CurCone
	if cone then
		if class:StartWith("swb_") then return ang end
		if class:StartWith("cw_") then
			math.randomseed(cmd:CommandNumber())
		elseif class:StartWith("fas2_") then
			math.randomseed(CurTime())
		end
		return ang - Angle(math.Rand(-cone, cone), math.Rand(-cone, cone), 0) * 25
	elseif spread then
		return ang - ded.PredictSpread(cmd, ang, spread):Angle()
	end
	return ang
end]]

Seeds = {}

function no_spread(cmd, ang)
	local w = me:GetActiveWeapon()
	if !w or !w:IsValid() then return ang end
	local class = w:GetClass()
	local spread = GetRekt.Cones[class]
	local cone = w.CurCone
	if cone then
		if class:StartWith("cw_") or class:StartWith("fas2_") then
			local Seed = ded.GetCmdRandomSeed(cmd)
			
			local X = Seeds[Seed].X
        	local Y = Seeds[Seed].Y
        	local Forward = ang:Forward()
	        local Right = ang:Right()
	        local Up = ang:Up()
		end
		return Forward + (X * cone.x * Right * -1) + (Y * cone.y * Up * -1)
	elseif spread then
		return ang - ded.PredictSpread(cmd, ang, spread):Angle()
	end
	return ang
end

function rapid_fire(cmd)
    if GetRekt.vars["RapidFire"] then
		if !IsValid(me:GetActiveWeapon()) or !me:Alive() then return end
		local name = me:GetActiveWeapon():GetClass()
        if me:KeyDown(IN_ATTACK) then
            cmd:RemoveKey(IN_ATTACK)
        end
    end
end

function can_shoot(cmd)
	local w = me:GetActiveWeapon()
	if IsValid(w) && w:Clip1() == 0 then
		return false
	end
	if IsValid(w) && GetRekt.vars["BulletTime"] && w:GetNextPrimaryFire() >= ded.GetServerTime(cmd) then
		return true
	end
end

function lerp_time()
	if GetConVar("cl_interpolate"):GetInt() == 0 then return 0 end
	local ratio = GetConVar("cl_interp_ratio"):GetFloat()
	if ratio == 0 then ratio = 1 end
	local lerp = GetConVar("cl_interp"):GetFloat()
	local updateRate = GetConVar("cl_updaterate"):GetFloat()
	return math.max(lerp, ratio / updateRate)
end

local tick_int = engine.TickInterval()

function time_to_tick(t)
	return math.floor(0.5 + t / tick_int) + lerp_time()
end

function aim_bot(cmd)
	if !me:Alive() then return end
	if can_shoot(cmd) then return end
	if GetRekt.vars["Silent"] then
        if cmd:CommandNumber() == 0 then return end
    end
	local v = GetRekt.Target
	if !v or !IsValid(v) then return end
	if !ToggleBinds["Aimbot"] and TargetMode[v] != "Rage" then return end
	local x, y = ScrW() * 0.5, ScrH() * 0.5
	local fov = (math.tan(math.rad(GetRekt.vars["FovSize"] / 2)) / math.tan(math.rad(me:GetFOV() * 0.5)) * ScrW()) / 2.6
	local pos = aim_pos(v):ToScreen()
	local dist = math.Dist(pos.x, pos.y, x, y)
	if TargetMode[v] != "Rage" and dist > fov then return end
	local pos = aim_pos(v) - me:EyePos()
	if !pos then return end
	pos:Normalize()
	local ang = pos:Angle()
	ang:Normalize()
	if GetRekt.vars["NoAimRecoil"] then
        ang = no_recoil(ang)
    end
    if GetRekt.vars["NoAimRecoil"] then
        ang = no_spread(cmd, ang)
    end
    if GetRekt.vars["NoAimLag"] then
		bsendpacket = true
	end
	local t = time_to_tick(ded.GetSimulationTime(v:EntIndex()))
	ded.SetCommandTick(cmd, t)
	cmd:SetViewAngles(ang)
	if GetRekt.vars["AutoShoot"] or TargetMode[v] == "Rage" then
		cmd:AddKey(IN_ATTACK)
	end
end

-- Anti Aim

local fa

local function FixView(cmd)
	if IsValid(me:GetActiveWeapon()) && me:GetActiveWeapon():GetClass() == "weapon_physgun" and IsValid(me:GetActiveWeapon():GetInternalVariable("m_hGrabbedEntity")) and (cmd:KeyDown(IN_USE) or me:KeyDown(IN_USE)) then return end
	if !fa then fa = cmd:GetViewAngles() end
    fa.x = fa.x + (cmd:GetMouseY() * GetConVar("m_pitch"):GetFloat())
    fa.y = fa.y - (cmd:GetMouseX() * GetConVar("m_yaw"):GetFloat())
	fa.x = math.Clamp(math.NormalizeAngle(fa.x), -89, 89)
	fa.r = 0
	fa:Normalize()
end

function fix_move(cmd)
	local view_ang = cmd:GetViewAngles()
	local move = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local yaw = math.rad(view_ang.y - cmd:GetViewAngles().y + move:Angle().y)
	local vel = move:Length2D()
	cmd:SetForwardMove(math.cos(yaw) * vel)
	cmd:SetSideMove(math.sin(yaw) * vel)
end

local function FixMovement(cmd)
	local vec = Vector(cm.GetForwardMove(cmd), cm.GetSideMove(cmd), 0)
	local vel = math.sqrt(vec.x * vec.x + vec.y * vec.y)
	local mang = vm.Angle(vec)
	local yaw = cm.GetViewAngles(cmd).y - fa.y + mang.y
	if (((cm.GetViewAngles(cmd).p + 90) % 360) > 180) then
	yaw = 180 - yaw
	end
	yaw = ((yaw + 180) % 360) - 180
	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function aacheck(cmd)
	if GetRekt.vars["AA_Yaw"] == "Off" and GetRekt.vars["AA_Pitch"] == "Off" then return false end
	if cmd:KeyDown(IN_ATTACK) then return false end
	if cmd:KeyDown(IN_USE) then return false end
	if me:GetMoveType() == MOVETYPE_LADDER then return false end
	if me:GetMoveType() == MOVETYPE_NOCLIP then return false end

	return true 
end

local SwitchOn = false

local function Pitch()
	if bsendpacket then
		pitchflip = !pitchflip
	end
	if (GetRekt.vars["AA_Pitch"] == "Off") then
        ox = fa.x
	elseif (GetRekt.vars["AA_Pitch"] == "Zero") then
		ox = 0
	elseif (GetRekt.vars["AA_Pitch"] == "Up") then
		ox = -89
	elseif (GetRekt.vars["AA_Pitch"] == "Down") then
		ox = 89
	elseif (GetRekt.vars["AA_Pitch"] == "Jitter") then
		SwitchOn = !SwitchOn
		ox = SwitchOn and 89 or -89
	elseif (GetRekt.vars["AA_Pitch"] == "Random") then
		ox = math.random( -89, 89)
	elseif (GetRekt.vars["AA_Pitch"] == "FakeDown") then
		ox = -540.000005
	elseif (GetRekt.vars["AA_Pitch"] == "FakeDownJitter") then
		ox = 180.00000762939
	end
end

local mm_side = false

local function micromovement(cmd)
    if !me:Alive() then return end
    if !me:IsFlagSet( FL_ONGROUND ) then return end
    if cmd:KeyDown(IN_BACK) or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT) then return end

    cmd:SetSideMove(mm_side and -15.0 or 15.0)
    mm_side = !mm_side
end

local ySwitch = false

local function Yaw(cmd)
	if (GetRekt.vars["AA_Yaw"] == "Off") then
        oy = fa.y
	elseif (GetRekt.vars["AA_Yaw"] == "Back") then
		oy = fa.y + 180
	elseif (GetRekt.vars["AA_Yaw"] == "Left") then
		oy = fa.y + 90
	elseif (GetRekt.vars["AA_Yaw"] == "Right") then
		oy = fa.y - 90
	elseif (GetRekt.vars["AA_Yaw"] == "Random") then
		oy = math.random( - 180, 180)
	elseif (GetRekt.vars["AA_Yaw"] == "Spin") then
		oy = (CurTime() * 15 * 23) % 350, 1	
	elseif (GetRekt.vars["AA_Yaw"] == "Jitter") then
		oy = (cmd:CommandNumber() % 3) >= 1 and fa.y + 140 or fa.y - 140
	elseif (GetRekt.vars["AA_Yaw"] == "Anti-Brute") then
		oy = fa.y + math.random(1, 180, 1, 80, 1)--ded.GetCurrentLBY(me:EntIndex()) + (bsendpacket and -90 or 90)
	elseif (GetRekt.vars["AA_Yaw"] == "Legit") then
		oy = bsendpacket and fa.y or fa.y + 140
	end
end

local function AntiAim(cmd)
	if cm.CommandNumber(cmd) == 0 then return end
	if !aacheck(cmd) then return end
	Pitch()
	Yaw(cmd)
	local aaang = Angle(ox, oy, 0)
	cm.SetViewAngles(cmd, aaang)
	if (GetRekt.vars["AA_Yaw"] == "Anti-Brute") and garterSDAdSA then
		micromovement(cmd)
	end
	--FixMovement(cmd, true)
end

-- Aim Functions

local function getWeapon( ent )
	local wep = ent:GetActiveWeapon()
	if ( IsValid(wep) ) then
		return wep:GetClass()
	else
		return false
	end
end
local function shouldFire(b)
	local wep = getWeapon(me)
	local wepactive = me:GetActiveWeapon()
	if me:Alive() and wep then
		if string.find(wep, "csgo_") ~= nil and !string.find(wep, "weapon_csgo_") then
			return true
		elseif wepactive:GetClass() == "m9k_damascus" then
			return true
		elseif wepactive:GetClass() == "m9k_knife" then
			return true
		elseif wepactive:GetClass() == "m9k_machete" then
			return true
		elseif wepactive:GetClass() == "weapon_knife" then
			return true
		elseif wepactive:GetClass() == "weapon_fists" or wepactive:GetClass() == "p_fists" then
			return true
		elseif wepactive:GetClass() == "swb_knife" or wepactive:GetClass() == "swb_knife_m" then
			return true
		end
	end
	return false
end

-- TriggerBot

local NextShotTime = 0

local function TriggerValid(v)
	return (v and IsValid(v) and v:Health() > 0 and not v:IsDormant() and me:GetObserverTarget() ~= v && v != me && me:GetObserverTarget() ~= v)
end

local function TriggerFilter(hitbox)
	if GetRekt.vars["TriggerBotHead"] and GetRekt.vars["TriggerBotChest"] and GetRekt.vars["TriggerBotStomach"] and GetRekt.vars["TriggerBotArms"] and GetRekt.vars["TriggerBotLegs"] then
		return hitbox ~= nil
	elseif GetRekt.vars["TriggerBotHead"] or GetRekt.vars["TriggerBotChest"] or GetRekt.vars["TriggerBotStomach"] or GetRekt.vars["TriggerBotArms"] or GetRekt.vars["TriggerBotLegs"] then
		return (hitbox == 0 and GetRekt.vars["TriggerBotHead"]) or (hitbox == 16 and GetRekt.vars["TriggerBotChest"]) or (hitbox == 15 and GetRekt.vars["TriggerBotStomach"]) or ((hitbox == 4 or hitbox == 5 or hitbox == 6 or hitbox == 1 or hitbox == 2 or hitbox == 3) and GetRekt.vars["TriggerBotArms"]) or ((hitbox == 11 or hitbox == 12 or hitbox == 13 or hitbox == 14 or hitbox == 18 or hitbox == 7 or hitbox == 8 or hitbox == 9 or hitbox == 10) and GetRekt.vars["TriggerBotLegs"])
	end
	return
end

local function Tbot(cmd)
	if cm.CommandNumber(cmd) == 0 or not me:Alive() or me:Health() < 1 or (me:Team() == TEAM_SPECTATOR or cmd:KeyDown(IN_ATTACK)) then return end
	if GetRekt.vars["TriggerBot"] and !shouldFire() then
		local trace = me:GetEyeTraceNoCursor()
		local v = trace.Entity
		local hitbox = trace.HitBox
		if TriggerValid(v) and TriggerFilter(hitbox) and ToggleBinds["TriggerBot"] and v:IsPlayer() then
			if GetRekt.vars["TriggerBotJumpCheck"] and !me:OnGround() then return end
			if GetRekt.vars["TriggerBotIgnoreTeam"] and v:Team() == LocalPlayer():Team() then return end
			cmd:AddKey( IN_ATTACK )
			if IsValid(me:GetActiveWeapon()) then
				if me:KeyDown( IN_ATTACK ) and me:Alive() and GetRekt.vars["TriggerBotAutoPistol"] then
					cmd:RemoveKey( IN_ATTACK )
				end
			end
		end
	end
end

local OEyeAngles = OEyeAngles or FindMetaTable( "Player" ).SetEyeAngles

FindMetaTable( "Player" ).SetEyeAngles = function( self, angle )

    if ( string.find( string.lower( debug.getinfo( 2 ).short_src ), "/weapons/" ) ) and GetRekt.vars["NoRecoil"] and GetRekt.vars["TriggerBot"] and ToggleBinds["TriggerBot"] then return end

    OEyeAngles( self, angle )

end

-- KnifeBot

local function IsVisible(ply)
	local pos = ply:LocalToWorld(ply:OBBCenter())	
	local trace = { 
		start = LocalPlayer():GetShootPos(), 
		endpos = pos, 
		filter = { LocalPlayer(), ply }, 
		mask = MASK_SHOT
	}
	local tr = util.TraceLine( trace )
	
	if( !tr.Hit ) then
		return true
	end
	return false
end

local function Distance()
	local wep = getWeapon(me)
	local wepactive = me:GetActiveWeapon()
	if me:Alive() and wep and IsValid(wepactive) then
		if string.find(wep, "csgo_") ~= nil then
			return 95
		elseif wepactive:GetClass() == "m9k_damascus" then
			return 81
		elseif wepactive:GetClass() == "m9k_knife" then
			return 50
		elseif wepactive:GetClass() == "m9k_machete" then
			return 70
		elseif wepactive:GetClass() == "weapon_knife" then
			return 100
		elseif wepactive:GetClass() == "weapon_fists" or wepactive:GetClass() == "p_fists" then
			return 70
		elseif wepactive:GetClass() == "swb_knife" or wepactive:GetClass() == "swb_knife_m" then
			return 65
		end
	end
	return 0
end

local function Kbot(cmd)
	local wep = getWeapon(me)
	local wepactive = me:GetActiveWeapon()
	if GetRekt.vars["KnifeBot"] and ToggleBinds["KnifeBot"] then
		
		local closestPlayer = nil
		local closestDistance = math.huge
		for _, player in pairs(player.GetAll()) do
			local distance = player:GetPos():Distance(LocalPlayer():GetPos())
			if distance < closestDistance then
				closestPlayer = player
				closestDistance = distance
			end
		end
		
		for k, v in next, player.GetAll() do
			if v:GetPos():Distance(me:GetPos()) < Distance() and IsVisible(v) then
				
				if not v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me then continue end
				
				if closestPlayer and shouldFire() then
					
					if string.find(wep, "csgo_") ~= nil then
						if v:Health() <= 30 or v:Health() > 65 or (v:Health() <= 65 and v:GetPos():Distance(me:GetPos()) > 72) then
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
						else
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
						end
					elseif wepactive:GetClass() == "m9k_knife" then
						if v:GetPos():Distance(me:GetPos()) > 40 then
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
						else
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
						end
					elseif wepactive:GetClass() == "weapon_knife" then
						if v:Health() <= 20 or v:Health() > 65 or (v:Health() <= 65 and v:GetPos():Distance(me:GetPos()) > 72) then
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
						else
							cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
						end
					elseif wepactive:GetClass() == "swb_knife" or wepactive:GetClass() == "swb_knife_m" then
						cmd:SetButtons(cmd:GetButtons() + IN_ATTACK2)
					else
						cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
					end
				
					if me:KeyDown(IN_ATTACK) and me:Alive() then
						cmd:RemoveKey(IN_ATTACK)
					end
					
					if me:KeyDown(IN_ATTACK2) and me:Alive() then
						cmd:RemoveKey(IN_ATTACK2)
					end
					
					local target = v:LookupBone("ValveBiped.Bip01_Spine")
					local targetpos = v:GetBonePosition(target)
					local aimang = (targetpos - LocalPlayer():GetShootPos()):Angle()
					
					ded.SetContextVector(cmd, aimang:Forward(), true)
				end
			end
		end
	end
end

local function KbotCircle()
	if GetRekt.vars["KnifeBotRange"] and shouldFire() then
		local pos = me:GetPos() + Vector(0, 0, 35)
		local dist = 9
			
		cam.Start3D2D(pos, Angle(0, 0, 0), 1)
			draw.NoTexture()
			surface.SetDrawColor(255, 255, 255, 255)
				
			local segments = 32
			local radius = dist / math.sin(math.rad(180 / segments))
	
			for i = 1, segments do
				local a = math.rad((i - 1) * (360 / segments))
				local b = math.rad(i * (360 / segments))
	
				surface.DrawLine(math.cos(a) * radius, math.sin(a) * radius, math.cos(b) * radius, math.sin(b) * radius)
			end
		cam.End3D2D()
	end
end

-- Visuals

function DrawGradientRect(x, y, w, h, color)
    local mat = Material("vgui/gradient-d") -- The d can be switched to u for up d for down r for right and l for left

    surface.SetDrawColor(color)
    surface.SetMaterial(mat)

    surface.DrawTexturedRect(x, y, w, h)
end

local function get_bounding(v)
    local min, max = v:OBBMins(), v:OBBMaxs()
    local corners = {
        Vector(min.x,min.y,min.z),
        Vector(min.x,min.y,max.z),
        Vector(min.x,max.y,min.z),
        Vector(min.x,max.y,max.z),
        Vector(max.x,min.y,min.z),
        Vector(max.x,min.y,max.z),
        Vector(max.x,max.y,min.z),
        Vector(max.x,max.y,max.z)
    }
    local minx,miny,maxx,maxy = math.huge, math.huge, -math.huge, -math.huge
    for _, corner in next, corners do
        local screen = v:LocalToWorld(corner):ToScreen()
        minx,miny = math.min(minx,screen.x), math.min(miny,screen.y)
        maxx,maxy = math.max(maxx,screen.x), math.max(maxy,screen.y)
    end
    return minx, miny, maxx, maxy
end

local function on_screen(v, radius)
	local dir = v:GetPos() - EyePos()
	local len = dir:Length()
	local max = math.abs(math.cos(math.acos(len / math.sqrt((len * len) + (radius * radius))) + 60 * (math.pi / 180)))
	dir:Normalize()
	return dir:Dot(EyeVector()) > max
end

local function player_esp()
	if GetRekt.vars["ESP"] and ToggleBinds["ESP"] then
		for _, v in pairs(GetRekt.Players) do
			if !v or !IsValid(v) then return end
			local x1, y1, x2, y2 = get_bounding(v)
			local w = math.floor(x2 - x1)
	        local h = math.floor(y2 - y1)
			
			if !on_screen(v, -w / 2) then continue end
			
			if GetRekt.vars["Name"] then
				local name_col = Color(255, 255, 255, 255)
				surface.SetFont("Feature2")
				surface.SetTextColor(name_col.r, name_col.g, name_col.b, name_col.a)
				surface.SetTextPos(x1 + w / 2 - surface.GetTextSize(v:Nick()) / 2, y1 - 13)
				surface.DrawText(v:Nick())
			end
			--[[if vortex.vars["weapon"] && IsValid(v:GetActiveWeapon()) then
				local wep_col = vortex.colors["weapon"]
				vortex.cache.ui.draw_text(string.gsub(v:GetActiveWeapon():GetClass(), ".*_", ""), "4", x1 + w / 2 - surface.GetTextSize(string.gsub(v:GetActiveWeapon():GetClass(), ".*_", "")) / 2, (vortex.vars["armorbar"] && v:Armor() > 0) && y1 + h + 3 or y1 + h - 1, wep_col.r, wep_col.g, wep_col.b, wep_col.a)
			end]]
			if GetRekt.vars["Box"] then
				local box_col = Color(255, 255, 255, 255)
				surface.SetDrawColor(box_col.r, box_col.g, box_col.b, box_col.a)
				surface.DrawOutlinedRect(x1, y1, w, h)
				surface.SetDrawColor(0, 0, 0)
				surface.DrawOutlinedRect(x1 - 1, y1 - 1, w + 2, h + 2)
				surface.SetDrawColor(0, 0, 0)
				surface.DrawOutlinedRect(x1 + 1, y1 + 1, w - 2, h - 2)
			end
			if GetRekt.vars["BoxFill"] then
				DrawGradientRect(x1 + 1, y1 + 1, w - 2, h - 2, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
			end
			if GetRekt.vars["HealthBar"] then
				if GetRekt.vars["HealthBarType"] == "Normal" then
					local hp_h = math.floor(math.Clamp(v:Health() / v:GetMaxHealth(), 0, 1) * h)
					surface.SetDrawColor(0, 0, 0)
					surface.DrawRect(x1 - 5, y1 - 1, 3, h + 2)
					surface.SetDrawColor( 255 - 2.55 * (v:Health() / v:GetMaxHealth() * 100), 2.55 * (v:Health() / v:GetMaxHealth() * 100), 0)
					surface.DrawRect(x1 - 4, y1 + h - hp_h, 1, hp_h)
					--surface.SetFont("5")
					--vortex.cache.ui.draw_text(v:Health(), "5", x1 - surface.GetTextSize(v:Health()) / 2  - 3, math.Clamp(y2 - 4 - hp_h, y1 - 4, y2 - 8), 255, 255, 255)
				elseif GetRekt.vars["HealthBarType"] == "Gradiant" then
					local hp_h = math.floor(math.Clamp(v:Health() / v:GetMaxHealth(), 0, 1) * h)
					surface.SetDrawColor(0, 0, 0)
					surface.DrawRect(x1 - 5, y1 - 1, 3, h + 2)
					surface.SetDrawColor(0, 255, 0)
					surface.DrawRect(x1 - 4, y1, 1, h)
					DrawGradientRect(x1 - 4, y1, 1, h, Color(255, 0, 0, 255))
					surface.SetDrawColor(0, 0, 0)
					surface.DrawRect(x1 - 4, y1, 1, h - hp_h)
				end
			end
			if GetRekt.vars["ArmorBar"] && v:Armor() > 0 then
				local ar_w = math.floor(math.Clamp(v:Armor() / v:GetMaxArmor(), 0, 1) * w)
				surface.SetDrawColor(0, 0, 0)
				surface.DrawRect(x1 - 1, y1 + h + 2, w + 2, 3)
				surface.SetDrawColor(35, 125, 255)
				surface.DrawRect(x1, y1 + h + 3, ar_w, 1)
				--surface.SetFont("5")
				--vortex.cache.ui.draw_text(v:Armor(), "5", math.Clamp(x1 - 5 + ar_w, x1 - 1, x2 - 9), y1 - 2 + h, 255, 255, 255)
			end
		end
	end
end

-- Bind List

surface.CreateFont("Feature2", { font = "Tahoma", size = 13, antialias = true, weight = 600})
local Bindx, Bindy = 10, ScrH() / 2 - 100

local function BindList()
	if true then
	local Bindw = 180
	local Bindh = 15
	local Bindamt = 0
	local offset = 0
	local textY = Bindy + Bindh + 2
	draw.RoundedBox(0, Bindx, Bindy + 35, Bindw, Bindh, Color(GrTheme.r, GrTheme.g, GrTheme.b, 120))
	draw.SimpleText("Bind List", "Feature2", Bindx + Bindw / 2, Bindy + 35, Color(220, 220, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	Bindh = 50
	draw.RoundedBox(0, Bindx, Bindy + Bindh + Bindamt, Bindw, Bindh, Color(DarkTheme.r, DarkTheme.g, DarkTheme.b, 255))
	draw.RoundedBox(0, Bindx + 6, Bindy + Bindh + Bindamt + 4, Bindw - 12, Bindh - 8, Color(DarkTheme3.r, DarkTheme3.g, DarkTheme3.b, 255))
	if true then
		for i, _ in pairs(ToggleBinds) do
			if ToggleBinds[i] and GetRekt.vars[i] then
				if i == "ESP" then continue end
				draw.SimpleText(i, "Feature2", Bindx + 10, Bindy + 2 + Bindh + Bindamt + 1, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(tostring(GetRekt.bind[i]), "Feature2", Bindx + Bindw - 10, Bindy + 2 + Bindh + Bindamt + 1, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
				Bindamt = Bindamt + 15
			end
		end
			if Bindamt == 0 then
				draw.SimpleText("No active binds", "Feature2", Bindx + Bindw / 2, Bindy + 2 + Bindh + Bindamt + 1, Color(BlackToWhite.r, BlackToWhite.g, BlackToWhite.b), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			end
		end
		Bindw = Bindamt + 15
	end
end

local function MovemntKeys()
	if GetRekt.vars["KeyBinds"] then
		if input.IsKeyDown(KEY_W) then
			draw.RoundedBox(0, ScrW()/2-10, ScrH()/1.5, 20, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-10, ScrH()/1.5, 20, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_E) or input.IsKeyDown(IN_USE) then
			draw.RoundedBox(0, ScrW()/2+13, ScrH()/1.5, 20, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2+13, ScrH()/1.5, 20, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_A) then
			draw.RoundedBox(0, ScrW()/2-33, ScrH()/1.5+23, 20, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-33, ScrH()/1.5+23, 20, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_S) then
			draw.RoundedBox(0, ScrW()/2-10, ScrH()/1.5+23, 20, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-10, ScrH()/1.5+23, 20, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_D) then
			draw.RoundedBox(0, ScrW()/2+13, ScrH()/1.5+23, 20, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2+13, ScrH()/1.5+23, 20, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(IN_SPEED) then
			draw.RoundedBox(0, ScrW()/2-81, ScrH()/1.5+23, 45, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-81, ScrH()/1.5+23, 45, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(IN_DUCK) then
			draw.RoundedBox(0, ScrW()/2-81, ScrH()/1.5+46, 45, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-81, ScrH()/1.5+46, 45, 20, Color(150, 120, 255, 150))
		end
		if input.IsKeyDown(KEY_SPACE) or input.IsKeyDown(IN_JUMP) then
			draw.RoundedBox(0, ScrW()/2-33, ScrH()/1.5+46, 66, 20, Color(140, 140, 255, 255))
		else
			draw.RoundedBox(0, ScrW()/2-33, ScrH()/1.5+46, 66, 20, Color(150, 120, 255, 150))
		end
		draw.SimpleText("W", "Feature", ScrW()/2, ScrH()/1.5+2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("E", "Feature", ScrW()/2+23, ScrH()/1.5+2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("A", "Feature", ScrW()/2-23, ScrH()/1.5+25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("S", "Feature", ScrW()/2, ScrH()/1.5+25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("D", "Feature", ScrW()/2+23, ScrH()/1.5+25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("SPEED", "Feature", ScrW()/2-58, ScrH()/1.5+25, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("DUCK", "Feature", ScrW()/2-58, ScrH()/1.5+48, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		draw.SimpleText("JUMP", "Feature", ScrW()/2, ScrH()/1.5+48, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

local velocityData = {}

local function captureVelocity()
	local ply = LocalPlayer()
	local velocity = ply:GetVelocity():Length2D()
	table.insert(velocityData, velocity)

	if #velocityData > 300 then
		table.remove(velocityData, 1)
	end
end

local function drawVelocityGraph()
	local dataSize = #velocityData
	local midX = ScrW() / 2
	local midY = ScrH() / 2
	local graphWidth = 300
	local graphHeight = 150
	local graphX = midX - graphWidth / 2
	local graphY = midY - graphHeight / 2 + 350

	if GetRekt.vars["MovementGraph"] then
		local staticY = graphY + graphHeight
		surface.SetDrawColor(255, 255, 255, 150)
		surface.DrawLine(graphX, staticY, graphX + graphWidth, staticY)
	
		for i = 1, dataSize do
			local velocity = velocityData[i]
			local x = (i / dataSize) * graphWidth + graphX
			local y = graphY + graphHeight - (velocity / 1000) * graphHeight
			surface.SetDrawColor(255, 255, 255, 150)
			surface.DrawLine(x, staticY, x, y)
		end
		
		local totalVelocity = 0
		for i = 1, dataSize do
			totalVelocity = totalVelocity + velocityData[i]
		end
		local averageVelocity = totalVelocity / dataSize
		
		local averageY = graphY + graphHeight - (averageVelocity / 1000) * graphHeight
		surface.SetDrawColor(GrTheme.r, GrTheme.g, GrTheme.b, 255)
		surface.DrawLine(graphX, averageY, graphX + graphWidth, averageY)
		local text = string.format("%.0f", averageVelocity)
		draw.DrawText(text, "Default", graphX + graphWidth + 10, averageY, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local text2 = string.format("%.0f", me:GetVelocity():Length())
		draw.DrawText(text2, "Default", midX, midY - graphHeight + 580, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local f0 = 0.0
local function Bunnyhop(cmd)
	if me:GetMoveType() == MOVETYPE_NOCLIP or me:GetMoveType() == MOVETYPE_LADDER or me:WaterLevel() > 1 then return end
	
	if GetRekt.vars["Bhop"] then
		if me:OnGround() and cmd:KeyDown(IN_JUMP) then
			cmd:AddKey(IN_JUMP)
		else
			cmd:RemoveKey(IN_JUMP)
		end
	end

	if GetRekt.vars["Strafe"] then
		if GetRekt.vars["StrafeType"] == "Normal" then
			if not me:OnGround() then
				if cmd:GetMouseX() > 1 or cmd:GetMouseX() < -1 then
					cmd:SetSideMove(cmd:GetMouseX() > 1 and 400 or -400)
				else
					cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
					cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and -400 or 400)
				end
			elseif cmd:KeyDown(IN_JUMP) then
				cmd:SetForwardMove(450)
			end
		elseif GetRekt.vars["StrafeType"] == "Multi" then
			if not ( me:IsFlagSet( FL_ONGROUND ) ) then
				local w = LocalPlayer():EyeAngles()
			    local f2 = function(f3)
			        local f4 = math.deg(math.atan(30.0 / f3))
			        if f4 > 90.0 then
			            return 90.0
			        elseif f4 < 0.0 then
			            return 0.0
			        else
			            return f4
			        end
			    end
			    local f5 = 57.295779513082
			    local f6 = 10000
			    local f3 = LocalPlayer():GetVelocity()
			    f3.z = 0.0
			    local f7 = cmd:GetForwardMove()
			    local f8 = cmd:GetSideMove()
			    if not f7 or not f8 then
			        return
			    end
			    local f9 = cmd:TickCount() % 2 == 0
			    local fa = f9 and 1.0 or -1.0
			    local fb = Angle(w.x, w.y, w.z)
			    if f7 or f8 then
			        cmd:SetForwardMove(0)
			        cmd:SetSideMove(0)
			        local fc = math.atan2(-f8, f7)
			        fb.y = fb.y + fc * f5
			    elseif f7 then
			        cmd:SetForwardMove(0)
			    end
			    local fd = math.deg(math.atan(15 / f3:Length2D()))
			    if fd > 90 then
			        fd = 90
			    elseif fd < 0 then
			        fd = 0
			    end
			    local fe = Vector(0, fb.y - f0, 0)
			    fe.y = math.NormalizeAngle(fe.y)
			    local ff = fe.y
			    f0 = fb.y
			    local fg = math.abs(ff)
			    if fg <= fd or fg >= 30 then
			        local fh = f3:Angle()
			        fe = Vector(0, fb.y - fh.y, 0)
			        fe.y = math.NormalizeAngle(fe.y)
			        local fi = fe.y
			        local fj = f2(f3:Length2D() * 128)
			        if fi <= fj or f3:Length2D() <= 15 then
			            if -fj <= fi or f3:Length2D() <= 15 then
			                fb.y = fb.y + fd * fa
			                cmd:SetSideMove(f6 * fa)
			            else
			                fb.y = fh.y - fj
			                cmd:SetSideMove(f6)
			            end
			        else
			            fb.y = fh.y + fj
			            cmd:SetSideMove(-f6)
			        end
			    elseif ff > 0 then
			        cmd:SetSideMove(-f6)
			    elseif ff < 0 then
			        cmd:SetSideMove(f6)
			    end
			    local fk = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
			    local fl = fk:Length()
			    local fm = fk:Angle()
			    local fn = math.modf(w.x + 180, 360) - 180
			    local fo = math.modf(w.y + 180, 360) - 180
			    local df = math.rad(fo - fb.y + fm.y)
			    if fn >= 90 or fn <= -90 or w.x >= 90 and w.x <= 200 or w.x <= -90 and w.x <= 200 then
			        cmd:SetForwardMove(-math.cos(df) * fl)
			    else
			        cmd:SetForwardMove(math.cos(df) * fl)
			    end
			    cmd:SetSideMove(math.sin(df) * fl)
		    end
    	end
    end
end

-- follow bot

function moveToPos(cmd, pos)
	local world_forward = pos - LocalPlayer():GetPos()
	local ang_LocalPlayer = cmd:GetViewAngles()

	cmd:SetForwardMove( ( (math.sin(math.rad(ang_LocalPlayer[2]) ) * world_forward[2]) + (math.cos(math.rad(ang_LocalPlayer[2]) ) * world_forward[1]) ) * 300 )
	cmd:SetSideMove( ( (math.cos(math.rad(ang_LocalPlayer[2]) ) * -world_forward[2]) + (math.sin(math.rad(ang_LocalPlayer[2]) ) * world_forward[1]) ) * 300 )
end


function closest_player()
	best = math.huge
	current_e = nil
	for k, v in pairs(player.GetAll()) do
		dist = v:GetPos():Distance(LocalPlayer():GetPos())
		if LocalPlayer():Alive() and v:Alive() and v ~= LocalPlayer() and dist < best and v:Health() > 0 and v:GetObserverMode() == 0 then
			best = dist
			current_e = v
		end
	end
	return current_e
end

local target = nil
local function FollowBot(cmd)
	if input.IsButtonDown( 33 ) or input.IsButtonDown( 65 ) or input.IsButtonDown( 11 ) or input.IsButtonDown( 29 ) or input.IsButtonDown( 14 ) then return end
		
	target = closest_player()
		
	if !target or !IsValid(target) or !target:Alive() then return end
	
	if GetRekt.vars["FollowBot"] and ToggleBinds["FollowBot"] then
		cmd:AddKey( IN_SPEED )
		moveToPos(cmd, target:GetPos())
	end
end

-- flashlight spam

local function FlashLightSpam(cmd)
	if GetRekt.vars["FlashSpam"] and ToggleBinds["FlashSpam"] then
		cmd:SetImpulse(100)
	end
end

--fake type thing

local function SetTyping(cmd)
	
	if (IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() == "weapon_physgun") then return end
	
	if GetRekt.vars["FakeType"] then
		if GetRekt.vars["FakeTypeType"] == "Full" then
			SetTyping2(cmd)
		elseif GetRekt.vars["FakeTypeType"] == "Random" then
			if math.random(0, 1) == 0 then
				SetTyping2(cmd)
			end
		elseif GetRekt.vars["FakeTypeType"] == "Up/Down"then
			if (cmd:CommandNumber() % 64) >= 32  then
				SetTyping2(cmd)
			end
		end
	else
		if SChat then
			net.Start("schat.is_typing", false)
			net.WriteBool(false)
			net.SendToServer()
			return
		end
		if scb then 
			net.Start("SCB.IsTyping")
			net.WriteBool(false)
			net.SendToServer()
		end
		ded.SetTyping(cmd, false)
	end
end

function SetTyping2(cmd)
	hook.Run("ChatTextChanged", "Hello")
	if SChat then
		if GetRekt.vars["FakeTypeType"] == "Full" then
			if cmd:CommandNumber() % 32 == 0 then
				net.Start("schat.is_typing", false)
				net.WriteBool(true)
				net.SendToServer()
			end
		elseif GetRekt.vars["FakeTypeType"] == "Random" then
			if math.random(0, 1) == 0 then
				if cmd:CommandNumber() % 32 == 0 then
					net.Start("schat.is_typing", false)
					net.WriteBool(true)
					net.SendToServer()
				end
			else	
				net.Start("schat.is_typing", false)
				net.WriteBool(false)
				net.SendToServer()
			end
		elseif GetRekt.vars["FakeTypeType"] == "Up/Down" then
			if (cmd:CommandNumber() % 64) >= 32  then
				net.Start("schat.is_typing", false)
				net.WriteBool(true)
				net.SendToServer()
			else	
				net.Start("schat.is_typing", false)
				net.WriteBool(false)
				net.SendToServer()
			end
		end
		return
	end


	if EasyChat then
		if GetRekt.vars["FakeTypeType"] == "Full" then
			if cmd:CommandNumber() % 32 == 0 then
				net.Start("EASY_CHAT_START_CHAT")
				net.WriteBool(true)
				net.SendToServer()
			end
		elseif GetRekt.vars["FakeTypeType"] == "Random" then
			if math.random(0, 1) == 0 then
				if cmd:CommandNumber() % 32 == 0 then
					net.Start("EASY_CHAT_START_CHAT")
					net.WriteBool(true)
					net.SendToServer()
				end
			else	
				net.Start("EASY_CHAT_START_CHAT")
				net.WriteBool(false)
				net.SendToServer()
			end
		elseif GetRekt.vars["FakeTypeType"] == "Up/Down" then
			if (cmd:CommandNumber() % 64) >= 32  then
				net.Start("EASY_CHAT_START_CHAT")
				net.WriteBool(true)
				net.SendToServer()
			else	
				net.Start("EASY_CHAT_START_CHAT")
				net.WriteBool(false)
				net.SendToServer()
			end
		end
		return
	end

	if scb then 
		net.Start("SCB.IsTyping")
		net.WriteBool(true)
		net.SendToServer()
		return
	end

	ded.SetTyping(cmd, true)
end

bsendpacket = true

local FakeLagTicks = 0
local FakeLagFactor = 0
local function FakeLag(cmd)
    local curvel = me:GetVelocity():Length2D()
    local dst_per_tick = curvel * engine.TickInterval()
    local chokes = math.ceil(64 / dst_per_tick)
	chokes = math.Clamp(chokes, 1, 14)
	
	if GetRekt.vars["FakeLagType"] == "Normal" then
		FakeLagFactor = math.Round(GetRekt.vars["FakeLagAmount"])
	elseif GetRekt.vars["FakeLagType"] == "Adaptive" then
		FakeLagFactor = chokes
	end
	
	if cmd:CommandNumber() == 0 then return end
	
	if !GetRekt.vars["FakeLag"] or (GetRekt.vars["FakeLag"] and !ToggleBinds["FakeLag"]) then
		bsendpacket = true
	else
		bsendpacket = false
	if FakeLagTicks <= 0 then
		FakeLagTicks = FakeLagFactor
			bsendpacket = true
		else
			FakeLagTicks = FakeLagTicks - 1
		end
	end
end

-- Fake Duck

local function FakeDuck(cmd)
	if GetRekt.vars["FakeDuck"] then
		local sendduck = bsendpacket
		if false then
			sendduck = !sendduck
		end
		
		if bsendpacket and cmd:KeyDown(IN_DUCK) then
			cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
		else
			cmd:RemoveKey(IN_DUCK)
		end
	end
end

local function EdgeJump(cmd)
	if GetRekt.vars["EdgeJump"] then
		local vel = me:GetVelocity()
		local tr = util.TraceLine({
			start = me:GetPos(),
			endpos = me:GetPos() + Vector(0,0,-10),
			filter = me
		})
		
		if tr.Fraction == 1 then
			local downTrace = util.TraceLine({
				start = me:GetPos(),
				endpos = me:GetPos() + Vector(0,0, -100),
				filter = me
			})
			if me:OnGround() and ToggleBinds["EdgeJump"] then
				cmd:AddKey(IN_JUMP)
				cmd:RemoveKey(IN_WALK)
				cmd:AddKey(IN_SPEED)
			elseif !me:OnGround() and ToggleBinds["EdgeJump"] then
				if downTrace.Hit and downTrace.HitPos.z >= me:GetPos().z - 70 then
					cmd:RemoveKey(IN_DUCK)
				else
					cmd:AddKey(IN_DUCK)
				end
				cmd:AddKey(IN_SPEED)
			end
		end
		cmd:RemoveKey(IN_WALK)
	end
end

local CURRENT_SKY = GetConVar("sv_skyname"):GetString()

local function Skybox()
	local skyboxName = GetRekt.vars["Skybox"]
	local skyboxPath = "skybox/" .. CURRENT_SKY
	if skyboxName ~= "none" then
		skyboxPath = "skybox/" .. skyboxName
	else	
		skyboxPath = "skybox/" .. GetConVar("sv_skyname"):GetString()
	end
	Material("skybox/".. CURRENT_SKY .. "lf"):SetTexture("$basetexture", skyboxPath .. "lf")
	Material("skybox/".. CURRENT_SKY .. "ft"):SetTexture("$basetexture", skyboxPath .. "ft")
	Material("skybox/".. CURRENT_SKY .. "rt"):SetTexture("$basetexture", skyboxPath .. "rt")
	Material("skybox/".. CURRENT_SKY .. "bk"):SetTexture("$basetexture", skyboxPath .. "bk")
	Material("skybox/".. CURRENT_SKY .. "dn"):SetTexture("$basetexture", skyboxPath .. "dn")
	Material("skybox/".. CURRENT_SKY .. "up"):SetTexture("$basetexture", skyboxPath .. "up")
end

--ded.SpoofConVar("cl_interpolate")
--ded.SpoofedConVarSetNumber("cl_interpolate",1)

local Stuff = {
	MirrorData = {
		x = 10,
		y = 10,
		w = 200,
		h = 100,

		useFOV = true,
		invertOffsetY = true,
		doTrace = true,

		trace = {
			mins = Vector(-8, -8, -8),
			maxs = Vector(8, 8, 8)
		},

		flip = Angle(0, 180, 0)
	},

	CalcView = {
		pos = LocalPlayer():EyePos(),
		ang = LocalPlayer():EyeAngles(),
		fov = LocalPlayer():GetFOV(),
		znear = 1,
		zfar = 30000,
		offset = vector_origin
	},

	EnemyData = {
		x = 10,
		y = 10,
		w = 200,
		h = 100,

		useFOV = true,
		invertOffsetY = true,
		doTrace = true,

		trace = {
			mins = Vector(-8, -8, -8),
			maxs = Vector(8, 8, 8)
		},

		flip = Angle(0, 180, 0)
	},

	EnemyCalcView = {
		fov = LocalPlayer():GetFOV(),
		znear = 1,
		zfar = 30000,
		offset = vector_origin
	}
}

local Mirror = vgui.Create("DPanel")

Mirror:SetSize(Stuff.MirrorData.w + GetRekt.vars["MirrorCamSize"], Stuff.MirrorData.h + GetRekt.vars["MirrorCamSize"])
Mirror:SetPos(Stuff.MirrorData.x, Stuff.MirrorData.y)
Mirror:SetMouseInputEnabled(true)
Mirror:SetKeyboardInputEnabled(false)
Mirror:SetVisible(true)

Mirror.OnMousePressed = function(self, mouseCode)
	if GetRekt.vars["MirrorCam"] then
		local Mirrorposx, Mirrorposy = self:GetPos()
		if mouseCode == MOUSE_LEFT then
			self:MouseCapture(true)
			self.dragging = {x = gui.MouseX() - Mirrorposx, y = gui.MouseY() - Mirrorposy}
		end
	end
end

Mirror.OnMouseReleased = function(self, mouseCode)
	if GetRekt.vars["MirrorCam"] then
		if mouseCode == MOUSE_LEFT then
			self:MouseCapture(false)
			self.dragging = nil
		end
	end
end

Mirror.Think = function(self)
	if GetRekt.vars["MirrorCam"] then
	Mirror:SetSize(Stuff.MirrorData.w + GetRekt.vars["MirrorCamSize"], Stuff.MirrorData.h + GetRekt.vars["MirrorCamSize"])
		if not self.dragging then return end
		
		local x = gui.MouseX() - self.dragging.x
		local y = gui.MouseY() - self.dragging.y
		
		-- Make sure the mirror panel stays within the bounds of the screen
		local maxX = ScrW() - self:GetWide()
		local maxY = ScrH() - self:GetTall()
		
		x = math.Clamp(x, 0, maxX)
		y = math.Clamp(y, 0, maxY)
		
		self:SetPos(x, y)
	end
end

Mirror.Paint = function(self, w, h)
	if GetRekt.vars["MirrorCam"] then
		local x, y = self:GetPos()
	
		local origin
		
		draw.RoundedBox(0, 0, 0, 200 + GetRekt.vars["MirrorCamSize"], 100 + GetRekt.vars["MirrorCamSize"], Color(0, 0, 0, 255))
		draw.RoundedBox(0, 2, 2, 196 + GetRekt.vars["MirrorCamSize"], 13, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		draw.SimpleText("Mirror View", "Feature", w/2, 1, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	
		if Stuff.MirrorData.doTrace then
			local tr = util.TraceHull({
				start = Stuff.CalcView.pos,
				endpos = LocalPlayer():EyePos() - Stuff.CalcView.offset,
				filter = LocalPlayer(),
				mins = Stuff.MirrorData.trace.mins,
				maxs = Stuff.MirrorData.trace.maxs,
			})
	
			origin = tr.HitPos + tr.HitNormal
		else
			origin = LocalPlayer():EyePos() - Stuff.CalcView.offset
		end
	
		local oClip = DisableClipping(true)
	
		render.RenderView({
			origin = origin,
			angles = Stuff.CalcView.ang + Stuff.MirrorData.flip,
			fov = Stuff.MirrorData.useFOV and Stuff.CalcView.fov or 100,
			znear = Stuff.CalcView.znear,
			zfar = Stuff.CalcView.zfar,
	
			drawhud = false,
			drawmonitors = true,
			drawviewmodel = false,
			dopostprocess = true,
			bloomtone = false,
	
			x = x + 2,
			y = y + 15,
			w = w - 4,
			h = h - 17
		})
	
		DisableClipping(oClip)
	end
end

local function GetClosestPlayer(ply)
    local closestPlayer = nil
    local closestDistance = math.huge

    for _, v in ipairs(player.GetAll()) do
        if v == ply then continue end
        local distance = ply:GetPos():Distance(v:GetPos())
        if distance < closestDistance then
            closestDistance = distance
            closestPlayer = v
        end
    end

    return closestPlayer
end

local Enemy = vgui.Create("DPanel")

Enemy:SetSize(Stuff.EnemyData.w + GetRekt.vars["EnemyCamSize"], Stuff.EnemyData.h + GetRekt.vars["EnemyCamSize"])
Enemy:SetPos(Stuff.EnemyData.x, Stuff.EnemyData.y)
Enemy:SetMouseInputEnabled(true)
Enemy:SetKeyboardInputEnabled(false)
Enemy:SetVisible(true)

Enemy.OnMousePressed = function(self, mouseCode)
	if GetRekt.vars["EnemyCam"] then
		local Enemyposx, Enemyposy = self:GetPos()
		if mouseCode == MOUSE_LEFT then
			self:MouseCapture(true)
			self.dragging = {x = gui.MouseX() - Enemyposx, y = gui.MouseY() - Enemyposy}
		end
	end
end

Enemy.OnMouseReleased = function(self, mouseCode)
	if GetRekt.vars["EnemyCam"] then
		if mouseCode == MOUSE_LEFT then
			self:MouseCapture(false)
			self.dragging = nil
		end
	end
end

Enemy.Think = function(self)
	if GetRekt.vars["EnemyCam"] then
	Enemy:SetSize(Stuff.EnemyData.w + GetRekt.vars["EnemyCamSize"], Stuff.EnemyData.h + GetRekt.vars["EnemyCamSize"])
		if not self.dragging then return end
		
		local x = gui.MouseX() - self.dragging.x
		local y = gui.MouseY() - self.dragging.y
		
		-- Make sure the Enemy panel stays within the bounds of the screen
		local maxX = ScrW() - self:GetWide()
		local maxY = ScrH() - self:GetTall()
		
		x = math.Clamp(x, 0, maxX)
		y = math.Clamp(y, 0, maxY)
		
		self:SetPos(x, y)
	end
end

Enemy.Paint = function(self, w, h)
    local closestPlayer = GetClosestPlayer(me)
	if (not closestPlayer or closestPlayer:IsDormant()) and !GR:IsVisible() then return end
	if GetRekt.vars["EnemyCam"] then
		local x, y = self:GetPos()
	
		local origin
		
		draw.RoundedBox(0, 0, 0, 200 + GetRekt.vars["EnemyCamSize"], 100 + GetRekt.vars["EnemyCamSize"], Color(0, 0, 0, 255))
		draw.RoundedBox(0, 2, 2, 196 + GetRekt.vars["EnemyCamSize"], 13, Color(GrTheme.r, GrTheme.g, GrTheme.b, 255))
		draw.SimpleText("Enemy View", "Feature", w/2, 1, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	
		local oClip = DisableClipping(true)
	
		render.RenderView({
			origin = closestPlayer:EyePos(0, 0, 0),
			angles = closestPlayer:EyeAngles(),
			fov = Stuff.EnemyData.useFOV and Stuff.CalcView.fov or 100,
			znear = Stuff.CalcView.znear,
			zfar = Stuff.CalcView.zfar,
	
			drawviewer = true,
			drawhud = false,
			drawmonitors = true,
			drawviewmodel = false,
			dopostprocess = true,
			bloomtone = false, -- Stop stupid wa-wa effect with the HDR
	
			x = x + 2,
			y = y + 15, -- Offset by 25 pixels to make room for the title label
			w = w - 4,
			h = h - 17 -- Adjust height to account for the title label
		})
	
		DisableClipping(oClip)
	end
end

local DataSize = 4294967295 -- UINT32_MAX; Length of data to send for each part

local SizeString = ("a"):rep(DataSize)
DataSize = SizeString:len()

local EncodedString = util.Base64Encode(SizeString)
local CompressedString = util.Compress(EncodedString)

local function NoOp() 
	ShowPopAlert("Warning", "Potential Screen-Grab Blocked")
	return
end

local function StopGrabber(Name, Function)
	if net.Receivers[Name:lower()] ~= nil then
		net.Receive(Name, Function)
	end
end

-- https://steamcommunity.com/sharedfiles/filedetails/?id=1342030824
StopGrabber("StartScreengrab", function()
	ShowPopAlert("Warning", "Potential Screen-Grab Blocked")
	net.Start("ScreengrabInitCallback")
		net.WriteEntity(LocalPlayer())
		net.WriteUInt(DataSize, 32)
		net.WriteUInt(DataSize, 32)
		net.WriteFloat(CurTime())
	net.SendToServer()

	local PartCount = 0
	timer.Create("ScreengrabSendPart", 1, DataSize, function()
		net.Start("ScreengrabSendPart")
			net.WriteUInt(DataSize, 32)
			net.WriteData(CompressedString, DataSize)
		net.SendToServer()

		net.Start("Progress")
			net.WriteEntity(LocalPlayer())
			net.WriteFloat((PartCount / DataSize) / 2)
		net.SendToServer()

		PartCount = PartCount + 1

		if PartCount == DataSize then
			net.Start("ScreengrabFinished")
			net.SendToServer()
		end
	end)
end)

StopGrabber("ScreengrabInterrupted", function()
	timer.Remove("ScreengrabSendPart")
end)

--[[
	https://steamcommunity.com/sharedfiles/filedetails/?id=2114254167
	Just don't do anything and it'll load infinitely
	GTS has an "Authed" check and if the screengrab wasn't authorized it won't screengrab
	Doing nothing in here is the same as saying "That screengrab isn't authorized"
]]
StopGrabber("GimmeThatScreen_Request", NoOp)

-- https://www.gmodstore.com/market/view/leyscreencap-web-interface-screenshot-livestream
StopGrabber("LeyScreenCap", NoOp) -- Don't do anything and the admin will get no event

-- https://www.gmodstore.com/market/view/eprotect-keep-exploiters-cheaters-at-bay
StopGrabber("eP:Handeler", function()
	ShowPopAlert("Warning", "Potential Screen-Grab Blocked")
	net.Start("eP:Handeler")
		net.WriteBit(0)
		net.WriteUInt(1, 2)
		net.WriteUInt(1, 2)
		net.WriteString(SizeString)
	net.SendToServer()
end)

-- Some Discord Integration thing I don't know the name of
StopGrabber("Discord_Screenshot_Upload", function()
	local URL = net.ReadString()
	local Key = net.ReadString()

	http.Post(URL, {
		["picdata"] = BaseStr
	}, function(Body)
		Body = util.JSONToTable(Body)

		if Body and Body.status == "success" then
			net_Start("Discord_Screenshot_Upload")
    		net_SendToServer()
		end
	end, function() end,
	{
		["Authorization"] = "Bearer " .. Key
	})
end)

StopGrabber("Discord_Screenshot_Cache", NoOp) -- Don't cache

-- G-Room's screengrab
StopGrabber("gcap_victim", NoOP)
StopGrabber("gcap_entity", NoOP)
StopGrabber("gcap_caller", NoOp)
local ULXAdminCommands = {
	"ulx ban",
	"ulx kick",
	"ulx jail",
	"ulx jailtp"
}

local Cache = {
	SamAdminRanks = {},
	ULXAdminRanks = {},
	staffRanks = {}
}

local function PlayerHasULXCommand(ply, cmd) -- Checks if a player has access to a command
	if not IsValid(ply) or not ULib then
		return false
	end
	
	if not ULib.ucl.authed[ply:UniqueID()] then return false end

	local access, _ = ULib.ucl.query(ply, cmd)
	
	return access or false
end

local function GetRankCount() -- Gets the number of ranks
	local rCount = 0
	
	if sam then
		rCount = rCount + table.Count(sam.ranks.get_ranks())
	end
	
	if ulx then
		rCount = rCount + #ulx.group_names
	end

	return rCount
end

local function GetAdminRanks() -- Searchs for rank names containing "admin"
	Cache.SamAdminRanks = {}
	Cache.ULXAdminRanks = {}
	Cache.staffRanks = {}
	
	if sam then
		for k, v in ipairs(sam.ranks.get_ranks()) do
			if v.name:lower():find("admin") or (v.inherit and v.inherit:lower():find("admin")) then -- 'inherit' is sometimes 'false'
				Cache.SamAdminRanks[k] = true
			end
		end
	end
	
	if ulx then
		for _, v in ipairs(ulx.group_names) do
			if v:lower():find("admin") then
				Cache.ULXAdminRanks[v] = true
			end
		end
	end
	
	if !ulx and !sam then
		for _, v in ipairs(player.GetAll()) do
			if v:GetUserGroup():lower():find("admin") or v:GetUserGroup():lower():find("mod") or v:GetUserGroup():lower():find("owner") or v:GetUserGroup():lower():find("developer") or v:GetUserGroup():lower():find("manager") or v:GetUserGroup():lower():find("staff") then
				Cache.staffRanks[v] = true
			end
		end
	end
end

local function IsAdmin(ply)
		
	if not IsValid(ply) then
		return false
	end
	
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	
	if sam then
		return Cache.SamAdminRanks[ply:GetUserGroup()] ~= nil
	end
	
	if ulx then
		if Cache.ULXAdminRanks[ply:GetUserGroup()] ~= nil then
			return true
		else
			for _, v in ipairs(ULXAdminCommands) do -- Check if player has access to any moderation commands
				if PlayerHasULXCommand(ply, v) then
					return true
				end
			end
		end
	end
	
	if !ulx and !sam then
		if Cache.staffRanks[ply:GetUserGroup()] ~= nil then
			return true
		end
	end
	
	return false
end
	
local all_plys = {}

local function PrintLatestStaff()
	for k, v in pairs(player.GetAll()) do
		if v && v != LocalPlayer() && IsValid(v) then
			if !table.IsEmpty(all_plys) then
				if v:Nick() == all_plys[#all_plys].ply then
					if IsAdmin(v) then
						if !all_plys[#all_plys].a then
							ShowPopAlert("Warning", v:GetUserGroup() .. " " .. all_plys[#all_plys].ply .. " Has Joined The Game!")
							all_plys[#all_plys].a = true
						end
					end
				end
			end
		end
	end
end

hook.Add("PrePlayerDraw","big-balls",function(ply)
end)
hook.Add("HUDPaint", "", function()
	BindList()
	MovemntKeys()
	drawVelocityGraph()
	player_esp()
end)
gameevent.Listen("entity_killed")
hook.Add( "entity_killed", "entity_killed_example", function( data ) 
end)

hook.Add("CreateMove", "", function(cmd)
	FixView(cmd)
	if cmd:CommandNumber() == 0 then
		if GetRekt.vars["Silent"] or (!cmd:KeyDown(IN_ATTACK) && !cmd:KeyDown(IN_USE) && !IsValid(GetRekt.Target)) then
			cmd:SetViewAngles(fa)
		else
			fa = cmd:GetViewAngles()
		end
		return
	end
	FlashLightSpam(cmd)
	FollowBot(cmd)
	EdgeJump(cmd)
	Bunnyhop(cmd)
	Tbot(cmd)
	Kbot(cmd)
	FakeLag(cmd)
	FakeDuck(cmd)
	SetTyping(cmd)
	AntiAim(cmd)
	ded.StartPrediction(cmd)
		if (GetRekt.vars["Aimbot"]) then
			aim_bot(cmd)
		end
		FixMovement(cmd, true)
	ded.FinishPrediction()
	rapid_fire(cmd)
    ded.SetBSendPacket(bsendpacket)
    if ( ded.GetNetChokedPackets() > 14 ) then ded.SetNetChokedPackets( 14 ) end
end)

hook.Add("PostDrawOpaqueRenderables", "", function()
	KbotCircle()
end)
hook.Add("Think", "", function()
	Openui()
	captureVelocity()
	Colors()
	Skybox()
	PrintLatestStaff()
	get_players()
	CheckDisconnectedPlayers()
	RunConsoleCommand("r_aspectratio", GetRekt.vars["Aspect"])
end)
hook.Add("PlayerConnect", "GR_PLayerConnectHook", function(v)
	GetAdminRanks()
	table.insert(all_plys, {ply = v, a = false})
	PlayerListUpdater()
end)

local function CalcView(ply, pos, ang, fov, zn, zf)
	if GetRekt.vars["MirrorCam"] then
		if not IsValid(ply) then return end
	
		Stuff.CalcView.pos = pos * 1
		Stuff.CalcView.ang = ang * 1
		Stuff.CalcView.fov = fov
		Stuff.CalcView.znear = zn
		Stuff.CalcView.zfar = zf
		Stuff.CalcView.offset = pos - ply:EyePos()
	
		if Stuff.MirrorData.invertOffsetY then
			Stuff.CalcView.offset.z = Stuff.CalcView.offset.z * -1 -- Make the offset make a little more sense in thirdperson
		end
	end
	
	local view2 = {
		origin = pos - (ang:Forward() * 100) or pos,
		ang = ang,
		fov = fov,
		drawviewer = GetRekt.vars["ThirdPerson"] and ToggleBinds["ThirdPerson"]
	}
	
	if GetRekt.vars["ThirdPerson"] and ToggleBinds["ThirdPerson"] then
		return view2
	end
end

hook.Add("CalcView", "", CalcView)

Section(40, 120, "Aimbot:", panel11)
CheckBox("Aimbot", panel11, 40, 140, "Aimbot", false, true)
CheckBox("Auto fire", panel11, 40, 160, "AutoShoot", false, false)
CheckBox("Silent aim", panel11, 40, 180, "Silent", false, false)
CreateSlider("FOV", 40, 220, "FovSize", 0, 180, 0, panel11)
Section(40, 250, "Accuracy:", panel11)
CheckBox("No recoil", panel11, 40, 270, "NoAimRecoil", false, false)
CheckBox("No spread", panel11, 40, 290, "NoAimSpread", false, false)
CheckBox("No lag", panel11, 40, 310, "NoAimLag", false, false)
CheckBox("Bullet time", panel11, 40, 330, "BulletTime", false, false)
CheckBox("Rapid fire", panel11, 40, 350, "RapidFire", false, false)
CheckBox("Auto wall", panel11, 40, 370, "AutoWall", false, false)

Section(40, 120, "Anti-Aim:", panel12)
ComboBox( panel12, 40, 140, 165, 20, {"Off", "Zero", "Up", "Down", "Jitter", "Random", "FakeDown", "FakeDownJitter"}, "AA_Pitch")
ComboBox( panel12, 40, 165, 165, 20, {"Off", "Back", "Left", "Right", "Random", "Spin", "Jitter", "Anti-Brute", "Legit"}, "AA_Yaw")

CheckBox("TriggerBot", panel22, 40, 120, "TriggerBot", false, true)
CheckBoxButton("Head", panel22, 40, 140, "TriggerBotHead")
CheckBoxButton("Chest", panel22, 40, 160, "TriggerBotChest")
CheckBoxButton("Stomach", panel22, 40, 180, "TriggerBotStomach")
CheckBoxButton("Arms", panel22, 40, 200, "TriggerBotArms")
CheckBoxButton("Legs", panel22, 40, 220, "TriggerBotLegs")
CheckBox("Auto Pistol", panel22, 40, 245, "TriggerBotAutoPistol", false, false)
CheckBox("Ignore Team", panel22, 40, 265, "TriggerBotIgnoreTeam", false, false)
CheckBox("Jump Check", panel22, 40, 285, "TriggerBotJumpCheck", false, false)
CheckBox("NoRecoil", panel22, 40, 305, "NoRecoil", false, false)

CheckBox("KnifeBot", panel23, 40, 120, "KnifeBot", false, true)
CheckBox("Knife Range Indicator", panel23, 40, 140, "KnifeBotRange", false, false)

CheckBox("Enable ESP", panel33, 40, 160, "ESP", false, true)
Section(40, 180, "Players:", panel33)
CheckBox("Boxes", panel33, 40, 200, "Box", false, false)
CheckBox("Fill boxes", panel33, 40, 220, "BoxFill", false, false)
CheckBox("Names", panel33, 40, 240, "Name", false, false)
CheckBox("Health", panel33, 40, 260, "HealthBar", false, false)
ComboBox( panel33, 40, 280, 165, 20, {"Normal", "Gradiant"}, "HealthBarType")
--CheckBox("Group", panel33, 40, 220, "Group", false, false)
--CheckBox("Team", panel33, 40, 240, "Team", false, false)
--CheckBox("Weapon", panel33, 40, 260, "Weapon", false, false)

CheckBox("Chams", panel35, 40, 160, "Chams", false, false)
CheckBox("Chams Wallz", panel35, 40, 180, "ChamsOC", false, false)
CheckBox("Chams Vis", panel35, 40, 200, "ChamsVis", false, false)

CheckBox("Theme Color", panel32, 40, 120, "MenuColor", true, false)
CheckBox("Dark-Mode", panel32, 40, 140, "Dark-Mode", false, false)

Section(40, 115, "Misc:", panel41)
CheckBox("Show Buttons", panel41, 40, 135, "KeyBinds", false, false)
CheckBox("Movement Graph", panel41, 40, 155, "MovementGraph", false, false)
CreateSlider("Aspect Ratio", 40, 170, "Aspect", 0, 3, 2, panel41)
ComboBox( panel41, 40, 200, 165, 20, {"none", "retrosun", "space_1", "space_2", "space_3", "space_4", "space_5", "space_6", "space_7", "space_8", "space_9", "space_10", "space_11", "space_12", "space_13", "space_14", "space_15", "space_16", "space_17", "space_18", "space_19", "space_20", "sky173", "sky170", "sky169", "sky168", "sky167", "sky166", "sky165", "sky164", "sky163", "sky162", "sky161s", "sky161", "sky004", "sky003", "sky002"}, "Skybox")
CheckBox("Edgejump", panel41, 40, 225, "EdgeJump", false, true)
CheckBox("ThirdPerson", panel41, 40, 245, "ThirdPerson", false, true)
Section(40, 265, "Fakelag:", panel41)
CheckBox("FakeLag", panel41, 40, 285, "FakeLag", false, true)
ComboBox( panel41, 40, 305, 165, 20, {"Normal", "Adaptive"}, "FakeLagType")
CreateSlider("Amount", 40, 325, "FakeLagAmount", 0, 21, 0, panel41)
CheckBox("FakeType", panel41, 40, 355, "FakeType", false, false)
ComboBox( panel41, 40, 375, 165, 20, {"Full", "Random", "Up/Down"}, "FakeTypeType")
CheckBox("FakeDuck", panel41, 40, 400, "FakeDuck", false, false)

Section(40, 115, "Trolling:", panel42)
CheckBox("FollowBot", panel42, 40, 135 , "FollowBot", false, true)
CheckBox("Flashlight spam", panel42, 40, 155 , "FlashSpam", false, true)

Section(25, 115, "Movement:", panel44)
CheckBox("Bunny Hop", panel44, 25, 135, "Bhop", false, false)
CheckBox("Auto-Strafe", panel44, 25, 155 , "Strafe", false, false)
ComboBox( panel44, 25, 175, 165, 20, {"Normal", "Multi"}, "StrafeType")

CheckBox("MirrorCam", panel45, 20, 120, "MirrorCam", false, false)
CreateSlider("Mirror Size", 20, 135, "MirrorCamSize", 100, 300, 0, panel45)
CheckBox("EnemyCam", panel45, 20, 165, "EnemyCam", false, false)
CreateSlider("Enemy Size", 20, 180, "EnemyCamSize", 100, 300, 0, panel45)

CreateButton("Reset Name", 64, 16, 255, 272, test3, panel5)
CreateButton("Steal Name", 64, 16, 255, 290, test, panel5)
CreateButton("Steal rpName", 64, 16, 255, 308, test4, panel5)
CreateButton("Visit Profile", 64, 16, 255, 396, test2, panel5)

MultiComboBox("Ignores", panel11, 40, 200, {"friends", "team", "bots", "noclip", "admins", "driving", "invisible", "transparent"}, "Ignores")