--[[
	Jackson Cheat (proxi edition)
	
	Credits: 
		flarose
		homonovus
		black
		solum
	
	TODO:
		make c strafe adaptive
		fix panel scroll while slider scrolling
		add smooth scrolling
		fix whitelist issue
		fix antiaim breaking when poseparms are passed
		improve on-shot backtrack
]]

require("proxi")
if not proxi then return end

local Data = {
	Environment = {
		_G = _G or getfenv(1),
		_R = proxi._R,

		proxi = proxi,
		net = net,

		ArcCW = ArcCW,

		Vars = {
			Aimbot = {
				Enabled = false,
				Key = KEY_NONE,
				Silent = false,
				FireOnKey = false,
				UseContext = false,

				SlowFire = {
					Enabled = false,
					Time = 0
				},

				HitChance = 0,

				MultiPoint = false,
				TickMod = false,

				SortMethod = 1,

				AimCone = {
					Enabled = false,
					Shape = "Circle",
					FOV = 0,
					Color = nil
				},

				TriggerBot = {
					Enabled = false,
					HitBacktrack = false,
					AutoWall = false,
					OnCrosshair = false,
					ForcePacket = false
				},

				NoSpread = {
					Enabled = false,
					UseContext = false,
					NoRecoil = false,
					ForceSeed = {
						Enabled = false,
						Seed = 0
					}
				},

				Backtrack = {
					Enabled = false,
					Amount = 0,
					AbuseInterp = false,
					Method = 0
				},

				Resolver = false,

				WhiteList = {
					IgnorePlayers = false,
					IgnoreNextBots = false,
					IgnoreNpcs = false,
				},

				Friends = {},

				AimAtHitboxes = 1
			},

			HvH = {
				AntiAim = {
					Enabled = false,

					Pitch = 0,

					RealYaw = 0, -- im annoyed because AntiAim.Yaw is SOMEHOW A FUCKING NUMBER WHEN IT WAS A TABLE
					FakeYaw = 0,

					CustomPitch = 0,

					CustomYaw = {
						Real = 0,
						Fake = 0
					},

					FollowTarget = false,

					SpinSpeed = 0,

					Edge = {
						Enabled = false,
						Fake = false,
						Wall = 0,
						Corner = 0
					},

					LbyBreaker = {
						Enabled = false,
						Delta = 0,
						LastBreak = 0
					}
				},

				FakeLag = {
					Enabled = false,
					Choke = 0,
					Method = 1
				},

				FakeDuck = {
					Enabled = false,
					Key = KEY_NONE
				},

				FakeAct = {
					Enabled = false,
					Gesture = 0
				}
			},

			ESP2D = {
				Player = {
					Enabled = false,
					Color = nil,

					Box2D = false,
					Box3D = false,
					Name = false,
					Weapon = false,
					Health = false,
					Armor = false,
					Skeleton = false,
					Avatar = false,

					Outline = {
						Enabled = false,
						Color = nil
					}
				},

				Entity = {
					Enabled = false,
					Color = nil,

					Box2D = false,
					Box3D = false,
					Name = false,
					Weapon = false,
					Health = false,
					Armor = false,
					Skeleton = false,

					Outline = {
						Enabled = false,
						Color = nil
					}
				},

				DebugInfo = false
			},

			ESP3D = {
				Chams = {
					Player = {
						Enabled = false,

						Color = nil,
						Material = "off",

						OverLay = {
							Enabled = true,
							Color = nil,
							Material = "off"
						}
					},

					Entity = {
						Enabled = false,

						Color = nil,
						Material = "off",

						OverLay = {
							Enabled = true,
							Color = nil,
							Material = "off"
						}
					},

					ViewModel = {
						Enabled = false,
						Color = nil,
						Material = "off",
					}
				},

				Backtrack = {
					Enabled = false,
					VisualStyle = 0,

					Colors = {
						Start = nil,
						End = nil
					},

					Material = "off"
				},

				HitBoxes = {
					Enabled = false,
					BoundingBox = false,
					LocalPlayer = false,
					Color = nil
				},

				BulletTracers = {
					Enabled = false,
					Material = "",
					DieTime = 0
				},
			},

			Misc = {
				Movement = {
					Bhop = false,
					AutoStrafe = {
						Enabled = false,
						Mode = 0
					},

					CircleStrafe = {
						Enabled = false,
						Key = KEY_NONE
					}
				},

				ThirdPerson = {
					Enabled = false,
					KeyCode = KEY_NONE,
					Distance = 0
				},

				Freeze = {
					DoubleTap = false,
					Teleport = false,
					TeleportKey = KEY_NONE
				},

				AutoClicker = {
					RapidFire = {
						Enabled = false,
						ToolGun = false
					},
					UseSpam = false,
					FlashlightSpam = false
				},

				CustomFOV = {
					Enabled = false,
					FOV = 0
				}
			},

			BindToggleModes = {},
			EntityClasses = {},
			MenuColors = {},
			Whitelist = {}
		},

		g_pCachedMenu = nil,
		g_pConfigList = nil,
		g_pEnvFrame = nil,
		g_pEnvPlayerList = nil,
		g_pEnvEntityList = nil,
		g_pEnvHookList = nil,
		g_pEnvBlockedHookList = nil,

		g_qFacingAngle = nil,
		g_qPunchAngle = nil,
		g_qPunchAngleVel = nil,

		g_nChokedPackets = 0,

		-- g_bSafeMode = false,
		g_bSendPacket = true,
		g_bShouldEngineViewAngles = true,
		g_bNoPlayerInterp = false,
		g_bSequenceRan = false,
		g_bInEnginePrediction = false,

		g_tPlayers = {},
		g_tEntities = {},
		g_tEnums = {},
		g_tModules = {},
		g_tLocalHooks = {},
		g_tWeaponSpreadSeeds = {},
		g_tWeaponSpreadCones = {},
		g_tCalcViewData = {},
		g_tRhombusData = {},
		g_tAlreadyXOR = {},
		g_tXORToRegular = {},
		g_tKnownEntities = {},

		TICK_INTERVAL = 0,
		M_HPI = 0,
		INT_MAX = 0,

		SCREEN_HEIGHT = 0,
		SCREEN_WIDTH = 0,
		SCREEN_CENTER_X = 0,
		SCREEN_CENTER_Y = 0,

		color_white = nil,
		color_black = nil,
		color_red = nil,
		color_blue = nil,
		color_green = nil,
		color_orange = nil,
		color_gray = nil,
		color_pink = nil,
		color_crimson = nil,
		color_lavender = nil,
		color_purple = nil,
		color_teal = nil,
		color_seafoam = nil,
		color_rainbow = nil,

		GetConVar = proxi.GetConVar
	}
}

--proxi = nil -- UNDETECTED

do
	local ENV = Data.Environment

	ENV.rawget = rawget(ENV._G, "rawget")
	ENV.getfenv = ENV.rawget(ENV._G, "getfenv")
	ENV.setfenv = ENV.rawget(ENV._G, "setfenv")
	ENV.type = ENV.rawget(ENV._G, "type")

	ENV.table = {
		Copy = ENV.rawget(ENV._G.table, "Copy")
	}

	function ENV.RegisterFunction(Function)
		return ENV.setfenv(Function, ENV)
	end

	function ENV.CreateFunction(Name, Function)
		ENV[Name] = ENV.RegisterFunction(Function)
	end

	ENV.CreateFunction("Localize", function(...)
		local Parameters = {...}
		local Found = false
		local Last = "_"
		local Cur = _G
		local LastTable = ENV
		local CurTable = ENV

		for i = 1, #Parameters do
			local v = Parameters[i]

			Last = Cur
			Cur = Cur[v]

			if type(Cur) == "table" then
				CurTable[v] = rawget(CurTable, v) or {}

				LastTable = CurTable
				CurTable = CurTable[v]
				Last = v
			else
				CurTable[v] = Cur
				Found = true

				break
			end
		end

		if not Found then
			LastTable[Last] = table.Copy(Cur)
		end
	end)

	-- Enums
	ENV.Localize("_MODULES")
	ENV.Localize("ACT_GMOD_GESTURE_AGREE")
	ENV.Localize("ACT_GMOD_GESTURE_BECON")
	ENV.Localize("ACT_GMOD_GESTURE_BOW")
	ENV.Localize("ACT_GMOD_TAUNT_CHEER")
	ENV.Localize("ACT_GMOD_TAUNT_DANCE")
	ENV.Localize("ACT_GMOD_GESTURE_DISAGREE")
	ENV.Localize("ACT_SIGNAL_FORWARD")
	ENV.Localize("ACT_SIGNAL_GROUP")
	ENV.Localize("ACT_SIGNAL_HALT")
	ENV.Localize("ACT_GMOD_TAUNT_LAUGH")
	ENV.Localize("ACT_GMOD_TAUNT_MUSCLE")
	ENV.Localize("ACT_GMOD_TAUNT_PERSISTENCE")
	ENV.Localize("ACT_GMOD_TAUNT_ROBOT")
	ENV.Localize("ACT_GMOD_TAUNT_SALUTE")
	ENV.Localize("ACT_GMOD_GESTURE_WAVE")
	ENV.Localize("ACT_GMOD_GESTURE_TAUNT_ZOMBIE")
	ENV.Localize("BONE_ALWAYS_PROCEDURAL")
	ENV.Localize("BONE_PHYSICALLY_SIMULATED")
	ENV.Localize("BONE_PHYSICS_PROCEDURAL")
	ENV.Localize("BONE_USED_BY_HITBOX")
	ENV.Localize("EF_NODRAW")
	ENV.Localize("FILL")
	ENV.Localize("FL_ONGROUND")
	ENV.Localize("GESTURE_SLOT_CUSTOM")
	ENV.Localize("GESTURE_SLOT_VCD")
	ENV.Localize("HITGROUP_CHEST")
	ENV.Localize("HITGROUP_GEAR")
	ENV.Localize("HITGROUP_GENERIC")
	ENV.Localize("HITGROUP_HEAD")
	ENV.Localize("HITGROUP_STOMACH")
	ENV.Localize("HITGROUP_RIGHTLEG")
	ENV.Localize("IN_ATTACK")
	ENV.Localize("IN_ATTACK2")
	ENV.Localize("IN_DUCK")
	ENV.Localize("IN_JUMP")
	ENV.Localize("IN_RELOAD")
	ENV.Localize("IN_SPEED")
	ENV.Localize("IN_USE")
	ENV.Localize("IN_ZOOM")
	ENV.Localize("KEY_E")
	ENV.Localize("KEY_R")
	ENV.Localize("LEFT")
	ENV.Localize("MASK_SHOT")
	ENV.Localize("MAT_SAND")
	ENV.Localize("MAT_DIRT")
	ENV.Localize("MAT_METAL")
	ENV.Localize("MAT_TILE")
	ENV.Localize("MAT_WOOD")
	ENV.Localize("MAT_SLOSH")
	ENV.Localize("MOUSE_RIGHT")
	ENV.Localize("MOVETYPE_NOCLIP")
	ENV.Localize("MOVETYPE_WALK")
	ENV.Localize("NODOCK")
	ENV.Localize("OBS_MODE_NONE")
	ENV.Localize("RENDERMODE_NORMAL")
	ENV.Localize("TEXT_ALIGN_CENTER")
	ENV.Localize("TEXT_ALIGN_BOTTOM")
	ENV.Localize("BOTTOM")
	ENV.Localize("RENDERMODE_TRANSALPHA")
	ENV.Localize("RIGHT")
	ENV.Localize("TOP")
	ENV.Localize("MOUSE_WHEEL_UP")
	ENV.Localize("MOUSE_WHEEL_DOWN")

	ENV.Localize("angle_zero")
	ENV.Localize("vector_origin")

	-- Functions
	ENV.Localize("Angle")
	ENV.Localize("Color")
	ENV.Localize("ColorAlpha")
	ENV.Localize("CompileString")
	ENV.Localize("CreateMaterial")
	ENV.Localize("CurTime")
	ENV.Localize("DermaMenu")
	ENV.Localize("Derma_StringRequest")
	ENV.Localize("Derma_Query")
	ENV.Localize("DevMsg")
	ENV.Localize("Entity")
	ENV.Localize("Error")
	ENV.Localize("EyePos")
	ENV.Localize("EyeVector")
	ENV.Localize("FrameNumber")
	ENV.Localize("HSVToColor")
	ENV.Localize("ipairs")
	ENV.Localize("IsValid")
	ENV.Localize("IsFirstTimePredicted")
	ENV.Localize("Lerp")
	ENV.Localize("LerpCW20")
	ENV.Localize("LerpVector")
	ENV.Localize("LocalPlayer")
	ENV.Localize("Material")
	ENV.Localize("MsgC")
	ENV.Localize("MsgN")
	ENV.Localize("Next")
	ENV.Localize("pairs")
	ENV.Localize("player")
	ENV.Localize("PrintTable")
	ENV.Localize("rawset")
	ENV.Localize("FrameTime")
	ENV.Localize("RunString")
	ENV.Localize("RealFrameTime")
	ENV.Localize("ScrH")
	ENV.Localize("ScrW")
	ENV.Localize("SortedPairs")
	ENV.Localize("STENCIL_ALWAYS")
	ENV.Localize("STENCIL_EQUAL")
	ENV.Localize("STENCIL_KEEP")
	ENV.Localize("STENCIL_REPLACE")
	ENV.Localize("SysTime")
	ENV.Localize("Vector")
	ENV.Localize("VectorRand")
	ENV.Localize("assert")
	ENV.Localize("collectgarbage")
	ENV.Localize("getinfo")
	ENV.Localize("getupvalue")
	ENV.Localize("getupvalues")
	ENV.Localize("ipairs")
	ENV.Localize("isbool")
	ENV.Localize("isvector")
	ENV.Localize("isfunction")
	ENV.Localize("isstring")
	ENV.Localize("istable")
	ENV.Localize("isentity")
	ENV.Localize("isnumber")
	ENV.Localize("ispanel")
	ENV.Localize("module")
	ENV.Localize("next")
	ENV.Localize("print")
	ENV.Localize("rawset")
	ENV.Localize("setmetatable")
	ENV.Localize("tobool")
	ENV.Localize("tonumber")
	ENV.Localize("tostring")
	ENV.Localize("unpack")
	ENV.Localize("xpcall")

	-- Libraries
	ENV.Localize("bit", "band")
	ENV.Localize("bit", "bor")
	ENV.Localize("bit", "bxor")
	ENV.Localize("bit", "lshift")
	ENV.Localize("bit", "rshift")
	ENV.Localize("cam", "End2D")
	ENV.Localize("cam", "End3D")
	ENV.Localize("cam", "IgnoreZ")
	ENV.Localize("cam", "Start2D")
	ENV.Localize("cam", "Start3D")
	ENV.Localize("concommand", "Add")
	ENV.Localize("concommand", "Remove")
	ENV.Localize("coroutine", "create")
	ENV.Localize("coroutine", "resume")
	ENV.Localize("coroutine", "yield")
	ENV.Localize("debug", "setmetatable")
	ENV.Localize("debug", "getinfo")
	ENV.Localize("debugoverlay", "Box")
	ENV.Localize("debugoverlay", "Cross")
	ENV.Localize("debugoverlay", "Line")
	ENV.Localize("debugoverlay", "Text")
	ENV.Localize("debugoverlay", "Sphere")
	ENV.Localize("draw", "NoTexture")
	ENV.Localize("draw", "SimpleText")
	ENV.Localize("drive", "CalcView")
	ENV.Localize("engine", "TickCount")
	ENV.Localize("engine", "TickInterval")
	ENV.Localize("ents", "FindByClass")
	ENV.Localize("ents", "GetAll")
	ENV.Localize("ents", "GetByIndex")
	ENV.Localize("file", "CreateDir")
	ENV.Localize("file", "Delete")
	ENV.Localize("file", "Exists")
	ENV.Localize("file", "Find")
	ENV.Localize("file", "IsDir")
	ENV.Localize("file", "Read")
	ENV.Localize("file", "Time")
	ENV.Localize("file", "Write")
	ENV.Localize("file", "Open")
	ENV.Localize("game", "GetAmmoName")
	ENV.Localize("game", "GetWorld")
	ENV.Localize("game", "SinglePlayer")
	ENV.Localize("game", "GetMap")
	ENV.Localize("gameevent", "Listen")
	ENV.Localize("gui", "EnableScreenClicker")
	ENV.Localize("gui", "IsGameUIVisible")
	ENV.Localize("gui", "OpenURL")
	ENV.Localize("gui", "IsConsoleVisible")
	ENV.Localize("hook", "Add")
	ENV.Localize("hook", "GetTable")
	ENV.Localize("hook", "Remove")
	ENV.Localize("hook", "Run")
	ENV.Localize("input", "GetCursorPos")
	ENV.Localize("input", "IsButtonDown")
	ENV.Localize("input", "IsKeyTrapping")
	ENV.Localize("input", "GetKeyName")
	ENV.Localize("input", "WasMousePressed")
	ENV.Localize("language", "GetPhrase")
	ENV.Localize("math", "asin")
	ENV.Localize("math", "AngleDifference")
	ENV.Localize("math", "Clamp")
	ENV.Localize("math", "Distance")
	ENV.Localize("math", "NormalizeAngle")
	ENV.Localize("math", "Round")
	ENV.Localize("math", "Truncate")
	ENV.Localize("math", "abs")
	ENV.Localize("math", "acos")
	ENV.Localize("math", "angle")
	ENV.Localize("math", "atan")
	ENV.Localize("math", "atan2")
	ENV.Localize("math", "ceil")
	ENV.Localize("math", "cos")
	ENV.Localize("math", "deg")
	ENV.Localize("math", "floor")
	ENV.Localize("math", "fmod")
	ENV.Localize("math", "huge")
	ENV.Localize("math", "max")
	ENV.Localize("math", "min")
	ENV.Localize("math", "pi")
	ENV.Localize("math", "pow")
	ENV.Localize("math", "rad")
	ENV.Localize("math", "Rand")
	ENV.Localize("math", "random")
	ENV.Localize("math", "randomseed")
	ENV.Localize("math", "sin")
	ENV.Localize("math", "sqrt")
	ENV.Localize("math", "tan")
	ENV.Localize("net", "Receive")
	ENV.Localize("os", "date")
	ENV.Localize("package", "loaded")
	ENV.Localize("package", "seeall")
	ENV.Localize("player", "GetAll")
	ENV.Localize("player", "GetCount")
	ENV.Localize("player_manager", "GetPlayerClasses")
	ENV.Localize("player_manager", "RunClass")
	ENV.Localize("render", "Clear")
	ENV.Localize("render", "CopyRenderTargetToTexture")
	ENV.Localize("render", "DrawBeam")
	ENV.Localize("render", "DrawScreenQuad")
	ENV.Localize("render", "DrawScreenQuadEx")
	ENV.Localize("render", "DrawWireframeBox")
	ENV.Localize("render", "GetBlend")
	ENV.Localize("GetRenderTarget")
	ENV.Localize("render", "GetRenderTarget")
	ENV.Localize("render", "GetScreenEffectTexture")
	ENV.Localize("render", "GetViewSetup")
	ENV.Localize("render", "MaterialOverride")
	ENV.Localize("render", "SetColorModulation")
	ENV.Localize("render", "SetBlend")
	ENV.Localize("render", "SetMaterial")
	ENV.Localize("render", "SetRenderTarget")
	ENV.Localize("render", "SetStencilCompareFunction")
	ENV.Localize("render", "SetStencilEnable")
	ENV.Localize("render", "SetStencilFailOperation")
	ENV.Localize("render", "SetStencilPassOperation")
	ENV.Localize("render", "SetStencilReferenceValue")
	ENV.Localize("render", "SetStencilTestMask")
	ENV.Localize("render", "SetStencilWriteMask")
	ENV.Localize("render", "SetStencilZFailOperation")
	ENV.Localize("render", "SuppressEngineLighting")
	ENV.Localize("render", "RenderView")
	ENV.Localize("render", "CopyTexture")
	ENV.Localize("scripted_ents", "GetList")
	ENV.Localize("sound", "PlayFile")
	ENV.Localize("string", "byte")
	ENV.Localize("string", "char")
	ENV.Localize("string", "EndsWith")
	ENV.Localize("string", "find")
	ENV.Localize("string", "format")
	ENV.Localize("string", "lower")
	ENV.Localize("string", "Split")
	ENV.Localize("string", "StripExtension")
	ENV.Localize("string", "sub")
	ENV.Localize("string", "Trim")
	ENV.Localize("string", "match")
	ENV.Localize("string", "PatternSafe")
	ENV.Localize("surface", "CreateFont")
	ENV.Localize("surface", "DrawCircle")
	ENV.Localize("surface", "DrawLine")
	ENV.Localize("surface", "DrawOutlinedRect")
	ENV.Localize("surface", "DrawPoly")
	ENV.Localize("surface", "DrawRect")
	ENV.Localize("surface", "DrawText")
	ENV.Localize("surface", "GetTextSize")
	ENV.Localize("surface", "GetTextureID")
	ENV.Localize("surface", "SetFont")
	ENV.Localize("surface", "SetDrawColor")
	ENV.Localize("surface", "SetTexture")
	ENV.Localize("surface", "SetTextColor")
	ENV.Localize("surface", "SetTextPos")
	ENV.Localize("system", "IsLinux")
	ENV.Localize("system", "IsOSX")
	ENV.Localize("system", "IsWindows")
	ENV.Localize("table", "concat")
	ENV.Localize("table", "Empty")
	ENV.Localize("table", "HasValue")
	ENV.Localize("table", "insert")
	ENV.Localize("table", "IsEmpty")
	ENV.Localize("table", "KeyFromValue")
	ENV.Localize("table", "Merge")
	ENV.Localize("table", "remove")
	ENV.Localize("table", "sort")
	ENV.Localize("timer", "Create")
	ENV.Localize("timer", "Remove")
	ENV.Localize("timer", "Simple")
	ENV.Localize("os", "time")
	ENV.Localize("util", "AimVector")
	ENV.Localize("util", "Base64Encode")
	ENV.Localize("util", "Compress")
	ENV.Localize("util", "CRC")
	ENV.Localize("util", "IntersectRayWithOBB")
	ENV.Localize("util", "JSONToTable")
	ENV.Localize("util", "QuickTrace")
	ENV.Localize("util", "NiceFloat")
	ENV.Localize("util", "SharedRandom")
	ENV.Localize("util", "TableToJSON")
	ENV.Localize("util", "TraceHull")
	ENV.Localize("util", "TraceLine")
	ENV.Localize("vgui", "Unregister")
	ENV.Localize("vgui", "GetWorldPanel")
	ENV.Localize("vgui", "Create")
	ENV.Localize("vgui", "CreateHTML")
	ENV.Localize("vgui", "CreateIcon")
	ENV.Localize("vgui", "CreateLabel")
	ENV.Localize("vgui", "CreateListView")
	ENV.Localize("vgui", "CreatePanel")
	ENV.Localize("vgui", "CreateScrollBar")
	ENV.Localize("vgui", "CreateSlider")
	ENV.Localize("vgui", "CreateSprite")
	ENV.Localize("vgui", "CreateTooltip")
	ENV.Localize("vgui", "CreateTreeView")
	ENV.Localize("vgui", "GetControlTable")
	ENV.Localize("vgui", "GetKeyboardFocus")
	ENV.Localize("vgui", "Register")
	ENV.Localize("vgui", "Unregister")
	ENV.Localize("weapons", "GetStored")
	ENV.Localize("weapons", "IsBasedOn")

	-- Stupid shit
	ENV.NULL = ENV.rawget(_G, "NULL") -- BEEEEEEEEEEEEEEE

	ENV.CustomizableWeaponry = ENV.rawget(ENV._G, "CustomizableWeaponry")
	ENV.CW_AIMING = ENV.rawget(ENV._G, "CW_AIMING")
	ENV.FAS_STAT_CUSTOMIZE = ENV.rawget(ENV._G, "FAS_STAT_CUSTOMIZE")
	ENV.FAS_STAT_SPRINT = ENV.rawget(ENV._G, "FAS_STAT_SPRINT")
	ENV.FAS_STAT_QUICKGRENADE = ENV.rawget(ENV._G, "FAS_STAT_QUICKGRENADE")
	ENV.TFA = ENV.rawget(ENV._G, "TFA")
	ENV.ArcCW = ENV.rawget(ENV._G, "ArcCW")

	local Vars = ENV.Vars
	Vars.Aimbot.AimCone.Color = ENV.Color(255, 255, 255)
	Vars.ESP2D.Player.Color = ENV.Color(255, 255, 255)
	Vars.ESP2D.Entity.Color = ENV.Color(0, 255, 255)
	Vars.ESP2D.Player.Outline.Color = ENV.Color(255, 255, 255)
	Vars.ESP2D.Entity.Outline.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Chams.Player.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Chams.Player.OverLay.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Chams.ViewModel.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Chams.Entity.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Chams.Entity.OverLay.Color = ENV.Color(255, 255, 255)
	Vars.ESP3D.Backtrack.Colors.Start = ENV.Color(255, 255, 255)
	Vars.ESP3D.Backtrack.Colors.End = ENV.Color(255, 255, 255)
	Vars.ESP3D.HitBoxes.Color = ENV.Color(255, 255, 255)

	ENV.CreateFunction("Log", function(String, ...)
		MsgC(color_gray, "[", color_crimson, "Jackson", color_gray, "] ", color_gray, string.format(String, ...))
		MsgN()
	end)

	ENV.CreateFunction("enum", function(prefix, id) -- hono
		if not g_tEnums[prefix] then
			g_tEnums[prefix] = {}
		end

		if istable(id) and not table.IsEmpty(id) then
			for k,v in next, id do
				enum(prefix, v)
			end
		else
			-- don't put this one in _G, but still populate the enum table
			if id == false then
				table.insert(g_tEnums[prefix], table.IsEmpty(g_tEnums[prefix]) and 0 or #g_tEnums[prefix] + 1, id)
				return
			end

			local key = prefix:upper() .. "_" .. id:upper()
			local value = table.IsEmpty(g_tEnums[prefix]) and 0 or #g_tEnums[prefix] + 1
			ENV[key] = value

			table.insert(g_tEnums[prefix], value, id)
		end
	end)

	ENV.CreateFunction("XORString", function(text) -- hono
		if not isstring(text) then return end

		if g_tAlreadyXOR[text] then
			return g_tAlreadyXOR[text]
		end

		local key = "rhoads"
		local out = {}

		for i = 1, #text do
			out[i] = bit.bxor(string.byte(text[i]), string.byte(key[i % #key]))
		end

		local strOut = string.char(unpack(out))

		g_tAlreadyXOR[text] = strOut
		g_tAlreadyXOR[strOut] = text
		g_tXORToRegular[strOut] = text

		return strOut
	end)

	ENV.CreateFunction("g_fnTraceback", function(err) -- hono
		local spaces = "\n "

		for lvl = 2, math.huge do
			local info = getinfo(lvl, "Slnf")
			if not info then break end

			err = err .. Format("%s%d. %s - %s:%d ",
								spaces,
								lvl - 1,
								info.name ~= "" and info.name or "(anonymous)",
								info.short_src,
								info.currentline)

			spaces = spaces .. " "
		end

		return err
	end)

	ENV.CreateFunction("LoadModule", function(strDir, strName)
		local code = file.Read(string.format("%s/%s", strDir, strName), "MOD")

		local CompiledCode = CompileString(code, XORString(strName), false)
		ENV.setfenv(CompiledCode, ENV)

		local ok, why = xpcall(CompiledCode, g_fnTraceback)
		if not ok then
			Log("failed to load module %s", strName)

			for xor, reg in next, g_tXORToRegular do
				why = why:gsub(string.PatternSafe(xor), reg)
			end

			print(string.format("Lua Error: %s", why))
			return
		end

		Log("Loaded module %s", strName)
	end)

	ENV.CreateFunction("LoadModules", function(strDir)
		if not file.Exists(strDir, "MOD") and not file.IsDir(strDir, "MOD") then return end

		local files = file.Find(string.format("%s/*", strDir), "MOD")

		for _, v in pairs(files) do
			if v == "menu.lua" or v == "hooks.lua" then
				continue
			end --  dont run twice fucker

			LoadModule(strDir, v)
		end

		LoadModule(strDir, "hooks.lua")
		LoadModule(strDir, "menu.lua")
	end)

	ENV.CreateFunction("AddHook", function(strType, pFunction)
		local strName = XORString(tostring({}))

		g_tLocalHooks[#g_tLocalHooks + 1] = {
			m_strType = strType,
			m_strName = strName
		}

		hook.Add(strType, strName, ENV.RegisterFunction(pFunction))

		Log("Hook Added! [{%s} {%s}]", strType, strName)
	end)

	ENV.CreateFunction("AddConCommand", function(Name, Function)
		Log("ConCommand Added! " .. Name)

		concommand.Add(Name, ENV.RegisterFunction(Function))
	end)

	ENV.LoadModules("lua/jackson_modules")
end

do
	local AddHook = Data.Environment.AddHook
	local AddConCommand = Data.Environment.AddConCommand

	Data.Environment.gameevent.Listen("player_connect_client")
	AddHook("player_connect_client", function()
		g_pEnvPlayerList:CacheUpdate()
	end)

	Data.Environment.gameevent.Listen("player_disconnect")
	AddHook("player_disconnect", function()
		g_pEnvPlayerList:CacheUpdate()
	end)

	AddHook("Tick", function()
		C_CreateMove:OnTick()
	end)

	AddHook("PostFrameStageNotify", function(nStage)
		LagCompensation:OnPostFrameStageNotify(nStage)
	end)

	AddHook("EntityFireBullets", function(pEntity, tData)
		C_Accuracy:OnEntityFireBullets(pEntity, tData)
	end)

	AddHook("DispatchEffect", function(strEffectName, pEffectData)
		C_Visuals:OnDispatchEffect(strEffectName, pEffectData)
	end)

	AddHook("PostDrawTranslucentRenderables", function(depth, sky)
		C_Visuals:OnPostDrawTranslucentRenderables(depth, sky)
	end)

	AddHook("PostDrawHUD", function()
		C_Visuals:OnPostDrawHUD()
	end)

	AddHook("PreDrawEffects", function()
		C_Visuals:OnPreDrawEffects()
	end)

	AddHook("PrePlayerDraw", function(hPlayer)
		MultiplayerAnimState:OnPrePlayerDraw(hPlayer)
	end)

	AddHook("PostPlayerDraw", function(hPlayer)
		MultiplayerAnimState:OnPostPlayerDraw(hPlayer)
	end)

	AddHook("PreDrawViewModel", function()
		C_Visuals:OnPreDrawViewModel()
	end)

	AddHook("PostDrawViewModel", function()
		C_Visuals:OnPostDrawViewModel()
	end)

	AddHook("InputMouseApply", function(pUserCmd, nMouseX, nMouseY)
		C_CreateMove:OnInputMouseApply(pUserCmd, nMouseX, nMouseY)
	end)

	AddHook("CreateMove", function(pUserCmd)
		C_CreateMove:OnCreateMove(pUserCmd)
	end)

	AddHook("CreateMoveEx", function(pUserCmd, bSendPacket)
		C_CreateMove:PreCreateMoveEx(pUserCmd, bSendPacket)
		C_CreateMove:OnCreateMoveEx(pUserCmd)
		C_CreateMove:PostCreateMoveEx(pUserCmd)

		if pUserCmd:TickCount() ~= 0 then
			if not isbool(g_bSendPacket) then
				g_bSendPacket = true
			end

			if not isbool(g_bShouldEngineViewAngles) then
				g_bShouldEngineViewAngles = true
			end

			return g_bSendPacket, g_bShouldEngineViewAngles
		end
	end)

	AddHook("FinishMove", function(hPlayer, mv)
		C_CreateMove:OnFinishMove(hPlayer, mv)
	end)

	AddHook("ShouldDrawLocalPlayer", function(hPlayer) -- this hook is pretty retarded
		if Vars.Misc.ThirdPerson.Enabled and Vars.Misc.ThirdPerson.Distance > 0 and VInputs:IsKeyActive(Vars.Misc.ThirdPerson.KeyCode) then
			return true
		end

		if g_pLocalPlayer:IsPlayingTaunt() or Wait then
			return true
		end

		return g_pLocalPlayer:ShouldDrawLocalPlayer()
	end)

	AddHook("CalcView", function(hPlayer, vOrigin, qAngles, nFOV, nZNear, nZFar)
		return C_Visuals:OnCalcView(hPlayer, vOrigin, qAngles, nFOV, nZNear, nZFar)
	end)

	AddHook("OnScreenSizeChanged", function()
		C_Visuals:OnScreenSizeChanged()
	end)

	--[[
		ConCommands
	]]

	AddConCommand("sh_menu", function()
		ToggleMenu()
	end)

	AddConCommand("sh_reload", function()
		for i = 1, #g_tLocalHooks do
			local CurrHook = g_tLocalHooks[i]
			local Type, Name = CurrHook.m_strType, CurrHook.m_strName

			Log("Hook Removed [{%s} {%s}]", Type, Name)

			hook.Remove(Type, Name)
		end

		g_pCachedMenu:Remove()

		concommand.Remove("sh_menu")
		concommand.Remove("sh_unload")

		if g_strOriginalName ~= g_strCurrName then
			cv_name:SendValue(g_strOriginalName)
		end

		local FILEREAD = file.Read
		local RUNSTRING = RunString

		for i = 1, #Data do
			Data[i] = nil
		end
		Data = nil

		local strCode = FILEREAD("jackson.lua", "LUA")
		RUNSTRING(strCode)

		strCode = nil
		RUNSTRING = nil
		FILEREAD = nil
	end)

	AddConCommand("sh_unload", function()
		for i = 1, #g_tLocalHooks do
			local CurrHook = g_tLocalHooks[i]
			local Type, Name = CurrHook.m_strType, CurrHook.m_strName

			Log("Hook Removed [{%s} {%s}]", Type, Name)

			hook.Remove(Type, Name)
		end

		for k, v in pairs(player.GetAll()) do
			v:SetRenderMode(RENDERMODE_NORMAL)
		end

		if g_strOriginalName ~= g_strCurrName then
			cv_name:SendValue(g_strOriginalName)
		end

		g_pCachedMenu:Remove()

		concommand.Remove("sh_menu")
		concommand.Remove("sh_unload")

		local CollectGarbage = collectgarbage

		for i = 1, #Data do
			Data[i] = nil
		end

		Data = nil
		CollectGarbage("step")
	end)
end