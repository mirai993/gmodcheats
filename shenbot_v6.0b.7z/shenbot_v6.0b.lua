/*************************
/**       ShenBot       **
/**    Made by Shen     **
/**     Version 6       **
/** DON'T REDISTRIBUTE! **
*************************/

/* Storing values so they can be used later. */
MsgN( "[ShenBot] ------- Creating values -------" )
ShenBot = {}
MsgN( "[ShenBot] Created value ShenBot (TABLE) and set to empty." )
ShenBot.Version = 6
MsgN( "[ShenBot] Created value ShenBot.Version (INTEGER) and set to 3." )
ShenBot.User = LocalPlayer()
MsgN( "[ShenBot] Created value ShenBot.Player (ENTITY) and set to LocalPlayer()." )
ShenBot.HUDCrossSize = ScrW() * 0.03
MsgN( "[ShenBot] Created value ShenBot.HUDShenBot.HUDCrossSize (INTEGER) and set to ScrW() * 0.03." )
ShenBot.UsefulItems = { "item_healthkit", "item_ammo_crate", "item_healthkit", "item_healthvial", "item_battery" }
MsgN( "[ShenBot] Created value ShenBot.UsefulItems." )
CreateClientConVar( "ShenBot.ESPEnemyOnly", 0, false, false )
MsgN( "[ShenBot] Created convar ShenBot.ESPEnemyOnly (INTEGER) and set to 0." )
CreateClientConVar( "ShenBot.AimbotEnemyOnly", 1, false, false )
MsgN( "[ShenBot] Created convar ShenBot.AimbotEnemyOnly (INTEGER) and set to 0." )
ShenBot.AimbotCheck = false
MsgN( "[ShenBot] Created value ShenBot.AimbotCheck (BOOLEAN) and set to false." )
ShenBot.AimbotTarget = nil
MsgN( "[ShenBot] Created value ShenBot.AimbotTarget (NIL) and set to nil." )
ShenBot.AimbotTarget_Position = nil
MsgN( "[ShenBot] Created value ShenBot.AimbotTarget_Position (NIL) and set to nil." )
ShenBot.AimbotTarget_Head = nil
MsgN( "[ShenBot] Created value ShenBot.AimbotTarget_Head (NIL) and set to nil." )
ShenBot.AimbotTarget_HeadPosition, ShenBot.AimbotTarget_HeadAngle = nil, nil
MsgN( "[ShenBot] Created value ShenBot.AimbotTarget_HeadPosition (NIL) and set to nil." )
MsgN( "[ShenBot] Created value ShenBot.AimbotTarget_HeadAngle (NIL) and set to nil." )
ShenBot.BunnyHopCheck = false
MsgN( "[ShenBot] Created value ShenBot.BunnyHopCheck (BOOLEAN) and set to false." )
ShenBot.BunnyHopSpeed = 180
MsgN( "[ShenBot] Created value ShenBot.BunnyHopSpeed (INTEGER) and set to 180." )
ShenBot.Meta = _R.Entity
MsgN( "[ShenBot] Created value ShenBot.Meta (META) and set to _R.Entity." )
ShenBot.GetTargetWeapons = _R['Player'].GetWeapons
MsgN( "[ShenBot] Created value ShenBot.GetTargetWeapons (META) and set to _R['Player'].GetWeapons." )
ShenBot.SaveFile = "ShenBot_Save.txt"
MsgN( "[ShenBot] Created value ShenBot.SaveFile (STRING) and set to 'ShenBot_Save.Txt'" )
/* Done storing values. */

/* Creating functions. */
MsgN( "[ShenBot] ------- Creating functions -------" )
function ShenBot.Load()

	if( file.Exists( ShenBot.SaveFile ) ) then
	
		local loaded_stuff = file.Read( ShenBot.SaveFile )
		
		local decoded_stuff = string.Explode( " ", loaded_stuff )
		
		RunConsoleCommand( "ShenBot.AimbotEnemyOnly", decoded_stuff[1] )
		MsgN( "[ShenBot] ShenBot.AimbotEnemyOnly was loaded succesfully to " .. decoded_stuff[1] .. "." )

		RunConsoleCommand( "ShenBot.ESPEnemyOnly", decoded_stuff[2] )
		MsgN( "[ShenBot] ShenBot.ESPEnemyOnly was loaded succesfully to " .. decoded_stuff[2] .. "." )

		ShenBot.BunnyHopSpeed = decoded_stuff[3]
		MsgN( "[ShenBot] ShenBot.BunnyHopSpeed was loaded succesfully to " .. decoded_stuff[3] .. "." )
		
	else
	
		MsgN( "[ShenBot] " .. ShenBot.SaveFile .. " non-existant, returning." )
		
	end
	
end
MsgN( "[ShenBot] ShenBot.Load function created and ready to use." )

function ShenBot.Save()

	if not ( file.Exists( ShenBot.SaveFile ) ) then
	
		file.Write( ShenBot.SaveFile, GetConVar( "ShenBot.AimbotEnemyOnly" ):GetInt() .. " " .. GetConVar( "ShenBot.ESPEnemyOnly" ):GetInt() .. " " .. ShenBot.BunnyHopSpeed .. " " .. "\nYou really shouldn't edit this." )
		Msg( "[ShenBot] " .. ShenBot.SaveFile .. " saved!" )
		
	else
	
		file.Delete( ShenBot.SaveFile )
		
		file.Write( ShenBot.SaveFile, GetConVar( "ShenBot.AimbotEnemyOnly" ):GetInt() .. " " .. GetConVar( "ShenBot.ESPEnemyOnly" ):GetInt() .. " " .. ShenBot.BunnyHopSpeed .. " " ..  "\nYou really shouldn't edit this.")
		
	end
	
end
MsgN( "[ShenBot] ShenBot.Save function created and ready to use." )
	
function ShenBot.Menu()

	surface.PlaySound( "npc/metropolice/vo/shit.wav" )

	local DCheckBox1
	local DCheckBox2
	local DNumSlider1
	local DPanel1
	local DFrame1

	DFrame1 = vgui.Create('DFrame')
	DFrame1:SetSize(193, 128)
	DFrame1:SetPos( ScrW() / 2 - 96, ScrH() / 2 - 64 )
	DFrame1:SetTitle('ShenBot version ' .. ShenBot.Version .. ' Menu')
	DFrame1:SetSizable(true)
	DFrame1:SetDeleteOnClose(false)
	DFrame1:MakePopup()

	DPanel1 = vgui.Create('DPanel')
	DPanel1:SetParent(DFrame1)
	DPanel1:SetSize(181, 46)
	DPanel1:SetPos(7, 28)

	DCheckBox2 = vgui.Create('DCheckBoxLabel')
	DCheckBox2:SetParent(DFrame1)
	DCheckBox2:SetPos(14, 56)
	DCheckBox2:SetText('Aimbot : Target enemies only?')
	DCheckBox2:SetValue ( GetConVar( "ShenBot.AimbotEnemyOnly" ):GetInt() )
	DCheckBox2:SetConVar( "ShenBot.AimbotEnemyOnly" )
	DCheckBox2.OnChange = function()
	
		hook.Remove( "HUDPaint", "ShenBot.Aimbot" )

		if ( ShenBot.AimbotTarget ~= nil ) then
		
			if ( ShenBot.AimbotTarget:Team() == ShenBot.User:Team() ) then
			
				ShenBot.AimbotTarget = nil
				
			end
		end
		
		hook.Add( "HUDPaint", "ShenBot.Aimbot", ShenBot.Aimbot )
		
		ShenBot.Save()
		
	end
	DCheckBox2:SizeToContents()

	DCheckBox1 = vgui.Create('DCheckBoxLabel')
	DCheckBox1:SetParent(DFrame1)
	DCheckBox1:SetPos(14, 34)
	DCheckBox1:SetText('ESP : Draw enemies only?')
	DCheckBox1:SetValue ( GetConVar( "ShenBot.ESPEnemyOnly" ):GetInt() )
	DCheckBox1:SetConVar( "ShenBot.ESPEnemyOnly" )
	DCheckBox1.OnChange = function()
	
		hook.Remove( "HUDPaint", "ShenBot.ESP" )
		
		for k, v in pairs ( player.GetAll() ) do
		
			if ( v:Team() == ShenBot.User:Team() ) then
			
				v:SetColor( 255, 255, 255, 255 )
				v:SetMaterial( "" )
				
			end
			
		end
		
		hook.Add( "HUDPaint", "ShenBot.ESP", ShenBot.DoESP )
		
		ShenBot.Save()
		
	end
	DCheckBox1:SizeToContents()

	DNumSlider1 = vgui.Create('DNumSlider')
	DNumSlider1:SetSize(181, 40)
	DNumSlider1:SetParent(DFrame1)
	DNumSlider1:SetPos(6, 81)
	DNumSlider1.OnMouseReleased = function() end
	DNumSlider1.OnValueChanged = function() ShenBot.BunnyHopSpeed = DNumSlider1:GetValue(); ShenBot.Save() end
	DNumSlider1:SetText('BunnyHop Minimum Speed')
	DNumSlider1:SetValue( ShenBot.BunnyHopSpeed )
	DNumSlider1:SetMinMax( 1, 999 )
	DNumSlider1:SetDecimals( 0 )
	
end
MsgN( "[ShenBot] ShenBot.Menu function created and ready to use." )

function ShenBot.DoHUD()

	if ( ShenBot.AimbotCheck ) then
	
		surface.SetTextColor( 255, 0, 0, 255 )
		surface.SetFont( "HUDNumber5" )
		surface.SetTextPos( ScrW() / 2 - 100, 50 ) 
		surface.DrawText( "AIMBOT ON" ) 
	
		if ( GetConVar( "ShenBot.AimbotEnemyOnly" ):GetInt() == 1 ) then
	
			surface.SetTextColor( 0, 255, 0, 255 )
			surface.SetFont( "HUDNumber5" )
			surface.SetTextPos( ScrW() / 2 - 125, 100 ) 
			surface.DrawText( "ENEMIES ONLY" ) 
		
		end
		
	end
	
	if ( ShenBot.BunnyHopCheck ) then
	
		surface.SetTextColor( 255, 255, 0, 255 )
		surface.SetFont( "HUDNumber5" )
		surface.SetTextPos( ScrW() / 2 - 200, 0 ) 
		surface.DrawText( "Speed: " .. math.Round( LocalPlayer():GetVelocity():Length() ) .. " - Minimum : " .. ShenBot.BunnyHopSpeed ) 
		
	end
	
end
MsgN( "[ShenBot] ShenBot.DoHUD function created and ready to use." )

function ShenBot.GetPlayerWeapon( ply )

	if ( ply:GetActiveWeapon() ~= nil ) then
	
		return ply:GetActiveWeapon():GetPrintName()
		
	end
	
end
MsgN( "[ShenBot] ShenBot.GetPlayerWeapon function created and ready to use." )

function ShenBot.DoESP()
	
	for k, v in pairs( ents.GetAll() ) do
	
		if ( v:IsValid() ) then
	
			if ( v:IsPlayer() ) then
				
				if ( v:Alive() and v:Health() > 0 and v ~= ShenBot.User ) then
				
					if ( v:Team() == ShenBot.User:Team() and GetConVar( "ShenBot.ESPEnemyOnly" ):GetInt() == 1 ) then
					
					else
					
						local vhead = v:LookupBone("ValveBiped.Bip01_Head1") 
							
						local vpos = v:GetPos()
							
						local vheadpos, vheadang = v:GetBonePosition( vhead )
						
						local vdist = math.floor( ( ShenBot.User:GetPos():Distance( vpos ) ) / 40 )
							
						local vscreenpos = vheadpos:ToScreen()
							
						surface.SetDrawColor( 255, 255, 0, 255 )
							
						surface.DrawLine( vscreenpos.x - ShenBot.HUDCrossSize, vscreenpos.y, vscreenpos.x + ShenBot.HUDCrossSize, vscreenpos.y )
						surface.DrawLine( vscreenpos.x, vscreenpos.y - ShenBot.HUDCrossSize, vscreenpos.x, vscreenpos.y + ShenBot.HUDCrossSize )
							
						surface.SetTextColor( 0, 255, 255, 255 )
						surface.SetFont( "Trebuchet18" )
						surface.SetTextPos( vscreenpos.x + 5, vscreenpos.y ) 
						surface.DrawText( v:Nick() )
								
						surface.SetTextColor( 0, 255, 0, 255 )
						surface.SetFont( "Trebuchet18" )
						surface.SetTextPos( vscreenpos.x + 5, vscreenpos.y + 15 ) 
						surface.DrawText( v:Health() .. " HP" )
						
						surface.SetTextColor( 0, 255, 0, 255 )
						surface.SetFont( "Trebuchet18" )
						surface.SetTextPos( vscreenpos.x + 5, vscreenpos.y + 30 ) 
						surface.DrawText( "Distance: " .. vdist .. " units" )
						
						surface.SetTextColor( 255, 0, 255, 255 )
						surface.SetFont( "Trebuchet18" )
						surface.SetTextPos( vscreenpos.x + 5, vscreenpos.y - 15 ) 
						surface.DrawText( "Speed: " .. math.Round( v:GetVelocity():Length() ) ) 
								
						v:SetColor( 255, 0, 0, 255 )
						v:SetMaterial( "testhack/solid" )
					
					end
				
				end
				
			elseif ( v:IsWeapon() ) then
		
				v:SetColor( 0, 255, 255, 255 )
				v:SetMaterial( "testhack/solid" )

			elseif ( table.HasValue( ShenBot.UsefulItems, v:GetClass() ) ) then 
			
				v:SetColor( 255, 0, 255, 255 )
				v:SetMaterial( "testhack/solid" )
				
			end
		
		end
				
	end
	
end
MsgN( "[ShenBot] ShenBot.DoESP function created and ready to use." )

function ShenBot.Aimbot()

	if not ( ShenBot.AimbotCheck ) then return end
	
	if ( ShenBot.AimbotTarget == nil ) then
	
		local trace = util.GetPlayerTrace( ShenBot.User )
		local traceRes = util.TraceLine( trace )
		
		if ( traceRes.HitNonWorld ) then
		
			local CurrentTarget = traceRes.Entity
			
			if ( CurrentTarget:IsPlayer()) then
			
				if ( CurrentTarget:Team() == ShenBot.User:Team() and GetConVar( "ShenBot.AimbotEnemyOnly" ):GetInt() == 1 ) then
				
				else
				
					for k, v in pairs( ShenBot.GetTargetWeapons( CurrentTarget ) ) do
			
						ShenBot.AimbotTarget = CurrentTarget
					
						ShenBot.AimbotTarget_Position = ShenBot.AimbotTarget:GetPos()
						
						ShenBot.AimbotTarget_Head = ShenBot.AimbotTarget:LookupBone( "ValveBiped.Bip01_Head1" )
						
						ShenBot.AimbotTarget_HeadPosition, ShenBot.AimbotTarget_HeadAngle = ShenBot.AimbotTarget:GetBonePosition( ShenBot.AimbotTarget_Head )
						
						ShenBot.User:SetEyeAngles( ( ShenBot.AimbotTarget_HeadPosition - ShenBot.User:GetShootPos() ):Angle() )
						
					end
					
				end
				
			end
			
		end
	
	else
	
		ShenBot.AimbotTarget_Position = ShenBot.AimbotTarget:GetPos()
			
		ShenBot.AimbotTarget_Head = ShenBot.AimbotTarget:LookupBone( "ValveBiped.Bip01_Head1" )
			
		ShenBot.AimbotTarget_HeadPosition, ShenBot.AimbotTarget_HeadAngle = ShenBot.AimbotTarget:GetBonePosition( ShenBot.AimbotTarget_Head )
			
		ShenBot.User:SetEyeAngles( ( ShenBot.AimbotTarget_HeadPosition - ShenBot.User:GetShootPos() ):Angle() )
	
		if not ( ShenBot.AimbotTarget:Alive() ) then
			
			ShenBot.AimbotTarget = nil
			
		end	
	
	end
	
end
MsgN( "[ShenBot] ShenBot.Aimbot function created and ready to use." )

function ShenBot.DoBunnyHop( ucmd )

	if ( ShenBot.BunnyHopCheck and ( LocalPlayer and LocalPlayer():GetVelocity():Length() > tonumber( ShenBot.BunnyHopSpeed ) or tonumber( ShenBot.BunnyHopSpeed ) == 0 ) ) then
		
		if ( LocalPlayer():OnGround() ) then
		
			ucmd:SetButtons( ucmd:GetButtons() | IN_JUMP )
			
		end
		
	end
	
end
MsgN( "[ShenBot] ShenBot.DoBunnyHop function created and ready to use." )

function ShenBot.BunnyHopToggle()

	if ( ShenBot.BunnyHopCheck == true ) then

		ShenBot.BunnyHopCheck = false
		
	else
	
		ShenBot.BunnyHopCheck = true
		
	end
	
end
MsgN( "[ShenBot] ShenBot.BunnyHopToggle function created and ready to use." )

function ShenBot.AimbotEnable()

	ShenBot.AimbotCheck = true
	
end
MsgN( "[ShenBot] ShenBot.AimbotEnable function created and ready to use." )

function ShenBot.AimbotDisable()

	ShenBot.AimbotCheck = false
	
	ShenBot.AimbotTarget = nil
	
end
MsgN( "[ShenBot] ShenBot.AimbotDisable function created and ready to use." )
/* Done creating functions. */

/* Adding hooks. */
MsgN( "[ShenBot] ------- Adding hooks -------" )
hook.Add( "HUDPaint", "ShenBot.HUD", ShenBot.DoHUD )
MsgN( "[ShenBot] ShenBot.HUD hook added." )
hook.Add( "HUDPaint", "ShenBot.ESP", ShenBot.DoESP )
MsgN( "[ShenBot] ShenBot.ESP hook added." )
hook.Add( "HUDPaint", "ShenBot.Aimbot", ShenBot.Aimbot )
MsgN( "[ShenBot] ShenBot.Aimbot hook added." )
hook.Add( "CreateMove", "ShenBot.BunnyHop", ShenBot.DoBunnyHop )
MsgN( "[ShenBot] ShenBot.BunnyHop hook added." )
/* Done adding hooks. */

/* Creating concommands. */
MsgN( "[ShenBot] ------- Creating concommands -------" )
concommand.Add( "+shenbot_aimbot", ShenBot.AimbotEnable )
MsgN( "[ShenBot] ShenBot.AimbotEnable concommand created and ready to use." )
concommand.Add( "-shenbot_aimbot", ShenBot.AimbotDisable )
MsgN( "[ShenBot] ShenBot.AimbotDisable concommand created and ready to use." )
concommand.Add( "shenbot_menu", ShenBot.Menu )
MsgN( "[ShenBot] ShenBot.Menu concommand created and ready to use." )
concommand.Add( "shenbot_bunnyhoptoggle", ShenBot.BunnyHopToggle )
MsgN( "[ShenBot] ShenBot.BunnyHopToggle concommand created and ready to use." )
/* Done creating concommands. */

MsgN( "[ShenBot] ------------------------------------" )
MsgN( "[ShenBot] ShenBot " .. ShenBot.Version .. " fully loaded and ready to use!" )
MsgN( "[ShenBot] ------------------------------------" )

ShenBot.Load()