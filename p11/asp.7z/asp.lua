--[[
	MOD/lua/asp.lua [#27336 (#28080), 1315598571]
	Ryan Kingstone | STEAM_0:1:42177812 <84.209.110.141:41680> | [13.02.14 07:05:42PM]
	===BadFile===
]]

local RH = { };

--Default to nil if you want to use a random prefix
-----------------------
RH.CustomPrefix = "";

function RH.RandomString( len, numbers, special )
	local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"..(numbers == true && "1234567890" or "")..(special == true && "!@#$%^&*(),.-" or ""); --You can change the list if you like
	local result = "";
	
	if (len < 1) then
		len = math.random( 10, 20 );
	end
	
	for i = 1, len do
		result = result..string.char( string.byte( chars, math.random( 1, string.len( chars ) ) ) );
	end
	
	return tostring( result );
end

RH.MetaPlayer = FindMetaTable( "Player" );
RH.CreateClientConVar = CreateClientConVar;

local function CreateClientConVar( cvarname, default, save, onmenu )
	RH.CreateClientConVar( cvarname, default, save, false );
	return {cvar = GetConVar( cvarname ), OnMenu = onmenu, name = cvarname, main = string.find( cvarname, "enable" )};
end

RH.RandomPrefix = RH.CustomPrefix or RH.RandomString( math.random( 5, 8 ), false );
RH.DeadPlayers = { };
RH.Traitors = { };
RH.TWeaponsFound = { };
RH.Recoils = { };
RH.RandomHooks = { hook = { }, name = { } };
RH.ply = LocalPlayer;
RH.players = player.GetAll;
RH.Target = nil;
RH.mouse1 = false;
RH.AimbotKeyDown = false;
RH.CVARS = {Bools = { }, Numbers = { }};
RH.CVARS.Bools["Aimbot"] = CreateClientConVar( RH.RandomPrefix.."_aimbot_enabled", "0", true, true );
RH.CVARS.Bools["Aim on key"] = CreateClientConVar( RH.RandomPrefix.."_aim_on_key", "1", true, true );
RH.CVARS.Bools["Aim on mouse1"] = CreateClientConVar( RH.RandomPrefix.."_aim_on_mouse", "1", true, true );
RH.CVARS.Numbers["Max Angle"] = CreateClientConVar( RH.RandomPrefix.."_aimbot_max_angle", "30", true, true );
RH.CVARS.Bools["Aim at team mates"] = CreateClientConVar( RH.RandomPrefix.."_aimbot_friendly_fire", "1", true, true );
RH.CVARS.Bools["Aim at steam friends"] = CreateClientConVar( RH.RandomPrefix.."_aimbot_steam_friends", "0", true, true );
RH.CVARS.Bools["ESP"] = CreateClientConVar( RH.RandomPrefix.."_esp_enabled", "1", true, true );
RH.CVARS.Bools["ESP: Show health"] = CreateClientConVar( RH.RandomPrefix.."_esp_show_health", "1", true, true );
RH.CVARS.Bools["ESP: Show weapon"] = CreateClientConVar( RH.RandomPrefix.."_esp_show_weapon", "1", true, true );
RH.CVARS.Bools["ESP: Show name"] = CreateClientConVar( RH.RandomPrefix.."_esp_show_name", "1", true, true );
RH.CVARS.Bools["ESP: Show traitors"] = CreateClientConVar( RH.RandomPrefix.."_esp_show_traitors", "1", true, true );
RH.CVARS.Bools["ESP: Show steamid"] = CreateClientConVar(  RH.RandomPrefix.."_esp_show_steamid", "1", true, true);
RH.CVARS.Bools["ESP: Show entities"] = CreateClientConVar(  RH.RandomPrefix.."_esp_show_entities", "1", true, true);
RH.CVARS.Bools["Chams"] = CreateClientConVar( RH.RandomPrefix.."_chams_enabled", "1", true, true );
RH.CVARS.Bools["Crosshair"] = CreateClientConVar( RH.RandomPrefix.."_crosshair_enabled", "1", true, true );
RH.CVARS.Bools["No Recoil"] = CreateClientConVar( RH.RandomPrefix.."_no_recoil", "1", true, true );
RH.CVARS.Bools["No Visual Recoil"] = CreateClientConVar( RH.RandomPrefix.."_no_visual_recoil", "1", true, true );
RH.CVARS.Bools["Traitor Detector"] = CreateClientConVar( RH.RandomPrefix.."_traitor_detector", "1", true, true );
RH.CVARS.Bools["Show spectators"] = CreateClientConVar( RH.RandomPrefix.."_show_spectators", "1", true, true );
RH.CVARS.Bools["Simplify spectator list"] = CreateClientConVar( RH.RandomPrefix.."_show_spectators_simplify", "0", true, true );
RH.Mat = CreateMaterial( string.lower( RH.RandomString( math.random( 5, 8 ), false, false ) ), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } ); --Last minute change
RH.HeadPos = nil;
RH.TraceRes = nil;
RH.Font = nil;
RH.IsTraitor = nil;
RH.IsTTT = false;
RH.PrintEx = MsgC;
RH.LatestVersion = nil;
RH.Version = "50";
RH.V = 50; --
RH.TimerName = RH.RandomString( 0, false, false );
RH.Unloaded = false;

function RH.Init( )
	--Initalizing
	--Current: Unoptimized
	RH.Font = RH.RandomString( 0, false, false );
	surface.CreateFont( RH.Font, { font = "TargetID", size = 14, weight = 750, antialias = false, outline = true } );
	RH.IsTTT = string.find( GAMEMODE.Name , "Terror" );
	
	RunConsoleCommand( "showconsole" );
	Msg( "\n\n\n" );
	RH.Print( true, true, Color( 255, 100, 100 ), "Your random prefix is "..RH.RandomPrefix );
	
	if (RH.IsTTT) then
		RH.IsTraitor = RH.MetaPlayer.IsTraitor
		
		function RH.MetaPlayer:IsTraitor()
			if (self == RH.ply()) then return RH.IsTraitor( self ); end
			
			if (!table.HasValue( RH.Traitors, self ) || !RH.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
				return RH.IsTraitor( self );
			else
				return true;
			end
		end
	end
end

function RH.Print( timestamp, stamp, ... )
	if (timestamp) then
		Msg( "["..os.date("%H:%M:%S").."] " );
	end
	
	if (stamp) then
		MsgC( Color( 50, 100, 255 ), "[RH] " );
	end
	
	local t = {...};
	
	if (#t == 1) then
		RH.PrintEx( Color(255, 255, 255), t[1] );
	else
		for i = 1, #t, 2 do
			RH.PrintEx( t[i], t[i+1] );
		end
	end
	
	Msg('\n');
end

function RH.PrintChat( ... )
	chat.AddText( Color( 50, 100, 255 ), "[RH] ", ... );
end

function RH.Error( error )
	Msg( "["..os.date("%H:%M:%S").."] " );
	MsgC( Color( 255, 50, 50 ), "[RH] ERROR: " );
	MsgC( Color( 255, 255, 255 ), error.."\n" );
end

function RH.IsOnTeam( ply )
	if ( RH.IsTTT ) then
		return ply:IsTraitor() == RH.ply():IsTraitor();
	else
		return ply:Team() == RH.ply():Team();
	end
end

function RH.GetValidPlayers( )
	local players = { };
	
	for _, ply in pairs( RH.players() ) do
		if ( ply != RH.ply && IsValid( ply ) && 
		ply:IsPlayer() && 
		ply:Alive() && 
		ply:Health() >= 1 &&
		( ply:GetFriendStatus() != "friend" || RH.CVARS.Bools["Aim at steam friends"].cvar:GetBool() ) &&
		( !RH.IsOnTeam( ply ) || RH.CVARS.Bools["Aim at team mates"].cvar:GetBool() ) ) then
			table.insert( players, ply );
		end
	end
	
	return players
end

function RH.IsVisible( ply )
	if (!IsValid( ply )) then return false end
	
	local vecPos, _ = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
	local trace = { start = RH.ply():EyePos(), endpos = vecPos, filter = RH.ply(), mask = MASK_SHOT };
	local traceRes = util.TraceLine( trace );
	
	RH.TraceRes = traceRes;
	
	if (traceRes.HitWorld || traceRes.Entity != ply) then return false end;
	
	return true;
end

function RH.ClosestAngle( players )
	local flAngleDifference = nil;
	local newAngle = nil;
	local viewAngles = RH.ply():EyeAngles();
	
	for _, ply in pairs( players ) do
		local vecPos, ang = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) or 12 );
		local oldpos = vecPos;
		vecPos = vecPos - RH.VelocityPrediction( RH.ply() ) + RH.VelocityPrediction( ply )
		local angAngle = ( vecPos - RH.ply():EyePos() ):Angle()
		local flDif = math.abs( math.AngleDifference( angAngle.p, viewAngles.p ) ) + math.abs( math.AngleDifference( angAngle.y, viewAngles.y ) );
		
		if ((flAngleDifference == nil || flDif < flAngleDifference) && (!RH.CVARS.Numbers["Max Angle"].cvar:GetBool() || flDif < RH.CVARS.Numbers["Max Angle"].cvar:GetFloat())) then
			RH.HeadPos = oldpos:ToScreen();
			RH.Target = ply;
			flAngleDifference = flDif;
			newAngle = angAngle;
		end
	end
	
	return newAngle;
end

function RH.VelocityPrediction( ply ) return ply:GetAbsVelocity() * 0.012; end

function RH.Aimbot( )
	RH.HeadPos = nil;
	
	if (!RH.CVARS.Bools["Aimbot"].cvar:GetBool() || !RH.mouse1 && (RH.CVARS.Bools["Aim on key"].cvar:GetBool() == true || RH.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true) && !RH.AimbotKeyDown) then return end
	
	local players = {};
	
	for _, ply in pairs( RH.GetValidPlayers() ) do
		if (RH.IsVisible( ply )) then
			table.insert( players, ply );
		end
	end
	
	if (table.Count( players ) == 0) then 
		RH.Target = nil;
		return
	end;
	
	local newAngle = RH.ClosestAngle( players );
	
	if ( newAngle != nil ) then RH.ply():SetEyeAngles( newAngle ) end;
end

function RH.TableSortByDistance( former, latter ) return latter:GetPos():Distance( RH.ply():GetPos() ) > former:GetPos():Distance( RH.ply():GetPos() ) end
function RH.TableSortByAsc( former, latter ) print( "hey" ) return string.byte( string.lower( former.name ), 1 ) < string.byte( string.lower( latter.name ), 1 ) end

function RH.GetPlayersByDistance( )
	local players = RH.players( );
	
	table.sort( players, RH.TableSortByDistance );
	
	return players;
end

function RH.CreateMove( cmd )
	if (RH.IsTTT && RH.ply():Alive() && RH.ply():Health() >= 1 && RH.ply():Team() != TEAM_SPECTATOR) then
		RH.ply().voice_battery = 100; --Infinite voichat time I don't need to check if it's TTT because swag
	end
	
	if (cmd:KeyDown( IN_ATTACK ) && !RH.mouse1 && RH.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
		RH.mouse1 = true;
		RH.Aimbot( );
	elseif ( !cmd:KeyDown( IN_ATTACK ) && RH.mouse1 && RH.CVARS.Bools["Aim on mouse1"].cvar:GetBool() == true ) then
		RH.mouse1 = false;
	end
	
	if (RH.CVARS.Bools["No Recoil"].cvar:GetBool() && IsValid( RH.ply() ) && RH.ply():Alive() && RH.ply():Health() > 0 && IsValid( RH.ply():GetActiveWeapon() )) then
		if ( RH.ply():GetActiveWeapon().Primary && RH.ply():GetActiveWeapon().Primary.Recoil ) then
			RH.Recoils[RH.ply():GetActiveWeapon():EntIndex()] = RH.ply():GetActiveWeapon().Primary.Recoil;
			RH.ply():GetActiveWeapon().Primary.Recoil = 0;
		end
	end
	
end

function RH.NoVisualRecoil( ply, pos, angles, fov )
   if (RH.CVARS.Bools["No Visual Recoil"].cvar:GetBool() && RH.ply():Health() > 0 && RH.ply():Team() != TEAM_SPECTATOR && RH.ply():Alive()) then
	   return GAMEMODE:CalcView( ply, RH.ply():EyePos(), RH.ply():EyeAngles(), fov, 0.1 );
   end
end

function RH.AddToColor( color, add )
	return color + add <= 255 and color + add or color + add - 255
end

function RH.SubtractFromColor( color, sub )
	return color - sub >= 0 and color - sub or color - sub + 255
end

function RH.ESP( )
	if (!RH.CVARS.Bools["Crosshair"].cvar:GetBool() && !RH.CVARS.Bools["ESP"].cvar:GetBool() && !RH.CVARS.Bools["Show spectators"].cvar:GetBool()) then return end;
	
	if ( RH.CVARS.Bools["Crosshair"].cvar:GetBool() ) then
		surface.SetDrawColor(Color(255, 255, 255))
		surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 );
		surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 );
		surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 );
		surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 );
	end
	
	if (RH.CVARS.Bools["Show spectators"].cvar:GetBool()) then
		local spectators = 0;
		for _, ply in pairs( RH.players() ) do
			if (ply != RH.ply() && (ply:GetObserverMode() == OBS_MODE_IN_EYE|| ply:GetObserverMode() == OBS_MODE_CHASE) && ply:GetObserverTarget() == RH.ply()) then
				if (spectators == 0 && !RH.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
					draw.DrawText( "Spectating you: "..ply:Nick(), RH.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
				elseif (!RH.CVARS.Bools["Simplify spectator list"].cvar:GetBool()) then
					draw.DrawText( ply:Nick(), RH.Font, ScrW()/2, 25 + spectators*13, Color( 255, 100, 50 ), 1 );
				else
					draw.DrawText( "Someone is spectating you!", RH.Font, ScrW()/2, 25, Color( 255, 100, 50 ), 1 );
					break;
				end
				
				spectators = spectators + 1;
			end
		end
	end
	
	if ( !RH.CVARS.Bools["ESP"].cvar:GetBool() ) then return end
	
	surface.SetFont( RH.Font );
	
	for _, ply in pairs( RH.players() ) do
		if (ply != RH.ply() && ply:Health() >= 1 && ply:Alive() && ply:Team() != TEAM_SPECTATOR) then
			local min, max = ply:GetRenderBounds();
			local pos = ply:GetPos() + Vector( 0, 0, ( min.z + max.z ) );
			local color = Color( 50, 255, 50, 255 );
			
			if ( ply:Health() <= 10 ) then color = Color( 255, 0, 0, 255 );
			elseif ( ply:Health() <= 20 ) then color = Color( 255, 50, 50, 255 );
			elseif ( ply:Health() <= 40 ) then color = Color( 250, 250, 50, 255 );
			elseif ( ply:Health() <= 60 ) then color = Color( 150, 250, 50, 255 ); 
			elseif ( ply:Health() <= 80 ) then color = Color( 100, 255, 50, 255 ); end
			
			pos = ply:GetPos():ToScreen()
			
			if ( RH.CVARS.Bools["ESP: Show name"].cvar:GetBool() ) then
				local width, height = surface.GetTextSize( tostring( ply:Nick() ) ); -- I have to do tostring because sometimes errors would occur
				pos.y = pos.y - 50
				draw.DrawText( ply:Nick(), RH.Font, pos.x, pos.y, ( RH.IsTTT && ply:IsTraitor() ) and Color( 255, 150, 150, 255 ) or Color( 255, 255, 255, 255 ), 1 );
			end

			if ( RH.IsTTT && RH.CVARS.Bools["ESP: Show traitors"].cvar:GetBool() && ply:IsTraitor() ) then
				local width, height = surface.GetTextSize( "[TRAITOR]" );
				draw.DrawText( "[TRAITOR]", RH.Font, pos.x, pos.y-height-3, Color( 255, 0, 0, 255 ), 1 );
			end
			
			pos = ply:GetPos():ToScreen();
			
			if (RH.CVARS.Bools["ESP: Show health"].cvar:GetBool()) then
				local width, height = surface.GetTextSize( "Health: "..tostring( ply:Health() ) );
				draw.DrawText( "Health: "..tostring( ply:Health() ), RH.Font, pos.x, pos.y, color, 1 );
				pos.y = pos.y + 5;
			end
			
			if (RH.CVARS.Bools["ESP: Show weapon"].cvar:GetBool() && IsValid( ply:GetActiveWeapon() )) then
				local width, height = surface.GetTextSize( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass() );
				draw.DrawText( ply:GetActiveWeapon():GetPrintName() or ply:GetActiveWeapon():GetClass(), RH.Font, pos.x, pos.y, Color( 255, 200, 50 ), 1 );
			end

			if (RH.CVARS.Bools["ESP: Show steamid"].cvar:GetBool()) then
				local width, height = surface.GetTextSize( ply:SteamID());
				pos.y = pos.y + 17;
				draw.DrawText( ply:SteamID(), RH.Font, pos.x, pos.y, Color( 255, 200, 50 ), 1 );
			end
			
			
			if (RH.CVARS.Bools["ESP: Show entities"].cvar:GetBool()) then
			end
		end
	end
	
	for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if (!RH.IsTTT) then break; end
		
		local pos = ent:GetPos():ToScreen();
		
		local width, height = surface.GetTextSize( "C4" );
		draw.DrawText( !ent:GetArmed() and "C4 - Unarmed" or "C4 - "..string.FormattedTime(ent:GetExplodeTime() - CurTime(), "%02i:%02i"), RH.Font, pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
	end
	
	if (RH.IsTTT) then
		for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
			local name = CORPSE.GetPlayerNick(ent, false)
			if ( name != false ) then
				local pos = ent:GetPos():ToScreen();
				local width, height = surface.GetTextSize( name );
				
				draw.DrawText( name, RH.Font, pos.x, pos.y-height/2, Color( 255, 255, 255, 255 ), 1 );
				
				if ( !CORPSE.GetFound(ent, false) ) then
					draw.DrawText( "Unidentified", RH.Font, pos.x, pos.y-height/2+12, Color( 200, 200, 0, 255 ), 1 );
				end
			end
		end
	end
	
	if (RH.HeadPos != nil) then
		local width = 5;
		local height = 5;
		surface.SetDrawColor( Color( 255, 0, 0, 255 ) );
		surface.DrawOutlinedRect( RH.HeadPos.x-width/2, RH.HeadPos.y-height/2, width, height );
	end
end

function RH.Chams()
	if (RH.CVARS.Bools["Chams"].cvar:GetBool()) then
		for _, ply in pairs( RH.GetPlayersByDistance( ) ) do
			if (IsValid( ply ) && ply:Alive() && ply:Health() > 0 && ply:Team() != TEAM_SPECTATOR) then
				local color = (RH.IsTTT and ply:IsTraitor( )) and Color( 200, 50, 50 ) or team.GetColor( ply:Team( ) );
				
				cam.Start3D( RH.ply():EyePos(), RH.ply():EyeAngles() );
					render.SuppressEngineLighting( true );

					render.SetColorModulation( color.r/255, color.g/255, color.b/255, 1 );
					render.MaterialOverride( RH.Mat );
					ply:DrawModel();
					
					render.SetColorModulation( RH.AddToColor( color.r, 150 )/255, RH.AddToColor( color.g, 150 )/255, RH.AddToColor( color.b, 150 )/255, 1 );
					if (IsValid( ply:GetActiveWeapon() )) then
						ply:GetActiveWeapon():DrawModel() 
					end
					
					if (RH.IsTTT && ply:IsTraitor()) then
						render.SetColorModulation( 1, 0, 0, 1 );
					else
						render.SetColorModulation( 1, 1, 1, 1 );
					end
					render.MaterialOverride();
					render.SetModelLighting( 4, color.r/255, color.g/255, color.b/255 );
					ply:DrawModel();
					
					render.SuppressEngineLighting( false );
				cam.End3D();
			end
		end
		
		for _, ent in pairs( ents.FindByClass( "ttt_c4" ) ) do
			cam.Start3D( RH.ply():EyePos(), RH.ply():EyeAngles() );
				render.SuppressEngineLighting( true );
				render.SetColorModulation( 1, 0, 0, 1 );
				render.MaterialOverride( RH.Mat );
				ent:DrawModel( );
				
				render.SetColorModulation( 1, 1, 1, 1 );
				render.MaterialOverride();
				render.SetModelLighting( BOX_TOP, 1, 1, 1 )
				ent:DrawModel();
					
				render.SuppressEngineLighting( false );
			cam.End3D();
		end
		
		if (RH.IsTTT) then
			for _, ent in pairs( ents.FindByClass( "prop_ragdoll" ) ) do
				if ( CORPSE.GetPlayerNick(ent, false) != false ) then
					cam.Start3D( RH.ply():EyePos(), RH.ply():EyeAngles() );
						render.SuppressEngineLighting( true );
						render.SetColorModulation( 1, 0.8, 0.5, 1 );
						render.MaterialOverride( RH.Mat );
						ent:DrawModel( );
						
						render.SetColorModulation( 1, 1, 1, 1 );
						render.MaterialOverride();
						render.SetModelLighting( BOX_TOP, 1, 1, 1 )
						ent:DrawModel();
							
						render.SuppressEngineLighting( false );
					cam.End3D();
				end
			end
		end
	end
end

function RH.PlayerDeath( ply )
	RH.PrintChat( Color( 255, 255, 255 ), ply:Nick().." has died!" );
end

timer.Create( RH.TimerName, 0.25, 0, function( )	
	if (!RH.IsTTT || GetRoundState() != 3) then 
		table.Empty( RH.DeadPlayers );
		return;
	end
	
	for _, ply in pairs( RH.players() ) do
		if ((!ply:Alive() || ply:Health() <= 0) && !table.HasValue( RH.DeadPlayers, ply )) then
			table.insert( RH.DeadPlayers, ply );
			RH.PlayerDeath( ply );
		end
	end
end )

function RH.TraitorDetector()
	if (!RH.IsTTT || RH.ply():IsTraitor()) then return end
	
	if (GetRoundState() == 2) then
		for _, wep in pairs(ents.GetAll()) do
			if (wep.CanBuy && wep:IsWeapon() && !table.HasValue(RH.TWeaponsFound, wep:EntIndex())) then
				table.insert( RH.TWeaponsFound, wep:EntIndex() )
			end
		end
	end
	
	if (GetRoundState() != 3 && GetRoundState() != 2) then
		table.Empty( RH.Traitors );
		table.Empty( RH.TWeaponsFound );
		return;
	end
	
	for _, wep in pairs(ents.GetAll()) do
		if (wep:IsWeapon() && wep.CanBuy && IsValid( wep:GetOwner() ) && wep:GetOwner():IsPlayer() && !table.HasValue( RH.TWeaponsFound, wep:EntIndex() )) then
			local ply = wep:GetOwner();
			table.insert( RH.TWeaponsFound, wep:EntIndex() );
			
			if (!ply:IsDetective()) then
				if (!table.HasValue(RH.Traitors, ply)) then
					table.insert(RH.Traitors, ply);
				end
				if (ply != RH.ply() && !RH.ply():IsTraitor() && RH.CVARS.Bools["Traitor Detector"].cvar:GetBool()) then
					chat.AddText( Color( 255, 150, 150 ), ply:Nick(), Color( 255, 255, 255 ), " is a ", Color( 255, 50, 50 ), "traitor: ", Color( 200, 120, 50 ), wep:GetPrintName() or wep:GetClass() );
				end
			end
		end
	end
end

function RH.AddHook( hookname, name, func )
	table.insert( RH.RandomHooks.hook, hookname );
	table.insert( RH.RandomHooks.name, name );
	hook.Add( hookname, name, func );
end

function RH.Menu( )
	--Creating main stuff
	local UsedCVARS = { };
	
	local Panel = vgui.Create( "DFrame" );
	Panel:SetSize( 500, 300 );
	Panel:SetPos( ScrW()/2-Panel:GetWide()/2, ScrH()/2-Panel:GetTall()/2 );
	Panel:SetTitle( "RH" );
	Panel:MakePopup();
	
	local SettingsSheet = vgui.Create( "DPropertySheet", Panel );
	SettingsSheet:SetPos( 0, 23 );
	SettingsSheet:SetSize( SettingsSheet:GetParent():GetWide(), SettingsSheet:GetParent():GetTall() - 23 );
	
	local MainPanel = vgui.Create( "DPanel", Panel );
	MainPanel:SetPos( 0, 0 );
	MainPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	MainPanel.Paint = function() end;
	
	local AimPanel = vgui.Create( "DPanel", Panel );
	AimPanel:SetPos( 0, 0 );
	AimPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	AimPanel.Paint = function() end;
	AimPanel:SetVisible( false );
	
	local ESPPanel = vgui.Create( "DPanel", Panel );
	ESPPanel:SetPos( 0, 0 );
	ESPPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	ESPPanel.Paint = function() end;
	ESPPanel:SetVisible( false );
	
	local MiscPanel = vgui.Create( "DPanel", Panel );
	MiscPanel:SetPos( 0, 25 );
	MiscPanel:SetSize( MainPanel:GetParent():GetWide(), MainPanel:GetParent():GetTall() - 23 );
	MiscPanel.Paint = function() end;
	MiscPanel:SetVisible( false );
	
	SettingsSheet:AddSheet("General", MainPanel, "gui/silkicons/user", false, false, "General settings");
	SettingsSheet:AddSheet("Aimbot", AimPanel, "gui/silkicons/user", false, false, "Aimbot settings");
	SettingsSheet:AddSheet("ESP/Chams", ESPPanel, "gui/silkicons/user", false, false, "ESP/Chams settings");
	SettingsSheet:AddSheet("Misc", MiscPanel, "gui/silkicons/user", false, false, "Misc settings");
	--==Main Panel==--
	local Label = vgui.Create( "DLabel", MainPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Settings" );
	Label:SetFont( "budgetlabel" )
	Label:SizeToContents();
	
	Label = vgui.Create( "DLabel", MainPanel );
	Label:SetPos( 275, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Information" );
	Label:SetFont( "budgetlabel" )
	Label:SizeToContents();
	
	local List = vgui.Create( "DPanelList", MainPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	table.sort( RH.CVARS.Bools, RH.TableSortByAsc );
	
	for name, base in pairs(RH.CVARS.Bools) do
		if (base.OnMenu && base.main) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	
	List = vgui.Create( "DPanelList", MainPanel );
	List:SetPos( 275, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	--==Aimbot==--
	Label = vgui.Create( "DLabel", AimPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Aimbot settings" );
	Label:SetFont( "budgetlabel" )
	Label:SizeToContents();
	
	local List = vgui.Create( "DPanelList", AimPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(RH.CVARS.Bools) do
		if (base.OnMenu && !base.main && string.find( base.cvar:GetName(), "aim" )) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	
	local FOVSlider = vgui.Create( "DNumSlider", AimPanel );
	FOVSlider:SetPos( 275, -15 );
	FOVSlider:SetSize( 150, 100 );
	FOVSlider:SetText( "Max Angle" );
	FOVSlider:SetMin( 0 );
	FOVSlider:SetMax( 180 );
	FOVSlider:SetDecimals( 0 );
	FOVSlider:SetConVar( RH.RandomPrefix.."_aimbot_max_angle" );
	FOVSlider.Paint = function()
		draw.RoundedBox( 4, 0, 36, FOVSlider:GetWide(), 25, Color( 0, 0, 0, 150 ) );
	end
	--==ESP==--
	Label = vgui.Create( "DLabel", ESPPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "ESP/Chams settings" );
	Label:SetFont( "budgetlabel" )
	Label:SizeToContents();
	
	List = vgui.Create( "DPanelList", ESPPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(RH.CVARS.Bools) do
		if (base.OnMenu && !base.main && (string.find( base.cvar:GetName(), "esp" ) || string.find( base.cvar:GetName(), "cham" ))) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
			table.insert( UsedCVARS, base );
		end
	end
	--==MISC==--
	Label = vgui.Create( "DLabel", MiscPanel );
	Label:SetPos( 10, 5 );
	Label:SetColor( Color( 255, 255, 255, 255 ) );
	Label:SetText( "Misc settings" );
	Label:SetFont( "budgetlabel" )
	Label:SizeToContents();
	
	List = vgui.Create( "DPanelList", MiscPanel );
	List:SetPos( 10, 20 );
	List:SetSize( 200, 200 );
	List:SetSpacing( 5 );
	List:EnableHorizontal( false );
	List:EnableVerticalScrollbar( true );
	List:SetPadding( 5 );
	function List:Paint()
		draw.RoundedBox( 4, 0, 0, List:GetWide(), List:GetTall(), Color( 0, 0, 0, 150 ) );
	end
	
	for name, base in pairs(RH.CVARS.Bools) do
		if (base.OnMenu && !table.HasValue( UsedCVARS, base )) then
			local CheckBox = vgui.Create( "DCheckBoxLabel" );
			CheckBox:SetText( name );
			CheckBox:SetConVar( base.cvar:GetName() );
			CheckBox:SetValue( base.cvar:GetBool() );
			CheckBox:SizeToContents();
			List:AddItem( CheckBox );
		end
	end
end

RH.Init();

RH.AddHook( "RenderScreenspaceEffects" , RH.RandomString( 0, true, true ), RH.Chams );
RH.AddHook( "Think", RH.RandomString( 0, true, true ), RH.Aimbot );
RH.AddHook( "Think", RH.RandomString( 0, true, true ), RH.TraitorDetector );
RH.AddHook( "CreateMove", RH.RandomString( 0, true, true ), RH.CreateMove );
RH.AddHook( "CalcView", RH.RandomString( 0, true, true ), RH.NoVisualRecoil );
RH.AddHook( "HUDPaint", RH.RandomString( 0, true, true ), RH.ESP );

concommand.Add( RH.RandomPrefix.."_unload", function( ply, cmd, args ) 
	for i = 1, #RH.RandomHooks.hook do
		hook.Remove( RH.RandomHooks.hook[i], RH.RandomHooks.name[i] );
		RH.Print( true, true, Color( 255, 255, 255 ), "Unhooked "..RH.RandomHooks.hook[i].." using name "..RH.RandomHooks.name[i] );
	end
	
	concommand.Remove( RH.RandomPrefix.."_unload" );
	concommand.Remove( RH.RandomPrefix.."_menu" );
	concommand.Remove( "+"..RH.RandomPrefix.."_aimbot" );
	concommand.Remove( "-"..RH.RandomPrefix.."_aimbot" );
	concommand.Remove( RH.RandomPrefix.."_aimbot_toggle" );
	timer.Destroy( RH.TimerName );
	RH.Unloaded = true;
	RH.Print( true, true, Color( 255, 255, 255 ), "Unloaded successfully!" );
end );

concommand.Add( RH.RandomPrefix.."_menu", RH.Menu );
concommand.Add( "+"..RH.RandomPrefix.."_aimbot", function( ply, cmd, args )
	RH.AimbotKeyDown = true;
	RH.Aimbot();
end );

concommand.Add( "-"..RH.RandomPrefix.."_aimbot", function( ply, cmd, args ) 
	RH.AimbotKeyDown = false;
end );

concommand.Add( RH.RandomPrefix.."_aimbot_toggle", function( ply, cmd, args ) 
	RH.AimbotKeyDown = !RH.AimbotKeyDown;
	
	if (RH.AimbotKeyDown == true) then
		RH.Aimbot();
	end
end );