--[[
	EXECUTABLE_PATH/scripts/AEDevBeta8.lua
	-=TRR- is Up=Dayzlayer | STEAM_0:1:65860748 <86.169.139.24:27005> | [19-10-13 04:18:34PM]
	===BadFile===
]]

surface.PlaySound("ambient/fire/ignite.wav")


LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Owner of AE: Cokeman" )
								chat.AddText(Color(10,60,250), "[AE] Client Updated by Snow Boi")
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Credits:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]BarmyAaron" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Snow Boi" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Commands:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Tab and Q to open Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]E to quit Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold o to flashlight spam" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold 3 For Aimbot" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold Space for bhop" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )
		chat.AddText(Color(255,0,100), "[AE] Loaded version: Beta 8!")
		chat.AddText(Color(250,100,0), "[AE] Client Hidden and protected from server!")
		LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )
		
							




local Cokehack = {Menu = {tabs = {}, b = {}}}
local menu = Cokehack.Menu
 
Cokehack.Settings = {
        aimbot                  = false;
        aimbot_fov              = 180;
        aimbot_bone             = "ValveBiped.Bip01_Head1";
       
        triggerbot              = true;
       
        esp                             = true;
        esp_ply                 = true;
        esp_ply_name    = true;
        esp_ply_rank    = true;
        esp_ply_health  = true;
        esp_ply_dist    = true;
        esp_player_dist = 5000;
        esp_ent                 = true;
        esp_ent_dist    = 4000;
       
        darkrp_god              = false;
        flashlight_spam = false;
        bunnyhop                = false;
		spam               = false;
		ae               = false;
	    afk              = false;
		propspam         = false;
		animation        = false;
		auto        = false;
	    spamadminchat  = false;
		crash  = false;
		nolag  = true;
		reset  = false;
		WeedGrowTime  = false;
		Weed  = false;
		Fule  = false;
		playerinfo  = false;
		ray = false;
		kill = false;
		crashl = false;
		mply = false;
                -- ScreenshotProtection = true;
		
}
 
 
 
Cokehack.Whitelist = {
}
Cokehack.Entities = {
        "money_printer";
        "spawned_money";
        "ent_pot_leaf";
        "ent_coca_leaf";
        "topaz_money_printer";
        "sapphire_money_printer";
        "ruby_money_printer";
        "emerald_money_printer";
        "amethyst_money_printer";
        "drug_pot_seeds";
        "perp_di";
}
Cokehack.Phrases = {
        " Cokeman is a gangsta";
        " Chicken Nuggets";
        " Black Man";
        " Dude wtf anticheat cant catch me";
        " AE is the best";
        " Is so AX";
		" Its not snowing";
		" You can close it by pressing E";
		" This is a menu";
		" Aaron was here";
		" Chicken Mc,Nuglets";
		" ALEX IS A DONKEY";
		" You are playing 'Insert shit server name here'";
		" Dat power";
		" Dont get banned";
		" Dont play with fire";
		" BECAUSE YOLO";
		" This is a random phrase";
}
 
Cokehack.Bones = {
        head = "ValveBiped.Bip01_Head1";
        spine = "ValveBiped.Bip01_Spine";
}
 
surface.CreateFont("Trebuchet19cat", {font="TabLarge", size=13, weight=700})
surface.CreateFont("Trebuchetcat", {font="TabLarge", size=10, weight=700})
 
function Cokehack.CloneTable( src ) --cbot
        local new = {}
        for k, v in pairs( src ) do
                local newf = rawget(src, k);
                if( type( newf ) == "table" and v ~= src ) then
                        new[k] = Cokehack.CloneTable( v );
                else
                        new[k] = newf;
                end
        end
 
        return new;
end
 
Cokehack.table                   = Cokehack.CloneTable( table );
Cokehack.hook                    = Cokehack.CloneTable( hook );
Cokehack.math                    = Cokehack.CloneTable( math );
Cokehack.surface                 = Cokehack.CloneTable( surface );
Cokehack.draw                    = Cokehack.CloneTable( draw );
 
local table                     = Cokehack.table;
local hook                              = Cokehack.hook;
local math                              = Cokehack.math;
local surface                   = Cokehack.surface;
local draw                              = Cokehack.draw;
 
function Cokehack.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end
 
function Cokehack.GetVisible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = Cokehack.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end
 
function Cokehack.Whitelisted(ent)
        if table.HasValue(Cokehack.Whitelist, ent:SteamID())     then return true
        else return false end
end
 
function Cokehack.Target(v)
        if v:IsPlayer() then
                if (Cokehack.GetVisible(v) and (not Cokehack.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if string.find(gmod.GetGamemode().Name, "Stronghold") then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end
 
function Cokehack.ESP(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && /*LocalPlayer():Alive() &&*/ LocalPlayer():Team() ~= TEAM_SPECTATOR then
                        return true
                else
                        return false
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
end
 
function Cokehack.Rank(v)
        if v:IsAdmin() or v:IsSuperAdmin() then
                return "[A] "
        else return "" end
end
 
function Cokehack.Get(value)
        if not(Cokehack.Settings[value]) then return end
       
        if Cokehack.Settings[value] == true then
                return "enabled"
        elseif Cokehack.Settings[value] == false then
                return "disabled"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Head1" then
                return "head"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Spine4" then
                return "spine"
        else
                return Cokehack.Settings[value]
        end
end
 
function Cokehack.Set(value, value2)
        if value2 == "enabled" then
                Cokehack.Settings[value] = true
        elseif value2 == "disabled" then
                Cokehack.Settings[value] = false
        elseif value2 == "head" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Head1"
        elseif value2 == "spine" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Spine4"
        else
                Cokehack.Settings[value] = value2
        end
end
 
function Cokehack.GetBone()
        local b = Cokehack.Settings["aimbot_bone"]
        if b == "head" then
                return Cokehack.Bones["head"]
        elseif b == "spine" then
                return Cokehack.Bones["spine"]
        end
        return nil
end
 
function Cokehack.CreateTab(txt, szw, szh, psw, psh, parent, func)
        if(not parent) then return; end
        local panel = vgui.Create("DPanel", menu.frame);
        panel:SetPos(120,25);
        panel:SetSize(375,405);
        if menu.curwin == txt then panel:SetVisible(true) else panel:SetVisible(false) end
        panel.Paint = function()
                local line = "__________________________________________________________________________"
                surface.SetDrawColor( 70, 0, 20, 155 )
                surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
                surface.CreateFont("shmenufont", {font="coolvetica", size=64, weight=500});
                surface.CreateFont("shmenufont2", {font="coolvetica", size=24, weight=500});
                draw.SimpleText(txt, "shmenufont", 10, 10, Color(255, 255, 00, 235), TEXT_ALIGN_LEFT);
                --draw.SimpleText(line, "MenuLarge", 50, 60, Color(3,3,0,200), TEXT_ALIGN_CENTER)
                if txt == "ESP" then
                        draw.SimpleText("Player ESP", "shmenufont2", 5, 100, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                        draw.SimpleText("Entity ESP", "shmenufont2", 5, 250, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", parent);
        button:SetText(txt);
        button:SetSize(szw, szh);
        button:SetPos(psw, psh);
        button.Paint = function(self) derma.SkinHook("PaintOver", "Button", self) end
        button:SetVisible(true);
        button.DoClick = func or function()
                for k,v in pairs(menu.tabs) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.curwin = txt
				                surface.PlaySound("ambient/levels/canals/drip4.wav");
        end
        return panel, button;
end
 
function Cokehack.AddFeature(parent, id, typ, text, val, option1, option2, option3, option4, option5)
        if not(parent) or not(typ) then return; end
        local posy = (55+(id*25))
        if typ == "button" then
                if Cokehack.Settings[val] == nil then return end
                if text ~= nil then
                        local label = vgui.Create("DLabel", parent)
                        label:SetText(text)
                        label:SetPos(5,posy)
                        label:SizeToContents(false)
                end
 
                local button = vgui.Create("DButton", parent)
                if Cokehack.Get(val) == option1 then
                        button:SetText(option1)
                else
                        button:SetText(option2)
                end
                button:SetSize(80,20)
                if id == 0 then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,posy)
                end
                button.DoClick = function()
                        if button:GetText() == option1 then
                                button:SetText(option2); Cokehack.Set(val, option2)
                        else
                                button:SetText(option1); Cokehack.Set(val, option1)
                        end
                end
                return button, label
        elseif typ == "dbutton" then
                local button = vgui.Create("DButton", parent)
                button:SetPos(option1,option2)
                button:SetSize(option3,option4)
                button:SetText(text)
                button.DoClick = option5
                return button
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, posy-10)
                slider:SetText(text)
                slider:SetMinMax(option1, option2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetValue(Cokehack.Get(val))
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        Cokehack.Set(val, math.Round(c))
                end
                return slider;
        elseif typ == "label" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(text)
                label:SetPos(5,posy)
                label:SizeToContents(false)
        end
end
 
function Cokehack.DrMenu()
        if(menu.frame) then menu.frame:Remove(); end
       
        menu.frame = vgui.Create("DFrame");
        menu.frame:SetPos(ScrW()/2-630, ScrH()/2-285);
        menu.frame:SetSize(500, 435);
        menu.frame:SetTitle("AE Hack Alpha Beta 7"..Cokehack.Phrases[math.random(1, table.Count(Cokehack.Phrases))]);
		        menu.frame.Paint = function()
                surface.SetDrawColor(138,192,132,150)
                surface.DrawRect(0, 0,menu.frame:GetWide(),menu.frame:GetTall())
                surface.SetDrawColor(0,255,0,255)
                surface.DrawOutlinedRect(0,0,menu.frame:GetWide(),menu.frame:GetTall())
        end

        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(false)
        menu.frame:MakePopup();


 
        menu.buttons = vgui.Create("DPanel", menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(111,406)

        menu.buttons.Paint = function()
                surface.SetDrawColor(10,10,10,255)
                            
        end
 
        menu.tabs.aimbot, menu.b.aimbot         =       Cokehack.CreateTab("Aimbot", 80, 20, 15, 10, menu.buttons)
        menu.tabs.pesp, menu.b.pesp             =       Cokehack.CreateTab("ESP", 80, 20, 15, 30, menu.buttons)
        menu.tabs.misc, menu.b.misc             =       Cokehack.CreateTab("Misc", 80, 20, 15, 50, menu.buttons)
		menu.tabs.perp, menu.b.perp             =       Cokehack.CreateTab("Perp", 80, 20, 15, 70, menu.buttons)
		menu.tabs.cm, menu.b.cm                 =       Cokehack.CreateTab("commands", 80, 20, 15, 90, menu.buttons)
		menu.tabs.an, menu.b.an                 =       Cokehack.CreateTab("Animation WIP", 80, 20, 15, 110, menu.buttons)
       

       Protection
        local mta      =   menu.tabs.aimbot
        local mtp      =   menu.tabs.pesp
        local mtm      =   menu.tabs.misc
		local perp     =   menu.tabs.perp
		local cm	   =   menu.tabs.cm
		local an       =   menu.tabs.an		
        -- aimbot tab
        Cokehack.AddFeature(mta, 1, "button", "Aimbot", "aimbot", "enabled", "disabled")
        Cokehack.AddFeature(mta, 2, "button", "Aim-bone", "aimbot_bone", "head", "spine")
        Cokehack.AddFeature(mta, 3, "slider", "Aim FOV", "aimbot_fov", 1, 180)
        Cokehack.AddFeature(mta, 4, "button", "Triggerbot Can Be Detected!", "triggerbot", "enabled", "disabled")
       
        -- esp tab
        Cokehack.AddFeature(mtp, 0, "button", nil, "esp", "enabled", "disabled")
       
        Cokehack.AddFeature(mtp, 2, "button", "Enabled", "esp_player", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 3, "button", "Show Name", "esp_ply_name", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 4, "button", "Show Rank", "esp_ply_rank", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 5, "button", "Show Health", "esp_ply_health", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 6, "button", "Show Distance", "esp_ply_dist", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 7, "slider", "Distance", "esp_player_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 9, "button", "Enabled", "esp_ent", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 10, "slider", "Distance", "esp_ent_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 11, "button", "Tracers", "esplas", "enabled", "disabled")
	Cokehack.AddFeature(mtp, 12, "button", "Crosshair", "crosshair", "enabled", "disabled")
      
       -- misc tab
        Cokehack.AddFeature(mtm, 1, "button", "Flashlight Spam", "flashlight_spam", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 2, "button", "DarkRP God Exploit", "darkrp_god", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 3, "button", "Bunnyhop", "bunnyhop", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 4, "button", "Spam", "spam", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 5, "button", "AE was here", "ae", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 6, "button", "AFK Fxing", "afk", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 7, "button", "Propspam", "propspam", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 8, "button", "Auto pistol", "auto", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 9, "button", "Spam AdminChat", "spamadminchat", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 10, "button", "Crash", "crash", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 11, "button", "Nolag", "nolag", "enabled", "disabled")
	Cokehack.AddFeature(mtm, 12, "button", "Resetlag", "reset", "enabled", "disabled")
	 --Cokehack.AddFeature(mtm, 13, "button", "ScreenshotProtection", "ScreenshotProtection", "enabled", "disabled")
		--An
	Cokehack.AddFeature(an, 1, "button", "Animation", "animation", "enabled", "disabled")
	Cokehack.AddFeature(an, 2, "button", "stacker", "crash1", "enabled", "disabled")
		
		--Perp Hacks tab
	Cokehack.AddFeature(perp, 1, "button", "WeedGrowTime", "WeedGrowTime", "enabled", "disabled")
	Cokehack.AddFeature(perp, 2, "button", "Weed", "Weed", "enabled", "disabled")
	Cokehack.AddFeature(perp, 4, "button", "Fuel", "Fuel", "enabled", "disabled")
	Cokehack.AddFeature(perp, 3, "button", "playerinfo", "playerinfo", "enabled", "disabled")
		
		
		-- Commands
	Cokehack.AddFeature(cm, 1, "button", "kill", "kill", "enabled", "disabled")
	Cokehack.AddFeature(cm, 2, "button", "Rejoin", "ray", "enabled", "disabled")
	Cokehack.AddFeature(cm, 3, "button", "Stacker", "crashl", "enabled", "disabled")	
		Cokehack.AddFeature(cm, 4, "button", "Music", "mply", "enabled", "disabled")
		
		 

		 
		 
end
 
hook.Add("Think", "CokeMENU", function()
        if(input.IsKeyDown(KEY_3) && !menu.frame)then
                Cokehack.DrMenu()
				surface.PlaySound("buttons/button1.wav")
        elseif(menu.frame && input.IsKeyDown(KEY_E))then
                menu.frame:Remove(); menu.frame = nil
                Cokehack.Menu = {}
        end
end)
 
hook.Add("Think", "CokeBOT", function()
        -- triggerbot
        if(Cokehack.Settings["triggerbot"] && input.IsKeyDown(KEY_2)) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and (not Cokehack.Whitelisted(target))) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        -- aimbot [ need bone changing support ]
        if(Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2)) /*or Cokehack.Settings["alert"]*/ then
                for k,v in pairs(player.GetAll()) do
                        /*if Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2) then*/
                        local bone = Cokehack.Settings["aimbot_bone"];
                                if Cokehack.Target(v) then
                                        local head = v:LookupBone(bone)
                                        local fov = Cokehack.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end
                               
                        --end
                        /*if Cokehack.Settings["alert"] then
                                local d = Cokehack.Settings["alert_dist"]
                                if v ~= LocalPlayer() and (v:GetPos():Distance(LocalPlayer():GetPos()) < d) then
                                       
                                end
                        end*/
                end
        end
        
      --  if(Cokehack.Settings["ScreenshotProtection"]) then

--local cap = render.Capture

 --function render.Capture()
 --chat.AddText(color_red, "Server attempted to view your screen!")
 --local g = table.Copy(_G)
 --local CamData = {}
 --CamData.format = "jpeg","PNG","png",
 --CamData.h = 0
 --CamData.w = 0
 --CamData.x = 0
 --CamData.y = 0
 --CamData.quality = 0
 --return cap(CamData)
 --end
 --end
        if Cokehack.Settings["flashlight_spam"] and input.IsKeyDown(KEY_O) then
                RunConsoleCommand("impulse", "100")
        end
       
        if Cokehack.Settings["darkrp_god"] and LocalPlayer():Health() < 100 and LocalPlayer():Alive() then
                RunConsoleCommand("say", "/buyhealth")
        end
		
		if Cokehack.Settings["ae"] then
                RunConsoleCommand("say", "/advert [AE] was HERE")
				end
	   if Cokehack.Settings["crash"] then
       local CRASHALL = CreateClientConVar("CrashAllClients", "0", true, false)
	   local function doCRSHALL()
        if CRASHALL:GetBool() then
 
                RunConsoleCommand("_DarkRP_DoAnimation", "-1921")
        end
end
timer.Create("allgo", 0, 0, doCRSHALL)
				end
	  
	   if Cokehack.Settings["Weed"]  then
        function PERP_Weed()
        if GetConVarNumber("ae_PERP_Weed") == 1 then
                local plants = {}
                for k, ent in pairs( ents.FindByClass("ent_pot") ) do
                        table.insert( plants, ent )
                end
                for k, ent in pairs( ents.FindByClass("ent_coca") ) do
                        table.insert( plants, ent )
                end
                local col = nil
                for k, ent in pairs( plants ) do
                        local pos = ent:GetPos() + Vector(0, 0, 10)
                        local ang = ent:GetAngles()
                        local drawpos = pos:ToScreen()
                        local timeleft = 85564
                        if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
                        if( ent.dt != nil ) then
                                timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
                        elseif( ent:GetTable().SpawnTime != nil ) then
                                timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
                        end
                        if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
                                if( timeleft > 1 and timeleft != 85564 ) then
                                        draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
                                elseif( timeleft != 85564 ) then
                                        draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
                                end
                        end
                end
        end
end	 
end  
	  
	  
		if Cokehack.Settings["auto"] and (input.IsMouseDown(MOUSE_LEFT)) then		

                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
    RunConsoleCommand("+attack")
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	end
	
	
			if Cokehack.Settings["crash1"] and input.IsKeyDown(KEY_F) then		

                    timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
    RunConsoleCommand("+attack")
					timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
                    timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
					timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("-attack")
	end

        if Cokehack.Settings["animation"]  then
		
	    local function doZombie ()

        if Enabled13:GetBool() then

                RunConsoleCommand("_DarkRP_DoAnimation", "1632")

        end

end

 

timer.Create("anim13", 1, 0, doZombie)
end


         if Cokehack.Settings["propspam"] then
				RunConsoleCommand("gm_spawn", "models/props_c17/chair02a.mdl")
				
				
			
			
        end
		

		 if Cokehack.Settings["reset"] then
				local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
	concommand.Add("coke_resetlag", Reset)
end

			
			
        end
		
		if Cokehack.Settings["spamadminchat"] then
				RunConsoleCommand("say", "@ Admin I need help")

			
			
        end
		
		if Cokehack.Settings["nolag"] then
	    local nolag = false
        local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end
concommand.Add("ae_stoplag", StopLag)
end


			
			
        end
		
		
		
		
		 if Cokehack.Settings["spam"] then
				RunConsoleCommand("say", "too much info")
			
			
        end
       
        if Cokehack.Settings["bunnyhop"] and input.IsKeyDown(KEY_SPACE) then
                if(LocalPlayer():OnGround())then
                        LocalPlayer():ConCommand("+jump")
                        timer.Simple(0.01, function()
                                LocalPlayer():ConCommand("-jump")
                        end)
                end
        end
end)

hook.Add("FinishChat", "bhpenabler", function()
	if bhopoff then
		RunConsoleCommand("ae_bunnyhop", 1)
		bhopoff = false
	end
end)
 
 
 
hook.Add("HUDPaint", "CokeHUD", function()
        if Cokehack.Settings["esp"] then
                for k,v in pairs(ents.GetAll()) do
                        if Cokehack.Settings["esp_ply"] && v:IsPlayer() then
                                if(Cokehack.ESP("player", v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (Cokehack.Settings["esp_player_dist"]))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if Cokehack.Settings["esp_ply_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if Cokehack.Settings["esp_ply_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if Cokehack.Settings["esp_ply_health"] then
                                                health = v:Health().."H - "..v:Armor().."A"
                                        end
                                        if Cokehack.Settings["esp_ply_dist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "Trebuchetcat", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "Trebuchet19cat", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(health, "Trebuchetcat", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        draw.SimpleTextOutlined(distance, "Trebuchetcat", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                end
                        end
                        if (Cokehack.Settings["esp_ent"] and Cokehack.ESP("entity", v) and (v:GetPos():Distance(LocalPlayer():GetPos()) < Cokehack.Settings["esp_ent_dist"]))then
                                for k,e in pairs(Cokehack.Entities) do
                                        if e == v:GetClass() then
                                                local ESP = (v:EyePos()):ToScreen()
                                                draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19cat", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        end
                                end
                        end
                end
        end
end)
 
 
 
concommand.Add("defcon", function()
        local z = {"player"}
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if not table.HasValue(t, v:GetClass()) then
                        table.insert(t, v:GetClass())
                end
        end
        for e,x in pairs(t) do
                if !table.HasValue(z, x) then
                        print(x)
                end
        end
end)
 
concommand.Add("Cokehack", function()
        local darkrpvar = true
        print("Player Cash Amounts")
        for k,v in pairs(player.GetAll()) do
                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                        darkrpvar = false
                end
                if v ~= LocalPlayer() then
                        print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
                end
        end
        if darkrpvar == false then
                print("    Unable to get player cash amounts.")
        end
end)
 
concommand.Add("Cokeapult", function()
        PrintTable(player.GetAll()[3]:GetTable())
end)
/**************************************
Name: SHIT SNOW HAS ADDED
Purpose: HACKS AND SHIT
**************************************/



/**************************************
Name: Rotater DONT ADD TO MENU
Purpose: Does 180 and shit
**************************************/

local function Rotate180()
	ae_NOAUTOPICKUP = true
	timer.Simple(0.5, function() ae_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("ae_180", Rotate180)



/**************************************
Name: De Lagger
Purpose: Removes useless shit that garrys added to raise FPS
**************************************/

local removes = {"env_steam",
"func_illusionary",
"beam",
"class C_BaseEntity",
"env_sprite",
"class C_ShadowControl",
"class C_ClientRagdoll",
"func_illusionary",
"class C_PhysPropClientside",
}

local nolag = false

local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end

end
concommand.Add("ae_stoplag", StopLag)

local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
end
concommand.Add("coke_resetlag", Reset)

/**************************************
Name: Hot key script
Purpose: Allows you to make Hotkeys and shit...
**************************************/

sql.Query("CREATE TABLE IF NOT EXISTS MultiKeyBinds('firstkey' INTEGER NOT NULL, 'secondkey' TEXT NOT NULL, 'commandname' TEXT NOT NULL, PRIMARY KEY('firstkey', 'secondkey'));")

local FirstButtons = {ctrl = KEY_LCONTROL, alt = KEY_LALT, shift = KEY_LSHIFT, space = KEY_SPACE}
local Binds = {}

local SQLBinds = sql.Query("SELECT * FROM MultiKeyBinds;")
if SQLBinds then
	for k,v in pairs(SQLBinds) do
		Binds[k] = {}
		Binds[k].firstkey = tonumber(v.firstkey)
		Binds[k].secondkey = string.lower(v.secondkey)
		Binds[k].commandname = v.commandname
	end
end

local AddGUI

local function Add(ply, cmd, args)
	if not args[1] then AddGUI() return end
	if not args[3] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	local bind = {firstkey = FirstButtons[string.lower(args[1])], secondkey = string.lower(args[2]), commandname = args[3]}
	for k,v in pairs(Binds) do
		if v.firstkey == bind.firstkey and v.secondkey == bind.secondkey then
			Binds[k].commandname = bind.commandname

			sql.Query("UPDATE MultiKeyBinds SET commandname = "..sql.SQLStr(bind.commandname).." WHERE firstkey = "..bind.firstkey .." AND secondkey = "..sql.SQLStr(bind.secondkey)..";")
			print("Keybind updated!")
			return "Keybind updated!"
		end
	end
	table.insert(Binds, bind)

	sql.Query("INSERT INTO MultiKeyBinds VALUES(".. bind.firstkey ..", "..sql.SQLStr(bind.secondkey)..", "..sql.SQLStr(bind.commandname)..");")
	print("Keybind made!")
	return "Keybind made!"
end
concommand.Add("ae_hotkey", Add, function() return "ae_hotkey <Ctrl/alt/shift/space> \"<bind other key>\" \"<command>\"" end)

AddGUI = function()
	local firstkey, secondkey, commandname

	local function _3()
		Derma_StringRequest("Command name",
		[[ What will be the command that will be executed when you press the hotkey?
		NOTE: Some commands are blocked! Examples of blocked commands: quit, ent_*,
		lua_run_cl etc.]], "",
		function(text) commandname = text

			local text = Add(LocalPlayer(), "fuck you", {firstkey, secondkey, commandname})
			chat.AddText(Color(0, 255, 0, 255), text)
		end)
	end

	local function _2()
		hook.Add("HUDPaint", "TEMPHotKey", function()
			draw.DrawText([[Press the second key for the hotkey
			Note: The key must already be bound to something!
			If it's not it won't work!

			Well who would use a hotkey with an unbound key anyway]], "HUDNumber5", ScrW()/2, ScrH()/2, Color(0,0,255,255), TEXT_ALIGN_CENTER)
		end)

		hook.Add("PlayerBindPress", "TEMPHotKey", function(ply, bind, pressed)
			hook.Remove("HUDPaint", "TEMPHotKey")
			hook.Remove("PlayerBindPress", "TEMPHotKey")
			secondkey = string.lower(bind)
			_3()
			return true
		end)
	end

	Derma_Query([[What will be the first key for the hotkey?]], "First key",
		"ctrl", function() firstkey = "ctrl" _2() end,
		"alt", function() firstkey = "alt" _2() end,
		"shift", function() firstkey = "shift" _2() end,
		"space", function() firstkey = "space" _2() end)

end

local RemoveGUI
local function Remove(ply, cmd, args)
	if not args[1] then RemoveGUI() return end
	if not args[2] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	for k,v in pairs(Binds) do
		if v.firstkey == FirstButtons[string.lower(args[1])] and v.secondkey == string.lower(args[2]) then
			sql.Query("DELETE FROM MultiKeyBinds WHERE firstkey = "..v.firstkey.." AND secondkey = "..sql.SQLStr(v.secondkey)..";")
			table.remove(Binds, k)
			print("Keybind removed!")
			return "Keybind Removed!"
		end
	end
	print("Keybind not found!")
	return "Keybind not found!"
end
concommand.Add("ae_Unhotkey", Remove, function() return "ae_Unhotkey <ctrl/alt/shift/space> \"bind other key\"" end)

RemoveGUI = function()
	local frame = vgui.Create("DFrame")
	frame:SetTitle( "Remove hotkeys" )
	frame:SetSize( 480, 200 )
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )

	local HotKeyList = vgui.Create("DListView", frame)
	HotKeyList:SetSize(470, 170)
	HotKeyList:SetPos(5, 25)
	HotKeyList:AddColumn("First key")
	HotKeyList:AddColumn("Second key")
	HotKeyList:AddColumn("command")
	HotKeyList:SetMultiSelect(false)

	local NumToKey = {[KEY_LCONTROL] = "ctrl", [KEY_LALT] = "alt", [KEY_LSHIFT] = "shift", [KEY_SPACE] = "space"}

	for k,v in pairs(Binds) do
		HotKeyList:AddLine(NumToKey[v.firstkey], v.secondkey, v.commandname)
	end

	function HotKeyList:OnClickLine(line)
		line:SetSelected(true)
		local text = Remove(LocalPlayer(), "get out", {line:GetValue(1), line:GetValue(2)})
		chat.AddText(Color(0, 255, 0, 255), text)

		HotKeyList:RemoveLine(HotKeyList:GetSelectedLine())
	end
end

concommand.Add("ae_hotkeyList", function() PrintTable(Binds) end)

hook.Add("PlayerBindPress", "ae_hotkey", function(ply, bind, pressed)

	for k,v in pairs(Binds) do
		if input.IsKeyDown(v.firstkey) and string.lower(bind) == string.lower(v.secondkey) and pressed then
			RunConsoleCommand(unpack(string.Explode(" ", v.commandname)))-- Using RunConsoleCommand instead of LocalPlayer():ConCommand to prevent unnecessary blocking
			return true
		end
	end
end)


/**************************************
Name: Error Replacer
Purpose: Replaces Errors With stacks of bricks
**************************************/

CreateClientConVar("ae_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("ae_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/


/**************************************
Name: Snow Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("ae_StartLog",function()
file.Write("ae/log.txt","Log created: ("..os.date()..") \n")
end)
 
function Log(msg)
file.Append("ae/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/**************************************
Name: ATM hack
Purpose: Gets ATM details
**************************************/



concommand.Add( "atm_getmoney", function(ply, cmd, args)

	local name = args[1]
	local money = args[2]

	if not money or not name then
		chat.AddText( nil, cmd.." name money" )
		return
	end

	local vict
	for k,v in pairs(player.GetAll()) do
		if string.find( v:Nick(), name ) then
			vict = v
			break
		end
	end

	if not IsValid(vict) then
		chat.AddText( nil, "No player found with "..name.." in their name." )
                return
	end

	chat.AddText( nil, "Attempting to take $"..money.." from "..vict:Nick().."." )
	RunConsoleCommand( "rp_atm_withdraw", "", vict:UniqueID(), money )

end )

concommand.Add("atm_takemoney", function(players, command, args)
	for k, v in pairs(player.GetAll()) do
		RunConsoleCommand("atm_getmoney", ""..v:GetName().."", args[1])
	end
end)




	
	
	/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) snow.Notify(red,"Error in the Lua script!") end
function Error(...) snow.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) snow.Notify(red,"Error in the Lua script!") end





-- Client side noclip
local SW = {}
 
SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
 
function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles
               
                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
 
function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        SW.Velocity = SW.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
 
function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "AE-FLY " .. status[ SW.Enabled ] )
end
concommand.Add( "ae_fly", SW.Toggle )
 
concommand.Add( "Dev_pos", function() print( SW.ViewOrigin ) end )




-- Crosshair

 CreateClientConVar("ae_advcrosshair", 1, true, false)
CreateClientConVar("ae_advcrosshair_hitmarker", 1, true, false)
CreateClientConVar("ae_advcrosshair_info", 1, true, false)


function advcrosshair()
	if GetConVarNumber("ae_advcrosshair") == 1 then
		local x = ScrW()*.5
		local y = ScrH()*.5
			target = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and (target:IsPlayer() or target:IsNPC()) then
			crosscolor = Color(220,60,90, 150)
			surface.SetDrawColor(crosscolor)
			if GetConVarNumber("ae_advcrosshair_info") == 1 then
				draw.DrawText("Heath: "..target:Health(), "Trebuchet18", x, y +25, Color(255,255,255, 150), 1)

			end
			if GetConVarNumber("ae_advcrosshair_hitmarker") == 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) and LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					surface.SetDrawColor(255,255,255)
					surface.DrawLine(x+15, y+15, x+8, y+8)
					surface.DrawLine(x-15, y-15, x-8, y-8)
					surface.DrawLine(x-15, y+15, x-8, y+8)
					surface.DrawLine(x+15, y-15, x+8, y-8)
				end
			end

		else
			crosscolor = Color(255,255,255, 150)
		end

		/*for _, v in pairs(player.GetAll()) do
			vtarget = v:GetEyeTrace().Entity
			if vtarget:IsPlayer() then
				if LocalPlayer():Alive() and v:GetActiveWeapon():Clip1() > 0 then
					if vtarget:Name() == LocalPlayer():Name() then
						draw.DrawText(vtarget:Name().." is aiming a weapon at you", "Trebuchet18", x, y +35, Color(255,255,255, 150), 1)
					end
				end
			end
		end*/



		surface.SetDrawColor(crosscolor)
		local gap = 15
		local length = gap + 10
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		surface.SetDrawColor(0, 255, 0)
		surface.DrawLine( x +2 , y, x -2, y)
		surface.DrawLine( x , y +2, x , y-2)
	end
end
hook.Add("HUDPaint", "advcrosshair", advcrosshair)




-- Witness box
    local Cap = math.cos(math.rad(45))
    local Offset = Vector(0, 0, 32)
    local Trace = {}

    function Draw()
    	local Time = os.time() - 1
    	local Witnesses = 0
    	local BeingWitnessed = true
    	local Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")

    	if Time < os.time() then
    		Time = os.time() + .5
    		Witnesses = 0
    		BeingWitnessed = false
    		for k, pla in pairs(player.GetAll()) do
    			if pla:IsValid() and pla != LocalPlayer() then
    				Trace.start  = LocalPlayer():EyePos() + Offset
    				Trace.endpos = pla:EyePos() + Offset
    				Trace.filter = {pla, LocalPlayer()}

    				TraceRes = util.TraceLine(Trace)

    				if !TraceRes.Hit then
    					if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
    						Witnesses = Witnesses + 1
    						BeingWitnessed = true

    					end
    				end
    			end
    		end
    	end

    	surface.SetFont("BudgetLabel")
    	if BeingWitnessed then
    		surface.SetTextColor(255, 000, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/cross")
    	else
    		surface.SetTextColor(000, 255, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")
    	end
    	local Text = "Witnesses: "..tostring(Witnesses)
    	local Width, Height = surface.GetTextSize(Text)

    	surface.SetDrawColor(80, 80, 80, 180)
    	surface.DrawRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)
    	surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawOutlinedRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)

    	surface.SetTexture(Texture)
    	surface.SetDrawColor(255, 255, 255, 255)
    	surface.DrawTexturedRect(ScrW()/2 - (Width/2 + 20), 8, 16, 16)
    	surface.SetTextPos(ScrW()/2 - Width/2, 8)
    	surface.DrawText(Text)
    end
    hook.Add("HUDPaint", "WitnessesBox", Draw)
	
	
/*---------------------------------------------------------------------------
Very hacky script that logs the things you spawn and allows you to undo any entity in the undo list.
---------------------------------------------------------------------------*/

local FakeUM = {}
local function MakeFakeUM()
	FakeUM = {}
	function FakeUM:ReadLong()
		return self.ID
	end
	function FakeUM:ReadString()
		return self.Ent
	end
end

local undoTable
local LastCreated = {} -- Sometimes OnEntityCreated gets called before AddUndo arrives. In that case catch the prop.

hook.Add("InitPostEntity", "LogUndoTable", function()
	local usermessageHooks = debug.getupvalues(usermessage.Hook).Hooks
	local AddUndo = usermessageHooks.AddUndo.Function
	local Undone = usermessageHooks.Undone.Function

	usermessage.Hook("AddUndo", function(um)
		local ID, Ent = um:ReadLong(), um:ReadString()
		local Match = string.match(Ent, "Prop .(.*).")
		if Match then
			hook.Call("ae_SpawnedProp", nil, Match, ID, Ent)
		end
		for k,v in pairs(LastCreated) do
			if IsValid(v) and not v.IsMine and string.lower(v:GetModel() or "") == string.lower(Match or "") then
				v.IsMine = true
				table.remove(LastCreated, k)
				hook.Call("ae_ActuallySpawnedProp", nil, v)

				local wep = LocalPlayer():GetActiveWeapon()
				if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == v then
					hook.Call("PhysgunPickup", nil, LocalPlayer(), v)
				end
				break
			end
		end

		MakeFakeUM()

		FakeUM.ID = ID
		FakeUM.Ent = Ent
		AddUndo(FakeUM) -- original AddUndo so that doesn't break
		undoTable = undo.GetTable()
		undoTable[1].IsTaken = false
	end)

	usermessage.Hook("Undone", function(um)
		local ID = um:ReadLong()

		for k,v in pairs(undoTable or {}) do
			local Match = string.match(v.Name, "Prop .(.*).")
			if v.Key == ID and Match then
				hook.Call("ae_RemovedProp", nil, Match)
			end
		end

		MakeFakeUM()
		FakeUM.ID = ID
		Undone(FakeUM)
	end)
end)

hook.Add("OnEntityCreated", "IActuallySpawnedProp", function(prop)
	if not IsValid(prop) or prop:GetClass() ~= "prop_physics" then return end

	for k, v in pairs(undo.GetTable()) do
		local Match = string.lower(string.match(v.Name, "Prop .(.*).") or "")
		if v.IsTaken == false and not prop.IsMine and Match == string.lower(prop:GetModel() or "") then
			hook.Call("ae_ActuallySpawnedProp", nil, prop)
			prop.IsMine = true
			undo.GetTable()[k].IsTaken = true

			local wep = LocalPlayer():GetActiveWeapon()
			if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == prop then
				hook.Call("PhysgunPickup", nil, LocalPlayer(), prop)
			end
			return
		end
	end

	local Index = table.insert(LastCreated, prop)
	timer.Simple(0.2, function() LastCreated[Index] = nil end)
end)

hook.Add("PhysgunPickup", "FPickupProp", function(ply, prop)
	if not prop.IsMine then return end
	LocalPlayer().IsHolding = prop
end)

hook.Add("PhysgunDrop", "FDropProp", function(ply, prop)
	ply.IsHolding = nil
end)

concommand.Add("ae_undonum", function(ply,cmd,args)
	local num = tonumber(args[1])
	local Undo = undo.GetTable()
	if not num or not Undo[num] then return end

	RunConsoleCommand("gmod_undonum", Undo[num].Key)
end)


local LastSpawned = ""
local BlockedModels = {}
local ae_Alternatives = {}
ae_Alternatives["models/props_c17/lockers001a.mdl"] = "models/props/CS_militia/refrigerator01.mdl"
ae_Alternatives["models/props_junk/gascan001a.mdl"] = "models/props_junk/metal_paintcan001a.mdl"
ae_Alternatives["models/props_wasteland/laundry_dryer001.mdl"] = "models/props_rooftop/dome_copper.mdl"
ae_Alternatives["models/props_rooftop/dome_copper.mdl"] = "models/props/CS_militia/crate_stackmill.mdl"
ae_Alternatives["models/props_combine/combine_fence01a.mdl"] = "models/props_c17/utilitypole01b.mdl"
ae_Alternatives["models/props_combine/breen_tube.mdl"] = "models/props/de_nuke/CoolingTower.mdl"
ae_Alternatives["models/props/de_tides/gate_large.mdl"] = "models/props/de_train/Lockers_Long.mdl"
ae_Alternatives["models/props/cs_militia/skylight_glass_p6.mdl"] = "models/props_debris/concrete_chunk02b.mdl"
ae_Alternatives["models/props_rooftop/roof_vent002.mdl"] = "models/props/cs_assault/FireHydrant.mdl"
ae_Alternatives["models/props_debris/walldestroyed03a.mdl"] = "models/props_junk/iBeam01a_cluster01.mdl"
ae_Alternatives["models/props_wasteland/interior_fence002d.mdl"] = "models/props/de_inferno/lattice.mdl"
ae_Alternatives["models/props_junk/sawblade001a.mdl"] = "models/props/CS_militia/skylight_glass_p6.mdl"
ae_Alternatives["models/props/cs_militia/refrigerator01.mdl"] = "models/props_c17/furnitureStove001a.mdl"
ae_Alternatives["models/props_vents/vent_large_grill001.mdl"] = "models/cheeze/pcb2/pcb6.mdl"
ae_Alternatives["models/props/de_train/lockers_long.mdl"] = "models/props_lab/blastdoor001c.mdl"
ae_Alternatives["models/props_canal/canal_bars004.mdl"] = "models/props/CS_militia/sheetrock_leaning.mdl"
ae_Alternatives["models/xqm/coastertrack/slope_225_2.mdl"] = "models/xqm/coastertrack/slope_225_1.mdl"
ae_Alternatives["models/xqm/coastertrack/slope_225_1.mdl"] = "models/hunter/misc/cone4x1.mdl"
ae_Alternatives["models/xqm/coastertrack/slope_90_1.mdl"] = "models/hunter/misc/cone2x1.mdl"
ae_Alternatives["models/hunter/tubes/tube1x1x6.mdl"] = "models/props_docks/dock03_pole01a.mdl"
ae_Alternatives["models/props_phx/construct/metal_angle360.mdl"] = "models/props_junk/trashdumpster02b.mdl"

function FSpawnModel(Model, DontSpawn)
	local check = string.lower(Model)
	if not DontSpawn then
		LastSpawned = string.lower(Model)
	end
	while(table.HasValue(BlockedModels, check) and ae_Alternatives[check]) do
		check = string.lower(ae_Alternatives[check])
	end
	if not DontSpawn then RunConsoleCommand("gm_spawn", check) end
	return check, table.HasValue(BlockedModels, check)
end

hook.Add("PlayerBindPress", "SpawnModel", function(ply, bind, pressed, extraArg)
	local TheBind = string.Explode(' ', bind)
	if not TheBind[1] or string.lower(TheBind[1]) ~= "gm_spawn" or not pressed or extraArg then return end
	local DoSpawn = hook.Call("PlayerBindPress", nil, ply, bind, pressed, true)
	if not DoSpawn then FSpawnModel(TheBind[2]) end
	return true
end)

hook.Add("InitPostEntity", "HookIntoFPP", function()
	if not FPP then return end
	local notify = FPP.AddNotify
	function FPP.AddNotify(str, type)
		if LastSpawned ~= '' and (str == "The model of this entity is in the black list!" or str == "The model of this entity is not in the white list!" or
			str == "Your prop is ghosted because it is too big. Interract with it to unghost it.") then
			table.insert(BlockedModels, string.lower(LastSpawned))
			if ae_Alternatives[string.lower(LastSpawned)] then
				FSpawnModel(ae_Alternatives[string.lower(LastSpawned)])
			end
		end
		return notify(str, type)
	end
end)







/*---------------------------------------------------------------------------
Removes the spawn effect of props
---------------------------------------------------------------------------*/

if SERVER then
	AddCSLuaFile("cl_OverridePropEffect.lua")
	return
end

local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)


//require("cvar2")

function ae_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("ae_bypass", function(ply, cmd, args)
	//ae_ForceVar(args[1], args[2])
end)
concommand.Add("ae_forcevar", function(ply, cmd, args)
	//ae_ForceVar(args[1], args[2])
end)
	


				
				
        if Cokehack.Settings["kill"] then
	RunConsoleCommand("kill","")
end






         if Cokehack.Settings["mply"] then
		 playermenu = true
		 end

local SoundEnt
local SongLength
local RunningSong		= ""
local Seconds			= 0
local name 				= ""
function Playermenu()

	DermaPanel1 = vgui.Create( "DFrame" )
	DermaPanel1:SetPos( 50,25 )
	DermaPanel1:SetSize( 300, 525 )
	DermaPanel1:SetTitle( "AE player" )
	DermaPanel1:SetDeleteOnClose(true)
	DermaPanel1:SetVisible( true )
	DermaPanel1:SetDraggable( true )
	DermaPanel1:ShowCloseButton( true )
	DermaPanel1:MakePopup()

	local DermaListView = vgui.Create("DListView")  
	DermaListView:SetParent(DermaPanel1)  
	DermaListView:SetPos(12.5, 37.5)  
	DermaListView:SetSize(275, 362.5)  
	DermaListView:SetMultiSelect(false)
	DermaListView:AddColumn("Name") // Add column     

	local list = file.Find("sound/songs/*.mp3", "MOD")  
	for k,v in pairs(list) do
	DermaListView:AddLine(v)
	end


	function DermaListView:OnRowSelected( LineID, Line )  
	   name = Line:GetColumnText( 1 )
	end

	local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
	DermaButton:SetText( "Play" )  
	DermaButton:SetPos( 12.5, 412.5 )  
	DermaButton:SetSize( 100, 25 )  
	DermaButton.DoClick = function()
	surface.PlaySound( "ui/buttonclick.wav" )
	SongLength = math.ceil(SoundDuration("songs/"..name))
	RunningSong = name
	play_song("songs/"..name)
	--RunConsoleCommand( "play", "songs/"..name )
	end

	local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
	DermaButton:SetText( "Stop" )  
	DermaButton:SetPos( 187.5, 412.5 )  
	DermaButton:SetSize( 100, 25 )  
	DermaButton.DoClick = function()
		surface.PlaySound( "ui/buttonclick.wav" )
		stop_song()
		Seconds = 0
		SongLength = nil
	end

	local Panel = vgui.Create( "DPanel", DermaPanel1 )
	Panel:SetPos( 12.5, 450 )
	Panel:SetSize( 275, 65 )

	DSongTitle = vgui.Create( "DLabel", Panel )
	DSongTitle:SetPos( 7.5, 2.5 )
	DSongTitle:SetSize( 260, 20 )
	DSongTitle:SetColor(Color(0,20,0,255))
	DSongTitle:SetText( "Now Playing: N/A" )

	local DLabel = vgui.Create( "DLabel", Panel )
	DLabel:SetPos( 7.5, 22.5 )
	DLabel:SetSize( 150, 20 )
	DLabel:SetColor(Color(0,0,0,255)) 
	DLabel:SetText( "Volume" )

	local DTimer = vgui.Create( "DLabel", Panel )
	DTimer:SetPos( 125, 35 )
	DTimer:SetSize( 150, 20 )
	DTimer:SetColor(Color(0,0,0,255)) 
	DTimer:SetText("Song Time: 00:00 / 00:00")
			
	local DermaSlider = vgui.Create("Slider", DermaPanel1)
	DermaSlider:SetPos( 15, 480 ) 
	DermaSlider:SetWide( 100 )
	--DermaSlider:SetText( "Volume" )
	DermaSlider:SetMin(0.1)
	DermaSlider:SetMax(1.0)
	DermaSlider:SetValue(1.0)
	DermaSlider:SetDecimals( 2 )
	DermaSlider.OnValueChanged = function( panel, value )
		SoundEnt:ChangeVolume( value, 1 )
	end

	if !timer.Exists("musicplayertimer3") then
		timer.Destroy("musicplayertimer3")
	end

	timer.Create("musicplayertimer3", 1, 0, function()
		Seconds = Seconds + 1
		if DermaPanel1:IsVisible() == true then
			if SongLength == nil then
				DSongTitle:SetText( "Now Playing: N/A" )
				DTimer:SetText("Song Time: 00:00 / 00:00")
			else
				DSongTitle:SetText( "Now Playing: " .. RunningSong)
				DTimer:SetText("Song Time: " .. string.ToMinutesSeconds(Seconds) .. " / " .. string.ToMinutesSeconds(SongLength))
			end
		end
	end)

end

function Hidemenu()
	if DermaPanel1:IsVisible() == true then
		DermaPanel1:SetVisible(false)
	end
end

function play_song(song_name)
	if file.Find("sound/"..song_name, "MOD") then
		if SoundEnt == nil or SoundEnt:IsPlaying() == false then
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
			SongLength = math.ceil(SoundDuration(song_name))
		else
			SoundEnt:Stop()
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
		end
	end
end

function stop_song()
	if SoundEnt:IsPlaying() == true then
		SoundEnt:Stop()
	end
end

concommand.Add("mp3", Playermenu)
concommand.Add("+mp3", Playermenu)
concommand.Add("-mp3", Hidemenu)

local ae = { Menu = { t = {}; b = {}; c = 0;}; Alive = {}; Spectators = {};}
local snoweps = "weapon_physgun"
// Laser Sight \\
function ae.Barrel( )
if GetConVarNumber( "ae_removelaser" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
if LocalPlayer():GetActiveWeapon():GetClass() == snoweps then
-- //if( !table.HasValue( LaserSightAllowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial(Material("sprites/physbeam"))
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, Color(50, 255, 50, 255) )
local Size = math.random() * 1.35
render.SetMaterial(Material("sprites/redglow1"))
render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() -  LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 30, 30, Color(235,80,80,235) )
cam.End3D()
else

end
end
hook.Add( 'HUDPaint', '\2\3', ae.Barrel )
 
CreateClientConVar( "ae_removelaser", 0, true, false )



function sayThatName(victim, inflictor, killer) //Use the same arguments as the original function you're hooking to
	if killer:IsPlayer()then --Only prints the killer if he was a player.
		victim:PrintMessage(HUD_PRINTTALK, killer:Nick().." killed you!\n")
	end
end
hook.Add("PlayerDeath","informTheVictims",sayThatName)
 

/*---------------------------------------------------------------------------
Ancient player detector script
---------------------------------------------------------------------------*/

local RadiusMode = false
local detectors = {}
local NaarBeeldscherm = debug.getregistry().Vector.ToScreen
surface.CreateFont("FdetectorFont1", {
	size = "coolvetica",
	weight = 32,
	antialias = 500,
	shadow = true,
	font = false})

local FDetDoSay = CreateClientConVar("ae_Det_DoSay", 0, true, false)

local ignores = {"class C_BaseEntity", "func_door", "prop_door_rotating", "class C_PhysPropClientside", "viewmodel", "worldspawn", "class C_HL2MPRagdoll"}

local function ThinkFunction()
	if #detectors < 1 then return end
	local sound1 = Sound("ambient/alarms/siren.wav" )
	local sound = CreateSound(LocalPlayer(), sound1)
	for num, center in pairs(detectors) do
		if not center:IsValid() then return end
		center:SetPos(center.pozizion)
		if center.detectmode then
			local trace = {}
			trace.start = LocalPlayer():GetShootPos()
			trace.endpos = center.pozizion
			trace.filter = LocalPlayer()
			trace.mask = -1
			local TheTrace = util.TraceLine(trace)
			if TheTrace.Hit then
				center.DrawRadius = false
			else
				center.DrawRadius = true
			end

			for k,v in pairs(center.Entities) do
				if not table.HasValue(ents.FindInSphere( center:GetPos(), center.radius), v) then
					table.remove(center.Entities, k)
				end
			end
			for k,v in pairs(ents.FindInSphere( center:GetPos(), center.radius)) do
				local class = v:GetClass()
				if class ==  "prop_physics" and not table.HasValue(center.Entities, v) and not table.HasValue(ignores, class)  then
					table.insert(center.Entities, v)
					aenote(v:GetModel() .. " has entered " .. center.Naam, 1, 5)

					local text = tostring(v:GetModel() .. " has entered " .. center.Naam)

					sound:Play()
					timer.Simple(1, function() sound:Stop() end)
					if v:GetNetworkedString("Owner") ~= "" then
						aenote("Prop belongs to: " .. v:GetNetworkedString("Owner"), 1, 5)
						text = tostring(v:GetModel() .. " of " .. v:GetNetworkedString("Owner") .. " has entered " .. center.Naam)
					elseif (ASS_PP_GetOwner and ASS_PP_GetOwner(v):IsValid()) then
						aenote("Prop belongs to: " .. ASS_PP_GetOwner(v):Nick(), 1, 5)
						text = tostring(v:GetModel() .. " of " .. ASS_PP_GetOwner(v):Nick() .. " has entered " .. center.Naam)
					end

					if FDetDoSay:GetInt() == 1 then
						ae_DelayedSay(text)
					end
				elseif class == "player" and not table.HasValue(center.Entities, v) then
					table.insert(center.Entities, v)
					if v == LocalPlayer() then
						surface.PlaySound("buttons/button14.wav")
					else
						sound:Play()
						timer.Simple(1, function() sound:Stop() end)
						aenote(v:Nick() .. " has entered " ..  center.Naam, 1, 5 )

						if FDetDoSay:GetInt() == 1 then
							ae_DelayedSay(tostring(v:Nick() .. " has entered " ..  center.Naam))
						end
					end
				elseif class ~= "player" and class ~= "prop_physics" and not v:IsWeapon() and not table.HasValue(center.Entities, v) and not table.HasValue(ignores, class) then
					table.insert(center.Entities, v)
					aenote(class .. " has entered " .. center.Naam, 1, 5)

					if FDetDoSay:GetInt() == 1 then
						ae_DelayedSay(tostring(class .. " has entered " .. center.Naam))
					end

					timer.Simple(1, function() sound:Stop() end)
					sound:Play()
				end
			end
		end
	end
end

local function RadiusSelection(ply, bind, pressed)
	if RadiusMode and ply == LocalPlayer() and pressed and string.find(bind, "attack") then
		hook.Remove("HUDPaint", "RadiusFDetector")
		local trace = LocalPlayer():GetEyeTrace()
		detectors[table.Count(detectors)].radius = detectors[table.Count(detectors)]:GetPos():Distance(trace.HitPos)
		RadiusMode = false
		LocalPlayer():ChatPrint("Radius selected: " .. tostring(math.floor(detectors[table.Count(detectors)].radius)))
		detectors[table.Count(detectors)].detectmode = true
		hook.Remove("PlayerBindPress", "Radiusselection")
		hook.Add("Think", "PlayerDetection", ThinkFunction)
		return true
	end
end

local function DrawRadius()
	for k,v in pairs(detectors) do
		if v.DrawRadius == true then
			surface.SetDrawColor(255,0,0,255)
			local pos1_1 = NaarBeeldscherm(v:GetPos() + Vector(v.radius, 0,0))
			local pos1_2 = NaarBeeldscherm(v:GetPos() - Vector(v.radius, 0,0))

			local pos2_1 = NaarBeeldscherm(v:GetPos() + Vector(0, v.radius,0))
			local pos2_2 = NaarBeeldscherm(v:GetPos() - Vector(0, v.radius,0))

			local pos3_1 = NaarBeeldscherm(v:GetPos() + Vector(0,0,v.radius))
			local pos3_2 = NaarBeeldscherm(v:GetPos() - Vector(0,0,v.radius))
			surface.DrawLine(pos1_1.x, pos1_1.y, pos1_2.x, pos1_2.y )
			surface.DrawLine(pos2_1.x, pos2_1.y, pos2_2.x, pos2_2.y )
			surface.DrawLine(pos3_1.x, pos3_1.y, pos3_2.x, pos3_2.y )
		end
	end
end

local function MakeDetector(ply, cmd, args)
	local center = ents.CreateClientProp()
	center:SetPos(LocalPlayer():GetShootPos())
	center:SetModel("models/Items/AR2_Grenade.mdl")
	center:Spawn()
	LocalPlayer():ChatPrint("Select radius(use mouse button)")
	RadiusMode = true
	hook.Add("PlayerBindPress", "Radiusselection", RadiusSelection)
	table.insert(detectors, center)
	detectors[table.Count(detectors)].pozizion = LocalPlayer():GetShootPos() - Vector(0,0,32)
	detectors[table.Count(detectors)].Entities = {}
	detectors[table.Count(detectors)].DrawRadius = false
	detectors[table.Count(detectors)].detectmode = false

	hook.Add("HUDPaint", "RadiusAEDetector", function()
		local trace = LocalPlayer():GetEyeTrace()
		local distance = center:GetPos():Distance(trace.HitPos)
		draw.DrawText(tostring(math.floor(distance)), "FdetectorFont1", ScrW() / 2, ScrH() / 2, Color(255,255,255,255), 1)
	end)
	hook.Add("HUDPaint", "DrawRadiusOfDetectors", DrawRadius)

	if args[1] ~= nil then
		detectors[table.Count(detectors)].Naam = tostring(table.concat(args, " "))
	else
		detectors[table.Count(detectors)].Naam = "your detector"
	end
end
concommand.Add("AEDetector",MakeDetector)

local function removedetectors()
	RadiusMode = false
	if detectors[table.Count(detectors)] and detectors[table.Count(detectors)]:IsValid() then
		detectors[table.Count(detectors)]:Remove()
		LocalPlayer():ChatPrint("Last detector removed")
		table.remove(detectors, table.Count(detectors))
	end
	if #detectors < 1 then
		hook.Remove("HUDPaint", "RadiusFDetector")
		hook.Remove("HUDPaint", "DrawRadiusOfDetectors")
	end
end
concommand.Add("AERemoveDetector",removedetectors)



/*---------------------------------------------------------------------------
Extremely simple script that shows you the info of the thing you're looking at
---------------------------------------------------------------------------*/

local function EntityInformation()
	local trace = LocalPlayer():GetEyeTrace()
	print(trace.Entity:GetClass())
	print(trace.Entity:GetModel())
	if trace.Hit and trace.Entity:IsValid() and string.find(string.lower(trace.Entity:GetClass()), "prop") then
		print(trace.Entity:GetModel())
		print(trace.Entity:GetOwner())
		print(trace.Entity:Health())
		PrintTable(trace.Entity:GetTable())
	elseif trace.Hit and trace.Entity:IsValid() and trace.Entity:GetClass() == "player" then
		print(trace.Entity:Nick())
		print(trace.Entity:Health())
		print(trace.Entity:GetActiveWeapon():GetPrintName())
		print("the guy you're looking at is admin:", trace.Entity:IsAdmin())
	end
end
concommand.Add("ae_GetModel", EntityInformation)


-- PK
function MagnetoThrow()
-- Nice and easy, turn it slow 180
timer.Simple(.02,Turn)
timer.Simple(.04,Turn)
timer.Simple(.06,Turn)
timer.Simple(.08,Turn)
timer.Simple(.10,Turn)
timer.Simple(.12,Turn)
timer.Simple(.14,Turn)
timer.Simple(.16,Turn)
timer.Simple(.18,Turn)
timer.Simple(.20,Turn)
timer.Simple(.22,Turn)
timer.Simple(.24,Turn)
timer.Simple(.26,Turn)
timer.Simple(.28,Turn)
timer.Simple(.30,Turn)
timer.Simple(.32,Turn)
timer.Simple(.34,Turn)
timer.Simple(.36,Turn)
-- OH MY GOD WHIP AROUND 180
	ae_NOAUTOPICKUP = true
	timer.Simple(0.5, function() ae_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
function Turn()
-- Turn function
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,10,0))
end

function TurnBack()
-- Turn 180 function
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles ()-Angle(0,180,0))
end
-- Making it a console command
concommand.Add("ThrowMagneto",MagnetoThrow)

--apex by Muffin
--mHack by Mythik
--local _espon = false -- handled using gui, but you can still check for _espon in this script because _espon is global in the gui script
--local _wallon = false -- do the same for this and replace my example, you can put the right tab names and delete items or add new ones
--local _enton = false
--local _crosson = false

if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();




orange = Color(255,106,0)
lightblue = Color(0,150,255)
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
white = Color(255,255,255)
yellow = Color(0,255,255)
local AE = {}

function AE.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(lightblue, "[AE] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end
 
 
AE.Notify(true,green,"has sucessfully loaded!")
 
local weed = Material( "vgui/hack/weed.png", nocull );
local shield = Material( "icon16/shield.png", nocull );
local shieldadd = Material( "icon16/shield_add.png", nocull );
local user = Material( "icon16/user.png", nocull );
local heart = Material( "icon16/heart.png", nocull );
local money = Material( "icon16/money.png", nocull );

function CreateTimer( sec, rep, func )
        local index = RandomString( 10 )       
        AE.timers[ index ] = sec     
        timer.Create( index, sec, rep, func )
end
function RandomString( len )
        local ret = ""
                for i = 1 , len do
                        ret = ret .. string.char( math.random( 65 , 116 ) )
       end
        return ret
end
AE.timers = {}
CreateClientConVar( "AE_showadmins", 1, true, false )
CreateClientConVar( "AE_rpgod", 1, true, false )
CreateClientConVar( "AE_showspecs", 1, true, false )
CreateClientConVar( "AE_sniper", 1, true, false )
CreateClientConVar( "AE_weed", 1, true, false )
CreateClientConVar( "AE_coke", 1, true, false )
CreateClientConVar( "AE_printer", 1, true, false )
CreateClientConVar( "AE_gmodz", 1, true, false )
CreateClientConVar( "AE_norecoil", 1, true, false )
CreateClientConVar( "AE_lazer", 1, true, false )
CreateClientConVar( "AE_dd", 1, true, false )
CreateClientConVar( "AE_box", 0, true, false )
CreateClientConVar( "AE_c4", 1, true, false )
CreateClientConVar( "AE_nospread", 1, true, false )
CreateClientConVar( "AE_showspec", 1, true, false )
CreateClientConVar( "AE_antiafk", 0, true, false )
CreateClientConVar( "AE_autoreload", 1, true, false )
CreateClientConVar( "AE_perp_playerinfo", 1, true, false )
speedhack_speed = CreateClientConVar( "AE_speedhack_speed", 1, true, false )
AE_speed = 1

--Check if player is alive or dead
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

concommand.Add("AE_dancin", function() _dancin = !_dancin  end)
concommand.Add("AE_esp", function() _espon = !_espon  end)

concommand.Add("AE_allents", function() _allents = !_allents  end)
concommand.Add("AE_crosshair", function() _crosson = !_crosson  end)
concommand.Add("AE_wall", function() _wallon = !_wallon surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("AE_ent", function() _enton = !_enton surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("AE_printents", function() _printent = !_printent end)

local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end

--Speed


VO = GetConVar('sv_allow_voice_from_file')
HT = GetConVar('host_timescale')
SC = GetConVar('sv_cheats')
KI = GetConVar('sv_kickerrornum')



forcevoice = function()
VO:SetValue(1.0)
AE.Notify(true,orange,"Forced CVAR sv_allow_voice_from_file to ", green, "1")
surface.PlaySound("buttons/blip1.wav")
end

forceluakick = function()
KI:SetValue(0.0)
AE.Notify(true,orange,"Forced CVAR sv_kickerrornum to "..KI:GetInt())
surface.PlaySound("buttons/blip1.wav")
end

speedon = function()
SC:SetValue(1.0)
HT:SetValue(speedhack_speed:GetInt())
end

speedoff = function()
HT:SetValue(1.0)
end


concommand.Add("forceluakick", forceluakick)
concommand.Add("forcevoice", forcevoice)
concommand.Add("+AE_speed", speedon)
concommand.Add("-AE_speed", speedoff)

AE.spectators = {}
AE.admins = {}
AE.superadmins = {}


 function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(AE.spectators, v)) then
                                table.insert(AE.spectators, v);
                                        AE.Notify(true,orange,""..v:Name().. " has begun to spectate you.")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
				
        for k, v in pairs(AE.spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(AE.spectators, k);
                                AE.Notify(true,green,""..v:Name().." has stopped spectating you.")
                        end
                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(AE.superadmins, v)) then
                                table.insert(AE.superadmins, v);
                                AE.Notify(true,white,"Super Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(AE.admins, v) and not v:IsSuperAdmin()) then
                                table.insert(AE.admins, v);
                                AE.Notify(true,white,"Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)
if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.
local _R = debug.getregistry();

local AE    = {} -- C is for CHEAT.
AE.Commands = {}
AE.ConVars  = {}
AE.Hooks    = {}
AE.MenuInfo = {}
AE.Meta	   = { _G, hook, concommand, debug, file }
AE.Settings = {}
AE.World	   = { players = {} }

-- spread
function AE:GetCone( wep )
	if !IsValid( wep ) then return 0 end
	
	if AE.HL2Cones[ wep:GetClass() ] then return AE.HL2Cones[ wep:GetClass() ] end
	if AE.NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
	if AE.CustomCones[ wep.Base ] then return AE.CustomCones[ wep.Base ]( wep ) end
	
	local Cone = wep.Cone
	
	if !Cone then
		Cone = wep.Primary and wep.Primary.Cone or 0
	end
	
	return Cone
end

AE.NormalCones 			= {
	[ "weapon_cs_base" ]	= true,
	[ "weapon_sh_base" ] 	= true,
	[ "weapon_zs_base" ] 	= true,
}

AE.HL2Cones 				= {
	[ "weapon_pistol" ] 	= Vector( 0.0100, 0.0100, 0.0100 ),
	[ "weapon_smg1" ] 		= Vector( 0.04362, 0.04362, 0.04362 ),
	[ "weapon_ar2" ]		= Vector( 0.02618, 0.02618, 0.02618 ),
	[ "weapon_shotgun" ]	= Vector( 0.08716, 0.08716, 0.08716 ),
}

AE.CustomCones 			= {
	[ "weapon_sh_base" ]	= function( wep )
								local Cone = wep.Primary.Cone
								local Recoil = AE.WeaponRecoil[ wep:GetClass() ]
								local IsSniper = wep.Sniper and 2 or 1								
								local Stance = wep.Owner:IsOnGround() and wep.Owner:Crouching() and 10
								or !wep.Sprinting and wep.Owner:IsOnGround() and 15
								or wep.Walking and wep.Owner:IsOnGround() and 20
								or !wep.Owner:IsOnGround() and 25
								or wep.Primary.Ammo == "buckshot" and 0
									
								local WepType = wep.Sniper and 8
								or wep.SMG and 2
								or wep.Pistol and 2
								or wep.Primary.Ammo == "buckshot" and 0
								or 1.6								
								local Shotgun = wep.Primary.Ammo == "buckshot" and wep.Primary.Cone or 0			
								if wep:GetIronsights() then
									return Cone
								else
									return Cone * Recoil * Stance * WepType + Shotgun
								end
							end,
	[ "weapon_zs_base" ] = function( wep )
								local Cone = wep.Cone or wep.Primary.Cone or 0		
								if LocalPlayer():GetVelocity():Length() > 20 then
									return wep.ConeMoving
								end									
								if LocalPlayer():Crouching() then
									return wep.ConeCrouching
								end		
								return Cone
							end,
}


function AE:PredictSpread( cmd, ang )
local w = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
		valCone = AE:GetCone( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = Vector( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + (cone * 2 )                        
		end
	else
		if ( w:IsValid() ) then
			local class = w:GetClass()
			if ( AE.CustomCones[ class ] ) then
				vecCone = AE.CustomCones[ class ]
			elseif ( AE.HL2Cones[ class ] ) then
				vecCone = AE.HL2Cones[ class ]
			end
		end
	end
return ( _nyx.RemoveSpread( cmd, ang, vecCone ) ):Angle()
end

--[ RESET METATABLES ]--

function AE:UnlockMeta()
	for i = 1, table.Count( AE.Meta ) do
		rawset( AE.Meta[i], "__metatable", false )
	end
end
AE:UnlockMeta()

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand


AE.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

AE.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "AE_"
}

function AE:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

function AE:AddCommand( name, func )
	return concommand.Add(name,func);
end


AE.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 1, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 1, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 12, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_bunnyhop", Value = 1, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },

	}

function AE:CreateConVars()
	local tbl = AE.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = AE.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		AE.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		AE.MenuInfo[pvar] = cvarinfo
		AE.MenuInfo[#AE.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			AE.Settings[v.Table] = new
		end )
	
		AE.ConVars[pvar] = convar
	end
end
AE:CreateConVars()


function AE:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

function AE:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function AE:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function AE:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function AE:IsTraitor( e )
	local ply = LocalPlayer()
	if not AE:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function AE:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( AE.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if AE:IsAdmin( e ) and AE:G( AE.Settings['ignoreadmins'], 1 ) then return false end
		if AE:IsTraitor( e ) and AE:G( AE.Settings['ignoretraitors'], 1 ) then return false end
		if AE:IsFriend( e ) and AE:G( AE.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and AE:G( AE.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not AE:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if AE:IsAdmin( e ) and AE:G( AE.Settings['ignoreadmins'], 1 ) then return false end
		if AE:IsTraitor( e ) and AE:G( AE.Settings['ignoretraitors'], 1 ) then return false end
		if AE:IsFriend( e ) and AE:G( AE.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and AE:G( AE.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

AE.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function AE:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function AE:GetTargetLocation( e )
	for i = 1, table.Count( AE.ZombieModels ) do
		if ( e:GetModel() == AE.ZombieModels[i][1] ) then return AE:GetPosition( e, AE.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = AE:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = AE:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return AE:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

--[ PREDICTION ]--

function AE:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

--[ AUTOWALL ]--

function AE:IsPenetrable( tr ) -- Thanks noPE.
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function AE:TargetVisible( e )
	local ply = LocalPlayer()
	if AE:G( AE.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = AE:GetTargetLocation( e ) + AE:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( AE:G( AE.Settings['autowall'], 1 ) and AE:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function AE:GetAimTarget()
	if AE:IsTargetValid( AE.Vars.target, "aim" ) and AE:TargetVisible( AE.Vars.target ) then return AE.Vars.target else AE.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if AE:G( AE.Settings['aim'], 1 ) then
		for i = 1, table.Count( AE.World.players ) do
			local e = AE.World.players[i]
			if AE:IsTargetValid( e, "aim" ) and AE:TargetVisible( e ) then
				local pos = AE:GetTargetLocation( e ) + AE:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function AE:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if AE:G( AE.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( AE.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function AE.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	AE.Vars.aacorrectang = ply:GetAimVector():Angle()
	AE.Vars.fakeang = ply:GetAimVector():Angle()
end
AE:AddHook( "OnToggled", AE.OnToggled )

--[ AIMBOT ]--

function AE.Aimbot( cmd )
	local ply, tar = LocalPlayer(), AE:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	AE.Vars.fakeang.p = math.Clamp( AE.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	AE.Vars.fakeang.y = math.NormalizeAngle( AE.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if AE:G( AE.Settings['aim'], 1 ) and ply:Alive() and tar then
		AE.Vars.target = tar
		AE.Vars.found = true
		local pos = AE:GetTargetLocation( tar ) + AE:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( AE.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		AE.Vars.aimingang = ang
		ang = AE:GetSmoothAngle( ang )
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		
		if AE:G( AE.Settings['nospread'], 1 ) and AE:G( AE.Settings['aimsmooth'], 0 ) then
			ang = AE:PredictSpread( cmd, Angle( ang.p, ang.y, 0 ) );
		end
		
		if AE:G( AE.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				AE.Copy.SetViewAngles( cmd, ang )
				AE.Vars.aimlocked = true
			else
				AE.Vars.aimlocked = false
			end
		else
			AE.Copy.SetViewAngles( cmd, ang )
			AE.Vars.aimlocked = true
		end
		if AE:G( AE.Settings['autoshoot'], 1 ) and not AE.Vars.firing then
			RunConsoleCommand( "+attack" )
			AE.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				AE.Vars.firing = false
			end )
		end
	else
		AE.Vars.target = nil
		AE.Vars.aimlocked = false
		AE.Vars.found = false
	end
end


--[[--------------------------------------------
	PLAYERS AND ENTITIES
--]]--------------------------------------------

function AE.GetAllPlayers()
	AE.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( AE.World.players, e ) end
	end
end


function AE.CreateMove( cmd )
	AE.Aimbot( cmd )
	AE.Bunnyhop( cmd )
end
AE:AddHook( "CreateMove", AE.CreateMove )

function AE.ThinkHook()
	AE.GetAllPlayers()
end
AE:AddHook( "Think", AE.ThinkHook )


--ESP
hook.Add("HUDPaint", "ESP", function()
	for k,v in pairs(player.GetAll()) do
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				local ESP2 = (v:EyePos()):ToScreen()
				if v:IsAdmin() and v:IsSuperAdmin() == false then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 7, ESP.y + 30, 16, 16 );
				elseif v:IsSuperAdmin() == true then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shieldadd ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				else
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				end
				draw.RoundedBox(0, ESP.x - 21, ESP.y +49, 42, 7, Color(0,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 5, Color(255,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 2.5, Color(255,255,255,30))
				draw.DrawText(v:Health(), "Herp", ESP.x, ESP.y +46, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end 
						end
		end
	end)
hook.Add("HUDPaint", "PERP", function()
	for k,v in pairs(player.GetAll()) do
	if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetRPName(), "Herp", ESP.x, ESP.y +7, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end)

	
 --Crosshair
hook.Add("HUDPaint", "Crosshair", function()
if _crosson then
	 surface.SetDrawColor( Color(0, 80, 255, 255) );
     surface.SetMaterial( Material("vgui/hack/crosshair.png") );
     surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 end
 end)
 

--Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxESP", function()
if(GetConVarNumber("AE_box") == 1) and _espon then
for k,v in pairs(player.GetAll()) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
    local Box1x,Box1y,Box2x,Box2y = coordinates(v)
    surface.SetDrawColor(team.GetColor(v:Team()))
    surface.DrawLine( Box1x, Box1y, math.min( Box1x + 5, Box2x ), Box1y )
    surface.DrawLine( Box1x, Box1y, Box1x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box2x, Box1y, math.max( Box2x - 5, Box1x ), Box1y )
    surface.DrawLine( Box2x, Box1y, Box2x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box1x, Box2y, math.min( Box1x + 5, Box2x ), Box2y )
    surface.DrawLine( Box1x, Box2y, Box1x, math.max( Box2y - 5, Box1y ) )
    surface.DrawLine( Box2x, Box2y, math.max( Box2x - 5, Box1x ), Box2y )
    surface.DrawLine( Box2x, Box2y, Box2x, math.max( Box2y - 5, Box1y ) )
end
end
end
end)
--I know, I was lazy so I used Skittles.


local t = getfenv( 0 )
_R = t.debug.getregistry()
m = t.LocalPlayer()


--AntiAFK
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
        if GetConVarNumber("AE_antiafk") == 1 then
                local command1 = table.Random( commands )
                local command2 = table.Random( commands )
                CreateTimer( 1, 1, function()
                        RunConsoleCommand( "+"..command1 )
                        RunConsoleCommand( "+"..command2 )
                end )
                CreateTimer( 2, 1, function()
                        RunConsoleCommand("-"..command1 )
                        RunConsoleCommand("-"..command2 )
                end )
        end
end
CreateTimer( 5 , 0 , function() AntiAfk() end )


do --Convenience functions
	function AE.BonePos( pl, bone )
		return pl:GetBonePosition( pl:LookupBone( bone ) )
	end
	function AE.Dist( p1, p2 )
		return p1:GetPos():Distance( p2:GetPos() )
	end
	function AE.Concat( ... )
		return t.string.format( t.string.rep( '%s', t.table.Count( { ... } ) ), ... )
	end
	function AE.RandString()
		local str, len = '', t.math.random( 1, 7 )
 
		while #str < len do
			AE.Concat( str, t.string.char( t.math.random( 97, 122 ) ) )
		end
		return str
	end
	function AE.IsInSight( pl )
		local tr = t.util.TraceLine( { start = t.LocalPlayer():GetShootPos(), endpos = pl:GetPos() + t.Vector( 0, 0, 40 ), filter = { t.LocalPlayer(), pl } } )
    	return tr.Fraction == 1
    end
	
    function AE.CalcVelocity( target )
    	local hcbow = m:GetActiveWeapon():GetClass() == 'weapon_crossbow'
    	if hcbow then
    		local dist = AE.Dist( target, m )
    		return target:GetVelocity() * ( dist / 3100 ) + t.Vector( 0, 0, dist / 500 )
    	end
    	return target:GetVelocity() * 0.01
    end
	function AE.RankInfo( pl )
		if AE.vars.amod == 1 then
			local rank = evolve.ranks[ pl:EV_GetRank() ]
			return {
				name = rank.Title,
				color = t.Color( rank.Color.r, rank.Color.g, rank.Color.b, 255 )
			}
		elseif AE.vars.amod == 2 then
			return {
				name = t.team.GetName( pl:Team() ),
				color = t.team.GetColor( pl:Team() )
			}
		else
			return {
				name = pl:IsSuperAdmin() and 'Super Admin' or ( pl:IsAdmin() and 'Admin' or 'Player' ),
				color = t.team.GetColor( pl:Team() )
			}
		end
	end
end

AE.RCC = RunConsoleCommand



--TTT Propkill
 
concommand.Add("+Propkill", function()
propkill1 = 1
        end)
 
concommand.Add("-Propkill", function()
propkill1 = 0
        end)
 
function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
        end
hook.Add("Think","Tesasd",OpenS)
 
function ReCalc(cmd)
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89)
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove(Forward.x)
cmd:SetSideMove(Forward.y)
 
        end
 end
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)
 
 
function Calc(ply, pos, angles, fov)
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
        end
view.fov = fov
return view
        end
hook.Add("CalcView", "NegTin", Calc)
 
function Throw()
if (LocalPlayer():KeyDown(IN_SPEED)) and propkill1 == 1 then
 
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
 
propkill1 = 0
 
                end
        end
hook.Add("Think","ThrowProp1",Throw)


--Traitor Detector
CreateClientConVar( "AE_traitor", 0, true, false )              
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" and GetConVarNumber("AE_traitor") == 1 then

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
function AE.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(Color(0,150,255), "[AE] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
										AE.Notify(true,red,"Player "..pl:Name().." has traitor weapon ".. "[ ".. v:GetClass().." ]")
										surface.PlaySound("buttons/blip1.wav")

                                end
                        end
                end
        end
   end)
   end
                          

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if GetConVarNumber( "AE_c4" ) >= 1 then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "Herp", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )
 
function TraitorESP()
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
for k,v in pairs ( player.GetAll() ) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
if _espon and v.HatTraitor and GetConVarNumber( "AE_traitor" ) >= 1 then 
local ESP = (v:GetPos()):ToScreen()
draw.DrawText("Traitor", "Herp", ESP.x, ESP.y +56, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end
hook.Add( "HUDPaint", "TraitorESP", TraitorESP )


--Wallhax
hook.Add("HUDPaint", "WallHax", function()
if not _wallon then return end
	for k,v in pairs(player.GetAll()) do
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
				cam.End3D()
				elseif ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
				for k,v in pairs(player.GetAll()) do
				if MESPCheck(v) then
				if v.HatTraitor and GetConVarNumber( "AE_traitor" ) >= 1 then 
				cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 0, 0, 255))
				render.SetColorModulation( 1, 0, 0 )
				v:DrawModel()
			cam.End3D()
		end
	end
	end
	end
	end
	end)
	


	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	

hook.Add("HUDPaint", "PERPY", function()

	CreateClientConVar( "AE_dd", 1, true, false )
	if GetConVarNumber("AE_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
			local posx = 17
		local posy = 15
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 80, Color(45,45,45,180) )
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 20, lightblue )
		draw.SimpleText("Dealer", "Herp", ScrW() /2 * 2 - 75, 45, white, TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Cocaine",
				"Buying Muscle"
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "Herp", ScrW() /2 * 2 - 75, posy + 65, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "Herp", ScrW() /2 * 2 - 75, posy + 95, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

--tiny dancin man
function dance()
if _dancin then
       RunConsoleCommand("act", "dance")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function PrinterESP()

	if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "silver_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Silver Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end

	if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "money_printer_standard" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Standard Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
	
	
		if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
		for k, v in pairs( ents.FindByClass( "gold_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Gold Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 255, 225, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
				
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "platinum_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Platinum Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 191, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			end
			end	
			
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "emerald_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Emerald Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					
			end
			end	
			
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
	end	
	
				
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "tuned_diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Tuned Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

						end
					end		
						
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "sapphire_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sapphire Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			
			end
			end	
			
			if _enton and GetConVarNumber( "AE_gmodz" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "gmodz_item" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Item", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	

			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Shipment", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	
					
			if _enton and GetConVarNumber( "AE_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "level_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Level Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
			if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_swarm" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
					
						if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_brood" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Brood Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	

					
					end


	
		
hook.Add( "HUDPaint", "PrinterESP", PrinterESP )


hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if _allents then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props_c17/consolebox01a.mdl"  or ent:GetModel() != "models/props_c17/consolebox03a.mdl" then
						draw.DrawText("" .. ent:GetClass(), "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money Printer", "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)


function AE.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if AE:G( AE.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end



		hook.Add("HUDPaint", "ShowAdmins", function()
		if GetConVarNumber("AE_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			Adminy = 140
			Admintext = 145
		else
			Adminy = 40
			Admintext = 45
		end
		end)




 hook.Add("HUDPaint", "ShowAdminss", function()
if GetConVarNumber("AE_showadmins") == 1 then
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Adminy, 100, 80 + textLength, Color(45,45,45,180))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, Adminy, 100, 20, lightblue )
draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, Admintext, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, Admintext + 25 + x, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end

		if GetConVarNumber("AE_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (GetConVarNumber("AE_showadmins") == 1) then
			Specy = 240 
			Spectext = 245
		elseif GetConVarNumber("AE_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (GetConVarNumber("AE_showadmins") == 1) then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
			end
			
			
			
if GetConVarNumber("AE_showspecs") == 1 then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color(45,45,45,180))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, lightblue )

draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, Spectext + textLength, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)

local Player = LocalPlayer();
local Weapon = Player:GetActiveWeapon();



function PlayerInfo()
HP = LocalPlayer():Health()
AR = LocalPlayer():Armor()
if GetConVarNumber("AE_perp_playerinfo") == 1 then
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
draw.RoundedBox(0, ScrW() / 2 / 2 - 325, 43, 125, 105, Color(45,45,45,180))
draw.RoundedBox(0, ScrW() / 2 / 2 -325, 43, 125, 20, lightblue )
draw.SimpleText("Player Info", "Herp", ScrW() /2 / 2 -265, 47, white, TEXT_ALIGN_CENTER )

--HP Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 68, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 8, Color(255,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(HP .. "%", "Herp", ScrW() / 2 / 2 -256, 67, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( heart ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 65, 16, 16 );

--Armor Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 88, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 8, Color(0,0,255,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(AR .. "%", "Herp", ScrW() / 2 / 2 -256, 87, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 85, 16, 16 );

--Name
surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 105, 16, 16 );
draw.DrawText(LocalPlayer():GetRPName(), "Herp", ScrW() / 2 / 2 -256, 108, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


--Money in bank
surface.SetMaterial( money ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 125, 16, 16 );
draw.DrawText("$".. string.Comma(LocalPlayer():GetBank()), "Herp", ScrW() / 2 / 2 -256, 128, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


end
end
end
hook.Add("HUDPaint", "PlayerInfo", PlayerInfo)

-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {"cluaeffect",
	"fog",
	"waterlodcontrol",
	"clientragdoll",
	"envtonemapcontroller",
	"entityflame",
	"func_tracktrain",
	"env_sprite",
	"prop_effect",
	"class c_sun",
	"class C_ClientRagdoll",
	"class C_BaseAnimating",
	"clientside",
	"illusionary",
	"shadowcontrol",
	"keyframe",
	"wind",
	"gmod_wire_hologram",
	"effect",
	"stasisshield",
	"shadertest",
	"portalball",
	"portalskydome",
	"cattails"
}

-- cvars
local repmat = CreateClientConVar("devae_xraymaterial", "mat1", true, false)
local PROPColor = CreateClientConVar("devae_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("devae_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("devae_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("devae_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("devae_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("devae_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "devaeDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off


	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end

			for a,b in pairs(NoDraws) do
				local model = ENTS[v]:GetModel() or ""
				if string.find(GetClass(ENTS[v]), b) or string.find(model, b) then -- Hide effects
					SetNoDraw(ENTS[v], false)
				end
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "devae_xray")
		hook.Remove("OnEntityCreated", "devaeRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "devae_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "devaeRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("ae_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	for _, entname in pairs(NoDraws) do
		if string.find(low, entname) or string.find(model, entname) then
			SetNoDraw(v, true)
			return
		end
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end


function aenote(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if FPP then FPP.AddNotify(text, true) return end
	if GAMEMODE.IsSandboxDerived then -- in some gamemodes GAMEMODE:AddNotify() doesn't exist
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound("ambient/water/drip2.wav") -- I don't care about the other drips so no difficult concatenations or something
	end
end


