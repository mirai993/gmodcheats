require("cvar2")

cvar2.SetValue("sv_cheats",1)

local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local ents = ents
local file = file
local hook = hook
local team = team
local cam = cam
local gui = gui
local render = render
local util = util
local vgui = vgui
local concommand = concommand
local cvars = cvars
local debug = debug

CreateClientConVar("ATTargetPlayers",1,false,false)
CreateClientConVar("ATTargetNPCs",1,false,false)
CreateClientConVar("ATIgnoreSteam",0,false,false)
CreateClientConVar("ATIgnoreDistance",1,false,false)
CreateClientConVar("ATAimDistance",1024,false,false)
CreateClientConVar("ATWallHack",0,false,false)
CreateClientConVar("ATAimRadius",30,false,false)
CreateClientConVar("ATNPCNames",0,false,false)
local BoneList = {}
local AT = {}
AT.Aim = 0
AT.View = 0
concommand.Add("+Aim",function()
	AT.Aim = 1	
end)

concommand.Add("-Aim",function()
	AT.Aim = 0	
	RunConsoleCommand("-attack")
end)

BoneList["models/combine_scanner.mdl"] = "Scanner.Body"	
		
BoneList["models/hunter.mdl"] = "MiniStrider.body_joint"

BoneList["models/combine_turrets/floor_turret.mdl"] = "Barrel"	

BoneList["models/dog.mdl"] = "Dog_Model.Eye"

BoneList["models/antlion.mdl"] = "Antlion.Body_Bone"

BoneList["models/antlion_guard.mdl"] = "Antlion_Guard.Body" 			

BoneList["models/antlion_worker.mdl"] = "Antlion.Head_Bone" 			

BoneList["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube"	

BoneList["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube"		

BoneList["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl"

BoneList["models/headcrabblack.mdl"] = "HCBlack.body"				

BoneList["models/headcrab.mdl"] = "HCFast.body"					

BoneList["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1"

BoneList["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone"	

BoneList["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone"

BoneList["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone" 

BoneList["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone"			
	
BoneList["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"

function AT.GetBonePos( ply )	
	if ply:GetAttachment(ply:LookupAttachment("eyes")) then		
		return ply:GetAttachment(ply:LookupAttachment("eyes")).Pos + ply:GetAttachment(ply:LookupAttachment("eyes")).Ang:Forward()*-3			
	elseif BoneList[ply:GetModel()] then			
		return ply:GetBonePosition(ply:LookupBone(BoneList[ply:GetModel()]))			
	else
		return ply:EyePos()-Vector(0,0,3)
	end
end

function AT.FovCheck( ent, fov )
	if fov == 0 or fov == 180 then return true end
	if ValidEntity( ent ) then	
		if math.NormalizeAngle( ( AT.GetBonePos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LocalPlayer():EyeAngles().y ) > fov then return false end	
		if math.NormalizeAngle( ( AT.GetBonePos( ent ) - LocalPlayer():GetShootPos()):Angle().y - LocalPlayer():EyeAngles().y ) < -fov then return false end
		if math.NormalizeAngle( ( AT.GetBonePos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LocalPlayer():EyeAngles().p ) < -fov then return false end
		if math.NormalizeAngle( ( AT.GetBonePos( ent ) - LocalPlayer():GetShootPos()):Angle().p - LocalPlayer():EyeAngles().p ) > fov then return false end		
	end
	return true
end

function AT.Visible( ply )
	local trace = {}	
	trace.start = LocalPlayer():GetShootPos()	
	trace.endpos = AT.GetBonePos( ply )	
	trace.mask = MASK_SHOT	
	trace.filter = {LocalPlayer(),ply}	
	local tr = util.TraceLine(trace)	
	return tr.Fraction == 1 and true or false	
end

function AT.Flags(e)
    if e:IsPlayer() then	
        if !e:IsValid() then return false end	
        if GetConVarNumber("ATIgnoreDistance") == 0 and e:GetPos():Distance(LocalPlayer():GetPos()) > GetConVarNumber("ATAimDistance") then return false end	
        if not e:Alive() and e:Health() < 1 then return false end		
		if e:GetMoveType() == MOVETYPE_OBSERVER then return false end		
        if e == LocalPlayer() then return false end    		
		if GetConVarNumber("ATTargetPlayers") == 0 then return false end		
        return true		
    end	
    if e:IsNPC() then	
    	if GetConVarNumber("ATIgnoreDistance") == 0 and e:GetPos():Distance(LocalPlayer():GetPos()) > GetConVarNumber("ATAimDistance") then return false end
        if e:GetMoveType() == 0 then return false end		
		if GetConVarNumber("ATTargetNPCs") == 0 then return false end		
        return true		
    end	
    return false
end

function AT.Targets()
	local TTbl = {}
	for k,v in pairs(ents.GetAll()) do
		if AT.Flags(v) == true then
			table.insert(TTbl,v)		
		end	
	end
	return TTbl
end
	
function AT.Target()
	local Targs = {0,0}
	local pos = LocalPlayer():GetPos()
	local ang = LocalPlayer():GetAimVector()
	for k,v in pairs(AT.Targets()) do
		if AT.Visible(v) and AT.FovCheck(v,GetConVarNumber("ATAimRadius")) then
			local t = (v:GetPos()-pos):Normalize()
			t = t - ang
			t = t:Length()
			t = math.abs(t)
			if t < Targs[2] or Targs[1] == 0 then
				Targs = {v,t}
			end
		end
	end
	return Targs[1]	
end

local SetViewAngles = _R.CUserCmd.SetViewAngles

function AT.AimBot(cmd)
	if AT.Aim == 1 and tonumber(AT.Target()) == nil then
		SetViewAngles(cmd,(AT.GetBonePos(AT.Target())+AT.Target():GetVelocity()/70-LocalPlayer():GetShootPos()):Angle())
	end
end
hook.Add("CreateMove","ATAimBot",AT.AimBot)
	
concommand.Add("PrintTarget",function()
	print("Name: "..AT.Target():Name().." HeadPos: "..tostring(AT.GetBonePos(AT.Target())).." Velocity"..tostring(AT.Target():GetVelocity()))
end)

local IF = 0
function AT.AimBotAttack()
	if ValidEntity(LocalPlayer():GetActiveWeapon()) and tonumber(AT.Target()) == nil then
		if AT.Aim == 1 and tonumber(AT.Target()) == nil then	
			if LocalPlayer():GetActiveWeapon().Primary then
				if LocalPlayer():GetActiveWeapon().Primary.Automatic then	
					RunConsoleCommand("+attack")		
				else			
					IF = IF + 1					
					if IF > 1 then					
						RunConsoleCommand("-attack")						
						IF = 0						
					else					
						RunConsoleCommand("+attack")						
					end						
				end		
			else			
				RunConsoleCommand("+attack")				
			end
		end
		if LocalPlayer():GetActiveWeapon():Clip1() < 1 and LocalPlayer():GetActiveWeapon().Primary then
			if LocalPlayer():GetActiveWeapon().Primary.ClipSize > 0 then 
				RunConsoleCommand("+reload")
				timer.Simple(0.1,function()
					RunConsoleCommand("-reload")
				end)
			end
		end
	elseif AT.Aim == 1 then
		RunConsoleCommand("-attack")
	end
end
hook.Add("Think","ATAttack",AT.AimBotAttack)

function AT.Recoil()
	if ValidEntity(LocalPlayer():GetActiveWeapon()) then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end
hook.Add("Think","ATRecoil",AT.Recoil)

function AT.ESP()
	for k,v in ipairs(player.GetAll()) do	
		if v != LocalPlayer() then 	
			local pos = v:GetShootPos():ToScreen()			
			local w1 = surface.GetTextSize(v:Name())/2			
			local w2 = surface.GetTextSize("Health: "..v:Health())/2	
			local x = pos.x	
			local y = pos.y			
			if v:GetPos():Distance(LocalPlayer():GetPos())>50 then
				draw.SimpleTextOutlined(v:Name(), "ScoreboardText", x-w1, y-80, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 2, Color(0,0,0,255))				
				draw.SimpleTextOutlined("Health: "..v:Health(), "ScoreboardText", x-w2, y-67, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 2, Color(0,0,0,255))				
			end  
		end  
	end
	if GetConVarNumber("ATNPCNames") == 1 then
		for k,v in ipairs(ents.FindByClass("npc_*")) do
			local pos = AT.GetBonePos(v):ToScreen()		
			local w1 = surface.GetTextSize(v:GetClass())/2				
			local x = pos.x	
			local y = pos.y			
			if v:GetPos():Distance(LocalPlayer():GetPos())>50 then
				local text = v:GetClass()
				text = string.sub(text,4)
				text = string.Replace(text,"_"," ")
				draw.SimpleTextOutlined(text, "ScoreboardText", x-w1, y-80, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 2, Color(0,0,0,255))				
				surface.SetDrawColor(255,255,255,255)
				surface.DrawOutlinedRect( x-5, y-5, 10, 10)		
			end  
		end
	end
end
hook.Add("HUDPaint","ESP",AT.ESP)

concommand.Add("ATToggleWallHack",function()
	if AT.View == 0 then
		AT.View = 1
	elseif AT.View == 1 then
		AT.View = 0
	end
end)

function AT.WallHack()
	for k,v in pairs(player.GetAll()) do	
		cam.Start3D(EyePos(),EyeAngles())		
			if GetConVarNumber("ATWallHack") == 1 then				
				if GetMat == 1 then			
					v.Material = v:GetMaterial()					
					GetMat = 0					
				end	
				v:DrawModel()			
				v:SetMaterial("debug/debugdrawflat")		
				v:SetColor(team.GetColor(v:Team()).r,team.GetColor(v:Team()).g,team.GetColor(v:Team()).b,255)		
			else			
				GetMat = 1			
				v:SetColor(255,255,255,255)				
				v:SetMaterial(v.Material)				
			end	
		cam.End3D()	
	end
end
hook.Add("HUDPaint","ATWallHack",AT.WallHack)


local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 350,250 )
DermaPanel:SetSize( 250, 400 )
DermaPanel:SetTitle( "AimTee Menu" )
DermaPanel:SetVisible( false )
DermaPanel:SetDraggable( false )
DermaPanel:ShowCloseButton( false )
DermaPanel:MakePopup()

local PlTbl = {}

local DermaTE1 = vgui.Create("DTextEntry",DermaPanel)
DermaTE1:SetPos(25,105)
DermaTE1:SetSize(200,250)
DermaTE1:SetMultiline(true)

local DermaTE2 = vgui.Create("DMultiChoice",DermaPanel)
DermaTE2:SetPos(25,80)
DermaTE2:SetSize(200,20)
DermaTE2.OnSelect = function(index,value,data)
	local Pl
	local PlName = string.lower(data)
	local PlName2 = string.Replace(PlName,"(1)","")
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Name()),PlName2) then
			Pl = v
		end
	end
	if ValidEntity(Pl) then
		PlTbl.Name = Pl:Name()
		PlTbl.SteamID = Pl:SteamID()
		PlTbl.UniqueID = Pl:UniqueID()
		PlTbl.PlayTime = Pl.Created;
		PlTbl.Admin = tostring(Pl:IsAdmin())
		PlTbl.SuperAdmin = tostring(Pl:IsSuperAdmin())
		PlTbl.Friend = tostring(Pl:GetFriendStatus() == "friend")
		local expl = string.Explode(":", Pl:SteamID())
    	local friendid = string.format("765%0.f", tonumber(expl[3]) * 2 + 61197960265728 + tonumber(expl[2]))
    	PlTbl.CommunityLink = "http://steamcommunity.com/profiles/"..friendid
    end
    DermaTE1:SetValue("Name = "..PlTbl.Name.."\n\nFriend = "..PlTbl.Friend.."\n\nSteamID = "..PlTbl.SteamID.."\n\nUniqueID = "..PlTbl.UniqueID.."\n\nPlaying Time = "..PlTbl.PlayTime.."\n\nSteam Link = "..PlTbl.CommunityLink.."\n\nAdmin = "..PlTbl.Admin.."\n\nSuperAdmin = "..PlTbl.SuperAdmin)
end
concommand.Add("+ATMenu",function()
	DermaPanel:SetVisible(true)
	for k,v in pairs(player.GetAll()) do
		if not v:IsBot() then
			DermaTE2:AddChoice(v:Name())
		end
	end
end)

concommand.Add("-ATMenu",function()
	DermaPanel:SetVisible(false)
	DermaTE2:Clear()
end)
 
local SomeCollapsibleCategory = vgui.Create("DCollapsibleCategory", DermaPanel)
SomeCollapsibleCategory:SetPos( 25,50 )
SomeCollapsibleCategory:SetSize( 200, 50 ) -- Keep the second number at 50
SomeCollapsibleCategory:SetExpanded( 0 ) -- Expanded when popped up
SomeCollapsibleCategory:SetLabel( "Hack Options" )
function SCCThink()
	if SomeCollapsibleCategory:GetExpanded() == true then
		DermaTE2:SetPos(25,365)
		DermaTE1:SetPos(25,340)
		DermaTE1:SetSize(200,25)
	else
		timer.Simple(0.3,function()
			DermaTE2:SetPos(25,80)
			DermaTE1:SetPos(25,105)
			DermaTE1:SetSize(200,250)
		end)
	end
end
hook.Add("Think","SCCThink",SCCThink)
 
CategoryList = vgui.Create( "DPanelList" )
CategoryList:SetAutoSize( true )
CategoryList:SetSpacing( 5 )
CategoryList:EnableHorizontal( false )
CategoryList:EnableVerticalScrollbar( true )
 
SomeCollapsibleCategory:SetContents( CategoryList ) -- Add our list above us as the contents of the collapsible category
 
local CategoryContentOne = vgui.Create( "DCheckBoxLabel" )
CategoryContentOne:SetText( "Target Players" )
CategoryContentOne:SetConVar( "ATTargetPlayers" )
CategoryContentOne:SizeToContents()
CategoryList:AddItem( CategoryContentOne ) -- Add the above item to our list
 
local CategoryContentTwo = vgui.Create( "DCheckBoxLabel" )
CategoryContentTwo:SetText( "Target NPCs" )
CategoryContentTwo:SetConVar( "ATTargetNPCs" )
CategoryContentTwo:SizeToContents()
CategoryList:AddItem( CategoryContentTwo )
 
local CategoryContentThree = vgui.Create( "DCheckBoxLabel" )
CategoryContentThree:SetText( "Show Particles" )
CategoryContentThree:SetConVar( "r_drawparticles" )
CategoryContentThree:SizeToContents()
CategoryList:AddItem( CategoryContentThree )
 
local CategoryContentFour = vgui.Create( "DCheckBoxLabel" )
CategoryContentFour:SetText( "Full Bright" )
CategoryContentFour:SetConVar( "mat_fullbright" )
CategoryContentFour:SizeToContents()
CategoryList:AddItem( CategoryContentFour )
 
local CategoryContentFive = vgui.Create( "DCheckBoxLabel" )
CategoryContentFive:SetText( "Ignore Aim Distance" )
CategoryContentFive:SetConVar( "ATIgnoreDistance" )
CategoryContentFive:SizeToContents()
CategoryList:AddItem( CategoryContentFive )
 
local CategoryContentSix = vgui.Create( "DNumSlider" )
CategoryContentSix:SetSize( 150, 50 ) -- Keep the second number at 50
CategoryContentSix:SetText( "Max Aim Distance" )
CategoryContentSix:SetMin( 0 )
CategoryContentSix:SetMax( 8192 )
CategoryContentSix:SetDecimals( 0 )
CategoryContentSix:SetConVar( "ATAimDistance" )
CategoryList:AddItem( CategoryContentSix )

local CategoryContentSix = vgui.Create( "DNumSlider" )
CategoryContentSix:SetSize( 150, 50 ) -- Keep the second number at 50
CategoryContentSix:SetText( "Max Aim Radius (FOV)" )
CategoryContentSix:SetMin( 0 )
CategoryContentSix:SetMax( 180 )
CategoryContentSix:SetDecimals( 0 )
CategoryContentSix:SetConVar( "ATAimRadius" )
CategoryList:AddItem( CategoryContentSix )

local CategoryContentSeven = vgui.Create( "DCheckBoxLabel" )
CategoryContentSeven:SetText( "Ignore Steam Friends" )
CategoryContentSeven:SetConVar( "ATIgnoreSteam" )
CategoryContentSeven:SizeToContents()
CategoryList:AddItem( CategoryContentSeven )

local CategoryContentSeven = vgui.Create( "DCheckBoxLabel" )
CategoryContentSeven:SetText( "Toggle WallHack" )
CategoryContentSeven:SetConVar( "ATWallHack" )
CategoryContentSeven:SizeToContents()
CategoryList:AddItem( CategoryContentSeven )

local CategoryContentSeven = vgui.Create( "DCheckBoxLabel" )
CategoryContentSeven:SetText( "Toggle NPC Names" )
CategoryContentSeven:SetConVar( "ATNPCNames" )
CategoryContentSeven:SizeToContents()
CategoryList:AddItem( CategoryContentSeven )
--[[
]]--