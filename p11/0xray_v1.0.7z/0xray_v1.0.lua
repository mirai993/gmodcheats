/*

	0xray - A simple & clean propkilling xray
	by 0xymoron
	
	THIS IS PUBLICLY RELEASED, NO YOU DID NOT LEAK THIS.
	
	I got bored & decided to make this & release it.
	
*/

local xray = {}

local g = table.Copy( _G )
local r = g.debug.getregistry()

xray.Props = { -- Add models here
	["models/props/de_tides/gate_large.mdl"] = true,
	["models/props_combine/breendesk.mdl"] = true,
	["models/props_junk/sawblade001a.mdl"] = true,
	["models/props_junk/sawblade001a.mdl"] = true,
	["models/props_junk/TrashDumpster01a.mdl"] = true,
	["models/props_lab/blastdoor001c.mdl"] = true,
	["models/props_interiors/VendingMachineSoda01a.mdl"] = true,
	["models/props_c17/furnitureStove001a.mdl"] = true,
	["models/props_canal/canal_bars004.mdl"] = true,
	["models/props/de_train/lockers_long.mdl"] = true,
	["models/props/de_train/lockers001a.mdl"] = true,
	["models/props_c17/Lockers001a.mdl"] = true,
	["models/props_c17/FurnitureCouch001a.mdl"] = true,
	["models/props_phx/construct/metal_angle360.mdl"] = true,
	["models/props_phx/construct/plastic/plastic_angle_360.mdl"] = true,
	["models/props_phx/construct/glass/glass_angle360.mdl"] = true,
	["models/props_borealis/door_wheel001a.mdl"] = true,
	["models/props_wasteland/laundry_dryer002.mdl"] = true,
}

xray.Hooks = {}

xray.Colors = {
	["Red"] = g.Color( 255, 0, 0 ),
	["SexyRed"] = g.Color( 205, 54, 54 ),
	["Blue"] = g.Color( 0, 52, 255 ),
	["Yellow"] = g.Color( 225, 205, 0 ),
	["White"] = g.Color( 255, 255, 255 ),
	["Green"] = g.Color( 0, 225, 0, 255 ),
	["Purple"] = g.Color( 255, 255, 0, 255 ),
	["Cyan"] = g.Color( 0, 255, 255, 255 ),
	["Grey"] = g.Color( 100, 100, 100, 255 ),
	["lightBlue"] = g.Color( 155, 205, 248 ),
	["lightGreen"] = g.Color( 174, 255, 0, 255 ),
	["iceBlue"] = g.Color( 116, 187, 251, 255 ),
}

g.surface.CreateFont( "0xray_$HUD", { size = 25, weight = 0, antialias = true, shadow = false, font = "Tahoma" } )


/************************

	Backend functions

*************************/

function xray.LoadProps()

	if !g.file.Exists( "0xray_props.txt", "DATA" ) then
		
		g.file.Write( "0xray_props.txt", g.util.TableToJSON( xray.Props ) )
		g.chat.AddText( xray.Colors.lightBlue, "[0xray] ", xray.Colors.lightGreen, "Created prop list." )
	
	else
		
		xray.Props = g.util.JSONToTable( g.file.Read( "0xray_props.txt", "DATA" ) )
		g.chat.AddText( xray.Colors.lightBlue, "[0xray] ", xray.Colors.lightGreen, "Loaded prop list." )
	
	end
	
end

function xray.SaveProps()
	
	if g.file.Exists( "0xray_props.txt", "DATA" ) then
		
		g.file.Write( "0xray_props.txt", g.util.TableToJSON( xray.Props ) )
		g.MsgC( xray.Colors.SexyRed, "[0xray] Saved props list\n" )
		
	end

end

function xray.Add( model )

	xray.Props[model] = true
	g.MsgC( xray.Colors.iceBlue, "[0xray] " )
	g.MsgC( xray.Colors.White, "Added model '" .. model .. "' to props list\n" )		
	xray.SaveProps()

end

function xray.Remove( model )
	
	xray.Props[model] = nil
	g.MsgC( xray.Colors.Red, "[0xray] " )
	g.MsgC( xray.Colors.White, "Removed model '" .. model .. "' to props list\n" )		
	xray.SaveProps()
	
end

local hookName
function xray.AddHook( Type, Function )

	hookName = g.tostring( Function )
	xray.Hooks[Type] = hookName
	
	return g.hook.Add( Type, hookName, Function )	
	
end

/*********************
	
	Visual backend
	
**********************/

local trace = {}
local ret
function xray.IsVisible( ent )

	trace.start = g.LocalPlayer():GetShootPos()
	trace.endpos = ent:GetPos() + g.Vector( 0, 0, 5 )
	trace.filter = { g.LocalPlayer(), ent }
	trace.mask = g.MASK_SHOT
	
	ret = g.util.TraceLine( trace )
	
	return ret.Fraction == 1
	
end

function xray.GetColor( ent )	

	if ent:GetVelocity():Length() != 0 then	
	
		if !xray.IsVisible( ent ) then
		 
			return g.Color( 200, 0, 0, 150 )
			
		else
		
			return g.Color( 0, 200, 0, 150 )
			
		end	
		
	else	
	
		return g.Color( 200, 200, 0, 150 )
		
	end

end
	
/************************

	Hooked functions	
	
************************/

local col
local tracePos = {}
local traceDraw
local pos
local mySpeed
function xray.HUDPaint()
	
	for k, v in g.next, g.ents.GetAll() do	
	
		if v:IsPlayer() or xray.Props[v:GetModel()] then	
		
			-- Prop Chams
			if xray.Props[ v:GetModel() ] then
				
				col = xray.GetColor( v )

				g.cam.Start3D( g.EyePos(), g.EyeAngles() )
					g.render.SuppressEngineLighting( true )
					
					v:SetColor( col )
					
					g.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255 )			
					g.render.SetBlend( col.a / 255 )
					
					r.Entity.SetMaterial( v, "models/debug/debugwhite" )
					r.Entity.DrawModel( v ) 
					
					g.render.SuppressEngineLighting( false )
				g.cam.End3D()		
				
			-- Player chams
			elseif v:IsPlayer() && v:Alive() && v != g.LocalPlayer() && v:Team() != g.TEAM_SPECTATOR then
	
				col = g.team.GetColor( v:Team() )	
				pos = v:GetPos():ToScreen()

				g.cam.Start3D( g.EyePos(), g.EyeAngles() )	
					g.render.SuppressEngineLighting( true )
					
					v:SetColor( col )
					
					g.render.SetColorModulation( col.r / 255, col.g / 255, col.b / 255 )			
					g.render.SetBlend( col.a / 255 )
					
					r.Entity.SetMaterial( v, "models/debug/debugwhite" )
					r.Entity.DrawModel( v ) 
					
					-- Laser to roof of map
					g.render.SetMaterial( g.Material( "trails/laser" ) )
					g.render.DrawBeam( v:GetShootPos(), v:GetPos() + g.Vector( 0, 0, 850 ), 30, 1, 1, g.Color( 255, 0, 255 ) )				
					
					g.render.SuppressEngineLighting( false )
				g.cam.End3D()
						
				-- Traditional XRay WordBox esp
				g.draw.WordBox( 1, pos.x - g.surface.GetTextSize( v:Nick() ) / 2, pos.y, v:Nick(), "default", g.Color( 0, 0, 0, 150 ), g.Color( 255, 255, 255, 255 ) )
				
			end
			
		else	
		
			continue
			
		end
	
	end
	
	r.Entity.SetMaterial( g.LocalPlayer():GetViewModel(), "models/wireframe" )
	r.Entity.SetColor( g.LocalPlayer():GetViewModel(), xray.Colors.iceBlue )
	
	mySpeed = "Speed: " .. g.math.Round( g.LocalPlayer():GetVelocity():Length() )
	g.draw.WordBox( 1, g.ScrW() / 2 - g.surface.GetTextSize( mySpeed ), 5, mySpeed, "0xray_$HUD", g.Color( 0, 0, 0, 150 ), g.Color( 255, 255, 255 ) )
		
end

function xray.CreateMove( cmd )
	
	if !g.LocalPlayer():IsOnGround() && g.LocalPlayer():GetMoveType() != g.MOVETYPE_LADDER then
		cmd:SetButtons( g.bit.band( cmd:GetButtons(), g.bit.bnot( g.IN_JUMP ) ) )
	end
	
end

/*************************
	
	Loading the script
	
*************************/	

function xray.Start()	

	g.chat.AddText( xray.Colors.iceBlue, "[0xray] ", xray.Colors.White, "Loaded! ", xray.Colors.lightGreen, "Coded by 0xymoron @ mpgh.net" )
	g.chat.AddText( xray.Colors.lightBlue, "[0xray] Commands - ", xray.Colors.Green, "0x_addmodel <model path> - 0x_removemodel <model path>" )
	g.surface.PlaySound( "ambient/fire/ignite.wav" )

	xray.LoadProps()
	
	g.concommand.Add( "0x_addmodel", function( ply, cmd, tbl, args )
		xray.Add( args )
	end )
	
	g.concommand.Add( "0x_removemodel", function( ply, cmd, tbl, args )
		xray.Remove( args )
	end )
	
	xray.AddHook( "HUDPaint", xray.HUDPaint )
	xray.AddHook( "CreateMove", xray.CreateMove )	
	
end

xray.Start()	